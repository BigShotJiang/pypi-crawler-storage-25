/** Workbench utilities — environment/session APIs and WebSocket URL derivation. */

import { getApiBaseUrl } from '@/lib/settings';
import { getAccessToken } from '@/lib/auth-storage';

// ---------------------------------------------------------------------------
// WebSocket helpers
// ---------------------------------------------------------------------------

export function getWsBaseUrl(): string {
  const apiBase = getApiBaseUrl();

  if (apiBase) {
    return apiBase.replace(/^http/, 'ws');
  }

  if (typeof window !== 'undefined') {
    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    return `${proto}//${window.location.host}`;
  }

  return 'ws://localhost:8005';
}

export function getTerminalWsUrl(
  sessionId: string,
  opts: { command?: string; envId?: string } = {},
): string {
  const base = getWsBaseUrl();
  const token = getAccessToken();
  const params = new URLSearchParams();
  if (opts.command) params.set('command', opts.command);
  if (opts.envId) params.set('env_id', opts.envId);
  if (token) params.set('token', token);
  return `${base}/api/v1/workbench/ws/${sessionId}?${params.toString()}`;
}

// ---------------------------------------------------------------------------
// Shared fetch helper
// ---------------------------------------------------------------------------

function authHeaders(extra?: Record<string, string>): Record<string, string> {
  const headers: Record<string, string> = { ...extra };
  const token = getAccessToken();
  if (token) headers['Authorization'] = `Bearer ${token}`;
  return headers;
}

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface WorkbenchCapabilities {
  venv: boolean;
  docker: boolean;
  services: boolean;
  session_idle_timeout_seconds?: number;
}

export interface EnvironmentInfo {
  env_id: string;
  backend: 'venv' | 'docker';
  created_at: number;
  session_count: number;
}

export interface WorkbenchSession {
  session_id: string;
  env_id: string;
  command: string;
  backend_type: string;
  pid: number;
  cols: number;
  rows: number;
  alive: boolean;
}

export interface PackageInfo {
  name: string;
  version: string;
}

// ---------------------------------------------------------------------------
// Capabilities (public, no auth needed)
// ---------------------------------------------------------------------------

export async function getCapabilities(): Promise<WorkbenchCapabilities> {
  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/v1/workbench/capabilities`);
  if (!res.ok) return { venv: true, docker: false, services: false };
  return res.json();
}

// ---------------------------------------------------------------------------
// Environment CRUD
// ---------------------------------------------------------------------------

export async function createEnvironment(
  backend: string = 'venv',
  profile?: string,
): Promise<EnvironmentInfo> {
  const base = getApiBaseUrl();
  const body: Record<string, string> = { backend };
  if (profile) body.profile = profile;
  const res = await fetch(`${base}/api/v1/workbench/environments`, {
    method: 'POST',
    headers: authHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Failed to create environment: ${body}`);
  }

  return res.json();
}

export async function listEnvironments(): Promise<EnvironmentInfo[]> {
  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/v1/workbench/environments`, {
    headers: authHeaders(),
  });
  if (!res.ok) return [];
  const data = await res.json();
  return data.environments ?? [];
}

export async function destroyEnvironment(envId: string): Promise<void> {
  const base = getApiBaseUrl();
  await fetch(`${base}/api/v1/workbench/environments/${envId}`, {
    method: 'DELETE',
    headers: authHeaders(),
  });
}

export async function listPackages(envId: string): Promise<PackageInfo[]> {
  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/v1/workbench/environments/${envId}/packages`, {
    headers: authHeaders(),
  });
  if (!res.ok) return [];
  const data = await res.json();
  return data.packages ?? [];
}

// ---------------------------------------------------------------------------
// Package install / uninstall
// ---------------------------------------------------------------------------

export interface PackageOperationResult {
  success: boolean;
  output: string;
  packages: PackageInfo[];
}

export async function installPackages(
  envId: string,
  packages: string[],
  opts: { editable?: boolean; upgrade?: boolean } = {},
): Promise<PackageOperationResult> {
  const base = getApiBaseUrl();
  const res = await fetch(
    `${base}/api/v1/workbench/environments/${envId}/packages/install`,
    {
      method: 'POST',
      headers: authHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({
        packages,
        editable: opts.editable ?? false,
        upgrade: opts.upgrade ?? false,
      }),
    },
  );
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Install failed: ${body}`);
  }
  return res.json();
}

export async function uninstallPackages(
  envId: string,
  packages: string[],
): Promise<PackageOperationResult> {
  const base = getApiBaseUrl();
  const res = await fetch(
    `${base}/api/v1/workbench/environments/${envId}/packages/uninstall`,
    {
      method: 'POST',
      headers: authHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ packages }),
    },
  );
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Uninstall failed: ${body}`);
  }
  return res.json();
}

// ---------------------------------------------------------------------------
// Profiles
// ---------------------------------------------------------------------------

export interface EnvironmentProfile {
  name: string;
  description: string;
  backend: string;
  packages: string[];
  editable_packages: string[];
}

export async function listProfiles(): Promise<EnvironmentProfile[]> {
  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/v1/workbench/profiles`);
  if (!res.ok) return [];
  const data = await res.json();
  return data.profiles ?? [];
}

// ---------------------------------------------------------------------------
// Recipe templates (for Send Data)
// ---------------------------------------------------------------------------

export interface RecipeTemplate {
  name: string;
  description: string;
}

export async function listRecipeTemplates(): Promise<RecipeTemplate[]> {
  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/v1/recipes/list`, {
    headers: authHeaders(),
  });
  if (!res.ok) return [];
  const data = await res.json();
  return data.recipes ?? [];
}

/** Load shipped template YAML by template name (from list). */
export async function fetchRecipeTemplateYaml(name: string): Promise<string> {
  const base = getApiBaseUrl();
  const res = await fetch(
    `${base}/api/v1/recipes/templates/${encodeURIComponent(name)}`,
    { headers: authHeaders() },
  );
  if (!res.ok) {
    throw new Error(`Recipe template ${name} not found`);
  }
  const data = await res.json();
  return String(data.yaml ?? '');
}

export type RecipeRunResult = import('@/lib/types').RecipeRunResponse;

export async function runRecipe(
  recipe: Record<string, unknown>,
): Promise<RecipeRunResult> {
  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/v1/recipes/run`, {
    method: 'POST',
    headers: authHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(recipe),
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Recipe run failed: ${body}`);
  }
  return res.json();
}

// ---------------------------------------------------------------------------
// Session CRUD
// ---------------------------------------------------------------------------

export async function createSessionInEnv(
  envId: string,
  command: string,
): Promise<WorkbenchSession> {
  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/v1/workbench/environments/${envId}/sessions`, {
    method: 'POST',
    headers: authHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify({ command }),
  });

  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Failed to create session: ${body}`);
  }

  return res.json();
}

export async function deleteSession(sessionId: string): Promise<void> {
  const base = getApiBaseUrl();
  await fetch(`${base}/api/v1/workbench/sessions/${sessionId}`, {
    method: 'DELETE',
    headers: authHeaders(),
  });
}

export async function listSessions(envId?: string): Promise<WorkbenchSession[]> {
  const base = getApiBaseUrl();
  const params = envId ? `?env_id=${envId}` : '';
  const res = await fetch(`${base}/api/v1/workbench/sessions${params}`, {
    headers: authHeaders(),
  });
  if (!res.ok) return [];
  const data = await res.json();
  return data.sessions ?? [];
}

export async function refreshSessionEnv(sessionId: string): Promise<void> {
  const base = getApiBaseUrl();
  await fetch(`${base}/api/v1/workbench/sessions/${sessionId}/refresh-env`, {
    method: 'POST',
    headers: authHeaders({ 'Content-Type': 'application/json' }),
  });
}

// ---------------------------------------------------------------------------
// Service containers
// ---------------------------------------------------------------------------

export interface ServiceInfo {
  service_id: string;
  env_id: string;
  service_type: 'postgres' | 'mongodb';
  status: 'creating' | 'starting' | 'healthy' | 'unhealthy' | 'stopped' | 'error';
  host_url: string;
  container_url: string;
  host_port: number;
  container_name: string;
  container_id: string;
  database: string;
  username: string;
  created_at: number;
  error_message: string;
}

export interface CreateServiceOptions {
  service_type: 'postgres' | 'mongodb';
  database?: string;
  username?: string;
  password?: string;
}

export async function createService(
  envId: string,
  opts: CreateServiceOptions,
): Promise<ServiceInfo> {
  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/v1/workbench/environments/${envId}/services`, {
    method: 'POST',
    headers: authHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(opts),
  });

  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Failed to create service: ${body}`);
  }

  return res.json();
}

export async function listServices(envId: string): Promise<ServiceInfo[]> {
  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/v1/workbench/environments/${envId}/services`, {
    headers: authHeaders(),
  });
  if (!res.ok) return [];
  const data = await res.json();
  return data.services ?? [];
}

export async function getService(serviceId: string): Promise<ServiceInfo | null> {
  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/v1/workbench/services/${serviceId}`, {
    headers: authHeaders(),
  });
  if (!res.ok) return null;
  return res.json();
}

export async function destroyService(serviceId: string): Promise<void> {
  const base = getApiBaseUrl();
  await fetch(`${base}/api/v1/workbench/services/${serviceId}`, {
    method: 'DELETE',
    headers: authHeaders(),
  });
}
