/** Typed API client for PyCatalyst. */

import { getApiBaseUrl } from '@/lib/settings';
import { getAccessToken, clearAccessToken } from '@/lib/auth-storage';
import { AUTH_SESSION_EXPIRED_EVENT } from '@/lib/constants';
import type {
  AuthMeResponse,
  AuthLoginResponse,
  GenerateRequest,
  GenerateResponse,
  StreamSSERequest,
  InferRequest,
  InferResponse,
  MlModelArtifactListResponse,
  MlModelDetail,
  MlModelListResponse,
  MlRunRequest,
  MlRunResponse,
  RecipeListResponse,
  RecipeRunRequest,
  RecipeRunResponse,
  RecipeTemplateYamlResponse,
} from '@/lib/types';

export type ArtifactStoreResponse = {
  type: 'database' | 's3';
  s3_bucket?: string | null;
  s3_prefix?: string | null;
};

export type AwsDataSourceResponse = {
  region?: string | null;
  profile?: string | null;
  s3_endpoint_url?: string | null;
  access_key_id_configured: boolean;
  secret_access_key_configured: boolean;
  session_token_configured: boolean;
  credentials_source: 'explicit' | 'profile' | 'ambient';
};

export type { AuthMeResponse };

export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public response?: Record<string, unknown>,
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

function authHeaders(): Record<string, string> {
  const token = getAccessToken();
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (token) headers['Authorization'] = `Bearer ${token}`;
  return headers;
}

async function handleResponse<T>(response: Response): Promise<T> {
  if (response.status === 401) {
    clearAccessToken();
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent(AUTH_SESSION_EXPIRED_EVENT));
    }
  }
  if (response.status === 204) return undefined as T;
  const text = await response.text();
  let data: T | undefined;
  try {
    data = JSON.parse(text) as T;
  } catch {}
  if (!response.ok) {
    const msg = (data as Record<string, unknown>)?.detail ?? text ?? `HTTP ${response.status}`;
    throw new ApiError(String(msg), response.status, data as Record<string, unknown>);
  }
  return data as T;
}

function wrapNetworkError(err: unknown): never {
  if (err instanceof ApiError) throw err;
  const apiUrl = getApiBaseUrl() || window.location.origin;
  if (err instanceof TypeError && err.message === 'Failed to fetch') {
    throw new ApiError(
      `Unable to connect to API server at ${apiUrl}. Please ensure the API server is running (pycatalyst api).`,
      0,
      { originalError: 'NetworkError', apiUrl, suggestion: 'Check Settings' },
    );
  }
  throw new ApiError(String(err), 0);
}

async function get<T>(endpoint: string): Promise<T> {
  const base = getApiBaseUrl();
  try {
    const res = await fetch(`${base}${endpoint}`, { headers: authHeaders() });
    return handleResponse<T>(res);
  } catch (err) {
    return wrapNetworkError(err);
  }
}

async function post<T>(endpoint: string, body?: unknown): Promise<T> {
  const base = getApiBaseUrl();
  try {
    const res = await fetch(`${base}${endpoint}`, {
      method: 'POST',
      headers: authHeaders(),
      body: body != null ? JSON.stringify(body) : undefined,
    });
    return handleResponse<T>(res);
  } catch (err) {
    return wrapNetworkError(err);
  }
}

/**
 * POST that returns the Response without reading the body (for SSE streams).
 * Throws ApiError on non-OK after consuming the error body as text.
 */
export async function postStream(
  endpoint: string,
  body: unknown,
  signal?: AbortSignal,
): Promise<Response> {
  const base = getApiBaseUrl();
  try {
    const res = await fetch(`${base}${endpoint}`, {
      method: 'POST',
      headers: authHeaders(),
      body: body != null ? JSON.stringify(body) : undefined,
      signal,
    });
    if (res.status === 401) {
      clearAccessToken();
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent(AUTH_SESSION_EXPIRED_EVENT));
      }
    }
    if (!res.ok) {
      const text = await res.text();
      let data: Record<string, unknown> | undefined;
      try {
        data = JSON.parse(text) as Record<string, unknown>;
      } catch {
        /* plain text */
      }
      const detail = data?.detail;
      const msg =
        typeof detail === 'string'
          ? detail
          : detail && typeof detail === 'object' && 'message' in detail
            ? String((detail as { message: unknown }).message)
            : text || `HTTP ${res.status}`;
      throw new ApiError(String(msg), res.status, data);
    }
    return res;
  } catch (err) {
    return wrapNetworkError(err);
  }
}

async function put<T>(endpoint: string, body: unknown): Promise<T> {
  const base = getApiBaseUrl();
  try {
    const res = await fetch(`${base}${endpoint}`, {
      method: 'PUT',
      headers: authHeaders(),
      body: JSON.stringify(body),
    });
    return handleResponse<T>(res);
  } catch (err) {
    return wrapNetworkError(err);
  }
}

async function del(endpoint: string): Promise<void> {
  const base = getApiBaseUrl();
  try {
    const res = await fetch(`${base}${endpoint}`, {
      method: 'DELETE',
      headers: authHeaders(),
    });
    await handleResponse<void>(res);
  } catch (err) {
    return wrapNetworkError(err);
  }
}

async function getBlob(endpoint: string): Promise<Blob> {
  const base = getApiBaseUrl();
  try {
    const res = await fetch(`${base}${endpoint}`, { headers: authHeaders() });
    if (!res.ok) {
      const text = await res.text();
      throw new ApiError(text || `HTTP ${res.status}`, res.status);
    }
    return await res.blob();
  } catch (err) {
    return wrapNetworkError(err);
  }
}

async function fetchWithTimeout<T>(
  endpoint: string,
  timeoutMs: number,
  init?: RequestInit,
): Promise<T> {
  const base = getApiBaseUrl();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(`${base}${endpoint}`, {
      ...init,
      headers: { ...authHeaders(), ...(init?.headers ?? {}) },
      signal: controller.signal,
    });
    return handleResponse<T>(res);
  } catch (err) {
    if (err instanceof DOMException && err.name === 'AbortError') {
      throw new ApiError(`Request timed out after ${timeoutMs}ms`, 0);
    }
    return wrapNetworkError(err);
  } finally {
    clearTimeout(timer);
  }
}

export async function loginWithTimeout(
  username: string,
  password: string,
  timeoutMs: number,
): Promise<AuthLoginResponse> {
  return fetchWithTimeout<AuthLoginResponse>(
    '/api/v1/auth/login',
    timeoutMs,
    {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    },
  );
}

export const api = {
  auth: {
    login: (username: string, password: string) =>
      post<AuthLoginResponse>('/api/v1/auth/login', { username, password }),
    logout: () => post<void>('/api/v1/auth/logout'),
    me: () => get<AuthMeResponse>('/api/v1/auth/me'),
    meWithTimeout: (timeoutMs: number) =>
      fetchWithTimeout<AuthMeResponse>('/api/v1/auth/me', timeoutMs),
  },
  generate: {
    run: (params: GenerateRequest) =>
      post<GenerateResponse>('/api/v1/generate', params),
  },
  stream: {
    openSse: (params: StreamSSERequest, signal?: AbortSignal) =>
      postStream('/api/v1/stream/sse', params, signal),
  },
  infer: {
    run: (params: InferRequest) =>
      post<InferResponse>('/api/v1/infer', params),
  },
  recipes: {
    run: (params: RecipeRunRequest) =>
      post<RecipeRunResponse>('/api/v1/recipes/run', params),
    list: () => get<RecipeListResponse>('/api/v1/recipes/list'),
    getTemplate: (name: string) =>
      get<RecipeTemplateYamlResponse>(
        `/api/v1/recipes/templates/${encodeURIComponent(name)}`,
      ),
  },
  settings: {
    getArtifactStore: () =>
      get<ArtifactStoreResponse>('/api/v1/settings/artifact-store'),
    getAwsDataSource: () =>
      get<AwsDataSourceResponse>('/api/v1/settings/aws-data-source'),
  },
  ml: {
    runExperiment: (params: MlRunRequest) =>
      post<MlRunResponse>('/api/v1/ml/run', params),
    listModels: (params?: {
      backend?: string;
      statusFilter?: string;
      limit?: number;
      offset?: number;
      sortBy?: 'timestamp' | 'name' | 'backend' | 'duration_seconds';
      sortOrder?: 'asc' | 'desc';
    }) => {
      const query = new URLSearchParams();
      if (params?.backend) query.set('backend', params.backend);
      if (params?.statusFilter) query.set('status_filter', params.statusFilter);
      if (typeof params?.limit === 'number') query.set('limit', String(params.limit));
      if (typeof params?.offset === 'number') query.set('offset', String(params.offset));
      if (params?.sortBy) query.set('sort_by', params.sortBy);
      if (params?.sortOrder) query.set('sort_order', params.sortOrder);
      const suffix = query.toString();
      return get<MlModelListResponse>(`/api/v1/ml/models${suffix ? `?${suffix}` : ''}`);
    },
    getModel: (modelId: string) =>
      get<MlModelDetail>(`/api/v1/ml/models/${encodeURIComponent(modelId)}`),
    deleteModel: (modelId: string) =>
      del(`/api/v1/ml/models/${encodeURIComponent(modelId)}`),
    listArtifacts: (modelId: string) =>
      get<MlModelArtifactListResponse>(`/api/v1/ml/models/${encodeURIComponent(modelId)}/artifacts`),
    downloadArtifact: (modelId: string, artifactName: string) =>
      getBlob(`/api/v1/ml/models/${encodeURIComponent(modelId)}/artifacts/${encodeURIComponent(artifactName)}`),
    deleteArtifact: (modelId: string, artifactName: string) =>
      del(`/api/v1/ml/models/${encodeURIComponent(modelId)}/artifacts/${encodeURIComponent(artifactName)}`),
  },
};
