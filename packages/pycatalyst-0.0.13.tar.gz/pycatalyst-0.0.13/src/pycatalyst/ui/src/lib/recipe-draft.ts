import type { GenerateField } from '@/lib/types';
import type { RecipeSinkValue } from '@/components/recipes/RecipeSinkFields';
import type { FieldRow } from '@/components/generate/generate-utils';

let rowIdSeq = 1;

/** Normalized recipe for structured editor + YAML sync. */
export type RecipeDraft = {
  name: string;
  description: string;
  version: string;
  /** Full schema fields (may include `children` from YAML). */
  fields: GenerateField[];
  generation: { count: number; seed?: number };
  sink: RecipeSinkValue;
};

export const defaultRecipeSink = (): RecipeSinkValue => ({
  type: 'memory',
  config: {},
});

export function emptyRecipeDraft(): RecipeDraft {
  return {
    name: 'recipe',
    description: '',
    version: '1.0',
    fields: [],
    generation: { count: 10 },
    sink: defaultRecipeSink(),
  };
}

export function parseSinkFromYaml(raw: unknown): RecipeSinkValue {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    return defaultRecipeSink();
  }
  const o = raw as Record<string, unknown>;
  const type = typeof o.type === 'string' ? o.type : 'memory';
  const config =
    o.config && typeof o.config === 'object' && !Array.isArray(o.config)
      ? (o.config as Record<string, unknown>)
      : {};
  return { type, config };
}

export function hasNestedSchemaFields(fields: GenerateField[]): boolean {
  return fields.some((f) => f.children && f.children.length > 0);
}

/** Fields editable as flat rows (no nested children). */
export function flatSchemaFields(fields: GenerateField[]): GenerateField[] {
  return fields.filter((f) => !f.children?.length);
}

export function nestedSchemaFields(fields: GenerateField[]): GenerateField[] {
  return fields.filter((f) => f.children?.length);
}

export function generateFieldToRow(f: GenerateField, id: number): FieldRow {
  const c = f.constraints ?? {};
  let constraintMin = '';
  let constraintMax = '';
  let constraintChoices = '';
  let constraintPattern = '';

  if (f.type === 'int' || f.type === 'float') {
    if (typeof c.min === 'number') constraintMin = String(c.min);
    if (typeof c.max === 'number') constraintMax = String(c.max);
  }
  if (f.type === 'enum' && Array.isArray(c.choices)) {
    constraintChoices = c.choices.map(String).join(', ');
  }
  if (f.type === 'string') {
    if (typeof c.pattern === 'string') constraintPattern = c.pattern;
    if (typeof c.min === 'number') constraintMin = String(c.min);
    if (typeof c.max === 'number') constraintMax = String(c.max);
  }

  return {
    id,
    name: f.name,
    type: f.type,
    nullable: f.nullable ?? false,
    constraintMin,
    constraintMax,
    constraintChoices,
    constraintPattern,
  };
}

export function generateFieldsToFieldRows(fields: GenerateField[]): FieldRow[] {
  return fields.map((f) => generateFieldToRow(f, rowIdSeq++));
}

export type ParseRecipeResult =
  | { ok: true; draft: RecipeDraft }
  | { ok: false; error: string };

/** Parse loaded YAML object (already `load`ed). */
export function recipeObjectToDraft(obj: Record<string, unknown>): ParseRecipeResult {
  const name = typeof obj.name === 'string' && obj.name.trim() ? obj.name.trim() : 'recipe';
  const description =
    typeof obj.description === 'string' ? obj.description : '';
  const version = typeof obj.version === 'string' ? obj.version : '1.0';

  const schema = obj.schema;
  if (!schema || typeof schema !== 'object' || Array.isArray(schema)) {
    return { ok: false, error: 'Recipe must have a schema object' };
  }
  const fieldsRaw = (schema as { fields?: unknown }).fields;
  if (!Array.isArray(fieldsRaw)) {
    return { ok: false, error: 'schema.fields must be an array' };
  }

  const fields: GenerateField[] = [];
  for (let i = 0; i < fieldsRaw.length; i++) {
    const item = fieldsRaw[i];
    if (!item || typeof item !== 'object' || Array.isArray(item)) {
      return { ok: false, error: `schema.fields[${i}] must be an object` };
    }
    const row = item as Record<string, unknown>;
    const fname = typeof row.name === 'string' ? row.name : '';
    const ftype = typeof row.type === 'string' ? row.type : '';
    if (!fname || !ftype) {
      return {
        ok: false,
        error: `schema.fields[${i}] needs name and type`,
      };
    }
    const gf: GenerateField = {
      name: fname,
      type: ftype,
      nullable: row.nullable === true,
    };
    if (row.constraints && typeof row.constraints === 'object' && !Array.isArray(row.constraints)) {
      gf.constraints = row.constraints as Record<string, unknown>;
    }
    if (Array.isArray(row.children)) {
      gf.children = row.children as GenerateField[];
    }
    fields.push(gf);
  }

  let generation = { count: 10 as number, seed: undefined as number | undefined };
  const gen = obj.generation;
  if (gen && typeof gen === 'object' && !Array.isArray(gen)) {
    const g = gen as Record<string, unknown>;
    if (typeof g.count === 'number' && g.count >= 1) {
      generation = { ...generation, count: g.count };
    }
    if (typeof g.seed === 'number') {
      generation = { ...generation, seed: g.seed };
    }
  }

  const sink = parseSinkFromYaml(obj.sink);

  return {
    ok: true,
    draft: {
      name,
      description,
      version,
      fields,
      generation,
      sink,
    },
  };
}

/** Build YAML-serializable object from draft. */
export function draftToSerializable(draft: RecipeDraft): Record<string, unknown> {
  return {
    name: draft.name,
    description: draft.description || undefined,
    version: draft.version || undefined,
    schema: {
      fields: draft.fields.map((f) => {
        const o: Record<string, unknown> = {
          name: f.name,
          type: f.type,
          nullable: f.nullable,
        };
        if (f.constraints && Object.keys(f.constraints).length > 0) {
          o.constraints = f.constraints;
        }
        if (f.children?.length) {
          o.children = f.children;
        }
        return o;
      }),
    },
    generation: {
      count: draft.generation.count,
      ...(draft.generation.seed !== undefined
        ? { seed: draft.generation.seed }
        : {}),
    },
    sink: {
      type: draft.sink.type,
      config: draft.sink.config,
    },
  };
}
