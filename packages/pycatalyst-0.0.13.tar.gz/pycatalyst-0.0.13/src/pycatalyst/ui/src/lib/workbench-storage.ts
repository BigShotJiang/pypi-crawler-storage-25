/** Persist / retrieve workbench layout state in localStorage. */

const STORAGE_KEY = 'pycatalyst_workbench_layout';

export interface WorkbenchLayoutState {
  splitDirection: 'horizontal' | 'vertical';
  splitRatio: number;
  activeEnvId: string | null;
  activePanelSessionId: string | null;
  panelSessionIds: string[];
}

const DEFAULTS: WorkbenchLayoutState = {
  splitDirection: 'horizontal',
  splitRatio: 50,
  activeEnvId: null,
  activePanelSessionId: null,
  panelSessionIds: [],
};

export function loadWorkbenchLayout(): WorkbenchLayoutState {
  if (typeof window === 'undefined') return { ...DEFAULTS };
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { ...DEFAULTS };
    const parsed: unknown = JSON.parse(raw);
    if (typeof parsed !== 'object' || parsed === null) return { ...DEFAULTS };

    const obj = parsed as Record<string, unknown>;

    const splitDirection =
      obj.splitDirection === 'horizontal' || obj.splitDirection === 'vertical'
        ? obj.splitDirection
        : DEFAULTS.splitDirection;

    const splitRatio =
      typeof obj.splitRatio === 'number' &&
      obj.splitRatio >= 15 &&
      obj.splitRatio <= 85
        ? obj.splitRatio
        : DEFAULTS.splitRatio;

    const activeEnvId =
      typeof obj.activeEnvId === 'string' ? obj.activeEnvId : null;

    const activePanelSessionId =
      typeof obj.activePanelSessionId === 'string'
        ? obj.activePanelSessionId
        : null;

    const panelSessionIds = Array.isArray(obj.panelSessionIds)
      ? (obj.panelSessionIds.filter(
          (id): id is string => typeof id === 'string',
        ) as string[])
      : [];

    return {
      splitDirection,
      splitRatio,
      activeEnvId,
      activePanelSessionId,
      panelSessionIds,
    };
  } catch {
    return { ...DEFAULTS };
  }
}

export function saveWorkbenchLayout(state: WorkbenchLayoutState): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {}
}
