/** Form state <-> YAML string conversion. */

import yaml from 'js-yaml';
import type {
  FormState,
  Backend,
  SklearnFormState,
  PytorchFormState,
  HuggingfaceFormState,
} from '@/components/model-training/types';
import {
  DEFAULT_EXPERIMENT,
  DEFAULT_SKLEARN_DATA,
  DEFAULT_SKLEARN_MODEL,
  DEFAULT_SKLEARN_TRAINING,
  DEFAULT_SKLEARN_EVALUATION,
  DEFAULT_PYTORCH_DATA,
  DEFAULT_PYTORCH_MODEL,
  DEFAULT_PYTORCH_TRAINING,
  DEFAULT_PYTORCH_EVALUATION,
  DEFAULT_HF_DATA,
  DEFAULT_HF_MODEL,
  DEFAULT_HF_TRAINING,
  DEFAULT_HF_EVALUATION,
} from '@/components/model-training/constants';

function parseCommaSeparated(s: string): string[] {
  return s.split(',').map((v) => v.trim()).filter(Boolean);
}

function parseNumberList(s: string): number[] {
  return s.split(',').map((v) => Number(v.trim())).filter((n) => !isNaN(n));
}

function cleanParams(params: Record<string, number | string>): Record<string, unknown> {
  const result: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(params)) {
    if (key === 'hidden_sizes' && typeof value === 'string') {
      result[key] = parseNumberList(value);
    } else {
      result[key] = value;
    }
  }
  return result;
}

const SKLEARN_ARCH_TO_YAML: Record<string, string> = {
  linear_regression: 'LinearRegression',
  ridge: 'Ridge',
  lasso: 'Lasso',
  decision_tree: 'DecisionTreeRegressor',
  random_forest: 'RandomForestRegressor',
  gradient_boosting: 'GradientBoostingRegressor',
  adaboost: 'AdaBoostRegressor',
  svm: 'SVR',
  knn: 'KNeighborsRegressor',
  hist_gradient_boosting: 'HistGradientBoostingRegressor',
};

const YAML_TO_SKLEARN_ARCH = Object.fromEntries(Object.entries(SKLEARN_ARCH_TO_YAML).map(([k, v]) => [v.toLowerCase(), k]));

const PYTORCH_ARCH_TO_YAML: Record<string, string> = {
  lstm: 'LSTMRegressor',
  gru: 'GRURegressor',
  tcn: 'TCNRegressor',
  transformer: 'TransformerRegressor',
  mlp: 'MLPRegressor',
};

const YAML_TO_PYTORCH_ARCH = Object.fromEntries(Object.entries(PYTORCH_ARCH_TO_YAML).map(([k, v]) => [v.toLowerCase(), k]));

function buildSklearnYaml(state: SklearnFormState): Record<string, unknown> {
  const { experiment: exp, data, model, training, evaluation } = state;
  const features = parseCommaSeparated(data.features);
  const dataPath = data.source === 's3' ? data.s3Uri : data.path;

  const yamlObj: Record<string, unknown> = {
    experiment: {
      name: exp.name,
      backend: 'sklearn',
      seed: exp.seed,
      output_dir: exp.outputDir,
    },
    data: {
      source: data.source,
      path: dataPath,
      target: data.target,
      ...(features.length > 0 ? { features } : {}),
      split: {
        strategy: data.splitStrategy,
        train: data.trainRatio,
        val: data.valRatio,
        test: data.testRatio,
      },
      scaler: data.scaler,
      handle_missing: data.handleMissing,
    },
    model: {
      architecture: SKLEARN_ARCH_TO_YAML[model.architecture] ?? model.architecture,
      params: cleanParams(model.params),
    },
    training: {
      cross_validation: {
        enabled: training.crossValidationEnabled,
        folds: training.folds,
        scoring: training.scoring,
      },
    },
    evaluation: {
      metrics: evaluation.metrics,
      plots: evaluation.plots,
    },
  };

  return yamlObj;
}

function buildPytorchYaml(state: PytorchFormState): Record<string, unknown> {
  const { experiment: exp, data, model, training, evaluation } = state;
  const features = parseCommaSeparated(data.features);
  const dataPath = data.source === 's3' ? data.s3Uri : data.path;

  const trainingObj: Record<string, unknown> = {
    epochs: training.epochs,
    batch_size: training.batchSize,
    learning_rate: training.learningRate,
    optimizer: training.optimizer,
    gradient_clip: training.gradientClip,
  };

  if (training.scheduler && training.scheduler !== 'none') {
    trainingObj.scheduler = training.scheduler;
  }

  if (training.earlyStoppingEnabled) {
    trainingObj.early_stopping = {
      patience: training.earlyStoppingPatience,
      metric: training.earlyStoppingMetric,
      mode: training.earlyStoppingMode,
    };
  }

  if (training.checkpointEnabled) {
    trainingObj.checkpoint = {
      metric: 'val_loss',
      save_best_only: true,
    };
  }

  return {
    experiment: {
      name: exp.name,
      backend: 'pytorch',
      seed: exp.seed,
      output_dir: exp.outputDir,
    },
    data: {
      source: data.source,
      path: dataPath,
      target: data.target,
      ...(features.length > 0 ? { features } : {}),
      split: {
        strategy: data.splitStrategy,
        train: data.trainRatio,
        val: data.valRatio,
        test: data.testRatio,
      },
      scaler: data.scaler,
      sequence_length: data.sequenceLength,
      stride: data.stride,
    },
    model: {
      architecture: PYTORCH_ARCH_TO_YAML[model.architecture] ?? model.architecture,
      params: cleanParams(model.params),
    },
    training: trainingObj,
    evaluation: {
      metrics: evaluation.metrics,
      plots: evaluation.plots,
    },
  };
}

function buildHuggingfaceYaml(state: HuggingfaceFormState): Record<string, unknown> {
  const { experiment: exp, data, model, training, evaluation } = state;
  const dataPath = data.source === 's3' ? data.s3Uri : data.path;

  const modelObj: Record<string, unknown> = {
    base_model: model.baseModel,
    adapter: model.adapter,
  };

  if (model.quantization !== 'none') {
    modelObj.quantization = model.quantization;
  }

  if (model.adapter !== 'none') {
    modelObj.params = {
      r: model.loraR,
      lora_alpha: model.loraAlpha,
      lora_dropout: model.loraDropout,
      target_modules: parseCommaSeparated(model.targetModules),
    };
  }

  return {
    experiment: {
      name: exp.name,
      backend: 'huggingface',
      seed: exp.seed,
      output_dir: exp.outputDir,
    },
    data: {
      source: data.source,
      path: dataPath,
      format: data.format,
      max_length: data.maxLength,
      val_split: data.valSplit,
    },
    model: modelObj,
    training: {
      epochs: training.epochs,
      batch_size: training.batchSize,
      gradient_accumulation_steps: training.gradientAccumulationSteps,
      learning_rate: training.learningRate,
      warmup_ratio: training.warmupRatio,
      mixed_precision: training.mixedPrecision,
      max_grad_norm: training.maxGradNorm,
    },
    evaluation: {
      metrics: evaluation.metrics,
    },
  };
}

export function formStateToYaml(state: FormState): string {
  const builders = { sklearn: buildSklearnYaml, pytorch: buildPytorchYaml, huggingface: buildHuggingfaceYaml } as const;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const obj = (builders[state.backend] as (s: any) => Record<string, unknown>)(state);
  return yaml.dump(obj, { lineWidth: -1, noRefs: true, quotingType: "'", forceQuotes: false });
}

const safeStr = (v: unknown, fb: string): string => typeof v === 'string' ? v : fb;
const safeNum = (v: unknown, fb: number): number => typeof v === 'number' ? v : fb;
const safeArr = (v: unknown, fb: string[]): string[] => Array.isArray(v) ? v.map(String) : fb;
const safeBool = (v: unknown, fb: boolean): boolean => typeof v === 'boolean' ? v : fb;

export function parseYamlToFormState(yamlStr: string): FormState | null {
  try {
    const raw = yaml.load(yamlStr) as Record<string, Record<string, unknown>> | null;
    if (!raw || typeof raw !== 'object') return null;

    const exp = (raw.experiment ?? {}) as Record<string, unknown>;
    const backendStr = safeStr(exp.backend, '');
    const experiment = {
      name: safeStr(exp.name, DEFAULT_EXPERIMENT.name),
      seed: safeNum(exp.seed, DEFAULT_EXPERIMENT.seed),
      outputDir: safeStr(exp.output_dir, DEFAULT_EXPERIMENT.outputDir),
    };
    const dataRaw = (raw.data ?? {}) as Record<string, unknown>;
    const modelRaw = (raw.model ?? {}) as Record<string, unknown>;
    const trainingRaw = (raw.training ?? {}) as Record<string, unknown>;
    const evalRaw = (raw.evaluation ?? {}) as Record<string, unknown>;
    const splitRaw = (dataRaw.split ?? {}) as Record<string, unknown>;
    const paramsRaw = (modelRaw.params ?? {}) as Record<string, unknown>;

    const dataPath = safeStr(dataRaw.path, '');
    const inferredSource = dataPath.startsWith('s3://') ? 's3' : 'local';
    const source = safeStr(dataRaw.source, inferredSource) === 's3' ? 's3' : 'local';

    if (backendStr === 'sklearn') {
      const archStr = safeStr(modelRaw.architecture, '').toLowerCase();
      const resolvedArch = YAML_TO_SKLEARN_ARCH[archStr] ?? DEFAULT_SKLEARN_MODEL.architecture;
      const cvRaw = (trainingRaw.cross_validation ?? {}) as Record<string, unknown>;
      const state: SklearnFormState = {
        backend: 'sklearn',
        experiment,
        data: {
          source,
          path: source === 'local' ? (dataPath || DEFAULT_SKLEARN_DATA.path) : DEFAULT_SKLEARN_DATA.path,
          s3Uri: source === 's3' ? dataPath : '',
          target: safeStr(dataRaw.target, DEFAULT_SKLEARN_DATA.target),
          features: safeArr(dataRaw.features, []).join(', '),
          splitStrategy: safeStr(splitRaw.strategy, DEFAULT_SKLEARN_DATA.splitStrategy) as SklearnFormState['data']['splitStrategy'],
          trainRatio: safeNum(splitRaw.train, DEFAULT_SKLEARN_DATA.trainRatio),
          valRatio: safeNum(splitRaw.val, DEFAULT_SKLEARN_DATA.valRatio),
          testRatio: safeNum(splitRaw.test, DEFAULT_SKLEARN_DATA.testRatio),
          scaler: safeStr(dataRaw.scaler, DEFAULT_SKLEARN_DATA.scaler) as SklearnFormState['data']['scaler'],
          handleMissing: safeStr(dataRaw.handle_missing, DEFAULT_SKLEARN_DATA.handleMissing) as SklearnFormState['data']['handleMissing'],
        },
        model: {
          architecture: resolvedArch as SklearnFormState['model']['architecture'],
          params: Object.fromEntries(Object.entries(paramsRaw).map(([k, v]) => [k, typeof v === 'number' ? v : String(v)])),
        },
        training: {
          crossValidationEnabled: safeBool(cvRaw.enabled, DEFAULT_SKLEARN_TRAINING.crossValidationEnabled),
          folds: safeNum(cvRaw.folds, DEFAULT_SKLEARN_TRAINING.folds),
          scoring: safeStr(cvRaw.scoring, DEFAULT_SKLEARN_TRAINING.scoring),
        },
        evaluation: {
          metrics: safeArr(evalRaw.metrics, DEFAULT_SKLEARN_EVALUATION.metrics),
          plots: safeArr(evalRaw.plots, DEFAULT_SKLEARN_EVALUATION.plots),
        },
      };
      return state;
    }

    if (backendStr === 'pytorch') {
      const archStr = safeStr(modelRaw.architecture, '').toLowerCase();
      const resolvedArch = YAML_TO_PYTORCH_ARCH[archStr] ?? DEFAULT_PYTORCH_MODEL.architecture;
      const esRaw = (trainingRaw.early_stopping ?? {}) as Record<string, unknown>;
      const hasEarlyStopping = Object.keys(esRaw).length > 0;
      const formParams: Record<string, number | string> = {};
      for (const [k, v] of Object.entries(paramsRaw)) {
        if (k === 'hidden_sizes' && Array.isArray(v)) {
          formParams[k] = v.join(', ');
        } else {
          formParams[k] = typeof v === 'number' ? v : String(v);
        }
      }
      const state: PytorchFormState = {
        backend: 'pytorch',
        experiment,
        data: {
          source,
          path: source === 'local' ? (dataPath || DEFAULT_PYTORCH_DATA.path) : DEFAULT_PYTORCH_DATA.path,
          s3Uri: source === 's3' ? dataPath : '',
          target: safeStr(dataRaw.target, DEFAULT_PYTORCH_DATA.target),
          features: safeArr(dataRaw.features, []).join(', '),
          splitStrategy: safeStr(splitRaw.strategy, DEFAULT_PYTORCH_DATA.splitStrategy) as PytorchFormState['data']['splitStrategy'],
          trainRatio: safeNum(splitRaw.train, DEFAULT_PYTORCH_DATA.trainRatio),
          valRatio: safeNum(splitRaw.val, DEFAULT_PYTORCH_DATA.valRatio),
          testRatio: safeNum(splitRaw.test, DEFAULT_PYTORCH_DATA.testRatio),
          scaler: safeStr(dataRaw.scaler, DEFAULT_PYTORCH_DATA.scaler) as PytorchFormState['data']['scaler'],
          sequenceLength: safeNum(dataRaw.sequence_length, DEFAULT_PYTORCH_DATA.sequenceLength),
          stride: safeNum(dataRaw.stride, DEFAULT_PYTORCH_DATA.stride),
        },
        model: {
          architecture: resolvedArch as PytorchFormState['model']['architecture'],
          params: formParams,
        },
        training: {
          epochs: safeNum(trainingRaw.epochs, DEFAULT_PYTORCH_TRAINING.epochs),
          batchSize: safeNum(trainingRaw.batch_size, DEFAULT_PYTORCH_TRAINING.batchSize),
          learningRate: safeNum(trainingRaw.learning_rate, DEFAULT_PYTORCH_TRAINING.learningRate),
          optimizer: safeStr(trainingRaw.optimizer, DEFAULT_PYTORCH_TRAINING.optimizer) as PytorchFormState['training']['optimizer'],
          scheduler: safeStr(trainingRaw.scheduler, DEFAULT_PYTORCH_TRAINING.scheduler) as PytorchFormState['training']['scheduler'],
          gradientClip: safeNum(trainingRaw.gradient_clip, DEFAULT_PYTORCH_TRAINING.gradientClip),
          earlyStoppingEnabled: hasEarlyStopping,
          earlyStoppingPatience: safeNum(esRaw.patience, DEFAULT_PYTORCH_TRAINING.earlyStoppingPatience),
          earlyStoppingMetric: safeStr(esRaw.metric, DEFAULT_PYTORCH_TRAINING.earlyStoppingMetric),
          earlyStoppingMode: safeStr(esRaw.mode, DEFAULT_PYTORCH_TRAINING.earlyStoppingMode) as PytorchFormState['training']['earlyStoppingMode'],
          checkpointEnabled: trainingRaw.checkpoint !== undefined,
        },
        evaluation: {
          metrics: safeArr(evalRaw.metrics, DEFAULT_PYTORCH_EVALUATION.metrics),
          plots: safeArr(evalRaw.plots, DEFAULT_PYTORCH_EVALUATION.plots),
        },
      };
      return state;
    }
    if (backendStr === 'huggingface') {
      const state: HuggingfaceFormState = {
        backend: 'huggingface',
        experiment,
        data: {
          source,
          path: source === 'local' ? (dataPath || DEFAULT_HF_DATA.path) : DEFAULT_HF_DATA.path,
          s3Uri: source === 's3' ? dataPath : '',
          format: safeStr(dataRaw.format, DEFAULT_HF_DATA.format) as HuggingfaceFormState['data']['format'],
          maxLength: safeNum(dataRaw.max_length, DEFAULT_HF_DATA.maxLength),
          valSplit: safeNum(dataRaw.val_split, DEFAULT_HF_DATA.valSplit),
        },
        model: {
          baseModel: safeStr(modelRaw.base_model, DEFAULT_HF_MODEL.baseModel),
          adapter: safeStr(modelRaw.adapter, DEFAULT_HF_MODEL.adapter) as HuggingfaceFormState['model']['adapter'],
          quantization: safeStr(modelRaw.quantization, DEFAULT_HF_MODEL.quantization) as HuggingfaceFormState['model']['quantization'],
          loraR: safeNum(paramsRaw.r, DEFAULT_HF_MODEL.loraR),
          loraAlpha: safeNum(paramsRaw.lora_alpha, DEFAULT_HF_MODEL.loraAlpha),
          loraDropout: safeNum(paramsRaw.lora_dropout, DEFAULT_HF_MODEL.loraDropout),
          targetModules: safeArr(paramsRaw.target_modules, parseCommaSeparated(DEFAULT_HF_MODEL.targetModules)).join(', '),
        },
        training: {
          epochs: safeNum(trainingRaw.epochs, DEFAULT_HF_TRAINING.epochs),
          batchSize: safeNum(trainingRaw.batch_size, DEFAULT_HF_TRAINING.batchSize),
          gradientAccumulationSteps: safeNum(trainingRaw.gradient_accumulation_steps, DEFAULT_HF_TRAINING.gradientAccumulationSteps),
          learningRate: safeNum(trainingRaw.learning_rate, DEFAULT_HF_TRAINING.learningRate),
          warmupRatio: safeNum(trainingRaw.warmup_ratio, DEFAULT_HF_TRAINING.warmupRatio),
          mixedPrecision: safeStr(trainingRaw.mixed_precision, DEFAULT_HF_TRAINING.mixedPrecision) as HuggingfaceFormState['training']['mixedPrecision'],
          maxGradNorm: safeNum(trainingRaw.max_grad_norm, DEFAULT_HF_TRAINING.maxGradNorm),
        },
        evaluation: {
          metrics: safeArr(evalRaw.metrics, DEFAULT_HF_EVALUATION.metrics),
        },
      };
      return state;
    }

    return null;
  } catch {
    return null;
  }
}

/** Detect backend from raw YAML string without full parsing. */
export function detectBackend(yamlStr: string): Backend | null {
  try {
    const raw = yaml.load(yamlStr) as Record<string, Record<string, unknown>> | null;
    if (!raw?.experiment) return null;
    const b = (raw.experiment as Record<string, unknown>).backend;
    if (b === 'sklearn' || b === 'pytorch' || b === 'huggingface') return b;
    return null;
  } catch {
    return null;
  }
}
