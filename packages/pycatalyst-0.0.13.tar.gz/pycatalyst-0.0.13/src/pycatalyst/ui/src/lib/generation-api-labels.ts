/**
 * Must match pycatalyst.api.generation_metadata.PYTHON_API_GENERATION_ENGINE_ITER_RECORDS
 * (stream endpoint has no JSON envelope with this field).
 */
export const PYTHON_API_STREAM_ITER_RECORDS =
  'pycatalyst.generators.engine.GenerationEngine.iter_records';
