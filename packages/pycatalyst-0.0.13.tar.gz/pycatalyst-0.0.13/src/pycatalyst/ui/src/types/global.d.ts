/** Global type declarations for PyCatalyst UI. */

interface AppConfig {
  theme?: string;
  appName?: string;
  version?: string;
  recipeSinkMode?: 'memory' | 'full';
}

interface Window {
  __APP_CONFIG__?: AppConfig;
}
