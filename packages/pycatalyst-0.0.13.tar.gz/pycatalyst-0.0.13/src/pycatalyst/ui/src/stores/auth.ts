import { create } from 'zustand';
import { devtools } from 'zustand/middleware';
import { api, ApiError, loginWithTimeout } from '@/lib/api';
import type { AuthMeResponse } from '@/lib/api';
import { clearAccessToken, setAccessToken } from '@/lib/auth-storage';
import { AUTH_CHECK_TIMEOUT_MS, LOGIN_REQUEST_TIMEOUT_MS, ROUTES } from '@/lib/constants';

function isConnectionError(err: unknown): boolean {
  if (!(err instanceof ApiError)) return false;
  return err.status === 0 || err.message.includes('Unable to connect') || err.message.includes('timed out');
}

export interface AuthState {
  user: AuthMeResponse | null;
  loading: boolean;
  apiUnavailable: boolean;
  checkAuth: () => Promise<void>;
  login: (username: string, password: string) => Promise<string>;
  logout: () => void;
  clearUser: () => void;
}

export const useAuthStore = create<AuthState>()(
  devtools(
    (set) => ({
      user: null,
      loading: true,
      apiUnavailable: false,

      checkAuth: async () => {
        try {
          const me = await api.auth.meWithTimeout(AUTH_CHECK_TIMEOUT_MS);
          set({ user: me, apiUnavailable: false });
        } catch (err) {
          if (err instanceof ApiError && err.status === 401) {
            set({ user: null, apiUnavailable: false });
          } else if (isConnectionError(err)) {
            set({ user: null, apiUnavailable: true });
          } else {
            set({ user: null, apiUnavailable: false });
          }
        } finally {
          set({ loading: false });
        }
      },

      login: async (username, password) => {
        const res = await loginWithTimeout(username, password, LOGIN_REQUEST_TIMEOUT_MS);
        setAccessToken(res.access_token);
        set({ user: { username, auth_disabled: false }, apiUnavailable: false });
        return res.access_token;
      },

      logout: () => {
        clearAccessToken();
        api.auth.logout().catch(() => {});
        set({ user: null });
      },

      clearUser: () => {
        clearAccessToken();
        set({ user: null });
      },
    }),
    { name: 'auth' },
  ),
);

// Selectors
export const selectUser = (s: AuthState) => s.user;
export const selectLoading = (s: AuthState) => s.loading;
export const selectIsAuthenticated = (s: AuthState) => !!s.user;
export const selectAuthDisabled = (s: AuthState) => s.user?.auth_disabled ?? false;
export const selectApiUnavailable = (s: AuthState) => s.apiUnavailable;
export const selectLogout = (s: AuthState) => s.logout;
export const selectCheckAuth = (s: AuthState) => s.checkAuth;
