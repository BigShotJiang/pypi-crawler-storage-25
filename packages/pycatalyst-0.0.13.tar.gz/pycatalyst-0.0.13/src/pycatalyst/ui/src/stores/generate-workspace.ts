/**
 * Zustand store for the Generate IDE workspace.
 *
 * Replaces all useState hooks in the Generate page with a single
 * shared store accessible by the sidebar, toolbar, inspector,
 * schema table, and output panel.
 */

import { create } from 'zustand';
import { devtools } from 'zustand/middleware';

import type { GenerateField, InferField } from '@/lib/types';
import type { RecipeDraft } from '@/lib/recipe-draft';
import { emptyRecipeDraft } from '@/lib/recipe-draft';

// ── Types ────────────────────────────────────────────────

export type DeliveryMode = 'batch' | 'stream';
export type SchemaSource = 'build' | 'infer' | 'json-schema' | 'recipe';
export type OutputTab = 'data' | 'stream' | 'logs' | 'stats';
export type SidebarTab = 'schema' | 'templates' | 'sinks';

export interface SinkConfig {
  id: string;
  type: string;
  config: Record<string, unknown>;
  label?: string;
  status: 'idle' | 'testing' | 'connected' | 'error';
  error?: string;
}

export interface GenerationConfig {
  deliveryMode: DeliveryMode;
  count: number;
  maxRecords: number;
  intervalMs: number;
  seed: string;
}

export interface LogEntry {
  timestamp: number;
  level: 'info' | 'warn' | 'error';
  message: string;
}

export interface BatchResultMeta {
  count: number;
  duration: number;
  sinkType?: string;
  errors?: string[];
  usedRecipeEndpoint?: boolean;
  pythonApi?: string;
}

export interface OutputState {
  activeTab: OutputTab;
  format: 'json' | 'csv';
  batchResults: Record<string, unknown>[] | null;
  batchMeta: BatchResultMeta | null;
  streamRecords: Record<string, unknown>[];
  streamTotalReceived: number;
  logs: LogEntry[];
}

// ── Store Interface ──────────────────────────────────────

export interface GenerateWorkspaceState {
  // Sidebar
  sidebarTab: SidebarTab;
  setSidebarTab: (tab: SidebarTab) => void;

  // Schema source mode
  schemaSource: SchemaSource;
  setSchemaSource: (source: SchemaSource) => void;

  // Schema fields — canonical resolved schema
  schemaName: string;
  setSchemaName: (name: string) => void;
  fields: GenerateField[];
  setFields: (fields: GenerateField[]) => void;
  addField: (field: GenerateField) => void;
  updateField: (index: number, field: GenerateField) => void;
  removeField: (index: number) => void;
  reorderFields: (fromIndex: number, toIndex: number) => void;

  // Field selection — drives inspector
  selectedFieldIndex: number | null;
  setSelectedFieldIndex: (index: number | null) => void;

  // Infer-specific state
  inferredFields: InferField[] | null;
  setInferredFields: (fields: InferField[] | null) => void;

  // JSON Schema-specific state
  jsonSchemaFields: GenerateField[] | null;
  setJsonSchemaFields: (fields: GenerateField[] | null) => void;

  // Recipe-specific state
  recipeDraft: RecipeDraft;
  setRecipeDraft: (draft: RecipeDraft) => void;
  recipeYaml: string;
  setRecipeYaml: (yaml: string) => void;

  // Generation config
  generation: GenerationConfig;
  setGeneration: (patch: Partial<GenerationConfig>) => void;

  // Sinks
  sinks: SinkConfig[];
  addSink: (type: string) => void;
  updateSink: (id: string, patch: Partial<SinkConfig>) => void;
  removeSink: (id: string) => void;

  // Execution
  busy: boolean;
  streaming: boolean;
  error: string | null;
  setBusy: (busy: boolean) => void;
  setStreaming: (streaming: boolean) => void;
  setError: (error: string | null) => void;

  // Output
  output: OutputState;
  setOutputTab: (tab: OutputTab) => void;
  setOutputFormat: (format: 'json' | 'csv') => void;
  setBatchResults: (
    records: Record<string, unknown>[],
    meta: BatchResultMeta,
  ) => void;
  addStreamRecord: (record: Record<string, unknown>) => void;
  clearStream: () => void;
  clearOutput: () => void;
  addLog: (level: LogEntry['level'], message: string) => void;

  // Bottom panel
  bottomPanelOpen: boolean;
  setBottomPanelOpen: (open: boolean) => void;
}

// ── Helpers ──────────────────────────────────────────────

let nextSinkId = 1;
function genSinkId(): string {
  return `sink-${nextSinkId++}`;
}

const STREAM_DISPLAY_CAP = 1000;

// ── Store ────────────────────────────────────────────────

export const useGenerateWorkspaceStore = create<GenerateWorkspaceState>()(
  devtools(
    (set) => ({
      // Sidebar
      sidebarTab: 'schema',
      setSidebarTab: (tab) => set({ sidebarTab: tab }),

      // Schema source
      schemaSource: 'build',
      setSchemaSource: (source) => set({ schemaSource: source }),

      // Schema fields
      schemaName: 'my_schema',
      setSchemaName: (name) => set({ schemaName: name }),
      fields: [],
      setFields: (fields) => set({ fields }),
      addField: (field) =>
        set((state) => ({ fields: [...state.fields, field] })),
      updateField: (index, field) =>
        set((state) => {
          const next = [...state.fields];
          next[index] = field;
          return { fields: next };
        }),
      removeField: (index) =>
        set((state) => ({
          fields: state.fields.filter((_, i) => i !== index),
          selectedFieldIndex:
            state.selectedFieldIndex === index
              ? null
              : state.selectedFieldIndex !== null &&
                  state.selectedFieldIndex > index
                ? state.selectedFieldIndex - 1
                : state.selectedFieldIndex,
        })),
      reorderFields: (fromIndex, toIndex) =>
        set((state) => {
          const next = [...state.fields];
          const [moved] = next.splice(fromIndex, 1);
          next.splice(toIndex, 0, moved);
          return { fields: next };
        }),

      // Field selection
      selectedFieldIndex: null,
      setSelectedFieldIndex: (index) => set({ selectedFieldIndex: index }),

      // Infer
      inferredFields: null,
      setInferredFields: (fields) => set({ inferredFields: fields }),

      // JSON Schema
      jsonSchemaFields: null,
      setJsonSchemaFields: (fields) => set({ jsonSchemaFields: fields }),

      // Recipe
      recipeDraft: emptyRecipeDraft(),
      setRecipeDraft: (draft) => set({ recipeDraft: draft }),
      recipeYaml: '',
      setRecipeYaml: (yaml) => set({ recipeYaml: yaml }),

      // Generation config
      generation: {
        deliveryMode: 'batch',
        count: 10,
        maxRecords: 50,
        intervalMs: 0,
        seed: '',
      },
      setGeneration: (patch) =>
        set((state) => ({
          generation: { ...state.generation, ...patch },
        })),

      // Sinks
      sinks: [
        { id: genSinkId(), type: 'memory', config: {}, status: 'idle' },
      ],
      addSink: (type) =>
        set((state) => ({
          sinks: [
            ...state.sinks,
            { id: genSinkId(), type, config: {}, status: 'idle' },
          ],
        })),
      updateSink: (id, patch) =>
        set((state) => ({
          sinks: state.sinks.map((s) =>
            s.id === id ? { ...s, ...patch } : s,
          ),
        })),
      removeSink: (id) =>
        set((state) => ({
          sinks: state.sinks.filter((s) => s.id !== id),
        })),

      // Execution
      busy: false,
      streaming: false,
      error: null,
      setBusy: (busy) => set({ busy }),
      setStreaming: (streaming) => set({ streaming }),
      setError: (error) => set({ error }),

      // Output
      output: {
        activeTab: 'data',
        format: 'json',
        batchResults: null,
        batchMeta: null,
        streamRecords: [],
        streamTotalReceived: 0,
        logs: [],
      },
      setOutputTab: (tab) =>
        set((state) => ({
          output: { ...state.output, activeTab: tab },
        })),
      setOutputFormat: (format) =>
        set((state) => ({
          output: { ...state.output, format },
        })),
      setBatchResults: (records, meta) =>
        set((state) => ({
          output: {
            ...state.output,
            activeTab: 'data',
            batchResults: records,
            batchMeta: meta,
          },
          bottomPanelOpen: true,
        })),
      addStreamRecord: (record) =>
        set((state) => {
          const next = [...state.output.streamRecords, record];
          const capped =
            next.length > STREAM_DISPLAY_CAP
              ? next.slice(-STREAM_DISPLAY_CAP)
              : next;
          return {
            output: {
              ...state.output,
              activeTab: 'stream',
              streamRecords: capped,
              streamTotalReceived: state.output.streamTotalReceived + 1,
            },
            bottomPanelOpen: true,
          };
        }),
      clearStream: () =>
        set((state) => ({
          output: {
            ...state.output,
            streamRecords: [],
            streamTotalReceived: 0,
          },
        })),
      clearOutput: () =>
        set((state) => ({
          output: {
            ...state.output,
            batchResults: null,
            batchMeta: null,
            streamRecords: [],
            streamTotalReceived: 0,
            logs: [],
          },
        })),
      addLog: (level, message) =>
        set((state) => ({
          output: {
            ...state.output,
            logs: [
              ...state.output.logs,
              { timestamp: Date.now(), level, message },
            ],
          },
        })),

      // Bottom panel
      bottomPanelOpen: true,
      setBottomPanelOpen: (open) => set({ bottomPanelOpen: open }),
    }),
    { name: 'GenerateWorkspace' },
  ),
);

// ── Selectors ────────────────────────────────────────────

export const selectSidebarTab = (s: GenerateWorkspaceState) => s.sidebarTab;
export const selectSchemaSource = (s: GenerateWorkspaceState) => s.schemaSource;
export const selectFields = (s: GenerateWorkspaceState) => s.fields;
export const selectSchemaName = (s: GenerateWorkspaceState) => s.schemaName;
export const selectSelectedFieldIndex = (s: GenerateWorkspaceState) =>
  s.selectedFieldIndex;
export const selectGeneration = (s: GenerateWorkspaceState) => s.generation;
export const selectSinks = (s: GenerateWorkspaceState) => s.sinks;
export const selectBusy = (s: GenerateWorkspaceState) => s.busy;
export const selectStreaming = (s: GenerateWorkspaceState) => s.streaming;
export const selectError = (s: GenerateWorkspaceState) => s.error;
export const selectOutput = (s: GenerateWorkspaceState) => s.output;
export const selectBottomPanelOpen = (s: GenerateWorkspaceState) =>
  s.bottomPanelOpen;
