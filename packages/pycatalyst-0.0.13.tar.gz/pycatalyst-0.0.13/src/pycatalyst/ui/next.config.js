/** @type {import('next').NextConfig} */
const nextConfig = {
  ...(process.env.NODE_ENV === 'production' && { output: 'export' }),
  trailingSlash: true,
  images: { unoptimized: true },
  async rewrites() {
    if (process.env.NEXT_PUBLIC_API_URL && process.env.NODE_ENV !== 'production') {
      return [
        { source: '/api/:path*', destination: `${process.env.NEXT_PUBLIC_API_URL}/api/:path*` },
      ];
    }
    return [];
  },
};

module.exports = nextConfig;
