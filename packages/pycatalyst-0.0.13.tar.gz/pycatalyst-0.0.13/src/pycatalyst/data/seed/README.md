# Seed data for ML experiments

This folder contains mock and seed data for running experiments from the PyCatalyst UI or CLI.

## Mock market data: `market_train.csv`

- **Purpose:** Quick try-out for sklearn and PyTorch experiments (regression).
- **Rows:** 600 (OHLCV-style time series).
- **Columns (all numeric):**
  - `open`, `high`, `low`, `close` — price levels
  - `volume` — traded volume
  - `return_1d` — one-period return `(close - open) / open`
  - `target` — next-period return (what to predict)

Use **target** as the prediction target and the rest as features (or a subset).

### Data path when running the API

When you start the PyCatalyst API from the **pycatalyst repo root** (e.g. `pycatalyst api` or `uvicorn pycatalyst.api.main:app`), use this path in your experiment YAML:

- **Relative to repo root:** `src/pycatalyst/data/seed/market_train.csv`
- Or use an **absolute path** to this file if your process runs from a different directory.

### Example: Sklearn (Random Forest regression)

In the Model Training UI, pick a Sklearn template and set **Data path** to:

```text
src/pycatalyst/data/seed/market_train.csv
```

Set **Target column** to `target`. Leave **Features** empty to use all columns except `target`, or set e.g.:

```text
[open, high, low, close, volume, return_1d]
```

Minimal YAML snippet:

```yaml
data:
  path: src/pycatalyst/data/seed/market_train.csv
  target: target
  split:
    strategy: random
    train: 0.7
    val: 0.15
    test: 0.15
  scaler: standard
  handle_missing: drop
```

### Example: PyTorch (MLP regression)

Use the same path and target. For **tabular** (MLP) experiments, temporal split is optional:

```yaml
data:
  path: src/pycatalyst/data/seed/market_train.csv
  target: target
  split:
    strategy: temporal
    train: 0.7
    val: 0.15
    test: 0.15
  scaler: minmax
  sequence_length: 60
  stride: 1
```

Model training will split the 600 rows into train/val/test and run the experiment.

### Ready-to-run experiment configs

- **Sklearn:** `market_experiment_sklearn.yaml` — Random Forest regression on `target`.
- **PyTorch:** `market_experiment_pytorch.yaml` — MLP regression with temporal split.

Open either file, copy the full YAML, and paste it into the Model Training UI “Run experiment” panel, then run. Ensure the API process was started from the **pycatalyst repository root** so the relative data path resolves.
