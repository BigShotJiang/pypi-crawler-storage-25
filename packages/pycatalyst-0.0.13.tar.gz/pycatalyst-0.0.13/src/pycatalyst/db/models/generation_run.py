"""GenerationRun model for persistent storage of data generation runs."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy import Column, DateTime, Float, Index, Integer, String
from sqlalchemy.types import JSON, Uuid

from pycatalyst.db.base import Base


class GenerationRunModel(Base):
    """Persistent record of a data generation run."""

    __tablename__ = "generation_runs"
    __table_args__ = (
        Index("ix_generation_runs_recipe_name", "recipe_name"),
        {"schema": "pycatalyst"},
    )

    id = Column(Uuid, primary_key=True, default=uuid.uuid4)
    recipe_name = Column(String(255), nullable=True)
    recipe_version = Column(String(50), nullable=True)
    schema_name = Column(String(255), nullable=True)
    record_count = Column(Integer, nullable=True)
    duration_ms = Column(Float, nullable=True)
    seed = Column(Integer, nullable=True)
    run_data = Column(JSON, nullable=True)

    created_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
    )
    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
    )
    created_by = Column(String(255), nullable=True)
    updated_by = Column(String(255), nullable=True)

    def __repr__(self) -> str:
        return f"<GenerationRun(id={self.id!r}, recipe={self.recipe_name!r})>"
