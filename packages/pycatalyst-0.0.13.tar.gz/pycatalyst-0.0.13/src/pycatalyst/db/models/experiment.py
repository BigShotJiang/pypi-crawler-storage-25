"""Experiment model for persistent storage of ML experiment metadata."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy import Column, DateTime, Float, Index, String
from sqlalchemy.types import JSON, Uuid

from pycatalyst.db.base import Base


class ExperimentModel(Base):
    """Persistent record of an ML experiment run."""

    __tablename__ = "experiments"
    __table_args__ = (
        Index("ix_experiments_name_backend", "name", "backend"),
        Index("ix_experiments_status", "status"),
        {"schema": "pycatalyst"},
    )

    id = Column(Uuid, primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    backend = Column(String(100), nullable=False)
    status = Column(String(50), nullable=True)
    metrics = Column(JSON, nullable=True)
    artifacts = Column(JSON, nullable=True)
    training_history = Column(JSON, nullable=True)
    duration_seconds = Column(Float, nullable=True)
    config = Column(JSON, nullable=True)
    timestamp = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
    )

    created_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
    )
    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
    )
    created_by = Column(String(255), nullable=True)
    updated_by = Column(String(255), nullable=True)

    def __repr__(self) -> str:
        return f"<Experiment(name={self.name!r}, backend={self.backend!r})>"
