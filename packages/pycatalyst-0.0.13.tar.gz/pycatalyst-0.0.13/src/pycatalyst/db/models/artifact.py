"""Artifact model for persistent binary storage of experiment artifacts."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy import (
    Column,
    DateTime,
    Index,
    Integer,
    LargeBinary,
    String,
    UniqueConstraint,
)
from sqlalchemy.types import Uuid

from pycatalyst.db.base import Base


class ArtifactModel(Base):
    """Persistent binary artifact associated with an experiment."""

    __tablename__ = "artifacts"
    __table_args__ = (
        UniqueConstraint(
            "experiment_id", "name", name="uq_artifacts_experiment_id_name"
        ),
        Index("ix_artifacts_experiment_id", "experiment_id"),
        {"schema": "pycatalyst"},
    )

    id = Column(Uuid, primary_key=True, default=uuid.uuid4)
    experiment_id = Column(Uuid, nullable=False)
    name = Column(String(255), nullable=False)
    data = Column(LargeBinary, nullable=False)
    size_bytes = Column(Integer, nullable=False)

    created_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
    )
    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
    )
    created_by = Column(String(255), nullable=True)
    updated_by = Column(String(255), nullable=True)

    def __repr__(self) -> str:
        return (
            f"<Artifact(experiment_id={self.experiment_id!r}, "
            f"name={self.name!r}, size={self.size_bytes})>"
        )
