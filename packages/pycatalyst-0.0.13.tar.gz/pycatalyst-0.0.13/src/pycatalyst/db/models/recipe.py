"""Recipe model for persistent storage of recipe configurations."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy import Column, DateTime, String, Text, UniqueConstraint
from sqlalchemy.types import JSON, Uuid

from pycatalyst.db.base import Base


class RecipeModel(Base):
    """Persistent record of a recipe configuration."""

    __tablename__ = "recipes"
    __table_args__ = (
        UniqueConstraint("name", "version", name="uq_recipes_name_version"),
        {"schema": "pycatalyst"},
    )

    id = Column(Uuid, primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    version = Column(String(50), nullable=False)
    description = Column(Text, nullable=True)
    recipe_data = Column(JSON, nullable=True)

    created_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
    )
    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
    )
    created_by = Column(String(255), nullable=True)
    updated_by = Column(String(255), nullable=True)

    def __repr__(self) -> str:
        return f"<Recipe(name={self.name!r}, version={self.version!r})>"
