"""Minimal app_metadata table for PyCatalyst DB (used by initial migration and optional seed)."""

from __future__ import annotations

from sqlalchemy import Column, DateTime, Integer, String, Text

from pycatalyst.db.base import Base


class AppMetadataModel(Base):
    """Key-value metadata table for app/seed state."""

    __tablename__ = "app_metadata"

    id = Column(Integer, primary_key=True, autoincrement=True)
    key = Column(String(255), nullable=False, index=True)
    value = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)

    def __repr__(self) -> str:
        return f"<AppMetadata(key={self.key!r})>"
