"""SchemaSpec model for persistent storage of schema specifications."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy import Column, DateTime, String, Text
from sqlalchemy.types import JSON, Uuid

from pycatalyst.db.base import Base


class SchemaSpecModel(Base):
    """Persistent record of a schema specification."""

    __tablename__ = "schema_specs"
    __table_args__ = {"schema": "pycatalyst"}

    id = Column(Uuid, primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False, unique=True)
    description = Column(Text, nullable=True)
    schema_data = Column(JSON, nullable=True)
    spec_metadata = Column("metadata", JSON, nullable=True)

    created_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
    )
    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
    )
    created_by = Column(String(255), nullable=True)
    updated_by = Column(String(255), nullable=True)

    def __repr__(self) -> str:
        return f"<SchemaSpec(name={self.name!r})>"
