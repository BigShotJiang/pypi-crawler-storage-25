"""
CLI commands for database management (pycatalyst db init, pycatalyst db upgrade)

Following PyStator/PyCharter pattern.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

try:
    from alembic import command
    from sqlalchemy import create_engine, inspect, text

    ALEMBIC_AVAILABLE = True
except ImportError:
    ALEMBIC_AVAILABLE = False

from pycatalyst.config import set_database_url
from pycatalyst.db.base import get_engine
from pycatalyst.db.config import (
    detect_db_type,
    get_alembic_config,
    get_db_url,
    get_migrations_dir,
    require_alembic,
)


# ---------------------------------------------------------------------------
# Command functions
# ---------------------------------------------------------------------------
def cmd_init(
    database_url: str | None = None,
    db_type: str | None = None,
    force: bool = False,
) -> int:
    """Initialize the database schema from scratch."""
    try:
        db_url = get_db_url(database_url)
        if not db_url:
            return 1

        db_type = db_type or detect_db_type(db_url)
        if db_type == "sqlite":
            return _init_sqlite(db_url, force)
        else:
            return _init_postgresql(db_url, force)
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback

        traceback.print_exc()
        return 1


def _init_sqlite(database_url: str, force: bool = False) -> int:
    """Initialize SQLite database."""
    require_alembic()

    try:
        db_path = (
            database_url[10:] if database_url.startswith("sqlite:///") else database_url
        )
        if db_path != ":memory:":
            Path(db_path).parent.mkdir(parents=True, exist_ok=True)

        engine = get_engine(database_url)
        existing_tables = inspect(engine).get_table_names()

        if existing_tables and not force:
            print(
                f"⚠ Warning: Database already contains {len(existing_tables)} tables."
            )
            print(
                "   Use --force to reinitialize, or run 'pycatalyst db upgrade' to apply migrations."
            )
            return 1

        if existing_tables and force:
            with engine.connect() as conn:
                conn.execute(text("PRAGMA foreign_keys=OFF"))
                for name in existing_tables:
                    conn.execute(text(f'DROP TABLE IF EXISTS "{name}"'))
                conn.execute(text("PRAGMA foreign_keys=ON"))
                conn.commit()
            print("✓ Dropped existing tables")

        versions_dir = get_migrations_dir() / "versions"
        if not versions_dir.exists() or not any(versions_dir.iterdir()):
            print(
                "❌ No migrations found. Add Alembic migration files under "
                "db/migrations/versions/ and run again."
            )
            return 1

        set_database_url(database_url)
        config = get_alembic_config(database_url)
        print("Running migrations to initialize database...")
        command.upgrade(config, "head")
        print("✓ Migrations complete")
        print("✓ SQLite initialization complete!")
        return 0
    except Exception as e:
        print(f"❌ Error initializing SQLite: {e}")
        import traceback

        traceback.print_exc()
        return 1


def _init_postgresql(database_url: str, force: bool = False) -> int:
    """Initialize PostgreSQL database."""
    require_alembic()

    try:
        set_database_url(database_url)
        config = get_alembic_config(database_url)
        engine = create_engine(database_url)

        # Create schema
        with engine.connect() as conn:
            conn.execute(text('CREATE SCHEMA IF NOT EXISTS "pycatalyst"'))
            conn.commit()
        print("✓ Created 'pycatalyst' schema (if it didn't exist)")

        # Run migrations
        print("Running migrations to initialize database...")
        command.upgrade(config, "head")
        print("✓ Database initialized successfully!")
        return 0
    except Exception as e:
        print(f"❌ Error initializing database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_upgrade(database_url: str | None = None, revision: str = "head") -> int:
    """Upgrade database to the latest revision."""
    require_alembic()

    try:
        db_url = get_db_url(database_url)
        if not db_url:
            return 1

        if database_url:
            set_database_url(database_url)

        config = get_alembic_config(db_url)
        print(f"Upgrading database to revision: {revision}...")
        command.upgrade(config, revision)
        print("✓ Database upgraded successfully!")
        return 0
    except Exception as e:
        print(f"❌ Error upgrading database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_downgrade(database_url: str | None = None, revision: str = "-1") -> int:
    """Downgrade database to a previous revision."""
    require_alembic()

    try:
        db_url = get_db_url(database_url)
        if not db_url:
            return 1

        if database_url:
            set_database_url(database_url)

        config = get_alembic_config(db_url)
        print(f"Downgrading database to revision: {revision}...")
        command.downgrade(config, revision)
        print("✓ Database downgraded successfully!")
        return 0
    except Exception as e:
        print(f"❌ Error downgrading database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_current(database_url: str | None = None) -> int:
    """Show current database revision."""
    require_alembic()

    try:
        db_url = get_db_url(database_url)
        if not db_url:
            return 1

        if database_url:
            set_database_url(database_url)

        engine = create_engine(db_url)
        is_postgres = db_url.startswith(("postgresql://", "postgres://"))

        with engine.connect() as connection:
            try:
                if is_postgres:
                    result = connection.execute(
                        text(
                            'SELECT version_num FROM "pycatalyst".alembic_version LIMIT 1'
                        )
                    )
                else:
                    result = connection.execute(
                        text("SELECT version_num FROM alembic_version LIMIT 1")
                    )
                version = result.fetchone()
                if version:
                    print(f"Current database revision: {version[0]}")
                    return 0
            except Exception:
                pass

            # Fallback: try MigrationContext
            from alembic.runtime.migration import MigrationContext

            context = MigrationContext.configure(connection)
            current_rev = context.get_current_revision()
            if current_rev:
                print(f"Current database revision: {current_rev}")
                return 0

        print("Database is not initialized. Run 'pycatalyst db init' first.")
        return 1
    except Exception as e:
        print(f"❌ Error getting current revision: {e}")
        return 1


def cmd_history(database_url: str | None = None) -> int:
    """Show migration history."""
    require_alembic()

    try:
        if database_url:
            set_database_url(database_url)
        config = get_alembic_config(database_url)
        command.history(config)
        return 0
    except Exception as e:
        print(f"❌ Error showing history: {e}")
        return 1


def cmd_stamp(database_url: str | None = None, revision: str = "head") -> int:
    """Stamp the database with a revision without running migrations."""
    require_alembic()

    try:
        db_url = get_db_url(database_url)
        if not db_url:
            return 1

        if database_url:
            set_database_url(database_url)

        config = get_alembic_config(db_url)
        print(f"Stamping database with revision: {revision}...")
        command.stamp(config, revision)
        print(f"✓ Database stamped at {revision}")
        return 0
    except Exception as e:
        print(f"❌ Error stamping database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_seed(seed_dir: str | None = None, database_url: str | None = None) -> int:
    """Seed the database. No domain seed data yet; reports and exits 0."""
    try:
        # Handle swapped arguments (URL as first positional)
        if seed_dir and any(
            seed_dir.startswith(prefix)
            for prefix in ("postgresql://", "postgres://", "sqlite://")
        ):
            database_url, seed_dir = seed_dir, None

        db_url = get_db_url(database_url)
        if not db_url:
            return 1

        # Resolve seed directory
        if seed_dir:
            seed_path = Path(seed_dir)
        else:
            try:
                import pycatalyst as _pkg

                seed_path = Path(_pkg.__file__).resolve().parent / "data" / "seed"
            except (ImportError, AttributeError):
                seed_path = Path(__file__).resolve().parent.parent / "data" / "seed"

        if not seed_path.exists():
            print(f"ℹ Seed directory not found: {seed_path}")
            print("  No seed data to load.")
            return 0

        yaml_files = sorted(seed_path.glob("*.yaml")) + sorted(seed_path.glob("*.yml"))
        if not yaml_files:
            print(f"ℹ No .yaml/.yml files in {seed_path}. No seed data to load.")
            return 0

        # Future: add a loader that inserts into app_metadata or a seed table
        print(
            f"ℹ Seed directory has {len(yaml_files)} file(s). No loader configured yet."
        )
        print("  No seed data loaded.")
        return 0
    except Exception as e:
        print(f"❌ Error seeding database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_truncate(database_url: str | None = None, force: bool = False) -> int:
    """Truncate PyCatalyst application tables (app_metadata)."""
    require_alembic()

    try:
        db_url = get_db_url(database_url)
        if not db_url:
            return 1

        if database_url:
            set_database_url(database_url)

        engine = create_engine(db_url)
        is_postgres = db_url.startswith(("postgresql://", "postgres://"))

        if is_postgres:
            inspector = inspect(engine)
            existing_tables = set(inspector.get_table_names(schema="pycatalyst"))
        else:
            existing_tables = set(inspect(engine).get_table_names())

        tables = ["app_metadata"]
        existing_tables_to_truncate = [t for t in tables if t in existing_tables]

        if not existing_tables_to_truncate:
            print("⚠ No PyCatalyst tables found to truncate.")
            return 0

        print(
            f"\n⚠ WARNING: This will truncate {len(existing_tables_to_truncate)} table(s):"
        )
        print(f"   {', '.join(existing_tables_to_truncate)}")
        print("\n⚠ ALL DATA IN THESE TABLES WILL BE PERMANENTLY DELETED!")

        if not force:
            try:
                confirmation = input("\nType 'yes' to confirm: ").strip().lower()
                if confirmation not in ["yes", "y"]:
                    print("❌ Truncate cancelled.")
                    return 1
            except (EOFError, KeyboardInterrupt):
                print("\n❌ Truncate cancelled.")
                return 1

        with engine.begin() as conn:
            if is_postgres:
                conn.execute(text("SET session_replication_role = 'replica'"))
                for table in existing_tables_to_truncate:
                    conn.execute(text(f'TRUNCATE TABLE pycatalyst."{table}" CASCADE'))
                    print(f"  ✓ Truncated {table}")
                conn.execute(text("SET session_replication_role = 'origin'"))
            else:
                conn.execute(text("PRAGMA foreign_keys=OFF"))
                for table in existing_tables_to_truncate:
                    conn.execute(text(f'DELETE FROM "{table}"'))
                    print(f"  ✓ Truncated {table}")
                conn.execute(text("PRAGMA foreign_keys=ON"))

        print("\n✓ Successfully truncated PyCatalyst tables!")
        return 0
    except Exception as e:
        print(f"❌ Error truncating database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def main() -> int:
    """Main CLI entry point for pycatalyst db commands."""
    parser = argparse.ArgumentParser(
        description="PyCatalyst database management commands",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # init
    init_parser = subparsers.add_parser(
        "init", help="Initialize database schema from scratch"
    )
    init_parser.add_argument(
        "database_url",
        nargs="?",
        help="Database connection string (defaults to sqlite:///pycatalyst.db)",
    )
    init_parser.add_argument(
        "--db",
        "--database-type",
        dest="db_type",
        choices=["postgresql", "postgres", "sqlite"],
        default=None,
        help="Database type (auto-detected from URL if not provided)",
    )
    init_parser.add_argument(
        "--force", action="store_true", help="Proceed even if initialized"
    )

    # upgrade
    upgrade_parser = subparsers.add_parser(
        "upgrade", help="Upgrade database to latest revision"
    )
    upgrade_parser.add_argument(
        "database_url", nargs="?", help="Database connection string"
    )
    upgrade_parser.add_argument("--revision", default="head", help="Target revision")

    # downgrade
    downgrade_parser = subparsers.add_parser("downgrade", help="Downgrade database")
    downgrade_parser.add_argument(
        "database_url", nargs="?", help="Database connection string"
    )
    downgrade_parser.add_argument("--revision", default="-1", help="Target revision")

    # current
    current_parser = subparsers.add_parser(
        "current", help="Show current database revision"
    )
    current_parser.add_argument(
        "database_url", nargs="?", help="Database connection string"
    )

    # history
    history_parser = subparsers.add_parser("history", help="Show migration history")
    history_parser.add_argument(
        "database_url", nargs="?", help="Database connection string"
    )

    # stamp
    stamp_parser = subparsers.add_parser(
        "stamp", help="Stamp database with revision without running migrations"
    )
    stamp_parser.add_argument(
        "database_url", nargs="?", help="Database connection string"
    )
    stamp_parser.add_argument("--revision", default="head", help="Revision to stamp")

    # seed
    seed_parser = subparsers.add_parser(
        "seed", help="Seed database from YAML (if configured)"
    )
    seed_parser.add_argument(
        "seed_dir", nargs="?", help="Directory with seed YAML files"
    )
    seed_parser.add_argument(
        "database_url", nargs="?", help="Database connection string"
    )

    # truncate
    truncate_parser = subparsers.add_parser(
        "truncate", help="Truncate application tables"
    )
    truncate_parser.add_argument(
        "database_url", nargs="?", help="Database connection string"
    )
    truncate_parser.add_argument(
        "--force", action="store_true", help="Skip confirmation"
    )

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    commands = {
        "init": lambda: cmd_init(
            getattr(args, "database_url", None),
            db_type=getattr(args, "db_type", None),
            force=getattr(args, "force", False),
        ),
        "upgrade": lambda: cmd_upgrade(
            getattr(args, "database_url", None),
            getattr(args, "revision", "head"),
        ),
        "downgrade": lambda: cmd_downgrade(
            getattr(args, "database_url", None),
            getattr(args, "revision", "-1"),
        ),
        "current": lambda: cmd_current(getattr(args, "database_url", None)),
        "history": lambda: cmd_history(getattr(args, "database_url", None)),
        "stamp": lambda: cmd_stamp(
            getattr(args, "database_url", None),
            getattr(args, "revision", "head"),
        ),
        "seed": lambda: cmd_seed(
            getattr(args, "seed_dir", None),
            getattr(args, "database_url", None),
        ),
        "truncate": lambda: cmd_truncate(
            getattr(args, "database_url", None),
            force=getattr(args, "force", False),
        ),
    }

    result = commands.get(args.command, lambda: (parser.print_help(), 1)[1])()
    return result if isinstance(result, int) else 0


if __name__ == "__main__":
    sys.exit(main())
