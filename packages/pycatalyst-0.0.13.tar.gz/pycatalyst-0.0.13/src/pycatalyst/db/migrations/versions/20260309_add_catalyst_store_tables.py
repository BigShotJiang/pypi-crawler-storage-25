"""Add catalyst store tables (experiments, recipes, schema_specs, generation_runs)

Revision ID: 20260309000000
Revises: 20260101000000
Create Date: 2026-03-09

"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "20260309000000"
down_revision: str | None = "20260101000000"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _schema() -> str | None:
    """Use pycatalyst schema for PostgreSQL; None for SQLite."""
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pycatalyst"


def upgrade() -> None:
    schema_name = _schema()

    # -- experiments --
    op.create_table(
        "experiments",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("backend", sa.String(100), nullable=False),
        sa.Column("status", sa.String(50), nullable=True),
        sa.Column("metrics", sa.JSON(), nullable=True),
        sa.Column("artifacts", sa.JSON(), nullable=True),
        sa.Column("training_history", sa.JSON(), nullable=True),
        sa.Column("duration_seconds", sa.Float(), nullable=True),
        sa.Column("config", sa.JSON(), nullable=True),
        sa.Column("timestamp", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_by", sa.String(255), nullable=True),
        sa.Column("updated_by", sa.String(255), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        schema=schema_name,
    )
    op.create_index(
        "ix_experiments_name_backend",
        "experiments",
        ["name", "backend"],
        schema=schema_name,
    )
    op.create_index(
        "ix_experiments_status",
        "experiments",
        ["status"],
        schema=schema_name,
    )

    # -- recipes --
    op.create_table(
        "recipes",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("version", sa.String(50), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("recipe_data", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_by", sa.String(255), nullable=True),
        sa.Column("updated_by", sa.String(255), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("name", "version", name="uq_recipes_name_version"),
        schema=schema_name,
    )

    # -- schema_specs --
    op.create_table(
        "schema_specs",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("schema_data", sa.JSON(), nullable=True),
        sa.Column("metadata", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_by", sa.String(255), nullable=True),
        sa.Column("updated_by", sa.String(255), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("name"),
        schema=schema_name,
    )

    # -- generation_runs --
    op.create_table(
        "generation_runs",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("recipe_name", sa.String(255), nullable=True),
        sa.Column("recipe_version", sa.String(50), nullable=True),
        sa.Column("schema_name", sa.String(255), nullable=True),
        sa.Column("record_count", sa.Integer(), nullable=True),
        sa.Column("duration_ms", sa.Float(), nullable=True),
        sa.Column("seed", sa.Integer(), nullable=True),
        sa.Column("run_data", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_by", sa.String(255), nullable=True),
        sa.Column("updated_by", sa.String(255), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        schema=schema_name,
    )
    op.create_index(
        "ix_generation_runs_recipe_name",
        "generation_runs",
        ["recipe_name"],
        schema=schema_name,
    )


def downgrade() -> None:
    schema_name = _schema()
    op.drop_index(
        "ix_generation_runs_recipe_name",
        table_name="generation_runs",
        schema=schema_name,
    )
    op.drop_table("generation_runs", schema=schema_name)
    op.drop_table("schema_specs", schema=schema_name)
    op.drop_table("recipes", schema=schema_name)
    op.drop_index(
        "ix_experiments_status",
        table_name="experiments",
        schema=schema_name,
    )
    op.drop_index(
        "ix_experiments_name_backend",
        table_name="experiments",
        schema=schema_name,
    )
    op.drop_table("experiments", schema=schema_name)
