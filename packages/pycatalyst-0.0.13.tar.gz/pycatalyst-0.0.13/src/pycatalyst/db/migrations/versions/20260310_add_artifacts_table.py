"""Add artifacts table for binary experiment artifact storage.

Revision ID: 20260310000000
Revises: 20260309000000
Create Date: 2026-03-10

"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "20260310000000"
down_revision: str | None = "20260309000000"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _schema() -> str | None:
    """Use pycatalyst schema for PostgreSQL; None for SQLite."""
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pycatalyst"


def upgrade() -> None:
    schema_name = _schema()

    op.create_table(
        "artifacts",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("experiment_id", sa.Uuid(), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("data", sa.LargeBinary(), nullable=False),
        sa.Column("size_bytes", sa.Integer(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_by", sa.String(255), nullable=True),
        sa.Column("updated_by", sa.String(255), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "experiment_id", "name", name="uq_artifacts_experiment_id_name"
        ),
        schema=schema_name,
    )
    op.create_index(
        "ix_artifacts_experiment_id",
        "artifacts",
        ["experiment_id"],
        schema=schema_name,
    )


def downgrade() -> None:
    schema_name = _schema()
    op.drop_index(
        "ix_artifacts_experiment_id",
        table_name="artifacts",
        schema=schema_name,
    )
    op.drop_table("artifacts", schema=schema_name)
