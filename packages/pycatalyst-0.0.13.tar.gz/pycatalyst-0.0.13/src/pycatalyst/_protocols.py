"""Protocol definitions for PyCatalyst pluggable interfaces.

Protocols define the contracts for generators and schema
inferrers. Implementations can be swapped in via dependency injection
without coupling to concrete classes.

Sink protocols live in ``pycatalyst.sinks.types``.
"""

from __future__ import annotations

from random import Random
from typing import Any, Protocol, runtime_checkable

from pycatalyst._types import FieldSpec, SchemaSpec

# ---------------------------------------------------------------------------
# Generator protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class Generator(Protocol):
    """Generates values for a single field type.

    Implementations produce random or constrained values based on a
    FieldSpec. Each generator handles one or more FieldType values.
    """

    def generate(self, spec: FieldSpec, rng: Random) -> Any:
        """Generate a single value for the given field spec.

        Args:
            spec: The field specification describing what to generate.
            rng: Random number generator for reproducible output.

        Returns:
            A generated value matching the field spec's type and constraints.
        """
        ...


# ---------------------------------------------------------------------------
# Schema inferrer protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class SchemaInferrer(Protocol):
    """Infers a SchemaSpec from a data source.

    Implementations analyze sample data (CSV, JSON, Parquet, etc.)
    to produce a SchemaSpec suitable for generation.
    """

    def infer(self, source: Any) -> SchemaSpec:
        """Infer a schema from the given data source.

        Args:
            source: The data source to analyze. Type depends on
                implementation (file path, DataFrame, dict, etc.).

        Returns:
            An inferred SchemaSpec ready for data generation.
        """
        ...
