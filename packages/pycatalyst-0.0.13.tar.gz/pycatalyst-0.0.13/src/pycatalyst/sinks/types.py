"""Sink protocols and result type for recipe output delivery."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable


@dataclass(frozen=True, slots=True)
class SinkResult:
    """Result of sending data to a sink."""

    success: bool
    records_sent: int
    sink_type: str = ""
    errors: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)


@runtime_checkable
class Sink(Protocol):
    """Receives data batches (synchronous)."""

    def send(
        self,
        records: list[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> SinkResult: ...

    def close(self) -> None: ...


@runtime_checkable
class AsyncSink(Protocol):
    """Receives data batches (asynchronous)."""

    async def send(
        self,
        records: list[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> SinkResult: ...

    async def close(self) -> None: ...
