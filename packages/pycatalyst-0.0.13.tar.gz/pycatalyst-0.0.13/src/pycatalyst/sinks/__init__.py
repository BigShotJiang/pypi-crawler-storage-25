"""Recipe output sinks (file, HTTP, Kafka, memory, etc.)."""

from pycatalyst.sinks.errors import SinkError
from pycatalyst.sinks.factory import create_sink, validate_sink_config
from pycatalyst.sinks.types import AsyncSink, Sink, SinkResult

__all__ = [
    "AsyncSink",
    "Sink",
    "SinkError",
    "SinkResult",
    "create_sink",
    "validate_sink_config",
]
