"""Exceptions for sink configuration and delivery."""

from __future__ import annotations

from typing import Any


class SinkError(Exception):
    """Error sending data to a sink or invalid sink configuration."""

    def __init__(
        self,
        message: str,
        sink_type: str | None = None,
        records_sent: int = 0,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = dict(context or {})
        if sink_type:
            ctx["sink_type"] = sink_type
        ctx["records_sent"] = records_sent
        super().__init__(message)
        self.sink_type = sink_type
        self.records_sent = records_sent
        self.context = ctx
