"""In-memory sink for testing and programmatic use."""

from __future__ import annotations

from typing import Any

from pycatalyst.sinks.types import SinkResult


class InMemorySink:
    """Stores generated records in memory."""

    def __init__(self) -> None:
        self.records: list[dict[str, Any]] = []
        self.batches: list[list[dict[str, Any]]] = []
        self._metadata: list[dict[str, Any]] = []

    def send(
        self,
        records: list[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> SinkResult:
        self.records.extend(records)
        self.batches.append(list(records))
        self._metadata.append(dict(metadata))
        return SinkResult(
            success=True,
            records_sent=len(records),
            sink_type="memory",
        )

    def close(self) -> None:
        """No-op for in-memory sink."""

    def clear(self) -> None:
        self.records.clear()
        self.batches.clear()
        self._metadata.clear()

    @property
    def record_count(self) -> int:
        return len(self.records)

    @property
    def batch_count(self) -> int:
        return len(self.batches)
