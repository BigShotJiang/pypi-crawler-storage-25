"""Console sink for printing generated data."""

from __future__ import annotations

import json
import logging
import sys
from typing import IO, Any

from pycatalyst.sinks.errors import SinkError
from pycatalyst.sinks.types import SinkResult

logger = logging.getLogger(__name__)

_SUPPORTED_FORMATS = {"json", "ndjson", "table"}


class ConsoleSink:
    """Prints generated records to stdout or a custom stream."""

    def __init__(
        self,
        *,
        format: str = "json",
        color: bool = True,
        file: IO[str] | None = None,
    ) -> None:
        fmt = format.lower()
        if fmt not in _SUPPORTED_FORMATS:
            raise SinkError(
                f"Unsupported console format: '{fmt}'. "
                f"Supported: {', '.join(sorted(_SUPPORTED_FORMATS))}",
                sink_type="console",
            )
        self._format = fmt
        self._color = color
        self._file = file

    @property
    def _out(self) -> IO[str]:
        return self._file if self._file is not None else sys.stdout

    def send(
        self,
        records: list[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> SinkResult:
        out = self._out
        if self._format == "json":
            out.write(json.dumps(records, indent=2, default=str))
            out.write("\n")
        elif self._format == "ndjson":
            for record in records:
                out.write(json.dumps(record, default=str))
                out.write("\n")
        elif self._format == "table":
            _write_table(records, out)
        out.flush()

        logger.info(
            "printed %d records to console (%s)",
            len(records),
            self._format,
        )
        return SinkResult(
            success=True,
            records_sent=len(records),
            sink_type="console",
            metadata={"format": self._format},
        )

    def close(self) -> None:
        """No-op for console sink."""


def _write_table(records: list[dict[str, Any]], out: IO[str]) -> None:
    if not records:
        return

    columns: list[str] = []
    seen: set[str] = set()
    for record in records:
        for key in record:
            if key not in seen:
                columns.append(key)
                seen.add(key)

    str_rows: list[list[str]] = []
    widths = [len(c) for c in columns]
    for record in records:
        row: list[str] = []
        for idx, col in enumerate(columns):
            cell = str(record.get(col, ""))
            if len(cell) > 60:
                cell = cell[:57] + "..."
            row.append(cell)
            widths[idx] = max(widths[idx], len(cell))
        str_rows.append(row)

    header = "  ".join(c.ljust(widths[i]) for i, c in enumerate(columns))
    separator = "  ".join("-" * widths[i] for i in range(len(columns)))
    out.write(header + "\n")
    out.write(separator + "\n")
    for row in str_rows:
        line = "  ".join(row[i].ljust(widths[i]) for i in range(len(columns)))
        out.write(line + "\n")
