"""RabbitMQ sink for publishing generated data."""

from __future__ import annotations

import json
import logging
from typing import Any

from pycatalyst.sinks.errors import SinkError
from pycatalyst.sinks.types import SinkResult

logger = logging.getLogger(__name__)


class RabbitMQSink:
    """Publishes generated records to a RabbitMQ exchange."""

    def __init__(
        self,
        url: str,
        *,
        exchange: str = "",
        routing_key: str = "",
        queue: str | None = None,
        declare_queue: bool = True,
        delivery_mode: int = 2,
    ) -> None:
        try:
            import pika  # noqa: F401
        except ImportError:
            raise SinkError(
                "pika is required for RabbitMQSink. "
                "Install with: pip install pycatalyst[rabbitmq]",
                sink_type="rabbitmq",
            ) from None

        self._url = url
        self._exchange = exchange
        self._routing_key = routing_key or (queue or "")
        self._queue = queue
        self._declare_queue = declare_queue
        self._delivery_mode = delivery_mode
        self._connection: Any = None
        self._channel: Any = None

    def _connect(self) -> Any:
        if self._connection is None or self._connection.is_closed:
            import pika

            params = pika.URLParameters(self._url)
            self._connection = pika.BlockingConnection(params)
            self._channel = self._connection.channel()

            if self._queue and self._declare_queue:
                self._channel.queue_declare(queue=self._queue, durable=True)
                logger.debug("declared queue %s", self._queue)

        return self._channel

    def send(
        self,
        records: list[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> SinkResult:
        if not records:
            return SinkResult(
                success=True,
                records_sent=0,
                sink_type="rabbitmq",
            )

        import pika

        total_sent = 0
        errors: list[str] = []

        try:
            channel = self._connect()

            properties = pika.BasicProperties(
                delivery_mode=self._delivery_mode,
                content_type="application/json",
            )

            for record in records:
                body = json.dumps(record).encode("utf-8")
                channel.basic_publish(
                    exchange=self._exchange,
                    routing_key=self._routing_key,
                    body=body,
                    properties=properties,
                )
                total_sent += 1

        except Exception as exc:
            msg = f"RabbitMQ publish failed: {exc}"
            errors.append(msg)
            logger.warning("rabbitmq sink error: %s", msg)

        success = len(errors) == 0

        if success:
            logger.info(
                "published %d records to %s/%s",
                total_sent,
                self._exchange or "(default)",
                self._routing_key,
            )

        return SinkResult(
            success=success,
            records_sent=total_sent,
            sink_type="rabbitmq",
            errors=tuple(errors),
            metadata={
                "exchange": self._exchange,
                "routing_key": self._routing_key,
                "url": _mask_amqp_url(self._url),
            },
        )

    def close(self) -> None:
        if self._connection is not None and not self._connection.is_closed:
            self._connection.close()
        self._connection = None
        self._channel = None


def _mask_amqp_url(url: str) -> str:
    if "@" in url and ":" in url.split("@")[0]:
        prefix, rest = url.split("@", 1)
        scheme_user = prefix.rsplit(":", 1)[0]
        return f"{scheme_user}:***@{rest}"
    return url
