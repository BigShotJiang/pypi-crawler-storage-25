"""Create sink instances from type name and config dict."""

from __future__ import annotations

from typing import Any

from pycatalyst.sinks.errors import SinkError


def validate_sink_config(sink_type: str, config: dict[str, Any]) -> None:
    """Raise SinkError if *sink_type* is known and required keys are missing."""
    st = sink_type.lower().strip()
    if st == "memory":
        return
    if st == "file":
        if not config.get("path"):
            raise SinkError("File sink requires 'path' in config", sink_type="file")
        return
    if st == "http":
        if not config.get("url"):
            raise SinkError("HTTP sink requires 'url' in config", sink_type="http")
        return
    if st == "database":
        if not config.get("connection_url"):
            raise SinkError(
                "Database sink requires 'connection_url'",
                sink_type="database",
            )
        if not config.get("table_name"):
            raise SinkError(
                "Database sink requires 'table_name'",
                sink_type="database",
            )
        return
    if st == "kafka":
        if not config.get("bootstrap_servers"):
            raise SinkError(
                "Kafka sink requires 'bootstrap_servers'",
                sink_type="kafka",
            )
        if not config.get("topic"):
            raise SinkError(
                "Kafka sink requires 'topic'",
                sink_type="kafka",
            )
        return
    if st == "rabbitmq":
        if not config.get("url"):
            raise SinkError(
                "RabbitMQ sink requires 'url'",
                sink_type="rabbitmq",
            )
        return
    if st == "s3":
        if not config.get("bucket"):
            raise SinkError("S3 sink requires 'bucket'", sink_type="s3")
        if not config.get("key"):
            raise SinkError("S3 sink requires 'key'", sink_type="s3")
        return
    if st == "console":
        return


def create_sink(sink_type: str, config: dict[str, Any]) -> Any:
    """Create a sink instance from a type name and config dict."""
    validate_sink_config(sink_type, config)
    st = sink_type.lower().strip()

    if st == "memory":
        from pycatalyst.sinks.memory import InMemorySink

        return InMemorySink()

    if st == "file":
        from pycatalyst.sinks.file import FileSink

        return FileSink(
            config["path"],
            format=config.get("format"),
            append=config.get("append", False),
        )

    if st == "http":
        from pycatalyst.sinks.http import HttpSink

        return HttpSink(
            config["url"],
            method=config.get("method", "POST"),
            headers=config.get("headers"),
            batch_size=config.get("batch_size", 0),
            timeout=config.get("timeout", 30.0),
            auth_token=config.get("auth_token"),
        )

    if st == "database":
        from pycatalyst.sinks.database import DatabaseSink

        return DatabaseSink(
            config["connection_url"],
            config["table_name"],
            batch_size=config.get("batch_size", 0),
            if_exists=config.get("if_exists", "append"),
            schema=config.get("schema"),
        )

    if st == "kafka":
        from pycatalyst.sinks.kafka import KafkaSink

        return KafkaSink(
            config["bootstrap_servers"],
            config["topic"],
            key_field=config.get("key_field"),
            producer_config=config.get("producer_config"),
            flush_timeout=config.get("flush_timeout", 10.0),
        )

    if st == "rabbitmq":
        from pycatalyst.sinks.rabbitmq import RabbitMQSink

        return RabbitMQSink(
            config["url"],
            exchange=config.get("exchange", ""),
            routing_key=config.get("routing_key", ""),
            queue=config.get("queue"),
            declare_queue=config.get("declare_queue", True),
        )

    if st == "s3":
        from pycatalyst.sinks.s3 import S3Sink

        return S3Sink(
            config["bucket"],
            config["key"],
            format=config.get("format", "json"),
            region=config.get("region"),
            credentials=config.get("credentials"),
            endpoint_url=config.get("endpoint_url"),
        )

    if st == "console":
        from pycatalyst.sinks.console import ConsoleSink

        return ConsoleSink(
            format=config.get("format", "json"),
            color=config.get("color", True),
        )

    raise SinkError(f"Unknown sink type: '{sink_type}'", sink_type=sink_type)
