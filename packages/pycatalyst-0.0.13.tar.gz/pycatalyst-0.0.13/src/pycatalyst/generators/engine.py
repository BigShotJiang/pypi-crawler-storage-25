"""Generation engine that orchestrates field generators.

The GenerationEngine is the main entry point for producing data batches.
It takes a SchemaSpec and produces records by delegating to the
appropriate generator for each field.
"""

from __future__ import annotations

import logging
import random
import time
from collections.abc import Iterator
from random import Random
from typing import Any

from pycatalyst._types import FieldSpec, FieldType, GenerationResult, SchemaSpec
from pycatalyst.errors import GenerationError
from pycatalyst.generators.registry import GeneratorRegistry

logger = logging.getLogger(__name__)


class GenerationEngine:
    """Orchestrates data generation from a SchemaSpec.

    Uses a GeneratorRegistry to resolve generators for each field
    type, then produces batches of records.

    Attributes:
        registry: The generator registry for field type resolution.
    """

    def __init__(
        self,
        registry: GeneratorRegistry | None = None,
    ) -> None:
        self._registry = registry or GeneratorRegistry.default()

    def generate(
        self,
        schema: SchemaSpec,
        count: int = 10,
        seed: int | None = None,
    ) -> GenerationResult:
        """Generate a batch of records from a schema.

        Args:
            schema: The schema describing records to generate.
            count: Number of records to generate.
            seed: Random seed for reproducible output.

        Returns:
            GenerationResult with the generated records.

        Raises:
            GenerationError: If generation fails for any field.
        """
        if count < 1:
            raise GenerationError(
                f"count must be at least 1, got {count}",
                schema_name=schema.name,
            )

        rng = Random(seed)
        if seed is not None:
            random.seed(seed)
        start = time.monotonic()

        records: list[dict[str, Any]] = []
        for i in range(count):
            try:
                record = self._generate_record(schema, rng)
                records.append(record)
            except Exception as exc:
                raise GenerationError(
                    f"Failed to generate record {i}: {exc}",
                    schema_name=schema.name,
                ) from exc

        duration_ms = (time.monotonic() - start) * 1000

        logger.info(
            "generated %d records for schema '%s' in %.1fms",
            count,
            schema.name,
            duration_ms,
        )

        return GenerationResult(
            records=tuple(records),
            schema=schema,
            count=count,
            duration_ms=duration_ms,
            seed=seed,
        )

    def iter_records(
        self,
        schema: SchemaSpec,
        *,
        seed: int | None = None,
        limit: int,
    ) -> Iterator[dict[str, Any]]:
        """Yield records one at a time using the same RNG semantics as :meth:`generate`.

        The first ``limit`` records match :meth:`generate` with the same
        ``schema``, ``seed``, and ``count=limit``.

        Args:
            schema: Schema describing each record.
            seed: Optional seed for reproducible streams.
            limit: Number of records to yield (must be >= 1).

        Yields:
            One dict per record.

        Raises:
            GenerationError: If ``limit`` is invalid or generation fails.
        """
        if limit < 1:
            raise GenerationError(
                f"limit must be at least 1, got {limit}",
                schema_name=schema.name,
            )
        rng = Random(seed)
        if seed is not None:
            random.seed(seed)
        for i in range(limit):
            try:
                yield self._generate_record(schema, rng)
            except Exception as exc:
                raise GenerationError(
                    f"Failed to generate record {i}: {exc}",
                    schema_name=schema.name,
                ) from exc

    def _generate_record(
        self,
        schema: SchemaSpec,
        rng: Random,
    ) -> dict[str, Any]:
        """Generate a single record from a schema."""
        record: dict[str, Any] = {}
        for field_spec in schema.fields:
            # Handle nullable fields
            if field_spec.nullable and rng.random() < field_spec.nullable_rate:
                record[field_spec.name] = None
                continue

            gen = self._registry.get(field_spec.type)
            value = gen.generate(field_spec, rng)

            # Apply quality defects if configured
            if field_spec.quality:
                value = _apply_quality_defects(value, field_spec, rng)

            record[field_spec.name] = value

        return record


def _apply_quality_defects(
    value: Any,
    spec: FieldSpec,
    rng: Random,
) -> Any:
    """Probabilistically corrupt a value based on quality settings."""
    quality = spec.quality
    if quality is None:
        return value

    # Out-of-range defect for numeric types
    if quality.out_of_range_rate > 0 and rng.random() < quality.out_of_range_rate:
        if spec.type in (FieldType.INT, FieldType.FLOAT):
            c = spec.constraints
            if c and c.max is not None:
                # Push value above max
                over = c.max + rng.randint(1, 100)
                return int(over) if spec.type == FieldType.INT else float(over)

    # Truncation defect for string types
    if quality.truncate_rate > 0 and rng.random() < quality.truncate_rate:
        if spec.type == FieldType.STRING and isinstance(value, str) and len(value) > 1:
            cut = rng.randint(1, max(1, len(value) - 1))
            return value[:cut]

    # Generic invalid defect — replace with type-mismatched sentinel
    if quality.invalid_rate > 0 and rng.random() < quality.invalid_rate:
        if spec.type in (FieldType.INT, FieldType.FLOAT):
            return "INVALID"
        if spec.type == FieldType.STRING:
            return None
        if spec.type == FieldType.BOOL:
            return "maybe"
        if spec.type == FieldType.DATE:
            return "not-a-date"
        if spec.type == FieldType.DATETIME:
            return "not-a-datetime"
        if spec.type == FieldType.UUID:
            return "not-a-uuid"
        if spec.type == FieldType.ENUM:
            return "__INVALID_ENUM__"

    return value
