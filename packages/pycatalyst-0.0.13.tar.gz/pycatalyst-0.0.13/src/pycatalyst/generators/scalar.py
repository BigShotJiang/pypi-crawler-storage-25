"""Built-in scalar generators for primitive field types.

Each generator produces values for a single FieldType using stdlib
``random.Random`` for reproducibility. Constraints from FieldSpec
are respected when provided.
"""

from __future__ import annotations

import math
import string
import uuid as uuid_mod
from datetime import UTC, date, datetime, timedelta
from random import Random
from typing import Any

import exrex

from pycatalyst._types import Distribution, FieldSpec
from pycatalyst.errors import GenerationError


class StringGenerator:
    """Generates random string values."""

    _DEFAULT_MIN_LEN = 5
    _DEFAULT_MAX_LEN = 20
    _CHARSET = string.ascii_letters + string.digits

    def generate(self, spec: FieldSpec, rng: Random) -> Any:
        """Generate a random string value.

        When constraints.pattern is set, generates a string matching the regex
        via exrex (uses global random, seeded by the engine when seed is set).
        Otherwise uses min/max as length and alphanumeric charset.

        Args:
            spec: Field specification with optional constraints.
            rng: Random number generator.

        Returns:
            A random string.
        """
        c = spec.constraints
        if c and c.pattern:
            try:
                return exrex.getone(c.pattern)
            except Exception as exc:
                raise GenerationError(
                    f"Pattern constraint failed for field '{spec.name}': {exc}. "
                    "Use a simpler pattern or check regex syntax.",
                    field_name=spec.name,
                ) from exc
        min_len = int(c.min) if c and c.min is not None else self._DEFAULT_MIN_LEN
        max_len = int(c.max) if c and c.max is not None else self._DEFAULT_MAX_LEN
        length = rng.randint(min_len, max_len)
        return "".join(rng.choices(self._CHARSET, k=length))


class IntGenerator:
    """Generates random integer values."""

    _DEFAULT_MIN = 0
    _DEFAULT_MAX = 2**31 - 1

    def generate(self, spec: FieldSpec, rng: Random) -> Any:
        """Generate a random integer value.

        Args:
            spec: Field specification with optional constraints.
            rng: Random number generator.

        Returns:
            A random integer.
        """
        c = spec.constraints
        lo = int(c.min) if c and c.min is not None else self._DEFAULT_MIN
        hi = int(c.max) if c and c.max is not None else self._DEFAULT_MAX
        if c and c.exclusive_min and c.min is not None:
            lo = int(c.min) + 1
        if c and c.exclusive_max and c.max is not None:
            hi = int(c.max) - 1
        if lo > hi:
            lo, hi = hi, lo
        dist = c.distribution if c else None

        if c and c.multiple_of is not None and c.multiple_of != 0:
            mult = int(c.multiple_of)
            start = ((lo + mult - 1) // mult) * mult
            end = (hi // mult) * mult
            if start > end:
                value = lo
            else:
                step_count = (end - start) // mult
                value = start + rng.randint(0, step_count) * mult
        elif dist == Distribution.NORMAL:
            mean = c.mean if c and c.mean is not None else (lo + hi) / 2
            std = c.std if c and c.std is not None else (hi - lo) / 6
            value = max(lo, min(hi, int(rng.gauss(mean, std))))
        else:
            value = rng.randint(lo, hi)
        return value


class FloatGenerator:
    """Generates random floating-point values."""

    _DEFAULT_MIN = 0.0
    _DEFAULT_MAX = 1000.0

    def generate(self, spec: FieldSpec, rng: Random) -> Any:
        """Generate a random float value.

        Args:
            spec: Field specification with optional constraints.
            rng: Random number generator.

        Returns:
            A random float, optionally rounded to precision.
        """
        c = spec.constraints
        lo = float(c.min) if c and c.min is not None else self._DEFAULT_MIN
        hi = float(c.max) if c and c.max is not None else self._DEFAULT_MAX
        if c and c.exclusive_min and c.min is not None:
            lo = math.nextafter(float(c.min), math.inf)
        if c and c.exclusive_max and c.max is not None:
            hi = math.nextafter(float(c.max), -math.inf)
        if lo > hi:
            lo, hi = hi, lo
        precision = c.precision if c else None
        dist = c.distribution if c else None

        if dist == Distribution.NORMAL:
            mean = c.mean if c and c.mean is not None else (lo + hi) / 2
            std = c.std if c and c.std is not None else (hi - lo) / 6
            value = max(lo, min(hi, rng.gauss(mean, std)))
        elif dist == Distribution.LOG_NORMAL:
            mean = c.mean if c and c.mean is not None else 0.0
            std = c.std if c and c.std is not None else 1.0
            value = max(lo, min(hi, rng.lognormvariate(mean, std)))
        elif dist == Distribution.EXPONENTIAL:
            lambd = 1.0 / ((c.mean if c and c.mean else (hi - lo) / 2) or 1.0)
            value = max(lo, min(hi, lo + rng.expovariate(lambd)))
        else:
            value = rng.uniform(lo, hi)

        if c and c.multiple_of is not None and c.multiple_of != 0:
            m = float(c.multiple_of)
            value = round(value / m) * m
            value = max(lo, min(hi, value))
        if precision is not None:
            value = round(value, precision)
        return value


class BoolGenerator:
    """Generates random boolean values."""

    def generate(self, spec: FieldSpec, rng: Random) -> Any:
        """Generate a random boolean.

        Args:
            spec: Field specification (unused for booleans).
            rng: Random number generator.

        Returns:
            True or False with equal probability.
        """
        return rng.choice([True, False])


class DateGenerator:
    """Generates random date values."""

    _DEFAULT_START = date(2020, 1, 1)
    _DEFAULT_RANGE_DAYS = 365 * 5

    def generate(self, spec: FieldSpec, rng: Random) -> Any:
        """Generate a random date.

        Args:
            spec: Field specification (unused for dates).
            rng: Random number generator.

        Returns:
            A random date as ISO format string.
        """
        offset = rng.randint(0, self._DEFAULT_RANGE_DAYS)
        d = self._DEFAULT_START + timedelta(days=offset)
        return d.isoformat()


class DateTimeGenerator:
    """Generates random datetime values."""

    _DEFAULT_START = datetime(2020, 1, 1, tzinfo=UTC)
    _DEFAULT_RANGE_SECONDS = 365 * 5 * 86400

    def generate(self, spec: FieldSpec, rng: Random) -> Any:
        """Generate a random datetime.

        Args:
            spec: Field specification (unused for datetimes).
            rng: Random number generator.

        Returns:
            A random datetime as ISO format string.
        """
        offset = rng.randint(0, self._DEFAULT_RANGE_SECONDS)
        dt = self._DEFAULT_START + timedelta(seconds=offset)
        return dt.isoformat()


class UUIDGenerator:
    """Generates UUID v4 values."""

    def generate(self, spec: FieldSpec, rng: Random) -> Any:
        """Generate a UUID v4 string.

        Args:
            spec: Field specification (unused for UUIDs).
            rng: Random number generator.

        Returns:
            A UUID v4 string.
        """
        # Generate deterministic UUID from rng for reproducibility
        random_bytes = bytes(rng.getrandbits(8) for _ in range(16))
        return str(uuid_mod.UUID(bytes=random_bytes, version=4))


class EnumGenerator:
    """Generates values from a fixed set of choices."""

    def generate(self, spec: FieldSpec, rng: Random) -> Any:
        """Generate a value from the field's choices.

        Args:
            spec: Field specification with constraints.choices.
            rng: Random number generator.

        Returns:
            A randomly selected choice.

        Raises:
            ValueError: If no choices are defined.
        """
        if not spec.constraints or not spec.constraints.choices:
            raise ValueError(f"Enum field '{spec.name}' has no choices defined")
        return rng.choice(spec.constraints.choices)
