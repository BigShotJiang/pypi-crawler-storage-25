"""Stable Python API identifiers returned to clients (e.g. UI tooltips)."""

# POST /api/v1/generate
PYTHON_API_GENERATION_ENGINE_GENERATE = (
    "pycatalyst.generators.engine.GenerationEngine.generate"
)

# POST /api/v1/recipes/run (orchestrates engine + sink)
PYTHON_API_RECIPE_RUNNER_RUN_DICT = "pycatalyst.recipes.runner.RecipeRunner.run_dict"

# POST /api/v1/stream/sse (no JSON wrapper; documented for UI parity)
PYTHON_API_GENERATION_ENGINE_ITER_RECORDS = (
    "pycatalyst.generators.engine.GenerationEngine.iter_records"
)
