"""FastAPI dependency for catalyst store injection."""

from __future__ import annotations

import logging
from collections.abc import Generator

from pycatalyst.catalyst_store.client import CatalystStoreClient
from pycatalyst.catalyst_store.in_memory import InMemoryCatalystStore

logger = logging.getLogger(__name__)

_store_singleton: CatalystStoreClient | None = None


def _create_store() -> CatalystStoreClient:
    """Resolve and create the appropriate store backend."""
    from pycatalyst.db.config import detect_db_type, get_db_url

    db_url = get_db_url(required=False)
    db_type = detect_db_type(db_url)

    if db_type == "postgresql":
        from pycatalyst.catalyst_store.postgres import (
            PostgresCatalystStore,
        )

        store = PostgresCatalystStore(db_url)
        store.connect(auto_initialize=True)
        logger.info("Catalyst store: PostgreSQL")
        return store

    if db_type == "mongodb":
        from pycatalyst.catalyst_store.mongodb import (
            MongoDBCatalystStore,
        )

        store = MongoDBCatalystStore(db_url)
        store.connect()
        logger.info("Catalyst store: MongoDB")
        return store

    if db_type == "sqlite":
        from pycatalyst.catalyst_store.sqlite import SQLiteCatalystStore

        store = SQLiteCatalystStore(db_url)
        store.connect(auto_initialize=True)
        logger.info("Catalyst store: SQLite (%s)", db_url)
        return store

    logger.warning("Unknown db type %r, falling back to InMemory store", db_type)
    store = InMemoryCatalystStore()
    store.connect()
    return store


def _attach_artifact_backend(store: CatalystStoreClient) -> None:
    """If config says S3, attach S3ArtifactStore as artifact_backend."""
    from pycatalyst.config.artifact import (
        get_artifact_s3_bucket,
        get_artifact_s3_prefix,
        get_artifact_store_type,
    )

    if get_artifact_store_type() != "s3":
        return
    bucket = get_artifact_s3_bucket()
    if not bucket:
        logger.warning(
            "Artifact store type is s3 but PYCATALYST_ARTIFACT_S3_BUCKET not set"
        )
        return
    try:
        from pycatalyst.catalyst_store.s3 import S3ArtifactStore

        prefix = get_artifact_s3_prefix()
        store.artifact_backend = S3ArtifactStore(bucket=bucket, prefix=prefix)
        logger.info("Artifact backend: S3 bucket=%s prefix=%s", bucket, prefix)
    except ImportError as e:
        logger.warning("S3 artifact store requested but boto3 not installed: %s", e)


def get_catalyst_store() -> Generator[CatalystStoreClient, None, None]:
    """FastAPI dependency that yields a catalyst store client.

    Creates a singleton on first call, reuses on subsequent calls.
    Falls back to ``InMemoryCatalystStore`` if the database type is unknown.
    """
    global _store_singleton  # noqa: PLW0603
    if _store_singleton is None:
        _store_singleton = _create_store()
        _attach_artifact_backend(_store_singleton)
    yield _store_singleton
