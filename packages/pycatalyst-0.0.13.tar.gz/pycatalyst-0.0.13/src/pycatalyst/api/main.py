"""PyCatalyst API — FastAPI application.

REST API for data generation, schema inference, and recipe management.

Usage:
    uvicorn pycatalyst.api.main:create_application --factory --reload
"""

from __future__ import annotations

import os
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, HTTPException, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from pycatalyst import __version__ as catalyst_version
from pycatalyst.api.dependencies.auth import get_current_user
from pycatalyst.api.routes.v1 import (
    auth,
    generate,
    infer,
    ml,
    profiles,
    recipes,
    services,
    settings,
    sinks,
    stream,
    workbench,
)
from pycatalyst.config.ports import UI_PORT

API_VERSION = "v1"
API_PREFIX = f"/api/{API_VERSION}"


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Lifespan context manager for FastAPI application."""
    import asyncio

    from pycatalyst.services.workbench_manager import workbench_manager

    reaper_task = asyncio.create_task(workbench_manager.run_reaper())
    yield
    reaper_task.cancel()
    workbench_manager.shutdown()


def create_application() -> FastAPI:
    """Create and configure FastAPI application."""
    app = FastAPI(
        title="PyCatalyst API",
        description="REST API for data generation and testing",
        version=catalyst_version,
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
        lifespan=lifespan,
    )

    # CORS
    cors_origins_env = os.getenv("CORS_ORIGINS", "").strip()
    cors_origins = (
        [o.strip() for o in cors_origins_env.split(",") if o.strip()]
        if cors_origins_env
        else []
    )
    is_production = os.getenv("ENVIRONMENT") == "production"
    if not cors_origins and not is_production:
        cors_origins = [
            "http://localhost:3000",
            "http://localhost:3001",
            f"http://localhost:{UI_PORT}",
            "http://127.0.0.1:3000",
            "http://127.0.0.1:3001",
            f"http://127.0.0.1:{UI_PORT}",
        ]
    use_credentials = bool(cors_origins and "*" not in cors_origins)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins if cors_origins else ["*"],
        allow_credentials=use_credentials,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Exception handlers
    @app.exception_handler(RequestValidationError)
    async def validation_error_handler(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        return JSONResponse(
            status_code=422,
            content={
                "detail": exc.errors(),
                "body": exc.body,
            },
        )

    @app.exception_handler(Exception)
    async def global_error_handler(request: Request, exc: Exception) -> JSONResponse:
        if isinstance(exc, RequestValidationError):
            return JSONResponse(
                status_code=422,
                content={
                    "detail": exc.errors(),
                    "body": exc.body,
                },
            )
        if isinstance(exc, HTTPException):
            return JSONResponse(
                status_code=exc.status_code,
                content={"detail": exc.detail},
            )
        is_dev = os.getenv("ENVIRONMENT") != "production"
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "detail": str(exc) if is_dev else "Internal server error",
            },
        )

    # Auth router (login, logout, me)
    app.include_router(auth.router, prefix=API_PREFIX, tags=["Auth"])

    # Public settings (app-config for UI; no auth)
    app.include_router(
        settings.public_router,
        prefix=API_PREFIX,
        tags=["Settings"],
    )

    # Protected routes: require valid Bearer when auth enabled
    auth_dep = [Depends(get_current_user)]
    app.include_router(
        generate.router,
        prefix=API_PREFIX,
        tags=["generate"],
        dependencies=auth_dep,
    )
    app.include_router(
        stream.router,
        prefix=API_PREFIX,
        tags=["stream"],
        dependencies=auth_dep,
    )
    app.include_router(
        infer.router,
        prefix=API_PREFIX,
        tags=["infer"],
        dependencies=auth_dep,
    )
    app.include_router(
        recipes.router,
        prefix=API_PREFIX,
        tags=["recipes"],
        dependencies=auth_dep,
    )
    app.include_router(
        sinks.router,
        prefix=API_PREFIX,
        tags=["sinks"],
        dependencies=auth_dep,
    )
    app.include_router(
        profiles.router,
        prefix=API_PREFIX,
        tags=["profiles"],
        dependencies=auth_dep,
    )
    app.include_router(
        ml.router,
        prefix=API_PREFIX,
        tags=["ml"],
        dependencies=auth_dep,
    )

    # Service containers (database services) — protected
    app.include_router(
        services.router,
        prefix=API_PREFIX,
        tags=["services"],
        dependencies=auth_dep,
    )

    # Workbench public (capabilities — no auth)
    app.include_router(
        workbench.public_router,
        prefix=API_PREFIX,
        tags=["workbench"],
    )
    # Workbench REST (environment/session CRUD) — protected by HTTPBearer auth
    app.include_router(
        workbench.router,
        prefix=API_PREFIX,
        tags=["workbench"],
        dependencies=auth_dep,
    )
    # Workbench WebSocket — auth via token query param (HTTPBearer can't work over WS)
    app.include_router(
        workbench.ws_router,
        prefix=API_PREFIX,
        tags=["workbench"],
    )

    # Health check
    @app.get("/health")
    async def health() -> dict[str, str]:
        out: dict[str, str] = {"status": "ok", "version": catalyst_version}
        try:
            out["workbench"] = workbench.workbench_manager.workbench_health()
        except Exception:
            out["workbench"] = "unavailable"
        return out

    return app
