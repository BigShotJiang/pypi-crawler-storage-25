"""Shared API request schemas."""
