"""Shared field definitions and schema building for generate/stream endpoints."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from pycatalyst._types import SchemaSpec


class GenerateFieldRequest(BaseModel):
    """Field definition in a generation or streaming request."""

    name: str
    type: str
    nullable: bool = False
    constraints: dict[str, Any] = Field(default_factory=dict)
    children: list[GenerateFieldRequest] = Field(default_factory=list)


def field_request_to_config(field: GenerateFieldRequest) -> dict[str, Any]:
    """Convert API field request to SchemaSpec config dict."""
    config: dict[str, Any] = {
        "name": field.name,
        "type": field.type,
        "nullable": field.nullable,
    }
    if field.constraints:
        config["constraints"] = field.constraints
    if field.children:
        config["children"] = [field_request_to_config(c) for c in field.children]
    return config


def schema_from_field_requests(
    schema_name: str,
    fields: list[GenerateFieldRequest],
) -> SchemaSpec:
    """Build SchemaSpec from API field list."""
    return SchemaSpec.from_config(
        {
            "name": schema_name,
            "fields": [field_request_to_config(f) for f in fields],
        }
    )
