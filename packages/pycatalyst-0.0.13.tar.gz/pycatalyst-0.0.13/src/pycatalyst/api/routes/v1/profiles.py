"""Generation profiles endpoints — list and detail."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, Field

from pycatalyst.recipes.profiles import get_profile, list_profiles

router = APIRouter()


class ProfileItem(BaseModel):
    """Summary of a generation profile."""

    name: str
    description: str
    count: int
    seed: int | None = None
    streaming_enabled: bool = False


class ProfileListResponse(BaseModel):
    """Response listing all profiles."""

    profiles: list[ProfileItem]


class ProfileDetailResponse(BaseModel):
    """Detailed profile information."""

    name: str
    description: str
    generation: dict[str, int | None] = Field(default_factory=dict)
    streaming: dict[str, int | float | bool | None] | None = None


@router.get("/profiles", response_model=ProfileListResponse)
async def list_generation_profiles() -> ProfileListResponse:
    """List all built-in generation profiles."""
    items: list[ProfileItem] = []
    for p in list_profiles():
        items.append(
            ProfileItem(
                name=p.name,
                description=p.description,
                count=p.generation.count,
                seed=p.generation.seed,
                streaming_enabled=p.streaming.enabled if p.streaming else False,
            )
        )
    return ProfileListResponse(profiles=items)


@router.get(
    "/profiles/{name}",
    response_model=ProfileDetailResponse,
)
async def get_generation_profile(name: str) -> ProfileDetailResponse:
    """Get details for a specific generation profile."""
    profile = get_profile(name)
    if profile is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"message": f"Profile {name!r} not found"},
        )
    streaming_dict = None
    if profile.streaming:
        streaming_dict = {
            "enabled": profile.streaming.enabled,
            "max_records": profile.streaming.max_records,
            "batch_size": profile.streaming.batch_size,
            "interval_ms": profile.streaming.interval_ms,
            "duration_seconds": profile.streaming.duration_seconds,
        }
    return ProfileDetailResponse(
        name=profile.name,
        description=profile.description,
        generation={
            "count": profile.generation.count,
            "seed": profile.generation.seed,
        },
        streaming=streaming_dict,
    )
