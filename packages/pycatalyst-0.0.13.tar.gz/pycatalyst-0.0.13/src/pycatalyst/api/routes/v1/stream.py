"""SSE streaming endpoint — POST /api/v1/stream/sse."""

from __future__ import annotations

import asyncio
import logging
import queue
import threading
from collections.abc import AsyncIterator
from typing import Any

from fastapi import APIRouter
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from pycatalyst.api.schemas.generate_common import (
    GenerateFieldRequest,
    schema_from_field_requests,
)
from pycatalyst.errors import CatalystError
from pycatalyst.generators.engine import GenerationEngine
from pycatalyst.streaming.formats import sse_event
from pycatalyst.streaming.limits import StreamLimits, clamp_stream_params

router = APIRouter()
_engine = GenerationEngine()
logger = logging.getLogger(__name__)

_QUEUE_MAX = 256
_DONE = object()


class StreamSSERequest(BaseModel):
    """Body for SSE streaming (same schema shape as generate, plus stream controls)."""

    schema_name: str = Field(default="stream", alias="name")
    fields: list[GenerateFieldRequest]
    seed: int | None = None
    max_records: int = Field(..., ge=1, description="Number of records to stream")
    interval_ms: int = Field(default=0, ge=0, description="Delay between events (ms)")

    model_config = {"populate_by_name": True}


async def _sse_bytes(
    schema_name: str,
    fields: list[GenerateFieldRequest],
    seed: int | None,
    max_records: int,
    interval_ms: float,
) -> AsyncIterator[bytes]:
    try:
        schema = schema_from_field_requests(schema_name, fields)
    except (ValueError, CatalystError) as exc:
        if isinstance(exc, CatalystError):
            err = exc.to_dict()
        else:
            err = {"message": str(exc)}
        yield sse_event({"error": err}, event="error").encode("utf-8")
        return

    q: queue.Queue[dict[str, Any] | object] = queue.Queue(maxsize=_QUEUE_MAX)
    err_box: list[str] = []

    def producer() -> None:
        try:
            for rec in _engine.iter_records(schema, seed=seed, limit=max_records):
                q.put(rec)
        except Exception as e:
            logger.exception("stream producer failed")
            err_box.append(str(e))
        finally:
            q.put(_DONE)

    threading.Thread(
        target=producer, name="pycatalyst-sse-producer", daemon=True
    ).start()

    while True:
        rec = await asyncio.to_thread(q.get)
        if rec is _DONE:
            break
        yield sse_event(rec).encode("utf-8")
        if interval_ms > 0:
            await asyncio.sleep(interval_ms / 1000.0)

    if err_box:
        yield sse_event({"error": err_box[0]}, event="error").encode("utf-8")


@router.post(
    "/stream/sse",
    summary="Stream generated records (SSE)",
    description=(
        "Server-Sent Events: one `record` event per generated row. "
        "Use curl -N or an HTTP client that reads the body incrementally. "
        "Bearer auth required when auth is enabled. "
        "Caps: PYCATALYST_STREAM_MAX_RECORDS, PYCATALYST_STREAM_MAX_INTERVAL_MS."
    ),
    responses={
        200: {
            "description": "text/event-stream; sequence of SSE events",
            "content": {"text/event-stream": {}},
        }
    },
)
async def stream_sse(request: StreamSSERequest) -> StreamingResponse:
    limits = StreamLimits.from_env()
    n, interval_ms = clamp_stream_params(
        request.max_records, request.interval_ms, limits=limits
    )

    async def body() -> AsyncIterator[bytes]:
        async for chunk in _sse_bytes(
            request.schema_name,
            request.fields,
            request.seed,
            n,
            float(interval_ms),
        ):
            yield chunk

    return StreamingResponse(
        body(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
