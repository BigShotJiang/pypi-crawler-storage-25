"""
Route handlers for settings: app-config for UI (theme, app name, version),
and artifact-store (read-only: where ML models are stored, from env/pycatalyst.cfg).
"""

from __future__ import annotations

from fastapi import APIRouter, status
from pydantic import BaseModel, Field

from pycatalyst import __version__ as catalyst_version
from pycatalyst.config import get_ui_app_name, get_ui_theme
from pycatalyst.config.recipes import get_recipe_sink_mode

# Public router: no auth (so UI can load theme before login)
public_router = APIRouter()


@public_router.get(
    "/settings/app-config",
    status_code=status.HTTP_200_OK,
    summary="Get app config (theme, app name, version) for UI",
    description="Returns UI theme (light, dark, system), app name, and release version. No auth required.",
)
async def get_app_config() -> dict[str, str]:
    return {
        "theme": get_ui_theme(),
        "app_name": get_ui_app_name(),
        "version": catalyst_version or "",
        "recipe_sink_mode": get_recipe_sink_mode(),
    }


# --- Artifact store (model storage) ----------------------------------------
# Read-only: configured via environment variables or pycatalyst.cfg [artifact].


class ArtifactStoreResponse(BaseModel):
    """Current artifact store configuration (from env / pycatalyst.cfg)."""

    type: str = Field(description="database or s3")
    s3_bucket: str | None = Field(default=None, description="S3 bucket when type is s3")
    s3_prefix: str | None = Field(
        default=None, description="S3 key prefix when type is s3"
    )


class AwsDataSourceResponse(BaseModel):
    """Resolved AWS data-source config (non-secret) for S3 access."""

    region: str | None = Field(default=None, description="AWS region")
    profile: str | None = Field(default=None, description="AWS profile")
    s3_endpoint_url: str | None = Field(
        default=None,
        description="Optional custom S3 endpoint URL (e.g. MinIO)",
    )
    access_key_id_configured: bool = Field(
        default=False,
        description="True if AWS access key id is configured via env/cfg",
    )
    secret_access_key_configured: bool = Field(
        default=False,
        description="True if AWS secret access key is configured via env/cfg",
    )
    session_token_configured: bool = Field(
        default=False,
        description="True if AWS session token is configured via env/cfg",
    )
    credentials_source: str = Field(
        default="ambient",
        description="explicit, profile, or ambient (instance/task role/other provider chain)",
    )


@public_router.get(
    "/settings/artifact-store",
    response_model=ArtifactStoreResponse,
    status_code=status.HTTP_200_OK,
    summary="Get artifact store configuration",
    description="Returns where ML models/artifacts are stored (database or S3). Configure via env or pycatalyst.cfg [artifact].",
)
async def get_artifact_store() -> ArtifactStoreResponse:
    from pycatalyst.config.artifact import (
        get_artifact_s3_bucket,
        get_artifact_s3_prefix,
        get_artifact_store_type,
    )

    store_type = get_artifact_store_type()
    return ArtifactStoreResponse(
        type=store_type,
        s3_bucket=get_artifact_s3_bucket() if store_type == "s3" else None,
        s3_prefix=get_artifact_s3_prefix() if store_type == "s3" else None,
    )


@public_router.get(
    "/settings/aws-data-source",
    response_model=AwsDataSourceResponse,
    status_code=status.HTTP_200_OK,
    summary="Get AWS data-source configuration",
    description="Returns resolved AWS settings used for S3 data-source access. Secrets are never returned.",
)
async def get_aws_data_source() -> AwsDataSourceResponse:
    from pycatalyst.config.aws import (
        get_aws_access_key_id,
        get_aws_profile,
        get_aws_region,
        get_aws_s3_endpoint_url,
        get_aws_secret_access_key,
        get_aws_session_token,
    )

    access_key = get_aws_access_key_id()
    secret_key = get_aws_secret_access_key()
    session_token = get_aws_session_token()
    profile = get_aws_profile()
    if access_key and secret_key:
        source = "explicit"
    elif profile:
        source = "profile"
    else:
        source = "ambient"
    return AwsDataSourceResponse(
        region=get_aws_region(),
        profile=profile,
        s3_endpoint_url=get_aws_s3_endpoint_url(),
        access_key_id_configured=bool(access_key),
        secret_access_key_configured=bool(secret_key),
        session_token_configured=bool(session_token),
        credentials_source=source,
    )
