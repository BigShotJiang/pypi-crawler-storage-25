"""Generate endpoint — POST /api/v1/generate."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, Field

from pycatalyst.api.generation_metadata import PYTHON_API_GENERATION_ENGINE_GENERATE
from pycatalyst.api.schemas.generate_common import (
    GenerateFieldRequest,
    schema_from_field_requests,
)
from pycatalyst.errors import CatalystError
from pycatalyst.generators.engine import GenerationEngine

router = APIRouter()

_engine = GenerationEngine()


class GenerateRequest(BaseModel):
    """Request body for the generate endpoint."""

    schema_name: str = Field(default="api_request", alias="name")
    fields: list[GenerateFieldRequest]
    count: int = Field(default=10, ge=1, le=100000)
    seed: int | None = None

    model_config = {"populate_by_name": True}


class GenerateResponse(BaseModel):
    """Response from the generate endpoint."""

    records: list[dict[str, Any]]
    count: int
    schema_name: str
    duration_ms: float
    seed: int | None = None
    python_api: str = PYTHON_API_GENERATION_ENGINE_GENERATE


@router.post("/generate", response_model=GenerateResponse)
async def generate_data(request: GenerateRequest) -> GenerateResponse:
    """Generate data from an inline schema definition.

    Args:
        request: Generation parameters with schema fields.

    Returns:
        Generated records with metadata.
    """
    try:
        schema = schema_from_field_requests(request.schema_name, request.fields)

        result = _engine.generate(schema, count=request.count, seed=request.seed)

        return GenerateResponse(
            records=list(result.records),
            count=result.count,
            schema_name=result.schema.name,
            duration_ms=round(result.duration_ms, 2),
            seed=result.seed,
            python_api=PYTHON_API_GENERATION_ENGINE_GENERATE,
        )
    except CatalystError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=exc.to_dict(),
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"message": str(exc)},
        )
