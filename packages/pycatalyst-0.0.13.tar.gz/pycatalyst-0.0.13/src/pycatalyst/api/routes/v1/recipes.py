"""Recipes endpoints — list templates, fetch template YAML, POST run."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

import yaml
from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, Field

from pycatalyst.api.generation_metadata import PYTHON_API_RECIPE_RUNNER_RUN_DICT
from pycatalyst.api.recipe_sink_policy import validate_sink_for_full_mode
from pycatalyst.config.recipes import get_recipe_sink_mode
from pycatalyst.errors import CatalystError
from pycatalyst.recipes.runner import RecipeRunner

router = APIRouter()

_runner = RecipeRunner()


def _recipe_templates_dir() -> Path:
    import pycatalyst

    root = Path(pycatalyst.__file__).resolve().parent
    return root / "data" / "templates" / "recipes"


def _iter_template_files() -> list[Path]:
    d = _recipe_templates_dir()
    if not d.is_dir():
        return []
    return sorted(d.glob("*.yaml"))


def _find_template_path(name: str) -> Path | None:
    n = name.strip()
    if not n:
        return None
    for path in _iter_template_files():
        if path.stem == n:
            return path
        try:
            raw = path.read_text(encoding="utf-8")
            data = yaml.safe_load(raw)
            if isinstance(data, dict) and str(data.get("name", "")).strip() == n:
                return path
        except Exception:
            continue
    return None


class RecipeRunRequest(BaseModel):
    """Request body for running a recipe."""

    name: str
    description: str = ""
    schema_: dict[str, Any] = Field(..., alias="schema")
    generation: dict[str, Any] = Field(default_factory=lambda: {"count": 10})
    sink: dict[str, Any] = Field(default_factory=lambda: {"type": "memory"})
    sinks: list[dict[str, Any]] | None = Field(
        default=None,
        description="Multiple sinks (overrides 'sink' when present)",
    )
    streaming: dict[str, Any] | None = Field(
        default=None,
        description="Streaming generation settings",
    )
    profile: str | None = Field(
        default=None,
        description="Named generation profile preset",
    )

    model_config = {"populate_by_name": True}


class RecipeRunResponse(BaseModel):
    """Response from running a recipe."""

    records: list[dict[str, Any]]
    count: int
    records_sent: int
    sink_type: str
    duration_ms: float
    errors: list[str] = Field(default_factory=list)
    python_api: str = PYTHON_API_RECIPE_RUNNER_RUN_DICT


class RecipeTemplateItem(BaseModel):
    """One shipped recipe template."""

    name: str
    description: str = ""


class RecipeListResponse(BaseModel):
    recipes: list[RecipeTemplateItem]


class RecipeTemplateBody(BaseModel):
    """YAML content for a template."""

    yaml: str


@router.get("/recipes/list", response_model=RecipeListResponse)
async def list_recipe_templates() -> RecipeListResponse:
    """List built-in recipe templates shipped with PyCatalyst."""
    items: list[RecipeTemplateItem] = []
    for path in _iter_template_files():
        try:
            raw = path.read_text(encoding="utf-8")
            data = yaml.safe_load(raw)
            if isinstance(data, dict):
                name = str(data.get("name") or path.stem)
                desc = str(data.get("description") or "")
                items.append(RecipeTemplateItem(name=name, description=desc))
            else:
                items.append(RecipeTemplateItem(name=path.stem, description=""))
        except Exception:
            items.append(RecipeTemplateItem(name=path.stem, description=""))
    return RecipeListResponse(recipes=items)


@router.get(
    "/recipes/templates/{name}",
    response_model=RecipeTemplateBody,
    summary="Get recipe template YAML by name",
)
async def get_recipe_template(name: str) -> RecipeTemplateBody:
    """Return the YAML text for a shipped template (by ``name`` field or file stem)."""
    path = _find_template_path(name)
    if path is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"message": f"Recipe template {name!r} not found."},
        )
    try:
        content = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"message": str(exc)},
        ) from exc
    return RecipeTemplateBody(yaml=content)


def _normalize_sink_dict(sink: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(sink, dict):
        raise ValueError("sink must be an object")
    if "type" not in sink:
        raise ValueError("sink requires 'type'")
    out = dict(sink)
    if "config" not in out:
        out["config"] = {}
    elif not isinstance(out["config"], dict):
        raise ValueError("sink.config must be an object")
    return out


@router.post("/recipes/run", response_model=RecipeRunResponse)
async def run_recipe(request: RecipeRunRequest) -> RecipeRunResponse:
    """Run a recipe and return generated data."""
    mode = get_recipe_sink_mode()
    try:
        if mode == "memory":
            recipe_dict: dict[str, Any] = {
                "name": request.name,
                "description": request.description,
                "schema": request.schema_,
                "generation": request.generation,
                "sink": {"type": "memory", "config": {}},
            }
        else:
            # Multi-sink support
            if request.sinks:
                validated_sinks = []
                for s in request.sinks:
                    ns = _normalize_sink_dict(s)
                    validate_sink_for_full_mode(ns)
                    validated_sinks.append(ns)
                recipe_dict = {
                    "name": request.name,
                    "description": request.description,
                    "schema": request.schema_,
                    "generation": request.generation,
                    "sinks": validated_sinks,
                }
            else:
                sink = _normalize_sink_dict(request.sink or {"type": "memory"})
                validate_sink_for_full_mode(sink)
                recipe_dict = {
                    "name": request.name,
                    "description": request.description,
                    "schema": request.schema_,
                    "generation": request.generation,
                    "sink": sink,
                }

        # Pass through optional fields
        if request.streaming:
            recipe_dict["streaming"] = request.streaming
        if request.profile:
            recipe_dict["profile"] = request.profile

        gen_result, sink_result = await asyncio.to_thread(
            _runner.run_dict,
            recipe_dict,
        )

        return RecipeRunResponse(
            records=list(gen_result.records),
            count=gen_result.count,
            records_sent=sink_result.records_sent,
            sink_type=sink_result.sink_type,
            duration_ms=round(gen_result.duration_ms, 2),
            errors=list(sink_result.errors),
            python_api=PYTHON_API_RECIPE_RUNNER_RUN_DICT,
        )
    except CatalystError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=exc.to_dict(),
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"message": str(exc)},
        )
