"""Workbench endpoints — environment + session management over REST & WebSocket.

Three routers are exported:

- ``public_router`` — Public endpoints (capabilities). No auth required.
- ``router``        — REST endpoints (environment CRUD, session CRUD).
                      Registered with the standard auth dependency.
- ``ws_router``     — WebSocket endpoint. Handles auth via ``token`` query
                      param because HTTPBearer doesn't work over WebSocket.

All mutating/listing endpoints are scoped to the authenticated user so
that one user's environments and sessions are invisible to another.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from typing import Any

_HEARTBEAT_INTERVAL = 30.0
_HEARTBEAT_TIMEOUT = 35.0

from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    Query,
    WebSocket,
    WebSocketDisconnect,
    status,
)
from pydantic import BaseModel, Field, field_validator

from pycatalyst.api.dependencies.auth import get_current_user, verify_jwt
from pycatalyst.config.auth import is_auth_disabled
from pycatalyst.config.workbench import (
    get_workbench_scrollback_size,
    get_workbench_session_idle_timeout,
)
from pycatalyst.services.backends.base import ScrollbackBuffer
from pycatalyst.services.workbench_manager import workbench_manager

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/workbench")
public_router = APIRouter(prefix="/workbench")
ws_router = APIRouter(prefix="/workbench")

_READ_CHUNK = 4096


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _owner_from_user(user: dict[str, Any]) -> str:
    """Extract the owner identifier from the resolved user dict."""
    return str(user.get("username", "anonymous"))


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class CreateEnvironmentRequest(BaseModel):
    """Request to create an isolated environment."""

    backend: str = Field(default="venv", description="Backend type: venv or docker")
    profile: str | None = Field(
        default=None, description="Profile name for auto-installing packages"
    )


class EnvironmentInfoResponse(BaseModel):
    """Public representation of an environment."""

    env_id: str
    backend: str
    created_at: float
    session_count: int


class EnvironmentListResponse(BaseModel):
    """Wrapper for a list of environments."""

    environments: list[EnvironmentInfoResponse]


class CapabilitiesResponse(BaseModel):
    """Which backends are available on this server."""

    venv: bool
    docker: bool
    services: bool = False
    session_idle_timeout_seconds: int = 0


ALLOWED_COMMANDS: frozenset[str] = frozenset(
    {"bash", "sh", "zsh", "fish", "python", "ipython"}
)
"""Commands permitted for workbench terminal sessions."""


class CreateSessionRequest(BaseModel):
    """Request to spawn a new terminal session inside an environment."""

    command: str = Field(
        default="bash",
        description="Command to run: bash, sh, zsh, fish, python, or ipython",
    )
    cols: int = Field(default=80, ge=10, le=500)
    rows: int = Field(default=24, ge=5, le=200)

    @field_validator("command")
    @classmethod
    def _validate_command(cls, v: str) -> str:
        cmd = v.strip().lower()
        if cmd not in ALLOWED_COMMANDS:
            allowed = ", ".join(sorted(ALLOWED_COMMANDS))
            raise ValueError(
                f"Command {v!r} is not allowed. Permitted commands: {allowed}"
            )
        return cmd


class SessionInfoResponse(BaseModel):
    """Public representation of a terminal session."""

    session_id: str
    env_id: str
    command: str
    backend_type: str
    pid: int
    cols: int
    rows: int
    alive: bool


class SessionListResponse(BaseModel):
    """Wrapper for a list of sessions."""

    sessions: list[SessionInfoResponse]


class PackageInfo(BaseModel):
    """A single installed Python package."""

    name: str
    version: str


class PackageListResponse(BaseModel):
    """Wrapper for a list of packages."""

    packages: list[PackageInfo]


class InstallPackagesRequest(BaseModel):
    """Request to install packages into an environment."""

    packages: list[str] = Field(min_length=1, description="Package specs to install")
    editable: bool = Field(default=False, description="Install in editable mode (-e)")
    upgrade: bool = Field(default=False, description="Upgrade packages (--upgrade)")


class UninstallPackagesRequest(BaseModel):
    """Request to uninstall packages from an environment."""

    packages: list[str] = Field(min_length=1, description="Package names to uninstall")


class PackageOperationResponse(BaseModel):
    """Response after a package install/uninstall operation."""

    success: bool
    output: str
    packages: list[PackageInfo]


class ProfileInfoResponse(BaseModel):
    """Public representation of an environment setup profile."""

    name: str
    description: str
    backend: str
    packages: list[str]
    editable_packages: list[str]


class ProfileListResponse(BaseModel):
    """Wrapper for a list of profiles."""

    profiles: list[ProfileInfoResponse]


# ---------------------------------------------------------------------------
# Capabilities (public, no auth)
# ---------------------------------------------------------------------------


@public_router.get("/capabilities", response_model=CapabilitiesResponse)
async def get_capabilities() -> CapabilitiesResponse:
    """Return which backends (venv, docker) are available and idle timeout."""
    caps = workbench_manager.capabilities()
    return CapabilitiesResponse(
        **caps,
        session_idle_timeout_seconds=get_workbench_session_idle_timeout(),
    )


@public_router.get("/profiles", response_model=ProfileListResponse)
async def get_profiles() -> ProfileListResponse:
    """Return available environment setup profiles."""
    from pycatalyst.services.profiles import list_profiles

    profiles = list_profiles()
    return ProfileListResponse(
        profiles=[
            ProfileInfoResponse(
                name=p.name,
                description=p.description,
                backend=p.backend,
                packages=p.packages,
                editable_packages=p.editable_packages,
            )
            for p in profiles
        ]
    )


# ---------------------------------------------------------------------------
# Environment CRUD (scoped to current user)
# ---------------------------------------------------------------------------


@router.post("/environments", response_model=EnvironmentInfoResponse, status_code=201)
async def create_environment(
    request: CreateEnvironmentRequest,
    user: dict[str, Any] = Depends(get_current_user),
) -> EnvironmentInfoResponse:
    """Create a new isolated environment for the current user."""
    owner = _owner_from_user(user)
    try:
        info = await workbench_manager.create_environment(
            request.backend,
            owner=owner,
            profile=request.profile,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))
    except RuntimeError as exc:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS, detail=str(exc)
        )

    return EnvironmentInfoResponse(
        env_id=info.env_id,
        backend=info.backend_type,
        created_at=info.created_at,
        session_count=0,
    )


@router.get("/environments", response_model=EnvironmentListResponse)
async def list_environments(
    user: dict[str, Any] = Depends(get_current_user),
) -> EnvironmentListResponse:
    """List environments owned by the current user."""
    owner = _owner_from_user(user)
    items = workbench_manager.list_environments(owner=owner)
    return EnvironmentListResponse(
        environments=[EnvironmentInfoResponse(**e) for e in items]
    )


@router.delete("/environments/{env_id}", status_code=204)
async def destroy_environment(
    env_id: str,
    user: dict[str, Any] = Depends(get_current_user),
) -> None:
    """Destroy an environment owned by the current user."""
    owner = _owner_from_user(user)
    try:
        await workbench_manager.destroy_environment(env_id, owner=owner)
    except ValueError:
        raise HTTPException(status_code=404, detail="Environment not found")


@router.get("/environments/{env_id}/packages", response_model=PackageListResponse)
async def list_packages(
    env_id: str,
    user: dict[str, Any] = Depends(get_current_user),
) -> PackageListResponse:
    """List Python packages in an environment owned by the current user."""
    owner = _owner_from_user(user)
    try:
        pkgs = await workbench_manager.list_packages(env_id, owner=owner)
    except ValueError:
        raise HTTPException(status_code=404, detail="Environment not found")

    return PackageListResponse(
        packages=[
            PackageInfo(name=p.get("name", ""), version=p.get("version", ""))
            for p in pkgs
        ]
    )


@router.post(
    "/environments/{env_id}/packages/install",
    response_model=PackageOperationResponse,
)
async def install_packages(
    env_id: str,
    request: InstallPackagesRequest,
    user: dict[str, Any] = Depends(get_current_user),
) -> PackageOperationResponse:
    """Install packages into an environment owned by the current user."""
    owner = _owner_from_user(user)
    try:
        result = await workbench_manager.install_packages(
            env_id,
            request.packages,
            editable=request.editable,
            upgrade=request.upgrade,
            owner=owner,
        )
    except ValueError:
        raise HTTPException(status_code=404, detail="Environment not found")
    except RuntimeError as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(exc)
        )

    return PackageOperationResponse(
        success=result["success"],
        output=result["output"],
        packages=[
            PackageInfo(name=p.get("name", ""), version=p.get("version", ""))
            for p in result.get("packages", [])
        ],
    )


@router.post(
    "/environments/{env_id}/packages/uninstall",
    response_model=PackageOperationResponse,
)
async def uninstall_packages(
    env_id: str,
    request: UninstallPackagesRequest,
    user: dict[str, Any] = Depends(get_current_user),
) -> PackageOperationResponse:
    """Uninstall packages from an environment owned by the current user."""
    owner = _owner_from_user(user)
    try:
        result = await workbench_manager.uninstall_packages(
            env_id,
            request.packages,
            owner=owner,
        )
    except ValueError:
        raise HTTPException(status_code=404, detail="Environment not found")
    except RuntimeError as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(exc)
        )

    return PackageOperationResponse(
        success=result["success"],
        output=result["output"],
        packages=[
            PackageInfo(name=p.get("name", ""), version=p.get("version", ""))
            for p in result.get("packages", [])
        ],
    )


# ---------------------------------------------------------------------------
# Session CRUD (scoped to current user)
# ---------------------------------------------------------------------------


@router.post(
    "/environments/{env_id}/sessions",
    response_model=SessionInfoResponse,
    status_code=201,
)
async def create_session(
    env_id: str,
    request: CreateSessionRequest,
    user: dict[str, Any] = Depends(get_current_user),
) -> SessionInfoResponse:
    """Spawn a terminal session in an environment owned by the current user."""
    owner = _owner_from_user(user)
    try:
        handle = await workbench_manager.spawn_session(
            env_id=env_id,
            command=request.command,
            cols=request.cols,
            rows=request.rows,
            owner=owner,
        )
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except RuntimeError as exc:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS, detail=str(exc)
        )

    return SessionInfoResponse(
        session_id=handle.session_id,
        env_id=handle.env_id,
        command=handle.command,
        backend_type=handle.backend_type,
        pid=handle.pid,
        cols=handle.cols,
        rows=handle.rows,
        alive=handle.is_alive(),
    )


@router.get("/sessions", response_model=SessionListResponse)
async def list_sessions(
    env_id: str | None = Query(default=None),
    user: dict[str, Any] = Depends(get_current_user),
) -> SessionListResponse:
    """List sessions visible to the current user."""
    owner = _owner_from_user(user)
    items = workbench_manager.list_sessions(env_id=env_id, owner=owner)
    return SessionListResponse(sessions=[SessionInfoResponse(**s) for s in items])


@router.delete("/sessions/{session_id}", status_code=204)
async def delete_session(
    session_id: str,
    user: dict[str, Any] = Depends(get_current_user),
) -> None:
    """Kill a session owned by the current user."""
    owner = _owner_from_user(user)
    if not workbench_manager.kill_session(session_id, owner=owner):
        raise HTTPException(status_code=404, detail="Session not found")


@router.post("/sessions/{session_id}/refresh-env", status_code=200)
async def refresh_env(
    session_id: str,
    user: dict[str, Any] = Depends(get_current_user),
) -> dict[str, str]:
    """Send importlib.invalidate_caches() to a Python/IPython session."""
    owner = _owner_from_user(user)
    handle = workbench_manager.get_session(session_id, owner=owner)
    if handle is None:
        raise HTTPException(status_code=404, detail="Session not found")

    if handle.command not in ("python", "ipython"):
        raise HTTPException(
            status_code=400,
            detail="refresh-env is only supported for python/ipython sessions",
        )

    cmd = b"import importlib; importlib.invalidate_caches()\n"
    handle.write(cmd)
    return {"status": "ok", "detail": "importlib.invalidate_caches() sent"}


# ---------------------------------------------------------------------------
# WebSocket endpoint for terminal I/O
# ---------------------------------------------------------------------------


def _resolve_ws_owner(token: str | None) -> str:
    """Extract the username from a JWT token for WebSocket ownership.

    Returns ``"anonymous"`` when auth is disabled or the token is empty.
    """
    if is_auth_disabled():
        return "anonymous"
    if not token:
        return ""
    payload = verify_jwt(token)
    if payload is None:
        return ""
    return payload.get("sub") or payload.get("username") or ""


@ws_router.websocket("/ws/{session_id}")
async def terminal_ws(
    websocket: WebSocket,
    session_id: str,
    env_id: str = Query(default=""),
    command: str = Query(default=""),
    token: str = Query(default=""),
) -> None:
    """Bidirectional WebSocket bridge to a terminal session.

    Works identically for PTY-backed venv sessions and Docker exec sockets
    thanks to the unified ``SessionHandle`` abstraction.
    """
    owner = _resolve_ws_owner(token)
    if not owner:
        await websocket.close(code=1008, reason="Unauthorized")
        return

    await websocket.accept()

    handle = workbench_manager.get_session(session_id, owner=owner)

    if handle is None and env_id and command:
        if command not in ALLOWED_COMMANDS:
            await websocket.close(code=1008, reason="Command not allowed")
            return
        try:
            handle = await workbench_manager.spawn_session(
                env_id=env_id,
                command=command,
                cols=80,
                rows=24,
                owner=owner,
            )
        except (ValueError, RuntimeError) as exc:
            await websocket.close(code=1008, reason=str(exc))
            return

    if handle is None:
        await websocket.close(code=1008, reason="Session not found")
        return

    # --- Scrollback buffer: get-or-create on the session handle ----------
    scrollback_size = get_workbench_scrollback_size()
    scrollback: ScrollbackBuffer | None = None
    if scrollback_size > 0:
        scrollback = handle._extra.get("scrollback")
        if scrollback is None:
            scrollback = ScrollbackBuffer(scrollback_size)
            handle._extra["scrollback"] = scrollback
        # Replay buffered output before live streaming begins.
        replay = scrollback.read()
        if replay:
            await websocket.send_bytes(replay)

    loop = asyncio.get_event_loop()
    output_queue: asyncio.Queue[bytes] = asyncio.Queue()

    def _on_readable() -> None:
        try:
            data = os.read(handle.read_fd, _READ_CHUNK)
            if data:
                handle.touch()
                if scrollback is not None:
                    scrollback.write(data)
                output_queue.put_nowait(data)
            else:
                output_queue.put_nowait(b"")
        except OSError:
            output_queue.put_nowait(b"")

    try:
        loop.add_reader(handle.read_fd, _on_readable)
    except Exception:
        await websocket.close(code=1011, reason="Failed to attach to session")
        return

    last_pong: list[float] = [time.monotonic()]

    async def _send_output() -> None:
        """Forward PTY output to WebSocket."""
        try:
            while True:
                data = await output_queue.get()
                if not data:
                    break
                await websocket.send_bytes(data)
        except WebSocketDisconnect:
            pass
        except Exception:
            logger.exception(
                "Error in WebSocket send loop for session %s",
                session_id,
            )

    async def _recv_input() -> None:
        """Forward WebSocket input to PTY."""
        try:
            while True:
                message = await websocket.receive()
                if message.get("type") == "websocket.disconnect":
                    break

                raw = message.get("bytes") or (message.get("text") or "").encode(
                    "utf-8"
                )
                if not raw:
                    continue

                try:
                    ctrl = json.loads(raw)
                    if isinstance(ctrl, dict):
                        if ctrl.get("type") == "pong":
                            last_pong[0] = time.monotonic()
                            continue
                        if ctrl.get("type") == "resize":
                            handle.resize(
                                int(ctrl.get("cols", handle.cols)),
                                int(ctrl.get("rows", handle.rows)),
                            )
                            continue
                except (json.JSONDecodeError, ValueError):
                    pass

                handle.touch()
                handle.write(raw)
        except WebSocketDisconnect:
            pass
        except Exception:
            logger.exception(
                "Error in WebSocket recv loop for session %s",
                session_id,
            )

    async def _heartbeat() -> None:
        """Send ping periodically; close if no pong within timeout."""
        while True:
            await asyncio.sleep(_HEARTBEAT_INTERVAL)
            try:
                await websocket.send_json({"type": "ping"})
            except Exception:
                return
            if time.monotonic() - last_pong[0] > _HEARTBEAT_TIMEOUT:
                handle.close_reason = "Connection idle"
                try:
                    await websocket.close(code=1000, reason="Connection idle")
                except Exception:
                    pass
                return

    send_task = asyncio.create_task(_send_output())
    recv_task = asyncio.create_task(_recv_input())
    heartbeat_task = asyncio.create_task(_heartbeat())

    try:
        _done, pending = await asyncio.wait(
            [send_task, recv_task, heartbeat_task],
            return_when=asyncio.FIRST_COMPLETED,
        )
        for task in pending:
            task.cancel()
    finally:
        try:
            loop.remove_reader(handle.read_fd)
        except Exception:
            pass
        try:
            reason = getattr(handle, "close_reason", None) or "Session ended"
            await websocket.close(code=1000, reason=reason)
        except Exception:
            pass
