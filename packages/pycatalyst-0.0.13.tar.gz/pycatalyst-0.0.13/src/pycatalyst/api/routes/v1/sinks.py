"""Sink discovery and test-connection endpoints."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, Field

router = APIRouter()


class SinkTypeInfo(BaseModel):
    """Metadata about an available sink type."""

    type: str
    description: str
    config_schema: dict[str, Any] = Field(default_factory=dict)
    requires_extra: str | None = None
    available: bool = True


class SinkTypesResponse(BaseModel):
    """Response listing all sink types."""

    sinks: list[SinkTypeInfo]


class TestConnectionRequest(BaseModel):
    """Request to test a sink connection."""

    type: str
    config: dict[str, Any] = Field(default_factory=dict)


class TestConnectionResponse(BaseModel):
    """Result of a connection test."""

    success: bool
    message: str


def _check_import(module: str) -> bool:
    """Check if a module is importable."""
    try:
        __import__(module)
        return True
    except ImportError:
        return False


_SINK_TYPES: list[SinkTypeInfo] = [
    SinkTypeInfo(
        type="memory",
        description="In-memory buffer (no external destination)",
        config_schema={},
    ),
    SinkTypeInfo(
        type="console",
        description="Print to stdout (CLI debugging)",
        config_schema={
            "type": "object",
            "properties": {
                "format": {
                    "type": "string",
                    "enum": ["json", "ndjson", "table"],
                    "default": "json",
                },
            },
        },
    ),
    SinkTypeInfo(
        type="file",
        description="Write to a local file (JSON, CSV, or YAML)",
        config_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Output file path"},
                "format": {
                    "type": "string",
                    "enum": ["json", "csv", "yaml"],
                },
                "append": {"type": "boolean", "default": False},
            },
            "required": ["path"],
        },
    ),
    SinkTypeInfo(
        type="http",
        description="POST records to an HTTP endpoint",
        config_schema={
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "Target URL"},
                "method": {
                    "type": "string",
                    "enum": ["POST", "PUT", "PATCH"],
                    "default": "POST",
                },
                "headers": {
                    "type": "object",
                    "additionalProperties": {"type": "string"},
                },
                "batch_size": {"type": "integer", "default": 0},
                "timeout": {"type": "number", "default": 30.0},
                "auth_token": {"type": "string"},
            },
            "required": ["url"],
        },
        requires_extra="pip install pycatalyst[http]",
    ),
    SinkTypeInfo(
        type="database",
        description="Insert into a SQL database via SQLAlchemy",
        config_schema={
            "type": "object",
            "properties": {
                "connection_url": {
                    "type": "string",
                    "description": "SQLAlchemy connection URL",
                },
                "table_name": {"type": "string"},
                "batch_size": {"type": "integer", "default": 0},
                "if_exists": {
                    "type": "string",
                    "enum": ["append", "replace", "fail"],
                    "default": "append",
                },
            },
            "required": ["connection_url", "table_name"],
        },
        requires_extra="pip install pycatalyst[db]",
    ),
    SinkTypeInfo(
        type="kafka",
        description="Publish records to a Kafka topic",
        config_schema={
            "type": "object",
            "properties": {
                "bootstrap_servers": {"type": "string"},
                "topic": {"type": "string"},
                "key_field": {"type": "string"},
                "flush_timeout": {"type": "number", "default": 10.0},
            },
            "required": ["bootstrap_servers", "topic"],
        },
        requires_extra="pip install pycatalyst[kafka]",
    ),
    SinkTypeInfo(
        type="rabbitmq",
        description="Publish records to a RabbitMQ exchange",
        config_schema={
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "AMQP URL"},
                "exchange": {"type": "string", "default": ""},
                "routing_key": {"type": "string", "default": ""},
                "queue": {"type": "string"},
                "declare_queue": {"type": "boolean", "default": True},
            },
            "required": ["url"],
        },
        requires_extra="pip install pycatalyst[rabbitmq]",
    ),
    SinkTypeInfo(
        type="s3",
        description="Write to an S3 bucket (or S3-compatible storage)",
        config_schema={
            "type": "object",
            "properties": {
                "bucket": {"type": "string"},
                "key": {"type": "string", "description": "S3 object key"},
                "format": {
                    "type": "string",
                    "enum": ["json", "ndjson", "csv"],
                    "default": "json",
                },
                "region": {"type": "string"},
                "endpoint_url": {
                    "type": "string",
                    "description": "Custom endpoint (e.g. MinIO)",
                },
            },
            "required": ["bucket", "key"],
        },
        requires_extra="pip install pycatalyst[s3]",
    ),
]

# Map of optional extras to their import check module
_EXTRA_CHECK: dict[str, str] = {
    "http": "httpx",
    "database": "sqlalchemy",
    "kafka": "confluent_kafka",
    "rabbitmq": "pika",
    "s3": "boto3",
}


@router.get("/sinks/types", response_model=SinkTypesResponse)
async def list_sink_types() -> SinkTypesResponse:
    """List all available sink types with their config schemas."""
    result: list[SinkTypeInfo] = []
    for info in _SINK_TYPES:
        check_module = _EXTRA_CHECK.get(info.type)
        available = _check_import(check_module) if check_module else True
        result.append(
            SinkTypeInfo(
                type=info.type,
                description=info.description,
                config_schema=info.config_schema,
                requires_extra=info.requires_extra,
                available=available,
            )
        )
    return SinkTypesResponse(sinks=result)


@router.post(
    "/sinks/test-connection",
    response_model=TestConnectionResponse,
)
async def test_sink_connection(
    request: TestConnectionRequest,
) -> TestConnectionResponse:
    """Test whether a sink is reachable without sending data.

    Performs basic validation and, where possible, connection checks.
    """
    sink_type = request.type.lower()

    if sink_type == "memory":
        return TestConnectionResponse(
            success=True, message="Memory sink is always available"
        )

    if sink_type == "console":
        return TestConnectionResponse(
            success=True, message="Console sink is always available"
        )

    if sink_type == "kafka":
        check_module = _EXTRA_CHECK.get("kafka")
        if check_module and not _check_import(check_module):
            return TestConnectionResponse(
                success=False,
                message="confluent-kafka not installed",
            )
        bootstrap = request.config.get("bootstrap_servers")
        if not bootstrap:
            return TestConnectionResponse(
                success=False,
                message="bootstrap_servers is required",
            )
        return TestConnectionResponse(
            success=True,
            message=f"Kafka config valid (bootstrap: {bootstrap})",
        )

    if sink_type == "s3":
        if not _check_import("boto3"):
            return TestConnectionResponse(success=False, message="boto3 not installed")
        bucket = request.config.get("bucket")
        key = request.config.get("key")
        if not bucket or not key:
            return TestConnectionResponse(
                success=False,
                message="bucket and key are required",
            )
        return TestConnectionResponse(
            success=True,
            message=f"S3 config valid (bucket: {bucket}, key: {key})",
        )

    if sink_type == "file":
        path = request.config.get("path")
        if not path:
            return TestConnectionResponse(success=False, message="path is required")
        return TestConnectionResponse(
            success=True,
            message=f"File config valid (path: {path})",
        )

    if sink_type == "http":
        url = request.config.get("url")
        if not url:
            return TestConnectionResponse(success=False, message="url is required")
        return TestConnectionResponse(
            success=True,
            message=f"HTTP config valid (url: {url})",
        )

    if sink_type == "database":
        conn_url = request.config.get("connection_url")
        table = request.config.get("table_name")
        if not conn_url or not table:
            return TestConnectionResponse(
                success=False,
                message="connection_url and table_name are required",
            )
        return TestConnectionResponse(
            success=True,
            message=f"Database config valid (table: {table})",
        )

    if sink_type == "rabbitmq":
        url = request.config.get("url")
        if not url:
            return TestConnectionResponse(success=False, message="url is required")
        return TestConnectionResponse(
            success=True,
            message=f"RabbitMQ config valid (url: {url})",
        )

    raise HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail={"message": f"Unknown sink type: {sink_type!r}"},
    )
