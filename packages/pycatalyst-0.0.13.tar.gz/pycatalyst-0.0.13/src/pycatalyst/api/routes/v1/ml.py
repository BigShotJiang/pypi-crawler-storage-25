"""ML experiment endpoints for run + saved model management."""

from __future__ import annotations

import asyncio
import logging
import tempfile
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, Literal

import yaml
from fastapi import APIRouter, HTTPException, Response, status
from pydantic import BaseModel, Field

from pycatalyst.catalyst_store import (
    MongoDBCatalystStore,
    PostgresCatalystStore,
    SQLiteCatalystStore,
)
from pycatalyst.catalyst_store.client import CatalystStoreClient
from pycatalyst.db.config import get_db_url
from pycatalyst.ml.run import run_experiment

router = APIRouter()
logger = logging.getLogger(__name__)


class MlRunRequest(BaseModel):
    """Request body for running an ML experiment."""

    config: str = Field(..., description="Experiment config as YAML string")


class MlRunResponse(BaseModel):
    """Response from running an ML experiment. Mirrors ExperimentResult."""

    name: str
    backend: str
    metrics: dict[str, float] = Field(default_factory=dict)
    artifacts: dict[str, str] = Field(default_factory=dict)
    training_history: list[dict] = Field(default_factory=list)
    duration_seconds: float = 0.0
    persisted_model_id: str | None = None
    persisted_artifact_count: int = 0


class MlModelSummaryResponse(BaseModel):
    """Summary row for a saved model run."""

    id: str
    name: str
    backend: str
    status: str | None = None
    duration_seconds: float | None = None
    timestamp: datetime | None = None
    metrics: dict[str, Any] = Field(default_factory=dict)
    artifact_names: list[str] = Field(default_factory=list)


class MlModelDetailResponse(MlModelSummaryResponse):
    """Detailed saved model payload."""

    config: dict[str, Any] | None = None
    training_history: list[dict[str, Any]] = Field(default_factory=list)


class MlModelListResponse(BaseModel):
    """Collection response for saved models."""

    models: list[MlModelSummaryResponse] = Field(default_factory=list)
    total: int = 0
    limit: int = 25
    offset: int = 0
    sort_by: str = "timestamp"
    sort_order: str = "desc"


class MlArtifactListResponse(BaseModel):
    """Collection response for model artifact names."""

    model_id: str
    artifact_names: list[str] = Field(default_factory=list)


def _build_store() -> CatalystStoreClient:
    """Build and connect a configured catalyst store client."""
    db_url = get_db_url(required=False) or get_db_url(required=True)
    if db_url.startswith("sqlite://"):
        if SQLiteCatalystStore is None:
            raise RuntimeError("SQLite catalyst store is unavailable.")
        store = SQLiteCatalystStore(db_url)
        store.connect(validate_schema_on_connect=True, auto_initialize=False)
        return store
    if db_url.startswith(("postgresql://", "postgres://")):
        if PostgresCatalystStore is None:
            raise RuntimeError("PostgreSQL catalyst store is unavailable.")
        store = PostgresCatalystStore(db_url)
        store.connect(validate_schema_on_connect=True, auto_initialize=False)
        return store
    if db_url.startswith(("mongodb://", "mongodb+srv://")):
        if MongoDBCatalystStore is None:
            raise RuntimeError("MongoDB catalyst store is unavailable.")
        store = MongoDBCatalystStore(db_url)
        store.connect(ensure_indexes=True)
        return store
    raise RuntimeError(f"Unsupported database URL scheme: {db_url!r}")


@contextmanager
def _connected_store() -> Any:
    """Yield a connected catalyst store and always disconnect."""
    store = _build_store()
    try:
        yield store
    finally:
        store.disconnect()


def _to_summary(raw: dict[str, Any]) -> MlModelSummaryResponse:
    """Map a raw experiment dict into API summary shape."""
    artifact_names = []
    artifacts = raw.get("artifacts")
    if isinstance(artifacts, dict):
        artifact_names = sorted(str(k) for k in artifacts.keys())
    timestamp = raw.get("timestamp")
    return MlModelSummaryResponse(
        id=str(raw.get("id", "")),
        name=str(raw.get("name", "")),
        backend=str(raw.get("backend", "")),
        status=str(raw["status"]) if raw.get("status") is not None else None,
        duration_seconds=(
            float(raw["duration_seconds"])
            if raw.get("duration_seconds") is not None
            else None
        ),
        timestamp=timestamp if isinstance(timestamp, datetime) else None,
        metrics=(raw.get("metrics") if isinstance(raw.get("metrics"), dict) else {}),
        artifact_names=artifact_names,
    )


def _get_model_or_404(store: CatalystStoreClient, model_id: str) -> dict[str, Any]:
    """Resolve one model by ID from store listing."""
    models = store.list_experiments()
    for model in models:
        if str(model.get("id", "")) == model_id:
            return model
    raise HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail={"message": f"Model {model_id!r} not found."},
    )


@router.post("/ml/run", response_model=MlRunResponse)
async def run_ml_experiment(request: MlRunRequest) -> MlRunResponse:
    """Run an ML experiment from YAML config and return the result.

    Writes config to a temporary file and calls stateless run_experiment() in a
    thread pool so the event loop is not blocked. Long-running training may
    hit timeouts; consider increasing gateway/worker timeouts for large jobs.
    """
    if not request.config.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="config must be a non-empty YAML string",
        )

    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            suffix=".yaml",
            delete=False,
            encoding="utf-8",
        ) as f:
            f.write(request.config)
            config_path = f.name

        try:
            result = await asyncio.to_thread(run_experiment, config_path)
        finally:
            Path(config_path).unlink(missing_ok=True)

        persisted_model_id: str | None = None
        persisted_artifact_count = 0
        try:
            raw_config = yaml.safe_load(request.config)
            if not isinstance(raw_config, dict):
                raw_config = {}
        except yaml.YAMLError:
            raw_config = {}

        try:
            with _connected_store() as store:
                persisted_model_id = store.store_experiment(
                    name=result.name,
                    backend=result.backend,
                    experiment={
                        "status": "completed",
                        "metrics": dict(result.metrics),
                        "artifacts": dict(result.artifacts),
                        "training_history": list(result.training_history),
                        "duration_seconds": result.duration_seconds,
                        "config": raw_config,
                        "timestamp": datetime.utcnow().isoformat(),
                    },
                )
                for artifact_name, artifact_path in result.artifacts.items():
                    path_obj = Path(str(artifact_path))
                    if not path_obj.exists() or not path_obj.is_file():
                        continue
                    store.store_artifact(
                        experiment_id=persisted_model_id,
                        name=str(artifact_name),
                        data=path_obj.read_bytes(),
                    )
                    persisted_artifact_count += 1
        except Exception as exc:
            logger.warning("Model persistence skipped due to store error: %s", exc)

        return MlRunResponse(
            name=result.name,
            backend=result.backend,
            metrics=dict(result.metrics),
            artifacts=dict(result.artifacts),
            training_history=list(result.training_history),
            duration_seconds=result.duration_seconds,
            persisted_model_id=persisted_model_id,
            persisted_artifact_count=persisted_artifact_count,
        )
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"message": str(exc)},
        ) from exc
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"message": str(exc)},
        ) from exc
    except ImportError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "message": str(exc),
                "hint": "Install the required ML extra (e.g. pycatalyst[ml-core], pycatalyst[ml-sklearn], pycatalyst[ml-llm])",
            },
        ) from exc


@router.get("/ml/models", response_model=MlModelListResponse)
async def list_ml_models(
    backend: str | None = None,
    status_filter: str | None = None,
    limit: int = 25,
    offset: int = 0,
    sort_by: Literal["timestamp", "name", "backend", "duration_seconds"] = "timestamp",
    sort_order: Literal["asc", "desc"] = "desc",
) -> MlModelListResponse:
    """List saved model runs."""
    if limit < 1 or limit > 200:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"message": "limit must be between 1 and 200."},
        )
    if offset < 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"message": "offset must be >= 0."},
        )

    try:
        with _connected_store() as store:
            models = store.list_experiments(
                backend=backend,
                status=status_filter,
            )
            summaries = [_to_summary(model) for model in models]
            reverse = sort_order == "desc"
            if sort_by == "timestamp":
                summaries.sort(
                    key=lambda item: item.timestamp or datetime.min,
                    reverse=reverse,
                )
            elif sort_by == "duration_seconds":
                summaries.sort(
                    key=lambda item: item.duration_seconds or 0.0,
                    reverse=reverse,
                )
            elif sort_by == "backend":
                summaries.sort(
                    key=lambda item: item.backend.lower(),
                    reverse=reverse,
                )
            else:
                summaries.sort(
                    key=lambda item: item.name.lower(),
                    reverse=reverse,
                )
            total = len(summaries)
            page = summaries[offset : offset + limit]
            return MlModelListResponse(
                models=page,
                total=total,
                limit=limit,
                offset=offset,
                sort_by=sort_by,
                sort_order=sort_order,
            )
    except RuntimeError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={"message": str(exc)},
        ) from exc


@router.get("/ml/models/{model_id}", response_model=MlModelDetailResponse)
async def get_ml_model(model_id: str) -> MlModelDetailResponse:
    """Get one saved model by id."""
    with _connected_store() as store:
        model = _get_model_or_404(store, model_id)
        summary = _to_summary(model)
        return MlModelDetailResponse(
            **summary.model_dump(),
            config=(
                model.get("config") if isinstance(model.get("config"), dict) else None
            ),
            training_history=(
                model.get("training_history")
                if isinstance(model.get("training_history"), list)
                else []
            ),
        )


@router.delete("/ml/models/{model_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_ml_model(model_id: str) -> Response:
    """Delete one saved model by id."""
    with _connected_store() as store:
        _get_model_or_404(store, model_id)
        deleted = store.delete_experiment(model_id)
        if not deleted:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={"message": f"Model {model_id!r} not found."},
            )
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.get(
    "/ml/models/{model_id}/artifacts",
    response_model=MlArtifactListResponse,
)
async def list_ml_model_artifacts(model_id: str) -> MlArtifactListResponse:
    """List artifact names for a saved model."""
    with _connected_store() as store:
        _get_model_or_404(store, model_id)
        artifact_names = sorted(store.list_artifacts(model_id))
        return MlArtifactListResponse(model_id=model_id, artifact_names=artifact_names)


@router.get("/ml/models/{model_id}/artifacts/{artifact_name:path}")
async def download_ml_model_artifact(model_id: str, artifact_name: str) -> Response:
    """Download one binary artifact for a saved model."""
    with _connected_store() as store:
        _get_model_or_404(store, model_id)
        payload = store.get_artifact(model_id, artifact_name)
        if payload is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={
                    "message": f"Artifact {artifact_name!r} not found for model {model_id!r}."
                },
            )
        return Response(
            content=payload,
            media_type="application/octet-stream",
            headers={"Content-Disposition": f'attachment; filename="{artifact_name}"'},
        )


@router.delete(
    "/ml/models/{model_id}/artifacts/{artifact_name:path}",
    status_code=status.HTTP_204_NO_CONTENT,
)
async def delete_ml_model_artifact(model_id: str, artifact_name: str) -> Response:
    """Delete one saved model artifact."""
    with _connected_store() as store:
        _get_model_or_404(store, model_id)
        deleted = store.delete_artifact(model_id, artifact_name)
        if not deleted:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={
                    "message": f"Artifact {artifact_name!r} not found for model {model_id!r}."
                },
            )
    return Response(status_code=status.HTTP_204_NO_CONTENT)
