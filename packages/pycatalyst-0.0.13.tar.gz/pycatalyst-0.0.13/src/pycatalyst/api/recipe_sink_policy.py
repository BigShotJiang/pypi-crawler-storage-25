"""Validate recipe sink dicts for API ``full`` mode (SSRF-safe HTTP, temp-only file)."""

from __future__ import annotations

import ipaddress
import tempfile
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from pycatalyst.config.recipes import get_recipe_http_host_suffix_allowlist
from pycatalyst.recipes.models import SinkConfig


def _blocked_host(hostname: str) -> bool:
    h = hostname.strip().lower().rstrip(".")
    if not h:
        return True
    if h == "localhost" or h.endswith(".localhost"):
        return True
    if h.endswith(".local"):
        return True
    if h.endswith(".internal"):
        return True
    try:
        ip = ipaddress.ip_address(h)
        return not ip.is_global
    except ValueError:
        pass
    return False


def _host_matches_allowlist(host: str, suffixes: list[str]) -> bool:
    host = host.lower().rstrip(".")
    for suf in suffixes:
        s = suf.lower().strip().lstrip(".")
        if not s:
            continue
        if host == s or host.endswith("." + s):
            return True
    return False


def _validate_http_config(config: dict[str, Any]) -> None:
    url = config.get("url")
    if not url or not isinstance(url, str):
        raise ValueError("HTTP sink requires a string 'url' in config")
    parsed = urlparse(url.strip())
    if parsed.scheme not in ("http", "https"):
        raise ValueError("HTTP sink URL must use http or https scheme")
    host = parsed.hostname
    if not host:
        raise ValueError("HTTP sink URL must include a hostname")
    if _blocked_host(host):
        raise ValueError(
            "HTTP sink URL must not target loopback, private, or link-local hosts"
        )
    allow = get_recipe_http_host_suffix_allowlist()
    if allow and not _host_matches_allowlist(host, allow):
        raise ValueError(
            "HTTP sink hostname does not match PYCATALYST_RECIPE_HTTP_ALLOW_HOST_SUFFIXES"
        )


def _validate_file_config(config: dict[str, Any]) -> None:
    path = config.get("path")
    if not path or not isinstance(path, str):
        raise ValueError("File sink requires a string 'path' in config")
    resolved = Path(path).expanduser().resolve()
    tmp_root = Path(tempfile.gettempdir()).resolve()
    try:
        resolved.relative_to(tmp_root)
    except ValueError as exc:
        raise ValueError(
            f"File sink path must be under the system temp directory ({tmp_root})"
        ) from exc


def validate_sink_for_full_mode(sink: dict[str, Any]) -> None:
    """Raise ValueError with a user-safe message if sink is not allowed."""
    model = SinkConfig.model_validate(sink)
    st = model.type.lower()
    cfg = dict(model.config)

    if st == "memory":
        return
    if st == "http":
        _validate_http_config(cfg)
        return
    if st == "file":
        _validate_file_config(cfg)
        return
    if st in ("database", "kafka", "rabbitmq", "s3", "console"):
        return
    raise ValueError(f"Unknown sink type: {model.type!r}")
