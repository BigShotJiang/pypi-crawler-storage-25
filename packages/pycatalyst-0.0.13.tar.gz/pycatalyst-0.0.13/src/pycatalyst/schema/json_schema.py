"""Convert JSON Schema documents to SchemaSpec.

Supports common JSON Schema types and constraints, mapping them
to PyCatalyst FieldSpec equivalents for data generation.
"""

from __future__ import annotations

import logging
from typing import Any

from pycatalyst._types import FieldConstraints, FieldSpec, FieldType, SchemaSpec
from pycatalyst.errors import SchemaError

logger = logging.getLogger(__name__)

# Mapping from JSON Schema type+format to FieldType
_TYPE_MAP: dict[str, FieldType] = {
    "string": FieldType.STRING,
    "integer": FieldType.INT,
    "number": FieldType.FLOAT,
    "boolean": FieldType.BOOL,
    "object": FieldType.OBJECT,
    "array": FieldType.ARRAY,
}

_FORMAT_MAP: dict[str, FieldType] = {
    "date": FieldType.DATE,
    "date-time": FieldType.DATETIME,
    "uuid": FieldType.UUID,
}


def from_json_schema(
    schema: dict[str, Any],
    name: str | None = None,
) -> SchemaSpec:
    """Convert a JSON Schema to a SchemaSpec.

    Args:
        schema: A JSON Schema document (dict).
        name: Schema name override. Defaults to schema's title or "unnamed".

    Returns:
        A SchemaSpec ready for data generation.

    Raises:
        SchemaError: If the schema is invalid or unsupported.
    """
    schema_name = name or schema.get("title", "unnamed")

    if schema.get("type") != "object":
        raise SchemaError(
            "Root JSON Schema must be type 'object'",
            context={"actual_type": schema.get("type")},
        )

    properties = schema.get("properties", {})
    required = set(schema.get("required", []))

    if not properties:
        raise SchemaError(
            f"JSON Schema '{schema_name}' has no properties",
        )

    fields: list[FieldSpec] = []
    for prop_name, prop_schema in properties.items():
        field = _convert_property(prop_name, prop_schema, prop_name in required)
        fields.append(field)

    return SchemaSpec(
        name=schema_name,
        fields=tuple(fields),
        description=schema.get("description", ""),
    )


def _convert_property(
    name: str,
    prop: dict[str, Any],
    required: bool,
) -> FieldSpec:
    """Convert a single JSON Schema property to a FieldSpec."""
    json_type = prop.get("type", "string")
    json_format = prop.get("format")

    # Check format first for date/datetime/uuid
    if json_format and json_format in _FORMAT_MAP:
        field_type = _FORMAT_MAP[json_format]
    elif json_type in _TYPE_MAP:
        field_type = _TYPE_MAP[json_type]
    else:
        logger.warning(
            "unsupported JSON Schema type '%s', defaulting to string", json_type
        )
        field_type = FieldType.STRING

    # Handle enum
    if "enum" in prop:
        field_type = FieldType.ENUM

    nullable = not required

    constraints = _extract_constraints(prop, field_type)

    # Handle nested objects
    children: tuple[FieldSpec, ...] = ()
    if field_type == FieldType.OBJECT:
        nested_props = prop.get("properties", {})
        nested_required = set(prop.get("required", []))
        children = tuple(
            _convert_property(k, v, k in nested_required)
            for k, v in nested_props.items()
        )

    # Handle arrays
    if field_type == FieldType.ARRAY:
        items = prop.get("items", {"type": "string"})
        item_field = _convert_property("item", items, True)
        children = (item_field,)

    return FieldSpec(
        name=name,
        type=field_type,
        nullable=nullable,
        constraints=constraints,
        children=children,
        description=prop.get("description", ""),
    )


def _extract_constraints(
    prop: dict[str, Any],
    field_type: FieldType,
) -> FieldConstraints | None:
    """Extract generation constraints from JSON Schema keywords."""
    kwargs: dict[str, Any] = {}

    # Numeric constraints
    if field_type in (FieldType.INT, FieldType.FLOAT):
        if "minimum" in prop:
            kwargs["min"] = prop["minimum"]
        if "maximum" in prop:
            kwargs["max"] = prop["maximum"]

    # String constraints
    if field_type == FieldType.STRING:
        if "minLength" in prop:
            kwargs["min"] = prop["minLength"]
        if "maxLength" in prop:
            kwargs["max"] = prop["maxLength"]
        if "pattern" in prop:
            kwargs["pattern"] = prop["pattern"]
        if "format" in prop:
            kwargs["format"] = prop["format"]

    # Enum choices
    if "enum" in prop:
        kwargs["choices"] = tuple(prop["enum"])

    # Array constraints
    if field_type == FieldType.ARRAY:
        if "minItems" in prop:
            kwargs["min_items"] = prop["minItems"]
        if "maxItems" in prop:
            kwargs["max_items"] = prop["maxItems"]

    if not kwargs:
        return None

    return FieldConstraints(**kwargs)
