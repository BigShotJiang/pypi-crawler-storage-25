"""Infer SchemaSpec from sample data.

Analyzes sample data (dicts, CSV, JSON) to produce a SchemaSpec
that can generate similar data. Optionally uses pandas for
file-based inference (requires the [inference] extra).
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

import yaml

from pycatalyst._types import FieldConstraints, FieldSpec, FieldType, SchemaSpec
from pycatalyst.errors import InferenceError

logger = logging.getLogger(__name__)

# Python type to FieldType mapping
_PYTHON_TYPE_MAP: dict[type, FieldType] = {
    str: FieldType.STRING,
    int: FieldType.INT,
    float: FieldType.FLOAT,
    bool: FieldType.BOOL,
}


def infer_from_records(
    records: list[dict[str, Any]],
    name: str = "inferred",
) -> SchemaSpec:
    """Infer a SchemaSpec from a list of record dicts.

    Analyzes all records to determine field types and constraints.

    Args:
        records: List of record dictionaries.
        name: Name for the inferred schema.

    Returns:
        An inferred SchemaSpec.

    Raises:
        InferenceError: If records are empty or cannot be analyzed.
    """
    if not records:
        raise InferenceError("Cannot infer schema from empty records")

    # Collect all field names across records
    all_keys: dict[str, list[Any]] = {}
    for record in records:
        if not isinstance(record, dict):
            raise InferenceError(
                "All records must be dicts",
                source_type="records",
            )
        for key, value in record.items():
            if key not in all_keys:
                all_keys[key] = []
            all_keys[key].append(value)

    fields: list[FieldSpec] = []
    for field_name, values in all_keys.items():
        field = _infer_field(field_name, values, len(records))
        fields.append(field)

    return SchemaSpec(name=name, fields=tuple(fields))


def infer_from_file(
    path: str | Path,
    name: str | None = None,
) -> SchemaSpec:
    """Infer a SchemaSpec from a data file (JSON or YAML).

    Args:
        path: Path to a JSON or YAML file containing a list of records.
        name: Schema name override. Defaults to the filename stem.

    Returns:
        An inferred SchemaSpec.

    Raises:
        InferenceError: If the file cannot be read or parsed.
    """
    filepath = Path(path)
    schema_name = name or filepath.stem

    if not filepath.exists():
        raise InferenceError(
            f"File not found: {filepath}",
            source_type=filepath.suffix.lstrip("."),
        )

    try:
        content = filepath.read_text(encoding="utf-8")
    except OSError as exc:
        raise InferenceError(
            f"Cannot read file: {exc}",
            source_type=filepath.suffix.lstrip("."),
        ) from exc

    suffix = filepath.suffix.lower()
    if suffix == ".json":
        try:
            data = json.loads(content)
        except json.JSONDecodeError as exc:
            raise InferenceError(f"Invalid JSON: {exc}", source_type="json") from exc
    elif suffix in (".yaml", ".yml"):
        try:
            data = yaml.safe_load(content)
        except yaml.YAMLError as exc:
            raise InferenceError(f"Invalid YAML: {exc}", source_type="yaml") from exc
    else:
        raise InferenceError(
            f"Unsupported file type: {suffix}. Use .json or .yaml",
            source_type=suffix.lstrip("."),
        )

    if not isinstance(data, list):
        raise InferenceError(
            "File must contain a JSON array / YAML list of records",
            source_type=suffix.lstrip("."),
        )

    return infer_from_records(data, name=schema_name)


def _infer_field(
    name: str,
    values: list[Any],
    total_records: int,
) -> FieldSpec:
    """Infer a FieldSpec from observed values."""
    non_null = [v for v in values if v is not None]
    null_count = len(values) - len(non_null)
    nullable = null_count > 0
    nullable_rate = null_count / total_records if nullable else 0.0

    if not non_null:
        # All nulls — default to string
        return FieldSpec(
            name=name,
            type=FieldType.STRING,
            nullable=True,
            nullable_rate=1.0,
        )

    field_type = _infer_type(non_null)
    constraints = _infer_constraints(non_null, field_type)

    return FieldSpec(
        name=name,
        type=field_type,
        nullable=nullable,
        nullable_rate=round(nullable_rate, 2),
        constraints=constraints,
    )


def _infer_type(values: list[Any]) -> FieldType:
    """Infer FieldType from a list of non-null values."""
    types = {type(v) for v in values}

    # Check bool before int (bool is subclass of int in Python)
    if types == {bool}:
        return FieldType.BOOL

    if types <= {int, bool}:
        # Mixed int/bool — treat as int
        return FieldType.INT

    if types <= {int, float}:
        return FieldType.FLOAT

    if types == {str}:
        return _infer_string_subtype(values)

    if types == {dict}:
        return FieldType.OBJECT

    if types == {list}:
        return FieldType.ARRAY

    # Mixed types — fallback to string
    return FieldType.STRING


def _infer_string_subtype(values: list[str]) -> FieldType:
    """Check if string values look like dates, UUIDs, etc."""
    import re

    uuid_pattern = re.compile(
        r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
        re.IGNORECASE,
    )
    date_pattern = re.compile(r"^\d{4}-\d{2}-\d{2}$")
    datetime_pattern = re.compile(r"^\d{4}-\d{2}-\d{2}T")

    sample = values[:20]

    if all(uuid_pattern.match(v) for v in sample):
        return FieldType.UUID
    if all(datetime_pattern.match(v) for v in sample):
        return FieldType.DATETIME
    if all(date_pattern.match(v) for v in sample):
        return FieldType.DATE

    # Check for enum-like (few unique values relative to count)
    unique = set(values)
    if len(unique) <= min(10, len(values) * 0.3):
        return FieldType.ENUM

    return FieldType.STRING


def _infer_constraints(
    values: list[Any],
    field_type: FieldType,
) -> FieldConstraints | None:
    """Infer constraints from observed values."""
    kwargs: dict[str, Any] = {}

    if field_type == FieldType.INT:
        int_vals = [int(v) for v in values if isinstance(v, int | float)]
        if int_vals:
            kwargs["min"] = min(int_vals)
            kwargs["max"] = max(int_vals)

    elif field_type == FieldType.FLOAT:
        float_vals = [float(v) for v in values if isinstance(v, int | float)]
        if float_vals:
            kwargs["min"] = min(float_vals)
            kwargs["max"] = max(float_vals)

    elif field_type == FieldType.STRING:
        str_vals = [str(v) for v in values]
        lengths = [len(s) for s in str_vals]
        if lengths:
            kwargs["min"] = min(lengths)
            kwargs["max"] = max(lengths)

    elif field_type == FieldType.ENUM:
        unique = sorted({str(v) for v in values})
        kwargs["choices"] = tuple(unique)

    if not kwargs:
        return None

    return FieldConstraints(**kwargs)
