"""Programmatic SchemaSpec builder.

Provides a fluent API for constructing SchemaSpec instances
without dealing with raw dataclasses directly.
"""

from __future__ import annotations

from typing import Any

from pycatalyst._types import (
    Distribution,
    FieldConstraints,
    FieldSpec,
    FieldType,
    SchemaSpec,
)


class SchemaBuilder:
    """Fluent builder for constructing SchemaSpec instances.

    Example::

        schema = (
            SchemaBuilder("orders")
            .add_uuid("order_id")
            .add_string("name", min_len=1, max_len=50)
            .add_int("quantity", min_val=1, max_val=10000)
            .add_float("price", min_val=0.01, max_val=99999.99, precision=2)
            .add_enum("side", choices=["buy", "sell"])
            .add_datetime("created_at")
            .build()
        )
    """

    def __init__(self, name: str, description: str = "") -> None:
        self._name = name
        self._description = description
        self._fields: list[FieldSpec] = []
        self._metadata: dict[str, Any] = {}

    def add_field(self, spec: FieldSpec) -> SchemaBuilder:
        """Add a pre-built FieldSpec.

        Args:
            spec: The field specification to add.

        Returns:
            Self for chaining.
        """
        self._fields.append(spec)
        return self

    def add_string(
        self,
        name: str,
        *,
        nullable: bool = False,
        min_len: int | None = None,
        max_len: int | None = None,
        pattern: str | None = None,
        format: str | None = None,
    ) -> SchemaBuilder:
        """Add a string field.

        Args:
            name: Field name.
            nullable: Whether the field can be None.
            min_len: Minimum string length.
            max_len: Maximum string length.
            pattern: Regex pattern constraint.
            format: Named format (email, url, phone).

        Returns:
            Self for chaining.
        """
        constraints = None
        if any(v is not None for v in (min_len, max_len, pattern, format)):
            constraints = FieldConstraints(
                min=min_len,
                max=max_len,
                pattern=pattern,
                format=format,
            )
        self._fields.append(
            FieldSpec(
                name=name,
                type=FieldType.STRING,
                nullable=nullable,
                constraints=constraints,
            )
        )
        return self

    def add_int(
        self,
        name: str,
        *,
        nullable: bool = False,
        min_val: int | None = None,
        max_val: int | None = None,
        distribution: Distribution | None = None,
        mean: float | None = None,
        std: float | None = None,
    ) -> SchemaBuilder:
        """Add an integer field.

        Args:
            name: Field name.
            nullable: Whether the field can be None.
            min_val: Minimum value.
            max_val: Maximum value.
            distribution: Statistical distribution.
            mean: Mean for normal distribution.
            std: Standard deviation for normal distribution.

        Returns:
            Self for chaining.
        """
        constraints = None
        if any(v is not None for v in (min_val, max_val, distribution, mean, std)):
            constraints = FieldConstraints(
                min=min_val,
                max=max_val,
                distribution=distribution,
                mean=mean,
                std=std,
            )
        self._fields.append(
            FieldSpec(
                name=name,
                type=FieldType.INT,
                nullable=nullable,
                constraints=constraints,
            )
        )
        return self

    def add_float(
        self,
        name: str,
        *,
        nullable: bool = False,
        min_val: float | None = None,
        max_val: float | None = None,
        precision: int | None = None,
        distribution: Distribution | None = None,
        mean: float | None = None,
        std: float | None = None,
    ) -> SchemaBuilder:
        """Add a float field.

        Args:
            name: Field name.
            nullable: Whether the field can be None.
            min_val: Minimum value.
            max_val: Maximum value.
            precision: Decimal precision.
            distribution: Statistical distribution.
            mean: Mean for distribution.
            std: Standard deviation for distribution.

        Returns:
            Self for chaining.
        """
        constraints = None
        if any(
            v is not None
            for v in (min_val, max_val, precision, distribution, mean, std)
        ):
            constraints = FieldConstraints(
                min=min_val,
                max=max_val,
                precision=precision,
                distribution=distribution,
                mean=mean,
                std=std,
            )
        self._fields.append(
            FieldSpec(
                name=name,
                type=FieldType.FLOAT,
                nullable=nullable,
                constraints=constraints,
            )
        )
        return self

    def add_bool(self, name: str, *, nullable: bool = False) -> SchemaBuilder:
        """Add a boolean field."""
        self._fields.append(
            FieldSpec(name=name, type=FieldType.BOOL, nullable=nullable)
        )
        return self

    def add_date(self, name: str, *, nullable: bool = False) -> SchemaBuilder:
        """Add a date field."""
        self._fields.append(
            FieldSpec(name=name, type=FieldType.DATE, nullable=nullable)
        )
        return self

    def add_datetime(self, name: str, *, nullable: bool = False) -> SchemaBuilder:
        """Add a datetime field."""
        self._fields.append(
            FieldSpec(name=name, type=FieldType.DATETIME, nullable=nullable)
        )
        return self

    def add_uuid(self, name: str, *, nullable: bool = False) -> SchemaBuilder:
        """Add a UUID field."""
        self._fields.append(
            FieldSpec(name=name, type=FieldType.UUID, nullable=nullable)
        )
        return self

    def add_enum(
        self,
        name: str,
        choices: list[Any],
        *,
        nullable: bool = False,
    ) -> SchemaBuilder:
        """Add an enum field with fixed choices.

        Args:
            name: Field name.
            choices: List of allowed values.
            nullable: Whether the field can be None.

        Returns:
            Self for chaining.
        """
        self._fields.append(
            FieldSpec(
                name=name,
                type=FieldType.ENUM,
                nullable=nullable,
                constraints=FieldConstraints(choices=tuple(choices)),
            )
        )
        return self

    def with_metadata(self, key: str, value: Any) -> SchemaBuilder:
        """Add metadata to the schema.

        Args:
            key: Metadata key.
            value: Metadata value.

        Returns:
            Self for chaining.
        """
        self._metadata[key] = value
        return self

    def build(self) -> SchemaSpec:
        """Build the SchemaSpec.

        Returns:
            The constructed SchemaSpec.

        Raises:
            ValueError: If no fields have been added.
        """
        return SchemaSpec(
            name=self._name,
            fields=tuple(self._fields),
            description=self._description,
            metadata=self._metadata,
        )
