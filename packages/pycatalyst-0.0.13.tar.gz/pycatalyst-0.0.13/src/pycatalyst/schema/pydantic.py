"""Convert Pydantic models to SchemaSpec.

Uses Pydantic v2's model_json_schema() to extract field information,
then converts to PyCatalyst SchemaSpec for data generation.
"""

from __future__ import annotations

import logging

from pycatalyst._types import SchemaSpec
from pycatalyst.errors import SchemaError
from pycatalyst.schema.json_schema import from_json_schema

logger = logging.getLogger(__name__)


def from_pydantic_model(
    model_class: type,
    name: str | None = None,
) -> SchemaSpec:
    """Convert a Pydantic model class to a SchemaSpec.

    Requires pydantic>=2.0.0 to be installed.

    Args:
        model_class: A Pydantic BaseModel subclass.
        name: Schema name override. Defaults to the model class name.

    Returns:
        A SchemaSpec derived from the model's field definitions.

    Raises:
        SchemaError: If the model cannot be converted.
    """
    try:
        from pydantic import BaseModel
    except ImportError:
        raise SchemaError(
            "pydantic is required for model conversion. "
            "Install with: pip install pycatalyst[api]"
        )

    if not isinstance(model_class, type) or not issubclass(model_class, BaseModel):
        raise SchemaError(
            f"Expected a Pydantic BaseModel subclass, got {type(model_class).__name__}",
        )

    schema_name = name or model_class.__name__

    try:
        json_schema = model_class.model_json_schema()
    except Exception as exc:
        raise SchemaError(
            f"Failed to extract JSON Schema from {model_class.__name__}: {exc}",
        ) from exc

    # Pydantic generates a valid JSON Schema, so delegate to json_schema converter
    return from_json_schema(json_schema, name=schema_name)
