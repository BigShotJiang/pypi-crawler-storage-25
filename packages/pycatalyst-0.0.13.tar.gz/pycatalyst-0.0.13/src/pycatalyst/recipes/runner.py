"""Recipe runner for end-to-end data generation and delivery.

Loads a recipe, builds a SchemaSpec, generates data, and sends
it to the configured sink. Supports multi-sink fan-out and
streaming batch delivery.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Iterator
from pathlib import Path
from typing import Any

from pycatalyst._types import FieldSpec, GenerationResult, SchemaSpec
from pycatalyst.generators.engine import GenerationEngine
from pycatalyst.recipes.loader import load_recipe, load_recipe_from_dict
from pycatalyst.recipes.models import RecipeConfig, SchemaFieldConfig
from pycatalyst.sinks.types import SinkResult

logger = logging.getLogger(__name__)


class RecipeRunner:
    """Executes a recipe end-to-end.

    Handles the full pipeline: load recipe → build schema →
    generate data → send to sink.
    """

    def __init__(self, engine: GenerationEngine | None = None) -> None:
        self._engine = engine or GenerationEngine()

    def run_file(self, path: str | Path) -> tuple[GenerationResult, SinkResult]:
        """Run a recipe from a YAML file.

        Args:
            path: Path to the recipe YAML file.

        Returns:
            Tuple of (GenerationResult, SinkResult).
        """
        config = load_recipe(path)
        return self._execute(config)

    def run_dict(self, data: dict[str, Any]) -> tuple[GenerationResult, SinkResult]:
        """Run a recipe from a dictionary.

        Args:
            data: Recipe configuration as a dict.

        Returns:
            Tuple of (GenerationResult, SinkResult).
        """
        config = load_recipe_from_dict(data)
        return self._execute(config)

    def run_streaming(
        self,
        config: RecipeConfig,
    ) -> Iterator[tuple[GenerationResult, SinkResult]]:
        """Run a recipe in streaming mode, yielding per-batch results.

        Generates records in batches of ``streaming.batch_size``,
        sinking each batch separately. Respects ``interval_ms``
        delay and ``duration_seconds`` time limit.

        Args:
            config: Validated recipe configuration with streaming enabled.

        Yields:
            Tuple of (GenerationResult, SinkResult) per batch.
        """
        _apply_profile(config)
        schema = _build_schema(config)
        sink = _build_sink(config)
        streaming = config.streaming

        total = streaming.max_records
        batch_sz = min(streaming.batch_size, total)
        interval_s = streaming.interval_ms / 1000.0 if streaming.interval_ms else 0
        start_wall = time.monotonic()
        sent = 0

        try:
            while sent < total:
                if (
                    streaming.duration_seconds is not None
                    and (time.monotonic() - start_wall) >= streaming.duration_seconds
                ):
                    break

                remaining = total - sent
                current_batch = min(batch_sz, remaining)
                gen_result = self._engine.generate(
                    schema,
                    count=current_batch,
                    seed=None,
                )
                metadata = {
                    "recipe_name": config.name,
                    "schema_name": schema.name,
                    "count": gen_result.count,
                    "batch_offset": sent,
                }
                sink_result = sink.send(list(gen_result.records), metadata)
                sent += gen_result.count
                yield gen_result, sink_result

                if interval_s > 0 and sent < total:
                    time.sleep(interval_s)
        finally:
            sink.close()

    def _execute(self, config: RecipeConfig) -> tuple[GenerationResult, SinkResult]:
        """Execute a validated recipe config."""
        _apply_profile(config)
        logger.info("running recipe '%s'", config.name)

        schema = _build_schema(config)
        gen_result = self._engine.generate(
            schema,
            count=config.generation.count,
            seed=config.generation.seed,
        )

        sink = _build_sink(config)
        metadata = {
            "recipe_name": config.name,
            "schema_name": schema.name,
            "count": gen_result.count,
        }
        sink_result = sink.send(list(gen_result.records), metadata)
        sink.close()

        logger.info(
            "recipe '%s' complete: %d records generated, %d sent",
            config.name,
            gen_result.count,
            sink_result.records_sent,
        )

        return gen_result, sink_result


def _build_schema(config: RecipeConfig) -> SchemaSpec:
    """Build a SchemaSpec from recipe config."""
    fields = tuple(_build_field(f) for f in config.schema_.fields)
    return SchemaSpec(
        name=config.name,
        fields=fields,
        description=config.description,
    )


def _build_field(field_config: SchemaFieldConfig) -> FieldSpec:
    """Convert a recipe field config to a FieldSpec."""
    config_dict: dict[str, Any] = {
        "name": field_config.name,
        "type": field_config.type,
        "nullable": field_config.nullable,
        "nullable_rate": field_config.nullable_rate,
        "description": field_config.description,
    }
    if field_config.constraints:
        config_dict["constraints"] = field_config.constraints
    if field_config.children:
        config_dict["children"] = [
            {
                "name": c.name,
                "type": c.type,
                "nullable": c.nullable,
                "constraints": c.constraints if c.constraints else None,
            }
            for c in field_config.children
        ]
    if field_config.quality:
        config_dict["quality"] = field_config.quality
    return FieldSpec.from_config(config_dict)


def _build_sink(config: RecipeConfig) -> Any:
    """Build a sink (or MultiSink) from recipe config."""
    from pycatalyst.sinks.factory import create_sink
    from pycatalyst.sinks.multi import MultiSink

    if config.sinks:
        sinks = [create_sink(sc.type, dict(sc.config)) for sc in config.sinks]
        return MultiSink(sinks)
    return create_sink(config.sink.type, dict(config.sink.config))


def _apply_profile(config: RecipeConfig) -> None:
    """Apply a named profile's defaults to a recipe config (in-place)."""
    if not config.profile:
        return
    from pycatalyst.recipes.profiles import get_profile

    profile = get_profile(config.profile)
    if profile is None:
        logger.warning("unknown profile '%s', ignoring", config.profile)
        return

    # Profile provides defaults; explicit recipe settings override.
    if config.generation.count == 10:  # default value
        config.generation.count = profile.generation.count
    if config.generation.seed is None and profile.generation.seed is not None:
        config.generation.seed = profile.generation.seed
    if profile.streaming and not config.streaming.enabled:
        config.streaming = profile.streaming
