"""Recipe loader with environment variable substitution.

Loads YAML recipe files, substitutes environment variables using
the ${VAR}, ${VAR:-default}, and ${VAR:?error} patterns (same as
pystator's ConfigLoader), and validates against the recipe schema.
"""

from __future__ import annotations

import logging
import os
import re
from pathlib import Path
from typing import Any

import yaml

from pycatalyst.errors import RecipeError
from pycatalyst.recipes.models import RecipeConfig
from pycatalyst.sinks.errors import SinkError

logger = logging.getLogger(__name__)

# Env var patterns:
#   ${VAR}          - required, error if missing
#   ${VAR:-default} - optional with default
#   ${VAR:?error}   - required with custom error message
_ENV_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::(-[^}]*|\?[^}]*))?\}")


def load_recipe(path: str | Path) -> RecipeConfig:
    """Load and validate a recipe from a YAML file.

    Performs environment variable substitution before validation.

    Args:
        path: Path to the recipe YAML file.

    Returns:
        A validated RecipeConfig.

    Raises:
        RecipeError: If the file cannot be loaded or is invalid.
    """
    filepath = Path(path)

    if not filepath.exists():
        raise RecipeError(
            f"Recipe file not found: {filepath}",
            path=str(filepath),
        )

    try:
        raw = filepath.read_text(encoding="utf-8")
    except OSError as exc:
        raise RecipeError(
            f"Cannot read recipe file: {exc}",
            path=str(filepath),
        ) from exc

    # Substitute env vars
    resolved = _substitute_env_vars(raw, str(filepath))

    try:
        data = yaml.safe_load(resolved)
    except yaml.YAMLError as exc:
        raise RecipeError(
            f"Invalid YAML in recipe: {exc}",
            path=str(filepath),
        ) from exc

    if not isinstance(data, dict):
        raise RecipeError(
            "Recipe must be a YAML mapping",
            path=str(filepath),
        )

    return _validate(data, str(filepath))


def load_recipe_from_dict(data: dict[str, Any]) -> RecipeConfig:
    """Load and validate a recipe from a dictionary.

    Args:
        data: Recipe configuration as a dict.

    Returns:
        A validated RecipeConfig.

    Raises:
        RecipeError: If the data is invalid.
    """
    return _validate(data, "<dict>")


def _validate(data: dict[str, Any], source: str) -> RecipeConfig:
    """Validate recipe data against the Pydantic model."""
    try:
        return RecipeConfig.model_validate(data)
    except SinkError:
        raise
    except Exception as exc:
        raise RecipeError(
            f"Invalid recipe: {exc}",
            recipe_name=data.get("name"),
            path=source,
        ) from exc


def _substitute_env_vars(content: str, source: str) -> str:
    """Replace ${VAR}, ${VAR:-default}, ${VAR:?msg} patterns."""

    def replacer(match: re.Match[str]) -> str:
        var_name = match.group(1)
        modifier = match.group(2)

        value = os.environ.get(var_name)

        if modifier is None:
            # ${VAR} - return value or keep original for YAML parsing
            return value if value is not None else match.group(0)

        if modifier.startswith("-"):
            # ${VAR:-default}
            default = modifier[1:]
            return value if value is not None else default

        if modifier.startswith("?"):
            # ${VAR:?error message}
            if value is None:
                error_msg = modifier[1:] or f"Required variable '{var_name}' is not set"
                raise RecipeError(
                    error_msg,
                    path=source,
                    context={"variable": var_name},
                )
            return value

        return match.group(0)

    return _ENV_PATTERN.sub(replacer, content)
