"""Pydantic models for recipe configuration.

Recipes are YAML files that declaratively describe what data to
generate, how to constrain it, and where to send it.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field, model_validator


class SchemaFieldConfig(BaseModel):
    """Configuration for a single field in a recipe schema."""

    name: str = Field(..., description="Field name")
    type: str = Field(..., description="Field type (string, int, float, etc.)")
    nullable: bool = Field(default=False, description="Whether field can be null")
    nullable_rate: float = Field(
        default=0.1, ge=0.0, le=1.0, description="Probability of null"
    )
    constraints: dict[str, Any] = Field(
        default_factory=dict, description="Generation constraints"
    )
    children: list[SchemaFieldConfig] = Field(
        default_factory=list, description="Child fields for object/array"
    )
    description: str = Field(default="", description="Field description")
    quality: dict[str, Any] = Field(
        default_factory=dict,
        description="Quality defect settings (invalid_rate, truncate_rate, etc.)",
    )


class SchemaConfig(BaseModel):
    """Schema section of a recipe."""

    fields: list[SchemaFieldConfig] = Field(
        ..., min_length=1, description="Field definitions"
    )


class GenerationConfig(BaseModel):
    """Generation settings section of a recipe."""

    count: int = Field(default=10, ge=1, description="Number of records")
    seed: int | None = Field(
        default=None, description="Random seed for reproducibility"
    )


class SinkConfig(BaseModel):
    """Sink (output target) section of a recipe."""

    type: str = Field(..., description="Sink type (memory, file, http)")
    config: dict[str, Any] = Field(
        default_factory=dict, description="Sink-specific configuration"
    )

    @model_validator(mode="after")
    def _validate_required_sink_keys(self) -> SinkConfig:
        from pycatalyst.sinks.factory import validate_sink_config

        validate_sink_config(self.type, dict(self.config))
        return self


class StreamingConfig(BaseModel):
    """Streaming generation settings (optional in a recipe).

    When ``enabled`` is True, the runner generates records in
    batches of ``batch_size``, sinking each batch separately with
    an optional ``interval_ms`` delay between them.
    """

    enabled: bool = Field(default=False, description="Enable streaming mode")
    max_records: int = Field(
        default=1000, ge=1, description="Total records to generate"
    )
    batch_size: int = Field(
        default=100, ge=1, description="Records per batch sent to sink"
    )
    interval_ms: int = Field(default=0, ge=0, description="Delay in ms between batches")
    duration_seconds: float | None = Field(
        default=None,
        description="Max duration in seconds (None = no time limit)",
    )


class RecipeConfig(BaseModel):
    """Complete recipe configuration.

    Represents a full YAML recipe file with schema, generation
    settings, and sink configuration.
    """

    name: str = Field(..., description="Recipe name")
    description: str = Field(default="", description="Recipe description")
    version: str = Field(default="1.0", description="Recipe version")
    schema_: SchemaConfig = Field(..., alias="schema", description="Schema definition")
    generation: GenerationConfig = Field(
        default_factory=GenerationConfig,
        description="Generation settings",
    )
    sink: SinkConfig = Field(
        default_factory=lambda: SinkConfig(type="memory"),
        description="Output sink",
    )
    sinks: list[SinkConfig] | None = Field(
        default=None,
        description="Multiple output sinks (overrides 'sink' when present)",
    )
    streaming: StreamingConfig = Field(
        default_factory=StreamingConfig,
        description="Streaming generation settings",
    )
    profile: str | None = Field(
        default=None,
        description="Named generation profile preset (e.g. 'realistic')",
    )

    model_config = {"populate_by_name": True}
