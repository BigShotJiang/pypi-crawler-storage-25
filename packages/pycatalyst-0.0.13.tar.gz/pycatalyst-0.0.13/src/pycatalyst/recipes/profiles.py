"""Built-in generation profiles for common data generation scenarios.

Profiles bundle generation and streaming settings into named presets
that can be referenced in recipes via ``profile: "name"``.
"""

from __future__ import annotations

from dataclasses import dataclass

from pycatalyst.recipes.models import GenerationConfig, StreamingConfig


@dataclass(frozen=True)
class GenerationProfile:
    """Named preset for generation parameters.

    Attributes:
        name: Profile identifier (e.g. ``"realistic"``).
        description: Human-readable description.
        generation: Default generation settings.
        streaming: Optional streaming settings override.
    """

    name: str
    description: str
    generation: GenerationConfig
    streaming: StreamingConfig | None = None


BUILTIN_PROFILES: dict[str, GenerationProfile] = {
    "quick-test": GenerationProfile(
        name="quick-test",
        description="Small batch for quick validation (10 records, seeded).",
        generation=GenerationConfig(count=10, seed=42),
    ),
    "realistic": GenerationProfile(
        name="realistic",
        description=("Medium batch simulating realistic data volume (1000 records)."),
        generation=GenerationConfig(count=1000),
    ),
    "high-volume": GenerationProfile(
        name="high-volume",
        description=("Large batch for volume testing (100K records)."),
        generation=GenerationConfig(count=100_000),
    ),
    "stress-test": GenerationProfile(
        name="stress-test",
        description=("Streaming stress test: 1M records in batches of 10K."),
        generation=GenerationConfig(count=1_000_000),
        streaming=StreamingConfig(
            enabled=True,
            max_records=1_000_000,
            batch_size=10_000,
            interval_ms=0,
        ),
    ),
}


def get_profile(name: str) -> GenerationProfile | None:
    """Look up a built-in profile by name.

    Args:
        name: Profile name (case-insensitive).

    Returns:
        The matching profile, or None if not found.
    """
    return BUILTIN_PROFILES.get(name.lower().strip())


def list_profiles() -> list[GenerationProfile]:
    """Return all available built-in profiles.

    Returns:
        List of GenerationProfile instances.
    """
    return list(BUILTIN_PROFILES.values())
