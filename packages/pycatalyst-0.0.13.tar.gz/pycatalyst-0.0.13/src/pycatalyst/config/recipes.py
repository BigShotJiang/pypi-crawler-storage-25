"""Recipe API policy: sink mode and optional HTTP host allowlist.

Env or pycatalyst.cfg [recipes]; keys match env names (e.g. PYCATALYST_RECIPE_SINK_MODE).
"""

from __future__ import annotations

import os
from configparser import ConfigParser
from typing import Literal

from pycatalyst.config.paths import find_config_file

RecipeSinkMode = Literal["memory", "full"]


def _cfg(section: str, key: str) -> str | None:
    cfg_path = find_config_file("pycatalyst.cfg")
    if not cfg_path:
        return None
    try:
        cfg = ConfigParser()
        cfg.read(cfg_path)
        if cfg.has_section(section):
            return cfg.get(section, key, fallback=None)
    except Exception:
        pass
    return None


def get_recipe_sink_mode() -> RecipeSinkMode:
    """Return whether recipe API may use configured sinks or memory only.

    Default ``memory`` (safe for production). Set ``full`` to allow file, http,
    database, kafka, and rabbitmq sinks from the API after validation.
    """
    raw = (
        (
            os.getenv("PYCATALYST_RECIPE_SINK_MODE")
            or _cfg("recipes", "PYCATALYST_RECIPE_SINK_MODE")
            or "memory"
        )
        .strip()
        .lower()
    )
    if raw == "full":
        return "full"
    return "memory"


def get_recipe_http_host_suffix_allowlist() -> list[str]:
    """Optional comma-separated host suffixes; when non-empty, HTTP sink URLs must match.

    Example: ``example.com,.mycompany.internal``. Empty list means only generic
    SSRF checks apply (no private/loopback hosts).
    """
    raw = (
        os.getenv("PYCATALYST_RECIPE_HTTP_ALLOW_HOST_SUFFIXES")
        or _cfg("recipes", "PYCATALYST_RECIPE_HTTP_ALLOW_HOST_SUFFIXES")
        or ""
    )
    if not raw.strip():
        return []
    return [s.strip() for s in raw.split(",") if s.strip()]
