"""AWS config for S3-backed data loading.

Precedence: environment variables override pycatalyst.cfg [aws].
"""

from __future__ import annotations

import os
from configparser import ConfigParser

from pycatalyst.config.paths import find_config_file


def _cfg(key: str) -> str | None:
    cfg_path = find_config_file("pycatalyst.cfg")
    if not cfg_path:
        return None
    try:
        parser = ConfigParser()
        parser.read(cfg_path)
        if parser.has_section("aws"):
            raw = parser.get("aws", key, fallback=None)
            if raw is not None and raw.strip():
                return raw.strip()
    except Exception:
        return None
    return None


def _env_or_cfg(env_key: str) -> str | None:
    value = os.getenv(env_key)
    if value is not None and value.strip():
        return value.strip()
    return _cfg(env_key)


def get_aws_access_key_id() -> str | None:
    return _env_or_cfg("AWS_ACCESS_KEY_ID")


def get_aws_secret_access_key() -> str | None:
    return _env_or_cfg("AWS_SECRET_ACCESS_KEY")


def get_aws_session_token() -> str | None:
    return _env_or_cfg("AWS_SESSION_TOKEN")


def get_aws_region() -> str | None:
    return _env_or_cfg("AWS_REGION") or _env_or_cfg("AWS_DEFAULT_REGION")


def get_aws_profile() -> str | None:
    return _env_or_cfg("AWS_PROFILE")


def get_aws_s3_endpoint_url() -> str | None:
    return _env_or_cfg("AWS_S3_ENDPOINT_URL")


def get_aws_s3_client_config() -> dict[str, str]:
    """Return resolved boto3 S3 client kwargs from env/cfg."""
    out: dict[str, str] = {}
    access_key = get_aws_access_key_id()
    secret_key = get_aws_secret_access_key()
    session_token = get_aws_session_token()
    region = get_aws_region()
    endpoint_url = get_aws_s3_endpoint_url()
    if access_key:
        out["aws_access_key_id"] = access_key
    if secret_key:
        out["aws_secret_access_key"] = secret_key
    if session_token:
        out["aws_session_token"] = session_token
    if region:
        out["region_name"] = region
    if endpoint_url:
        out["endpoint_url"] = endpoint_url
    return out


def has_explicit_aws_credentials() -> bool:
    return bool(get_aws_access_key_id() and get_aws_secret_access_key())
