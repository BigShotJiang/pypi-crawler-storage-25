"""Default local development ports (aligned with workspace PORTS.md)."""

from __future__ import annotations

UI_PORT = 3005
API_PORT = 8005
DOCS_PORT = 5005
