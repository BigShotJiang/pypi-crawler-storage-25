"""Artifact (model) storage configuration.

Where ML artifacts are stored: database (default) or S3.
Source of truth: environment variables override pycatalyst.cfg [artifact].
Same precedence as database URL, UI theme, etc.
"""

from __future__ import annotations

import os

from pycatalyst.config.paths import find_config_file

_ARTIFACT_STORE_ENV = "PYCATALYST_ARTIFACT_STORE"
_S3_BUCKET_ENV = "PYCATALYST_ARTIFACT_S3_BUCKET"
_S3_PREFIX_ENV = "PYCATALYST_ARTIFACT_S3_PREFIX"

_VALID_TYPES = ("database", "s3")
_DEFAULT_PREFIX = "artifacts/"


def _get_from_cfg(key: str) -> str | None:
    """Read a key from [artifact] in pycatalyst.cfg. Returns None if missing or invalid."""
    cfg = find_config_file("pycatalyst.cfg")
    if not cfg:
        return None
    try:
        from configparser import ConfigParser

        parser = ConfigParser()
        parser.read(cfg)
        if parser.has_section("artifact"):
            val = parser.get("artifact", key, fallback="")
            return val.strip() or None
    except Exception:
        pass
    return None


def get_artifact_store_type() -> str:
    """Return artifact store type: database or s3. Default database."""
    val = os.getenv(_ARTIFACT_STORE_ENV)
    if val and val.strip().lower() in _VALID_TYPES:
        return val.strip().lower()
    val = _get_from_cfg(_ARTIFACT_STORE_ENV)
    if val and val.strip().lower() in _VALID_TYPES:
        return val.strip().lower()
    return "database"


def get_artifact_s3_bucket() -> str | None:
    """Return S3 bucket for artifact storage, or None if not set."""
    val = os.getenv(_S3_BUCKET_ENV)
    if val and val.strip():
        return val.strip()
    val = _get_from_cfg(_S3_BUCKET_ENV)
    if val:
        return val.strip()
    return None


def get_artifact_s3_prefix() -> str:
    """Return S3 key prefix for artifacts. Default artifacts/."""
    val = os.getenv(_S3_PREFIX_ENV)
    if val is not None and str(val).strip():
        p = str(val).strip()
        return p if p.endswith("/") else p + "/"
    val = _get_from_cfg(_S3_PREFIX_ENV)
    if val and val.strip():
        p = val.strip()
        return p if p.endswith("/") else p + "/"
    return _DEFAULT_PREFIX
