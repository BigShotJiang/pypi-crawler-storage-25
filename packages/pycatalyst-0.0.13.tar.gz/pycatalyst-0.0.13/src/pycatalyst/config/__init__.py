"""PyCatalyst configuration utilities."""

from __future__ import annotations

from pycatalyst.config.api import get_api_url
from pycatalyst.config.auth import (
    get_auth_admin_group_claims,
    get_auth_admin_role_claims,
    get_auth_jwt_secret,
    get_auth_users,
    is_auth_disabled,
)
from pycatalyst.config.aws import (
    get_aws_access_key_id,
    get_aws_profile,
    get_aws_region,
    get_aws_s3_client_config,
    get_aws_s3_endpoint_url,
    get_aws_secret_access_key,
    get_aws_session_token,
    has_explicit_aws_credentials,
)
from pycatalyst.config.database import get_database_url, set_database_url
from pycatalyst.config.paths import find_config_file
from pycatalyst.config.recipes import get_recipe_sink_mode
from pycatalyst.config.ui import get_ui_app_name, get_ui_theme
from pycatalyst.config.workbench import (
    get_workbench_docker_image,
    get_workbench_docker_mem_limit,
    get_workbench_max_environments,
    get_workbench_max_sessions,
    get_workbench_shell,
    get_workbench_venv_dir,
)

__all__ = [
    "find_config_file",
    "get_api_url",
    "get_aws_access_key_id",
    "get_aws_profile",
    "get_aws_region",
    "get_aws_s3_client_config",
    "get_aws_s3_endpoint_url",
    "get_aws_secret_access_key",
    "get_aws_session_token",
    "get_auth_admin_group_claims",
    "get_auth_admin_role_claims",
    "get_auth_jwt_secret",
    "get_auth_users",
    "get_database_url",
    "get_recipe_sink_mode",
    "get_ui_app_name",
    "get_ui_theme",
    "get_workbench_docker_image",
    "get_workbench_docker_mem_limit",
    "get_workbench_max_environments",
    "get_workbench_max_sessions",
    "get_workbench_shell",
    "get_workbench_venv_dir",
    "has_explicit_aws_credentials",
    "is_auth_disabled",
    "set_database_url",
]
