"""Shared path-resolution helpers for PyCatalyst configuration files."""

from __future__ import annotations

from pathlib import Path

_CONFIG_FILENAME = "pycatalyst.cfg"
_MAX_PARENT_WALK = 5


def find_config_file(filename: str = _CONFIG_FILENAME) -> Path | None:
    """Locate a config file by searching standard locations.

    Search order:
        1. Current working directory
        2. ``~/.pycatalyst/``
        3. Package/project directory (directory containing the pycatalyst package)
        4. Project root (directory containing alembic.ini)
    """
    # 1. Current working directory
    cwd_path = Path.cwd() / filename
    if cwd_path.exists():
        return cwd_path

    # 2. User home directory
    home_path = Path.home() / ".pycatalyst" / filename
    if home_path.exists():
        return home_path

    # 3. Package/project directory
    try:
        import pycatalyst

        start = Path(pycatalyst.__file__).resolve().parent
        for _ in range(10):
            cand = start / filename
            if cand.exists():
                return cand
            parent = start.parent
            if parent == start:
                break
            start = parent
    except (ImportError, AttributeError):
        pass

    # 4. Project root (where alembic.ini typically is)
    current = Path.cwd()
    for _ in range(_MAX_PARENT_WALK):
        alembic_path = current / "alembic.ini"
        if alembic_path.exists():
            config_path = current / filename
            if config_path.exists():
                return config_path
        current = current.parent

    return None
