"""Field descriptor DSL for Python-first mock data generation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from pycatalyst._types import Distribution, FieldConstraints, FieldSpec, FieldType


@dataclass(frozen=True, slots=True)
class FieldDef:
    """A Python-first field definition.

    FieldDef is an ergonomic wrapper that can be converted to the core
    `FieldSpec` type used by `GenerationEngine`.
    """

    type: FieldType
    constraints: FieldConstraints | None = None
    nullable: bool = False
    nullable_rate: float = 0.1
    description: str = ""
    # For OBJECT, children is a sequence of (name, field) pairs.
    # For ARRAY, children contains a single ("item", field) pair.
    children: tuple[tuple[str, FieldDef], ...] = ()

    def to_spec(self, name: str) -> FieldSpec:
        children_specs = tuple(
            child.to_spec(child_name) for child_name, child in self.children
        )
        return FieldSpec(
            name=name,
            type=self.type,
            nullable=self.nullable,
            nullable_rate=self.nullable_rate,
            constraints=self.constraints,
            children=children_specs,
            description=self.description,
        )


def string(
    *,
    min_len: int | None = None,
    max_len: int | None = None,
    pattern: str | None = None,
    format: str | None = None,
    unique: bool = False,
    nullable: bool = False,
    nullable_rate: float = 0.1,
    description: str = "",
) -> FieldDef:
    constraints = None
    if any(v is not None for v in (min_len, max_len, pattern, format)) or unique:
        constraints = FieldConstraints(
            min=min_len,
            max=max_len,
            pattern=pattern,
            format=format,
            unique=unique,
        )
    return FieldDef(
        type=FieldType.STRING,
        constraints=constraints,
        nullable=nullable,
        nullable_rate=nullable_rate,
        description=description,
    )


def int_(
    *,
    min: int | None = None,
    max: int | None = None,
    distribution: Distribution | None = None,
    mean: float | None = None,
    std: float | None = None,
    multiple_of: int | None = None,
    exclusive_min: bool = False,
    exclusive_max: bool = False,
    unique: bool = False,
    nullable: bool = False,
    nullable_rate: float = 0.1,
    description: str = "",
) -> FieldDef:
    constraints = None
    if (
        any(v is not None for v in (min, max, distribution, mean, std, multiple_of))
        or exclusive_min
        or exclusive_max
        or unique
    ):
        constraints = FieldConstraints(
            min=min,
            max=max,
            distribution=distribution,
            mean=mean,
            std=std,
            multiple_of=multiple_of,
            exclusive_min=exclusive_min,
            exclusive_max=exclusive_max,
            unique=unique,
        )
    return FieldDef(
        type=FieldType.INT,
        constraints=constraints,
        nullable=nullable,
        nullable_rate=nullable_rate,
        description=description,
    )


def float_(
    *,
    min: float | None = None,
    max: float | None = None,
    precision: int | None = None,
    distribution: Distribution | None = None,
    mean: float | None = None,
    std: float | None = None,
    multiple_of: float | None = None,
    exclusive_min: bool = False,
    exclusive_max: bool = False,
    unique: bool = False,
    nullable: bool = False,
    nullable_rate: float = 0.1,
    description: str = "",
) -> FieldDef:
    constraints = None
    if (
        any(
            v is not None
            for v in (min, max, precision, distribution, mean, std, multiple_of)
        )
        or exclusive_min
        or exclusive_max
        or unique
    ):
        constraints = FieldConstraints(
            min=min,
            max=max,
            precision=precision,
            distribution=distribution,
            mean=mean,
            std=std,
            multiple_of=multiple_of,
            exclusive_min=exclusive_min,
            exclusive_max=exclusive_max,
            unique=unique,
        )
    return FieldDef(
        type=FieldType.FLOAT,
        constraints=constraints,
        nullable=nullable,
        nullable_rate=nullable_rate,
        description=description,
    )


def bool_(
    *,
    nullable: bool = False,
    nullable_rate: float = 0.1,
    description: str = "",
) -> FieldDef:
    return FieldDef(
        type=FieldType.BOOL,
        nullable=nullable,
        nullable_rate=nullable_rate,
        description=description,
    )


def date(
    *,
    nullable: bool = False,
    nullable_rate: float = 0.1,
    description: str = "",
) -> FieldDef:
    return FieldDef(
        type=FieldType.DATE,
        nullable=nullable,
        nullable_rate=nullable_rate,
        description=description,
    )


def datetime(
    *,
    nullable: bool = False,
    nullable_rate: float = 0.1,
    description: str = "",
) -> FieldDef:
    return FieldDef(
        type=FieldType.DATETIME,
        nullable=nullable,
        nullable_rate=nullable_rate,
        description=description,
    )


def uuid(
    *,
    nullable: bool = False,
    nullable_rate: float = 0.1,
    description: str = "",
) -> FieldDef:
    return FieldDef(
        type=FieldType.UUID,
        nullable=nullable,
        nullable_rate=nullable_rate,
        description=description,
    )


def enum(
    *choices: Any,
    nullable: bool = False,
    nullable_rate: float = 0.1,
    description: str = "",
) -> FieldDef:
    constraints = FieldConstraints(choices=tuple(choices))
    return FieldDef(
        type=FieldType.ENUM,
        constraints=constraints,
        nullable=nullable,
        nullable_rate=nullable_rate,
        description=description,
    )


def object_(
    **fields: FieldDef,
) -> FieldDef:
    # Children are stored in order of insertion (Python 3.7+ dict order).
    children = tuple((name, fields[name]) for name in fields)
    return FieldDef(
        type=FieldType.OBJECT,
        children=children,
    )


def array(
    item: FieldDef,
    *,
    min_items: int | None = None,
    max_items: int | None = None,
    nullable: bool = False,
    nullable_rate: float = 0.1,
) -> FieldDef:
    constraints = None
    if any(v is not None for v in (min_items, max_items)):
        constraints = FieldConstraints(min_items=min_items, max_items=max_items)
    return FieldDef(
        type=FieldType.ARRAY,
        constraints=constraints,
        nullable=nullable,
        nullable_rate=nullable_rate,
        children=(("item", item),),
    )
