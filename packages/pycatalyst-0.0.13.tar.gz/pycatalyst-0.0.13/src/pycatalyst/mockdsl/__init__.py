"""Python-first mock data DSL.

This module provides two ergonomic front-ends over the core generation engine:

- Model-class DSL (declare fields on a class)
- Fluent DSL (chain field definitions)
"""

from __future__ import annotations

from pycatalyst.mockdsl.fields import (
    array,
    bool_,
    date,
    datetime,
    enum,
    float_,
    int_,
    object_,
    string,
    uuid,
)
from pycatalyst.mockdsl.fluent import mock
from pycatalyst.mockdsl.model import MockModel

__all__ = [
    "MockModel",
    "array",
    "bool_",
    "date",
    "datetime",
    "enum",
    "float_",
    "int_",
    "mock",
    "object_",
    "string",
    "uuid",
]
