"""Model-class DSL for Python-first mock data generation."""

from __future__ import annotations

from collections.abc import Callable, Iterator
from dataclasses import is_dataclass
from typing import Any, Generic, TypeVar, overload

from pycatalyst._types import SchemaSpec
from pycatalyst.generators.engine import GenerationEngine
from pycatalyst.mockdsl.fields import FieldDef

T = TypeVar("T")


ReturnMapper = Callable[[dict[str, Any]], T]


def _apply_return_type(
    row: dict[str, Any],
    return_type: ReturnMapper[T] | type[T] | None,
) -> dict[str, Any] | T:
    if return_type is None:
        return row
    if callable(return_type) and not isinstance(return_type, type):
        return return_type(row)
    # `type[T]` case
    cls: type[T] = return_type  # type: ignore[assignment]
    if is_dataclass(cls):
        return cls(**row)  # type: ignore[call-arg]
    return cls(**row)  # type: ignore[call-arg]


class MockModelMeta(type):
    def __new__(mcls, name: str, bases: tuple[type, ...], namespace: dict[str, Any]):
        fields: list[tuple[str, FieldDef]] = []

        # Inherit fields from base classes first.
        for base in bases:
            base_fields = getattr(base, "__mock_fields__", ())
            for item in base_fields:
                fields.append(item)

        # Then add fields declared on this class (in definition order).
        for attr_name, value in namespace.items():
            if isinstance(value, FieldDef):
                fields.append((attr_name, value))

        namespace["__mock_fields__"] = tuple(fields)
        return super().__new__(mcls, name, bases, namespace)


class MockModel(Generic[T], metaclass=MockModelMeta):
    """Base class for model-style mock data generation."""

    __mock_fields__: tuple[tuple[str, FieldDef], ...]

    @classmethod
    def schema(cls, name: str | None = None) -> SchemaSpec:
        schema_name = name or cls.__name__
        fields = tuple(
            field.to_spec(field_name) for field_name, field in cls.__mock_fields__
        )
        return SchemaSpec(name=schema_name, fields=fields)

    @classmethod
    @overload
    def generate(
        cls,
        count: int,
        *,
        seed: int | None = None,
        return_type: None = None,
        schema_name: str | None = None,
    ) -> list[dict[str, Any]]: ...

    @classmethod
    @overload
    def generate(
        cls,
        count: int,
        *,
        seed: int | None = None,
        return_type: ReturnMapper[T] | type[T],
        schema_name: str | None = None,
    ) -> list[T]: ...

    @classmethod
    def generate(
        cls,
        count: int,
        *,
        seed: int | None = None,
        return_type: ReturnMapper[T] | type[T] | None = None,
        schema_name: str | None = None,
    ) -> list[dict[str, Any]] | list[T]:
        engine = GenerationEngine()
        schema = cls.schema(schema_name)
        result = engine.generate(schema, count=count, seed=seed)
        return [  # type: ignore[return-value]
            _apply_return_type(
                dict(row), return_type
            )  # ensure mutable dict for constructors
            for row in result.records
        ]

    @classmethod
    @overload
    def iter(
        cls,
        limit: int,
        *,
        seed: int | None = None,
        return_type: None = None,
        schema_name: str | None = None,
    ) -> Iterator[dict[str, Any]]: ...

    @classmethod
    @overload
    def iter(
        cls,
        limit: int,
        *,
        seed: int | None = None,
        return_type: ReturnMapper[T] | type[T],
        schema_name: str | None = None,
    ) -> Iterator[T]: ...

    @classmethod
    def iter(
        cls,
        limit: int,
        *,
        seed: int | None = None,
        return_type: ReturnMapper[T] | type[T] | None = None,
        schema_name: str | None = None,
    ) -> Iterator[dict[str, Any]] | Iterator[T]:
        engine = GenerationEngine()
        schema = cls.schema(schema_name)
        for row in engine.iter_records(schema, seed=seed, limit=limit):
            yield _apply_return_type(dict(row), return_type)  # type: ignore[misc]
