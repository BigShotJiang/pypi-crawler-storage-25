"""Fluent/functional DSL for Python-first mock data generation."""

from __future__ import annotations

from collections.abc import Callable, Iterator
from dataclasses import is_dataclass
from typing import Any, Generic, TypeVar, overload

from pycatalyst._types import SchemaSpec
from pycatalyst.generators.engine import GenerationEngine
from pycatalyst.mockdsl.fields import FieldDef

T = TypeVar("T")
ReturnMapper = Callable[[dict[str, Any]], T]


def _apply_return_type(
    row: dict[str, Any],
    return_type: ReturnMapper[T] | type[T] | None,
) -> dict[str, Any] | T:
    if return_type is None:
        return row
    if callable(return_type) and not isinstance(return_type, type):
        return return_type(row)
    cls: type[T] = return_type  # type: ignore[assignment]
    if is_dataclass(cls):
        return cls(**row)  # type: ignore[call-arg]
    return cls(**row)  # type: ignore[call-arg]


class MockBuilder(Generic[T]):
    def __init__(self, name: str = "mock") -> None:
        self._name = name
        self._fields: list[tuple[str, FieldDef]] = []

    def field(self, name: str, field: FieldDef) -> MockBuilder[T]:
        self._fields.append((name, field))
        return self

    def schema(self, name: str | None = None) -> SchemaSpec:
        schema_name = name or self._name
        fields = tuple(field.to_spec(field_name) for field_name, field in self._fields)
        return SchemaSpec(name=schema_name, fields=fields)

    @overload
    def generate(
        self,
        count: int,
        *,
        seed: int | None = None,
        return_type: None = None,
        schema_name: str | None = None,
    ) -> list[dict[str, Any]]: ...

    @overload
    def generate(
        self,
        count: int,
        *,
        seed: int | None = None,
        return_type: ReturnMapper[T] | type[T],
        schema_name: str | None = None,
    ) -> list[T]: ...

    def generate(
        self,
        count: int,
        *,
        seed: int | None = None,
        return_type: ReturnMapper[T] | type[T] | None = None,
        schema_name: str | None = None,
    ) -> list[dict[str, Any]] | list[T]:
        engine = GenerationEngine()
        schema = self.schema(schema_name)
        result = engine.generate(schema, count=count, seed=seed)
        return [  # type: ignore[return-value]
            _apply_return_type(dict(row), return_type) for row in result.records
        ]

    @overload
    def iter(
        self,
        limit: int,
        *,
        seed: int | None = None,
        return_type: None = None,
        schema_name: str | None = None,
    ) -> Iterator[dict[str, Any]]: ...

    @overload
    def iter(
        self,
        limit: int,
        *,
        seed: int | None = None,
        return_type: ReturnMapper[T] | type[T],
        schema_name: str | None = None,
    ) -> Iterator[T]: ...

    def iter(
        self,
        limit: int,
        *,
        seed: int | None = None,
        return_type: ReturnMapper[T] | type[T] | None = None,
        schema_name: str | None = None,
    ) -> Iterator[dict[str, Any]] | Iterator[T]:
        engine = GenerationEngine()
        schema = self.schema(schema_name)
        for row in engine.iter_records(schema, seed=seed, limit=limit):
            yield _apply_return_type(dict(row), return_type)  # type: ignore[misc]


def mock(name: str = "mock") -> MockBuilder[Any]:
    return MockBuilder(name=name)
