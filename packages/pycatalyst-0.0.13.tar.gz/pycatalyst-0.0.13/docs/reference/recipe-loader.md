# load_recipe

::: pycatalyst.recipes.loader.load_recipe
