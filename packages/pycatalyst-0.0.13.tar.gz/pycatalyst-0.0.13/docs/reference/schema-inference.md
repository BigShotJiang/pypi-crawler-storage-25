# Schema inference

::: pycatalyst.schema.inferrer.infer_from_records

::: pycatalyst.schema.inferrer.infer_from_file
