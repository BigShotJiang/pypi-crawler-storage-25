# Python API overview

Use PyCatalyst as a **library** (without the HTTP server) for generation, recipes, and inference.

## Core entry points

| Module | Role |
|--------|------|
| [`GenerationEngine`](generation-engine.md) | Generate records; **`iter_records()`** streams rows with the same RNG semantics as batch `generate()` |
| **Mock DSL** | Python-first mock data DSL (model-class + fluent) — see [`mock-dsl`](mock-dsl.md) |
| **`pycatalyst.streaming`** | `stream_records()`, `sse_event`, `ndjson_line`, `StreamLimits`, `clamp_stream_params` |
| [`RecipeRunner`](recipe-runner.md) | Execute recipes from dict or YAML file |
| [`load_recipe`](recipe-loader.md) | Parse and validate recipe YAML |
| [Schema inference](schema-inference.md) | `infer_from_records`, `infer_from_file` |

## Types

Schema and field definitions live in **`pycatalyst._types`** (`SchemaSpec`, `FieldSpec`, `FieldType`, constraints). Prefer building specs via YAML/JSON config or `SchemaSpec.from_config()`.

## Sinks

Generated data can be sent to **memory**, **file**, **HTTP**, **database**, **Kafka**, **RabbitMQ**, etc., depending on installed extras. The recipe runner wires the sink from the recipe YAML.

## Further reading

- [Quick Start: CLI generate](../getting-started/quickstart.md)
- [Streaming data](../getting-started/streaming-data.md)
- [Recipes tutorial](../getting-started/recipes.md)

Subpages document the main classes and functions with full API signatures.
