# Python-first mock data DSL

PyCatalyst’s mock DSL is a thin, ergonomic layer over the core generation engine. It lets you define “what a record looks like” in Python, without writing `SchemaSpec` or YAML.

It supports two styles:

- **Model-class DSL**: declare fields on a class.
- **Fluent DSL**: chain `.field()` calls.

## Install

The DSL is part of the core package:

```bash
pip install pycatalyst
```

## Model-class DSL

```python
from dataclasses import dataclass

from pycatalyst import MockModel, enum, int_, string, uuid


class Order(MockModel):
    order_id = uuid()
    side = enum("buy", "sell")
    qty = int_(min=1, max=1000)
    symbol = string(pattern=r"^[A-Z]{1,5}$")


rows = Order.generate(5, seed=42)
stream = Order.iter(5, seed=42)
```

## Fluent DSL

```python
from pycatalyst import enum, int_, mock, string, uuid

rows = (
    mock("orders")
    .field("order_id", uuid())
    .field("side", enum("buy", "sell"))
    .field("qty", int_(min=1, max=1000))
    .field("symbol", string(pattern=r"^[A-Z]{1,5}$"))
    .generate(5, seed=42)
)
```

## Optional `return_type`

By default, generation returns dicts. You can optionally map each row into a different type.

### Callable mapper

```python
from pycatalyst import mock, uuid

rows = mock("x").field("id", uuid()).generate(3, return_type=lambda r: r["id"])
```

### Constructor type (dataclass or any `T(**row)` type)

```python
from dataclasses import dataclass

from pycatalyst import MockModel, int_, uuid


@dataclass
class OrderObj:
    id: str
    qty: int


class Order(MockModel):
    id = uuid()
    qty = int_(min=1, max=10)


objs = Order.generate(5, seed=1, return_type=OrderObj)
```

## Notes

- **Determinism**: passing the same `seed` yields the same sequence for both `generate()` and `iter()`.
- **Streaming**: use `iter()` when you want an iterator of records instead of a list.
