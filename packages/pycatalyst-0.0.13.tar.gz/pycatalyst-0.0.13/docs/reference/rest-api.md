# REST API overview

Base URL: **`/api/v1`**. All paths below are relative to that prefix (e.g. full path `POST /api/v1/generate`).

Interactive docs: **`/docs`** (Swagger) and **`/redoc`**.

## Auth (`/auth`)

| Method | Path | Description |
|--------|------|-------------|
| POST | `/auth/login` | Username/password → JWT |
| POST | `/auth/logout` | Client discards token |
| GET | `/auth/me` | Current user (Bearer) |

## Settings (public fragments)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/settings/app-config` | Theme, app name, version, `recipe_sink_mode` (`memory` or `full`) for UI (no auth) |

## Generate

| Method | Path | Description |
|--------|------|-------------|
| POST | `/generate` | Inline schema → synthetic records (batch JSON) |

## Stream (SSE)

| Method | Path | Description |
|--------|------|-------------|
| POST | `/stream/sse` | Same `name` + `fields` as `/generate`, plus `max_records` and optional `interval_ms` → **`text/event-stream`** (one SSE event per row, default event type `record`) |

When auth is enabled, send **`Authorization: Bearer <token>`**. Use `curl -N` or a client that reads the body incrementally. Server-side caps: **`PYCATALYST_STREAM_MAX_RECORDS`**, **`PYCATALYST_STREAM_MAX_INTERVAL_MS`**. Tutorial: [Streaming data](../getting-started/streaming-data.md).

## Infer

| Method | Path | Description |
|--------|------|-------------|
| POST | `/infer` | Sample records → inferred schema |

## Recipes

| Method | Path | Description |
|--------|------|-------------|
| GET | `/recipes/list` | Built-in template names and descriptions (shipped YAML under `data/templates/recipes`) |
| GET | `/recipes/templates/{name}` | Template YAML by `name` field or file stem |
| POST | `/recipes/run` | Run recipe dict; see below |

Default **`PYCATALYST_RECIPE_SINK_MODE=memory`**: the API ignores client sink config and uses an in-memory sink (returns records in JSON). With **`PYCATALYST_RECIPE_SINK_MODE=full`**, the request `sink` is used after validation (HTTP URLs must not target private/loopback hosts; file paths must stay under the system temp directory). Optional **`PYCATALYST_RECIPE_HTTP_ALLOW_HOST_SUFFIXES`** further restricts HTTP hostnames. Response includes `errors` from the sink when present.

## ML

Training, experiments, and model endpoints (see OpenAPI for paths and bodies). Requires ML extras installed on the server.

## Services

Database service containers (PostgreSQL, MongoDB, etc.)—CRUD and lifecycle. See `/docs` for operation IDs.

## Workbench

| Scope | Method | Path | Auth |
|-------|--------|------|------|
| Public | GET | `/workbench/capabilities` | No |
| Public | GET | `/workbench/profiles` | No |
| Protected | POST | `/workbench/environments` | Bearer |
| Protected | GET | `/workbench/environments` | Bearer |
| Protected | GET | `/workbench/environments/{env_id}/packages` | Bearer |
| Protected | POST | `/workbench/environments/{env_id}/sessions` | Bearer |
| Protected | GET | `/workbench/sessions` | Bearer |
| Protected | POST | `/workbench/sessions/{session_id}/refresh-env` | Bearer |
| WebSocket | WS | `/workbench/...` | `token` query param |

Exact session/WebSocket paths are listed in OpenAPI.

## Health

| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Status, version, workbench health |

## Authentication behavior

Routes under generate, **stream**, infer, recipes, ml, services, and workbench (except public workbench routes) use **`Depends(get_current_user)`** when auth is enabled. If auth is disabled, the API behaves as an anonymous admin for those routes.
