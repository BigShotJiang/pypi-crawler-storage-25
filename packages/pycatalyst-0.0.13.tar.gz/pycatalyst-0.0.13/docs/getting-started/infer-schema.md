# Infer schema from data

PyCatalyst can infer a **SchemaSpec** from sample rows (API) or from a file (CLI).

## REST: POST /api/v1/infer

Send JSON with an array of homogeneous records:

```bash
BASE=http://127.0.0.1:8005/api/v1

curl -s -X POST "$BASE/infer" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "name": "customers",
    "records": [
      {"id": 1, "email": "a@example.com", "score": 98.5},
      {"id": 2, "email": "b@example.com", "score": 12.0}
    ]
  }'
```

Response includes `name`, `fields` (name, type, nullable, constraints), and `field_count`.

No file upload is required—pass parsed JSON records.

## CLI: infer from file

Input must be a **JSON or YAML file** containing a **list of record objects** (same shape as the API `records` array):

```bash
pycatalyst infer --input samples.json -o schema.yaml
pycatalyst infer --input samples.yaml -o schema.json --name my_schema
```

Example `samples.json`:

```json
[
  {"id": 1, "name": "alice"},
  {"id": 2, "name": "bob"}
]
```

## Next steps

Use the inferred schema with:

- `pycatalyst generate --schema schema.yaml`
- **POST /api/v1/generate** with the same field definitions

See [Schema inference](../reference/schema-inference.md) for Python functions (`infer_from_records`, `infer_from_file`).
