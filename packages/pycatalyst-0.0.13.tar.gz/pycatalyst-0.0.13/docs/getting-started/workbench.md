# Workbench

The **workbench** provides isolated environments (venv or Docker) and **terminal sessions** (bash, Python, IPython) for interactive testing—useful for trying generators and recipes in a controlled shell.

## Capabilities (no auth)

Check what the server supports:

```bash
curl -s http://127.0.0.1:8005/api/v1/workbench/capabilities
```

Returns flags such as `venv`, `docker`, `services`, and session timeout settings.

## Profiles (no auth)

```bash
curl -s http://127.0.0.1:8005/api/v1/workbench/profiles
```

## Authenticated REST flow

When auth is enabled, list/create **environments** and **sessions** with a Bearer token:

1. **Create environment** — `POST /api/v1/workbench/environments`
   Body: `{"backend": "venv", "profile": null}`

2. **List environments** — `GET /api/v1/workbench/environments`

3. **Create session** — `POST /api/v1/workbench/environments/{env_id}/sessions`
   Body: `{"command": "bash", "cols": 80, "rows": 24}`
   Allowed commands include `bash`, `sh`, `python`, `ipython`, etc.

4. **List sessions** — `GET /api/v1/workbench/sessions`

5. **WebSocket** — connect to the WS URL documented in OpenAPI (`/docs`) with `token` query parameter for terminal I/O.

## Extras

- **`pycatalyst[workbench]`** — API + sandbox helpers
- **Docker backend** — `pycatalyst[sandbox]` and a running Docker daemon

## Health

Workbench status appears in the main health payload:

```bash
curl -s http://127.0.0.1:8005/health
```

See [REST API overview](../reference/rest-api.md) for the full route list.
