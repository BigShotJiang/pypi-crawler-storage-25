# API authentication

Protected routes under `/api/v1/` require a valid **Bearer** JWT when authentication is enabled. Public routes (e.g. settings, workbench capabilities) do not.

## When auth is disabled

If auth is disabled in configuration, `get_current_user` treats callers as an **anonymous admin**—you can omit `Authorization` for most workflows. Check your deployment: production should enable auth.

## Enable auth

Configure in `pycatalyst.cfg` or environment:

- **JWT secret**: `PYCATALYST_AUTH_JWT_SECRET` or `[auth] jwt_secret`
- **Users**: static users with username/password (see config docs) or external auth service

When enabled, `/api/v1/auth/login` accepts credentials and returns a token.

## Login

```bash
BASE=http://127.0.0.1:8005/api/v1

curl -s -X POST "$BASE/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"your-password"}'
```

Response (example):

```json
{
  "access_token": "eyJ...",
  "token_type": "bearer",
  "expires_in": 3600
}
```

## Call protected endpoints

```bash
TOKEN="<paste access_token>"

curl -s "$BASE/auth/me" \
  -H "Authorization: Bearer $TOKEN"
```

## Logout

The API returns OK; discard the token on the client.

```bash
curl -s -X POST "$BASE/auth/logout" \
  -H "Authorization: Bearer $TOKEN"
```

## Common errors

| Status | Meaning |
|--------|---------|
| 401 | Missing/invalid token or bad login |
| 503 | Auth disabled (`/auth/login`) or JWT/users not configured |

## Endpoints summary

| Method | Path | Auth |
|--------|------|------|
| POST | `/api/v1/auth/login` | No |
| POST | `/api/v1/auth/logout` | Optional |
| GET | `/api/v1/auth/me` | Yes (Bearer) |

See also [REST API overview](../reference/rest-api.md).
