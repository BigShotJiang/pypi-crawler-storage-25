# Quick Start

Go from install to a running API and optional UI in a few minutes.

## 1. Install

**Library + API + database** (typical for local development):

```bash
pip install "pycatalyst[api,db,inference,faker]"
```

For everything including UI, workbench, and ML:

```bash
pip install "pycatalyst[all]"
```

## 2. Database

Migrations and seed data power recipes and persistence. Set **`PYCATALYST_DATABASE_URL`** (or `[database]` in `pycatalyst.cfg`):

```bash
export PYCATALYST_DATABASE_URL="postgresql://user:pass@localhost:5432/pycatalyst"
# SQLite example:
export PYCATALYST_DATABASE_URL="sqlite:///./pycatalyst.db"

pycatalyst db init
pycatalyst db upgrade
pycatalyst db seed
```

If you only need generation without DB-backed features, you can skip this step and use the CLI (`pycatalyst generate`) or start the API for in-memory flows where applicable.

## 3. Start the API

```bash
pycatalyst api --host 127.0.0.1 --port 8005
```

- **Swagger**: [http://127.0.0.1:8005/docs](http://127.0.0.1:8005/docs)
- **Health**: [http://127.0.0.1:8005/health](http://127.0.0.1:8005/health)

Default bind is `0.0.0.0:8005`; use `--no-reload` for production-style runs.

## 4. Authentication (optional)

In development, auth is often **disabled**—protected routes accept requests without a Bearer token and run as an anonymous admin. When you enable auth (`pycatalyst.cfg` or environment), you must log in and send `Authorization: Bearer <token>`. See [API authentication](api-auth.md).

## 5. Try generation (CLI)

Minimal JSON Schema file `schema.json`:

```json
{
  "name": "widget",
  "fields": [
    { "name": "id", "type": "uuid" },
    { "name": "name", "type": "string" }
  ]
}
```

```bash
pycatalyst generate --schema schema.json -n 5
```

## 6. Optional: web UI

Build once (from repo with Node for the UI package):

```bash
pycatalyst ui build
```

Serve UI (proxies to API):

```bash
pycatalyst ui serve --api-url http://127.0.0.1:8005
```

UI default: [http://127.0.0.1:3005](http://127.0.0.1:3005).

## 7. This documentation site

```bash
pip install pycatalyst[docs]
pycatalyst docs serve
```

Opens at [http://127.0.0.1:5005](http://127.0.0.1:5005).

## Next steps

- [Generate via REST](generate-data.md)
- [Streaming mock data](streaming-data.md) (SSE, Python, NDJSON, Kafka)
- [Recipes](recipes.md)
- [Infer schema](infer-schema.md)
- [Workbench](workbench.md)
