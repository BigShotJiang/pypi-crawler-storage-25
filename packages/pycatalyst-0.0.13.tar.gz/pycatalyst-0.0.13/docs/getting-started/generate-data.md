# Generate synthetic data (REST)

The **generate** endpoint builds records from an **inline schema** (field list), without a stored recipe file.

## Endpoint

`POST /api/v1/generate`

Requires **Bearer** token when auth is enabled (see [API authentication](api-auth.md)).

## Minimal example

```bash
BASE=http://127.0.0.1:8005/api/v1
TOKEN=""  # set if auth enabled

curl -s -X POST "$BASE/generate" \
  -H "Content-Type: application/json" \
  ${TOKEN:+-H "Authorization: Bearer $TOKEN"} \
  -d '{
    "name": "orders",
    "fields": [
      {"name": "order_id", "type": "uuid"},
      {"name": "symbol", "type": "string", "constraints": {"pattern": "^[A-Z]{1,5}$"}},
      {"name": "qty", "type": "int", "constraints": {"min": 1, "max": 1000}}
    ],
    "count": 5,
    "seed": 42
  }'
```

Response fields:

- `records` — list of generated objects
- `count` — number of records
- `schema_name` — name from request
- `duration_ms` — timing
- `seed` — optional reproducibility seed

## Field types

Use the same type names as the core schema layer (`string`, `int`, `float`, `bool`, `uuid`, `datetime`, `enum`, `json`, nested objects via `children`, etc.). See OpenAPI at `/docs` for the full request model.

## CLI equivalent

```bash
pycatalyst generate --schema myschema.json -n 10 --seed 42
```

## Recipes vs inline generate

- **POST /generate** — ad-hoc schema in JSON body.
- **POST /recipes/run** — full recipe (schema + generation + sink config). By default the API uses an in-memory sink and returns records in the response. Set **`PYCATALYST_RECIPE_SINK_MODE=full`** to honor the request `sink` (with validation). See [Recipes](recipes.md).
