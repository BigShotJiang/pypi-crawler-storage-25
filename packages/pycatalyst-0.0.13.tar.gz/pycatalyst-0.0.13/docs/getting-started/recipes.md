# Recipes

Recipes are YAML (or dict) configurations: **schema**, **generation** (count, seed), and **sink** (file, memory, HTTP, etc.).

## Validate a recipe file (CLI)

```bash
pycatalyst recipe validate path/to/recipe.yaml
```

## List built-in templates (CLI)

```bash
pycatalyst recipe list
```

Shipped examples include templates such as `pystator_events`, `pycharter_contracts`, `pyoptima_portfolio` under `src/pycatalyst/data/templates/recipes/`.

## Run from CLI

```bash
pycatalyst generate --recipe src/pycatalyst/data/templates/recipes/pystator_events.yaml -o out.json
```

## Run via REST API

`POST /api/v1/recipes/run`

By default (**`PYCATALYST_RECIPE_SINK_MODE=memory`**, or unset) the API uses an in-memory sink and returns generated records in the response (nothing is written to external systems). With **`PYCATALYST_RECIPE_SINK_MODE=full`**, the JSON `sink` field is applied (HTTP and file sinks are validated for SSRF-safe URLs and temp-only file paths).

- **`GET /api/v1/recipes/list`** — template names and descriptions.
- **`GET /api/v1/recipes/templates/{name}`** — YAML text for a shipped template.

`GET /api/v1/settings/app-config` includes **`recipe_sink_mode`** so the UI can show or hide sink controls.

```bash
BASE=http://127.0.0.1:8005/api/v1

curl -s -X POST "$BASE/recipes/run" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "name": "demo",
    "description": "Quick API recipe",
    "schema": {
      "fields": [
        {"name": "id", "type": "uuid"},
        {"name": "status", "type": "enum", "constraints": {"choices": ["open", "closed"]}}
      ]
    },
    "generation": {"count": 3, "seed": 1}
  }'
```

## Recipe YAML shape (file)

```yaml
name: my_recipe
description: Example
version: "1.0"

schema:
  fields:
    - name: order_id
      type: uuid
    - name: quantity
      type: int
      constraints:
        min: 1
        max: 100

generation:
  count: 100
  seed: 42

sink:
  type: memory
```

See [Recipe loader](../reference/recipe-loader.md) and [Recipe runner](../reference/recipe-runner.md) for Python API details.
