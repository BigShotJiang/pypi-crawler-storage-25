# Streaming mock data

PyCatalyst can emit synthetic records **incrementally**—same field definitions and RNG semantics as batch [`generate`](generate-data.md), but suited for long-lived HTTP clients, shell pipelines, and message buses.

| Path | Use case |
|------|----------|
| **Python** `GenerationEngine.iter_records` | Libraries, custom sinks, tests |
| **REST** `POST /api/v1/stream/sse` | Browsers, microservices, `curl` |
| **CLI** `pycatalyst stream ndjson` | Pipe to `jq`, files, other tools |
| **CLI** `pycatalyst stream kafka` | Load Kafka topics for integration tests |

---

## Quickstart 1 — Python iterator

The first `limit` rows from `iter_records` match **`generate(..., count=limit)`** with the same `schema` and `seed`.

```python
from pycatalyst import GenerationEngine, SchemaBuilder

engine = GenerationEngine()
schema = SchemaBuilder("events").add_uuid("id").add_string("kind").build()

for row in engine.iter_records(schema, seed=123, limit=10):
    print(row)
```

**One-liner** via `pycatalyst.streaming`:

```python
from pycatalyst import GenerationEngine, SchemaBuilder
from pycatalyst.streaming import stream_records

schema = SchemaBuilder("x").add_string("id").build()
for row in stream_records(schema, limit=5, seed=1):
    print(row)
```

**JSON Schema file** (same as CLI):

```python
import json
from pathlib import Path
from pycatalyst.generators.engine import GenerationEngine
from pycatalyst.schema.json_schema import from_json_schema

data = json.loads(Path("schema.json").read_text(encoding="utf-8"))
schema = from_json_schema(data, name="widget")
engine = GenerationEngine()
for rec in engine.iter_records(schema, limit=100):
    ...
```

Helpers for wire formats: `from pycatalyst.streaming import ndjson_line, sse_event, StreamLimits, clamp_stream_params`.

---

## Quickstart 2 — HTTP (Server-Sent Events)

Start the API (see [Quick Start](quickstart.md)):

```bash
pycatalyst api --host 127.0.0.1 --port 8005
```

**Request body** matches batch generate: top-level **`name`** (schema name), **`fields`** array, optional **`seed`**, plus:

- **`max_records`** (required, ≥ 1) — how many rows to stream
- **`interval_ms`** (optional) — delay between events

**curl** (`-N` disables buffering so events appear as they arrive). Omit the auth header when auth is disabled:

```bash
curl -N -H "Content-Type: application/json" \
  -d '{
    "name": "widget",
    "fields": [
      {"name": "id", "type": "uuid"},
      {"name": "name", "type": "string"}
    ],
    "max_records": 5,
    "seed": 1,
    "interval_ms": 0
  }' \
  http://127.0.0.1:8005/api/v1/stream/sse
```

With JWT:

```bash
curl -N -H "Authorization: Bearer YOUR_JWT" -H "Content-Type: application/json" \
  -d '{"name":"x","fields":[{"name":"n","type":"int"}],"max_records":5,"seed":1}' \
  http://127.0.0.1:8005/api/v1/stream/sse
```

Each payload line is SSE: default **event type `record`** with JSON data per row. Errors use **`event: error`**. See also [REST API — Stream (SSE)](../reference/rest-api.md).

**Python (httpx)** — stream the body line-by-line:

```python
import httpx

url = "http://127.0.0.1:8005/api/v1/stream/sse"
body = {
    "name": "x",
    "fields": [{"name": "v", "type": "int"}],
    "max_records": 3,
}
headers = {}  # or {"Authorization": "Bearer ..."}

with httpx.Client(timeout=None) as client:
    with client.stream("POST", url, json=body, headers=headers) as r:
        r.raise_for_status()
        for line in r.iter_lines():
            if line:
                print(line)
```

---

## Quickstart 3 — NDJSON to stdout

Define a **JSON Schema** file (e.g. `schema.json` from the [Quick Start](quickstart.md) `widget` example). Then:

```bash
pycatalyst stream ndjson --schema schema.json -n 500 --seed 1
```

Each line is one JSON object. Pipe into other tools:

```bash
pycatalyst stream ndjson -s schema.json -n 20 | jq .
```

---

## Quickstart 4 — Kafka

Requires **`pip install pycatalyst[kafka]`**. Set bootstrap and topic via flags or environment:

```bash
export PYCATALYST_STREAM_KAFKA_BOOTSTRAP=localhost:9092
export PYCATALYST_STREAM_KAFKA_TOPIC=test-topic

pycatalyst stream kafka --schema schema.json -n 2000 --batch 100
```

Or explicitly:

```bash
pycatalyst stream kafka -s schema.json \
  --bootstrap localhost:9092 --topic my-topic \
  -n 1000 --batch 50 --key-field id
```

---

## Limits and environment

| Variable | Role |
|----------|------|
| `PYCATALYST_STREAM_MAX_RECORDS` | Cap on `max_records` / CLI `-n` (default 100_000) |
| `PYCATALYST_STREAM_MAX_INTERVAL_MS` | Max delay between SSE events (default 60_000) |
| `PYCATALYST_STREAM_KAFKA_BOOTSTRAP` | Kafka brokers for `stream kafka` |
| `PYCATALYST_STREAM_KAFKA_TOPIC` | Topic for `stream kafka` |

---

## Next steps

- [Generate via REST](generate-data.md) — batch JSON from the same field model
- [REST API overview](../reference/rest-api.md)
- [Python API overview](../reference/python-api.md)
