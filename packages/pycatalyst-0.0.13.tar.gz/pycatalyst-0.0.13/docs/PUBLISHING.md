# Publishing pycatalyst to PyPI

## Option A: Trusted Publishing (recommended)

No API tokens in GitHub. One-time setup on PyPI, then every tag/release publishes automatically.

### 1. Create a PyPI account

- Go to [pypi.org](https://pypi.org), register, and enable 2FA.

### 2. Create the project and add a Trusted Publisher

- **If the project does not exist yet:**
  [Create a new project via OIDC](https://docs.pypi.org/trusted-publishers/creating-a-project-through-oidc/):
  PyPI → Your projects → **Add new project** → under “Publishing” choose **Add a new pending publisher** and fill in:

- **If the project already exists:**
  PyPI → Your projects → **pycatalyst** → **Publishing** → **Add a new pending publisher**

Use these values:

| Field            | Value              |
|------------------|--------------------|
| **Owner**        | Your GitHub username or org (e.g. `your-org`) |
| **Repository name** | Your repo name (e.g. `pycatalyst`)        |
| **Workflow name**   | `Publish to PyPI`                      |
| **Environment**    | Leave empty (or set one in the workflow and here) |

Save. The publisher is “pending” until the first successful run.

### 3. Push the repo and trigger a release

Ensure the repo is on GitHub and the workflow file is in `.github/workflows/publish.yml`.

Then:

```bash
# Version is read from pyproject.toml — bump it if needed (e.g. 0.1.0)
git add .
git commit -m "Release 0.1.0"
git push origin main

# Create and push a tag (this triggers the workflow)
git tag v0.1.0
git push origin v0.1.0
```

The **Publish to PyPI** workflow will run, build the package, and upload to PyPI. After the first successful run, the pending publisher becomes active.

---

## Option B: Publish from your machine (API token)

Use this for a one-off publish or if you are not using GitHub Actions.

### 1. Create a PyPI API token

- PyPI → Account settings → **API tokens** → **Add API token**
- Scope: **Project** → select or create **pycatalyst**
- Copy the token (starts with `pypi-`).

### 2. Build and upload

```bash
cd /path/to/pycatalyst
pip install build twine

# Build
python -m build

# Upload (you will be prompted for username and password; use __token__ and the token as password)
twine upload dist/*
```

Or with the token in the environment (no prompt):

```bash
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-YourTokenHere
twine upload dist/*
```

---

## After publishing

- Check the project on PyPI: `https://pypi.org/project/pycatalyst/`
- Install with: `pip install pycatalyst`

For later releases: bump `version` in `pyproject.toml`, update `CHANGELOG.md`, then run the same tag/push (Option A) or build/upload (Option B) again.
