# PyCatalyst

**PyCatalyst** is a schema-aware data generation and testing platform. Use it to produce synthetic datasets from JSON Schema–like definitions, run **recipes** (YAML pipelines), infer schemas from sample data, and expose everything through a **REST API** and optional web UI. For pipelines and integration tests, you can **stream** mock records over **HTTP (Server-Sent Events)**, from **Python** (`iter_records`), as **NDJSON**, or to **Kafka**—see [Streaming data](getting-started/streaming-data.md).

## Documentation

| Resource | Description |
|----------|-------------|
| [Quick Start](getting-started/quickstart.md) | Install, database, API, and UI in minutes |
| [Getting Started tutorials](getting-started/quickstart.md) | Auth, generate, recipes, infer, workbench |
| [Streaming data](getting-started/streaming-data.md) | SSE API, Python iterator, NDJSON & Kafka CLI |
| [REST API overview](reference/rest-api.md) | `/api/v1/...` resource groups |
| [Python API](reference/python-api.md) | Core library modules (mkdocstrings) |

## Live API docs

When the API server is running (default port **8005**), interactive OpenAPI documentation is available at:

- **Swagger UI**: [http://127.0.0.1:8005/docs](http://127.0.0.1:8005/docs)
- **ReDoc**: [http://127.0.0.1:8005/redoc](http://127.0.0.1:8005/redoc)
- **OpenAPI JSON**: [http://127.0.0.1:8005/openapi.json](http://127.0.0.1:8005/openapi.json)

## Build this site locally

From the repository root (with MkDocs installed):

```bash
pip install pycatalyst[docs]
pycatalyst docs serve
```

Default URL: [http://127.0.0.1:5005](http://127.0.0.1:5005) (docs **5005**; API **8005**; UI **3005**).

Static build:

```bash
pycatalyst docs build   # output in site/
```

## Links

- [Repository](https://github.com/optophi/pycatalyst)
- [PyPI](https://pypi.org/project/pycatalyst/) (when published)
