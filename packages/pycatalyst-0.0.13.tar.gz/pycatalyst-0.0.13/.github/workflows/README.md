# GitHub Actions in PyCatalyst

## What should happen when you create a PR (develop → main)

When you open a **pull request that targets `main` or `develop`**:

1. The **Test** workflow should run (`.github/workflows/test.yml`).
2. You get **3 matrix jobs** (Python 3.11, 3.12, 3.13), each running:
   - Install deps (`pip install -e ".[dev]"`)
   - `pytest`
   - Ruff format + Ruff check (linting)
   - Mypy (type checking)
   - Node/npm for UI (if present): `npm ci`, `npm run type-check`
3. The run appears under the **Checks** tab of the PR and in **Actions**.

Trigger in `test.yml` is:

```yaml
on:
  pull_request:
    branches: [main, develop]
```

So the PR’s **base (target) branch** must be `main` or `develop`. A PR **develop → main** has base `main`, so it qualifies.

---

## Why the workflow might not run at all

### 1. Workflow file not on the PR’s **source** branch (most common)

GitHub runs the workflow that exists on the **head** of the PR (the branch you’re merging **from**).

- PR: **develop → main**
- GitHub uses the workflow from the **develop** branch.
- If `.github/workflows/test.yml` is **not** on `develop` (e.g. you only added it on `main`), **no workflow run is created**.

**Fix:** Ensure the workflow is on the branch you use for the PR:

- Merge `main` into `develop` and push, then open (or update) the PR, or
- Cherry-pick/add the workflow on `develop` and push.

After that, new pushes to the PR or reopening it should trigger the Test workflow.

### 2. GitHub Actions disabled or restricted

- **Settings → Actions → General**
  - “Actions permissions”: should allow “Allow all actions and reusable workflows” (or your intended choice).
  - If “Disable actions” is selected, no workflows run.
- **Fork PRs:** If the PR is from a **fork**, check “Fork pull request workflows from outside collaborators” (or equivalent); if disabled, workflows from fork PRs may not run.

### 3. Default branch / branch name

- The trigger only lists `main` and `develop`. If your default branch is something else (e.g. `master`) and you open a PR **into** that branch, the workflow will not run unless you add that branch to `branches:` in `test.yml`.

### 4. Credits / billing (unlikely to prevent the run from starting)

- **Public repos:** GitHub Actions minutes are free; you don’t run out of “credits” in a way that would stop the workflow from **starting**.
- **Private repos:** Free tier has a monthly minutes limit. Exhausting it or having a **spending limit set to $0** can block new runs. You’d usually see a billing warning in the UI or email; the run might show as “canceled” or not start.
- If **no run appears at all** (no “Test” workflow in the Actions tab for that PR), the usual cause is that the workflow didn’t trigger (e.g. workflow file not on the source branch or Actions disabled), not billing.

---

## Quick checklist when no runs appear for “develop → main”

1. **Workflow on `develop`**
   On GitHub, open the repo, switch to branch **develop**, and confirm `.github/workflows/test.yml` exists and has the `pull_request: branches: [main, develop]` trigger.

2. **PR base branch**
   The PR must target **main** (or **develop**). If it targets another branch, the current trigger won’t run.

3. **Actions enabled**
   **Settings → Actions → General** → Actions are not disabled.

4. **Fork (if applicable)**
   If the PR is from a fork, ensure “Fork pull request workflows” (or similar) is allowed.

5. **Push after fixing**
   If you just merged `main` into `develop` to get the workflow file onto `develop`, push that merge (or any new commit) to the PR branch so the workflow is re-evaluated.

---

## Summary

- **Expected:** A PR that targets `main` or `develop` (e.g. develop → main) should trigger the **Test** workflow and run tests on Python 3.11, 3.12, and 3.13.
- **Most likely reason it doesn’t:** The workflow file is not on the PR’s source branch (e.g. not on `develop`). Get `.github/workflows/test.yml` onto that branch (e.g. by merging `main` into `develop`), then push and re-open or update the PR.
- **Then check:** Settings → Actions and, for fork PRs, fork workflow permissions. Credits are rarely the cause when no run appears at all.
