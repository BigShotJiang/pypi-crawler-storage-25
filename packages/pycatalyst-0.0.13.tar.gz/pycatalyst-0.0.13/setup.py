"""Setup script for PyCatalyst.

This script bundles documentation files and handles UI static files
before packaging.
"""

from __future__ import annotations

import shutil
from pathlib import Path

from setuptools import setup
from setuptools.command.build_py import build_py
from setuptools.command.sdist import sdist


def _bundle_docs(pkg_name: str) -> None:
    """Copy mkdocs.yml + docs/ into src/<pkg>/_bundled_docs/ for packaging."""
    repo_root = Path(__file__).parent
    mkdocs_yml = repo_root / "mkdocs.yml"
    docs_dir = repo_root / "docs"
    target = repo_root / "src" / pkg_name / "_bundled_docs"

    if not mkdocs_yml.exists():
        print("mkdocs.yml not found, skipping docs bundling.")
        return

    if target.exists():
        shutil.rmtree(target)
    target.mkdir(parents=True, exist_ok=True)

    shutil.copy2(mkdocs_yml, target / "mkdocs.yml")
    if docs_dir.exists():
        shutil.copytree(docs_dir, target / "docs")

    print(f"Docs bundled into {target.relative_to(repo_root)}")


class BuildCommand(build_py):
    """Custom build command that bundles docs before packaging."""

    def run(self) -> None:
        _bundle_docs("pycatalyst")
        super().run()


class SDistCommand(sdist):
    """Custom sdist command that bundles docs before creating source dist."""

    def run(self) -> None:
        self.run_command("build_py")
        if hasattr(self, "filelist"):
            self.filelist = None
        super().run()


cmdclass = {
    "build_py": BuildCommand,
    "sdist": SDistCommand,
}

if __name__ == "__main__":
    from setuptools import find_packages

    setup(
        package_dir={"": "src"},
        packages=find_packages(where="src"),
        cmdclass=cmdclass,
    )
