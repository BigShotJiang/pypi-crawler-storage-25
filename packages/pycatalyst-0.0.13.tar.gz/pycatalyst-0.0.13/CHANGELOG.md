# Changelog

All notable changes to this project will be documented in this file.
The format is based on [Keep a Changelog](https://keepachangelog.com/).

## [0.0.13] - 2026-04-06

### Added

- Update package

### Documentation

- Update documentation

## [0.0.4] - 2026-03-05

