"""Tests for GenerationEngine.iter_records and streaming helpers."""

from __future__ import annotations

import json

import pytest

from pycatalyst.generators.engine import GenerationEngine
from pycatalyst.schema.spec import SchemaBuilder
from pycatalyst.streaming import (
    clamp_stream_params,
    ndjson_line,
    sse_event,
    stream_records,
)
from pycatalyst.streaming.limits import StreamLimits


def _simple_schema():
    return (
        SchemaBuilder("t")
        .add_string("id", min_len=4, max_len=8)
        .add_int("n", min_val=0, max_val=100)
        .build()
    )


def test_iter_records_matches_generate_batch() -> None:
    engine = GenerationEngine()
    schema = _simple_schema()
    seed = 12345
    n = 50
    batch = engine.generate(schema, count=n, seed=seed).records
    streamed = list(engine.iter_records(schema, seed=seed, limit=n))
    assert streamed == list(batch)


def test_iter_records_limit_stops() -> None:
    engine = GenerationEngine()
    schema = _simple_schema()
    assert len(list(engine.iter_records(schema, seed=1, limit=7))) == 7


def test_iter_records_limit_invalid() -> None:
    engine = GenerationEngine()
    schema = _simple_schema()
    with pytest.raises(Exception):  # GenerationError
        list(engine.iter_records(schema, limit=0))


def test_stream_records_wrapper() -> None:
    schema = _simple_schema()
    engine = GenerationEngine()
    a = list(stream_records(schema, limit=5, seed=99, engine=engine))
    b = list(engine.iter_records(schema, seed=99, limit=5))
    assert a == b


def test_sse_event_format() -> None:
    s = sse_event({"a": 1})
    assert s.startswith("event: record\n")
    assert "data: " in s
    assert json.loads(s.split("data: ")[1].split("\n")[0]) == {"a": 1}


def test_ndjson_line() -> None:
    assert ndjson_line({"x": True}).endswith("\n")


def test_clamp_stream_params() -> None:
    n, ms = clamp_stream_params(
        999_999, 999_999, limits=StreamLimits(max_records=100, max_interval_ms=5000)
    )
    assert n == 100
    assert ms == 5000
