"""Unit tests for catalyst_store — InMemory CRUD, template methods, context manager."""

from __future__ import annotations

import pytest

from pycatalyst.catalyst_store import CatalystStoreClient, InMemoryCatalystStore

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def store() -> InMemoryCatalystStore:
    """Connected in-memory catalyst store."""
    s = InMemoryCatalystStore()
    s.connect()
    return s


# ---------------------------------------------------------------------------
# ABC enforcement
# ---------------------------------------------------------------------------


class TestABCEnforcement:
    """CatalystStoreClient cannot be instantiated directly."""

    def test_direct_instantiation_raises(self) -> None:
        with pytest.raises(TypeError):
            CatalystStoreClient()  # type: ignore[abstract]


# ---------------------------------------------------------------------------
# Context manager
# ---------------------------------------------------------------------------


class TestContextManager:
    """__enter__ / __exit__ lifecycle."""

    def test_context_manager_connects_and_disconnects(self) -> None:
        with InMemoryCatalystStore() as store:
            assert store._connection is not None
        assert store._connection is None

    def test_context_manager_yields_store(self) -> None:
        with InMemoryCatalystStore() as store:
            assert isinstance(store, CatalystStoreClient)


# ---------------------------------------------------------------------------
# Experiment CRUD
# ---------------------------------------------------------------------------


class TestExperimentCRUD:
    """Store, get, list, delete experiments."""

    def test_store_and_get(self, store: InMemoryCatalystStore) -> None:
        exp = {"status": "completed", "metrics": {"accuracy": 0.95}}
        exp_id = store.store_experiment("exp1", "pytorch", exp)
        assert exp_id == "exp1:pytorch"

        result = store.get_experiment("exp1", "pytorch")
        assert result is not None
        assert result["name"] == "exp1"
        assert result["metrics"]["accuracy"] == 0.95

    def test_get_missing_returns_none(self, store: InMemoryCatalystStore) -> None:
        assert store.get_experiment("missing", "pytorch") is None

    def test_list_experiments(self, store: InMemoryCatalystStore) -> None:
        store.store_experiment("a", "pytorch", {"status": "running"})
        store.store_experiment("b", "sklearn", {"status": "completed"})
        store.store_experiment("c", "pytorch", {"status": "completed"})

        assert len(store.list_experiments()) == 3
        assert len(store.list_experiments(backend="pytorch")) == 2
        assert len(store.list_experiments(status="completed")) == 2
        assert len(store.list_experiments(backend="pytorch", status="completed")) == 1

    def test_delete_experiment(self, store: InMemoryCatalystStore) -> None:
        store.store_experiment("exp1", "pytorch", {})
        assert store.delete_experiment("exp1:pytorch") is True
        assert store.get_experiment("exp1", "pytorch") is None

    def test_delete_missing_returns_false(self, store: InMemoryCatalystStore) -> None:
        assert store.delete_experiment("nope:pytorch") is False

    def test_deepcopy_isolation(self, store: InMemoryCatalystStore) -> None:
        exp = {"metrics": {"loss": 0.5}}
        store.store_experiment("exp1", "pytorch", exp)
        result = store.get_experiment("exp1", "pytorch")
        assert result is not None
        result["metrics"]["loss"] = 999
        fresh = store.get_experiment("exp1", "pytorch")
        assert fresh is not None
        assert fresh["metrics"]["loss"] == 0.5


# ---------------------------------------------------------------------------
# Recipe CRUD
# ---------------------------------------------------------------------------


class TestRecipeCRUD:
    """Store, get, list, delete recipes."""

    def test_store_and_get(self, store: InMemoryCatalystStore) -> None:
        recipe = {"schema_name": "users", "record_count": 100}
        recipe_id = store.store_recipe("users_recipe", "1.0", recipe)
        assert recipe_id == "users_recipe:1.0"

        result = store.get_recipe("users_recipe", "1.0")
        assert result is not None
        assert result["schema_name"] == "users"

    def test_get_missing_returns_none(self, store: InMemoryCatalystStore) -> None:
        assert store.get_recipe("missing", "1.0") is None

    def test_list_recipes(self, store: InMemoryCatalystStore) -> None:
        store.store_recipe("a", "1.0", {})
        store.store_recipe("b", "2.0", {})
        assert len(store.list_recipes()) == 2

    def test_delete_recipe(self, store: InMemoryCatalystStore) -> None:
        store.store_recipe("r1", "1.0", {})
        assert store.delete_recipe("r1:1.0") is True
        assert store.get_recipe("r1", "1.0") is None


# ---------------------------------------------------------------------------
# SchemaSpec CRUD
# ---------------------------------------------------------------------------


class TestSchemaSpecCRUD:
    """Store, get, list, delete schema specs."""

    def test_store_and_get(self, store: InMemoryCatalystStore) -> None:
        spec = {"fields": [{"name": "id", "type": "integer"}]}
        spec_id = store.store_schema_spec("users", spec)
        assert spec_id == "users"

        result = store.get_schema_spec("users")
        assert result is not None
        assert result["fields"][0]["name"] == "id"

    def test_get_missing_returns_none(self, store: InMemoryCatalystStore) -> None:
        assert store.get_schema_spec("missing") is None

    def test_list_schema_specs(self, store: InMemoryCatalystStore) -> None:
        store.store_schema_spec("a", {})
        store.store_schema_spec("b", {})
        assert len(store.list_schema_specs()) == 2

    def test_delete_schema_spec(self, store: InMemoryCatalystStore) -> None:
        store.store_schema_spec("s1", {})
        assert store.delete_schema_spec("s1") is True
        assert store.get_schema_spec("s1") is None


# ---------------------------------------------------------------------------
# GenerationRun CRUD
# ---------------------------------------------------------------------------


class TestGenerationRunCRUD:
    """Store, get, list, delete generation runs."""

    def test_store_and_get(self, store: InMemoryCatalystStore) -> None:
        run = {"record_count": 500, "seed": 42}
        run_id = store.store_generation_run("recipe1", "1.0", run)
        assert run_id  # UUID string

        result = store.get_generation_run(run_id)
        assert result is not None
        assert result["record_count"] == 500
        assert result["recipe_name"] == "recipe1"

    def test_get_missing_returns_none(self, store: InMemoryCatalystStore) -> None:
        assert store.get_generation_run("nonexistent-uuid") is None

    def test_list_with_filter(self, store: InMemoryCatalystStore) -> None:
        store.store_generation_run("r1", "1.0", {})
        store.store_generation_run("r1", "1.0", {})
        store.store_generation_run("r2", "1.0", {})

        assert len(store.list_generation_runs()) == 3
        assert len(store.list_generation_runs(recipe_name="r1")) == 2

    def test_delete_generation_run(self, store: InMemoryCatalystStore) -> None:
        run_id = store.store_generation_run("r1", "1.0", {})
        assert store.delete_generation_run(run_id) is True
        assert store.get_generation_run(run_id) is None

    def test_delete_missing_returns_false(self, store: InMemoryCatalystStore) -> None:
        assert store.delete_generation_run("missing") is False


# ---------------------------------------------------------------------------
# Template methods
# ---------------------------------------------------------------------------


class TestTemplateMethods:
    """get_experiment_summary and get_recipe_with_schema."""

    def test_experiment_summary_strips_bulky_fields(
        self, store: InMemoryCatalystStore
    ) -> None:
        exp = {
            "status": "completed",
            "metrics": {"acc": 0.9},
            "training_history": [{"epoch": 1, "loss": 0.5}],
            "config": {"lr": 0.001, "epochs": 10},
        }
        store.store_experiment("exp1", "pytorch", exp)

        summary = store.get_experiment_summary("exp1", "pytorch")
        assert summary is not None
        assert "training_history" not in summary
        assert "config" not in summary
        assert summary["metrics"]["acc"] == 0.9

    def test_experiment_summary_missing_returns_none(
        self, store: InMemoryCatalystStore
    ) -> None:
        assert store.get_experiment_summary("nope", "pytorch") is None

    def test_recipe_with_schema_resolves(self, store: InMemoryCatalystStore) -> None:
        store.store_schema_spec("users", {"fields": [{"name": "id", "type": "int"}]})
        store.store_recipe(
            "gen_users",
            "1.0",
            {"schema_name": "users", "record_count": 100},
        )

        result = store.get_recipe_with_schema("gen_users", "1.0")
        assert result is not None
        assert "schema_spec" in result
        assert result["schema_spec"]["fields"][0]["name"] == "id"

    def test_recipe_with_schema_no_schema_name(
        self, store: InMemoryCatalystStore
    ) -> None:
        store.store_recipe("r1", "1.0", {"record_count": 10})
        result = store.get_recipe_with_schema("r1", "1.0")
        assert result is not None
        assert "schema_spec" not in result

    def test_recipe_with_schema_missing_recipe(
        self, store: InMemoryCatalystStore
    ) -> None:
        assert store.get_recipe_with_schema("nope", "1.0") is None


# ---------------------------------------------------------------------------
# Optional extension points
# ---------------------------------------------------------------------------


class TestOptionalExtensions:
    """Default artifact behavior on the ABC (no artifact_backend set)."""

    def test_base_store_artifact_raises(self) -> None:
        """A minimal subclass without native artifact support raises."""

        class _Bare(CatalystStoreClient):
            """Minimal concrete subclass for testing defaults."""

            def connect(self) -> None:
                self._connection = "ok"

            def store_experiment(self, n, b, e):  # noqa: ANN001
                ...

            def get_experiment(self, n, b):  # noqa: ANN001
                ...

            def list_experiments(self, **kw):  # noqa: ANN003
                ...

            def delete_experiment(self, eid):  # noqa: ANN001
                ...

            def store_recipe(self, n, v, r):  # noqa: ANN001
                ...

            def get_recipe(self, n, v):  # noqa: ANN001
                ...

            def list_recipes(self): ...

            def delete_recipe(self, rid):  # noqa: ANN001
                ...

            def store_schema_spec(self, n, s):  # noqa: ANN001
                ...

            def get_schema_spec(self, n):  # noqa: ANN001
                ...

            def list_schema_specs(self): ...

            def delete_schema_spec(self, sid):  # noqa: ANN001
                ...

            def store_generation_run(self, rn, rv, r):  # noqa: ANN001
                ...

            def get_generation_run(self, rid):  # noqa: ANN001
                ...

            def list_generation_runs(self, **kw):  # noqa: ANN003
                ...

            def delete_generation_run(self, rid):  # noqa: ANN001
                ...

        bare = _Bare()
        bare.connect()
        with pytest.raises(NotImplementedError):
            bare.store_artifact("exp1", "model.pt", b"data")
        assert bare.get_artifact("exp1", "model.pt") is None
        assert bare.list_artifacts("exp1") == []
        assert bare.delete_artifact("exp1", "model.pt") is False


# ---------------------------------------------------------------------------
# Artifact CRUD (InMemory native)
# ---------------------------------------------------------------------------


class TestArtifactCRUD:
    """InMemory artifact store/get/list/delete."""

    def test_store_and_get(self, store: InMemoryCatalystStore) -> None:
        aid = store.store_artifact("exp1", "model.pt", b"weights")
        assert aid == "exp1:model.pt"

        data = store.get_artifact("exp1", "model.pt")
        assert data == b"weights"

    def test_get_missing_returns_none(self, store: InMemoryCatalystStore) -> None:
        assert store.get_artifact("exp1", "missing.pt") is None

    def test_list_artifacts(self, store: InMemoryCatalystStore) -> None:
        store.store_artifact("exp1", "model.pt", b"w")
        store.store_artifact("exp1", "config.json", b"{}")
        store.store_artifact("exp2", "other.pt", b"x")

        names = store.list_artifacts("exp1")
        assert sorted(names) == ["config.json", "model.pt"]

    def test_delete_artifact(self, store: InMemoryCatalystStore) -> None:
        store.store_artifact("exp1", "model.pt", b"w")
        assert store.delete_artifact("exp1", "model.pt") is True
        assert store.get_artifact("exp1", "model.pt") is None

    def test_delete_missing_returns_false(self, store: InMemoryCatalystStore) -> None:
        assert store.delete_artifact("exp1", "nope") is False

    def test_upsert_overwrites(self, store: InMemoryCatalystStore) -> None:
        store.store_artifact("exp1", "model.pt", b"v1")
        store.store_artifact("exp1", "model.pt", b"v2")
        assert store.get_artifact("exp1", "model.pt") == b"v2"

    def test_list_empty(self, store: InMemoryCatalystStore) -> None:
        assert store.list_artifacts("no-such-experiment") == []


# ---------------------------------------------------------------------------
# Error module integration
# ---------------------------------------------------------------------------


class TestStoreError:
    """StoreError exists and inherits from CatalystError."""

    def test_store_error_attributes(self) -> None:
        from pycatalyst.errors import ErrorCode, StoreError

        err = StoreError(
            "connection failed",
            store_type="sqlite",
            entity_type="experiment",
        )
        assert err.store_type == "sqlite"
        assert err.entity_type == "experiment"
        assert err.code == ErrorCode.STORE_ERROR
        assert "sqlite" in str(err)
