"""Tests for pycatalyst.generators module."""

from __future__ import annotations

import random
import re
from random import Random

import pytest

from pycatalyst._types import (
    Distribution,
    FieldConstraints,
    FieldSpec,
    FieldType,
    SchemaSpec,
)
from pycatalyst.errors import GenerationError, GeneratorNotFoundError
from pycatalyst.generators.compound import ArrayGenerator, ObjectGenerator
from pycatalyst.generators.engine import GenerationEngine
from pycatalyst.generators.registry import GeneratorRegistry
from pycatalyst.generators.scalar import (
    BoolGenerator,
    DateGenerator,
    DateTimeGenerator,
    EnumGenerator,
    FloatGenerator,
    IntGenerator,
    StringGenerator,
    UUIDGenerator,
)


class TestGeneratorRegistry:
    """Tests for GeneratorRegistry."""

    def test_default_has_all_types(self) -> None:
        registry = GeneratorRegistry.default()
        for ft in FieldType:
            assert registry.has(ft), f"Missing generator for {ft.value}"

    def test_register_and_get(self) -> None:
        registry = GeneratorRegistry()
        gen = StringGenerator()
        registry.register(FieldType.STRING, gen)
        assert registry.get(FieldType.STRING) is gen

    def test_get_missing_raises(self) -> None:
        registry = GeneratorRegistry()
        with pytest.raises(GeneratorNotFoundError):
            registry.get(FieldType.STRING)

    def test_has(self) -> None:
        registry = GeneratorRegistry()
        assert not registry.has(FieldType.INT)
        registry.register(FieldType.INT, IntGenerator())
        assert registry.has(FieldType.INT)

    def test_unregister(self) -> None:
        registry = GeneratorRegistry()
        registry.register(FieldType.INT, IntGenerator())
        registry.unregister(FieldType.INT)
        assert not registry.has(FieldType.INT)

    def test_override(self) -> None:
        registry = GeneratorRegistry()
        gen1 = IntGenerator()
        gen2 = IntGenerator()
        registry.register(FieldType.INT, gen1)
        registry.register(FieldType.INT, gen2)
        assert registry.get(FieldType.INT) is gen2

    def test_registered_types(self) -> None:
        registry = GeneratorRegistry()
        registry.register(FieldType.INT, IntGenerator())
        registry.register(FieldType.STRING, StringGenerator())
        assert set(registry.registered_types) == {
            FieldType.INT,
            FieldType.STRING,
        }


class TestStringGenerator:
    """Tests for StringGenerator."""

    def test_generates_string(self) -> None:
        gen = StringGenerator()
        spec = FieldSpec(name="name", type=FieldType.STRING)
        result = gen.generate(spec, Random(42))
        assert isinstance(result, str)
        assert len(result) >= 5

    def test_respects_length_constraints(self) -> None:
        gen = StringGenerator()
        constraints = FieldConstraints(min=3, max=3)
        spec = FieldSpec(name="code", type=FieldType.STRING, constraints=constraints)
        rng = Random(42)
        for _ in range(20):
            result = gen.generate(spec, rng)
            assert len(result) == 3

    def test_respects_pattern_constraint(self) -> None:
        gen = StringGenerator()
        pattern = r"[A-Z]{3}"
        constraints = FieldConstraints(pattern=pattern)
        spec = FieldSpec(name="code", type=FieldType.STRING, constraints=constraints)
        random.seed(42)
        for _ in range(20):
            result = gen.generate(spec, Random(42))
            assert re.fullmatch(pattern, result), f"{result!r} does not match {pattern}"

    def test_pattern_reproducible_with_seed(self) -> None:
        gen = StringGenerator()
        constraints = FieldConstraints(pattern=r"[0-9]{4}")
        spec = FieldSpec(name="digits", type=FieldType.STRING, constraints=constraints)
        random.seed(123)
        result1 = gen.generate(spec, Random(123))
        random.seed(123)
        result2 = gen.generate(spec, Random(123))
        assert result1 == result2, (
            "pattern generation should be reproducible with same seed"
        )


class TestIntGenerator:
    """Tests for IntGenerator."""

    def test_generates_int(self) -> None:
        gen = IntGenerator()
        spec = FieldSpec(name="age", type=FieldType.INT)
        result = gen.generate(spec, Random(42))
        assert isinstance(result, int)

    def test_respects_range(self) -> None:
        gen = IntGenerator()
        constraints = FieldConstraints(min=10, max=20)
        spec = FieldSpec(name="val", type=FieldType.INT, constraints=constraints)
        rng = Random(42)
        for _ in range(50):
            result = gen.generate(spec, rng)
            assert 10 <= result <= 20

    def test_normal_distribution(self) -> None:
        gen = IntGenerator()
        constraints = FieldConstraints(
            min=0,
            max=100,
            distribution=Distribution.NORMAL,
            mean=50,
            std=10,
        )
        spec = FieldSpec(name="val", type=FieldType.INT, constraints=constraints)
        rng = Random(42)
        values = [gen.generate(spec, rng) for _ in range(100)]
        avg = sum(values) / len(values)
        # Mean should be roughly 50
        assert 30 < avg < 70
        # All values clamped to range
        assert all(0 <= v <= 100 for v in values)

    def test_exclusive_min_max(self) -> None:
        gen = IntGenerator()
        constraints = FieldConstraints(
            min=10, max=20, exclusive_min=True, exclusive_max=True
        )
        spec = FieldSpec(name="val", type=FieldType.INT, constraints=constraints)
        rng = Random(42)
        for _ in range(50):
            result = gen.generate(spec, rng)
            assert 11 <= result <= 19

    def test_multiple_of(self) -> None:
        gen = IntGenerator()
        constraints = FieldConstraints(min=0, max=100, multiple_of=5)
        spec = FieldSpec(name="val", type=FieldType.INT, constraints=constraints)
        rng = Random(42)
        for _ in range(50):
            result = gen.generate(spec, rng)
            assert result % 5 == 0
            assert 0 <= result <= 100


class TestFloatGenerator:
    """Tests for FloatGenerator."""

    def test_generates_float(self) -> None:
        gen = FloatGenerator()
        spec = FieldSpec(name="price", type=FieldType.FLOAT)
        result = gen.generate(spec, Random(42))
        assert isinstance(result, float)

    def test_respects_range(self) -> None:
        gen = FloatGenerator()
        constraints = FieldConstraints(min=1.0, max=10.0)
        spec = FieldSpec(name="val", type=FieldType.FLOAT, constraints=constraints)
        rng = Random(42)
        for _ in range(50):
            result = gen.generate(spec, rng)
            assert 1.0 <= result <= 10.0

    def test_precision(self) -> None:
        gen = FloatGenerator()
        constraints = FieldConstraints(min=0.0, max=100.0, precision=2)
        spec = FieldSpec(name="val", type=FieldType.FLOAT, constraints=constraints)
        rng = Random(42)
        for _ in range(50):
            result = gen.generate(spec, rng)
            # Check at most 2 decimal places
            assert result == round(result, 2)

    def test_exclusive_min_max(self) -> None:
        gen = FloatGenerator()
        constraints = FieldConstraints(
            min=1.0, max=10.0, exclusive_min=True, exclusive_max=True
        )
        spec = FieldSpec(name="val", type=FieldType.FLOAT, constraints=constraints)
        rng = Random(42)
        for _ in range(50):
            result = gen.generate(spec, rng)
            assert 1.0 < result < 10.0

    def test_multiple_of(self) -> None:
        gen = FloatGenerator()
        constraints = FieldConstraints(min=0.0, max=10.0, multiple_of=0.5)
        spec = FieldSpec(name="val", type=FieldType.FLOAT, constraints=constraints)
        rng = Random(42)
        for _ in range(50):
            result = gen.generate(spec, rng)
            remainder = abs(result - round(result / 0.5) * 0.5)
            assert remainder < 1e-9
            assert 0.0 <= result <= 10.0


class TestBoolGenerator:
    """Tests for BoolGenerator."""

    def test_generates_bool(self) -> None:
        gen = BoolGenerator()
        spec = FieldSpec(name="active", type=FieldType.BOOL)
        result = gen.generate(spec, Random(42))
        assert isinstance(result, bool)

    def test_produces_both_values(self) -> None:
        gen = BoolGenerator()
        spec = FieldSpec(name="flag", type=FieldType.BOOL)
        rng = Random(42)
        values = {gen.generate(spec, rng) for _ in range(20)}
        assert values == {True, False}


class TestDateGenerator:
    """Tests for DateGenerator."""

    def test_generates_iso_date(self) -> None:
        gen = DateGenerator()
        spec = FieldSpec(name="dob", type=FieldType.DATE)
        result = gen.generate(spec, Random(42))
        assert isinstance(result, str)
        assert re.match(r"\d{4}-\d{2}-\d{2}$", result)


class TestDateTimeGenerator:
    """Tests for DateTimeGenerator."""

    def test_generates_iso_datetime(self) -> None:
        gen = DateTimeGenerator()
        spec = FieldSpec(name="created", type=FieldType.DATETIME)
        result = gen.generate(spec, Random(42))
        assert isinstance(result, str)
        assert "T" in result


class TestUUIDGenerator:
    """Tests for UUIDGenerator."""

    def test_generates_uuid_string(self) -> None:
        gen = UUIDGenerator()
        spec = FieldSpec(name="id", type=FieldType.UUID)
        result = gen.generate(spec, Random(42))
        assert isinstance(result, str)
        assert re.match(
            r"[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-"
            r"[89ab][0-9a-f]{3}-[0-9a-f]{12}$",
            result,
        )

    def test_deterministic_with_seed(self) -> None:
        gen = UUIDGenerator()
        spec = FieldSpec(name="id", type=FieldType.UUID)
        r1 = gen.generate(spec, Random(42))
        r2 = gen.generate(spec, Random(42))
        assert r1 == r2


class TestEnumGenerator:
    """Tests for EnumGenerator."""

    def test_generates_from_choices(self) -> None:
        gen = EnumGenerator()
        constraints = FieldConstraints(choices=("a", "b", "c"))
        spec = FieldSpec(name="pick", type=FieldType.ENUM, constraints=constraints)
        rng = Random(42)
        result = gen.generate(spec, rng)
        assert result in ("a", "b", "c")

    def test_no_choices_raises(self) -> None:
        gen = EnumGenerator()
        # Bypass FieldSpec validation for this edge case
        spec = FieldSpec.__new__(FieldSpec)
        object.__setattr__(spec, "name", "x")
        object.__setattr__(spec, "type", FieldType.ENUM)
        object.__setattr__(spec, "constraints", None)
        object.__setattr__(spec, "nullable", False)
        object.__setattr__(spec, "nullable_rate", 0.1)
        object.__setattr__(spec, "children", ())
        object.__setattr__(spec, "description", "")
        with pytest.raises(ValueError, match="no choices"):
            gen.generate(spec, Random(42))


class TestObjectGenerator:
    """Tests for ObjectGenerator."""

    def test_generates_nested_object(self) -> None:
        registry = GeneratorRegistry.default()
        gen = ObjectGenerator(registry)
        spec = FieldSpec(
            name="address",
            type=FieldType.OBJECT,
            children=(
                FieldSpec(name="street", type=FieldType.STRING),
                FieldSpec(name="zip", type=FieldType.STRING),
            ),
        )
        result = gen.generate(spec, Random(42))
        assert isinstance(result, dict)
        assert "street" in result
        assert "zip" in result
        assert isinstance(result["street"], str)


class TestArrayGenerator:
    """Tests for ArrayGenerator."""

    def test_generates_array(self) -> None:
        registry = GeneratorRegistry.default()
        gen = ArrayGenerator(registry)
        constraints = FieldConstraints(min_items=3, max_items=5)
        spec = FieldSpec(
            name="tags",
            type=FieldType.ARRAY,
            constraints=constraints,
            children=(FieldSpec(name="item", type=FieldType.STRING),),
        )
        result = gen.generate(spec, Random(42))
        assert isinstance(result, list)
        assert 3 <= len(result) <= 5
        assert all(isinstance(item, str) for item in result)


class TestGenerationEngine:
    """Tests for GenerationEngine."""

    def test_basic_generation(self) -> None:
        engine = GenerationEngine()
        schema = SchemaSpec(
            name="test",
            fields=(
                FieldSpec(name="id", type=FieldType.UUID),
                FieldSpec(name="name", type=FieldType.STRING),
            ),
        )
        result = engine.generate(schema, count=5, seed=42)
        assert result.count == 5
        assert len(result.records) == 5
        assert result.seed == 42
        assert all("id" in r and "name" in r for r in result.records)

    def test_reproducible_with_seed(self) -> None:
        engine = GenerationEngine()
        schema = SchemaSpec(
            name="test",
            fields=(FieldSpec(name="val", type=FieldType.INT),),
        )
        r1 = engine.generate(schema, count=10, seed=42)
        r2 = engine.generate(schema, count=10, seed=42)
        assert r1.records == r2.records

    def test_different_seeds_different_data(self) -> None:
        engine = GenerationEngine()
        schema = SchemaSpec(
            name="test",
            fields=(FieldSpec(name="val", type=FieldType.INT),),
        )
        r1 = engine.generate(schema, count=10, seed=1)
        r2 = engine.generate(schema, count=10, seed=2)
        assert r1.records != r2.records

    def test_count_zero_raises(self) -> None:
        engine = GenerationEngine()
        schema = SchemaSpec(
            name="test",
            fields=(FieldSpec(name="val", type=FieldType.INT),),
        )
        with pytest.raises(GenerationError, match="count must be at least 1"):
            engine.generate(schema, count=0)

    def test_nullable_fields(self) -> None:
        engine = GenerationEngine()
        schema = SchemaSpec(
            name="test",
            fields=(
                FieldSpec(
                    name="opt",
                    type=FieldType.STRING,
                    nullable=True,
                    nullable_rate=0.5,
                ),
            ),
        )
        result = engine.generate(schema, count=100, seed=42)
        values = [r["opt"] for r in result.records]
        none_count = values.count(None)
        # Should have some nulls but not all
        assert 10 < none_count < 90

    def test_complex_schema(self, order_schema: SchemaSpec) -> None:
        engine = GenerationEngine()
        result = engine.generate(order_schema, count=50, seed=42)
        assert result.count == 50
        for record in result.records:
            assert "order_id" in record
            assert "symbol" in record
            assert record["symbol"] in ("AAPL", "GOOGL", "MSFT", "AMZN")
            assert 1 <= record["quantity"] <= 10000
            assert 1.0 <= record["price"] <= 5000.0
            assert record["side"] in ("buy", "sell")
            assert "timestamp" in record

    def test_duration_tracked(self) -> None:
        engine = GenerationEngine()
        schema = SchemaSpec(
            name="test",
            fields=(FieldSpec(name="val", type=FieldType.INT),),
        )
        result = engine.generate(schema, count=10, seed=42)
        assert result.duration_ms >= 0

    def test_custom_registry(self) -> None:
        registry = GeneratorRegistry()
        registry.register(FieldType.INT, IntGenerator())
        engine = GenerationEngine(registry=registry)
        schema = SchemaSpec(
            name="test",
            fields=(FieldSpec(name="val", type=FieldType.INT),),
        )
        result = engine.generate(schema, count=5, seed=42)
        assert result.count == 5
