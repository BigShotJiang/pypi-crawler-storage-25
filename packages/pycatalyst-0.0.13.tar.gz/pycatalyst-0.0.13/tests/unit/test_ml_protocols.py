"""Tests for pycatalyst.ml._protocols module."""

from __future__ import annotations

from typing import Any

import numpy as np

from pycatalyst.ml._protocols import Engine, ModelArtifact, Preprocessor
from pycatalyst.ml.results import ExperimentResult


class _DummyEngine:
    """Concrete implementation of Engine for testing."""

    name: str = "dummy"

    def train(self, config: Any) -> ExperimentResult:
        return ExperimentResult(name="test", backend="dummy")

    def is_available(self) -> bool:
        return True


class _DummyModel:
    """Concrete implementation of ModelArtifact for testing."""

    def predict(self, data: np.ndarray) -> np.ndarray:
        return data * 2

    def save(self, directory: str) -> dict[str, str]:
        return {"model": f"{directory}/model.bin"}


class _DummyPreprocessor:
    """Concrete implementation of Preprocessor for testing."""

    def fit(self, data: np.ndarray) -> _DummyPreprocessor:
        return self

    def transform(self, data: np.ndarray) -> np.ndarray:
        return data - data.mean()

    def inverse_transform(self, data: np.ndarray) -> np.ndarray:
        return data


class TestEngineProtocol:
    """Tests for Engine protocol runtime checking."""

    def test_isinstance_check(self) -> None:
        engine = _DummyEngine()
        assert isinstance(engine, Engine)

    def test_non_engine_fails(self) -> None:
        assert not isinstance("not an engine", Engine)

    def test_engine_train(self) -> None:
        engine = _DummyEngine()
        result = engine.train({})
        assert isinstance(result, ExperimentResult)

    def test_engine_is_available(self) -> None:
        engine = _DummyEngine()
        assert engine.is_available() is True


class TestModelArtifactProtocol:
    """Tests for ModelArtifact protocol runtime checking."""

    def test_isinstance_check(self) -> None:
        model = _DummyModel()
        assert isinstance(model, ModelArtifact)

    def test_non_model_fails(self) -> None:
        assert not isinstance(42, ModelArtifact)

    def test_predict(self) -> None:
        model = _DummyModel()
        data = np.array([1.0, 2.0, 3.0])
        result = model.predict(data)
        np.testing.assert_array_equal(result, data * 2)

    def test_save(self) -> None:
        model = _DummyModel()
        artifacts = model.save("/tmp/test")
        assert "model" in artifacts


class TestPreprocessorProtocol:
    """Tests for Preprocessor protocol runtime checking."""

    def test_isinstance_check(self) -> None:
        pp = _DummyPreprocessor()
        assert isinstance(pp, Preprocessor)

    def test_non_preprocessor_fails(self) -> None:
        assert not isinstance([], Preprocessor)

    def test_fit_returns_self(self) -> None:
        pp = _DummyPreprocessor()
        result = pp.fit(np.array([1.0, 2.0]))
        assert result is pp

    def test_transform(self) -> None:
        pp = _DummyPreprocessor()
        data = np.array([1.0, 2.0, 3.0])
        transformed = pp.transform(data)
        assert transformed.shape == data.shape
