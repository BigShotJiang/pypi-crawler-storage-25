"""Tests for PanelData class."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from pycatalyst.ml.data import PanelData


@pytest.fixture()
def sample_dfs():
    """Create a dict of sample DataFrames for two symbols."""
    rng = np.random.default_rng(42)
    dates = pd.date_range("2020-01-01", periods=100, freq="min")

    dfs = {}
    for sym in ("AAPL", "MSFT"):
        dfs[sym] = pd.DataFrame(
            {
                "timestamp": dates,
                "feat_a": rng.standard_normal(100),
                "feat_b": rng.standard_normal(100),
                "feat_c": rng.standard_normal(100),
                "ret": rng.standard_normal(100) * 0.01,
            }
        )
    return dfs


class TestPanelDataFromDataframes:
    def test_basic_construction(self, sample_dfs):
        data = PanelData.from_dataframes(sample_dfs, target="ret", sort_by="timestamp")
        assert data.n_symbols == 2
        assert data.n_features == 3
        assert data.total_rows == 200
        assert data.target == "ret"
        assert set(data.symbols) == {"AAPL", "MSFT"}

    def test_explicit_features(self, sample_dfs):
        data = PanelData.from_dataframes(
            sample_dfs,
            target="ret",
            sort_by="timestamp",
            features=["feat_a", "feat_b"],
        )
        assert data.n_features == 2
        assert data.features == ["feat_a", "feat_b"]

    def test_to_arrays(self, sample_dfs):
        data = PanelData.from_dataframes(sample_dfs, target="ret", sort_by="timestamp")
        arrays = data.to_arrays()
        assert set(arrays.keys()) == {"AAPL", "MSFT"}
        feat, tgt = arrays["AAPL"]
        assert feat.shape == (100, 3)
        assert tgt.shape == (100,)
        assert feat.dtype == np.float32
        assert tgt.dtype == np.float32

    def test_get_symbol(self, sample_dfs):
        data = PanelData.from_dataframes(sample_dfs, target="ret", sort_by="timestamp")
        df = data.get_symbol("AAPL")
        assert len(df) == 100
        assert "ret" in df.columns

    def test_get_symbol_unknown_raises(self, sample_dfs):
        data = PanelData.from_dataframes(sample_dfs, target="ret", sort_by="timestamp")
        with pytest.raises(KeyError, match="GOOG"):
            data.get_symbol("GOOG")

    def test_describe(self, sample_dfs):
        data = PanelData.from_dataframes(sample_dfs, target="ret", sort_by="timestamp")
        info = data.describe()
        assert info["n_symbols"] == 2
        assert info["n_features"] == 3
        assert info["total_rows"] == 200
        assert len(info["per_symbol"]) == 2

    def test_memory_usage(self, sample_dfs):
        data = PanelData.from_dataframes(sample_dfs, target="ret", sort_by="timestamp")
        mem = data.memory_usage
        assert "MB" in mem or "GB" in mem

    def test_repr(self, sample_dfs):
        data = PanelData.from_dataframes(sample_dfs, target="ret", sort_by="timestamp")
        r = repr(data)
        assert "PanelData" in r
        assert "n_symbols=2" in r


class TestPanelDataFromDirectory:
    def test_load_from_directory(self, sample_dfs, tmp_path):
        for sym, df in sample_dfs.items():
            df.to_parquet(tmp_path / f"{sym}.parquet", index=False)

        data = PanelData.from_directory(
            tmp_path,
            target="ret",
            sort_by="timestamp",
        )
        assert data.n_symbols == 2
        assert data.total_rows == 200

    def test_missing_directory_raises(self):
        with pytest.raises(FileNotFoundError, match="Directory"):
            PanelData.from_directory(
                "/nonexistent/path",
                target="ret",
                sort_by="ts",
            )

    def test_empty_directory_raises(self, tmp_path):
        with pytest.raises(FileNotFoundError, match="No files"):
            PanelData.from_directory(
                tmp_path,
                target="ret",
                sort_by="ts",
            )


class TestPanelDataFromParquet:
    def test_load_from_single_parquet(self, sample_dfs, tmp_path):
        combined = []
        for sym, df in sample_dfs.items():
            df_copy = df.copy()
            df_copy["symbol"] = sym
            combined.append(df_copy)
        all_df = pd.concat(combined, ignore_index=True)
        path = tmp_path / "all_data.parquet"
        all_df.to_parquet(path, index=False)

        data = PanelData.from_parquet(
            path,
            symbol_column="symbol",
            target="ret",
            sort_by="timestamp",
        )
        assert data.n_symbols == 2
        assert data.total_rows == 200
        assert "symbol" not in data.features

    def test_missing_symbol_column_raises(self, sample_dfs, tmp_path):
        df = next(iter(sample_dfs.values()))
        path = tmp_path / "data.parquet"
        df.to_parquet(path, index=False)
        with pytest.raises(ValueError, match="Symbol column"):
            PanelData.from_parquet(
                path,
                symbol_column="nonexistent",
                target="ret",
            )


class TestPanelDataValidation:
    def test_empty_data_raises(self):
        with pytest.raises(ValueError, match="non-empty"):
            PanelData({}, target="ret")

    def test_missing_target_raises(self, sample_dfs):
        with pytest.raises(ValueError, match="Target column"):
            PanelData(sample_dfs, target="nonexistent")
