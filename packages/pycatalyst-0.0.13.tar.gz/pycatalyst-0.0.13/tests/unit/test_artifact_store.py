"""Unit tests for artifact backend delegation, S3 store (mocked), and protocol."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from pycatalyst.catalyst_store import InMemoryCatalystStore
from pycatalyst.catalyst_store._artifact_protocol import ArtifactBackend

# ---------------------------------------------------------------------------
# Protocol conformance
# ---------------------------------------------------------------------------


class TestArtifactBackendProtocol:
    """ArtifactBackend is a runtime-checkable protocol."""

    def test_inmemory_satisfies_protocol(self) -> None:
        store = InMemoryCatalystStore()
        assert isinstance(store, ArtifactBackend)

    def test_custom_class_satisfies_protocol(self) -> None:
        class _Custom:
            def store_artifact(self, eid: str, n: str, d: bytes) -> str:
                return "ok"

            def get_artifact(self, eid: str, n: str) -> bytes | None:
                return None

            def list_artifacts(self, eid: str) -> list[str]:
                return []

            def delete_artifact(self, eid: str, n: str) -> bool:
                return False

        assert isinstance(_Custom(), ArtifactBackend)

    def test_non_conforming_class_fails(self) -> None:
        class _Bad:
            pass

        assert not isinstance(_Bad(), ArtifactBackend)


# ---------------------------------------------------------------------------
# Delegation
# ---------------------------------------------------------------------------


class TestArtifactDelegation:
    """CatalystStoreClient delegates to artifact_backend when set."""

    @pytest.fixture()
    def store(self) -> InMemoryCatalystStore:
        s = InMemoryCatalystStore()
        s.connect()
        return s

    @pytest.fixture()
    def mock_backend(self) -> MagicMock:
        backend = MagicMock(spec=ArtifactBackend)
        backend.store_artifact.return_value = "s3://bucket/key"
        backend.get_artifact.return_value = b"remote-data"
        backend.list_artifacts.return_value = ["a.pt", "b.json"]
        backend.delete_artifact.return_value = True
        return backend

    def test_store_delegates(
        self, store: InMemoryCatalystStore, mock_backend: MagicMock
    ) -> None:
        store.artifact_backend = mock_backend
        result = store.store_artifact("exp1", "model.pt", b"data")
        assert result == "s3://bucket/key"
        mock_backend.store_artifact.assert_called_once_with("exp1", "model.pt", b"data")

    def test_get_delegates(
        self, store: InMemoryCatalystStore, mock_backend: MagicMock
    ) -> None:
        store.artifact_backend = mock_backend
        result = store.get_artifact("exp1", "model.pt")
        assert result == b"remote-data"
        mock_backend.get_artifact.assert_called_once_with("exp1", "model.pt")

    def test_list_delegates(
        self, store: InMemoryCatalystStore, mock_backend: MagicMock
    ) -> None:
        store.artifact_backend = mock_backend
        result = store.list_artifacts("exp1")
        assert result == ["a.pt", "b.json"]
        mock_backend.list_artifacts.assert_called_once_with("exp1")

    def test_delete_delegates(
        self, store: InMemoryCatalystStore, mock_backend: MagicMock
    ) -> None:
        store.artifact_backend = mock_backend
        result = store.delete_artifact("exp1", "model.pt")
        assert result is True
        mock_backend.delete_artifact.assert_called_once_with("exp1", "model.pt")

    def test_native_when_no_backend(self, store: InMemoryCatalystStore) -> None:
        """Without a backend, calls go to native InMemory implementation."""
        assert store.artifact_backend is None
        store.store_artifact("exp1", "model.pt", b"native")
        assert store.get_artifact("exp1", "model.pt") == b"native"

    def test_reset_backend_to_none(
        self, store: InMemoryCatalystStore, mock_backend: MagicMock
    ) -> None:
        store.artifact_backend = mock_backend
        store.artifact_backend = None
        # Now should go to native
        store.store_artifact("exp1", "model.pt", b"native")
        assert store.get_artifact("exp1", "model.pt") == b"native"
        mock_backend.store_artifact.assert_not_called()


# ---------------------------------------------------------------------------
# S3ArtifactStore (mocked boto3)
# ---------------------------------------------------------------------------


class TestS3ArtifactStore:
    """S3ArtifactStore with mocked boto3 client."""

    @pytest.fixture()
    def s3_store(self):
        with patch("pycatalyst.catalyst_store.s3.boto3") as mock_boto3:
            mock_client = MagicMock()
            mock_boto3.client.return_value = mock_client
            from pycatalyst.catalyst_store.s3 import S3ArtifactStore

            store = S3ArtifactStore(bucket="test-bucket", prefix="art/")
            yield store, mock_client

    def test_store_artifact(self, s3_store) -> None:
        store, client = s3_store
        result = store.store_artifact("exp1", "model.pt", b"weights")
        assert result == "art/exp1/model.pt"
        client.put_object.assert_called_once_with(
            Bucket="test-bucket",
            Key="art/exp1/model.pt",
            Body=b"weights",
        )

    def test_get_artifact(self, s3_store) -> None:
        store, client = s3_store
        body_mock = MagicMock()
        body_mock.read.return_value = b"weights"
        client.get_object.return_value = {"Body": body_mock}

        result = store.get_artifact("exp1", "model.pt")
        assert result == b"weights"
        client.get_object.assert_called_once_with(
            Bucket="test-bucket",
            Key="art/exp1/model.pt",
        )

    def test_get_artifact_not_found(self, s3_store) -> None:
        store, client = s3_store
        from pycatalyst.catalyst_store.s3 import ClientError

        client.get_object.side_effect = ClientError(
            {"Error": {"Code": "NoSuchKey", "Message": ""}},
            "GetObject",
        )
        result = store.get_artifact("exp1", "missing.pt")
        assert result is None

    def test_list_artifacts(self, s3_store) -> None:
        store, client = s3_store
        paginator = MagicMock()
        client.get_paginator.return_value = paginator
        paginator.paginate.return_value = [
            {
                "Contents": [
                    {"Key": "art/exp1/model.pt"},
                    {"Key": "art/exp1/config.json"},
                ]
            },
        ]
        result = store.list_artifacts("exp1")
        assert result == ["config.json", "model.pt"]

    def test_delete_artifact(self, s3_store) -> None:
        store, client = s3_store
        client.head_object.return_value = {}
        result = store.delete_artifact("exp1", "model.pt")
        assert result is True
        client.delete_object.assert_called_once_with(
            Bucket="test-bucket",
            Key="art/exp1/model.pt",
        )

    def test_delete_artifact_not_found(self, s3_store) -> None:
        store, client = s3_store
        from pycatalyst.catalyst_store.s3 import ClientError

        client.head_object.side_effect = ClientError(
            {"Error": {"Code": "404", "Message": ""}},
            "HeadObject",
        )
        result = store.delete_artifact("exp1", "missing.pt")
        assert result is False

    def test_bucket_required(self) -> None:
        with patch("pycatalyst.catalyst_store.s3.boto3"):
            from pycatalyst.catalyst_store.s3 import S3ArtifactStore

            with pytest.raises(ValueError, match="bucket is required"):
                S3ArtifactStore(bucket="")

    def test_default_prefix(self) -> None:
        with patch("pycatalyst.catalyst_store.s3.boto3") as mock_boto3:
            mock_boto3.client.return_value = MagicMock()
            from pycatalyst.catalyst_store.s3 import S3ArtifactStore

            store = S3ArtifactStore(bucket="b")
            assert store._prefix == "artifacts/"
