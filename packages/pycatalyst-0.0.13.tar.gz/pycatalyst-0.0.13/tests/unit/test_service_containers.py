"""Tests for ServiceContainerManager — types, lifecycle, and robustness."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from pycatalyst.errors import ServiceError
from pycatalyst.services.service_containers import (
    DockerAPIError,
    DockerImageNotFound,
    ServiceConfig,
    ServiceContainerManager,
    ServiceInfo,
    ServiceStatus,
    ServiceType,
    _build_urls,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _mock_client(
    *,
    containers: list | None = None,
    image_not_found: bool = False,
    api_error: bool = False,
) -> MagicMock:
    """Create a mock docker client."""
    client = MagicMock()

    # containers.list returns empty by default (no orphans)
    client.containers.list.return_value = containers or []

    # networks.create returns a mock network
    network = MagicMock()
    network.name = "pycatalyst-net-test123"
    client.networks.create.return_value = network
    client.networks.list.return_value = []

    if image_not_found:
        client.containers.run.side_effect = DockerImageNotFound("not found")
    elif api_error:
        client.containers.run.side_effect = DockerAPIError("api error")
    else:
        container = _mock_container()
        client.containers.run.return_value = container

    return client


def _mock_container(
    *,
    status: str = "running",
    health_status: str = "healthy",
    short_id: str = "abc123",
    name: str = "pycatalyst-svc-postgres-test123",
    host_port: int = 54321,
    labels: dict | None = None,
) -> MagicMock:
    """Create a mock Docker container."""
    container = MagicMock()
    container.short_id = short_id
    container.name = name
    container.status = status
    container.labels = labels or {}

    container.attrs = {
        "State": {
            "Health": {"Status": health_status},
        },
        "NetworkSettings": {
            "Ports": {
                "5432/tcp": [{"HostPort": str(host_port)}],
            },
        },
    }

    container.reload = MagicMock()
    container.stop = MagicMock()
    container.remove = MagicMock()

    return container


def _make_postgres_config(**kwargs) -> ServiceConfig:
    """Create a Postgres ServiceConfig with defaults."""
    defaults = {
        "service_type": ServiceType.POSTGRES,
        "database": "testdb",
        "username": "testuser",
        "password": "testpass",
    }
    defaults.update(kwargs)
    return ServiceConfig(**defaults)


def _make_mongodb_config(**kwargs) -> ServiceConfig:
    """Create a MongoDB ServiceConfig with defaults."""
    defaults = {
        "service_type": ServiceType.MONGODB,
        "database": "testdb",
        "username": "testuser",
        "password": "testpass",
    }
    defaults.update(kwargs)
    return ServiceConfig(**defaults)


# ---------------------------------------------------------------------------
# Types and serialisation
# ---------------------------------------------------------------------------


class TestServiceConfig:
    """Tests for ServiceConfig dataclass."""

    def test_defaults(self) -> None:
        cfg = ServiceConfig(service_type=ServiceType.POSTGRES)
        assert cfg.database == "pycatalyst_db"
        assert cfg.username == "pycatalyst"
        assert cfg.password == "pycatalyst_dev"
        assert cfg.image == ""
        assert cfg.mem_limit == ""

    def test_custom_values(self) -> None:
        cfg = _make_postgres_config(image="postgres:15")
        assert cfg.image == "postgres:15"
        assert cfg.database == "testdb"

    def test_frozen(self) -> None:
        cfg = _make_postgres_config()
        with pytest.raises(AttributeError):
            cfg.database = "other"  # type: ignore[misc]


class TestServiceInfo:
    """Tests for ServiceInfo dataclass."""

    def test_to_dict(self) -> None:
        cfg = _make_postgres_config()
        info = ServiceInfo(
            service_id="svc123",
            env_id="env456",
            service_type=ServiceType.POSTGRES,
            config=cfg,
            status=ServiceStatus.HEALTHY,
            host_url="postgresql://u:p@localhost:5432/db",
            container_url="postgresql://u:p@cname:5432/db",
            host_port=54321,
            container_name="pycatalyst-svc-postgres-env456",
            container_id="abc123",
        )

        d = info.to_dict()
        assert d["service_id"] == "svc123"
        assert d["env_id"] == "env456"
        assert d["service_type"] == "postgres"
        assert d["status"] == "healthy"
        assert d["host_port"] == 54321
        assert d["database"] == "testdb"
        assert d["username"] == "testuser"
        assert isinstance(d["created_at"], float)

    def test_defaults(self) -> None:
        cfg = _make_postgres_config()
        info = ServiceInfo(
            service_id="x",
            env_id="y",
            service_type=ServiceType.POSTGRES,
            config=cfg,
        )
        assert info.status == ServiceStatus.CREATING
        assert info.error_message == ""
        assert info.host_port == 0


class TestBuildUrls:
    """Tests for connection URL generation."""

    def test_postgres_urls(self) -> None:
        cfg = _make_postgres_config()
        host, container = _build_urls(
            ServiceType.POSTGRES, cfg, "mycontainer", 54321, 5432
        )
        assert host == "postgresql://testuser:testpass@localhost:54321/testdb"
        assert container == "postgresql://testuser:testpass@mycontainer:5432/testdb"

    def test_mongodb_urls(self) -> None:
        cfg = _make_mongodb_config()
        host, container = _build_urls(
            ServiceType.MONGODB, cfg, "mongobox", 27018, 27017
        )
        assert "mongodb://" in host
        assert "localhost:27018" in host
        assert "authSource=admin" in host
        assert "mongobox:27017" in container


# ---------------------------------------------------------------------------
# ServiceContainerManager — happy path
# ---------------------------------------------------------------------------


class TestServiceContainerManagerCreate:
    """Happy-path tests for creating services."""

    @pytest.mark.asyncio
    async def test_create_postgres_service(self) -> None:
        client = _mock_client()
        mgr = ServiceContainerManager(client)

        cfg = _make_postgres_config()
        svc = await mgr.create_service("env1", cfg)

        assert svc.service_type == ServiceType.POSTGRES
        assert svc.env_id == "env1"
        assert svc.status == ServiceStatus.HEALTHY
        assert svc.host_port > 0
        assert "postgresql://" in svc.host_url
        assert "postgresql://" in svc.container_url
        client.containers.run.assert_called_once()

    @pytest.mark.asyncio
    async def test_create_mongodb_service(self) -> None:
        client = _mock_client()
        # Override port bindings for MongoDB
        container = _mock_container(host_port=27018)
        container.attrs["NetworkSettings"]["Ports"] = {
            "27017/tcp": [{"HostPort": "27018"}],
        }
        client.containers.run.return_value = container

        mgr = ServiceContainerManager(client)
        cfg = _make_mongodb_config()
        svc = await mgr.create_service("env1", cfg)

        assert svc.service_type == ServiceType.MONGODB
        assert "mongodb://" in svc.host_url
        assert svc.host_port == 27018

    @pytest.mark.asyncio
    async def test_create_sets_labels(self) -> None:
        client = _mock_client()
        mgr = ServiceContainerManager(client)

        cfg = _make_postgres_config()
        svc = await mgr.create_service("env1", cfg)

        call_kwargs = client.containers.run.call_args
        labels = call_kwargs.kwargs.get("labels", {})
        assert labels["pycatalyst.service"] == "true"
        assert labels["pycatalyst.env_id"] == "env1"
        assert labels["pycatalyst.service_type"] == "postgres"
        assert labels["pycatalyst.service_id"] == svc.service_id

    @pytest.mark.asyncio
    async def test_create_sets_restart_policy(self) -> None:
        client = _mock_client()
        mgr = ServiceContainerManager(client)

        await mgr.create_service("env1", _make_postgres_config())
        call_kwargs = client.containers.run.call_args
        assert call_kwargs.kwargs["restart_policy"] == {"Name": "unless-stopped"}

    @pytest.mark.asyncio
    async def test_create_sets_healthcheck(self) -> None:
        client = _mock_client()
        mgr = ServiceContainerManager(client)

        await mgr.create_service("env1", _make_postgres_config())
        call_kwargs = client.containers.run.call_args
        hc = call_kwargs.kwargs.get("healthcheck", {})
        assert "pg_isready" in hc["test"][1]


# ---------------------------------------------------------------------------
# Idempotency and limits
# ---------------------------------------------------------------------------


class TestServiceContainerManagerIdempotency:
    """Tests for idempotent creation and resource limits."""

    @pytest.mark.asyncio
    async def test_idempotent_same_type_returns_existing(self) -> None:
        client = _mock_client()
        mgr = ServiceContainerManager(client)

        cfg = _make_postgres_config()
        svc1 = await mgr.create_service("env1", cfg)
        svc2 = await mgr.create_service("env1", cfg)

        assert svc1.service_id == svc2.service_id
        assert client.containers.run.call_count == 1

    @pytest.mark.asyncio
    async def test_different_type_creates_new(self) -> None:
        client = _mock_client()

        # Second container for MongoDB
        mongo_container = _mock_container(
            short_id="def456",
            name="pycatalyst-svc-mongodb-env1",
            host_port=27018,
        )
        mongo_container.attrs["NetworkSettings"]["Ports"] = {
            "27017/tcp": [{"HostPort": "27018"}],
        }
        client.containers.run.side_effect = [
            _mock_container(),
            mongo_container,
        ]

        mgr = ServiceContainerManager(client)
        pg = await mgr.create_service("env1", _make_postgres_config())
        mongo = await mgr.create_service("env1", _make_mongodb_config())

        assert pg.service_id != mongo.service_id
        assert client.containers.run.call_count == 2

    @pytest.mark.asyncio
    async def test_max_services_per_env_enforced(self) -> None:
        client = _mock_client()
        mgr = ServiceContainerManager(client)

        with patch(
            "pycatalyst.config.workbench.get_service_max_per_env",
            return_value=1,
        ):
            await mgr.create_service("env1", _make_postgres_config())

            with pytest.raises(ServiceError, match="Maximum services"):
                await mgr.create_service("env1", _make_mongodb_config())


# ---------------------------------------------------------------------------
# Failure and rollback
# ---------------------------------------------------------------------------


class TestServiceContainerManagerFailures:
    """Tests for error handling and rollback on failure."""

    @pytest.mark.asyncio
    async def test_image_not_found_raises_service_error(self) -> None:
        client = _mock_client(image_not_found=True)
        mgr = ServiceContainerManager(client)

        with pytest.raises(ServiceError, match="not found"):
            await mgr.create_service("env1", _make_postgres_config())

        # No orphan service in tracking
        assert len(mgr.list_services()) == 0

    @pytest.mark.asyncio
    async def test_api_error_raises_service_error(self) -> None:
        client = _mock_client(api_error=True)
        mgr = ServiceContainerManager(client)

        with pytest.raises(ServiceError, match="Docker API error"):
            await mgr.create_service("env1", _make_postgres_config())

        assert len(mgr.list_services()) == 0

    @pytest.mark.asyncio
    async def test_health_timeout_cleans_up(self) -> None:
        client = _mock_client()
        # Make health check always return "starting"
        container = _mock_container(health_status="starting")
        client.containers.run.return_value = container

        mgr = ServiceContainerManager(client)

        with pytest.raises(ServiceError, match="healthy"):
            await mgr.create_service("env1", _make_postgres_config())

        # Container should have been cleaned up
        container.stop.assert_called()
        container.remove.assert_called()
        assert len(mgr.list_services()) == 0


# ---------------------------------------------------------------------------
# Destruction
# ---------------------------------------------------------------------------


class TestServiceContainerManagerDestroy:
    """Tests for service destruction."""

    @pytest.mark.asyncio
    async def test_destroy_service(self) -> None:
        client = _mock_client()
        mgr = ServiceContainerManager(client)

        svc = await mgr.create_service("env1", _make_postgres_config())
        assert len(mgr.list_services()) == 1

        await mgr.destroy_service(svc.service_id)
        assert len(mgr.list_services()) == 0

    @pytest.mark.asyncio
    async def test_destroy_nonexistent_is_noop(self) -> None:
        client = _mock_client()
        mgr = ServiceContainerManager(client)

        # Should not raise
        await mgr.destroy_service("nonexistent")

    @pytest.mark.asyncio
    async def test_destroy_all_for_env(self) -> None:
        client = _mock_client()
        second_container = _mock_container(short_id="xyz789", host_port=27018)
        second_container.attrs["NetworkSettings"]["Ports"] = {
            "27017/tcp": [{"HostPort": "27018"}],
        }
        client.containers.run.side_effect = [
            _mock_container(),
            second_container,
        ]

        mgr = ServiceContainerManager(client)

        await mgr.create_service("env1", _make_postgres_config())
        await mgr.create_service("env1", _make_mongodb_config())
        assert len(mgr.list_services("env1")) == 2

        await mgr.destroy_all_for_env("env1")
        assert len(mgr.list_services("env1")) == 0

    @pytest.mark.asyncio
    async def test_destroy_resilient_to_stop_failure(self) -> None:
        client = _mock_client()
        container = _mock_container()
        container.stop.side_effect = Exception("stop failed")
        client.containers.run.return_value = container

        mgr = ServiceContainerManager(client)
        svc = await mgr.create_service("env1", _make_postgres_config())

        # Should not raise even though stop fails
        await mgr.destroy_service(svc.service_id)
        assert len(mgr.list_services()) == 0
        container.remove.assert_called()


# ---------------------------------------------------------------------------
# Query
# ---------------------------------------------------------------------------


class TestServiceContainerManagerQuery:
    """Tests for get/list/refresh operations."""

    @pytest.mark.asyncio
    async def test_list_services_with_env_filter(self) -> None:
        client = _mock_client()
        mgr = ServiceContainerManager(client)

        await mgr.create_service("env1", _make_postgres_config())

        assert len(mgr.list_services("env1")) == 1
        assert len(mgr.list_services("env2")) == 0
        assert len(mgr.list_services()) == 1

    @pytest.mark.asyncio
    async def test_get_service(self) -> None:
        client = _mock_client()
        mgr = ServiceContainerManager(client)

        svc = await mgr.create_service("env1", _make_postgres_config())

        result = mgr.get_service(svc.service_id)
        assert result is not None
        assert result.service_id == svc.service_id

    def test_get_nonexistent_returns_none(self) -> None:
        client = _mock_client()
        mgr = ServiceContainerManager(client)
        assert mgr.get_service("nonexistent") is None

    @pytest.mark.asyncio
    async def test_refresh_status_maps_running_healthy(self) -> None:
        client = _mock_client()
        mgr = ServiceContainerManager(client)

        svc = await mgr.create_service("env1", _make_postgres_config())
        status = mgr.refresh_status(svc.service_id)
        assert status == ServiceStatus.HEALTHY

    def test_refresh_nonexistent_returns_none(self) -> None:
        client = _mock_client()
        mgr = ServiceContainerManager(client)
        assert mgr.refresh_status("nonexistent") is None


# ---------------------------------------------------------------------------
# Orphan recovery
# ---------------------------------------------------------------------------


class TestOrphanRecovery:
    """Tests for _recover_orphans on startup."""

    def test_recovers_labeled_containers(self) -> None:
        orphan = _mock_container(
            status="running",
            health_status="healthy",
            labels={
                "pycatalyst.service": "true",
                "pycatalyst.env_id": "env1",
                "pycatalyst.service_type": "postgres",
                "pycatalyst.service_id": "svc999",
            },
        )
        client = _mock_client(containers=[orphan])

        mgr = ServiceContainerManager(client)

        services = mgr.list_services()
        assert len(services) == 1
        assert services[0].service_id == "svc999"
        assert services[0].status == ServiceStatus.HEALTHY

    def test_removes_unlabelled_orphans(self) -> None:
        orphan = _mock_container(
            labels={"pycatalyst.service": "true"},  # Missing env_id, etc.
        )
        client = _mock_client(containers=[orphan])

        mgr = ServiceContainerManager(client)

        assert len(mgr.list_services()) == 0
        orphan.remove.assert_called()

    def test_handles_docker_unreachable(self) -> None:
        client = MagicMock()
        client.containers.list.side_effect = Exception("unreachable")

        # Should not raise
        mgr = ServiceContainerManager(client)
        assert len(mgr.list_services()) == 0


# ---------------------------------------------------------------------------
# Network management
# ---------------------------------------------------------------------------


class TestNetworkManagement:
    """Tests for ensure_network and network cleanup."""

    def test_ensure_network_creates_once(self) -> None:
        client = _mock_client()
        mgr = ServiceContainerManager(client)

        net1 = mgr.ensure_network("env1")
        net2 = mgr.ensure_network("env1")

        assert net1 is net2
        client.networks.create.assert_called_once()

    def test_ensure_network_different_envs(self) -> None:
        client = _mock_client()
        mgr = ServiceContainerManager(client)

        mgr.ensure_network("env1")
        mgr.ensure_network("env2")

        assert client.networks.create.call_count == 2


# ---------------------------------------------------------------------------
# Shutdown
# ---------------------------------------------------------------------------


class TestServiceContainerManagerShutdown:
    """Tests for shutdown lifecycle."""

    @pytest.mark.asyncio
    async def test_shutdown_stops_all(self) -> None:
        client = _mock_client()
        container = _mock_container()
        client.containers.run.return_value = container

        mgr = ServiceContainerManager(client)
        await mgr.create_service("env1", _make_postgres_config())

        assert len(mgr.list_services()) == 1

        mgr.shutdown()

        assert len(mgr.list_services()) == 0
        container.stop.assert_called()
        container.remove.assert_called()

    @pytest.mark.asyncio
    async def test_shutdown_continues_on_failure(self) -> None:
        client = _mock_client()
        container = _mock_container()
        container.stop.side_effect = Exception("fail")
        client.containers.run.return_value = container

        mgr = ServiceContainerManager(client)
        await mgr.create_service("env1", _make_postgres_config())

        # Should not raise
        mgr.shutdown()
        assert len(mgr.list_services()) == 0


# ---------------------------------------------------------------------------
# Health check polling
# ---------------------------------------------------------------------------


class TestHealthCheck:
    """Tests for wait_healthy with exponential backoff."""

    @pytest.mark.asyncio
    async def test_healthy_immediately(self) -> None:
        client = _mock_client()
        mgr = ServiceContainerManager(client)

        svc = await mgr.create_service("env1", _make_postgres_config())
        assert svc.status == ServiceStatus.HEALTHY

    @pytest.mark.asyncio
    async def test_wait_healthy_returns_false_on_unhealthy(self) -> None:
        client = _mock_client()
        container = _mock_container(health_status="unhealthy")
        client.containers.run.return_value = container

        mgr = ServiceContainerManager(client)

        # Manually register a service for health check test
        cfg = _make_postgres_config()
        info = ServiceInfo(
            service_id="test1",
            env_id="env1",
            service_type=ServiceType.POSTGRES,
            config=cfg,
            status=ServiceStatus.STARTING,
        )
        mgr._services["test1"] = info
        mgr._containers["test1"] = container

        result = await mgr.wait_healthy("test1", timeout=2)
        assert result is False
        assert info.status == ServiceStatus.UNHEALTHY

    @pytest.mark.asyncio
    async def test_wait_healthy_nonexistent(self) -> None:
        client = _mock_client()
        mgr = ServiceContainerManager(client)

        result = await mgr.wait_healthy("nonexistent", timeout=1)
        assert result is False
