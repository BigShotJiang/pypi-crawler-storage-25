"""Tests for the panel data pipeline (prepare_panel_temporal)."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from pycatalyst.ml.data import PanelData
from pycatalyst.ml.pytorch.data.panel import PanelSplits, prepare_panel_temporal


@pytest.fixture()
def panel_data():
    rng = np.random.default_rng(42)
    dfs = {}
    for sym in ("AAPL", "MSFT", "GOOG"):
        dfs[sym] = pd.DataFrame(
            {
                "timestamp": pd.date_range("2020-01-01", periods=200, freq="min"),
                "feat_a": rng.standard_normal(200),
                "feat_b": rng.standard_normal(200),
                "ret": rng.standard_normal(200) * 0.01,
            }
        )
    return PanelData.from_dataframes(dfs, target="ret", sort_by="timestamp")


@pytest.fixture()
def minimal_config():
    """Build a minimal PytorchExperimentConfig for panel mode."""
    from pycatalyst.ml.pytorch.config import PytorchExperimentConfig

    raw = {
        "experiment": {
            "name": "test-panel",
            "backend": "pytorch",
            "seed": 42,
            "output_dir": "./test_runs",
        },
        "data": {
            "format": "panel",
            "target": "ret",
            "panel": {
                "directory": "/fake/path",
                "sort_column": "timestamp",
            },
            "split": {"train": 0.7, "val": 0.15, "test": 0.15},
            "scaler": "standard",
            "scale_per_symbol": True,
            "training_mode": "shared",
            "sequence_length": 10,
            "stride": 1,
        },
        "model": {"architecture": "lstm", "params": {"hidden_size": 16}},
        "training": {"epochs": 2, "batch_size": 16},
    }
    return PytorchExperimentConfig.from_raw(raw)


class TestPrepareShared:
    def test_returns_panel_splits(self, minimal_config, panel_data):
        splits = prepare_panel_temporal(minimal_config, panel_data=panel_data)
        assert isinstance(splits, PanelSplits)

    def test_splits_have_data(self, minimal_config, panel_data):
        splits = prepare_panel_temporal(minimal_config, panel_data=panel_data)
        assert len(splits.train_loader) > 0
        assert len(splits.val_loader) > 0
        assert len(splits.test_loader) > 0

    def test_loader_batch_shape(self, minimal_config, panel_data):
        splits = prepare_panel_temporal(minimal_config, panel_data=panel_data)
        x, y = next(iter(splits.train_loader))
        assert x.ndim == 3
        assert x.shape[1] == 10  # seq_len
        assert x.shape[2] == 2  # n_features (feat_a, feat_b)
        assert y.ndim == 2

    def test_input_size(self, minimal_config, panel_data):
        splits = prepare_panel_temporal(minimal_config, panel_data=panel_data)
        assert splits.input_size == 2

    def test_symbols_all_present(self, minimal_config, panel_data):
        splits = prepare_panel_temporal(minimal_config, panel_data=panel_data)
        assert set(splits.symbols) == {"AAPL", "GOOG", "MSFT"}


class TestPreparePerSymbol:
    def test_returns_dict(self, minimal_config, panel_data):
        minimal_config.data.training_mode = "per_symbol"
        result = prepare_panel_temporal(minimal_config, panel_data=panel_data)
        assert isinstance(result, dict)
        assert set(result.keys()) == {"AAPL", "GOOG", "MSFT"}

    def test_each_entry_is_splits(self, minimal_config, panel_data):
        minimal_config.data.training_mode = "per_symbol"
        result = prepare_panel_temporal(minimal_config, panel_data=panel_data)
        for _sym, splits in result.items():
            assert isinstance(splits, PanelSplits)
            assert len(splits.train_loader) > 0


class TestPrepareGlobalScaler:
    def test_global_scaling(self, minimal_config, panel_data):
        minimal_config.data.scale_per_symbol = False
        splits = prepare_panel_temporal(minimal_config, panel_data=panel_data)
        assert isinstance(splits, PanelSplits)
        assert len(splits.train_loader) > 0
