"""Tests for pycatalyst.ml.registry module."""

from __future__ import annotations

import pytest

from pycatalyst.ml.registry import list_architectures, list_backends


class TestListBackends:
    """Tests for list_backends() function."""

    def test_returns_list(self) -> None:
        result = list_backends()
        assert isinstance(result, list)

    def test_sklearn_available(self) -> None:
        # sklearn should be installed in test env
        backends = list_backends()
        assert "sklearn" in backends

    def test_sorted(self) -> None:
        backends = list_backends()
        assert backends == sorted(backends)


class TestListArchitectures:
    """Tests for list_architectures() function."""

    def test_returns_dict(self) -> None:
        result = list_architectures()
        assert isinstance(result, dict)

    def test_sklearn_architectures(self) -> None:
        result = list_architectures("sklearn")
        assert "sklearn" in result
        archs = result["sklearn"]
        assert isinstance(archs, list)
        assert "linear_regression" in archs
        assert "ridge" in archs

    def test_all_backends(self) -> None:
        result = list_architectures()
        # At minimum sklearn should be present
        assert "sklearn" in result

    def test_unknown_backend_raises(self) -> None:
        with pytest.raises(ValueError, match="Unknown backend"):
            list_architectures("tensorflow")

    def test_sklearn_archs_are_sorted(self) -> None:
        result = list_architectures("sklearn")
        archs = result["sklearn"]
        assert archs == sorted(archs)
