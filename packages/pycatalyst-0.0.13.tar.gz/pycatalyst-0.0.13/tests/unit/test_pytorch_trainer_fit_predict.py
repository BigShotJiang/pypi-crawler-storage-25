"""Tests for PytorchTrainer.fit(), predict(), save(), and load()."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pytest

from pycatalyst.ml.trainers.pytorch import PytorchTrainer


@pytest.fixture()
def tabular_data():
    """Simple 2-D tabular dataset for MLP."""
    rng = np.random.default_rng(42)
    X = rng.standard_normal((200, 10)).astype(np.float32)
    y = (X[:, 0] * 2 + X[:, 1] * -1 + rng.standard_normal(200) * 0.1).astype(np.float32)
    return X, y


@pytest.fixture()
def temporal_data_3d():
    """Pre-windowed 3-D dataset for LSTM."""
    rng = np.random.default_rng(42)
    X = rng.standard_normal((100, 10, 5)).astype(np.float32)
    y = rng.standard_normal(100).astype(np.float32)
    return X, y


class TestFitArraysTabular:
    """Test fit(X, y) with tabular (MLP) architecture."""

    def test_fit_returns_self(self, tabular_data):
        X, y = tabular_data
        t = PytorchTrainer(architecture="MLPRegressor", epochs=2, patience=5)
        result = t.fit(X, y)
        assert result is t

    def test_fitted_state_set(self, tabular_data):
        X, y = tabular_data
        t = PytorchTrainer(architecture="MLPRegressor", epochs=2, patience=5)
        t.fit(X, y)
        assert t.is_fitted
        assert t.model_ is not None
        assert t.scaler_ is not None
        assert t.result_ is not None
        assert t.result_.backend == "pytorch"

    def test_predict_after_fit(self, tabular_data):
        X, y = tabular_data
        t = PytorchTrainer(architecture="MLPRegressor", epochs=2, patience=5)
        t.fit(X, y)
        preds = t.predict(X[:10])
        assert isinstance(preds, np.ndarray)
        assert preds.shape[0] == 10

    def test_score_after_fit(self, tabular_data):
        X, y = tabular_data
        t = PytorchTrainer(architecture="MLPRegressor", epochs=2, patience=5)
        t.fit(X, y)
        score = t.score(X, y)
        assert isinstance(score, float)
        assert score != float("-inf")


class TestFitArraysTemporal:
    """Test fit(X, y) with temporal (LSTM) architecture."""

    def test_fit_3d_input(self, temporal_data_3d):
        X, y = temporal_data_3d
        t = PytorchTrainer(
            architecture="lstm", epochs=2, patience=5, params={"hidden_size": 16}
        )
        t.fit(X, y)
        assert t.is_fitted

    def test_fit_2d_with_sequence_length(self, tabular_data):
        X, y = tabular_data
        t = PytorchTrainer(
            architecture="lstm", epochs=2, patience=5, params={"hidden_size": 16}
        )
        t.fit(X, y, sequence_length=10)
        assert t.is_fitted

    def test_fit_2d_without_sequence_length_raises(self, tabular_data):
        X, y = tabular_data
        t = PytorchTrainer(architecture="lstm", epochs=2, patience=5)
        with pytest.raises(ValueError, match="sequence_length"):
            t.fit(X, y)


class TestFitWithValidation:
    """Test fit with explicit validation data."""

    def test_explicit_val_set(self, tabular_data):
        X, y = tabular_data
        X_train, X_val = X[:160], X[160:]
        y_train, y_val = y[:160], y[160:]
        t = PytorchTrainer(architecture="MLPRegressor", epochs=2, patience=5)
        t.fit(X_train, y_train, X_val=X_val, y_val=y_val)
        assert t.is_fitted
        preds = t.predict(X_val)
        assert preds.shape[0] == 40


class TestSaveLoad:
    """Test save/load round-trip."""

    def test_save_creates_files(self, tabular_data, tmp_path):
        X, y = tabular_data
        t = PytorchTrainer(architecture="MLPRegressor", epochs=2, patience=5)
        t.fit(X, y)
        paths = t.save(tmp_path / "model")
        assert "trainer_config" in paths
        assert Path(paths["trainer_config"]).exists()

    def test_load_restores_state(self, tabular_data, tmp_path):
        X, y = tabular_data
        t = PytorchTrainer(architecture="MLPRegressor", epochs=2, patience=5)
        t.fit(X, y)
        save_dir = tmp_path / "model"
        t.save(save_dir)

        t2 = PytorchTrainer.load(save_dir)
        assert t2.is_fitted
        assert t2.architecture == "MLPRegressor"
        assert t2.epochs == 2

    def test_save_before_fit_raises(self, tmp_path):
        t = PytorchTrainer()
        with pytest.raises(RuntimeError, match="No trained model"):
            t.save(tmp_path / "model")

    def test_trainer_config_json_valid(self, tabular_data, tmp_path):
        X, y = tabular_data
        t = PytorchTrainer(architecture="MLPRegressor", epochs=2, patience=5)
        t.fit(X, y)
        t.save(tmp_path / "model")
        config = json.loads((tmp_path / "model" / "trainer_config.json").read_text())
        assert config["architecture"] == "MLPRegressor"
        assert config["epochs"] == 2
