"""Tests for pycatalyst.services.backends.venv_backend."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

from pycatalyst.services.backends.venv_backend import (
    VenvBackend,
    _build_venv_env,
    _resolve_command,
)

# ---------------------------------------------------------------------------
# _resolve_command
# ---------------------------------------------------------------------------


class TestResolveCommand:
    """Tests for _resolve_command helper."""

    def test_bash_returns_executable(self, tmp_path: Path) -> None:
        venv_bin = tmp_path / "bin"
        venv_bin.mkdir()
        result = _resolve_command("bash", venv_bin)
        assert len(result) >= 1
        assert "bash" in result[0] or "sh" in result[0]

    def test_python_uses_venv_python(self, tmp_path: Path) -> None:
        venv_bin = tmp_path / "bin"
        venv_bin.mkdir()
        python = venv_bin / "python"
        python.write_text("#!/usr/bin/env python3\n")
        python.chmod(0o755)

        result = _resolve_command("python", venv_bin)
        assert str(venv_bin / "python") in result[0]

    def test_python_falls_back_to_sys_executable(self, tmp_path: Path) -> None:
        venv_bin = tmp_path / "bin"
        venv_bin.mkdir()
        result = _resolve_command("python", venv_bin)
        assert result[0] == sys.executable

    def test_ipython_uses_venv_ipython(self, tmp_path: Path) -> None:
        venv_bin = tmp_path / "bin"
        venv_bin.mkdir()
        ipython = venv_bin / "ipython"
        ipython.write_text("#!/usr/bin/env python3\n")
        ipython.chmod(0o755)

        result = _resolve_command("ipython", venv_bin)
        assert str(venv_bin / "ipython") in result[0]

    def test_unknown_command_found_on_path(self, tmp_path: Path) -> None:
        venv_bin = tmp_path / "bin"
        venv_bin.mkdir()
        with patch("shutil.which", return_value="/usr/bin/ls"):
            result = _resolve_command("ls", venv_bin)
            assert result == ["/usr/bin/ls"]

    def test_unknown_command_not_found_raises(self, tmp_path: Path) -> None:
        venv_bin = tmp_path / "bin"
        venv_bin.mkdir()
        with patch("shutil.which", return_value=None):
            with pytest.raises(ValueError, match="not found on PATH"):
                _resolve_command("nonexistent_cmd_xyz", venv_bin)


# ---------------------------------------------------------------------------
# _build_venv_env
# ---------------------------------------------------------------------------


class TestBuildVenvEnv:
    """Tests for _build_venv_env helper."""

    def test_sets_virtual_env(self, tmp_path: Path) -> None:
        env = _build_venv_env(tmp_path)
        assert env["VIRTUAL_ENV"] == str(tmp_path)

    def test_prepends_venv_bin_to_path(self, tmp_path: Path) -> None:
        env = _build_venv_env(tmp_path)
        assert env["PATH"].startswith(str(tmp_path / "bin"))

    def test_inherits_parent_path(self, tmp_path: Path) -> None:
        parent_path = os.environ.get("PATH", "")
        env = _build_venv_env(tmp_path)
        # Parent PATH should appear after the venv bin
        assert parent_path in env["PATH"]

    def test_removes_pythonhome(self, tmp_path: Path) -> None:
        with patch.dict(os.environ, {"PYTHONHOME": "/some/path"}):
            env = _build_venv_env(tmp_path)
            assert "PYTHONHOME" not in env

    def test_sets_term(self, tmp_path: Path) -> None:
        env = _build_venv_env(tmp_path)
        assert env["TERM"] == "xterm-256color"


# ---------------------------------------------------------------------------
# VenvBackend
# ---------------------------------------------------------------------------


class TestVenvBackend:
    """Tests for VenvBackend lifecycle."""

    @pytest.fixture()
    def backend(self, tmp_path: Path) -> VenvBackend:
        return VenvBackend(base_dir=tmp_path)

    def test_is_available(self) -> None:
        assert VenvBackend.is_available() is True

    async def test_create_and_destroy(self, backend: VenvBackend) -> None:
        env_id = await backend.create()
        assert backend.has_env(env_id)

        await backend.destroy(env_id)
        assert not backend.has_env(env_id)

    async def test_spawn_session(self, backend: VenvBackend) -> None:
        env_id = await backend.create()
        handle = await backend.spawn_session(env_id, "bash", 80, 24)

        assert handle.session_id
        assert handle.env_id == env_id
        assert handle.command == "bash"
        assert handle.backend_type == "venv"
        assert handle.is_alive()
        assert handle.pid > 0

        # Clean up
        handle.close()
        await backend.destroy(env_id)

    async def test_spawn_rejects_unknown_env(self, backend: VenvBackend) -> None:
        with pytest.raises(ValueError, match="Unknown venv"):
            await backend.spawn_session("nonexistent", "bash", 80, 24)

    async def test_get_session(self, backend: VenvBackend) -> None:
        env_id = await backend.create()
        handle = await backend.spawn_session(env_id, "bash", 80, 24)

        found = backend.get_session(handle.session_id)
        assert found is not None
        assert found.session_id == handle.session_id

        assert backend.get_session("nonexistent") is None

        handle.close()
        await backend.destroy(env_id)

    async def test_remove_session(self, backend: VenvBackend) -> None:
        env_id = await backend.create()
        handle = await backend.spawn_session(env_id, "bash", 80, 24)

        assert backend.remove_session(handle.session_id) is True
        assert backend.remove_session(handle.session_id) is False

        await backend.destroy(env_id)

    async def test_env_session_count(self, backend: VenvBackend) -> None:
        env_id = await backend.create()
        assert backend.env_session_count(env_id) == 0

        h1 = await backend.spawn_session(env_id, "bash", 80, 24)
        assert backend.env_session_count(env_id) == 1

        h2 = await backend.spawn_session(env_id, "bash", 80, 24)
        assert backend.env_session_count(env_id) == 2

        h1.close()
        h2.close()
        await backend.destroy(env_id)

    async def test_list_sessions(self, backend: VenvBackend) -> None:
        env_id = await backend.create()
        h = await backend.spawn_session(env_id, "bash", 80, 24)

        sessions = backend.list_sessions()
        assert len(sessions) == 1
        assert sessions[0].session_id == h.session_id

        h.close()
        await backend.destroy(env_id)

    async def test_list_packages(self, backend: VenvBackend) -> None:
        env_id = await backend.create()
        pkgs = await backend.list_packages(env_id)
        # A fresh venv should at least have pip
        assert isinstance(pkgs, list)
        assert any(p.get("name") == "pip" for p in pkgs)

        await backend.destroy(env_id)

    async def test_list_packages_unknown_env(self, backend: VenvBackend) -> None:
        with pytest.raises(ValueError, match="Unknown venv"):
            await backend.list_packages("nonexistent")

    async def test_install_packages(self, backend: VenvBackend) -> None:
        env_id = await backend.create()
        result = await backend.install_packages(env_id, ["pip"])
        assert result["success"] is True
        assert isinstance(result["output"], str)
        assert isinstance(result["packages"], list)
        await backend.destroy(env_id)

    async def test_install_packages_with_upgrade(self, backend: VenvBackend) -> None:
        env_id = await backend.create()
        result = await backend.install_packages(env_id, ["pip"], upgrade=True)
        assert result["success"] is True
        await backend.destroy(env_id)

    async def test_install_packages_failure(self, backend: VenvBackend) -> None:
        env_id = await backend.create()
        result = await backend.install_packages(env_id, ["nonexistent_pkg_xyz_12345"])
        assert result["success"] is False
        assert len(result["output"]) > 0
        await backend.destroy(env_id)

    async def test_install_packages_unknown_env(self, backend: VenvBackend) -> None:
        with pytest.raises(ValueError, match="Unknown venv"):
            await backend.install_packages("nonexistent", ["pip"])

    async def test_uninstall_packages(self, backend: VenvBackend) -> None:
        env_id = await backend.create()
        # Install setuptools first, then uninstall it
        await backend.install_packages(env_id, ["setuptools"])
        result = await backend.uninstall_packages(env_id, ["setuptools"])
        assert result["success"] is True
        assert isinstance(result["output"], str)
        assert isinstance(result["packages"], list)
        await backend.destroy(env_id)

    async def test_uninstall_packages_unknown_env(self, backend: VenvBackend) -> None:
        with pytest.raises(ValueError, match="Unknown venv"):
            await backend.uninstall_packages("nonexistent", ["pip"])

    async def test_shutdown_preserves_venvs(
        self,
        backend: VenvBackend,
        tmp_path: Path,
    ) -> None:
        env_id = await backend.create()
        venv_path = backend.get_env_path(env_id)
        assert venv_path is not None
        assert venv_path.exists()

        h = await backend.spawn_session(env_id, "bash", 80, 24)
        backend.shutdown()

        # Venv directory should still exist on disk
        assert venv_path.exists()
        # But internal state should be cleared
        assert not backend.has_env(env_id)
