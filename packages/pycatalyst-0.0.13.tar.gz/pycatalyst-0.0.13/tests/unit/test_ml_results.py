"""Tests for pycatalyst.ml.results module."""

from __future__ import annotations

import json
from datetime import datetime

import pandas as pd
import pytest

from pycatalyst.ml._types import TrainingStatus
from pycatalyst.ml.results import ExperimentResult


@pytest.fixture()
def sample_result() -> ExperimentResult:
    """Create a sample ExperimentResult for testing."""
    return ExperimentResult(
        name="test-experiment",
        backend="sklearn",
        status=TrainingStatus.COMPLETED,
        metrics={"mse": 0.123, "r2": 0.95},
        artifacts={"model": "/tmp/model.joblib"},
        training_history=[
            {"epoch": 1, "train_loss": 0.5},
            {"epoch": 2, "train_loss": 0.3},
        ],
        duration_seconds=4.5,
        config={"architecture": "ridge"},
    )


class TestExperimentResultProperties:
    """Tests for ExperimentResult properties."""

    def test_is_completed_when_completed(self, sample_result: ExperimentResult) -> None:
        assert sample_result.is_completed is True

    def test_is_completed_when_early_stopped(self) -> None:
        result = ExperimentResult(
            name="test",
            backend="sklearn",
            status=TrainingStatus.EARLY_STOPPED,
        )
        assert result.is_completed is True

    def test_is_completed_when_failed(self) -> None:
        result = ExperimentResult(
            name="test",
            backend="sklearn",
            status=TrainingStatus.FAILED,
        )
        assert result.is_completed is False

    def test_is_successful_with_metrics(self, sample_result: ExperimentResult) -> None:
        assert sample_result.is_successful is True

    def test_is_successful_without_metrics(self) -> None:
        result = ExperimentResult(name="test", backend="sklearn")
        assert result.is_successful is False


class TestExperimentResultToDict:
    """Tests for to_dict() method."""

    def test_basic_fields(self, sample_result: ExperimentResult) -> None:
        d = sample_result.to_dict()
        assert d["name"] == "test-experiment"
        assert d["backend"] == "sklearn"
        assert d["status"] == "completed"
        assert d["metrics"] == {"mse": 0.123, "r2": 0.95}

    def test_includes_config_by_default(self, sample_result: ExperimentResult) -> None:
        d = sample_result.to_dict()
        assert "config" in d

    def test_excludes_config_when_requested(
        self,
        sample_result: ExperimentResult,
    ) -> None:
        d = sample_result.to_dict(include_config=False)
        assert "config" not in d

    def test_empty_artifacts_excluded(self) -> None:
        result = ExperimentResult(name="test", backend="sklearn")
        d = result.to_dict()
        assert "artifacts" not in d

    def test_non_empty_artifacts_included(
        self,
        sample_result: ExperimentResult,
    ) -> None:
        d = sample_result.to_dict()
        assert "artifacts" in d


class TestExperimentResultFromDict:
    """Tests for from_dict() classmethod."""

    def test_round_trip(self, sample_result: ExperimentResult) -> None:
        d = sample_result.to_dict()
        restored = ExperimentResult.from_dict(d)
        assert restored.name == sample_result.name
        assert restored.backend == sample_result.backend
        assert restored.metrics == sample_result.metrics
        assert restored.status == sample_result.status

    def test_from_minimal_dict(self) -> None:
        result = ExperimentResult.from_dict({"name": "x", "backend": "y"})
        assert result.name == "x"
        assert result.backend == "y"
        assert result.status == TrainingStatus.COMPLETED

    def test_unknown_status_becomes_unknown(self) -> None:
        result = ExperimentResult.from_dict(
            {"name": "x", "backend": "y", "status": "bogus"},
        )
        assert result.status == TrainingStatus.UNKNOWN

    def test_timestamp_from_iso_string(self) -> None:
        ts = "2024-01-15T12:00:00+00:00"
        result = ExperimentResult.from_dict(
            {"name": "x", "backend": "y", "timestamp": ts},
        )
        assert isinstance(result.timestamp, datetime)


class TestExperimentResultToJson:
    """Tests for to_json() method."""

    def test_returns_valid_json(self, sample_result: ExperimentResult) -> None:
        json_str = sample_result.to_json()
        parsed = json.loads(json_str)
        assert parsed["name"] == "test-experiment"

    def test_writes_to_file(self, sample_result: ExperimentResult, tmp_path) -> None:
        path = str(tmp_path / "result.json")
        sample_result.to_json(path=path)

        loaded = json.loads(open(path, encoding="utf-8").read())
        assert loaded["name"] == "test-experiment"


class TestExperimentResultToDataframe:
    """Tests for to_dataframe() method."""

    def test_index_orientation(self, sample_result: ExperimentResult) -> None:
        df = sample_result.to_dataframe(orient="index")
        assert isinstance(df, pd.DataFrame)
        assert "value" in df.columns

    def test_columns_orientation(self, sample_result: ExperimentResult) -> None:
        df = sample_result.to_dataframe(orient="columns")
        assert isinstance(df, pd.DataFrame)
        assert "name" in df.columns


class TestExperimentResultHistoryDataframe:
    """Tests for history_to_dataframe() method."""

    def test_with_history(self, sample_result: ExperimentResult) -> None:
        df = sample_result.history_to_dataframe()
        assert isinstance(df, pd.DataFrame)
        assert len(df) == 2
        assert "epoch" in df.columns

    def test_without_history_raises(self) -> None:
        result = ExperimentResult(name="test", backend="sklearn")
        with pytest.raises(ValueError, match="No training history"):
            result.history_to_dataframe()


class TestExperimentResultRepr:
    """Tests for __repr__ method."""

    def test_includes_status(self, sample_result: ExperimentResult) -> None:
        r = repr(sample_result)
        assert "completed" in r

    def test_includes_primary_metric(self, sample_result: ExperimentResult) -> None:
        r = repr(sample_result)
        assert "mse" in r

    def test_includes_time(self, sample_result: ExperimentResult) -> None:
        r = repr(sample_result)
        assert "4.5s" in r


class TestExperimentResultSummary:
    """Tests for summary() method."""

    def test_includes_experiment_name(self, sample_result: ExperimentResult) -> None:
        s = sample_result.summary()
        assert "test-experiment" in s

    def test_includes_metrics(self, sample_result: ExperimentResult) -> None:
        s = sample_result.summary()
        assert "mse" in s
        assert "r2" in s

    def test_includes_artifacts(self, sample_result: ExperimentResult) -> None:
        s = sample_result.summary()
        assert "model" in s


class TestExperimentResultDefaults:
    """Tests for default field values."""

    def test_default_status(self) -> None:
        result = ExperimentResult(name="test", backend="sklearn")
        assert result.status == TrainingStatus.COMPLETED

    def test_default_timestamp(self) -> None:
        result = ExperimentResult(name="test", backend="sklearn")
        assert isinstance(result.timestamp, datetime)

    def test_default_metrics_empty(self) -> None:
        result = ExperimentResult(name="test", backend="sklearn")
        assert result.metrics == {}

    def test_default_config_empty(self) -> None:
        result = ExperimentResult(name="test", backend="sklearn")
        assert result.config == {}
