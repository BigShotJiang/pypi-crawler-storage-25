"""Unit tests for PyCatalyst auth: multi-user login, roles, require_admin, claim mapping."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from pycatalyst.config.auth import get_auth_users, is_auth_disabled

# ---------------------------------------------------------------------------
# Config: get_auth_users
# ---------------------------------------------------------------------------


class TestGetAuthUsers:
    """Tests for get_auth_users multi-user config resolution."""

    def test_json_env_var(self) -> None:
        users_json = '[{"username":"admin","password":"pass","role":"Admin"},{"username":"reader","password":"pw","role":"User"}]'
        with patch.dict(
            "os.environ", {"PYCATALYST_AUTH_USERS": users_json}, clear=False
        ):
            with patch("pycatalyst.config.auth._cfg", return_value=None):
                users = get_auth_users()
        assert len(users) == 2
        assert users[0] == {"username": "admin", "password": "pass", "role": "Admin"}
        assert users[1] == {"username": "reader", "password": "pw", "role": "User"}

    def test_default_role_is_user(self) -> None:
        users_json = '[{"username":"bob","password":"pw"}]'
        with patch.dict(
            "os.environ", {"PYCATALYST_AUTH_USERS": users_json}, clear=False
        ):
            with patch("pycatalyst.config.auth._cfg", return_value=None):
                users = get_auth_users()
        assert users[0]["role"] == "User"

    def test_empty_when_nothing_configured(self) -> None:
        with patch.dict("os.environ", {}, clear=True):
            with patch("pycatalyst.config.auth._cfg", return_value=None):
                users = get_auth_users()
        assert users == []

    def test_invalid_json_returns_empty(self) -> None:
        with patch.dict(
            "os.environ", {"PYCATALYST_AUTH_USERS": "not-json"}, clear=False
        ):
            with patch("pycatalyst.config.auth._cfg", return_value=None):
                users = get_auth_users()
        assert users == []


# ---------------------------------------------------------------------------
# Config: is_auth_disabled
# ---------------------------------------------------------------------------


class TestIsAuthDisabled:
    """Tests for auth disabled detection."""

    def test_explicitly_disabled(self) -> None:
        with patch.dict(
            "os.environ", {"PYCATALYST_AUTH_DISABLED": "true"}, clear=False
        ):
            with patch("pycatalyst.config.auth._cfg", return_value=None):
                assert is_auth_disabled() is True

    def test_enabled_with_users_and_secret(self) -> None:
        env = {
            "PYCATALYST_AUTH_USERS": '[{"username":"a","password":"b"}]',
            "PYCATALYST_AUTH_JWT_SECRET": "secret",
        }
        with patch.dict("os.environ", env, clear=False):
            with patch("pycatalyst.config.auth._cfg", return_value=None):
                assert is_auth_disabled() is False


# ---------------------------------------------------------------------------
# Dependencies: verify_credentials
# ---------------------------------------------------------------------------


class TestVerifyCredentials:
    """Tests for multi-user credential verification."""

    def test_valid_first_user(self) -> None:
        from pycatalyst.api.dependencies.auth import verify_credentials

        users = [
            {"username": "admin", "password": "pass1", "role": "Admin"},
            {"username": "reader", "password": "pass2", "role": "User"},
        ]
        with patch(
            "pycatalyst.api.dependencies.auth.get_auth_users", return_value=users
        ):
            result = verify_credentials("admin", "pass1")
        assert result == {"username": "admin", "role": "Admin"}

    def test_valid_second_user(self) -> None:
        from pycatalyst.api.dependencies.auth import verify_credentials

        users = [
            {"username": "admin", "password": "pass1", "role": "Admin"},
            {"username": "reader", "password": "pass2", "role": "User"},
        ]
        with patch(
            "pycatalyst.api.dependencies.auth.get_auth_users", return_value=users
        ):
            result = verify_credentials("reader", "pass2")
        assert result == {"username": "reader", "role": "User"}

    def test_invalid_password(self) -> None:
        from pycatalyst.api.dependencies.auth import verify_credentials

        users = [{"username": "admin", "password": "pass1", "role": "Admin"}]
        with patch(
            "pycatalyst.api.dependencies.auth.get_auth_users", return_value=users
        ):
            result = verify_credentials("admin", "wrong")
        assert result is None


# ---------------------------------------------------------------------------
# Dependencies: create_access_token with role
# ---------------------------------------------------------------------------


class TestCreateAccessToken:
    """Tests for JWT creation with role claim."""

    def test_token_contains_role(self) -> None:
        import jwt

        from pycatalyst.api.dependencies.auth import create_access_token

        with patch(
            "pycatalyst.api.dependencies.auth.get_auth_jwt_secret",
            return_value="test-secret",
        ):
            token = create_access_token("admin", role="Admin")

        payload = jwt.decode(token, "test-secret", algorithms=["HS256"])
        assert payload["sub"] == "admin"
        assert payload["role"] == "Admin"


# ---------------------------------------------------------------------------
# Dependencies: require_admin
# ---------------------------------------------------------------------------


class TestRequireAdmin:
    """Tests for admin-only dependency guard."""

    @pytest.mark.asyncio
    async def test_admin_allowed(self) -> None:
        from pycatalyst.api.dependencies.auth import require_admin

        user = {"username": "admin", "role": "Admin", "auth_disabled": False}
        result = await require_admin(current_user=user)
        assert result["username"] == "admin"

    @pytest.mark.asyncio
    async def test_user_forbidden(self) -> None:
        from fastapi import HTTPException

        from pycatalyst.api.dependencies.auth import require_admin

        user = {"username": "reader", "role": "User", "auth_disabled": False}
        with pytest.raises(HTTPException) as exc_info:
            await require_admin(current_user=user)
        assert exc_info.value.status_code == 403

    @pytest.mark.asyncio
    async def test_auth_disabled_passes(self) -> None:
        from pycatalyst.api.dependencies.auth import require_admin

        user = {"username": "anonymous", "role": "Admin", "auth_disabled": True}
        result = await require_admin(current_user=user)
        assert result["auth_disabled"] is True
