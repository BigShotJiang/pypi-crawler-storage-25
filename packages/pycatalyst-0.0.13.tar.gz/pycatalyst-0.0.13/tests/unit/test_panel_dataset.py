"""Tests for PanelTemporalDataset lazy windowing."""

from __future__ import annotations

import numpy as np
import pytest
import torch

from pycatalyst.ml.pytorch.data.panel_dataset import PanelTemporalDataset


@pytest.fixture()
def symbol_arrays():
    rng = np.random.default_rng(42)
    return {
        "AAPL": (
            rng.standard_normal((100, 5)).astype(np.float32),
            rng.standard_normal(100).astype(np.float32),
        ),
        "MSFT": (
            rng.standard_normal((80, 5)).astype(np.float32),
            rng.standard_normal(80).astype(np.float32),
        ),
    }


class TestPanelTemporalDataset:
    def test_length(self, symbol_arrays):
        ds = PanelTemporalDataset(symbol_arrays, seq_len=10, stride=1)
        aapl_windows = 100 - 10  # 90
        msft_windows = 80 - 10  # 70
        assert len(ds) == aapl_windows + msft_windows

    def test_length_with_stride(self, symbol_arrays):
        ds = PanelTemporalDataset(symbol_arrays, seq_len=10, stride=5)
        aapl_windows = len(range(0, 100 - 10, 5))
        msft_windows = len(range(0, 80 - 10, 5))
        assert len(ds) == aapl_windows + msft_windows

    def test_getitem_shape(self, symbol_arrays):
        ds = PanelTemporalDataset(symbol_arrays, seq_len=10, stride=1)
        x, y = ds[0]
        assert isinstance(x, torch.Tensor)
        assert isinstance(y, torch.Tensor)
        assert x.shape == (10, 5)
        assert y.shape == (1,)

    def test_getitem_content(self, symbol_arrays):
        ds = PanelTemporalDataset(symbol_arrays, seq_len=10, stride=1)
        x, y = ds[0]
        feat, tgt = symbol_arrays["AAPL"]
        np.testing.assert_array_almost_equal(x.numpy(), feat[0:10])
        np.testing.assert_array_almost_equal(y.numpy(), [tgt[10]])

    def test_symbol_window_counts(self, symbol_arrays):
        ds = PanelTemporalDataset(symbol_arrays, seq_len=10, stride=1)
        counts = ds.symbol_window_counts()
        assert counts["AAPL"] == 90
        assert counts["MSFT"] == 70

    def test_symbols_property(self, symbol_arrays):
        ds = PanelTemporalDataset(symbol_arrays, seq_len=10, stride=1)
        assert ds.symbols == ["AAPL", "MSFT"]

    def test_empty_if_too_short(self):
        arrays = {
            "X": (
                np.zeros((5, 3), dtype=np.float32),
                np.zeros(5, dtype=np.float32),
            ),
        }
        ds = PanelTemporalDataset(arrays, seq_len=10, stride=1)
        assert len(ds) == 0

    def test_repr(self, symbol_arrays):
        ds = PanelTemporalDataset(symbol_arrays, seq_len=10, stride=1)
        r = repr(ds)
        assert "PanelTemporalDataset" in r
        assert "symbols=2" in r
