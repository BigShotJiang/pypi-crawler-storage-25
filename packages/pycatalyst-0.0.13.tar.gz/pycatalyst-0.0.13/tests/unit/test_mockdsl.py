"""Tests for the Python-first mock DSL."""

from __future__ import annotations

from dataclasses import dataclass

from pycatalyst import MockModel, array, enum, int_, mock, object_, string, uuid


class Order(MockModel):
    order_id = uuid()
    side = enum("buy", "sell")
    qty = int_(min=1, max=10)
    symbol = string(pattern=r"^[A-Z]{1,5}$")


def test_model_generate_deterministic() -> None:
    rows1 = Order.generate(10, seed=123)
    rows2 = Order.generate(10, seed=123)
    assert rows1 == rows2


def test_model_iter_matches_generate_prefix() -> None:
    rows = Order.generate(20, seed=42)
    streamed = list(Order.iter(20, seed=42))
    assert streamed == rows


def test_fluent_iter_matches_generate_prefix() -> None:
    b = (
        mock("orders")
        .field("order_id", uuid())
        .field("side", enum("buy", "sell"))
        .field("qty", int_(min=1, max=10))
        .field("symbol", string(pattern=r"^[A-Z]{1,5}$"))
    )
    rows = b.generate(25, seed=99)
    streamed = list(b.iter(25, seed=99))
    assert streamed == rows


def test_nested_object_and_array() -> None:
    rows = (
        mock("events")
        .field(
            "meta",
            object_(
                source=string(min_len=3, max_len=3),
                tags=array(string(min_len=1, max_len=3), min_items=1, max_items=3),
            ),
        )
        .generate(5, seed=1)
    )
    assert len(rows) == 5
    for row in rows:
        assert "meta" in row
        assert "source" in row["meta"]
        assert "tags" in row["meta"]
        assert isinstance(row["meta"]["tags"], list)


def test_return_type_callable_mapper() -> None:
    out = Order.generate(5, seed=1, return_type=lambda r: r["qty"])
    assert all(isinstance(x, int) for x in out)


@dataclass
class OrderObj:
    order_id: str
    side: str
    qty: int
    symbol: str


def test_return_type_constructor_dataclass() -> None:
    out = Order.generate(5, seed=2, return_type=OrderObj)
    assert all(isinstance(x, OrderObj) for x in out)
