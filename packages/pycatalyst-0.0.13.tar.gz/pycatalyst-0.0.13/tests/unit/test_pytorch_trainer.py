"""Tests for pycatalyst.ml.trainers.pytorch module."""

from __future__ import annotations

import pytest

from pycatalyst.ml.trainers.pytorch import PytorchTrainer


class TestPytorchTrainerInit:
    """Tests for PytorchTrainer initialization."""

    def test_defaults(self) -> None:
        t = PytorchTrainer()
        assert t.architecture == "lstm"
        assert t.epochs == 100
        assert t.batch_size == 32
        assert t.learning_rate == 1e-3
        assert t.optimizer == "adam"
        assert t.seed == 42

    def test_custom_params(self) -> None:
        t = PytorchTrainer(
            architecture="gru",
            params={"hidden_size": 256},
            epochs=50,
        )
        assert t.architecture == "gru"
        assert t.params == {"hidden_size": 256}
        assert t.epochs == 50


class TestPytorchTrainerGetParams:
    """Tests for get_params() introspection."""

    def test_returns_all_init_params(self) -> None:
        t = PytorchTrainer(architecture="tcn", epochs=200)
        params = t.get_params()
        assert params["architecture"] == "tcn"
        assert params["epochs"] == 200
        assert "batch_size" in params
        assert "learning_rate" in params
        assert "gradient_clip" in params
        assert "patience" in params

    def test_set_params(self) -> None:
        t = PytorchTrainer()
        t.set_params(architecture="transformer", epochs=50)
        assert t.architecture == "transformer"
        assert t.epochs == 50


class TestPytorchTrainerConfigRoundTrip:
    """Tests for config round-trip."""

    def test_to_config(self) -> None:
        t = PytorchTrainer(
            architecture="gru",
            params={"hidden_size": 128},
            epochs=50,
        )
        config = t.to_config()
        assert config["architecture"] == "gru"
        assert config["epochs"] == 50

    def test_round_trip(self) -> None:
        t1 = PytorchTrainer(
            architecture="lstm",
            params={"hidden_size": 64},
            epochs=75,
            learning_rate=5e-4,
        )
        config = t1.to_config()
        t2 = PytorchTrainer.from_config(config)
        assert t1.get_params() == t2.get_params()


class TestPytorchTrainerValidation:
    """Tests for config validation."""

    def test_validate_missing_experiment_raises(self) -> None:
        t = PytorchTrainer()
        with pytest.raises(ValueError, match="experiment"):
            t._validate_config({"data": {}, "model": {}})

    def test_validate_missing_data_raises(self) -> None:
        t = PytorchTrainer()
        with pytest.raises(ValueError, match="data"):
            t._validate_config({"experiment": {}, "model": {}})

    def test_validate_missing_model_raises(self) -> None:
        t = PytorchTrainer()
        with pytest.raises(ValueError, match="model"):
            t._validate_config({"experiment": {}, "data": {}})


class TestPytorchTrainerPredict:
    """Tests for predict() boundary."""

    def test_predict_before_fit_raises(self) -> None:
        t = PytorchTrainer()
        with pytest.raises(RuntimeError, match="fit"):
            t.predict([1, 2, 3])

    def test_predict_with_no_model_raises(self) -> None:
        from pycatalyst.ml.results import ExperimentResult

        t = PytorchTrainer()
        t.result_ = ExperimentResult(name="test", backend="pytorch")
        with pytest.raises(RuntimeError, match="No fitted model"):
            t.predict([1, 2, 3])


class TestPytorchTrainerTrain:
    """Tests for _train() boundary."""

    def test_train_without_experiment_raises(self) -> None:
        t = PytorchTrainer()
        with pytest.raises(ValueError, match="experiment"):
            t._train(X=[1, 2], y=[3, 4])


class TestPytorchTrainerFittedState:
    """Tests for fitted state attributes."""

    def test_not_fitted_by_default(self) -> None:
        t = PytorchTrainer()
        assert not t.is_fitted
        assert t.model_ is None
        assert t.scaler_ is None
        assert t.result_ is None


class TestPytorchTrainerRepr:
    """Tests for __repr__."""

    def test_includes_class_name(self) -> None:
        t = PytorchTrainer()
        assert "PytorchTrainer" in repr(t)

    def test_includes_architecture(self) -> None:
        t = PytorchTrainer(architecture="gru")
        assert "gru" in repr(t)


class TestPytorchTrainerClone:
    """Tests for clone() with PytorchTrainer."""

    def test_clone(self) -> None:
        from pycatalyst.ml.trainers.base import clone

        t = PytorchTrainer(architecture="lstm", epochs=100)
        t2 = clone(t, epochs=50)
        assert t2.epochs == 50
        assert t2.architecture == "lstm"
        assert t.epochs == 100
