"""Tests for generation profiles."""

from __future__ import annotations

from pycatalyst.recipes.profiles import (
    BUILTIN_PROFILES,
    get_profile,
    list_profiles,
)


class TestGenerationProfiles:
    """Tests for built-in generation profiles."""

    def test_builtin_profiles_exist(self) -> None:
        assert "quick-test" in BUILTIN_PROFILES
        assert "realistic" in BUILTIN_PROFILES
        assert "high-volume" in BUILTIN_PROFILES
        assert "stress-test" in BUILTIN_PROFILES

    def test_get_profile_found(self) -> None:
        profile = get_profile("realistic")
        assert profile is not None
        assert profile.name == "realistic"
        assert profile.generation.count == 1000

    def test_get_profile_case_insensitive(self) -> None:
        profile = get_profile("Quick-Test")
        assert profile is not None
        assert profile.name == "quick-test"

    def test_get_profile_not_found(self) -> None:
        profile = get_profile("nonexistent")
        assert profile is None

    def test_list_profiles(self) -> None:
        profiles = list_profiles()
        assert len(profiles) == 4
        names = {p.name for p in profiles}
        assert "quick-test" in names

    def test_quick_test_profile(self) -> None:
        p = get_profile("quick-test")
        assert p is not None
        assert p.generation.count == 10
        assert p.generation.seed == 42

    def test_stress_test_has_streaming(self) -> None:
        p = get_profile("stress-test")
        assert p is not None
        assert p.streaming is not None
        assert p.streaming.enabled is True
        assert p.streaming.batch_size == 10_000

    def test_realistic_no_streaming(self) -> None:
        p = get_profile("realistic")
        assert p is not None
        assert p.streaming is None
