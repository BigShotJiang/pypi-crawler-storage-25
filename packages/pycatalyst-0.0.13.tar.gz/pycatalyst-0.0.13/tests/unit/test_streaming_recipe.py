"""Tests for streaming recipe execution and multi-sink support."""

from __future__ import annotations

from pycatalyst.recipes.loader import load_recipe_from_dict
from pycatalyst.recipes.runner import RecipeRunner


def _streaming_recipe() -> dict:
    """Return a recipe with streaming enabled."""
    return {
        "name": "stream_test",
        "schema": {
            "fields": [
                {"name": "id", "type": "uuid"},
                {"name": "value", "type": "int"},
            ],
        },
        "generation": {"count": 10},
        "streaming": {
            "enabled": True,
            "max_records": 50,
            "batch_size": 10,
            "interval_ms": 0,
        },
        "sink": {"type": "memory"},
    }


def _multi_sink_recipe() -> dict:
    """Return a recipe with multiple sinks."""
    return {
        "name": "multi_test",
        "schema": {
            "fields": [
                {"name": "id", "type": "uuid"},
                {"name": "value", "type": "int"},
            ],
        },
        "generation": {"count": 5, "seed": 42},
        "sinks": [
            {"type": "memory"},
            {"type": "memory"},
        ],
    }


class TestStreamingConfig:
    """Tests for StreamingConfig in recipe models."""

    def test_streaming_config_defaults(self) -> None:
        config = load_recipe_from_dict(
            {
                "name": "test",
                "schema": {"fields": [{"name": "x", "type": "int"}]},
            }
        )
        assert config.streaming.enabled is False
        assert config.streaming.max_records == 1000
        assert config.streaming.batch_size == 100

    def test_streaming_config_from_yaml(self) -> None:
        config = load_recipe_from_dict(_streaming_recipe())
        assert config.streaming.enabled is True
        assert config.streaming.max_records == 50
        assert config.streaming.batch_size == 10


class TestStreamingExecution:
    """Tests for run_streaming method."""

    def test_streaming_yields_batches(self) -> None:
        config = load_recipe_from_dict(_streaming_recipe())
        runner = RecipeRunner()
        batches = list(runner.run_streaming(config))
        # 50 records / 10 batch_size = 5 batches
        assert len(batches) == 5
        total_records = sum(gr.count for gr, _ in batches)
        assert total_records == 50

    def test_streaming_each_batch_sinks(self) -> None:
        config = load_recipe_from_dict(_streaming_recipe())
        runner = RecipeRunner()
        for gen_result, sink_result in runner.run_streaming(config):
            assert gen_result.count == 10
            assert sink_result.success is True


class TestMultiSinkRecipe:
    """Tests for multi-sink recipe support."""

    def test_multi_sink_config_loaded(self) -> None:
        config = load_recipe_from_dict(_multi_sink_recipe())
        assert config.sinks is not None
        assert len(config.sinks) == 2

    def test_multi_sink_execution(self) -> None:
        config = load_recipe_from_dict(_multi_sink_recipe())
        runner = RecipeRunner()
        gen_result, sink_result = runner.run_dict(_multi_sink_recipe())
        assert gen_result.count == 5
        # MultiSink: success when all sinks succeed
        assert sink_result.success is True
        assert sink_result.sink_type == "multi"
        # Total records_sent is sum across sinks (5 records * 2 sinks)
        assert sink_result.records_sent == 10

    def test_single_sink_backward_compat(self) -> None:
        """Recipes with only 'sink' (no 'sinks') still work."""
        recipe = {
            "name": "compat_test",
            "schema": {"fields": [{"name": "x", "type": "int"}]},
            "generation": {"count": 3, "seed": 1},
            "sink": {"type": "memory"},
        }
        runner = RecipeRunner()
        gen_result, sink_result = runner.run_dict(recipe)
        assert gen_result.count == 3
        assert sink_result.success is True
        assert sink_result.sink_type == "memory"


class TestRecipeWithQuality:
    """Tests for quality settings in recipes."""

    def test_quality_in_recipe_field(self) -> None:
        recipe = {
            "name": "quality_test",
            "schema": {
                "fields": [
                    {
                        "name": "value",
                        "type": "int",
                        "constraints": {"min": 0, "max": 100},
                        "quality": {"invalid_rate": 1.0},
                    },
                ],
            },
            "generation": {"count": 10, "seed": 42},
            "sink": {"type": "memory"},
        }
        runner = RecipeRunner()
        gen_result, sink_result = runner.run_dict(recipe)
        assert gen_result.count == 10
        # All values should be invalid (string "INVALID" for int fields)
        invalid_count = sum(
            1 for r in gen_result.records if not isinstance(r["value"], int)
        )
        assert invalid_count == 10
