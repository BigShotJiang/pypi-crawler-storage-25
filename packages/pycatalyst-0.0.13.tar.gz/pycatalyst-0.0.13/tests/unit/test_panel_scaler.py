"""Tests for PanelScaler (per-symbol and global scaling)."""

from __future__ import annotations

import json

import numpy as np
import pytest

from pycatalyst.ml.pytorch.data.scaling import PanelScaler


@pytest.fixture()
def symbol_data():
    rng = np.random.default_rng(42)
    return {
        "AAPL": rng.standard_normal((100, 5)).astype(np.float32) * 10 + 50,
        "MSFT": rng.standard_normal((80, 5)).astype(np.float32) * 5 + 100,
    }


class TestPanelScalerPerSymbol:
    def test_fit_transform(self, symbol_data):
        ps = PanelScaler(method="standard", per_symbol=True)
        ps.fit(symbol_data)
        transformed = ps.transform("AAPL", symbol_data["AAPL"])
        assert transformed.shape == symbol_data["AAPL"].shape
        np.testing.assert_almost_equal(transformed.mean(axis=0), 0, decimal=1)
        np.testing.assert_almost_equal(transformed.std(axis=0), 1, decimal=1)

    def test_per_symbol_independence(self, symbol_data):
        ps = PanelScaler(method="standard", per_symbol=True)
        ps.fit(symbol_data)
        t_aapl = ps.transform("AAPL", symbol_data["AAPL"])
        t_msft = ps.transform("MSFT", symbol_data["MSFT"])
        np.testing.assert_almost_equal(t_aapl.mean(axis=0), 0, decimal=1)
        np.testing.assert_almost_equal(t_msft.mean(axis=0), 0, decimal=1)

    def test_inverse_transform(self, symbol_data):
        ps = PanelScaler(method="standard", per_symbol=True)
        ps.fit(symbol_data)
        transformed = ps.transform("AAPL", symbol_data["AAPL"])
        recovered = ps.inverse_transform("AAPL", transformed)
        np.testing.assert_array_almost_equal(recovered, symbol_data["AAPL"], decimal=4)

    def test_unknown_symbol_raises(self, symbol_data):
        ps = PanelScaler(method="standard", per_symbol=True)
        ps.fit(symbol_data)
        with pytest.raises(KeyError, match="GOOG"):
            ps.transform("GOOG", np.zeros((10, 5)))


class TestPanelScalerGlobal:
    def test_fit_transform_global(self, symbol_data):
        ps = PanelScaler(method="standard", per_symbol=False)
        ps.fit(symbol_data)
        t = ps.transform("AAPL", symbol_data["AAPL"])
        assert t.shape == symbol_data["AAPL"].shape

    def test_any_symbol_key_works(self, symbol_data):
        ps = PanelScaler(method="standard", per_symbol=False)
        ps.fit(symbol_data)
        t = ps.transform("AAPL", symbol_data["AAPL"])
        assert t.shape == (100, 5)


class TestPanelScalerPersistence:
    def test_save_load_per_symbol(self, symbol_data, tmp_path):
        ps = PanelScaler(method="standard", per_symbol=True)
        ps.fit(symbol_data)
        path = tmp_path / "panel_scaler.json"
        ps.save(path)

        ps2 = PanelScaler.load(path)
        assert ps2.method == "standard"
        assert ps2.per_symbol is True
        t1 = ps.transform("AAPL", symbol_data["AAPL"])
        t2 = ps2.transform("AAPL", symbol_data["AAPL"])
        np.testing.assert_array_almost_equal(t1, t2)

    def test_save_load_global(self, symbol_data, tmp_path):
        ps = PanelScaler(method="minmax", per_symbol=False)
        ps.fit(symbol_data)
        path = tmp_path / "panel_scaler.json"
        ps.save(path)

        ps2 = PanelScaler.load(path)
        assert ps2.per_symbol is False
        t1 = ps.transform("AAPL", symbol_data["AAPL"])
        t2 = ps2.transform("AAPL", symbol_data["AAPL"])
        np.testing.assert_array_almost_equal(t1, t2)

    def test_save_produces_valid_json(self, symbol_data, tmp_path):
        ps = PanelScaler(method="robust", per_symbol=True)
        ps.fit(symbol_data)
        path = tmp_path / "panel_scaler.json"
        ps.save(path)
        data = json.loads(path.read_text())
        assert data["method"] == "robust"
        assert data["per_symbol"] is True
        assert "AAPL" in data["scalers"]


class TestPanelScalerRepr:
    def test_repr_per_symbol(self, symbol_data):
        ps = PanelScaler(method="standard", per_symbol=True)
        ps.fit(symbol_data)
        r = repr(ps)
        assert "per_symbol" in r
        assert "n_scalers=2" in r

    def test_repr_global(self, symbol_data):
        ps = PanelScaler(method="standard", per_symbol=False)
        ps.fit(symbol_data)
        r = repr(ps)
        assert "global" in r
