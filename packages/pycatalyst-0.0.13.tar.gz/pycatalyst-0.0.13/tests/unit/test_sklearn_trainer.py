"""Tests for pycatalyst.ml.trainers.sklearn module."""

from __future__ import annotations

import json

import numpy as np
import pytest

from pycatalyst.ml.results import ExperimentResult
from pycatalyst.ml.trainers.sklearn import SklearnTrainer


@pytest.fixture()
def synthetic_data() -> tuple[np.ndarray, np.ndarray]:
    """Generate simple synthetic regression data."""
    rng = np.random.RandomState(42)
    X = rng.randn(100, 3)
    y = X[:, 0] * 2 + X[:, 1] * 0.5 + rng.randn(100) * 0.1
    return X, y


class TestSklearnTrainerInit:
    """Tests for SklearnTrainer initialization."""

    def test_defaults(self) -> None:
        t = SklearnTrainer()
        assert t.architecture == "linear_regression"
        assert t.params == {}
        assert t.seed == 42
        assert t.scaler == "standard"

    def test_custom_params(self) -> None:
        t = SklearnTrainer(architecture="ridge", params={"alpha": 1.0})
        assert t.architecture == "ridge"
        assert t.params == {"alpha": 1.0}


class TestSklearnTrainerGetParams:
    """Tests for get_params() introspection."""

    def test_returns_init_params(self) -> None:
        t = SklearnTrainer(architecture="ridge", seed=123)
        params = t.get_params()
        assert params["architecture"] == "ridge"
        assert params["seed"] == 123
        assert "output_dir" in params

    def test_set_params_updates(self) -> None:
        t = SklearnTrainer()
        t.set_params(architecture="lasso", seed=99)
        assert t.architecture == "lasso"
        assert t.seed == 99


class TestSklearnTrainerFit:
    """Tests for fit/predict/score sklearn-style API."""

    def test_fit_returns_self(self, synthetic_data) -> None:
        X, y = synthetic_data
        t = SklearnTrainer(architecture="linear_regression")
        result = t.fit(X=X, y=y)
        assert result is t

    def test_fit_stores_result(self, synthetic_data) -> None:
        X, y = synthetic_data
        t = SklearnTrainer(architecture="ridge", params={"alpha": 0.1})
        t.fit(X=X, y=y)
        assert t.is_fitted
        assert isinstance(t.result_, ExperimentResult)

    def test_fit_result_has_metrics(self, synthetic_data) -> None:
        X, y = synthetic_data
        t = SklearnTrainer(architecture="ridge", params={"alpha": 0.1})
        t.fit(X=X, y=y)
        assert "mse" in t.result_.metrics
        assert "r2" in t.result_.metrics

    def test_predict_after_fit(self, synthetic_data) -> None:
        X, y = synthetic_data
        t = SklearnTrainer(
            architecture="linear_regression",
            scaler="none",
        )
        t.fit(X=X, y=y)
        preds = t.predict(X[:5])
        assert isinstance(preds, np.ndarray)
        assert len(preds) == 5

    def test_predict_before_fit_raises(self) -> None:
        t = SklearnTrainer()
        with pytest.raises(RuntimeError, match="not been fit"):
            t.predict(np.array([[1, 2, 3]]))

    def test_score_returns_float(self, synthetic_data) -> None:
        X, y = synthetic_data
        t = SklearnTrainer(architecture="linear_regression")
        t.fit(X=X, y=y)
        score = t.score(X=X, y=y)
        assert isinstance(score, float)


class TestSklearnTrainerConfigRoundTrip:
    """Tests for config round-trip (from_config / to_config)."""

    def test_to_config_returns_dict(self) -> None:
        t = SklearnTrainer(architecture="ridge", params={"alpha": 2.0})
        config = t.to_config()
        assert isinstance(config, dict)
        assert config["architecture"] == "ridge"

    def test_round_trip(self) -> None:
        t1 = SklearnTrainer(architecture="ridge", params={"alpha": 2.0}, seed=99)
        config = t1.to_config()
        t2 = SklearnTrainer.from_config(config)
        assert t1.get_params() == t2.get_params()


class TestSklearnTrainerSaveLoad:
    """Tests for save/load persistence."""

    def test_save_load_round_trip(self, synthetic_data, tmp_path) -> None:
        X, y = synthetic_data
        t = SklearnTrainer(architecture="ridge", params={"alpha": 0.5})
        t.fit(X=X, y=y)
        artifacts = t.save(tmp_path / "model")
        assert "model" in artifacts
        assert "config" in artifacts

        loaded = SklearnTrainer.load(tmp_path / "model")
        assert loaded.architecture == "ridge"
        assert loaded.params == {"alpha": 0.5}

        # Check loaded model can predict
        preds = loaded.predict(X[:3])
        assert len(preds) == 3

    def test_save_creates_files(self, synthetic_data, tmp_path) -> None:
        X, y = synthetic_data
        t = SklearnTrainer(architecture="linear_regression")
        t.fit(X=X, y=y)
        t.save(tmp_path / "output")

        assert (tmp_path / "output" / "model.joblib").exists()
        assert (tmp_path / "output" / "trainer_config.json").exists()

    def test_saved_config_is_valid_json(self, synthetic_data, tmp_path) -> None:
        X, y = synthetic_data
        t = SklearnTrainer(architecture="ridge", params={"alpha": 1.0})
        t.fit(X=X, y=y)
        t.save(tmp_path / "output")

        config_path = tmp_path / "output" / "trainer_config.json"
        config = json.loads(config_path.read_text(encoding="utf-8"))
        assert config["architecture"] == "ridge"


class TestSklearnTrainerListArchitectures:
    """Tests for list_architectures() static method."""

    def test_returns_list(self) -> None:
        archs = SklearnTrainer.list_architectures()
        assert isinstance(archs, list)
        assert len(archs) > 0

    def test_contains_common_models(self) -> None:
        archs = SklearnTrainer.list_architectures()
        assert "linear_regression" in archs
        assert "ridge" in archs
        assert "random_forest" in archs

    def test_is_sorted(self) -> None:
        archs = SklearnTrainer.list_architectures()
        assert archs == sorted(archs)


class TestSklearnTrainerClone:
    """Tests for clone() with SklearnTrainer."""

    def test_clone_preserves_params(self) -> None:
        from pycatalyst.ml.trainers.base import clone

        t = SklearnTrainer(architecture="ridge", params={"alpha": 1.0})
        t2 = clone(t)
        assert t == t2
        assert t is not t2

    def test_clone_with_override(self) -> None:
        from pycatalyst.ml.trainers.base import clone

        t = SklearnTrainer(architecture="ridge")
        t2 = clone(t, architecture="lasso")
        assert t2.architecture == "lasso"
        assert t.architecture == "ridge"


class TestSklearnTrainerMultipleArchitectures:
    """Tests that multiple sklearn architectures can be trained."""

    @pytest.mark.parametrize(
        "architecture",
        ["linear_regression", "ridge", "lasso", "decision_tree", "knn"],
    )
    def test_fit_various_models(self, synthetic_data, architecture: str) -> None:
        X, y = synthetic_data
        t = SklearnTrainer(architecture=architecture)
        t.fit(X=X, y=y)
        preds = t.predict(X[:5])
        assert len(preds) == 5
