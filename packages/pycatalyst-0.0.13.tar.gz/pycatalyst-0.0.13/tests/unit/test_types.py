"""Tests for pycatalyst._types module."""

from __future__ import annotations

import pytest

from pycatalyst._types import (
    Distribution,
    FieldConstraints,
    FieldSpec,
    FieldType,
    GenerationResult,
    SchemaSpec,
)
from pycatalyst.sinks.types import SinkResult


class TestFieldType:
    """Tests for FieldType enum."""

    def test_all_types_are_strings(self) -> None:
        for ft in FieldType:
            assert isinstance(ft.value, str)

    def test_from_string(self) -> None:
        assert FieldType.from_string("string") == FieldType.STRING
        assert FieldType.from_string("INT") == FieldType.INT
        assert FieldType.from_string("  Float  ") == FieldType.FLOAT
        assert FieldType.from_string("uuid") == FieldType.UUID

    def test_from_string_invalid(self) -> None:
        with pytest.raises(ValueError, match="Unknown field type"):
            FieldType.from_string("invalid")

    def test_expected_types(self) -> None:
        expected = {
            "string",
            "int",
            "float",
            "bool",
            "date",
            "datetime",
            "uuid",
            "enum",
            "object",
            "array",
        }
        assert {ft.value for ft in FieldType} == expected


class TestDistribution:
    """Tests for Distribution enum."""

    def test_values(self) -> None:
        assert Distribution.UNIFORM == "uniform"
        assert Distribution.NORMAL == "normal"
        assert Distribution.LOG_NORMAL == "log_normal"
        assert Distribution.EXPONENTIAL == "exponential"


class TestFieldConstraints:
    """Tests for FieldConstraints dataclass."""

    def test_default_creation(self) -> None:
        fc = FieldConstraints()
        assert fc.min is None
        assert fc.max is None
        assert fc.precision is None
        assert fc.choices == ()
        assert fc.unique is False

    def test_min_max_validation(self) -> None:
        with pytest.raises(ValueError, match="min.*cannot be greater than max"):
            FieldConstraints(min=10, max=5)

    def test_valid_min_max(self) -> None:
        fc = FieldConstraints(min=1, max=100)
        assert fc.min == 1
        assert fc.max == 100

    def test_equal_min_max(self) -> None:
        fc = FieldConstraints(min=5, max=5)
        assert fc.min == fc.max

    def test_negative_precision(self) -> None:
        with pytest.raises(ValueError, match="precision must be non-negative"):
            FieldConstraints(precision=-1)

    def test_min_items_validation(self) -> None:
        with pytest.raises(ValueError, match="min_items must be non-negative"):
            FieldConstraints(min_items=-1)

    def test_max_items_validation(self) -> None:
        with pytest.raises(ValueError, match="max_items must be non-negative"):
            FieldConstraints(max_items=-1)

    def test_min_max_items_validation(self) -> None:
        with pytest.raises(ValueError, match="min_items.*cannot be greater"):
            FieldConstraints(min_items=10, max_items=5)

    def test_from_config(self) -> None:
        config = {
            "min": 0,
            "max": 100,
            "precision": 2,
            "choices": ["a", "b", "c"],
            "distribution": "normal",
            "mean": 50.0,
            "std": 10.0,
            "unique": True,
        }
        fc = FieldConstraints.from_config(config)
        assert fc.min == 0
        assert fc.max == 100
        assert fc.precision == 2
        assert fc.choices == ("a", "b", "c")
        assert fc.distribution == Distribution.NORMAL
        assert fc.mean == 50.0
        assert fc.std == 10.0
        assert fc.unique is True

    def test_from_config_minimal(self) -> None:
        fc = FieldConstraints.from_config({})
        assert fc.min is None
        assert fc.choices == ()

    def test_from_config_exclusive_and_multiple_of(self) -> None:
        fc = FieldConstraints.from_config(
            {
                "min": 0,
                "max": 100,
                "exclusiveMinimum": True,
                "exclusiveMaximum": True,
                "multipleOf": 5,
            }
        )
        assert fc.min == 0
        assert fc.max == 100
        assert fc.exclusive_min is True
        assert fc.exclusive_max is True
        assert fc.multiple_of == 5
        fc2 = FieldConstraints.from_config(
            {"exclusive_min": True, "exclusive_max": True, "multiple_of": 10}
        )
        assert fc2.exclusive_min is True
        assert fc2.exclusive_max is True
        assert fc2.multiple_of == 10

    def test_frozen(self) -> None:
        fc = FieldConstraints(min=1)
        with pytest.raises(AttributeError):
            fc.min = 2  # type: ignore[misc]


class TestFieldSpec:
    """Tests for FieldSpec dataclass."""

    def test_basic_creation(self) -> None:
        fs = FieldSpec(name="age", type=FieldType.INT)
        assert fs.name == "age"
        assert fs.type == FieldType.INT
        assert fs.nullable is False
        assert fs.children == ()

    def test_empty_name_rejected(self) -> None:
        with pytest.raises(ValueError, match="Field name cannot be empty"):
            FieldSpec(name="", type=FieldType.STRING)

    def test_invalid_nullable_rate(self) -> None:
        with pytest.raises(ValueError, match="nullable_rate must be between"):
            FieldSpec(name="x", type=FieldType.STRING, nullable_rate=1.5)

    def test_object_without_children(self) -> None:
        with pytest.raises(ValueError, match="must have at least one child"):
            FieldSpec(name="addr", type=FieldType.OBJECT)

    def test_object_with_children(self) -> None:
        child = FieldSpec(name="street", type=FieldType.STRING)
        fs = FieldSpec(name="addr", type=FieldType.OBJECT, children=(child,))
        assert len(fs.children) == 1

    def test_array_without_children(self) -> None:
        with pytest.raises(ValueError, match="must have at least one child"):
            FieldSpec(name="tags", type=FieldType.ARRAY)

    def test_enum_without_choices(self) -> None:
        with pytest.raises(ValueError, match="must have constraints with choices"):
            FieldSpec(name="status", type=FieldType.ENUM)

    def test_enum_with_choices(self) -> None:
        constraints = FieldConstraints(choices=("active", "inactive"))
        fs = FieldSpec(name="status", type=FieldType.ENUM, constraints=constraints)
        assert fs.constraints.choices == ("active", "inactive")

    def test_from_config(self) -> None:
        config = {
            "name": "price",
            "type": "float",
            "nullable": True,
            "constraints": {"min": 0.0, "max": 9999.99, "precision": 2},
            "description": "Product price",
        }
        fs = FieldSpec.from_config(config)
        assert fs.name == "price"
        assert fs.type == FieldType.FLOAT
        assert fs.nullable is True
        assert fs.constraints.min == 0.0
        assert fs.constraints.precision == 2
        assert fs.description == "Product price"

    def test_from_config_missing_name(self) -> None:
        with pytest.raises(ValueError, match="requires 'name' and 'type'"):
            FieldSpec.from_config({"type": "string"})

    def test_from_config_missing_type(self) -> None:
        with pytest.raises(ValueError, match="requires 'name' and 'type'"):
            FieldSpec.from_config({"name": "x"})

    def test_from_config_nested(self) -> None:
        config = {
            "name": "address",
            "type": "object",
            "children": [
                {"name": "street", "type": "string"},
                {"name": "zip", "type": "string"},
            ],
        }
        fs = FieldSpec.from_config(config)
        assert fs.type == FieldType.OBJECT
        assert len(fs.children) == 2
        assert fs.children[0].name == "street"

    def test_frozen(self) -> None:
        fs = FieldSpec(name="x", type=FieldType.STRING)
        with pytest.raises(AttributeError):
            fs.name = "y"  # type: ignore[misc]


class TestSchemaSpec:
    """Tests for SchemaSpec dataclass."""

    def test_basic_creation(self) -> None:
        fields = (FieldSpec(name="id", type=FieldType.UUID),)
        schema = SchemaSpec(name="test", fields=fields)
        assert schema.name == "test"
        assert schema.field_names == ("id",)

    def test_empty_name_rejected(self) -> None:
        fields = (FieldSpec(name="id", type=FieldType.UUID),)
        with pytest.raises(ValueError, match="Schema name cannot be empty"):
            SchemaSpec(name="", fields=fields)

    def test_no_fields_rejected(self) -> None:
        with pytest.raises(ValueError, match="must have at least one field"):
            SchemaSpec(name="empty", fields=())

    def test_duplicate_fields_rejected(self) -> None:
        fields = (
            FieldSpec(name="id", type=FieldType.UUID),
            FieldSpec(name="id", type=FieldType.STRING),
        )
        with pytest.raises(ValueError, match="duplicate field names"):
            SchemaSpec(name="dup", fields=fields)

    def test_get_field(self) -> None:
        fields = (
            FieldSpec(name="id", type=FieldType.UUID),
            FieldSpec(name="name", type=FieldType.STRING),
        )
        schema = SchemaSpec(name="test", fields=fields)
        assert schema.get_field("name") is not None
        assert schema.get_field("name").type == FieldType.STRING
        assert schema.get_field("missing") is None

    def test_from_config(self) -> None:
        config = {
            "name": "orders",
            "description": "Order schema",
            "fields": [
                {"name": "order_id", "type": "uuid"},
                {
                    "name": "amount",
                    "type": "float",
                    "constraints": {"min": 0, "max": 10000},
                },
            ],
        }
        schema = SchemaSpec.from_config(config)
        assert schema.name == "orders"
        assert schema.description == "Order schema"
        assert len(schema.fields) == 2

    def test_from_config_missing_name(self) -> None:
        with pytest.raises(ValueError, match="requires 'name'"):
            SchemaSpec.from_config({"fields": [{"name": "x", "type": "int"}]})

    def test_from_config_no_fields(self) -> None:
        with pytest.raises(ValueError, match="requires at least one field"):
            SchemaSpec.from_config({"name": "empty", "fields": []})

    def test_frozen(self) -> None:
        fields = (FieldSpec(name="id", type=FieldType.UUID),)
        schema = SchemaSpec(name="test", fields=fields)
        with pytest.raises(AttributeError):
            schema.name = "other"  # type: ignore[misc]


class TestGenerationResult:
    """Tests for GenerationResult dataclass."""

    def test_creation(self) -> None:
        fields = (FieldSpec(name="id", type=FieldType.UUID),)
        schema = SchemaSpec(name="test", fields=fields)
        result = GenerationResult(
            records=({"id": "abc-123"},),
            schema=schema,
            count=1,
            duration_ms=12.5,
            seed=42,
        )
        assert result.count == 1
        assert result.duration_ms == 12.5
        assert result.seed == 42
        assert len(result.records) == 1


class TestSinkResult:
    """Tests for SinkResult dataclass."""

    def test_success(self) -> None:
        result = SinkResult(
            success=True,
            records_sent=100,
            sink_type="file",
        )
        assert result.success is True
        assert result.records_sent == 100
        assert result.errors == ()

    def test_failure(self) -> None:
        result = SinkResult(
            success=False,
            records_sent=50,
            sink_type="http",
            errors=("connection timeout",),
        )
        assert result.success is False
        assert len(result.errors) == 1
