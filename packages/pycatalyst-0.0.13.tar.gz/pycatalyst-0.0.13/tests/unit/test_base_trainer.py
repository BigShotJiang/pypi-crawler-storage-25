"""Tests for pycatalyst.ml.trainers.base module."""

from __future__ import annotations

from typing import Any

import numpy as np
import pytest

from pycatalyst.ml.results import ExperimentResult
from pycatalyst.ml.trainers.base import BaseTrainer, clone


class DummyTrainer(BaseTrainer):
    """Concrete test double for BaseTrainer."""

    def __init__(
        self,
        alpha: float = 1.0,
        max_iter: int = 100,
        tol: float = 1e-4,
    ) -> None:
        self.alpha = alpha
        self.max_iter = max_iter
        self.tol = tol

    def _train(self, **data: Any) -> ExperimentResult:
        return ExperimentResult(
            name="dummy",
            backend="test",
            metrics={"mse": self.alpha * 0.1},
            config={"alpha": self.alpha},
        )

    def _predict(self, X: Any) -> np.ndarray:
        return np.asarray(X) * self.alpha

    def _primary_metric(self) -> str:
        return "mse"


class TestGetParams:
    """Tests for get_params() method."""

    def test_returns_all_init_params(self) -> None:
        t = DummyTrainer(alpha=2.0, max_iter=50)
        params = t.get_params()
        assert params == {"alpha": 2.0, "max_iter": 50, "tol": 1e-4}

    def test_returns_defaults_when_unset(self) -> None:
        t = DummyTrainer()
        params = t.get_params()
        assert params["alpha"] == 1.0
        assert params["max_iter"] == 100

    def test_deep_false_returns_same(self) -> None:
        t = DummyTrainer()
        assert t.get_params(deep=False) == t.get_params(deep=True)


class TestSetParams:
    """Tests for set_params() method."""

    def test_sets_valid_param(self) -> None:
        t = DummyTrainer()
        result = t.set_params(alpha=5.0)
        assert t.alpha == 5.0
        assert result is t  # returns self

    def test_sets_multiple_params(self) -> None:
        t = DummyTrainer()
        t.set_params(alpha=2.0, max_iter=200)
        assert t.alpha == 2.0
        assert t.max_iter == 200

    def test_invalid_param_raises(self) -> None:
        t = DummyTrainer()
        with pytest.raises(ValueError, match="Invalid parameter 'bogus'"):
            t.set_params(bogus=42)


class TestClone:
    """Tests for clone() function."""

    def test_clone_produces_equal_trainer(self) -> None:
        t = DummyTrainer(alpha=3.0)
        t2 = clone(t)
        assert t == t2
        assert t is not t2

    def test_clone_with_override(self) -> None:
        t = DummyTrainer(alpha=1.0)
        t2 = clone(t, alpha=5.0)
        assert t2.alpha == 5.0
        assert t.alpha == 1.0  # original unchanged

    def test_clone_preserves_type(self) -> None:
        t = DummyTrainer()
        t2 = clone(t)
        assert type(t2) is DummyTrainer


class TestFit:
    """Tests for fit() method."""

    def test_fit_returns_self(self) -> None:
        t = DummyTrainer()
        result = t.fit(X=np.array([1, 2, 3]), y=np.array([1, 2, 3]))
        assert result is t

    def test_fit_stores_result(self) -> None:
        t = DummyTrainer()
        t.fit(X=np.array([1, 2, 3]), y=np.array([1, 2, 3]))
        assert t.is_fitted
        assert isinstance(t.result_, ExperimentResult)


class TestPredict:
    """Tests for predict() method."""

    def test_predict_after_fit(self) -> None:
        t = DummyTrainer(alpha=2.0)
        t.fit(X=np.array([1, 2]), y=np.array([2, 4]))
        result = t.predict(np.array([3, 4]))
        np.testing.assert_array_equal(result, np.array([6, 8]))

    def test_predict_before_fit_raises(self) -> None:
        t = DummyTrainer()
        with pytest.raises(RuntimeError, match="not been fit"):
            t.predict(np.array([1, 2]))


class TestScore:
    """Tests for score() method."""

    def test_score_returns_float_after_fit(self) -> None:
        t = DummyTrainer(alpha=1.0)
        t.fit(X=np.array([1, 2]), y=np.array([1, 2]))
        score = t.score(X=np.array([1, 2]), y=np.array([1, 2]))
        assert isinstance(score, float)

    def test_score_with_x_y_computes_negative_mse(self) -> None:
        t = DummyTrainer(alpha=1.0)
        t.fit(X=np.array([1, 2]), y=np.array([1, 2]))
        score = t.score(X=np.array([1, 2]), y=np.array([1, 2]))
        assert score == pytest.approx(0.0)  # perfect prediction → -MSE = 0

    def test_score_without_x_y_returns_stored_metric(self) -> None:
        t = DummyTrainer(alpha=1.0)
        t.fit(X=np.array([1, 2]), y=np.array([1, 2]))
        score = t.score()
        assert score == pytest.approx(0.1)  # mse metric from DummyTrainer._train


class TestRun:
    """Tests for run() method."""

    def test_run_with_dict_config(self) -> None:
        t = DummyTrainer()
        result = t.run({"alpha": 1.0})
        assert isinstance(result, ExperimentResult)

    def test_run_without_config_raises(self) -> None:
        t = DummyTrainer()
        with pytest.raises(ValueError, match="No config provided"):
            t.run()


class TestFromConfig:
    """Tests for from_config() classmethod."""

    def test_from_dict(self) -> None:
        t = DummyTrainer.from_config({"alpha": 3.0, "max_iter": 50})
        assert t.alpha == 3.0
        assert t.max_iter == 50

    def test_from_config_ignores_unknown_keys(self) -> None:
        t = DummyTrainer.from_config({"alpha": 3.0, "unknown_key": "ignored"})
        assert t.alpha == 3.0

    def test_from_config_then_run(self) -> None:
        t = DummyTrainer.from_config({"alpha": 2.0})
        # Should be able to run() using stored config
        result = t.run()
        assert isinstance(result, ExperimentResult)


class TestToConfig:
    """Tests for to_config() method."""

    def test_round_trip(self) -> None:
        t1 = DummyTrainer(alpha=2.5, max_iter=75)
        config = t1.to_config()
        t2 = DummyTrainer.from_config(config)
        assert t1.get_params() == t2.get_params()


class TestRepr:
    """Tests for __repr__ method."""

    def test_includes_class_name(self) -> None:
        t = DummyTrainer()
        r = repr(t)
        assert "DummyTrainer" in r

    def test_includes_params(self) -> None:
        t = DummyTrainer(alpha=2.5)
        r = repr(t)
        assert "alpha=2.5" in r


class TestEquality:
    """Tests for __eq__ and __hash__ methods."""

    def test_equal_params_are_equal(self) -> None:
        t1 = DummyTrainer(alpha=1.0)
        t2 = DummyTrainer(alpha=1.0)
        assert t1 == t2

    def test_different_params_not_equal(self) -> None:
        t1 = DummyTrainer(alpha=1.0)
        t2 = DummyTrainer(alpha=2.0)
        assert t1 != t2

    def test_different_type_not_equal(self) -> None:
        t = DummyTrainer()
        assert t != "not a trainer"

    def test_hash_consistent(self) -> None:
        t1 = DummyTrainer()
        t2 = DummyTrainer()
        assert hash(t1) == hash(t2)


class TestSave:
    """Tests for save/load boundary."""

    def test_save_before_fit_raises(self) -> None:
        t = DummyTrainer()
        with pytest.raises(RuntimeError, match="No trained model"):
            t.save("/tmp/test")

    def test_load_not_implemented(self) -> None:
        with pytest.raises(NotImplementedError):
            DummyTrainer.load("/tmp/test")
