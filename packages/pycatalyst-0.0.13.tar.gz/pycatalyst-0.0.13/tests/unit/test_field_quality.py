"""Tests for FieldQuality and quality defect generation."""

from __future__ import annotations

import pytest

from pycatalyst._types import (
    FieldConstraints,
    FieldQuality,
    FieldSpec,
    FieldType,
    SchemaSpec,
)
from pycatalyst.generators.engine import GenerationEngine


class TestFieldQuality:
    """Tests for FieldQuality dataclass."""

    def test_default_no_defects(self) -> None:
        q = FieldQuality()
        assert q.invalid_rate == 0.0
        assert q.truncate_rate == 0.0
        assert q.out_of_range_rate == 0.0

    def test_from_config(self) -> None:
        q = FieldQuality.from_config(
            {"invalid_rate": 0.1, "truncate_rate": 0.2, "out_of_range_rate": 0.3}
        )
        assert q.invalid_rate == 0.1
        assert q.truncate_rate == 0.2
        assert q.out_of_range_rate == 0.3

    def test_from_config_defaults(self) -> None:
        q = FieldQuality.from_config({})
        assert q.invalid_rate == 0.0

    @pytest.mark.parametrize(
        "attr", ["invalid_rate", "truncate_rate", "out_of_range_rate"]
    )
    def test_rate_validation_negative(self, attr: str) -> None:
        with pytest.raises(ValueError, match="must be between"):
            FieldQuality(**{attr: -0.1})

    @pytest.mark.parametrize(
        "attr", ["invalid_rate", "truncate_rate", "out_of_range_rate"]
    )
    def test_rate_validation_too_high(self, attr: str) -> None:
        with pytest.raises(ValueError, match="must be between"):
            FieldQuality(**{attr: 1.1})


class TestFieldSpecWithQuality:
    """Tests for FieldSpec with quality config."""

    def test_field_spec_default_quality_none(self) -> None:
        spec = FieldSpec(name="x", type=FieldType.INT)
        assert spec.quality is None

    def test_field_spec_with_quality(self) -> None:
        q = FieldQuality(invalid_rate=0.5)
        spec = FieldSpec(name="x", type=FieldType.INT, quality=q)
        assert spec.quality is not None
        assert spec.quality.invalid_rate == 0.5

    def test_field_spec_from_config_with_quality(self) -> None:
        config = {
            "name": "x",
            "type": "int",
            "quality": {"invalid_rate": 0.1},
        }
        spec = FieldSpec.from_config(config)
        assert spec.quality is not None
        assert spec.quality.invalid_rate == 0.1

    def test_field_spec_from_config_without_quality(self) -> None:
        config = {"name": "x", "type": "int"}
        spec = FieldSpec.from_config(config)
        assert spec.quality is None


class TestQualityDefectGeneration:
    """Tests for quality defect application in GenerationEngine."""

    def test_invalid_rate_produces_defects(self) -> None:
        """With invalid_rate=1.0, all values should be invalid."""
        schema = SchemaSpec(
            name="test",
            fields=(
                FieldSpec(
                    name="value",
                    type=FieldType.INT,
                    constraints=FieldConstraints(min=0, max=100),
                    quality=FieldQuality(invalid_rate=1.0),
                ),
            ),
        )
        engine = GenerationEngine()
        result = engine.generate(schema, count=20, seed=42)
        invalid_count = sum(
            1 for r in result.records if not isinstance(r["value"], int)
        )
        assert invalid_count == 20

    def test_out_of_range_produces_high_values(self) -> None:
        """With out_of_range_rate=1.0, all values should exceed max."""
        schema = SchemaSpec(
            name="test",
            fields=(
                FieldSpec(
                    name="value",
                    type=FieldType.INT,
                    constraints=FieldConstraints(min=0, max=10),
                    quality=FieldQuality(out_of_range_rate=1.0),
                ),
            ),
        )
        engine = GenerationEngine()
        result = engine.generate(schema, count=20, seed=42)
        over_max = sum(
            1 for r in result.records if isinstance(r["value"], int) and r["value"] > 10
        )
        assert over_max == 20

    def test_truncate_shortens_strings(self) -> None:
        """With truncate_rate=1.0, strings should be shorter."""
        schema = SchemaSpec(
            name="test",
            fields=(
                FieldSpec(
                    name="text",
                    type=FieldType.STRING,
                    constraints=FieldConstraints(min=10, max=20),
                    quality=FieldQuality(truncate_rate=1.0),
                ),
            ),
        )
        engine = GenerationEngine()
        result = engine.generate(schema, count=20, seed=42)
        # All should be truncated (shorter than min constraint)
        for record in result.records:
            assert isinstance(record["text"], str)
            assert len(record["text"]) < 20

    def test_zero_rates_no_defects(self) -> None:
        """With all rates at 0.0, no defects should occur."""
        schema = SchemaSpec(
            name="test",
            fields=(
                FieldSpec(
                    name="value",
                    type=FieldType.INT,
                    constraints=FieldConstraints(min=0, max=100),
                    quality=FieldQuality(),
                ),
            ),
        )
        engine = GenerationEngine()
        result = engine.generate(schema, count=50, seed=42)
        for record in result.records:
            assert isinstance(record["value"], int)
            assert 0 <= record["value"] <= 100
