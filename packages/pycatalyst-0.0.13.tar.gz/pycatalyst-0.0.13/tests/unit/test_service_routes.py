"""Tests for service container API routes."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from pycatalyst.api.routes.v1.services import router
from pycatalyst.errors import ServiceError
from pycatalyst.services.service_containers import (
    ServiceConfig,
    ServiceInfo,
    ServiceStatus,
    ServiceType,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_app() -> FastAPI:
    """Create a minimal FastAPI app with the services router."""
    app = FastAPI()
    app.include_router(router, prefix="/api/v1")
    return app


def _mock_user_dep():
    """Override the auth dependency to return a test user."""
    return {"username": "testuser"}


@pytest.fixture
def app() -> FastAPI:
    """FastAPI app with auth mocked out."""
    from pycatalyst.api.dependencies.auth import get_current_user

    application = _make_app()
    application.dependency_overrides[get_current_user] = _mock_user_dep
    return application


@pytest.fixture
def client(app: FastAPI) -> TestClient:
    """Test client for the app."""
    return TestClient(app)


def _sample_service_dict(
    service_id: str = "svc123",
    env_id: str = "env456",
    service_type: str = "postgres",
    status: str = "healthy",
) -> dict:
    """Create a sample service info dict matching ServiceInfoResponse."""
    return {
        "service_id": service_id,
        "env_id": env_id,
        "service_type": service_type,
        "status": status,
        "host_url": "postgresql://u:p@localhost:5432/db",
        "container_url": "postgresql://u:p@cname:5432/db",
        "host_port": 54321,
        "container_name": "pycatalyst-svc-postgres-env456",
        "container_id": "abc123",
        "database": "testdb",
        "username": "testuser",
        "created_at": 1700000000.0,
        "error_message": "",
    }


def _sample_service_info(**kwargs) -> ServiceInfo:
    """Create a sample ServiceInfo object."""
    cfg = ServiceConfig(
        service_type=ServiceType.POSTGRES, database="testdb", username="testuser"
    )
    defaults = {
        "service_id": "svc123",
        "env_id": "env456",
        "service_type": ServiceType.POSTGRES,
        "config": cfg,
        "status": ServiceStatus.HEALTHY,
        "host_url": "postgresql://u:p@localhost:5432/db",
        "container_url": "postgresql://u:p@cname:5432/db",
        "host_port": 54321,
        "container_name": "pycatalyst-svc-postgres-env456",
        "container_id": "abc123",
    }
    defaults.update(kwargs)
    return ServiceInfo(**defaults)


# ---------------------------------------------------------------------------
# POST /environments/{env_id}/services
# ---------------------------------------------------------------------------


class TestCreateService:
    """Tests for the create service endpoint."""

    @patch("pycatalyst.api.routes.v1.services.workbench_manager")
    def test_create_postgres(self, mock_mgr: MagicMock, client: TestClient) -> None:
        svc = _sample_service_info()
        mock_mgr.create_service = AsyncMock(return_value=svc)

        resp = client.post(
            "/api/v1/workbench/environments/env456/services",
            json={"service_type": "postgres"},
        )

        assert resp.status_code == 201
        data = resp.json()
        assert data["service_type"] == "postgres"
        assert data["status"] == "healthy"
        mock_mgr.create_service.assert_called_once()

    @patch("pycatalyst.api.routes.v1.services.workbench_manager")
    def test_create_mongodb(self, mock_mgr: MagicMock, client: TestClient) -> None:
        svc = _sample_service_info(service_type=ServiceType.MONGODB)
        mock_mgr.create_service = AsyncMock(return_value=svc)

        resp = client.post(
            "/api/v1/workbench/environments/env456/services",
            json={"service_type": "mongodb"},
        )

        assert resp.status_code == 201

    def test_invalid_service_type(self, client: TestClient) -> None:
        resp = client.post(
            "/api/v1/workbench/environments/env456/services",
            json={"service_type": "redis"},
        )
        assert resp.status_code == 422

    @patch("pycatalyst.api.routes.v1.services.workbench_manager")
    def test_unknown_env_returns_404(
        self, mock_mgr: MagicMock, client: TestClient
    ) -> None:
        mock_mgr.create_service = AsyncMock(
            side_effect=ValueError("Unknown environment: env999")
        )

        resp = client.post(
            "/api/v1/workbench/environments/env999/services",
            json={"service_type": "postgres"},
        )
        assert resp.status_code == 404

    @patch("pycatalyst.api.routes.v1.services.workbench_manager")
    def test_service_error_returns_400(
        self, mock_mgr: MagicMock, client: TestClient
    ) -> None:
        mock_mgr.create_service = AsyncMock(
            side_effect=ServiceError("Maximum services reached")
        )

        resp = client.post(
            "/api/v1/workbench/environments/env456/services",
            json={"service_type": "postgres"},
        )
        assert resp.status_code == 400
        assert "Maximum services" in resp.json()["detail"]

    @patch("pycatalyst.api.routes.v1.services.workbench_manager")
    def test_runtime_error_returns_400(
        self, mock_mgr: MagicMock, client: TestClient
    ) -> None:
        mock_mgr.create_service = AsyncMock(
            side_effect=RuntimeError("Services not available")
        )

        resp = client.post(
            "/api/v1/workbench/environments/env456/services",
            json={"service_type": "postgres"},
        )
        assert resp.status_code == 400


# ---------------------------------------------------------------------------
# GET /environments/{env_id}/services
# ---------------------------------------------------------------------------


class TestListServices:
    """Tests for the list services endpoint."""

    @patch("pycatalyst.api.routes.v1.services.workbench_manager")
    def test_list_services(self, mock_mgr: MagicMock, client: TestClient) -> None:
        mock_mgr.get_environment.return_value = MagicMock()
        mock_mgr.list_services.return_value = [_sample_service_dict()]

        resp = client.get("/api/v1/workbench/environments/env456/services")

        assert resp.status_code == 200
        data = resp.json()
        assert len(data["services"]) == 1
        assert data["services"][0]["service_id"] == "svc123"

    @patch("pycatalyst.api.routes.v1.services.workbench_manager")
    def test_list_empty(self, mock_mgr: MagicMock, client: TestClient) -> None:
        mock_mgr.get_environment.return_value = MagicMock()
        mock_mgr.list_services.return_value = []

        resp = client.get("/api/v1/workbench/environments/env456/services")

        assert resp.status_code == 200
        assert resp.json()["services"] == []

    @patch("pycatalyst.api.routes.v1.services.workbench_manager")
    def test_unknown_env_returns_404(
        self, mock_mgr: MagicMock, client: TestClient
    ) -> None:
        mock_mgr.get_environment.return_value = None

        resp = client.get("/api/v1/workbench/environments/env999/services")
        assert resp.status_code == 404


# ---------------------------------------------------------------------------
# GET /services/{service_id}
# ---------------------------------------------------------------------------


class TestGetService:
    """Tests for the get service status endpoint."""

    @patch("pycatalyst.api.routes.v1.services.workbench_manager")
    def test_get_service(self, mock_mgr: MagicMock, client: TestClient) -> None:
        mock_mgr.get_service_status.return_value = _sample_service_dict()

        resp = client.get("/api/v1/workbench/services/svc123")

        assert resp.status_code == 200
        assert resp.json()["service_id"] == "svc123"

    @patch("pycatalyst.api.routes.v1.services.workbench_manager")
    def test_unknown_service_returns_404(
        self, mock_mgr: MagicMock, client: TestClient
    ) -> None:
        mock_mgr.get_service_status.return_value = None

        resp = client.get("/api/v1/workbench/services/nonexistent")
        assert resp.status_code == 404


# ---------------------------------------------------------------------------
# DELETE /services/{service_id}
# ---------------------------------------------------------------------------


class TestDestroyService:
    """Tests for the destroy service endpoint."""

    @patch("pycatalyst.api.routes.v1.services.workbench_manager")
    def test_destroy_service(self, mock_mgr: MagicMock, client: TestClient) -> None:
        mock_mgr.destroy_service = AsyncMock()

        resp = client.delete("/api/v1/workbench/services/svc123")
        assert resp.status_code == 204

    @patch("pycatalyst.api.routes.v1.services.workbench_manager")
    def test_destroy_unknown_returns_404(
        self, mock_mgr: MagicMock, client: TestClient
    ) -> None:
        mock_mgr.destroy_service = AsyncMock(
            side_effect=ValueError("Unknown service: svc999")
        )

        resp = client.delete("/api/v1/workbench/services/svc999")
        assert resp.status_code == 404
