"""Integration tests for SQLiteCatalystStore — full CRUD round-trips."""

from __future__ import annotations

import pytest

try:
    from sqlalchemy import inspect as sa_inspect

    SQLALCHEMY_AVAILABLE = True
except ImportError:
    SQLALCHEMY_AVAILABLE = False

from pycatalyst.catalyst_store import SQLiteCatalystStore

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skipif(
        not SQLALCHEMY_AVAILABLE or SQLiteCatalystStore is None,
        reason="sqlalchemy not installed",
    ),
]


@pytest.fixture()
def store():
    """SQLite in-memory store, auto-initialized."""
    s = SQLiteCatalystStore("sqlite:///:memory:")
    s.connect(validate_schema_on_connect=True, auto_initialize=True)
    yield s
    s.disconnect()


class TestSQLiteExperiment:
    """Experiment CRUD via SQLite."""

    def test_store_and_get(self, store) -> None:
        exp_id = store.store_experiment(
            "exp1", "pytorch", {"status": "running", "metrics": {"loss": 0.3}}
        )
        assert exp_id

        result = store.get_experiment("exp1", "pytorch")
        assert result is not None
        assert result["name"] == "exp1"
        assert result["metrics"]["loss"] == 0.3

    def test_list_and_delete(self, store) -> None:
        store.store_experiment("a", "pytorch", {})
        exp_id = store.store_experiment("b", "sklearn", {})

        assert len(store.list_experiments()) == 2
        assert store.delete_experiment(exp_id) is True
        assert len(store.list_experiments()) == 1


class TestSQLiteRecipe:
    """Recipe CRUD via SQLite."""

    def test_store_and_get(self, store) -> None:
        rid = store.store_recipe(
            "users_recipe", "1.0", {"description": "Generate users"}
        )
        assert rid

        result = store.get_recipe("users_recipe", "1.0")
        assert result is not None
        assert result["name"] == "users_recipe"

    def test_list_and_delete(self, store) -> None:
        store.store_recipe("a", "1.0", {})
        rid = store.store_recipe("b", "2.0", {})

        assert len(store.list_recipes()) == 2
        assert store.delete_recipe(rid) is True
        assert len(store.list_recipes()) == 1


class TestSQLiteSchemaSpec:
    """SchemaSpec CRUD via SQLite."""

    def test_store_and_get(self, store) -> None:
        sid = store.store_schema_spec(
            "users", {"fields": [{"name": "id", "type": "integer"}]}
        )
        assert sid

        result = store.get_schema_spec("users")
        assert result is not None
        assert result["name"] == "users"

    def test_list_and_delete(self, store) -> None:
        store.store_schema_spec("a", {})
        sid = store.store_schema_spec("b", {})

        assert len(store.list_schema_specs()) == 2
        assert store.delete_schema_spec(sid) is True
        assert len(store.list_schema_specs()) == 1


class TestSQLiteGenerationRun:
    """GenerationRun CRUD via SQLite."""

    def test_store_and_get(self, store) -> None:
        run_id = store.store_generation_run(
            "recipe1", "1.0", {"record_count": 1000, "seed": 42}
        )
        assert run_id

        result = store.get_generation_run(run_id)
        assert result is not None
        assert result["recipe_name"] == "recipe1"
        assert result["record_count"] == 1000

    def test_list_with_filter(self, store) -> None:
        store.store_generation_run("r1", "1.0", {})
        store.store_generation_run("r1", "1.0", {})
        store.store_generation_run("r2", "1.0", {})

        assert len(store.list_generation_runs()) == 3
        assert len(store.list_generation_runs(recipe_name="r1")) == 2

    def test_delete(self, store) -> None:
        run_id = store.store_generation_run("r1", "1.0", {})
        assert store.delete_generation_run(run_id) is True
        assert store.get_generation_run(run_id) is None


class TestSQLiteAutoInitialize:
    """Auto-initialization creates tables."""

    def test_tables_created(self, store) -> None:
        insp = sa_inspect(store._engine)
        tables = insp.get_table_names()
        assert "experiments" in tables
        assert "recipes" in tables
        assert "schema_specs" in tables
        assert "generation_runs" in tables


class TestSQLiteArtifactCRUD:
    """Artifact CRUD via SQLite (native ArtifactModel-backed)."""

    def test_store_and_get(self, store) -> None:
        exp_id = store.store_experiment("exp1", "pytorch", {"status": "done"})
        aid = store.store_artifact(exp_id, "model.pt", b"weights-data")
        assert aid  # UUID string

        data = store.get_artifact(exp_id, "model.pt")
        assert data == b"weights-data"

    def test_get_missing_returns_none(self, store) -> None:
        import uuid

        fake_id = str(uuid.uuid4())
        assert store.get_artifact(fake_id, "missing.pt") is None

    def test_list_artifacts(self, store) -> None:
        exp_id = store.store_experiment("exp1", "pytorch", {})
        store.store_artifact(exp_id, "model.pt", b"w")
        store.store_artifact(exp_id, "config.json", b"{}")

        names = store.list_artifacts(exp_id)
        assert names == ["config.json", "model.pt"]

    def test_delete_artifact(self, store) -> None:
        exp_id = store.store_experiment("exp1", "pytorch", {})
        store.store_artifact(exp_id, "model.pt", b"w")
        assert store.delete_artifact(exp_id, "model.pt") is True
        assert store.get_artifact(exp_id, "model.pt") is None

    def test_delete_missing_returns_false(self, store) -> None:
        import uuid

        fake_id = str(uuid.uuid4())
        assert store.delete_artifact(fake_id, "nope") is False

    def test_upsert_overwrites(self, store) -> None:
        exp_id = store.store_experiment("exp1", "pytorch", {})
        store.store_artifact(exp_id, "model.pt", b"v1")
        store.store_artifact(exp_id, "model.pt", b"v2")
        assert store.get_artifact(exp_id, "model.pt") == b"v2"

    def test_large_artifact(self, store) -> None:
        exp_id = store.store_experiment("exp1", "pytorch", {})
        large_data = b"x" * (1024 * 1024)  # 1 MB
        store.store_artifact(exp_id, "big.bin", large_data)
        assert store.get_artifact(exp_id, "big.bin") == large_data

    def test_artifacts_table_exists(self, store) -> None:
        insp = sa_inspect(store._engine)
        tables = insp.get_table_names()
        assert "artifacts" in tables


class TestSQLiteTemplateMethods:
    """Template methods work with SQLite backend."""

    def test_experiment_summary(self, store) -> None:
        store.store_experiment(
            "exp1",
            "pytorch",
            {
                "status": "done",
                "metrics": {"acc": 0.9},
                "training_history": [1, 2, 3],
                "config": {"lr": 0.01},
            },
        )
        summary = store.get_experiment_summary("exp1", "pytorch")
        assert summary is not None
        assert "training_history" not in summary
        assert "config" not in summary
        assert summary["metrics"]["acc"] == 0.9

    def test_recipe_with_schema(self, store) -> None:
        store.store_schema_spec("users", {"fields": [{"name": "id", "type": "int"}]})
        store.store_recipe("gen", "1.0", {"schema_name": "users", "record_count": 50})
        result = store.get_recipe_with_schema("gen", "1.0")
        assert result is not None
        assert "schema_spec" in result
