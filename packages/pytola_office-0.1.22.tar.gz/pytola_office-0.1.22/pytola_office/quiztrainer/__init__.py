"""QuizTrainer - 在线答题训练系统."""

from .core import DataManager, QuizManager, QuizSession
from .models import (
    AnswerRecord,
    BaseQuestion,
    ChoiceQuestion,
    Difficulty,
    EssayQuestion,
    FillQuestion,
    QuestionType,
    QuizCategory,
    TrueFalseQuestion,
    UserData,
)

__version__ = "0.1.22"
__all__ = [
    "AnswerRecord",
    "BaseQuestion",
    "ChoiceQuestion",
    "DataManager",
    "Difficulty",
    "EssayQuestion",
    "FillQuestion",
    "QuestionType",
    "QuizCategory",
    "QuizManager",
    "QuizSession",
    "TrueFalseQuestion",
    "UserData",
]
