# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'filetreeviewer.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_FileTreeViewer(object):
    def setupUi(self, FileTreeViewer):
        if not FileTreeViewer.objectName():
            FileTreeViewer.setObjectName(u"FileTreeViewer")
        FileTreeViewer.resize(720, 480)
        FileTreeViewer.setMinimumSize(QSize(720, 480))
        self.horizontalLayout = QHBoxLayout(FileTreeViewer)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.tvFiles = QTreeView(FileTreeViewer)
        self.tvFiles.setObjectName(u"tvFiles")

        self.horizontalLayout.addWidget(self.tvFiles)

        self.gbOperations = QGroupBox(FileTreeViewer)
        self.gbOperations.setObjectName(u"gbOperations")
        self.verticalLayout = QVBoxLayout(self.gbOperations)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.pbOpenFile = QPushButton(self.gbOperations)
        self.pbOpenFile.setObjectName(u"pbOpenFile")
        self.pbOpenFile.setMinimumSize(QSize(100, 30))

        self.verticalLayout.addWidget(self.pbOpenFile)

        self.pbLocateFile = QPushButton(self.gbOperations)
        self.pbLocateFile.setObjectName(u"pbLocateFile")
        self.pbLocateFile.setMinimumSize(QSize(100, 30))

        self.verticalLayout.addWidget(self.pbLocateFile)

        self.pbMarkNormal = QPushButton(self.gbOperations)
        self.pbMarkNormal.setObjectName(u"pbMarkNormal")
        self.pbMarkNormal.setMinimumSize(QSize(100, 30))

        self.verticalLayout.addWidget(self.pbMarkNormal)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)


        self.horizontalLayout.addWidget(self.gbOperations)


        self.retranslateUi(FileTreeViewer)

        QMetaObject.connectSlotsByName(FileTreeViewer)
    # setupUi

    def retranslateUi(self, FileTreeViewer):
        FileTreeViewer.setWindowTitle(QCoreApplication.translate("FileTreeViewer", u"\u641c\u7d22\u7ed3\u679c", None))
        self.gbOperations.setTitle(QCoreApplication.translate("FileTreeViewer", u"\u64cd\u4f5c", None))
        self.pbOpenFile.setText(QCoreApplication.translate("FileTreeViewer", u"\u67e5\u770b\u6587\u4ef6", None))
        self.pbLocateFile.setText(QCoreApplication.translate("FileTreeViewer", u"\u5b9a\u4f4d\u6587\u4ef6", None))
        self.pbMarkNormal.setText(QCoreApplication.translate("FileTreeViewer", u"\u6807\u8bb0\u8df3\u8fc7", None))
    # retranslateUi
