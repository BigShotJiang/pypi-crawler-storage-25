# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'configdialog.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import resource_rc

class Ui_ConfigDialog(object):
    def setupUi(self, ConfigDialog):
        if not ConfigDialog.objectName():
            ConfigDialog.setObjectName(u"ConfigDialog")
        ConfigDialog.resize(720, 400)
        ConfigDialog.setMinimumSize(QSize(720, 400))
        self.verticalLayout = QVBoxLayout(ConfigDialog)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.tabWidget = QTabWidget(ConfigDialog)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tabWidget.setMovable(False)
        self.tabUI = QWidget()
        self.tabUI.setObjectName(u"tabUI")
        self.horizontalLayout_3 = QHBoxLayout(self.tabUI)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.gbStyle = QGroupBox(self.tabUI)
        self.gbStyle.setObjectName(u"gbStyle")
        self.horizontalLayout_2 = QHBoxLayout(self.gbStyle)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.lvStyles = QListView(self.gbStyle)
        self.lvStyles.setObjectName(u"lvStyles")

        self.horizontalLayout_2.addWidget(self.lvStyles)


        self.horizontalLayout_3.addWidget(self.gbStyle)

        self.tabWidget.addTab(self.tabUI, "")
        self.tabFileType = QWidget()
        self.tabFileType.setObjectName(u"tabFileType")
        self.verticalLayout_2 = QVBoxLayout(self.tabFileType)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.lvFileTypes = QListView(self.tabFileType)
        self.lvFileTypes.setObjectName(u"lvFileTypes")

        self.verticalLayout_2.addWidget(self.lvFileTypes)

        self.tabWidget.addTab(self.tabFileType, "")
        self.tabKeywords = QWidget()
        self.tabKeywords.setObjectName(u"tabKeywords")
        self.verticalLayout_3 = QVBoxLayout(self.tabKeywords)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.lvKeywords = QListView(self.tabKeywords)
        self.lvKeywords.setObjectName(u"lvKeywords")

        self.verticalLayout_3.addWidget(self.lvKeywords)

        self.tabWidget.addTab(self.tabKeywords, "")
        self.tabIgnoreDirs = QWidget()
        self.tabIgnoreDirs.setObjectName(u"tabIgnoreDirs")
        self.verticalLayout_5 = QVBoxLayout(self.tabIgnoreDirs)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.lvIgnoreDirs = QListView(self.tabIgnoreDirs)
        self.lvIgnoreDirs.setObjectName(u"lvIgnoreDirs")

        self.verticalLayout_5.addWidget(self.lvIgnoreDirs)

        self.tabWidget.addTab(self.tabIgnoreDirs, "")
        self.tabIgnoreFileNames = QWidget()
        self.tabIgnoreFileNames.setObjectName(u"tabIgnoreFileNames")
        self.verticalLayout_7 = QVBoxLayout(self.tabIgnoreFileNames)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.lvIgnoreFileNames = QListView(self.tabIgnoreFileNames)
        self.lvIgnoreFileNames.setObjectName(u"lvIgnoreFileNames")

        self.verticalLayout_7.addWidget(self.lvIgnoreFileNames)

        self.tabWidget.addTab(self.tabIgnoreFileNames, "")

        self.verticalLayout.addWidget(self.tabWidget)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer)

        self.labelContent = QLabel(ConfigDialog)
        self.labelContent.setObjectName(u"labelContent")

        self.horizontalLayout.addWidget(self.labelContent)

        self.leContent = QLineEdit(ConfigDialog)
        self.leContent.setObjectName(u"leContent")
        self.leContent.setMinimumSize(QSize(0, 32))

        self.horizontalLayout.addWidget(self.leContent)

        self.pbOpenDir = QPushButton(ConfigDialog)
        self.pbOpenDir.setObjectName(u"pbOpenDir")
        icon = QIcon()
        icon.addFile(u":/assets/icons/folder.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pbOpenDir.setIcon(icon)
        self.pbOpenDir.setIconSize(QSize(32, 32))

        self.horizontalLayout.addWidget(self.pbOpenDir)

        self.pbAdd = QPushButton(ConfigDialog)
        self.pbAdd.setObjectName(u"pbAdd")
        icon1 = QIcon()
        icon1.addFile(u":/assets/icons/add.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pbAdd.setIcon(icon1)
        self.pbAdd.setIconSize(QSize(32, 32))

        self.horizontalLayout.addWidget(self.pbAdd)

        self.pbRemove = QPushButton(ConfigDialog)
        self.pbRemove.setObjectName(u"pbRemove")
        icon2 = QIcon()
        icon2.addFile(u":/assets/icons/remove.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pbRemove.setIcon(icon2)
        self.pbRemove.setIconSize(QSize(32, 32))

        self.horizontalLayout.addWidget(self.pbRemove)

        self.pbSave = QPushButton(ConfigDialog)
        self.pbSave.setObjectName(u"pbSave")
        icon3 = QIcon()
        icon3.addFile(u":/assets/icons/save.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pbSave.setIcon(icon3)
        self.pbSave.setIconSize(QSize(32, 32))

        self.horizontalLayout.addWidget(self.pbSave)


        self.verticalLayout.addLayout(self.horizontalLayout)


        self.retranslateUi(ConfigDialog)

        self.tabWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(ConfigDialog)
    # setupUi

    def retranslateUi(self, ConfigDialog):
        ConfigDialog.setWindowTitle(QCoreApplication.translate("ConfigDialog", u"\u8bbe\u7f6e", None))
        self.gbStyle.setTitle(QCoreApplication.translate("ConfigDialog", u"\u98ce\u683c", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tabUI), QCoreApplication.translate("ConfigDialog", u"\u754c\u9762", None))
#if QT_CONFIG(tooltip)
        self.lvFileTypes.setToolTip(QCoreApplication.translate("ConfigDialog", u"\u5904\u7406\u7684\u6587\u4ef6\u7c7b\u578b\u6e05\u5355\uff0c\u4e0d\u5728\u6e05\u5355\u5185\u7684\u76f4\u63a5\u8df3\u8fc7\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tabFileType), QCoreApplication.translate("ConfigDialog", u"\u6587\u4ef6\u7c7b\u578b", None))
#if QT_CONFIG(tooltip)
        self.lvKeywords.setToolTip(QCoreApplication.translate("ConfigDialog", u"\u626b\u63cf\u89c4\u5219\u6e05\u5355\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tabKeywords), QCoreApplication.translate("ConfigDialog", u"\u89c4\u5219", None))
#if QT_CONFIG(tooltip)
        self.lvIgnoreDirs.setToolTip(QCoreApplication.translate("ConfigDialog", u"\u6392\u9664\u7684\u6587\u4ef6\u5939\u6e05\u5355\uff0c\u5728\u5176\u4e2d\u7684\u6587\u4ef6\u5747\u76f4\u63a5\u8df3\u8fc7\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tabIgnoreDirs), QCoreApplication.translate("ConfigDialog", u"\u6392\u9664\u6587\u4ef6\u5939", None))
#if QT_CONFIG(tooltip)
        self.lvIgnoreFileNames.setToolTip(QCoreApplication.translate("ConfigDialog", u"\u6392\u9664\u7684\u6587\u4ef6\u540d\u6807\u8bc6\uff0c\u5305\u542b\u8be5\u6807\u8bc6\u7684\u6240\u6709\u6587\u4ef6\u4e00\u5f8b\u8df3\u8fc7\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tabIgnoreFileNames), QCoreApplication.translate("ConfigDialog", u"\u6392\u9664\u6587\u4ef6\u540d\u6807\u8bc6", None))
        self.labelContent.setText(QCoreApplication.translate("ConfigDialog", u"\u5185\u5bb9\uff1a", None))
#if QT_CONFIG(tooltip)
        self.leContent.setToolTip(QCoreApplication.translate("ConfigDialog", u"\u589e\u52a0\u7684\u5185\u5bb9\u3002", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.pbOpenDir.setToolTip(QCoreApplication.translate("ConfigDialog", u"\u6253\u5f00\u6587\u4ef6\u76ee\u5f55\u4f5c\u4e3a\u5185\u5bb9\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.pbOpenDir.setText("")
#if QT_CONFIG(tooltip)
        self.pbAdd.setToolTip(QCoreApplication.translate("ConfigDialog", u"\u589e\u52a0\u9879\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.pbAdd.setText("")
#if QT_CONFIG(tooltip)
        self.pbRemove.setToolTip(QCoreApplication.translate("ConfigDialog", u"\u5220\u9664\u9879\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.pbRemove.setText("")
#if QT_CONFIG(tooltip)
        self.pbSave.setToolTip(QCoreApplication.translate("ConfigDialog", u"\u4fdd\u5b58\u6240\u6709\u8bbe\u7f6e\u3002", None))
#endif // QT_CONFIG(tooltip)
        self.pbSave.setText("")
    # retranslateUi
