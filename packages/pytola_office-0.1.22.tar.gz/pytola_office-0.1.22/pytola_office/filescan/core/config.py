"""文件扫描配置模块."""

from __future__ import annotations

from pathlib import Path

from pytola_core.config import ConfigMixin

__all__ = ["conf"]

# 获取项目根目录
_ROOT_DIR = Path(__file__).parent


class FilescanConfig(ConfigMixin):
    """文件扫描配置类."""

    # 资源目录路径
    _ASSETS_DIR = _ROOT_DIR / "assets"
    _DATA_DIR = _ROOT_DIR / "data"

    # GUI 配置
    DEFAULT_FONT = "Microsoft YaHei"
    DEFAULT_STYLE = "aqua"
    DEFAULT_FONT_SIZE = 12
    FONT_BOLD = True

    # 窗口配置
    WINDOW_WIDTH: int = 1200
    WINDOW_HEIGHT: int = 800
    WINDOW_X: int = 100
    WINDOW_Y: int = 100

    # 文件搜索配置
    FILE_TYPES: list[str] = ["docx", "doc", "rar", "zip"]  # noqa: RUF012
    STYLE_NAMES: list[str] = []  # noqa: RUF012

    SEARCH_FOLDERS: list = []  # noqa: RUF012
    MAX_FOLDERS = 12
    KEYWORDS: str = ""
    IGNORE_DIRS: list[str] = ["C:/Windows", "C:/Program Files", "C:/Program Files (x86)"]  # noqa: RUF012
    IGNORE_FILE_NAMES: list = []  # noqa: RUF012

    # 文档扫描配置 (来自 docscan)
    DOC_FILE_TYPES: str = "pdf,docx,xlsx,pptx,txt,odt,rtf,epub,csv,xml,html,md,jpg,jpeg,png,gif,bmp,tiff"
    USE_PDF_OCR: bool = False
    USE_PROCESS_POOL: bool = False
    THREADS: int = 4
    BATCH_SIZE: int = 50
    INCLUDE_IMAGE_FORMATS: bool = False

    # 最近使用的目录
    RECENT_DIRECTORIES: list[str] = []  # noqa: RUF012
    MAX_RECENT_ITEMS: int = 10

    # 规则配置
    RULES: dict = {  # noqa: RUF012 默认规则模板
        "description": "默认扫描规则",
        "rules": [
            {
                "name": "emails",
                "pattern": r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",
                "regex": True,
                "case_sensitive": False,
                "context_lines": 2,
                "description": "查找电子邮件地址",
            },
            {
                "name": "phones",
                "pattern": r"\b\d{3}[-.]?\d{3}[-.]?\d{4}\b",
                "regex": True,
                "case_sensitive": False,
                "context_lines": 1,
                "description": "查找电话号码",
            },
            {
                "name": "dates",
                "pattern": r"\d{4}-\d{2}-\d{2}",
                "regex": True,
                "case_sensitive": False,
                "context_lines": 1,
                "description": "查找日期",
            },
        ],
    }

    # 数据库配置
    ENABLE_DB_PERSISTENCE: bool = True
    DB_FILENAME: str = "scan_results.db"


conf = FilescanConfig()
