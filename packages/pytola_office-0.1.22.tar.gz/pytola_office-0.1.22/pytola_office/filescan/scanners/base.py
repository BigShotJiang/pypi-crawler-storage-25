"""Base scanner module for filescan - 扫描器基类."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any


class BaseScanner(ABC):
    """扫描器基类，定义通用接口."""

    def __init__(self, input_dir: Path) -> None:
        """初始化扫描器.

        Args:
            input_dir: 输入目录路径
        """
        self.input_dir = Path(input_dir)
        self.paused = False
        self.stopped = False

    @abstractmethod
    def scan(self, **kwargs: Any) -> dict[str, Any]:
        """执行扫描.

        Args:
            **kwargs: 扫描参数

        Returns
        -------
            扫描结果字典
        """
        pass

    @abstractmethod
    def pause(self) -> None:
        """暂停扫描."""
        pass

    @abstractmethod
    def resume(self) -> None:
        """恢复扫描."""
        pass

    @abstractmethod
    def stop(self) -> None:
        """停止扫描."""
        pass

    def is_paused(self) -> bool:
        """检查是否已暂停.

        Returns
        -------
            如果暂停返回 True，否则返回 False
        """
        return self.paused

    def is_stopped(self) -> bool:
        """检查是否已停止.

        Returns
        -------
            如果停止返回 True，否则返回 False
        """
        return self.stopped
