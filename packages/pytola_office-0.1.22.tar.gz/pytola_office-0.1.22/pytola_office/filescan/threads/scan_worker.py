"""ScanWorker module for filescan - 后台扫描工作线程."""

from __future__ import annotations

import logging
from contextlib import suppress

from PySide2.QtCore import QObject, QThread, Signal

from ..scanners import DocumentScanner


class ScanWorker(QThread):
    """文档扫描后台工作线程."""

    def __init__(self, scanner: DocumentScanner, threads: int) -> None:
        """初始化工作线程.

        Args:
            scanner: 文档扫描器实例
            threads: 使用的线程数
        """
        super().__init__()
        self.scanner = scanner
        self.threads = threads
        self.signals = WorkerSignals()

    def _create_progress_handler(self) -> logging.Handler:
        """创建日志处理器以发出进度消息."""

        class ProgressHandler(logging.Handler):
            def __init__(self, signal: Signal[str]) -> None:
                super().__init__()
                self.signal = signal

            def emit(self, record: logging.LogRecord) -> None:
                with suppress(ValueError, TypeError, AttributeError):
                    message = self.format(record)
                    if message and message.strip():
                        self.signal.emit(message)

        handler = ProgressHandler(self.signals.progress_message)
        handler.setFormatter(logging.Formatter("%(message)s"))
        return handler

    def _setup_loggers(self, handler: logging.Handler) -> dict:
        """设置日志记录器以捕获进度消息.

        Returns
        -------
            映射日志记录器到其原始处理程序的字典.
        """
        loggers_to_monitor = [
            logging.getLogger(__name__),
            logging.getLogger("filescan"),
            logging.getLogger("pytola.filescan"),
            logging.getLogger(),
            logging.getLogger("filescan.scanners"),
        ]

        original_handlers = {}
        for logger in loggers_to_monitor:
            original_handlers[logger] = list(logger.handlers)
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)

        return original_handlers

    def _cleanup_loggers(self, loggers_to_monitor: list, handler: logging.Handler, original_handlers: dict) -> None:
        """清理自定义日志处理器."""
        for logger in loggers_to_monitor:
            if logger in original_handlers:
                with suppress(ValueError, TypeError):
                    logger.removeHandler(handler)
                logger.handlers = original_handlers[logger]

    def _get_loggers_to_monitor(self) -> list:
        """获取要监控的日志记录器列表."""
        return [
            logging.getLogger(__name__),
            logging.getLogger("filescan"),
            logging.getLogger("pytola.filescan"),
            logging.getLogger(),
            logging.getLogger("filescan.scanners"),
        ]

    def run(self) -> None:
        """运行文档扫描."""
        try:
            handler = self._create_progress_handler()
            original_handlers = self._setup_loggers(handler)

            def progress_callback(current: int, total: int) -> None:
                self.signals.progress_update.emit(current, total)

            self.scanner.set_progress_callback(progress_callback)
            self.signals.progress_message.emit("开始扫描...")

            results = self.scanner.scan(threads=self.threads, show_progress=True)

            self._cleanup_loggers(self._get_loggers_to_monitor(), handler, original_handlers)

            self.signals.progress_message.emit("扫描完成!")
            self.signals.scan_finished.emit(results)
        except RuntimeError as e:
            try:
                for logger in self._get_loggers_to_monitor():
                    with suppress(ValueError, TypeError):
                        logger.removeHandler(handler)
            except (OSError, AttributeError):
                pass
            self.signals.scan_error.emit(str(e))


class WorkerSignals(QObject):
    """定义工作线程可用的信号."""

    # 进度报告信号
    progress_message = Signal(str)
    progress_update = Signal(int, int)

    # 完成信号
    scan_finished = Signal(dict)
    scan_error = Signal(str)
