"""Tests for docscan module."""
