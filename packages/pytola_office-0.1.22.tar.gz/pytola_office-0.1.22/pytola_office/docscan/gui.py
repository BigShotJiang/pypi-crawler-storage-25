"""PySide2 GUI version of docscan application - DEPRECATED.

This module is deprecated. Use filescan module instead.
"""

# GUI functionality has been migrated to filescan module
# This file is kept for backward compatibility reference only

# from __future__ import annotations
# import os
# import sys
# from pathlib import Path
# import PySide2
# from PySide2.QtWidgets import QApplication
# from pytola_office.docscan.widgets.docscan_window import DocScanGUI
#
# qt_dir = Path(PySide2.__file__).parent
# plugin_path = str(qt_dir / "plugins" / "platforms")
# os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"] = plugin_path
#
#
# def main() -> None:
#     """Run main entry point for GUI application."""
#     app = QApplication(sys.argv)
#     window = DocScanGUI()
#     window.show()
#     sys.exit(app.exec_())
#
#
# if __name__ == "__main__":
#     main()
