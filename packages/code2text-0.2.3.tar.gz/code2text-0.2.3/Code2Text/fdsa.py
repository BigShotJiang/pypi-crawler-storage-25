"""
✅ Class fdsa - Contains all programs from fds.py as text
Each method returns the program code as a string
"""


class fdsa:
    """Class containing all data science and ML programs as text"""

    @staticmethod
    def program_1():
        """EX NO: 1 – NumPy Arrays"""
        return """# ========== PROGRAM 1: NumPy Arrays ==========

import numpy as np

arr = np.array([[1,2,3],[4,2,5]])

print("Type:", type(arr))
print("Dimensions:", arr.ndim)
print("Shape:", arr.shape)
print("Size:", arr.size)
print("Datatype:", arr.dtype)"""

    @staticmethod
    def program_2():
        """EX NO: 2 – Array Slicing"""
        return """# ========== PROGRAM 2: Array Slicing ==========

import numpy as np

a = np.array([[1,2,3],[3,4,5],[4,5,6]])

print(a)
print("Second column:", a[:,1])
print("Second row:", a[1,:])
print("Column 1 onwards:\\n", a[:,1:])"""

    @staticmethod
    def program_3():
        """EX NO: 3 – Pandas DataFrame"""
        return """# ========== PROGRAM 3: Pandas DataFrame ==========

import numpy as np
import pandas as pd

data = np.array([['','Col1','Col2'],
                 ['Row1',1,2],
                 ['Row2',3,4]])

df = pd.DataFrame(data=data[1:,1:], index=data[1:,0], columns=data[0,1:])
print(df)

arr = np.array([[1,2,3],[4,5,6]])
print(pd.DataFrame(arr))

d = {1:['1','3'],2:['1','2'],3:['2','4']}
print(pd.DataFrame(d))"""

    @staticmethod
    def program_4():
        """EX NO: 4 – Iris Dataset (CSV)"""
        return """# ========== PROGRAM 4: Iris Dataset (CSV) ==========

import pandas as pd

df = pd.read_csv("Iris.csv")

print(df.head())
print("Shape:", df.shape)

print(df.info())
print(df.describe())

print("Missing values:\\n", df.isnull().sum())

# Remove duplicates
data = df.drop_duplicates(subset="Species")
print(data)

print(df["Species"].value_counts())"""

    @staticmethod
    def program_5():
        """EX NO: 5 – Univariate Analysis"""
        return """# ========== PROGRAM 5: Univariate Analysis ==========

import pandas as pd
import numpy as np

df = pd.read_csv("diabetes.csv")

def analysis(df):
    for col in df.columns:
        print(f"\\n--- {col} ---")
        print("Mean:", df[col].mean())
        print("Median:", df[col].median())
        print("Mode:", df[col].mode()[0])
        print("Variance:", df[col].var())
        print("Std Dev:", df[col].std())
        print("Skewness:", df[col].skew())

analysis(df)"""

    @staticmethod
    def program_6():
        """EX NO: 6 – Logistic Regression"""
        return """# ========== PROGRAM 6: Logistic Regression ==========
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

df = pd.read_csv("diabetes.csv")

# Check classes
print(df["Outcome"].value_counts())

X = df.drop("Outcome", axis=1)
y = df["Outcome"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y
)

model = LogisticRegression(max_iter=1000)
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

print("Accuracy:", accuracy_score(y_test, y_pred))"""

    @staticmethod
    def program_7():
        """EX NO: 7 – Histogram + Normal Curve"""
        return """# ========== PROGRAM 7: Histogram + Normal Curve ==========

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from scipy.stats import norm

df = pd.read_csv("Iris.csv")

for col in df.columns[:-1]:
    sns.histplot(df[col], kde=True, stat="density")

    mean, std = norm.fit(df[col])
    xmin, xmax = plt.xlim()
    x = np.linspace(xmin, xmax, 100)
    p = norm.pdf(x, mean, std)

    plt.plot(x, p, 'k', linewidth=2)
    plt.title(col)
    plt.show()"""

    @staticmethod
    def program_8():
        """EX NO: 8 – Density + Contour"""
        return """# ========== PROGRAM 8: Density + Contour ==========

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv("Iris.csv")

# Density
for col in df.columns[:-1]:
    sns.kdeplot(data=df, x=col, hue="Species", fill=True)
    plt.show()

# Contour
sns.pairplot(df, hue="Species", kind="kde")
plt.show()"""

    @staticmethod
    def program_9():
        """EX NO: 9 – Correlation + Scatter"""
        return """# ========== PROGRAM 9: Correlation + Scatter ==========

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv("diabetes.csv")

corr = df.corr(numeric_only=True)
sns.heatmap(corr, annot=True)
plt.show()

plt.scatter(df["Glucose"], df["Insulin"])
plt.show()

plt.scatter(df["BMI"], df["Age"])
plt.show()"""

    @staticmethod
    def program_10():
        """EX NO: 10 – Histogram + 3D Plot"""
        return """# ========== PROGRAM 10: Histogram + 3D Plot ==========

import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

df = pd.read_csv("diabetes.csv")

# Histogram
df.hist()
plt.show()

# 3D plot
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

ax.scatter(df["Glucose"], df["BMI"], df["Age"])

ax.set_xlabel("Glucose")
ax.set_ylabel("BMI")
ax.set_zlabel("Age")

plt.show()"""
    
class fdsa_data:
    def iris():
        return '''Id,SepalLengthCm,SepalWidthCm,PetalLengthCm,PetalWidthCm,Species
1,5.1,3.5,1.4,0.2,setosa
2,4.9,3.0,1.4,0.2,setosa
3,4.7,3.2,1.3,0.2,setosa
4,4.6,3.1,1.5,0.2,setosa
5,5.0,3.6,1.4,0.2,setosa
6,5.4,3.9,1.7,0.4,setosa
7,4.6,3.4,1.4,0.3,setosa
8,5.0,3.4,1.5,0.2,setosa
9,4.4,2.9,1.4,0.2,setosa
10,4.9,3.1,1.5,0.1,setosa
11,5.4,3.7,1.5,0.2,setosa
12,4.8,3.4,1.6,0.2,setosa
13,4.8,3.0,1.4,0.1,setosa
14,4.3,3.0,1.1,0.1,setosa
15,5.8,4.0,1.2,0.2,setosa
16,5.7,4.4,1.5,0.4,setosa
17,5.4,3.9,1.3,0.4,setosa
18,5.1,3.5,1.4,0.3,setosa
19,5.7,3.8,1.7,0.3,setosa
20,5.1,3.8,1.5,0.3,setosa
21,5.4,3.4,1.7,0.2,setosa
22,5.1,3.7,1.5,0.4,setosa
23,4.6,3.6,1.0,0.2,setosa
24,5.1,3.3,1.7,0.5,setosa
25,4.8,3.4,1.9,0.2,setosa
26,5.0,3.0,1.6,0.2,setosa
27,5.0,3.4,1.6,0.4,setosa
28,5.2,3.5,1.5,0.2,setosa
29,5.2,3.4,1.4,0.2,setosa
30,4.7,3.2,1.6,0.2,setosa
31,4.8,3.1,1.6,0.2,setosa
32,5.4,3.4,1.5,0.4,setosa
33,5.2,4.1,1.5,0.1,setosa
34,5.5,4.2,1.4,0.2,setosa
35,4.9,3.1,1.5,0.2,setosa
36,5.0,3.2,1.2,0.2,setosa
37,5.5,3.5,1.3,0.2,setosa
38,4.9,3.6,1.4,0.1,setosa
39,4.4,3.0,1.3,0.2,setosa
40,5.1,3.4,1.5,0.2,setosa
41,5.0,3.5,1.3,0.3,setosa
42,4.5,2.3,1.3,0.3,setosa
43,4.4,3.2,1.3,0.2,setosa
44,5.0,3.5,1.6,0.6,setosa
45,5.1,3.8,1.9,0.4,setosa
46,4.8,3.0,1.4,0.3,setosa
47,5.1,3.8,1.6,0.2,setosa
48,4.6,3.2,1.4,0.2,setosa
49,5.3,3.7,1.5,0.2,setosa
50,5.0,3.3,1.4,0.2,setosa
51,7.0,3.2,4.7,1.4,versicolor
52,6.4,3.2,4.5,1.5,versicolor
53,6.9,3.1,4.9,1.5,versicolor
54,5.5,2.3,4.0,1.3,versicolor
55,6.5,2.8,4.6,1.5,versicolor
56,5.7,2.8,4.5,1.3,versicolor
57,6.3,3.3,4.7,1.6,versicolor
58,4.9,2.4,3.3,1.0,versicolor
59,6.6,2.9,4.6,1.3,versicolor
60,5.2,2.7,3.9,1.4,versicolor
61,5.0,2.0,3.5,1.0,versicolor
62,5.9,3.0,4.2,1.5,versicolor
63,6.0,2.2,4.0,1.0,versicolor
64,6.1,2.9,4.7,1.4,versicolor
65,5.6,2.9,3.6,1.3,versicolor
66,6.7,3.1,4.4,1.4,versicolor
67,5.6,3.0,4.5,1.5,versicolor
68,5.8,2.7,4.1,1.0,versicolor
69,6.2,2.2,4.5,1.5,versicolor
70,5.6,2.5,3.9,1.1,versicolor
71,5.9,3.2,4.8,1.8,versicolor
72,6.1,2.8,4.0,1.3,versicolor
73,6.3,2.5,4.9,1.5,versicolor
74,6.1,2.8,4.7,1.2,versicolor
75,6.4,2.9,4.3,1.3,versicolor
76,6.6,3.0,4.4,1.4,versicolor
77,6.8,2.8,4.8,1.4,versicolor
78,6.7,3.0,5.0,1.7,versicolor
79,6.0,2.9,4.5,1.5,versicolor
80,5.7,2.6,3.5,1.0,versicolor
81,5.5,2.4,3.8,1.1,versicolor
82,5.5,2.4,3.7,1.0,versicolor
83,5.8,2.7,3.9,1.2,versicolor
84,6.0,2.7,5.1,1.6,versicolor
85,5.4,3.0,4.5,1.5,versicolor
86,6.0,3.4,4.5,1.6,versicolor
87,6.7,3.1,4.7,1.5,versicolor
88,6.3,2.3,4.4,1.3,versicolor
89,5.6,3.0,4.1,1.3,versicolor
90,5.5,2.5,4.0,1.3,versicolor
91,5.5,2.6,4.4,1.2,versicolor
92,6.1,3.0,4.6,1.4,versicolor
93,5.8,2.6,4.0,1.2,versicolor
94,5.0,2.3,3.3,1.0,versicolor
95,5.6,2.7,4.2,1.3,versicolor
96,5.7,3.0,4.2,1.2,versicolor
97,5.7,2.9,4.2,1.3,versicolor
98,6.2,2.9,4.3,1.3,versicolor
99,5.1,2.5,3.0,1.1,versicolor
100,5.7,2.8,4.1,1.3,versicolor
101,6.3,3.3,6.0,2.5,virginica
102,5.8,2.7,5.1,1.9,virginica
103,7.1,3.0,5.9,2.1,virginica
104,6.3,2.9,5.6,1.8,virginica
105,6.5,3.0,5.8,2.2,virginica
106,7.6,3.0,6.6,2.1,virginica
107,4.9,2.5,4.5,1.7,virginica
108,7.3,2.9,6.3,1.8,virginica
109,6.7,2.5,5.8,1.8,virginica
110,7.2,3.6,6.1,2.5,virginica
111,6.5,3.2,5.1,2.0,virginica
112,6.4,2.7,5.3,1.9,virginica
113,6.8,3.0,5.5,2.1,virginica
114,5.7,2.5,5.0,2.0,virginica
115,5.8,2.8,5.1,2.4,virginica
116,6.4,3.2,5.3,2.3,virginica
117,6.5,3.0,5.5,1.8,virginica
118,7.7,3.8,6.7,2.2,virginica
119,7.7,2.6,6.9,2.3,virginica
120,6.0,2.2,5.0,1.5,virginica
121,6.9,3.2,5.7,2.3,virginica
122,5.6,2.8,4.9,2.0,virginica
123,7.7,2.8,6.7,2.0,virginica
124,6.3,2.7,4.9,1.8,virginica
125,6.7,3.3,5.7,2.1,virginica
126,7.2,3.2,6.0,1.8,virginica
127,6.2,2.8,4.8,1.8,virginica
128,6.1,3.0,4.9,1.8,virginica
129,6.4,2.8,5.6,2.1,virginica
130,7.2,3.0,5.8,1.6,virginica
131,7.4,2.8,6.1,1.9,virginica
132,7.9,3.8,6.4,2.0,virginica
133,6.4,2.8,5.6,2.2,virginica
134,6.3,2.8,5.1,1.5,virginica
135,6.1,2.6,5.6,1.4,virginica
136,7.7,3.0,6.1,2.3,virginica
137,6.3,3.4,5.6,2.4,virginica
138,6.4,3.1,5.5,1.8,virginica
139,6.0,3.0,4.8,1.8,virginica
140,6.9,3.1,5.4,2.1,virginica
141,6.7,3.1,5.6,2.4,virginica
142,6.9,3.1,5.1,2.3,virginica
143,5.8,2.7,5.1,1.9,virginica
144,6.8,3.2,5.9,2.3,virginica
145,6.7,3.3,5.7,2.5,virginica
146,6.7,3.0,5.2,2.3,virginica
147,6.3,2.5,5.0,1.9,virginica
148,6.5,3.0,5.2,2.0,virginica
149,6.2,3.4,5.4,2.3,virginica
150,5.9,3.0,5.1,1.8,virginica
'''
    def diabetes():
        return '''Pregnancies,Glucose,BloodPressure,SkinThickness,Insulin,BMI,DiabetesPedigreeFunction,Age,Outcome
6,98,69,25,362,43.0,2.138,43,1
3,105,58,30,507,30.2,0.699,51,1
12,82,56,20,273,21.1,1.275,63,0
14,140,102,46,505,44.6,0.631,51,1
10,155,58,45,14,40.7,2.47,46,0
7,97,97,44,191,21.4,2.366,21,1
12,135,94,28,484,42.9,0.195,34,1
4,114,101,29,27,41.5,1.793,52,0
6,131,62,27,38,32.0,2.321,30,0
9,97,48,23,272,34.0,0.533,58,0
2,97,51,24,230,28.8,1.463,56,1
6,177,40,40,85,19.5,2.297,32,1
10,113,97,10,473,27.1,0.181,46,0
10,153,40,12,125,39.7,1.774,46,0
7,99,73,25,536,18.1,0.814,28,0
4,144,87,32,144,27.0,2.319,69,0
3,197,40,20,524,28.8,2.431,49,1
7,161,55,21,211,32.5,2.366,19,0
7,198,100,19,24,42.8,1.238,64,0
2,190,103,41,579,27.4,2.169,31,0
5,96,102,25,393,27.4,2.127,37,0
4,190,108,17,66,37.9,0.866,39,1
1,185,61,47,232,30.2,2.089,28,0
7,72,106,21,108,24.1,0.189,44,1
11,172,115,33,145,30.2,1.531,20,0
13,131,65,37,110,21.8,0.652,34,0
5,120,55,17,227,22.8,0.389,61,1
1,128,90,37,110,31.5,0.285,45,0
11,187,96,45,469,29.3,1.771,46,1
4,165,68,35,33,42.7,0.916,38,1
0,182,117,17,368,27.8,1.839,64,0
11,131,108,37,594,33.7,0.257,33,1
9,121,86,37,553,35.1,0.857,54,1
5,81,101,46,424,18.4,1.395,37,1
12,108,108,45,517,35.9,1.998,23,1
11,199,115,36,281,22.8,0.865,36,1
8,182,55,26,319,43.9,1.602,22,1
0,170,87,18,442,22.0,2.226,20,1
10,182,78,42,314,29.2,1.578,18,1
10,150,72,29,376,20.3,0.659,55,0
14,182,62,22,288,44.9,0.159,32,0
9,71,49,37,436,31.6,2.188,51,1
11,199,108,38,276,34.1,0.151,52,0
11,123,73,22,581,19.8,2.199,66,1
14,156,91,44,502,38.2,1.369,42,1
13,198,49,15,515,23.7,2.354,41,0
13,195,58,27,349,42.2,2.017,29,1
14,199,97,14,445,23.5,2.495,35,1
13,122,40,34,349,23.1,0.942,32,1
2,137,108,11,136,19.0,1.941,61,1
11,192,43,19,242,30.7,1.065,33,0
6,107,55,39,542,33.3,1.252,44,1
3,93,63,14,39,19.8,1.606,25,1
8,138,119,42,228,38.9,2.197,63,1
2,185,41,10,547,30.2,2.462,42,0
4,167,71,27,222,32.2,1.944,34,1
2,166,63,41,5,29.9,1.103,46,0
6,193,51,20,321,28.8,1.111,25,0
4,139,89,30,467,33.1,1.87,32,1
8,162,74,35,74,22.2,0.673,44,1
6,72,72,34,3,22.9,0.365,63,0
1,159,72,31,117,41.3,0.951,67,1
3,165,100,36,503,43.5,0.789,69,0
8,121,90,22,573,28.1,0.811,24,0
11,197,82,42,440,25.3,0.661,20,1
13,108,51,43,193,35.4,0.201,46,1
1,151,106,44,391,29.0,0.143,61,0
9,173,104,10,25,18.7,2.471,41,0
8,198,72,30,434,22.2,1.127,20,0
9,80,79,15,172,37.3,1.022,37,0
4,111,113,37,299,35.8,1.731,63,1
1,168,82,26,325,18.7,0.624,32,1
3,76,83,14,409,24.0,2.38,42,1
11,159,68,40,117,24.2,1.987,47,1
14,181,52,14,224,36.1,0.315,31,1
11,129,51,47,531,18.5,1.102,24,0
6,182,85,12,112,20.8,2.21,34,1
11,71,41,32,139,39.6,2.367,61,1
12,198,74,46,558,22.8,1.222,37,1
7,117,47,46,0,35.6,1.572,53,1
14,106,65,19,89,24.4,0.501,26,1
2,78,113,19,319,20.7,2.479,55,0
13,168,73,28,549,24.6,0.656,65,0
0,117,46,26,138,37.5,2.363,39,0
3,123,107,30,510,41.1,1.659,19,1
1,189,97,23,258,40.4,1.559,41,0
7,185,114,18,9,28.7,1.33,25,0
3,144,68,10,260,36.0,0.654,28,1
1,182,75,22,171,23.5,0.524,30,1
13,173,60,13,12,25.9,0.629,34,1
5,153,75,10,167,42.2,0.547,25,0
5,181,49,49,595,18.4,1.971,38,0
9,168,112,41,320,20.3,0.94,35,1
3,162,63,43,318,23.6,0.239,47,1
5,197,103,37,328,18.7,2.426,35,0
12,179,88,40,549,22.9,2.221,63,0
14,151,75,17,418,33.7,2.327,64,1
1,123,63,48,94,29.4,2.488,48,1
9,137,62,35,580,42.1,0.517,55,0
11,102,101,43,317,40.1,1.051,49,1
1,90,76,12,235,27.2,1.92,28,0
9,117,51,21,333,25.0,1.77,62,0
13,197,94,10,375,28.3,0.469,42,0
3,197,52,14,458,33.9,2.058,50,0
13,102,62,39,136,25.2,0.639,55,1
14,184,69,39,587,34.9,0.637,58,1
14,188,56,26,546,29.1,1.389,25,0
7,91,101,32,512,32.9,1.523,28,0
13,107,52,24,295,29.8,1.492,39,0
6,178,98,46,319,26.0,0.32,68,0
11,120,58,30,571,43.6,2.206,41,0
8,77,88,23,348,38.6,0.737,58,1
13,96,51,11,228,21.8,0.411,34,1
7,96,100,20,269,41.4,2.233,29,1
4,90,58,48,290,31.2,2.394,63,1
12,99,115,47,164,42.2,2.169,49,0
1,166,48,43,4,39.6,2.043,32,0
14,97,110,47,378,29.5,1.673,33,0
4,180,67,43,77,18.6,1.422,39,0
7,130,117,27,409,25.3,0.309,45,0
9,117,91,39,573,32.6,1.08,37,1
8,73,55,24,131,35.1,0.994,50,0
11,104,108,36,41,25.0,0.723,27,1
11,118,51,43,88,21.8,1.836,57,1
11,86,64,47,401,40.5,1.29,49,1
12,115,91,42,295,44.6,0.295,67,1
8,186,92,33,294,32.2,0.628,50,0
12,75,62,24,525,22.6,1.74,19,1
14,168,55,39,421,25.4,0.283,50,1
12,193,96,26,22,18.5,2.143,50,1
0,106,78,14,574,42.7,1.288,58,0
8,93,92,38,142,21.2,1.253,30,0
6,162,81,13,144,33.6,1.522,47,0
8,115,97,19,224,25.4,2.079,50,1
7,164,78,26,502,33.0,0.935,30,1
0,168,53,19,103,35.6,1.727,69,0
11,185,44,26,38,40.4,1.458,43,1
7,136,74,29,197,23.6,0.741,39,0
7,197,114,33,578,18.3,2.209,56,0
14,87,57,14,390,21.7,2.014,19,1
10,94,115,43,178,42.3,1.68,55,1
2,123,48,15,553,41.6,2.141,56,1
0,127,113,11,447,34.1,2.182,43,1
7,136,97,22,499,34.2,1.8,63,0
2,173,56,20,14,36.0,2.109,67,0
2,93,46,32,288,22.7,1.774,32,0
0,183,85,25,477,42.7,1.732,51,0
10,101,52,40,230,29.3,1.585,59,0
4,155,79,20,419,28.3,1.907,61,1
9,196,81,25,156,32.0,0.481,66,0
6,199,48,17,549,19.3,2.214,57,0
9,86,89,13,440,22.5,2.192,28,0
8,173,66,49,96,37.9,0.17,20,1
11,112,105,13,410,20.2,2.082,23,1
6,108,44,34,288,34.3,0.409,26,1
8,95,68,12,253,24.6,0.904,23,1
7,168,76,41,195,28.5,1.884,26,0
11,119,77,12,597,25.8,0.486,56,0
1,82,47,36,521,27.6,2.063,48,1
0,129,104,38,516,37.4,2.097,49,1
6,126,56,41,117,26.0,1.318,58,0
6,105,110,28,158,33.3,0.115,67,0
13,89,84,30,227,30.9,0.789,29,1
7,134,43,14,215,35.9,1.581,25,1
4,77,75,27,14,43.3,2.455,25,1
2,184,109,37,156,37.8,1.616,67,1
11,161,70,31,260,23.8,0.724,45,0
7,167,58,30,156,18.8,1.622,37,0
5,135,100,15,46,25.1,1.396,64,0
10,101,93,10,323,34.1,1.972,24,1
2,155,78,14,129,19.4,0.357,28,1
0,120,113,21,410,31.4,1.926,37,0
2,132,58,35,94,34.1,1.399,33,0
4,194,78,43,291,27.0,2.411,21,0
14,127,106,23,282,38.8,0.92,23,0
13,127,84,35,68,20.9,1.618,39,1
2,155,52,36,10,20.0,2.337,43,0
0,118,97,18,253,37.7,0.346,20,0
4,139,59,35,549,31.4,2.349,58,0
9,84,111,31,133,36.6,1.751,59,0
6,123,100,39,22,29.7,0.263,31,0
14,170,78,26,345,24.7,0.822,28,0
13,77,40,35,301,40.1,1.8,35,0
6,122,42,45,362,39.6,0.262,29,1
10,129,116,10,395,36.8,1.497,40,1
8,177,101,17,217,25.3,0.93,29,1
14,74,102,44,140,33.9,1.59,30,1
14,172,64,24,209,27.7,0.21,42,0
9,75,95,31,459,20.5,2.192,62,1
9,178,72,23,355,42.8,2.436,68,1
11,185,77,35,323,21.7,2.425,36,0
12,163,45,37,132,43.7,1.899,63,0
2,116,97,32,126,30.0,0.412,53,1
14,168,83,23,105,23.0,1.92,62,1
6,124,84,33,377,32.6,0.159,25,0
0,121,71,11,50,41.6,0.153,46,1
3,82,84,35,28,37.8,0.877,49,0
12,183,100,23,461,39.8,1.273,68,0
3,193,86,16,295,35.8,1.949,61,0
13,175,60,12,296,36.7,1.74,35,0
'''

# Usage examples:
if __name__ == "__main__":
    # Get program 1 as text
    print("Program 1:")
    print(fdsa.program_1())
    print("\n" + "="*50 + "\n")
    
    # Get program 2 as text
    print("Program 2:")
    print(fdsa.program_2())
    print("\n" + "="*50 + "\n")
    
    # Get program 3 as text
    print("Program 3:")
    print(fdsa.program_3())
