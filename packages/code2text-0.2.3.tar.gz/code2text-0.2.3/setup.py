from setuptools import setup, find_packages

setup(
    name="Code2Text",
    version="0.2.3",
    packages=find_packages(),
    install_requires=[],
)