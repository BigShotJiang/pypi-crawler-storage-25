"""Malformed publisher for H1-CALTEST channels.

Publishes a mix of zero-duration blocks, duplicate timestamps, and
correctly formatted blocks to test client and server side validation.
"""

import argparse
import logging
import time

import numpy

from arrakis import Publisher, SeriesBlock, Time

logger = logging.getLogger("malformed_publisher")

# -- block generators --------------------------------------------------------


def make_correct_block(channels, time_ns, stride_ns):
    """Generate a correctly formatted block."""
    series = {}
    metadata = {}
    for name, channel in channels.items():
        n_samples = int(channel.sample_rate * stride_ns / Time.SECONDS)
        series[name] = numpy.zeros(n_samples, dtype=channel.data_type)
        metadata[name] = channel
    return SeriesBlock(time_ns, series, metadata)


def make_zero_duration_block(channels, time_ns):
    """Generate a block with zero samples (zero duration)."""
    series = {}
    metadata = {}
    for name, channel in channels.items():
        series[name] = numpy.array([], dtype=channel.data_type)
        metadata[name] = channel
    return SeriesBlock(time_ns, series, metadata)


# -- main loop ---------------------------------------------------------------

BLOCK_SEQUENCE = [
    "correct",
    "correct",
    "zero_duration",
    "correct",
    "duplicate",  # re-publishes the previous correct block's timestamp
    "correct",
    "zero_duration",
    "duplicate",
    "correct",
    "correct",
]


def run(publisher, n_cycles=1):
    stride = publisher.stride
    assert stride, "publisher stride not set after registration"
    stride_s = stride / Time.SECONDS

    tick = int(time.time()) * Time.SECONDS  # approximate GPS start
    published_times = []

    for cycle in range(n_cycles):
        logger.info("--- cycle %d/%d ---", cycle + 1, n_cycles)

        for step, kind in enumerate(BLOCK_SEQUENCE):
            loop_start = time.monotonic()

            if kind == "correct":
                tick += stride
                block = make_correct_block(publisher.channels, tick, stride)
                label = f"correct  t={block.time_ns}"
                published_times.append(tick)

            elif kind == "zero_duration":
                tick += stride
                try:
                    block = make_zero_duration_block(publisher.channels, tick)
                except (AssertionError, ValueError) as exc:
                    logger.warning(
                        "cycle %d step %d: zero-duration block rejected "
                        "at construction: %s",
                        cycle,
                        step,
                        exc,
                    )
                    continue
                label = f"zero_dur t={block.time_ns}"

            elif kind == "duplicate":
                # re-use the most recent successfully built timestamp
                dup_time = published_times[-1] if published_times else tick
                block = make_correct_block(
                    publisher.channels,
                    dup_time,
                    stride,
                )
                label = f"dup      t={block.time_ns}"

            else:
                msg = f"unknown block kind: {kind}"
                raise ValueError(msg)

            try:
                publisher.publish(block)
                logger.info("cycle %d step %2d: PUBLISHED %s", cycle, step, label)
            except Exception:
                logger.exception(
                    "cycle %d step %2d: REJECTED  %s",
                    cycle,
                    step,
                    label,
                )

            # Sleep for the remainder of one stride, minus time already
            # spent in this iteration.  Duplicate and zero-duration blocks
            # don't advance the timeline, so skip the sleep for those to
            # keep the wall-clock cadence realistic.
            if kind == "correct":
                elapsed = time.monotonic() - loop_start
                remaining = stride_s - elapsed
                if remaining > 0:
                    time.sleep(remaining)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", "-u", default=None, help="Arrakis Flight server URL")
    parser.add_argument(
        "--cycles",
        "-n",
        type=int,
        default=1,
        help="number of times to repeat the block sequence (default: 1)",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="enable debug logging",
    )
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
    )

    publisher = Publisher("H1-CALTEST", args.url)
    publisher.register()

    with publisher:
        run(publisher, n_cycles=args.cycles)


if __name__ == "__main__":
    main()
