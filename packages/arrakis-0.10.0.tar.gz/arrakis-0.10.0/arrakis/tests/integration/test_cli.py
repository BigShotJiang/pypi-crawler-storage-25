import json
import shlex

from ...channel import Channel


def test_count(script_runner, arrakis_server):
    cmd = "arrakis count H1:TEST-CHANNEL*"
    result = script_runner.run(shlex.split(cmd))
    assert result.success
    assert result.stdout.rstrip() == "2"

    cmd = "arrakis count H1:TEST-STATE*"
    result = script_runner.run(shlex.split(cmd))
    assert result.success
    assert result.stdout.rstrip() == "1"


def test_find(script_runner, arrakis_server, arrakis_channels):
    cmd = "arrakis find --json H1:TEST*"
    result = script_runner.run(shlex.split(cmd))
    assert result.success
    for line in result.stdout.splitlines():
        channel = Channel.from_json(line)
        assert channel == arrakis_channels[channel.name]


def test_find_repr(script_runner, arrakis_server):
    cmd = "arrakis find --repr H1:TEST-CHANNEL_SIN"
    result = script_runner.run(shlex.split(cmd))
    assert result.success
    assert "H1:TEST-CHANNEL_SIN" in result.stdout


def test_describe(script_runner, arrakis_server):
    cmd = "arrakis describe --json H1:TEST-CHANNEL_COS"
    result = script_runner.run(shlex.split(cmd))
    assert result.success

    channel = Channel.from_json(result.stdout.rstrip())
    assert channel.domain == "H1"
    assert channel.data_type == "float64"
    assert channel.sample_rate == 16384


def test_stream(script_runner, arrakis_server):
    start = 1000000000
    end = 1000000010
    duration = end - start

    cmd = f"arrakis stream --start {start} --end {end} --str H1:TEST-STATE_ONES"
    result = script_runner.run(shlex.split(cmd))
    assert result.success
    blocks = result.stdout.splitlines()
    assert len(blocks) == duration * 16


def test_stream_json(script_runner, arrakis_server):
    start = 1000000000
    end = 1000000001

    cmd = f"arrakis stream --start {start} --end {end} --json H1:TEST-STATE_ONES"
    result = script_runner.run(shlex.split(cmd))
    assert result.success
    for line in result.stdout.splitlines():
        obj = json.loads(line)
        assert "time_ns" in obj


def test_stream_json_abrv(script_runner, arrakis_server):
    start = 1000000000
    end = 1000000001

    cmd = f"arrakis stream --start {start} --end {end} --json-abrv H1:TEST-STATE_ONES"
    result = script_runner.run(shlex.split(cmd))
    assert result.success
    assert "array(" in result.stdout


def test_fetch(script_runner, arrakis_server):
    start = 1000000000
    end = 1000000010

    cmd = f"arrakis fetch --start {start} --end {end} --str H1:TEST-STATE_ONES"
    result = script_runner.run(shlex.split(cmd))
    assert result.success
    assert result.stdout.strip()


def test_fetch_json(script_runner, arrakis_server):
    start = 1000000000
    end = 1000000002

    cmd = f"arrakis fetch --start {start} --end {end} --json H1:TEST-STATE_ONES"
    result = script_runner.run(shlex.split(cmd))
    assert result.success
    obj = json.loads(result.stdout)
    assert "time_ns" in obj


def test_fetch_with_duration(script_runner, arrakis_server):
    start = 1000000000

    cmd = f"arrakis fetch --start {start} --duration 10 --str H1:TEST-STATE_ONES"
    result = script_runner.run(shlex.split(cmd))
    assert result.success
    assert result.stdout.strip()


def test_publish_list(script_runner, arrakis_server):
    cmd = "arrakis publish --list --repr -p FAKE_H1"
    result = script_runner.run(shlex.split(cmd))
    assert result.success
    lines = result.stdout.strip().splitlines()
    assert len(lines) == 3
    for line in lines:
        assert "FAKE_H1" in line


def test_publish_invalid_args(script_runner, arrakis_server):
    cmd = "arrakis publish -p FAKE_H1 H1:TEST-CHANNEL_SIN"
    result = script_runner.run(shlex.split(cmd))
    assert not result.success
