"""Unit tests for format module."""

from __future__ import annotations

import numpy
import pytest

from arrakis.channel import Channel
from arrakis.format import formatter


@pytest.fixture
def channel():
    return Channel(name="H1:TEST-CHAN", data_type="float64", sample_rate=16384)


def test_formatter_str(channel):
    assert formatter(channel, "str") == str(channel)


def test_formatter_repr(channel):
    assert formatter(channel, "repr") == repr(channel)


def test_formatter_pprint(channel):
    result = formatter(channel, "pprint")
    assert "H1:TEST-CHAN" in result


def test_formatter_json(channel):
    result = formatter(channel, "json")
    assert '"name": "H1:TEST-CHAN"' in result
    assert '"data_type": "float64"' in result


def test_formatter_json_pp(channel):
    result = formatter(channel, "json-pp")
    assert "\n" in result
    assert '"name": "H1:TEST-CHAN"' in result


def test_formatter_json_abrv_with_array():
    data = numpy.array([1.0, 2.0, 3.0])
    result = formatter(data, "json-abrv")
    assert "array(" in result
    assert "dtype=" in result


def test_formatter_json_with_dtype():
    result = formatter(numpy.dtype("float64"), "json")
    assert '"float64"' in result


def test_formatter_json_with_array():
    data = numpy.array([1.0, 2.0, 3.0])
    result = formatter(data, "json")
    assert "[1.0, 2.0, 3.0]" in result


def test_formatter_json_unknown_type():
    result = formatter(object(), "json")
    assert "??" in result


def test_formatter_unknown_format(channel):
    with pytest.raises(ValueError, match="Unknown format"):
        formatter(channel, "badformat")
