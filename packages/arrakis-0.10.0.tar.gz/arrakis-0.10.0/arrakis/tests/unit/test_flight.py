"""Tests for ChainedFlightReader and flight utilities."""

import json
from typing import ClassVar
from unittest.mock import patch

import pytest
from pyarrow import flight

from ...flight import ChainedFlightReader, _endpoint_start_time


def make_endpoint(start=None, channels=None):
    """Create a FlightEndpoint with a JSON ticket encoding start/channels."""
    args = {}
    if start is not None:
        args["start"] = start
    if channels is not None:
        args["channels"] = channels
    ticket_bytes = json.dumps({"request": "Stream", "args": args}).encode()
    ticket = flight.Ticket(ticket_bytes)
    location = flight.Location.for_grpc_tcp("localhost", 31206)
    return flight.FlightEndpoint(ticket, [location])


class FakeMultiFlightReader:
    """Test double for MultiFlightReader that yields canned data."""

    def __init__(self, endpoints, initial_url, metadata=None):
        self.endpoints = endpoints
        self.initial_url = initial_url
        self.metadata = metadata
        self._buffer = []
        self._done = False
        self._entered = False
        self._closed = False
        # register with class-level tracker so tests can feed data
        FakeMultiFlightReader.instances.append(self)

    instances: ClassVar[list["FakeMultiFlightReader"]] = []

    def _id(self, endpoint):
        return endpoint.serialize()

    @property
    def streams(self):
        streams = {}
        for endpoint in self.endpoints:
            channels = []
            if self.metadata:
                try:
                    names = json.loads(endpoint.ticket.ticket)["args"]["channels"]
                except KeyError:
                    pass
                else:
                    channels = [self.metadata[chan] for chan in names]
            streams[self._id(endpoint)] = channels
        return streams

    def feed(self, endpoint_index, data):
        stream_id = self._id(self.endpoints[endpoint_index])
        self._buffer.append((stream_id, data))

    def finish(self):
        self._done = True

    def enter(self):
        self._entered = True

    def read(self, *, convert_blocks=False):
        buf = list(self._buffer)
        self._buffer.clear()
        yield from buf

    def done(self):
        return self._done and len(self._buffer) == 0

    def close(self):
        self._closed = True


class TestEndpointStartTime:
    def test_extracts_start(self):
        ep = make_endpoint(start=1000)
        assert _endpoint_start_time(ep) == 1000

    def test_missing_start_returns_none(self):
        ep = make_endpoint(channels=["H1:CAL-TEST"])
        assert _endpoint_start_time(ep) is None

    def test_invalid_json_returns_none(self):
        ticket = flight.Ticket(b"not json")
        location = flight.Location.for_grpc_tcp("localhost", 31206)
        ep = flight.FlightEndpoint(ticket, [location])
        assert _endpoint_start_time(ep) is None


class TestChainedFlightReaderGrouping:
    """Test that endpoints are grouped by start time and ordered correctly."""

    def test_single_slice(self):
        endpoints = [make_endpoint(start=100), make_endpoint(start=100)]
        reader = ChainedFlightReader(endpoints, "grpc://localhost:31206")
        assert len(reader._slices) == 1
        assert reader._slices[0][0] == 100
        assert len(reader._slices[0][1]) == 2

    def test_multiple_slices_ordered(self):
        endpoints = [
            make_endpoint(start=300),
            make_endpoint(start=100),
            make_endpoint(start=200),
        ]
        reader = ChainedFlightReader(endpoints, "grpc://localhost:31206")
        assert len(reader._slices) == 3
        assert [s[0] for s in reader._slices] == [100, 200, 300]

    def test_none_start_sorts_last(self):
        """Endpoints with no start time (live) sort after historical slices."""
        endpoints = [
            make_endpoint(start=None),
            make_endpoint(start=100),
        ]
        reader = ChainedFlightReader(endpoints, "grpc://localhost:31206")
        assert len(reader._slices) == 2
        assert reader._slices[0][0] == 100
        assert reader._slices[1][0] is None

    def test_mixed_grouping(self):
        """Endpoints with same start time are grouped together."""
        endpoints = [
            make_endpoint(start=200),
            make_endpoint(start=100),
            make_endpoint(start=200),
            make_endpoint(start=100),
        ]
        reader = ChainedFlightReader(endpoints, "grpc://localhost:31206")
        assert len(reader._slices) == 2
        assert reader._slices[0][0] == 100
        assert len(reader._slices[0][1]) == 2
        assert reader._slices[1][0] == 200
        assert len(reader._slices[1][1]) == 2


@pytest.fixture
def _fake_reader():
    FakeMultiFlightReader.instances.clear()
    with patch.object(
        ChainedFlightReader,
        "_make_reader",
        staticmethod(lambda eps, url, md: FakeMultiFlightReader(eps, url, metadata=md)),
    ):
        yield


@pytest.mark.usefixtures("_fake_reader")
class TestChainedFlightReaderSingleSlice:
    """Single-slice requests delegate directly to MultiFlightReader."""

    def test_delegate_is_set(self):
        endpoints = [make_endpoint(start=100), make_endpoint(start=100)]
        reader = ChainedFlightReader(endpoints, "grpc://localhost:31206")
        assert reader._delegate is not None

    def test_enter_delegates(self):
        endpoints = [make_endpoint(start=100)]
        reader = ChainedFlightReader(endpoints, "grpc://localhost:31206")
        reader.enter()
        assert reader._delegate._entered

    def test_read_yields_delegate_data(self):
        endpoints = [make_endpoint(start=100)]
        reader = ChainedFlightReader(endpoints, "grpc://localhost:31206")
        reader.enter()
        reader._delegate.feed(0, "block_a")
        reader._delegate.feed(0, "block_b")
        items = list(reader.read())
        assert len(items) == 2
        assert items[0][1] == "block_a"
        assert items[1][1] == "block_b"

    def test_done_delegates(self):
        endpoints = [make_endpoint(start=100)]
        reader = ChainedFlightReader(endpoints, "grpc://localhost:31206")
        reader.enter()
        assert not reader.done()
        reader._delegate.finish()
        assert reader.done()

    def test_close_delegates(self):
        endpoints = [make_endpoint(start=100)]
        reader = ChainedFlightReader(endpoints, "grpc://localhost:31206")
        reader.enter()
        reader.close()
        assert reader._delegate._closed

    def test_context_manager(self):
        endpoints = [make_endpoint(start=100)]
        reader = ChainedFlightReader(endpoints, "grpc://localhost:31206")
        with reader as r:
            assert r._delegate._entered
            r._delegate.feed(0, "data")
            items = list(r.read())
            assert len(items) == 1
        assert r._delegate._closed


@pytest.mark.usefixtures("_fake_reader")
class TestChainedFlightReaderMultiSlice:
    """Multi-slice requests read slices sequentially."""

    def test_no_delegate_for_multiple_slices(self):
        endpoints = [make_endpoint(start=100), make_endpoint(start=200)]
        reader = ChainedFlightReader(endpoints, "grpc://localhost:31206")
        assert reader._delegate is None

    def test_slices_read_in_order(self):
        endpoints = [make_endpoint(start=200), make_endpoint(start=100)]
        reader = ChainedFlightReader(endpoints, "grpc://localhost:31206")
        reader.enter()
        # after enter(), the first slice (start=100) should be active
        active = FakeMultiFlightReader.instances[-1]
        assert active._entered

        # feed data to slice 1 and finish it
        active.feed(0, "slice1_data")
        active.finish()
        items = list(reader.read())
        assert len(items) == 1
        assert items[0][1] == "slice1_data"

        # after exhausting slice 1, the next read should advance
        # to slice 2 (start=200)
        items = list(reader.read())
        # slice 2 reader was created by _advance_slice
        active2 = FakeMultiFlightReader.instances[-1]
        assert active2._entered
        active2.feed(0, "slice2_data")
        active2.finish()
        items = list(reader.read())
        assert len(items) == 1
        assert items[0][1] == "slice2_data"

    def test_done_after_all_slices_exhausted(self):
        endpoints = [make_endpoint(start=100), make_endpoint(start=200)]
        reader = ChainedFlightReader(endpoints, "grpc://localhost:31206")
        reader.enter()

        # exhaust slice 1
        active1 = FakeMultiFlightReader.instances[-1]
        active1.finish()
        list(reader.read())

        # exhaust slice 2
        active2 = FakeMultiFlightReader.instances[-1]
        active2.finish()
        list(reader.read())

        assert reader.done()

    def test_read_is_nonblocking(self):
        """read() should return when no data is available, not busy-wait."""
        endpoints = [make_endpoint(start=100), make_endpoint(start=200)]
        reader = ChainedFlightReader(endpoints, "grpc://localhost:31206")
        reader.enter()

        # no data fed, reader not done — read should return empty
        items = list(reader.read())
        assert items == []
        assert not reader.done()

    def test_close_cleans_up_current_reader(self):
        endpoints = [make_endpoint(start=100), make_endpoint(start=200)]
        reader = ChainedFlightReader(endpoints, "grpc://localhost:31206")
        reader.enter()
        active = FakeMultiFlightReader.instances[-1]
        reader.close()
        assert active._closed
        assert reader.done()
