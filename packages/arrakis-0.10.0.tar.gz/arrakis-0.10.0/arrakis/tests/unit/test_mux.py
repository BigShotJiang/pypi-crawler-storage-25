import gpstime
import numpy
import pytest

from ...block import SeriesBlock, Time
from ...channel import Channel
from ...mux import BlockMuxStream, TimedQueue

STRIDE = 62_500_000  # 62.5ms in nanoseconds
TIMEOUT = 2 * Time.s
GPS_T0 = 1_400_000_000 * Time.s
GPS_T0_DATETIME = gpstime.gpstime.fromgps(GPS_T0 / Time.s)


def make_channel(name="H1:FKE-TEST_CHANNEL", sample_rate=128, **kwargs):
    defaults = {
        "data_type": "float64",
        "partition_id": "A",
        "partition_index": 0,
        "stride": STRIDE,
        "max_latency": TIMEOUT,
    }
    defaults.update(kwargs)
    return Channel(name, sample_rate=sample_rate, **defaults)


def make_block(time_ns, channels, *, gap=False):
    """Create a SeriesBlock at the given time for the given channels."""
    if isinstance(channels, Channel):
        channels = [channels]
    data = {}
    chan_dict = {}
    for ch in channels:
        size = int(ch.sample_rate * STRIDE) // Time.s
        if gap:
            data[ch.name] = numpy.ma.masked_all(size, dtype=ch.data_type)
        else:
            data[ch.name] = numpy.random.randint(256, size=size).astype(ch.data_type)
        chan_dict[ch.name] = ch
    return SeriesBlock(time_ns, data, chan_dict)


def is_gap_block(block):
    """True if all series in the block are fully masked."""
    return all(
        isinstance(arr, numpy.ma.MaskedArray) and arr.mask.all()
        for arr in block.data.values()
    )


class FakeStreamReader:
    """A controllable StreamReader test double.

    Push (stream_id, block) pairs via `feed()`, then `read()` yields them.
    Call `finish()` to make `done()` return True.
    """

    def __init__(self, streams_map):
        self._streams = streams_map
        self._buffer = []
        self._done = False

    @property
    def streams(self):
        return self._streams

    def feed(self, stream_id, block):
        self._buffer.append((stream_id, block))

    def finish(self):
        self._done = True

    def enter(self):
        pass

    def __enter__(self):
        self.enter()
        return self

    def read(self, *, convert_blocks=False):
        buf = list(self._buffer)
        self._buffer.clear()
        yield from buf

    def done(self):
        return self._done and len(self._buffer) == 0

    def close(self):
        pass

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()
        return False


class ContinuousStreamReader:
    """A reader that yields blocks continuously from a generator.

    read() calls the generator to produce the next batch of blocks.
    done() always returns False — the only way to stop is via end_ns.
    Tracks how many blocks have been yielded and the max queue depth
    observed externally (set by test code).
    """

    def __init__(self, streams_map, block_generator):
        self._streams = streams_map
        self._gen = block_generator
        self.blocks_yielded = 0

    @property
    def streams(self):
        return self._streams

    def enter(self):
        pass

    def __enter__(self):
        self.enter()
        return self

    def read(self, *, convert_blocks=False):
        for item in self._gen:
            self.blocks_yielded += 1
            yield item

    def done(self):
        return False

    def close(self):
        pass

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()
        return False


class TestTimedQueueBasic:
    def test_push_pull_sequential(self):
        q = TimedQueue(stride=STRIDE, timeout=TIMEOUT, start=GPS_T0)
        t1 = GPS_T0
        t2 = GPS_T0 + STRIDE

        q.push(t1, "block_1")
        q.push(t2, "block_2")

        items = list(q.pull())
        assert len(items) == 2
        assert items[0] == (t1, "block_1")
        assert items[1] == (t2, "block_2")

    def test_drain_empties_queue(self):
        q = TimedQueue(stride=STRIDE, timeout=TIMEOUT, start=GPS_T0)
        q.push(GPS_T0, "a")
        q.push(GPS_T0 + STRIDE, "b")
        list(q.pull())
        assert len(q) == 0

    def test_backfill_gaps(self):
        q = TimedQueue(stride=STRIDE, timeout=TIMEOUT, start=GPS_T0)
        q.push(GPS_T0 + 2 * STRIDE, "after_gap")

        items = list(q.pull())
        assert len(items) == 3
        assert items[0] == (GPS_T0, None)
        assert items[1] == (GPS_T0 + STRIDE, None)
        assert items[2] == (GPS_T0 + 2 * STRIDE, "after_gap")

    def test_drop_old_timestamps(self):
        q = TimedQueue(stride=STRIDE, timeout=TIMEOUT, start=GPS_T0)
        q.push(GPS_T0 + STRIDE, "newer")
        with pytest.warns(UserWarning, match="timestamp is too old"):
            q.push(GPS_T0, "older")

        items = list(q.pull())
        assert len(items) == 2
        assert items[0] == (GPS_T0, None)
        assert items[1] == (GPS_T0 + STRIDE, "newer")

    def test_drop_equal_timestamp(self):
        q = TimedQueue(stride=STRIDE, timeout=TIMEOUT, start=GPS_T0)
        q.push(GPS_T0, "first")
        with pytest.warns(UserWarning, match="timestamp is too old"):
            q.push(GPS_T0, "duplicate")

        items = list(q.pull())
        assert len(items) == 1
        assert items[0] == (GPS_T0, "first")

    def test_stride_alignment_assertion(self):
        q = TimedQueue(stride=STRIDE, timeout=TIMEOUT, start=GPS_T0)
        with pytest.raises(AssertionError, match="not a multiple"):
            q.push(GPS_T0 + 1, "misaligned")

    def test_ready_with_enough_elements(self):
        q = TimedQueue(stride=STRIDE, timeout=TIMEOUT, start=GPS_T0)
        duration = 2 * STRIDE
        q.push(GPS_T0, "a")
        q.push(GPS_T0 + STRIDE, "b")
        assert q.ready(duration) == 2

    def test_ready_when_empty(self):
        q = TimedQueue(stride=STRIDE, timeout=TIMEOUT, start=GPS_T0)
        assert q.ready(STRIDE) is None

    def test_pull_with_duration(self):
        q = TimedQueue(stride=STRIDE, timeout=TIMEOUT, start=GPS_T0)
        duration = 2 * STRIDE
        for i in range(4):
            q.push(GPS_T0 + i * STRIDE, f"block_{i}")

        items = list(q.pull(duration))
        assert len(items) == 2
        assert items[0] == (GPS_T0, "block_0")
        assert items[1] == (GPS_T0 + STRIDE, "block_1")
        assert len(q) == 2

    def test_pull_with_duration_not_enough(self):
        q = TimedQueue(stride=STRIDE, timeout=TIMEOUT, start=GPS_T0)
        q.push(GPS_T0, "only_one")
        items = list(q.pull(2 * STRIDE))
        assert len(items) == 0
        assert len(q) == 1


class TestTimedQueueLive:
    """Tests for start=None (live stream) behavior using freezer."""

    def test_initialized_reset_on_first_real_block(self, freezer):
        freezer.move_to(GPS_T0_DATETIME)
        q = TimedQueue(stride=STRIDE, timeout=TIMEOUT, start=None)
        assert not q._initialized

        q.push(GPS_T0, "real_block")
        assert q._initialized
        assert q.last_time == GPS_T0

    def test_gap_push_does_not_set_initialized(self, freezer):
        freezer.move_to(GPS_T0_DATETIME)
        q = TimedQueue(stride=STRIDE, timeout=TIMEOUT, start=None)
        gap_time = (q.last_time // STRIDE + 1) * STRIDE
        q.push(gap_time, None, on_drop="ignore")
        assert not q._initialized

    def test_first_real_block_clears_queued_gaps(self, freezer):
        """After timeout gaps have accumulated, first real block resets
        last_time, effectively discarding the stale gaps."""
        freezer.move_to(GPS_T0_DATETIME)
        q = TimedQueue(stride=STRIDE, timeout=TIMEOUT, start=None)

        # simulate timeout pushing a few gaps
        gap_time = (q.last_time // STRIDE + 1) * STRIDE
        q.push(gap_time, None, on_drop="ignore")
        q.push(gap_time + STRIDE, None, on_drop="ignore")
        assert len(q) == 2

        # first real block arrives — clears stale gaps and resets last_time
        real_time = GPS_T0
        q.push(real_time, "real_block")
        assert q._initialized
        assert q.last_time == real_time
        # stale gaps must be gone; only the real block remains
        assert len(q) == 1
        items = list(q.pull())
        assert items[0] == (real_time, "real_block")

    def test_pull_drains_with_frozen_time(self, freezer):
        """With time frozen near data timestamps, pull works normally."""
        freezer.move_to(GPS_T0_DATETIME)
        q = TimedQueue(stride=STRIDE, timeout=TIMEOUT, start=None)

        q.push(GPS_T0, "first")
        q.push(GPS_T0 + STRIDE, "second")
        q.push(GPS_T0 + 2 * STRIDE, "third")

        items = list(q.pull())
        assert len(items) == 3
        assert all(item[1] is not None for item in items)

    def test_timeout_pushes_gaps_when_no_data(self, freezer):
        """When time advances past timeout with no data, gaps appear."""
        freezer.move_to(GPS_T0_DATETIME)
        q = TimedQueue(stride=STRIDE, timeout=TIMEOUT, start=None)

        # push one real block to initialize
        q.push(GPS_T0, "real_block")
        initial_len = len(q)

        # advance time past timeout
        freezer.tick(TIMEOUT / Time.s + 0.1)

        # _update_timeout (called by ready/pull) should push gap(s)
        q.update_timeout()
        assert len(q) > initial_len

    def test_timeout_does_not_outrun_real_data(self, freezer):
        """When real data arrives on time, timeout gaps should be dropped."""
        freezer.move_to(GPS_T0_DATETIME)
        q = TimedQueue(stride=STRIDE, timeout=TIMEOUT, start=None)

        # push blocks up to current time
        n_strides = int(TIMEOUT / STRIDE) + 2
        for i in range(n_strides):
            t = GPS_T0 + i * STRIDE
            q.push(t, f"block_{i}")

        # advance time by one stride
        freezer.tick(STRIDE / Time.s)
        q.update_timeout()

        # timeout gap should be dropped (data is ahead of timeout)
        items = list(q.pull())
        assert all(item[1] is not None for item in items)

    def test_recovery_after_timeout_gaps(self, freezer):
        """After timeout gaps, real data arriving should be usable."""
        freezer.move_to(GPS_T0_DATETIME)
        q = TimedQueue(stride=STRIDE, timeout=TIMEOUT, start=None)

        # push initial data
        q.push(GPS_T0, "initial")

        # advance time to create some timeout gaps
        freezer.tick(TIMEOUT / Time.s + STRIDE / Time.s)
        q.update_timeout()
        gap_count = len(q) - 1  # subtract the initial real block
        assert gap_count > 0

        # now push new real data at a time near "now"
        now_ns = int(gpstime.gpsnow() * Time.s)
        now_aligned = (now_ns // STRIDE) * STRIDE
        q.push(now_aligned, "recovery")

        items = list(q.pull())
        real_items = [item for item in items if item[1] is not None]
        assert len(real_items) == 2  # initial + recovery

    def test_late_data_dropped_after_timeout_advances(self, freezer):
        """Data arriving after timeout has advanced past it gets dropped."""
        freezer.move_to(GPS_T0_DATETIME)
        q = TimedQueue(stride=STRIDE, timeout=TIMEOUT, start=None)

        q.push(GPS_T0, "on_time")

        # advance time well past the initial data
        freezer.tick(TIMEOUT / Time.s + 1.0)
        q.update_timeout()
        # drain everything
        list(q.pull())

        # try to push data at the old time — should be dropped
        with pytest.warns(UserWarning, match="timestamp is too old"):
            q.push(GPS_T0 + STRIDE, "late_arrival")


class TestTimedQueueFrontAndDrain:
    def test_front_time_empty(self):
        q = TimedQueue(stride=STRIDE, timeout=TIMEOUT, start=GPS_T0)
        assert q.front_time() is None

    def test_front_time(self):
        q = TimedQueue(stride=STRIDE, timeout=TIMEOUT, start=GPS_T0)
        q.push(GPS_T0, "a")
        q.push(GPS_T0 + STRIDE, "b")
        assert q.front_time() == GPS_T0

    def test_drain_until(self):
        q = TimedQueue(stride=STRIDE, timeout=TIMEOUT, start=GPS_T0)
        for i in range(5):
            q.push(GPS_T0 + i * STRIDE, f"block_{i}")
        target = GPS_T0 + 3 * STRIDE
        q.drain_until(target)
        assert q.front_time() == target
        assert len(q) == 2

    def test_drain_until_advances_last_time(self):
        """drain_until must advance last_time so _update_timeout
        does not refill gaps before the drain target."""
        q = TimedQueue(stride=STRIDE, timeout=TIMEOUT, start=GPS_T0)
        q.push(GPS_T0, "a")
        q.push(GPS_T0 + STRIDE, "b")
        assert q.last_time == GPS_T0 + STRIDE

        target = GPS_T0 + 5 * STRIDE
        q.drain_until(target)
        # last_time must be at least target - stride so that
        # future pushes/backfills don't recreate drained elements
        assert q.last_time >= target - STRIDE

    def test_drain_until_resets_last_time_when_empty(self):
        """When drain_until empties a queue whose last_time is ahead
        of the target, last_time must be reset to target - stride so
        that _update_timeout refills from the target, not from
        last_time + stride (which would break alignment)."""
        q = TimedQueue(stride=STRIDE, timeout=TIMEOUT, start=GPS_T0)
        # Push data far ahead so last_time is well past the target
        far_ahead = GPS_T0 + 20 * STRIDE
        q.push(far_ahead, "x")
        assert q.last_time == far_ahead

        # Drain to a target behind the only element
        target = far_ahead + STRIDE
        q.drain_until(target)
        assert len(q) == 0
        # last_time must be exactly target - stride, NOT far_ahead
        assert q.last_time == target - STRIDE


class TestBlockMuxStreamSingleStream:
    def _make_reader_and_channel(self):
        ch = make_channel()
        stream_id = "test_stream"
        reader = FakeStreamReader({stream_id: [ch]})
        return reader, stream_id, ch

    def test_push_ready_pull(self):
        reader, stream_id, ch = self._make_reader_and_channel()
        mux = BlockMuxStream(reader, start=GPS_T0)

        block = make_block(GPS_T0, ch)
        mux.push(stream_id, block)

        assert mux.ready()
        result = mux.pull()
        assert result.time_ns == GPS_T0

    def test_gap_block_for_none_elements(self):
        reader, stream_id, ch = self._make_reader_and_channel()
        mux = BlockMuxStream(reader, start=GPS_T0)

        block = make_block(GPS_T0 + STRIDE, ch)
        mux.push(stream_id, block)

        assert mux.ready()
        result = mux.pull()
        assert result.time_ns == GPS_T0
        assert is_gap_block(result)

    def test_stream_yields_blocks(self):
        reader, stream_id, ch = self._make_reader_and_channel()

        n_blocks = 4
        for i in range(n_blocks):
            reader.feed(stream_id, make_block(GPS_T0 + i * STRIDE, ch))
        reader.finish()

        end_ns = GPS_T0 + n_blocks * STRIDE
        mux = BlockMuxStream(reader, start=GPS_T0)

        blocks = list(mux.stream(end_ns))
        assert len(blocks) > 0
        for b in blocks:
            assert ch.name in b.channels

    def test_stream_stops_at_end(self):
        reader, stream_id, ch = self._make_reader_and_channel()

        for i in range(10):
            reader.feed(stream_id, make_block(GPS_T0 + i * STRIDE, ch))
        reader.finish()

        end_ns = GPS_T0 + 3 * STRIDE
        mux = BlockMuxStream(reader, start=GPS_T0)
        blocks = list(mux.stream(end_ns))

        for b in blocks:
            assert b.time_ns <= end_ns

    def test_stream_start_none_immediate_data(self, freezer):
        """With start=None and data arriving immediately, blocks are yielded."""
        freezer.move_to(GPS_T0_DATETIME)
        reader, stream_id, ch = self._make_reader_and_channel()

        n_blocks = 4
        for i in range(n_blocks):
            reader.feed(stream_id, make_block(GPS_T0 + i * STRIDE, ch))
        reader.finish()

        end_ns = GPS_T0 + n_blocks * STRIDE
        mux = BlockMuxStream(reader, start=None)

        blocks = list(mux.stream(end_ns))
        assert len(blocks) > 0
        for b in blocks:
            assert ch.name in b.channels


class TestBlockMuxStreamNoLatency:
    """Tests for historical streams where max_latency is None."""

    def _make_channel(self, name="H1:FKE-HIST_CHANNEL", **kwargs):
        return make_channel(name=name, max_latency=None, **kwargs)

    def test_single_stream_no_latency(self):
        ch = self._make_channel()
        reader = FakeStreamReader({"test": [ch]})
        mux = BlockMuxStream(reader, start=GPS_T0)

        assert not mux._use_timeouts

        block = make_block(GPS_T0, ch)
        mux.push("test", block)
        assert mux.ready()
        result = mux.pull()
        assert result.time_ns == GPS_T0

    def test_two_streams_no_latency_disables_timeouts(self):
        ch1 = self._make_channel(name="H1:FKE-HIST_A", partition_id="A")
        ch2 = self._make_channel(name="H1:FKE-HIST_B", partition_id="B")
        reader = FakeStreamReader({"a": [ch1], "b": [ch2]})
        mux = BlockMuxStream(reader, start=GPS_T0)

        # Even with two queues, timeouts are disabled when no latency constraint
        assert not mux._use_timeouts

    def test_stream_yields_blocks_without_latency(self):
        ch = self._make_channel()
        stream_id = "test"
        reader = FakeStreamReader({stream_id: [ch]})

        n_blocks = 4
        for i in range(n_blocks):
            reader.feed(stream_id, make_block(GPS_T0 + i * STRIDE, ch))
        reader.finish()

        end_ns = GPS_T0 + n_blocks * STRIDE
        mux = BlockMuxStream(reader, start=GPS_T0)
        blocks = list(mux.stream(end_ns))
        assert len(blocks) > 0
        for b in blocks:
            assert ch.name in b.channels


class TestBlockMuxStreamTwoStreams:
    def _make_reader_and_channels(self):
        ch1 = make_channel(
            name="H1:FKE-CHANNEL_A",
            partition_id="A",
            partition_index=0,
        )
        ch2 = make_channel(
            name="H1:FKE-CHANNEL_B",
            partition_id="B",
            partition_index=1,
        )
        stream_a = "stream_A"
        stream_b = "stream_B"
        reader = FakeStreamReader({stream_a: [ch1], stream_b: [ch2]})
        return reader, stream_a, stream_b, ch1, ch2

    def test_combines_two_streams(self):
        reader, sa, sb, ch1, ch2 = self._make_reader_and_channels()
        mux = BlockMuxStream(reader, start=GPS_T0)

        mux.push(sa, make_block(GPS_T0, ch1))
        mux.push(sb, make_block(GPS_T0, ch2))

        assert mux.ready()
        result = mux.pull()
        assert ch1.name in result.channels
        assert ch2.name in result.channels

    def test_partial_stream_produces_gap(self):
        reader, sa, sb, ch1, ch2 = self._make_reader_and_channels()
        mux = BlockMuxStream(reader, start=GPS_T0)

        mux.push(sa, make_block(GPS_T0, ch1))
        mux[sb].push(GPS_T0, None, on_drop="ignore")

        assert mux.ready()
        result = mux.pull()
        assert ch1.name in result.channels
        assert ch2.name in result.channels
        assert numpy.ma.is_masked(result.data[ch2.name])

    def test_stream_does_not_pull_without_ready_when_done(self):
        """When reader is done and queues are misaligned, stream()
        must not call pull() without a ready() check."""
        reader, sa, _sb, ch1, _ch2 = self._make_reader_and_channels()

        # Feed only stream A, so queues are unbalanced when reader finishes
        reader.feed(sa, make_block(GPS_T0, ch1))
        reader.feed(sa, make_block(GPS_T0 + STRIDE, ch1))
        reader.finish()

        mux = BlockMuxStream(reader, start=GPS_T0)
        # stream() should terminate gracefully, not raise in pull()
        blocks = list(mux.stream(GPS_T0 + 10 * STRIDE))
        # stream B never had data, so no combined blocks are possible
        assert len(blocks) == 0

    def test_stream_with_two_streams_interleaved(self):
        reader, sa, sb, ch1, ch2 = self._make_reader_and_channels()
        n_blocks = 3
        for i in range(n_blocks):
            reader.feed(sa, make_block(GPS_T0 + i * STRIDE, ch1))
            reader.feed(sb, make_block(GPS_T0 + i * STRIDE, ch2))
        reader.finish()

        end_ns = GPS_T0 + n_blocks * STRIDE
        mux = BlockMuxStream(reader, start=GPS_T0)
        blocks = list(mux.stream(end_ns))

        assert len(blocks) > 0
        for b in blocks:
            assert ch1.name in b.channels
            assert ch2.name in b.channels


class TestBlockMuxStreamContinuousRead:
    @pytest.mark.timeout(5)
    def test_continuous_single_stream_yields_blocks(self):
        """stream() must yield blocks even when read() never stops."""
        ch = make_channel()
        stream_id = "test_stream"
        n_total = 20
        end_ns = GPS_T0 + n_total * STRIDE

        def gen():
            for i in range(n_total):
                yield stream_id, make_block(GPS_T0 + i * STRIDE, ch)

        reader = ContinuousStreamReader({stream_id: [ch]}, gen())
        mux = BlockMuxStream(reader, start=GPS_T0)
        blocks = list(mux.stream(end_ns))

        assert len(blocks) > 0
        for b in blocks:
            assert ch.name in b.channels

    @pytest.mark.timeout(5)
    def test_continuous_read_does_not_buffer_all_before_yielding(self):
        """stream() should yield blocks incrementally, not buffer everything
        from read() first."""
        ch = make_channel()
        stream_id = "test_stream"
        n_total = 100
        end_ns = GPS_T0 + n_total * STRIDE

        def gen():
            for i in range(n_total):
                yield stream_id, make_block(GPS_T0 + i * STRIDE, ch)

        reader = ContinuousStreamReader({stream_id: [ch]}, gen())
        mux = BlockMuxStream(reader, start=GPS_T0)

        max_queue_depth = 0
        for _block in mux.stream(end_ns):
            for q in mux._queues.values():
                max_queue_depth = max(max_queue_depth, len(q))

        assert max_queue_depth < n_total, (
            f"queue depth {max_queue_depth} suggests all blocks were "
            f"buffered before any were yielded"
        )

    @pytest.mark.timeout(5)
    def test_continuous_read_end_ns_stops_early(self):
        """stream() should stop at end_ns even with unlimited data."""
        ch = make_channel()
        stream_id = "test_stream"
        stop_at = 5
        end_ns = GPS_T0 + stop_at * STRIDE

        def gen():
            i = 0
            while True:
                yield stream_id, make_block(GPS_T0 + i * STRIDE, ch)
                i += 1

        reader = ContinuousStreamReader({stream_id: [ch]}, gen())
        mux = BlockMuxStream(reader, start=GPS_T0)
        blocks = list(mux.stream(end_ns))

        assert len(blocks) > 0
        for b in blocks:
            assert b.time_ns <= end_ns

    @pytest.mark.timeout(5)
    def test_continuous_two_streams_yields_combined(self):
        """With two continuous streams, stream() yields combined blocks."""
        ch1 = make_channel(
            name="H1:FKE-CHANNEL_A",
            partition_id="A",
            partition_index=0,
        )
        ch2 = make_channel(
            name="H1:FKE-CHANNEL_B",
            partition_id="B",
            partition_index=1,
        )
        sa, sb = "stream_A", "stream_B"
        n_total = 10
        end_ns = GPS_T0 + n_total * STRIDE

        def gen():
            for i in range(n_total):
                t = GPS_T0 + i * STRIDE
                yield sa, make_block(t, ch1)
                yield sb, make_block(t, ch2)

        reader = ContinuousStreamReader({sa: [ch1], sb: [ch2]}, gen())
        mux = BlockMuxStream(reader, start=GPS_T0)
        blocks = list(mux.stream(end_ns))

        assert len(blocks) > 0
        for b in blocks:
            assert ch1.name in b.channels
            assert ch2.name in b.channels

    @pytest.mark.timeout(5)
    def test_continuous_read_many_blocks_per_call(self):
        """When read() yields many blocks at once, stream() should still
        yield incrementally."""
        ch = make_channel()
        stream_id = "test_stream"
        n_total = 50
        end_ns = GPS_T0 + n_total * STRIDE

        def gen():
            for i in range(n_total):
                yield stream_id, make_block(GPS_T0 + i * STRIDE, ch)

        reader = ContinuousStreamReader({stream_id: [ch]}, gen())
        mux = BlockMuxStream(reader, start=GPS_T0)

        block_count = 0
        for _block in mux.stream(end_ns):
            block_count += 1
            if block_count == 1:
                assert reader.blocks_yielded < n_total, (
                    "all blocks consumed from reader before first yield"
                )

        assert block_count > 0

    @pytest.mark.timeout(5)
    def test_continuous_two_streams_one_ahead(self):
        """When one stream is ahead of another, stream() should still
        yield when both queues have enough data."""
        ch1 = make_channel(
            name="H1:FKE-CHANNEL_A",
            partition_id="A",
            partition_index=0,
        )
        ch2 = make_channel(
            name="H1:FKE-CHANNEL_B",
            partition_id="B",
            partition_index=1,
        )
        sa, sb = "stream_A", "stream_B"
        n_total = 10
        end_ns = GPS_T0 + n_total * STRIDE

        def gen():
            # stream A sends 3 blocks before stream B sends any
            for i in range(3):
                yield sa, make_block(GPS_T0 + i * STRIDE, ch1)
            # then they alternate
            for i in range(n_total):
                t = GPS_T0 + i * STRIDE
                yield sb, make_block(t, ch2)
                if i + 3 < n_total:
                    yield sa, make_block(GPS_T0 + (i + 3) * STRIDE, ch1)

        reader = ContinuousStreamReader({sa: [ch1], sb: [ch2]}, gen())
        mux = BlockMuxStream(reader, start=GPS_T0)
        blocks = list(mux.stream(end_ns))

        assert len(blocks) > 0
        for b in blocks:
            assert ch1.name in b.channels
            assert ch2.name in b.channels


class TestPartialEdgeBlocks:
    """Tests for non-stride-aligned start/end (archival requests with large stride)."""

    # Use a large stride (16s) to make partial blocks obvious
    LARGE_STRIDE = 16 * Time.s

    def _make_channel(self, name="H1:FKE-HIST_CHANNEL", **kwargs):
        return make_channel(
            name=name,
            stride=self.LARGE_STRIDE,
            max_latency=None,
            **kwargs,
        )

    def _make_sized_block(self, time_ns, channel, duration_ns):
        """Create a block with a specific duration (may be partial stride)."""
        n_samples = int(channel.sample_rate * duration_ns) // Time.s
        data = {
            channel.name: numpy.random.randint(256, size=n_samples).astype(
                channel.data_type
            )
        }
        return SeriesBlock(time_ns, data, {channel.name: channel})

    def test_timed_queue_accepts_non_aligned_start(self):
        """TimedQueue.push() accepts a block at a non-stride-aligned start time."""
        start = GPS_T0 + 5 * Time.s  # not a multiple of 16s stride
        q = TimedQueue(stride=self.LARGE_STRIDE, timeout=0, start=start)
        # should not raise
        q.push(start, "partial_block")
        items = list(q.pull())
        assert len(items) == 1
        assert items[0] == (start, "partial_block")

    def test_no_spurious_gaps_before_start(self):
        """No gap slots should be generated before the start time."""
        start = GPS_T0 + 5 * Time.s
        q = TimedQueue(stride=self.LARGE_STRIDE, timeout=0, start=start)
        q.push(start, "partial_first")
        items = list(q.pull())
        # only the one block, no gaps before it
        assert len(items) == 1
        assert items[0][1] == "partial_first"

    def test_stride_aligned_blocks_after_partial_start(self):
        """After a partial first block, stride-aligned blocks work normally."""
        start = GPS_T0 + 5 * Time.s
        # next stride boundary after start
        next_boundary = ((start // self.LARGE_STRIDE) + 1) * self.LARGE_STRIDE
        q = TimedQueue(stride=self.LARGE_STRIDE, timeout=0, start=start)
        q.push(start, "partial_first")
        q.push(next_boundary, "aligned_second")
        items = list(q.pull())
        assert len(items) == 2
        assert items[0] == (start, "partial_first")
        assert items[1] == (next_boundary, "aligned_second")

    def test_gap_detection_after_partial_start(self):
        """Gaps after a partial first block are detected at stride boundaries."""
        start = GPS_T0 + 5 * Time.s
        next_boundary = ((start // self.LARGE_STRIDE) + 1) * self.LARGE_STRIDE
        # skip one stride-aligned slot
        q = TimedQueue(stride=self.LARGE_STRIDE, timeout=0, start=start)
        q.push(start, "partial_first")
        q.push(next_boundary + self.LARGE_STRIDE, "after_gap")
        items = list(q.pull())
        assert len(items) == 3
        assert items[0] == (start, "partial_first")
        assert items[1] == (next_boundary, None)  # gap
        assert items[2] == (next_boundary + self.LARGE_STRIDE, "after_gap")

    def test_mux_stream_partial_start_and_end(self):
        """BlockMuxStream handles a request where start/end don't align to stride."""
        ch = self._make_channel()
        stream_id = "test"

        # request: [start, end) where neither aligns to 16s stride
        start = GPS_T0 + 5 * Time.s
        end = GPS_T0 + 37 * Time.s  # 32s of data total
        next_boundary = ((start // self.LARGE_STRIDE) + 1) * self.LARGE_STRIDE

        reader = FakeStreamReader({stream_id: [ch]})

        # partial first block: [start, next_boundary)
        first_dur = next_boundary - start
        reader.feed(stream_id, self._make_sized_block(start, ch, first_dur))
        # full middle block: [next_boundary, next_boundary + stride)
        reader.feed(
            stream_id, self._make_sized_block(next_boundary, ch, self.LARGE_STRIDE)
        )
        # partial last block: [next_boundary + stride, end)
        last_start = next_boundary + self.LARGE_STRIDE
        last_dur = end - last_start
        reader.feed(stream_id, self._make_sized_block(last_start, ch, last_dur))
        reader.finish()

        mux = BlockMuxStream(reader, start=start)
        blocks = list(mux.stream(end))

        assert len(blocks) > 0
        # first block starts at our requested start
        assert blocks[0].time_ns == start
        # all blocks within [start, end]
        for b in blocks:
            assert b.time_ns >= start
            assert b.time_ns <= end

    def test_mux_stream_single_partial_block(self):
        """A request smaller than stride produces a single partial block."""
        ch = self._make_channel()
        stream_id = "test"

        start = GPS_T0 + 5 * Time.s
        end = GPS_T0 + 10 * Time.s  # 5s, less than 16s stride

        reader = FakeStreamReader({stream_id: [ch]})
        reader.feed(stream_id, self._make_sized_block(start, ch, end - start))
        reader.finish()

        mux = BlockMuxStream(reader, start=start)
        blocks = list(mux.stream(end))

        assert len(blocks) == 1
        assert blocks[0].time_ns == start
        assert blocks[0].end_ns == end


class TestBlockMuxStreamAlignmentBug:
    """Regression test for misaligned queues after drain_until.

    When _align_queues drains behind queues, drain_until must advance
    last_time.  Otherwise _update_timeout refills gaps from the old
    last_time, which can be before the alignment target, causing
    combine_blocks to see different time_ns across queues.
    """

    def test_drain_then_timeout_preserves_alignment(self, freezer):
        """After alignment drains a queue, _update_timeout must not
        refill elements before the alignment target."""
        freezer.move_to(GPS_T0_DATETIME)
        ch1 = make_channel(
            name="H1:FKE-CHANNEL_A",
            partition_id="A",
            partition_index=0,
        )
        ch2 = make_channel(
            name="H1:FKE-CHANNEL_B",
            partition_id="B",
            partition_index=1,
        )
        ch3 = make_channel(
            name="H1:FKE-CHANNEL_C",
            partition_id="C",
            partition_index=2,
        )
        sa, sb, sc = "stream_A", "stream_B", "stream_C"
        reader = FakeStreamReader({sa: [ch1], sb: [ch2], sc: [ch3]})
        mux = BlockMuxStream(reader, start=None)

        # Push data at different times to simulate Kafka partition skew:
        # stream A has early data, stream B has late data, stream C in between
        mux.push(sa, make_block(GPS_T0, ch1))
        mux.push(sa, make_block(GPS_T0 + STRIDE, ch1))
        mux.push(sc, make_block(GPS_T0 + 2 * STRIDE, ch3))
        mux.push(sc, make_block(GPS_T0 + 3 * STRIDE, ch3))
        # stream B arrives much later
        mux.push(sb, make_block(GPS_T0 + 5 * STRIDE, ch2))
        mux.push(sb, make_block(GPS_T0 + 6 * STRIDE, ch2))

        # Advance time so _update_timeout will push gaps
        freezer.tick(TIMEOUT / Time.s + 1.0)

        # This should NOT raise AssertionError in combine_blocks
        if mux.ready():
            block = mux.pull()
            # all channels present and times agree
            assert ch1.name in block.channels
            assert ch2.name in block.channels
            assert ch3.name in block.channels

    def test_empty_queue_ahead_of_target_realigns(self, freezer):
        """When a queue is empty with last_time ahead of the alignment
        target (from prior timeout gap-filling), _update_timeout must
        refill from the target, not from last_time + stride.

        Without the fix in drain_until, combine_blocks raises
        AssertionError because the refilled queue's front doesn't
        match the other queues' front.
        """
        freezer.move_to(GPS_T0_DATETIME)
        ch1 = make_channel(name="H1:FKE-CHANNEL_A", partition_id="A", partition_index=0)
        ch2 = make_channel(name="H1:FKE-CHANNEL_B", partition_id="B", partition_index=1)
        sa, sb = "stream_A", "stream_B"
        reader = FakeStreamReader({sa: [ch1], sb: [ch2]})
        mux = BlockMuxStream(reader, start=None)

        # Push real data to both streams at the same time to initialize
        mux.push(sa, make_block(GPS_T0, ch1))
        mux.push(sb, make_block(GPS_T0, ch2))

        # Advance time so _update_timeout fills both queues with gaps
        # well past the real data
        freezer.tick(TIMEOUT / Time.s + 2.0)

        # Drain multiple ready blocks to empty the queues
        while mux.ready():
            mux.pull()

        # Now both queues are empty with last_time far ahead.
        # Push new real data to stream A only — stream B stays empty.
        new_time = GPS_T0 + 50 * STRIDE
        mux.push(sa, make_block(new_time, ch1))
        mux.push(sa, make_block(new_time + STRIDE, ch1))

        # Advance time so _update_timeout can fill stream B
        freezer.tick(TIMEOUT / Time.s + 2.0)

        # This must NOT raise AssertionError in combine_blocks
        if mux.ready():
            block = mux.pull()
            assert ch1.name in block.channels
            assert ch2.name in block.channels

    def test_ready_timeout_does_not_break_alignment(self, freezer):
        """Regression: _update_timeout must not run AFTER _align_queues.

        Old code called _align_queues() then q.ready() which triggered
        _update_timeout() per-queue.  Because each queue's timeout
        push depends on its own last_time, the per-queue timeout could
        add elements at different positions, breaking the alignment
        that _align_queues had just established.

        The fix updates all timeouts first, then aligns, then checks
        readiness without re-triggering timeouts.
        """
        freezer.move_to(GPS_T0_DATETIME)
        ch1 = make_channel(name="H1:FKE-CHANNEL_A", partition_id="A", partition_index=0)
        ch2 = make_channel(name="H1:FKE-CHANNEL_B", partition_id="B", partition_index=1)
        ch3 = make_channel(name="H1:FKE-CHANNEL_C", partition_id="C", partition_index=2)
        sa, sb, sc = "stream_A", "stream_B", "stream_C"
        reader = FakeStreamReader({sa: [ch1], sb: [ch2], sc: [ch3]})
        mux = BlockMuxStream(reader, start=None)

        # Push real data at staggered times to create different last_time values
        mux.push(sa, make_block(GPS_T0, ch1))
        mux.push(sb, make_block(GPS_T0 + 2 * STRIDE, ch2))
        mux.push(sc, make_block(GPS_T0 + 4 * STRIDE, ch3))

        # Advance time so _update_timeout would push gaps, but at
        # different positions for each queue (since last_time differs)
        freezer.tick(TIMEOUT / Time.s + 1.0)

        # ready() must align all queues.  If _update_timeout runs
        # after alignment, it would re-diverge them and pull() would
        # crash in combine_blocks.
        while mux.ready():
            block = mux.pull()
            assert ch1.name in block.channels
            assert ch2.name in block.channels
            assert ch3.name in block.channels
