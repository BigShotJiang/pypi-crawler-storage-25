"""API Key Model.

SQLAlchemy ORM model for server-to-server authentication. API keys are stored as
one-way hashes; the raw key is shown only at creation time. Scopes (e.g. read_only)
restrict what operations the key can perform.

Usage:
    >>> from fastx_database.persistence.models.api_key import ApiKey
    >>> # Keys are created via repository; auth middleware validates key_hash and scopes
"""

from datetime import datetime

from sqlalchemy import BigInteger, Column, DateTime, ForeignKey, String
from sqlalchemy.dialects.postgresql import JSONB

from fastx_database.core.constants.db import MAX_IP_ADDRESS_LENGTH, ServerDefault, StringLength
from fastx_database.core.constants.table import Table
from fastx_database.persistence.models import Base


class ApiKey(Base):
    """API key for server-to-server authentication.

    Stores a hash of the secret key; the plaintext is never persisted. Scopes
    (JSON array) limit which endpoints or actions the key can call. Optional
    last_used_at supports usage analytics; revoked_at supports key rotation.

    Attributes:
        id: Primary key.
        user_id: Owner of the key (FK to user).
        key_hash: One-way hash of the secret (e.g. SHA-256); unique, indexed.
        name: Human-readable label for the key.
        scopes: JSONB array of scope strings (e.g. ["read_only"]).
        last_used_at: Last time the key was used for a request.
        created_at: When the key was created.
        revoked_at: If set, key is invalid and must not be accepted.

    """

    __tablename__ = Table.API_KEY

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    user_id = Column(
        BigInteger,
        ForeignKey(Table.USER + ".id"),
        nullable=False,
        index=True,
    )
    key_hash = Column(String(StringLength.URN), nullable=False, unique=True, index=True)
    name = Column(String(StringLength.NAME), nullable=False)
    description = Column(String(StringLength.DESCRIPTION), nullable=True)
    scopes = Column(JSONB, nullable=False, server_default=ServerDefault.EMPTY_JSON_ARRAY)
    expires_at = Column(DateTime(timezone=True), nullable=True)
    last_used_at = Column(DateTime(timezone=True), nullable=True)
    last_used_ip = Column(String(MAX_IP_ADDRESS_LENGTH), nullable=True)  # IPv4 or IPv6
    created_at = Column(
        DateTime(timezone=True), nullable=False, default=datetime.utcnow
    )
    revoked_at = Column(DateTime(timezone=True), nullable=True)

    def to_dict(self) -> dict:
        """Execute to_dict operation.

        Returns:
            The result of the operation.
        """
        return {
            "id": self.id,
            "user_id": self.user_id,
            "name": self.name,
            "description": self.description,
            "prefix": "kiv_***",
            "scopes": self.scopes or [],
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "last_used_at": self.last_used_at.isoformat()
            if self.last_used_at
            else None,
            "last_used_ip": self.last_used_ip,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "revoked_at": self.revoked_at.isoformat() if self.revoked_at else None,
        }
