"""Education Level Lookup Model.

SQLAlchemy ORM model for education level codes (e.g. high_school, bachelor,
master). Referenced by profile.education_level_id. Code is unique.

Usage:
    >>> from fastx_database.persistence.models.education_level_lk import EducationLevelLk
    >>> # Used in profile for highest education level
"""

from datetime import datetime

from sqlalchemy import BigInteger, Column, DateTime, String

from fastx_database.core.constants.table import Table
from fastx_database.persistence.models import Base


class EducationLevelLk(Base):
    """Lookup: education level (e.g. high_school, bachelor, master).

    Attributes:
        id: Primary key.
        urn: Unique Resource Name.
        code: Unique code.
        description: Human-readable label.
        created_at, updated_at: Timestamps.

    """

    __tablename__ = Table.EDUCATION_LEVEL_LK

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    urn = Column(String(128), nullable=False, unique=True, index=True)
    code = Column(String(64), nullable=False, unique=True, index=True)
    description = Column(String(255), nullable=False)
    created_at = Column(
        DateTime(timezone=True), nullable=False, default=datetime.utcnow
    )
    updated_at = Column(
        DateTime(timezone=True), nullable=True, onupdate=datetime.utcnow
    )

    def to_dict(self) -> dict:
        """Execute to_dict operation.

        Returns:
            The result of the operation.
        """
        return {
            "urn": self.urn,
            "code": self.code,
            "description": self.description,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
