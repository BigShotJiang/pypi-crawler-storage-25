from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.file_import_products_response_201_field_mappings_item import (
        FileImportProductsResponse201FieldMappingsItem,
    )
    from ..models.file_import_products_response_201_links_item import FileImportProductsResponse201LinksItem


T = TypeVar("T", bound="FileImportProductsResponse201")


@_attrs_define
class FileImportProductsResponse201:
    """
    Attributes:
        file_import_id (int | Unset):
        name (str | Unset):
        created (str | Unset):
        records (int | Unset):
        import_type (str | Unset):
        status (str | Unset):
        field_mappings (list[FileImportProductsResponse201FieldMappingsItem] | Unset):
        results (None | str | Unset):
        links (list[FileImportProductsResponse201LinksItem] | Unset):
    """

    file_import_id: int | Unset = UNSET
    name: str | Unset = UNSET
    created: str | Unset = UNSET
    records: int | Unset = UNSET
    import_type: str | Unset = UNSET
    status: str | Unset = UNSET
    field_mappings: list[FileImportProductsResponse201FieldMappingsItem] | Unset = UNSET
    results: None | str | Unset = UNSET
    links: list[FileImportProductsResponse201LinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        file_import_id = self.file_import_id

        name = self.name

        created = self.created

        records = self.records

        import_type = self.import_type

        status = self.status

        field_mappings: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.field_mappings, Unset):
            field_mappings = []
            for field_mappings_item_data in self.field_mappings:
                field_mappings_item = field_mappings_item_data.to_dict()
                field_mappings.append(field_mappings_item)

        results: None | str | Unset
        if isinstance(self.results, Unset):
            results = UNSET
        else:
            results = self.results

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if file_import_id is not UNSET:
            field_dict["FileImportID"] = file_import_id
        if name is not UNSET:
            field_dict["Name"] = name
        if created is not UNSET:
            field_dict["Created"] = created
        if records is not UNSET:
            field_dict["Records"] = records
        if import_type is not UNSET:
            field_dict["ImportType"] = import_type
        if status is not UNSET:
            field_dict["Status"] = status
        if field_mappings is not UNSET:
            field_dict["FieldMappings"] = field_mappings
        if results is not UNSET:
            field_dict["Results"] = results
        if links is not UNSET:
            field_dict["Links"] = links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.file_import_products_response_201_field_mappings_item import (
            FileImportProductsResponse201FieldMappingsItem,
        )
        from ..models.file_import_products_response_201_links_item import FileImportProductsResponse201LinksItem

        d = dict(src_dict)
        file_import_id = d.pop("FileImportID", UNSET)

        name = d.pop("Name", UNSET)

        created = d.pop("Created", UNSET)

        records = d.pop("Records", UNSET)

        import_type = d.pop("ImportType", UNSET)

        status = d.pop("Status", UNSET)

        _field_mappings = d.pop("FieldMappings", UNSET)
        field_mappings: list[FileImportProductsResponse201FieldMappingsItem] | Unset = UNSET
        if _field_mappings is not UNSET:
            field_mappings = []
            for field_mappings_item_data in _field_mappings:
                field_mappings_item = FileImportProductsResponse201FieldMappingsItem.from_dict(field_mappings_item_data)

                field_mappings.append(field_mappings_item)

        def _parse_results(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        results = _parse_results(d.pop("Results", UNSET))

        _links = d.pop("Links", UNSET)
        links: list[FileImportProductsResponse201LinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = FileImportProductsResponse201LinksItem.from_dict(links_item_data)

                links.append(links_item)

        file_import_products_response_201 = cls(
            file_import_id=file_import_id,
            name=name,
            created=created,
            records=records,
            import_type=import_type,
            status=status,
            field_mappings=field_mappings,
            results=results,
            links=links,
        )

        file_import_products_response_201.additional_properties = d
        return file_import_products_response_201

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
