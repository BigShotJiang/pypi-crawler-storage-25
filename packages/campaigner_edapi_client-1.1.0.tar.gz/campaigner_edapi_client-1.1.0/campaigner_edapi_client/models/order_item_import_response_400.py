from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.order_item_import_response_400_failures_item import OrderItemImportResponse400FailuresItem


T = TypeVar("T", bound="OrderItemImportResponse400")


@_attrs_define
class OrderItemImportResponse400:
    """
    Attributes:
        orders_submitted (int | Unset):
        successes (int | Unset):
        failures (list[OrderItemImportResponse400FailuresItem] | Unset):
    """

    orders_submitted: int | Unset = UNSET
    successes: int | Unset = UNSET
    failures: list[OrderItemImportResponse400FailuresItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        orders_submitted = self.orders_submitted

        successes = self.successes

        failures: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.failures, Unset):
            failures = []
            for failures_item_data in self.failures:
                failures_item = failures_item_data.to_dict()
                failures.append(failures_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if orders_submitted is not UNSET:
            field_dict["OrdersSubmitted"] = orders_submitted
        if successes is not UNSET:
            field_dict["Successes"] = successes
        if failures is not UNSET:
            field_dict["Failures"] = failures

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.order_item_import_response_400_failures_item import OrderItemImportResponse400FailuresItem

        d = dict(src_dict)
        orders_submitted = d.pop("OrdersSubmitted", UNSET)

        successes = d.pop("Successes", UNSET)

        _failures = d.pop("Failures", UNSET)
        failures: list[OrderItemImportResponse400FailuresItem] | Unset = UNSET
        if _failures is not UNSET:
            failures = []
            for failures_item_data in _failures:
                failures_item = OrderItemImportResponse400FailuresItem.from_dict(failures_item_data)

                failures.append(failures_item)

        order_item_import_response_400 = cls(
            orders_submitted=orders_submitted,
            successes=successes,
            failures=failures,
        )

        order_item_import_response_400.additional_properties = d
        return order_item_import_response_400

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
