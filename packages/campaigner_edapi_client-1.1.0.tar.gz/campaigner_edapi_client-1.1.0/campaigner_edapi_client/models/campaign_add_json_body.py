from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="CampaignAddJsonBody")


@_attrs_define
class CampaignAddJsonBody:
    """
    Attributes:
        name (str | Unset):
        creative_id (int | Unset):
        subject (str | Unset):
        from_name (str | Unset):
        publication_id (int | Unset):
    """

    name: str | Unset = UNSET
    creative_id: int | Unset = UNSET
    subject: str | Unset = UNSET
    from_name: str | Unset = UNSET
    publication_id: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        creative_id = self.creative_id

        subject = self.subject

        from_name = self.from_name

        publication_id = self.publication_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["Name"] = name
        if creative_id is not UNSET:
            field_dict["CreativeID"] = creative_id
        if subject is not UNSET:
            field_dict["Subject"] = subject
        if from_name is not UNSET:
            field_dict["FromName"] = from_name
        if publication_id is not UNSET:
            field_dict["PublicationID"] = publication_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("Name", UNSET)

        creative_id = d.pop("CreativeID", UNSET)

        subject = d.pop("Subject", UNSET)

        from_name = d.pop("FromName", UNSET)

        publication_id = d.pop("PublicationID", UNSET)

        campaign_add_json_body = cls(
            name=name,
            creative_id=creative_id,
            subject=subject,
            from_name=from_name,
            publication_id=publication_id,
        )

        campaign_add_json_body.additional_properties = d
        return campaign_add_json_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
