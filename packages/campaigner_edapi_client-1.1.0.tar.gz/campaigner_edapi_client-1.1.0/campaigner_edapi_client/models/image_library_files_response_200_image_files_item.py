from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.image_library_files_response_200_image_files_item_links_item import (
        ImageLibraryFilesResponse200ImageFilesItemLinksItem,
    )


T = TypeVar("T", bound="ImageLibraryFilesResponse200ImageFilesItem")


@_attrs_define
class ImageLibraryFilesResponse200ImageFilesItem:
    """
    Attributes:
        file_name (str | Unset):
        uri (str | Unset):
        local_path (str | Unset):
        size (int | Unset):
        height (int | Unset):
        width (int | Unset):
        created (str | Unset):
        links (list[ImageLibraryFilesResponse200ImageFilesItemLinksItem] | Unset):
    """

    file_name: str | Unset = UNSET
    uri: str | Unset = UNSET
    local_path: str | Unset = UNSET
    size: int | Unset = UNSET
    height: int | Unset = UNSET
    width: int | Unset = UNSET
    created: str | Unset = UNSET
    links: list[ImageLibraryFilesResponse200ImageFilesItemLinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        file_name = self.file_name

        uri = self.uri

        local_path = self.local_path

        size = self.size

        height = self.height

        width = self.width

        created = self.created

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if file_name is not UNSET:
            field_dict["FileName"] = file_name
        if uri is not UNSET:
            field_dict["Uri"] = uri
        if local_path is not UNSET:
            field_dict["LocalPath"] = local_path
        if size is not UNSET:
            field_dict["Size"] = size
        if height is not UNSET:
            field_dict["Height"] = height
        if width is not UNSET:
            field_dict["Width"] = width
        if created is not UNSET:
            field_dict["Created"] = created
        if links is not UNSET:
            field_dict["Links"] = links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.image_library_files_response_200_image_files_item_links_item import (
            ImageLibraryFilesResponse200ImageFilesItemLinksItem,
        )

        d = dict(src_dict)
        file_name = d.pop("FileName", UNSET)

        uri = d.pop("Uri", UNSET)

        local_path = d.pop("LocalPath", UNSET)

        size = d.pop("Size", UNSET)

        height = d.pop("Height", UNSET)

        width = d.pop("Width", UNSET)

        created = d.pop("Created", UNSET)

        _links = d.pop("Links", UNSET)
        links: list[ImageLibraryFilesResponse200ImageFilesItemLinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = ImageLibraryFilesResponse200ImageFilesItemLinksItem.from_dict(links_item_data)

                links.append(links_item)

        image_library_files_response_200_image_files_item = cls(
            file_name=file_name,
            uri=uri,
            local_path=local_path,
            size=size,
            height=height,
            width=width,
            created=created,
            links=links,
        )

        image_library_files_response_200_image_files_item.additional_properties = d
        return image_library_files_response_200_image_files_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
