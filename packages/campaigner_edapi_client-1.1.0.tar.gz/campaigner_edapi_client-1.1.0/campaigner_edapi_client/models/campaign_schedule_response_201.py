from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.campaign_schedule_response_201_links_item import CampaignScheduleResponse201LinksItem
    from ..models.campaign_schedule_response_201_publication import CampaignScheduleResponse201Publication


T = TypeVar("T", bound="CampaignScheduleResponse201")


@_attrs_define
class CampaignScheduleResponse201:
    """
    Attributes:
        campaign_id (int | Unset):
        name (str | Unset):
        status (str | Unset):
        is_active (bool | Unset):
        created (str | Unset):
        schedule_date (str | Unset):
        from_name (str | Unset):
        from_email (str | Unset):
        to_name (str | Unset):
        subject (str | Unset):
        archive_url (str | Unset):
        emails_sent (int | Unset):
        opens (int | Unset):
        unique_clicks (int | Unset):
        total_clicks (int | Unset):
        removes (int | Unset):
        forwards (int | Unset):
        forwards_from (int | Unset):
        hard_bounces (int | Unset):
        soft_bounces (int | Unset):
        complaints (int | Unset):
        delivered (int | Unset):
        delivery_rate (float | Unset):
        open_rate (float | Unset):
        unique_rate (float | Unset):
        ctr (float | Unset):
        remove_rate (float | Unset):
        bounce_rate (float | Unset):
        soft_bounce_rate (float | Unset):
        complaint_rate (float | Unset):
        publication (CampaignScheduleResponse201Publication | Unset):
        links (list[CampaignScheduleResponse201LinksItem] | Unset):
    """

    campaign_id: int | Unset = UNSET
    name: str | Unset = UNSET
    status: str | Unset = UNSET
    is_active: bool | Unset = UNSET
    created: str | Unset = UNSET
    schedule_date: str | Unset = UNSET
    from_name: str | Unset = UNSET
    from_email: str | Unset = UNSET
    to_name: str | Unset = UNSET
    subject: str | Unset = UNSET
    archive_url: str | Unset = UNSET
    emails_sent: int | Unset = UNSET
    opens: int | Unset = UNSET
    unique_clicks: int | Unset = UNSET
    total_clicks: int | Unset = UNSET
    removes: int | Unset = UNSET
    forwards: int | Unset = UNSET
    forwards_from: int | Unset = UNSET
    hard_bounces: int | Unset = UNSET
    soft_bounces: int | Unset = UNSET
    complaints: int | Unset = UNSET
    delivered: int | Unset = UNSET
    delivery_rate: float | Unset = UNSET
    open_rate: float | Unset = UNSET
    unique_rate: float | Unset = UNSET
    ctr: float | Unset = UNSET
    remove_rate: float | Unset = UNSET
    bounce_rate: float | Unset = UNSET
    soft_bounce_rate: float | Unset = UNSET
    complaint_rate: float | Unset = UNSET
    publication: CampaignScheduleResponse201Publication | Unset = UNSET
    links: list[CampaignScheduleResponse201LinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        campaign_id = self.campaign_id

        name = self.name

        status = self.status

        is_active = self.is_active

        created = self.created

        schedule_date = self.schedule_date

        from_name = self.from_name

        from_email = self.from_email

        to_name = self.to_name

        subject = self.subject

        archive_url = self.archive_url

        emails_sent = self.emails_sent

        opens = self.opens

        unique_clicks = self.unique_clicks

        total_clicks = self.total_clicks

        removes = self.removes

        forwards = self.forwards

        forwards_from = self.forwards_from

        hard_bounces = self.hard_bounces

        soft_bounces = self.soft_bounces

        complaints = self.complaints

        delivered = self.delivered

        delivery_rate = self.delivery_rate

        open_rate = self.open_rate

        unique_rate = self.unique_rate

        ctr = self.ctr

        remove_rate = self.remove_rate

        bounce_rate = self.bounce_rate

        soft_bounce_rate = self.soft_bounce_rate

        complaint_rate = self.complaint_rate

        publication: dict[str, Any] | Unset = UNSET
        if not isinstance(self.publication, Unset):
            publication = self.publication.to_dict()

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if campaign_id is not UNSET:
            field_dict["CampaignID"] = campaign_id
        if name is not UNSET:
            field_dict["Name"] = name
        if status is not UNSET:
            field_dict["Status"] = status
        if is_active is not UNSET:
            field_dict["IsActive"] = is_active
        if created is not UNSET:
            field_dict["Created"] = created
        if schedule_date is not UNSET:
            field_dict["ScheduleDate"] = schedule_date
        if from_name is not UNSET:
            field_dict["FromName"] = from_name
        if from_email is not UNSET:
            field_dict["FromEmail"] = from_email
        if to_name is not UNSET:
            field_dict["ToName"] = to_name
        if subject is not UNSET:
            field_dict["Subject"] = subject
        if archive_url is not UNSET:
            field_dict["ArchiveURL"] = archive_url
        if emails_sent is not UNSET:
            field_dict["EmailsSent"] = emails_sent
        if opens is not UNSET:
            field_dict["Opens"] = opens
        if unique_clicks is not UNSET:
            field_dict["UniqueClicks"] = unique_clicks
        if total_clicks is not UNSET:
            field_dict["TotalClicks"] = total_clicks
        if removes is not UNSET:
            field_dict["Removes"] = removes
        if forwards is not UNSET:
            field_dict["Forwards"] = forwards
        if forwards_from is not UNSET:
            field_dict["ForwardsFrom"] = forwards_from
        if hard_bounces is not UNSET:
            field_dict["HardBounces"] = hard_bounces
        if soft_bounces is not UNSET:
            field_dict["SoftBounces"] = soft_bounces
        if complaints is not UNSET:
            field_dict["Complaints"] = complaints
        if delivered is not UNSET:
            field_dict["Delivered"] = delivered
        if delivery_rate is not UNSET:
            field_dict["DeliveryRate"] = delivery_rate
        if open_rate is not UNSET:
            field_dict["OpenRate"] = open_rate
        if unique_rate is not UNSET:
            field_dict["UniqueRate"] = unique_rate
        if ctr is not UNSET:
            field_dict["CTR"] = ctr
        if remove_rate is not UNSET:
            field_dict["RemoveRate"] = remove_rate
        if bounce_rate is not UNSET:
            field_dict["BounceRate"] = bounce_rate
        if soft_bounce_rate is not UNSET:
            field_dict["SoftBounceRate"] = soft_bounce_rate
        if complaint_rate is not UNSET:
            field_dict["ComplaintRate"] = complaint_rate
        if publication is not UNSET:
            field_dict["Publication"] = publication
        if links is not UNSET:
            field_dict["Links"] = links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.campaign_schedule_response_201_links_item import CampaignScheduleResponse201LinksItem
        from ..models.campaign_schedule_response_201_publication import CampaignScheduleResponse201Publication

        d = dict(src_dict)
        campaign_id = d.pop("CampaignID", UNSET)

        name = d.pop("Name", UNSET)

        status = d.pop("Status", UNSET)

        is_active = d.pop("IsActive", UNSET)

        created = d.pop("Created", UNSET)

        schedule_date = d.pop("ScheduleDate", UNSET)

        from_name = d.pop("FromName", UNSET)

        from_email = d.pop("FromEmail", UNSET)

        to_name = d.pop("ToName", UNSET)

        subject = d.pop("Subject", UNSET)

        archive_url = d.pop("ArchiveURL", UNSET)

        emails_sent = d.pop("EmailsSent", UNSET)

        opens = d.pop("Opens", UNSET)

        unique_clicks = d.pop("UniqueClicks", UNSET)

        total_clicks = d.pop("TotalClicks", UNSET)

        removes = d.pop("Removes", UNSET)

        forwards = d.pop("Forwards", UNSET)

        forwards_from = d.pop("ForwardsFrom", UNSET)

        hard_bounces = d.pop("HardBounces", UNSET)

        soft_bounces = d.pop("SoftBounces", UNSET)

        complaints = d.pop("Complaints", UNSET)

        delivered = d.pop("Delivered", UNSET)

        delivery_rate = d.pop("DeliveryRate", UNSET)

        open_rate = d.pop("OpenRate", UNSET)

        unique_rate = d.pop("UniqueRate", UNSET)

        ctr = d.pop("CTR", UNSET)

        remove_rate = d.pop("RemoveRate", UNSET)

        bounce_rate = d.pop("BounceRate", UNSET)

        soft_bounce_rate = d.pop("SoftBounceRate", UNSET)

        complaint_rate = d.pop("ComplaintRate", UNSET)

        _publication = d.pop("Publication", UNSET)
        publication: CampaignScheduleResponse201Publication | Unset
        if isinstance(_publication, Unset):
            publication = UNSET
        else:
            publication = CampaignScheduleResponse201Publication.from_dict(_publication)

        _links = d.pop("Links", UNSET)
        links: list[CampaignScheduleResponse201LinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = CampaignScheduleResponse201LinksItem.from_dict(links_item_data)

                links.append(links_item)

        campaign_schedule_response_201 = cls(
            campaign_id=campaign_id,
            name=name,
            status=status,
            is_active=is_active,
            created=created,
            schedule_date=schedule_date,
            from_name=from_name,
            from_email=from_email,
            to_name=to_name,
            subject=subject,
            archive_url=archive_url,
            emails_sent=emails_sent,
            opens=opens,
            unique_clicks=unique_clicks,
            total_clicks=total_clicks,
            removes=removes,
            forwards=forwards,
            forwards_from=forwards_from,
            hard_bounces=hard_bounces,
            soft_bounces=soft_bounces,
            complaints=complaints,
            delivered=delivered,
            delivery_rate=delivery_rate,
            open_rate=open_rate,
            unique_rate=unique_rate,
            ctr=ctr,
            remove_rate=remove_rate,
            bounce_rate=bounce_rate,
            soft_bounce_rate=soft_bounce_rate,
            complaint_rate=complaint_rate,
            publication=publication,
            links=links,
        )

        campaign_schedule_response_201.additional_properties = d
        return campaign_schedule_response_201

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
