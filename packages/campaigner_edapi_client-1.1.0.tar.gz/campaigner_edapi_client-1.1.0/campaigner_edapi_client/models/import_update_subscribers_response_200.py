from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.import_update_subscribers_response_200_failures_item import (
        ImportUpdateSubscribersResponse200FailuresItem,
    )


T = TypeVar("T", bound="ImportUpdateSubscribersResponse200")


@_attrs_define
class ImportUpdateSubscribersResponse200:
    """
    Attributes:
        contacts_submitted (int | Unset):
        successes (int | Unset):
        failures (list[ImportUpdateSubscribersResponse200FailuresItem] | Unset):
    """

    contacts_submitted: int | Unset = UNSET
    successes: int | Unset = UNSET
    failures: list[ImportUpdateSubscribersResponse200FailuresItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        contacts_submitted = self.contacts_submitted

        successes = self.successes

        failures: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.failures, Unset):
            failures = []
            for failures_item_data in self.failures:
                failures_item = failures_item_data.to_dict()
                failures.append(failures_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if contacts_submitted is not UNSET:
            field_dict["ContactsSubmitted"] = contacts_submitted
        if successes is not UNSET:
            field_dict["Successes"] = successes
        if failures is not UNSET:
            field_dict["Failures"] = failures

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.import_update_subscribers_response_200_failures_item import (
            ImportUpdateSubscribersResponse200FailuresItem,
        )

        d = dict(src_dict)
        contacts_submitted = d.pop("ContactsSubmitted", UNSET)

        successes = d.pop("Successes", UNSET)

        _failures = d.pop("Failures", UNSET)
        failures: list[ImportUpdateSubscribersResponse200FailuresItem] | Unset = UNSET
        if _failures is not UNSET:
            failures = []
            for failures_item_data in _failures:
                failures_item = ImportUpdateSubscribersResponse200FailuresItem.from_dict(failures_item_data)

                failures.append(failures_item)

        import_update_subscribers_response_200 = cls(
            contacts_submitted=contacts_submitted,
            successes=successes,
            failures=failures,
        )

        import_update_subscribers_response_200.additional_properties = d
        return import_update_subscribers_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
