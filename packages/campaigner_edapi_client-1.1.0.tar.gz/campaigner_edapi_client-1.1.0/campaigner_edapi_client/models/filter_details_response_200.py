from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.filter_details_response_200_links_item import FilterDetailsResponse200LinksItem


T = TypeVar("T", bound="FilterDetailsResponse200")


@_attrs_define
class FilterDetailsResponse200:
    """
    Attributes:
        filter_id (int | Unset):
        created (str | Unset):
        name (str | Unset):
        description (str | Unset):
        active_members (int | Unset):
        last_updated (str | Unset):
        links (list[FilterDetailsResponse200LinksItem] | Unset):
    """

    filter_id: int | Unset = UNSET
    created: str | Unset = UNSET
    name: str | Unset = UNSET
    description: str | Unset = UNSET
    active_members: int | Unset = UNSET
    last_updated: str | Unset = UNSET
    links: list[FilterDetailsResponse200LinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        filter_id = self.filter_id

        created = self.created

        name = self.name

        description = self.description

        active_members = self.active_members

        last_updated = self.last_updated

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if filter_id is not UNSET:
            field_dict["FilterID"] = filter_id
        if created is not UNSET:
            field_dict["Created"] = created
        if name is not UNSET:
            field_dict["Name"] = name
        if description is not UNSET:
            field_dict["Description"] = description
        if active_members is not UNSET:
            field_dict["ActiveMembers"] = active_members
        if last_updated is not UNSET:
            field_dict["LastUpdated"] = last_updated
        if links is not UNSET:
            field_dict["Links"] = links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.filter_details_response_200_links_item import FilterDetailsResponse200LinksItem

        d = dict(src_dict)
        filter_id = d.pop("FilterID", UNSET)

        created = d.pop("Created", UNSET)

        name = d.pop("Name", UNSET)

        description = d.pop("Description", UNSET)

        active_members = d.pop("ActiveMembers", UNSET)

        last_updated = d.pop("LastUpdated", UNSET)

        _links = d.pop("Links", UNSET)
        links: list[FilterDetailsResponse200LinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = FilterDetailsResponse200LinksItem.from_dict(links_item_data)

                links.append(links_item)

        filter_details_response_200 = cls(
            filter_id=filter_id,
            created=created,
            name=name,
            description=description,
            active_members=active_members,
            last_updated=last_updated,
            links=links,
        )

        filter_details_response_200.additional_properties = d
        return filter_details_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
