from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="OrderItemUpdateJsonBody")


@_attrs_define
class OrderItemUpdateJsonBody:
    """
    Attributes:
        product_name (str | Unset):
        sku (str | Unset):
        quantity (int | Unset):
        unit_price (int | Unset):
        weight (int | Unset):
        status (str | Unset):
    """

    product_name: str | Unset = UNSET
    sku: str | Unset = UNSET
    quantity: int | Unset = UNSET
    unit_price: int | Unset = UNSET
    weight: int | Unset = UNSET
    status: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        product_name = self.product_name

        sku = self.sku

        quantity = self.quantity

        unit_price = self.unit_price

        weight = self.weight

        status = self.status

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if product_name is not UNSET:
            field_dict["ProductName"] = product_name
        if sku is not UNSET:
            field_dict["SKU"] = sku
        if quantity is not UNSET:
            field_dict["Quantity"] = quantity
        if unit_price is not UNSET:
            field_dict["UnitPrice"] = unit_price
        if weight is not UNSET:
            field_dict["Weight"] = weight
        if status is not UNSET:
            field_dict["Status"] = status

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        product_name = d.pop("ProductName", UNSET)

        sku = d.pop("SKU", UNSET)

        quantity = d.pop("Quantity", UNSET)

        unit_price = d.pop("UnitPrice", UNSET)

        weight = d.pop("Weight", UNSET)

        status = d.pop("Status", UNSET)

        order_item_update_json_body = cls(
            product_name=product_name,
            sku=sku,
            quantity=quantity,
            unit_price=unit_price,
            weight=weight,
            status=status,
        )

        order_item_update_json_body.additional_properties = d
        return order_item_update_json_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
