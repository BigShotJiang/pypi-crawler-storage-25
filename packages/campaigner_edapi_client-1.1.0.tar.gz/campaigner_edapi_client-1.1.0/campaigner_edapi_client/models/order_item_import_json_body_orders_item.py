from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.order_item_import_json_body_orders_item_items_item import OrderItemImportJsonBodyOrdersItemItemsItem


T = TypeVar("T", bound="OrderItemImportJsonBodyOrdersItem")


@_attrs_define
class OrderItemImportJsonBodyOrdersItem:
    """
    Attributes:
        email_address (str | Unset):
        purchase_date (str | Unset):
        items (list[OrderItemImportJsonBodyOrdersItemItemsItem] | Unset):
    """

    email_address: str | Unset = UNSET
    purchase_date: str | Unset = UNSET
    items: list[OrderItemImportJsonBodyOrdersItemItemsItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        email_address = self.email_address

        purchase_date = self.purchase_date

        items: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.items, Unset):
            items = []
            for items_item_data in self.items:
                items_item = items_item_data.to_dict()
                items.append(items_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if email_address is not UNSET:
            field_dict["EmailAddress"] = email_address
        if purchase_date is not UNSET:
            field_dict["PurchaseDate"] = purchase_date
        if items is not UNSET:
            field_dict["Items"] = items

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.order_item_import_json_body_orders_item_items_item import (
            OrderItemImportJsonBodyOrdersItemItemsItem,
        )

        d = dict(src_dict)
        email_address = d.pop("EmailAddress", UNSET)

        purchase_date = d.pop("PurchaseDate", UNSET)

        _items = d.pop("Items", UNSET)
        items: list[OrderItemImportJsonBodyOrdersItemItemsItem] | Unset = UNSET
        if _items is not UNSET:
            items = []
            for items_item_data in _items:
                items_item = OrderItemImportJsonBodyOrdersItemItemsItem.from_dict(items_item_data)

                items.append(items_item)

        order_item_import_json_body_orders_item = cls(
            email_address=email_address,
            purchase_date=purchase_date,
            items=items,
        )

        order_item_import_json_body_orders_item.additional_properties = d
        return order_item_import_json_body_orders_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
