from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.creative_delete_response_200_links_item import CreativeDeleteResponse200LinksItem


T = TypeVar("T", bound="CreativeDeleteResponse200")


@_attrs_define
class CreativeDeleteResponse200:
    """
    Attributes:
        creative_id (int | Unset):
        created (str | Unset):
        last_updated (str | Unset):
        creative_name (str | Unset):
        html (str | Unset):
        text (str | Unset):
        tracking_links (bool | Unset):
        is_active (bool | Unset):
        folder_id (int | Unset):
        default_values (list[Any] | Unset):
        links (list[CreativeDeleteResponse200LinksItem] | Unset):
    """

    creative_id: int | Unset = UNSET
    created: str | Unset = UNSET
    last_updated: str | Unset = UNSET
    creative_name: str | Unset = UNSET
    html: str | Unset = UNSET
    text: str | Unset = UNSET
    tracking_links: bool | Unset = UNSET
    is_active: bool | Unset = UNSET
    folder_id: int | Unset = UNSET
    default_values: list[Any] | Unset = UNSET
    links: list[CreativeDeleteResponse200LinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        creative_id = self.creative_id

        created = self.created

        last_updated = self.last_updated

        creative_name = self.creative_name

        html = self.html

        text = self.text

        tracking_links = self.tracking_links

        is_active = self.is_active

        folder_id = self.folder_id

        default_values: list[Any] | Unset = UNSET
        if not isinstance(self.default_values, Unset):
            default_values = self.default_values

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if creative_id is not UNSET:
            field_dict["CreativeID"] = creative_id
        if created is not UNSET:
            field_dict["Created"] = created
        if last_updated is not UNSET:
            field_dict["LastUpdated"] = last_updated
        if creative_name is not UNSET:
            field_dict["CreativeName"] = creative_name
        if html is not UNSET:
            field_dict["HTML"] = html
        if text is not UNSET:
            field_dict["Text"] = text
        if tracking_links is not UNSET:
            field_dict["TrackingLinks"] = tracking_links
        if is_active is not UNSET:
            field_dict["IsActive"] = is_active
        if folder_id is not UNSET:
            field_dict["FolderID"] = folder_id
        if default_values is not UNSET:
            field_dict["DefaultValues"] = default_values
        if links is not UNSET:
            field_dict["Links"] = links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.creative_delete_response_200_links_item import CreativeDeleteResponse200LinksItem

        d = dict(src_dict)
        creative_id = d.pop("CreativeID", UNSET)

        created = d.pop("Created", UNSET)

        last_updated = d.pop("LastUpdated", UNSET)

        creative_name = d.pop("CreativeName", UNSET)

        html = d.pop("HTML", UNSET)

        text = d.pop("Text", UNSET)

        tracking_links = d.pop("TrackingLinks", UNSET)

        is_active = d.pop("IsActive", UNSET)

        folder_id = d.pop("FolderID", UNSET)

        default_values = cast(list[Any], d.pop("DefaultValues", UNSET))

        _links = d.pop("Links", UNSET)
        links: list[CreativeDeleteResponse200LinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = CreativeDeleteResponse200LinksItem.from_dict(links_item_data)

                links.append(links_item)

        creative_delete_response_200 = cls(
            creative_id=creative_id,
            created=created,
            last_updated=last_updated,
            creative_name=creative_name,
            html=html,
            text=text,
            tracking_links=tracking_links,
            is_active=is_active,
            folder_id=folder_id,
            default_values=default_values,
            links=links,
        )

        creative_delete_response_200.additional_properties = d
        return creative_delete_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
