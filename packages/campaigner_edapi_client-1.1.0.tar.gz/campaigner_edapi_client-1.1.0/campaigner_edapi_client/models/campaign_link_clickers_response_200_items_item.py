from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.campaign_link_clickers_response_200_items_item_links_item import (
        CampaignLinkClickersResponse200ItemsItemLinksItem,
    )


T = TypeVar("T", bound="CampaignLinkClickersResponse200ItemsItem")


@_attrs_define
class CampaignLinkClickersResponse200ItemsItem:
    """
    Attributes:
        action_date (str | Unset):
        email_id (int | Unset):
        email_address (str | Unset):
        created (str | Unset):
        status (str | Unset):
        custom_fields (None | str | Unset):
        links (list[CampaignLinkClickersResponse200ItemsItemLinksItem] | Unset):
    """

    action_date: str | Unset = UNSET
    email_id: int | Unset = UNSET
    email_address: str | Unset = UNSET
    created: str | Unset = UNSET
    status: str | Unset = UNSET
    custom_fields: None | str | Unset = UNSET
    links: list[CampaignLinkClickersResponse200ItemsItemLinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        action_date = self.action_date

        email_id = self.email_id

        email_address = self.email_address

        created = self.created

        status = self.status

        custom_fields: None | str | Unset
        if isinstance(self.custom_fields, Unset):
            custom_fields = UNSET
        else:
            custom_fields = self.custom_fields

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if action_date is not UNSET:
            field_dict["ActionDate"] = action_date
        if email_id is not UNSET:
            field_dict["EmailID"] = email_id
        if email_address is not UNSET:
            field_dict["EmailAddress"] = email_address
        if created is not UNSET:
            field_dict["Created"] = created
        if status is not UNSET:
            field_dict["Status"] = status
        if custom_fields is not UNSET:
            field_dict["CustomFields"] = custom_fields
        if links is not UNSET:
            field_dict["Links"] = links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.campaign_link_clickers_response_200_items_item_links_item import (
            CampaignLinkClickersResponse200ItemsItemLinksItem,
        )

        d = dict(src_dict)
        action_date = d.pop("ActionDate", UNSET)

        email_id = d.pop("EmailID", UNSET)

        email_address = d.pop("EmailAddress", UNSET)

        created = d.pop("Created", UNSET)

        status = d.pop("Status", UNSET)

        def _parse_custom_fields(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        custom_fields = _parse_custom_fields(d.pop("CustomFields", UNSET))

        _links = d.pop("Links", UNSET)
        links: list[CampaignLinkClickersResponse200ItemsItemLinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = CampaignLinkClickersResponse200ItemsItemLinksItem.from_dict(links_item_data)

                links.append(links_item)

        campaign_link_clickers_response_200_items_item = cls(
            action_date=action_date,
            email_id=email_id,
            email_address=email_address,
            created=created,
            status=status,
            custom_fields=custom_fields,
            links=links,
        )

        campaign_link_clickers_response_200_items_item.additional_properties = d
        return campaign_link_clickers_response_200_items_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
