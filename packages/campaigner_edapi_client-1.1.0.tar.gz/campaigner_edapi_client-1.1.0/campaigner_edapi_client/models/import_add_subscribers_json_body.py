from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.import_add_subscribers_json_body_subscribers_item import ImportAddSubscribersJsonBodySubscribersItem


T = TypeVar("T", bound="ImportAddSubscribersJsonBody")


@_attrs_define
class ImportAddSubscribersJsonBody:
    """
    Attributes:
        subscribers (list[ImportAddSubscribersJsonBodySubscribersItem] | Unset):
    """

    subscribers: list[ImportAddSubscribersJsonBodySubscribersItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        subscribers: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.subscribers, Unset):
            subscribers = []
            for subscribers_item_data in self.subscribers:
                subscribers_item = subscribers_item_data.to_dict()
                subscribers.append(subscribers_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if subscribers is not UNSET:
            field_dict["Subscribers"] = subscribers

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.import_add_subscribers_json_body_subscribers_item import (
            ImportAddSubscribersJsonBodySubscribersItem,
        )

        d = dict(src_dict)
        _subscribers = d.pop("Subscribers", UNSET)
        subscribers: list[ImportAddSubscribersJsonBodySubscribersItem] | Unset = UNSET
        if _subscribers is not UNSET:
            subscribers = []
            for subscribers_item_data in _subscribers:
                subscribers_item = ImportAddSubscribersJsonBodySubscribersItem.from_dict(subscribers_item_data)

                subscribers.append(subscribers_item)

        import_add_subscribers_json_body = cls(
            subscribers=subscribers,
        )

        import_add_subscribers_json_body.additional_properties = d
        return import_add_subscribers_json_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
