from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="DatabaseAddJsonBody")


@_attrs_define
class DatabaseAddJsonBody:
    """
    Attributes:
        column_name (str | Unset):
        column_type (str | Unset):
    """

    column_name: str | Unset = UNSET
    column_type: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        column_name = self.column_name

        column_type = self.column_type

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if column_name is not UNSET:
            field_dict["ColumnName"] = column_name
        if column_type is not UNSET:
            field_dict["ColumnType"] = column_type

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        column_name = d.pop("ColumnName", UNSET)

        column_type = d.pop("ColumnType", UNSET)

        database_add_json_body = cls(
            column_name=column_name,
            column_type=column_type,
        )

        database_add_json_body.additional_properties = d
        return database_add_json_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
