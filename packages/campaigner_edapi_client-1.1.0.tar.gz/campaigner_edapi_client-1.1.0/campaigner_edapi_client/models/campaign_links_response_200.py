from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.campaign_links_response_200_tracked_links_item import CampaignLinksResponse200TrackedLinksItem


T = TypeVar("T", bound="CampaignLinksResponse200")


@_attrs_define
class CampaignLinksResponse200:
    """
    Attributes:
        tracked_links (list[CampaignLinksResponse200TrackedLinksItem] | Unset):
    """

    tracked_links: list[CampaignLinksResponse200TrackedLinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        tracked_links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.tracked_links, Unset):
            tracked_links = []
            for tracked_links_item_data in self.tracked_links:
                tracked_links_item = tracked_links_item_data.to_dict()
                tracked_links.append(tracked_links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if tracked_links is not UNSET:
            field_dict["TrackedLinks"] = tracked_links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.campaign_links_response_200_tracked_links_item import CampaignLinksResponse200TrackedLinksItem

        d = dict(src_dict)
        _tracked_links = d.pop("TrackedLinks", UNSET)
        tracked_links: list[CampaignLinksResponse200TrackedLinksItem] | Unset = UNSET
        if _tracked_links is not UNSET:
            tracked_links = []
            for tracked_links_item_data in _tracked_links:
                tracked_links_item = CampaignLinksResponse200TrackedLinksItem.from_dict(tracked_links_item_data)

                tracked_links.append(tracked_links_item)

        campaign_links_response_200 = cls(
            tracked_links=tracked_links,
        )

        campaign_links_response_200.additional_properties = d
        return campaign_links_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
