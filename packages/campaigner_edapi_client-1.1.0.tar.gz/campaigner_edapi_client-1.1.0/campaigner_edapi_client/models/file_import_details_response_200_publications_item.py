from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.file_import_details_response_200_publications_item_links_item import (
        FileImportDetailsResponse200PublicationsItemLinksItem,
    )


T = TypeVar("T", bound="FileImportDetailsResponse200PublicationsItem")


@_attrs_define
class FileImportDetailsResponse200PublicationsItem:
    """
    Attributes:
        publication_id (int | Unset):
        name (str | Unset):
        links (list[FileImportDetailsResponse200PublicationsItemLinksItem] | Unset):
    """

    publication_id: int | Unset = UNSET
    name: str | Unset = UNSET
    links: list[FileImportDetailsResponse200PublicationsItemLinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        publication_id = self.publication_id

        name = self.name

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if publication_id is not UNSET:
            field_dict["PublicationID"] = publication_id
        if name is not UNSET:
            field_dict["Name"] = name
        if links is not UNSET:
            field_dict["Links"] = links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.file_import_details_response_200_publications_item_links_item import (
            FileImportDetailsResponse200PublicationsItemLinksItem,
        )

        d = dict(src_dict)
        publication_id = d.pop("PublicationID", UNSET)

        name = d.pop("Name", UNSET)

        _links = d.pop("Links", UNSET)
        links: list[FileImportDetailsResponse200PublicationsItemLinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = FileImportDetailsResponse200PublicationsItemLinksItem.from_dict(links_item_data)

                links.append(links_item)

        file_import_details_response_200_publications_item = cls(
            publication_id=publication_id,
            name=name,
            links=links,
        )

        file_import_details_response_200_publications_item.additional_properties = d
        return file_import_details_response_200_publications_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
