from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.filter_list_response_200_filters_item import FilterListResponse200FiltersItem


T = TypeVar("T", bound="FilterListResponse200")


@_attrs_define
class FilterListResponse200:
    """
    Attributes:
        filters (list[FilterListResponse200FiltersItem] | Unset):
    """

    filters: list[FilterListResponse200FiltersItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        filters: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.filters, Unset):
            filters = []
            for filters_item_data in self.filters:
                filters_item = filters_item_data.to_dict()
                filters.append(filters_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if filters is not UNSET:
            field_dict["Filters"] = filters

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.filter_list_response_200_filters_item import FilterListResponse200FiltersItem

        d = dict(src_dict)
        _filters = d.pop("Filters", UNSET)
        filters: list[FilterListResponse200FiltersItem] | Unset = UNSET
        if _filters is not UNSET:
            filters = []
            for filters_item_data in _filters:
                filters_item = FilterListResponse200FiltersItem.from_dict(filters_item_data)

                filters.append(filters_item)

        filter_list_response_200 = cls(
            filters=filters,
        )

        filter_list_response_200.additional_properties = d
        return filter_list_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
