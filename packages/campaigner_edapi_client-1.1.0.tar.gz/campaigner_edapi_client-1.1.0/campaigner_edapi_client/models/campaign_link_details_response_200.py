from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.campaign_link_details_response_200_links_item import CampaignLinkDetailsResponse200LinksItem


T = TypeVar("T", bound="CampaignLinkDetailsResponse200")


@_attrs_define
class CampaignLinkDetailsResponse200:
    """
    Attributes:
        link_id (int | Unset):
        url (str | Unset):
        friendly_name (str | Unset):
        total_clicks (int | Unset):
        unique_clicks (int | Unset):
        links (list[CampaignLinkDetailsResponse200LinksItem] | Unset):
    """

    link_id: int | Unset = UNSET
    url: str | Unset = UNSET
    friendly_name: str | Unset = UNSET
    total_clicks: int | Unset = UNSET
    unique_clicks: int | Unset = UNSET
    links: list[CampaignLinkDetailsResponse200LinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        link_id = self.link_id

        url = self.url

        friendly_name = self.friendly_name

        total_clicks = self.total_clicks

        unique_clicks = self.unique_clicks

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if link_id is not UNSET:
            field_dict["LinkID"] = link_id
        if url is not UNSET:
            field_dict["URL"] = url
        if friendly_name is not UNSET:
            field_dict["FriendlyName"] = friendly_name
        if total_clicks is not UNSET:
            field_dict["TotalClicks"] = total_clicks
        if unique_clicks is not UNSET:
            field_dict["UniqueClicks"] = unique_clicks
        if links is not UNSET:
            field_dict["Links"] = links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.campaign_link_details_response_200_links_item import CampaignLinkDetailsResponse200LinksItem

        d = dict(src_dict)
        link_id = d.pop("LinkID", UNSET)

        url = d.pop("URL", UNSET)

        friendly_name = d.pop("FriendlyName", UNSET)

        total_clicks = d.pop("TotalClicks", UNSET)

        unique_clicks = d.pop("UniqueClicks", UNSET)

        _links = d.pop("Links", UNSET)
        links: list[CampaignLinkDetailsResponse200LinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = CampaignLinkDetailsResponse200LinksItem.from_dict(links_item_data)

                links.append(links_item)

        campaign_link_details_response_200 = cls(
            link_id=link_id,
            url=url,
            friendly_name=friendly_name,
            total_clicks=total_clicks,
            unique_clicks=unique_clicks,
            links=links,
        )

        campaign_link_details_response_200.additional_properties = d
        return campaign_link_details_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
