from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.file_import_products_json_body_field_mappings_item import FileImportProductsJsonBodyFieldMappingsItem


T = TypeVar("T", bound="FileImportProductsJsonBody")


@_attrs_define
class FileImportProductsJsonBody:
    """
    Attributes:
        local_ftp_file_path (str | Unset):
        field_mappings (list[FileImportProductsJsonBodyFieldMappingsItem] | Unset):
    """

    local_ftp_file_path: str | Unset = UNSET
    field_mappings: list[FileImportProductsJsonBodyFieldMappingsItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        local_ftp_file_path = self.local_ftp_file_path

        field_mappings: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.field_mappings, Unset):
            field_mappings = []
            for field_mappings_item_data in self.field_mappings:
                field_mappings_item = field_mappings_item_data.to_dict()
                field_mappings.append(field_mappings_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if local_ftp_file_path is not UNSET:
            field_dict["LocalFTPFilePath"] = local_ftp_file_path
        if field_mappings is not UNSET:
            field_dict["FieldMappings"] = field_mappings

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.file_import_products_json_body_field_mappings_item import (
            FileImportProductsJsonBodyFieldMappingsItem,
        )

        d = dict(src_dict)
        local_ftp_file_path = d.pop("LocalFTPFilePath", UNSET)

        _field_mappings = d.pop("FieldMappings", UNSET)
        field_mappings: list[FileImportProductsJsonBodyFieldMappingsItem] | Unset = UNSET
        if _field_mappings is not UNSET:
            field_mappings = []
            for field_mappings_item_data in _field_mappings:
                field_mappings_item = FileImportProductsJsonBodyFieldMappingsItem.from_dict(field_mappings_item_data)

                field_mappings.append(field_mappings_item)

        file_import_products_json_body = cls(
            local_ftp_file_path=local_ftp_file_path,
            field_mappings=field_mappings,
        )

        file_import_products_json_body.additional_properties = d
        return file_import_products_json_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
