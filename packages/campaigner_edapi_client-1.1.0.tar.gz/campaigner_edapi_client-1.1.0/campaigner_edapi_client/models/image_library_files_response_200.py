from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.image_library_files_response_200_image_files_item import ImageLibraryFilesResponse200ImageFilesItem


T = TypeVar("T", bound="ImageLibraryFilesResponse200")


@_attrs_define
class ImageLibraryFilesResponse200:
    """
    Attributes:
        image_files (list[ImageLibraryFilesResponse200ImageFilesItem] | Unset):
    """

    image_files: list[ImageLibraryFilesResponse200ImageFilesItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        image_files: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.image_files, Unset):
            image_files = []
            for image_files_item_data in self.image_files:
                image_files_item = image_files_item_data.to_dict()
                image_files.append(image_files_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if image_files is not UNSET:
            field_dict["ImageFiles"] = image_files

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.image_library_files_response_200_image_files_item import (
            ImageLibraryFilesResponse200ImageFilesItem,
        )

        d = dict(src_dict)
        _image_files = d.pop("ImageFiles", UNSET)
        image_files: list[ImageLibraryFilesResponse200ImageFilesItem] | Unset = UNSET
        if _image_files is not UNSET:
            image_files = []
            for image_files_item_data in _image_files:
                image_files_item = ImageLibraryFilesResponse200ImageFilesItem.from_dict(image_files_item_data)

                image_files.append(image_files_item)

        image_library_files_response_200 = cls(
            image_files=image_files,
        )

        image_library_files_response_200.additional_properties = d
        return image_library_files_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
