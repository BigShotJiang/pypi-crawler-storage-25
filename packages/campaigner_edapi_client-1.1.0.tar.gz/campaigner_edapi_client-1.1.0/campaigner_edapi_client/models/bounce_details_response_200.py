from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.bounce_details_response_200_links_item import BounceDetailsResponse200LinksItem


T = TypeVar("T", bound="BounceDetailsResponse200")


@_attrs_define
class BounceDetailsResponse200:
    """
    Attributes:
        email_id (int | Unset):
        email_address (str | Unset):
        status (str | Unset):
        send_type (str | Unset):
        bounce_id (int | Unset):
        bounced_at (str | Unset):
        ndr_code (int | Unset):
        bounce_type (str | Unset):
        reason (str | Unset):
        links (list[BounceDetailsResponse200LinksItem] | Unset):
    """

    email_id: int | Unset = UNSET
    email_address: str | Unset = UNSET
    status: str | Unset = UNSET
    send_type: str | Unset = UNSET
    bounce_id: int | Unset = UNSET
    bounced_at: str | Unset = UNSET
    ndr_code: int | Unset = UNSET
    bounce_type: str | Unset = UNSET
    reason: str | Unset = UNSET
    links: list[BounceDetailsResponse200LinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        email_id = self.email_id

        email_address = self.email_address

        status = self.status

        send_type = self.send_type

        bounce_id = self.bounce_id

        bounced_at = self.bounced_at

        ndr_code = self.ndr_code

        bounce_type = self.bounce_type

        reason = self.reason

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if email_id is not UNSET:
            field_dict["EmailID"] = email_id
        if email_address is not UNSET:
            field_dict["EmailAddress"] = email_address
        if status is not UNSET:
            field_dict["Status"] = status
        if send_type is not UNSET:
            field_dict["SendType"] = send_type
        if bounce_id is not UNSET:
            field_dict["BounceID"] = bounce_id
        if bounced_at is not UNSET:
            field_dict["BouncedAt"] = bounced_at
        if ndr_code is not UNSET:
            field_dict["NDRCode"] = ndr_code
        if bounce_type is not UNSET:
            field_dict["BounceType"] = bounce_type
        if reason is not UNSET:
            field_dict["Reason"] = reason
        if links is not UNSET:
            field_dict["Links"] = links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.bounce_details_response_200_links_item import BounceDetailsResponse200LinksItem

        d = dict(src_dict)
        email_id = d.pop("EmailID", UNSET)

        email_address = d.pop("EmailAddress", UNSET)

        status = d.pop("Status", UNSET)

        send_type = d.pop("SendType", UNSET)

        bounce_id = d.pop("BounceID", UNSET)

        bounced_at = d.pop("BouncedAt", UNSET)

        ndr_code = d.pop("NDRCode", UNSET)

        bounce_type = d.pop("BounceType", UNSET)

        reason = d.pop("Reason", UNSET)

        _links = d.pop("Links", UNSET)
        links: list[BounceDetailsResponse200LinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = BounceDetailsResponse200LinksItem.from_dict(links_item_data)

                links.append(links_item)

        bounce_details_response_200 = cls(
            email_id=email_id,
            email_address=email_address,
            status=status,
            send_type=send_type,
            bounce_id=bounce_id,
            bounced_at=bounced_at,
            ndr_code=ndr_code,
            bounce_type=bounce_type,
            reason=reason,
            links=links,
        )

        bounce_details_response_200.additional_properties = d
        return bounce_details_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
