from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.ftp_folders_add_response_201_links_item import FTPFoldersAddResponse201LinksItem


T = TypeVar("T", bound="FTPFoldersAddResponse201")


@_attrs_define
class FTPFoldersAddResponse201:
    """
    Attributes:
        folder_name (str | Unset):
        folder_path (str | Unset):
        file_count (int | Unset):
        folders (list[Any] | Unset):
        uri (str | Unset):
        links (list[FTPFoldersAddResponse201LinksItem] | Unset):
    """

    folder_name: str | Unset = UNSET
    folder_path: str | Unset = UNSET
    file_count: int | Unset = UNSET
    folders: list[Any] | Unset = UNSET
    uri: str | Unset = UNSET
    links: list[FTPFoldersAddResponse201LinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        folder_name = self.folder_name

        folder_path = self.folder_path

        file_count = self.file_count

        folders: list[Any] | Unset = UNSET
        if not isinstance(self.folders, Unset):
            folders = self.folders

        uri = self.uri

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if folder_name is not UNSET:
            field_dict["FolderName"] = folder_name
        if folder_path is not UNSET:
            field_dict["FolderPath"] = folder_path
        if file_count is not UNSET:
            field_dict["FileCount"] = file_count
        if folders is not UNSET:
            field_dict["Folders"] = folders
        if uri is not UNSET:
            field_dict["Uri"] = uri
        if links is not UNSET:
            field_dict["Links"] = links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.ftp_folders_add_response_201_links_item import FTPFoldersAddResponse201LinksItem

        d = dict(src_dict)
        folder_name = d.pop("FolderName", UNSET)

        folder_path = d.pop("FolderPath", UNSET)

        file_count = d.pop("FileCount", UNSET)

        folders = cast(list[Any], d.pop("Folders", UNSET))

        uri = d.pop("Uri", UNSET)

        _links = d.pop("Links", UNSET)
        links: list[FTPFoldersAddResponse201LinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = FTPFoldersAddResponse201LinksItem.from_dict(links_item_data)

                links.append(links_item)

        ftp_folders_add_response_201 = cls(
            folder_name=folder_name,
            folder_path=folder_path,
            file_count=file_count,
            folders=folders,
            uri=uri,
            links=links,
        )

        ftp_folders_add_response_201.additional_properties = d
        return ftp_folders_add_response_201

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
