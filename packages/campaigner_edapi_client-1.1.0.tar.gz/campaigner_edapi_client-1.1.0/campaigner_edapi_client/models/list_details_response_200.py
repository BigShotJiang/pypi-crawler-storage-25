from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.list_details_response_200_links_item import ListDetailsResponse200LinksItem


T = TypeVar("T", bound="ListDetailsResponse200")


@_attrs_define
class ListDetailsResponse200:
    """
    Attributes:
        list_id (int | Unset):
        name (str | Unset):
        description (str | Unset):
        active_members (int | Unset):
        is_active (bool | Unset):
        links (list[ListDetailsResponse200LinksItem] | Unset):
    """

    list_id: int | Unset = UNSET
    name: str | Unset = UNSET
    description: str | Unset = UNSET
    active_members: int | Unset = UNSET
    is_active: bool | Unset = UNSET
    links: list[ListDetailsResponse200LinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        list_id = self.list_id

        name = self.name

        description = self.description

        active_members = self.active_members

        is_active = self.is_active

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if list_id is not UNSET:
            field_dict["ListID"] = list_id
        if name is not UNSET:
            field_dict["Name"] = name
        if description is not UNSET:
            field_dict["Description"] = description
        if active_members is not UNSET:
            field_dict["ActiveMembers"] = active_members
        if is_active is not UNSET:
            field_dict["IsActive"] = is_active
        if links is not UNSET:
            field_dict["Links"] = links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.list_details_response_200_links_item import ListDetailsResponse200LinksItem

        d = dict(src_dict)
        list_id = d.pop("ListID", UNSET)

        name = d.pop("Name", UNSET)

        description = d.pop("Description", UNSET)

        active_members = d.pop("ActiveMembers", UNSET)

        is_active = d.pop("IsActive", UNSET)

        _links = d.pop("Links", UNSET)
        links: list[ListDetailsResponse200LinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = ListDetailsResponse200LinksItem.from_dict(links_item_data)

                links.append(links_item)

        list_details_response_200 = cls(
            list_id=list_id,
            name=name,
            description=description,
            active_members=active_members,
            is_active=is_active,
            links=links,
        )

        list_details_response_200.additional_properties = d
        return list_details_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
