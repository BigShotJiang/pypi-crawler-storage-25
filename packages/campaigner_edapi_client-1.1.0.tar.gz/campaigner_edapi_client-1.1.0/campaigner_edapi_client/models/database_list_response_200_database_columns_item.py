from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.database_list_response_200_database_columns_item_links_item import (
        DatabaseListResponse200DatabaseColumnsItemLinksItem,
    )


T = TypeVar("T", bound="DatabaseListResponse200DatabaseColumnsItem")


@_attrs_define
class DatabaseListResponse200DatabaseColumnsItem:
    """
    Attributes:
        column_name (str | Unset):
        column_type (str | Unset):
        column_size (int | Unset):
        is_custom (bool | Unset):
        variable (str | Unset):
        links (list[DatabaseListResponse200DatabaseColumnsItemLinksItem] | Unset):
    """

    column_name: str | Unset = UNSET
    column_type: str | Unset = UNSET
    column_size: int | Unset = UNSET
    is_custom: bool | Unset = UNSET
    variable: str | Unset = UNSET
    links: list[DatabaseListResponse200DatabaseColumnsItemLinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        column_name = self.column_name

        column_type = self.column_type

        column_size = self.column_size

        is_custom = self.is_custom

        variable = self.variable

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if column_name is not UNSET:
            field_dict["ColumnName"] = column_name
        if column_type is not UNSET:
            field_dict["ColumnType"] = column_type
        if column_size is not UNSET:
            field_dict["ColumnSize"] = column_size
        if is_custom is not UNSET:
            field_dict["IsCustom"] = is_custom
        if variable is not UNSET:
            field_dict["Variable"] = variable
        if links is not UNSET:
            field_dict["Links"] = links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.database_list_response_200_database_columns_item_links_item import (
            DatabaseListResponse200DatabaseColumnsItemLinksItem,
        )

        d = dict(src_dict)
        column_name = d.pop("ColumnName", UNSET)

        column_type = d.pop("ColumnType", UNSET)

        column_size = d.pop("ColumnSize", UNSET)

        is_custom = d.pop("IsCustom", UNSET)

        variable = d.pop("Variable", UNSET)

        _links = d.pop("Links", UNSET)
        links: list[DatabaseListResponse200DatabaseColumnsItemLinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = DatabaseListResponse200DatabaseColumnsItemLinksItem.from_dict(links_item_data)

                links.append(links_item)

        database_list_response_200_database_columns_item = cls(
            column_name=column_name,
            column_type=column_type,
            column_size=column_size,
            is_custom=is_custom,
            variable=variable,
            links=links,
        )

        database_list_response_200_database_columns_item.additional_properties = d
        return database_list_response_200_database_columns_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
