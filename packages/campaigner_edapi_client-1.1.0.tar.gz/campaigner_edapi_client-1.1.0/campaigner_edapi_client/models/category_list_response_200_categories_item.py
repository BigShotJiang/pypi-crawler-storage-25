from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.category_list_response_200_categories_item_categories_item import (
        CategoryListResponse200CategoriesItemCategoriesItem,
    )
    from ..models.category_list_response_200_categories_item_links_item import (
        CategoryListResponse200CategoriesItemLinksItem,
    )


T = TypeVar("T", bound="CategoryListResponse200CategoriesItem")


@_attrs_define
class CategoryListResponse200CategoriesItem:
    """
    Attributes:
        category_id (int | Unset):
        name (str | Unset):
        product_count (int | Unset):
        description (str | Unset):
        image (str | Unset):
        url (str | Unset):
        created (str | Unset):
        last_updated (str | Unset):
        categories (list[CategoryListResponse200CategoriesItemCategoriesItem] | Unset):
        links (list[CategoryListResponse200CategoriesItemLinksItem] | Unset):
    """

    category_id: int | Unset = UNSET
    name: str | Unset = UNSET
    product_count: int | Unset = UNSET
    description: str | Unset = UNSET
    image: str | Unset = UNSET
    url: str | Unset = UNSET
    created: str | Unset = UNSET
    last_updated: str | Unset = UNSET
    categories: list[CategoryListResponse200CategoriesItemCategoriesItem] | Unset = UNSET
    links: list[CategoryListResponse200CategoriesItemLinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        category_id = self.category_id

        name = self.name

        product_count = self.product_count

        description = self.description

        image = self.image

        url = self.url

        created = self.created

        last_updated = self.last_updated

        categories: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.categories, Unset):
            categories = []
            for categories_item_data in self.categories:
                categories_item = categories_item_data.to_dict()
                categories.append(categories_item)

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if category_id is not UNSET:
            field_dict["CategoryID"] = category_id
        if name is not UNSET:
            field_dict["Name"] = name
        if product_count is not UNSET:
            field_dict["ProductCount"] = product_count
        if description is not UNSET:
            field_dict["Description"] = description
        if image is not UNSET:
            field_dict["Image"] = image
        if url is not UNSET:
            field_dict["URL"] = url
        if created is not UNSET:
            field_dict["Created"] = created
        if last_updated is not UNSET:
            field_dict["LastUpdated"] = last_updated
        if categories is not UNSET:
            field_dict["Categories"] = categories
        if links is not UNSET:
            field_dict["Links"] = links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.category_list_response_200_categories_item_categories_item import (
            CategoryListResponse200CategoriesItemCategoriesItem,
        )
        from ..models.category_list_response_200_categories_item_links_item import (
            CategoryListResponse200CategoriesItemLinksItem,
        )

        d = dict(src_dict)
        category_id = d.pop("CategoryID", UNSET)

        name = d.pop("Name", UNSET)

        product_count = d.pop("ProductCount", UNSET)

        description = d.pop("Description", UNSET)

        image = d.pop("Image", UNSET)

        url = d.pop("URL", UNSET)

        created = d.pop("Created", UNSET)

        last_updated = d.pop("LastUpdated", UNSET)

        _categories = d.pop("Categories", UNSET)
        categories: list[CategoryListResponse200CategoriesItemCategoriesItem] | Unset = UNSET
        if _categories is not UNSET:
            categories = []
            for categories_item_data in _categories:
                categories_item = CategoryListResponse200CategoriesItemCategoriesItem.from_dict(categories_item_data)

                categories.append(categories_item)

        _links = d.pop("Links", UNSET)
        links: list[CategoryListResponse200CategoriesItemLinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = CategoryListResponse200CategoriesItemLinksItem.from_dict(links_item_data)

                links.append(links_item)

        category_list_response_200_categories_item = cls(
            category_id=category_id,
            name=name,
            product_count=product_count,
            description=description,
            image=image,
            url=url,
            created=created,
            last_updated=last_updated,
            categories=categories,
            links=links,
        )

        category_list_response_200_categories_item.additional_properties = d
        return category_list_response_200_categories_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
