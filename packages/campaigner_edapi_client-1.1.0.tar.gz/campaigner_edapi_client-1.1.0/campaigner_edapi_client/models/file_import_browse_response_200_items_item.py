from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.file_import_browse_response_200_items_item_links_item import (
        FileImportBrowseResponse200ItemsItemLinksItem,
    )


T = TypeVar("T", bound="FileImportBrowseResponse200ItemsItem")


@_attrs_define
class FileImportBrowseResponse200ItemsItem:
    """
    Attributes:
        file_import_id (int | Unset):
        name (str | Unset):
        created (str | Unset):
        records (int | Unset):
        import_type (str | Unset):
        status (str | Unset):
        links (list[FileImportBrowseResponse200ItemsItemLinksItem] | Unset):
    """

    file_import_id: int | Unset = UNSET
    name: str | Unset = UNSET
    created: str | Unset = UNSET
    records: int | Unset = UNSET
    import_type: str | Unset = UNSET
    status: str | Unset = UNSET
    links: list[FileImportBrowseResponse200ItemsItemLinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        file_import_id = self.file_import_id

        name = self.name

        created = self.created

        records = self.records

        import_type = self.import_type

        status = self.status

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if file_import_id is not UNSET:
            field_dict["FileImportID"] = file_import_id
        if name is not UNSET:
            field_dict["Name"] = name
        if created is not UNSET:
            field_dict["Created"] = created
        if records is not UNSET:
            field_dict["Records"] = records
        if import_type is not UNSET:
            field_dict["ImportType"] = import_type
        if status is not UNSET:
            field_dict["Status"] = status
        if links is not UNSET:
            field_dict["Links"] = links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.file_import_browse_response_200_items_item_links_item import (
            FileImportBrowseResponse200ItemsItemLinksItem,
        )

        d = dict(src_dict)
        file_import_id = d.pop("FileImportID", UNSET)

        name = d.pop("Name", UNSET)

        created = d.pop("Created", UNSET)

        records = d.pop("Records", UNSET)

        import_type = d.pop("ImportType", UNSET)

        status = d.pop("Status", UNSET)

        _links = d.pop("Links", UNSET)
        links: list[FileImportBrowseResponse200ItemsItemLinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = FileImportBrowseResponse200ItemsItemLinksItem.from_dict(links_item_data)

                links.append(links_item)

        file_import_browse_response_200_items_item = cls(
            file_import_id=file_import_id,
            name=name,
            created=created,
            records=records,
            import_type=import_type,
            status=status,
            links=links,
        )

        file_import_browse_response_200_items_item.additional_properties = d
        return file_import_browse_response_200_items_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
