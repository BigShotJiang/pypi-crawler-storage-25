from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.file_import_details_response_200_auto_responder_links_item import (
        FileImportDetailsResponse200AutoResponderLinksItem,
    )


T = TypeVar("T", bound="FileImportDetailsResponse200AutoResponder")


@_attrs_define
class FileImportDetailsResponse200AutoResponder:
    """
    Attributes:
        auto_responder_id (int | Unset):
        name (str | Unset):
        links (list[FileImportDetailsResponse200AutoResponderLinksItem] | Unset):
        responder_type (str | Unset):
    """

    auto_responder_id: int | Unset = UNSET
    name: str | Unset = UNSET
    links: list[FileImportDetailsResponse200AutoResponderLinksItem] | Unset = UNSET
    responder_type: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        auto_responder_id = self.auto_responder_id

        name = self.name

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        responder_type = self.responder_type

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if auto_responder_id is not UNSET:
            field_dict["AutoResponderID"] = auto_responder_id
        if name is not UNSET:
            field_dict["Name"] = name
        if links is not UNSET:
            field_dict["Links"] = links
        if responder_type is not UNSET:
            field_dict["ResponderType"] = responder_type

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.file_import_details_response_200_auto_responder_links_item import (
            FileImportDetailsResponse200AutoResponderLinksItem,
        )

        d = dict(src_dict)
        auto_responder_id = d.pop("AutoResponderID", UNSET)

        name = d.pop("Name", UNSET)

        _links = d.pop("Links", UNSET)
        links: list[FileImportDetailsResponse200AutoResponderLinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = FileImportDetailsResponse200AutoResponderLinksItem.from_dict(links_item_data)

                links.append(links_item)

        responder_type = d.pop("ResponderType", UNSET)

        file_import_details_response_200_auto_responder = cls(
            auto_responder_id=auto_responder_id,
            name=name,
            links=links,
            responder_type=responder_type,
        )

        file_import_details_response_200_auto_responder.additional_properties = d
        return file_import_details_response_200_auto_responder

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
