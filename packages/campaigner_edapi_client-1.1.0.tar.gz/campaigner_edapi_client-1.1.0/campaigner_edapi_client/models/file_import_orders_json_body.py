from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="FileImportOrdersJsonBody")


@_attrs_define
class FileImportOrdersJsonBody:
    """
    Attributes:
        local_ftp_file_path (str | Unset):
    """

    local_ftp_file_path: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        local_ftp_file_path = self.local_ftp_file_path

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if local_ftp_file_path is not UNSET:
            field_dict["LocalFTPFilePath"] = local_ftp_file_path

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        local_ftp_file_path = d.pop("LocalFTPFilePath", UNSET)

        file_import_orders_json_body = cls(
            local_ftp_file_path=local_ftp_file_path,
        )

        file_import_orders_json_body.additional_properties = d
        return file_import_orders_json_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
