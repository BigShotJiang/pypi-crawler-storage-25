from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="OrderItemImportResponse400FailuresItem")


@_attrs_define
class OrderItemImportResponse400FailuresItem:
    """
    Attributes:
        email_address (str | Unset):
        order_number (str | Unset):
        error_code (int | Unset):
        message (str | Unset):
    """

    email_address: str | Unset = UNSET
    order_number: str | Unset = UNSET
    error_code: int | Unset = UNSET
    message: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        email_address = self.email_address

        order_number = self.order_number

        error_code = self.error_code

        message = self.message

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if email_address is not UNSET:
            field_dict["EmailAddress"] = email_address
        if order_number is not UNSET:
            field_dict["OrderNumber"] = order_number
        if error_code is not UNSET:
            field_dict["ErrorCode"] = error_code
        if message is not UNSET:
            field_dict["Message"] = message

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        email_address = d.pop("EmailAddress", UNSET)

        order_number = d.pop("OrderNumber", UNSET)

        error_code = d.pop("ErrorCode", UNSET)

        message = d.pop("Message", UNSET)

        order_item_import_response_400_failures_item = cls(
            email_address=email_address,
            order_number=order_number,
            error_code=error_code,
            message=message,
        )

        order_item_import_response_400_failures_item.additional_properties = d
        return order_item_import_response_400_failures_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
