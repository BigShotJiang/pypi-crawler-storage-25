from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.file_import_details_response_200_auto_responder import FileImportDetailsResponse200AutoResponder
    from ..models.file_import_details_response_200_field_mappings_item import (
        FileImportDetailsResponse200FieldMappingsItem,
    )
    from ..models.file_import_details_response_200_links_item import FileImportDetailsResponse200LinksItem
    from ..models.file_import_details_response_200_lists_item import FileImportDetailsResponse200ListsItem
    from ..models.file_import_details_response_200_publications_item import FileImportDetailsResponse200PublicationsItem
    from ..models.file_import_details_response_200_results import FileImportDetailsResponse200Results
    from ..models.file_import_details_response_200_source import FileImportDetailsResponse200Source


T = TypeVar("T", bound="FileImportDetailsResponse200")


@_attrs_define
class FileImportDetailsResponse200:
    """
    Attributes:
        file_import_id (int | Unset):
        name (str | Unset):
        created (str | Unset):
        records (int | Unset):
        import_type (str | Unset):
        status (str | Unset):
        source (FileImportDetailsResponse200Source | Unset):
        publications (list[FileImportDetailsResponse200PublicationsItem] | Unset):
        lists (list[FileImportDetailsResponse200ListsItem] | Unset):
        auto_responder (FileImportDetailsResponse200AutoResponder | Unset):
        field_mappings (list[FileImportDetailsResponse200FieldMappingsItem] | Unset):
        results (FileImportDetailsResponse200Results | Unset):
        links (list[FileImportDetailsResponse200LinksItem] | Unset):
    """

    file_import_id: int | Unset = UNSET
    name: str | Unset = UNSET
    created: str | Unset = UNSET
    records: int | Unset = UNSET
    import_type: str | Unset = UNSET
    status: str | Unset = UNSET
    source: FileImportDetailsResponse200Source | Unset = UNSET
    publications: list[FileImportDetailsResponse200PublicationsItem] | Unset = UNSET
    lists: list[FileImportDetailsResponse200ListsItem] | Unset = UNSET
    auto_responder: FileImportDetailsResponse200AutoResponder | Unset = UNSET
    field_mappings: list[FileImportDetailsResponse200FieldMappingsItem] | Unset = UNSET
    results: FileImportDetailsResponse200Results | Unset = UNSET
    links: list[FileImportDetailsResponse200LinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        file_import_id = self.file_import_id

        name = self.name

        created = self.created

        records = self.records

        import_type = self.import_type

        status = self.status

        source: dict[str, Any] | Unset = UNSET
        if not isinstance(self.source, Unset):
            source = self.source.to_dict()

        publications: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.publications, Unset):
            publications = []
            for publications_item_data in self.publications:
                publications_item = publications_item_data.to_dict()
                publications.append(publications_item)

        lists: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.lists, Unset):
            lists = []
            for lists_item_data in self.lists:
                lists_item = lists_item_data.to_dict()
                lists.append(lists_item)

        auto_responder: dict[str, Any] | Unset = UNSET
        if not isinstance(self.auto_responder, Unset):
            auto_responder = self.auto_responder.to_dict()

        field_mappings: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.field_mappings, Unset):
            field_mappings = []
            for field_mappings_item_data in self.field_mappings:
                field_mappings_item = field_mappings_item_data.to_dict()
                field_mappings.append(field_mappings_item)

        results: dict[str, Any] | Unset = UNSET
        if not isinstance(self.results, Unset):
            results = self.results.to_dict()

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if file_import_id is not UNSET:
            field_dict["FileImportID"] = file_import_id
        if name is not UNSET:
            field_dict["Name"] = name
        if created is not UNSET:
            field_dict["Created"] = created
        if records is not UNSET:
            field_dict["Records"] = records
        if import_type is not UNSET:
            field_dict["ImportType"] = import_type
        if status is not UNSET:
            field_dict["Status"] = status
        if source is not UNSET:
            field_dict["Source"] = source
        if publications is not UNSET:
            field_dict["Publications"] = publications
        if lists is not UNSET:
            field_dict["Lists"] = lists
        if auto_responder is not UNSET:
            field_dict["AutoResponder"] = auto_responder
        if field_mappings is not UNSET:
            field_dict["FieldMappings"] = field_mappings
        if results is not UNSET:
            field_dict["Results"] = results
        if links is not UNSET:
            field_dict["Links"] = links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.file_import_details_response_200_auto_responder import FileImportDetailsResponse200AutoResponder
        from ..models.file_import_details_response_200_field_mappings_item import (
            FileImportDetailsResponse200FieldMappingsItem,
        )
        from ..models.file_import_details_response_200_links_item import FileImportDetailsResponse200LinksItem
        from ..models.file_import_details_response_200_lists_item import FileImportDetailsResponse200ListsItem
        from ..models.file_import_details_response_200_publications_item import (
            FileImportDetailsResponse200PublicationsItem,
        )
        from ..models.file_import_details_response_200_results import FileImportDetailsResponse200Results
        from ..models.file_import_details_response_200_source import FileImportDetailsResponse200Source

        d = dict(src_dict)
        file_import_id = d.pop("FileImportID", UNSET)

        name = d.pop("Name", UNSET)

        created = d.pop("Created", UNSET)

        records = d.pop("Records", UNSET)

        import_type = d.pop("ImportType", UNSET)

        status = d.pop("Status", UNSET)

        _source = d.pop("Source", UNSET)
        source: FileImportDetailsResponse200Source | Unset
        if isinstance(_source, Unset):
            source = UNSET
        else:
            source = FileImportDetailsResponse200Source.from_dict(_source)

        _publications = d.pop("Publications", UNSET)
        publications: list[FileImportDetailsResponse200PublicationsItem] | Unset = UNSET
        if _publications is not UNSET:
            publications = []
            for publications_item_data in _publications:
                publications_item = FileImportDetailsResponse200PublicationsItem.from_dict(publications_item_data)

                publications.append(publications_item)

        _lists = d.pop("Lists", UNSET)
        lists: list[FileImportDetailsResponse200ListsItem] | Unset = UNSET
        if _lists is not UNSET:
            lists = []
            for lists_item_data in _lists:
                lists_item = FileImportDetailsResponse200ListsItem.from_dict(lists_item_data)

                lists.append(lists_item)

        _auto_responder = d.pop("AutoResponder", UNSET)
        auto_responder: FileImportDetailsResponse200AutoResponder | Unset
        if isinstance(_auto_responder, Unset):
            auto_responder = UNSET
        else:
            auto_responder = FileImportDetailsResponse200AutoResponder.from_dict(_auto_responder)

        _field_mappings = d.pop("FieldMappings", UNSET)
        field_mappings: list[FileImportDetailsResponse200FieldMappingsItem] | Unset = UNSET
        if _field_mappings is not UNSET:
            field_mappings = []
            for field_mappings_item_data in _field_mappings:
                field_mappings_item = FileImportDetailsResponse200FieldMappingsItem.from_dict(field_mappings_item_data)

                field_mappings.append(field_mappings_item)

        _results = d.pop("Results", UNSET)
        results: FileImportDetailsResponse200Results | Unset
        if isinstance(_results, Unset):
            results = UNSET
        else:
            results = FileImportDetailsResponse200Results.from_dict(_results)

        _links = d.pop("Links", UNSET)
        links: list[FileImportDetailsResponse200LinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = FileImportDetailsResponse200LinksItem.from_dict(links_item_data)

                links.append(links_item)

        file_import_details_response_200 = cls(
            file_import_id=file_import_id,
            name=name,
            created=created,
            records=records,
            import_type=import_type,
            status=status,
            source=source,
            publications=publications,
            lists=lists,
            auto_responder=auto_responder,
            field_mappings=field_mappings,
            results=results,
            links=links,
        )

        file_import_details_response_200.additional_properties = d
        return file_import_details_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
