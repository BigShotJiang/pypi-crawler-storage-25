from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="CreativeAddJsonBody")


@_attrs_define
class CreativeAddJsonBody:
    """
    Attributes:
        name (str | Unset):
        text (str | Unset):
        html (str | Unset):
    """

    name: str | Unset = UNSET
    text: str | Unset = UNSET
    html: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        text = self.text

        html = self.html

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["Name"] = name
        if text is not UNSET:
            field_dict["Text"] = text
        if html is not UNSET:
            field_dict["HTML"] = html

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("Name", UNSET)

        text = d.pop("Text", UNSET)

        html = d.pop("HTML", UNSET)

        creative_add_json_body = cls(
            name=name,
            text=text,
            html=html,
        )

        creative_add_json_body.additional_properties = d
        return creative_add_json_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
