from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="FileImportDetailsResponse200Results")


@_attrs_define
class FileImportDetailsResponse200Results:
    """
    Attributes:
        duplicates (int | Unset):
        found_but_bounced (int | Unset):
        found_but_removed (int | Unset):
        malformed_emails (int | Unset):
        malformed_records (int | Unset):
        records_added (int | Unset):
        records_deleted (int | Unset):
        records_removed (int | Unset):
        records_updated (int | Unset):
    """

    duplicates: int | Unset = UNSET
    found_but_bounced: int | Unset = UNSET
    found_but_removed: int | Unset = UNSET
    malformed_emails: int | Unset = UNSET
    malformed_records: int | Unset = UNSET
    records_added: int | Unset = UNSET
    records_deleted: int | Unset = UNSET
    records_removed: int | Unset = UNSET
    records_updated: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        duplicates = self.duplicates

        found_but_bounced = self.found_but_bounced

        found_but_removed = self.found_but_removed

        malformed_emails = self.malformed_emails

        malformed_records = self.malformed_records

        records_added = self.records_added

        records_deleted = self.records_deleted

        records_removed = self.records_removed

        records_updated = self.records_updated

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if duplicates is not UNSET:
            field_dict["Duplicates"] = duplicates
        if found_but_bounced is not UNSET:
            field_dict["FoundButBounced"] = found_but_bounced
        if found_but_removed is not UNSET:
            field_dict["FoundButRemoved"] = found_but_removed
        if malformed_emails is not UNSET:
            field_dict["MalformedEmails"] = malformed_emails
        if malformed_records is not UNSET:
            field_dict["MalformedRecords"] = malformed_records
        if records_added is not UNSET:
            field_dict["RecordsAdded"] = records_added
        if records_deleted is not UNSET:
            field_dict["RecordsDeleted"] = records_deleted
        if records_removed is not UNSET:
            field_dict["RecordsRemoved"] = records_removed
        if records_updated is not UNSET:
            field_dict["RecordsUpdated"] = records_updated

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        duplicates = d.pop("Duplicates", UNSET)

        found_but_bounced = d.pop("FoundButBounced", UNSET)

        found_but_removed = d.pop("FoundButRemoved", UNSET)

        malformed_emails = d.pop("MalformedEmails", UNSET)

        malformed_records = d.pop("MalformedRecords", UNSET)

        records_added = d.pop("RecordsAdded", UNSET)

        records_deleted = d.pop("RecordsDeleted", UNSET)

        records_removed = d.pop("RecordsRemoved", UNSET)

        records_updated = d.pop("RecordsUpdated", UNSET)

        file_import_details_response_200_results = cls(
            duplicates=duplicates,
            found_but_bounced=found_but_bounced,
            found_but_removed=found_but_removed,
            malformed_emails=malformed_emails,
            malformed_records=malformed_records,
            records_added=records_added,
            records_deleted=records_deleted,
            records_removed=records_removed,
            records_updated=records_updated,
        )

        file_import_details_response_200_results.additional_properties = d
        return file_import_details_response_200_results

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
