from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.list_list_response_200_lists_item import ListListResponse200ListsItem


T = TypeVar("T", bound="ListListResponse200")


@_attrs_define
class ListListResponse200:
    """
    Attributes:
        lists (list[ListListResponse200ListsItem] | Unset):
    """

    lists: list[ListListResponse200ListsItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        lists: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.lists, Unset):
            lists = []
            for lists_item_data in self.lists:
                lists_item = lists_item_data.to_dict()
                lists.append(lists_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if lists is not UNSET:
            field_dict["Lists"] = lists

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.list_list_response_200_lists_item import ListListResponse200ListsItem

        d = dict(src_dict)
        _lists = d.pop("Lists", UNSET)
        lists: list[ListListResponse200ListsItem] | Unset = UNSET
        if _lists is not UNSET:
            lists = []
            for lists_item_data in _lists:
                lists_item = ListListResponse200ListsItem.from_dict(lists_item_data)

                lists.append(lists_item)

        list_list_response_200 = cls(
            lists=lists,
        )

        list_list_response_200.additional_properties = d
        return list_list_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
