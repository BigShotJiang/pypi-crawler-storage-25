from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.creative_folder_update_response_200_links_item import CreativeFolderUpdateResponse200LinksItem


T = TypeVar("T", bound="CreativeFolderUpdateResponse200")


@_attrs_define
class CreativeFolderUpdateResponse200:
    """
    Attributes:
        folder_id (int | Unset):
        folder_name (str | Unset):
        creatives (int | Unset):
        folders (list[Any] | Unset):
        links (list[CreativeFolderUpdateResponse200LinksItem] | Unset):
    """

    folder_id: int | Unset = UNSET
    folder_name: str | Unset = UNSET
    creatives: int | Unset = UNSET
    folders: list[Any] | Unset = UNSET
    links: list[CreativeFolderUpdateResponse200LinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        folder_id = self.folder_id

        folder_name = self.folder_name

        creatives = self.creatives

        folders: list[Any] | Unset = UNSET
        if not isinstance(self.folders, Unset):
            folders = self.folders

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if folder_id is not UNSET:
            field_dict["FolderID"] = folder_id
        if folder_name is not UNSET:
            field_dict["FolderName"] = folder_name
        if creatives is not UNSET:
            field_dict["Creatives"] = creatives
        if folders is not UNSET:
            field_dict["Folders"] = folders
        if links is not UNSET:
            field_dict["Links"] = links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.creative_folder_update_response_200_links_item import CreativeFolderUpdateResponse200LinksItem

        d = dict(src_dict)
        folder_id = d.pop("FolderID", UNSET)

        folder_name = d.pop("FolderName", UNSET)

        creatives = d.pop("Creatives", UNSET)

        folders = cast(list[Any], d.pop("Folders", UNSET))

        _links = d.pop("Links", UNSET)
        links: list[CreativeFolderUpdateResponse200LinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = CreativeFolderUpdateResponse200LinksItem.from_dict(links_item_data)

                links.append(links_item)

        creative_folder_update_response_200 = cls(
            folder_id=folder_id,
            folder_name=folder_name,
            creatives=creatives,
            folders=folders,
            links=links,
        )

        creative_folder_update_response_200.additional_properties = d
        return creative_folder_update_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
