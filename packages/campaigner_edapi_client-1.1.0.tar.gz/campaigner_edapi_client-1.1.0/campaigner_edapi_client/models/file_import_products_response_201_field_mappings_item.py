from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="FileImportProductsResponse201FieldMappingsItem")


@_attrs_define
class FileImportProductsResponse201FieldMappingsItem:
    """
    Attributes:
        file_column_index (int | Unset):
        column_name (str | Unset):
    """

    file_column_index: int | Unset = UNSET
    column_name: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        file_column_index = self.file_column_index

        column_name = self.column_name

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if file_column_index is not UNSET:
            field_dict["FileColumnIndex"] = file_column_index
        if column_name is not UNSET:
            field_dict["ColumnName"] = column_name

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        file_column_index = d.pop("FileColumnIndex", UNSET)

        column_name = d.pop("ColumnName", UNSET)

        file_import_products_response_201_field_mappings_item = cls(
            file_column_index=file_column_index,
            column_name=column_name,
        )

        file_import_products_response_201_field_mappings_item.additional_properties = d
        return file_import_products_response_201_field_mappings_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
