from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.creative_folder_templates_response_200_items_item_links_item import (
        CreativeFolderTemplatesResponse200ItemsItemLinksItem,
    )


T = TypeVar("T", bound="CreativeFolderTemplatesResponse200ItemsItem")


@_attrs_define
class CreativeFolderTemplatesResponse200ItemsItem:
    """
    Attributes:
        creative_id (int | Unset):
        created (str | Unset):
        last_updated (str | Unset):
        creative_name (str | Unset):
        links (list[CreativeFolderTemplatesResponse200ItemsItemLinksItem] | Unset):
    """

    creative_id: int | Unset = UNSET
    created: str | Unset = UNSET
    last_updated: str | Unset = UNSET
    creative_name: str | Unset = UNSET
    links: list[CreativeFolderTemplatesResponse200ItemsItemLinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        creative_id = self.creative_id

        created = self.created

        last_updated = self.last_updated

        creative_name = self.creative_name

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if creative_id is not UNSET:
            field_dict["CreativeID"] = creative_id
        if created is not UNSET:
            field_dict["Created"] = created
        if last_updated is not UNSET:
            field_dict["LastUpdated"] = last_updated
        if creative_name is not UNSET:
            field_dict["CreativeName"] = creative_name
        if links is not UNSET:
            field_dict["Links"] = links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.creative_folder_templates_response_200_items_item_links_item import (
            CreativeFolderTemplatesResponse200ItemsItemLinksItem,
        )

        d = dict(src_dict)
        creative_id = d.pop("CreativeID", UNSET)

        created = d.pop("Created", UNSET)

        last_updated = d.pop("LastUpdated", UNSET)

        creative_name = d.pop("CreativeName", UNSET)

        _links = d.pop("Links", UNSET)
        links: list[CreativeFolderTemplatesResponse200ItemsItemLinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = CreativeFolderTemplatesResponse200ItemsItemLinksItem.from_dict(links_item_data)

                links.append(links_item)

        creative_folder_templates_response_200_items_item = cls(
            creative_id=creative_id,
            created=created,
            last_updated=last_updated,
            creative_name=creative_name,
            links=links,
        )

        creative_folder_templates_response_200_items_item.additional_properties = d
        return creative_folder_templates_response_200_items_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
