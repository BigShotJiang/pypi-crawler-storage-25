from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="CategoryUpdateJsonBody")


@_attrs_define
class CategoryUpdateJsonBody:
    """
    Attributes:
        name (str | Unset):
        description (str | Unset):
        image (str | Unset):
        url (str | Unset):
    """

    name: str | Unset = UNSET
    description: str | Unset = UNSET
    image: str | Unset = UNSET
    url: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        description = self.description

        image = self.image

        url = self.url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["Name"] = name
        if description is not UNSET:
            field_dict["Description"] = description
        if image is not UNSET:
            field_dict["Image"] = image
        if url is not UNSET:
            field_dict["URL"] = url

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("Name", UNSET)

        description = d.pop("Description", UNSET)

        image = d.pop("Image", UNSET)

        url = d.pop("URL", UNSET)

        category_update_json_body = cls(
            name=name,
            description=description,
            image=image,
            url=url,
        )

        category_update_json_body.additional_properties = d
        return category_update_json_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
