from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.file_import_details_response_200_source_links_item import FileImportDetailsResponse200SourceLinksItem


T = TypeVar("T", bound="FileImportDetailsResponse200Source")


@_attrs_define
class FileImportDetailsResponse200Source:
    """
    Attributes:
        source_id (int | Unset):
        name (str | Unset):
        links (list[FileImportDetailsResponse200SourceLinksItem] | Unset):
    """

    source_id: int | Unset = UNSET
    name: str | Unset = UNSET
    links: list[FileImportDetailsResponse200SourceLinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        source_id = self.source_id

        name = self.name

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if source_id is not UNSET:
            field_dict["SourceID"] = source_id
        if name is not UNSET:
            field_dict["Name"] = name
        if links is not UNSET:
            field_dict["Links"] = links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.file_import_details_response_200_source_links_item import (
            FileImportDetailsResponse200SourceLinksItem,
        )

        d = dict(src_dict)
        source_id = d.pop("SourceID", UNSET)

        name = d.pop("Name", UNSET)

        _links = d.pop("Links", UNSET)
        links: list[FileImportDetailsResponse200SourceLinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = FileImportDetailsResponse200SourceLinksItem.from_dict(links_item_data)

                links.append(links_item)

        file_import_details_response_200_source = cls(
            source_id=source_id,
            name=name,
            links=links,
        )

        file_import_details_response_200_source.additional_properties = d
        return file_import_details_response_200_source

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
