from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.campaign_link_clickers_response_200_items_item import CampaignLinkClickersResponse200ItemsItem
    from ..models.campaign_link_clickers_response_200_links_item import CampaignLinkClickersResponse200LinksItem


T = TypeVar("T", bound="CampaignLinkClickersResponse200")


@_attrs_define
class CampaignLinkClickersResponse200:
    """
    Attributes:
        page_size (int | Unset):
        page_number (int | Unset):
        total_records (int | Unset):
        total_pages (int | Unset):
        items (list[CampaignLinkClickersResponse200ItemsItem] | Unset):
        links (list[CampaignLinkClickersResponse200LinksItem] | Unset):
    """

    page_size: int | Unset = UNSET
    page_number: int | Unset = UNSET
    total_records: int | Unset = UNSET
    total_pages: int | Unset = UNSET
    items: list[CampaignLinkClickersResponse200ItemsItem] | Unset = UNSET
    links: list[CampaignLinkClickersResponse200LinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        page_size = self.page_size

        page_number = self.page_number

        total_records = self.total_records

        total_pages = self.total_pages

        items: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.items, Unset):
            items = []
            for items_item_data in self.items:
                items_item = items_item_data.to_dict()
                items.append(items_item)

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if page_size is not UNSET:
            field_dict["PageSize"] = page_size
        if page_number is not UNSET:
            field_dict["PageNumber"] = page_number
        if total_records is not UNSET:
            field_dict["TotalRecords"] = total_records
        if total_pages is not UNSET:
            field_dict["TotalPages"] = total_pages
        if items is not UNSET:
            field_dict["Items"] = items
        if links is not UNSET:
            field_dict["Links"] = links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.campaign_link_clickers_response_200_items_item import CampaignLinkClickersResponse200ItemsItem
        from ..models.campaign_link_clickers_response_200_links_item import CampaignLinkClickersResponse200LinksItem

        d = dict(src_dict)
        page_size = d.pop("PageSize", UNSET)

        page_number = d.pop("PageNumber", UNSET)

        total_records = d.pop("TotalRecords", UNSET)

        total_pages = d.pop("TotalPages", UNSET)

        _items = d.pop("Items", UNSET)
        items: list[CampaignLinkClickersResponse200ItemsItem] | Unset = UNSET
        if _items is not UNSET:
            items = []
            for items_item_data in _items:
                items_item = CampaignLinkClickersResponse200ItemsItem.from_dict(items_item_data)

                items.append(items_item)

        _links = d.pop("Links", UNSET)
        links: list[CampaignLinkClickersResponse200LinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = CampaignLinkClickersResponse200LinksItem.from_dict(links_item_data)

                links.append(links_item)

        campaign_link_clickers_response_200 = cls(
            page_size=page_size,
            page_number=page_number,
            total_records=total_records,
            total_pages=total_pages,
            items=items,
            links=links,
        )

        campaign_link_clickers_response_200.additional_properties = d
        return campaign_link_clickers_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
