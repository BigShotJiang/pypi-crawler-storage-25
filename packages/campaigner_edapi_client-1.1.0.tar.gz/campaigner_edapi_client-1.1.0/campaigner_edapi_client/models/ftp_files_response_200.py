from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.ftp_files_response_200ftp_files_item import FTPFilesResponse200FTPFilesItem


T = TypeVar("T", bound="FTPFilesResponse200")


@_attrs_define
class FTPFilesResponse200:
    """
    Attributes:
        ftp_files (list[FTPFilesResponse200FTPFilesItem] | Unset):
    """

    ftp_files: list[FTPFilesResponse200FTPFilesItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        ftp_files: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.ftp_files, Unset):
            ftp_files = []
            for ftp_files_item_data in self.ftp_files:
                ftp_files_item = ftp_files_item_data.to_dict()
                ftp_files.append(ftp_files_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if ftp_files is not UNSET:
            field_dict["FTPFiles"] = ftp_files

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.ftp_files_response_200ftp_files_item import FTPFilesResponse200FTPFilesItem

        d = dict(src_dict)
        _ftp_files = d.pop("FTPFiles", UNSET)
        ftp_files: list[FTPFilesResponse200FTPFilesItem] | Unset = UNSET
        if _ftp_files is not UNSET:
            ftp_files = []
            for ftp_files_item_data in _ftp_files:
                ftp_files_item = FTPFilesResponse200FTPFilesItem.from_dict(ftp_files_item_data)

                ftp_files.append(ftp_files_item)

        ftp_files_response_200 = cls(
            ftp_files=ftp_files,
        )

        ftp_files_response_200.additional_properties = d
        return ftp_files_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
