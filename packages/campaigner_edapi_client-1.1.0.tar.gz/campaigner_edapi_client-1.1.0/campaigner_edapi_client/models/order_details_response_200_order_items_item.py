from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.order_details_response_200_order_items_item_links_item import (
        OrderDetailsResponse200OrderItemsItemLinksItem,
    )


T = TypeVar("T", bound="OrderDetailsResponse200OrderItemsItem")


@_attrs_define
class OrderDetailsResponse200OrderItemsItem:
    """
    Attributes:
        order_item_id (int | Unset):
        product_id (int | Unset):
        order_number (str | Unset):
        email_address (str | Unset):
        product_name (str | Unset):
        sku (str | Unset):
        quantity (int | Unset):
        unit_price (float | Unset):
        weight (float | Unset):
        status (str | Unset):
        total_amount (float | Unset):
        purchase_date (str | Unset):
        created (str | Unset):
        last_updated (str | Unset):
        links (list[OrderDetailsResponse200OrderItemsItemLinksItem] | Unset):
    """

    order_item_id: int | Unset = UNSET
    product_id: int | Unset = UNSET
    order_number: str | Unset = UNSET
    email_address: str | Unset = UNSET
    product_name: str | Unset = UNSET
    sku: str | Unset = UNSET
    quantity: int | Unset = UNSET
    unit_price: float | Unset = UNSET
    weight: float | Unset = UNSET
    status: str | Unset = UNSET
    total_amount: float | Unset = UNSET
    purchase_date: str | Unset = UNSET
    created: str | Unset = UNSET
    last_updated: str | Unset = UNSET
    links: list[OrderDetailsResponse200OrderItemsItemLinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        order_item_id = self.order_item_id

        product_id = self.product_id

        order_number = self.order_number

        email_address = self.email_address

        product_name = self.product_name

        sku = self.sku

        quantity = self.quantity

        unit_price = self.unit_price

        weight = self.weight

        status = self.status

        total_amount = self.total_amount

        purchase_date = self.purchase_date

        created = self.created

        last_updated = self.last_updated

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if order_item_id is not UNSET:
            field_dict["OrderItemID"] = order_item_id
        if product_id is not UNSET:
            field_dict["ProductID"] = product_id
        if order_number is not UNSET:
            field_dict["OrderNumber"] = order_number
        if email_address is not UNSET:
            field_dict["EmailAddress"] = email_address
        if product_name is not UNSET:
            field_dict["ProductName"] = product_name
        if sku is not UNSET:
            field_dict["SKU"] = sku
        if quantity is not UNSET:
            field_dict["Quantity"] = quantity
        if unit_price is not UNSET:
            field_dict["UnitPrice"] = unit_price
        if weight is not UNSET:
            field_dict["Weight"] = weight
        if status is not UNSET:
            field_dict["Status"] = status
        if total_amount is not UNSET:
            field_dict["TotalAmount"] = total_amount
        if purchase_date is not UNSET:
            field_dict["PurchaseDate"] = purchase_date
        if created is not UNSET:
            field_dict["Created"] = created
        if last_updated is not UNSET:
            field_dict["LastUpdated"] = last_updated
        if links is not UNSET:
            field_dict["Links"] = links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.order_details_response_200_order_items_item_links_item import (
            OrderDetailsResponse200OrderItemsItemLinksItem,
        )

        d = dict(src_dict)
        order_item_id = d.pop("OrderItemID", UNSET)

        product_id = d.pop("ProductID", UNSET)

        order_number = d.pop("OrderNumber", UNSET)

        email_address = d.pop("EmailAddress", UNSET)

        product_name = d.pop("ProductName", UNSET)

        sku = d.pop("SKU", UNSET)

        quantity = d.pop("Quantity", UNSET)

        unit_price = d.pop("UnitPrice", UNSET)

        weight = d.pop("Weight", UNSET)

        status = d.pop("Status", UNSET)

        total_amount = d.pop("TotalAmount", UNSET)

        purchase_date = d.pop("PurchaseDate", UNSET)

        created = d.pop("Created", UNSET)

        last_updated = d.pop("LastUpdated", UNSET)

        _links = d.pop("Links", UNSET)
        links: list[OrderDetailsResponse200OrderItemsItemLinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = OrderDetailsResponse200OrderItemsItemLinksItem.from_dict(links_item_data)

                links.append(links_item)

        order_details_response_200_order_items_item = cls(
            order_item_id=order_item_id,
            product_id=product_id,
            order_number=order_number,
            email_address=email_address,
            product_name=product_name,
            sku=sku,
            quantity=quantity,
            unit_price=unit_price,
            weight=weight,
            status=status,
            total_amount=total_amount,
            purchase_date=purchase_date,
            created=created,
            last_updated=last_updated,
            links=links,
        )

        order_details_response_200_order_items_item.additional_properties = d
        return order_details_response_200_order_items_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
