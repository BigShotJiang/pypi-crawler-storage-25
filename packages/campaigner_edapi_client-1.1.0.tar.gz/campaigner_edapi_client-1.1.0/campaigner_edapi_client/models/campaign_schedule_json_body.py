from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="CampaignScheduleJsonBody")


@_attrs_define
class CampaignScheduleJsonBody:
    """
    Attributes:
        campaign_id (int | Unset):
        schedule_date (str | Unset):
    """

    campaign_id: int | Unset = UNSET
    schedule_date: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        campaign_id = self.campaign_id

        schedule_date = self.schedule_date

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if campaign_id is not UNSET:
            field_dict["CampaignID"] = campaign_id
        if schedule_date is not UNSET:
            field_dict["ScheduleDate"] = schedule_date

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        campaign_id = d.pop("CampaignID", UNSET)

        schedule_date = d.pop("ScheduleDate", UNSET)

        campaign_schedule_json_body = cls(
            campaign_id=campaign_id,
            schedule_date=schedule_date,
        )

        campaign_schedule_json_body.additional_properties = d
        return campaign_schedule_json_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
