from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ListAddEmailsResponse200")


@_attrs_define
class ListAddEmailsResponse200:
    """
    Attributes:
        contacts_submitted (int | Unset):
        successes (int | Unset):
        failures (list[Any] | Unset):
    """

    contacts_submitted: int | Unset = UNSET
    successes: int | Unset = UNSET
    failures: list[Any] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        contacts_submitted = self.contacts_submitted

        successes = self.successes

        failures: list[Any] | Unset = UNSET
        if not isinstance(self.failures, Unset):
            failures = self.failures

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if contacts_submitted is not UNSET:
            field_dict["ContactsSubmitted"] = contacts_submitted
        if successes is not UNSET:
            field_dict["Successes"] = successes
        if failures is not UNSET:
            field_dict["Failures"] = failures

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        contacts_submitted = d.pop("ContactsSubmitted", UNSET)

        successes = d.pop("Successes", UNSET)

        failures = cast(list[Any], d.pop("Failures", UNSET))

        list_add_emails_response_200 = cls(
            contacts_submitted=contacts_submitted,
            successes=successes,
            failures=failures,
        )

        list_add_emails_response_200.additional_properties = d
        return list_add_emails_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
