from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.database_list_response_200_database_columns_item import DatabaseListResponse200DatabaseColumnsItem


T = TypeVar("T", bound="DatabaseListResponse200")


@_attrs_define
class DatabaseListResponse200:
    """
    Attributes:
        database_columns (list[DatabaseListResponse200DatabaseColumnsItem] | Unset):
    """

    database_columns: list[DatabaseListResponse200DatabaseColumnsItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        database_columns: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.database_columns, Unset):
            database_columns = []
            for database_columns_item_data in self.database_columns:
                database_columns_item = database_columns_item_data.to_dict()
                database_columns.append(database_columns_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if database_columns is not UNSET:
            field_dict["DatabaseColumns"] = database_columns

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.database_list_response_200_database_columns_item import DatabaseListResponse200DatabaseColumnsItem

        d = dict(src_dict)
        _database_columns = d.pop("DatabaseColumns", UNSET)
        database_columns: list[DatabaseListResponse200DatabaseColumnsItem] | Unset = UNSET
        if _database_columns is not UNSET:
            database_columns = []
            for database_columns_item_data in _database_columns:
                database_columns_item = DatabaseListResponse200DatabaseColumnsItem.from_dict(database_columns_item_data)

                database_columns.append(database_columns_item)

        database_list_response_200 = cls(
            database_columns=database_columns,
        )

        database_list_response_200.additional_properties = d
        return database_list_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
