from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.order_details_response_200_links_item import OrderDetailsResponse200LinksItem
    from ..models.order_details_response_200_order_items_item import OrderDetailsResponse200OrderItemsItem


T = TypeVar("T", bound="OrderDetailsResponse200")


@_attrs_define
class OrderDetailsResponse200:
    """
    Attributes:
        order_number (str | Unset):
        email_address (str | Unset):
        purchase_date (str | Unset):
        created (str | Unset):
        last_updated (str | Unset):
        total_items (int | Unset):
        total_amount (float | Unset):
        total_weight (float | Unset):
        is_active (bool | Unset):
        order_items (list[OrderDetailsResponse200OrderItemsItem] | Unset):
        links (list[OrderDetailsResponse200LinksItem] | Unset):
    """

    order_number: str | Unset = UNSET
    email_address: str | Unset = UNSET
    purchase_date: str | Unset = UNSET
    created: str | Unset = UNSET
    last_updated: str | Unset = UNSET
    total_items: int | Unset = UNSET
    total_amount: float | Unset = UNSET
    total_weight: float | Unset = UNSET
    is_active: bool | Unset = UNSET
    order_items: list[OrderDetailsResponse200OrderItemsItem] | Unset = UNSET
    links: list[OrderDetailsResponse200LinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        order_number = self.order_number

        email_address = self.email_address

        purchase_date = self.purchase_date

        created = self.created

        last_updated = self.last_updated

        total_items = self.total_items

        total_amount = self.total_amount

        total_weight = self.total_weight

        is_active = self.is_active

        order_items: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.order_items, Unset):
            order_items = []
            for order_items_item_data in self.order_items:
                order_items_item = order_items_item_data.to_dict()
                order_items.append(order_items_item)

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if order_number is not UNSET:
            field_dict["OrderNumber"] = order_number
        if email_address is not UNSET:
            field_dict["EmailAddress"] = email_address
        if purchase_date is not UNSET:
            field_dict["PurchaseDate"] = purchase_date
        if created is not UNSET:
            field_dict["Created"] = created
        if last_updated is not UNSET:
            field_dict["LastUpdated"] = last_updated
        if total_items is not UNSET:
            field_dict["TotalItems"] = total_items
        if total_amount is not UNSET:
            field_dict["TotalAmount"] = total_amount
        if total_weight is not UNSET:
            field_dict["TotalWeight"] = total_weight
        if is_active is not UNSET:
            field_dict["IsActive"] = is_active
        if order_items is not UNSET:
            field_dict["OrderItems"] = order_items
        if links is not UNSET:
            field_dict["Links"] = links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.order_details_response_200_links_item import OrderDetailsResponse200LinksItem
        from ..models.order_details_response_200_order_items_item import OrderDetailsResponse200OrderItemsItem

        d = dict(src_dict)
        order_number = d.pop("OrderNumber", UNSET)

        email_address = d.pop("EmailAddress", UNSET)

        purchase_date = d.pop("PurchaseDate", UNSET)

        created = d.pop("Created", UNSET)

        last_updated = d.pop("LastUpdated", UNSET)

        total_items = d.pop("TotalItems", UNSET)

        total_amount = d.pop("TotalAmount", UNSET)

        total_weight = d.pop("TotalWeight", UNSET)

        is_active = d.pop("IsActive", UNSET)

        _order_items = d.pop("OrderItems", UNSET)
        order_items: list[OrderDetailsResponse200OrderItemsItem] | Unset = UNSET
        if _order_items is not UNSET:
            order_items = []
            for order_items_item_data in _order_items:
                order_items_item = OrderDetailsResponse200OrderItemsItem.from_dict(order_items_item_data)

                order_items.append(order_items_item)

        _links = d.pop("Links", UNSET)
        links: list[OrderDetailsResponse200LinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = OrderDetailsResponse200LinksItem.from_dict(links_item_data)

                links.append(links_item)

        order_details_response_200 = cls(
            order_number=order_number,
            email_address=email_address,
            purchase_date=purchase_date,
            created=created,
            last_updated=last_updated,
            total_items=total_items,
            total_amount=total_amount,
            total_weight=total_weight,
            is_active=is_active,
            order_items=order_items,
            links=links,
        )

        order_details_response_200.additional_properties = d
        return order_details_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
