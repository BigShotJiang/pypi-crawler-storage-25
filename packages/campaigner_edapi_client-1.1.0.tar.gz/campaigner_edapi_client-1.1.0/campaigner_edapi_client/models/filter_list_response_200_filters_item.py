from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.filter_list_response_200_filters_item_links_item import FilterListResponse200FiltersItemLinksItem


T = TypeVar("T", bound="FilterListResponse200FiltersItem")


@_attrs_define
class FilterListResponse200FiltersItem:
    """
    Attributes:
        filter_id (int | Unset):
        created (str | Unset):
        name (str | Unset):
        description (str | Unset):
        last_updated (str | Unset):
        links (list[FilterListResponse200FiltersItemLinksItem] | Unset):
    """

    filter_id: int | Unset = UNSET
    created: str | Unset = UNSET
    name: str | Unset = UNSET
    description: str | Unset = UNSET
    last_updated: str | Unset = UNSET
    links: list[FilterListResponse200FiltersItemLinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        filter_id = self.filter_id

        created = self.created

        name = self.name

        description = self.description

        last_updated = self.last_updated

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if filter_id is not UNSET:
            field_dict["FilterID"] = filter_id
        if created is not UNSET:
            field_dict["Created"] = created
        if name is not UNSET:
            field_dict["Name"] = name
        if description is not UNSET:
            field_dict["Description"] = description
        if last_updated is not UNSET:
            field_dict["LastUpdated"] = last_updated
        if links is not UNSET:
            field_dict["Links"] = links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.filter_list_response_200_filters_item_links_item import FilterListResponse200FiltersItemLinksItem

        d = dict(src_dict)
        filter_id = d.pop("FilterID", UNSET)

        created = d.pop("Created", UNSET)

        name = d.pop("Name", UNSET)

        description = d.pop("Description", UNSET)

        last_updated = d.pop("LastUpdated", UNSET)

        _links = d.pop("Links", UNSET)
        links: list[FilterListResponse200FiltersItemLinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = FilterListResponse200FiltersItemLinksItem.from_dict(links_item_data)

                links.append(links_item)

        filter_list_response_200_filters_item = cls(
            filter_id=filter_id,
            created=created,
            name=name,
            description=description,
            last_updated=last_updated,
            links=links,
        )

        filter_list_response_200_filters_item.additional_properties = d
        return filter_list_response_200_filters_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
