from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.category_products_response_200_items_item_links_item import (
        CategoryProductsResponse200ItemsItemLinksItem,
    )


T = TypeVar("T", bound="CategoryProductsResponse200ItemsItem")


@_attrs_define
class CategoryProductsResponse200ItemsItem:
    """
    Attributes:
        product_id (int | Unset):
        sku (str | Unset):
        product_name (str | Unset):
        long_description (str | Unset):
        short_description (str | Unset):
        product_url (str | Unset):
        product_image (str | Unset):
        weight (float | Unset):
        cost (float | Unset):
        price (float | Unset):
        active (bool | Unset):
        created (str | Unset):
        last_updated (str | Unset):
        links (list[CategoryProductsResponse200ItemsItemLinksItem] | Unset):
    """

    product_id: int | Unset = UNSET
    sku: str | Unset = UNSET
    product_name: str | Unset = UNSET
    long_description: str | Unset = UNSET
    short_description: str | Unset = UNSET
    product_url: str | Unset = UNSET
    product_image: str | Unset = UNSET
    weight: float | Unset = UNSET
    cost: float | Unset = UNSET
    price: float | Unset = UNSET
    active: bool | Unset = UNSET
    created: str | Unset = UNSET
    last_updated: str | Unset = UNSET
    links: list[CategoryProductsResponse200ItemsItemLinksItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        product_id = self.product_id

        sku = self.sku

        product_name = self.product_name

        long_description = self.long_description

        short_description = self.short_description

        product_url = self.product_url

        product_image = self.product_image

        weight = self.weight

        cost = self.cost

        price = self.price

        active = self.active

        created = self.created

        last_updated = self.last_updated

        links: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.links, Unset):
            links = []
            for links_item_data in self.links:
                links_item = links_item_data.to_dict()
                links.append(links_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if product_id is not UNSET:
            field_dict["ProductID"] = product_id
        if sku is not UNSET:
            field_dict["SKU"] = sku
        if product_name is not UNSET:
            field_dict["ProductName"] = product_name
        if long_description is not UNSET:
            field_dict["LongDescription"] = long_description
        if short_description is not UNSET:
            field_dict["ShortDescription"] = short_description
        if product_url is not UNSET:
            field_dict["ProductURL"] = product_url
        if product_image is not UNSET:
            field_dict["ProductImage"] = product_image
        if weight is not UNSET:
            field_dict["Weight"] = weight
        if cost is not UNSET:
            field_dict["Cost"] = cost
        if price is not UNSET:
            field_dict["Price"] = price
        if active is not UNSET:
            field_dict["Active"] = active
        if created is not UNSET:
            field_dict["Created"] = created
        if last_updated is not UNSET:
            field_dict["LastUpdated"] = last_updated
        if links is not UNSET:
            field_dict["Links"] = links

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.category_products_response_200_items_item_links_item import (
            CategoryProductsResponse200ItemsItemLinksItem,
        )

        d = dict(src_dict)
        product_id = d.pop("ProductID", UNSET)

        sku = d.pop("SKU", UNSET)

        product_name = d.pop("ProductName", UNSET)

        long_description = d.pop("LongDescription", UNSET)

        short_description = d.pop("ShortDescription", UNSET)

        product_url = d.pop("ProductURL", UNSET)

        product_image = d.pop("ProductImage", UNSET)

        weight = d.pop("Weight", UNSET)

        cost = d.pop("Cost", UNSET)

        price = d.pop("Price", UNSET)

        active = d.pop("Active", UNSET)

        created = d.pop("Created", UNSET)

        last_updated = d.pop("LastUpdated", UNSET)

        _links = d.pop("Links", UNSET)
        links: list[CategoryProductsResponse200ItemsItemLinksItem] | Unset = UNSET
        if _links is not UNSET:
            links = []
            for links_item_data in _links:
                links_item = CategoryProductsResponse200ItemsItemLinksItem.from_dict(links_item_data)

                links.append(links_item)

        category_products_response_200_items_item = cls(
            product_id=product_id,
            sku=sku,
            product_name=product_name,
            long_description=long_description,
            short_description=short_description,
            product_url=product_url,
            product_image=product_image,
            weight=weight,
            cost=cost,
            price=price,
            active=active,
            created=created,
            last_updated=last_updated,
            links=links,
        )

        category_products_response_200_items_item.additional_properties = d
        return category_products_response_200_items_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
