from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.relay_category_links_response_200 import RelayCategoryLinksResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    relay_send_category_id: str,
    *,
    end_date: str | Unset = UNSET,
    page_size: str | Unset = UNSET,
    start_date: str | Unset = UNSET,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    params: dict[str, Any] = {}

    params["EndDate"] = end_date

    params["PageSize"] = page_size

    params["StartDate"] = start_date

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/RelaySends/{relay_send_category_id}/Links".format(
            relay_send_category_id=quote(str(relay_send_category_id), safe=""),
        ),
        "params": params,
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> RelayCategoryLinksResponse200 | None:
    if response.status_code == 200:
        response_200 = RelayCategoryLinksResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[RelayCategoryLinksResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    relay_send_category_id: str,
    *,
    client: AuthenticatedClient,
    end_date: str | Unset = UNSET,
    page_size: str | Unset = UNSET,
    start_date: str | Unset = UNSET,
    api_key: str,
) -> Response[RelayCategoryLinksResponse200]:
    """Get Links

    Args:
        relay_send_category_id (str):
        end_date (str | Unset):
        page_size (str | Unset):
        start_date (str | Unset):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RelayCategoryLinksResponse200]
    """

    kwargs = _get_kwargs(
        relay_send_category_id=relay_send_category_id,
        end_date=end_date,
        page_size=page_size,
        start_date=start_date,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    relay_send_category_id: str,
    *,
    client: AuthenticatedClient,
    end_date: str | Unset = UNSET,
    page_size: str | Unset = UNSET,
    start_date: str | Unset = UNSET,
    api_key: str,
) -> RelayCategoryLinksResponse200 | None:
    """Get Links

    Args:
        relay_send_category_id (str):
        end_date (str | Unset):
        page_size (str | Unset):
        start_date (str | Unset):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RelayCategoryLinksResponse200
    """

    return sync_detailed(
        relay_send_category_id=relay_send_category_id,
        client=client,
        end_date=end_date,
        page_size=page_size,
        start_date=start_date,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    relay_send_category_id: str,
    *,
    client: AuthenticatedClient,
    end_date: str | Unset = UNSET,
    page_size: str | Unset = UNSET,
    start_date: str | Unset = UNSET,
    api_key: str,
) -> Response[RelayCategoryLinksResponse200]:
    """Get Links

    Args:
        relay_send_category_id (str):
        end_date (str | Unset):
        page_size (str | Unset):
        start_date (str | Unset):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RelayCategoryLinksResponse200]
    """

    kwargs = _get_kwargs(
        relay_send_category_id=relay_send_category_id,
        end_date=end_date,
        page_size=page_size,
        start_date=start_date,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    relay_send_category_id: str,
    *,
    client: AuthenticatedClient,
    end_date: str | Unset = UNSET,
    page_size: str | Unset = UNSET,
    start_date: str | Unset = UNSET,
    api_key: str,
) -> RelayCategoryLinksResponse200 | None:
    """Get Links

    Args:
        relay_send_category_id (str):
        end_date (str | Unset):
        page_size (str | Unset):
        start_date (str | Unset):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RelayCategoryLinksResponse200
    """

    return (
        await asyncio_detailed(
            relay_send_category_id=relay_send_category_id,
            client=client,
            end_date=end_date,
            page_size=page_size,
            start_date=start_date,
            api_key=api_key,
        )
    ).parsed
