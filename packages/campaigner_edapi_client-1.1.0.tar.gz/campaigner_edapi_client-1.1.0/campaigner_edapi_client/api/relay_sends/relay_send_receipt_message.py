from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...types import Response


def _get_kwargs(
    relay_send_receipt_id: str,
    *,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/RelaySends/Receipt/{relay_send_receipt_id}/Message".format(
            relay_send_receipt_id=quote(str(relay_send_receipt_id), safe=""),
        ),
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> str | None:
    if response.status_code == 200:
        response_200 = cast(str, response.json())
        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    relay_send_receipt_id: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> Response[str]:
    """Get Full Message

    Args:
        relay_send_receipt_id (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        relay_send_receipt_id=relay_send_receipt_id,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    relay_send_receipt_id: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> str | None:
    """Get Full Message

    Args:
        relay_send_receipt_id (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return sync_detailed(
        relay_send_receipt_id=relay_send_receipt_id,
        client=client,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    relay_send_receipt_id: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> Response[str]:
    """Get Full Message

    Args:
        relay_send_receipt_id (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[str]
    """

    kwargs = _get_kwargs(
        relay_send_receipt_id=relay_send_receipt_id,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    relay_send_receipt_id: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> str | None:
    """Get Full Message

    Args:
        relay_send_receipt_id (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        str
    """

    return (
        await asyncio_detailed(
            relay_send_receipt_id=relay_send_receipt_id,
            client=client,
            api_key=api_key,
        )
    ).parsed
