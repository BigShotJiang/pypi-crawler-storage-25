from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.order_item_update_json_body import OrderItemUpdateJsonBody
from ...models.order_item_update_response_200 import OrderItemUpdateResponse200
from ...types import Response


def _get_kwargs(
    order_item_id: str,
    *,
    body: OrderItemUpdateJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/Orders/Items/{order_item_id}".format(
            order_item_id=quote(str(order_item_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> OrderItemUpdateResponse200 | None:
    if response.status_code == 200:
        response_200 = OrderItemUpdateResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[OrderItemUpdateResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    order_item_id: str,
    *,
    client: AuthenticatedClient,
    body: OrderItemUpdateJsonBody,
    api_key: str,
) -> Response[OrderItemUpdateResponse200]:
    """Update OrderItem

    Args:
        order_item_id (str):
        api_key (str):
        body (OrderItemUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[OrderItemUpdateResponse200]
    """

    kwargs = _get_kwargs(
        order_item_id=order_item_id,
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    order_item_id: str,
    *,
    client: AuthenticatedClient,
    body: OrderItemUpdateJsonBody,
    api_key: str,
) -> OrderItemUpdateResponse200 | None:
    """Update OrderItem

    Args:
        order_item_id (str):
        api_key (str):
        body (OrderItemUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        OrderItemUpdateResponse200
    """

    return sync_detailed(
        order_item_id=order_item_id,
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    order_item_id: str,
    *,
    client: AuthenticatedClient,
    body: OrderItemUpdateJsonBody,
    api_key: str,
) -> Response[OrderItemUpdateResponse200]:
    """Update OrderItem

    Args:
        order_item_id (str):
        api_key (str):
        body (OrderItemUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[OrderItemUpdateResponse200]
    """

    kwargs = _get_kwargs(
        order_item_id=order_item_id,
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    order_item_id: str,
    *,
    client: AuthenticatedClient,
    body: OrderItemUpdateJsonBody,
    api_key: str,
) -> OrderItemUpdateResponse200 | None:
    """Update OrderItem

    Args:
        order_item_id (str):
        api_key (str):
        body (OrderItemUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        OrderItemUpdateResponse200
    """

    return (
        await asyncio_detailed(
            order_item_id=order_item_id,
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
