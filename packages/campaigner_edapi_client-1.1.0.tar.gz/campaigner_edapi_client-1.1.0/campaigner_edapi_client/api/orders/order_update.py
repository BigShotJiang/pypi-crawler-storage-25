from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.order_update_json_body import OrderUpdateJsonBody
from ...models.order_update_response_200 import OrderUpdateResponse200
from ...types import Response


def _get_kwargs(
    order_number: str,
    *,
    body: OrderUpdateJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/Orders/{order_number}".format(
            order_number=quote(str(order_number), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> OrderUpdateResponse200 | None:
    if response.status_code == 200:
        response_200 = OrderUpdateResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[OrderUpdateResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    order_number: str,
    *,
    client: AuthenticatedClient,
    body: OrderUpdateJsonBody,
    api_key: str,
) -> Response[OrderUpdateResponse200]:
    """Update Order

    Args:
        order_number (str):
        api_key (str):
        body (OrderUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[OrderUpdateResponse200]
    """

    kwargs = _get_kwargs(
        order_number=order_number,
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    order_number: str,
    *,
    client: AuthenticatedClient,
    body: OrderUpdateJsonBody,
    api_key: str,
) -> OrderUpdateResponse200 | None:
    """Update Order

    Args:
        order_number (str):
        api_key (str):
        body (OrderUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        OrderUpdateResponse200
    """

    return sync_detailed(
        order_number=order_number,
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    order_number: str,
    *,
    client: AuthenticatedClient,
    body: OrderUpdateJsonBody,
    api_key: str,
) -> Response[OrderUpdateResponse200]:
    """Update Order

    Args:
        order_number (str):
        api_key (str):
        body (OrderUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[OrderUpdateResponse200]
    """

    kwargs = _get_kwargs(
        order_number=order_number,
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    order_number: str,
    *,
    client: AuthenticatedClient,
    body: OrderUpdateJsonBody,
    api_key: str,
) -> OrderUpdateResponse200 | None:
    """Update Order

    Args:
        order_number (str):
        api_key (str):
        body (OrderUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        OrderUpdateResponse200
    """

    return (
        await asyncio_detailed(
            order_number=order_number,
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
