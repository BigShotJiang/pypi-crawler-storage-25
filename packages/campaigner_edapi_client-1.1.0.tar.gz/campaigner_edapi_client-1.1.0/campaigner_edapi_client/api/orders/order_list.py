from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.order_list_response_200 import OrderListResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    order_by: str | Unset = UNSET,
    page_number: str | Unset = UNSET,
    page_size: str | Unset = UNSET,
    since: str | Unset = UNSET,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    params: dict[str, Any] = {}

    params["OrderBy"] = order_by

    params["PageNumber"] = page_number

    params["PageSize"] = page_size

    params["Since"] = since

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/Orders",
        "params": params,
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> OrderListResponse200 | None:
    if response.status_code == 200:
        response_200 = OrderListResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[OrderListResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    order_by: str | Unset = UNSET,
    page_number: str | Unset = UNSET,
    page_size: str | Unset = UNSET,
    since: str | Unset = UNSET,
    api_key: str,
) -> Response[OrderListResponse200]:
    """Browse Orders

    Args:
        order_by (str | Unset):
        page_number (str | Unset):
        page_size (str | Unset):
        since (str | Unset):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[OrderListResponse200]
    """

    kwargs = _get_kwargs(
        order_by=order_by,
        page_number=page_number,
        page_size=page_size,
        since=since,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    order_by: str | Unset = UNSET,
    page_number: str | Unset = UNSET,
    page_size: str | Unset = UNSET,
    since: str | Unset = UNSET,
    api_key: str,
) -> OrderListResponse200 | None:
    """Browse Orders

    Args:
        order_by (str | Unset):
        page_number (str | Unset):
        page_size (str | Unset):
        since (str | Unset):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        OrderListResponse200
    """

    return sync_detailed(
        client=client,
        order_by=order_by,
        page_number=page_number,
        page_size=page_size,
        since=since,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    order_by: str | Unset = UNSET,
    page_number: str | Unset = UNSET,
    page_size: str | Unset = UNSET,
    since: str | Unset = UNSET,
    api_key: str,
) -> Response[OrderListResponse200]:
    """Browse Orders

    Args:
        order_by (str | Unset):
        page_number (str | Unset):
        page_size (str | Unset):
        since (str | Unset):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[OrderListResponse200]
    """

    kwargs = _get_kwargs(
        order_by=order_by,
        page_number=page_number,
        page_size=page_size,
        since=since,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    order_by: str | Unset = UNSET,
    page_number: str | Unset = UNSET,
    page_size: str | Unset = UNSET,
    since: str | Unset = UNSET,
    api_key: str,
) -> OrderListResponse200 | None:
    """Browse Orders

    Args:
        order_by (str | Unset):
        page_number (str | Unset):
        page_size (str | Unset):
        since (str | Unset):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        OrderListResponse200
    """

    return (
        await asyncio_detailed(
            client=client,
            order_by=order_by,
            page_number=page_number,
            page_size=page_size,
            since=since,
            api_key=api_key,
        )
    ).parsed
