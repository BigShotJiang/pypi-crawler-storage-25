from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.order_item_import_json_body import OrderItemImportJsonBody
from ...models.order_item_import_response_200 import OrderItemImportResponse200
from ...models.order_item_import_response_400 import OrderItemImportResponse400
from ...types import Response


def _get_kwargs(
    *,
    body: OrderItemImportJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/Orders/Import",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> OrderItemImportResponse200 | OrderItemImportResponse400 | None:
    if response.status_code == 200:
        response_200 = OrderItemImportResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = OrderItemImportResponse400.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[OrderItemImportResponse200 | OrderItemImportResponse400]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: OrderItemImportJsonBody,
    api_key: str,
) -> Response[OrderItemImportResponse200 | OrderItemImportResponse400]:
    """Import Multiple OrderItems

    Args:
        api_key (str):
        body (OrderItemImportJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[OrderItemImportResponse200 | OrderItemImportResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: OrderItemImportJsonBody,
    api_key: str,
) -> OrderItemImportResponse200 | OrderItemImportResponse400 | None:
    """Import Multiple OrderItems

    Args:
        api_key (str):
        body (OrderItemImportJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        OrderItemImportResponse200 | OrderItemImportResponse400
    """

    return sync_detailed(
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: OrderItemImportJsonBody,
    api_key: str,
) -> Response[OrderItemImportResponse200 | OrderItemImportResponse400]:
    """Import Multiple OrderItems

    Args:
        api_key (str):
        body (OrderItemImportJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[OrderItemImportResponse200 | OrderItemImportResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: OrderItemImportJsonBody,
    api_key: str,
) -> OrderItemImportResponse200 | OrderItemImportResponse400 | None:
    """Import Multiple OrderItems

    Args:
        api_key (str):
        body (OrderItemImportJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        OrderItemImportResponse200 | OrderItemImportResponse400
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
