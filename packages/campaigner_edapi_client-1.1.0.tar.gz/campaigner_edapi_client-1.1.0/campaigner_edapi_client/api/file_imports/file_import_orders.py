from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.file_import_orders_json_body import FileImportOrdersJsonBody
from ...models.file_import_orders_response_201 import FileImportOrdersResponse201
from ...types import Response


def _get_kwargs(
    *,
    body: FileImportOrdersJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/FileImports/Orders",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> FileImportOrdersResponse201 | None:
    if response.status_code == 201:
        response_201 = FileImportOrdersResponse201.from_dict(response.json())

        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[FileImportOrdersResponse201]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: FileImportOrdersJsonBody,
    api_key: str,
) -> Response[FileImportOrdersResponse201]:
    """File Import Orders

    Args:
        api_key (str):
        body (FileImportOrdersJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FileImportOrdersResponse201]
    """

    kwargs = _get_kwargs(
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: FileImportOrdersJsonBody,
    api_key: str,
) -> FileImportOrdersResponse201 | None:
    """File Import Orders

    Args:
        api_key (str):
        body (FileImportOrdersJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FileImportOrdersResponse201
    """

    return sync_detailed(
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: FileImportOrdersJsonBody,
    api_key: str,
) -> Response[FileImportOrdersResponse201]:
    """File Import Orders

    Args:
        api_key (str):
        body (FileImportOrdersJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FileImportOrdersResponse201]
    """

    kwargs = _get_kwargs(
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: FileImportOrdersJsonBody,
    api_key: str,
) -> FileImportOrdersResponse201 | None:
    """File Import Orders

    Args:
        api_key (str):
        body (FileImportOrdersJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FileImportOrdersResponse201
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
