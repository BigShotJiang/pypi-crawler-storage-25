from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.file_import_details_response_200 import FileImportDetailsResponse200
from ...types import Response


def _get_kwargs(
    file_import_id: str,
    *,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/FileImports/{file_import_id}".format(
            file_import_id=quote(str(file_import_id), safe=""),
        ),
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> FileImportDetailsResponse200 | None:
    if response.status_code == 200:
        response_200 = FileImportDetailsResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[FileImportDetailsResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    file_import_id: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> Response[FileImportDetailsResponse200]:
    """File Import Details

    Args:
        file_import_id (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FileImportDetailsResponse200]
    """

    kwargs = _get_kwargs(
        file_import_id=file_import_id,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    file_import_id: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> FileImportDetailsResponse200 | None:
    """File Import Details

    Args:
        file_import_id (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FileImportDetailsResponse200
    """

    return sync_detailed(
        file_import_id=file_import_id,
        client=client,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    file_import_id: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> Response[FileImportDetailsResponse200]:
    """File Import Details

    Args:
        file_import_id (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FileImportDetailsResponse200]
    """

    kwargs = _get_kwargs(
        file_import_id=file_import_id,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    file_import_id: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> FileImportDetailsResponse200 | None:
    """File Import Details

    Args:
        file_import_id (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FileImportDetailsResponse200
    """

    return (
        await asyncio_detailed(
            file_import_id=file_import_id,
            client=client,
            api_key=api_key,
        )
    ).parsed
