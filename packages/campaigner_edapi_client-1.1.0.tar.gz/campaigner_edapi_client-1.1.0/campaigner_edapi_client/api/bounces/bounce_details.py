from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.bounce_details_response_200 import BounceDetailsResponse200
from ...types import Response


def _get_kwargs(
    bounce_id: str,
    *,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/Bounces/{bounce_id}".format(
            bounce_id=quote(str(bounce_id), safe=""),
        ),
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> BounceDetailsResponse200 | None:
    if response.status_code == 200:
        response_200 = BounceDetailsResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[BounceDetailsResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    bounce_id: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> Response[BounceDetailsResponse200]:
    """Get Bounce Details

    Args:
        bounce_id (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BounceDetailsResponse200]
    """

    kwargs = _get_kwargs(
        bounce_id=bounce_id,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    bounce_id: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> BounceDetailsResponse200 | None:
    """Get Bounce Details

    Args:
        bounce_id (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BounceDetailsResponse200
    """

    return sync_detailed(
        bounce_id=bounce_id,
        client=client,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    bounce_id: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> Response[BounceDetailsResponse200]:
    """Get Bounce Details

    Args:
        bounce_id (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BounceDetailsResponse200]
    """

    kwargs = _get_kwargs(
        bounce_id=bounce_id,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    bounce_id: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> BounceDetailsResponse200 | None:
    """Get Bounce Details

    Args:
        bounce_id (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BounceDetailsResponse200
    """

    return (
        await asyncio_detailed(
            bounce_id=bounce_id,
            client=client,
            api_key=api_key,
        )
    ).parsed
