from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.publication_update_json_body import PublicationUpdateJsonBody
from ...models.publication_update_response_200 import PublicationUpdateResponse200
from ...models.publication_update_response_400 import PublicationUpdateResponse400
from ...types import Response


def _get_kwargs(
    publication_id: str,
    *,
    body: PublicationUpdateJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/Publications/{publication_id}".format(
            publication_id=quote(str(publication_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PublicationUpdateResponse200 | PublicationUpdateResponse400 | None:
    if response.status_code == 200:
        response_200 = PublicationUpdateResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = PublicationUpdateResponse400.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PublicationUpdateResponse200 | PublicationUpdateResponse400]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    publication_id: str,
    *,
    client: AuthenticatedClient,
    body: PublicationUpdateJsonBody,
    api_key: str,
) -> Response[PublicationUpdateResponse200 | PublicationUpdateResponse400]:
    """Update Publication

    Args:
        publication_id (str):
        api_key (str):
        body (PublicationUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PublicationUpdateResponse200 | PublicationUpdateResponse400]
    """

    kwargs = _get_kwargs(
        publication_id=publication_id,
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    publication_id: str,
    *,
    client: AuthenticatedClient,
    body: PublicationUpdateJsonBody,
    api_key: str,
) -> PublicationUpdateResponse200 | PublicationUpdateResponse400 | None:
    """Update Publication

    Args:
        publication_id (str):
        api_key (str):
        body (PublicationUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PublicationUpdateResponse200 | PublicationUpdateResponse400
    """

    return sync_detailed(
        publication_id=publication_id,
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    publication_id: str,
    *,
    client: AuthenticatedClient,
    body: PublicationUpdateJsonBody,
    api_key: str,
) -> Response[PublicationUpdateResponse200 | PublicationUpdateResponse400]:
    """Update Publication

    Args:
        publication_id (str):
        api_key (str):
        body (PublicationUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PublicationUpdateResponse200 | PublicationUpdateResponse400]
    """

    kwargs = _get_kwargs(
        publication_id=publication_id,
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    publication_id: str,
    *,
    client: AuthenticatedClient,
    body: PublicationUpdateJsonBody,
    api_key: str,
) -> PublicationUpdateResponse200 | PublicationUpdateResponse400 | None:
    """Update Publication

    Args:
        publication_id (str):
        api_key (str):
        body (PublicationUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PublicationUpdateResponse200 | PublicationUpdateResponse400
    """

    return (
        await asyncio_detailed(
            publication_id=publication_id,
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
