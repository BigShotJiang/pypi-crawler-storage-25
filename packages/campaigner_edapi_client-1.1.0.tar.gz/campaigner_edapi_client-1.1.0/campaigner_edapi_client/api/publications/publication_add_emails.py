from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.publication_add_emails_json_body import PublicationAddEmailsJsonBody
from ...models.publication_add_emails_response_200 import PublicationAddEmailsResponse200
from ...models.publication_add_emails_response_400 import PublicationAddEmailsResponse400
from ...types import Response


def _get_kwargs(
    publication_id: str,
    *,
    body: PublicationAddEmailsJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/Publications/{publication_id}/AddEmails".format(
            publication_id=quote(str(publication_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PublicationAddEmailsResponse200 | PublicationAddEmailsResponse400 | None:
    if response.status_code == 200:
        response_200 = PublicationAddEmailsResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = PublicationAddEmailsResponse400.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PublicationAddEmailsResponse200 | PublicationAddEmailsResponse400]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    publication_id: str,
    *,
    client: AuthenticatedClient,
    body: PublicationAddEmailsJsonBody,
    api_key: str,
) -> Response[PublicationAddEmailsResponse200 | PublicationAddEmailsResponse400]:
    """Add Emails To Publication

    Args:
        publication_id (str):
        api_key (str):
        body (PublicationAddEmailsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PublicationAddEmailsResponse200 | PublicationAddEmailsResponse400]
    """

    kwargs = _get_kwargs(
        publication_id=publication_id,
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    publication_id: str,
    *,
    client: AuthenticatedClient,
    body: PublicationAddEmailsJsonBody,
    api_key: str,
) -> PublicationAddEmailsResponse200 | PublicationAddEmailsResponse400 | None:
    """Add Emails To Publication

    Args:
        publication_id (str):
        api_key (str):
        body (PublicationAddEmailsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PublicationAddEmailsResponse200 | PublicationAddEmailsResponse400
    """

    return sync_detailed(
        publication_id=publication_id,
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    publication_id: str,
    *,
    client: AuthenticatedClient,
    body: PublicationAddEmailsJsonBody,
    api_key: str,
) -> Response[PublicationAddEmailsResponse200 | PublicationAddEmailsResponse400]:
    """Add Emails To Publication

    Args:
        publication_id (str):
        api_key (str):
        body (PublicationAddEmailsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PublicationAddEmailsResponse200 | PublicationAddEmailsResponse400]
    """

    kwargs = _get_kwargs(
        publication_id=publication_id,
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    publication_id: str,
    *,
    client: AuthenticatedClient,
    body: PublicationAddEmailsJsonBody,
    api_key: str,
) -> PublicationAddEmailsResponse200 | PublicationAddEmailsResponse400 | None:
    """Add Emails To Publication

    Args:
        publication_id (str):
        api_key (str):
        body (PublicationAddEmailsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PublicationAddEmailsResponse200 | PublicationAddEmailsResponse400
    """

    return (
        await asyncio_detailed(
            publication_id=publication_id,
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
