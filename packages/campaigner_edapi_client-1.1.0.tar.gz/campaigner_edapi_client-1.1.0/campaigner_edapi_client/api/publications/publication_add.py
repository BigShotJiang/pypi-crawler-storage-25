from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.publication_add_json_body import PublicationAddJsonBody
from ...models.publication_add_response_201 import PublicationAddResponse201
from ...models.publication_add_response_400 import PublicationAddResponse400
from ...types import Response


def _get_kwargs(
    *,
    body: PublicationAddJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/Publications",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PublicationAddResponse201 | PublicationAddResponse400 | None:
    if response.status_code == 201:
        response_201 = PublicationAddResponse201.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = PublicationAddResponse400.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PublicationAddResponse201 | PublicationAddResponse400]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: PublicationAddJsonBody,
    api_key: str,
) -> Response[PublicationAddResponse201 | PublicationAddResponse400]:
    """Add New Publication

    Args:
        api_key (str):
        body (PublicationAddJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PublicationAddResponse201 | PublicationAddResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: PublicationAddJsonBody,
    api_key: str,
) -> PublicationAddResponse201 | PublicationAddResponse400 | None:
    """Add New Publication

    Args:
        api_key (str):
        body (PublicationAddJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PublicationAddResponse201 | PublicationAddResponse400
    """

    return sync_detailed(
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: PublicationAddJsonBody,
    api_key: str,
) -> Response[PublicationAddResponse201 | PublicationAddResponse400]:
    """Add New Publication

    Args:
        api_key (str):
        body (PublicationAddJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PublicationAddResponse201 | PublicationAddResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: PublicationAddJsonBody,
    api_key: str,
) -> PublicationAddResponse201 | PublicationAddResponse400 | None:
    """Add New Publication

    Args:
        api_key (str):
        body (PublicationAddJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PublicationAddResponse201 | PublicationAddResponse400
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
