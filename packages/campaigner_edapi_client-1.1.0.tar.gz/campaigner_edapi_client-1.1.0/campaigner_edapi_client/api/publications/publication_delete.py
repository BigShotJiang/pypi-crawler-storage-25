from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.publication_delete_response_200 import PublicationDeleteResponse200
from ...types import Response


def _get_kwargs(
    publication_id: str,
    *,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/Publications/{publication_id}".format(
            publication_id=quote(str(publication_id), safe=""),
        ),
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PublicationDeleteResponse200 | None:
    if response.status_code == 200:
        response_200 = PublicationDeleteResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PublicationDeleteResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    publication_id: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> Response[PublicationDeleteResponse200]:
    """Delete Publication

    Args:
        publication_id (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PublicationDeleteResponse200]
    """

    kwargs = _get_kwargs(
        publication_id=publication_id,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    publication_id: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> PublicationDeleteResponse200 | None:
    """Delete Publication

    Args:
        publication_id (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PublicationDeleteResponse200
    """

    return sync_detailed(
        publication_id=publication_id,
        client=client,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    publication_id: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> Response[PublicationDeleteResponse200]:
    """Delete Publication

    Args:
        publication_id (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PublicationDeleteResponse200]
    """

    kwargs = _get_kwargs(
        publication_id=publication_id,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    publication_id: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> PublicationDeleteResponse200 | None:
    """Delete Publication

    Args:
        publication_id (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PublicationDeleteResponse200
    """

    return (
        await asyncio_detailed(
            publication_id=publication_id,
            client=client,
            api_key=api_key,
        )
    ).parsed
