from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.private_label_update_json_body import PrivateLabelUpdateJsonBody
from ...models.private_label_update_response_200 import PrivateLabelUpdateResponse200
from ...types import Response


def _get_kwargs(
    account_name: str,
    *,
    body: PrivateLabelUpdateJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/PrivateLabel/{account_name}".format(
            account_name=quote(str(account_name), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PrivateLabelUpdateResponse200 | None:
    if response.status_code == 200:
        response_200 = PrivateLabelUpdateResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PrivateLabelUpdateResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    account_name: str,
    *,
    client: AuthenticatedClient,
    body: PrivateLabelUpdateJsonBody,
    api_key: str,
) -> Response[PrivateLabelUpdateResponse200]:
    """Update Account

    Args:
        account_name (str):
        api_key (str):
        body (PrivateLabelUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PrivateLabelUpdateResponse200]
    """

    kwargs = _get_kwargs(
        account_name=account_name,
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    account_name: str,
    *,
    client: AuthenticatedClient,
    body: PrivateLabelUpdateJsonBody,
    api_key: str,
) -> PrivateLabelUpdateResponse200 | None:
    """Update Account

    Args:
        account_name (str):
        api_key (str):
        body (PrivateLabelUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PrivateLabelUpdateResponse200
    """

    return sync_detailed(
        account_name=account_name,
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    account_name: str,
    *,
    client: AuthenticatedClient,
    body: PrivateLabelUpdateJsonBody,
    api_key: str,
) -> Response[PrivateLabelUpdateResponse200]:
    """Update Account

    Args:
        account_name (str):
        api_key (str):
        body (PrivateLabelUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PrivateLabelUpdateResponse200]
    """

    kwargs = _get_kwargs(
        account_name=account_name,
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    account_name: str,
    *,
    client: AuthenticatedClient,
    body: PrivateLabelUpdateJsonBody,
    api_key: str,
) -> PrivateLabelUpdateResponse200 | None:
    """Update Account

    Args:
        account_name (str):
        api_key (str):
        body (PrivateLabelUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PrivateLabelUpdateResponse200
    """

    return (
        await asyncio_detailed(
            account_name=account_name,
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
