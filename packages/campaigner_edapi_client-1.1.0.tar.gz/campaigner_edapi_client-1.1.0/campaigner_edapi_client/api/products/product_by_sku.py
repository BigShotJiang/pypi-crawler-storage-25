from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.product_by_sku_response_200 import ProductBySKUResponse200
from ...types import Response


def _get_kwargs(
    product_sku: str,
    *,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/Products/SKU/{product_sku}".format(
            product_sku=quote(str(product_sku), safe=""),
        ),
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProductBySKUResponse200 | None:
    if response.status_code == 200:
        response_200 = ProductBySKUResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProductBySKUResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    product_sku: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> Response[ProductBySKUResponse200]:
    """Product Details By SKU

    Args:
        product_sku (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProductBySKUResponse200]
    """

    kwargs = _get_kwargs(
        product_sku=product_sku,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    product_sku: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> ProductBySKUResponse200 | None:
    """Product Details By SKU

    Args:
        product_sku (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProductBySKUResponse200
    """

    return sync_detailed(
        product_sku=product_sku,
        client=client,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    product_sku: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> Response[ProductBySKUResponse200]:
    """Product Details By SKU

    Args:
        product_sku (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProductBySKUResponse200]
    """

    kwargs = _get_kwargs(
        product_sku=product_sku,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    product_sku: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> ProductBySKUResponse200 | None:
    """Product Details By SKU

    Args:
        product_sku (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProductBySKUResponse200
    """

    return (
        await asyncio_detailed(
            product_sku=product_sku,
            client=client,
            api_key=api_key,
        )
    ).parsed
