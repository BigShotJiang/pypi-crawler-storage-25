from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.product_add_to_categories_json_body import ProductAddToCategoriesJsonBody
from ...models.product_add_to_categories_response_200 import ProductAddToCategoriesResponse200
from ...types import Response


def _get_kwargs(
    product_id: str,
    *,
    body: ProductAddToCategoriesJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/Products/{product_id}/AddToCategories".format(
            product_id=quote(str(product_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProductAddToCategoriesResponse200 | None:
    if response.status_code == 200:
        response_200 = ProductAddToCategoriesResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProductAddToCategoriesResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    product_id: str,
    *,
    client: AuthenticatedClient,
    body: ProductAddToCategoriesJsonBody,
    api_key: str,
) -> Response[ProductAddToCategoriesResponse200]:
    """Add To Categories

    Args:
        product_id (str):
        api_key (str):
        body (ProductAddToCategoriesJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProductAddToCategoriesResponse200]
    """

    kwargs = _get_kwargs(
        product_id=product_id,
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    product_id: str,
    *,
    client: AuthenticatedClient,
    body: ProductAddToCategoriesJsonBody,
    api_key: str,
) -> ProductAddToCategoriesResponse200 | None:
    """Add To Categories

    Args:
        product_id (str):
        api_key (str):
        body (ProductAddToCategoriesJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProductAddToCategoriesResponse200
    """

    return sync_detailed(
        product_id=product_id,
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    product_id: str,
    *,
    client: AuthenticatedClient,
    body: ProductAddToCategoriesJsonBody,
    api_key: str,
) -> Response[ProductAddToCategoriesResponse200]:
    """Add To Categories

    Args:
        product_id (str):
        api_key (str):
        body (ProductAddToCategoriesJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProductAddToCategoriesResponse200]
    """

    kwargs = _get_kwargs(
        product_id=product_id,
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    product_id: str,
    *,
    client: AuthenticatedClient,
    body: ProductAddToCategoriesJsonBody,
    api_key: str,
) -> ProductAddToCategoriesResponse200 | None:
    """Add To Categories

    Args:
        product_id (str):
        api_key (str):
        body (ProductAddToCategoriesJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProductAddToCategoriesResponse200
    """

    return (
        await asyncio_detailed(
            product_id=product_id,
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
