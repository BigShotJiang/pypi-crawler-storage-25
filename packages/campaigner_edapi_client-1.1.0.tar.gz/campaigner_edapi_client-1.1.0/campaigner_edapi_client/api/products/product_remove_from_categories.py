from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.product_remove_from_categories_json_body import ProductRemoveFromCategoriesJsonBody
from ...models.product_remove_from_categories_response_200 import ProductRemoveFromCategoriesResponse200
from ...types import Response


def _get_kwargs(
    product_id: str,
    *,
    body: ProductRemoveFromCategoriesJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/Products/{product_id}/RemoveFromCategories".format(
            product_id=quote(str(product_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProductRemoveFromCategoriesResponse200 | None:
    if response.status_code == 200:
        response_200 = ProductRemoveFromCategoriesResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProductRemoveFromCategoriesResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    product_id: str,
    *,
    client: AuthenticatedClient,
    body: ProductRemoveFromCategoriesJsonBody,
    api_key: str,
) -> Response[ProductRemoveFromCategoriesResponse200]:
    """Remove From Categories

    Args:
        product_id (str):
        api_key (str):
        body (ProductRemoveFromCategoriesJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProductRemoveFromCategoriesResponse200]
    """

    kwargs = _get_kwargs(
        product_id=product_id,
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    product_id: str,
    *,
    client: AuthenticatedClient,
    body: ProductRemoveFromCategoriesJsonBody,
    api_key: str,
) -> ProductRemoveFromCategoriesResponse200 | None:
    """Remove From Categories

    Args:
        product_id (str):
        api_key (str):
        body (ProductRemoveFromCategoriesJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProductRemoveFromCategoriesResponse200
    """

    return sync_detailed(
        product_id=product_id,
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    product_id: str,
    *,
    client: AuthenticatedClient,
    body: ProductRemoveFromCategoriesJsonBody,
    api_key: str,
) -> Response[ProductRemoveFromCategoriesResponse200]:
    """Remove From Categories

    Args:
        product_id (str):
        api_key (str):
        body (ProductRemoveFromCategoriesJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProductRemoveFromCategoriesResponse200]
    """

    kwargs = _get_kwargs(
        product_id=product_id,
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    product_id: str,
    *,
    client: AuthenticatedClient,
    body: ProductRemoveFromCategoriesJsonBody,
    api_key: str,
) -> ProductRemoveFromCategoriesResponse200 | None:
    """Remove From Categories

    Args:
        product_id (str):
        api_key (str):
        body (ProductRemoveFromCategoriesJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProductRemoveFromCategoriesResponse200
    """

    return (
        await asyncio_detailed(
            product_id=product_id,
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
