from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.source_add_json_body import SourceAddJsonBody
from ...models.source_add_response_201 import SourceAddResponse201
from ...models.source_add_response_400 import SourceAddResponse400
from ...types import Response


def _get_kwargs(
    *,
    body: SourceAddJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/Sources",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> SourceAddResponse201 | SourceAddResponse400 | None:
    if response.status_code == 201:
        response_201 = SourceAddResponse201.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = SourceAddResponse400.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[SourceAddResponse201 | SourceAddResponse400]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: SourceAddJsonBody,
    api_key: str,
) -> Response[SourceAddResponse201 | SourceAddResponse400]:
    """Add New Source

    Args:
        api_key (str):
        body (SourceAddJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SourceAddResponse201 | SourceAddResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: SourceAddJsonBody,
    api_key: str,
) -> SourceAddResponse201 | SourceAddResponse400 | None:
    """Add New Source

    Args:
        api_key (str):
        body (SourceAddJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SourceAddResponse201 | SourceAddResponse400
    """

    return sync_detailed(
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: SourceAddJsonBody,
    api_key: str,
) -> Response[SourceAddResponse201 | SourceAddResponse400]:
    """Add New Source

    Args:
        api_key (str):
        body (SourceAddJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SourceAddResponse201 | SourceAddResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: SourceAddJsonBody,
    api_key: str,
) -> SourceAddResponse201 | SourceAddResponse400 | None:
    """Add New Source

    Args:
        api_key (str):
        body (SourceAddJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SourceAddResponse201 | SourceAddResponse400
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
