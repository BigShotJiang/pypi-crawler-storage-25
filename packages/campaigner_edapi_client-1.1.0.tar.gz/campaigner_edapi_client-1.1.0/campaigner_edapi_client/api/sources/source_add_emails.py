from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.source_add_emails_json_body import SourceAddEmailsJsonBody
from ...models.source_add_emails_response_200 import SourceAddEmailsResponse200
from ...models.source_add_emails_response_400 import SourceAddEmailsResponse400
from ...types import Response


def _get_kwargs(
    source_id: str,
    *,
    body: SourceAddEmailsJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/Sources/{source_id}/AddEmails".format(
            source_id=quote(str(source_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> SourceAddEmailsResponse200 | SourceAddEmailsResponse400 | None:
    if response.status_code == 200:
        response_200 = SourceAddEmailsResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = SourceAddEmailsResponse400.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[SourceAddEmailsResponse200 | SourceAddEmailsResponse400]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    source_id: str,
    *,
    client: AuthenticatedClient,
    body: SourceAddEmailsJsonBody,
    api_key: str,
) -> Response[SourceAddEmailsResponse200 | SourceAddEmailsResponse400]:
    """Add Emails To Source

    Args:
        source_id (str):
        api_key (str):
        body (SourceAddEmailsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SourceAddEmailsResponse200 | SourceAddEmailsResponse400]
    """

    kwargs = _get_kwargs(
        source_id=source_id,
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    source_id: str,
    *,
    client: AuthenticatedClient,
    body: SourceAddEmailsJsonBody,
    api_key: str,
) -> SourceAddEmailsResponse200 | SourceAddEmailsResponse400 | None:
    """Add Emails To Source

    Args:
        source_id (str):
        api_key (str):
        body (SourceAddEmailsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SourceAddEmailsResponse200 | SourceAddEmailsResponse400
    """

    return sync_detailed(
        source_id=source_id,
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    source_id: str,
    *,
    client: AuthenticatedClient,
    body: SourceAddEmailsJsonBody,
    api_key: str,
) -> Response[SourceAddEmailsResponse200 | SourceAddEmailsResponse400]:
    """Add Emails To Source

    Args:
        source_id (str):
        api_key (str):
        body (SourceAddEmailsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SourceAddEmailsResponse200 | SourceAddEmailsResponse400]
    """

    kwargs = _get_kwargs(
        source_id=source_id,
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    source_id: str,
    *,
    client: AuthenticatedClient,
    body: SourceAddEmailsJsonBody,
    api_key: str,
) -> SourceAddEmailsResponse200 | SourceAddEmailsResponse400 | None:
    """Add Emails To Source

    Args:
        source_id (str):
        api_key (str):
        body (SourceAddEmailsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SourceAddEmailsResponse200 | SourceAddEmailsResponse400
    """

    return (
        await asyncio_detailed(
            source_id=source_id,
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
