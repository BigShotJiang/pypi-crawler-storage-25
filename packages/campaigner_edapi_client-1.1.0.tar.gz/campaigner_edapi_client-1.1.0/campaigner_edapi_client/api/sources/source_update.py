from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.source_update_json_body import SourceUpdateJsonBody
from ...models.source_update_response_200 import SourceUpdateResponse200
from ...types import Response


def _get_kwargs(
    source_id: str,
    *,
    body: SourceUpdateJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/Sources/{source_id}".format(
            source_id=quote(str(source_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> SourceUpdateResponse200 | None:
    if response.status_code == 200:
        response_200 = SourceUpdateResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[SourceUpdateResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    source_id: str,
    *,
    client: AuthenticatedClient,
    body: SourceUpdateJsonBody,
    api_key: str,
) -> Response[SourceUpdateResponse200]:
    """Update Source

    Args:
        source_id (str):
        api_key (str):
        body (SourceUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SourceUpdateResponse200]
    """

    kwargs = _get_kwargs(
        source_id=source_id,
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    source_id: str,
    *,
    client: AuthenticatedClient,
    body: SourceUpdateJsonBody,
    api_key: str,
) -> SourceUpdateResponse200 | None:
    """Update Source

    Args:
        source_id (str):
        api_key (str):
        body (SourceUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SourceUpdateResponse200
    """

    return sync_detailed(
        source_id=source_id,
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    source_id: str,
    *,
    client: AuthenticatedClient,
    body: SourceUpdateJsonBody,
    api_key: str,
) -> Response[SourceUpdateResponse200]:
    """Update Source

    Args:
        source_id (str):
        api_key (str):
        body (SourceUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SourceUpdateResponse200]
    """

    kwargs = _get_kwargs(
        source_id=source_id,
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    source_id: str,
    *,
    client: AuthenticatedClient,
    body: SourceUpdateJsonBody,
    api_key: str,
) -> SourceUpdateResponse200 | None:
    """Update Source

    Args:
        source_id (str):
        api_key (str):
        body (SourceUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SourceUpdateResponse200
    """

    return (
        await asyncio_detailed(
            source_id=source_id,
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
