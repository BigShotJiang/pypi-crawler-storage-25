from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.import_update_subscribers_json_body import ImportUpdateSubscribersJsonBody
from ...models.import_update_subscribers_response_200 import ImportUpdateSubscribersResponse200
from ...models.import_update_subscribers_response_400 import ImportUpdateSubscribersResponse400
from ...types import Response


def _get_kwargs(
    *,
    body: ImportUpdateSubscribersJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/Import/Subscribers",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ImportUpdateSubscribersResponse200 | ImportUpdateSubscribersResponse400 | None:
    if response.status_code == 200:
        response_200 = ImportUpdateSubscribersResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ImportUpdateSubscribersResponse400.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ImportUpdateSubscribersResponse200 | ImportUpdateSubscribersResponse400]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: ImportUpdateSubscribersJsonBody,
    api_key: str,
) -> Response[ImportUpdateSubscribersResponse200 | ImportUpdateSubscribersResponse400]:
    """Update Multiple Subscribers

    Args:
        api_key (str):
        body (ImportUpdateSubscribersJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ImportUpdateSubscribersResponse200 | ImportUpdateSubscribersResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: ImportUpdateSubscribersJsonBody,
    api_key: str,
) -> ImportUpdateSubscribersResponse200 | ImportUpdateSubscribersResponse400 | None:
    """Update Multiple Subscribers

    Args:
        api_key (str):
        body (ImportUpdateSubscribersJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ImportUpdateSubscribersResponse200 | ImportUpdateSubscribersResponse400
    """

    return sync_detailed(
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: ImportUpdateSubscribersJsonBody,
    api_key: str,
) -> Response[ImportUpdateSubscribersResponse200 | ImportUpdateSubscribersResponse400]:
    """Update Multiple Subscribers

    Args:
        api_key (str):
        body (ImportUpdateSubscribersJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ImportUpdateSubscribersResponse200 | ImportUpdateSubscribersResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: ImportUpdateSubscribersJsonBody,
    api_key: str,
) -> ImportUpdateSubscribersResponse200 | ImportUpdateSubscribersResponse400 | None:
    """Update Multiple Subscribers

    Args:
        api_key (str):
        body (ImportUpdateSubscribersJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ImportUpdateSubscribersResponse200 | ImportUpdateSubscribersResponse400
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
