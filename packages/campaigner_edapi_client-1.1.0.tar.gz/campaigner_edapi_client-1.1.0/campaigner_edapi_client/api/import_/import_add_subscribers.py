from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.import_add_subscribers_json_body import ImportAddSubscribersJsonBody
from ...models.import_add_subscribers_response_200 import ImportAddSubscribersResponse200
from ...models.import_add_subscribers_response_400 import ImportAddSubscribersResponse400
from ...types import Response


def _get_kwargs(
    *,
    body: ImportAddSubscribersJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/Import/Subscribers",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ImportAddSubscribersResponse200 | ImportAddSubscribersResponse400 | None:
    if response.status_code == 200:
        response_200 = ImportAddSubscribersResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ImportAddSubscribersResponse400.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ImportAddSubscribersResponse200 | ImportAddSubscribersResponse400]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: ImportAddSubscribersJsonBody,
    api_key: str,
) -> Response[ImportAddSubscribersResponse200 | ImportAddSubscribersResponse400]:
    """Create Multiple Subscribers

    Args:
        api_key (str):
        body (ImportAddSubscribersJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ImportAddSubscribersResponse200 | ImportAddSubscribersResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: ImportAddSubscribersJsonBody,
    api_key: str,
) -> ImportAddSubscribersResponse200 | ImportAddSubscribersResponse400 | None:
    """Create Multiple Subscribers

    Args:
        api_key (str):
        body (ImportAddSubscribersJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ImportAddSubscribersResponse200 | ImportAddSubscribersResponse400
    """

    return sync_detailed(
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: ImportAddSubscribersJsonBody,
    api_key: str,
) -> Response[ImportAddSubscribersResponse200 | ImportAddSubscribersResponse400]:
    """Create Multiple Subscribers

    Args:
        api_key (str):
        body (ImportAddSubscribersJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ImportAddSubscribersResponse200 | ImportAddSubscribersResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: ImportAddSubscribersJsonBody,
    api_key: str,
) -> ImportAddSubscribersResponse200 | ImportAddSubscribersResponse400 | None:
    """Create Multiple Subscribers

    Args:
        api_key (str):
        body (ImportAddSubscribersJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ImportAddSubscribersResponse200 | ImportAddSubscribersResponse400
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
