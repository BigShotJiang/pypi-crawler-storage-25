from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.import_removes_json_body import ImportRemovesJsonBody
from ...models.import_removes_response_200 import ImportRemovesResponse200
from ...models.import_removes_response_400 import ImportRemovesResponse400
from ...types import Response


def _get_kwargs(
    *,
    body: ImportRemovesJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/Import/Removes",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ImportRemovesResponse200 | ImportRemovesResponse400 | None:
    if response.status_code == 200:
        response_200 = ImportRemovesResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ImportRemovesResponse400.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ImportRemovesResponse200 | ImportRemovesResponse400]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: ImportRemovesJsonBody,
    api_key: str,
) -> Response[ImportRemovesResponse200 | ImportRemovesResponse400]:
    """Remove Multiple Subscribers

    Args:
        api_key (str):
        body (ImportRemovesJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ImportRemovesResponse200 | ImportRemovesResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: ImportRemovesJsonBody,
    api_key: str,
) -> ImportRemovesResponse200 | ImportRemovesResponse400 | None:
    """Remove Multiple Subscribers

    Args:
        api_key (str):
        body (ImportRemovesJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ImportRemovesResponse200 | ImportRemovesResponse400
    """

    return sync_detailed(
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: ImportRemovesJsonBody,
    api_key: str,
) -> Response[ImportRemovesResponse200 | ImportRemovesResponse400]:
    """Remove Multiple Subscribers

    Args:
        api_key (str):
        body (ImportRemovesJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ImportRemovesResponse200 | ImportRemovesResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: ImportRemovesJsonBody,
    api_key: str,
) -> ImportRemovesResponse200 | ImportRemovesResponse400 | None:
    """Remove Multiple Subscribers

    Args:
        api_key (str):
        body (ImportRemovesJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ImportRemovesResponse200 | ImportRemovesResponse400
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
