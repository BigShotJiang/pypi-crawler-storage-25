from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.category_products_response_200 import CategoryProductsResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    category_id: str,
    *,
    order_by: str | Unset = UNSET,
    page_number: str | Unset = UNSET,
    page_size: str | Unset = UNSET,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    params: dict[str, Any] = {}

    params["OrderBy"] = order_by

    params["PageNumber"] = page_number

    params["PageSize"] = page_size

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/ProductCategories/{category_id}/Products".format(
            category_id=quote(str(category_id), safe=""),
        ),
        "params": params,
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CategoryProductsResponse200 | None:
    if response.status_code == 200:
        response_200 = CategoryProductsResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CategoryProductsResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    category_id: str,
    *,
    client: AuthenticatedClient,
    order_by: str | Unset = UNSET,
    page_number: str | Unset = UNSET,
    page_size: str | Unset = UNSET,
    api_key: str,
) -> Response[CategoryProductsResponse200]:
    """Browse Category Products

    Args:
        category_id (str):
        order_by (str | Unset):
        page_number (str | Unset):
        page_size (str | Unset):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CategoryProductsResponse200]
    """

    kwargs = _get_kwargs(
        category_id=category_id,
        order_by=order_by,
        page_number=page_number,
        page_size=page_size,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    category_id: str,
    *,
    client: AuthenticatedClient,
    order_by: str | Unset = UNSET,
    page_number: str | Unset = UNSET,
    page_size: str | Unset = UNSET,
    api_key: str,
) -> CategoryProductsResponse200 | None:
    """Browse Category Products

    Args:
        category_id (str):
        order_by (str | Unset):
        page_number (str | Unset):
        page_size (str | Unset):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CategoryProductsResponse200
    """

    return sync_detailed(
        category_id=category_id,
        client=client,
        order_by=order_by,
        page_number=page_number,
        page_size=page_size,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    category_id: str,
    *,
    client: AuthenticatedClient,
    order_by: str | Unset = UNSET,
    page_number: str | Unset = UNSET,
    page_size: str | Unset = UNSET,
    api_key: str,
) -> Response[CategoryProductsResponse200]:
    """Browse Category Products

    Args:
        category_id (str):
        order_by (str | Unset):
        page_number (str | Unset):
        page_size (str | Unset):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CategoryProductsResponse200]
    """

    kwargs = _get_kwargs(
        category_id=category_id,
        order_by=order_by,
        page_number=page_number,
        page_size=page_size,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    category_id: str,
    *,
    client: AuthenticatedClient,
    order_by: str | Unset = UNSET,
    page_number: str | Unset = UNSET,
    page_size: str | Unset = UNSET,
    api_key: str,
) -> CategoryProductsResponse200 | None:
    """Browse Category Products

    Args:
        category_id (str):
        order_by (str | Unset):
        page_number (str | Unset):
        page_size (str | Unset):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CategoryProductsResponse200
    """

    return (
        await asyncio_detailed(
            category_id=category_id,
            client=client,
            order_by=order_by,
            page_number=page_number,
            page_size=page_size,
            api_key=api_key,
        )
    ).parsed
