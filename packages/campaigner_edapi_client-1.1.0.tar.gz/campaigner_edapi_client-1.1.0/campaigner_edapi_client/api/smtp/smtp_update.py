from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.smtp_update_json_body import SMTPUpdateJsonBody
from ...models.smtp_update_response_200 import SMTPUpdateResponse200
from ...types import Response


def _get_kwargs(
    smtp_user_name: str,
    *,
    body: SMTPUpdateJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/SMTP/{smtp_user_name}".format(
            smtp_user_name=quote(str(smtp_user_name), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> SMTPUpdateResponse200 | None:
    if response.status_code == 200:
        response_200 = SMTPUpdateResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[SMTPUpdateResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    smtp_user_name: str,
    *,
    client: AuthenticatedClient,
    body: SMTPUpdateJsonBody,
    api_key: str,
) -> Response[SMTPUpdateResponse200]:
    """Update Login

    Args:
        smtp_user_name (str):
        api_key (str):
        body (SMTPUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SMTPUpdateResponse200]
    """

    kwargs = _get_kwargs(
        smtp_user_name=smtp_user_name,
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    smtp_user_name: str,
    *,
    client: AuthenticatedClient,
    body: SMTPUpdateJsonBody,
    api_key: str,
) -> SMTPUpdateResponse200 | None:
    """Update Login

    Args:
        smtp_user_name (str):
        api_key (str):
        body (SMTPUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SMTPUpdateResponse200
    """

    return sync_detailed(
        smtp_user_name=smtp_user_name,
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    smtp_user_name: str,
    *,
    client: AuthenticatedClient,
    body: SMTPUpdateJsonBody,
    api_key: str,
) -> Response[SMTPUpdateResponse200]:
    """Update Login

    Args:
        smtp_user_name (str):
        api_key (str):
        body (SMTPUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SMTPUpdateResponse200]
    """

    kwargs = _get_kwargs(
        smtp_user_name=smtp_user_name,
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    smtp_user_name: str,
    *,
    client: AuthenticatedClient,
    body: SMTPUpdateJsonBody,
    api_key: str,
) -> SMTPUpdateResponse200 | None:
    """Update Login

    Args:
        smtp_user_name (str):
        api_key (str):
        body (SMTPUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SMTPUpdateResponse200
    """

    return (
        await asyncio_detailed(
            smtp_user_name=smtp_user_name,
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
