from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.subscriber_details_response_200 import SubscriberDetailsResponse200
from ...models.subscriber_details_response_400 import SubscriberDetailsResponse400
from ...types import Response


def _get_kwargs(
    email: str,
    *,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/Subscribers/{email}".format(
            email=quote(str(email), safe=""),
        ),
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> SubscriberDetailsResponse200 | SubscriberDetailsResponse400 | None:
    if response.status_code == 200:
        response_200 = SubscriberDetailsResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = SubscriberDetailsResponse400.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[SubscriberDetailsResponse200 | SubscriberDetailsResponse400]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    email: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> Response[SubscriberDetailsResponse200 | SubscriberDetailsResponse400]:
    """Get Subscriber Details

    Args:
        email (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SubscriberDetailsResponse200 | SubscriberDetailsResponse400]
    """

    kwargs = _get_kwargs(
        email=email,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    email: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> SubscriberDetailsResponse200 | SubscriberDetailsResponse400 | None:
    """Get Subscriber Details

    Args:
        email (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SubscriberDetailsResponse200 | SubscriberDetailsResponse400
    """

    return sync_detailed(
        email=email,
        client=client,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    email: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> Response[SubscriberDetailsResponse200 | SubscriberDetailsResponse400]:
    """Get Subscriber Details

    Args:
        email (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SubscriberDetailsResponse200 | SubscriberDetailsResponse400]
    """

    kwargs = _get_kwargs(
        email=email,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    email: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> SubscriberDetailsResponse200 | SubscriberDetailsResponse400 | None:
    """Get Subscriber Details

    Args:
        email (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SubscriberDetailsResponse200 | SubscriberDetailsResponse400
    """

    return (
        await asyncio_detailed(
            email=email,
            client=client,
            api_key=api_key,
        )
    ).parsed
