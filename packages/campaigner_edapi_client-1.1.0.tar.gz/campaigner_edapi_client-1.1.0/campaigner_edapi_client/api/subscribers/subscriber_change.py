from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.subscriber_change_json_body import SubscriberChangeJsonBody
from ...models.subscriber_change_response_200 import SubscriberChangeResponse200
from ...types import Response


def _get_kwargs(
    email: str,
    *,
    body: SubscriberChangeJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/Subscribers/{email}/ChangeEmail".format(
            email=quote(str(email), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> SubscriberChangeResponse200 | None:
    if response.status_code == 200:
        response_200 = SubscriberChangeResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[SubscriberChangeResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    email: str,
    *,
    client: AuthenticatedClient,
    body: SubscriberChangeJsonBody,
    api_key: str,
) -> Response[SubscriberChangeResponse200]:
    """Change Email Address

    Args:
        email (str):
        api_key (str):
        body (SubscriberChangeJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SubscriberChangeResponse200]
    """

    kwargs = _get_kwargs(
        email=email,
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    email: str,
    *,
    client: AuthenticatedClient,
    body: SubscriberChangeJsonBody,
    api_key: str,
) -> SubscriberChangeResponse200 | None:
    """Change Email Address

    Args:
        email (str):
        api_key (str):
        body (SubscriberChangeJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SubscriberChangeResponse200
    """

    return sync_detailed(
        email=email,
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    email: str,
    *,
    client: AuthenticatedClient,
    body: SubscriberChangeJsonBody,
    api_key: str,
) -> Response[SubscriberChangeResponse200]:
    """Change Email Address

    Args:
        email (str):
        api_key (str):
        body (SubscriberChangeJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SubscriberChangeResponse200]
    """

    kwargs = _get_kwargs(
        email=email,
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    email: str,
    *,
    client: AuthenticatedClient,
    body: SubscriberChangeJsonBody,
    api_key: str,
) -> SubscriberChangeResponse200 | None:
    """Change Email Address

    Args:
        email (str):
        api_key (str):
        body (SubscriberChangeJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SubscriberChangeResponse200
    """

    return (
        await asyncio_detailed(
            email=email,
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
