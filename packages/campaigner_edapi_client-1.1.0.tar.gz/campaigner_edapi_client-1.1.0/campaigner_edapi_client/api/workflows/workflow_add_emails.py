from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.workflow_add_emails_json_body import WorkflowAddEmailsJsonBody
from ...models.workflow_add_emails_response_200 import WorkflowAddEmailsResponse200
from ...types import Response


def _get_kwargs(
    workflow_id: str,
    *,
    body: WorkflowAddEmailsJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/Workflows/{workflow_id}/AddEmails".format(
            workflow_id=quote(str(workflow_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> WorkflowAddEmailsResponse200 | None:
    if response.status_code == 200:
        response_200 = WorkflowAddEmailsResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[WorkflowAddEmailsResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workflow_id: str,
    *,
    client: AuthenticatedClient,
    body: WorkflowAddEmailsJsonBody,
    api_key: str,
) -> Response[WorkflowAddEmailsResponse200]:
    """Add Emails

    Args:
        workflow_id (str):
        api_key (str):
        body (WorkflowAddEmailsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[WorkflowAddEmailsResponse200]
    """

    kwargs = _get_kwargs(
        workflow_id=workflow_id,
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workflow_id: str,
    *,
    client: AuthenticatedClient,
    body: WorkflowAddEmailsJsonBody,
    api_key: str,
) -> WorkflowAddEmailsResponse200 | None:
    """Add Emails

    Args:
        workflow_id (str):
        api_key (str):
        body (WorkflowAddEmailsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        WorkflowAddEmailsResponse200
    """

    return sync_detailed(
        workflow_id=workflow_id,
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    workflow_id: str,
    *,
    client: AuthenticatedClient,
    body: WorkflowAddEmailsJsonBody,
    api_key: str,
) -> Response[WorkflowAddEmailsResponse200]:
    """Add Emails

    Args:
        workflow_id (str):
        api_key (str):
        body (WorkflowAddEmailsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[WorkflowAddEmailsResponse200]
    """

    kwargs = _get_kwargs(
        workflow_id=workflow_id,
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workflow_id: str,
    *,
    client: AuthenticatedClient,
    body: WorkflowAddEmailsJsonBody,
    api_key: str,
) -> WorkflowAddEmailsResponse200 | None:
    """Add Emails

    Args:
        workflow_id (str):
        api_key (str):
        body (WorkflowAddEmailsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        WorkflowAddEmailsResponse200
    """

    return (
        await asyncio_detailed(
            workflow_id=workflow_id,
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
