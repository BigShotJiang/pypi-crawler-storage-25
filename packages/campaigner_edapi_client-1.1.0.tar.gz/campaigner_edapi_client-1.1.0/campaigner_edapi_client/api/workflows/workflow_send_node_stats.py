from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.workflow_send_node_stats_response_200 import WorkflowSendNodeStatsResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workflow_id: str,
    send_node_id: str,
    *,
    end_date: str | Unset = UNSET,
    start_date: str | Unset = UNSET,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    params: dict[str, Any] = {}

    params["EndDate"] = end_date

    params["StartDate"] = start_date

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/Workflows/{workflow_id}/SendNodes/{send_node_id}/Stats".format(
            workflow_id=quote(str(workflow_id), safe=""),
            send_node_id=quote(str(send_node_id), safe=""),
        ),
        "params": params,
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> WorkflowSendNodeStatsResponse200 | None:
    if response.status_code == 200:
        response_200 = WorkflowSendNodeStatsResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[WorkflowSendNodeStatsResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workflow_id: str,
    send_node_id: str,
    *,
    client: AuthenticatedClient,
    end_date: str | Unset = UNSET,
    start_date: str | Unset = UNSET,
    api_key: str,
) -> Response[WorkflowSendNodeStatsResponse200]:
    """Get Send Node Stats

    Args:
        workflow_id (str):
        send_node_id (str):
        end_date (str | Unset):
        start_date (str | Unset):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[WorkflowSendNodeStatsResponse200]
    """

    kwargs = _get_kwargs(
        workflow_id=workflow_id,
        send_node_id=send_node_id,
        end_date=end_date,
        start_date=start_date,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workflow_id: str,
    send_node_id: str,
    *,
    client: AuthenticatedClient,
    end_date: str | Unset = UNSET,
    start_date: str | Unset = UNSET,
    api_key: str,
) -> WorkflowSendNodeStatsResponse200 | None:
    """Get Send Node Stats

    Args:
        workflow_id (str):
        send_node_id (str):
        end_date (str | Unset):
        start_date (str | Unset):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        WorkflowSendNodeStatsResponse200
    """

    return sync_detailed(
        workflow_id=workflow_id,
        send_node_id=send_node_id,
        client=client,
        end_date=end_date,
        start_date=start_date,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    workflow_id: str,
    send_node_id: str,
    *,
    client: AuthenticatedClient,
    end_date: str | Unset = UNSET,
    start_date: str | Unset = UNSET,
    api_key: str,
) -> Response[WorkflowSendNodeStatsResponse200]:
    """Get Send Node Stats

    Args:
        workflow_id (str):
        send_node_id (str):
        end_date (str | Unset):
        start_date (str | Unset):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[WorkflowSendNodeStatsResponse200]
    """

    kwargs = _get_kwargs(
        workflow_id=workflow_id,
        send_node_id=send_node_id,
        end_date=end_date,
        start_date=start_date,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workflow_id: str,
    send_node_id: str,
    *,
    client: AuthenticatedClient,
    end_date: str | Unset = UNSET,
    start_date: str | Unset = UNSET,
    api_key: str,
) -> WorkflowSendNodeStatsResponse200 | None:
    """Get Send Node Stats

    Args:
        workflow_id (str):
        send_node_id (str):
        end_date (str | Unset):
        start_date (str | Unset):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        WorkflowSendNodeStatsResponse200
    """

    return (
        await asyncio_detailed(
            workflow_id=workflow_id,
            send_node_id=send_node_id,
            client=client,
            end_date=end_date,
            start_date=start_date,
            api_key=api_key,
        )
    ).parsed
