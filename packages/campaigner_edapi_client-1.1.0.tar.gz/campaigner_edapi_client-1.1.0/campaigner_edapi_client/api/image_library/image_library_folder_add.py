from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.image_library_folder_add_response_201 import ImageLibraryFolderAddResponse201
from ...types import UNSET, Response


def _get_kwargs(
    *,
    body: str,
    folder: str,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    params: dict[str, Any] = {}

    params["Folder"] = folder

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/ImageLibrary/Folders",
        "params": params,
    }

    _kwargs["json"] = body

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ImageLibraryFolderAddResponse201 | None:
    if response.status_code == 201:
        response_201 = ImageLibraryFolderAddResponse201.from_dict(response.json())

        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ImageLibraryFolderAddResponse201]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: str,
    folder: str,
    api_key: str,
) -> Response[ImageLibraryFolderAddResponse201]:
    """Add New Folder

    Args:
        folder (str):
        api_key (str):
        body (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ImageLibraryFolderAddResponse201]
    """

    kwargs = _get_kwargs(
        body=body,
        folder=folder,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: str,
    folder: str,
    api_key: str,
) -> ImageLibraryFolderAddResponse201 | None:
    """Add New Folder

    Args:
        folder (str):
        api_key (str):
        body (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ImageLibraryFolderAddResponse201
    """

    return sync_detailed(
        client=client,
        body=body,
        folder=folder,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: str,
    folder: str,
    api_key: str,
) -> Response[ImageLibraryFolderAddResponse201]:
    """Add New Folder

    Args:
        folder (str):
        api_key (str):
        body (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ImageLibraryFolderAddResponse201]
    """

    kwargs = _get_kwargs(
        body=body,
        folder=folder,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: str,
    folder: str,
    api_key: str,
) -> ImageLibraryFolderAddResponse201 | None:
    """Add New Folder

    Args:
        folder (str):
        api_key (str):
        body (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ImageLibraryFolderAddResponse201
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            folder=folder,
            api_key=api_key,
        )
    ).parsed
