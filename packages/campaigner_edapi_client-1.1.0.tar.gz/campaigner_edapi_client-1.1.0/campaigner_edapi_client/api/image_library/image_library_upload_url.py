from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.image_library_upload_url_json_body import ImageLibraryUploadURLJsonBody
from ...models.image_library_upload_url_response_201 import ImageLibraryUploadURLResponse201
from ...types import Response


def _get_kwargs(
    *,
    body: ImageLibraryUploadURLJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/ImageLibrary",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ImageLibraryUploadURLResponse201 | None:
    if response.status_code == 201:
        response_201 = ImageLibraryUploadURLResponse201.from_dict(response.json())

        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ImageLibraryUploadURLResponse201]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: ImageLibraryUploadURLJsonBody,
    api_key: str,
) -> Response[ImageLibraryUploadURLResponse201]:
    """Upload File URL

    Args:
        api_key (str):
        body (ImageLibraryUploadURLJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ImageLibraryUploadURLResponse201]
    """

    kwargs = _get_kwargs(
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: ImageLibraryUploadURLJsonBody,
    api_key: str,
) -> ImageLibraryUploadURLResponse201 | None:
    """Upload File URL

    Args:
        api_key (str):
        body (ImageLibraryUploadURLJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ImageLibraryUploadURLResponse201
    """

    return sync_detailed(
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: ImageLibraryUploadURLJsonBody,
    api_key: str,
) -> Response[ImageLibraryUploadURLResponse201]:
    """Upload File URL

    Args:
        api_key (str):
        body (ImageLibraryUploadURLJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ImageLibraryUploadURLResponse201]
    """

    kwargs = _get_kwargs(
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: ImageLibraryUploadURLJsonBody,
    api_key: str,
) -> ImageLibraryUploadURLResponse201 | None:
    """Upload File URL

    Args:
        api_key (str):
        body (ImageLibraryUploadURLJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ImageLibraryUploadURLResponse201
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
