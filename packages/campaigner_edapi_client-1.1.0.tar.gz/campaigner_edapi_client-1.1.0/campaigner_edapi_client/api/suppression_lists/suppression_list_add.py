from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.suppression_list_add_response_201 import SuppressionListAddResponse201
from ...models.suppression_list_add_response_400 import SuppressionListAddResponse400
from ...types import Response


def _get_kwargs(
    *,
    body: str,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/SuppressionLists",
    }

    _kwargs["json"] = body

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> SuppressionListAddResponse201 | SuppressionListAddResponse400 | None:
    if response.status_code == 201:
        response_201 = SuppressionListAddResponse201.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = SuppressionListAddResponse400.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[SuppressionListAddResponse201 | SuppressionListAddResponse400]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: str,
    api_key: str,
) -> Response[SuppressionListAddResponse201 | SuppressionListAddResponse400]:
    """Add New SuppressionList

    Args:
        api_key (str):
        body (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SuppressionListAddResponse201 | SuppressionListAddResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: str,
    api_key: str,
) -> SuppressionListAddResponse201 | SuppressionListAddResponse400 | None:
    """Add New SuppressionList

    Args:
        api_key (str):
        body (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SuppressionListAddResponse201 | SuppressionListAddResponse400
    """

    return sync_detailed(
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: str,
    api_key: str,
) -> Response[SuppressionListAddResponse201 | SuppressionListAddResponse400]:
    """Add New SuppressionList

    Args:
        api_key (str):
        body (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SuppressionListAddResponse201 | SuppressionListAddResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: str,
    api_key: str,
) -> SuppressionListAddResponse201 | SuppressionListAddResponse400 | None:
    """Add New SuppressionList

    Args:
        api_key (str):
        body (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SuppressionListAddResponse201 | SuppressionListAddResponse400
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
