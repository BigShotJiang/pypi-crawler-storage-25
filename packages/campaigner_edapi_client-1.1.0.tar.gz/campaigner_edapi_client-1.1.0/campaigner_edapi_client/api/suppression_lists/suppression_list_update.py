from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.suppression_list_update_response_200 import SuppressionListUpdateResponse200
from ...models.suppression_list_update_response_400 import SuppressionListUpdateResponse400
from ...types import Response


def _get_kwargs(
    suppression_list_id: str,
    *,
    body: str,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/SuppressionLists/{suppression_list_id}".format(
            suppression_list_id=quote(str(suppression_list_id), safe=""),
        ),
    }

    _kwargs["json"] = body

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> SuppressionListUpdateResponse200 | SuppressionListUpdateResponse400 | None:
    if response.status_code == 200:
        response_200 = SuppressionListUpdateResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = SuppressionListUpdateResponse400.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[SuppressionListUpdateResponse200 | SuppressionListUpdateResponse400]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    suppression_list_id: str,
    *,
    client: AuthenticatedClient,
    body: str,
    api_key: str,
) -> Response[SuppressionListUpdateResponse200 | SuppressionListUpdateResponse400]:
    """Update SuppressionList

    Args:
        suppression_list_id (str):
        api_key (str):
        body (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SuppressionListUpdateResponse200 | SuppressionListUpdateResponse400]
    """

    kwargs = _get_kwargs(
        suppression_list_id=suppression_list_id,
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    suppression_list_id: str,
    *,
    client: AuthenticatedClient,
    body: str,
    api_key: str,
) -> SuppressionListUpdateResponse200 | SuppressionListUpdateResponse400 | None:
    """Update SuppressionList

    Args:
        suppression_list_id (str):
        api_key (str):
        body (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SuppressionListUpdateResponse200 | SuppressionListUpdateResponse400
    """

    return sync_detailed(
        suppression_list_id=suppression_list_id,
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    suppression_list_id: str,
    *,
    client: AuthenticatedClient,
    body: str,
    api_key: str,
) -> Response[SuppressionListUpdateResponse200 | SuppressionListUpdateResponse400]:
    """Update SuppressionList

    Args:
        suppression_list_id (str):
        api_key (str):
        body (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SuppressionListUpdateResponse200 | SuppressionListUpdateResponse400]
    """

    kwargs = _get_kwargs(
        suppression_list_id=suppression_list_id,
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    suppression_list_id: str,
    *,
    client: AuthenticatedClient,
    body: str,
    api_key: str,
) -> SuppressionListUpdateResponse200 | SuppressionListUpdateResponse400 | None:
    """Update SuppressionList

    Args:
        suppression_list_id (str):
        api_key (str):
        body (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SuppressionListUpdateResponse200 | SuppressionListUpdateResponse400
    """

    return (
        await asyncio_detailed(
            suppression_list_id=suppression_list_id,
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
