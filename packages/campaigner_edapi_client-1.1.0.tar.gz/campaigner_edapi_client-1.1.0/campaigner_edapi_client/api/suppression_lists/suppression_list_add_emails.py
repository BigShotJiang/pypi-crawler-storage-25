from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.suppression_list_add_emails_json_body import SuppressionListAddEmailsJsonBody
from ...models.suppression_list_add_emails_response_200 import SuppressionListAddEmailsResponse200
from ...models.suppression_list_add_emails_response_400 import SuppressionListAddEmailsResponse400
from ...types import Response


def _get_kwargs(
    suppression_list_id: str,
    *,
    body: SuppressionListAddEmailsJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/SuppressionLists/{suppression_list_id}/AddEmails".format(
            suppression_list_id=quote(str(suppression_list_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> SuppressionListAddEmailsResponse200 | SuppressionListAddEmailsResponse400 | None:
    if response.status_code == 200:
        response_200 = SuppressionListAddEmailsResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = SuppressionListAddEmailsResponse400.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[SuppressionListAddEmailsResponse200 | SuppressionListAddEmailsResponse400]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    suppression_list_id: str,
    *,
    client: AuthenticatedClient,
    body: SuppressionListAddEmailsJsonBody,
    api_key: str,
) -> Response[SuppressionListAddEmailsResponse200 | SuppressionListAddEmailsResponse400]:
    """Add Emails To SuppressionList

    Args:
        suppression_list_id (str):
        api_key (str):
        body (SuppressionListAddEmailsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SuppressionListAddEmailsResponse200 | SuppressionListAddEmailsResponse400]
    """

    kwargs = _get_kwargs(
        suppression_list_id=suppression_list_id,
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    suppression_list_id: str,
    *,
    client: AuthenticatedClient,
    body: SuppressionListAddEmailsJsonBody,
    api_key: str,
) -> SuppressionListAddEmailsResponse200 | SuppressionListAddEmailsResponse400 | None:
    """Add Emails To SuppressionList

    Args:
        suppression_list_id (str):
        api_key (str):
        body (SuppressionListAddEmailsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SuppressionListAddEmailsResponse200 | SuppressionListAddEmailsResponse400
    """

    return sync_detailed(
        suppression_list_id=suppression_list_id,
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    suppression_list_id: str,
    *,
    client: AuthenticatedClient,
    body: SuppressionListAddEmailsJsonBody,
    api_key: str,
) -> Response[SuppressionListAddEmailsResponse200 | SuppressionListAddEmailsResponse400]:
    """Add Emails To SuppressionList

    Args:
        suppression_list_id (str):
        api_key (str):
        body (SuppressionListAddEmailsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SuppressionListAddEmailsResponse200 | SuppressionListAddEmailsResponse400]
    """

    kwargs = _get_kwargs(
        suppression_list_id=suppression_list_id,
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    suppression_list_id: str,
    *,
    client: AuthenticatedClient,
    body: SuppressionListAddEmailsJsonBody,
    api_key: str,
) -> SuppressionListAddEmailsResponse200 | SuppressionListAddEmailsResponse400 | None:
    """Add Emails To SuppressionList

    Args:
        suppression_list_id (str):
        api_key (str):
        body (SuppressionListAddEmailsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SuppressionListAddEmailsResponse200 | SuppressionListAddEmailsResponse400
    """

    return (
        await asyncio_detailed(
            suppression_list_id=suppression_list_id,
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
