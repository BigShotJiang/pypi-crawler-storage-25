from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.suppression_list_add_domains_json_body import SuppressionListAddDomainsJsonBody
from ...models.suppression_list_add_domains_response_200 import SuppressionListAddDomainsResponse200
from ...models.suppression_list_add_domains_response_400 import SuppressionListAddDomainsResponse400
from ...types import Response


def _get_kwargs(
    suppression_list_id: str,
    *,
    body: SuppressionListAddDomainsJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/SuppressionLists/{suppression_list_id}/AddDomains".format(
            suppression_list_id=quote(str(suppression_list_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> SuppressionListAddDomainsResponse200 | SuppressionListAddDomainsResponse400 | None:
    if response.status_code == 200:
        response_200 = SuppressionListAddDomainsResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = SuppressionListAddDomainsResponse400.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[SuppressionListAddDomainsResponse200 | SuppressionListAddDomainsResponse400]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    suppression_list_id: str,
    *,
    client: AuthenticatedClient,
    body: SuppressionListAddDomainsJsonBody,
    api_key: str,
) -> Response[SuppressionListAddDomainsResponse200 | SuppressionListAddDomainsResponse400]:
    """Add Domains To SuppressionList

    Args:
        suppression_list_id (str):
        api_key (str):
        body (SuppressionListAddDomainsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SuppressionListAddDomainsResponse200 | SuppressionListAddDomainsResponse400]
    """

    kwargs = _get_kwargs(
        suppression_list_id=suppression_list_id,
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    suppression_list_id: str,
    *,
    client: AuthenticatedClient,
    body: SuppressionListAddDomainsJsonBody,
    api_key: str,
) -> SuppressionListAddDomainsResponse200 | SuppressionListAddDomainsResponse400 | None:
    """Add Domains To SuppressionList

    Args:
        suppression_list_id (str):
        api_key (str):
        body (SuppressionListAddDomainsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SuppressionListAddDomainsResponse200 | SuppressionListAddDomainsResponse400
    """

    return sync_detailed(
        suppression_list_id=suppression_list_id,
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    suppression_list_id: str,
    *,
    client: AuthenticatedClient,
    body: SuppressionListAddDomainsJsonBody,
    api_key: str,
) -> Response[SuppressionListAddDomainsResponse200 | SuppressionListAddDomainsResponse400]:
    """Add Domains To SuppressionList

    Args:
        suppression_list_id (str):
        api_key (str):
        body (SuppressionListAddDomainsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SuppressionListAddDomainsResponse200 | SuppressionListAddDomainsResponse400]
    """

    kwargs = _get_kwargs(
        suppression_list_id=suppression_list_id,
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    suppression_list_id: str,
    *,
    client: AuthenticatedClient,
    body: SuppressionListAddDomainsJsonBody,
    api_key: str,
) -> SuppressionListAddDomainsResponse200 | SuppressionListAddDomainsResponse400 | None:
    """Add Domains To SuppressionList

    Args:
        suppression_list_id (str):
        api_key (str):
        body (SuppressionListAddDomainsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SuppressionListAddDomainsResponse200 | SuppressionListAddDomainsResponse400
    """

    return (
        await asyncio_detailed(
            suppression_list_id=suppression_list_id,
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
