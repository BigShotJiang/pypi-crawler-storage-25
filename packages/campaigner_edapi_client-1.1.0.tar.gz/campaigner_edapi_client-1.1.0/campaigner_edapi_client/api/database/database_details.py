from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.database_details_response_200 import DatabaseDetailsResponse200
from ...types import Response


def _get_kwargs(
    column_name: str,
    *,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/Database/{column_name}".format(
            column_name=quote(str(column_name), safe=""),
        ),
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DatabaseDetailsResponse200 | None:
    if response.status_code == 200:
        response_200 = DatabaseDetailsResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DatabaseDetailsResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    column_name: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> Response[DatabaseDetailsResponse200]:
    """Get Column Details

    Args:
        column_name (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DatabaseDetailsResponse200]
    """

    kwargs = _get_kwargs(
        column_name=column_name,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    column_name: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> DatabaseDetailsResponse200 | None:
    """Get Column Details

    Args:
        column_name (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DatabaseDetailsResponse200
    """

    return sync_detailed(
        column_name=column_name,
        client=client,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    column_name: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> Response[DatabaseDetailsResponse200]:
    """Get Column Details

    Args:
        column_name (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DatabaseDetailsResponse200]
    """

    kwargs = _get_kwargs(
        column_name=column_name,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    column_name: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> DatabaseDetailsResponse200 | None:
    """Get Column Details

    Args:
        column_name (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DatabaseDetailsResponse200
    """

    return (
        await asyncio_detailed(
            column_name=column_name,
            client=client,
            api_key=api_key,
        )
    ).parsed
