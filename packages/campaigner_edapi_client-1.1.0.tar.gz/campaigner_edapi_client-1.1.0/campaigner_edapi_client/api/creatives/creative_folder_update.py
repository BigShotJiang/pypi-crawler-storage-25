from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.creative_folder_update_response_200 import CreativeFolderUpdateResponse200
from ...types import Response


def _get_kwargs(
    folder_id: str,
    *,
    body: str,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/Creatives/Folders/{folder_id}".format(
            folder_id=quote(str(folder_id), safe=""),
        ),
    }

    _kwargs["json"] = body

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CreativeFolderUpdateResponse200 | None:
    if response.status_code == 200:
        response_200 = CreativeFolderUpdateResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CreativeFolderUpdateResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    folder_id: str,
    *,
    client: AuthenticatedClient,
    body: str,
    api_key: str,
) -> Response[CreativeFolderUpdateResponse200]:
    """Update Folder

    Args:
        folder_id (str):
        api_key (str):
        body (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreativeFolderUpdateResponse200]
    """

    kwargs = _get_kwargs(
        folder_id=folder_id,
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    folder_id: str,
    *,
    client: AuthenticatedClient,
    body: str,
    api_key: str,
) -> CreativeFolderUpdateResponse200 | None:
    """Update Folder

    Args:
        folder_id (str):
        api_key (str):
        body (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreativeFolderUpdateResponse200
    """

    return sync_detailed(
        folder_id=folder_id,
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    folder_id: str,
    *,
    client: AuthenticatedClient,
    body: str,
    api_key: str,
) -> Response[CreativeFolderUpdateResponse200]:
    """Update Folder

    Args:
        folder_id (str):
        api_key (str):
        body (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreativeFolderUpdateResponse200]
    """

    kwargs = _get_kwargs(
        folder_id=folder_id,
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    folder_id: str,
    *,
    client: AuthenticatedClient,
    body: str,
    api_key: str,
) -> CreativeFolderUpdateResponse200 | None:
    """Update Folder

    Args:
        folder_id (str):
        api_key (str):
        body (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreativeFolderUpdateResponse200
    """

    return (
        await asyncio_detailed(
            folder_id=folder_id,
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
