from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.creative_delete_response_200 import CreativeDeleteResponse200
from ...types import Response


def _get_kwargs(
    creative_id: str,
    *,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/Creatives/{creative_id}".format(
            creative_id=quote(str(creative_id), safe=""),
        ),
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CreativeDeleteResponse200 | None:
    if response.status_code == 200:
        response_200 = CreativeDeleteResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CreativeDeleteResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    creative_id: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> Response[CreativeDeleteResponse200]:
    """Delete Creative

    Args:
        creative_id (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreativeDeleteResponse200]
    """

    kwargs = _get_kwargs(
        creative_id=creative_id,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    creative_id: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> CreativeDeleteResponse200 | None:
    """Delete Creative

    Args:
        creative_id (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreativeDeleteResponse200
    """

    return sync_detailed(
        creative_id=creative_id,
        client=client,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    creative_id: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> Response[CreativeDeleteResponse200]:
    """Delete Creative

    Args:
        creative_id (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreativeDeleteResponse200]
    """

    kwargs = _get_kwargs(
        creative_id=creative_id,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    creative_id: str,
    *,
    client: AuthenticatedClient,
    api_key: str,
) -> CreativeDeleteResponse200 | None:
    """Delete Creative

    Args:
        creative_id (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreativeDeleteResponse200
    """

    return (
        await asyncio_detailed(
            creative_id=creative_id,
            client=client,
            api_key=api_key,
        )
    ).parsed
