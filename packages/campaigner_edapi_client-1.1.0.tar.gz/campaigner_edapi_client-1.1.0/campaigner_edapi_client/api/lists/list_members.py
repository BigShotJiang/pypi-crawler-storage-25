from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_members_response_200 import ListMembersResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    list_id: str,
    *,
    fields: str | Unset = UNSET,
    page_number: str | Unset = UNSET,
    page_size: str | Unset = UNSET,
    since: str | Unset = UNSET,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    params: dict[str, Any] = {}

    params["Fields"] = fields

    params["PageNumber"] = page_number

    params["PageSize"] = page_size

    params["Since"] = since

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/Lists/{list_id}/Members".format(
            list_id=quote(str(list_id), safe=""),
        ),
        "params": params,
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ListMembersResponse200 | None:
    if response.status_code == 200:
        response_200 = ListMembersResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ListMembersResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    list_id: str,
    *,
    client: AuthenticatedClient,
    fields: str | Unset = UNSET,
    page_number: str | Unset = UNSET,
    page_size: str | Unset = UNSET,
    since: str | Unset = UNSET,
    api_key: str,
) -> Response[ListMembersResponse200]:
    """Browse List Members

    Args:
        list_id (str):
        fields (str | Unset):
        page_number (str | Unset):
        page_size (str | Unset):
        since (str | Unset):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListMembersResponse200]
    """

    kwargs = _get_kwargs(
        list_id=list_id,
        fields=fields,
        page_number=page_number,
        page_size=page_size,
        since=since,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    list_id: str,
    *,
    client: AuthenticatedClient,
    fields: str | Unset = UNSET,
    page_number: str | Unset = UNSET,
    page_size: str | Unset = UNSET,
    since: str | Unset = UNSET,
    api_key: str,
) -> ListMembersResponse200 | None:
    """Browse List Members

    Args:
        list_id (str):
        fields (str | Unset):
        page_number (str | Unset):
        page_size (str | Unset):
        since (str | Unset):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListMembersResponse200
    """

    return sync_detailed(
        list_id=list_id,
        client=client,
        fields=fields,
        page_number=page_number,
        page_size=page_size,
        since=since,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    list_id: str,
    *,
    client: AuthenticatedClient,
    fields: str | Unset = UNSET,
    page_number: str | Unset = UNSET,
    page_size: str | Unset = UNSET,
    since: str | Unset = UNSET,
    api_key: str,
) -> Response[ListMembersResponse200]:
    """Browse List Members

    Args:
        list_id (str):
        fields (str | Unset):
        page_number (str | Unset):
        page_size (str | Unset):
        since (str | Unset):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListMembersResponse200]
    """

    kwargs = _get_kwargs(
        list_id=list_id,
        fields=fields,
        page_number=page_number,
        page_size=page_size,
        since=since,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    list_id: str,
    *,
    client: AuthenticatedClient,
    fields: str | Unset = UNSET,
    page_number: str | Unset = UNSET,
    page_size: str | Unset = UNSET,
    since: str | Unset = UNSET,
    api_key: str,
) -> ListMembersResponse200 | None:
    """Browse List Members

    Args:
        list_id (str):
        fields (str | Unset):
        page_number (str | Unset):
        page_size (str | Unset):
        since (str | Unset):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListMembersResponse200
    """

    return (
        await asyncio_detailed(
            list_id=list_id,
            client=client,
            fields=fields,
            page_number=page_number,
            page_size=page_size,
            since=since,
            api_key=api_key,
        )
    ).parsed
