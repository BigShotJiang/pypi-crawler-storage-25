from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_all_members_response_200 import ListAllMembersResponse200
from ...types import Response


def _get_kwargs(
    list_id: str,
    *,
    accept_encoding: str,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["Accept-Encoding"] = accept_encoding

    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/Lists/{list_id}/AllMembers".format(
            list_id=quote(str(list_id), safe=""),
        ),
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ListAllMembersResponse200 | None:
    if response.status_code == 200:
        response_200 = ListAllMembersResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ListAllMembersResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    list_id: str,
    *,
    client: AuthenticatedClient,
    accept_encoding: str,
    api_key: str,
) -> Response[ListAllMembersResponse200]:
    """Get All Members

    Args:
        list_id (str):
        accept_encoding (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListAllMembersResponse200]
    """

    kwargs = _get_kwargs(
        list_id=list_id,
        accept_encoding=accept_encoding,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    list_id: str,
    *,
    client: AuthenticatedClient,
    accept_encoding: str,
    api_key: str,
) -> ListAllMembersResponse200 | None:
    """Get All Members

    Args:
        list_id (str):
        accept_encoding (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListAllMembersResponse200
    """

    return sync_detailed(
        list_id=list_id,
        client=client,
        accept_encoding=accept_encoding,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    list_id: str,
    *,
    client: AuthenticatedClient,
    accept_encoding: str,
    api_key: str,
) -> Response[ListAllMembersResponse200]:
    """Get All Members

    Args:
        list_id (str):
        accept_encoding (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListAllMembersResponse200]
    """

    kwargs = _get_kwargs(
        list_id=list_id,
        accept_encoding=accept_encoding,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    list_id: str,
    *,
    client: AuthenticatedClient,
    accept_encoding: str,
    api_key: str,
) -> ListAllMembersResponse200 | None:
    """Get All Members

    Args:
        list_id (str):
        accept_encoding (str):
        api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListAllMembersResponse200
    """

    return (
        await asyncio_detailed(
            list_id=list_id,
            client=client,
            accept_encoding=accept_encoding,
            api_key=api_key,
        )
    ).parsed
