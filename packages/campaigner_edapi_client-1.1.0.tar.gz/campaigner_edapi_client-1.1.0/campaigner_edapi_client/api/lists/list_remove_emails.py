from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_remove_emails_json_body import ListRemoveEmailsJsonBody
from ...models.list_remove_emails_response_200 import ListRemoveEmailsResponse200
from ...models.list_remove_emails_response_400 import ListRemoveEmailsResponse400
from ...types import Response


def _get_kwargs(
    list_id: str,
    *,
    body: ListRemoveEmailsJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/Lists/{list_id}/RemoveEmails".format(
            list_id=quote(str(list_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ListRemoveEmailsResponse200 | ListRemoveEmailsResponse400 | None:
    if response.status_code == 200:
        response_200 = ListRemoveEmailsResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ListRemoveEmailsResponse400.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ListRemoveEmailsResponse200 | ListRemoveEmailsResponse400]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    list_id: str,
    *,
    client: AuthenticatedClient,
    body: ListRemoveEmailsJsonBody,
    api_key: str,
) -> Response[ListRemoveEmailsResponse200 | ListRemoveEmailsResponse400]:
    """Remove Emails From List

    Args:
        list_id (str):
        api_key (str):
        body (ListRemoveEmailsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListRemoveEmailsResponse200 | ListRemoveEmailsResponse400]
    """

    kwargs = _get_kwargs(
        list_id=list_id,
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    list_id: str,
    *,
    client: AuthenticatedClient,
    body: ListRemoveEmailsJsonBody,
    api_key: str,
) -> ListRemoveEmailsResponse200 | ListRemoveEmailsResponse400 | None:
    """Remove Emails From List

    Args:
        list_id (str):
        api_key (str):
        body (ListRemoveEmailsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListRemoveEmailsResponse200 | ListRemoveEmailsResponse400
    """

    return sync_detailed(
        list_id=list_id,
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    list_id: str,
    *,
    client: AuthenticatedClient,
    body: ListRemoveEmailsJsonBody,
    api_key: str,
) -> Response[ListRemoveEmailsResponse200 | ListRemoveEmailsResponse400]:
    """Remove Emails From List

    Args:
        list_id (str):
        api_key (str):
        body (ListRemoveEmailsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListRemoveEmailsResponse200 | ListRemoveEmailsResponse400]
    """

    kwargs = _get_kwargs(
        list_id=list_id,
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    list_id: str,
    *,
    client: AuthenticatedClient,
    body: ListRemoveEmailsJsonBody,
    api_key: str,
) -> ListRemoveEmailsResponse200 | ListRemoveEmailsResponse400 | None:
    """Remove Emails From List

    Args:
        list_id (str):
        api_key (str):
        body (ListRemoveEmailsJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListRemoveEmailsResponse200 | ListRemoveEmailsResponse400
    """

    return (
        await asyncio_detailed(
            list_id=list_id,
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
