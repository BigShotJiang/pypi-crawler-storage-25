from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_update_json_body import ListUpdateJsonBody
from ...models.list_update_response_200 import ListUpdateResponse200
from ...models.list_update_response_400 import ListUpdateResponse400
from ...types import Response


def _get_kwargs(
    list_id: str,
    *,
    body: ListUpdateJsonBody,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["ApiKey"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/Lists/{list_id}".format(
            list_id=quote(str(list_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ListUpdateResponse200 | ListUpdateResponse400 | None:
    if response.status_code == 200:
        response_200 = ListUpdateResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ListUpdateResponse400.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ListUpdateResponse200 | ListUpdateResponse400]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    list_id: str,
    *,
    client: AuthenticatedClient,
    body: ListUpdateJsonBody,
    api_key: str,
) -> Response[ListUpdateResponse200 | ListUpdateResponse400]:
    """Update List

    Args:
        list_id (str):
        api_key (str):
        body (ListUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListUpdateResponse200 | ListUpdateResponse400]
    """

    kwargs = _get_kwargs(
        list_id=list_id,
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    list_id: str,
    *,
    client: AuthenticatedClient,
    body: ListUpdateJsonBody,
    api_key: str,
) -> ListUpdateResponse200 | ListUpdateResponse400 | None:
    """Update List

    Args:
        list_id (str):
        api_key (str):
        body (ListUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListUpdateResponse200 | ListUpdateResponse400
    """

    return sync_detailed(
        list_id=list_id,
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    list_id: str,
    *,
    client: AuthenticatedClient,
    body: ListUpdateJsonBody,
    api_key: str,
) -> Response[ListUpdateResponse200 | ListUpdateResponse400]:
    """Update List

    Args:
        list_id (str):
        api_key (str):
        body (ListUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListUpdateResponse200 | ListUpdateResponse400]
    """

    kwargs = _get_kwargs(
        list_id=list_id,
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    list_id: str,
    *,
    client: AuthenticatedClient,
    body: ListUpdateJsonBody,
    api_key: str,
) -> ListUpdateResponse200 | ListUpdateResponse400 | None:
    """Update List

    Args:
        list_id (str):
        api_key (str):
        body (ListUpdateJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListUpdateResponse200 | ListUpdateResponse400
    """

    return (
        await asyncio_detailed(
            list_id=list_id,
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
