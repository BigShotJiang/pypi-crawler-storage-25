"""Runtime bootstrap: detect Ollama, probe embed/LLM models, optionally pull.

This module is the friendly front door of ``skygrep``. The first time a user
runs the CLI we want to:

  - Confirm the local Ollama runtime is reachable.
  - Confirm the embedding model the CLI is configured to use is present.
  - Optionally confirm the LLM (used by ``--hyde`` / ``--answer`` / cascade
    escalation) is present.

When a check fails we either:
  - print a single actionable command the user can copy-paste, or
  - run ``ollama pull <model>`` ourselves (with confirm prompt unless
    ``SKYGREP_AUTO_PULL=yes`` is set).

The probes are cheap (one HTTP GET each); we don't gate ``skygrep search`` on
them when the index is already populated and reachable, because that adds
latency to every query. Bootstrap is invoked from ``cli.doctor`` (always),
from ``cli.search_cmd`` only when an actual error needs explaining (e.g.
embed call returned an empty body), and from ``auto_index.ensure_index``
before the first index of a fresh project.
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import sys
import time
from typing import Iterable

import requests

from .config import get_config

logger = logging.getLogger(__name__)

# 0.5.8: only attempt `ollama serve` autostart once per process. Subsequent
# calls just re-probe — they don't try to spawn another server.
_AUTOSTART_ATTEMPTED = False

OLLAMA_INSTALL_HINT = (
    "Ollama is required for local embeddings. Install on macOS:\n"
    "    brew install ollama\n"
    "or follow https://ollama.com/download. After install, start the server:\n"
    "    ollama serve  &"
)


class BootstrapError(RuntimeError):
    """Raised when a required runtime/model is missing and we cannot fix it."""


def _probe_ollama(base_url: str, timeout: float = 2.0) -> tuple[bool, str]:
    """Return (reachable, error message)."""
    try:
        r = requests.get(f"{base_url.rstrip('/')}/api/tags", timeout=timeout)
        r.raise_for_status()
        return True, ""
    except requests.RequestException as exc:
        return False, str(exc)


def _has_ollama_binary() -> bool:
    """True iff an `ollama` executable is on PATH."""
    return shutil.which("ollama") is not None


def try_autostart_ollama(
    base_url: str | None = None,
    *,
    wait_seconds: float = 5.0,
    poll_interval: float = 0.25,
    echo: bool = True,
) -> bool:
    """If Ollama is not reachable, spawn ``ollama serve`` detached in the
    background and poll the HTTP API until it answers, with a deadline.

    Returns True iff Ollama is reachable when the function exits.

    Idempotent within a process: only attempts ``ollama serve`` once per
    process (guarded by ``_AUTOSTART_ATTEMPTED``); on the second call, if
    the server still isn't up, we don't try to spawn another one.

    Echoes a short status line to stderr (``echo=True`` by default) so
    the user understands the brief startup pause:

      ``🔧 Ollama not running — starting in background…``
      ``✓ Ollama up after 1.4 s``        (success)
      ``× Ollama did not respond within 5 s — using rule-based router``

    Disabled via ``SKYGREP_AUTOSTART_OLLAMA=0``. Override the budget via
    ``SKYGREP_OLLAMA_AUTOSTART_TIMEOUT``.
    """
    global _AUTOSTART_ATTEMPTED

    if os.environ.get("SKYGREP_AUTOSTART_OLLAMA", "1") in ("0", "no", "false"):
        return False
    try:
        wait_seconds = float(
            os.environ.get("SKYGREP_OLLAMA_AUTOSTART_TIMEOUT", wait_seconds)
        )
    except (TypeError, ValueError):
        pass

    cfg = get_config()
    url = (base_url or cfg["ollama_url"]).rstrip("/")

    ok, _ = _probe_ollama(url, timeout=0.5)
    if ok:
        return True

    if _AUTOSTART_ATTEMPTED:
        # Already tried and the server still isn't up. Don't spam spawns.
        return False
    _AUTOSTART_ATTEMPTED = True

    if not _has_ollama_binary():
        if echo:
            print(
                "⚠ Ollama not installed — using rule-based router. "
                "Install: brew install ollama (or https://ollama.com/download)",
                file=sys.stderr,
                flush=True,
            )
        return False

    if echo:
        print(
            "🔧 Ollama not running — starting in background…",
            file=sys.stderr,
            flush=True,
        )

    try:
        subprocess.Popen(
            ["ollama", "serve"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )
    except (FileNotFoundError, OSError) as exc:
        logger.debug("ollama serve spawn failed: %s", exc)
        if echo:
            print(
                f"× Could not spawn `ollama serve`: {exc} — "
                "using rule-based router",
                file=sys.stderr,
                flush=True,
            )
        return False

    deadline = time.monotonic() + wait_seconds
    started_at = time.monotonic()
    while time.monotonic() < deadline:
        ok, _ = _probe_ollama(url, timeout=0.3)
        if ok:
            elapsed = time.monotonic() - started_at
            if echo:
                print(
                    f"✓ Ollama up after {elapsed:.1f} s",
                    file=sys.stderr,
                    flush=True,
                )
            return True
        time.sleep(poll_interval)

    if echo:
        print(
            f"× Ollama did not respond within {wait_seconds:.0f} s — "
            "using rule-based router for now",
            file=sys.stderr,
            flush=True,
        )
    return False


def list_local_models(base_url: str, timeout: float = 5.0) -> list[str]:
    """Return the list of locally-installed Ollama model names (with tags).

    Tags are normalised so that ``nomic-embed-text`` matches a server entry
    of ``nomic-embed-text:latest``.
    """
    try:
        r = requests.get(f"{base_url.rstrip('/')}/api/tags", timeout=timeout)
        r.raise_for_status()
    except requests.RequestException:
        return []
    data = r.json() or {}
    out: list[str] = []
    for item in data.get("models", []) or []:
        name = item.get("name") or item.get("model") or ""
        if name:
            out.append(name)
    return out


def _model_present(installed: Iterable[str], wanted: str) -> bool:
    """Tag-aware match: ``nomic-embed-text`` matches
    ``nomic-embed-text:latest``, but ``qwen2.5:1.5b`` does NOT match
    ``qwen2.5:3b`` because Ollama treats those as separate model files.

    Rule: if ``wanted`` carries an explicit tag, require an exact name
    match. If ``wanted`` is bare (no colon), accept either an exact match
    or ``<wanted>:latest`` since Ollama's API treats those equivalently.
    """
    if ":" in wanted:
        return wanted in installed
    target_latest = f"{wanted}:latest"
    return wanted in installed or target_latest in installed


def pull_model(model: str, *, base_url: str | None = None, stream: bool = True) -> bool:
    """Run ``ollama pull <model>`` via the HTTP API, stream progress to stderr.

    Returns True on success. On failure prints actionable error and returns
    False.
    """

    cfg = get_config()
    url = (base_url or cfg["ollama_url"]).rstrip("/")
    print(f"  → pulling {model} (this may take a few minutes) …", file=sys.stderr, flush=True)
    try:
        with requests.post(
            f"{url}/api/pull",
            json={"name": model},
            stream=True,
            timeout=None,
        ) as r:
            r.raise_for_status()
            last = ""
            for raw in r.iter_lines():
                if not raw:
                    continue
                try:
                    obj = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                msg = obj.get("status", "")
                # Show only meaningful transitions, not byte-by-byte progress.
                if msg and msg != last and not msg.startswith("downloading"):
                    print(f"    {msg}", file=sys.stderr, flush=True)
                    last = msg
                if obj.get("error"):
                    print(f"  × pull error: {obj['error']}", file=sys.stderr, flush=True)
                    return False
    except requests.RequestException as exc:
        print(
            f"  × pull failed: {exc}\n"
            f"    Try manually: ollama pull {model}",
            file=sys.stderr,
        )
        return False
    print(f"  ✓ pulled {model}", file=sys.stderr, flush=True)
    return True


def ensure_ollama(base_url: str | None = None) -> None:
    """Raise BootstrapError with an actionable message if Ollama is unreachable."""
    cfg = get_config()
    url = (base_url or cfg["ollama_url"])
    ok, err = _probe_ollama(url)
    if not ok:
        raise BootstrapError(
            f"Ollama not reachable at {url}: {err}\n\n{OLLAMA_INSTALL_HINT}"
        )


def ensure_model(
    model: str,
    *,
    base_url: str | None = None,
    auto_pull: bool | None = None,
    confirm_prompt: str | None = None,
) -> None:
    """Ensure an Ollama model is locally present, pulling on demand.

    ``auto_pull=True`` skips the y/N prompt. ``auto_pull=None`` reads
    ``SKYGREP_AUTO_PULL`` (``yes`` / ``no``). Default is to prompt.
    """

    cfg = get_config()
    url = (base_url or cfg["ollama_url"])
    installed = list_local_models(url)
    if _model_present(installed, model):
        return

    if auto_pull is None:
        env = os.environ.get("SKYGREP_AUTO_PULL", "").lower()
        auto_pull = env in {"yes", "y", "true", "1"}

    if not auto_pull:
        prompt = confirm_prompt or (
            f"Model '{model}' is not installed locally. Pull it now? [Y/n] "
        )
        try:
            answer = input(prompt).strip().lower()
        except EOFError:
            answer = ""
        if answer and answer not in {"y", "yes"}:
            raise BootstrapError(
                f"Aborted. Pull manually with: ollama pull {model}"
            )

    if not pull_model(model, base_url=url):
        raise BootstrapError(
            f"Could not pull '{model}'. Try manually: ollama pull {model}"
        )


def preheat_models(
    *,
    base_url: str | None = None,
    embed_model: str | None = None,
    hyde_model: str | None = None,
    timeout: float = 0.25,
) -> None:
    """Fire-and-forget warm-up of Ollama models in a background thread.

    Sending a no-op generate / embed call with ``keep_alive=-1`` causes
    Ollama to load the model into memory and pin it there. The first
    real query in the same shell session then no longer pays the
    5-10 s cold-load. Subsequent ``skygrep`` invocations benefit too,
    because Ollama keeps the model resident across our process exit.

    Network failures, missing models, and short timeouts are silently
    swallowed — preheat is best-effort and must never block or break
    the real search flow.
    """
    import threading

    cfg = get_config()
    url = (base_url or cfg["ollama_url"]).rstrip("/")
    em = embed_model or cfg["embed_model"]
    lm = hyde_model or (cfg.get("hyde_model") or cfg["llm_model"])

    def _ping_embed():
        try:
            requests.post(
                f"{url}/api/embeddings",
                json={"model": em, "prompt": "warm", "keep_alive": -1},
                timeout=timeout,
            )
        except Exception:
            pass

    def _ping_generate():
        try:
            requests.post(
                f"{url}/api/generate",
                json={
                    "model": lm,
                    "prompt": "",
                    "stream": False,
                    "keep_alive": -1,
                    "options": {"num_predict": 1},
                },
                timeout=timeout,
            )
        except Exception:
            pass

    for fn in (_ping_embed, _ping_generate):
        t = threading.Thread(target=fn, daemon=True)
        t.start()


def doctor_report(base_url: str | None = None) -> dict:
    """Collect a structured health report. Used by ``skygrep doctor``."""
    cfg = get_config()
    url = (base_url or cfg["ollama_url"]).rstrip("/")
    report: dict = {
        "ollama": {"url": url, "ok": False, "error": ""},
        "models": [],
        "keep_alive": cfg.get("keep_alive"),
    }
    ok, err = _probe_ollama(url)
    report["ollama"]["ok"] = ok
    report["ollama"]["error"] = err
    if not ok:
        return report
    installed = list_local_models(url)
    seen_names: set[str] = set()
    for label, name in (
        ("embed", cfg["embed_model"]),
        ("llm (--answer)", cfg["llm_model"]),
        ("llm (cascade/HyDE)", cfg.get("hyde_model") or cfg["llm_model"]),
    ):
        if name in seen_names:
            # ``hyde_model == llm_model`` is fine (legacy / explicit override) —
            # don't print the same row twice.
            continue
        seen_names.add(name)
        report["models"].append(
            {
                "role": label,
                "name": name,
                "present": _model_present(installed, name),
            }
        )
    return report
