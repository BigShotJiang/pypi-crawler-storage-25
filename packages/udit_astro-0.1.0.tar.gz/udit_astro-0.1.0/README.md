# udit-astro

`udit-astro` is a Python library for Vedic astrology calculations powered by Swiss Ephemeris.

This first version focuses on planet data:

- sidereal longitude
- zodiac sign
- degree within sign
- includes Sun, Moon, Mercury, Venus, Mars, Jupiter, Saturn, Uranus, Neptune, Pluto, Ceres, Chiron, Rahu, Ketu, Upaketu, Gulika, and POF

## Installation

For local development:

```bash
pip install -e .
```

After publication, this will become:

```bash
pip install udit-astro
```

## Example

```python
from datetime import datetime, timedelta, timezone

from udit_astro import (
    BirthData,
    ChartSettings,
    Formula,
    GulikaMode,
    HouseSystem,
    NodeType,
    Place,
    get_cusp_data,
    get_d9_cusp_data,
    get_d9_cusps_data,
    get_d9_planet_data,
    get_d9_planets_data,
    get_cusps_data,
    get_house_significator_data,
    get_house_significators_data,
    get_planet_data,
    get_planet_significator_data,
    get_planet_significators_data,
    get_planets_data,
    set_ephemeris_path,
)

set_ephemeris_path("C:/ephe")
place = Place(latitude=28.6139, longitude=77.2090)
dt = datetime(
    1996,
    6,
    13,
    5,
    30,
    tzinfo=timezone(timedelta(hours=5, minutes=30)),
)
birth_data = BirthData(dt=dt, place=place)
chart_settings = ChartSettings(
    node_type=NodeType.TRUE,
    gulika_mode=GulikaMode.START_OF_SATURN_SEGMENT,
    part_of_fortune=Formula.DAY_FORMULA,
    house_system=HouseSystem.PLACIDUS,
    planet_house_system=HouseSystem.WHOLE_SIGN,
)
positions = get_planets_data(birth_data, chart_settings=chart_settings)
moon = get_planet_data(birth_data, "Moon", chart_settings=chart_settings)
d9_positions = get_d9_planets_data(birth_data, chart_settings=chart_settings)
d9_moon = get_d9_planet_data(birth_data, "Moon", chart_settings=chart_settings)
cusps = get_cusps_data(birth_data, chart_settings=chart_settings)
first_cusp = get_cusp_data(birth_data, 1, chart_settings=chart_settings)
d9_cusps = get_d9_cusps_data(birth_data, chart_settings=chart_settings)
d9_first_cusp = get_d9_cusp_data(birth_data, 1, chart_settings=chart_settings)
significators = get_house_significators_data(birth_data, chart_settings=chart_settings)
first_house_significator = get_house_significator_data(
    birth_data,
    1,
    chart_settings=chart_settings,
)
planet_significators = get_planet_significators_data(
    birth_data,
    chart_settings=chart_settings,
)
moon_significator = get_planet_significator_data(
    birth_data,
    "Moon",
    chart_settings=chart_settings,
)

for planet, data in positions.items():
    print(
        planet,
        data.sign_as_name,
        data.sign_as_number,
        data.house_number,
        data.nakshatra_name,
        data.nakshatra_pada,
        round(data.position, 4),
        data.position_as_DMS,
        data.is_retrograde,
        data.sign_lord,
        data.star_lord,
        data.sub_lord,
        data.sub_sub_lord,
        data.sub_sub_sub_lord,
        round(data.longitude, 4),
    )

for planet, data in d9_positions.items():
    print(planet, data.sign_as_name, data.position_as_DMS, data.house_number)

for house_number, cusp in cusps.items():
    print(
        house_number,
        cusp.sign_as_name,
        cusp.sign_as_number,
        cusp.nakshatra_name,
        cusp.nakshatra_pada,
        cusp.position_as_DMS,
        cusp.sign_lord,
        cusp.star_lord,
        cusp.sub_lord,
        cusp.sub_sub_lord,
        cusp.sub_sub_sub_lord,
    )

for house_number, cusp in d9_cusps.items():
    print(
        house_number,
        cusp.sign_as_name,
        cusp.sign_as_number,
        cusp.position_as_DMS,
    )

print(moon.sign_as_name, moon.position_as_DMS)
print(d9_moon.sign_as_name, d9_moon.position_as_DMS)
print(first_cusp.sign_as_name, first_cusp.position_as_DMS)
print(d9_first_cusp.sign_as_name, d9_first_cusp.position_as_DMS)

for house_number, data in significators.items():
    print(
        house_number,
        data.a,
        data.b,
        data.c,
        data.d,
    )

print(
    first_house_significator.a,
    first_house_significator.b,
    first_house_significator.c,
    first_house_significator.d,
)

for planet_name, data in planet_significators.items():
    print(
        planet_name,
        data.a,
        data.b,
        data.c,
        data.d,
    )

print(
    moon_significator.a,
    moon_significator.b,
    moon_significator.c,
    moon_significator.d,
)
```

## Notes

- Input datetimes must be timezone-aware.
- `BirthData` bundles the birth datetime and optional place into one object.
- `ChartSettings` bundles chart-level options like ayanamsha, Rahu/Ketu node type, and Gulika mode.
- `ChartSettings` also controls house cusps through `house_system`, which defaults to `HouseSystem.PLACIDUS`.
- Planet house placement uses `planet_house_system`, which defaults to `HouseSystem.WHOLE_SIGN`.
- Use `get_planet_data(...)`, `get_d9_planet_data(...)`, `get_cusp_data(...)`, and `get_d9_cusp_data(...)` when you want one item directly instead of the full dictionary.
- Use `get_house_significators_data(...)` for KP-style house significator A/B/C/D lists, or `get_house_significator_data(...)` for one house.
- House significators currently consider only the standard 9 planets: Sun, Moon, Mars, Mercury, Jupiter, Venus, Saturn, Rahu, and Ketu.
- Significator occupancy uses `chart_settings.house_system`, so it defaults to `HouseSystem.PLACIDUS`.
- Use `get_planet_significators_data(...)` for the inverse planet-wise A/B/C/D house view, or `get_planet_significator_data(...)` for one planet.
- `get_d9_cusps_data(...)` returns a slimmer D9 cusp shape with sign and position fields only.
- `ChartSettings` can also take a single enum-based Part of Fortune formula override.
- Place coordinates should be passed in decimal degrees.
- Calculations are sidereal by default.
- The default ayanamsha is Lahiri.
- Rahu/Ketu use `true` node by default; set `NodeType.MEAN` to use mean node.
- Upaketu is currently computed as a solar upagraha derived from the Sun's sidereal longitude.
- Part of Fortune uses the standard day/night logic by default. If `chart_settings.part_of_fortune` is set, that formula is used directly.
- Gulika is currently computed with the Parashara day/night eight-part method and uses the ascendant at the selected Saturn-segment boundary.
- Gulika requires `place`, because sunrise, sunset, and ascendant depend on location.
- Planet sign/degree output is geocentric for now; coordinates are accepted now because place will be required for upcoming features like ascendant and houses.
- If you have Swiss Ephemeris data files, set their directory with `set_ephemeris_path(...)`.

## Run A Test Script

Use the included example script:

```bash
pip install -e .
python examples/show_planet_positions.py
```
