from datetime import datetime, timedelta, timezone

from udit_astro import (
    Ayanamsha,
    BirthData,
    ChartSettings,
    Formula,
    GulikaMode,
    HouseSystem,
    NodeType,
    Place,
    get_cusp_data,
    get_d9_cusp_data,
    get_d9_cusps_data,
    get_d9_planet_data,
    get_d9_planets_data,
    get_cusps_data,
    get_house_significator_data,
    get_house_significators_data,
    get_planet_data,
    get_planet_significator_data,
    get_planet_significators_data,
    get_planets_data,
    set_ephemeris_path,
)


def main() -> None:
    # Optional: point this to your Swiss Ephemeris data folder if you have one.
    set_ephemeris_path("C:/Users/yadav/Desktop/Astro-Sports/swefiles")

    place = Place(latitude=17.4399, longitude=78.4983)
    dt = datetime(
        1995,
        10,
        5,
        5,
        10,
        0,
        tzinfo=timezone(timedelta(hours=5, minutes=30)),
        # tzinfo=ZoneInfo("Asia/Kolkata")
    )
    birth_data = BirthData(dt=dt, place=place)
    chart_settings = ChartSettings(
        ayanamsha=Ayanamsha.LAHIRI,
        node_type=NodeType.MEAN,
        gulika_mode=GulikaMode.START_OF_SATURN_SEGMENT,
        part_of_fortune=Formula.DAY_FORMULA,
        house_system=HouseSystem.PLACIDUS,
        planet_house_system=HouseSystem.WHOLE_SIGN,
    )
    planets = get_planets_data(birth_data, chart_settings=chart_settings)
    moon = get_planet_data(birth_data, "Moon", chart_settings=chart_settings)
    d9_planets = get_d9_planets_data(birth_data, chart_settings=chart_settings)
    d9_moon = get_d9_planet_data(birth_data, "Moon", chart_settings=chart_settings)
    cusps = get_cusps_data(birth_data, chart_settings=chart_settings)
    first_cusp = get_cusp_data(birth_data, 1, chart_settings=chart_settings)
    d9_cusps = get_d9_cusps_data(birth_data, chart_settings=chart_settings)
    d9_first_cusp = get_d9_cusp_data(birth_data, 1, chart_settings=chart_settings)
    significators = get_house_significators_data(birth_data, chart_settings=chart_settings)
    first_house_significator = get_house_significator_data(
        birth_data,
        1,
        chart_settings=chart_settings,
    )
    planet_significators = get_planet_significators_data(
        birth_data,
        chart_settings=chart_settings,
    )
    moon_significator = get_planet_significator_data(
        birth_data,
        "Moon",
        chart_settings=chart_settings,
    )

    print(f"Planetary positions for: {birth_data.dt.isoformat()}")
    print(f"Coordinates: lat={birth_data.place.latitude}, lon={birth_data.place.longitude}")
    print(f"Node type: {chart_settings.node_type.value}")
    print(f"Gulika mode: {chart_settings.gulika_mode.value}")
    print(f"House system: {chart_settings.house_system.name}")
    print(f"Planet house system: {chart_settings.planet_house_system.name}")
    print("-" * 183)
    print(f"{'Planet':<10} {'Sign':<12} {'House':>7} {'Nakshatra':>16} {'Pada':>6} {'Deg in Sign':>12} {'DMS':>12} {'Retro':>7} {'SignLord':>10} {'Star':>10} {'Sub':>10} {'SubSub':>10} {'Sub3':>10}")
    print("-" * 183)

    for planet, data in planets.items():
        print(
            f"{planet:<10} "
            f"{data.sign_as_name:<12} "
            f"{str(data.house_number):>7} "
            f"{data.nakshatra_name:>16} "
            f"{data.nakshatra_pada:>6} "
            f"{data.position:>12.6f} "
            f"{data.position_as_DMS:>12} "
            f"{str(data.is_retrograde):>7} "
            f"{data.sign_lord:>10} "
            f"{data.star_lord:>10} "
            f"{data.sub_lord:>10} "
            f"{data.sub_sub_lord:>10} "
            f"{data.sub_sub_sub_lord:>10} "
        )

    print()
    print("D9 planet positions")
    print("-" * 73)
    print(f"{'Planet':<10} {'Sign':<12} {'House':>7} {'Position':>12} {'DMS':>12} {'Longitude':>12}")
    print("-" * 73)

    for planet, data in d9_planets.items():
        print(
            f"{planet:<10} "
            f"{data.sign_as_name:<12} "
            f"{str(data.house_number):>7} "
            f"{data.position:>12.6f} "
            f"{data.position_as_DMS:>12} "
            f"{data.longitude:>12.6f}"
        )

    print()
    print("House cusps")
    print("-" * 145)
    print(f"{'House':<10} {'Sign':<12} {'Number':>8} {'Nakshatra':>16} {'Pada':>6} {'DMS':>12} {'SignLord':>10} {'Star':>10} {'Sub':>10} {'SubSub':>10} {'Sub3':>10}")
    print("-" * 145)

    for house_number, cusp in cusps.items():
        print(
            f"{house_number:<10} "
            f"{cusp.sign_as_name:<12} "
            f"{cusp.sign_as_number:>8} "
            f"{cusp.nakshatra_name:>16} "
            f"{cusp.nakshatra_pada:>6} "
            f"{cusp.position_as_DMS:>12} "
            f"{cusp.sign_lord:>10} "
            f"{cusp.star_lord:>10} "
            f"{cusp.sub_lord:>10} "
            f"{cusp.sub_sub_lord:>10} "
            f"{cusp.sub_sub_sub_lord:>10} "
        )

    print()
    print("D9 house cusps")
    print("-" * 52)
    print(f"{'House':<10} {'Sign':<12} {'Number':>8} {'DMS':>12}")
    print("-" * 52)

    for house_number, cusp in d9_cusps.items():
        print(
            f"{house_number:<10} "
            f"{cusp.sign_as_name:<12} "
            f"{cusp.sign_as_number:>8} "
            f"{cusp.position_as_DMS:>12} "
        )

    print()
    print("Single item methods")
    print("-" * 72)
    print(f"Moon D1     : {moon.sign_as_name} {moon.position_as_DMS} House {moon.house_number}")
    print(f"Moon D9     : {d9_moon.sign_as_name} {d9_moon.position_as_DMS} House {d9_moon.house_number}")
    print(f"Cusp 1 D1   : {first_cusp.sign_as_name} {first_cusp.position_as_DMS}")
    print(f"Cusp 1 D9   : {d9_first_cusp.sign_as_name} {d9_first_cusp.position_as_DMS}")

    print()
    print("Significator - House View")
    print("-" * 80)
    print(f"{'House':<8} {'(A)':<20} {'(B)':<20} {'(C)':<20} {'(D)':<12}")
    print("-" * 80)

    for house_number, data in significators.items():
        print(
            f"{house_number:<8} "
            f"{','.join(data.a):<20} "
            f"{','.join(data.b):<20} "
            f"{','.join(data.c):<20} "
            f"{','.join(data.d):<12} "
        )

    print()
    print(
        f"House 1 significator demo: "
        f"A={','.join(first_house_significator.a)} "
        f"B={','.join(first_house_significator.b)} "
        f"C={','.join(first_house_significator.c)} "
        f"D={','.join(first_house_significator.d)}"
    )

    print()
    print("Significators - Planet View")
    print("-" * 72)
    print(f"{'Planet':<14} {'(A)':<12} {'(B)':<12} {'(C)':<12} {'(D)':<12}")
    print("-" * 72)

    for planet_name, data in planet_significators.items():
        print(
            f"{planet_name:<14} "
            f"{','.join(str(house) for house in data.a):<12} "
            f"{','.join(str(house) for house in data.b):<12} "
            f"{','.join(str(house) for house in data.c):<12} "
            f"{','.join(str(house) for house in data.d):<12} "
        )

    print()
    print(
        f"Moon significator demo: "
        f"A={','.join(str(house) for house in moon_significator.a)} "
        f"B={','.join(str(house) for house in moon_significator.b)} "
        f"C={','.join(str(house) for house in moon_significator.c)} "
        f"D={','.join(str(house) for house in moon_significator.d)}"
    )


if __name__ == "__main__":
    main()
