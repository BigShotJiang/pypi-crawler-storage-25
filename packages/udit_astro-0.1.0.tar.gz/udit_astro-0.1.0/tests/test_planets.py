from datetime import datetime
from zoneinfo import ZoneInfo

from udit_astro.planets import (
    Ayanamsha,
    BirthData,
    ChartSettings,
    CuspPosition,
    D9CuspPosition,
    Formula,
    GulikaMode,
    HouseSignificator,
    HouseSystem,
    NodeType,
    PLANET_CODES,
    PlanetSignificator,
    Place,
    _build_part_of_fortune_longitude,
    _build_cusp_position,
    _build_d9_cusp_position,
    _calc_d9_longitude,
    _calc_kp_lords,
    _calc_upaketu_longitude,
    _get_house_number_from_cusps,
    _get_gulika_segment_number,
    _build_position,
    _get_significator_chart_settings,
    _get_significator_planets,
    _to_julian_day_ut,
    format_degree_as_dms,
    get_cusp_data,
    get_d9_cusp_data,
    get_d9_planet_data,
    get_planet_data,
    get_house_significator_data,
    get_planet_significator_data,
)


def test_build_position_maps_sign_and_degree() -> None:
    position = _build_position("Sun", 47.25)

    assert position.sign_as_name == "Taurus"
    assert position.sign_as_number == 2
    assert position.nakshatra_name == "Rohini"
    assert position.nakshatra_pada == 2
    assert position.position == 17.25
    assert position.position_as_DMS == "17:15:00"
    assert position.is_retrograde is False
    assert position.house_number is None
    assert position.sign_lord == "Venus"
    assert isinstance(position.star_lord, str)
    assert isinstance(position.sub_lord, str)
    assert isinstance(position.sub_sub_lord, str)
    assert isinstance(position.sub_sub_sub_lord, str)


def test_to_julian_day_requires_timezone_aware_datetime() -> None:
    try:
        _to_julian_day_ut(datetime(2024, 1, 1, 0, 0))
    except ValueError as exc:
        assert "timezone-aware" in str(exc)
    else:
        raise AssertionError("Expected ValueError for naive datetime")


def test_to_julian_day_accepts_timezone_aware_datetime() -> None:
    jd = _to_julian_day_ut(datetime(2024, 1, 1, 12, 0, tzinfo=ZoneInfo("UTC")))

    assert isinstance(jd, float)


def test_place_accepts_decimal_lat_lon() -> None:
    place = Place(28.6139, 77.2090)

    assert place.latitude == 28.6139
    assert place.longitude == 77.2090


def test_place_rejects_invalid_longitude() -> None:
    try:
        Place(28.6139, 200.0)
    except ValueError as exc:
        assert "longitude" in str(exc)
    else:
        raise AssertionError("Expected ValueError for invalid longitude")


def test_format_degree_as_dms_formats_minutes_and_seconds() -> None:
    assert format_degree_as_dms(2.0666666667) == "02:04:00"


def test_birth_data_accepts_datetime_and_place() -> None:
    birth_data = BirthData(
        dt=datetime(2024, 1, 1, 12, 0, tzinfo=ZoneInfo("UTC")),
        place=Place(28.6139, 77.2090),
    )

    assert birth_data.place is not None
    assert birth_data.place.latitude == 28.6139


def test_planet_codes_include_outer_planets() -> None:
    assert "Uranus" in PLANET_CODES
    assert "Neptune" in PLANET_CODES
    assert "Pluto" in PLANET_CODES


def test_planet_codes_include_ceres_and_chiron() -> None:
    assert "Ceres" in PLANET_CODES
    assert "Chiron" in PLANET_CODES


def test_chart_settings_default_to_lahiri_and_true_node() -> None:
    chart_settings = ChartSettings()

    assert chart_settings.ayanamsha is Ayanamsha.LAHIRI
    assert chart_settings.node_type is NodeType.TRUE
    assert chart_settings.gulika_mode is GulikaMode.START_OF_SATURN_SEGMENT
    assert chart_settings.house_system is HouseSystem.PLACIDUS
    assert chart_settings.planet_house_system is HouseSystem.WHOLE_SIGN


def test_calc_upaketu_longitude_is_thirty_degrees_behind_sun() -> None:
    assert _calc_upaketu_longitude(100.0) == 70.0
    assert _calc_upaketu_longitude(20.0) == 350.0


def test_build_part_of_fortune_longitude_for_day_chart() -> None:
    fortune = _build_part_of_fortune_longitude(100.0, 80.0, 130.0, is_day_birth=True)

    assert fortune == 150.0


def test_build_part_of_fortune_longitude_for_night_chart() -> None:
    fortune = _build_part_of_fortune_longitude(100.0, 80.0, 130.0, is_day_birth=False)

    assert fortune == 50.0


def test_build_part_of_fortune_longitude_accepts_custom_formula() -> None:
    chart_settings = ChartSettings(
        part_of_fortune=Formula.NIGHT_FORMULA,
    )

    fortune = _build_part_of_fortune_longitude(
        100.0,
        80.0,
        130.0,
        is_day_birth=True,
        chart_settings=chart_settings,
    )

    assert fortune == 50.0


def test_day_and_night_formula_enum_values_match_defaults() -> None:
    assert Formula.DAY_FORMULA.ascendant_sign == 1
    assert Formula.DAY_FORMULA.sun_sign == -1
    assert Formula.DAY_FORMULA.moon_sign == 1
    assert Formula.NIGHT_FORMULA.ascendant_sign == 1
    assert Formula.NIGHT_FORMULA.sun_sign == 1
    assert Formula.NIGHT_FORMULA.moon_sign == -1


def test_get_gulika_segment_number_for_day_birth() -> None:
    assert _get_gulika_segment_number(0, is_day_birth=True) == 6
    assert _get_gulika_segment_number(5, is_day_birth=True) == 1
    assert _get_gulika_segment_number(6, is_day_birth=True) == 7


def test_get_gulika_segment_number_for_night_birth() -> None:
    assert _get_gulika_segment_number(0, is_day_birth=False) == 2
    assert _get_gulika_segment_number(2, is_day_birth=False) == 7
    assert _get_gulika_segment_number(6, is_day_birth=False) == 3


def test_build_cusp_position_maps_sign_and_degree() -> None:
    cusp = _build_cusp_position(1, 47.25)

    assert isinstance(cusp, CuspPosition)
    assert cusp.house_number == 1
    assert cusp.sign_as_name == "Taurus"
    assert cusp.sign_as_number == 2
    assert cusp.nakshatra_name == "Rohini"
    assert cusp.nakshatra_pada == 2
    assert cusp.position == 17.25
    assert cusp.sign_lord == "Venus"
    assert isinstance(cusp.star_lord, str)
    assert isinstance(cusp.sub_lord, str)
    assert isinstance(cusp.sub_sub_lord, str)
    assert isinstance(cusp.sub_sub_sub_lord, str)


def test_get_house_number_from_cusps_handles_wraparound() -> None:
    cusp_longitudes = [330.0, 0.0, 30.0, 60.0, 90.0, 120.0, 150.0, 180.0, 210.0, 240.0, 270.0, 300.0]

    assert _get_house_number_from_cusps(350.0, cusp_longitudes) == 1
    assert _get_house_number_from_cusps(15.0, cusp_longitudes) == 2


def test_calc_kp_lords_for_ashwini_start() -> None:
    star_lord, sub_lord, sub_sub_lord, sub_sub_sub_lord = _calc_kp_lords(0.0)

    assert star_lord == "Ketu"
    assert sub_lord == "Ketu"
    assert sub_sub_lord == "Ketu"
    assert sub_sub_sub_lord == "Ketu"


def test_calc_d9_longitude_for_fixed_sign_start() -> None:
    d9_longitude = _calc_d9_longitude(30.0)

    assert d9_longitude == 270.0


def test_calc_d9_longitude_maps_taurus_position_into_gemini() -> None:
    d9_longitude = _calc_d9_longitude(47.25)

    assert round(d9_longitude, 6) == 65.25


def test_build_cusp_position_includes_position_as_dms() -> None:
    cusp = _build_cusp_position(1, 47.25)

    assert cusp.position_as_DMS == "17:15:00"


def test_calc_d9_longitude_maps_cusp_into_expected_d9_sign() -> None:
    cusp = _build_d9_cusp_position(1, _calc_d9_longitude(47.25))

    assert isinstance(cusp, D9CuspPosition)
    assert cusp.sign_as_name == "Gemini"
    assert cusp.sign_as_number == 3
    assert cusp.position == 5.25
    assert cusp.position_as_DMS == "05:15:00"




def test_get_planet_data_returns_requested_planet() -> None:
    birth_data = BirthData(dt=datetime(2024, 1, 1, 12, 0, tzinfo=ZoneInfo("UTC")))

    moon = get_planet_data(birth_data, "Moon")

    assert moon.planet == "Moon"


def test_get_planet_data_rejects_unknown_planet_name() -> None:
    birth_data = BirthData(dt=datetime(2024, 1, 1, 12, 0, tzinfo=ZoneInfo("UTC")))

    try:
        get_planet_data(birth_data, "InvalidPlanet")
    except ValueError as exc:
        assert "unknown planet_name" in str(exc)
    else:
        raise AssertionError("Expected ValueError for invalid planet name")


def test_get_cusp_data_rejects_invalid_cusp_number() -> None:
    birth_data = BirthData(
        dt=datetime(2024, 1, 1, 12, 0, tzinfo=ZoneInfo("UTC")),
        place=Place(28.6139, 77.2090),
    )

    try:
        get_cusp_data(birth_data, 13)
    except ValueError as exc:
        assert "between 1 and 12" in str(exc)
    else:
        raise AssertionError("Expected ValueError for invalid cusp number")


def test_get_d9_planet_data_returns_requested_planet() -> None:
    birth_data = BirthData(dt=datetime(2024, 1, 1, 12, 0, tzinfo=ZoneInfo("UTC")))

    moon = get_d9_planet_data(birth_data, "Moon")

    assert moon.planet == "Moon"


def test_get_d9_cusp_data_rejects_invalid_cusp_number() -> None:
    birth_data = BirthData(
        dt=datetime(2024, 1, 1, 12, 0, tzinfo=ZoneInfo("UTC")),
        place=Place(28.6139, 77.2090),
    )

    try:
        get_d9_cusp_data(birth_data, 0)
    except ValueError as exc:
        assert "between 1 and 12" in str(exc)
    else:
        raise AssertionError("Expected ValueError for invalid cusp number")


def test_house_significator_dataclass_stores_columns() -> None:
    significator = HouseSignificator(
        house_number=1,
        a=("Saturn",),
        b=("Moon",),
        c=("Venus",),
        d=("Mars",),
    )

    assert significator.house_number == 1
    assert significator.a == ("Saturn",)
    assert significator.b == ("Moon",)
    assert significator.c == ("Venus",)
    assert significator.d == ("Mars",)


def test_get_house_significator_data_rejects_invalid_house_number() -> None:
    birth_data = BirthData(
        dt=datetime(2024, 1, 1, 12, 0, tzinfo=ZoneInfo("UTC")),
        place=Place(28.6139, 77.2090),
    )

    try:
        get_house_significator_data(birth_data, 13)
    except ValueError as exc:
        assert "between 1 and 12" in str(exc)
    else:
        raise AssertionError("Expected ValueError for invalid house number")


def test_get_significator_planets_uses_standard_nine_planets_only() -> None:
    positions = {
        "Sun": _build_position("Sun", 10.0),
        "Moon": _build_position("Moon", 20.0),
        "Mars": _build_position("Mars", 30.0),
        "Mercury": _build_position("Mercury", 40.0),
        "Jupiter": _build_position("Jupiter", 50.0),
        "Venus": _build_position("Venus", 60.0),
        "Saturn": _build_position("Saturn", 70.0),
        "Rahu": _build_position("Rahu", 80.0),
        "Ketu": _build_position("Ketu", 90.0),
        "Uranus": _build_position("Uranus", 100.0),
        "Neptune": _build_position("Neptune", 110.0),
        "Pluto": _build_position("Pluto", 120.0),
        "Ceres": _build_position("Ceres", 130.0),
        "Chiron": _build_position("Chiron", 140.0),
        "Upaketu": _build_position("Upaketu", 150.0),
        "Gulika": _build_position("Gulika", 160.0),
        "POF": _build_position("POF", 170.0),
    }

    significator_planets = _get_significator_planets(positions)

    assert tuple(significator_planets.keys()) == (
        "Sun",
        "Moon",
        "Mars",
        "Mercury",
        "Jupiter",
        "Venus",
        "Saturn",
        "Rahu",
        "Ketu",
    )


def test_planet_significator_dataclass_stores_columns() -> None:
    significator = PlanetSignificator(
        planet="Moon",
        a=(5,),
        b=(4,),
        c=(8,),
        d=(7,),
    )

    assert significator.planet == "Moon"
    assert significator.a == (5,)
    assert significator.b == (4,)
    assert significator.c == (8,)
    assert significator.d == (7,)


def test_get_planet_significator_data_rejects_invalid_planet_name() -> None:
    birth_data = BirthData(
        dt=datetime(2024, 1, 1, 12, 0, tzinfo=ZoneInfo("UTC")),
        place=Place(28.6139, 77.2090),
    )

    try:
        get_planet_significator_data(birth_data, "InvalidPlanet")
    except ValueError as exc:
        assert "unknown planet_name" in str(exc)
    else:
        raise AssertionError("Expected ValueError for invalid planet name")


def test_get_significator_chart_settings_uses_house_system_for_planet_placement() -> None:
    chart_settings = ChartSettings(
        house_system=HouseSystem.PLACIDUS,
        planet_house_system=HouseSystem.WHOLE_SIGN,
    )

    significator_settings = _get_significator_chart_settings(chart_settings)

    assert significator_settings.house_system is HouseSystem.PLACIDUS
    assert significator_settings.planet_house_system is HouseSystem.PLACIDUS
