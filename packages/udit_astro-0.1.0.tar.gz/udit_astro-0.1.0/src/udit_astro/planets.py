from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import datetime, timedelta, timezone
from enum import Enum

import swisseph as swe


SIGNS = (
    "Aries",
    "Taurus",
    "Gemini",
    "Cancer",
    "Leo",
    "Virgo",
    "Libra",
    "Scorpio",
    "Sagittarius",
    "Capricorn",
    "Aquarius",
    "Pisces",
)

SIGN_LORDS = (
    "Mars",
    "Venus",
    "Mercury",
    "Moon",
    "Sun",
    "Mercury",
    "Venus",
    "Mars",
    "Jupiter",
    "Saturn",
    "Saturn",
    "Jupiter",
)

KP_LORD_SEQUENCE = (
    "Ketu",
    "Venus",
    "Sun",
    "Moon",
    "Mars",
    "Rahu",
    "Jupiter",
    "Saturn",
    "Mercury",
)

VIMSHOTTARI_YEARS = {
    "Ketu": 7,
    "Venus": 20,
    "Sun": 6,
    "Moon": 10,
    "Mars": 7,
    "Rahu": 18,
    "Jupiter": 16,
    "Saturn": 19,
    "Mercury": 17,
}

NAKSHATRA_SPAN = 360.0 / 27.0
PADA_SPAN = NAKSHATRA_SPAN / 4.0
NAVAMSA_SPAN = 30.0 / 9.0
NAKSHATRA_NAMES = (
    "Ashwini",
    "Bharani",
    "Krittika",
    "Rohini",
    "Mrigashira",
    "Ardra",
    "Punarvasu",
    "Pushya",
    "Ashlesha",
    "Magha",
    "Purva Phalguni",
    "Uttara Phalguni",
    "Hasta",
    "Chitra",
    "Swati",
    "Vishakha",
    "Anuradha",
    "Jyeshtha",
    "Mula",
    "Purva Ashadha",
    "Uttara Ashadha",
    "Shravana",
    "Dhanishta",
    "Shatabhisha",
    "Purva Bhadrapada",
    "Uttara Bhadrapada",
    "Revati",
)


class Ayanamsha(Enum):
    LAHIRI = swe.SIDM_LAHIRI
    RAMAN = swe.SIDM_RAMAN
    KRISHNAMURTI = swe.SIDM_KRISHNAMURTI
    YUKTESHWAR = swe.SIDM_YUKTESHWAR


class NodeType(Enum):
    TRUE = "true"
    MEAN = "mean"


class GulikaMode(Enum):
    START_OF_SATURN_SEGMENT = "start_of_saturn_segment"
    END_OF_SATURN_SEGMENT = "end_of_saturn_segment"


class HouseSystem(Enum):
    PLACIDUS = b"P"
    KOCH = b"K"
    EQUAL = b"A"
    WHOLE_SIGN = b"W"
    SRIPATI = b"S"


class Formula(Enum):
    DAY_FORMULA = (1, -1, 1)
    NIGHT_FORMULA = (1, 1, -1)

    @property
    def ascendant_sign(self) -> int:
        return self.value[0]

    @property
    def sun_sign(self) -> int:
        return self.value[1]

    @property
    def moon_sign(self) -> int:
        return self.value[2]


@dataclass(frozen=True, slots=True)
class PlanetPosition:
    planet: str
    longitude: float
    sign_as_name: str
    sign_as_number: int
    nakshatra_name: str
    nakshatra_pada: int
    position: float
    is_retrograde: bool
    house_number: int | None
    sign_lord: str
    star_lord: str
    sub_lord: str
    sub_sub_lord: str
    sub_sub_sub_lord: str

    @property
    def position_as_DMS(self) -> str:
        return format_degree_as_dms(self.position)


@dataclass(frozen=True, slots=True)
class CuspPosition:
    house_number: int
    longitude: float
    sign_as_name: str
    sign_as_number: int
    nakshatra_name: str
    nakshatra_pada: int
    position: float
    sign_lord: str
    star_lord: str
    sub_lord: str
    sub_sub_lord: str
    sub_sub_sub_lord: str

    @property
    def position_as_DMS(self) -> str:
        return format_degree_as_dms(self.position)


@dataclass(frozen=True, slots=True)
class D9CuspPosition:
    house_number: int
    longitude: float
    sign_as_name: str
    sign_as_number: int
    position: float

    @property
    def position_as_DMS(self) -> str:
        return format_degree_as_dms(self.position)


@dataclass(frozen=True, slots=True)
class HouseSignificator:
    house_number: int
    a: tuple[str, ...]
    b: tuple[str, ...]
    c: tuple[str, ...]
    d: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class PlanetSignificator:
    planet: str
    a: tuple[int, ...]
    b: tuple[int, ...]
    c: tuple[int, ...]
    d: tuple[int, ...]


@dataclass(frozen=True, slots=True)
class Place:
    latitude: float
    longitude: float

    def __post_init__(self) -> None:
        _validate_coordinates(self.latitude, self.longitude)


@dataclass(frozen=True, slots=True)
class BirthData:
    dt: datetime
    place: Place | None = None

    def __post_init__(self) -> None:
        if self.place is not None:
            _validate_coordinates(self.place.latitude, self.place.longitude)


@dataclass(frozen=True, slots=True)
class ChartSettings:
    ayanamsha: Ayanamsha = Ayanamsha.LAHIRI
    node_type: NodeType = NodeType.TRUE
    gulika_mode: GulikaMode = GulikaMode.START_OF_SATURN_SEGMENT
    part_of_fortune: Formula | None = None
    house_system: HouseSystem = HouseSystem.PLACIDUS
    planet_house_system: HouseSystem = HouseSystem.WHOLE_SIGN


PLANET_CODES = {
    "Sun": swe.SUN,
    "Moon": swe.MOON,
    "Mercury": swe.MERCURY,
    "Venus": swe.VENUS,
    "Mars": swe.MARS,
    "Jupiter": swe.JUPITER,
    "Saturn": swe.SATURN,
    "Uranus": swe.URANUS,
    "Neptune": swe.NEPTUNE,
    "Pluto": swe.PLUTO,
    "Ceres": swe.CERES,
    "Chiron": swe.CHIRON,
}

SIGNIFICATOR_BODY_NAMES = (
    "Sun",
    "Moon",
    "Mars",
    "Mercury",
    "Jupiter",
    "Venus",
    "Saturn",
    "Rahu",
    "Ketu",
)


def set_ephemeris_path(path: str) -> None:
    swe.set_ephe_path(path)


def get_planets_data(
    birth_data: BirthData,
    chart_settings: ChartSettings = ChartSettings(),
) -> dict[str, PlanetPosition]:
    """
    Return sidereal sign and degree information for the main Vedic grahas.

    Parameters
    ----------
    birth_data:
        Bundled birth datetime and optional place information.
    chart_settings:
        Chart calculation settings such as ayanamsha and node type.
    """
    jd_ut = _to_julian_day_ut(birth_data.dt)
    swe.set_sid_mode(chart_settings.ayanamsha.value)

    flags = swe.FLG_SWIEPH | swe.FLG_SIDEREAL | swe.FLG_SPEED

    positions: dict[str, PlanetPosition] = {}

    for name, body in PLANET_CODES.items():
        longitude, is_retrograde = _calc_planet_data(jd_ut, body, flags)
        positions[name] = _build_position(name, longitude, is_retrograde=is_retrograde)

    upaketu_longitude = _calc_upaketu_longitude(positions["Sun"].longitude)
    positions["Upaketu"] = _build_position("Upaketu", upaketu_longitude)

    if birth_data.place is not None:
        ascendant_longitude = _calc_ascendant_longitude(
            jd_ut,
            birth_data.place,
            chart_settings.house_system,
        )
        part_of_fortune_longitude = _calc_part_of_fortune_longitude(
            birth_data,
            ascendant_longitude,
            positions["Sun"].longitude,
            positions["Moon"].longitude,
            chart_settings,
        )
        positions["POF"] = _build_position("POF", part_of_fortune_longitude)

        gulika_longitude = _calc_gulika_longitude(birth_data, chart_settings)
        positions["Gulika"] = _build_position("Gulika", gulika_longitude)

    node_body = swe.TRUE_NODE if chart_settings.node_type is NodeType.TRUE else swe.MEAN_NODE
    rahu_longitude, rahu_is_retrograde = _calc_planet_data(jd_ut, node_body, flags)
    positions["Rahu"] = _build_position("Rahu", rahu_longitude, is_retrograde=rahu_is_retrograde)
    positions["Ketu"] = _build_position("Ketu", (rahu_longitude + 180.0) % 360.0)

    if birth_data.place is not None:
        _assign_house_numbers(positions, jd_ut, birth_data.place, chart_settings)

    return positions


def get_planet_data(
    birth_data: BirthData,
    planet_name: str,
    chart_settings: ChartSettings = ChartSettings(),
) -> PlanetPosition:
    return _get_planet_or_raise(
        get_planets_data(birth_data, chart_settings=chart_settings),
        planet_name,
    )


def get_cusps_data(
    birth_data: BirthData,
    chart_settings: ChartSettings = ChartSettings(),
) -> dict[int, CuspPosition]:
    if birth_data.place is None:
        raise ValueError("place is required to calculate house cusps")

    jd_ut = _to_julian_day_ut(birth_data.dt)
    swe.set_sid_mode(chart_settings.ayanamsha.value)
    flags = swe.FLG_SIDEREAL

    cusps, _ascmc = swe.houses_ex(
        jd_ut,
        birth_data.place.latitude,
        birth_data.place.longitude,
        chart_settings.house_system.value,
        flags,
    )

    cusp_positions: dict[int, CuspPosition] = {}
    for house_number in range(1, 13):
        cusp_positions[house_number] = _build_cusp_position(house_number, cusps[house_number - 1])

    return cusp_positions


def get_cusp_data(
    birth_data: BirthData,
    cusp_number: int,
    chart_settings: ChartSettings = ChartSettings(),
) -> CuspPosition:
    return _get_cusp_or_raise(
        get_cusps_data(birth_data, chart_settings=chart_settings),
        cusp_number,
    )


def get_d9_planets_data(
    birth_data: BirthData,
    chart_settings: ChartSettings = ChartSettings(),
) -> dict[str, PlanetPosition]:
    d1_positions = get_planets_data(birth_data, chart_settings=chart_settings)

    d9_positions: dict[str, PlanetPosition] = {}
    for name, position in d1_positions.items():
        d9_longitude = _calc_d9_longitude(position.longitude)
        d9_positions[name] = _build_position(
            name,
            d9_longitude,
            is_retrograde=position.is_retrograde,
        )

    if birth_data.place is not None:
        jd_ut = _to_julian_day_ut(birth_data.dt)
        d1_ascendant_longitude = _calc_ascendant_longitude(
            jd_ut,
            birth_data.place,
            HouseSystem.WHOLE_SIGN,
        )
        d9_ascendant_longitude = _calc_d9_longitude(d1_ascendant_longitude)
        _assign_house_numbers_from_ascendant(d9_positions, d9_ascendant_longitude)

    return d9_positions


def get_d9_planet_data(
    birth_data: BirthData,
    planet_name: str,
    chart_settings: ChartSettings = ChartSettings(),
) -> PlanetPosition:
    return _get_planet_or_raise(
        get_d9_planets_data(birth_data, chart_settings=chart_settings),
        planet_name,
    )


def get_d9_cusps_data(
    birth_data: BirthData,
    chart_settings: ChartSettings = ChartSettings(),
) -> dict[int, D9CuspPosition]:
    d1_cusps = get_cusps_data(birth_data, chart_settings=chart_settings)

    d9_cusps: dict[int, D9CuspPosition] = {}
    for house_number, cusp in d1_cusps.items():
        d9_cusps[house_number] = _build_d9_cusp_position(
            house_number,
            _calc_d9_longitude(cusp.longitude),
        )

    return d9_cusps


def get_d9_cusp_data(
    birth_data: BirthData,
    cusp_number: int,
    chart_settings: ChartSettings = ChartSettings(),
) -> D9CuspPosition:
    return _get_cusp_or_raise(
        get_d9_cusps_data(birth_data, chart_settings=chart_settings),
        cusp_number,
    )


def get_house_significators_data(
    birth_data: BirthData,
    chart_settings: ChartSettings = ChartSettings(),
) -> dict[int, HouseSignificator]:
    planets = get_planets_data(
        birth_data,
        chart_settings=_get_significator_chart_settings(chart_settings),
    )
    cusps = get_cusps_data(birth_data, chart_settings=chart_settings)
    significator_planets = _get_significator_planets(planets)

    house_significators: dict[int, HouseSignificator] = {}
    for house_number in range(1, 13):
        owner = cusps[house_number].sign_lord
        occupants = _get_occupants(significator_planets, house_number)
        occupant_stars = {occupant.planet for occupant in occupants}

        a = tuple(
            position.planet
            for position in significator_planets.values()
            if position.star_lord in occupant_stars
        )
        b = tuple(position.planet for position in occupants)
        c = tuple(
            position.planet
            for position in significator_planets.values()
            if position.star_lord == owner
        )
        d = (owner,)

        house_significators[house_number] = HouseSignificator(
            house_number=house_number,
            a=a,
            b=b,
            c=c,
            d=d,
        )

    return house_significators


def get_house_significator_data(
    birth_data: BirthData,
    house_number: int,
    chart_settings: ChartSettings = ChartSettings(),
) -> HouseSignificator:
    return _get_house_significator_or_raise(
        get_house_significators_data(birth_data, chart_settings=chart_settings),
        house_number,
    )


def get_planet_significators_data(
    birth_data: BirthData,
    chart_settings: ChartSettings = ChartSettings(),
) -> dict[str, PlanetSignificator]:
    planets = get_planets_data(birth_data, chart_settings=chart_settings)
    house_significators = get_house_significators_data(
        birth_data,
        chart_settings=chart_settings,
    )
    significator_planets = _get_significator_planets(planets)

    planet_significators: dict[str, PlanetSignificator] = {}
    for planet_name in significator_planets:
        a = tuple(
            house_number
            for house_number, data in house_significators.items()
            if planet_name in data.a
        )
        b = tuple(
            house_number
            for house_number, data in house_significators.items()
            if planet_name in data.b
        )
        c = tuple(
            house_number
            for house_number, data in house_significators.items()
            if planet_name in data.c
        )
        d = tuple(
            house_number
            for house_number, data in house_significators.items()
            if planet_name in data.d
        )

        planet_significators[planet_name] = PlanetSignificator(
            planet=planet_name,
            a=a,
            b=b,
            c=c,
            d=d,
        )

    return planet_significators


def get_planet_significator_data(
    birth_data: BirthData,
    planet_name: str,
    chart_settings: ChartSettings = ChartSettings(),
) -> PlanetSignificator:
    return _get_planet_significator_or_raise(
        get_planet_significators_data(birth_data, chart_settings=chart_settings),
        planet_name,
    )


def _validate_coordinates(latitude: float | None, longitude: float | None) -> None:
    if latitude is None and longitude is None:
        return

    if latitude is None or longitude is None:
        raise ValueError("latitude and longitude must be provided together")

    if not -90.0 <= latitude <= 90.0:
        raise ValueError("latitude must be between -90 and 90 degrees")

    if not -180.0 <= longitude <= 180.0:
        raise ValueError("longitude must be between -180 and 180 degrees")


def _get_planet_or_raise(
    positions: dict[str, PlanetPosition],
    planet_name: str,
) -> PlanetPosition:
    try:
        return positions[planet_name]
    except KeyError as exc:
        available_planets = ", ".join(positions.keys())
        raise ValueError(
            f"unknown planet_name '{planet_name}'. Available planets: {available_planets}"
        ) from exc


def _get_cusp_or_raise(
    cusps: dict[int, CuspPosition] | dict[int, D9CuspPosition],
    cusp_number: int,
) -> CuspPosition | D9CuspPosition:
    if cusp_number not in range(1, 13):
        raise ValueError("cusp_number must be between 1 and 12")

    return cusps[cusp_number]


def _get_house_significator_or_raise(
    house_significators: dict[int, HouseSignificator],
    house_number: int,
) -> HouseSignificator:
    if house_number not in range(1, 13):
        raise ValueError("house_number must be between 1 and 12")

    return house_significators[house_number]


def _get_planet_significator_or_raise(
    planet_significators: dict[str, PlanetSignificator],
    planet_name: str,
) -> PlanetSignificator:
    try:
        return planet_significators[planet_name]
    except KeyError as exc:
        available_planets = ", ".join(planet_significators.keys())
        raise ValueError(
            f"unknown planet_name '{planet_name}'. Available planets: {available_planets}"
        ) from exc


def _get_significator_planets(
    positions: dict[str, PlanetPosition],
) -> dict[str, PlanetPosition]:
    return {
        name: position
        for name, position in positions.items()
        if name in SIGNIFICATOR_BODY_NAMES
    }


def _get_significator_chart_settings(chart_settings: ChartSettings) -> ChartSettings:
    return replace(
        chart_settings,
        planet_house_system=chart_settings.house_system,
    )


def _get_occupants(
    positions: dict[str, PlanetPosition],
    house_number: int,
) -> list[PlanetPosition]:
    return [
        position
        for position in positions.values()
        if position.house_number == house_number
    ]


def _to_julian_day_ut(dt: datetime) -> float:
    if dt.tzinfo is None or dt.utcoffset() is None:
        raise ValueError("dt must be timezone-aware")

    dt_utc = dt.astimezone(timezone.utc)
    hour = (
        dt_utc.hour
        + dt_utc.minute / 60.0
        + dt_utc.second / 3600.0
        + dt_utc.microsecond / 3_600_000_000.0
    )
    return swe.julday(dt_utc.year, dt_utc.month, dt_utc.day, hour)


def _calc_planet_data(jd_ut: float, body: int, flags: int) -> tuple[float, bool]:
    values, _ = swe.calc_ut(jd_ut, body, flags)
    longitude = values[0] % 360.0
    speed_in_longitude = values[3]
    return longitude, speed_in_longitude < 0.0


def _build_position(
    planet: str,
    longitude: float,
    is_retrograde: bool = False,
    house_number: int | None = None,
) -> PlanetPosition:
    sign_as_number = int(longitude // 30) + 1
    nakshatra_name, nakshatra_pada = _calc_nakshatra_and_pada(longitude)
    position = longitude % 30.0
    sign_lord = SIGN_LORDS[sign_as_number - 1]
    star_lord, sub_lord, sub_sub_lord, sub_sub_sub_lord = _calc_kp_lords(longitude)
    return PlanetPosition(
        planet=planet,
        longitude=longitude,
        sign_as_name=SIGNS[sign_as_number - 1],
        sign_as_number=sign_as_number,
        nakshatra_name=nakshatra_name,
        nakshatra_pada=nakshatra_pada,
        position=position,
        is_retrograde=is_retrograde,
        house_number=house_number,
        sign_lord=sign_lord,
        star_lord=star_lord,
        sub_lord=sub_lord,
        sub_sub_lord=sub_sub_lord,
        sub_sub_sub_lord=sub_sub_sub_lord,
    )


def _calc_nakshatra_and_pada(longitude: float) -> tuple[str, int]:
    normalized = longitude % 360.0
    nakshatra_index = int(normalized // NAKSHATRA_SPAN)
    nakshatra_name = NAKSHATRA_NAMES[nakshatra_index]
    longitude_in_nakshatra = normalized % NAKSHATRA_SPAN
    pada = int(longitude_in_nakshatra // PADA_SPAN) + 1
    return nakshatra_name, pada


def _assign_house_numbers(
    positions: dict[str, PlanetPosition],
    jd_ut: float,
    place: Place,
    chart_settings: ChartSettings,
) -> None:
    if chart_settings.planet_house_system is HouseSystem.WHOLE_SIGN:
        ascendant_longitude = _calc_ascendant_longitude(jd_ut, place, HouseSystem.WHOLE_SIGN)
        _assign_house_numbers_from_ascendant(positions, ascendant_longitude)
        return

    cusps, _ascmc = swe.houses_ex(
        jd_ut,
        place.latitude,
        place.longitude,
        chart_settings.planet_house_system.value,
        swe.FLG_SIDEREAL,
    )
    cusp_longitudes = [cusp % 360.0 for cusp in cusps]
    _assign_house_numbers_from_cusps(positions, cusp_longitudes)


def _assign_house_numbers_from_ascendant(
    positions: dict[str, PlanetPosition],
    ascendant_longitude: float,
) -> None:
    ascendant_sign_number = int(ascendant_longitude // 30) + 1

    for name, position in list(positions.items()):
        house_number = ((position.sign_as_number - ascendant_sign_number) % 12) + 1
        positions[name] = _build_position(
            position.planet,
            position.longitude,
            is_retrograde=position.is_retrograde,
            house_number=house_number,
        )


def _assign_house_numbers_from_cusps(
    positions: dict[str, PlanetPosition],
    cusp_longitudes: list[float],
) -> None:
    for name, position in list(positions.items()):
        house_number = _get_house_number_from_cusps(position.longitude, cusp_longitudes)
        positions[name] = _build_position(
            position.planet,
            position.longitude,
            is_retrograde=position.is_retrograde,
            house_number=house_number,
        )


def _get_house_number_from_cusps(longitude: float, cusp_longitudes: list[float]) -> int:
    for index in range(12):
        start = cusp_longitudes[index]
        end = cusp_longitudes[(index + 1) % 12]
        if _longitude_in_arc(longitude, start, end):
            return index + 1
    return 12


def _longitude_in_arc(longitude: float, start: float, end: float) -> bool:
    if start <= end:
        return start <= longitude < end
    return longitude >= start or longitude < end


def _build_cusp_position(house_number: int, longitude: float) -> CuspPosition:
    sign_as_number = int(longitude // 30) + 1
    nakshatra_name, nakshatra_pada = _calc_nakshatra_and_pada(longitude)
    position = longitude % 30.0
    sign_lord = SIGN_LORDS[sign_as_number - 1]
    star_lord, sub_lord, sub_sub_lord, sub_sub_sub_lord = _calc_kp_lords(longitude)
    return CuspPosition(
        house_number=house_number,
        longitude=longitude,
        sign_as_name=SIGNS[sign_as_number - 1],
        sign_as_number=sign_as_number,
        nakshatra_name=nakshatra_name,
        nakshatra_pada=nakshatra_pada,
        position=position,
        sign_lord=sign_lord,
        star_lord=star_lord,
        sub_lord=sub_lord,
        sub_sub_lord=sub_sub_lord,
        sub_sub_sub_lord=sub_sub_sub_lord,
    )


def _build_d9_cusp_position(house_number: int, longitude: float) -> D9CuspPosition:
    sign_as_number = int(longitude // 30) + 1
    position = longitude % 30.0
    return D9CuspPosition(
        house_number=house_number,
        longitude=longitude,
        sign_as_name=SIGNS[sign_as_number - 1],
        sign_as_number=sign_as_number,
        position=position,
    )




def _calc_kp_lords(longitude: float) -> tuple[str, str, str, str]:
    nakshatra_index = int((longitude % 360.0) // NAKSHATRA_SPAN)
    star_lord = KP_LORD_SEQUENCE[nakshatra_index % len(KP_LORD_SEQUENCE)]
    longitude_in_nakshatra = (longitude % NAKSHATRA_SPAN)
    sub_lord, longitude_in_sub, sub_span = _find_kp_segment(
        longitude_in_nakshatra,
        span=NAKSHATRA_SPAN,
        start_lord=star_lord,
    )
    sub_sub_lord, _longitude_in_sub_sub, _sub_sub_span = _find_kp_segment(
        longitude_in_sub,
        span=sub_span,
        start_lord=sub_lord,
    )
    sub_sub_sub_lord, _longitude_in_sub_sub_sub, _sub_sub_sub_span = _find_kp_segment(
        _longitude_in_sub_sub,
        span=_sub_sub_span,
        start_lord=sub_sub_lord,
    )
    return star_lord, sub_lord, sub_sub_lord, sub_sub_sub_lord


def _find_kp_segment(
    offset: float,
    span: float,
    start_lord: str,
) -> tuple[str, float, float]:
    start_index = KP_LORD_SEQUENCE.index(start_lord)
    traversed = 0.0

    for step in range(len(KP_LORD_SEQUENCE)):
        lord = KP_LORD_SEQUENCE[(start_index + step) % len(KP_LORD_SEQUENCE)]
        segment_span = span * VIMSHOTTARI_YEARS[lord] / 120.0
        next_traversed = traversed + segment_span

        if offset < next_traversed or step == len(KP_LORD_SEQUENCE) - 1:
            return lord, offset - traversed, segment_span

        traversed = next_traversed

    raise ValueError("unable to determine KP segment")


def _calc_upaketu_longitude(sun_longitude: float) -> float:
    return (sun_longitude - 30.0) % 360.0


def _calc_d9_longitude(longitude: float) -> float:
    normalized = longitude % 360.0
    sign_as_number = int(normalized // 30.0) + 1
    position_in_sign = normalized % 30.0
    navamsa_index = int(position_in_sign // NAVAMSA_SPAN)
    position_in_navamsa = (position_in_sign % NAVAMSA_SPAN) * 9.0

    if sign_as_number in (1, 4, 7, 10):
        starting_sign = sign_as_number
    elif sign_as_number in (2, 5, 8, 11):
        starting_sign = ((sign_as_number + 8 - 1) % 12) + 1
    else:
        starting_sign = ((sign_as_number + 4 - 1) % 12) + 1

    d9_sign_as_number = ((starting_sign + navamsa_index - 1) % 12) + 1
    return ((d9_sign_as_number - 1) * 30.0 + position_in_navamsa) % 360.0


def _calc_part_of_fortune_longitude(
    birth_data: BirthData,
    ascendant_longitude: float,
    sun_longitude: float,
    moon_longitude: float,
    chart_settings: ChartSettings,
) -> float:
    return _build_part_of_fortune_longitude(
        ascendant_longitude=ascendant_longitude,
        sun_longitude=sun_longitude,
        moon_longitude=moon_longitude,
        is_day_birth=_is_day_birth(birth_data),
        chart_settings=chart_settings,
    )


def _build_part_of_fortune_longitude(
    ascendant_longitude: float,
    sun_longitude: float,
    moon_longitude: float,
    is_day_birth: bool,
    chart_settings: ChartSettings | None = None,
) -> float:
    settings = chart_settings or ChartSettings()
    formula = settings.part_of_fortune

    if formula is None:
        formula = (
            Formula.DAY_FORMULA
            if is_day_birth
            else Formula.NIGHT_FORMULA
        )

    return (
        ascendant_longitude * formula.ascendant_sign
        + sun_longitude * formula.sun_sign
        + moon_longitude * formula.moon_sign
    ) % 360.0


def _calc_gulika_longitude(birth_data: BirthData, chart_settings: ChartSettings) -> float:
    place = birth_data.place
    if place is None:
        raise ValueError("place is required to calculate Gulika")

    birth_dt = birth_data.dt
    local_midnight = birth_dt.replace(hour=0, minute=0, second=0, microsecond=0)
    previous_midnight = local_midnight - timedelta(days=1)
    next_midnight = local_midnight + timedelta(days=1)

    birth_jd_ut = _to_julian_day_ut(birth_dt)
    sunrise_today = _calc_solar_event_jd(local_midnight, place, swe.CALC_RISE)
    sunset_today = _calc_solar_event_jd(local_midnight, place, swe.CALC_SET)

    if sunrise_today <= birth_jd_ut < sunset_today:
        weekday = birth_dt.weekday()
        period_start = sunrise_today
        period_end = sunset_today
        segment_number = _get_gulika_segment_number(weekday, is_day_birth=True)
    elif birth_jd_ut < sunrise_today:
        sunset_previous = _calc_solar_event_jd(previous_midnight, place, swe.CALC_SET)
        weekday = (birth_dt.weekday() - 1) % 7
        period_start = sunset_previous
        period_end = sunrise_today
        segment_number = _get_gulika_segment_number(weekday, is_day_birth=False)
    else:
        sunrise_next = _calc_solar_event_jd(next_midnight, place, swe.CALC_RISE)
        weekday = birth_dt.weekday()
        period_start = sunset_today
        period_end = sunrise_next
        segment_number = _get_gulika_segment_number(weekday, is_day_birth=False)

    segment_length = (period_end - period_start) / 8.0
    segment_offset = segment_number - 1
    if chart_settings.gulika_mode is GulikaMode.END_OF_SATURN_SEGMENT:
        segment_offset += 1

    gulika_jd_ut = period_start + segment_offset * segment_length
    return _calc_ascendant_longitude(gulika_jd_ut, place, chart_settings.house_system)


def _calc_solar_event_jd(start_dt: datetime, place: Place, rsmi: int) -> float:
    geopos = (place.longitude, place.latitude, 0.0)
    start_jd_ut = _to_julian_day_ut(start_dt)
    result, event_times = swe.rise_trans(start_jd_ut, swe.SUN, rsmi, geopos)
    if result != 0:
        raise ValueError("unable to calculate local sunrise or sunset for Gulika")
    return event_times[0]


def _is_day_birth(birth_data: BirthData) -> bool:
    place = birth_data.place
    if place is None:
        raise ValueError("place is required to determine day or night birth")

    birth_dt = birth_data.dt
    local_midnight = birth_dt.replace(hour=0, minute=0, second=0, microsecond=0)
    birth_jd_ut = _to_julian_day_ut(birth_dt)
    sunrise_today = _calc_solar_event_jd(local_midnight, place, swe.CALC_RISE)
    sunset_today = _calc_solar_event_jd(local_midnight, place, swe.CALC_SET)
    return sunrise_today <= birth_jd_ut < sunset_today


def _get_gulika_segment_number(weekday: int, is_day_birth: bool) -> int:
    day_segments = (6, 5, 4, 3, 2, 1, 7)
    night_segments = (2, 1, 7, 6, 5, 4, 3)
    return day_segments[weekday] if is_day_birth else night_segments[weekday]


def _calc_ascendant_longitude(
    jd_ut: float,
    place: Place,
    house_system: HouseSystem = HouseSystem.PLACIDUS,
) -> float:
    _cusps, ascmc = swe.houses_ex(
        jd_ut,
        place.latitude,
        place.longitude,
        house_system.value,
        swe.FLG_SIDEREAL,
    )
    return ascmc[0] % 360.0


def format_degree_as_dms(value: float) -> str:
    total_seconds = round(value * 3600)
    degrees, remainder = divmod(total_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)

    if seconds == 60:
        seconds = 0
        minutes += 1

    if minutes == 60:
        minutes = 0
        degrees += 1

    return f"{degrees:02d}:{minutes:02d}:{seconds:02d}"
