from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.post_public_webhook_create_body import PostPublicWebhookCreateBody
from ...models.post_public_webhook_create_response_200 import PostPublicWebhookCreateResponse200
from ...models.post_public_webhook_create_response_400 import PostPublicWebhookCreateResponse400
from ...models.post_public_webhook_create_response_401 import PostPublicWebhookCreateResponse401
from ...models.post_public_webhook_create_response_403 import PostPublicWebhookCreateResponse403
from ...models.post_public_webhook_create_response_500 import PostPublicWebhookCreateResponse500
from typing import cast



def _get_kwargs(
    *,
    body: PostPublicWebhookCreateBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/public/webhook/create",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> PostPublicWebhookCreateResponse200 | PostPublicWebhookCreateResponse400 | PostPublicWebhookCreateResponse401 | PostPublicWebhookCreateResponse403 | PostPublicWebhookCreateResponse500 | None:
    if response.status_code == 200:
        response_200 = PostPublicWebhookCreateResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = PostPublicWebhookCreateResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = PostPublicWebhookCreateResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = PostPublicWebhookCreateResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 500:
        response_500 = PostPublicWebhookCreateResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[PostPublicWebhookCreateResponse200 | PostPublicWebhookCreateResponse400 | PostPublicWebhookCreateResponse401 | PostPublicWebhookCreateResponse403 | PostPublicWebhookCreateResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostPublicWebhookCreateBody,

) -> Response[PostPublicWebhookCreateResponse200 | PostPublicWebhookCreateResponse400 | PostPublicWebhookCreateResponse401 | PostPublicWebhookCreateResponse403 | PostPublicWebhookCreateResponse500]:
    """ create

     Create a new webhook for the team (team API key).

    Args:
        body (PostPublicWebhookCreateBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostPublicWebhookCreateResponse200 | PostPublicWebhookCreateResponse400 | PostPublicWebhookCreateResponse401 | PostPublicWebhookCreateResponse403 | PostPublicWebhookCreateResponse500]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: PostPublicWebhookCreateBody,

) -> PostPublicWebhookCreateResponse200 | PostPublicWebhookCreateResponse400 | PostPublicWebhookCreateResponse401 | PostPublicWebhookCreateResponse403 | PostPublicWebhookCreateResponse500 | None:
    """ create

     Create a new webhook for the team (team API key).

    Args:
        body (PostPublicWebhookCreateBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostPublicWebhookCreateResponse200 | PostPublicWebhookCreateResponse400 | PostPublicWebhookCreateResponse401 | PostPublicWebhookCreateResponse403 | PostPublicWebhookCreateResponse500
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostPublicWebhookCreateBody,

) -> Response[PostPublicWebhookCreateResponse200 | PostPublicWebhookCreateResponse400 | PostPublicWebhookCreateResponse401 | PostPublicWebhookCreateResponse403 | PostPublicWebhookCreateResponse500]:
    """ create

     Create a new webhook for the team (team API key).

    Args:
        body (PostPublicWebhookCreateBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostPublicWebhookCreateResponse200 | PostPublicWebhookCreateResponse400 | PostPublicWebhookCreateResponse401 | PostPublicWebhookCreateResponse403 | PostPublicWebhookCreateResponse500]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: PostPublicWebhookCreateBody,

) -> PostPublicWebhookCreateResponse200 | PostPublicWebhookCreateResponse400 | PostPublicWebhookCreateResponse401 | PostPublicWebhookCreateResponse403 | PostPublicWebhookCreateResponse500 | None:
    """ create

     Create a new webhook for the team (team API key).

    Args:
        body (PostPublicWebhookCreateBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostPublicWebhookCreateResponse200 | PostPublicWebhookCreateResponse400 | PostPublicWebhookCreateResponse401 | PostPublicWebhookCreateResponse403 | PostPublicWebhookCreateResponse500
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
