from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.post_public_authentication_create_iframe_token_body import PostPublicAuthenticationCreateIframeTokenBody
from ...models.post_public_authentication_create_iframe_token_response_200 import PostPublicAuthenticationCreateIframeTokenResponse200
from ...models.post_public_authentication_create_iframe_token_response_400 import PostPublicAuthenticationCreateIframeTokenResponse400
from ...models.post_public_authentication_create_iframe_token_response_401 import PostPublicAuthenticationCreateIframeTokenResponse401
from ...models.post_public_authentication_create_iframe_token_response_403 import PostPublicAuthenticationCreateIframeTokenResponse403
from ...models.post_public_authentication_create_iframe_token_response_500 import PostPublicAuthenticationCreateIframeTokenResponse500
from typing import cast



def _get_kwargs(
    *,
    body: PostPublicAuthenticationCreateIframeTokenBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/public/authentication/create-iframe-token",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> PostPublicAuthenticationCreateIframeTokenResponse200 | PostPublicAuthenticationCreateIframeTokenResponse400 | PostPublicAuthenticationCreateIframeTokenResponse401 | PostPublicAuthenticationCreateIframeTokenResponse403 | PostPublicAuthenticationCreateIframeTokenResponse500 | None:
    if response.status_code == 200:
        response_200 = PostPublicAuthenticationCreateIframeTokenResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = PostPublicAuthenticationCreateIframeTokenResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = PostPublicAuthenticationCreateIframeTokenResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = PostPublicAuthenticationCreateIframeTokenResponse403.from_dict(response.json())



        return response_403

    if response.status_code == 500:
        response_500 = PostPublicAuthenticationCreateIframeTokenResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[PostPublicAuthenticationCreateIframeTokenResponse200 | PostPublicAuthenticationCreateIframeTokenResponse400 | PostPublicAuthenticationCreateIframeTokenResponse401 | PostPublicAuthenticationCreateIframeTokenResponse403 | PostPublicAuthenticationCreateIframeTokenResponse500]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostPublicAuthenticationCreateIframeTokenBody,

) -> Response[PostPublicAuthenticationCreateIframeTokenResponse200 | PostPublicAuthenticationCreateIframeTokenResponse400 | PostPublicAuthenticationCreateIframeTokenResponse401 | PostPublicAuthenticationCreateIframeTokenResponse403 | PostPublicAuthenticationCreateIframeTokenResponse500]:
    """ create-iframe-token

     Create an iframe token for embedding the sign flow for a specific envelope and signer.

    Args:
        body (PostPublicAuthenticationCreateIframeTokenBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostPublicAuthenticationCreateIframeTokenResponse200 | PostPublicAuthenticationCreateIframeTokenResponse400 | PostPublicAuthenticationCreateIframeTokenResponse401 | PostPublicAuthenticationCreateIframeTokenResponse403 | PostPublicAuthenticationCreateIframeTokenResponse500]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: PostPublicAuthenticationCreateIframeTokenBody,

) -> PostPublicAuthenticationCreateIframeTokenResponse200 | PostPublicAuthenticationCreateIframeTokenResponse400 | PostPublicAuthenticationCreateIframeTokenResponse401 | PostPublicAuthenticationCreateIframeTokenResponse403 | PostPublicAuthenticationCreateIframeTokenResponse500 | None:
    """ create-iframe-token

     Create an iframe token for embedding the sign flow for a specific envelope and signer.

    Args:
        body (PostPublicAuthenticationCreateIframeTokenBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostPublicAuthenticationCreateIframeTokenResponse200 | PostPublicAuthenticationCreateIframeTokenResponse400 | PostPublicAuthenticationCreateIframeTokenResponse401 | PostPublicAuthenticationCreateIframeTokenResponse403 | PostPublicAuthenticationCreateIframeTokenResponse500
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostPublicAuthenticationCreateIframeTokenBody,

) -> Response[PostPublicAuthenticationCreateIframeTokenResponse200 | PostPublicAuthenticationCreateIframeTokenResponse400 | PostPublicAuthenticationCreateIframeTokenResponse401 | PostPublicAuthenticationCreateIframeTokenResponse403 | PostPublicAuthenticationCreateIframeTokenResponse500]:
    """ create-iframe-token

     Create an iframe token for embedding the sign flow for a specific envelope and signer.

    Args:
        body (PostPublicAuthenticationCreateIframeTokenBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostPublicAuthenticationCreateIframeTokenResponse200 | PostPublicAuthenticationCreateIframeTokenResponse400 | PostPublicAuthenticationCreateIframeTokenResponse401 | PostPublicAuthenticationCreateIframeTokenResponse403 | PostPublicAuthenticationCreateIframeTokenResponse500]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: PostPublicAuthenticationCreateIframeTokenBody,

) -> PostPublicAuthenticationCreateIframeTokenResponse200 | PostPublicAuthenticationCreateIframeTokenResponse400 | PostPublicAuthenticationCreateIframeTokenResponse401 | PostPublicAuthenticationCreateIframeTokenResponse403 | PostPublicAuthenticationCreateIframeTokenResponse500 | None:
    """ create-iframe-token

     Create an iframe token for embedding the sign flow for a specific envelope and signer.

    Args:
        body (PostPublicAuthenticationCreateIframeTokenBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostPublicAuthenticationCreateIframeTokenResponse200 | PostPublicAuthenticationCreateIframeTokenResponse400 | PostPublicAuthenticationCreateIframeTokenResponse401 | PostPublicAuthenticationCreateIframeTokenResponse403 | PostPublicAuthenticationCreateIframeTokenResponse500
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
