from enum import Enum

class PostPublicEnvelopeGetResponse200DocumentsItemBlocksAdditionalPropertyItemType3Type(str, Enum):
    SIGNATURE = "signature"

    def __str__(self) -> str:
        return str(self.value)
