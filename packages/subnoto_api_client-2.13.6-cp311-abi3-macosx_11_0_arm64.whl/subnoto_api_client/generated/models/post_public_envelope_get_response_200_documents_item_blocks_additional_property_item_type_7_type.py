from enum import Enum

class PostPublicEnvelopeGetResponse200DocumentsItemBlocksAdditionalPropertyItemType7Type(str, Enum):
    CHECKBOX = "checkbox"

    def __str__(self) -> str:
        return str(self.value)
