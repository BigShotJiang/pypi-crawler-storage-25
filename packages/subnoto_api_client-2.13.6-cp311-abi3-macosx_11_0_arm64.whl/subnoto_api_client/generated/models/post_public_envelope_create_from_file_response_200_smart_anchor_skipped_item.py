from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.post_public_envelope_create_from_file_response_200_smart_anchor_skipped_item_reason import PostPublicEnvelopeCreateFromFileResponse200SmartAnchorSkippedItemReason






T = TypeVar("T", bound="PostPublicEnvelopeCreateFromFileResponse200SmartAnchorSkippedItem")



@_attrs_define
class PostPublicEnvelopeCreateFromFileResponse200SmartAnchorSkippedItem:
    """ 
        Attributes:
            email (str):
            block_type (str):
            page_number (float):
            reason (PostPublicEnvelopeCreateFromFileResponse200SmartAnchorSkippedItemReason):
     """

    email: str
    block_type: str
    page_number: float
    reason: PostPublicEnvelopeCreateFromFileResponse200SmartAnchorSkippedItemReason





    def to_dict(self) -> dict[str, Any]:
        email = self.email

        block_type = self.block_type

        page_number = self.page_number

        reason = self.reason.value


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "email": email,
            "blockType": block_type,
            "pageNumber": page_number,
            "reason": reason,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        email = d.pop("email")

        block_type = d.pop("blockType")

        page_number = d.pop("pageNumber")

        reason = PostPublicEnvelopeCreateFromFileResponse200SmartAnchorSkippedItemReason(d.pop("reason"))




        post_public_envelope_create_from_file_response_200_smart_anchor_skipped_item = cls(
            email=email,
            block_type=block_type,
            page_number=page_number,
            reason=reason,
        )

        return post_public_envelope_create_from_file_response_200_smart_anchor_skipped_item

