from enum import Enum

class PostPublicEnvelopeAddBlocksBodyBlocksItemType5Type(str, Enum):
    NUMBER = "number"

    def __str__(self) -> str:
        return str(self.value)
