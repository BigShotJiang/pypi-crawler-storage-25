from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="PostPublicEnvelopeCreateFromFileResponse200SmartAnchorRecipientsItem")



@_attrs_define
class PostPublicEnvelopeCreateFromFileResponse200SmartAnchorRecipientsItem:
    """ 
        Attributes:
            email (str):
            firstname (str):
            lastname (str):
            order (float):
     """

    email: str
    firstname: str
    lastname: str
    order: float





    def to_dict(self) -> dict[str, Any]:
        email = self.email

        firstname = self.firstname

        lastname = self.lastname

        order = self.order


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "email": email,
            "firstname": firstname,
            "lastname": lastname,
            "order": order,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        email = d.pop("email")

        firstname = d.pop("firstname")

        lastname = d.pop("lastname")

        order = d.pop("order")

        post_public_envelope_create_from_file_response_200_smart_anchor_recipients_item = cls(
            email=email,
            firstname=firstname,
            lastname=lastname,
            order=order,
        )

        return post_public_envelope_create_from_file_response_200_smart_anchor_recipients_item

