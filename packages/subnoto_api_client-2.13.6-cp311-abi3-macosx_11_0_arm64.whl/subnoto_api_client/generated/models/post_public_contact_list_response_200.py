from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.post_public_contact_list_response_200_contacts_item import PostPublicContactListResponse200ContactsItem
  from ..models.post_public_contact_list_response_200_pagination import PostPublicContactListResponse200Pagination





T = TypeVar("T", bound="PostPublicContactListResponse200")



@_attrs_define
class PostPublicContactListResponse200:
    """ 
        Attributes:
            contacts (list[PostPublicContactListResponse200ContactsItem]): The list of contacts.
            pagination (PostPublicContactListResponse200Pagination):
     """

    contacts: list[PostPublicContactListResponse200ContactsItem]
    pagination: PostPublicContactListResponse200Pagination





    def to_dict(self) -> dict[str, Any]:
        from ..models.post_public_contact_list_response_200_contacts_item import PostPublicContactListResponse200ContactsItem
        from ..models.post_public_contact_list_response_200_pagination import PostPublicContactListResponse200Pagination
        contacts = []
        for contacts_item_data in self.contacts:
            contacts_item = contacts_item_data.to_dict()
            contacts.append(contacts_item)



        pagination = self.pagination.to_dict()


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "contacts": contacts,
            "pagination": pagination,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_public_contact_list_response_200_contacts_item import PostPublicContactListResponse200ContactsItem
        from ..models.post_public_contact_list_response_200_pagination import PostPublicContactListResponse200Pagination
        d = dict(src_dict)
        contacts = []
        _contacts = d.pop("contacts")
        for contacts_item_data in (_contacts):
            contacts_item = PostPublicContactListResponse200ContactsItem.from_dict(contacts_item_data)



            contacts.append(contacts_item)


        pagination = PostPublicContactListResponse200Pagination.from_dict(d.pop("pagination"))




        post_public_contact_list_response_200 = cls(
            contacts=contacts,
            pagination=pagination,
        )

        return post_public_contact_list_response_200

