from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.post_public_envelope_create_from_file_response_200_smart_anchor import PostPublicEnvelopeCreateFromFileResponse200SmartAnchor





T = TypeVar("T", bound="PostPublicEnvelopeCreateFromFileResponse200")



@_attrs_define
class PostPublicEnvelopeCreateFromFileResponse200:
    """ 
        Attributes:
            envelope_uuid (str): The unique identifier of the created envelope.
            document_uuid (str): The unique identifier of the first document.
            smart_anchor (PostPublicEnvelopeCreateFromFileResponse200SmartAnchor | Unset): When detectSmartAnchors was
                enabled, contains blocks and recipients added from Smart Anchors and any skipped anchors with reasons.
     """

    envelope_uuid: str
    document_uuid: str
    smart_anchor: PostPublicEnvelopeCreateFromFileResponse200SmartAnchor | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        from ..models.post_public_envelope_create_from_file_response_200_smart_anchor import PostPublicEnvelopeCreateFromFileResponse200SmartAnchor
        envelope_uuid = self.envelope_uuid

        document_uuid = self.document_uuid

        smart_anchor: dict[str, Any] | Unset = UNSET
        if not isinstance(self.smart_anchor, Unset):
            smart_anchor = self.smart_anchor.to_dict()


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "envelopeUuid": envelope_uuid,
            "documentUuid": document_uuid,
        })
        if smart_anchor is not UNSET:
            field_dict["smartAnchor"] = smart_anchor

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_public_envelope_create_from_file_response_200_smart_anchor import PostPublicEnvelopeCreateFromFileResponse200SmartAnchor
        d = dict(src_dict)
        envelope_uuid = d.pop("envelopeUuid")

        document_uuid = d.pop("documentUuid")

        _smart_anchor = d.pop("smartAnchor", UNSET)
        smart_anchor: PostPublicEnvelopeCreateFromFileResponse200SmartAnchor | Unset
        if isinstance(_smart_anchor,  Unset):
            smart_anchor = UNSET
        else:
            smart_anchor = PostPublicEnvelopeCreateFromFileResponse200SmartAnchor.from_dict(_smart_anchor)




        post_public_envelope_create_from_file_response_200 = cls(
            envelope_uuid=envelope_uuid,
            document_uuid=document_uuid,
            smart_anchor=smart_anchor,
        )

        return post_public_envelope_create_from_file_response_200

