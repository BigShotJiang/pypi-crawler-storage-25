from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.post_public_envelope_get_response_401_error_code import PostPublicEnvelopeGetResponse401ErrorCode
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.post_public_envelope_get_response_401_error_details_item import PostPublicEnvelopeGetResponse401ErrorDetailsItem





T = TypeVar("T", bound="PostPublicEnvelopeGetResponse401Error")



@_attrs_define
class PostPublicEnvelopeGetResponse401Error:
    """ 
        Attributes:
            code (PostPublicEnvelopeGetResponse401ErrorCode): The error code
            message (str): The error message
            suggestion (str): A suggestion to resolve the error
            documentation_url (str): A URL to the documentation
            details (list[PostPublicEnvelopeGetResponse401ErrorDetailsItem] | Unset): Optional validation details (e.g. for
                INVALID_REQUEST_FORMAT)
     """

    code: PostPublicEnvelopeGetResponse401ErrorCode
    message: str
    suggestion: str
    documentation_url: str
    details: list[PostPublicEnvelopeGetResponse401ErrorDetailsItem] | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        from ..models.post_public_envelope_get_response_401_error_details_item import PostPublicEnvelopeGetResponse401ErrorDetailsItem
        code = self.code.value

        message = self.message

        suggestion = self.suggestion

        documentation_url = self.documentation_url

        details: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.details, Unset):
            details = []
            for details_item_data in self.details:
                details_item = details_item_data.to_dict()
                details.append(details_item)




        field_dict: dict[str, Any] = {}

        field_dict.update({
            "code": code,
            "message": message,
            "suggestion": suggestion,
            "documentationUrl": documentation_url,
        })
        if details is not UNSET:
            field_dict["details"] = details

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_public_envelope_get_response_401_error_details_item import PostPublicEnvelopeGetResponse401ErrorDetailsItem
        d = dict(src_dict)
        code = PostPublicEnvelopeGetResponse401ErrorCode(d.pop("code"))




        message = d.pop("message")

        suggestion = d.pop("suggestion")

        documentation_url = d.pop("documentationUrl")

        _details = d.pop("details", UNSET)
        details: list[PostPublicEnvelopeGetResponse401ErrorDetailsItem] | Unset = UNSET
        if _details is not UNSET:
            details = []
            for details_item_data in _details:
                details_item = PostPublicEnvelopeGetResponse401ErrorDetailsItem.from_dict(details_item_data)



                details.append(details_item)


        post_public_envelope_get_response_401_error = cls(
            code=code,
            message=message,
            suggestion=suggestion,
            documentation_url=documentation_url,
            details=details,
        )

        return post_public_envelope_get_response_401_error

