from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.post_public_envelope_get_response_200_recipients_item_language import PostPublicEnvelopeGetResponse200RecipientsItemLanguage
from ..models.post_public_envelope_get_response_200_recipients_item_role import PostPublicEnvelopeGetResponse200RecipientsItemRole
from ..models.post_public_envelope_get_response_200_recipients_item_status import PostPublicEnvelopeGetResponse200RecipientsItemStatus
from ..models.post_public_envelope_get_response_200_recipients_item_verification_type import PostPublicEnvelopeGetResponse200RecipientsItemVerificationType
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.post_public_envelope_get_response_200_recipients_item_invitation import PostPublicEnvelopeGetResponse200RecipientsItemInvitation





T = TypeVar("T", bound="PostPublicEnvelopeGetResponse200RecipientsItem")



@_attrs_define
class PostPublicEnvelopeGetResponse200RecipientsItem:
    """ 
        Attributes:
            email (str): Recipient email address.
            firstname (str): Recipient first name.
            lastname (str): Recipient last name.
            phone (str): Recipient phone number.
            role (PostPublicEnvelopeGetResponse200RecipientsItemRole): Recipient role in the envelope workflow.
            order (float): Recipient routing order in sequential workflows.
            associated_contact (bool): Whether this recipient is linked to an existing contact.
            status (PostPublicEnvelopeGetResponse200RecipientsItemStatus): Current recipient completion status.
            language (PostPublicEnvelopeGetResponse200RecipientsItemLanguage): Recipient language preference.
            verification_type (PostPublicEnvelopeGetResponse200RecipientsItemVerificationType): Default verification type
                for this participant on the envelope; it is the configuration applied when creating or refreshing invitations
                and links.
            job_title (str | Unset): Recipient job title.
            company (str | Unset): Recipient company name.
            address_line_1 (str | Unset): Recipient primary address line.
            address_line_2 (str | Unset): Recipient secondary address line.
            zip_code (str | Unset): Recipient postal or ZIP code.
            city (str | Unset): Recipient city.
            country (str | Unset): Recipient country.
            invitation (PostPublicEnvelopeGetResponse200RecipientsItemInvitation | Unset): Metadata for the recipient's
                current valid invitation link, when one exists.
     """

    email: str
    firstname: str
    lastname: str
    phone: str
    role: PostPublicEnvelopeGetResponse200RecipientsItemRole
    order: float
    associated_contact: bool
    status: PostPublicEnvelopeGetResponse200RecipientsItemStatus
    language: PostPublicEnvelopeGetResponse200RecipientsItemLanguage
    verification_type: PostPublicEnvelopeGetResponse200RecipientsItemVerificationType
    job_title: str | Unset = UNSET
    company: str | Unset = UNSET
    address_line_1: str | Unset = UNSET
    address_line_2: str | Unset = UNSET
    zip_code: str | Unset = UNSET
    city: str | Unset = UNSET
    country: str | Unset = UNSET
    invitation: PostPublicEnvelopeGetResponse200RecipientsItemInvitation | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        from ..models.post_public_envelope_get_response_200_recipients_item_invitation import PostPublicEnvelopeGetResponse200RecipientsItemInvitation
        email = self.email

        firstname = self.firstname

        lastname = self.lastname

        phone = self.phone

        role = self.role.value

        order = self.order

        associated_contact = self.associated_contact

        status = self.status.value

        language = self.language.value

        verification_type = self.verification_type.value

        job_title = self.job_title

        company = self.company

        address_line_1 = self.address_line_1

        address_line_2 = self.address_line_2

        zip_code = self.zip_code

        city = self.city

        country = self.country

        invitation: dict[str, Any] | Unset = UNSET
        if not isinstance(self.invitation, Unset):
            invitation = self.invitation.to_dict()


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "email": email,
            "firstname": firstname,
            "lastname": lastname,
            "phone": phone,
            "role": role,
            "order": order,
            "associatedContact": associated_contact,
            "status": status,
            "language": language,
            "verificationType": verification_type,
        })
        if job_title is not UNSET:
            field_dict["jobTitle"] = job_title
        if company is not UNSET:
            field_dict["company"] = company
        if address_line_1 is not UNSET:
            field_dict["addressLine1"] = address_line_1
        if address_line_2 is not UNSET:
            field_dict["addressLine2"] = address_line_2
        if zip_code is not UNSET:
            field_dict["zipCode"] = zip_code
        if city is not UNSET:
            field_dict["city"] = city
        if country is not UNSET:
            field_dict["country"] = country
        if invitation is not UNSET:
            field_dict["invitation"] = invitation

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_public_envelope_get_response_200_recipients_item_invitation import PostPublicEnvelopeGetResponse200RecipientsItemInvitation
        d = dict(src_dict)
        email = d.pop("email")

        firstname = d.pop("firstname")

        lastname = d.pop("lastname")

        phone = d.pop("phone")

        role = PostPublicEnvelopeGetResponse200RecipientsItemRole(d.pop("role"))




        order = d.pop("order")

        associated_contact = d.pop("associatedContact")

        status = PostPublicEnvelopeGetResponse200RecipientsItemStatus(d.pop("status"))




        language = PostPublicEnvelopeGetResponse200RecipientsItemLanguage(d.pop("language"))




        verification_type = PostPublicEnvelopeGetResponse200RecipientsItemVerificationType(d.pop("verificationType"))




        job_title = d.pop("jobTitle", UNSET)

        company = d.pop("company", UNSET)

        address_line_1 = d.pop("addressLine1", UNSET)

        address_line_2 = d.pop("addressLine2", UNSET)

        zip_code = d.pop("zipCode", UNSET)

        city = d.pop("city", UNSET)

        country = d.pop("country", UNSET)

        _invitation = d.pop("invitation", UNSET)
        invitation: PostPublicEnvelopeGetResponse200RecipientsItemInvitation | Unset
        if isinstance(_invitation,  Unset):
            invitation = UNSET
        else:
            invitation = PostPublicEnvelopeGetResponse200RecipientsItemInvitation.from_dict(_invitation)




        post_public_envelope_get_response_200_recipients_item = cls(
            email=email,
            firstname=firstname,
            lastname=lastname,
            phone=phone,
            role=role,
            order=order,
            associated_contact=associated_contact,
            status=status,
            language=language,
            verification_type=verification_type,
            job_title=job_title,
            company=company,
            address_line_1=address_line_1,
            address_line_2=address_line_2,
            zip_code=zip_code,
            city=city,
            country=country,
            invitation=invitation,
        )

        return post_public_envelope_get_response_200_recipients_item

