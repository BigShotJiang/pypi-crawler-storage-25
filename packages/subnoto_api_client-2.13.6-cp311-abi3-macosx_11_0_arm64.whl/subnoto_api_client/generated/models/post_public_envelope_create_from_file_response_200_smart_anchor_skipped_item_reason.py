from enum import Enum

class PostPublicEnvelopeCreateFromFileResponse200SmartAnchorSkippedItemReason(str, Enum):
    ERROR = "ERROR"
    UNRECOGNIZED_RECIPIENT = "UNRECOGNIZED_RECIPIENT"
    UNSUPPORTED_BLOCK_TYPE = "UNSUPPORTED_BLOCK_TYPE"

    def __str__(self) -> str:
        return str(self.value)
