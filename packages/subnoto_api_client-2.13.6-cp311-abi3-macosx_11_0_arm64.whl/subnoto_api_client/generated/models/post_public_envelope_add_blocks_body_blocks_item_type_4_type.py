from enum import Enum

class PostPublicEnvelopeAddBlocksBodyBlocksItemType4Type(str, Enum):
    DATE = "date"

    def __str__(self) -> str:
        return str(self.value)
