from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast






T = TypeVar("T", bound="PostPublicContactListResponse200Pagination")



@_attrs_define
class PostPublicContactListResponse200Pagination:
    """ 
        Attributes:
            total_records (int): The total number of items matching the filters.
            current_page (int): The page number that was requested (1-indexed).
            total_pages (int): The total number of pages. Equals ceil(totalRecords / limit), or 1 when totalRecords is 0.
            next_page (int | None): The page number for the next page, or null when there is no next page.
            prev_page (int | None): The page number for the previous page, or null when on the first page.
     """

    total_records: int
    current_page: int
    total_pages: int
    next_page: int | None
    prev_page: int | None





    def to_dict(self) -> dict[str, Any]:
        total_records = self.total_records

        current_page = self.current_page

        total_pages = self.total_pages

        next_page: int | None
        next_page = self.next_page

        prev_page: int | None
        prev_page = self.prev_page


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "totalRecords": total_records,
            "currentPage": current_page,
            "totalPages": total_pages,
            "nextPage": next_page,
            "prevPage": prev_page,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        total_records = d.pop("totalRecords")

        current_page = d.pop("currentPage")

        total_pages = d.pop("totalPages")

        def _parse_next_page(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        next_page = _parse_next_page(d.pop("nextPage"))


        def _parse_prev_page(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        prev_page = _parse_prev_page(d.pop("prevPage"))


        post_public_contact_list_response_200_pagination = cls(
            total_records=total_records,
            current_page=current_page,
            total_pages=total_pages,
            next_page=next_page,
            prev_page=prev_page,
        )

        return post_public_contact_list_response_200_pagination

