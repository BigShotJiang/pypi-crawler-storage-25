from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="PostPublicContactDeleteBody")



@_attrs_define
class PostPublicContactDeleteBody:
    """ 
        Attributes:
            emails (list[str]): The emails of the contacts to delete.
            workspace_uuid (str | Unset): Optional. When omitted, the team's default workspace is used.
     """

    emails: list[str]
    workspace_uuid: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        emails = self.emails



        workspace_uuid = self.workspace_uuid


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "emails": emails,
        })
        if workspace_uuid is not UNSET:
            field_dict["workspaceUuid"] = workspace_uuid

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        emails = cast(list[str], d.pop("emails"))


        workspace_uuid = d.pop("workspaceUuid", UNSET)

        post_public_contact_delete_body = cls(
            emails=emails,
            workspace_uuid=workspace_uuid,
        )


        post_public_contact_delete_body.additional_properties = d
        return post_public_contact_delete_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
