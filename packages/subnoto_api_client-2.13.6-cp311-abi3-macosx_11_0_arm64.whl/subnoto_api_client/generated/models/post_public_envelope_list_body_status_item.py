from enum import Enum

class PostPublicEnvelopeListBodyStatusItem(str, Enum):
    APPROVING = "approving"
    CANCELED = "canceled"
    COMPLETE = "complete"
    DECLINED = "declined"
    DRAFT = "draft"
    EXPIRED = "expired"
    SIGNING = "signing"
    UPLOADING = "uploading"

    def __str__(self) -> str:
        return str(self.value)
