from enum import Enum

class PostPublicEnvelopeGetResponse200DocumentsItemBlocksAdditionalPropertyItemType2Type(str, Enum):
    IMAGE = "image"

    def __str__(self) -> str:
        return str(self.value)
