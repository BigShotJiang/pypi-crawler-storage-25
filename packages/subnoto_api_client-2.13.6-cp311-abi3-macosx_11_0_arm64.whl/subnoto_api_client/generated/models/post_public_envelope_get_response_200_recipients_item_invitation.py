from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.post_public_envelope_get_response_200_recipients_item_invitation_verification_type import PostPublicEnvelopeGetResponse200RecipientsItemInvitationVerificationType
from typing import cast






T = TypeVar("T", bound="PostPublicEnvelopeGetResponse200RecipientsItemInvitation")



@_attrs_define
class PostPublicEnvelopeGetResponse200RecipientsItemInvitation:
    """ Metadata for the recipient's current valid invitation link, when one exists.

        Attributes:
            valid (bool): Whether the recipient invitation link is currently valid.
            expiration_date (float): Invitation link expiration timestamp (unix timestamp).
            creation_date (float): Invitation link creation timestamp (unix timestamp).
            last_notification_date (float | None): Most recent invitation notification timestamp, or null if never notified.
            medium (str): How the invitation is delivered (opaque application-specific value, e.g. email or webhook channel
                name).
            verification_type (PostPublicEnvelopeGetResponse200RecipientsItemInvitationVerificationType): Verification mode
                stored on the active invitation link (snapshot from when the link was issued). May differ from the recipient's
                top-level verificationType if the participant configuration was updated afterward.
     """

    valid: bool
    expiration_date: float
    creation_date: float
    last_notification_date: float | None
    medium: str
    verification_type: PostPublicEnvelopeGetResponse200RecipientsItemInvitationVerificationType





    def to_dict(self) -> dict[str, Any]:
        valid = self.valid

        expiration_date = self.expiration_date

        creation_date = self.creation_date

        last_notification_date: float | None
        last_notification_date = self.last_notification_date

        medium = self.medium

        verification_type = self.verification_type.value


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "valid": valid,
            "expirationDate": expiration_date,
            "creationDate": creation_date,
            "lastNotificationDate": last_notification_date,
            "medium": medium,
            "verificationType": verification_type,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        valid = d.pop("valid")

        expiration_date = d.pop("expirationDate")

        creation_date = d.pop("creationDate")

        def _parse_last_notification_date(data: object) -> float | None:
            if data is None:
                return data
            return cast(float | None, data)

        last_notification_date = _parse_last_notification_date(d.pop("lastNotificationDate"))


        medium = d.pop("medium")

        verification_type = PostPublicEnvelopeGetResponse200RecipientsItemInvitationVerificationType(d.pop("verificationType"))




        post_public_envelope_get_response_200_recipients_item_invitation = cls(
            valid=valid,
            expiration_date=expiration_date,
            creation_date=creation_date,
            last_notification_date=last_notification_date,
            medium=medium,
            verification_type=verification_type,
        )

        return post_public_envelope_get_response_200_recipients_item_invitation

