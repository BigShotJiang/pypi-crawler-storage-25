from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.post_public_envelope_add_blocks_body_blocks_item_type_5_type import PostPublicEnvelopeAddBlocksBodyBlocksItemType5Type
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="PostPublicEnvelopeAddBlocksBodyBlocksItemType5")



@_attrs_define
class PostPublicEnvelopeAddBlocksBodyBlocksItemType5:
    """ 
        Attributes:
            page (str): The page number where the block should be placed.
            x (float): The x position of the block on the page.
            y (float): The y position of the block on the page.
            type_ (PostPublicEnvelopeAddBlocksBodyBlocksItemType5Type):
            height (float | Unset): The height of the block.
            width (float | Unset): The width of the block.
            recipient_email (str | Unset): The email of the recipient for templated blocks.
            required (bool | Unset):
            placeholder (str | Unset):
            default_value (bool | float | str | Unset):
            min_ (float | Unset):
            max_ (float | Unset):
            step (float | Unset):
     """

    page: str
    x: float
    y: float
    type_: PostPublicEnvelopeAddBlocksBodyBlocksItemType5Type
    height: float | Unset = UNSET
    width: float | Unset = UNSET
    recipient_email: str | Unset = UNSET
    required: bool | Unset = UNSET
    placeholder: str | Unset = UNSET
    default_value: bool | float | str | Unset = UNSET
    min_: float | Unset = UNSET
    max_: float | Unset = UNSET
    step: float | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        page = self.page

        x = self.x

        y = self.y

        type_ = self.type_.value

        height = self.height

        width = self.width

        recipient_email = self.recipient_email

        required = self.required

        placeholder = self.placeholder

        default_value: bool | float | str | Unset
        if isinstance(self.default_value, Unset):
            default_value = UNSET
        else:
            default_value = self.default_value

        min_ = self.min_

        max_ = self.max_

        step = self.step


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "page": page,
            "x": x,
            "y": y,
            "type": type_,
        })
        if height is not UNSET:
            field_dict["height"] = height
        if width is not UNSET:
            field_dict["width"] = width
        if recipient_email is not UNSET:
            field_dict["recipientEmail"] = recipient_email
        if required is not UNSET:
            field_dict["required"] = required
        if placeholder is not UNSET:
            field_dict["placeholder"] = placeholder
        if default_value is not UNSET:
            field_dict["defaultValue"] = default_value
        if min_ is not UNSET:
            field_dict["min"] = min_
        if max_ is not UNSET:
            field_dict["max"] = max_
        if step is not UNSET:
            field_dict["step"] = step

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        page = d.pop("page")

        x = d.pop("x")

        y = d.pop("y")

        type_ = PostPublicEnvelopeAddBlocksBodyBlocksItemType5Type(d.pop("type"))




        height = d.pop("height", UNSET)

        width = d.pop("width", UNSET)

        recipient_email = d.pop("recipientEmail", UNSET)

        required = d.pop("required", UNSET)

        placeholder = d.pop("placeholder", UNSET)

        def _parse_default_value(data: object) -> bool | float | str | Unset:
            if isinstance(data, Unset):
                return data
            return cast(bool | float | str | Unset, data)

        default_value = _parse_default_value(d.pop("defaultValue", UNSET))


        min_ = d.pop("min", UNSET)

        max_ = d.pop("max", UNSET)

        step = d.pop("step", UNSET)

        post_public_envelope_add_blocks_body_blocks_item_type_5 = cls(
            page=page,
            x=x,
            y=y,
            type_=type_,
            height=height,
            width=width,
            recipient_email=recipient_email,
            required=required,
            placeholder=placeholder,
            default_value=default_value,
            min_=min_,
            max_=max_,
            step=step,
        )


        post_public_envelope_add_blocks_body_blocks_item_type_5.additional_properties = d
        return post_public_envelope_add_blocks_body_blocks_item_type_5

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
