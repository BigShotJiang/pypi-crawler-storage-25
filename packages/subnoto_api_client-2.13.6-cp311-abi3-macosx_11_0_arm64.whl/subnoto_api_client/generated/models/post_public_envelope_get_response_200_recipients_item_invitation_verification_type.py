from enum import Enum

class PostPublicEnvelopeGetResponse200RecipientsItemInvitationVerificationType(str, Enum):
    EMAIL = "email"
    NONE = "none"
    SMS = "sms"

    def __str__(self) -> str:
        return str(self.value)
