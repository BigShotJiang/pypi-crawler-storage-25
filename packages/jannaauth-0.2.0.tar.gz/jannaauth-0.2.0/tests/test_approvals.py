"""
JannaAuth v0.3.0 — Human Approval Workflow Tests

Covers:
- ApprovalRequest lifecycle (pending → approved/rejected/expired)
- ApprovalQueue: request, approve, reject, list, expiry sweep
- ApprovalGate context manager (blocking and non-blocking)
- @protect(requires_approval=True) decorator — both wait modes
- approval_details_fn argument extraction
- SQLite persistence (requests survive queue reset)
- Thread-safety of concurrent approvals
"""

import os
import sqlite3
import tempfile
import threading
import time

import pytest

from jannaauth import (
    Agent,
    AgentRegistry,
    AgentStore,
    ApprovalGate,
    ApprovalNotFoundError,
    ApprovalPendingError,
    ApprovalRejectedError,
    ApprovalExpiredError,
    ApprovalRequest,
    ApprovalStatus,
    approval_queue,
    audit_log,
    protect,
)
from jannaauth.approval import ApprovalQueue


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def reset_queue():
    """Reset the ApprovalQueue singleton between tests."""
    approval_queue._requests.clear()
    approval_queue._store = None


def make_agent(name="TestAgent", permissions=None):
    permissions = permissions or ["write:database", "delete:records"]
    return Agent(name=name, permissions=permissions)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def clean_queue():
    """Ensure a clean queue for every test."""
    reset_queue()
    yield
    reset_queue()


@pytest.fixture
def agent():
    return make_agent()


@pytest.fixture
def db_path(tmp_path):
    return str(tmp_path / "test_jannaauth.db")


# ---------------------------------------------------------------------------
# ApprovalRequest
# ---------------------------------------------------------------------------

class TestApprovalRequest:

    def test_creation(self, agent):
        with agent.session():
            req = approval_queue.request(agent, "delete_records", details={"count": 100})

        assert req.id.startswith("approval_")
        assert req.agent_id == agent.id
        assert req.agent_name == agent.name
        assert req.action == "delete_records"
        assert req.details == {"count": 100}
        assert req.status == ApprovalStatus.PENDING
        assert req.is_pending
        assert not req.is_approved
        assert not req.is_rejected
        assert not req.is_expired

    def test_time_properties(self, agent):
        with agent.session():
            req = approval_queue.request(agent, "action", timeout_seconds=60)

        assert req.age_seconds >= 0
        assert 0 < req.time_remaining <= 60

    def test_serialisation_roundtrip(self, agent):
        with agent.session():
            req = approval_queue.request(agent, "test_action", details={"key": "value"})

        d = req.to_dict()
        restored = ApprovalRequest.from_dict(d)

        assert restored.id == req.id
        assert restored.agent_id == req.agent_id
        assert restored.action == req.action
        assert restored.details == req.details
        assert restored.status == req.status

    def test_json_roundtrip(self, agent):
        with agent.session():
            req = approval_queue.request(agent, "json_action")

        restored = ApprovalRequest.from_dict(__import__("json").loads(req.to_json()))
        assert restored.id == req.id


# ---------------------------------------------------------------------------
# ApprovalQueue — core operations
# ---------------------------------------------------------------------------

class TestApprovalQueue:

    def test_approve_transitions_status(self, agent):
        with agent.session():
            req = approval_queue.request(agent, "deploy")

        resolved = approval_queue.approve(req.id, approved_by="admin@co.com")

        assert resolved.status == ApprovalStatus.APPROVED
        assert resolved.is_approved
        assert resolved.resolved_by == "admin@co.com"
        assert resolved.resolved_at is not None

    def test_reject_transitions_status(self, agent):
        with agent.session():
            req = approval_queue.request(agent, "deploy")

        resolved = approval_queue.reject(req.id, reason="Too risky", rejected_by="cto@co.com")

        assert resolved.status == ApprovalStatus.REJECTED
        assert resolved.is_rejected
        assert resolved.rejection_reason == "Too risky"
        assert resolved.resolved_by == "cto@co.com"

    def test_cannot_approve_already_resolved(self, agent):
        with agent.session():
            req = approval_queue.request(agent, "action")

        approval_queue.approve(req.id)

        with pytest.raises(Exception):
            approval_queue.approve(req.id)

    def test_cannot_reject_already_resolved(self, agent):
        with agent.session():
            req = approval_queue.request(agent, "action")

        approval_queue.reject(req.id)

        with pytest.raises(Exception):
            approval_queue.reject(req.id)

    def test_get_unknown_id_raises(self):
        with pytest.raises(ApprovalNotFoundError):
            approval_queue.get("approval_doesnotexist")

    def test_list_pending_returns_only_pending(self, agent):
        with agent.session():
            r1 = approval_queue.request(agent, "action_1")
            r2 = approval_queue.request(agent, "action_2")
            r3 = approval_queue.request(agent, "action_3")

        approval_queue.approve(r1.id)
        approval_queue.reject(r2.id)

        pending = approval_queue.list_pending()
        pending_ids = [r.id for r in pending]

        assert r3.id in pending_ids
        assert r1.id not in pending_ids
        assert r2.id not in pending_ids

    def test_list_pending_filters_by_agent(self):
        agent_a = make_agent("AgentA")
        agent_b = make_agent("AgentB")

        with agent_a.session():
            ra = approval_queue.request(agent_a, "action_a")
        with agent_b.session():
            rb = approval_queue.request(agent_b, "action_b")

        pending_a = approval_queue.list_pending(agent_id=agent_a.id)
        assert all(r.agent_id == agent_a.id for r in pending_a)

    def test_list_all_status_filter(self, agent):
        with agent.session():
            r1 = approval_queue.request(agent, "a1")
            r2 = approval_queue.request(agent, "a2")

        approval_queue.approve(r1.id)

        approved = approval_queue.list_all(status=ApprovalStatus.APPROVED)
        assert any(r.id == r1.id for r in approved)
        assert all(r.is_approved for r in approved)

    def test_expired_requests_auto_transition(self, agent):
        with agent.session():
            req = approval_queue.request(agent, "action", timeout_seconds=0)

        time.sleep(0.05)  # let it expire
        fetched = approval_queue.get(req.id)
        assert fetched.is_expired

    def test_expire_stale_sweep(self, agent):
        with agent.session():
            req = approval_queue.request(agent, "stale", timeout_seconds=0)

        time.sleep(0.05)
        approval_queue._expire_stale()

        assert approval_queue.pending_count == 0

    def test_pending_count(self, agent):
        with agent.session():
            approval_queue.request(agent, "a1")
            approval_queue.request(agent, "a2")

        assert approval_queue.pending_count == 2


# ---------------------------------------------------------------------------
# wait_for_decision — blocking path
# ---------------------------------------------------------------------------

class TestWaitForDecision:

    def test_wait_resolves_on_approval(self, agent):
        with agent.session():
            req = approval_queue.request(agent, "wait_action")

        # Approve in a background thread after 0.1s
        def approve_later():
            time.sleep(0.1)
            approval_queue.approve(req.id, approved_by="human")

        t = threading.Thread(target=approve_later)
        t.start()

        resolved = approval_queue.wait_for_decision(req.id, poll_interval=0.05, timeout=5)
        t.join()

        assert resolved.is_approved

    def test_wait_raises_on_rejection(self, agent):
        with agent.session():
            req = approval_queue.request(agent, "wait_reject")

        def reject_later():
            time.sleep(0.1)
            approval_queue.reject(req.id, reason="No")

        t = threading.Thread(target=reject_later)
        t.start()

        with pytest.raises(ApprovalRejectedError) as exc_info:
            approval_queue.wait_for_decision(req.id, poll_interval=0.05, timeout=5)

        t.join()
        assert exc_info.value.request.id == req.id

    def test_wait_raises_on_timeout(self, agent):
        with agent.session():
            req = approval_queue.request(agent, "timeout_action", timeout_seconds=60)

        with pytest.raises(ApprovalExpiredError):
            approval_queue.wait_for_decision(req.id, poll_interval=0.05, timeout=0.1)


# ---------------------------------------------------------------------------
# @protect with requires_approval
# ---------------------------------------------------------------------------

class TestProtectRequiresApproval:

    def test_raises_approval_pending_by_default(self, agent):
        @protect(requires="write:database", requires_approval=True)
        def guarded():
            return "executed"

        with agent.session():
            with pytest.raises(ApprovalPendingError) as exc_info:
                guarded()

        assert exc_info.value.request is not None
        assert exc_info.value.request.is_pending

    def test_pending_error_carries_request(self, agent):
        @protect(requires="write:database", requires_approval=True)
        def guarded():
            return "executed"

        with agent.session():
            try:
                guarded()
            except ApprovalPendingError as e:
                req = e.request
                assert req.action == "guarded"
                assert req.agent_id == agent.id

    def test_executes_after_wait_and_approval(self, agent):
        @protect(
            requires="write:database",
            requires_approval=True,
            wait_for_approval=True,
            approval_poll_interval=0.05,
            approval_timeout=5,
        )
        def guarded():
            return "executed"

        results = {}

        def run():
            with agent.session():
                results["result"] = guarded()

        t = threading.Thread(target=run)
        t.start()

        # Wait for the request to appear then approve it
        deadline = time.time() + 3
        while time.time() < deadline:
            pending = approval_queue.list_pending(agent_id=agent.id)
            if pending:
                approval_queue.approve(pending[0].id, approved_by="tester")
                break
            time.sleep(0.05)

        t.join(timeout=5)
        assert results.get("result") == "executed"

    def test_raises_rejected_error_on_wait(self, agent):
        @protect(
            requires="write:database",
            requires_approval=True,
            wait_for_approval=True,
            approval_poll_interval=0.05,
            approval_timeout=5,
        )
        def guarded():
            return "executed"

        errors = {}

        def run():
            with agent.session():
                try:
                    guarded()
                except ApprovalRejectedError as e:
                    errors["error"] = e

        t = threading.Thread(target=run)
        t.start()

        deadline = time.time() + 3
        while time.time() < deadline:
            pending = approval_queue.list_pending(agent_id=agent.id)
            if pending:
                approval_queue.reject(pending[0].id, reason="Denied", rejected_by="cto")
                break
            time.sleep(0.05)

        t.join(timeout=5)
        assert "error" in errors

    def test_approval_details_fn_extracts_args(self, agent):
        @protect(
            requires="delete:records",
            requires_approval=True,
            approval_details_fn=lambda f, a, kw: {"record_id": kw.get("record_id")},
        )
        def delete_record(record_id=None):
            return "deleted"

        with agent.session():
            try:
                delete_record(record_id=42)
            except ApprovalPendingError as e:
                assert e.request.details == {"record_id": 42}

    def test_permission_denied_before_approval_check(self):
        """Permission check fires before approval — no request created if denied."""
        restricted = Agent(name="Restricted", permissions=["read:only"])

        @protect(requires="delete:records", requires_approval=True)
        def guarded():
            return "executed"

        with restricted.session():
            from jannaauth import PermissionDeniedError
            with pytest.raises(PermissionDeniedError):
                guarded()

        assert approval_queue.pending_count == 0


# ---------------------------------------------------------------------------
# ApprovalGate context manager
# ---------------------------------------------------------------------------

class TestApprovalGate:

    def test_nonblocking_raises_pending(self, agent):
        with pytest.raises(ApprovalPendingError) as exc_info:
            with ApprovalGate(agent, "purge_logs", details={"days": 90}):
                pass  # never reached

        assert exc_info.value.request.action == "purge_logs"

    def test_blocking_executes_after_approval(self, agent):
        executed = []

        def run():
            with ApprovalGate(agent, "deploy", wait=True, timeout_seconds=5):
                executed.append(True)

        t = threading.Thread(target=run)
        t.start()

        deadline = time.time() + 3
        while time.time() < deadline:
            pending = approval_queue.list_pending(agent_id=agent.id)
            if pending:
                approval_queue.approve(pending[0].id)
                break
            time.sleep(0.05)

        t.join(timeout=5)
        assert executed == [True]

    def test_blocking_raises_on_rejection(self, agent):
        errors = {}

        def run():
            try:
                with ApprovalGate(agent, "risky_action", wait=True, timeout_seconds=5):
                    pass
            except ApprovalRejectedError as e:
                errors["e"] = e

        t = threading.Thread(target=run)
        t.start()

        deadline = time.time() + 3
        while time.time() < deadline:
            pending = approval_queue.list_pending(agent_id=agent.id)
            if pending:
                approval_queue.reject(pending[0].id, reason="Too risky")
                break
            time.sleep(0.05)

        t.join(timeout=5)
        assert "e" in errors

    def test_gate_metadata_is_stored(self, agent):
        with pytest.raises(ApprovalPendingError) as exc_info:
            with ApprovalGate(agent, "act", metadata={"env": "prod"}):
                pass

        assert exc_info.value.request.metadata == {"env": "prod"}


# ---------------------------------------------------------------------------
# SQLite persistence
# ---------------------------------------------------------------------------

class TestSQLitePersistence:

    def test_pending_requests_survive_queue_reset(self, agent, db_path):
        store = AgentStore(db_path)
        approval_queue.configure(store=store)

        with agent.session():
            req = approval_queue.request(agent, "persistent_action")

        # Simulate restart — reset in-memory queue, reconfigure from same DB
        reset_queue()
        approval_queue.configure(store=store)

        reloaded = approval_queue.get(req.id)
        assert reloaded.id == req.id
        assert reloaded.is_pending

    def test_approved_status_persists(self, agent, db_path):
        store = AgentStore(db_path)
        approval_queue.configure(store=store)

        with agent.session():
            req = approval_queue.request(agent, "persist_approve")

        approval_queue.approve(req.id, approved_by="admin")

        # Check directly in SQLite
        conn = sqlite3.connect(db_path)
        row = conn.execute(
            "SELECT status, resolved_by FROM pending_approvals WHERE id = ?", (req.id,)
        ).fetchone()
        conn.close()

        assert row[0] == "approved"
        assert row[1] == "admin"

    def test_rejected_status_persists(self, agent, db_path):
        store = AgentStore(db_path)
        approval_queue.configure(store=store)

        with agent.session():
            req = approval_queue.request(agent, "persist_reject")

        approval_queue.reject(req.id, reason="No way", rejected_by="cto")

        conn = sqlite3.connect(db_path)
        row = conn.execute(
            "SELECT status, rejection_reason FROM pending_approvals WHERE id = ?",
            (req.id,)
        ).fetchone()
        conn.close()

        assert row[0] == "rejected"
        assert row[1] == "No way"


# ---------------------------------------------------------------------------
# Audit log integration
# ---------------------------------------------------------------------------

class TestApprovalAuditLog:

    def test_request_logs_approval_requested(self, agent):
        from jannaauth import ActionType
        audit_log.clear()

        with agent.session():
            req = approval_queue.request(agent, "audited_action")

        entries = audit_log.query(action_type=ActionType.APPROVAL_REQUESTED)
        assert len(entries) >= 1
        assert entries[0].details["approval_id"] == req.id

    def test_approve_logs_approval_granted(self, agent):
        from jannaauth import ActionType
        audit_log.clear()

        with agent.session():
            req = approval_queue.request(agent, "audited_approve")

        approval_queue.approve(req.id, approved_by="auditor")

        entries = audit_log.query(action_type=ActionType.APPROVAL_GRANTED)
        assert len(entries) >= 1
        assert entries[0].details["approved_by"] == "auditor"

    def test_reject_logs_approval_rejected(self, agent):
        from jannaauth import ActionType
        audit_log.clear()

        with agent.session():
            req = approval_queue.request(agent, "audited_reject")

        approval_queue.reject(req.id, reason="Risky", rejected_by="cto")

        entries = audit_log.query(action_type=ActionType.APPROVAL_REJECTED)
        assert len(entries) >= 1
        assert entries[0].details["reason"] == "Risky"
