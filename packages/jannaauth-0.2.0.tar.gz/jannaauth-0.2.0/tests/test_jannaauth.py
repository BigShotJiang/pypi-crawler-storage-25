"""
JannaAuth SDK v0.2.0 - Comprehensive Test Suite
Tests for cryptographic proofs, permissions, and integrations
"""

import pytest
import time
import json
from datetime import datetime

# Import JannaAuth
from jannaauth import (
    Agent,
    AgentRegistry,
    AgentStatus,
    agent_registry,
    KeyPair,
    Proof,
    ProofGenerator,
    ProofVerifier,
    generate_challenge,
    CRYPTO_AVAILABLE,
    Permission,
    PermissionSet,
    PermissionChecker,
    protect,
    requires_permission,
    Session,
    session_manager,
    TokenManager,
    audit_log,
    ActionType,
    ActionStatus,
    Handoff,
    HandoffManager,
    create_handoff,
    receive_handoff,
    AgentNotFoundError,
    AgentRevokedError,
    AgentSuspendedError,
    InvalidTokenError,
    TokenExpiredError,
    PermissionDeniedError,
    InvalidPermissionError,
    InvalidProofError,
    ProofExpiredError,
    InvalidRecipientError,
    NoActiveSessionError
)


# ============================================================================
# AGENT TESTS
# ============================================================================

class TestAgent:
    """Test Agent class"""
    
    def test_create_agent(self):
        """Test basic agent creation"""
        agent = Agent(name="TestAgent")
        
        assert agent.name == "TestAgent"
        assert agent.id.startswith("agent_")
        assert len(agent.id) == 22  # "agent_" + 16 hex chars
        assert agent.status == AgentStatus.ACTIVE
        assert agent.is_active
    
    def test_agent_with_permissions(self):
        """Test agent with permissions"""
        agent = Agent(
            name="PermAgent",
            _permissions=["read:database", "write:files"]
        )
        
        assert agent.can("read:database")
        assert agent.can("write:files")
        assert not agent.can("delete:records")
    
    def test_agent_with_metadata(self):
        """Test agent with metadata"""
        agent = Agent(
            name="MetaAgent",
            description="Test agent",
            owner="test@example.com",
            metadata={"team": "analytics"}
        )
        
        assert agent.description == "Test agent"
        assert agent.owner == "test@example.com"
        assert agent.metadata["team"] == "analytics"
    
    def test_agent_has_keypair(self):
        """Test agent has cryptographic key pair"""
        agent = Agent(name="CryptoAgent")
        
        assert agent.public_key_hex is not None
        assert len(agent.public_key_hex) == 64  # 32 bytes = 64 hex chars
        assert agent.key_algorithm in ["ed25519", "hmac-sha256"]
    
    def test_agent_token(self):
        """Test agent token generation"""
        agent = Agent(name="TokenAgent")
        
        token = agent.token
        assert token.startswith("ja_")
        assert agent.verify_token(token)
    
    def test_agent_suspend_reactivate(self):
        """Test agent suspension and reactivation"""
        agent = Agent(name="SuspendAgent")
        
        agent.suspend(reason="Testing")
        assert agent.status == AgentStatus.SUSPENDED
        assert agent.is_suspended
        
        agent.reactivate()
        assert agent.status == AgentStatus.ACTIVE
        assert agent.is_active
    
    def test_agent_revoke(self):
        """Test agent revocation"""
        agent = Agent(name="RevokeAgent")
        
        agent.revoke(reason="Testing")
        assert agent.status == AgentStatus.REVOKED
        assert agent.is_revoked
        
        with pytest.raises(AgentRevokedError):
            agent.token
    
    def test_agent_to_dict(self):
        """Test agent serialization"""
        agent = Agent(
            name="SerializeAgent",
            description="Test",
            owner="test@example.com"
        )
        
        data = agent.to_dict()
        assert data["name"] == "SerializeAgent"
        assert data["description"] == "Test"
        assert data["owner"] == "test@example.com"
        assert "public_key" in data
        assert "id" in data


# ============================================================================
# CRYPTOGRAPHIC TESTS
# ============================================================================

class TestCryptography:
    """Test cryptographic functions"""
    
    def test_keypair_creation(self):
        """Test key pair generation"""
        keys = KeyPair()
        
        assert keys.public_key_bytes is not None
        assert keys.public_key_hex is not None
        assert keys.algorithm in ["ed25519", "hmac-sha256"]
    
    def test_keypair_signing(self):
        """Test message signing"""
        keys = KeyPair()
        message = b"test message"
        
        signature = keys.sign(message)
        assert signature is not None
        assert len(signature) > 0
    
    def test_keypair_verification(self):
        """Test signature verification"""
        keys = KeyPair()
        message = b"test message"
        
        signature = keys.sign(message)
        assert keys.verify(message, signature)
    
    def test_proof_creation(self):
        """Test proof generation"""
        agent = Agent(name="ProofAgent")
        
        proof = agent.create_proof("test_challenge")
        
        assert proof.challenge == "test_challenge"
        assert proof.agent_id == agent.id
        assert proof.public_key == agent.public_key_hex
        assert proof.signature is not None
    
    def test_proof_serialization(self):
        """Test proof serialization"""
        agent = Agent(name="SerializeProofAgent")
        proof = agent.create_proof("challenge")
        
        # To dict
        proof_dict = proof.to_dict()
        assert proof_dict["challenge"] == "challenge"
        assert proof_dict["agent_id"] == agent.id
        
        # From dict
        proof2 = Proof.from_dict(proof_dict)
        assert proof2.challenge == proof.challenge
        assert proof2.agent_id == proof.agent_id
        
        # To JSON
        proof_json = proof.to_json()
        proof3 = Proof.from_json(proof_json)
        assert proof3.challenge == proof.challenge
    
    def test_generate_challenge(self):
        """Test challenge generation"""
        c1 = generate_challenge()
        c2 = generate_challenge()
        
        assert len(c1) == 32  # 16 bytes = 32 hex chars
        assert c1 != c2  # Random each time


# ============================================================================
# PERMISSION TESTS
# ============================================================================

class TestPermissions:
    """Test permission system"""
    
    def test_permission_creation(self):
        """Test permission creation"""
        perm = Permission(action="read", resource="database")
        
        assert perm.action == "read"
        assert perm.resource == "database"
        assert str(perm) == "read:database"
    
    def test_permission_from_string(self):
        """Test permission from string"""
        perm = Permission.from_string("write:files")
        
        assert perm.action == "write"
        assert perm.resource == "files"
    
    def test_permission_matching(self):
        """Test permission matching"""
        read_db = Permission.from_string("read:database")
        read_all = Permission.from_string("read:*")
        all_db = Permission.from_string("*:database")
        superuser = Permission.from_string("*:*")
        
        # Exact match
        assert read_db.matches(read_db)
        
        # Wildcard resource
        assert read_all.matches(read_db)
        
        # Wildcard action
        assert all_db.matches(read_db)
        
        # Superuser
        assert superuser.matches(read_db)
    
    def test_permission_hierarchical(self):
        """Test hierarchical permission matching"""
        files_all = Permission.from_string("read:files.*")
        files_docs = Permission.from_string("read:files.documents")
        
        assert files_all.matches(files_docs)
        assert not files_docs.matches(files_all)
    
    def test_permission_set(self):
        """Test permission set"""
        perms = PermissionSet([
            "read:database",
            "write:files",
            "call:api.*"
        ])
        
        assert perms.has("read:database")
        assert perms.has("write:files")
        assert perms.has("call:api.openai")
        assert not perms.has("delete:records")
    
    def test_permission_set_all_any(self):
        """Test has_all and has_any"""
        perms = PermissionSet(["read:a", "read:b"])
        
        assert perms.has_all(["read:a", "read:b"])
        assert not perms.has_all(["read:a", "read:c"])
        
        assert perms.has_any(["read:a", "read:c"])
        assert not perms.has_any(["read:c", "read:d"])
    
    def test_invalid_permission(self):
        """Test invalid permission raises error"""
        with pytest.raises(InvalidPermissionError):
            Permission.from_string("invalid")
        
        with pytest.raises(InvalidPermissionError):
            Permission(action="invalid_action", resource="db")
    
    def test_agent_permission_methods(self):
        """Test agent permission methods"""
        agent = Agent(
            name="PermTestAgent",
            _permissions=["read:database", "write:files.*"]
        )
        
        assert agent.can("read:database")
        assert agent.can("write:files.documents")
        assert not agent.can("delete:records")
        
        assert agent.can_all(["read:database"])
        assert agent.can_any(["read:database", "delete:records"])
    
    def test_grant_revoke_permission(self):
        """Test granting and revoking permissions"""
        agent = Agent(name="GrantAgent")
        
        assert not agent.can("admin:users")
        
        agent.grant_permission("admin:users")
        assert agent.can("admin:users")
        
        agent.revoke_permission("admin:users")
        assert not agent.can("admin:users")


# ============================================================================
# SESSION TESTS
# ============================================================================

class TestSessions:
    """Test session management"""
    
    def test_session_creation(self):
        """Test session creation"""
        agent = Agent(name="SessionAgent")
        
        with agent.session() as session:
            assert session is not None
            assert session.agent_id == agent.id
            assert session.agent_name == agent.name
            assert session.is_active
    
    def test_session_ends_properly(self):
        """Test session ends after context"""
        agent = Agent(name="SessionEndAgent")
        
        with agent.session() as session:
            session_id = session.session_id
        
        ended_session = session_manager.get(session_id)
        assert ended_session.ended_at is not None
        assert ended_session.status == "completed"
    
    def test_session_on_error(self):
        """Test session handles errors"""
        agent = Agent(name="SessionErrorAgent")
        
        try:
            with agent.session() as session:
                session_id = session.session_id
                raise ValueError("Test error")
        except ValueError:
            pass
        
        ended_session = session_manager.get(session_id)
        assert ended_session.status == "error"
    
    def test_current_session(self):
        """Test getting current session"""
        agent = Agent(name="CurrentSessionAgent")
        
        assert session_manager.get_current() is None
        
        with agent.session():
            current = session_manager.get_current()
            assert current is not None
            assert current.agent_id == agent.id
        
        assert session_manager.get_current() is None


# ============================================================================
# TOKEN TESTS
# ============================================================================

class TestTokens:
    """Test token management"""
    
    def test_token_generation(self):
        """Test token generation"""
        manager = TokenManager()
        token = manager.generate("agent_123", "TestAgent")
        
        assert token.startswith("ja_")
        assert token.count('.') == 2
    
    def test_token_verification(self):
        """Test token verification"""
        manager = TokenManager()
        token = manager.generate("agent_123", "TestAgent")
        
        payload = manager.verify(token)
        assert payload["aid"] == "agent_123"
        assert payload["name"] == "TestAgent"
    
    def test_token_expiration(self):
        """Test token expiration"""
        manager = TokenManager()
        token = manager.generate("agent_123", "TestAgent", expires_in=-1)
        
        with pytest.raises(TokenExpiredError):
            manager.verify(token)
    
    def test_invalid_token(self):
        """Test invalid token raises error"""
        manager = TokenManager()
        
        with pytest.raises(InvalidTokenError):
            manager.verify("invalid_token")
        
        with pytest.raises(InvalidTokenError):
            manager.verify("ja_invalid.token.format")


# ============================================================================
# HANDOFF TESTS
# ============================================================================

class TestHandoffs:
    """Test secure handoffs"""
    
    def test_handoff_creation(self):
        """Test handoff creation"""
        registry = AgentRegistry()
        agent_a = registry.create(name="AgentA")
        agent_b = registry.create(name="AgentB")
        
        manager = HandoffManager(registry)
        handoff = manager.create(
            sender=agent_a,
            recipient_id=agent_b.id,
            data={"message": "Hello"}
        )
        
        assert handoff.from_agent_id == agent_a.id
        assert handoff.to_agent_id == agent_b.id
        assert handoff.data["message"] == "Hello"
    
    def test_handoff_receive(self):
        """Test handoff receiving"""
        registry = AgentRegistry()
        agent_a = registry.create(name="SenderAgent")
        agent_b = registry.create(name="ReceiverAgent")
        
        manager = HandoffManager(registry)
        handoff = manager.create(
            sender=agent_a,
            recipient_id=agent_b.id,
            data={"key": "value"}
        )
        
        # This will fail without cryptography library for Ed25519
        # but should work with HMAC self-verification
        if CRYPTO_AVAILABLE:
            data = manager.receive(agent_b, handoff)
            assert data["key"] == "value"
    
    def test_handoff_wrong_recipient(self):
        """Test handoff to wrong recipient fails"""
        registry = AgentRegistry()
        agent_a = registry.create(name="Sender")
        agent_b = registry.create(name="IntendedRecipient")
        agent_c = registry.create(name="WrongRecipient")
        
        manager = HandoffManager(registry)
        handoff = manager.create(
            sender=agent_a,
            recipient_id=agent_b.id,
            data={"secret": "data"}
        )
        
        with pytest.raises(InvalidRecipientError):
            manager.receive(agent_c, handoff)
    
    def test_handoff_serialization(self):
        """Test handoff serialization"""
        registry = AgentRegistry()
        agent_a = registry.create(name="SerializeSender")
        agent_b = registry.create(name="SerializeReceiver")
        
        manager = HandoffManager(registry)
        handoff = manager.create(
            sender=agent_a,
            recipient_id=agent_b.id,
            data={"test": "data"}
        )
        
        # To JSON
        json_str = handoff.to_json()
        assert isinstance(json_str, str)
        
        # From JSON
        handoff2 = Handoff.from_json(json_str)
        assert handoff2.from_agent_id == agent_a.id
        assert handoff2.data["test"] == "data"


# ============================================================================
# REGISTRY TESTS
# ============================================================================

class TestAgentRegistry:
    """Test agent registry"""
    
    def test_registry_create(self):
        """Test creating agents via registry"""
        registry = AgentRegistry()
        agent = registry.create(
            name="RegistryAgent",
            permissions=["read:*"],
            owner="test@example.com"
        )
        
        assert agent.name == "RegistryAgent"
        assert agent.can("read:database")
    
    def test_registry_get(self):
        """Test getting agent by ID"""
        registry = AgentRegistry()
        agent = registry.create(name="GetAgent")
        
        found = registry.get(agent.id)
        assert found.id == agent.id
    
    def test_registry_get_not_found(self):
        """Test getting non-existent agent"""
        registry = AgentRegistry()
        
        with pytest.raises(AgentNotFoundError):
            registry.get("agent_nonexistent")
    
    def test_registry_verify_token(self):
        """Test token verification via registry"""
        registry = AgentRegistry()
        agent = registry.create(name="TokenVerifyAgent")
        
        found = registry.verify_token(agent.token)
        assert found.id == agent.id
    
    def test_registry_list(self):
        """Test listing agents"""
        registry = AgentRegistry()
        registry.create(name="ListAgent1")
        registry.create(name="ListAgent2")
        
        agents = registry.list()
        assert len(agents) >= 2
    
    def test_registry_revoke(self):
        """Test revoking via registry"""
        registry = AgentRegistry()
        agent = registry.create(name="RevokeRegistryAgent")
        
        registry.revoke(agent.id, reason="Test")
        
        found = registry.get(agent.id)
        assert found.is_revoked


# ============================================================================
# AUDIT LOG TESTS
# ============================================================================

class TestAuditLog:
    """Test audit logging"""
    
    def test_audit_log_entry(self):
        """Test audit log entries"""
        audit_log.clear()
        
        audit_log.log(
            agent_id="agent_test",
            agent_name="TestAgent",
            action_type=ActionType.ACTION_EXECUTED,
            status=ActionStatus.SUCCESS,
            resource="test_resource"
        )
        
        entries = audit_log.query(agent_id="agent_test")
        assert len(entries) >= 1
        assert entries[0].agent_id == "agent_test"
    
    def test_audit_log_query(self):
        """Test audit log querying"""
        audit_log.clear()
        
        # Create some entries
        for i in range(5):
            audit_log.log(
                agent_id="query_agent",
                agent_name="QueryAgent",
                action_type=ActionType.ACTION_EXECUTED,
                status=ActionStatus.SUCCESS
            )
        
        entries = audit_log.query(agent_id="query_agent", limit=3)
        assert len(entries) == 3
    
    def test_audit_log_export(self):
        """Test audit log export"""
        audit_log.clear()
        
        audit_log.log(
            agent_id="export_agent",
            agent_name="ExportAgent",
            action_type=ActionType.SESSION_START,
            status=ActionStatus.SUCCESS
        )
        
        json_export = audit_log.export(format="json")
        assert isinstance(json_export, str)
        data = json.loads(json_export)
        assert isinstance(data, list)
        
        csv_export = audit_log.export(format="csv")
        assert "timestamp" in csv_export


# ============================================================================
# INTEGRATION TESTS
# ============================================================================

class TestFullWorkflow:
    """Test complete workflows"""
    
    def test_complete_agent_workflow(self):
        """Test complete agent lifecycle"""
        # Create registry
        registry = AgentRegistry()
        
        # Create agent with permissions
        agent = registry.create(
            name="WorkflowAgent",
            permissions=["read:database", "write:reports"],
            owner="workflow@example.com"
        )
        
        # Verify agent exists
        found = registry.get(agent.id)
        assert found.id == agent.id
        
        # Create session
        with agent.session() as session:
            # Check permissions
            assert agent.can("read:database")
            assert not agent.can("delete:records")
            
            # Create proof
            proof = agent.create_proof("workflow_challenge")
            assert proof.agent_id == agent.id
        
        # Verify token
        verified = registry.verify_token(agent.token)
        assert verified.id == agent.id
        
        # Suspend and reactivate
        agent.suspend(reason="Maintenance")
        assert agent.is_suspended
        
        agent.reactivate()
        assert agent.is_active
        
        # Revoke
        registry.revoke(agent.id, reason="End of test")
        assert agent.is_revoked
    
    def test_multi_agent_handoff(self):
        """Test multi-agent data handoff"""
        registry = AgentRegistry()
        
        researcher = registry.create(
            name="Researcher",
            permissions=["read:web", "write:research"]
        )
        
        analyst = registry.create(
            name="Analyst",
            permissions=["read:research", "write:analysis"]
        )
        
        writer = registry.create(
            name="Writer",
            permissions=["read:analysis", "write:reports"]
        )
        
        # Researcher creates data
        research_data = {
            "findings": ["Finding 1", "Finding 2"],
            "sources": ["Source A", "Source B"]
        }
        
        # Create handoff to analyst
        manager = HandoffManager(registry)
        handoff1 = manager.create(
            sender=researcher,
            recipient_id=analyst.id,
            data=research_data
        )
        
        # Verify handoff structure
        assert handoff1.from_agent_id == researcher.id
        assert handoff1.to_agent_id == analyst.id
        
        # Analyst can receive (with crypto library)
        if CRYPTO_AVAILABLE:
            received = manager.receive(analyst, handoff1)
            assert received["findings"][0] == "Finding 1"


# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
