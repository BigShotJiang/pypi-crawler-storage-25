"""
JannaAuth Key Store Backends
Pluggable private key storage — from environment variables to HashiCorp Vault
and AWS Secrets Manager.

By default, JannaAuth stores private key bytes in SQLite alongside the agent
record. For production environments with stricter security requirements, swap
in an external backend so private keys never touch your application database.

Available backends:
    EnvVarKeyStore       — keys injected as environment variables (CI/CD friendly)
    VaultKeyStore        — HashiCorp Vault KV v2  (pip install jannaauth[vault])
    AWSSecretsKeyStore   — AWS Secrets Manager     (pip install jannaauth[aws])

Usage:
    from jannaauth import AgentRegistry
    from jannaauth.keystore import EnvVarKeyStore, VaultKeyStore, AWSSecretsKeyStore

    # Environment variables (great for containers / Kubernetes secrets)
    registry = AgentRegistry()
    registry.configure(
        store=AgentStore("agents.db"),
        key_store=EnvVarKeyStore(prefix="MYAPP_KEY_")
    )

    # HashiCorp Vault
    registry.configure(
        store=AgentStore("agents.db"),
        key_store=VaultKeyStore(
            url="https://vault.internal:8200",
            token="s.xxxx",
            mount_path="secret",
        )
    )

    # AWS Secrets Manager
    registry.configure(
        store=AgentStore("agents.db"),
        key_store=AWSSecretsKeyStore(
            region="eu-west-1",
            prefix="jannaauth/keys/",
        )
    )

Security note:
    Private keys are Ed25519 32-byte keys stored as hex strings.
    Treat them with the same care as database passwords or API keys.

Copyright (c) 2025 Janna Labs (IRAVEN GROUP UK)
MIT License
"""

import os
from abc import ABC, abstractmethod
from typing import Optional

from .exceptions import KeyPairError


class KeyStoreBackend(ABC):
    """
    Abstract base class for private key storage backends.

    Implement save(), load(), and delete() to create a custom backend.
    """

    @abstractmethod
    def save(self, agent_id: str, private_key_hex: str):
        """
        Persist a private key for an agent.

        Args:
            agent_id:        The agent's unique ID (e.g. "agent_a1b2c3d4").
            private_key_hex: 64-character hex string of the Ed25519 private key.
        """
        ...

    @abstractmethod
    def load(self, agent_id: str) -> str:
        """
        Retrieve a private key for an agent.

        Args:
            agent_id: The agent's unique ID.

        Returns:
            64-character hex string of the Ed25519 private key.

        Raises:
            KeyPairError: If the key is not found or cannot be loaded.
        """
        ...

    @abstractmethod
    def delete(self, agent_id: str):
        """
        Delete a private key for an agent.

        Args:
            agent_id: The agent's unique ID.
        """
        ...


class EnvVarKeyStore(KeyStoreBackend):
    """
    Environment variable key store.

    Stores private keys as environment variables in the current process.
    Ideal for:
    - Containers with secrets injected as env vars (Docker, Kubernetes)
    - CI/CD pipelines
    - Development / testing

    Key name format: {prefix}{AGENT_ID_UPPERCASE}
    Example: JANNAAUTH_KEY_AGENT_A1B2C3D4

    Usage:
        store = EnvVarKeyStore(prefix="MYAPP_KEY_")
        registry.configure(AgentStore("agents.db"), key_store=store)

    Note:
        Keys set via save() exist only for the current process lifetime.
        For persistence across restarts, inject them as real environment
        variables in your deployment configuration.
    """

    def __init__(self, prefix: str = "JANNAAUTH_KEY_"):
        """
        Args:
            prefix: Prefix for environment variable names.
                    Default: "JANNAAUTH_KEY_"
        """
        self.prefix = prefix

    def _env_name(self, agent_id: str) -> str:
        """Convert agent_id to a valid env var name."""
        return self.prefix + agent_id.upper().replace("-", "_")

    def save(self, agent_id: str, private_key_hex: str):
        os.environ[self._env_name(agent_id)] = private_key_hex

    def load(self, agent_id: str) -> str:
        key = os.environ.get(self._env_name(agent_id))
        if not key:
            raise KeyPairError(
                f"Private key not found in environment for agent '{agent_id}'. "
                f"Expected env var: {self._env_name(agent_id)}"
            )
        return key

    def delete(self, agent_id: str):
        os.environ.pop(self._env_name(agent_id), None)


class VaultKeyStore(KeyStoreBackend):
    """
    HashiCorp Vault KV v2 key store.

    Stores private keys in Vault's KV secrets engine.
    Requires: pip install jannaauth[vault]

    Usage:
        from jannaauth.keystore import VaultKeyStore

        store = VaultKeyStore(
            url="https://vault.internal:8200",
            token="s.xxxxxxxxxxxx",
            mount_path="secret",        # KV v2 mount point
            secret_prefix="jannaauth/", # path prefix within mount
        )
        registry.configure(AgentStore("agents.db"), key_store=store)

    Auth methods:
        Pass token= for token auth, or configure the hvac client externally
        and pass it directly via client= for other auth methods (AppRole,
        Kubernetes, AWS IAM, etc).
    """

    def __init__(
        self,
        url: str,
        token: Optional[str] = None,
        mount_path: str = "secret",
        secret_prefix: str = "jannaauth/keys/",
        client=None,
    ):
        """
        Args:
            url:           Vault server URL.
            token:         Vault token (optional if client is provided).
            mount_path:    KV v2 mount path (default: "secret").
            secret_prefix: Path prefix for all JannaAuth keys.
            client:        Pre-configured hvac.Client (optional).
        """
        try:
            import hvac
        except ImportError:
            raise ImportError(
                "HashiCorp Vault support requires the 'hvac' package. "
                "Install it with: pip install 'jannaauth[vault]'"
            )

        self._hvac = hvac
        self.mount_path = mount_path
        self.secret_prefix = secret_prefix

        if client:
            self._client = client
        else:
            self._client = hvac.Client(url=url, token=token)

        if not self._client.is_authenticated():
            raise KeyPairError(
                "Vault authentication failed. Check your URL and token."
            )

    def _path(self, agent_id: str) -> str:
        return f"{self.secret_prefix}{agent_id}"

    def save(self, agent_id: str, private_key_hex: str):
        try:
            self._client.secrets.kv.v2.create_or_update_secret(
                path=self._path(agent_id),
                secret={"private_key_hex": private_key_hex},
                mount_point=self.mount_path,
            )
        except Exception as e:
            raise KeyPairError(f"Failed to save key to Vault for agent '{agent_id}': {e}")

    def load(self, agent_id: str) -> str:
        try:
            response = self._client.secrets.kv.v2.read_secret_version(
                path=self._path(agent_id),
                mount_point=self.mount_path,
            )
            return response["data"]["data"]["private_key_hex"]
        except Exception as e:
            raise KeyPairError(
                f"Failed to load key from Vault for agent '{agent_id}': {e}"
            )

    def delete(self, agent_id: str):
        try:
            self._client.secrets.kv.v2.delete_metadata_and_all_versions(
                path=self._path(agent_id),
                mount_point=self.mount_path,
            )
        except Exception:
            pass  # Best-effort delete


class AWSSecretsKeyStore(KeyStoreBackend):
    """
    AWS Secrets Manager key store.

    Stores private keys as individual secrets in AWS Secrets Manager.
    Requires: pip install jannaauth[aws]

    Usage:
        from jannaauth.keystore import AWSSecretsKeyStore

        store = AWSSecretsKeyStore(
            region="eu-west-1",
            prefix="jannaauth/keys/",  # Secret name prefix
        )
        registry.configure(AgentStore("agents.db"), key_store=store)

    IAM permissions required:
        secretsmanager:CreateSecret
        secretsmanager:GetSecretValue
        secretsmanager:PutSecretValue
        secretsmanager:DeleteSecret
    """

    def __init__(
        self,
        region: str,
        prefix: str = "jannaauth/keys/",
        profile: Optional[str] = None,
        client=None,
    ):
        """
        Args:
            region:  AWS region (e.g. "eu-west-1").
            prefix:  Secret name prefix (default: "jannaauth/keys/").
            profile: AWS profile name (optional, uses default if not set).
            client:  Pre-configured boto3 secretsmanager client (optional).
        """
        try:
            import boto3
        except ImportError:
            raise ImportError(
                "AWS Secrets Manager support requires the 'boto3' package. "
                "Install it with: pip install 'jannaauth[aws]'"
            )

        self.prefix = prefix

        if client:
            self._client = client
        else:
            session = boto3.Session(profile_name=profile, region_name=region)
            self._client = session.client("secretsmanager")

    def _secret_name(self, agent_id: str) -> str:
        return f"{self.prefix}{agent_id}"

    def save(self, agent_id: str, private_key_hex: str):
        name = self._secret_name(agent_id)
        try:
            # Try update first, create if it doesn't exist
            try:
                self._client.put_secret_value(
                    SecretId=name,
                    SecretString=private_key_hex,
                )
            except self._client.exceptions.ResourceNotFoundException:
                self._client.create_secret(
                    Name=name,
                    SecretString=private_key_hex,
                    Description=f"JannaAuth private key for agent {agent_id}",
                )
        except Exception as e:
            raise KeyPairError(
                f"Failed to save key to AWS Secrets Manager for agent '{agent_id}': {e}"
            )

    def load(self, agent_id: str) -> str:
        try:
            response = self._client.get_secret_value(
                SecretId=self._secret_name(agent_id)
            )
            return response["SecretString"]
        except Exception as e:
            raise KeyPairError(
                f"Failed to load key from AWS Secrets Manager for agent '{agent_id}': {e}"
            )

    def delete(self, agent_id: str):
        try:
            self._client.delete_secret(
                SecretId=self._secret_name(agent_id),
                ForceDeleteWithoutRecovery=True,
            )
        except Exception:
            pass  # Best-effort delete
