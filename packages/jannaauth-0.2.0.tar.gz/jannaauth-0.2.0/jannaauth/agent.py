"""
JannaAuth Agent
Core Agent identity class with cryptographic proofs and permissions
"""

import json
import secrets
from typing import Optional, Dict, Any, List, Union, TYPE_CHECKING
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

if TYPE_CHECKING:
    from .storage import AgentStore

from .crypto import KeyPair, ProofGenerator, Proof, generate_challenge
from .token import TokenManager
from .session import session_manager, Session
from .permissions import Permission, PermissionSet
from .audit import audit_log, ActionType, ActionStatus
from .exceptions import (
    AgentNotFoundError,
    AgentRevokedError,
    AgentSuspendedError,
    InvalidTokenError
)


class AgentStatus(Enum):
    """Agent status states"""
    ACTIVE = "active"
    SUSPENDED = "suspended"
    REVOKED = "revoked"


@dataclass
class Agent:
    """
    AI Agent with cryptographic identity and permissions.
    
    Features:
    - Unique identifier
    - Ed25519 key pair for cryptographic proofs
    - JWT-like tokens
    - Permission management
    - Session tracking
    - Audit logging
    
    Usage:
        # Create agent with permissions
        agent = Agent(
            name="DataAnalyst",
            permissions=["read:database", "write:reports"],
            owner="analytics@company.com"
        )
        
        # Use in session
        with agent.session():
            # Actions are tracked and permission-checked
            analyze_data()
        
        # Create cryptographic proof
        proof = agent.create_proof("challenge_string")
        
        # Verify another agent's proof
        is_valid = verifier.verify(proof)
    """
    
    name: str
    description: Optional[str] = None
    owner: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    
    # Permissions
    _permissions: Optional[List[Union[str, Permission]]] = field(default=None, repr=False)
    
    # Auto-generated
    id: str = field(default_factory=lambda: f"agent_{secrets.token_hex(8)}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    status: AgentStatus = field(default=AgentStatus.ACTIVE)
    
    # Cryptographic identity
    _key_pair: KeyPair = field(default=None, repr=False)
    
    # Token management
    _token: Optional[str] = field(default=None, repr=False)
    _token_manager: TokenManager = field(default=None, repr=False)
    _token_expires_in: int = field(default=86400, repr=False)
    
    # Proof generator
    _proof_generator: ProofGenerator = field(default=None, repr=False)
    
    # Permission set
    permissions: PermissionSet = field(default=None, repr=False)
    
    def __post_init__(self):
        """Initialize agent with cryptographic identity"""
        # Initialize key pair
        if self._key_pair is None:
            self._key_pair = KeyPair()
        
        # Initialize token manager
        if self._token_manager is None:
            self._token_manager = TokenManager()
        
        # Initialize proof generator
        self._proof_generator = ProofGenerator(self.id, self._key_pair)
        
        # Initialize permissions
        if self._permissions:
            perms = []
            for p in self._permissions:
                if isinstance(p, str):
                    perms.append(Permission.from_string(p))
                else:
                    perms.append(p)
            self.permissions = PermissionSet(perms)
        else:
            self.permissions = PermissionSet()
        
        # Generate initial token
        self._generate_token()
        
        # Log creation
        audit_log.log(
            agent_id=self.id,
            agent_name=self.name,
            action_type=ActionType.AGENT_CREATED,
            status=ActionStatus.SUCCESS,
            details={
                "description": self.description,
                "owner": self.owner,
                "permissions": self.permissions.to_list(),
                "public_key": self.public_key_hex[:16] + "..."
            }
        )
    
    def _generate_token(self) -> str:
        """Generate a new token"""
        self._token = self._token_manager.generate(
            agent_id=self.id,
            agent_name=self.name,
            expires_in=self._token_expires_in,
            claims={
                "owner": self.owner,
                "permissions": self.permissions.to_list(),
                "public_key": self.public_key_hex
            }
        )
        
        audit_log.log(
            agent_id=self.id,
            agent_name=self.name,
            action_type=ActionType.TOKEN_GENERATED,
            status=ActionStatus.SUCCESS
        )
        
        return self._token
    
    # -------------------------
    # Cryptographic Properties
    # -------------------------
    
    @property
    def public_key_bytes(self) -> bytes:
        """Get public key as bytes"""
        return self._key_pair.public_key_bytes
    
    @property
    def public_key_hex(self) -> str:
        """Get public key as hex string (shareable)"""
        return self._key_pair.public_key_hex
    
    @property
    def key_algorithm(self) -> str:
        """Get signing algorithm"""
        return self._key_pair.algorithm
    
    # -------------------------
    # Token Properties
    # -------------------------
    
    @property
    def token(self) -> str:
        """Get current token"""
        self._check_status()
        
        if self._token and self._token_manager.is_expired(self._token):
            self._generate_token()
        
        return self._token
    
    def refresh_token(self) -> str:
        """Generate a new token"""
        self._check_status()
        return self._generate_token()
    
    def verify_token(self, token: str) -> bool:
        """Verify if a token belongs to this agent"""
        try:
            payload = self._token_manager.verify(token)
            return payload.get("aid") == self.id
        except InvalidTokenError:
            return False
    
    # -------------------------
    # Status Properties
    # -------------------------
    
    @property
    def is_active(self) -> bool:
        return self.status == AgentStatus.ACTIVE
    
    @property
    def is_revoked(self) -> bool:
        return self.status == AgentStatus.REVOKED
    
    @property
    def is_suspended(self) -> bool:
        return self.status == AgentStatus.SUSPENDED
    
    def _check_status(self):
        """Check if agent is active"""
        if self.status == AgentStatus.REVOKED:
            raise AgentRevokedError(f"Agent '{self.name}' has been revoked")
        if self.status == AgentStatus.SUSPENDED:
            raise AgentSuspendedError(f"Agent '{self.name}' is suspended")
    
    # -------------------------
    # Cryptographic Proofs
    # -------------------------
    
    def create_proof(self, challenge: str = None) -> Proof:
        """
        Create a cryptographic proof of identity.
        
        Args:
            challenge: Challenge string (auto-generated if not provided)
            
        Returns:
            Signed Proof object
        """
        self._check_status()
        
        if challenge is None:
            challenge = generate_challenge()
        
        proof = self._proof_generator.create_proof(challenge)
        
        audit_log.log(
            agent_id=self.id,
            agent_name=self.name,
            action_type=ActionType.PROOF_CREATED,
            status=ActionStatus.SUCCESS,
            details={"challenge": challenge[:32] + "..." if len(challenge) > 32 else challenge}
        )
        
        return proof
    
    def sign(self, message: bytes) -> bytes:
        """Sign arbitrary message"""
        self._check_status()
        return self._key_pair.sign(message)
    
    def verify_signature(self, message: bytes, signature: bytes) -> bool:
        """Verify a signature"""
        return self._key_pair.verify(message, signature)
    
    # -------------------------
    # Sessions
    # -------------------------
    
    def session(self, metadata: Optional[Dict[str, Any]] = None):
        """Create a session context"""
        self._check_status()
        return session_manager.session_context(
            agent_id=self.id,
            agent_name=self.name,
            metadata=metadata
        )
    
    def async_session(self, metadata: Optional[Dict[str, Any]] = None):
        """
        Create an async session context — for use with async agent workflows.

        Usage:
            async with agent.async_session():
                await some_async_tool()
        """
        self._check_status()
        return session_manager.session_context_async(
            agent_id=self.id,
            agent_name=self.name,
            metadata=metadata
        )

    def get_current_session(self) -> Optional[Session]:
        """Get current active session"""
        return session_manager.get_active(self.id)
    
    # -------------------------
    # Permissions
    # -------------------------
    
    def can(self, permission: Union[str, Permission]) -> bool:
        """Check if agent has permission"""
        return self.permissions.has(permission)
    
    def can_all(self, permissions: List[Union[str, Permission]]) -> bool:
        """Check if agent has all permissions"""
        return self.permissions.has_all(permissions)
    
    def can_any(self, permissions: List[Union[str, Permission]]) -> bool:
        """Check if agent has any permission"""
        return self.permissions.has_any(permissions)
    
    def grant_permission(self, permission: Union[str, Permission]):
        """Grant a permission"""
        self.permissions.add(permission)
        audit_log.log(
            agent_id=self.id,
            agent_name=self.name,
            action_type=ActionType.PERMISSION_GRANTED,
            status=ActionStatus.SUCCESS,
            details={"permission": str(permission)}
        )
    
    def revoke_permission(self, permission: Union[str, Permission]):
        """Revoke a permission"""
        self.permissions.remove(permission)
        audit_log.log(
            agent_id=self.id,
            agent_name=self.name,
            action_type=ActionType.PERMISSION_REVOKED,
            status=ActionStatus.SUCCESS,
            details={"permission": str(permission)}
        )
    
    # -------------------------
    # Lifecycle
    # -------------------------
    
    def revoke(self, reason: Optional[str] = None, revoked_by: Optional[str] = None):
        """Permanently revoke agent"""
        if self._token:
            self._token_manager.revoke(self._token)
        self.status = AgentStatus.REVOKED
        self._token = None
        
        audit_log.log(
            agent_id=self.id,
            agent_name=self.name,
            action_type=ActionType.AGENT_REVOKED,
            status=ActionStatus.SUCCESS,
            details={"reason": reason, "revoked_by": revoked_by}
        )
    
    def suspend(self, reason: Optional[str] = None, suspended_by: Optional[str] = None):
        """Temporarily suspend agent"""
        if self._token:
            self._token_manager.revoke(self._token)
        self.status = AgentStatus.SUSPENDED
        
        audit_log.log(
            agent_id=self.id,
            agent_name=self.name,
            action_type=ActionType.AGENT_SUSPENDED,
            status=ActionStatus.SUCCESS,
            details={"reason": reason, "suspended_by": suspended_by}
        )
    
    def reactivate(self):
        """Reactivate suspended agent"""
        if self.status == AgentStatus.REVOKED:
            raise AgentRevokedError("Cannot reactivate a revoked agent")
        
        self.status = AgentStatus.ACTIVE
        self._generate_token()
        
        audit_log.log(
            agent_id=self.id,
            agent_name=self.name,
            action_type=ActionType.AGENT_REACTIVATED,
            status=ActionStatus.SUCCESS
        )
    
    # -------------------------
    # Serialization
    # -------------------------

    @classmethod
    def _restore(cls, data: Dict[str, Any]) -> 'Agent':
        """
        Reconstruct an Agent from a stored record (e.g. from AgentStore).

        Bypasses __post_init__ so no AGENT_CREATED audit entry is emitted
        and no new key pair is generated — the stored private key is reused.

        Args:
            data: Dict with keys: id, name, description, owner, status,
                  created_at, permissions (list[str]), public_key_hex,
                  private_key_hex, metadata.

        Returns:
            Fully initialised Agent instance.
        """
        from .crypto import KeyPair
        from .permissions import Permission, PermissionSet

        obj = object.__new__(cls)
        obj.id = data["id"]
        obj.name = data["name"]
        obj.description = data.get("description")
        obj.owner = data.get("owner")
        obj.metadata = data.get("metadata")
        obj.created_at = datetime.fromisoformat(data["created_at"])
        obj.status = AgentStatus(data["status"])
        obj._permissions = None
        obj._token_expires_in = 86400
        obj._key_pair = KeyPair(bytes.fromhex(data["private_key_hex"]))
        obj._token_manager = TokenManager()
        obj._proof_generator = ProofGenerator(obj.id, obj._key_pair)
        perms = data.get("permissions", [])
        obj.permissions = PermissionSet([Permission.from_string(p) for p in perms])
        obj._token = None
        return obj

    def _to_store_dict(self) -> Dict[str, Any]:
        """Serialise agent to a dict suitable for AgentStore.save_agent()."""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "owner": self.owner,
            "status": self.status.value,
            "created_at": self.created_at.isoformat(),
            "permissions": self.permissions.to_list(),
            "public_key_hex": self.public_key_hex,
            "private_key_hex": self._key_pair.private_key_bytes.hex(),
            "metadata": self.metadata,
        }

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary (safe, no private key)"""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "owner": self.owner,
            "status": self.status.value,
            "created_at": self.created_at.isoformat() + "Z",
            "permissions": self.permissions.to_list(),
            "public_key": self.public_key_hex,
            "key_algorithm": self.key_algorithm,
            "metadata": self.metadata
        }
    
    def __str__(self) -> str:
        return f"Agent(id='{self.id}', name='{self.name}', status='{self.status.value}')"


class AgentRegistry:
    """
    Registry for managing multiple agents.
    
    Usage:
        registry = AgentRegistry()
        
        agent = registry.create(
            name="Analyst",
            permissions=["read:*"],
            owner="team@company.com"
        )
        
        # Get by ID
        agent = registry.get(agent_id)
        
        # Verify token
        agent = registry.verify_token(token)
        
        # Verify proof
        agent = registry.verify_proof(proof)
    """
    
    def __init__(self):
        self._agents: Dict[str, Agent] = {}
        self._token_manager = TokenManager()
        self._store: Optional['AgentStore'] = None
        self._key_store: Optional[Any] = None  # KeyStoreBackend

    def configure(self, store: 'AgentStore', key_store=None):
        """
        Attach a persistent store and optionally an external key store,
        then load existing agents from the database.

        Call once at startup before creating any agents.

        Args:
            store:     An AgentStore instance (SQLite-backed).
            key_store: Optional KeyStoreBackend for storing private keys
                       outside SQLite (e.g. EnvVarKeyStore, VaultKeyStore,
                       AWSSecretsKeyStore). If None, keys stay in SQLite.

        Example:
            from jannaauth import AgentRegistry, AgentStore
            from jannaauth.keystore import VaultKeyStore

            registry = AgentRegistry()
            registry.configure(
                AgentStore("agents.db"),
                key_store=VaultKeyStore(url="https://vault:8200", token="s.xxx"),
            )
        """
        self._store = store
        self._key_store = key_store

        # Restore revoked JTIs into the shared token manager
        self._token_manager.load_revoked_jtis(store.load_revoked_jtis())

        # Restore agents — load private key from key_store if configured,
        # otherwise fall back to the hex stored in SQLite.
        for data in store.load_all_agents():
            if key_store is not None:
                try:
                    data["private_key_hex"] = key_store.load(data["id"])
                except Exception as e:
                    # Key not found in external store — skip this agent
                    continue

            agent = Agent._restore(data)
            agent._token_manager = self._token_manager
            self._agents[agent.id] = agent
    
    def create(
        self,
        name: str,
        description: Optional[str] = None,
        owner: Optional[str] = None,
        permissions: List[Union[str, Permission]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        token_expires_in: int = 86400
    ) -> Agent:
        """Create and register a new agent"""
        agent = Agent(
            name=name,
            description=description,
            owner=owner,
            _permissions=permissions,
            metadata=metadata
        )
        agent._token_expires_in = token_expires_in
        agent._token_manager = self._token_manager
        agent._generate_token()
        
        self._agents[agent.id] = agent
        if self._store:
            store_data = agent._to_store_dict()
            if self._key_store is not None:
                # Save private key to external store; null it out in SQLite
                self._key_store.save(agent.id, store_data["private_key_hex"])
                store_data["private_key_hex"] = ""
            self._store.save_agent(store_data)
        return agent
    
    def get(self, agent_id: str) -> Agent:
        """Get agent by ID"""
        if agent_id not in self._agents:
            raise AgentNotFoundError(f"Agent not found: {agent_id}")
        return self._agents[agent_id]
    
    def get_by_name(self, name: str) -> Optional[Agent]:
        """Get agent by name"""
        for agent in self._agents.values():
            if agent.name == name:
                return agent
        return None
    
    def get_by_public_key(self, public_key_hex: str) -> Optional[Agent]:
        """Get agent by public key"""
        for agent in self._agents.values():
            if agent.public_key_hex == public_key_hex:
                return agent
        return None
    
    def verify_token(self, token: str) -> Agent:
        """Verify token and return agent"""
        payload = self._token_manager.verify(token)
        agent_id = payload.get("aid")
        
        if not agent_id:
            raise InvalidTokenError("Token missing agent ID")
        
        agent = self.get(agent_id)
        
        if agent.is_revoked:
            raise AgentRevokedError(f"Agent '{agent.name}' is revoked")
        if agent.is_suspended:
            raise AgentSuspendedError(f"Agent '{agent.name}' is suspended")
        
        audit_log.log(
            agent_id=agent.id,
            agent_name=agent.name,
            action_type=ActionType.TOKEN_VERIFIED,
            status=ActionStatus.SUCCESS
        )
        
        return agent
    
    def verify_proof(self, proof: Proof, expected_challenge: str = None) -> Agent:
        """Verify proof and return agent"""
        from .crypto import ProofVerifier
        
        verifier = ProofVerifier(self)
        verifier.verify(proof, expected_challenge=expected_challenge)
        
        agent = self.get(proof.agent_id)
        
        audit_log.log(
            agent_id=agent.id,
            agent_name=agent.name,
            action_type=ActionType.PROOF_VERIFIED,
            status=ActionStatus.SUCCESS
        )
        
        return agent
    
    def list(self, status: Optional[AgentStatus] = None) -> List[Agent]:
        """List agents"""
        agents = list(self._agents.values())
        if status:
            agents = [a for a in agents if a.status == status]
        return agents
    
    def revoke(self, agent_id: str, reason: Optional[str] = None):
        """Revoke an agent"""
        agent = self.get(agent_id)
        agent.revoke(reason=reason)
        if self._store:
            self._store.update_status(agent_id, "revoked")
    
    def revoke_all(self, owner: str, reason: Optional[str] = None):
        """Revoke all agents by owner"""
        for agent in self._agents.values():
            if agent.owner == owner:
                agent.revoke(reason=reason)
                if self._store:
                    self._store.update_status(agent.id, "revoked")
    
    def remove(self, agent_id: str):
        """Remove agent from registry"""
        if agent_id in self._agents:
            del self._agents[agent_id]
            if self._store:
                self._store.remove_agent(agent_id)
            if self._key_store is not None:
                self._key_store.delete(agent_id)
    
    @property
    def count(self) -> int:
        return len(self._agents)
    
    @property
    def active_count(self) -> int:
        return len([a for a in self._agents.values() if a.is_active])


# Global registry
agent_registry = AgentRegistry()
