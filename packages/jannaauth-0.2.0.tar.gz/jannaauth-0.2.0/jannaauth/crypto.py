"""
JannaAuth Cryptographic Identity
Ed25519 key pairs and challenge-response proofs for AI agents
"""

import hashlib
import hmac
import json
import secrets
import time
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, Tuple
from datetime import datetime

from .exceptions import (
    CryptoError,
    InvalidProofError,
    InvalidSignatureError,
    ProofExpiredError,
    KeyPairError
)

# Try to import cryptography library, fall back to HMAC-based if not available
try:
    from cryptography.hazmat.primitives.asymmetric import ed25519
    from cryptography.hazmat.primitives import serialization
    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False


class KeyPair:
    """
    Ed25519 key pair for agent identity.
    
    If cryptography library is not available, falls back to HMAC-based
    signing which provides similar security properties for our use case.
    
    Usage:
        keys = KeyPair()
        signature = keys.sign(b"message")
        keys.verify(b"message", signature)  # Returns True
    """
    
    def __init__(self, private_key_bytes: Optional[bytes] = None):
        """
        Create or load a key pair.

        Args:
            private_key_bytes: Optional existing private key to load

        Raises:
            CryptoError: If the 'cryptography' package is not installed.
        """
        if not CRYPTO_AVAILABLE:
            raise CryptoError(
                "Ed25519 requires the 'cryptography' package. "
                "Install it with: pip install 'jannaauth[crypto]'"
            )
        self._init_ed25519(private_key_bytes)
    
    def _init_ed25519(self, private_key_bytes: Optional[bytes] = None):
        """Initialize with Ed25519 (cryptography library)"""
        try:
            if private_key_bytes:
                self._private_key = ed25519.Ed25519PrivateKey.from_private_bytes(
                    private_key_bytes
                )
            else:
                self._private_key = ed25519.Ed25519PrivateKey.generate()
            
            self._public_key = self._private_key.public_key()
            self._algorithm = "ed25519"
        except Exception as e:
            raise KeyPairError(f"Failed to initialize Ed25519 key pair: {e}")
    
    def _init_hmac(self, secret_bytes: Optional[bytes] = None):
        """Initialize with HMAC fallback"""
        if secret_bytes:
            self._secret = secret_bytes
        else:
            self._secret = secrets.token_bytes(32)
        
        # Derive a "public key" hash for identification
        self._public_hash = hashlib.sha256(self._secret).digest()
        self._algorithm = "hmac-sha256"
    
    @property
    def public_key_bytes(self) -> bytes:
        """Get public key as bytes"""
        if CRYPTO_AVAILABLE:
            return self._public_key.public_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PublicFormat.Raw
            )
        else:
            return self._public_hash
    
    @property
    def public_key_hex(self) -> str:
        """Get public key as hex string (shareable)"""
        return self.public_key_bytes.hex()
    
    @property
    def private_key_bytes(self) -> bytes:
        """Get private key as bytes (keep secret!)"""
        if CRYPTO_AVAILABLE:
            return self._private_key.private_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PrivateFormat.Raw,
                encryption_algorithm=serialization.NoEncryption()
            )
        else:
            return self._secret
    
    @property
    def algorithm(self) -> str:
        """Get signing algorithm being used"""
        return self._algorithm
    
    def sign(self, message: bytes) -> bytes:
        """
        Sign a message.
        
        Args:
            message: Bytes to sign
            
        Returns:
            Signature bytes
        """
        if CRYPTO_AVAILABLE:
            return self._private_key.sign(message)
        else:
            return hmac.new(
                self._secret,
                message,
                hashlib.sha256
            ).digest()
    
    def verify(self, message: bytes, signature: bytes) -> bool:
        """
        Verify a signature.
        
        Args:
            message: Original message
            signature: Signature to verify
            
        Returns:
            True if valid
            
        Raises:
            InvalidSignatureError: If signature is invalid
        """
        try:
            if CRYPTO_AVAILABLE:
                self._public_key.verify(signature, message)
                return True
            else:
                expected = hmac.new(
                    self._secret,
                    message,
                    hashlib.sha256
                ).digest()
                if hmac.compare_digest(signature, expected):
                    return True
                raise InvalidSignatureError("Signature mismatch")
        except Exception as e:
            if isinstance(e, InvalidSignatureError):
                raise
            raise InvalidSignatureError(f"Signature verification failed: {e}")
    
    @classmethod
    def from_public_key_hex(cls, public_key_hex: str) -> 'PublicKeyOnly':
        """
        Create a verify-only instance from public key.
        
        Args:
            public_key_hex: Public key as hex string
            
        Returns:
            PublicKeyOnly instance (can only verify, not sign)
        """
        return PublicKeyOnly(bytes.fromhex(public_key_hex))


class PublicKeyOnly:
    """
    Public key only - can verify but not sign.
    Used by verifiers who only have the public key.
    """
    
    def __init__(self, public_key_bytes: bytes):
        self._public_key_bytes = public_key_bytes
        
        if CRYPTO_AVAILABLE:
            try:
                self._public_key = ed25519.Ed25519PublicKey.from_public_bytes(
                    public_key_bytes
                )
                self._algorithm = "ed25519"
            except Exception:
                # Might be HMAC-based key
                self._public_key = None
                self._algorithm = "hmac-sha256"
        else:
            self._public_key = None
            self._algorithm = "hmac-sha256"
    
    @property
    def public_key_bytes(self) -> bytes:
        return self._public_key_bytes
    
    @property
    def public_key_hex(self) -> str:
        return self._public_key_bytes.hex()
    
    def verify(self, message: bytes, signature: bytes) -> bool:
        """Verify a signature (Ed25519 only)"""
        if not CRYPTO_AVAILABLE or not self._public_key:
            raise CryptoError(
                "Cannot verify with public key only in HMAC mode. "
                "Install 'cryptography' package for Ed25519 support."
            )
        
        try:
            self._public_key.verify(signature, message)
            return True
        except Exception as e:
            raise InvalidSignatureError(f"Signature verification failed: {e}")


@dataclass
class Proof:
    """
    Cryptographic proof of agent identity.
    
    Contains everything needed to verify an agent's identity:
    - Challenge that was signed
    - Timestamp (for replay protection)
    - Signature
    - Public key
    - Agent ID
    """
    challenge: str
    timestamp: int
    signature: str  # Hex encoded
    public_key: str  # Hex encoded
    agent_id: str
    nonce: str  # Random nonce for uniqueness
    algorithm: str = "ed25519"
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "challenge": self.challenge,
            "timestamp": self.timestamp,
            "signature": self.signature,
            "public_key": self.public_key,
            "agent_id": self.agent_id,
            "nonce": self.nonce,
            "algorithm": self.algorithm
        }
    
    def to_json(self) -> str:
        """Convert to JSON string"""
        return json.dumps(self.to_dict())
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Proof':
        """Create from dictionary"""
        return cls(
            challenge=data["challenge"],
            timestamp=data["timestamp"],
            signature=data["signature"],
            public_key=data["public_key"],
            agent_id=data["agent_id"],
            nonce=data["nonce"],
            algorithm=data.get("algorithm", "ed25519")
        )
    
    @classmethod
    def from_json(cls, json_str: str) -> 'Proof':
        """Create from JSON string"""
        return cls.from_dict(json.loads(json_str))
    
    @property
    def message_bytes(self) -> bytes:
        """Get the message that was signed"""
        return f"{self.challenge}:{self.timestamp}:{self.nonce}".encode()
    
    @property
    def signature_bytes(self) -> bytes:
        """Get signature as bytes"""
        return bytes.fromhex(self.signature)
    
    @property
    def age_seconds(self) -> float:
        """Get age of proof in seconds"""
        return time.time() - self.timestamp
    
    def is_expired(self, max_age_seconds: int = 60) -> bool:
        """Check if proof has expired"""
        return self.age_seconds > max_age_seconds


class ProofGenerator:
    """
    Generates cryptographic proofs for an agent.
    
    Usage:
        generator = ProofGenerator(agent_id, key_pair)
        proof = generator.create_proof("challenge_string")
    """
    
    def __init__(self, agent_id: str, key_pair: KeyPair):
        self.agent_id = agent_id
        self.key_pair = key_pair
    
    def create_proof(self, challenge: str, timestamp: Optional[int] = None) -> Proof:
        """
        Create a signed proof of identity.
        
        Args:
            challenge: Challenge string to sign
            timestamp: Optional timestamp (defaults to now)
            
        Returns:
            Signed Proof object
        """
        timestamp = timestamp or int(time.time())
        nonce = secrets.token_hex(8)
        
        # Create message to sign
        message = f"{challenge}:{timestamp}:{nonce}".encode()
        
        # Sign it
        signature = self.key_pair.sign(message)
        
        return Proof(
            challenge=challenge,
            timestamp=timestamp,
            signature=signature.hex(),
            public_key=self.key_pair.public_key_hex,
            agent_id=self.agent_id,
            nonce=nonce,
            algorithm=self.key_pair.algorithm
        )


class ProofVerifier:
    """
    Verifies cryptographic proofs from agents.
    
    Usage:
        verifier = ProofVerifier(registry)
        is_valid = verifier.verify(proof, max_age_seconds=60)
    """
    
    def __init__(self, registry=None):
        """
        Initialize verifier.
        
        Args:
            registry: Optional AgentRegistry for looking up agents
        """
        self.registry = registry
    
    def verify(
        self,
        proof: Proof,
        expected_challenge: Optional[str] = None,
        max_age_seconds: int = 60,
        check_registry: bool = True
    ) -> bool:
        """
        Verify a proof of identity.
        
        Args:
            proof: Proof to verify
            expected_challenge: If provided, verify challenge matches
            max_age_seconds: Maximum age of proof (replay protection)
            check_registry: Whether to check agent exists and is active
            
        Returns:
            True if valid
            
        Raises:
            ProofExpiredError: If proof is too old
            InvalidProofError: If verification fails
            AgentNotFoundError: If agent not in registry
            AgentRevokedError: If agent is revoked
        """
        # 1. Check expiration
        if proof.is_expired(max_age_seconds):
            raise ProofExpiredError(
                f"Proof is {proof.age_seconds:.1f}s old, max is {max_age_seconds}s"
            )
        
        # 2. Check challenge if expected
        if expected_challenge and proof.challenge != expected_challenge:
            raise InvalidProofError("Challenge mismatch")
        
        # 3. Check agent in registry
        if check_registry and self.registry:
            from .agent import AgentStatus
            from .exceptions import AgentNotFoundError, AgentRevokedError, AgentSuspendedError
            
            try:
                agent = self.registry.get(proof.agent_id)
            except AgentNotFoundError:
                raise
            
            if agent.status == AgentStatus.REVOKED:
                raise AgentRevokedError(f"Agent {proof.agent_id} is revoked")
            
            if agent.status == AgentStatus.SUSPENDED:
                raise AgentSuspendedError(f"Agent {proof.agent_id} is suspended")
            
            # Verify public key matches registered key
            if agent.public_key_hex != proof.public_key:
                raise InvalidProofError("Public key does not match registered key")
        
        # 4. Verify signature
        if CRYPTO_AVAILABLE and proof.algorithm == "ed25519":
            try:
                public_key = ed25519.Ed25519PublicKey.from_public_bytes(
                    bytes.fromhex(proof.public_key)
                )
                public_key.verify(proof.signature_bytes, proof.message_bytes)
            except Exception as e:
                raise InvalidSignatureError(f"Signature verification failed: {e}")
        else:
            # For HMAC mode, we need the full key pair (self-verification only)
            # In production with HMAC, the verifier would need shared secret
            raise InvalidProofError(
                "HMAC proofs can only be self-verified. "
                "Install 'cryptography' for cross-verification."
            )
        
        return True
    
    def verify_dict(self, proof_dict: Dict[str, Any], **kwargs) -> bool:
        """Verify from dictionary"""
        return self.verify(Proof.from_dict(proof_dict), **kwargs)
    
    def verify_json(self, proof_json: str, **kwargs) -> bool:
        """Verify from JSON string"""
        return self.verify(Proof.from_json(proof_json), **kwargs)


def generate_challenge() -> str:
    """Generate a random challenge string"""
    return secrets.token_hex(16)
