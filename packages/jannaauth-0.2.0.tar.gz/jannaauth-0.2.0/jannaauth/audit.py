"""
JannaAuth Audit Logging
Track all agent actions for compliance and debugging
"""

import json
import time
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any, List, Union
from dataclasses import dataclass, field, asdict
from enum import Enum
import threading


class ActionType(Enum):
    """Types of auditable actions"""
    # Session
    SESSION_START = "session_start"
    SESSION_END = "session_end"
    
    # Token
    TOKEN_GENERATED = "token_generated"
    TOKEN_VERIFIED = "token_verified"
    TOKEN_EXPIRED = "token_expired"
    TOKEN_INVALID = "token_invalid"
    
    # Agent lifecycle
    AGENT_CREATED = "agent_created"
    AGENT_REVOKED = "agent_revoked"
    AGENT_SUSPENDED = "agent_suspended"
    AGENT_REACTIVATED = "agent_reactivated"
    
    # Actions
    ACTION_EXECUTED = "action_executed"
    ACTION_DENIED = "action_denied"
    
    # Proofs
    PROOF_CREATED = "proof_created"
    PROOF_VERIFIED = "proof_verified"
    PROOF_REJECTED = "proof_rejected"
    
    # Permissions
    PERMISSION_GRANTED = "permission_granted"
    PERMISSION_REVOKED = "permission_revoked"
    PERMISSION_CHECKED = "permission_checked"
    
    # Handoffs
    HANDOFF_SENT = "handoff_sent"
    HANDOFF_RECEIVED = "handoff_received"
    HANDOFF_REJECTED = "handoff_rejected"

    # Human approvals (v0.3.0)
    APPROVAL_REQUESTED = "approval_requested"
    APPROVAL_GRANTED = "approval_granted"
    APPROVAL_REJECTED = "approval_rejected"
    APPROVAL_EXPIRED = "approval_expired"


class ActionStatus(Enum):
    """Status of an action"""
    SUCCESS = "success"
    DENIED = "denied"
    ERROR = "error"
    PENDING = "pending"


@dataclass
class AuditEntry:
    """Single audit log entry"""
    timestamp: str
    agent_id: str
    agent_name: str
    action_type: str
    status: str
    resource: Optional[str] = None
    details: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    duration_ms: Optional[int] = None
    session_id: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {k: v for k, v in asdict(self).items() if v is not None}
    
    def to_json(self) -> str:
        """Convert to JSON string"""
        return json.dumps(self.to_dict())


class AuditLog:
    """
    Audit logging for JannaAuth.
    
    Tracks all agent actions including:
    - Session start/end
    - Token operations
    - Action execution
    - Permission checks
    - Proofs and verifications
    - Errors and denials
    
    Usage:
        audit = AuditLog()
        audit.log(agent_id, agent_name, ActionType.SESSION_START)
        entries = audit.query(agent_id="agent_123", limit=100)
    """
    
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        """Singleton pattern for global audit log"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return

        self._entries: List[AuditEntry] = []
        self._max_entries = 10000
        self._callbacks: List[callable] = []
        self._persist_path: Optional[Path] = None
        self._file_lock = threading.Lock()
        self._initialized = True
    
    def configure(
        self,
        persist_path: Union[str, Path] = None,
        max_entries: int = None
    ):
        """
        Configure persistence and/or entry cap.

        Call this once at startup, before any agents are created.

        Args:
            persist_path: Path to a .jsonl file. Created if it doesn't exist.
                          Existing entries are loaded into memory on first call.
            max_entries:  Override the default 10,000 in-memory cap.

        Example:
            from jannaauth import audit_log
            audit_log.configure(persist_path="logs/jannaauth.jsonl")
        """
        if max_entries is not None:
            self._max_entries = max_entries

        if persist_path is not None:
            path = Path(persist_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            self._persist_path = path
            self._load_from_file()

    def _load_from_file(self):
        """Load existing entries from the .jsonl file into memory."""
        if not self._persist_path or not self._persist_path.exists():
            return

        loaded = []
        with open(self._persist_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    loaded.append(AuditEntry(**data))
                except Exception:
                    pass  # Skip malformed lines

        # Merge: file entries first, then any entries already in memory
        self._entries = loaded + self._entries
        if len(self._entries) > self._max_entries:
            self._entries = self._entries[-self._max_entries:]

    def _append_to_file(self, entry: AuditEntry):
        """Append a single entry to the .jsonl file."""
        if not self._persist_path:
            return
        with self._file_lock:
            with open(self._persist_path, "a", encoding="utf-8") as f:
                f.write(entry.to_json() + "\n")

    def log(
        self,
        agent_id: str,
        agent_name: str,
        action_type: ActionType,
        status: ActionStatus = ActionStatus.SUCCESS,
        resource: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        error: Optional[str] = None,
        duration_ms: Optional[int] = None,
        session_id: Optional[str] = None
    ) -> AuditEntry:
        """Log an action"""
        entry = AuditEntry(
            timestamp=datetime.utcnow().isoformat() + "Z",
            agent_id=agent_id,
            agent_name=agent_name,
            action_type=action_type.value,
            status=status.value,
            resource=resource,
            details=details,
            error=error,
            duration_ms=duration_ms,
            session_id=session_id
        )
        
        self._entries.append(entry)
        self._append_to_file(entry)

        if len(self._entries) > self._max_entries:
            self._entries = self._entries[-self._max_entries:]

        for callback in self._callbacks:
            try:
                callback(entry)
            except Exception:
                pass
        
        return entry
    
    def query(
        self,
        agent_id: Optional[str] = None,
        agent_name: Optional[str] = None,
        action_type: Optional[ActionType] = None,
        status: Optional[ActionStatus] = None,
        session_id: Optional[str] = None,
        since: Optional[datetime] = None,
        until: Optional[datetime] = None,
        limit: int = 100
    ) -> List[AuditEntry]:
        """Query audit log entries"""
        results = []
        
        for entry in reversed(self._entries):
            if agent_id and entry.agent_id != agent_id:
                continue
            if agent_name and entry.agent_name != agent_name:
                continue
            if action_type and entry.action_type != action_type.value:
                continue
            if status and entry.status != status.value:
                continue
            if session_id and entry.session_id != session_id:
                continue
            if since:
                entry_time = datetime.fromisoformat(entry.timestamp.rstrip('Z'))
                if entry_time < since:
                    continue
            if until:
                entry_time = datetime.fromisoformat(entry.timestamp.rstrip('Z'))
                if entry_time > until:
                    continue
            
            results.append(entry)
            
            if len(results) >= limit:
                break
        
        return results
    
    def get_agent_history(self, agent_id: str, limit: int = 100) -> List[AuditEntry]:
        """Get all entries for a specific agent"""
        return self.query(agent_id=agent_id, limit=limit)
    
    def get_session_history(self, session_id: str) -> List[AuditEntry]:
        """Get all entries for a specific session"""
        return self.query(session_id=session_id, limit=1000)
    
    def add_callback(self, callback: callable):
        """Add a callback to be notified of new entries"""
        self._callbacks.append(callback)
    
    def remove_callback(self, callback: callable):
        """Remove a callback"""
        if callback in self._callbacks:
            self._callbacks.remove(callback)
    
    def export(self, format: str = "json") -> str:
        """Export all entries"""
        if format == "json":
            return json.dumps([e.to_dict() for e in self._entries], indent=2)
        elif format == "csv":
            if not self._entries:
                return ""
            
            headers = ["timestamp", "agent_id", "agent_name", "action_type", 
                      "status", "resource", "error", "duration_ms", "session_id"]
            
            lines = [",".join(headers)]
            for entry in self._entries:
                row = []
                for h in headers:
                    val = getattr(entry, h, "") or ""
                    val = str(val).replace('"', '""')
                    if ',' in val or '"' in val:
                        val = f'"{val}"'
                    row.append(val)
                lines.append(",".join(row))
            
            return "\n".join(lines)
        else:
            raise ValueError(f"Unknown format: {format}")
    
    def clear(self):
        """Clear all in-memory entries and truncate the persist file if configured."""
        self._entries = []
        if self._persist_path and self._persist_path.exists():
            with self._file_lock:
                self._persist_path.write_text("", encoding="utf-8")
    
    @property
    def count(self) -> int:
        """Total number of entries"""
        return len(self._entries)


# Global audit log instance
audit_log = AuditLog()
