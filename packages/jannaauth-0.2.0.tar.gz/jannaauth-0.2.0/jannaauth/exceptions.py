"""
JannaAuth Exceptions
Custom exceptions for JannaAuth SDK v0.2.0
"""


class JannaAuthError(Exception):
    """Base exception for JannaAuth"""
    pass


# Agent Errors
class AgentNotFoundError(JannaAuthError):
    """Agent does not exist"""
    pass


class AgentRevokedError(JannaAuthError):
    """Agent has been revoked"""
    pass


class AgentSuspendedError(JannaAuthError):
    """Agent is temporarily suspended"""
    pass


# Token Errors
class InvalidTokenError(JannaAuthError):
    """Token is invalid or expired"""
    pass


class TokenExpiredError(InvalidTokenError):
    """Token has expired"""
    pass


# Session Errors
class SessionError(JannaAuthError):
    """Session-related error"""
    pass


class NoActiveSessionError(SessionError):
    """No active session for agent"""
    pass


# Permission Errors
class PermissionError(JannaAuthError):
    """Permission-related error"""
    pass


class PermissionDeniedError(PermissionError):
    """Agent does not have required permission"""
    pass


class InvalidPermissionError(PermissionError):
    """Permission format is invalid"""
    pass


# Cryptographic Errors
class CryptoError(JannaAuthError):
    """Cryptographic operation error"""
    pass


class InvalidProofError(CryptoError):
    """Proof verification failed"""
    pass


class InvalidSignatureError(CryptoError):
    """Signature verification failed"""
    pass


class ProofExpiredError(CryptoError):
    """Proof has expired"""
    pass


class KeyPairError(CryptoError):
    """Key pair generation or loading error"""
    pass


# Handoff Errors
class HandoffError(JannaAuthError):
    """Agent-to-agent handoff error"""
    pass


class InvalidRecipientError(HandoffError):
    """Data not intended for this agent"""
    pass


class HandoffVerificationError(HandoffError):
    """Handoff verification failed"""
    pass


# Approval Errors
class ApprovalError(JannaAuthError):
    """Base class for human approval workflow errors"""
    pass


class ApprovalPendingError(ApprovalError):
    """
    Action is awaiting human approval.

    Raised by @protect(requires_approval=True) when wait=False (default).
    Catch this to get the ApprovalRequest and poll for a decision later.

    Example:
        try:
            delete_records(ids)
        except ApprovalPendingError as e:
            print(f"Approval requested: {e.request.id}")
            # Poll approval_queue.get(e.request.id) until resolved
    """
    def __init__(self, message: str, request=None):
        super().__init__(message)
        self.request = request  # ApprovalRequest instance


class ApprovalRejectedError(ApprovalError):
    """
    Action was rejected by a human approver.

    Raised when wait=True and the approval is rejected.
    """
    def __init__(self, message: str, request=None):
        super().__init__(message)
        self.request = request


class ApprovalExpiredError(ApprovalError):
    """
    Approval request timed out before a decision was made.

    Raised when wait=True and the timeout is exceeded.
    """
    def __init__(self, message: str, request=None):
        super().__init__(message)
        self.request = request


class ApprovalNotFoundError(ApprovalError):
    """Approval request ID does not exist"""
    pass
