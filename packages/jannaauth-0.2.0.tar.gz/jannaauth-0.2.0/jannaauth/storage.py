"""
JannaAuth Storage Backend
SQLite persistence for AgentRegistry and token revocation
"""

import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Set


class AgentStore:
    """
    SQLite-backed persistence for agents and revoked token JTIs.

    Pass an instance to AgentRegistry.configure() to enable persistence.

    Usage:
        from jannaauth import AgentStore, AgentRegistry

        registry = AgentRegistry()
        registry.configure(AgentStore("jannaauth.db"))

        # All agents created, revoked, or suspended are now persisted.
        # On restart, call registry.configure() again to reload.

    Security note:
        Private keys are stored as hex in the database. For high-security
        environments, replace this with an HSM or secrets vault and override
        save_agent() / load_all_agents() accordingly.
    """

    def __init__(self, db_path: str):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self._connect() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS agents (
                    id              TEXT PRIMARY KEY,
                    name            TEXT NOT NULL,
                    description     TEXT,
                    owner           TEXT,
                    status          TEXT NOT NULL DEFAULT 'active',
                    created_at      TEXT NOT NULL,
                    permissions     TEXT NOT NULL DEFAULT '[]',
                    public_key_hex  TEXT NOT NULL,
                    private_key_hex TEXT NOT NULL,
                    metadata        TEXT
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS revoked_tokens (
                    jti        TEXT PRIMARY KEY,
                    agent_id   TEXT NOT NULL,
                    revoked_at TEXT NOT NULL
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS pending_approvals (
                    id               TEXT PRIMARY KEY,
                    agent_id         TEXT NOT NULL,
                    agent_name       TEXT NOT NULL,
                    action           TEXT NOT NULL,
                    details          TEXT,
                    status           TEXT NOT NULL DEFAULT 'pending',
                    created_at       TEXT NOT NULL,
                    expires_at       TEXT NOT NULL,
                    resolved_at      TEXT,
                    resolved_by      TEXT,
                    rejection_reason TEXT,
                    session_id       TEXT,
                    metadata         TEXT
                )
            """)

    # -------------------------
    # Agent persistence
    # -------------------------

    def save_agent(self, agent_data: Dict[str, Any]):
        """Insert or update an agent record."""
        with self._connect() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO agents
                (id, name, description, owner, status, created_at,
                 permissions, public_key_hex, private_key_hex, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                agent_data["id"],
                agent_data["name"],
                agent_data.get("description"),
                agent_data.get("owner"),
                agent_data["status"],
                agent_data["created_at"],
                json.dumps(agent_data["permissions"]),
                agent_data["public_key_hex"],
                agent_data["private_key_hex"],
                json.dumps(agent_data["metadata"]) if agent_data.get("metadata") else None,
            ))

    def update_status(self, agent_id: str, status: str):
        """Update agent status (active / suspended / revoked)."""
        with self._connect() as conn:
            conn.execute(
                "UPDATE agents SET status = ? WHERE id = ?",
                (status, agent_id),
            )

    def load_all_agents(self) -> List[Dict[str, Any]]:
        """Return all agent records from the database."""
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM agents").fetchall()
            result = []
            for row in rows:
                data = dict(row)
                data["permissions"] = json.loads(data["permissions"])
                data["metadata"] = json.loads(data["metadata"]) if data["metadata"] else None
                result.append(data)
            return result

    def remove_agent(self, agent_id: str):
        """Delete an agent record."""
        with self._connect() as conn:
            conn.execute("DELETE FROM agents WHERE id = ?", (agent_id,))

    # -------------------------
    # Token revocation
    # -------------------------

    def save_revoked_jti(self, jti: str, agent_id: str):
        """Persist a single revoked token JTI."""
        with self._connect() as conn:
            conn.execute(
                "INSERT OR IGNORE INTO revoked_tokens (jti, agent_id, revoked_at) VALUES (?, ?, ?)",
                (jti, agent_id, datetime.utcnow().isoformat() + "Z"),
            )

    def save_revoked_jtis(self, jtis: List[str], agent_id: str):
        """Persist multiple revoked JTIs at once (e.g. on agent revocation)."""
        now = datetime.utcnow().isoformat() + "Z"
        with self._connect() as conn:
            conn.executemany(
                "INSERT OR IGNORE INTO revoked_tokens (jti, agent_id, revoked_at) VALUES (?, ?, ?)",
                [(jti, agent_id, now) for jti in jtis],
            )

    def load_revoked_jtis(self) -> Set[str]:
        """Load all revoked JTIs from the database."""
        with self._connect() as conn:
            rows = conn.execute("SELECT jti FROM revoked_tokens").fetchall()
            return {row[0] for row in rows}

    # -------------------------
    # Approval persistence
    # -------------------------

    def save_approval(self, approval_data: Dict[str, Any]):
        """Insert or update an approval request record."""
        with self._connect() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO pending_approvals
                (id, agent_id, agent_name, action, details, status,
                 created_at, expires_at, resolved_at, resolved_by,
                 rejection_reason, session_id, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                approval_data["id"],
                approval_data["agent_id"],
                approval_data["agent_name"],
                approval_data["action"],
                json.dumps(approval_data.get("details")) if approval_data.get("details") else None,
                approval_data["status"],
                approval_data["created_at"],
                approval_data["expires_at"],
                approval_data.get("resolved_at"),
                approval_data.get("resolved_by"),
                approval_data.get("rejection_reason"),
                approval_data.get("session_id"),
                json.dumps(approval_data.get("metadata")) if approval_data.get("metadata") else None,
            ))

    def update_approval_status(
        self,
        approval_id: str,
        status: str,
        resolved_at: Optional[str] = None,
        resolved_by: Optional[str] = None,
        rejection_reason: Optional[str] = None,
    ):
        """Update an approval's status and resolution details."""
        with self._connect() as conn:
            conn.execute("""
                UPDATE pending_approvals
                SET status = ?, resolved_at = ?, resolved_by = ?, rejection_reason = ?
                WHERE id = ?
            """, (status, resolved_at, resolved_by, rejection_reason, approval_id))

    def load_pending_approvals(self, agent_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Load pending approval requests, optionally filtered by agent."""
        with self._connect() as conn:
            if agent_id:
                rows = conn.execute(
                    "SELECT * FROM pending_approvals WHERE status = 'pending' AND agent_id = ?",
                    (agent_id,)
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM pending_approvals WHERE status = 'pending'"
                ).fetchall()

            result = []
            for row in rows:
                data = dict(row)
                data["details"] = json.loads(data["details"]) if data["details"] else None
                data["metadata"] = json.loads(data["metadata"]) if data["metadata"] else None
                result.append(data)
            return result

    def load_all_approvals(
        self,
        agent_id: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """Load approval records with optional filters."""
        query = "SELECT * FROM pending_approvals WHERE 1=1"
        params = []
        if agent_id:
            query += " AND agent_id = ?"
            params.append(agent_id)
        if status:
            query += " AND status = ?"
            params.append(status)
        query += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)

        with self._connect() as conn:
            rows = conn.execute(query, params).fetchall()
            result = []
            for row in rows:
                data = dict(row)
                data["details"] = json.loads(data["details"]) if data["details"] else None
                data["metadata"] = json.loads(data["metadata"]) if data["metadata"] else None
                result.append(data)
            return result
