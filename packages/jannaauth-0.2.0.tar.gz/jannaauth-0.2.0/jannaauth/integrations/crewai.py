"""
JannaAuth CrewAI Integration
Wrapper for CrewAI agents with JannaAuth identity
"""

from typing import Optional, Dict, Any, List, Union, TYPE_CHECKING
from functools import wraps

from ..agent import Agent, AgentRegistry, agent_registry
from ..permissions import Permission, PermissionSet, protect
from ..audit import audit_log, ActionType, ActionStatus
from ..handoff import HandoffManager, Handoff, create_handoff, receive_handoff
from ..session import session_manager
from ..exceptions import PermissionDeniedError

# Try to import CrewAI
try:
    from crewai import Agent as CrewAgent
    from crewai import Task, Crew
    CREWAI_AVAILABLE = True
except ImportError:
    CREWAI_AVAILABLE = False
    CrewAgent = object  # Placeholder


class JannaCrewAgent:
    """
    CrewAI Agent wrapper with JannaAuth identity.
    
    Every action by this agent is:
    - Identified (unique agent ID)
    - Authenticated (cryptographic proofs)
    - Permission-checked
    - Logged (full audit trail)
    
    Usage:
        from jannaauth.integrations.crewai import JannaCrewAgent
        
        researcher = JannaCrewAgent(
            name="Researcher",
            permissions=["read:web", "read:database"],
            role="Senior Researcher",
            goal="Find accurate information",
            tools=[SearchTool()]
        )
        
        with researcher.session():
            # All actions tracked
            result = researcher.execute_task(task)
    """
    
    def __init__(
        self,
        name: str,
        permissions: List[str] = None,
        owner: Optional[str] = None,
        registry: AgentRegistry = None,
        # CrewAI Agent parameters
        role: str = None,
        goal: str = None,
        backstory: str = None,
        tools: List = None,
        verbose: bool = False,
        allow_delegation: bool = False,
        **crew_kwargs
    ):
        """
        Create a JannaAuth-wrapped CrewAI agent.
        
        Args:
            name: Agent name (used for both JannaAuth and CrewAI)
            permissions: List of permissions like ["read:database"]
            owner: Owner email/team
            registry: AgentRegistry (uses global if not provided)
            role: CrewAI role
            goal: CrewAI goal
            backstory: CrewAI backstory
            tools: CrewAI tools
            verbose: CrewAI verbose flag
            allow_delegation: CrewAI delegation flag
            **crew_kwargs: Additional CrewAI parameters
        """
        if not CREWAI_AVAILABLE:
            raise ImportError(
                "CrewAI is not installed. Install it with: pip install crewai"
            )
        
        # Create JannaAuth identity
        self._registry = registry or agent_registry
        self.identity = self._registry.create(
            name=name,
            permissions=permissions or [],
            owner=owner,
            metadata={
                "framework": "crewai",
                "role": role
            }
        )
        
        # Create CrewAI agent
        self._crew_agent = CrewAgent(
            role=role or name,
            goal=goal or f"Fulfill the role of {name}",
            backstory=backstory or f"An AI agent named {name}",
            tools=tools or [],
            verbose=verbose,
            allow_delegation=allow_delegation,
            **crew_kwargs
        )
        
        # Store config
        self._role = role
        self._goal = goal
        self._tools = tools or []
    
    @property
    def id(self) -> str:
        """Agent ID"""
        return self.identity.id
    
    @property
    def name(self) -> str:
        """Agent name"""
        return self.identity.name
    
    @property
    def permissions(self) -> PermissionSet:
        """Agent permissions"""
        return self.identity.permissions
    
    @property
    def crew_agent(self) -> CrewAgent:
        """Underlying CrewAI agent"""
        return self._crew_agent
    
    def session(self, metadata: Optional[Dict[str, Any]] = None):
        """Create session context"""
        return self.identity.session(metadata=metadata)
    
    def can(self, permission: str) -> bool:
        """Check permission"""
        return self.identity.can(permission)
    
    def create_proof(self, challenge: str = None):
        """Create cryptographic proof"""
        return self.identity.create_proof(challenge)
    
    def execute_task(self, task, context: str = None) -> str:
        """
        Execute a CrewAI task with JannaAuth tracking.
        
        Args:
            task: CrewAI Task object
            context: Optional context string
            
        Returns:
            Task result
        """
        task_description = task.description if hasattr(task, 'description') else str(task)
        
        with self.session(metadata={"task": task_description[:100]}):
            # Log task start
            audit_log.log(
                agent_id=self.id,
                agent_name=self.name,
                action_type=ActionType.ACTION_EXECUTED,
                status=ActionStatus.SUCCESS,
                resource="crewai.task",
                details={
                    "task": task_description[:200],
                    "context": context[:100] if context else None
                }
            )
            
            # Execute via CrewAI
            result = self._crew_agent.execute_task(task, context)
            
            return result
    
    def send_to(self, recipient_id: str, data: Dict[str, Any]) -> Handoff:
        """
        Send data to another agent securely.
        
        Args:
            recipient_id: Target agent ID
            data: Data to send
            
        Returns:
            Signed Handoff
        """
        return create_handoff(self.identity, recipient_id, data)
    
    def receive_from(self, handoff: Handoff) -> Dict[str, Any]:
        """
        Receive data from another agent.
        
        Args:
            handoff: Handoff to receive
            
        Returns:
            Received data
        """
        return receive_handoff(self.identity, handoff)


class JannaCrew:
    """
    CrewAI Crew wrapper with JannaAuth tracking.
    
    All agents and their interactions are tracked.
    
    Usage:
        from jannaauth.integrations.crewai import JannaCrewAgent, JannaCrew
        
        researcher = JannaCrewAgent(name="Researcher", ...)
        writer = JannaCrewAgent(name="Writer", ...)
        
        crew = JannaCrew(
            agents=[researcher, writer],
            tasks=[research_task, write_task]
        )
        
        result = crew.kickoff()
        
        # Full audit trail available
        crew.get_audit_trail()
    """
    
    def __init__(
        self,
        agents: List[JannaCrewAgent],
        tasks: List = None,
        process: str = "sequential",
        verbose: bool = False,
        **crew_kwargs
    ):
        """
        Create a JannaAuth-tracked Crew.
        
        Args:
            agents: List of JannaCrewAgent
            tasks: List of CrewAI Tasks
            process: "sequential" or "hierarchical"
            verbose: Verbose output
            **crew_kwargs: Additional Crew parameters
        """
        if not CREWAI_AVAILABLE:
            raise ImportError("CrewAI is not installed")
        
        self._janna_agents = agents
        self._tasks = tasks or []
        
        # Create underlying Crew with CrewAI agents
        self._crew = Crew(
            agents=[a.crew_agent for a in agents],
            tasks=tasks,
            process=process,
            verbose=verbose,
            **crew_kwargs
        )
    
    def kickoff(self) -> str:
        """
        Start the crew with full tracking.
        
        Returns:
            Crew result
        """
        # Log crew start
        for agent in self._janna_agents:
            audit_log.log(
                agent_id=agent.id,
                agent_name=agent.name,
                action_type=ActionType.SESSION_START,
                status=ActionStatus.SUCCESS,
                resource="crewai.crew",
                details={"crew_size": len(self._janna_agents)}
            )
        
        # Run crew
        result = self._crew.kickoff()
        
        # Log crew end
        for agent in self._janna_agents:
            audit_log.log(
                agent_id=agent.id,
                agent_name=agent.name,
                action_type=ActionType.SESSION_END,
                status=ActionStatus.SUCCESS,
                resource="crewai.crew"
            )
        
        return result
    
    def get_audit_trail(self) -> Dict[str, List]:
        """
        Get audit trail for all agents in crew.
        
        Returns:
            Dict mapping agent_id to audit entries
        """
        trail = {}
        for agent in self._janna_agents:
            entries = audit_log.get_agent_history(agent.id)
            trail[agent.id] = [e.to_dict() for e in entries]
        return trail
    
    @property
    def agents(self) -> List[JannaCrewAgent]:
        """Get all JannaAuth agents"""
        return self._janna_agents


def protected_tool(requires: Union[str, List[str]]):
    """
    Decorator to make CrewAI tools permission-protected.
    
    Usage:
        @protected_tool(requires="read:database")
        def search_database(query: str) -> str:
            return db.search(query)
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            session = session_manager.get_current()
            
            if not session:
                raise PermissionDeniedError(
                    f"Tool '{func.__name__}' requires active session"
                )
            
            # Get agent
            try:
                agent = agent_registry.get(session.agent_id)
            except Exception:
                raise PermissionDeniedError(f"Agent not found")
            
            # Check permissions
            req_list = [requires] if isinstance(requires, str) else requires
            if not agent.permissions.has_all(req_list):
                audit_log.log(
                    agent_id=session.agent_id,
                    agent_name=session.agent_name,
                    action_type=ActionType.ACTION_DENIED,
                    status=ActionStatus.DENIED,
                    resource=func.__name__,
                    error=f"Missing permissions: {req_list}"
                )
                raise PermissionDeniedError(
                    f"Tool '{func.__name__}' requires: {req_list}"
                )
            
            # Execute
            audit_log.log(
                agent_id=session.agent_id,
                agent_name=session.agent_name,
                action_type=ActionType.ACTION_EXECUTED,
                status=ActionStatus.SUCCESS,
                resource=func.__name__
            )
            
            return func(*args, **kwargs)
        
        return wrapper
    return decorator
