"""
JannaAuth LangChain Integration
Callbacks and protected tools for LangChain agents
"""

from typing import Optional, Dict, Any, List, Union, TYPE_CHECKING
from functools import wraps
import time

from ..agent import Agent, AgentRegistry, agent_registry
from ..permissions import Permission, PermissionSet
from ..audit import audit_log, ActionType, ActionStatus
from ..session import session_manager, Session
from ..exceptions import PermissionDeniedError, NoActiveSessionError

# Try to import LangChain
try:
    from langchain.callbacks.base import BaseCallbackHandler
    from langchain.schema import AgentAction, AgentFinish, LLMResult
    from langchain.tools import BaseTool
    LANGCHAIN_AVAILABLE = True
except ImportError:
    LANGCHAIN_AVAILABLE = False
    BaseCallbackHandler = object
    BaseTool = object


class JannaAuthCallback(BaseCallbackHandler):
    """
    LangChain callback handler for JannaAuth tracking.
    
    Automatically tracks:
    - LLM calls
    - Tool usage
    - Agent actions
    - Chain execution
    - Errors
    
    Usage:
        from jannaauth.integrations.langchain import JannaAuthCallback
        from jannaauth import Agent
        
        agent_identity = Agent(name="Analyst", permissions=["read:*"])
        
        callback = JannaAuthCallback(agent_identity)
        
        # Use with any LangChain component
        llm = ChatAnthropic(callbacks=[callback])
        chain = LLMChain(llm=llm, callbacks=[callback])
        agent = AgentExecutor(callbacks=[callback])
    """
    
    def __init__(
        self,
        agent: Agent,
        track_llm_calls: bool = True,
        track_tool_calls: bool = True,
        track_chain_calls: bool = True
    ):
        """
        Initialize callback handler.
        
        Args:
            agent: JannaAuth Agent identity
            track_llm_calls: Whether to track LLM invocations
            track_tool_calls: Whether to track tool usage
            track_chain_calls: Whether to track chain execution
        """
        if not LANGCHAIN_AVAILABLE:
            raise ImportError(
                "LangChain is not installed. Install with: pip install langchain"
            )
        
        self.agent = agent
        self.track_llm_calls = track_llm_calls
        self.track_tool_calls = track_tool_calls
        self.track_chain_calls = track_chain_calls
        
        self._session: Optional[Session] = None
        self._call_stack: List[Dict] = []
        self._start_times: Dict[str, float] = {}
    
    def _get_session(self) -> Optional[Session]:
        """Get current session"""
        return session_manager.get_active(self.agent.id)
    
    def _log(
        self,
        action_type: ActionType,
        status: ActionStatus,
        resource: str,
        details: Dict = None,
        error: str = None,
        duration_ms: int = None
    ):
        """Log an action"""
        session = self._get_session()
        audit_log.log(
            agent_id=self.agent.id,
            agent_name=self.agent.name,
            action_type=action_type,
            status=status,
            resource=resource,
            details=details,
            error=error,
            duration_ms=duration_ms,
            session_id=session.session_id if session else None
        )
    
    # -------------------------
    # LLM Callbacks
    # -------------------------
    
    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        **kwargs
    ):
        """Called when LLM starts"""
        if not self.track_llm_calls:
            return
        
        run_id = str(kwargs.get('run_id', ''))
        self._start_times[f"llm_{run_id}"] = time.time()
        
        self._log(
            ActionType.ACTION_EXECUTED,
            ActionStatus.PENDING,
            resource="langchain.llm",
            details={
                "model": serialized.get('name', 'unknown'),
                "prompt_count": len(prompts)
            }
        )
    
    def on_llm_end(self, response: 'LLMResult', **kwargs):
        """Called when LLM completes"""
        if not self.track_llm_calls:
            return
        
        run_id = str(kwargs.get('run_id', ''))
        start_key = f"llm_{run_id}"
        duration = None
        if start_key in self._start_times:
            duration = int((time.time() - self._start_times[start_key]) * 1000)
            del self._start_times[start_key]
        
        self._log(
            ActionType.ACTION_EXECUTED,
            ActionStatus.SUCCESS,
            resource="langchain.llm",
            details={
                "generations": len(response.generations) if response.generations else 0
            },
            duration_ms=duration
        )
    
    def on_llm_error(self, error: Exception, **kwargs):
        """Called when LLM errors"""
        if not self.track_llm_calls:
            return
        
        self._log(
            ActionType.ACTION_EXECUTED,
            ActionStatus.ERROR,
            resource="langchain.llm",
            error=str(error)
        )
    
    # -------------------------
    # Tool Callbacks
    # -------------------------
    
    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        **kwargs
    ):
        """Called when tool starts"""
        if not self.track_tool_calls:
            return
        
        tool_name = serialized.get('name', 'unknown')
        run_id = str(kwargs.get('run_id', ''))
        self._start_times[f"tool_{run_id}"] = time.time()
        
        self._log(
            ActionType.ACTION_EXECUTED,
            ActionStatus.PENDING,
            resource=f"langchain.tool.{tool_name}",
            details={
                "tool": tool_name,
                "input_length": len(input_str)
            }
        )
    
    def on_tool_end(self, output: str, **kwargs):
        """Called when tool completes"""
        if not self.track_tool_calls:
            return
        
        run_id = str(kwargs.get('run_id', ''))
        start_key = f"tool_{run_id}"
        duration = None
        if start_key in self._start_times:
            duration = int((time.time() - self._start_times[start_key]) * 1000)
            del self._start_times[start_key]
        
        self._log(
            ActionType.ACTION_EXECUTED,
            ActionStatus.SUCCESS,
            resource="langchain.tool",
            details={"output_length": len(output)},
            duration_ms=duration
        )
    
    def on_tool_error(self, error: Exception, **kwargs):
        """Called when tool errors"""
        if not self.track_tool_calls:
            return
        
        self._log(
            ActionType.ACTION_EXECUTED,
            ActionStatus.ERROR,
            resource="langchain.tool",
            error=str(error)
        )
    
    # -------------------------
    # Chain Callbacks
    # -------------------------
    
    def on_chain_start(
        self,
        serialized: Dict[str, Any],
        inputs: Dict[str, Any],
        **kwargs
    ):
        """Called when chain starts"""
        if not self.track_chain_calls:
            return
        
        run_id = str(kwargs.get('run_id', ''))
        self._start_times[f"chain_{run_id}"] = time.time()
        
        self._log(
            ActionType.SESSION_START,
            ActionStatus.SUCCESS,
            resource="langchain.chain",
            details={
                "chain": serialized.get('name', 'unknown'),
                "input_keys": list(inputs.keys())
            }
        )
    
    def on_chain_end(self, outputs: Dict[str, Any], **kwargs):
        """Called when chain completes"""
        if not self.track_chain_calls:
            return
        
        run_id = str(kwargs.get('run_id', ''))
        start_key = f"chain_{run_id}"
        duration = None
        if start_key in self._start_times:
            duration = int((time.time() - self._start_times[start_key]) * 1000)
            del self._start_times[start_key]
        
        self._log(
            ActionType.SESSION_END,
            ActionStatus.SUCCESS,
            resource="langchain.chain",
            details={"output_keys": list(outputs.keys())},
            duration_ms=duration
        )
    
    def on_chain_error(self, error: Exception, **kwargs):
        """Called when chain errors"""
        if not self.track_chain_calls:
            return
        
        self._log(
            ActionType.SESSION_END,
            ActionStatus.ERROR,
            resource="langchain.chain",
            error=str(error)
        )
    
    # -------------------------
    # Agent Callbacks
    # -------------------------
    
    def on_agent_action(self, action: 'AgentAction', **kwargs):
        """Called when agent takes action"""
        self._log(
            ActionType.ACTION_EXECUTED,
            ActionStatus.SUCCESS,
            resource="langchain.agent.action",
            details={
                "tool": action.tool,
                "log": action.log[:200] if action.log else None
            }
        )
    
    def on_agent_finish(self, finish: 'AgentFinish', **kwargs):
        """Called when agent finishes"""
        self._log(
            ActionType.SESSION_END,
            ActionStatus.SUCCESS,
            resource="langchain.agent",
            details={
                "output_keys": list(finish.return_values.keys())
            }
        )


class ProtectedTool:
    """
    Base class for JannaAuth-protected LangChain tools.
    
    Usage:
        from jannaauth.integrations.langchain import ProtectedTool
        
        class DatabaseTool(ProtectedTool):
            name = "database"
            description = "Query the database"
            required_permissions = ["read:database"]
            
            def _execute(self, query: str) -> str:
                return db.query(query)
    """
    
    name: str = "protected_tool"
    description: str = "A protected tool"
    required_permissions: List[str] = []
    
    def __init__(self, agent: Agent = None):
        """
        Initialize protected tool.
        
        Args:
            agent: JannaAuth Agent (uses session agent if not provided)
        """
        self._explicit_agent = agent
    
    def _get_agent(self) -> Agent:
        """Get the agent for permission checking"""
        if self._explicit_agent:
            return self._explicit_agent
        
        session = session_manager.get_current()
        if not session:
            raise NoActiveSessionError(
                f"Tool '{self.name}' requires active session"
            )
        
        return agent_registry.get(session.agent_id)
    
    def _check_permissions(self):
        """Check if agent has required permissions"""
        agent = self._get_agent()
        
        for perm in self.required_permissions:
            if not agent.can(perm):
                audit_log.log(
                    agent_id=agent.id,
                    agent_name=agent.name,
                    action_type=ActionType.ACTION_DENIED,
                    status=ActionStatus.DENIED,
                    resource=self.name,
                    error=f"Missing permission: {perm}"
                )
                raise PermissionDeniedError(
                    f"Tool '{self.name}' requires permission: {perm}"
                )
    
    def _execute(self, *args, **kwargs) -> str:
        """Override this in subclasses"""
        raise NotImplementedError
    
    def __call__(self, *args, **kwargs) -> str:
        """Execute the tool with permission checking"""
        self._check_permissions()
        
        agent = self._get_agent()
        
        audit_log.log(
            agent_id=agent.id,
            agent_name=agent.name,
            action_type=ActionType.ACTION_EXECUTED,
            status=ActionStatus.SUCCESS,
            resource=self.name,
            details={"args": str(args)[:100]}
        )
        
        return self._execute(*args, **kwargs)


def protected_tool(requires: Union[str, List[str]]):
    """
    Decorator to protect any function as a LangChain tool.
    
    Usage:
        @protected_tool(requires="read:database")
        def search_database(query: str) -> str:
            return db.search(query)
        
        # Or with multiple permissions
        @protected_tool(requires=["read:database", "read:users"])
        def search_users(name: str) -> str:
            return db.search_users(name)
    """
    req_list = [requires] if isinstance(requires, str) else requires
    
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            session = session_manager.get_current()
            
            if not session:
                raise NoActiveSessionError(
                    f"Tool '{func.__name__}' requires active session"
                )
            
            agent = agent_registry.get(session.agent_id)
            
            # Check permissions
            for perm in req_list:
                if not agent.can(perm):
                    audit_log.log(
                        agent_id=agent.id,
                        agent_name=agent.name,
                        action_type=ActionType.ACTION_DENIED,
                        status=ActionStatus.DENIED,
                        resource=func.__name__,
                        error=f"Missing permission: {perm}"
                    )
                    raise PermissionDeniedError(
                        f"Tool '{func.__name__}' requires: {perm}"
                    )
            
            # Execute
            audit_log.log(
                agent_id=agent.id,
                agent_name=agent.name,
                action_type=ActionType.ACTION_EXECUTED,
                status=ActionStatus.SUCCESS,
                resource=func.__name__
            )
            
            return func(*args, **kwargs)
        
        return wrapper
    return decorator


class JannaLangChainAgent:
    """
    Wrapper to create LangChain agents with JannaAuth identity.
    
    Usage:
        from jannaauth.integrations.langchain import JannaLangChainAgent
        
        agent = JannaLangChainAgent(
            name="Analyst",
            permissions=["read:database", "write:reports"],
            llm=ChatAnthropic(),
            tools=[search_tool, write_tool]
        )
        
        with agent.session():
            result = agent.run("Analyze the data")
    """
    
    def __init__(
        self,
        name: str,
        permissions: List[str] = None,
        owner: str = None,
        llm = None,
        tools: List = None,
        agent_type: str = "zero-shot-react-description",
        verbose: bool = False,
        registry: AgentRegistry = None
    ):
        """
        Create a JannaAuth LangChain agent.
        
        Args:
            name: Agent name
            permissions: List of permissions
            owner: Owner email/team
            llm: LangChain LLM
            tools: List of tools
            agent_type: LangChain agent type
            verbose: Verbose output
            registry: AgentRegistry
        """
        if not LANGCHAIN_AVAILABLE:
            raise ImportError("LangChain is not installed")
        
        # Create JannaAuth identity
        self._registry = registry or agent_registry
        self.identity = self._registry.create(
            name=name,
            permissions=permissions or [],
            owner=owner,
            metadata={"framework": "langchain"}
        )
        
        # Create callback
        self._callback = JannaAuthCallback(self.identity)
        
        # Store for lazy initialization
        self._llm = llm
        self._tools = tools or []
        self._agent_type = agent_type
        self._verbose = verbose
        self._agent_executor = None
    
    def _build_agent(self):
        """Build the LangChain agent"""
        if self._agent_executor is None:
            from langchain.agents import initialize_agent
            
            self._agent_executor = initialize_agent(
                tools=self._tools,
                llm=self._llm,
                agent=self._agent_type,
                verbose=self._verbose,
                callbacks=[self._callback]
            )
    
    @property
    def id(self) -> str:
        return self.identity.id
    
    @property
    def name(self) -> str:
        return self.identity.name
    
    def session(self, metadata: Dict = None):
        """Create session context"""
        return self.identity.session(metadata=metadata)
    
    def can(self, permission: str) -> bool:
        """Check permission"""
        return self.identity.can(permission)
    
    def run(self, input_text: str) -> str:
        """Run the agent"""
        self._build_agent()
        return self._agent_executor.run(input_text)
    
    def __call__(self, input_text: str) -> str:
        """Run the agent"""
        return self.run(input_text)
