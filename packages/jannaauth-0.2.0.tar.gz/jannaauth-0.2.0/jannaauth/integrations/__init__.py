"""
JannaAuth Framework Integrations
Support for CrewAI, LangChain, and other multi-agent frameworks
"""

from typing import TYPE_CHECKING

# Lazy imports to avoid requiring all frameworks
def get_crewai():
    """Get CrewAI integration module"""
    from . import crewai
    return crewai

def get_langchain():
    """Get LangChain integration module"""
    from . import langchain
    return langchain

__all__ = [
    'get_crewai',
    'get_langchain'
]
