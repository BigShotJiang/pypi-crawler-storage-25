"""
JannaAuth Secure Handoffs
Secure agent-to-agent data transfer with verification
"""

import hashlib
import json
import time
import secrets
from typing import Dict, Any, Optional, TYPE_CHECKING
from dataclasses import dataclass

from .crypto import ProofGenerator, ProofVerifier, Proof
from .audit import audit_log, ActionType, ActionStatus
from .exceptions import (
    HandoffError,
    InvalidRecipientError,
    HandoffVerificationError
)

if TYPE_CHECKING:
    from .agent import Agent


@dataclass
class Handoff:
    """
    Secure data handoff between agents.
    
    Contains:
    - Data being transferred
    - Sender identification
    - Recipient identification
    - Cryptographic proof
    - Timestamp
    """
    data: Dict[str, Any]
    from_agent_id: str
    to_agent_id: str
    timestamp: int
    nonce: str
    proof: Proof
    metadata: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "data": self.data,
            "from_agent_id": self.from_agent_id,
            "to_agent_id": self.to_agent_id,
            "timestamp": self.timestamp,
            "nonce": self.nonce,
            "proof": self.proof.to_dict(),
            "metadata": self.metadata
        }
    
    def to_json(self) -> str:
        return json.dumps(self.to_dict())
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Handoff':
        return cls(
            data=data["data"],
            from_agent_id=data["from_agent_id"],
            to_agent_id=data["to_agent_id"],
            timestamp=data["timestamp"],
            nonce=data["nonce"],
            proof=Proof.from_dict(data["proof"]),
            metadata=data.get("metadata")
        )
    
    @classmethod
    def from_json(cls, json_str: str) -> 'Handoff':
        return cls.from_dict(json.loads(json_str))
    
    @property
    def age_seconds(self) -> float:
        return time.time() - self.timestamp


class HandoffManager:
    """
    Manages secure agent-to-agent handoffs.
    
    Usage:
        manager = HandoffManager(registry)
        
        # Agent A sends to Agent B
        handoff = manager.create(
            sender=agent_a,
            recipient_id=agent_b.id,
            data={"research": results}
        )
        
        # Agent B receives
        data = manager.receive(
            recipient=agent_b,
            handoff=handoff
        )
    """
    
    def __init__(self, registry=None, verifier: ProofVerifier = None):
        """
        Initialize handoff manager.
        
        Args:
            registry: AgentRegistry for looking up agents
            verifier: ProofVerifier for verification
        """
        self.registry = registry
        self.verifier = verifier or ProofVerifier(registry)
    
    def create(
        self,
        sender: 'Agent',
        recipient_id: str,
        data: Dict[str, Any],
        metadata: Optional[Dict[str, Any]] = None
    ) -> Handoff:
        """
        Create a secure handoff from sender to recipient.
        
        Args:
            sender: Sending agent (must have key pair)
            recipient_id: ID of receiving agent
            data: Data to transfer
            metadata: Optional metadata
            
        Returns:
            Signed Handoff object
        """
        timestamp = int(time.time())
        nonce = secrets.token_hex(8)
        
        # Create challenge from handoff details
        challenge = json.dumps({
            "to": recipient_id,
            "data_hash": hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest(),
            "timestamp": timestamp,
            "nonce": nonce
        }, sort_keys=True)
        
        # Create proof
        proof = sender.create_proof(challenge)
        
        handoff = Handoff(
            data=data,
            from_agent_id=sender.id,
            to_agent_id=recipient_id,
            timestamp=timestamp,
            nonce=nonce,
            proof=proof,
            metadata=metadata
        )
        
        # Log handoff creation
        audit_log.log(
            agent_id=sender.id,
            agent_name=sender.name,
            action_type=ActionType.HANDOFF_SENT,
            status=ActionStatus.SUCCESS,
            details={
                "to_agent": recipient_id,
                "data_keys": list(data.keys()),
                "nonce": nonce
            }
        )
        
        return handoff
    
    def receive(
        self,
        recipient: 'Agent',
        handoff: Handoff,
        max_age_seconds: int = 300
    ) -> Dict[str, Any]:
        """
        Receive and verify a handoff.
        
        Args:
            recipient: Receiving agent
            handoff: Handoff to receive
            max_age_seconds: Maximum age of handoff
            
        Returns:
            The data from the handoff
            
        Raises:
            InvalidRecipientError: If not intended recipient
            HandoffVerificationError: If verification fails
        """
        # 1. Verify intended recipient
        if handoff.to_agent_id != recipient.id:
            audit_log.log(
                agent_id=recipient.id,
                agent_name=recipient.name,
                action_type=ActionType.HANDOFF_REJECTED,
                status=ActionStatus.DENIED,
                error="Not intended recipient",
                details={
                    "intended_for": handoff.to_agent_id,
                    "from_agent": handoff.from_agent_id
                }
            )
            raise InvalidRecipientError(
                f"Handoff intended for {handoff.to_agent_id}, not {recipient.id}"
            )
        
        # 2. Verify age
        if handoff.age_seconds > max_age_seconds:
            audit_log.log(
                agent_id=recipient.id,
                agent_name=recipient.name,
                action_type=ActionType.HANDOFF_REJECTED,
                status=ActionStatus.DENIED,
                error="Handoff expired",
                details={
                    "age_seconds": handoff.age_seconds,
                    "max_age": max_age_seconds
                }
            )
            raise HandoffVerificationError(
                f"Handoff expired: {handoff.age_seconds}s old, max is {max_age_seconds}s"
            )
        
        # 3. Verify sender's proof
        try:
            self.verifier.verify(
                proof=handoff.proof,
                max_age_seconds=max_age_seconds,
                check_registry=True
            )
        except Exception as e:
            audit_log.log(
                agent_id=recipient.id,
                agent_name=recipient.name,
                action_type=ActionType.HANDOFF_REJECTED,
                status=ActionStatus.DENIED,
                error=str(e),
                details={
                    "from_agent": handoff.from_agent_id
                }
            )
            raise HandoffVerificationError(f"Sender verification failed: {e}")
        
        # 4. Log successful receipt
        audit_log.log(
            agent_id=recipient.id,
            agent_name=recipient.name,
            action_type=ActionType.HANDOFF_RECEIVED,
            status=ActionStatus.SUCCESS,
            details={
                "from_agent": handoff.from_agent_id,
                "data_keys": list(handoff.data.keys()),
                "age_seconds": handoff.age_seconds
            }
        )
        
        return handoff.data
    
    def create_and_serialize(
        self,
        sender: 'Agent',
        recipient_id: str,
        data: Dict[str, Any],
        **kwargs
    ) -> str:
        """Create handoff and return as JSON string"""
        handoff = self.create(sender, recipient_id, data, **kwargs)
        return handoff.to_json()
    
    def receive_from_json(
        self,
        recipient: 'Agent',
        handoff_json: str,
        **kwargs
    ) -> Dict[str, Any]:
        """Receive handoff from JSON string"""
        handoff = Handoff.from_json(handoff_json)
        return self.receive(recipient, handoff, **kwargs)


# Convenience functions
def create_handoff(
    sender: 'Agent',
    recipient_id: str,
    data: Dict[str, Any],
    **kwargs
) -> Handoff:
    """Create a handoff without explicit manager"""
    from .agent import agent_registry
    manager = HandoffManager(agent_registry)
    return manager.create(sender, recipient_id, data, **kwargs)


def receive_handoff(
    recipient: 'Agent',
    handoff: Handoff,
    **kwargs
) -> Dict[str, Any]:
    """Receive a handoff without explicit manager"""
    from .agent import agent_registry
    manager = HandoffManager(agent_registry)
    return manager.receive(recipient, handoff, **kwargs)
