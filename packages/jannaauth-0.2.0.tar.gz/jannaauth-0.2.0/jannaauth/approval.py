"""
JannaAuth Human Approval Workflows (v0.3.0)
Human-in-the-loop (HITL) gates for AI agent actions.

Architecture:
    ApprovalRequest  — immutable record of a pending/resolved approval
    ApprovalQueue    — singleton that manages all requests (in-memory + optional SQLite)
    ApprovalGate     — context manager for one-off gating of a code block

Flow:
    1. Agent hits a @protect(requires_approval=True) function
    2. ApprovalQueue.request() creates an ApprovalRequest (status=PENDING)
    3a. If wait=False → ApprovalPendingError is raised immediately.
        Caller catches it, stores request.id, and polls later.
    3b. If wait=True  → blocks with polling until approved/rejected/expired.
    4. Human calls approval_queue.approve(id) or approval_queue.reject(id)
    5. If approved → function executes. If rejected → ApprovalRejectedError.

Usage:
    # One-line setup with persistence
    from jannaauth import approval_queue, AgentStore
    approval_queue.configure(store=AgentStore("jannaauth.db"))

    # Gate a function
    from jannaauth import protect

    @protect(requires="write:database", requires_approval=True)
    def delete_all_records():
        db.execute("DELETE FROM records")

    # Non-blocking (web/async recommended)
    try:
        delete_all_records()
    except ApprovalPendingError as e:
        send_slack_notification(e.request.id)
        # Later, a human hits your API:
        # approval_queue.approve(request_id, approved_by="admin@co.com")
        # approval_queue.reject(request_id, reason="Too risky")

    # Blocking (scripts / CLI tools)
    @protect(requires="write:database", requires_approval=True, wait_for_approval=True)
    def delete_all_records():
        db.execute("DELETE FROM records")

    # Manual gate (no decorator)
    with ApprovalGate(agent, action="purge_logs", details={"days": 90}, wait=True):
        purge_logs(days=90)

Copyright (c) 2025 Janna Labs (IRAVEN GROUP UK)
MIT License
"""

import json
import secrets
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from .audit import audit_log, ActionType, ActionStatus
from .exceptions import (
    ApprovalPendingError,
    ApprovalRejectedError,
    ApprovalExpiredError,
    ApprovalNotFoundError,
)

if TYPE_CHECKING:
    from .agent import Agent
    from .storage import AgentStore


class ApprovalStatus(Enum):
    """Lifecycle states of an approval request."""
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"


@dataclass
class ApprovalRequest:
    """
    A single human approval request.

    Created by ApprovalQueue.request() and resolved via
    ApprovalQueue.approve() or ApprovalQueue.reject().

    Attributes:
        id:               Unique ID — share this with approvers.
        agent_id:         ID of the agent requesting approval.
        agent_name:       Human-readable agent name.
        action:           Name of the action/function requiring approval.
        details:          Contextual information for the approver.
        status:           Current ApprovalStatus.
        created_at:       When the request was created (UTC).
        expires_at:       When the request auto-expires (UTC).
        resolved_at:      When the request was approved/rejected/expired.
        resolved_by:      Who resolved it (email, username, etc.).
        rejection_reason: Free-text reason if rejected.
        session_id:       Agent session that triggered this request.
        metadata:         Arbitrary extra data.
    """
    id: str
    agent_id: str
    agent_name: str
    action: str
    details: Optional[Dict[str, Any]]
    status: ApprovalStatus
    created_at: datetime
    expires_at: datetime
    resolved_at: Optional[datetime] = None
    resolved_by: Optional[str] = None
    rejection_reason: Optional[str] = None
    session_id: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

    # -------------------------
    # Convenience properties
    # -------------------------

    @property
    def is_pending(self) -> bool:
        return self.status == ApprovalStatus.PENDING

    @property
    def is_approved(self) -> bool:
        return self.status == ApprovalStatus.APPROVED

    @property
    def is_rejected(self) -> bool:
        return self.status == ApprovalStatus.REJECTED

    @property
    def is_expired(self) -> bool:
        return self.status == ApprovalStatus.EXPIRED

    @property
    def age_seconds(self) -> float:
        """Seconds since the request was created."""
        return (datetime.utcnow() - self.created_at).total_seconds()

    @property
    def time_remaining(self) -> float:
        """Seconds until natural expiry. Negative if already past."""
        return (self.expires_at - datetime.utcnow()).total_seconds()

    # -------------------------
    # Serialisation
    # -------------------------

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "agent_id": self.agent_id,
            "agent_name": self.agent_name,
            "action": self.action,
            "details": self.details,
            "status": self.status.value,
            "created_at": self.created_at.isoformat() + "Z",
            "expires_at": self.expires_at.isoformat() + "Z",
            "resolved_at": self.resolved_at.isoformat() + "Z" if self.resolved_at else None,
            "resolved_by": self.resolved_by,
            "rejection_reason": self.rejection_reason,
            "session_id": self.session_id,
            "metadata": self.metadata,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ApprovalRequest":
        return cls(
            id=data["id"],
            agent_id=data["agent_id"],
            agent_name=data["agent_name"],
            action=data["action"],
            details=data.get("details"),
            status=ApprovalStatus(data["status"]),
            created_at=datetime.fromisoformat(data["created_at"].rstrip("Z")),
            expires_at=datetime.fromisoformat(data["expires_at"].rstrip("Z")),
            resolved_at=datetime.fromisoformat(data["resolved_at"].rstrip("Z"))
            if data.get("resolved_at")
            else None,
            resolved_by=data.get("resolved_by"),
            rejection_reason=data.get("rejection_reason"),
            session_id=data.get("session_id"),
            metadata=data.get("metadata"),
        )

    def __str__(self) -> str:
        return (
            f"ApprovalRequest(id='{self.id}', agent='{self.agent_name}', "
            f"action='{self.action}', status='{self.status.value}')"
        )


class ApprovalQueue:
    """
    Singleton queue for all human approval requests.

    All agents share one queue. Optionally backed by SQLite via configure().

    Usage:
        from jannaauth import approval_queue

        # Optional persistence (call once at startup)
        approval_queue.configure(store=AgentStore("jannaauth.db"))

        # Approver side
        pending = approval_queue.list_pending()
        approval_queue.approve(pending[0].id, approved_by="admin@co.com")
        approval_queue.reject(pending[0].id, reason="Not safe", rejected_by="cto@co.com")

        # Query
        req = approval_queue.get("approval_abc123")
        all_for_agent = approval_queue.list_all(agent_id="agent_xyz")
    """

    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._requests: Dict[str, ApprovalRequest] = {}
        self._store: Optional["AgentStore"] = None
        self._request_lock = threading.Lock()
        self._initialized = True

    def configure(self, store: "AgentStore"):
        """
        Attach a persistent store and reload any pending approvals from it.

        Call once at startup alongside AgentRegistry.configure().

        Args:
            store: The same AgentStore used by AgentRegistry.
        """
        self._store = store
        for data in store.load_pending_approvals():
            req = ApprovalRequest.from_dict({
                **data,
                "created_at": data["created_at"] if data["created_at"].endswith("Z")
                              else data["created_at"] + "Z",
                "expires_at": data["expires_at"] if data["expires_at"].endswith("Z")
                              else data["expires_at"] + "Z",
            })
            # Mark naturally expired ones immediately
            if req.is_pending and datetime.utcnow() > req.expires_at:
                req.status = ApprovalStatus.EXPIRED
            self._requests[req.id] = req

    # -------------------------
    # Core operations
    # -------------------------

    def request(
        self,
        agent: "Agent",
        action: str,
        details: Optional[Dict[str, Any]] = None,
        timeout_seconds: int = 300,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "ApprovalRequest":
        """
        Create a new approval request for an agent action.

        Args:
            agent:           The agent requesting approval.
            action:          Name of the action/function (shown to approver).
            details:         Context for the approver — what will happen, why, impact.
            timeout_seconds: Seconds before the request auto-expires (default 5 min).
            metadata:        Arbitrary extra data attached to the request.

        Returns:
            ApprovalRequest with status=PENDING.
        """
        from .session import session_manager

        now = datetime.utcnow()
        session = session_manager.get_active(agent.id)

        req = ApprovalRequest(
            id=f"approval_{secrets.token_hex(8)}",
            agent_id=agent.id,
            agent_name=agent.name,
            action=action,
            details=details,
            status=ApprovalStatus.PENDING,
            created_at=now,
            expires_at=now + timedelta(seconds=timeout_seconds),
            session_id=session.session_id if session else None,
            metadata=metadata,
        )

        with self._request_lock:
            self._requests[req.id] = req

        if self._store:
            self._store.save_approval({
                **req.to_dict(),
                "created_at": req.created_at.isoformat(),
                "expires_at": req.expires_at.isoformat(),
            })

        audit_log.log(
            agent_id=agent.id,
            agent_name=agent.name,
            action_type=ActionType.APPROVAL_REQUESTED,
            status=ActionStatus.PENDING,
            resource=action,
            details={
                "approval_id": req.id,
                "timeout_seconds": timeout_seconds,
                "details": details,
            },
            session_id=req.session_id,
        )

        return req

    def approve(
        self,
        approval_id: str,
        approved_by: Optional[str] = None,
    ) -> "ApprovalRequest":
        """
        Approve a pending request.

        Args:
            approval_id:  The ApprovalRequest.id to approve.
            approved_by:  Identity of the approver (email, username, etc.).

        Returns:
            Updated ApprovalRequest with status=APPROVED.

        Raises:
            ApprovalNotFoundError: If the ID does not exist.
            ApprovalError: If the request is not in PENDING state.
        """
        req = self._get_pending(approval_id)
        now = datetime.utcnow()

        req.status = ApprovalStatus.APPROVED
        req.resolved_at = now
        req.resolved_by = approved_by

        if self._store:
            self._store.update_approval_status(
                approval_id, "approved",
                resolved_at=now.isoformat() + "Z",
                resolved_by=approved_by,
            )

        audit_log.log(
            agent_id=req.agent_id,
            agent_name=req.agent_name,
            action_type=ActionType.APPROVAL_GRANTED,
            status=ActionStatus.SUCCESS,
            resource=req.action,
            details={
                "approval_id": approval_id,
                "approved_by": approved_by,
                "wait_time_seconds": round(req.age_seconds, 2),
            },
            session_id=req.session_id,
        )

        return req

    def reject(
        self,
        approval_id: str,
        reason: Optional[str] = None,
        rejected_by: Optional[str] = None,
    ) -> "ApprovalRequest":
        """
        Reject a pending request.

        Args:
            approval_id:  The ApprovalRequest.id to reject.
            reason:       Free-text reason for rejection (shown to agent).
            rejected_by:  Identity of the rejector.

        Returns:
            Updated ApprovalRequest with status=REJECTED.
        """
        req = self._get_pending(approval_id)
        now = datetime.utcnow()

        req.status = ApprovalStatus.REJECTED
        req.resolved_at = now
        req.resolved_by = rejected_by
        req.rejection_reason = reason

        if self._store:
            self._store.update_approval_status(
                approval_id, "rejected",
                resolved_at=now.isoformat() + "Z",
                resolved_by=rejected_by,
                rejection_reason=reason,
            )

        audit_log.log(
            agent_id=req.agent_id,
            agent_name=req.agent_name,
            action_type=ActionType.APPROVAL_REJECTED,
            status=ActionStatus.DENIED,
            resource=req.action,
            details={
                "approval_id": approval_id,
                "rejected_by": rejected_by,
                "reason": reason,
                "wait_time_seconds": round(req.age_seconds, 2),
            },
            session_id=req.session_id,
        )

        return req

    def get(self, approval_id: str) -> "ApprovalRequest":
        """Get an approval request by ID."""
        if approval_id not in self._requests:
            raise ApprovalNotFoundError(f"Approval not found: {approval_id}")
        req = self._requests[approval_id]
        # Auto-expire if past expiry and still pending
        if req.is_pending and datetime.utcnow() > req.expires_at:
            self._expire(req)
        return req

    def list_pending(
        self, agent_id: Optional[str] = None
    ) -> List["ApprovalRequest"]:
        """
        List all currently pending approval requests.

        Args:
            agent_id: Optional filter — only return requests for this agent.

        Returns:
            List of pending ApprovalRequests, oldest first.
        """
        self._expire_stale()
        result = [
            r for r in self._requests.values()
            if r.is_pending and (agent_id is None or r.agent_id == agent_id)
        ]
        return sorted(result, key=lambda r: r.created_at)

    def list_all(
        self,
        agent_id: Optional[str] = None,
        status: Optional[ApprovalStatus] = None,
        limit: int = 100,
    ) -> List["ApprovalRequest"]:
        """
        List all approval requests with optional filters.

        Args:
            agent_id: Filter by agent.
            status:   Filter by ApprovalStatus.
            limit:    Maximum number of results.

        Returns:
            List of ApprovalRequests, most recent first.
        """
        self._expire_stale()
        result = list(self._requests.values())
        if agent_id:
            result = [r for r in result if r.agent_id == agent_id]
        if status:
            result = [r for r in result if r.status == status]
        result.sort(key=lambda r: r.created_at, reverse=True)
        return result[:limit]

    async def wait_for_decision_async(
        self,
        approval_id: str,
        poll_interval: float = 1.0,
        timeout: float = 300.0,
    ) -> "ApprovalRequest":
        """
        Async version of wait_for_decision — use in FastAPI / async workflows.

        Uses asyncio.sleep instead of time.sleep so it doesn't block the
        event loop while waiting for a human decision.

        Usage:
            req = approval_queue.request(agent, "deploy")
            resolved = await approval_queue.wait_for_decision_async(req.id)
        """
        import asyncio

        deadline = asyncio.get_event_loop().time() + timeout

        while True:
            req = self.get(approval_id)

            if req.is_approved:
                return req

            if req.is_rejected:
                raise ApprovalRejectedError(
                    f"Approval '{approval_id}' was rejected"
                    + (f": {req.rejection_reason}" if req.rejection_reason else ""),
                    request=req,
                )

            if req.is_expired:
                raise ApprovalExpiredError(
                    f"Approval '{approval_id}' expired before a decision was made.",
                    request=req,
                )

            if asyncio.get_event_loop().time() >= deadline:
                self._expire(req)
                raise ApprovalExpiredError(
                    f"Timed out waiting for approval '{approval_id}' after {timeout}s.",
                    request=req,
                )

            await asyncio.sleep(poll_interval)

    def wait_for_decision(
        self,
        approval_id: str,
        poll_interval: float = 1.0,
        timeout: float = 300.0,
    ) -> "ApprovalRequest":
        """
        Block until a decision is made on an approval request.

        Polls every poll_interval seconds. Use this in scripts/CLI tools.
        For web apps, handle ApprovalPendingError asynchronously instead.

        Args:
            approval_id:   The request to wait on.
            poll_interval: Seconds between polls (default 1s).
            timeout:       Max seconds to wait before raising ApprovalExpiredError.

        Returns:
            Resolved ApprovalRequest (APPROVED or REJECTED).

        Raises:
            ApprovalExpiredError: If timeout is exceeded or natural expiry hit.
            ApprovalRejectedError: If the request is rejected while waiting.
        """
        deadline = time.time() + timeout

        while True:
            req = self.get(approval_id)

            if req.is_approved:
                return req

            if req.is_rejected:
                raise ApprovalRejectedError(
                    f"Approval '{approval_id}' was rejected"
                    + (f": {req.rejection_reason}" if req.rejection_reason else ""),
                    request=req,
                )

            if req.is_expired:
                raise ApprovalExpiredError(
                    f"Approval '{approval_id}' expired before a decision was made.",
                    request=req,
                )

            if time.time() >= deadline:
                self._expire(req)
                raise ApprovalExpiredError(
                    f"Timed out waiting for approval '{approval_id}' "
                    f"after {timeout}s.",
                    request=req,
                )

            time.sleep(poll_interval)

    # -------------------------
    # Internal helpers
    # -------------------------

    def _get_pending(self, approval_id: str) -> "ApprovalRequest":
        """Fetch a request and validate it is still pending."""
        from .exceptions import ApprovalError
        req = self.get(approval_id)  # also auto-expires if needed
        if not req.is_pending:
            raise ApprovalError(
                f"Approval '{approval_id}' is already {req.status.value}."
            )
        return req

    def _expire(self, req: "ApprovalRequest"):
        """Mark a request as expired."""
        now = datetime.utcnow()
        req.status = ApprovalStatus.EXPIRED
        req.resolved_at = now

        if self._store:
            self._store.update_approval_status(
                req.id, "expired",
                resolved_at=now.isoformat() + "Z",
            )

        audit_log.log(
            agent_id=req.agent_id,
            agent_name=req.agent_name,
            action_type=ActionType.APPROVAL_EXPIRED,
            status=ActionStatus.ERROR,
            resource=req.action,
            details={"approval_id": req.id},
            session_id=req.session_id,
        )

    def _expire_stale(self):
        """Sweep all pending requests and expire any past their expiry time."""
        now = datetime.utcnow()
        for req in list(self._requests.values()):
            if req.is_pending and now > req.expires_at:
                self._expire(req)

    @property
    def pending_count(self) -> int:
        self._expire_stale()
        return sum(1 for r in self._requests.values() if r.is_pending)


class ApprovalGate:
    """
    Context manager that gates a code block behind human approval.

    Prefer the @protect(requires_approval=True) decorator for reusable
    functions. Use ApprovalGate for one-off, imperative code blocks.

    Usage:
        # Non-blocking (raises ApprovalPendingError immediately)
        try:
            with ApprovalGate(agent, "purge_logs", details={"days": 90}):
                purge_logs(90)
        except ApprovalPendingError as e:
            notify_approver(e.request.id)

        # Blocking (waits for a human decision before continuing)
        with ApprovalGate(agent, "deploy_model", wait=True, timeout_seconds=600):
            deploy_model()
    """

    def __init__(
        self,
        agent: "Agent",
        action: str,
        details: Optional[Dict[str, Any]] = None,
        wait: bool = False,
        timeout_seconds: int = 300,
        poll_interval: float = 1.0,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        """
        Args:
            agent:            The agent requesting approval.
            action:           Short name for the action (shown to approver).
            details:          Contextual info for the approver.
            wait:             If True, block until approved/rejected/expired.
                              If False (default), raise ApprovalPendingError immediately.
            timeout_seconds:  How long the request is valid (default 5 min).
            poll_interval:    Polling interval when wait=True (default 1s).
            metadata:         Extra data attached to the request.
        """
        self._agent = agent
        self._action = action
        self._details = details
        self._wait = wait
        self._timeout_seconds = timeout_seconds
        self._poll_interval = poll_interval
        self._metadata = metadata
        self._request: Optional[ApprovalRequest] = None

    def __enter__(self) -> ApprovalRequest:
        self._request = approval_queue.request(
            agent=self._agent,
            action=self._action,
            details=self._details,
            timeout_seconds=self._timeout_seconds,
            metadata=self._metadata,
        )

        if self._wait:
            approval_queue.wait_for_decision(
                self._request.id,
                poll_interval=self._poll_interval,
                timeout=self._timeout_seconds,
            )
        else:
            raise ApprovalPendingError(
                f"Action '{self._action}' is awaiting human approval "
                f"(id: {self._request.id}).",
                request=self._request,
            )

        return self._request

    def __exit__(self, exc_type, exc_val, exc_tb):
        return False  # Never suppress exceptions

    async def __aenter__(self) -> "ApprovalRequest":
        """
        Async context manager entry — use in FastAPI / async workflows.

        Usage:
            async with ApprovalGate(agent, "deploy", wait=True):
                await deploy()
        """
        self._request = approval_queue.request(
            agent=self._agent,
            action=self._action,
            details=self._details,
            timeout_seconds=self._timeout_seconds,
            metadata=self._metadata,
        )

        if self._wait:
            await approval_queue.wait_for_decision_async(
                self._request.id,
                poll_interval=self._poll_interval,
                timeout=self._timeout_seconds,
            )
        else:
            raise ApprovalPendingError(
                f"Action '{self._action}' is awaiting human approval "
                f"(id: {self._request.id}).",
                request=self._request,
            )

        return self._request

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        return False


# Global singleton
approval_queue = ApprovalQueue()
