# JannaAuth SDK v0.2.0

**Identity and Authentication for AI Agents**

[![PyPI version](https://badge.fury.io/py/jannaauth.svg)](https://pypi.org/project/jannaauth/)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

JannaAuth provides cryptographic identity, permissions, and authentication for AI agents. Built for the multi-agent era where knowing *who* did *what* matters.

## The Problem

Modern AI systems are increasingly multi-agent:
- **CrewAI** crews with multiple specialized agents
- **LangChain** chains with tool-using agents
- **AutoGen** conversations between agents

But there's no standard way to:
- ✗ **Identify** which agent performed an action
- ✗ **Verify** that an agent is who it claims to be
- ✗ **Control** what each agent can access
- ✗ **Audit** the complete action trail
- ✗ **Trust** data passed between agents

## The Solution

JannaAuth gives every AI agent a **cryptographic identity**:

```python
from jannaauth import Agent, AgentRegistry

# Create an identified agent
agent = Agent(
    name="DataAnalyst",
    permissions=["read:database", "write:reports"],
    owner="analytics@company.com"
)

# Every action is tracked
with agent.session():
    analyze_data()  # Logged with agent ID

# Cryptographic proof of identity
proof = agent.create_proof("challenge")

# Anyone can verify
registry = AgentRegistry()
verified_agent = registry.verify_proof(proof)
```

## Features

| Feature | Description |
|---------|-------------|
| **🔐 Cryptographic Identity** | Ed25519 key pairs for each agent |
| **📜 Challenge-Response Proofs** | Verify agent identity without shared secrets |
| **🔑 Permissions System** | Granular RBAC with wildcards |
| **📝 Audit Logging** | Complete action trail |
| **🔗 Secure Handoffs** | Verified agent-to-agent data transfer |
| **🤖 CrewAI Integration** | Native support for CrewAI agents |
| **⛓️ LangChain Integration** | Callbacks and protected tools |
| **🎫 JWT-like Tokens** | Stateless authentication |

## Installation

```bash
# Core (zero dependencies)
pip install jannaauth

# With Ed25519 cryptography (recommended)
pip install jannaauth[crypto]

# With CrewAI support
pip install jannaauth[crewai]

# With LangChain support
pip install jannaauth[langchain]

# Everything
pip install jannaauth[all]
```

## Quick Start

### 1. Create an Agent

```python
from jannaauth import Agent

agent = Agent(
    name="Researcher",
    permissions=["read:web", "read:database"],
    owner="research-team@company.com"
)

print(agent.id)          # agent_a1b2c3d4e5f6g7h8
print(agent.public_key_hex)  # Shareable public key
```

### 2. Use Sessions for Tracking

```python
with agent.session():
    # All actions within this block are:
    # - Associated with the agent
    # - Logged to audit trail
    # - Permission-checked
    search_web("AI trends")
    query_database("SELECT * FROM papers")
```

### 3. Check Permissions

```python
# Check before action
if agent.can("write:database"):
    update_database(data)

# Or use decorator
from jannaauth import protect

@protect(requires="write:database")
def update_database(data):
    db.update(data)
```

### 4. Create Cryptographic Proofs

```python
# Agent creates proof
proof = agent.create_proof("random_challenge_string")

# Send proof to verifier (another service, agent, etc.)
proof_json = proof.to_json()

# Verifier checks proof
from jannaauth import ProofVerifier

verifier = ProofVerifier()
is_valid = verifier.verify(proof)  # True if valid
```

### 5. Secure Agent-to-Agent Handoffs

```python
from jannaauth import create_handoff, receive_handoff

# Agent A sends data to Agent B
handoff = create_handoff(
    sender=agent_a,
    recipient_id=agent_b.id,
    data={"research": research_results}
)

# Agent B receives and verifies
data = receive_handoff(
    recipient=agent_b,
    handoff=handoff
)
# Cryptographically verified that Agent A sent this
```

## CrewAI Integration

```python
from jannaauth.integrations.crewai import JannaCrewAgent, JannaCrew

# Create identified agents
researcher = JannaCrewAgent(
    name="Researcher",
    permissions=["read:web", "read:papers"],
    role="Senior Researcher",
    goal="Find accurate information",
    tools=[SearchTool()]
)

writer = JannaCrewAgent(
    name="Writer",
    permissions=["read:research", "write:reports"],
    role="Technical Writer",
    goal="Write clear reports",
    tools=[WriteTool()]
)

# Create tracked crew
crew = JannaCrew(
    agents=[researcher, writer],
    tasks=[research_task, write_task]
)

# Run with full audit trail
result = crew.kickoff()

# Get complete audit trail
trail = crew.get_audit_trail()
```

## LangChain Integration

```python
from jannaauth import Agent
from jannaauth.integrations.langchain import JannaAuthCallback, protected_tool

# Create agent identity
agent = Agent(name="Analyst", permissions=["read:database"])

# Create callback for tracking
callback = JannaAuthCallback(agent)

# Use with any LangChain component
llm = ChatAnthropic(callbacks=[callback])
chain = LLMChain(llm=llm, callbacks=[callback])

# Protected tools
@protected_tool(requires="read:database")
def search_database(query: str) -> str:
    return db.search(query)
```

## Permissions

JannaAuth uses a simple `action:resource` format:

```python
# Basic permissions
agent.can("read:database")      # Read database
agent.can("write:files")        # Write to files
agent.can("call:api.openai")    # Call OpenAI API

# Wildcards
agent.can("read:*")             # Read anything
agent.can("*:database")         # Any action on database
agent.can("*:*")                # Superuser

# Hierarchical
agent.can("read:files.documents")  # Matches "read:files.*"
```

### Permission Decorator

```python
from jannaauth import protect

@protect(requires="read:database")
def query_database():
    return db.query()

@protect(requires=["read:users", "read:profile"])
def get_user_profile():
    return ...

@protect(any_of=["admin:*", "read:sensitive"])
def get_sensitive_data():
    return ...
```

## Audit Logging

Every action is logged:

```python
from jannaauth import audit_log

# Query audit trail
entries = audit_log.query(
    agent_id="agent_xyz",
    action_type=ActionType.ACTION_EXECUTED,
    since=datetime(2024, 1, 1)
)

# Export for compliance
audit_log.export(format="json")
audit_log.export(format="csv")
```

## Agent Registry

Manage multiple agents:

```python
from jannaauth import AgentRegistry

registry = AgentRegistry()

# Create agents
analyst = registry.create(
    name="Analyst",
    permissions=["read:*"],
    owner="analytics@company.com"
)

writer = registry.create(
    name="Writer",
    permissions=["read:analysis", "write:reports"],
    owner="content@company.com"
)

# Verify tokens
agent = registry.verify_token(token)

# Verify proofs
agent = registry.verify_proof(proof)

# Revoke compromised agent
registry.revoke(agent_id, reason="Security breach")
```

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         JannaAuth SDK                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   ┌─────────┐  ┌─────────┐  ┌──────────┐  ┌─────────────────┐ │
│   │  Agent  │  │  Crypto │  │Permission│  │   Integrations  │ │
│   │Identity │  │ Ed25519 │  │  System  │  │ CrewAI/LangChain│ │
│   └────┬────┘  └────┬────┘  └────┬─────┘  └────────┬────────┘ │
│        │            │            │                  │          │
│   ┌────┴────────────┴────────────┴──────────────────┴────┐    │
│   │                    Session Manager                    │    │
│   └────────────────────────────┬─────────────────────────┘    │
│                                │                               │
│   ┌────────────────────────────┴─────────────────────────┐    │
│   │                     Audit Logger                      │    │
│   └───────────────────────────────────────────────────────┘    │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## Why JannaAuth?

| Without JannaAuth | With JannaAuth |
|-------------------|----------------|
| Anonymous agents | Verified identity |
| No access control | Granular permissions |
| No audit trail | Complete logging |
| Trust by assumption | Cryptographic verification |
| One agent compromised = all compromised | Revoke single agent |

## Roadmap

- ✅ **v0.1.0** - Core identity and sessions
- ✅ **v0.2.0** - Cryptographic proofs, permissions, integrations
- 🔜 **v0.3.0** - Human approval workflows
- 🔜 **v0.4.0** - AutoGen integration
- 🔜 **v1.0.0** - JannaAuth Cloud dashboard

## Part of Janna Labs

JannaAuth is part of the **Janna Labs** AI infrastructure platform:

- **Janna SDK** - AI Compliance Intelligence
- **JannaAuth** - Identity & Auth for AI Agents
- **JannaCost** - AI Cost Management (coming soon)
- **JannaTest** - AI Testing Framework (coming soon)

## License

MIT License - Copyright (c) 2025 Janna Labs (IRAVEN GROUP UK)

## Links

- [Documentation](https://jannaauth.iraven.co.uk)
- [GitHub](https://github.com/iraven-group/jannaauth)
- [PyPI](https://pypi.org/project/jannaauth/)
- [Janna Labs](https://janna.iraven.co.uk)
