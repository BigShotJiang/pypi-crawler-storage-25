from __future__ import annotations

import logging
import queue
import sys
import threading
import time
import traceback
from collections.abc import Callable
from contextlib import ExitStack
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from pathlib import Path

from application_pipeline import config as config_module
from application_pipeline import dedup as dedup_module
from application_pipeline import extracts as extracts_module
from application_pipeline import layout as layout_module
from application_pipeline.llm import quota as _quota
from application_pipeline.parser_log import RunLog
from application_pipeline._context import current_stage
from application_pipeline.run_metrics import RunMetrics, RunSummary
from application_pipeline.status_display import PlainStatusDisplay, StatusDisplay
from application_pipeline.config import ConfigError, SourceEntry
from application_pipeline.dedup import (
    DedupStoreError,
    DeduplicationStore,
)
from application_pipeline.failure_report import write_failure as _write_failure
from application_pipeline.layout.types import Layout
from application_pipeline.llm import (
    ClassifyItem,
    ClaudeExtractor,
    ExtractorError,
    JudgeCandidate,
    LLMExtractor,
)
from application_pipeline.llm.claude_cli import ClaudeUsageLimitError
from application_pipeline.llm.types import MatchVerdict, StructuredExtract
from application_pipeline.parsers import (
    ExternalRedirect,
    NotServedQuery,
    Parser,
    ParserQuery,
    Position,
    PositionStub,
)
from application_pipeline.parsers.types import City, Location, Remote
from application_pipeline.parsers import registry as _default_registry
from application_pipeline.parsers.errors import ParserError
from application_pipeline.freshness_gate import FreshnessGate
from application_pipeline.prefilter_gate import PreFilterGate
from application_pipeline.prompts import PromptError, load_prompts
from application_pipeline.search_terms import SearchTerms, load_search_terms
from application_pipeline.renderer import render
from application_pipeline.results import ResultsFileError, append, ensure_initialized

_log = logging.getLogger(__name__)

_STALL_THRESHOLD_S: float = 60.0


# ---------------------------------------------------------------------------
# Run state
# ---------------------------------------------------------------------------


class _RunState:
    """Consolidated run-state object replacing ad-hoc abort/degraded flags."""

    def __init__(self) -> None:
        self.degraded_reason: str | None = None
        self.fatal_exc: BaseException | None = None
        self.degraded_at: datetime | None = None
        self.degraded_by: str | None = None
        self._lock = threading.Lock()

    @property
    def is_degraded(self) -> bool:
        return self.degraded_reason is not None

    @property
    def is_aborted(self) -> bool:
        return self.fatal_exc is not None

    def set_degraded(self, reason: str, by: str) -> None:
        with self._lock:
            if self.degraded_reason is None:
                self.degraded_reason = reason
                self.degraded_at = datetime.now(timezone.utc)
                self.degraded_by = by

    def set_aborted(self, exc: BaseException) -> None:
        with self._lock:
            if self.fatal_exc is None:
                self.fatal_exc = exc


# ---------------------------------------------------------------------------
# Queue protocol sentinels
# ---------------------------------------------------------------------------


class _ParserDone:
    __slots__ = ()


@dataclass
class _ParserDead:
    exc: BaseException
    traceback_str: str


@dataclass
class _EnrichDecision:
    judge_resume: bool


@dataclass
class _EnrichResult:
    stub: PositionStub
    payload: "Position | ParserError | ExternalRedirect"
    judge_resume: bool


class _Skip:
    __slots__ = ()


class _SkipAndEndQuery:
    __slots__ = ()


_PARSER_DONE = _ParserDone()
_SKIP = _Skip()
_SKIP_AND_END_QUERY = _SkipAndEndQuery()


class _QueryDone:
    __slots__ = ()


_QUERY_DONE = _QueryDone()


# ---------------------------------------------------------------------------
# Classify queue protocol
# ---------------------------------------------------------------------------


@dataclass
class _ClassifyPosition:
    position: "Position"


class _NoMoreBatches:
    __slots__ = ()


_NO_MORE_BATCHES = _NoMoreBatches()


# ---------------------------------------------------------------------------
# Pool collector — thread-safe accumulator for judge candidates
# ---------------------------------------------------------------------------


class _PoolCollector:
    """Collects (Position, StructuredExtract) pairs from classify and judge-pending paths."""

    def __init__(self) -> None:
        self._positions: dict[str, "Position"] = {}
        self._extracts: dict[str, "StructuredExtract"] = {}
        self._lock = threading.Lock()

    def add_classified(
        self, position: "Position", extract: "StructuredExtract"
    ) -> None:
        with self._lock:
            self._positions[position.stub.url] = position
            self._extracts[position.stub.url] = extract

    def add_judge_pending(self, position: "Position") -> None:
        with self._lock:
            self._positions[position.stub.url] = position

    def get_position(self, url: str) -> "Position | None":
        with self._lock:
            return self._positions.get(url)

    def build_candidates(
        self, extract_store: "extracts_module.ExtractStore | None"
    ) -> "list[JudgeCandidate]":
        with self._lock:
            positions = dict(self._positions)
            extracts = dict(self._extracts)
        candidates = []
        for url, position in positions.items():
            extract: StructuredExtract | None = extracts.get(url)
            if extract is None and extract_store is not None:
                extract = extract_store.get(url)
            if extract is None:
                continue
            candidates.append(
                JudgeCandidate(
                    id=url,
                    extract=extract,
                    title=position.stub.title,
                    company=position.stub.company,
                    location=position.stub.location,
                )
            )
        return candidates

    @property
    def pool_size(self) -> int:
        with self._lock:
            return len(self._positions)


# ---------------------------------------------------------------------------
# Queue worker base class
# ---------------------------------------------------------------------------


class _QueueWorker(threading.Thread):
    def __init__(
        self,
        *,
        input_queue: queue.Queue[object],
        sentinel: object,
        stage_name: str,
        run_state: "_RunState",
    ) -> None:
        super().__init__(daemon=True)
        self._input_queue = input_queue
        self._sentinel = sentinel
        self._stage_name = stage_name
        self._run_state = run_state
        self.exc: BaseException | None = None

    def run(self) -> None:
        current_stage.set(self._stage_name)
        try:
            while True:
                item = self._input_queue.get()
                if item is self._sentinel:
                    break
                self._on_dequeue(item)
                if not self._run_state.is_degraded:
                    self._process(item)
        except BaseException as exc:
            self.exc = exc
            self._run_state.set_aborted(exc)
        finally:
            self._on_shutdown()

    def _on_dequeue(self, item: object) -> None:
        pass

    def _on_shutdown(self) -> None:
        pass

    def _process(self, item: object) -> None:
        raise NotImplementedError


# ---------------------------------------------------------------------------
# Parser thread — pure producer
# ---------------------------------------------------------------------------


class _ParserThread(threading.Thread):
    def __init__(
        self,
        parser_id: str,
        parser: Parser,
        worklist: list[ParserQuery],
        outbound: queue.Queue[tuple[str, object]],
        inbound: queue.Queue[object],
        *,
        run_log: RunLog,
    ) -> None:
        super().__init__(name=f"parser-{parser_id}", daemon=True)
        self._parser_id = parser_id
        self._parser = parser
        self._worklist = worklist
        self._outbound = outbound
        self._inbound = inbound
        self._run_log = run_log

    def run(self) -> None:
        try:
            for query in self._worklist:
                location_str = (
                    query.location.name
                    if isinstance(query.location, City)
                    else "Remote"
                )
                self._run_log.event(
                    "parser_" + self._parser_id,
                    "query_started",
                    keyword=query.keyword,
                    location=location_str,
                )
                try:
                    gen = iter(self._parser.discover(query))
                    try:
                        for item in gen:
                            self._outbound.put((self._parser_id, item))
                            if isinstance(item, NotServedQuery):
                                continue  # fire-and-forget; orchestrator counts, no reply
                            decision = self._inbound.get()
                            if isinstance(decision, _EnrichDecision):
                                enrich_payload: (
                                    Position | ParserError | ExternalRedirect
                                )
                                try:
                                    enrich_payload = self._parser.enrich(item)
                                except ParserError as exc:
                                    enrich_payload = exc
                                self._outbound.put(
                                    (
                                        self._parser_id,
                                        _EnrichResult(
                                            stub=item,
                                            payload=enrich_payload,
                                            judge_resume=decision.judge_resume,
                                        ),
                                    )
                                )
                            elif decision is _SKIP_AND_END_QUERY:
                                break
                            # else: _SKIP — continue to next stub
                    finally:
                        close = getattr(gen, "close", None)
                        if close is not None:
                            close()
                    self._outbound.put((self._parser_id, _QUERY_DONE))
                finally:
                    self._run_log.event(
                        "parser_" + self._parser_id,
                        "query_ended",
                        keyword=query.keyword,
                        location=location_str,
                    )
        except BaseException as exc:
            self._outbound.put(
                (self._parser_id, _ParserDead(exc, traceback.format_exc()))
            )
        else:
            self._outbound.put((self._parser_id, _PARSER_DONE))


# ---------------------------------------------------------------------------
# Quota sleep helper
# ---------------------------------------------------------------------------


def _quota_sleep(err: ClaudeUsageLimitError, run_log: RunLog) -> None:
    now = datetime.now(timezone.utc)
    wake = _quota.compute_wake_time(err.reset_time, now)
    duration_s = max(0.0, (wake - now).total_seconds())
    run_log.event(
        "pipeline_orchestrator",
        "quota_sleep",
        reset_time=err.reset_time.isoformat() if err.reset_time is not None else None,
        wake_time=wake.isoformat(),
        duration_s=duration_s,
    )
    time.sleep(duration_s)


# ---------------------------------------------------------------------------
# Classify thread
# ---------------------------------------------------------------------------


class _ClassifyThread(_QueueWorker):
    def __init__(
        self,
        *,
        classify_queue: queue.Queue[object],
        pool_collector: "_PoolCollector",
        extractor: LLMExtractor,
        dedup_store: DeduplicationStore,
        metrics: "RunMetrics",
        run_state: _RunState,
        run_log: RunLog,
    ) -> None:
        super().__init__(
            input_queue=classify_queue,
            sentinel=_NO_MORE_BATCHES,
            stage_name="classify",
            run_state=run_state,
        )
        self.name = "classify-worker"
        self._pool_collector = pool_collector
        self._extractor = extractor
        self._dedup_store = dedup_store
        self._metrics = metrics
        self._run_log = run_log

    def _on_dequeue(self, item: object) -> None:
        assert isinstance(item, _ClassifyPosition)
        self._metrics.classify_batch_dequeued(1)

    def _process(self, item: object) -> None:
        assert isinstance(item, _ClassifyPosition)
        position = item.position
        classify_item = ClassifyItem(
            title=position.stub.title,
            raw_description=position.raw_description,
        )
        while True:
            try:
                verdict, classify_usage = self._extractor.classify_relevance(
                    classify_item
                )
                break
            except ClaudeUsageLimitError as err:
                _quota_sleep(err, self._run_log)
            except ExtractorError as exc:
                _log.warning("classify_relevance failed: %s", exc)
                self._metrics.classify_batch_failed(1)
                self._run_log.event(
                    "llm_classify_relevance",
                    "classify_relevance",
                    status="error",
                    error=str(exc),
                )
                return

        self._run_log.event(
            "llm_classify_relevance",
            "classify_relevance",
            in_domain=verdict.in_domain,
        )
        classifier_dropped = 0
        if not verdict.in_domain:
            self._dedup_store.mark_out_of_domain(position.stub)
            classifier_dropped = 1
        else:
            assert verdict.extract is not None
            self._dedup_store.mark_in_domain(position.stub, extract=verdict.extract)
            self._pool_collector.add_classified(position, verdict.extract)
        self._metrics.classify_batch_complete(classify_usage, 1, classifier_dropped)


@dataclass
class _ParserState:
    parser_id: str
    inbound: queue.Queue[object]
    started_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    started_monotonic: float = field(default_factory=time.monotonic)
    last_event_monotonic: float = field(default_factory=time.monotonic)
    stall_logged: bool = False


# ---------------------------------------------------------------------------
# Outbound dispatcher
# ---------------------------------------------------------------------------


class _OutboundDispatcher:
    """Routes payloads from the outbound queue to the appropriate handlers."""

    def __init__(
        self,
        *,
        parser_states: dict[str, "_ParserState"],
        dedup: DeduplicationStore,
        metrics: "RunMetrics",
        classify_queue: "queue.Queue[object]",
        pool_collector: "_PoolCollector",
        run_state: _RunState,
        run_log: RunLog,
        freshness: FreshnessGate,
        prefilter: PreFilterGate,
    ) -> None:
        self._parser_states = parser_states
        self._dedup = dedup
        self._metrics = metrics
        self._classify_queue = classify_queue
        self._pool_collector = pool_collector
        self._run_state = run_state
        self._run_log = run_log
        self._freshness = freshness
        self._prefilter = prefilter

    def dispatch(self, pid: str, payload: object) -> bool:
        """Dispatch a payload to the appropriate handler.

        Returns True if the parser has finished (PARSER_DONE or ParserDead).
        """
        state = self._parser_states[pid]
        if isinstance(payload, PositionStub):
            self._handle_stub(pid, state, payload)
        elif isinstance(payload, _EnrichResult):
            self._handle_enrich_result(pid, payload)
        elif isinstance(payload, NotServedQuery):
            self._handle_not_served(pid)
        elif payload is _QUERY_DONE:
            self._handle_query_done(pid)
        elif payload is _PARSER_DONE:
            self._handle_parser_done(pid)
            return True
        elif isinstance(payload, _ParserDead):
            self._handle_parser_dead(pid, payload)
            return True
        return False

    def flush_residual(self) -> None:
        """Signal end of positions to the classify worker."""
        self._classify_queue.put(_NO_MORE_BATCHES)

    def _enqueue_classify(self, position: Position) -> None:
        self._classify_queue.put(_ClassifyPosition(position=position))
        self._metrics.classify_buffered(1)

    def _handle_stub(
        self, pid: str, state: _ParserState, payload: PositionStub
    ) -> None:
        self._metrics.discovered(pid)
        if self._run_state.is_aborted:
            state.inbound.put(_SKIP_AND_END_QUERY)
            return
        result = self._dedup.is_seen(payload)
        self._metrics.record_dedup(result)
        if result == "miss":
            state.inbound.put(_EnrichDecision(judge_resume=False))
        elif result == "judge_pending":
            state.inbound.put(_EnrichDecision(judge_resume=True))
        else:
            state.inbound.put(_SKIP)

    def _handle_enrich_result(self, pid: str, wrapper: _EnrichResult) -> None:
        stub = wrapper.stub
        payload = wrapper.payload
        if isinstance(payload, Position):
            for warning in payload._warnings:
                self._run_log.event("parser_" + pid, warning)
                if warning.startswith("unparseable_date"):
                    self._metrics.unparseable_date(pid)
            self._metrics.enriched(pid)
            if wrapper.judge_resume:
                if self._freshness.admit(payload):
                    self._pool_collector.add_judge_pending(payload)
                else:
                    return
            else:
                if self._prefilter.admit(payload):
                    if self._freshness.admit(payload):
                        self._enqueue_classify(payload)
        elif isinstance(payload, ParserError):
            self._run_log.event(
                "parser_" + pid,
                "enrich_failed",
                stub_url=stub.url,
                title=stub.title,
                reason=str(payload),
            )
            self._dedup.mark_enrich_failed(stub)
            self._metrics.enrich_failed(pid)
        elif isinstance(payload, ExternalRedirect):
            self._run_log.event(
                "parser_" + pid,
                "external_redirect",
                stub_url=stub.url,
                outbound=payload.outbound_url,
                skipped=True,
            )
            self._dedup.mark_external_redirect(stub)
            self._metrics.external_redirect(pid)

    def _handle_not_served(self, pid: str) -> None:
        self._metrics.not_served_query(pid)

    def _handle_query_done(self, pid: str) -> None:
        self._metrics.query_done(pid)

    def _handle_parser_done(self, pid: str) -> None:
        self._metrics.parser_done(pid)

    def _handle_parser_dead(self, pid: str, payload: _ParserDead) -> None:
        self._run_log.traceback("parser_" + pid, payload.traceback_str)
        self._metrics.parser_dead(pid)


def run(
    config_path: Path,
    *,
    search_terms: SearchTerms | None = None,
    extractor: LLMExtractor | None = None,
    parser_registry: Callable[[str], type[Parser] | None] | None = None,
    dedup_store: DeduplicationStore | None = None,
    layout: Layout | None = None,
    status_display: StatusDisplay | None = None,
    run_log: RunLog | None = None,
    stall_threshold_s: float = _STALL_THRESHOLD_S,
) -> RunSummary:
    anchored_today: date = datetime.now(timezone.utc).date()
    cron_anchored_date = anchored_today.isoformat()

    if status_display is None:
        status_display = PlainStatusDisplay(run_log=run_log)

    run_state = _RunState()
    _start = time.monotonic()
    status_display.register("pipeline", order=0, phase="running")
    status_display.register("startup", order=1, phase="running")
    try:
        # Step 1: Load config
        try:
            cfg = config_module.load(config_path)
        except ConfigError as exc:
            _log.error("startup failed — config: %s", exc)
            raise

        if run_log is None:
            run_log = RunLog(cfg.logs_path)

        # Steps 2-3: Load prompts, build extractor
        if extractor is None:
            try:
                prompts = load_prompts(cfg)
            except PromptError as exc:
                _log.error("startup failed — prompts: %s", exc)
                raise
            if search_terms is None:
                search_terms = load_search_terms(cfg.user_info_dir)
            extractor = ClaudeExtractor(
                cfg, prompts, search_terms=search_terms, run_log=run_log
            )
        elif search_terms is None:
            search_terms = load_search_terms(cfg.user_info_dir)

        # Step 6: Resolve parser classes; unknown types are skipped (registry logs WARNING)
        _resolve = (
            parser_registry if parser_registry is not None else _default_registry.get
        )
        resolved: list[tuple[type[Parser], SourceEntry]] = []
        for source in cfg.sources:
            cls = _resolve(source.parser_type)
            if cls is not None:
                resolved.append((cls, source))

        # Step 7: Dedup store (wire ExtractStore for judge_pending extract retrieval)
        extract_store = extracts_module.load(
            cfg.seen_store_path.parent / "extracts.json"
        )
        if dedup_store is None:
            try:
                dedup_store = dedup_module.load(
                    cfg.seen_store_path, extract_store=extract_store
                )
            except DedupStoreError as exc:
                _log.error("startup failed — dedup store: %s", exc)
                raise

        # Step 8: Layout + daily results file initialization
        if layout is None:
            if cfg.layout is not None:
                layout = layout_module.load(cfg.layout)
            else:
                layout = layout_module.default()

        daily_file_path = cfg.results_dir / f"{cron_anchored_date}.md"
        try:
            ensure_initialized(daily_file_path)
        except ResultsFileError as exc:
            _log.error("startup failed — results file: %s", exc)
            raise

        # Step 9: Enter parsers via ExitStack, start parser threads, consume outbound queue
        metrics = RunMetrics(status_display, run_log=run_log)
        classify_queue: queue.Queue[object] = queue.Queue()
        pool_collector = _PoolCollector()
        _run_started_at = datetime.now(timezone.utc)

        locations: list[Location] = [City(loc) for loc in cfg.locations]
        if cfg.include_remote:
            locations.append(Remote())

        outbound: queue.Queue[tuple[str, object]] = queue.Queue()

        with ExitStack() as stack:
            parsers_list: list[tuple[Parser, SourceEntry]] = [
                (stack.enter_context(cls(run_log=run_log)), source)  # type: ignore[call-arg]
                for cls, source in resolved
            ]
            dedup_run = stack.enter_context(dedup_store.run_scope())

            parser_states: dict[str, _ParserState] = {}
            threads: list[tuple[str, _ParserThread]] = []

            for parser, source in parsers_list:
                parser_id = source.parser_type
                inbound: queue.Queue[object] = queue.Queue()
                worklist = [
                    ParserQuery(
                        keyword=kw, location=loc, max_results=source.max_results
                    )
                    for kw in search_terms.keywords
                    for loc in locations
                ]
                parser_states[parser_id] = _ParserState(
                    parser_id=parser_id,
                    inbound=inbound,
                )
                t = _ParserThread(
                    parser_id, parser, worklist, outbound, inbound, run_log=run_log
                )
                threads.append((parser_id, t))

            for i, (pid, t) in enumerate(threads):
                t.start()
                state = parser_states[pid]
                state.started_at = datetime.now(timezone.utc)
                state.started_monotonic = time.monotonic()
                state.last_event_monotonic = state.started_monotonic
                _log.info("parser %s started", pid)
                run_log.event("parser_" + pid, "parser started")
                metrics.register_parser(
                    pid,
                    order=2 + i,
                    total_queries=len(t._worklist),
                )

            status_display.remove("startup")

            metrics.register_rows(starting_order=2 + len(threads))

            classify_thread = _ClassifyThread(
                classify_queue=classify_queue,
                pool_collector=pool_collector,
                extractor=extractor,
                dedup_store=dedup_store,
                metrics=metrics,
                run_state=run_state,
                run_log=run_log,
            )
            classify_thread.start()

            freshness = FreshnessGate(
                anchored_today=anchored_today,
                max_listing_age_days=cfg.max_listing_age_days,
                dedup=dedup_run,
                metrics=metrics,
                run_log=run_log,
            )
            prefilter = PreFilterGate(
                blacklist=list(search_terms.negative_keywords),
                dedup=dedup_run,
                metrics=metrics,
                run_log=run_log,
            )

            dispatcher = _OutboundDispatcher(
                parser_states=parser_states,
                dedup=dedup_run,
                metrics=metrics,
                classify_queue=classify_queue,
                pool_collector=pool_collector,
                run_state=run_state,
                run_log=run_log,
                freshness=freshness,
                prefilter=prefilter,
            )

            parsers_remaining: set[str] = set(parser_states.keys())

            poll_s = min(stall_threshold_s, 5.0)
            while parsers_remaining:
                try:
                    pid, payload = outbound.get(timeout=poll_s)
                except queue.Empty:
                    if run_state.is_aborted:
                        continue
                    now = time.monotonic()
                    frames = sys._current_frames()
                    threads_by_name = {t.name: t for t in threading.enumerate()}
                    for stall_pid in parsers_remaining:
                        stall_state = parser_states[stall_pid]
                        age = now - stall_state.last_event_monotonic
                        if age < stall_threshold_s or stall_state.stall_logged:
                            continue
                        run_log.event(
                            "parser_" + stall_pid,
                            "stalled",
                            last_event_age_s=round(age, 1),
                        )
                        thread = threads_by_name.get(f"parser-{stall_pid}")
                        frame = (
                            frames.get(thread.ident)
                            if thread is not None and thread.ident is not None
                            else None
                        )
                        if frame is not None:
                            run_log.traceback(
                                "parser_" + stall_pid,
                                "".join(traceback.format_stack(frame)),
                            )
                        stall_state.stall_logged = True
                    continue
                current_stage.set(f"parser:{pid}")
                state = parser_states[pid]
                state.last_event_monotonic = time.monotonic()
                state.stall_logged = False

                if dispatcher.dispatch(pid, payload):
                    parsers_remaining.discard(pid)

            for _, t in threads:
                t.join()

            parsers_done_monotonic = time.monotonic()
            for pid, pstate in parser_states.items():
                run_log.summary(
                    "parser_" + pid,
                    metrics.parser_summary(
                        pid, parsers_done_monotonic, pstate.started_monotonic
                    ),
                    pstate.started_at,
                )

            freshness.emit_run_complete()
            prefilter.emit_run_complete()
            dispatcher.flush_residual()

        classify_thread.join()

        if classify_thread.exc is not None:
            raise classify_thread.exc

        # Emit per-call-site SUMMARY OF SESSION trailers
        metrics.summarize_to_parser_log(_run_started_at)

        # Step 13: Single end-of-run judge_top_n call
        candidates = pool_collector.build_candidates(extract_store)
        pool_size = pool_collector.pool_size

        daily_top_5_count = 0
        if candidates:
            verdicts: list[MatchVerdict] | None = None
            judge_usage = None
            while True:
                try:
                    verdicts, judge_usage = extractor.judge_top_n(candidates)
                    break
                except ClaudeUsageLimitError as err:
                    _quota_sleep(err, run_log)
                except ExtractorError as exc:
                    _log.warning("judge_top_n failed: %s", exc)
                    run_log.event(
                        "llm_judge_top_n",
                        "error",
                        returncode=getattr(exc, "returncode", None),
                        stderr_excerpt=str(getattr(exc, "stderr", "") or "")[:200],
                        error=str(exc),
                    )
                    _write_failure(
                        stage="judge_top_n",
                        error=exc,
                        log_tail="",
                        failures_dir=cfg.failures_path,
                    )
                    break

            if verdicts is not None and judge_usage is not None:
                for verdict in sorted(verdicts, key=lambda v: v.rank):
                    position = pool_collector.get_position(verdict.id)
                    if position is None:
                        continue
                    rendered = render(position, verdict, layout)
                    try:
                        append(daily_file_path, rendered)
                    except ResultsFileError as exc:
                        _log.error("daily file append failed: %s", exc)
                        raise
                    dedup_store.mark_selected_by_judge(position.stub)
                    daily_top_5_count += 1
                metrics.judge_top_n_complete(judge_usage, daily_top_5_count)
                run_log.event(
                    "pipeline_orchestrator",
                    "daily_file_written",
                    path=str(daily_file_path),
                    card_count=daily_top_5_count,
                )

        elapsed_s = time.monotonic() - _start
        if run_state.degraded_reason is not None:
            metrics.set_degraded_reason(run_state.degraded_reason)

        run_log.event(
            "pipeline_orchestrator",
            "run_complete",
            classify_calls=metrics.classify_calls,
            classify_input_tokens=metrics.classify_input_tokens,
            classify_output_tokens=metrics.classify_output_tokens,
            judge_input_tokens=metrics.judge_input_tokens,
            judge_output_tokens=metrics.judge_output_tokens,
            dedup_url_hits=metrics.dedup_url_hits,
            dedup_tuple_hits=metrics.dedup_tuple_hits,
            dedup_run_hits=metrics.dedup_run_hits,
            dedup_misses=metrics.dedup_misses,
            pool_size=pool_size,
            daily_top_5_count=daily_top_5_count,
            elapsed_s=round(elapsed_s, 1),
        )

        summary = metrics.to_run_summary(duration_s=elapsed_s)
        _log.info(
            "run complete: discovered=%d skipped=%d "
            "prefilter_considered=%d prefilter_passed=%d prefilter_dropped=%d "
            "prefilter_blacklist_hits=%d "
            "dedup_url_hits=%d dedup_tuple_hits=%d dedup_run_hits=%d dedup_misses=%d "
            "classifier_dropped=%d written=%d "
            "enrich_failed=%d external_redirects=%d errored=%d parsers_dead=%d",
            summary.discovered,
            summary.skipped,
            summary.prefilter_considered,
            summary.prefilter_passed,
            summary.prefilter_dropped,
            summary.prefilter_blacklist_hits,
            summary.dedup_url_hits,
            summary.dedup_tuple_hits,
            summary.dedup_run_hits,
            summary.dedup_misses,
            summary.classifier_dropped,
            summary.written,
            summary.enrich_failed,
            summary.external_redirects,
            summary.errored,
            summary.parsers_dead,
        )
        return summary
    finally:
        status_display.stop()
