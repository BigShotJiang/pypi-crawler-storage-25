"""Agent Insurance MCP Server — Escrow und Versicherung fuer Agent-Transaktionen."""

__version__ = "0.1.0"
