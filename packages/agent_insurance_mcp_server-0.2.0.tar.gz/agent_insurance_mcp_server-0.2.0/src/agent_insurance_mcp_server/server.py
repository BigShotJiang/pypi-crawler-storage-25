"""Agent Insurance MCP Server — Haupteinstiegspunkt."""

import sys
from mcp.server.fastmcp import FastMCP
from . import store as insurance_store

# FastMCP-Server initialisieren
mcp = FastMCP(
    "agent-insurance-mcp-server",
    instructions=(
        "MCP server for AI agent transaction insurance and escrow. "
        "Protects agent-to-agent payments with smart escrow, risk scoring, "
        "automated dispute resolution, and claim processing. "
        "Use create_escrow to lock funds, release_escrow when task is done, "
        "open_dispute for conflicts, get_insurance_quote before transacting, "
        "get_agent_history for trust evaluation, and insurance_analytics for system health."
    ),
)


@mcp.tool()
def create_escrow(
    buyer_agent_id: str,
    seller_agent_id: str,
    amount: float,
    task_description: str,
    deadline_hours: int = 24,
) -> dict:
    """Erstellt einen neuen Escrow fuer eine Agent-Transaktion.

    Sperrt den angegebenen Betrag sicher zwischen Buyer und Seller Agent.
    Der Betrag wird erst freigegeben, wenn die Aufgabe abgeschlossen ist
    oder ein Streitfall geloest wurde. Risikobasierte Praemie wird berechnet.

    Args:
        buyer_agent_id: ID des zahlenden Agents (z.B. 'agent_weather_v2')
        seller_agent_id: ID des leistungserbringenden Agents (z.B. 'agent_code_gen')
        amount: Betrag der abzusichernden Transaktion (z.B. 50.0)
        task_description: Beschreibung der zu erbringenden Leistung
        deadline_hours: Frist in Stunden bis zur automatischen Aufloesung (1-720, Standard: 24)
    """
    return insurance_store.create_escrow(
        buyer_agent_id=buyer_agent_id,
        seller_agent_id=seller_agent_id,
        amount=amount,
        task_description=task_description,
        deadline_hours=deadline_hours,
    )


@mcp.tool()
def release_escrow(escrow_id: str, outcome: str, quality_score: int = 8) -> dict:
    """Gibt den Escrow frei und zahlt den Seller aus.

    Beendet einen aktiven Escrow nach Abschluss der Aufgabe.
    Bei 'success' erhaelt der Seller den vollen Betrag.
    Bei 'partial' wird anteilig nach quality_score ausgezahlt.

    Args:
        escrow_id: ID des freizugebenden Escrows (z.B. 'escrow_abc123def456')
        outcome: Ergebnis der Transaktion ('success' oder 'partial')
        quality_score: Qualitaet der Leistung von 1-10 (nur bei 'partial' relevant, Standard: 8)
    """
    return insurance_store.release_escrow(
        escrow_id=escrow_id,
        outcome=outcome,
        quality_score=quality_score,
    )


@mcp.tool()
def open_dispute(escrow_id: str, reason: str, evidence: str = "") -> dict:
    """Eroeffnet einen Streitfall fuer einen Escrow.

    Startet einen automatischen Bewertungsprozess und setzt den Escrow
    auf 'disputed'. Die automatische Erstbewertung basiert auf
    Schluesselwoertern in der Begruendung.

    Args:
        escrow_id: ID des bestrittenen Escrows
        reason: Begruendung fuer den Streitfall (z.B. 'Task not delivered as agreed')
        evidence: Optionale Beweise oder Details (z.B. API-Responses, Logs)
    """
    return insurance_store.open_dispute(
        escrow_id=escrow_id,
        reason=reason,
        evidence=evidence,
    )


@mcp.tool()
def get_insurance_quote(
    buyer_agent_id: str,
    seller_agent_id: str,
    amount: float,
    task_type: str = "general",
) -> dict:
    """Erstellt eine Versicherungsquote vor einer Agent-Transaktion.

    Berechnet den Risiko-Score und die Praemie fuer eine geplante Transaktion.
    Empfohlen vor jeder create_escrow-Anfrage um die Kosten zu kennen.

    Args:
        buyer_agent_id: ID des Buyers
        seller_agent_id: ID des Sellers
        amount: Geplanter Transaktionsbetrag
        task_type: Art der Aufgabe ('general', 'code', 'data', 'content', 'analysis')
    """
    return insurance_store.get_insurance_quote(
        buyer_agent_id=buyer_agent_id,
        seller_agent_id=seller_agent_id,
        amount=amount,
        task_type=task_type,
    )


@mcp.tool()
def process_claim(dispute_id: str, resolution: str, buyer_pct: int = 50) -> dict:
    """Verarbeitet einen Schadensfall und schliesst den Streitfall.

    Loest einen offenen Dispute auf und verteilt den Escrow-Betrag
    gemaess der Entscheidung. Benoetigt manuelle Eingabe nach
    Pruefung der Beweise.

    Args:
        dispute_id: ID des zu loesenden Streitfalls
        resolution: Entscheidung ('buyer_wins', 'seller_wins', 'split')
        buyer_pct: Prozentsatz fuer den Buyer bei 'split'-Entscheidung (0-100, Standard: 50)
    """
    return insurance_store.process_claim(
        dispute_id=dispute_id,
        resolution=resolution,
        buyer_pct=buyer_pct,
    )


@mcp.tool()
def get_escrow_status(escrow_id: str) -> dict:
    """Gibt den aktuellen Status und alle Details eines Escrows zurueck.

    Zeigt Betrag, Parteien, Frist, Risiko-Score und alle Auszahlungsdetails.
    Erkennt abgelaufene Escrows automatisch.

    Args:
        escrow_id: ID des Escrows (z.B. 'escrow_abc123def456')
    """
    return insurance_store.get_escrow_status(escrow_id=escrow_id)


@mcp.tool()
def list_escrows(
    status: str = "",
    agent_id: str = "",
    limit: int = 20,
) -> dict:
    """List and filter all escrows in the system.

    Browse all escrow transactions with optional filters.
    Shows escrow ID, status, parties, amount, and risk score.
    Expired escrows are automatically detected.

    Args:
        status: Filter by status ('active', 'released', 'disputed', 'expired', 'claim_resolved').
            Empty string returns all escrows.
        agent_id: Filter by agent ID (matches buyer OR seller). Empty = all agents.
        limit: Maximum results to return (1-100, default: 20)
    """
    return insurance_store.list_escrows(
        status=status,
        agent_id=agent_id,
        limit=limit,
    )


@mcp.tool()
def get_agent_history(agent_id: str) -> dict:
    """Get full transaction history and trust metrics for an agent.

    Shows all escrows (as buyer and seller), dispute rate, completion rate,
    average quality score, and a computed trust score (0-100).
    Useful for evaluating agent reliability before transacting.

    Args:
        agent_id: ID of the agent to check (e.g. 'agent_weather_v2')
    """
    return insurance_store.get_agent_history(agent_id=agent_id)


@mcp.tool()
def auto_resolve_expired() -> dict:
    """Automatically resolve all expired escrows.

    Escrows past their deadline are resolved in favor of the buyer
    (full refund), since the seller failed to deliver on time.
    Run this periodically to keep the system clean.
    """
    return insurance_store.auto_resolve_expired()


@mcp.tool()
def insurance_analytics() -> dict:
    """Get detailed analytics about the insurance system.

    Shows volume trends, top agents by volume, risk distribution,
    dispute rates, quality scores, and status breakdown.
    Useful for monitoring system health and agent economy trends.
    """
    return insurance_store.insurance_analytics()


@mcp.tool()
def get_insurance_info() -> dict:
    """Gibt Systeminformationen und Statistiken ueber das Insurance-System zurueck.

    Zeigt Gesamtanzahl der Escrows, aktive Disputes, geschuetzte Betraege
    und verfuegbare Tools. Nuetzlich fuer einen Ueberblick ueber das System.
    """
    return insurance_store.get_insurance_info()


def main():
    """Server-Startpunkt fuer den CLI-Befehl."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
