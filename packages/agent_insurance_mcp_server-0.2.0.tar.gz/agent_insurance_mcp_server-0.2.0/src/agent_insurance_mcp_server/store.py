"""Persistente Datenspeicherung fuer Escrow-Eintraege und Versicherungsquoten."""

import json
import uuid
import time
from pathlib import Path
from typing import Any

# Lokaler Datenspeicher (wie bei agent-staking-mcp-server)
STORE_PATH = Path.home() / ".agent_insurance_store.json"


def _load_store() -> dict:
    """Laedt den Datenspeicher aus der JSON-Datei."""
    if not STORE_PATH.exists():
        return {"escrows": {}, "claims": {}, "stats": {"total_protected": 0, "total_released": 0, "total_disputed": 0}}
    try:
        with open(STORE_PATH) as f:
            return json.load(f)
    except Exception:
        return {"escrows": {}, "claims": {}, "stats": {"total_protected": 0, "total_released": 0, "total_disputed": 0}}


def _save_store(data: dict) -> None:
    """Speichert den Datenspeicher in die JSON-Datei."""
    with open(STORE_PATH, "w") as f:
        json.dump(data, f, indent=2)


def create_escrow(
    buyer_agent_id: str,
    seller_agent_id: str,
    amount: float,
    task_description: str,
    deadline_hours: int = 24,
) -> dict[str, Any]:
    """Erstellt einen neuen Escrow fuer eine Agent-Transaktion.

    Args:
        buyer_agent_id: ID des zahlenden Agents
        seller_agent_id: ID des leistungserbringenden Agents
        amount: Betrag der abzusichernden Transaktion
        task_description: Beschreibung der zu erbringenden Leistung
        deadline_hours: Frist in Stunden (Standard: 24)

    Returns:
        Escrow-Eintrag mit ID, Status und Details
    """
    if amount <= 0:
        return {"error": "Betrag muss groesser als 0 sein"}
    if deadline_hours <= 0 or deadline_hours > 720:
        return {"error": "Frist muss zwischen 1 und 720 Stunden liegen"}

    store = _load_store()

    # Risikobasierte Praemie berechnen (1-5% des Betrags)
    risk_score = _calculate_risk(buyer_agent_id, seller_agent_id, amount, store)
    premium_rate = 0.01 + (risk_score / 100) * 0.04  # 1-5%
    premium = round(amount * premium_rate, 4)

    escrow_id = f"escrow_{uuid.uuid4().hex[:12]}"
    now = time.time()
    deadline = now + (deadline_hours * 3600)

    escrow = {
        "escrow_id": escrow_id,
        "buyer_agent_id": buyer_agent_id,
        "seller_agent_id": seller_agent_id,
        "amount": amount,
        "premium": premium,
        "premium_rate_pct": round(premium_rate * 100, 2),
        "task_description": task_description,
        "status": "active",
        "risk_score": risk_score,
        "created_at": now,
        "deadline": deadline,
        "deadline_hours": deadline_hours,
        "released_at": None,
        "dispute_reason": None,
    }

    store["escrows"][escrow_id] = escrow
    store["stats"]["total_protected"] = store["stats"].get("total_protected", 0) + amount
    _save_store(store)

    return {
        "escrow_id": escrow_id,
        "status": "active",
        "amount_protected": amount,
        "premium_charged": premium,
        "premium_rate_pct": round(premium_rate * 100, 2),
        "risk_score": risk_score,
        "deadline_hours": deadline_hours,
        "message": f"Escrow erstellt. {amount} Einheiten gesichert. Praemie: {premium} ({round(premium_rate * 100, 2)}%).",
    }


def release_escrow(escrow_id: str, outcome: str, quality_score: int = 8) -> dict[str, Any]:
    """Gibt den Escrow frei und zahlt den Seller aus.

    Args:
        escrow_id: ID des Escrows
        outcome: Ergebnis ('success' oder 'partial')
        quality_score: Qualitaet der Leistung (1-10, Standard: 8)

    Returns:
        Release-Ergebnis mit Auszahlungsdetails
    """
    store = _load_store()

    if escrow_id not in store["escrows"]:
        return {"error": f"Escrow {escrow_id} nicht gefunden"}

    escrow = store["escrows"][escrow_id]

    if escrow["status"] != "active":
        return {"error": f"Escrow ist nicht aktiv (Status: {escrow['status']})"}

    # Auszahlung basierend auf Outcome
    if outcome == "success":
        payout = escrow["amount"]
        buyer_refund = 0.0
    elif outcome == "partial":
        payout = round(escrow["amount"] * (quality_score / 10), 4)
        buyer_refund = round(escrow["amount"] - payout, 4)
    else:
        return {"error": "outcome muss 'success' oder 'partial' sein"}

    escrow["status"] = "released"
    escrow["released_at"] = time.time()
    escrow["outcome"] = outcome
    escrow["quality_score"] = quality_score
    escrow["seller_payout"] = payout
    escrow["buyer_refund"] = buyer_refund

    store["escrows"][escrow_id] = escrow
    store["stats"]["total_released"] = store["stats"].get("total_released", 0) + payout
    _save_store(store)

    return {
        "escrow_id": escrow_id,
        "status": "released",
        "seller_payout": payout,
        "buyer_refund": buyer_refund,
        "quality_score": quality_score,
        "message": f"Escrow freigegeben. Seller erhaelt {payout}, Buyer bekommt {buyer_refund} zurueck.",
    }


def open_dispute(escrow_id: str, reason: str, evidence: str = "") -> dict[str, Any]:
    """Eroeffnet einen Streitfall fuer einen Escrow.

    Args:
        escrow_id: ID des Escrows
        reason: Grund des Streitfalls
        evidence: Beweise (optional)

    Returns:
        Dispute-Status mit automatischer Erstbewertung
    """
    store = _load_store()

    if escrow_id not in store["escrows"]:
        return {"error": f"Escrow {escrow_id} nicht gefunden"}

    escrow = store["escrows"][escrow_id]

    if escrow["status"] not in ("active", "released"):
        return {"error": f"Dispute kann nur fuer aktive/freigegebene Escrows geoeffnet werden (Status: {escrow['status']})"}

    dispute_id = f"dispute_{uuid.uuid4().hex[:10]}"

    # Automatische Erstbewertung
    auto_verdict = _auto_verdict(reason, escrow)

    dispute = {
        "dispute_id": dispute_id,
        "escrow_id": escrow_id,
        "reason": reason,
        "evidence": evidence,
        "status": "under_review",
        "created_at": time.time(),
        "auto_verdict": auto_verdict,
        "buyer_protection": auto_verdict["buyer_protection"],
        "seller_protection": auto_verdict["seller_protection"],
    }

    escrow["status"] = "disputed"
    escrow["dispute_reason"] = reason
    escrow["dispute_id"] = dispute_id

    store["escrows"][escrow_id] = escrow
    store["claims"][dispute_id] = dispute
    store["stats"]["total_disputed"] = store["stats"].get("total_disputed", 0) + 1
    _save_store(store)

    return {
        "dispute_id": dispute_id,
        "escrow_id": escrow_id,
        "status": "under_review",
        "auto_verdict": auto_verdict["verdict"],
        "buyer_protection_pct": auto_verdict["buyer_protection"],
        "seller_protection_pct": auto_verdict["seller_protection"],
        "estimated_resolution_hours": 24,
        "message": f"Streitfall {dispute_id} erstellt. Automatische Erstbewertung: {auto_verdict['verdict']}",
    }


def get_insurance_quote(
    buyer_agent_id: str,
    seller_agent_id: str,
    amount: float,
    task_type: str = "general",
) -> dict[str, Any]:
    """Erstellt eine Versicherungsquote fuer eine Agent-Transaktion.

    Args:
        buyer_agent_id: ID des Buyers
        seller_agent_id: ID des Sellers
        amount: Transaktionsbetrag
        task_type: Art der Aufgabe (general/code/data/content/analysis)

    Returns:
        Versicherungsquote mit Risikoanalyse
    """
    if amount <= 0:
        return {"error": "Betrag muss groesser als 0 sein"}

    store = _load_store()
    risk_score = _calculate_risk(buyer_agent_id, seller_agent_id, amount, store)

    # Aufgaben-basiertes Risiko
    task_multipliers = {
        "code": 1.2,
        "data": 1.1,
        "content": 0.9,
        "analysis": 1.0,
        "general": 1.0,
    }
    task_mult = task_multipliers.get(task_type, 1.0)

    adjusted_risk = min(100, risk_score * task_mult)
    base_premium_rate = 0.01 + (adjusted_risk / 100) * 0.04

    # Rabatt fuer kleine Transaktionen
    if amount < 10:
        discount = 0.1
    elif amount < 100:
        discount = 0.05
    else:
        discount = 0.0

    final_rate = base_premium_rate * (1 - discount)
    premium = round(amount * final_rate, 4)

    return {
        "quote": {
            "amount": amount,
            "task_type": task_type,
            "risk_score": round(adjusted_risk, 1),
            "premium_rate_pct": round(final_rate * 100, 2),
            "premium": premium,
            "discount_applied_pct": round(discount * 100, 1),
            "coverage": "100% bei Nichtlieferung, anteilig bei Teillieferung",
            "valid_for_hours": 1,
        },
        "risk_breakdown": {
            "base_risk": risk_score,
            "task_type_factor": task_mult,
            "adjusted_risk": round(adjusted_risk, 1),
        },
        "recommendation": "low" if adjusted_risk < 30 else ("medium" if adjusted_risk < 70 else "high"),
    }


def process_claim(dispute_id: str, resolution: str, buyer_pct: int) -> dict[str, Any]:
    """Verarbeitet einen Schadensfall und loest ihn auf.

    Args:
        dispute_id: ID des Streitfalls
        resolution: Aufloesung ('buyer_wins', 'seller_wins', 'split')
        buyer_pct: Prozentsatz fuer den Buyer bei split (0-100)

    Returns:
        Claim-Ergebnis mit Auszahlungsdetails
    """
    store = _load_store()

    if dispute_id not in store["claims"]:
        return {"error": f"Streitfall {dispute_id} nicht gefunden"}

    dispute = store["claims"][dispute_id]
    escrow_id = dispute["escrow_id"]
    escrow = store["escrows"].get(escrow_id, {})

    amount = escrow.get("amount", 0)

    if resolution == "buyer_wins":
        buyer_gets = amount
        seller_gets = 0.0
    elif resolution == "seller_wins":
        buyer_gets = 0.0
        seller_gets = amount
    elif resolution == "split":
        if not 0 <= buyer_pct <= 100:
            return {"error": "buyer_pct muss zwischen 0 und 100 liegen"}
        buyer_gets = round(amount * (buyer_pct / 100), 4)
        seller_gets = round(amount - buyer_gets, 4)
    else:
        return {"error": "resolution muss 'buyer_wins', 'seller_wins' oder 'split' sein"}

    dispute["status"] = "resolved"
    dispute["resolution"] = resolution
    dispute["buyer_gets"] = buyer_gets
    dispute["seller_gets"] = seller_gets
    dispute["resolved_at"] = time.time()

    if escrow:
        escrow["status"] = "claim_resolved"
        store["escrows"][escrow_id] = escrow

    store["claims"][dispute_id] = dispute
    _save_store(store)

    return {
        "dispute_id": dispute_id,
        "resolution": resolution,
        "buyer_gets": buyer_gets,
        "seller_gets": seller_gets,
        "status": "resolved",
        "message": f"Streitfall {dispute_id} geloest. Buyer erhaelt {buyer_gets}, Seller erhaelt {seller_gets}.",
    }


def get_escrow_status(escrow_id: str) -> dict[str, Any]:
    """Gibt den aktuellen Status eines Escrows zurueck.

    Args:
        escrow_id: ID des Escrows

    Returns:
        Aktueller Escrow-Status mit allen Details
    """
    store = _load_store()

    if escrow_id not in store["escrows"]:
        return {"error": f"Escrow {escrow_id} nicht gefunden"}

    escrow = store["escrows"][escrow_id]
    now = time.time()

    # Ablaufstatus pruefen
    is_expired = escrow["status"] == "active" and now > escrow["deadline"]
    time_remaining = max(0, escrow["deadline"] - now)

    return {
        "escrow_id": escrow_id,
        "status": "expired" if is_expired else escrow["status"],
        "buyer_agent_id": escrow["buyer_agent_id"],
        "seller_agent_id": escrow["seller_agent_id"],
        "amount": escrow["amount"],
        "premium": escrow["premium"],
        "task_description": escrow["task_description"],
        "risk_score": escrow["risk_score"],
        "time_remaining_hours": round(time_remaining / 3600, 1),
        "is_expired": is_expired,
        "outcome": escrow.get("outcome"),
        "seller_payout": escrow.get("seller_payout"),
        "buyer_refund": escrow.get("buyer_refund"),
        "dispute_id": escrow.get("dispute_id"),
    }


def get_insurance_info() -> dict[str, Any]:
    """Gibt Informationen ueber das Agent Insurance System zurueck.

    Returns:
        System-Statistiken und Beschreibung
    """
    store = _load_store()

    escrows = store.get("escrows", {})
    claims = store.get("claims", {})
    stats = store.get("stats", {})

    # Aktive Escrows zaehlen
    active_count = sum(1 for e in escrows.values() if e["status"] == "active")
    resolved_count = sum(1 for e in escrows.values() if e["status"] in ("released", "claim_resolved"))

    # Durchschnittliche Praemienrate
    if escrows:
        avg_premium = sum(e.get("premium_rate_pct", 2.5) for e in escrows.values()) / len(escrows)
    else:
        avg_premium = 2.5

    return {
        "system": "Agent Insurance & Escrow MCP Server",
        "version": "0.1.0",
        "description": "Sichert Agent-zu-Agent-Transaktionen mit Smart Escrow und automatischer Streitbeilegung",
        "stats": {
            "total_escrows": len(escrows),
            "active_escrows": active_count,
            "resolved_escrows": resolved_count,
            "total_disputes": len(claims),
            "total_protected_amount": round(stats.get("total_protected", 0), 2),
            "total_released_amount": round(stats.get("total_released", 0), 2),
            "avg_premium_rate_pct": round(avg_premium, 2),
        },
        "coverage": {
            "full_coverage": "Nichtlieferung, Betrug, Ausfall",
            "partial_coverage": "Unvollstaendige Lieferung (anteilig)",
            "dispute_resolution": "Automatische Erstbewertung + manuelle Eskalation",
        },
        "premium_range": "1-5% des Transaktionsbetrags (risikobasiert)",
        "tools": [
            "create_escrow", "release_escrow", "open_dispute",
            "get_insurance_quote", "process_claim", "get_escrow_status", "get_insurance_info",
        ],
    }


def list_escrows(
    status: str = "",
    agent_id: str = "",
    limit: int = 20,
) -> dict[str, Any]:
    """Listet alle Escrows mit optionalen Filtern auf.

    Args:
        status: Filter nach Status (active/released/disputed/expired/claim_resolved). Leer = alle.
        agent_id: Filter nach Agent-ID (Buyer oder Seller).
        limit: Max. Ergebnisse (Standard: 20, Max: 100).

    Returns:
        Liste der Escrows mit Zusammenfassung
    """
    store = _load_store()
    escrows = list(store.get("escrows", {}).values())
    now = time.time()

    # Status-Filter (inkl. expired-Erkennung)
    if status:
        filtered = []
        for e in escrows:
            effective_status = e["status"]
            if effective_status == "active" and now > e.get("deadline", now + 1):
                effective_status = "expired"
            if effective_status == status:
                filtered.append(e)
        escrows = filtered

    # Agent-Filter
    if agent_id:
        escrows = [
            e for e in escrows
            if e["buyer_agent_id"] == agent_id or e["seller_agent_id"] == agent_id
        ]

    # Sortieren nach Erstelldatum (neueste zuerst)
    escrows.sort(key=lambda e: e.get("created_at", 0), reverse=True)
    total = len(escrows)
    escrows = escrows[:min(limit, 100)]

    items = []
    for e in escrows:
        effective_status = e["status"]
        if effective_status == "active" and now > e.get("deadline", now + 1):
            effective_status = "expired"
        items.append({
            "escrow_id": e["escrow_id"],
            "status": effective_status,
            "buyer": e["buyer_agent_id"],
            "seller": e["seller_agent_id"],
            "amount": e["amount"],
            "task": e["task_description"][:80],
            "risk_score": e["risk_score"],
        })

    return {
        "total": total,
        "shown": len(items),
        "filters": {"status": status or "all", "agent_id": agent_id or "all"},
        "escrows": items,
    }


def get_agent_history(agent_id: str) -> dict[str, Any]:
    """Gibt die komplette Transaktionshistorie eines Agents zurueck.

    Zeigt alle Escrows (als Buyer und Seller), Dispute-Rate, Zuverlaessigkeit
    und durchschnittlichen Risiko-Score. Nuetzlich fuer Vertrauensbewertung.

    Args:
        agent_id: ID des Agents

    Returns:
        Transaktionshistorie mit Vertrauens-Metriken
    """
    store = _load_store()
    escrows = store.get("escrows", {})
    now = time.time()

    as_buyer = []
    as_seller = []

    for e in escrows.values():
        if e["buyer_agent_id"] == agent_id:
            as_buyer.append(e)
        if e["seller_agent_id"] == agent_id:
            as_seller.append(e)

    total = len(as_buyer) + len(as_seller)
    if total == 0:
        return {
            "agent_id": agent_id,
            "message": "Keine Transaktionshistorie vorhanden",
            "trust_score": 0,
            "total_transactions": 0,
        }

    # Seller-Metriken
    seller_completed = sum(1 for e in as_seller if e["status"] == "released")
    seller_disputed = sum(1 for e in as_seller if e["status"] in ("disputed", "claim_resolved"))
    seller_total = len(as_seller)
    dispute_rate = round(seller_disputed / seller_total * 100, 1) if seller_total > 0 else 0.0
    completion_rate = round(seller_completed / seller_total * 100, 1) if seller_total > 0 else 0.0

    # Buyer-Metriken
    buyer_volume = sum(e["amount"] for e in as_buyer)
    seller_volume = sum(e["amount"] for e in as_seller)

    # Qualitaets-Schnitt
    quality_scores = [e.get("quality_score", 0) for e in as_seller if e.get("quality_score")]
    avg_quality = round(sum(quality_scores) / len(quality_scores), 1) if quality_scores else 0.0

    # Vertrauens-Score berechnen (0-100)
    trust = 50  # Basis
    trust += min(20, total * 2)  # Erfahrung (max +20)
    trust += int(completion_rate * 0.2)  # Abschlussrate (max +20)
    trust -= int(dispute_rate * 0.3)  # Dispute-Abzug
    if avg_quality > 0:
        trust += int((avg_quality - 5) * 2)  # Qualitaet (+/- 10)
    trust = max(0, min(100, trust))

    return {
        "agent_id": agent_id,
        "trust_score": trust,
        "total_transactions": total,
        "as_buyer": {
            "count": len(as_buyer),
            "total_volume": round(buyer_volume, 2),
        },
        "as_seller": {
            "count": seller_total,
            "completed": seller_completed,
            "disputed": seller_disputed,
            "completion_rate_pct": completion_rate,
            "dispute_rate_pct": dispute_rate,
            "avg_quality_score": avg_quality,
            "total_volume": round(seller_volume, 2),
        },
        "recommendation": (
            "highly_trusted" if trust >= 80
            else "trusted" if trust >= 60
            else "neutral" if trust >= 40
            else "caution" if trust >= 20
            else "high_risk"
        ),
    }


def auto_resolve_expired() -> dict[str, Any]:
    """Loest alle abgelaufenen Escrows automatisch auf.

    Escrows die ihre Deadline ueberschritten haben werden automatisch
    zugunsten des Buyers aufgeloest (Geld zurueck), da der Seller
    nicht rechtzeitig geliefert hat.

    Returns:
        Anzahl der aufgeloesten Escrows und Details
    """
    store = _load_store()
    now = time.time()
    resolved = []

    for escrow_id, escrow in store["escrows"].items():
        if escrow["status"] == "active" and now > escrow.get("deadline", now + 1):
            escrow["status"] = "expired_auto_resolved"
            escrow["released_at"] = now
            escrow["outcome"] = "expired"
            escrow["seller_payout"] = 0.0
            escrow["buyer_refund"] = escrow["amount"]
            resolved.append({
                "escrow_id": escrow_id,
                "amount_refunded": escrow["amount"],
                "buyer": escrow["buyer_agent_id"],
                "seller": escrow["seller_agent_id"],
            })

    if resolved:
        _save_store(store)

    return {
        "resolved_count": len(resolved),
        "total_refunded": round(sum(r["amount_refunded"] for r in resolved), 2),
        "resolved_escrows": resolved,
        "message": f"{len(resolved)} abgelaufene Escrows automatisch aufgeloest",
    }


def insurance_analytics() -> dict[str, Any]:
    """Gibt detaillierte Analytics ueber das Insurance-System zurueck.

    Zeigt Volumen-Trends, Top-Agents, Risiko-Verteilung und
    Dispute-Statistiken. Nuetzlich fuer System-Monitoring.

    Returns:
        Detaillierte System-Analytics
    """
    store = _load_store()
    escrows = list(store.get("escrows", {}).values())
    claims = list(store.get("claims", {}).values())

    if not escrows:
        return {
            "message": "Noch keine Transaktionsdaten vorhanden",
            "total_escrows": 0,
        }

    # Status-Verteilung
    status_counts: dict[str, int] = {}
    for e in escrows:
        s = e.get("status", "unknown")
        status_counts[s] = status_counts.get(s, 0) + 1

    # Gesamtvolumen
    total_volume = sum(e["amount"] for e in escrows)
    total_premiums = sum(e.get("premium", 0) for e in escrows)

    # Risiko-Verteilung
    risk_low = sum(1 for e in escrows if e.get("risk_score", 50) < 30)
    risk_medium = sum(1 for e in escrows if 30 <= e.get("risk_score", 50) < 70)
    risk_high = sum(1 for e in escrows if e.get("risk_score", 50) >= 70)

    # Top Agents (nach Volumen)
    agent_volumes: dict[str, float] = {}
    for e in escrows:
        buyer = e["buyer_agent_id"]
        seller = e["seller_agent_id"]
        agent_volumes[buyer] = agent_volumes.get(buyer, 0) + e["amount"]
        agent_volumes[seller] = agent_volumes.get(seller, 0) + e["amount"]

    top_agents = sorted(agent_volumes.items(), key=lambda x: x[1], reverse=True)[:10]

    # Dispute-Rate
    dispute_count = sum(1 for e in escrows if e.get("status") in ("disputed", "claim_resolved"))
    dispute_rate = round(dispute_count / len(escrows) * 100, 1) if escrows else 0.0

    # Durchschnittliche Qualitaet
    quality_scores = [e.get("quality_score", 0) for e in escrows if e.get("quality_score")]
    avg_quality = round(sum(quality_scores) / len(quality_scores), 1) if quality_scores else 0.0

    return {
        "total_escrows": len(escrows),
        "total_volume": round(total_volume, 2),
        "total_premiums_collected": round(total_premiums, 2),
        "status_distribution": status_counts,
        "risk_distribution": {
            "low_risk": risk_low,
            "medium_risk": risk_medium,
            "high_risk": risk_high,
        },
        "dispute_rate_pct": dispute_rate,
        "avg_quality_score": avg_quality,
        "top_agents_by_volume": [{"agent": a, "volume": round(v, 2)} for a, v in top_agents],
        "total_disputes": len(claims),
        "resolved_disputes": sum(1 for c in claims if c.get("status") == "resolved"),
    }


# --- Interne Hilfsfunktionen ---

def _calculate_risk(buyer_id: str, seller_id: str, amount: float, store: dict) -> int:
    """Berechnet einen Risiko-Score (0-100) fuer eine Transaktion."""
    risk = 30  # Basis-Risiko

    escrows = store.get("escrows", {})

    # Seller-Historie pruefen
    seller_escrows = [e for e in escrows.values() if e["seller_agent_id"] == seller_id]
    if seller_escrows:
        disputed = sum(1 for e in seller_escrows if e["status"] in ("disputed", "claim_resolved"))
        dispute_rate = disputed / len(seller_escrows)
        risk += int(dispute_rate * 40)  # Bis zu 40 Punkte fuer Streithistorie
        risk -= min(20, len(seller_escrows) * 2)  # Abzug fuer Erfahrung

    # Betragsbezogenes Risiko
    if amount > 1000:
        risk += 15
    elif amount > 100:
        risk += 5

    return max(5, min(95, risk))


def _auto_verdict(reason: str, escrow: dict) -> dict:
    """Erstellt eine automatische Erstbewertung fuer einen Streitfall."""
    reason_lower = reason.lower()

    # Schluesselwoerter fuer Buyer-Schutz
    buyer_keywords = ["not delivered", "fraud", "scam", "missing", "keine lieferung", "betrug", "not completed"]
    seller_keywords = ["partial", "completed", "delivered", "done", "teilweise", "fertig"]

    buyer_score = sum(1 for kw in buyer_keywords if kw in reason_lower)
    seller_score = sum(1 for kw in seller_keywords if kw in reason_lower)

    if buyer_score > seller_score:
        return {"verdict": "buyer_favored", "buyer_protection": 80, "seller_protection": 20}
    elif seller_score > buyer_score:
        return {"verdict": "seller_favored", "buyer_protection": 20, "seller_protection": 80}
    else:
        return {"verdict": "neutral_split", "buyer_protection": 50, "seller_protection": 50}
