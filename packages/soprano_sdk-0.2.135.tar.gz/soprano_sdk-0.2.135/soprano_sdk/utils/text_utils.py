from typing import Any, Set, List, Optional
import re
import json

from .parser import convert_to_dict

def filter_metadata(value: Any, metadata_fields: Set[str]) -> Any:
    """Removes internal framework metadata fields from a dictionary value.
    
    Args:
        value: The value to filter.
        metadata_fields: A set of keys to exclude if value is a dict.
        
    Returns:
        Filtered dict if value was a dict, otherwise original value.
    """
    if isinstance(value, dict):
        return {k: v for k, v in value.items() if k not in metadata_fields}
    return value


def normalize_text(text: str) -> str:
    """Normalize user message for comparison with previous messages.
    """
    if not text:
        return ""
    text = text.lower().strip()
    # Remove common punctuation
    text = re.sub(r"[^\w\s]", "", text)
    # Collapse multiple spaces
    text = re.sub(r"\s+", " ", text)
    return text

def format_field_name(name: str) -> str:
    """Formats an underscore-separated field name into a proper human-readable format.
    Example: 'user_id' -> 'User Id' or 'NAME' -> 'Name'
    """
    if not name:
        return ""
    # Simplify: replace underscores, handle uppercase, and title-case
    parts = name.replace("_", " ").split()
    return " ".join(p.capitalize() for p in parts)


def extract_conversational_text(content: str) -> str:
    """Extract and standardize human-readable text from assistant message content.
    
    Handles:
    1. Standard JSON-formatted assistant messages (structured output) - extracts text & options.
    2. Standard technical markers (passed through or normalized).
    3. Legacy patterns (INTENT_CHANGE:, OUT_OF_SCOPE:) - transformed to markers.
    4. Plain text messages.
    """
    if not content:
        return ""
    
    content = content.strip()

    # Extract from JSON (Structured Output mode)
    try:
        parsed = convert_to_dict(content)
        if isinstance(parsed, dict):
            # Prioritize intent/scope signals
            if parsed.get('intent_change'):
                return f"(signaled intent change): {parsed['intent_change']}"
            if parsed.get('out_of_scope'):
                return f"(signaled out of scope): {parsed['out_of_scope']}"
            if parsed.get('restart'):
                return "(signaled restart)"

            # Extract main text
            text = str(parsed.get('bot_response') or parsed.get('text') or parsed.get('message') or '').strip()
            
            # Extract collected fields if any (keys that are not metadata)
            metadata_keys = {'bot_response', 'text', 'message', 'options', 'intent_change', 'out_of_scope', 'restart', 'reason', 'timestamp', 'is_selectable', 'reasoning'}
            filtered = filter_metadata(parsed, metadata_keys)
            collected_data = []
            for k, v in filtered.items():
                if v is not None and str(v).strip():
                    formatted_k = format_field_name(k)
                    collected_data.append(f"(collected {formatted_k}): {v}")
            
            if collected_data:
                collection_marker = " ".join(collected_data)
                text = f"{collection_marker} {text}".strip() if text else collection_marker

            # Append options if available (for history context)
            options = parsed.get('options')
            if options and isinstance(options, list):
                opt_texts = [str(opt.get('text')) for opt in options if isinstance(opt, dict) and opt.get('text')]
                if opt_texts:
                    text += f"\nOptions: {', '.join(opt_texts)}"
            
            return text
    except (json.JSONDecodeError, TypeError):
        pass

    
    # Intent Change: INTENT_CHANGE: <target>
    if "INTENT_CHANGE:" in content:
        parts = content.split("INTENT_CHANGE:", 1)
        return f"(signaled intent change): {parts[1].strip()}"
    
    # Out of Scope: OUT_OF_SCOPE: <reason>
    if "OUT_OF_SCOPE:" in content:
        parts = content.split("OUT_OF_SCOPE:", 1)
        return f"(signaled out of scope): {parts[1].strip()}"
    

    return content




def extract_pattern_match(content: str, patterns: List[str], field_name: str) -> Optional[str]:
    """Extract captured value from assistant response content based on step patterns.
    
    Used in conversation history summaries to identify internal pattern-match extractions.
    Format: (collected Field Name): Value (Pattern Name) OR (signaled transition): Pattern Name
    """
    for pattern in patterns:
        if pattern in content:
            # Clean the pattern name for display (e.g. "NAME_CAPTURED:" -> "Name Captured")
            display_pattern = pattern.strip(" :._-").replace('_', ' ').title()
            
            clean_value = content.split(pattern)[1].strip()
            if clean_value:
                formatted_field = format_field_name(field_name)
                return f"(collected {formatted_field}): {clean_value} ({display_pattern})"
            else:
                return f"(signaled transition): {display_pattern}"
    return None
