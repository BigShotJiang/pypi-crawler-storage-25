
from typing import Any, Dict, Type, Union, get_origin, get_args
from ..utils.logger import logger
from ..utils.tracing import tracer
import json
import ast
import re

from pydantic import BaseModel


def _get_field_type_for_key(schema: Type[BaseModel] | None, key: str) -> type | None:
    """Return the resolved type annotation for a given field name, or None."""
    if schema is None:
        return None

    field_info = schema.model_fields.get(key)
    if field_info is None:
        return None

    annotation = field_info.annotation

    # Unwrap Optional[X] / Union[X, None] to get X
    origin = get_origin(annotation)
    if origin is Union:
        args = [a for a in get_args(annotation) if a is not type(None)]
        if len(args) == 1:
            return args[0]

    return annotation


def _expects_string(schema: Type[BaseModel] | None, key: str) -> bool:
    """Check if the schema expects a str for the given key."""
    field_type = _get_field_type_for_key(schema, key)
    if field_type is None:
        return False
    return field_type is str


def _repair_json_string(s: str, schema: Type[BaseModel] | None = None) -> str:
    """Attempt to fix common malformed JSON from LLM output.

    Handles the case where the LLM produces unquoted string values, e.g.:
        {"reasoning": A reason, "bot_response": "Bot Response"}

    If a Pydantic *schema* is provided, field type information guides the
    repair.  For example, a bare ``true`` for a field typed as ``str`` will
    be wrapped in quotes rather than left as a JSON boolean.

    Strategy: walk through each ``"key":`` value position and, if the value
    token is not a recognised JSON literal (string, number, object, array,
    true/false/null), wrap it in double quotes up to the next comma or
    closing brace/bracket.
    """
    # Match a JSON key followed by a colon and optional whitespace.
    # Captures the key name (group 1) for schema lookups.
    pattern = re.compile(
        r'"((?:[^"\\]|\\.)*)"\s*:\s*'
    )

    parts = list(pattern.finditer(s))
    result = list(s)  # mutable char list

    _KEYWORDS = ('true', 'false', 'null')
    _DELIMITERS = {',', '}', ']', ' ', '\t', '\n', '\r'}

    for match in reversed(parts):
        key_name = match.group(1)
        value_start = match.end()

        # Skip whitespace after colon
        idx = value_start
        while idx < len(result) and result[idx] in (' ', '\t', '\n', '\r'):
            idx += 1

        if idx >= len(result):
            continue

        first_char = result[idx]

        # Already a quoted string — skip
        if first_char == '"':
            continue

        # Object or array — skip
        if first_char in ('{', '['):
            continue

        # Numeric literal — skip (unless schema expects a string)
        if first_char in '-0123456789':
            if _expects_string(schema, key_name):
                end_idx = idx
                while end_idx < len(result) and result[end_idx] not in (',', '}', ']'):
                    end_idx += 1
                val_end = end_idx
                while val_end > idx and result[val_end - 1] in (' ', '\t', '\n', '\r'):
                    val_end -= 1
                if val_end > idx:
                    raw_value = ''.join(result[idx:val_end])
                    replacement = list(f'"{raw_value}"')
                    result[idx:val_end] = replacement
            continue

        # Keyword literals: true / false / null
        if first_char in ('t', 'f', 'n'):
            rest = ''.join(result[idx:idx + 6])
            matched_kw = None
            for kw in _KEYWORDS:
                if rest.startswith(kw):
                    after = idx + len(kw)
                    if after >= len(result) or result[after] in _DELIMITERS:
                        matched_kw = kw
                        break

            if matched_kw is not None:
                # Schema says this field should be a string?
                # Then quote the keyword so it becomes "true" / "false" / "null".
                if _expects_string(schema, key_name):
                    kw_len = len(matched_kw)
                    replacement = list(f'"{matched_kw}"')
                    result[idx:idx + kw_len] = replacement
                continue

        # Unquoted string value — find where it ends
        end_idx = idx
        while end_idx < len(result) and result[end_idx] not in (',', '}', ']'):
            end_idx += 1

        # Trim trailing whitespace
        val_end = end_idx
        while val_end > idx and result[val_end - 1] in (' ', '\t', '\n', '\r'):
            val_end -= 1

        if val_end > idx:
            raw_value = ''.join(result[idx:val_end])
            escaped = raw_value.replace('\\', '\\\\').replace('"', '\\"')
            replacement = list(f'"{escaped}"')
            result[idx:val_end] = replacement

    return ''.join(result)


def convert_to_dict(response: Any, schema: Type[BaseModel] | None = None) -> Dict[str, Any] | str:
    """
    Convert response to dict using 4 strategies:
    1. Check if already a dict
    2. Try json.loads()
    3. Try ast.literal_eval()
    4. Try schema-aware JSON repair and json.loads() again
    """
    with tracer.start_as_current_span("parser.convert_to_dict") as span:
        has_schema = schema is not None
        if span.is_recording():
            span.set_attribute("parser.has_schema", has_schema)
            if has_schema:
                span.set_attribute("parser.schema_name", schema.__name__)

        # Strategy 1: Already a dict
        if isinstance(response, dict):
            logger.info("Response is already a dict")
            if span.is_recording():
                span.set_attribute("parser.strategy", "already_dict")
            return response

        # Convert to string for parsing
        response_str_raw = str(response)
        response_str = response_str_raw[response_str_raw.find("{"): response_str_raw.rfind("}")+1]

        if span.is_recording():
            span.set_attribute("parser.input_length", len(response_str))

        # Strategy 2: Try json.loads()
        try:
            parsed = json.loads(response_str)
            logger.info("Successfully parsed with json.loads()")
            if span.is_recording():
                span.set_attribute("parser.strategy", "json_loads")
            return parsed
        except (json.JSONDecodeError, ValueError, TypeError) as e:
            logger.error(f"json.loads() failed: {e}")

        # Strategy 3: Try ast.literal_eval() (handles Python dict syntax: single quotes, None, True/False)
        try:
            parsed = ast.literal_eval(response_str)
            if isinstance(parsed, dict):
                logger.info("Successfully parsed with ast.literal_eval()")
                if span.is_recording():
                    span.set_attribute("parser.strategy", "ast_literal_eval")
                return parsed
        except (ValueError, SyntaxError, TypeError) as e:
            logger.error(f"ast.literal_eval() failed: {e}")

        # Strategy 4: Try schema-aware repair of common LLM JSON mistakes (e.g. unquoted string values), then json.loads()
        if has_schema:
            try:
                repaired = _repair_json_string(response_str, schema=schema)
                parsed = json.loads(repaired)
                logger.info("Successfully parsed with repaired JSON")
                if span.is_recording():
                    span.set_attribute("parser.strategy", "json_repair")
                    span.set_attribute("parser.repaired", True)
                return parsed
            except (json.JSONDecodeError, ValueError, TypeError) as e:
                logger.error(f"Repaired json.loads() failed: {e}")
        else:
            logger.warning("JSON repair skipped: no schema provided for schema-aware repair")

        # All parsing failed - return as string
        logger.error("All parsing strategies failed, returning raw response")
        if span.is_recording():
            span.set_attribute("parser.strategy", "failed")
            span.set_attribute("parser.input", response_str)
        return response_str
