from __future__ import annotations

import json
from datetime import datetime, timezone

from .paths import logs_dir


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def append_bridge_log(payload: dict[str, object]) -> None:
    log_path = logs_dir() / "bridge.log"
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(payload, sort_keys=True) + "\n")
    except OSError:
        return
