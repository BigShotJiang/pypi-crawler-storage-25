from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path

from .errors import LockConflictError

try:
    import fcntl
except ImportError:  # pragma: no cover
    fcntl = None


@contextmanager
def acquire_thread_lock(lock_path: Path):
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    handle = lock_path.open("a+", encoding="utf-8")
    try:
        if fcntl is None:
            raise LockConflictError("Locking unsupported on this platform.")
        try:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise LockConflictError("Lock already held.") from exc
        yield lock_path
    finally:
        if fcntl is not None:
            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
            except OSError:
                pass
        handle.close()
