from __future__ import annotations

import os
from pathlib import Path

from .errors import InvalidArgsError


def bridge_root() -> Path:
    override = os.environ.get("CODEX2OPENCODE_HOME")
    if override:
        return Path(override).expanduser()
    return Path.home() / ".codex" / "codex2opencode"


def threads_dir() -> Path:
    return bridge_root() / "threads"


def runs_dir() -> Path:
    return bridge_root() / "runs"


def logs_dir() -> Path:
    return bridge_root() / "logs"


def _validate_thread_key(thread_key: str) -> None:
    if not thread_key or thread_key.strip() == "":
        raise InvalidArgsError("Thread key must be non-empty.")
    if os.sep in thread_key:
        raise InvalidArgsError("Thread key contains path separators.")
    if os.altsep and os.altsep in thread_key:
        raise InvalidArgsError("Thread key contains path separators.")
    if thread_key in {".", ".."} or ".." in thread_key:
        raise InvalidArgsError("Thread key contains invalid segments.")


def thread_file_path(thread_key: str) -> Path:
    _validate_thread_key(thread_key)
    return threads_dir() / f"{thread_key}.json"


def lock_file_path(thread_key: str) -> Path:
    _validate_thread_key(thread_key)
    return threads_dir() / f"{thread_key}.lock"
