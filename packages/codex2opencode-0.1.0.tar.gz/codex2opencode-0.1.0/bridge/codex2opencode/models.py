from __future__ import annotations

from dataclasses import dataclass, asdict

from .errors import StateError


@dataclass(slots=True)
class ThreadState:
    thread_key: str
    workspace_root: str
    thread_name: str | None
    opencode_session_id: str | None
    opencode_title: str | None
    created_at: str
    last_used_at: str
    last_status: str
    last_run_mode: str | None
    bridge_version: str
    opencode_version: str | None
    last_error: str | None
    message_count: int
    last_exported_at: str | None

    def to_dict(self) -> dict[str, object]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, object]) -> "ThreadState":
        required = {
            "thread_key",
            "workspace_root",
            "thread_name",
            "opencode_session_id",
            "opencode_title",
            "created_at",
            "last_used_at",
            "last_status",
            "last_run_mode",
            "bridge_version",
            "opencode_version",
            "last_error",
            "message_count",
            "last_exported_at",
        }
        missing = required - set(data.keys())
        if missing:
            raise StateError(f"Missing required state fields: {sorted(missing)}")

        def expect_str(value: object, name: str) -> str:
            if not isinstance(value, str):
                raise StateError(f"Invalid type for {name}.")
            return value

        def expect_optional_str(value: object, name: str) -> str | None:
            if value is None:
                return None
            if not isinstance(value, str):
                raise StateError(f"Invalid type for {name}.")
            return value

        def expect_int(value: object, name: str) -> int:
            if isinstance(value, bool) or not isinstance(value, int):
                raise StateError(f"Invalid type for {name}.")
            return value

        return cls(
            thread_key=expect_str(data["thread_key"], "thread_key"),
            workspace_root=expect_str(data["workspace_root"], "workspace_root"),
            thread_name=expect_optional_str(data["thread_name"], "thread_name"),
            opencode_session_id=expect_optional_str(
                data["opencode_session_id"], "opencode_session_id"
            ),
            opencode_title=expect_optional_str(data["opencode_title"], "opencode_title"),
            created_at=expect_str(data["created_at"], "created_at"),
            last_used_at=expect_str(data["last_used_at"], "last_used_at"),
            last_status=expect_str(data["last_status"], "last_status"),
            last_run_mode=expect_optional_str(data["last_run_mode"], "last_run_mode"),
            bridge_version=expect_str(data["bridge_version"], "bridge_version"),
            opencode_version=expect_optional_str(data["opencode_version"], "opencode_version"),
            last_error=expect_optional_str(data["last_error"], "last_error"),
            message_count=expect_int(data["message_count"], "message_count"),
            last_exported_at=expect_optional_str(data["last_exported_at"], "last_exported_at"),
        )
