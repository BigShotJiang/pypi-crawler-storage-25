from __future__ import annotations

import json
from pathlib import Path

from .errors import StateError
from .models import ThreadState


def save_thread_state(path: Path, state: ThreadState) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        temp_path = path.with_suffix(".tmp")
        temp_path.write_text(
            json.dumps(state.to_dict(), indent=2, sort_keys=True),
            encoding="utf-8",
        )
        temp_path.replace(path)
    except OSError as exc:
        raise StateError(f"Failed to write state to {path}: {exc}") from exc


def load_thread_state(path: Path) -> ThreadState:
    try:
        raw = path.read_text(encoding="utf-8")
        payload = json.loads(raw)
    except (OSError, json.JSONDecodeError) as exc:
        raise StateError(f"Failed to read state from {path}.") from exc
    if not isinstance(payload, dict):
        raise StateError(f"Invalid state payload in {path}.")
    return ThreadState.from_dict(payload)
