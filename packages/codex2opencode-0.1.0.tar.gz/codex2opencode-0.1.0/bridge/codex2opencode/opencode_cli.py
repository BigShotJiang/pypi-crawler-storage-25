from __future__ import annotations

import json
import subprocess
from typing import Any

from codex2opencode.errors import InvalidArgsError


def build_run_command(
    prompt: str,
    cwd: str,
    session_id: str | None,
    fork: bool,
    title: str | None,
    opencode_bin: str = "opencode",
) -> list[str]:
    if fork and not session_id:
        raise InvalidArgsError("fork requires an existing session id")
    command = [opencode_bin, "run", prompt, "--format", "json", "--dir", cwd]
    if session_id:
        command.extend(["--session", session_id])
    if fork:
        command.append("--fork")
    if title:
        command.extend(["--title", title])
    return command


def build_export_command(session_id: str, opencode_bin: str = "opencode") -> list[str]:
    return [opencode_bin, "export", session_id]


def build_delete_session_command(session_id: str, opencode_bin: str = "opencode") -> list[str]:
    return [opencode_bin, "session", "delete", session_id]


def _run_command(command: list[str], cwd: str | None = None) -> subprocess.CompletedProcess[str] | None:
    try:
        return subprocess.run(
            command,
            check=False,
            capture_output=True,
            text=True,
            cwd=cwd,
        )
    except FileNotFoundError:
        return None
    except OSError:
        return None


def read_opencode_version(opencode_bin: str = "opencode", cwd: str | None = None) -> str | None:
    completed = _run_command([opencode_bin, "--version"], cwd=cwd)
    if not completed or completed.returncode != 0:
        return None
    output = completed.stdout.strip()
    if not output:
        return None
    return output


def read_debug_paths(opencode_bin: str = "opencode", cwd: str | None = None) -> str | None:
    completed = _run_command([opencode_bin, "debug", "paths"], cwd=cwd)
    if not completed or completed.returncode != 0:
        return None
    output = completed.stdout.strip()
    if not output:
        return None
    return output


def read_debug_config(opencode_bin: str = "opencode", cwd: str | None = None) -> dict[str, Any] | None:
    completed = _run_command([opencode_bin, "debug", "config"], cwd=cwd)
    if not completed or completed.returncode != 0:
        return None
    output = completed.stdout.strip()
    if not output:
        return None
    try:
        parsed = json.loads(output)
    except json.JSONDecodeError:
        return None
    if not isinstance(parsed, dict):
        return None
    return parsed
