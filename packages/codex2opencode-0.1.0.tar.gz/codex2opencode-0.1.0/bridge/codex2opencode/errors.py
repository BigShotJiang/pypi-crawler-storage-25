EXIT_OK = 0
EXIT_OPENCODE_ERROR = 1
EXIT_TIMEOUT = 2
EXIT_LOCK_CONFLICT = 3
EXIT_INVALID_ARGS = 4
EXIT_STATE_ERROR = 5
EXIT_STREAM_ERROR = 6
EXIT_SESSION_ERROR = 7


class BridgeError(Exception):
    exit_code = EXIT_OPENCODE_ERROR


class TimeoutError(BridgeError):
    exit_code = EXIT_TIMEOUT


class LockConflictError(BridgeError):
    exit_code = EXIT_LOCK_CONFLICT


class InvalidArgsError(BridgeError):
    exit_code = EXIT_INVALID_ARGS


class StateError(BridgeError):
    exit_code = EXIT_STATE_ERROR


class StreamError(BridgeError):
    exit_code = EXIT_STREAM_ERROR


class SessionError(BridgeError):
    exit_code = EXIT_SESSION_ERROR
