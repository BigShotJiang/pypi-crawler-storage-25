from __future__ import annotations

import hashlib
import json
from pathlib import Path


def resolve_workspace_root(workspace_root: str) -> str:
    return str(Path(workspace_root).expanduser().resolve())


def make_thread_key(workspace_root: str, thread_name: str | None) -> str:
    payload = {
        "workspace_root": resolve_workspace_root(workspace_root),
        "thread_name": thread_name,
    }
    encoded = json.dumps(payload, sort_keys=True).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()
