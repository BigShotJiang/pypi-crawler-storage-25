from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Iterable, Iterator, TextIO


@dataclass(slots=True)
class StreamSummary:
    session_id: str | None
    text_output: str
    malformed_lines: int
    event_counts: dict[str, int]


def parse_event_lines(lines: Iterable[str]) -> StreamSummary:
    session_id: str | None = None
    text_parts: list[str] = []
    malformed_lines = 0
    event_counts: dict[str, int] = {}

    for raw_line in lines:
        line = raw_line.strip()
        if not line:
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            malformed_lines += 1
            continue

        if not isinstance(event, dict):
            malformed_lines += 1
            continue

        event_type = str(event.get("type", "unknown"))
        event_counts[event_type] = event_counts.get(event_type, 0) + 1
        if session_id is None:
            candidate_session_id = event.get("sessionID")
            if isinstance(candidate_session_id, str):
                session_id = candidate_session_id
        part = event.get("part") or {}
        if event_type == "text" and isinstance(part, dict):
            text = part.get("text")
            if isinstance(text, str):
                text_parts.append(text)

    return StreamSummary(
        session_id=session_id,
        text_output="".join(text_parts),
        malformed_lines=malformed_lines,
        event_counts=event_counts,
    )


def iter_stream_events(handle: TextIO) -> Iterator[str]:
    for line in handle:
        yield line
