from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path

from .errors import (
    EXIT_OK,
    BridgeError,
    InvalidArgsError,
    SessionError,
    StateError,
    StreamError,
    TimeoutError,
)
from .event_stream import parse_event_lines
from .locking import acquire_thread_lock
from .locking import fcntl
from .logging_utils import append_bridge_log, utc_now_iso
from .models import ThreadState
from .opencode_cli import (
    build_delete_session_command,
    build_export_command,
    build_run_command,
    read_debug_config,
    read_debug_paths,
    read_opencode_version,
)
from .paths import lock_file_path, logs_dir, runs_dir, thread_file_path, threads_dir
from .state import load_thread_state, save_thread_state
from .threading import make_thread_key, resolve_workspace_root
from .version import __version__


DEFAULT_TIMEOUT_SECONDS = 300


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="codex2opencode")
    subparsers = parser.add_subparsers(dest="command", required=True)

    ask = subparsers.add_parser("ask")
    ask.add_argument("--prompt", required=True)
    ask.add_argument("--workspace")
    ask.add_argument("--thread")
    ask.add_argument("--new", action="store_true")
    ask.add_argument("--fork", action="store_true")
    ask.add_argument("--title")
    ask.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT_SECONDS)

    status = subparsers.add_parser("status")
    status.add_argument("--workspace")
    status.add_argument("--thread")

    forget = subparsers.add_parser("forget")
    forget.add_argument("--workspace")
    forget.add_argument("--thread")

    gc = subparsers.add_parser("gc")
    gc.add_argument("--max-age-days", type=int, default=7)

    doctor = subparsers.add_parser("doctor")
    doctor.add_argument("--workspace")
    doctor.add_argument("--thread")

    return parser


def _resolve_thread(workspace: str | None, thread_name: str | None) -> tuple[str, str]:
    workspace_root = resolve_workspace_root(workspace or ".")
    return workspace_root, make_thread_key(workspace_root, thread_name)


def _read_optional_thread_state(path: Path) -> ThreadState | None:
    if not path.exists():
        return None
    try:
        return load_thread_state(path)
    except BridgeError:
        return None


def _write_run_record(
    thread_key: str,
    prompt: str,
    started_at: str,
    duration_ms: int,
    run_mode: str,
    summary_session_id: str | None,
    export_verified: bool,
    text_output: str,
    stderr_text: str,
    event_counts: dict[str, int],
) -> None:
    record = {
        "run_id": uuid.uuid4().hex,
        "thread_key": thread_key,
        "started_at": started_at,
        "ended_at": utc_now_iso(),
        "duration_ms": duration_ms,
        "run_mode": run_mode,
        "prompt_sha256": hashlib.sha256(prompt.encode("utf-8")).hexdigest(),
        "session_id": summary_session_id,
        "export_verified": export_verified,
        "stdout_preview": text_output[:200],
        "stderr_preview": stderr_text[:200],
        "event_counts": event_counts,
    }
    run_dir = runs_dir() / thread_key
    filename = f"{record['ended_at'].replace(':', '-')}-{record['run_id']}.json"
    path = run_dir / filename
    temp_path = path.with_suffix(".tmp")
    try:
        run_dir.mkdir(parents=True, exist_ok=True)
        temp_path.write_text(json.dumps(record, indent=2, sort_keys=True), encoding="utf-8")
        temp_path.replace(path)
    except OSError as exc:
        raise StateError(f"Failed to write run record to {path}: {exc}") from exc


def _run_opencode(command: list[str], timeout_seconds: int, cwd: str) -> subprocess.CompletedProcess[str]:
    try:
        return subprocess.run(
            command,
            check=False,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            cwd=cwd,
        )
    except FileNotFoundError as exc:
        raise BridgeError(f"Opencode CLI not found: {command[0]}") from exc
    except subprocess.TimeoutExpired as exc:
        raise TimeoutError(f"Opencode timed out after {timeout_seconds}s") from exc
    except OSError as exc:
        raise BridgeError(f"Failed to execute Opencode CLI: {exc}") from exc


def _extract_export_json(raw_output: str) -> str:
    lines = raw_output.splitlines()
    for index, line in enumerate(lines):
        if line.lstrip().startswith("{"):
            return "\n".join(lines[index:])
    return raw_output


def _extract_response_metadata(export_payload: dict[str, object]) -> tuple[str | None, str | None]:
    messages = export_payload.get("messages")
    if not isinstance(messages, list):
        return None, None
    for message in reversed(messages):
        if not isinstance(message, dict):
            continue
        info = message.get("info")
        if not isinstance(info, dict):
            continue
        if info.get("role") != "assistant":
            continue
        provider_id = info.get("providerID") if isinstance(info.get("providerID"), str) else None
        model_id = info.get("modelID") if isinstance(info.get("modelID"), str) else None
        return provider_id, model_id
    return None, None


def _write_response_text(
    text_output: str,
    session_id: str,
    provider_id: str | None = None,
    model_id: str | None = None,
) -> None:
    header_parts = ["[oc"]
    if provider_id:
        header_parts.append(f"provider={provider_id}")
    if model_id:
        header_parts.append(f"model={model_id}")
    header_parts.append(f"session={session_id}]")
    sys.stdout.write(" ".join(header_parts) + "\n")
    if text_output:
        sys.stdout.write(text_output)


def _export_session(session_id: str, opencode_bin: str, workspace_root: str) -> dict[str, object]:
    completed = _run_opencode(
        build_export_command(session_id, opencode_bin),
        timeout_seconds=20,
        cwd=workspace_root,
    )
    if completed.returncode != 0:
        message = completed.stderr.strip() or completed.stdout.strip() or f"Session export failed: {session_id}"
        raise SessionError(message)
    try:
        payload = json.loads(_extract_export_json(completed.stdout))
    except json.JSONDecodeError as exc:
        raise SessionError("Opencode export returned malformed JSON") from exc
    if not isinstance(payload, dict):
        raise SessionError("Opencode export returned invalid payload")
    return payload


def _build_thread_state(
    thread_key: str,
    workspace_root: str,
    thread_name: str | None,
    summary_session_id: str,
    prior_state: ThreadState | None,
    run_mode: str,
    title_override: str | None,
    export_payload: dict[str, object],
    opencode_bin: str,
) -> ThreadState:
    now = utc_now_iso()
    info = export_payload.get("info")
    info_dict = info if isinstance(info, dict) else {}
    messages = export_payload.get("messages")
    message_count = len(messages) if isinstance(messages, list) else 0
    exported_title = info_dict.get("title") if isinstance(info_dict.get("title"), str) else None
    exported_version = info_dict.get("version") if isinstance(info_dict.get("version"), str) else None
    opencode_version = read_opencode_version(opencode_bin, cwd=workspace_root) or exported_version

    created_at = now if prior_state is None or run_mode in {"new", "fork"} else prior_state.created_at
    return ThreadState(
        thread_key=thread_key,
        workspace_root=workspace_root,
        thread_name=thread_name,
        opencode_session_id=summary_session_id,
        opencode_title=title_override or exported_title,
        created_at=created_at,
        last_used_at=now,
        last_status="ok",
        last_run_mode=run_mode,
        bridge_version=__version__,
        opencode_version=opencode_version,
        last_error=None,
        message_count=message_count,
        last_exported_at=now,
    )


def _build_unverified_thread_state(
    thread_key: str,
    workspace_root: str,
    thread_name: str | None,
    summary_session_id: str,
    prior_state: ThreadState | None,
    run_mode: str,
    title_override: str | None,
    opencode_bin: str,
    error_message: str,
) -> ThreadState:
    now = utc_now_iso()
    created_at = now if prior_state is None or run_mode in {"new", "fork"} else prior_state.created_at
    opencode_version = read_opencode_version(opencode_bin, cwd=workspace_root) or (
        prior_state.opencode_version if prior_state else None
    )
    return ThreadState(
        thread_key=thread_key,
        workspace_root=workspace_root,
        thread_name=thread_name,
        opencode_session_id=summary_session_id,
        opencode_title=title_override or (prior_state.opencode_title if prior_state else None),
        created_at=created_at,
        last_used_at=now,
        last_status="session_unverified",
        last_run_mode=run_mode,
        bridge_version=__version__,
        opencode_version=opencode_version,
        last_error=error_message,
        message_count=prior_state.message_count if prior_state else 0,
        last_exported_at=prior_state.last_exported_at if prior_state else None,
    )


def _handle_ask(args: argparse.Namespace) -> int:
    if args.new and args.fork:
        raise InvalidArgsError("--new and --fork cannot be combined")

    workspace_root, thread_key = _resolve_thread(args.workspace, args.thread)
    state_path = thread_file_path(thread_key)
    lock_path = lock_file_path(thread_key)
    opencode_bin = os.environ.get("CODEX2OPENCODE_OPENCODE_BIN", "opencode")
    started_at = utc_now_iso()
    monotonic_start = time.monotonic()

    with acquire_thread_lock(lock_path):
        prior_state = None if args.new else _read_optional_thread_state(state_path)
        session_id = None if args.new else (prior_state.opencode_session_id if prior_state else None)
        if args.fork and not session_id:
            raise InvalidArgsError("--fork requires an existing thread session")

        run_mode = "fork" if args.fork else ("new" if args.new or session_id is None else "resume")
        command = build_run_command(
            prompt=args.prompt,
            cwd=workspace_root,
            session_id=session_id,
            fork=args.fork,
            title=args.title,
            opencode_bin=opencode_bin,
        )
        completed = _run_opencode(command, timeout_seconds=args.timeout, cwd=workspace_root)
        if completed.returncode != 0:
            message = completed.stderr.strip() or completed.stdout.strip() or "Opencode run failed"
            raise BridgeError(message)

        summary = parse_event_lines(completed.stdout.splitlines(keepends=True))
        if summary.session_id is None:
            raise StreamError("Opencode stream did not include a sessionID")

        duration_ms = max(1, int((time.monotonic() - monotonic_start) * 1000))
        try:
            export_payload = _export_session(summary.session_id, opencode_bin, workspace_root)
        except SessionError as exc:
            state = _build_unverified_thread_state(
                thread_key=thread_key,
                workspace_root=workspace_root,
                thread_name=args.thread,
                summary_session_id=summary.session_id,
                prior_state=prior_state,
                run_mode=run_mode,
                title_override=args.title,
                opencode_bin=opencode_bin,
                error_message=str(exc),
            )
            save_thread_state(state_path, state)
            _write_run_record(
                thread_key=thread_key,
                prompt=args.prompt,
                started_at=started_at,
                duration_ms=duration_ms,
                run_mode=run_mode,
                summary_session_id=summary.session_id,
                export_verified=False,
                text_output=summary.text_output,
                stderr_text=str(exc),
                event_counts=summary.event_counts,
            )
            append_bridge_log(
                {
                    "action": "ask",
                    "thread_key": thread_key,
                    "run_mode": run_mode,
                    "session_id": summary.session_id,
                    "outcome": "session_unverified",
                    "message": str(exc),
                }
            )
            _write_response_text(
                text_output=summary.text_output,
                session_id=summary.session_id,
            )
            raise

        state = _build_thread_state(
            thread_key=thread_key,
            workspace_root=workspace_root,
            thread_name=args.thread,
            summary_session_id=summary.session_id,
            prior_state=prior_state,
            run_mode=run_mode,
            title_override=args.title,
            export_payload=export_payload,
            opencode_bin=opencode_bin,
        )
        provider_id, model_id = _extract_response_metadata(export_payload)
        save_thread_state(state_path, state)
        _write_run_record(
            thread_key=thread_key,
            prompt=args.prompt,
            started_at=started_at,
            duration_ms=duration_ms,
            run_mode=run_mode,
            summary_session_id=summary.session_id,
            export_verified=True,
            text_output=summary.text_output,
            stderr_text=completed.stderr,
            event_counts=summary.event_counts,
        )
        append_bridge_log(
            {
                "action": "ask",
                "thread_key": thread_key,
                "run_mode": run_mode,
                "session_id": summary.session_id,
                "outcome": "success",
            }
        )
        _write_response_text(
            text_output=summary.text_output,
            session_id=summary.session_id,
            provider_id=provider_id,
            model_id=model_id,
        )
    return EXIT_OK


def _probe_lock_path(lock_path: Path) -> dict[str, object]:
    payload: dict[str, object] = {
        "path": str(lock_path),
        "present": lock_path.exists(),
    }
    if not lock_path.exists():
        payload["status"] = "ok"
        return payload
    if fcntl is None:
        payload["status"] = "error"
        payload["message"] = "Lock probing unsupported on this platform."
        return payload
    try:
        with lock_path.open("a+", encoding="utf-8") as handle:
            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                payload["status"] = "locked"
                return payload
            finally:
                try:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
                except OSError:
                    pass
    except OSError as exc:
        payload["status"] = "error"
        payload["message"] = str(exc)
        return payload
    payload["status"] = "ok"
    return payload


def _unlink_lock_file_if_stale_unlocked(lock_path: Path, cutoff: float) -> bool:
    if fcntl is None or not lock_path.exists():
        return False
    try:
        if lock_path.stat().st_mtime >= cutoff:
            return False
        with lock_path.open("a+", encoding="utf-8") as handle:
            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                return False
            if lock_path.exists() and lock_path.stat().st_mtime < cutoff:
                lock_path.unlink(missing_ok=True)
                return True
            return False
    except FileNotFoundError:
        return False
    except OSError:
        return False


def _handle_status(args: argparse.Namespace) -> int:
    _, thread_key = _resolve_thread(args.workspace, args.thread)
    state_path = thread_file_path(thread_key)
    if not state_path.exists():
        sys.stderr.write(f"No thread state found for {thread_key}\n")
        return BridgeError.exit_code
    state = load_thread_state(state_path)
    sys.stdout.write(json.dumps(state.to_dict(), indent=2, sort_keys=True) + "\n")
    return EXIT_OK


def _handle_forget(args: argparse.Namespace) -> int:
    workspace_root, thread_key = _resolve_thread(args.workspace, args.thread)
    state_path = thread_file_path(thread_key)
    lock_path = lock_file_path(thread_key)
    opencode_bin = os.environ.get("CODEX2OPENCODE_OPENCODE_BIN", "opencode")
    with acquire_thread_lock(lock_path):
        state = _read_optional_thread_state(state_path)

        warning_message: str | None = None
        if state and state.opencode_session_id:
            delete_cwd = state.workspace_root or workspace_root
            try:
                completed = _run_opencode(
                    build_delete_session_command(state.opencode_session_id, opencode_bin),
                    timeout_seconds=20,
                    cwd=delete_cwd,
                )
                if completed.returncode != 0:
                    warning_message = (
                        completed.stderr.strip()
                        or completed.stdout.strip()
                        or f"Failed to delete Opencode session {state.opencode_session_id}"
                    )
            except BridgeError as exc:
                warning_message = str(exc)

        state_path.unlink(missing_ok=True)
        lock_path.unlink(missing_ok=True)

    if warning_message:
        append_bridge_log(
            {
                "action": "forget",
                "outcome": "warning",
                "thread_key": thread_key,
                "message": warning_message,
            }
        )
        sys.stderr.write(f"{warning_message}\n")
    append_bridge_log({"action": "forget", "outcome": "success", "thread_key": thread_key})
    return EXIT_OK


def _handle_gc(args: argparse.Namespace) -> int:
    threads_dir().mkdir(parents=True, exist_ok=True)
    runs_dir().mkdir(parents=True, exist_ok=True)
    logs_dir().mkdir(parents=True, exist_ok=True)
    cutoff = time.time() - (args.max_age_days * 24 * 60 * 60)

    locked_thread_keys: set[str] = set()
    for lock_path in threads_dir().glob("*.lock"):
        if _probe_lock_path(lock_path)["status"] == "locked":
            locked_thread_keys.add(lock_path.stem)

    deleted = 0
    for path in threads_dir().glob("*"):
        try:
            if path.suffix == ".lock":
                if _unlink_lock_file_if_stale_unlocked(path, cutoff):
                    deleted += 1
                continue
            if path.stem in locked_thread_keys:
                continue
            if path.stat().st_mtime >= cutoff:
                continue
            path.unlink()
            deleted += 1
        except FileNotFoundError:
            continue

    for run_dir in runs_dir().iterdir():
        try:
            if not run_dir.is_dir():
                continue
            if run_dir.name in locked_thread_keys:
                continue
            newest_mtime = max(
                (child.stat().st_mtime for child in run_dir.rglob("*")),
                default=run_dir.stat().st_mtime,
            )
            if newest_mtime >= cutoff:
                continue
            shutil.rmtree(run_dir)
            deleted += 1
        except FileNotFoundError:
            continue

    append_bridge_log({"action": "gc", "outcome": "success", "deleted": deleted})
    return EXIT_OK


def _thread_state_doctor_payload(
    state_path: Path,
    thread_key: str,
    workspace_root: str,
    opencode_bin: str,
    lock_path: Path,
) -> dict[str, object]:
    if not state_path.exists():
        return {
            "status": "missing",
            "path": str(state_path),
            "thread_key": thread_key,
            "lock": _probe_lock_path(lock_path),
        }

    try:
        state = load_thread_state(state_path)
    except BridgeError as exc:
        return {
            "status": "error",
            "path": str(state_path),
            "thread_key": thread_key,
            "message": str(exc),
            "lock": _probe_lock_path(lock_path),
        }

    payload: dict[str, object] = {
        "status": "ok",
        "path": str(state_path),
        "thread_key": thread_key,
        "session_id": state.opencode_session_id,
        "last_status": state.last_status,
        "last_used_at": state.last_used_at,
        "lock": _probe_lock_path(lock_path),
        "session_verified": False,
    }
    if not state.opencode_session_id:
        return payload

    try:
        _export_session(state.opencode_session_id, opencode_bin, state.workspace_root or workspace_root)
    except SessionError as exc:
        payload["status"] = "orphaned"
        payload["message"] = str(exc)
        return payload
    except BridgeError as exc:
        payload["status"] = "error"
        payload["message"] = str(exc)
        return payload

    payload["session_verified"] = True
    return payload


def _handle_doctor(args: argparse.Namespace) -> int:
    workspace_root, thread_key = _resolve_thread(args.workspace, args.thread)
    state_path = thread_file_path(thread_key)
    lock_path = lock_file_path(thread_key)
    opencode_bin = os.environ.get("CODEX2OPENCODE_OPENCODE_BIN", "opencode")

    opencode_version = read_opencode_version(opencode_bin, cwd=workspace_root)
    debug_paths = read_debug_paths(opencode_bin, cwd=workspace_root)
    debug_config = read_debug_config(opencode_bin, cwd=workspace_root)
    thread_state_payload = _thread_state_doctor_payload(
        state_path=state_path,
        thread_key=thread_key,
        workspace_root=workspace_root,
        opencode_bin=opencode_bin,
        lock_path=lock_path,
    )

    payload = {
        "ok": (
            opencode_version is not None
            and debug_paths is not None
            and debug_config is not None
            and thread_state_payload["status"] not in {"error", "orphaned"}
        ),
        "bridge_version": __version__,
        "workspace_root": workspace_root,
        "bridge_root": {
            "status": "ok",
            "path": str(threads_dir().parent),
        },
        "paths": {
            "threads": str(threads_dir()),
            "runs": str(runs_dir()),
            "logs": str(logs_dir()),
            "state_file": str(state_path),
            "lock_file": str(lock_path),
        },
        "opencode": {
            "status": "ok" if opencode_version is not None else "error",
            "bin": opencode_bin,
            "version": opencode_version,
        },
        "opencode_debug": {
            "paths": {
                "status": "ok" if debug_paths is not None else "error",
                "value": debug_paths,
            },
            "config": {
                "status": "ok" if debug_config is not None else "error",
                "value": debug_config,
            },
        },
        "thread_state": thread_state_payload,
    }
    sys.stdout.write(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    return EXIT_OK if payload["ok"] else BridgeError.exit_code


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
        if args.command == "ask":
            return _handle_ask(args)
        if args.command == "status":
            return _handle_status(args)
        if args.command == "forget":
            return _handle_forget(args)
        if args.command == "gc":
            return _handle_gc(args)
        if args.command == "doctor":
            return _handle_doctor(args)
        raise InvalidArgsError(f"Unknown command: {args.command}")
    except BridgeError as exc:
        append_bridge_log({"action": "error", "outcome": type(exc).__name__, "message": str(exc)})
        sys.stderr.write(f"{exc}\n")
        return exc.exit_code
    except OSError as exc:
        error = StateError(str(exc))
        append_bridge_log({"action": "error", "outcome": type(error).__name__, "message": str(error)})
        sys.stderr.write(f"{error}\n")
        return error.exit_code
