import tempfile
from pathlib import Path
import sys
import unittest


ROOT = Path(__file__).resolve().parents[1]
BRIDGE = ROOT / "bridge"
if str(BRIDGE) not in sys.path:
    sys.path.insert(0, str(BRIDGE))


class StatePersistenceTest(unittest.TestCase):
    def test_save_and_load_thread_state(self) -> None:
        from codex2opencode.models import ThreadState
        from codex2opencode.state import load_thread_state, save_thread_state

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "thread.json"
            state = ThreadState(
                thread_key="abc123",
                workspace_root="/tmp/project",
                thread_name=None,
                opencode_session_id=None,
                opencode_title=None,
                created_at="2026-03-28T00:00:00Z",
                last_used_at="2026-03-28T00:00:00Z",
                last_status="ok",
                last_run_mode=None,
                bridge_version="0.1.0",
                opencode_version=None,
                last_error=None,
                message_count=0,
                last_exported_at=None,
            )

            save_thread_state(path, state)
            loaded = load_thread_state(path)

        self.assertEqual(loaded, state)

    def test_load_thread_state_rejects_missing_fields(self) -> None:
        from codex2opencode.errors import StateError
        from codex2opencode.state import load_thread_state, save_thread_state

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "thread.json"
            path.write_text("{}", encoding="utf-8")

            with self.assertRaises(StateError):
                load_thread_state(path)

    def test_load_thread_state_rejects_bad_types(self) -> None:
        from codex2opencode.errors import StateError
        from codex2opencode.state import load_thread_state

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "thread.json"
            path.write_text(
                '{"thread_key":"abc","workspace_root":"/tmp","thread_name":null,'
                '"opencode_session_id":null,"opencode_title":null,'
                '"created_at":"2026-03-28T00:00:00Z","last_used_at":"2026-03-28T00:00:00Z",'
                '"last_status":"ok","last_run_mode":null,"bridge_version":"0.1.0",'
                '"opencode_version":null,"last_error":null,"message_count":"oops",'
                '"last_exported_at":null}',
                encoding="utf-8",
            )

            with self.assertRaises(StateError):
                load_thread_state(path)
