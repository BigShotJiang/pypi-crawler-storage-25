import tempfile
from pathlib import Path
import sys
import unittest


ROOT = Path(__file__).resolve().parents[1]
BRIDGE = ROOT / "bridge"
if str(BRIDGE) not in sys.path:
    sys.path.insert(0, str(BRIDGE))


class LockingTest(unittest.TestCase):
    def test_second_lock_attempt_fails(self) -> None:
        from codex2opencode.locking import LockConflictError, acquire_thread_lock

        with tempfile.TemporaryDirectory() as temp_dir:
            lock_path = Path(temp_dir) / "thread.lock"
            with acquire_thread_lock(lock_path):
                with self.assertRaises(LockConflictError):
                    with acquire_thread_lock(lock_path):
                        pass
