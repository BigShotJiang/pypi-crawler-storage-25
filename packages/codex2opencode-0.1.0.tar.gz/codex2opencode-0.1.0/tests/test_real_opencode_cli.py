import json
import os
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest import mock, skipUnless


@skipUnless(shutil.which("opencode"), "opencode CLI missing")
class RealOpencodeCliTest(unittest.TestCase):
    def test_real_opencode_roundtrip_smoke(self) -> None:
        if os.environ.get("CODEX2OPENCODE_RUN_REAL") != "1":
            self.skipTest("set CODEX2OPENCODE_RUN_REAL=1 to enable real Opencode integration")

        from codex2opencode.cli import main

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            workspace = Path(temp_dir) / "workspace"
            workspace.mkdir()
            with mock.patch.dict(os.environ, {"CODEX2OPENCODE_HOME": str(state_root)}, clear=False), mock.patch("sys.stdout.write"):
                exit_code = main(
                    [
                        "ask",
                        "--prompt",
                        "Reply with ok only",
                        "--workspace",
                        str(workspace),
                        "--timeout",
                        "120",
                        "--new",
                    ]
                )

        self.assertEqual(exit_code, 0)

    def test_real_opencode_resume_smoke(self) -> None:
        if os.environ.get("CODEX2OPENCODE_RUN_REAL") != "1":
            self.skipTest("set CODEX2OPENCODE_RUN_REAL=1 to enable real Opencode integration")

        from codex2opencode.cli import main
        from codex2opencode.threading import make_thread_key

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            workspace = Path(temp_dir) / "workspace"
            workspace.mkdir()
            with mock.patch.dict(os.environ, {"CODEX2OPENCODE_HOME": str(state_root)}, clear=False), mock.patch("sys.stdout.write"):
                first = main(
                    [
                        "ask",
                        "--prompt",
                        "Reply with ok only",
                        "--workspace",
                        str(workspace),
                        "--thread",
                        "resume-smoke",
                        "--timeout",
                        "120",
                    ]
                )
                second = main(
                    [
                        "ask",
                        "--prompt",
                        "Now reply with resume-ok only",
                        "--workspace",
                        str(workspace),
                        "--thread",
                        "resume-smoke",
                        "--timeout",
                        "120",
                    ]
                )

            thread_key = make_thread_key(str(workspace), "resume-smoke")
            state_path = state_root / "threads" / f"{thread_key}.json"
            run_files = sorted((state_root / "runs" / thread_key).glob("*.json"))
            last_record = json.loads(run_files[-1].read_text(encoding="utf-8"))
            state = json.loads(state_path.read_text(encoding="utf-8"))

        self.assertEqual(first, 0)
        self.assertEqual(second, 0)
        self.assertEqual(last_record["run_mode"], "resume")
        self.assertTrue(last_record["export_verified"])
        self.assertEqual(state["last_run_mode"], "resume")


if __name__ == "__main__":
    unittest.main()
