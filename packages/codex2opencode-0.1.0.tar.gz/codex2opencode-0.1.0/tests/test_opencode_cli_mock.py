import sys
import unittest
from pathlib import Path
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
BRIDGE = ROOT / "bridge"
if str(BRIDGE) not in sys.path:
    sys.path.insert(0, str(BRIDGE))


class OpencodeCliAdapterTest(unittest.TestCase):
    def test_build_run_command_for_new_prompt(self) -> None:
        from codex2opencode.opencode_cli import build_run_command

        cmd = build_run_command(
            prompt="hello",
            cwd="/tmp/project",
            session_id=None,
            fork=False,
            title=None,
            opencode_bin="opencode",
        )

        self.assertEqual(cmd[:2], ["opencode", "run"])
        self.assertIn("--format", cmd)
        self.assertIn("json", cmd)
        self.assertIn("--dir", cmd)

    def test_build_run_command_for_forked_session(self) -> None:
        from codex2opencode.opencode_cli import build_run_command

        cmd = build_run_command(
            prompt="fork",
            cwd="/tmp/project",
            session_id="ses_123",
            fork=True,
            title="Forked",
            opencode_bin="opencode",
        )

        self.assertIn("--session", cmd)
        self.assertIn("--fork", cmd)
        self.assertIn("--title", cmd)

    def test_build_run_command_rejects_fork_without_session(self) -> None:
        from codex2opencode.errors import InvalidArgsError
        from codex2opencode.opencode_cli import build_run_command

        with self.assertRaises(InvalidArgsError):
            build_run_command(
                prompt="fork",
                cwd="/tmp/project",
                session_id=None,
                fork=True,
                title=None,
                opencode_bin="opencode",
            )

    def test_build_export_command(self) -> None:
        from codex2opencode.opencode_cli import build_export_command

        self.assertEqual(build_export_command("ses_123", "opencode"), ["opencode", "export", "ses_123"])

    def test_build_delete_session_command(self) -> None:
        from codex2opencode.opencode_cli import build_delete_session_command

        self.assertEqual(
            build_delete_session_command("ses_123", "opencode"),
            ["opencode", "session", "delete", "ses_123"],
        )

    def test_read_opencode_version_returns_none_when_missing(self) -> None:
        from codex2opencode.opencode_cli import read_opencode_version

        self.assertIsNone(read_opencode_version("/missing/opencode"))

    def test_read_opencode_version_success(self) -> None:
        from codex2opencode.opencode_cli import read_opencode_version

        completed = mock.Mock(returncode=0, stdout="opencode 1.2.3\n")
        with mock.patch(
            "codex2opencode.opencode_cli._run_command",
            return_value=completed,
        ):
            self.assertEqual(read_opencode_version("opencode"), "opencode 1.2.3")

    def test_read_debug_config_success(self) -> None:
        from codex2opencode.opencode_cli import read_debug_config

        completed = mock.Mock(returncode=0, stdout='{"key":"value"}\n')
        with mock.patch(
            "codex2opencode.opencode_cli._run_command",
            return_value=completed,
        ):
            self.assertEqual(read_debug_config("opencode"), {"key": "value"})

    def test_read_debug_config_returns_none_on_malformed_json(self) -> None:
        from codex2opencode.opencode_cli import read_debug_config

        completed = mock.Mock(returncode=0, stdout="{bad json}\n")
        with mock.patch(
            "codex2opencode.opencode_cli._run_command",
            return_value=completed,
        ):
            self.assertIsNone(read_debug_config("opencode"))

    def test_read_debug_config_returns_none_on_nonzero_exit(self) -> None:
        from codex2opencode.opencode_cli import read_debug_config

        completed = mock.Mock(returncode=1, stdout='{"key":"value"}\n')
        with mock.patch(
            "codex2opencode.opencode_cli._run_command",
            return_value=completed,
        ):
            self.assertIsNone(read_debug_config("opencode"))
