import os
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

from tests.test_ask_flow_mock import FAKE_OPENCODE


ROOT = Path(__file__).resolve().parents[1]
BRIDGE = ROOT / "bridge"


class ConcurrencyTest(unittest.TestCase):
    def test_same_thread_lock_contention(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            workspace = Path(temp_dir) / "workspace"
            bin_dir = Path(temp_dir) / "bin"
            workspace.mkdir()
            bin_dir.mkdir()

            fake_opencode = bin_dir / "opencode"
            fake_opencode.write_text(FAKE_OPENCODE, encoding="utf-8")
            fake_opencode.chmod(0o755)

            env = dict(os.environ)
            env["PYTHONPATH"] = str(BRIDGE)
            env["CODEX2OPENCODE_HOME"] = str(state_root)
            env["CODEX2OPENCODE_OPENCODE_BIN"] = str(fake_opencode)
            env["OPENCODE_FAKE_SLEEP_MS"] = "1200"

            first = subprocess.Popen(
                [
                    sys.executable,
                    "-m",
                    "codex2opencode",
                    "ask",
                    "--prompt",
                    "one",
                    "--workspace",
                    str(workspace),
                ],
                cwd=str(ROOT),
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
            try:
                time.sleep(0.2)
                second = subprocess.run(
                    [
                        sys.executable,
                        "-m",
                        "codex2opencode",
                        "ask",
                        "--prompt",
                        "two",
                        "--workspace",
                        str(workspace),
                    ],
                    cwd=str(ROOT),
                    env=env,
                    capture_output=True,
                    text=True,
                )
            finally:
                first_result = first.communicate(timeout=5)

        self.assertEqual(first.returncode, 0, msg="".join(first_result))
        self.assertEqual(second.returncode, 3, msg=second.stderr)
        self.assertIn("Lock already held", second.stderr)

    def test_forget_conflicts_with_in_flight_ask_on_same_thread(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            workspace = Path(temp_dir) / "workspace"
            bin_dir = Path(temp_dir) / "bin"
            workspace.mkdir()
            bin_dir.mkdir()

            fake_opencode = bin_dir / "opencode"
            fake_opencode.write_text(FAKE_OPENCODE, encoding="utf-8")
            fake_opencode.chmod(0o755)

            env = dict(os.environ)
            env["PYTHONPATH"] = str(BRIDGE)
            env["CODEX2OPENCODE_HOME"] = str(state_root)
            env["CODEX2OPENCODE_OPENCODE_BIN"] = str(fake_opencode)
            env["OPENCODE_FAKE_SLEEP_MS"] = "1200"

            first = subprocess.Popen(
                [
                    sys.executable,
                    "-m",
                    "codex2opencode",
                    "ask",
                    "--prompt",
                    "one",
                    "--workspace",
                    str(workspace),
                ],
                cwd=str(ROOT),
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
            try:
                time.sleep(0.2)
                second = subprocess.run(
                    [
                        sys.executable,
                        "-m",
                        "codex2opencode",
                        "forget",
                        "--workspace",
                        str(workspace),
                    ],
                    cwd=str(ROOT),
                    env=env,
                    capture_output=True,
                    text=True,
                )
            finally:
                first_result = first.communicate(timeout=5)

        self.assertEqual(first.returncode, 0, msg="".join(first_result))
        self.assertEqual(second.returncode, 3, msg=second.stderr)
        self.assertIn("Lock already held", second.stderr)
