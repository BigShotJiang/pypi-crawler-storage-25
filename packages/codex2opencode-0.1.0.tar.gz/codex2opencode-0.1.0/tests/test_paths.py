import os
from pathlib import Path
import sys
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
BRIDGE = ROOT / "bridge"
if str(BRIDGE) not in sys.path:
    sys.path.insert(0, str(BRIDGE))


class PathsTest(unittest.TestCase):
    def test_thread_file_path_uses_codex_root(self) -> None:
        with mock.patch.dict(os.environ, {"HOME": "/tmp/c2o-home"}, clear=False):
            from codex2opencode.paths import thread_file_path

            path = thread_file_path("abc123")

        self.assertIn("codex2opencode", str(path))
        self.assertEqual(path.name, "abc123.json")

    def test_bridge_root_honors_override_env_var(self) -> None:
        with mock.patch.dict(os.environ, {"CODEX2OPENCODE_HOME": "/tmp/c2o-root"}, clear=False):
            from codex2opencode.paths import bridge_root

            self.assertEqual(str(bridge_root()), "/tmp/c2o-root")

    def test_thread_file_path_rejects_unsafe_key(self) -> None:
        from codex2opencode.errors import InvalidArgsError
        from codex2opencode.paths import thread_file_path

        with self.assertRaises(InvalidArgsError):
            thread_file_path("../escape")
