import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from tests.test_ask_flow_mock import FAKE_OPENCODE


class RecoveryTest(unittest.TestCase):
    def test_corrupted_thread_state_is_replaced_on_next_ask(self) -> None:
        from codex2opencode.cli import main
        from codex2opencode.threading import make_thread_key

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            workspace = Path(temp_dir) / "workspace"
            bin_dir = Path(temp_dir) / "bin"
            workspace.mkdir()
            bin_dir.mkdir()

            fake_opencode = bin_dir / "opencode"
            fake_opencode.write_text(FAKE_OPENCODE, encoding="utf-8")
            fake_opencode.chmod(0o755)

            thread_key = make_thread_key(str(workspace), None)
            state_path = state_root / "threads" / f"{thread_key}.json"
            state_path.parent.mkdir(parents=True, exist_ok=True)
            state_path.write_text("{bad json", encoding="utf-8")

            env = {
                "CODEX2OPENCODE_HOME": str(state_root),
                "CODEX2OPENCODE_OPENCODE_BIN": str(fake_opencode),
            }
            with mock.patch.dict(os.environ, env, clear=False), mock.patch("sys.stdout.write"):
                exit_code = main(["ask", "--prompt", "hello", "--workspace", str(workspace)])

            state = json.loads(state_path.read_text(encoding="utf-8"))

        self.assertEqual(exit_code, 0)
        self.assertEqual(state["opencode_session_id"], "ses_new")

    def test_missing_export_after_run_raises_session_error(self) -> None:
        from codex2opencode.cli import main
        from codex2opencode.errors import EXIT_SESSION_ERROR
        from codex2opencode.threading import make_thread_key

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            workspace = Path(temp_dir) / "workspace"
            bin_dir = Path(temp_dir) / "bin"
            workspace.mkdir()
            bin_dir.mkdir()

            fake_opencode = bin_dir / "opencode"
            fake_opencode.write_text(FAKE_OPENCODE, encoding="utf-8")
            fake_opencode.chmod(0o755)

            env = {
                "CODEX2OPENCODE_HOME": str(state_root),
                "CODEX2OPENCODE_OPENCODE_BIN": str(fake_opencode),
                "OPENCODE_FAKE_MISSING_EXPORT": "ses_new",
            }
            stdout_writes: list[str] = []
            with (
                mock.patch.dict(os.environ, env, clear=False),
                mock.patch("sys.stdout.write", side_effect=stdout_writes.append),
                mock.patch("sys.stderr.write"),
            ):
                exit_code = main(["ask", "--prompt", "hello", "--workspace", str(workspace)])

            thread_key = make_thread_key(str(workspace), None)
            state_path = state_root / "threads" / f"{thread_key}.json"
            run_files = sorted((state_root / "runs" / thread_key).glob("*.json"))
            state = json.loads(state_path.read_text(encoding="utf-8"))
            record = json.loads(run_files[0].read_text(encoding="utf-8"))

        self.assertEqual(exit_code, EXIT_SESSION_ERROR)
        self.assertEqual(state["opencode_session_id"], "ses_new")
        self.assertEqual(state["last_status"], "session_unverified")
        self.assertEqual(state["last_error"], "Session not found: ses_new")
        self.assertEqual(len(run_files), 1)
        self.assertFalse(record["export_verified"])
        self.assertEqual(record["session_id"], "ses_new")
        self.assertIn("[oc session=ses_new]", "".join(stdout_writes))
        self.assertIn("echo:hello", "".join(stdout_writes))

    def test_ask_returns_state_error_when_state_write_fails(self) -> None:
        from codex2opencode.cli import main
        from codex2opencode.errors import EXIT_STATE_ERROR

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            workspace = Path(temp_dir) / "workspace"
            bin_dir = Path(temp_dir) / "bin"
            workspace.mkdir()
            bin_dir.mkdir()

            fake_opencode = bin_dir / "opencode"
            fake_opencode.write_text(FAKE_OPENCODE, encoding="utf-8")
            fake_opencode.chmod(0o755)

            env = {
                "CODEX2OPENCODE_HOME": str(state_root),
                "CODEX2OPENCODE_OPENCODE_BIN": str(fake_opencode),
            }
            stderr_writes: list[str] = []
            with (
                mock.patch.dict(os.environ, env, clear=False),
                mock.patch("codex2opencode.cli.save_thread_state", side_effect=OSError("disk full")),
                mock.patch("sys.stdout.write"),
                mock.patch("sys.stderr.write", side_effect=stderr_writes.append),
            ):
                exit_code = main(["ask", "--prompt", "hello", "--workspace", str(workspace)])

        self.assertEqual(exit_code, EXIT_STATE_ERROR)
        self.assertIn("disk full", "".join(stderr_writes))

    def test_ask_returns_bridge_error_when_opencode_is_not_executable(self) -> None:
        from codex2opencode.cli import main
        from codex2opencode.errors import EXIT_OPENCODE_ERROR

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            workspace = Path(temp_dir) / "workspace"
            workspace.mkdir()

            env = {
                "CODEX2OPENCODE_HOME": str(state_root),
                "CODEX2OPENCODE_OPENCODE_BIN": "/tmp/not-executable",
            }
            stderr_writes: list[str] = []
            with (
                mock.patch.dict(os.environ, env, clear=False),
                mock.patch("codex2opencode.cli.subprocess.run", side_effect=PermissionError("Permission denied")),
                mock.patch("sys.stderr.write", side_effect=stderr_writes.append),
            ):
                exit_code = main(["ask", "--prompt", "hello", "--workspace", str(workspace)])

        self.assertEqual(exit_code, EXIT_OPENCODE_ERROR)
        self.assertIn("Permission denied", "".join(stderr_writes))
