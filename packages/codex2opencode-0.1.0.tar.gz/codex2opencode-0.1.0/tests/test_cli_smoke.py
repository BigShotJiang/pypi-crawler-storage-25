import os
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
BRIDGE = ROOT / "bridge"
if str(BRIDGE) not in sys.path:
    sys.path.insert(0, str(BRIDGE))


class CliSmokeTest(unittest.TestCase):
    def test_version_is_defined(self) -> None:
        from codex2opencode.version import __version__

        self.assertIsInstance(__version__, str)
        self.assertTrue(__version__)

    def test_module_entrypoint_requires_a_command(self) -> None:
        env = dict(os.environ)
        env["PYTHONPATH"] = "bridge"
        result = subprocess.run(
            [sys.executable, "-m", "codex2opencode"],
            capture_output=True,
            text=True,
            env=env,
        )

        self.assertNotEqual(result.returncode, 0)
        combined_output = (result.stderr or "") + (result.stdout or "")
        self.assertIn("the following arguments are required: command", combined_output)
