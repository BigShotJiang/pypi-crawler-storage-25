from pathlib import Path
import tomllib
import unittest


class PackageMetadataTest(unittest.TestCase):
    def test_pyproject_exists(self) -> None:
        self.assertTrue(Path("pyproject.toml").exists())

    def test_pyproject_metadata(self) -> None:
        pyproject = Path("pyproject.toml").read_text(encoding="utf-8")
        data = tomllib.loads(pyproject)

        project = data.get("project", {})
        self.assertEqual(project.get("name"), "codex2opencode")
        scripts = project.get("scripts", {})
        self.assertEqual(scripts.get("codex2opencode"), "codex2opencode.cli:main")
        self.assertIn("version", project.get("dynamic", []))

        setuptools_dynamic = data.get("tool", {}).get("setuptools", {}).get("dynamic", {})
        version = setuptools_dynamic.get("version", {})
        self.assertEqual(version.get("attr"), "codex2opencode.version.__version__")
