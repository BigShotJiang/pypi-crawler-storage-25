import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock


FAKE_OPENCODE = """#!/usr/bin/env python3
import json
import os
import sys
import time
from pathlib import Path

args = sys.argv[1:]
command = args[0]

log_path = os.environ.get("OPENCODE_FAKE_LOG")
cwd_log = os.environ.get("OPENCODE_FAKE_CWD_LOG")
trace_log = os.environ.get("OPENCODE_FAKE_TRACE_LOG")
sleep_ms = int(os.environ.get("OPENCODE_FAKE_SLEEP_MS", "0"))
missing_export = os.environ.get("OPENCODE_FAKE_MISSING_EXPORT")
missing_delete = os.environ.get("OPENCODE_FAKE_MISSING_DELETE")
broken_debug_config = os.environ.get("OPENCODE_FAKE_BROKEN_DEBUG_CONFIG")
export_banner = os.environ.get("OPENCODE_FAKE_EXPORT_BANNER")

if log_path:
    with open(log_path, "a", encoding="utf-8") as handle:
        handle.write(" ".join(args) + "\\n")

if cwd_log:
    with open(cwd_log, "a", encoding="utf-8") as handle:
        handle.write(str(Path.cwd()) + "\\n")

if trace_log:
    with open(trace_log, "a", encoding="utf-8") as handle:
        handle.write(f"{command}|{Path.cwd()}\\n")

if command == "--version":
    sys.stdout.write("1.3.3\\n")
    raise SystemExit(0)

if command == "run":
    prompt = args[1]
    if sleep_ms:
        time.sleep(sleep_ms / 1000.0)
    if "--fork" in args:
        session_id = "ses_forked"
    elif "--session" in args:
        session_id = args[args.index("--session") + 1]
    else:
        session_id = "ses_new"
    sys.stdout.write(json.dumps({"type": "step_start", "sessionID": session_id, "part": {"type": "step-start"}}) + "\\n")
    sys.stdout.write(json.dumps({"type": "text", "sessionID": session_id, "part": {"type": "text", "text": "echo:" + prompt}}) + "\\n")
    raise SystemExit(0)

if command == "export":
    session_id = args[1]
    if missing_export == session_id:
        sys.stderr.write(f"Session not found: {session_id}\\n")
        raise SystemExit(1)
    payload = {
        "info": {
            "id": session_id,
            "title": "hello",
            "version": "1.3.3",
        },
        "messages": [
            {
                "info": {
                    "role": "assistant",
                    "providerID": "opencode",
                    "modelID": "mimo-v2-omni-free",
                },
                "parts": [],
            }
        ],
    }
    if export_banner:
        sys.stdout.write(f"Exporting session: {session_id}\\n")
    sys.stdout.write(json.dumps(payload))
    raise SystemExit(0)

if command == "session" and len(args) >= 3 and args[1] == "delete":
    session_id = args[2]
    if missing_delete == session_id:
        sys.stderr.write(f"Session not found: {session_id}\\n")
        raise SystemExit(1)
    sys.stdout.write(json.dumps({"deleted": session_id}))
    raise SystemExit(0)

if command == "debug" and len(args) >= 2 and args[1] == "paths":
    sys.stdout.write("config: /tmp/opencode-config.json\\nstate: /tmp/opencode-state\\n")
    raise SystemExit(0)

if command == "debug" and len(args) >= 2 and args[1] == "config":
    if broken_debug_config:
        sys.stdout.write("{bad json")
        raise SystemExit(0)
    sys.stdout.write(json.dumps({"model": "gpt-5", "theme": "light"}))
    raise SystemExit(0)

sys.stderr.write("unsupported command\\n")
raise SystemExit(1)
"""


class AskFlowTest(unittest.TestCase):
    def test_ask_creates_thread_and_returns_success(self) -> None:
        from codex2opencode.cli import main
        from codex2opencode.threading import make_thread_key

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            workspace = Path(temp_dir) / "workspace"
            bin_dir = Path(temp_dir) / "bin"
            workspace.mkdir()
            bin_dir.mkdir()
            fake_opencode = bin_dir / "opencode"
            fake_opencode.write_text(FAKE_OPENCODE, encoding="utf-8")
            fake_opencode.chmod(0o755)

            env = {
                "CODEX2OPENCODE_HOME": str(state_root),
                "CODEX2OPENCODE_OPENCODE_BIN": str(fake_opencode),
            }
            with mock.patch.dict(os.environ, env, clear=False), mock.patch("sys.stdout.write") as mock_write:
                exit_code = main(["ask", "--prompt", "hello", "--workspace", str(workspace)])

            thread_key = make_thread_key(str(workspace), None)
            state_path = state_root / "threads" / f"{thread_key}.json"
            state = json.loads(state_path.read_text(encoding="utf-8"))

        self.assertEqual(exit_code, 0)
        self.assertTrue(mock_write.called)
        self.assertEqual(state["opencode_session_id"], "ses_new")
        combined_output = "".join(call.args[0] for call in mock_write.call_args_list)
        self.assertIn("[oc provider=opencode model=mimo-v2-omni-free session=ses_new]", combined_output)
        self.assertIn("echo:hello", combined_output)

    def test_second_ask_resumes_existing_session(self) -> None:
        from codex2opencode.cli import main

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            workspace = Path(temp_dir) / "workspace"
            bin_dir = Path(temp_dir) / "bin"
            log_path = Path(temp_dir) / "opencode-args.log"
            workspace.mkdir()
            bin_dir.mkdir()
            fake_opencode = bin_dir / "opencode"
            fake_opencode.write_text(FAKE_OPENCODE, encoding="utf-8")
            fake_opencode.chmod(0o755)

            env = {
                "CODEX2OPENCODE_HOME": str(state_root),
                "CODEX2OPENCODE_OPENCODE_BIN": str(fake_opencode),
                "OPENCODE_FAKE_LOG": str(log_path),
            }
            with mock.patch.dict(os.environ, env, clear=False), mock.patch("sys.stdout.write"):
                self.assertEqual(main(["ask", "--prompt", "one", "--workspace", str(workspace)]), 0)
                self.assertEqual(main(["ask", "--prompt", "two", "--workspace", str(workspace)]), 0)

            lines = log_path.read_text(encoding="utf-8").strip().splitlines()
            run_lines = [line for line in lines if line.startswith("run ")]

        self.assertEqual(len(run_lines), 2)
        self.assertNotIn("--session", run_lines[0])
        self.assertIn("--session ses_new", run_lines[1])

    def test_new_flag_forces_fresh_session(self) -> None:
        from codex2opencode.cli import main

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            workspace = Path(temp_dir) / "workspace"
            bin_dir = Path(temp_dir) / "bin"
            log_path = Path(temp_dir) / "opencode-args.log"
            workspace.mkdir()
            bin_dir.mkdir()
            fake_opencode = bin_dir / "opencode"
            fake_opencode.write_text(FAKE_OPENCODE, encoding="utf-8")
            fake_opencode.chmod(0o755)

            env = {
                "CODEX2OPENCODE_HOME": str(state_root),
                "CODEX2OPENCODE_OPENCODE_BIN": str(fake_opencode),
                "OPENCODE_FAKE_LOG": str(log_path),
            }
            with mock.patch.dict(os.environ, env, clear=False), mock.patch("sys.stdout.write"):
                self.assertEqual(main(["ask", "--prompt", "one", "--workspace", str(workspace)]), 0)
                self.assertEqual(main(["ask", "--prompt", "two", "--workspace", str(workspace), "--new"]), 0)

            lines = log_path.read_text(encoding="utf-8").strip().splitlines()
            run_lines = [line for line in lines if line.startswith("run ")]

        self.assertEqual(len(run_lines), 2)
        self.assertNotIn("--session", run_lines[1])

    def test_fork_rewrites_thread_to_new_session(self) -> None:
        from codex2opencode.cli import main
        from codex2opencode.threading import make_thread_key

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            workspace = Path(temp_dir) / "workspace"
            bin_dir = Path(temp_dir) / "bin"
            workspace.mkdir()
            bin_dir.mkdir()
            fake_opencode = bin_dir / "opencode"
            fake_opencode.write_text(FAKE_OPENCODE, encoding="utf-8")
            fake_opencode.chmod(0o755)

            env = {
                "CODEX2OPENCODE_HOME": str(state_root),
                "CODEX2OPENCODE_OPENCODE_BIN": str(fake_opencode),
            }
            with mock.patch.dict(os.environ, env, clear=False), mock.patch("sys.stdout.write"):
                self.assertEqual(main(["ask", "--prompt", "one", "--workspace", str(workspace)]), 0)
                self.assertEqual(main(["ask", "--prompt", "fork", "--workspace", str(workspace), "--fork"]), 0)

            thread_key = make_thread_key(str(workspace), None)
            state_path = state_root / "threads" / f"{thread_key}.json"
            state = json.loads(state_path.read_text(encoding="utf-8"))

        self.assertEqual(state["opencode_session_id"], "ses_forked")
        self.assertEqual(state["last_run_mode"], "fork")

    def test_ask_records_nonzero_duration_in_run_artifact(self) -> None:
        from codex2opencode.cli import main
        from codex2opencode.threading import make_thread_key

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            workspace = Path(temp_dir) / "workspace"
            bin_dir = Path(temp_dir) / "bin"
            workspace.mkdir()
            bin_dir.mkdir()
            fake_opencode = bin_dir / "opencode"
            fake_opencode.write_text(FAKE_OPENCODE, encoding="utf-8")
            fake_opencode.chmod(0o755)

            env = {
                "CODEX2OPENCODE_HOME": str(state_root),
                "CODEX2OPENCODE_OPENCODE_BIN": str(fake_opencode),
                "OPENCODE_FAKE_SLEEP_MS": "50",
            }
            with mock.patch.dict(os.environ, env, clear=False), mock.patch("sys.stdout.write"):
                exit_code = main(["ask", "--prompt", "hello", "--workspace", str(workspace)])

            thread_key = make_thread_key(str(workspace), None)
            run_files = sorted((state_root / "runs" / thread_key).glob("*.json"))
            record = json.loads(run_files[0].read_text(encoding="utf-8"))

        self.assertEqual(exit_code, 0)
        self.assertGreater(record["duration_ms"], 0)

    def test_workspace_is_used_as_opencode_working_directory(self) -> None:
        from codex2opencode.cli import main

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            workspace = Path(temp_dir) / "workspace"
            bin_dir = Path(temp_dir) / "bin"
            trace_log = Path(temp_dir) / "trace.log"
            workspace.mkdir()
            bin_dir.mkdir()
            fake_opencode = bin_dir / "opencode"
            fake_opencode.write_text(FAKE_OPENCODE, encoding="utf-8")
            fake_opencode.chmod(0o755)

            env = {
                "CODEX2OPENCODE_HOME": str(state_root),
                "CODEX2OPENCODE_OPENCODE_BIN": str(fake_opencode),
                "OPENCODE_FAKE_TRACE_LOG": str(trace_log),
            }
            with mock.patch.dict(os.environ, env, clear=False), mock.patch("sys.stdout.write"):
                exit_code = main(["ask", "--prompt", "hello", "--workspace", str(workspace)])

            trace_lines = trace_log.read_text(encoding="utf-8").strip().splitlines()

        self.assertEqual(exit_code, 0)
        self.assertEqual(
            trace_lines,
            [
                f"run|{workspace.resolve()}",
                f"export|{workspace.resolve()}",
                f"--version|{workspace.resolve()}",
            ],
        )

    def test_ask_accepts_export_output_with_banner_prefix(self) -> None:
        from codex2opencode.cli import main
        from codex2opencode.threading import make_thread_key

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            workspace = Path(temp_dir) / "workspace"
            bin_dir = Path(temp_dir) / "bin"
            workspace.mkdir()
            bin_dir.mkdir()
            fake_opencode = bin_dir / "opencode"
            fake_opencode.write_text(FAKE_OPENCODE, encoding="utf-8")
            fake_opencode.chmod(0o755)

            env = {
                "CODEX2OPENCODE_HOME": str(state_root),
                "CODEX2OPENCODE_OPENCODE_BIN": str(fake_opencode),
                "OPENCODE_FAKE_EXPORT_BANNER": "1",
            }
            with mock.patch.dict(os.environ, env, clear=False), mock.patch("sys.stdout.write"):
                exit_code = main(["ask", "--prompt", "hello", "--workspace", str(workspace)])

            thread_key = make_thread_key(str(workspace), None)
            state_path = state_root / "threads" / f"{thread_key}.json"
            state = json.loads(state_path.read_text(encoding="utf-8"))

        self.assertEqual(exit_code, 0)
        self.assertEqual(state["last_status"], "ok")
