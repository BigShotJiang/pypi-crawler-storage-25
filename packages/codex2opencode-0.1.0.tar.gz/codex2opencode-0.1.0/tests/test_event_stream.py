import unittest


class EventStreamTest(unittest.TestCase):
    def test_collects_text_and_session_id(self) -> None:
        from codex2opencode.event_stream import parse_event_lines

        lines = [
            '{"type":"step_start","sessionID":"ses_123","part":{"type":"step-start"}}\n',
            '{"type":"text","sessionID":"ses_123","part":{"type":"text","text":"Hello"}}\n',
            '{"type":"text","sessionID":"ses_123","part":{"type":"text","text":" world"}}\n',
        ]

        summary = parse_event_lines(lines)

        self.assertEqual(summary.session_id, "ses_123")
        self.assertEqual(summary.text_output, "Hello world")

    def test_records_malformed_lines(self) -> None:
        from codex2opencode.event_stream import parse_event_lines

        summary = parse_event_lines(["not-json\n"])
        self.assertEqual(summary.malformed_lines, 1)

    def test_missing_session_id_is_detectable(self) -> None:
        from codex2opencode.event_stream import parse_event_lines

        summary = parse_event_lines(['{"type":"text","part":{"type":"text","text":"ok"}}\n'])
        self.assertIsNone(summary.session_id)

    def test_non_dict_json_is_malformed(self) -> None:
        from codex2opencode.event_stream import parse_event_lines

        summary = parse_event_lines(["[]\n", "null\n", '"x"\n'])
        self.assertEqual(summary.malformed_lines, 3)
        self.assertEqual(summary.event_counts, {})

    def test_event_counts_are_recorded(self) -> None:
        from codex2opencode.event_stream import parse_event_lines

        summary = parse_event_lines(
            [
                '{"type":"text","sessionID":"ses_456","part":{"type":"text","text":"a"}}\n',
                '{"type":"step_start","sessionID":"ses_456","part":{"type":"step-start"}}\n',
                '{"type":"text","sessionID":"ses_456","part":{"type":"text","text":"b"}}\n',
            ]
        )

        self.assertEqual(summary.event_counts, {"text": 2, "step_start": 1})

    def test_malformed_part_does_not_crash(self) -> None:
        from codex2opencode.event_stream import parse_event_lines

        summary = parse_event_lines(
            ['{"type":"text","sessionID":"ses_789","part":["nope"]}\n']
        )

        self.assertEqual(summary.text_output, "")
