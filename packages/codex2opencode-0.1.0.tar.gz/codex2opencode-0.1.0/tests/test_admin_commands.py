import json
import os
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

from tests.test_ask_flow_mock import FAKE_OPENCODE


ROOT = Path(__file__).resolve().parents[1]
BRIDGE = ROOT / "bridge"
if str(BRIDGE) not in sys.path:
    sys.path.insert(0, str(BRIDGE))


class AdminCommandsTest(unittest.TestCase):
    def _make_fake_opencode(self, temp_dir: str) -> tuple[Path, Path, Path]:
        state_root = Path(temp_dir) / "state"
        workspace = Path(temp_dir) / "workspace"
        bin_dir = Path(temp_dir) / "bin"
        workspace.mkdir()
        bin_dir.mkdir()
        fake_opencode = bin_dir / "opencode"
        fake_opencode.write_text(FAKE_OPENCODE, encoding="utf-8")
        fake_opencode.chmod(0o755)
        return state_root, workspace, fake_opencode

    def test_doctor_reports_ok_when_opencode_is_available(self) -> None:
        from codex2opencode.cli import main

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root, workspace, fake_opencode = self._make_fake_opencode(temp_dir)
            env = {
                "CODEX2OPENCODE_HOME": str(state_root),
                "CODEX2OPENCODE_OPENCODE_BIN": str(fake_opencode),
            }
            with mock.patch.dict(os.environ, env, clear=False), mock.patch("sys.stdout.write"):
                self.assertEqual(main(["ask", "--prompt", "hello", "--workspace", str(workspace)]), 0)

            writes: list[str] = []
            with mock.patch.dict(os.environ, env, clear=False), mock.patch("sys.stdout.write", side_effect=writes.append):
                exit_code = main(["doctor", "--workspace", str(workspace)])

            payload = json.loads("".join(writes))

        self.assertEqual(exit_code, 0)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["opencode"]["status"], "ok")
        self.assertEqual(payload["opencode_debug"]["paths"]["status"], "ok")
        self.assertEqual(payload["opencode_debug"]["config"]["status"], "ok")
        self.assertEqual(payload["thread_state"]["status"], "ok")
        self.assertTrue(payload["thread_state"]["session_verified"])

    def test_doctor_returns_nonzero_when_opencode_is_unavailable(self) -> None:
        from codex2opencode.cli import main

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            workspace = Path(temp_dir) / "workspace"
            workspace.mkdir()
            env = {
                "CODEX2OPENCODE_HOME": str(state_root),
                "CODEX2OPENCODE_OPENCODE_BIN": str(Path(temp_dir) / "missing-opencode"),
            }
            writes: list[str] = []
            with mock.patch.dict(os.environ, env, clear=False), mock.patch("sys.stdout.write", side_effect=writes.append):
                exit_code = main(["doctor", "--workspace", str(workspace)])

            payload = json.loads("".join(writes))

        self.assertNotEqual(exit_code, 0)
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["opencode"]["status"], "error")

    def test_doctor_reports_orphaned_thread_state(self) -> None:
        from codex2opencode.cli import main

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root, workspace, fake_opencode = self._make_fake_opencode(temp_dir)
            env = {
                "CODEX2OPENCODE_HOME": str(state_root),
                "CODEX2OPENCODE_OPENCODE_BIN": str(fake_opencode),
            }
            with mock.patch.dict(os.environ, env, clear=False), mock.patch("sys.stdout.write"):
                self.assertEqual(main(["ask", "--prompt", "hello", "--workspace", str(workspace)]), 0)

            writes: list[str] = []
            orphan_env = dict(env)
            orphan_env["OPENCODE_FAKE_MISSING_EXPORT"] = "ses_new"
            with mock.patch.dict(os.environ, orphan_env, clear=False), mock.patch("sys.stdout.write", side_effect=writes.append):
                exit_code = main(["doctor", "--workspace", str(workspace)])

            payload = json.loads("".join(writes))

        self.assertNotEqual(exit_code, 0)
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["thread_state"]["status"], "orphaned")
        self.assertFalse(payload["thread_state"]["session_verified"])

    def test_status_command_on_missing_thread_returns_nonzero(self) -> None:
        from codex2opencode.cli import main

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            workspace = Path(temp_dir) / "workspace"
            workspace.mkdir()
            env = {"CODEX2OPENCODE_HOME": str(state_root)}
            stderr_writes: list[str] = []
            with mock.patch.dict(os.environ, env, clear=False), mock.patch("sys.stderr.write", side_effect=stderr_writes.append):
                exit_code = main(["status", "--workspace", str(workspace)])

        self.assertNotEqual(exit_code, 0)
        self.assertIn("No thread state found", "".join(stderr_writes))

    def test_forget_command_removes_thread_file_and_deletes_session(self) -> None:
        from codex2opencode.cli import main
        from codex2opencode.threading import make_thread_key

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root, workspace, fake_opencode = self._make_fake_opencode(temp_dir)
            log_path = Path(temp_dir) / "opencode.log"
            env = {
                "CODEX2OPENCODE_HOME": str(state_root),
                "CODEX2OPENCODE_OPENCODE_BIN": str(fake_opencode),
                "OPENCODE_FAKE_LOG": str(log_path),
            }
            with mock.patch.dict(os.environ, env, clear=False), mock.patch("sys.stdout.write"):
                self.assertEqual(main(["ask", "--prompt", "hello", "--workspace", str(workspace)]), 0)

            thread_key = make_thread_key(str(workspace), None)
            state_path = state_root / "threads" / f"{thread_key}.json"
            lock_path = state_root / "threads" / f"{thread_key}.lock"
            lock_path.touch()

            with mock.patch.dict(os.environ, env, clear=False):
                exit_code = main(["forget", "--workspace", str(workspace)])

            log_lines = log_path.read_text(encoding="utf-8").splitlines()

        self.assertEqual(exit_code, 0)
        self.assertFalse(state_path.exists())
        self.assertFalse(lock_path.exists())
        self.assertIn("session delete ses_new", log_lines)

    def test_forget_succeeds_when_remote_session_is_missing(self) -> None:
        from codex2opencode.cli import main
        from codex2opencode.threading import make_thread_key

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root, workspace, fake_opencode = self._make_fake_opencode(temp_dir)
            env = {
                "CODEX2OPENCODE_HOME": str(state_root),
                "CODEX2OPENCODE_OPENCODE_BIN": str(fake_opencode),
            }
            with mock.patch.dict(os.environ, env, clear=False), mock.patch("sys.stdout.write"):
                self.assertEqual(main(["ask", "--prompt", "hello", "--workspace", str(workspace)]), 0)

            stderr_writes: list[str] = []
            missing_env = dict(env)
            missing_env["OPENCODE_FAKE_MISSING_DELETE"] = "ses_new"
            with mock.patch.dict(os.environ, missing_env, clear=False), mock.patch("sys.stderr.write", side_effect=stderr_writes.append):
                exit_code = main(["forget", "--workspace", str(workspace)])

            thread_key = make_thread_key(str(workspace), None)
            state_path = state_root / "threads" / f"{thread_key}.json"

        self.assertEqual(exit_code, 0)
        self.assertFalse(state_path.exists())
        self.assertIn("Session not found: ses_new", "".join(stderr_writes))

    def test_gc_removes_old_thread_files(self) -> None:
        from codex2opencode.cli import main

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            thread_key = "deadbeef"
            state_path = state_root / "threads" / f"{thread_key}.json"
            lock_path = state_root / "threads" / f"{thread_key}.lock"
            run_dir = state_root / "runs" / thread_key
            run_file = run_dir / "record.json"
            for path in (state_path.parent, run_dir):
                path.mkdir(parents=True, exist_ok=True)
            state_path.write_text("{}", encoding="utf-8")
            lock_path.write_text("", encoding="utf-8")
            run_file.write_text("{}", encoding="utf-8")

            old_time = time.time() - (10 * 24 * 60 * 60)
            os.utime(state_path, (old_time, old_time))
            os.utime(lock_path, (old_time, old_time))
            os.utime(run_file, (old_time, old_time))
            os.utime(run_dir, (old_time, old_time))

            env = {"CODEX2OPENCODE_HOME": str(state_root)}
            with mock.patch.dict(os.environ, env, clear=False):
                exit_code = main(["gc", "--max-age-days", "7"])

        self.assertEqual(exit_code, 0)
        self.assertFalse(state_path.exists())
        self.assertFalse(lock_path.exists())
        self.assertFalse(run_dir.exists())

    def test_gc_skips_locked_threads(self) -> None:
        from codex2opencode.cli import main

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            thread_key = "lockedthread"
            state_path = state_root / "threads" / f"{thread_key}.json"
            lock_path = state_root / "threads" / f"{thread_key}.lock"
            run_dir = state_root / "runs" / thread_key
            run_file = run_dir / "record.json"
            ready_path = Path(temp_dir) / "lock-ready"
            for path in (state_path.parent, run_dir):
                path.mkdir(parents=True, exist_ok=True)
            state_path.write_text("{}", encoding="utf-8")
            lock_path.write_text("", encoding="utf-8")
            run_file.write_text("{}", encoding="utf-8")

            old_time = time.time() - (10 * 24 * 60 * 60)
            for path in (state_path, lock_path, run_file, run_dir):
                os.utime(path, (old_time, old_time))

            holder = subprocess.Popen(
                [
                    sys.executable,
                    "-c",
                    (
                        "import fcntl, pathlib, sys, time; "
                        "path = pathlib.Path(sys.argv[1]); "
                        "ready = pathlib.Path(sys.argv[2]); "
                        "handle = path.open('a+', encoding='utf-8'); "
                        "fcntl.flock(handle.fileno(), fcntl.LOCK_EX); "
                        "ready.write_text('ready', encoding='utf-8'); "
                        "time.sleep(1.5)"
                    ),
                    str(lock_path),
                    str(ready_path),
                ],
            )
            try:
                for _ in range(20):
                    if ready_path.exists():
                        break
                    time.sleep(0.05)
                env = {"CODEX2OPENCODE_HOME": str(state_root)}
                with mock.patch.dict(os.environ, env, clear=False):
                    exit_code = main(["gc", "--max-age-days", "7"])
                state_exists = state_path.exists()
                lock_exists = lock_path.exists()
                run_exists = run_dir.exists()
            finally:
                holder.wait(timeout=5)

        self.assertEqual(exit_code, 0)
        self.assertTrue(state_exists)
        self.assertTrue(lock_exists)
        self.assertTrue(run_exists)
