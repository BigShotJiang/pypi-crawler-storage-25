from pathlib import Path
import sys
import unittest


ROOT = Path(__file__).resolve().parents[1]
BRIDGE = ROOT / "bridge"
if str(BRIDGE) not in sys.path:
    sys.path.insert(0, str(BRIDGE))


class ThreadKeyTest(unittest.TestCase):
    def test_thread_key_is_stable_for_same_workspace_and_name(self) -> None:
        from codex2opencode.threading import make_thread_key

        self.assertEqual(make_thread_key("/tmp/project", None), make_thread_key("/tmp/project", None))
