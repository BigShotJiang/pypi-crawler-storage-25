import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BRIDGE = ROOT / "bridge"
if str(BRIDGE) not in sys.path:
    sys.path.insert(0, str(BRIDGE))


class SkillDocsTest(unittest.TestCase):
    def test_core_docs_exist(self) -> None:
        for relative_path in (
            "README.md",
            "CONTRIBUTING.md",
            "AGENTS.md",
            "ARCHITECTURE.md",
            "DEVELOPMENT.md",
            "skills/codex-to-opencode/SKILL.md",
        ):
            self.assertTrue((ROOT / relative_path).exists(), msg=relative_path)

    def test_readme_mentions_all_public_commands(self) -> None:
        readme = (ROOT / "README.md").read_text(encoding="utf-8")
        for command in ("ask", "status", "forget", "gc", "doctor"):
            self.assertIn(f"codex2opencode {command}", readme)
        self.assertIn("--fork", readme)
        self.assertIn("--title", readme)

    def test_skill_stays_thin_and_explicit(self) -> None:
        skill = (ROOT / "skills" / "codex-to-opencode" / "SKILL.md").read_text(encoding="utf-8")
        self.assertIn("Keep this skill thin.", skill)
        self.assertIn("Do not parse Opencode JSONL", skill)
        self.assertIn("codex2opencode ask", skill)
        self.assertIn("Do not treat bare `opencode` alone as a trigger", skill)
        self.assertIn("Do not treat bare `oc` alone as a trigger", skill)
        self.assertIn("问问oc", skill)
        self.assertIn("给oc看看", skill)

    def test_architecture_and_development_cover_diagnostics(self) -> None:
        architecture = (ROOT / "ARCHITECTURE.md").read_text(encoding="utf-8")
        development = (ROOT / "DEVELOPMENT.md").read_text(encoding="utf-8")
        self.assertIn("doctor", architecture)
        self.assertIn("orphaned", architecture)
        self.assertIn(".venv-release", development)
        self.assertIn("Trusted Publishing", (ROOT / "CONTRIBUTING.md").read_text(encoding="utf-8"))
