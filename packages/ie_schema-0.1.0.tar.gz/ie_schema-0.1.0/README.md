# Information Extraction Schema

A flexible input schema for [GLiNER](https://github.com/fastino-ai/GLiNER2) style multi-task models.

## Python

```
uv add ie_schema # or pip install
```

``` python
from dataclasses import dataclasses
from ie_schema import IESchema

@dataclass
class BusinessRecord:
    business_name: str
    address_line1: str
    address_line2: str | None
    email: str | None
    website: str | None
    phone: str | None

business_location_schema = IESchema.from(BusinessLocation)
print(business_location_schema)
```


## Rust

```
cargo add ie-schema
```
