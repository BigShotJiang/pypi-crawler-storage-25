from setuptools import setup

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='pbk',
    version='2.0.8', 
    author='prest0nn',
    description='Advanced Admin Panel Finder for Kali Linux',
    long_description=long_description,
    long_description_content_type="text/markdown",
    url='https://github.com/prest0nn/pbk',
    
    # 1. CHANGE THIS: We are using a package folder now, not a module
    packages=['pbk_pkg'], 
    
    install_requires=[
        'requests',
    ],
    
    include_package_data=True,
    
    # 2. CHANGE THIS: Tell it paths.txt is inside the package folder
    package_data={
        "pbk_pkg": ["paths.txt"],
    },
    
    # 3. CHANGE THIS: Point the command to the __init__.py inside the folder
    entry_points={
        'console_scripts': [
            'pbk=pbk_pkg.__init__:main',
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
