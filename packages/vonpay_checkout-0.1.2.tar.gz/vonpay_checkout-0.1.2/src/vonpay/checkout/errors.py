"""Error types for Von Payments Checkout SDK."""

from __future__ import annotations

from typing import Optional

from vonpay.checkout.types import ErrorCode, RateLimitInfo


class VonPayError(Exception):
    """API error with structured error code, fix suggestion, and docs link."""

    def __init__(
        self,
        status: int,
        error: str,
        code: ErrorCode,
        fix: str,
        docs: str,
        request_id: Optional[str] = None,
        rate_limit: Optional[RateLimitInfo] = None,
    ) -> None:
        super().__init__(error)
        self.status = status
        self.code = code
        self.fix = fix
        self.docs = docs
        self.request_id = request_id
        self.rate_limit = rate_limit
