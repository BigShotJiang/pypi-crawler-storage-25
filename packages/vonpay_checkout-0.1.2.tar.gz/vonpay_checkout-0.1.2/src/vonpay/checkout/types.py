"""Type definitions for Von Payments Checkout SDK."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Literal, Optional

ErrorCode = Literal[
    "auth_missing_bearer",
    "auth_invalid_key",
    "auth_key_expired",
    "auth_key_type_forbidden",
    "auth_merchant_inactive",
    "auth_service_unavailable",
    "merchant_not_onboarded",
    "session_not_found",
    "session_expired",
    "session_wrong_state",
    "session_integrity_error",
    "validation_error",
    "validation_missing_field",
    "validation_invalid_amount",
    "merchant_not_configured",
    "rate_limit_exceeded",
    "rate_limit_exceeded_per_key",
    "provider_unavailable",
    "provider_attestation_failed",
    "provider_charge_failed",
    "internal_error",
    "webhook_missing_signature",
    "webhook_invalid_signature",
    "webhook_not_configured",
    "origin_forbidden",
    "transaction_verification_failed",
    "unsupported_media_type",
]


@dataclass
class CheckoutSession:
    """Response from POST /v1/sessions."""

    id: str
    checkout_url: str
    expires_at: str


@dataclass
class SessionStatus:
    """Response from GET /v1/sessions/:id."""

    id: str
    status: str  # pending, succeeded, failed, expired
    mode: str
    merchant_id: str
    amount: int
    currency: str
    created_at: str
    updated_at: str
    expires_at: str
    country: Optional[str] = None
    description: Optional[str] = None
    collect_shipping: Optional[bool] = None
    shipping_address: Optional[Dict[str, str]] = None
    transaction_id: Optional[str] = None
    metadata: Optional[Dict[str, str]] = None


@dataclass
class DryRunResult:
    """Response from POST /v1/sessions?dry_run=true."""

    valid: bool
    warnings: List[str] = field(default_factory=list)


@dataclass
class WebhookEvent:
    """Parsed webhook payload."""

    event: str
    session_id: str
    merchant_id: str
    amount: int
    currency: str
    status: str
    timestamp: str
    transaction_id: Optional[str] = None
    error: Optional[str] = None
    failure_code: Optional[str] = None
    refund_id: Optional[str] = None
    metadata: Optional[Dict[str, str]] = None


@dataclass
class HealthStatus:
    """API health check result."""

    status: str
    latency_ms: float
    version: str


@dataclass
class RateLimitInfo:
    """Rate limit information from response headers."""

    limit: int
    remaining: int
    reset: int
    retry_after: Optional[int] = None
