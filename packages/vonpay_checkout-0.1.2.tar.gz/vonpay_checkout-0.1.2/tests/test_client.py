"""Tests for Von Payments Checkout Python SDK."""

import hashlib
import hmac as hmac_mod
import json
import time

import pytest

from vonpay.checkout import VonPayCheckout, VonPayError


class TestConstructor:
    def test_accepts_valid_test_key(self):
        client = VonPayCheckout("vp_sk_test_abc123def456")
        assert client is not None

    def test_accepts_valid_live_key(self):
        client = VonPayCheckout("vp_sk_live_abc123def456")
        assert client is not None

    def test_accepts_publishable_key(self):
        client = VonPayCheckout("vp_pk_test_abc123def456")
        assert client is not None

    def test_rejects_empty_key(self):
        with pytest.raises(ValueError, match="API key is required"):
            VonPayCheckout("")

    def test_rejects_invalid_prefix(self):
        with pytest.raises(ValueError, match="Invalid API key format"):
            VonPayCheckout("sk_live_bad_prefix")


class TestWebhookVerification:
    SECRET = "vp_sk_test_webhook_secret_key"

    def _sign(self, payload: str) -> str:
        return hmac_mod.new(
            self.SECRET.encode(), payload.encode(), hashlib.sha256
        ).hexdigest()

    def test_verify_valid_signature(self):
        payload = '{"event":"session.succeeded"}'
        sig = self._sign(payload)
        client = VonPayCheckout("vp_sk_test_abc123def456")
        assert client.webhooks.verify_signature(payload, sig, self.SECRET)

    def test_reject_invalid_signature(self):
        client = VonPayCheckout("vp_sk_test_abc123def456")
        assert not client.webhooks.verify_signature(
            '{"event":"session.succeeded"}', "bad" * 16, self.SECRET
        )

    def test_reject_tampered_payload(self):
        payload = '{"event":"session.succeeded","amount":1499}'
        sig = self._sign(payload)
        tampered = '{"event":"session.succeeded","amount":9999}'
        client = VonPayCheckout("vp_sk_test_abc123def456")
        assert not client.webhooks.verify_signature(tampered, sig, self.SECRET)

    def test_reject_non_hex_signature(self):
        client = VonPayCheckout("vp_sk_test_abc123def456")
        assert not client.webhooks.verify_signature(
            '{"event":"test"}', "not-hex-at-all!", self.SECRET
        )


class TestConstructEvent:
    SECRET = "vp_sk_test_webhook_secret_key"

    def _sign(self, payload: str) -> str:
        return hmac_mod.new(
            self.SECRET.encode(), payload.encode(), hashlib.sha256
        ).hexdigest()

    def test_parses_valid_event(self):
        event_data = {
            "event": "session.succeeded",
            "sessionId": "session_abc",
            "merchantId": "merchant_123",
            "amount": 1499,
            "currency": "USD",
            "status": "succeeded",
            "transactionId": "txn_xyz",
            "timestamp": "2026-04-14T10:00:00Z",
        }
        payload = json.dumps(event_data)
        sig = self._sign(payload)
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

        client = VonPayCheckout("vp_sk_test_abc123def456")
        result = client.webhooks.construct_event(payload, sig, self.SECRET, now)
        assert result.event == "session.succeeded"
        assert result.session_id == "session_abc"
        assert result.amount == 1499
        assert result.transaction_id == "txn_xyz"

    def test_rejects_expired_timestamp(self):
        payload = '{"event":"session.succeeded"}'
        sig = self._sign(payload)
        old = "2020-01-01T00:00:00Z"

        client = VonPayCheckout("vp_sk_test_abc123def456")
        with pytest.raises(VonPayError) as exc_info:
            client.webhooks.construct_event(payload, sig, self.SECRET, old)
        assert exc_info.value.code == "webhook_invalid_signature"
        assert "timestamp" in str(exc_info.value)

    def test_rejects_bad_signature(self):
        payload = '{"event":"session.succeeded"}'
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

        client = VonPayCheckout("vp_sk_test_abc123def456")
        with pytest.raises(VonPayError) as exc_info:
            client.webhooks.construct_event(
                payload, "a" * 64, self.SECRET, now
            )
        assert exc_info.value.code == "webhook_invalid_signature"


class TestReturnSignature:
    SECRET = "ss_test_session_signing_secret"

    def _sign_return(self, params: dict) -> str:
        data = ".".join([
            params["session"],
            params["status"],
            params["amount"],
            params["currency"],
            params.get("transaction_id", ""),
        ])
        return hmac_mod.new(
            self.SECRET.encode(), data.encode(), hashlib.sha256
        ).hexdigest()

    def test_valid_signature(self):
        params = {
            "session": "session_abc",
            "status": "succeeded",
            "amount": "1499",
            "currency": "USD",
            "transaction_id": "txn_xyz",
        }
        params["sig"] = self._sign_return(params)
        assert VonPayCheckout.verify_return_signature(params, self.SECRET)

    def test_valid_without_transaction_id(self):
        params = {
            "session": "session_abc",
            "status": "succeeded",
            "amount": "1499",
            "currency": "USD",
        }
        params["sig"] = self._sign_return(params)
        assert VonPayCheckout.verify_return_signature(params, self.SECRET)

    def test_rejects_missing_sig(self):
        params = {"session": "abc", "status": "ok", "amount": "1", "currency": "USD"}
        assert not VonPayCheckout.verify_return_signature(params, self.SECRET)

    def test_rejects_wrong_secret(self):
        params = {
            "session": "session_abc",
            "status": "succeeded",
            "amount": "1499",
            "currency": "USD",
        }
        params["sig"] = self._sign_return(params)
        assert not VonPayCheckout.verify_return_signature(params, "wrong_secret")

    def test_rejects_tampered_amount(self):
        params = {
            "session": "session_abc",
            "status": "succeeded",
            "amount": "1499",
            "currency": "USD",
        }
        params["sig"] = self._sign_return(params)
        params["amount"] = "9999"
        assert not VonPayCheckout.verify_return_signature(params, self.SECRET)
