# vonpay-checkout

Python SDK for the [Von Payments Checkout API](https://docs.vonpay.com). Create hosted checkout sessions, verify webhook signatures, and validate signed return redirects.

## Install

```bash
pip install vonpay-checkout
```

**Requires:** Python 3.9+, httpx 0.27+

## Quick start

```python
from vonpay.checkout import VonPayCheckout, VonPayError

client = VonPayCheckout("vp_sk_test_...")

session = client.sessions.create(
    amount=1499,
    currency="USD",
    country="US",
    success_url="https://example.com/order/123/confirm",
)

print(session.checkout_url)
# https://checkout.vonpay.com/checkout?session=vp_cs_test_...
```

## Features

- **Typed session / webhook / error objects** — full `CheckoutSession`, `SessionStatus`, `WebhookEvent`, `VonPayError` types.
- **Webhook verification** — HMAC-SHA256 with ±5 minute timestamp replay protection.
- **Signed return URL verification (v1 + v2)** — `verify_return_signature()` supports both legacy v1 signatures and v2 signatures that bind `successUrl`, `keyMode`, and `iat` freshness.
- **Auto-retry** — exponential backoff on 429 / 5xx with `Retry-After` header support.
- **Request ID tracing** — every response includes `X-Request-Id` for support tickets.

## Documentation

- [Python SDK reference](https://docs.vonpay.com/sdks/python-sdk)
- [API reference](https://docs.vonpay.com/reference/api)
- [Quickstart](https://docs.vonpay.com/quickstart)

## License

MIT
