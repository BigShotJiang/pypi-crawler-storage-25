import gzip, os, re, unicodedata
from math import log


__version__ = '0.1.1'


_PKG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'wordninja')
LANGUAGES = {
    'en':        os.path.join(_PKG_DIR, 'wordninja_words.txt.gz'),
    'es':        os.path.join(_PKG_DIR, 'es_words.txt.gz'),
    'fr':        os.path.join(_PKG_DIR, 'fr_words.txt.gz'),
    'de':        os.path.join(_PKG_DIR, 'de_words.txt.gz'),
    'it':        os.path.join(_PKG_DIR, 'it_words.txt.gz'),
    'pt':        os.path.join(_PKG_DIR, 'pt_words.txt.gz'),
    'ru':        os.path.join(_PKG_DIR, 'ru_words.txt.gz'),
    'he':        os.path.join(_PKG_DIR, 'he_words.txt.gz'),
    'zh':        os.path.join(_PKG_DIR, 'zh_words.txt.gz'),
    'ja':        os.path.join(_PKG_DIR, 'ja_words.txt.gz'),
    'ko':        os.path.join(_PKG_DIR, 'ko_words.txt.gz'),
    'vi':        os.path.join(_PKG_DIR, 'vi_words.txt.gz'),
    'vi-no-dia': os.path.join(_PKG_DIR, 'vi_words_no_diacritics.txt.gz'),
}
LANGUAGE_NAMES = {
    'en':        'English',
    'es':        'Spanish',
    'fr':        'French',
    'de':        'German',
    'it':        'Italian',
    'pt':        'Portuguese',
    'ru':        'Russian',
    'he':        'Hebrew',
    'zh':        'Chinese (Simplified)',
    'ja':        'Japanese',
    'ko':        'Korean',
    'vi':        'Vietnamese',
    'vi-no-dia': 'Vietnamese (no diacritics)',
}


def supported_languages():
    """Return the list of language codes that ``split(s, lang=...)`` accepts."""
    return list(LANGUAGES.keys())


# I did not author this code, only tweaked it from:
# http://stackoverflow.com/a/11642687/2449774
# Thanks Generic Human!


# Modifications by Scott Randal (Genesys)
#
# 1. Preserve original character case after splitting
# 2. Avoid splitting every post-digit character in a mixed string (e.g. 'win32intel')
# 3. Avoid splitting digit sequences
# 4. Handle input containing apostrophes (for possessives and contractions)
#
# Wordlist changes:
# Change 2 required adding single digits to the wordlist
# Change 4 required the following wordlist additions:
#   's
#   '
#   <list of contractions>


class LanguageModel(object):
  def __init__(self, word_file_or_lang):
    # Accepts either a path to a .gz word list, or a language code like 'en', 'vi'.
    word_file = LANGUAGES.get(word_file_or_lang, word_file_or_lang)
    self._lang = word_file_or_lang if word_file_or_lang in LANGUAGES else None
    # Build a cost dictionary, assuming Zipf's law and cost = -math.log(probability).
    with gzip.open(word_file) as f:
      words = f.read().decode().split()
    self._wordcost = dict((k, log((i+1)*log(len(words)))) for i,k in enumerate(words))
    self._maxword = max(len(x) for x in words)


  def split(self, s):
    """Uses dynamic programming to infer the location of spaces in a string without spaces."""
    # NFC-normalize for any language with combining marks. The dicts are built
    # in NFC, so NFD inputs (e.g. macOS clipboard) would otherwise fall apart.
    if self._lang is not None:
      s = unicodedata.normalize('NFC', s)
      if self._lang == 'vi-no-dia':
        s = s.replace('đ', 'd').replace('Đ', 'D')
        s = ''.join(c for c in unicodedata.normalize('NFD', s)
                    if unicodedata.category(c) != 'Mn')
    punctuations = _SPLIT_RE.findall(s)
    texts = _SPLIT_RE.split(s)
    assert len(punctuations) + 1 == len(texts)
    new_texts = [self._split(x) for x in texts]
    for i, punctuation in enumerate(punctuations):
      new_texts.insert(2*i+1, punctuation)
    return [item for sublist in new_texts for item in sublist]


  def _split(self, s):
    # Find the best match for the i first characters, assuming cost has
    # been built for the i-1 first characters.
    # Returns a pair (match_cost, match_length).
    def best_match(i):
      candidates = enumerate(reversed(cost[max(0, i-self._maxword):i]))
      return min((c + self._wordcost.get(s[i-k-1:i].lower(), 9e999), k+1) for k,c in candidates)

    # Build the cost array.
    cost = [0]
    for i in range(1,len(s)+1):
      c,k = best_match(i)
      cost.append(c)

    # Backtrack to recover the minimal-cost string.
    out = []
    i = len(s)
    while i>0:
      c,k = best_match(i)
      assert c == cost[i]
      # Apostrophe and digit handling (added by Genesys)
      newToken = True
      if not s[i-k:i] == "'": # ignore a lone apostrophe
        if len(out) > 0:
          # re-attach split 's and split digits
          if out[-1] == "'s" or (s[i-1].isdigit() and out[-1][0].isdigit()): # digit followed by digit
            out[-1] = s[i-k:i] + out[-1] # combine current token with previous token
            newToken = False
      # (End of Genesys addition)

      if newToken:
        out.append(s[i-k:i])

      i -= k

    return reversed(out)

DEFAULT_LANGUAGE_MODEL = LanguageModel('en')
_SPLIT_RE = re.compile(r"\s+")
_LANG_CACHE = {'en': DEFAULT_LANGUAGE_MODEL}

def split(s, lang=None):
  """Split a no-spaces string into tokens. Pass lang='en' or 'vi' or 'vi-no-dia'
  to use a built-in language model. Defaults to English."""
  if lang is None:
    return DEFAULT_LANGUAGE_MODEL.split(s)
  if lang not in _LANG_CACHE:
    if lang not in LANGUAGES:
      raise ValueError(f'unknown language {lang!r}; use one of {list(LANGUAGES)} or pass a custom LanguageModel')
    _LANG_CACHE[lang] = LanguageModel(lang)
  return _LANG_CACHE[lang].split(s)


