"""Frames for receiving network setup from gateway."""
from pyvlx.const import Command, DHCPParameter

from .frame import FrameBase


class FrameGetNetworkSetupRequest(FrameBase):
    """Frame for requesting network setup."""

    PAYLOAD_LEN = 0

    def __init__(self) -> None:
        """Init Frame."""
        super().__init__(Command.GW_GET_NETWORK_SETUP_REQ)


class FrameGetNetworkSetupConfirmation(FrameBase):
    """Frame for confirmation for get network setup requests."""

    PAYLOAD_LEN = 13

    def __init__(self, ipaddress: bytes = bytes(4), netmask: bytes = bytes(4), gateway: bytes = bytes(4),
                 dhcp: DHCPParameter = DHCPParameter.DISABLE):
        """Init Frame."""
        super().__init__(Command.GW_GET_NETWORK_SETUP_CFM)
        self._ipaddress = ipaddress
        self._netmask = netmask
        self._gateway = gateway
        self.dhcp = dhcp

    @property
    def ipaddress(self) -> str:
        """Return ipaddress as human readable string."""
        return ".".join(str(c) for c in self._ipaddress)

    @property
    def netmask(self) -> str:
        """Return ipaddress as human readable string."""
        return ".".join(str(c) for c in self._netmask)

    @property
    def gateway(self) -> str:
        """Return ipaddress as human readable string."""
        return ".".join(str(c) for c in self._gateway)

    def get_payload(self) -> bytes:
        """Return Payload."""
        payload = self._ipaddress
        payload += self._netmask
        payload += self._gateway
        payload += bytes(self.dhcp.value)
        return payload

    def from_payload(self, payload: bytes) -> None:
        """Init frame from binary data."""
        self._ipaddress = payload[0:4]
        self._netmask = payload[4:8]
        self._gateway = payload[8:12]
        self.dhcp = DHCPParameter(payload[12])

    def __str__(self) -> str:
        """Return human readable string."""
        return f'<{type(self).__name__} ipaddress="{self.ipaddress}" netmask="{self.netmask}" gateway="{self.gateway}" dhcp="{self.dhcp}"/>'
