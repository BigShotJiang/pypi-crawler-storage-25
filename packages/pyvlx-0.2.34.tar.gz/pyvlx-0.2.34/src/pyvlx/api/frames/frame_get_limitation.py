"""Module for get limitation status classes."""
from typing import List

from pyvlx.const import Command, LimitationType, Originator, Priority

from .frame import FrameBase


class FrameGetLimitationStatus(FrameBase):
    """Frame for requesting limitation status."""

    PAYLOAD_LEN = 25

    def __init__(self,
                 node_ids: List[int] | None = None,
                 session_id: int | None = None,
                 limitation_type: LimitationType = LimitationType.MIN_LIMITATION):
        """Init Frame."""
        super().__init__(Command.GW_GET_LIMITATION_STATUS_REQ)
        self.session_id = session_id
        self.originator = Originator.USER
        self.priority = Priority.USER_LEVEL_2
        self.node_ids = node_ids if node_ids is not None else []

        self.parameter_id = 0  # Main Parameter
        self.limitation_type = limitation_type

    def get_payload(self) -> bytes:
        """Return Payload."""
        assert self.session_id is not None
        ret = bytes([self.session_id >> 8 & 255, self.session_id & 255])
        ret += bytes([len(self.node_ids)])  # index array count
        ret += bytes(self.node_ids) + bytes(20 - len(self.node_ids))
        ret += bytes([self.parameter_id])
        ret += bytes([self.limitation_type.value])
        return ret

    def __str__(self) -> str:
        """Return human readable string."""
        return f'<{type(self).__name__} node_ids="{self.node_ids}" ' \
               f'session_id="{self.session_id}" originator="{self.originator}" limitation_type="{self.limitation_type.name}" />'


class FrameGetLimitationStatusConfirmation(FrameBase):
    """Frame for response for get limitation requests."""

    PAYLOAD_LEN = 3

    def __init__(self, session_id: int | None = None, data: int | None = None):
        """Init Frame."""
        super().__init__(Command.GW_GET_LIMITATION_STATUS_CFM)
        self.session_id = session_id
        self.data = data

    def get_payload(self) -> bytes:
        """Return Payload."""
        assert self.session_id is not None
        ret = bytes([self.session_id >> 8 & 255, self.session_id & 255])
        assert self.data is not None
        ret += bytes([self.data])
        return ret

    def from_payload(self, payload: bytes) -> None:
        """Init frame from binary data."""
        self.session_id = payload[0] * 256 + payload[1]
        self.data = payload[2]

    def __str__(self) -> str:
        """Return human readable string."""
        return f'<{type(self).__name__} session_id="{self.session_id}" status="{self.data}"/>'


class FrameGetLimitationStatusNotification(FrameBase):
    """Frame for notification of note information request."""

    PAYLOAD_LEN = 10

    def __init__(self) -> None:
        """Init Frame."""
        super().__init__(Command.GW_LIMITATION_STATUS_NTF)
        self.session_id: int | None = None
        self.node_id = 0
        self.parameter_id = 0
        self.min_value: bytes | None = None
        self.max_value: bytes | None = None
        self.limit_originator: Originator | None = None
        self.limit_time: int | None = None

    def get_payload(self) -> bytes:
        """Return Payload."""
        assert self.session_id is not None
        assert self.min_value is not None
        assert self.max_value is not None
        assert self.limit_originator is not None
        assert self.limit_time is not None
        payload = bytes([self.session_id >> 8 & 255, self.session_id & 255])
        payload += bytes([self.node_id])
        payload += bytes([self.parameter_id])
        payload += self.min_value
        payload += self.max_value
        payload += bytes([self.limit_originator.value])
        payload += bytes([self.limit_time])
        return payload

    def from_payload(self, payload: bytes) -> None:
        """Init frame from binary data."""
        self.session_id = payload[0] * 256 + payload[1]
        self.node_id = payload[2]
        self.parameter_id = payload[3]
        self.min_value = payload[4:6]
        self.max_value = payload[6:8]
        self.limit_originator = Originator(payload[8])
        self.limit_time = payload[9]

    def __str__(self) -> str:
        """Return human readable string."""
        return (
            f'<{type(self).__name__} node_id="{self.node_id}" session_id="{self.session_id}" min_value="{self.min_value!r}" '
            f'max_value="{self.max_value!r}" originator="{self.limit_originator}" limit_time="{self.limit_time}"/>'
        )
