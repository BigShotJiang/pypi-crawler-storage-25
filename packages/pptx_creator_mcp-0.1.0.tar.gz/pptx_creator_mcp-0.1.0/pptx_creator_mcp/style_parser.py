"""
Style tag parser for inline text styling.

Supports XML-like style tags in text:
    Hi this is <style color="orange" text-size="15" font-type="Roman">Kiro</style>

Attributes:
    - color: CSS color name or hex (#FF5733)
    - text-size: font size in points
    - font-type: font family name
    - bold: true/false
    - italic: true/false
    - underline: true/false
"""

import re
from dataclasses import dataclass, field
from pptx.util import Pt
from pptx.dml.color import RGBColor


# Common CSS color names to RGB
COLOR_MAP = {
    "white": "FFFFFF",
    "black": "000000",
    "red": "EF5350",
    "green": "66BB6A",
    "blue": "4FC3F7",
    "orange": "FFA726",
    "yellow": "FFEE58",
    "purple": "AB47BC",
    "cyan": "4FC3F7",
    "gray": "999999",
    "grey": "999999",
    "lightgray": "CCCCCC",
    "darkgray": "666666",
    "accent": "4FC3F7",
    "muted": "888888",
    "subtle": "999999",
}


@dataclass
class TextSegment:
    """A segment of text with optional styling."""
    text: str
    color: str | None = None
    font_size: float | None = None
    font_type: str | None = None
    bold: bool | None = None
    italic: bool | None = None
    underline: bool | None = None


def parse_color(color_str: str) -> RGBColor | None:
    """Parse a color string (name or hex) to RGBColor."""
    if not color_str:
        return None
    color_str = color_str.strip().lower()
    if color_str in COLOR_MAP:
        hex_val = COLOR_MAP[color_str]
    elif color_str.startswith("#"):
        hex_val = color_str.lstrip("#")
    else:
        hex_val = color_str
    try:
        if len(hex_val) == 6:
            return RGBColor(int(hex_val[0:2], 16), int(hex_val[2:4], 16), int(hex_val[4:6], 16))
    except (ValueError, IndexError):
        pass
    return None


def parse_style_tags(text: str) -> list[TextSegment]:
    """
    Parse text with <style> tags into segments.

    Example:
        "Hello <style color='orange' text-size='20'>World</style> end"
        -> [TextSegment("Hello "), TextSegment("World", color="orange", font_size=20), TextSegment(" end")]
    """
    pattern = r'<style\s+(.*?)>(.*?)</style>'
    segments: list[TextSegment] = []
    last_end = 0

    for match in re.finditer(pattern, text, re.DOTALL):
        # Add plain text before this tag
        if match.start() > last_end:
            plain = text[last_end:match.start()]
            if plain:
                segments.append(TextSegment(text=plain))

        attrs_str = match.group(1)
        styled_text = match.group(2)

        # Parse attributes (supports both key=value and key="value")
        attrs = {}
        for attr_match in re.finditer(r'([\w-]+)\s*=\s*["\']?([^"\'>,\s]+)["\']?', attrs_str):
            attrs[attr_match.group(1).lower()] = attr_match.group(2)

        segment = TextSegment(text=styled_text)
        if "color" in attrs:
            segment.color = attrs["color"]
        if "text-size" in attrs:
            try:
                segment.font_size = float(attrs["text-size"])
            except ValueError:
                pass
        if "font-type" in attrs:
            segment.font_type = attrs["font-type"]
        if "bold" in attrs:
            segment.bold = attrs["bold"].lower() == "true"
        if "italic" in attrs:
            segment.italic = attrs["italic"].lower() == "true"
        if "underline" in attrs:
            segment.underline = attrs["underline"].lower() == "true"

        segments.append(segment)
        last_end = match.end()

    # Add remaining plain text
    if last_end < len(text):
        remaining = text[last_end:]
        if remaining:
            segments.append(TextSegment(text=remaining))

    # If no tags found, return the whole text as one segment
    if not segments:
        segments.append(TextSegment(text=text))

    return segments
