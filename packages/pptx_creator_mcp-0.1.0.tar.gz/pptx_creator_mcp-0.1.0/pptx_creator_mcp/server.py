"""
PPTX MCP Server - FastMCP server for creating professional presentations.

Provides a single tool `create_presentation` that accepts structured slide data
and generates a styled PPTX file matching a dark professional theme.
"""

import json
import os
from pathlib import Path
from fastmcp import FastMCP

from .slide_builder import create_presentation as _build_pptx
from .style_extractor import analyze_presentation as _analyze_pptx
from .slide_renderer import render_slides as _render_slides

mcp = FastMCP("pptx-creator")


@mcp.tool()
def create_presentation(
    slides: list[dict],
    output_dir: str,
    filename: str = "presentation.pptx",
) -> str:
    """
    Create a professional PPTX presentation from structured slide data.

    The presentation uses a dark gradient theme inspired by executive advisory decks.
    Each slide is defined by a type and its content. Text supports inline <style> tags
    for granular formatting control.

    Args:
        slides: List of slide objects. Each slide must have a "type" field.
            Common fields across all types:
                - type (required): Slide type. One of: "title", "content", "metrics",
                  "table", "quote", "two_column", "three_column", "bars", "summary", "image"
                - background: Background preset. One of: "bg_dark", "bg_accent",
                  "bg_highlight", "bg_impact". Default varies by type.
                - background_colors: Custom gradient as ["hex1", "hex2"] overriding preset.
                - background_image: Local file path to an image used as slide background
                  (stretched to fill). Overrides background and background_colors when set.
                - section_label: Small uppercase label above the title (e.g. "THE CONTEXT").

            Slide type schemas:

            "title" - Title/cover slide:
                - title: Main title text
                - subtitle: Subtitle text
                - footer: Footer text (e.g. "Company | Confidential | Date")

            "content" - Bullet point slide:
                - title: Slide title
                - bullets: List of bullet point strings
                - footer_text: Bottom text
                - image_path: Optional image (local path or URL) placed below bullets

            "metrics" - Big number cards (up to 3):
                - title: Slide title
                - metrics: List of {value, label, description?, color?}
                  color can be hex or theme key: "color_accent", "color_green", "color_orange", "color_red"
                - footer_text: Bottom text

            "table" - Data table:
                - title: Slide title
                - headers: List of column header strings
                - rows: List of lists (each inner list = one row of cell values)
                - highlight_rows: List of row indices (0-based) to highlight in green

            "quote" - Quote with attribution:
                - title: Slide title
                - quote: The quote text
                - attribution: Source attribution

            "two_column" - Two-column layout:
                - title: Slide title
                - left: {title?, text?, items?: list[str], card?: bool, image_path?: str}
                - right: {title?, text?, items?: list[str], card?: bool, image_path?: str}
                  Each column can include an image_path (local or URL) displayed in the column.

            "three_column" - Three card columns:
                - title: Slide title
                - columns: List of {title, subtitle?, text, footer?, accent_color?}
                - footer_text: Bottom text

            "bars" - Horizontal bar chart:
                - title: Slide title
                - bars: List of {label, value (numeric), display_value (str), color?}
                - footer_text: Bottom text

            "summary" - Summary with metric row:
                - title: Main summary text
                - metrics: List of {value, label, color?}
                - footer_text: Bottom text

            "image" - Dedicated image slide:
                - image_path: Local file path or URL (required)
                - title: Optional title above/over the image
                - caption: Optional caption below the image
                - image_mode: "centered" (default) or "full" (stretches to fill slide)

            INLINE STYLING:
            Any text field supports <style> tags for inline formatting:
                <style color="orange" text-size="20" font-type="Arial" bold="true">text</style>

            Attributes:
                - color: CSS name (red, green, blue, orange, accent, muted) or hex (#FF5733)
                - text-size: Font size in points
                - font-type: Font family name
                - bold: true/false
                - italic: true/false
                - underline: true/false

            Example: "Unlock <style color='green' text-size='36' bold='true'>€6.5bn</style> in profit"

        output_dir: Directory where the PPTX will be saved. A "generated-pptx" subdirectory
            will be created inside this directory.

        filename: Output filename. Default: "presentation.pptx"

    Returns:
        Absolute path to the generated PPTX file.
    """
    # Create output directory
    out_dir = Path(output_dir) / "generated-pptx"
    out_dir.mkdir(parents=True, exist_ok=True)

    output_path = out_dir / filename
    result_path = _build_pptx(slides, str(output_path))

    return f"Presentation created: {os.path.abspath(result_path)}"


@mcp.tool()
def analyze_presentation(pptx_path: str, auto_screenshot: bool = True) -> str:
    """
    Analyze an existing PPTX file and extract a complete shape-level style library.

    This tool performs deep extraction of every visual property from each slide:
    - Background type and colors (solid, gradient, image)
    - Shape positions, dimensions, fills, borders
    - Text formatting per run (font, size, color, bold/italic) — resolves theme-inherited styles
    - Table cell styling
    - Global color palette and font usage

    When a slide's extraction confidence is below 60%, the tool automatically
    renders a screenshot of that slide (tries LibreOffice, PowerPoint COM, or
    pure Python fallback) so the agent can visually analyze what couldn't be
    extracted programmatically.

    Args:
        pptx_path: Absolute path to the PPTX file to analyze.
        auto_screenshot: If True (default), automatically render PNG screenshots
            for slides with confidence < 60%. Screenshots are saved in a
            'screenshots' subdirectory next to the PPTX file.

    Returns:
        JSON string containing the full style library with:
        - slide_dimensions: Width and height in inches
        - global_palette: Most-used colors, fonts, and font sizes across all slides
        - slide_templates: Per-slide array with background, shapes (position, fill,
          line, text runs with styles), confidence score, needs_screenshot flag,
          and screenshot_path (if rendered)
        - overall_confidence_pct: Average confidence across all slides
        - slides_needing_screenshot: List of slide indices where extraction was
          insufficient (<60%)
        - screenshots: List of rendered screenshot info (slide_index, image_path, backend)
    """
    if not os.path.exists(pptx_path):
        return json.dumps({"error": f"File not found: {pptx_path}"})

    result = _analyze_pptx(pptx_path, auto_screenshot=auto_screenshot)
    return json.dumps(result, indent=2, default=str)


@mcp.tool()
def render_slide_screenshots(
    pptx_path: str,
    slide_indices: list[int] | None = None,
    output_dir: str | None = None,
    width: int = 1920,
) -> str:
    """
    Render PPTX slides as PNG images.

    Tries backends in order: LibreOffice headless → PowerPoint COM → Pure Python.
    Useful for visual inspection of slides or when analyze_presentation flags
    slides needing screenshots.

    Args:
        pptx_path: Absolute path to the PPTX file.
        slide_indices: List of 0-based slide indices to render. None = all slides.
        output_dir: Directory to save PNGs. Defaults to 'screenshots' next to the PPTX.
        width: Output image width in pixels (default 1920). Height auto-calculated.

    Returns:
        JSON with list of rendered slides: [{slide_index, image_path, backend}]
    """
    if not os.path.exists(pptx_path):
        return json.dumps({"error": f"File not found: {pptx_path}"})

    if output_dir is None:
        output_dir = str(Path(pptx_path).parent / "screenshots")

    results = _render_slides(pptx_path, output_dir, slide_indices, width)
    return json.dumps({"rendered": results, "count": len(results)}, indent=2)


def main():
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
