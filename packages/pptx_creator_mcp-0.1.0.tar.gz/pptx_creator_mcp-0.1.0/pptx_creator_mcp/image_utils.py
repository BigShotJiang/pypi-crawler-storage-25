"""
Image utilities for fetching and preparing images for PPTX slides.
Supports local file paths and URLs.
"""

import os
import tempfile
import urllib.request
import urllib.error
from io import BytesIO
from pathlib import Path
from PIL import Image


def resolve_image(image_path: str) -> BytesIO | None:
    """
    Resolve an image from a local path or URL into a BytesIO stream.

    Args:
        image_path: Local file path or HTTP(S) URL.

    Returns:
        BytesIO stream of the image, or None if resolution fails.
    """
    if not image_path:
        return None

    try:
        if image_path.startswith(("http://", "https://")):
            return _fetch_url(image_path)
        else:
            return _read_local(image_path)
    except Exception as e:
        print(f"[pptx-mcp] Warning: Could not resolve image '{image_path}': {e}")
        return None


def _fetch_url(url: str) -> BytesIO | None:
    """Download image from URL into BytesIO."""
    headers = {"User-Agent": "pptx-mcp-server/0.1"}
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = resp.read()
            # Validate it's actually an image
            buf = BytesIO(data)
            img = Image.open(buf)
            img.verify()
            buf.seek(0)
            return buf
    except (urllib.error.URLError, urllib.error.HTTPError, Exception) as e:
        print(f"[pptx-mcp] Warning: Failed to fetch URL '{url}': {e}")
        return None


def _read_local(file_path: str) -> BytesIO | None:
    """Read a local image file into BytesIO."""
    path = Path(file_path).expanduser().resolve()
    if not path.exists():
        print(f"[pptx-mcp] Warning: Image file not found: {path}")
        return None
    if not path.is_file():
        print(f"[pptx-mcp] Warning: Not a file: {path}")
        return None
    try:
        with open(path, "rb") as f:
            data = f.read()
        buf = BytesIO(data)
        img = Image.open(buf)
        img.verify()
        buf.seek(0)
        return buf
    except Exception as e:
        print(f"[pptx-mcp] Warning: Failed to read image '{path}': {e}")
        return None


def get_image_dimensions(image_stream: BytesIO) -> tuple[int, int]:
    """Get (width, height) in pixels from an image stream. Resets stream position."""
    pos = image_stream.tell()
    img = Image.open(image_stream)
    w, h = img.size
    image_stream.seek(pos)
    return w, h


def fit_image_dimensions(
    img_w: int, img_h: int,
    max_w_inches: float, max_h_inches: float,
    dpi: int = 96
) -> tuple[float, float]:
    """
    Calculate dimensions (in inches) to fit image within max bounds while preserving aspect ratio.

    Returns:
        (width_inches, height_inches)
    """
    aspect = img_w / img_h if img_h > 0 else 1.0
    # Try fitting to width first
    fit_w = max_w_inches
    fit_h = fit_w / aspect
    if fit_h > max_h_inches:
        fit_h = max_h_inches
        fit_w = fit_h * aspect
    return fit_w, fit_h
