"""
Cross-platform slide-to-image renderer.

Tries backends in order:
1. LibreOffice headless (macOS/Linux/Windows)
2. PowerPoint COM automation (Windows only)
3. Pure Python fallback (Pillow + python-pptx) — works everywhere

Exports individual slides as PNG images.
"""

import os
import sys
import shutil
import subprocess
import tempfile
import platform
from pathlib import Path
from io import BytesIO

from pptx import Presentation
from pptx.util import Emu
from pptx.enum.shapes import MSO_SHAPE_TYPE
from PIL import Image, ImageDraw, ImageFont


def render_slides(
    pptx_path: str,
    output_dir: str | None = None,
    slide_indices: list[int] | None = None,
    width: int = 1920,
) -> list[dict]:
    """
    Render PPTX slides to PNG images.

    Args:
        pptx_path: Path to the PPTX file.
        output_dir: Directory to save PNGs. Defaults to a temp directory.
        slide_indices: List of 0-based slide indices to render. None = all.
        width: Output image width in pixels (height auto-calculated from aspect ratio).

    Returns:
        List of dicts: [{"slide_index": int, "image_path": str, "backend": str}]
    """
    if output_dir is None:
        output_dir = tempfile.mkdtemp(prefix="pptx_slides_")
    else:
        os.makedirs(output_dir, exist_ok=True)

    # Determine which slides to render
    prs = Presentation(pptx_path)
    total = len(prs.slides)
    if slide_indices is None:
        slide_indices = list(range(total))
    else:
        slide_indices = [i for i in slide_indices if 0 <= i < total]

    # Try backends in order
    results = _try_libreoffice(pptx_path, output_dir, slide_indices, width)
    if results:
        return results

    results = _try_powerpoint_com(pptx_path, output_dir, slide_indices, width)
    if results:
        return results

    # Fallback: pure Python rendering
    return _render_python(pptx_path, output_dir, slide_indices, width)


# ── Backend 1: LibreOffice headless ─────────────────────────────────────────

def _find_libreoffice() -> str | None:
    """Find LibreOffice executable across platforms."""
    candidates = []
    system = platform.system()

    if system == "Darwin":  # macOS
        candidates = [
            "/Applications/LibreOffice.app/Contents/MacOS/soffice",
            shutil.which("libreoffice"),
            shutil.which("soffice"),
        ]
    elif system == "Windows":
        candidates = [
            r"C:\Program Files\LibreOffice\program\soffice.exe",
            r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
            shutil.which("soffice"),
            shutil.which("libreoffice"),
        ]
    else:  # Linux
        candidates = [
            shutil.which("libreoffice"),
            shutil.which("soffice"),
            "/usr/bin/libreoffice",
            "/usr/bin/soffice",
        ]

    for c in candidates:
        if c and os.path.isfile(c):
            return c
    return None


def _try_libreoffice(
    pptx_path: str, output_dir: str, slide_indices: list[int], width: int
) -> list[dict] | None:
    """Render slides using LibreOffice headless."""
    soffice = _find_libreoffice()
    if not soffice:
        return None

    try:
        # LibreOffice exports all slides at once to a temp dir
        with tempfile.TemporaryDirectory(prefix="lo_export_") as tmpdir:
            cmd = [
                soffice,
                "--headless",
                "--convert-to", "png",
                "--outdir", tmpdir,
                os.path.abspath(pptx_path),
            ]
            proc = subprocess.run(cmd, capture_output=True, timeout=120, text=True)
            if proc.returncode != 0:
                return None

            # LibreOffice creates one PNG per slide: filename-0.png, filename-1.png, etc.
            # Or sometimes just filename.png for single-slide
            stem = Path(pptx_path).stem
            exported = sorted(Path(tmpdir).glob("*.png"))

            if not exported:
                return None

            results = []
            for idx in slide_indices:
                # Find the matching exported file
                src = None
                if len(exported) == 1 and len(slide_indices) <= 1:
                    src = exported[0]
                elif idx < len(exported):
                    src = exported[idx]

                if src and src.exists():
                    dest = os.path.join(output_dir, f"slide_{idx:03d}.png")
                    # Resize to target width
                    img = Image.open(src)
                    aspect = img.height / img.width
                    new_h = int(width * aspect)
                    img = img.resize((width, new_h), Image.LANCZOS)
                    img.save(dest, "PNG")
                    results.append({
                        "slide_index": idx,
                        "image_path": os.path.abspath(dest),
                        "backend": "libreoffice",
                    })

            return results if results else None
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return None


# ── Backend 2: PowerPoint COM (Windows only) ────────────────────────────────

def _try_powerpoint_com(
    pptx_path: str, output_dir: str, slide_indices: list[int], width: int
) -> list[dict] | None:
    """Render slides using PowerPoint COM automation (Windows only)."""
    if platform.system() != "Windows":
        return None

    try:
        import comtypes.client
    except ImportError:
        return None

    ppt_app = None
    presentation = None
    try:
        ppt_app = comtypes.client.CreateObject("PowerPoint.Application")
        ppt_app.Visible = 1  # Must be visible for export

        abs_path = os.path.abspath(pptx_path)
        presentation = ppt_app.Presentations.Open(abs_path, WithWindow=False)

        results = []
        for idx in slide_indices:
            slide_num = idx + 1  # COM is 1-based
            if slide_num > presentation.Slides.Count:
                continue

            dest = os.path.join(output_dir, f"slide_{idx:03d}.png")
            slide = presentation.Slides(slide_num)
            slide.Export(os.path.abspath(dest), "PNG", width)

            results.append({
                "slide_index": idx,
                "image_path": os.path.abspath(dest),
                "backend": "powerpoint_com",
            })

        return results if results else None
    except Exception:
        return None
    finally:
        try:
            if presentation:
                presentation.Close()
            if ppt_app:
                ppt_app.Quit()
        except Exception:
            pass


# ── Backend 3: Pure Python fallback ─────────────────────────────────────────

def _hex_to_rgb(hex_str: str) -> tuple[int, int, int]:
    h = hex_str.lstrip("#")
    if len(h) == 6:
        return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
    return (128, 128, 128)


def _get_shape_fill_color(shape) -> tuple[int, int, int] | None:
    """Try to get a shape's fill color as RGB tuple."""
    try:
        fill = shape.fill
        if fill.type is not None and "SOLID" in str(fill.type):
            rgb = fill.fore_color.rgb
            return (rgb[0], rgb[1], rgb[2])
    except Exception:
        pass
    return None


def _get_font_color_rgb(font) -> tuple[int, int, int]:
    """Try to get font color, default to light gray."""
    try:
        if font.color and font.color.type is not None and font.color.rgb:
            rgb = font.color.rgb
            return (rgb[0], rgb[1], rgb[2])
    except Exception:
        pass
    return (200, 200, 200)


def _try_load_font(name: str, size: int) -> ImageFont.FreeTypeFont | None:
    """Try to load a system font by name."""
    system = platform.system()
    font_dirs = []

    if system == "Darwin":
        font_dirs = ["/System/Library/Fonts", "/Library/Fonts", os.path.expanduser("~/Library/Fonts")]
    elif system == "Windows":
        font_dirs = [r"C:\Windows\Fonts"]
    else:
        font_dirs = ["/usr/share/fonts", "/usr/local/share/fonts"]

    # Common filename patterns
    name_lower = name.lower().replace(" ", "")
    candidates = [
        f"{name_lower}.ttf", f"{name_lower}.ttc",
        f"{name}.ttf", f"{name}.ttc",
        f"{name_lower}regular.ttf", f"{name_lower}-regular.ttf",
    ]

    for d in font_dirs:
        if not os.path.isdir(d):
            continue
        for root, _, files in os.walk(d):
            for f in files:
                if f.lower() in candidates:
                    try:
                        return ImageFont.truetype(os.path.join(root, f), size)
                    except Exception:
                        pass
    return None


def _get_pil_font(font_name: str | None, font_size_pt: float | None) -> ImageFont.FreeTypeFont:
    """Get a PIL font, falling back gracefully."""
    size = int(font_size_pt or 14)
    if font_name:
        loaded = _try_load_font(font_name, size)
        if loaded:
            return loaded
    # Fallback chain
    for fallback in ["Arial", "Helvetica", "DejaVuSans", "Calibri", "Segoe UI"]:
        loaded = _try_load_font(fallback, size)
        if loaded:
            return loaded
    return ImageFont.load_default()


def _render_python(
    pptx_path: str, output_dir: str, slide_indices: list[int], width: int
) -> list[dict]:
    """Render slides using pure Python (Pillow + python-pptx)."""
    prs = Presentation(pptx_path)
    slide_w_emu = prs.slide_width
    slide_h_emu = prs.slide_height
    aspect = slide_h_emu / slide_w_emu
    height = int(width * aspect)
    scale_x = width / slide_w_emu
    scale_y = height / slide_h_emu

    results = []
    for idx in slide_indices:
        if idx >= len(prs.slides):
            continue

        slide = prs.slides[idx]

        # Start with slide background
        bg_color = (10, 10, 26)  # Default dark
        try:
            bg_fill = slide.background.fill
            if bg_fill.type is not None and "SOLID" in str(bg_fill.type):
                rgb = bg_fill.fore_color.rgb
                bg_color = (rgb[0], rgb[1], rgb[2])
        except Exception:
            pass

        img = Image.new("RGB", (width, height), bg_color)
        draw = ImageDraw.Draw(img)

        for shape in slide.shapes:
            # Convert EMU positions to pixels
            x = int((shape.left or 0) * scale_x)
            y = int((shape.top or 0) * scale_y)
            w = int((shape.width or 0) * scale_x)
            h = int((shape.height or 0) * scale_y)

            if w <= 0 or h <= 0:
                continue

            # Draw pictures
            if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
                try:
                    img_data = BytesIO(shape.image.blob)
                    pic = Image.open(img_data)
                    pic = pic.convert("RGB")
                    pic = pic.resize((w, h), Image.LANCZOS)
                    img.paste(pic, (x, y))
                    continue
                except Exception:
                    pass

            # Draw shape fills
            fill_color = _get_shape_fill_color(shape)
            if fill_color:
                draw.rectangle([x, y, x + w, y + h], fill=fill_color)

            # Draw shape borders
            try:
                line = shape.line
                if line.color and line.color.type is not None:
                    lc = line.color.rgb
                    border_color = (lc[0], lc[1], lc[2])
                    lw = max(1, int((line.width or 12700) / 12700))
                    draw.rectangle([x, y, x + w, y + h], outline=border_color, width=lw)
            except Exception:
                pass

            # Draw text
            if shape.has_text_frame:
                tx = x + 4
                ty = y + 4
                for para in shape.text_frame.paragraphs:
                    for run in para.runs:
                        if not run.text.strip():
                            continue
                        font_name = None
                        font_size = None
                        try:
                            font_name = run.font.name
                        except Exception:
                            pass
                        try:
                            if run.font.size:
                                font_size = run.font.size / 12700  # EMU to pt
                        except Exception:
                            pass

                        # Scale font size to image
                        render_size = max(8, int((font_size or 12) * scale_y * 0.9))
                        pil_font = _get_pil_font(font_name, render_size)
                        text_color = _get_font_color_rgb(run.font)

                        try:
                            draw.text((tx, ty), run.text, fill=text_color, font=pil_font)
                            bbox = pil_font.getbbox(run.text)
                            tx += bbox[2] - bbox[0] + 2
                        except Exception:
                            draw.text((tx, ty), run.text, fill=text_color)
                            tx += len(run.text) * 7

                    # New line after paragraph
                    ty += int((font_size or 14) * scale_y * 1.2) + 2
                    tx = x + 4

            # Draw tables
            if shape.shape_type == MSO_SHAPE_TYPE.TABLE:
                try:
                    table = shape.table
                    n_rows = len(table.rows)
                    n_cols = len(table.columns)
                    cell_w = w // max(n_cols, 1)
                    cell_h = h // max(n_rows, 1)

                    for ri in range(n_rows):
                        for ci in range(n_cols):
                            cx = x + ci * cell_w
                            cy = y + ri * cell_h
                            # Cell border
                            draw.rectangle([cx, cy, cx + cell_w, cy + cell_h],
                                           outline=(60, 60, 80), width=1)
                            # Cell text
                            cell = table.cell(ri, ci)
                            if cell.text.strip():
                                cfont = _get_pil_font(None, max(8, int(10 * scale_y * 0.7)))
                                draw.text((cx + 3, cy + 3), cell.text[:30],
                                          fill=(200, 200, 200), font=cfont)
                except Exception:
                    pass

        # Save
        dest = os.path.join(output_dir, f"slide_{idx:03d}.png")
        img.save(dest, "PNG")
        results.append({
            "slide_index": idx,
            "image_path": os.path.abspath(dest),
            "backend": "python_pillow",
        })

    return results
