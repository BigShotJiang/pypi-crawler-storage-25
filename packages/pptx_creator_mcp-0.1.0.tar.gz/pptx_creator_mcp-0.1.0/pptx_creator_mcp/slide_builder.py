"""
Slide builder - creates styled PPTX slides using python-pptx.

Supports slide types:
    - title: Title slide with subtitle
    - content: Header + bullet points or paragraphs
    - metrics: Big number cards (up to 3)
    - table: Data table with optional highlight rows
    - quote: Quote with attribution
    - two_column: Two-column layout
    - three_column: Three-column card layout
    - bars: Horizontal bar chart
    - summary: Summary slide with key metrics
    - image: Full-slide or centered image with optional title/caption
"""

from io import BytesIO
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR

from .image_utils import resolve_image, get_image_dimensions, fit_image_dimensions
from PIL import Image, ImageDraw
import math

from .style_parser import parse_style_tags, parse_color, TextSegment


# ── Default theme (matches the dark HTML presentation) ──────────────────────

THEME = {
    "bg_dark": ["0A0A0A", "1A1A2E"],
    "bg_accent": ["1A1A2E", "16213E"],
    "bg_highlight": ["0F3460", "1A1A2E"],
    "bg_impact": ["1A1A2E", "0A3D2E"],
    "font_heading": "Segoe UI",
    "font_body": "Segoe UI",
    "color_title": "F0F0F0",
    "color_body": "CCCCCC",
    "color_accent": "4FC3F7",
    "color_green": "66BB6A",
    "color_orange": "FFA726",
    "color_red": "EF5350",
    "color_muted": "888888",
    "color_subtle": "999999",
    "color_section_label": "A0C4FF",
}

SLIDE_WIDTH = Inches(13.333)
SLIDE_HEIGHT = Inches(7.5)


def _hex_to_rgb(hex_str: str) -> tuple[int, int, int]:
    h = hex_str.lstrip("#")
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))


def _create_gradient_bg(color1_hex: str, color2_hex: str, width: int = 1920, height: int = 1080) -> BytesIO:
    """Create a diagonal gradient image for slide background."""
    img = Image.new("RGB", (width, height))
    draw = ImageDraw.Draw(img)
    r1, g1, b1 = _hex_to_rgb(color1_hex)
    r2, g2, b2 = _hex_to_rgb(color2_hex)
    for y in range(height):
        for x_block in range(0, width, 4):
            t = (x_block / width * 0.5) + (y / height * 0.5)
            t = min(1.0, max(0.0, t))
            r = int(r1 + (r2 - r1) * t)
            g = int(g1 + (g2 - g1) * t)
            b = int(b1 + (b2 - b1) * t)
            for dx in range(min(4, width - x_block)):
                draw.point((x_block + dx, y), fill=(r, g, b))
    buf = BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return buf


def _apply_bg(slide, bg_key: str, custom_colors: list[str] | None = None,
              background_image: str | None = None):
    """Apply background to a slide — image if provided, otherwise gradient."""
    if background_image:
        img_stream = resolve_image(background_image)
        if img_stream:
            slide.shapes.add_picture(img_stream, Emu(0), Emu(0), SLIDE_WIDTH, SLIDE_HEIGHT)
            return
    # Fallback to gradient
    if custom_colors and len(custom_colors) >= 2:
        colors = custom_colors
    elif bg_key in THEME:
        colors = THEME[bg_key]
    else:
        colors = THEME["bg_dark"]
    img_stream = _create_gradient_bg(colors[0], colors[1])
    slide.shapes.add_picture(img_stream, Emu(0), Emu(0), SLIDE_WIDTH, SLIDE_HEIGHT)


def _rgb(hex_str: str) -> RGBColor:
    return RGBColor(*_hex_to_rgb(hex_str))


def _add_styled_runs(paragraph, segments: list[TextSegment], default_color: str = None,
                     default_size: float = None, default_font: str = None,
                     default_bold: bool = None):
    """Add styled text runs to a paragraph from parsed segments."""
    for seg in segments:
        run = paragraph.add_run()
        run.text = seg.text
        font = run.font
        # Color
        color_val = seg.color
        if color_val:
            rgb = parse_color(color_val)
            if rgb:
                font.color.rgb = rgb
        elif default_color:
            font.color.rgb = _rgb(default_color)
        # Size
        if seg.font_size:
            font.size = Pt(seg.font_size)
        elif default_size:
            font.size = Pt(default_size)
        # Font family
        if seg.font_type:
            font.name = seg.font_type
        elif default_font:
            font.name = default_font
        # Bold / Italic / Underline
        if seg.bold is not None:
            font.bold = seg.bold
        elif default_bold is not None:
            font.bold = default_bold
        if seg.italic is not None:
            font.italic = seg.italic
        if seg.underline is not None:
            font.underline = seg.underline


def _add_text_box(slide, left, top, width, height, text: str,
                  color: str = None, size: float = None, font: str = None,
                  bold: bool = None, alignment=None):
    """Add a text box with styled text (supports <style> tags)."""
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    if alignment:
        p.alignment = alignment
    segments = parse_style_tags(text)
    _add_styled_runs(p, segments, default_color=color, default_size=size,
                     default_font=font, default_bold=bold)
    return txBox


def _add_card_shape(slide, left, top, width, height, border_color: str = "FFFFFF14"):
    """Add a rounded rectangle card background."""
    from pptx.enum.shapes import MSO_SHAPE
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
    shape.fill.solid()
    shape.fill.fore_color.rgb = RGBColor(0x18, 0x18, 0x28)
    shape.line.color.rgb = RGBColor(0x30, 0x30, 0x45)
    shape.line.width = Pt(0.75)
    shape.shadow.inherit = False
    return shape


# ── Slide type builders ─────────────────────────────────────────────────────

def build_title_slide(prs: Presentation, slide_data: dict):
    """Title slide: section_label, title, subtitle, footer."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])  # blank
    bg = slide_data.get("background", "bg_dark")
    _apply_bg(slide, bg, slide_data.get("background_colors"), slide_data.get("background_image"))

    y = Inches(2.0)
    if slide_data.get("section_label"):
        _add_text_box(slide, Inches(1), Inches(1.5), Inches(11.3), Inches(0.5),
                      slide_data["section_label"],
                      color=THEME["color_muted"], size=12, font=THEME["font_body"],
                      alignment=PP_ALIGN.CENTER)
        y = Inches(2.2)

    _add_text_box(slide, Inches(1), y, Inches(11.3), Inches(2.0),
                  slide_data.get("title", ""),
                  color=THEME["color_title"], size=40, font=THEME["font_heading"],
                  bold=False, alignment=PP_ALIGN.CENTER)

    if slide_data.get("subtitle"):
        _add_text_box(slide, Inches(1), y + Inches(2.2), Inches(11.3), Inches(0.8),
                      slide_data["subtitle"],
                      color="7EB8DA", size=20, font=THEME["font_body"],
                      alignment=PP_ALIGN.CENTER)

    if slide_data.get("footer"):
        _add_text_box(slide, Inches(1), Inches(6.5), Inches(11.3), Inches(0.5),
                      slide_data["footer"],
                      color=THEME["color_muted"], size=11, font=THEME["font_body"],
                      alignment=PP_ALIGN.CENTER)


def build_content_slide(prs: Presentation, slide_data: dict):
    """Content slide: section_label, title, bullet points or paragraphs."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    bg = slide_data.get("background", "bg_accent")
    _apply_bg(slide, bg, slide_data.get("background_colors"), slide_data.get("background_image"))

    y = Inches(0.6)
    if slide_data.get("section_label"):
        _add_text_box(slide, Inches(0.8), y, Inches(11.5), Inches(0.4),
                      slide_data["section_label"],
                      color=THEME["color_section_label"], size=14, font=THEME["font_body"])
        y += Inches(0.5)

    if slide_data.get("title"):
        _add_text_box(slide, Inches(0.8), y, Inches(11.5), Inches(1.0),
                      slide_data["title"],
                      color=THEME["color_title"], size=30, font=THEME["font_heading"])
        y += Inches(1.2)

    items = slide_data.get("bullets", [])
    if items:
        txBox = slide.shapes.add_textbox(Inches(0.8), y, Inches(11.5), Inches(4.5))
        tf = txBox.text_frame
        tf.word_wrap = True
        for i, item in enumerate(items):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            p.space_after = Pt(8)
            segments = parse_style_tags(f"• {item}")
            _add_styled_runs(p, segments, default_color=THEME["color_body"],
                             default_size=16, default_font=THEME["font_body"])

    if slide_data.get("footer_text"):
        _add_text_box(slide, Inches(0.8), Inches(6.5), Inches(11.5), Inches(0.5),
                      slide_data["footer_text"],
                      color=THEME["color_orange"], size=13, font=THEME["font_body"],
                      alignment=PP_ALIGN.CENTER)

    # Inline image support on content slides
    if slide_data.get("image_path"):
        img_y = y + Inches(0.2) if not items else y + Inches(len(items) * 0.4 + 0.3)
        img_y = min(img_y, Inches(4.0))  # cap position
        remaining = Inches(6.2) - img_y
        _add_centered_image(slide, slide_data["image_path"], img_y, Inches(10.0), remaining)


def build_metrics_slide(prs: Presentation, slide_data: dict):
    """Metrics slide: section_label, title, up to 3 metric cards with big numbers."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    bg = slide_data.get("background", "bg_accent")
    _apply_bg(slide, bg, slide_data.get("background_colors"), slide_data.get("background_image"))

    y = Inches(0.6)
    if slide_data.get("section_label"):
        _add_text_box(slide, Inches(0.8), y, Inches(11.5), Inches(0.4),
                      slide_data["section_label"],
                      color=THEME["color_section_label"], size=14, font=THEME["font_body"])
        y += Inches(0.5)

    if slide_data.get("title"):
        _add_text_box(slide, Inches(0.8), y, Inches(11.5), Inches(1.0),
                      slide_data["title"],
                      color=THEME["color_title"], size=30, font=THEME["font_heading"])
        y += Inches(1.3)

    metrics = slide_data.get("metrics", [])
    n = len(metrics)
    if n == 0:
        return

    card_w = Inches(3.4)
    gap = Inches(0.4)
    total_w = n * card_w + (n - 1) * gap
    start_x = (SLIDE_WIDTH - total_w) // 2

    for i, m in enumerate(metrics):
        x = start_x + i * (card_w + gap)
        _add_card_shape(slide, x, y, card_w, Inches(3.2))

        color = m.get("color", THEME["color_accent"])
        if color in THEME:
            color = THEME[color]

        _add_text_box(slide, x + Inches(0.3), y + Inches(0.3), card_w - Inches(0.6), Inches(1.2),
                      m.get("value", ""),
                      color=color, size=48, font=THEME["font_heading"],
                      alignment=PP_ALIGN.CENTER)

        _add_text_box(slide, x + Inches(0.3), y + Inches(1.5), card_w - Inches(0.6), Inches(0.4),
                      m.get("label", ""),
                      color=THEME["color_subtle"], size=13, font=THEME["font_body"],
                      alignment=PP_ALIGN.CENTER)

        if m.get("description"):
            _add_text_box(slide, x + Inches(0.3), y + Inches(2.0), card_w - Inches(0.6), Inches(1.0),
                          m["description"],
                          color=THEME["color_body"], size=11, font=THEME["font_body"],
                          alignment=PP_ALIGN.CENTER)

    if slide_data.get("footer_text"):
        _add_text_box(slide, Inches(0.8), Inches(6.5), Inches(11.5), Inches(0.5),
                      slide_data["footer_text"],
                      color=THEME["color_green"], size=14, font=THEME["font_body"],
                      alignment=PP_ALIGN.CENTER)


def build_table_slide(prs: Presentation, slide_data: dict):
    """Table slide: section_label, title, table data with optional highlight rows."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    bg = slide_data.get("background", "bg_dark")
    _apply_bg(slide, bg, slide_data.get("background_colors"), slide_data.get("background_image"))

    y = Inches(0.6)
    if slide_data.get("section_label"):
        _add_text_box(slide, Inches(0.8), y, Inches(11.5), Inches(0.4),
                      slide_data["section_label"],
                      color=THEME["color_section_label"], size=14, font=THEME["font_body"])
        y += Inches(0.5)

    if slide_data.get("title"):
        _add_text_box(slide, Inches(0.8), y, Inches(11.5), Inches(0.8),
                      slide_data["title"],
                      color=THEME["color_title"], size=28, font=THEME["font_heading"])
        y += Inches(1.0)

    headers = slide_data.get("headers", [])
    rows = slide_data.get("rows", [])
    highlight_rows = slide_data.get("highlight_rows", [])

    if not headers or not rows:
        return

    n_cols = len(headers)
    n_rows = len(rows) + 1  # +1 for header
    table_w = Inches(11.5)
    table_h = Inches(min(5.0, 0.45 * n_rows))

    table_shape = slide.shapes.add_table(n_rows, n_cols, Inches(0.8), y, table_w, table_h)
    table = table_shape.table

    # Style header row
    for j, h in enumerate(headers):
        cell = table.cell(0, j)
        cell.text = ""
        p = cell.text_frame.paragraphs[0]
        run = p.add_run()
        run.text = h
        run.font.color.rgb = _rgb(THEME["color_accent"])
        run.font.size = Pt(13)
        run.font.name = THEME["font_body"]
        run.font.bold = True
        cell.fill.solid()
        cell.fill.fore_color.rgb = RGBColor(0x12, 0x12, 0x20)

    # Style data rows
    for i, row in enumerate(rows):
        is_highlight = i in highlight_rows
        for j, val in enumerate(row):
            cell = table.cell(i + 1, j)
            cell.text = ""
            p = cell.text_frame.paragraphs[0]
            segments = parse_style_tags(str(val))
            default_color = THEME["color_green"] if is_highlight else THEME["color_body"]
            _add_styled_runs(p, segments, default_color=default_color,
                             default_size=12, default_font=THEME["font_body"],
                             default_bold=is_highlight)
            cell.fill.solid()
            cell.fill.fore_color.rgb = RGBColor(0x10, 0x10, 0x1A)


def build_quote_slide(prs: Presentation, slide_data: dict):
    """Quote slide: quote text with attribution."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    bg = slide_data.get("background", "bg_dark")
    _apply_bg(slide, bg, slide_data.get("background_colors"), slide_data.get("background_image"))

    y = Inches(0.6)
    if slide_data.get("section_label"):
        _add_text_box(slide, Inches(0.8), y, Inches(11.5), Inches(0.4),
                      slide_data["section_label"],
                      color=THEME["color_section_label"], size=14, font=THEME["font_body"])
        y += Inches(0.5)

    if slide_data.get("title"):
        _add_text_box(slide, Inches(0.8), y, Inches(11.5), Inches(0.8),
                      slide_data["title"],
                      color=THEME["color_title"], size=28, font=THEME["font_heading"])
        y += Inches(1.2)

    # Quote accent bar
    from pptx.enum.shapes import MSO_SHAPE
    bar = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(1.5), y, Inches(0.05), Inches(2.0))
    bar.fill.solid()
    bar.fill.fore_color.rgb = _rgb(THEME["color_accent"])
    bar.line.fill.background()

    # Quote text
    quote_text = slide_data.get("quote", "")
    _add_text_box(slide, Inches(1.8), y, Inches(9.0), Inches(2.0),
                  quote_text,
                  color="A0C4FF", size=19, font=THEME["font_body"])

    if slide_data.get("attribution"):
        _add_text_box(slide, Inches(1.8), y + Inches(2.2), Inches(9.0), Inches(0.4),
                      slide_data["attribution"],
                      color=THEME["color_muted"], size=12, font=THEME["font_body"])


def build_two_column_slide(prs: Presentation, slide_data: dict):
    """Two-column layout: section_label, title, left/right content."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    bg = slide_data.get("background", "bg_dark")
    _apply_bg(slide, bg, slide_data.get("background_colors"), slide_data.get("background_image"))

    y = Inches(0.6)
    if slide_data.get("section_label"):
        _add_text_box(slide, Inches(0.8), y, Inches(11.5), Inches(0.4),
                      slide_data["section_label"],
                      color=THEME["color_section_label"], size=14, font=THEME["font_body"])
        y += Inches(0.5)

    if slide_data.get("title"):
        _add_text_box(slide, Inches(0.8), y, Inches(11.5), Inches(0.8),
                      slide_data["title"],
                      color=THEME["color_title"], size=28, font=THEME["font_heading"])
        y += Inches(1.2)

    col_w = Inches(5.4)
    for col_idx, col_key in enumerate(["left", "right"]):
        col = slide_data.get(col_key, {})
        x = Inches(0.8) if col_idx == 0 else Inches(7.0)

        if col.get("card", False):
            _add_card_shape(slide, x, y, col_w, Inches(4.0))

        cy = y + Inches(0.3)
        if col.get("title"):
            _add_text_box(slide, x + Inches(0.3), cy, col_w - Inches(0.6), Inches(0.4),
                          col["title"],
                          color=THEME["color_accent"], size=15, font=THEME["font_body"], bold=True)
            cy += Inches(0.5)

        items = col.get("items", [])
        if items:
            txBox = slide.shapes.add_textbox(x + Inches(0.3), cy, col_w - Inches(0.6), Inches(3.0))
            tf = txBox.text_frame
            tf.word_wrap = True
            for i, item in enumerate(items):
                p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
                p.space_after = Pt(6)
                segments = parse_style_tags(item)
                _add_styled_runs(p, segments, default_color=THEME["color_body"],
                                 default_size=13, default_font=THEME["font_body"])

        if col.get("text"):
            _add_text_box(slide, x + Inches(0.3), cy, col_w - Inches(0.6), Inches(3.0),
                          col["text"],
                          color=THEME["color_body"], size=13, font=THEME["font_body"])

        # Inline image support in columns
        if col.get("image_path"):
            img_top = cy if not items and not col.get("text") else cy + Inches(0.3)
            remaining_h = Inches(4.0) - (img_top - y)
            _add_image_to_slide(slide, col["image_path"],
                                x + Inches(0.3), img_top,
                                col_w - Inches(0.6), remaining_h)


def build_bars_slide(prs: Presentation, slide_data: dict):
    """Horizontal bar chart slide."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    bg = slide_data.get("background", "bg_accent")
    _apply_bg(slide, bg, slide_data.get("background_colors"), slide_data.get("background_image"))

    y = Inches(0.6)
    if slide_data.get("section_label"):
        _add_text_box(slide, Inches(0.8), y, Inches(11.5), Inches(0.4),
                      slide_data["section_label"],
                      color=THEME["color_section_label"], size=14, font=THEME["font_body"])
        y += Inches(0.5)

    if slide_data.get("title"):
        _add_text_box(slide, Inches(0.8), y, Inches(11.5), Inches(0.8),
                      slide_data["title"],
                      color=THEME["color_title"], size=28, font=THEME["font_heading"])
        y += Inches(1.2)

    bars = slide_data.get("bars", [])
    max_val = max((b.get("value", 0) for b in bars), default=1)
    bar_h = Inches(0.4)
    bar_gap = Inches(0.15)
    max_bar_w = Inches(7.0)

    from pptx.enum.shapes import MSO_SHAPE
    for i, bar in enumerate(bars):
        by = y + i * (bar_h + bar_gap + Inches(0.25))
        # Label
        label_text = f"{bar.get('label', '')}    {bar.get('display_value', '')}"
        _add_text_box(slide, Inches(0.8), by, Inches(11.0), Inches(0.25),
                      label_text,
                      color=THEME["color_body"], size=11, font=THEME["font_body"])
        # Bar background
        bg_shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE,
                                          Inches(0.8), by + Inches(0.25), max_bar_w, bar_h)
        bg_shape.fill.solid()
        bg_shape.fill.fore_color.rgb = RGBColor(0x20, 0x20, 0x30)
        bg_shape.line.fill.background()
        # Bar fill
        ratio = bar.get("value", 0) / max_val if max_val > 0 else 0
        fill_w = int(max_bar_w * ratio)
        if fill_w > 0:
            bar_color = bar.get("color", THEME["color_green"])
            if bar_color in THEME:
                bar_color = THEME[bar_color]
            fill_shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE,
                                                Inches(0.8), by + Inches(0.25), fill_w, bar_h)
            fill_shape.fill.solid()
            fill_shape.fill.fore_color.rgb = _rgb(bar_color) if isinstance(bar_color, str) else _rgb(THEME["color_green"])
            fill_shape.line.fill.background()

    if slide_data.get("footer_text"):
        _add_text_box(slide, Inches(0.8), Inches(6.5), Inches(11.5), Inches(0.5),
                      slide_data["footer_text"],
                      color=THEME["color_muted"], size=10, font=THEME["font_body"])


def build_three_column_slide(prs: Presentation, slide_data: dict):
    """Three-column card layout."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    bg = slide_data.get("background", "bg_dark")
    _apply_bg(slide, bg, slide_data.get("background_colors"), slide_data.get("background_image"))

    y = Inches(0.6)
    if slide_data.get("section_label"):
        _add_text_box(slide, Inches(0.8), y, Inches(11.5), Inches(0.4),
                      slide_data["section_label"],
                      color=THEME["color_section_label"], size=14, font=THEME["font_body"])
        y += Inches(0.5)

    if slide_data.get("title"):
        _add_text_box(slide, Inches(0.8), y, Inches(11.5), Inches(0.8),
                      slide_data["title"],
                      color=THEME["color_title"], size=28, font=THEME["font_heading"])
        y += Inches(1.2)

    columns = slide_data.get("columns", [])
    n = min(len(columns), 3)
    card_w = Inches(3.6)
    gap = Inches(0.3)
    total_w = n * card_w + (n - 1) * gap
    start_x = (SLIDE_WIDTH - total_w) // 2

    for i, col in enumerate(columns[:3]):
        x = start_x + i * (card_w + gap)
        border_color = col.get("accent_color", THEME["color_accent"])
        if border_color in THEME:
            border_color = THEME[border_color]

        card = _add_card_shape(slide, x, y, card_w, Inches(3.8))

        # Accent top border
        from pptx.enum.shapes import MSO_SHAPE
        top_bar = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, x, y, card_w, Inches(0.04))
        top_bar.fill.solid()
        top_bar.fill.fore_color.rgb = _rgb(border_color)
        top_bar.line.fill.background()

        cy = y + Inches(0.3)
        if col.get("title"):
            _add_text_box(slide, x + Inches(0.3), cy, card_w - Inches(0.6), Inches(0.4),
                          col["title"],
                          color=THEME["color_accent"], size=14, font=THEME["font_body"], bold=True)
            cy += Inches(0.45)

        if col.get("subtitle"):
            _add_text_box(slide, x + Inches(0.3), cy, card_w - Inches(0.6), Inches(0.3),
                          col["subtitle"],
                          color=border_color, size=10, font=THEME["font_body"])
            cy += Inches(0.35)

        if col.get("text"):
            _add_text_box(slide, x + Inches(0.3), cy, card_w - Inches(0.6), Inches(1.8),
                          col["text"],
                          color=THEME["color_body"], size=12, font=THEME["font_body"])

        if col.get("footer"):
            _add_text_box(slide, x + Inches(0.3), y + Inches(3.2), card_w - Inches(0.6), Inches(0.4),
                          col["footer"],
                          color=THEME["color_green"], size=10, font=THEME["font_body"])

    if slide_data.get("footer_text"):
        _add_text_box(slide, Inches(0.8), Inches(6.5), Inches(11.5), Inches(0.5),
                      slide_data["footer_text"],
                      color=THEME["color_muted"], size=11, font=THEME["font_body"],
                      alignment=PP_ALIGN.CENTER)


def build_summary_slide(prs: Presentation, slide_data: dict):
    """Summary slide with key metrics in a row."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    bg = slide_data.get("background", "bg_dark")
    _apply_bg(slide, bg, slide_data.get("background_colors"), slide_data.get("background_image"))

    y = Inches(0.6)
    if slide_data.get("section_label"):
        _add_text_box(slide, Inches(0.8), y, Inches(11.5), Inches(0.4),
                      slide_data["section_label"],
                      color=THEME["color_section_label"], size=14, font=THEME["font_body"])
        y += Inches(0.5)

    if slide_data.get("title"):
        _add_text_box(slide, Inches(0.8), y, Inches(11.5), Inches(1.5),
                      slide_data["title"],
                      color=THEME["color_title"], size=32, font=THEME["font_heading"],
                      alignment=PP_ALIGN.CENTER)
        y += Inches(2.0)

    metrics = slide_data.get("metrics", [])
    n = len(metrics)
    if n > 0:
        card_w = Inches(2.0)
        gap = Inches(0.25)
        total_w = n * card_w + (n - 1) * gap
        start_x = (SLIDE_WIDTH - total_w) // 2

        for i, m in enumerate(metrics):
            x = start_x + i * (card_w + gap)
            _add_card_shape(slide, x, y, card_w, Inches(1.4))
            color = m.get("color", THEME["color_accent"])
            if color in THEME:
                color = THEME[color]
            _add_text_box(slide, x + Inches(0.1), y + Inches(0.15), card_w - Inches(0.2), Inches(0.7),
                          m.get("value", ""),
                          color=color, size=22, font=THEME["font_heading"],
                          alignment=PP_ALIGN.CENTER)
            _add_text_box(slide, x + Inches(0.1), y + Inches(0.85), card_w - Inches(0.2), Inches(0.4),
                          m.get("label", ""),
                          color=THEME["color_muted"], size=10, font=THEME["font_body"],
                          alignment=PP_ALIGN.CENTER)

    if slide_data.get("footer_text"):
        _add_text_box(slide, Inches(0.8), Inches(6.5), Inches(11.5), Inches(0.5),
                      slide_data["footer_text"],
                      color=THEME["color_muted"], size=12, font=THEME["font_body"],
                      alignment=PP_ALIGN.CENTER)


def _add_image_to_slide(slide, image_path: str, left, top, max_width, max_height):
    """
    Add an image to a slide, preserving aspect ratio within max bounds.

    Args:
        slide: The slide object.
        image_path: Local path or URL.
        left, top: Position in EMU or Inches.
        max_width, max_height: Maximum bounds in EMU or Inches.

    Returns:
        The picture shape, or None if image couldn't be resolved.
    """
    img_stream = resolve_image(image_path)
    if img_stream is None:
        return None

    img_w, img_h = get_image_dimensions(img_stream)
    # Convert max bounds to inches for calculation
    max_w_in = max_width / 914400 if isinstance(max_width, int) else max_width.inches if hasattr(max_width, 'inches') else float(max_width) / 914400
    max_h_in = max_height / 914400 if isinstance(max_height, int) else max_height.inches if hasattr(max_height, 'inches') else float(max_height) / 914400

    fit_w, fit_h = fit_image_dimensions(img_w, img_h, max_w_in, max_h_in)

    pic = slide.shapes.add_picture(img_stream, left, top, Inches(fit_w), Inches(fit_h))
    return pic


def _add_centered_image(slide, image_path: str, top, max_width, max_height):
    """Add an image centered horizontally on the slide."""
    img_stream = resolve_image(image_path)
    if img_stream is None:
        return None

    img_w, img_h = get_image_dimensions(img_stream)
    max_w_in = max_width / 914400 if isinstance(max_width, int) else max_width.inches if hasattr(max_width, 'inches') else float(max_width) / 914400
    max_h_in = max_height / 914400 if isinstance(max_height, int) else max_height.inches if hasattr(max_height, 'inches') else float(max_height) / 914400

    fit_w, fit_h = fit_image_dimensions(img_w, img_h, max_w_in, max_h_in)

    # Center horizontally
    slide_w_in = SLIDE_WIDTH / 914400
    left = Inches((slide_w_in - fit_w) / 2)

    pic = slide.shapes.add_picture(img_stream, left, top, Inches(fit_w), Inches(fit_h))
    return pic


def build_image_slide(prs: Presentation, slide_data: dict):
    """
    Image slide: full-slide or centered image with optional title and caption.

    Fields:
        - image_path: Local file path or URL (required)
        - title: Optional title above the image
        - caption: Optional caption below the image
        - section_label: Optional section label
        - image_mode: "centered" (default) or "full" for full-slide background image
    """
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    bg = slide_data.get("background", "bg_dark")
    _apply_bg(slide, bg, slide_data.get("background_colors"), slide_data.get("background_image"))

    image_path = slide_data.get("image_path", "")
    mode = slide_data.get("image_mode", "centered")

    if mode == "full":
        # Full-slide image (stretched to fill)
        img_stream = resolve_image(image_path)
        if img_stream:
            slide.shapes.add_picture(img_stream, Emu(0), Emu(0), SLIDE_WIDTH, SLIDE_HEIGHT)
        # Overlay title if provided
        if slide_data.get("title"):
            _add_text_box(slide, Inches(1), Inches(5.5), Inches(11.3), Inches(1.0),
                          slide_data["title"],
                          color=THEME["color_title"], size=28, font=THEME["font_heading"],
                          alignment=PP_ALIGN.CENTER)
        if slide_data.get("caption"):
            _add_text_box(slide, Inches(1), Inches(6.5), Inches(11.3), Inches(0.5),
                          slide_data["caption"],
                          color=THEME["color_muted"], size=11, font=THEME["font_body"],
                          alignment=PP_ALIGN.CENTER)
    else:
        # Centered image with title/caption
        y = Inches(0.6)
        if slide_data.get("section_label"):
            _add_text_box(slide, Inches(0.8), y, Inches(11.5), Inches(0.4),
                          slide_data["section_label"],
                          color=THEME["color_section_label"], size=14, font=THEME["font_body"])
            y += Inches(0.5)

        if slide_data.get("title"):
            _add_text_box(slide, Inches(0.8), y, Inches(11.5), Inches(0.8),
                          slide_data["title"],
                          color=THEME["color_title"], size=28, font=THEME["font_heading"],
                          alignment=PP_ALIGN.CENTER)
            y += Inches(1.0)

        # Image area
        max_img_h = Inches(4.5) if slide_data.get("title") else Inches(5.5)
        _add_centered_image(slide, image_path, y, Inches(11.0), max_img_h)

        if slide_data.get("caption"):
            _add_text_box(slide, Inches(1), Inches(6.5), Inches(11.3), Inches(0.5),
                          slide_data["caption"],
                          color=THEME["color_muted"], size=11, font=THEME["font_body"],
                          alignment=PP_ALIGN.CENTER)


# ── Slide type dispatcher ───────────────────────────────────────────────────

SLIDE_BUILDERS = {
    "title": build_title_slide,
    "content": build_content_slide,
    "metrics": build_metrics_slide,
    "table": build_table_slide,
    "quote": build_quote_slide,
    "two_column": build_two_column_slide,
    "three_column": build_three_column_slide,
    "bars": build_bars_slide,
    "summary": build_summary_slide,
    "image": build_image_slide,
}


def create_presentation(slides: list[dict], output_path: str) -> str:
    """
    Create a PPTX presentation from structured slide data.

    Args:
        slides: List of slide dictionaries, each with a "type" key.
        output_path: Path to save the .pptx file.

    Returns:
        Path to the created file.
    """
    prs = Presentation()
    prs.slide_width = SLIDE_WIDTH
    prs.slide_height = SLIDE_HEIGHT

    for slide_data in slides:
        slide_type = slide_data.get("type", "content")
        builder = SLIDE_BUILDERS.get(slide_type)
        if builder:
            builder(prs, slide_data)
        else:
            # Fallback to content slide
            build_content_slide(prs, slide_data)

    prs.save(output_path)
    return output_path
