"""
Style extractor — deep shape-level analysis of PPTX presentations.

Extracts a reusable "style library" from an existing PPTX:
- Global palette (most-used colors, fonts)
- Per-slide templates (background, shape positions, text styles)
- Shape-level detail (position, size, fill, border, text formatting)

Outputs a JSON-serializable dict that can be applied to new content.
"""

import json
from collections import Counter
from pathlib import Path
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE_TYPE
from lxml import etree


def _emu_to_inches(emu: int | None) -> float | None:
    if emu is None:
        return None
    return round(emu / 914400, 4)


def _rgb_to_hex(rgb: RGBColor | None) -> str | None:
    if rgb is None:
        return None
    return f"{rgb[0]:02X}{rgb[1]:02X}{rgb[2]:02X}"


def _resolve_theme_color(color_format, slide) -> str | None:
    """Try to resolve a theme color reference to an actual hex value."""
    try:
        if color_format.rgb:
            return _rgb_to_hex(color_format.rgb)
    except (AttributeError, TypeError):
        pass

    # Try to get theme color enum
    try:
        theme_color = color_format.theme_color
        if theme_color is not None:
            # Attempt to resolve from slide's theme
            return _resolve_theme_color_from_xml(theme_color, slide)
    except (AttributeError, TypeError):
        pass

    return None


def _resolve_theme_color_from_xml(theme_color_enum, slide) -> str | None:
    """Resolve theme color by walking the presentation theme XML."""
    try:
        # Map MSO theme color index to Open XML theme element names
        theme_map = {
            1: "dk1", 2: "lt1", 3: "dk2", 4: "lt2",
            5: "accent1", 6: "accent2", 7: "accent3", 8: "accent4",
            9: "accent5", 10: "accent6", 11: "hlink", 12: "folHlink",
        }
        idx = int(theme_color_enum)
        tag_name = theme_map.get(idx)
        if not tag_name:
            return None

        # Navigate to theme XML
        prs = slide.part.package.presentation_part.presentation
        theme_part = slide.part.package.presentation_part.part_related_by(
            "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme"
        )
        theme_xml = theme_part._element
        ns = {"a": "http://schemas.openxmlformats.org/drawingml/2006/main"}

        # Look in clrScheme
        for scheme in theme_xml.iter("{http://schemas.openxmlformats.org/drawingml/2006/main}clrScheme"):
            for child in scheme:
                local = child.tag.split("}")[-1] if "}" in child.tag else child.tag
                if local == tag_name:
                    # Get srgbClr or sysClr
                    for clr in child:
                        clr_tag = clr.tag.split("}")[-1] if "}" in clr.tag else clr.tag
                        if clr_tag == "srgbClr":
                            return clr.get("val", "").upper()
                        elif clr_tag == "sysClr":
                            return clr.get("lastClr", "").upper()
        return None
    except Exception:
        return None


def _extract_font_style(font, run=None, paragraph=None, shape=None, slide=None) -> dict:
    """Extract font properties, resolving inherited/theme styles when explicit ones are missing."""
    style = {}

    # --- Explicit properties from the font object ---
    try:
        if font.name:
            style["font_name"] = font.name
    except Exception:
        pass
    try:
        if font.size:
            style["font_size_pt"] = round(font.size / 12700, 1)
    except Exception:
        pass
    try:
        if font.bold is not None:
            style["bold"] = font.bold
    except Exception:
        pass
    try:
        if font.italic is not None:
            style["italic"] = font.italic
    except Exception:
        pass
    try:
        if font.underline is not None:
            style["underline"] = bool(font.underline)
    except Exception:
        pass
    try:
        if font.color and font.color.type is not None:
            hex_val = _rgb_to_hex(font.color.rgb) if font.color.rgb else None
            if hex_val:
                style["color"] = hex_val
    except Exception:
        pass

    # --- Resolve inherited styles from theme/layout/master ---
    if slide and ("font_name" not in style or "color" not in style or "font_size_pt" not in style):
        inherited = _resolve_inherited_text_style(run, paragraph, shape, slide)
        if "font_name" not in style and inherited.get("font_name"):
            style["font_name"] = inherited["font_name"]
            style["font_name_source"] = "inherited"
        if "color" not in style and inherited.get("color"):
            style["color"] = inherited["color"]
            style["color_source"] = "inherited"
        if "font_size_pt" not in style and inherited.get("font_size_pt"):
            style["font_size_pt"] = inherited["font_size_pt"]
            style["font_size_source"] = "inherited"
        if "bold" not in style and inherited.get("bold") is not None:
            style["bold"] = inherited["bold"]

    return style


def _resolve_inherited_text_style(run, paragraph, shape, slide) -> dict:
    """Walk the inheritance chain: paragraph defaults → layout → master → theme."""
    from pptx.oxml.ns import qn
    from lxml import etree
    result = {}

    # 1. Try paragraph-level defaults (defRPr)
    if paragraph is not None:
        try:
            pPr = paragraph._p.find(qn("a:pPr"))
            if pPr is not None:
                defRPr = pPr.find(qn("a:defRPr"))
                if defRPr is not None:
                    _extract_from_rPr_xml(defRPr, result)
        except Exception:
            pass

    # 2. Try shape's text body defaults (lstStyle / bodyPr)
    if shape is not None and not result.get("font_name"):
        try:
            txBody = shape._element.find(qn("p:txBody"))
            if txBody is not None:
                lstStyle = txBody.find(qn("a:lstStyle"))
                if lstStyle is not None:
                    for lvl_tag in ["a:lvl1pPr", "a:defPPr"]:
                        lvl = lstStyle.find(qn(lvl_tag))
                        if lvl is not None:
                            defRPr = lvl.find(qn("a:defRPr"))
                            if defRPr is not None:
                                _extract_from_rPr_xml(defRPr, result)
        except Exception:
            pass

    # 3. Try slide layout and master
    if not result.get("font_name") or not result.get("font_size_pt"):
        try:
            layout = slide.slide_layout
            master = layout.slide_master
            # Get theme fonts
            theme_part = master.part.part_related_by(
                "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme"
            )
            theme_xml = etree.fromstring(theme_part.blob)

            # Font scheme
            for fscheme in theme_xml.iter(qn("a:fontScheme")):
                for minor in fscheme.iter(qn("a:minorFont")):
                    for f in minor:
                        if f.tag.endswith("latin") and not result.get("font_name"):
                            result["font_name"] = f.get("typeface")
                for major in fscheme.iter(qn("a:majorFont")):
                    for f in major:
                        if f.tag.endswith("latin") and not result.get("font_name"):
                            result["font_name"] = f.get("typeface")

            # Theme color scheme — resolve dk1/lt1 for default text
            if not result.get("color"):
                for scheme in theme_xml.iter(qn("a:clrScheme")):
                    # Default text is usually dk1 on light bg, lt1 on dark bg
                    for tag_name in ["dk1", "lt1"]:
                        for child in scheme:
                            if child.tag.split("}")[-1] == tag_name:
                                for clr in child:
                                    val = clr.get("val") or clr.get("lastClr")
                                    if val:
                                        result["color"] = val.upper()
                                        break
                        if result.get("color"):
                            break
        except Exception:
            pass

    return result


def _extract_from_rPr_xml(rPr_elem, result: dict):
    """Extract font info from an XML rPr or defRPr element."""
    from pptx.oxml.ns import qn

    # Font size
    sz = rPr_elem.get("sz")
    if sz and "font_size_pt" not in result:
        try:
            result["font_size_pt"] = round(int(sz) / 100, 1)
        except ValueError:
            pass

    # Bold
    b = rPr_elem.get("b")
    if b is not None and "bold" not in result:
        result["bold"] = b == "1" or b.lower() == "true"

    # Font name
    latin = rPr_elem.find(qn("a:latin"))
    if latin is not None and "font_name" not in result:
        tf = latin.get("typeface")
        if tf and tf not in ("+mn-lt", "+mj-lt"):
            result["font_name"] = tf

    # Color
    sf = rPr_elem.find(qn("a:solidFill"))
    if sf is not None and "color" not in result:
        for c in sf:
            ctag = c.tag.split("}")[-1]
            if ctag == "srgbClr":
                result["color"] = c.get("val", "").upper()
            elif ctag == "sysClr":
                result["color"] = c.get("lastClr", "").upper()


def _extract_paragraph_style(paragraph) -> dict:
    """Extract paragraph-level formatting."""
    style = {}
    try:
        if paragraph.alignment is not None:
            style["alignment"] = str(paragraph.alignment).split("(")[0].strip() if "(" in str(paragraph.alignment) else str(paragraph.alignment)
    except Exception:
        pass
    try:
        if paragraph.space_before:
            style["space_before_pt"] = round(paragraph.space_before / 12700, 1)
    except Exception:
        pass
    try:
        if paragraph.space_after:
            style["space_after_pt"] = round(paragraph.space_after / 12700, 1)
    except Exception:
        pass
    try:
        if paragraph.level is not None:
            style["indent_level"] = paragraph.level
    except Exception:
        pass
    return style


def _extract_fill(shape) -> dict | None:
    """Extract fill properties from a shape."""
    fill_info = {}
    try:
        fill = shape.fill
        if fill.type is not None:
            fill_info["fill_type"] = str(fill.type)
            if str(fill.type) == "SOLID (1)":
                fill_info["fill_type"] = "solid"
                try:
                    fill_info["fill_color"] = _rgb_to_hex(fill.fore_color.rgb)
                except Exception:
                    pass
            elif "GRADIENT" in str(fill.type):
                fill_info["fill_type"] = "gradient"
                try:
                    stops = []
                    for stop in fill.gradient_stops:
                        stop_info = {"position": round(stop.position, 4)}
                        try:
                            stop_info["color"] = _rgb_to_hex(stop.color.rgb)
                        except Exception:
                            pass
                        stops.append(stop_info)
                    if stops:
                        fill_info["gradient_stops"] = stops
                except Exception:
                    pass
            elif "PATTERNED" in str(fill.type):
                fill_info["fill_type"] = "patterned"
    except Exception:
        pass
    return fill_info if fill_info else None


def _extract_line(shape) -> dict | None:
    """Extract line/border properties."""
    line_info = {}
    try:
        line = shape.line
        if line.color and line.color.type is not None:
            try:
                line_info["color"] = _rgb_to_hex(line.color.rgb)
            except Exception:
                pass
        if line.width:
            line_info["width_pt"] = round(line.width / 12700, 2)
        if line.dash_style:
            line_info["dash_style"] = str(line.dash_style)
    except Exception:
        pass
    return line_info if line_info else None


def _extract_text_content(shape, slide) -> list[dict] | None:
    """Extract all text runs with their styles from a shape."""
    if not shape.has_text_frame:
        return None

    paragraphs = []
    for para in shape.text_frame.paragraphs:
        para_info = {
            "style": _extract_paragraph_style(para),
            "runs": []
        }
        for run in para.runs:
            run_info = {
                "text": run.text,
                "style": _extract_font_style(run.font, run=run._r, paragraph=para,
                                             shape=shape, slide=slide)
            }
            para_info["runs"].append(run_info)
        if para_info["runs"]:
            paragraphs.append(para_info)
    return paragraphs if paragraphs else None


def _extract_shape(shape, slide) -> dict:
    """Extract complete shape-level information."""
    info = {
        "shape_type": str(shape.shape_type).split("(")[0].strip() if "(" in str(shape.shape_type) else str(shape.shape_type),
        "name": shape.name,
        "position": {
            "left_inches": _emu_to_inches(shape.left),
            "top_inches": _emu_to_inches(shape.top),
            "width_inches": _emu_to_inches(shape.width),
            "height_inches": _emu_to_inches(shape.height),
        },
    }

    # Shape type specifics
    shape_type_val = shape.shape_type
    if shape_type_val == MSO_SHAPE_TYPE.PICTURE:
        info["content_type"] = "image"
        try:
            info["image_content_type"] = shape.image.content_type
            info["image_size_bytes"] = len(shape.image.blob)
        except Exception:
            pass

    elif shape_type_val == MSO_SHAPE_TYPE.TABLE:
        info["content_type"] = "table"
        try:
            table = shape.table
            info["table"] = {
                "rows": len(table.rows),
                "columns": len(table.columns),
                "cell_styles": []
            }
            # Sample first row and first data row for styling
            for row_idx in range(min(2, len(table.rows))):
                for col_idx in range(len(table.columns)):
                    cell = table.cell(row_idx, col_idx)
                    cell_style = {
                        "row": row_idx, "col": col_idx,
                        "fill": None, "text_style": None
                    }
                    try:
                        if cell.fill and cell.fill.type is not None:
                            cell_style["fill"] = {"fill_color": _rgb_to_hex(cell.fill.fore_color.rgb)}
                    except Exception:
                        pass
                    if cell.text_frame and cell.text_frame.paragraphs:
                        for para in cell.text_frame.paragraphs:
                            for run in para.runs:
                                cell_style["text_style"] = _extract_font_style(
                                    run.font, run=run._r, paragraph=para, shape=shape, slide=slide)
                                break
                            break
                    info["table"]["cell_styles"].append(cell_style)
        except Exception:
            pass

    elif shape_type_val == MSO_SHAPE_TYPE.AUTO_SHAPE:
        info["content_type"] = "shape"
        try:
            info["auto_shape_type"] = str(shape.auto_shape_type)
        except Exception:
            pass

    elif shape_type_val == MSO_SHAPE_TYPE.TEXT_BOX:
        info["content_type"] = "textbox"

    elif shape_type_val == MSO_SHAPE_TYPE.GROUP:
        info["content_type"] = "group"
        try:
            info["group_shapes_count"] = len(shape.shapes)
        except Exception:
            pass

    elif shape_type_val == MSO_SHAPE_TYPE.PLACEHOLDER:
        info["content_type"] = "placeholder"
        try:
            info["placeholder_type"] = str(shape.placeholder_format.type)
        except Exception:
            pass

    # Fill and line for non-picture shapes
    if shape_type_val != MSO_SHAPE_TYPE.PICTURE:
        fill = _extract_fill(shape)
        if fill:
            info["fill"] = fill
        line = _extract_line(shape)
        if line:
            info["line"] = line

    # Text content
    text_content = _extract_text_content(shape, slide)
    if text_content:
        info["text"] = text_content

    # Text frame properties
    if shape.has_text_frame:
        tf = shape.text_frame
        tf_info = {}
        try:
            tf_info["word_wrap"] = tf.word_wrap
        except Exception:
            pass
        try:
            if tf.margin_left is not None:
                tf_info["margin_left_inches"] = _emu_to_inches(tf.margin_left)
            if tf.margin_right is not None:
                tf_info["margin_right_inches"] = _emu_to_inches(tf.margin_right)
            if tf.margin_top is not None:
                tf_info["margin_top_inches"] = _emu_to_inches(tf.margin_top)
            if tf.margin_bottom is not None:
                tf_info["margin_bottom_inches"] = _emu_to_inches(tf.margin_bottom)
        except Exception:
            pass
        if tf_info:
            info["text_frame"] = tf_info

    return info


def _extract_slide_background(slide) -> dict:
    """Extract slide background styling."""
    bg_info = {}
    try:
        bg = slide.background
        fill = bg.fill
        if fill.type is not None:
            fill_type_str = str(fill.type)
            if "SOLID" in fill_type_str:
                bg_info["type"] = "solid"
                try:
                    bg_info["color"] = _rgb_to_hex(fill.fore_color.rgb)
                except Exception:
                    pass
            elif "GRADIENT" in fill_type_str:
                bg_info["type"] = "gradient"
                try:
                    stops = []
                    for stop in fill.gradient_stops:
                        s = {"position": round(stop.position, 4)}
                        try:
                            s["color"] = _rgb_to_hex(stop.color.rgb)
                        except Exception:
                            pass
                        stops.append(s)
                    bg_info["gradient_stops"] = stops
                except Exception:
                    pass
            elif "PICTURE" in fill_type_str or "BACKGROUND" in fill_type_str:
                bg_info["type"] = "image_or_inherited"
    except Exception:
        pass

    # Check if first shape is a full-slide image (common pattern for BG images)
    try:
        shapes = list(slide.shapes)
        if shapes:
            first = shapes[0]
            if first.shape_type == MSO_SHAPE_TYPE.PICTURE:
                w = first.width
                h = first.height
                # If image covers >90% of slide, it's likely a background
                slide_w = slide.part.package.presentation_part.presentation.slide_width
                slide_h = slide.part.package.presentation_part.presentation.slide_height
                if w and h and slide_w and slide_h:
                    coverage = (w * h) / (slide_w * slide_h)
                    if coverage > 0.85:
                        bg_info["type"] = "full_image"
                        bg_info["note"] = "First shape is a near-full-slide image (likely background)"
                        try:
                            bg_info["image_content_type"] = first.image.content_type
                        except Exception:
                            pass
    except Exception:
        pass

    return bg_info if bg_info else {"type": "unknown_or_inherited"}


def _compute_confidence(slide_info: dict) -> float:
    """
    Compute a confidence score (0-100) for how much styling info was extracted.
    Based on: background resolved, shapes with colors, text with fonts.
    """
    score = 0.0
    total_checks = 0

    # Background
    total_checks += 1
    bg_type = slide_info.get("background", {}).get("type", "unknown")
    if bg_type not in ("unknown_or_inherited", "unknown"):
        score += 1

    # Shapes with position info
    shapes = slide_info.get("shapes", [])
    if shapes:
        for s in shapes:
            total_checks += 1
            pos = s.get("position", {})
            if pos.get("left_inches") is not None and pos.get("width_inches") is not None:
                score += 0.5
            # Has fill or text style?
            if s.get("fill") or s.get("text"):
                score += 0.5

    # Text runs with explicit colors/fonts
    text_runs_total = 0
    text_runs_styled = 0
    for s in shapes:
        texts = s.get("text", [])
        if texts:
            for para in texts:
                for run in para.get("runs", []):
                    text_runs_total += 1
                    style = run.get("style", {})
                    if style.get("color") or style.get("font_name"):
                        text_runs_styled += 1

    if text_runs_total > 0:
        total_checks += text_runs_total
        score += text_runs_styled

    if total_checks == 0:
        return 0.0
    return round((score / total_checks) * 100, 1)


def _build_global_palette(slide_templates: list[dict]) -> dict:
    """Aggregate colors and fonts across all slides into a global palette."""
    colors = Counter()
    fonts = Counter()
    font_sizes = Counter()

    for st in slide_templates:
        for shape in st.get("shapes", []):
            # Fill colors
            fill = shape.get("fill", {})
            if fill.get("fill_color"):
                colors[fill["fill_color"]] += 1
            if fill.get("gradient_stops"):
                for stop in fill["gradient_stops"]:
                    if stop.get("color"):
                        colors[stop["color"]] += 1

            # Line colors
            line = shape.get("line", {})
            if line.get("color"):
                colors[line["color"]] += 1

            # Text styles
            for para in shape.get("text", []):
                for run in para.get("runs", []):
                    style = run.get("style", {})
                    if style.get("color"):
                        colors[style["color"]] += 1
                    if style.get("font_name"):
                        fonts[style["font_name"]] += 1
                    if style.get("font_size_pt"):
                        font_sizes[style["font_size_pt"]] += 1

    return {
        "colors": [{"hex": c, "count": n} for c, n in colors.most_common(20)],
        "fonts": [{"name": f, "count": n} for f, n in fonts.most_common(10)],
        "font_sizes": [{"pt": s, "count": n} for s, n in font_sizes.most_common(15)],
        "primary_color": colors.most_common(1)[0][0] if colors else None,
        "primary_font": fonts.most_common(1)[0][0] if fonts else None,
    }


def analyze_presentation(pptx_path: str, auto_screenshot: bool = True,
                         screenshot_dir: str | None = None) -> dict:
    """
    Analyze a PPTX file and extract a complete style library.

    Args:
        pptx_path: Path to the PPTX file.
        auto_screenshot: If True, automatically render screenshots for slides
            with confidence < 60%. Screenshots are saved as PNGs.
        screenshot_dir: Directory to save screenshots. Defaults to a
            'screenshots' subdirectory next to the PPTX file.

    Returns:
        {
            "file": str,
            "slide_dimensions": {width_inches, height_inches},
            "total_slides": int,
            "global_palette": {colors, fonts, font_sizes, primary_color, primary_font},
            "slide_templates": [
                {
                    "slide_index": int,
                    "background": {...},
                    "shapes": [{shape details}],
                    "confidence_pct": float,
                    "needs_screenshot": bool,
                    "screenshot_path": str | None
                }
            ],
            "overall_confidence_pct": float,
            "slides_needing_screenshot": [int],
            "screenshots": [{"slide_index": int, "image_path": str, "backend": str}]
        }
    """
    from .slide_renderer import render_slides

    prs = Presentation(pptx_path)

    result = {
        "file": str(pptx_path),
        "slide_dimensions": {
            "width_inches": _emu_to_inches(prs.slide_width),
            "height_inches": _emu_to_inches(prs.slide_height),
        },
        "total_slides": len(prs.slides),
        "slide_templates": [],
    }

    for idx, slide in enumerate(prs.slides):
        slide_info = {
            "slide_index": idx,
            "background": _extract_slide_background(slide),
            "shapes": [],
            "screenshot_path": None,
        }

        for shape in slide.shapes:
            shape_info = _extract_shape(shape, slide)
            slide_info["shapes"].append(shape_info)

        confidence = _compute_confidence(slide_info)
        slide_info["confidence_pct"] = confidence
        slide_info["needs_screenshot"] = confidence < 60.0

        result["slide_templates"].append(slide_info)

    # Global palette
    result["global_palette"] = _build_global_palette(result["slide_templates"])

    # Overall confidence
    confidences = [s["confidence_pct"] for s in result["slide_templates"]]
    result["overall_confidence_pct"] = round(sum(confidences) / len(confidences), 1) if confidences else 0.0
    result["slides_needing_screenshot"] = [
        s["slide_index"] for s in result["slide_templates"] if s["needs_screenshot"]
    ]

    # Auto-screenshot for low-confidence slides
    result["screenshots"] = []
    if auto_screenshot and result["slides_needing_screenshot"]:
        if screenshot_dir is None:
            screenshot_dir = str(Path(pptx_path).parent / "screenshots")

        rendered = render_slides(
            pptx_path,
            output_dir=screenshot_dir,
            slide_indices=result["slides_needing_screenshot"],
            width=1920,
        )
        result["screenshots"] = rendered

        # Attach screenshot paths to slide templates
        path_map = {r["slide_index"]: r["image_path"] for r in rendered}
        for st in result["slide_templates"]:
            if st["slide_index"] in path_map:
                st["screenshot_path"] = path_map[st["slide_index"]]

    return result
