"""
pptx-creator-mcp -- An MCP server for creating, analyzing, and rendering
professional PPTX presentations.
"""

__version__ = "0.1.0"
