"""Core MCP tools for Summary Stack search and discovery.

These tools are designed to be imported and registered by connector-specific
MCP servers (e.g., Obsidian, Notion). They provide search, listing, and
discovery capabilities across the user's Summary Stacks via the API.
"""

import logging
from collections.abc import Awaitable, Callable

from .api_client import SummaryStackCoreAPIClient, SummaryStackCoreAPIError
from .config import load_config


logger = logging.getLogger(__name__)


async def _with_client[T](
    operation: str,
    fn: Callable[[SummaryStackCoreAPIClient], Awaitable[T]],
) -> T | str:
    """Execute API operation with standard config/client setup and error handling.

    Args:
        operation: Human-readable operation name for error messages
        fn: Async function that receives the client and returns a result

    Returns:
        Result from fn, or error message string on failure
    """
    config = load_config()
    client = SummaryStackCoreAPIClient(config.api_url, config.api_key)
    try:
        return await fn(client)
    except SummaryStackCoreAPIError as e:
        logger.error(f"{operation} failed: {e}")
        return f"{operation} failed: {e}"


async def search_corpus(query: str, limit: int = 10) -> str:
    """Search your Summary Stack corpus (library and knowledge graph).

    Searches both your Summary Stack library (vector similarity) and
    knowledge graph (Neo4J entities) to find relevant content matching
    your query. Returns deduplicated, merged results with executive
    summaries and key insights.

    Args:
        query: Search query (what you're looking for)
        limit: Maximum number of results to return (default: 10)

    Returns:
        Formatted search results with titles, summaries, and matching content
    """

    async def _search(client: SummaryStackCoreAPIClient) -> str:
        response = await client.search_corpus(query=query, limit=limit)

        if not response.results:
            return f"No stacks found matching '{query}'"

        lines = [f"Found {len(response.results)} stack(s) matching '{query}':\n"]

        for i, result in enumerate(response.results, 1):
            lines.append(f"{i}. **{result.title}**")
            lines.append(f"   ID: {result.summary_stack_id}")
            lines.append(f"   Source: {result.source_domain or result.uri}")

            if result.search_source:
                source_label = "Vector Search" if result.search_source == "rag" else "Knowledge Graph"
                lines.append(f"   Found via: {source_label}")

            if result.similarity is not None:
                similarity_pct = int(result.similarity * 100)
                lines.append(f"   Relevance: {similarity_pct}%")

            if result.executive_summary:
                summary_preview = result.executive_summary[:200] + "..." if len(result.executive_summary) > 200 else result.executive_summary
                lines.append(f"   Summary: {summary_preview}")

            if result.key_insights:
                lines.append("   Key Insights:")
                for insight in result.key_insights[:3]:
                    lines.append(f"   - {insight}")

            if result.matching_chunks:
                chunk_preview = result.matching_chunks[0][:150]
                lines.append(f'   Matching content: "{chunk_preview}..."')

            lines.append("")

        return "\n".join(lines)

    return await _with_client("Corpus search", _search)


async def get_stack(stack_id: str) -> str:
    """Get full details of a specific Summary Stack.

    Retrieves the complete summary stack including title, executive summary,
    key insights, and source information.

    Args:
        stack_id: The UUID of the summary stack to retrieve

    Returns:
        Formatted stack details with all available information
    """

    async def _get(client: SummaryStackCoreAPIClient) -> str:
        stack = await client.get_stack(stack_id)

        lines = [
            f"# {stack.title or 'Untitled'}",
            f"**ID:** {stack.summary_stack_id}",
            "",
        ]

        if stack.source_metadata:
            meta = stack.source_metadata
            if meta.source_domain:
                lines.append(f"**Source:** {meta.source_domain}")
            if meta.uri:
                lines.append(f"**URL:** {meta.uri}")
            lines.append("")

        if stack.executive_summary:
            lines.append("## Summary")
            lines.append(stack.executive_summary.summary or "")
            lines.append("")

            if stack.executive_summary.bullets:
                lines.append("## Key Insights")
                for bullet in stack.executive_summary.bullets:
                    text = bullet.text if hasattr(bullet, "text") else str(bullet)
                    lines.append(f"- {text}")
                lines.append("")

        return "\n".join(lines)

    return await _with_client("Get stack", _get)


async def list_stacks(limit: int = 20, offset: int = 0) -> str:
    """List your most recent Summary Stacks.

    Returns a paginated list of your stacks ordered by creation date
    (newest first). Use offset for pagination through large collections.

    Args:
        limit: Maximum number of stacks to return (default: 20)
        offset: Number of stacks to skip for pagination (default: 0)

    Returns:
        Formatted list of stacks with titles and summaries
    """

    async def _list(client: SummaryStackCoreAPIClient) -> str:
        response = await client.list_stacks(limit=limit, offset=offset)

        if not response.items:
            return "No Summary Stacks found"

        lines = [f"Found {response.total} stack(s) (showing {len(response.items)}):\n"]

        for i, item in enumerate(response.items, offset + 1):
            lines.append(f"{i}. **{item.title}**")
            lines.append(f"   ID: {item.summary_stack_id}")

            if item.source_domain:
                lines.append(f"   Source: {item.source_domain}")

            if item.summary:
                lines.append(f"   {item.summary}")

            lines.append("")

        if response.total > offset + len(response.items):
            remaining = response.total - (offset + len(response.items))
            lines.append(f"... and {remaining} more. Use offset={offset + limit} to see next page.")

        return "\n".join(lines)

    return await _with_client("List stacks", _list)
