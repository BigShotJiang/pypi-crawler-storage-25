---
name: zotcli
description: Read-only CLI for querying, browsing, and exporting a local Zotero library (SQLite). Search by title, author, tag, DOI, or year; browse collections; resolve PDF attachment paths; export to JSON/CSV/BibTeX/Markdown. Use when asked to find papers, list references, get PDF paths, or export a Zotero collection.
---

# zotcli (`zot`)

A read-only Python CLI for your local Zotero library. Queries the SQLite database directly — no Zotero app or API key needed. Never writes to the database.

## Installation

```bash
# Install globally or in a virtual environment
pip install zotcli

# Verify
zot --help
```

**Dependencies installed automatically:** `click`, `rich`, `pydantic`, `python-dateutil`, `platformdirs`

Optional extras:
```bash
pip install "zotcli[export]"   # adds jinja2 for Markdown templates
pip install "zotcli[bibtex]"   # adds pybtex
```

## Database path

The database is auto-detected. On this machine it resolves to:

```
~/Zotero/zotero.sqlite
```

Override with `--db` if needed:
```bash
zot --db ~/Zotero/zotero.sqlite stats
```

Or set it permanently in `~/.config/zotcli/config.toml`:
```toml
[database]
path = "~/Zotero/zotero.sqlite"
```

## Quick orientation

```bash
zot stats              # Library summary: 3,771 items, 200 collections, 3,201 tags
zot stats types        # Break down by item type
zot stats years        # Publication year histogram
zot collections list   # Full collection tree
```

---

## Core workflow: search → inspect → get attachment paths

### Step 1 — Search by title keyword

```bash
zot search "bayesian" --field title
```

Output:
```
                  5 result(s)
 #   Key        Type               Title                                   Authors           Year
 1   LVTG4KLQ   journalArticle     An Improved Recursive Bayesian …        Chen et al.       2013
 2   6BR3CYQA   conferencePaper    Bayesian distribution system state …    Angioni et al.    2016
 3   K2YXXPX7   journalArticle     A Recursive Bayesian Approach for …     Singh et al.      2010
 4   CRJWMH2X   journalArticle     Real-Time Topology Estimation … Graph…  Liu et al.        2023
 5   TJH8CGUT   conferencePaper    Bayesian Methods for the Identific…     Brouillon et al.  2021
```

### Step 2 — Search by author name

Author search queries the creators table directly (first name or last name, partial match):

```bash
zot search --author "Numair"
```

```
                  12 result(s)
 #   Key        Type               Title                                        Authors        Year
 1   BRRZZRLD   journalArticle     Applications of IoT and digital twin …       Mansour et al. 2023
 2   MDLX3G4P   conferencePaper    A Proposed IoT Architecture for …            Numair et al.  2020
 3   W3P98AE9   conferencePaper    On the UK smart metering system …            Numair et al.  2023
 4   UIMHSHNV   journalArticle     Fault Detection and Localisation in LV …     Numair et al.  2023
 5   TAVRNAY6   bookSection        Infrastructure for the 4th Industrial …      Numair et al.  2024
 6   5UFZMSLU   journalArticle     UNLOCKING DATA CENTRE HOSTING CAPACITY …     Numair et al.  2026
 …
```

### Step 3 — Inspect a single item

Use the `Key` from the table (e.g. `5UFZMSLU`):

```bash
zot items show 5UFZMSLU
```

Shows a full detail panel: title, authors, year, journal, DOI, tags, collections, and attached files with existence status.

### Step 4 — Get the PDF path for a single item

```bash
zot attachments path 5UFZMSLU
```

```
~/Zotero/storage/RIB344FW/Numair et al. - 2026 - UNLOCKING DATA CENTRE HOSTING CAPACITY AND FLEXIBILITY THROUGH DYNAMIC CABLE RATING.pdf
```

### Step 5 — Batch: get paths for all items from a search

#### Shell loop (interactive)

```bash
# Get all PDF paths for items with "bayesian" in the title
for key in LVTG4KLQ 6BR3CYQA K2YXXPX7 CRJWMH2X TJH8CGUT; do
    zot attachments path "$key" 2>/dev/null
done
```

#### Python script (programmatic)

```python
import sys

from zotcli.db import ZoteroDatabase
from zotcli.queries.search import search_items, search_by_author
from zotcli.queries.attachments import get_attachments_for_item, enrich_attachment_paths

DB = "~/Zotero/zotero.sqlite"

with ZoteroDatabase(DB) as db:
    data_dir = db.path.parent

    # --- Find items with "bayesian" in title ---
    bayesian_items = search_items(db, "bayesian", fields=["title"])

    # --- Find items by author "Numair" ---
    numair_items = search_by_author(db, "Numair")

    # Combine, deduplicate by item_id
    all_items = {i.item_id: i for i in bayesian_items + numair_items}.values()

    print(f"Found {len(list(all_items))} unique items\n")

    for item in all_items:
        atts = get_attachments_for_item(db, item.item_id)
        enrich_attachment_paths(atts, data_dir)
        pdfs = [a for a in atts if a.file_exists and "pdf" in a.content_type.lower()]
        for pdf in pdfs:
            print(f"{item.key}\t{item.title[:60]}\t{pdf.absolute_path}")
```

Example output:
```
Found 17 unique items

LVTG4KLQ    An Improved Recursive Bayesian Approach…    ~/Zotero/storage/ABC12345/Chen2013.pdf
5UFZMSLU    UNLOCKING DATA CENTRE HOSTING CAPACITY…     ~/Zotero/storage/RIB344FW/Numair et al. - 2026 - UNLOCKING…pdf
…
```


---

## All commands at a glance

```bash
# Stats
zot stats
zot stats types | tags [--top N] | years | collections [--top N]

# Collections
zot collections list [--flat]
zot collections show <id|name>
zot collections items <id|name> [--recursive] [--type journalArticle]

# Items
zot items list [--type TYPE] [--collection NAME] [--limit N]
zot items show <id|key>
zot items attachments <id|key>
zot items notes <id|key>

# Search
zot search "query" [--field title] [--field abstract] [--type TYPE]
zot search --author "Name"
zot search --doi 10.xxxx/yyyy
zot search --tag "tag-name"
zot search --year 2020-2024
zot search "query" --fulltext

# Attachments
zot attachments list [--missing] [--type pdf]
zot attachments path <id|key>
zot attachments open <id|key>

# Export
zot export json|csv|bib|markdown --collection "Name" [--output file]
zot export json|csv|bib|markdown --all [--output file]
zot export markdown --all --notes --output report.md
```

Full reference: [`docs/commands.md`](docs/commands.md)

---

## Safety guarantees

- Database opened in **strict read-only URI mode** (`sqlite3://…?mode=ro`) — impossible to corrupt your Zotero library
- WAL journal detection: warns if Zotero is currently running (changes may not be visible yet)
- No network access, no Zotero API calls

## Running tests

```bash
python3 -m pytest tests/ -q          # 38 unit + integration tests (in-memory DB fixture)
python3 -m pytest tests/e2e -m e2e   # End-to-end against real zotero.sqlite (slow)
```
