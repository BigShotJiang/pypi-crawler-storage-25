"""zotcli — A read-only CLI for browsing and exporting a Zotero library."""

__version__ = "0.1.0"
