"""Root Click group and shared context."""

from __future__ import annotations

import warnings
from pathlib import Path

import click

from zotcli.db import ZoteroDatabase, discover_db
from zotcli.config import get_db_path, get_library_id


class Context:
    def __init__(self, db: ZoteroDatabase, library_id: int, fmt: str, color: bool):
        self.db = db
        self.library_id = library_id
        self.fmt = fmt
        self.color = color


pass_ctx = click.make_pass_decorator(Context)


@click.group()
@click.option("--db", "db_path", default=None, help="Path to zotero.sqlite")
@click.option("--library", "library_id", default=None, type=int, help="Library ID (default: 1)")
@click.option(
    "--format",
    "fmt",
    default="table",
    type=click.Choice(["table", "json", "csv"]),
    help="Output format",
)
@click.option("--no-color", is_flag=True, default=False, help="Disable colour output")
@click.pass_context
def cli(ctx: click.Context, db_path: str | None, library_id: int | None, fmt: str, no_color: bool):
    """zot — read-only CLI for your Zotero library."""
    resolved_path = get_db_path(db_path)
    if resolved_path is None:
        try:
            resolved_path = discover_db()
        except FileNotFoundError as e:
            raise click.ClickException(str(e))

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        db = ZoteroDatabase(resolved_path, warn_if_open=True)

    for w in caught:
        click.echo(f"[warning] {w.message}", err=True)

    lib_id = get_library_id(library_id)
    ctx.obj = Context(db=db, library_id=lib_id, fmt=fmt, color=not no_color)
    ctx.call_on_close(db.close)


# Import and register subcommand groups
from zotcli.cli import collections as _col_mod  # noqa: E402
from zotcli.cli import items as _items_mod  # noqa: E402
from zotcli.cli import attachments as _att_mod  # noqa: E402
from zotcli.cli import search as _search_mod  # noqa: E402
from zotcli.cli import stats as _stats_mod  # noqa: E402
from zotcli.cli import export as _export_mod  # noqa: E402

cli.add_command(_col_mod.collections)
cli.add_command(_items_mod.items)
cli.add_command(_att_mod.attachments)
cli.add_command(_search_mod.search)
cli.add_command(_stats_mod.stats)
cli.add_command(_export_mod.export)
