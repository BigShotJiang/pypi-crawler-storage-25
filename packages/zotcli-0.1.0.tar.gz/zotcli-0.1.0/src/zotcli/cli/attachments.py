"""CLI — `zot attachments` subcommands."""

from __future__ import annotations

import subprocess
import sys

import click
from rich.table import Table

from zotcli.cli.main import pass_ctx, Context
from zotcli.cli.render import make_console
from zotcli.models import Attachment
from zotcli.queries.attachments import enrich_attachment_paths
from zotcli.queries.items import get_item


@click.group()
def attachments():
    """Browse and open Zotero attachments."""


@attachments.command("list")
@click.option("--missing", is_flag=True, help="Only show missing files")
@click.option("--type", "content_type", default=None, help="Filter by content type (e.g. pdf)")
@pass_ctx
def list_attachments(ctx: Context, missing: bool, content_type: str | None):
    """List all attachments."""
    console = make_console(ctx.color)
    data_dir = ctx.db.path.parent

    rows = ctx.db.fetchall(
        """
        SELECT i.itemID, i.key, ia.parentItemID, ia.linkMode,
               ia.contentType, ia.path
        FROM itemAttachments ia
        JOIN items i ON ia.itemID = i.itemID
        WHERE ia.parentItemID IS NOT NULL
        ORDER BY ia.contentType
        """
    )

    atts = [
        Attachment(
            item_id=r["itemID"],
            key=r["key"],
            parent_item_id=r["parentItemID"],
            link_mode=r["linkMode"] if r["linkMode"] is not None else 0,
            content_type=r["contentType"] or "",
            path=r["path"],
        )
        for r in rows
    ]
    enrich_attachment_paths(atts, data_dir)

    if content_type:
        atts = [a for a in atts if content_type.lower() in a.content_type.lower()]
    if missing:
        atts = [a for a in atts if not a.file_exists]

    if not atts:
        console.print("[dim]No attachments found.[/dim]")
        return

    t = Table(title=f"{len(atts)} attachments")
    t.add_column("Key", style="cyan", width=10)
    t.add_column("Type", width=20)
    t.add_column("Mode", width=14)
    t.add_column("Exists", width=7)
    t.add_column("Path")

    for att in atts[:500]:
        exists = "[green]✓[/green]" if att.file_exists else "[red]✗[/red]"
        path_str = str(att.absolute_path) if att.absolute_path else att.path or ""
        t.add_row(att.key, att.content_type, att.link_mode_name, exists, path_str[:80])
    console.print(t)
    if len(atts) > 500:
        console.print(f"[dim]... and {len(atts) - 500} more[/dim]")


@attachments.command("path")
@click.argument("id_or_key")
@pass_ctx
def attachment_path(ctx: Context, id_or_key: str):
    """Print the resolved absolute path(s) for an item's attachments."""
    item_id_val = int(id_or_key) if id_or_key.isdigit() else id_or_key
    item = get_item(ctx.db, item_id_val)
    if item is None:
        raise click.ClickException(f"Item not found: {id_or_key!r}")

    for att in item.attachments:
        if att.absolute_path:
            click.echo(str(att.absolute_path))


@attachments.command("open")
@click.argument("id_or_key")
@pass_ctx
def open_attachment(ctx: Context, id_or_key: str):
    """Open the first attachment with the system default application."""
    item_id_val = int(id_or_key) if id_or_key.isdigit() else id_or_key
    item = get_item(ctx.db, item_id_val)
    if item is None:
        raise click.ClickException(f"Item not found: {id_or_key!r}")

    existing = [a for a in item.attachments if a.file_exists and a.absolute_path]
    if not existing:
        raise click.ClickException("No local files found for this item.")

    path = existing[0].absolute_path
    click.echo(f"Opening: {path}")

    if sys.platform == "win32":
        import os
        os.startfile(str(path))
    elif sys.platform == "darwin":
        subprocess.run(["open", str(path)])
    else:
        opener = "wslview" if _which("wslview") else "xdg-open"
        subprocess.run([opener, str(path)])


def _which(cmd: str) -> bool:
    import shutil
    return shutil.which(cmd) is not None
