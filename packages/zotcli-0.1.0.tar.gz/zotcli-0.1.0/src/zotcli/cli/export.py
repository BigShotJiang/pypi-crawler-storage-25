"""CLI — `zot export` subcommands."""

from __future__ import annotations

import sys

import click
from rich.progress import Progress, SpinnerColumn, TextColumn

from zotcli.cli.main import pass_ctx, Context
from zotcli.cli.render import make_console
from zotcli.queries.items import get_items
from zotcli.queries.collections import get_collection_by_name, get_collection_by_id, get_items_in_collection


def _get_items(ctx: Context, collection: str | None, all_items: bool) -> tuple[list, object | None]:
    """Return (items, collection_obj|None)."""
    if collection:
        if collection.isdigit():
            col = get_collection_by_id(ctx.db, int(collection))
        else:
            matches = get_collection_by_name(ctx.db, collection, fuzzy=True)
            col = matches[0] if matches else None
        if col is None:
            raise click.ClickException(f"Collection not found: {collection!r}")
        return get_items_in_collection(ctx.db, col.collection_id), col
    if all_items:
        return get_items(ctx.db, library_id=ctx.library_id), None
    raise click.UsageError("Provide --collection NAME or --all.")


@click.group("export")
def export():
    """Export items to various formats."""


@export.command("json")
@click.option("--collection", "-c", default=None, help="Export a specific collection")
@click.option("--all", "all_items", is_flag=True, help="Export entire library")
@click.option("--output", "-o", default=None, help="Output file (default: stdout)")
@pass_ctx
def export_json(ctx: Context, collection: str | None, all_items: bool, output: str | None):
    """Export items as JSON."""
    from zotcli.export.json_ import items_to_json
    items, _ = _get_items(ctx, collection, all_items)
    fp = open(output, "w", encoding="utf-8") if output else sys.stdout
    try:
        items_to_json(items, fp)
        if output:
            make_console(ctx.color).print(f"[green]Exported {len(items)} items to {output}[/green]")
    finally:
        if output:
            fp.close()


@export.command("csv")
@click.option("--collection", "-c", default=None)
@click.option("--all", "all_items", is_flag=True)
@click.option("--output", "-o", default=None)
@pass_ctx
def export_csv(ctx: Context, collection: str | None, all_items: bool, output: str | None):
    """Export items as CSV."""
    from zotcli.export.csv_ import items_to_csv
    items, _ = _get_items(ctx, collection, all_items)
    fp = open(output, "w", newline="", encoding="utf-8") if output else sys.stdout
    try:
        items_to_csv(items, fp)
        if output:
            make_console(ctx.color).print(f"[green]Exported {len(items)} items to {output}[/green]")
    finally:
        if output:
            fp.close()


@export.command("bib")
@click.option("--collection", "-c", default=None)
@click.option("--all", "all_items", is_flag=True)
@click.option("--output", "-o", default=None)
@pass_ctx
def export_bib(ctx: Context, collection: str | None, all_items: bool, output: str | None):
    """Export items as BibTeX."""
    from zotcli.export.bibtex import items_to_bibtex
    items, _ = _get_items(ctx, collection, all_items)
    fp = open(output, "w", encoding="utf-8") if output else sys.stdout
    try:
        items_to_bibtex(items, fp)
        if output:
            make_console(ctx.color).print(f"[green]Exported {len(items)} items to {output}[/green]")
    finally:
        if output:
            fp.close()


@export.command("markdown")
@click.option("--collection", "-c", default=None)
@click.option("--all", "all_items", is_flag=True)
@click.option("--output", "-o", default=None)
@click.option("--notes", is_flag=True, help="Include notes sections")
@pass_ctx
def export_markdown(ctx: Context, collection: str | None, all_items: bool, output: str | None, notes: bool):
    """Export items as a Markdown report."""
    from zotcli.export.markdown import items_to_markdown
    items, col = _get_items(ctx, collection, all_items)
    fp = open(output, "w", encoding="utf-8") if output else sys.stdout
    try:
        items_to_markdown(items, collection=col, include_notes=notes, fp=fp)
        if output:
            make_console(ctx.color).print(f"[green]Exported {len(items)} items to {output}[/green]")
    finally:
        if output:
            fp.close()
