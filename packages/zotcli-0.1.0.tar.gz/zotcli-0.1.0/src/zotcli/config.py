"""Configuration — auto-detection and persistence via TOML."""

from __future__ import annotations

import sys
from pathlib import Path

try:
    import tomllib  # Python 3.11+
except ImportError:
    try:
        import tomli as tomllib  # type: ignore[no-redef]
    except ImportError:
        tomllib = None  # type: ignore[assignment]


def _config_dir() -> Path:
    from platformdirs import user_config_dir
    return Path(user_config_dir("zotcli", appauthor=False))


def _config_path() -> Path:
    return _config_dir() / "config.toml"


_DEFAULTS: dict = {
    "database": {
        "path": None,
        "library_id": 1,
    },
    "output": {
        "default_format": "table",
        "color": True,
        "page_size": 50,
    },
}


def load_config() -> dict:
    """Load config from disk, merging with defaults."""
    cfg = {k: dict(v) for k, v in _DEFAULTS.items()}
    p = _config_path()
    if p.exists() and tomllib is not None:
        with open(p, "rb") as f:
            on_disk = tomllib.load(f)
        for section, values in on_disk.items():
            if section in cfg and isinstance(values, dict):
                cfg[section].update(values)
            else:
                cfg[section] = values
    return cfg


def save_config(cfg: dict) -> None:
    """Persist config to disk (TOML format)."""
    import tomli_w  # type: ignore[import]
    p = _config_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "wb") as f:
        tomli_w.dump(cfg, f)


def get_db_path(override: str | None = None) -> Path | None:
    """Return the database path from override > config > None."""
    if override:
        return Path(override)
    cfg = load_config()
    raw = cfg.get("database", {}).get("path")
    if raw:
        return Path(raw)
    return None


def get_library_id(override: int | None = None) -> int:
    if override is not None:
        return override
    cfg = load_config()
    return cfg.get("database", {}).get("library_id", 1)
