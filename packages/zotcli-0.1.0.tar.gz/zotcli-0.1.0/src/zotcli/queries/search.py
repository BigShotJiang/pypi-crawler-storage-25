"""Search queries — field-level and full-text."""

from __future__ import annotations

from zotcli.db import ZoteroDatabase
from zotcli.models import Item
from zotcli.queries.items import _build_items


def search_items(
    db: ZoteroDatabase,
    query: str,
    fields: list[str] | None = None,
    item_type: str | None = None,
) -> list[Item]:
    """Search item field values. If fields is None, search all fields."""
    like = f"%{query}%"

    if fields:
        placeholders = ",".join("?" * len(fields))
        field_clause = f"AND f.fieldName IN ({placeholders})"
        field_params: tuple = tuple(fields)
    else:
        field_clause = ""
        field_params = ()

    type_clause = ""
    type_params: tuple = ()
    if item_type:
        type_clause = "AND it.typeName = ?"
        type_params = (item_type,)

    sql = f"""
        SELECT DISTINCT i.itemID
        FROM items i
        JOIN itemTypes it ON i.itemTypeID = it.itemTypeID
        LEFT JOIN itemData id ON i.itemID = id.itemID
        LEFT JOIN fields f ON id.fieldID = f.fieldID
        LEFT JOIN itemDataValues idv ON id.valueID = idv.valueID
        WHERE i.itemID NOT IN (SELECT itemID FROM itemNotes)
          AND i.itemID NOT IN (SELECT itemID FROM itemAttachments)
          AND idv.value LIKE ?
          {field_clause}
          {type_clause}
        ORDER BY i.dateAdded DESC
    """
    params = (like,) + field_params + type_params
    rows = db.fetchall(sql, params)
    return _build_items(db, [r["itemID"] for r in rows])


def search_fulltext(db: ZoteroDatabase, query: str) -> list[Item]:
    """Search the full-text index (fulltextWords table)."""
    words = query.lower().split()
    if not words:
        return []

    # Each word must appear in the same item
    word_subqueries = " AND ".join(
        f"EXISTS (SELECT 1 FROM fulltextWords fw{i} JOIN fulltextItems fi{i} "
        f"ON fw{i}.wordID = fi{i}.wordID WHERE fi{i}.itemID = i.itemID "
        f"AND fw{i}.word LIKE ?)"
        for i in range(len(words))
    )
    params = tuple(f"%{w}%" for w in words)

    sql = f"""
        SELECT DISTINCT i.itemID
        FROM items i
        WHERE i.itemID NOT IN (SELECT itemID FROM itemNotes)
          AND i.itemID NOT IN (SELECT itemID FROM itemAttachments)
          AND {word_subqueries}
        ORDER BY i.dateAdded DESC
    """
    try:
        rows = db.fetchall(sql, params)
        return _build_items(db, [r["itemID"] for r in rows])
    except Exception:
        # fulltextWords may not be populated; fall back to field search
        return search_items(db, query)


def search_by_doi(db: ZoteroDatabase, doi: str) -> Item | None:
    # Normalise: strip https://doi.org/ prefix
    doi = doi.strip()
    for prefix in ("https://doi.org/", "http://doi.org/", "doi:"):
        if doi.lower().startswith(prefix):
            doi = doi[len(prefix):]

    rows = db.fetchall(
        """
        SELECT DISTINCT id.itemID
        FROM itemData id
        JOIN fields f ON id.fieldID = f.fieldID
        JOIN itemDataValues idv ON id.valueID = idv.valueID
        WHERE f.fieldName = 'DOI' AND LOWER(idv.value) = LOWER(?)
        """,
        (doi,),
    )
    if not rows:
        return None
    items = _build_items(db, [rows[0]["itemID"]])
    return items[0] if items else None


def search_by_author(db: ZoteroDatabase, query: str) -> list[Item]:
    """Search items by creator first or last name (case-insensitive, partial match)."""
    like = f"%{query}%"
    rows = db.fetchall(
        """
        SELECT DISTINCT ic.itemID
        FROM itemCreators ic
        JOIN creators c ON ic.creatorID = c.creatorID
        WHERE c.lastName LIKE ? OR c.firstName LIKE ?
        """,
        (like, like),
    )
    return _build_items(db, [r["itemID"] for r in rows])


def search_by_year_range(db: ZoteroDatabase, start: int, end: int) -> list[Item]:
    rows = db.fetchall(
        """
        SELECT DISTINCT id.itemID
        FROM itemData id
        JOIN fields f ON id.fieldID = f.fieldID
        JOIN itemDataValues idv ON id.valueID = idv.valueID
        WHERE f.fieldName = 'date'
          AND CAST(SUBSTR(idv.value, 1, 4) AS INTEGER) BETWEEN ? AND ?
        """,
        (start, end),
    )
    return _build_items(db, [r["itemID"] for r in rows])
