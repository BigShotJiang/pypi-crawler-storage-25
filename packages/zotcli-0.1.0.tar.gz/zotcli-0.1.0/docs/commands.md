# `zot` — Command Reference

All commands share global options that must come **before** the subcommand:

```
zot [--db PATH] [--library ID] [--format table|json|csv] [--no-color] <command>
```

| Global option | Default | Description |
|---|---|---|
| `--db PATH` | auto-detected | Path to `zotero.sqlite` |
| `--library INT` | `1` | Library ID (1 = personal library) |
| `--format` | `table` | Output format for list views |
| `--no-color` | off | Disable Rich colour output |

Auto-detection order: `~/.config/zotcli/config.toml` → `/mnt/c/Users/<user>/Zotero/zotero.sqlite` (WSL) → `~/Zotero/zotero.sqlite`.

---

## `zot stats`

Library statistics dashboard.

```bash
zot stats                  # Overall summary (item count, collections, tags, creators)
zot stats summary          # Same as above
zot stats types            # Items per item type (journalArticle, book, …)
zot stats tags [--top N]   # Top N tags by frequency (default: 20)
zot stats years            # Publication year histogram
zot stats collections [--top N]  # Collections by item count (default: 20)
```

---

## `zot collections`

Browse the collection tree.

```bash
zot collections list               # Rich tree view of all collections
zot collections list --flat        # Flat table: ID, Key, Name, Parent, Item count

zot collections show <id|name>     # Details for one collection
zot collections show "Energy Market"

zot collections items <id|name>               # Items in a collection
zot collections items "Energy Market"
zot collections items 42 --recursive          # Include all sub-collections
zot collections items "NLP" --type journalArticle  # Filter by item type
```

`<id|name>` accepts a numeric collection ID or an exact/fuzzy collection name.

---

## `zot items`

Browse individual items.

```bash
zot items list                             # Paginated item list (default: 50)
zot items list --limit 100                 # Override page size
zot items list --type journalArticle       # Filter by item type
zot items list --collection "Energy Market"

zot items show <id|key>                    # Full detail panel for one item
zot items show 1234
zot items show AABB0001

zot items attachments <id|key>             # Attachments with path + existence check
zot items notes <id|key>                   # Attached notes (HTML stripped)
```

`<id|key>` accepts a numeric item ID or the 8-character Zotero key (e.g. `AABB0001`).

---

## `zot search`

Search across fields, authors, tags, DOIs, and years.

```bash
# General field search (all fields if no --field given)
zot search "deep learning"
zot search "bayesian" --field title
zot search "state estimation" --field title --field abstract
zot search "power flow" --type journalArticle

# Author search (queries creators table — first/last name, partial match)
zot search --author "Smith"
zot search --author "Smith" --type conferencePaper

# Exact DOI lookup
zot search --doi 10.1038/example
zot search --doi "https://doi.org/10.1109/TPWRS.2023.1234"

# Tag filter
zot search --tag "machine-learning"

# Year range
zot search --year 2023          # Single year
zot search --year 2020-2024     # Range (inclusive)

# Full-text index (uses Zotero's fulltextWords table — requires Zotero to have indexed files)
zot search "demand response" --fulltext
```

### Search fields reference

Common `--field` values:

| Field name | Description |
|---|---|
| `title` | Item title |
| `abstract` | Abstract / short description |
| `publicationTitle` | Journal or conference name |
| `publisher` | Publisher |
| `place` | Place of publication |
| `date` | Date string (use `--year` for year filtering) |
| `DOI` | Digital Object Identifier |
| `url` | URL |
| `extra` | Extra / notes field |
| `volume` | Volume |
| `issue` | Issue |
| `pages` | Page range |

---

## `zot attachments`

Browse and open local attachment files.

```bash
zot attachments list                        # All attachments with resolved paths
zot attachments list --missing              # Only attachments where the file is absent
zot attachments list --type pdf             # Filter by content type (partial match)

zot attachments path <id|key>               # Print absolute path(s) for an item's attachments
zot attachments open <id|key>               # Open first attachment with system default app
                                            # (uses wslview on WSL, open on macOS, xdg-open on Linux)
```

---

## `zot export`

Export items to a file or stdout.

```bash
# Export a specific collection
zot export json     --collection "Energy Market" --output energy.json
zot export csv      --collection "Energy Market" --output energy.csv
zot export bib      --collection "Energy Market" --output energy.bib
zot export markdown --collection "Energy Market" --output energy.md

# Export the entire library
zot export json     --all --output library.json
zot export bib      --all --output library.bib
zot export markdown --all --notes --output library.md   # Include notes sections

# Print to stdout (omit --output)
zot export bib --collection "NLP"
```

### Export format details

| Format | Command | Notes |
|---|---|---|
| JSON | `export json` | Full-fidelity Pydantic dump; one object per item |
| CSV | `export csv` | One row per item; creators flattened to `author_1`, `author_2`, … |
| BibTeX | `export bib` | Uses Better BibTeX `citationKey` if present, else auto-generates `LastName2023word` |
| Markdown | `export markdown` | Table of items + optional `## Notes` sections per item |

---

## Item types reference

Common values for `--type`:

`journalArticle` · `conferencePaper` · `book` · `bookSection` · `thesis` · `report` · `preprint` · `webpage` · `blogPost` · `patent` · `dataset` · `software` · `manuscript`

Run `zot stats types` to see all types present in your library.
