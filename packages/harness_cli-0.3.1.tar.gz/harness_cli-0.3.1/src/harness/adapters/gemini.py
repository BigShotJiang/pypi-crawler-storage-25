"""gemini adapter — invokes the `gemini` CLI in print mode.

`gemini -p PROMPT --output-format json` emits a JSON envelope where token
usage lives at `stats.models[*].tokens.{input,candidates}`.
"""
from __future__ import annotations

import json

from harness._subproc import SubprocOutcome, run_subprocess, write_instructions
from harness.base import Adapter, BuildCommand, RunResult, RunSpec
from harness.model_normalization import normalize_model_for_harness
from harness.pricing import derive_cost


class GeminiAdapter(Adapter):
    name = "gemini"
    instructions_filename = "GEMINI.md"

    DEFAULT_MODEL = "gemini-2.5-pro"

    def build_command(self, spec: RunSpec) -> BuildCommand:
        model = normalize_model_for_harness(self.name, spec.model or self.DEFAULT_MODEL, resolve=not spec.model_no_resolve)
        instructions_file = write_instructions(spec.workdir, self.instructions_filename, spec.instructions)
        args = ["-p", spec.prompt, "-y", "-m", model, "--output-format", "json"]
        return BuildCommand(cmd="gemini", args=args, cwd=spec.workdir, env={}, instructions_file=instructions_file)

    def parse_output(self, spec: RunSpec, outcome: SubprocOutcome) -> dict:
        tokens_in, tokens_out, raw = _parse_gemini_stats(outcome.stdout)
        if raw is None:
            return {"cost_usd": None, "tokens_in": None, "tokens_out": None, "raw": None}

        stats = raw.get("stats") if isinstance(raw, dict) else {}
        models = stats.get("models") if isinstance(stats, dict) else {}
        model_name = next(iter(models.keys()), None) if isinstance(models, dict) and models else None
        return {
            "cost_usd": derive_cost(model_name, tokens_in, tokens_out),
            "tokens_in": tokens_in,
            "tokens_out": tokens_out,
            "raw": raw,
        }

    def run(self, spec: RunSpec) -> RunResult:
        bc = self.build_command(spec)
        outcome = run_subprocess(
            [bc.cmd] + bc.args,
            cwd=bc.cwd,
            timeout_seconds=spec.timeout_seconds,
            extra_env={**bc.env, **spec.env},
        )
        parsed = self.parse_output(spec, outcome)
        return RunResult(
            harness=self.name,
            model=spec.model or self.DEFAULT_MODEL,
            exit_code=outcome.exit_code,
            duration_seconds=outcome.duration_seconds,
            stdout=outcome.stdout,
            stderr=outcome.stderr,
            timed_out=outcome.timed_out,
            cost_usd=parsed.get("cost_usd"),
            tokens_in=parsed.get("tokens_in"),
            tokens_out=parsed.get("tokens_out"),
            raw=parsed.get("raw"),
        )


def _parse_gemini_stats(stdout: str) -> tuple[int, int, dict | None]:
    """Try whole-stdout JSON first, then fall back to scanning lines."""
    candidates: list[str] = [stdout.strip()]
    candidates += [ln.strip() for ln in stdout.splitlines() if ln.strip().startswith("{")]

    for blob in candidates:
        if not blob:
            continue
        try:
            parsed = json.loads(blob)
        except json.JSONDecodeError:
            continue
        models = (parsed.get("stats") or {}).get("models")
        if not isinstance(models, dict):
            continue
        tokens_in = tokens_out = 0
        for stats in models.values():
            t = (stats or {}).get("tokens") or {}
            tokens_in += int(t.get("input") or 0)
            tokens_out += int(t.get("candidates") or 0)
        # Stats block was present — report as-is (including 0/0 for "ran
        # but upstream didn't expose usage" vs None for "couldn't parse").
        return tokens_in, tokens_out, parsed

    return 0, 0, None
