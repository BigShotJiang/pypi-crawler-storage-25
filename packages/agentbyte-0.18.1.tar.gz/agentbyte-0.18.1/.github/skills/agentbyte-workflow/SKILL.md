---
name: agentbyte-workflow
description: Complete guide for Agentbyte workflows — Workflow, WorkflowRunner, all step types (FunctionStep, TransformStep, HttpStep, EchoStep, AgentStep, SubWorkflowStep), conditional branching with EdgeCondition, WorkflowContext state sharing, checkpointing, suspend/resume for human-in-the-loop, cancellation, and event-driven observability.
---

Use this skill when implementing deterministic multi-step execution graphs in Agentbyte. Workflows are the right choice when the control flow is known up front — fixed steps, explicit edges, and typed inputs/outputs. Use orchestrators instead when routing should be decided by an LLM at runtime.

---

## 1. Basic linear workflow

```python
import asyncio
from pydantic import BaseModel
from agentbyte.workflow import (
    FunctionStep,
    StepMetadata,
    Workflow,
    WorkflowConfig,
    WorkflowRunner,
)


class NumberInput(BaseModel):
    value: int


class NumberOutput(BaseModel):
    value: int


async def double(input_data: NumberInput, context) -> NumberOutput:
    return NumberOutput(value=input_data.value * 2)


async def add_ten(input_data: NumberOutput, context) -> NumberOutput:
    return NumberOutput(value=input_data.value + 10)


workflow = Workflow(WorkflowConfig(name="math_pipeline"))
workflow.chain(
    FunctionStep("double", StepMetadata(name="double"), NumberInput, NumberOutput, double),
    FunctionStep("add_ten", StepMetadata(name="add_ten"), NumberOutput, NumberOutput, add_ten),
)

runner = WorkflowRunner()
execution = asyncio.run(runner.run(workflow, {"value": 5}))
print(execution.state["add_ten_output"])
```

`run()` wraps `run_stream()` — it collects all events and returns the final `WorkflowExecution`.

---

## 2. WorkflowConfig

```python
from agentbyte.workflow import WorkflowConfig, WorkflowCompletionMode

config = WorkflowConfig(
    name="my_pipeline",
    description="Optional description",
    initial_state={"env": "production"},   # pre-seed shared state for all steps
    completion_mode=WorkflowCompletionMode.ANY_END,  # stop when first end step finishes
)
```

`initial_state` values are available to every step via `context.get(...)` from the first step onward.

---

## 3. StepMetadata — retries and timeouts

```python
from agentbyte.workflow import StepMetadata, JoinFailureMode

meta = StepMetadata(
    name="fetch_data",
    description="Optional",          # shown in visualizer
    max_retries=3,                    # retry the step up to 3 times on failure
    timeout_seconds=30.0,             # fail the step if it takes longer than 30s
    join_failure_mode=JoinFailureMode.FAIL_FAST,  # default; SKIP_FAILED tolerates branch failures
)
```

---

## 4. Step types

### FunctionStep

Wraps any sync or async Python callable.

```python
FunctionStep(
    step_id,
    metadata,
    input_type,    # Pydantic model class
    output_type,   # Pydantic model class
    fn,            # callable(input_data, context) -> output_type
)
```

### TransformStep

Maps fields from one schema to another without custom code. Use `"static:<value>"` for literal values, or a field name string to copy from input.

```python
from agentbyte.workflow import TransformStep

class RawRecord(BaseModel):
    first_name: str
    last_name: str
    age: int

class NormalizedRecord(BaseModel):
    full_name: str
    category: str
    age: int

step = TransformStep(
    "normalize",
    StepMetadata(name="normalize"),
    RawRecord,
    NormalizedRecord,
    mappings={
        "full_name": "first_name",        # copy from input field
        "category": "static:employee",    # literal value
        "age": "age",
    },
)
```

### HttpStep

Makes an async HTTP request using httpx. Input and output types are fixed.

```python
from agentbyte.workflow import HttpStep, HttpRequestInput, HttpResponseOutput

step = HttpStep("fetch_api", StepMetadata(name="fetch_api"))

# Input passed at runtime:
# HttpRequestInput(url="https://api.example.com/data", method="GET", headers={"Authorization": "Bearer ..."})
# Output: HttpResponseOutput(status_code=200, content="...", headers={...}, url="...", elapsed_time=0.12)
```

`HttpStep` writes `{step_id}_status` (the HTTP status code) into workflow state automatically.

### EchoStep

Passes input through unchanged. Useful for testing and graph stubs.

```python
from agentbyte.workflow import EchoStep, EchoInput, EchoOutput

step = EchoStep("echo", StepMetadata(name="echo"))
# Input: EchoInput(message="hello")  →  Output: EchoOutput(message="hello", echo_count=1)
```

### AgentStep

Runs an Agentbyte agent as a workflow step. Pass an `AgentContext` in the input for session continuity.

```python
from agentbyte.context import AgentContext
from agentbyte.session_store import CachedFileSessionStore
from agentbyte.workflow import AgentStep, Workflow, WorkflowConfig, WorkflowRunner
from agentbyte.workflow.steps.agentbyte_agent import AgentbyteAgentInput

store = CachedFileSessionStore(".sessions")
session_id = "user-abc"
ctx = await store.get(session_id) or AgentContext(session_id=session_id)

step = AgentStep("writer", StepMetadata(name="writer"), writer_agent)
workflow = Workflow(WorkflowConfig(name="draft_pipeline"))
workflow.add_step(step)

execution = await WorkflowRunner().run(
    workflow,
    AgentbyteAgentInput(task="Write about AI trends", agent_context=ctx),
)
await store.save(session_id, ctx)
```

`agent_context` is optional — omit it for a stateless step that starts fresh each run.

### SubWorkflowStep

Runs a child workflow as a single step inside the parent workflow. Pass a workflow factory (callable) so the runner can create a fresh instance per execution.

```python
from agentbyte.workflow import SubWorkflowStep, Workflow, WorkflowConfig

def build_child_workflow() -> Workflow:
    child = Workflow(WorkflowConfig(name="child"))
    child.chain(
        FunctionStep("process", StepMetadata(name="process"), ChildInput, ChildOutput, process_fn),
    )
    return child

step = SubWorkflowStep(
    "sub",
    StepMetadata(name="sub"),
    workflow=build_child_workflow,   # pass a factory, not a live instance
    input_type=ParentInput,
    output_type=ParentOutput,
)
```

Child suspend/resume (human-in-the-loop inside a sub-workflow) is propagated automatically to the parent runner.

---

## 5. Conditional branching with EdgeCondition

Use `add_step()` + `add_edge()` instead of `chain()` when routing depends on output values or shared state.

```python
from agentbyte.workflow import EdgeCondition, Workflow, WorkflowConfig

workflow = Workflow(WorkflowConfig(name="conditional"))
workflow.add_step(validate_step)
workflow.add_step(approve_step)
workflow.add_step(reject_step)
workflow.set_start_step("validate")

# Route based on an output field value
workflow.add_edge(
    "validate", "approve",
    EdgeCondition(type="output_based", field="status", operator="==", value="ok"),
)
workflow.add_edge(
    "validate", "reject",
    EdgeCondition(type="output_based", field="status", operator="!=", value="ok"),
)
workflow.add_end_step("approve")
workflow.add_end_step("reject")
```

Route based on shared workflow state instead of output:

```python
workflow.add_edge(
    "check", "next_step",
    EdgeCondition(type="state_based", field="retry_count", operator=">", value=0),
)
```

Unconditional edge (same as `chain()`):

```python
workflow.add_edge("step_a", "step_b")
# EdgeCondition defaults to type="always"
```

---

## 6. Parallel execution — fan-out and fan-in

The runner automatically runs all steps whose dependencies are satisfied concurrently, up to `max_concurrent_steps`. No special API is required for fan-out — just add multiple outgoing edges from one step.

### Fan-out (one step → many branches)

```python
from agentbyte.workflow import Workflow, WorkflowConfig, FunctionStep, StepMetadata

workflow = Workflow(WorkflowConfig(name="parallel_pipeline"))

workflow.add_step(ingest_step)
workflow.add_step(branch_a_step)
workflow.add_step(branch_b_step)
workflow.set_start_step("ingest")

# Both branch_a and branch_b receive ingest output and run in parallel
workflow.add_edge("ingest", "branch_a")
workflow.add_edge("ingest", "branch_b")

workflow.add_end_step("branch_a")
workflow.add_end_step("branch_b")
```

### Fan-in (many branches → one join step)

When a join step has **≥ 2 upstream `always` edges**, the runner collects all branch outputs into a special envelope before calling the join step. The join step's input model must accept this shape:

```python
from typing import Any
from pydantic import BaseModel

class JoinInput(BaseModel):
    branch_outputs: dict[str, Any]   # {step_id: output_dict}
    failed_branches: list[str]       # step IDs that did not complete

class JoinOutput(BaseModel):
    combined: str

async def merge(input_data: JoinInput, context) -> JoinOutput:
    a_result = input_data.branch_outputs.get("branch_a", {})
    b_result = input_data.branch_outputs.get("branch_b", {})
    return JoinOutput(combined=f"{a_result} + {b_result}")

join_step = FunctionStep("join", StepMetadata(name="join"), JoinInput, JoinOutput, merge)

workflow.add_step(join_step)
workflow.add_edge("branch_a", "join")
workflow.add_edge("branch_b", "join")
workflow.add_end_step("join")
```

To tolerate partial branch failures instead of raising immediately, set `join_failure_mode` on the join step:

```python
from agentbyte.workflow import JoinFailureMode

join_step = FunctionStep(
    "join",
    StepMetadata(name="join", join_failure_mode=JoinFailureMode.SKIP_FAILED),
    JoinInput, JoinOutput, merge,
)
# failed_branches in JoinInput will list the failed step IDs; branch_outputs will contain only the successful ones
```

---

## 7. WorkflowContext — cross-step state sharing

Each step receives `WorkflowContext` as its second argument.

```python
from agentbyte.workflow import WorkflowContext

async def step_a(input_data: MyInput, context: WorkflowContext) -> MyOutput:
    context.set("shared_value", input_data.value.upper())
    context.emit_progress("Processed first step", completed=1, total=3)
    return MyOutput(value=input_data.value)

async def step_b(input_data: MyOutput, context: WorkflowContext) -> MyOutput:
    shared = context.get("shared_value", "")
    context.update({"step_b_done": True, "result": shared})
    return MyOutput(value=f"Got: {shared}")
```

`WorkflowContext` API:

| Method | Purpose |
|---|---|
| `context.set(key, value)` | Write a value into shared workflow state |
| `context.get(key, default)` | Read from shared workflow state |
| `context.update({...})` | Bulk write |
| `context.emit_progress(message, completed, total)` | Emit a `StepProgressEvent` |
| `context.request_input(key, response_type, prompt)` | Suspend and request typed external input |
| `context.request_approval(key, reason, payload, response_type)` | Suspend and request human approval |

Import: `from agentbyte.workflow import WorkflowContext`

---

## 8. WorkflowExecution — reading results

```python
execution = await runner.run(workflow, {"value": 5})

execution.status          # WorkflowStatus enum: COMPLETED / FAILED / SUSPENDED / CANCELLED
execution.state           # dict — shared workflow state after all steps
execution.step_executions # dict[step_id, StepExecution] — per-step status, times, output
execution.pending_requests # dict[request_id, WorkflowPendingRequest] — filled when suspended
execution.error           # str | None — set when status == FAILED
```

`StepExecution` fields: `step_id`, `status` (StepStatus), `start_time`, `end_time`, `input_data`, `output_data`, `error`, `retry_count`.

---

## 9. Streaming workflow events

```python
from agentbyte.logger import StreamEventLogger

stream_logger = StreamEventLogger()

async for event in WorkflowRunner().run_stream(workflow, {"value": 5}):
    stream_logger.info(event)
    stream_logger.debug(event)
    stream_logger.warning(event)
    stream_logger.error(event)
    stream_logger.exception(event)
```

Full event list:

| Event | Trigger |
|---|---|
| `WorkflowStartedEvent` | Execution begins |
| `WorkflowCompletedEvent` | All end steps finished |
| `WorkflowFailedEvent` | Unrecoverable error |
| `WorkflowCancelledEvent` | `CancellationToken` fired |
| `WorkflowSuspendedEvent` | Step called `request_input` or `request_approval` |
| `WorkflowResumedEvent` | Runner resumed from a checkpoint |
| `CheckpointSavedEvent` | Auto-checkpoint saved |
| `WorkflowInputRequestedEvent` | Step requested external input |
| `WorkflowApprovalRequestedEvent` | Step requested approval |
| `StepStartedEvent` | Step execution begins (includes `input_data`) |
| `StepCompletedEvent` | Step finished (includes `output_data`, `duration_seconds`) |
| `StepFailedEvent` | Step failed (includes `error_details`, `duration_seconds`) |
| `StepProgressEvent` | `context.emit_progress(...)` called inside a step |
| `EdgeActivatedEvent` | Data flowing from one step to the next |

---

## 10. Checkpointing

Save execution state so a long-running workflow can be resumed after a crash or restart.

```python
from agentbyte.workflow import (
    CheckpointConfig,
    FileCheckpointStore,
    WorkflowRunner,
)

store = FileCheckpointStore(".checkpoints")
checkpoint_config = CheckpointConfig(
    store=store,
    auto_save=True,
    save_interval_steps=2,   # save every 2 completed steps
)

runner = WorkflowRunner()
execution = await runner.run(
    workflow,
    {"value": 5},
    checkpoint_config=checkpoint_config,
)

# Resume from the latest checkpoint (e.g. after a crash)
checkpoint = await store.load_latest(workflow.id)
resumed_execution = await runner.run(
    workflow,
    checkpoint=checkpoint,
    checkpoint_config=checkpoint_config,
)
```

`FileCheckpointStore(base_path)` — persists JSON files per workflow.
`InMemoryCheckpointStore()` — volatile, useful for tests.

The runner validates the checkpoint's structure hash against the live workflow graph on resume. If steps were added/removed, `can_resume=False` is set on the `CheckpointValidationResult`.

---

## 11. Suspend / resume — human-in-the-loop

A step can pause the entire workflow to wait for typed external input or approval.

```python
from pydantic import BaseModel

class UserDecision(BaseModel):
    approved: bool
    reason: str

async def review_step(input_data: ReviewInput, context) -> ReviewOutput:
    # Suspend here — workflow returns status=SUSPENDED
    await context.request_approval(
        key="manager_approval",
        reason="Payment over $10,000 requires manager sign-off.",
        payload={"amount": input_data.amount},
        response_type=UserDecision,
    )
    # Code below never runs in the same call — it runs after resume
```

Resume by passing `responses=`:

```python
from agentbyte.workflow import WorkflowRunner, FileCheckpointStore

store = FileCheckpointStore(".checkpoints")
checkpoint_config = CheckpointConfig(store=store, auto_save=True)

runner = WorkflowRunner()

# First run — suspends at review_step
execution = await runner.run(
    workflow, {"amount": 15000},
    checkpoint_config=checkpoint_config,
)
# execution.status == WorkflowStatus.SUSPENDED

# Inspect what is pending
pending = list(execution.pending_requests.values())[0]
request_id = pending.request_id

# Resume with the human's answer
checkpoint = await store.load_latest(workflow.id)
resumed = await runner.run(
    workflow,
    checkpoint=checkpoint,
    checkpoint_config=checkpoint_config,
    responses={request_id: {"approved": True, "reason": "Looks good"}},
)
```

`request_input()` works identically — use it when you need the human to provide data rather than a yes/no decision.

---

## 12. Cancellation

```python
from agentbyte.cancellation_token import CancellationToken
from agentbyte.workflow import WorkflowRunner, WorkflowCancelledError
import asyncio

token = CancellationToken()
runner = WorkflowRunner()

async def cancel_after(delay: float) -> None:
    await asyncio.sleep(delay)
    token.cancel()

asyncio.create_task(cancel_after(5.0))

try:
    execution = await runner.run(workflow, {"value": 5}, cancellation_token=token)
except WorkflowCancelledError:
    print("Workflow was cancelled")
```

---

## 13. WorkflowRunner — concurrency

```python
runner = WorkflowRunner(max_concurrent_steps=10)  # default is 5
```

Steps whose input dependencies are all resolved run in parallel up to `max_concurrent_steps`.

---

## 14. Workflow validation

```python
validation: WorkflowValidationResult = workflow.validate_workflow()
if not validation.is_valid:
    for err in validation.errors:
        print(err)
```

`WorkflowValidationResult` fields: `is_valid`, `errors`, `warnings`, `has_cycles`, `unreachable_steps`.

---

## Guardrails

- Use `chain()` for linear flows; use `add_step()` + `add_edge()` only when branching or fan-out is required.
- A fan-in join step with ≥ 2 upstream `always` edges receives `{"branch_outputs": {...}, "failed_branches": [...]}` — its input model must declare these fields, not the upstream output shape.
- Always pass a workflow factory (callable) to `SubWorkflowStep`, not a live instance — the runner calls it to get a fresh copy per execution.
- Do not pass `initial_input` and `responses` together — they are mutually exclusive.
- `request_input()` and `request_approval()` never return; code after them runs only on resume.
- Do not thread `AgentContext` through `WorkflowContext.state` — keep it in `AgentbyteAgentInput.agent_context`.
- `WorkflowRunner` is not thread-safe across concurrent runs of the same workflow instance; use one runner per concurrent workflow.
- Workflow logging is event-driven today — use `run_stream()` for observability, and pair it with `StreamEventLogger` when you want standard Python log output.
