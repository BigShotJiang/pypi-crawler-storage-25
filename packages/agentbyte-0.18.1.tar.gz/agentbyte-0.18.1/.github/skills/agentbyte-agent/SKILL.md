---
name: agentbyte-agent
description: Complete guide for Agentbyte agents — construction, run/run_stream, AgentContext, multi-turn sessions, session stores, structured output, cancellation, approval pause/resume, AgentAsTool composition, context compaction, context engineering strategy, and EmbeddingAgent for RAG pipelines. Use this for any task involving Agent creation, execution, multi-agent composition, or embedding large document batches.
---

Use this skill for anything related to `Agent` creation, execution, conversation state, tool use, structured output, approval flows, composing agents as tools, or embedding documents with `EmbeddingAgent`.

For tool definitions see `agentbyte-function-tools`, `agentbyte-coding-tools`, `agentbyte-memory-tool`.
For middleware deep dive see `agentbyte-middleware`.
For orchestration patterns (round-robin, AI-driven, plan-based) see the orchestration skills.
For raw LLM and embedding client setup see `agentbyte-llm-client`.

---

## 1. Agent construction

```python
from agentbyte.agents import Agent
from agentbyte.llm.openai import OpenAIChatCompletionClient

client = OpenAIChatCompletionClient.from_api_key(model="gpt-4o-mini")

agent = Agent(
    # Identity
    name="contracts_reviewer",
    description="Reviews contract questions and searches for evidence before answering.",
    instructions=(
        "Answer contract questions carefully. "
        "Always call the search tool before making factual claims. "
        "Be concise and flag uncertainty when evidence is weak."
    ),
    # Execution engine
    model_client=client,
    # Capabilities
    tools=[search_contracts, get_contract_by_id],
    required_tools=["search_contracts"],   # always force this tool before answering
    # Context control
    max_iterations=4,
    middlewares=[ContextCompactionMiddleware(max_tokens=16_000, keep_last=8)],
    # Memory (application-managed, injected into system prompt)
    memory=my_memory_backend,              # optional
    # Output shape
    output_format=None,                    # or a Pydantic model class
    summarize_tool_result=True,
    # Discoverability
    example_tasks=[
        "Find the termination date for contract CW001.",
        "Who signed vendor agreement V-12?",
    ],
)
```

### Constructor parameter groups

| Group | Parameters | Purpose |
|---|---|---|
| Identity | `name`, `description`, `instructions` | Who the agent is and how it behaves |
| Engine | `model_client` | Required — the LLM backend |
| Capabilities | `tools`, `required_tools` | What the agent can call; `required_tools` adds a system-prompt mandate |
| Control | `max_iterations`, `middlewares`, `summarize_tool_result` | Execution bounds and cross-cutting behavior |
| Memory | `memory` | Application-managed retrieval injected before each model call |
| Output | `output_format`, `example_tasks` | Structured response shape and discoverability metadata |

`max_iterations` meaning in practice:
- `1` — one LLM pass, no looping
- `3–6` — focused tool-assisted tasks
- `10` — generous default for open-ended agents

Plain Python callables passed in `tools` are automatically wrapped as `FunctionTool` — no manual wrapping needed.

---

## 2. Running an agent

### Single-turn (stateless)

```python
response = await agent.run("What is the termination date for contract CW001?")
print(response.final_content)        # assistant's final text
print(response.messages[-1].content) # same, from message list
```

### Multi-turn (stateful — caller owns context)

```python
from agentbyte.context import AgentContext

ctx = AgentContext(session_id="user-123")

r1 = await agent.run("Hi, I am Alex.", context=ctx)
r2 = await agent.run("What is my name?", context=r1.context)
# r2.final_content → "Your name is Alex."
```

The agent has **no `self.context`** — it is a stateless singleton. A fresh `AgentContext` is created per call when `context=None`. The caller always holds and threads the context.

### Streaming

```python
async for event in agent.run_stream(
    task="Summarise the last 3 contracts.",
    context=ctx,
    verbose=True,         # include tool-call lifecycle events
    stream_tokens=True,   # emit token chunks when model supports it
):
    print(event)

# Final AgentResponse is the last item yielded
```

### Stream logging with StreamEventLogger

Use `verbose=True` to emit execution events, then pass every streamed item to
`StreamEventLogger`. It ignores non-event items automatically, so you do not
need your own `isinstance` dispatch just to log the stream.

```python
import logging

from agentbyte.logger import StreamEventLogger

logging.basicConfig(level=logging.INFO)
stream_logger = StreamEventLogger()

async for item in agent.run_stream(
    task="Summarise the last 3 contracts.",
    context=ctx,
    verbose=True,
    stream_tokens=True,
):
    stream_logger.info(item)
    stream_logger.debug(item)
    stream_logger.warning(item)
    stream_logger.error(item)
    stream_logger.exception(item)

    print(item)

# Final AgentResponse is still the last item yielded
```

`StreamEventLogger` covers execution-layer events from `run_stream()`. It
complements `LoggingMiddleware`, which logs model and tool operations inside the
middleware chain.

### run() parameters

| Parameter | Type | Purpose |
|---|---|---|
| `task` | `str \| UserMessage \| list[Message] \| None` | The work for this call. Optional if `context` is non-empty. |
| `context` | `AgentContext \| None` | Caller-owned session state. If `None`, a fresh context is created. |
| `cancellation_token` | `CancellationToken \| None` | Cooperative stop signal for long runs. |

`run_stream` adds `verbose: bool` and `stream_tokens: bool`.

### AgentResponse

```python
response.final_content     # str — last assistant message text
response.messages          # list[Message] — full turn history
response.context           # AgentContext — updated session state (pass to next call)
response.finish_reason     # "stop" | "max_iterations" | "approval_needed" | "cancelled" | "error"
response.usage             # LLM token usage summary
```

---

## 3. AgentContext — session state

`AgentContext` is the conversation short-term memory. The caller creates it, passes it in, and persists it. Never store it on the agent.

```python
from agentbyte.context import AgentContext

ctx = AgentContext(session_id="chat-001")

# Key attributes
ctx.messages        # list[Message] — full conversation history
ctx.session_id      # str — identifier used as session store key
ctx.metadata        # dict — custom per-session data
ctx.shared_state    # dict — cross-agent state (used by orchestrators)
```

Pre-seed a context with prior messages:

```python
ctx = AgentContext(session_id="chat-001")
ctx.add_message(SystemMessage(content="User is a premium subscriber."))
response = await agent.run("What's my plan?", context=ctx)
```

---

## 4. Session stores — persistence across restarts

```python
from agentbyte.session_store import CachedFileSessionStore  # or FileSessionStore, InMemorySessionStore

store = CachedFileSessionStore(".sessions")
session_id = "user-123"

# Load or create
ctx = await store.get(session_id) or AgentContext(session_id=session_id)

response = await agent.run("Remember: my budget is $500.", context=ctx)

# Persist after every turn
await store.save(session_id, response.context)
```

| Store | Backend | Use when |
|---|---|---|
| `InMemorySessionStore` | Python dict (volatile) | Tests, single-process demos |
| `FileSessionStore` | One JSON file per session | Simple persistence, low concurrency |
| `CachedFileSessionStore` | In-memory cache + file | Production — fast reads, durable writes |

Session store interface (all three share it):

```python
await store.get(session_id)         # AgentContext | None
await store.save(session_id, ctx)   # None
await store.list()                  # Iterable[tuple[str, AgentContext]]
await store.delete(session_id)      # bool
await store.clear_all()             # int (count deleted)
```

Import paths:

```python
from agentbyte import CachedFileSessionStore           # package root
from agentbyte.session_store import FileSessionStore   # module
```

Add `.sessions/` to `.gitignore`.

---

## 5. Structured output

```python
from pydantic import BaseModel
from agentbyte.agents import Agent

class ContractSummary(BaseModel):
    parties: list[str]
    termination_date: str
    key_obligations: list[str]

agent = Agent(
    name="extractor",
    instructions="Extract contract fields from the provided text.",
    model_client=client,
    output_format=ContractSummary,
)

response = await agent.run("Contract text: ...")
summary: ContractSummary = response.structured_output   # typed Pydantic instance
```

---

## 6. Cancellation

```python
from agentbyte.cancellation_token import CancellationToken

token = CancellationToken()

# Cancel from another coroutine or a UI event
asyncio.create_task(cancel_after(token, delay=5.0))

response = await agent.run("Long task...", cancellation_token=token)
# response.finish_reason == "cancelled" if cancelled mid-run
```

---

## 7. Tool approval — pause and resume

When a tool has `approval_mode=ApprovalMode.ALWAYS`, the agent pauses and returns `finish_reason="approval_needed"` before executing it.

```python
from agentbyte.tools import FunctionTool, ApprovalMode

risky_tool = FunctionTool(
    process_payment,
    description="Process a payment card charge.",
    approval_mode=ApprovalMode.ALWAYS,
)

agent = Agent(name="payment-agent", model_client=client, tools=[risky_tool])

# First run — agent pauses before executing the tool
r1 = await agent.run("Charge $50 to my account.")
assert r1.finish_reason == "approval_needed"

# Inspect what is pending
pending = r1.context.pending_approval_requests[0]
print(f"Tool: {pending.tool_name}, params: {pending.parameters}")

# Approve and resume — pass the same context back, task=None
r1.context.approve_tool(pending.call_id)
r2 = await agent.run(context=r1.context)   # task omitted — resumes from context

# To deny instead:
# r1.context.deny_tool(pending.call_id)
# r2 = await agent.run(context=r1.context)
```

Key rule: always pass the **same** `AgentContext` object between the first run and the approved run. The context carries the approval decision.

---

## 8. AgentAsTool — hierarchical composition

Wrap any agent as a `BaseTool` so a coordinator agent can invoke it as a specialist.

```python
from agentbyte.agents import Agent, AgentAsTool

# Specialist
weather_agent = Agent(
    name="weather_analyst",
    description="Answers weather questions using live data.",
    instructions="Report weather concisely with the unit the user requested.",
    model_client=client,
    tools=[get_weather],
)

# Wrap as a tool — shortcut via .as_tool()
weather_tool = weather_agent.as_tool(result_strategy="last")

# Coordinator sees the specialist as a tool
coordinator = Agent(
    name="coordinator",
    description="Handles user queries by delegating to specialists.",
    instructions="Delegate to the right specialist. Synthesize the results.",
    model_client=client,
    tools=[weather_tool],
)

response = await coordinator.run("What is the weather in Berlin in Celsius?")
```

### result_strategy options

| Value | Behavior |
|---|---|
| `"last"` (default) | Return only the final assistant message from the specialist |
| `"all"` | Concatenate all assistant messages with `\n` |
| `"last:N"` | Concatenate last N assistant messages |
| `callable` | Custom function `(list[Message]) -> str` |

`AgentAsTool` also accepts `context=` forwarding in `execute()` — pass a pre-seeded context to give the specialist prior history.

### Manual construction

```python
from agentbyte.agents import AgentAsTool

weather_tool = AgentAsTool(
    agent=weather_agent,
    result_strategy="last:2",
    task_parameter_name="task",   # default
)
```

---

## 9. Context engineering — keeping token costs under control

As agents loop through tool calls, context grows. Four strategies:

| Strategy | Mechanism | When to use |
|---|---|---|
| Compaction | Summarise + trim old messages at model-call time | Any long-running agent |
| Context isolation | Each specialist runs in its own bubble via `AgentAsTool` | Multi-specialist coordinators |
| Agent-managed memory | Agent writes/reads files via `MemoryTool` | Sessions needing persistent knowledge |
| Tool result filtering | Summarize large tool outputs | Future: `_execute_tool_call` hook |

Empirical token reduction data (from book, Chapter 4.12.3):
- Baseline: **21,633 tokens**
- Compaction middleware: **7,276 tokens (−66%)**
- Context isolation via `AgentAsTool`: **5,892 tokens (−73%)**

### ContextCompactionMiddleware

```python
from agentbyte.middleware import ContextCompactionMiddleware

agent = Agent(
    name="researcher",
    model_client=client,
    tools=[...],
    middlewares=[ContextCompactionMiddleware(
        max_tokens=16_000,   # trigger threshold (chars ÷ 4 heuristic)
        keep_last=8,         # number of tail messages to retain verbatim
    )],
)
```

Compaction output structure when triggered:
```
[system_message, SystemMessage("[Previous context summarized...]"), *messages[-keep_last:]]
```

Detection after a run:
```python
if response.context.metadata.get("compaction_applied"):
    original = response.context.metadata["original_message_count"]
    compacted = response.context.metadata["compacted_message_count"]
```

Best practice: combine `ContextCompactionMiddleware` inside specialists with `AgentAsTool(result_strategy="last")` for maximum reduction — the coordinator only sees the filtered summary, not the specialist's full tool trace.

---

## 10. Custom agent with task + filters (real-world pattern)

Pattern for agents that receive structured payloads (e.g. from an API endpoint) with optional filters:

```python
from agentbyte.agents import Agent
from agentbyte.context import AgentContext
from agentbyte.session_store import CachedFileSessionStore
from agentbyte.tools import ThinkTool
import json


def build_contract_agent(*, model_client) -> Agent:
    return Agent(
        name="contract_filter_agent",
        description="Answers contract questions using scoped document filters.",
        instructions=(
            "You are a contract intelligence agent.\n"
            "1. Always call ThinkTool first to plan your tool usage.\n"
            "2. If filters.documents is present, constrain all retrieval to those documents.\n"
            "3. Use DocumentSearchTool for content questions (who signed, clauses, obligations).\n"
            "4. Use MetadataSearchTool for structured/tabular questions (dates, counts, status).\n"
            "5. Only return claims supported by tool evidence. Say so if nothing is found."
        ),
        model_client=model_client,
        tools=[ThinkTool(), document_search_tool, metadata_search_tool],
        required_tools=["think"],
        max_iterations=6,
        example_tasks=[
            "Who signed CW347209 from Novartis?",
            "List all contracts expiring in Q3 2025.",
        ],
    )


async def run_with_filters(
    *,
    agent: Agent,
    payload: dict,
    session_id: str,
    store: CachedFileSessionStore,
) -> str:
    ctx = await store.get(session_id) or AgentContext(session_id=session_id)

    task = payload.get("task", "").strip()
    filters = payload.get("filters") or {}

    # Embed filters in the task text so tools can consume them
    task_text = f"User task:\n{task}\n\nFilters JSON:\n{json.dumps(filters)}"

    response = await agent.run(task_text, context=ctx)
    await store.save(session_id, response.context)
    return response.final_content
```

---

## 11. EmbeddingAgent — batch embedding for RAG pipelines

`EmbeddingAgent` sits one layer above the raw embedding client. It handles batching, carries `AgentContext` for OTel trace correlation, and exposes the same `run()` / `run_stream()` interface as `Agent`.

### Construction

```python
from agentbyte.agents import EmbeddingAgent
from agentbyte.llm.openai import OpenAIEmbeddingClient
from agentbyte.middleware import OTelMiddleware

client = OpenAIEmbeddingClient.from_api_key(model="text-embedding-3-small")

agent = EmbeddingAgent(
    name="doc-embedder",
    embedding_client=client,
    middlewares=[OTelMiddleware()],     # optional — for trace correlation
    batch_size=100,                     # texts per API call (default 100)
    max_concurrent_batches=1,           # default: sequential; raise for throughput
)
```

### run() — embed and return all vectors

```python
result = await agent.run(texts=document_chunks)

vectors = result.embeddings          # list[list[float]] — all vectors, original order
first   = result.embedding           # list[float] — first vector (convenience)
print(f"Cost: ${result.usage.cost_estimate:.4f}, tokens: {result.usage.tokens_input}")
```

`run()` returns a single `EmbeddingResult` with embeddings aggregated across all batches.

### run_stream() — batch progress events

```python
from agentbyte.agents import EmbeddingBatchProgressEvent

async for event in agent.run_stream(texts=chunks):
    if isinstance(event, EmbeddingBatchProgressEvent):
        pct = event.completed_texts / event.total_texts * 100
        print(f"[{pct:.0f}%] batch {event.batch_index + 1}/{event.total_batches}")
    elif isinstance(event, EmbeddingResult):
        result = event   # final aggregated result, always last
```

`EmbeddingBatchProgressEvent` fields: `batch_index`, `total_batches`, `completed_texts`, `total_texts`.

### OTel trace correlation inside a workflow

```python
async def embed_step(texts: list[str], context: AgentContext) -> EmbeddingResult:
    return await agent.run(texts=texts, context=context)
```

Pass the workflow's `AgentContext` so embedding spans are linked to the parent trace. If omitted, middleware still runs but without a parent span.

### Concurrent batching

Set `max_concurrent_batches > 1` to run that many batches in-flight at once via an `asyncio.Semaphore`. Useful for large ingestion jobs where network I/O is the bottleneck.

```python
agent = EmbeddingAgent(
    name="fast-embedder",
    embedding_client=client,
    batch_size=100,
    max_concurrent_batches=5,   # up to 5 batches in-flight at once
)
```

With concurrent batches, `run_stream()` progress events arrive in **completion order** — use `event.batch_index` to determine position. The final `EmbeddingResult.embeddings` list is always in original text order regardless of completion order.

### EmbeddingAgent guardrails

- `batch_size` controls how many texts go in a single API call — it does **not** split long individual texts. Texts exceeding the model's token limit raise an error from the provider (fail fast, not silent truncation).
- Default `max_concurrent_batches=1` is sequential — safe for rate limits. Increase only when you know your provider quota allows it; too high will trigger 429s.
- `AgentContext` is optional — pass it only for trace correlation; `EmbeddingAgent` has no message history or tool calls.
- Do **not** pass `middlewares` to the embedding client itself — `middlewares` was removed from embedding clients in 0.17.0. Add them to `EmbeddingAgent` instead.

---

## Guardrails

- Agent is **stateless** — never store conversation history on the `Agent` object; always on `AgentContext`.
- Always pass the **returned** `response.context` (not the original) into the next call — the agent may have mutated it.
- Do **not** pass the same `AgentContext` to two concurrent agent calls — not thread-safe.
- For approval resume: pass `task=None` and the mutated `context` — the guard `if not task and context.is_empty` protects against ambiguous empty calls.
- Add `.sessions/` to `.gitignore`.
- `required_tools` names must match the actual tool names in `tools` — a mismatch silently adds a non-functional mandate to the system prompt.
