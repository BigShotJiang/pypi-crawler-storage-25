---
name: agentbyte-memory-tool
description: Guide for sandboxed file-system memory in Agentbyte. Use when agents need to persist structured data across turns or sessions via explicit read/write tool calls. Covers MemoryTool, MemoryBackend, all six commands, and the sandbox security model.
---

Use this skill when your agent needs to persist structured data or documents in a sandboxed directory that it controls explicitly.

`MemoryTool` is **agent-managed memory** — the agent decides when to read, write, and organise files by calling the tool directly. This is distinct from `BaseMemory` subclasses (application-managed), where the framework handles storage transparently.

## Pattern: Attach MemoryTool to an agent

```python
from agentbyte.tools import MemoryTool
from agentbyte.agents import Agent

memory_tool = MemoryTool(base_path="./agent_knowledge_base")

agent = Agent(
    name="knowledge-agent",
    model_client=client,
    tools=[memory_tool],
)

await agent.run("Create a file called notes.md with the text 'First session notes.'")
```

`MemoryTool` creates a `MemoryBackend` internally — do not construct `MemoryBackend` separately unless you need direct (non-tool) access to it.

## Constructor

```python
from agentbyte.tools import MemoryTool, ApprovalMode

MemoryTool(
    base_path="./memories",          # sandbox root (created if absent)
    approval_mode=ApprovalMode.NEVER,  # default: no approval required
)
```

`base_path` resolves to an absolute path; all file operations are constrained to it.

## The six commands

The LLM calls `memory` with a `command` parameter selecting the operation.

### `view` — read a file or list a directory

```python
{"command": "view", "path": "notes.md"}          # file contents
{"command": "view", "path": "reports/"}           # directory listing
{"command": "view", "path": "/"}                  # list entire memory root
```

Returns file content as a string, or a sorted list of filenames for directories.

### `create` — write or overwrite a file

```python
{"command": "create", "path": "notes.md", "file_text": "# Notes\nFirst entry."}
{"command": "create", "path": "reports/2025/summary.md", "file_text": "..."}
```

Parent directories are created automatically. Overwrites the file if it already exists.

### `str_replace` — replace the first occurrence of a string

```python
{
    "command": "str_replace",
    "path": "notes.md",
    "old_str": "First entry.",
    "new_str": "Updated entry."
}
```

Replaces **only the first occurrence** — deterministic by design. Raises an error if `old_str` is not found.

### `insert` — insert text after a line number

```python
{"command": "insert", "path": "notes.md", "insert_line": 1, "insert_text": "Second line."}
```

`insert_line` is 1-based. `insert_line=0` prepends before line 1; `insert_line=N` (where N = total lines) appends after the last line.

### `delete` — remove a file

```python
{"command": "delete", "path": "old_notes.md"}
```

Deletes a file. Directory deletion is not supported via this command.

### `rename` — move or rename a file within the sandbox

```python
{"command": "rename", "path": "notes.md", "new_path": "archive/notes_2025.md"}
```

Both source and destination paths are validated against the sandbox. Parent directories of `new_path` are created automatically.

## Direct backend access (non-agent use)

If you need to call memory operations directly from application code (outside a tool call):

```python
from agentbyte.tools import MemoryBackend

backend = MemoryBackend(base_path="./agent_knowledge_base")

backend.create("notes.md", "# Notes\nFirst entry.")
content = backend.view("notes.md")
backend.str_replace("notes.md", "First entry.", "Updated entry.")
backend.insert("notes.md", insert_line=1, insert_text="New second line.")
backend.rename("notes.md", "archive/notes.md")
backend.delete("archive/notes.md")
```

`MemoryBackend` methods are synchronous. `MemoryTool.execute()` wraps them in the async tool interface.

## Sandbox security model

All paths are validated by `MemoryBackend._validate_path()`:

1. Leading `/` is stripped — `"/etc/passwd"` becomes `"etc/passwd"` inside the sandbox, not the real system path.
2. `Path.resolve()` expands `..` — `"../../etc/passwd"` resolves outside `base_path` and raises `ValueError` with "Access denied".
3. `view("/")` is special-cased before path validation to allow listing the root.

The sandbox cannot be disabled — all paths go through the same guard.

## Guardrails

- `MemoryTool(base_path=...)` is the only constructor — there is no `root_dir` param and no `sandbox=True` flag (sandboxing is always on).
- Import from `agentbyte.tools`, not `agentbyte.tools.memory_tool` (both work, but the public API is the top-level namespace).
- `MemoryTool` is for long-term structured file storage. For conversation history, use `AgentContext`. For application-managed vector or list memory, use `BaseMemory` subclasses.
- `str_replace` replaces only the **first** occurrence — use multiple calls for repeated replacements.
