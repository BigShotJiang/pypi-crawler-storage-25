---
name: agentbyte-list-memory
description: Complete guide for Agentbyte memory backends — ListMemory (in-memory), FileMemory (persistent JSON), MemoryContent, MemoryQueryResult, and wiring memory into agents. Use this when agents need to retain facts across turns or across restarts.
---

Use this skill when an agent needs to remember facts between turns (`ListMemory`) or between restarts (`FileMemory`). This is separate from `AgentContext` (short-term message history) and from `MemoryTool` (file-based sandbox for tool-calling agents).

---

## 1. ListMemory — in-memory, volatile

Stores memories in a Python list. Fast, simple, lost on process restart.

```python
from agentbyte.memory import ListMemory, MemoryContent
from agentbyte.agents import Agent

memory = ListMemory(max_memories=500)   # default is 1000

# Pre-load facts before attaching to an agent
await memory.add(MemoryContent(content="The user prefers metric units."))
await memory.add(MemoryContent(
    content="User project: Acme pipeline",
    metadata={"category": "project"},
))

agent = Agent(
    name="assistant",
    instructions="Answer concisely.",
    model_client=client,
    memory=memory,
)

response = await agent.run("What project am I working on?")
# Agent sees memory content injected into its system prompt
```

---

## 2. FileMemory — persistent JSON

Writes memories to a JSON file on every `add()`. Survives process restarts.

```python
from agentbyte.memory import FileMemory, MemoryContent

memory = FileMemory(file_path=".agent_memory.json", max_memories=1000)

await memory.add(MemoryContent(content="User timezone: Europe/Berlin"))

agent = Agent(
    name="assistant",
    instructions="Answer concisely.",
    model_client=client,
    memory=memory,
)
```

The file is created automatically including any missing parent directories. If the file is corrupted on load, `FileMemory` silently starts fresh.

---

## 3. MemoryContent fields

```python
from agentbyte.memory import MemoryContent

item = MemoryContent(
    content="User prefers dark mode",      # str or dict
    mime_type="text/plain",                # default; use "application/json" for dict content
    metadata={"category": "preference"},   # arbitrary key-value pairs
    # timestamp is set automatically to datetime.now()
)
```

`MemoryContent` is immutable (`frozen=True`) — create a new instance to update a fact.

---

## 4. Querying memory directly

Both backends share the same async interface.

```python
from agentbyte.memory import MemoryQueryResult

# Text search — most recent matches first
result: MemoryQueryResult = await memory.query("dark mode", limit=5)
for item in result.results:
    print(item.content)

# Most recent N items (no text filter)
context: MemoryQueryResult = await memory.get_context(max_items=10)

# Stats
stats = await memory.get_stats()
# {"max_memories": 1000, "current_memories": 42, "is_persistent": False, ...}

# Clear all memories
await memory.clear()
```

`MemoryQueryResult.results` is a `list[MemoryContent]`.

---

## 5. How memory is injected into agents

When `memory=` is set on an `Agent`, the framework calls `memory.get_context()` before each model call and injects the results into the system prompt. The agent sees the memory as additional context — it does not call `query()` or `add()` on its own.

To let the agent write to memory during a run, give it a `MemoryTool` (see `agentbyte-memory-tool`). `ListMemory` / `FileMemory` and `MemoryTool` serve different purposes:

| | `ListMemory` / `FileMemory` | `MemoryTool` |
|---|---|---|
| Who writes | Application code via `memory.add()` | The agent itself via tool calls |
| Storage | In-memory list or JSON file | Markdown files in a sandbox directory |
| Best for | Injecting known facts into the agent | Letting the agent build its own notes |

---

## 6. BaseMemory interface

Both backends implement `BaseMemory`. Use the interface when you want to swap implementations:

```python
from agentbyte.memory import BaseMemory, ListMemory, FileMemory

def build_memory(persist: bool) -> BaseMemory:
    if persist:
        return FileMemory(file_path=".memory.json")
    return ListMemory()
```

---

## Guardrails

- `add()`, `query()`, `get_context()`, `clear()`, and `get_stats()` are all `async` — always `await` them.
- `ListMemory` is not persisted — all memories are lost when the process exits. Use `FileMemory` for anything that must survive restarts.
- When `max_memories` is exceeded, the oldest entries are evicted (FIFO).
- Do not confuse `memory=` on `Agent` with `AgentContext` — context carries message history, memory carries facts.
- `MemoryContent` is immutable — you cannot update an existing entry; add a new one instead.
