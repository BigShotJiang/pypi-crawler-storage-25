---
name: agentbyte-research-tools
description: Guide for Agentbyte research tools — WebSearchTool, WebFetchTool, ExtractTextTool, ArxivSearchTool, YouTubeCaptionTool. Use when agents need to search the web, fetch URLs, parse HTML, search academic papers, or extract YouTube transcripts. Requires the [research] extra.
---

Use this skill when an agent needs to retrieve information from the web or external knowledge sources.

## Installation

Research tools require optional dependencies:

```bash
uv sync --extra research
# or
uv add "agentbyte[research]"
```

Importing `agentbyte.tools.research_tools` without these packages raises `ImportError` with a clear install message.

## Import

```python
from agentbyte.tools.research_tools import (
    WebSearchTool,
    WebFetchTool,
    ExtractTextTool,
    ArxivSearchTool,
    YouTubeCaptionTool,
    create_research_tools,
)
```

## Pattern 1: Factory (recommended)

```python
from agentbyte.tools.research_tools import create_research_tools
from agentbyte.agents import Agent

tools = create_research_tools(
    allowed_domains=None,   # None = allow all
    blocked_domains=["ads.example.com"],
    fetch_timeout=30,
    fetch_max_length=50_000,
)

agent = Agent(
    name="research-agent",
    model_client=client,
    tools=tools,
)
```

`create_research_tools` returns: `WebSearchTool`, `WebFetchTool`, `ExtractTextTool`, `ArxivSearchTool`, `YouTubeCaptionTool`.

## Pattern 2: Individual tools

```python
web_search = WebSearchTool(allowed_domains=["wikipedia.org", "arxiv.org"])
web_fetch   = WebFetchTool(timeout=30, max_content_length=50_000)
arxiv       = ArxivSearchTool(max_results=5)
youtube     = YouTubeCaptionTool(language="en")
```

## Tool reference

### WebSearchTool — `web_search`

Searches the web via the DuckDuckGo Instant Answer API. No API key required.

```python
{"query": "agentbyte python framework"}
{"query": "latest LLM benchmarks 2025", "max_results": 10}
```

Returns: `ToolResult.result` is a list of `{"title": str, "url": str, "snippet": str}`.
`metadata` includes `backend`, `count`, and `filtered` (domain-filtered count).

Domain filtering:
```python
# Restrict to specific domains
WebSearchTool(allowed_domains=["en.wikipedia.org", "docs.python.org"])

# Block specific domains
WebSearchTool(blocked_domains=["pinterest.com", "quora.com"])
```

> `GoogleSearchTool` exists in the module but is **not yet implemented** — use `WebSearchTool` instead.

### WebFetchTool — `web_fetch`

Fetches a URL and returns content as clean markdown, plain text, or raw HTML. Strips scripts and style tags. Truncates at `max_content_length`.

```python
{"url": "https://docs.python.org/3/library/asyncio.html"}
{"url": "https://example.com/page", "output_format": "text"}
{"url": "https://example.com/page", "output_format": "html"}
```

`output_format` options: `"markdown"` (default), `"text"`, `"html"`.

Returns: `ToolResult.result` is the content string.
`metadata` includes `url`, `status_code`, `content_length`, `original_length`, `truncated`.

### ExtractTextTool — `extract_text`

Converts raw HTML string or a local HTML file to markdown/text/html. Useful after storing fetched content or for processing existing HTML files.

```python
# From an inline HTML string
{"html": "<h1>Hello</h1><p>World</p>", "output_format": "markdown"}

# From a workspace-relative file path
{"file_path": "downloads/page.html", "output_format": "text"}
```

Provide exactly one of `html` or `file_path`.

### ArxivSearchTool — `arxiv_search`

Searches academic papers on arXiv.

```python
{"query": "multi-agent reinforcement learning"}
{"query": "transformer attention mechanisms", "max_results": 10, "sort_by": "lastUpdatedDate"}
```

`sort_by` options: `"relevance"` (default), `"lastUpdatedDate"`, `"submittedDate"`.

Returns: list of `{"title", "authors", "published", "summary", "pdf_url", "entry_id"}`.

### YouTubeCaptionTool — `youtube_caption`

Extracts the full transcript from a YouTube video.

```python
{"url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ"}
{"url": "https://youtu.be/dQw4w9WgXcQ", "language": "de"}
```

Supports `youtube.com/watch`, `youtu.be`, `youtube.com/shorts`, and `youtube.com/embed` URL formats.
Falls back to any available language if the requested one is not found.

Returns: `ToolResult.result` is the full transcript as a single string.
`metadata` includes `video_id`, `url`, `language`, `length`, `segment_count`.

## ResearchToolsConfig (Pydantic serialization)

```python
from agentbyte.tools.research_tools import ResearchToolsConfig

config = ResearchToolsConfig(
    allowed_domains=None,
    blocked_domains=["ads.example.com"],
    fetch_timeout=30,
    fetch_max_length=50_000,
)
tools = config.build_tools()
```

## Guardrails

- **`[research]` extra is required** — `beautifulsoup4`, `html2text`, `arxiv`, `youtube-transcript-api`, `httpx` must be installed.
- **No authentication** — `WebSearchTool` uses DuckDuckGo (no API key). For authenticated search, `GoogleSearchTool` is a placeholder stub that returns an error.
- **Domain filtering** — always configure `allowed_domains` or `blocked_domains` for production agents to prevent access to unwanted content.
- **Content truncation** — `WebFetchTool` and `ExtractTextTool` truncate at `max_content_length` (default 50,000 chars). Check `metadata["truncated"]` if completeness matters.
- Import from `agentbyte.tools.research_tools`, not `agentbyte.tools` (research tools are not re-exported from the top-level namespace).
