---
name: agentbyte-llm-client
description: Complete guide for Agentbyte chat and embedding clients — OpenAI and Azure OpenAI initialization, create/create_stream usage, ChatCompletionResult fields, EmbeddingResult fields, RetryPolicy, exception handling, and custom pricing.
---

Use this skill when setting up model clients, calling the LLM directly, configuring retry behaviour, or reading result metadata.

---

## 1. OpenAI chat client

### From environment (recommended)

Reads `OPENAI_API_KEY` from the environment automatically.

```python
from agentbyte.llm.openai import OpenAIChatCompletionClient

client = OpenAIChatCompletionClient.from_api_key(
    model="gpt-4o-mini",
    config={"max_completion_tokens": 500, "temperature": 0.2},
)
```

### From explicit key or injected SDK instance

```python
import os
from openai import AsyncOpenAI
from agentbyte.llm.openai import OpenAIChatCompletionClient

# Explicit key
client = OpenAIChatCompletionClient.from_api_key(
    model="gpt-4o-mini",
    api_key=os.environ["OPENAI_API_KEY"],
)

# Inject a pre-configured AsyncOpenAI instance
raw = AsyncOpenAI(api_key=os.environ["OPENAI_API_KEY"], timeout=30.0)
client = OpenAIChatCompletionClient(model="gpt-4o-mini", client=raw)
```

---

## 2. Azure OpenAI chat client

```python
from agentbyte.llm.azure import AzureOpenAIChatCompletionClient
```

### API key auth

Reads `AZURE_OPENAI_API_KEY`, `AZURE_OPENAI_ENDPOINT`, `AZURE_OPENAI_API_VERSION`, `AZURE_OPENAI_CHAT_DEPLOYMENT_NAME` from environment.

```python
client = AzureOpenAIChatCompletionClient.from_api_key(
    model="gpt-4o-mini",          # deployment name; falls back to env var
    api_version="2024-10-21",      # falls back to AZURE_OPENAI_API_VERSION
)
```

### Managed identity (Azure-hosted production)

```python
client = AzureOpenAIChatCompletionClient.from_default_credential(
    model="gpt-4o-mini",
)
```

### Certificate auth (service principal)

```python
import os

client = AzureOpenAIChatCompletionClient.from_certificate(
    model="gpt-4o-mini",
    tenant_id=os.environ["AZURE_TENANT_ID"],
    client_id=os.environ["AZURE_CLIENT_ID"],
    certificate_data=os.environ["AZURE_CERT_DATA"],
)
```

---

## 3. Calling the chat client

### Non-streaming

```python
from agentbyte.llm import SystemMessage, UserMessage

result = await client.create([
    SystemMessage(content="You are a concise assistant."),
    UserMessage(content="What is the capital of France?"),
])

print(result.message.content)        # "Paris."
print(result.usage.total_tokens)     # 27
print(result.finish_reason)          # "stop"
```

### Structured output

```python
from pydantic import BaseModel

class Answer(BaseModel):
    city: str
    country: str

result = await client.create(
    [UserMessage(content="Capital of France?")],
    output_format=Answer,
)
answer: Answer = result.structured_output   # typed Pydantic instance
```

### Streaming

```python
from agentbyte.llm import ChatCompletionChunk

async for chunk in client.create_stream([
    UserMessage(content="Tell me a short story."),
]):
    print(chunk.content, end="", flush=True)
    if chunk.is_complete:
        print()
        print(f"Tokens: {chunk.usage.total_tokens if chunk.usage else 'n/a'}")
```

---

## 4. ChatCompletionResult fields

| Field | Type | Purpose |
|---|---|---|
| `message` | `AssistantMessage` | Generated message — `.content` for text |
| `usage` | `Usage` | Token stats — `.tokens_input`, `.tokens_output`, `.total_tokens` |
| `model` | `str` | Model name returned by the provider |
| `finish_reason` | `str \| None` | Stop reason: `"stop"`, `"length"`, `"tool_calls"` |
| `structured_output` | `Any \| None` | Parsed Pydantic instance when `output_format=` was passed |
| `metadata` | `dict` | Provider metadata; includes `retry_observability` when retries occurred |

---

## 5. OpenAI embedding client

```python
from agentbyte.llm.openai import OpenAIEmbeddingClient

client = OpenAIEmbeddingClient.from_api_key(
    model="text-embedding-3-small",
    config={"encoding_format": "float"},
)

# Single input
result = await client.create("hello world")
vector = result.embedding          # list[float]
tokens = result.usage.tokens_input

# Batch input
batch = await client.create_batch(["alpha", "beta", "gamma"])
vectors = batch.embeddings         # list[list[float]]
first   = batch.embedding          # same as embeddings[0]
```

> **0.17.0 breaking change**: `middlewares` was removed from embedding clients. For batch processing with middleware (OTel, logging), use `EmbeddingAgent` from `agentbyte.agents` instead — see the `agentbyte-agent` skill.

---

## 6. Azure OpenAI embedding client

```python
from agentbyte.llm.azure import AzureOpenAIEmbeddingClient

# API key auth (reads AZURE_OPENAI_API_KEY, AZURE_OPENAI_ENDPOINT, etc.)
client = AzureOpenAIEmbeddingClient.from_api_key(
    model="text-embedding-3-small",
    api_version="2024-10-21",
)

# Managed identity
client = AzureOpenAIEmbeddingClient.from_default_credential(
    model="text-embedding-3-small",
)

# Certificate auth
client = AzureOpenAIEmbeddingClient.from_certificate(
    model="text-embedding-3-small",
    api_version="2024-10-21",
)
```

> **0.17.0 breaking change**: `middlewares` was removed from embedding clients. For batch processing with middleware (OTel, logging), use `EmbeddingAgent` from `agentbyte.agents` instead — see the `agentbyte-agent` skill.

---

## 7. EmbeddingResult fields

| Field | Type | Purpose |
|---|---|---|
| `embedding` | `list[float]` | First (or only) vector — shortcut for single-input calls |
| `embeddings` | `list[list[float]]` | All vectors in request order |
| `model` | `str` | Model or deployment name |
| `usage` | `Usage` | Token stats — `.tokens_input`, `.cost_estimate` |
| `metadata` | `dict` | Provider metadata |

Invariant: `result.embedding == result.embeddings[0]` always holds.

---

## 8. RetryPolicy — custom retry configuration

Both chat and embedding clients accept `retry_policy=` to override the default (3 retries, 1s–60s backoff).

```python
from agentbyte.llm import RetryPolicy
from agentbyte.llm.openai import OpenAIChatCompletionClient

client = OpenAIChatCompletionClient.from_api_key(
    model="gpt-4o-mini",
    retry_policy=RetryPolicy(
        max_retries=5,
        initial_retry_delay=0.5,
        max_retry_delay=30.0,
    ),
)
```

`RetryPolicy` fields: `max_retries` (default 3), `initial_retry_delay` (default 1.0s), `max_retry_delay` (default 60.0s). Backoff doubles each attempt, capped at `max_retry_delay`. Only `RateLimitError` and `ModelClientError` trigger retries — `AuthenticationError` and `InvalidRequestError` are non-retryable.

---

## 9. Exception handling

```python
from agentbyte.llm import (
    ModelClientError,
    RateLimitError,
    AuthenticationError,
    InvalidRequestError,
)

try:
    result = await client.create([UserMessage(content="Hello")])
except RateLimitError:
    ...   # retries exhausted — back off or queue
except AuthenticationError:
    ...   # bad API key or expired credential
except InvalidRequestError:
    ...   # malformed request (bad model name, unsupported param)
except ModelClientError:
    ...   # other provider error
```

---

## 10. Custom model pricing

Pass `ModelPricing` to get cost estimates in `result.usage.cost_estimate`:

```python
from agentbyte.llm import ModelPricing
from agentbyte.llm.openai import OpenAIChatCompletionClient

client = OpenAIChatCompletionClient.from_api_key(
    model="gpt-4o-mini",
    model_pricing=ModelPricing(input_per_1m=0.15, output_per_1m=0.60),
)

result = await client.create([UserMessage(content="Hello")])
print(result.usage.cost_estimate)   # USD, rounded to 15 decimal places
```

---

## 11. Provider fallback pattern

```python
import os
from agentbyte.llm import OpenAIEmbeddingClient, AzureOpenAIEmbeddingClient


def build_embedding_client():
    if os.getenv("OPENAI_API_KEY"):
        return OpenAIEmbeddingClient.from_api_key(model="text-embedding-3-small")

    deployment = os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME")
    if not deployment:
        raise ValueError("Set OPENAI_API_KEY or AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME")

    if os.getenv("AZURE_OPENAI_API_KEY"):
        return AzureOpenAIEmbeddingClient.from_api_key(
            model=deployment,
            api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21"),
        )

    return AzureOpenAIEmbeddingClient.from_default_credential(
        model=deployment,
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21"),
    )


embedding_client = build_embedding_client()
```

---

## Guardrails

- Canonical import paths are `from agentbyte.llm.openai import ...` and `from agentbyte.llm.azure import ...`. `from agentbyte.llm import ...` also works for all public classes.
- Create one client instance and reuse it — do not re-initialize per call.
- `result.embedding` is always the first vector, even for `create_batch()` — use `result.embeddings` for all vectors.
- `structured_output` is `None` when `output_format=` was not passed to `create()`.
- `AuthenticationError` and `InvalidRequestError` are not retried — fix the underlying cause.
- Cost precision: `usage.cost_estimate` is `None` when no `model_pricing` is configured.
- Do **not** pass `middlewares` to embedding clients — removed in 0.17.0. Use `EmbeddingAgent` for middleware-aware batch embedding.
