---
name: agentbyte-middleware
description: Complete guide for Agentbyte middleware — custom BaseMiddleware, MiddlewareContext fields, OperationType values, execution order, all built-in middlewares (Logging, Guardrail, PII, RateLimit, Metrics, Approval, ContextCompaction, Retry), UsageLoggerMiddleware with SQL backend, and OTelMiddleware with auto-instrumentation.
---

Use this skill when adding cross-cutting behaviour to agent operations — logging, safety, throttling, retries, approval policy, token compaction, usage persistence, or distributed tracing.

Middleware wraps every operation the agent performs (model calls, tool calls, memory access) without touching agent or tool business logic.

---

## 1. Custom middleware

```python
from typing import Any, Optional
from agentbyte.middleware import BaseMiddleware, MiddlewareContext

class AuditMiddleware(BaseMiddleware):

    async def process_request(self, context: MiddlewareContext) -> MiddlewareContext:
        """Runs before the operation. Mutate context.metadata to pass state forward."""
        print(f"[{context.operation}] agent={context.agent_name}")
        context.metadata["started_at"] = time.monotonic()
        return context

    async def process_response(self, context: MiddlewareContext, result: Any) -> Any:
        """Runs after a successful operation. Return the (optionally modified) result."""
        elapsed = time.monotonic() - context.metadata.get("started_at", 0)
        print(f"[{context.operation}] done in {elapsed:.3f}s")
        return result

    async def process_error(
        self, context: MiddlewareContext, error: Exception
    ) -> Optional[Any]:
        """Runs when the operation raises. Return a recovery value or None to re-raise."""
        print(f"[{context.operation}] error: {error}")
        return None   # None = propagate the exception
```

### `MiddlewareContext` fields

| Field | Type | Purpose |
|---|---|---|
| `operation` | `str` | Which operation is running (see OperationType table below) |
| `agent_name` | `str` | Name of the agent or embedding client |
| `agent_context` | `AgentContext \| None` | Live session state. `None` for non-agent callers (e.g. embedding clients) |
| `data` | `Any` | Operation-specific input payload |
| `metadata` | `dict` | Shared scratchpad — use it to pass state between `process_request` and `process_response` |

### OperationType values

```python
from agentbyte.middleware import OperationType

OperationType.MODEL_CALL      # "model_call"    — LLM chat completion
OperationType.TOOL_CALL       # "tool_call"     — tool execution
OperationType.MEMORY_ACCESS   # "memory_access" — memory retrieval
OperationType.APPROVAL        # "approval"      — tool approval gate
OperationType.EMBEDDING_CALL  # "embedding_call"— embedding client request
```

Branch inside middleware by operation:

```python
async def process_request(self, context: MiddlewareContext) -> MiddlewareContext:
    if context.operation == OperationType.TOOL_CALL:
        tool_name = context.data.get("tool_name") if isinstance(context.data, dict) else None
        print(f"tool call: {tool_name}")
    return context
```

---

## 2. Execution order

```
middlewares = [A, B, C]

process_request:  A → B → C    (forward)
  operation runs
process_response: C → B → A    (reverse)
process_error:    C → B → A    (reverse — only after all retries exhausted)
```

Register on an agent:

```python
from agentbyte.agents import Agent
from agentbyte.middleware import LoggingMiddleware, RetryMiddleware, MetricsMiddleware

agent = Agent(
    name="my-agent",
    model_client=client,
    middlewares=[
        LoggingMiddleware(),
        RetryMiddleware(max_retries=3),
        MetricsMiddleware(),
    ],
)
```

---

## 3. Built-in middlewares

| Class | Purpose |
|---|---|
| `LoggingMiddleware` | Request / response / error logs with elapsed time |
| `GuardrailMiddleware` | Block forbidden tool names and content patterns |
| `PIIRedactionMiddleware` | Mask emails, phone numbers, SSNs in payloads |
| `RateLimitMiddleware` | Fixed-window in-memory throttle |
| `MetricsMiddleware` | Track operation counts, durations, error rates |
| `ApprovalMiddleware` | Centralized approval policy enforcement |
| `ContextCompactionMiddleware` | Summarise + trim context at model-call time |
| `RetryMiddleware` | Exponential backoff retry for tool and memory operations |
| `OTelMiddleware` | OpenTelemetry spans and metrics (Gen-AI conventions) |

### LoggingMiddleware

```python
from agentbyte.middleware import LoggingMiddleware

agent = Agent(..., middlewares=[LoggingMiddleware()])
# Logs at INFO level under logger "agentbyte.middleware"
```

### GuardrailMiddleware

```python
from agentbyte.middleware import GuardrailMiddleware

agent = Agent(..., middlewares=[
    GuardrailMiddleware(
        blocked_tools=["bash_execute", "delete_file"],
        forbidden_patterns=[r"DROP TABLE", r"rm -rf"],
    )
])
```

### PIIRedactionMiddleware

```python
from agentbyte.middleware import PIIRedactionMiddleware

agent = Agent(..., middlewares=[PIIRedactionMiddleware()])
# Masks emails, phone numbers, SSNs in model and embedding payloads
```

### RateLimitMiddleware

```python
from agentbyte.middleware import RateLimitMiddleware

agent = Agent(..., middlewares=[
    RateLimitMiddleware(max_calls=10, window_seconds=60)
])
```

### MetricsMiddleware

```python
from agentbyte.middleware import MetricsMiddleware

metrics_mw = MetricsMiddleware()
agent = Agent(..., middlewares=[metrics_mw])

# After runs:
print(metrics_mw.summary())   # operation counts, avg duration, error rates
```

### ApprovalMiddleware

Centralises approval policy across tools instead of setting `ApprovalMode` per-tool.

```python
from agentbyte.middleware import ApprovalMiddleware

agent = Agent(..., middlewares=[
    ApprovalMiddleware(require_approval_for=["process_payment", "send_email"])
])
```

### ContextCompactionMiddleware

Intercepts every `model_call` and trims context when the estimated token count exceeds the threshold. First message (system prompt) and the last `keep_last` messages are always preserved.

```python
from agentbyte.middleware import ContextCompactionMiddleware

agent = Agent(..., middlewares=[
    ContextCompactionMiddleware(
        max_tokens=16_000,   # trigger threshold (chars ÷ 4 heuristic)
        keep_last=8,         # tail messages to keep verbatim
    )
])
```

Compaction detection after a run:

```python
if response.context.metadata.get("compaction_applied"):
    before = response.context.metadata["original_message_count"]
    after  = response.context.metadata["compacted_message_count"]
```

---

## 4. RetryMiddleware

Retries failed `tool_call` and `memory_access` operations with exponential backoff. `model_call` and `embedding_call` are **excluded by default** — their provider clients already implement retry, and double-registering creates nested retries (3 × 3 = 9 calls).

```python
from agentbyte.middleware import RetryMiddleware

agent = Agent(..., middlewares=[
    RetryMiddleware(
        max_retries=3,            # total attempts including the first call
        initial_interval=1.0,     # seconds before first retry
        backoff_factor=2.0,       # multiplier per retry: 1s → 2s → 4s
        max_interval=30.0,        # cap on wait time
        jitter=True,              # randomise delay ×[0.5, 1.0] to avoid thundering-herd
        retry_on=(Exception,),    # exception types that trigger a retry
        operation_types=None,     # None = default ["tool_call", "memory_access"]
    )
])
```

Override operation types (advanced — read the nested-retry warning first):

```python
RetryMiddleware(
    max_retries=2,
    operation_types=["tool_call"],   # only retry tool calls
)
```

Retry observability is written to `AgentContext.metadata`:

```python
obs = response.context.metadata.get("retry_observability", {})
# obs["history"] → list of attempt records with delay, error, will_retry
```

---

## 5. UsageLoggerMiddleware + SqlUsageBackend

Persists one `UsageEvent` per `MODEL_CALL` to a database. Requires the `[sql]` extra.

```bash
uv sync --extra sql
```

```python
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from agentbyte.middleware.sql_usage import SqlUsageBackend, create_usage_tables
from agentbyte.middleware.usage_logger import UsageLoggerMiddleware
from agentbyte.agents import Agent

# 1. Set up async SQLAlchemy engine
engine = create_async_engine("postgresql+asyncpg://user:pass@host/db")  # pragma: allowlist-secret
AsyncSessionLocal = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

async def get_session():
    async with AsyncSessionLocal() as session:
        yield session

# 2. Create the usage table (run once at startup)
await create_usage_tables(engine)

# 3. Wire up the middleware
backend = SqlUsageBackend(session_factory=get_session)
usage_mw = UsageLoggerMiddleware(backend=backend, identifier="contracts-service")

agent = Agent(..., middlewares=[usage_mw])
```

SQLite is also supported:

```python
engine = create_async_engine("sqlite+aiosqlite:///usage.db")
```

`UsageEvent` fields written per call: `run_id`, `session_id`, `user_id`, `identifier`, `agent_name`, `model`, `duration_ms`, `llm_calls`, `tokens_input`, `tokens_output`.

Import from `agentbyte.middleware.usage_logger` and `agentbyte.middleware.sql_usage` — these are **not** re-exported from `agentbyte.middleware`.

---

## 6. OTelMiddleware — distributed tracing

Emits OpenTelemetry spans and metrics following Gen-AI semantic conventions. Requires the `otel` dependency group.

```bash
uv sync --group otel
```

### Manual wiring

```python
from agentbyte.middleware import OTelMiddleware

agent = Agent(..., middlewares=[OTelMiddleware()])
```

### Automatic via environment variable

Set these before importing `agentbyte` — `OTelMiddleware` is prepended to every agent automatically:

```python
import os
os.environ["AGENTBYTE_ENABLE_OTEL"] = "true"
os.environ["OTEL_EXPORTER_OTLP_ENDPOINT"] = "http://localhost:4318"
os.environ["OTEL_SERVICE_NAME"] = "my-agent-app"

from agentbyte import Agent   # OTelMiddleware active from this point
```

Or call explicitly after import:

```python
from agentbyte.middleware import init_auto_instrumentation_from_env
init_auto_instrumentation_from_env()   # reads AGENTBYTE_ENABLE_OTEL from env
```

If OpenTelemetry libraries are not installed, `OTelMiddleware` is a no-op — it will not raise.

---

## 7. Embedding client middleware

Middleware can also be registered directly on embedding clients for `embedding_call` operations:

```python
from agentbyte.llm import OpenAIEmbeddingClient
from agentbyte.middleware import LoggingMiddleware, PIIRedactionMiddleware

client = OpenAIEmbeddingClient.from_api_key(model="text-embedding-3-small")
client.add_middleware(LoggingMiddleware())
client.add_middleware(PIIRedactionMiddleware())

result = await client.create("Contact me at user@example.com")
# PIIRedactionMiddleware masks the email before it reaches the API
```

`agent_context` is `None` inside `MiddlewareContext` for embedding operations — do not access it without a `None` guard.

---

## Guardrails

- `process_request` runs **forward** (index 0 first); `process_response` and `process_error` run **reverse** (last index first).
- `process_error` is called only after all retry attempts from `RetryMiddleware` are exhausted — do not use it as a retry hook.
- Return `None` from `process_error` to propagate the exception; return a value to recover silently.
- Do not add `RetryMiddleware` with `operation_types=["model_call"]` unless you have disabled provider-level retry first — this creates nested retries.
- `UsageLoggerMiddleware` and `SqlUsageBackend` import from their own submodules, not from `agentbyte.middleware`.
- In notebooks, register middleware once — repeated cell runs stack duplicate handlers on the same agent instance.
- `ContextCompactionMiddleware` only fires on `model_call` — it does not affect tool or memory operations.
