---
name: agentbyte-function-tools
description: Guide for creating and using tools in Agentbyte — @tool decorator, FunctionTool, BaseTool subclassing, ToolResult, ApprovalMode, and all built-in core tools (ThinkTool, TaskStatusTool, CalculatorTool, DateTimeTool, JSONParserTool, RegexTool). Use this when defining agent capabilities or picking built-in utilities.
---

Use this skill when defining tools an Agentbyte agent can execute, or when selecting from built-in utilities.

For coding tools (PythonREPLTool, BashExecuteTool, ReadFileTool, etc.) see `agentbyte-coding-tools`.
For research tools (WebSearchTool, WebFetchTool, ArxivSearchTool, etc.) see `agentbyte-research-tools`.
For sandboxed file memory see `agentbyte-memory-tool`.

## Pattern 1: `@tool` decorator (recommended for simple functions)

```python
from agentbyte.tools import tool

@tool
def get_weather(city: str, unit: str = "celsius") -> str:
    """Get the current weather for a city."""
    return f"Weather in {city}: 25°{unit[0].upper()}, Sunny"
```

Type hints are **required** for schema generation — parameters without hints default to `"string"` in the LLM schema but produce no validation.

### Async functions work identically

```python
@tool
async def fetch_exchange_rate(base: str, target: str) -> float:
    """Fetch live currency exchange rate."""
    async with httpx.AsyncClient() as client:
        response = await client.get(f"https://api.example.com/rate/{base}/{target}")
        return response.json()["rate"]
```

### Literal types generate enum constraints in the schema

```python
from typing import Literal

@tool
def set_log_level(level: Literal["debug", "info", "warning", "error"]) -> str:
    """Set the application log level."""
    logging.getLogger().setLevel(level.upper())
    return f"Log level set to {level}"
```

The LLM schema will include `"enum": ["debug", "info", "warning", "error"]` for `level`.

### Custom name and approval mode

```python
@tool(name="charge_card", description="Charge a payment card.", approval_mode="always_require")
def process_payment(amount: float, card_token: str) -> str:
    """Charge amount to the tokenised card."""
    ...
```

## Pattern 2: Manual `FunctionTool` wrapping

```python
from agentbyte.tools import FunctionTool, ApprovalMode

def calculate_tax(amount: float, rate: float = 0.15) -> float:
    return round(amount * rate, 2)

tax_tool = FunctionTool(
    calculate_tax,
    name="tax_calculator",
    description="Calculate tax for a given amount and rate.",
    approval_mode=ApprovalMode.NEVER,
)
```

Decorated functions remain directly callable for testing:

```python
result = get_weather("Berlin")   # returns the string directly
```

## Pattern 3: `BaseTool` subclass (custom / stateful tools)

Use this for tools that need constructor arguments, connection objects, or state.

```python
from agentbyte.tools import BaseTool
from agentbyte.types import ToolResult
from typing import Any

class DatabaseQueryTool(BaseTool):
    """Execute read-only SQL queries against a live database."""

    def __init__(self, connection_string: str) -> None:
        super().__init__(
            name="db_query",
            description="Run a read-only SQL query and return results as a list of rows.",
        )
        self._conn_str = connection_string

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "SQL SELECT query to execute",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum rows to return (default 100)",
                },
            },
            "required": ["query"],
        }

    async def execute(self, parameters: dict[str, Any]) -> ToolResult:
        query = parameters["query"]
        limit = parameters.get("limit", 100)
        try:
            rows = await self._run_query(query, limit)
            return ToolResult(success=True, result=rows, metadata={"query": query, "rows": len(rows)})
        except Exception as exc:
            return ToolResult(success=False, result=None, error=str(exc), metadata={"query": query})

    async def _run_query(self, query: str, limit: int) -> list[dict]:
        ...
```

## ToolResult — correct field names

```python
from agentbyte.types import ToolResult

# Success
ToolResult(success=True, result="some output", metadata={"tool_name": "my_tool"})

# Failure
ToolResult(success=False, result=None, error="Something went wrong", metadata={"tool_name": "my_tool"})
```

Fields: `success: bool`, `result: Any`, `error: str | None`, `metadata: dict`.
`ToolResult` is **immutable** (Pydantic frozen model) — do not mutate after creation.

## Registering tools with an agent

```python
from agentbyte.agents import Agent
from agentbyte.tools import tool, create_core_tools

@tool
def search_docs(query: str) -> list[str]:
    """Search internal documentation."""
    ...

agent = Agent(
    name="assistant",
    model_client=client,
    tools=[search_docs, *create_core_tools()],
)
```

## Built-in core tools (zero extra dependencies)

Import individually or use `create_core_tools()` to get all six at once.

```python
from agentbyte.tools import (
    ThinkTool,
    TaskStatusTool,
    CalculatorTool,
    DateTimeTool,
    JSONParserTool,
    RegexTool,
    create_core_tools,
)
```

| Tool | Name sent to LLM | Purpose |
|---|---|---|
| `ThinkTool` | `think` | Structured mid-task reasoning — agent records a `thought` string. Based on Anthropic research showing 54% improvement on complex tasks. |
| `TaskStatusTool` | `task_status` | Explicit completion self-assessment — agent sets `status` to `"complete"` or `"incomplete"` with a `rationale`. |
| `CalculatorTool` | `calculator` | Safe `eval` of math expressions: `sqrt`, `sin`, `cos`, `log`, `pi`, `e`, etc. |
| `DateTimeTool` | `datetime` | Three operations: `now` (UTC ISO string), `parse` (string → ISO), `format` (ISO → custom strftime). |
| `JSONParserTool` | `json_parser` | Parse a JSON string; optionally extract a value via dot-path (e.g. `"user.address.city"`). |
| `RegexTool` | `regex` | `search`, `match`, `findall`, `replace` with optional `i`/`m`/`s` flags. |

### Quick examples

```python
# All six at once
tools = create_core_tools()

# Think tool — give the agent space to reason before acting
ThinkTool()

# Task status — force the agent to assess completion explicitly
TaskStatusTool()

# Calculator
CalculatorTool()   # agent calls: {"expression": "sqrt(144) + pi"}

# DateTime
DateTimeTool()     # agent calls: {"operation": "now"}
                   #              {"operation": "format", "value": "2025-01-15T10:00:00Z", "format": "%d %b %Y"}

# JSON parser
JSONParserTool()   # agent calls: {"json_string": "{...}", "path": "data.items.0.id"}

# Regex
RegexTool()        # agent calls: {"operation": "findall", "pattern": r"\d+", "text": "order 42 item 7"}
```

## ApprovalMode reference

```python
from agentbyte.tools import ApprovalMode

ApprovalMode.NEVER   # execute immediately (default for most tools)
ApprovalMode.ALWAYS  # pause and require human approval before execution
```

See `agentbyte-tool-approval` for the full human-in-the-loop workflow.

## Guardrails

- Always provide a docstring — it becomes the tool description sent to the LLM.
- Always type-hint every parameter — schema generation depends on type hints.
- `ToolResult` fields are `success`, `result`, `error`, `metadata` — there is no `content` field.
- Tools should be stateless or receive all state via parameters; avoid global mutable state.
- Import from `agentbyte.tools` (not `agentbyte.tools.base` or `agentbyte.tools.function`).
