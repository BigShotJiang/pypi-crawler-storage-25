---
name: agentbyte-coding-tools
description: Guide for Agentbyte coding tools — ReadFileTool, WriteFileTool, ListDirectoryTool, GrepSearchTool, BashExecuteTool, PythonREPLTool. Use when agents need to read/write files, search code, run shell commands, or execute Python code inside a sandboxed workspace.
---

Use this skill when an agent needs to interact with the filesystem, run shell commands, or execute Python code.

All coding tools enforce **workspace isolation** — any path that resolves outside the configured workspace root is rejected with an error `ToolResult`. No extra pip dependencies required.

## Import

```python
from agentbyte.tools.coding_tools import (
    ReadFileTool,
    WriteFileTool,
    ListDirectoryTool,
    GrepSearchTool,
    BashExecuteTool,
    PythonREPLTool,
    create_coding_tools,
)
```

## Pattern 1: Factory (recommended)

```python
from pathlib import Path
from agentbyte.tools.coding_tools import create_coding_tools
from agentbyte.agents import Agent

tools = create_coding_tools(
    workspace=Path("/tmp/agent_workspace"),
    bash_timeout=30,
    repl_timeout=30,
)

agent = Agent(
    name="coding-agent",
    model_client=client,
    tools=tools,
)
```

`create_coding_tools` returns all six tools pre-configured with the same workspace root:
`ReadFileTool`, `WriteFileTool`, `ListDirectoryTool`, `GrepSearchTool`, `BashExecuteTool`, `PythonREPLTool`.

## Pattern 2: Individual tools

```python
from pathlib import Path
from agentbyte.tools import ApprovalMode
from agentbyte.tools.coding_tools import ReadFileTool, PythonREPLTool, BashExecuteTool

workspace = Path("/tmp/agent_workspace")

read_tool  = ReadFileTool(workspace=workspace)
repl_tool  = PythonREPLTool(workspace=workspace, timeout=60, approval_mode=ApprovalMode.ALWAYS)
bash_tool  = BashExecuteTool(workspace=workspace, timeout=30, approval_mode=ApprovalMode.ALWAYS)
```

## Tool reference

### ReadFileTool — `read_file`

Reads a file and returns its content as a string.

```python
# Agent calls:
{"file_path": "src/main.py"}
{"file_path": "data/report.csv", "encoding": "latin-1"}
```

Returns: `ToolResult.result` is the file content string.
`metadata` includes `size` (bytes) and `lines` count.

### WriteFileTool — `write_file`

Three sub-operations on a single tool:

| Operation | Required params | Effect |
|---|---|---|
| Full write | `file_path`, `content` | Create or overwrite the file (parent dirs auto-created) |
| str_replace | `file_path`, `old_str`, `new_str` | Replace **first occurrence** of `old_str` |
| insert_at_line | `file_path`, `insert_line`, `insert_content` | Insert after 1-based line number |

```python
# Full write
{"file_path": "notes.md", "content": "# Notes\nHello world"}

# Patch a specific string
{"file_path": "config.py", "old_str": "DEBUG = False", "new_str": "DEBUG = True"}

# Insert after line 5
{"file_path": "main.py", "insert_line": 5, "insert_content": "import logging"}
```

### ListDirectoryTool — `list_directory`

```python
{"directory_path": "src"}               # list src/
{"directory_path": ".", "recursive": true}  # full tree
```

Returns: `ToolResult.result` is a list of `{"name": str, "type": "file"|"directory", "size": int|None}`.

### GrepSearchTool — `grep_search`

Uses `rg` (ripgrep) when available, falls back to `grep`.

```python
{"pattern": "def run", "path": "src", "file_pattern": "*.py"}
{"pattern": "TODO", "case_sensitive": false}
```

Returns: list of `{"file": str, "line": int, "text": str}` matches.

### BashExecuteTool — `bash_execute`

**Default approval mode: `ApprovalMode.ALWAYS`** — always pauses for human confirmation.

```python
{"command": "uv run pytest tests -q"}
{"command": "git status", "timeout": 10}
```

Returns: `ToolResult.result` is `{"stdout": str, "stderr": str}`.
`metadata` includes `returncode`.
Commands are killed on timeout and return `success=False`.

### PythonREPLTool — `python_repl`

Executes Python code in a **fresh subprocess** — no shared state between calls.

**Default approval mode: `ApprovalMode.ALWAYS`** — always pauses for human confirmation.

```python
{"code": "import math\nprint(math.pi)"}
{"code": "with open('output.txt', 'w') as f:\n    f.write('done')", "timeout": 10}
```

Returns: `ToolResult.result` is stdout as a string (or `None` if empty).
`ToolResult.error` contains stderr when `returncode != 0`.

## CodingToolsConfig (Pydantic serialization)

```python
from agentbyte.tools.coding_tools import CodingToolsConfig
from agentbyte.tools import ApprovalMode
from pathlib import Path

config = CodingToolsConfig(
    workspace=Path("/tmp/agent_workspace"),
    bash_timeout=60,
    bash_approval=ApprovalMode.ALWAYS,
    repl_timeout=60,
    repl_approval=ApprovalMode.ALWAYS,
)
tools = config.build_tools()
```

## Guardrails

- **Workspace isolation**: all paths are validated with `Path.resolve()` + `relative_to(workspace)`. Paths like `../../etc/passwd` are rejected.
- **`BashExecuteTool` and `PythonREPLTool` default to `ApprovalMode.ALWAYS`** — do not lower this without explicit justification.
- **No shared REPL state**: each `PythonREPLTool.execute()` call spawns a fresh subprocess; do not rely on variables from a previous call.
- **workspace defaults to `Path.cwd()`** when not provided — always set an explicit workspace in production.
- Import from `agentbyte.tools.coding_tools`, not `agentbyte.tools` (coding tools are not re-exported from the top-level namespace).
