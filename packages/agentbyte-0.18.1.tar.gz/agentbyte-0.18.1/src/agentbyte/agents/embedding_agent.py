from __future__ import annotations

import asyncio
from typing import Any, AsyncGenerator, Optional

from agentbyte.context import AgentContext
from agentbyte.llm.embeddings_base import BaseEmbeddingClient
from agentbyte.llm.types import EmbeddingResult
from agentbyte.middleware.base import MiddlewareChain, OperationType
from agentbyte.middleware import BaseMiddleware

from .types import EmbeddingBatchProgressEvent


class EmbeddingAgent:
    """Agent-layer wrapper around an embedding client.

    Splits large text lists into batches, runs them through the embedding client
    (sequentially or concurrently), and aggregates the results. Each batch is
    executed through the middleware chain with a real AgentContext, enabling OTel
    trace correlation and consistent pipeline observability.
    """

    def __init__(
        self,
        name: str,
        embedding_client: BaseEmbeddingClient,
        middlewares: Optional[list[BaseMiddleware]] = None,
        batch_size: int = 100,
        max_concurrent_batches: int = 1,
    ) -> None:
        if batch_size < 1:
            raise ValueError("batch_size must be at least 1")
        if max_concurrent_batches < 1:
            raise ValueError("max_concurrent_batches must be at least 1")
        self.name = name
        self.embedding_client = embedding_client
        self.middleware_chain = MiddlewareChain(middlewares or [])
        self.batch_size = batch_size
        self.max_concurrent_batches = max_concurrent_batches

    async def run(
        self,
        texts: list[str],
        context: Optional[AgentContext] = None,
    ) -> EmbeddingResult:
        """Embed all texts and return a single aggregated EmbeddingResult."""
        result: EmbeddingResult | None = None
        async for item in self.run_stream(texts, context=context):
            if isinstance(item, EmbeddingResult):
                result = item
        if result is None:
            raise RuntimeError("run_stream completed without yielding an EmbeddingResult")
        return result

    async def run_stream(
        self,
        texts: list[str],
        context: Optional[AgentContext] = None,
    ) -> AsyncGenerator[EmbeddingBatchProgressEvent | EmbeddingResult, None]:
        """Embed all texts, yielding progress events per batch then a final EmbeddingResult.

        Each batch is routed through the middleware chain with the provided AgentContext,
        enabling OTel trace correlation when called from a workflow or agent.

        With max_concurrent_batches > 1, batches run concurrently bounded by a semaphore.
        Progress events arrive in completion order (not batch-index order) — use
        batch_index to determine position, not arrival order.
        """
        if not texts:
            raise ValueError("texts cannot be empty")

        batches = [
            texts[i : i + self.batch_size]
            for i in range(0, len(texts), self.batch_size)
        ]
        total_batches = len(batches)

        if self.max_concurrent_batches == 1:
            completed = 0
            batch_results: list[EmbeddingResult] = []
            for i, batch in enumerate(batches):
                batch_result = await self._run_batch(batch, i, total_batches, context)
                batch_results.append(batch_result)
                completed += len(batch)
                yield EmbeddingBatchProgressEvent(
                    source=self.name,
                    batch_index=i,
                    total_batches=total_batches,
                    completed_texts=completed,
                    total_texts=len(texts),
                )
            yield _aggregate(batch_results)
        else:
            sem = asyncio.Semaphore(self.max_concurrent_batches)

            async def _run_with_sem(batch: list[str], idx: int) -> tuple[int, EmbeddingResult]:
                async with sem:
                    return idx, await self._run_batch(batch, idx, total_batches, context)

            tasks = [
                asyncio.create_task(_run_with_sem(batch, i))
                for i, batch in enumerate(batches)
            ]
            concurrent_results: dict[int, EmbeddingResult] = {}
            completed = 0
            for coro in asyncio.as_completed(tasks):
                idx, batch_result = await coro
                concurrent_results[idx] = batch_result
                completed += len(batches[idx])
                yield EmbeddingBatchProgressEvent(
                    source=self.name,
                    batch_index=idx,
                    total_batches=total_batches,
                    completed_texts=completed,
                    total_texts=len(texts),
                )
            yield _aggregate([concurrent_results[i] for i in range(total_batches)])

    async def _run_batch(
        self,
        batch: list[str],
        batch_index: int,
        total_batches: int,
        context: Optional[AgentContext],
    ) -> EmbeddingResult:
        async def _call(payload: dict[str, Any]) -> EmbeddingResult:
            return await self.embedding_client.create_batch(payload["texts"])

        return await self.middleware_chain.execute(
            operation=OperationType.EMBEDDING_CALL.value,
            agent_name=self.name,
            agent_context=context,
            data={"texts": batch, "batch_index": batch_index, "total_batches": total_batches},
            func=_call,
            metadata={"model": self.embedding_client.model, "batch_size": len(batch)},
        )


def _aggregate(results: list[EmbeddingResult]) -> EmbeddingResult:
    all_embeddings: list[list[float]] = []
    for r in results:
        all_embeddings.extend(r.embeddings)

    total_usage = results[0].usage
    for r in results[1:]:
        total_usage = total_usage + r.usage

    return EmbeddingResult(
        embedding=all_embeddings[0],
        embeddings=all_embeddings,
        model=results[0].model,
        usage=total_usage,
        metadata={"batch_count": len(results)},
    )
