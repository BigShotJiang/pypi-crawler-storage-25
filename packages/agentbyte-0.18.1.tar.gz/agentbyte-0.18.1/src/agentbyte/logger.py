"""Execution-level event logger for agent, orchestrator, and workflow streams.

:class:`StreamEventLogger` operates one layer above the middleware chain — it
consumes the events yielded by ``run_stream()`` and routes each to the
appropriate standard log level so callers never have to write their own
``isinstance`` dispatch.

Log format matches :class:`~agentbyte.middleware.LoggingMiddleware`:
    ``[source] HH:MM:SS | event_type  key=value ...``

Logger name: ``agentbyte.stream`` (distinct from the middleware logger
``agentbyte.middleware`` so the two can be filtered independently).
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Optional


class StreamEventLogger:
    """Logs events from ``run_stream()`` using standard Python log levels.

    Each method — ``info()``, ``debug()``, ``warning()``, ``error()``,
    ``exception()`` — handles only the event types that belong to that level.
    Every other item (including ``Message``, ``AgentResponse``, raw token
    chunks, and non-event objects) is silently ignored, so callers can pass
    every item from the stream without pre-filtering.

    This logger sits at the agent/orchestrator/workflow execution layer, above
    the :class:`~agentbyte.middleware.LoggingMiddleware` which operates at the
    LLM/tool operation layer.  The two loggers are complementary and can be
    active at the same time without conflict.

    Args:
        logger: Logger to write to.  Defaults to ``agentbyte.stream``.

    Example — single agent::

        from agentbyte.logger import StreamEventLogger

        stream_logger = StreamEventLogger()

        async for item in agent.run_stream("hello", verbose=True):
            stream_logger.info(item)
            stream_logger.debug(item)
            stream_logger.warning(item)
            stream_logger.error(item)
            stream_logger.exception(item)

    Example — orchestrator with multiple agents::

        async for item in orchestrator.run_stream("research this", verbose=True):
            stream_logger.info(item)
            stream_logger.debug(item)
            stream_logger.warning(item)
            stream_logger.error(item)
            stream_logger.exception(item)
    """

    _DEFAULT_LOGGER = "agentbyte.stream"

    def __init__(self, logger: Optional[logging.Logger] = None) -> None:
        self._logger = logger or logging.getLogger(self._DEFAULT_LOGGER)

    @staticmethod
    def _orchestration_event_type(item: Any) -> str:
        class_name = item.__class__.__name__
        if class_name.endswith("Event"):
            class_name = class_name[:-5]

        event_chars: list[str] = []
        for index, char in enumerate(class_name):
            if char.isupper() and index > 0:
                event_chars.append("_")
            event_chars.append(char.lower())
        return "".join(event_chars)

    @staticmethod
    def _fmt(item: Any) -> tuple[str, str, str]:
        event_type = getattr(item, "event_type", None)
        if event_type is None:
            event_type = StreamEventLogger._orchestration_event_type(item)
        else:
            event_type = getattr(event_type, "value", event_type)

        source = getattr(item, "source", None)
        if source is None:
            workflow_id = getattr(item, "workflow_id", "workflow")
            origin = getattr(item, "origin", "workflow")
            source = f"{getattr(origin, 'value', origin)}:{workflow_id[:8]}"

        timestamp = item.timestamp
        if isinstance(timestamp, (int, float)):
            time_str = datetime.fromtimestamp(timestamp).strftime("%H:%M:%S")
        else:
            time_str = timestamp.strftime("%H:%M:%S")

        return (
            source,
            time_str,
            str(event_type),
        )

    def info(self, item: Any) -> None:
        """Emit INFO for task/tool start-complete and workflow progress milestones.

        All other items are silently ignored.
        """
        from agentbyte.agents.types import (
            BaseEvent,
            TaskCompleteEvent,
            TaskStartEvent,
            ToolCallEvent,
        )
        from agentbyte.types import (
            AgentExecutionCompleteEvent,
            OrchestrationCompleteEvent,
            OrchestrationEvent,
            OrchestrationStartEvent,
        )
        from agentbyte.workflow.core.models import (
            StepCompletedEvent,
            StepStartedEvent,
            WorkflowCompletedEvent,
            WorkflowEvent,
            WorkflowStartedEvent,
        )

        if not isinstance(item, (BaseEvent, OrchestrationEvent, WorkflowEvent)):
            return

        source, time_str, event_type = self._fmt(item)

        if isinstance(item, TaskStartEvent):
            self._logger.info("[%s] %s | %s", source, time_str, event_type)

        elif isinstance(item, TaskCompleteEvent):
            self._logger.info(
                "[%s] %s | %s  finish_reason=%s",
                source,
                time_str,
                event_type,
                item.finish_reason,
            )

        elif isinstance(item, ToolCallEvent):
            self._logger.info(
                "[%s] %s | %s  tool=%s  call_id=%s",
                source,
                time_str,
                event_type,
                item.tool_name,
                item.call_id,
            )

        elif isinstance(item, OrchestrationStartEvent):
            self._logger.info(
                "[%s] %s | %s  pattern=%s",
                source,
                time_str,
                event_type,
                item.pattern,
            )

        elif isinstance(item, OrchestrationCompleteEvent):
            self._logger.info(
                "[%s] %s | %s  stop_reason=%s",
                source,
                time_str,
                event_type,
                item.stop_reason,
            )

        elif isinstance(item, AgentExecutionCompleteEvent) and item.success:
            self._logger.info(
                "[%s] %s | %s  agent=%s  messages=%s",
                source,
                time_str,
                event_type,
                item.executing_agent,
                item.message_count,
            )

        elif isinstance(item, WorkflowStartedEvent):
            self._logger.info("[%s] %s | %s", source, time_str, event_type)

        elif isinstance(item, WorkflowCompletedEvent):
            self._logger.info(
                "[%s] %s | %s  steps=%s",
                source,
                time_str,
                event_type,
                len(item.execution.step_executions),
            )

        elif isinstance(item, StepStartedEvent):
            self._logger.info(
                "[%s] %s | %s  step=%s",
                source,
                time_str,
                event_type,
                item.step_id,
            )

        elif isinstance(item, StepCompletedEvent):
            self._logger.info(
                "[%s] %s | %s  step=%s  duration=%.3fs",
                source,
                time_str,
                event_type,
                item.step_id,
                item.duration_seconds,
            )

    def debug(self, item: Any) -> None:
        """Emit DEBUG for model/tool/memory detail events.

        Handles ``ModelCallEvent``, ``ModelResponseEvent``,
        ``ModelStreamChunkEvent``, ``ToolCallResponseEvent``,
        ``ToolValidationEvent`` (when valid), ``MemoryUpdateEvent``,
        ``MemoryRetrievalEvent``, and workflow detail events such as
        ``StepProgressEvent``. All other items are silently ignored.
        """
        from agentbyte.agents.types import (
            BaseEvent,
            MemoryRetrievalEvent,
            MemoryUpdateEvent,
            ModelCallEvent,
            ModelResponseEvent,
            ModelStreamChunkEvent,
            ToolCallResponseEvent,
            ToolValidationEvent,
        )
        from agentbyte.types import (
            AgentExecutionStartEvent,
            AgentSelectionEvent,
            OrchestrationEvent,
        )
        from agentbyte.workflow.core.models import (
            CheckpointSavedEvent,
            EdgeActivatedEvent,
            StepProgressEvent,
            WorkflowEvent,
            WorkflowResumedEvent,
        )

        if not isinstance(item, (BaseEvent, OrchestrationEvent, WorkflowEvent)):
            return

        source, time_str, event_type = self._fmt(item)

        if isinstance(item, ModelStreamChunkEvent):
            self._logger.debug(
                "[%s] %s | %s  is_final=%s",
                source,
                time_str,
                event_type,
                item.is_final,
            )

        elif isinstance(item, ToolValidationEvent) and item.is_valid:
            self._logger.debug(
                "[%s] %s | %s  tool=%s  valid=True",
                source,
                time_str,
                event_type,
                item.tool_name,
            )

        elif isinstance(
            item,
            (
                ModelCallEvent,
                ModelResponseEvent,
                ToolCallResponseEvent,
                MemoryUpdateEvent,
                MemoryRetrievalEvent,
            ),
        ):
            self._logger.debug("[%s] %s | %s", source, time_str, event_type)

        elif isinstance(item, StepProgressEvent):
            progress_suffix = ""
            if item.completed is not None and item.total is not None:
                progress_suffix = f"  progress={item.completed}/{item.total}"
            self._logger.debug(
                "[%s] %s | %s  step=%s  message=%s%s",
                source,
                time_str,
                event_type,
                item.step_id,
                item.message,
                progress_suffix,
            )

        elif isinstance(item, EdgeActivatedEvent):
            self._logger.debug(
                "[%s] %s | %s  from=%s  to=%s",
                source,
                time_str,
                event_type,
                item.from_step,
                item.to_step,
            )

        elif isinstance(item, CheckpointSavedEvent):
            self._logger.debug(
                "[%s] %s | %s  checkpoint_id=%s  completed=%s  total=%s",
                source,
                time_str,
                event_type,
                item.checkpoint_id,
                item.completed_steps,
                item.total_steps,
            )

        elif isinstance(item, WorkflowResumedEvent):
            self._logger.debug(
                "[%s] %s | %s  checkpoint_id=%s",
                source,
                time_str,
                event_type,
                item.checkpoint_id,
            )

        elif isinstance(item, AgentSelectionEvent):
            self._logger.debug(
                "[%s] %s | %s  agent=%s  reason=%s",
                source,
                time_str,
                event_type,
                item.selected_agent,
                item.selection_reason,
            )

        elif isinstance(item, AgentExecutionStartEvent):
            self._logger.debug(
                "[%s] %s | %s  agent=%s  context_size=%s",
                source,
                time_str,
                event_type,
                item.executing_agent,
                item.context_size,
            )

    def warning(self, item: Any) -> None:
        """Emit WARNING for approval/suspension events and invalid validation.

        All other items are silently ignored.
        """
        from agentbyte.agents.types import (
            BaseEvent,
            ToolApprovalEvent,
            ToolValidationEvent,
        )
        from agentbyte.types import AgentExecutionCompleteEvent, OrchestrationEvent
        from agentbyte.workflow.core.models import (
            WorkflowApprovalRequestedEvent,
            WorkflowEvent,
            WorkflowInputRequestedEvent,
            WorkflowSuspendedEvent,
        )

        if not isinstance(item, (BaseEvent, OrchestrationEvent, WorkflowEvent)):
            return

        source, time_str, event_type = self._fmt(item)

        if isinstance(item, ToolApprovalEvent):
            self._logger.warning(
                "[%s] %s | %s  tool=%s  request_id=%s",
                source,
                time_str,
                event_type,
                item.approval_request.tool_name,
                item.approval_request.request_id,
            )

        elif isinstance(item, ToolValidationEvent) and not item.is_valid:
            errors = ", ".join(item.errors or [])
            self._logger.warning(
                "[%s] %s | %s  tool=%s  valid=False  errors=%s",
                source,
                time_str,
                event_type,
                item.tool_name,
                errors,
            )

        elif isinstance(item, WorkflowInputRequestedEvent):
            self._logger.warning(
                "[%s] %s | %s  step=%s  request_id=%s",
                source,
                time_str,
                event_type,
                item.step_id,
                item.request.request_id,
            )

        elif isinstance(item, WorkflowApprovalRequestedEvent):
            self._logger.warning(
                "[%s] %s | %s  step=%s  request_id=%s",
                source,
                time_str,
                event_type,
                item.step_id,
                item.request.request_id,
            )

        elif isinstance(item, WorkflowSuspendedEvent):
            self._logger.warning(
                "[%s] %s | %s  reason=%s",
                source,
                time_str,
                event_type,
                item.reason,
            )

        elif isinstance(item, AgentExecutionCompleteEvent) and not item.success:
            self._logger.warning(
                "[%s] %s | %s  agent=%s  messages=%s  success=False",
                source,
                time_str,
                event_type,
                item.executing_agent,
                item.message_count,
            )

    def error(self, item: Any) -> None:
        """Emit ERROR for agent and workflow failure events.

        All other items are silently ignored.
        """
        from agentbyte.agents.types import (
            BaseEvent,
            ErrorEvent,
            FatalErrorEvent,
        )
        from agentbyte.types import OrchestrationEvent
        from agentbyte.workflow.core.models import (
            StepFailedEvent,
            WorkflowCancelledEvent,
            WorkflowEvent,
            WorkflowFailedEvent,
        )

        if not isinstance(item, (BaseEvent, OrchestrationEvent, WorkflowEvent)):
            return

        source, time_str, event_type = self._fmt(item)

        if isinstance(item, (ErrorEvent, FatalErrorEvent)):
            self._logger.error(
                "[%s] %s | %s  error=%s",
                source,
                time_str,
                event_type,
                item.error_message,
            )

        elif isinstance(item, WorkflowFailedEvent):
            self._logger.error(
                "[%s] %s | %s  error=%s",
                source,
                time_str,
                event_type,
                item.error_details.message,
            )

        elif isinstance(item, StepFailedEvent):
            self._logger.error(
                "[%s] %s | %s  step=%s  error=%s",
                source,
                time_str,
                event_type,
                item.step_id,
                item.error_details.message,
            )

        elif isinstance(item, WorkflowCancelledEvent):
            self._logger.error(
                "[%s] %s | %s  reason=%s",
                source,
                time_str,
                event_type,
                item.reason,
            )

    def exception(self, item: Any) -> None:
        """Emit ERROR with traceback for unrecoverable failure events.

        Uses ``logger.exception()`` which appends the current exception
        traceback when called inside an ``except`` block.  Intended for
        ``FatalErrorEvent`` — unrecoverable failures where the full traceback
        context matters most. ``WorkflowFailedEvent`` is included so workflow
        runner callers can log terminal failures the same way. ``ErrorEvent``
        (recoverable) is intentionally excluded; use ``error()`` for those.

        All other items are silently ignored.
        """
        from agentbyte.agents.types import (
            BaseEvent,
            FatalErrorEvent,
        )
        from agentbyte.types import OrchestrationEvent
        from agentbyte.workflow.core.models import WorkflowEvent, WorkflowFailedEvent

        if not isinstance(item, (BaseEvent, OrchestrationEvent, WorkflowEvent)):
            return

        source, time_str, event_type = self._fmt(item)

        if isinstance(item, FatalErrorEvent):
            self._logger.exception(
                "[%s] %s | %s  error=%s",
                source,
                time_str,
                event_type,
                item.error_message,
            )

        elif isinstance(item, WorkflowFailedEvent):
            self._logger.exception(
                "[%s] %s | %s  error=%s",
                source,
                time_str,
                event_type,
                item.error_details.message,
            )


__all__ = ["StreamEventLogger"]
