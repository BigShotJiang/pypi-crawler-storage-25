"""Tests for EmbeddingAgent."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock

import pytest

from agentbyte.agents.embedding_agent import EmbeddingAgent, _aggregate
from agentbyte.agents.types import EmbeddingBatchProgressEvent
from agentbyte.context import AgentContext
from agentbyte.llm.types import EmbeddingResult
from agentbyte.messages import Usage
from agentbyte.middleware.base import BaseMiddleware, MiddlewareContext


def _make_result(
    embeddings: list[list[float]],
    model: str = "text-embedding-3-small",
    tokens: int = 10,
    cost: float = 0.001,
) -> EmbeddingResult:
    return EmbeddingResult(
        embedding=embeddings[0],
        embeddings=embeddings,
        model=model,
        usage=Usage(
            duration_ms=100,
            llm_calls=1,
            tokens_input=tokens,
            tokens_output=0,
            tool_calls=0,
            memory_operations=0,
            cost_estimate=cost,
        ),
        metadata={},
    )


def _make_client(batch_results: list[EmbeddingResult]) -> Any:
    """Return a fake embedding client that returns results in sequence."""
    client = MagicMock()
    client.model = "text-embedding-3-small"
    call_count = {"n": 0}

    async def _create_batch(texts: list[str], **kwargs: Any) -> EmbeddingResult:
        result = batch_results[call_count["n"]]
        call_count["n"] += 1
        return result

    client.create_batch = _create_batch
    return client


# ===== run() tests =====


@pytest.mark.asyncio
async def test_run_returns_single_batch_result():
    texts = ["a", "b", "c"]
    fake_result = _make_result([[0.1, 0.2], [0.3, 0.4], [0.5, 0.6]])
    client = _make_client([fake_result])
    agent = EmbeddingAgent(name="test", embedding_client=client, batch_size=10)

    result = await agent.run(texts)

    assert result.embeddings == [[0.1, 0.2], [0.3, 0.4], [0.5, 0.6]]
    assert result.model == "text-embedding-3-small"


@pytest.mark.asyncio
async def test_run_aggregates_multiple_batches():
    texts = ["a", "b", "c", "d", "e"]
    batch1 = _make_result([[0.1], [0.2]], tokens=20, cost=0.002)
    batch2 = _make_result([[0.3], [0.4]], tokens=20, cost=0.002)
    batch3 = _make_result([[0.5]], tokens=10, cost=0.001)
    client = _make_client([batch1, batch2, batch3])
    agent = EmbeddingAgent(name="test", embedding_client=client, batch_size=2)

    result = await agent.run(texts)

    assert result.embeddings == [[0.1], [0.2], [0.3], [0.4], [0.5]]
    assert result.embedding == [0.1]
    assert result.usage.tokens_input == 50
    assert result.usage.llm_calls == 3
    assert result.usage.cost_estimate == pytest.approx(0.005)


@pytest.mark.asyncio
async def test_run_empty_texts_raises():
    client = _make_client([])
    agent = EmbeddingAgent(name="test", embedding_client=client)

    with pytest.raises(ValueError, match="cannot be empty"):
        await agent.run([])


def test_batch_size_zero_raises():
    client = MagicMock()
    with pytest.raises(ValueError, match="batch_size must be at least 1"):
        EmbeddingAgent(name="test", embedding_client=client, batch_size=0)


def test_max_concurrent_batches_zero_raises():
    client = MagicMock()
    with pytest.raises(ValueError, match="max_concurrent_batches must be at least 1"):
        EmbeddingAgent(name="test", embedding_client=client, max_concurrent_batches=0)


# ===== run_stream() tests =====


@pytest.mark.asyncio
async def test_run_stream_yields_progress_then_result():
    texts = ["a", "b", "c", "d", "e"]
    batch1 = _make_result([[0.1], [0.2]])
    batch2 = _make_result([[0.3], [0.4]])
    batch3 = _make_result([[0.5]])
    client = _make_client([batch1, batch2, batch3])
    agent = EmbeddingAgent(name="test", embedding_client=client, batch_size=2)

    events = []
    final: EmbeddingResult | None = None
    async for item in agent.run_stream(texts):
        if isinstance(item, EmbeddingBatchProgressEvent):
            events.append(item)
        elif isinstance(item, EmbeddingResult):
            final = item

    assert len(events) == 3
    assert final is not None
    assert len(final.embeddings) == 5


@pytest.mark.asyncio
async def test_run_stream_progress_event_fields():
    texts = ["a", "b", "c", "d", "e"]
    client = _make_client([
        _make_result([[0.1], [0.2]]),
        _make_result([[0.3], [0.4]]),
        _make_result([[0.5]]),
    ])
    agent = EmbeddingAgent(name="embedder", embedding_client=client, batch_size=2)

    events: list[EmbeddingBatchProgressEvent] = []
    async for item in agent.run_stream(texts):
        if isinstance(item, EmbeddingBatchProgressEvent):
            events.append(item)

    assert events[0].batch_index == 0
    assert events[0].total_batches == 3
    assert events[0].completed_texts == 2
    assert events[0].total_texts == 5

    assert events[1].batch_index == 1
    assert events[1].completed_texts == 4

    assert events[2].batch_index == 2
    assert events[2].completed_texts == 5


@pytest.mark.asyncio
async def test_run_stream_single_batch_one_progress_event():
    texts = ["x", "y"]
    client = _make_client([_make_result([[0.1], [0.2]])])
    agent = EmbeddingAgent(name="test", embedding_client=client, batch_size=10)

    progress_events = []
    async for item in agent.run_stream(texts):
        if isinstance(item, EmbeddingBatchProgressEvent):
            progress_events.append(item)

    assert len(progress_events) == 1
    assert progress_events[0].total_batches == 1
    assert progress_events[0].completed_texts == 2


@pytest.mark.asyncio
async def test_run_stream_event_source_matches_agent_name():
    client = _make_client([_make_result([[0.1]])])
    agent = EmbeddingAgent(name="my-embedder", embedding_client=client, batch_size=10)

    async for item in agent.run_stream(["text"]):
        if isinstance(item, EmbeddingBatchProgressEvent):
            assert item.source == "my-embedder"


# ===== middleware tests =====


@pytest.mark.asyncio
async def test_run_passes_agent_context_to_middleware():
    captured: list[MiddlewareContext] = []

    class CapturingMiddleware(BaseMiddleware):
        async def process_request(self, ctx: MiddlewareContext) -> MiddlewareContext:
            captured.append(ctx)
            return ctx

        async def process_response(self, ctx: MiddlewareContext, result: Any) -> Any:
            return result

        async def process_error(self, ctx: MiddlewareContext, error: Exception) -> Any:
            raise error

    agent_context = AgentContext()
    client = _make_client([_make_result([[0.1]])])
    agent = EmbeddingAgent(
        name="test",
        embedding_client=client,
        middlewares=[CapturingMiddleware()],
    )

    await agent.run(["hello"], context=agent_context)

    assert len(captured) == 1
    assert captured[0].agent_context is agent_context
    assert captured[0].agent_name == "test"
    assert captured[0].operation == "embedding_call"


@pytest.mark.asyncio
async def test_run_without_context_passes_none_to_middleware():
    captured: list[MiddlewareContext] = []

    class CapturingMiddleware(BaseMiddleware):
        async def process_request(self, ctx: MiddlewareContext) -> MiddlewareContext:
            captured.append(ctx)
            return ctx

        async def process_response(self, ctx: MiddlewareContext, result: Any) -> Any:
            return result

        async def process_error(self, ctx: MiddlewareContext, error: Exception) -> Any:
            raise error

    client = _make_client([_make_result([[0.1]])])
    agent = EmbeddingAgent(
        name="test",
        embedding_client=client,
        middlewares=[CapturingMiddleware()],
    )

    await agent.run(["hello"])

    assert captured[0].agent_context is None


# ===== _aggregate() unit tests =====


def test_aggregate_combines_embeddings_in_order():
    r1 = _make_result([[0.1, 0.2], [0.3, 0.4]])
    r2 = _make_result([[0.5, 0.6]])
    result = _aggregate([r1, r2])

    assert result.embeddings == [[0.1, 0.2], [0.3, 0.4], [0.5, 0.6]]
    assert result.embedding == [0.1, 0.2]


def test_aggregate_sums_usage():
    r1 = _make_result([[0.1]], tokens=100, cost=0.01)
    r2 = _make_result([[0.2]], tokens=200, cost=0.02)
    result = _aggregate([r1, r2])

    assert result.usage.tokens_input == 300
    assert result.usage.llm_calls == 2
    assert result.usage.cost_estimate == pytest.approx(0.03)


def test_aggregate_records_batch_count():
    results = [_make_result([[float(i)]]) for i in range(5)]
    result = _aggregate(results)
    assert result.metadata["batch_count"] == 5


# ===== concurrent batching tests =====


@pytest.mark.asyncio
async def test_run_concurrent_preserves_result_order():
    """Embeddings must be in original text order regardless of completion order."""
    texts = ["a", "b", "c", "d", "e"]
    results_by_idx = [
        _make_result([[0.1], [0.2]]),
        _make_result([[0.3], [0.4]]),
        _make_result([[0.5]]),
    ]
    call_count = {"n": 0}

    async def _create_batch(texts_in: list[str]) -> EmbeddingResult:
        idx = call_count["n"]
        call_count["n"] += 1
        return results_by_idx[idx]

    client = MagicMock()
    client.model = "text-embedding-3-small"
    client.create_batch = _create_batch

    agent = EmbeddingAgent(
        name="test", embedding_client=client, batch_size=2, max_concurrent_batches=3
    )
    result = await agent.run(texts)

    assert result.embeddings == [[0.1], [0.2], [0.3], [0.4], [0.5]]
    assert result.embedding == [0.1]


@pytest.mark.asyncio
async def test_run_stream_concurrent_yields_all_progress_events():
    texts = ["a", "b", "c", "d", "e"]
    client = _make_client([
        _make_result([[0.1], [0.2]]),
        _make_result([[0.3], [0.4]]),
        _make_result([[0.5]]),
    ])
    agent = EmbeddingAgent(
        name="embedder", embedding_client=client, batch_size=2, max_concurrent_batches=3
    )

    events: list[EmbeddingBatchProgressEvent] = []
    final: EmbeddingResult | None = None
    async for item in agent.run_stream(texts):
        if isinstance(item, EmbeddingBatchProgressEvent):
            events.append(item)
        elif isinstance(item, EmbeddingResult):
            final = item

    assert len(events) == 3
    assert {e.batch_index for e in events} == {0, 1, 2}
    assert all(e.total_batches == 3 for e in events)
    assert all(e.total_texts == 5 for e in events)
    assert final is not None
    assert len(final.embeddings) == 5


@pytest.mark.asyncio
async def test_run_concurrent_semaphore_bounds_in_flight():
    """Peak concurrent calls must not exceed max_concurrent_batches."""
    import asyncio as _asyncio

    max_concurrent = 2
    in_flight = {"count": 0, "peak": 0}

    async def slow_create_batch(texts_in: list[str]) -> EmbeddingResult:
        in_flight["count"] += 1
        in_flight["peak"] = max(in_flight["peak"], in_flight["count"])
        await _asyncio.sleep(0.01)
        result = _make_result([[float(j)] for j in range(len(texts_in))])
        in_flight["count"] -= 1
        return result

    client = MagicMock()
    client.model = "text-embedding-3-small"
    client.create_batch = slow_create_batch

    texts = [str(i) for i in range(20)]  # 10 batches at batch_size=2
    agent = EmbeddingAgent(
        name="test", embedding_client=client, batch_size=2, max_concurrent_batches=max_concurrent
    )
    result = await agent.run(texts)

    assert in_flight["peak"] <= max_concurrent
    assert len(result.embeddings) == 20
