from __future__ import annotations

from datetime import datetime
from unittest.mock import MagicMock

from agentbyte.agents.types import TaskStartEvent
from agentbyte.logger import StreamEventLogger
from agentbyte.types import (
    AgentExecutionCompleteEvent,
    AgentExecutionStartEvent,
    AgentSelectionEvent,
    OrchestrationCompleteEvent,
    OrchestrationStartEvent,
)
from agentbyte.workflow.core.models import (
    StepExecution,
    StepProgressEvent,
    StepStartedEvent,
    WorkflowCompletedEvent,
    WorkflowErrorDetails,
    WorkflowExecution,
    WorkflowFailedEvent,
    WorkflowStartedEvent,
)


def test_stream_event_logger_logs_agent_info_events() -> None:
    logger = MagicMock()
    stream_logger = StreamEventLogger(logger=logger)

    stream_logger.info(
        TaskStartEvent(
            source="assistant",
            task="hello",
        )
    )

    logger.info.assert_called_once()
    message, source, _, event_type = logger.info.call_args.args
    assert message == "[%s] %s | %s"
    assert source == "assistant"
    assert event_type == "task_start"


def test_stream_event_logger_logs_workflow_info_debug_and_error_events() -> None:
    logger = MagicMock()
    stream_logger = StreamEventLogger(logger=logger)
    execution = WorkflowExecution(
        workflow_id="workflow-12345678",
        start_time=datetime.now(),
        end_time=datetime.now(),
        step_executions={"draft": StepExecution(step_id="draft")},
    )

    stream_logger.info(
        WorkflowStartedEvent(
            workflow_id="workflow-12345678",
            timestamp=datetime.now(),
            initial_input={"value": 1},
        )
    )
    stream_logger.info(
        StepStartedEvent(
            workflow_id="workflow-12345678",
            timestamp=datetime.now(),
            step_id="draft",
            input_data={"value": 1},
        )
    )
    stream_logger.debug(
        StepProgressEvent(
            workflow_id="workflow-12345678",
            timestamp=datetime.now(),
            step_id="draft",
            message="working",
            completed=1,
            total=2,
        )
    )
    stream_logger.info(
        WorkflowCompletedEvent(
            workflow_id="workflow-12345678",
            timestamp=datetime.now(),
            execution=execution,
            final_output={"value": 2},
        )
    )
    stream_logger.error(
        WorkflowFailedEvent(
            workflow_id="workflow-12345678",
            timestamp=datetime.now(),
            error_details=WorkflowErrorDetails(
                error_type="RuntimeError",
                message="boom",
            ),
            execution=execution,
        )
    )

    assert logger.info.call_count == 3
    assert logger.debug.call_count == 1
    assert logger.error.call_count == 1

    info_calls = logger.info.call_args_list
    assert info_calls[0].args[1] == "framework:workflow"
    assert info_calls[0].args[3] == "workflow_started"
    assert info_calls[1].args[3] == "step_started"
    assert info_calls[1].args[4] == "draft"
    assert info_calls[2].args[3] == "workflow_completed"
    assert info_calls[2].args[4] == 1

    debug_call = logger.debug.call_args
    assert debug_call.args[1] == "step:workflow"
    assert debug_call.args[3] == "step_progress"
    assert debug_call.args[4] == "draft"
    assert debug_call.args[5] == "working"
    assert debug_call.args[6] == "  progress=1/2"

    error_call = logger.error.call_args
    assert error_call.args[1] == "framework:workflow"
    assert error_call.args[3] == "workflow_failed"
    assert error_call.args[4] == "boom"


def test_stream_event_logger_logs_orchestrator_events() -> None:
    logger = MagicMock()
    stream_logger = StreamEventLogger(logger=logger)

    stream_logger.info(
        OrchestrationStartEvent(
            source="orchestrator",
            timestamp=1715079600.0,
            task="research this",
            pattern="RoundRobinOrchestrator",
        )
    )
    stream_logger.debug(
        AgentSelectionEvent(
            source="orchestrator",
            timestamp=1715079601.0,
            selected_agent="planner",
            selection_reason="Iteration 1",
        )
    )
    stream_logger.debug(
        AgentExecutionStartEvent(
            source="orchestrator",
            timestamp=1715079602.0,
            executing_agent="planner",
            context_size=3,
        )
    )
    stream_logger.info(
        AgentExecutionCompleteEvent(
            source="orchestrator",
            timestamp=1715079603.0,
            executing_agent="planner",
            success=True,
            message_count=2,
        )
    )
    stream_logger.warning(
        AgentExecutionCompleteEvent(
            source="orchestrator",
            timestamp=1715079604.0,
            executing_agent="reviewer",
            success=False,
            message_count=0,
        )
    )
    stream_logger.info(
        OrchestrationCompleteEvent(
            source="orchestrator",
            timestamp=1715079605.0,
            result="done",
            stop_reason="Maximum iterations reached",
        )
    )

    assert logger.info.call_count == 3
    assert logger.debug.call_count == 2
    assert logger.warning.call_count == 1

    info_calls = logger.info.call_args_list
    assert info_calls[0].args[1] == "orchestrator"
    assert info_calls[0].args[3] == "orchestration_start"
    assert info_calls[0].args[4] == "RoundRobinOrchestrator"
    assert info_calls[1].args[3] == "agent_execution_complete"
    assert info_calls[1].args[4] == "planner"
    assert info_calls[1].args[5] == 2
    assert info_calls[2].args[3] == "orchestration_complete"
    assert info_calls[2].args[4] == "Maximum iterations reached"

    debug_calls = logger.debug.call_args_list
    assert debug_calls[0].args[3] == "agent_selection"
    assert debug_calls[0].args[4] == "planner"
    assert debug_calls[0].args[5] == "Iteration 1"
    assert debug_calls[1].args[3] == "agent_execution_start"
    assert debug_calls[1].args[4] == "planner"
    assert debug_calls[1].args[5] == 3

    warning_call = logger.warning.call_args
    assert warning_call.args[3] == "agent_execution_complete"
    assert warning_call.args[4] == "reviewer"
    assert warning_call.args[5] == 0