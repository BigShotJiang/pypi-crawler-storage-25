from __future__ import annotations

import unittest

from hermit_proxy.config import ProviderConfig
from hermit_proxy.policy import ProviderPolicy


class ChatPayloadPolicyTests(unittest.TestCase):
    def test_deepseek_maps_singular_max_token_to_max_tokens(self) -> None:
        provider = ProviderConfig(
            name="deepseek",
            base_url="https://api.deepseek.com/v1",
            api_key="",
            model="deepseek-reasoner",
        )
        payload = {
            "model": "client-model",
            "messages": [{"role": "user", "content": "hello"}],
            "max_token": 128,
        }

        prepared = ProviderPolicy.prepare_chat_payload(provider, payload)

        self.assertEqual(prepared["model"], "deepseek-reasoner")
        self.assertEqual(prepared["max_tokens"], 128)
        self.assertNotIn("max_token", prepared)
        self.assertNotIn("max_completion_tokens", prepared)

    def test_profile_default_max_tokens_is_used_when_client_omits_limit(self) -> None:
        provider = ProviderConfig(
            name="ollama",
            base_url="http://localhost:11434/v1",
            api_key="",
            model="deepseek-r1:32b",
            default_max_tokens=2048,
        )
        payload = {
            "model": "client-model",
            "messages": [{"role": "user", "content": "hello"}],
        }

        prepared = ProviderPolicy.prepare_chat_payload(provider, payload)

        self.assertEqual(prepared["model"], "deepseek-r1:32b")
        self.assertEqual(prepared["max_tokens"], 2048)

    def test_client_token_limit_overrides_profile_default_max_tokens(self) -> None:
        provider = ProviderConfig(
            name="ollama",
            base_url="http://localhost:11434/v1",
            api_key="",
            model="deepseek-r1:32b",
            default_max_tokens=2048,
        )
        payload = {
            "messages": [{"role": "user", "content": "hello"}],
            "max_tokens": 512,
        }

        prepared = ProviderPolicy.prepare_chat_payload(provider, payload)

        self.assertEqual(prepared["max_tokens"], 512)

    def test_openai_uses_max_completion_tokens(self) -> None:
        provider = ProviderConfig(
            name="openai",
            base_url="https://api.openai.com/v1",
            api_key="",
            model="gpt-4o-mini",
        )
        payload = {
            "messages": [{"role": "user", "content": "hello"}],
            "max_tokens": 128,
        }

        prepared = ProviderPolicy.prepare_chat_payload(provider, payload)

        self.assertEqual(prepared["model"], "gpt-4o-mini")
        self.assertEqual(prepared["max_completion_tokens"], 128)
        self.assertNotIn("max_tokens", prepared)
        self.assertNotIn("max_token", prepared)

    def test_openrouter_uses_max_tokens_for_model_parameter_coverage(self) -> None:
        provider = ProviderConfig(
            name="openrouter",
            base_url="https://openrouter.ai/api/v1",
            api_key="",
            model="openai/gpt-5-mini",
        )
        payload = {
            "messages": [{"role": "user", "content": "hello"}],
            "max_completion_tokens": 128,
        }

        prepared = ProviderPolicy.prepare_chat_payload(provider, payload)

        self.assertEqual(prepared["model"], "openai/gpt-5-mini")
        self.assertEqual(prepared["max_tokens"], 128)
        self.assertNotIn("max_completion_tokens", prepared)
        self.assertNotIn("max_token", prepared)

    def test_unknown_provider_preserves_official_openai_token_field(self) -> None:
        provider = ProviderConfig(
            name="openai-compatible",
            base_url="https://example.test/v1",
            api_key="",
            model="local-model",
            allow_client_model_override=True,
        )
        payload = {
            "model": "client-model",
            "messages": [{"role": "user", "content": "hello"}],
            "max_completion_tokens": 128,
        }

        prepared = ProviderPolicy.prepare_chat_payload(provider, payload)

        self.assertEqual(prepared["model"], "client-model")
        self.assertEqual(prepared["max_completion_tokens"], 128)
        self.assertNotIn("max_tokens", prepared)
        self.assertNotIn("max_token", prepared)

    def test_unknown_provider_maps_singular_max_token_to_max_tokens(self) -> None:
        provider = ProviderConfig(
            name="openai-compatible",
            base_url="https://example.test/v1",
            api_key="",
            model="local-model",
        )
        payload = {
            "messages": [{"role": "user", "content": "hello"}],
            "max_token": 128,
        }

        prepared = ProviderPolicy.prepare_chat_payload(provider, payload)

        self.assertEqual(prepared["max_tokens"], 128)
        self.assertNotIn("max_token", prepared)


if __name__ == "__main__":
    unittest.main()
