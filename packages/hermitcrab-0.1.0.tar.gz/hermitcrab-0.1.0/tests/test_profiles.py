from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from hermit_proxy.config import Settings
from hermit_proxy.profiles import ProfileManager
from hermit_proxy.storage import TrafficStore


class ClientModelRoutingTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmpdir = tempfile.TemporaryDirectory()
        db_path = Path(self.tmpdir.name) / "hermit.db"
        self.settings = Settings(database_url=f"sqlite:///{db_path}")
        self.store = TrafficStore(self.settings.database_url)
        self.manager = ProfileManager(self.settings, self.store)
        self.openai_profile_id = self.manager.save_profile(
            name="openai-default",
            provider="openai",
            base_url="https://api.openai.com/v1",
            api_key="openai-key",
            auth_profile_id=None,
            model="gpt-4o-mini",
            allow_client_model_override=False,
            activate=True,
        )
        self.openrouter_profile_id = self.manager.save_profile(
            name="openrouter-nano",
            provider="openrouter",
            base_url="https://openrouter.ai/api/v1",
            api_key="openrouter-key",
            auth_profile_id=None,
            model="nvidia/nemotron-3-nano-30b-a3b:free",
            allow_client_model_override=False,
        )

    def tearDown(self) -> None:
        self.tmpdir.cleanup()

    def test_provider_prefix_routes_to_saved_provider_profile(self) -> None:
        provider = self.manager.provider_config_for_client_model(
            "openrouter/nvidia/nemotron-3-nano-30b-a3b:free"
        )

        self.assertEqual(provider.name, "openrouter")
        self.assertEqual(provider.profile_id, self.openrouter_profile_id)
        self.assertEqual(provider.model, "nvidia/nemotron-3-nano-30b-a3b:free")
        self.assertEqual(provider.api_key, "openrouter-key")
        self.assertFalse(provider.allow_client_model_override)

    def test_provider_prefix_can_reuse_provider_credentials_for_new_model(self) -> None:
        provider = self.manager.provider_config_for_client_model(
            "openrouter/nvidia/nemotron-3-super-120b-a12b:free"
        )

        self.assertEqual(provider.name, "openrouter")
        self.assertEqual(provider.profile_id, self.openrouter_profile_id)
        self.assertEqual(provider.model, "nvidia/nemotron-3-super-120b-a12b:free")
        self.assertEqual(provider.api_key, "openrouter-key")

    def test_unknown_provider_prefix_falls_back_to_active_profile(self) -> None:
        provider = self.manager.provider_config_for_client_model("unknown/foo")

        self.assertEqual(provider.name, "openai")
        self.assertEqual(provider.profile_id, self.openai_profile_id)
        self.assertEqual(provider.model, "gpt-4o-mini")


if __name__ == "__main__":
    unittest.main()
