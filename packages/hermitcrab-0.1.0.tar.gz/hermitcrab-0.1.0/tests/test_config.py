from __future__ import annotations

import unittest

from hermit_proxy.config import Settings


class BootstrapProviderConfigTests(unittest.TestCase):
    def setUp(self) -> None:
        self.settings = Settings()

    def test_xiaomi_provider_defaults(self) -> None:
        config = self.settings.bootstrap_provider_config("xiaomi")
        self.assertEqual(config.name, "xiaomi")
        self.assertEqual(config.base_url, "https://api.xiaomimimo.com/v1")

    def test_mimo_alias_resolves_to_xiaomi(self) -> None:
        config = self.settings.bootstrap_provider_config("mimo")
        self.assertEqual(config.name, "xiaomi")
        self.assertEqual(config.base_url, "https://api.xiaomimimo.com/v1")

    def test_bedrock_alias_resolves_to_amazon_bedrock(self) -> None:
        config = self.settings.bootstrap_provider_config("bedrock")
        self.assertEqual(config.name, "amazon-bedrock")
        self.assertEqual(config.base_url, "https://bedrock-mantle.us-east-1.api.aws/v1")

    def test_hugging_face_alias_resolves_to_huggingface(self) -> None:
        config = self.settings.bootstrap_provider_config("hugging-face")
        self.assertEqual(config.name, "huggingface")
        self.assertEqual(config.base_url, "https://router.huggingface.co/v1")


if __name__ == "__main__":
    unittest.main()
