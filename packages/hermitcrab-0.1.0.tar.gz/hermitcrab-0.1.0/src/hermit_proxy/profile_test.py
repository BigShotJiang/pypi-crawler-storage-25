from __future__ import annotations

from datetime import UTC, datetime

from hermit_proxy.auth import AuthManager
from hermit_proxy.config import ProviderConfig, Settings
from hermit_proxy.models import ProfileTestResult
from hermit_proxy.storage import TrafficStore
from hermit_proxy.upstream import UpstreamClient


class ProfileTester:
    def __init__(self, settings: Settings, store: TrafficStore, upstream: UpstreamClient) -> None:
        self.settings = settings
        self.auth = AuthManager(settings, store)
        self.upstream = upstream

    async def quick_test(self, provider: ProviderConfig) -> ProfileTestResult:
        provider = self.auth.resolve_provider(provider)
        started_at = datetime.now(UTC)
        payload = {
            "model": provider.model,
            "messages": [{"role": "user", "content": "Reply with OK."}],
            "max_tokens": 8,
            "temperature": 0,
            "stream": False,
        }
        try:
            status_code, response_body = await self.upstream.chat_completions(provider, payload)
            latency_ms = int((datetime.now(UTC) - started_at).total_seconds() * 1000)
            if 200 <= status_code < 300:
                return ProfileTestResult(
                    ok=True,
                    status_code=status_code,
                    latency_ms=latency_ms,
                    provider=provider.name,
                    model=provider.model,
                    message="Quick test succeeded",
                    response_excerpt=extract_excerpt(response_body),
                )
            return ProfileTestResult(
                ok=False,
                status_code=status_code,
                latency_ms=latency_ms,
                provider=provider.name,
                model=provider.model,
                message="Quick test failed",
                response_excerpt=extract_excerpt(response_body),
            )
        except Exception as exc:
            latency_ms = int((datetime.now(UTC) - started_at).total_seconds() * 1000)
            return ProfileTestResult(
                ok=False,
                status_code=None,
                latency_ms=latency_ms,
                provider=provider.name,
                model=provider.model,
                message=f"Quick test failed: {exc}",
                response_excerpt=None,
            )


def extract_excerpt(response_body: dict) -> str | None:
    if not isinstance(response_body, dict):
        return None
    choices = response_body.get("choices")
    if isinstance(choices, list) and choices:
        message = choices[0].get("message", {})
        content = message.get("content")
        if isinstance(content, str):
            return content[:200]
    error = response_body.get("error")
    if isinstance(error, dict):
        error_message = error.get("message")
        if isinstance(error_message, str):
            return error_message[:200]
    return str(response_body)[:200]
