from __future__ import annotations

from datetime import UTC, datetime
import logging
from uuid import uuid4

from fastapi import HTTPException
from fastapi.responses import StreamingResponse

from hermit_proxy.auth import AuthManager
from hermit_proxy.config import Settings
from hermit_proxy.models import ChatCompletionRequest, EmbeddingsRequest, ProxyRequestRecord
from hermit_proxy.policy import ProviderPolicy
from hermit_proxy.profiles import ProfileManager
from hermit_proxy.storage import TrafficStore
from hermit_proxy.upstream import UpstreamClient

logger = logging.getLogger("hermit_proxy.service")


class ProxyService:
    def __init__(self, settings: Settings, store: TrafficStore, upstream: UpstreamClient) -> None:
        self.settings = settings
        self.store = store
        self.upstream = upstream
        self.profiles = ProfileManager(settings, store)
        self.auth = AuthManager(settings, store)

    async def create_chat_completion(self, request: ChatCompletionRequest) -> dict | StreamingResponse:
        provider = self.auth.resolve_provider(self.profiles.provider_config_for_client_model(request.model))
        request_id = str(uuid4())
        received_at = datetime.now(UTC)

        upstream_payload = request.model_dump(exclude_none=True)
        upstream_payload = ProviderPolicy.prepare_chat_payload(provider, upstream_payload)
        if request.stream and "stream_options" not in upstream_payload:
            upstream_payload["stream_options"] = {"include_usage": True}

        record = ProxyRequestRecord(
            request_id=request_id,
            received_at=normalize_timestamp(received_at),
            provider=provider.name,
            upstream_model=upstream_payload["model"],
            client_model=request.model,
            request_body=upstream_payload,
        )
        self.store.upsert_request(record.model_dump(mode="json"))
        logger.info(
            "chat request started request_id=%s provider=%s upstream_model=%s client_model=%s stream=%s",
            request_id,
            provider.name,
            upstream_payload["model"],
            request.model,
            bool(request.stream),
        )

        if request.stream:
            return await self._create_streaming_chat_completion(provider, upstream_payload, record, received_at)

        try:
            status_code, response_body = await self.upstream.chat_completions(provider, upstream_payload)
            completed_at = datetime.now(UTC)
            usage = response_body.get("usage", {})
            record.completed_at = normalize_timestamp(completed_at)
            record.status_code = status_code
            record.success = 200 <= status_code < 300
            record.latency_ms = int((completed_at - received_at).total_seconds() * 1000)
            record.prompt_tokens = int(usage.get("prompt_tokens", 0) or 0)
            record.completion_tokens = int(usage.get("completion_tokens", 0) or 0)
            record.total_tokens = int(
                usage.get("total_tokens", record.prompt_tokens + record.completion_tokens) or 0
            )
            record.response_body = response_body
            if not record.success:
                record.error_message = str(response_body)
            self.store.upsert_request(record.model_dump(mode="json"))
            if record.success:
                logger.info(
                    "chat request completed request_id=%s status=%s latency_ms=%s prompt_tokens=%s completion_tokens=%s total_tokens=%s",
                    request_id,
                    status_code,
                    record.latency_ms,
                    record.prompt_tokens,
                    record.completion_tokens,
                    record.total_tokens,
                )
            else:
                logger.warning(
                    "chat request failed request_id=%s status=%s latency_ms=%s detail=%s",
                    request_id,
                    status_code,
                    record.latency_ms,
                    record.error_message,
                )

            if not record.success:
                raise HTTPException(status_code=status_code, detail=response_body)

            return response_body
        except HTTPException:
            raise
        except Exception as exc:
            completed_at = datetime.now(UTC)
            record.completed_at = normalize_timestamp(completed_at)
            record.status_code = 502
            record.success = False
            record.latency_ms = int((completed_at - received_at).total_seconds() * 1000)
            record.error_message = str(exc)
            self.store.upsert_request(record.model_dump(mode="json"))
            logger.exception(
                "chat request upstream exception request_id=%s provider=%s upstream_model=%s",
                request_id,
                provider.name,
                upstream_payload["model"],
            )
            raise HTTPException(status_code=502, detail="Upstream provider request failed") from exc

    async def create_embeddings(self, request: EmbeddingsRequest) -> dict:
        provider = self.auth.resolve_provider(self.profiles.provider_config_for_client_model(request.model))
        request_id = str(uuid4())
        received_at = datetime.now(UTC)
        upstream_payload = request.model_dump(exclude_none=True)
        upstream_payload["model"] = ProviderPolicy.resolve_model(provider, request.model)
        record = ProxyRequestRecord(
            request_id=request_id,
            received_at=normalize_timestamp(received_at),
            provider=provider.name,
            upstream_model=upstream_payload["model"],
            client_model=request.model,
            request_body=upstream_payload,
        )
        self.store.upsert_request(record.model_dump(mode="json"))
        logger.info(
            "embeddings request started request_id=%s provider=%s upstream_model=%s client_model=%s",
            request_id,
            provider.name,
            upstream_payload["model"],
            request.model,
        )
        try:
            status_code, response_body = await self.upstream.embeddings(provider, upstream_payload)
        except Exception as exc:
            completed_at = datetime.now(UTC)
            record.completed_at = normalize_timestamp(completed_at)
            record.status_code = 502
            record.success = False
            record.latency_ms = int((completed_at - received_at).total_seconds() * 1000)
            record.error_message = str(exc)
            self.store.upsert_request(record.model_dump(mode="json"))
            logger.exception(
                "embeddings request upstream exception request_id=%s provider=%s upstream_model=%s",
                request_id,
                provider.name,
                upstream_payload["model"],
            )
            raise HTTPException(status_code=502, detail="Upstream provider request failed") from exc

        completed_at = datetime.now(UTC)
        usage = response_body.get("usage", {})
        record.completed_at = normalize_timestamp(completed_at)
        record.status_code = status_code
        record.success = 200 <= status_code < 300
        record.latency_ms = int((completed_at - received_at).total_seconds() * 1000)
        record.prompt_tokens = int(usage.get("prompt_tokens", 0) or 0)
        record.completion_tokens = int(usage.get("completion_tokens", 0) or 0)
        record.total_tokens = int(
            usage.get("total_tokens", record.prompt_tokens + record.completion_tokens) or 0
        )
        record.response_body = response_body
        if not record.success:
            record.error_message = str(response_body)
        self.store.upsert_request(record.model_dump(mode="json"))

        if not 200 <= status_code < 300:
            logger.warning(
                "embeddings request failed request_id=%s status=%s latency_ms=%s detail=%s",
                request_id,
                status_code,
                record.latency_ms,
                record.error_message,
            )
            raise HTTPException(status_code=status_code, detail=response_body)
        logger.info(
            "embeddings request completed request_id=%s status=%s latency_ms=%s prompt_tokens=%s completion_tokens=%s total_tokens=%s",
            request_id,
            status_code,
            record.latency_ms,
            record.prompt_tokens,
            record.completion_tokens,
            record.total_tokens,
        )
        return response_body

    async def list_models(self) -> dict:
        provider = self.auth.resolve_provider(self.profiles.active_provider_config())
        logger.debug(
            "models request started provider=%s allow_client_model_override=%s",
            provider.name,
            provider.allow_client_model_override,
        )
        status_code, response_body = await self.upstream.models(provider)
        if 200 <= status_code < 300:
            if provider.allow_client_model_override:
                logger.debug("models request completed provider=%s source=upstream", provider.name)
                return response_body
            logger.debug("models request completed provider=%s source=proxy-profile", provider.name)
            return {
                "object": "list",
                "data": [
                    {
                        "id": provider.model,
                        "object": "model",
                        "owned_by": provider.name,
                    }
                ],
            }
        if provider.allow_client_model_override:
            logger.warning("models request failed provider=%s status=%s", provider.name, status_code)
            raise HTTPException(status_code=status_code, detail=response_body)
        logger.warning(
            "models request upstream failed provider=%s status=%s falling back to active profile",
            provider.name,
            status_code,
        )
        return {
            "object": "list",
            "data": [
                {
                    "id": provider.model,
                    "object": "model",
                    "owned_by": provider.name,
                }
            ],
        }

    async def _create_streaming_chat_completion(
        self,
        provider,
        upstream_payload: dict,
        record: ProxyRequestRecord,
        received_at: datetime,
    ) -> StreamingResponse:
        try:
            status_code, iterator, headers = await self.upstream.stream_chat_completions(provider, upstream_payload)
        except Exception as exc:
            completed_at = datetime.now(UTC)
            record.completed_at = normalize_timestamp(completed_at)
            record.status_code = 502
            record.success = False
            record.latency_ms = int((completed_at - received_at).total_seconds() * 1000)
            record.error_message = str(exc)
            self.store.upsert_request(record.model_dump(mode="json"))
            logger.exception(
                "streaming chat request upstream exception request_id=%s provider=%s upstream_model=%s",
                record.request_id,
                provider.name,
                upstream_payload["model"],
            )
            raise HTTPException(status_code=502, detail="Upstream provider request failed") from exc

        if not 200 <= status_code < 300:
            chunks = [chunk async for chunk in iterator]
            completed_at = datetime.now(UTC)
            record.completed_at = normalize_timestamp(completed_at)
            record.status_code = status_code
            record.success = False
            record.latency_ms = int((completed_at - received_at).total_seconds() * 1000)
            record.error_message = b"".join(chunks).decode("utf-8", errors="ignore")
            self.store.upsert_request(record.model_dump(mode="json"))
            logger.warning(
                "streaming chat request failed request_id=%s status=%s latency_ms=%s detail=%s",
                record.request_id,
                status_code,
                record.latency_ms,
                record.error_message,
            )
            raise HTTPException(status_code=status_code, detail=record.error_message)

        captured: list[bytes] = []

        async def stream_wrapper():
            try:
                async for chunk in iterator:
                    captured.append(chunk)
                    yield chunk
            finally:
                completed_at = datetime.now(UTC)
                usage = self.upstream.parse_sse_usage(captured)
                record.completed_at = normalize_timestamp(completed_at)
                record.status_code = status_code
                record.success = True
                record.latency_ms = int((completed_at - received_at).total_seconds() * 1000)
                record.prompt_tokens = int(usage.get("prompt_tokens", 0) or 0)
                record.completion_tokens = int(usage.get("completion_tokens", 0) or 0)
                record.total_tokens = int(
                    usage.get("total_tokens", record.prompt_tokens + record.completion_tokens) or 0
                )
                self.store.upsert_request(record.model_dump(mode="json"))
                logger.info(
                    "streaming chat request completed request_id=%s status=%s latency_ms=%s prompt_tokens=%s completion_tokens=%s total_tokens=%s",
                    record.request_id,
                    status_code,
                    record.latency_ms,
                    record.prompt_tokens,
                    record.completion_tokens,
                    record.total_tokens,
                )

        media_type = headers.get("content-type", "text/event-stream")
        return StreamingResponse(stream_wrapper(), media_type=media_type)


def normalize_timestamp(value: datetime) -> datetime:
    return value.astimezone(UTC).replace(microsecond=0)
