from __future__ import annotations

from datetime import datetime
from functools import lru_cache

from fastapi import Depends, FastAPI, HTTPException, Query

from hermit_proxy.auth import AuthManager
from hermit_proxy.config import Settings, get_settings
from hermit_proxy.models import (
    AuthProfileInput,
    ChatCompletionRequest,
    EmbeddingsRequest,
    GitHubDeviceCompleteInput,
    GitHubDeviceStartInput,
    ModelProfileInput,
)
from hermit_proxy.profile_test import ProfileTester
from hermit_proxy.profiles import ProfileManager
from hermit_proxy.service import ProxyService
from hermit_proxy.storage import TrafficStore
from hermit_proxy.upstream import UpstreamClient

app = FastAPI(title="Hermit LLM Proxy", version="0.1.0")


@lru_cache(maxsize=1)
def get_store() -> TrafficStore:
    settings = get_settings()
    return TrafficStore(settings.database_url)


@lru_cache(maxsize=1)
def get_upstream() -> UpstreamClient:
    settings = get_settings()
    return UpstreamClient(settings.request_timeout_seconds)


def get_service(
    settings: Settings = Depends(get_settings),
    store: TrafficStore = Depends(get_store),
    upstream: UpstreamClient = Depends(get_upstream),
) -> ProxyService:
    return ProxyService(settings, store, upstream)


def get_profile_manager(
    settings: Settings = Depends(get_settings),
    store: TrafficStore = Depends(get_store),
) -> ProfileManager:
    return ProfileManager(settings, store)


def get_profile_tester(
    settings: Settings = Depends(get_settings),
    store: TrafficStore = Depends(get_store),
    upstream: UpstreamClient = Depends(get_upstream),
) -> ProfileTester:
    return ProfileTester(settings, store, upstream)


def get_auth_manager(
    settings: Settings = Depends(get_settings),
    store: TrafficStore = Depends(get_store),
) -> AuthManager:
    return AuthManager(settings, store)


@app.get("/health")
async def health(manager: ProfileManager = Depends(get_profile_manager)) -> dict:
    provider = manager.active_provider_config()
    store = get_store()
    return {
        "status": "ok",
        "default_provider": provider.name,
        "default_model": provider.model,
        "allow_client_model_override": provider.allow_client_model_override,
        "active_profile_id": provider.profile_id,
        "active_profile_name": provider.profile_name,
        "log_level": store.get_app_state("log_level") or "INFO",
    }


@app.post("/v1/chat/completions")
async def create_chat_completion(
    request: ChatCompletionRequest,
    service: ProxyService = Depends(get_service),
) -> dict:
    return await service.create_chat_completion(request)


@app.post("/v1/embeddings")
async def create_embeddings(
    request: EmbeddingsRequest,
    service: ProxyService = Depends(get_service),
) -> dict:
    return await service.create_embeddings(request)


@app.get("/v1/models")
async def list_models(service: ProxyService = Depends(get_service)) -> dict:
    return await service.list_models()


@app.get("/analytics/summary")
async def analytics_summary(store: TrafficStore = Depends(get_store)) -> dict:
    return store.summary()


@app.get("/analytics/by-model")
async def analytics_by_model(store: TrafficStore = Depends(get_store)) -> dict:
    return {"items": store.summary_by_profile()}


@app.get("/analytics/requests")
async def analytics_requests(
    limit: int = Query(default=100, ge=1, le=1000),
    store: TrafficStore = Depends(get_store),
) -> dict:
    return {"items": store.recent_requests(limit)}


@app.get("/analytics/timeseries")
async def analytics_timeseries(
    bucket: str = Query(default="hour"),
    since: datetime | None = Query(default=None),
    store: TrafficStore = Depends(get_store),
) -> dict:
    since_value = since.isoformat() if since else None
    return {"items": store.timeseries(bucket=bucket, since=since_value)}


@app.get("/profiles")
async def list_profiles(
    store: TrafficStore = Depends(get_store),
    manager: ProfileManager = Depends(get_profile_manager),
) -> dict:
    manager.ensure_bootstrap_profile()
    return {
        "active_profile_id": store.get_app_state("active_profile_id"),
        "items": store.list_profiles(),
    }


@app.post("/profiles")
async def create_profile(
    payload: ModelProfileInput,
    manager: ProfileManager = Depends(get_profile_manager),
    store: TrafficStore = Depends(get_store),
    tester: ProfileTester = Depends(get_profile_tester),
) -> dict:
    profile_data = payload.model_dump()
    skip_test = bool(profile_data.pop("skip_test", False))
    provider_config = manager.provider_config_from_values(**profile_data)
    test_result = None if skip_test else await tester.quick_test(provider_config)
    if test_result and not test_result.ok:
        raise HTTPException(status_code=400, detail=test_result.model_dump())
    profile_id = manager.save_profile(**profile_data)
    return {
        "active_profile_id": store.get_app_state("active_profile_id"),
        "item": store.get_profile(profile_id),
        "test_result": None if skip_test else test_result.model_dump(),
    }


@app.put("/profiles/{profile_id}")
async def update_profile(
    profile_id: int,
    payload: ModelProfileInput,
    manager: ProfileManager = Depends(get_profile_manager),
    store: TrafficStore = Depends(get_store),
    tester: ProfileTester = Depends(get_profile_tester),
) -> dict:
    if not store.get_profile(profile_id):
        raise HTTPException(status_code=404, detail="Profile not found")
    profile_data = payload.model_dump()
    skip_test = bool(profile_data.pop("skip_test", False))
    provider_config = manager.provider_config_from_values(**profile_data)
    test_result = None if skip_test else await tester.quick_test(provider_config)
    if test_result and not test_result.ok:
        raise HTTPException(status_code=400, detail=test_result.model_dump())
    manager.save_profile(profile_id=profile_id, **profile_data)
    return {
        "active_profile_id": store.get_app_state("active_profile_id"),
        "item": store.get_profile(profile_id),
        "test_result": None if skip_test else test_result.model_dump(),
    }


@app.post("/profiles/test")
async def test_profile(
    payload: ModelProfileInput,
    manager: ProfileManager = Depends(get_profile_manager),
    tester: ProfileTester = Depends(get_profile_tester),
) -> dict:
    profile_data = payload.model_dump()
    profile_data.pop("skip_test", None)
    provider_config = manager.provider_config_from_values(**profile_data)
    result = await tester.quick_test(provider_config)
    return result.model_dump()


@app.post("/profiles/{profile_id}/activate")
async def activate_profile(
    profile_id: int,
    store: TrafficStore = Depends(get_store),
    manager: ProfileManager = Depends(get_profile_manager),
    tester: ProfileTester = Depends(get_profile_tester),
) -> dict:
    profile = store.get_profile(profile_id)
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    provider_config = manager.provider_config_from_values(
        name=str(profile["name"]),
        provider=str(profile["provider"]),
        base_url=str(profile["base_url"]),
        api_key=str(profile["api_key"]),
        auth_profile_id=profile.get("auth_profile_id"),
        model=str(profile["model"]),
        allow_client_model_override=bool(profile.get("allow_client_model_override")),
        default_max_tokens=profile.get("default_max_tokens"),
    )
    test_result = await tester.quick_test(provider_config)
    if not test_result.ok:
        raise HTTPException(status_code=400, detail=test_result.model_dump())
    store.set_active_profile(profile_id)
    return {
        "active_profile_id": store.get_app_state("active_profile_id"),
        "item": profile,
        "test_result": test_result.model_dump(),
    }


@app.delete("/profiles/{profile_id}")
async def delete_profile(profile_id: int, store: TrafficStore = Depends(get_store)) -> dict:
    if not store.get_profile(profile_id):
        raise HTTPException(status_code=404, detail="Profile not found")
    store.delete_profile(profile_id)
    return {
        "active_profile_id": store.get_app_state("active_profile_id"),
        "deleted_profile_id": profile_id,
    }


@app.get("/auth-profiles")
async def list_auth_profiles(store: TrafficStore = Depends(get_store)) -> dict:
    return {"items": store.list_auth_profiles()}


@app.post("/auth-profiles")
async def create_auth_profile(
    payload: AuthProfileInput,
    auth: AuthManager = Depends(get_auth_manager),
    store: TrafficStore = Depends(get_store),
) -> dict:
    if payload.provider != "github-copilot":
        raise HTTPException(status_code=400, detail="Only github-copilot auth profiles are implemented")
    auth_profile_id = auth.save_github_copilot_auth_profile(
        name=payload.name,
        github_token=payload.github_token,
        github_domain=payload.github_domain,
    )
    return {"item": store.get_auth_profile(auth_profile_id)}


@app.post("/auth-profiles/github-copilot/device/start")
async def start_github_copilot_device_flow(
    payload: GitHubDeviceStartInput,
    auth: AuthManager = Depends(get_auth_manager),
) -> dict:
    flow = auth.start_github_device_flow(
        client_id=payload.client_id,
        github_domain=payload.github_domain,
    )
    return {
        "device_code": flow.device_code,
        "user_code": flow.user_code,
        "verification_uri": flow.verification_uri,
        "expires_in": flow.expires_in,
        "interval": flow.interval,
    }


@app.post("/auth-profiles/github-copilot/device/complete")
async def complete_github_copilot_device_flow(
    payload: GitHubDeviceCompleteInput,
    auth: AuthManager = Depends(get_auth_manager),
    store: TrafficStore = Depends(get_store),
) -> dict:
    github_token = auth.complete_github_device_flow(
        client_id=payload.client_id,
        device_code=payload.device_code,
        github_domain=payload.github_domain,
        interval=payload.interval,
        expires_in=payload.expires_in,
    )
    auth_profile_id = auth.save_github_copilot_auth_profile(
        name=payload.name,
        github_token=github_token,
        github_domain=payload.github_domain,
    )
    return {"item": store.get_auth_profile(auth_profile_id)}
