from __future__ import annotations

import getpass
import os
import pathlib
import shutil
import subprocess
import sys

SERVICE_NAME = "hermitcrab"
_SYSTEM_SERVICE_DIR = pathlib.Path("/etc/systemd/system")


def _hermitcrab_exe() -> str:
    exe = shutil.which("hermitcrab")
    if exe:
        return str(pathlib.Path(exe).resolve())
    return str(pathlib.Path(sys.argv[0]).resolve())


def _working_dir() -> str:
    db_url = os.environ.get("HERMIT_DATABASE_URL", "")
    if db_url.startswith("sqlite:///") and not db_url.startswith("sqlite:///./"):
        db_path = pathlib.Path(db_url.removeprefix("sqlite:///"))
        return str(db_path.parent.resolve())
    # Default: ~/.hermitcrab/
    default_dir = pathlib.Path.home() / ".hermitcrab"
    default_dir.mkdir(parents=True, exist_ok=True)
    return str(default_dir)


def _user_service_path() -> pathlib.Path:
    return pathlib.Path.home() / ".config" / "systemd" / "user" / f"{SERVICE_NAME}.service"


def _system_service_path() -> pathlib.Path:
    return _SYSTEM_SERVICE_DIR / f"{SERVICE_NAME}.service"


def generate_service_unit(*, user_service: bool) -> str:
    exe = _hermitcrab_exe()
    wd = _working_dir()
    if user_service:
        return (
            "[Unit]\n"
            "Description=hermitcrab LLM billing server\n"
            "After=network-online.target\n"
            "Wants=network-online.target\n"
            "\n"
            "[Service]\n"
            "Type=simple\n"
            f"WorkingDirectory={wd}\n"
            f"ExecStart={exe} serve\n"
            "Restart=always\n"
            "RestartSec=5\n"
            "\n"
            "[Install]\n"
            "WantedBy=default.target\n"
        )
    user = getpass.getuser()
    return (
        "[Unit]\n"
        "Description=hermitcrab LLM billing server\n"
        "After=network-online.target\n"
        "Wants=network-online.target\n"
        "\n"
        "[Service]\n"
        "Type=simple\n"
        f"User={user}\n"
        f"Group={user}\n"
        f"WorkingDirectory={wd}\n"
        f"ExecStart={exe} serve\n"
        "Restart=always\n"
        "RestartSec=5\n"
        "\n"
        "[Install]\n"
        "WantedBy=multi-user.target\n"
    )


def _systemctl(*args: str, user_service: bool) -> subprocess.CompletedProcess[str]:
    cmd = ["systemctl"]
    if user_service:
        cmd.append("--user")
    cmd.extend(args)
    return subprocess.run(cmd, capture_output=True, text=True)


def _systemd_available() -> bool:
    r = subprocess.run(["systemctl", "--version"], capture_output=True, text=True)
    return r.returncode == 0


def install(*, user_service: bool, enable: bool = True) -> tuple[bool, str]:
    if not _systemd_available():
        return False, "systemd is not available on this system"

    content = generate_service_unit(user_service=user_service)

    if user_service:
        path = _user_service_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content)
    else:
        path = _system_service_path()
        result = subprocess.run(
            ["sudo", "tee", str(path)],
            input=content,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            return False, f"Failed to write service file (sudo tee): {result.stderr.strip()}"

    r = _systemctl("daemon-reload", user_service=user_service)
    if r.returncode != 0:
        return False, f"daemon-reload failed: {r.stderr.strip()}"

    if enable:
        r = _systemctl("enable", "--now", SERVICE_NAME, user_service=user_service)
        if r.returncode != 0:
            return False, f"enable --now failed: {r.stderr.strip()}"

    scope = "user" if user_service else "system"
    return True, f"Installed and started {scope} service  [{path}]"


def uninstall(*, user_service: bool) -> tuple[bool, str]:
    if not _systemd_available():
        return False, "systemd is not available on this system"

    _systemctl("stop", SERVICE_NAME, user_service=user_service)
    _systemctl("disable", SERVICE_NAME, user_service=user_service)

    path = _user_service_path() if user_service else _system_service_path()
    if not path.exists():
        return False, f"Service file not found: {path}"

    if user_service:
        path.unlink()
    else:
        result = subprocess.run(["sudo", "rm", str(path)], capture_output=True, text=True)
        if result.returncode != 0:
            return False, f"Failed to remove service file (sudo rm): {result.stderr.strip()}"

    _systemctl("daemon-reload", user_service=user_service)
    return True, f"Uninstalled {'user' if user_service else 'system'} service"


def start(*, user_service: bool) -> tuple[bool, str]:
    if not _systemd_available():
        return False, "systemd is not available on this system"
    r = _systemctl("start", SERVICE_NAME, user_service=user_service)
    if r.returncode != 0:
        return False, r.stderr.strip() or "start failed"
    return True, "Service started"


def stop(*, user_service: bool) -> tuple[bool, str]:
    if not _systemd_available():
        return False, "systemd is not available on this system"
    r = _systemctl("stop", SERVICE_NAME, user_service=user_service)
    if r.returncode != 0:
        return False, r.stderr.strip() or "stop failed"
    return True, "Service stopped"


def restart(*, user_service: bool) -> tuple[bool, str]:
    if not _systemd_available():
        return False, "systemd is not available on this system"
    r = _systemctl("restart", SERVICE_NAME, user_service=user_service)
    if r.returncode != 0:
        return False, r.stderr.strip() or "restart failed"
    return True, "Service restarted"


def service_state(*, user_service: bool) -> str:
    """Return the active-state string: active, inactive, failed, not-installed, unavailable."""
    if not _systemd_available():
        return "unavailable"
    path = _user_service_path() if user_service else _system_service_path()
    if not path.exists():
        # Also check the other scope before giving up
        other = _system_service_path() if user_service else _user_service_path()
        if not other.exists():
            return "not-installed"
    r = _systemctl("is-active", SERVICE_NAME, user_service=user_service)
    return r.stdout.strip() or "unknown"


def status_output(*, user_service: bool) -> str:
    """Return human-readable `systemctl status` output."""
    if not _systemd_available():
        return "systemd is not available on this system"
    r = _systemctl("status", "--no-pager", SERVICE_NAME, user_service=user_service)
    out = (r.stdout + r.stderr).strip()
    return out if out else "No status output"
