from __future__ import annotations

import argparse
import asyncio
from datetime import datetime
import os


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    from hermit_proxy.config import get_settings
    from hermit_proxy.logging_utils import DEFAULT_LOG_LEVEL, VALID_LOG_LEVELS, configure_logging
    from hermit_proxy.storage import TrafficStore

    settings = get_settings()
    store = TrafficStore(settings.database_url)
    stored_log_level = store.get_app_state("log_level") or DEFAULT_LOG_LEVEL

    if args.command == "serve":
        import uvicorn

        from hermit_proxy.main import app

        active_log_level = configure_logging(getattr(args, "log_level", None) or stored_log_level)
        host = args.host or store.get_app_state("server_host") or "127.0.0.1"
        port = args.port or int(store.get_app_state("server_port") or 14415)
        uvicorn.run(app, host=host, port=port, reload=args.reload, log_level=active_log_level.lower())
        return
    if args.command == "tui":
        from hermit_proxy.tui import run_tui

        configure_logging(stored_log_level)
        run_tui()
        return

    from hermit_proxy.auth import AuthManager
    from hermit_proxy.profile_test import ProfileTester
    from hermit_proxy.profiles import ProfileManager
    from hermit_proxy.upstream import UpstreamClient

    configure_logging(stored_log_level)
    manager = ProfileManager(settings, store)
    auth_manager = AuthManager(settings, store)
    tester = ProfileTester(settings, store, UpstreamClient(settings.request_timeout_seconds))
    manager.ensure_bootstrap_profile()

    if args.command == "profiles":
        handle_profiles_command(args, store, manager, tester)
        return
    if args.command == "auth":
        handle_auth_command(args, store, auth_manager)
        return
    if args.command == "report":
        handle_report_command(args, store)
        return
    if args.command == "usage":
        handle_usage_command(store)
        return
    if args.command == "config":
        handle_config_command(args, store, valid_levels=VALID_LOG_LEVELS)
        return
    if args.command == "service":
        handle_service_command(args)
        return
    if args.command == "ping":
        handle_ping_command(args, store)
        return


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="hermitcrab",
        description=(
            "hermitcrab — local LLM billing ledger with OpenAI-compatible routing.\n"
            "Every request is logged to a local SQLite database with full token accounting.\n"
            "Use 'usage' for a quick spending summary, 'report' for detailed breakdowns by model or time,\n"
            "and 'tui' for an interactive billing dashboard.\n"
            "Database path comes from HERMIT_DATABASE_URL (default: ~/.hermitcrab/hermit.db)."
        ),
        epilog=(
            "Examples:\n"
            "  HERMIT_DATABASE_URL=sqlite:////path/to/hermit.db hermitcrab profiles list\n"
            "  hermitcrab serve --host 0.0.0.0 --port 14415\n"
            "  hermitcrab profiles list\n"
            "  hermitcrab profiles add --name openrouter --provider openrouter "
            "--base-url https://openrouter.ai/api/v1 --model anthropic/claude-sonnet-4 "
            "--api-key $OPENROUTER_API_KEY --activate\n"
            "  hermitcrab profiles activate openrouter --skip-test\n"
            "  hermitcrab usage\n"
            "  hermitcrab report --view all --bucket day --since 2026-04-01T00:00:00\n"
            "  hermitcrab auth login-github-copilot --name work-copilot --device --client-id $GITHUB_OAUTH_CLIENT_ID"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    server = subparsers.add_parser(
        "serve",
        help="Start the billing server (OpenAI-compatible endpoint)",
        description=(
            "Start the hermitcrab server. Exposes OpenAI-compatible endpoints your tools connect to.\n"
            "Every request is transparently forwarded to the active upstream provider and logged\n"
            "to the local SQLite billing ledger with full token accounting.\n"
            "Main endpoints: /v1/chat/completions, /v1/embeddings, /v1/models.\n\n"
            "The active provider profile is read from the database on each request — switch providers\n"
            "with `hermitcrab profiles activate ...` without restarting the server."
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    server.add_argument("--host", default=None, help="Bind address for the HTTP server. Default: 127.0.0.1 (or persisted config value)")
    server.add_argument("--port", type=int, default=None, help="TCP port for the HTTP server. Default: 14415 (or persisted config value)")
    server.add_argument("--reload", action="store_true", help="Enable uvicorn auto-reload for development.")
    server.add_argument(
        "--log-level",
        choices=["critical", "error", "warning", "info", "debug"],
        help="One-off server log level override. If omitted, the persisted config value is used.",
    )

    subparsers.add_parser(
        "tui",
        help="Interactive billing dashboard (terminal UI)",
        description=(
            "Launch the interactive terminal dashboard.\n"
            "Shows live token spending by provider and model, lets you switch profiles,\n"
            "and provides a billing overview without leaving the terminal."
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )

    profiles = subparsers.add_parser(
        "profiles",
        help="Manage provider profiles (which provider gets billed)",
        description=(
            "Create, update, activate, test, list, and inspect provider profiles.\n"
            "A profile defines which upstream provider and model receives requests,\n"
            "and therefore which account is billed.\n\n"
            "Profiles are stored in the local SQLite billing database (HERMIT_DATABASE_URL, default: ~/.hermitcrab/hermit.db).\n"
            "Switching the active profile takes effect immediately — no server restart needed.\n\n"
            "Typical flow:\n"
            "  1. List existing profiles\n"
            "     hermitcrab profiles list\n"
            "  2. Add a new provider and validate connectivity\n"
            "     hermitcrab profiles add --name openrouter \\\n"
            "       --provider openrouter --base-url https://openrouter.ai/api/v1 \\\n"
            "       --model nvidia/nemotron-3-super-120b-a12b:free --api-key $OPENROUTER_API_KEY --activate\n"
            "  3. Hot-switch billing to a different provider\n"
            "     hermitcrab profiles activate openrouter --skip-test\n"
            "  4. Check token spend so far\n"
            "     hermitcrab usage\n"
            "     hermitcrab report --view recent --requests-limit 20"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    profiles_sub = profiles.add_subparsers(dest="profiles_command", required=True)

    profiles_sub.add_parser(
        "list",
        help="List saved profiles",
        description=(
            "Show all saved upstream profiles. The active profile is marked with '*'.\n"
            "Output includes provider, base URL, auth-profile linkage, and client-model-override policy."
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )

    add = profiles_sub.add_parser(
        "add",
        help="Create a saved profile",
        description=(
            "Create a new upstream profile.\n"
            "By default this runs a quick validation request before saving.\n"
            "Use --skip-test only when the upstream is intentionally unreachable during setup."
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    add_profile_arguments(add, required=True)
    add.add_argument("--activate", action="store_true", help="Activate the profile immediately after saving it.")
    add.add_argument("--skip-test", action="store_true", help="Skip the automatic quick validation request.")

    update = profiles_sub.add_parser(
        "update",
        help="Update a saved profile",
        description=(
            "Update an existing profile selected by numeric id or exact profile name.\n"
            "All core connection fields are supplied again on update."
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    update.add_argument("selector", help="Profile id or exact profile name to update.")
    add_profile_arguments(update, required=True)
    update.add_argument("--activate", action="store_true", help="Activate the profile after updating it.")
    update.add_argument("--skip-test", action="store_true", help="Skip the automatic quick validation request.")

    activate = profiles_sub.add_parser(
        "activate",
        help="Activate a saved profile",
        description=(
            "Switch the proxy to a previously saved profile.\n"
            "By default the profile is tested before activation.\n\n"
            "This is a hot switch: new proxy requests use the new active profile immediately,\n"
            "while requests already in flight continue on the old upstream connection."
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    activate.add_argument("selector", help="Profile id or exact profile name to activate.")
    activate.add_argument("--skip-test", action="store_true", help="Activate without running the quick validation request.")

    delete = profiles_sub.add_parser(
        "delete",
        help="Delete a saved profile",
        description="Delete a saved profile selected by numeric id or exact profile name.",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    delete.add_argument("selector", help="Profile id or exact profile name to delete.")

    current = profiles_sub.add_parser(
        "current",
        help="Show the active profile",
        description="Print the current active profile, including whether client model override is enabled.",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    current.add_argument("--show-secret", action="store_true", help="Print the raw API key instead of a masked version.")

    test = profiles_sub.add_parser(
        "test",
        help="Run a quick upstream validation request",
        description=(
            "Run the quick validation request without saving or activating anything.\n\n"
            "Mode 1: test an existing saved profile\n"
            "  hermitcrab profiles test --saved openrouter-gemma-free\n\n"
            "Mode 2: test a temporary unsaved config\n"
            "  hermitcrab profiles test --provider openrouter --base-url https://openrouter.ai/api/v1 \\\n"
            "    --model google/gemma-4-26b-a4b-it:free --api-key $OPENROUTER_API_KEY"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    test.add_argument(
        "selector",
        nargs="?",
        help="Saved profile id or exact profile name when using --saved.",
    )
    add_test_profile_arguments(test)
    test.add_argument("--saved", action="store_true", help="Interpret selector as an existing saved profile.")

    auth = subparsers.add_parser(
        "auth",
        help="Manage provider auth profiles",
        description=(
            "Create and inspect auth profiles used by providers that need separate credential state.\n"
            "Current examples: github-copilot auth profiles and device-login flows."
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    auth_sub = auth.add_subparsers(dest="auth_command", required=True)

    auth_sub.add_parser(
        "list",
        help="List auth profiles",
        description="Show stored auth profiles and masked credential summaries.",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    auth_login = auth_sub.add_parser(
        "login-github-copilot",
        help="Create or update a GitHub Copilot auth profile",
        description=(
            "Store GitHub credentials for the github-copilot provider.\n"
            "You can either pass a GitHub token directly or run a GitHub device-login flow.\n"
            "When using --device, provide a GitHub OAuth client id."
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    auth_login.add_argument("--name", required=True, help="Logical auth-profile name to store.")
    auth_login.add_argument("--github-token", help="Existing GitHub access token. If omitted, env fallbacks are checked.")
    auth_login.add_argument("--github-domain", default="github.com", help="GitHub host. Default: github.com")
    auth_login.add_argument("--device", action="store_true", help="Use GitHub OAuth device-login flow instead of a pre-existing token.")
    auth_login.add_argument("--client-id", help="GitHub OAuth client id used for device flow.")

    report = subparsers.add_parser(
        "report",
        help="Print token billing reports",
        description=(
            "Read the local billing ledger and print token spend analytics.\n"
            "Use this to audit prompt/completion/total token costs, spending over time,\n"
            "and per-model breakdown without opening the TUI.\n"
            "Reads from the database selected by HERMIT_DATABASE_URL (default: ~/.hermitcrab/hermit.db).\n\n"
            "Views:\n"
            "  summary    Global spend totals and average latency.\n"
            "  by-model   Spend aggregated by provider/model pair.\n"
            "  timeseries Time-bucketed spend over a period.\n"
            "  recent     Most recent billed requests.\n"
            "  all        Print every view in sequence.\n\n"
            "Use `hermitcrab usage` when you only need the shortest totals output.\n\n"
            "Examples:\n"
            "  hermitcrab report --view summary\n"
            "  hermitcrab report --view by-model\n"
            "  hermitcrab report --view timeseries --bucket day --since 2026-04-01T00:00:00\n"
            "  hermitcrab report --view recent --requests-limit 20"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    report.add_argument("--bucket", choices=["minute", "hour", "day"], default="hour", help="Time bucket size for --view timeseries. Default: hour")
    report.add_argument("--since", help="ISO timestamp lower bound, for example 2026-04-01T00:00:00")
    report.add_argument("--requests-limit", type=int, default=10, help="Maximum number of rows for --view recent. Default: 10")
    report.add_argument(
        "--view",
        choices=["summary", "by-model", "timeseries", "recent", "all"],
        default="all",
        help="Which report section to print. Default: all",
    )

    subparsers.add_parser(
        "usage",
        help="Print token spend totals (quick summary)",
        description=(
            "Print a one-line billing summary from the local ledger:\n"
            "prompt tokens sent, completion tokens received, total tokens, request count, success count.\n"
            "This is the fastest way to check how much has been spent.\n"
            "Reads from the database selected by HERMIT_DATABASE_URL (default: ~/.hermitcrab/hermit.db).\n\n"
            "Example:\n"
            "  hermitcrab usage"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )

    config = subparsers.add_parser(
        "config",
        help="Manage runtime settings",
        description=(
            "Read or update persisted settings stored in the local SQLite database.\n"
            "Database location comes from HERMIT_DATABASE_URL (default: ~/.hermitcrab/hermit.db).\n"
            "Currently supported settings: default server log level.\n\n"
            "Examples:\n"
            "  hermitcrab config get log-level\n"
            "  hermitcrab config set log-level debug\n"
            "  hermitcrab server --log-level warning"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    config_sub = config.add_subparsers(dest="config_command", required=True)
    config_get = config_sub.add_parser(
        "get",
        help="Read a persisted setting",
        description="Read a persisted proxy setting from local state.",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    config_get.add_argument("key", choices=["log-level", "host", "port"], help="Setting name. Supported: log-level, host, port")
    config_set = config_sub.add_parser(
        "set",
        help="Update a persisted setting",
        description=(
            "Update a persisted proxy setting. The new value will be used by later `server` runs\n"
            "unless a one-off command-line override is provided."
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    config_set.add_argument("key", choices=["log-level", "host", "port"], help="Setting name. Supported: log-level, host, port")
    config_set.add_argument(
        "value",
        help="New setting value. For log-level: critical/error/warning/info/debug. For host: bind address. For port: TCP port number.",
    )

    service = subparsers.add_parser(
        "service",
        help="Manage the hermitcrab systemd service",
        description=(
            "Install, uninstall, start, stop, restart, or check the status of the\n"
            "hermitcrab systemd service.\n\n"
            "User-level services (--user, default) do not require sudo.\n"
            "System-level services write to /etc/systemd/system/ and require sudo.\n\n"
            "Examples:\n"
            "  hermitcrab service install          # user-level, no sudo\n"
            "  hermitcrab service install --system # system-level, uses sudo\n"
            "  hermitcrab service restart\n"
            "  hermitcrab service status\n"
            "  hermitcrab service uninstall"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    service_sub = service.add_subparsers(dest="service_command", required=True)

    def _add_scope_arg(p: argparse.ArgumentParser) -> None:
        grp = p.add_mutually_exclusive_group()
        grp.add_argument("--user", dest="user_service", action="store_true", default=True,
                         help="Operate on the user-level service (default, no sudo required)")
        grp.add_argument("--system", dest="user_service", action="store_false",
                         help="Operate on the system-level service (requires sudo)")

    install_p = service_sub.add_parser("install", help="Install and enable the service",
                                       formatter_class=argparse.RawTextHelpFormatter)
    _add_scope_arg(install_p)
    install_p.add_argument("--no-enable", action="store_true",
                           help="Install the unit file but do not enable or start the service")
    install_p.add_argument("--print-unit", action="store_true",
                           help="Print the generated unit file and exit without installing")

    uninstall_p = service_sub.add_parser("uninstall", help="Stop, disable, and remove the service",
                                         formatter_class=argparse.RawTextHelpFormatter)
    _add_scope_arg(uninstall_p)

    start_p = service_sub.add_parser("start", help="Start the service",
                                     formatter_class=argparse.RawTextHelpFormatter)
    _add_scope_arg(start_p)

    stop_p = service_sub.add_parser("stop", help="Stop the service",
                                    formatter_class=argparse.RawTextHelpFormatter)
    _add_scope_arg(stop_p)

    restart_p = service_sub.add_parser("restart", help="Restart the service",
                                       formatter_class=argparse.RawTextHelpFormatter)
    _add_scope_arg(restart_p)

    status_p = service_sub.add_parser("status", help="Show service status",
                                      formatter_class=argparse.RawTextHelpFormatter)
    _add_scope_arg(status_p)

    ping = subparsers.add_parser(
        "ping",
        help="Test proxy reachability and upstream model connectivity",
        description=(
            "Two-stage connectivity check:\n\n"
            "  Stage 1 — proxy port:  GET /health on the local hermitcrab proxy.\n"
            "  Stage 2 — upstream:    POST /v1/chat/completions through the proxy\n"
            "                         (or directly to the upstream if --direct is set).\n\n"
            "By default both stages run against the proxy.  Use --no-proxy to skip\n"
            "the proxy and test the active profile's upstream directly.\n\n"
            "Examples:\n"
            "  hermitcrab ping                          # health + chat through proxy\n"
            "  hermitcrab ping --host 0.0.0.0 --port 14415\n"
            "  hermitcrab ping --no-proxy               # direct upstream test only\n"
            "  hermitcrab ping --no-chat                # health check only"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    ping.add_argument("--host", default=None,
                      help="Proxy host to test (default: persisted config or 127.0.0.1)")
    ping.add_argument("--port", type=int, default=None,
                      help="Proxy port to test (default: persisted config or 14415)")
    ping.add_argument("--no-proxy", action="store_true",
                      help="Skip proxy and test the active upstream profile directly")
    ping.add_argument("--no-chat", action="store_true",
                      help="Only run the proxy health check, skip the chat completion probe")
    ping.add_argument("--message", "-m", default=None,
                      help="Message to send in the chat probe (default: prompt interactively)")

    return parser


def add_profile_arguments(parser: argparse.ArgumentParser, *, required: bool) -> None:
    parser.add_argument("--name", required=required, help="Profile name used for later lookup and activation.")
    parser.add_argument(
        "--provider",
        required=required,
        help=(
            "Provider id, for example openai, openrouter, github-models, github-copilot, "
            "copilot-proxy, vllm, lmstudio, xiaomi, amazon-bedrock, nvidia, huggingface, or openai-compatible."
        ),
    )
    parser.add_argument("--base-url", required=required, help="Upstream provider base URL, usually ending in /v1.")
    parser.add_argument("--model", required=required, help="Default upstream model for this profile.")
    parser.add_argument("--api-key", default="", help="Raw API key for providers that use direct Bearer auth.")
    parser.add_argument(
        "--auth-profile-id",
        type=int,
        help="Reference to a stored auth profile, used by providers like github-copilot.",
    )
    parser.add_argument(
        "--allow-client-model-override",
        action="store_true",
        help="Forward the caller's model field to the upstream provider instead of forcing the saved profile model.",
    )
    parser.add_argument(
        "--default-max-tokens",
        type=int,
        help="Default output token limit for this profile when the client does not send one.",
    )


def add_test_profile_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--name", help="Temporary label for the unsaved test config. Optional.")
    parser.add_argument(
        "--provider",
        help=(
            "Provider id for an unsaved test config, for example openai, openrouter, github-models, "
            "github-copilot, copilot-proxy, vllm, lmstudio, xiaomi, amazon-bedrock, nvidia, huggingface, or openai-compatible."
        ),
    )
    parser.add_argument("--base-url", help="Upstream provider base URL for an unsaved test config.")
    parser.add_argument("--model", help="Model to test for an unsaved config.")
    parser.add_argument("--api-key", default="", help="API key for an unsaved test config.")
    parser.add_argument(
        "--auth-profile-id",
        type=int,
        help="Auth-profile id for an unsaved test config, used by providers like github-copilot.",
    )
    parser.add_argument(
        "--allow-client-model-override",
        action="store_true",
        help="For an unsaved test config, resolve the upstream as if caller model forwarding were enabled.",
    )
    parser.add_argument(
        "--default-max-tokens",
        type=int,
        help="Default output token limit for an unsaved test config.",
    )


def handle_profiles_command(
    args: argparse.Namespace,
    store: TrafficStore,
    manager: ProfileManager,
    tester: ProfileTester,
) -> None:
    if args.profiles_command == "list":
        active_id = int(store.get_app_state("active_profile_id") or 0)
        for profile in store.list_profiles():
            marker = "*" if int(profile["id"]) == active_id else " "
            print(
                f"{marker} id={profile['id']} name={profile['name']} provider={profile['provider']} "
                f"model={profile['model']} base_url={profile['base_url']} auth_profile_id={profile.get('auth_profile_id')} "
                f"allow_client_model_override={bool(profile.get('allow_client_model_override'))} "
                f"default_max_tokens={profile.get('default_max_tokens')}"
            )
        return

    if args.profiles_command == "add":
        provider_config = manager.provider_config_from_values(
            name=args.name,
            provider=args.provider,
            base_url=args.base_url,
            api_key=args.api_key,
            model=args.model,
            auth_profile_id=args.auth_profile_id,
            allow_client_model_override=args.allow_client_model_override,
            default_max_tokens=args.default_max_tokens,
            activate=args.activate,
        )
        if not args.skip_test:
            print_test_result(asyncio.run(tester.quick_test(provider_config)))
        profile_id = manager.save_profile(
            name=args.name,
            provider=args.provider,
            base_url=args.base_url,
            api_key=args.api_key,
            auth_profile_id=args.auth_profile_id,
            model=args.model,
            allow_client_model_override=args.allow_client_model_override,
            default_max_tokens=args.default_max_tokens,
            activate=args.activate,
        )
        print_profile(store.get_profile(profile_id), show_secret=False)
        return

    if args.profiles_command in {"update", "activate", "delete", "test"}:
        profile = manager.resolve_profile(args.selector)
        if args.profiles_command != "test" and not profile:
            raise SystemExit(f"Profile not found: {args.selector}")
        if args.profiles_command == "test":
            if args.saved:
                if not profile:
                    raise SystemExit(f"Profile not found: {args.selector}")
                provider_config = manager.provider_config_from_values(
                    name=str(profile["name"]),
                    provider=str(profile["provider"]),
                    base_url=str(profile["base_url"]),
                    api_key=str(profile["api_key"]),
                    auth_profile_id=profile.get("auth_profile_id"),
                    model=str(profile["model"]),
                    allow_client_model_override=bool(profile.get("allow_client_model_override")),
                    default_max_tokens=profile.get("default_max_tokens"),
                )
            else:
                for field in ("name", "provider", "base_url", "model"):
                    if getattr(args, field) in (None, ""):
                        raise SystemExit(f"--{field.replace('_', '-')} is required unless --saved is used")
                provider_config = manager.provider_config_from_values(
                    name=args.name,
                    provider=args.provider,
                    base_url=args.base_url,
                    api_key=args.api_key,
                    auth_profile_id=args.auth_profile_id,
                    model=args.model,
                    allow_client_model_override=args.allow_client_model_override,
                    default_max_tokens=args.default_max_tokens,
                )
            print_test_result(asyncio.run(tester.quick_test(provider_config)))
            return

        if args.profiles_command == "update":
            provider_config = manager.provider_config_from_values(
                name=args.name,
                provider=args.provider,
                base_url=args.base_url,
                api_key=args.api_key,
                auth_profile_id=args.auth_profile_id,
                model=args.model,
                allow_client_model_override=args.allow_client_model_override,
                default_max_tokens=args.default_max_tokens,
                activate=args.activate,
            )
            if not args.skip_test:
                print_test_result(asyncio.run(tester.quick_test(provider_config)))
            manager.save_profile(
                profile_id=int(profile["id"]),
                name=args.name,
                provider=args.provider,
                base_url=args.base_url,
                api_key=args.api_key,
                auth_profile_id=args.auth_profile_id,
                model=args.model,
                allow_client_model_override=args.allow_client_model_override,
                default_max_tokens=args.default_max_tokens,
                activate=args.activate,
            )
            print_profile(store.get_profile(int(profile["id"])), show_secret=False)
            return

        if args.profiles_command == "activate":
            if args.skip_test:
                store.set_active_profile(int(profile["id"]))
                print(f"Activated profile id={profile['id']} name={profile['name']}")
                return
            provider_config = manager.provider_config_from_values(
                name=str(profile["name"]),
                provider=str(profile["provider"]),
                base_url=str(profile["base_url"]),
                api_key=str(profile["api_key"]),
                auth_profile_id=profile.get("auth_profile_id"),
                model=str(profile["model"]),
                allow_client_model_override=bool(profile.get("allow_client_model_override")),
                default_max_tokens=profile.get("default_max_tokens"),
            )
            print_test_result(asyncio.run(tester.quick_test(provider_config)))
            store.set_active_profile(int(profile["id"]))
            print(f"Activated profile id={profile['id']} name={profile['name']}")
            return

        if args.profiles_command == "delete":
            store.delete_profile(int(profile["id"]))
            manager.ensure_bootstrap_profile()
            print(f"Deleted profile id={profile['id']} name={profile['name']}")
            return

    if args.profiles_command == "current":
        print_profile(store.get_active_profile(), show_secret=args.show_secret)
        return


def handle_auth_command(args: argparse.Namespace, store: TrafficStore, auth: AuthManager) -> None:
    if args.auth_command == "list":
        for item in store.list_auth_profiles():
            secrets = item.get("secrets", {})
            token = str(secrets.get("github_token") or "")
            domain = str(secrets.get("github_domain") or "github.com")
            print(
                f"id={item['id']} name={item['name']} provider={item['provider']} "
                f"github_domain={domain} github_token={mask_secret(token)}"
            )
        return

    if args.auth_command == "login-github-copilot":
        github_token = args.github_token or os.getenv("COPILOT_GITHUB_TOKEN") or os.getenv("GH_TOKEN") or os.getenv("GITHUB_TOKEN")
        if args.device:
            client_id = args.client_id or os.getenv("GITHUB_OAUTH_CLIENT_ID")
            if not client_id:
                raise SystemExit("OAuth client id is required via --client-id or GITHUB_OAUTH_CLIENT_ID for --device")
            flow = auth.start_github_device_flow(client_id=client_id, github_domain=args.github_domain)
            print(f"Open {flow.verification_uri} and enter code: {flow.user_code}")
            github_token = auth.complete_github_device_flow(
                client_id=client_id,
                device_code=flow.device_code,
                github_domain=args.github_domain,
                interval=flow.interval,
                expires_in=flow.expires_in,
            )
        if not github_token:
            raise SystemExit("GitHub token is required via --github-token or COPILOT_GITHUB_TOKEN/GH_TOKEN/GITHUB_TOKEN")
        auth_profile_id = auth.save_github_copilot_auth_profile(
            name=args.name,
            github_token=github_token,
            github_domain=args.github_domain,
        )
        item = store.get_auth_profile(auth_profile_id)
        assert item is not None
        print(
            f"Saved auth profile id={item['id']} name={item['name']} provider={item['provider']} "
            f"github_domain={item['secrets'].get('github_domain')} github_token={mask_secret(str(item['secrets'].get('github_token') or ''))}"
        )
        return


def handle_report_command(args: argparse.Namespace, store: TrafficStore) -> None:
    if args.since:
        datetime.fromisoformat(args.since)

    if args.view in {"summary", "all"}:
        summary = store.summary()
        print("[summary]")
        print(
            f"requests={summary['requests']} successful={summary['successful_requests']} "
            f"prompt_tokens={summary['prompt_tokens']} completion_tokens={summary['completion_tokens']} "
            f"total_tokens={summary['total_tokens']} avg_latency_ms={int(summary['avg_latency_ms'] or 0)}"
        )
        print()

    if args.view in {"by-model", "all"}:
        print("[by-model]")
        for item in store.summary_by_profile():
            print(
                f"{item['provider']}/{item['upstream_model']} requests={item['requests']} "
                f"prompt={item['prompt_tokens']} completion={item['completion_tokens']} "
                f"total={item['total_tokens']} avg_ms={int(item['avg_latency_ms'] or 0)}"
            )
        print()

    if args.view in {"timeseries", "all"}:
        print(f"[timeseries bucket={args.bucket}]")
        for item in store.timeseries(bucket=args.bucket, since=args.since):
            print(
                f"{item['bucket_start']} {item['provider']}/{item['upstream_model']} "
                f"requests={item['requests']} prompt={item['prompt_tokens']} "
                f"completion={item['completion_tokens']} total={item['total_tokens']}"
            )
        print()

    if args.view in {"recent", "all"}:
        print(f"[recent limit={args.requests_limit}]")
        for item in store.recent_requests(limit=args.requests_limit):
            print(
                f"{item['received_at']} status={item['status_code']} success={item['success']} "
                f"provider={item['provider']} model={item['upstream_model']} "
                f"prompt={item['prompt_tokens']} completion={item['completion_tokens']} "
                f"total={item['total_tokens']}"
            )


def handle_usage_command(store: TrafficStore) -> None:
    summary = store.summary()
    print(
        f"up={summary['prompt_tokens']} down={summary['completion_tokens']} "
        f"total={summary['total_tokens']} requests={summary['requests']} "
        f"successful={summary['successful_requests']}"
    )


def handle_config_command(args: argparse.Namespace, store: TrafficStore, *, valid_levels: tuple[str, ...]) -> None:
    if args.config_command == "get":
        if args.key == "log-level":
            value = store.get_app_state("log_level") or "INFO"
            print(f"log-level={value}")
            return
        if args.key == "host":
            value = store.get_app_state("server_host") or "127.0.0.1"
            print(f"host={value}")
            return
        if args.key == "port":
            value = store.get_app_state("server_port") or "14415"
            print(f"port={value}")
            return

    if args.config_command == "set":
        if args.key == "log-level":
            value = args.value.upper()
            if value not in valid_levels:
                valid = ", ".join(level.lower() for level in valid_levels)
                raise SystemExit(f"log-level must be one of: {valid}")
            store.set_app_state("log_level", value)
            print(f"log-level={value}")
            return
        if args.key == "host":
            store.set_app_state("server_host", args.value)
            print(f"host={args.value}")
            return
        if args.key == "port":
            try:
                port = int(args.value)
                if not (1 <= port <= 65535):
                    raise ValueError
            except ValueError:
                raise SystemExit("port must be an integer between 1 and 65535")
            store.set_app_state("server_port", str(port))
            print(f"port={port}")
            return


def handle_ping_command(args: argparse.Namespace, store: TrafficStore) -> None:
    import time
    import urllib.error
    import urllib.request

    from hermit_proxy.config import get_settings
    from hermit_proxy.profile_test import ProfileTester
    from hermit_proxy.profiles import ProfileManager
    from hermit_proxy.upstream import UpstreamClient

    settings = get_settings()
    failed = False

    import json as _json
    import sys as _sys

    # Resolve the user message once (used by both proxy-chat and upstream modes)
    user_message: str | None = None
    if not args.no_chat:
        if args.message:
            user_message = args.message
        else:
            try:
                user_message = input("Message: ").strip()
            except EOFError:
                user_message = "Reply with OK"

    def _send_via_proxy(url: str, message: str) -> tuple[int, str, dict]:
        """POST to the proxy chat endpoint. Returns (latency_ms, reply, usage)."""
        payload = _json.dumps({
            "model": "ping",
            "messages": [{"role": "user", "content": message}],
        }).encode()
        req = urllib.request.Request(
            url, data=payload, headers={"Content-Type": "application/json"}, method="POST"
        )
        t0 = time.monotonic()
        with urllib.request.urlopen(req, timeout=60) as resp:
            latency = int((time.monotonic() - t0) * 1000)
            data = _json.loads(resp.read().decode())
        return latency, data["choices"][0]["message"]["content"], data.get("usage", {})

    if not args.no_proxy:
        host = args.host or store.get_app_state("server_host") or "127.0.0.1"
        port = args.port or int(store.get_app_state("server_port") or 14415)
        health_url = f"http://{host}:{port}/health"
        try:
            t0 = time.monotonic()
            with urllib.request.urlopen(health_url, timeout=5) as resp:
                latency = int((time.monotonic() - t0) * 1000)
                body = resp.read().decode()
            print(f"[proxy-health] status=ok  url={health_url}  latency_ms={latency}")
            print(f"[proxy-health] {body}")
        except Exception as exc:
            print(f"[proxy-health] status=fail  url={health_url}  error={exc}")
            failed = True

        if not args.no_chat and not failed and user_message:
            chat_url = f"http://{host}:{port}/v1/chat/completions"
            print(f"\n[proxy-chat]   sending to {chat_url}")
            print(f"[proxy-chat]   You: {user_message}")
            try:
                latency, reply, usage = _send_via_proxy(chat_url, user_message)
                print(
                    f"[proxy-chat]   latency_ms={latency}  "
                    f"prompt={usage.get('prompt_tokens','?')} completion={usage.get('completion_tokens','?')}"
                )
                print(f"[proxy-chat]   AI: {reply}")
            except Exception as exc:
                print(f"[proxy-chat]   status=fail  error={exc}")
                failed = True

    if args.no_proxy:
        manager = ProfileManager(settings, store)
        client = UpstreamClient(settings.request_timeout_seconds)
        profile = store.get_active_profile()
        if not profile:
            print("[upstream] status=fail  error=no active profile")
            raise SystemExit(1)
        provider_config = manager.provider_config_from_values(
            name=str(profile["name"]),
            provider=str(profile["provider"]),
            base_url=str(profile["base_url"]),
            api_key=str(profile["api_key"]),
            auth_profile_id=profile.get("auth_profile_id"),
            model=str(profile["model"]),
            allow_client_model_override=bool(profile.get("allow_client_model_override")),
            default_max_tokens=profile.get("default_max_tokens"),
        )
        label = f"{profile['provider']}/{profile['model']}"
        if args.no_chat:
            # Quick connectivity test only (no user message needed)
            tester = ProfileTester(settings, store, client)
            result = asyncio.run(tester.quick_test(provider_config))
            status = "ok" if result.ok else "fail"
            print(
                f"[upstream]     status={status}  provider={result.provider}  model={result.model}  "
                f"http_status={result.status_code}  latency_ms={result.latency_ms}"
            )
            if result.response_excerpt:
                print(f"[upstream]     detail={result.response_excerpt[:120]}")
            if not result.ok:
                failed = True
        elif user_message:
            print(f"\n[upstream]     sending to {label}")
            print(f"[upstream]     You: {user_message}")
            try:
                payload = {"model": provider_config.model, "messages": [{"role": "user", "content": user_message}]}
                t0 = time.monotonic()
                status_code, data = asyncio.run(client.chat_completions(provider_config, payload))
                latency = int((time.monotonic() - t0) * 1000)
                if status_code != 200:
                    err = data.get("error", {})
                    raise RuntimeError(f"HTTP {status_code}: {err.get('message', data)}")
                reply = data["choices"][0]["message"]["content"]
                usage = data.get("usage", {})
                print(
                    f"[upstream]     latency_ms={latency}  "
                    f"prompt={usage.get('prompt_tokens','?')} completion={usage.get('completion_tokens','?')}"
                )
                print(f"[upstream]     AI: {reply}")
            except Exception as exc:
                print(f"[upstream]     status=fail  error={exc}")
                failed = True

    if failed:
        raise SystemExit(1)


def handle_service_command(args: argparse.Namespace) -> None:
    from hermit_proxy import service_manager as svc

    user_service: bool = args.user_service

    if args.service_command == "install":
        if args.print_unit:
            print(svc.generate_service_unit(user_service=user_service), end="")
            return
        ok, msg = svc.install(user_service=user_service, enable=not args.no_enable)
        print(msg)
        if not ok:
            raise SystemExit(1)
        return

    if args.service_command == "uninstall":
        ok, msg = svc.uninstall(user_service=user_service)
        print(msg)
        if not ok:
            raise SystemExit(1)
        return

    if args.service_command == "start":
        ok, msg = svc.start(user_service=user_service)
        print(msg)
        if not ok:
            raise SystemExit(1)
        return

    if args.service_command == "stop":
        ok, msg = svc.stop(user_service=user_service)
        print(msg)
        if not ok:
            raise SystemExit(1)
        return

    if args.service_command == "restart":
        ok, msg = svc.restart(user_service=user_service)
        print(msg)
        if not ok:
            raise SystemExit(1)
        return

    if args.service_command == "status":
        print(svc.status_output(user_service=user_service))
        return


def print_profile(profile: dict | None, *, show_secret: bool) -> None:
    if not profile:
        raise SystemExit("No active profile")
    api_key = str(profile["api_key"]) if show_secret else mask_secret(str(profile["api_key"]))
    print(
        f"id={profile['id']} name={profile['name']} provider={profile['provider']} "
        f"model={profile['model']} base_url={profile['base_url']} auth_profile_id={profile.get('auth_profile_id')} "
        f"allow_client_model_override={bool(profile.get('allow_client_model_override'))} "
        f"default_max_tokens={profile.get('default_max_tokens')} api_key={api_key}"
    )


def print_test_result(result) -> None:
    status = "ok" if result.ok else "failed"
    print(
        f"[quick-test] status={status} provider={result.provider} model={result.model} "
        f"http_status={result.status_code} latency_ms={result.latency_ms}"
    )
    if result.response_excerpt:
        print(f"[quick-test] detail={result.response_excerpt}")
    if not result.ok:
        raise SystemExit(result.message)


def mask_secret(value: str) -> str:
    if not value:
        return "(empty)"
    if len(value) <= 8:
        return "*" * len(value)
    return f"{value[:4]}...{value[-4:]}"


if __name__ == "__main__":
    main()
