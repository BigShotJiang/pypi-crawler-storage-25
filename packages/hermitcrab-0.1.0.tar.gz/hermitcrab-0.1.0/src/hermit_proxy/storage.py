from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator


class TrafficStore:
    def __init__(self, database_url: str) -> None:
        if not database_url.startswith("sqlite:///"):
            raise ValueError("Only sqlite:/// URLs are supported")
        self.db_path = Path(database_url.removeprefix("sqlite:///"))
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    @contextmanager
    def connection(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def _init_db(self) -> None:
        with self.connection() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS request_log (
                    request_id TEXT PRIMARY KEY,
                    received_at TEXT NOT NULL,
                    completed_at TEXT,
                    provider TEXT NOT NULL,
                    upstream_model TEXT NOT NULL,
                    client_model TEXT,
                    status_code INTEGER,
                    success INTEGER NOT NULL DEFAULT 0,
                    latency_ms INTEGER,
                    prompt_tokens INTEGER NOT NULL DEFAULT 0,
                    completion_tokens INTEGER NOT NULL DEFAULT 0,
                    total_tokens INTEGER NOT NULL DEFAULT 0,
                    request_body TEXT NOT NULL,
                    response_body TEXT NOT NULL,
                    error_message TEXT
                );
                CREATE TABLE IF NOT EXISTS model_profiles (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL UNIQUE,
                    provider TEXT NOT NULL,
                    base_url TEXT NOT NULL,
                    api_key TEXT NOT NULL DEFAULT '',
                    auth_profile_id INTEGER,
                    model TEXT NOT NULL,
                    allow_client_model_override INTEGER NOT NULL DEFAULT 0,
                    default_max_tokens INTEGER,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS auth_profiles (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL UNIQUE,
                    provider TEXT NOT NULL,
                    secrets_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS app_state (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_request_log_received_at ON request_log(received_at);
                CREATE INDEX IF NOT EXISTS idx_request_log_provider_model ON request_log(provider, upstream_model);
                CREATE INDEX IF NOT EXISTS idx_model_profiles_provider ON model_profiles(provider);
                CREATE INDEX IF NOT EXISTS idx_model_profiles_auth_profile ON model_profiles(auth_profile_id);
                CREATE INDEX IF NOT EXISTS idx_auth_profiles_provider ON auth_profiles(provider);
                """
            )
            columns = {row["name"] for row in conn.execute("PRAGMA table_info(model_profiles)").fetchall()}
            if "auth_profile_id" not in columns:
                conn.execute("ALTER TABLE model_profiles ADD COLUMN auth_profile_id INTEGER")
            if "allow_client_model_override" not in columns:
                conn.execute("ALTER TABLE model_profiles ADD COLUMN allow_client_model_override INTEGER NOT NULL DEFAULT 0")
            if "default_max_tokens" not in columns:
                conn.execute("ALTER TABLE model_profiles ADD COLUMN default_max_tokens INTEGER")

    def upsert_request(self, record: dict) -> None:
        with self.connection() as conn:
            conn.execute(
                """
                INSERT INTO request_log (
                    request_id, received_at, completed_at, provider, upstream_model, client_model,
                    status_code, success, latency_ms, prompt_tokens, completion_tokens, total_tokens,
                    request_body, response_body, error_message
                ) VALUES (
                    :request_id, :received_at, :completed_at, :provider, :upstream_model, :client_model,
                    :status_code, :success, :latency_ms, :prompt_tokens, :completion_tokens, :total_tokens,
                    :request_body, :response_body, :error_message
                )
                ON CONFLICT(request_id) DO UPDATE SET
                    completed_at=excluded.completed_at,
                    provider=excluded.provider,
                    upstream_model=excluded.upstream_model,
                    client_model=excluded.client_model,
                    status_code=excluded.status_code,
                    success=excluded.success,
                    latency_ms=excluded.latency_ms,
                    prompt_tokens=excluded.prompt_tokens,
                    completion_tokens=excluded.completion_tokens,
                    total_tokens=excluded.total_tokens,
                    request_body=excluded.request_body,
                    response_body=excluded.response_body,
                    error_message=excluded.error_message
                """,
                {
                    **record,
                    "success": 1 if record["success"] else 0,
                    "request_body": json.dumps(record["request_body"], ensure_ascii=True),
                    "response_body": json.dumps(record["response_body"], ensure_ascii=True),
                },
            )

    def summary(self) -> dict:
        with self.connection() as conn:
            row = conn.execute(
                """
                SELECT
                    COUNT(*) AS requests,
                    COALESCE(SUM(prompt_tokens), 0) AS prompt_tokens,
                    COALESCE(SUM(completion_tokens), 0) AS completion_tokens,
                    COALESCE(SUM(total_tokens), 0) AS total_tokens,
                    COALESCE(AVG(latency_ms), 0) AS avg_latency_ms,
                    COALESCE(SUM(success), 0) AS successful_requests
                FROM request_log
                """
            ).fetchone()
        return dict(row)

    def summary_by_profile(self) -> list[dict]:
        with self.connection() as conn:
            rows = conn.execute(
                """
                SELECT
                    provider,
                    upstream_model,
                    COUNT(*) AS requests,
                    COALESCE(SUM(prompt_tokens), 0) AS prompt_tokens,
                    COALESCE(SUM(completion_tokens), 0) AS completion_tokens,
                    COALESCE(SUM(total_tokens), 0) AS total_tokens,
                    COALESCE(AVG(latency_ms), 0) AS avg_latency_ms
                FROM request_log
                GROUP BY provider, upstream_model
                ORDER BY total_tokens DESC, requests DESC
                """
            ).fetchall()
        return [dict(row) for row in rows]

    def recent_requests(self, limit: int) -> list[dict]:
        with self.connection() as conn:
            rows = conn.execute(
                """
                SELECT *
                FROM request_log
                ORDER BY received_at DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [self._deserialize_row(row) for row in rows]

    def list_profiles(self) -> list[dict]:
        with self.connection() as conn:
            rows = conn.execute(
                """
                SELECT *
                FROM model_profiles
                ORDER BY updated_at DESC, id DESC
                """
            ).fetchall()
        return [dict(row) for row in rows]

    def get_profile(self, profile_id: int) -> dict | None:
        with self.connection() as conn:
            row = conn.execute(
                """
                SELECT *
                FROM model_profiles
                WHERE id = ?
                """,
                (profile_id,),
            ).fetchone()
        return dict(row) if row else None

    def create_profile(
        self,
        *,
        name: str,
        provider: str,
        base_url: str,
        api_key: str,
        auth_profile_id: int | None,
        model: str,
        allow_client_model_override: bool,
        default_max_tokens: int | None,
        created_at: str,
    ) -> int:
        with self.connection() as conn:
            cursor = conn.execute(
                """
                INSERT INTO model_profiles (name, provider, base_url, api_key, auth_profile_id, model, allow_client_model_override, default_max_tokens, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    name,
                    provider,
                    base_url,
                    api_key,
                    auth_profile_id,
                    model,
                    1 if allow_client_model_override else 0,
                    default_max_tokens,
                    created_at,
                    created_at,
                ),
            )
        return int(cursor.lastrowid)

    def update_profile(
        self,
        profile_id: int,
        *,
        name: str,
        provider: str,
        base_url: str,
        api_key: str,
        auth_profile_id: int | None,
        model: str,
        allow_client_model_override: bool,
        default_max_tokens: int | None,
        updated_at: str,
    ) -> None:
        with self.connection() as conn:
            conn.execute(
                """
                UPDATE model_profiles
                SET name = ?, provider = ?, base_url = ?, api_key = ?, auth_profile_id = ?, model = ?, allow_client_model_override = ?, default_max_tokens = ?, updated_at = ?
                WHERE id = ?
                """,
                (
                    name,
                    provider,
                    base_url,
                    api_key,
                    auth_profile_id,
                    model,
                    1 if allow_client_model_override else 0,
                    default_max_tokens,
                    updated_at,
                    profile_id,
                ),
            )

    def list_auth_profiles(self) -> list[dict]:
        with self.connection() as conn:
            rows = conn.execute(
                """
                SELECT *
                FROM auth_profiles
                ORDER BY updated_at DESC, id DESC
                """
            ).fetchall()
        return [self._deserialize_auth_row(row) for row in rows]

    def get_auth_profile(self, auth_profile_id: int) -> dict | None:
        with self.connection() as conn:
            row = conn.execute(
                """
                SELECT *
                FROM auth_profiles
                WHERE id = ?
                """,
                (auth_profile_id,),
            ).fetchone()
        return self._deserialize_auth_row(row) if row else None

    def get_auth_profile_by_name(self, name: str) -> dict | None:
        with self.connection() as conn:
            row = conn.execute(
                """
                SELECT *
                FROM auth_profiles
                WHERE name = ?
                """,
                (name,),
            ).fetchone()
        return self._deserialize_auth_row(row) if row else None

    def create_auth_profile(self, *, name: str, provider: str, secrets: dict, created_at: str) -> int:
        with self.connection() as conn:
            cursor = conn.execute(
                """
                INSERT INTO auth_profiles (name, provider, secrets_json, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (name, provider, json.dumps(secrets, ensure_ascii=True), created_at, created_at),
            )
        return int(cursor.lastrowid)

    def update_auth_profile(self, auth_profile_id: int, *, name: str, provider: str, secrets: dict, updated_at: str) -> None:
        with self.connection() as conn:
            conn.execute(
                """
                UPDATE auth_profiles
                SET name = ?, provider = ?, secrets_json = ?, updated_at = ?
                WHERE id = ?
                """,
                (name, provider, json.dumps(secrets, ensure_ascii=True), updated_at, auth_profile_id),
            )

    def delete_auth_profile(self, auth_profile_id: int) -> None:
        with self.connection() as conn:
            conn.execute("UPDATE model_profiles SET auth_profile_id = NULL WHERE auth_profile_id = ?", (auth_profile_id,))
            conn.execute("DELETE FROM auth_profiles WHERE id = ?", (auth_profile_id,))

    def delete_profile(self, profile_id: int) -> None:
        with self.connection() as conn:
            active_row = conn.execute(
                "SELECT value FROM app_state WHERE key = 'active_profile_id'"
            ).fetchone()
            active_id = active_row["value"] if active_row else None
            conn.execute("DELETE FROM model_profiles WHERE id = ?", (profile_id,))
            if active_id and int(active_id) == profile_id:
                conn.execute("DELETE FROM app_state WHERE key = 'active_profile_id'")

    def get_app_state(self, key: str) -> str | None:
        with self.connection() as conn:
            row = conn.execute("SELECT value FROM app_state WHERE key = ?", (key,)).fetchone()
        return row["value"] if row else None

    def set_app_state(self, key: str, value: str) -> None:
        with self.connection() as conn:
            conn.execute(
                """
                INSERT INTO app_state (key, value)
                VALUES (?, ?)
                ON CONFLICT(key) DO UPDATE SET value = excluded.value
                """,
                (key, value),
            )

    def get_active_profile(self) -> dict | None:
        active_id = self.get_app_state("active_profile_id")
        if not active_id:
            return None
        return self.get_profile(int(active_id))

    def set_active_profile(self, profile_id: int) -> None:
        self.set_app_state("active_profile_id", str(profile_id))

    def timeseries(self, bucket: str, since: str | None = None) -> list[dict]:
        format_map = {
            "hour": "%Y-%m-%dT%H:00:00",
            "day": "%Y-%m-%dT00:00:00",
            "minute": "%Y-%m-%dT%H:%M:00",
        }
        if bucket not in format_map:
            raise ValueError("bucket must be one of: minute, hour, day")
        sql = f"""
            SELECT
                strftime('{format_map[bucket]}', received_at) AS bucket_start,
                provider,
                upstream_model,
                COUNT(*) AS requests,
                SUM(prompt_tokens) AS prompt_tokens,
                SUM(completion_tokens) AS completion_tokens,
                SUM(total_tokens) AS total_tokens
            FROM request_log
            {"WHERE received_at >= ?" if since else ""}
            GROUP BY bucket_start, provider, upstream_model
            ORDER BY bucket_start DESC
        """
        params = (since,) if since else ()
        with self.connection() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [dict(row) for row in rows]

    @staticmethod
    def _deserialize_row(row: sqlite3.Row) -> dict:
        record = dict(row)
        record["success"] = bool(record["success"])
        record["request_body"] = json.loads(record["request_body"])
        record["response_body"] = json.loads(record["response_body"])
        return record

    @staticmethod
    def _deserialize_auth_row(row: sqlite3.Row) -> dict:
        record = dict(row)
        record["secrets"] = json.loads(record.pop("secrets_json"))
        return record
