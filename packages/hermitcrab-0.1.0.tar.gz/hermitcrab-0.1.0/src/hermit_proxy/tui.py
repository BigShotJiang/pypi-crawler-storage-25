from __future__ import annotations

import curses
import logging
import textwrap
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any
import asyncio

from hermit_proxy import service_manager as _svc
from hermit_proxy.config import Settings, get_settings
from hermit_proxy.profile_test import ProfileTester
from hermit_proxy.profiles import ProfileManager
from hermit_proxy.storage import TrafficStore
from hermit_proxy.upstream import UpstreamClient


class _TUILogHandler(logging.Handler):
    """Redirect all log records into the TUI log panel instead of stderr."""

    def __init__(self, log_fn: Any) -> None:
        super().__init__()
        self._log_fn = log_fn

    def emit(self, record: logging.LogRecord) -> None:
        try:
            self._log_fn(f"[{record.levelname}] {record.getMessage()}")
        except Exception:
            pass


class ChatWindow:
    """In-TUI scrollable multi-turn chat panel.  Esc to close."""

    def __init__(self, stdscr: curses.window, title: str, send_fn: Any) -> None:
        self.stdscr = stdscr
        self.title = title
        self.send_fn = send_fn          # send_fn(messages: list[dict]) -> str
        self.messages: list[dict] = []
        self.scroll = 0
        self.input_buf: list[str] = []
        self.status = ""

    def _display_lines(self, width: int) -> list[tuple[int, str]]:
        """Return (curses_attr, text) pairs for all messages, word-wrapped."""
        lines: list[tuple[int, str]] = []
        for msg in self.messages:
            if msg["role"] == "user":
                prefix = "You: "
                attr = curses.A_BOLD
            else:
                prefix = "AI:  "
                attr = 0
            content = msg["content"]
            avail = max(1, width - len(prefix))
            wrapped = textwrap.wrap(content, avail) if content.strip() else [""]
            lines.append((attr, prefix + wrapped[0]))
            for part in wrapped[1:]:
                lines.append((attr, " " * len(prefix) + part))
            lines.append((0, ""))   # blank separator between turns
        return lines

    def run(self) -> None:
        curses.curs_set(1)
        while True:
            h, w = self.stdscr.getmaxyx()
            inner_w = max(1, w - 4)
            # Layout:  row 0 border, rows 1..(h-5) content, row h-4 separator, row h-3 input, row h-2 status, row h-1 border
            content_h = max(1, h - 5)

            win = curses.newwin(h, w, 0, 0)
            win.keypad(True)
            win.border()

            # Title centred on top border
            title_str = f" {self.title} "
            title_col = max(2, (w - len(title_str)) // 2)
            try:
                win.addnstr(0, title_col, title_str, w - title_col - 2, curses.A_BOLD)
                win.addnstr(0, w - 14, " Esc = close ", 13)
            except curses.error:
                pass

            # Content area
            all_lines = self._display_lines(inner_w)
            total = len(all_lines)
            max_scroll = max(0, total - content_h)
            self.scroll = min(self.scroll, max_scroll)

            for i in range(content_h):
                idx = self.scroll + i
                if idx >= total:
                    break
                attr, text = all_lines[idx]
                try:
                    win.addnstr(1 + i, 2, text, inner_w, attr)
                except curses.error:
                    pass

            # Scroll indicator (top-right of content area)
            if total > content_h:
                indicator = f" {self.scroll + 1}-{min(self.scroll + content_h, total)}/{total} "
                try:
                    win.addnstr(1, w - len(indicator) - 2, indicator, len(indicator))
                except curses.error:
                    pass

            # Separator
            try:
                win.addnstr(h - 4, 1, "─" * (w - 2), w - 2)
            except curses.error:
                pass

            # Input line
            input_str = "".join(self.input_buf)
            prompt = "> "
            display_input = (prompt + input_str)[: inner_w]
            try:
                win.addnstr(h - 3, 2, display_input, inner_w)
            except curses.error:
                pass

            # Status / hint line
            hint = self.status if self.status else "Enter = send  ↑↓ = scroll"
            try:
                win.addnstr(h - 2, 2, hint[:inner_w], inner_w)
            except curses.error:
                pass

            # Cursor in input
            cursor_col = min(2 + len(prompt) + len(input_str), w - 2)
            try:
                win.move(h - 3, cursor_col)
            except curses.error:
                pass

            win.refresh()
            key = win.getch()

            if key == 27:   # Esc
                break
            elif key == curses.KEY_UP:
                self.scroll = max(0, self.scroll - 1)
            elif key == curses.KEY_DOWN:
                self.scroll = min(max_scroll, self.scroll + 1)
            elif key in (curses.KEY_BACKSPACE, 127, 8):
                if self.input_buf:
                    self.input_buf.pop()
            elif key in (10, 13):
                text = "".join(self.input_buf).strip()
                if not text:
                    continue
                self.messages.append({"role": "user", "content": text})
                self.input_buf.clear()
                self.status = "Waiting for response..."
                # Show waiting status immediately before blocking call
                try:
                    win.addnstr(h - 2, 2, self.status[:inner_w], inner_w)
                    win.refresh()
                except curses.error:
                    pass
                try:
                    response = self.send_fn(list(self.messages))
                    self.messages.append({"role": "assistant", "content": response})
                except Exception as exc:
                    self.messages.append({"role": "assistant", "content": f"[error] {exc}"})
                self.status = ""
                # Auto-scroll to bottom
                new_lines = self._display_lines(inner_w)
                self.scroll = max(0, len(new_lines) - content_h)
            elif 32 <= key <= 126:
                self.input_buf.append(chr(key))

        # Restore main TUI
        curses.curs_set(0)
        self.stdscr.touchwin()
        self.stdscr.refresh()


# (provider_id, display_label, default_base_url, api_key_hint)
# api_key_hint: "required" | "optional" | "none"
PROVIDER_MENU: list[tuple[str, str, str, str]] = [
    ("ollama",           "Ollama (local)",              "http://localhost:11434/v1",                          "none"),
    ("vllm",             "vLLM (local)",                "http://localhost:8000/v1",                           "none"),
    ("lmstudio",         "LM Studio (local)",           "http://localhost:1234/v1",                           "none"),
    ("openai",           "OpenAI",                      "https://api.openai.com/v1",                          "required"),
    ("openrouter",       "OpenRouter",                  "https://openrouter.ai/api/v1",                       "required"),
    ("deepseek",         "DeepSeek",                    "https://api.deepseek.com/v1",                        "required"),
    ("google-gemini",    "Google Gemini",               "https://generativelanguage.googleapis.com/v1beta/openai", "required"),
    ("xai-grok",         "xAI Grok",                    "https://api.x.ai/v1",                                "required"),
    ("alibaba-qwen",     "Alibaba Qwen (DashScope)",    "https://dashscope.aliyuncs.com/compatible-mode/v1",  "required"),
    ("nvidia",           "NVIDIA NIM",                  "https://integrate.api.nvidia.com/v1",                "required"),
    ("huggingface",      "HuggingFace Router",          "https://router.huggingface.co/v1",                   "required"),
    ("minimax",          "MiniMax",                     "https://api.minimax.io/v1",                          "required"),
    ("glm",              "GLM / Zhipu",                 "https://api.z.ai/api/paas/v4",                       "required"),
    ("github-models",    "GitHub Models",               "https://models.github.ai",                           "required"),
    ("openai-compatible","Custom OpenAI-compatible",    "",                                                   "optional"),
]


@dataclass
class ProfileForm:
    name: str = ""
    provider: str = ""
    base_url: str = ""
    api_key: str = ""
    model: str = ""
    auth_profile_id: str = ""
    default_max_tokens: str = ""
    allow_client_model_override: bool = False
    activate: bool = True


_LOG_LINES = 3   # visible log lines in the log panel


class HermitTUI:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.store = TrafficStore(settings.database_url)
        self.profiles = ProfileManager(settings, self.store)
        self.tester = ProfileTester(settings, self.store, UpstreamClient(settings.request_timeout_seconds))
        self.focus = "profiles"
        self.profile_index = 0
        self.analytics_index = 0
        self._log: list[str] = []

    def log_append(self, msg: str) -> None:
        from datetime import datetime
        ts = datetime.now().strftime("%H:%M:%S")
        self._log.append(f"{ts}  {msg}")
        if len(self._log) > 200:
            self._log = self._log[-200:]

    def run(self, stdscr: curses.window) -> None:
        curses.curs_set(0)
        stdscr.keypad(True)
        self.profiles.ensure_bootstrap_profile()
        # Capture all logging output into the TUI log panel
        handler = _TUILogHandler(self.log_append)
        handler.setLevel(logging.DEBUG)
        root_logger = logging.getLogger()
        root_logger.addHandler(handler)
        try:
            while True:
                self.render(stdscr)
                key = stdscr.getch()
                if key in (ord("q"), 27):
                    return
                self.handle_key(stdscr, key)
        finally:
            root_logger.removeHandler(handler)

    def _get_server_config(self) -> tuple[str, int, str]:
        host = self.store.get_app_state("server_host") or "127.0.0.1"
        port = int(self.store.get_app_state("server_port") or 14415)
        log_level = self.store.get_app_state("log_level") or "INFO"
        return host, port, log_level

    def handle_key(self, stdscr: curses.window, key: int) -> None:
        profiles = self.store.list_profiles()
        by_model = self.store.summary_by_profile()

        if key == 9:
            self.focus = "analytics" if self.focus == "profiles" else "profiles"
            return
        if key in (curses.KEY_UP, ord("k")):
            if self.focus == "profiles" and profiles:
                self.profile_index = max(0, self.profile_index - 1)
            if self.focus == "analytics" and by_model:
                self.analytics_index = max(0, self.analytics_index - 1)
            return
        if key in (curses.KEY_DOWN, ord("j")):
            if self.focus == "profiles" and profiles:
                self.profile_index = min(len(profiles) - 1, self.profile_index + 1)
            if self.focus == "analytics" and by_model:
                self.analytics_index = min(len(by_model) - 1, self.analytics_index + 1)
            return
        if key in (10, 13) and self.focus == "profiles" and profiles:
            profile = profiles[self.profile_index]
            provider_config = self.profiles.provider_config_from_values(
                name=str(profile["name"]),
                provider=str(profile["provider"]),
                base_url=str(profile["base_url"]),
                api_key=str(profile["api_key"]),
                auth_profile_id=profile.get("auth_profile_id"),
                model=str(profile["model"]),
                allow_client_model_override=bool(profile.get("allow_client_model_override")),
            )
            result = asyncio.run(self.tester.quick_test(provider_config))
            if not result.ok:
                self.log_append(f"Activation blocked: {result.message}")
                return
            self.store.set_active_profile(int(profile["id"]))
            self.log_append(f"Activated profile {profile['name']} ({result.latency_ms} ms)")
            return
        if key == ord("a"):
            form = self.prompt_add_profile_guided(stdscr)
            if form:
                provider_config = self.profiles.provider_config_from_values(**profile_form_to_payload(form))
                result = asyncio.run(self.tester.quick_test(provider_config))
                if not result.ok:
                    self.log_append(f"Save blocked: {result.message}")
                    return
                profile_id = self.profiles.save_profile(**profile_form_to_payload(form))
                self.profile_index = 0
                self.log_append(f"Saved profile #{profile_id} ({result.latency_ms} ms)")
            return
        if key == ord("e") and self.focus == "profiles" and profiles:
            profile = profiles[self.profile_index]
            form = ProfileForm(
                name=str(profile["name"]),
                provider=str(profile["provider"]),
                base_url=str(profile["base_url"]),
                api_key=str(profile["api_key"]),
                model=str(profile["model"]),
                auth_profile_id="" if profile.get("auth_profile_id") is None else str(profile.get("auth_profile_id")),
                default_max_tokens="" if profile.get("default_max_tokens") is None else str(profile.get("default_max_tokens")),
                allow_client_model_override=bool(profile.get("allow_client_model_override")),
                activate=int(profile["id"]) == int(self.store.get_app_state("active_profile_id") or 0),
            )
            updated = self.prompt_profile(stdscr, form, title=f"Edit profile #{profile['id']}")
            if updated:
                provider_config = self.profiles.provider_config_from_values(**profile_form_to_payload(updated))
                result = asyncio.run(self.tester.quick_test(provider_config))
                if not result.ok:
                    self.log_append(f"Update blocked: {result.message}")
                    return
                self.profiles.save_profile(profile_id=int(profile["id"]), **profile_form_to_payload(updated))
                self.log_append(f"Updated profile {updated.name} ({result.latency_ms} ms)")
            return
        if key == ord("d") and self.focus == "profiles" and profiles:
            profile = profiles[self.profile_index]
            if self.confirm(stdscr, f"Delete profile {profile['name']}?"):
                self.store.delete_profile(int(profile["id"]))
                self.profile_index = max(0, self.profile_index - 1)
                self.profiles.ensure_bootstrap_profile()
                self.log_append(f"Deleted profile {profile['name']}")
            return
        if key == ord("r"):
            self.profiles.ensure_bootstrap_profile()
            self.log_append("Refreshed")
            return
        if key == ord("s"):
            self.prompt_server_config(stdscr)
            return
        if key == ord("t") and self.focus == "profiles" and profiles:
            profile = profiles[self.profile_index]
            provider_config = self.profiles.provider_config_from_values(
                name=str(profile["name"]),
                provider=str(profile["provider"]),
                base_url=str(profile["base_url"]),
                api_key=str(profile["api_key"]),
                auth_profile_id=profile.get("auth_profile_id"),
                model=str(profile["model"]),
                allow_client_model_override=bool(profile.get("allow_client_model_override")),
            )
            client = UpstreamClient(self.settings.request_timeout_seconds)

            def _upstream_send(messages: list[dict], _cfg=provider_config, _cli=client) -> str:
                payload = {"model": _cfg.model, "messages": messages}
                status, data = asyncio.run(_cli.chat_completions(_cfg, payload))
                if status != 200:
                    import json as _j
                    detail = _extract_error_msg(_j.dumps(data))
                    raise RuntimeError(f"HTTP {status}: {detail}")
                if "error" in data:
                    msg = (data["error"] or {}).get("message") or str(data["error"])
                    raise RuntimeError(f"Upstream error: {msg}")
                return data["choices"][0]["message"]["content"]

            title = f"Upstream: {profile['provider']} / {profile['model']}"
            ChatWindow(stdscr, title, _upstream_send).run()
            return
        if key == ord("p"):
            host, port, _ = self._get_server_config()
            active = self.store.get_active_profile()
            active_label = active["name"] if active else "active profile"
            active_model = active["model"] if active else "default"

            def _proxy_send(messages: list[dict], _h=host, _p=port, _m=active_model) -> str:
                import json as _json
                import urllib.error as _ue
                url = f"http://{_h}:{_p}/v1/chat/completions"
                payload = _json.dumps({"model": _m, "messages": messages}).encode()
                req = urllib.request.Request(
                    url, data=payload, headers={"Content-Type": "application/json"}
                )
                try:
                    with urllib.request.urlopen(req, timeout=60) as resp:
                        data = _json.loads(resp.read())
                except _ue.HTTPError as e:
                    body = e.read().decode("utf-8", errors="replace")
                    msg = _extract_error_msg(body)
                    raise RuntimeError(f"HTTP {e.code} from proxy: {msg}")
                if "error" in data:
                    msg = (data["error"] or {}).get("message") or str(data["error"])
                    raise RuntimeError(f"Upstream error: {msg}")
                return data["choices"][0]["message"]["content"]

            title = f"Proxy: {host}:{port} → {active_label}"
            ChatWindow(stdscr, title, _proxy_send).run()
            return
        if key == ord("i"):
            if self.confirm(stdscr, "Install user-level systemd service?"):
                ok, msg = _svc.install(user_service=True)
                self.log_append(msg)
            return
        if key == ord("R"):
            ok, msg = _svc.restart(user_service=True)
            self.log_append(msg)
            return
        if key == ord("X"):
            if self.confirm(stdscr, "Uninstall hermitcrab systemd service?"):
                ok, msg = _svc.uninstall(user_service=True)
                self.log_append(msg)
            return

    def render(self, stdscr: curses.window) -> None:
        stdscr.clear()   # full physical repaint, clears any stray terminal writes
        height, width = stdscr.getmaxyx()
        profiles = self.store.list_profiles()
        active_id = int(self.store.get_app_state("active_profile_id") or 0)
        summary = self.store.summary()
        by_model = self.store.summary_by_profile()
        recent = self.store.recent_requests(limit=8)
        timeseries = self.store.timeseries(bucket="hour")[:8]

        self.draw_header(stdscr, width, summary)

        # Row layout (bottom-up):
        #   height-2  footer
        #   height-3..(height-2-_LOG_LINES)  log lines
        #   height-3-_LOG_LINES              log separator
        #   3..(height-4-_LOG_LINES)         panes
        footer_row = height - 2
        log_sep_row = footer_row - _LOG_LINES - 1
        pane_h = log_sep_row - 2   # pane entries end one row above separator

        split = max(42, width // 2)
        self.draw_profiles(stdscr, 3, 0, pane_h, split, profiles, active_id)
        self.draw_analytics(stdscr, 3, split, pane_h, width - split, by_model, recent, timeseries)
        self.draw_log(stdscr, log_sep_row, width)

        footer = "Tab:switch  Enter:activate  a:add  e:edit  d:del  t:test-upstream  p:ping-proxy  s:server-cfg  i:install-svc  R:restart  X:uninstall  r:refresh  q:quit"
        stdscr.addnstr(footer_row, 1, footer, max(0, width - 2))
        stdscr.refresh()

    def draw_log(self, stdscr: curses.window, sep_row: int, width: int) -> None:
        sep = "─ Log " + "─" * max(0, width - 7)
        try:
            stdscr.addnstr(sep_row, 0, sep, width)
        except curses.error:
            pass
        visible = self._log[-_LOG_LINES:]
        for i, line in enumerate(visible):
            try:
                stdscr.addnstr(sep_row + 1 + i, 1, line, max(0, width - 2))
            except curses.error:
                pass

    def draw_header(self, stdscr: curses.window, width: int, summary: dict[str, Any]) -> None:
        host, port, log_level = self._get_server_config()
        svc_state = _svc.service_state(user_service=True)
        title = f"Hermit Proxy TUI  [{host}:{port}  log={log_level}  svc={svc_state}]"
        stats = (
            f"requests={summary.get('requests', 0)} "
            f"prompt={summary.get('prompt_tokens', 0)} "
            f"completion={summary.get('completion_tokens', 0)} "
            f"total={summary.get('total_tokens', 0)} "
            f"avg_ms={int(summary.get('avg_latency_ms', 0) or 0)}"
        )
        stdscr.addnstr(0, 1, title, max(0, width - 2), curses.A_BOLD)
        stdscr.addnstr(1, 1, stats, max(0, width - 2))

    def draw_profiles(
        self,
        stdscr: curses.window,
        top: int,
        left: int,
        height: int,
        width: int,
        profiles: list[dict],
        active_id: int,
    ) -> None:
        title_attr = curses.A_REVERSE if self.focus == "profiles" else curses.A_BOLD
        stdscr.addnstr(top, left + 1, "Profiles", max(0, width - 2), title_attr)
        line = top + 1
        visible = max(1, height - 2)
        start = min(self.profile_index, max(0, len(profiles) - visible))
        for idx, profile in enumerate(profiles[start : start + visible]):
            absolute_idx = start + idx
            marker = "*" if int(profile["id"]) == active_id else " "
            api_key = mask_secret(str(profile["api_key"]))
            text = (
                f"{marker} [{profile['id']}] {profile['name']} | {profile['provider']} | "
                f"{profile['model']} | compat={bool(profile.get('allow_client_model_override'))} "
                f"| max={profile.get('default_max_tokens') or '-'} | auth={profile.get('auth_profile_id') or '-'} | {api_key}"
            )
            attr = curses.A_STANDOUT if absolute_idx == self.profile_index and self.focus == "profiles" else 0
            stdscr.addnstr(line + idx, left + 1, text, max(0, width - 2), attr)

    def draw_analytics(
        self,
        stdscr: curses.window,
        top: int,
        left: int,
        height: int,
        width: int,
        by_model: list[dict],
        recent: list[dict],
        timeseries: list[dict],
    ) -> None:
        title_attr = curses.A_REVERSE if self.focus == "analytics" else curses.A_BOLD
        stdscr.addnstr(top, left + 1, "Analytics", max(0, width - 2), title_attr)

        line = top + 1
        stdscr.addnstr(line, left + 1, "By model", max(0, width - 2), curses.A_UNDERLINE)
        line += 1
        limit = max(1, min(6, height // 3))
        start = min(self.analytics_index, max(0, len(by_model) - limit))
        for idx, item in enumerate(by_model[start : start + limit]):
            absolute_idx = start + idx
            text = (
                f"{item['provider']}/{item['upstream_model']} "
                f"req={item['requests']} total={item['total_tokens']}"
            )
            attr = curses.A_STANDOUT if absolute_idx == self.analytics_index and self.focus == "analytics" else 0
            stdscr.addnstr(line + idx, left + 1, text, max(0, width - 2), attr)
        line += limit + 1

        stdscr.addnstr(line, left + 1, "Hourly traffic", max(0, width - 2), curses.A_UNDERLINE)
        line += 1
        for item in timeseries[:3]:
            text = (
                f"{item['bucket_start']} {item['provider']}/{item['upstream_model']} "
                f"req={item['requests']} total={item['total_tokens']}"
            )
            stdscr.addnstr(line, left + 1, text, max(0, width - 2))
            line += 1

        line += 1
        stdscr.addnstr(line, left + 1, "Recent requests", max(0, width - 2), curses.A_UNDERLINE)
        line += 1
        for item in recent[:3]:
            status = item.get("status_code") or "-"
            text = (
                f"{item['received_at']} {item['provider']}/{item['upstream_model']} "
                f"status={status} total={item['total_tokens']}"
            )
            stdscr.addnstr(line, left + 1, text, max(0, width - 2))
            line += 1

    # ------------------------------------------------------------------ #
    #  Generic selection widget                                           #
    # ------------------------------------------------------------------ #

    def prompt_select(
        self,
        stdscr: curses.window,
        title: str,
        items: list[str],
        hint: str = "↑↓ navigate  Enter select  Esc cancel",
        selected: int = 0,
    ) -> int | None:
        """Floating scrollable selection menu. Returns chosen index or None."""
        if not items:
            return None
        curses.curs_set(0)
        H, W = stdscr.getmaxyx()
        inner_w = max(40, min(W - 6, max((len(s) for s in items), default=20) + 6))
        inner_h = min(len(items) + 4, H - 4)
        top  = max(0, (H - inner_h) // 2)
        left = max(0, (W - inner_w) // 2)

        cur    = max(0, min(selected, len(items) - 1))
        scroll = 0
        visible = inner_h - 3   # title row + top/bottom border

        while True:
            win = curses.newwin(inner_h, inner_w, top, left)
            win.keypad(True)
            win.border()
            title_str = f" {title} "
            try:
                win.addnstr(0, max(1, (inner_w - len(title_str)) // 2), title_str,
                             inner_w - 2, curses.A_BOLD)
                win.addnstr(inner_h - 1, 2, hint[:inner_w - 4], inner_w - 4)
            except curses.error:
                pass

            # adjust scroll window
            if cur < scroll:
                scroll = cur
            elif cur >= scroll + visible:
                scroll = cur - visible + 1

            for i in range(visible):
                idx = scroll + i
                if idx >= len(items):
                    break
                attr = curses.A_STANDOUT if idx == cur else 0
                try:
                    win.addnstr(1 + i, 2, items[idx][:inner_w - 4], inner_w - 4, attr)
                except curses.error:
                    pass

            # scroll indicator
            if len(items) > visible:
                ind = f" {cur + 1}/{len(items)} "
                try:
                    win.addnstr(inner_h - 1, inner_w - len(ind) - 2, ind, len(ind))
                except curses.error:
                    pass

            win.refresh()
            key = win.getch()

            if key == 27:
                return None
            if key in (curses.KEY_UP, ord("k")):
                cur = max(0, cur - 1)
            elif key in (curses.KEY_DOWN, ord("j")):
                cur = min(len(items) - 1, cur + 1)
            elif key in (10, 13):
                return cur

    # ------------------------------------------------------------------ #
    #  Guided add-profile flow                                            #
    # ------------------------------------------------------------------ #

    def prompt_add_profile_guided(self, stdscr: curses.window) -> ProfileForm | None:
        """Multi-step guided profile creation with provider menu + model fetch."""
        curses.curs_set(1)

        # ── Step 1: choose provider ──────────────────────────────────────
        provider_labels = [
            f"{label}  ({hint})"
            for _, label, _, hint in PROVIDER_MENU
        ]
        idx = self.prompt_select(stdscr, "Step 1/4 – Select Provider", provider_labels)
        if idx is None:
            return None
        provider_id, provider_label, default_base_url, key_hint = PROVIDER_MENU[idx]

        # ── Step 2: API key ──────────────────────────────────────────────
        if key_hint == "none":
            api_key = ""
        else:
            # Collect existing profiles for this provider that have a key set
            existing = [
                p for p in self.store.list_profiles()
                if str(p["provider"]) == provider_id and str(p.get("api_key") or "")
            ]
            if existing:
                NEW_KEY = "[Enter new key]"
                key_items = [
                    f"Use key from '{p['name']}'  ({mask_secret(str(p['api_key']))})"
                    for p in existing
                ] + [NEW_KEY]
                key_sel = self.prompt_select(
                    stdscr,
                    f"Step 2/4 – API Key for {provider_label}",
                    key_items,
                    hint="Reuse an existing key or enter a new one  |  Enter select  Esc cancel",
                )
                if key_sel is None:
                    return None
                if key_items[key_sel] == NEW_KEY:
                    hint_text = "required" if key_hint == "required" else "optional – blank to skip"
                    api_key_raw = self.prompt_input(
                        stdscr, f"Step 2/4 – New API key ({hint_text}): ", secret=True,
                    )
                    if api_key_raw is None:
                        return None
                    api_key = api_key_raw.strip()
                else:
                    api_key = str(existing[key_sel]["api_key"])
            else:
                hint_text = "required" if key_hint == "required" else "optional – blank to skip"
                api_key_raw = self.prompt_input(
                    stdscr, f"Step 2/4 – API key for {provider_label} ({hint_text}): ",
                    secret=True,
                )
                if api_key_raw is None:
                    return None
                api_key = api_key_raw.strip()

        # ── Step 3: base URL (custom only, or allow override) ────────────
        if provider_id == "openai-compatible":
            url_raw = self.prompt_input(
                stdscr, "Step 3/4 – Base URL (e.g. http://localhost:4000/v1): "
            )
            if url_raw is None:
                return None
            base_url = url_raw.strip() or "http://localhost:8000/v1"
        else:
            base_url = default_base_url

        # ── Step 4: fetch models + select ────────────────────────────────
        model = self._guided_pick_model(stdscr, provider_id, base_url, api_key)
        if model is None:
            return None

        # ── Step 5: profile name ─────────────────────────────────────────
        slug = model.split("/")[-1].replace(":", "-")[:32]
        suggested = f"{provider_id}-{slug}"
        name_raw = self.prompt_input(stdscr, f"Profile name [{suggested}]: ")
        if name_raw is None:
            return None
        name = name_raw.strip() or suggested

        # ── Step 6: options ───────────────────────────────────────────────
        act_raw = self.prompt_input(stdscr, "Activate now? [Y/n]: ")
        if act_raw is None:
            return None
        activate = not act_raw.strip().lower().startswith("n")

        compat_raw = self.prompt_input(stdscr, "Allow client model override? [y/N]: ")
        if compat_raw is None:
            return None
        allow_override = compat_raw.strip().lower().startswith("y")

        maxtok_raw = self.prompt_input(stdscr, "Default max tokens (blank=unlimited): ")
        if maxtok_raw is None:
            return None

        return ProfileForm(
            name=name,
            provider=provider_id,
            base_url=base_url,
            api_key=api_key,
            model=model,
            default_max_tokens=maxtok_raw.strip(),
            allow_client_model_override=allow_override,
            activate=activate,
        )

    def _guided_pick_model(
        self,
        stdscr: curses.window,
        provider_id: str,
        base_url: str,
        api_key: str,
    ) -> str | None:
        """Fetch model list from upstream and let user pick. Returns model id or None."""
        from hermit_proxy.config import ProviderConfig

        while True:
            # Show "fetching…" status
            H, W = stdscr.getmaxyx()
            try:
                stdscr.addnstr(H // 2, 2, f"Step 4/4 – Fetching models from {base_url} …".ljust(W - 4), W - 4)
                stdscr.refresh()
            except curses.error:
                pass

            models: list[str] = []
            fetch_error = ""
            try:
                from hermit_proxy.upstream import UpstreamClient
                cfg = ProviderConfig(
                    name=provider_id,
                    base_url=base_url.rstrip("/"),
                    api_key=api_key,
                    model="",
                )
                status, data = asyncio.run(
                    UpstreamClient(self.settings.request_timeout_seconds).models(cfg)
                )
                if status == 200:
                    raw = data.get("data") or data.get("models") or []
                    for entry in raw:
                        mid = entry.get("id") or entry.get("name") or str(entry)
                        if mid:
                            models.append(mid)
                    models.sort()
                else:
                    fetch_error = f"HTTP {status}: {data.get('error', {}).get('message', str(data)[:80])}"
            except Exception as exc:
                fetch_error = str(exc)[:120]

            MANUAL = "[Enter model name manually]"
            FIX_URL = "[Fix base URL and retry]"

            if models:
                items = models + [MANUAL]
                sel = self.prompt_select(
                    stdscr,
                    f"Step 4/4 – Select Model  ({provider_id})",
                    items,
                )
                if sel is None:
                    return None
                if items[sel] == MANUAL:
                    return self._prompt_model_manual(stdscr)
                return items[sel]

            # Fetch failed
            self.log_append(f"Model fetch failed: {fetch_error}")
            items = [FIX_URL, MANUAL, "[Cancel]"]
            sel = self.prompt_select(
                stdscr,
                f"Step 4/4 – Model fetch failed",
                items,
                hint=fetch_error[:60] + "  |  Enter select  Esc cancel",
            )
            if sel is None or items[sel] == "[Cancel]":
                return None
            if items[sel] == MANUAL:
                return self._prompt_model_manual(stdscr)
            # FIX_URL
            new_url = self.prompt_input(stdscr, f"Fix base URL [{base_url}]: ")
            if new_url is None:
                return None
            if new_url.strip():
                base_url = new_url.strip()
            # loop back and retry

    def _prompt_model_manual(self, stdscr: curses.window) -> str | None:
        val = self.prompt_input(stdscr, "Model name: ")
        if val is None:
            return None
        return val.strip() or None

    def prompt_server_config(self, stdscr: curses.window) -> None:
        curses.curs_set(1)
        host, port, log_level = self._get_server_config()

        new_host = self.prompt_input(stdscr, f"Server config | Bind host [{host}]: ")
        if new_host is None:
            curses.curs_set(0)
            return
        if new_host.strip():
            host = new_host.strip()

        new_port = self.prompt_input(stdscr, f"Server config | TCP port [{port}]: ")
        if new_port is None:
            curses.curs_set(0)
            return
        if new_port.strip():
            try:
                p = int(new_port.strip())
                if not (1 <= p <= 65535):
                    raise ValueError
                port = p
            except ValueError:
                self.log_append("Invalid port — must be 1-65535")
                curses.curs_set(0)
                return

        new_level = self.prompt_input(stdscr, f"Server config | Log level [{log_level}]: ")
        if new_level is None:
            curses.curs_set(0)
            return
        if new_level.strip():
            level = new_level.strip().upper()
            valid = {"CRITICAL", "ERROR", "WARNING", "INFO", "DEBUG"}
            if level not in valid:
                self.log_append(f"Invalid log level — must be one of: {', '.join(sorted(valid))}")
                curses.curs_set(0)
                return
            log_level = level

        self.store.set_app_state("server_host", host)
        self.store.set_app_state("server_port", str(port))
        self.store.set_app_state("log_level", log_level)
        self.log_append(f"Server config saved: {host}:{port}  log={log_level}  (restart to apply)")
        curses.curs_set(0)

    def prompt_profile(self, stdscr: curses.window, form: ProfileForm, title: str) -> ProfileForm | None:
        curses.curs_set(1)
        fields = [
            ("name", "Profile name"),
            ("provider", "Provider"),
            ("base_url", "Base URL"),
            ("api_key", "API key"),
            ("model", "Model"),
            ("auth_profile_id", "Auth profile id"),
            ("default_max_tokens", "Default max tokens"),
        ]
        values = form.__dict__.copy()

        for key, label in fields:
            current = str(values[key])
            prompt = f"{title} | {label} [{current}]: "
            response = self.prompt_input(stdscr, prompt, secret=(key == "api_key"))
            if response is None:
                curses.curs_set(0)
                return None
            if response != "":
                values[key] = response

        activate_default = "y" if bool(values["activate"]) else "n"
        activate = self.prompt_input(stdscr, f"{title} | Activate now? [y/n] [{activate_default}]: ")
        if activate is None:
            curses.curs_set(0)
            return None
        if activate.strip():
            values["activate"] = activate.strip().lower().startswith("y")

        compat_default = "y" if bool(values["allow_client_model_override"]) else "n"
        compat = self.prompt_input(
            stdscr,
            f"{title} | Allow client model override? [y/n] [{compat_default}]: ",
        )
        if compat is None:
            curses.curs_set(0)
            return None
        if compat.strip():
            values["allow_client_model_override"] = compat.strip().lower().startswith("y")

        curses.curs_set(0)
        values["auth_profile_id"] = values["auth_profile_id"].strip()
        values["default_max_tokens"] = values["default_max_tokens"].strip()
        return ProfileForm(**values)

    def prompt_input(self, stdscr: curses.window, prompt: str, secret: bool = False) -> str | None:
        height, width = stdscr.getmaxyx()
        win_height = 5
        lines = textwrap.wrap(prompt, width - 6) or [prompt]
        box = curses.newwin(win_height + len(lines), width - 4, max(0, height // 2 - 3), 2)
        box.keypad(True)
        box.border()
        for idx, line in enumerate(lines):
            box.addnstr(1 + idx, 2, line, max(0, width - 8))
        box.refresh()

        buffer: list[str] = []
        while True:
            display = "*" * len(buffer) if secret else "".join(buffer)
            box.addnstr(len(lines) + 2, 2, " " * (width - 8), max(0, width - 8))
            box.addnstr(len(lines) + 2, 2, display, max(0, width - 8))
            box.refresh()
            key = box.getch()
            if key in (10, 13):
                return "".join(buffer)
            if key == 27:
                return None
            if key in (curses.KEY_BACKSPACE, 127, 8):
                if buffer:
                    buffer.pop()
                continue
            if 32 <= key <= 126:
                buffer.append(chr(key))

    def confirm(self, stdscr: curses.window, message: str) -> bool:
        answer = self.prompt_input(stdscr, f"{message} [y/N]: ")
        return bool(answer and answer.strip().lower() == "y")


def mask_secret(value: str) -> str:
    if not value:
        return "(empty)"
    if len(value) <= 8:
        return "*" * len(value)
    return f"{value[:4]}...{value[-4:]}"


def _extract_error_msg(body: str) -> str:
    """Extract human-readable error from proxy/upstream JSON response body."""
    import json as _j
    try:
        err = _j.loads(body)
    except Exception:
        return body[:300]
    # Hermitcrab proxy format: {"detail": {"error": {"message": "..."}}}
    detail = err.get("detail")
    if isinstance(detail, dict):
        msg = (detail.get("error") or {}).get("message")
        if msg:
            return str(msg)
        return str(detail)[:200]
    # FastAPI string detail: {"detail": "some error string"}
    if isinstance(detail, str):
        return detail[:200]
    # FastAPI list detail: [{"msg": "...", "loc": [...]}]
    if isinstance(detail, list) and detail:
        return str(detail[0].get("msg", detail[0]))[:200]
    # OpenAI format: {"error": {"message": "..."}}
    error = err.get("error")
    if isinstance(error, dict):
        return str(error.get("message", error))[:200]
    return body[:300]


def profile_form_to_payload(form: ProfileForm) -> dict[str, Any]:
    auth_profile_id = form.auth_profile_id.strip()
    default_max_tokens = form.default_max_tokens.strip()
    return {
        "name": form.name,
        "provider": form.provider,
        "base_url": form.base_url,
        "api_key": form.api_key,
        "model": form.model,
        "auth_profile_id": int(auth_profile_id) if auth_profile_id else None,
        "default_max_tokens": int(default_max_tokens) if default_max_tokens else None,
        "allow_client_model_override": form.allow_client_model_override,
        "activate": form.activate,
    }


def run_tui() -> None:
    settings = get_settings()
    curses.wrapper(HermitTUI(settings).run)
