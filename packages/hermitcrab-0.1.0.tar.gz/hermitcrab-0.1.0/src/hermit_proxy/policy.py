from __future__ import annotations

from urllib.parse import urlparse

from hermit_proxy.config import ProviderConfig


class ProviderPolicy:
    TOKEN_LIMIT_FIELD_BY_PROVIDER = {
        "anthropic": "max_completion_tokens",
        "openai": "max_completion_tokens",
        "openai-codex": "max_completion_tokens",
        "openrouter": "max_tokens",
        "deepseek": "max_tokens",
        "ollama": "max_tokens",
        "lmstudio": "max_tokens",
        "github-models": "max_tokens",
        "github-copilot": "max_tokens",
        "copilot-proxy": "max_tokens",
        "nvidia": "max_tokens",
        "huggingface": "max_tokens",
    }
    NATIVE_HOSTS = {
        "openai": {"api.openai.com"},
        "deepseek": {"api.deepseek.com"},
        "google-gemini": {"generativelanguage.googleapis.com"},
        "xai-grok": {"api.x.ai"},
        "alibaba-qwen": {"dashscope.aliyuncs.com"},
        "minimax": {"api.minimax.io"},
        "glm": {"api.z.ai"},
        "github-models": {"models.github.ai"},
        "github-copilot": {"api.githubcopilot.com"},
        "copilot-proxy": {"127.0.0.1", "localhost"},
        "ollama": {"localhost", "127.0.0.1"},
        "vllm": {"localhost", "127.0.0.1"},
        "lmstudio": {"localhost", "127.0.0.1"},
    }

    @classmethod
    def apply(cls, provider: ProviderConfig) -> ProviderConfig:
        host = (urlparse(provider.base_url).hostname or "").lower()
        native_verified = host in cls.NATIVE_HOSTS.get(provider.name, set())
        data = provider.model_dump()
        data["native_verified"] = native_verified
        if not native_verified and provider.name in {"github-models", "github-copilot"}:
            data["extra_headers"] = {}
        return ProviderConfig(**data)

    @staticmethod
    def resolve_model(provider: ProviderConfig, client_model: str | None) -> str:
        if provider.allow_client_model_override and client_model:
            return client_model
        return provider.model

    @classmethod
    def prepare_chat_payload(cls, provider: ProviderConfig, payload: dict) -> dict:
        prepared = dict(payload)
        prepared["model"] = cls.resolve_model(provider, prepared.get("model"))
        cls._normalize_token_limit(provider, prepared)
        return prepared

    @classmethod
    def _normalize_token_limit(cls, provider: ProviderConfig, payload: dict) -> None:
        target_field = cls.token_limit_field(provider)
        if target_field:
            requested = cls._first_present(
                payload,
                (
                    target_field,
                    "max_completion_tokens",
                    "max_tokens",
                    "max_token",
                ),
            )
            if requested is None:
                requested = provider.default_max_tokens
            for key in ("max_completion_tokens", "max_tokens", "max_token"):
                payload.pop(key, None)
            if requested is not None:
                payload[target_field] = requested
            return

        if "max_token" in payload:
            value = payload.pop("max_token")
            if (
                value is not None
                and "max_tokens" not in payload
                and "max_completion_tokens" not in payload
            ):
                payload["max_tokens"] = value
        if "max_tokens" in payload and "max_completion_tokens" in payload:
            payload.pop("max_tokens", None)
        if (
            provider.default_max_tokens is not None
            and "max_tokens" not in payload
            and "max_completion_tokens" not in payload
        ):
            payload["max_tokens"] = provider.default_max_tokens

    @staticmethod
    def _first_present(payload: dict, keys: tuple[str, ...]) -> object | None:
        for key in keys:
            if key in payload and payload[key] is not None:
                return payload[key]
        return None

    @classmethod
    def token_limit_field(cls, provider: ProviderConfig) -> str | None:
        return cls.TOKEN_LIMIT_FIELD_BY_PROVIDER.get(provider.name)
