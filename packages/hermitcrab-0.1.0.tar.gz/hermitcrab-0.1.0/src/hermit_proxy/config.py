from __future__ import annotations

from functools import lru_cache
import pathlib

from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict

# Default config directory: ~/.hermitcrab/  (mirrors tools like claude code, gh, etc.)
DEFAULT_CONFIG_DIR = pathlib.Path.home() / ".hermitcrab"
_DEFAULT_DATABASE_URL = f"sqlite:///{DEFAULT_CONFIG_DIR / 'hermit.db'}"


class ProviderConfig(BaseModel):
    profile_id: int | None = None
    profile_name: str | None = None
    name: str
    base_url: str
    api_key: str = ""
    model: str
    chat_completions_path: str = "/chat/completions"
    models_path: str = "/models"
    embeddings_path: str = "/embeddings"
    extra_headers: dict[str, str] = Field(default_factory=dict)
    auth_profile_id: int | None = None
    allow_client_model_override: bool = False
    default_max_tokens: int | None = None
    native_verified: bool = False


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_prefix="HERMIT_", extra="ignore")

    database_url: str = _DEFAULT_DATABASE_URL
    request_timeout_seconds: float = 120.0

    default_provider: str = "ollama"
    default_model: str = "deepseek-r1:32b"
    default_base_url: str = "http://localhost:11434/v1"
    default_api_key: str = ""
    default_max_tokens: int | None = 2048

    openai_base_url: str | None = None
    openai_api_key: str | None = None
    openai_model: str | None = None

    openrouter_base_url: str | None = None
    openrouter_api_key: str | None = None
    openrouter_model: str | None = None

    anthropic_base_url: str | None = None
    anthropic_api_key: str | None = None
    anthropic_model: str | None = None

    deepseek_base_url: str | None = None
    deepseek_api_key: str | None = None
    deepseek_model: str | None = None

    ollama_base_url: str | None = None
    ollama_api_key: str | None = None
    ollama_model: str | None = None

    vllm_base_url: str | None = None
    vllm_api_key: str | None = None
    vllm_model: str | None = None

    lmstudio_base_url: str | None = None
    lmstudio_api_key: str | None = None
    lmstudio_model: str | None = None

    google_gemini_base_url: str | None = None
    google_gemini_api_key: str | None = None
    google_gemini_model: str | None = None

    xai_grok_base_url: str | None = None
    xai_grok_api_key: str | None = None
    xai_grok_model: str | None = None

    alibaba_qwen_base_url: str | None = None
    alibaba_qwen_api_key: str | None = None
    alibaba_qwen_model: str | None = None

    minimax_base_url: str | None = None
    minimax_api_key: str | None = None
    minimax_model: str | None = None

    glm_base_url: str | None = None
    glm_api_key: str | None = None
    glm_model: str | None = None

    github_models_base_url: str | None = None
    github_models_api_key: str | None = None
    github_models_model: str | None = None

    github_copilot_base_url: str | None = None
    github_copilot_api_key: str | None = None
    github_copilot_model: str | None = None

    copilot_proxy_base_url: str | None = None
    copilot_proxy_api_key: str | None = None
    copilot_proxy_model: str | None = None

    openai_compatible_base_url: str | None = None
    openai_compatible_api_key: str | None = None
    openai_compatible_model: str | None = None

    openai_codex_base_url: str | None = None
    openai_codex_api_key: str | None = None
    openai_codex_model: str | None = None

    xiaomi_base_url: str | None = None
    xiaomi_api_key: str | None = None
    xiaomi_model: str | None = None

    amazon_bedrock_base_url: str | None = None
    amazon_bedrock_api_key: str | None = None
    amazon_bedrock_model: str | None = None

    nvidia_base_url: str | None = None
    nvidia_api_key: str | None = None
    nvidia_model: str | None = None

    huggingface_base_url: str | None = None
    huggingface_api_key: str | None = None
    huggingface_model: str | None = None

    def bootstrap_provider_config(self, provider_name: str | None = None) -> ProviderConfig:
        provider = (provider_name or self.default_provider).lower()
        provider_defaults = {
            "openai": {"base_url": "https://api.openai.com/v1"},
            "openrouter": {"base_url": "https://openrouter.ai/api/v1"},
            "anthropic": {"base_url": "https://api.anthropic.com/v1"},
            "deepseek": {"base_url": "https://api.deepseek.com/v1"},
            "ollama": {"base_url": "http://localhost:11434/v1"},
            "vllm": {"base_url": "http://localhost:8000/v1"},
            "lmstudio": {"base_url": "http://localhost:1234/v1"},
            "google-gemini": {"base_url": "https://generativelanguage.googleapis.com/v1beta/openai"},
            "xai-grok": {"base_url": "https://api.x.ai/v1"},
            "alibaba-qwen": {"base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1"},
            "minimax": {"base_url": "https://api.minimax.io/v1"},
            "glm": {"base_url": "https://api.z.ai/api/paas/v4"},
            "github-models": {
                "base_url": "https://models.github.ai",
                "chat_completions_path": "/inference/chat/completions",
                "extra_headers": {
                    "Accept": "application/vnd.github+json",
                    "X-GitHub-Api-Version": "2026-03-10",
                },
            },
            "github-copilot": {
                "base_url": "https://api.githubcopilot.com",
            },
            "copilot-proxy": {
                "base_url": "http://127.0.0.1:4141/v1",
            },
            "openai-compatible": {
                "base_url": "http://localhost:8000/v1",
            },
            "openai-codex": {
                "base_url": "https://api.openai.com/v1",
            },
            "xiaomi": {
                "base_url": "https://api.xiaomimimo.com/v1",
            },
            "amazon-bedrock": {
                "base_url": "https://bedrock-mantle.us-east-1.api.aws/v1",
            },
            "nvidia": {
                "base_url": "https://integrate.api.nvidia.com/v1",
            },
            "huggingface": {
                "base_url": "https://router.huggingface.co/v1",
            },
        }
        alias_map = {
            "gemini": "google-gemini",
            "google_gemini": "google-gemini",
            "xai": "xai-grok",
            "grok": "xai-grok",
            "xai_grok": "xai-grok",
            "qwen": "alibaba-qwen",
            "alibaba_qwen": "alibaba-qwen",
            "github_models": "github-models",
            "github_copilot": "github-copilot",
            "copilot_proxy": "copilot-proxy",
            "openai_compatible": "openai-compatible",
            "openai_codex": "openai-codex",
            "lm-studio": "lmstudio",
            "xiaomi_mimo": "xiaomi",
            "mimo": "xiaomi",
            "amazon_bedrock": "amazon-bedrock",
            "bedrock": "amazon-bedrock",
            "nvidia_nim": "nvidia",
            "hugging_face": "huggingface",
            "hugging-face": "huggingface",
        }
        provider = alias_map.get(provider, provider)
        env_key = provider.replace("-", "_")
        defaults = provider_defaults.get(provider, {})
        base_url = getattr(self, f"{env_key}_base_url", None) or defaults.get("base_url") or self.default_base_url
        api_key = getattr(self, f"{env_key}_api_key", None) or self.default_api_key
        model = getattr(self, f"{env_key}_model", None) or self.default_model
        chat_completions_path = defaults.get("chat_completions_path", "/chat/completions")
        extra_headers = defaults.get("extra_headers", {})
        return ProviderConfig(
            name=provider,
            base_url=base_url.rstrip("/"),
            api_key=api_key,
            model=model,
            chat_completions_path=chat_completions_path,
            extra_headers=extra_headers,
            default_max_tokens=self.default_max_tokens,
            native_verified=False,
        )


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
