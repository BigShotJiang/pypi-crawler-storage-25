from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class ChatMessage(BaseModel):
    model_config = ConfigDict(extra="allow")

    role: str
    content: Any
    name: str | None = None


class ChatCompletionRequest(BaseModel):
    model_config = ConfigDict(extra="allow")

    model: str | None = None
    messages: list[ChatMessage]
    temperature: float | None = None
    top_p: float | None = None
    max_token: int | None = None
    max_tokens: int | None = None
    max_completion_tokens: int | None = None
    stream: bool = False
    user: str | None = None


class EmbeddingsRequest(BaseModel):
    model_config = ConfigDict(extra="allow")

    model: str | None = None
    input: Any
    user: str | None = None


class UsageRecord(BaseModel):
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


class ModelProfileInput(BaseModel):
    name: str
    provider: str
    base_url: str
    api_key: str = ""
    model: str
    allow_client_model_override: bool = False
    default_max_tokens: int | None = None
    activate: bool = False
    skip_test: bool = False
    auth_profile_id: int | None = None


class AuthProfileInput(BaseModel):
    name: str
    provider: str
    github_token: str | None = None
    github_domain: str = "github.com"
    openai_api_key: str | None = None


class GitHubDeviceStartInput(BaseModel):
    client_id: str
    github_domain: str = "github.com"


class GitHubDeviceCompleteInput(BaseModel):
    name: str
    client_id: str
    device_code: str
    github_domain: str = "github.com"
    interval: int = 5
    expires_in: int = 900


class ProfileTestResult(BaseModel):
    ok: bool
    status_code: int | None = None
    latency_ms: int | None = None
    provider: str
    model: str
    message: str
    response_excerpt: str | None = None


class ProxyRequestRecord(BaseModel):
    request_id: str
    received_at: datetime
    completed_at: datetime | None = None
    provider: str
    upstream_model: str
    client_model: str | None = None
    status_code: int | None = None
    success: bool = False
    latency_ms: int | None = None
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    request_body: dict[str, Any] = Field(default_factory=dict)
    response_body: dict[str, Any] = Field(default_factory=dict)
    error_message: str | None = None
