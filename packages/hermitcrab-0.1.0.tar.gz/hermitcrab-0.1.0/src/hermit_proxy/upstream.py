from __future__ import annotations

import json
from collections.abc import AsyncIterator
from typing import Any

import httpx

from hermit_proxy.config import ProviderConfig


class UpstreamClient:
    def __init__(self, timeout_seconds: float) -> None:
        self.timeout = timeout_seconds

    def _headers(self, provider: ProviderConfig) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if provider.native_verified:
            headers.update(provider.extra_headers)
        if provider.api_key:
            headers["Authorization"] = f"Bearer {provider.api_key}"
        return headers

    async def chat_completions(self, provider: ProviderConfig, payload: dict[str, Any]) -> tuple[int, dict[str, Any]]:
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.post(
                f"{provider.base_url}{provider.chat_completions_path}",
                headers=self._headers(provider),
                json=payload,
            )
        try:
            data = response.json()
        except ValueError:
            data = {"error": {"message": response.text}}
        return response.status_code, data

    async def embeddings(self, provider: ProviderConfig, payload: dict[str, Any]) -> tuple[int, dict[str, Any]]:
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.post(
                f"{provider.base_url}{provider.embeddings_path}",
                headers=self._headers(provider),
                json=payload,
            )
        try:
            data = response.json()
        except ValueError:
            data = {"error": {"message": response.text}}
        return response.status_code, data

    async def models(self, provider: ProviderConfig) -> tuple[int, dict[str, Any]]:
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.get(
                f"{provider.base_url}{provider.models_path}",
                headers=self._headers(provider),
            )
        try:
            data = response.json()
        except ValueError:
            data = {"error": {"message": response.text}}
        return response.status_code, data

    async def stream_chat_completions(
        self, provider: ProviderConfig, payload: dict[str, Any]
    ) -> tuple[int, AsyncIterator[bytes], httpx.Headers]:
        client = httpx.AsyncClient(timeout=None)
        request = client.build_request(
            "POST",
            f"{provider.base_url}{provider.chat_completions_path}",
            headers=self._headers(provider),
            json=payload,
        )
        response = await client.send(request, stream=True)

        async def iterator() -> AsyncIterator[bytes]:
            try:
                async for line in response.aiter_lines():
                    if not line:
                        yield b"\n"
                        continue
                    yield line.encode("utf-8") + b"\n"
            finally:
                await response.aclose()
                await client.aclose()

        return response.status_code, iterator(), response.headers

    @staticmethod
    def parse_sse_usage(chunks: list[bytes]) -> dict[str, int]:
        usage: dict[str, int] = {}
        for chunk in chunks:
            text = chunk.decode("utf-8", errors="ignore").strip()
            if not text.startswith("data: "):
                continue
            payload = text[6:]
            if payload == "[DONE]":
                continue
            try:
                data = json.loads(payload)
            except json.JSONDecodeError:
                continue
            item = data.get("usage")
            if isinstance(item, dict):
                for key in ("prompt_tokens", "completion_tokens", "total_tokens"):
                    value = item.get(key)
                    if isinstance(value, int):
                        usage[key] = value
        return usage
