from __future__ import annotations

import logging

VALID_LOG_LEVELS = ("CRITICAL", "ERROR", "WARNING", "INFO", "DEBUG")
DEFAULT_LOG_LEVEL = "INFO"


def normalize_log_level(level: str | None) -> str:
    value = (level or DEFAULT_LOG_LEVEL).upper()
    if value not in VALID_LOG_LEVELS:
        valid = ", ".join(VALID_LOG_LEVELS)
        raise ValueError(f"log level must be one of: {valid}")
    return value


def configure_logging(level: str | None) -> str:
    normalized = normalize_log_level(level)
    logging.basicConfig(
        level=getattr(logging, normalized),
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
        force=True,
    )
    return normalized
