from __future__ import annotations

from datetime import UTC, datetime

from hermit_proxy.config import ProviderConfig, Settings
from hermit_proxy.policy import ProviderPolicy
from hermit_proxy.storage import TrafficStore


class ProfileManager:
    def __init__(self, settings: Settings, store: TrafficStore) -> None:
        self.settings = settings
        self.store = store

    def ensure_bootstrap_profile(self) -> dict:
        active = self.store.get_active_profile()
        if active:
            return active

        profiles = self.store.list_profiles()
        if profiles:
            profile = profiles[0]
            self.store.set_active_profile(int(profile["id"]))
            return profile

        bootstrap = self.settings.bootstrap_provider_config()
        timestamp = utc_now()
        profile_id = self.store.create_profile(
            name=f"{bootstrap.name}:{bootstrap.model}",
            provider=bootstrap.name,
            base_url=bootstrap.base_url,
            api_key=bootstrap.api_key,
            auth_profile_id=None,
            model=bootstrap.model,
            allow_client_model_override=False,
            default_max_tokens=bootstrap.default_max_tokens,
            created_at=timestamp,
        )
        self.store.set_active_profile(profile_id)
        profile = self.store.get_profile(profile_id)
        assert profile is not None
        return profile

    def active_provider_config(self) -> ProviderConfig:
        profile = self.ensure_bootstrap_profile()
        return self.provider_config_from_profile(profile)

    def provider_config_for_client_model(self, client_model: str | None) -> ProviderConfig:
        routed = self.routed_provider_config(client_model)
        if routed:
            return routed
        return self.active_provider_config()

    def routed_provider_config(self, client_model: str | None) -> ProviderConfig | None:
        if not client_model or "/" not in client_model:
            return None
        provider_name, upstream_model = client_model.split("/", 1)
        provider_name = provider_name.strip().lower()
        upstream_model = upstream_model.strip()
        if not provider_name or not upstream_model:
            return None

        normalized_provider = self.normalize_provider_name(provider_name)
        provider_profiles = [
            profile for profile in self.store.list_profiles()
            if self.normalize_provider_name(str(profile["provider"])) == normalized_provider
        ]
        if not provider_profiles:
            return None

        exact_profile = next(
            (profile for profile in provider_profiles if str(profile["model"]) == upstream_model),
            None,
        )
        return self.provider_config_from_profile(
            exact_profile or provider_profiles[0],
            model_override=upstream_model,
            allow_client_model_override=False,
        )

    def provider_config_from_profile(
        self,
        profile: dict,
        *,
        model_override: str | None = None,
        allow_client_model_override: bool | None = None,
    ) -> ProviderConfig:
        base = self.settings.bootstrap_provider_config(str(profile["provider"]))
        return ProviderPolicy.apply(
            ProviderConfig(
                profile_id=int(profile["id"]),
                profile_name=str(profile["name"]),
                **base.model_dump(
                    exclude={
                        "profile_id",
                        "profile_name",
                        "name",
                        "base_url",
                        "api_key",
                        "model",
                        "auth_profile_id",
                        "allow_client_model_override",
                        "default_max_tokens",
                        "native_verified",
                    }
                ),
                name=base.name,
                base_url=str(profile["base_url"]).rstrip("/"),
                api_key=str(profile["api_key"]),
                auth_profile_id=profile.get("auth_profile_id"),
                model=model_override or str(profile["model"]),
                default_max_tokens=profile.get("default_max_tokens"),
                allow_client_model_override=(
                    allow_client_model_override
                    if allow_client_model_override is not None
                    else bool(profile.get("allow_client_model_override"))
                ),
            )
        )

    def normalize_provider_name(self, provider: str) -> str:
        return self.settings.bootstrap_provider_config(provider).name

    def resolve_profile(self, selector: str) -> dict | None:
        if selector.isdigit():
            return self.store.get_profile(int(selector))
        for profile in self.store.list_profiles():
            if str(profile["name"]) == selector:
                return profile
        return None

    def provider_config_from_values(
        self,
        *,
        name: str,
        provider: str,
        base_url: str,
        api_key: str,
        model: str,
        auth_profile_id: int | None = None,
        allow_client_model_override: bool = False,
        default_max_tokens: int | None = None,
        activate: bool = False,
    ) -> ProviderConfig:
        del name, activate
        base = self.settings.bootstrap_provider_config(provider)
        return ProviderPolicy.apply(
            ProviderConfig(
            name=base.name,
            base_url=base_url.rstrip("/"),
            api_key=api_key,
            model=model,
            chat_completions_path=base.chat_completions_path,
            models_path=base.models_path,
            embeddings_path=base.embeddings_path,
            extra_headers=base.extra_headers,
            auth_profile_id=auth_profile_id,
            allow_client_model_override=allow_client_model_override,
            default_max_tokens=default_max_tokens,
            )
        )

    def save_profile(
        self,
        *,
        name: str,
        provider: str,
        base_url: str,
        api_key: str,
        auth_profile_id: int | None,
        model: str,
        allow_client_model_override: bool,
        default_max_tokens: int | None = None,
        profile_id: int | None = None,
        activate: bool = False,
    ) -> int:
        now = utc_now()
        if profile_id is None:
            profile_id = self.store.create_profile(
                name=name,
                provider=provider,
                base_url=base_url.rstrip("/"),
                api_key=api_key,
                auth_profile_id=auth_profile_id,
                model=model,
                allow_client_model_override=allow_client_model_override,
                default_max_tokens=default_max_tokens,
                created_at=now,
            )
        else:
            self.store.update_profile(
                profile_id,
                name=name,
                provider=provider,
                base_url=base_url.rstrip("/"),
                api_key=api_key,
                auth_profile_id=auth_profile_id,
                model=model,
                allow_client_model_override=allow_client_model_override,
                default_max_tokens=default_max_tokens,
                updated_at=now,
            )
        if activate:
            self.store.set_active_profile(profile_id)
        return profile_id


def utc_now() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat()
