from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
import time
from typing import Any

import httpx

from hermit_proxy.config import ProviderConfig, Settings
from hermit_proxy.storage import TrafficStore


@dataclass
class CopilotAccessToken:
    token: str
    expires_at: int | None
    endpoint: str


@dataclass
class DeviceCodeResult:
    device_code: str
    user_code: str
    verification_uri: str
    expires_in: int
    interval: int


class AuthManager:
    _copilot_cache: dict[int, CopilotAccessToken] = {}

    def __init__(self, settings: Settings, store: TrafficStore) -> None:
        self.settings = settings
        self.store = store

    def resolve_provider(self, provider: ProviderConfig) -> ProviderConfig:
        if provider.name != "github-copilot":
            if provider.name != "openai-codex":
                return provider
            if not provider.auth_profile_id:
                return provider
            auth_profile = self.store.get_auth_profile(int(provider.auth_profile_id))
            if not auth_profile:
                raise ValueError(f"Auth profile not found: {provider.auth_profile_id}")
            api_key = str(auth_profile["secrets"].get("openai_api_key") or "")
            if not api_key:
                raise ValueError("OpenAI Codex auth profile is missing an API key")
            data = provider.model_dump()
            data["api_key"] = api_key
            if not data.get("model"):
                data["model"] = "codex-mini-latest"
            return ProviderConfig(**data)
        if not provider.auth_profile_id:
            return provider
        auth_profile = self.store.get_auth_profile(int(provider.auth_profile_id))
        if not auth_profile:
            raise ValueError(f"Auth profile not found: {provider.auth_profile_id}")
        token = self.get_cached_or_exchange_copilot_token(int(provider.auth_profile_id), auth_profile["secrets"])
        data = provider.model_dump()
        data["base_url"] = token.endpoint.rstrip("/")
        data["api_key"] = token.token
        return ProviderConfig(**data)

    def get_cached_or_exchange_copilot_token(self, auth_profile_id: int, secrets: dict[str, Any]) -> CopilotAccessToken:
        cached = self._copilot_cache.get(auth_profile_id)
        now = int(datetime.now(UTC).timestamp())
        if cached and cached.expires_at and cached.expires_at - now > 60:
            return cached
        token = self.exchange_copilot_token(secrets)
        self._copilot_cache[auth_profile_id] = token
        return token

    def exchange_copilot_token(self, secrets: dict[str, Any]) -> CopilotAccessToken:
        github_token = str(secrets.get("github_token") or "")
        github_domain = str(secrets.get("github_domain") or "github.com")
        if not github_token:
            raise ValueError("GitHub token missing from auth profile")

        url = f"https://api.{github_domain}/copilot_internal/v2/token"
        headers = {
            "Authorization": f"Bearer {github_token}",
            "Accept": "application/json",
            "User-Agent": "hermit-proxy/0.1.0",
        }
        with httpx.Client(timeout=self.settings.request_timeout_seconds) as client:
            response = client.get(url, headers=headers)
        response.raise_for_status()
        data = response.json()
        token = data.get("token")
        if not token:
            raise ValueError("Copilot token exchange did not return a token")
        endpoint = extract_copilot_endpoint(data) or "https://api.githubcopilot.com"
        expires_at = data.get("expires_at")
        return CopilotAccessToken(
            token=str(token),
            expires_at=int(expires_at) if expires_at else None,
            endpoint=endpoint,
        )

    def save_github_copilot_auth_profile(
        self,
        *,
        name: str,
        github_token: str,
        github_domain: str = "github.com",
        auth_profile_id: int | None = None,
    ) -> int:
        now = datetime.now(UTC).replace(microsecond=0).isoformat()
        secrets = {"github_token": github_token, "github_domain": github_domain}
        if auth_profile_id is None:
            return self.store.create_auth_profile(
                name=name,
                provider="github-copilot",
                secrets=secrets,
                created_at=now,
            )
        self.store.update_auth_profile(
            auth_profile_id,
            name=name,
            provider="github-copilot",
            secrets=secrets,
            updated_at=now,
        )
        return auth_profile_id

    def save_openai_codex_auth_profile(
        self,
        *,
        name: str,
        openai_api_key: str,
        auth_profile_id: int | None = None,
    ) -> int:
        now = datetime.now(UTC).replace(microsecond=0).isoformat()
        secrets = {"openai_api_key": openai_api_key}
        if auth_profile_id is None:
            return self.store.create_auth_profile(
                name=name,
                provider="openai-codex",
                secrets=secrets,
                created_at=now,
            )
        self.store.update_auth_profile(
            auth_profile_id,
            name=name,
            provider="openai-codex",
            secrets=secrets,
            updated_at=now,
        )
        return auth_profile_id

    def start_github_device_flow(
        self,
        *,
        client_id: str,
        github_domain: str = "github.com",
    ) -> DeviceCodeResult:
        url = f"https://{github_domain}/login/device/code"
        headers = {"Accept": "application/json"}
        data = {"client_id": client_id}
        with httpx.Client(timeout=self.settings.request_timeout_seconds) as client:
            response = client.post(url, headers=headers, data=data)
        response.raise_for_status()
        payload = response.json()
        return DeviceCodeResult(
            device_code=str(payload["device_code"]),
            user_code=str(payload["user_code"]),
            verification_uri=str(payload.get("verification_uri") or payload.get("verification_uri_complete") or f"https://{github_domain}/login/device"),
            expires_in=int(payload["expires_in"]),
            interval=int(payload.get("interval", 5)),
        )

    def complete_github_device_flow(
        self,
        *,
        client_id: str,
        device_code: str,
        github_domain: str = "github.com",
        interval: int = 5,
        expires_in: int = 900,
    ) -> str:
        deadline = time.time() + expires_in
        url = f"https://{github_domain}/login/oauth/access_token"
        headers = {"Accept": "application/json"}
        poll_interval = max(1, interval)

        with httpx.Client(timeout=self.settings.request_timeout_seconds) as client:
            while time.time() < deadline:
                response = client.post(
                    url,
                    headers=headers,
                    data={
                        "client_id": client_id,
                        "device_code": device_code,
                        "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                    },
                )
                response.raise_for_status()
                payload = response.json()
                access_token = payload.get("access_token")
                if isinstance(access_token, str) and access_token:
                    return access_token

                error = payload.get("error")
                if error == "authorization_pending":
                    time.sleep(poll_interval)
                    continue
                if error == "slow_down":
                    poll_interval += 5
                    time.sleep(poll_interval)
                    continue
                if error in {"expired_token", "access_denied", "incorrect_device_code", "unsupported_grant_type"}:
                    raise ValueError(f"GitHub device flow failed: {error}")
                raise ValueError(f"GitHub device flow failed: {payload}")

        raise TimeoutError("GitHub device flow timed out before authorization completed")


def extract_copilot_endpoint(payload: dict[str, Any]) -> str | None:
    for key in ("endpoint", "api_endpoint"):
        value = payload.get(key)
        if isinstance(value, str) and value.startswith("http"):
            return value
    endpoints = payload.get("endpoints")
    if isinstance(endpoints, dict):
        for key in ("api", "chat", "completions"):
            value = endpoints.get(key)
            if isinstance(value, str) and value.startswith("http"):
                return value.removesuffix("/chat/completions")
    return None
