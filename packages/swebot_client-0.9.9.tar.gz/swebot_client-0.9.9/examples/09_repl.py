#!/usr/bin/env python3
"""Interactive REPL — chat with swebot from your terminal."""
from swebot_client import SwebotClient

client = SwebotClient()
if not client.wait_until_ready():
    print("Cannot reach swebot. Start it with: swebot --serve")
    exit(1)

session = client.create_session()
info = client.stats()
print(f"swebot REPL — {info.get('provider')}/{info.get('model')}")
print("Type 'quit' to exit, 'new' for fresh session\n")

while True:
    try:
        msg = input("You: ").strip()
    except (EOFError, KeyboardInterrupt):
        break
    if not msg:
        continue
    if msg == "quit":
        break
    if msg == "new":
        session = client.create_session()
        print("✓ New session\n")
        continue

    print("AI: ", end="", flush=True)
    for token in session.stream(msg):
        print(token, end="", flush=True)
    print("\n")
