#!/usr/bin/env python3
"""One question, one answer. The simplest possible swebot script."""
from swebot_client import SwebotClient

client = SwebotClient()
session = client.create_session()
print(session.send("What are the top 3 design patterns every Go developer should know?"))
