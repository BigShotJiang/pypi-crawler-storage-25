#!/usr/bin/env python3
"""Pipeline: research → design → implement in three chained sessions."""
import sys
from swebot_client import SwebotClient

task = " ".join(sys.argv[1:]) or "Build a CLI tool that converts CSV to JSON"

client = SwebotClient()

stages = [
    ("research",  "Research this task and list key considerations:\n\n"),
    ("default",   "Based on this research, create a short technical design:\n\n"),
    ("developer", "Implement this design. Write clean, working code:\n\n"),
]

context = task
for agent, prefix in stages:
    print(f"\n{'━'*60}")
    print(f"  Stage: {agent}")
    print(f"{'━'*60}\n")
    session = client.create_session(agent=agent)
    context = session.send(prefix + context)
    print(context[:2000])

print(f"\n{'━'*60}")
print("  ✓ Pipeline complete")
