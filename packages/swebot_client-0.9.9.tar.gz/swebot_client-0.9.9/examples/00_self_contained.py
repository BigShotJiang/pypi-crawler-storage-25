#!/usr/bin/env python3
"""
Self-contained swebot script — starts its own backend, asks a question, shuts down.

Use this pattern when you need a standalone script that doesn't depend on
an already-running swebot process. Perfect for CI, cron jobs, or one-off tasks.

Usage:
    python 00_self_contained.py
    python 00_self_contained.py --port 8082   # if 8080 is in use
"""
import argparse
import atexit
import shutil
import subprocess
import sys
import time

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8080)
    args = parser.parse_args()

    swebot = shutil.which("swebot")
    if not swebot:
        sys.exit("swebot not found in PATH — install from https://github.com/tickup-se/swebot")

    # Start a headless backend (no auto-token, open API)
    proc = subprocess.Popen(
        [swebot, "--serve", "--foreground", "--port", str(args.port)],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    atexit.register(proc.terminate)

    from swebot_client import SwebotClient

    client = SwebotClient(f"http://localhost:{args.port}")
    if not client.wait_until_ready(timeout=15):
        sys.exit(f"Backend didn't start on port {args.port}")

    session = client.create_session()
    reply = session.send("What are the three most popular programming languages in 2025?")
    print(reply)

    proc.terminate()

if __name__ == "__main__":
    main()
