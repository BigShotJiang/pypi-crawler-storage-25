#!/usr/bin/env python3
"""Batch processor — run the same prompt across multiple inputs."""
from swebot_client import SwebotClient

client = SwebotClient()

functions = [
    "def add(a, b): return a + b",
    "def factorial(n): return 1 if n <= 1 else n * factorial(n-1)",
    "def fib(n): return n if n < 2 else fib(n-1) + fib(n-2)",
]

for fn in functions:
    session = client.create_session()
    reply = session.send(
        f"Write 3 edge-case unit tests for this function. "
        f"Output ONLY the pytest code, no explanation.\n\n```python\n{fn}\n```"
    )
    print(f"# Tests for: {fn.split('(')[0].replace('def ', '')}")
    print(reply)
    print()
