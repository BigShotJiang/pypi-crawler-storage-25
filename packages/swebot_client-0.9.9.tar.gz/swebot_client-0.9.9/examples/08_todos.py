#!/usr/bin/env python3
"""Todo tracker — let the agent plan, then monitor progress."""
from swebot_client import SwebotClient

client = SwebotClient()
session = client.create_session()

# Ask the agent to create a plan with todos
session.send("Plan how to build a REST API with authentication. Break it into 5 tasks using your todo tool.")

# Read the todos it created
print("📋 Agent's plan:\n")
for todo in session.get_todos():
    icon = {"pending": "○", "in_progress": "◐", "done": "●"}.get(todo.status, "?")
    print(f"  {icon} [{todo.status:^11}] {todo.title}")
    if todo.description:
        print(f"    {todo.description[:80]}")

# Show token usage
usage = session.token_usage()
print(f"\n📊 Tokens: {usage['tokens_in']:,} in / {usage['tokens_out']:,} out ({usage['usage_pct']}%)")
