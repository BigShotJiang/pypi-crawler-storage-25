#!/usr/bin/env python3
"""Stream tokens in real-time — feels like ChatGPT in your terminal."""
from swebot_client import SwebotClient

client = SwebotClient()
session = client.create_session()

for token in session.stream("Explain async/await in Python with a practical example"):
    print(token, end="", flush=True)
print()
