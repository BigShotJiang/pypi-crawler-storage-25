#!/usr/bin/env python3
"""Code review — point swebot at a file and get actionable feedback."""
import sys
from pathlib import Path
from swebot_client import SwebotClient

file_path = sys.argv[1] if len(sys.argv) > 1 else "main.go"

client = SwebotClient()
session = client.create_session(agent="developer")

prompt = f"""Review this file for bugs, security issues, and improvements.
Be specific — reference line numbers and show fixed code.
Only flag things that genuinely matter.

File: {file_path}"""

for token in session.stream(prompt):
    print(token, end="", flush=True)
print()
