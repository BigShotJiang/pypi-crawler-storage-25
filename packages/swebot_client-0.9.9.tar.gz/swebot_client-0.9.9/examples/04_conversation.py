#!/usr/bin/env python3
"""Multi-turn conversation — context carries across messages."""
from swebot_client import SwebotClient

client = SwebotClient()
session = client.create_session()

questions = [
    "What is a binary search tree?",
    "Now implement one in Python with insert and search",
    "Add a delete method and unit tests",
]

for q in questions:
    print(f"\n{'─'*60}")
    print(f"You: {q}\n")
    for token in session.stream(q):
        print(token, end="", flush=True)
    print()
