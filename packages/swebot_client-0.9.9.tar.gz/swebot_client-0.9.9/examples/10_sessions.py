#!/usr/bin/env python3
"""Session management — create, list, resume, delete."""
from swebot_client import SwebotClient

client = SwebotClient()

# Create two sessions
s1 = client.create_session()
s1.send("Remember: the secret word is 'banana'")
print(f"Session 1: {s1.id}")

s2 = client.create_session()
s2.send("Remember: the secret word is 'mango'")
print(f"Session 2: {s2.id}")

# List all sessions
sessions = client.list_sessions()
print(f"\nActive sessions: {len(sessions)}")

# Resume session 1 by sending another message to it
reply = s1.send("What's the secret word?")
print(f"\nResumed S1, reply: {reply[:100]}")

# Clean up
client.delete_session(s1.id)
client.delete_session(s2.id)
print("\n✓ Sessions cleaned up")
