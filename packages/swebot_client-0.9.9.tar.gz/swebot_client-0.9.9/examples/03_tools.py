#!/usr/bin/env python3
"""Watch the agent think — see every tool call as it happens."""
from swebot_client import SwebotClient

client = SwebotClient()
session = client.create_session(agent="developer")

reply = session.send_with_events(
    "Read the main Go file in this project and suggest one improvement",
    on_token=lambda t: print(t, end="", flush=True),
    on_tool_start=lambda tc: print(f"\n  ⚙ {tc.name}", flush=True),
    on_tool_result=lambda tc: print(f"  ✓ {tc.name} ({len(tc.output)} chars)", flush=True),
)
print()
