#!/usr/bin/env python3
"""
swebot-client — Python client for the swebot autonomous coding agent.

Pure Python — zero dependencies beyond the standard library.

Install:
    pip install swebot-client
    uv add swebot-client

Usage:
    from swebot_client import SwebotClient

    client = SwebotClient()                       # localhost:8080, no auth needed
    session = client.create_session()
    for chunk in session.stream("explain goroutines"):
        print(chunk, end="", flush=True)

Auth: If swebot was started with --token, set SWEBOT_TOKEN in your environment.
The SDK reads it automatically — no need to pass it in code.
"""

__version__ = "0.9.9"
__all__ = ["SwebotClient", "Session", "ToolCall", "TodoItem", "Message", "Event"]

import json
import os
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Callable, Dict, Iterator, List, Optional, Union

# ── ANSI colours ──────────────────────────────────────────────────────────────

RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
RED = "\033[91m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
BLUE = "\033[94m"
MAGENTA = "\033[95m"
CYAN = "\033[96m"
WHITE = "\033[97m"

def _color(text: str, *codes: str) -> str:
    if not sys.stdout.isatty():
        return text
    return "".join(codes) + text + RESET


# ── Data types ─────────────────────────────────────────────────────────────────

@dataclass
class ToolCall:
    id: str
    name: str
    input: str = ""
    output: str = ""
    is_error: bool = False


@dataclass
class TodoItem:
    id: str
    title: str
    description: str
    status: str  # pending | in_progress | done


@dataclass
class Message:
    role: str
    content: str
    tool_calls: list = field(default_factory=list)


@dataclass
class Event:
    kind: str
    data: dict


# ── Client ────────────────────────────────────────────────────────────────────

class SwebotClient:
    """HTTP client for the swebot backend API."""

    def __init__(self, addr: str = "http://localhost:8080", token: str = ""):
        self.addr = addr.rstrip("/")
        # Auto-discover token: explicit arg > SWEBOT_TOKEN env var > no auth
        self.token = token or os.environ.get("SWEBOT_TOKEN", "")

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _get(self, path: str) -> Dict:
        return self._request("GET", path)

    def _delete(self, path: str) -> None:
        self._request("DELETE", path)

    def _request(self, method: str, path: str, body=None) -> Dict:
        url = f"{self.addr}{path}"
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(url, method=method, data=data)
        req.add_header("Content-Type", "application/json")
        if self.token:
            req.add_header("Authorization", f"Bearer {self.token}")
        try:
            with urllib.request.urlopen(req) as resp:
                body = resp.read()
                return json.loads(body) if body else {}
        except urllib.error.HTTPError as e:
            msg = e.read().decode()
            if e.code == 401:
                hint = (
                    "\n\nHint: The backend requires a Bearer token. "
                    "Either:\n"
                    "  • Set SWEBOT_TOKEN in your environment to match "
                    "the backend's --token flag\n"
                    "  • Start the backend without --token for open access: "
                    "swebot --serve --port <port>\n"
                    "  • Check if another backend is already running on "
                    f"{self.addr} (try: curl {self.addr}/health)"
                )
                raise RuntimeError(f"HTTP 401 {method} {path}: {msg}{hint}") from e
            raise RuntimeError(f"HTTP {e.code} {method} {path}: {msg}") from e

    def _stream(self, path: str, body: dict) -> Iterator[Event]:
        url = f"{self.addr}{path}"
        data = json.dumps(body).encode()
        req = urllib.request.Request(url, method="POST", data=data)
        req.add_header("Content-Type", "application/json")
        if self.token:
            req.add_header("Authorization", f"Bearer {self.token}")
        event_type = ""
        with urllib.request.urlopen(req) as resp:
            for raw in resp:
                line = raw.decode().rstrip("\n")
                if line.startswith("event: "):
                    event_type = line[7:]
                elif line.startswith("data: ") and event_type:
                    yield Event(kind=event_type, data=json.loads(line[6:]))
                    event_type = ""

    # ── Health ────────────────────────────────────────────────────────────────

    def health(self) -> bool:
        try:
            self._request("GET", "/health")
            return True
        except Exception:
            return False

    def wait_until_ready(self, timeout: float = 10.0) -> bool:
        deadline = time.time() + timeout
        while time.time() < deadline:
            if self.health():
                return True
            time.sleep(0.2)
        return False

    # ── Sessions ──────────────────────────────────────────────────────────────

    def create_session(self, agent: str = "default") -> "Session":
        resp = self._request("POST", "/api/sessions", {"agent": agent})
        return Session(self, resp["id"], agent)

    def get_session(self, session_id: str) -> "Session":
        resp = self._request("GET", f"/api/sessions/{session_id}")
        return Session(self, resp["id"], resp.get("agent", "default"), resp)

    def list_sessions(self) -> List[dict]:
        resp = self._request("GET", "/api/sessions")
        return resp if isinstance(resp, list) else resp.get("sessions", [])

    def delete_session(self, session_id: str) -> None:
        self._request("DELETE", f"/api/sessions/{session_id}")

    # ── Agents / providers ────────────────────────────────────────────────────

    def list_agents(self) -> List[dict]:
        resp = self._request("GET", "/api/agents")
        return resp if isinstance(resp, list) else resp.get("agents", [])

    def list_providers(self) -> List[dict]:
        resp = self._request("GET", "/api/providers")
        return resp if isinstance(resp, list) else resp.get("providers", [])

    # ── MCP management ────────────────────────────────────────────────────────

    def list_mcp(self) -> List[dict]:
        """Return all configured MCP servers with live connection state."""
        resp = self._request("GET", "/api/mcp")
        return resp if isinstance(resp, list) else resp.get("servers", [])

    def add_mcp(
        self,
        name: str,
        *,
        type: str = "stdio",
        command: str = "",
        args: Optional[List[str]] = None,
        url: str = "",
        env: Optional[List[str]] = None,
        headers: Optional[Dict[str, str]] = None,
        tools: Optional[List[str]] = None,
        disabled: bool = False,
    ) -> Dict:
        """Add a new MCP server and connect it immediately."""
        payload: dict = {"name": name, "type": type}
        if command:
            payload["command"] = command
        if args:
            payload["args"] = args
        if url:
            payload["url"] = url
        if env:
            payload["env"] = env
        if headers:
            payload["headers"] = headers
        if tools:
            payload["tools"] = tools
        if disabled:
            payload["disabled"] = True
        return self._request("POST", "/api/mcp", payload)

    def update_mcp(self, name: str, **fields) -> Dict:
        """Update an existing MCP server's config (reconnects automatically)."""
        fields["name"] = name
        return self._request("PUT", f"/api/mcp/{name}", fields)

    def delete_mcp(self, name: str) -> Dict:
        """Remove an MCP server from config and disconnect it."""
        return self._request("DELETE", f"/api/mcp/{name}")

    def enable_mcp(self, name: str) -> Dict:
        """Enable a disabled MCP server and connect it."""
        return self._request("POST", f"/api/mcp/{name}/enable")

    def disable_mcp(self, name: str) -> Dict:
        """Disable an MCP server (keeps config, stops connection)."""
        return self._request("POST", f"/api/mcp/{name}/disable")

    def reload_mcp(self) -> Dict:
        """Disconnect all MCP servers and reconnect every enabled one."""
        return self._request("POST", "/api/mcp/reload")

    # ── Backend management ────────────────────────────────────────────────────

    def stats(self) -> Dict:
        """Return backend stats: mode, agents, prompts, tools, lines, mcp_count."""
        return self._request("GET", "/api/stats")

    def skills(self) -> list:
        """Return the catalogue of all built-in skill agents with active status."""
        return self._request("GET", "/api/skills")

    def shutdown(self) -> Dict:
        """Gracefully stop the backend. Returns the last session ID.

        After this call the backend process exits. Resume with:
            swebot --serve
            swebot --tui  (or --session <last_session_id>)
        """
        return self._request("POST", "/api/shutdown")


class Session:
    """A single conversation session with the swebot agent."""

    def __init__(self, client: SwebotClient, session_id: str,
                 agent: str = "default", data: dict = None):
        self.client = client
        self.id = session_id
        self.agent = agent
        self._data = data or {}

    # ── Messaging ─────────────────────────────────────────────────────────────

    def stream(self, message: str) -> Iterator[str]:
        """Stream the assistant's reply token-by-token."""
        for ev in self._stream_events(message):
            if ev.kind == "content_delta":
                yield ev.data.get("delta", "")

    def send(self, message: str) -> str:
        """Send a message and return the complete reply (non-streaming)."""
        reply = ""
        for ev in self._stream_events(message):
            if ev.kind == "content_delta":
                reply += ev.data.get("delta", "")
            elif ev.kind == "message_complete":
                reply = ev.data.get("content", reply)
        return reply

    def send_with_events(
        self,
        message: str,
        on_token: Optional[Callable[[str], None]] = None,
        on_tool_start: Optional[Callable[[ToolCall], None]] = None,
        on_tool_result: Optional[Callable[[ToolCall], None]] = None,
    ) -> str:
        """Send a message, firing callbacks for tokens and tool calls."""
        reply = ""
        active_tools: dict[str, ToolCall] = {}

        for ev in self._stream_events(message):
            if ev.kind == "content_delta":
                delta = ev.data.get("delta", "")
                reply += delta
                if on_token:
                    on_token(delta)

            elif ev.kind == "tool_start":
                tc = ToolCall(
                    id=ev.data.get("tool_id", ""),
                    name=ev.data.get("tool_name", ""),
                )
                active_tools[tc.id] = tc
                if on_tool_start:
                    on_tool_start(tc)

            elif ev.kind == "tool_result":
                tid = ev.data.get("tool_id", "")
                tc = active_tools.pop(tid, ToolCall(id=tid, name=ev.data.get("tool_name", "")))
                tc.output = ev.data.get("content", "")
                tc.is_error = ev.data.get("is_error", False)
                if on_tool_result:
                    on_tool_result(tc)

            elif ev.kind == "message_complete":
                reply = ev.data.get("content", reply)

        return reply

    def _stream_events(self, message: str) -> Iterator[Event]:
        return self.client._stream(
            f"/api/sessions/{self.id}/messages",
            {"content": message},
        )

    # ── Todos ─────────────────────────────────────────────────────────────────

    def compact(self) -> Dict:
        """Manually trigger context compaction for this session.

        swebot auto-compacts at 85 % of the model context window.  Call this
        to compact earlier and free up tokens.

        Returns a dict with ``{"compacted": true, "summary": "..."}`` on
        success or ``{"compacted": false, "reason": "..."}`` when not needed.
        """
        return self.client._request("POST", f"/api/sessions/{self.id}/compact")

    def clear(self) -> Dict:
        """Clear all context (messages + knowledge) from this session.

        Resets the session to a fresh state as if swebot just started, without
        restarting the process.  The session ID, agent, and model are preserved.

        Useful for:
        - SWE-bench harness: clean slate between tasks
        - Switching to a different task without restarting

        Returns ``{"status": "cleared"}`` on success.
        """
        return self.client._request("POST", f"/api/sessions/{self.id}/clear")

    def token_usage(self) -> Dict:
        """Return token usage for this session from the stats endpoint.

        Returns::

            {
              "tokens_in": 14200,
              "tokens_out": 3400,
              "context_window": 200000,
              "usage_pct": 8.8,
            }
        """
        stats = self.client._request("GET", "/api/stats")
        win = stats.get("context_window", 0)
        tin = stats.get("tokens_in", 0)
        tout = stats.get("tokens_out", 0)
        pct = round((tin / win * 100), 1) if win else 0
        return {
            "tokens_in": tin,
            "tokens_out": tout,
            "context_window": win,
            "usage_pct": pct,
        }

    def get_todos(self) -> List['TodoItem']:
        resp = self.client._request("GET", f"/api/sessions/{self.id}/todos")
        todos_list = resp if isinstance(resp, list) else resp.get("todos", [])
        return [
            TodoItem(
                id=t["id"], title=t["title"],
                description=t.get("description", ""),
                status=t.get("status", "pending"),
            )
            for t in todos_list
        ]

    def update_todo(self, todo_id: str, status: str) -> None:
        self.client._request(
            "PATCH", f"/api/sessions/{self.id}/todos/{todo_id}",
            {"status": status},
        )

    # ── Info ──────────────────────────────────────────────────────────────────

    def refresh(self) -> "Session":
        self._data = self.client._request("GET", f"/api/sessions/{self.id}")
        return self

    @property
    def message_count(self) -> int:
        return self._data.get("message_count", 0)

    def __repr__(self) -> str:
        return f"Session(id={self.id!r}, agent={self.agent!r})"
