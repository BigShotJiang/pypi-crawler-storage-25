"""Human-readable session ID generator.

Generates short, memorable hyphen-joined phrases (e.g. ``swift-cedar-fox``)
as drop-in replacements for UUID session identifiers.  Phrases are safe to
use as S3 keys, filesystem paths, and AgentCore Memory session IDs.

Collision space: ~150 × 150 × 150 ≈ 3.4 million unique phrases.  For a
single user accumulating 100 threads the collision probability is < 0.002 %.
"""

from __future__ import annotations

import random

# ── Word lists ────────────────────────────────────────────────────────────────

_ADJECTIVES: tuple[str, ...] = (
    "amber", "ashen", "bare", "bleak", "blind", "bold", "brief", "bright",
    "broad", "brisk", "calm", "clear", "cold", "crisp", "cyan", "dark",
    "dawn", "dead", "deep", "dim", "dusk", "dusty", "deft", "dry", "elder",
    "even", "fair", "faint", "far", "fast", "fell", "fierce", "fine",
    "firm", "fixed", "flat", "fleet", "free", "frost", "full", "gold",
    "grave", "gray", "great", "green", "grim", "hard", "harsh", "high",
    "holt", "hushed", "idle", "inner", "iron", "jade", "keen", "kind",
    "known", "last", "lean", "light", "lone", "long", "lost", "loud",
    "low", "lunar", "mild", "mist", "murk", "mute", "near", "new",
    "night", "north", "numb", "odd", "old", "open", "pale", "plain",
    "prime", "pure", "quick", "quiet", "rare", "raw", "red", "rife",
    "rough", "round", "rust", "sage", "salt", "sharp", "sheer", "short",
    "shy", "silent", "slim", "slow", "small", "soft", "solar", "still",
    "stone", "storm", "swift", "tall", "tame", "thin", "tidal", "tight",
    "true", "twin", "vast", "void", "wan", "warm", "west", "wide",
    "wild", "wind", "wise", "worn", "young", "zeal", "zinc", "azure",
    "black", "blue", "bone", "burnt", "clay", "coal", "coral", "dawn",
    "dew", "ember", "frost", "hemp", "ink", "iron", "leaf", "lime",
    "moss", "oak", "pine", "plum", "reed", "rose", "rust", "sand",
    "silk", "slate", "smoke", "snow", "soot", "steel", "straw", "tide",
    "umber", "vale", "vine", "wave", "weld", "wood",
)

_NOUNS: tuple[str, ...] = (
    "arch", "atoll", "bay", "beck", "bluff", "bog", "boulder", "brook",
    "burn", "butte", "cairn", "cape", "cave", "chalk", "chasm", "cirque",
    "cliff", "cloud", "combe", "copse", "cove", "creek", "crest", "croft",
    "dale", "dell", "delta", "dene", "dune", "dyke", "eddy", "escarp",
    "fen", "fern", "field", "fell", "fjord", "flint", "flood", "ford",
    "forest", "forge", "forth", "glade", "glen", "gorge", "gravel",
    "grove", "gulf", "heath", "holm", "inlet", "isle", "kelp", "knoll",
    "lagoon", "larch", "ledge", "loch", "marl", "marsh", "mead", "mesa",
    "mire", "moor", "moraine", "mount", "mud", "node", "peat", "peak",
    "pier", "plain", "plunge", "point", "pond", "pool", "press", "quarry",
    "ravine", "reach", "reef", "ridge", "rill", "rise", "river", "rock",
    "run", "sand", "scarp", "sedge", "shale", "shore", "sill", "silt",
    "slab", "slope", "slough", "snow", "spit", "spring", "spur", "stone",
    "strath", "stream", "sward", "swamp", "tarn", "terrace", "tide",
    "timber", "torrent", "tract", "trail", "vale", "vein", "wadi",
    "weald", "weir", "wetland", "wood", "yarrow", "knot", "lode", "loft",
)

_ANIMALS: tuple[str, ...] = (
    "adder", "asp", "auks", "badger", "bat", "bear", "bee", "bison",
    "boar", "buck", "bull", "bunting", "crane", "crow", "cub", "deer",
    "dove", "drake", "duck", "eagle", "elk", "erne", "falcon", "fawn",
    "finch", "fish", "fox", "frog", "gnat", "goat", "goose", "grebe",
    "grouse", "gull", "hare", "hart", "hawk", "heron", "horse", "hound",
    "ibis", "jay", "kite", "koel", "lamb", "lark", "linnet", "lion",
    "lynx", "mink", "mole", "moose", "moth", "newt", "osprey", "otter",
    "owl", "ox", "pike", "plover", "polecat", "pony", "puffin", "ram",
    "raven", "redstart", "robin", "rook", "roach", "salmon", "seal",
    "shrew", "snipe", "sparrow", "stag", "starling", "stoat", "stork",
    "swallow", "swan", "swift", "teal", "thrush", "toad", "trout",
    "vole", "wasp", "weasel", "whale", "wildcat", "wolf", "wren",
    "yellowhammer", "bream", "chaffinch", "chat", "coot", "dace",
    "darter", "dunnock", "egret", "fieldfare", "gadwall", "garganey",
    "goshawk", "harrier", "hobby", "jackdaw", "kestrel", "kingfisher",
    "lapwing", "martin", "merlin", "nightjar", "nuthatch", "peregrine",
    "pipit", "redshank", "sandpiper", "shoveler", "siskin", "treecreeper",
)


# ── Public API ────────────────────────────────────────────────────────────────

def new_phrase_id() -> str:
    """Return a random three-word phrase usable as a session identifier.

    Example return values: ``swift-cedar-fox``, ``pale-tarn-wren``.
    """
    adj = random.choice(_ADJECTIVES)  # noqa: S311
    noun = random.choice(_NOUNS)      # noqa: S311
    animal = random.choice(_ANIMALS)  # noqa: S311
    return f"{adj}-{noun}-{animal}"
