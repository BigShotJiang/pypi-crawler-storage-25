"""Centralized Bedrock client creation and authentication.

Eliminates the ~60-line API-key-vs-SSO branching block that was previously
duplicated across every command that calls the Bedrock Converse API.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from alice_cli import personality
from alice_cli.auth import detect_identity_from_key, detect_username
from alice_cli.aws.bedrock import BedrockClient
from alice_cli.aws.session import get_session
from alice_cli.console import print_status, spinner
from alice_cli.logging import get_logger
from alice_cli.secrets import build_secret_path, fetch_credentials

if TYPE_CHECKING:
    from alice_cli.models import CLIConfig

log = get_logger(__name__)


@dataclass
class BedrockContext:
    """Authenticated context for Bedrock operations.

    Attributes:
        client: boto3 bedrock-runtime client, ready to call ``converse()``.
        username: User's JHED identifier (extracted from STS or API key alias).
        inference_profile_arns: Mapping of model alias → inference profile ARN.
            Pass this to ``resolve_model_id()`` when resolving model aliases.
        config: The CLI configuration used to create this context.
    """

    client: Any
    username: str
    inference_profile_arns: dict[str, str]
    config: CLIConfig


def create_bedrock_context(config: CLIConfig) -> BedrockContext:
    """Authenticate and return a ready-to-use Bedrock context.

    Handles both API-key mode and SSO profile mode transparently.

    **API-key mode** (``config.bedrock_secret_key`` is set, ``config.profile``
    is unset): skips STS and Secrets Manager, uses the stored key directly.

    **SSO profile mode**: calls STS ``get-caller-identity`` to detect the JHED,
    then fetches credentials from Secrets Manager to obtain inference profile ARNs.

    Args:
        config: Resolved CLI configuration.

    Returns:
        BedrockContext with authenticated client and inference profile ARNs.

    Raises:
        AuthError: If STS identity detection fails.
        SecretError: If credentials cannot be fetched from Secrets Manager.

    Example::

        context = create_bedrock_context(config)
        resolved_id = resolve_model_id(model_alias, context.inference_profile_arns)
        response = context.client.converse(modelId=resolved_id, messages=[...])
    """
    if config.profile:
        # ── SSO Profile Mode ──────────────────────────────────────────────────
        # When a profile is specified, permanently remove the IAM/API-key
        # credential env vars for this process lifetime.  botocore's EnvProvider
        # runs *first* in the credential chain, so leaving AWS_ACCESS_KEY_ID (or
        # AWS_BEARER_TOKEN_BEDROCK) set causes every boto3 client — including
        # third-party SDKs like bedrock-agentcore — to silently use the API-key
        # identity instead of the SSO role, even when profile_name is explicit.
        import os as _os

        for _var in (
            "AWS_ACCESS_KEY_ID",
            "AWS_SECRET_ACCESS_KEY",
            "AWS_SESSION_TOKEN",
            "AWS_BEARER_TOKEN_BEDROCK",
        ):
            _os.environ.pop(_var, None)

        with spinner(personality.status_detecting_identity(), config.quiet):
            result = detect_username(config.profile, config.region)
        username = result.username
        print_status(personality.status_identity_detected(username), config.quiet)

        secret_path = build_secret_path(config.namespace, config.environment, username)
        assert config.profile is not None  # detect_username() already raised if profile is None
        with spinner(personality.status_fetching_secret(), config.quiet):
            creds = fetch_credentials(config.profile, config.region, secret_path)

        log.debug(
            "bedrock_context_created",
            auth_mode="sso",
            username=username,
            profile=config.profile,
            has_inference_profiles=bool(creds.inference_profile_arns),
        )

        session = get_session(profile=config.profile, region=config.region)
        # Application inference profile ARNs live in the Bedrock service
        # account and are not accessible cross-account via an SSO role.
        # Pass None so resolve_model_id falls back to cross-region model IDs
        # (e.g. us.anthropic.claude-sonnet-4-6) — matching alice auth --claude.
        return BedrockContext(
            client=BedrockClient.from_session(session),
            username=username,
            inference_profile_arns={},
            config=config,
        )

    else:
        # ── API Key Mode ──────────────────────────────────────────────────────
        # Used when no SSO profile is configured (e.g. BEDROCK_SECRET_KEY env
        # var alone, or explicit --api-key flag without --profile).
        username = detect_identity_from_key(config.bedrock_access_key)
        print_status(personality.status_using_api_key(username), config.quiet)
        log.debug("bedrock_context_created", auth_mode="api_key", username=username)

        session = get_session(
            region=config.region,
            access_key=config.bedrock_access_key or "",
            secret_key=config.bedrock_secret_key or "",
        )
        return BedrockContext(
            client=BedrockClient.from_session(session),
            username=username,
            inference_profile_arns=config.inference_profile_arns or {},
            config=config,
        )
