"""
tests/test_autosuture.py — Tests de l'Auto-Suture autonome (Phase 12).
"""

import os
import shutil
import tempfile
from unittest.mock import patch, MagicMock

from phi_complexity.autosuture import AutoSuture

CODE_HARMONIEUX = '''\
def ajouter(a: float, b: float) -> float:
    """Additionne deux nombres."""
    return a + b

def multiplier(a: float, b: float) -> float:
    """Multiplie deux nombres."""
    return a * b
'''

CODE_CHAOTIQUE = """\
def f(x,y,z,w,v):
    r=0
    for i in range(x):
        for j in range(y):
            for k in range(z):
                for l in range(w):
                    for m in range(v):
                        r+=i*j*k*l*m
    return r
"""


def _creer_fichier(contenu: str) -> str:
    f = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", delete=False, encoding="utf-8"
    )
    f.write(contenu)
    f.close()
    return f.name


class TestAutoSuture:

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp()

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    # ──────────────── _extraire_code() ────────────────

    def test_extraire_code_bloc_python(self):
        """Extrait le code d'un bloc ```python ... ```."""
        autosuture = AutoSuture.__new__(AutoSuture)
        reponse = "Texte\n```python\nx = 1\n```\nFin"
        code = autosuture._extraire_code(reponse)
        assert code == "x = 1"

    def test_extraire_code_bloc_generique(self):
        """Extrait le code d'un bloc ``` ... ``` sans langage."""
        autosuture = AutoSuture.__new__(AutoSuture)
        reponse = "Texte\n```\ny = 2\n```\nFin"
        code = autosuture._extraire_code(reponse)
        assert code == "y = 2"

    def test_extraire_code_aucun_bloc(self):
        """Retourne None si aucun bloc de code n'est trouvé."""
        autosuture = AutoSuture.__new__(AutoSuture)
        code = autosuture._extraire_code("Pas de code ici.")
        assert code is None

    def test_extraire_code_prend_le_plus_long(self):
        """S'il y a plusieurs blocs, prend le plus long."""
        autosuture = AutoSuture.__new__(AutoSuture)
        reponse = "```python\ncourt\n```\n```python\nbloc beaucoup plus long ici\n```"
        code = autosuture._extraire_code(reponse)
        assert code == "bloc beaucoup plus long ici"

    # ──────────────── guerir() — radiance élevée ────────────────

    def test_guerir_radiance_elevee_sans_force(self):
        """Si la radiance >= 85 et force=False, pas de guérison."""
        fichier = _creer_fichier(CODE_HARMONIEUX)
        try:
            with (
                patch("phi_complexity.autosuture.SutureAgent") as MockAgent,
                patch("phi_complexity.autosuture.SecuriteMaat") as MockSec,
            ):
                mock_agent = MagicMock()
                MockAgent.return_value = mock_agent
                mock_sec = MagicMock()
                MockSec.return_value = mock_sec

                # Forcer une radiance haute en mockant l'analyseur
                with patch("phi_complexity.autosuture.AnalyseurPhi") as MockAnalyseur:
                    mock_res = MagicMock()
                    mock_res.radiance = 90.0
                    mock_res.resistance = 0.1
                    mock_res.fonctions = []
                    mock_res.annotations = []
                    MockAnalyseur.return_value.analyser.return_value = mock_res

                    autosuture = AutoSuture()
                    verdict = autosuture.guerir(fichier, force=False)

                assert "STABLE" in verdict or "Aucune guérison" in verdict
        finally:
            os.unlink(fichier)

    def test_guerir_radiance_elevee_avec_force(self):
        """Avec force=True, la guérison est tentée même si la radiance est haute."""
        fichier = _creer_fichier(CODE_HARMONIEUX)
        try:
            with (
                patch("phi_complexity.autosuture.SutureAgent") as MockAgent,
                patch("phi_complexity.autosuture.SecuriteMaat") as MockSec,
                patch("phi_complexity.autosuture.AnalyseurPhi") as MockAnalyseur,
            ):

                mock_res = MagicMock()
                mock_res.radiance = 90.0
                mock_res.resistance = 0.1
                mock_res.fonctions = []
                mock_res.annotations = []
                MockAnalyseur.return_value.analyser.return_value = mock_res

                mock_agent = MagicMock()
                mock_agent.suturer.return_value = ""  # Aucun code valide
                MockAgent.return_value = mock_agent

                mock_sec = MagicMock()
                MockSec.return_value = mock_sec

                autosuture = AutoSuture()
                verdict = autosuture.guerir(fichier, force=True)

            # La suture retourne "ÉCHEC DE SUTURE" car pas de code valide
            assert "ÉCHEC" in verdict or "SUTURE" in verdict or "GUÉRISON" in verdict
        finally:
            os.unlink(fichier)

    def test_guerir_suture_invalide_retourne_echec(self):
        """Si l'IA ne renvoie pas de code valide, le verdict est ÉCHEC."""
        fichier = _creer_fichier(CODE_CHAOTIQUE)
        try:
            with (
                patch("phi_complexity.autosuture.SutureAgent") as MockAgent,
                patch("phi_complexity.autosuture.SecuriteMaat") as MockSec,
                patch("phi_complexity.autosuture.AnalyseurPhi") as MockAnalyseur,
                patch(
                    "phi_complexity.autosuture.calculer_sync_index", return_value=0.5
                ),
            ):

                mock_res = MagicMock()
                mock_res.radiance = 40.0
                mock_res.resistance = 0.8
                mock_res.fonctions = [MagicMock()]
                mock_res.annotations = []
                MockAnalyseur.return_value.analyser.return_value = mock_res

                mock_agent = MagicMock()
                mock_agent.suturer.return_value = "Aucun bloc de code."
                MockAgent.return_value = mock_agent

                mock_sec = MagicMock()
                MockSec.return_value = mock_sec

                autosuture = AutoSuture()
                verdict = autosuture.guerir(fichier, force=False)

            assert "ÉCHEC" in verdict
        finally:
            os.unlink(fichier)

    def test_guerir_injection_echoue_restaure_backup(self):
        """Si l'écriture échoue, restauration et message ERREUR D'INJECTION (lignes 47-52)."""
        fichier = _creer_fichier(CODE_CHAOTIQUE)
        try:
            with (
                patch("phi_complexity.autosuture.SutureAgent") as MockAgent,
                patch("phi_complexity.autosuture.SecuriteMaat") as MockSec,
                patch("phi_complexity.autosuture.AnalyseurPhi") as MockAnalyseur,
                patch(
                    "phi_complexity.autosuture.calculer_sync_index", return_value=0.3
                ),
            ):
                mock_res = MagicMock()
                mock_res.radiance = 40.0
                mock_res.resistance = 0.8
                MockAnalyseur.return_value.analyser.return_value = mock_res

                mock_agent = MagicMock()
                mock_agent.suturer.return_value = "```python\nprint('fix')\n```"
                MockAgent.return_value = mock_agent

                mock_sec = MagicMock()
                MockSec.return_value = mock_sec

                autosuture = AutoSuture()

                # Mock open to raise IOError on write
                with patch("builtins.open", side_effect=IOError("disk full")):
                    verdict = autosuture.guerir(fichier, force=False)

                assert "ERREUR D'INJECTION" in verdict
                mock_sec.restaurer_dernier.assert_called_once_with(fichier)
        finally:
            if os.path.exists(fichier):
                os.unlink(fichier)

    def test_guerir_code_invalide_restaure_backup(self):
        """Si le code injecté est invalide (SyntaxError), restauration (lignes 55-60)."""
        fichier = _creer_fichier(CODE_CHAOTIQUE)
        try:
            with (
                patch("phi_complexity.autosuture.SutureAgent") as MockAgent,
                patch("phi_complexity.autosuture.SecuriteMaat") as MockSec,
                patch("phi_complexity.autosuture.AnalyseurPhi") as MockAnalyseur,
                patch(
                    "phi_complexity.autosuture.calculer_sync_index", return_value=0.3
                ),
            ):
                mock_res = MagicMock()
                mock_res.radiance = 40.0
                mock_res.resistance = 0.8
                MockAnalyseur.return_value.analyser.side_effect = [
                    mock_res,  # avant
                    Exception("SyntaxError"),  # après injection
                ]

                mock_agent = MagicMock()
                mock_agent.suturer.return_value = "```python\nprint('fix')\n```"
                MockAgent.return_value = mock_agent

                mock_sec = MagicMock()
                MockSec.return_value = mock_sec

                autosuture = AutoSuture()
                verdict = autosuture.guerir(fichier, force=False)

                assert "ALERTE ENTROPIE" in verdict
                mock_sec.restaurer_dernier.assert_called_once_with(fichier)
        finally:
            if os.path.exists(fichier):
                os.unlink(fichier)

    def test_guerir_code_ameliore_succes(self):
        """Code amélioré (sync_index gain > 0) → GUÉRISON RÉUSSIE (lignes 63-65)."""
        fichier = _creer_fichier(CODE_CHAOTIQUE)
        try:
            with (
                patch("phi_complexity.autosuture.SutureAgent") as MockAgent,
                patch("phi_complexity.autosuture.SecuriteMaat") as MockSec,
                patch("phi_complexity.autosuture.AnalyseurPhi") as MockAnalyseur,
                patch("phi_complexity.autosuture.calculer_sync_index") as MockSync,
            ):
                mock_res_avant = MagicMock()
                mock_res_avant.radiance = 40.0
                mock_res_avant.resistance = 0.8

                mock_res_apres = MagicMock()
                mock_res_apres.radiance = 85.0
                mock_res_apres.resistance = 0.2

                MockAnalyseur.return_value.analyser.side_effect = [
                    mock_res_avant,
                    mock_res_apres,
                ]

                # sync_index: avant=0.3, après=0.8 → gain > 0
                MockSync.side_effect = [0.3, 0.8]

                mock_agent = MagicMock()
                mock_agent.suturer.return_value = "```python\nprint('fix')\n```"
                MockAgent.return_value = mock_agent

                mock_sec = MagicMock()
                MockSec.return_value = mock_sec

                autosuture = AutoSuture()
                verdict = autosuture.guerir(fichier, force=False)

                assert "GUÉRISON RÉUSSIE" in verdict
        finally:
            if os.path.exists(fichier):
                os.unlink(fichier)

    def test_guerir_code_pas_ameliore_restaure(self):
        """Code pas amélioré et force=False → SUTURE REJETÉE (lignes 66-69)."""
        fichier = _creer_fichier(CODE_CHAOTIQUE)
        try:
            with (
                patch("phi_complexity.autosuture.SutureAgent") as MockAgent,
                patch("phi_complexity.autosuture.SecuriteMaat") as MockSec,
                patch("phi_complexity.autosuture.AnalyseurPhi") as MockAnalyseur,
                patch("phi_complexity.autosuture.calculer_sync_index") as MockSync,
            ):
                mock_res_avant = MagicMock()
                mock_res_avant.radiance = 40.0
                mock_res_avant.resistance = 0.8

                mock_res_apres = MagicMock()
                mock_res_apres.radiance = 35.0
                mock_res_apres.resistance = 0.9

                MockAnalyseur.return_value.analyser.side_effect = [
                    mock_res_avant,
                    mock_res_apres,
                ]

                # sync_index: avant=0.5, après=0.4 → gain < 0
                MockSync.side_effect = [0.5, 0.4]

                mock_agent = MagicMock()
                mock_agent.suturer.return_value = "```python\nprint('worse')\n```"
                MockAgent.return_value = mock_agent

                mock_sec = MagicMock()
                MockSec.return_value = mock_sec

                autosuture = AutoSuture()
                verdict = autosuture.guerir(fichier, force=False)

                assert "SUTURE REJETÉE" in verdict
                mock_sec.restaurer_dernier.assert_called_once_with(fichier)
        finally:
            if os.path.exists(fichier):
                os.unlink(fichier)
