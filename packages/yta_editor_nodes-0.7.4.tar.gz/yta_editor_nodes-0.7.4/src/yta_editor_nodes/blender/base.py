from yta_editor_nodes.abstract import _ProcessorGPUAndCPUConfigured
from yta_editor_parameters.specifications import ParameterSpecification


class _Blender(
    _ProcessorGPUAndCPUConfigured
):
    """
    *For internal use only*

    This class must be inherited by the specific
    implementation of some blenders that will use
    CPU or GPU (at least one of the options).

    Class that is capable of mixing 2 different
    inputs by using the GPU or the CPU.

    Mandatory inputs:
    - `base_input`
    - `overlay_input`

    Optional inputs:
    - `None`

    Parameters:
    - `*mix_weight`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """
    _is_marker: bool = True
    """
    *For internal use only*

    Internal flag to identify it as a marker class
    that is not providing a very specific
    implementation at all.

    This marker will make the `cpu_class` and
    `gpu_class` attributes validation be omitted.
    """
    mandatory_inputs = ['base_input', 'overlay_input']
    optional_inputs = []
    parameters_specifications = [
        ParameterSpecification(
            name = 'mix_weight',
            type = float,
            is_required = True,
            default = 1.0,
            min = 0.01,
            max = 1.0
        )
    ]