from yta_editor_nodes.blender.base import _Blender
from yta_editor_parameters.specifications import ParameterSpecification
from yta_editor_nodes_cpu.blender.mix import MixBlenderCPU
from yta_editor_nodes_gpu.blender.mix import MixBlenderGPU


class MixBlender(_Blender):
    """
    A blender that uses a float value to mix the
    result with the original input as much as that
    value determines.

    Mandatory inputs:
    - `base_input`
    - `overlay_input`

    Optional inputs:
    - `None`

    Parameters:
    - `*mix_weight`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """

    mandatory_inputs = ['base_input', 'overlay_input']
    optional_inputs = []
    parameters_specifications = [
        ParameterSpecification(
            name = 'mix_weight',
            type = float,
            is_required = True,
            default = 1.0,
            min = 0.01,
            max = 1.0
        )
    ]
    cpu_class = MixBlenderCPU
    gpu_class = MixBlenderGPU