from yta_editor_nodes.blender.base import _Blender
from yta_editor_parameters.specifications import ParameterSpecification
from yta_editor_nodes_cpu.blender.alpha import AlphaBlenderCPU
from yta_editor_nodes_gpu.blender.alpha import AlphaBlenderGPU


class AlphaBlender(_Blender):
    """
    The most common blender used in video edition.

    This blender will use the alpha channel of the 
    overlay input, multiplied by the `blend_strength`
    parameter provided, to use it as the mixer factor
    between the base and the overlay inputs.

    Mandatory inputs:
    - `base_input`
    - `overlay_input`

    Optional inputs:
    - `None`

    Parameters:
    - `*mix_weight`
    - `*blend_strength`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """

    mandatory_inputs = ['base_input', 'overlay_input']
    optional_inputs = []
    parameters_specifications = [
        ParameterSpecification(
            name = 'mix_weight',
            type = float,
            is_required = True,
            default = 1.0,
            min = 0.01,
            max = 1.0
        ),
        ParameterSpecification(
            name = 'blend_strength',
            type = float,
            is_required = True,
            default = 1.0,
            min = 0.01,
            max = 1.0
        )
    ]
    cpu_class = AlphaBlenderCPU
    gpu_class = AlphaBlenderGPU