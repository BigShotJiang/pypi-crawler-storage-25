from yta_editor_nodes.processor.base import _NodeProcessor
from yta_editor_nodes_cpu.processor.selection_mask import SelectionMaskNodeProcessorCPU
from yta_editor_nodes_gpu.processor.selection_mask import SelectionMaskNodeProcessorGPU


class SelectionMaskNodeProcessor(
    _NodeProcessor
):
    """
    Class to use a mask selection (from which we will
    determine if the pixel must be applied or not) to
    apply the processed input over the original one.

    If the selection mask is completely full, the
    result will be the processed input.

    Mandatory inputs:
    - `original_input`
    - `processed_input`
    - `selection_mask_input`

    Optional inputs:
    - `None`

    Parameters:
    - `factor`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """
    
    mandatory_inputs = ['original_input', 'processed_input', 'selection_mask_input']
    optional_inputs = []
    parameters_specifications = []
    cpu_class = SelectionMaskNodeProcessorCPU
    gpu_class = SelectionMaskNodeProcessorGPU