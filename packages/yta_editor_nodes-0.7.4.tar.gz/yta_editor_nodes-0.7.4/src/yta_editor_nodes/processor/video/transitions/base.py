from yta_editor_nodes.abstract import _ProcessorGPUAndCPUConfigured


class _TransitionProcessor(
    _ProcessorGPUAndCPUConfigured
):
    """
    *For internal use only*

    *This class must be inherited by the specific
    implementation of some transition that will be
    done by CPU or GPU (at least one of the options)*

    Class that is capable of doing some processing on
    an input by using the GPU or the CPU.

    Mandatory inputs:
    - `first_input`
    - `second_input`

    Optional inputs:
    - `None`

    Parameters:
    - `None`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """
    _is_marker: bool = True
    """
    *For internal use only*

    Internal flag to identify it as a marker class
    that is not providing a very specific
    implementation at all.

    This marker will make the `cpu_class` and
    `gpu_class` attributes validation be omitted.
    """
    mandatory_inputs = ['first_input', 'second_input']
    optional_inputs = []
    parameters_specifications = []
