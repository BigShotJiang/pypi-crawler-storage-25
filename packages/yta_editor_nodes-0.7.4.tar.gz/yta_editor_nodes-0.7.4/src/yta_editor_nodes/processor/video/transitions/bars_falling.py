from yta_editor_nodes.processor.video.transitions.base import _TransitionProcessor
from yta_editor_parameters.specifications import ParameterSpecification
from yta_editor_nodes_gpu.processor.video.transitions.bars_falling import BarsFallingTransitionNodeProcessorGPU


class BarsFallingTransitionProcessor(_TransitionProcessor):
    """
    A transition between the frames of 2 videos in which
    a set of bars fall with the first video to let the
    second one be seen.

    Class that is capable of doing some processing on
    an input by using the GPU or the CPU.

    Mandatory inputs:
    - `first_input`
    - `second_input`

    Optional inputs:
    - `None`
    
    Parameters:
    - `*number_of_bars`
    - `*amplitude`
    - `*noise`
    - `*frequency`
    - `*drip_scale`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """

    mandatory_inputs = ['first_input', 'second_input']
    optional_inputs = []
    parameters_specifications = [
        ParameterSpecification(
            name = 'number_of_bars',
            type = int,
            is_required = True,
            default = 30,
            min = 5,
            max = 100
        ),
        ParameterSpecification(
            name = 'amplitude',
            type = float,
            is_required = True,
            default = 2.0,
            min = 0.1,
            max = 10.0
        ),
        ParameterSpecification(
            name = 'noise',
            type = float,
            is_required = True,
            default = 0.1,
            min = 0.001,
            max = 1.0
        ),
        ParameterSpecification(
            name = 'frequency',
            type = float,
            is_required = True,
            default = 0.5,
            min = 0.001,
            max = 2.0
        ),
        ParameterSpecification(
            name = 'drip_scale',
            type = float,
            is_required = True,
            default = 0.5,
            min = 0.001,
            max = 5.0
        )
    ]
    cpu_class = None
    gpu_class = BarsFallingTransitionNodeProcessorGPU