from yta_editor_nodes.processor.video.transitions.base import _TransitionProcessor
from yta_editor_nodes_gpu.processor.video.transitions.crossfade import CrossfadeTransitionNodeProcessorGPU


class CrossfadeTransitionProcessor(_TransitionProcessor):
    """
    A transition between the frames of 2 videos,
    transforming the first one into the second one.

    Class that is capable of doing some processing on
    an input by using the GPU or the CPU.

    Mandatory inputs:
    - `first_input`
    - `second_input`

    Optional inputs:
    - `None`
         
    Parameters:
    - `None`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """

    mandatory_inputs = ['first_input', 'second_input']
    optional_inputs = []
    parameters_specifications = []
    cpu_class = None
    gpu_class = CrossfadeTransitionNodeProcessorGPU