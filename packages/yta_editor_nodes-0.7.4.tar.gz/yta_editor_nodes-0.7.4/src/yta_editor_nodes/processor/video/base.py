from yta_editor_nodes.processor.base import _NodeProcessor


class _VideoNodeProcessor(_NodeProcessor):
    """
    *For internal use only*
    
    This class must be inherited by the specific
    implementation of some effect that will be done by
    CPU or GPU (at least one of the options).

    Class that is capable of doing some processing on
    an input by using the GPU or the CPU, but for 
    video frames, including a `t` time moment parameter
    when processing.

    Mandatory inputs:
    - `base_input`

    Optional inputs:
    - `None`

    Parameters:
    - `None`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """
    _is_marker: bool = True
    """
    *For internal use only*

    Internal flag to identify it as a marker class
    that is not providing a very specific
    implementation at all.

    This marker will make the `cpu_class` and
    `gpu_class` attributes validation be omitted.
    """
    mandatory_inputs = ['base_input']
    optional_inputs = []
    parameters_specifications = []