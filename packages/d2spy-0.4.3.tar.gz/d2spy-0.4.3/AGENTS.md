# Repository Guidelines

This file provides guidance for developers and AI assistants (like Claude Code at claude.ai/code) when working with code in this repository.

## Project Overview
d2spy is a Python client library for interacting with Data to Science (D2S) instances. It provides a high-level API for managing projects, flights, and geospatial data products (rasters, point clouds) with built-in authentication and automatic token refresh.

### Optional Dependencies
The package supports two installation modes:

**Core Installation (`d2spy`):**
- Minimal dependencies (only `requests`)
- Full API access: authentication, project/flight management, data uploads
- Server-side analysis tools: NDVI, ExG, zonal statistics (job submission)
- Ideal for lightweight integrations, CI/CD, or environments where geo libraries are already present

**Geo Installation (`d2spy[geo]`):**
- Includes `rasterio`, `geopandas`, `exifread`
- Adds client-side geospatial processing: raster clipping, EXIF extraction, bounding box generation
- Required for: `DataProduct.clip()`, `get_exif_data()`, `get_bounding_box_from_exif_data()`

The geo features use lazy imports—code gracefully raises `ImportError` with installation instructions if geo dependencies are missing.

## Architecture Overview

### Layered Design
The codebase follows a clear layered architecture with separation of concerns:

```
User API Layer (workspace.py)
    ↓
Domain Models Layer (models/)
    ↓
Schema Layer (schemas/)
    ↓
HTTP Client Layer (api_client.py)
    ↓
Authentication Layer (auth.py)
```

### Component Relationships
- **Workspace**: Entry point via `Workspace.connect()`; manages session lifecycle and project CRUD
- **Project**: Represents a spatial project; manages flights and map layers
- **Flight**: Represents a temporal snapshot; manages data product uploads
- **DataProduct**: Represents raster/point cloud; provides analysis tools (clip, NDVI, zonal stats)
- **Collection classes** (`*_collection.py`): Provide filtering and list-like access to resources

### Key Patterns
- **Schema → Model transformation**: API responses deserialize through schemas (`from_dict()`) then wrap into models
- **Flexible initialization**: Models accept `**kwargs` and use `self.__dict__.update(kwargs)` for future-proof API compatibility
- **Automatic token refresh**: `APIClient` transparently handles 401 errors by refreshing tokens and retrying requests (thread-safe with locking)
- **Collection filtering**: Chainable methods like `flights.filter(name="Survey")` for resource queries

## Project Structure & Module Organization
- `d2spy/` hosts the package modules: `api_client.py`, `auth.py`, and `workspace.py` manage API workflows; `models/` wraps API responses; `schemas/` contains dataclass types; `extras/` includes TUS upload client and geospatial utilities; `utils/` exposes logging helpers.
  - `d2spy/extras/utils.py`: Core utilities (no geo dependencies) - file validation, response formatting
  - `d2spy/extras/geo.py`: Geospatial utilities (requires `d2spy[geo]`) - raster clipping, EXIF extraction
  - Backward compatibility: `extras/utils.py` re-exports geo functions as lazy imports
- `tests/` mirrors package modules with pytest cases, shared fixtures in `example_data.py`, and sample payloads under `tests/data/`.
- `docs/` is the MkDocs site; update Markdown and notebooks under `docs/` and `tutorial/` when you add features. Generated wheels live in `dist/`—do not edit them.

## Build, Test, and Development Commands

### Environment Setup
- `uv sync` resolves dependencies into the virtualenv (core only)
- `uv sync --extra geo` includes geospatial dependencies (rasterio, geopandas, exifread)
- `uv sync --group docs` includes documentation dependencies
- `uv sync --group test` includes test dependencies
- `uv sync --group dev` includes development dependencies
- `uv run pre-commit install` sets up pre-commit hooks for automatic code quality checks

**Note:** Tests require geo extras to be installed (`uv sync --extra geo`) since they test both core and geo functionality.

### Testing
- `uv run pytest` runs the full unit test suite
- `uv run pytest tests/test_api_client.py` targets a specific test file
- `uv run pytest tests/test_auth.py::TestAuth::test_login_success` runs a specific test method
- `uv run pytest -v` shows verbose output with individual test names
- `uv run pytest --cov=d2spy` runs tests with coverage report
- `uv run pytest -k refresh` runs only tests matching "refresh" keyword

### Code Quality
- `uv run black d2spy tests` formats code with Black (88-char line length)
- `uv run flake8 d2spy tests` runs linter checks
- `uv run mypy d2spy` runs type checking
- `uv run pre-commit run --all-files` runs all pre-commit hooks manually

### Documentation
- `uv run mkdocs serve` builds docs locally at `http://127.0.0.1:8000`
- `uv run mkdocs build` generates static documentation site
- `uv run mkdocs gh-deploy` deploys documentation to GitHub Pages

### Building & Publishing
- `uv build` creates distribution packages in `dist/`
- `uv publish` uploads package to PyPI (requires credentials)

## Authentication Flow

### Multi-Stage Authentication
1. User calls `Workspace.connect(base_url, email, password)` (credentials from args, env vars, or prompt)
2. `Auth.login()` sends credentials to `/api/v1/auth/access-token`
3. Server returns `access_token` and `refresh_token` (stored in session cookies)
4. Tokens normalized in `D2SpySession.cookies`:
   - **Localhost**: No domain specified (avoids port-matching issues)
   - **Other hosts**: Domain set to hostname
5. `Auth.get_current_user()` validates login and stores user's API key in `session.d2s_data["API_KEY"]`

### Automatic Token Refresh
- On 401 error, `APIClient` automatically refreshes tokens and retries the request
- Thread-safe: Uses `threading.Lock()` to prevent concurrent refresh attempts
- POST to `/api/v1/auth/refresh-token` with `refresh_token` cookie
- On success: Updates cookies and retries original request transparently
- On failure: Clears session and raises error

### Credential Sources (Priority Order)
1. Method arguments (`email`, `password`)
2. Environment variables (`D2S_EMAIL`, `D2S_PASSWORD`)
3. Interactive prompt (uses `getpass` for password)

## Data Operations

### Data Upload (TUS Protocol)
Data products and raw data upload via TUS (resumable upload protocol) in 10 MiB chunks:

**Rasters (DSM, Ortho):**
```python
flight.add_data_product(filepath="/path/to/dsm.tif", data_type="dsm")
```
- Uploads to `/files` endpoint with headers: `X-Project-ID`, `X-Flight-ID`, `X-Data-Type`
- File validation: `.tif` → `dsm` or `ortho` only (NOT `point_cloud`)

**Point Clouds (LAS/LAZ):**
```python
flight.add_data_product(filepath="/path/to/pointcloud.las", data_type="point_cloud")
```
- File validation: `.las/.laz` → `point_cloud` only
- Data type must be < 16 characters

**Raw Data:**
```python
flight.add_raw_data(filepath="/path/to/data.zip")
```
- Uses same TUS flow with `X-Data-Type: "raw"`

### Data Product Analysis Tools
`DataProduct` objects provide raster analysis methods:

**Client-side (requires `d2spy[geo]`):**
- `clip(geojson_feature, out_raster)`: Clip raster by polygon using rasterio; supports VRT export
  - Uses lazy import: raises `ImportError` if geo dependencies not installed
  - Handles 401 errors by retrying with `D2S_API_KEY` environment variable

**Server-side (core package, no geo dependencies required):**
- `derive_ndvi(red_band_idx, nir_band_idx)`: POST async job to server for NDVI calculation
- `derive_exg(red_idx, green_idx, blue_idx)`: POST async job for Excess Green index
- `get_band_info()`: Returns STAC EO extension band metadata
- `update_band_info(band_info)`: PUT to update band descriptions
- `generate_zonal_statistics(zonal_layer_id)`: POST async job for zonal stats
- `get_zonal_statistics(zonal_layer_id, wait=True, timeout=300)`: Poll for results or return immediately

### Async Job Handling
- Server returns **202 status** for accepted async jobs
- User must poll separately with GET requests
- Use `wait=True` parameter where available to block until completion

## Key Design Patterns

### Schema → Model Transformation
API responses follow a consistent deserialization pattern:
```python
# Step 1: API returns raw dict
response_data = client.make_get_request("/api/v1/projects/123")

# Step 2: Schema deserializes and validates
project_schema = schemas.Project.from_dict(response_data)
# Handles: UUID parsing, date deserialization, field mapping

# Step 3: Model wraps schema for behavior
project_model = models.Project(client, **project_schema.__dict__)
# Adds: add_flight(), get_flights(), update(), etc.
```

### Flexible Model Initialization
All domain models use `**kwargs` for forward compatibility:
```python
class Flight:
    def __init__(self, client: APIClient, **kwargs):
        self.client = client
        self.__dict__.update(kwargs)  # Dynamically set all attributes
```
Benefits: Works with partial responses, handles new API fields, maintains backward compatibility

### Dependency Injection
Models receive dependencies through constructors:
- `APIClient` injected into all models for making requests
- `D2SpySession` passed to maintain authentication state
- Enables testing with mocked dependencies

### Collection Pattern
Collection classes provide filtering without polluting model APIs:
```python
flights = project.get_flights()  # Returns FlightCollection
recent = flights.filter(name="Survey")  # Chainable filtering
for flight in recent:  # Iterable
    print(flight.name)
```

### Thread-Safe Token Refresh
`APIClient` uses locking to handle concurrent 401 errors:
- First thread acquires `_refresh_lock` and refreshes tokens
- Other threads wait and reuse the refreshed tokens
- Prevents token refresh storms from parallel requests

## API Conventions

### REST Endpoint Structure
```
GET    /api/v1/{resources}           → List all
GET    /api/v1/{resources}/{id}      → Get single
POST   /api/v1/{resources}           → Create
PUT    /api/v1/{resources}/{id}      → Update

Nested resources:
POST   /api/v1/projects/{p_id}/flights
GET    /api/v1/projects/{p_id}/flights/{f_id}/data_products
```

### Status Code Handling
- **200**: Success (GET, PUT)
- **201**: Resource created (POST)
- **202**: Async job accepted (POST to `/tools` endpoints) - poll separately
- **401**: Unauthorized - triggers automatic token refresh and retry

### Response Validation
Helper functions ensure correct response types:
- `ensure_dict(response)`: Validates single resource response
- `ensure_list_of_dict(response)`: Validates collection response
- Raises `ValueError` on unexpected types or empty lists

### API Versioning
All endpoints prefixed with `/api/v1/` for version isolation

## Implementation Notes

### Logging
Central logger configured in `d2spy/utils/logging_config.py`:
```python
from d2spy.utils.logging_config import get_logger
logger = get_logger(__name__)

# Usage in module
logger.info("Operation succeeded")
logger.warning("Non-fatal issue")
logger.error("Error occurred")
```
- Logger automatically named with module path (e.g., `d2spy.api_client`)
- Configured on package import via `d2spy/__init__.py`

### Optional Geo Dependencies Pattern

The package uses lazy imports to avoid hard dependencies on geospatial libraries:

**Module Structure:**
- `d2spy/extras/geo.py`: Contains all geo-dependent code
  - Top-level try/except imports `rasterio`, `geopandas`, `exifread`
  - Sets `HAS_GEO = True/False` flag
  - `require_geo()` helper raises friendly error if dependencies missing

**Lazy Import in Models:**
```python
# In d2spy/models/data_product.py
def _lazy_import_clip_by_mask():
    """Lazy import of clip_by_mask to avoid requiring geo extras."""
    try:
        from d2spy.extras.geo import clip_by_mask
        return clip_by_mask
    except ImportError:
        raise ImportError(
            "clip_by_mask requires geospatial dependencies.\n"
            "Install with: pip install d2spy[geo]"
        )

def clip(self, geojson_feature, out_raster):
    clip_by_mask = _lazy_import_clip_by_mask()  # Import only when called
    clip_by_mask(self.url, geojson_feature, out_raster)
```

**Backward Compatibility:**
- `d2spy/extras/utils.py` re-exports geo functions as lazy imports
- Old code using `from d2spy.extras.utils import clip_by_mask` still works
- Raises same helpful error if geo dependencies not installed

**Testing Geo Features:**
- Mock imports at correct location: `@patch("d2spy.extras.geo.clip_by_mask")`
- NOT at model location: `@patch("d2spy.models.data_product.clip_by_mask")` (doesn't exist)

### Third-Party Code
- `d2spy/extras/third_party/tusclient/` contains TUS (resumable upload) protocol client
- Excluded from flake8 linting (see `.pre-commit-config.yaml`)
- Used for chunked file uploads (10 MiB chunks)

### File Validation
Data type and extension validation in `d2spy/extras/utils.py`:
- `.tif` files → `dsm` or `ortho` data types (NOT `point_cloud`)
- `.las/.laz` files → `point_cloud` data type only
- `data_type` parameter must be < 16 characters
- Raises `ValueError` on validation failure

### Thread Safety
- Token refresh uses `threading.Lock()` in `APIClient._refresh_lock`
- Ensures only one thread refreshes tokens when multiple concurrent requests receive 401 errors
- Other threads wait and reuse refreshed tokens

### Localhost Cookie Handling
For `localhost` base URLs, cookies set without domain specification to avoid port-matching issues in `requests.Session`.

## Coding Style & Naming Conventions
- Follow PEP 8 with Black's defaults (88-char line length, double quotes where practical).
- Prefer type hints on public APIs and dataclasses/models for resource objects.
- Use snake_case for functions and vars, PascalCase for classes (e.g., `ProjectCollection`), and descriptive module names.

### Code Quality Tools
- **Formatter**: Black (line length: 88)
- **Linter**: Flake8 with `--max-line-length=88`
- **Type Checker**: mypy with `types-requests` dependency
- **Pre-commit hooks**: Enforces trailing whitespace, EOF, YAML validation, Black, Flake8, mypy

### Flake8 Exceptions
- `__init__.py` files: Allow `F401` (unused imports for re-exports)
- `d2spy/extras/third_party/**`: Excluded from linting (third-party TUS client)

## Documentation

Documentation uses MkDocs with Material theme and mkdocstrings for API reference generation.

### Structure
- `docs/index.md`: Homepage
- `docs/guides/notebooks/`: Jupyter notebook tutorials (e.g., creating workspaces, adding data products, visualizing with leafmap)
- `docs/*_module.md`: API reference per module (auto-generated from docstrings using mkdocstrings)
- `mkdocs.yml`: Navigation and configuration

### Adding Documentation

**1. Add docstrings to code** (Google style):
```python
def add_flight(self, acquisition_date: str, altitude: float) -> Flight:
    """Add a new flight to the project.

    Args:
        acquisition_date: Date of flight acquisition (YYYY-MM-DD)
        altitude: Flight altitude in meters

    Returns:
        Flight object representing the newly created flight

    Raises:
        ValueError: If acquisition_date format is invalid
    """
```

**2. Create markdown files or notebooks**:
- Add markdown files to `docs/` for new sections
- Add Jupyter notebooks to `docs/guides/notebooks/` for tutorials

**3. Update navigation**:
- Edit `mkdocs.yml` to add new pages to the `nav` section

**4. Preview and build**:
```bash
uv run mkdocs serve    # Preview at http://127.0.0.1:8000
uv run mkdocs build     # Generate static site
```

## Testing Guidelines

### Test Organization
- Mirror package structure: `tests/test_<module>.py` for each `d2spy/<module>.py`
- Shared fixtures in `tests/example_data.py` (e.g., `TEST_USER`, `TEST_PROJECT`, `TEST_FLIGHT`)
- Sample payloads in `tests/data/` for complex responses
- Name tests: `test_<feature>_<scenario>` (e.g., `test_login_success`, `test_token_refresh_on_401`)

### Mock Patterns
Use `@patch` to mock HTTP dependencies:
```python
@patch("d2spy.api_client.APIClient.make_post_request")
def test_add_project(self, mock_post):
    mock_post.return_value = TEST_PROJECT
    result = workspace.add_project(...)
    mock_post.assert_called_once_with("/api/v1/projects", json={...})
```

### Key Test Scenarios to Cover
- **Success paths**: Happy path with valid data
- **Failure paths**: Invalid inputs, network errors, API errors
- **Token refresh**: 401 handling with retry logic
- **Thread safety**: Concurrent requests with token refresh
- **Async jobs**: 202 status code handling
- **Cookie handling**: Localhost vs. remote domain normalization

### Running Specific Test Subsets
```bash
# Test token refresh mechanism
uv run pytest tests/test_api_client.py -k refresh

# Test authentication flows
uv run pytest tests/test_auth.py -k login

# Test with verbose output
uv run pytest tests/test_data_product.py -v
```

### Test Assertions Best Practices
- Assert on both **results** (return values) and **calls** (mock.assert_called_with)
- Focus on **behavior** over internal state
- Use `requests-mock` to isolate HTTP flows
- Reuse fixtures from `tests/example_data.py` to avoid duplication

## Common Development Tasks

### Adding New API Endpoints

When adding support for a new D2S API endpoint:

**1. Create Schema** (`schemas/`):
```python
from dataclasses import dataclass
from typing import Optional
from uuid import UUID

@dataclass
class NewResource:
    id: UUID
    name: str
    description: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "NewResource":
        return cls(
            id=UUID(data["id"]),
            name=data["name"],
            description=data.get("description")
        )
```

**2. Create Model** (`models/`):
```python
from d2spy.api_client import APIClient

class NewResource:
    def __init__(self, client: APIClient, **kwargs):
        self.client = client
        self.__dict__.update(kwargs)

    def update(self, name: str) -> "NewResource":
        response = self.client.make_put_request(
            f"/api/v1/resources/{self.id}",
            json={"name": name}
        )
        return NewResource(self.client, **response)
```

**3. Add API Method** (to relevant model or APIClient):
```python
def get_new_resource(self, resource_id: str) -> NewResource:
    response = self.client.make_get_request(f"/api/v1/resources/{resource_id}")
    schema = schemas.NewResource.from_dict(response)
    return models.NewResource(self.client, **schema.__dict__)
```

**4. Add Tests** (`tests/`):
```python
@patch("d2spy.api_client.APIClient.make_get_request")
def test_get_new_resource(self, mock_get):
    mock_get.return_value = {"id": "123", "name": "Test"}
    result = workspace.get_new_resource("123")
    assert result.name == "Test"
```

### Adding New Data Product Analysis Tools

To add a new analysis tool to `DataProduct`:

**1. Add method to `models/data_product.py`**:
```python
def derive_custom_index(self, band_indices: list[int]) -> dict:
    """Generate custom spectral index from specified bands.

    Args:
        band_indices: List of band indices to use

    Returns:
        Job status dict with 'status': 'accepted'
    """
    response = self.client.make_post_request(
        f"/api/v1/data_products/{self.id}/tools",
        json={
            "tool": "custom_index",
            "band_indices": band_indices
        }
    )
    return response  # Returns 202 status
```

**2. Add tests with mocked responses**:
```python
def test_derive_custom_index(self):
    mock_response = {"status": "accepted"}
    with patch.object(self.client, "make_post_request", return_value=mock_response):
        result = data_product.derive_custom_index([1, 2, 3])
        assert result["status"] == "accepted"
```

### Updating Authentication

Authentication logic is split across two modules:

**Login/Logout** (`auth.py`):
- Modify `Auth.login()` for credential handling
- Update `Auth._normalize_cookies()` for cookie processing

**Token Refresh** (`api_client.py`):
- Modify `APIClient._handle_401_error()` for refresh logic
- Update `APIClient._refresh_access_token()` for token request

**Cookie Handling** (`auth.py`):
- Update `Auth._normalize_cookies()` for domain/path logic

## Commit & Pull Request Guidelines
- Write short, imperative commit subjects (`add zonal stats helper`); include focused changes per commit.
- In PRs, provide a summary of behavior changes, link relevant issues, and attach CLI output or screenshots for user-facing updates.
- Verify `uv run pytest` and formatting before requesting review; note any follow-up work in the PR description.

## Security & Configuration Tips
- Never hardcode credentials; rely on `D2S_EMAIL` and `D2S_PASSWORD` env vars when invoking `Auth.login`.
- Review responses with `extras.utils.pretty_print_response` when debugging but avoid logging sensitive tokens.
