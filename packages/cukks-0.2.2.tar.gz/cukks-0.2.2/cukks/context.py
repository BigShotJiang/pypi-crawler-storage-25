"""
CKKS Inference Context - Easy setup for encrypted deep learning inference.

This module provides a high-level interface for setting up CKKS encryption
parameters optimized for neural network inference.
"""

from __future__ import annotations

import math
import pickle
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Sequence, Tuple, Union

import torch

if TYPE_CHECKING:
    from .tensor import EncryptedTensor

from .batching.packing import SlotPacker
from .batching import PackingLayout, TokenBlockPacker

CKKSConfig: Any | None = None
CKKSContext: Any | None = None

@dataclass
class InferenceConfig:
    poly_mod_degree: int = 32768  # OpenFHE 1.2+ requires ≥32768 for HE standards
    scale_bits: int = 40
    security_level: Optional[str] = "128_classic"
    mult_depth: int = 4
    enable_bootstrap: bool = False
    level_budget: Optional[Tuple[int, int]] = None
    
    _coeff_mod_bits: Optional[Tuple[int, ...]] = field(default=None, repr=False)
    
    def __post_init__(self) -> None:
        if self._coeff_mod_bits is None:
            middle_bits = tuple([self.scale_bits] * self.mult_depth)
            object.__setattr__(self, '_coeff_mod_bits', (60,) + middle_bits + (60,))
    
    @property
    def coeff_mod_bits(self) -> Tuple[int, ...]:
        if self._coeff_mod_bits is None:
            middle_bits = tuple([self.scale_bits] * self.mult_depth)
            return (60,) + middle_bits + (60,)
        return self._coeff_mod_bits
    
    @property
    def num_slots(self) -> int:
        return self.poly_mod_degree // 2
    
    @property
    def resolved_level_budget(self) -> Optional[Tuple[int, int]]:
        if self.level_budget is not None:
            return self.level_budget
        if self.enable_bootstrap:
            return (3, 3)
        return None
    
    @classmethod
    def for_depth(cls, mult_depth: int, **kwargs: Any) -> "InferenceConfig":
        mult_depth = max(1, mult_depth)
        enable_bootstrap = kwargs.pop("enable_bootstrap", False)
        level_budget = kwargs.pop("level_budget", None)
        security_level = kwargs.pop("security_level", "128_classic")
        scale_bits = kwargs.pop("scale_bits", 50)
        
        # Check if poly_mod_degree is explicitly passed
        poly_mod_degree = kwargs.pop("poly_mod_degree", None)

        if enable_bootstrap:
            if poly_mod_degree is None:
                poly_mod_degree = 65536
            effective_depth = mult_depth + 2
        else:
            effective_depth = mult_depth + 2
            if poly_mod_degree is None:
                # OpenFHE GPU fork (1.2.x) enforces HE standard limits including
                # key-switching prime overhead. Empirically:
                #   N=32768: max ~620 total coeff_mod bits (10 primes × 50 + 2 × 60)
                #   N=65536: max ~1240 total coeff_mod bits with scale_bits=40
                # With 13+ primes, the key-switching overhead pushes logQ(P) beyond
                # what N=32768 allows, even if coeff_mod bits alone fit.
                total_bits = 60 + scale_bits * effective_depth + 60
                num_primes = effective_depth + 2
                if total_bits <= 620 and num_primes <= 12:
                    poly_mod_degree = 32768
                elif total_bits <= 620 and num_primes <= 14 and not kwargs.get("enable_gpu", False):
                    poly_mod_degree = 32768
                else:
                    poly_mod_degree = 65536

        return cls(
            poly_mod_degree=poly_mod_degree,
            mult_depth=effective_depth,
            scale_bits=scale_bits,
            security_level=security_level,
            enable_bootstrap=enable_bootstrap,
            level_budget=level_budget,
            **kwargs,
        )
    
    @classmethod
    def for_model(
        cls,
        model: torch.nn.Module,
        activation_degree: int = 4,
        use_square_activation: bool = False,
        **kwargs: Any,
    ) -> "InferenceConfig":
        enable_gpu = kwargs.pop("enable_gpu", False)
        attention_normalization_mode = kwargs.pop("attention_normalization_mode", "power_softmax")
        depth = _estimate_model_depth(
            model,
            activation_degree=activation_degree,
            use_square_activation=use_square_activation,
            enable_gpu=enable_gpu,
            attention_normalization_mode=attention_normalization_mode,
        )
        return cls.for_depth(depth, **kwargs)


def _estimate_model_depth(
    model: torch.nn.Module,
    activation_degree: int = 4,
    use_square_activation: bool = False,
    enable_gpu: bool = False,
    attention_normalization_mode: str = "power_softmax",
    inverse_free_ln_names: "frozenset[str]" = frozenset(),
) -> int:
    depth = 0
    if use_square_activation:
        poly_depth = 1
    elif enable_gpu and activation_degree >= 4:
        poly_depth = 3
    else:
        poly_depth = max(1, math.ceil(math.log2(activation_degree + 1)))

    from .nn.block_diagonal import BlockDiagonalLinear
    from .nn.block_diagonal_low_rank import BlockDiagLowRankLinear

    _module_to_name = {id(m): name for name, m in model.named_modules()}

    for module in model.modules():
        if isinstance(module, BlockDiagLowRankLinear):
            depth += 2 if module.rank > 0 else 1
        elif isinstance(module, (torch.nn.Linear, torch.nn.Conv2d, BlockDiagonalLinear)):
            depth += 1
            if enable_gpu:
                depth += 1
        elif isinstance(module, (
            torch.nn.ReLU, torch.nn.GELU, torch.nn.SiLU,
            torch.nn.Sigmoid, torch.nn.Tanh,
        )):
            depth += poly_depth
        elif isinstance(module, torch.nn.MultiheadAttention):
            depth += 9 if attention_normalization_mode == "gaussian" else 10
        elif isinstance(module, torch.nn.LayerNorm):
            module_name = _module_to_name.get(id(module), "")
            if module_name in inverse_free_ln_names:
                depth += 5
            else:
                depth += 18
        elif isinstance(module, torch.nn.GroupNorm):
            depth += activation_degree + 3
        elif isinstance(module, torch.nn.AdaptiveAvgPool2d):
            depth += 1
    return max(1, depth)


def _collect_rotation_requirements(
    model: torch.nn.Module,
    input_shape: Optional[Tuple[int, ...]] = None,
    *,
    small_output_threshold: int = 16,
) -> Tuple[List[int], List[int], List[int], List[int]]:
    from .nn.block_diagonal import BlockDiagonalLinear
    from .nn.block_diagonal_low_rank import BlockDiagLowRankLinear
    from .nn.conv import EncryptedConv2d as _EC

    generic_dims: List[int] = []
    reduction_lengths: List[int] = []
    pack_shifts: set[int] = set()
    extra_rotations: set[int] = set()

    spatial_h, spatial_w = 28, 28
    if input_shape is not None:
        if len(input_shape) == 4:
            spatial_h, spatial_w = int(input_shape[2]), int(input_shape[3])
        elif len(input_shape) >= 2:
            spatial_h, spatial_w = int(input_shape[-2]), int(input_shape[-1])

    current_channels: Optional[int] = None
    if input_shape is not None:
        if len(input_shape) == 4:
            current_channels = int(input_shape[1])
        elif len(input_shape) == 3:
            current_channels = int(input_shape[0])

    pending_sparse_pool: Optional[Tuple[int, int]] = None

    for module in model.modules():
        if isinstance(module, BlockDiagLowRankLinear):
            if pending_sparse_pool is not None:
                generic_dims.append(pending_sparse_pool[1])
            generic_dims.extend([module.in_features, module.out_features])
            pending_sparse_pool = None
            continue

        if isinstance(module, BlockDiagonalLinear):
            if pending_sparse_pool is not None:
                generic_dims.append(pending_sparse_pool[1])
            generic_dims.extend([module.in_features, module.out_features])
            pending_sparse_pool = None
            continue

        if isinstance(module, torch.nn.MultiheadAttention):
            if pending_sparse_pool is not None:
                generic_dims.append(pending_sparse_pool[1])
            generic_dims.extend([module.embed_dim, module.embed_dim * 8])
            pending_sparse_pool = None
            continue

        if isinstance(module, torch.nn.Conv2d):
            if pending_sparse_pool is not None:
                generic_dims.append(pending_sparse_pool[1])
            kh, kw = (module.kernel_size, module.kernel_size) if isinstance(module.kernel_size, int) else module.kernel_size
            sh, sw = (module.stride, module.stride) if isinstance(module.stride, int) else module.stride
            if isinstance(module.padding, int):
                ph = pw = int(module.padding)
            elif isinstance(module.padding, tuple):
                ph, pw = int(module.padding[0]), int(module.padding[1])
            else:
                pending_sparse_pool = None
                continue

            kh, kw = int(kh), int(kw)
            sh, sw = int(sh), int(sw)

            out_h = (spatial_h + 2 * ph - kh) // sh + 1
            out_w = (spatial_w + 2 * pw - kw) // sw + 1
            num_patches = out_h * out_w
            patch_features = module.in_channels * kh * kw

            extra_rotations.update(
                _EC.required_packed_compact_rotations(num_patches, patch_features, module.out_channels)
            )

            spatial_h, spatial_w = out_h, out_w
            current_channels = int(module.out_channels)
            pending_sparse_pool = None
            continue

        if isinstance(module, torch.nn.GroupNorm):
            if current_channels is not None:
                sample_size = spatial_h * spatial_w * current_channels
            else:
                sample_size = int(module.num_channels)
            generic_dims.append(sample_size)
            if pending_sparse_pool is not None:
                generic_dims.append(pending_sparse_pool[1])
                pending_sparse_pool = None
            continue

        if isinstance(module, torch.nn.AvgPool2d):
            if pending_sparse_pool is not None:
                generic_dims.append(pending_sparse_pool[1])
                pending_sparse_pool = None

            if isinstance(module.kernel_size, int):
                pk_h = pk_w = module.kernel_size
            else:
                pk_h, pk_w = int(module.kernel_size[0]), int(module.kernel_size[1])

            stride = getattr(module, "stride", None)
            if isinstance(stride, int):
                ps_h = ps_w = stride
            elif stride is None:
                ps_h, ps_w = pk_h, pk_w
            else:
                ps_h, ps_w = int(stride[0]), int(stride[1])

            padding = getattr(module, "padding", 0)
            if isinstance(padding, int):
                p_h = p_w = padding
            else:
                p_h, p_w = int(padding[0]), int(padding[1])

            pool_total_slots = spatial_h * spatial_w * current_channels if current_channels is not None else None

            if current_channels is not None and pk_h == 2 and pk_w == 2 and ps_h == 2 and ps_w == 2 and p_h == 0 and p_w == 0:
                extra_rotations.update(
                    compute_cnn_rotations(
                        spatial_h,
                        spatial_w,
                        current_channels,
                        pool_size=pk_h,
                        pool_stride=ps_h,
                    )
                )
                if pk_h == 2 and ps_h == 2:
                    compact_features = (spatial_h // ps_h) * (spatial_w // ps_w) * current_channels
                    total_slots = spatial_h * spatial_w * current_channels
                    pending_sparse_pool = (compact_features, total_slots)
                else:
                    pending_sparse_pool = None
            else:
                if pool_total_slots is not None:
                    generic_dims.append(pool_total_slots)
                pending_sparse_pool = None

            spatial_h = (spatial_h + 2 * p_h - pk_h) // ps_h + 1
            spatial_w = (spatial_w + 2 * p_w - pk_w) // ps_w + 1
            continue

        if isinstance(module, torch.nn.AdaptiveAvgPool2d):
            if pending_sparse_pool is not None:
                generic_dims.append(pending_sparse_pool[1])
                pending_sparse_pool = None

            if current_channels is not None:
                total_in = spatial_h * spatial_w * current_channels
                generic_dims.append(total_in)

            output_size = module.output_size
            if isinstance(output_size, int):
                out_h = out_w = int(output_size)
            elif output_size is not None:
                out_h_s, out_w_s = output_size
                out_h = int(out_h_s) if out_h_s is not None else spatial_h
                out_w = int(out_w_s) if out_w_s is not None else spatial_w
            else:
                out_h, out_w = spatial_h, spatial_w
            spatial_h, spatial_w = out_h, out_w
            continue

        if isinstance(module, torch.nn.Linear):
            if pending_sparse_pool is not None and pending_sparse_pool[0] != module.in_features:
                generic_dims.append(pending_sparse_pool[1])
                pending_sparse_pool = None

            if module.out_features <= small_output_threshold and module.out_features < module.in_features:
                reduction_length = int(module.in_features)
                if pending_sparse_pool is not None and pending_sparse_pool[0] == module.in_features:
                    reduction_length = pending_sparse_pool[1]
                reduction_lengths.append(reduction_length)
                pack_shifts.update(range(1, int(module.out_features)))
            else:
                if pending_sparse_pool is not None:
                    generic_dims.append(pending_sparse_pool[1])
                    pending_sparse_pool = None
                generic_dims.extend([module.in_features, module.out_features])
            pending_sparse_pool = None
            continue

        if isinstance(module, (
            torch.nn.Flatten,
            torch.nn.ReLU,
            torch.nn.GELU,
            torch.nn.SiLU,
            torch.nn.Sigmoid,
            torch.nn.Tanh,
            torch.nn.Dropout,
        )):
            continue

        if pending_sparse_pool is not None:
            generic_dims.append(pending_sparse_pool[1])
            pending_sparse_pool = None

    if pending_sparse_pool is not None:
        generic_dims.append(pending_sparse_pool[1])

    return (
        generic_dims,
        sorted(set(reduction_lengths)),
        sorted(pack_shifts),
        sorted(extra_rotations),
    )


def _compute_reduction_rotations(length: int) -> List[int]:
    if length <= 1:
        return []

    rotations: List[int] = []
    step = 1
    while step < length:
        rotations.append(step)
        step *= 2
    return rotations


def compute_bsgs_rotations(max_dim: int, bsgs_n1: Optional[int] = None) -> List[int]:
    if max_dim <= 1:
        return []
    
    if bsgs_n1 is None:
        bsgs_n1 = max(1, int(math.ceil(math.sqrt(max_dim))))
    
    bsgs_n2 = (max_dim + bsgs_n1 - 1) // bsgs_n1
    
    baby_steps = list(range(1, bsgs_n1))
    giant_steps = [i * bsgs_n1 for i in range(1, bsgs_n2 + 1) if i * bsgs_n1 < max_dim]
    
    rotations = sorted(set(baby_steps + giant_steps))
    return rotations

def compute_packed_batch_rotations(
    max_dim: int,
    batch_size: int = 1,
    bsgs_n1: Optional[int] = None,
) -> List[int]:
    """Compute rotation indices for packed-batch CKKS inference.

    Returns the union of within-sample BSGS rotations and cross-block
    offsets.  Total count grows as O(sqrt(max_dim) + batch_size) instead
    of O(batch_size * max_dim).

    Args:
        max_dim: Slots per sample (*K*).
        batch_size: Number of samples packed per ciphertext (*B*).
        bsgs_n1: Optional baby-step size override.

    Returns:
        Sorted list of **positive** rotation indices.  The caller is
        responsible for adding negatives.
    """
    # Within-sample rotations: O(sqrt(K))
    rotations = set(compute_bsgs_rotations(max_dim, bsgs_n1))

    # Cross-block offsets: O(B) — shift between packed sample blocks
    if batch_size > 1:
        for i in range(1, batch_size):
            rotations.add(i * max_dim)

    return sorted(rotations)


def compute_cnn_rotations(
    image_height: int,
    image_width: int,
    channels: int,
    pool_size: int = 2,
    pool_stride: int = 2,
) -> List[int]:
    rotations = set()
    if pool_size == 2 and pool_stride == 2:
        W = image_width
        offsets = [
            channels,
            W * channels,
            (W + 1) * channels,
        ]
        rotations.update(offsets)
    else:
        for dy in range(pool_size):
            for dx in range(pool_size):
                if dy == 0 and dx == 0:
                    continue
                offset = (dy * image_width + dx) * channels
                rotations.add(offset)
    return sorted(rotations)


def compute_rotations_for_model(model: torch.nn.Module, use_bsgs: bool = True) -> List[int]:
    from .nn.block_diagonal_low_rank import BlockDiagLowRankLinear

    dims, reduction_lengths, pack_shifts, extra_rotations = _collect_rotation_requirements(model)
    rotations = set(extra_rotations)

    if dims:
        max_dim = max(dims)
    else:
        max_dim = 0

    if max_dim > 1 and use_bsgs:
        rotations = compute_bsgs_rotations(max_dim)
    elif max_dim > 1:
        rotations = list(range(1, max_dim))
    else:
        rotations = []

    rotation_set = set(rotations) | set(extra_rotations) | set(pack_shifts)
    for length in reduction_lengths:
        rotation_set.update(_compute_reduction_rotations(length))
    
    for module in model.modules():
        if isinstance(module, BlockDiagLowRankLinear) and module.rank > 0:
            step = 1
            while step <= max_dim * 64:
                rotation_set.add(step)
                step *= 2
            break

    neg_rotations = [-r for r in rotation_set if r > 0]
    return sorted(set(rotation_set) | set(neg_rotations))


class CKKSInferenceContext:
    def __init__(
        self,
        config: Optional[InferenceConfig] = None,
        *,
        device: Optional[str] = None,
        rotations: Optional[List[int]] = None,
        use_bsgs: bool = True,
        max_rotation_dim: Optional[int] = None,
        auto_bootstrap: bool = False,
        bootstrap_threshold: int = 2,
        cnn_config: Optional[Dict[str, Any]] = None,
        enable_gpu: bool = True,
        batch_size: int = 1,
        architecture: str = "default",
    ):
        if architecture not in {"default", "stip"}:
            raise ValueError(
                "architecture must be 'default' or 'stip', "
                f"got {architecture!r}"
            )
        if cnn_config is not None and config is None:
            config = InferenceConfig(mult_depth=6, security_level=None)
        
        self.config = config or InferenceConfig()
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.use_bsgs = use_bsgs
        self._auto_bootstrap = auto_bootstrap
        self._bootstrap_threshold = bootstrap_threshold
        self._cnn_config = cnn_config
        self._enable_gpu = enable_gpu
        self._batch_size = batch_size
        self._architecture = architecture
        
        _resolved_max_dim = max_rotation_dim
        if rotations is None:
            max_dim = max_rotation_dim or min(self.config.num_slots, 1024)
            _resolved_max_dim = max_dim
            if self.use_bsgs:
                rotations = compute_packed_batch_rotations(max_dim, batch_size)
                neg_rotations = [-r for r in rotations if r > 0]
                rotations = sorted(set(rotations + neg_rotations))
            else:
                rotations = list(range(1, max_dim)) + list(range(-max_dim + 1, 0))
                if batch_size > 1:
                    for i in range(1, batch_size):
                        rotations.extend([i * max_dim, -(i * max_dim)])
                    rotations = sorted(set(rotations))
            
            if cnn_config is not None:
                cnn_rots = compute_cnn_rotations(
                    image_height=cnn_config.get('image_height', 8),
                    image_width=cnn_config.get('image_width', 8),
                    channels=cnn_config.get('channels', 4),
                    pool_size=cnn_config.get('pool_size', 2),
                    pool_stride=cnn_config.get('pool_stride', 2),
                )
                cnn_neg_rots = [-r for r in cnn_rots if r > 0]
                all_rots = set(rotations) | set(cnn_rots) | set(cnn_neg_rots)
                
                H = cnn_config.get('image_height', 8)
                W = cnn_config.get('image_width', 8)
                C = cnn_config.get('channels', 4)
                total_sparse_slots = H * W * C
                
                fc_rots = compute_bsgs_rotations(total_sparse_slots)
                fc_neg_rots = [-r for r in fc_rots if r > 0]
                all_rots = all_rots | set(fc_rots) | set(fc_neg_rots)
                
                rotations = sorted(all_rots)
        
        self._rotations = rotations
        self._max_rotation_dim = _resolved_max_dim
        self._ctx: Any = None
        self._initialized = False
        self._init_lock = threading.Lock()
    
    def _ensure_initialized(self) -> None:
        if self._initialized:
            return
        
        with self._init_lock:
            if self._initialized:
                return

            global CKKSConfig, CKKSContext
            if CKKSConfig is None or CKKSContext is None:
                from .backend_loader import load_backend
                CKKSConfig, CKKSContext = load_backend()  # raises RuntimeError with install hint if unavailable
            
            ckks_config = CKKSConfig(
                poly_mod_degree=self.config.poly_mod_degree,
                coeff_mod_bits=self.config.coeff_mod_bits,
                scale_bits=self.config.scale_bits,
                security_level=self.config.security_level,
                enable_bootstrap=self.config.enable_bootstrap,
                level_budget=self.config.resolved_level_budget,
                rotations=self._rotations,
                relin=True,
                generate_conjugate_keys=True,
            )
            
            self._ctx = CKKSContext(ckks_config, device=self.device, enable_gpu=self._enable_gpu)
            self._initialized = True
    
    @property
    def num_slots(self) -> int:
        return self.config.num_slots
    
    @property
    def batch_size(self) -> int:
        """Number of samples this context was configured to pack."""
        return self._batch_size

    @property
    def auto_bootstrap(self) -> bool:
        return self._auto_bootstrap
    
    @property
    def bootstrap_threshold(self) -> int:
        return self._bootstrap_threshold
    
    @property
    def backend(self) -> Any:
        self._ensure_initialized()
        return self._ctx
    
    def set_plain_cache_limit(self, limit: int) -> None:
        self._ensure_initialized()
        if hasattr(self._ctx, 'set_plain_cache_limit'):
            self._ctx.set_plain_cache_limit(limit)

    def pin_plain_cache(self) -> None:
        self._ensure_initialized()
        if hasattr(self._ctx, 'pin_plain_cache'):
            self._ctx.pin_plain_cache()

    def clear_pinned_plain_cache(self) -> None:
        self._ensure_initialized()
        if hasattr(self._ctx, 'clear_pinned_plain_cache'):
            self._ctx.clear_pinned_plain_cache()

    def plain_cache_info(self) -> Dict[str, int]:
        self._ensure_initialized()
        if hasattr(self._ctx, 'plain_cache_info'):
            return self._ctx.plain_cache_info()
        return {"total": 0, "pinned": 0, "unpinned": 0}

    def encrypt(self, tensor: torch.Tensor) -> "EncryptedTensor":
        from .tensor import EncryptedTensor
        
        self._ensure_initialized()
        
        flat = tensor.detach().to(dtype=torch.float64, device="cpu").reshape(-1)
        original_size = flat.numel()
        
        if original_size > self.num_slots:
            raise ValueError(
                f"Tensor size {original_size} exceeds available slots {self.num_slots}. "
                f"Consider using a larger poly_mod_degree or batching."
            )
        
        if self.use_bsgs and original_size < self.num_slots:
            # Tile data to fill all slots for BSGS giant step access
            indices = torch.arange(self.num_slots) % original_size
            flat = flat[indices]
            assert len(flat) == self.num_slots
        
        cipher = self._ctx.encrypt(flat)
        enc_tensor = EncryptedTensor(cipher, tuple(tensor.shape), self)
        enc_tensor._original_size = original_size
        return enc_tensor
    
    def decrypt(
        self,
        encrypted: "EncryptedTensor",
        shape: Optional[Sequence[int]] = None,
    ) -> torch.Tensor:
        self._ensure_initialized()

        if hasattr(encrypted, '_cipher'):
            cipher = encrypted
        else:
            from .tensor import EncryptedTensor

            raw_shape = getattr(encrypted, 'shape', None)
            resolved_shape = tuple(raw_shape) if raw_shape else shape
            if resolved_shape is None:
                raise ValueError("shape is required when decrypting a raw backend tensor")
            cipher = EncryptedTensor(encrypted, tuple(resolved_shape), self)

        if getattr(cipher, '_needs_rescale', False):
            cipher = cipher.rescale()
        
        target_shape = tuple(shape) if shape else cipher.shape
        target_numel = int(math.prod(target_shape)) if target_shape else 1
        
        result = self._ctx.decrypt(cipher._cipher, shape=None)
        result = result[:target_numel].reshape(target_shape)
        
        if self.device != "cpu":
            result = result.to(self.device)
            
        return result
    
    def encrypt_batch(
        self,
        samples: List[torch.Tensor],
        slots_per_sample: Optional[int] = None,
    ) -> Any:
        """Pack *samples* into a single ciphertext and return an EncryptedTensor.
        
        Slot layout (contiguous block packing)::
        
            [s0[0..K-1], s1[0..K-1], ..., s(B-1)[0..K-1], padding...]
        
        where *B* = ``len(samples)`` and *K* = ``slots_per_sample``.
        
        The returned tensor carries ``_packed_batch=True``,
        ``_batch_size=B``, and ``_slots_per_sample=K`` so that every
        subsequent operation preserves the packed-batch contract.
        
        Args:
            samples: List of plaintext tensors (all same numel).
            slots_per_sample: Slots reserved per sample (default: sample numel).
        
        Returns:
            EncryptedTensor with packed-batch metadata set.
        """
        from .tensor import EncryptedTensor

        self._ensure_initialized()

        if not samples:
            raise ValueError("Cannot encrypt empty list of samples")

        if self._batch_size > 1 and len(samples) != self._batch_size:
            raise ValueError(
                f"Context was created with batch_size={self._batch_size} but "
                f"encrypt_batch() received {len(samples)} samples. "
                f"Provide exactly {self._batch_size} samples."
            )
        first_sample_size = samples[0].numel()
        sample_shape = tuple(samples[0].shape)
        if slots_per_sample is None:
            slots_per_sample = first_sample_size
        
        packer = SlotPacker(slots_per_sample, self.num_slots)
        packed = packer.pack(samples)
        
        cipher = self._ctx.encrypt(packed.to(dtype=torch.float64, device="cpu"))

        batch_shape = (len(samples), *sample_shape) if slots_per_sample == first_sample_size else (len(samples), slots_per_sample)
        enc_tensor = EncryptedTensor(cipher, batch_shape, self)
        enc_tensor._packed_batch = True
        enc_tensor._batch_size = len(samples)
        enc_tensor._slots_per_sample = slots_per_sample
        enc_tensor._packed_sample_shape = sample_shape
        return enc_tensor

    def _forward_packed_batch(self, model: Any, packed_batch: "EncryptedTensor") -> "EncryptedTensor":
        raise RuntimeError(
            "Legacy packed-batch plaintext fallback has been disabled. "
            "Packed EncryptedTensor inputs must execute through native layer "
            "implementations without decrypt/re-encrypt."
        )
    
    def decrypt_batch(
        self,
        encrypted: Any,
        num_samples: Optional[int] = None,
        sample_shape: Optional[Sequence[int]] = None,
    ) -> List[torch.Tensor]:
        self._ensure_initialized()

        if isinstance(encrypted, list):
            samples = [self.decrypt(item, shape=sample_shape) for item in encrypted]
            if num_samples is not None:
                return samples[:num_samples]
            return samples

        if num_samples is None and getattr(encrypted, "_packed_batch", False):
            num_samples = getattr(encrypted, "_batch_size", None)
        
        if num_samples is None:
            if len(encrypted.shape) >= 1:
                num_samples = encrypted.shape[0]
            else:
                raise ValueError(
                    "Cannot infer num_samples from encrypted tensor shape. "
                    "Please provide num_samples explicitly."
                )
        
        if getattr(encrypted, "_packed_batch", False) and getattr(encrypted, "_slots_per_sample", None) is not None:
            slots_per_sample = int(getattr(encrypted, "_slots_per_sample"))
        elif len(encrypted.shape) >= 2:
            slots_per_sample = encrypted.shape[1]
        else:
            slots_per_sample = encrypted.size // num_samples

        if num_samples is None:
            raise ValueError("num_samples could not be resolved")

        full_result = self._ctx.decrypt(encrypted._cipher, shape=None)
        
        packer = SlotPacker(slots_per_sample, self.num_slots)
        samples = packer.unpack(full_result, num_samples)
        
        if sample_shape is not None:
            target_numel = int(math.prod(sample_shape))
            reshaped_samples = []
            for sample in samples:
                trimmed = sample[:target_numel].to(torch.float32)
                reshaped_samples.append(trimmed.reshape(sample_shape))
            samples = reshaped_samples
        else:
            samples = [s.to(torch.float32) for s in samples]
        
        if self.device != "cpu":
            samples = [s.to(self.device) for s in samples]
        
        return samples

    def encrypt_sequence(
        self,
        tensor: torch.Tensor,
        *,
        num_heads: int,
        block_size: Optional[int] = None,
    ) -> "EncryptedTensor":
        from .tensor import EncryptedTensor

        self._ensure_initialized()

        if tensor.ndim != 2:
            raise ValueError(f"Expected 2D tensor (seq_len, d_model), got shape {tuple(tensor.shape)}")

        seq_len, d_model = tensor.shape
        resolved_block_size = int(block_size) if block_size is not None else int(d_model)
        layout = PackingLayout(
            seq_len=int(seq_len),
            d_model=int(d_model),
            num_heads=int(num_heads),
            block_size=resolved_block_size,
        )
        if layout.total_slots_needed > self.num_slots:
            raise ValueError(
                f"Sequence requires {layout.total_slots_needed} slots but context has {self.num_slots}"
            )

        packer = TokenBlockPacker(layout, self.num_slots)
        packed = packer.pack(tensor)
        cipher = self._ctx.encrypt(packed.to(dtype=torch.float64, device="cpu"))
        enc_tensor = EncryptedTensor(cipher, (layout.seq_len, layout.d_model), self)
        enc_tensor._packing_layout = layout
        enc_tensor._stip_layout_fresh = True
        return enc_tensor

    def decrypt_sequence(self, encrypted: "EncryptedTensor") -> torch.Tensor:
        self._ensure_initialized()

        layout = getattr(encrypted, "_packing_layout", None)
        if layout is None:
            raise ValueError("EncryptedTensor has no STIP packing layout")
        if not getattr(encrypted, "_stip_layout_fresh", False):
            raise ValueError("EncryptedTensor does not have fresh STIP sequence-layout provenance")
        if encrypted.shape != (layout.seq_len, layout.d_model):
            raise ValueError(
                "EncryptedTensor shape does not match STIP packing layout. "
                f"Got tensor shape {encrypted.shape} and layout {(layout.seq_len, layout.d_model)}."
            )

        full_result = self._ctx.decrypt(encrypted._cipher, shape=None)
        packer = TokenBlockPacker(layout, self.num_slots)
        recovered = packer.unpack(full_result)
        if self.device != "cpu":
            recovered = recovered.to(self.device)
        return recovered.to(torch.float32)
    
    def encrypt_cnn_input(
        self,
        image: torch.Tensor,
        conv_params: List[Dict[str, Any]],
    ) -> "EncryptedTensor":
        import torch.nn.functional as F
        
        self._ensure_initialized()
        
        if image.ndim == 3:
            image = image.unsqueeze(0)
        
        if not conv_params:
            return self.encrypt(image)
        
        first_conv = conv_params[0]
        kernel_size = first_conv['kernel_size']
        stride = first_conv.get('stride', (1, 1))
        padding = first_conv.get('padding', (0, 0))
        
        if padding != (0, 0):
            image = F.pad(image, (padding[1], padding[1], padding[0], padding[0]))
        
        patches = F.unfold(image.to(torch.float64), kernel_size, stride=stride)
        patches = patches.transpose(1, 2)
        patches = patches.squeeze(0)
        
        num_patches, patch_features = patches.shape
        flat_patches = patches.flatten()
        
        enc_tensor = self.encrypt(flat_patches)
        
        enc_tensor._cnn_layout = {
            'num_patches': num_patches,
            'patch_features': patch_features,
            'original_shape': tuple(image.shape),
        }
        enc_tensor._shape = (num_patches, patch_features)
        
        return enc_tensor

    @classmethod
    def for_model(
        cls,
        model: torch.nn.Module,
        use_bsgs: bool = True,
        activation_degree: int = 4,
        use_square_activation: bool = False,
        batch_size: int = 1,
        attention_normalization_mode: str = "power_softmax",
        architecture: str = "default",
        input_shape: Optional[Sequence[int]] = None,
        **kwargs: Any,
    ) -> "CKKSInferenceContext":
        enable_bootstrap = kwargs.pop("enable_bootstrap", False)
        level_budget = kwargs.pop("level_budget", None)
        scale_bits = kwargs.pop("scale_bits", 50)
        security_level = kwargs.pop("security_level", "128_classic")
        poly_mod_degree = kwargs.pop("poly_mod_degree", None)
        kwargs.pop("optimize_cnn", True)

        config = InferenceConfig.for_model(
            model,
            activation_degree=activation_degree,
            use_square_activation=use_square_activation,
            enable_gpu=kwargs.get("enable_gpu", False),
            attention_normalization_mode=attention_normalization_mode,
            enable_bootstrap=enable_bootstrap,
            level_budget=level_budget,
            scale_bits=scale_bits,
            security_level=security_level,
            poly_mod_degree=poly_mod_degree,
        )
        input_shape_tuple = tuple(input_shape) if input_shape is not None else None
        dims, reduction_lengths, pack_shifts, extra_rotations = _collect_rotation_requirements(
            model,
            input_shape=input_shape_tuple,
        )
        max_dim = max(dims) if dims else 0
        resolved_use_bsgs = use_bsgs

        positive_rotations: set[int] = set(extra_rotations)
        for length in reduction_lengths:
            positive_rotations.update(_compute_reduction_rotations(length))

        if max_dim > 1:
            if resolved_use_bsgs:
                positive_rotations.update(compute_packed_batch_rotations(max_dim, batch_size))
            else:
                positive_rotations.update(range(1, max_dim))
                if batch_size > 1:
                    positive_rotations.update(i * max_dim for i in range(1, batch_size))

        if batch_size > 1:
            positive_rotations.update(pack_shifts)
            rotations = sorted(positive_rotations | {-r for r in positive_rotations if r > 0})
        else:
            rotations = sorted(positive_rotations | {-shift for shift in pack_shifts if shift > 0})
        resolved_max_dim = max_dim

        extra_rotations = kwargs.pop("rotations", [])
        if extra_rotations:
            rotations.extend(extra_rotations)
            rotations = sorted(list(set(rotations)))
        
        return cls(
            config,
            rotations=rotations,
            use_bsgs=resolved_use_bsgs,
            max_rotation_dim=resolved_max_dim,
            batch_size=batch_size,
            architecture=architecture,
            **kwargs,
        )
    
    @classmethod
    def for_depth(
        cls,
        depth: int,
        **kwargs: Any,
    ) -> "CKKSInferenceContext":
        config_keys = {
            "enable_bootstrap",
            "level_budget",
            "security_level",
            "scale_bits",
            "poly_mod_degree",
        }
        context_keys = {
            "device",
            "rotations",
            "use_bsgs",
            "max_rotation_dim",
            "auto_bootstrap",
            "bootstrap_threshold",
            "cnn_config",
            "enable_gpu",
            "architecture",
        }

        config_kwargs = {k: v for k, v in kwargs.items() if k in config_keys}
        context_kwargs = {k: v for k, v in kwargs.items() if k in context_keys}
        unknown_keys = sorted(set(kwargs) - config_keys - context_keys)
        if unknown_keys:
            names = ", ".join(unknown_keys)
            raise TypeError(f"Unexpected keyword arguments for for_depth(): {names}")

        config = InferenceConfig.for_depth(depth, **config_kwargs)
        return cls(config, **context_kwargs)
    
    def __repr__(self) -> str:
        status = "initialized" if self._initialized else "not initialized"
        return (
            f"CKKSInferenceContext("
            f"slots={self.num_slots}, "
            f"depth={self.config.mult_depth}, "
            f"device='{self.device}', "
            f"status={status})"
        )
    
    def save_context(self, path: Union[str, Path]) -> None:
        config_data = {
            "poly_mod_degree": self.config.poly_mod_degree,
            "scale_bits": self.config.scale_bits,
            "security_level": self.config.security_level,
            "mult_depth": self.config.mult_depth,
            "enable_bootstrap": self.config.enable_bootstrap,
            "device": self.device,
            "use_bsgs": self.use_bsgs,
            "rotations": self._rotations,
            "max_rotation_dim": self._max_rotation_dim,
            "auto_bootstrap": self._auto_bootstrap,
            "bootstrap_threshold": self._bootstrap_threshold,
            "batch_size": self._batch_size,
            "architecture": self._architecture,
        }
        with open(path, "wb") as f:
            pickle.dump(config_data, f)
    
    @classmethod
    def load_context(cls, path: Union[str, Path]) -> "CKKSInferenceContext":
        with open(path, "rb") as f:
            config_data = pickle.load(f)
        import warnings
        warnings.warn(
            "CKKSInferenceContext.load_context() uses pickle deserialization which can "
            "execute arbitrary code. Only load context files from trusted sources.",
            stacklevel=2,
        )
        
        inference_config = InferenceConfig(
            poly_mod_degree=config_data["poly_mod_degree"],
            scale_bits=config_data["scale_bits"],
            security_level=config_data["security_level"],
            mult_depth=config_data["mult_depth"],
            enable_bootstrap=config_data["enable_bootstrap"],
        )
        
        return cls(
            config=inference_config,
            device=config_data["device"],
            rotations=config_data["rotations"],
            use_bsgs=config_data["use_bsgs"],
            max_rotation_dim=config_data["max_rotation_dim"],
            auto_bootstrap=config_data["auto_bootstrap"],
            bootstrap_threshold=config_data["bootstrap_threshold"],
            batch_size=config_data.get("batch_size", 1),
            architecture=config_data.get("architecture", "default"),
        )
    
    load = load_context

    def close(self):
        if hasattr(self, '_ctx') and self._ctx is not None:
            if hasattr(self._ctx, 'cleanup'):
                self._ctx.cleanup()
            self._ctx = None
        self._initialized = False

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *args: Any):
        self.close()

    def encrypt_cnn_input_batch(
        self,
        images: List[torch.Tensor],
        conv_params: List[Dict[str, Any]],
    ) -> "EncryptedTensor":
        """Pack *B* images into a single ciphertext after im2col unfolding.
        
        Slot layout::
        
            [img0_patches, img1_patches, ..., img(B-1)_patches, padding...]
        
        Each image is independently unfolded (im2col) using *conv_params*,
        then all patches are concatenated into one flat vector and encrypted.
        
        The returned tensor carries ``_packed_batch=True`` and ``_cnn_layout``
        with ``batch_size`` so downstream :class:`EncryptedConv2d` can apply
        the weight matrix as a block-diagonal without mixing images.
        
        Args:
            images: List of B image tensors, each (C, H, W) or (1, C, H, W).
            conv_params: List of conv parameter dicts (same as encrypt_cnn_input).
        
        Returns:
            EncryptedTensor with packed-batch and CNN layout metadata.
        """
        import torch.nn.functional as F
        
        self._ensure_initialized()
        
        if not images:
            raise ValueError("Cannot encrypt empty list of images")
        
        if self._batch_size > 1 and len(images) != self._batch_size:
            raise ValueError(
                f"Context was created with batch_size={self._batch_size} but "
                f"received {len(images)} images. "
                f"Provide exactly {self._batch_size} images."
            )
        
        batch_size = len(images)
        processed_images = []
        
        for img in images:
            if img.ndim == 3:
                img = img.unsqueeze(0)
            processed_images.append(img)
        
        if not conv_params:
            # Fallback to regular batch encryption
            return self.encrypt_batch([img.flatten() for img in processed_images])
        
        first_conv = conv_params[0]
        kernel_size = first_conv['kernel_size']
        stride = first_conv.get('stride', (1, 1))
        padding = first_conv.get('padding', (0, 0))
        
        all_patches = []
        for image in processed_images:
            if padding != (0, 0):
                image = F.pad(image, (padding[1], padding[1], padding[0], padding[0]))
            
            patches = F.unfold(image.to(torch.float64), kernel_size, stride=stride)
            patches = patches.transpose(1, 2)
            patches = patches.squeeze(0)
            all_patches.append(patches)
        
        # Concatenate all patches from all images
        concatenated = torch.cat(all_patches, dim=0)
        num_patches_per_image = all_patches[0].shape[0]
        patch_features = all_patches[0].shape[1]
        flat_patches = concatenated.flatten()
        
        enc_tensor = self.encrypt(flat_patches)
        
        enc_tensor._cnn_layout = {
            'num_patches': num_patches_per_image * batch_size,
            'num_patches_per_image': num_patches_per_image,
            'patch_features': patch_features,
            'batch_size': batch_size,
            'original_shape': tuple(processed_images[0].shape),
        }
        enc_tensor._shape = (num_patches_per_image * batch_size, patch_features)
        enc_tensor._packed_batch = True
        enc_tensor._batch_size = batch_size
        enc_tensor._slots_per_sample = num_patches_per_image * patch_features
        
        return enc_tensor
