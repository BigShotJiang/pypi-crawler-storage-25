"""
Encrypted pooling layers using pure HE operations.

EncryptedAvgPool2d - Average pooling via HE rotations and masking.
EncryptedMaxPool2d - Max pooling via polynomial approximation of |x|.
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING, List, Tuple, Union

import torch

from .module import EncryptedModule

if TYPE_CHECKING:
    from ..tensor import EncryptedTensor


# =============================================================================
# Polynomial Approximation for Absolute Value
# =============================================================================

def _chebyshev_sqrt_coeffs(  # pyright: ignore[reportUnusedFunction]
    degree: int = 4,
    domain: tuple = (0.01, 1.0),
) -> List[float]:
    """Compute Chebyshev polynomial coefficients for sqrt approximation.
    
    This is used to approximate |x| = sqrt(x^2).
    
    Args:
        degree: Polynomial degree.
        domain: Domain for approximation. Default (0.01, 1.0) avoids singularity at 0.
        
    Returns:
        Polynomial coefficients [a0, a1, a2, ...] for sqrt(x).
    """
    try:
        import numpy as np
        from numpy.polynomial import chebyshev
        
        a, b = domain
        # Chebyshev nodes on [-1, 1]
        nodes = np.cos(np.pi * (np.arange(degree + 1) + 0.5) / (degree + 1))
        # Map to [a, b]
        x = 0.5 * (b - a) * nodes + 0.5 * (a + b)
        y = np.sqrt(x)
        
        # Fit Chebyshev polynomial
        coeffs = chebyshev.chebfit(x, y, degree)
        return coeffs.tolist()
    except ImportError:
        # Fallback: hardcoded degree-4 coefficients for sqrt on (0.01, 1.0)
        # Approximation: sqrt(x) ≈ 0.5 + 0.5*x - 0.125*x^2 + 0.0625*x^3 - ...
        return [0.1, 1.45, -0.85, 0.35, -0.05]


def _smooth_abs_coeffs(degree: int = 4) -> List[float]:
    """Compute polynomial coefficients for smooth |x| approximation.
    
    Uses the approximation: |x| ≈ sqrt(x^2 + epsilon) for stability.
    We fit a polynomial to |x| directly on [-1, 1].
    
    Args:
        degree: Polynomial degree (should be even for |x| symmetry).
        
    Returns:
        Polynomial coefficients for |x| approximation.
    """
    try:
        import numpy as np
        from numpy.polynomial import polynomial
        
        # Sample points on [-1, 1]
        n_points = 100
        x = np.linspace(-1, 1, n_points)
        
        # Use smooth absolute value: sqrt(x^2 + eps)
        eps = 0.01
        y = np.sqrt(x**2 + eps)
        
        # Fit polynomial - use only even powers since |x| is symmetric
        # For degree 4: a0 + a2*x^2 + a4*x^4
        coeffs = polynomial.polyfit(x, y, degree)
        return coeffs.tolist()
    except ImportError:
        # Fallback: hardcoded coefficients for |x| ≈ a0 + a2*x^2 + a4*x^4
        # This approximates |x| on [-1, 1]
        return [0.1, 0.0, 0.9, 0.0, 0.05]


def _pool_patch_indices(
    out_H: int,
    out_W: int,
    W: int,
    kH: int,
    kW: int,
    sH: int,
    sW: int,
) -> torch.Tensor:
    """Compute patch indices for pooling windows.
    
    Returns a 2D tensor of shape (out_H*out_W, kH*kW) where each row
    contains the flat patch indices for one output position's kernel window.
    """
    out_y = torch.arange(out_H, dtype=torch.long)
    out_x = torch.arange(out_W, dtype=torch.long)
    ky = torch.arange(kH, dtype=torch.long)
    kx = torch.arange(kW, dtype=torch.long)
    base = (out_y[:, None] * sH * W + out_x[None, :] * sW).reshape(-1, 1)
    kernel = (ky[:, None] * W + kx[None, :]).reshape(1, -1)
    return base + kernel


def _expand_patch_indices_with_channels(
    patch_indices: torch.Tensor,
    channels: int,
    *,
    patch_offset: int = 0,
) -> torch.Tensor:
    """Expand patch indices to include channel offsets."""
    channel_offsets = torch.arange(channels, dtype=torch.long)
    return (patch_indices[..., None] + patch_offset) * channels + channel_offsets


class EncryptedAvgPool2d(EncryptedModule):
    """Encrypted 2D average pooling using pure HE operations.
    
    Average pooling can be implemented in CKKS as:
    1. Sum the elements in each pooling window
    2. Multiply by 1/kernel_area
    
    For 2D input with CNN layout, uses rotation-based optimization for 2x2 pooling
    or sparse matrix multiplication for other kernel sizes.
    
    Args:
        kernel_size: Size of the pooling window.
        stride: Stride of the pooling. Default: same as kernel_size.
        padding: Padding to add. Default: 0.
        
    Note:
        Requires pre-processed input via ctx.encrypt_cnn_input() for 2D CNN layout.
        4D input is not supported in pure HE mode.
    """
    
    def __init__(
        self,
        kernel_size: Union[int, Tuple[int, int]],
        stride: Union[int, Tuple[int, int], None] = None,
        padding: Union[int, Tuple[int, int]] = 0,
    ) -> None:
        super().__init__()
        
        if isinstance(kernel_size, int):
            kernel_size = (kernel_size, kernel_size)
        if kernel_size[0] <= 0 or kernel_size[1] <= 0:
            raise ValueError(f"kernel_size must be positive, got {kernel_size}")
        self.kernel_size = kernel_size
        
        if stride is None:
            stride = kernel_size
        elif isinstance(stride, int):
            stride = (stride, stride)
        if stride[0] <= 0 or stride[1] <= 0:
            raise ValueError(f"stride must be positive, got {stride}")
        self.stride = stride
        
        if isinstance(padding, int):
            padding = (padding, padding)
        self.padding = padding
        
        # Pre-compute the averaging factor
        self.pool_area = self.kernel_size[0] * self.kernel_size[1]
        self.avg_factor = 1.0 / self.pool_area
        self._use_sparse_output = False
    
    def __call__(self, x: Union["EncryptedTensor", List["EncryptedTensor"]]) -> Union["EncryptedTensor", List["EncryptedTensor"]]:
        """Bypass the base-class packed-batch fallback.
        
        EncryptedAvgPool2d natively handles packed batches in forward(),
        so we call forward() directly instead of going through the
        context._forward_packed_batch decrypt/re-encrypt loop.
        """
        if isinstance(x, list):
            return [self.forward(item) for item in x]
        return self.forward(x)
    def forward(self, x: "EncryptedTensor") -> "EncryptedTensor":
        """Apply average pooling using pure HE operations.
        
        For 2D input with CNN layout, applies pooling via HE rotations or matmul.
        For pre-processed input without layout, applies scalar multiplication.
        4D input is not supported in pure HE mode.
        
        Args:
            x: Encrypted input tensor.
               
        Returns:
            Averaged encrypted output.
            
        Raises:
            RuntimeError: If input is 4D.
        """
        if getattr(x, '_packed_batch', False):
            sample_shape = getattr(x, '_packed_sample_shape', None) or x.shape[1:]
            if len(sample_shape) == 2:
                kH, kW = self.kernel_size
                sH, sW = self.stride
                if (
                    getattr(x, '_cnn_layout', None) is not None
                    and kH == 2 and kW == 2 and sH == 2 and sW == 2
                ):
                    return self._forward_he_rotation(x)
                return self._forward_he_packed_batch(x, sample_shape)

        input_ndim = len(x.shape)
        
        if input_ndim == 4:
            raise RuntimeError(
                "EncryptedAvgPool2d does not support 4D input in pure HE mode. "
                "Pre-process input using ctx.encrypt_cnn_input() to create a "
                "2D CNN layout. See: cukks.CKKSInferenceContext.encrypt_cnn_input()"
            )
        elif input_ndim == 2 and hasattr(x, '_cnn_layout') and x._cnn_layout is not None:
            kH, kW = self.kernel_size
            sH, sW = self.stride
            if (
                kH == 2 and kW == 2 and sH == 2 and sW == 2
                and (self._use_sparse_output or getattr(x, '_packed_batch', False))
            ):
                return self._forward_he_rotation(x)
            return self._forward_he_packed(x)
        else:
            # For pre-processed input, just multiply by averaging factor
            # Create a full-size plaintext with the avg_factor
            slot_count = x._cipher.size
            avg_plain = [self.avg_factor] * slot_count
            result = x.mul(avg_plain)
            return result.rescale()

    def _infer_spatial_dims(self, num_patches: int) -> Tuple[int, int]:
        hw = int(math.sqrt(num_patches))
        if hw * hw != num_patches:
            raise ValueError(
                f"Cannot infer H, W from num_patches={num_patches} (not a perfect square). "
                "Packed pooling requires square patch grids unless explicit CNN layout metadata is present."
            )
        return hw, hw

    @staticmethod
    def _output_indices_for_channels(
        num_out_patches: int,
        channels: int,
        *,
        patch_offset: int = 0,
    ) -> torch.Tensor:
        out_patch_indices = torch.arange(num_out_patches, dtype=torch.long) + patch_offset
        channel_offsets = torch.arange(channels, dtype=torch.long)
        return out_patch_indices[:, None] * channels + channel_offsets

    def _forward_he_packed_batch(self, x: "EncryptedTensor", sample_shape: Tuple[int, int]) -> "EncryptedTensor":
        num_patches, channels = sample_shape
        H, W = self._infer_spatial_dims(num_patches)
        kH, kW = self.kernel_size
        sH, sW = self.stride
        pH, pW = self.padding
        out_H = (H + 2 * pH - kH) // sH + 1
        out_W = (W + 2 * pW - kW) // sW + 1
        out_patches = out_H * out_W
        total_in = num_patches * channels
        total_out = out_patches * channels

        patch_indices = _pool_patch_indices(out_H, out_W, W, kH, kW, sH, sW)
        out_indices = self._output_indices_for_channels(out_patches, channels)
        in_indices = _expand_patch_indices_with_channels(patch_indices, channels)
        pool_weight = torch.zeros(total_out, total_in, dtype=torch.float64)
        pool_weight[
            out_indices[:, None, :].expand(-1, patch_indices.shape[1], -1).reshape(-1),
            in_indices.reshape(-1),
        ] = self.avg_factor

        batch_size = getattr(x, '_batch_size', None)
        if batch_size is None:
            raise RuntimeError("Packed average pooling requires batch_size metadata")

        x_flat = x.view(batch_size, total_in)
        result = x_flat.matmul(pool_weight)
        return result.view(batch_size, out_patches, channels)
    
    def _forward_he_packed(self, x: "EncryptedTensor") -> "EncryptedTensor":
        """Apply average pooling on im2col CNN layout using HE operations.
        
        Supports packed batches (batch_size > 1).  The pool weight matrix is
        built as a block-diagonal with one block per image so that patches
        from different images never interact.
        
        Input shape: (num_patches, channels) where num_patches = B * H * W
        Output shape: (out_patches, channels) where out_patches = B * (H/sH) * (W/sW)
        """
        import torch
        
        layout = x._cnn_layout
        if layout is None:
            raise RuntimeError("EncryptedAvgPool2d requires _cnn_layout metadata for CNN-packed input")
        num_patches = layout['num_patches']
        channels = layout['patch_features']
        batch_size = layout.get('batch_size', 1)
        
        # Per-image spatial dimensions
        if batch_size > 1:
            npp = layout.get('num_patches_per_image', num_patches // batch_size)
        else:
            npp = num_patches
        
        if 'height' in layout and 'width' in layout:
            height, width = layout['height'], layout['width']
        else:
            import math
            hw = int(math.sqrt(npp))
            if hw * hw != npp:
                raise ValueError(
                    f"Cannot infer H, W from num_patches_per_image={npp} (not a perfect square). "
                    f"For rectangular inputs, set layout['height'] and layout['width'] explicitly."
                )
            height, width = hw, hw
        H, W = height, width
        
        kH, kW = self.kernel_size
        sH, sW = self.stride
        
        # Output spatial size (per image)
        out_H = H // sH
        out_W = W // sW
        out_patches_per_image = out_H * out_W
        out_patches = out_patches_per_image * batch_size
        
        total_in = num_patches * channels   # B * H * W * C
        total_out = out_patches * channels   # B * (H/sH) * (W/sW) * C

        patch_indices = _pool_patch_indices(out_H, out_W, W, kH, kW, sH, sW)
        pool_area = patch_indices.shape[1]
        pool_weight = torch.zeros(total_out, total_in, dtype=torch.float64)
        for b in range(batch_size):
            out_indices = self._output_indices_for_channels(
                out_patches_per_image,
                channels,
                patch_offset=b * out_patches_per_image,
            )
            in_indices = _expand_patch_indices_with_channels(
                patch_indices,
                channels,
                patch_offset=b * npp,
            )
            pool_weight[
                out_indices[:, None, :].expand(-1, pool_area, -1).reshape(-1),
                in_indices.reshape(-1),
            ] = self.avg_factor
        
        # Bypass packed-matmul dispatch: create a plain 1-D wrapper without
        # packed-batch flags so that the standard matmul path is used.
        from ..tensor import EncryptedTensor as _ET
        x_flat = _ET(x._cipher, (total_in,), x._context, x._depth)
        x_flat._needs_rescale = x._needs_rescale
        result = x_flat.matmul(pool_weight, None)
        
        # Update CNN layout for next layer
        result._cnn_layout = {
            'num_patches': out_patches,
            'num_patches_per_image': out_patches_per_image,
            'patch_features': channels,
            'original_shape': layout.get('original_shape'),
            'batch_size': batch_size,
        }
        result._shape = (out_patches, channels)
        
        if batch_size > 1:
            result._packed_batch = True
            result._batch_size = batch_size
            result._slots_per_sample = out_patches_per_image * channels
        
        return result
    
    def _forward_he_rotation(self, x: "EncryptedTensor") -> "EncryptedTensor":
        """Apply average pooling using rotation-based optimization.
        
        For 2x2 pooling with stride 2, instead of sparse matmul:
        1. Use rotations to align neighboring elements
        2. Add them together
        3. Mask to keep only valid output positions
        4. Keep sparse layout (FC layer handles extraction)
        
        Supports packed batches (batch_size > 1).  Rotation offsets are
        based on the per-image width so that all images are pooled in
        parallel.  No boundary mask is needed: at every valid output
        position ``(2*out_y, 2*out_x)``, the four referenced patches
        ``(2*out_y:2*out_y+2, 2*out_x:2*out_x+2)`` lie entirely within
        the same image block, so cross-sample bleed cannot occur.
        The averaging mask zeros out all other positions.
        
        Consumes 1 multiplicative level (the averaging-mask ``mul``).
        """
        import torch
        import math
        
        layout = x._cnn_layout
        if layout is None:
            raise RuntimeError("EncryptedMaxPool2d requires _cnn_layout metadata for CNN-packed input")
        num_patches = layout['num_patches']
        channels = layout['patch_features']
        batch_size = layout.get('batch_size', 1)
        
        # Per-image spatial dimensions
        if batch_size > 1:
            npp = layout.get('num_patches_per_image', num_patches // batch_size)
        else:
            npp = num_patches
        
        if 'height' in layout and 'width' in layout:
            height, width = layout['height'], layout['width']
        else:
            hw = int(math.sqrt(npp))
            if hw * hw != npp:
                raise ValueError(
                    f"Cannot infer H, W from num_patches_per_image={npp} "
                    f"(not a perfect square). "
                    f"For rectangular inputs, set layout['height'] and "
                    f"layout['width'] explicitly."
                )
            height, width = hw, hw
        H, W = height, width
        
        kH, kW = self.kernel_size
        sH, sW = self.stride
        
        if kH != 2 or kW != 2 or sH != 2 or sW != 2:
            return self._forward_he_packed(x)
        
        out_H = H // sH
        out_W = W // sW
        out_patches_per_image = out_H * out_W
        out_patches = out_patches_per_image * batch_size
        
        total_in = num_patches * channels
        
        # Rotation offsets for 2x2 pooling, using per-image width W.
        # These work for all images simultaneously because the spatial
        # layout is identical within each image block.
        offsets = [0, channels, W * channels, (W + 1) * channels]
        
        # Sum the 4 positions via rotation and addition
        result = x
        
        for offset in offsets[1:]:  # Skip first (already have it)
            rotated = x.rotate(offset)
            result = result + rotated
        
        # Only rescale if input needed rescaling (e.g., came from a mul without rescale)
        if result._needs_rescale:
            result = result.rescale()
        
        # Create mask for valid output positions across ALL images.
        # Valid positions: (2*out_y, 2*out_x) for each image's spatial grid.
        mask = torch.zeros(total_in, dtype=torch.float64)
        valid_positions = self._get_valid_positions(out_H, out_W, W, channels, batch_size=batch_size, npp=npp)
        mask[torch.as_tensor(valid_positions, dtype=torch.long)] = self.avg_factor
        
        # Apply mask (multiply by avg_factor at valid positions, 0 elsewhere)
        # Consumes 1 multiplicative level.
        result = result.mul(mask.tolist())
        result = result.rescale()
        
        # Store the sparse layout information for downstream layers
        result._cnn_layout = {
            'num_patches': out_patches,
            'num_patches_per_image': out_patches_per_image,
            'patch_features': channels,
            'original_shape': layout.get('original_shape'),
            'batch_size': batch_size,
            'sparse': True,
            'sparse_positions': self._get_valid_positions(
                out_H, out_W, W, channels, batch_size=batch_size, npp=npp,
            ),
            'total_slots': total_in,
        }
        result._shape = (out_patches, channels)
        
        # Propagate packed-batch metadata
        if batch_size > 1:
            result._packed_batch = True
            result._batch_size = batch_size
            result._slots_per_sample = npp * channels
        
        return result
    
    def _get_valid_positions(
        self, out_H: int, out_W: int, W: int, channels: int,
        *, batch_size: int = 1, npp: int = 0,
    ) -> list:
        base_patch_indices = _pool_patch_indices(out_H, out_W, W, 1, 1, 2, 2).reshape(-1)
        positions = [
            _expand_patch_indices_with_channels(
                base_patch_indices[:, None],
                channels,
                patch_offset=batch_idx * npp,
            ).reshape(-1)
            for batch_idx in range(batch_size)
        ]
        return torch.cat(positions).tolist() if positions else []
    
    def mult_depth(self) -> int:
        """Average pooling uses 1 multiplication for scaling."""
        return 1
    
    def get_output_size(
        self,
        input_height: int,
        input_width: int,
    ) -> Tuple[int, int]:
        """Compute output spatial dimensions.
        
        Args:
            input_height: Height of the input.
            input_width: Width of the input.
            
        Returns:
            Tuple of (output_height, output_width).
        """
        kH, kW = self.kernel_size
        sH, sW = self.stride
        pH, pW = self.padding
        
        out_h = (input_height + 2 * pH - kH) // sH + 1
        out_w = (input_width + 2 * pW - kW) // sW + 1
        
        return out_h, out_w
    
    @classmethod
    def from_torch(cls, pool: torch.nn.AvgPool2d) -> "EncryptedAvgPool2d":
        """Create from a PyTorch AvgPool2d layer.
        
        Args:
            pool: The PyTorch AvgPool2d layer to convert.
            
        Returns:
            EncryptedAvgPool2d.
        """
        return cls(
            kernel_size=pool.kernel_size,
            stride=pool.stride,
            padding=pool.padding,
        )
    
    def extra_repr(self) -> str:
        return f"kernel_size={self.kernel_size}, stride={self.stride}, padding={self.padding}"


class EncryptedMaxPool2d(EncryptedModule):
    """Encrypted 2D max pooling using polynomial approximation in pure HE mode.
    
    Since CKKS doesn't support comparison, max is approximated using:
        max(a, b) ≈ (a + b + |a - b|) / 2
    
    where |x| is approximated via polynomial fitting to sqrt(x^2 + eps).
    
    Requires 2D input with CNN layout metadata (_cnn_layout). 4D and 3D inputs
    are not supported in pure HE mode.
    
    Warning:
        This is an APPROXIMATION. The output will differ from exact max pooling.
        Average error < 10% for normalized inputs in [-1, 1].
    
    Args:
        kernel_size: Size of the pooling window.
        stride: Stride of the pooling. Default: same as kernel_size.
        padding: Padding to add. Default: 0.
        degree: Polynomial degree for |x| approximation. Higher = more accurate
            but deeper circuit.
    """
    
    def __init__(
        self,
        kernel_size: Union[int, Tuple[int, int]],
        stride: Union[int, Tuple[int, int], None] = None,
        padding: Union[int, Tuple[int, int]] = 0,
        degree: int = 4,
    ) -> None:
        super().__init__()
        
        if isinstance(kernel_size, int):
            kernel_size = (kernel_size, kernel_size)
        if kernel_size[0] <= 0 or kernel_size[1] <= 0:
            raise ValueError(f"kernel_size must be positive, got {kernel_size}")
        self.kernel_size = kernel_size
        
        if stride is None:
            stride = kernel_size
        elif isinstance(stride, int):
            stride = (stride, stride)
        if stride[0] <= 0 or stride[1] <= 0:
            raise ValueError(f"stride must be positive, got {stride}")
        self.stride = stride
        
        if isinstance(padding, int):
            padding = (padding, padding)
        self.padding = padding
        
        self.degree = degree
        self.pool_area = self.kernel_size[0] * self.kernel_size[1]
        self._abs_coeffs = _smooth_abs_coeffs(degree)
    
    def _approx_abs(self, x: "EncryptedTensor") -> "EncryptedTensor":
        """Approximate |x| using polynomial: |x| ≈ sqrt(x^2 + eps)."""
        return x.poly_eval(self._abs_coeffs)
    
    def _approx_max(self, a: "EncryptedTensor", b: "EncryptedTensor") -> "EncryptedTensor":
        """Approximate max(a, b) ≈ (a + b + |a - b|) / 2."""
        sum_ab = a.add(b)
        diff_ab = a.sub(b)
        abs_diff = self._approx_abs(diff_ab).rescale()
        
        if sum_ab._needs_rescale:
            sum_ab = sum_ab.rescale()
        
        result = sum_ab.add(abs_diff)
        return result.mul(0.5).rescale()
    
    def forward(self, x: "EncryptedTensor") -> "EncryptedTensor":
        if getattr(x, '_packed_batch', False):
            sample_shape = getattr(x, '_packed_sample_shape', None) or x.shape[1:]
            if len(sample_shape) == 2:
                return self._forward_he_packed_batch(x, sample_shape)

        input_ndim = len(x.shape)

        if input_ndim == 4:
            raise RuntimeError(
                "EncryptedMaxPool2d does not support 4D input in pure HE mode. "
                "Pre-process input using ctx.encrypt_cnn_input() to create a "
                "2D CNN layout with _cnn_layout metadata."
            )
        elif input_ndim == 3:
            raise RuntimeError(
                "EncryptedMaxPool2d does not support 3D input in pure HE mode. "
                "Pre-process input using ctx.encrypt_cnn_input()."
            )
        elif input_ndim == 2 and hasattr(x, '_cnn_layout') and x._cnn_layout is not None:
            return self._forward_he_cnn(x)
        else:
            raise RuntimeError(
                f"EncryptedMaxPool2d: unsupported input. "
                f"Expected 2D tensor with _cnn_layout metadata or packed batch, "
                f"got shape={x.shape}, _cnn_layout={getattr(x, '_cnn_layout', None)}."
            )

    def _rotate_packed_within_sample(self, x: "EncryptedTensor", offset: int) -> "EncryptedTensor":
        batch_size = getattr(x, '_batch_size', None)
        slots_per_sample = getattr(x, '_slots_per_sample', None)
        if batch_size is None or slots_per_sample is None:
            raise RuntimeError("Packed max pooling requires packed batch metadata")

        slot_count = x._cipher.size
        source_mask = [0.0] * slot_count
        for batch_idx in range(batch_size):
            sample_start = batch_idx * slots_per_sample
            sample_end = sample_start + slots_per_sample
            if offset >= 0:
                valid_start = sample_start + offset
                valid_end = sample_end
            else:
                valid_start = sample_start
                valid_end = sample_end + offset
            for pos in range(max(sample_start, valid_start), min(sample_end, valid_end)):
                source_mask[pos] = 1.0

        return x.mul(source_mask).rescale().rotate(offset)

    def _forward_he_packed_batch(self, x: "EncryptedTensor", sample_shape: Tuple[int, int]) -> "EncryptedTensor":
        num_patches, channels = sample_shape
        H, W = self._infer_spatial_dims(num_patches)
        out_H = (H + 2 * self.padding[0] - self.kernel_size[0]) // self.stride[0] + 1
        out_W = (W + 2 * self.padding[1] - self.kernel_size[1]) // self.stride[1] + 1
        out_patches = out_H * out_W

        batch_size = getattr(x, '_batch_size', None)
        slots_per_sample = getattr(x, '_slots_per_sample', None)
        if batch_size is None or slots_per_sample is None:
            raise RuntimeError("Packed max pooling requires batch metadata")
        out_slots_per_sample = out_patches * channels

        slot_count = x._cipher.size

        accumulated = None
        for batch_idx in range(batch_size):
            sample_start = batch_idx * slots_per_sample
            sample_mask = [0.0] * slot_count
            for pos in range(sample_start, min(sample_start + slots_per_sample, slot_count)):
                sample_mask[pos] = 1.0

            isolated = x.mul(sample_mask).rescale()
            if sample_start:
                isolated = isolated.rotate(sample_start)
            isolated._shape = (num_patches, channels)
            isolated._packed_batch = False
            isolated._batch_size = None
            isolated._slots_per_sample = None
            isolated._packed_sample_shape = None
            isolated._cnn_layout = {
                'num_patches': num_patches,
                'patch_features': channels,
                'height': H,
                'width': W,
            }

            pooled = self._forward_he_cnn(isolated)
            target_base = batch_idx * out_slots_per_sample
            if target_base:
                pooled = pooled.rotate(-target_base)
            accumulated = pooled if accumulated is None else accumulated.add(pooled)

        if accumulated is None:
            raise RuntimeError("Packed max pooling produced no outputs")

        accumulated._shape = (batch_size, out_patches, channels)
        accumulated._packed_batch = True
        accumulated._batch_size = batch_size
        accumulated._slots_per_sample = out_slots_per_sample
        accumulated._packed_sample_shape = (out_patches, channels)
        accumulated._cnn_layout = None
        return accumulated

    def _infer_spatial_dims(self, num_patches: int) -> Tuple[int, int]:
        hw = int(math.sqrt(num_patches))
        if hw * hw != num_patches:
            raise ValueError(
                f"Cannot infer H, W from num_patches={num_patches} (not a perfect square). "
                "Packed pooling requires square patch grids unless explicit CNN layout metadata is present."
            )
        return hw, hw

    def _forward_he_cnn(self, x: "EncryptedTensor") -> "EncryptedTensor":
        layout = x._cnn_layout
        if layout is None:
            raise RuntimeError("EncryptedMaxPool2d requires _cnn_layout metadata for CNN-packed input")
        num_patches = layout['num_patches']
        channels = layout['patch_features']

        if 'height' in layout and 'width' in layout:
            height, width = layout['height'], layout['width']
        else:
            hw = int(math.sqrt(num_patches))
            if hw * hw != num_patches:
                raise ValueError(
                    f"Cannot infer H, W from num_patches={num_patches} (not a perfect square). "
                    f"For rectangular inputs, set layout['height'] and layout['width'] explicitly."
                )
            height, width = hw, hw
        H, W = height, width
        kH, kW = self.kernel_size
        sH, sW = self.stride

        out_H = (H + 2 * self.padding[0] - kH) // sH + 1
        out_W = (W + 2 * self.padding[1] - kW) // sW + 1
        out_patches = out_H * out_W
        total_in = num_patches * channels

        offsets = (
            _pool_patch_indices(1, 1, W, kH, kW, 1, 1).reshape(-1)[1:] * channels
        ).tolist()

        result = x
        for offset in offsets:
            rotated = x.rotate(offset)
            result = self._approx_max(result, rotated)

        mask = torch.zeros(total_in, dtype=torch.float64)
        valid_patch_indices = _pool_patch_indices(out_H, out_W, W, 1, 1, sH, sW).reshape(-1)
        mask_indices = _expand_patch_indices_with_channels(valid_patch_indices[:, None], channels).reshape(-1)
        mask[mask_indices] = 1.0

        result = result.mul(mask.tolist())
        result = result.rescale()

        result._cnn_layout = {
            'num_patches': out_patches,
            'patch_features': channels,
            'original_shape': layout.get('original_shape'),
        }
        result._shape = (out_patches, channels)
        result._needs_rescale = False
        result._packed_batch = False
        return result
    
    def mult_depth(self) -> int:
        """Multiplicative depth depends on polynomial degree and pooling size.
        
        Each pairwise max requires:
        - 1 subtraction (free)
        - polynomial eval for |x|: ceil(log2(degree+1)) mults
        - 1 addition (free)  
        - 1 scalar mult (for /2)
        
        For 2x2 pooling, we need 3 pairwise max operations.
        """
        poly_depth = max(1, int(math.ceil(math.log2(self.degree + 1))))
        num_pairwise_ops = self.pool_area - 1
        return poly_depth * num_pairwise_ops + 1
    
    def get_output_size(
        self,
        input_height: int,
        input_width: int,
    ) -> Tuple[int, int]:
        """Compute output spatial dimensions."""
        kH, kW = self.kernel_size
        sH, sW = self.stride
        pH, pW = self.padding
        
        out_h = (input_height + 2 * pH - kH) // sH + 1
        out_w = (input_width + 2 * pW - kW) // sW + 1
        
        return out_h, out_w
    
    @classmethod
    def from_torch(cls, pool: torch.nn.MaxPool2d) -> "EncryptedMaxPool2d":
        """Create from a PyTorch MaxPool2d layer.
        
        Args:
            pool: The PyTorch MaxPool2d layer to convert.
            
        Returns:
            EncryptedMaxPool2d with matching configuration.
            
        Note:
            The encrypted version uses polynomial approximation.
            Output will differ from exact MaxPool2d.
        """
        return cls(
            kernel_size=pool.kernel_size,
            stride=pool.stride,
            padding=pool.padding,
        )
    
    def extra_repr(self) -> str:
        return (
            f"kernel_size={self.kernel_size}, stride={self.stride}, "
            f"padding={self.padding}, degree={self.degree}"
        )
