# llmwiki-cli

English | [日本語](README-ja.md)

Standalone CLI for [llmwiki](https://github.com/ktrysmt/llmwiki), runnable outside of Claude Code.

## Requirements

- Python 3.12+
- [Claude Code](https://claude.com/claude-code) installed and on PATH — the Agent SDK spawns the `claude` binary as a subprocess. Install via:
  ```
  npm install -g @anthropic-ai/claude-code
  ```
  or follow the native installer at <https://claude.com/claude-code>.

## Authentication

Primary: `CLAUDE_CODE_OAUTH_TOKEN` (recommended).

```
claude setup-token
export CLAUDE_CODE_OAUTH_TOKEN=sk-ant-oat01-...
```

A one-year long-lived OAuth token that uses your Claude Pro / Max / Team / Enterprise subscription quota. No per-call API billing.

Fallback: `ANTHROPIC_API_KEY` (API billing) — issued at <https://console.anthropic.com>.

Resolution order: `CLAUDE_CODE_OAUTH_TOKEN` > `ANTHROPIC_API_KEY`.

## Run

### uvx (recommended, no install)

```
uvx llmwiki-cli lint
uvx llmwiki-cli ingest
uvx llmwiki-cli query "your question"
uvx llmwiki-cli docs "theme" -o out.md
```

Each run uses a fresh isolated environment. The first invocation resolves dependencies; subsequent runs start instantly from the uv cache.

### uv run (as a project dependency)

For a project that declares `llmwiki-cli` in its `pyproject.toml`:

```
uv run llmwiki-cli lint
```

One-off usage without declaring the dependency:

```
uv run --with llmwiki-cli llmwiki-cli lint
```

### Before publication / straight from the repo

Prior to PyPI release:

```
uvx --from . llmwiki-cli lint                                                  # local checkout
uvx --from git+https://github.com/ktrysmt/llmwiki-cli llmwiki-cli lint         # Git
uvx --from git+https://github.com/ktrysmt/llmwiki-cli@v0.1.0 llmwiki-cli lint  # pinned tag
```

### Persistent install

```
uv tool install llmwiki-cli
# or
pipx install llmwiki-cli
```

## Commands

```
llmwiki-cli ingest [path]                      # import + lint + fix pipeline
llmwiki-cli lint                               # read-only health check
llmwiki-cli query "question" [--write]         # natural-language query over the wiki
llmwiki-cli docs "theme" [-o out.md]           # single document
llmwiki-cli docs "theme A" "theme B" -o dir/   # multiple themes in parallel
```

`--write` on `query` enables the feedback loop: the LLM proposes relationship additions, new entities, contradiction flags, dormant promotions, and synthesis saves. 4a-4d require user confirmation; 4e (synthesis save) is applied automatically.

## Internals

Resolution order for the deterministic scripts (`llmwiki-preprocess` / `llmwiki-makeindex` / `llmwiki-decay`):

1. Bundled inside the installed wheel at `llmwiki_cli/resources/bin/`
2. PATH (when the llmwiki Claude Code plugin is installed)
3. Repository `bin/` (for editable dev checkouts)

Under uvx / uv run everything resolves via (1), so users do not need anything beyond the CLI itself (except `claude`).

The wiki page schema is bundled at `llmwiki_cli/resources/schema.md` and embedded into LLM system prompts for Phase 1 / 3 / 4 of `ingest` and for `query --write`.

## License

MIT
