"""Read/write .llmwiki/config.json with the same shape the plugin uses."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path


CONFIG_REL = Path(".llmwiki/config.json")


@dataclass
class Config:
    input_dir: str | None = None
    exclude_patterns: list[str] | None = None
    auto_approve: dict | None = None

    def to_dict(self) -> dict:
        data: dict = {}
        if self.input_dir is not None:
            data["input_dir"] = self.input_dir
        if self.exclude_patterns is not None:
            data["exclude_patterns"] = self.exclude_patterns
        if self.auto_approve is not None:
            data["auto_approve"] = self.auto_approve
        return data


def config_path(project_root: Path) -> Path:
    return project_root / CONFIG_REL


def load(project_root: Path) -> Config:
    path = config_path(project_root)
    if not path.exists():
        return Config()
    data = json.loads(path.read_text(encoding="utf-8"))
    return Config(
        input_dir=data.get("input_dir"),
        exclude_patterns=data.get("exclude_patterns"),
        auto_approve=data.get("auto_approve"),
    )


def save_input_dir(project_root: Path, input_dir: Path) -> None:
    """Merge input_dir into config.json, preserving other keys."""
    path = config_path(project_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    data["input_dir"] = str(input_dir.resolve())
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def resolve_input_dir(project_root: Path, arg: str | None) -> Path:
    """Resolve input directory: explicit arg > config.json > project root."""
    if arg:
        p = Path(arg).expanduser().resolve()
        if not p.is_dir():
            raise FileNotFoundError(f"input path not found: {p}")
        return p
    cfg = load(project_root)
    if cfg.input_dir:
        p = Path(cfg.input_dir).expanduser().resolve()
        if p.is_dir():
            return p
    return project_root.resolve()
