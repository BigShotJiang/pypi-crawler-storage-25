"""Thin wrapper over claude-agent-sdk.

The SDK spawns the `claude` binary as a subprocess and handles OAuth /
API key auth via env vars. This wrapper collects the assistant's text
output and surfaces tool-use events to a writer callback.
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from pathlib import Path


@dataclass
class RunResult:
    text: str
    turn_count: int


async def run_async(
    *,
    prompt: str,
    system_prompt: str,
    cwd: Path,
    allowed_tools: Iterable[str] = ("Read",),
    permission_mode: str = "default",
    on_event: Callable[[str], None] | None = None,
) -> RunResult:
    # Imported lazily so `llmwiki --help` works without the SDK installed.
    from claude_agent_sdk import ClaudeAgentOptions, query  # type: ignore

    options = ClaudeAgentOptions(
        system_prompt=system_prompt,
        cwd=str(cwd),
        allowed_tools=list(allowed_tools),
        permission_mode=permission_mode,
    )

    chunks: list[str] = []
    turns = 0
    async for message in query(prompt=prompt, options=options):
        turns += 1
        kind = type(message).__name__
        if on_event:
            on_event(f"[event] {kind}")
        text = getattr(message, "text", None) or getattr(message, "content", None)
        if isinstance(text, str):
            chunks.append(text)

    return RunResult(text="\n".join(chunks), turn_count=turns)


def run(
    *,
    prompt: str,
    system_prompt: str,
    cwd: Path,
    allowed_tools: Iterable[str] = ("Read",),
    permission_mode: str = "default",
    on_event: Callable[[str], None] | None = None,
) -> RunResult:
    return asyncio.run(
        run_async(
            prompt=prompt,
            system_prompt=system_prompt,
            cwd=cwd,
            allowed_tools=allowed_tools,
            permission_mode=permission_mode,
            on_event=on_event,
        )
    )
