"""/llmwiki:lint — read-only health check."""

from __future__ import annotations

import tempfile
from pathlib import Path

from rich.console import Console

from llmwiki_cli import auth, config, runner, scripts

console = Console()


LINT_SYSTEM_PROMPT = """\
You are the llmwiki lint reporter. You receive a preprocessing XML output and
a decay-candidates list. Produce a read-only human-readable report.

Report structure (Japanese OK if the user's environment suggests Japanese):

1. Summary counts: entities, orphan pages, broken links, stale pages,
   uncovered files, contradictions (needs-review count), decay candidates,
   promotion candidates, provenance gaps.
2. Top issues (up to 10), each with a concrete corrective action. Every
   fix proposal must guide the user to `llmwiki-cli ingest`.
3. Cross-entity contradictions and contradiction-source statistics:
   highlight source files appearing in 3+ contradictions.

Rules:
- Do NOT modify any file. This skill is strictly read-only.
- Do not invent data not present in the inputs.
"""


def run_lint(project_root: Path) -> int:
    wiki_dir = project_root / ".llmwiki"
    if not wiki_dir.is_dir():
        console.print("[red]error:[/red] .llmwiki/ not found. Run `llmwiki-cli ingest` first.")
        return 1

    auth.resolve()  # raises AuthError with guidance

    input_dir = config.resolve_input_dir(project_root, arg=None)
    console.print(f"[dim]input:[/dim] {input_dir}")

    with tempfile.TemporaryDirectory() as tmp:
        xml_path = Path(tmp) / "preprocess.xml"
        console.print("[dim]running llmwiki-preprocess...[/dim]")
        scripts.run(
            "llmwiki-preprocess",
            str(input_dir),
            "--llmwiki-dir",
            str(wiki_dir),
            stdout_path=xml_path,
        )

        console.print("[dim]running llmwiki-decay...[/dim]")
        decay = scripts.run(
            "llmwiki-decay",
            "--llmwiki-dir",
            str(wiki_dir),
            "--threshold-days",
            "90",
            capture=True,
        )

        prompt = (
            "Below are the deterministic outputs. Produce the lint report.\n\n"
            f"<preprocess_xml path=\"{xml_path}\">\n"
            f"{xml_path.read_text(encoding='utf-8')}\n"
            "</preprocess_xml>\n\n"
            f"<decay_output>\n{decay.stdout}\n</decay_output>\n"
        )

        result = runner.run(
            prompt=prompt,
            system_prompt=LINT_SYSTEM_PROMPT,
            cwd=project_root,
            allowed_tools=["Read"],
            permission_mode="default",
        )

    console.print(result.text)
    return 0
