"""/llmwiki:docs — generate a structured document from the wiki.

Single theme: write to --output (file) or stdout.
Multiple themes: --output must be a directory; each theme is generated in
parallel via asyncio.gather and written as `<kebab-case-theme>.md`.
"""

from __future__ import annotations

import asyncio
import re
from pathlib import Path

from rich.console import Console

from llmwiki_cli import auth, runner

console = Console()


DOCS_SYSTEM_PROMPT = """\
You are the llmwiki docs generator. Synthesize a structured document on the
requested theme by reading multiple entity pages under `.llmwiki/entities/`.

Rules:
- Read-only. Do not write under `.llmwiki/` (syntheses are written by the
  query skill, not here).
- Cite sources inline as `[[entity-id]]`.
- Surface unresolved "needs review" flags at the end.
- Structure: Overview / Components / Relationships / Open questions.

Output the document as markdown on stdout.
"""


def run_docs(project_root: Path, themes: list[str], output: Path | None) -> int:
    wiki_dir = project_root / ".llmwiki"
    if not wiki_dir.is_dir():
        console.print("[red]error:[/red] .llmwiki/ not found. Run `llmwiki-cli ingest` first.")
        return 1

    if not themes:
        console.print("[red]error:[/red] at least one theme required.")
        return 1

    auth.resolve()

    if len(themes) == 1:
        return _generate_single(project_root, themes[0], output)
    return _generate_parallel(project_root, themes, output)


def _generate_single(project_root: Path, theme: str, output: Path | None) -> int:
    result = runner.run(
        prompt=f"Theme: {theme}",
        system_prompt=DOCS_SYSTEM_PROMPT,
        cwd=project_root,
        allowed_tools=["Read"],
        permission_mode="default",
    )
    if output:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(result.text, encoding="utf-8")
        console.print(f"[green]wrote:[/green] {output}")
    else:
        console.print(result.text)
    return 0


def _generate_parallel(project_root: Path, themes: list[str], output: Path | None) -> int:
    if output is None or (output.exists() and not output.is_dir()):
        console.print(
            "[red]error:[/red] multiple themes require --output to point at a directory."
        )
        return 1
    output.mkdir(parents=True, exist_ok=True)

    console.print(f"[dim]generating {len(themes)} document(s) in parallel...[/dim]")

    async def _gather() -> list[tuple[str, runner.RunResult]]:
        coros = [
            runner.run_async(
                prompt=f"Theme: {t}",
                system_prompt=DOCS_SYSTEM_PROMPT,
                cwd=project_root,
                allowed_tools=["Read"],
                permission_mode="default",
            )
            for t in themes
        ]
        results = await asyncio.gather(*coros, return_exceptions=True)
        paired: list[tuple[str, runner.RunResult]] = []
        for theme, r in zip(themes, results, strict=True):
            if isinstance(r, Exception):
                console.print(f"[red]failed:[/red] {theme}: {r}")
                continue
            paired.append((theme, r))
        return paired

    paired = asyncio.run(_gather())
    for theme, result in paired:
        filename = _kebab_case(theme) + ".md"
        path = output / filename
        path.write_text(result.text, encoding="utf-8")
        console.print(f"[green]wrote:[/green] {path}")

    failures = len(themes) - len(paired)
    return 0 if failures == 0 else 1


def _kebab_case(s: str) -> str:
    s = s.strip().lower()
    s = re.sub(r"[\s_]+", "-", s)
    s = re.sub(r"[^a-z0-9\-]+", "", s)
    s = re.sub(r"-+", "-", s).strip("-")
    return s or "untitled"
