"""/llmwiki:query — natural language query against the wiki.

Two-pass when `--write` is set:

  Pass 1 (read-only): LLM answers the question and emits structured
  feedback proposals (4a-4e) as JSON.

  Pass 2 (writes): CLI auto-applies 4e (synthesis save), prompts the user
  per-item for 4a-4d, then the LLM applies approved items.

Without `--write`, only Pass 1 runs and the wiki is untouched.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

from rich.console import Console
from rich.prompt import Confirm

from llmwiki_cli import auth, runner

console = Console()


QUERY_SYSTEM_PROMPT_BASE = """\
You are the llmwiki query responder. Use the knowledge base under
`.llmwiki/` (index.xml + entities/**/*.md + entities.json).

Procedure:
1. Read `.llmwiki/index.xml` to identify related entities.
2. Read up to 10 related entity pages; follow Relations one hop.
3. Cite sources inline as `[[entity-id]]`.
4. Flag any "needs review" items explicitly.
5. Lower priority for pages with `status: dormant`.
"""


QUERY_PROPOSE_SUFFIX = """\

After the answer, emit a single block with proposals for feedback writes
discovered during answering. Use this exact format:

<proposals>
```json
[
  {"type": "4a", "entity_a": "...", "entity_b": "...", "description": "..."},
  {"type": "4b", "entity_id": "...", "category": "...", "description": "..."},
  {"type": "4c", "entity_id": "...", "description": "..."},
  {"type": "4d", "entity_id": "...", "description": "..."},
  {"type": "4e", "theme": "kebab-case-theme", "source_entities": ["a", "b"]}
]
```
</proposals>

Types:
- 4a: new relationship between two existing entities
- 4b: propose creating a new entity
- 4c: contradiction discovered — flag needs review
- 4d: dormant page re-referenced — propose promotion
- 4e: synthesized answer worth saving (spans multiple entities with analysis)

Emit `<proposals>[]</proposals>` if nothing. Do not write to files in
this pass — proposals only.
"""


QUERY_APPLY_PROMPT = """\
Apply the following approved feedback items to the wiki. Follow the
llmwiki schema rules:

- 4a: Read both pages, add bidirectional frontmatter `related` entries,
  append `[[B]] -- description` to `## Relations` (and vice versa), update
  `updated`, add Changelog entries on both pages.
- 4b: Create `.llmwiki/entities/<category>/<entity-id>.md` from the
  template. Add to `entities.json` (kebab-case IDs, JA+EN aliases).
  Bidirectional Relations on related existing pages.
- 4c: Record both values with provenance in `## Key Facts` and add
  "needs review". Update `updated`. Changelog: contradiction detected.
- 4d: Remove `status: dormant` from page + entities.json. Changelog:
  reactivated. Update `updated`.
- 4e: Save `.llmwiki/syntheses/<kebab-case-theme>.md` with frontmatter
  `source_type: derived`, `generated: <today>`, `source_entities: [...]`.

Append a log entry to `.llmwiki/log.md`:
`## [YYYY-MM-DD] query | <types applied and targets>`
"""


def run_query(project_root: Path, question: str, write_feedback: bool = False) -> int:
    wiki_dir = project_root / ".llmwiki"
    if not wiki_dir.is_dir():
        console.print("[red]error:[/red] .llmwiki/ not found. Run `llmwiki-cli ingest` first.")
        return 1
    if not (wiki_dir / "index.xml").is_file():
        console.print("[red]error:[/red] .llmwiki/index.xml missing. Run `llmwiki-cli ingest` first.")
        return 1

    auth.resolve()

    system_prompt = QUERY_SYSTEM_PROMPT_BASE
    if write_feedback:
        system_prompt += QUERY_PROPOSE_SUFFIX

    result = runner.run(
        prompt=question,
        system_prompt=system_prompt,
        cwd=project_root,
        allowed_tools=["Read"],
        permission_mode="default",
    )

    answer, proposals = _split_answer_and_proposals(result.text)
    console.print(answer)

    if not write_feedback:
        return 0

    approved = _collect_feedback_approvals(proposals)
    if not approved:
        console.print("[dim]No feedback approved.[/dim]")
        return 0

    runner.run(
        prompt=(
            "Approved feedback items:\n"
            f"```json\n{json.dumps(approved, ensure_ascii=False, indent=2)}\n```\n"
        ),
        system_prompt=QUERY_APPLY_PROMPT,
        cwd=project_root,
        allowed_tools=["Read", "Write", "Edit"],
        permission_mode="acceptEdits",
    )
    console.print(f"[green]Applied {len(approved)} feedback item(s).[/green]")
    return 0


_PROPOSALS_RE = re.compile(
    r"<proposals>\s*```json\s*(\[[\s\S]*?\])\s*```\s*</proposals>"
)


def _split_answer_and_proposals(text: str) -> tuple[str, list[dict]]:
    m = _PROPOSALS_RE.search(text)
    if not m:
        return text, []
    answer = text[: m.start()].rstrip()
    try:
        proposals = json.loads(m.group(1))
        if not isinstance(proposals, list):
            return answer, []
        return answer, [p for p in proposals if isinstance(p, dict)]
    except json.JSONDecodeError:
        return answer, []


def _collect_feedback_approvals(proposals: list[dict]) -> list[dict]:
    if not proposals:
        return []

    approved: list[dict] = []
    for p in proposals:
        kind = p.get("type", "")
        if kind == "4e":
            approved.append(p)
            console.print(
                f"[dim]auto-save synthesis:[/dim] {p.get('theme', '?')}"
            )
            continue
        label = {
            "4a": "Add relationship",
            "4b": "Create new entity",
            "4c": "Flag contradiction",
            "4d": "Promote dormant",
        }.get(kind, f"Unknown ({kind})")
        summary = p.get("description") or json.dumps(
            {k: v for k, v in p.items() if k != "type"}, ensure_ascii=False
        )
        console.print(f"\n[yellow]{label}:[/yellow] {summary}")
        if Confirm.ask("  Apply?", default=False):
            approved.append(p)

    return approved
