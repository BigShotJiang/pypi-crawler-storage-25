"""`llmwiki-cli ingest` — import + lint + fix pipeline.

Phase 0 (preprocess) and Phase 5 (reindex) run via deterministic scripts.
Phase 1 (ingest), Phase 3 (auto-fix), Phase 4 (approved changes) are LLM
passes. Phase 4 collects user approval through rich.Prompt before handing
items to the LLM for application.
"""

from __future__ import annotations

import tempfile
from pathlib import Path

from rich.console import Console
from rich.prompt import Confirm

from llmwiki_cli import auth, config, runner, scripts, xml_parse
from llmwiki_cli.resources_loader import load_schema

console = Console()

PHASE1_CHUNK_SIZE = 5
DECAY_THRESHOLD_DAYS = 90


SYSTEM_PROMPT_BASE = """\
You are the llmwiki ingest pipeline running inside the CLI harness. Write
paths are restricted to `.llmwiki/` under the cwd. Input directory files
are READ-ONLY. Never delete wiki pages — flag stale/orphan only.

Wiki page schema:
---
{schema}
---
"""


SYSTEM_PROMPT_PHASE1 = SYSTEM_PROMPT_BASE + """\
Task: Phase 1 (ingestion). For each source file in the chunk:

1. Read the file with the Read tool.
2. Determine `source_type` (primary / secondary / derived) from path + content.
3. Extract entities + relationships beyond dictionary-matched `known_entities`.
4. Create or update wiki pages at `.llmwiki/entities/<category>/<entity-id>.md`
   following the schema. If the page exists, merge per schema rules.
5. Update `.llmwiki/entities.json` (lowercase kebab-case IDs; aliases in
   Japanese + English). Add relationships bidirectionally.
6. Record each source's SHA-256 and `source_type` in frontmatter `sources[]`.
7. Attach fact-level provenance: `- Fact [source: filename, source_type, YYYY-MM-DD]`.
8. For dormant pages whose source reappears: remove `status: dormant`,
   remove it from entities.json, add a Changelog entry, refresh `updated`.

If values contradict existing content, KEEP BOTH with dates and flag
"needs review". Do not resolve contradictions here. At the end, report
counts of pages created / updated / reactivated.
"""


SYSTEM_PROMPT_PHASE3 = SYSTEM_PROMPT_BASE + """\
Task: Phase 3 (auto-fix). For each contradiction page, classify as
temporal / scope / genuine / none. Apply ONLY the auto-resolvable cases:

- temporal where BOTH sources are `primary`: adopt newer value. Log
  Changelog `YYYY-MM-DD: auto-resolved (temporal, primary+primary) — ...`
- scope: keep both values, remove the "needs review" flag.
  Log `YYYY-MM-DD: auto-resolved (scope)`
- none (false positive): remove the flag.
  Log `YYYY-MM-DD: auto-resolved (false positive)`

Do NOT touch genuine or mixed-trust temporal contradictions — those go to
Phase 4 with user approval.

Dormant promotion (references > 0 OR recent source updates in frontmatter):
reactivate automatically — remove `status: dormant`, remove it from
entities.json, add Changelog entry, update `updated` to today.

Provenance backfill: for Key Facts missing provenance tags, infer from
the page's `sources[]` frontmatter when unambiguous; leave ambiguous ones.

After writing, perform a propagation check: for each modified page, read
its `related` entries (1 hop) and semantically verify the new value does
not conflict with facts in related pages. If it does, flag both pages
with "needs review" and log the cross-entity finding.

Report counts of fixes applied by category.
"""


SYSTEM_PROMPT_PHASE4 = SYSTEM_PROMPT_BASE + """\
Task: Phase 4 (apply user-approved changes). The CLI already collected
user approvals. Apply ONLY the changes in the user prompt below. For each:

- Temporal / genuine contradiction resolution:
  1. Keep the adopted value with `- Adopted value [source: ..., YYYY-MM-DD]`.
  2. Append Changelog: `YYYY-MM-DD: Adopted value A, discarded value B (reason: ...)`.
  3. Remove "needs review" flag. Update frontmatter `updated` to today.
- Decay demotion:
  1. Add `status: dormant` to the page's frontmatter.
  2. Add `"status": "dormant"` to the entity entry in entities.json.
  3. Changelog: `YYYY-MM-DD: Demoted to dormant (not updated for N days, 0 references)`.

After applying, run a propagation check (1 hop) and flag any new
cross-entity contradictions.
"""


def run_ingest(project_root: Path, path_arg: str | None) -> int:
    auth.resolve()

    input_dir = config.resolve_input_dir(project_root, path_arg)
    console.print(f"[dim]input:[/dim] {input_dir}")

    wiki_dir = project_root / ".llmwiki"
    (wiki_dir / "entities").mkdir(parents=True, exist_ok=True)

    schema = load_schema()
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".xml", delete=False, encoding="utf-8"
    ) as tmp:
        xml_path = Path(tmp.name)

    try:
        console.print("[dim]Phase 0: preprocess...[/dim]")
        scripts.run("llmwiki-makeindex", "--llmwiki-dir", str(wiki_dir))
        _run_preprocess(input_dir, wiki_dir, xml_path)

        files_to_ingest = xml_parse.parse_files_to_ingest(xml_path)
        if files_to_ingest:
            _phase1_ingest(project_root, schema, files_to_ingest, xml_path)
        else:
            console.print("[green]Phase 1: no new/updated files.[/green]")

        console.print("[dim]Phase 2: re-scan + decay...[/dim]")
        _run_preprocess(input_dir, wiki_dir, xml_path)
        decay_xml = _run_decay(wiki_dir)

        contradictions = xml_parse.parse_contradictions(xml_path)
        decay_candidates = xml_parse.parse_decay_candidates(decay_xml)

        if contradictions or decay_candidates:
            _phase3_autofix(project_root, schema, xml_path, decay_xml)
            # Re-scan after Phase 3; auto-resolved items are gone from the lint output.
            _run_preprocess(input_dir, wiki_dir, xml_path)
            decay_xml = _run_decay(wiki_dir)
            contradictions = xml_parse.parse_contradictions(xml_path)
            decay_candidates = xml_parse.parse_decay_candidates(decay_xml)

        approvals = _phase4_collect_approvals(contradictions, decay_candidates)
        if approvals:
            _phase4_apply(project_root, schema, approvals, xml_path)
        else:
            console.print("[green]Phase 4: nothing requires approval.[/green]")

        console.print("[dim]Phase 5: reindex + persist config...[/dim]")
        scripts.run("llmwiki-makeindex", "--llmwiki-dir", str(wiki_dir))
        config.save_input_dir(project_root, input_dir)

    finally:
        xml_path.unlink(missing_ok=True)

    return 0


def _run_preprocess(input_dir: Path, wiki_dir: Path, xml_path: Path) -> None:
    scripts.run(
        "llmwiki-preprocess",
        str(input_dir),
        "--llmwiki-dir",
        str(wiki_dir),
        stdout_path=xml_path,
    )


def _run_decay(wiki_dir: Path) -> str:
    r = scripts.run(
        "llmwiki-decay",
        "--llmwiki-dir",
        str(wiki_dir),
        "--threshold-days",
        str(DECAY_THRESHOLD_DAYS),
        capture=True,
    )
    return r.stdout


def _phase1_ingest(
    project_root: Path,
    schema: str,
    files: list[xml_parse.FileToIngest],
    xml_path: Path,
) -> None:
    total = len(files)
    chunks = [files[i : i + PHASE1_CHUNK_SIZE] for i in range(0, total, PHASE1_CHUNK_SIZE)]
    console.print(
        f"[dim]Phase 1: ingesting {total} files "
        f"in {len(chunks)} chunk(s) of up to {PHASE1_CHUNK_SIZE}...[/dim]"
    )

    preprocess_xml = xml_path.read_text(encoding="utf-8")
    system_prompt = SYSTEM_PROMPT_PHASE1.format(schema=schema)

    for i, chunk in enumerate(chunks, start=1):
        file_list = "\n".join(f"- [{f.kind}] {f.path}" for f in chunk)
        prompt = (
            f"Chunk {i}/{len(chunks)}. Process ONLY these files in this turn:\n"
            f"{file_list}\n\n"
            f"Reference — preprocess XML (shared dictionaries + known_entities):\n"
            f"<preprocess_xml>\n{preprocess_xml}\n</preprocess_xml>\n"
        )
        result = runner.run(
            prompt=prompt,
            system_prompt=system_prompt,
            cwd=project_root,
            allowed_tools=["Read", "Write", "Edit"],
            permission_mode="acceptEdits",
        )
        console.print(result.text)


def _phase3_autofix(
    project_root: Path,
    schema: str,
    xml_path: Path,
    decay_xml: str,
) -> None:
    console.print("[dim]Phase 3: auto-fix...[/dim]")
    system_prompt = SYSTEM_PROMPT_PHASE3.format(schema=schema)
    preprocess_xml = xml_path.read_text(encoding="utf-8")
    prompt = (
        "Auto-fix contradictions and dormant-promotion candidates using the "
        "inputs below. Only apply auto-resolvable cases as defined in the "
        "system prompt.\n\n"
        f"<preprocess_xml>\n{preprocess_xml}\n</preprocess_xml>\n\n"
        f"<decay_xml>\n{decay_xml}\n</decay_xml>\n"
    )
    result = runner.run(
        prompt=prompt,
        system_prompt=system_prompt,
        cwd=project_root,
        allowed_tools=["Read", "Write", "Edit"],
        permission_mode="acceptEdits",
    )
    console.print(result.text)


def _phase4_collect_approvals(
    contradictions: list[xml_parse.Contradiction],
    decay_candidates: list[xml_parse.DecayCandidate],
) -> list[dict]:
    demotable = [
        d
        for d in decay_candidates
        if d.incoming_references == 0 and d.days_since_update >= DECAY_THRESHOLD_DAYS
    ]
    if not contradictions and not demotable:
        return []

    console.print()
    console.print("[bold]Phase 4: approval batch[/bold]")
    console.print(
        f"  contradictions: {len(contradictions)}  |  decay demotion candidates: {len(demotable)}"
    )
    console.print("Respond y/n per item, or hit Ctrl+C to abort.")

    approvals: list[dict] = []
    all_yes = False

    for c in sorted(contradictions, key=lambda x: -x.urgency):
        console.print(
            f"\n[yellow]Contradiction[/yellow] [[cyan]{c.entity_id}[/cyan]] "
            f"count={c.count} days_flagged={c.days_since_flagged} urgency={c.urgency}"
        )
        console.print("  Resolve using the higher-trust / newer source value.")
        if all_yes or Confirm.ask("  Approve resolution?", default=False):
            approvals.append({"kind": "contradiction", "entity_id": c.entity_id})

    for d in sorted(demotable, key=lambda x: -x.days_since_update):
        severity = "strongly recommend" if d.days_since_update > 180 else "propose"
        console.print(
            f"\n[yellow]Decay demotion[/yellow] [[cyan]{d.entity_id}[/cyan]] "
            f"days_since_update={d.days_since_update} refs={d.incoming_references} ({severity})"
        )
        if all_yes or Confirm.ask("  Approve demotion?", default=False):
            approvals.append(
                {
                    "kind": "decay",
                    "entity_id": d.entity_id,
                    "category": d.category,
                    "days_since_update": d.days_since_update,
                }
            )

    return approvals


def _phase4_apply(
    project_root: Path,
    schema: str,
    approvals: list[dict],
    xml_path: Path,
) -> None:
    console.print(f"[dim]Phase 4: applying {len(approvals)} approved change(s)...[/dim]")
    system_prompt = SYSTEM_PROMPT_PHASE4.format(schema=schema)
    preprocess_xml = xml_path.read_text(encoding="utf-8")
    items = "\n".join(
        f"- {a}" for a in approvals
    )
    prompt = (
        "Apply the following user-approved changes. Do NOT touch anything "
        "else.\n\n"
        f"<approved_changes>\n{items}\n</approved_changes>\n\n"
        "Reference — current preprocess XML:\n"
        f"<preprocess_xml>\n{preprocess_xml}\n</preprocess_xml>\n"
    )
    result = runner.run(
        prompt=prompt,
        system_prompt=system_prompt,
        cwd=project_root,
        allowed_tools=["Read", "Write", "Edit"],
        permission_mode="acceptEdits",
    )
    console.print(result.text)
