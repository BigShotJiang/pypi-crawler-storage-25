"""Authentication resolution for llmwiki CLI.

Priority:
  1. CLAUDE_CODE_OAUTH_TOKEN (subscription-based, generated via `claude setup-token`)
  2. ANTHROPIC_API_KEY (API billing)

The Agent SDK reads these env vars itself — this module only validates presence
and emits a helpful error when both are missing.
"""

from __future__ import annotations

import os
from dataclasses import dataclass


class AuthError(RuntimeError):
    pass


@dataclass(frozen=True)
class AuthInfo:
    kind: str  # "oauth" | "api_key"
    source_env: str


def resolve() -> AuthInfo:
    if os.environ.get("CLAUDE_CODE_OAUTH_TOKEN"):
        return AuthInfo(kind="oauth", source_env="CLAUDE_CODE_OAUTH_TOKEN")
    if os.environ.get("ANTHROPIC_API_KEY"):
        return AuthInfo(kind="api_key", source_env="ANTHROPIC_API_KEY")
    raise AuthError(
        "No credentials found. Set one of:\n"
        "  CLAUDE_CODE_OAUTH_TOKEN  (run `claude setup-token`; uses Claude Pro/Max/Team/Enterprise)\n"
        "  ANTHROPIC_API_KEY        (from https://console.anthropic.com)"
    )
