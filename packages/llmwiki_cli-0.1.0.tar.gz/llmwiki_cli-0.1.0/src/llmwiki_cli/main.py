"""llmwiki CLI entry point."""

from __future__ import annotations

import sys
from pathlib import Path

import typer
from rich.console import Console

from llmwiki_cli import __version__, auth
from llmwiki_cli.commands import docs as docs_cmd
from llmwiki_cli.commands import ingest as ingest_cmd
from llmwiki_cli.commands import lint as lint_cmd
from llmwiki_cli.commands import query as query_cmd

app = typer.Typer(
    help="llmwiki — entity-based knowledge wiki CLI.",
    no_args_is_help=True,
    add_completion=False,
    context_settings={"help_option_names": ["-h", "--help"]},
)
console = Console(stderr=True)


def _project_root() -> Path:
    return Path.cwd()


@app.command(help="Full pipeline: import + lint + fix. Writes to .llmwiki/.")
def ingest(
    path: str | None = typer.Argument(None, help="Input directory (overrides config)."),
) -> None:
    try:
        code = ingest_cmd.run_ingest(_project_root(), path)
    except auth.AuthError as e:
        console.print(f"[red]auth error:[/red] {e}")
        raise typer.Exit(2)
    raise typer.Exit(code)


@app.command(help="Read-only health check of the wiki.")
def lint() -> None:
    try:
        code = lint_cmd.run_lint(_project_root())
    except auth.AuthError as e:
        console.print(f"[red]auth error:[/red] {e}")
        raise typer.Exit(2)
    raise typer.Exit(code)


@app.command(help="Query the wiki with a natural language question.")
def query(
    question: list[str] = typer.Argument(..., help="Question text."),
    write: bool = typer.Option(
        False,
        "--write",
        help="Also write back approved feedback (relationships, new entities, "
        "contradictions, dormant promotion, synthesis save).",
    ),
) -> None:
    try:
        code = query_cmd.run_query(_project_root(), " ".join(question), write_feedback=write)
    except auth.AuthError as e:
        console.print(f"[red]auth error:[/red] {e}")
        raise typer.Exit(2)
    raise typer.Exit(code)


@app.command(
    help="Generate one or more documents from the wiki. Multiple themes run in parallel."
)
def docs(
    themes: list[str] = typer.Argument(
        ...,
        help="One or more themes. Each positional arg is a separate theme. "
        "Multiple themes require --output to point at a directory.",
    ),
    output: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="File (single theme) or directory (multiple themes). "
        "Omit for single-theme stdout.",
    ),
) -> None:
    try:
        code = docs_cmd.run_docs(_project_root(), themes, output)
    except auth.AuthError as e:
        console.print(f"[red]auth error:[/red] {e}")
        raise typer.Exit(2)
    raise typer.Exit(code)


@app.command(help="Print CLI version.")
def version() -> None:
    print(__version__)


if __name__ == "__main__":
    sys.exit(app())
