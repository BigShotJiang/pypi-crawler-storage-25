"""Bundled-resource loaders.

Resolves package-data files (schema.md, etc.) in this order:

1. Bundled inside the installed wheel via importlib.resources
2. Repository `shared/` — for editable dev checkouts where force-include
   has not copied files into the source tree

The wheel build uses hatch force-include to place `shared/schema.md` at
`llmwiki_cli/resources/schema.md`, so in installed deployments path (1)
always resolves.
"""

from __future__ import annotations

from importlib.resources import files
from pathlib import Path


def _dev_shared() -> Path:
    # resources_loader.py -> llmwiki_cli -> src -> repo root -> shared/
    return Path(__file__).resolve().parents[2] / "shared"


def load_schema() -> str:
    try:
        res = files("llmwiki_cli").joinpath("resources", "schema.md")
        if res.is_file():
            return res.read_text(encoding="utf-8")
    except (ModuleNotFoundError, FileNotFoundError):
        pass
    dev_path = _dev_shared() / "schema.md"
    if dev_path.is_file():
        return dev_path.read_text(encoding="utf-8")
    raise FileNotFoundError(
        "schema.md not found in bundled resources or shared/. "
        "Reinstall llmwiki-cli."
    )
