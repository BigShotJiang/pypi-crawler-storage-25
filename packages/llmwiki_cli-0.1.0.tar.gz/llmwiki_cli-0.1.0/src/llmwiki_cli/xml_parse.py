"""Parsers for llmwiki-preprocess and llmwiki-decay XML outputs."""

from __future__ import annotations

import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path


@dataclass
class FileToIngest:
    path: str
    kind: str  # "new" | "updated"


@dataclass
class Contradiction:
    entity_id: str
    count: int
    days_since_flagged: int
    urgency: int


@dataclass
class DecayCandidate:
    entity_id: str
    category: str
    updated: str
    days_since_update: int
    incoming_references: int


def parse_files_to_ingest(xml_path: Path) -> list[FileToIngest]:
    root = ET.parse(xml_path).getroot()
    out: list[FileToIngest] = []
    for el in (root.find("new-files") or []):
        p = el.get("path")
        if p:
            out.append(FileToIngest(path=p, kind="new"))
    for el in (root.find("updated-files") or []):
        p = el.get("path")
        if p:
            out.append(FileToIngest(path=p, kind="updated"))
    return out


def parse_stats(xml_path: Path) -> dict[str, int]:
    root = ET.parse(xml_path).getroot()
    stats_el = root.find("stats")
    if stats_el is None:
        return {}
    return {k: int(v) for k, v in stats_el.attrib.items() if v.isdigit()}


def parse_contradictions(xml_path: Path) -> list[Contradiction]:
    root = ET.parse(xml_path).getroot()
    contr_el = root.find("lint/contradictions")
    if contr_el is None:
        return []
    out: list[Contradiction] = []
    for e in contr_el.findall("entity"):
        out.append(
            Contradiction(
                entity_id=e.get("id", ""),
                count=int(e.get("count", "0")),
                days_since_flagged=int(e.get("days-since-flagged", "0")),
                urgency=int(e.get("urgency", "0")),
            )
        )
    return out


def parse_decay_candidates(decay_xml: str) -> list[DecayCandidate]:
    if not decay_xml.strip():
        return []
    root = ET.fromstring(decay_xml)
    out: list[DecayCandidate] = []
    for c in root.findall("candidate"):
        out.append(
            DecayCandidate(
                entity_id=c.get("entity-id", ""),
                category=c.get("category", ""),
                updated=c.get("updated", ""),
                days_since_update=int(c.get("days-since-update", "0")),
                incoming_references=int(c.get("incoming-references", "0")),
            )
        )
    return out
