"""Locate and invoke llmwiki-* deterministic scripts.

Resolution order:
  1. Bundled inside the installed wheel via importlib.resources
     (works for shiv / wheel / pip install — the portable path).
  2. PATH — when the Claude Code plugin is installed, `bin/` is on PATH.
  3. Repo `bin/` — for editable dev checkouts.

Scripts are always invoked via `sys.executable` so the shebang line and
filesystem exec-bit of the extracted file do not matter (important for
zipapp extractions and Windows).
"""

from __future__ import annotations

import shutil
import subprocess
import sys
from contextlib import ExitStack
from importlib.resources import as_file, files
from importlib.resources.abc import Traversable
from pathlib import Path

SCRIPTS = ("llmwiki-preprocess", "llmwiki-makeindex", "llmwiki-decay")


def _bundled(name: str) -> Traversable | None:
    try:
        res = files("llmwiki_cli").joinpath("resources", "bin", name)
    except (ModuleNotFoundError, FileNotFoundError):
        return None
    return res if res.is_file() else None


def _repo_bin() -> Path:
    # scripts.py -> llmwiki_cli -> src -> repo root / bin
    return Path(__file__).resolve().parents[2] / "bin"


def _path_resolved(name: str) -> Path | None:
    p = shutil.which(name)
    return Path(p) if p else None


def _invoke(cmd: list[str], capture: bool, stdout_path: Path | None) -> subprocess.CompletedProcess:
    if stdout_path is not None:
        with open(stdout_path, "w", encoding="utf-8") as f:
            return subprocess.run(cmd, stdout=f, check=True)
    return subprocess.run(cmd, capture_output=capture, text=True, check=True)


def run(
    name: str,
    *args: str,
    capture: bool = False,
    stdout_path: Path | None = None,
) -> subprocess.CompletedProcess:
    if name not in SCRIPTS:
        raise ValueError(f"unknown script: {name}")

    bundled = _bundled(name)
    if bundled is not None:
        with ExitStack() as stack:
            path = stack.enter_context(as_file(bundled))
            return _invoke([sys.executable, str(path), *args], capture, stdout_path)

    on_path = _path_resolved(name)
    if on_path is not None:
        return _invoke([sys.executable, str(on_path), *args], capture, stdout_path)

    candidate = _repo_bin() / name
    if candidate.is_file():
        return _invoke([sys.executable, str(candidate), *args], capture, stdout_path)

    raise FileNotFoundError(
        f"{name} not found. Install `llmwiki-cli` (bundled scripts) "
        f"or the llmwiki Claude Code plugin (scripts on PATH)."
    )
