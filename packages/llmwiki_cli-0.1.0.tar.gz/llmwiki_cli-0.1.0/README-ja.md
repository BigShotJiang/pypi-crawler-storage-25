# llmwiki-cli

[English](README.md) | 日本語

[llmwiki](https://github.com/ktrysmt/llmwiki) のスタンドアロン CLI 実装。Claude Code の外でも動作する。

## 前提

- Python 3.12+
- [Claude Code](https://claude.com/claude-code) が PATH に必要。Agent SDK が `claude` バイナリを spawn するため。インストール:
  ```
  npm install -g @anthropic-ai/claude-code
  ```
  または <https://claude.com/claude-code> のネイティブインストーラを使用。

## 認証

推奨: `CLAUDE_CODE_OAUTH_TOKEN`

```
claude setup-token
export CLAUDE_CODE_OAUTH_TOKEN=sk-ant-oat01-...
```

1 年有効の長寿命 OAuth トークン。Claude Pro / Max / Team / Enterprise のサブスクリプション枠を使用し、API 課金は発生しない。

フォールバック: `ANTHROPIC_API_KEY`（API 課金）— <https://console.anthropic.com> で発行。

解決順: `CLAUDE_CODE_OAUTH_TOKEN` > `ANTHROPIC_API_KEY`。

## 実行

### uvx（推奨、インストール不要）

```
uvx llmwiki-cli lint
uvx llmwiki-cli ingest
uvx llmwiki-cli query "質問文"
uvx llmwiki-cli docs "テーマ" -o out.md
```

毎回新しい隔離環境で起動。初回のみ依存解決で時間がかかるが、2 回目以降は uv のキャッシュから即起動。

### uv run（プロジェクト依存として）

`pyproject.toml` に `llmwiki-cli` を宣言したプロジェクトで:

```
uv run llmwiki-cli lint
```

その場限りで使いたいときは:

```
uv run --with llmwiki-cli llmwiki-cli lint
```

### 公開前 / リポジトリから直接

PyPI 公開前に試す場合:

```
uvx --from . llmwiki-cli lint                                                  # ローカルチェックアウト
uvx --from git+https://github.com/ktrysmt/llmwiki-cli llmwiki-cli lint         # Git
uvx --from git+https://github.com/ktrysmt/llmwiki-cli@v0.1.0 llmwiki-cli lint  # タグ固定
```

### 従来型インストール

```
uv tool install llmwiki-cli
# または
pipx install llmwiki-cli
```

## コマンド

```
llmwiki-cli ingest [path]                      # import + lint + fix パイプライン
llmwiki-cli lint                               # 読み取り専用ヘルスチェック
llmwiki-cli query "質問文" [--write]           # ウィキへの自然言語クエリ
llmwiki-cli docs "テーマ" [-o out.md]          # 単体ドキュメント生成
llmwiki-cli docs "テーマA" "テーマB" -o dir/   # 複数テーマを並列生成
```

`query --write` はフィードバックループを有効化。LLM が関係性追加・新エンティティ・矛盾フラグ・dormant 昇格・synthesis 保存を提案。4a-4d はユーザー承認必須、4e（synthesis 保存）は自動適用。

## 内部仕様

決定論スクリプト（`llmwiki-preprocess` / `llmwiki-makeindex` / `llmwiki-decay`）の解決順:

1. パッケージ同梱（wheel 内 `llmwiki_cli/resources/bin/`）
2. PATH（llmwiki Claude Code プラグイン経由でインストール済みの場合）
3. リポジトリ `bin/`（editable dev チェックアウト用）

uvx / uv run 経由ではすべて (1) を使用するため、ユーザーは CLI 本体以外を用意する必要がない（`claude` を除く）。

ウィキページスキーマは `llmwiki_cli/resources/schema.md` に同梱され、`ingest` の Phase 1 / 3 / 4 および `query --write` の LLM システムプロンプトに埋め込まれる。

## ライセンス

MIT
