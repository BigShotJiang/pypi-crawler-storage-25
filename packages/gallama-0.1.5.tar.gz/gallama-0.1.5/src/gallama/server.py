import time
import sys
import httpx
from fastapi import FastAPI, HTTPException, Request, APIRouter
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, PlainTextResponse, StreamingResponse
from starlette.types import ASGIApp, Receive, Scope, Send
from collections import defaultdict
from typing import Union
from gallama.data_classes.data_class import ModelSpec
from gallama.data_classes import  ModelInstanceInfo,  ModelInfo
from gallama.server_engine import create_options_response
from gallama.utils import parse_request_body
from gallama.utils.utils import format_request_body_for_logging
from typing import List, Dict
from gallama.config import ConfigManager
from gallama.server_engine import close_forward_http_client, forward_request
import shutil
import asyncio
import uvicorn
import argparse
from gallama.utils.utils import get_package_file_path
import os
import json
import base64
from gallama.server_routes import (
    responses_ws_router,
    server_management_router,
    realtime_router,
    periodic_health_check,
    stop_model_instance
)
from gallama.server_engine import log_model_status
from gallama.dependencies_server import (
    get_responses_websocket_hub,
    get_server_manager,
    get_server_logger,
    start_log_receiver,
    DEFAULT_ZMQ_URL,
    configure_server_logging,
)
from gallama.server_engine.responses_ws_bridge import (
    extract_response_ws_keys,
    is_codex_responses_transport,
    stream_responses_request_to_events,
)
from gallama.server_engine.request_routing import (
    prefer_vision_instances,
    request_requires_vision,
)
from gallama.server_engine.model_capabilities import infer_model_modalities_fallback
from gallama.logger.logger import (
    REQUEST_ID_HEADER,
    basic_log_extra,
    get_log_level_for_verbosity,
    is_max_log_verbosity,
    new_request_id,
    reset_request_id,
    set_request_id,
    set_log_verbosity,
)


server_logger = get_server_logger()
responses_websocket_hub = get_responses_websocket_hub()

router = APIRouter()
router.include_router(server_management_router)
router.include_router(responses_ws_router)
router.include_router(realtime_router)


manager_app = FastAPI()
manager_app.include_router(router)


@manager_app.head("/")
async def root_head():
    return PlainTextResponse("Not Found\n", status_code=404)


def _log_request_received(request: Request) -> None:
    request_id = getattr(request.state, "request_id", "-")
    server_logger.info(
        f"REQ {request_id} {request.method} {request.url.path}",
        extra=basic_log_extra(),
    )


def _log_response_sent(
    request: Request,
    *,
    status_code: int,
    started_at: float,
    stream_complete: bool | None = None,
) -> None:
    request_id = getattr(request.state, "request_id", "-")
    parts = [f"RES {request_id} {status_code} {request.method} {request.url.path}"]

    model_name = getattr(request.state, "request_model", None) or getattr(request.state, "routed_model", None)
    if model_name:
        parts.append(f"model={model_name}")

    instance_port = getattr(request.state, "instance_port", None)
    if instance_port:
        parts.append(f"port={instance_port}")

    if stream_complete is not None:
        parts.append("stream=done" if stream_complete else "stream=aborted")

    elapsed_ms = int((time.perf_counter() - started_at) * 1000)
    parts.append(f"{elapsed_ms}ms")

    server_logger.info(" ".join(parts), extra=basic_log_extra())


def _finalize_request_logging(request: Request, response, *, started_at: float):
    request_id = getattr(request.state, "request_id", None)
    if request_id:
        response.headers[REQUEST_ID_HEADER] = request_id

    if isinstance(response, StreamingResponse):
        original_iterator = response.body_iterator

        async def logged_body_iterator():
            stream_token = set_request_id(request_id)
            completed = False
            try:
                async for chunk in original_iterator:
                    yield chunk
                completed = True
            finally:
                _log_response_sent(
                    request,
                    status_code=response.status_code,
                    started_at=started_at,
                    stream_complete=completed,
                )
                reset_request_id(stream_token)

        response.body_iterator = logged_body_iterator()
        return response

    _log_response_sent(request, status_code=response.status_code, started_at=started_at)
    return response





@manager_app.middleware("http")
async def log_requests(request: Request, call_next):
    request_id = request.headers.get(REQUEST_ID_HEADER) or new_request_id()
    request.state.request_id = request_id
    started_at = time.perf_counter()
    token = set_request_id(request_id)
    _log_request_received(request)

    try:
        if request.url.path in EXCLUDED_ENDPOINTS and request.method in ("POST", "PUT", "PATCH"):
            content_type = request.headers.get("Content-Type", "")
            if "multipart/form-data" in content_type or "application/octet-stream" in content_type:
                server_logger.debug(f"API Request:\nMethod: {request.method}\nURL: {request.url}\n[Binary content omitted]")
            else:
                request_content = await request.body()
                if request_content:
                    request_content = format_request_body_for_logging(
                        request_content,
                        include_full_base64=is_max_log_verbosity(),
                    )
                    server_logger.info(f"API Request:\nMethod: {request.method}\nURL: {request.url}\n{request_content}")

        response = await call_next(request)
    except RequestValidationError as e:
        server_logger.debug(f"Validation error:\n{e}")
        response = JSONResponse(status_code=422, content={"detail": "Validation error"})
    finally:
        reset_request_id(token)

    return _finalize_request_logging(request, response, started_at=started_at)


class WebSocketLoggingMiddleware:
    def __init__(self, app: ASGIApp):
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send):
        if scope["type"] == "websocket":
            await self.log_websocket(scope, receive, send)
        else:
            await self.app(scope, receive, send)

    async def log_websocket(self, scope: Scope, receive: Receive, send: Send):
        # Log detailed connection attempt information
        client = scope.get('client')
        server_logger.info(f"WebSocket connection attempt from {client}")

        # Log query parameters
        query_string = scope.get('query_string', b'').decode('utf-8')
        server_logger.debug(f"Query parameters: {query_string}")

        # Convert headers to a more readable format and log them
        headers = dict(scope.get('headers', []))
        formatted_headers = {
            k.decode('utf-8'): v.decode('utf-8')
            for k, v in headers.items()
        }
        server_logger.debug("WebSocket headers:")
        for key, value in formatted_headers.items():
            server_logger.debug(f"  {key}: {value}")

        # Log protocols specifically
        protocols = formatted_headers.get('sec-websocket-protocol', '').split(', ')
        server_logger.debug(f"Requested protocols: {protocols}")

        async def receive_with_logging():
            message = await receive()
            server_logger.debug(f"Received message type: {message['type']}")

            if message["type"] == "websocket.connect":
                server_logger.info("WebSocket client connecting")
                # Log any authentication info (safely)
                auth_header = formatted_headers.get('authorization', '')
                if auth_header:
                    server_logger.debug("Authorization header present")

            elif message["type"] == "websocket.disconnect":
                server_logger.info(f"WebSocket client disconnecting from {client}")

            elif message["type"] == "websocket.receive":
                try:
                    if "text" in message:
                        content = message["text"]
                        try:
                            parsed_content = json.loads(content)
                            server_logger.info(
                                "WebSocket received text:\n" +
                                json.dumps(parsed_content, indent=2)
                            )
                        except json.JSONDecodeError:
                            server_logger.info(f"WebSocket received raw text: {content}")
                    elif "bytes" in message:
                        server_logger.info(f"WebSocket received binary data of size: {len(message['bytes'])} bytes")
                except Exception as e:
                    server_logger.error(f"Error logging WebSocket message: {str(e)}")
                    server_logger.debug(f"Raw message content: {message}")
            return message

        async def send_with_logging(message):
            server_logger.debug(f"Sending message type: {message['type']}")

            if message["type"] == "websocket.accept":
                selected_protocol = message.get('subprotocol')
                server_logger.info(f"WebSocket connection accepted with protocol: {selected_protocol}")

            elif message["type"] == "websocket.close":
                code = message.get('code', 1000)
                reason = message.get('reason', '')
                server_logger.info(f"WebSocket connection closed with code {code}: {reason}")

            elif message["type"] == "websocket.send":
                try:
                    if "text" in message:
                        content = message["text"]
                        try:
                            parsed_content = json.loads(content)
                            server_logger.info(
                                "WebSocket sent text:\n" +
                                json.dumps(parsed_content, indent=2)
                            )
                        except json.JSONDecodeError:
                            server_logger.info(f"WebSocket sent raw text: {content}")
                    elif "bytes" in message:
                        server_logger.info(f"WebSocket sent binary data of size: {len(message['bytes'])} bytes")
                except Exception as e:
                    server_logger.error(f"Error logging WebSocket message: {str(e)}")
                    server_logger.debug(f"Raw message content: {message}")

            # Log any error responses
            if message.get('status', 200) >= 400:
                server_logger.error(f"WebSocket error response: {message}")

            await send(message)

        try:
            await self.app(scope, receive_with_logging, send_with_logging)
        except Exception as e:
            server_logger.error(f"WebSocket connection error: {str(e)}")
            server_logger.debug(f"Error details:", exc_info=True)

# Add WebSocket middleware
# manager_app.add_middleware(WebSocketLoggingMiddleware)

# Add CORS middleware
manager_app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods
    allow_headers=["*"],  # Allows all headers
)


# models: Dict[str, ModelInfo] = {}
# model_load_queue = asyncio.Queue()
# loading_lock = asyncio.Lock()
# active_requests_lock = asyncio.Lock()
# task_status = {}
config_manager = ConfigManager()

# Define a variable for the starting port
START_PORT = 8001

# Increase the timeout for long-running tasks (adjust as needed)
TIMEOUT = 300  # 5 minutes

strict_mode = False

# List of endpoints to exclude from API gateway redirection
EXCLUDED_ENDPOINTS = [
    "/add_model", "/remove_model", "/list_models", "/list_available_models",
    "/v1/add_model", "/v1/remove_model", "/v1/list_models", "/v1/list_available_models",
    "/list_models", "/v1/list_models"
    "/v1/remove_model_by_port","/remove_model_by_port",
    "/v1/models", "/task_status"
]
EMBEDDING_SUBPATHS = []     # No overwriting at the moment
# EMBEDDING_SUBPATHS = [
#     {
#         "original": "/v1/embeddings",
#         "replacement": "/v1/embeddings"
#     },
#     # Add more paths here as needed, e.g.:
#     # {"original": "/v2/some_path", "replacement": "/new_path"}
# ]

# Dictionary to keep track of active requests per instance
active_requests: Dict[int, int] = defaultdict(int)

# Add a semaphore for concurrency control
MAX_CONCURRENT_REQUESTS = 100  # Adjust this value based on your system's capacity
request_semaphore = asyncio.Semaphore(MAX_CONCURRENT_REQUESTS)


def get_instance_concurrency_limit(instance: ModelInstanceInfo) -> int:
    limit = getattr(instance, "max_concurrent_requests", 1)
    return max(1, int(limit))


def get_instance_load_key(instance: ModelInstanceInfo) -> tuple[float, int]:
    active = active_requests[instance.port]
    limit = get_instance_concurrency_limit(instance)
    return active / limit, active


# # set up logging
# def start_log_receiver(zmq_url):
#     context = zmq.Context()
#     socket = context.socket(zmq.PULL)
#     socket.bind("tcp://*:5555")
#
#     # Initialize the server_logger for the receiver
#     receiver_logger = get_logger(name="log_receiver", to_console=True, to_file=False, to_zmq=False)
#
#     receiver_logger.info(f"Log receiver started on {zmq_url}")
#
#     def receive_logs():
#         while True:
#             try:
#                 message = socket.recv_json()
#                 log_level = getattr(logging, message['level'].upper(), logging.INFO)
#
#                 receiver_logger.log(
#                     level=log_level,
#                     msg=f"{message['model']}:{message['port']} | {message['log']}"
#                 )
#             except zmq.Again:
#                 # No message available, sleep for a short time
#                 time.sleep(0.1)
#             except zmq.ZMQError as e:
#                 receiver_logger.error(f"ZMQ Error in log receiver: {e}")
#             except json.JSONDecodeError as e:
#                 receiver_logger.error(f"JSON Decode Error in log receiver: {e}")
#             except Exception as e:
#                 receiver_logger.error(f"Unexpected error in log receiver: {e}")
#                 receiver_logger.error(traceback.format_exc())
#
#     # Start the receiver in a separate thread
#     receiver_thread = threading.Thread(target=receive_logs, daemon=True)
#     receiver_thread.start()
#
#     return receiver_thread
#
#
#
# # Start the log receiver in a separate thread
# DEFAULT_ZMQ_URL = "tcp://127.0.0.1:5555"  # Using 5559 as a standard port for logging
#
#
# # Initialize the logger for the manager
# # Set to_console=True and to_zmq=False to avoid duplication
# logger = get_logger(name="manager", to_console=True, to_zmq=False)



async def model_loader():
    server_manager = get_server_manager()

    while True:
        server_logger.info("Model loader waiting for next model in queue", extra=basic_log_extra())
        model = await server_manager.model_load_queue.get()
        server_logger.info(f"Model loader retrieved model from queue: {model}", extra=basic_log_extra())
        async with server_manager.loading_lock:
            try:
                server_logger.info(f"Starting to load model: {model}", extra=basic_log_extra())
                server_logger.info(
                    f"Current queue size: {server_manager.model_load_queue.qsize()}",
                    extra=basic_log_extra(),
                )
                await run_model_with_timeout(model)
            except Exception as e:
                server_logger.exception(f"Error loading model {model} instance: {str(e)}")
            finally:
                server_logger.info(f"Finished processing model: {model}", extra=basic_log_extra())
                server_manager.model_load_queue.task_done()
                server_logger.info(
                    f"Remaining queue size: {server_manager.model_load_queue.qsize()}",
                    extra=basic_log_extra(),
                )

        server_logger.info("Model loader finished processing, looping back", extra=basic_log_extra())
        await asyncio.sleep(1)


async def wait_for_model_ready(port, timeout=600):  # 10 minutes timeout
    start_time = time.time()
    while time.time() - start_time < timeout:
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(f"http://localhost:{port}/health", timeout=5.0)
                if response.status_code == 200:
                    return True
        except httpx.RequestError:
            pass  # The server_engine might not be up yet, so we'll just continue waiting
        await asyncio.sleep(1)
    return False


async def get_instance_modalities(port, timeout=5.0) -> List[str]:
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(f"http://localhost:{port}/status", timeout=timeout)
            response.raise_for_status()
            payload = response.json()
    except Exception as exc:
        server_logger.debug(f"Failed to fetch modalities for port {port}: {exc}")
        return []

    modalities = payload.get("modalities", [])
    if not isinstance(modalities, list):
        return []

    return [str(modality) for modality in modalities]


async def run_model(model_spec: ModelSpec):
    server_manager = get_server_manager()
    port = None

    try:
        model_config = config_manager.get_effective_model_config(model_spec.model_name) or {}
        if model_config:
            resolved_model_config = model_config.copy()
            resolved_model_config.update({"model_name": model_spec.model_name})
            default_model_spec = ModelSpec.from_dict(resolved_model_config)
            model_spec = ModelSpec.from_merged_config(model_spec, default_model_spec.model_dump())

        # add the entry for the dictionary (where key is the model name)
        if model_spec.model_name not in server_manager.models:
            server_manager.models[model_spec.model_name] = ModelInfo(instances=[])

        # Find the next available port
        port = START_PORT
        while any(instance.port == port for model_info in server_manager.models.values() for instance in model_info.instances):
            port += 1

        server_logger.info(
            f"Attempting to start model {model_spec.model_name} on port {port}",
            extra=basic_log_extra(),
        )

        backend = model_spec.backend
        if not backend:
            raise ValueError(
                f"backend is required to start model '{model_spec.model_name}' when it is not defined in model_config.yaml"
            )

        env = model_spec.build_child_env(os.environ)
        child_model_spec = model_spec.build_child_model_spec()
        server_logger.info("CUDA_VISIBLE_DEVICES: {}".format(env['CUDA_VISIBLE_DEVICES']), extra=basic_log_extra())
        server_logger.info("Child env overrides: {}".format(model_spec.env), extra=basic_log_extra())
        server_logger.info(f"Resolved model spec: {child_model_spec}", extra=basic_log_extra())

        try:
            # Serialize the ModelSpec to JSON and encode to base64
            model_json = child_model_spec.model_dump_json()
            model_b64 = base64.b64encode(model_json.encode('utf-8')).decode('utf-8')


            # Use the function
            app_path = get_package_file_path('app.py')
            server_logger.info(f"Using app path: {app_path}", extra=basic_log_extra())

            # Determine the correct Python executable
            python_exec = shutil.which("python3") or shutil.which("python")
            child_log_file_args = ["--log-file", server_manager.log_file] if server_manager.log_file else []

            if backend in ["exllama", "exllamav3"]:
                # model_cli_args = model.to_arg_string()
                # server_logger.debug(f"model cli: {model_cli_args}")
                process = await asyncio.create_subprocess_exec(
                    python_exec, app_path, "--model-spec", model_b64, "--detached", "--port", str(port),
                    *child_log_file_args,
                    stdout=asyncio.subprocess.DEVNULL,
                    env=env,
                    # stderr=asyncio.subprocess.DEVNULL,
                )
            else:
                # other than exllama, we will use env setting to set visible GPUs
                # CUDA_VISIBLE_DEVICES constraints before launching fastapi

                # model_cli_args = model.to_arg_string()
                # server_logger.debug(f"model cli: {model_cli_args}")
                process = await asyncio.create_subprocess_exec(
                    python_exec, app_path, "--model-spec", model_b64, "--detached", "--port", str(port),
                    *child_log_file_args,
                    # stdout=asyncio.subprocess.DEVNULL,
                    # stderr=asyncio.subprocess.DEVNULL,
                    env=env  # Pass the modified environment to the subprocess
                )

        except Exception as e:
            server_logger.error(f"Failed to create subprocess for model {model_spec.model_id} on port {port}: {str(e)}")
            return

        # Wait for the model to become ready
        if await wait_for_model_ready(port):
            server_logger.info(f"Model {model_spec.model_name} on port {port} is ready", extra=basic_log_extra())
            modalities = await get_instance_modalities(port)
            if not modalities:
                config_record = config_manager.configs.get(model_spec.model_name, {})
                default_record = config_manager.default_model_list.get(model_spec.model_name, {})
                modalities = infer_model_modalities_fallback(
                    model_name=model_spec.model_name,
                    model_id=model_spec.model_id,
                    backend=model_spec.backend,
                    prompt_template=model_spec.prompt_template,
                    config_records=[config_record, default_record],
                )
                if modalities:
                    server_logger.info(
                        f"Inferred modalities for {model_spec.model_name} on port {port}: {modalities}",
                        extra=basic_log_extra(),
                    )
            instance_info = ModelInstanceInfo(
                port=port,
                pid=process.pid,
                status="running",
                model_name=model_spec.model_name,
                model_type=ModelSpec.get_model_type_from_backend(backend),
                strict=model_spec.strict,
                modalities=modalities,
                max_concurrent_requests=model_spec.max_concurrent_requests,
                cuda_visible_devices=env.get("CUDA_VISIBLE_DEVICES", ""),
            )
            server_manager.models[model_spec.model_name].instances.append(instance_info)
        else:
            server_logger.error(f"Timeout waiting for model {model_spec.model_name} on port {port} to become ready")
            await stop_model_instance(model_spec.model_name, port)
            return

        server_logger.info(
            f"Model {model_spec.model_id} instance on port {port} is fully loaded and ready",
            extra=basic_log_extra(),
        )
        log_model_status(server_manager.models, custom_logger=server_logger)  # Log status after successfully loading a model

        # Instead of entering an infinite loop, we'll exit the function here
        return

    except Exception as e:
        location = f" on port {port}" if port is not None else ""
        server_logger.exception(f"Error running model {model_spec.model_name} instance{location}: {str(e)}")
        if port is not None:
            await stop_model_instance(model_spec.model_name, port)
    finally:
        await cleanup_after_model_load(model_spec.model_name)
        location = f" on port {port}" if port is not None else ""
        server_logger.info(f"Exiting run_model for {model_spec.model_name}{location}", extra=basic_log_extra())


async def cleanup_after_model_load(model: str):
    # Perform any necessary cleanup here
    server_logger.info(f"Performing cleanup after loading model: {model}", extra=basic_log_extra())
    # For example, you might want to close any open connections or release resources
    # This is a placeholder - add specific cleanup tasks as needed


async def run_model_with_timeout(model: str, timeout: int = 600):  # 10 minutes timeout
    server_manager = get_server_manager()

    try:
        await asyncio.wait_for(run_model(model), timeout=timeout)
    except asyncio.TimeoutError:
        server_logger.error(f"Timeout occurred while loading model: {model}")
        # Perform cleanup or error handling here
        await stop_model_instance(model, server_manager.models[model].instances[-1].port if model in server_manager.models and server_manager.models[model].instances else None)




async def get_model_from_body(
    request: Request,
    parsed_body: object | None = None,
) -> str:
    try:
        body = parsed_body
        if body is None:
            body, _ = await parse_request_body(request)

        if isinstance(body, dict):
            return body.get("model", "")

        return ""
    except Exception as e:     # when request doesnt come with model e.g. audio transcription
        server_logger.debug(f"Can not get body from request {e}. Hence continue with raw body")
        return ""



async def get_instance_for_model(model: str):
    server_manager = get_server_manager()

    running_instances = [inst for inst in server_manager.models[model].instances if inst.status == "running"]
    if not running_instances:
        raise HTTPException(status_code=503, detail=f"No running instances available for model: {model}")

    return min(running_instances, key=get_instance_load_key)


async def acquire_instance_slot(
    instances: list[ModelInstanceInfo],
    request: Request,
    poll_interval: float = 0.05,
) -> ModelInstanceInfo:
    """
    Wait until one instance is below its configured concurrency limit, then
    atomically reserve a slot on that instance.
    """
    server_manager = get_server_manager()

    while True:
        async with server_manager.active_requests_lock:
            candidates = [
                inst for inst in instances
                if active_requests[inst.port] < get_instance_concurrency_limit(inst)
            ]
            if candidates:
                instance = min(candidates, key=get_instance_load_key)
                active_requests[instance.port] += 1
                return instance

        if await request.is_disconnected():
            raise HTTPException(status_code=499, detail="Client disconnected while waiting for model capacity")

        await asyncio.sleep(poll_interval)


async def load_balanced_router(request: Request, path: str):
    server_manager = get_server_manager()

    body_json, is_multipart = await parse_request_body(request)
    request.state.request_stream = bool(body_json.get("stream", False)) if isinstance(body_json, dict) else False

    if request.url.path in EXCLUDED_ENDPOINTS:
        server_logger.info(body_json)
        return await request.app.router.get_route_handler()(request)

    if request.method == "OPTIONS":
        return create_options_response(dict(request.headers))

    model = await get_model_from_body(request, parsed_body=body_json)
    request.state.request_model = model or None

    async with request_semaphore:
        is_embedding = any(subpath["original"] in path for subpath in EMBEDDING_SUBPATHS)
        if "/audio/transcriptions" in path:
            model_type = "stt"
        elif "embeddings" in path:
            model_type = "embedding"
        elif "/audio/speech" in path:
            model_type = "tts"
        else:
            model_type = "llm"
        vision_required = model_type == "llm" and request_requires_vision(body_json)

        if not model and strict_mode:
            raise HTTPException(status_code=400, detail="Model must be specified in strict mode")

        available_instances = []

        if strict_mode:
            # In strict mode, the model must be specified and found
            if model not in server_manager.models:
                raise HTTPException(status_code=404, detail="Specified model not found")
            available_instances = [inst for inst in server_manager.models[model].instances if inst.status == "running"]
        else:
            # Try to find a matching model first (if model is specified)
            if model and model in server_manager.models:
                available_instances = [inst for inst in server_manager.models[model].instances if inst.status == "running"]

            # If no matching model or no instances found, pick any running instance of the correct type that is not strict
            if not available_instances:
                for model_info in server_manager.models.values():
                    for inst in model_info.instances:
                        if inst.status == "running" and inst.model_type == model_type and not inst.strict:
                            available_instances.append(inst)

                available_instances = prefer_vision_instances(
                    available_instances,
                    vision_required=vision_required,
                )

        if not available_instances:
            raise HTTPException(status_code=503, detail=f"No suitable running instances with requested model '{model}'")

        # Select an instance with spare capacity and reserve a slot on it.
        instance = await acquire_instance_slot(available_instances, request)

        try:
            server_logger.info(f"active_requests: {str(active_requests)}")
            server_logger.info(f"Request routed to model {instance.model_name} instance at port {instance.port}")
            request.state.routed_model = instance.model_name
            request.state.instance_port = instance.port

            if (
                request.method == "POST"
                and request.url.path == "/v1/responses"
                and isinstance(body_json, dict)
                and not body_json.get("stream", False)
                and is_codex_responses_transport(request.headers)
            ):
                session_keys = extract_response_ws_keys(request.headers)

                async def publish_event(_event_name, event_payload):
                    if session_keys:
                        await responses_websocket_hub.publish(session_keys, event_payload)

                try:
                    final_response = await stream_responses_request_to_events(
                        instance=instance,
                        payload=body_json,
                        headers=request.headers,
                        on_event=publish_event,
                    )
                except httpx.HTTPStatusError as exc:
                    raise HTTPException(status_code=exc.response.status_code, detail=exc.response.text) from exc

                if final_response is None:
                    raise HTTPException(status_code=502, detail="No completed response received from backend stream")

                return JSONResponse(status_code=200, content=final_response)

            # Forward the request
            response = await forward_request(
                request,
                instance,
                parsed_body=body_json,
            )

            return response
        finally:
            # Decrement the active request count after the request is completed
            async with server_manager.active_requests_lock:
                active_requests[instance.port] -= 1


@manager_app.api_route("/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"])
async def router(request: Request, path: str):
    return await load_balanced_router(request, path)


def shutdown(signal, frame):
    server_manager = get_server_manager()

    server_logger.info("Shutting down all models...")
    for model in list(server_manager.models.keys()):
        for instance in server_manager.models[model].instances:
            stop_model_instance(model, instance.port)
    server_logger.info("All models have been shut down. Exiting.")
    sys.exit(0)


async def start_server(port=8000):
    uvicorn_log_level = "debug" if get_log_level_for_verbosity() == 10 else "info"
    config = uvicorn.Config(manager_app, host="0.0.0.0", port=port, log_level=uvicorn_log_level)
    server = uvicorn.Server(config)
    await server.serve()


async def main(model_list=None, port=8000, strict_mode=False, log_file: str | None = None):
    server_manager = get_server_manager()
    server_manager.log_file = log_file

    receiver_thread = start_log_receiver(DEFAULT_ZMQ_URL, log_file=log_file)
    server_logger.info("Starting main function", extra=basic_log_extra())
    server_logger.info(f"Strict mode: {'enabled' if strict_mode else 'disabled'}", extra=basic_log_extra())

    model_loader_task = asyncio.create_task(model_loader())
    server_logger.info("Created model_loader task", extra=basic_log_extra())

    # Load initial models
    if model_list:
        server_logger.info(f"Loading initial models: {[model.model_name for model in model_list]}", extra=basic_log_extra())
        for model in model_list:
            await server_manager.model_load_queue.put(model)

        # Wait for all initial models to load
        while not server_manager.model_load_queue.empty():
            await asyncio.sleep(1)

        server_logger.info("All initial models have been queued for loading", extra=basic_log_extra())

    # Start periodic health checks
    health_check_task = asyncio.create_task(periodic_health_check())

    try:
        await start_server(port)
    finally:
        await close_forward_http_client()

        # Ensure tasks are cancelled when the server_engine stops
        model_loader_task.cancel()
        health_check_task.cancel()
        try:
            await asyncio.gather(model_loader_task, health_check_task)
        except asyncio.CancelledError:
            server_logger.info("Tasks cancelled")


# this parser is different to app.py
def parse_dict(arg):
    """Parses key=value pairs and supports dotted keys for nested dictionaries."""

    def assign_nested_key(target, dotted_key, value):
        parts = dotted_key.split(".")
        current = target
        for part in parts[:-1]:
            current = current.setdefault(part, {})
        current[parts[-1]] = value

    result = {}
    for pair in arg.split():
        key, value = pair.split('=', 1)
        assign_nested_key(result, key, value.strip("'"))
    return result


def llama_picture():
    """ show a fun picture cause why not :) """
    # Load the image
    llama_art = """
        ,,__
        .. \\(oo)
           (__)
             ||----w |
             ||     ||
    """
    server_logger.info(llama_art, extra=basic_log_extra())


def run_from_script(args):
    global server_logger
    requested_verbosity = max(
        getattr(args, "global_verbose", 0) or 0,
        getattr(args, "verbose", 0) or 0,
    )
    set_log_verbosity(requested_verbosity)
    configure_server_logging(getattr(args, "log_file", None))
    server_logger = get_server_logger()

    # opening llama picture cause why not
    llama_picture()

    global strict_mode

    if args.strict_mode:
        strict_mode = True

    # parse the cli input
    model_list = []
    if args.model_id:
        for item in args.model_id:
            model_spec = ModelSpec.from_dict(item)
            model_list.append(model_spec)
            server_logger.info(model_spec, extra=basic_log_extra())

    # simple loading with model_name
    if args.model_name:
        model_spec = ModelSpec(model_name=args.model_name)
        model_list.append(model_spec)

    if model_list:
        server_logger.info("Initial models: " + str(model_list), extra=basic_log_extra())

    server_logger.setLevel(get_log_level_for_verbosity())


    server_logger.info("Parsed Arguments:" + str(args), extra=basic_log_extra())

    asyncio.run(
        main(
            model_list=model_list,
            port=args.port,
            strict_mode=args.strict_mode,
            log_file=getattr(args, "log_file", None)
        )
    )


if __name__ == "__main__":

    server_logger.info("Script started", extra=basic_log_extra())
    arg_parser = argparse.ArgumentParser(description="Launch multi model src instance")
    arg_parser.add_argument("--strict_mode", action="store_true", default=False,
                            help="Enable strict mode for routing non-embedding requests to matching model names")
    arg_parser.add_argument("-id", "--model_id", action='append', type=parse_dict, default=None,
                            help="Model configuration. Can be used multiple times for different models. "
                                 "Format: -id model_id=<model_name> [gpu=<vram1>,<vram2>,...] [gpu<n>=<vram>] [cache=<size>] [model_type=exllama|embedding]"
                                 "Examples:\n"
                                 "1. Specify all GPUs: -id model_id=/path/llama3-8b gpu=4,2,0,3 cache=8192\n"
                                 "2. Specify individual GPUs: -id model_id=/path/llama3-8b gpu0=8 gpu1=8 cache=8192\n"
                                 "3. Mix formats: -id model_id=gpt4 gpu=4,2 gpu3=3 cache=8192\n"
                                 "4. Embedding model: -id model_id=/path/gte-large-en-v1.5 gpu=0,0,0,3"
                                 "cache_size is defaulted to model context length if not specified"
                                 "cache_size can be more than context length, which will help model perform better in batched generation"
                                 "cache_size is not application to embedding model"
                                 "VRAM is specified in GB. Cache size is integer which is the context length to cache."
                                 "VRAM for embedding will simple set env parameter to allow infinity_embedding to view the specific GPU and can not enforce VRAM size restriction")
    arg_parser.add_argument(
        '-v',
        "--verbose",
        action='count',
        default=0,
        help="Increase logging verbosity. Use -v for current logs, -vv for debug, -vvv for maximum request/body detail.",
    )
    arg_parser.add_argument("--host", type=str, default="127.0.0.1", help="The host to bind to.")
    arg_parser.add_argument('-p', "--port", type=int, default=8000, help="The port to bind to.")
    arg_parser.add_argument("--log-file", type=str, default=None, help="Also write CLI logs to this file.")

    # arg_parser.add_argument("--reload", action="store_true", help="Enable auto-reload.")

    args = arg_parser.parse_args()

    run_from_script(args)
