import{c as e}from"./index-BdTlbgP2.js";const o=[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]],r=e("arrow-left",o);export{o as __iconNode,r as default};
