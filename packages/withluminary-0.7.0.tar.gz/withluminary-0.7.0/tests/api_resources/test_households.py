# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from withluminary import Luminary, AsyncLuminary
from withluminary.types import (
    Entity,
    Document,
    Household,
    Individual,
)
from withluminary._utils import parse_date
from withluminary.pagination import SyncCursorPagination, AsyncCursorPagination

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestHouseholds:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create(self, client: Luminary) -> None:
        household = client.households.create(
            primary_relationship_owner_id="user_01ARZ3NDEKTSV4RRFFQ69G5FAV",
        )
        assert_matches_type(Household, household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Luminary) -> None:
        household = client.households.create(
            primary_relationship_owner_id="user_01ARZ3NDEKTSV4RRFFQ69G5FAV",
            external_id="crm-household-12345",
            notes="notes",
            primary_individuals=[
                {
                    "first_name": "John",
                    "last_name": "Smith",
                    "state": "xx",
                    "address_line1": "x",
                    "address_line2": "x",
                    "city": "x",
                    "country": "x",
                    "date_of_birth": parse_date("2019-12-27"),
                    "email": "dev@stainless.com",
                    "is_beneficiary": True,
                    "is_deceased": True,
                    "is_trustee": True,
                    "middle_name": "x",
                    "notes": "notes",
                    "postal_code": "x",
                    "suffix": "x",
                }
            ],
        )
        assert_matches_type(Household, household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Luminary) -> None:
        response = client.households.with_raw_response.create(
            primary_relationship_owner_id="user_01ARZ3NDEKTSV4RRFFQ69G5FAV",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        household = response.parse()
        assert_matches_type(Household, household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Luminary) -> None:
        with client.households.with_streaming_response.create(
            primary_relationship_owner_id="user_01ARZ3NDEKTSV4RRFFQ69G5FAV",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            household = response.parse()
            assert_matches_type(Household, household, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: Luminary) -> None:
        household = client.households.retrieve(
            "id",
        )
        assert_matches_type(Household, household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: Luminary) -> None:
        response = client.households.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        household = response.parse()
        assert_matches_type(Household, household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: Luminary) -> None:
        with client.households.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            household = response.parse()
            assert_matches_type(Household, household, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: Luminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.households.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update(self, client: Luminary) -> None:
        household = client.households.update(
            id="id",
        )
        assert_matches_type(Household, household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update_with_all_params(self, client: Luminary) -> None:
        household = client.households.update(
            id="id",
            external_id="crm-household-12345",
            notes="notes",
            primary_relationship_owner_id="user_01ARZ3NDEKTSV4RRFFQ69G5FAV",
        )
        assert_matches_type(Household, household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_update(self, client: Luminary) -> None:
        response = client.households.with_raw_response.update(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        household = response.parse()
        assert_matches_type(Household, household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_update(self, client: Luminary) -> None:
        with client.households.with_streaming_response.update(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            household = response.parse()
            assert_matches_type(Household, household, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_update(self, client: Luminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.households.with_raw_response.update(
                id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Luminary) -> None:
        household = client.households.list()
        assert_matches_type(SyncCursorPagination[Household], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Luminary) -> None:
        household = client.households.list(
            after="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            before="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            external_id="x",
            limit=1,
        )
        assert_matches_type(SyncCursorPagination[Household], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Luminary) -> None:
        response = client.households.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        household = response.parse()
        assert_matches_type(SyncCursorPagination[Household], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Luminary) -> None:
        with client.households.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            household = response.parse()
            assert_matches_type(SyncCursorPagination[Household], household, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_delete(self, client: Luminary) -> None:
        household = client.households.delete(
            "id",
        )
        assert household is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_delete(self, client: Luminary) -> None:
        response = client.households.with_raw_response.delete(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        household = response.parse()
        assert household is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_delete(self, client: Luminary) -> None:
        with client.households.with_streaming_response.delete(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            household = response.parse()
            assert household is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_delete(self, client: Luminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.households.with_raw_response.delete(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_documents(self, client: Luminary) -> None:
        household = client.households.list_documents(
            id="id",
        )
        assert_matches_type(SyncCursorPagination[Document], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_documents_with_all_params(self, client: Luminary) -> None:
        household = client.households.list_documents(
            id="id",
            after="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            before="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            limit=1,
            type="GRAT_DESIGN_SUMMARY",
        )
        assert_matches_type(SyncCursorPagination[Document], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list_documents(self, client: Luminary) -> None:
        response = client.households.with_raw_response.list_documents(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        household = response.parse()
        assert_matches_type(SyncCursorPagination[Document], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list_documents(self, client: Luminary) -> None:
        with client.households.with_streaming_response.list_documents(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            household = response.parse()
            assert_matches_type(SyncCursorPagination[Document], household, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_list_documents(self, client: Luminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.households.with_raw_response.list_documents(
                id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_entities(self, client: Luminary) -> None:
        household = client.households.list_entities(
            id="id",
        )
        assert_matches_type(SyncCursorPagination[Entity], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_entities_with_all_params(self, client: Luminary) -> None:
        household = client.households.list_entities(
            id="id",
            after="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            before="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            kind="REVOCABLE_TRUST",
            limit=1,
        )
        assert_matches_type(SyncCursorPagination[Entity], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list_entities(self, client: Luminary) -> None:
        response = client.households.with_raw_response.list_entities(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        household = response.parse()
        assert_matches_type(SyncCursorPagination[Entity], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list_entities(self, client: Luminary) -> None:
        with client.households.with_streaming_response.list_entities(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            household = response.parse()
            assert_matches_type(SyncCursorPagination[Entity], household, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_list_entities(self, client: Luminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.households.with_raw_response.list_entities(
                id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_individuals(self, client: Luminary) -> None:
        household = client.households.list_individuals(
            id="id",
        )
        assert_matches_type(SyncCursorPagination[Individual], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_individuals_with_all_params(self, client: Luminary) -> None:
        household = client.households.list_individuals(
            id="id",
            after="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            before="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            is_primary=True,
            limit=1,
        )
        assert_matches_type(SyncCursorPagination[Individual], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list_individuals(self, client: Luminary) -> None:
        response = client.households.with_raw_response.list_individuals(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        household = response.parse()
        assert_matches_type(SyncCursorPagination[Individual], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list_individuals(self, client: Luminary) -> None:
        with client.households.with_streaming_response.list_individuals(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            household = response.parse()
            assert_matches_type(SyncCursorPagination[Individual], household, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_list_individuals(self, client: Luminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.households.with_raw_response.list_individuals(
                id="",
            )


class TestAsyncHouseholds:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncLuminary) -> None:
        household = await async_client.households.create(
            primary_relationship_owner_id="user_01ARZ3NDEKTSV4RRFFQ69G5FAV",
        )
        assert_matches_type(Household, household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncLuminary) -> None:
        household = await async_client.households.create(
            primary_relationship_owner_id="user_01ARZ3NDEKTSV4RRFFQ69G5FAV",
            external_id="crm-household-12345",
            notes="notes",
            primary_individuals=[
                {
                    "first_name": "John",
                    "last_name": "Smith",
                    "state": "xx",
                    "address_line1": "x",
                    "address_line2": "x",
                    "city": "x",
                    "country": "x",
                    "date_of_birth": parse_date("2019-12-27"),
                    "email": "dev@stainless.com",
                    "is_beneficiary": True,
                    "is_deceased": True,
                    "is_trustee": True,
                    "middle_name": "x",
                    "notes": "notes",
                    "postal_code": "x",
                    "suffix": "x",
                }
            ],
        )
        assert_matches_type(Household, household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncLuminary) -> None:
        response = await async_client.households.with_raw_response.create(
            primary_relationship_owner_id="user_01ARZ3NDEKTSV4RRFFQ69G5FAV",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        household = await response.parse()
        assert_matches_type(Household, household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncLuminary) -> None:
        async with async_client.households.with_streaming_response.create(
            primary_relationship_owner_id="user_01ARZ3NDEKTSV4RRFFQ69G5FAV",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            household = await response.parse()
            assert_matches_type(Household, household, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncLuminary) -> None:
        household = await async_client.households.retrieve(
            "id",
        )
        assert_matches_type(Household, household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncLuminary) -> None:
        response = await async_client.households.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        household = await response.parse()
        assert_matches_type(Household, household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncLuminary) -> None:
        async with async_client.households.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            household = await response.parse()
            assert_matches_type(Household, household, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncLuminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.households.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update(self, async_client: AsyncLuminary) -> None:
        household = await async_client.households.update(
            id="id",
        )
        assert_matches_type(Household, household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncLuminary) -> None:
        household = await async_client.households.update(
            id="id",
            external_id="crm-household-12345",
            notes="notes",
            primary_relationship_owner_id="user_01ARZ3NDEKTSV4RRFFQ69G5FAV",
        )
        assert_matches_type(Household, household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_update(self, async_client: AsyncLuminary) -> None:
        response = await async_client.households.with_raw_response.update(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        household = await response.parse()
        assert_matches_type(Household, household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncLuminary) -> None:
        async with async_client.households.with_streaming_response.update(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            household = await response.parse()
            assert_matches_type(Household, household, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_update(self, async_client: AsyncLuminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.households.with_raw_response.update(
                id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncLuminary) -> None:
        household = await async_client.households.list()
        assert_matches_type(AsyncCursorPagination[Household], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncLuminary) -> None:
        household = await async_client.households.list(
            after="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            before="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            external_id="x",
            limit=1,
        )
        assert_matches_type(AsyncCursorPagination[Household], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncLuminary) -> None:
        response = await async_client.households.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        household = await response.parse()
        assert_matches_type(AsyncCursorPagination[Household], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncLuminary) -> None:
        async with async_client.households.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            household = await response.parse()
            assert_matches_type(AsyncCursorPagination[Household], household, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_delete(self, async_client: AsyncLuminary) -> None:
        household = await async_client.households.delete(
            "id",
        )
        assert household is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncLuminary) -> None:
        response = await async_client.households.with_raw_response.delete(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        household = await response.parse()
        assert household is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncLuminary) -> None:
        async with async_client.households.with_streaming_response.delete(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            household = await response.parse()
            assert household is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_delete(self, async_client: AsyncLuminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.households.with_raw_response.delete(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_documents(self, async_client: AsyncLuminary) -> None:
        household = await async_client.households.list_documents(
            id="id",
        )
        assert_matches_type(AsyncCursorPagination[Document], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_documents_with_all_params(self, async_client: AsyncLuminary) -> None:
        household = await async_client.households.list_documents(
            id="id",
            after="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            before="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            limit=1,
            type="GRAT_DESIGN_SUMMARY",
        )
        assert_matches_type(AsyncCursorPagination[Document], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list_documents(self, async_client: AsyncLuminary) -> None:
        response = await async_client.households.with_raw_response.list_documents(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        household = await response.parse()
        assert_matches_type(AsyncCursorPagination[Document], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list_documents(self, async_client: AsyncLuminary) -> None:
        async with async_client.households.with_streaming_response.list_documents(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            household = await response.parse()
            assert_matches_type(AsyncCursorPagination[Document], household, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_list_documents(self, async_client: AsyncLuminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.households.with_raw_response.list_documents(
                id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_entities(self, async_client: AsyncLuminary) -> None:
        household = await async_client.households.list_entities(
            id="id",
        )
        assert_matches_type(AsyncCursorPagination[Entity], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_entities_with_all_params(self, async_client: AsyncLuminary) -> None:
        household = await async_client.households.list_entities(
            id="id",
            after="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            before="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            kind="REVOCABLE_TRUST",
            limit=1,
        )
        assert_matches_type(AsyncCursorPagination[Entity], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list_entities(self, async_client: AsyncLuminary) -> None:
        response = await async_client.households.with_raw_response.list_entities(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        household = await response.parse()
        assert_matches_type(AsyncCursorPagination[Entity], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list_entities(self, async_client: AsyncLuminary) -> None:
        async with async_client.households.with_streaming_response.list_entities(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            household = await response.parse()
            assert_matches_type(AsyncCursorPagination[Entity], household, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_list_entities(self, async_client: AsyncLuminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.households.with_raw_response.list_entities(
                id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_individuals(self, async_client: AsyncLuminary) -> None:
        household = await async_client.households.list_individuals(
            id="id",
        )
        assert_matches_type(AsyncCursorPagination[Individual], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_individuals_with_all_params(self, async_client: AsyncLuminary) -> None:
        household = await async_client.households.list_individuals(
            id="id",
            after="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            before="eyJpZCI6ImhvdXNlaG9sZF8wMUFSWjNOREVLVFNWNFJSRkZRNjlHNUZBViJ9",
            is_primary=True,
            limit=1,
        )
        assert_matches_type(AsyncCursorPagination[Individual], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list_individuals(self, async_client: AsyncLuminary) -> None:
        response = await async_client.households.with_raw_response.list_individuals(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        household = await response.parse()
        assert_matches_type(AsyncCursorPagination[Individual], household, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list_individuals(self, async_client: AsyncLuminary) -> None:
        async with async_client.households.with_streaming_response.list_individuals(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            household = await response.parse()
            assert_matches_type(AsyncCursorPagination[Individual], household, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_list_individuals(self, async_client: AsyncLuminary) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.households.with_raw_response.list_individuals(
                id="",
            )
