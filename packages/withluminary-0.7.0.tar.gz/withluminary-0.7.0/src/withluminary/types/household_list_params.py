# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["HouseholdListParams"]


class HouseholdListParams(TypedDict, total=False):
    after: str
    """Cursor for forward pagination. Returns items after this cursor."""

    before: str
    """Cursor for backward pagination. Returns items before this cursor."""

    external_id: str
    """Filter by external ID (exact match within the caller's tenant)"""

    limit: int
    """Maximum number of items to return"""
