# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import TypedDict

__all__ = ["HouseholdUpdateParams"]


class HouseholdUpdateParams(TypedDict, total=False):
    external_id: Optional[str]
    """Customer-supplied identifier from an external system.

    Unique within the caller's tenant when set. Send null to clear.
    """

    notes: Optional[str]
    """Notes about the household"""

    primary_relationship_owner_id: str
    """User ID of the primary relationship owner"""
