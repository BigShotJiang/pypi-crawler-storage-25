# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

from .entity_kind import EntityKind

__all__ = ["EntityListParams"]


class EntityListParams(TypedDict, total=False):
    after: str
    """Cursor for forward pagination. Returns items after this cursor."""

    before: str
    """Cursor for backward pagination. Returns items before this cursor."""

    external_id: str
    """Filter by external ID (exact match within the caller's tenant)"""

    household_id: str
    """Filter entities by household ID"""

    kind: EntityKind
    """Filter by entity kind/type"""

    limit: int
    """Maximum number of items to return"""
