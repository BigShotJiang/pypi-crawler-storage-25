# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from .._models import BaseModel
from .individual import Individual

__all__ = ["Household"]


class Household(BaseModel):
    id: str
    """Unique identifier with household\\__ prefix"""

    created_at: datetime
    """Timestamp when the household was created"""

    primary_relationship_owner_id: str
    """User ID of the primary relationship owner"""

    updated_at: datetime
    """Timestamp when the household was last updated"""

    external_id: Optional[str] = None
    """Customer-supplied identifier from an external system.

    Unique within the caller's tenant when set.
    """

    name: Optional[str] = None
    """Display name for the household"""

    notes: Optional[str] = None
    """Notes about the household"""

    primary_individuals: Optional[List[Individual]] = None
    """Primary client profiles for this household (at most 2)"""
