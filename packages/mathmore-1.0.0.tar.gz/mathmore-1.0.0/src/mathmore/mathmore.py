def info():
    return '''
This module is made by HZY.
This is a mathematical module.
Now,the version of the module is 1.0.1.
'''

def root_of_unity(exponent):
    import cmath
    list_root=[]
    for term in range(0,exponent):
        item=2*term/exponent
        in_list=cmath.exp(item*(1j)*cmath.pi)
        real=in_list.real
        imag=in_list.imag
        if abs(in_list.imag)<=1e-10:
            imag=0
            in_list=real+imag*(1j)
        if abs(in_list.real-round(in_list.real,5))<=1e-10:
           real=round(in_list.real,5)
           in_list=real+imag*(1j)
        list_root.append(in_list)
    return list_root

def distance(tuple1,tuple2):
    from math import sqrt
    if tuple1==():
        tuple1=(0,0)
    if tuple2==():
        tuple2=(0,0)
    if len(tuple1)>2 or len(tuple1)==1 or len(tuple2)>2 or len(tuple2)==1:
        raise SyntaxError
    dist=sqrt((tuple1[0]-tuple2[0])**2+(tuple1[1]-tuple2[1])**2)
    return dist

omega=0.567143290409784
gamma=0.577215664901533

def get_help():
    help="""
This module is made by HZY.
FUCTIONS:
get_version()               You can get the version of the module.(Now,the version of the module is 1.0.1.)
info()                      You can get the informations of the module.
get_help()                  You can get all the functions and usages of the module.
root_of_unity(exponent)     This function can export n-dimensional unit roots.
distance(tuple1,tuple2)     This function can export the distance between two points.

CONSTANTS:(All the expressions will use the LaTeX grammar.)
omega                       This constant satisfies an equation:xe^{x}=1.
gamma                       This constant the solution of a limit expression:\lim\limits_{x\to\infty}\big(H(x)-\ln x\big)
"""
    return help

