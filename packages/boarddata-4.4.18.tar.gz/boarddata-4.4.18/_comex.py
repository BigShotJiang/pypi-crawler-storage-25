"""Comex (executive committee) mandate and compensation methods."""

from __future__ import annotations

import logging
from typing import Any

from .types.core import FieldSourcePayload, PaginatedResponse, UpsertResult
from .types.comex import ComexCompensationDetail, ComexDetail

logger = logging.getLogger("boarddata")


class ComexMixin:
    """Comex mandate and compensation API methods.

    .. important:: Comex compensations use **fixed/variable/stock_options** fields,
       NOT the token/attendance fields used by board compensations.
       See ``DirectorMixin`` for board compensation.
    """

    # ------------------------------------------------------------------
    # Comex mandates
    # ------------------------------------------------------------------

    def list_comex(
        self,
        *,
        company: str | None = None,
        person: str | None = None,
        search: str | None = None,
        search_scope: str | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
        as_of: str | None = None,
        nature: str | None = None,
        roles: list[str] | None = None,
        role_at: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
        **kwargs: Any,
    ) -> PaginatedResponse:
        """List comex mandates.

        Args:
            company: Filter by company UUID.
            person: Filter by person UUID.
            search: Search by person or company name.
            search_scope: Scope for search.
            date_from: Filter mandates valid from this date.
            date_to: Filter mandates valid to this date.
            as_of: Show mandates active on this date.
            nature: Filter by compensation nature (``"REAL"`` or ``"POLITIC"``).
            roles: Filter by role identifiers (e.g. ``["CEO", "CFO"]``).
            role_at: Filter for mandates that held a role at this date (``"YYYY-MM-DD"``).
            page: Page number (1-indexed).
            page_size: Results per page.
            **kwargs: Advanced filters — ``indexes``, ``sectors``, ``headquarters``,
                ``governance_code``, ``floating``, ``turnover``, ``gender``,
                ``nationality``, ``age``, ``fiscal_year``,
                ``validity_interval``, and all ``_exclude`` variants.

        Returns:
            PaginatedResponse with ``results`` list of ComexListItem.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        params: dict[str, Any] = {}
        if roles:
            params["roles"] = ",".join(roles)
        return self._get(  # type: ignore[attr-defined]
            "comex/",
            company=company,
            person=person,
            search=search,
            search_scope=search_scope,
            date_from=date_from,
            date_to=date_to,
            as_of=as_of,
            nature=nature,
            role_at=role_at,
            page=page,
            page_size=page_size,
            **params,
            **kwargs,
        )

    def get_comex(self, uid: str) -> ComexDetail:
        """Retrieve a comex mandate by UUID.

        Args:
            uid: Comex mandate UUID.

        Returns:
            ComexDetail with full mandate data.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get(f"comex/{uid}/")  # type: ignore[attr-defined]

    def create_comex(
        self,
        company: str,
        person: str,
        *,
        title: str | None = None,
        roles: list[str] | None = None,
        valid_from: str | None = None,
        valid_to: str | None = None,
        cause_end: str | None = None,
        assembly_leave: str | None = None,
        resolution_nominated: str | None = None,
        field_sources: list[FieldSourcePayload] | None = None,
    ) -> ComexDetail:
        """Create a comex mandate.

        Args:
            company: Company UUID.
            person: Person UUID.
            title: Mandate title/role.
            roles: List of role identifiers (e.g. ``["CEO"]``).
            valid_from: Start date (``"YYYY-MM-DD"``).
            valid_to: End date (``"YYYY-MM-DD"``).
            cause_end: Reason the mandate ended.
            assembly_leave: Assembly where departure was noted.
            resolution_nominated: Resolution that nominated this person.
            field_sources: Document provenance for fields.

        Returns:
            Created ComexDetail.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = self._build_payload(  # type: ignore[attr-defined]
            company=company,
            person=person,
            title=title,
            roles=roles,
            valid_from=valid_from,
            valid_to=valid_to,
            cause_end=cause_end,
            assembly_leave=assembly_leave,
            resolution_nominated=resolution_nominated,
            field_sources=field_sources,
        )
        return self._post("comex/", payload)  # type: ignore[attr-defined]

    def update_comex(
        self,
        uid: str,
        *,
        title: str | None = None,
        roles: list[str] | None = None,
        valid_from: str | None = None,
        valid_to: str | None = None,
        cause_end: str | None = None,
        assembly_leave: str | None = None,
        resolution_nominated: str | None = None,
        field_sources: list[FieldSourcePayload] | None = None,
    ) -> ComexDetail:
        """Partial update a comex mandate.

        Args:
            uid: Comex mandate UUID.
            title: Mandate title/role.
            roles: List of role identifiers (e.g. ``["CEO"]``).
            valid_from: Start date.
            valid_to: End date.
            cause_end: Reason the mandate ended.
            assembly_leave: Assembly where departure was noted.
            resolution_nominated: Resolution that nominated this person.
            field_sources: Document provenance for fields.

        Returns:
            Updated ComexDetail.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = self._build_payload(  # type: ignore[attr-defined]
            title=title,
            roles=roles,
            valid_from=valid_from,
            valid_to=valid_to,
            cause_end=cause_end,
            assembly_leave=assembly_leave,
            resolution_nominated=resolution_nominated,
            field_sources=field_sources,
        )
        return self._patch(f"comex/{uid}/", payload)  # type: ignore[attr-defined]

    def delete_comex(self, uid: str) -> None:
        """Soft-delete a comex mandate.

        Args:
            uid: Comex mandate UUID.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        self._delete(f"comex/{uid}/")  # type: ignore[attr-defined]

    def get_comex_stats(self, **params: Any) -> Any:
        """Get comex mandate statistics.

        Args:
            company: Filter by company UUID.
            fiscal_year: Filter by fiscal year.

        Returns:
            Dict with comex mandate statistics.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get("comex/stats/", **params)  # type: ignore[attr-defined]

    # ------------------------------------------------------------------
    # Comex compensations
    # ------------------------------------------------------------------

    def list_comex_compensations(self, comex_uid: str, **params: Any) -> PaginatedResponse:
        """List compensations for a comex mandate.

        Args:
            comex_uid: Comex mandate UUID.
            fiscal_year: Filter by fiscal year.
            nature: Filter by compensation nature.
            page: Page number.
            page_size: Results per page.

        Returns:
            Paginated response with ComexCompensationDetail results.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get(f"comex/{comex_uid}/compensations/", **params)  # type: ignore[attr-defined]

    def get_comex_compensation(self, comex_uid: str, pk: str) -> ComexCompensationDetail:
        """Retrieve a single comex compensation.

        Args:
            comex_uid: Comex mandate UUID.
            pk: Compensation entry ID.

        Returns:
            ComexCompensationDetail with full compensation data.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get(f"comex/{comex_uid}/compensations/{pk}/")  # type: ignore[attr-defined]

    def create_comex_compensation(
        self,
        comex_uid: str,
        fiscal_year: int,
        nature: str,
        *,
        assembly: str | None = None,
        fixed: str | None = None,
        variable: str | None = None,
        exceptional: str | None = None,
        benefits_in_kind: str | None = None,
        stock_options: str | None = None,
        performance_shares: str | None = None,
        other_long_term: str | None = None,
        retirement_benefit: str | None = None,
        retirement_contribution: str | None = None,
        severance: str | None = None,
        golden_hello: str | None = None,
        fixed_paid: str | None = None,
        variable_paid: str | None = None,
        exceptional_paid: str | None = None,
        benefits_in_kind_paid: str | None = None,
        stock_options_paid: str | None = None,
        performance_shares_paid: str | None = None,
        other_long_term_paid: str | None = None,
        severance_paid: str | None = None,
        retirement_benefit_paid: str | None = None,
        retirement_contribution_paid: str | None = None,
        golden_hello_paid: str | None = None,
        exercised_options: str | None = None,
        performance_shares_number: int | None = None,
        pay_ratio_average: str | None = None,
        pay_ratio_median: str | None = None,
        pay_ratio_method: str | None = None,
        non_compete_compensation: str | None = None,
        non_compete: bool | None = None,
        clawback: bool | None = None,
        unemployment_insurance: bool | None = None,
        holding: bool | None = None,
        has_employment_contract: bool | None = None,
        discretionary_grant: bool | None = None,
        subsidiary_remuneration: str | None = None,
        remuneration_via_holding: bool | None = None,
        currency: str | None = None,
        field_sources: list[FieldSourcePayload] | None = None,
        criteria: list[dict[str, Any]] | None = None,
        component_achievement_rates: list[dict[str, Any]] | None = None,
    ) -> ComexCompensationDetail:
        """Create a compensation entry for a comex mandate.

        Args:
            comex_uid: Comex mandate UUID.
            fiscal_year: Fiscal year.
            nature: Compensation nature (``"REAL"`` or ``"POLITIC"``).
            assembly: Assembly UUID.
            fixed: Fixed compensation (decimal).
            variable: Variable compensation (decimal).
            exceptional: Exceptional compensation (decimal).
            benefits_in_kind: Benefits in kind (decimal).
            stock_options: Stock options value (decimal).
            performance_shares: Performance shares value (decimal).
            other_long_term: Other long-term compensation (decimal).
            retirement_benefit: Retirement benefit (decimal).
            retirement_contribution: Retirement contribution (decimal).
            severance: Severance (decimal).
            golden_hello: Golden hello (decimal).
            fixed_paid: Fixed paid (decimal).
            variable_paid: Variable paid (decimal).
            exceptional_paid: Exceptional paid (decimal).
            benefits_in_kind_paid: Benefits in kind paid (decimal).
            stock_options_paid: Stock options paid (decimal).
            performance_shares_paid: Performance shares paid (decimal).
            other_long_term_paid: Other long-term paid (decimal).
            severance_paid: Severance paid (decimal).
            retirement_benefit_paid: Retirement benefit paid (decimal).
            retirement_contribution_paid: Retirement contribution paid (decimal).
            golden_hello_paid: Golden hello paid (decimal).
            exercised_options: Exercised options value (decimal).
            performance_shares_number: Number of performance shares.
            pay_ratio_average: Average pay ratio (decimal).
            pay_ratio_median: Median pay ratio (decimal).
            pay_ratio_method: Pay ratio calculation method.
            non_compete_compensation: Non-compete compensation (decimal).
            non_compete: Whether non-compete clause applies.
            clawback: Whether clawback clause applies.
            unemployment_insurance: Whether unemployment insurance applies.
            holding: Whether holding applies.
            has_employment_contract: Whether has employment contract.
            discretionary_grant: Whether discretionary grant applies.
            subsidiary_remuneration: Subsidiary remuneration (decimal).
            remuneration_via_holding: Whether remuneration is provided via holding.
            currency: Currency code (e.g. ``"EUR"``).
            field_sources: Document provenance for fields.
            criteria: List of compensation criteria dicts.
            component_achievement_rates: List of achievement rate dicts.

        Returns:
            Created ComexCompensationDetail.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = self._build_payload(  # type: ignore[attr-defined]
            fiscal_year=fiscal_year,
            nature=nature,
            assembly=assembly,
            fixed=fixed,
            variable=variable,
            exceptional=exceptional,
            benefits_in_kind=benefits_in_kind,
            stock_options=stock_options,
            performance_shares=performance_shares,
            other_long_term=other_long_term,
            retirement_benefit=retirement_benefit,
            retirement_contribution=retirement_contribution,
            severance=severance,
            golden_hello=golden_hello,
            fixed_paid=fixed_paid,
            variable_paid=variable_paid,
            exceptional_paid=exceptional_paid,
            benefits_in_kind_paid=benefits_in_kind_paid,
            stock_options_paid=stock_options_paid,
            performance_shares_paid=performance_shares_paid,
            other_long_term_paid=other_long_term_paid,
            severance_paid=severance_paid,
            retirement_benefit_paid=retirement_benefit_paid,
            retirement_contribution_paid=retirement_contribution_paid,
            golden_hello_paid=golden_hello_paid,
            exercised_options=exercised_options,
            performance_shares_number=performance_shares_number,
            pay_ratio_average=pay_ratio_average,
            pay_ratio_median=pay_ratio_median,
            pay_ratio_method=pay_ratio_method,
            non_compete_compensation=non_compete_compensation,
            non_compete=non_compete,
            clawback=clawback,
            unemployment_insurance=unemployment_insurance,
            holding=holding,
            has_employment_contract=has_employment_contract,
            discretionary_grant=discretionary_grant,
            subsidiary_remuneration=subsidiary_remuneration,
            remuneration_via_holding=remuneration_via_holding,
            currency=currency,
            field_sources=field_sources,
            criteria=criteria,
            component_achievement_rates=component_achievement_rates,
        )
        return self._post(f"comex/{comex_uid}/compensations/", payload)  # type: ignore[attr-defined]

    def update_comex_compensation(
        self,
        comex_uid: str,
        pk: str,
        **comp_fields: Any,
    ) -> ComexCompensationDetail:
        """Partial update a comex compensation.

        Args:
            comex_uid: Comex mandate UUID.
            pk: Compensation entry ID.
            **comp_fields: Compensation fields to update (see create_comex_compensation).

        Returns:
            Updated ComexCompensationDetail.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = {k: v for k, v in comp_fields.items() if v is not None}
        return self._patch(f"comex/{comex_uid}/compensations/{pk}/", payload)  # type: ignore[attr-defined]

    def delete_comex_compensation(self, comex_uid: str, pk: str) -> None:
        """Delete a comex compensation.

        Args:
            comex_uid: Comex mandate UUID.
            pk: Compensation entry ID.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        self._delete(f"comex/{comex_uid}/compensations/{pk}/")  # type: ignore[attr-defined]

    def list_bulk_comex_compensations(self, **params: Any) -> PaginatedResponse:
        """Bulk-read compensations across multiple comex mandates.

        Args:
            company: Filter by company UUID.
            fiscal_year: Filter by fiscal year.
            nature: Filter by compensation nature.
            page: Page number.
            page_size: Results per page.

        Returns:
            Paginated response with comex compensation results across mandates.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get("comex/compensations/", **params)  # type: ignore[attr-defined]

    # ------------------------------------------------------------------
    # Upsert
    # ------------------------------------------------------------------

    def upsert_comex(
        self,
        company: str,
        person: str,
        *,
        title: str | None = None,
        roles: list[str] | None = None,
        valid_from: str | None = None,
        valid_to: str | None = None,
        cause_end: str | None = None,
        assembly_leave: str | None = None,
        resolution_nominated: str | None = None,
        field_sources: list[FieldSourcePayload] | None = None,
    ) -> UpsertResult:
        """Find comex mandate by company+person+validity, create or update.

        Args:
            company: Company UUID.
            person: Person UUID.
            title: Mandate title/role.
            roles: List of role identifiers (e.g. ``["CEO"]``).
            valid_from: Start date (``"YYYY-MM-DD"``).
            valid_to: End date (``"YYYY-MM-DD"``).
            cause_end: Reason the mandate ended.
            assembly_leave: Assembly where departure was noted.
            resolution_nominated: Resolution that nominated this person.
            field_sources: Document provenance for fields.

        Returns:
            UpsertResult::

                {"action": "created", "id": "uuid", "data": {<ComexDetail>}}

        Raises:
            BoardDataError: On non-2xx API response.
        """
        resp = self.list_comex(
            company=company,
            person=person,
            valid_from=valid_from,
            valid_to=valid_to,
        )
        results = resp.get("results", []) if isinstance(resp, dict) else resp
        existing = results[0] if results else None

        payload = self._build_payload(  # type: ignore[attr-defined]
            company=company,
            person=person,
            title=title,
            roles=roles,
            valid_from=valid_from,
            valid_to=valid_to,
            cause_end=cause_end,
            assembly_leave=assembly_leave,
            resolution_nominated=resolution_nominated,
            field_sources=field_sources,
        )

        if existing:
            comex_uid = existing["id"]
            logger.info("Updating comex mandate %s", comex_uid)
            data = self._patch(f"comex/{comex_uid}/", payload)  # type: ignore[attr-defined]
            return UpsertResult(action="updated", id=comex_uid, data=data)

        logger.info("Creating comex mandate")
        data = self._post("comex/", payload)  # type: ignore[attr-defined]
        return UpsertResult(action="created", id=data["id"], data=data)
