"""BoardData API Python SDK."""

from .cache import FileTokenCache, ScalewaySecretTokenCache
from ._base import Base, TokenCache
from .client import BoardDataClient
from .errors import BoardDataError

from . import types as types  # noqa: F401 — makes types accessible as boarddata.types

__version__ = "4.4.18"
__all__ = [
    "Base",
    "BoardDataClient",
    "BoardDataError",
    "FileTokenCache",
    "ScalewaySecretTokenCache",
    "TokenCache",
    "__version__",
]
