"""Comex mandate and compensation types."""

from __future__ import annotations

try:
    from typing import Any, NotRequired, TypedDict
except ImportError:
    from typing_extensions import Any, NotRequired, TypedDict

from .core import FieldSourceItem, FieldSourcePayload
from .directors import RoleEntry

__all__ = ["RoleEntry"]  # re-export for convenience


class _PersonSummary(TypedDict):
    id: str
    first_name: str
    last_name: str


class _CompanySummary(TypedDict):
    id: str
    name: str


# -- Compensation criteria --

class _CriteriaSummary(TypedDict):
    id: int
    name: str
    theme_name: str
    theme_category: str


class ComexCompensationCriteria(TypedDict):
    criteria: _CriteriaSummary
    component_type: str
    label: str
    weight: str | None
    duration: int | None
    achievement_value: str | None
    achievement_rate: str | None
    achievement_rate_percent: str | None
    achievement_rate_target: str | None
    achievement_rate_target_percent: str | None
    achievement_rate_min: str | None
    achievement_rate_min_percent: str | None
    achievement_rate_max: str | None
    achievement_rate_max_percent: str | None
    target_value: str
    achieved_value: str
    is_condition: bool


class ComponentAchievementRate(TypedDict):
    component_type: str
    achievement_value: str | None
    achievement_rate: str | None
    achievement_rate_percent: str | None
    achievement_rate_target: str | None
    achievement_rate_target_percent: str | None
    achievement_rate_min: str | None
    achievement_rate_min_percent: str | None
    achievement_rate_max: str | None
    achievement_rate_max_percent: str | None


# -- Comex compensation --

class ComexCompensationItem(TypedDict):
    """Compensation as returned in list endpoints (inline)."""
    id: str
    fiscal_year: int
    nature: str
    fixed: str | None
    variable: str | None
    exceptional: str | None
    benefits_in_kind: str | None
    stock_options: str | None
    performance_shares: str | None
    other_long_term: str | None
    retirement_benefit: str | None
    retirement_contribution: str | None
    severance: str | None
    golden_hello: str | None
    fixed_paid: str | None
    variable_paid: str | None
    exceptional_paid: str | None
    benefits_in_kind_paid: str | None
    stock_options_paid: str | None
    performance_shares_paid: str | None
    other_long_term_paid: str | None
    severance_paid: str | None
    retirement_benefit_paid: str | None
    retirement_contribution_paid: str | None
    golden_hello_paid: str | None
    exercised_options: str | None
    performance_shares_number: int | None
    pay_ratio_average: str | None
    pay_ratio_median: str | None
    non_compete_compensation: str | None
    non_compete: bool
    clawback: bool
    unemployment_insurance: bool
    subsidiary_remuneration: str | None
    holding: bool
    has_employment_contract: bool
    remuneration_via_holding: bool
    total: str | None
    total_paid: str | None
    currency: str
    component_achievement_rates: list[ComponentAchievementRate]


class ComexCompensationDetail(TypedDict):
    """Compensation with full criteria and sources."""
    id: str
    fiscal_year: int
    nature: str
    fixed: str | None
    variable: str | None
    exceptional: str | None
    benefits_in_kind: str | None
    stock_options: str | None
    performance_shares: str | None
    other_long_term: str | None
    retirement_benefit: str | None
    retirement_contribution: str | None
    severance: str | None
    golden_hello: str | None
    fixed_paid: str | None
    variable_paid: str | None
    exceptional_paid: str | None
    benefits_in_kind_paid: str | None
    stock_options_paid: str | None
    performance_shares_paid: str | None
    other_long_term_paid: str | None
    severance_paid: str | None
    retirement_benefit_paid: str | None
    retirement_contribution_paid: str | None
    golden_hello_paid: str | None
    exercised_options: str | None
    performance_shares_number: int | None
    pay_ratio_average: str | None
    pay_ratio_median: str | None
    pay_ratio_method: str
    non_compete_compensation: str | None
    non_compete: bool
    clawback: bool
    unemployment_insurance: bool
    holding: bool
    has_employment_contract: bool
    discretionary_grant: bool
    subsidiary_remuneration: str | None
    remuneration_via_holding: bool
    currency: str
    total: str | None
    total_paid: str | None
    criteria: list[ComexCompensationCriteria]
    component_achievement_rates: list[ComponentAchievementRate]
    _sources: list[FieldSourceItem]


class CreateComexCompensationPayload(TypedDict):
    fiscal_year: int
    nature: str
    assembly: NotRequired[str | None]
    fixed: NotRequired[str | None]
    variable: NotRequired[str | None]
    exceptional: NotRequired[str | None]
    benefits_in_kind: NotRequired[str | None]
    stock_options: NotRequired[str | None]
    performance_shares: NotRequired[str | None]
    other_long_term: NotRequired[str | None]
    retirement_benefit: NotRequired[str | None]
    retirement_contribution: NotRequired[str | None]
    severance: NotRequired[str | None]
    golden_hello: NotRequired[str | None]
    fixed_paid: NotRequired[str | None]
    variable_paid: NotRequired[str | None]
    exceptional_paid: NotRequired[str | None]
    benefits_in_kind_paid: NotRequired[str | None]
    stock_options_paid: NotRequired[str | None]
    performance_shares_paid: NotRequired[str | None]
    other_long_term_paid: NotRequired[str | None]
    severance_paid: NotRequired[str | None]
    retirement_benefit_paid: NotRequired[str | None]
    retirement_contribution_paid: NotRequired[str | None]
    golden_hello_paid: NotRequired[str | None]
    exercised_options: NotRequired[str | None]
    performance_shares_number: NotRequired[int | None]
    pay_ratio_average: NotRequired[str | None]
    pay_ratio_median: NotRequired[str | None]
    pay_ratio_method: NotRequired[str]
    non_compete_compensation: NotRequired[str | None]
    non_compete: NotRequired[bool]
    clawback: NotRequired[bool]
    unemployment_insurance: NotRequired[bool]
    holding: NotRequired[bool]
    has_employment_contract: NotRequired[bool]
    discretionary_grant: NotRequired[bool]
    subsidiary_remuneration: NotRequired[str | None]
    remuneration_via_holding: NotRequired[bool]
    currency: NotRequired[str]
    field_sources: NotRequired[list[FieldSourcePayload]]
    criteria: NotRequired[list[dict[str, Any]]]
    component_achievement_rates: NotRequired[list[dict[str, Any]]]


class UpdateComexCompensationPayload(TypedDict, total=False):
    fiscal_year: int
    nature: str
    assembly: str | None
    fixed: str | None
    variable: str | None
    exceptional: str | None
    benefits_in_kind: str | None
    stock_options: str | None
    performance_shares: str | None
    other_long_term: str | None
    retirement_benefit: str | None
    retirement_contribution: str | None
    severance: str | None
    golden_hello: str | None
    fixed_paid: str | None
    variable_paid: str | None
    exceptional_paid: str | None
    benefits_in_kind_paid: str | None
    stock_options_paid: str | None
    performance_shares_paid: str | None
    other_long_term_paid: str | None
    severance_paid: str | None
    retirement_benefit_paid: str | None
    retirement_contribution_paid: str | None
    golden_hello_paid: str | None
    exercised_options: str | None
    performance_shares_number: int | None
    pay_ratio_average: str | None
    pay_ratio_median: str | None
    pay_ratio_method: str
    non_compete_compensation: str | None
    non_compete: bool
    clawback: bool
    unemployment_insurance: bool
    holding: bool
    has_employment_contract: bool
    discretionary_grant: bool
    subsidiary_remuneration: str | None
    remuneration_via_holding: bool
    currency: str
    field_sources: list[FieldSourcePayload]
    criteria: list[dict[str, Any]]
    component_achievement_rates: list[dict[str, Any]]


# -- Comex mandates --

class ComexListItem(TypedDict):
    id: str
    person: _PersonSummary
    company: _CompanySummary
    title: str
    roles: list[str]
    valid_from: str | None
    valid_to: str | None
    company_country: str
    company_sectors: str
    governance_code: str
    company_index: str
    turnover_eur: str | None
    gender: str
    seniority: float | None
    age: int | None
    nationality: str
    compensation: dict[str, Any] | None
    criteria_count: int


class ComexDetail(TypedDict):
    id: str
    person: _PersonSummary
    company: _CompanySummary
    title: str
    roles: list[str]
    role_history: NotRequired[list[RoleEntry]]
    valid_from: str | None
    valid_to: str | None
    cause_end: str
    assembly_leave: str | None
    resolution_nominated: str | None
    comex_compensations: list[ComexCompensationDetail]
    _sources: list[FieldSourceItem]


class CreateComexPayload(TypedDict):
    company: str
    person: str
    title: NotRequired[str]
    roles: NotRequired[list[str]]
    valid_from: NotRequired[str]
    valid_to: NotRequired[str | None]
    cause_end: NotRequired[str]
    assembly_leave: NotRequired[str | None]
    resolution_nominated: NotRequired[str | None]
    field_sources: NotRequired[list[FieldSourcePayload]]


class UpdateComexPayload(TypedDict, total=False):
    title: str
    roles: list[str]
    valid_from: str
    valid_to: str | None
    cause_end: str
    assembly_leave: str | None
    resolution_nominated: str | None
    field_sources: list[FieldSourcePayload]


class ComexStats(TypedDict):
    """Dynamic shape based on query params."""
    pass
