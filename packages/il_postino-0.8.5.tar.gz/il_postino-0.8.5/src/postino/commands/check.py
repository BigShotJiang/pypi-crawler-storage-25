"""postino check — print findings + exit non-zero on errors.

Exit codes:

* 0 — every finding is severity="info".
* 4 — at least one finding is severity="error" (ConfigError).

Warnings (severity="warn") are surfaced visually but do not flip exit
code; that's the contract for non-blocking issues.
"""

from __future__ import annotations

import json as _json
import sys

import typer
from rich.console import Console

from postino.exit import exit_with_error, get_services, is_json
from postino_core.check.consistency import CheckResult, run_consistency_check
from postino_core.errors import ConfigError


def run(
    ctx: typer.Context,
    deep: bool = typer.Option(
        False,
        "--deep",
        help="Reconcile mailbox rows against maildirs on disk and check FK substitutes.",
    ),
) -> None:
    s = get_services(ctx)
    result = run_consistency_check(
        settings=s.settings,
        engine=s.engine,
        metadata=s.metadata,
        deep=deep,
    )
    if is_json(ctx):
        _render_json(result)
    else:
        _render_human(result)
    if not result.ok:
        exit_with_error(ConfigError("one or more checks failed"))


def _render_human(result: CheckResult) -> None:
    console = Console()
    marks = {
        "info": "[green]✓[/green]",
        "warn": "[yellow]![/yellow]",
        "error": "[red]✗[/red]",
    }
    for f in result.findings:
        console.print(f"{marks[f.severity]} {f.name}: {f.message}")


def _render_json(result: CheckResult) -> None:
    _json.dump(result.model_dump(mode="json"), sys.stdout)
    sys.stdout.write("\n")
