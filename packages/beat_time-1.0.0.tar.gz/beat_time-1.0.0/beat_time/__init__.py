from beat_time.beat import internettime, now
