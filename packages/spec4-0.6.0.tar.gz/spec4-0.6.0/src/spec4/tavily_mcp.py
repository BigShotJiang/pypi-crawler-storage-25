from __future__ import annotations

import asyncio
import concurrent.futures
import json
from collections.abc import Coroutine, Generator
from typing import Any

import litellm
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client


# Tool spec supplied to the LLM for web search.
WEB_SEARCH_TOOL: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "web_search",
        "description": "Search the web for current information on any topic.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The search query.",
                }
            },
            "required": ["query"],
        },
    },
}

# Appended to a system prompt when web search is available.
WEB_SEARCH_ADDENDUM = (
    "\n\nYou have direct access to the web_search tool. "
    "Whenever the user asks you to search, look something up, or find information, "
    "you MUST immediately call the web_search tool — never say you cannot search or "
    "that you lack access to it. The tool works for any query on any topic."
)


def build_system_prompt(base: str, tavily_api_key: str | None) -> str:
    """Append the web-search addendum to base when a Tavily key is present."""
    return base + (WEB_SEARCH_ADDENDUM if tavily_api_key else "")


def _url(api_key: str) -> str:
    return f"https://mcp.tavily.com/mcp/?tavilyApiKey={api_key}"


def _run_async(coro: Coroutine[Any, Any, Any]) -> Any:
    """Run an async coroutine from synchronous code.

    Always delegates to a fresh thread so it works regardless of whether
    the calling thread already has a running event loop (e.g. Streamlit).
    """
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
        return pool.submit(asyncio.run, coro).result()


async def _list_tools_async(api_key: str) -> list[str]:
    async with streamablehttp_client(_url(api_key)) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()
            result = await session.list_tools()
            return [t.name for t in result.tools]


async def _call_search_async(query: str, api_key: str) -> str:
    async with streamablehttp_client(_url(api_key)) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()
            # Discover the actual search tool name rather than hardcoding it.
            tools_result = await session.list_tools()
            tool = next(
                (t for t in tools_result.tools if "search" in t.name.lower()),
                None,
            )
            if tool is None:
                available = [t.name for t in tools_result.tools]
                return f"No search tool found. Available tools: {available}"
            result = await session.call_tool(tool.name, {"query": query})
            if result.content:
                return "\n".join(c.text for c in result.content if hasattr(c, "text"))
            return ""


def validate(api_key: str) -> tuple[bool, list[str], str]:
    """Validate a Tavily API key by listing available tools.

    Returns (True, tool_names, "") on success or (False, [], error_message) on failure.
    """
    try:
        tools = _run_async(_list_tools_async(api_key))
        return True, tools, ""
    except Exception as exc:
        return False, [], str(exc)


def search(query: str, api_key: str) -> str:
    """Run a web search via the Tavily MCP server. Returns the result text."""
    try:
        return str(_run_async(_call_search_async(query, api_key)))
    except Exception as exc:
        return f"Search failed: {exc}"


# Per-agent temperature tuning. Extraction-shaped agents (CodeScanner,
# Phaser, Deployer) emit structured artifacts where sampling creativity
# actively hurts (e.g. inventing canonical keys, paraphrasing instead of
# quoting, embedding shell fallbacks in command values). Conversational /
# creative agents stay near provider defaults.
#
# An agent not listed here falls through to the provider's default
# temperature. The user's llm_config can also include an explicit
# `temperature` key — that always wins over the per-agent mapping.
_AGENT_TEMPERATURE: dict[str, float] = {
    "code_scanner": 0.2,
    "phaser": 0.2,
    "deployer": 0.3,
}


def _temperature_for(
    agent_name: str | None, llm_config: dict[str, Any]
) -> float | None:
    """Return the temperature to merge into the completion kwargs, or None.

    Precedence: explicit `llm_config["temperature"]` (user override) >
    per-agent mapping > None (use provider default).
    """
    if "temperature" in llm_config:
        value = llm_config["temperature"]
        return float(value) if value is not None else None
    if agent_name is None:
        return None
    return _AGENT_TEMPERATURE.get(agent_name)


def _history_has_tool_use(messages: list[dict[str, Any]]) -> bool:
    """Return True if the message log contains tool calls or tool results.

    Anthropic (via litellm) rejects requests whose message history contains
    `tool_use` / `tool_result` blocks unless the request also specifies
    `tools=`. This check lets `stream_turn` keep `tools=` present on retry
    calls when prior tool use has already occurred, even when we would
    otherwise suppress the tool for `response_format`-style structured
    output.
    """
    for m in messages:
        if m.get("role") == "tool":
            return True
        if m.get("tool_calls"):
            return True
    return False


def supports_response_format(model: str) -> bool:
    """Return True if the provider/model accepts the `response_format` kwarg.

    Used by agents (currently only CodeScanner) that want to force a
    JSON-only retry after schema validation fails. LiteLLM exposes
    `get_supported_openai_params` per model; if that probe fails we
    conservatively return False rather than risking a 400 on the retry.
    """
    if not model:
        return False
    try:
        params = litellm.get_supported_openai_params(model=model) or []
    except Exception:
        return False
    return "response_format" in params


def stream_turn(
    system_prompt: str,
    messages: list[dict[str, Any]],
    llm_config: dict[str, Any],
    tavily_api_key: str | None,
    agent_name: str | None = None,
    response_format: dict[str, Any] | None = None,
) -> Generator[str, None, None]:
    """Stream one LLM conversation turn, handling tool calls transparently.

    Yields text chunks consumed by streaming.start() via the agent run() generators.
    Mutates `messages` to record the full turn (assistant reply + tool calls/results).
    Loops internally until the LLM produces a final text response.

    `agent_name`, when provided, opts the call into the per-agent temperature
    mapping in `_AGENT_TEMPERATURE`. An explicit `llm_config["temperature"]`
    always wins over the mapping.

    `response_format`, when provided, is forwarded to LiteLLM as-is — e.g.
    `{"type": "json_object"}` to force JSON-only output. When set, the
    web-search tool is suppressed for the call since JSON-mode responses
    do not interleave tool calls cleanly across providers — UNLESS the
    message history already contains tool_use / tool_result blocks, in
    which case `tools=` must remain present (Anthropic rejects the request
    otherwise with `UnsupportedParamsError`).
    """
    suppress_tools_for_format = (
        response_format is not None and not _history_has_tool_use(messages)
    )
    tools = (
        [WEB_SEARCH_TOOL]
        if tavily_api_key and not suppress_tools_for_format
        else None
    )
    temperature = _temperature_for(agent_name, llm_config)

    while True:
        llm_messages = [{"role": "system", "content": system_prompt}] + messages
        kwargs: dict[str, Any] = dict(
            model=llm_config["model"],
            messages=llm_messages,
            api_key=llm_config["api_key"],
            stream=True,
        )
        if temperature is not None:
            kwargs["temperature"] = temperature
        if tools:
            kwargs["tools"] = tools
        if response_format is not None:
            kwargs["response_format"] = response_format

        response = litellm.completion(**kwargs)

        full_text = ""
        tool_call_acc: dict[int, dict[str, str]] = {}
        tool_call_started = False

        for chunk in response:
            choice = chunk.choices[0]

            if choice.delta.tool_calls:
                tool_call_started = True

            delta = choice.delta.content or ""
            if delta:
                full_text += delta
                if not tool_call_started:
                    yield delta

            if choice.delta.tool_calls:
                for tc in choice.delta.tool_calls:
                    i = tc.index
                    if i not in tool_call_acc:
                        tool_call_acc[i] = {"id": "", "name": "", "arguments": ""}
                    if tc.id:
                        tool_call_acc[i]["id"] = tc.id
                    if tc.function:
                        if tc.function.name:
                            tool_call_acc[i]["name"] += tc.function.name
                        if tc.function.arguments:
                            tool_call_acc[i]["arguments"] += tc.function.arguments

        if tool_call_acc:
            messages.append(
                {
                    "role": "assistant",
                    "content": full_text or None,
                    "tool_calls": [
                        {
                            "id": tc["id"],
                            "type": "function",
                            "function": {
                                "name": tc["name"],
                                "arguments": tc["arguments"],
                            },
                        }
                        for tc in tool_call_acc.values()
                    ],
                }
            )
            for tc in tool_call_acc.values():
                if tc["name"] == "web_search":
                    try:
                        query = json.loads(tc["arguments"]).get("query", "")
                    except (json.JSONDecodeError, KeyError):
                        query = tc["arguments"]
                    yield f"\n\n*🔍 Searching: {query}*\n\n"
                    if tavily_api_key is None:
                        raise RuntimeError(
                            "web_search tool called but tavily_api_key is None"
                        )
                    result = search(query, tavily_api_key)
                    if result.startswith("Search failed:") or result.startswith(
                        "No search tool"
                    ):
                        yield f"\n\n> ⚠️ {result}\n\n"
                    messages.append(
                        {
                            "role": "tool",
                            "tool_call_id": tc["id"],
                            "content": result,
                        }
                    )
            continue

        else:
            messages.append({"role": "assistant", "content": full_text})
            return
