from __future__ import annotations
from typing import List, Tuple, Iterable

from ._paragon import Graph as _Graph
from ._paragon import WeightedGraph as _WeightedGraph


class Graph(_Graph):
    """
    Graph data structure (unweighted).

    This is a Python wrapper over a high-performance C++ implementation.

    Parameters
    ----------
    vertices : int
        Number of vertices in the graph.

    directed : bool, optional (default=False)
        Whether the graph is directed.

    Notes
    -----
    - Nodes are indexed from 0 to vertices-1
    - Uses adjacency list internally
    """

    def __init__(self, vertices: int, directed: bool = False) -> None:
        if not isinstance(vertices, int) or vertices <= 0:
            raise ValueError("vertices must be a positive integer")

        super().__init__(vertices, directed)

    # ---------------- EDGE OPERATIONS ---------------- #

    def add_edge(self, u: int, v: int) -> None:
        """
        Add an edge between u and v.

        Parameters
        ----------
        u : int
            Source node
        v : int
            Destination node

        Raises
        ------
        ValueError
            If u or v are invalid
        """
        if not isinstance(u, int) or not isinstance(v, int):
            raise TypeError("u and v must be integers")

        if u < 0 or v < 0:
            raise ValueError("Node indices must be non-negative")

        super().add_edge(u, v)

    def add_edges(self, edges: Iterable[Tuple[int, int]]) -> None:
        """
        Add multiple edges.

        Parameters
        ----------
        edges : Iterable[Tuple[int, int]]
            List of (u, v) edges
        """
        for u, v in edges:
            self.add_edge(u, v)

    # ---------------- GRAPH INFO ---------------- #

    def vertices(self) -> int:
        """
        Return number of vertices.

        Returns
        -------
        int
        """
        return super().vertices()

    def get_adj(self) -> List[List[int]]:
        """
        Get adjacency list.

        Returns
        -------
        List[List[int]]
        """
        return super().get_adj()

    def degree(self, u: int) -> int:
        """
        Get degree of a node.

        Parameters
        ----------
        u : int

        Returns
        -------
        int
        """
        return super().degree(u)

    def has_edge(self, u: int, v: int) -> bool:
        """
        Check if edge exists.

        Returns
        -------
        bool
        """
        return super().has_edge(u, v)

    # ---------------- UTILITIES ---------------- #

    def __repr__(self) -> str:
        return f"Graph(vertices={self.vertices()})"


class WeightedGraph(_WeightedGraph):
    """
    Weighted graph data structure.

    Parameters
    ----------
    vertices : int
        Number of vertices

    directed : bool, optional
        Whether graph is directed

    Notes
    -----
    - Edge weights are floats
    """

    def __init__(self, vertices: int, directed: bool = False) -> None:
        if not isinstance(vertices, int) or vertices <= 0:
            raise ValueError("vertices must be a positive integer")

        super().__init__(vertices, directed)

    def add_edge(self, u: int, v: int, w: float) -> None:
        """
        Add weighted edge.

        Parameters
        ----------
        u : int
        v : int
        w : float
            Edge weight
        """
        if not isinstance(w, (int, float)):
            raise TypeError("weight must be numeric")

        super().add_edge(u, v, float(w))

    def add_edges(self, edges: Iterable[Tuple[int, int, float]]) -> None:
        """
        Add multiple weighted edges.

        Parameters
        ----------
        edges : Iterable[Tuple[int, int, float]]
        """
        for u, v, w in edges:
            self.add_edge(u, v, w)

    def get_adj(self) -> List[List[Tuple[int, float]]]:
        """
        Get weighted adjacency list.

        Returns
        -------
        List[List[Tuple[int, float]]]
        """
        return super().get_adj()

    def __repr__(self) -> str:
        return f"WeightedGraph(vertices={self.vertices()})"