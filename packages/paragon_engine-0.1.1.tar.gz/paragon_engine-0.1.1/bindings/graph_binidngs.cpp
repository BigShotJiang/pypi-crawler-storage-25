#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include "graph.hpp"

namespace py = pybind11;

void bind_graph(py::module_ &m) {

    py::class_<Graph>(m, "Graph")
        .def(py::init<int, bool>(), py::arg("vertices"), py::arg("directed")=false)
        .def("add_edge", &Graph::addEdge)
        .def("add_vertex", &Graph::addVertex)
        .def("vertices", &Graph::vertices)
        .def("degree", &Graph::degree)
        .def("has_edge", &Graph::hasEdge)
        .def("get_adj", &Graph::getAdj);

    py::class_<WeightedGraph>(m, "WeightedGraph")
        .def(py::init<int, bool>(), py::arg("vertices"), py::arg("directed")=false)
        .def("add_edge", &WeightedGraph::addEdge)
        .def("get_adj", &WeightedGraph::getWeightedAdj);
}