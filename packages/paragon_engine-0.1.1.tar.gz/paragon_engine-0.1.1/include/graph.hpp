#pragma once

#include <vector>
#include <utility>      // pair
#include <tuple>        // tuple
#include <stdexcept>    // out_of_range
#include <algorithm>    // find
#include <iostream>     // cout

class Graph {
private:
    int V;                                 // Number of vertices
    bool directed;                         // Directed or undirected graph
    std::vector<std::vector<int>> adj;     // Adjacency list

public:
    /* ================= CONSTRUCTORS ================= */

    Graph() : V(0), directed(false) {}

    Graph(int vertices, bool isDirected = false) {
        V = vertices;
        directed = isDirected;
        adj.resize(V);
    }

    Graph(const std::vector<std::vector<int>>& adjacency, bool isDirected = false) {
        V = adjacency.size();
        directed = isDirected;
        adj = adjacency;
    }

    Graph(int vertices, const std::vector<std::pair<int,int>>& edges, bool isDirected = false) {
        V = vertices;
        directed = isDirected;
        adj.resize(V);
        for (auto &e : edges) {
            addEdge(e.first, e.second);
        }
    }

    /* ================= BASIC UTILITIES ================= */

    int vertices() const {
        return V;
    }

    bool isDirected() const {
        return directed;
    }

    const std::vector<std::vector<int>>& getAdj() const {
        return adj;
    }

    /* ================= MODIFY GRAPH ================= */

    void addVertex() {
        adj.push_back({});
        V++;
    }

    void addEdge(int u, int v) {
        if (u >= V || v >= V)
            throw std::out_of_range("Vertex index out of range");

        adj[u].push_back(v);
        if (!directed) {
            adj[v].push_back(u);
        }
    }

    void addEdges(const std::vector<std::pair<int,int>>& edges) {
        for (auto &e : edges) {
            addEdge(e.first, e.second);
        }
    }

    /* ================= BUILD FROM DATA ================= */

    void buildFromAdjMatrix(const std::vector<std::vector<int>>& matrix) {
        int n = matrix.size();
        V = n;
        adj.assign(V, {});

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < matrix[i].size(); j++) {
                if (matrix[i][j]) {
                    adj[i].push_back(j);
                    if (!directed && i != j)
                        adj[j].push_back(i);
                }
            }
        }
    }

    void buildFromAdjList(const std::vector<std::vector<int>>& adjacency) {
        V = adjacency.size();
        adj = adjacency;
    }

    /* ================= GRAPH INFO ================= */

    int degree(int u) const {
        if (u >= V)
            throw std::out_of_range("Vertex index out of range");
        return adj[u].size();
    }

    bool hasEdge(int u, int v) const {
        if (u >= V || v >= V)
            throw std::out_of_range("Vertex index out of range");

        return std::find(adj[u].begin(), adj[u].end(), v) != adj[u].end();
    }

    /* ================= DEBUG ================= */

    void printGraph() const {
        for (int i = 0; i < V; i++) {
            std::cout << i << " : ";
            for (int v : adj[i]) {
                std::cout << v << " ";
            }
            std::cout << "\n";
        }
    }
};


/*
    WeightedGraph
*/
class WeightedGraph : public Graph {
private:
    std::vector<std::vector<std::pair<int,double>>> wadj;

public:
    WeightedGraph() : Graph() {}

    WeightedGraph(int vertices, bool isDirected = false)
        : Graph(vertices, isDirected) {
        wadj.resize(vertices);
    }

    void addEdge(int u, int v, double w) {
        if (u >= vertices() || v >= vertices())
            throw std::out_of_range("Vertex index out of range");

        wadj[u].push_back({v, w});
        if (!isDirected())
            wadj[v].push_back({u, w});
    }

    void addEdges(const std::vector<std::tuple<int,int,double>>& edges) {
        for (auto& [u, v, w] : edges)
            addEdge(u, v, w);
    }

    const std::vector<std::vector<std::pair<int,double>>>& getWeightedAdj() const {
        return wadj;
    }

    void printWeightedGraph() const {
        for (int i = 0; i < wadj.size(); i++) {
            std::cout << i << " : ";
            for (auto& [v, w] : wadj[i]) {
                std::cout << "(" << v << ", w=" << w << ") ";
            }
            std::cout << "\n";
        }
    }
};