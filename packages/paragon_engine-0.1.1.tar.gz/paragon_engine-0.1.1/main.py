from paragon import Graph
from paragon.algorithms import parallel_dfs
from paragon.algorithms import parallel_bfs
from paragon.algorithms import parallel_connected_components
from paragon.algorithms import pagerank
from paragon.algorithms import pagerank_bfs
from paragon.algorithms import parallel_dijkstra
from paragon import WeightedGraph
from paragon.algorithms import parallel_triangle_count

g = Graph(5)
g.add_edges([(0, 1), (1, 2), (2, 3), (3, 4), (4, 0)])
visited = parallel_dfs(g, 0)
print("Visited nodes:", visited)

components = parallel_connected_components(g, 8)
print("Connected components:", components)

distances = parallel_bfs(g, 0)
print("Shortest distances:", distances)

rank = pagerank(g)
print("PageRank scores:", rank)

rank_bfs = pagerank_bfs(g)
print("PageRank scores (BFS):", rank_bfs)

wg = WeightedGraph(5)
wg.add_edges([(0, 1, 2), (1, 2, 3), (2, 3, 4), (3, 4, 5), (4, 0, 1)])

d = parallel_dijkstra(wg, 1)
print("Shortest paths from node 1:", d)


t = parallel_triangle_count(g)
print("Number of triangles in the graph:", t)