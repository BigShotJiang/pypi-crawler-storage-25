"""Sets of helper functions for BaseDiscretizer JSON serialization"""

import copy
from json import dumps, loads
from typing import Any

import numpy as np

from AutoCarver.config import Constants
from AutoCarver.features.utils.grouped_list import GroupedList


def convert_value_to_base_type(value: Any) -> str | float | int:
    """Converts a value to python's base types (str, int, float) for JSON serialization.

    Parameters
    ----------
    value : Any
        A value to serialize

    Returns
    -------
    Union[str, float, int]
        Serialized value
    """

    output = value  # str/float/int value
    if not isinstance(value, str) and not np.isfinite(value):  # numpy.inf value
        output = Constants.INF
    elif isinstance(value, np.integer):  # np.int value
        output = int(value)
    elif isinstance(value, np.floating):  # np.float value
        output = float(value)

    return output


def convert_value_to_numpy_type(value: str | float | int) -> Any:
    """Converts a list or a dict of lists values to numpy types for JSON deserialization.

    Parameters
    ----------
    value : Union[str, float, int]
        A value to deserialize

    Returns
    -------
    Any
        Deserialized value
    """
    output = value  # str/float/int value
    if value == Constants.INF:  # numpy.inf value
        output = np.inf

    return output


def convert_values_to_base_types(
    iterable: list[Any] | dict[str, list[Any]],
) -> list[str | int | float] | dict[str | int | float, Any] | None:
    """Converts a list or a dict of lists values to python's base types (str, int, float)
    for JSON serialization.

    Parameters
    ----------
    iterable : Union[list[Any], dict[str, list[Any]]]
        List or dict of lists of values to serialize

    Returns
    -------
    Union[list[Union[str, int, float]], dict[str, list[Union[str, int, float]]]]
        List or dict of lists of values serialized
    """
    # list input (GroupedList is iterable as a leader list — treat it like one)
    output = None
    if isinstance(iterable, list) or isinstance(iterable, GroupedList):
        output = [convert_value_to_base_type(value) for value in iterable]
    # dict input
    elif isinstance(iterable, dict):
        output = {
            convert_value_to_base_type(key): convert_values_to_base_types(values) for key, values in iterable.items()
        }

    return output


def convert_values_to_numpy_types(
    iterable: list[str | int | float] | dict[str, list[str | int | float]],
) -> list[Any] | dict[Any, Any] | None:
    """Converts a list or a dict of lists values to numpy types for JSON deserialization.

    Parameters
    ----------
    iterable : Union[list[Union[str, int, float]], dict[str, list[Union[str, int, float]]]]
        List or dict of lists of values to deserialize

    Returns
    -------
    Union[list[Any], dict[str, list[Any]]]
        List or dict of lists of values deserialized
    """
    # list input (GroupedList is iterable as a leader list — treat it like one)
    output = None
    if isinstance(iterable, list) or isinstance(iterable, GroupedList):
        output = [convert_value_to_numpy_type(value) for value in iterable]
    # dict input
    elif isinstance(iterable, dict):
        output = {
            convert_value_to_numpy_type(key): convert_values_to_numpy_types(values) for key, values in iterable.items()
        }

    return output


def json_serialize_feature(feature: dict[Any, Any]) -> dict[Any, Any]:
    """JSON serializes a feature's dict"""

    # serializing values
    values = feature.get("values")
    feature.update({"values": convert_values_to_base_types(values)})

    # serializing content
    content = feature.get("content")
    feature.update({"content": dumps(convert_values_to_base_types(content))})

    return feature


def json_serialize_combination(combination: dict[Any, Any]) -> dict[Any, Any]:
    """JSON serializes a combination

    Parameters
    ----------
    combination : dict[Any, Any]
        combination to serialize

    Returns
    -------
    dict[Any, Any]
        JSON serialized combination
    """

    # converting combination to a json
    json_serialized_combination = copy.deepcopy(combination)

    # converting combination values to a json
    json_serialized_combination.update(
        {
            "combination": [
                [convert_value_to_base_type(value) for value in modality]
                for modality in json_serialized_combination["combination"]
            ]
        }
    )

    return json_serialized_combination


def json_deserialize_content(json_serialized_feature: dict) -> GroupedList | None:
    """JSON deserializes a content

    Parameters
    ----------
    json_serialized_content : str
        JSON serialized content

    Returns
    -------
    GroupedList
        content deserialized
    """

    # reading values and content from json
    values = json_serialized_feature.get("values")
    content = json_serialized_feature.get("content")

    # converting to numpy types
    values = convert_values_to_numpy_types(values)
    content = convert_values_to_numpy_types(loads(content))  # type: ignore

    # cehcking for values
    if values is not None:
        # fixing json dumping with string keys
        for value in values:
            content_key = value

            # float and int dict keys (converted in string by json.dumps)
            if not isinstance(value, str) and np.isfinite(value):
                content_key = str(value)

            # updating
            content.update({value: content.pop(content_key)})  # type: ignore

        # converting to grouped list
        return GroupedList(content)
