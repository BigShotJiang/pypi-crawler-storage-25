"""MLflow tracing integration for flowra via span-hooks.

Uses ``mlflow.start_span_no_context()`` for manual span creation combined with
``FlowingRegistry`` for parent-child tracking and external context sync.
MLflow's ``set_span_in_context``/``detach_span_from_context`` are managed
automatically by the FlowingVar's on_enter/on_exit callbacks, keeping
the MLflow context stack in sync with flowing context switches.

Automatically integrates with external MLflow context: if a span was created
with ``mlflow.start_span()`` or ``@mlflow.trace`` before calling flowra,
flowra's spans become children of the external span.

Usage::

    from flowra.agent import AgentRuntime
    from flowra.ext.mlflow import MLFLOW_TRACING

    runtime = AgentRuntime(agents={...}, services={...})
    MLFLOW_TRACING.install(runtime, experiment_name="my-experiment")
"""

import json
from collections.abc import Callable
from typing import Any

import mlflow
from mlflow.entities.span import LiveSpan
from mlflow.tracing.provider import detach_span_from_context, set_span_in_context

from ..agent import AbstractAgent, AgentRuntime, AgentSpan, Event, FlowingVar, SpanExitHandler, StepSpan
from ..lib.observability import LLMCallSpan, ToolCallSpan
from ..llm import (
    AssistantMessage,
    LLMRequest,
    MediaBlock,
    Message,
    SystemMessage,
    TextBlock,
    ThinkingBlock,
    ToolResultBlock,
    ToolUseBlock,
    UserMessage,
)

__all__ = ["MLFLOW_TRACING"]


def _on_mlflow_span_enter(span: LiveSpan | None) -> Any:
    if span is not None:
        return set_span_in_context(span)
    return None


def _on_mlflow_span_exit(token: Any) -> None:
    if token is not None:
        detach_span_from_context(token)


def _resolve_experiment_id(experiment_name: str) -> str:
    client = mlflow.MlflowClient()
    experiment = client.get_experiment_by_name(experiment_name)
    return client.create_experiment(experiment_name) if experiment is None else experiment.experiment_id


class _MlflowTracing:
    __slots__ = ()

    @staticmethod
    def install(
        runtime: AgentRuntime,
        *,
        experiment_name: str | None = None,
        session_id: str | Callable[[], str | None] | None = None,
        trace_agents: bool = True,
        trace_steps: bool = False,
        trace_llm_calls: bool = True,
        trace_tool_calls: bool = True,
        during: str | type[AbstractAgent] | None = None,
    ) -> None:
        """Install MLflow tracing span-hooks on a runtime.

        Args:
            runtime: AgentRuntime to install tracing on.
            experiment_name: MLflow experiment name (created if missing). When ``None``,
                flowra does not create an experiment — use this when flowra spans are
                always children of externally created MLflow spans.
            session_id: Session ID for grouping traces (multi-turn chat).
            trace_agents: Trace agent lifecycle (AgentSpan).
            trace_steps: Trace individual step invocations (StepSpan). Disabled by default.
            trace_llm_calls: Trace LLM calls (LLMCallSpan).
            trace_tool_calls: Trace tool calls (ToolCallSpan).
            during: Restrict tracing to spans emitted while the given agent is on the
                call stack. Accepts an agent path (``str``) or agent type
                (``type[AbstractAgent]``); matches the semantics of
                ``hooks.on_span(..., during=...)``. ``None`` traces every span.
        """
        flowing = runtime.flowing
        hooks = runtime.hooks

        # Lazy experiment resolution — only needed if flowra creates root spans
        resolved_id: list[str | None] = [None]
        resolved_flag = [experiment_name is None]

        def get_experiment_id() -> str | None:
            if not resolved_flag[0]:
                assert experiment_name is not None
                resolved_id[0] = _resolve_experiment_id(experiment_name)
                resolved_flag[0] = True
            return resolved_id[0]

        mlflow_parent: FlowingVar[LiveSpan | None] = flowing.create_var(
            default=None,
            on_enter=_on_mlflow_span_enter,
            on_exit=_on_mlflow_span_exit,
        )

        if trace_agents:
            hooks.on_span(AgentSpan, _make_agent_handler(mlflow_parent, get_experiment_id, session_id), during=during)
        if trace_steps:
            hooks.on_span(StepSpan, _make_step_handler(mlflow_parent, get_experiment_id, session_id), during=during)
        if trace_llm_calls:
            hooks.on_span(LLMCallSpan, _make_llm_handler(mlflow_parent), during=during)
        if trace_tool_calls:
            hooks.on_span(ToolCallSpan, _make_tool_handler(mlflow_parent), during=during)


MLFLOW_TRACING = _MlflowTracing()


# -- Span handlers --


def _resolve_session_id(session_id: str | Callable[[], str | None] | None) -> str | None:
    if session_id is None:
        return None
    if callable(session_id):
        return session_id()
    return session_id


def _preview(obj: Any) -> str:
    """Use __preview__() if available, otherwise str()."""
    fn = getattr(obj, "__preview__", None)
    return fn() if fn is not None else str(obj)


def _root_metadata(session_id: str | Callable[[], str | None] | None) -> dict[str, str] | None:
    sid = _resolve_session_id(session_id)
    if sid is None:
        return None
    return {"mlflow.trace.session": sid}


def _make_agent_handler(
    mlflow_parent: FlowingVar[LiveSpan | None],
    get_experiment_id: Callable[[], str | None],
    session_id: str | Callable[[], str | None] | None,
) -> Callable[[Event[AgentSpan]], SpanExitHandler | None]:
    def on_enter(event: Event[AgentSpan]) -> SpanExitHandler:
        span = event.data
        # Check internal flowra context first, then external MLflow context
        parent = mlflow_parent.get()
        if parent is None:
            parent = mlflow.get_current_active_span()
        is_root = parent is None

        inputs: dict[str, Any] = {}
        if span.spec is not None:
            inputs["spec"] = _preview(span.spec)
        if span.is_resume:
            inputs["is_resume"] = True

        mlflow_span = mlflow.start_span_no_context(
            name=span.agent_info.path,
            span_type="AGENT",
            parent_span=parent,
            inputs=inputs or None,
            experiment_id=get_experiment_id() if is_root else None,
            metadata=_root_metadata(session_id) if is_root else None,
        )

        # FlowingVar on_enter callback handles set_span_in_context automatically
        mlflow_parent.set(mlflow_span)

        if is_root and span.spec is not None:
            mlflow.update_current_trace(request_preview=_preview(span.spec))

        def on_exit(error: BaseException | None = None) -> None:
            outputs: dict[str, Any] = {}
            if span.result is not None:
                result_preview = _preview(span.result)
                outputs["result"] = result_preview
                if is_root:
                    mlflow.update_current_trace(response_preview=result_preview)
            if error is not None:
                outputs["error"] = str(error)
            if outputs:
                mlflow_span.set_outputs(outputs)
            # No detach_span_from_context — FlowingRegistry handles it on restore
            mlflow_span.end()

        return on_exit

    return on_enter


def _make_step_handler(
    mlflow_parent: FlowingVar[LiveSpan | None],
    get_experiment_id: Callable[[], str | None],
    session_id: str | Callable[[], str | None] | None,
) -> Callable[[Event[StepSpan]], SpanExitHandler | None]:
    def on_enter(event: Event[StepSpan]) -> SpanExitHandler:
        span = event.data
        # Check internal flowra context first, then external MLflow context
        parent = mlflow_parent.get()
        if parent is None:
            parent = mlflow.get_current_active_span()
        is_root = parent is None
        mlflow_span = mlflow.start_span_no_context(
            name=span.step if not is_root else f"{span.agent_info.path}:{span.step}",
            span_type="CHAIN",
            parent_span=parent,
            inputs={"step": span.step, **({"spec": _preview(span.spec)} if span.spec is not None else {})},
            experiment_id=get_experiment_id() if is_root else None,
            metadata=_root_metadata(session_id) if is_root else None,
        )

        # FlowingVar on_enter callback handles set_span_in_context automatically
        mlflow_parent.set(mlflow_span)

        def on_exit(error: BaseException | None = None) -> None:
            outputs: dict[str, Any] = {}
            if span.result is not None:
                outputs["result"] = _preview(span.result)
            if error is not None:
                outputs["error"] = str(error)
            if outputs:
                mlflow_span.set_outputs(outputs)
            # No detach_span_from_context — FlowingRegistry handles it on restore
            mlflow_span.end()

        return on_exit

    return on_enter


def _make_llm_handler(
    mlflow_parent: FlowingVar[LiveSpan | None],
) -> Callable[[Event[LLMCallSpan]], SpanExitHandler | None]:
    def on_enter(event: Event[LLMCallSpan]) -> SpanExitHandler | None:
        span = event.data
        # Check internal flowra context first, then external MLflow context
        parent = mlflow_parent.get()
        if parent is None:
            parent = mlflow.get_current_active_span()
        if parent is None:
            return None

        model_short = span.request.model.split("/")[-1]
        inputs = _format_chat_inputs(span.request)

        attributes: dict[str, str] = {
            "mlflow.message.format": "openai",
            "mlflow.llm.model": span.request.model,
        }

        mlflow_span = mlflow.start_span_no_context(
            name=f"llm_call ({model_short})",
            span_type="CHAT_MODEL",
            parent_span=parent,
            inputs=inputs,
            attributes=attributes,
        )

        if span.request.tools:
            mlflow_span.set_attribute(
                "mlflow.chat.tools",
                [
                    {
                        "type": "function",
                        "function": {
                            "name": t.name,
                            "description": t.description,
                            **({"parameters": t.input_schema} if t.input_schema else {}),
                        },
                    }
                    for t in span.request.tools
                ],
            )

        # LLM/tool spans manage MLflow context manually (within a single scope)
        context_token = set_span_in_context(mlflow_span)

        def on_exit(error: BaseException | None = None) -> None:
            detach_span_from_context(context_token)
            if span.response is not None:
                mlflow_span.set_outputs(_format_chat_outputs(span))
                mlflow_span.set_attributes(_format_chat_attributes(span))
            elif error is not None:
                mlflow_span.set_outputs({"error": str(error)})
            mlflow_span.end()

        return on_exit

    return on_enter


def _make_tool_handler(
    mlflow_parent: FlowingVar[LiveSpan | None],
) -> Callable[[Event[ToolCallSpan]], SpanExitHandler | None]:
    def on_enter(event: Event[ToolCallSpan]) -> SpanExitHandler | None:
        span = event.data
        # Check internal flowra context first, then external MLflow context
        parent = mlflow_parent.get()
        if parent is None:
            parent = mlflow.get_current_active_span()
        if parent is None:
            return None

        mlflow_span = mlflow.start_span_no_context(
            name=f"tool:{span.tool_use.name}",
            span_type="TOOL",
            parent_span=parent,
            inputs={"tool_name": span.tool_use.name, "input": span.tool_use.input},
        )

        # LLM/tool spans manage MLflow context manually (within a single scope)
        context_token = set_span_in_context(mlflow_span)

        def on_exit(error: BaseException | None = None) -> None:
            detach_span_from_context(context_token)
            outputs: dict[str, Any] = {}
            if span.result is not None:
                try:
                    outputs["content"] = json.loads(span.result.content)
                except (json.JSONDecodeError, TypeError):
                    outputs["content"] = span.result.content
                outputs["is_error"] = span.result.is_error
            if span.error_kind is not None:
                outputs["error_kind"] = str(span.error_kind)
            if error is not None:
                outputs["error"] = str(error)
            if outputs:
                mlflow_span.set_outputs(outputs)
            mlflow_span.end()

        return on_exit

    return on_enter


# -- Chat formatting (OpenAI-compatible for MLflow UI) --


def _format_chat_inputs(req: LLMRequest) -> dict[str, Any]:
    inputs: dict[str, Any] = {"model": req.model}
    if req.temperature is not None:
        inputs["temperature"] = req.temperature
    if req.top_p is not None:
        inputs["top_p"] = req.top_p
    if req.max_tokens is not None:
        inputs["max_tokens"] = req.max_tokens
    for ns, ns_config in req.extra.items():
        if isinstance(ns_config, dict):
            for key, val in ns_config.items():
                inputs[f"{ns}.{key}"] = val

    messages: list[dict[str, Any]] = []
    for msg in req.system:
        messages.extend(_message_to_openai(msg))
    for msg in req.messages:
        messages.extend(_message_to_openai(msg))
    inputs["messages"] = messages
    return inputs


def _format_chat_outputs(span: LLMCallSpan) -> dict[str, Any]:
    resp = span.response
    assert resp is not None

    output_messages: list[dict[str, Any]] = []
    for msg in resp.messages:
        output_messages.extend(_message_to_openai(msg))

    assistant_msg = _assistant_message_to_openai(resp.message)
    stop_reason_map = {"end_turn": "stop", "tool_use": "tool_calls", "max_tokens": "length"}
    finish_reason = stop_reason_map.get(str(resp.stop_reason), str(resp.stop_reason))

    outputs: dict[str, Any] = {
        "choices": [{"index": 0, "message": assistant_msg, "finish_reason": finish_reason}],
        "model": span.request.model,
    }
    if len(output_messages) > 1:
        outputs["messages"] = output_messages
    if resp.usage:
        outputs["usage"] = {
            "prompt_tokens": resp.usage.input_tokens,
            "completion_tokens": resp.usage.output_tokens,
            "total_tokens": resp.usage.input_tokens
            + resp.usage.cache_read_input_tokens
            + resp.usage.cache_creation_input_tokens
            + resp.usage.output_tokens,
        }
    return outputs


def _format_chat_attributes(span: LLMCallSpan) -> dict[str, Any]:
    resp = span.response
    assert resp is not None
    attributes: dict[str, Any] = {}
    if resp.usage:
        token_usage: dict[str, int] = {
            "input_tokens": resp.usage.input_tokens,
            "output_tokens": resp.usage.output_tokens,
            "total_tokens": resp.usage.input_tokens
            + resp.usage.cache_read_input_tokens
            + resp.usage.cache_creation_input_tokens
            + resp.usage.output_tokens,
        }
        if resp.usage.cache_read_input_tokens:
            token_usage["cache_read_input_tokens"] = resp.usage.cache_read_input_tokens
        if resp.usage.cache_creation_input_tokens:
            token_usage["cache_creation_input_tokens"] = resp.usage.cache_creation_input_tokens
        attributes["mlflow.chat.tokenUsage"] = token_usage
        if resp.usage.cost is not None:
            cost = resp.usage.cost
            attributes["mlflow.llm.cost"] = {
                "input_cost": cost.input + cost.cache_read + cost.cache_creation,
                "output_cost": cost.output,
                "total_cost": cost.total,
            }
        elif resp.usage.cost_usd is not None:
            attributes["mlflow.llm.cost"] = {"total_cost": resp.usage.cost_usd}
    return attributes


# -- Message conversion to OpenAI format --


def _message_to_openai(msg: Message) -> list[dict[str, Any]]:
    match msg:
        case SystemMessage():
            return [_system_message_to_openai(msg)]
        case UserMessage():
            return _user_message_to_openai(msg)
        case AssistantMessage():
            return [_assistant_message_to_openai(msg)]


def _system_message_to_openai(msg: SystemMessage) -> dict[str, Any]:
    texts = [b.text for b in msg.blocks]
    return {"role": "system", "content": "\n".join(texts)}


def _user_message_to_openai(msg: UserMessage) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    text_parts: list[str] = []
    for block in msg.blocks:
        match block:
            case TextBlock(text=text):
                text_parts.append(text)
            case ToolResultBlock(tool_use_id=tool_use_id, content=content):
                if text_parts:
                    result.append({"role": "user", "content": "\n".join(text_parts)})
                    text_parts = []
                result.append(
                    {
                        "role": "tool",
                        "content": content,
                        "tool_call_id": tool_use_id,
                    }
                )
            case MediaBlock():
                text_parts.append("[image]")
    if text_parts:
        result.append({"role": "user", "content": "\n".join(text_parts)})
    return result or [{"role": "user", "content": ""}]


def _assistant_message_to_openai(msg: AssistantMessage) -> dict[str, Any]:
    text_parts: list[str] = []
    tool_calls: list[dict[str, Any]] = []
    reasoning: str | None = None

    for block in msg.blocks:
        match block:
            case TextBlock(text=text):
                text_parts.append(text)
            case ToolUseBlock(id=id_, name=name, input=input_):
                tool_calls.append(
                    {
                        "id": id_,
                        "type": "function",
                        "function": {
                            "name": name,
                            "arguments": json.dumps(input_),
                        },
                    }
                )
            case ThinkingBlock(text=text):
                reasoning = text

    result: dict[str, Any] = {"role": "assistant"}
    if text_parts:
        result["content"] = "\n".join(text_parts)
    if tool_calls:
        result["tool_calls"] = tool_calls
    if reasoning:
        result["reasoning"] = reasoning
    return result
