# Changelog

## 0.5.0 - 2026-04-10

- Added `TextPrompt`, scheduled `--prompt <text@frame_id>` parsing, and updated local/gRPC SAM3 text-propagation examples to drive `SAM3TextPropagation` through a runtime `text_prompt` port instead of constructor hparams.
- Added SAM3 prompt-free segment-everything tooling: `SAM3SegmentEverything`, local CLI wiring, and CU3S/video pipeline YAMLs for per-frame automatic mask generation with overlay/video/JSON outputs.
- Added runtime SAM3 bbox propagation tooling: `BBoxPrompt`, local/gRPC bbox-propagation examples, and CU3S/video bbox-propagation pipeline YAMLs using scheduled `--prompt <object_id:detection_id@frame_id>` bbox updates from detection JSON.
- Added runtime SAM3 mask propagation tooling: `MaskPrompt`, local/gRPC mask-propagation examples, and CU3S/video mask-propagation pipeline YAMLs using scheduled `--prompt <object_id:detection_id@frame_id>` mask updates from detection JSON.
- Added SAM3 text-propagation pipeline configs and a new gRPC client (`examples/grpc/sam3/sam3_text_propagation_client.py`) supporting CU3S/video inputs plus plugin-manifest bootstrap.
- Added SAM3 tracking workflow updates across propagation scripts and examples, including batch processing for full-folder video runs, per-node profiling, threshold/name-suffix options, and frame-lookup support in `TrackingResultsReader`.
- Added `NDVISelector` for normalized-difference vegetation index band selection, `ScalarHSVColormapNode` for scalar-to-HSV colormap rendering, and `DetectionCocoJsonNode` for streaming COCO detection JSON output.
- Added per-frame `PCA` dimensionality reduction node alongside the existing trainable variant.
- Added Spectral Angle Mapper (SPAM) pipeline nodes and tooling for spectral-angle-based workflows.
- Added `BBoxSpectralExtractor`, sparkline visualization helpers, and richer `BBoxesOverlayNode` annotations (`draw_labels`, `frame_id`).
- Added occlusion and Poisson inpainting utilities with tests and object-tracking example integrations.
- Added ByteTrack and tracker workflow expansion: spectral-aware association, COCO JSON sinks, threshold/JSON sweep tooling, spectral re-ID validation, RT-DETR/YOLO integration points, and overlay/transcoding helpers for rendered tracking outputs.
- Added DeepEIOU plugin integration plus related preprocessing, NumPy writer, and tracking overlay renderer updates.
- Added TrackEval preparation/evaluation tooling updates for aligned HOTA benchmarking workflows, including prediction frame-id passthrough in evaluator pipelines when supported by the metric plugin.
- Added released tracking plugin manifests for ByteTrack, DeepEIOU, TrackEval, Ultralytics, RT-DETR, and a `cuvis_ai_builtin` manifest.
- Added blood perfusion tutorial (`docs/tutorials/blood-perfusion.md`) and four example scripts under `examples/blood_perfusion/` covering NDVI, PCA, and PCA-HSV visualizations.
- Added plugin node catalog documentation page listing all available plugin nodes.
- Added ~41 new test files covering PCA, NDVI, colormap, text prompt, manifest sync, spectral extractor, occlusion, video, tracking overlay, and more.
- Changed tracking JSON export so `CocoTrackMaskWriter` can consume optional `category_ids` and `category_semantics` inputs, preserving the old single-category behavior when they are absent and writing multi-category `categories` headers when they are present.
- Changed local SAM3 bbox propagation from the archived `--detection` single-seed flow to the same scheduled prompt contract used by mask propagation, including optional bbox prompt debug overlays.
- Changed local SAM3 mask propagation from archived PNG prompts to detection-JSON-driven label-map prompting, and clarified that gRPC mask propagation sends masks directly through `InputBatch.mask`.
- Renamed `CocoTrackMaskWriter(category_name=...)` to `CocoTrackMaskWriter(default_category_name=...)`, changed the default fallback label to `"object"`, and clarified that this constructor value is only the fallback label when `category_semantics` is absent.
- Refactored and consolidated video/tracking utilities (including `cuvis_ai/node/video.py`), moved SAM3 examples into a dedicated subdirectory, and adopted shorthand port syntax across updated examples.
- Refactored shared XML plugin helpers into `cuvis_ai/utils/xml_plugin_parser.py`.
- Refactored prompt specs, parsers, and frame-hw resolution to deduplicate shared logic across text/bbox/mask propagation modes.
- Reorganized AdaCLIP gRPC examples under `examples/grpc/adaclip/` and updated gRPC workflow/docs utilities around explicit config resolution and session search paths.
- Refined tracking output tooling with JSON IO/overlay updates, new CLI output-dir helpers, and expanded tracking regression tests.
- Updated SAM3 text-propagation pipeline YAMLs and example docs to match runtime text prompting plus category-aware tracking JSON output.
- Updated ByteTrack and tracking documentation, including multi-pipeline usage and FFmpeg/torchcodec setup guidance.
- Updated plugin/trainrun configs to match current SAM3 and channel-selector runtime paths.
- Updated SAM3 plugin to v0.1.3 and switched AdaCLIP plugin to released repository.
- Updated docs: removed 7 redundant pages and cleaned up stale references across the documentation site.
- Bumped cuvis-ai-schemas to >=0.3.0 and cuvis-ai-core to >=0.3.4.
- Consolidated `json_reader` and `json_writer` modules into a single `json_file` module; updated all node registrations, pipeline configs, imports, and documentation.
- Switched from `opencv-python` to `opencv-python-headless`.
- Fixed SAM3 batch-runner control flow and mask-overlay color handling.
- Fixed JSON reader robustness and pre-push regressions in manifest sync, CLI commands, and statistical-contract tests.
- Fixed video/tracking fallback and output handling: `VideoIterator` now falls back to OpenCV when torchcodec is unavailable, `output_video_path` naming is normalized, and ByteTrack JSON output path heuristics were hardened.

## 0.4.0 - 2026-02-27

- Added reusable `WelfordAccumulator` utility (`cuvis_ai.utils.welford`) for streaming mean/variance/covariance
- Added `resolve_reduce_dims()` as shared module-level utility in `binary_decider`
- Added `TRAINABLE_BUFFERS` class attribute — 5 nodes declare trainable buffers, base class handles buffer↔parameter conversion in freeze/unfreeze automatically
- Added `freeze()` for `LearnableChannelMixer` matching existing `unfreeze()` override
- Added `ConcreteChannelMixer` and `LearnableChannelMixer` exported from `cuvis_ai.node`
- Added all 6 visualization nodes exported from `cuvis_ai.node`: `AnomalyMask`, `RGBAnomalyMask`, `ScoreHeatmapVisualizer`, `CubeRGBVisualizer`, `PCAVisualization`, `PipelineComparisonVisualizer`
- Added insufficient-samples guard to `RXGlobal` and `ScoreToLogit` — raises early when training data has too few samples
- Added plugin runtime smoke CI workflow (`plugin-runtime-smoke.yml`) with slow plugin tests
- Added AdaCLIP standalone plugin manifest (`configs/plugins/adaclip.yaml`) and 6 example scripts
- Added plugin contract, manifest sync, and runtime smoke test files
- Added 8 new test files: `test_welford`, `test_freeze_unfreeze`, `test_channel_selector_coverage`, `test_concrete_channel_mixer`, `test_pipeline_visualization`, `test_binary_decider`, `test_data_node`, `test_rx_per_batch`
- Added pytest markers (`unit`/`integration`/`slow`) on all 30 test files; session-scoped fixtures for expensive operations; pytest config consolidated in `pytest.ini`
- Added SAM3 plugin integration scaffolding with plugin registry, pipeline configs, and example manifests
- Added CU3S video data support with restructured data nodes and CU3SDataNode
- Added RangeAverageFalseRGBSelector for wavelength-range-averaged false RGB
- Added CIETristimulusFalseRGBSelector using CIE 1931 2-degree observer color matching functions
- Added CameraEmulationFalseRGBSelector using Gaussian spectral response curves
- Added NormMode enum and unified percentile-based RGB normalization in ChannelSelectorBase (per_frame/running/statistical with warmup+accumulation)
- Added sRGB gamma, _compute_raw_rgb() hook, and statistical_initialization() to ChannelSelectorBase
- Added LearnableChannelMixer weights output port for loss/viz consumption
- Added ForegroundContrastLoss with OKLab color space and anchor_weight anti-gaming penalty
- Added OKLab perceptual color space utilities (rgb_to_oklab, linear_rgb_to_oklab, srgb_to_linear)
- Added ImageArtifactVizBase, ChannelSelectorFalseRGBViz, and ChannelWeightsViz visualization nodes
- Added MaskOverlayNode and create_mask_overlay shared PyTorch utility
- Added TrackingOverlayNode for per-object colored mask overlays with contour lines and ID labels
- Added multi-object overlay rendering utilities (render_multi_object_overlay)
- Added TrackingCocoJsonNode for streaming COCO instance-segmentation JSON with RLE masks and atomic writes
- Added ToVideoNode for streaming RGB frames to MP4 via OpenCV
- Added channel selector false RGB experiment with Hydra configs, inspect mode, and training pipeline
- Added sam3_hsi_tracker.py end-to-end SAM3 tracking example using CIE false RGB and core Predictor
- Added SAM3 pipeline configs: naive false RGB, learned projection, and spectral signature extraction
- Added mesu_index passthrough in CU3SDataNode and ChannelSelectorFalseRGBViz for frame tracking
- Added LR scheduling (reduce_on_plateau) wired to GradientTrainer
- Added unit tests for data, video, band selection, tracking COCO JSON, and tracking overlay nodes
- Changed RXGlobal, ScoreToLogit, LADGlobal to use `WelfordAccumulator` instead of inline Welford implementations
- Changed `_compute_band_correlation_matrix` to single-pass streaming with `WelfordAccumulator`
- Changed TrainablePCA and LearnableChannelMixer to use streaming covariance + `eigh` instead of concat + SVD
- Changed SoftChannelSelector variance init to use streaming `WelfordAccumulator`
- Changed ZScoreNormalizerGlobal to use streaming `WelfordAccumulator` instead of concat + subsample
- Changed supervised band selectors to use template method pattern
- Changed YAML configs and docs to use new schema field names (`hparams`, `class_name`)
- Changed LearnableChannelMixer output normalization from per-image min-max to BatchNorm2d + sigmoid
- Changed channel selector training config to max_epochs=200 with early stopping and LR scheduling
- Changed ForegroundContrastLoss to vectorized batch computation (no per-sample loop)
- Changed export_cu3s_false_rgb_video.py from argparse to Click CLI and DataLoader to core Predictor
- Changed plugin registry to use relative path for SAM3 and AdaCLIP repo tag v0.1.2
- **Breaking**: Reorganized channel selector and mixer nodes into separate files
- **Breaking**: Renamed 9 classes to reflect selector/mixer distinction
- **Breaking**: Deleted old files — no deprecation stubs or re-exports
- Removed redundant `.to(device)` calls — pipeline handles device placement
- Updated 13 pipeline + 17 trainrun YAML configs with new `class_name` paths
- Updated 11 example scripts with new import paths
- Updated 19 documentation files with new class names and import paths
- Fixed `pyproject.toml` uv source field (`develop` to `editable`)
- Fixed Werkzeug CVE-2026-27199 by bumping 3.1.5 → 3.1.6
- Fixed ToVideoNode parameter typo: output__video_path renamed to output_video_path
- Fixed setuptools<82 pin for tensorboard pkg_resources compatibility
- Fixed Windows uv script path errors by using python -m in hooks and tests
- Fixed CU3SDataNode cube input spec to use torch.Tensor dtype
- Expanded training data splits in tracking_cap_and_car.yaml
- Pinned cuvis-ai-schemas to git main branch
- Removed examples/adaclip/plugins.yaml (consolidated into central registry)
- Removed Phase 1 scaffold files (sam3_example.md, sam3_tracking_example.py)

## 0.3.0 - 2026-02-11

- Fixed README documentation links to use docs.cuvis.ai with correct version prefix
- Fixed Pillow CVE-2026-25990 by bumping 12.1.0 to 12.1.1
- Added comprehensive documentation site with tutorials, API reference, and node catalog
- Added MkDocs Material theme with dark mode and versioned deployment via mike
- Added AnomalyPixelStatisticsMetric node replacing duplicate SampleCustomMetrics
- Added deep_svdd_factory utility module with ChannelConfig dataclass
- Added central plugin registry at configs/plugins/registry.yaml
- Added statistical-only training config (default_statistical.yaml)
- Added CI/CD pipeline with test, lint, security, and typecheck jobs
- Added PyPI release workflow with TestPyPI verification and docs deployment
- Added Dependabot configuration for GitHub Actions and pip dependencies
- Added automated test data downloader script with CLI entry point
- Added documentation test suite for link checking and code example validation
- Added Git hooks for ruff format and module case checking
- Added Apache-2.0 LICENSE file
- Changed TrainablePCA to require num_channels parameter (breaking)
- Changed type imports to use cuvis-ai-schemas package
- Changed RXLogitHead to ScoreToLogit and moved to cuvis_ai.node.conversion
- Changed BaseDecider import to BinaryDecider in deciders module
- Changed trainrun config into separate statistical and gradient variants
- Changed pyproject.toml for PyPI compliance and updated tooling configs
- Changed dependencies to add cuvis-ai-schemas and loosen cuvis version pin
- Changed restore-pipeline/restore-trainrun entry points to use cuvis_ai_core
- Improved README and CONTRIBUTING.md with plugin contribution workflow
- Improved docstring coverage to 95%+ across all public APIs
- Fixed LAD detector reset() initializing buffers with wrong shapes
- Fixed LAD detector unfreeze() losing device when converting buffers
- Fixed TrainablePCA with proper num_channels parameter and buffer shapes
- Fixed node import paths for cuvis-ai-schemas migration
- Fixed config references for trainrun and ScoreToLogit rename
- Fixed documentation links, module references, and placeholder content
- Fixed MkDocs build warnings and docstring formatting
- Fixed package metadata for PyPI submission
- Removed restore_pipeline.md from repo root
- Removed old changelog.md replaced by CHANGELOG.md
- Removed run_tests.yml replaced by ci.yml
- Removed outdated docs pages replaced by expanded docs sections

## 0.2.3 - 2026-01-29

- Added plugin system with Git repository and local filesystem support
- Added Pydantic plugin configuration with strict validation
- Added plugin caching in ~/.cuvis_plugins/ with version verification
- Added session-scoped plugin isolation for gRPC services
- Added plugin management gRPC RPCs (LoadPlugins, ListLoadedPlugins, GetPluginInfo, ClearPluginCache)
- Added JSON transport pattern for plugin manifests
- Added test migration infrastructure with 426 tests moved to cuvis-ai-core
- Changed repository architecture to split into cuvis-ai-core and cuvis-ai
- Changed import pattern to use cuvis_ai_core for framework components
- Fixed DataLoader access violation with num_workers=0
- Fixed gRPC servers to use single-threaded mode for cuvis SDK compatibility

## 0.2.2 - 2026-01-15

- Added restoration utilities in cuvis_ai.utils.restore module
- Added CLI entry points for restore-pipeline and restore-trainrun
- Added restore_pipeline.md guide with CLI and Python API examples
- Changed restoration utilities to auto-detect statistical vs gradient workflows
- Changed Python API surface to standardized imports
- Removed duplicate example scripts replaced with library utilities

## 0.2.1 - 2026-01-08

- Added Pydantic v2 config models as single source of truth with validation
- Added server-side Hydra composition with session-scoped search paths
- Added config RPCs: ResolveConfig, ValidateConfig, GetParameterSchema, SetSessionSearchPaths
- Added explicit 4-step workflow for gRPC API
- Changed terminology from Experiment to TrainRun across configs and RPCs
- Changed gRPC service into modular components
- Changed config transport to use config_bytes with central registry
- Fixed RPC surface for new config resolution flow
- Fixed tests and examples (596 tests passing, 65% coverage)

## 0.2.0 - 2025-12-20

- Added YAML-driven pipeline configuration with OmegaConf interpolation
- Added hybrid NodeRegistry for built-ins and custom nodes
- Added end-to-end pipeline serialization with YAML structure and .pt weights
- Added version/schema compatibility guards on load
- Added gRPC canvas management and discovery RPCs
- Added pipeline path resolution helpers with CUVIS_CANVAS_DIR environment variable
- Changed gRPC API to use PipelineConfig via config_bytes
- Changed Train RPC to require DataConfig and TrainingConfig
- Changed SaveCanvas/LoadCanvas to replace SaveCheckpoint/LoadCheckpoint
- Changed node state management to standard state_dict()
- Removed custom serialize/load patterns

## 0.1.5 - 2025-12-01

- Added gRPC service stack with proto definitions
- Added Buf Schema Registry integration for cross-language codegen
- Added session management and PipelineBuilder
- Added file-based data access via DataConfig
- Added two-phase training (statistical init then gradient fine-tuning)
- Added pipeline introspection RPCs and streaming training progress
- Changed output selection to use output_specs
- Changed node naming to deterministic counter-based scheme

## 0.1.3 - 2025-11-06

- Added port-based typed I/O system with PortSpec, InputPort, OutputPort
- Added graph connection API with auto-validation
- Added multi-input/output support for nodes
- Added training integration with PyTorch Lightning
- Changed nodes to declare INPUT_SPECS/OUTPUT_SPECS with auto-created ports
- Changed executor for port-based routing and stage-aware execution
