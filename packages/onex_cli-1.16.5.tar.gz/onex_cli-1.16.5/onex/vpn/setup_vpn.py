"""
Main VPN setup orchestration
"""

import os
import time
from pathlib import Path
from typing import Dict, Optional
from .platform_detector import (
    detect_os,
    detect_environment_from_ip,
    get_gateway_ip,
    get_platform_url
)
from .wireguard_manager import (
    install_wireguard,
    parse_config,
    import_config,
    connect,
    get_status,
    verify_connectivity,
    WireGuardError
)


def setup_vpn(config_file_path: str, auto_connect: bool = True) -> Dict[str, any]:
    """
    Setup VPN from config file

    Args:
        config_file_path: Path to WireGuard config file
        auto_connect: Whether to automatically connect after setup

    Returns:
        Dict with:
            - interface: Interface name (e.g., 'wg-onex-dev')
            - vpn_ip: VPN IP address (e.g., '10.0.0.100')
            - gateway_ip: Gateway IP address (e.g., '10.0.0.1')
            - environment: Environment name ('dev', 'staging', 'prod')
            - platform_url: Platform URL (e.g., 'http://10.0.0.1:8000')
            - connected: Whether VPN is connected
            - gateway_reachable: Whether gateway is reachable

    Raises:
        WireGuardError: If setup fails
    """
    # Validate config file exists
    config_path = Path(config_file_path).expanduser().resolve()
    if not config_path.exists():
        raise WireGuardError(f"Config file not found: {config_file_path}")

    # Parse config to extract information
    config = parse_config(str(config_path))

    vpn_ip = config['vpn_ip']
    gateway_ip = get_gateway_ip(vpn_ip)
    environment = detect_environment_from_ip(vpn_ip)
    platform_url = get_platform_url(gateway_ip)

    # Generate interface name from config filename
    # Note: Interface names must be valid Linux interface names (max 15 chars - IFNAMSIZ)
    # Replace hyphens with underscores for compatibility
    config_basename = config_path.stem.replace('-', '_')  # e.g., 'alice_dev'
    interface_name = f"wg_{config_basename}"  # e.g., 'wg_test_dev' (11 chars)

    # Validate interface name length (Linux limit is 15 characters)
    if len(interface_name) > 15:
        raise WireGuardError(
            f"Interface name too long: '{interface_name}' ({len(interface_name)} chars)\n"
            f"Linux interface names must be 15 characters or less.\n"
            f"Please rename your config file to something shorter.\n"
            f"Example: {config_path.name} → test_dev.conf"
        )

    # Check if WireGuard is installed
    from .platform_detector import check_wireguard_installed
    if not check_wireguard_installed():
        # Try to install automatically
        try:
            install_wireguard()
        except WireGuardError as e:
            # Re-raise with more helpful message
            raise WireGuardError(
                f"WireGuard is not installed and automatic installation failed.\n"
                f"{str(e)}\n\n"
                f"Please install WireGuard manually and try again."
            )

    # Import config file
    import_config(str(config_path), interface_name)

    # Verify config file was created successfully
    from .platform_detector import get_config_directory
    config_dir = Path(get_config_directory())
    imported_config_path = config_dir / f"{interface_name}.conf"

    # Wait briefly for filesystem sync
    time.sleep(1)

    if not imported_config_path.exists():
        raise WireGuardError(
            f"Config file not found after import: {imported_config_path}\n"
            f"This may be a permissions issue. Try running with sudo."
        )

    # Connect if requested
    connected = False
    gateway_reachable = False
    connection_error = None

    if auto_connect:
        try:
            connect(interface_name)
            connected = True

            # Wait a moment for connection to establish
            time.sleep(2)

            # Verify connectivity
            gateway_reachable = verify_connectivity(gateway_ip)

        except WireGuardError as e:
            # Connection failed, but config is imported
            # Store error for later retry/reporting
            connection_error = str(e)
            connected = False

    # Check actual status
    status = get_status(interface_name)
    if status:
        connected = True

    return {
        'interface': interface_name,
        'vpn_ip': vpn_ip,
        'gateway_ip': gateway_ip,
        'environment': environment,
        'platform_url': platform_url,
        'connected': connected,
        'gateway_reachable': gateway_reachable,
        'config_path': str(config_path),
        'connection_error': connection_error  # Include error for retry logic
    }


def get_vpn_info(interface_name: str) -> Optional[Dict[str, any]]:
    """
    Get information about configured VPN

    Args:
        interface_name: Interface name (e.g., 'wg-onex-dev')

    Returns:
        Dict with VPN info, or None if not configured
    """
    # Try to get status
    status = get_status(interface_name)
    if not status:
        return None

    return {
        'interface': interface_name,
        'connected': status['connected'],
        'endpoint': status.get('endpoint'),
        'latest_handshake': status.get('latest_handshake'),
        'transfer': status.get('transfer', {})
    }


def list_configured_vpns() -> list:
    """
    List all configured VPN interfaces

    Returns:
        List of interface names (only valid ones <= 15 characters)
    """
    from .platform_detector import get_config_directory

    config_dir = Path(get_config_directory())
    if not config_dir.exists():
        return []

    # Find all wg_*.conf files (using underscores, which is the correct format)
    # Note: Old configs may use hyphens (wg-onex-*.conf) but these are invalid for wg-quick
    # We only look for underscore-based configs which follow Linux interface naming rules
    # IMPORTANT: Linux interface names have a 15-character limit (IFNAMSIZ)
    vpns = []
    try:
        for conf_file in config_dir.glob('wg_*.conf'):
            interface_name = conf_file.stem
            # Filter out interface names that exceed 15 characters (Linux limit)
            if len(interface_name) <= 15:
                vpns.append(interface_name)
    except PermissionError:
        # Can't read directory, return empty list
        pass

    return vpns


def detect_current_vpn() -> Optional[str]:
    """
    Detect which VPN (if any) is currently connected

    Returns:
        Interface name if connected, None otherwise
    """
    vpns = list_configured_vpns()

    for vpn in vpns:
        status = get_status(vpn)
        if status and status.get('connected'):
            return vpn

    return None


def get_environment_from_interface(interface_name: str) -> Optional[str]:
    """
    Extract environment name from interface name

    Args:
        interface_name: Interface name (e.g., 'wg_onex_test_dev' or 'wg_test_dev')

    Returns:
        Environment name ('dev', 'staging', 'prod'), or None
    """
    # Interface format: wg_<name>_<env> or wg_<env>
    # Split by underscore (correct format) or hyphen (legacy format)
    parts = interface_name.replace('-', '_').split('_')

    # Check last part
    if parts[-1] in ['dev', 'staging', 'prod']:
        return parts[-1]

    # Check second-to-last part
    if len(parts) >= 2 and parts[-2] in ['dev', 'staging', 'prod']:
        return parts[-2]

    return None
