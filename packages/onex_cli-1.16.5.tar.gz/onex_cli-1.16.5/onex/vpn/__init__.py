"""
VPN management module for OneX CLI

Handles WireGuard VPN setup and management across platforms.
"""

from .setup_vpn import setup_vpn
from .wireguard_manager import (
    install_wireguard,
    import_config,
    connect,
    disconnect,
    get_status
)
from .platform_detector import (
    detect_os,
    detect_environment_from_ip,
    get_install_command,
    get_connect_command,
    get_disconnect_command
)

__all__ = [
    'setup_vpn',
    'install_wireguard',
    'import_config',
    'connect',
    'disconnect',
    'get_status',
    'detect_os',
    'detect_environment_from_ip',
    'get_install_command',
    'get_connect_command',
    'get_disconnect_command',
]
