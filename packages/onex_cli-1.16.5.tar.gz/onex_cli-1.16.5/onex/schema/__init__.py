"""
Service descriptor schema management.

This package provides:
- Pydantic models for service.yml schema
- Validation logic
- Documentation generation
- JSON Schema export
"""

from .service_descriptor import (
    ServiceDescriptor,
    DeploymentConfig,
    ContainerConfig,
    ResourcesConfig,
    HealthCheckConfig,
    UpdateConfig,
    RestartPolicyConfig,
    RouteDefinition,
    DependenciesConfig,
    MetadataConfig,
)

__all__ = [
    "ServiceDescriptor",
    "DeploymentConfig",
    "ContainerConfig",
    "ResourcesConfig",
    "HealthCheckConfig",
    "UpdateConfig",
    "RestartPolicyConfig",
    "RouteDefinition",
    "DependenciesConfig",
    "MetadataConfig",
]
