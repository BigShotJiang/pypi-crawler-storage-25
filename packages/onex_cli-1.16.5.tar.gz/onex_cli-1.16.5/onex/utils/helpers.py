"""
Utility functions for OneXEOS CLI
"""

import os
import json
import yaml
import zipfile
import re
import shutil
import tempfile
import py_compile
import sys
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple, Set


def load_service_yml(service_dir: Path) -> Dict[str, Any]:
    """
    Load and parse service.yml from service directory

    Args:
        service_dir: Path to service directory

    Returns:
        Parsed service configuration

    Raises:
        FileNotFoundError: If service.yml not found
        yaml.YAMLError: If YAML is invalid
    """
    service_yml_path = service_dir / 'service.yml'

    if not service_yml_path.exists():
        raise FileNotFoundError(f"service.yml not found in {service_dir}")

    with open(service_yml_path, 'r') as f:
        config = yaml.safe_load(f)

    # Validate required fields (support both 'name' and legacy 'service')
    if 'name' not in config and 'service' not in config:
        raise ValueError("service.yml must contain 'name' field")

    # Normalize: if 'service' is used, copy it to 'name' for backward compatibility
    if 'service' in config and 'name' not in config:
        config['name'] = config['service']

    return config


def create_service_bundle(service_dir: Path, output_path: Path, exclude: List[str] = None) -> Path:
    """
    Create a zip bundle of the service with auto-included shared libs.

    This function:
    1. Scans service code to detect imports from shared libs (helpers, models, etc.)
    2. Auto-copies required shared libs into bundle
    3. Creates zip file ready for deployment
    4. Includes .env file (service-specific environment variables)

    Args:
        service_dir: Path to service directory
        output_path: Path where to save the zip file
        exclude: List of patterns to exclude from service files
                 NOTE: .env is NOT excluded by default - it must be bundled

    Returns:
        Path to created zip file

    Raises:
        RuntimeError: If shared libs can't be copied
    """
    language = _detect_service_language(service_dir)

    if exclude is None:
        if language == 'go':
            exclude = ['.git', '*.log', '.DS_Store', 'vendor']
        else:
            exclude = ['__pycache__', '*.pyc', '.git', 'tests', '*.log', '.DS_Store']
            # NOTE: .env is intentionally NOT in this list
            # Service .env files contain service-specific variables (JWT_SECRET_KEY, etc.)
            # and are loaded by shared runtime during service initialization

    zip_path = output_path / f"{service_dir.name}.zip"

    # Step 1: Detect shared lib imports (Python only)
    detected_libs = set()
    if language == 'python':
        detected_libs = _detect_lib_imports(service_dir)

    # Step 2: Create bundle in temp directory with libs
    with tempfile.TemporaryDirectory() as temp_dir_str:
        bundle_temp_dir = Path(temp_dir_str)

        # Copy service files to temp directory
        service_temp = bundle_temp_dir / service_dir.name
        shutil.copytree(
            service_dir,
            service_temp,
            ignore=shutil.ignore_patterns(*exclude),
            dirs_exist_ok=True  # Allow overwriting if dir exists
        )

        # Copy shared libs if any were detected (Python only)
        if detected_libs:
            import click  # Import here to avoid circular dependency
            click.echo(f"   📚 Detected shared lib imports: {', '.join(sorted(detected_libs))}")

            copied_count = _copy_shared_libs(service_dir, bundle_temp_dir, detected_libs)

            if copied_count > 0:
                click.echo(f"   ✅ Copied {copied_count} shared lib module(s) into bundle")
            else:
                click.echo(f"   ⚠️  Warning: Detected lib imports but couldn't copy modules")

        # Step 3: Create zip from temp directory
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(bundle_temp_dir):
                # Filter out excluded directories from libs
                dirs[:] = [d for d in dirs if d not in ['__pycache__', 'tests']]

                for file in files:
                    # Skip excluded files
                    if file.endswith(('.pyc', '.pyo', '.log')):
                        continue

                    file_path = Path(root) / file
                    arcname = file_path.relative_to(bundle_temp_dir)
                    zipf.write(file_path, arcname)

    return zip_path


def get_shared_libs_path() -> Path:
    """
    Get path to shared libs directory

    Returns:
        Path to libs/ directory in repository root
    """
    # Assume we're in cli/ directory, go up one level
    repo_root = Path(__file__).parent.parent
    libs_path = repo_root / 'libs'

    if not libs_path.exists():
        raise FileNotFoundError(f"Shared libs not found at {libs_path}")

    return libs_path


def _detect_lib_imports(service_dir: Path, include_transitive: bool = True) -> Set[str]:
    """
    Scan service Python files to detect imports from shared libs.

    Detects imports like:
    - from helpers.mongodb_utils import ...
    - from models.order import ...
    - import helpers.auth

    Args:
        service_dir: Path to service directory
        include_transitive: If True, also detect imports from copied libs (transitive deps)

    Returns:
        Set of detected lib module names (e.g., {'helpers', 'models', 'integrations'})
    """
    import_pattern = re.compile(
        r'^\s*(?:from\s+(\w+)(?:\.\w+)*\s+import|import\s+(\w+)(?:\.\w+)*)',
        re.MULTILINE
    )

    # Known shared lib modules (exclude pip packages like nolicore)
    shared_lib_modules = {'helpers', 'models', 'integrations', 'stream_watcher', 'constants'}
    detected_libs = set()

    # Scan all .py files in service
    for py_file in service_dir.rglob('*.py'):
        # Skip __pycache__ and tests
        if '__pycache__' in str(py_file) or 'tests' in str(py_file):
            continue

        try:
            with open(py_file, 'r', encoding='utf-8') as f:
                content = f.read()

                # Find all imports
                for match in import_pattern.finditer(content):
                    # match.group(1) is from ... import, match.group(2) is import ...
                    module_name = match.group(1) or match.group(2)

                    # Check if it's a shared lib module
                    if module_name in shared_lib_modules:
                        detected_libs.add(module_name)
        except Exception:
            # Skip files that can't be read
            pass

    # Add common transitive dependencies
    if include_transitive:
        # If we detected helpers or models, also include integrations
        if 'helpers' in detected_libs or 'models' in detected_libs:
            detected_libs.add('integrations')

        # If we detected models, also include constants (models imports from constants)
        if 'models' in detected_libs:
            detected_libs.add('constants')

    return detected_libs


def _copy_shared_libs(service_dir: Path, bundle_temp_dir: Path, detected_libs: Set[str]) -> int:
    """
    Copy shared libs from repository root to bundle temp directory.

    Args:
        service_dir: Path to service directory
        bundle_temp_dir: Path to bundle assembly temp directory
        detected_libs: Set of detected lib module names to copy

    Returns:
        Number of lib modules copied
    """
    if not detected_libs:
        return 0

    # Get repository root libs path
    try:
        # Navigate from service dir to repo root
        # Structure: repo_root/services/service_name
        service_dir_abs = service_dir.resolve()
        repo_root = service_dir_abs.parent.parent
        libs_source = repo_root / 'libs' / 'python'

        if not libs_source.exists():
            # Try alternative structure if not found
            raise FileNotFoundError(f"Shared libs not found at {libs_source} (repo_root: {repo_root})")

        # Create libs directory in bundle
        libs_dest = bundle_temp_dir / service_dir.name / 'libs' / 'python'
        libs_dest.mkdir(parents=True, exist_ok=True)

        copied_count = 0
        for lib_module in detected_libs:
            lib_source_dir = libs_source / lib_module
            lib_dest_dir = libs_dest / lib_module

            if lib_source_dir.exists():
                # Copy entire lib module directory
                shutil.copytree(lib_source_dir, lib_dest_dir,
                                ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '*.pyo', 'tests'))
                copied_count += 1

        # Create __init__.py files
        (libs_dest.parent / '__init__.py').touch()
        (libs_dest / '__init__.py').touch()

        return copied_count

    except Exception as e:
        raise RuntimeError(f"Failed to copy shared libs: {e}")


def validate_bundle_compilation(bundle_path: Path, service_dir: Path) -> List[str]:
    """
    Extract and compile bundle to validate Python imports.

    This catches:
    - ModuleNotFoundError (missing imports)
    - ImportError (circular imports, broken imports)
    - SyntaxError (invalid Python syntax)

    Skipped for non-Python services (Go, etc.)

    Args:
        bundle_path: Path to the created bundle zip file
        service_dir: Path to original service directory (for context)

    Returns:
        List of error messages (empty if validation passed)
    """
    # Skip compilation check for non-Python services
    language = _detect_service_language(service_dir)
    if language != 'python':
        return []

    errors = []

    # Extract bundle to temp directory
    with tempfile.TemporaryDirectory() as temp_dir_str:
        temp_dir = Path(temp_dir_str)

        try:
            # Extract zip
            with zipfile.ZipFile(bundle_path, 'r') as zipf:
                zipf.extractall(temp_dir)

            # Get service directory in extracted bundle
            service_name = service_dir.name
            extracted_service = temp_dir / service_name

            if not extracted_service.exists():
                errors.append(f"Service directory '{service_name}' not found in bundle")
                return errors

            # Set up Python path to include the extracted bundle
            # This allows imports to resolve correctly
            original_sys_path = sys.path.copy()
            try:
                # Add extracted service to Python path (for relative imports)
                sys.path.insert(0, str(temp_dir))
                sys.path.insert(0, str(extracted_service))

                # If libs exist, add them to path
                libs_path = extracted_service / 'libs' / 'python'
                if libs_path.exists():
                    sys.path.insert(0, str(libs_path))

                # Compile all Python files
                py_files = list(extracted_service.rglob('*.py'))

                for py_file in py_files:
                    # Skip __pycache__ directories
                    if '__pycache__' in str(py_file):
                        continue

                    try:
                        # Compile to check syntax
                        py_compile.compile(str(py_file), doraise=True)

                        # Try importing to check dependencies
                        # Convert file path to module path
                        rel_path = py_file.relative_to(extracted_service)
                        module_parts = list(rel_path.parts[:-1])  # Remove .py extension from path

                        if rel_path.stem != '__init__':
                            module_parts.append(rel_path.stem)

                        if module_parts:
                            module_name = '.'.join(module_parts)

                            # Only validate imports, don't execute module code
                            # We just check if file compiles and has valid import statements
                            with open(py_file, 'r', encoding='utf-8') as f:
                                content = f.read()

                                # Check for common import issues
                                import_pattern = re.compile(
                                    r'^\s*from\s+([\w.]+)\s+import|^\s*import\s+([\w.]+)',
                                    re.MULTILINE
                                )

                                for match in import_pattern.finditer(content):
                                    imported_module = match.group(1) or match.group(2)

                                    # Check if it's importing from known SHARED lib modules (not pip packages)
                                    # Only check for modules that should be in libs/ directory
                                    shared_lib_prefixes = ('helpers.', 'models.', 'integrations.', 'stream_watcher.')

                                    if imported_module.startswith(shared_lib_prefixes):
                                        # Check if the base module exists in libs/
                                        base_module = imported_module.split('.')[0]
                                        base_path = libs_path / base_module if libs_path.exists() else None

                                        if not base_path or not base_path.exists():
                                            relative_file = str(py_file.relative_to(extracted_service))
                                            errors.append(
                                                f"{relative_file}: ModuleNotFoundError: No module named '{base_module}' "
                                                f"(imported as '{imported_module}') - shared lib not found in bundle"
                                            )

                    except SyntaxError as e:
                        relative_file = str(py_file.relative_to(extracted_service))
                        errors.append(
                            f"{relative_file}:{e.lineno}: SyntaxError: {e.msg}"
                        )
                    except py_compile.PyCompileError as e:
                        relative_file = str(py_file.relative_to(extracted_service))
                        errors.append(
                            f"{relative_file}: Compilation error: {str(e)}"
                        )

            finally:
                # Restore original sys.path
                sys.path = original_sys_path

        except zipfile.BadZipFile:
            errors.append("Invalid zip file")
        except Exception as e:
            errors.append(f"Validation error: {str(e)}")

    return errors


def _detect_service_language(service_dir: Path) -> str:
    """Detect the service language from service.yml deployment config."""
    service_yml = service_dir / 'service.yml'
    if not service_yml.exists():
        return 'python'
    try:
        config = yaml.safe_load(open(service_yml))
        deployment = config.get('deployment', {})
        if isinstance(deployment, dict):
            return deployment.get('language', 'python')
    except Exception:
        pass
    return 'python'


def validate_service_structure(service_dir: Path) -> List[str]:
    """
    Validate service directory structure.

    Language-aware: validates Python structure (src/, __init__.py) for Python
    services and Go structure (go.mod, main.go) for Go services.

    Args:
        service_dir: Path to service directory

    Returns:
        List of validation errors (empty if valid)
    """
    errors = []

    # Check service.yml exists
    if not (service_dir / 'service.yml').exists():
        errors.append("Missing service.yml")
        return errors  # Can't detect language without service.yml

    language = _detect_service_language(service_dir)

    if language == 'go':
        # Go service structure
        if not (service_dir / 'go.mod').exists():
            errors.append("Missing go.mod file")
        if not (service_dir / 'main.go').exists():
            errors.append("Missing main.go file")
    else:
        # Python service structure (default)
        if not (service_dir / 'src').exists():
            errors.append("Missing src/ directory")
        if not (service_dir / '__init__.py').exists():
            errors.append("Missing __init__.py in service root")
        if (service_dir / 'src').exists() and not (service_dir / 'src' / '__init__.py').exists():
            errors.append("Missing __init__.py in src/")

    return errors


def validate_service_schema(service_dir: Path) -> tuple[bool, List[str], List[str]]:
    """
    Validate service.yml schema using Pydantic models

    Args:
        service_dir: Path to service directory

    Returns:
        Tuple of (is_valid, errors, warnings)
    """
    from onex.schema.validator import ServiceYmlValidator

    service_yml_path = service_dir / 'service.yml'

    if not service_yml_path.exists():
        return False, ["service.yml not found"], []

    result = ServiceYmlValidator.validate_file(str(service_yml_path))

    return result.is_valid, result.errors, result.warnings


def format_size(size_bytes: int) -> str:
    """Format bytes to human-readable size"""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.1f} TB"


def print_success(message: str):
    """Print success message with checkmark"""
    click.echo(click.style(f"✅ {message}", fg='green'))


def print_error(message: str):
    """Print error message with X"""
    click.echo(click.style(f"❌ {message}", fg='red'))


def print_info(message: str):
    """Print info message"""
    click.echo(click.style(f"ℹ️  {message}", fg='blue'))


def print_warning(message: str):
    """Print warning message"""
    click.echo(click.style(f"⚠️  {message}", fg='yellow'))


import click
from datetime import datetime


def print_header(title: str, icon: str = "🚀"):
    """Print fancy header with double-line border"""
    separator = "═" * 60
    click.echo(separator)
    click.echo(f"{icon} {click.style(title, bold=True)}")
    click.echo(separator)


def print_section_header(title: str):
    """Print section header with single-line border"""
    click.echo()
    click.echo(click.style(title, bold=True))
    click.echo("─" * 60)


def print_footer():
    """Print footer separator"""
    click.echo("═" * 60)


def format_timestamp(timestamp_ms: float, show_date: bool = True) -> str:
    """
    Format Unix timestamp (in milliseconds) to local time with timezone

    Args:
        timestamp_ms: Unix timestamp in milliseconds
        show_date: Include date in output

    Returns:
        Formatted timestamp string
    """
    try:
        dt = datetime.fromtimestamp(timestamp_ms / 1000)
        # Convert to local timezone
        dt_local = dt.astimezone()

        if show_date:
            # Format: 2026-02-15 11:51:56.614 (UTC+7)
            tz_offset = dt_local.strftime('%z')
            tz_formatted = f"UTC{tz_offset[0]}{int(tz_offset[1:3])}"
            return f"{dt_local.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]} ({tz_formatted})"
        else:
            # Format: 11:51:56.614
            return dt_local.strftime('%H:%M:%S.%f')[:-3]
    except:
        # Fallback if timezone handling fails
        dt = datetime.fromtimestamp(timestamp_ms / 1000)
        if show_date:
            return dt.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
        else:
            return dt.strftime('%H:%M:%S.%f')[:-3]


def format_current_time() -> str:
    """Get current time formatted with timezone"""
    now = datetime.now()
    tz_offset = now.strftime('%z')
    tz_formatted = f"UTC{tz_offset[0]}{int(tz_offset[1:3])}" if tz_offset else "Local"
    return f"{now.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]} ({tz_formatted})"


def format_duration(ms: float) -> str:
    """
    Format duration in milliseconds to human-readable string

    Args:
        ms: Duration in milliseconds

    Returns:
        Formatted duration (e.g., "0.31ms", "1.2s", "2m 30s")
    """
    if ms < 1000:
        return f"{ms:.2f}ms"
    elif ms < 60000:
        return f"{ms/1000:.2f}s"
    else:
        minutes = int(ms / 60000)
        seconds = (ms % 60000) / 1000
        return f"{minutes}m {seconds:.1f}s"


def print_metrics_table(metrics: dict, key_width: int = 20):
    """
    Print key-value metrics table with aligned columns

    Args:
        metrics: Dictionary of metric key-value pairs
        key_width: Width for key column
    """
    for key, value in metrics.items():
        key_formatted = f"{key}:".ljust(key_width)
        click.echo(f"{key_formatted} {value}")


def print_progress_bar(label: str, value: float, max_value: float, width: int = 20):
    """
    Print horizontal progress bar

    Args:
        label: Label for the progress bar
        value: Current value
        max_value: Maximum value (for 100%)
        width: Width of the bar in characters
    """
    if max_value == 0:
        percentage = 0
    else:
        percentage = (value / max_value) * 100
        percentage = min(100, max(0, percentage))  # Clamp to 0-100

    filled = int((percentage / 100) * width)
    bar = "█" * filled + "░" * (width - filled)

    value_str = format_duration(value)
    pct_str = f"{percentage:.0f}%"

    # Format: "Gateway:     20.61ms  45%  ████████████"
    label_formatted = f"{label}:".ljust(15)
    value_formatted = value_str.rjust(10)
    pct_formatted = pct_str.rjust(5)

    click.echo(f"{label_formatted} {value_formatted}  {pct_formatted}  {bar}")


def print_tree_item(text: str, is_last: bool = False, indent: str = "                       "):
    """
    Print tree structure item

    Args:
        text: Text to display
        is_last: Whether this is the last item (use └─ instead of ├─)
        indent: Indentation for wrapped lines
    """
    prefix = "└─" if is_last else "├─"
    click.echo(f"{indent}{prefix} {text}")


def monitor_deployment_progress(platform_url: str, deployment_id: str, access_token: str):
    """
    Poll deployment progress endpoint and yield progress updates.

    Args:
        platform_url: Platform base URL
        deployment_id: Deployment ID to monitor
        access_token: JWT access token for authentication

    Yields:
        Dict containing progress data with keys:
        - deployment_id: str
        - service: str
        - status: str
        - progress_pct: int
        - message: str
        - timestamp: str
        - completed: bool (True when deployment is done)
        - result: dict (deployment result if successful)
        - error: str (error message if failed)
    """
    import requests
    import time

    # Progress endpoint is now proxied through the gateway at /_internal/deploy/progress
    # This allows the CLI to work in environments where deployment-controller is not directly accessible
    progress_url = f"{platform_url}/_internal/deploy/progress/{deployment_id}"

    # Only add Authorization header if we have an access token
    headers = {}
    if access_token:
        headers['Authorization'] = f'Bearer {access_token}'

    last_message = None
    retry_429_count = 0
    max_429_retries = 10

    # Small delay to allow background task to initialize
    time.sleep(0.1)

    while True:
        try:
            response = requests.get(progress_url, headers=headers, timeout=10)

            if response.status_code == 200:
                retry_429_count = 0  # Reset on success
                progress_data = response.json()

                # Check if progress has an update (avoid duplicate messages)
                current_message = progress_data.get('message', '')
                if current_message != last_message:
                    yield progress_data
                    last_message = current_message

                # Check if deployment completed (either success or failure)
                if progress_data.get('completed'):
                    yield progress_data
                    break

                if progress_data.get('status') in ['success', 'failed', 'rolled_back']:
                    yield progress_data
                    break

            elif response.status_code == 429:
                # Rate limited - back off and retry instead of failing
                retry_429_count += 1
                if retry_429_count >= max_429_retries:
                    yield {
                        'deployment_id': deployment_id,
                        'error': f'Rate limited after {max_429_retries} retries. Deployment may still be running - check with: onex status',
                        'completed': True,
                        'failed': True
                    }
                    break
                # Exponential backoff: 2s, 4s, 8s, ...
                backoff = min(2 ** retry_429_count, 30)
                time.sleep(backoff)
                continue

            elif response.status_code == 404:
                yield {
                    'deployment_id': deployment_id,
                    'error': 'Deployment not found',
                    'completed': True,
                    'failed': True
                }
                break
            else:
                yield {
                    'deployment_id': deployment_id,
                    'error': f'Failed to get progress: {response.status_code}',
                    'completed': True,
                    'failed': True
                }
                break

        except requests.exceptions.Timeout:
            # Timeout - just continue polling
            pass
        except requests.exceptions.RequestException as e:
            yield {
                'deployment_id': deployment_id,
                'error': f'Network error: {str(e)}',
                'completed': True,
                'failed': True
            }
            break

        # Poll every 2 seconds (reduced from 1s to lower rate limit pressure)
        time.sleep(2)


def format_progress_message(progress_data: Dict[str, Any]) -> str:
    """
    Format progress data for display.

    Args:
        progress_data: Progress data dict from monitor_deployment_progress

    Returns:
        Formatted progress message string
    """
    status = progress_data.get('status', 'unknown')
    progress_pct = progress_data.get('progress_pct', 0)
    message = progress_data.get('message', 'Processing...')

    # Status icons
    status_icons = {
        'pending': '⏳',
        'uploading': '📤',
        'extracting': '📦',
        'installing_dependencies': '📥',
        'provisioning_resources': '⚙️',
        'registering_routes': '🔗',
        'health_check': '🩺',
        'success': '✅',
        'failed': '❌',
        'rolled_back': '🔄'
    }

    icon = status_icons.get(status, '⏳')

    # Format progress bar
    bar_width = 20
    filled = int((progress_pct / 100) * bar_width)
    bar = "█" * filled + "░" * (bar_width - filled)

    return f"{icon} [{bar}] {progress_pct:3d}% - {message}"


def get_auth_data() -> Optional[Dict[str, Any]]:
    """
    Read authentication data from ~/.onex/auth.json

    Returns:
        Auth data dict with platform_url, access_token, user info
        None if not logged in
    """
    auth_file = Path.home() / '.onex' / 'auth.json'

    if not auth_file.exists():
        return None

    try:
        with auth_file.open('r') as f:
            return json.load(f)
    except Exception:
        return None


def get_auth_headers() -> Tuple[Optional[Dict[str, str]], Optional[str]]:
    """
    Get authentication headers and platform URL for API requests.

    Returns:
        Tuple of (headers dict, platform_url)
        (None, None) if not logged in
    """
    auth_data = get_auth_data()

    if not auth_data:
        return None, None

    access_token = auth_data.get('access_token')
    platform_url = auth_data.get('platform_url')

    if not access_token or not platform_url:
        return None, None

    headers = {
        'Authorization': f"Bearer {access_token}",
        'Content-Type': 'application/json'
    }

    return headers, platform_url


def require_auth() -> Tuple[Dict[str, str], str]:
    """
    Require authentication - exit with error if not logged in.

    Returns:
        Tuple of (headers dict, platform_url)

    Raises:
        SystemExit: If not logged in
    """
    headers, platform_url = get_auth_headers()

    if not headers or not platform_url:
        print_error("Not logged in")
        print_info("Run 'onex login' to authenticate")
        raise SystemExit(1)

    return headers, platform_url
