"""
Authentication Utilities

Handles token expiration checking and automatic refresh.
"""

import requests
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Dict, Tuple
from onex.utils import print_info, print_warning, print_error
from onex.utils.crypto import decrypt_credentials


def load_environments() -> dict:
    """Load environments from ~/.onex/environments.json"""
    from onex.commands.login import load_environments as _load
    return _load()


def save_environments(envs: dict):
    """Save environments to ~/.onex/environments.json"""
    from onex.commands.login import save_environments as _save
    _save(envs)


def get_active_environment() -> Optional[str]:
    """Get active environment name"""
    from onex.config import get_onex_dir
    active_file = get_onex_dir() / 'active-env'
    if not active_file.exists():
        return None
    return active_file.read_text().strip()


def is_token_expired(env_name: Optional[str] = None) -> Tuple[bool, Optional[str]]:
    """
    Check if access token has expired or will expire soon.

    Args:
        env_name: Environment name (default: active environment)

    Returns:
        Tuple of (is_expired, expires_at_iso)
        - is_expired: True if token is expired or will expire in <5 minutes
        - expires_at_iso: ISO timestamp of expiration, or None if no token

    Example:
        expired, expires_at = is_token_expired("dev")
        if expired:
            print(f"Token expired at {expires_at}")
    """
    if env_name is None:
        env_name = get_active_environment()

    if not env_name:
        return True, None  # No active environment = expired

    envs = load_environments()
    env_data = envs.get(env_name)

    if not env_data:
        return True, None  # Environment not found = expired

    # Check if token exists
    access_token = env_data.get('access_token')
    if not access_token:
        return True, None  # No token = expired

    # Check expiration time
    expires_at_str = env_data.get('expires_at')
    if not expires_at_str:
        return True, None  # No expiration data = expired

    try:
        # Parse expiration timestamp
        expires_at = datetime.fromisoformat(expires_at_str.replace('Z', '+00:00'))

        # Add buffer time (5 minutes) to avoid using token that's about to expire
        buffer = timedelta(minutes=5)
        effective_expiry = expires_at - buffer

        # Check if expired
        now = datetime.now(effective_expiry.tzinfo)
        is_expired = now >= effective_expiry

        return is_expired, expires_at_str

    except Exception as e:
        # Parse error = treat as expired
        return True, expires_at_str


def auto_refresh_token(env_name: Optional[str] = None, silent: bool = True) -> bool:
    """
    Automatically refresh access token if expired.

    Uses encrypted credentials stored during `onex init` to silently
    re-authenticate without user interaction.

    Args:
        env_name: Environment name (default: active environment)
        silent: If True, suppress informational messages

    Returns:
        True if token refreshed successfully, False otherwise

    Example:
        if auto_refresh_token("dev"):
            # Token is now valid
            pass
    """
    if env_name is None:
        env_name = get_active_environment()

    if not env_name:
        if not silent:
            print_error("No active environment")
        return False

    # Load environment data
    envs = load_environments()
    env_data = envs.get(env_name)

    if not env_data:
        if not silent:
            print_error(f"Environment '{env_name}' not found")
        return False

    # Check if encrypted credentials are available
    encrypted_credentials = env_data.get('encrypted_credentials')
    if not encrypted_credentials:
        if not silent:
            print_warning("Auto-refresh not available (no stored credentials)")
            print_info("Run 'onex login' to re-authenticate")
        return False

    # Decrypt credentials
    try:
        email, password = decrypt_credentials(encrypted_credentials)
    except Exception as e:
        if not silent:
            print_error(f"Failed to decrypt credentials: {e}")
            print_info("Run 'onex login' to update credentials")
        return False

    # Get platform URL
    platform_url = env_data.get('platform_url')
    if not platform_url:
        if not silent:
            print_error("Platform URL not found")
        return False

    # Use auth service (port 8100) for authentication
    import re
    from urllib.parse import urlparse

    # Check for explicit auth URLs in credentials
    creds = env_data.get('credentials', {})
    if creds.get('public_auth_url'):
        auth_url = creds['public_auth_url']
    elif creds.get('auth_url'):
        auth_url = creds['auth_url']
    else:
        parsed = urlparse(platform_url)
        auth_url = f"{parsed.scheme}://{parsed.hostname}:8100"

    if not silent:
        print_info(f"🔄 Refreshing token for {env_name}...")

    # Attempt login
    try:
        response = requests.post(
            f"{auth_url}/auth/login",
            json={
                "email": email,
                "password": password
            },
            timeout=10
        )

        if response.status_code != 200:
            if not silent:
                try:
                    error_detail = response.json().get('detail', 'Unknown error')
                except:
                    error_detail = response.text
                print_error(f"Token refresh failed: {error_detail}")
            return False

        # Parse login response
        login_data = response.json()
        access_token = login_data.get('AccessToken') or login_data.get('access_token')

        if not access_token:
            if not silent:
                print_error("Invalid response from server (no access token)")
            return False

        # Calculate new expiration
        expires_in = login_data.get('ExpiresIn', 28800)  # Default 8 hours
        expires_at = datetime.utcnow() + timedelta(seconds=expires_in)

        # Update environment data
        env_data['access_token'] = access_token
        env_data['token_type'] = login_data.get('TokenType', 'bearer')
        env_data['expires_in'] = expires_in
        env_data['expires_at'] = expires_at.isoformat() + 'Z'
        env_data['last_updated'] = datetime.utcnow().isoformat() + 'Z'

        # Save updated environment
        envs[env_name] = env_data
        save_environments(envs)

        if not silent:
            print_info(f"✅ Token refreshed successfully")
            print_info(f"   Valid until: {expires_at.strftime('%Y-%m-%d %H:%M:%S')} UTC")

        return True

    except requests.exceptions.ConnectionError:
        if not silent:
            print_error(f"Could not connect to {auth_url}")
            print_info("Make sure you are connected to VPN")
        return False
    except Exception as e:
        if not silent:
            print_error(f"Token refresh failed: {str(e)}")
        return False


def ensure_valid_token(env_name: Optional[str] = None, auto_refresh: bool = True) -> bool:
    """
    Ensure we have a valid access token.

    Checks token expiration and automatically refreshes if needed.

    Args:
        env_name: Environment name (default: active environment)
        auto_refresh: If True, automatically refresh expired tokens

    Returns:
        True if token is valid (or was successfully refreshed)
        False if token is invalid and could not be refreshed

    Example:
        # At start of CLI command
        if not ensure_valid_token():
            click.echo("Please run 'onex login' first")
            return 1
    """
    # Check if token is expired
    expired, expires_at = is_token_expired(env_name)

    if not expired:
        # Token is still valid
        return True

    # Token expired - try auto-refresh if enabled
    if auto_refresh:
        return auto_refresh_token(env_name, silent=True)

    # Auto-refresh disabled or failed
    return False


def get_token_info(env_name: Optional[str] = None) -> Optional[Dict]:
    """
    Get token information for debugging.

    Args:
        env_name: Environment name (default: active environment)

    Returns:
        Dict with token info, or None if no token

    Example:
        info = get_token_info("dev")
        print(f"Token expires at: {info['expires_at']}")
        print(f"Time remaining: {info['time_remaining']}")
    """
    if env_name is None:
        env_name = get_active_environment()

    if not env_name:
        return None

    envs = load_environments()
    env_data = envs.get(env_name)

    if not env_data or not env_data.get('access_token'):
        return None

    expires_at_str = env_data.get('expires_at')
    if not expires_at_str:
        return None

    try:
        expires_at = datetime.fromisoformat(expires_at_str.replace('Z', '+00:00'))
        now = datetime.now(expires_at.tzinfo)
        time_remaining = expires_at - now

        return {
            'environment': env_name,
            'expires_at': expires_at_str,
            'expires_in_seconds': int(time_remaining.total_seconds()),
            'time_remaining': str(time_remaining).split('.')[0],  # Remove microseconds
            'is_expired': time_remaining.total_seconds() <= 0,
            'has_auto_refresh': bool(env_data.get('encrypted_credentials')),
        }

    except Exception:
        return None
