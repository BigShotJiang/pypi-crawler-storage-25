"""
Email utilities for sending emails via platform email service.

This module provides helper functions to send emails through the
OneXEOS platform email service (http://email-service:8900).
"""

import httpx
from typing import Optional, Dict, Any


def send_email(
    email_service_url: str,
    to: str,
    subject: str,
    html: str,
    text: Optional[str] = None,
    trace_id: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Send email via platform email service.

    Args:
        email_service_url: Email service URL (e.g., "http://10.0.0.1:8900")
        to: Recipient email address
        subject: Email subject
        html: HTML email body
        text: Plain text email body (optional fallback)
        trace_id: Request trace ID for debugging (optional)
        metadata: Additional metadata (optional)

    Returns:
        dict: Response from email service with email_id, status, message

    Raises:
        httpx.HTTPError: If email service request fails
        ValueError: If email service returns error response
    """
    endpoint = f"{email_service_url}/_internal/email/send"

    payload = {
        "to": to,
        "subject": subject,
        "html": html,
        "text": text or "",  # Fallback to empty string
        "trace_id": trace_id,
        "metadata": metadata or {},
    }

    try:
        response = httpx.post(
            endpoint,
            json=payload,
            timeout=30.0,  # 30 second timeout for email send
        )

        response.raise_for_status()
        return response.json()

    except httpx.HTTPStatusError as e:
        # Extract error message from response if available
        try:
            error_detail = e.response.json().get("detail", str(e))
        except Exception:
            error_detail = str(e)

        raise ValueError(f"Email service error: {error_detail}") from e

    except httpx.RequestError as e:
        raise ValueError(f"Failed to connect to email service: {e}") from e


# VPN config email functionality has been moved to bash scripts
# See: scripts/vpn/lib/email-helpers.sh for VPN email implementation
