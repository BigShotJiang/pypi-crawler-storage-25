"""
Provision command - Manually provision resources without deploying
"""

import click
import requests
import json
from pathlib import Path
from onex.config import get_config, get_access_token
from onex.utils import load_service_yml, print_success, print_error, print_info, print_warning
from onex.utils.auth import auto_refresh_token


@click.command()
@click.option('--env', default=None, help='Environment (local/dev/staging/prod, defaults to active)')
@click.option('--platform-url', help='Override platform URL')
@click.option('--service-dir', type=click.Path(exists=True), default='.', help='Service directory path')
def provision(env, platform_url, service_dir):
    """Manually provision resources (MongoDB collections, Redis keys, etc.)"""
    from onex.config import get_active_environment

    # Use active environment if not specified
    if env is None:
        env = get_active_environment()

    service_path = Path(service_dir).resolve()

    click.echo("🔧 Provisioning resources...")
    click.echo()

    # Load service config
    try:
        config = load_service_yml(service_path)
        service_name = config['name']  # Updated to use 'name' instead of 'service'
    except Exception as e:
        print_error(f"Failed to load service.yml: {e}")
        return

    cli_config = get_config()
    platform_base_url = platform_url or cli_config.get_platform_url(env)

    click.echo(f"📦 Service: {service_name}")
    click.echo(f"🌐 Platform: {platform_base_url}")
    click.echo()

    # Check if service has resources defined
    resources = config.get('resources', {})

    if not resources:
        print_info("No resources defined in service.yml")
        return

    # Build auth headers
    access_token = get_access_token(env)
    headers = {}
    if access_token:
        headers['Authorization'] = f'Bearer {access_token}'

    # Provision resources
    provision_url = f"{platform_base_url}/_internal/provision"

    try:
        response = requests.post(
            provision_url,
            json={
                'service_name': service_name,
                'resources': resources
            },
            headers=headers,
            timeout=30
        )

        if response.status_code == 401 and env != "local":
            print_warning("Token expired, refreshing...")
            if auto_refresh_token(env, silent=False):
                access_token = get_access_token(env)
                headers['Authorization'] = f'Bearer {access_token}'
                response = requests.post(
                    provision_url,
                    json={
                        'service_name': service_name,
                        'resources': resources
                    },
                    headers=headers,
                    timeout=30
                )
            else:
                print_error("Authentication failed - could not refresh token")
                print_info(f"Please login again: onex login --env {env}")
                return

        if response.status_code == 200:
            result = response.json()

            print_success("Resources provisioned successfully!")
            click.echo()

            # Show what was created
            if 'databases' in result:
                click.echo("📊 MongoDB Collections:")
                for db_resource in result['databases']:
                    collection = db_resource.get('collection')
                    indexes = db_resource.get('indexes_created', [])
                    click.echo(f"   ✓ {collection}")
                    for idx in indexes:
                        click.echo(f"      - Index: {idx}")

            if 'redis_keys' in result:
                click.echo()
                click.echo("🔑 Redis Keys:")
                for key in result['redis_keys']:
                    click.echo(f"   ✓ {key}")

        else:
            print_error(f"Provisioning failed: {response.status_code}")
            try:
                error_detail = response.json()
                click.echo(f"   Error: {error_detail.get('detail', 'Unknown error')}")
            except:
                click.echo(f"   Response: {response.text}")

    except requests.exceptions.ConnectionError:
        print_error(f"Cannot connect to platform at {platform_base_url}")
        print_info("Make sure platform is running")

    except Exception as e:
        print_error(f"Provisioning failed: {e}")
