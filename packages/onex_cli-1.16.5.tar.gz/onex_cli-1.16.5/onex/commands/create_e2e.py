"""
E2E test scaffolding command

Generates E2E test file and test data YAML for a service.

Usage:
    onex create-e2e --service product
    onex create-e2e --service order --entities order,package
    onex create-e2e --service inventory --output ./tests/e2e
"""

import os
import re
import click
from pathlib import Path
from jinja2 import Environment, FileSystemLoader, select_autoescape
from onex.utils import print_success, print_error, print_info, print_warning


def _find_services_repo():
    """Auto-discover services repo."""
    if os.environ.get('ONEX_SERVICES_DIR'):
        return Path(os.environ['ONEX_SERVICES_DIR'])

    cwd = Path.cwd()
    if (cwd / 'tests' / 'e2e').exists():
        return cwd

    for name in ['onexerp-services', 'onexeos-services']:
        candidate = cwd.parent / name
        if (candidate / 'tests' / 'e2e').exists():
            return candidate

    return None


def _to_class_name(name):
    """Convert snake_case or kebab-case to PascalCase."""
    parts = re.split(r'[-_]', name)
    return ''.join(p.capitalize() for p in parts)


def _pluralize(name):
    """Simple pluralization for endpoint names."""
    if name.endswith('y') and name[-2:] not in ('ay', 'ey', 'oy', 'uy'):
        return name[:-1] + 'ies'
    if name.endswith('s') or name.endswith('x') or name.endswith('z'):
        return name + 'es'
    return name + 's'


def _discover_entities_from_service_yml(service_dir):
    """Parse service.yml to auto-discover entities from HTTP routes."""
    import yaml

    service_yml = service_dir / 'service.yml'
    if not service_yml.exists():
        return []

    with open(service_yml) as f:
        config = yaml.safe_load(f)

    if not config:
        return []

    service_name = config.get('name', '')
    functions = config.get('functions', [])
    entities_seen = {}

    for func in functions:
        triggers = func.get('triggers', [])
        for trigger in triggers:
            if trigger.get('type') != 'http':
                continue
            method = trigger.get('method', 'GET').upper()
            path = trigger.get('path', '')

            if not path:
                continue

            # Strip service prefix
            prefix = f'/{service_name}'
            if path.startswith(prefix):
                path = path[len(prefix):]

            # Get first path segment (the collection)
            parts = path.lstrip('/').split('/')
            if not parts or not parts[0]:
                continue

            collection = parts[0]
            # Convert to snake_case entity name
            entity_name = collection.replace('-', '_')

            # De-pluralize
            if entity_name.endswith('ies') and len(entity_name) > 3:
                singular = entity_name[:-3] + 'y'
            elif entity_name.endswith('s') and not entity_name.endswith('ss'):
                singular = entity_name[:-1]
            else:
                singular = entity_name

            if singular not in entities_seen:
                entities_seen[singular] = collection

    return [
        {
            'name': name,
            'class_name': _to_class_name(name),
            'endpoint': endpoint,
        }
        for name, endpoint in entities_seen.items()
    ]


def _build_entities(entity_names):
    """Build entity dicts from comma-separated names."""
    entities = []
    for name in entity_names:
        name = name.strip().replace('-', '_')
        if not name:
            continue
        entities.append({
            'name': name,
            'class_name': _to_class_name(name),
            'endpoint': _pluralize(name),
        })
    return entities


@click.command()
@click.option('--service', '-s', required=True, help='Service name (e.g., product, customer)')
@click.option('--entities', '-e', help='Comma-separated entity names (auto-detected from service.yml if omitted)')
@click.option('--output', '-o', type=click.Path(), help='Output directory (default: auto-detected tests/e2e)')
@click.option('--services-dir', type=click.Path(exists=True), help='Path to services repo')
@click.option('--force', is_flag=True, help='Overwrite existing files')
def create_e2e(service, entities, output, services_dir, force):
    """Scaffold E2E test file and data YAML for a service.

    Examples:
      onex create-e2e --service product
      onex create-e2e --service order --entities order,package
      onex create-e2e --service inventory -o ./tests/e2e
    """
    # Find services repo
    repo = Path(services_dir) if services_dir else _find_services_repo()

    # Determine output directory
    if output:
        e2e_dir = Path(output)
    elif repo and (repo / 'tests' / 'e2e').exists():
        e2e_dir = repo / 'tests' / 'e2e'
    else:
        e2e_dir = Path.cwd() / 'tests' / 'e2e'

    # Discover or parse entities
    if entities:
        entity_list = _build_entities(entities.split(','))
    else:
        # Try auto-discovery from service.yml
        service_dir = None
        if repo:
            candidate = repo / 'services' / service
            if candidate.exists():
                service_dir = candidate
        if not service_dir:
            candidate = Path.cwd() / 'services' / service
            if candidate.exists():
                service_dir = candidate

        if service_dir:
            entity_list = _discover_entities_from_service_yml(service_dir)
            if entity_list:
                print_info(f"Auto-discovered {len(entity_list)} entities from service.yml:")
                for e in entity_list:
                    print_info(f"  {e['name']} -> /{e['endpoint']}")
            else:
                print_warning(f"No entities found in service.yml, using service name as entity")
                entity_list = _build_entities([service])
        else:
            print_warning(f"No service directory found for '{service}', using service name as entity")
            entity_list = _build_entities([service])

    if not entity_list:
        print_error("No entities to scaffold")
        raise SystemExit(1)

    # Prepare template context
    context = {
        'service_name': service,
        'service_description': f"{_to_class_name(service)} Service",
        'entities': entity_list,
        'entity_names_str': ', '.join(e['name'] for e in entity_list),
    }

    # Load templates
    cli_dir = Path(__file__).parent.parent
    template_dir = cli_dir / 'templates' / 'e2e'

    jinja_env = Environment(
        loader=FileSystemLoader(str(template_dir)),
        autoescape=select_autoescape(),
        keep_trailing_newline=True,
    )

    # Generate test file
    test_file = e2e_dir / f'test_{service}_e2e.py'
    data_dir = e2e_dir / 'data'
    data_file = data_dir / f'{service}.yml'

    created = []

    # Check existing files
    for f in [test_file, data_file]:
        if f.exists() and not force:
            print_warning(f"File already exists: {f}")
            print_info("Use --force to overwrite")
            raise SystemExit(1)

    # Create output directories
    e2e_dir.mkdir(parents=True, exist_ok=True)
    data_dir.mkdir(parents=True, exist_ok=True)

    # Render test file
    test_template = jinja_env.get_template('test_service_e2e.py.j2')
    test_content = test_template.render(**context)
    test_file.write_text(test_content)
    created.append(test_file)

    # Render data YAML
    data_template = jinja_env.get_template('data_service.yml.j2')
    data_content = data_template.render(**context)
    data_file.write_text(data_content)
    created.append(data_file)

    # Print results
    print_success(f"\nScaffolded E2E tests for '{service}':")
    for f in created:
        print_success(f"  {f}")

    print_info(f"\nNext steps:")
    print_info(f"  1. Edit {data_file.name} with correct API payloads")
    print_info(f"  2. Review {test_file.name} and customize if needed")
    print_info(f"  3. Run: onex test --service {service} --env dev")
