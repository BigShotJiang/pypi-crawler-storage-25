"""
Logout from OneXEOS platform and clear authentication token
"""

import click
from pathlib import Path
from onex.utils import print_success, print_info, print_error, print_warning


@click.command()
@click.option('--force', is_flag=True, help='Force logout without confirmation')
def logout(force):
    """Logout from OneXEOS platform and remove stored token"""

    # Check if auth file exists
    auth_file = Path.home() / '.onex' / 'auth.json'

    if not auth_file.exists():
        print_warning("Not currently logged in")
        return

    # Read current auth info to show user details
    try:
        import json
        with auth_file.open('r') as f:
            auth_data = json.load(f)

        user = auth_data.get('user', {})
        platform_url = auth_data.get('platform_url', 'Unknown')

        click.echo("🔓 Logout from OneXEOS Platform")
        click.echo()
        print_info(f"Current user:     {user.get('full_name', 'Unknown')} ({user.get('email', 'Unknown')})")
        print_info(f"Platform:         {platform_url}")
        click.echo()

        # Confirm logout
        if not force:
            if not click.confirm("Are you sure you want to logout?"):
                print_info("Logout cancelled")
                return

        # Remove auth file
        auth_file.unlink()

        click.echo()
        print_success("Logged out successfully")
        click.echo()
        print_info("Authentication token has been removed from ~/.onex/auth.json")
        print_info("Run 'onex login' to login again")

    except Exception as e:
        print_error(f"Logout failed: {str(e)}")
        print_info("You can manually delete ~/.onex/auth.json to clear authentication")
