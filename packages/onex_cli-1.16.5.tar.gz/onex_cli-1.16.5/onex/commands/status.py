"""
Status command - Check service status on platform
"""

import click
import requests
from datetime import datetime, timezone
from onex.config import get_config, get_access_token
from onex.utils import print_success, print_error, print_info, print_warning
from onex.utils.auth import auto_refresh_token


def _format_relative_time(timestamp_str):
    """Format a timestamp string as relative time (e.g., '2m ago')."""
    if not timestamp_str:
        return "-"
    try:
        # Parse ISO format timestamp
        if isinstance(timestamp_str, str):
            ts = timestamp_str.replace("Z", "+00:00")
            dt = datetime.fromisoformat(ts)
        else:
            return "-"

        # Make offset-aware if naive
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)

        now = datetime.now(timezone.utc)
        diff = now - dt

        seconds = int(diff.total_seconds())
        if seconds < 0:
            return "just now"
        elif seconds < 60:
            return f"{seconds}s ago"
        elif seconds < 3600:
            return f"{seconds // 60}m ago"
        elif seconds < 86400:
            return f"{seconds // 3600}h ago"
        else:
            return f"{seconds // 86400}d ago"
    except (ValueError, TypeError):
        return "-"


@click.command()
@click.argument('service_name', required=False)
@click.option('--env', default=None, help='Environment (local/dev/staging/prod, defaults to active)')
@click.option('--platform-url', help='Override platform URL')
def status(service_name, env, platform_url):
    """Check service status on platform"""
    from onex.config import get_active_environment

    # Use active environment if not specified
    if env is None:
        env = get_active_environment()

    config = get_config()
    platform_base_url = platform_url or config.get_platform_url(env)

    # Get access token for authentication
    access_token = get_access_token(env)
    headers = {}
    if access_token:
        headers['Authorization'] = f'Bearer {access_token}'

    if service_name:
        # Check specific service
        click.echo(f"🔍 Checking status of {service_name}...")
        click.echo()

        status_url = f"{platform_base_url}/_internal/services/{service_name}"

        try:
            response = requests.get(status_url, headers=headers, timeout=10)

            if response.status_code == 200:
                data = response.json()

                click.echo(f"📦 Service: {data.get('name')}")
                click.echo(f"   Version: {data.get('version', 'N/A')}")
                click.echo(f"   Status: {data.get('status', 'unknown')}")
                click.echo(f"   Mode: {data.get('mode', 'shared')}")

                if data.get('mode') == 'isolated':
                    click.echo(f"   Replicas: {data.get('replicas', 0)}")
                    click.echo(f"   Container: {data.get('container_name', 'N/A')}")

                click.echo()
                click.echo("🔗 Routes:")
                for route in data.get('routes', []):
                    method = route.get('method', 'GET')
                    path = route.get('path', '')
                    click.echo(f"   {method:6} {path}")

                click.echo()
                click.echo("📊 Metrics:")
                metrics = data.get('metrics', {})
                click.echo(f"   Requests: {metrics.get('total_requests', 0)}")
                click.echo(f"   Errors: {metrics.get('error_count', 0)}")
                click.echo(f"   Avg Response Time: {metrics.get('avg_response_time', 0):.2f}ms")

                # Health status
                health = data.get('health', 'unknown')
                if health == 'healthy':
                    print_success(f"Service is healthy")
                elif health == 'unhealthy':
                    print_error(f"Service is unhealthy")
                else:
                    print_warning(f"Service health: {health}")

            elif response.status_code == 401 and env != "local":
                print_warning("Token expired, refreshing...")
                if auto_refresh_token(env, silent=False):
                    access_token = get_access_token(env)
                    headers['Authorization'] = f'Bearer {access_token}'
                    response = requests.get(status_url, headers=headers, timeout=10)
                    if response.status_code == 200:
                        data = response.json()
                        click.echo(f"📦 Service: {data.get('name')}")
                        click.echo(f"   Version: {data.get('version', 'N/A')}")
                        click.echo(f"   Status: {data.get('status', 'unknown')}")
                        click.echo(f"   Mode: {data.get('mode', 'shared')}")
                        if data.get('mode') == 'isolated':
                            click.echo(f"   Replicas: {data.get('replicas', 0)}")
                            click.echo(f"   Container: {data.get('container_name', 'N/A')}")
                        click.echo()
                        click.echo("🔗 Routes:")
                        for route in data.get('routes', []):
                            method = route.get('method', 'GET')
                            path = route.get('path', '')
                            click.echo(f"   {method:6} {path}")
                        click.echo()
                        click.echo("📊 Metrics:")
                        metrics = data.get('metrics', {})
                        click.echo(f"   Requests: {metrics.get('total_requests', 0)}")
                        click.echo(f"   Errors: {metrics.get('error_count', 0)}")
                        click.echo(f"   Avg Response Time: {metrics.get('avg_response_time', 0):.2f}ms")
                        health = data.get('health', 'unknown')
                        if health == 'healthy':
                            print_success(f"Service is healthy")
                        elif health == 'unhealthy':
                            print_error(f"Service is unhealthy")
                        else:
                            print_warning(f"Service health: {health}")
                        return
                print_error("Authentication failed - could not refresh token")
                print_info(f"Please login again: onex login --env {env}")

            elif response.status_code == 404:
                print_error(f"Service '{service_name}' not found")
                print_info("Check deployed services with: onex status")

            else:
                print_error(f"Failed to get status: {response.status_code}")

        except requests.exceptions.ConnectionError:
            print_error(f"Cannot connect to platform at {platform_base_url}")
            print_info("Make sure platform is running")

        except Exception as e:
            print_error(f"Error checking status: {e}")

    else:
        # List all services
        click.echo("📋 Listing all deployed services...")
        click.echo()

        services_url = f"{platform_base_url}/_internal/services"

        try:
            response = requests.get(services_url, headers=headers, timeout=10)

            if response.status_code == 200:
                data = response.json()
                services = data.get('services', {})

                if not services:
                    print_info("No services deployed")
                    print_info("Deploy a service with: onex deploy")
                    return

                click.echo(f"Found {len(services)} service(s):")
                click.echo()

                # Table header
                click.echo(f"{'Service':<20} {'Version':<10} {'Mode':<12} {'Status':<10} {'Health':<12} {'Last Check':<12} {'Routes':<8}")
                click.echo("-" * 94)

                for svc_name, svc_data in services.items():
                    version = svc_data.get('version', 'N/A')
                    mode = svc_data.get('mode', 'shared')
                    status_val = svc_data.get('status', 'unknown')
                    health_val = svc_data.get('health_status', 'unknown')
                    last_check = _format_relative_time(svc_data.get('last_health_check'))
                    route_count = len(svc_data.get('apis', []))

                    # Color code status
                    if status_val == 'running':
                        status_colored = click.style(status_val, fg='green')
                    elif status_val == 'error':
                        status_colored = click.style(status_val, fg='red')
                    else:
                        status_colored = status_val

                    # Color code health
                    if health_val == 'healthy':
                        health_colored = click.style(health_val, fg='green')
                    elif health_val == 'unhealthy':
                        health_colored = click.style(health_val, fg='red')
                    elif health_val == 'degraded':
                        health_colored = click.style(health_val, fg='yellow')
                    else:
                        health_colored = click.style(health_val, fg='yellow')

                    click.echo(f"{svc_name:<20} {version:<10} {mode:<12} {status_colored:<19} {health_colored:<21} {last_check:<12} {route_count:<8}")

                click.echo()
                print_info(f"Platform: {platform_base_url}")
                print_info("Use 'onex status <service_name>' for detailed info")

            elif response.status_code == 401 and env != "local":
                print_warning("Token expired, refreshing...")
                if auto_refresh_token(env, silent=False):
                    access_token = get_access_token(env)
                    headers['Authorization'] = f'Bearer {access_token}'
                    response = requests.get(services_url, headers=headers, timeout=10)
                    if response.status_code == 200:
                        data = response.json()
                        services = data.get('services', {})
                        if not services:
                            print_info("No services deployed")
                            return
                        click.echo(f"Found {len(services)} service(s):")
                        click.echo()
                        click.echo(f"{'Service':<20} {'Version':<10} {'Mode':<12} {'Status':<10} {'Health':<12} {'Last Check':<12} {'Routes':<8}")
                        click.echo("-" * 94)
                        for svc_name, svc_data in services.items():
                            version = svc_data.get('version', 'N/A')
                            mode = svc_data.get('mode', 'shared')
                            status_val = svc_data.get('status', 'unknown')
                            health_val = svc_data.get('health_status', 'unknown')
                            last_check = _format_relative_time(svc_data.get('last_health_check'))
                            route_count = len(svc_data.get('apis', []))
                            if status_val == 'running':
                                status_colored = click.style(status_val, fg='green')
                            elif status_val == 'error':
                                status_colored = click.style(status_val, fg='red')
                            else:
                                status_colored = status_val
                            if health_val == 'healthy':
                                health_colored = click.style(health_val, fg='green')
                            elif health_val == 'unhealthy':
                                health_colored = click.style(health_val, fg='red')
                            elif health_val == 'degraded':
                                health_colored = click.style(health_val, fg='yellow')
                            else:
                                health_colored = click.style(health_val, fg='yellow')
                            click.echo(f"{svc_name:<20} {version:<10} {mode:<12} {status_colored:<19} {health_colored:<21} {last_check:<12} {route_count:<8}")
                        click.echo()
                        print_info(f"Platform: {platform_base_url}")
                        print_info("Use 'onex status <service_name>' for detailed info")
                        return
                print_error("Authentication failed - could not refresh token")
                print_info(f"Please login again: onex login --env {env}")

            else:
                print_error(f"Failed to list services: {response.status_code}")

        except requests.exceptions.ConnectionError:
            print_error(f"Cannot connect to platform at {platform_base_url}")
            print_info("Make sure platform is running")

        except Exception as e:
            print_error(f"Error listing services: {e}")
