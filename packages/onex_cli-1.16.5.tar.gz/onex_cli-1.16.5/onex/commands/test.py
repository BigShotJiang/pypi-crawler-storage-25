"""
E2E test runner command

Runs E2E tests against the platform using pytest.

Usage:
    onex test                          # Run all E2E tests
    onex test --service product        # Run product tests only
    onex test --service customer       # Run customer tests only
    onex test --env staging            # Run against staging
    onex test -k "test_01_create"      # Pass pytest -k filter
    onex test --maxfail 3              # Stop after 3 failures
    onex test --list                   # List available test files
"""

import click
import subprocess
import sys
import os
from pathlib import Path
from onex.config import get_active_environment, get_platform_url
from onex.utils import print_success, print_error, print_info, print_warning


def _find_services_repo():
    """Auto-discover services repo (sibling dir or env var)."""
    if os.environ.get('ONEX_SERVICES_DIR'):
        return Path(os.environ['ONEX_SERVICES_DIR'])

    cwd = Path.cwd()

    # Check if we're already in the services repo
    if (cwd / 'tests' / 'e2e').exists():
        return cwd

    # Check common sibling patterns
    for name in ['onexerp-services', 'onexeos-services']:
        candidate = cwd.parent / name
        if (candidate / 'tests' / 'e2e').exists():
            return candidate

    return None


@click.command()
@click.option('--service', '-s', help='Service to test (e.g., product, customer)')
@click.option('--env', default=None, help='Environment (defaults to active)')
@click.option('--maxfail', default=5, type=int, help='Stop after N failures')
@click.option('-k', 'filter_expr', help='Pytest -k filter expression')
@click.option('-v', '--verbose', is_flag=True, default=True, help='Verbose output')
@click.option('--list', 'list_tests', is_flag=True, help='List available test files')
@click.option('--services-dir', type=click.Path(exists=True), help='Path to services repo')
def test(service, env, maxfail, filter_expr, verbose, list_tests, services_dir):
    """Run E2E tests against the platform.

    Examples:
      onex test                          # Run all E2E tests
      onex test --service product        # Test product service
      onex test --env staging            # Test against staging
      onex test -k "test_create"         # Filter by test name
    """
    # Resolve environment
    if env is None:
        env = get_active_environment()

    # Find services repo
    repo = Path(services_dir) if services_dir else _find_services_repo()
    if not repo or not (repo / 'tests' / 'e2e').exists():
        print_error("Cannot find E2E tests directory.")
        print_info("Run from the services repo, or set ONEX_SERVICES_DIR, or use --services-dir")
        raise SystemExit(1)

    e2e_dir = repo / 'tests' / 'e2e'

    # --list: show available test files
    if list_tests:
        print_info(f"Available E2E tests in {e2e_dir}:")
        found = False
        for f in sorted(e2e_dir.glob('test_*_e2e.py')):
            svc = f.stem.replace('test_', '').replace('_e2e', '')
            print_info(f"  {svc:20s}  {f.name}")
            found = True
        if not found:
            print_warning("No E2E test files found")
        return

    # Build pytest args
    if service:
        test_file = e2e_dir / f'test_{service}_e2e.py'
        if not test_file.exists():
            print_error(f"No test file: {test_file.name}")
            print_info("Use 'onex test --list' to see available tests")
            raise SystemExit(1)
        target = str(test_file)
    else:
        target = str(e2e_dir)

    cmd = [sys.executable, '-m', 'pytest', target, '--env', env]
    if verbose:
        cmd.append('-v')
    if maxfail:
        cmd.extend(['--maxfail', str(maxfail)])
    if filter_expr:
        cmd.extend(['-k', filter_expr])

    # Set platform env vars
    run_env = os.environ.copy()
    run_env['TEST_ENV'] = env
    try:
        platform_url = get_platform_url(env)
        if platform_url:
            run_env['PLATFORM_URL'] = platform_url
    except Exception:
        pass

    print_info(f"Running E2E tests against {env}...")
    if service:
        print_info(f"Service: {service}")
    print_info(f"Command: {' '.join(cmd)}\n")

    result = subprocess.run(cmd, cwd=str(repo), env=run_env)
    raise SystemExit(result.returncode)
