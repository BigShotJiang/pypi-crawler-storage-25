"""
Reload command - Force reload a service in the shared runtime

Useful when:
- Code changes aren't reflected after deployment
- Python bytecode cache is stale
- Hot-reload didn't trigger automatically
"""

import click
import requests
from onex.config import get_config, get_access_token
from onex.utils import print_success, print_error, print_info, print_warning
from onex.utils.auth import auto_refresh_token


@click.command()
@click.argument('service_name')
@click.option('--env', default=None, help='Environment (local/dev/staging/prod, defaults to active)')
@click.option('--platform-url', help='Override platform URL')
def reload(service_name, env, platform_url):
    """Force reload a service in the shared runtime.

    Purges cached Python modules, reinstalls dependencies, and reloads
    the service. Use this when code changes aren't reflected after deployment.

    Example:
        onex reload pricing
        onex reload pricing --env dev
    """
    from onex.config import get_active_environment

    if env is None:
        env = get_active_environment()

    config = get_config()
    platform_base_url = platform_url or config.get_platform_url(env)

    access_token = get_access_token(env)
    headers = {}
    if access_token:
        headers['Authorization'] = f'Bearer {access_token}'

    reload_url = f"{platform_base_url}/_internal/reload/{service_name}"

    click.echo(f"🔄 Reloading {service_name} in shared runtime...")
    click.echo()

    try:
        response = requests.post(reload_url, headers=headers, timeout=120)

        if response.status_code == 200:
            data = response.json()
            success = data.get('success', False)
            deps_installed = data.get('deps_installed', False)

            if success:
                print_success(f"Service '{service_name}' reloaded successfully")
                click.echo()
                click.echo(f"   Dependencies: {'✅ installed' if deps_installed else '⚠️  skipped'}")
                deps_details = data.get('deps_details', '')
                if deps_details:
                    # Show first line of deps output
                    first_line = deps_details.strip().split('\n')[0][:100]
                    click.echo(f"   Details: {first_line}")
            else:
                print_error(f"Service '{service_name}' failed to reload")
                click.echo()
                deps_details = data.get('deps_details', '')
                if deps_details:
                    click.echo(f"   Details: {deps_details[:300]}")
                print_info("Check shared-runtime logs: onex logs shared-runtime")

        elif response.status_code == 401 and env != "local":
            print_warning("Token expired, refreshing...")
            if auto_refresh_token(env, silent=False):
                access_token = get_access_token(env)
                headers['Authorization'] = f'Bearer {access_token}'
                response = requests.post(reload_url, headers=headers, timeout=120)
                if response.status_code == 200:
                    data = response.json()
                    if data.get('success'):
                        print_success(f"Service '{service_name}' reloaded successfully")
                    else:
                        print_error(f"Service '{service_name}' failed to reload")
                    return
            print_error("Authentication failed - could not refresh token")
            print_info(f"Please login again: onex login --env {env}")

        elif response.status_code == 404:
            print_error(f"Service '{service_name}' not found")
            print_info("Check deployed services with: onex status")

        elif response.status_code == 500:
            detail = ''
            try:
                detail = response.json().get('detail', response.text[:300])
            except Exception:
                detail = response.text[:300]
            print_error(f"Reload failed: {detail}")
            print_info("Fix the issue and redeploy, or check logs: onex logs shared-runtime")

        else:
            print_error(f"Unexpected response: HTTP {response.status_code}")
            print_info(response.text[:200])

    except requests.exceptions.ConnectionError:
        print_error(f"Cannot connect to platform at {platform_base_url}")
        print_info("Make sure platform is running")

    except requests.exceptions.Timeout:
        print_error("Reload request timed out (120s)")
        print_info("The service may still be reloading. Check: onex status " + service_name)

    except Exception as e:
        print_error(f"Error reloading service: {e}")
