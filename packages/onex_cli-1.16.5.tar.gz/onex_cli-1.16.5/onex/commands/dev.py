"""
Dev command - Run service locally with hot-reload
"""

import click
import subprocess
import sys
from pathlib import Path
from onex.utils import load_service_yml, validate_service_structure, print_success, print_error, print_info


@click.command()
@click.argument('service_name', required=False)
@click.option('--port', default=8001, help='Port to run service on')
@click.option('--no-reload', is_flag=True, help='Disable hot-reload')
@click.option('--service-dir', type=click.Path(exists=True), default='.', help='Service directory path')
def dev(service_name, port, no_reload, service_dir):
    """Run service locally with hot-reload"""

    service_path = Path(service_dir).resolve()

    click.echo(f"🔧 Starting local development server...")
    click.echo()

    # Validate service structure
    errors = validate_service_structure(service_path)
    if errors:
        print_error("Service validation failed:")
        for error in errors:
            click.echo(f"  - {error}")
        return

    # Load service config
    try:
        config = load_service_yml(service_path)
        service_name = service_name or config['name']  # Updated to use 'name' instead of 'service'
    except Exception as e:
        print_error(f"Failed to load service.yml: {e}")
        return

    click.echo(f"📦 Service: {service_name}")
    click.echo(f"🌐 Port: {port}")
    click.echo(f"🔄 Hot-reload: {'Disabled' if no_reload else 'Enabled'}")
    click.echo()

    print_info("Starting FastAPI development server with hot-reload...")
    print_info("Press CTRL+C to stop")
    click.echo()

    # Get repository root (assuming we're in services/{service_name})
    repo_root = service_path.parent.parent

    # Build Python path to include libs and services
    python_path = f"{repo_root}/libs/python:{repo_root}/libs/nolicore:{repo_root}/services"

    # Set environment variables
    env = {
        'PYTHONPATH': python_path,
        'SERVICE_NAME': service_name,
        'SERVICE_DIR': str(service_path),
        'PORT': str(port),
    }

    # Command to run using onex.runtime.local_runtime
    cmd = [
        sys.executable,
        '-m',
        'uvicorn',
        'onex.runtime.local_runtime:app',
        '--host', '0.0.0.0',
        '--port', str(port),
    ]

    if not no_reload:
        cmd.extend(['--reload', '--reload-dir', str(service_path)])

    try:
        # Run uvicorn
        subprocess.run(cmd, env={**subprocess.os.environ, **env}, check=True)
    except KeyboardInterrupt:
        click.echo()
        print_success("Development server stopped")
    except FileNotFoundError:
        print_error("uvicorn not found. Install it with: pip install uvicorn[standard]")
    except Exception as e:
        print_error(f"Failed to start dev server: {e}")
