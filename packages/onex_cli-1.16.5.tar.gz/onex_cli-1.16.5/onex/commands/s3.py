"""
S3 command group - MinIO/S3 object storage management

Commands:
  ls       - List buckets or objects in a bucket
  search   - Search objects by prefix/pattern
  get      - Download an object to local file
  info     - Get object metadata (size, content-type, etag, last modified)
  browse   - Interactive browser for exploring buckets and objects
"""

import click
import json
import os
import sys
from pathlib import Path
from onex.config import get_active_environment
from onex.utils import print_error, print_info, print_success, print_warning, format_size


def _get_minio_credentials(env):
    """Get MinIO credentials for the environment."""
    if env == 'local':
        return {
            'endpoint': 'localhost:9000',
            'access_key': 'minioadmin',
            'secret_key': 'minioadmin123',
            'secure': False,
        }

    # Load from environments.json
    env_file = Path.home() / '.onex' / 'environments.json'
    if not env_file.exists():
        return None

    with env_file.open() as f:
        data = json.load(f)

    env_data = data.get(env, {})
    credentials = env_data.get('credentials', {})

    endpoint = credentials.get('minio_endpoint', '')
    access_key = credentials.get('minio_access_key', '')
    secret_key = credentials.get('minio_secret_key', '')

    if not endpoint or not access_key or not secret_key:
        return None

    return {
        'endpoint': endpoint,
        'access_key': access_key,
        'secret_key': secret_key,
        'secure': False,
    }


def _get_minio_client(env):
    """Create and return a MinIO client for the environment."""
    try:
        from minio import Minio
    except ImportError:
        print_error("minio package not installed")
        print_info("Install with: pip install minio")
        sys.exit(1)

    creds = _get_minio_credentials(env)
    if not creds:
        print_error(f"MinIO credentials not found for environment '{env}'")
        print_info(f"Run: onex login --env {env}")
        sys.exit(1)

    return Minio(
        creds['endpoint'],
        access_key=creds['access_key'],
        secret_key=creds['secret_key'],
        secure=creds['secure'],
    )


def _format_object_size(size):
    """Format byte size to human readable."""
    if size is None:
        return 'N/A'
    return format_size(size)


def _format_time(dt):
    """Format datetime for display."""
    if dt is None:
        return 'N/A'
    return dt.strftime('%Y-%m-%d %H:%M:%S')


MCP_HINT = click.style(
    "\n  Tip: These commands are also available via Claude MCP.\n"
    "  Ask Claude: \"What S3 buckets do we have?\" or \"Find all zip files in uploads\"",
    fg='bright_black',
)


@click.group()
def s3():
    """S3/MinIO object storage commands.

    \b
    Available via Claude MCP (AI assistant):
      "What S3 buckets do we have?"          -> onex_s3_ls()
      "List files in the uploads bucket"     -> onex_s3_ls(path="uploads")
      "Find all zip files in uploads"        -> onex_s3_search(bucket="uploads", pattern="*.zip")
      "Show details for uploads/report.pdf"  -> onex_s3_info(path="uploads/report.pdf")

    \b
    Setup MCP: onex mcp setup
    """
    pass


@s3.command('ls')
@click.argument('path', required=False, default=None)
@click.option('--env', default=None, help='Environment (local/dev/staging/prod, defaults to active)')
@click.option('--recursive', '-r', is_flag=True, help='List objects recursively')
@click.option('--json', 'output_json', is_flag=True, help='Output as JSON')
def ls(path, env, recursive, output_json):
    """List buckets or objects in a bucket.

    \b
    Examples:
      # List all buckets
      onex s3 ls

      # List objects in a bucket
      onex s3 ls uploads

      # List objects with prefix
      onex s3 ls uploads/images/

      # List recursively
      onex s3 ls uploads -r

      # Output as JSON
      onex s3 ls uploads --json

    \b
    Claude MCP:
      "What S3 buckets do we have?"        -> onex_s3_ls()
      "List files in uploads"              -> onex_s3_ls(path="uploads")
      "Show all files recursively"         -> onex_s3_ls(path="uploads", recursive=True)
    """
    if env is None:
        env = get_active_environment()

    client = _get_minio_client(env)

    try:
        if path is None:
            # List buckets
            buckets = list(client.list_buckets())

            if output_json:
                result = [{
                    'name': b.name,
                    'creation_date': b.creation_date.isoformat() if b.creation_date else None,
                } for b in buckets]
                click.echo(json.dumps(result, indent=2))
                return

            if not buckets:
                print_info("No buckets found.")
                return

            click.echo(f"\n  {'Bucket':<30} {'Created'}")
            click.echo(f"  {'─' * 30} {'─' * 20}")
            for b in buckets:
                created = _format_time(b.creation_date) if b.creation_date else 'N/A'
                click.echo(f"  {b.name:<30} {created}")
            click.echo(f"\n  {len(buckets)} bucket(s)")
            click.echo(MCP_HINT)

        else:
            # Parse bucket/prefix
            parts = path.split('/', 1)
            bucket = parts[0]
            prefix = parts[1] if len(parts) > 1 else ''

            objects = list(client.list_objects(bucket, prefix=prefix or None, recursive=recursive))

            if output_json:
                result = []
                for obj in objects:
                    item = {
                        'name': obj.object_name,
                        'is_dir': obj.is_dir,
                    }
                    if not obj.is_dir:
                        item['size'] = obj.size
                        item['last_modified'] = obj.last_modified.isoformat() if obj.last_modified else None
                        item['etag'] = obj.etag
                    result.append(item)
                click.echo(json.dumps(result, indent=2))
                return

            if not objects:
                print_info(f"No objects found in {bucket}/{prefix}")
                return

            click.echo(f"\n  {'Name':<50} {'Size':>10}  {'Last Modified'}")
            click.echo(f"  {'─' * 50} {'─' * 10}  {'─' * 20}")

            dirs = 0
            files = 0
            total_size = 0

            for obj in objects:
                name = obj.object_name
                if prefix and name.startswith(prefix):
                    name = name[len(prefix):]

                if obj.is_dir:
                    dirs += 1
                    click.echo(f"  {click.style(name, fg='cyan'):<50} {'DIR':>10}  {''}".rstrip())
                else:
                    files += 1
                    size = obj.size or 0
                    total_size += size
                    modified = _format_time(obj.last_modified) if obj.last_modified else ''
                    click.echo(f"  {name:<50} {_format_object_size(size):>10}  {modified}")

            click.echo(f"\n  {files} file(s), {dirs} dir(s), {_format_object_size(total_size)} total")
            click.echo(MCP_HINT)

    except Exception as e:
        err_str = str(e)
        if 'NoSuchBucket' in err_str or 'does not exist' in err_str.lower():
            print_error(f"Bucket '{path}' does not exist")
            print_info("Use 'onex s3 ls' to list available buckets")
        elif 'Connection refused' in err_str or 'MaxRetryError' in err_str:
            print_error(f"Cannot connect to MinIO ({env})")
            print_info("Make sure platform is running: ./scripts/deploy-dev.sh status")
        else:
            print_error(f"Error: {e}")


@s3.command()
@click.argument('bucket')
@click.option('--prefix', '-p', default='', help='Key prefix to search within')
@click.option('--pattern', '-P', default=None, help='Filename pattern to match (e.g., *.jpg, report*)')
@click.option('--env', default=None, help='Environment (local/dev/staging/prod, defaults to active)')
@click.option('--limit', '-n', default=50, help='Max results (default: 50)')
@click.option('--json', 'output_json', is_flag=True, help='Output as JSON')
def search(bucket, prefix, pattern, env, limit, output_json):
    """Search objects by prefix and filename pattern.

    \b
    Examples:
      # Search all objects in a bucket
      onex s3 search uploads

      # Search by prefix
      onex s3 search uploads --prefix images/

      # Search by filename pattern
      onex s3 search uploads --pattern "*.jpg"

      # Search with prefix + pattern
      onex s3 search uploads -p documents/ -P "report*"

      # Limit results
      onex s3 search uploads -n 10

    \b
    Claude MCP:
      "Find all JPG files in uploads"      -> onex_s3_search(bucket="uploads", pattern="*.jpg")
      "Search for reports in documents/"    -> onex_s3_search(bucket="docs", prefix="reports/", pattern="*.pdf")
    """
    import fnmatch

    if env is None:
        env = get_active_environment()

    client = _get_minio_client(env)

    try:
        objects = client.list_objects(bucket, prefix=prefix or None, recursive=True)

        results = []
        for obj in objects:
            if obj.is_dir:
                continue

            # Apply filename pattern filter
            if pattern:
                filename = obj.object_name.rsplit('/', 1)[-1]
                if not fnmatch.fnmatch(filename, pattern):
                    continue

            results.append(obj)
            if len(results) >= limit:
                break

        if output_json:
            output = [{
                'name': obj.object_name,
                'size': obj.size,
                'last_modified': obj.last_modified.isoformat() if obj.last_modified else None,
                'etag': obj.etag,
            } for obj in results]
            click.echo(json.dumps(output, indent=2))
            return

        if not results:
            print_info(f"No objects found matching criteria in '{bucket}'")
            return

        click.echo(f"\n  {'Name':<50} {'Size':>10}  {'Last Modified'}")
        click.echo(f"  {'─' * 50} {'─' * 10}  {'─' * 20}")

        total_size = 0
        for obj in results:
            size = obj.size or 0
            total_size += size
            modified = _format_time(obj.last_modified) if obj.last_modified else ''
            click.echo(f"  {obj.object_name:<50} {_format_object_size(size):>10}  {modified}")

        click.echo(f"\n  {len(results)} object(s), {_format_object_size(total_size)} total")
        if len(results) >= limit:
            print_info(f"  Results limited to {limit}. Use --limit to show more.")
        click.echo(MCP_HINT)

    except Exception as e:
        err_str = str(e)
        if 'NoSuchBucket' in err_str:
            print_error(f"Bucket '{bucket}' does not exist")
        elif 'Connection refused' in err_str or 'MaxRetryError' in err_str:
            print_error(f"Cannot connect to MinIO ({env})")
            print_info("Make sure platform is running")
        else:
            print_error(f"Error: {e}")


@s3.command()
@click.argument('path')
@click.option('--output', '-o', default=None, help='Output file path (default: original filename)')
@click.option('--env', default=None, help='Environment (local/dev/staging/prod, defaults to active)')
def get(path, output, env):
    """Download an object from S3/MinIO.

    PATH should be in the format: bucket/key

    \b
    Examples:
      # Download a file
      onex s3 get uploads/images/photo.jpg

      # Download to specific path
      onex s3 get uploads/report.pdf -o /tmp/report.pdf

    \b
    Note: Download is CLI-only (not available via MCP).
    Use 'onex s3 browse' for interactive download.
    """
    if env is None:
        env = get_active_environment()

    client = _get_minio_client(env)

    # Parse bucket/key
    parts = path.split('/', 1)
    if len(parts) < 2 or not parts[1]:
        print_error("Path must be in format: bucket/key")
        print_info("Example: onex s3 get uploads/images/photo.jpg")
        return

    bucket = parts[0]
    key = parts[1]

    # Determine output path
    if output is None:
        output = key.rsplit('/', 1)[-1]  # Use filename from key

    try:
        # Get object info first
        stat = client.stat_object(bucket, key)
        size = stat.size or 0

        click.echo(f"  Downloading {bucket}/{key} ({_format_object_size(size)})...")

        client.fget_object(bucket, key, output)
        print_success(f"  Saved to: {output}")

    except Exception as e:
        err_str = str(e)
        if 'NoSuchKey' in err_str or 'not found' in err_str.lower():
            print_error(f"Object not found: {bucket}/{key}")
        elif 'NoSuchBucket' in err_str:
            print_error(f"Bucket '{bucket}' does not exist")
        elif 'Connection refused' in err_str or 'MaxRetryError' in err_str:
            print_error(f"Cannot connect to MinIO ({env})")
            print_info("Make sure platform is running")
        else:
            print_error(f"Error: {e}")


@s3.command()
@click.argument('path')
@click.option('--env', default=None, help='Environment (local/dev/staging/prod, defaults to active)')
@click.option('--json', 'output_json', is_flag=True, help='Output as JSON')
def info(path, env, output_json):
    """Get detailed metadata for an object.

    PATH should be in the format: bucket/key

    \b
    Examples:
      # View object details
      onex s3 info uploads/images/photo.jpg

      # Output as JSON
      onex s3 info uploads/report.pdf --json

    \b
    Claude MCP:
      "What's the size of uploads/report.pdf?"  -> onex_s3_info(path="uploads/report.pdf")
      "Show details for this image"             -> onex_s3_info(path="uploads/images/logo.png")
    """
    if env is None:
        env = get_active_environment()

    client = _get_minio_client(env)

    # Parse bucket/key
    parts = path.split('/', 1)
    if len(parts) < 2 or not parts[1]:
        print_error("Path must be in format: bucket/key")
        print_info("Example: onex s3 info uploads/images/photo.jpg")
        return

    bucket = parts[0]
    key = parts[1]

    try:
        stat = client.stat_object(bucket, key)

        data = {
            'bucket': bucket,
            'key': key,
            'size': stat.size,
            'size_human': _format_object_size(stat.size),
            'content_type': stat.content_type,
            'etag': stat.etag,
            'last_modified': stat.last_modified.isoformat() if stat.last_modified else None,
            'metadata': dict(stat.metadata) if stat.metadata else {},
        }

        if output_json:
            click.echo(json.dumps(data, indent=2))
            return

        click.echo()
        click.echo(f"  {'Bucket:':<18} {bucket}")
        click.echo(f"  {'Key:':<18} {key}")
        click.echo(f"  {'Size:':<18} {_format_object_size(stat.size)} ({stat.size:,} bytes)")
        click.echo(f"  {'Content-Type:':<18} {stat.content_type or 'N/A'}")
        click.echo(f"  {'ETag:':<18} {stat.etag or 'N/A'}")
        click.echo(f"  {'Last Modified:':<18} {_format_time(stat.last_modified)}")

        if stat.metadata:
            click.echo(f"  {'Metadata:':<18}")
            for k, v in stat.metadata.items():
                click.echo(f"    {k}: {v}")

        click.echo()
        click.echo(MCP_HINT)

    except Exception as e:
        err_str = str(e)
        if 'NoSuchKey' in err_str or 'not found' in err_str.lower():
            print_error(f"Object not found: {bucket}/{key}")
        elif 'NoSuchBucket' in err_str:
            print_error(f"Bucket '{bucket}' does not exist")
        elif 'Connection refused' in err_str or 'MaxRetryError' in err_str:
            print_error(f"Cannot connect to MinIO ({env})")
            print_info("Make sure platform is running")
        else:
            print_error(f"Error: {e}")


TEXT_EXTENSIONS = {
    '.json', '.txt', '.md', '.yml', '.yaml', '.xml', '.csv', '.tsv',
    '.html', '.htm', '.css', '.js', '.ts', '.jsx', '.tsx', '.py',
    '.toml', '.ini', '.cfg', '.conf', '.env', '.log', '.sh', '.bash',
    '.sql', '.graphql', '.svg', '.map',
}

PAGE_SIZE = 20


def _clear_screen():
    """Clear terminal screen."""
    click.echo('\033[2J\033[H', nl=False)


def _draw_header(env, breadcrumb):
    """Draw the browser header with breadcrumb."""
    click.echo()
    click.echo(click.style(f"  S3 Browser", bold=True) + click.style(f"  ({env})", fg='bright_black'))
    click.echo(click.style(f"  {breadcrumb}", fg='cyan'))
    click.echo(f"  {'─' * 60}")


def _draw_footer(page, total_pages, items_count, total_size=None, hint=''):
    """Draw the browser footer with controls and pagination."""
    click.echo(f"  {'─' * 60}")

    # Pagination info
    if total_pages > 1:
        click.echo(click.style(f"  Page {page}/{total_pages} ({items_count} items)", fg='bright_black') +
                   (click.style(f"  Total: {_format_object_size(total_size)}", fg='bright_black') if total_size else ''))
    elif total_size:
        click.echo(click.style(f"  {items_count} items, {_format_object_size(total_size)} total", fg='bright_black'))

    # Controls
    controls = []
    controls.append(click.style('[num]', fg='yellow') + ' open')
    controls.append(click.style('[b]', fg='yellow') + ' back')
    if total_pages > 1:
        controls.append(click.style('[n/p]', fg='yellow') + ' next/prev page')
    controls.append(click.style('[/]', fg='yellow') + ' search')
    controls.append(click.style('[d num]', fg='yellow') + ' download')
    controls.append(click.style('[q]', fg='yellow') + ' quit')
    click.echo(f"  {' | '.join(controls)}")
    if hint:
        click.echo(click.style(f"  {hint}", fg='bright_black'))


def _preview_text_object(client, bucket, key, max_bytes=4096, max_lines=30):
    """Preview a text file's content."""
    try:
        response = client.get_object(bucket, key)
        data = response.read(max_bytes)
        response.close()
        response.release_conn()

        text = data.decode('utf-8', errors='replace')
        lines = text.splitlines()

        click.echo()
        click.echo(click.style("  Preview:", bold=True))
        click.echo(f"  {'─' * 58}")
        for i, line in enumerate(lines[:max_lines]):
            # Truncate long lines
            display = line[:100] + ('...' if len(line) > 100 else '')
            line_num = click.style(f'{i + 1:>4}', fg='bright_black')
            click.echo(f"  {line_num} | {display}")

        if len(lines) > max_lines:
            click.echo(click.style(f"  ... ({len(lines) - max_lines} more lines)", fg='bright_black'))
        if len(data) >= max_bytes:
            click.echo(click.style(f"  ... (truncated at {max_bytes // 1024}KB)", fg='bright_black'))
        click.echo(f"  {'─' * 58}")

    except Exception as e:
        click.echo(click.style(f"  (preview unavailable: {e})", fg='bright_black'))


@s3.command()
@click.argument('start_path', required=False, default=None)
@click.option('--env', default=None, help='Environment (local/dev/staging/prod, defaults to active)')
def browse(start_path, env):
    """Interactive browser for exploring S3/MinIO storage.

    Navigate buckets and objects with pagination, search, and file preview.

    \b
    Controls:
      [number]    Open bucket/directory or view file details
      [b]         Go back to parent
      [n] / [p]   Next / previous page
      [/pattern]  Search files by name in current location
      [d number]  Download a file
      [q]         Quit

    \b
    Examples:
      onex s3 browse
      onex s3 browse website-themes/themes/
      onex s3 browse --env dev

    \b
    Note: Browse is interactive CLI-only.
    For AI-assisted exploration, ask Claude:
      "What buckets do we have?"
      "Find all manifest.json files in website-themes"
      "Show details for website-themes/themes/simple/1.0.0/manifest.json"
    """
    if env is None:
        env = get_active_environment()

    client = _get_minio_client(env)

    # Parse optional start path
    current_bucket = None
    current_prefix = ''
    nav_stack = []

    if start_path:
        parts = start_path.rstrip('/').split('/', 1)
        current_bucket = parts[0]
        current_prefix = (parts[1] + '/') if len(parts) > 1 else ''
        nav_stack.append((None, ''))

    page = 1
    search_filter = None

    while True:
        try:
            _clear_screen()

            if current_bucket is None:
                # ── Bucket list ──
                buckets = list(client.list_buckets())
                if not buckets:
                    print_info("No buckets found.")
                    return

                breadcrumb = "/"
                _draw_header(env, breadcrumb)

                for i, b in enumerate(buckets, 1):
                    created = _format_time(b.creation_date) if b.creation_date else ''
                    num = click.style(f'  [{i:>2}]', fg='yellow')
                    icon = click.style(' ', fg='cyan')
                    click.echo(f"{num}{icon} {b.name:<35} {click.style(created, fg='bright_black')}")

                _draw_footer(1, 1, len(buckets))
                click.echo()

                choice = click.prompt("  >", default='q', show_default=False, prompt_suffix=' ')

                if choice.strip().lower() == 'q':
                    return

                try:
                    idx = int(choice.strip()) - 1
                    if 0 <= idx < len(buckets):
                        nav_stack.append((None, ''))
                        current_bucket = buckets[idx].name
                        current_prefix = ''
                        page = 1
                        search_filter = None
                except ValueError:
                    pass

            else:
                # ── Object list ──
                all_objects = list(client.list_objects(
                    current_bucket,
                    prefix=current_prefix or None,
                    recursive=bool(search_filter),
                ))

                # Apply search filter
                if search_filter:
                    import fnmatch
                    filtered = []
                    for obj in all_objects:
                        name = obj.object_name.rsplit('/', 1)[-1] if not obj.is_dir else obj.object_name
                        if fnmatch.fnmatch(name.lower(), f'*{search_filter.lower()}*'):
                            filtered.append(obj)
                    all_objects = filtered

                # Sort: dirs first, then files by name
                dirs = [o for o in all_objects if o.is_dir]
                files = [o for o in all_objects if not o.is_dir]
                items = dirs + files

                total_size = sum(o.size or 0 for o in files)
                total_pages = max(1, (len(items) + PAGE_SIZE - 1) // PAGE_SIZE)
                page = max(1, min(page, total_pages))

                # Breadcrumb
                breadcrumb_parts = [current_bucket]
                if current_prefix:
                    breadcrumb_parts.extend(current_prefix.rstrip('/').split('/'))
                breadcrumb = " / ".join(breadcrumb_parts)

                _draw_header(env, breadcrumb)

                if search_filter:
                    click.echo(click.style(f"  Filter: *{search_filter}*", fg='green') +
                               click.style("  (clear with /)", fg='bright_black'))
                    click.echo()

                if not items:
                    if search_filter:
                        print_info(f"  No matches for '{search_filter}'")
                    else:
                        print_info("  (empty)")
                else:
                    # Paginated display
                    start = (page - 1) * PAGE_SIZE
                    end = start + PAGE_SIZE
                    page_items = items[start:end]

                    for i, obj in enumerate(page_items, start + 1):
                        name = obj.object_name
                        if current_prefix and name.startswith(current_prefix) and not search_filter:
                            name = name[len(current_prefix):]

                        num = click.style(f'  [{i:>3}]', fg='yellow')

                        if obj.is_dir:
                            icon = click.style(' ', fg='cyan')
                            click.echo(f"{num}{icon} {click.style(name, fg='cyan')}")
                        else:
                            size = _format_object_size(obj.size)
                            modified = _format_time(obj.last_modified) if obj.last_modified else ''
                            # File type icon
                            ext = os.path.splitext(name)[1].lower()
                            if ext in ('.zip', '.gz', '.tar', '.rar'):
                                icon = ' '
                            elif ext in ('.jpg', '.jpeg', '.png', '.gif', '.svg', '.webp'):
                                icon = ' '
                            elif ext in ('.js', '.ts', '.py', '.go', '.java'):
                                icon = ' '
                            elif ext in ('.json', '.yml', '.yaml', '.xml', '.toml'):
                                icon = ' '
                            else:
                                icon = ' '
                            click.echo(f"{num}{icon} {name:<42} {click.style(size, fg='bright_black'):>18}  {click.style(modified, fg='bright_black')}")

                _draw_footer(page, total_pages, len(items), total_size,
                             hint='Type / followed by text to search' if not search_filter else '')
                click.echo()

                choice = click.prompt("  >", default='b', show_default=False, prompt_suffix=' ').strip()

                if not choice:
                    continue

                # Quit
                if choice.lower() == 'q':
                    return

                # Back
                if choice.lower() == 'b':
                    search_filter = None
                    page = 1
                    if nav_stack:
                        current_bucket, current_prefix = nav_stack.pop()
                    else:
                        current_bucket = None
                        current_prefix = ''
                    continue

                # Next page
                if choice.lower() == 'n':
                    if page < total_pages:
                        page += 1
                    continue

                # Previous page
                if choice.lower() == 'p':
                    if page > 1:
                        page -= 1
                    continue

                # Search
                if choice.startswith('/'):
                    query = choice[1:].strip()
                    if query:
                        search_filter = query
                    else:
                        search_filter = None  # Clear filter
                    page = 1
                    continue

                # Download: "d 3" or "d3"
                if choice.lower().startswith('d'):
                    num_str = choice[1:].strip()
                    try:
                        idx = int(num_str) - 1
                        if 0 <= idx < len(items) and not items[idx].is_dir:
                            obj = items[idx]
                            filename = obj.object_name.rsplit('/', 1)[-1]
                            output_path = click.prompt("  Save as", default=filename)
                            click.echo(f"  Downloading ({_format_object_size(obj.size)})...")
                            client.fget_object(current_bucket, obj.object_name, output_path)
                            print_success(f"  Saved to: {output_path}")
                            click.prompt("  Press Enter to continue", default='', show_default=False)
                        elif 0 <= idx < len(items):
                            print_warning("  Cannot download a directory")
                            click.prompt("  Press Enter to continue", default='', show_default=False)
                    except ValueError:
                        pass
                    continue

                # Select by number
                try:
                    idx = int(choice) - 1
                    if 0 <= idx < len(items):
                        selected = items[idx]
                        if selected.is_dir:
                            nav_stack.append((current_bucket, current_prefix))
                            current_prefix = selected.object_name
                            page = 1
                            search_filter = None
                        else:
                            # ── File detail view ──
                            _clear_screen()
                            stat = client.stat_object(current_bucket, selected.object_name)

                            click.echo()
                            click.echo(click.style("  File Details", bold=True))
                            click.echo(f"  {'─' * 58}")
                            click.echo(f"  {'Bucket:':<18} {current_bucket}")
                            click.echo(f"  {'Key:':<18} {selected.object_name}")
                            click.echo(f"  {'Size:':<18} {_format_object_size(stat.size)} ({stat.size:,} bytes)")
                            click.echo(f"  {'Content-Type:':<18} {stat.content_type or 'N/A'}")
                            click.echo(f"  {'ETag:':<18} {stat.etag or 'N/A'}")
                            click.echo(f"  {'Last Modified:':<18} {_format_time(stat.last_modified)}")

                            # Preview text files
                            ext = os.path.splitext(selected.object_name)[1].lower()
                            content_type = stat.content_type or ''
                            if ext in TEXT_EXTENSIONS or content_type.startswith('text/') or content_type == 'application/json':
                                if (stat.size or 0) <= 512 * 1024:  # Only preview files up to 512KB
                                    _preview_text_object(client, current_bucket, selected.object_name)

                            click.echo()
                            click.echo(f"  {click.style('[d]', fg='yellow')} download  {click.style('[b]', fg='yellow')} back")
                            click.echo()
                            action = click.prompt("  >", default='b', show_default=False, prompt_suffix=' ').strip().lower()

                            if action == 'd':
                                filename = selected.object_name.rsplit('/', 1)[-1]
                                output_path = click.prompt("  Save as", default=filename)
                                click.echo(f"  Downloading ({_format_object_size(stat.size)})...")
                                client.fget_object(current_bucket, selected.object_name, output_path)
                                print_success(f"  Saved to: {output_path}")
                                click.prompt("  Press Enter to continue", default='', show_default=False)
                except ValueError:
                    pass

        except KeyboardInterrupt:
            click.echo()
            return
        except Exception as e:
            err_str = str(e)
            if 'Connection refused' in err_str or 'MaxRetryError' in err_str:
                print_error(f"\n  Lost connection to MinIO ({env})")
                return
            print_error(f"\n  Error: {e}")
            click.prompt("  Press Enter to continue", default='', show_default=False)
