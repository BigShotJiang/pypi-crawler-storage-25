"""
Service scaffolding command
Creates new services from templates
"""

import click
import os
import re
from datetime import datetime
from pathlib import Path
from jinja2 import Environment, FileSystemLoader, select_autoescape
import shutil


# Template configurations
TEMPLATES = {
    'rest-api': {
        'name': 'REST API',
        'description': 'Full CRUD operations with database integration',
        'use_case': 'Product catalogs, user management, data APIs'
    },
    'event-driven': {
        'name': 'Event-Driven',
        'description': 'React to events, schedules, and streams',
        'use_case': 'Notifications, data sync, scheduled reports'
    },
    'crud-service': {
        'name': 'CRUD Service',
        'description': 'Production layered architecture (models, repos, services)',
        'use_case': 'Complex business logic, enterprise applications'
    },
    'minimal': {
        'name': 'Minimal',
        'description': 'Single endpoint, quickest to deploy',
        'use_case': 'Prototypes, health checks, simple APIs'
    },
    'go-rest-api': {
        'name': 'Go REST API',
        'description': 'Full CRUD operations in Go (high performance)',
        'use_case': 'High-throughput APIs, performance-critical services'
    },
    'go-minimal': {
        'name': 'Go Minimal',
        'description': 'Single endpoint Go service',
        'use_case': 'Lightweight Go microservices, health probes'
    }
}


def validate_service_name(name):
    """
    Validate service name format
    - Must be lowercase
    - Only hyphens allowed (no underscores, no spaces)
    - 3-50 characters
    """
    if not name:
        raise click.BadParameter("Service name is required")

    if not re.match(r'^[a-z0-9-]{3,50}$', name):
        raise click.BadParameter(
            "Service name must be:\n"
            "  - Lowercase letters and numbers\n"
            "  - Hyphens allowed (no underscores)\n"
            "  - 3-50 characters\n"
            f"  Example: my-product-service"
        )

    if name.startswith('-') or name.endswith('-'):
        raise click.BadParameter("Service name cannot start or end with hyphen")

    return name


def to_snake_case(name):
    """Convert kebab-case to snake_case"""
    return name.replace('-', '_')


def render_template(template_path, context):
    """Render Jinja2 template with context"""
    env = Environment(
        loader=FileSystemLoader(os.path.dirname(template_path)),
        autoescape=select_autoescape(),
        keep_trailing_newline=True
    )
    template = env.get_template(os.path.basename(template_path))
    return template.render(**context)


def copy_template_directory(template_dir, output_dir, context):
    """
    Recursively copy template directory and render all .j2 files
    """
    created_files = []

    for root, dirs, files in os.walk(template_dir):
        # Calculate relative path from template dir
        rel_path = os.path.relpath(root, template_dir)
        target_dir = output_dir if rel_path == '.' else os.path.join(output_dir, rel_path)

        # Create target directory
        os.makedirs(target_dir, exist_ok=True)

        # Process files
        for filename in files:
            source_file = os.path.join(root, filename)

            # Check if it's a Jinja2 template
            if filename.endswith('.j2'):
                # Render template
                rendered_content = render_template(source_file, context)

                # Remove .j2 extension for target file
                target_filename = filename[:-3]
                target_file = os.path.join(target_dir, target_filename)

                # Write rendered content
                with open(target_file, 'w') as f:
                    f.write(rendered_content)

                created_files.append(target_file)
            else:
                # Copy non-template files as-is
                target_file = os.path.join(target_dir, filename)
                shutil.copy2(source_file, target_file)
                created_files.append(target_file)

    return created_files


@click.command()
@click.option('--name', '-n', help='Service name (kebab-case)')
@click.option('--template', '-t', type=click.Choice(list(TEMPLATES.keys())), help='Template type')
@click.option('--description', '-d', help='Service description')
@click.option('--output', '-o', help='Output directory (default: ./services/<name>)')
@click.option('--author', '-a', help='Author/team name (default: platform-team)')
@click.option('--no-validate', is_flag=True, help='Skip validation after creation')
def create(name, template, description, output, author, no_validate):
    """
    Create new service from template

    Examples:
      onex create                          # Interactive mode
      onex create -n my-service -t rest-api
      onex create --name product --template crud-service --description "Product catalog"
    """

    click.echo("🚀 OneXEOS Service Scaffolding\n")

    # Interactive prompts if not provided
    if not name:
        name = click.prompt(
            "Service name (kebab-case, e.g., my-product-service)",
            type=str
        )

    # Validate service name
    try:
        name = validate_service_name(name)
    except click.BadParameter as e:
        click.echo(f"❌ {e.message}", err=True)
        raise click.Abort()

    if not template:
        click.echo("\nAvailable templates:")
        for key, info in TEMPLATES.items():
            click.echo(f"  [{key}] {info['name']}")
            click.echo(f"      {info['description']}")
            click.echo(f"      Use case: {info['use_case']}\n")

        template = click.prompt(
            "Select template",
            type=click.Choice(list(TEMPLATES.keys())),
            default='minimal'
        )

    if not description:
        description = click.prompt(
            "Service description",
            default=f"{TEMPLATES[template]['name']} service",
            type=str
        )

    if not author:
        author = click.prompt("Author/team", default="platform-team", type=str)

    # Determine output directory
    if not output:
        output = os.path.join(os.getcwd(), 'services', name)
    else:
        output = os.path.abspath(output)

    # Check if directory already exists
    if os.path.exists(output):
        click.echo(f"\n❌ Directory already exists: {output}", err=True)
        if not click.confirm("Overwrite?"):
            raise click.Abort()
        shutil.rmtree(output)

    # Prepare template context
    context = {
        'service_name': name,
        'service_name_underscore': to_snake_case(name),
        'service_description': description,
        'author': author,
        'year': datetime.now().year
    }

    # Get template directory
    cli_dir = Path(__file__).parent.parent
    template_dir = cli_dir / 'templates' / template

    if not template_dir.exists():
        click.echo(f"\n❌ Template not found: {template_dir}", err=True)
        raise click.Abort()

    # Copy and render template
    click.echo(f"\n📁 Creating service in: {output}")
    click.echo(f"📋 Template: {TEMPLATES[template]['name']}")
    click.echo(f"⚙️  Processing...\n")

    try:
        created_files = copy_template_directory(template_dir, output, context)

        click.echo(f"✅ Service created successfully!")
        click.echo(f"\n📊 Created {len(created_files)} files:")
        for file_path in sorted(created_files)[:10]:  # Show first 10
            rel_path = os.path.relpath(file_path, output)
            click.echo(f"   - {rel_path}")
        if len(created_files) > 10:
            click.echo(f"   ... and {len(created_files) - 10} more files")

    except Exception as e:
        click.echo(f"\n❌ Error creating service: {e}", err=True)
        raise click.Abort()

    # Validate service.yml
    if not no_validate:
        click.echo(f"\n🔍 Validating service.yml...")
        service_yml = os.path.join(output, 'service.yml')

        if os.path.exists(service_yml):
            try:
                # Use subprocess to call onex validate
                import subprocess
                result = subprocess.run(
                    ['onex', 'validate'],
                    cwd=output,
                    capture_output=True,
                    text=True
                )

                if result.returncode == 0:
                    click.echo("✅ Service configuration is valid!")
                else:
                    click.echo("⚠️  Validation output:")
                    if result.stdout:
                        click.echo(result.stdout)
                    if result.stderr:
                        click.echo(result.stderr)
            except Exception as e:
                click.echo(f"⚠️  Could not validate: {e}")

    # Print next steps
    click.echo(f"\n{'='*60}")
    click.echo("🎉 Next steps:")
    click.echo(f"{'='*60}")
    click.echo(f"\n  cd {os.path.relpath(output, os.getcwd())}")
    click.echo(f"  onex validate")
    click.echo(f"  onex deploy\n")

    click.echo("📚 Resources:")
    click.echo("  - Documentation: docs/service-developers/DEVELOPER_PORTAL.md")
    click.echo("  - Templates: examples/templates/README.md")
    click.echo("  - FAQ: docs/service-developers/FAQ.md")
    click.echo(f"\n{'='*60}\n")
