"""
ES command group - Elasticsearch management commands

Commands:
  status   - View es_sync trigger status, ES index health, and execution stats
  test     - Test es_sync by inserting a doc, verifying sync, then cleaning up
  reindex  - Reindex ES from MongoDB for a service's es_sync collections
"""

import click
import json
import requests
from onex.config import get_config, get_access_token, get_active_environment
from onex.utils import print_error, print_info, print_success, print_warning
from onex.utils.auth import auto_refresh_token


@click.group()
def es():
    """Elasticsearch management commands."""
    pass


def _build_headers(env):
    """Build auth headers for the given environment."""
    access_token = get_access_token(env)
    headers = {}
    if access_token:
        headers['Authorization'] = f'Bearer {access_token}'
    return headers


def _handle_auth_retry(env, headers, make_request):
    """Handle 401 with token refresh. Returns response or None."""
    if env != "local":
        print_warning("Token expired, refreshing...")
        if auto_refresh_token(env, silent=False):
            access_token = get_access_token(env)
            headers['Authorization'] = f'Bearer {access_token}'
            return make_request(headers)
        else:
            print_error("Authentication failed - could not refresh token")
            print_info(f"Please login again: onex login --env {env}")
    return None


@es.command()
@click.argument('service_name', required=False, default=None)
@click.option('--env', default=None, help='Environment (local/dev/staging/prod, defaults to active)')
@click.option('--platform-url', help='Override platform URL')
@click.option('--json', 'output_json', is_flag=True, help='Output as JSON')
def status(service_name, env, platform_url, output_json):
    """View es_sync trigger status, ES index health, and execution stats.

    Shows all es_sync triggers with their current status, ES index document counts,
    MongoDB source counts, execution stats, and recent execution logs.

    \b
    Examples:
      # View all es_sync triggers across all services
      onex es status

      # View es_sync triggers for a specific service
      onex es status crm

      # Output as JSON
      onex es status crm --json
    """
    if env is None:
        env = get_active_environment()

    config = get_config()
    base_url = platform_url or config.get_platform_url(env)
    headers = _build_headers(env)

    click.echo(f"🔍 ES Sync Status ({env})...")

    params = {}
    if service_name:
        params['service_name'] = service_name

    try:
        response = requests.get(
            f"{base_url}/_internal/es-sync",
            params=params,
            headers=headers,
            timeout=30,
        )

        if response.status_code == 401 and env != "local":
            retry_resp = _handle_auth_retry(env, headers, lambda h: requests.get(
                f"{base_url}/_internal/es-sync", params=params, headers=h, timeout=30))
            if retry_resp:
                response = retry_resp
            else:
                return

        if response.status_code == 200:
            data = response.json()

            if output_json:
                click.echo(json.dumps(data, indent=2))
                return

            total = data.get('total', 0)
            summary = data.get('summary', {})

            if total == 0:
                if service_name:
                    print_info(f"No es_sync triggers found for service '{service_name}'.")
                else:
                    print_info("No es_sync triggers registered.")
                print_info("Deploy a service with es_sync in service.yml to register triggers.")
                return

            # Summary header
            click.echo()
            active = summary.get('active', 0)
            paused = summary.get('paused', 0)
            error = summary.get('error', 0)
            total_exec = summary.get('total_executions', 0)
            total_fail = summary.get('total_failures', 0)

            click.echo(f"  Total: {total} trigger(s) | "
                       f"{click.style(f'{active} active', fg='green')} | "
                       f"{click.style(f'{paused} paused', fg='yellow') if paused else f'{paused} paused'} | "
                       f"{click.style(f'{error} error', fg='red') if error else f'{error} error'}")
            click.echo(f"  Executions: {total_exec:,} total | {total_fail:,} failures")
            click.echo()

            # Per-service details
            for svc in data.get('services', []):
                svc_name = svc.get('service_name', '?')
                triggers = svc.get('triggers', [])
                click.echo(click.style(f"  ┌─ {svc_name} ({len(triggers)} trigger(s))", fg='cyan', bold=True))

                for i, t in enumerate(triggers):
                    is_last = (i == len(triggers) - 1)
                    prefix = "  └──" if is_last else "  ├──"
                    indent = "      " if is_last else "  │   "

                    # Status indicator
                    t_status = t.get('status', 'unknown')
                    if t_status == 'active':
                        status_str = click.style('● ACTIVE', fg='green')
                    elif t_status == 'paused':
                        status_str = click.style('○ PAUSED', fg='yellow')
                    else:
                        status_str = click.style('✖ ERROR', fg='red')

                    collection = t.get('collection', '?')
                    index = t.get('index', '?')
                    click.echo(f"{prefix} {collection} → {index}  {status_str}")

                    # ES index info
                    es_info = t.get('es_index', {})
                    mongo_count = t.get('mongo_doc_count', 0)
                    es_count = es_info.get('doc_count', 0)
                    es_size = es_info.get('size', 'N/A')
                    es_exists = es_info.get('exists', False)

                    if es_exists:
                        # Show sync ratio
                        sync_indicator = ''
                        if mongo_count > 0 and es_count > 0:
                            ratio = es_count / mongo_count * 100
                            if ratio >= 99:
                                sync_indicator = click.style(' (in sync)', fg='green')
                            elif ratio >= 80:
                                sync_indicator = click.style(f' ({ratio:.0f}% synced)', fg='yellow')
                            else:
                                sync_indicator = click.style(f' ({ratio:.0f}% synced)', fg='red')
                        click.echo(f"{indent}MongoDB: {mongo_count:,} docs | ES: {es_count:,} docs ({es_size}){sync_indicator}")
                    else:
                        click.echo(f"{indent}MongoDB: {mongo_count:,} docs | " +
                                   click.style("ES index missing!", fg='red'))

                    # Execution stats
                    exec_count = t.get('execution_count', 0)
                    fail_count = t.get('failure_count', 0)
                    last_exec = t.get('last_execution')
                    last_error = t.get('last_error')

                    exec_line = f"{indent}Executions: {exec_count:,}"
                    if fail_count > 0:
                        exec_line += f" | " + click.style(f"Failures: {fail_count:,}", fg='red')
                    if last_exec:
                        exec_line += f" | Last: {last_exec}"
                    click.echo(exec_line)

                    if last_error:
                        click.echo(f"{indent}" + click.style(f"Last error: {last_error}", fg='red'))

                    # Operations & field mapping
                    ops = t.get('operations', [])
                    if ops:
                        click.echo(f"{indent}Operations: {', '.join(ops)}")
                    fm = t.get('field_mapping')
                    if fm:
                        click.echo(f"{indent}Field mapping: {len(fm)} field(s)")

                    # Recent logs (compact)
                    recent = t.get('recent_logs', [])
                    if recent:
                        click.echo(f"{indent}Recent:")
                        for log in recent[:3]:
                            op = log.get('operation', '?')
                            ok = '✓' if log.get('success') else '✗'
                            ms = log.get('execution_time_ms', 0)
                            ts = log.get('executed_at', '')
                            if ts and len(ts) > 19:
                                ts = ts[:19]
                            color = 'green' if log.get('success') else 'red'
                            click.echo(f"{indent}  {click.style(ok, fg=color)} {op} ({ms}ms) {ts}")

                click.echo()

        elif response.status_code == 503:
            print_error("Stream Trigger Service unavailable")
            print_info("Make sure platform is running: ./scripts/deploy-dev.sh status")

        else:
            print_error(f"Failed: HTTP {response.status_code}")
            try:
                detail = response.json().get('detail', response.text)
                print_error(f"  {detail}")
            except Exception:
                pass

    except requests.exceptions.ConnectionError:
        print_error(f"Cannot connect to platform at {base_url}")
        print_info("Make sure platform is running")

    except Exception as e:
        print_error(f"Error: {e}")


@es.command()
@click.argument('service_name')
@click.option('--collection', '-c', default=None, help='Specific collection to test (all if omitted)')
@click.option('--env', default=None, help='Environment (local/dev/staging/prod, defaults to active)')
@click.option('--platform-url', help='Override platform URL')
@click.option('--json', 'output_json', is_flag=True, help='Output as JSON')
def test(service_name, collection, env, platform_url, output_json):
    """Test es_sync by inserting a doc, verifying sync, then cleaning up.

    For each es_sync trigger, this command:
    1. Checks ES index exists
    2. Inserts a test document into MongoDB
    3. Waits up to 10s for it to appear in ES via change stream
    4. Cleans up the test document from both MongoDB and ES

    \b
    Examples:
      # Test all es_sync triggers for crm service
      onex es test crm

      # Test a specific collection
      onex es test crm --collection adminService

      # Test on dev environment
      onex es test crm --env dev
    """
    if env is None:
        env = get_active_environment()

    config = get_config()
    base_url = platform_url or config.get_platform_url(env)
    headers = _build_headers(env)

    click.echo(f"🧪 Testing ES Sync for {service_name} ({env})...")
    click.echo()

    body = {'service_name': service_name}
    if collection:
        body['collection'] = collection

    try:
        response = requests.post(
            f"{base_url}/_internal/es-sync/test",
            json=body,
            headers=headers,
            timeout=120,
        )

        if response.status_code == 401 and env != "local":
            retry_resp = _handle_auth_retry(env, headers, lambda h: requests.post(
                f"{base_url}/_internal/es-sync/test", json=body, headers=h, timeout=120))
            if retry_resp:
                response = retry_resp
            else:
                return

        if response.status_code == 200:
            data = response.json()

            if output_json:
                click.echo(json.dumps(data, indent=2))
                return

            results = data.get('results', [])
            summary = data.get('summary', {})
            error = data.get('error')

            if error and not results:
                print_error(error)
                print_info("Deploy a service with es_sync in service.yml first.")
                return

            for r in results:
                coll = r.get('collection', '?')
                index = r.get('index', '?')
                passed = r.get('passed', False)
                duration = r.get('duration_ms', 0)
                steps = r.get('steps', [])

                if passed:
                    click.echo(click.style(
                        f"  ✅ {coll} → {index}: PASSED ({duration}ms)", fg='green'))
                else:
                    click.echo(click.style(
                        f"  ❌ {coll} → {index}: FAILED ({duration}ms)", fg='red'))

                for step in steps:
                    if step.startswith('OK:'):
                        click.echo(f"     {click.style('✓', fg='green')} {step[4:]}")
                    elif step.startswith('FAIL:'):
                        click.echo(f"     {click.style('✗', fg='red')} {step[6:]}")
                    elif step.startswith('WARN:'):
                        click.echo(f"     {click.style('!', fg='yellow')} {step[6:]}")
                    elif step.startswith('SKIP:'):
                        click.echo(f"     {click.style('○', fg='yellow')} {step[6:]}")
                    else:
                        click.echo(f"     {step}")

                # Show diagnostics and next steps on failure
                diagnostics = r.get('diagnostics', [])
                next_steps_list = r.get('next_steps', [])

                if diagnostics:
                    click.echo()
                    click.echo(click.style("     Diagnostics:", bold=True))
                    for d in diagnostics:
                        if d.get('passed'):
                            icon = click.style('✓', fg='green')
                        else:
                            icon = click.style('✗', fg='red')
                        click.echo(f"     {icon} {d.get('label', d.get('check', ''))}")
                        detail = d.get('detail')
                        if detail and not d.get('passed'):
                            click.echo(f"       {click.style(detail, fg='yellow')}")

                if next_steps_list:
                    click.echo()
                    click.echo(click.style("     Next Steps:", bold=True))
                    for i, step in enumerate(next_steps_list, 1):
                        click.echo(f"     {i}. {step}")

            click.echo()
            total = summary.get('total', 0)
            passed_count = summary.get('passed', 0)
            failed_count = summary.get('failed', 0)

            if failed_count == 0:
                print_success(f"All {total} es_sync trigger(s) passed")
            else:
                print_warning(f"{passed_count}/{total} passed, {failed_count} failed")

        elif response.status_code == 503:
            print_error("Stream Trigger Service unavailable")
            print_info("Make sure platform is running: ./scripts/deploy-dev.sh status")

        else:
            print_error(f"Test failed: HTTP {response.status_code}")
            try:
                detail = response.json().get('detail', response.text)
                print_error(f"  {detail}")
            except Exception:
                pass

    except requests.exceptions.ConnectionError:
        print_error(f"Cannot connect to platform at {base_url}")
        print_info("Make sure platform is running")

    except requests.exceptions.Timeout:
        print_error("Test timed out (>2 minutes)")
        print_info("This can happen if change streams are slow. Check stream-trigger logs.")

    except Exception as e:
        print_error(f"Error: {e}")


@es.command()
@click.argument('service_name')
@click.option('--collection', '-c', default=None, help='Specific collection to reindex (all if omitted)')
@click.option('--recreate', is_flag=True, help='Delete and recreate ES index with stored mappings before reindexing')
@click.option('--env', default=None, help='Environment (local/dev/staging/prod, defaults to active)')
@click.option('--platform-url', help='Override platform URL')
@click.option('--json', 'output_json', is_flag=True, help='Output as JSON')
def reindex(service_name, collection, recreate, env, platform_url, output_json):
    """Reindex Elasticsearch from MongoDB for a service.

    Reads all documents from MongoDB collections that have es_sync triggers
    registered and bulk-indexes them into Elasticsearch.

    Use --recreate to delete and recreate the ES index with correct mappings
    from the model's es_mapping before reindexing. This fixes type mismatches
    between the model definition and the actual ES index.

    \b
    Examples:
      # Reindex all ES collections for crm service
      onex es reindex crm

      # Reindex a specific collection
      onex es reindex crm --collection adminService

      # Recreate index with correct mappings, then reindex
      onex es reindex user --recreate

      # Reindex on dev environment
      onex es reindex crm --env dev
    """
    if env is None:
        env = get_active_environment()

    config = get_config()
    base_url = platform_url or config.get_platform_url(env)

    # Build auth headers
    access_token = get_access_token(env)
    headers = {}
    if access_token:
        headers['Authorization'] = f'Bearer {access_token}'

    click.echo(f"🔄 Reindexing ES for {service_name} ({env})...")

    if recreate:
        click.echo(f"  (--recreate: will delete and recreate ES index with stored mappings)")

    body = {'service_name': service_name}
    if collection:
        body['collection'] = collection
    if recreate:
        body['recreate'] = True

    try:
        response = requests.post(
            f"{base_url}/_internal/reindex",
            json=body,
            headers=headers,
            timeout=300,
        )

        if response.status_code == 401 and env != "local":
            print_warning("Token expired, refreshing...")
            if auto_refresh_token(env, silent=False):
                access_token = get_access_token(env)
                headers['Authorization'] = f'Bearer {access_token}'
                response = requests.post(
                    f"{base_url}/_internal/reindex",
                    json=body,
                    headers=headers,
                    timeout=300,
                )
            else:
                print_error("Authentication failed - could not refresh token")
                print_info(f"Please login again: onex login --env {env}")
                return

        if response.status_code == 200:
            data = response.json()

            if output_json:
                click.echo(json.dumps(data, indent=2))
                return

            collections = data.get('collections', [])
            total = data.get('total_docs_synced', 0)

            if not collections:
                print_info("No es_sync collections found for this service.")
                return

            click.echo()
            for col in collections:
                name = col.get('collection', '?')
                index = col.get('index', '?')
                docs = col.get('docs_synced', 0)
                duration = col.get('duration_ms', 0)
                error = col.get('error')

                if error:
                    click.echo(click.style(
                        f"  ❌ {name} → {index}: {error}", fg='red'))
                else:
                    click.echo(
                        f"  ✅ {name} → {index}: {docs} docs ({duration}ms)")

            click.echo()
            print_success(f"Total: {total} docs synced across {len(collections)} collection(s)")

        elif response.status_code == 404:
            print_error(response.json().get('detail', 'No es_sync triggers found'))
            print_info("Make sure the service has es_sync configured in service.yml and is deployed.")

        else:
            print_error(f"Reindex failed: HTTP {response.status_code}")
            try:
                detail = response.json().get('detail', response.text)
                print_error(f"  {detail}")
            except Exception:
                pass

    except requests.exceptions.ConnectionError:
        print_error(f"Cannot connect to platform at {base_url}")
        print_info("Make sure platform is running")

    except requests.exceptions.Timeout:
        print_error("Reindex timed out (>5 minutes)")
        print_info("This can happen with very large collections. Try reindexing one collection at a time with --collection.")

    except Exception as e:
        print_error(f"Error: {e}")


@es.command()
@click.argument('service_name', required=False, default=None)
@click.option('--env', default=None, help='Environment (local/dev/staging/prod, defaults to active)')
@click.option('--platform-url', help='Override platform URL')
@click.option('--json', 'output_json', is_flag=True, help='Output as JSON')
def mapping(service_name, env, platform_url, output_json):
    """Check ES index mappings against model definitions.

    Compares actual ES index mappings with the desired mappings stored
    during deployment. Highlights type mismatches and missing fields.

    Requires that the service has been deployed at least once with nolicore v2.7.13+
    so that es_mappings are stored in trigger metadata.

    \b
    Examples:
      # Check mappings for a specific service
      onex es mapping user

      # Check all services
      onex es mapping

      # Output as JSON
      onex es mapping user --json
    """
    if env is None:
        env = get_active_environment()

    config = get_config()
    base_url = platform_url or config.get_platform_url(env)
    headers = _build_headers(env)

    if service_name:
        click.echo(f"🔍 ES Mapping Check for {service_name} ({env})...")
    else:
        click.echo(f"🔍 ES Mapping Check ({env})...")

    params = {}
    if service_name:
        params['service_name'] = service_name

    try:
        response = requests.get(
            f"{base_url}/_internal/es-sync/mapping",
            params=params,
            headers=headers,
            timeout=30,
        )

        if response.status_code == 401 and env != "local":
            retry_resp = _handle_auth_retry(env, headers, lambda h: requests.get(
                f"{base_url}/_internal/es-sync/mapping", params=params, headers=h, timeout=30))
            if retry_resp:
                response = retry_resp
            else:
                return

        if response.status_code == 200:
            data = response.json()

            if output_json:
                click.echo(json.dumps(data, indent=2))
                return

            indices = data.get('indices', [])
            error = data.get('error')

            if error and not indices:
                print_info(error)
                print_info("Deploy a service with es_sync in service.yml first.")
                return

            click.echo()

            for idx_info in indices:
                svc = idx_info.get('service_name', '?')
                collection = idx_info.get('collection', '?')
                index = idx_info.get('index', '?')
                fields = idx_info.get('fields', [])
                idx_error = idx_info.get('error')
                mismatches = idx_info.get('mismatches', 0)
                missing = idx_info.get('missing_in_es', 0)
                has_mappings = idx_info.get('has_stored_mappings', False)

                click.echo(click.style(f"  ┌─ {svc}: {collection} → {index}", fg='cyan', bold=True))

                if idx_error:
                    click.echo(f"  │   " + click.style(idx_error, fg='red'))
                elif not has_mappings:
                    click.echo(f"  │   " + click.style("No es_mappings stored — redeploy service to populate", fg='yellow'))
                else:
                    for f in fields:
                        field_name = f.get('field', '?')
                        desired = f.get('desired', '?')
                        actual = f.get('actual')
                        status = f.get('status', '?')

                        # Pad field name for alignment
                        padded = field_name.ljust(24)

                        if status == 'match':
                            icon = click.style('✓', fg='green')
                            click.echo(f"  │   {padded} {desired.ljust(16)} {icon} match")
                        elif status == 'mismatch':
                            icon = click.style('✗', fg='red')
                            click.echo(f"  │   {padded} {desired.ljust(16)} {icon} "
                                       + click.style(f"MISMATCH (ES: {actual})", fg='red'))
                        elif status == 'missing_in_es':
                            icon = click.style('?', fg='yellow')
                            click.echo(f"  │   {padded} {desired.ljust(16)} {icon} "
                                       + click.style("missing in ES", fg='yellow'))

                    if mismatches > 0:
                        click.echo(f"  │")
                        click.echo(f"  │   " + click.style(
                            f"{mismatches} field(s) have type mismatches", fg='red'))
                        click.echo(f"  │   Fix: " + click.style(
                            f"onex es reindex {svc} --recreate", fg='yellow'))
                    elif missing > 0:
                        click.echo(f"  │")
                        click.echo(f"  │   " + click.style(
                            f"{missing} field(s) missing in ES (will be added on next deploy)", fg='yellow'))
                    else:
                        click.echo(f"  │")
                        click.echo(f"  │   " + click.style("All fields match", fg='green'))

                click.echo(f"  └──")
                click.echo()

            # Summary
            total_m = data.get('total_mismatches', 0)
            total_missing = data.get('total_missing', 0)
            if total_m == 0 and total_missing == 0:
                print_success(f"All {len(indices)} index(es) have correct mappings")
            else:
                if total_m > 0:
                    print_warning(f"{total_m} field(s) with type mismatches across {len(indices)} index(es)")
                if total_missing > 0:
                    print_info(f"{total_missing} field(s) missing in ES")

        elif response.status_code == 503:
            print_error("Stream Trigger Service unavailable")
            print_info("Make sure platform is running: ./scripts/deploy-dev.sh status")

        else:
            print_error(f"Failed: HTTP {response.status_code}")
            try:
                detail = response.json().get('detail', response.text)
                print_error(f"  {detail}")
            except Exception:
                pass

    except requests.exceptions.ConnectionError:
        print_error(f"Cannot connect to platform at {base_url}")
        print_info("Make sure platform is running")

    except Exception as e:
        print_error(f"Error: {e}")
