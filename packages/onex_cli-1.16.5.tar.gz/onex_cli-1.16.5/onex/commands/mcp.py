"""
OneX MCP Server Configuration Commands

Manages Model Context Protocol (MCP) server setup for Claude Code/Desktop.
Automatically configures Claude to use OneX CLI tools as AI-accessible debugging tools.

Commands:
  onex mcp setup   - Auto-configure MCP server (one-time setup)
  onex mcp remove  - Remove MCP server configuration
  onex mcp status  - Check MCP server configuration status
"""

import sys
import subprocess
import json
import click
from pathlib import Path
from onex.utils import print_success, print_error, print_info, print_warning


def _run_claude_cli(args, timeout=10):
    """Run claude CLI command, handling Windows PATH resolution.

    On Windows, subprocess.run without shell=True cannot find .cmd/.bat
    executables in PATH. We try without shell first (safer), then fall
    back to shell=True on Windows if needed.
    """
    try:
        return subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=timeout
        )
    except FileNotFoundError:
        if sys.platform == 'win32':
            # Windows: .cmd/.bat files need shell=True to resolve via PATH
            return subprocess.run(
                args,
                capture_output=True,
                text=True,
                timeout=timeout,
                shell=True
            )
        raise


def _get_claude_settings_path():
    """Get the path to Claude Code's settings JSON file.

    Returns the path to the user-scope MCP settings file, or None if
    the Claude config directory doesn't exist.
    """
    if sys.platform == 'win32':
        # Windows: %APPDATA%\Claude\claude_desktop_config.json (Claude Desktop)
        # or %USERPROFILE%\.claude\settings.json (Claude Code)
        import os
        appdata = os.environ.get('APPDATA', '')
        home = Path.home()

        # Claude Code settings (preferred)
        claude_code_settings = home / '.claude' / 'settings.json'
        if claude_code_settings.parent.exists():
            return claude_code_settings

        # Claude Desktop config
        claude_desktop_config = Path(appdata) / 'Claude' / 'claude_desktop_config.json'
        if claude_desktop_config.parent.exists():
            return claude_desktop_config

        # Default to Claude Code path (will be created)
        return claude_code_settings
    else:
        # macOS/Linux: ~/.claude/settings.json
        return Path.home() / '.claude' / 'settings.json'


def _configure_mcp_via_json(onex_mcp_path):
    """Directly write MCP server config to Claude's settings JSON.

    Fallback method when `claude` CLI is not available. Writes the MCP
    server configuration directly to Claude Code's settings.json file.

    Returns True on success, False on failure.
    """
    settings_path = _get_claude_settings_path()
    if not settings_path:
        return False

    try:
        # Read existing settings or start fresh
        if settings_path.exists():
            with open(settings_path, 'r') as f:
                settings = json.load(f)
        else:
            settings = {}

        # Ensure mcpServers section exists
        if 'mcpServers' not in settings:
            settings['mcpServers'] = {}

        # Add onex-platform MCP server (includes both platform tools + rocket code graph tools)
        settings['mcpServers']['onex-platform'] = {
            'command': str(onex_mcp_path),
            'args': [],
            'type': 'stdio'
        }

        # Write settings
        settings_path.parent.mkdir(parents=True, exist_ok=True)
        with open(settings_path, 'w') as f:
            json.dump(settings, f, indent=2)

        return True
    except Exception:
        return False


@click.group()
def mcp():
    """Configure MCP server for Claude Code/Desktop"""
    pass


@mcp.command()
def setup():
    """
    Auto-configure OneX MCP server for Claude Code.

    This command:
    1. Auto-detects onex-mcp installation path
    2. Configures Claude Code to use OneX tools
    3. Runs only once (uses marker file)

    After setup, Claude can debug your platform with natural language:
      - "Is my platform healthy?"
      - "Debug this API failure, trace_id: abc123"
      - "Show me email-service logs"
    """
    from onex.config import get_onex_dir

    # Check if already configured
    config_dir = get_onex_dir()
    marker_file = config_dir / '.mcp_setup_done'

    if marker_file.exists():
        print_info("✅ MCP server already configured")
        print_info("   Run 'onex mcp status' to verify")
        print_info("   Run 'onex mcp remove' to reconfigure")
        return

    click.echo()
    print_info("🔧 Setting up OneX MCP Server for Claude Code...")
    click.echo()

    # Step 1: Check MCP package is installed
    try:
        import mcp
        print_success("✓ MCP package found")
    except ImportError:
        print_error("✗ MCP package not installed")
        print_info("  Install with: pip install -e '../onexeos-platform/onex-cli[mcp]'")
        sys.exit(1)

    # Step 2: Auto-detect onex-mcp path
    # When installed via pip install -e, the shebang uses venv's Python
    # So we can find onex-mcp in the same bin directory as current Python
    python_exe = Path(sys.executable)
    bin_dir = python_exe.parent

    # Windows uses .exe extension, Unix doesn't
    if sys.platform == 'win32':
        onex_mcp_path = bin_dir / 'onex-mcp.exe'
    else:
        onex_mcp_path = bin_dir / 'onex-mcp'

    if not onex_mcp_path.exists():
        print_error(f"✗ onex-mcp not found at: {onex_mcp_path}")
        print_info("  Make sure you installed with: pip install onex-cli")
        sys.exit(1)

    print_success(f"✓ Found onex-mcp at: {onex_mcp_path}")

    # Step 3: Check if claude CLI is available
    claude_cli_available = False
    try:
        result = _run_claude_cli(['claude', 'mcp', 'list'])
        print_success("✓ Claude Code CLI found")
        claude_cli_available = True
    except FileNotFoundError:
        print_warning("⚠ Claude Code CLI not found in PATH")
        print_info("  Will configure MCP via settings file instead")
    except subprocess.TimeoutExpired:
        print_warning("⚠ Claude Code CLI responding slowly")
        print_info("  Will configure MCP via settings file instead")

    # Step 4: Add MCP server to Claude Code
    # Only onex-platform is needed — it includes both platform debugging tools (12)
    # AND code graph tools (17 rocket_* tools) via HTTP API to 10.0.0.3:7432.
    # No separate onex-rocket binary required.
    if claude_cli_available:
        # Method A: Use claude CLI (preferred)
        try:
            print_info(f"  Adding onex-platform MCP server via CLI...")

            cmd = [
                'claude', 'mcp', 'add',
                '--transport', 'stdio',
                '--scope', 'user',
                'onex-platform',
                '--',
                str(onex_mcp_path)
            ]

            result = _run_claude_cli(cmd, timeout=30)

            if result.returncode == 0:
                print_success("✓ MCP server configured successfully")
            else:
                # Check if already exists
                if 'already exists' in result.stderr.lower() or 'already exists' in result.stdout.lower():
                    print_warning("⚠ MCP server 'onex-platform' already exists")
                    print_info("  Run 'onex mcp remove' first to reconfigure")
                else:
                    print_error(f"✗ Failed to add MCP server via CLI")
                    print_info(f"  Error: {result.stderr or result.stdout}")
                    print_info("  Falling back to settings file...")
                    # Fall back to JSON method
                    if _configure_mcp_via_json(onex_mcp_path):
                        settings_path = _get_claude_settings_path()
                        print_success(f"✓ MCP server configured via {settings_path}")
                    else:
                        print_error("✗ Failed to configure MCP server")
                        sys.exit(1)

        except subprocess.TimeoutExpired:
            print_error("✗ Claude Code CLI timed out, falling back to settings file...")
            if _configure_mcp_via_json(onex_mcp_path):
                settings_path = _get_claude_settings_path()
                print_success(f"✓ MCP server configured via {settings_path}")
            else:
                print_error("✗ Failed to configure MCP server")
                sys.exit(1)
        except Exception as e:
            print_error(f"✗ CLI method failed: {e}")
            print_info("  Falling back to settings file...")
            if _configure_mcp_via_json(onex_mcp_path):
                settings_path = _get_claude_settings_path()
                print_success(f"✓ MCP server configured via {settings_path}")
            else:
                print_error(f"✗ Failed to configure MCP server")
                sys.exit(1)
    else:
        # Method B: Direct JSON configuration (fallback for Windows / CLI not in PATH)
        print_info(f"  Adding onex-platform MCP server via settings file...")
        if _configure_mcp_via_json(onex_mcp_path):
            settings_path = _get_claude_settings_path()
            print_success(f"✓ MCP server configured via {settings_path}")
        else:
            print_error("✗ Failed to configure MCP server")
            print_info("  Manual setup: Add to Claude Code settings.json:")
            print_info(f'    "mcpServers": {{"onex-platform": {{"command": "{onex_mcp_path}", "args": [], "type": "stdio"}}}}')
            sys.exit(1)

    # Step 5: Mark as done
    config_dir.mkdir(parents=True, exist_ok=True)
    marker_file.touch()

    # Step 6: Show success message
    click.echo()
    print_success("🎉 OneX MCP Server configured successfully!")
    click.echo()
    print_info("Includes:")
    print_info("  • Platform debugging tools (12) — logs, trace, status, deploy, etc.")
    print_info("  • Code graph tools (17)         — dead code, hotspots, dependencies, etc.")
    print_info("    (via onex-rocket API at 10.0.0.3:7432 — no local binary needed)")
    click.echo()
    print_info("Next steps:")
    print_info("  1. Restart Claude Code completely")
    print_info("  2. Open Claude Code and type: /mcp")
    print_info("  3. You should see 'onex-platform' with 29 tools")
    click.echo()
    print_info("Example usage in Claude Code:")
    print_info('  "Is my platform healthy?"')
    print_info('  "Debug trace_id: 550e8400-e29b-41d4-a716-446655440000"')
    print_info('  "Find dead code in onexerp-platform"')
    click.echo()
    print_info("Run 'onex mcp status' to verify configuration")
    click.echo()


@mcp.command()
def remove():
    """
    Remove OneX MCP server from Claude Code.

    Useful for:
    - Reconfiguring with different settings
    - Uninstalling MCP server
    - Troubleshooting issues
    """
    from onex.config import get_onex_dir

    click.echo()
    print_info("🗑️  Removing OneX MCP Server...")
    click.echo()

    # Remove from Claude Code (try CLI first, then JSON fallback)
    cli_removed = False
    try:
        result = _run_claude_cli(['claude', 'mcp', 'remove', 'onex-platform'], timeout=30)

        if result.returncode == 0:
            print_success("✓ MCP server removed from Claude Code")
            cli_removed = True
        else:
            if 'not found' in result.stderr.lower() or 'not found' in result.stdout.lower():
                print_warning("⚠ MCP server 'onex-platform' not found (already removed)")
                cli_removed = True
            else:
                print_error(f"✗ Failed to remove MCP server via CLI")
                print_info(f"  Error: {result.stderr or result.stdout}")

    except FileNotFoundError:
        print_warning("⚠ Claude Code CLI not found, removing from settings file...")
    except subprocess.TimeoutExpired:
        print_warning("⚠ Claude Code CLI timed out, removing from settings file...")
    except Exception as e:
        print_warning(f"⚠ CLI removal failed: {e}")

    # Also remove from settings JSON (covers direct-config installs)
    if not cli_removed:
        settings_path = _get_claude_settings_path()
        if settings_path and settings_path.exists():
            try:
                with open(settings_path, 'r') as f:
                    settings = json.load(f)
                if 'mcpServers' in settings and 'onex-platform' in settings['mcpServers']:
                    del settings['mcpServers']['onex-platform']
                    with open(settings_path, 'w') as f:
                        json.dump(settings, f, indent=2)
                    print_success(f"✓ MCP server removed from {settings_path}")
                else:
                    print_warning("⚠ MCP server 'onex-platform' not found in settings file")
            except Exception as e:
                print_error(f"✗ Failed to remove from settings file: {e}")
                sys.exit(1)
        else:
            print_warning("⚠ No Claude settings file found")

    # Remove marker file
    config_dir = get_onex_dir()
    marker_file = config_dir / '.mcp_setup_done'
    if marker_file.exists():
        marker_file.unlink()
        print_success("✓ Cleared setup marker")

    click.echo()
    print_success("✅ OneX MCP Server removed")
    print_info("   Run 'onex mcp setup' to reconfigure")
    click.echo()


@mcp.command()
def status():
    """
    Check OneX MCP server configuration status.

    Shows:
    - Whether MCP server is configured
    - Installation path
    - Claude Code connection status
    - Available tools
    """
    click.echo()
    print_info("📊 OneX MCP Server Status")
    click.echo()

    # Check if onex-mcp is installed
    python_exe = Path(sys.executable)
    bin_dir = python_exe.parent

    # Windows uses .exe extension, Unix doesn't
    if sys.platform == 'win32':
        onex_mcp_path = bin_dir / 'onex-mcp.exe'
    else:
        onex_mcp_path = bin_dir / 'onex-mcp'

    if onex_mcp_path.exists():
        print_success(f"✓ onex-mcp installed: {onex_mcp_path}")
    else:
        print_error(f"✗ onex-mcp not found")
        print_info("  Install with: pip install -e '../onexeos-platform/onex-cli[mcp]'")
        click.echo()
        return

    # Check MCP package
    try:
        import mcp
        # MCP package doesn't expose __version__, just check it's installed
        print_success("✓ MCP package installed")
    except ImportError:
        print_error("✗ MCP package not installed")
        print_info("  Install with: pip install onex-cli")
        click.echo()
        return

    # Check Claude Code configuration (try CLI first, then settings file)
    config_found = False
    try:
        result = _run_claude_cli(['claude', 'mcp', 'get', 'onex-platform'])

        if result.returncode == 0:
            print_success("✓ MCP server configured in Claude Code")
            config_found = True
            click.echo()
            print_info("Configuration details:")
            # Show the output from claude mcp get
            for line in result.stdout.strip().split('\n'):
                print_info(f"  {line}")
        else:
            print_warning("⚠ MCP server not configured via Claude CLI")

    except FileNotFoundError:
        print_warning("⚠ Claude Code CLI not found")
    except subprocess.TimeoutExpired:
        print_warning("⚠ Claude Code CLI responding slowly")
    except Exception as e:
        print_warning(f"⚠ Could not check via CLI: {e}")

    # Also check settings JSON file
    if not config_found:
        settings_path = _get_claude_settings_path()
        if settings_path and settings_path.exists():
            try:
                with open(settings_path, 'r') as f:
                    settings = json.load(f)
                if 'mcpServers' in settings and 'onex-platform' in settings['mcpServers']:
                    print_success(f"✓ MCP server configured in {settings_path}")
                    config_found = True
                    click.echo()
                    print_info("Configuration details:")
                    config = settings['mcpServers']['onex-platform']
                    print_info(f"  command: {config.get('command', 'N/A')}")
                    print_info(f"  args: {config.get('args', [])}")
                    print_info(f"  type: {config.get('type', 'stdio')}")
            except Exception:
                pass

        if not config_found:
            print_warning("⚠ MCP server not configured")
            print_info("  Run 'onex mcp setup' to configure")

    click.echo()
    print_info("Platform debugging tools (12):")
    print_info("  • onex_platform_check - Platform health")
    print_info("  • onex_trace          - Request tracing")
    print_info("  • onex_logs           - Service logs")
    print_info("  • onex_status         - Deployment status")
    print_info("  • onex_reload         - Force reload service")
    print_info("  • onex_invoke         - Invoke handlers")
    print_info("  • onex_es_reindex     - ES reindex from MongoDB")
    print_info("  • onex_validate       - Validate config")
    print_info("  • onex_create         - Service scaffolding")
    print_info("  • onex_replay         - Replay captured request")
    print_info("  • onex_test           - Run E2E tests")
    print_info("  • onex_create_e2e     - Scaffold E2E tests")
    click.echo()
    print_info("Code graph tools (17, via onex-rocket API at 10.0.0.3:7432):")
    print_info("  • rocket_stats, rocket_find_symbol, rocket_find_dead_code")
    print_info("  • rocket_find_hotspots, rocket_find_cycles, rocket_get_repo_map")
    print_info("  • rocket_get_dependencies, rocket_get_dependents, rocket_get_impact")
    print_info("  • rocket_get_references, rocket_get_symbol_context")
    print_info("  • rocket_get_usage_examples, rocket_get_test_coverage")
    print_info("  • rocket_trace_path, rocket_rename_impact, rocket_get_file_churn")
    print_info("  • rocket_index")
    click.echo()
    print_info("Documentation:")
    print_info("  onex-cli/onex/mcp/README.md")
    print_info("  onex-cli/onex/mcp/SERVICE_DEVELOPER_GUIDE.md")
    click.echo()


if __name__ == '__main__':
    mcp()
