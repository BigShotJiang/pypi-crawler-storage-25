#!/usr/bin/env python3
"""
OneXEOS Shared Runtime - LOCAL DEVELOPMENT VERSION

This is a modified version of runtime.py for local development WITHOUT Docker.

Key Differences from Production:
- Uses ./services/ instead of /app/services/
- Auto-adds libs/ to Python path
- Environment variables from .env file
- Enhanced debug logging
- No sudo/root required
- Supports debugpy for VS Code debugging

Usage:
    python runtime_local.py

    # Or with custom port
    PORT=8001 python runtime_local.py

    # With debugpy for VS Code debugging
    ENABLE_DEBUGPY=true python runtime_local.py
"""
import os
import sys
import yaml
import importlib
import traceback
from pathlib import Path
from typing import Dict, Any, Callable
from datetime import datetime

# Initialize debugpy if requested
DEBUGPY_ENABLED = os.getenv('ENABLE_DEBUGPY', 'false').lower() == 'true'
DEBUGPY_PORT = int(os.getenv('DEBUGPY_PORT', '5678'))

if DEBUGPY_ENABLED:
    try:
        import debugpy
        debugpy.listen(("0.0.0.0", DEBUGPY_PORT))
        print(f"🐛 debugpy listening on port {DEBUGPY_PORT}")
        print(f"   Attach VS Code debugger to continue")
        print(f"   VS Code: Run 'Attach to Runtime' debug configuration")

        # Optional: Wait for debugger to attach before continuing
        if os.getenv('DEBUGPY_WAIT', 'false').lower() == 'true':
            print(f"⏳ Waiting for debugger to attach...")
            debugpy.wait_for_client()
            print(f"✅ Debugger attached!")
    except ImportError:
        print("⚠️  debugpy not installed - visual debugging disabled")
        print("    Install: pip install debugpy")
        DEBUGPY_ENABLED = False

# Load environment variables from .env
try:
    from dotenv import load_dotenv
    env_file = Path(__file__).parent / '.env'
    if env_file.exists():
        load_dotenv(env_file)
        print(f"✅ Loaded environment from {env_file}")
    else:
        print(f"⚠️  No .env file found at {env_file}")
        print(f"    Run: onex env sync")
except ImportError:
    print("⚠️  python-dotenv not installed, skipping .env loading")
    print("    Install: pip install python-dotenv")

from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware

# File system watcher for hot-reload
try:
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler
    WATCHDOG_AVAILABLE = True
except ImportError:
    WATCHDOG_AVAILABLE = False
    print("⚠️  watchdog not installed - hot-reload disabled")
    print("    Install: pip install watchdog")

# Initialize FastAPI app
app = FastAPI(
    title="OneXEOS Shared Runtime (Local Dev)",
    description="Multi-tenant service container for local development",
    version="1.0.0-local"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global service registry
SERVICES: Dict[str, Dict[str, Any]] = {}
ROUTES: Dict[str, Dict[str, Any]] = {}

# Local development paths
# Use PROJECT_ROOT from environment (set by onex debug/dev) or fallback to current directory
PROJECT_ROOT = Path(os.getenv('PROJECT_ROOT', Path.cwd()))
SERVICES_DIR = PROJECT_ROOT / "services"
LIBS_DIR = PROJECT_ROOT / "libs"
LIBS_PYTHON_DIR = LIBS_DIR / "python"

# Add libs/python to Python path FIRST (before service imports)
if LIBS_PYTHON_DIR.exists():
    sys.path.insert(0, str(LIBS_PYTHON_DIR))
    print(f"✅ Added {LIBS_PYTHON_DIR} to Python path")
elif LIBS_DIR.exists():
    # Fallback to libs/ if libs/python doesn't exist
    sys.path.insert(0, str(LIBS_DIR))
    print(f"✅ Added {LIBS_DIR} to Python path")
else:
    print(f"⚠️  libs directory not found at {LIBS_DIR}")


class MockContext:
    """Mock AWS Lambda context for @as_api decorator compatibility"""
    def __init__(self, service_name: str = "shared-runtime"):
        self.function_name = service_name
        self.memory_limit_in_mb = 512
        self.invoked_function_arn = f"arn:aws:lambda:local:000000000000:function:{service_name}"
        self.aws_request_id = f"local-{datetime.utcnow().isoformat()}"


async def create_lambda_event(request: Request) -> dict:
    """
    Convert FastAPI Request → AWS Lambda API Gateway event format

    This allows existing @as_api decorated handlers to work without changes
    """
    # Extract request body
    body = None
    if request.method in ['POST', 'PUT', 'PATCH']:
        try:
            body = await request.json()
        except:
            try:
                body = await request.body()
                body = body.decode('utf-8') if body else None
            except:
                pass

    # Extract JWT claims from Authorization header
    auth_header = request.headers.get('authorization', '')
    claims = {}
    if auth_header.startswith('Bearer '):
        try:
            import jwt
            token = auth_header[7:]
            claims = jwt.decode(token, options={"verify_signature": False})
        except:
            pass

    # Extract company_id from state (set by auth middleware)
    company_id = getattr(request.state, 'company_id', None)
    user_id = getattr(request.state, 'user_id', None)

    # Create Lambda event
    return {
        'httpMethod': request.method,
        'path': str(request.url.path),
        'pathParameters': dict(request.path_params) or None,
        'queryStringParameters': dict(request.query_params) or None,
        'body': body,
        'headers': dict(request.headers),
        'requestContext': {
            'requestId': f'runtime-{datetime.utcnow().timestamp()}',
            'authorizer': {
                'claims': claims or {
                    'sub': user_id or 'anonymous',
                    'custom:company_id': company_id or request.headers.get('x-company-id', 'unknown')
                }
            }
        }
    }


def load_service(service_name: str) -> bool:
    """
    Load a service from ./services/{service_name}/service.yml

    Returns True if successful, False otherwise
    """
    service_dir = SERVICES_DIR / service_name
    service_yml = service_dir / "service.yml"

    if not service_yml.exists():
        print(f"⚠️  No service.yml found for {service_name} at {service_yml}")
        return False

    try:
        print(f"\n📦 Loading service: {service_name}")
        print(f"   Path: {service_dir}")

        # Parse service.yml
        with open(service_yml) as f:
            config = yaml.safe_load(f)

        if not config:
            print(f"❌ Invalid service.yml for {service_name}")
            return False

        # Add service parent directory to Python path (matches platform approach)
        # This allows imports like: demo.src.handlers.calculate_sum
        sys.path.insert(0, str(service_dir.parent))
        print(f"   ✅ Added to Python path: {service_dir.parent}")

        # Register API endpoints (supports both OLD and NEW schemas)
        routes_registered = 0

        # OLD Schema: apis (backward compatibility)
        for api in config.get('apis', []):
            handler_path = api.get('handler')
            path = api.get('path')
            method = api.get('method', 'GET').upper()
            name = api.get('name', handler_path)
            auth = api.get('auth', 'required')  # public or required

            if not handler_path or not path:
                print(f"   ⚠️  Skipping invalid API config: {api}")
                continue

            # Import handler
            try:
                # handler_path format: "src.apis.auth.register"
                module_path, func_name = handler_path.rsplit('.', 1)

                # CRITICAL: Prefix with service name to create unique namespace
                # This prevents Python module caching collisions when multiple services use "src.apis"
                # Platform approach: auth.src.apis.auth vs order.src.apis.order
                full_module_path = f"{service_name}.{module_path}"

                print(f"   🔍 Importing: {full_module_path}.{func_name}")

                # Dynamic import with unique namespace
                module = importlib.import_module(full_module_path)
                handler = getattr(module, func_name)

                # Create FastAPI route
                route_name = f"{service_name}_{name}"

                # Create endpoint wrapper
                def create_endpoint(handler_func: Callable, api_config: dict):
                    async def endpoint(request: Request):
                        """
                        Endpoint wrapper that converts FastAPI Request → Lambda event
                        Calls handler with @as_api decorator compatibility
                        """
                        try:
                            # Debug logging
                            print(f"📥 {request.method} {request.url.path}")

                            # Create Lambda event
                            event = await create_lambda_event(request)
                            context = MockContext(service_name)

                            # Call handler (works with @as_api decorator)
                            result = handler_func(event, context)

                            # Handle response
                            if isinstance(result, dict):
                                if 'statusCode' in result:
                                    # Lambda response format
                                    return JSONResponse(
                                        content=result.get('body', {}),
                                        status_code=result.get('statusCode', 200),
                                        headers=result.get('headers', {})
                                    )
                                else:
                                    # Direct dict response
                                    return JSONResponse(content=result)
                            else:
                                # Other response types
                                return result

                        except Exception as e:
                            print(f"❌ Error in {service_name}.{func_name}: {e}")
                            traceback.print_exc()
                            return JSONResponse(
                                content={
                                    "error": str(e),
                                    "error_type": type(e).__name__,
                                    "service": service_name,
                                    "handler": handler_path,
                                    "traceback": traceback.format_exc()
                                },
                                status_code=500
                            )

                    return endpoint

                # Register route with FastAPI
                app.add_api_route(
                    path,
                    create_endpoint(handler, api),
                    methods=[method],
                    name=route_name,
                    tags=[service_name]
                )

                # Track route
                route_key = f"{method}:{path}"
                ROUTES[route_key] = {
                    "service": service_name,
                    "handler": handler_path,
                    "method": method,
                    "path": path,
                    "auth": auth
                }

                auth_icon = "🔓" if auth == "public" else "🔐"
                print(f"   ✅ {auth_icon} {method:6} {path:40} → {handler_path}")
                routes_registered += 1

            except Exception as e:
                print(f"   ❌ Failed to load {handler_path}: {e}")
                traceback.print_exc()

        # NEW Schema: functions + triggers
        for func in config.get('functions', []):
            handler_path = func.get('handler')
            func_name = func.get('name', handler_path)

            if not handler_path:
                print(f"   ⚠️  Skipping function without handler: {func}")
                continue

            # Process each trigger
            for trigger in func.get('triggers', []):
                # Only register HTTP triggers for now (ignore schedule, event, stream, s3)
                if trigger.get('type') != 'http':
                    continue

                path = trigger.get('path')
                method = trigger.get('method', 'GET').upper()
                public = trigger.get('public', False)
                auth = 'public' if public else 'required'

                if not path:
                    print(f"   ⚠️  Skipping HTTP trigger without path: {trigger}")
                    continue

                # Import handler
                try:
                    # handler_path format: "src.handlers.calculate_sum"
                    module_path, handler_func_name = handler_path.rsplit('.', 1)

                    # CRITICAL: Prefix with service name to create unique namespace
                    # Platform approach: auth.src.apis.auth vs order.src.apis.order
                    full_module_path = f"{service_name}.{module_path}"

                    print(f"   🔍 Importing: {full_module_path}.{handler_func_name}")

                    # Dynamic import with unique namespace
                    module = importlib.import_module(full_module_path)
                    handler = getattr(module, handler_func_name)

                    # Create FastAPI route
                    route_name = f"{service_name}_{func_name}"

                    # Create endpoint wrapper (same as old schema)
                    def create_endpoint(handler_func: Callable, trigger_config: dict):
                        async def endpoint(request: Request):
                            """
                            Endpoint wrapper that converts FastAPI Request → Lambda event
                            Calls handler with @as_api decorator compatibility
                            """
                            try:
                                # Debug logging
                                print(f"📥 {request.method} {request.url.path}")

                                # Create Lambda event
                                event = await create_lambda_event(request)
                                context = MockContext(service_name)

                                # Call handler (works with @as_api decorator)
                                result = handler_func(event, context)

                                # Handle response
                                if isinstance(result, dict):
                                    if 'statusCode' in result:
                                        # Lambda response format
                                        return JSONResponse(
                                            content=result.get('body', {}),
                                            status_code=result.get('statusCode', 200),
                                            headers=result.get('headers', {})
                                        )
                                    else:
                                        # Direct dict response
                                        return JSONResponse(content=result)
                                else:
                                    # Other response types
                                    return result

                            except Exception as e:
                                print(f"❌ Error in {service_name}.{handler_func_name}: {e}")
                                traceback.print_exc()
                                return JSONResponse(
                                    content={
                                        "error": str(e),
                                        "error_type": type(e).__name__,
                                        "service": service_name,
                                        "handler": handler_path,
                                        "traceback": traceback.format_exc()
                                    },
                                    status_code=500
                                )

                        return endpoint

                    # Register route with FastAPI
                    app.add_api_route(
                        path,
                        create_endpoint(handler, trigger),
                        methods=[method],
                        name=route_name,
                        tags=[service_name]
                    )

                    # Track route
                    route_key = f"{method}:{path}"
                    ROUTES[route_key] = {
                        "service": service_name,
                        "handler": handler_path,
                        "method": method,
                        "path": path,
                        "auth": auth
                    }

                    auth_icon = "🔓" if auth == "public" else "🔐"
                    print(f"   ✅ {auth_icon} {method:6} {path:40} → {handler_path}")
                    routes_registered += 1

                except Exception as e:
                    print(f"   ❌ Failed to load {handler_path}: {e}")
                    traceback.print_exc()

        # Store service config
        SERVICES[service_name] = {
            **config,
            'loaded_at': datetime.utcnow().isoformat(),
            'routes_count': routes_registered,
            'service_dir': str(service_dir)
        }

        print(f"✅ Loaded {service_name}: {routes_registered} routes")
        return True

    except Exception as e:
        print(f"❌ Failed to load service {service_name}: {e}")
        traceback.print_exc()
        return False


def load_all_services():
    """Load all services from ./services/"""
    if not SERVICES_DIR.exists():
        print(f"❌ Services directory not found: {SERVICES_DIR}")
        print(f"   Current directory: {os.getcwd()}")
        return

    # Check if user wants to load only specific service (to avoid module caching issues)
    target_service = os.getenv('SERVICE_NAME', None)

    print("\n" + "=" * 70)
    if target_service:
        print(f"🎯 Loading ONLY service: {target_service} (via SERVICE_NAME env var)")
    else:
        print(f"🚀 Loading services from {SERVICES_DIR}")
        print(f"💡 TIP: Set SERVICE_NAME=<service> to load only one service")
        print(f"   (avoids Python module caching issues with src.* imports)")
    print("=" * 70)

    service_count = 0
    for service_dir in SERVICES_DIR.iterdir():
        if service_dir.is_dir() and not service_dir.name.startswith('.'):
            # Skip if target_service is set and this isn't it
            if target_service and service_dir.name != target_service:
                continue

            if load_service(service_dir.name):
                service_count += 1

    print("\n" + "=" * 70)
    print(f"✅ Loaded {service_count} services, {len(ROUTES)} total routes")
    print("=" * 70 + "\n")


if WATCHDOG_AVAILABLE:
    class ServiceReloader(FileSystemEventHandler):
        """
        Watch ./services/ for changes and hot-reload services

        Triggers on:
        - service.yml modified
        - Python files modified
        """

        def on_modified(self, event):
            """Handle file modifications"""
            if event.is_directory:
                return

            file_path = Path(event.src_path)

            # Check if it's a service.yml file
            if file_path.name == 'service.yml':
                service_name = file_path.parent.name
                if (SERVICES_DIR / service_name).exists():
                    print(f"\n🔄 service.yml changed for {service_name}, reloading...")
                    load_service(service_name)

            # Check if it's a Python file in a service
            elif file_path.suffix == '.py':
                # Find which service this belongs to
                try:
                    service_path = None
                    for parent in file_path.parents:
                        if parent.parent == SERVICES_DIR:
                            service_path = parent
                            break

                    if service_path:
                        service_name = service_path.name
                        print(f"\n🔄 Python file changed in {service_name}, reloading...")

                        # Clear module cache for this service
                        modules_to_remove = [
                            key for key in sys.modules.keys()
                            if key.startswith(f"{service_name}.")
                        ]
                        for module_name in modules_to_remove:
                            del sys.modules[module_name]

                        load_service(service_name)
                except Exception as e:
                    print(f"⚠️  Error during hot-reload: {e}")


# Health check endpoint
@app.get("/health")
async def health():
    """Health check - shows loaded services and routes"""
    return {
        "status": "healthy",
        "runtime": "shared-local",
        "services": list(SERVICES.keys()),
        "services_count": len(SERVICES),
        "routes_count": len(ROUTES),
        "timestamp": datetime.utcnow().isoformat(),
        "python_path": sys.path[:5],  # First 5 entries
        "services_dir": str(SERVICES_DIR),
        "libs_dir": str(LIBS_DIR)
    }


# Service status endpoint
@app.get("/_internal/services")
async def list_services():
    """List all loaded services with details"""
    return {
        "services": SERVICES,
        "routes": ROUTES
    }


# Route listing endpoint
@app.get("/_internal/routes")
async def list_routes():
    """List all registered routes"""
    routes = []
    for route in app.routes:
        if hasattr(route, 'methods') and hasattr(route, 'path'):
            routes.append({
                "path": route.path,
                "methods": list(route.methods),
                "name": route.name
            })
    return {"routes": routes, "count": len(routes)}


# Startup event
@app.on_event("startup")
async def startup():
    """
    Startup tasks:
    1. Load all existing services
    2. Start file watcher for hot-reload
    """
    print("\n" + "=" * 70)
    print("🚀 OneXEOS Shared Runtime Starting (LOCAL DEV MODE)")
    print("=" * 70)
    print(f"📁 Project root: {PROJECT_ROOT}")
    print(f"📁 Services dir: {SERVICES_DIR}")
    print(f"📁 Libs dir: {LIBS_DIR}")
    print(f"🐍 Python version: {sys.version.split()[0]}")
    print(f"🌍 Environment: {os.getenv('ENVIRONMENT', 'local')}")
    print("=" * 70)

    # Load all services
    load_all_services()

    # Start file watcher
    if WATCHDOG_AVAILABLE:
        print("👁️  Starting file watcher for hot-reload...")
        observer = Observer()
        observer.schedule(
            ServiceReloader(),
            str(SERVICES_DIR),
            recursive=True
        )
        observer.start()
        print("✅ File watcher started - code changes will auto-reload!")
    else:
        print("⚠️  File watcher disabled (install watchdog for hot-reload)")
        print("    pip install watchdog")

    print("\n" + "=" * 70)
    print("✅ Shared Runtime Ready for Local Development")
    print(f"📡 Access at: http://localhost:{os.getenv('PORT', '8001')}")
    print(f"📚 API Docs: http://localhost:{os.getenv('PORT', '8001')}/docs")
    print("=" * 70 + "\n")


if __name__ == "__main__":
    import uvicorn
    import platform

    # Run with uvicorn
    port = int(os.getenv("PORT", "8001"))
    log_level = os.getenv("LOG_LEVEL", "info").lower()

    print(f"🚀 Starting server on http://0.0.0.0:{port}")
    print(f"📝 Log level: {log_level}")
    print(f"🔄 Hot-reload: {'Enabled' if WATCHDOG_AVAILABLE else 'Disabled'}\n")

    try:
        uvicorn.run(
            app,
            host="0.0.0.0",
            port=port,
            log_level=log_level,
            access_log=True
        )
    except OSError as e:
        if e.errno == 48:  # Address already in use
            print(f"\n❌ Error: Port {port} is already in use!")
            print(f"\n💡 To kill the process using port {port}:\n")

            system = platform.system()
            if system == "Darwin":  # macOS
                print(f"   Mac/Linux:")
                print(f"   pkill -9 -f runtime_local")
                print(f"   # or find specific process:")
                print(f"   lsof -ti :{port} | xargs kill -9")
            elif system == "Windows":
                print(f"   Windows (PowerShell):")
                print(f"   Get-Process -Id (Get-NetTCPConnection -LocalPort {port}).OwningProcess | Stop-Process -Force")
                print(f"   # or Command Prompt:")
                print(f"   netstat -ano | findstr :{port}")
                print(f"   taskkill /PID <PID> /F")
            else:  # Linux
                print(f"   Linux:")
                print(f"   pkill -9 -f runtime_local")
                print(f"   # or:")
                print(f"   lsof -ti :{port} | xargs kill -9")

            print(f"\n   Then restart: python3 runtime_local.py\n")
            sys.exit(1)
        else:
            raise
