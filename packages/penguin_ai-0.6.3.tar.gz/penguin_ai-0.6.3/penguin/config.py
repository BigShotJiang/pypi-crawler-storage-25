import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
import logging
from logging.handlers import RotatingFileHandler

logger = logging.getLogger(__name__)

# import logging
from typing import Any, Dict, Optional, Literal, List, Callable, Union

import yaml  # type: ignore
from dotenv import load_dotenv  # type: ignore

# LinkAI Workspace Configuration
# LINKAI_WORKSPACE_ID = os.getenv('LINKAI_WORKSPACE_ID')
# LINKAI_API_KEY = os.getenv('LINKAI_API_KEY')

def get_project_root() -> Path:
    """Get the absolute path to the project root."""
    # If installed in site-packages
    if 'site-packages' in __file__:
        # Use environment variable or default to user's home directory
        return Path(os.getenv('PENGUIN_ROOT', Path.home() / '.penguin'))
    
    # If running from source
    return Path(__file__).parent.parent

def load_config():
    """Load configuration by merging multiple locations with clear precedence.

    Precedence (lowest → highest):
      1. Package default (penguin/penguin/config.yml)
      2. Development repo default (repo_root/penguin/config.yml)
      3. User config (~/.config/penguin/config.yml or %APPDATA%/penguin/config.yml)
      4. Project config (<project_root>/.penguin/config.yml)
      5. Project local overrides (<project_root>/.penguin/settings.local.yml)
      6. Explicit override via PENGUIN_CONFIG_PATH (highest single-file override)

    Note: Enterprise-managed policy layer can be added above these in future.
    
    Security lists (allowed_paths, denied_paths, require_approval) are merged
    additively. Other security settings follow normal precedence (higher overrides lower).
    """
    
    # Keys in security section that should merge additively (append lists)
    SECURITY_ADDITIVE_KEYS = {"allowed_paths", "denied_paths", "require_approval"}

    def deep_merge_dicts(base: Dict[str, Any], override: Dict[str, Any], path: str = "") -> Dict[str, Any]:
        for key, value in (override or {}).items():
            current_path = f"{path}.{key}" if path else key
            
            # Special handling for security section lists - merge additively
            if path == "security" and key in SECURITY_ADDITIVE_KEYS:
                base_list = base.get(key, [])
                if not isinstance(base_list, list):
                    base_list = [base_list] if base_list else []
                override_list = value if isinstance(value, list) else [value] if value else []
                # Combine lists, deduplicate while preserving order
                combined = list(dict.fromkeys(base_list + override_list))
                base[key] = combined
            elif isinstance(value, dict) and isinstance(base.get(key), dict):
                base[key] = deep_merge_dicts(dict(base.get(key, {})), value, current_path)
            else:
                # Normal override: higher-precedence config wins
                base[key] = value
        return base

    # 0) Start with empty config
    merged: Dict[str, Any] = {}

    # 1) Package default
    package_config_path = Path(__file__).parent / "config.yml"
    try:
        if package_config_path.exists():
            with open(package_config_path) as f:
                merged = deep_merge_dicts(merged, yaml.safe_load(f) or {})
                logger.debug(f"Loaded package default config: {package_config_path}")
    except Exception as e:
        logger.warning(f"Error loading package default config {package_config_path}: {e}")

    # 2) Development repo default (if running from source)
    try:
        project_root = get_project_root()
        if not str(project_root).endswith('.penguin'):
            dev_config_path = project_root / "penguin" / "config.yml"
            if dev_config_path.exists():
                with open(dev_config_path) as f:
                    merged = deep_merge_dicts(merged, yaml.safe_load(f) or {})
                    logger.debug(f"Loaded dev repo config: {dev_config_path}")
    except Exception:
        pass

    # 3) User config
    if os.name == 'posix':  # Linux/macOS
        config_base = Path(os.environ.get('XDG_CONFIG_HOME', Path.home() / '.config'))
        user_config_path = config_base / "penguin" / "config.yml"
    else:  # Windows
        config_base = Path(os.environ.get('APPDATA', Path.home() / 'AppData' / 'Roaming'))
        user_config_path = config_base / "penguin" / "config.yml"
    try:
        if user_config_path.exists():
            with open(user_config_path) as f:
                merged = deep_merge_dicts(merged, yaml.safe_load(f) or {})
                logger.debug(f"Loaded user config: {user_config_path}")
    except Exception as e:
        logger.warning(f"Error loading user config {user_config_path}: {e}")

    # 4) Project config + local overrides
    def find_git_root(start_path: Path) -> Optional[Path]:
        path = start_path
        while True:
            if (path / '.git').exists():
                return path
            if path.parent == path:
                return None
            path = path.parent

    try:
        start_dir = Path(os.environ.get('PENGUIN_CWD', os.getcwd())).resolve()
    except Exception:
        start_dir = Path.cwd().resolve()

    git_root = find_git_root(start_dir)
    project_root_for_config = git_root or start_dir
    project_config_dir = project_root_for_config / '.penguin'
    project_config_path = project_config_dir / 'config.yml'
    project_local_path = project_config_dir / 'settings.local.yml'

    try:
        if project_config_path.exists():
            with open(project_config_path) as f:
                merged = deep_merge_dicts(merged, yaml.safe_load(f) or {})
                logger.debug(f"Loaded project config: {project_config_path}")
    except Exception as e:
        logger.warning(f"Error loading project config {project_config_path}: {e}")

    try:
        if project_local_path.exists():
            with open(project_local_path) as f:
                merged = deep_merge_dicts(merged, yaml.safe_load(f) or {})
                logger.debug(f"Loaded project local overrides: {project_local_path}")
    except Exception as e:
        logger.warning(f"Error loading project local settings {project_local_path}: {e}")

    # 5) Explicit override (highest single-file override)
    try:
        if os.getenv('PENGUIN_CONFIG_PATH'):
            override_path = Path(os.getenv('PENGUIN_CONFIG_PATH'))
            if override_path.exists():
                with open(override_path) as f:
                    merged = deep_merge_dicts(merged, yaml.safe_load(f) or {})
                    logger.debug(f"Loaded override config: {override_path}")
    except Exception as e:
        logger.warning(f"Error loading override config via PENGUIN_CONFIG_PATH: {e}")

    # If still empty, try setup wizard (skip in non-interactive/CI)
    if not merged:
        # Detect CI/non-interactive environments to avoid prompting
        non_interactive = (
            os.environ.get("CI", "").lower() == "true"
            or os.environ.get("GITHUB_ACTIONS", "").lower() == "true"
            or os.environ.get("PENGUIN_NO_SETUP", "") == "1"
            or not sys.stdin.isatty()
        )
        if non_interactive:
            logger.debug("Non-interactive environment detected; skipping setup wizard and using defaults")
            logger.debug("No config file found, using defaults")
            return {}

        # New guard: do not run setup wizard during import unless explicitly enabled.
        # This prevents blocking behaviors when penguin is imported by standalone scripts.
        # CLI entry points can opt-in by setting PENGUIN_SETUP_ON_IMPORT=1 before import.
        if os.environ.get("PENGUIN_SETUP_ON_IMPORT", "").lower() != "1":
            logger.debug("Setup wizard disabled on import (PENGUIN_SETUP_ON_IMPORT not set). Using defaults")
            return {}

        try:
            from penguin.setup.wizard import check_first_run, run_setup_wizard_sync
            if check_first_run():
                logger.info("No user config detected. Launching setup wizard…")
                result = run_setup_wizard_sync()
                if isinstance(result, dict) and result and not result.get("error"):
                    return result
        except Exception as e:
            logger.debug(f"Setup wizard not available or failed to run: {e}")
        logger.debug("No config file found, using defaults")
        return {}

    return merged

# -------------------------
# Config helper utilities
# -------------------------

def _find_git_root(start_path: Path) -> Optional[Path]:
    path = start_path
    while True:
        if (path / '.git').exists():
            return path
        if path.parent == path:
            return None
        path = path.parent

def get_user_config_path() -> Path:
    if os.name == 'posix':
        base = Path(os.environ.get('XDG_CONFIG_HOME', Path.home() / '.config'))
    else:
        base = Path(os.environ.get('APPDATA', Path.home() / 'AppData' / 'Roaming'))
    return base / 'penguin' / 'config.yml'

def get_project_config_paths(cwd_override: Optional[str] = None) -> Dict[str, Path]:
    try:
        start_dir = Path(cwd_override or os.environ.get('PENGUIN_CWD') or os.getcwd()).resolve()
    except Exception:
        start_dir = Path.cwd().resolve()
    git_root = _find_git_root(start_dir)
    project_root = git_root or start_dir
    cfg_dir = project_root / '.penguin'
    return {
        'project_root': project_root,
        'dir': cfg_dir,
        'project': cfg_dir / 'config.yml',
        'local': cfg_dir / 'settings.local.yml',
    }

def _ensure_parent_dir(path: Path) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

def _read_yaml(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    try:
        with open(path, 'r') as f:
            data = yaml.safe_load(f) or {}
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}

def _write_yaml(path: Path, data: Dict[str, Any]) -> None:
    _ensure_parent_dir(path)
    with open(path, 'w') as f:
        yaml.safe_dump(data, f, default_flow_style=False, sort_keys=False)
    # Auto-gitignore local settings in .penguin/.gitignore
    try:
        if path.name == 'settings.local.yml':
            gitignore = path.parent / '.gitignore'
            _ensure_parent_dir(gitignore)
            line = 'settings.local.yml\n'
            if gitignore.exists():
                existing = gitignore.read_text(encoding='utf-8')
                if 'settings.local.yml' not in existing:
                    with open(gitignore, 'a', encoding='utf-8') as gf:
                        gf.write(line)
            else:
                with open(gitignore, 'w', encoding='utf-8') as gf:
                    gf.write(line)
    except Exception:
        pass

def _set_nested(config_dict: Dict[str, Any], key_path: str, value: Any) -> None:
    parts = [p for p in key_path.split('.') if p]
    node = config_dict
    for p in parts[:-1]:
        if p not in node or not isinstance(node[p], dict):
            node[p] = {}
        node = node[p]
    node[parts[-1]] = value

def _get_nested(config_dict: Dict[str, Any], key_path: str, default=None):
    parts = [p for p in key_path.split('.') if p]
    node = config_dict
    for p in parts:
        if not isinstance(node, dict) or p not in node:
            return default
        node = node[p]
    return node

def set_config_value(key: str, value: Any, scope: str = 'project', cwd_override: Optional[str] = None, list_op: Optional[str] = None) -> Path:
    """Set or modify a config value in the selected scope.

    scope: 'project' (default) writes to .penguin/settings.local.yml;
           'global' writes to user config (~/.config/penguin/config.yml).
    list_op: 'add' | 'remove' for list manipulation.
    Returns the path written.
    """
    if scope not in ('project', 'global'):
        raise ValueError("scope must be 'project' or 'global'")

    if scope == 'global':
        target_path = get_user_config_path()
    else:
        paths = get_project_config_paths(cwd_override)
        target_path = paths['local']

    data = _read_yaml(target_path)
    current = _get_nested(data, key, None)

    if list_op:
        lst = current if isinstance(current, list) else ([] if current in (None, '') else [current])
        if list_op == 'add':
            if value not in lst:
                lst.append(value)
        elif list_op == 'remove':
            lst = [x for x in lst if x != value]
        else:
            raise ValueError("list_op must be 'add' or 'remove'")
        _set_nested(data, key, lst)
    else:
        _set_nested(data, key, value)

    _write_yaml(target_path, data)
    return target_path

def get_config_value(key: str, default=None, cwd_override: Optional[str] = None):
    cfg = load_config()
    return _get_nested(cfg, key, default)


# ---------------------------------------------------------------------------
# RuntimeConfig - Runtime-changeable configuration with observer pattern
# ---------------------------------------------------------------------------

class RuntimeConfig:
    """Manages runtime-changeable configuration separate from startup config.
    
    This class provides a clean separation between:
    1. Startup configuration (immutable, from config files/env vars)
    2. Runtime configuration (mutable, can be changed via API/CLI)
    
    Components can subscribe to configuration changes via the observer pattern,
    ensuring all parts of the system stay synchronized.
    
    Example:
        >>> runtime_config = RuntimeConfig(startup_config)
        >>> runtime_config.register_observer(tool_manager.on_config_change)
        >>> runtime_config.set_project_root("/new/path")  # Observers are notified
    """
    
    def __init__(self, startup_config: Optional[Dict[str, Any]] = None):
        """Initialize runtime configuration from startup config.
        
        Args:
            startup_config: Initial configuration dictionary from load_config()
        """
        startup_config = startup_config or {}
        
        # Import here to avoid circular dependency
        from penguin.utils.path_utils import get_allowed_roots, get_default_write_root
        
        # Initialize project root (prefer env, then config, then auto-detect)
        project_root_env = os.environ.get('PENGUIN_PROJECT_ROOT')
        if project_root_env:
            try:
                self._project_root = str(Path(project_root_env).expanduser().resolve())
                logger.info(f"RuntimeConfig: Using PENGUIN_PROJECT_ROOT={self._project_root}")
            except Exception as e:
                logger.warning(f"Invalid PENGUIN_PROJECT_ROOT: {e}")
                project_root_env = None
        
        if not project_root_env:
            try:
                prj_root, _ws_root, *_ = get_allowed_roots()
                self._project_root = str(prj_root)
            except Exception:
                # Fallback to current working directory
                self._project_root = os.getcwd()
                logger.warning(f"RuntimeConfig: Falling back to cwd as project_root: {self._project_root}")
        
        # Initialize workspace root (prefer env, then config, then default)
        workspace_env = os.environ.get('PENGUIN_WORKSPACE')
        if workspace_env:
            try:
                self._workspace_root = str(Path(workspace_env).expanduser().resolve())
            except Exception:
                self._workspace_root = str(WORKSPACE_PATH)
        else:
            self._workspace_root = str(WORKSPACE_PATH)
        
        # Initialize execution mode (project vs workspace)
        root_pref_env = os.environ.get('PENGUIN_WRITE_ROOT', '').lower()
        if root_pref_env in ('project', 'workspace'):
            self._execution_mode = root_pref_env
        else:
            self._execution_mode = get_default_write_root()

        # Propagate defaults to env for components that rely on env hints.
        # Use setdefault so explicit env overrides still win.
        try:
            os.environ.setdefault("PENGUIN_WRITE_ROOT", self._execution_mode)
            os.environ.setdefault("PENGUIN_CWD", self.active_root)
        except Exception:
            logger.debug("RuntimeConfig: failed to set default env roots", exc_info=True)
        
        # Initialize security settings from config
        security_config = startup_config.get('security', {})
        self._security_mode = security_config.get('mode', 'workspace')
        self._security_enabled = security_config.get('enabled', True)
        # Check for YOLO mode override
        if os.environ.get('PENGUIN_YOLO', '').lower() in ('1', 'true', 'yes'):
            self._security_enabled = False
            logger.warning("RuntimeConfig: YOLO mode enabled - permission checks disabled")
        
        # Observer list for components that need to react to config changes
        self._observers: List[Callable[[str, Any], None]] = []
        
        logger.info(
            f"RuntimeConfig initialized: project_root={self._project_root}, "
            f"workspace_root={self._workspace_root}, execution_mode={self._execution_mode}, "
            f"security_mode={self._security_mode}, security_enabled={self._security_enabled}"
        )
    
    # Properties for read access
    @property
    def project_root(self) -> str:
        """Get current project root directory."""
        return self._project_root
    
    @property
    def workspace_root(self) -> str:
        """Get current workspace root directory."""
        return self._workspace_root
    
    @property
    def execution_mode(self) -> str:
        """Get current execution mode ('project' or 'workspace')."""
        return self._execution_mode
    
    @property
    def active_root(self) -> str:
        """Get the currently active root based on execution mode."""
        return self._project_root if self._execution_mode == 'project' else self._workspace_root
    
    @property
    def security_mode(self) -> str:
        """Get current security mode ('read_only', 'workspace', or 'full')."""
        return self._security_mode
    
    @property
    def security_enabled(self) -> bool:
        """Get whether security/permission checks are enabled."""
        return self._security_enabled
    
    # Observer pattern methods
    def register_observer(self, callback: Callable[[str, Any], None]) -> None:
        """Register a callback to be notified of configuration changes.
        
        Args:
            callback: Function that takes (config_key: str, new_value: Any)
        """
        if callback not in self._observers:
            self._observers.append(callback)
            logger.debug(f"RuntimeConfig: Registered observer {callback.__name__}")
    
    def unregister_observer(self, callback: Callable[[str, Any], None]) -> None:
        """Unregister a callback."""
        if callback in self._observers:
            self._observers.remove(callback)
            logger.debug(f"RuntimeConfig: Unregistered observer {callback.__name__}")
    
    def _notify_observers(self, config_key: str, value: Any) -> None:
        """Notify all registered observers of a configuration change."""
        logger.debug(f"RuntimeConfig: Notifying {len(self._observers)} observers of {config_key} change")
        for callback in self._observers:
            try:
                callback(config_key, value)
            except Exception as e:
                logger.error(f"RuntimeConfig: Observer {callback.__name__} error: {e}", exc_info=True)
    
    # Configuration change methods
    def set_project_root(self, project_root: Union[str, Path]) -> str:
        """Change the project root directory at runtime.
        
        Args:
            project_root: Path to new project root directory
            
        Returns:
            Success message string
            
        Raises:
            ValueError: If path is invalid or doesn't exist
        """
        try:
            resolved = Path(project_root).expanduser().resolve()
        except Exception as exc:
            raise ValueError(f"Invalid project root '{project_root}': {exc}") from exc
        
        if not resolved.exists():
            raise ValueError(f"Project root does not exist: {resolved}")
        if not resolved.is_dir():
            raise ValueError(f"Project root must be a directory: {resolved}")
        
        old_root = self._project_root
        self._project_root = str(resolved)
        
        logger.info(f"RuntimeConfig: Project root changed from {old_root} to {self._project_root}")
        
        # Update environment variable for path_utils security checks
        try:
            os.environ['PENGUIN_CWD'] = self._project_root
        except Exception:
            pass
        
        # Notify observers
        self._notify_observers('project_root', self._project_root)
        
        return f"Project root set to {self._project_root}"
    
    def set_workspace_root(self, workspace_root: Union[str, Path]) -> str:
        """Change the workspace root directory at runtime.
        
        Args:
            workspace_root: Path to new workspace root directory
            
        Returns:
            Success message string
            
        Raises:
            ValueError: If path is invalid or doesn't exist
        """
        try:
            resolved = Path(workspace_root).expanduser().resolve()
        except Exception as exc:
            raise ValueError(f"Invalid workspace root '{workspace_root}': {exc}") from exc
        
        if not resolved.exists():
            raise ValueError(f"Workspace root does not exist: {resolved}")
        if not resolved.is_dir():
            raise ValueError(f"Workspace root must be a directory: {resolved}")
        
        old_root = self._workspace_root
        self._workspace_root = str(resolved)
        
        logger.info(f"RuntimeConfig: Workspace root changed from {old_root} to {self._workspace_root}")
        
        # Notify observers
        self._notify_observers('workspace_root', self._workspace_root)
        
        return f"Workspace root set to {self._workspace_root}"
    
    def set_execution_mode(self, mode: str) -> str:
        """Switch active execution root between 'project' and 'workspace'.
        
        Args:
            mode: Either 'project' or 'workspace'
            
        Returns:
            Success message string
            
        Raises:
            ValueError: If mode is not 'project' or 'workspace'
        """
        mode_lower = (mode or '').lower()
        if mode_lower not in ('project', 'workspace'):
            raise ValueError(f"Invalid execution mode '{mode}'. Must be 'project' or 'workspace'.")
        
        old_mode = self._execution_mode
        self._execution_mode = mode_lower
        
        logger.info(f"RuntimeConfig: Execution mode changed from {old_mode} to {self._execution_mode}")
        
        # Update environment variable
        try:
            os.environ['PENGUIN_WRITE_ROOT'] = mode_lower
            os.environ['PENGUIN_CWD'] = self.active_root
        except Exception:
            pass
        
        # Notify observers
        self._notify_observers('execution_mode', self._execution_mode)
        
        return f"Execution mode set to {mode_lower}: {self.active_root}"
    
    def set_security_mode(self, mode: str) -> str:
        """Change the security/permission mode at runtime.
        
        Args:
            mode: One of 'read_only', 'workspace', or 'full'
            
        Returns:
            Success message string
            
        Raises:
            ValueError: If mode is not valid
        """
        valid_modes = ('read_only', 'workspace', 'full')
        mode_lower = (mode or '').lower()
        if mode_lower not in valid_modes:
            raise ValueError(f"Invalid security mode '{mode}'. Must be one of: {valid_modes}")
        
        old_mode = self._security_mode
        self._security_mode = mode_lower
        
        logger.info(f"RuntimeConfig: Security mode changed from {old_mode} to {self._security_mode}")
        
        # Notify observers (ToolManager will update its permission enforcer)
        self._notify_observers('security_mode', self._security_mode)
        
        return f"Security mode set to {mode_lower}"
    
    def set_security_enabled(self, enabled: bool) -> str:
        """Enable or disable security/permission checks (YOLO mode toggle).
        
        Args:
            enabled: True to enable checks, False to disable (YOLO mode)
            
        Returns:
            Success message string
        """
        old_enabled = self._security_enabled
        self._security_enabled = bool(enabled)
        
        if not self._security_enabled:
            logger.warning("RuntimeConfig: Security checks DISABLED (YOLO mode)")
        else:
            logger.info("RuntimeConfig: Security checks enabled")
        
        # Notify observers
        self._notify_observers('security_enabled', self._security_enabled)
        
        status = "enabled" if self._security_enabled else "disabled (YOLO mode)"
        return f"Security checks {status}"
    
    def to_dict(self) -> Dict[str, Any]:
        """Export current runtime configuration as a dictionary.
        
        Returns:
            Dictionary with current configuration values
        """
        return {
            'project_root': self._project_root,
            'workspace_root': self._workspace_root,
            'execution_mode': self._execution_mode,
            'active_root': self.active_root,
            'security_mode': self._security_mode,
            'security_enabled': self._security_enabled,
        }
    
    def __repr__(self) -> str:
        return (
            f"RuntimeConfig(project_root='{self._project_root}', "
            f"workspace_root='{self._workspace_root}', "
            f"execution_mode='{self._execution_mode}')"
        )


def init_diagnostics(config_data: dict):
    """Initialize diagnostics based on configuration. Call this after config is loaded."""
    if "diagnostics" in config_data:
        try:
            from penguin.utils.diagnostics import (
                disable_diagnostics,
                enable_diagnostics,
            )

            if not config_data["diagnostics"].get("enabled", False):
                disable_diagnostics()
            else:
                enable_diagnostics()
        except ImportError as e:
            # Only show warning if diagnostics is explicitly enabled
            if config_data["diagnostics"].get("enabled", False):
                logger.warning(f"Could not import diagnostics module: {e}")
            # Continue without diagnostics

def get_workspace_root() -> Path:
    """Get the workspace root directory."""
    # Load config
    config_data = load_config()
    
    # Priority order:
    # 1. Environment variable
    # 2. Config file
    # 3. Default location
    workspace_root = os.getenv(
        'PENGUIN_WORKSPACE',
        config_data.get('workspace', {}).get('path', '~/penguin_workspace')
    )
    
    return Path(workspace_root).expanduser()

# Base paths
PROJECT_ROOT = get_project_root()

# Load config first (without initializing diagnostics yet)
config = load_config()

# Use workspace path from config.yml (respecting environment variable and config file)
WORKSPACE_PATH = get_workspace_root()

# Add explicit creation with better error handling
try:
    WORKSPACE_PATH.mkdir(parents=True, exist_ok=True)
except PermissionError as e:
    # Try to use a fallback workspace in user's home directory
    fallback_path = Path.home() / "penguin_workspace"
    logger.warning(f"Permission denied creating workspace at {WORKSPACE_PATH}. Using fallback: {fallback_path}")
    try:
        fallback_path.mkdir(parents=True, exist_ok=True)
        WORKSPACE_PATH = fallback_path
    except PermissionError:
        raise RuntimeError(
            f"Permission denied creating workspace at {WORKSPACE_PATH} and fallback {fallback_path}. "
            "Try setting PENGUIN_WORKSPACE environment variable to a writable location."
        ) from e
except FileNotFoundError as e:
    # This can happen if the parent directory doesn't exist and can't be created
    fallback_path = Path.home() / "penguin_workspace" 
    logger.warning(f"Cannot create workspace at {WORKSPACE_PATH} (path not found). Using fallback: {fallback_path}")
    try:
        fallback_path.mkdir(parents=True, exist_ok=True)
        WORKSPACE_PATH = fallback_path
    except Exception:
        raise RuntimeError(
            f"Cannot create workspace at {WORKSPACE_PATH} or fallback {fallback_path}. "
            "Try setting PENGUIN_WORKSPACE environment variable to a valid location."
        ) from e

# Create configured subdirectories
for subdir in config.get('workspace', {}).get('create_dirs', [
    'conversations',
    'memory_db',
    'logs'
]):
    (WORKSPACE_PATH / subdir).mkdir(exist_ok=True)

# Update config with resolved paths
config['paths'] = {
    'workspace': str(WORKSPACE_PATH),
    'conversations': str(WORKSPACE_PATH / 'conversations'),
    'memory_db': str(WORKSPACE_PATH / 'memory_db'),
    'logs': str(WORKSPACE_PATH / 'logs'),
}

def substitute_path_variables(obj, paths):
    """Simple template substitution for ${paths.*} variables"""
    if isinstance(obj, str):
        for key, value in paths.items():
            obj = obj.replace(f"${{paths.{key}}}", value)
        return obj
    elif isinstance(obj, dict):
        return {k: substitute_path_variables(v, paths) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [substitute_path_variables(item, paths) for item in obj]
    else:
        return obj

# Substitute path variables in the entire config
config = substitute_path_variables(config, config['paths'])

# Safe access to common sections
_MODEL = config.get('model', {}) if isinstance(config.get('model'), dict) else {}
_API = config.get('api', {}) if isinstance(config.get('api'), dict) else {}

# Avoid noisy stdout during normal startup; log at DEBUG level instead.
logger.debug(f"Workspace path: {WORKSPACE_PATH}")

# =============================================================================
# LAZY INITIALIZATION FOR STARTUP PERFORMANCE
# =============================================================================
# These operations are deferred until first use to speed up startup time.
# - init_diagnostics: Only needed when diagnostics features are used
# - load_dotenv: Only needed when API keys are accessed
# =============================================================================

_env_loaded = False
_diagnostics_initialized = False

def _ensure_env_loaded():
    """Lazy-load environment variables from .env files. Called on first API key access."""
    global _env_loaded
    if _env_loaded:
        return
    _env_loaded = True

    # 1) User-level: ~/.config/penguin/.env (or APPDATA equivalent) – provides persistent keys
    try:
        if os.name == 'posix':
            user_env_dir = Path(os.environ.get('XDG_CONFIG_HOME', Path.home() / '.config')) / 'penguin'
        else:
            user_env_dir = Path(os.environ.get('APPDATA', Path.home() / 'AppData' / 'Roaming')) / 'penguin'
        user_env_path = user_env_dir / '.env'
        if user_env_path.exists():
            load_dotenv(dotenv_path=str(user_env_path), override=False)
    except Exception:
        # Non-fatal if user-level .env loading fails
        pass

    # 2) Project-level: nearest .env up the CWD chain – overrides user-level values
    load_dotenv(override=True)

def _ensure_diagnostics_initialized():
    """Lazy-initialize diagnostics. Called on first diagnostics access."""
    global _diagnostics_initialized
    if _diagnostics_initialized:
        return
    _diagnostics_initialized = True
    init_diagnostics(config)

def get_api_key(key_name: str) -> Optional[str]:
    """Get an API key, loading .env files if not already done."""
    _ensure_env_loaded()
    return os.environ.get(key_name)

# API Keys - now lazily loaded via property-like access
# For backwards compatibility, we provide module-level variables that are
# populated on first access via __getattr__ at the module level.
# Direct access patterns like `from penguin.config import TAVILY_API_KEY`
# will trigger the lazy load.

# Placeholder values - actual values loaded lazily
_API_KEY_NAMES = {
    'TAVILY_API_KEY': 'TAVILY_API_KEY',
    'PERPLEXITY_API_KEY': 'PERPLEXITY_API_KEY',
    'GITHUB_TOKEN': 'GITHUB_TOKEN',
    'GITHUB_APP_ID': 'GITHUB_APP_ID',
    'GITHUB_APP_PRIVATE_KEY_PATH': 'GITHUB_APP_PRIVATE_KEY_PATH',
    'GITHUB_APP_INSTALLATION_ID': 'GITHUB_APP_INSTALLATION_ID',
}

# For direct module attribute access, we need actual variables
# These will be None until _ensure_env_loaded() is called
TAVILY_API_KEY: Optional[str] = None
PERPLEXITY_API_KEY: Optional[str] = None
GITHUB_TOKEN: Optional[str] = None
GITHUB_APP_ID: Optional[str] = None
GITHUB_APP_PRIVATE_KEY_PATH: Optional[str] = None
GITHUB_APP_INSTALLATION_ID: Optional[str] = None

def _populate_api_keys():
    """Populate API key module variables after env is loaded."""
    global TAVILY_API_KEY, PERPLEXITY_API_KEY, GITHUB_TOKEN
    global GITHUB_APP_ID, GITHUB_APP_PRIVATE_KEY_PATH, GITHUB_APP_INSTALLATION_ID
    _ensure_env_loaded()
    TAVILY_API_KEY = os.environ.get("TAVILY_API_KEY")
    PERPLEXITY_API_KEY = os.environ.get("PERPLEXITY_API_KEY")
    GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN")
    GITHUB_APP_ID = os.environ.get("GITHUB_APP_ID")
    GITHUB_APP_PRIVATE_KEY_PATH = os.environ.get("GITHUB_APP_PRIVATE_KEY_PATH")
    GITHUB_APP_INSTALLATION_ID = os.environ.get("GITHUB_APP_INSTALLATION_ID")

# Constants
# CONTINUATION_EXIT_PHRASE = "AUTOMODE_COMPLETE"
# MAX_CONTINUATION_ITERATIONS = 100
TASK_COMPLETION_PHRASE = "TASK_COMPLETED"  # Single task completion
CONTINUOUS_COMPLETION_PHRASE = "CONTINUOUS_COMPLETED"  # End of continuous session
EMERGENCY_STOP_PHRASE = "EMERGENCY_STOP"  # Immediate termination needed
NEED_USER_CLARIFICATION_PHRASE = "NEED_USER_CLARIFICATION"  # Pause for user input
# Canonical iteration budget (config-driven).
# Source of truth: config.yml → engine.max_iterations_default
try:
    MAX_TASK_ITERATIONS = int(_get_nested(config, "engine.max_iterations_default", 5000))
except Exception:
    MAX_TASK_ITERATIONS = 5000


# Default model configuration (safe defaults for CI/non-interactive)
DEFAULT_MODEL = os.getenv("PENGUIN_DEFAULT_MODEL", _MODEL.get("default")) or "openai/gpt-5"
DEFAULT_PROVIDER = os.getenv("PENGUIN_DEFAULT_PROVIDER", _MODEL.get("provider", "openrouter"))
DEFAULT_API_BASE = os.getenv("PENGUIN_DEFAULT_API_BASE", _API.get("base_url"))
USE_ASSISTANTS_API = _MODEL.get("use_assistants_api", True)

# Project Management Configuration
GITHUB_REPOSITORY = os.getenv("GITHUB_REPOSITORY", config.get("project", {}).get("github_repository"))

# Add assistant-specific configuration
ASSISTANT_CONFIG = {
    "provider": _MODEL.get("provider", "openai"),
    "enabled": _MODEL.get("use_assistants_api", False),
    "custom_llm_provider": "openai",  # Used by assistant compatibility flows
    "model_name_override": None,  # Optional override for assistant model name
}


def get_assistant_config() -> Dict[str, Any]:
    """Get the configuration for the Assistants API"""
    return {
        "provider": ASSISTANT_CONFIG["provider"],
        "enabled": ASSISTANT_CONFIG["enabled"],
        "custom_llm_provider": ASSISTANT_CONFIG["custom_llm_provider"],
        "model_name_override": ASSISTANT_CONFIG["model_name_override"],
    }


# Model-specific configurations
MODEL_CONFIGS = config.get("model_configs", {})


# Update the existing ModelConfig creation to include assistant config
def get_model_config(model_name: Optional[str] = None) -> Dict[str, Any]:
    """Get the configuration for a specific model"""
    model_name = model_name or DEFAULT_MODEL
    base_config = MODEL_CONFIGS.get(model_name, {})

    return {
        "model": model_name,
        "provider": base_config.get("provider", DEFAULT_PROVIDER),
        "api_base": base_config.get("api_base", DEFAULT_API_BASE),
        "max_output_tokens": base_config.get("max_output_tokens", base_config.get("max_tokens")),
        "temperature": base_config.get("temperature"),
        "use_assistants_api": _MODEL.get("use_assistants_api", False),
        "assistant_config": get_assistant_config() if _MODEL.get("use_assistants_api", False) else None,
    }


# Feature Flags
class FeatureFlags:
    DIAGNOSTICS_ENABLED = False


# Color Configuration
class Colors:
    USER_COLOR = "white"
    CLAUDE_COLOR = "blue"
    TOOL_COLOR = "yellow"
    RESULT_COLOR = "green"


# Configuration class
class Config:
    @classmethod
    def get(cls, key, default=None):
        return getattr(cls, key, default)

    @classmethod
    def set(cls, key, value):
        setattr(cls, key, value)

    @classmethod
    def enable_feature(cls, feature):
        setattr(FeatureFlags, feature, True)

    @classmethod
    def disable_feature(cls, feature):
        setattr(FeatureFlags, feature, False)

    @classmethod
    def is_feature_enabled(cls, feature):
        return getattr(FeatureFlags, feature, False)


# You can add more configuration settings here as needed


# Show tool output in the UI

# Show iteration messages in the UI.

# Show memory search results in the UI. ( I mean it is tool output, but it's a lot of output so we should have a flag for it )

#


@dataclass
class OutputConfig:
    prompt_style: str = field(default="steps_final")
    show_tool_results: bool = field(default=True)


@dataclass
class DiagnosticsConfig:
    enabled: bool = field(default=False)
    max_context_tokens: int = field(default=200000)
    log_to_file: bool = field(default=False)
    log_path: Optional[Path] = field(default=None)


@dataclass
class AuditConfig:
    """Configuration for permission audit logging.
    
    Controls what permission checks are logged and where.
    
    Verbosity levels per category:
    - "off": No logging for this category
    - "deny_only": Only log DENY results
    - "ask_and_deny": Log ASK and DENY results
    - "all": Log all permission checks (ALLOW, ASK, DENY)
    
    Example config:
        ```yaml
        security:
          audit:
            enabled: true
            log_file: ".penguin/permission_audit.log"
            categories:
              filesystem: all
              process: deny_only
              network: off
        ```
    """
    # Enable/disable audit logging
    enabled: bool = field(default=True)
    # Log file path (relative to workspace or absolute)
    log_file: str = field(default=".penguin/permission_audit.log")
    # Per-category verbosity settings
    categories: Dict[str, str] = field(default_factory=lambda: {
        "filesystem": "all",
        "process": "ask_and_deny",
        "network": "deny_only",
        "git": "ask_and_deny",
        "memory": "off",
    })
    # Maximum number of entries to keep in memory (for API queries)
    max_memory_entries: int = field(default=1000)
    # Include full context in logs (may contain sensitive data)
    include_context: bool = field(default=False)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AuditConfig":
        """Create from config dictionary."""
        if not isinstance(data, dict):
            return cls()
        
        # Validate categories is a dict before converting
        default_categories = {
            "filesystem": "all",
            "process": "ask_and_deny",
            "network": "deny_only",
            "git": "ask_and_deny",
            "memory": "off",
        }
        categories_raw = data.get("categories", default_categories)
        categories = dict(categories_raw) if isinstance(categories_raw, dict) else default_categories
        
        return cls(
            enabled=data.get("enabled", True),
            log_file=data.get("log_file", ".penguin/permission_audit.log"),
            categories=categories,
            max_memory_entries=data.get("max_memory_entries", 1000),
            include_context=data.get("include_context", False),
        )
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "enabled": self.enabled,
            "log_file": self.log_file,
            "categories": dict(self.categories),
            "max_memory_entries": self.max_memory_entries,
            "include_context": self.include_context,
        }
    
    def should_log(self, category: str, result: str) -> bool:
        """Check if a permission check should be logged.
        
        Args:
            category: Operation category (e.g., "filesystem", "process")
            result: Permission result ("allow", "ask", "deny")
            
        Returns:
            True if this check should be logged
        """
        if not self.enabled:
            return False
        
        verbosity = self.categories.get(category, "deny_only")
        
        if verbosity == "off":
            return False
        elif verbosity == "deny_only":
            return result == "deny"
        elif verbosity == "ask_and_deny":
            return result in ("ask", "deny")
        elif verbosity == "all":
            return True
        else:
            # Unknown verbosity, default to deny_only
            return result == "deny"


@dataclass
class SecurityConfig:
    """Security and permission configuration.
    
    Controls permission enforcement for tool operations.
    Lists (allowed_paths, denied_paths, require_approval) are merged
    additively from project configs.
    """
    # Permission mode: read_only | workspace | full
    mode: str = field(default="workspace")
    # Additional paths to allow (glob patterns)
    allowed_paths: List[str] = field(default_factory=list)
    # Paths to always deny (glob patterns)
    denied_paths: List[str] = field(default_factory=lambda: [
        ".env", ".env.*", "**/*.pem", "**/*.key",
        "**/*secret*", "**/*credential*"
    ])
    # Operations requiring user approval
    require_approval: List[str] = field(default_factory=lambda: [
        "filesystem.delete", "git.push", "git.force"
    ])
    # Enable/disable permission checks
    enabled: bool = field(default=True)
    # Audit logging configuration
    audit: AuditConfig = field(default_factory=AuditConfig)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SecurityConfig":
        """Create from config dictionary."""
        return cls(
            mode=data.get("mode", "workspace"),
            allowed_paths=list(data.get("allowed_paths", [])),
            denied_paths=list(data.get("denied_paths", [
                ".env", ".env.*", "**/*.pem", "**/*.key",
                "**/*secret*", "**/*credential*"
            ])),
            require_approval=list(data.get("require_approval", [
                "filesystem.delete", "git.push", "git.force"
            ])),
            enabled=data.get("enabled", True),
            audit=AuditConfig.from_dict(data.get("audit", {})),
        )
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "mode": self.mode,
            "allowed_paths": list(self.allowed_paths),
            "denied_paths": list(self.denied_paths),
            "require_approval": list(self.require_approval),
            "enabled": self.enabled,
            "audit": self.audit.to_dict(),
        }
    
    def merge_additive(self, other: "SecurityConfig") -> "SecurityConfig":
        """Merge another SecurityConfig additively.
        
        Lists are combined (deduplicated), mode is NOT changed.
        This allows project configs to add paths without escalating mode.
        """
        return SecurityConfig(
            mode=self.mode,  # Keep original mode (no escalation)
            allowed_paths=list(dict.fromkeys(self.allowed_paths + other.allowed_paths)),
            denied_paths=list(dict.fromkeys(self.denied_paths + other.denied_paths)),
            require_approval=list(dict.fromkeys(self.require_approval + other.require_approval)),
            enabled=self.enabled,  # Keep original enabled state
            audit=self.audit,  # Keep original audit config
        )


@dataclass
class AgentModelSettings:
    """Model override declaration for an agent persona."""

    id: Optional[str] = None
    model: Optional[str] = None
    provider: Optional[str] = None
    client_preference: Optional[str] = None
    api_base: Optional[str] = None
    temperature: Optional[float] = None
    max_output_tokens: Optional[int] = None
    streaming_enabled: Optional[bool] = None
    vision_enabled: Optional[bool] = None
    use_assistants_api: Optional[bool] = None
    reasoning: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AgentModelSettings":
        """Create settings from raw config dictionary."""

        return cls(
            id=data.get("id") or data.get("name"),
            model=data.get("model"),
            provider=data.get("provider"),
            client_preference=data.get("client_preference"),
            api_base=data.get("api_base"),
            temperature=data.get("temperature"),
            max_output_tokens=data.get("max_output_tokens", data.get("max_tokens")),
            streaming_enabled=data.get("streaming_enabled"),
            vision_enabled=data.get("vision_enabled"),
            use_assistants_api=data.get("use_assistants_api"),
            reasoning=dict(data.get("reasoning", {})),
        )

    def to_dict(self) -> Dict[str, Any]:
        """Return a serialisable copy of the settings."""

        payload: Dict[str, Any] = {
            "id": self.id,
            "model": self.model,
            "provider": self.provider,
            "client_preference": self.client_preference,
            "api_base": self.api_base,
            "temperature": self.temperature,
            "max_output_tokens": self.max_output_tokens,
            "streaming_enabled": self.streaming_enabled,
            "vision_enabled": self.vision_enabled,
            "use_assistants_api": self.use_assistants_api,
        }
        if self.reasoning:
            payload["reasoning"] = dict(self.reasoning)
        return {k: v for k, v in payload.items() if v is not None}


@dataclass
class AgentPersonaConfig:
    """Declarative configuration for a reusable agent persona.
    
    The `permissions` field unifies with `default_tools` for operation-based
    access control. If both are specified, `permissions.operations` takes
    precedence; `default_tools` is kept for backward compatibility.
    
    Example config:
        ```yaml
        agents:
          analyzer:
            description: "Read-only code analyzer"
            permissions:
              mode: read_only
              operations: [filesystem.read, memory.read]
              allowed_paths: ["src/", "tests/"]
          implementer:
            permissions:
              operations: [filesystem.read, filesystem.write, process.execute]
              denied_paths: ["**/.env*"]
        ```
    """

    name: str
    description: Optional[str] = None
    system_prompt: Optional[str] = None
    model: Optional[AgentModelSettings] = None
    # Legacy: tool name restrictions (kept for backward compatibility)
    default_tools: Optional[List[str]] = None
    # New: unified permission config (operations, paths, mode)
    permissions: Optional[Dict[str, Any]] = None
    share_session_with: Optional[str] = None
    share_context_window_with: Optional[str] = None
    shared_context_window_max_tokens: Optional[int] = None
    model_output_max_tokens: Optional[int] = None
    activate_by_default: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, name: str, data: Dict[str, Any]) -> "AgentPersonaConfig":
        """Build a persona config from raw configuration data."""

        model_block = data.get("model") or {}
        model_settings = None
        if isinstance(model_block, dict) and model_block:
            model_settings = AgentModelSettings.from_dict(model_block)

        tools_block = data.get("default_tools")
        if tools_block is None:
            tools_block = data.get("tools")
        default_tools = list(tools_block) if isinstance(tools_block, list) else None

        # Parse permissions block
        permissions_block = data.get("permissions")
        permissions = None
        if isinstance(permissions_block, dict):
            permissions = dict(permissions_block)
        elif isinstance(permissions_block, list):
            # Short form: just a list of operations
            permissions = {"operations": list(permissions_block)}

        return cls(
            name=name,
            description=data.get("description"),
            system_prompt=data.get("system_prompt"),
            model=model_settings,
            default_tools=default_tools,
            permissions=permissions,
            share_session_with=data.get("share_session_with"),
            share_context_window_with=data.get("share_context_window_with"),
            shared_context_window_max_tokens=data.get("shared_context_window_max_tokens", data.get("shared_cw_max_tokens")),
            model_output_max_tokens=data.get("model_output_max_tokens", data.get("model_max_tokens")),
            activate_by_default=bool(data.get("activate") or data.get("activate_by_default", False)),
            metadata=dict(data.get("metadata", {})),
        )
    
    def get_permission_config(self) -> Optional["AgentPermissionConfig"]:
        """Get the AgentPermissionConfig for this persona.
        
        Lazily imports from security module to avoid circular imports.
        Returns None if no permissions configured.
        """
        if self.permissions is None:
            return None
        
        try:
            from penguin.security.agent_permissions import AgentPermissionConfig
            return AgentPermissionConfig.from_dict(self.permissions)
        except ImportError:
            logger.warning("Security module not available, skipping permission config")
            return None

    def to_dict(self) -> Dict[str, Any]:
        """Return a serialisable mapping representing the persona."""

        payload: Dict[str, Any] = {
            "name": self.name,
            "description": self.description,
            "system_prompt": self.system_prompt,
            "default_tools": list(self.default_tools) if self.default_tools else None,
            "permissions": dict(self.permissions) if self.permissions else None,
            "share_session_with": self.share_session_with,
            "share_context_window_with": self.share_context_window_with,
            "shared_context_window_max_tokens": self.shared_context_window_max_tokens,
            "model_output_max_tokens": self.model_output_max_tokens,
            "activate": self.activate_by_default,
            "metadata": dict(self.metadata) if self.metadata else None,
        }
        if self.model:
            payload["model"] = self.model.to_dict()
        return {k: v for k, v in payload.items() if v is not None}


@dataclass
class APIConfig:
    base_url: Optional[str] = None


@dataclass
class Config:
    # Use forward reference for type hint to avoid circular import
    model_config: Any = None  # Will be set in load_config
    api: APIConfig = field(default_factory=APIConfig)
    workspace_path: Path = field(default_factory=lambda: Path(WORKSPACE_PATH))
    temperature: float = field(default=0.7)
    max_output_tokens: Optional[int] = field(default=None)
    diagnostics: DiagnosticsConfig = field(default_factory=DiagnosticsConfig)
    security: SecurityConfig = field(default_factory=SecurityConfig)
    output: OutputConfig = field(default_factory=OutputConfig)
    workspace_dir: Path = field(default_factory=Path.cwd)
    cache_dir: Path = field(
        default_factory=lambda: Path(
            os.getenv("PENGUIN_CACHE_DIR", "~/.cache/penguin")
        ).expanduser()
    )
    # Fast startup configuration
    fast_startup: bool = field(default=False)
    model_configs: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    agent_personas: Dict[str, AgentPersonaConfig] = field(default_factory=dict)
    
    # Dictionary-like access to model settings
    @property
    def model(self) -> Dict[str, Any]:
        """
        Provide dictionary-like access to model settings.
        For compatibility with code expecting a dict-like interface.
        """
        if self.model_config is None:
            return {}
            
        result = {}
        # Common model parameters
        attrs = ["provider", "client_preference", "streaming_enabled", "api_base", 
                 "max_output_tokens", "temperature", "vision_enabled", "use_assistants_api"]
        
        for attr in attrs:
            if hasattr(self.model_config, attr):
                result[attr] = getattr(self.model_config, attr)
        
        # Add method for dictionary-like access
        def get(key, default=None):
            return result.get(key, default)
            
        result["get"] = get
        return result

    def __post_init__(self):
        # Initialize model_config if it's None
        if self.model_config is None:
            # Import inside the method to avoid circular imports
            from penguin.llm.model_config import ModelConfig as LLMModelConfig
            self.model_config = LLMModelConfig.from_env()
        if self.model_configs is None:
            self.model_configs = {}
        if self.agent_personas is None:
            self.agent_personas = {}
        if self.output is None:
            self.output = OutputConfig()

    @classmethod
    def load_config(cls, config_path: Optional[Path] = None) -> "Config":
        """Load effective Penguin config using the central resolver.

        This delegates to the top‑level load_config() in this module, which
        merges config from (in order): package defaults, dev repo defaults,
        user config (~/.config/penguin/config.yml), project overrides, and
        an explicit PENGUIN_CONFIG_PATH override. This avoids divergence
        between different config loading paths across the codebase.
        """
        # Import ModelConfig here to avoid circular imports
        from penguin.llm.model_config import ModelConfig as LLMModelConfig

        # Prefer the merged config resolver, unless an explicit file path was provided
        if config_path is None:
            config_data = load_config()
        else:
            try:
                with open(config_path) as f:
                    config_data = yaml.safe_load(f) or {}
            except (FileNotFoundError, yaml.YAMLError):
                config_data = {}

        if not isinstance(config_data, dict):
            config_data = {}

        if not config_data:
            logging.getLogger(__name__).warning(
                "No resolved config found. Falling back to environment defaults."
            )
            # Fall back to environment defaults
            default_llm_model_config = LLMModelConfig.from_env()
            return cls(model_config=default_llm_model_config)

        diagnostics_config = DiagnosticsConfig(
            enabled=config_data.get("diagnostics", {}).get("enabled", False),
            max_context_tokens=config_data.get("diagnostics", {}).get(
                "max_context_tokens", 400000 # TODO: Possible culprit. Make this a default value in the config.yml
            ),
            log_to_file=config_data.get("diagnostics", {}).get("log_to_file", False),
            log_path=Path(config_data["diagnostics"]["log_path"]) if config_data.get("diagnostics", {}).get("log_path") else None
        )

        output_settings = config_data.get("output", {})
        if not isinstance(output_settings, dict):
            output_settings = {}

        prompt_style_value = output_settings.get("prompt_style", "steps_final")
        if prompt_style_value is None:
            prompt_style_value = "steps_final"
        prompt_style = str(prompt_style_value).strip()
        if not prompt_style:
            prompt_style = "steps_final"

        show_tool_results_value = output_settings.get("show_tool_results", True)
        if isinstance(show_tool_results_value, str):
            show_tool_results = show_tool_results_value.strip().lower() in {"1", "true", "yes", "on"}
        else:
            show_tool_results = bool(show_tool_results_value)

        output_config = OutputConfig(
            prompt_style=prompt_style,
            show_tool_results=show_tool_results,
        )

        if diagnostics_config.enabled:
            log_level = logging.DEBUG if os.getenv("PENGUIN_DEBUG") else logging.INFO
            _configure_diagnostics_logging(diagnostics_config, log_level)
            logging.getLogger(__name__).info("Diagnostics enabled via config.yml.")
            
        # Initialize diagnostics using the loaded config
        init_diagnostics(config_data)

        # --- Determine Model Config --- #
        default_model_settings = config_data.get("model", {})
        # ENV VARS TAKE PRECEDENCE over config.yml for container deployments
        default_model_id = os.getenv("PENGUIN_DEFAULT_MODEL") or default_model_settings.get("default") or "anthropic/claude-3-5-sonnet-20240620"
        default_provider = os.getenv("PENGUIN_DEFAULT_PROVIDER") or default_model_settings.get("provider") or "openrouter"
        default_client_pref = os.getenv("PENGUIN_CLIENT_PREFERENCE") or default_model_settings.get("client_preference") or "openrouter"

        model_configs_section = config_data.get("model_configs")
        if not isinstance(model_configs_section, dict):
            model_configs_section = {}

        # Use the new for_model() method to dynamically resolve model-specific configs
        llm_model_config = LLMModelConfig.for_model(
            model_name=default_model_id,
            provider=default_provider,
            client_preference=default_client_pref,
            model_configs=model_configs_section
        )

        # Apply top-level model overrides (e.g., vision_enabled).
        # User's explicit config takes precedence over auto-detection in ModelConfig.__post_init__.
        if isinstance(default_model_settings, dict):
            if "vision_enabled" in default_model_settings:
                llm_model_config.vision_enabled = bool(
                    default_model_settings.get("vision_enabled")
                )

        # Resolve agent personas (Phase 1+ configuration surface)
        raw_personas = config_data.get("agents")
        if raw_personas is None:
            raw_personas = config_data.get("personas", {})
        agent_personas: Dict[str, AgentPersonaConfig] = {}
        if isinstance(raw_personas, dict):
            for persona_name, persona_config in raw_personas.items():
                if not isinstance(persona_config, dict):
                    logger.warning("Skipping persona '%s': expected a mapping, got %s", persona_name, type(persona_config).__name__)
                    continue
                try:
                    agent_personas[persona_name] = AgentPersonaConfig.from_dict(persona_name, persona_config)
                except Exception as exc:  # pragma: no cover - defensive, config errors should surface in logs
                    logger.warning("Failed to load agent persona '%s': %s", persona_name, exc)

        # Parse security config
        security_data = config_data.get("security", {})
        if not isinstance(security_data, dict):
            security_data = {}
        security_config = SecurityConfig.from_dict(security_data)

        return cls(
            model_config=llm_model_config,
            api=APIConfig(base_url=config_data.get("api", {}).get("base_url")),
            workspace_path=Path(WORKSPACE_PATH), # WORKSPACE_PATH is already defined globally
            temperature=config_data.get("temperature", llm_model_config.temperature), # Use model temp if global not set
            max_output_tokens=config_data.get("max_output_tokens", config_data.get("max_tokens", llm_model_config.max_output_tokens)),  # Accepts both old and new key
            diagnostics=diagnostics_config,
            security=security_config,
            output=output_config,
            fast_startup=config_data.get("performance", {}).get("fast_startup", False),
            model_configs=model_configs_section,
            agent_personas=agent_personas,
        )

    def to_dict(self) -> Dict[str, Any]:
        if not self.model_config.model:
            raise ValueError("model_name must be specified in the effective model config")

        return {
            "default_model_config": self.model_config.get_config(),
            "global_temperature": self.temperature,
            "global_max_output_tokens": self.max_output_tokens,
            "diagnostics": {
                "enabled": self.diagnostics.enabled,
                "max_context_tokens": self.diagnostics.max_context_tokens,
                "log_to_file": self.diagnostics.log_to_file,
                "log_path": str(self.diagnostics.log_path)
                if self.diagnostics.log_path
                else None,
            },
            "security": self.security.to_dict(),
            "output": {
                "prompt_style": getattr(self.output, "prompt_style", "steps_final"),
                "show_tool_results": getattr(self.output, "show_tool_results", True),
            },
            "workspace_dir": str(self.workspace_dir),
            "cache_dir": str(self.cache_dir),
            "workspace_path": str(self.workspace_path),
            "model_configs": self.model_configs,
            "agent_personas": {name: persona.to_dict() for name, persona in self.agent_personas.items()},
        }


# Add to existing config.py
CONVERSATIONS_PATH = WORKSPACE_PATH / "conversations"
CONVERSATIONS_PATH.mkdir(exist_ok=True)

# Add conversation-specific configuration
CONVERSATION_CONFIG = {
    "max_history": 1000000,
    "auto_save": True,
    "save_format": "json",
}

# Add after loading config
# print("Loaded DEEPSEEK_API_KEY exists:", os.getenv("DEEPSEEK_API_KEY") is not None)  # Debug check

# class BrowserConfig:
#     preferred_browser: str = 'chromium'  # 'chrome' or 'chromium'
#     suppress_popups: bool = True

def _configure_diagnostics_logging(diagnostics_config: "DiagnosticsConfig", log_level: int) -> None:
    """Route diagnostics logs to a managed file instead of stdout."""
    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)

    # Determine target log file
    if diagnostics_config.log_to_file and diagnostics_config.log_path:
        target_path = diagnostics_config.log_path
    else:
        log_dir = WORKSPACE_PATH / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        target_path = log_dir / "diagnostics.log"
        diagnostics_config.log_to_file = True
        diagnostics_config.log_path = target_path

    target_path.parent.mkdir(parents=True, exist_ok=True)

    handler_flag = "_penguin_diagnostics_handler"
    existing_handler = None
    for handler in list(root_logger.handlers):
        if getattr(handler, handler_flag, False):
            existing_handler = handler
            break

    if existing_handler:
        existing_path = Path(getattr(existing_handler, "baseFilename", ""))
        if existing_path != target_path:
            root_logger.removeHandler(existing_handler)
            existing_handler.close()
            existing_handler = None

    if not existing_handler:
        diagnostics_handler = RotatingFileHandler(
            target_path,
            maxBytes=5 * 1024 * 1024,
            backupCount=3,
            encoding="utf-8",
        )
        diagnostics_handler.setLevel(log_level)
        diagnostics_handler.setFormatter(
            logging.Formatter(
                "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
            )
        )
        setattr(diagnostics_handler, handler_flag, True)
        root_logger.addHandler(diagnostics_handler)

    # Ensure existing stdout/stderr handlers don't spam interactive sessions
    for handler in root_logger.handlers:
        if isinstance(handler, logging.StreamHandler):
            handler.setLevel(max(handler.level, logging.WARNING))


# =============================================================================
# MODULE-LEVEL __getattr__ FOR LAZY API KEY ACCESS
# =============================================================================
# This enables lazy loading when accessing API keys via attribute access
# e.g., `import penguin.config; penguin.config.TAVILY_API_KEY`
# Note: Direct imports like `from penguin.config import TAVILY_API_KEY` will
# get None initially; use get_api_key() for those cases.
# =============================================================================

def __getattr__(name: str):
    """Lazy loading for API key variables."""
    if name in _API_KEY_NAMES:
        _ensure_env_loaded()
        return os.environ.get(_API_KEY_NAMES[name])
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
