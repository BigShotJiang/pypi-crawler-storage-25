import uuid
import re
import unicodedata

import dill
import os
import types
from .api_dto import ApiDto
import inspect
from collections import OrderedDict
from enum import Enum


class ScriptType(Enum):
    """
    defines the type of script execution.
        - "wizata" builtin wizata library function (wizata. prefix)
        - "api" dill-serialized script stored on backend (DB + blob .pkl)
        - "module" function from an installed custom python module
        - "raw" raw .py source stored on blob, compiled at runtime
    """
    WIZATA = 'wizata'
    API = 'api'
    MODULE = 'module'
    RAW = 'raw'


class ScriptCategory(Enum):
    """
    Defines the category of a script, determining which pipeline step type it creates.
        - "function" data transformation scripts (creates a SCRIPT step)
        - "model" ML model training scripts (creates a MODEL step)
        - "plot" visualization scripts (creates a PLOT step)
    """
    FUNCTION = 'function'
    MODEL = 'model'
    PLOT = 'plot'


def sanitize_blob_name(name: str) -> str:
    """
    Sanitize a script name for use as a blob path segment.
    Normalizes unicode, replaces path separators and control characters,
    collapses underscores, strips leading/trailing problematic chars.
    """
    if name is None:
        raise ValueError("script name cannot be None")
    name = unicodedata.normalize('NFKC', name)
    name = re.sub(r'[/\\<>:|?*\x00-\x1f]', '_', name)
    name = re.sub(r'_+', '_', name)
    name = name.strip('_. ')
    if not name:
        raise ValueError("script name results in empty blob path after sanitization")
    return name


def get_imports(line) -> dict:
    keywords = []
    for item in line.split(' '):
        keywords.extend(item.split(','))
    keywords[:] = [x for x in keywords if x]

    if len(keywords) <= 1:
        return {}

    i = 0
    current_key = None
    definition = {}
    while i < len(keywords):
        word = keywords[i]
        if word in ['from', 'as', 'import']:
            current_key = word
        elif current_key is not None:
            if current_key not in definition or definition[current_key] is None:
                definition[current_key] = [word]
            else:
                definition[current_key].append(word)
        else:
            raise ValueError(f'{line} cannot be parsed for possible import.')
        i = i+1

    return definition


class ScriptConfig(ApiDto):
    """
    a script config defines execution properties for a specific script.
    usually to define how a pipeline should call your script.

    :ivar str function: name of function referencing the script.
    :ivar dict properties: specific properties to configure the script.
    :ivar dict properties_mapping: mapping used to rename properties from context to script expected name.
    """

    def __init__(self,
                 function=None,
                 library=None,
                 properties_mapping=None,
                 properties: dict = None,
                 script_type=None):
        self.function = function
        self.library = library
        self.properties = properties
        self.properties_mapping = properties_mapping
        self.script_type = script_type

    def from_json(self, obj):
        if isinstance(obj, str):
            self.function = obj
            return
        else:
            if "function" in obj:
                self.function = obj["function"]
            if "library" in obj:
                self.library = obj["library"]
            elif "script" in obj:
                self.function = obj["script"]
            if "properties" in obj:
                self.properties = obj["properties"]
            if "properties_mapping" in obj:
                self.properties_mapping = obj["properties_mapping"]
            if "script_type" in obj and obj["script_type"] is not None:
                self.script_type = ScriptType(obj["script_type"])

    def to_json(self, target: str = None):
        obj = {
            "function": self.function
        }
        if self.library is not None:
            obj["library"] = self.library
        if self.properties is not None and isinstance(self.properties, dict):
            obj["properties"] = self.properties
        if self.properties_mapping is not None and isinstance(self.properties_mapping, dict):
            obj["properties_mapping"] = self.properties_mapping
        if self.script_type is not None:
            obj["script_type"] = str(self.script_type.value)
        return obj

    def infer_script_type(self):
        """
        Return explicit script_type if set, otherwise infer from convention:
        - function starts with "wizata." -> LIBRARY_WIZATA
        - library field is set -> LIBRARY_CUSTOM
        - else -> API
        Note: RAW cannot be inferred; must be set explicitly.
        """
        if self.script_type is not None:
            return self.script_type
        if self.function is not None and str(self.function).startswith("wizata."):
            return ScriptType.WIZATA
        if self.library is not None:
            return ScriptType.MODULE
        return ScriptType.API


class Script(ApiDto):
    """
    A piece of python code that can transform data, generate plots or train ML models.

    :ivar uuid.UUID script_id: technical id of the script.
    :ivar str name: unique name of the script function (unique key within its type).
    :ivar str description: human-readable description of what the script does.
    :ivar ScriptType script_type: type of script execution (api, raw, module, wizata).
    :ivar str version: version string of the script.
    :ivar str library: key of the ScriptLibrary this script belongs to (module type only).
    :ivar str module: Python import path for import_module() (module type only, e.g. 'my_lib.transforms').
    :ivar callable function: the function as a callable object (not serialized).
    :ivar str source: python source code of the script (not serialized).
    """

    @classmethod
    def route(cls):
        return "scripts"

    @classmethod
    def from_dict(cls, data: dict):
        """
        Create a Script from a dict.
        Handles both new blob format and legacy backend format.
        """
        obj = Script()
        obj.from_json(data)
        return obj

    @classmethod
    def get_type(cls):
        return "json"

    def __init__(self, script_id=None, description=None, function=None,
                 script_type=None, version=None, library=None, category=None,
                 properties=None):

        # Id
        if script_id is None:
            script_id = uuid.uuid4()
        self.script_id = script_id
        self._name = None

        # Properties
        self.description = description
        self.script_type = script_type
        self.version = version
        self.library = library
        self.module = None
        self.category = category
        self.properties = properties if properties is not None else {}

        # Source code property (not serialized)
        self.source = None

        # Function properties (not serialized)
        self.function = None
        if function is not None:
            self.copy(function)

    @property
    def name(self):
        """
        Name of the function
        :return: name of the function
        """
        return self._name

    def api_id(self) -> str:
        """
        Id of the script (script_id)

        :return: string formatted UUID of the script.
        """
        return str(self.script_id).upper()

    @staticmethod
    def load_function_from_dill(pkl_bytes):
        """
        Deserialize dill bytes into a Function object.
        Handles both new format (Function only) and old format (entire Script).

        :param pkl_bytes: raw dill-serialized bytes.
        :return: Function object (or whatever was stored if not a Script).
        """
        loaded = dill.loads(pkl_bytes)
        if isinstance(loaded, Script):
            return loaded.function
        return loaded

    def endpoint(self) -> str:
        """
        Name of the endpoints used to manipulate scripts.
        :return: Endpoint name.
        """
        return "Scripts"

    def to_dict(self) -> dict:
        """
        Serialize Script to a clean dict.
        """
        obj = {
            "id": str(self.script_id),
        }
        if self.name is not None:
            obj["name"] = self.name
        if self.description is not None:
            obj["description"] = self.description
        if self.script_type is not None:
            obj["type"] = self.script_type.value
        if self.version is not None:
            obj["version"] = self.version
        if self.library is not None:
            obj["library"] = self.library
        if self.module is not None:
            obj["module"] = self.module
        if self.source is not None:
            obj["source"] = self.source
        if self.category is not None:
            obj["category"] = self.category.value
        if self.properties:
            obj["properties"] = self.properties
        return obj

    def to_json(self, target: str = None):
        """
        Convert the script to a dictionary compatible to JSON format.
        """
        return self.to_dict()

    def from_json(self, obj):
        """
        Load the Script entity from a dict.
        Handles both new format and legacy backend format.

        :param obj: Dict version of the Script.
        """
        if "id" in obj:
            self.script_id = uuid.UUID(obj["id"])
        if "name" in obj:
            self._name = obj["name"]
        if "description" in obj and obj["description"] is not None and obj["description"] != "None":
            self.description = obj["description"]
        if "type" in obj and obj["type"] is not None:
            self.script_type = ScriptType(obj["type"])
        if "version" in obj:
            self.version = obj["version"]
        if "library" in obj:
            self.library = obj["library"]
        if "module" in obj:
            self.module = obj["module"]
        if "source" in obj and obj["source"] is not None:
            self.source = obj["source"]
        if "category" in obj and obj["category"] is not None:
            self.category = ScriptCategory(obj["category"])
        if "properties" in obj and obj["properties"] is not None:
            self.properties = obj["properties"]

    def copy(self, myfunction):
        """
        Copy your function code and decorators to a format executable by the Wizata App.
        :param myfunction: your function - pass the function itself as parameter
        """

        if myfunction.__code__.co_argcount < 1:
            raise ValueError('your function must contains at least one parameter')

        self.function = Function()

        self.function.id = myfunction.__name__
        self.function.params = inspect.signature(myfunction).parameters

        self._name = myfunction.__name__

        self.function.code = myfunction.__code__

        f_globals = myfunction.__globals__
        self.function.globals = []

        # ADD GLOBAL IMPORTS
        k_global: str
        for k_global in f_globals:

            if self._name == k_global:
                pass
            elif isinstance(myfunction.__globals__[k_global], types.ModuleType):
                module = f_globals[k_global]
                self.function.append_global(definition={
                    "var": k_global,
                    "module": str(module.__name__)
                })

            elif not k_global.startswith('__') and not k_global.startswith('@') and not k_global.startswith('_'):
                obj = f_globals[k_global]
                if callable(obj) and hasattr(obj, '__module__'):
                    definition = {
                        "var": k_global,
                        'module': obj.__module__
                    }
                    if hasattr(obj, '__name__'):
                        definition['class'] = obj.__name__
                    self.function.append_global(definition)

        # ADD LOCAL IMPORTS
        for line in inspect.getsourcelines(myfunction)[0]:
            line = line.strip()
            if line.startswith("from ") or line.startswith("import "):
                imports = get_imports(line)
                if 'import' not in imports:
                    raise ValueError(f'from/import statement missing import {line}')

                if 'from' in imports:
                    if len(imports['from']) != 1:
                        raise ValueError(f'unsupported multiple from statement {line}')
                    if 'as' in imports:
                        if len(imports["import"]) != 1:
                            raise ValueError(f'unsupported multiple import statement with as {line}')
                        self.function.append_global({
                            'module': imports['from'][0],
                            'class': imports['import'][0],
                            'var': imports['as'][0]
                        })
                    else:
                        for import_class in imports['import']:
                            self.function.append_global({
                                'module': imports['from'][0],
                                'class': import_class,
                                'var': import_class
                            })
                else:
                    if 'as' in imports:
                        if len(imports["import"]) != 1:
                            raise ValueError(f'unsupported multiple import statement with as {line}')
                        self.function.append_global({
                            'module': imports['import'][0],
                            'var': imports['as'][0]
                        })
                    else:
                        for import_class in imports['import']:
                            self.function.append_global({
                                'module': import_class,
                                'var': import_class
                            })

        if myfunction.__code__.co_filename is not None:
            if os.path.exists(myfunction.__code__.co_filename):
                with open(myfunction.__code__.co_filename, "r") as f:
                    source_code = f.read()
                self.source = source_code


class ScriptLibrary:
    """
    Represents a custom library registration.
    Describes an installed Python package that exposes functions usable in pipelines.

    Metadata is stored in PostgreSQL; function entries are Script rows with
    script_type=MODULE and a foreign key back to this library's key.

    :ivar str key: unique identifier/key for this library registration.
    :ivar str package_name: pip package name (e.g. 'my-custom-lib').
    :ivar str module_name: Python import module name (e.g. 'my_custom_lib').
    :ivar str version: version string of the registered library.
    :ivar str description: human-readable description of the library.
    :ivar list functions: list of Script entries (script_type=MODULE).
    """

    def __init__(self,
                 key: str = None,
                 package_name: str = None,
                 module_name: str = None,
                 version: str = None,
                 description: str = None,
                 functions: list = None):
        self.key = key
        self.package_name = package_name
        self.module_name = module_name
        self.version = version
        self.description = description
        if functions is None:
            functions = []
        self.functions = functions

    @classmethod
    def from_dict(cls, data: dict):
        obj = ScriptLibrary()
        obj.key = data.get("key")
        obj.package_name = data.get("packageName") or data.get("package_name")
        obj.module_name = data.get("moduleName") or data.get("module_name")
        obj.version = data.get("version")
        obj.description = data.get("description")
        if "functions" in data and data["functions"] is not None:
            for func_data in data["functions"]:
                script = Script.from_dict(func_data)
                script.script_type = ScriptType.MODULE
                script.library = obj.key
                # "module" field = import path; falls back to library module_name
                if script.module is None:
                    script.module = obj.module_name
                obj.functions.append(script)
        return obj

    def to_dict(self) -> dict:
        obj = {}
        if self.key is not None:
            obj["key"] = self.key
        if self.package_name is not None:
            obj["packageName"] = self.package_name
        if self.module_name is not None:
            obj["moduleName"] = self.module_name
        if self.version is not None:
            obj["version"] = self.version
        if self.description is not None:
            obj["description"] = self.description
        if self.functions is not None and len(self.functions) > 0:
            obj["functions"] = [f.to_dict() for f in self.functions]
        return obj

    def get_function(self, name: str):
        """
        Find a function entry by name.
        :param name: function name to search.
        :return: Script or None.
        """
        for func in self.functions:
            if func.name == name:
                return func
        return None


def discover_from_wheel(wheel_source) -> ScriptLibrary:
    """
    Extract wizata.json manifest from a .whl file and parse into ScriptLibrary.

    The manifest should be placed inside the top-level package directory
    of the wheel (e.g. ``my_custom_lib/wizata.json``).

    :param wheel_source: filesystem path (str) or bytes content of the .whl file.
    :return: ScriptLibrary parsed from the manifest.
    :raises FileNotFoundError: if no wizata.json found in the wheel.
    :raises ValueError: if wizata.json is missing the required 'key' field.
    """
    import zipfile
    import json
    import io

    if isinstance(wheel_source, bytes):
        file_obj = io.BytesIO(wheel_source)
    else:
        file_obj = wheel_source

    with zipfile.ZipFile(file_obj, 'r') as zf:
        candidates = [n for n in zf.namelist()
                      if n.endswith('/wizata.json') or n == 'wizata.json']
        if not candidates:
            raise FileNotFoundError(
                f"no wizata.json found in wheel"
            )
        # prefer the shortest path (top-level package)
        candidates.sort(key=len)
        raw = zf.read(candidates[0])

    data = json.loads(raw)
    if "key" not in data:
        raise ValueError("wizata.json must contain a 'key' field")

    return ScriptLibrary.from_dict(data)


class Function:
    """
    Python Code Function

    :ivar id: technical name and then id of the function
    :ivar code: code of the function __code__
    :ivar globals: modules references __globals__
    """

    def __init__(self):
        self.id = None
        self.code = None
        self.globals = None
        self.params = OrderedDict()

    def append_global(self, definition: dict):
        exclusion_list = [
            '__main__',
            'IPython.core.interactiveshell',
            'IPython.core.autocall'
        ]
        if 'module' in definition and definition['module'] not in exclusion_list:
            self.globals.append(definition)


