import uuid
from enum import Enum
from .api_dto import ApiDto


class EdgeDeviceStatus(Enum):
    """
    Status of an edge device.
    """
    WAITING_FOR_REGISTRATION = "WaitingForRegistration"
    REGISTERED = "Registered"
    DEPLOYED = "Deployed"
    FAILED = "Failed"
    OFFLINE = "Offline"


class EdgeDeviceType(Enum):
    """
    Type of an edge device.
    """
    CONNECTIVITY = "Connectivity"
    CONNECTIVITY_AND_PIPELINES = "ConnectivityAndPipelines"
    CUSTOM = "Custom"


class EdgeDevice(ApiDto):
    """
    Edge device registered on the platform.

    :ivar uuid.UUID edge_device_id: technical id of the edge device.
    :ivar str device_id: logical device identifier string.
    :ivar str name: display name of the edge device.
    :ivar str twin_name: name of the associated twin.
    :ivar uuid.UUID twin_id: technical id of the associated twin.
    :ivar EdgeDeviceStatus status: current status of the device.
    :ivar int status_code: numeric status code.
    :ivar EdgeDeviceType device_type: type of the edge device.
    :ivar str connection_state: IoT Hub connection state ('Connected' or 'Disconnected'), enriched from IoT Hub.
    :ivar str last_activity_time: last device activity timestamp from IoT Hub.
    """

    @classmethod
    def route(cls):
        return "edgedevices"

    @classmethod
    def from_dict(cls, data):
        obj = EdgeDevice()
        obj.from_json(data)
        return obj

    def __init__(self,
                 edge_device_id: uuid.UUID = None,
                 device_id: str = None,
                 name: str = None,
                 twin_name: str = None,
                 twin_id: uuid.UUID = None,
                 status: EdgeDeviceStatus = None,
                 status_code: int = None,
                 device_type: EdgeDeviceType = None,
                 connection_state: str = None,
                 last_activity_time: str = None):
        if edge_device_id is None:
            self.edge_device_id = uuid.uuid4()
        else:
            self.edge_device_id = edge_device_id
        self.device_id = device_id
        self.name = name
        self.twin_name = twin_name
        self.twin_id = twin_id
        self.status = status
        self.status_code = status_code
        self.device_type = device_type
        self.connection_state = connection_state
        self.last_activity_time = last_activity_time

    def api_id(self) -> str:
        return str(self.edge_device_id).upper()

    def api_key(self) -> str:
        return self.device_id

    def set_id(self, id_value):
        self.edge_device_id = uuid.UUID(str(id_value))

    def endpoint(self) -> str:
        return "EdgeDevices"

    def from_json(self, obj):
        if "id" in obj and obj["id"] is not None:
            self.edge_device_id = uuid.UUID(obj["id"])
        if "deviceId" in obj and obj["deviceId"] is not None:
            self.device_id = obj["deviceId"]
        if "name" in obj and obj["name"] is not None:
            self.name = obj["name"]
        if "twinName" in obj and obj["twinName"] is not None:
            self.twin_name = obj["twinName"]
        if "twinId" in obj and obj["twinId"] is not None:
            self.twin_id = uuid.UUID(obj["twinId"])
        if "status" in obj and obj["status"] is not None:
            self.status = EdgeDeviceStatus(obj["status"])
        if "statusCode" in obj and obj["statusCode"] is not None:
            self.status_code = int(obj["statusCode"])
        if "deviceType" in obj and obj["deviceType"] is not None:
            self.device_type = EdgeDeviceType(obj["deviceType"])
        if "connectionState" in obj and obj["connectionState"] is not None:
            self.connection_state = obj["connectionState"]
        if "lastActivityTime" in obj and obj["lastActivityTime"] is not None:
            self.last_activity_time = obj["lastActivityTime"]

    def to_json(self, target: str = None):
        obj = {
            "id": str(self.edge_device_id)
        }
        if self.device_id is not None:
            obj["deviceId"] = self.device_id
        if self.name is not None:
            obj["name"] = self.name
        if self.twin_name is not None:
            obj["twinName"] = self.twin_name
        if self.twin_id is not None:
            obj["twinId"] = str(self.twin_id)
        if self.status is not None:
            obj["status"] = self.status.value
        if self.status_code is not None:
            obj["statusCode"] = self.status_code
        if self.device_type is not None:
            obj["deviceType"] = self.device_type.value
        if self.connection_state is not None:
            obj["connectionState"] = self.connection_state
        if self.last_activity_time is not None:
            obj["lastActivityTime"] = self.last_activity_time
        return obj