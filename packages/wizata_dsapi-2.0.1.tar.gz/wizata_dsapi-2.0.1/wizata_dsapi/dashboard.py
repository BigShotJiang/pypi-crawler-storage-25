"""
Dashboard DTO for mobile dashboard persistence.

DashboardType — platform the dashboard is designed for:
  - MOBILE: mobile app dashboard.

Dashboard — stores a named dashboard with an ordered list of tiles.
  Linked to either a template (by key) or a twin (by hardware_id), not both.
  Tiles are stored as a JSON array — tile order is array index.
"""

from datetime import datetime, timezone
from enum import Enum
from typing import Optional


class DashboardType(str, Enum):
    MOBILE = "mobile"


class Dashboard:
    """
    Dashboard entity stored in PostgreSQL ``"Dashboard"`` table.

    PK is ``id`` (UUID, server-generated).

    - ``name``: display name.
    - ``dashboard_type``: MOBILE (more values later).
    - ``template``: template key (mutually exclusive with ``twin``).
    - ``twin``: twin hardware ID (mutually exclusive with ``template``).
    - ``tiles``: ordered list of tile dicts (type + config).
    """

    def __init__(self):
        self.id: Optional[str] = None
        self.name: Optional[str] = None
        self.dashboard_type: Optional[DashboardType] = None
        self.template: Optional[str] = None
        self.twin: Optional[str] = None
        self.tiles: list = []
        self.created_at: Optional[datetime] = None
        self.updated_at: Optional[datetime] = None

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        obj = {}
        if self.id is not None:
            obj["id"] = str(self.id)
        if self.name is not None:
            obj["name"] = self.name
        if self.dashboard_type is not None:
            obj["dashboardType"] = (
                self.dashboard_type.value
                if isinstance(self.dashboard_type, DashboardType)
                else self.dashboard_type
            )
        if self.template is not None:
            obj["template"] = self.template
        if self.twin is not None:
            obj["twin"] = self.twin
        obj["tiles"] = list(self.tiles)
        if self.created_at is not None:
            obj["createdAt"] = int(self.created_at.timestamp() * 1000)
        if self.updated_at is not None:
            obj["updatedAt"] = int(self.updated_at.timestamp() * 1000)
        return obj

    @classmethod
    def from_dict(cls, data: dict) -> "Dashboard":
        obj = cls()
        obj.id = data.get("id")
        obj.name = data.get("name")

        raw_type = data.get("dashboardType") or data.get("dashboard_type")
        if raw_type is not None:
            obj.dashboard_type = DashboardType(raw_type.lower())

        obj.template = data.get("template")
        obj.twin = data.get("twin")
        obj.tiles = data.get("tiles") or []

        created_raw = data.get("createdAt") or data.get("created_at")
        if created_raw is not None:
            obj.created_at = datetime.fromtimestamp(created_raw / 1000, tz=timezone.utc)

        updated_raw = data.get("updatedAt") or data.get("updated_at")
        if updated_raw is not None:
            obj.updated_at = datetime.fromtimestamp(updated_raw / 1000, tz=timezone.utc)
        return obj

    # ------------------------------------------------------------------
    # API identity helpers
    # ------------------------------------------------------------------

    def api_id(self) -> str:
        return str(self.id) if self.id else None

    def api_key(self) -> str:
        return str(self.id) if self.id else None

    def set_id(self, value):
        self.id = str(value)

    def __repr__(self) -> str:
        return (
            f"Dashboard(id={self.id!r}, name={self.name!r}, "
            f"type={self.dashboard_type!r}, "
            f"template={self.template!r}, twin={self.twin!r})"
        )