from .api_dto import Dto


class EdgeConsumer(Dto):
    """
    A data source connector configured on an edge device.

    Known fields are extracted as attributes; everything else lands in ``extras``.
    Consumer types vary (opc-ua, mqtt, modbus, …) so type-specific fields are
    intentionally left unstructured.

    :ivar str id: connector identifier.
    :ivar str type: connector type (e.g. ``"opc-ua"``, ``"mqtt"``).
    :ivar str prefix: datapoint prefix applied by this consumer.
    :ivar dict extras: all other fields from the JSON config.
    """

    _KNOWN_KEYS = {"id", "type", "prefix"}

    def __init__(self, id=None, type=None, prefix=None, extras=None):
        self.id = id
        self.type = type
        self.prefix = prefix
        self.extras = extras or {}

    @classmethod
    def from_dict(cls, data: dict) -> "EdgeConsumer":
        extras = {k: v for k, v in data.items() if k not in cls._KNOWN_KEYS}
        return cls(
            id=data.get("id"),
            type=data.get("type"),
            prefix=data.get("prefix"),
            extras=extras,
        )

    def to_dict(self, include_extras=True) -> dict:
        obj = {}
        if self.id is not None:
            obj["id"] = self.id
        if self.type is not None:
            obj["type"] = self.type
        if self.prefix is not None:
            obj["prefix"] = self.prefix
        if include_extras and self.extras:
            obj.update(self.extras)
        return obj


class EdgeWriter(Dto):
    """
    A data output destination configured on an edge device.

    :ivar str id: writer identifier.
    :ivar str type: writer type (e.g. ``"tsdb"``, ``"hub"``, ``"opc-ua"``).
    :ivar datapoints: ``"*"`` for all, a list of datapoint names, or a dict mapping names to addresses.
    :ivar dict extras: all other fields from the JSON config.
    """

    _KNOWN_KEYS = {"id", "type", "datapoints"}

    def __init__(self, id=None, type=None, datapoints=None, extras=None):
        self.id = id
        self.type = type
        self.datapoints = datapoints
        self.extras = extras or {}

    @classmethod
    def from_dict(cls, data: dict) -> "EdgeWriter":
        extras = {k: v for k, v in data.items() if k not in cls._KNOWN_KEYS}
        return cls(
            id=data.get("id"),
            type=data.get("type"),
            datapoints=data.get("datapoints"),
            extras=extras,
        )

    def to_dict(self, include_extras=True) -> dict:
        obj = {}
        if self.id is not None:
            obj["id"] = self.id
        if self.type is not None:
            obj["type"] = self.type
        if self.datapoints is not None:
            obj["datapoints"] = self.datapoints
        if include_extras and self.extras:
            obj.update(self.extras)
        return obj


class EdgeTrigger(Dto):
    """
    A pipeline trigger configured on an edge device.

    :ivar str id: trigger identifier.
    :ivar int interval: execution interval in milliseconds.
    :ivar str pipeline_image_id: pipeline image reference (build tag + pipeline key).
    :ivar str twin: twin key this trigger targets.
    :ivar str template: template key this trigger targets.
    :ivar dict extras: all other fields from the JSON config.
    """

    _KNOWN_KEYS = {"id", "interval", "pipelineImageId", "twin", "template"}

    def __init__(self, id=None, interval=None, pipeline_image_id=None,
                 twin=None, template=None, extras=None):
        self.id = id
        self.interval = interval
        self.pipeline_image_id = pipeline_image_id
        self.twin = twin
        self.template = template
        self.extras = extras or {}

    @classmethod
    def from_dict(cls, data: dict) -> "EdgeTrigger":
        extras = {k: v for k, v in data.items() if k not in cls._KNOWN_KEYS}
        return cls(
            id=data.get("id"),
            interval=data.get("interval"),
            pipeline_image_id=data.get("pipelineImageId"),
            twin=data.get("twin"),
            template=data.get("template"),
            extras=extras,
        )

    def to_dict(self, include_extras=True) -> dict:
        obj = {}
        if self.id is not None:
            obj["id"] = self.id
        if self.interval is not None:
            obj["interval"] = self.interval
        if self.pipeline_image_id is not None:
            obj["pipelineImageId"] = self.pipeline_image_id
        if self.twin is not None:
            obj["twin"] = self.twin
        if self.template is not None:
            obj["template"] = self.template
        if include_extras and self.extras:
            obj.update(self.extras)
        return obj
