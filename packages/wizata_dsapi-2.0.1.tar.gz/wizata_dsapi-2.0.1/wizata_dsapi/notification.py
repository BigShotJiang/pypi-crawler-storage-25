"""
Push notification DTOs.

NotificationScope — event source for alert rules and device subscriptions:
  - PIPELINE_USER:    user-defined alert block inside a pipeline.
  - EDGE_MONITOR:     system rule monitoring edge connectivity.
  - PIPELINE_MONITOR: system rule monitoring pipeline health.

DeviceToken — FCM registration token with multi-scope and twin-filter support.
  twins filter: empty list = all twins; otherwise scoped to specific hardware IDs.

AlertRule — defines when and how an alert fires (thresholds, expiration).

AlertActive — tracks a currently active alert episode per rule + twin.

NotificationPreference — per-user channel enable/disable (global).

RecipientList — named list of internal users (follow preferences) and free entries
                (explicit address + channel).
"""

from datetime import datetime, timezone
from enum import Enum
from typing import Optional
import uuid


class NotificationScope(str, Enum):
    PIPELINE_USER = "pipeline_user"
    EDGE_MONITOR = "edge_monitor"
    PIPELINE_MONITOR = "pipeline_monitor"
    DATAPOINT_MONITOR = "datapoint_monitor"


class DeviceToken:
    """
    FCM device registration token stored in PostgreSQL ``"DeviceToken"`` table.

    Primary key is ``(token, tenant_id)`` — one row per device per tenant.

    Pure token registration — scopes and twins are on NotificationPreference.
    """

    def __init__(self):
        self.token: Optional[str] = None
        self.tenant_id: Optional[str] = None
        self.user_id: Optional[str] = None
        self.platform: Optional[str] = None
        self.created_at: Optional[datetime] = None

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        obj = {}
        if self.token is not None:
            obj["token"] = self.token
        if self.tenant_id is not None:
            obj["tenantId"] = self.tenant_id
        if self.user_id is not None:
            obj["userId"] = self.user_id
        if self.platform is not None:
            obj["platform"] = self.platform
        if self.created_at is not None:
            obj["createdAt"] = self.created_at.isoformat()
        return obj

    @classmethod
    def from_dict(cls, data: dict) -> "DeviceToken":
        obj = cls()
        obj.token = data.get("token")
        obj.tenant_id = data.get("tenantId") or data.get("tenant_id")
        obj.user_id = data.get("userId") or data.get("user_id")
        obj.platform = data.get("platform")

        created_raw = data.get("createdAt") or data.get("created_at")
        if created_raw is not None:
            obj.created_at = datetime.fromisoformat(created_raw)
        return obj

    # ------------------------------------------------------------------
    # API identity helpers
    # ------------------------------------------------------------------

    def api_id(self) -> str:
        return self.token

    def api_key(self) -> str:
        return self.token

    def __repr__(self) -> str:
        return (
            f"DeviceToken(tenant={self.tenant_id!r}, user={self.user_id!r}, "
            f"platform={self.platform!r})"
        )


class AlertRule:
    """
    Defines when and how an alert fires.

    Stored in PostgreSQL ``"AlertRule"`` table. PK is ``id`` (UUID).

    - ``event_type``: user-defined short text tag categorising the alert
                      (also stored in InfluxDB as a tag).
    - ``scope``: determines the notification scope (pipeline_user, edge_monitor,
                 pipeline_monitor).
    - ``expiration_cycles``: how many missed intervals before the active alert
                             auto-expires.
    - ``activation_threshold``: how many occurrences before the first notification
                                is sent.
    """

    def __init__(self):
        self.id: Optional[str] = None
        self.event_type: Optional[str] = None
        self.pipeline_key: Optional[str] = None
        self.group_system: Optional[str] = None
        self.hardware_id: Optional[str] = None
        self.scope: Optional[NotificationScope] = None
        self.expiration_cycles: int = 3
        self.activation_threshold: int = 1

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        obj = {}
        if self.id is not None:
            obj["id"] = str(self.id)
        if self.event_type is not None:
            obj["eventType"] = self.event_type
        if self.pipeline_key is not None:
            obj["pipelineKey"] = self.pipeline_key
        if self.group_system is not None:
            obj["groupSystem"] = self.group_system
        if self.hardware_id is not None:
            obj["hardwareId"] = self.hardware_id
        if self.scope is not None:
            obj["scope"] = self.scope.value if isinstance(self.scope, NotificationScope) else self.scope
        obj["expirationCycles"] = self.expiration_cycles
        obj["activationThreshold"] = self.activation_threshold
        return obj

    @classmethod
    def from_dict(cls, data: dict) -> "AlertRule":
        obj = cls()
        obj.id = data.get("id")
        obj.event_type = data.get("eventType") or data.get("event_type")
        obj.pipeline_key = data.get("pipelineKey") or data.get("pipeline_key")
        obj.group_system = data.get("groupSystem") or data.get("group_system")
        obj.hardware_id = data.get("hardwareId") or data.get("hardware_id")

        raw_scope = data.get("scope")
        if raw_scope is not None:
            obj.scope = NotificationScope(raw_scope.lower())

        obj.expiration_cycles = data.get("expirationCycles", data.get("expiration_cycles", 3))
        obj.activation_threshold = data.get("activationThreshold", data.get("activation_threshold", 1))
        return obj

    # ------------------------------------------------------------------
    # API identity helpers
    # ------------------------------------------------------------------

    def api_id(self) -> str:
        return str(self.id) if self.id else None

    def api_key(self) -> str:
        return str(self.id) if self.id else None

    def set_id(self, value):
        self.id = str(value)

    def __repr__(self) -> str:
        return (
            f"AlertRule(id={self.id!r}, event_type={self.event_type!r}, "
            f"scope={self.scope!r}, pipeline_key={self.pipeline_key!r})"
        )


class AlertActive:
    """
    Tracks a currently active alert episode.

    Stored in PostgreSQL ``"AlertActive"`` table.
    Composite PK is ``(alert_rule_id, twin_id)`` — one active episode per rule per twin.

    - ``twin_id``: hardware ID of the twin; defaults to ``""`` when not
                   associated with a specific twin.
    - ``interval_seconds``: pipeline execution interval at trigger time, used
                            with ``expiration_cycles`` to compute auto-expiry.
    - ``occurrence_count``: increments on each trigger; notification fires when
                            ``>= activation_threshold``.
    - ``severity``: 1–7 scale.
    """

    def __init__(self):
        self.alert_rule_id: Optional[str] = None
        self.twin_id: str = ""
        self.scope: Optional[NotificationScope] = None
        self.first_occurrence: Optional[datetime] = None
        self.last_occurrence: Optional[datetime] = None
        self.interval_seconds: int = 0
        self.occurrence_count: int = 0
        self.notification_sent_at: Optional[datetime] = None
        self.title: Optional[str] = None
        self.body: Optional[str] = None
        self.severity: int = 1

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        obj = {}
        if self.alert_rule_id is not None:
            obj["alertRuleId"] = str(self.alert_rule_id)
        obj["twinId"] = self.twin_id or ""
        if self.scope is not None:
            obj["scope"] = self.scope.value if isinstance(self.scope, NotificationScope) else self.scope
        if self.first_occurrence is not None:
            obj["firstOccurrence"] = self.first_occurrence.isoformat()
        if self.last_occurrence is not None:
            obj["lastOccurrence"] = self.last_occurrence.isoformat()
        obj["intervalSeconds"] = self.interval_seconds
        obj["occurrenceCount"] = self.occurrence_count
        if self.notification_sent_at is not None:
            obj["notificationSentAt"] = self.notification_sent_at.isoformat()
        if self.title is not None:
            obj["title"] = self.title
        if self.body is not None:
            obj["body"] = self.body
        obj["severity"] = self.severity
        return obj

    @classmethod
    def from_dict(cls, data: dict) -> "AlertActive":
        obj = cls()
        obj.alert_rule_id = data.get("alertRuleId") or data.get("alert_rule_id")
        obj.twin_id = data.get("twinId", data.get("twin_id", "")) or ""

        raw_scope = data.get("scope")
        if raw_scope is not None:
            obj.scope = NotificationScope(raw_scope.lower())

        for key in ("firstOccurrence", "first_occurrence"):
            raw = data.get(key)
            if raw is not None:
                obj.first_occurrence = datetime.fromisoformat(raw) if isinstance(raw, str) else raw
                break

        for key in ("lastOccurrence", "last_occurrence"):
            raw = data.get(key)
            if raw is not None:
                obj.last_occurrence = datetime.fromisoformat(raw) if isinstance(raw, str) else raw
                break

        obj.interval_seconds = data.get("intervalSeconds", data.get("interval_seconds", 0))
        obj.occurrence_count = data.get("occurrenceCount", data.get("occurrence_count", 0))

        for key in ("notificationSentAt", "notification_sent_at"):
            raw = data.get(key)
            if raw is not None:
                obj.notification_sent_at = datetime.fromisoformat(raw) if isinstance(raw, str) else raw
                break

        obj.title = data.get("title")
        obj.body = data.get("body")
        obj.severity = data.get("severity", 1)
        return obj

    # ------------------------------------------------------------------
    # API identity helpers
    # ------------------------------------------------------------------

    def api_id(self) -> str:
        return f"{self.alert_rule_id}:{self.twin_id}"

    def api_key(self) -> str:
        return f"{self.alert_rule_id}:{self.twin_id}"

    def __repr__(self) -> str:
        return (
            f"AlertActive(rule={self.alert_rule_id!r}, twin={self.twin_id!r}, "
            f"count={self.occurrence_count}, severity={self.severity})"
        )


class MonitoredDatapoint:
    """
    Registry entry for a datapoint flagged for monitoring.

    Stored in PostgreSQL ``"MonitoredDatapoint"`` table.
    PK is ``hardware_id`` (one row per datapoint).

    The datapoint_monitor job reads this table and creates independent
    AlertRule/AlertActive entries per event type (disconnected, out_of_range,
    misconfigured).
    """

    def __init__(self, hardware_id: str = None):
        self.hardware_id: Optional[str] = hardware_id
        self.created_at: Optional[datetime] = None

    def to_dict(self) -> dict:
        obj = {}
        if self.hardware_id is not None:
            obj["hardwareId"] = self.hardware_id
        if self.created_at is not None:
            obj["createdAt"] = int(self.created_at.timestamp() * 1000)
        return obj

    @classmethod
    def from_dict(cls, data: dict) -> "MonitoredDatapoint":
        obj = cls()
        obj.hardware_id = data.get("hardwareId") or data.get("hardware_id")
        raw = data.get("createdAt") or data.get("created_at")
        if raw is not None:
            if isinstance(raw, (int, float)):
                obj.created_at = datetime.fromtimestamp(raw / 1000, tz=timezone.utc)
            elif isinstance(raw, datetime):
                obj.created_at = raw
        return obj

    def api_id(self) -> str:
        return self.hardware_id

    def api_key(self) -> str:
        return self.hardware_id

    def set_id(self, value):
        self.hardware_id = str(value)

    def __repr__(self) -> str:
        return f"MonitoredDatapoint(hardware_id={self.hardware_id!r})"


class MonitoredPipeline:
    """
    Registry entry for a pipeline flagged for monitoring.

    Stored in PostgreSQL ``"MonitoredPipeline"`` table.
    PK is ``key`` (pipeline key string, one row per pipeline).

    The pipeline_monitor job reads this table and creates independent
    AlertRule/AlertActive entries per event type (not_triggered, failed).
    """

    def __init__(self, key: str = None):
        self.key: Optional[str] = key
        self.created_at: Optional[datetime] = None

    def to_dict(self) -> dict:
        obj = {}
        if self.key is not None:
            obj["key"] = self.key
        if self.created_at is not None:
            obj["createdAt"] = int(self.created_at.timestamp() * 1000)
        return obj

    @classmethod
    def from_dict(cls, data: dict) -> "MonitoredPipeline":
        obj = cls()
        obj.key = data.get("key")
        raw = data.get("createdAt") or data.get("created_at")
        if raw is not None:
            if isinstance(raw, (int, float)):
                obj.created_at = datetime.fromtimestamp(raw / 1000, tz=timezone.utc)
            elif isinstance(raw, datetime):
                obj.created_at = raw
        return obj

    def api_id(self) -> str:
        return self.key

    def api_key(self) -> str:
        return self.key

    def set_id(self, value):
        self.key = str(value)

    def __repr__(self) -> str:
        return f"MonitoredPipeline(key={self.key!r})"


class NotificationPreference:
    """
    Per-user notification channel preferences stored in PostgreSQL
    ``"NotificationPreference"`` table.

    PK is ``user_id`` (platform user UUID).  Each boolean flag controls
    whether the user receives notifications through that channel.
    Push is enabled by default; all others are disabled.
    """

    def __init__(self):
        self.user_id: Optional[str] = None
        self.push_enabled: bool = True
        self.email_enabled: bool = False
        self.sms_enabled: bool = False
        self.whatsapp_enabled: bool = False
        self.scopes: list = [NotificationScope.PIPELINE_USER]
        self.twins: list = []
        self.created_at: Optional[datetime] = None
        self.updated_at: Optional[datetime] = None

    # ------------------------------------------------------------------
    # Channel helper
    # ------------------------------------------------------------------

    def is_channel_enabled(self, alert_type) -> bool:
        """Check if a channel is enabled given an AlertType enum value."""
        mapping = {
            "push_notification": self.push_enabled,
            "email": self.email_enabled,
            "sms": self.sms_enabled,
            "whatsapp": self.whatsapp_enabled,
        }
        key = alert_type.value if hasattr(alert_type, "value") else str(alert_type)
        return mapping.get(key, False)

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        obj = {}
        if self.user_id is not None:
            obj["userId"] = self.user_id
        obj["pushEnabled"] = self.push_enabled
        obj["emailEnabled"] = self.email_enabled
        obj["smsEnabled"] = self.sms_enabled
        obj["whatsappEnabled"] = self.whatsapp_enabled
        obj["scopes"] = [s.value if isinstance(s, NotificationScope) else s for s in self.scopes]
        obj["twins"] = list(self.twins)
        if self.created_at is not None:
            obj["createdAt"] = self.created_at.isoformat()
        if self.updated_at is not None:
            obj["updatedAt"] = self.updated_at.isoformat()
        return obj

    @classmethod
    def from_dict(cls, data: dict) -> "NotificationPreference":
        obj = cls()
        obj.user_id = data.get("userId") or data.get("user_id")
        obj.push_enabled = data.get("pushEnabled", data.get("push_enabled", True))
        obj.email_enabled = data.get("emailEnabled", data.get("email_enabled", False))
        obj.sms_enabled = data.get("smsEnabled", data.get("sms_enabled", False))
        obj.whatsapp_enabled = data.get("whatsappEnabled", data.get("whatsapp_enabled", False))

        raw_scopes = data.get("scopes")
        if raw_scopes is not None:
            obj.scopes = [NotificationScope(s.lower()) for s in raw_scopes]
        else:
            obj.scopes = [NotificationScope.PIPELINE_USER]
        obj.twins = data.get("twins") or []

        for key in ("createdAt", "created_at"):
            raw = data.get(key)
            if raw is not None:
                obj.created_at = datetime.fromisoformat(raw) if isinstance(raw, str) else raw
                break

        for key in ("updatedAt", "updated_at"):
            raw = data.get(key)
            if raw is not None:
                obj.updated_at = datetime.fromisoformat(raw) if isinstance(raw, str) else raw
                break

        return obj

    # ------------------------------------------------------------------
    # API identity helpers
    # ------------------------------------------------------------------

    def api_id(self) -> str:
        return self.user_id

    def api_key(self) -> str:
        return self.user_id

    def set_id(self, value):
        self.user_id = str(value)

    def __repr__(self) -> str:
        channels = []
        if self.push_enabled:
            channels.append("push")
        if self.email_enabled:
            channels.append("email")
        if self.sms_enabled:
            channels.append("sms")
        if self.whatsapp_enabled:
            channels.append("whatsapp")
        return (
            f"NotificationPreference(user={self.user_id!r}, channels={channels}, "
            f"scopes={[s.value for s in self.scopes]}, twins={self.twins!r})"
        )


class RecipientType(str, Enum):
    INTERNAL = "internal"
    FREE = "free"


class Recipient:
    """
    A single entry in a :class:`RecipientList`.

    **Internal** (``recipient_type=INTERNAL``):
        References a platform user by ``user_id``.  Dispatch follows the
        user's :class:`NotificationPreference`.

    **Free** (``recipient_type=FREE``):
        Explicit ``address`` (email, phone number) with a specified
        ``channel`` (SMS, EMAIL, or WHATSAPP only — no PUSH_NOTIFICATION).
    """

    def __init__(self,
                 recipient_type: RecipientType = None,
                 user_id: str = None,
                 address: str = None,
                 channel=None,
                 name: str = None):
        self.recipient_type: Optional[RecipientType] = recipient_type
        self.user_id: Optional[str] = user_id
        self.address: Optional[str] = address
        self.channel = channel  # AlertType or None
        self.name: Optional[str] = name

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        obj = {}
        if self.recipient_type is not None:
            obj["recipientType"] = self.recipient_type.value if isinstance(self.recipient_type, RecipientType) else self.recipient_type
        if self.user_id is not None:
            obj["userId"] = self.user_id
        if self.address is not None:
            obj["address"] = self.address
        if self.channel is not None:
            obj["channel"] = self.channel.value if hasattr(self.channel, "value") else self.channel
        if self.name is not None:
            obj["name"] = self.name
        return obj

    @classmethod
    def from_dict(cls, data: dict) -> "Recipient":
        obj = cls()
        raw_type = data.get("recipientType") or data.get("recipient_type")
        if raw_type is not None:
            obj.recipient_type = RecipientType(raw_type)
        obj.user_id = data.get("userId") or data.get("user_id")
        obj.address = data.get("address")
        raw_channel = data.get("channel")
        if raw_channel is not None:
            from .pipeline import AlertType
            obj.channel = AlertType(raw_channel)
        obj.name = data.get("name")
        return obj

    def __repr__(self) -> str:
        if self.recipient_type == RecipientType.INTERNAL:
            return f"Recipient(internal, user={self.user_id!r})"
        return f"Recipient(free, address={self.address!r}, channel={self.channel!r})"


class RecipientList:
    """
    Named list of notification recipients stored in PostgreSQL
    ``"RecipientList"`` table.

    PK is ``key`` — a short, user-defined string identifier (like Template key).

    Each entry is a :class:`Recipient` — either an internal user reference
    (follows preferences) or a free address with explicit channel.
    """

    def __init__(self, key: str = None, name: str = None):
        self.key: Optional[str] = key
        self.name: Optional[str] = name
        self.description: Optional[str] = None
        self.entries: list = []
        self.created_at: Optional[datetime] = None
        self.updated_at: Optional[datetime] = None

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        obj = {}
        if self.key is not None:
            obj["key"] = self.key
        if self.name is not None:
            obj["name"] = self.name
        if self.description is not None:
            obj["description"] = self.description
        obj["entries"] = [e.to_dict() for e in self.entries]
        if self.created_at is not None:
            obj["createdAt"] = self.created_at.isoformat()
        if self.updated_at is not None:
            obj["updatedAt"] = self.updated_at.isoformat()
        return obj

    @classmethod
    def from_dict(cls, data: dict) -> "RecipientList":
        obj = cls()
        obj.key = data.get("key")
        obj.name = data.get("name")
        obj.description = data.get("description")
        raw_entries = data.get("entries") or []
        obj.entries = [Recipient.from_dict(e) for e in raw_entries]

        for dt_key in ("createdAt", "created_at"):
            raw = data.get(dt_key)
            if raw is not None:
                obj.created_at = datetime.fromisoformat(raw) if isinstance(raw, str) else raw
                break

        for dt_key in ("updatedAt", "updated_at"):
            raw = data.get(dt_key)
            if raw is not None:
                obj.updated_at = datetime.fromisoformat(raw) if isinstance(raw, str) else raw
                break

        return obj

    # ------------------------------------------------------------------
    # API identity helpers
    # ------------------------------------------------------------------

    def api_id(self) -> str:
        return self.key

    def api_key(self) -> str:
        return self.key

    def set_id(self, value):
        self.key = str(value)

    def __repr__(self) -> str:
        return (
            f"RecipientList(key={self.key!r}, name={self.name!r}, "
            f"entries={len(self.entries)})"
        )