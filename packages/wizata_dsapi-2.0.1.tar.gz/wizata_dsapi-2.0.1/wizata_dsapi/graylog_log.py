from typing import Optional
from datetime import datetime, timezone


class GraylogLog:
    """
    DTO for a single Graylog log entry.

    Represents a log message from Graylog with standard GELF fields
    plus Wizata custom fields (appId, edgeDeviceId, etc.).

    Timestamps are always milliseconds (int) in serialized form.

    :ivar int timestamp: event timestamp in milliseconds
    :ivar str message: log message text
    :ivar int level: syslog severity level (0=Emergency .. 7=Debug)
    :ivar str source: source hostname
    :ivar str app_id: application identifier
    :ivar str edge_device_id: IoT Edge device identifier
    :ivar str env: environment name
    :ivar str tenant_id: tenant identifier
    :ivar dict extra: any additional fields from the Graylog message
    """

    @classmethod
    def from_dict(cls, data: dict) -> "GraylogLog":
        """
        Deserialize a Graylog message dict into a GraylogLog.

        Graylog returns timestamps as ISO 8601 strings — these are
        converted to millisecond timestamps.

        :param data: Graylog message dict (from API response message field).
        """
        timestamp = data.get("timestamp")
        timestamp_ms = None
        if timestamp is not None:
            if isinstance(timestamp, (int, float)):
                timestamp_ms = int(timestamp)
            elif isinstance(timestamp, str):
                timestamp_ms = cls._parse_graylog_timestamp(timestamp)

        known_fields = {
            "timestamp", "message", "level", "source",
            "appId", "app_id",
            "edgeDeviceId", "edge_device_id",
            "env", "tenantId", "tenant_id",
            "gl2_message_id", "gl2_remote_ip", "gl2_remote_port",
            "gl2_source_input", "gl2_source_node",
            "streams", "_id", "facility",
        }
        extra = {k: v for k, v in data.items() if k not in known_fields}

        return cls(
            timestamp=timestamp_ms,
            message=data.get("message"),
            level=int(data["level"]) if "level" in data and data["level"] is not None else None,
            source=data.get("source"),
            app_id=data.get("appId") or data.get("app_id"),
            edge_device_id=data.get("edgeDeviceId") or data.get("edge_device_id"),
            env=data.get("env"),
            tenant_id=data.get("tenantId") or data.get("tenant_id"),
            extra=extra if extra else None,
        )

    def __init__(self,
                 timestamp: Optional[int] = None,
                 message: Optional[str] = None,
                 level: Optional[int] = None,
                 source: Optional[str] = None,
                 app_id: Optional[str] = None,
                 edge_device_id: Optional[str] = None,
                 env: Optional[str] = None,
                 tenant_id: Optional[str] = None,
                 extra: Optional[dict] = None):
        self.timestamp = timestamp
        self.message = message
        self.level = level
        self.source = source
        self.app_id = app_id
        self.edge_device_id = edge_device_id
        self.env = env
        self.tenant_id = tenant_id
        self.extra = extra or {}

    def to_dict(self) -> dict:
        """
        Serialize to a camelCase dict.
        Timestamps are millisecond integers.
        """
        data = {}
        if self.timestamp is not None:
            data["timestamp"] = self.timestamp
        if self.message is not None:
            data["message"] = self.message
        if self.level is not None:
            data["level"] = self.level
        if self.source is not None:
            data["source"] = self.source
        if self.app_id is not None:
            data["appId"] = self.app_id
        if self.edge_device_id is not None:
            data["edgeDeviceId"] = self.edge_device_id
        if self.env is not None:
            data["env"] = self.env
        if self.tenant_id is not None:
            data["tenantId"] = self.tenant_id
        if self.extra:
            data.update(self.extra)
        return data

    @staticmethod
    def _parse_graylog_timestamp(ts_str: str) -> Optional[int]:
        """
        Parse a Graylog ISO 8601 timestamp string to milliseconds.
        Graylog format: '2024-01-15T10:30:00.123Z' or '2024-01-15 10:30:00.123'
        """
        formats = [
            "%Y-%m-%dT%H:%M:%S.%fZ",
            "%Y-%m-%dT%H:%M:%SZ",
            "%Y-%m-%dT%H:%M:%S.%f",
            "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%d %H:%M:%S.%f",
            "%Y-%m-%d %H:%M:%S",
        ]
        for fmt in formats:
            try:
                dt = datetime.strptime(ts_str, fmt).replace(tzinfo=timezone.utc)
                return int(dt.timestamp() * 1000)
            except ValueError:
                continue
        return None