import enum
import uuid
from typing import Optional


class UserType(enum.Enum):
    USER = 0
    API_KEY = 1


class User:

    def __init__(self):
        self.id: Optional[uuid.UUID] = None
        self.ad_id: Optional[uuid.UUID] = None
        self.first_name: Optional[str] = None
        self.last_name: Optional[str] = None
        self.email: Optional[str] = None
        self.phone: Optional[str] = None
        self.user_type: Optional[UserType] = None

    @classmethod
    def from_dict(cls, data: dict) -> "User":
        obj = cls()
        if "id" in data and data["id"] is not None:
            obj.id = uuid.UUID(str(data["id"]))
        if "adId" in data and data["adId"] is not None:
            obj.ad_id = uuid.UUID(str(data["adId"]))
        obj.first_name = data.get("firstName")
        obj.last_name = data.get("lastName")
        obj.email = data.get("email")
        obj.phone = data.get("phone")
        raw_type = data.get("userType")
        if raw_type is not None:
            obj.user_type = UserType(int(raw_type))
        return obj

    def to_dict(self) -> dict:
        obj = {}
        if self.id is not None:
            obj["id"] = str(self.id)
        if self.ad_id is not None:
            obj["adId"] = str(self.ad_id)
        if self.first_name is not None:
            obj["firstName"] = self.first_name
        if self.last_name is not None:
            obj["lastName"] = self.last_name
        if self.email is not None:
            obj["email"] = self.email
        if self.phone is not None:
            obj["phone"] = self.phone
        if self.user_type is not None:
            obj["userType"] = self.user_type.value
        return obj

    def api_id(self) -> Optional[str]:
        return str(self.id) if self.id else None

    def api_key(self) -> Optional[str]:
        return str(self.ad_id) if self.ad_id else None

    def set_id(self, id_value):
        self.id = uuid.UUID(str(id_value))
