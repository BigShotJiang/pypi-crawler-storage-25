"""
Wizata chart theme for Plotly figures.

Provides consistent colors, fonts, and layout defaults
designed for rendering on the Wizata platform dark background.
"""

# -- Brand --------------------------------------------------------------------
MAIN_COLOR = "#E64600"

# Blue shades
SECONDARY = "#184980"
TERTIARY = "#031E37"
FOURTH = "#062B56"

WHITE = "#FFFFFF"
TEXT_MUTED = "#B8C4D0"
BACKGROUND = "#01101D"

# -- Status -------------------------------------------------------------------
STATUS_SUCCESS = "#7CFFB2"
STATUS_WARNING = "#FDDD60"
STATUS_ERROR = "#FF6E76"
STATUS_INFO = "#4992FF"
STATUS_ABORTED = "#9B9BA2"

# -- Data series (ordered cycle) ----------------------------------------------
SERIES_COLORS = [
    "#7CFFB2",
    "#9E7CFF",
    "#FDDD60",
    "#4992FF",
    "#6FE7F7",
    "#E992FF",
    "#FF6E76",
    "#FFA686",
    "#D1E2EE",
    "#FFF0B5",
    "#91C778",
    "#7B7D88",
]

# -- Semantic -----------------------------------------------------------------
ANOMALY_COLOR = "rgba(255,110,118,0.25)"  # STATUS_ERROR at 25%
POSITIVE_COLOR = STATUS_SUCCESS
NEGATIVE_COLOR = STATUS_ERROR
NEUTRAL_COLOR = STATUS_INFO

# -- Table --------------------------------------------------------------------
TABLE_HEADER_BG = SECONDARY
TABLE_HEADER_TEXT = WHITE
TABLE_CELL_BG = [TERTIARY, FOURTH]
TABLE_CELL_TEXT = TEXT_MUTED
TABLE_LINE_COLOR = "rgba(255,255,255,0.12)"

# -- Column type classification -----------------------------------------------
# Used by plots to visually distinguish column roles in the process pipeline.
COLUMN_TYPE_TELEMETRY = {"tag": "T", "label": "Telemetry", "color": "#4992FF"}
COLUMN_TYPE_SETPOINT = {"tag": "SP", "label": "Setpoint", "color": "#E64600"}
COLUMN_TYPE_RECOMMENDATION = {"tag": "REC", "label": "Recommendation", "color": "#7CFFB2"}
COLUMN_TYPE_TARGET = {"tag": "Q", "label": "Target / Quality", "color": "#FDDD60"}
COLUMN_TYPE_CALCULATED = {"tag": "C", "label": "Calculated", "color": "#9E7CFF"}

COLUMN_TYPES_ORDER = ["telemetry", "setpoint", "recommendation", "calculated", "target"]

# -- Font ---------------------------------------------------------------------
FONT_FAMILY = "Inter, -apple-system, BlinkMacSystemFont, sans-serif"
FONT_SIZE = 12
TITLE_SIZE = 14

# -- Layout defaults ----------------------------------------------------------
TRANSPARENT = "rgba(0,0,0,0)"

LAYOUT_DEFAULTS = dict(
    paper_bgcolor=TRANSPARENT,
    plot_bgcolor=TRANSPARENT,
    font=dict(
        family=FONT_FAMILY,
        size=FONT_SIZE,
        color=TEXT_MUTED,
    ),
    title=dict(
        font=dict(size=TITLE_SIZE, color=WHITE),
    ),
    legend=dict(
        bgcolor=TRANSPARENT,
        font=dict(color=TEXT_MUTED),
    ),
    xaxis=dict(
        gridcolor="rgba(255,255,255,0.08)",
        linecolor="rgba(255,255,255,0.2)",
        zerolinecolor="rgba(255,255,255,0.08)",
        tickfont=dict(color=TEXT_MUTED),
        title_font=dict(color=TEXT_MUTED),
    ),
    yaxis=dict(
        gridcolor="rgba(255,255,255,0.08)",
        linecolor="rgba(255,255,255,0.2)",
        zerolinecolor="rgba(255,255,255,0.08)",
        tickfont=dict(color=TEXT_MUTED),
        title_font=dict(color=TEXT_MUTED),
    ),
    colorway=SERIES_COLORS,
    margin=dict(l=50, r=20, t=40, b=40),
)


def apply_theme(fig):
    """
    Apply Wizata theme to an existing Plotly figure.
    Returns the figure for chaining.
    """
    fig.update_layout(**LAYOUT_DEFAULTS)
    return fig