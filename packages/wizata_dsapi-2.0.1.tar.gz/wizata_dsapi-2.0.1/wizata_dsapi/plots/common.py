import pandas
import wizata_dsapi
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import sklearn.metrics

from plotly.subplots import make_subplots

from .theme import (
    apply_theme, SERIES_COLORS, ANOMALY_COLOR, MAIN_COLOR, POSITIVE_COLOR,
    TEXT_MUTED, WHITE,
    TABLE_HEADER_BG, TABLE_HEADER_TEXT, TABLE_CELL_BG, TABLE_CELL_TEXT,
    TABLE_LINE_COLOR, FONT_FAMILY, FONT_SIZE,
    COLUMN_TYPE_TELEMETRY, COLUMN_TYPE_SETPOINT, COLUMN_TYPE_RECOMMENDATION,
    COLUMN_TYPE_TARGET, COLUMN_TYPE_CALCULATED, COLUMN_TYPES_ORDER,
)


def _classify_columns(df, context):
    """Classify each dataframe column by its role in the pipeline.

    Returns a dict of {col_name: {"type": str, "tag": str, "label": str, "color": str}}.
    Type ordering: telemetry < setpoint < recommendation < calculated < target.
    """
    datapoints = context.datapoints or {}
    target = context.properties.get("target_feat") if context.properties else None

    # Also check models for target_feat if not in properties
    if target is None and hasattr(context, "models") and context.models:
        for model in context.models.values():
            if hasattr(model, "has_target_feat") and model.has_target_feat:
                target_candidates = getattr(model, "target_feat", None)
                if target_candidates:
                    target = target_candidates if isinstance(target_candidates, str) else target_candidates[0]
                    break

    classification = {}
    for col in df.select_dtypes(include="number").columns:
        if col == target:
            classification[col] = {**COLUMN_TYPE_TARGET, "type": "target"}
        elif isinstance(col, str) and col.endswith("_recommended"):
            classification[col] = {**COLUMN_TYPE_RECOMMENDATION, "type": "recommendation"}
        elif col in datapoints:
            dp = datapoints[col]
            if dp.business_type == wizata_dsapi.BusinessType.SET_POINTS:
                classification[col] = {**COLUMN_TYPE_SETPOINT, "type": "setpoint"}
            else:
                classification[col] = {**COLUMN_TYPE_TELEMETRY, "type": "telemetry"}
        else:
            classification[col] = {**COLUMN_TYPE_CALCULATED, "type": "calculated"}

    return classification


def _sort_columns_by_type(columns, classification):
    """Sort columns following COLUMN_TYPES_ORDER: telemetry, setpoint, recommendation, calculated, target."""
    order_map = {t: i for i, t in enumerate(COLUMN_TYPES_ORDER)}
    return sorted(columns, key=lambda c: order_map.get(classification.get(c, {}).get("type", "calculated"), 3))


def check_single_column_and_target_feat(context: wizata_dsapi.Context):
    """
    check_single_column_and_target_feat
    :param context:
    :return:
    """
    input_io = context.step.get_unique_input()
    if input_io.dataframe not in context.dataframes or input_io.dataframe + '.reference' not in context.dataframes:
        raise ValueError(f'impossible to find {input_io.dataframe} dataframe and reference inside the context ')

    predict_df = context.dataframes[input_io.dataframe]
    ref_df = context.dataframes[input_io.dataframe + ".reference"]
    if ref_df.ndim != 1:
        raise ValueError('please use a model that predict only one serie/dimension.')

    if "output_columns_names" not in context.properties:
        raise RuntimeError('there is no output columns in properties, r squared cannot find results')

    column_name = context.properties["output_columns_names"]
    if not isinstance(column_name, str):
        if isinstance(column_name, list) and len(column_name) == 1:
            column_name = column_name[0]
        elif isinstance(column_name, list):
            raise ValueError('please use a model that predict only one serie/dimension - mulitple column names')
        else:
            raise TypeError(f'column_name is not a str or a list {column_name.__class__.__name__}')

    if not isinstance(predict_df, pandas.DataFrame):
        raise TypeError(f'predicted dataframe is not a dataframe {predict_df.__class__.__name__}')
    predict_df = predict_df.copy()
    predict_df = predict_df[[column_name]]

    if isinstance(ref_df, pandas.Series):
        ref_df = pandas.DataFrame(ref_df, index=predict_df.index)
    return predict_df, ref_df


def confusion_matrix(context: wizata_dsapi.Context):
    """Plot a confusion matrix heatmap comparing predicted vs actual binary classes."""
    predict_df, ref_df = check_single_column_and_target_feat(context)
    cm = sklearn.metrics.confusion_matrix(ref_df, predict_df)
    inverted_cm = np.flip(cm, axis=1)

    fig = go.Figure(data=go.Heatmap(
        z=inverted_cm,
        x=['Positive', 'Negative'],
        y=['Negative', 'Positive'],
        colorscale=[[0, '#062B56'], [1, '#E64600']],
        colorbar=dict(title='Count', tickfont=dict(color=TEXT_MUTED)),
    ))

    for i in range(len(inverted_cm)):
        for j in range(len(inverted_cm[i])):
            fig.add_annotation(
                x=j,
                y=i,
                text=str(inverted_cm[i][j]),
                showarrow=False,
                font=dict(color=WHITE if inverted_cm[i][j] > np.max(inverted_cm) / 2 else TEXT_MUTED)
            )

    fig.update_layout(
        xaxis=dict(title='Predicted'),
        yaxis=dict(title='Actual')
    )

    apply_theme(fig)

    context.set_plot(
        figure=fig,
        name="confusion_matrix"
    )


def r_squared(context: wizata_dsapi.Context):
    """Plot actual vs predicted scatter with R-squared coefficient and reference diagonal."""
    predict_df, ref_df = check_single_column_and_target_feat(context)

    r2 = sklearn.metrics.r2_score(ref_df, predict_df)

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=ref_df.values.flatten(),
        y=predict_df.values.flatten(),
        mode='markers',
        name='Data Points',
        marker=dict(color=SERIES_COLORS[0], size=5, opacity=0.7),
    ))

    min_value = min(ref_df.values.min(), predict_df.values.min())
    max_value = max(ref_df.values.max(), predict_df.values.max())
    fig.add_trace(go.Scatter(
        x=[min_value, max_value],
        y=[min_value, max_value],
        mode='lines',
        line=dict(color=TEXT_MUTED, dash='dash'),
        showlegend=False,
    ))

    fig.add_annotation(
        x=min_value,
        y=max_value,
        text=f'R\u00b2 = {r2:.4f}',
        showarrow=False,
        font=dict(color=WHITE, size=12),
        bgcolor='#184980',
        bordercolor='rgba(255,255,255,0.2)',
        borderwidth=1,
        borderpad=4,
        opacity=0.9,
    )

    fig.update_layout(
        xaxis=dict(title='Actual'),
        yaxis=dict(title='Predicted')
    )

    apply_theme(fig)

    context.set_plot(
        figure=fig,
        name="r_squared"
    )


def ts_chart(context: wizata_dsapi.Context):
    """Plot all dataframe columns as time-series lines over the index."""
    df = context.dataframe
    traces = []
    for i, column in enumerate(df.columns):
        trace = go.Scatter(
            x=df.index,
            y=df[column],
            mode='lines',
            name=column,
            line=dict(color=SERIES_COLORS[i % len(SERIES_COLORS)]),
        )
        traces.append(trace)

    fig = go.Figure(traces)
    apply_theme(fig)

    context.set_plot(
        figure=fig,
        name="ts_chart"
    )


def anomalies_chart(context: wizata_dsapi.Context):
    """Plot time-series signals with detected anomaly regions highlighted in red."""
    df = context.dataframe

    # Add Signals
    traces = []
    color_idx = 0
    for column in df.columns:
        if column != "anomalies_type":
            trace = go.Scatter(
                x=df.index,
                y=df[column],
                mode='lines',
                name=column,
                line=dict(color=SERIES_COLORS[color_idx % len(SERIES_COLORS)]),
            )
            traces.append(trace)
            color_idx += 1
    fig = go.Figure(traces)

    # Add Anomalies as Highlighted
    anomalies_list = context.dataframe.copy()
    anomalies_list['anomaly'] = np.where(anomalies_list['anomalies_type'] != 0, 1, 0)
    anomalies_list['new_occurrence'] = np.where(
        (anomalies_list['anomaly'] != anomalies_list['anomaly'].shift(1)) |
        (anomalies_list['anomalies_type'] != anomalies_list['anomalies_type'].shift(1)), 1, 0)
    anomalies_list['new_occurrence_index'] = anomalies_list['new_occurrence'].cumsum()
    anomalies_occurrences = anomalies_list[anomalies_list['anomaly'] != 0].reset_index(). \
        groupby(['new_occurrence_index']). \
        agg({'Timestamp': ['first', 'last'], 'anomalies_type': 'first'})
    anomalies_occurrences.columns = ['from', 'to', 'anomaly_group']
    for i in anomalies_occurrences.index:
        fig.add_vrect(x0=anomalies_occurrences['from'][i], x1=anomalies_occurrences['to'][i], line_width=0,
                      fillcolor=ANOMALY_COLOR, opacity=1)

    apply_theme(fig)

    context.set_plot(
        figure=fig,
        name="anomalies_chart"
    )


def parallel_coordinates(context: wizata_dsapi.Context):
    """Plot parallel coordinates colored by anomaly type for multi-dimensional analysis."""
    df = context.dataframe

    fig = px.parallel_coordinates(df,
                                  color='anomalies_type',
                                  dimensions=df,
                                  color_continuous_scale=px.colors.diverging.Portland)
    apply_theme(fig)

    context.set_plot(
        figure=fig,
        name="parallel_coordinates"
    )


def setpoint_recommendation(context: wizata_dsapi.Context):
    """Compare current vs recommended setpoint values as a grouped bar chart with a summary table.

    Auto-pairs columns ending in '_recommended' with the matching setpoint column, validated via
    context.datapoints BusinessType.SET_POINTS. Uses the last row (most recent state). The top half
    shows a horizontal grouped bar chart (Current vs Recommended) with type-colored labels; the
    bottom half is a summary table with Setpoint | Current | Recommended | delta | delta (%).
    """
    df = context.dataframe
    datapoints = context.datapoints or {}

    if df is None or len(df) == 0:
        raise ValueError("setpoint_recommendation: dataframe is empty")

    suffix = "_recommended"
    pairs = []
    for col in df.columns:
        if not isinstance(col, str) or not col.endswith(suffix):
            continue
        base = col[: -len(suffix)]
        if base not in df.columns:
            continue
        if datapoints:
            dp = datapoints.get(base)
            if dp is None or dp.business_type != wizata_dsapi.BusinessType.SET_POINTS:
                continue
        pairs.append((base, col))

    if not pairs:
        raise ValueError(
            "setpoint_recommendation: no <col>_recommended / setpoint pairs found in the dataframe"
        )

    last = df.iloc[-1]
    names, currents, recommendeds, deltas, pcts = [], [], [], [], []
    for base, rec in pairs:
        current = float(last[base])
        recommended = float(last[rec])
        delta = recommended - current
        pct = (delta / current * 100.0) if current not in (0, 0.0) and not pd.isna(current) else float("nan")
        names.append(base)
        currents.append(current)
        recommendeds.append(recommended)
        deltas.append(delta)
        pcts.append(pct)

    # ── Build combined figure: bar chart (top) + table (bottom) ──────────
    fig = make_subplots(
        rows=2, cols=1,
        specs=[[{"type": "xy"}], [{"type": "domain"}]],
        row_heights=[0.55, 0.45],
        vertical_spacing=0.08,
    )

    # Grouped horizontal bars
    fig.add_trace(go.Bar(
        y=names,
        x=recommendeds,
        orientation="h",
        name="Recommended Value",
        marker_color=POSITIVE_COLOR,
        text=[f"{v:.2f}" for v in recommendeds],
        textposition="inside",
        insidetextanchor="start",
        textfont=dict(color=WHITE, size=FONT_SIZE),
    ), row=1, col=1)

    fig.add_trace(go.Bar(
        y=names,
        x=currents,
        orientation="h",
        name="Current Value",
        marker_color=MAIN_COLOR,
        text=[f"{v:.2f}" for v in currents],
        textposition="inside",
        insidetextanchor="start",
        textfont=dict(color=WHITE, size=FONT_SIZE),
    ), row=1, col=1)

    fig.update_layout(barmode="group")
    fig.update_xaxes(title_text="Values", row=1, col=1)
    fig.update_yaxes(title_text="Setpoints", row=1, col=1)

    # Summary table
    fmt = lambda v: "—" if pd.isna(v) else f"{v:.3f}"
    n_rows = len(names)
    cell_bg = [TABLE_CELL_BG[i % 2] for i in range(n_rows)]

    fig.add_trace(go.Table(
        header=dict(
            values=["<b>Setpoint</b>", "<b>Current</b>", "<b>Recommended</b>",
                    "<b>\u0394</b>", "<b>\u0394 (%)</b>"],
            fill_color=TABLE_HEADER_BG,
            font=dict(family=FONT_FAMILY, size=FONT_SIZE, color=TABLE_HEADER_TEXT),
            align="left",
            line_color=TABLE_LINE_COLOR,
            height=32,
        ),
        cells=dict(
            values=[
                names,
                [fmt(v) for v in currents],
                [fmt(v) for v in recommendeds],
                [fmt(v) for v in deltas],
                [fmt(v) for v in pcts],
            ],
            fill_color=[cell_bg],
            font=dict(family=FONT_FAMILY, size=FONT_SIZE, color=TABLE_CELL_TEXT),
            align="left",
            line_color=TABLE_LINE_COLOR,
            height=28,
        ),
    ), row=2, col=1)

    fig.update_layout(
        title="Actual vs Recommended Values",
        legend=dict(orientation="h", y=1.02, x=0.5, xanchor="center"),
    )
    apply_theme(fig)

    context.set_plot(figure=fig, name="setpoint_recommendation")


def feature_importance(context: wizata_dsapi.Context):
    """Plot the top-N feature importances of a trained model as a horizontal bar chart.

    Scans context.models for a model whose underlying trained_model exposes `feature_importances_`
    (RandomForestRegressor, RandomForestClassifier, GradientBoostingClassifier, etc.). Uses
    `ml_model.input_columns` for feature labels. Bars are sorted ascending so the most important
    feature is at the top when rendered.

    Property: top_n (default 15) — maximum number of features to display.
    """
    top_n = int(context.properties.get("top_n", 15)) if "top_n" in context.properties else 15

    selected = None
    for model in (context.models or {}).values():
        trained = getattr(model, "trained_model", None)
        if trained is not None and hasattr(trained, "feature_importances_"):
            selected = model
            break

    if selected is None:
        raise ValueError(
            "feature_importance: no trained model with feature_importances_ found in context.models "
            "(supported by RandomForest, GradientBoosting, and similar tree-based models)"
        )

    importances = np.asarray(selected.trained_model.feature_importances_)
    feature_names = list(selected.input_columns) if selected.input_columns is not None else \
        [f"f{i}" for i in range(len(importances))]

    if len(feature_names) != len(importances):
        raise ValueError(
            f"feature_importance: feature_importances_ length {len(importances)} does not match "
            f"input_columns length {len(feature_names)}"
        )

    fi = pd.DataFrame({"feature": feature_names, "importance": importances})
    fi = fi.sort_values("importance", ascending=True).tail(top_n)

    fig = go.Figure(go.Bar(
        x=fi["importance"],
        y=fi["feature"],
        orientation="h",
        marker_color=SERIES_COLORS[0],
    ))
    fig.update_layout(
        title=f"Top-{min(top_n, len(fi))} Feature Importances",
        xaxis=dict(title="Importance"),
        yaxis=dict(title=""),
        margin=dict(l=200, r=20, t=40, b=40),
    )
    apply_theme(fig)

    context.set_plot(figure=fig, name="feature_importance")


def process_variability(context: wizata_dsapi.Context):
    """Parallel coordinates plot showing process configurations variability, colored by a quality
    outcome. Columns are ordered by type: telemetry, setpoints, recommendations, calculated,
    with the target/quality column last. Each axis label is prefixed with a type tag
    ([T], [SP], [REC], [C], [Q]) for quick identification.

    Column selection:
      - color_by: property name of the quality column used for coloring (defaults to
        context.properties['target_feat'] if set, otherwise the last numeric column).
      - color_reverse: set to true (default) when a LOWER color_by value is better
        (e.g. residual_co2) — low values will be green. Set to false when higher is better
        (e.g. 'good_bottles') — high values will be green.
    """
    df = context.dataframe
    if df is None or len(df) == 0:
        raise ValueError("process_variability: dataframe is empty")

    numeric_cols = df.select_dtypes(include="number").columns.tolist()
    if len(numeric_cols) < 2:
        raise ValueError("process_variability: need at least 2 numeric columns")

    # Classify and order columns by type
    classification = _classify_columns(df, context)
    ordered_cols = _sort_columns_by_type(
        [c for c in numeric_cols if c in classification],
        classification
    )

    # Resolve color column
    color_by = context.properties.get("color_by")
    if color_by is None:
        color_by = context.properties.get("target_feat")
    if color_by is None:
        color_by = ordered_cols[-1] if ordered_cols else numeric_cols[-1]
    if color_by not in df.columns:
        raise ValueError(f"process_variability: color_by column '{color_by}' not found in dataframe")

    color_reverse = context.properties.get("color_reverse", True)
    if isinstance(color_reverse, str):
        color_reverse = color_reverse.lower() not in ("false", "0", "no")

    # Build dimensions with type-tagged labels, in order
    dimensions = []
    for col in ordered_cols:
        col_vals = df[col].dropna()
        if col_vals.empty:
            continue
        info = classification[col]
        tagged_label = f"[{info['tag']}] {col}"
        dimensions.append(dict(
            label=tagged_label,
            values=df[col].values,
            range=[float(col_vals.min()), float(col_vals.max())],
        ))

    # Colorscale: red → yellow → green (reversed if lower is better)
    if color_reverse:
        colorscale = [[0, POSITIVE_COLOR], [0.5, "#FDDD60"], [1, "#FF6E76"]]
    else:
        colorscale = [[0, "#FF6E76"], [0.5, "#FDDD60"], [1, POSITIVE_COLOR]]

    fig = go.Figure(data=go.Parcoords(
        line=dict(
            color=df[color_by].values,
            colorscale=colorscale,
            showscale=True,
            colorbar=dict(title=color_by),
        ),
        dimensions=dimensions,
    ))

    # Add a legend-like annotation for the type tags
    type_legend = "  ".join(
        f"[{t['tag']}] {t['label']}"
        for t in [COLUMN_TYPE_TELEMETRY, COLUMN_TYPE_SETPOINT, COLUMN_TYPE_RECOMMENDATION,
                  COLUMN_TYPE_CALCULATED, COLUMN_TYPE_TARGET]
    )
    fig.update_layout(
        title=dict(text="Configurations Variability"),
        annotations=[dict(
            text=type_legend,
            xref="paper", yref="paper", x=0, y=-0.08,
            showarrow=False,
            font=dict(size=10, color=TEXT_MUTED),
        )],
    )
    apply_theme(fig)

    context.set_plot(figure=fig, name="process_variability")


def data_table(context: wizata_dsapi.Context):
    """Render the dataframe as a styled table with Wizata theme colors."""
    df = context.dataframe.copy()

    # Format the index as a column if it has a name or is a DatetimeIndex
    if isinstance(df.index, pd.DatetimeIndex):
        df.insert(0, df.index.name or "Timestamp", df.index.strftime("%Y-%m-%d %H:%M:%S"))
        df = df.reset_index(drop=True)
    elif df.index.name is not None:
        df = df.reset_index()

    # Round numeric columns
    precision = int(context.properties.get("precision", 4)) if "precision" in context.properties else 4
    for col in df.select_dtypes(include="number").columns:
        df[col] = df[col].round(precision)

    # Build alternating row colors
    n_rows = len(df)
    cell_bg = [TABLE_CELL_BG[i % 2] for i in range(n_rows)]

    fig = go.Figure(data=[go.Table(
        header=dict(
            values=[f"<b>{c}</b>" for c in df.columns],
            fill_color=TABLE_HEADER_BG,
            font=dict(family=FONT_FAMILY, size=FONT_SIZE, color=TABLE_HEADER_TEXT),
            align="left",
            line_color=TABLE_LINE_COLOR,
            height=32,
        ),
        cells=dict(
            values=[df[c].tolist() for c in df.columns],
            fill_color=[cell_bg],
            font=dict(family=FONT_FAMILY, size=FONT_SIZE, color=TABLE_CELL_TEXT),
            align="left",
            line_color=TABLE_LINE_COLOR,
            height=28,
        ),
    )])

    fig.update_layout(
        margin=dict(l=0, r=0, t=0, b=0),
    )
    apply_theme(fig)

    context.set_plot(
        figure=fig,
        name="data_table"
    )