from enum import Enum
from .api_dto import Dto


class EdgeModuleType(Enum):
    """
    Classification of an edge module.

    WIZATA: modules developed and maintained by Wizata (configsync, message_client, pipeline_runner).
    SYSTEM: IoT Edge runtime and third-party infrastructure (edgeAgent, edgeHub, influxdb, rabbitmq, loki, ...).
    """
    WIZATA = "wizata"
    SYSTEM = "system"


# Hardcoded registry of known Wizata modules.
# Maps module_id to a human-readable description.
WIZATA_MODULES = {
    "configsync": "Configuration synchronization between cloud and edge",
    "message_client": "Message client for edge-to-cloud telemetry",
    "pipeline_runner": "Pipeline execution engine on edge",
}


def _extract_image_version(image: str) -> str:
    """Extract the tag portion after ':' from a container image reference."""
    if image and ":" in image:
        return image.rsplit(":", 1)[1]
    return None


class EdgeModule(Dto):
    """
    Represents a module deployed on an IoT Edge device.

    :ivar str module_id: module identifier (e.g. 'configsync', '$edgeAgent').
    :ivar str runtime_status: runtime status from $edgeAgent reported twin (e.g. 'running', 'stopped').
    :ivar int exit_code: last exit code of the module container.
    :ivar str last_start_time: last container start time (UTC).
    :ivar str last_exit_time: last container exit time (UTC).
    :ivar str image: container image reference.
    :ivar str image_version: tag extracted from image (e.g. 'p12-20260313.3'), only set for wizata modules.
    :ivar str last_updated: when this module's status was last reported to IoT Hub (from $edgeAgent twin $metadata).
    :ivar EdgeModuleType module_type: wizata or system classification.
    """

    def __init__(self,
                 module_id: str = None,
                 runtime_status: str = None,
                 exit_code: int = None,
                 last_start_time: str = None,
                 last_exit_time: str = None,
                 image: str = None,
                 image_version: str = None,
                 last_updated: str = None,
                 module_type: EdgeModuleType = None):
        self.module_id = module_id
        self.runtime_status = runtime_status
        self.exit_code = exit_code
        self.last_start_time = last_start_time
        self.last_exit_time = last_exit_time
        self.image = image
        self.last_updated = last_updated
        if module_type is not None:
            self.module_type = module_type
        elif module_id is not None:
            self.module_type = EdgeModuleType.WIZATA if module_id in WIZATA_MODULES else EdgeModuleType.SYSTEM
        else:
            self.module_type = None
        # image_version: explicit value wins, otherwise extract for wizata modules only
        if image_version is not None:
            self.image_version = image_version
        elif self.module_type == EdgeModuleType.WIZATA and image:
            self.image_version = _extract_image_version(image)
        else:
            self.image_version = None

    @classmethod
    def from_dict(cls, data: dict) -> "EdgeModule":
        module_type = None
        if "moduleType" in data and data["moduleType"] is not None:
            module_type = EdgeModuleType(data["moduleType"])
        return cls(
            module_id=data.get("moduleId"),
            runtime_status=data.get("runtimeStatus"),
            exit_code=data.get("exitCode"),
            last_start_time=data.get("lastStartTime"),
            last_exit_time=data.get("lastExitTime"),
            image=data.get("image"),
            image_version=data.get("imageVersion"),
            last_updated=data.get("lastUpdated"),
            module_type=module_type,
        )

    def to_dict(self) -> dict:
        obj = {}
        if self.module_id is not None:
            obj["moduleId"] = self.module_id
        if self.runtime_status is not None:
            obj["runtimeStatus"] = self.runtime_status
        if self.exit_code is not None:
            obj["exitCode"] = self.exit_code
        if self.last_start_time is not None:
            obj["lastStartTime"] = self.last_start_time
        if self.last_exit_time is not None:
            obj["lastExitTime"] = self.last_exit_time
        if self.image is not None:
            obj["image"] = self.image
        if self.image_version is not None:
            obj["imageVersion"] = self.image_version
        if self.last_updated is not None:
            obj["lastUpdated"] = self.last_updated
        if self.module_type is not None:
            obj["moduleType"] = self.module_type.value
        return obj
