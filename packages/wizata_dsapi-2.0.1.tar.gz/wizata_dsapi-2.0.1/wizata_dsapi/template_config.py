"""
TemplateConfig DTO for template configuration persistence.

Stores structured metadata linking template properties together
for models, recommendations/automation, and KPIs.

One row per template. PK is templateKey (string, matches Template.key).
"""

from datetime import datetime, timezone
from typing import Optional


class TemplateConfig:
    """
    TemplateConfig entity stored in PostgreSQL ``"TemplateConfig"`` table.

    PK is ``template_key`` (string, matches Template.key).

    - ``models``: list of model definitions (modelKey + activationProperty).
    - ``recommendations``: list of recommendation groups linking related properties.
    - ``kpis``: list of KPI definitions with operator-based evaluation.
    """

    def __init__(self):
        self.template_key: Optional[str] = None
        self.models: list = []
        self.recommendations: list = []
        self.kpis: list = []
        self.created_at: Optional[datetime] = None
        self.updated_at: Optional[datetime] = None

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        obj = {}
        if self.template_key is not None:
            obj["templateKey"] = self.template_key
        obj["models"] = list(self.models)
        obj["recommendations"] = list(self.recommendations)
        obj["kpis"] = list(self.kpis)
        if self.created_at is not None:
            obj["createdAt"] = int(self.created_at.timestamp() * 1000)
        if self.updated_at is not None:
            obj["updatedAt"] = int(self.updated_at.timestamp() * 1000)
        return obj

    @classmethod
    def from_dict(cls, data: dict) -> "TemplateConfig":
        obj = cls()
        obj.template_key = data.get("templateKey") or data.get("template_key")
        obj.models = data.get("models") or []
        obj.recommendations = data.get("recommendations") or []
        obj.kpis = data.get("kpis") or []

        created_raw = data.get("createdAt") or data.get("created_at")
        if created_raw is not None:
            obj.created_at = datetime.fromtimestamp(created_raw / 1000, tz=timezone.utc)

        updated_raw = data.get("updatedAt") or data.get("updated_at")
        if updated_raw is not None:
            obj.updated_at = datetime.fromtimestamp(updated_raw / 1000, tz=timezone.utc)
        return obj

    # ------------------------------------------------------------------
    # API identity helpers
    # ------------------------------------------------------------------

    def api_id(self) -> str:
        return self.template_key

    def api_key(self) -> str:
        return self.template_key

    def set_id(self, value):
        self.template_key = str(value)

    def __repr__(self) -> str:
        return (
            f"TemplateConfig(template_key={self.template_key!r}, "
            f"models={len(self.models)}, "
            f"recommendations={len(self.recommendations)}, "
            f"kpis={len(self.kpis)})"
        )
