"""
Mobile asset DTOs for tile and config persistence.

MobileAssetTileType — tile visualization type:
  - SENSOR: single datapoint live value
  - CHART: time-series chart
  - TABLE: tabular data view
  - POLAR: polar/radar chart
  - EVENT: event timeline

MobileAssetTile — individual tile configuration scoped to a template
  or a specific twin.

MobileAssetConfig — per-asset or per-template display preferences
  (hero metrics, anomaly ref, pinned twins).
"""

import json
from datetime import datetime, timezone
from enum import Enum
from typing import Optional


class MobileAssetTileType(str, Enum):
    SENSOR = "sensor"
    CHART = "chart"
    TABLE = "table"
    POLAR = "polar"
    EVENT = "event"


class MobileAssetTile:
    """
    Tile entity stored in PostgreSQL ``"MobileAssetTile"`` table.

    PK is ``id`` (UUID, server-generated).

    - ``template_id``: template scope (empty GUID for non-templated assets).
    - ``twin_id``: NULL = template-scoped, set = twin-scoped override.
    - ``type``: tile visualization type (sensor, chart, table, polar, event).
    - ``label``: display label.
    - ``sort_order``: sort position (0-based).
    - ``config``: free-form JSON with type-specific settings.
    """

    def __init__(self):
        self.id: Optional[str] = None
        self.template_id: Optional[str] = None
        self.twin_id: Optional[str] = None
        self.type: Optional[MobileAssetTileType] = None
        self.label: Optional[str] = None
        self.sort_order: int = 0
        self.config: Optional[dict] = None
        self.created_by: Optional[str] = None
        self.updated_at: Optional[datetime] = None

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        obj = {}
        if self.id is not None:
            obj["id"] = str(self.id)
        if self.template_id is not None:
            obj["templateId"] = str(self.template_id)
        if self.twin_id is not None:
            obj["twinId"] = str(self.twin_id)
        if self.type is not None:
            obj["type"] = (
                self.type.value
                if isinstance(self.type, MobileAssetTileType)
                else self.type
            )
        if self.label is not None:
            obj["label"] = self.label
        obj["sortOrder"] = self.sort_order
        if self.config is not None:
            obj["config"] = self.config
        if self.created_by is not None:
            obj["createdBy"] = self.created_by
        if self.updated_at is not None:
            obj["updatedAt"] = int(self.updated_at.timestamp() * 1000)
        return obj

    @classmethod
    def from_dict(cls, data: dict) -> "MobileAssetTile":
        obj = cls()
        obj.id = data.get("id")
        obj.template_id = data.get("templateId") or data.get("template_id")
        obj.twin_id = data.get("twinId") or data.get("twin_id")

        raw_type = data.get("type")
        if raw_type is not None:
            obj.type = MobileAssetTileType(raw_type.lower())

        obj.label = data.get("label")
        obj.sort_order = data.get("sortOrder", data.get("sort_order", 0))

        raw_config = data.get("config")
        if isinstance(raw_config, dict):
            obj.config = raw_config
        elif isinstance(raw_config, str) and raw_config:
            try:
                parsed = json.loads(raw_config)
                obj.config = parsed if isinstance(parsed, dict) else None
            except (json.JSONDecodeError, ValueError):
                obj.config = None

        obj.created_by = data.get("createdBy") or data.get("created_by")

        updated_raw = data.get("updatedAt") or data.get("updated_at")
        if updated_raw is not None:
            if isinstance(updated_raw, (int, float)):
                obj.updated_at = datetime.fromtimestamp(updated_raw / 1000, tz=timezone.utc)
            elif isinstance(updated_raw, datetime):
                obj.updated_at = updated_raw
        return obj

    # ------------------------------------------------------------------
    # API identity helpers
    # ------------------------------------------------------------------

    def api_id(self) -> str:
        return str(self.id) if self.id else None

    def api_key(self) -> str:
        return str(self.id) if self.id else None

    def set_id(self, value):
        self.id = str(value)

    def __repr__(self) -> str:
        return (
            f"MobileAssetTile(id={self.id!r}, label={self.label!r}, "
            f"type={self.type!r}, template_id={self.template_id!r}, "
            f"twin_id={self.twin_id!r})"
        )


class MobileAssetConfig:
    """
    Asset config entity stored in PostgreSQL ``"MobileAssetConfig"`` table.

    PK is ``id`` (UUID, server-generated).

    - ``template_id``: template scope.
    - ``twin_id``: NULL = template default, set = twin override.
    - ``config``: free-form JSON (heroMetricRefs, anomalyDatapointRef, pinnedTwinIds, etc.).
    """

    def __init__(self):
        self.id: Optional[str] = None
        self.template_id: Optional[str] = None
        self.twin_id: Optional[str] = None
        self.config: Optional[dict] = None
        self.updated_at: Optional[datetime] = None

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        obj = {}
        if self.id is not None:
            obj["id"] = str(self.id)
        if self.template_id is not None:
            obj["templateId"] = str(self.template_id)
        if self.twin_id is not None:
            obj["twinId"] = str(self.twin_id)
        if self.config is not None:
            obj["config"] = self.config
        if self.updated_at is not None:
            obj["updatedAt"] = int(self.updated_at.timestamp() * 1000)
        return obj

    @classmethod
    def from_dict(cls, data: dict) -> "MobileAssetConfig":
        obj = cls()
        obj.id = data.get("id")
        obj.template_id = data.get("templateId") or data.get("template_id")
        obj.twin_id = data.get("twinId") or data.get("twin_id")

        raw_config = data.get("config")
        if isinstance(raw_config, dict):
            obj.config = raw_config
        elif isinstance(raw_config, str) and raw_config:
            try:
                parsed = json.loads(raw_config)
                obj.config = parsed if isinstance(parsed, dict) else None
            except (json.JSONDecodeError, ValueError):
                obj.config = None

        updated_raw = data.get("updatedAt") or data.get("updated_at")
        if updated_raw is not None:
            if isinstance(updated_raw, (int, float)):
                obj.updated_at = datetime.fromtimestamp(updated_raw / 1000, tz=timezone.utc)
            elif isinstance(updated_raw, datetime):
                obj.updated_at = updated_raw
        return obj

    # ------------------------------------------------------------------
    # API identity helpers
    # ------------------------------------------------------------------

    def api_id(self) -> str:
        return str(self.id) if self.id else None

    def api_key(self) -> str:
        return str(self.id) if self.id else None

    def set_id(self, value):
        self.id = str(value)

    def __repr__(self) -> str:
        return (
            f"MobileAssetConfig(id={self.id!r}, "
            f"template_id={self.template_id!r}, "
            f"twin_id={self.twin_id!r})"
        )
