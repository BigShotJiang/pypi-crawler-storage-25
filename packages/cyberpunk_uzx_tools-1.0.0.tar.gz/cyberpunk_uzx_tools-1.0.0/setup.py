from setuptools import setup, find_packages

setup(
    name="cyberpunk-uzx-tools",
    version="1.0.0",
    author="cyberpunkuzx",
    description="Cyberpunk python toolkit",
    packages=find_packages(),
    install_requires=[],
)
