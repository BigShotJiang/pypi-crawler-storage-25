"""Bundled XML templates for Hermes Reports."""
