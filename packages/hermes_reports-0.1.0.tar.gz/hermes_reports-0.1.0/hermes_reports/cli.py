from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from .engine import ReportEngine


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m hermes_reports",
        description="Renderiza relatórios Hermes Reports a partir de templates XML em HTML, PDF, CSV e XLSX.",
    )
    parser.add_argument("template", help="Caminho do template XML.")
    parser.add_argument("data", help="Arquivo JSON com os dados do relatório.")
    parser.add_argument(
        "--params",
        default=None,
        help="Arquivo JSON opcional com parâmetros separados dos dados do relatório.",
    )
    parser.add_argument(
        "-o",
        "--output",
        default="relatorio.html",
        help="Arquivo de saída. Padrão: relatorio.html",
    )
    parser.add_argument(
        "-f",
        "--format",
        default=None,
        choices=["html", "pdf", "csv", "xlsx", "xmlx"],
        help="Formato de saída. Se omitido, usa a extensão do arquivo de saída.",
    )
    return parser


def load_json(path: str | Path) -> dict[str, Any] | list[dict[str, Any]]:
    with Path(path).open("r", encoding="utf-8") as file_handle:
        return json.load(file_handle)


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    engine = ReportEngine(args.template)
    data = load_json(args.data)
    parameters = load_json(args.params) if args.params else None
    if parameters is not None and not isinstance(parameters, dict):
        raise SystemExit("O arquivo informado em --params deve conter um objeto JSON.")
    output_path = engine.render_to_file(data, args.output, output=args.format, parameters=parameters)
    print(f"Relatório gerado em: {output_path}")
    return 0


__all__ = ["build_parser", "load_json", "main"]
