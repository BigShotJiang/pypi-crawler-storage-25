"""Official parser module for Hermes Reports."""

from report_engine.parser import TemplateValidationError, parse_template

__all__ = ["TemplateValidationError", "parse_template"]
