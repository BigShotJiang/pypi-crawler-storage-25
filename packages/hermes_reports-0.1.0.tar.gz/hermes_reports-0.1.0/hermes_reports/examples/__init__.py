"""Examples for Hermes Reports."""
