from __future__ import annotations

import argparse
import json
from pathlib import Path

from hermes_reports import ReportEngine

EXAMPLE_NUMBERS = ("01", "02", "03", "04", "05", "06", "07")


def _load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as file_handle:
        return json.load(file_handle)


def _example_paths(base_dir: Path, number: str) -> tuple[Path, Path]:
    xml_files = sorted(base_dir.glob(f"{number}_*.xml"))
    json_files = sorted(base_dir.glob(f"{number}_*.json"))
    if not xml_files or not json_files:
        raise FileNotFoundError(f"Exemplo {number} incompleto em {base_dir}")
    data_candidates = [path for path in json_files if "params" not in path.stem]
    if not data_candidates:
        raise FileNotFoundError(f"Exemplo {number} não possui template principal ou JSON principal.")
    data_path = data_candidates[0]
    matching_templates = [path for path in xml_files if path.stem == data_path.stem]
    if matching_templates:
        return matching_templates[0], data_path
    return xml_files[0], data_path


def render_example(number: str, output_format: str, base_dir: Path, output_dir: Path) -> Path:
    template_path, data_path = _example_paths(base_dir, number)
    params_path = base_dir / f"{number}_params.json"
    engine = ReportEngine(template_path)
    data = _load_json(data_path)
    parameters = _load_json(params_path) if params_path.exists() else None
    output_name = f"{template_path.stem}.{output_format}"
    destination = output_dir / output_name
    engine.render_to_file(data, destination, output=output_format, parameters=parameters)
    return destination


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m hermes_reports.examples.run_examples",
        description="Renderiza os exemplos numerados do Hermes Reports.",
    )
    parser.add_argument(
        "--example",
        choices=[*EXAMPLE_NUMBERS, "all"],
        default="all",
        help="Número do exemplo a renderizar. Padrão: all.",
    )
    parser.add_argument(
        "--format",
        choices=["html", "pdf", "csv", "xlsx", "all"],
        default="all",
        help="Formato de saída. Padrão: all.",
    )
    parser.add_argument(
        "--output-dir",
        default=None,
        help="Diretório de saída. Padrão: examples/outputs.",
    )
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    base_dir = Path(__file__).resolve().parent
    output_dir = Path(args.output_dir).resolve() if args.output_dir else base_dir / "outputs"
    output_dir.mkdir(parents=True, exist_ok=True)

    numbers = EXAMPLE_NUMBERS if args.example == "all" else (args.example,)
    formats = ("html", "pdf", "csv", "xlsx") if args.format == "all" else (args.format,)

    for number in numbers:
        for output_format in formats:
            destination = render_example(number, output_format, base_dir, output_dir)
            print(f"{number} -> {destination}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
