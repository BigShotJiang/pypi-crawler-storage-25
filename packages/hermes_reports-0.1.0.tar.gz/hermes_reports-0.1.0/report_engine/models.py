from __future__ import annotations

from dataclasses import dataclass, field as dataclass_field


@dataclass(slots=True)
class FontStyle:
    family: str | None = None
    size_pt: float | None = None
    transform: str | None = None
    color: str | None = None


@dataclass(slots=True)
class StyleDefinition:
    align: str | None = None
    header_align: str | None = None
    width_mode: str | None = None
    width_mm: float | None = None
    background_color: str | None = None
    border_color: str | None = None
    header_background_color: str | None = None
    header_border_color: str | None = None
    font: FontStyle = dataclass_field(default_factory=FontStyle)
    header_font: FontStyle = dataclass_field(default_factory=FontStyle)


@dataclass(slots=True)
class ParameterDefinition:
    name: str
    field: str | None = None
    expression: str | None = None
    value: str | None = None


@dataclass(slots=True)
class VariableDefinition:
    name: str
    expression: str


@dataclass(slots=True)
class PageMargins:
    top_mm: float = 20.0
    right_mm: float = 20.0
    bottom_mm: float = 20.0
    left_mm: float = 20.0


@dataclass(slots=True)
class TextElement:
    kind: str
    field: str | None = None
    expression: str | None = None
    value: str | None = None
    formatter: str | None = None
    visible_if: str | None = None
    label: str | None = None
    align: str | None = None
    page_break_before: bool = False
    keep_together: bool = False
    background_color: str | None = None
    border_color: str | None = None
    font: FontStyle = dataclass_field(default_factory=FontStyle)


@dataclass(slots=True)
class ImageElement:
    src: str | None = None
    field: str | None = None
    expression: str | None = None
    alt: str | None = None
    width_mm: float | None = None
    height_mm: float | None = None
    visible_if: str | None = None
    page_break_before: bool = False
    keep_together: bool = False
    background_color: str | None = None
    border_color: str | None = None


@dataclass(slots=True)
class CodeElement:
    kind: str
    field: str | None = None
    expression: str | None = None
    value: str | None = None
    symbology: str | None = None
    width_mm: float | None = None
    height_mm: float | None = None
    visible_if: str | None = None
    page_break_before: bool = False
    keep_together: bool = False
    color: str | None = None
    background_color: str | None = None
    border_color: str | None = None


@dataclass(slots=True)
class Column:
    label: str
    field: str | None = None
    expression: str | None = None
    formatter: str | None = None
    visible_if: str | None = None
    align: str = "left"
    header_align: str | None = None
    width_mode: str = "auto"
    width_mm: float | None = None
    background_color: str | None = None
    border_color: str | None = None
    header_background_color: str | None = None
    header_border_color: str | None = None
    font: FontStyle = dataclass_field(default_factory=FontStyle)
    header_font: FontStyle = dataclass_field(default_factory=FontStyle)


@dataclass(slots=True)
class Table:
    columns: list[Column]
    data_source: str | None = None
    title: str | None = None
    group_by: str | None = None
    visible_if: str | None = None
    page_break_before: bool = False
    keep_together: bool = False
    background_color: str | None = None
    border_color: str | None = None
    title_align: str = "left"
    title_font: FontStyle = dataclass_field(default_factory=FontStyle)


@dataclass(slots=True)
class DetailBand:
    data_source: str
    elements: list[TextElement | ImageElement | CodeElement] = dataclass_field(default_factory=list)
    visible_if: str | None = None
    page_break_before: bool = False
    keep_together: bool = False


@dataclass(slots=True)
class Subreport:
    report: ReportDefinition
    data_source: str | None = None
    parameters: list[ParameterDefinition] = dataclass_field(default_factory=list)
    visible_if: str | None = None
    page_break_before: bool = False
    keep_together: bool = False


@dataclass(slots=True)
class Total:
    operation: str
    field: str | None = None
    expression: str | None = None
    formatter: str | None = None
    label: str | None = None
    data_source: str | None = None
    visible_if: str | None = None
    background_color: str | None = None
    border_color: str | None = None
    font: FontStyle = dataclass_field(default_factory=FontStyle)


HeaderElement = TextElement | ImageElement | CodeElement
BodyElement = TextElement | ImageElement | CodeElement | Table | DetailBand | Subreport
FooterElement = TextElement | ImageElement | CodeElement | Total


@dataclass(slots=True)
class Header:
    elements: list[HeaderElement] = dataclass_field(default_factory=list)


@dataclass(slots=True)
class PageBand:
    elements: list[HeaderElement] = dataclass_field(default_factory=list)


@dataclass(slots=True)
class Body:
    elements: list[BodyElement] = dataclass_field(default_factory=list)


@dataclass(slots=True)
class Footer:
    elements: list[FooterElement] = dataclass_field(default_factory=list)


@dataclass(slots=True)
class ReportDefinition:
    name: str
    margins: PageMargins = dataclass_field(default_factory=PageMargins)
    styles: dict[str, StyleDefinition] = dataclass_field(default_factory=dict)
    parameters: list[ParameterDefinition] = dataclass_field(default_factory=list)
    variables: list[VariableDefinition] = dataclass_field(default_factory=list)
    header: Header = dataclass_field(default_factory=Header)
    page_header: PageBand = dataclass_field(default_factory=PageBand)
    body: Body = dataclass_field(default_factory=Body)
    footer: Footer = dataclass_field(default_factory=Footer)
    page_footer: PageBand = dataclass_field(default_factory=PageBand)
    last_page_footer: PageBand = dataclass_field(default_factory=PageBand)
