from __future__ import annotations

from collections.abc import Callable, Iterable
from decimal import Decimal, InvalidOperation
from typing import Any


Aggregation = Callable[[list[Any]], Any]


def _numeric_sum(values: list[Any]) -> Decimal:
    total = Decimal("0")
    for value in values:
        if value is None:
            continue
        try:
            total += Decimal(str(value))
        except (InvalidOperation, ValueError):
            continue
    return total


def agg_sum(values: list[Any]) -> Any:
    return _numeric_sum(values)


def agg_count(values: list[Any]) -> int:
    return len(values)


def agg_avg(values: list[Any]) -> Decimal:
    if not values:
        return Decimal("0")
    return _numeric_sum(values) / Decimal(len(values))


AGGREGATIONS: dict[str, Aggregation] = {
    "sum": agg_sum,
    "count": agg_count,
    "avg": agg_avg,
}


def register_aggregation(name: str, aggregation: Aggregation) -> None:
    AGGREGATIONS[name] = aggregation


def has_aggregation(name: str) -> bool:
    return name in AGGREGATIONS


def aggregate(values: Iterable[Any], operation: str) -> Any:
    try:
        handler = AGGREGATIONS[operation]
    except KeyError as exc:
        raise KeyError(f"Agregação desconhecida: {operation}") from exc
    collected_values = list(values)
    return handler(collected_values)
