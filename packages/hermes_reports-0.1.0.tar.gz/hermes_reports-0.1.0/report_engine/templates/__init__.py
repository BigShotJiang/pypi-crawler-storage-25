"""Bundled XML report templates."""
