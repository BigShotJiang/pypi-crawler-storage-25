from __future__ import annotations

from collections.abc import Callable
from datetime import date, datetime
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Any


Formatter = Callable[[Any], str]


def _to_decimal(value: Any) -> Decimal | None:
    if value in (None, ""):
        return None
    if isinstance(value, Decimal):
        return value
    try:
        return Decimal(str(value))
    except (InvalidOperation, ValueError):
        return None


def _format_decimal(value: Decimal, decimal_places: int) -> str:
    quantized = value.quantize(
        Decimal("1") if decimal_places == 0 else Decimal(f"1.{'0' * decimal_places}"),
        rounding=ROUND_HALF_UP,
    )
    formatted = f"{quantized:,.{decimal_places}f}"
    return formatted.replace(",", "X").replace(".", ",").replace("X", ".")


def format_currency(value: Any) -> str:
    decimal_value = _to_decimal(value)
    if decimal_value is None:
        return ""
    return f"R$ {_format_decimal(decimal_value, 2)}"


def format_number(value: Any) -> str:
    decimal_value = _to_decimal(value)
    if decimal_value is None:
        return "" if value is None else str(value)
    decimal_places = max(0, min(-decimal_value.as_tuple().exponent, 6))
    return _format_decimal(decimal_value, decimal_places)


def format_date(value: Any) -> str:
    if value in (None, ""):
        return ""
    if isinstance(value, datetime):
        return value.strftime("%d/%m/%Y")
    if isinstance(value, date):
        return value.strftime("%d/%m/%Y")

    if isinstance(value, str):
        for fmt in ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S", "%d/%m/%Y"):
            try:
                return datetime.strptime(value, fmt).strftime("%d/%m/%Y")
            except ValueError:
                continue
    return str(value)


FORMATTERS: dict[str, Formatter] = {
    "currency": format_currency,
    "date": format_date,
    "number": format_number,
}


def register_formatter(name: str, formatter: Formatter) -> None:
    FORMATTERS[name] = formatter


def has_formatter(name: str) -> bool:
    return name in FORMATTERS


def format_value(value: Any, formatter_name: str | None = None) -> str:
    if formatter_name is None:
        return "" if value is None else str(value)
    formatter = FORMATTERS.get(formatter_name)
    if formatter is None:
        raise KeyError(f"Formatter desconhecido: {formatter_name}")
    return formatter(value)
