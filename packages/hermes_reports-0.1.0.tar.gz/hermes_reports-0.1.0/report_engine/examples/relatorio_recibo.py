from __future__ import annotations

from pathlib import Path

from hermes_reports import ReportEngine


def main() -> None:
    base_dir = Path(__file__).resolve().parent
    dados = {
        "numero": "2026-0042",
        "pagador": "João da Silva",
        "documento_pagador": "123.456.789-00",
        "recebedor": "Empresa Exemplo Ltda",
        "documento_recebedor": "12.345.678/0001-90",
        "responsavel_assinatura": "Marina Costa",
        "valor_pago": 1850.75,
        "referencia": "Serviços de consultoria prestados em março de 2026",
        "forma_pagamento": "Transferência bancária",
        "data_pagamento": "2026-03-28",
        "logo_dinamica": str((base_dir / "assets" / "logo_recibo.png").resolve()),
        "url_validacao": "https://hermes-report.local/validacao/2026-0042",
        "parcelas": [
            {"descricao": "Consultoria estratégica", "valor": 1200.50},
            {"descricao": "Elaboração de relatório técnico", "valor": 650.25},
        ],
        "historico_processamento": [
            {
                "etapa": "Solicitação recebida",
                "responsavel": "Larissa Nogueira",
                "data_hora": "28/03/2026 09:12",
                "observacao": "Pedido validado no portal financeiro e associado ao contrato principal.",
            },
            {
                "etapa": "Conferência documental",
                "responsavel": "Marina Costa",
                "data_hora": "28/03/2026 09:48",
                "observacao": "Documentos do pagador e comprovantes bancários conferidos sem divergências.",
            },
            {
                "etapa": "Baixa contábil",
                "responsavel": "Equipe de Tesouraria",
                "data_hora": "28/03/2026 10:21",
                "observacao": "Lançamento conciliado e recibo liberado para emissão final.",
            },
        ],
    }

    template_path = base_dir.parent / "templates" / "recibo.xml"
    output_dir = base_dir / "outputs"
    output_dir.mkdir(exist_ok=True)

    engine = ReportEngine(template_path)
    for extension in ("html", "pdf", "csv", "xlsx"):
        engine.render_to_file(
            dados,
            output_dir / f"relatorio_recibo.{extension}",
            output=extension,
        )

    print(f"Arquivos gerados em: {output_dir}")


if __name__ == "__main__":
    main()
