"""Examples for the XML report engine."""
