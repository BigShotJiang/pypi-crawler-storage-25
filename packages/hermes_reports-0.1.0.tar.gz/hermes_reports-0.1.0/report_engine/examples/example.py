from __future__ import annotations

from pathlib import Path

from hermes_reports import ReportEngine


def build_summary(rows: list[dict[str, int | float | str]]) -> list[dict[str, int | float | str]]:
    summary: dict[str, dict[str, int | float | str]] = {}
    for row in rows:
        category = str(row["categoria"])
        bucket = summary.setdefault(
            category,
            {
                "categoria": category,
                "quantidade_total": 0,
                "valor_total": 0.0,
                "ultima_venda": row.get("data_venda", ""),
            },
        )
        bucket["quantidade_total"] = int(bucket["quantidade_total"]) + int(row["quantidade"])
        bucket["valor_total"] = float(bucket["valor_total"]) + (
            int(row["quantidade"]) * float(row["valor"])
        )
        bucket["ultima_venda"] = str(row.get("data_venda", bucket["ultima_venda"]))
    return list(summary.values())


def main() -> None:
    categorias = ["Informática", "Periféricos", "Móveis", "Escritório"]
    produtos = [
        ("Notebook", 3500),
        ("Mouse", 80),
        ("Teclado", 140),
        ("Monitor", 1200),
        ("Cadeira", 890),
        ("Mesa", 950),
        ("Dock Station", 640),
        ("Webcam", 310),
    ]
    itens = [
        {
            "categoria": categorias[index % len(categorias)],
            "produto": f"{produto} {index + 1}",
            "quantidade": (index % 9) + 1,
            "valor": valor,
            "data_venda": f"2026-01-{(index % 28) + 1:02d}",
        }
        for index, (produto, valor) in enumerate(produtos * 8)
    ]
    dados = {
        "titulo": "Relatório de Vendas",
        "periodo": "01/01/2026 a 31/01/2026",
        "itens": itens,
        "resumo_categorias": build_summary(itens),
    }
    parameters = {
        "empresa": "Hermes Retail Brasil",
        "responsavel_relatorio": "Gerencia Nacional de Vendas",
        "titulo_resumo_categoria": "Painel executivo por categoria",
    }

    base_dir = Path(__file__).resolve().parent
    template_path = base_dir.parent / "templates" / "vendas.xml"
    output_dir = base_dir / "outputs"
    output_dir.mkdir(exist_ok=True)

    engine = ReportEngine(template_path)
    for extension in ("html", "pdf", "csv", "xlsx"):
        engine.render_to_file(
            dados,
            output_dir / f"relatorio_vendas.{extension}",
            output=extension,
            parameters=parameters,
        )

    print(f"Arquivos gerados em: {output_dir}")


if __name__ == "__main__":
    main()
