from __future__ import annotations

from pathlib import Path
from typing import Any

from .parser import parse_template
from .renderers import CSVRenderer, HTMLRenderer, PDFRenderer, XLSXRenderer


class ReportEngine:
    """Coordinates template parsing and report rendering."""

    def __init__(self, template_path: str | Path) -> None:
        self.template_path = Path(template_path)
        self.definition = parse_template(self.template_path)
        self._renderers = {
            "html": HTMLRenderer(),
            "csv": CSVRenderer(),
            "pdf": PDFRenderer(),
            "xlsx": XLSXRenderer(),
            "xmlx": XLSXRenderer(),
        }

    def register_renderer(self, name: str, renderer: Any) -> None:
        self._renderers[name] = renderer

    def render(
        self,
        data: dict[str, Any] | list[dict[str, Any]],
        output: str = "html",
        parameters: dict[str, Any] | None = None,
    ) -> str | bytes:
        try:
            renderer = self._renderers[output]
        except KeyError as exc:
            raise ValueError(f"Formato de saída não suportado: {output}") from exc
        return renderer.render(self.definition, data, parameters=parameters)

    def render_to_file(
        self,
        data: dict[str, Any] | list[dict[str, Any]],
        output_path: str | Path,
        output: str | None = None,
        parameters: dict[str, Any] | None = None,
        encoding: str = "utf-8",
    ) -> Path:
        destination = Path(output_path)
        output_format = output or self._detect_output_format(destination)
        content = self.render(data, output=output_format, parameters=parameters)

        if isinstance(content, bytes):
            destination.write_bytes(content)
        else:
            destination.write_text(content, encoding=encoding)
        return destination

    def _detect_output_format(self, destination: Path) -> str:
        suffix = destination.suffix.lower()
        mapping = {
            ".html": "html",
            ".htm": "html",
            ".pdf": "pdf",
            ".csv": "csv",
            ".xlsx": "xlsx",
            ".xmlx": "xlsx",
        }
        return mapping.get(suffix, "html")
