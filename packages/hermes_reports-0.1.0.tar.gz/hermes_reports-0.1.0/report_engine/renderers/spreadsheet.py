from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, time
from decimal import Decimal, InvalidOperation
from io import BytesIO
from typing import Any
from xml.sax.saxutils import escape as xml_escape
from zipfile import ZIP_DEFLATED, ZipFile

from ..models import ReportDefinition
from .base import BaseRenderer, RenderedReport, RenderedSubreport, RenderedTable


def _column_name(index: int) -> str:
    name = ""
    while index > 0:
        index, remainder = divmod(index - 1, 26)
        name = chr(65 + remainder) + name
    return name


@dataclass(slots=True)
class SpreadsheetCell:
    value: Any
    display: str
    style_id: int
    cell_type: str = "s"


@dataclass(slots=True)
class SpreadsheetRow:
    cells: list[SpreadsheetCell]


class XLSXRenderer(BaseRenderer):
    output_type = "xlsx"

    def render(self, report: ReportDefinition, data: Any, parameters: dict[str, Any] | None = None) -> bytes:
        rendered = self.build_rendered_report(report, data, parameters=parameters)
        rows = self._build_rows(rendered)
        sheet_xml = self._build_sheet_xml(rows)
        workbook_xml = self._build_workbook_xml(rendered.name)
        styles_xml = self._build_styles_xml()

        buffer = BytesIO()
        with ZipFile(buffer, "w", compression=ZIP_DEFLATED) as archive:
            archive.writestr("[Content_Types].xml", self._content_types_xml())
            archive.writestr("_rels/.rels", self._root_rels_xml())
            archive.writestr("xl/workbook.xml", workbook_xml)
            archive.writestr("xl/_rels/workbook.xml.rels", self._workbook_rels_xml())
            archive.writestr("xl/styles.xml", styles_xml)
            archive.writestr("xl/worksheets/sheet1.xml", sheet_xml)
        return buffer.getvalue()

    def _build_rows(self, rendered: RenderedReport) -> list[SpreadsheetRow]:
        rows: list[SpreadsheetRow] = []
        for table in self._iter_tables(rendered):
            rows.append(
                SpreadsheetRow(
                    cells=[
                        SpreadsheetCell(value=column.label, display=column.label, style_id=1)
                        for column in table.columns
                    ]
                )
            )
            for row in table.rows:
                if row.is_group:
                    values = [row.group_label or ""] + [""] * (len(table.columns) - 1)
                    rows.append(
                        SpreadsheetRow(
                            cells=[
                                SpreadsheetCell(
                                    value=value,
                                    display=value,
                                    style_id=6,
                                )
                                for value in values
                            ]
                        )
                    )
                    continue

                spreadsheet_cells: list[SpreadsheetCell] = []
                for index, cell in enumerate(row.cells):
                    column = table.columns[index]
                    spreadsheet_cells.append(self._build_cell(cell.value, cell.display, cell.formatter, column.align))
                rows.append(SpreadsheetRow(cells=spreadsheet_cells))
            rows.append(SpreadsheetRow(cells=[]))

        if rows and not rows[-1].cells:
            rows.pop()
        return rows

    def _iter_tables(self, rendered: RenderedReport) -> list[RenderedTable]:
        tables: list[RenderedTable] = []
        for block in rendered.body:
            if isinstance(block, RenderedTable):
                tables.append(block)
                continue
            if isinstance(block, RenderedSubreport):
                tables.extend(self._iter_tables(block.report))
        return tables

    def _build_cell(
        self,
        value: Any,
        display: str,
        formatter: str | None,
        align: str,
    ) -> SpreadsheetCell:
        if formatter == "date":
            serial = self._excel_date_serial(value)
            if serial is not None:
                return SpreadsheetCell(value=serial, display=display, style_id=5, cell_type="n")

        numeric = self._numeric_value(value)
        if formatter == "currency" and numeric is not None:
            return SpreadsheetCell(value=numeric, display=display, style_id=4, cell_type="n")
        if formatter == "number" and numeric is not None:
            style_id = 2 if float(numeric).is_integer() else 3
            return SpreadsheetCell(value=numeric, display=display, style_id=style_id, cell_type="n")

        if isinstance(value, bool):
            return SpreadsheetCell(value="1" if value else "0", display=display, style_id=2, cell_type="b")

        if isinstance(value, (int, float, Decimal)):
            style_id = 2 if float(value).is_integer() else 3
            return SpreadsheetCell(value=self._numeric_value(value), display=display, style_id=style_id, cell_type="n")

        serial = self._excel_date_serial(value)
        if serial is not None:
            return SpreadsheetCell(value=serial, display=display, style_id=5, cell_type="n")

        style_id = 7 if align == "right" else 8 if align == "center" else 0
        return SpreadsheetCell(value="" if value is None else str(value), display=display, style_id=style_id)

    def _build_sheet_xml(self, rows: list[SpreadsheetRow]) -> str:
        column_widths = self._compute_column_widths(rows)
        cols_xml = "".join(
            f'<col min="{index}" max="{index}" width="{width:.2f}" customWidth="1"/>'
            for index, width in enumerate(column_widths, start=1)
        )

        xml_rows: list[str] = []
        for row_index, row in enumerate(rows, start=1):
            cells_xml = []
            for column_index, cell in enumerate(row.cells, start=1):
                reference = f"{_column_name(column_index)}{row_index}"
                cells_xml.append(self._serialize_cell(reference, cell))
            xml_rows.append(f'<row r="{row_index}">{"".join(cells_xml)}</row>')

        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            f'<dimension ref="A1:{_column_name(max(1, len(column_widths)))}{max(1, len(rows))}"/>'
            f'<cols>{cols_xml}</cols>'
            f'<sheetData>{"".join(xml_rows)}</sheetData>'
            "</worksheet>"
        )

    def _serialize_cell(self, reference: str, cell: SpreadsheetCell) -> str:
        if cell.cell_type == "n":
            return f'<c r="{reference}" s="{cell.style_id}"><v>{cell.value}</v></c>'
        if cell.cell_type == "b":
            return f'<c r="{reference}" s="{cell.style_id}" t="b"><v>{cell.value}</v></c>'
        return (
            f'<c r="{reference}" s="{cell.style_id}" t="inlineStr">'
            f"<is><t>{xml_escape(str(cell.value))}</t></is></c>"
        )

    def _compute_column_widths(self, rows: list[SpreadsheetRow]) -> list[float]:
        max_columns = max((len(row.cells) for row in rows), default=1)
        widths = [10.0] * max_columns
        for row in rows:
            for index, cell in enumerate(row.cells):
                estimate = max(6.0, min(len(cell.display) * 1.12 + 2, 60.0))
                widths[index] = max(widths[index], estimate)
        return widths

    def _numeric_value(self, value: Any) -> str | None:
        if value in (None, ""):
            return None
        if isinstance(value, bool):
            return None
        if isinstance(value, int):
            return str(value)
        if isinstance(value, float):
            return format(value, ".15g")
        if isinstance(value, Decimal):
            return format(value, "f")
        try:
            decimal_value = Decimal(str(value))
        except (InvalidOperation, ValueError):
            return None
        return format(decimal_value, "f")

    def _excel_date_serial(self, value: Any) -> float | None:
        parsed = self._coerce_date(value)
        if parsed is None:
            return None

        base = datetime(1899, 12, 30)
        if isinstance(parsed, datetime):
            delta = parsed - base
            return delta.days + ((delta.seconds + delta.microseconds / 1_000_000) / 86400)
        delta = datetime.combine(parsed, time.min) - base
        return float(delta.days)

    def _coerce_date(self, value: Any) -> date | datetime | None:
        if value in (None, ""):
            return None
        if isinstance(value, datetime):
            return value
        if isinstance(value, date):
            return value
        if isinstance(value, str):
            for fmt in ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S", "%d/%m/%Y"):
                try:
                    parsed = datetime.strptime(value, fmt)
                except ValueError:
                    continue
                return parsed.date() if fmt == "%d/%m/%Y" else parsed
        return None

    def _content_types_xml(self) -> str:
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            '<Default Extension="xml" ContentType="application/xml"/>'
            '<Override PartName="/xl/workbook.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            '<Override PartName="/xl/worksheets/sheet1.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            '<Override PartName="/xl/styles.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            "</Types>"
        )

    def _root_rels_xml(self) -> str:
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" '
            'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" '
            'Target="xl/workbook.xml"/>'
            "</Relationships>"
        )

    def _workbook_rels_xml(self) -> str:
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" '
            'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" '
            'Target="worksheets/sheet1.xml"/>'
            '<Relationship Id="rId2" '
            'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" '
            'Target="styles.xml"/>'
            "</Relationships>"
        )

    def _build_workbook_xml(self, report_name: str) -> str:
        sheet_name = xml_escape(report_name[:31] or "Relatorio")
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            f'<sheets><sheet name="{sheet_name}" sheetId="1" r:id="rId1"/></sheets>'
            "</workbook>"
        )

    def _build_styles_xml(self) -> str:
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            '<numFmts count="3">'
            '<numFmt numFmtId="164" formatCode="#,##0.######"/>'
            '<numFmt numFmtId="165" formatCode="&quot;R$&quot; #,##0.00"/>'
            '<numFmt numFmtId="166" formatCode="dd/mm/yyyy"/>'
            '</numFmts>'
            '<fonts count="2">'
            '<font><sz val="11"/><name val="Calibri"/></font>'
            '<font><b/><sz val="11"/><color rgb="FF2C241B"/><name val="Calibri"/></font>'
            '</fonts>'
            '<fills count="4">'
            '<fill><patternFill patternType="none"/></fill>'
            '<fill><patternFill patternType="gray125"/></fill>'
            '<fill><patternFill patternType="solid"><fgColor rgb="FFF1E6D6"/><bgColor indexed="64"/></patternFill></fill>'
            '<fill><patternFill patternType="solid"><fgColor rgb="FFFBF3E7"/><bgColor indexed="64"/></patternFill></fill>'
            '</fills>'
            '<borders count="2">'
            '<border/>'
            '<border>'
            '<left style="thin"><color rgb="FFD9CCB9"/></left>'
            '<right style="thin"><color rgb="FFD9CCB9"/></right>'
            '<top style="thin"><color rgb="FFD9CCB9"/></top>'
            '<bottom style="thin"><color rgb="FFD9CCB9"/></bottom>'
            '</border>'
            '</borders>'
            '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            '<cellXfs count="9">'
            '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="1" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>'
            '<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>'
            '<xf numFmtId="165" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>'
            '<xf numFmtId="166" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>'
            '<xf numFmtId="0" fontId="1" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>'
            '</cellXfs>'
            "</styleSheet>"
        )
