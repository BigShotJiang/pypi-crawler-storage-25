from __future__ import annotations

import csv
from io import StringIO
from typing import Any

from ..models import ReportDefinition
from .base import BaseRenderer, table_rows_only


class CSVRenderer(BaseRenderer):
    output_type = "csv"

    def render(self, report: ReportDefinition, data: Any, parameters: dict[str, Any] | None = None) -> str:
        rendered = self.build_rendered_report(report, data, parameters=parameters)
        buffer = StringIO()
        writer = csv.writer(buffer)
        writer.writerows(table_rows_only(rendered))
        return buffer.getvalue()
