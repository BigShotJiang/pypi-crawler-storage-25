from __future__ import annotations

from collections import OrderedDict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..aggregators import aggregate
from ..formatters import format_value
from ..models import Body, CodeElement, Column, DetailBand, FontStyle, Footer, Header, ImageElement, PageBand, PageMargins, ParameterDefinition, ReportDefinition, Subreport, Table, TextElement, Total, VariableDefinition


class RenderError(RuntimeError):
    """Raised when report rendering fails."""


class AttrDict(dict):
    """Mapping that also exposes keys as attributes for expressions."""

    def __getattr__(self, item: str) -> Any:
        try:
            return self[item]
        except KeyError as exc:
            raise AttributeError(item) from exc


def wrap_context(value: Any) -> Any:
    if isinstance(value, Mapping):
        return AttrDict({key: wrap_context(item) for key, item in value.items()})
    if isinstance(value, list):
        return [wrap_context(item) for item in value]
    return value


@dataclass(slots=True)
class RenderContext:
    data: Any
    parameters: dict[str, Any] = field(default_factory=dict)
    variables: dict[str, Any] = field(default_factory=dict)


def _context_namespace(root: Any) -> AttrDict:
    if isinstance(root, RenderContext):
        data = wrap_context(root.data)
        params = wrap_context(root.parameters)
        variables = wrap_context(root.variables)
        namespace: AttrDict = AttrDict(
            {
                "data": data,
                "params": params,
                "parameters": params,
                "vars": variables,
                "variables": variables,
            }
        )
        if isinstance(data, Mapping):
            namespace.update({key: value for key, value in data.items() if str(key).isidentifier()})
        return namespace
    return wrap_context(root)


def resolve_path(path: str | None, root: Any, local: Any = None) -> Any:
    root_namespace = _context_namespace(root)
    if path in (None, "", "."):
        return local if local is not None else getattr(root, "data", root_namespace)

    parts = path.split(".")
    first = parts[0]
    candidates = []

    if isinstance(local, Mapping) and first in local:
        candidates.append(local)
    elif local is not None and hasattr(local, first):
        candidates.append(local)
    candidates.append(root_namespace)

    for candidate in candidates:
        current = candidate
        try:
            for part in parts:
                current = _resolve_part(current, part)
        except (AttributeError, KeyError, IndexError, TypeError, ValueError):
            continue
        return current
    return None


def _resolve_part(value: Any, part: str) -> Any:
    if isinstance(value, Mapping):
        return value[part]
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return value[int(part)]
    return getattr(value, part)


def evaluate_expression(expression: str, root: Any, local: Any = None) -> Any:
    root_namespace = _context_namespace(root)
    namespace: dict[str, Any] = {
        "root": root_namespace,
        "row": wrap_context(local),
        "data": root_namespace.get("data"),
        "params": root_namespace.get("params"),
        "parameters": root_namespace.get("parameters"),
        "vars": root_namespace.get("vars"),
        "variables": root_namespace.get("variables"),
        "len": len,
        "sum": sum,
        "min": min,
        "max": max,
        "abs": abs,
        "round": round,
        "str": str,
        "int": int,
        "float": float,
        "bool": bool,
    }

    if isinstance(root_namespace, Mapping):
        namespace.update({key: wrap_context(value) for key, value in root_namespace.items() if str(key).isidentifier()})
    if isinstance(local, Mapping):
        namespace.update({key: wrap_context(value) for key, value in local.items() if key.isidentifier()})

    try:
        return eval(expression, {"__builtins__": {}}, namespace)
    except Exception as exc:
        raise RenderError(f"Falha ao avaliar expressão '{expression}': {exc}") from exc


def is_visible(visible_if: str | None, root: Any, local: Any = None) -> bool:
    if not visible_if:
        return True
    return bool(evaluate_expression(visible_if, root, local))


@dataclass(slots=True)
class TableState:
    default_rows: list[dict[str, Any]] = field(default_factory=list)
    collections: dict[str, list[dict[str, Any]]] = field(default_factory=dict)


@dataclass(slots=True)
class RenderedText:
    kind: str
    text: str
    align: str = "left"
    page_break_before: bool = False
    keep_together: bool = False
    background_color: str | None = None
    border_color: str | None = None
    font: FontStyle = field(default_factory=FontStyle)


@dataclass(slots=True)
class RenderedImage:
    src: str
    alt: str | None = None
    width_mm: float | None = None
    height_mm: float | None = None
    page_break_before: bool = False
    keep_together: bool = False
    background_color: str | None = None
    border_color: str | None = None


@dataclass(slots=True)
class RenderedCode:
    kind: str
    value: str
    symbology: str | None = None
    width_mm: float | None = None
    height_mm: float | None = None
    page_break_before: bool = False
    keep_together: bool = False
    color: str | None = None
    background_color: str | None = None
    border_color: str | None = None


@dataclass(slots=True)
class RenderedCell:
    label: str
    value: Any
    display: str
    align: str
    formatter: str | None = None
    font: FontStyle = field(default_factory=FontStyle)


@dataclass(slots=True)
class RenderedColumn:
    label: str
    align: str = "left"
    header_align: str = "left"
    width_mode: str = "auto"
    width_mm: float | None = None
    background_color: str | None = None
    border_color: str | None = None
    header_background_color: str | None = None
    header_border_color: str | None = None
    font: FontStyle = field(default_factory=FontStyle)
    header_font: FontStyle = field(default_factory=FontStyle)


@dataclass(slots=True)
class RenderedTableRow:
    cells: list[RenderedCell] = field(default_factory=list)
    is_group: bool = False
    group_label: str | None = None


@dataclass(slots=True)
class RenderedTable:
    title: str | None
    columns: list[RenderedColumn]
    rows: list[RenderedTableRow]
    source: str | None = None
    page_break_before: bool = False
    keep_together: bool = False
    background_color: str | None = None
    border_color: str | None = None
    title_align: str = "left"
    title_font: FontStyle = field(default_factory=FontStyle)


@dataclass(slots=True)
class RenderedDetailRow:
    blocks: list[RenderedText | RenderedImage | RenderedCode] = field(default_factory=list)


@dataclass(slots=True)
class RenderedDetail:
    source: str
    rows: list[RenderedDetailRow] = field(default_factory=list)
    page_break_before: bool = False
    keep_together: bool = False


@dataclass(slots=True)
class RenderedSubreport:
    report: RenderedReport
    page_break_before: bool = False
    keep_together: bool = False


@dataclass(slots=True)
class RenderedTotal:
    label: str
    value: Any
    display: str
    background_color: str | None = None
    border_color: str | None = None
    font: FontStyle = field(default_factory=FontStyle)


RenderedHeaderBlock = RenderedText | RenderedImage | RenderedCode
RenderedBodyBlock = RenderedText | RenderedImage | RenderedCode | RenderedTable | RenderedDetail | RenderedSubreport
RenderedFooterBlock = RenderedText | RenderedImage | RenderedCode | RenderedTotal


@dataclass(slots=True)
class RenderedReport:
    name: str
    margins: PageMargins = field(default_factory=PageMargins)
    header: list[RenderedHeaderBlock] = field(default_factory=list)
    page_header: list[RenderedHeaderBlock] = field(default_factory=list)
    body: list[RenderedBodyBlock] = field(default_factory=list)
    footer: list[RenderedFooterBlock] = field(default_factory=list)
    page_footer: list[RenderedHeaderBlock] = field(default_factory=list)
    last_page_footer: list[RenderedHeaderBlock] = field(default_factory=list)


def report_to_rows(rendered: RenderedReport) -> list[list[str]]:
    rows: list[list[str]] = [[rendered.name]]
    for block in rendered.header:
        if isinstance(block, RenderedText):
            rows.append([block.text])
            continue
        if isinstance(block, RenderedCode):
            rows.append([f"[{block.kind.upper()}: {block.value}]"])
            continue
        rows.append([f"[Imagem: {block.alt or Path(block.src).name}]"])
    rows.append([])

    for block in rendered.body:
        if isinstance(block, RenderedText):
            rows.append([block.text])
            continue
        if isinstance(block, RenderedImage):
            rows.append([f"[Imagem: {block.alt or Path(block.src).name}]"])
            continue
        if isinstance(block, RenderedCode):
            rows.append([f"[{block.kind.upper()}: {block.value}]"])
            continue
        if isinstance(block, RenderedSubreport):
            rows.extend(report_to_rows(block.report))
            rows.append([])
            continue
        if isinstance(block, RenderedDetail):
            for detail_row in block.rows:
                for detail_block in detail_row.blocks:
                    if isinstance(detail_block, RenderedText):
                        rows.append([detail_block.text])
                    elif isinstance(detail_block, RenderedCode):
                        rows.append([f"[{detail_block.kind.upper()}: {detail_block.value}]"])
                    else:
                        rows.append([f"[Imagem: {detail_block.alt or Path(detail_block.src).name}]"])
                rows.append([])
            continue

        if block.title:
            rows.append([block.title])
        rows.append([column.label for column in block.columns])
        for row in block.rows:
            if row.is_group:
                rows.append([row.group_label or ""] + [""] * (len(block.columns) - 1))
                continue
            rows.append([cell.display for cell in row.cells])
        rows.append([])

    for block in rendered.footer:
        if isinstance(block, RenderedText):
            rows.append([block.text])
            continue
        if isinstance(block, RenderedCode):
            rows.append([f"[{block.kind.upper()}: {block.value}]"])
            continue
        if isinstance(block, RenderedImage):
            rows.append([f"[Imagem: {block.alt or Path(block.src).name}]"])
            continue
        rows.append([block.label, block.display])
    return rows


def table_rows_only(rendered: RenderedReport) -> list[list[str]]:
    rows: list[list[str]] = []
    for block in rendered.body:
        if isinstance(block, RenderedSubreport):
            nested_rows = table_rows_only(block.report)
            rows.extend(nested_rows)
            if nested_rows:
                rows.append([])
            continue
        if isinstance(block, RenderedTable):
            rows.append([column.label for column in block.columns])
            for row in block.rows:
                if row.is_group:
                    rows.append([row.group_label or ""] + [""] * (len(block.columns) - 1))
                    continue
                rows.append([cell.display for cell in row.cells])
            rows.append([])
    if rows and rows[-1] == []:
        rows.pop()
    return rows


class BaseRenderer:
    output_type = ""

    def build_rendered_report(
        self,
        report: ReportDefinition,
        data: Any,
        parameters: dict[str, Any] | None = None,
        inherited_parameters: dict[str, Any] | None = None,
        parameter_bindings: list[ParameterDefinition] | None = None,
    ) -> RenderedReport:
        context = self._build_context(
            report,
            data,
            runtime_parameters=parameters,
            inherited_parameters=inherited_parameters,
            parameter_bindings=parameter_bindings,
        )
        table_state = TableState()
        rendered_report = RenderedReport(name=report.name, margins=report.margins)
        rendered_report.header = self._render_header(report.header, context)
        rendered_report.page_header = self._render_page_band(report.page_header, context)
        rendered_report.body = self._render_body(report.body, context, table_state)
        rendered_report.footer = self._render_footer(report.footer, context, table_state)
        rendered_report.page_footer = self._render_page_band(report.page_footer, context)
        rendered_report.last_page_footer = self._render_page_band(report.last_page_footer, context)
        return rendered_report

    def _build_context(
        self,
        report: ReportDefinition,
        data: Any,
        runtime_parameters: dict[str, Any] | None = None,
        inherited_parameters: dict[str, Any] | None = None,
        parameter_bindings: list[ParameterDefinition] | None = None,
    ) -> RenderContext:
        parameters = dict(inherited_parameters or {})
        for name, value in self._resolve_parameter_definitions(report.parameters, data, parameters, {}).items():
            parameters.setdefault(name, value)
        if runtime_parameters:
            parameters.update(runtime_parameters)
        if parameter_bindings:
            parameters.update(self._resolve_parameter_definitions(parameter_bindings, data, parameters, {}))

        variables = self._resolve_variables(report.variables, data, parameters)
        if parameter_bindings:
            parameters.update(self._resolve_parameter_definitions(parameter_bindings, data, parameters, variables))
            variables = self._resolve_variables(report.variables, data, parameters)
        return RenderContext(data=data, parameters=parameters, variables=variables)

    def _resolve_parameter_definitions(
        self,
        definitions: list[ParameterDefinition],
        data: Any,
        parameters: dict[str, Any],
        variables: dict[str, Any],
    ) -> dict[str, Any]:
        resolved: dict[str, Any] = {}
        for definition in definitions:
            current_parameters = {**parameters, **resolved}
            context = RenderContext(data=data, parameters=current_parameters, variables=variables)
            resolved[definition.name] = self._resolve_parameter_value(definition, context)
        return resolved

    def _resolve_parameter_value(self, definition: ParameterDefinition, context: RenderContext) -> Any:
        if definition.value is not None:
            return definition.value
        if definition.expression:
            return evaluate_expression(definition.expression, context)
        return resolve_path(definition.field, context)

    def _resolve_variables(
        self,
        definitions: list[VariableDefinition],
        data: Any,
        parameters: dict[str, Any],
    ) -> dict[str, Any]:
        variables: dict[str, Any] = {}
        for definition in definitions:
            context = RenderContext(data=data, parameters=parameters, variables=variables)
            variables[definition.name] = evaluate_expression(definition.expression, context)
        return variables

    def _render_header(self, header: Header, context: RenderContext) -> list[RenderedHeaderBlock]:
        parts: list[RenderedHeaderBlock] = []
        for element in header.elements:
            if isinstance(element, ImageElement):
                if not is_visible(element.visible_if, context):
                    continue
                rendered_image = self._render_dynamic_image_element(element, context)
                if rendered_image:
                    parts.append(rendered_image)
                continue
            if isinstance(element, CodeElement):
                if not is_visible(element.visible_if, context):
                    continue
                rendered_code = self._render_code_element(element, context)
                if rendered_code:
                    parts.append(rendered_code)
                continue
            if not is_visible(element.visible_if, context):
                continue
            content = self._render_text_element(element, context)
            if content:
                parts.append(
                    RenderedText(
                        kind=element.kind,
                        text=content,
                        align=element.align or "left",
                        background_color=element.background_color,
                        border_color=element.border_color,
                        font=element.font,
                    )
                )
        return parts

    def _render_page_band(self, band: PageBand, context: RenderContext) -> list[RenderedHeaderBlock]:
        parts: list[RenderedHeaderBlock] = []
        for element in band.elements:
            if isinstance(element, ImageElement):
                if not is_visible(element.visible_if, context):
                    continue
                rendered_image = self._render_dynamic_image_element(element, context)
                if rendered_image:
                    parts.append(rendered_image)
                continue
            if isinstance(element, CodeElement):
                if not is_visible(element.visible_if, context):
                    continue
                rendered_code = self._render_code_element(element, context)
                if rendered_code:
                    parts.append(rendered_code)
                continue
            if not is_visible(element.visible_if, context):
                continue
            content = self._render_text_element(element, context)
            if content:
                parts.append(
                    RenderedText(
                        kind=element.kind,
                        text=content,
                        align=element.align or "left",
                        background_color=element.background_color,
                        border_color=element.border_color,
                        font=element.font,
                    )
                )
        return parts

    def _render_body(self, body: Body, context: RenderContext, table_state: TableState) -> list[RenderedBodyBlock]:
        parts: list[RenderedBodyBlock] = []
        for element in body.elements:
            if isinstance(element, ImageElement):
                if not is_visible(element.visible_if, context):
                    continue
                rendered_image = self._render_dynamic_image_element(element, context)
                if rendered_image:
                    parts.append(rendered_image)
                continue
            if isinstance(element, CodeElement):
                if not is_visible(element.visible_if, context):
                    continue
                rendered_code = self._render_code_element(element, context)
                if rendered_code:
                    parts.append(rendered_code)
                continue
            if isinstance(element, TextElement):
                if not is_visible(element.visible_if, context):
                    continue
                content = self._render_text_element(element, context)
                if content:
                    parts.append(
                        RenderedText(
                            kind=element.kind,
                            text=content,
                            align=element.align or "left",
                            page_break_before=element.page_break_before,
                            keep_together=element.keep_together,
                            background_color=element.background_color,
                            border_color=element.border_color,
                            font=element.font,
                        )
                    )
                continue
            if isinstance(element, DetailBand):
                if not is_visible(element.visible_if, context):
                    continue
                rendered_detail = self._render_detail_band(element, context)
                if rendered_detail.rows:
                    parts.append(rendered_detail)
                continue
            if isinstance(element, Subreport):
                if not is_visible(element.visible_if, context):
                    continue
                parts.append(self._render_subreport(element, context))
                continue

            if not is_visible(element.visible_if, context):
                continue

            rendered_table, rows = self._render_table(element, context)
            if rows and not table_state.default_rows:
                table_state.default_rows = rows
            if element.data_source:
                table_state.collections[element.data_source] = rows
            parts.append(rendered_table)
        return parts

    def _render_footer(self, footer: Footer, context: RenderContext, table_state: TableState) -> list[RenderedFooterBlock]:
        parts: list[RenderedFooterBlock] = []
        for element in footer.elements:
            if isinstance(element, ImageElement):
                if not is_visible(element.visible_if, context):
                    continue
                rendered_image = self._render_dynamic_image_element(element, context)
                if rendered_image:
                    parts.append(rendered_image)
                continue
            if isinstance(element, CodeElement):
                if not is_visible(element.visible_if, context):
                    continue
                rendered_code = self._render_code_element(element, context)
                if rendered_code:
                    parts.append(rendered_code)
                continue
            if isinstance(element, TextElement):
                if not is_visible(element.visible_if, context):
                    continue
                content = self._render_text_element(element, context)
                if content:
                    parts.append(
                        RenderedText(
                            kind=element.kind,
                            text=content,
                            align=element.align or "left",
                            background_color=element.background_color,
                            border_color=element.border_color,
                            font=element.font,
                        )
                    )
                continue

            if not is_visible(element.visible_if, context):
                continue
            parts.append(self._render_total(element, context, table_state))
        return parts

    def _render_text_element(self, element: TextElement, context: RenderContext, row: Any = None) -> str:
        value = self._resolve_element_value(element, context, row)
        return self._apply_text_transform(format_value(value, element.formatter), element.font.transform)

    def _render_image_element(self, element: ImageElement) -> RenderedImage:
        source = self._resolve_image_source(element, None)
        if not source:
            raise RenderError("A imagem não definiu um caminho resolvido para renderização.")
        return RenderedImage(
            src=source,
            alt=element.alt,
            width_mm=element.width_mm,
            height_mm=element.height_mm,
            page_break_before=element.page_break_before,
            keep_together=element.keep_together,
            background_color=element.background_color,
            border_color=element.border_color,
        )

    def _render_dynamic_image_element(
        self,
        element: ImageElement,
        context: RenderContext,
        row: Any = None,
    ) -> RenderedImage | None:
        source = self._resolve_image_source(element, context, row)
        if not source:
            return None
        return RenderedImage(
            src=source,
            alt=element.alt,
            width_mm=element.width_mm,
            height_mm=element.height_mm,
            page_break_before=element.page_break_before,
            keep_together=element.keep_together,
            background_color=element.background_color,
            border_color=element.border_color,
        )

    def _resolve_image_source(
        self,
        element: ImageElement,
        context: RenderContext | None,
        row: Any = None,
    ) -> str | None:
        if element.src:
            return element.src
        if context is None:
            return None
        if element.expression:
            resolved = evaluate_expression(element.expression, context, row)
        else:
            resolved = resolve_path(element.field, context, row)
        if resolved in (None, ""):
            return None
        return str(resolved)

    def _render_code_element(
        self,
        element: CodeElement,
        context: RenderContext,
        row: Any = None,
    ) -> RenderedCode | None:
        value = self._resolve_code_value(element, context, row)
        if value in (None, ""):
            return None
        return RenderedCode(
            kind=element.kind,
            value=str(value),
            symbology=element.symbology,
            width_mm=element.width_mm,
            height_mm=element.height_mm,
            page_break_before=element.page_break_before,
            keep_together=element.keep_together,
            color=element.color,
            background_color=element.background_color,
            border_color=element.border_color,
        )

    def _resolve_code_value(
        self,
        element: CodeElement,
        context: RenderContext,
        row: Any = None,
    ) -> Any:
        if element.value is not None:
            return element.value
        if element.expression:
            return evaluate_expression(element.expression, context, row)
        return resolve_path(element.field, context, row)

    def _render_table(self, table: Table, context: RenderContext) -> tuple[RenderedTable, list[dict[str, Any]]]:
        raw_rows = resolve_path(table.data_source, context)
        if raw_rows is None and isinstance(context.data, list):
            raw_rows = context.data

        if raw_rows is None:
            rows: list[dict[str, Any]] = []
        elif isinstance(raw_rows, list):
            rows = list(raw_rows)
        else:
            raise RenderError(f"A fonte de dados '{table.data_source}' deve ser uma lista.")

        visible_columns = [column for column in table.columns if is_visible(column.visible_if, context)]
        if not visible_columns:
            raise RenderError("A tabela não possui colunas visíveis para renderização.")
        rendered_columns = [self._render_column(column) for column in visible_columns]

        rendered_rows: list[RenderedTableRow] = []
        grouped_rows = self._group_rows(rows, table.group_by, context)

        for group_label, items in grouped_rows.items():
            if group_label is not None:
                rendered_rows.append(RenderedTableRow(is_group=True, group_label=group_label))
            for row in items:
                rendered_rows.append(
                    RenderedTableRow(
                        cells=[self._render_cell(column, context, row) for column in visible_columns]
                    )
                )

        return (
            RenderedTable(
                title=table.title,
                columns=rendered_columns,
                rows=rendered_rows,
                source=table.data_source,
                page_break_before=table.page_break_before,
                keep_together=table.keep_together,
                background_color=table.background_color,
                border_color=table.border_color,
                title_align=table.title_align,
                title_font=table.title_font,
            ),
            rows,
        )

    def _render_detail_band(self, detail: DetailBand, context: RenderContext) -> RenderedDetail:
        raw_rows = resolve_path(detail.data_source, context)
        if raw_rows is None and isinstance(context.data, list):
            raw_rows = context.data

        if raw_rows is None:
            rows: list[dict[str, Any]] = []
        elif isinstance(raw_rows, list):
            rows = list(raw_rows)
        else:
            raise RenderError(f"A fonte de dados '{detail.data_source}' deve ser uma lista.")

        rendered_rows: list[RenderedDetailRow] = []
        for row in rows:
            blocks: list[RenderedText | RenderedImage | RenderedCode] = []
            for element in detail.elements:
                if isinstance(element, ImageElement):
                    if not is_visible(element.visible_if, context, row):
                        continue
                    rendered_image = self._render_dynamic_image_element(element, context, row)
                    if rendered_image:
                        blocks.append(rendered_image)
                    continue
                if isinstance(element, CodeElement):
                    if not is_visible(element.visible_if, context, row):
                        continue
                    rendered_code = self._render_code_element(element, context, row)
                    if rendered_code:
                        blocks.append(rendered_code)
                    continue
                if not is_visible(element.visible_if, context, row):
                    continue
                content = self._render_text_element(element, context, row)
                if not content:
                    continue
                blocks.append(
                    RenderedText(
                        kind=element.kind,
                        text=content,
                        align=element.align or "left",
                        background_color=element.background_color,
                        border_color=element.border_color,
                        font=element.font,
                    )
                )
            if blocks:
                rendered_rows.append(RenderedDetailRow(blocks=blocks))

        return RenderedDetail(
            source=detail.data_source,
            rows=rendered_rows,
            page_break_before=detail.page_break_before,
            keep_together=detail.keep_together,
        )

    def _render_subreport(self, subreport: Subreport, context: RenderContext) -> RenderedSubreport:
        subreport_data = resolve_path(subreport.data_source, context)
        if subreport_data is None:
            subreport_data = [] if subreport.data_source else context.data

        rendered_report = self.build_rendered_report(
            subreport.report,
            subreport_data,
            inherited_parameters=context.parameters,
            parameter_bindings=subreport.parameters,
        )
        return RenderedSubreport(
            report=rendered_report,
            page_break_before=subreport.page_break_before,
            keep_together=subreport.keep_together,
        )

    def _render_column(self, column: Column) -> RenderedColumn:
        return RenderedColumn(
            label=self._apply_text_transform(column.label, column.header_font.transform),
            align=column.align or "left",
            header_align=column.header_align or column.align or "left",
            width_mode=column.width_mode,
            width_mm=column.width_mm,
            background_color=column.background_color,
            border_color=column.border_color,
            header_background_color=column.header_background_color,
            header_border_color=column.header_border_color,
            font=column.font,
            header_font=column.header_font,
        )

    def _render_cell(self, column: Column, context: RenderContext, row: dict[str, Any]) -> RenderedCell:
        if column.expression:
            value = evaluate_expression(column.expression, context, row)
        else:
            value = resolve_path(column.field, context, row)
        display = format_value(value, column.formatter)
        return RenderedCell(
            label=column.label,
            value=value,
            display=self._apply_text_transform(display, column.font.transform),
            align=column.align or self._infer_alignment(column),
            formatter=column.formatter,
            font=column.font,
        )

    def _render_total(self, total: Total, context: RenderContext, table_state: TableState) -> RenderedTotal:
        rows = self._resolve_total_rows(total, context, table_state)
        if total.operation == "count" and not total.field and not total.expression:
            values = rows
        else:
            values = [self._resolve_total_value(total, context, row) for row in rows]

        result = aggregate(values, total.operation)
        label = total.label or self._default_total_label(total)
        return RenderedTotal(
            label=label,
            value=result,
            display=format_value(result, total.formatter),
            background_color=total.background_color,
            border_color=total.border_color,
            font=total.font,
        )

    def _resolve_total_rows(self, total: Total, context: RenderContext, table_state: TableState) -> list[dict[str, Any]]:
        if total.data_source:
            rows = resolve_path(total.data_source, context)
            if rows is None:
                rows = table_state.collections.get(total.data_source, [])
        else:
            rows = table_state.default_rows or (context.data if isinstance(context.data, list) else [])

        if rows is None:
            return []
        if not isinstance(rows, list):
            raise RenderError("Totais só podem ser calculados sobre listas.")
        return list(rows)

    def _resolve_total_value(self, total: Total, context: RenderContext, row: dict[str, Any]) -> Any:
        if total.expression:
            return evaluate_expression(total.expression, context, row)
        return resolve_path(total.field, context, row)

    def _resolve_element_value(self, element: TextElement, context: RenderContext, row: Any = None) -> Any:
        if element.value is not None:
            return element.value
        if element.expression:
            return evaluate_expression(element.expression, context, row)
        return resolve_path(element.field, context, row)

    def _group_rows(
        self,
        rows: list[dict[str, Any]],
        group_by: str | None,
        context: RenderContext,
    ) -> OrderedDict[str | None, list[dict[str, Any]]]:
        if not group_by:
            return OrderedDict({None: rows})

        grouped: OrderedDict[str | None, list[dict[str, Any]]] = OrderedDict()
        for row in rows:
            key = resolve_path(group_by, context, row)
            grouped.setdefault(None if key is None else str(key), []).append(row)
        return grouped

    def _default_total_label(self, total: Total) -> str:
        target = total.field or total.expression or "itens"
        return f"{total.operation.upper()} de {target}"

    def _infer_alignment(self, column: Column) -> str:
        return "left"

    def _apply_text_transform(self, value: str, transform: str | None) -> str:
        if transform == "uppercase":
            return value.upper()
        if transform == "lowercase":
            return value.lower()
        if transform == "capitalize":
            return value.title()
        return value
