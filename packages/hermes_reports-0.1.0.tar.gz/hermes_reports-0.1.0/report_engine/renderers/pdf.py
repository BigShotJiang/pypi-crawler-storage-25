from __future__ import annotations

import base64
from html import escape
from io import BytesIO
from pathlib import Path
from typing import Any

from ..models import FontStyle, ReportDefinition
from .base import BaseRenderer, RenderedCode, RenderedColumn, RenderedDetail, RenderedImage, RenderedSubreport, RenderedTable, RenderedText, RenderError


class PDFRenderer(BaseRenderer):
    output_type = "pdf"

    def render(self, report: ReportDefinition, data: Any, parameters: dict[str, Any] | None = None) -> bytes:
        try:
            from reportlab.pdfgen import canvas as pdf_canvas
            from reportlab.lib import colors
            from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT, TA_RIGHT
            from reportlab.lib.pagesizes import A4
            from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
            from reportlab.lib.units import mm
            from reportlab.platypus import Image as PDFImage
            from reportlab.platypus import KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table as PDFTable, TableStyle
        except ImportError as exc:
            raise RenderError("reportlab não está instalado. Instale as dependências do projeto.") from exc

        rendered = self.build_rendered_report(report, data, parameters=parameters)
        buffer = BytesIO()
        page_width, page_height = A4
        physical_left = rendered.margins.left_mm * mm
        physical_right = rendered.margins.right_mm * mm
        physical_top = rendered.margins.top_mm * mm
        physical_bottom = rendered.margins.bottom_mm * mm
        content_width = page_width - physical_left - physical_right
        page_band_gap = 8

        document = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            leftMargin=physical_left,
            rightMargin=physical_right,
            topMargin=physical_top,
            bottomMargin=physical_bottom,
            title=rendered.name,
        )

        styles = getSampleStyleSheet()
        title_style = ParagraphStyle(
            "ReportTitle",
            parent=styles["Title"],
            fontName="Helvetica-Bold",
            fontSize=19,
            leading=22,
            textColor=colors.HexColor("#2c241b"),
            alignment=TA_LEFT,
        )
        subtitle_style = ParagraphStyle(
            "ReportSubtitle",
            parent=styles["BodyText"],
            fontName="Helvetica",
            fontSize=10,
            leading=13,
            textColor=colors.HexColor("#776959"),
        )

        page_header_height = self._measure_page_band(
            rendered.page_header,
            width=content_width,
            image_cls=PDFImage,
            paragraph_cls=Paragraph,
            mm=mm,
            title_style=title_style,
            subtitle_style=subtitle_style,
        )
        page_footer_height = self._measure_page_band(
            rendered.page_footer,
            width=content_width,
            image_cls=PDFImage,
            paragraph_cls=Paragraph,
            mm=mm,
            title_style=title_style,
            subtitle_style=subtitle_style,
        )
        last_page_footer_height = self._measure_page_band(
            rendered.last_page_footer,
            width=content_width,
            image_cls=PDFImage,
            paragraph_cls=Paragraph,
            mm=mm,
            title_style=title_style,
            subtitle_style=subtitle_style,
        )
        reserved_footer_height = max(page_footer_height, last_page_footer_height)
        document.topMargin = physical_top + (page_header_height + page_band_gap if page_header_height else 0)
        document.bottomMargin = physical_bottom + (reserved_footer_height + page_band_gap if reserved_footer_height else 0)
        story: list[Any] = []

        for block in rendered.header:
            if isinstance(block, RenderedImage):
                story.append(self._box_flowable(self._build_pdf_image(block, PDFImage, mm), block, PDFTable, TableStyle, colors))
                story.append(Spacer(1, 8))
                continue
            if isinstance(block, RenderedCode):
                story.append(self._build_pdf_code(block, mm, colors, PDFTable, TableStyle))
                story.append(Spacer(1, 8))
                continue
            default_style = title_style if block.kind == "title" else subtitle_style
            story.append(
                self._box_flowable(
                    Paragraph(escape(block.text), self._text_style(default_style, block.font, block.align)),
                    block,
                    PDFTable,
                    TableStyle,
                    colors,
                )
            )
            story.append(Spacer(1, 8 if block.kind == "title" else 4))

        for block in rendered.body:
            if getattr(block, "page_break_before", False):
                story.append(PageBreak())

            if isinstance(block, RenderedSubreport):
                flowables = self._pdf_subreport_elements(
                    block,
                    colors=colors,
                    pdf_table_cls=PDFTable,
                    table_style_cls=TableStyle,
                    paragraph_cls=Paragraph,
                    image_cls=PDFImage,
                    spacer_cls=Spacer,
                    keep_together_cls=KeepTogether,
                    page_break_cls=PageBreak,
                    mm=mm,
                    title_style=title_style,
                    subtitle_style=subtitle_style,
                )
                if block.keep_together and flowables:
                    story.append(KeepTogether(flowables))
                    continue
                story.extend(flowables)
                continue

            if isinstance(block, RenderedDetail):
                story.extend(
                    self._pdf_detail_elements(
                        block,
                        paragraph_cls=Paragraph,
                        image_cls=PDFImage,
                        spacer_cls=Spacer,
                        keep_together_cls=KeepTogether,
                        colors=colors,
                        pdf_table_cls=PDFTable,
                        table_style_cls=TableStyle,
                        mm=mm,
                        subtitle_style=subtitle_style,
                    )
                )
                continue

            flowables = self._pdf_body_flowables(
                block,
                colors=colors,
                pdf_table_cls=PDFTable,
                table_style_cls=TableStyle,
                paragraph_cls=Paragraph,
                image_cls=PDFImage,
                spacer_cls=Spacer,
                mm=mm,
                subtitle_style=subtitle_style,
            )
            if getattr(block, "keep_together", False) and flowables:
                story.append(KeepTogether(flowables))
                continue
            story.extend(flowables)

        if rendered.footer:
            story.append(Spacer(1, 6))
        for block in rendered.footer:
            if isinstance(block, RenderedText):
                story.append(
                    self._box_flowable(
                        Paragraph(escape(block.text), self._text_style(subtitle_style, block.font, block.align)),
                        block,
                        PDFTable,
                        TableStyle,
                        colors,
                    )
                )
                continue
            if isinstance(block, RenderedImage):
                story.append(self._box_flowable(self._build_pdf_image(block, PDFImage, mm), block, PDFTable, TableStyle, colors))
                continue
            if isinstance(block, RenderedCode):
                story.append(self._build_pdf_code(block, mm, colors, PDFTable, TableStyle))
                continue

            total_table = PDFTable([[block.label, block.display]], colWidths=[320, 140])
            total_table.setStyle(
                TableStyle(
                    [
                        ("TEXTCOLOR", (0, 0), (-1, -1), colors.HexColor(block.font.color or "#2c241b")),
                        ("FONTNAME", (0, 0), (0, 0), "Helvetica"),
                        ("FONTNAME", (1, 0), (1, 0), "Helvetica-Bold"),
                        ("ALIGN", (1, 0), (1, 0), "RIGHT"),
                        ("LINEBELOW", (0, 0), (-1, -1), 0.5, colors.HexColor(block.border_color or "#d9ccb9")),
                        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor(block.background_color or "#ffffff")),
                        ("TOPPADDING", (0, 0), (-1, -1), 6),
                        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                    ]
                )
            )
            story.append(total_table)

        page_decorator = self._build_page_decorator(
            rendered=rendered,
            content_width=content_width,
            physical_left=physical_left,
            physical_top=physical_top,
            physical_bottom=physical_bottom,
            page_height=page_height,
            reserved_footer_height=reserved_footer_height,
            image_cls=PDFImage,
            paragraph_cls=Paragraph,
            mm=mm,
            title_style=title_style,
            subtitle_style=subtitle_style,
        )

        class DecoratedCanvas(pdf_canvas.Canvas):
            def __init__(self, *args: Any, **kwargs: Any) -> None:
                super().__init__(*args, **kwargs)
                self._saved_page_states: list[dict[str, Any]] = []

            def showPage(self) -> None:
                self._saved_page_states.append(dict(self.__dict__))
                self._startPage()

            def save(self) -> None:
                total_pages = len(self._saved_page_states)
                for page_number, state in enumerate(self._saved_page_states, start=1):
                    self.__dict__.update(state)
                    page_decorator(self, page_number, total_pages)
                    super().showPage()
                super().save()

        document.build(story, canvasmaker=DecoratedCanvas)
        return buffer.getvalue()

    def _build_pdf_image(self, block: RenderedImage, image_cls: Any, mm: Any) -> Any:
        image_source = self._pdf_image_source(block.src)
        image = image_cls(image_source)
        width = block.width_mm * mm if block.width_mm is not None else None
        height = block.height_mm * mm if block.height_mm is not None else None

        if width and height:
            image.drawWidth = width
            image.drawHeight = height
            return image

        aspect_ratio = image.imageHeight / image.imageWidth if image.imageWidth else 1
        if width:
            image.drawWidth = width
            image.drawHeight = width * aspect_ratio
        elif height:
            image.drawHeight = height
            image.drawWidth = height / aspect_ratio if aspect_ratio else height
        return image

    def _pdf_image_source(self, source: str) -> Any:
        if source.startswith("data:"):
            try:
                _, payload = source.split(",", 1)
            except ValueError as exc:
                raise RenderError("Data URI de imagem inválida para renderização em PDF.") from exc
            return BytesIO(base64.b64decode(payload))

        image_path = Path(source)
        if not image_path.exists():
            raise RenderError(f"Imagem não encontrada para renderização em PDF: {image_path}")
        return str(image_path)

    def _pdf_table_elements(
        self,
        block: RenderedTable,
        colors: Any,
        pdf_table_cls: Any,
        table_style_cls: Any,
        paragraph_cls: Any,
        mm: Any,
    ) -> list[Any]:
        base_header_style = self._paragraph_style(
            "HeaderCell",
            family="Helvetica-Bold",
            size_pt=10,
            align="left",
        )
        base_cell_style = self._paragraph_style(
            "BodyCell",
            family="Helvetica",
            size_pt=9,
            align="left",
        )
        base_group_style = self._paragraph_style(
            "GroupCell",
            family="Helvetica-Bold",
            size_pt=9,
            align="left",
        )

        table_data: list[list[Any]] = [[
            paragraph_cls(
                escape(column.label),
                self._column_style(base_header_style, column, header=True),
            )
            for column in block.columns
        ]]
        group_rows: list[int] = []

        for row in block.rows:
            if row.is_group:
                table_data.append(
                    [paragraph_cls(escape(row.group_label or ""), base_group_style)] + [""] * (len(block.columns) - 1)
                )
                group_rows.append(len(table_data) - 1)
                continue
            table_data.append(
                [
                    paragraph_cls(
                        escape(cell.display),
                        self._column_style(base_cell_style, block.columns[index], header=False),
                    )
                    for index, cell in enumerate(row.cells)
                ]
            )

        if len(table_data) == 1:
            table_data.append(
                [paragraph_cls("Nenhum dado encontrado.", base_group_style)] + [""] * (len(block.columns) - 1)
            )
            group_rows.append(1)

        col_widths = [
            column.width_mm * mm if column.width_mode == "mm" and column.width_mm is not None else None
            for column in block.columns
        ]
        pdf_table = pdf_table_cls(table_data, repeatRows=1, colWidths=col_widths)
        style_commands = [
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor(block.columns[0].header_background_color or "#f1e6d6")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.HexColor(block.columns[0].header_font.color or "#2c241b")),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor(block.border_color or "#d9ccb9")),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.HexColor(block.background_color or "#ffffff"), colors.HexColor(block.background_color or "#fcf8f1")]),
            ("LEFTPADDING", (0, 0), (-1, -1), 8),
            ("RIGHTPADDING", (0, 0), (-1, -1), 8),
            ("TOPPADDING", (0, 0), (-1, -1), 8),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ]

        for column_index, column in enumerate(block.columns):
            if column.header_background_color:
                style_commands.append(
                    ("BACKGROUND", (column_index, 0), (column_index, 0), colors.HexColor(column.header_background_color))
                )
            if column.header_border_color:
                style_commands.append(
                    ("BOX", (column_index, 0), (column_index, 0), 0.5, colors.HexColor(column.header_border_color))
                )
            if column.background_color:
                style_commands.append(
                    ("BACKGROUND", (column_index, 1), (column_index, -1), colors.HexColor(column.background_color))
                )
            if column.border_color:
                style_commands.append(
                    ("BOX", (column_index, 1), (column_index, -1), 0.5, colors.HexColor(column.border_color))
                )

        for row_index in group_rows:
            style_commands.extend(
                [
                    ("BACKGROUND", (0, row_index), (-1, row_index), colors.HexColor(block.background_color or "#fbf3e7")),
                    ("SPAN", (0, row_index), (-1, row_index)),
                ]
            )

        pdf_table.setStyle(table_style_cls(style_commands))
        return [pdf_table]

    def _build_pdf_code(
        self,
        block: RenderedCode,
        mm: Any,
        colors: Any,
        pdf_table_cls: Any,
        table_style_cls: Any,
    ) -> Any:
        from reportlab.graphics.barcode import createBarcodeDrawing
        from reportlab.graphics.barcode import qr as qr_barcode
        from reportlab.graphics.shapes import Drawing

        foreground = colors.HexColor(block.color or "#2c241b")
        width = (block.width_mm or 40) * mm
        height = (block.height_mm or 18) * mm

        if block.kind == "barcode":
            drawing = createBarcodeDrawing(
                "Code128",
                value=block.value,
                barHeight=height * 0.65,
                humanReadable=True,
                barFillColor=foreground,
            )
        else:
            widget = qr_barcode.QrCodeWidget(block.value)
            widget.barFillColor = foreground
            target_height = (block.height_mm or block.width_mm or 32) * mm
            widget.barWidth = width
            widget.barHeight = target_height
            drawing = Drawing(width, target_height)
            drawing.add(widget.draw())

        return self._box_flowable(drawing, block, pdf_table_cls, table_style_cls, colors)

    def _box_flowable(
        self,
        flowable: Any,
        block: Any,
        pdf_table_cls: Any,
        table_style_cls: Any,
        colors: Any,
    ) -> Any:
        if not getattr(block, "background_color", None) and not getattr(block, "border_color", None):
            return flowable

        wrapper = pdf_table_cls([[flowable]])
        wrapper.setStyle(
            table_style_cls(
                [
                    ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor(getattr(block, "background_color", None) or "#ffffff")),
                    ("BOX", (0, 0), (-1, -1), 0.8, colors.HexColor(getattr(block, "border_color", None) or "#d9ccb9")),
                    ("LEFTPADDING", (0, 0), (-1, -1), 6),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                    ("TOPPADDING", (0, 0), (-1, -1), 6),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                ]
            )
        )
        return wrapper

    def _pdf_subreport_elements(
        self,
        block: RenderedSubreport,
        *,
        colors: Any,
        pdf_table_cls: Any,
        table_style_cls: Any,
        paragraph_cls: Any,
        image_cls: Any,
        spacer_cls: Any,
        keep_together_cls: Any,
        page_break_cls: Any,
        mm: Any,
        title_style: Any,
        subtitle_style: Any,
    ) -> list[Any]:
        flowables: list[Any] = []
        report = block.report

        for header_block in report.header:
            if isinstance(header_block, RenderedImage):
                flowables.append(self._box_flowable(self._build_pdf_image(header_block, image_cls, mm), header_block, pdf_table_cls, table_style_cls, colors))
                flowables.append(spacer_cls(1, 8))
                continue
            if isinstance(header_block, RenderedCode):
                flowables.append(self._build_pdf_code(header_block, mm, colors, pdf_table_cls, table_style_cls))
                flowables.append(spacer_cls(1, 8))
                continue
            default_style = title_style if header_block.kind == "title" else subtitle_style
            flowables.append(
                self._box_flowable(
                    paragraph_cls(
                        escape(header_block.text),
                        self._text_style(default_style, header_block.font, header_block.align),
                    ),
                    header_block,
                    pdf_table_cls,
                    table_style_cls,
                    colors,
                )
            )
            flowables.append(spacer_cls(1, 6 if header_block.kind == "title" else 4))

        for body_block in report.body:
            if getattr(body_block, "page_break_before", False):
                flowables.append(page_break_cls())
            if isinstance(body_block, RenderedSubreport):
                nested = self._pdf_subreport_elements(
                    body_block,
                    colors=colors,
                    pdf_table_cls=pdf_table_cls,
                    table_style_cls=table_style_cls,
                    paragraph_cls=paragraph_cls,
                    image_cls=image_cls,
                    spacer_cls=spacer_cls,
                    keep_together_cls=keep_together_cls,
                    page_break_cls=page_break_cls,
                    mm=mm,
                    title_style=title_style,
                    subtitle_style=subtitle_style,
                )
                if body_block.keep_together and nested:
                    flowables.append(keep_together_cls(nested))
                    continue
                flowables.extend(nested)
                continue
            if isinstance(body_block, RenderedDetail):
                flowables.extend(
                    self._pdf_detail_elements(
                        body_block,
                        paragraph_cls=paragraph_cls,
                        image_cls=image_cls,
                        spacer_cls=spacer_cls,
                        keep_together_cls=keep_together_cls,
                        colors=colors,
                        pdf_table_cls=pdf_table_cls,
                        table_style_cls=table_style_cls,
                        mm=mm,
                        subtitle_style=subtitle_style,
                    )
                )
                continue
            nested_body = self._pdf_body_flowables(
                body_block,
                colors=colors,
                pdf_table_cls=pdf_table_cls,
                table_style_cls=table_style_cls,
                paragraph_cls=paragraph_cls,
                image_cls=image_cls,
                spacer_cls=spacer_cls,
                mm=mm,
                subtitle_style=subtitle_style,
            )
            if getattr(body_block, "keep_together", False) and nested_body:
                flowables.append(keep_together_cls(nested_body))
                continue
            flowables.extend(nested_body)

        for footer_block in report.footer:
            if isinstance(footer_block, RenderedText):
                flowables.append(
                    self._box_flowable(
                        paragraph_cls(
                            escape(footer_block.text),
                            self._text_style(subtitle_style, footer_block.font, footer_block.align),
                        ),
                        footer_block,
                        pdf_table_cls,
                        table_style_cls,
                        colors,
                    )
                )
                continue
            if isinstance(footer_block, RenderedImage):
                flowables.append(self._box_flowable(self._build_pdf_image(footer_block, image_cls, mm), footer_block, pdf_table_cls, table_style_cls, colors))
                continue
            if isinstance(footer_block, RenderedCode):
                flowables.append(self._build_pdf_code(footer_block, mm, colors, pdf_table_cls, table_style_cls))
                continue
            total_table = pdf_table_cls([[footer_block.label, footer_block.display]], colWidths=[320, 140])
            total_table.setStyle(
                table_style_cls(
                    [
                        ("TEXTCOLOR", (0, 0), (-1, -1), colors.HexColor("#2c241b")),
                        ("FONTNAME", (0, 0), (0, 0), "Helvetica"),
                        ("FONTNAME", (1, 0), (1, 0), "Helvetica-Bold"),
                        ("ALIGN", (1, 0), (1, 0), "RIGHT"),
                        ("LINEBELOW", (0, 0), (-1, -1), 0.5, colors.HexColor("#d9ccb9")),
                        ("TOPPADDING", (0, 0), (-1, -1), 6),
                        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                    ]
                )
            )
            flowables.append(total_table)

        flowables.append(spacer_cls(1, 12))
        return flowables

    def _pdf_body_flowables(
        self,
        block: RenderedText | RenderedImage | RenderedCode | RenderedTable,
        *,
        colors: Any,
        pdf_table_cls: Any,
        table_style_cls: Any,
        paragraph_cls: Any,
        image_cls: Any,
        spacer_cls: Any,
        mm: Any,
        subtitle_style: Any,
    ) -> list[Any]:
        flowables: list[Any] = []
        if isinstance(block, RenderedText):
            paragraph = paragraph_cls(
                escape(block.text),
                self._text_style(subtitle_style, block.font, block.align),
            )
            flowables.append(self._box_flowable(paragraph, block, pdf_table_cls, table_style_cls, colors))
            flowables.append(spacer_cls(1, 8))
            return flowables

        if isinstance(block, RenderedImage):
            flowables.append(self._box_flowable(self._build_pdf_image(block, image_cls, mm), block, pdf_table_cls, table_style_cls, colors))
            flowables.append(spacer_cls(1, 10))
            return flowables

        if isinstance(block, RenderedCode):
            flowables.append(self._build_pdf_code(block, mm, colors, pdf_table_cls, table_style_cls))
            flowables.append(spacer_cls(1, 10))
            return flowables

        if block.title:
            title_text = self._apply_text_transform(block.title, block.title_font.transform)
            flowables.append(
                self._box_flowable(
                    paragraph_cls(
                        f"<b>{escape(title_text)}</b>",
                        self._text_style(subtitle_style, block.title_font, block.title_align),
                    ),
                    block,
                    pdf_table_cls,
                    table_style_cls,
                    colors,
                )
            )
            flowables.append(spacer_cls(1, 6))
        flowables.extend(
            self._pdf_table_elements(block, colors, pdf_table_cls, table_style_cls, paragraph_cls, mm)
        )
        flowables.append(spacer_cls(1, 12))
        return flowables

    def _pdf_detail_elements(
        self,
        detail: RenderedDetail,
        *,
        paragraph_cls: Any,
        image_cls: Any,
        spacer_cls: Any,
        keep_together_cls: Any,
        colors: Any,
        pdf_table_cls: Any,
        table_style_cls: Any,
        mm: Any,
        subtitle_style: Any,
    ) -> list[Any]:
        flowables: list[Any] = []
        for row in detail.rows:
            row_flowables: list[Any] = []
            for block in row.blocks:
                if isinstance(block, RenderedText):
                    default_style = subtitle_style
                    if block.kind == "title":
                        default_style = self._paragraph_style(
                            "DetailTitle",
                            family="Helvetica-Bold",
                            size_pt=max(subtitle_style.fontSize + 2, 11),
                            align=block.align or "left",
                        )
                    row_flowables.append(
                        self._box_flowable(
                            paragraph_cls(
                                escape(block.text),
                                self._text_style(default_style, block.font, block.align),
                            ),
                            block,
                            pdf_table_cls,
                            table_style_cls,
                            colors,
                        )
                    )
                    row_flowables.append(spacer_cls(1, 4))
                    continue
                if isinstance(block, RenderedCode):
                    row_flowables.append(
                        self._build_pdf_code(
                            block,
                            mm,
                            colors,
                            pdf_table_cls,
                            table_style_cls,
                        )
                    )
                    row_flowables.append(spacer_cls(1, 6))
                    continue
                row_flowables.append(
                    self._box_flowable(
                        self._build_pdf_image(block, image_cls, mm),
                        block,
                        pdf_table_cls,
                        table_style_cls,
                        colors,
                    )
                )
                row_flowables.append(spacer_cls(1, 6))
            if row_flowables and isinstance(row_flowables[-1], spacer_cls):
                row_flowables.pop()
            if not row_flowables:
                continue
            row_flowables.append(spacer_cls(1, 10))
            if detail.keep_together:
                flowables.append(keep_together_cls(row_flowables))
                continue
            flowables.extend(row_flowables)
        return flowables

    def _text_style(self, default_style: Any, font: FontStyle, align: str) -> Any:
        return self._paragraph_style(
            "Text",
            family=font.family or default_style.fontName,
            size_pt=font.size_pt or default_style.fontSize,
            align=align or self._reportlab_align_name(default_style.alignment),
            color=font.color,
        )

    def _column_style(self, default_style: Any, column: RenderedColumn, header: bool) -> Any:
        font = column.header_font if header else column.font
        align = column.header_align if header else column.align
        return self._paragraph_style(
            "Column",
            family=font.family or default_style.fontName,
            size_pt=font.size_pt or default_style.fontSize,
            align=align or "left",
            color=font.color,
        )

    def _paragraph_style(self, name: str, *, family: str, size_pt: float, align: str, color: str | None = None) -> Any:
        from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT, TA_RIGHT
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.colors import HexColor

        return ParagraphStyle(
            name,
            fontName=self._pdf_font_name(family),
            fontSize=size_pt,
            leading=max(size_pt * 1.25, size_pt + 2),
            textColor=HexColor(color or "#2c241b"),
            alignment={
                "left": TA_LEFT,
                "center": TA_CENTER,
                "right": TA_RIGHT,
                "justify": TA_JUSTIFY,
            }.get(align, TA_LEFT),
        )

    def _pdf_font_name(self, family: str | None) -> str:
        if not family:
            return "Helvetica"
        normalized = family.strip().lower()
        if normalized in {
            "helvetica",
            "helvetica-bold",
            "helvetica-oblique",
            "helvetica-boldoblique",
            "times-roman",
            "times-bold",
            "times-italic",
            "times-bolditalic",
            "courier",
            "courier-bold",
            "courier-oblique",
            "courier-boldoblique",
        }:
            return family
        if "bold" in normalized and ("helvetica" in normalized or "sans" in normalized):
            return "Helvetica-Bold"
        if "italic" in normalized or "oblique" in normalized:
            if "times" in normalized:
                return "Times-Italic"
            if "courier" in normalized or "mono" in normalized:
                return "Courier-Oblique"
            return "Helvetica-Oblique"
        if "courier" in normalized or "mono" in normalized:
            return "Courier"
        if normalized in {"georgia", "times", "times new roman", "serif"} or "times" in normalized:
            return "Times-Roman"
        return "Helvetica"

    def _reportlab_align_name(self, value: int) -> str:
        mapping = {0: "left", 1: "center", 2: "right", 4: "justify"}
        return mapping.get(value, "left")

    def _build_page_decorator(
        self,
        *,
        rendered: Any,
        content_width: float,
        physical_left: float,
        physical_top: float,
        physical_bottom: float,
        page_height: float,
        reserved_footer_height: float,
        image_cls: Any,
        paragraph_cls: Any,
        mm: Any,
        title_style: Any,
        subtitle_style: Any,
    ) -> Any:
        def decorator(canvas_obj: Any, page_number: int, total_pages: int) -> None:
            canvas_obj.saveState()
            if rendered.page_header:
                self._draw_page_band(
                    canvas_obj,
                    rendered.page_header,
                    x=physical_left,
                    top_y=page_height - physical_top,
                    width=content_width,
                    image_cls=image_cls,
                    paragraph_cls=paragraph_cls,
                    mm=mm,
                    title_style=title_style,
                    subtitle_style=subtitle_style,
                )

            footer_blocks = rendered.last_page_footer if page_number == total_pages and rendered.last_page_footer else rendered.page_footer
            if footer_blocks:
                self._draw_page_band(
                    canvas_obj,
                    footer_blocks,
                    x=physical_left,
                    top_y=physical_bottom + reserved_footer_height,
                    width=content_width,
                    image_cls=image_cls,
                    paragraph_cls=paragraph_cls,
                    mm=mm,
                    title_style=title_style,
                    subtitle_style=subtitle_style,
                )
            canvas_obj.restoreState()

        return decorator

    def _measure_page_band(
        self,
        blocks: list[Any],
        *,
        width: float,
        image_cls: Any,
        paragraph_cls: Any,
        mm: Any,
        title_style: Any,
        subtitle_style: Any,
    ) -> float:
        height = 0.0
        for flowable in self._page_band_flowables(
            blocks,
            image_cls=image_cls,
            paragraph_cls=paragraph_cls,
            mm=mm,
            title_style=title_style,
            subtitle_style=subtitle_style,
        ):
            _, flowable_height = flowable.wrap(width, 10000)
            height += flowable_height
        return height

    def _draw_page_band(
        self,
        canvas_obj: Any,
        blocks: list[Any],
        *,
        x: float,
        top_y: float,
        width: float,
        image_cls: Any,
        paragraph_cls: Any,
        mm: Any,
        title_style: Any,
        subtitle_style: Any,
    ) -> None:
        current_y = top_y
        for flowable in self._page_band_flowables(
            blocks,
            image_cls=image_cls,
            paragraph_cls=paragraph_cls,
            mm=mm,
            title_style=title_style,
            subtitle_style=subtitle_style,
        ):
            _, flowable_height = flowable.wrap(width, 10000)
            current_y -= flowable_height
            flowable.drawOn(canvas_obj, x, current_y)

    def _page_band_flowables(
        self,
        blocks: list[Any],
        *,
        image_cls: Any,
        paragraph_cls: Any,
        mm: Any,
        title_style: Any,
        subtitle_style: Any,
    ) -> list[Any]:
        from reportlab.platypus import Spacer
        from reportlab.platypus import Table as PDFTable, TableStyle
        from reportlab.lib import colors

        flowables: list[Any] = []
        for index, block in enumerate(blocks):
            if isinstance(block, RenderedImage):
                flowables.append(
                    self._box_flowable(
                        self._build_pdf_image(block, image_cls, mm),
                        block,
                        PDFTable,
                        TableStyle,
                        colors,
                    )
                )
            elif isinstance(block, RenderedCode):
                flowables.append(self._build_pdf_code(block, mm, colors, PDFTable, TableStyle))
            else:
                default_style = title_style if block.kind == "title" else subtitle_style
                flowables.append(
                    self._box_flowable(
                        paragraph_cls(
                            escape(block.text),
                            self._text_style(default_style, block.font, block.align),
                        ),
                        block,
                        PDFTable,
                        TableStyle,
                        colors,
                    )
                )
            if index < len(blocks) - 1:
                flowables.append(Spacer(1, 4))
        return flowables
