from __future__ import annotations

from html import escape
from pathlib import Path
from typing import Any

from ..models import FontStyle
from ..models import ReportDefinition
from .base import BaseRenderer, RenderedBodyBlock, RenderedCode, RenderedColumn, RenderedDetail, RenderedFooterBlock, RenderedHeaderBlock, RenderedImage, RenderedSubreport, RenderedTable, RenderedText


class HTMLRenderer(BaseRenderer):
    output_type = "html"

    def render(self, report: ReportDefinition, data: Any, parameters: dict[str, Any] | None = None) -> str:
        rendered = self.build_rendered_report(report, data, parameters=parameters)
        header_html = self._render_header_html(rendered.header)
        body_html = self._render_body_html(rendered.body)
        footer_html = self._render_footer_html(rendered.footer)
        return self._build_document(rendered.name, rendered.margins, header_html, body_html, footer_html)

    def _render_header_html(self, blocks: list[RenderedHeaderBlock]) -> str:
        parts: list[str] = []
        for block in blocks:
            if isinstance(block, RenderedText):
                parts.append(
                    f'<div class="report-{block.kind}"{self._style_attr(font=block.font, align=block.align, background_color=block.background_color, border_color=block.border_color)}>'
                    f"{escape(block.text)}</div>"
                )
                continue
            if isinstance(block, RenderedCode):
                parts.append(self._render_code_html(block))
                continue
            parts.append(self._render_image_html(block))
        return "\n".join(parts)

    def _render_body_html(self, blocks: list[RenderedBodyBlock]) -> str:
        parts: list[str] = []
        for block in blocks:
            if isinstance(block, RenderedText):
                parts.append(
                    f'<div class="report-text"{self._style_attr(font=block.font, align=block.align, background_color=block.background_color, border_color=block.border_color)}>'
                    f"{escape(block.text)}</div>"
                )
                continue
            if isinstance(block, RenderedImage):
                parts.append(self._render_image_html(block))
                continue
            if isinstance(block, RenderedCode):
                parts.append(self._render_code_html(block))
                continue
            if isinstance(block, RenderedSubreport):
                parts.append(self._render_subreport_html(block))
                continue
            if isinstance(block, RenderedDetail):
                parts.append(self._render_detail_html(block))
                continue
            parts.append(self._render_table_html(block))
        return "\n".join(parts)

    def _render_footer_html(self, blocks: list[RenderedFooterBlock]) -> str:
        parts: list[str] = []
        for block in blocks:
            if isinstance(block, RenderedText):
                parts.append(
                    f'<div class="report-footer-text"{self._style_attr(font=block.font, align=block.align, background_color=block.background_color, border_color=block.border_color)}>'
                    f"{escape(block.text)}</div>"
                )
                continue
            if isinstance(block, RenderedImage):
                parts.append(self._render_image_html(block))
                continue
            if isinstance(block, RenderedCode):
                parts.append(self._render_code_html(block))
                continue
            parts.append(
                f'<div class="report-total"{self._style_attr(font=block.font, background_color=block.background_color, border_color=block.border_color)}>'
                f'<span class="report-total-label">{escape(block.label)}</span>'
                f'<strong class="report-total-value">{escape(block.display)}</strong>'
                "</div>"
            )
        return "\n".join(parts)

    def _render_image_html(self, image: RenderedImage) -> str:
        source = self._normalize_image_source(image.src)
        alt = escape(image.alt or "Imagem do relatório")
        styles = []
        if image.width_mm is not None:
            styles.append(f"width:{image.width_mm}mm")
        if image.height_mm is not None:
            styles.append(f"height:{image.height_mm}mm")
        if image.background_color:
            styles.append(f"background-color:{image.background_color}")
        if image.border_color:
            styles.append(f"border:1px solid {image.border_color}")
            styles.append("padding:4px")
            styles.append("border-radius:10px")
        style_attr = f' style="{";".join(styles)}"' if styles else ""
        return (
            '<div class="report-image-wrap">'
            f'<img class="report-image" src="{escape(source)}" alt="{alt}"{style_attr}>'
            "</div>"
        )

    def _normalize_image_source(self, source: str) -> str:
        if source.startswith("data:"):
            return source
        path = Path(source)
        if path.is_absolute():
            return path.as_uri()
        return source

    def _render_table_html(self, table: RenderedTable) -> str:
        header_cells = "".join(
            f"<th{self._cell_style_attr(column, header=True)}>{escape(column.label)}</th>"
            for column in table.columns
        )
        colspan = len(table.columns)
        body_rows: list[str] = []

        for row in table.rows:
            if row.is_group:
                body_rows.append(
                    f'<tr class="group-row"><td colspan="{colspan}">{escape(row.group_label or "")}</td></tr>'
                )
                continue
            cells = "".join(
                f"<td{self._cell_style_attr(table.columns[index])}>{escape(cell.display)}</td>"
                for index, cell in enumerate(row.cells)
            )
            body_rows.append(f"<tr>{cells}</tr>")

        if not body_rows:
            body_rows.append(
                f'<tr class="empty-row"><td colspan="{colspan}">Nenhum dado encontrado.</td></tr>'
            )

        caption = (
            f"<caption{self._style_attr(font=table.title_font, align=table.title_align)}>"
            f"{escape(self._apply_text_transform(table.title, table.title_font.transform))}</caption>"
            if table.title
            else ""
        )
        colgroup = self._render_colgroup(table.columns)
        table_class = "report-table report-table-fixed" if any(
            column.width_mode == "mm" for column in table.columns
        ) else "report-table"
        return (
            f'<table class="{table_class}"{self._table_style_attr(table)}>'
            f"{caption}"
            f"{colgroup}"
            f"<thead><tr>{header_cells}</tr></thead>"
            f"<tbody>{''.join(body_rows)}</tbody>"
            "</table>"
        )

    def _render_detail_html(self, detail: RenderedDetail) -> str:
        rows: list[str] = []
        for row in detail.rows:
            blocks: list[str] = []
            for block in row.blocks:
                if isinstance(block, RenderedText):
                    css_class = (
                        "report-detail-title"
                        if block.kind == "title"
                        else "report-detail-subtitle"
                        if block.kind == "subtitle"
                        else "report-detail-text"
                    )
                    blocks.append(
                        f'<div class="{css_class}"{self._style_attr(font=block.font, align=block.align)}>'
                        f"{escape(block.text)}</div>"
                    )
                    continue
                if isinstance(block, RenderedCode):
                    blocks.append(self._render_code_html(block))
                    continue
                blocks.append(self._render_image_html(block))
            rows.append(f'<section class="report-detail-row">{"".join(blocks)}</section>')
        return f'<div class="report-detail">{"".join(rows)}</div>'

    def _render_subreport_html(self, subreport: RenderedSubreport) -> str:
        report = subreport.report
        header_html = self._render_header_html(report.header)
        body_html = self._render_body_html(report.body)
        footer_html = self._render_footer_html(report.footer)
        return (
            '<section class="report-subreport">'
            f'<div class="report-subreport-header">{header_html}</div>'
            f'<div class="report-subreport-body">{body_html}</div>'
            f'<div class="report-subreport-footer">{footer_html}</div>'
            "</section>"
        )

    def _render_colgroup(self, columns: list[RenderedColumn]) -> str:
        parts = []
        for column in columns:
            if column.width_mode == "mm" and column.width_mm is not None:
                parts.append(f'<col style="width:{column.width_mm}mm">')
                continue
            parts.append("<col>")
        return f"<colgroup>{''.join(parts)}</colgroup>"

    def _cell_style_attr(self, column: RenderedColumn, header: bool = False) -> str:
        font = column.header_font if header else column.font
        align = column.header_align if header else column.align
        wrap = column.width_mode == "mm"
        return self._style_attr(
            font=font,
            align=align,
            wrap=wrap,
            background_color=column.header_background_color if header else column.background_color,
            border_color=column.header_border_color if header else column.border_color,
        )

    def _table_style_attr(self, table: RenderedTable) -> str:
        return self._style_attr(
            background_color=table.background_color,
            border_color=table.border_color,
        )

    def _render_code_html(self, code: RenderedCode) -> str:
        svg = self._code_svg(code)
        style = self._style_attr(
            background_color=code.background_color,
            border_color=code.border_color,
        )
        return f'<div class="report-code"{style}>{svg}</div>'

    def _style_attr(
        self,
        *,
        font: FontStyle | None = None,
        align: str | None = None,
        wrap: bool = False,
        background_color: str | None = None,
        border_color: str | None = None,
    ) -> str:
        styles: list[str] = []
        if font and font.family:
            styles.append(f"font-family:{font.family}")
        if font and font.size_pt is not None:
            styles.append(f"font-size:{font.size_pt}pt")
            styles.append(f"line-height:{max(font.size_pt * 1.25, 12):.2f}pt")
        if font and font.transform:
            styles.append(f"text-transform:{font.transform}")
        if font and font.color:
            styles.append(f"color:{font.color}")
        if align:
            styles.append(f"text-align:{align}")
        if background_color:
            styles.append(f"background-color:{background_color}")
        if border_color:
            styles.append(f"border:1px solid {border_color}")
            styles.append("border-radius:10px")
            styles.append("padding:8px 10px")
        if wrap:
            styles.append("white-space:normal")
            styles.append("overflow-wrap:anywhere")
            styles.append("word-break:break-word")
        if not styles:
            return ""
        return f' style="{";".join(styles)}"'

    def _code_svg(self, code: RenderedCode) -> str:
        from reportlab.graphics import renderSVG
        from reportlab.graphics.barcode import createBarcodeDrawing
        from reportlab.graphics.barcode import qr as qr_barcode
        from reportlab.graphics.shapes import Drawing
        from reportlab.lib import colors
        from reportlab.lib.units import mm

        foreground = colors.HexColor(code.color or "#2C241B")
        background = colors.HexColor(code.background_color or "#FFFFFF")
        width = (code.width_mm or 40) * mm
        height = (code.height_mm or 18) * mm

        if code.kind == "barcode":
            drawing = createBarcodeDrawing(
                "Code128",
                value=code.value,
                barHeight=height * 0.65,
                humanReadable=True,
                barFillColor=foreground,
            )
        else:
            widget = qr_barcode.QrCodeWidget(code.value)
            widget.barFillColor = foreground
            widget.barWidth = width
            widget.barHeight = (code.height_mm or code.width_mm or 32) * mm
            drawing = Drawing(widget.barWidth, widget.barHeight)
            drawing.add(widget.draw())

        svg = renderSVG.drawToString(drawing)
        return svg.decode("utf-8") if isinstance(svg, bytes) else svg

    def _build_document(self, title: str, margins: Any, header_html: str, body_html: str, footer_html: str) -> str:
        return f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{escape(title)}</title>
  <style>
    :root {{
      color-scheme: light;
      --page-bg: #f4f1ea;
      --panel-bg: #fffdfa;
      --ink: #2c241b;
      --muted: #776959;
      --accent: #8a5a2b;
      --line: #d9ccb9;
      --header-bg: #f1e6d6;
      --group-bg: #fbf3e7;
    }}

    * {{
      box-sizing: border-box;
    }}

    body {{
      margin: 0;
      padding: {margins.top_mm}mm {margins.right_mm}mm {margins.bottom_mm}mm {margins.left_mm}mm;
      background:
        radial-gradient(circle at top left, rgba(138, 90, 43, 0.12), transparent 32%),
        linear-gradient(180deg, #f8f5ef 0%, var(--page-bg) 100%);
      color: var(--ink);
      font-family: "Georgia", "Times New Roman", serif;
    }}

    .report {{
      max-width: 980px;
      margin: 0 auto;
      background: var(--panel-bg);
      border: 1px solid var(--line);
      border-radius: 18px;
      box-shadow: 0 18px 45px rgba(77, 53, 29, 0.08);
      overflow: hidden;
    }}

    .report-header,
    .report-body,
    .report-footer {{
      padding: 28px 32px;
    }}

    .report-header {{
      background: linear-gradient(135deg, var(--header-bg), #fff5e8);
      border-bottom: 1px solid var(--line);
    }}

    .report-title {{
      font-size: 2rem;
      font-weight: 700;
      letter-spacing: 0.02em;
    }}

    .report-subtitle,
    .report-text,
    .report-footer-text {{
      margin-top: 8px;
      color: var(--muted);
      font-size: 1rem;
    }}

    .report-image-wrap {{
      margin-bottom: 12px;
    }}

    .report-image {{
      display: block;
      max-width: 100%;
      height: auto;
    }}

    .report-table {{
      width: 100%;
      border-collapse: collapse;
      margin-top: 8px;
      overflow: hidden;
      border-radius: 12px;
    }}

    .report-detail {{
      display: grid;
      gap: 14px;
      margin-top: 12px;
    }}

    .report-subreport {{
      margin-top: 18px;
      border: 1px solid var(--line);
      border-radius: 16px;
      background: linear-gradient(180deg, #fffdfa, #fff7ec);
      overflow: hidden;
    }}

    .report-subreport-header,
    .report-subreport-body,
    .report-subreport-footer {{
      padding: 18px 20px;
    }}

    .report-subreport-header {{
      border-bottom: 1px solid var(--line);
      background: #fbf3e7;
    }}

    .report-subreport-footer {{
      border-top: 1px solid var(--line);
      background: #fdf8f0;
    }}

    .report-detail-row {{
      padding: 14px 16px;
      border: 1px solid var(--line);
      border-radius: 12px;
      background: #fffaf2;
    }}

    .report-detail-title,
    .report-detail-subtitle,
    .report-detail-text {{
      color: var(--ink);
    }}

    .report-detail-subtitle,
    .report-detail-text {{
      margin-top: 6px;
    }}

    .report-table-fixed {{
      table-layout: fixed;
    }}

    .report-table caption {{
      caption-side: top;
      padding-bottom: 12px;
      text-align: left;
      font-weight: 700;
      color: var(--accent);
    }}

    .report-table th,
    .report-table td {{
      padding: 14px 16px;
      border-bottom: 1px solid var(--line);
    }}

    .report-table th {{
      letter-spacing: 0.04em;
      font-size: 0.88rem;
      background: #fcf8f1;
      color: var(--muted);
      text-align: left;
    }}

    .report-table tbody tr:nth-child(even) {{
      background: rgba(241, 230, 214, 0.28);
    }}

    .report-table .group-row td {{
      background: var(--group-bg);
      color: var(--accent);
      font-weight: 700;
    }}

    .report-table .empty-row td {{
      text-align: center;
      color: var(--muted);
      font-style: italic;
    }}

    .report-footer {{
      border-top: 1px solid var(--line);
      background: #fff9f1;
    }}

    .report-total {{
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 16px;
      padding: 12px 0;
      border-bottom: 1px dashed var(--line);
    }}

    .report-total:last-child {{
      border-bottom: 0;
    }}

    .report-total-label {{
      color: var(--muted);
      font-size: 0.95rem;
    }}

    .report-total-value {{
      font-size: 1.1rem;
      color: var(--ink);
    }}

    @media (max-width: 720px) {{
      body {{
        padding: 16px;
      }}

      .report-header,
      .report-body,
      .report-footer {{
        padding: 20px;
      }}

      .report-title {{
        font-size: 1.55rem;
      }}

      .report-table th,
      .report-table td {{
        padding: 10px 12px;
        font-size: 0.92rem;
      }}
    }}
  </style>
</head>
<body>
  <main class="report">
    <header class="report-header">{header_html}</header>
    <section class="report-body">{body_html}</section>
    <footer class="report-footer">{footer_html}</footer>
  </main>
</body>
</html>
"""
