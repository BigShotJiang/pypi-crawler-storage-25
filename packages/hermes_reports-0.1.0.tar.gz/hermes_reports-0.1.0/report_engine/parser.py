from __future__ import annotations

from pathlib import Path
import re
import xml.etree.ElementTree as ET

from .aggregators import has_aggregation
from .formatters import has_formatter
from .models import Body, CodeElement, Column, DetailBand, FontStyle, Footer, Header, ImageElement, PageBand, PageMargins, ParameterDefinition, ReportDefinition, StyleDefinition, Subreport, Table, TextElement, Total, VariableDefinition


class TemplateValidationError(ValueError):
    """Raised when the XML template is invalid."""


VALID_ALIGNMENTS = {"left", "center", "right", "justify"}
VALID_TEXT_TRANSFORMS = {"uppercase", "lowercase", "capitalize", "none"}
VALID_BARCODE_SYMBOLOGIES = {"code128"}
HEX_COLOR_RE = re.compile(r"^#[0-9A-Fa-f]{6}$")


def parse_template(template_path: str | Path, _visited: set[Path] | None = None) -> ReportDefinition:
    path = Path(template_path).resolve()
    visited = set(_visited or ())
    if path in visited:
        raise TemplateValidationError(f"Referência circular de subreport detectada em: {path}")
    visited.add(path)

    try:
        root = ET.parse(path).getroot()
    except ET.ParseError as exc:
        raise TemplateValidationError(f"XML inválido em {path}: {exc}") from exc

    if root.tag != "report":
        raise TemplateValidationError("O elemento raiz deve ser <report>.")

    name = root.attrib.get("name")
    if not name:
        raise TemplateValidationError("O atributo 'name' é obrigatório em <report>.")

    _validate_root_structure(root)
    styles = _parse_styles(root.find("styles"))
    return ReportDefinition(
        name=name,
        margins=_parse_margins(root),
        styles=styles,
        parameters=_parse_parameter_definitions(root.find("parameters"), "<parameters>"),
        variables=_parse_variables(root.find("variables")),
        header=_parse_header(root.find("header"), path.parent, styles),
        page_header=_parse_page_band(root.find("page_header"), path.parent, styles),
        body=_parse_body(root.find("body"), path.parent, styles, visited),
        footer=_parse_footer(root.find("footer"), path.parent, styles),
        page_footer=_parse_page_band(root.find("page_footer"), path.parent, styles),
        last_page_footer=_parse_page_band(root.find("last_page_footer"), path.parent, styles),
    )


def _parse_header(
    element: ET.Element | None,
    template_dir: Path,
    styles: dict[str, StyleDefinition],
) -> Header:
    if element is None:
        return Header()
    header = Header()
    for child in element:
        if child.tag == "image":
            header.elements.append(_parse_image_element(child, template_dir))
            continue
        if child.tag in {"barcode", "qrcode"}:
            header.elements.append(_parse_code_element(child))
            continue
        if child.tag not in {"title", "subtitle", "text"}:
            raise TemplateValidationError(f"Elemento não suportado em <header>: <{child.tag}>.")
        header.elements.append(_parse_text_element(child, styles))
    return header


def _parse_body(
    element: ET.Element | None,
    template_dir: Path,
    styles: dict[str, StyleDefinition],
    visited: set[Path],
) -> Body:
    if element is None:
        return Body()
    body = Body()
    for child in element:
        if child.tag == "table":
            body.elements.append(_parse_table(child, styles))
            continue
        if child.tag == "detail":
            body.elements.append(_parse_detail_band(child, template_dir, styles))
            continue
        if child.tag == "subreport":
            body.elements.append(_parse_subreport(child, template_dir, visited))
            continue
        if child.tag == "image":
            body.elements.append(_parse_image_element(child, template_dir))
            continue
        if child.tag in {"barcode", "qrcode"}:
            body.elements.append(_parse_code_element(child))
            continue
        if child.tag == "text":
            body.elements.append(_parse_text_element(child, styles))
            continue
        raise TemplateValidationError(f"Elemento não suportado em <body>: <{child.tag}>.")
    return body


def _parse_detail_band(
    element: ET.Element,
    template_dir: Path,
    styles: dict[str, StyleDefinition],
) -> DetailBand:
    data_source = element.attrib.get("data")
    if not data_source:
        raise TemplateValidationError("Todo <detail> deve definir o atributo 'data'.")

    detail = DetailBand(
        data_source=data_source,
        visible_if=element.attrib.get("visible_if"),
        page_break_before=_parse_bool_attribute(element, "page_break_before", default=False),
        keep_together=_parse_bool_attribute(element, "keep_together", default=False),
    )

    for child in element:
        if child.tag == "image":
            detail.elements.append(_parse_image_element(child, template_dir))
            continue
        if child.tag in {"barcode", "qrcode"}:
            detail.elements.append(_parse_code_element(child))
            continue
        if child.tag not in {"title", "subtitle", "text"}:
            raise TemplateValidationError(f"Elemento não suportado em <detail>: <{child.tag}>.")
        detail.elements.append(_parse_text_element(child, styles))

    if not detail.elements:
        raise TemplateValidationError("Todo <detail> deve possuir ao menos um elemento filho.")
    return detail


def _parse_subreport(
    element: ET.Element,
    template_dir: Path,
    visited: set[Path],
) -> Subreport:
    template_name = element.attrib.get("template")
    if not template_name:
        raise TemplateValidationError("Todo <subreport> deve definir o atributo 'template'.")

    subreport_path = (template_dir / template_name).resolve()
    if not subreport_path.exists():
        raise TemplateValidationError(f"Template de subreport não encontrado: {subreport_path}")
    parameters_element = element.find("parameters")
    if parameters_element is not None and any(child.tag != "parameter" for child in parameters_element):
        raise TemplateValidationError("O elemento <parameters> dentro de <subreport> aceita apenas <parameter>.")

    return Subreport(
        report=parse_template(subreport_path, visited),
        data_source=element.attrib.get("data"),
        parameters=_parse_parameter_definitions(parameters_element, "<subreport>/<parameters>"),
        visible_if=element.attrib.get("visible_if"),
        page_break_before=_parse_bool_attribute(element, "page_break_before", default=False),
        keep_together=_parse_bool_attribute(element, "keep_together", default=False),
    )


def _parse_footer(
    element: ET.Element | None,
    template_dir: Path,
    styles: dict[str, StyleDefinition],
) -> Footer:
    if element is None:
        return Footer()
    footer = Footer()
    for child in element:
        if child.tag == "total":
            footer.elements.append(_parse_total(child))
            continue
        if child.tag == "image":
            footer.elements.append(_parse_image_element(child, template_dir))
            continue
        if child.tag in {"barcode", "qrcode"}:
            footer.elements.append(_parse_code_element(child))
            continue
        if child.tag == "text":
            footer.elements.append(_parse_text_element(child, styles))
            continue
        raise TemplateValidationError(f"Elemento não suportado em <footer>: <{child.tag}>.")
    return footer


def _parse_page_band(
    element: ET.Element | None,
    template_dir: Path,
    styles: dict[str, StyleDefinition],
) -> PageBand:
    if element is None:
        return PageBand()
    band = PageBand()
    for child in element:
        if child.tag == "image":
            band.elements.append(_parse_image_element(child, template_dir))
            continue
        if child.tag in {"barcode", "qrcode"}:
            band.elements.append(_parse_code_element(child))
            continue
        if child.tag not in {"title", "subtitle", "text"}:
            raise TemplateValidationError(f"Elemento não suportado em <{element.tag}>: <{child.tag}>.")
        band.elements.append(_parse_text_element(child, styles))
    return band


def _parse_text_element(element: ET.Element, styles: dict[str, StyleDefinition]) -> TextElement:
    field = element.attrib.get("field")
    expression = element.attrib.get("expression")
    value = element.attrib.get("value") or _clean_text(element.text)

    if not any((field, expression, value)):
        raise TemplateValidationError(
            f"O elemento <{element.tag}> deve definir 'field', 'expression' ou 'value'."
        )

    formatter = element.attrib.get("format")
    if formatter and not has_formatter(formatter):
        raise TemplateValidationError(f"Formatter desconhecido: {formatter}")

    style = _resolve_style(styles, element.attrib.get("style"), f"<{element.tag}>")
    explicit_font = _parse_font_style(element)

    return TextElement(
        kind=element.tag,
        field=field,
        expression=expression,
        value=value,
        formatter=formatter,
        visible_if=element.attrib.get("visible_if"),
        label=element.attrib.get("label"),
        align=_parse_alignment(element.attrib.get("align"), f"<{element.tag}>") or style.align,
        page_break_before=_parse_bool_attribute(element, "page_break_before", default=False),
        keep_together=_parse_bool_attribute(element, "keep_together", default=False),
        background_color=_parse_hex_color_attribute(element, "background_color") or style.background_color,
        border_color=_parse_hex_color_attribute(element, "border_color") or style.border_color,
        font=_merge_font_style(style.font, explicit_font),
    )


def _parse_table(element: ET.Element, styles: dict[str, StyleDefinition]) -> Table:
    columns_element = element.find("columns")
    if columns_element is None:
        raise TemplateValidationError("Todo <table> deve possuir um elemento <columns>.")

    columns = [_parse_column(column, styles) for column in columns_element.findall("column")]
    if not columns:
        raise TemplateValidationError("Todo <table> deve possuir ao menos um <column>.")

    style = _resolve_style(styles, element.attrib.get("style"), "<table>")

    return Table(
        columns=columns,
        data_source=element.attrib.get("data"),
        title=element.attrib.get("title"),
        group_by=element.attrib.get("group_by"),
        visible_if=element.attrib.get("visible_if"),
        page_break_before=_parse_bool_attribute(element, "page_break_before", default=False),
        keep_together=_parse_bool_attribute(element, "keep_together", default=False),
        background_color=_parse_hex_color_attribute(element, "background_color") or style.background_color,
        border_color=_parse_hex_color_attribute(element, "border_color") or style.border_color,
        title_align=_parse_alignment(element.attrib.get("align"), "<table>") or style.align or "left",
        title_font=_merge_font_style(style.font, _parse_font_style(element)),
    )


def _parse_column(element: ET.Element, styles: dict[str, StyleDefinition]) -> Column:
    label = element.attrib.get("label")
    if not label:
        raise TemplateValidationError("Todo <column> deve definir o atributo 'label'.")

    field = element.attrib.get("field")
    expression = element.attrib.get("expression")
    if not any((field, expression)):
        raise TemplateValidationError("Todo <column> deve definir 'field' ou 'expression'.")

    formatter = element.attrib.get("format")
    if formatter and not has_formatter(formatter):
        raise TemplateValidationError(f"Formatter desconhecido: {formatter}")

    style = _resolve_style(styles, element.attrib.get("style"), "<column>")
    header_style = _resolve_style(
        styles,
        element.attrib.get("header_style"),
        "<column>",
        default=style,
    )
    has_explicit_width = element.attrib.get("width") is not None
    explicit_width_mode, explicit_width_mm = _parse_width(element)
    explicit_font = _parse_font_style(element)
    explicit_header_font = _parse_font_style(element, prefix="header_")

    return Column(
        label=label,
        field=field,
        expression=expression,
        formatter=formatter,
        visible_if=element.attrib.get("visible_if"),
        align=_parse_alignment(element.attrib.get("align"), "<column>") or style.align or "left",
        header_align=(
            _parse_alignment(element.attrib.get("header_align"), "<column>")
            or header_style.header_align
            or header_style.align
            or style.header_align
            or style.align
        ),
        width_mode=explicit_width_mode if has_explicit_width else style.width_mode or "auto",
        width_mm=explicit_width_mm if has_explicit_width else style.width_mm,
        background_color=_parse_hex_color_attribute(element, "background_color") or style.background_color,
        border_color=_parse_hex_color_attribute(element, "border_color") or style.border_color,
        header_background_color=(
            _parse_hex_color_attribute(element, "header_background_color")
            or header_style.header_background_color
            or style.header_background_color
            or style.background_color
        ),
        header_border_color=(
            _parse_hex_color_attribute(element, "header_border_color")
            or header_style.header_border_color
            or style.header_border_color
            or style.border_color
        ),
        font=_merge_font_style(style.font, explicit_font),
        header_font=_merge_font_style(_base_header_font(header_style), explicit_header_font),
    )


def _parse_total(element: ET.Element) -> Total:
    operation = element.attrib.get("operation")
    if not operation:
        raise TemplateValidationError("Todo <total> deve definir o atributo 'operation'.")
    if not has_aggregation(operation):
        raise TemplateValidationError(f"Agregação desconhecida: {operation}")

    field = element.attrib.get("field")
    expression = element.attrib.get("expression")
    if operation != "count" and not any((field, expression)):
        raise TemplateValidationError(
            "Totais com operação diferente de 'count' devem definir 'field' ou 'expression'."
        )

    formatter = element.attrib.get("format")
    if formatter and not has_formatter(formatter):
        raise TemplateValidationError(f"Formatter desconhecido: {formatter}")

    return Total(
        operation=operation,
        field=field,
        expression=expression,
        formatter=formatter,
        label=element.attrib.get("label"),
        data_source=element.attrib.get("data"),
        visible_if=element.attrib.get("visible_if"),
        background_color=_parse_hex_color_attribute(element, "background_color"),
        border_color=_parse_hex_color_attribute(element, "border_color"),
        font=_parse_font_style(element),
    )


def _parse_image_element(element: ET.Element, template_dir: Path) -> ImageElement:
    src = element.attrib.get("src")
    field = element.attrib.get("field")
    expression = element.attrib.get("expression")
    if not any((src, field, expression)):
        raise TemplateValidationError("Todo <image> deve definir 'src', 'field' ou 'expression'.")
    resolved_src = None
    if src:
        resolved_path = (template_dir / src).resolve() if not Path(src).is_absolute() else Path(src)
        if not resolved_path.exists():
            raise TemplateValidationError(f"Imagem estática não encontrada no template: {resolved_path}")
        resolved_src = str(resolved_path)

    return ImageElement(
        src=resolved_src,
        field=field,
        expression=expression,
        alt=element.attrib.get("alt"),
        width_mm=_parse_positive_float_attribute(element, "width_mm"),
        height_mm=_parse_positive_float_attribute(element, "height_mm"),
        visible_if=element.attrib.get("visible_if"),
        page_break_before=_parse_bool_attribute(element, "page_break_before", default=False),
        keep_together=_parse_bool_attribute(element, "keep_together", default=False),
        background_color=_parse_hex_color_attribute(element, "background_color"),
        border_color=_parse_hex_color_attribute(element, "border_color"),
    )


def _parse_code_element(element: ET.Element) -> CodeElement:
    field = element.attrib.get("field")
    expression = element.attrib.get("expression")
    value = element.attrib.get("value") or _clean_text(element.text)
    if not any((field, expression, value)):
        raise TemplateValidationError(
            f"O elemento <{element.tag}> deve definir 'field', 'expression' ou 'value'."
        )

    symbology = None
    if element.tag == "barcode":
        symbology = (element.attrib.get("symbology") or "code128").strip().lower()
        if symbology not in VALID_BARCODE_SYMBOLOGIES:
            raise TemplateValidationError(
                f"Simbologia de barcode não suportada em <barcode>: {symbology}"
            )

    return CodeElement(
        kind=element.tag,
        field=field,
        expression=expression,
        value=value,
        symbology=symbology,
        width_mm=_parse_positive_float_attribute(element, "width_mm"),
        height_mm=_parse_positive_float_attribute(element, "height_mm"),
        visible_if=element.attrib.get("visible_if"),
        page_break_before=_parse_bool_attribute(element, "page_break_before", default=False),
        keep_together=_parse_bool_attribute(element, "keep_together", default=False),
        color=_parse_hex_color_attribute(element, "color"),
        background_color=_parse_hex_color_attribute(element, "background_color"),
        border_color=_parse_hex_color_attribute(element, "border_color"),
    )


def _parse_styles(element: ET.Element | None) -> dict[str, StyleDefinition]:
    if element is None:
        return {}

    styles: dict[str, StyleDefinition] = {}
    if any(child.tag != "style" for child in element):
        raise TemplateValidationError("O elemento <styles> aceita apenas elementos <style>.")
    for child in element.findall("style"):
        name = child.attrib.get("name")
        if not name:
            raise TemplateValidationError("Todo <style> deve definir o atributo 'name'.")
        if name in styles:
            raise TemplateValidationError(f"Estilo duplicado no template: {name}")
        width_mode, width_mm = _parse_width(child)
        styles[name] = StyleDefinition(
            align=_parse_alignment(child.attrib.get("align"), "<style>"),
            header_align=_parse_alignment(child.attrib.get("header_align"), "<style>"),
            width_mode=width_mode,
            width_mm=width_mm,
            background_color=_parse_hex_color_attribute(child, "background_color"),
            border_color=_parse_hex_color_attribute(child, "border_color"),
            header_background_color=_parse_hex_color_attribute(child, "header_background_color"),
            header_border_color=_parse_hex_color_attribute(child, "header_border_color"),
            font=_parse_font_style(child),
            header_font=_parse_font_style(child, prefix="header_"),
        )
    return styles


def _parse_parameter_definitions(
    element: ET.Element | None,
    context: str,
) -> list[ParameterDefinition]:
    if element is None:
        return []
    if any(child.tag != "parameter" for child in element):
        raise TemplateValidationError(f"O elemento {context} aceita apenas <parameter>.")

    parameters: list[ParameterDefinition] = []
    seen_names: set[str] = set()
    for child in element.findall("parameter"):
        name = child.attrib.get("name")
        if not name:
            raise TemplateValidationError(f"Todo <parameter> em {context} deve definir o atributo 'name'.")
        if name in seen_names:
            raise TemplateValidationError(f"Parâmetro duplicado em {context}: {name}")
        field = child.attrib.get("field")
        expression = child.attrib.get("expression")
        value = child.attrib.get("value") or _clean_text(child.text)
        if not any((field, expression, value)):
            raise TemplateValidationError(
                f"O parâmetro '{name}' em {context} deve definir 'field', 'expression' ou 'value'."
            )
        parameters.append(
            ParameterDefinition(
                name=name,
                field=field,
                expression=expression,
                value=value,
            )
        )
        seen_names.add(name)
    return parameters


def _parse_variables(element: ET.Element | None) -> list[VariableDefinition]:
    if element is None:
        return []
    if any(child.tag != "variable" for child in element):
        raise TemplateValidationError("O elemento <variables> aceita apenas <variable>.")

    variables: list[VariableDefinition] = []
    seen_names: set[str] = set()
    for child in element.findall("variable"):
        name = child.attrib.get("name")
        expression = child.attrib.get("expression")
        if not name:
            raise TemplateValidationError("Todo <variable> deve definir o atributo 'name'.")
        if not expression:
            raise TemplateValidationError(f"A variável '{name}' deve definir o atributo 'expression'.")
        if name in seen_names:
            raise TemplateValidationError(f"Variável duplicada no template: {name}")
        variables.append(VariableDefinition(name=name, expression=expression))
        seen_names.add(name)
    return variables


def _parse_margins(element: ET.Element) -> PageMargins:
    return PageMargins(
        top_mm=_parse_positive_float_attribute(element, "margin_top_mm", default=20.0),
        right_mm=_parse_positive_float_attribute(element, "margin_right_mm", default=20.0),
        bottom_mm=_parse_positive_float_attribute(element, "margin_bottom_mm", default=20.0),
        left_mm=_parse_positive_float_attribute(element, "margin_left_mm", default=20.0),
    )


def _parse_float_attribute(element: ET.Element, attribute: str, default: float | None = None) -> float | None:
    raw_value = element.attrib.get(attribute)
    if raw_value is None:
        return default
    try:
        return float(raw_value)
    except ValueError as exc:
        raise TemplateValidationError(
            f"O atributo '{attribute}' em <{element.tag}> deve ser numérico."
        ) from exc


def _parse_positive_float_attribute(
    element: ET.Element,
    attribute: str,
    default: float | None = None,
) -> float | None:
    value = _parse_float_attribute(element, attribute, default=default)
    if value is not None and value <= 0:
        raise TemplateValidationError(
            f"O atributo '{attribute}' em <{element.tag}> deve ser maior que zero."
        )
    return value


def _parse_bool_attribute(element: ET.Element, attribute: str, default: bool = False) -> bool:
    raw_value = element.attrib.get(attribute)
    if raw_value is None:
        return default

    normalized = raw_value.strip().lower()
    if normalized in {"1", "true", "yes", "sim"}:
        return True
    if normalized in {"0", "false", "no", "nao", "não"}:
        return False
    raise TemplateValidationError(
        f"O atributo '{attribute}' em <{element.tag}> deve ser booleano."
    )


def _parse_alignment(value: str | None, context: str) -> str | None:
    if value is None:
        return None
    normalized = value.strip().lower()
    if normalized not in VALID_ALIGNMENTS:
        raise TemplateValidationError(f"Alinhamento inválido em {context}: {value}")
    return normalized


def _parse_font_style(element: ET.Element, prefix: str = "") -> FontStyle:
    transform = element.attrib.get(f"{prefix}text_transform")
    if transform is not None:
        transform = transform.strip().lower()
        if transform not in VALID_TEXT_TRANSFORMS:
            raise TemplateValidationError(
                f"Transformação de texto inválida em <{element.tag}>: {transform}"
            )

    return FontStyle(
        family=element.attrib.get(f"{prefix}font_family"),
        size_pt=_parse_float_attribute(element, f"{prefix}font_size_pt"),
        transform=transform,
        color=_parse_hex_color_attribute(element, f"{prefix}color"),
    )


def _parse_width(element: ET.Element) -> tuple[str, float | None]:
    raw_width = element.attrib.get("width")
    if raw_width is None or raw_width.strip() == "":
        return "auto", None

    normalized = raw_width.strip().lower()
    if normalized == "auto":
        return "auto", None
    if normalized.endswith("mm"):
        try:
            value = float(normalized[:-2])
        except ValueError as exc:
            raise TemplateValidationError(
                f"Largura inválida em <{element.tag}>: {raw_width}. Use 'auto' ou valor em mm."
            ) from exc
        if value <= 0:
            raise TemplateValidationError(
                f"Largura inválida em <{element.tag}>: {raw_width}. Use um valor em mm maior que zero."
            )
        return "mm", value
    raise TemplateValidationError(
        f"Largura inválida em <{element.tag}>: {raw_width}. Use 'auto' ou valor em mm."
    )


def _parse_hex_color_attribute(element: ET.Element, attribute: str) -> str | None:
    raw_value = element.attrib.get(attribute)
    if raw_value is None:
        return None
    value = raw_value.strip()
    if not HEX_COLOR_RE.match(value):
        raise TemplateValidationError(
            f"O atributo '{attribute}' em <{element.tag}> deve usar cor hexadecimal no formato #RRGGBB."
        )
    return value.upper()


def _resolve_style(
    styles: dict[str, StyleDefinition],
    name: str | None,
    context: str,
    default: StyleDefinition | None = None,
) -> StyleDefinition:
    if name is None:
        return default or StyleDefinition()
    try:
        return styles[name]
    except KeyError as exc:
        raise TemplateValidationError(f"Estilo desconhecido em {context}: {name}") from exc


def _merge_font_style(base: FontStyle, override: FontStyle) -> FontStyle:
    return FontStyle(
        family=override.family or base.family,
        size_pt=override.size_pt if override.size_pt is not None else base.size_pt,
        transform=override.transform or base.transform,
        color=override.color or base.color,
    )


def _base_header_font(style: StyleDefinition) -> FontStyle:
    if any(
        (
            style.header_font.family,
            style.header_font.size_pt is not None,
            style.header_font.transform,
        )
    ):
        return style.header_font
    return style.font


def _clean_text(value: str | None) -> str | None:
    if value is None:
        return None
    cleaned = value.strip()
    return cleaned or None


def _validate_root_structure(root: ET.Element) -> None:
    allowed_children = {
        "styles",
        "parameters",
        "variables",
        "header",
        "page_header",
        "body",
        "footer",
        "page_footer",
        "last_page_footer",
    }
    seen_singletons: dict[str, int] = {}
    for child in root:
        if child.tag not in allowed_children:
            raise TemplateValidationError(f"Elemento não suportado em <report>: <{child.tag}>.")
        seen_singletons[child.tag] = seen_singletons.get(child.tag, 0) + 1

    duplicated = [tag for tag, count in seen_singletons.items() if count > 1]
    if duplicated:
        raise TemplateValidationError(
            f"Seções duplicadas em <report>: {', '.join(sorted(duplicated))}."
        )
