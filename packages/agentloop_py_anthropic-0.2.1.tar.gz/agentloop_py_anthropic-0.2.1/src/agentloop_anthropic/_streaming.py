"""
Streaming support for the Anthropic wrapper.

Anthropic's streaming API delivers events with these types:

  - content_block_start   ({"type": "text"} or {"type": "tool_use", ...})
  - content_block_delta   (delta.text fragments OR delta.partial_json)
  - content_block_stop
  - message_start, message_delta, message_stop

We accumulate text deltas and partial_json from tool_use blocks, then
render the assembled answer as text + "[Called <name>(<args>)]" lines.

Same partial-stream / error-handling contract as the OpenAI wrapper:
partial responses log with metadata.partial=True, errors don't log
at all, empty streams don't log.

Anthropic supports two streaming APIs:

  1. messages.create(stream=True)  → returns an iterator of raw events
  2. messages.stream(...)           → returns a context manager with
                                       higher-level event accessors

We support (1) — the lower-level form. If a user wants to use (2)'s
helpers, they can; the wrapper still passes the underlying object
through, so context manager methods like .text_stream are accessible
via __getattr__.
"""

from __future__ import annotations

import json
import logging
from typing import Any, AsyncIterator, Iterator

logger = logging.getLogger("agentloop.anthropic.streaming")


class _Accumulator:
    """Reassembles Anthropic streaming events into a complete answer."""

    def __init__(self) -> None:
        self._text_parts: list[str] = []
        # Map block index -> {"name": str, "partial_json": str}
        self._tool_uses: dict[int, dict[str, str]] = {}
        # Track active block types so we know how to interpret deltas
        self._block_types: dict[int, str] = {}
        self._chunk_count = 0

    def absorb(self, event: Any) -> None:
        """Process one streaming event. Tolerates malformed events."""
        self._chunk_count += 1
        try:
            event_type = (
                getattr(event, "type", None)
                or (event.get("type") if isinstance(event, dict) else None)
            )
            if not event_type:
                return

            if event_type == "content_block_start":
                self._handle_block_start(event)
            elif event_type == "content_block_delta":
                self._handle_block_delta(event)
            # content_block_stop, message_*: nothing to absorb

        except Exception as e:  # noqa: BLE001
            logger.debug("anthropic accumulator absorb error: %s", e)

    def _handle_block_start(self, event: Any) -> None:
        idx = _get(event, "index")
        block = _get(event, "content_block")
        if idx is None or block is None:
            return
        block_type = _get(block, "type")
        if block_type:
            self._block_types[idx] = block_type
        if block_type == "tool_use":
            name = _get(block, "name") or ""
            self._tool_uses.setdefault(idx, {"name": name, "partial_json": ""})
            if name and not self._tool_uses[idx].get("name"):
                self._tool_uses[idx]["name"] = name

    def _handle_block_delta(self, event: Any) -> None:
        idx = _get(event, "index")
        delta = _get(event, "delta")
        if idx is None or delta is None:
            return

        delta_type = _get(delta, "type")

        # Text delta
        if delta_type == "text_delta":
            text = _get(delta, "text")
            if isinstance(text, str) and text:
                self._text_parts.append(text)
            return

        # Tool use input JSON delta — fragment of the arguments
        if delta_type == "input_json_delta":
            partial = _get(delta, "partial_json")
            if isinstance(partial, str):
                entry = self._tool_uses.setdefault(
                    idx, {"name": "", "partial_json": ""}
                )
                entry["partial_json"] += partial

    def assembled_answer(self) -> str:
        parts: list[str] = []
        text = "".join(self._text_parts).strip()
        if text:
            parts.append(text)

        if self._tool_uses:
            for idx in sorted(self._tool_uses.keys()):
                tu = self._tool_uses[idx]
                name = tu.get("name") or "<unknown>"
                args_raw = tu.get("partial_json") or ""
                args_pretty = _pretty_args(args_raw)
                parts.append(f"[Called {name}({args_pretty})]")

        return "\n".join(parts)

    @property
    def chunk_count(self) -> int:
        return self._chunk_count


def _get(obj: Any, key: str) -> Any:
    """Pull a key from either an object (attribute) or a dict (item)."""
    if obj is None:
        return None
    if hasattr(obj, key):
        return getattr(obj, key)
    if isinstance(obj, dict):
        return obj.get(key)
    return None


def _pretty_args(raw: str) -> str:
    if not raw:
        return ""
    try:
        return json.dumps(json.loads(raw), separators=(", ", ": "))
    except (json.JSONDecodeError, ValueError):
        return raw


class AgentLoopStream:
    """Sync iterator/context-manager wrapper around an Anthropic stream."""

    def __init__(
        self,
        underlying_stream: Iterator[Any],
        *,
        question: str,
        memories: Any,
        config: Any,
        per_call: Any,
    ) -> None:
        self._underlying = underlying_stream
        self._question = question
        self._memories = memories
        self._config = config
        self._per_call = per_call
        self._accumulator = _Accumulator()
        self._exhausted = False
        self._logged = False
        self._errored = False

    def __iter__(self) -> "AgentLoopStream":
        return self

    def __next__(self) -> Any:
        try:
            event = next(self._underlying)
        except StopIteration:
            self._exhausted = True
            self._log_turn_once()
            raise
        except Exception:
            self._errored = True
            raise
        else:
            self._accumulator.absorb(event)
            return event

    def __enter__(self) -> "AgentLoopStream":
        enter = getattr(self._underlying, "__enter__", None)
        if callable(enter):
            enter()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> Any:
        if exc_type is not None:
            self._errored = True
        self._log_turn_once()
        ex = getattr(self._underlying, "__exit__", None)
        if callable(ex):
            return ex(exc_type, exc_val, exc_tb)
        return None

    def __del__(self) -> None:
        try:
            self._log_turn_once()
        except Exception:  # noqa: BLE001
            pass

    def __getattr__(self, name: str) -> Any:
        return getattr(self._underlying, name)

    def _log_turn_once(self) -> None:
        if self._logged or self._errored:
            return
        self._logged = True

        if self._accumulator.chunk_count == 0:
            return

        answer = self._accumulator.assembled_answer()
        if not answer:
            return

        from ._ask import _detect_and_log
        _detect_and_log(
            question=self._question,
            answer=answer,
            memories=self._memories,
            config=self._config,
            per_call=self._per_call,
            partial=not self._exhausted,
        )


class AgentLoopAsyncStream:
    """Async iterator/context-manager wrapper. Mirrors AgentLoopStream."""

    def __init__(
        self,
        underlying_stream: AsyncIterator[Any],
        *,
        question: str,
        memories: Any,
        config: Any,
        per_call: Any,
    ) -> None:
        self._underlying = underlying_stream
        self._question = question
        self._memories = memories
        self._config = config
        self._per_call = per_call
        self._accumulator = _Accumulator()
        self._exhausted = False
        self._logged = False
        self._errored = False

    def __aiter__(self) -> "AgentLoopAsyncStream":
        return self

    async def __anext__(self) -> Any:
        try:
            event = await self._underlying.__anext__()
        except StopAsyncIteration:
            self._exhausted = True
            await self._log_turn_once_async()
            raise
        except Exception:
            self._errored = True
            raise
        else:
            self._accumulator.absorb(event)
            return event

    async def __aenter__(self) -> "AgentLoopAsyncStream":
        enter = getattr(self._underlying, "__aenter__", None)
        if callable(enter):
            await enter()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> Any:
        if exc_type is not None:
            self._errored = True
        await self._log_turn_once_async()
        ex = getattr(self._underlying, "__aexit__", None)
        if callable(ex):
            return await ex(exc_type, exc_val, exc_tb)
        return None

    def __getattr__(self, name: str) -> Any:
        return getattr(self._underlying, name)

    async def _log_turn_once_async(self) -> None:
        if self._logged or self._errored:
            return
        self._logged = True

        if self._accumulator.chunk_count == 0:
            return

        answer = self._accumulator.assembled_answer()
        if not answer:
            return

        from ._ask import _detect_and_log_async
        await _detect_and_log_async(
            question=self._question,
            answer=answer,
            memories=self._memories,
            config=self._config,
            per_call=self._per_call,
            partial=not self._exhausted,
        )
