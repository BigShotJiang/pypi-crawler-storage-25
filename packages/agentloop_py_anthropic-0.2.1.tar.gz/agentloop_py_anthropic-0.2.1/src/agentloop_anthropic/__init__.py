"""
agentloop-py-anthropic — drop-in Anthropic SDK wrapper for AgentLoop.

    from anthropic import Anthropic
    from agentloop import AgentLoop
    from agentloop_anthropic import wrap_anthropic

    anthropic = wrap_anthropic(
        Anthropic(),
        loop=AgentLoop(api_key="ak_..."),
    )

    # Unchanged Anthropic call — AgentLoop hooks fire automatically
    msg = anthropic.messages.create(
        model="claude-opus-4-7",
        max_tokens=1024,
        messages=[{"role": "user", "content": "hello"}],
        agentloop={"user_id": "u_123"},
    )

    # Streaming works the same way (added in v0.2.0):
    stream = anthropic.messages.create(
        model="claude-opus-4-7",
        max_tokens=1024,
        messages=[{"role": "user", "content": "hello"}],
        stream=True,
    )
    for event in stream:
        ...

For async code, use AsyncAnthropic + wrap_async_anthropic:

    from anthropic import AsyncAnthropic
    from agentloop.aio import AsyncAgentLoop
    from agentloop_anthropic import wrap_async_anthropic

    async with AsyncAgentLoop(api_key="ak_...") as loop:
        anthropic = wrap_async_anthropic(AsyncAnthropic(), loop=loop)
        stream = await anthropic.messages.create(..., stream=True)
        async for event in stream:
            ...
"""

from ._ask import (
    PerCallOptions,
    WrapOptions,
    ask_with_agentloop,
    ask_with_agentloop_async,
)
from ._streaming import AgentLoopAsyncStream, AgentLoopStream
from ._wrap import wrap_anthropic, wrap_async_anthropic

__all__ = [
    # Sync
    "wrap_anthropic",
    "ask_with_agentloop",
    # Async
    "wrap_async_anthropic",
    "ask_with_agentloop_async",
    # Streaming wrappers
    "AgentLoopStream",
    "AgentLoopAsyncStream",
    # Configuration
    "PerCallOptions",
    "WrapOptions",
]

__version__ = "0.2.1"
