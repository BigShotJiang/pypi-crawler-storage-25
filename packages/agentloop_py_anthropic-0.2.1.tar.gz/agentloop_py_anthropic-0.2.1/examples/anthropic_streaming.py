"""
Streaming example for the Anthropic wrapper.

Run with:
    pip install agentloop-py agentloop-py-anthropic anthropic
    export ANTHROPIC_API_KEY=...
    export AGENTLOOP_API_KEY=ak_live_...
    python anthropic_streaming.py
"""

import os

from anthropic import Anthropic

from agentloop import AgentLoop
from agentloop_anthropic import wrap_anthropic


def main() -> None:
    loop = AgentLoop(api_key=os.environ["AGENTLOOP_API_KEY"])

    anthropic = wrap_anthropic(Anthropic(), loop=loop)

    # Identical to a vanilla Anthropic streaming call. AgentLoop runs:
    #   1. memory search (before)
    #   2. memory injection into the system prompt
    #   3. event-by-event passthrough as you iterate
    #   4. log_turn (after stream ends, with assembled response)
    stream = anthropic.messages.create(
        model="claude-opus-4-7",
        max_tokens=1024,
        system="You are a helpful assistant for a Brazilian fintech.",
        messages=[
            {"role": "user", "content": "What's the Pix limit at night?"},
        ],
        stream=True,
        agentloop={"user_id": "u_demo", "tags": ["streaming_demo"]},
    )

    print("Response (streaming):")
    for event in stream:
        # Anthropic emits typed events. We print text deltas; everything
        # else (block start/stop, message events) we silently skip in
        # this demo, but your code would handle them as needed.
        if getattr(event, "type", None) == "content_block_delta":
            delta = getattr(event, "delta", None)
            if getattr(delta, "type", None) == "text_delta":
                print(getattr(delta, "text", ""), end="", flush=True)
    print()
    print()
    print("Done. Check the AgentLoop dashboard — this turn is in the review queue.")


if __name__ == "__main__":
    main()
