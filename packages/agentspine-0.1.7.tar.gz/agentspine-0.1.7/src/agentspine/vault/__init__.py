"""Credential vault."""
