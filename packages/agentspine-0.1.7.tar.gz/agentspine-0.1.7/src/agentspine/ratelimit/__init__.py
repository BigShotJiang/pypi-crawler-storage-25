"""Rate limiting module."""
