"""Event streaming and auditing."""
