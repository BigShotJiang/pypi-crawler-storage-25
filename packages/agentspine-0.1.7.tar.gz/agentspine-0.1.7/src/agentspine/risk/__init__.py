"""Risk scoring module."""
