"""Resource lock manager."""
