"""Tool execution framework."""
