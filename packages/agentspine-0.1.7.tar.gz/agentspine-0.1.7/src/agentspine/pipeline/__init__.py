"""Action lifecycle pipeline."""
