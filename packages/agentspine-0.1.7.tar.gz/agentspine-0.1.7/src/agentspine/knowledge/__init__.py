"""Knowledge graph."""
