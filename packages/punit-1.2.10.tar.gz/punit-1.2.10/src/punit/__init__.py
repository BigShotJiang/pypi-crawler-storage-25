# SPDX-FileCopyrightText: © 2024 Shaun Wilson
# SPDX-License-Identifier: MIT

from .assertions import *
from .facts import *
from .theories import *
from .traits import *


__version__ = '1.2.10'
__commit__ = 'c0f4ed9'
__all__ = [
    '__version__', '__commit__',
    'assertions',
    'collections', 'exceptions', 'strings',
    'facts',
    'fact',
    'theories',
    'theory', 'inlinedata',
    'traits',
    'trait'
]
