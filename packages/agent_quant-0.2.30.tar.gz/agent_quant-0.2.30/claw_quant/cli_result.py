# -*- coding: utf-8 -*-
"""
回测结果管理命令

提供回测结果的查询、对比、报告生成等功能
"""

import json
import sys
import os
from datetime import date
from typing import Optional
import webbrowser

from .backtest.result_manager import BacktestResultManager


def format_output(data: dict) -> str:
    """格式化输出为JSON"""
    def json_serial(obj):
        if isinstance(obj, date):
            return obj.isoformat()
        raise TypeError(f"Type {type(obj)} not serializable")
    
    return json.dumps(data, ensure_ascii=False, indent=2, default=json_serial)


def cmd_result(args) -> int:
    """回测结果管理命令"""
    if args.action == 'list':
        return cmd_result_list(args)
    elif args.action == 'show':
        return cmd_result_show(args)
    elif args.action == 'report':
        return cmd_result_report(args)
    elif args.action == 'compare':
        return cmd_result_compare(args)
    elif args.action == 'clean':
        return cmd_result_clean(args)
    elif args.action == 'delete':
        return cmd_result_delete(args)
    else:
        print(format_output({
            'success': False,
            'message': f'未知操作: {args.action}'
        }))
        return 1


def cmd_result_list(args) -> int:
    """列出历史回测结果"""
    manager = BacktestResultManager(args.dir)
    
    results = manager.list_results(
        limit=args.limit if args.limit else 20,
        strategy_code=args.strategy
    )
    
    # 简化输出
    simplified = []
    for r in results:
        simplified.append({
            'id': r.result_id[:8],
            'strategy': r.strategy_name,
            'period': f"{r.start_date} ~ {r.end_date}",
            'total_return': f"{r.total_return:+.2f}%",
            'max_drawdown': f"{r.max_drawdown:.2f}%",
            'trades': r.total_trades,
            'created_at': r.created_at.strftime('%Y-%m-%d %H:%M')
        })
    
    print(format_output({
        'success': True,
        'count': len(simplified),
        'results': simplified
    }))
    return 0


def cmd_result_show(args) -> int:
    """查看回测结果详情"""
    manager = BacktestResultManager(args.dir)
    
    # 获取结果
    if args.id:
        result = manager.get_result(args.id)
    else:
        # 获取最近的结果
        results = manager.list_results(limit=1)
        if not results:
            print(format_output({
                'success': False,
                'message': '没有回测结果'
            }))
            return 1
        result = results[0]
    
    if not result:
        print(format_output({
            'success': False,
            'message': f'回测结果不存在: {args.id}'
        }))
        return 1
    
    # 获取详情
    detail = manager.get_result_detail(result.result_id)
    
    # 简化输出
    output = {
        'success': True,
        'summary': {
            'id': result.result_id[:8],
            'strategy': result.strategy_name,
            'period': f"{result.start_date} ~ {result.end_date}",
            'initial_capital': result.initial_capital,
            'final_capital': result.final_capital,
            'total_return': f"{result.total_return:+.2f}%",
            'annual_return': f"{result.annual_return:+.2f}%",
            'max_drawdown': f"{result.max_drawdown:.2f}%",
            'sharpe_ratio': result.sharpe_ratio,
            'win_rate': f"{result.win_rate:.2f}%" if result.win_rate else None,
            'total_trades': result.total_trades,
            'trade_days': result.trade_days
        },
        'trades_count': len(detail.get('trades', [])),
        'daily_stats_count': len(detail.get('daily_stats', []))
    }
    
    # 显示最近的交易记录
    if detail.get('trades') and args.show_trades:
        trades = detail['trades'][:10]
        output['recent_trades'] = trades
    
    print(format_output(output))
    return 0


def cmd_result_report(args) -> int:
    """生成 HTML 报告"""
    manager = BacktestResultManager(args.dir)
    
    # 获取结果
    if args.id:
        result = manager.get_result(args.id)
    else:
        results = manager.list_results(limit=1)
        if not results:
            print(format_output({
                'success': False,
                'message': '没有回测结果'
            }))
            return 1
        result = results[0]
    
    if not result:
        print(format_output({
            'success': False,
            'message': f'回测结果不存在: {args.id}'
        }))
        return 1
    
    # 生成报告
    try:
        html_path = manager.generate_html_report(result.result_id)
        
        output = {
            'success': True,
            'message': 'HTML 报告已生成',
            'path': html_path
        }
        
        # 自动打开
        if args.open:
            webbrowser.open(f'file://{os.path.abspath(html_path)}')
            output['opened'] = True
        
        print(format_output(output))
        return 0
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'生成报告失败: {str(e)}'
        }))
        return 1


def cmd_result_compare(args) -> int:
    """对比多个回测结果"""
    manager = BacktestResultManager(args.dir)
    
    if not args.ids:
        print(format_output({
            'success': False,
            'message': '请指定要对比的结果ID，用逗号分隔'
        }))
        return 1
    
    result_ids = [rid.strip() for rid in args.ids.split(',')]
    
    # 检查每个ID是否有效
    invalid_ids = []
    valid_results = []
    
    for rid in result_ids:
        result = manager.get_result(rid)
        if result:
            valid_results.append(result)
        else:
            invalid_ids.append(rid)
    
    # 如果有无效ID，返回错误
    if invalid_ids:
        print(format_output({
            'success': False,
            'message': f'无效的结果ID: {", ".join(invalid_ids)}',
            'invalid_ids': invalid_ids,
            'valid_ids': [r.result_id for r in valid_results]
        }))
        return 1
    
    # 如果没有有效结果
    if not valid_results:
        print(format_output({
            'success': False,
            'message': '未找到任何有效的回测结果',
            'ids': result_ids
        }))
        return 1
    
    try:
        # 构建对比DataFrame
        import pandas as pd
        results_data = [r.to_dict() for r in valid_results]
        df = pd.DataFrame(results_data)
        
        # 选择关键列
        columns = [
            'result_id', 'strategy_name', 'start_date', 'end_date',
            'total_return', 'annual_return', 'max_drawdown',
            'sharpe_ratio', 'win_rate', 'total_trades'
        ]
        available_columns = [c for c in columns if c in df.columns]
        df = df[available_columns]
        
        print(format_output({
            'success': True,
            'comparison': df.to_dict('records'),
            'count': len(valid_results)
        }))
        return 0
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'对比失败: {str(e)}'
        }))
        return 1


def cmd_result_clean(args) -> int:
    """清理旧结果"""
    manager = BacktestResultManager(args.dir)
    
    days = args.days if args.days else 30
    count = manager.clean_old_results(days)
    
    print(format_output({
        'success': True,
        'message': f'已清理 {count} 个旧结果',
        'cleaned': count,
        'retention_days': days
    }))
    return 0


def cmd_result_delete(args) -> int:
    """删除回测结果"""
    manager = BacktestResultManager(args.dir)
    
    if not args.id:
        print(format_output({
            'success': False,
            'message': '请指定要删除的结果ID'
        }))
        return 1
    
    success = manager.delete_result(args.id)
    
    print(format_output({
        'success': success,
        'message': '删除成功' if success else '删除失败'
    }))
    return 0 if success else 1
