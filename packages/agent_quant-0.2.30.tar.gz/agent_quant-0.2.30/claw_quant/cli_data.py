# -*- coding: utf-8 -*-
"""
数据管理 CLI 子命令

提供类似 khquant 的数据管理功能：
- data list: 列出所有有数据的股票
- data stats: 数据库统计概览
- data info: 查看单只股票详情
- data download: 从多数据源下载数据
- data scan: 扫描数据缺口
- data export: 导出数据到CSV
- data repair: 修复数据库
"""

import argparse
import json
import sys
import os
from datetime import datetime, date
from typing import Optional, List, Dict, Any
import pandas as pd

from .database.api import StockAPI
from .database.source.factory import DataSourceFactory


def cmd_data_list(args):
    """列出所有有数据的股票"""
    api = StockAPI()
    
    try:
        # 获取所有股票数据
        query = "SELECT DISTINCT code FROM market_data_daily"
        params = []
        
        if args.market:
            query += " WHERE code LIKE ?"
            params.append(f"%.{args.market}")
        
        df = api.db_client.execute_query(query, params)
        stocks = df['code'].tolist() if 'code' in df.columns else []
        
        if not stocks:
            print("数据库中没有股票数据")
            return
        
        print(f"\n  共 {len(stocks)} 只股票:\n")
        
        # 按市场分组
        sh_stocks = [s for s in stocks if s.endswith('.SH')]
        sz_stocks = [s for s in stocks if s.endswith('.SZ')]
        bj_stocks = [s for s in stocks if s.endswith('.BJ')]
        
        if sh_stocks:
            print(f"  上海市场 (SH): {len(sh_stocks)} 只")
            for i, code in enumerate(sh_stocks[:10]):
                print(f"    {code}")
            if len(sh_stocks) > 10:
                print(f"    ... 还有 {len(sh_stocks) - 10} 只")
        
        if sz_stocks:
            print(f"\n  深圳市场 (SZ): {len(sz_stocks)} 只")
            for i, code in enumerate(sz_stocks[:10]):
                print(f"    {code}")
            if len(sz_stocks) > 10:
                print(f"    ... 还有 {len(sz_stocks) - 10} 只")
        
        if bj_stocks:
            print(f"\n  北京市场 (BJ): {len(bj_stocks)} 只")
        
        print()
        
    except Exception as e:
        print(f"错误: {e}")
        sys.exit(1)


def cmd_data_stats(args):
    """数据库统计概览"""
    api = StockAPI()
    
    try:
        # 总体统计
        df = api.db_client.execute_query("""
            SELECT 
                COUNT(DISTINCT code) as stock_count,
                COUNT(*) as total_records,
                MIN(trade_date) as start_date,
                MAX(trade_date) as end_date
            FROM market_data_daily
        """)
        
        row = df.iloc[0] if not df.empty else [0, 0, None, None]
        
        print("\n  ══════════════════════════════════════════════════")
        print("  数据库统计")
        print("  ══════════════════════════════════════════════════")
        print(f"  股票数量:      {row['stock_count'] or 0} 只")
        print(f"  总记录数:      {row['total_records'] or 0:,} 条")
        print(f"  数据起始:      {row['start_date'] or 'N/A'}")
        print(f"  数据结束:      {row['end_date'] or 'N/A'}")
        
        # 按市场统计
        df_market = api.db_client.execute_query("""
            SELECT 
                CASE 
                    WHEN code LIKE '%.SH' THEN 'SH'
                    WHEN code LIKE '%.SZ' THEN 'SZ'
                    WHEN code LIKE '%.BJ' THEN 'BJ'
                    ELSE 'OTHER'
                END as market,
                COUNT(DISTINCT code) as count
            FROM market_data_daily
            GROUP BY market
        """)
        
        print("\n  ──────────────────────────────────────────────────")
        print("  按市场分布")
        print("  ──────────────────────────────────────────────────")
        for _, row in df_market.iterrows():
            print(f"  {row['market']}: {row['count']} 只")
        
        # 最近更新
        df_recent = api.db_client.execute_query("""
            SELECT code, MAX(trade_date) as last_date
            FROM market_data_daily
            GROUP BY code
            ORDER BY last_date DESC
            LIMIT 5
        """)
        
        print("\n  ──────────────────────────────────────────────────")
        print("  最近更新 (Top 5)")
        print("  ──────────────────────────────────────────────────")
        for _, row in df_recent.iterrows():
            print(f"  {row['code']}: {row['last_date']}")
        
        print("  ══════════════════════════════════════════════════\n")
        
    except Exception as e:
        print(f"错误: {e}")
        sys.exit(1)


def cmd_data_info(args):
    """查看单只股票详情"""
    api = StockAPI()
    code = args.code
    
    try:
        # 检查股票是否存在
        df_check = api.db_client.execute_query(
            "SELECT COUNT(*) as cnt FROM market_data_daily WHERE code = ?",
            [code]
        )
        
        if df_check.empty or df_check.iloc[0]['cnt'] == 0:
            print(f"\n  股票 {code} 在数据库中不存在\n")
            return
        
        # 获取统计信息
        df = api.db_client.execute_query("""
            SELECT 
                COUNT(*) as record_count,
                MIN(trade_date) as start_date,
                MAX(trade_date) as end_date,
                MIN(low) as min_price,
                MAX(high) as max_price,
                AVG(volume) as avg_volume
            FROM market_data_daily
            WHERE code = ?
        """, [code])
        
        row = df.iloc[0]
        
        print(f"\n  ══════════════════════════════════════════════════")
        print(f"  股票详情: {code}")
        print(f"  ══════════════════════════════════════════════════")
        print(f"  数据条数:      {row['record_count']:,} 条")
        print(f"  起始日期:      {row['start_date']}")
        print(f"  结束日期:      {row['end_date']}")
        print(f"  最低价:        {row['min_price']:.2f}")
        print(f"  最高价:        {row['max_price']:.2f}")
        print(f"  平均成交量:    {row['avg_volume']:,.0f}")
        
        # 获取最新数据
        df_latest = api.db_client.execute_query("""
            SELECT trade_date, open, high, low, close, volume
            FROM market_data_daily
            WHERE code = ?
            ORDER BY trade_date DESC
            LIMIT 1
        """, [code])
        
        if not df_latest.empty:
            row = df_latest.iloc[0]
            print(f"\n  ──────────────────────────────────────────────────")
            print(f"  最新数据 ({row['trade_date']})")
            print(f"  ──────────────────────────────────────────────────")
            print(f"  开盘: {row['open']:.2f}  最高: {row['high']:.2f}")
            print(f"  最低: {row['low']:.2f}  收盘: {row['close']:.2f}")
            print(f"  成交量: {row['volume']:,}")
        
        print(f"  ══════════════════════════════════════════════════\n")
        
    except Exception as e:
        print(f"错误: {e}")
        sys.exit(1)


def cmd_data_download(args):
    """下载数据"""
    print(f"\n  从 {args.source} 下载数据...")
    
    try:
        # 获取股票列表
        stocks = []
        
        if args.stocks:
            stocks = [s.strip() for s in args.stocks.split(',')]
        elif args.file:
            with open(args.file, 'r') as f:
                stocks = [line.strip() for line in f if line.strip()]
        elif args.pool:
            # 从股票池获取
            from .backtest.pools import StockPool
            pool = StockPool()
            pools = args.pool.split(',')
            for p in pools:
                stocks.extend(pool.get_pool_stocks(p))
            stocks = list(set(stocks))  # 去重
        
        if not stocks:
            print("  错误: 请指定股票代码 (--stocks)、文件 (--file) 或股票池 (--pool)")
            sys.exit(1)
        
        print(f"  股票数量: {len(stocks)} 只")
        print(f"  数据周期: {args.period}")
        print(f"  时间范围: {args.start} ~ {args.end}\n")
        
        # 创建数据源
        config = {}
        if args.source == 'tushare' and args.token:
            config['token'] = args.token
        
        source = DataSourceFactory.create(args.source, config, use_cache=False)
        
        # 下载数据
        success_count = 0
        fail_count = 0
        
        for i, code in enumerate(stocks, 1):
            print(f"  [{i}/{len(stocks)}] {code} ... ", end='', flush=True)
            
            try:
                # 下载数据
                df = source.download_daily(
                    code=code,
                    start_date=args.start,
                    end_date=args.end
                )
                
                if df is not None and not df.empty:
                    # 保存到数据库
                    api = StockAPI()
                    api.db_client.save_daily_data(code, df)
                    print(f"✓ ({len(df)} 条)")
                    success_count += 1
                else:
                    print("✗ (无数据)")
                    fail_count += 1
                    
            except Exception as e:
                print(f"✗ ({e})")
                fail_count += 1
        
        print(f"\n  下载完成: 成功 {success_count} 只, 失败 {fail_count} 只\n")
        
    except Exception as e:
        print(f"错误: {e}")
        sys.exit(1)


def cmd_data_scan(args):
    """扫描数据缺口"""
    api = StockAPI()
    
    try:
        print("\n  扫描数据缺口...")
        
        # 获取所有股票
        df_stocks = api.db_client.execute_query(
            "SELECT DISTINCT code FROM market_data_daily"
        )
        stocks = df_stocks['code'].tolist() if 'code' in df_stocks.columns else []
        
        gaps = []
        
        for code in stocks:
            df = api.db_client.execute_query("""
                SELECT trade_date FROM market_data_daily
                WHERE code = ?
                ORDER BY trade_date
            """, [code])
            
            if df.empty or 'trade_date' not in df.columns:
                continue
                
            dates = df['trade_date'].tolist()
            
            # 检查连续日期缺口
            for i in range(1, len(dates)):
                # 处理可能包含时间部分的日期
                date_str1 = str(dates[i-1]).split()[0]  # 取日期部分
                date_str2 = str(dates[i]).split()[0]
                d1 = datetime.strptime(date_str1, '%Y-%m-%d').date()
                d2 = datetime.strptime(date_str2, '%Y-%m-%d').date()
                gap_days = (d2 - d1).days - 1
                
                if gap_days > 5:  # 超过5天的缺口
                    gaps.append({
                        'code': code,
                        'start': dates[i-1],
                        'end': dates[i],
                        'days': gap_days
                    })
        
        if gaps:
            print(f"\n  发现 {len(gaps)} 个数据缺口:\n")
            for g in gaps[:20]:  # 只显示前20个
                print(f"  {g['code']}: {g['start']} ~ {g['end']} (缺 {g['days']} 天)")
            if len(gaps) > 20:
                print(f"  ... 还有 {len(gaps) - 20} 个")
        else:
            print("\n  ✓ 未发现明显数据缺口\n")
        
        # 修复模式
        if args.fix and gaps:
            print("\n  正在修复...")
            # TODO: 实现修复逻辑
            
    except Exception as e:
        print(f"错误: {e}")
        sys.exit(1)


def cmd_data_export(args):
    """导出数据到CSV"""
    api = StockAPI()
    code = args.code
    
    try:
        # 查询数据
        query = """
            SELECT trade_date, open, high, low, close, volume, amount
            FROM market_data_daily
            WHERE code = ?
        """
        params = [code]
        
        if args.start:
            query += " AND trade_date >= ?"
            params.append(args.start)
        if args.end:
            query += " AND trade_date <= ?"
            params.append(args.end)
        
        query += " ORDER BY trade_date"
        
        df = api.db_client.execute_query(query, params)
        
        if df.empty:
            print(f"\n  股票 {code} 没有数据\n")
            return
        
        # 确定输出路径
        output = args.output or f"{code.replace('.', '_')}.csv"
        
        # 导出
        df.to_csv(output, index=False, encoding='utf-8-sig')
        print(f"\n  ✓ 已导出 {len(df)} 条记录到: {output}\n")
        
    except Exception as e:
        print(f"错误: {e}")
        sys.exit(1)


def cmd_data_repair(args):
    """修复数据库"""
    print("\n  正在检查数据库...")
    
    try:
        api = StockAPI()
        
        # 检查并修复常见问题
        # 1. 删除重复数据
        df_dup = api.db_client.execute_query("""
            SELECT code, trade_date, COUNT(*) as cnt
            FROM market_data_daily
            GROUP BY code, trade_date
            HAVING cnt > 1
        """)
        
        if not df_dup.empty:
            print(f"  发现 {len(df_dup)} 组重复数据，正在清理...")
            # 保留每组最新的记录
            api.db_client.execute_query("""
                DELETE FROM market_data_daily
                WHERE rowid NOT IN (
                    SELECT MAX(rowid)
                    FROM market_data_daily
                    GROUP BY code, trade_date
                )
            """)
            print("  ✓ 重复数据已清理")
        
        # 2. 检查缺失值
        df_null = api.db_client.execute_query("""
            SELECT COUNT(*) as cnt FROM market_data_daily
            WHERE open IS NULL OR high IS NULL OR low IS NULL 
               OR close IS NULL OR volume IS NULL
        """)
        
        null_count = df_null.iloc[0]['cnt'] if not df_null.empty else 0
        if null_count > 0:
            print(f"  发现 {null_count} 条记录有缺失值")
        
        # 3. 优化数据库
        api.db_client.execute_query("VACUUM")
        
        print("  ✓ 数据库修复完成\n")
        
    except Exception as e:
        print(f"错误: {e}")
        sys.exit(1)


def setup_data_parser(subparsers):
    """设置 data 子命令解析器"""
    data_parser = subparsers.add_parser('data', help='数据管理')
    data_subparsers = data_parser.add_subparsers(dest='data_command', help='数据管理命令')
    
    # list 命令
    list_parser = data_subparsers.add_parser('list', help='列出所有有数据的股票')
    list_parser.add_argument('--market', choices=['SH', 'SZ', 'BJ'], help='按市场过滤')
    list_parser.set_defaults(func=cmd_data_list)
    
    # stats 命令
    stats_parser = data_subparsers.add_parser('stats', help='数据库统计概览')
    stats_parser.set_defaults(func=cmd_data_stats)
    
    # info 命令
    info_parser = data_subparsers.add_parser('info', help='查看单只股票详情')
    info_parser.add_argument('code', help='股票代码')
    info_parser.set_defaults(func=cmd_data_info)
    
    # download 命令
    download_parser = data_subparsers.add_parser('download', help='下载数据')
    download_parser.add_argument('--source', required=True, 
                              choices=['qmt', 'baostock', 'tushare'],
                              help='数据源')
    download_parser.add_argument('--stocks', help='股票代码，逗号分隔')
    download_parser.add_argument('--file', help='股票列表文件')
    download_parser.add_argument('--pool', help='股票池代码，如 hs300,sz50')
    download_parser.add_argument('--period', default='1d', 
                              choices=['1d', '1m', '5m'],
                              help='数据周期')
    download_parser.add_argument('--start', required=True, help='起始日期 YYYYMMDD')
    download_parser.add_argument('--end', required=True, help='结束日期 YYYYMMDD')
    download_parser.add_argument('--token', help='Tushare Token（仅tushare需要）')
    download_parser.set_defaults(func=cmd_data_download)
    
    # scan 命令
    scan_parser = data_subparsers.add_parser('scan', help='扫描数据缺口')
    scan_parser.add_argument('--fix', action='store_true', help='自动修复')
    scan_parser.set_defaults(func=cmd_data_scan)
    
    # export 命令
    export_parser = data_subparsers.add_parser('export', help='导出数据到CSV')
    export_parser.add_argument('code', help='股票代码')
    export_parser.add_argument('--start', help='起始日期 YYYY-MM-DD')
    export_parser.add_argument('--end', help='结束日期 YYYY-MM-DD')
    export_parser.add_argument('--output', '-o', help='输出文件路径')
    export_parser.set_defaults(func=cmd_data_export)
    
    # repair 命令
    repair_parser = data_subparsers.add_parser('repair', help='修复数据库')
    repair_parser.set_defaults(func=cmd_data_repair)
