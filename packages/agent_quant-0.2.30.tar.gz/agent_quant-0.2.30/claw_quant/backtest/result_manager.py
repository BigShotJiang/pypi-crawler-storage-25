# -*- coding: utf-8 -*-
"""
回测结果管理器 - 统一管理回测结果的存储和查询

功能:
- 保存回测结果（summary, trades, daily_stats, config）
- 列出历史回测记录
- 查看回测详情
- 生成对比报告
- 生成 HTML 报告
"""

import os
import json
import glob
import shutil
from datetime import datetime, date
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from pathlib import Path
import pandas as pd
import logging

logger = logging.getLogger(__name__)


@dataclass
class BacktestResult:
    """回测结果数据结构"""
    result_id: str                    # 结果ID
    task_name: str                    # 任务名称
    strategy_code: str                # 策略代码
    strategy_name: str                # 策略名称
    start_date: date                  # 开始日期
    end_date: date                    # 结束日期
    initial_capital: float            # 初始资金
    final_capital: float              # 最终资金
    total_return: float               # 总收益率 (%)
    annual_return: float              # 年化收益率 (%)
    max_drawdown: float               # 最大回撤 (%)
    sharpe_ratio: Optional[float]     # 夏普比率
    sortino_ratio: Optional[float]    # 索提诺比率
    calmar_ratio: Optional[float]     # 卡尔玛比率
    volatility: Optional[float]       # 波动率
    win_rate: Optional[float]         # 胜率
    profit_factor: Optional[float]    # 盈亏比
    total_trades: int                 # 总交易次数
    winning_trades: int               # 盈利次数
    losing_trades: int                # 亏损次数
    avg_profit: Optional[float]       # 平均盈利
    avg_loss: Optional[float]         # 平均亏损
    trade_days: int                   # 交易天数
    created_at: datetime              # 创建时间
    result_dir: str                   # 结果目录
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        data = asdict(self)
        # 处理日期类型
        data['start_date'] = self.start_date.isoformat()
        data['end_date'] = self.end_date.isoformat()
        data['created_at'] = self.created_at.isoformat()
        return data
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'BacktestResult':
        """从字典创建"""
        # 转换日期类型
        data['start_date'] = date.fromisoformat(data['start_date'])
        data['end_date'] = date.fromisoformat(data['end_date'])
        data['created_at'] = datetime.fromisoformat(data['created_at'])
        return cls(**data)


class BacktestResultManager:
    """
    回测结果管理器
    
    管理回测结果的存储、查询和报告生成
    """
    
    def __init__(self, results_dir: str = None):
        """
        初始化结果管理器
        
        Args:
            results_dir: 结果存储目录，默认使用当前目录下的 backtest_results
        """
        if results_dir is None:
            # 默认在当前工作目录
            results_dir = os.path.join(os.getcwd(), 'backtest_results')
            
        self.results_dir = Path(results_dir)
        self.results_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"回测结果目录: {self.results_dir}")
    
    def save_result(
        self,
        result: BacktestResult,
        trades_df: Optional[pd.DataFrame] = None,
        daily_stats_df: Optional[pd.DataFrame] = None,
        config: Optional[Dict] = None,
        benchmark_df: Optional[pd.DataFrame] = None
    ) -> str:
        """
        保存回测结果
        
        Args:
            result: 回测结果摘要
            trades_df: 交易记录
            daily_stats_df: 每日统计
            config: 回测配置
            benchmark_df: 基准数据
            
        Returns:
            结果目录路径
        """
        # 创建结果目录
        result_dir = self.results_dir / result.result_id
        result_dir.mkdir(parents=True, exist_ok=True)
        
        # 保存摘要
        summary_path = result_dir / 'summary.json'
        with open(summary_path, 'w', encoding='utf-8') as f:
            json.dump(result.to_dict(), f, ensure_ascii=False, indent=2)
            
        # 保存交易记录
        if trades_df is not None and not trades_df.empty:
            trades_path = result_dir / 'trades.csv'
            trades_df.to_csv(trades_path, index=False, encoding='utf-8')
            
        # 保存每日统计
        if daily_stats_df is not None and not daily_stats_df.empty:
            daily_path = result_dir / 'daily_stats.csv'
            daily_stats_df.to_csv(daily_path, index=False, encoding='utf-8')
            
        # 保存配置
        if config is not None:
            config_path = result_dir / 'config.json'
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(config, f, ensure_ascii=False, indent=2)
                
        # 保存基准数据
        if benchmark_df is not None and not benchmark_df.empty:
            benchmark_path = result_dir / 'benchmark.csv'
            benchmark_df.to_csv(benchmark_path, index=False, encoding='utf-8')
            
        logger.info(f"回测结果已保存: {result_dir}")
        return str(result_dir)
    
    def list_results(
        self,
        limit: int = 20,
        strategy_code: Optional[str] = None,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None
    ) -> List[BacktestResult]:
        """
        列出历史回测结果
        
        Args:
            limit: 返回数量限制
            strategy_code: 按策略代码过滤
            start_date: 按开始日期过滤
            end_date: 按结束日期过滤
            
        Returns:
            回测结果列表，按时间倒序
        """
        results = []
        
        # 遍历所有结果目录
        for result_dir in sorted(self.results_dir.iterdir(), key=lambda x: x.stat().st_mtime, reverse=True):
            if not result_dir.is_dir():
                continue
                
            summary_path = result_dir / 'summary.json'
            if not summary_path.exists():
                continue
                
            try:
                with open(summary_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    
                result = BacktestResult.from_dict(data)
                result.result_dir = str(result_dir)
                
                # 过滤
                if strategy_code and result.strategy_code != strategy_code:
                    continue
                if start_date and result.start_date < start_date:
                    continue
                if end_date and result.end_date > end_date:
                    continue
                    
                results.append(result)
                
                if len(results) >= limit:
                    break
                    
            except Exception as e:
                logger.warning(f"读取结果失败 {result_dir}: {e}")
                continue
                
        return results
    
    def get_result(self, result_id: str) -> Optional[BacktestResult]:
        """
        获取单个回测结果
        
        Args:
            result_id: 结果ID 或目录名
            
        Returns:
            回测结果，不存在返回 None
        """
        result_dir = self.results_dir / result_id
        if not result_dir.exists():
            # 尝试查找
            for d in self.results_dir.iterdir():
                if d.name.startswith(result_id):
                    result_dir = d
                    break
                    
        if not result_dir.exists():
            return None
            
        summary_path = result_dir / 'summary.json'
        if not summary_path.exists():
            return None
            
        try:
            with open(summary_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                
            result = BacktestResult.from_dict(data)
            result.result_dir = str(result_dir)
            return result
            
        except Exception as e:
            logger.error(f"读取结果失败: {e}")
            return None
    
    def get_result_detail(self, result_id: str) -> Dict[str, Any]:
        """
        获取回测结果详情
        
        Args:
            result_id: 结果ID
            
        Returns:
            包含所有数据的字典
        """
        result = self.get_result(result_id)
        if result is None:
            return {}
            
        result_dir = Path(result.result_dir)
        detail = {
            'summary': result.to_dict(),
            'trades': None,
            'daily_stats': None,
            'config': None,
            'benchmark': None
        }
        
        # 读取交易记录
        trades_path = result_dir / 'trades.csv'
        if trades_path.exists():
            detail['trades'] = pd.read_csv(trades_path).to_dict('records')
            
        # 读取每日统计
        daily_path = result_dir / 'daily_stats.csv'
        if daily_path.exists():
            detail['daily_stats'] = pd.read_csv(daily_path).to_dict('records')
            
        # 读取配置
        config_path = result_dir / 'config.json'
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                detail['config'] = json.load(f)
                
        # 读取基准数据
        benchmark_path = result_dir / 'benchmark.csv'
        if benchmark_path.exists():
            detail['benchmark'] = pd.read_csv(benchmark_path).to_dict('records')
            
        return detail
    
    def delete_result(self, result_id: str) -> bool:
        """
        删除回测结果
        
        Args:
            result_id: 结果ID
            
        Returns:
            是否删除成功
        """
        result_dir = self.results_dir / result_id
        if not result_dir.exists():
            return False
            
        try:
            shutil.rmtree(result_dir)
            logger.info(f"已删除结果: {result_id}")
            return True
        except Exception as e:
            logger.error(f"删除结果失败: {e}")
            return False
    
    def clean_old_results(self, days: int = 30) -> int:
        """
        清理旧的回测结果
        
        Args:
            days: 保留天数
            
        Returns:
            删除的结果数量
        """
        cutoff = datetime.now().timestamp() - days * 24 * 3600
        count = 0
        
        for result_dir in self.results_dir.iterdir():
            if not result_dir.is_dir():
                continue
                
            mtime = result_dir.stat().st_mtime
            if mtime < cutoff:
                try:
                    shutil.rmtree(result_dir)
                    count += 1
                except Exception as e:
                    logger.warning(f"删除失败 {result_dir}: {e}")
                    
        logger.info(f"清理了 {count} 个旧结果")
        return count
    
    def generate_html_report(self, result_id: str, output_path: str = None) -> str:
        """
        生成 HTML 报告
        
        Args:
            result_id: 结果ID
            output_path: 输出路径，默认在结果目录生成
            
        Returns:
            HTML 文件路径
        """
        detail = self.get_result_detail(result_id)
        if not detail:
            raise ValueError(f"结果不存在: {result_id}")
            
        result_dir = Path(detail['summary']['result_dir'])
        
        if output_path is None:
            output_path = result_dir / 'report.html'
            
        # 生成 HTML
        html = self._generate_html(detail)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)
            
        logger.info(f"HTML 报告已生成: {output_path}")
        return str(output_path)
    
    def _generate_html(self, detail: Dict[str, Any]) -> str:
        """生成 HTML 内容"""
        summary = detail['summary']
        
        html = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>回测报告 - {summary['strategy_name']}</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 20px; background: #f5f5f5; }}
        .container {{ max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
        h1 {{ color: #333; border-bottom: 2px solid #4CAF50; padding-bottom: 10px; }}
        h2 {{ color: #555; margin-top: 30px; }}
        .metrics {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin: 20px 0; }}
        .metric {{ background: #f8f9fa; padding: 15px; border-radius: 6px; border-left: 4px solid #4CAF50; }}
        .metric-label {{ font-size: 12px; color: #666; text-transform: uppercase; }}
        .metric-value {{ font-size: 24px; font-weight: bold; color: #333; margin-top: 5px; }}
        .metric-value.positive {{ color: #4CAF50; }}
        .metric-value.negative {{ color: #f44336; }}
        table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
        th, td {{ padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }}
        th {{ background: #f8f9fa; font-weight: 600; }}
        tr:hover {{ background: #f5f5f5; }}
        .info {{ background: #e3f2fd; padding: 15px; border-radius: 6px; margin: 20px 0; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>回测报告</h1>
        
        <div class="info">
            <strong>策略:</strong> {summary['strategy_name']} ({summary['strategy_code']})<br>
            <strong>回测区间:</strong> {summary['start_date']} ~ {summary['end_date']}<br>
            <strong>运行时间:</strong> {summary['created_at']}
        </div>
        
        <h2>绩效指标</h2>
        <div class="metrics">
            <div class="metric">
                <div class="metric-label">总收益率</div>
                <div class="metric-value {'positive' if summary['total_return'] >= 0 else 'negative'}">{summary['total_return']:+.2f}%</div>
            </div>
            <div class="metric">
                <div class="metric-label">年化收益率</div>
                <div class="metric-value {'positive' if summary['annual_return'] >= 0 else 'negative'}">{summary['annual_return']:+.2f}%</div>
            </div>
            <div class="metric">
                <div class="metric-label">最大回撤</div>
                <div class="metric-value negative">{summary['max_drawdown']:.2f}%</div>
            </div>
            <div class="metric">
                <div class="metric-label">夏普比率</div>
                <div class="metric-value">{summary.get('sharpe_ratio', 'N/A') or 'N/A'}</div>
            </div>
            <div class="metric">
                <div class="metric-label">胜率</div>
                <div class="metric-value">{summary.get('win_rate', 'N/A') or 'N/A'}{'%' if summary.get('win_rate') else ''}</div>
            </div>
            <div class="metric">
                <div class="metric-label">交易次数</div>
                <div class="metric-value">{summary['total_trades']}</div>
            </div>
        </div>
        
        <h2>资金变动</h2>
        <div class="metrics">
            <div class="metric">
                <div class="metric-label">初始资金</div>
                <div class="metric-value">{summary['initial_capital']:,.2f}</div>
            </div>
            <div class="metric">
                <div class="metric-label">最终资金</div>
                <div class="metric-value">{summary['final_capital']:,.2f}</div>
            </div>
        </div>
'''
        
        # 添加交易记录
        if detail.get('trades'):
            html += '''
        <h2>交易记录</h2>
        <table>
            <thead>
                <tr>
                    <th>日期</th>
                    <th>代码</th>
                    <th>方向</th>
                    <th>价格</th>
                    <th>数量</th>
                    <th>金额</th>
                </tr>
            </thead>
            <tbody>
'''
            for trade in detail['trades'][:50]:  # 只显示前50条
                html += f'''                <tr>
                    <td>{trade.get('date', '')}</td>
                    <td>{trade.get('code', '')}</td>
                    <td>{trade.get('direction', '')}</td>
                    <td>{trade.get('price', 0):.2f}</td>
                    <td>{trade.get('volume', 0)}</td>
                    <td>{trade.get('amount', 0):,.2f}</td>
                </tr>
'''
            html += '''            </tbody>
        </table>
'''
        
        html += '''
    </div>
</body>
</html>
'''
        return html
    
    def compare_results(self, result_ids: List[str]) -> pd.DataFrame:
        """
        对比多个回测结果
        
        Args:
            result_ids: 结果ID列表
            
        Returns:
            对比 DataFrame
        """
        results = []
        
        for rid in result_ids:
            result = self.get_result(rid)
            if result:
                results.append(result.to_dict())
                
        if not results:
            return pd.DataFrame()
            
        df = pd.DataFrame(results)
        
        # 选择关键列
        columns = [
            'strategy_name', 'start_date', 'end_date',
            'total_return', 'annual_return', 'max_drawdown',
            'sharpe_ratio', 'win_rate', 'total_trades'
        ]
        
        return df[[c for c in columns if c in df.columns]]
