"""Metapackage marker for aws-resource-validator-data."""
