"""FastAPI router builder: signup, verify, login, approve, reject, me."""

from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime

from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, EmailStr, Field
from slowapi import Limiter
from sqlmodel import Session, select

from parbaked.auth.deps import make_current_user
from parbaked.auth.jwt import create_jwt
from parbaked.auth.models import User, UserStatus
from parbaked.auth.passwords import hash_password, verify_password
from parbaked.auth.tokens import (
    InvalidApprovalToken,
    InvalidVerifyToken,
    create_approval_token,
    create_verify_token,
    verify_approval_token,
    verify_verify_token,
)
from parbaked.config import ParbakedConfig
from parbaked.email.base import EmailTransport
from parbaked.email.templates import Templates

# ---------------------------------------------------------------------------
# Request / response schemas
# ---------------------------------------------------------------------------


class SignupRequest(BaseModel):
    email: EmailStr
    name: str = Field(min_length=1, max_length=255)
    password: str = Field(min_length=8, max_length=128)


class SignupResponse(BaseModel):
    user_id: str
    status: UserStatus


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class UserPublic(BaseModel):
    id: str
    email: EmailStr
    name: str
    status: UserStatus


class LoginResponse(BaseModel):
    token: str
    user: UserPublic


# ---------------------------------------------------------------------------
# Confirmation pages (admin click-through)
# ---------------------------------------------------------------------------

_PAGE_SHELL = """\
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>{title}</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
          max-width: 32rem; margin: 4rem auto; padding: 0 1.5rem; color: #1a1a1a; }}
  h1 {{ font-size: 1.5rem; margin-bottom: 0.5rem; }}
  p  {{ line-height: 1.5; color: #444; }}
  .ok    {{ color: #15803d; }}
  .nope  {{ color: #b91c1c; }}
</style>
</head>
<body>
  <h1 class="{cls}">{heading}</h1>
  <p>{body}</p>
</body>
</html>
"""


def _ok_page(heading: str, body: str) -> HTMLResponse:
    return HTMLResponse(_PAGE_SHELL.format(title=heading, heading=heading, body=body, cls="ok"))


def _err_page(heading: str, body: str, status_code: int = 400) -> HTMLResponse:
    return HTMLResponse(
        _PAGE_SHELL.format(title=heading, heading=heading, body=body, cls="nope"),
        status_code=status_code,
    )


# ---------------------------------------------------------------------------
# Router builder
# ---------------------------------------------------------------------------


def build_auth_router(
    config: ParbakedConfig,
    get_session: Callable[..., Session],
    email: EmailTransport,
    *,
    limiter: Limiter | None = None,
    templates: Templates | None = None,
    prefix: str = "/auth",
    tags: list[str] | None = None,
) -> APIRouter:
    """Construct the signup/login/approval router.

    Args:
        config: parbaked settings (secrets, branding, rate limits).
        get_session: FastAPI dependency yielding a SQLModel ``Session``. parbaked
            calls this via ``Depends`` — supply the same one you use elsewhere.
        email: any object implementing :class:`EmailTransport`. Use
            :class:`ConsoleEmail` for dev and tests.
        limiter: optional slowapi ``Limiter``. If omitted, rate limiting is OFF
            on these routes — fine for tests but DO NOT ship to production
            without it. Pair with :func:`install_rate_limiting`.
        templates: override the email body renderers if you want custom copy.
        prefix: URL prefix. Default ``/auth``.
        tags: OpenAPI tags. Default ``["auth"]``.
    """
    templates = templates or Templates()
    current_user = make_current_user(config, get_session)
    router = APIRouter(prefix=prefix, tags=tags or ["auth"])

    # slowapi requires the decorator at definition time, so we resolve to a
    # no-op when no limiter is provided.
    def _limit(rule: str) -> Callable[[Callable], Callable]:
        if limiter is None:
            return lambda f: f
        return limiter.limit(rule)

    # ----- signup ----------------------------------------------------
    @router.post("/signup", response_model=SignupResponse, status_code=status.HTTP_201_CREATED)
    @_limit(config.ratelimit_signup)
    async def signup(
        request: Request,  # noqa: ARG001 — needed by slowapi
        response: Response,  # noqa: ARG001 — slowapi injects rate-limit headers
        body: SignupRequest,
        session: Session = Depends(get_session),
    ) -> SignupResponse:
        # Reject duplicate emails up-front. Generic message to avoid enumeration.
        existing = session.exec(select(User).where(User.email == body.email)).first()
        if existing is not None:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="An account with that email is already registered or pending.",
            )

        user = User(
            email=body.email,
            name=body.name,
            password_hash=hash_password(body.password),
            status=UserStatus.pending,
        )
        session.add(user)
        session.commit()
        session.refresh(user)

        # Email the user a verification magic link. The admin doesn't get
        # notified until the user actually clicks through — that's how we
        # filter out junk signups before they reach the admin queue.
        verify_token = create_verify_token(user.id, config)
        verify_url = f"{config.app_url.rstrip('/')}{prefix}/verify/{verify_token}"
        email.send(templates.user_verify_email(user, verify_url, config))

        return SignupResponse(user_id=str(user.id), status=user.status)

    # ----- verify email ---------------------------------------------
    @router.get("/verify/{token}", response_class=HTMLResponse)
    async def verify(token: str, session: Session = Depends(get_session)) -> HTMLResponse:
        try:
            user_id = verify_verify_token(token, config)
        except InvalidVerifyToken as exc:
            return _err_page("Link invalid or expired", str(exc), status_code=400)

        user = session.get(User, user_id)
        if user is None:
            return _err_page("User no longer exists", "The signup may have been deleted.", 404)
        if user.email_verified_at is not None:
            return _ok_page(
                "Already verified", f"{user.email} is already verified — awaiting approval."
            )

        user.email_verified_at = datetime.now(UTC)
        session.add(user)
        session.commit()
        session.refresh(user)

        # Now that we've proven the email is real, notify the admin.
        if config.admin_email:
            approve = create_approval_token(user.id, "approve", config)
            reject = create_approval_token(user.id, "reject", config)
            approve_url = f"{config.app_url.rstrip('/')}{prefix}/approve/{approve}"
            reject_url = f"{config.app_url.rstrip('/')}{prefix}/reject/{reject}"
            email.send(
                templates.admin_approval_request(user, approve_url, reject_url, config)
            )

        return _ok_page(
            "Email verified",
            f"Thanks, {user.name}. {user.email} is confirmed — an admin will "
            "approve your account shortly.",
        )

    # ----- login -----------------------------------------------------
    @router.post("/login", response_model=LoginResponse)
    @_limit(config.ratelimit_login)
    async def login(
        request: Request,  # noqa: ARG001
        response: Response,  # noqa: ARG001
        body: LoginRequest,
        session: Session = Depends(get_session),
    ) -> LoginResponse:
        user = session.exec(select(User).where(User.email == body.email)).first()
        # Same response for "no user" and "wrong password" to avoid enumeration.
        if user is None or not verify_password(body.password, user.password_hash):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials"
            )
        if user.email_verified_at is None:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Email not yet verified — check your inbox for the verification link.",
            )
        if user.status == UserStatus.pending:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN, detail="Account awaiting approval"
            )
        if user.status == UserStatus.rejected:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN, detail="Account not approved"
            )

        token = create_jwt(user.id, user.email, user.name, config)
        return LoginResponse(
            token=token,
            user=UserPublic(
                id=str(user.id), email=user.email, name=user.name, status=user.status
            ),
        )

    # ----- approve ---------------------------------------------------
    @router.get("/approve/{token}", response_class=HTMLResponse)
    async def approve(token: str, session: Session = Depends(get_session)) -> HTMLResponse:
        try:
            user_id, action = verify_approval_token(token, config)
        except InvalidApprovalToken as exc:
            return _err_page("Link invalid or expired", str(exc), status_code=400)
        if action != "approve":
            return _err_page("Wrong link", "This link doesn't approve.", status_code=400)

        user = session.get(User, user_id)
        if user is None:
            return _err_page("User no longer exists", "The signup may have been deleted.", 404)
        if user.status == UserStatus.active:
            return _ok_page("Already approved", f"{user.email} is already active.")

        now = datetime.now(UTC)
        user.status = UserStatus.active
        user.approved_at = now
        # Safety net: an admin clicking approve implicitly attests to the email.
        if user.email_verified_at is None:
            user.email_verified_at = now
        session.add(user)
        session.commit()
        session.refresh(user)

        login_url = f"{config.app_url.rstrip('/')}{config.login_path}"
        email.send(templates.user_approved(user, login_url, config))

        return _ok_page("Approved", f"{user.email} can now sign in.")

    # ----- reject ----------------------------------------------------
    @router.get("/reject/{token}", response_class=HTMLResponse)
    async def reject(token: str, session: Session = Depends(get_session)) -> HTMLResponse:
        try:
            user_id, action = verify_approval_token(token, config)
        except InvalidApprovalToken as exc:
            return _err_page("Link invalid or expired", str(exc), status_code=400)
        if action != "reject":
            return _err_page("Wrong link", "This link doesn't reject.", status_code=400)

        user = session.get(User, user_id)
        if user is None:
            return _err_page("User no longer exists", "The signup may have been deleted.", 404)
        if user.status == UserStatus.rejected:
            return _ok_page("Already rejected", f"{user.email} was already rejected.")

        user.status = UserStatus.rejected
        session.add(user)
        session.commit()
        session.refresh(user)

        email.send(templates.user_rejected(user, config))
        return _ok_page("Rejected", f"{user.email} has been rejected and notified.")

    # ----- me --------------------------------------------------------
    @router.get("/me", response_model=UserPublic)
    async def me(user: User = Depends(current_user)) -> UserPublic:
        return UserPublic(id=str(user.id), email=user.email, name=user.name, status=user.status)

    return router
