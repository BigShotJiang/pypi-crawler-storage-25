"""Shared DB / config / email helpers for the CLI subcommands.

The CLI commands run *outside* a FastAPI request — they need to reach the same
DB and use the same email transport as the running app does. This module
resolves both from the cwd's `.env` / env vars / `.parbaked.json`.
"""

from __future__ import annotations

import json
import os
from collections.abc import Iterator
from pathlib import Path

from sqlalchemy.engine import Engine
from sqlmodel import Session, create_engine

from parbaked.config import ParbakedConfig
from parbaked.email.base import EmailTransport
from parbaked.email.console import ConsoleEmail
from parbaked.email.resend import ResendEmail


def load_config() -> ParbakedConfig:
    """Load the same config the app loads. Reads `.env` + env vars."""
    config = ParbakedConfig()

    # Fill in auto-generated secrets from .parbaked.json if env vars are unset
    # — matches the runtime Parbaked() behaviour.
    secrets_file = Path(".parbaked.json")
    if secrets_file.exists():
        try:
            stored = json.loads(secrets_file.read_text())
            if not config.jwt_secret and stored.get("jwt_secret"):
                config.jwt_secret = stored["jwt_secret"]
            if not config.approval_token_secret and stored.get("approval_token_secret"):
                config.approval_token_secret = stored["approval_token_secret"]
        except (OSError, json.JSONDecodeError):
            pass

    return config


def open_engine() -> Engine:
    url = os.getenv("DATABASE_URL") or "sqlite:///./parbaked.db"
    connect_args = {"check_same_thread": False} if url.startswith("sqlite") else {}
    return create_engine(url, connect_args=connect_args)


def open_session() -> Iterator[Session]:
    """Yield a session against the project's DB. Caller iterates once."""
    engine = open_engine()
    with Session(engine) as session:
        yield session


def make_email_transport(config: ParbakedConfig) -> EmailTransport:
    """Pick the same transport the app uses — Resend if configured, else console."""
    if config.resend_key:
        return ResendEmail(config)
    return ConsoleEmail()
