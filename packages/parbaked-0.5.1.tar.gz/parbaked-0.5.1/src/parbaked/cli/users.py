"""parbaked users <sub-command> — inspect and manage users from the shell.

Useful when:
- An agent is debugging "user X can't log in" — they `parbaked users show X` to
  inspect lifecycle state without needing the admin dashboard.
- You want to manually approve someone without clicking through the UI.
- You want to scan the user list (e.g. for a beta).
"""

from __future__ import annotations

import contextlib
from datetime import UTC, datetime

import typer
from sqlmodel import select

from parbaked.auth.models import User, UserStatus
from parbaked.cli._db import load_config, make_email_transport, open_session
from parbaked.email.templates import (
    render_user_approved,
    render_user_rejected,
)

users_app = typer.Typer(help="Inspect and manage users.", no_args_is_help=True)


def _find_user(session, email: str) -> User:
    user = session.exec(select(User).where(User.email == email)).first()
    if user is None:
        typer.echo(f"✗ no user with email {email!r}", err=True)
        raise typer.Exit(1)
    return user


@users_app.command("list")
def list_users() -> None:
    """Print every user with status + verification + signup time."""
    session = next(open_session())
    rows = session.exec(select(User).order_by(User.created_at.desc())).all()
    if not rows:
        typer.echo("(no users yet)")
        return
    typer.echo(f"{'V':1s} {'STATUS':9s} {'EMAIL':40s} {'NAME':25s} SIGNED UP")
    for u in rows:
        verified = "✓" if u.email_verified_at else " "
        signup = u.created_at.strftime("%Y-%m-%d %H:%M")
        typer.echo(
            f"{verified} {u.status.value:9s} {u.email:40s} {u.name[:25]:25s} {signup}"
        )


@users_app.command("show")
def show_user(email: str = typer.Argument(..., help="Email of the user to look up")) -> None:
    """Print full details for a single user."""
    session = next(open_session())
    user = _find_user(session, email)
    typer.echo(f"id:           {user.id}")
    typer.echo(f"email:        {user.email}")
    typer.echo(f"name:         {user.name}")
    typer.echo(f"status:       {user.status.value}")
    typer.echo(f"verified:     {user.email_verified_at or '(not yet)'}")
    typer.echo(f"created:      {user.created_at}")
    typer.echo(f"approved:     {user.approved_at or '(not yet)'}")


@users_app.command("approve")
def approve_user(
    email: str = typer.Argument(..., help="Email of the user to approve"),
    no_email: bool = typer.Option(
        False, "--no-email", help="Skip the welcome email"
    ),
) -> None:
    """Flip a user to active. Sends them the welcome email by default."""
    config = load_config()
    transport = make_email_transport(config)
    session = next(open_session())
    user = _find_user(session, email)

    if user.status == UserStatus.active:
        typer.echo(f"  · {user.email} is already active")
        return

    now = datetime.now(UTC)
    user.status = UserStatus.active
    user.approved_at = now
    if user.email_verified_at is None:
        user.email_verified_at = now
    session.add(user)
    session.commit()

    typer.echo(f"  ✓ approved {user.email}")

    if not no_email:
        login_url = f"{config.app_url.rstrip('/')}{config.login_path}"
        with contextlib.suppress(Exception):
            transport.send(render_user_approved(user, login_url, config))
            typer.echo(f"  ✓ welcome email sent to {user.email}")


@users_app.command("reject")
def reject_user(
    email: str = typer.Argument(..., help="Email of the user to reject"),
    no_email: bool = typer.Option(False, "--no-email", help="Skip the rejection email"),
) -> None:
    """Flip a user to rejected."""
    config = load_config()
    transport = make_email_transport(config)
    session = next(open_session())
    user = _find_user(session, email)

    if user.status == UserStatus.rejected:
        typer.echo(f"  · {user.email} is already rejected")
        return

    user.status = UserStatus.rejected
    session.add(user)
    session.commit()
    typer.echo(f"  ✓ rejected {user.email}")

    if not no_email:
        with contextlib.suppress(Exception):
            transport.send(render_user_rejected(user, config))
            typer.echo(f"  ✓ rejection email sent to {user.email}")
