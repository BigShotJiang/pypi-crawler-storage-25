use thiserror::Error;

#[derive(Debug, Error)]
pub enum Error {
    #[error(transparent)]
    IO(#[from] std::io::Error),
    #[error(transparent)]
    ColorCet(#[from] colorcet::ColorcetError),
    #[error(transparent)]
    Tokio(#[from] tokio::task::JoinError),
    #[error("could not parse color: {0}")]
    ColorParse(String),
    #[error("could not covert ColorMap into LinearGradient")]
    Conversion,
    #[error("mutex was poisoned, this is a bug, please report it!")]
    MutexPoisoned,
    #[error("cannot express {0} as Rational32")]
    Rational(f64),
}
