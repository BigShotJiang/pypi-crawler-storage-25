__version__ = "0.3.7"
APP_TITLE = "Adbnik"
