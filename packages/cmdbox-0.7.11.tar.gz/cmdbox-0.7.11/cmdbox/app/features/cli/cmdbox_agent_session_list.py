from cmdbox.app import common, client
from cmdbox.app.commons import convert, redis_client, resdata, validator
from cmdbox.app.features.cli import cmdbox_agent_chat
from cmdbox.app.options import Options
from pathlib import Path
from typing import Dict, Any, Tuple, List, Union
import argparse
import logging
import json
import pydantic
import re


class AgentSessionList(cmdbox_agent_chat.AgentChat, validator.Validator):

    def get_mode(self) -> str:
        return 'agent'

    def get_cmd(self) -> str:
        return 'session_list'

    def get_option(self) -> Dict[str, Any]:
        return dict(
            use_redis=self.USE_REDIS_TRUE, nouse_webmode=False, use_agent=False,
            description_ja="Agentのセッション一覧を取得します。",
            description_en="List sessions for the agent.",
            choice=[
                dict(opt="host", type=Options.T_STR, default=self.default_host, required=True, multi=False, hide=True, choice=None, web="mask",
                     description_ja="Redisサーバーのサービスホストを指定します。",
                     description_en="Specify the service host of the Redis server."),
                dict(opt="port", type=Options.T_INT, default=self.default_port, required=True, multi=False, hide=True, choice=None, web="mask",
                     description_ja="Redisサーバーのサービスポートを指定します。",
                     description_en="Specify the service port of the Redis server."),
                dict(opt="password", type=Options.T_PASSWD, default=self.default_pass, required=True, multi=False, hide=True, choice=None, web="mask",
                     description_ja=f"Redisサーバーのアクセスパスワード(任意)を指定します。省略時は `{self.default_pass}` を使用します。",
                     description_en=f"Specify the access password of the Redis server (optional). If omitted, `{self.default_pass}` is used."),
                dict(opt="svname", type=Options.T_STR, default=self.default_svname, required=True, multi=False, hide=True, choice=None, web="readonly",
                     description_ja="サーバーのサービス名を指定します。",
                     description_en="Specify the service name of the inference server."),
                dict(opt="retry_count", type=Options.T_INT, default=3, required=False, multi=False, hide=True, choice=None,
                     description_ja="Redisサーバーへの再接続回数を指定します。",
                     description_en="Specifies the number of reconnections to the Redis server."),
                dict(opt="retry_interval", type=Options.T_INT, default=5, required=False, multi=False, hide=True, choice=None,
                     description_ja="Redisサーバーに再接続までの秒数を指定します。",
                     description_en="Specifies the number of seconds before reconnecting to the Redis server."),
                dict(opt="timeout", type=Options.T_INT, default="120", required=False, multi=False, hide=True, choice=None,
                     description_ja="サーバーの応答が返ってくるまでの最大待ち時間を指定。",
                     description_en="Specify the maximum waiting time until the server responds."),
                dict(opt="runner_name", type=Options.T_STR, default=None, required=True, multi=False, hide=False, choice=None,
                    description_ja="Runner設定の名前を指定します。",
                    description_en="Specify the name of the Runner configuration."),
                dict(opt="user_name", type=Options.T_STR, default=None, required=True, multi=False, hide=False, choice=None,
                     description_ja="ユーザー名を指定します。",
                     description_en="Specify a user name."),
                dict(opt="session_id", type=Options.T_STR, default=None, required=False, multi=False, hide=False, choice=None,
                    description_ja="Runnerに送信するセッションIDを指定します。",
                    description_en="Specify the session ID to send to the Runner."),
            ]
        )

    @validator.apprun_check
    def apprun(self, logger: logging.Logger, args: argparse.Namespace, tm: float, pf: List[Dict[str, float]] = []) -> Tuple[int, Dict[str, Any], Any]:

        payload = dict(runner_name=args.runner_name, session_id=args.session_id, user_name=args.user_name)
        payload_b64 = convert.str2b64str(common.to_str(payload))

        cl = client.Client(logger, redis_host=args.host, redis_port=args.port, redis_password=args.password, svname=args.svname)
        ret = cl.redis_cli.send_cmd(self.get_svcmd(), [payload_b64],
                                    retry_count=args.retry_count, retry_interval=args.retry_interval, timeout=args.timeout, nowait=False)
        common.print_format(ret, False, tm, None, False, pf=pf)
        if 'success' not in ret:
            return self.RESP_WARN, ret, cl
        return self.RESP_SUCCESS, ret, cl

    def output_schema(self) -> type:
        class SessionEvent(resdata.Base):
            author: Union[str, None] = pydantic.Field(default=None, description="作成者")
            text: Union[str, None] = pydantic.Field(default=None, description="テキスト")
            final_response: Union[bool, None] = pydantic.Field(default=None, description="最終レスポンスフラグ")
            function_call: Union[bool, None] = pydantic.Field(default=None, description="関数呼び出しフラグ")
            function_response: Union[bool, None] = pydantic.Field(default=None, description="関数レスポンスフラグ")
        class SessionRecord(resdata.Base):
            runner_name: Union[str, None] = pydantic.Field(default=None, description="ランナー名")
            session_id: Union[str, None] = pydantic.Field(default=None, description="セッションID")
            user_name: Union[str, None] = pydantic.Field(default=None, description="ユーザー名")
            last_update_time: Union[Any, None] = pydantic.Field(default=None, description="最終更新日時")
            events: Union[List[SessionEvent], None] = pydantic.Field(default=None, description="イベントリスト")
        class Data(resdata.Data):
            data: Union[List[SessionRecord], None] = pydantic.Field(default=None, description="処理結果のデータ")
        class Result(resdata.Result):
            success: Union[Data, None] = pydantic.Field(default=None, description="成功した場合の結果")
        return Result

    def is_cluster_redirect(self):
        return False

    async def svrun(self, data_dir:Path, logger:logging.Logger, redis_cli:redis_client.RedisClient, msg:List[str],
                    sessions:Dict[str, Dict[str, Any]]):
        reskey = msg[1]
        try:
            if 'agents' not in sessions:
                sessions['agents'] = {}

            payload = json.loads(convert.b64str2str(msg[2]))
            name = payload.get('runner_name')
            session_id = payload.get('session_id')
            user_name = payload.get('user_name')
            runner_conf, agent_conf, llm_conf, memory_conf, memory_llm_conf, memory_embed_conf, mcpsv_confs = self.load_conf(name, data_dir, logger)
            session_service = self.create_session_service(data_dir, logger, runner_conf)
            if session_id is None:
                sessions = await session_service.list_sessions(app_name=name, user_id=user_name)
                data = []
                for s in sessions.sessions:
                    if not s: continue
                    row = dict(runner_name=s.app_name, session_id=s.id, user_name=s.user_id, last_update_time=s.last_update_time)
                    ss = await session_service.get_session(app_name=name, user_id=user_name, session_id=s.id)
                    row['events'] = []
                    for ev in ss.events:
                        msg, is_func_call, is_func_response, is_final_response = cmdbox_agent_chat.AgentChat.gen_msg(ev)
                        row['events'].append(dict(author=ev.author, text=msg,
                                                  final_response=is_final_response,
                                                  function_call=is_func_call,
                                                  function_response=is_func_response))
                    data.append(row)
                data.sort(key=lambda x: (x['last_update_time'],))
                out = dict(success=data, end=True)
                redis_cli.rpush(reskey, out)
                return self.RESP_SUCCESS
            else:
                s = await session_service.get_session(app_name=name, user_id=user_name, session_id=session_id)
                if s is None:
                    out = dict(success=[], end=True)
                else:
                    row = dict(runner_name=s.app_name, session_id=s.id, user_name=s.user_id, last_update_time=s.last_update_time)
                    row['events'] = []
                    for ev in s.events:
                        msg, is_func_call, is_func_response, is_final_response = cmdbox_agent_chat.AgentChat.gen_msg(ev)
                        row['events'].append(dict(author=ev.author, text=msg,
                                                  final_response=is_final_response,
                                                  function_call=is_func_call,
                                                  function_response=is_func_response))
                    out = dict(success=[row], end=True)
                redis_cli.rpush(reskey, out)
                return self.RESP_SUCCESS
        except NotImplementedError as e:
            logger.warning(f"Session listing is not implemented for this Runner: {e}", exc_info=True)
            out = dict(warn="Session listing is not implemented for this Runner.", end=True)
            redis_cli.rpush(reskey, out)
            return self.RESP_WARN
        except Exception as e:
            # それ以外のエラーが発生した時はログに出力して空リストを返す
            logger.warning(f"list_agent_sessions warning: {e}", exc_info=True)
            out = dict(success=[], end=True)
            redis_cli.rpush(reskey, out)
            return self.RESP_WARN
