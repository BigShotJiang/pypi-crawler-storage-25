from cmdbox.app import common, client, options
from cmdbox.app.auth import signin
from cmdbox.app.commons import convert, redis_client, resdata, validator
from cmdbox.app.features.cli import cmdbox_agent_memory_status, cmdbox_tts_say
from cmdbox.app.features.cli.agent import agant_base
from cmdbox.app.options import Options
from contextlib import aclosing
from pathlib import Path
from typing import Dict, Any, Tuple, List, Union
import argparse
import logging
import json
import pydantic
import re


class AgentChat(agant_base.AgentBase, validator.Validator):

    def __init__(self, appcls, ver, language:str=None):
        super().__init__(appcls, ver, language=language)
        self.memory = cmdbox_agent_memory_status.AgentMemoryStatus(appcls, ver, language=language)
        self.call_a2asv_start:bool = False

    def get_mode(self) -> Union[str, List[str]]:
        return 'agent'

    def get_cmd(self) -> str:
        return 'chat'

    def get_option(self) -> Dict[str, Any]:
        return dict(
            use_redis=self.USE_REDIS_TRUE, nouse_webmode=False, use_agent=True,
            description_ja="Agentとチャットを行います。",
            description_en="Chat with the agent.",
            choice=[
                dict(opt="host", type=Options.T_STR, default=self.default_host, required=True, multi=False, hide=True, choice=None, web="mask",
                     description_ja="Redisサーバーのサービスホストを指定します。",
                     description_en="Specify the service host of the Redis server."),
                dict(opt="port", type=Options.T_INT, default=self.default_port, required=True, multi=False, hide=True, choice=None, web="mask",
                     description_ja="Redisサーバーのサービスポートを指定します。",
                     description_en="Specify the service port of the Redis server."),
                dict(opt="password", type=Options.T_PASSWD, default=self.default_pass, required=True, multi=False, hide=True, choice=None, web="mask",
                     description_ja=f"Redisサーバーのアクセスパスワード(任意)を指定します。省略時は `{self.default_pass}` を使用します。",
                     description_en=f"Specify the access password of the Redis server (optional). If omitted, `{self.default_pass}` is used."),
                dict(opt="svname", type=Options.T_STR, default=self.default_svname, required=True, multi=False, hide=True, choice=None, web="readonly",
                     description_ja="サーバーのサービス名を指定します。",
                     description_en="Specify the service name of the inference server."),
                dict(opt="retry_count", type=Options.T_INT, default=3, required=False, multi=False, hide=True, choice=None,
                     description_ja="Redisサーバーへの再接続回数を指定します。",
                     description_en="Specifies the number of reconnections to the Redis server."),
                dict(opt="retry_interval", type=Options.T_INT, default=5, required=False, multi=False, hide=True, choice=None,
                     description_ja="Redisサーバーに再接続までの秒数を指定します。",
                     description_en="Specifies the number of seconds before reconnecting to the Redis server."),
                dict(opt="timeout", type=Options.T_INT, default=600, required=False, multi=False, hide=True, choice=None,
                     description_ja="サーバーの応答が返ってくるまでの最大待ち時間を指定。",
                     description_en="Specify the maximum waiting time until the server responds."),
                dict(opt="runner_name", type=Options.T_STR, default=None, required=True, multi=False, hide=False, choice=None,
                    description_ja="Runner設定の名前を指定します。",
                    description_en="Specify the name of the Runner configuration."),
                dict(opt="user_name", type=Options.T_STR, default=None, required=True, multi=False, hide=False, choice=None,
                     description_ja="ユーザー名を指定します。",
                     description_en="Specify a user name."),
                dict(opt="session_id", type=Options.T_STR, default=None, required=False, multi=False, hide=False, choice=None,
                    description_ja="Runnerに送信するセッションIDを指定します。",
                    description_en="Specify the session ID to send to the Runner."),
                dict(opt="a2asv_apikey", type=Options.T_PASSWD, default=None, required=False, multi=False, hide=False, choice=None,
                    description_ja="A2A ServerのAPI Keyを指定します。",
                    description_en="Specify the API Key of the A2A Server.",),
                dict(opt="mcpserver_apikey", type=Options.T_PASSWD, default=None, required=False, multi=False, hide=False, choice=None,
                    description_ja="リモートMCPサーバーのAPI Keyを指定します。",
                    description_en="Specify the API Key of the remote MCP server.",),
                dict(opt="message", type=Options.T_TEXT, default=None, required=True, multi=False, hide=False, choice=None,
                    description_ja="Runnerに送信するメッセージを指定します。",
                    description_en="Specify the message to send to the Runner."),
                dict(opt="call_tts", type=Options.T_BOOL, default=False, required=False, multi=False, hide=True, choice=[True, False],
                    description_ja="TTS(Text-to-Speech)機能を実行するかどうかを指定します。",
                    description_en="Specify whether to execute the TTS (Text-to-Speech) feature."),
            ]
        )

    @validator.apprun_check
    def apprun(self, logger: logging.Logger, args: argparse.Namespace, tm: float, pf: List[Dict[str, float]] = []) -> Tuple[int, Dict[str, Any], Any]:

        payload = dict(runner_name=args.runner_name, user_name=args.user_name, session_id=args.session_id,
                       a2asv_apikey=args.a2asv_apikey, mcpserver_apikey=args.mcpserver_apikey, message=args.message,
                       call_tts=args.call_tts)
        payload_b64 = convert.str2b64str(common.to_str(payload))

        cl = client.Client(logger, redis_host=args.host, redis_port=args.port, redis_password=args.password, svname=args.svname)
        msg = dict(success=[], warn=[])
        for st, res in self.apprun_generate(logger, host=args.host, port=args.port, password=args.password, svname=args.svname,
                                            retry_interval=args.retry_interval, retry_count=args.retry_count, timeout=args.timeout,
                                            runner_name=args.runner_name, user_name=args.user_name, session_id=args.session_id,
                                            a2asv_apikey=args.a2asv_apikey, mcpserver_apikey=args.mcpserver_apikey, message=args.message, call_tts=args.call_tts):
            if st == self.RESP_SUCCESS:
                msg['success'].append(res)
            else:
                msg['warn'].append(res)
            
        if len(msg['success']) <= 0:
            del msg['success']
        if len(msg['warn']) > 0:
            return self.RESP_WARN, msg, cl
        return self.RESP_SUCCESS, msg, cl

    def apprun_generate(self, logger:logging.Logger, host:str, port:int, password:str, svname:str, retry_interval:int, retry_count:int, timeout:int,
                        runner_name:str, user_name:str, session_id:str, a2asv_apikey:str, mcpserver_apikey:str, message:str, call_tts:bool):
        """
        Agentチャットを実行します
        
        Args:
            logger (logging.Logger): ロガー
            host (str): Redisホスト
            port (int): Redisポート
            password (str): Redisパスワード
            svname (str): サービス名
            retry_interval (int): 再接続インターバル秒数
            retry_count (int): 再接続回数
            timeout (int): タイムアウト秒数
            runner_name (str): Runner設定名
            user_name (str): ユーザー名
            session_id (str): セッションID
            a2asv_apikey (str): A2A Server API Key
            mcpserver_apikey (str): MCPサーバーAPI Key
            message (str): メッセージ
            call_tts (bool): TTS機能を呼び出すかどうか
        Yields:
            Tuple[int, Any]: 処理結果ステータスと内容
        """
        payload = dict(runner_name=runner_name, user_name=user_name, session_id=session_id,
                       a2asv_apikey=a2asv_apikey, mcpserver_apikey=mcpserver_apikey, message=message,
                       call_tts=call_tts)
        payload_b64 = convert.str2b64str(common.to_str(payload))

        cl = client.Client(logger, redis_host=host, redis_port=port, redis_password=password, svname=svname)
        for res in cl.redis_cli.send_cmd_sse(self.get_svcmd(), [payload_b64],
                                             retry_count=retry_count, retry_interval=retry_interval, timeout=timeout, nowait=False):
            cls = self.output_schema()
            try:
                cls.model_validate(res)  # 結果のスキーマ検証
            except Exception as e:
                info = cls.get_model_info()
                res = dict(warn=dict(msg=f"Invalid result format: {e}.", output=res, schema=info))
                logger.warning(f"Invalid result format: {res}", exc_info=True)
            if 'success' in res:
                yield self.RESP_SUCCESS, res
            else:
                yield self.RESP_WARN, res

    def output_schema(self) -> type:
        class Ids(resdata.Base):
            agent_session_id: str = pydantic.Field(default=None, description="エージェントセッションID")
            event_id: str = pydantic.Field(default=None, description="イベントID")
            invocation_id: str = pydantic.Field(default=None, description="呼び出しID")
        class Flags(resdata.Base):
            final_response: bool = pydantic.Field(default=False, description="最終レスポンスフラグ")
            function_call: bool = pydantic.Field(default=False, description="関数呼び出しフラグ")
            function_response: bool = pydantic.Field(default=False, description="関数レスポンスフラグ")
        class Data(resdata.Data):
            ids: Union[Ids, None] = pydantic.Field(default=None, description="セッション・イベントID情報")
            flags: Union[Flags, None] = pydantic.Field(default=None, description="フラグ情報")
            message: Union[str, None] = pydantic.Field(default=None, description="メッセージ")
            wav_b64: Union[str, None] = pydantic.Field(default=None, description="Base64エンコードされたWAVデータ")
        class Result(resdata.Result):
            success: Union[Data, None] = pydantic.Field(default=None, description="成功した場合の結果")
        return Result

    def is_cluster_redirect(self):
        return False

    def create_agent(self, logger:logging.Logger, data_dir:Path, disable_remote_agent:bool,
                     agent_conf:Dict[str, Any], llm_conf:Dict[str, Any], mcpsv_confs:List[Dict[str, Any]]) -> Any:
        """
        エージェントを作成します

        Args:
            logger (logging.Logger): ロガー
            data_dir (Path): データディレクトリパス
            disable_remote_agent (bool): リモートエージェントを無効化するかどうか
            agent_conf (Dict[str, Any]): エージェント設定
            llm_conf (Dict[str, Any]): LLM設定
            mcpsv_confs (List[Dict[str, Any]]): MCPサーバー設定リスト

        Returns:
            Agent: エージェント
        """
        if logger.level == logging.DEBUG:
            logger.debug(f"create_agent processing..")
        description = agent_conf.get("agent_description", f"{self.ver.__appid__}に登録されているコマンド提供")
        instruction = agent_conf.get("agent_instruction", f"あなたはコマンドの意味を熟知しているエキスパートです。" + \
                      f"ユーザーがコマンドを実行したいとき、あなたは以下の手順に従ってコマンドを確実に実行してください。\n" + \
                      f"1. ユーザーのクエリからが実行したいコマンドを特定します。\n" + \
                      f"2. コマンド実行に必要なパラメータのなかで、ユーザーのクエリから取得できないものは、コマンド定義にあるデフォルト値を指定して実行してください。\n" + \
                      f"3. もしエラーが発生した場合は、ユーザーにコマンド名とパラメータとエラー内容を提示してください。\n" \
                      f"4. コマンドの実行結果は、json文字列で出力するようにしてください。この時json文字列は「```json」と「```」で囲んだ文字列にしてください。\n")

        if logger.level == logging.DEBUG:
            logger.debug(f"google-adk loading..")
        from google.adk.agents import Agent as AdkAgent
        # App name mismatch警告を回避するためのラッパークラス
        class Agent(AdkAgent):
            pass

        if logger.level == logging.DEBUG:
            logger.debug(f"litellm loading..")
        from google.adk.models import lite_llm
        import litellm
        #from litellm import _logging
        #_logging._turn_on_debug()

        # loggerの初期化
        common.reset_logger("LiteLLM Proxy")
        common.reset_logger("LiteLLM Router")
        common.reset_logger("LiteLLM")
        common.reset_logger("litellm")
        common.reset_logger("httpcore")
        common.reset_logger("httpx")
        common.reset_logger("openai")
        #litellm.suppress_debug_info = True
        # 各種設定値の取得
        agent_name = agent_conf.get('agent_name', None)
        agent_type = agent_conf.get('agent_type', None)
        use_planner = agent_conf.get('use_planner', False)
        a2asv_baseurl = agent_conf.get('a2asv_baseurl', "http://localhost:8071/a2a")
        a2asv_delegated_auth = agent_conf.get('a2asv_delegated_auth', False)
        a2asv_apikey = agent_conf.get('a2asv_apikey', None)
        agent_subagents = agent_conf.get('subagents', None)

        def create_subagent(data_dir:Path, agent_name:str) -> Any:
            agent_conf = self._load_agent_config(data_dir, agent_name)
            if agent_conf.get('llm', None) is not None:
                llm_conf = self._load_llm_config(data_dir, agent_conf['llm'])
            else:
                llm_conf = {}

            if agent_conf.get('mcpservers', None) is not None:
                mcpsv_confs = self._load_mcpsv_config(data_dir, agent_conf['mcpservers'])
            else:
                mcpsv_confs = []
            return self.create_agent(logger, data_dir, disable_remote_agent, agent_conf, llm_conf, mcpsv_confs)

        agent_subagents = agent_subagents if agent_subagents is not None else []
        subagents = []
        if 'subagents' in agent_conf and isinstance(agent_subagents, list):
            for subagent_name in agent_subagents:
                subagent_obj = create_subagent(data_dir, subagent_name)
                if subagent_obj is not None:
                    subagents.append(subagent_obj)

        llmprov = llm_conf.get('llmprov', None)
        if agent_type == 'remote' and not disable_remote_agent:
            from google.adk.agents.remote_a2a_agent import RemoteA2aAgent, AGENT_CARD_WELL_KNOWN_PATH
            from a2a.client.client_factory import ClientConfig, ClientFactory
            import httpx

            def _create_dynamic_header_provider():
                async def add_auth_headers(request):
                    scope = signin.get_request_scope()
                    if scope is not None and a2asv_delegated_auth:
                        apikey = scope["a2asv_apikey"] if scope["a2asv_apikey"] is not None else a2asv_apikey
                        request.headers['Authorization'] = f'Bearer {apikey}'
                    if a2asv_apikey is not None:
                        request.headers['Authorization'] = f'Bearer {a2asv_apikey}'
                return add_auth_headers
            custom_httpx_client = httpx.AsyncClient(
                follow_redirects=True,
                timeout=httpx.Timeout(600.0),
                event_hooks={'request': [_create_dynamic_header_provider()]}
            )
            config = ClientConfig(httpx_client=custom_httpx_client)
            factory = ClientFactory(config=config)
            agent = RemoteA2aAgent(
                name=agent_name,
                agent_card=a2asv_baseurl + AGENT_CARD_WELL_KNOWN_PATH,
                a2a_client_factory=factory,
            )
            if logger.level == logging.DEBUG:
                logger.debug(f"create_agent complate.")
            return agent
        elif llmprov == 'openai':
            llmmodel = llm_conf.get('llmmodel', None)
            llmapikey = llm_conf.get('llmapikey', None)
            llmendpoint = llm_conf.get('llmendpoint', None)
            if llmmodel is None: raise ValueError("llmmodel is required.")
            if llmapikey is None: raise ValueError("llmapikey is required.")
            from google.adk.planners import PlanReActPlanner
            agent = Agent(
                name=agent_name,
                model=lite_llm.LiteLlm(
                    model=llmmodel,
                    api_key=llmapikey,
                    endpoint=llmendpoint,
                ),
                description=description,
                instruction=instruction,
                planner=PlanReActPlanner() if use_planner else None,
                tools=self.create_tool_mcpsv(logger, mcpsv_confs),
                sub_agents=subagents,
            )
        elif llmprov == 'azureopenai':
            llmmodel = llm_conf.get('llmmodel', None)
            llmapikey = llm_conf.get('llmapikey', None)
            llmendpoint = llm_conf.get('llmendpoint', None)
            llmapiversion = llm_conf.get('llmapiversion', None)
            if llmmodel is None: raise ValueError("llmmodel is required.")
            if llmendpoint is None: raise ValueError("llmendpoint is required.")
            if "/openai/deployments" in llmendpoint:
                llmendpoint = llmendpoint.split("/openai/deployments")[0]
            if llmapikey is None: raise ValueError("llmapikey is required.")
            if llmapiversion is None: raise ValueError("llmapiversion is required.")
            from google.adk.planners import PlanReActPlanner
            if not llmmodel.startswith("azure/"):
                llmmodel = f"azure/{llmmodel}"
            agent = Agent(
                name=agent_name,
                model=lite_llm.LiteLlm(
                    model=llmmodel,
                    api_key=llmapikey,
                    api_base=llmendpoint,
                    api_version=llmapiversion,
                    base_url=llmendpoint,
                ),
                description=description,
                instruction=instruction,
                planner=PlanReActPlanner() if use_planner else None,
                tools=self.create_tool_mcpsv(logger, mcpsv_confs),
                sub_agents=subagents,
            )
        elif llmprov == 'vertexai':
            llmprojectid = llm_conf.get('llmprojectid', None)
            llmsvaccountfile = llm_conf.get('llmsvaccountfile', None)
            llmmodel = llm_conf.get('llmmodel', None)
            llmlocation = llm_conf.get('llmlocation', None)
            llmsvaccountfile_data = llm_conf.get('llmsvaccountfile_data', {})
            llmtemperature = llm_conf.get('llmtemperature', None)
            llmseed = llm_conf.get('llmseed', None)
            if llmmodel is None: raise ValueError("llmmodel is required.")
            if llmlocation is None: raise ValueError("llmlocation is required.")
            if llmsvaccountfile_data is None: raise ValueError("llmsvaccountfile_data is required.")
            from google.adk.planners import BuiltInPlanner
            from google.genai import types
            agent = Agent(
                name=agent_name,
                model=lite_llm.LiteLlm(
                    model=llmmodel,
                    #vertex_project=llmprojectid,
                    vertex_credentials=llmsvaccountfile_data,
                    vertex_location=llmlocation,
                    seed=llmseed,
                    temperature=llmtemperature,
                ),
                description=description,
                instruction=instruction,
                planner=BuiltInPlanner(thinking_config=types.ThinkingConfig(
                    include_thoughts=True,
                    thinking_budget=1024,
                )) if use_planner else None,
                tools=self.create_tool_mcpsv(logger, mcpsv_confs),
                sub_agents=subagents,
            )
        elif llmprov == 'ollama':
            llmmodel = llm_conf.get('llmmodel', None)
            llmendpoint = llm_conf.get('llmendpoint', None)
            llmtemperature = llm_conf.get('llmtemperature', None)
            if llmmodel is None: raise ValueError("llmmodel is required.")
            if llmendpoint is None: raise ValueError("llmendpoint is required.")
            from google.adk.planners import PlanReActPlanner
            agent = Agent(
                name=agent_name,
                model=lite_llm.LiteLlm(
                    model=f"ollama/{llmmodel}",
                    api_base=llmendpoint,
                    temperature=llmtemperature,
                    stream=True
                ),
                description=description,
                instruction=instruction,
                planner=PlanReActPlanner() if use_planner else None,
                tools=self.create_tool_mcpsv(logger, mcpsv_confs),
                sub_agents=subagents,
            )
        elif disable_remote_agent:
            return None
        else:
            raise ValueError("llmprov is required.")
        if logger.level == logging.DEBUG:
            logger.debug(f"create_agent complate.")
        return agent

    def create_tool_mcpsv(self, logger:logging.Logger, mcpsv_confs:List[Dict[str, Any]]) -> List[Any]:
        """
        MCPサーバーツールを作成します
        Args:
            logger (logging.Logger): ロガー
            mcpsv_confs (List[Dict[str, Any]]): MCPサーバー設定リスト
        Returns:
            List[MCPToolset]: MCPToolsetのリスト
        """
        from fastapi.openapi.models import HTTPBearer, SecuritySchemeType
        from google.adk.auth.auth_credential import AuthCredential, AuthCredentialTypes
        from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset
        from google.adk.tools.mcp_tool.mcp_session_manager import SseConnectionParams, StreamableHTTPConnectionParams
        from google.adk.agents.readonly_context import ReadonlyContext
        from google.adk.tools.preload_memory_tool import PreloadMemoryTool

        auth_scheme = HTTPBearer()
        tools = [PreloadMemoryTool()]
        for mcpsv_conf in mcpsv_confs:
            mcpserver_url = mcpsv_conf.get('mcpserver_url', None)
            mcpserver_apikey = mcpsv_conf.get('mcpserver_apikey', None)
            mcpserver_delegated_auth = mcpsv_conf.get('mcpserver_delegated_auth', False)
            mcpserver_transport = mcpsv_conf.get('mcpserver_transport', 'streamable-http')  # sse
            auth_cred = AuthCredential(auth_type=AuthCredentialTypes.HTTP)
            if mcpserver_transport == 'sse':
                conn_params = SseConnectionParams(
                    url=mcpserver_url,
                    timeout=120,
                    sse_read_timeout=600,
                )
            else:
                conn_params = StreamableHTTPConnectionParams(
                    url=mcpserver_url,
                    timeout=120,
                    sse_read_timeout=600,
                )
            if self.call_a2asv_start and mcpserver_apikey is not None:
                conn_params.headers = dict(Authorization=f"Bearer {mcpserver_apikey}")
            def _warp(mcpserver_apikey:str, mcpserver_delegated_auth:bool):
                # mcpserver_delegated_auth=Trueの場合、chatコマンド実行時に、
                # Signin情報からapikeyを取得してMCPサーバーに転送するためのヘッダープロバイダー
                def header_provider(readonly_context:ReadonlyContext) -> Dict[str, str]:
                    scope = signin.get_request_scope()
                    # delegated_authが有効な場合、Signin情報からapikeyを取得して使用
                    if scope is not None and mcpserver_delegated_auth and scope.get("mcpserver_apikey", None) is not None:
                        return dict(Authorization=f"Bearer {scope['mcpserver_apikey']}")
                    # delegated_authが無効な場合、設定済みのAPIKeyを使用
                    elif not mcpserver_delegated_auth and mcpserver_apikey is not None:
                        return dict(Authorization=f"Bearer {mcpserver_apikey}")
                    # fastmcp経由で来たときはreqヘッダーからAuthorizationを取得して転送
                    elif mcpserver_delegated_auth and 'req' in scope and 'headers' in scope['req']:
                        req_headers = scope['req'].headers
                        if 'authorization' in req_headers:
                            return dict(Authorization=req_headers['authorization'])
                    return {}
                return header_provider
            toolset = MCPToolset(
                connection_params=conn_params,
                tool_filter=mcpsv_conf.get('mcpserver_mcp_tools', []),
                auth_scheme=auth_scheme,
                auth_credential=auth_cred,
                header_provider=_warp(mcpserver_apikey, mcpserver_delegated_auth),
            )
            tools.append(toolset)
        return tools

    async def svrun(self, data_dir:Path, logger:logging.Logger, redis_cli:redis_client.RedisClient, msg:List[str],
                    sessions:Dict[str, Dict[str, Any]]):
        reskey = msg[1]
        runner = None
        tts_engine_obj = None
        enable_tts = True
        try:
            payload = json.loads(convert.b64str2str(msg[2]))
            name = payload.get('runner_name')
            user_name = payload.get('user_name')
            session_id = payload.get('session_id')
            a2asv_apikey = payload.get('a2asv_apikey')
            mcpserver_apikey = payload.get('mcpserver_apikey')
            message = payload.get('message')
            call_tts = payload.get('call_tts')

            from google.adk.agents.run_config import RunConfig, StreamingMode
            from google.adk.runners import Runner
            from google.genai import types

            json_pattern = re.compile(r'\{.*?\}')
            runner_conf, agent_conf, llm_conf, memory_conf, memory_llm_conf, memory_embed_conf, mcpsv_confs = self.load_conf(name, data_dir, logger)
            agent = self.create_agent(logger, data_dir, False, agent_conf, llm_conf, mcpsv_confs)
            memory_service = self.memory.create_memory_service(data_dir, logger, memory_conf, memory_llm_conf, memory_embed_conf, sessions)
            runner = Runner(
                app_name=runner_conf.get('runner_name', self.ver.__appid__),
                agent=agent,
                session_service=self.create_session_service(data_dir, logger, runner_conf),
                memory_service=memory_service,
            )
            content = types.Content(role='user', parts=[types.Part(text=message)])
            tts_engine = runner_conf.get('tts_engine', None)
            voicevox_model = runner_conf.get('voicevox_model', None)
            enable_tts = call_tts and tts_engine and voicevox_model
            if enable_tts:
                try:
                    # TTSモデルの準備
                    tts_engine_obj = cmdbox_tts_say.TtsSay.tts_start(data_dir, tts_engine, voicevox_model)
                except Exception as e:
                    logger.warning(f"Failed to prepare TTS model: {e}", exc_info=True)
                    enable_tts = False

            short_mem_msg = f"The following is an instruction from {user_name}: {message}\n\n=====\n\n"
            # セッションを作成する
            agent_session = await self.create_agent_session(runner.session_service, runner.app_name,
                                                       user_name, session_id=session_id)
            # チャットを実行する
            signin.set_request_scope(dict(mcpserver_apikey=mcpserver_apikey, a2asv_apikey=a2asv_apikey))
            run_config = RunConfig(streaming_mode=StreamingMode.NONE)
            async with aclosing(runner.run_async(user_id=user_name,
                                                 session_id=agent_session.id,
                                                 new_message=content,
                                                 state_delta=None,
                                                 run_config=run_config)) as run_iter:
                try:
                    async for event in run_iter:
                        outputs = dict(success=dict(),)
                        success = outputs['success']
                        ids = outputs['success']['ids'] = dict()
                        ids['agent_session_id'] = agent_session.id
                        ids['event_id'] = event.id
                        ids['invocation_id'] = event.invocation_id
                        flags = outputs['success']['flags'] = dict()
                        if event.turn_complete:
                            flags['turn_complete'] = True
                        if event.interrupted:
                            flags['interrupted'] = True
                        msg, is_func_call, is_func_response, is_final_response = self.gen_msg(event)
                        flags['final_response'] = is_final_response
                        flags['function_call'] = is_func_call
                        flags['function_response'] = is_func_response
                        if msg:
                            success['message'] = msg
                            options.Options.getInstance().audit_exec(body=dict(agent_session=agent_session.id, result=msg),
                                                                        audit_type=options.Options.AT_USER, user=user_name)
                            if enable_tts and tts_engine_obj and not is_func_call and not is_func_response:
                                tts_msg = re.sub(r'```json.*?```', '', msg, flags=re.DOTALL) # json表現部分を除去
                                try:
                                    wav_b64 = cmdbox_tts_say.TtsSay.tts_say(tts_engine_obj, tts_msg) \
                                        if tts_msg is not None and tts_msg.strip() != '' else None
                                    success['wav_b64'] = wav_b64
                                except Exception as e:
                                    success['wav_b64'] = None
                            if msg is not None and msg.strip() != '':
                                mem_msg = re.sub(r'```json.*?```', '', msg, flags=re.DOTALL) # json表現部分を除去
                                short_mem_msg += f"The following is an instruction from {event.author}: {mem_msg}\n\n=====\n\n" \
                                    if mem_msg is not None and mem_msg.strip() != '' else ''
                            redis_cli.rpush(reskey, outputs)
                            if flags['final_response']:
                                if 'llm' in memory_conf and memory_conf['llm'] is not None \
                                    and 'memory_instruction' in memory_conf and memory_conf['memory_instruction'] is not None:
                                    # 要約文生成
                                    sammary_msg = await self.memory.summary(data_dir=data_dir, logger=logger,
                                                                            llmname=memory_conf['llm'], short_mem_msg=short_mem_msg,
                                                                            msg_text_system=memory_conf['memory_instruction'])
                                    sdata = sammary_msg.get('success', {}).get('data', None) if sammary_msg else None
                                    sammary_msg = sdata[-1] if sdata and isinstance(sdata, list) and len(sdata) > 0 else None
                                    # メモリーにセッションを保存する
                                    if sammary_msg:
                                        await self.memory.add_memory(memory_service, agent_session, sammary_msg.get('content', ''))
                                break

                except Exception as e:
                    outputs = dict(success=dict(flags=dict(final_response=True, function_call=False, function_response=False),
                                                message=str(e),
                                                ids=dict(agent_session_id=agent_session.id)),)
                    redis_cli.rpush(reskey, outputs)
                    raise e
            msg = dict(success=dict(message=f"Chat '{name}' successfully."), end=True)
            redis_cli.rpush(reskey, msg)
            await run_iter.aclose()
            return self.RESP_SUCCESS

        except Exception as e:
            msg = dict(warn=f"{self.get_mode()}_{self.get_cmd()}: {e}", end=True)
            logger.warning(f"{self.get_mode()}_{self.get_cmd()}: {e}", exc_info=True)
            redis_cli.rpush(reskey, msg)
            return self.RESP_WARN
        finally:
            if enable_tts:
                # TTSモデルの停止
                cmdbox_tts_say.TtsSay.tts_stop(tts_engine_obj)
            if runner:
                if hasattr(runner.session_service, 'db_engine'):
                    await runner.session_service.db_engine.dispose()
                await runner.close()
