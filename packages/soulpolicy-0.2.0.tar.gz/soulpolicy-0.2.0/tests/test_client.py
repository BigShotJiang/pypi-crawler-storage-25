"""Python SDK 单测 — 用 pytest-httpx mock 不依赖真实服务。"""
from __future__ import annotations

import json

import pytest

from soulpolicy import (
    AuthenticationError,
    Client,
    IdempotencyError,
    InvalidRequestError,
    NotFoundError,
)
from soulpolicy import SoulPolicyPermissionError as PermissionError


@pytest.fixture
def client():
    return Client(api_key="sk_live_test", base_url="http://api.test")


def _err(type_: str, code: str, message: str) -> dict:
    return {"error": {"type": type_, "code": code, "message": message, "request_id": "req_x"}}


def test_baseline_create_success(httpx_mock, client):
    httpx_mock.add_response(
        method="POST",
        url="http://api.test/api/v2/baselines",
        json={
            "id": "bl_x", "label": "test", "distance_mode": "cosine",
            "embedding_model": "all-MiniLM-L6", "sample_count": 5,
            "z_warn": 2.0, "z_critical": 3.0, "ewma_alpha": 0.3,
            "fingerprint": "sha256:abc", "created_at": 1745740800,
        },
    )
    bl = client.baselines.create(samples=["a", "b", "c", "d", "e"], label="test")
    assert bl.id == "bl_x"
    assert bl.fingerprint == "sha256:abc"


def test_drift_check_success(httpx_mock, client):
    httpx_mock.add_response(
        method="POST",
        url="http://api.test/api/v2/drift_checks",
        json={
            "id": "dc_x", "created_at": 0, "score": 0.5, "z_score": 1.0,
            "severity": "warn", "ema": 0.0, "decision": "trigger_review",
            "distance_cosine": 0.5, "distance_mahalanobis": None,
            "role_axis_score": None, "evidence": {"nearest_baseline_samples": []},
            "reproducibility": {"input_hash": "sha256:y", "algo_version": "drift_v2.1.0"},
            "latency_ms": 50,
        },
    )
    r = client.drift_checks.check(text="hello", baseline="bl_x")
    assert r.id == "dc_x"
    assert r.severity == "warn"
    assert r.reproducibility["algo_version"] == "drift_v2.1.0"


def test_replay_self_consistent(httpx_mock, client):
    httpx_mock.add_response(
        method="POST",
        url="http://api.test/api/v2/drift_checks/replay",
        json={
            "matched": True,
            "diff": {},
            "result": {
                "id": "dc_y", "created_at": 0, "score": 0.5, "z_score": 1.0,
                "severity": "warn", "ema": 0.0, "decision": "trigger_review",
                "distance_cosine": 0.5, "distance_mahalanobis": None,
                "role_axis_score": None, "evidence": {},
                "reproducibility": {}, "latency_ms": 5,
            },
        },
    )
    rep = client.drift_checks.replay(
        text="hello", baseline="bl_x", reproducibility={"input_hash": "sha256:y"}
    )
    assert rep.matched
    assert rep.result.severity == "warn"


def test_feedback_success(httpx_mock, client):
    httpx_mock.add_response(
        method="POST",
        url="http://api.test/api/v2/drift_checks/dc_x/feedback",
        json={
            "id": "fb_1", "target_id": "dc_x", "label": "true_positive",
            "created_at": 0, "primitive": "drift_check",
        },
    )
    fb = client.drift_checks.feedback("dc_x", label="true_positive")
    assert fb.target_id == "dc_x"
    assert fb.label == "true_positive"


def test_auth_error_raises(httpx_mock, client):
    httpx_mock.add_response(
        method="POST",
        url="http://api.test/api/v2/baselines",
        status_code=401,
        json=_err("authentication_error", "invalid_api_key", "bad key"),
    )
    with pytest.raises(AuthenticationError) as ei:
        client.baselines.create(samples=["a", "b", "c"])
    assert ei.value.code == "invalid_api_key"


def test_permission_error_raises(httpx_mock, client):
    httpx_mock.add_response(
        method="POST",
        url="http://api.test/api/v2/baselines",
        status_code=403,
        json=_err("permission_error", "missing_scope", "missing scope: baseline.write"),
    )
    with pytest.raises(PermissionError):
        client.baselines.create(samples=["a", "b", "c"])


def test_not_found_raises(httpx_mock, client):
    httpx_mock.add_response(
        method="GET",
        url="http://api.test/api/v2/baselines/bl_missing",
        status_code=404,
        json=_err("invalid_request_error", "resource_missing", "baseline 'bl_missing' not found"),
    )
    with pytest.raises(NotFoundError):
        client.baselines.retrieve("bl_missing")


def test_idempotency_conflict_raises(httpx_mock, client):
    httpx_mock.add_response(
        method="POST",
        url="http://api.test/api/v2/drift_checks",
        status_code=409,
        json=_err("idempotency_error", "idempotency_request_mismatch", "..."),
    )
    with pytest.raises(IdempotencyError):
        client.drift_checks.check(text="x", baseline="bl_y")


def test_validation_error_raises_invalid_request(httpx_mock, client):
    httpx_mock.add_response(
        method="POST",
        url="http://api.test/api/v2/baselines",
        status_code=422,
        json=_err("invalid_request_error", "validation_error", "samples: min length 3"),
    )
    with pytest.raises(InvalidRequestError):
        client.baselines.create(samples=["only one"])


def test_5xx_retries_then_raises_apierror(httpx_mock, client):
    """SDK 重试 5xx 直到耗尽，然后抛 APIError。"""
    for _ in range(client.max_retries + 1):
        httpx_mock.add_response(
            method="POST",
            url="http://api.test/api/v2/drift_checks",
            status_code=503,
            json=_err("api_error", "internal_error", "down"),
        )
    from soulpolicy import APIError

    with pytest.raises(APIError):
        client.drift_checks.check(text="x", baseline="bl_y")


def test_idempotency_key_auto_generated(httpx_mock, client):
    httpx_mock.add_response(
        method="POST",
        url="http://api.test/api/v2/baselines",
        json={
            "id": "bl_x", "label": None, "distance_mode": "cosine",
            "embedding_model": "x", "sample_count": 3, "z_warn": 2.0,
            "z_critical": 3.0, "ewma_alpha": 0.3, "fingerprint": "sha256:1",
            "created_at": 0,
        },
    )
    client.baselines.create(samples=["a", "b", "c"])
    req = httpx_mock.get_requests()[0]
    assert "Idempotency-Key" in req.headers
    assert req.headers["Idempotency-Key"].startswith("sdk-auto-")


def test_snapshot_create_retrieve_restore(httpx_mock, client):
    sn_body = {
        "id": "sn_x", "object": "snapshot", "session_id": "s1", "turn_index": 2,
        "context_hash": "sha256:abc", "has_kv_blob": True, "health_score": 0.9,
        "snapshot_format": "1", "provider_mode": "noop",
        "last_restored_at": None, "restore_count": 0, "created_at": 0,
    }
    httpx_mock.add_response(method="POST", url="http://api.test/api/v2/snapshots", json=sn_body)
    httpx_mock.add_response(method="GET", url="http://api.test/api/v2/snapshots/sn_x", json=sn_body)
    httpx_mock.add_response(
        method="POST",
        url="http://api.test/api/v2/snapshots/sn_x/restore",
        json={
            "id": "rs_x", "object": "snapshot_restore", "snapshot": "sn_x",
            "ok": True, "session_id": "s1", "restored_turn": 2,
            "restored_context_hash": "sha256:abc", "provider_mode": "noop",
            "error": None, "created_at": 0,
        },
    )
    sn = client.snapshots.create(session_id="s1", turn_index=2, context_text="ctx")
    assert sn.id == "sn_x"
    assert sn.has_kv_blob is True
    got = client.snapshots.retrieve("sn_x")
    assert got.session_id == "s1"
    rs = client.snapshots.restore("sn_x")
    assert rs.ok is True
    assert rs.snapshot == "sn_x"


def test_policy_and_guardrail(httpx_mock, client):
    httpx_mock.add_response(
        method="POST", url="http://api.test/api/v2/policies",
        json={
            "id": "pol_x", "object": "policy", "name": "p", "description": None,
            "rule_count": 1, "version": 1, "fingerprint": "sha256:p", "created_at": 0,
        },
    )
    httpx_mock.add_response(
        method="POST", url="http://api.test/api/v2/guardrail_evals",
        json={
            "id": "ge_x", "object": "guardrail_eval", "created_at": 0,
            "decision": "block", "severity": "high",
            "violated": [{"rule_id": "r1"}],
            "redacted_text": "We [REDACTED] returns",
            "evidence": {}, "reproducibility": {"algo_version": "guardrail_v1.0.0"},
            "latency_ms": 10,
        },
    )
    pol = client.policies.create(
        name="p",
        rules=[{"rule_id": "r1", "name": "no_promise", "severity": "high",
                "when": {"keywords": ["guarantee"]}}],
    )
    assert pol.id == "pol_x"
    ge = client.guardrail_evals.eval(text="we guarantee returns", policy="pol_x")
    assert ge.decision == "block"
    assert "[REDACTED]" in (ge.redacted_text or "")


def test_audit_proof(httpx_mock, client):
    httpx_mock.add_response(
        method="GET",
        url="http://api.test/api/v2/audit/proof?primitive=drift_check&request_id=dc_y",
        json={
            "request_id": "dc_y", "primitive": "drift_check", "day": "2026-04-26",
            "leaf_hash": "sha256:leaf", "merkle_root": "sha256:root",
            "proof": [{"position": "right", "hash": "sha256:sib"}],
            "verified": True,
        },
    )
    p = client.audit.proof(primitive="drift_check", request_id="dc_y")
    assert p.verified is True
    assert p.merkle_root == "sha256:root"


def test_verify_cli_accepts_valid_proof(tmp_path):
    """soulpolicy-verify CLI 离线复算验证。"""
    import hashlib
    import sys

    from soulpolicy._verify import verify_inclusion, main as verify_main

    leaves = [f"sha256:{i:064x}" for i in range(4)]

    def H(a, b):
        a, b = a.removeprefix("sha256:"), b.removeprefix("sha256:")
        return "sha256:" + hashlib.sha256((a + b).encode()).hexdigest()

    p01 = H(leaves[0], leaves[1])
    p23 = H(leaves[2], leaves[3])
    root = H(p01, p23)

    proof = {
        "request_id": "dc_abc",
        "primitive": "drift_check",
        "day": "2026-04-26",
        "leaf_hash": leaves[0],
        "merkle_root": root,
        "proof": [
            {"position": "right", "hash": leaves[1]},
            {"position": "right", "hash": p23},
        ],
        "verified": True,
    }
    assert verify_inclusion(proof) is True

    proof_bad = {**proof, "leaf_hash": "sha256:" + ("f" * 64)}
    assert verify_inclusion(proof_bad) is False

    p = tmp_path / "proof.json"
    p.write_text(json.dumps(proof))
    sys.argv = ["soulpolicy-verify", str(p)]
    assert verify_main() == 0


def test_idempotency_key_manual_override(httpx_mock, client):
    httpx_mock.add_response(
        method="POST",
        url="http://api.test/api/v2/drift_checks",
        json={
            "id": "dc_x", "created_at": 0, "score": 0, "z_score": 0,
            "severity": "ok", "ema": 0, "decision": "pass",
            "distance_cosine": None, "distance_mahalanobis": None,
            "role_axis_score": None, "evidence": {}, "reproducibility": {},
            "latency_ms": 1,
        },
    )
    client.drift_checks.check(
        text="x", baseline="bl_y", idempotency_key="my-key-7"
    )
    req = httpx_mock.get_requests()[0]
    assert req.headers["Idempotency-Key"] == "my-key-7"
