"""离线 Merkle proof 验证 CLI。

用法：
    soulpolicy-verify proof.json
    cat proof.json | soulpolicy-verify -

输入：从 GET /api/v2/audit/proof 拿到的 JSON。
输出：✓ verified / ✗ tampered。退出码：0 = 验证通过，1 = 失败。

不需要联网、不需要 API key、不需要 SoulPolicy 服务可达。完全本地复算。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from typing import Any


def _sha256_hex(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _hash_pair(left: str, right: str) -> str:
    a = left.removeprefix("sha256:")
    b = right.removeprefix("sha256:")
    return "sha256:" + _sha256_hex(a + b)


def verify_inclusion(proof: dict[str, Any]) -> bool:
    leaf = proof["leaf_hash"]
    expected = proof["merkle_root"]
    cur = leaf
    for step in proof.get("proof", []):
        sibling = step["hash"]
        if step["position"] == "left":
            cur = _hash_pair(sibling, cur)
        else:
            cur = _hash_pair(cur, sibling)
    return cur == expected


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="soulpolicy-verify",
        description=(
            "Offline verifier for SoulPolicy Merkle inclusion proofs. "
            "Reads a JSON file (or stdin with '-') from GET /api/v2/audit/proof "
            "and recomputes the Merkle root locally — no network, no API key needed."
        ),
    )
    parser.add_argument("path", help="proof json file path; '-' for stdin")
    args = parser.parse_args()

    if args.path == "-":
        raw = sys.stdin.read()
    else:
        with open(args.path, encoding="utf-8") as f:
            raw = f.read()

    try:
        proof = json.loads(raw)
    except json.JSONDecodeError as e:
        print(f"✗ invalid JSON: {e}", file=sys.stderr)
        return 2

    required = {"leaf_hash", "merkle_root", "proof", "request_id"}
    missing = required - proof.keys()
    if missing:
        print(f"✗ missing fields: {sorted(missing)}", file=sys.stderr)
        return 2

    ok = verify_inclusion(proof)
    if ok:
        print("✓ verified")
        print(f"  request_id : {proof['request_id']}")
        print(f"  primitive  : {proof.get('primitive', '?')}")
        print(f"  day        : {proof.get('day', '?')}")
        print(f"  leaf       : {proof['leaf_hash']}")
        print(f"  root       : {proof['merkle_root']}")
        print(f"  proof len  : {len(proof['proof'])}")
        return 0
    print("✗ TAMPERED — recomputed root does not match published root")
    print(f"  request_id : {proof['request_id']}")
    print(f"  expected   : {proof['merkle_root']}")
    return 1


if __name__ == "__main__":
    sys.exit(main())
