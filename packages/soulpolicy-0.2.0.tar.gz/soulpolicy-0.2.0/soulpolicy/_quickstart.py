"""5 分钟交互式 onboarding：

    soulpolicy-quickstart [--api-key sk_live_xxx]

流程：
  1. 校验 API key（GET /v2/usage 试一次）
  2. 引导收集 5+ 条 healthy 样本
  3. 创建 baseline + 自动跑 baseline_report
  4. 让用户输入待检文本，跑 drift_check
  5. 引导回标
  6. 给 reproducibility 包，告诉用户怎么 verify
"""
from __future__ import annotations

import argparse
import os
import sys
import textwrap
from typing import Any

from soulpolicy import (
    AuthenticationError,
    Client,
    InvalidRequestError,
    NotFoundError,
    SoulPolicyError,
)


def _input_multiline_until_blank(prompt: str) -> str:
    print(prompt)
    lines: list[str] = []
    while True:
        try:
            line = input()
        except EOFError:
            break
        if not line.strip():
            break
        lines.append(line)
    return "\n".join(lines).strip()


def _banner(title: str) -> None:
    print("\n" + "=" * 60)
    print(f"  {title}")
    print("=" * 60)


def _wait_enter() -> None:
    try:
        input("(按 Enter 继续) ")
    except EOFError:
        pass


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="soulpolicy-quickstart",
        description="Interactive 5-minute onboarding for SoulPolicy.",
    )
    parser.add_argument(
        "--api-key",
        default=os.environ.get("SOULPOLICY_API_KEY"),
        help="sk_live_xxx; will read SOULPOLICY_API_KEY env if omitted",
    )
    parser.add_argument(
        "--base-url", default=os.environ.get("SOULPOLICY_BASE_URL", "https://api.soulpolicy.cc")
    )
    args = parser.parse_args()

    if not args.api_key:
        print("✗ no API key. Set SOULPOLICY_API_KEY or pass --api-key.", file=sys.stderr)
        return 2

    sp = Client(api_key=args.api_key, base_url=args.base_url)

    # ---------- 1) 校验 ----------
    _banner("Step 1/5  ·  Verify API key")
    try:
        # 用 baselines.retrieve 一个不存在的 id 来"无副作用地"打通鉴权层
        sp.baselines.retrieve("bl_quickstart_probe")
    except NotFoundError:
        print("✓ key OK (got expected 404 on probe)")
    except AuthenticationError:
        print("✗ key rejected. Double-check sk_live_xxx and try again.", file=sys.stderr)
        return 2
    except SoulPolicyError as e:
        # 其它错误（403 scope / 5xx）也算证明 key 通了鉴权层
        if e.status_code in (403, 500, 502, 503):
            print(f"⚠ key OK but got {e.status_code} — continuing")
        else:
            print(f"✗ unexpected error: {e!r}", file=sys.stderr)
            return 2

    # ---------- 2) 收集 baseline 样本 ----------
    _banner("Step 2/5  ·  Collect 5+ healthy samples")
    print(textwrap.dedent("""
        粘贴 5+ 条「正常」的 LLM 输出。每行一条，**空行结束**。
        建议：从你过去客户满意的回复里挑，不要只挑模板。
    """))
    samples: list[str] = []
    while len(samples) < 5:
        s = input(f"sample #{len(samples)+1}: ").strip()
        if not s:
            if len(samples) >= 5:
                break
            print(f"  请至少 5 条，再加 {5 - len(samples)} 条")
            continue
        samples.append(s)

    print(f"✓ collected {len(samples)} samples")
    label = input("baseline label (e.g. customer_support_v1) [skip]: ").strip() or None

    # ---------- 3) 建 baseline + report ----------
    _banner("Step 3/5  ·  Create baseline + auto-report")
    try:
        bl = sp.baselines.create(samples=samples, label=label, distance_mode="cosine")
    except InvalidRequestError as e:
        print(f"✗ create failed: {e}", file=sys.stderr)
        return 1
    print(f"✓ baseline = {bl.id}")
    print(f"  fingerprint = {bl.fingerprint}")

    try:
        report = sp.baselines.report(bl.id)
        print(f"\n  Report:")
        print(f"    AUC                = {report.auc}")
        print(f"    FP rate at z_warn  = {report.fp_rate_at_warn}")
        print(f"    FN rate at z_warn  = {report.fn_rate_at_warn}")
        for n in report.notes[:5]:
            print(f"    • {n}")
    except SoulPolicyError as e:
        print(f"⚠ report unavailable: {e}")

    # ---------- 4) 第一次 drift_check ----------
    _banner("Step 4/5  ·  First drift_check")
    text = input("\n粘贴一段你想检查的 LLM 输出: ").strip()
    if not text:
        print("✗ skipped")
        return 0
    r = sp.drift_checks.check(text=text, baseline=bl.id)
    print(f"\n  id          = {r.id}")
    print(f"  severity    = {r.severity}")
    print(f"  z_score     = {r.z_score:+.3f}")
    print(f"  decision    = {r.decision}")
    nearest = r.evidence.get("nearest_baseline_samples", [])
    if nearest:
        print(f"  nearest baseline preview:")
        for s in nearest[:2]:
            print(f"    • {s.get('preview', '')[:80]}")
    print(f"\n  reproducibility:")
    for k, v in r.reproducibility.items():
        print(f"    {k}: {v}")

    # ---------- 5) 回标 + 解释 ----------
    _banner("Step 5/5  ·  Feedback + audit pointer")
    print(textwrap.dedent(f"""
        判定准吗？
          y = true_positive (你也认为漂移)
          n = false_positive (你认为正常)
          s = skip
    """))
    fb = input("> ").strip().lower()
    if fb == "y":
        sp.drift_checks.feedback(r.id, label="true_positive")
        print("✓ recorded as TP")
    elif fb == "n":
        sp.drift_checks.feedback(r.id, label="false_positive")
        print("✓ recorded as FP — 月度 calibration 报告会反映这条")

    print(textwrap.dedent(f"""
        🎉 Done.

        你的下一步：
          1. 把 `sp.drift_checks.check(...)` 放进你的 LangGraph / OpenAI agent
          2. 收集回标，月底看 calibration（precision / recall）
          3. 任何时刻拿 reproducibility 包验证：
                 sp.drift_checks.replay(text=..., baseline="{bl.id}",
                                        reproducibility={{...}})
          4. 拿审计 inclusion proof：
                 proof = sp.audit.proof(primitive="drift_check", request_id="{r.id}")
                 # 离线复算：soulpolicy-verify <(echo $proof)
    """))
    return 0


if __name__ == "__main__":
    sys.exit(main())
