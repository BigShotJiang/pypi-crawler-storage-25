"""SoulPolicy Python SDK.

Quick start::

    from soulpolicy import Client

    sp = Client(api_key="sk_live_xxx")
    bl = sp.baselines.create(samples=[
        "Hello, thanks for contacting us.",
        "Hi there, how can I help today?",
        "Apologies for the trouble. Let me look into that.",
    ])
    r = sp.drift_checks.create(text="Sure, let me help.", baseline=bl.id)
    print(r.severity, r.score)

设计原则：
  - 每个 primitive 一个 resource 类，所有方法返回 dataclass
  - 错误统一用 SoulPolicyError 抛出（含 type / code / message / request_id）
  - Idempotency-Key 由 SDK 自动生成（也可手动指定）
  - 内置重试：仅对 5xx 与连接错误重试，4xx 不重试
"""

from soulpolicy._client import Client
from soulpolicy._errors import (
    SoulPolicyError,
    InvalidRequestError,
    AuthenticationError,
    PermissionError as SoulPolicyPermissionError,
    NotFoundError,
    IdempotencyError,
    APIError,
)
from soulpolicy._models import (
    Baseline,
    DriftCheck,
    DriftCheckReplay,
    DriftCheckFeedback,
    BaselineReport,
    Snapshot,
    SnapshotRestore,
    Policy,
    GuardrailEval,
    AuditProof,
)

__version__ = "0.2.0"

__all__ = [
    "Client",
    "Baseline",
    "DriftCheck",
    "DriftCheckReplay",
    "DriftCheckFeedback",
    "BaselineReport",
    "Snapshot",
    "SnapshotRestore",
    "Policy",
    "GuardrailEval",
    "AuditProof",
    "SoulPolicyError",
    "InvalidRequestError",
    "AuthenticationError",
    "SoulPolicyPermissionError",
    "NotFoundError",
    "IdempotencyError",
    "APIError",
    "__version__",
]
