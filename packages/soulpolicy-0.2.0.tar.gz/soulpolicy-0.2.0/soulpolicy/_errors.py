"""Stripe 风格错误层级。"""
from __future__ import annotations

from typing import Any


class SoulPolicyError(Exception):
    """所有 SDK 抛出的错误的基类。"""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        type: str | None = None,
        code: str | None = None,
        param: str | None = None,
        request_id: str | None = None,
    ):
        super().__init__(message)
        self.status_code = status_code
        self.type = type
        self.code = code
        self.param = param
        self.request_id = request_id

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"status={self.status_code}, code={self.code!r}, "
            f"message={self.args[0]!r}, request_id={self.request_id!r})"
        )


class InvalidRequestError(SoulPolicyError):
    """400 / 422 — 参数错误或资源不存在。"""


class AuthenticationError(SoulPolicyError):
    """401 — API key 缺失或无效。"""


class PermissionError(SoulPolicyError):  # noqa: A001 (intentional shadow)
    """403 — API key 没有所需 scope。"""


class NotFoundError(SoulPolicyError):
    """404 — 资源不存在。"""


class IdempotencyError(SoulPolicyError):
    """409 — 同 idempotency-key 复用了不同 payload。"""


class APIError(SoulPolicyError):
    """5xx — 服务端错误（自动重试后仍失败）。"""


_STATUS_TO_CLASS = {
    400: InvalidRequestError,
    401: AuthenticationError,
    403: PermissionError,
    404: NotFoundError,
    409: IdempotencyError,
    422: InvalidRequestError,
}


def from_response(status_code: int, body: dict[str, Any], request_id: str | None) -> SoulPolicyError:
    err = body.get("error") if isinstance(body, dict) else None
    if not isinstance(err, dict):
        err = {}
    cls = _STATUS_TO_CLASS.get(status_code, APIError)
    return cls(
        err.get("message") or f"HTTP {status_code}",
        status_code=status_code,
        type=err.get("type"),
        code=err.get("code"),
        param=err.get("param"),
        request_id=err.get("request_id") or request_id,
    )
