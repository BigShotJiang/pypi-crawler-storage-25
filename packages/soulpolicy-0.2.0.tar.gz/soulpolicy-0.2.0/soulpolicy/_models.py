"""SDK 返回对象。所有字段都用 dataclass 而非 dict，便于 IDE 补全。"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Baseline:
    id: str
    label: str | None
    distance_mode: str
    embedding_model: str
    sample_count: int
    z_warn: float
    z_critical: float
    ewma_alpha: float
    fingerprint: str
    created_at: int
    object: str = "baseline"

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Baseline":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class DriftCheck:
    id: str
    created_at: int
    score: float
    z_score: float
    severity: str            # ok | warn | critical
    ema: float
    decision: str            # pass | trigger_review | hard_rollback
    distance_cosine: float | None
    distance_mahalanobis: float | None
    role_axis_score: float | None
    evidence: dict[str, Any]
    reproducibility: dict[str, Any]
    latency_ms: int
    object: str = "drift_check"
    request_id: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DriftCheck":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class DriftCheckReplay:
    matched: bool
    diff: dict[str, Any]
    result: DriftCheck

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DriftCheckReplay":
        return cls(
            matched=data.get("matched", False),
            diff=data.get("diff") or {},
            result=DriftCheck.from_dict(data.get("result") or {}),
        )


@dataclass
class DriftCheckFeedback:
    id: str
    target_id: str
    label: str
    created_at: int
    object: str = "feedback"
    primitive: str = "drift_check"

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DriftCheckFeedback":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class Snapshot:
    id: str
    session_id: str
    turn_index: int
    context_hash: str
    has_kv_blob: bool
    health_score: float | None
    snapshot_format: str
    provider_mode: str
    last_restored_at: int | None
    restore_count: int
    created_at: int
    object: str = "snapshot"

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Snapshot":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class SnapshotRestore:
    id: str
    snapshot: str
    ok: bool
    session_id: str
    restored_turn: int
    restored_context_hash: str
    provider_mode: str
    error: str | None
    created_at: int
    object: str = "snapshot_restore"

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SnapshotRestore":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class Policy:
    id: str
    name: str
    description: str | None
    rule_count: int
    version: int
    fingerprint: str
    created_at: int
    object: str = "policy"

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Policy":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class GuardrailEval:
    id: str
    created_at: int
    decision: str          # pass | warn | block
    severity: str
    violated: list[dict[str, Any]]
    redacted_text: str | None
    evidence: dict[str, Any]
    reproducibility: dict[str, Any]
    latency_ms: int
    object: str = "guardrail_eval"

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "GuardrailEval":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class AuditProof:
    request_id: str
    primitive: str
    day: str
    leaf_hash: str
    merkle_root: str
    proof: list[dict[str, str]]
    verified: bool

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AuditProof":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class BaselineReport:
    id: str
    baseline: str
    sample_count: int
    holdout_count: int
    perturbation_count: int
    auc: float | None
    fp_rate_at_warn: float | None
    fn_rate_at_warn: float | None
    severity_distribution: dict[str, int]
    weakest_categories: list[str]
    notes: list[str]
    generated_at: int
    object: str = "baseline_report"

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "BaselineReport":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})
