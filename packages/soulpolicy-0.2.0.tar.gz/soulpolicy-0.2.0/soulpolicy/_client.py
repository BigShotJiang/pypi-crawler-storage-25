"""SoulPolicy SDK Client + Resource 类。"""
from __future__ import annotations

import os
import secrets
import time
from typing import Any, Callable

import httpx

from soulpolicy._errors import APIError, SoulPolicyError, from_response
from soulpolicy._models import (
    AuditProof,
    Baseline,
    BaselineReport,
    DriftCheck,
    DriftCheckFeedback,
    DriftCheckReplay,
    GuardrailEval,
    Policy,
    Snapshot,
    SnapshotRestore,
)


DEFAULT_BASE_URL = "https://api.soulpolicy.cc"
DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_RETRIES = 2


class Client:
    """SoulPolicy SDK 入口。

    Args:
      api_key: sk_live_xxx；若为 None 则读 env SOULPOLICY_API_KEY
      base_url: 默认 https://api.soulpolicy.cc；可指向自托管
      timeout: 单次请求超时秒
      max_retries: 5xx / 网络错误重试次数（不含首次）
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        http_client: httpx.Client | None = None,
    ):
        self.api_key = api_key or os.environ.get("SOULPOLICY_API_KEY")
        if not self.api_key:
            raise ValueError("api_key is required (or set SOULPOLICY_API_KEY)")
        self.base_url = (base_url or os.environ.get("SOULPOLICY_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self._http = http_client or httpx.Client(timeout=timeout)
        # 资源代理
        self.baselines = _Baselines(self)
        self.drift_checks = _DriftChecks(self)
        self.snapshots = _Snapshots(self)
        self.policies = _Policies(self)
        self.guardrail_evals = _GuardrailEvals(self)
        self.audit = _Audit(self)

    # ------- 内部 HTTP 抽象 -------

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "User-Agent": "soulpolicy-python/0.2.0",
        }
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        elif method.upper() == "POST":
            headers["Idempotency-Key"] = f"sdk-auto-{secrets.token_hex(8)}"

        attempt = 0
        last_exc: Exception | None = None
        while attempt <= self.max_retries:
            try:
                resp = self._http.request(method, url, headers=headers, json=json)
            except httpx.HTTPError as e:
                last_exc = e
                attempt += 1
                if attempt > self.max_retries:
                    raise APIError(f"network error: {e}") from e
                time.sleep(0.5 * (2**attempt))
                continue

            if resp.status_code >= 500:
                attempt += 1
                if attempt > self.max_retries:
                    raise from_response(
                        resp.status_code,
                        _safe_json(resp),
                        resp.headers.get("X-Request-Id"),
                    )
                time.sleep(0.5 * (2**attempt))
                continue

            if resp.status_code >= 400:
                raise from_response(
                    resp.status_code,
                    _safe_json(resp),
                    resp.headers.get("X-Request-Id"),
                )

            return _safe_json(resp)
        # 不应到达
        raise APIError(f"unreachable: {last_exc}")  # pragma: no cover

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "Client":
        return self

    def __exit__(self, *_exc: Any) -> None:
        self.close()


def _safe_json(resp: httpx.Response) -> dict[str, Any]:
    try:
        return resp.json()
    except Exception:
        return {}


# ============== Resources ==============


class _Baselines:
    def __init__(self, client: Client):
        self._c = client

    def create(
        self,
        *,
        samples: list[str],
        negative_samples: list[str] | None = None,
        distance_mode: str = "cosine",
        z_warn: float = 2.0,
        z_critical: float = 3.0,
        ewma_alpha: float = 0.3,
        label: str | None = None,
        idempotency_key: str | None = None,
    ) -> Baseline:
        data = self._c._request(
            "POST",
            "/api/v2/baselines",
            json={
                "samples": samples,
                "negative_samples": negative_samples,
                "distance_mode": distance_mode,
                "z_warn": z_warn,
                "z_critical": z_critical,
                "ewma_alpha": ewma_alpha,
                "label": label,
            },
            idempotency_key=idempotency_key,
        )
        return Baseline.from_dict(data)

    def retrieve(self, id: str) -> Baseline:  # noqa: A002
        data = self._c._request("GET", f"/api/v2/baselines/{id}")
        return Baseline.from_dict(data)

    def report(self, id: str) -> BaselineReport:  # noqa: A002
        data = self._c._request("GET", f"/api/v2/baselines/{id}/report")
        return BaselineReport.from_dict(data)

    @classmethod
    def from_samples(
        cls,
        client: Client,
        samples: list[str],
        **kwargs: Any,
    ) -> Baseline:
        """糖：与 create 等价，名字更符合开发者直觉。"""
        return client.baselines.create(samples=samples, **kwargs)


class _DriftChecks:
    def __init__(self, client: Client):
        self._c = client

    def create(
        self,
        *,
        text: str,
        baseline: str,
        ema_prev: float = 0.0,
        idempotency_key: str | None = None,
    ) -> DriftCheck:
        data = self._c._request(
            "POST",
            "/api/v2/drift_checks",
            json={"text": text, "baseline": baseline, "ema_prev": ema_prev},
            idempotency_key=idempotency_key,
        )
        return DriftCheck.from_dict(data)

    # 别名：让代码读起来像 sp.drift.check(...)
    check = create

    def replay(
        self,
        *,
        text: str,
        baseline: str,
        reproducibility: dict[str, Any],
        ema_prev: float = 0.0,
    ) -> DriftCheckReplay:
        data = self._c._request(
            "POST",
            "/api/v2/drift_checks/replay",
            json={
                "text": text,
                "baseline": baseline,
                "reproducibility": reproducibility,
                "ema_prev": ema_prev,
            },
        )
        return DriftCheckReplay.from_dict(data)

    def feedback(
        self,
        id: str,  # noqa: A002
        *,
        label: str,
        note: str | None = None,
    ) -> DriftCheckFeedback:
        data = self._c._request(
            "POST",
            f"/api/v2/drift_checks/{id}/feedback",
            json={"label": label, "note": note},
        )
        return DriftCheckFeedback.from_dict(data)


class _Snapshots:
    def __init__(self, client: Client):
        self._c = client

    def create(
        self,
        *,
        session_id: str,
        turn_index: int,
        context_text: str,
        kv_blob_b64: str | None = None,
        context_payload: dict[str, Any] | None = None,
        health_score: float | None = None,
        provider_mode: str = "noop",
        idempotency_key: str | None = None,
    ) -> Snapshot:
        data = self._c._request(
            "POST",
            "/api/v2/snapshots",
            json={
                "session_id": session_id,
                "turn_index": turn_index,
                "context_text": context_text,
                "kv_blob_b64": kv_blob_b64,
                "context_payload": context_payload,
                "health_score": health_score,
                "provider_mode": provider_mode,
            },
            idempotency_key=idempotency_key,
        )
        return Snapshot.from_dict(data)

    def retrieve(self, id: str) -> Snapshot:  # noqa: A002
        return Snapshot.from_dict(self._c._request("GET", f"/api/v2/snapshots/{id}"))

    def restore(self, id: str) -> SnapshotRestore:  # noqa: A002
        return SnapshotRestore.from_dict(
            self._c._request("POST", f"/api/v2/snapshots/{id}/restore", json={})
        )


class _Policies:
    def __init__(self, client: Client):
        self._c = client

    def create(
        self,
        *,
        name: str,
        rules: list[dict[str, Any]],
        description: str | None = None,
        idempotency_key: str | None = None,
    ) -> Policy:
        return Policy.from_dict(
            self._c._request(
                "POST",
                "/api/v2/policies",
                json={"name": name, "description": description, "rules": rules},
                idempotency_key=idempotency_key,
            )
        )

    def retrieve(self, id: str) -> Policy:  # noqa: A002
        return Policy.from_dict(self._c._request("GET", f"/api/v2/policies/{id}"))


class _GuardrailEvals:
    def __init__(self, client: Client):
        self._c = client

    def create(
        self,
        *,
        text: str,
        policy: str,
        metadata: dict[str, Any] | None = None,
        scope: dict[str, Any] | None = None,
        redact: bool = True,
        idempotency_key: str | None = None,
    ) -> GuardrailEval:
        return GuardrailEval.from_dict(
            self._c._request(
                "POST",
                "/api/v2/guardrail_evals",
                json={
                    "text": text,
                    "policy": policy,
                    "metadata": metadata,
                    "scope": scope,
                    "redact": redact,
                },
                idempotency_key=idempotency_key,
            )
        )

    # 别名
    eval = create


class _Audit:
    def __init__(self, client: Client):
        self._c = client

    def proof(self, *, primitive: str, request_id: str) -> AuditProof:
        from urllib.parse import urlencode

        qs = urlencode({"primitive": primitive, "request_id": request_id})
        return AuditProof.from_dict(
            self._c._request("GET", f"/api/v2/audit/proof?{qs}")
        )
