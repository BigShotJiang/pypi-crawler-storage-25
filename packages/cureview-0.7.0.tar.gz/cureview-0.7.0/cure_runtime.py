from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tomllib
from typing import Any, Mapping
import urllib.error
import urllib.request

from cure_errors import ReviewflowError
from cure_sessions import PullRequestRef, parse_pr_url
from meta import json_fingerprint
from paths import (
    ReviewflowPaths,
    default_cache_root,
    default_codex_base_config_path,
    default_reviewflow_config_path,
    default_sandbox_root,
)
from run import ReviewflowSubprocessError, run_cmd
from ui import Verbosity


DEFAULT_REVIEW_INTELLIGENCE_POLICY_MODE = "cure_first_unrestricted"
CODEX_REASONING_EFFORT_CHOICES = ("minimal", "low", "medium", "high", "xhigh")
CLAUDE_REASONING_EFFORT_CHOICES = ("low", "medium", "high", "max")
CLAUDE_CLI_DEFAULT_MODEL = "claude-sonnet-4-6"
CLAUDE_CLI_DEFAULT_REASONING_EFFORT = "high"
LLM_TRANSPORT_CHOICES = ("http", "cli")
HTTP_LLM_PROVIDERS = ("openai", "openrouter")
CLI_LLM_PROVIDERS = ("codex", "claude")
LLM_RESUME_PROVIDERS = ("codex", "claude")
DEFAULT_LEGACY_CODEX_PRESET = "legacy_codex"
DEFAULT_IMPLICIT_CODEX_PRESET = "codex-cli"
IMPLICIT_CODEX_PRESET_SOURCE = "implicit_codex_cli"
AGENT_RUNTIME_PROFILE_CHOICES = ("permissive",)
DEFAULT_AGENT_RUNTIME_PROFILE = "permissive"
BUILTIN_LLM_PRESET_IDS = (
    "codex-cli",
    "claude-cli",
    "openai-responses",
    "openrouter-responses",
)
CURATED_ENV_INHERIT_KEYS = (
    "ANTHROPIC_API_KEY",
    "CHUNKHOUND_EMBEDDING__API_KEY",
    "CHUNKHOUND_LLM_API_KEY",
    "COLORTERM",
    "FORCE_COLOR",
    "HOME",
    "LANG",
    "LC_ALL",
    "LC_CTYPE",
    "LOGNAME",
    "NO_COLOR",
    "OPENAI_API_KEY",
    "PATH",
    "SHELL",
    "SSH_AUTH_SOCK",
    "SYSTEMROOT",
    "TEMP",
    "TERM",
    "TMP",
    "TMPDIR",
    "USER",
    "VOYAGE_API_KEY",
)
CLI_PROVIDER_SESSION_ENV_PREFIXES = {
    "codex": ("CODEX_",),
    "claude": ("CLAUDE_",),
}
LOCAL_AGENT_PRESET_BY_NAME = {
    "codex": "codex-cli",
    "claude": "claude-cli",
}
LOCAL_AGENT_NAME_BY_PRESET = {preset: agent for agent, preset in LOCAL_AGENT_PRESET_BY_NAME.items()}
DEFAULT_MULTIPASS_ENABLED = True
DEFAULT_MULTIPASS_MAX_STEPS = 20
MULTIPASS_MAX_STEPS_HARD_CAP = 20
DEFAULT_MULTIPASS_STEP_WORKERS = 4
MULTIPASS_STEP_WORKERS_HARD_CAP = 8
DEFAULT_MULTIPASS_GROUNDING_MODE = "strict"
MULTIPASS_GROUNDING_MODES = {"strict", "warn", "off"}
REVIEW_INTELLIGENCE_SOURCE_MODES = {"off", "auto", "when-referenced", "required"}
_BUILTIN_REVIEW_INTELLIGENCE_SOURCE_NAMES = {"github", "jira"}
REVIEW_INTELLIGENCE_CAPABILITY_STATES = {"available", "unavailable", "unknown"}

REVIEW_INTELLIGENCE_CONFIG_EXAMPLE = """[review_intelligence]
[[review_intelligence.sources]]
name = "github"
mode = "auto"

[[review_intelligence.sources]]
name = "jira"
mode = "when-referenced"
"""

CHUNKHOUND_CONFIG_EXAMPLE = """[chunkhound]
base_config_path = "/absolute/path/to/chunkhound-base.json"

[chunkhound.indexing]
# Optional: when set, these replace the corresponding lists in the base config.
include = ["**/*.py", "**/*.ts"]
exclude = ["**/.claude/**", "**/openspec/**"]
per_file_timeout_seconds = 6
per_file_timeout_min_size_kb = 128

[chunkhound.research]
algorithm = "hybrid"
"""

_DISABLED_REVIEWFLOW_CONFIG_PATH: Path | None = None
LEGACY_ENV_RENAMES = {
    "REVIEWFLOW_AGENT_RUNTIME_PROFILE": "CURE_AGENT_RUNTIME_PROFILE",
    "REVIEWFLOW_CACHE_ROOT": "CURE_CACHE_ROOT",
    "REVIEWFLOW_CODEX_CONFIG": "CURE_CODEX_CONFIG",
    "REVIEWFLOW_CONFIG": "CURE_CONFIG",
    "REVIEWFLOW_SANDBOX_ROOT": "CURE_SANDBOX_ROOT",
    "REVIEWFLOW_WORK_DIR": "CURE_WORK_DIR",
}


@dataclass(frozen=True)
class ReviewflowRuntime:
    config_path: Path
    config_source: str
    config_enabled: bool
    paths: ReviewflowPaths
    sandbox_root_source: str
    cache_root_source: str
    codex_base_config_path: Path
    codex_base_config_source: str


@dataclass(frozen=True)
class ReviewIntelligenceSource:
    name: str
    mode: str
    notes: tuple[str, ...] = ()


@dataclass(frozen=True)
class ReviewIntelligenceConfig:
    notes: tuple[str, ...] = ()
    sources: tuple[ReviewIntelligenceSource, ...] = ()


@dataclass(frozen=True)
class ReviewflowChunkHoundConfig:
    base_config_path: Path
    indexing_include: tuple[str, ...] | None = None
    indexing_exclude: tuple[str, ...] | None = None
    per_file_timeout_seconds: float | int | None = None
    per_file_timeout_min_size_kb: int | None = None
    research_algorithm: str | None = None


@dataclass(frozen=True)
class DoctorCheck:
    name: str
    status: str
    detail: str


@dataclass(frozen=True)
class DoctorTargetContext:
    pr_url: str
    pr: PullRequestRef
    public_fallback_supported: bool
    public_pr_metadata_reachable: bool
    public_pr_metadata_detail: str


def _set_disabled_reviewflow_config_path(path: Path | None) -> None:
    global _DISABLED_REVIEWFLOW_CONFIG_PATH
    _DISABLED_REVIEWFLOW_CONFIG_PATH = path.resolve(strict=False) if path is not None else None


def _loaded_shell_module():
    import sys as _sys

    return _sys.modules.get("cure")


def _default_reviewflow_config_path() -> Path:
    rf = _loaded_shell_module()
    return rf.default_reviewflow_config_path() if rf is not None else default_reviewflow_config_path()


def _default_codex_base_config_path() -> Path:
    rf = _loaded_shell_module()
    return rf.default_codex_base_config_path() if rf is not None else default_codex_base_config_path()


def _default_sandbox_root() -> Path:
    rf = _loaded_shell_module()
    return rf.default_sandbox_root() if rf is not None else default_sandbox_root()


def _default_cache_root() -> Path:
    rf = _loaded_shell_module()
    return rf.default_cache_root() if rf is not None else default_cache_root()


def _legacy_env_rename_error(env_name: str, renamed_to: str) -> ReviewflowError:
    return ReviewflowError(f"{env_name} is no longer supported. Use {renamed_to} instead.")


def _read_supported_env_value(primary_env: str, legacy_env: str | None = None) -> str | None:
    legacy_name = str(legacy_env or "").strip()
    if legacy_name:
        legacy_value = str(os.environ.get(legacy_name) or "").strip()
        if legacy_value:
            raise _legacy_env_rename_error(legacy_name, primary_env)
    value = str(os.environ.get(primary_env) or "").strip()
    return value or None


def load_toml(path: Path) -> dict[str, Any]:
    disabled = _DISABLED_REVIEWFLOW_CONFIG_PATH
    if disabled is not None and path.resolve(strict=False) == disabled:
        return {}
    try:
        text = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return {}
    except (OSError, UnicodeDecodeError) as e:
        raise ReviewflowError(f"Failed to read TOML at {path}: {e}") from e
    try:
        return tomllib.loads(text)
    except tomllib.TOMLDecodeError as e:
        raise ReviewflowError(f"Failed to parse TOML at {path}: {e}") from e


def toml_string(value: str) -> str:
    return json.dumps(value)


def codex_flags_from_base_config(*, base_config_path: Path) -> tuple[list[str], dict[str, Any]]:
    cfg = load_toml(base_config_path)
    meta: dict[str, Any] = {"base_config_path": str(base_config_path), "loaded": bool(cfg)}
    flags: list[str] = []

    model = cfg.get("model")
    if isinstance(model, str) and model.strip():
        flags.extend(["-m", model.strip()])
        meta["model"] = model.strip()

    sandbox_mode = cfg.get("sandbox_mode")
    if (
        isinstance(sandbox_mode, str)
        and sandbox_mode in {"read-only", "workspace-write", "danger-full-access"}
    ):
        flags.extend(["--sandbox", sandbox_mode])
        meta["sandbox_mode"] = sandbox_mode

    web_search = cfg.get("web_search")
    if web_search == "live":
        flags.append("--search")
        meta["web_search"] = "live"

    model_reasoning_effort = cfg.get("model_reasoning_effort")
    if isinstance(model_reasoning_effort, str) and model_reasoning_effort.strip():
        flags.extend(
            ["-c", f"model_reasoning_effort={toml_string(model_reasoning_effort.strip())}"]
        )
        meta["model_reasoning_effort"] = model_reasoning_effort.strip()

    plan_mode_reasoning_effort = cfg.get("plan_mode_reasoning_effort")
    if isinstance(plan_mode_reasoning_effort, str) and plan_mode_reasoning_effort.strip():
        flags.extend(
            [
                "-c",
                f"plan_mode_reasoning_effort={toml_string(plan_mode_reasoning_effort.strip())}",
            ]
        )
        meta["plan_mode_reasoning_effort"] = plan_mode_reasoning_effort.strip()

    return flags, meta


def _resolve_optional_path(raw: object, *, base_dir: Path | None = None) -> Path | None:
    text = str(raw or "").strip()
    if not text:
        return None
    path = Path(text).expanduser()
    if not path.is_absolute():
        anchor = base_dir or Path.cwd()
        path = anchor / path
    return path.resolve(strict=False)


def _select_path_with_source(
    *,
    cli_value: object,
    env_value: object,
    config_value: Path | None,
    default_value: Path,
    base_dir: Path | None = None,
) -> tuple[Path, str]:
    cli_path = _resolve_optional_path(cli_value, base_dir=base_dir)
    if cli_path is not None:
        return cli_path, "cli"
    env_path = _resolve_optional_path(env_value, base_dir=base_dir)
    if env_path is not None:
        return env_path, "env"
    if config_value is not None:
        return config_value, "config"
    return default_value.resolve(strict=False), "default"


def _select_env_path_with_source(*, env_names: tuple[str, ...], base_dir: Path | None = None) -> tuple[Path, str] | None:
    if not env_names:
        return None
    primary_env = env_names[0]
    for legacy_env in env_names[1:]:
        legacy_value = _read_supported_env_value(primary_env, legacy_env)
        if legacy_value is not None:
            break
    env_path = _resolve_optional_path(_read_supported_env_value(primary_env), base_dir=base_dir)
    if env_path is not None:
        return env_path, "env"
    return None


def load_reviewflow_paths_defaults(
    *, config_path: Path | None = None
) -> tuple[dict[str, Path | None], dict[str, Any]]:
    path = config_path or _default_reviewflow_config_path()
    raw = load_toml(path)
    section = raw.get("paths", {}) if isinstance(raw, dict) else {}
    section = section if isinstance(section, dict) else {}
    base_dir = path.parent
    sandbox_root = _resolve_optional_path(section.get("sandbox_root"), base_dir=base_dir)
    cache_root = _resolve_optional_path(section.get("cache_root"), base_dir=base_dir)
    cfg = {"sandbox_root": sandbox_root, "cache_root": cache_root}
    meta = {
        "config_path": str(path),
        "loaded": bool(raw),
        "paths": {
            "sandbox_root": str(sandbox_root) if sandbox_root is not None else None,
            "cache_root": str(cache_root) if cache_root is not None else None,
        },
    }
    return cfg, meta


def load_reviewflow_codex_base_config_path(*, config_path: Path | None = None) -> Path | None:
    path = config_path or _default_reviewflow_config_path()
    raw = load_toml(path)
    section = raw.get("codex", {}) if isinstance(raw, dict) else {}
    section = section if isinstance(section, dict) else {}
    return _resolve_optional_path(section.get("base_config_path"), base_dir=path.parent)


def resolve_reviewflow_config_path(args: argparse.Namespace) -> tuple[Path, str, bool]:
    cli_path = _resolve_optional_path(getattr(args, "config_path", None))
    if cli_path is not None:
        config_path, config_source = cli_path, "cli"
    else:
        env_path = _select_env_path_with_source(env_names=("CURE_CONFIG", "REVIEWFLOW_CONFIG"))
        if env_path is not None:
            config_path, config_source = env_path
        else:
            config_path, config_source = _default_reviewflow_config_path(), "default"
    config_enabled = not bool(getattr(args, "no_config", False))
    _set_disabled_reviewflow_config_path(None if config_enabled else config_path)
    return config_path, config_source, config_enabled


def resolve_runtime_paths(args: argparse.Namespace, *, config_path: Path) -> tuple[ReviewflowPaths, str, str]:
    path_defaults, _ = load_reviewflow_paths_defaults(config_path=config_path)
    sandbox_root = _resolve_optional_path(getattr(args, "sandbox_root", None))
    if sandbox_root is not None:
        sandbox_root_source = "cli"
    else:
        sandbox_env = _select_env_path_with_source(env_names=("CURE_SANDBOX_ROOT", "REVIEWFLOW_SANDBOX_ROOT"))
        if sandbox_env is not None:
            sandbox_root, sandbox_root_source = sandbox_env
        elif path_defaults.get("sandbox_root") is not None:
            sandbox_root, sandbox_root_source = path_defaults["sandbox_root"], "config"
        else:
            sandbox_root, sandbox_root_source = _default_sandbox_root(), "default"

    cache_root = _resolve_optional_path(getattr(args, "cache_root", None))
    if cache_root is not None:
        cache_root_source = "cli"
    else:
        cache_env = _select_env_path_with_source(env_names=("CURE_CACHE_ROOT", "REVIEWFLOW_CACHE_ROOT"))
        if cache_env is not None:
            cache_root, cache_root_source = cache_env
        elif path_defaults.get("cache_root") is not None:
            cache_root, cache_root_source = path_defaults["cache_root"], "config"
        else:
            cache_root, cache_root_source = _default_cache_root(), "default"
    return ReviewflowPaths(sandbox_root=sandbox_root, cache_root=cache_root), sandbox_root_source, cache_root_source


def resolve_codex_base_config_path(args: argparse.Namespace, *, config_path: Path) -> tuple[Path, str]:
    cli_path = _resolve_optional_path(getattr(args, "codex_config_path", None))
    if cli_path is not None:
        return cli_path, "cli"
    env_path = _select_env_path_with_source(env_names=("CURE_CODEX_CONFIG", "REVIEWFLOW_CODEX_CONFIG"))
    if env_path is not None:
        return env_path
    config_value = load_reviewflow_codex_base_config_path(config_path=config_path)
    if config_value is not None:
        return config_value, "config"
    return _default_codex_base_config_path(), "default"


def resolve_runtime(args: argparse.Namespace) -> ReviewflowRuntime:
    if str(os.environ.get("REVIEWFLOW_WORK_DIR") or "").strip():
        raise _legacy_env_rename_error("REVIEWFLOW_WORK_DIR", "CURE_WORK_DIR")
    config_path, config_source, config_enabled = resolve_reviewflow_config_path(args)
    paths, sandbox_root_source, cache_root_source = resolve_runtime_paths(args, config_path=config_path)
    codex_base_config_path, codex_base_config_source = resolve_codex_base_config_path(
        args, config_path=config_path
    )
    return ReviewflowRuntime(
        config_path=config_path,
        config_source=config_source,
        config_enabled=config_enabled,
        paths=paths,
        sandbox_root_source=sandbox_root_source,
        cache_root_source=cache_root_source,
        codex_base_config_path=codex_base_config_path,
        codex_base_config_source=codex_base_config_source,
    )


def resolve_verbosity(args: argparse.Namespace) -> Verbosity:
    if bool(getattr(args, "quiet", False)):
        return Verbosity.quiet
    raw = getattr(args, "verbosity", None)
    if raw is None:
        return Verbosity.normal
    text = str(raw).strip().lower()
    if text == "quiet":
        return Verbosity.quiet
    if text == "debug":
        return Verbosity.debug
    return Verbosity.normal


def resolve_ui_enabled(args: argparse.Namespace, *, verbosity: Verbosity) -> bool:
    if bool(getattr(args, "quiet", False)):
        return False
    ui = str(getattr(args, "ui", "auto") or "auto").strip().lower()
    if ui == "off":
        return False
    if ui == "on":
        return bool(sys.stderr.isatty()) and (os.environ.get("TERM", "").strip().lower() not in {"", "dumb"})
    return bool(sys.stderr.isatty()) and (os.environ.get("TERM", "").strip().lower() not in {"", "dumb"})


def parse_llm_key_value(raw: str, *, value_mode: str) -> tuple[str, Any]:
    text = str(raw or "").strip()
    if "=" not in text:
        raise ReviewflowError(f"Expected KEY=VALUE for --llm-{value_mode}, got: {raw!r}")
    key, value = text.split("=", 1)
    key = key.strip()
    if not key:
        raise ReviewflowError(f"Expected non-empty KEY for --llm-{value_mode}.")
    if value_mode == "header":
        return key, value.strip()
    try:
        parsed = tomllib.loads(f"value = {value}\n").get("value")
    except Exception:
        parsed = value.strip()
    return key, parsed


def parse_llm_request_overrides(raw_items: object) -> dict[str, Any]:
    if not isinstance(raw_items, list):
        return {}
    out: dict[str, Any] = {}
    for item in raw_items:
        key, value = parse_llm_key_value(str(item), value_mode="set")
        out[key] = value
    return out


def parse_llm_header_overrides(raw_items: object) -> dict[str, str]:
    if not isinstance(raw_items, list):
        return {}
    out: dict[str, str] = {}
    for item in raw_items:
        key, value = parse_llm_key_value(str(item), value_mode="header")
        out[key] = str(value)
    return out


def resolve_llm_config_from_args(
    args: argparse.Namespace,
    *,
    reviewflow_config_path: Path | None = None,
    base_codex_config_path: Path | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    return resolve_llm_config(
        base_codex_config_path=(base_codex_config_path or _default_codex_base_config_path()),
        reviewflow_config_path=(reviewflow_config_path or _default_reviewflow_config_path()),
        cli_preset=getattr(args, "llm_preset", None),
        cli_model=getattr(args, "llm_model", None),
        cli_effort=getattr(args, "llm_effort", None),
        cli_plan_effort=getattr(args, "llm_plan_effort", None),
        cli_verbosity=getattr(args, "llm_verbosity", None),
        cli_max_output_tokens=getattr(args, "llm_max_output_tokens", None),
        cli_request_overrides=parse_llm_request_overrides(getattr(args, "llm_set", [])),
        cli_header_overrides=parse_llm_header_overrides(getattr(args, "llm_header", [])),
        deprecated_codex_model=getattr(args, "codex_model", None),
        deprecated_codex_effort=getattr(args, "codex_effort", None),
        deprecated_codex_plan_effort=getattr(args, "codex_plan_effort", None),
    )


def build_llm_meta(
    *,
    resolved: dict[str, Any],
    resolution_meta: dict[str, Any],
    env: dict[str, str],
    adapter_meta: dict[str, Any] | None = None,
    helpers: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return {
        "preset": resolved.get("preset"),
        "selected_name": resolved.get("selected_name"),
        "transport": resolved.get("transport"),
        "provider": resolved.get("provider"),
        "command": resolved.get("command"),
        "model": resolved.get("model"),
        "reasoning_effort": resolved.get("reasoning_effort"),
        "model_source": ((resolution_meta.get("resolved") or {}).get("model_source")),
        "model_source_detail": ((resolution_meta.get("resolved") or {}).get("model_source_detail")),
        "reasoning_effort_source": ((resolution_meta.get("resolved") or {}).get("reasoning_effort_source")),
        "reasoning_effort_source_detail": (
            (resolution_meta.get("resolved") or {}).get("reasoning_effort_source_detail")
        ),
        "text_verbosity": resolved.get("text_verbosity"),
        "max_output_tokens": resolved.get("max_output_tokens"),
        "runtime_overrides": resolution_meta.get("runtime_overrides"),
        "config": resolution_meta,
        "adapter": dict(adapter_meta or {}),
        "helpers": dict(helpers or {}),
        "env_keys": sorted(_string_dict(resolved.get("env")).keys()),
        "capabilities": dict(resolved.get("capabilities") or {}),
    }


def build_utility_llm_meta(
    *,
    resolved: dict[str, Any],
    resolution_meta: dict[str, Any],
    env: dict[str, str],
    adapter_meta: dict[str, Any] | None = None,
    helpers: dict[str, Any] | None = None,
) -> dict[str, Any]:
    meta = build_llm_meta(
        resolved=resolved,
        resolution_meta=resolution_meta,
        env=env,
        adapter_meta=adapter_meta,
        helpers=helpers,
    )
    resolved_meta = resolution_meta.get("resolved") if isinstance(resolution_meta.get("resolved"), dict) else {}
    for key in (
        "preset_source",
        "preset_source_detail",
        "preset_inherited",
        "model_inherited",
        "reasoning_effort_inherited",
    ):
        if key in resolved_meta:
            meta[key] = resolved_meta[key]
    return meta


def _reasoning_effort_choices_for_provider(provider: object) -> tuple[str, ...]:
    name = str(provider or "").strip().lower()
    if name == "claude":
        return CLAUDE_REASONING_EFFORT_CHOICES
    return CODEX_REASONING_EFFORT_CHOICES


def _normalize_optional_reasoning_effort(*, raw: object, field_name: str, provider: object = "codex") -> str | None:
    if raw is None:
        return None
    allowed_choices = _reasoning_effort_choices_for_provider(provider)
    if not isinstance(raw, str):
        allowed = ", ".join(allowed_choices)
        raise ReviewflowError(
            f"Invalid {field_name} in reviewflow config. Expected one of: {allowed}."
        )
    value = raw.strip().lower()
    if not value:
        return None
    if value not in allowed_choices:
        allowed = ", ".join(allowed_choices)
        raise ReviewflowError(
            f"Invalid {field_name} in reviewflow config. Expected one of: {allowed}."
        )
    return value


def resolve_multipass_stage_llm_config(
    *,
    stage: str,
    resolved: dict[str, Any],
    resolution_meta: dict[str, Any],
    multipass_cfg: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    stage_name = str(stage or "").strip().lower()
    if stage_name not in {"plan", "step", "synth"}:
        raise ReviewflowError(f"Unsupported multipass llm stage: {stage!r}")
    resolved_meta = (
        dict(resolution_meta.get("resolved"))
        if isinstance(resolution_meta.get("resolved"), dict)
        else {}
    )
    generic_value = str(resolved.get("reasoning_effort") or "").strip() or None
    generic_source = str(resolved_meta.get("reasoning_effort_source") or "").strip() or "unset"
    base_value = generic_value
    base_source = f"reasoning_effort:{generic_source}"

    stage_resolved = dict(resolved)
    stage_resolution_meta = dict(resolution_meta)
    stage_resolved_meta = dict(resolved_meta)
    stage_meta = {
        "stage": stage_name,
        "model": str(stage_resolved.get("model") or "").strip() or None,
        "applied_reasoning_effort_field": "reasoning_effort",
        "base_reasoning_effort": base_value,
        "base_reasoning_effort_source": base_source,
        "override_reasoning_effort": None,
        "override_reasoning_effort_source": "unset",
        "effective_reasoning_effort": base_value,
        "effective_reasoning_effort_source": "inherited",
    }
    stage_resolved["reasoning_effort"] = base_value
    stage_resolved_meta["reasoning_effort"] = base_value
    stage_resolved_meta["reasoning_effort_source"] = base_source
    stage_resolution_meta["resolved"] = stage_resolved_meta
    stage_resolution_meta["multipass_stage_reasoning"] = dict(stage_meta)
    return stage_resolved, stage_resolution_meta, stage_meta


def _resolve_named_llm_preset(
    *,
    selected_name: str,
    presets: dict[str, Any],
    builtin_presets: dict[str, dict[str, Any]],
) -> tuple[dict[str, Any], str]:
    if selected_name == "gemini-cli":
        _raise_removed_gemini_support(context="The built-in preset `gemini-cli` is no longer available.")
    if selected_name in presets and isinstance(presets[selected_name], dict):
        base_preset = dict(presets[selected_name])
        resolved_preset_id = str(base_preset.get("preset") or selected_name).strip() or selected_name
    elif selected_name in builtin_presets:
        base_preset = dict(builtin_presets[selected_name])
        base_preset["preset"] = selected_name
        base_preset["_source_mode"] = "builtin_direct"
        resolved_preset_id = selected_name
    else:
        available = sorted(set(presets.keys()) | set(builtin_presets.keys()))
        raise ReviewflowError(
            f"Unknown llm preset: {selected_name!r}. Available presets: {', '.join(available) or '(none)'}"
        )

    transport = str(base_preset.get("transport") or "").strip().lower()
    provider = str(base_preset.get("provider") or "").strip().lower()
    if transport not in LLM_TRANSPORT_CHOICES:
        raise ReviewflowError(f"Invalid llm preset transport for {selected_name!r}: {transport!r}")
    if transport == "http" and provider not in HTTP_LLM_PROVIDERS:
        raise ReviewflowError(f"Invalid HTTP llm provider for {selected_name!r}: {provider!r}")
    if transport == "cli" and provider not in CLI_LLM_PROVIDERS:
        raise ReviewflowError(f"Invalid CLI llm provider for {selected_name!r}: {provider!r}")
    return base_preset, resolved_preset_id


def resolve_utility_llm_config(
    *,
    main_resolved: dict[str, Any],
    main_resolution_meta: dict[str, Any],
    reviewflow_config_path: Path | None,
    utility_llm_preset: str | None = None,
    utility_llm_model: str | None = None,
    utility_llm_effort: str | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    llm_cfg, llm_meta = load_reviewflow_llm_config(config_path=reviewflow_config_path)
    utility_cfg = llm_cfg.get("utility") if isinstance(llm_cfg.get("utility"), dict) else {}

    def _utility_pick(field: str, caller_value: object) -> tuple[Any, str, str, bool]:
        caller_text = str(caller_value or "").strip() if caller_value is not None else None
        if caller_text:
            return caller_text, "caller_override", "caller_override", False
        toml_value = utility_cfg.get(field) if isinstance(utility_cfg, dict) else None
        toml_text = str(toml_value or "").strip() if toml_value is not None else None
        if toml_text:
            return toml_text, "cure.toml", "[llm.utility]", False
        return main_resolved.get(field), "inherited", "main_llm", True

    selected_name, preset_source, preset_source_detail, preset_inherited = _utility_pick(
        "preset", utility_llm_preset
    )
    model, model_source, model_source_detail, model_inherited = _utility_pick("model", utility_llm_model)
    reasoning_effort, effort_source, effort_source_detail, effort_inherited = _utility_pick(
        "reasoning_effort", utility_llm_effort
    )

    if preset_inherited:
        resolved = dict(main_resolved)
        resolved_preset_id = str(resolved.get("preset") or "").strip() or None
        selected_name = str(resolved.get("selected_name") or resolved_preset_id or "").strip() or None
    else:
        selected_text = str(selected_name or "").strip()
        base_preset, resolved_preset_id = _resolve_named_llm_preset(
            selected_name=selected_text,
            presets=llm_cfg.get("presets", {}) if isinstance(llm_cfg.get("presets"), dict) else {},
            builtin_presets=builtin_llm_presets(),
        )
        transport = str(base_preset.get("transport") or "").strip().lower()
        provider = str(base_preset.get("provider") or "").strip().lower()
        resolved = {
            "preset": resolved_preset_id,
            "selected_name": selected_text,
            "transport": transport,
            "provider": provider,
            "command": str(base_preset.get("command") or provider).strip() if transport == "cli" else None,
            "endpoint": str(base_preset.get("endpoint") or "responses").strip() if transport == "http" else None,
            "base_url": str(base_preset.get("base_url") or "").strip() or None,
            "api_key": str(base_preset.get("api_key") or "").strip() or None,
            "text_verbosity": base_preset.get("text_verbosity"),
            "max_output_tokens": (
                int(base_preset.get("max_output_tokens")) if isinstance(base_preset.get("max_output_tokens"), int) else None
            ),
            "store": base_preset.get("store") if isinstance(base_preset.get("store"), bool) else None,
            "include": _string_list(base_preset.get("include")),
            "metadata": _plain_dict(base_preset.get("metadata")),
            "headers": _string_dict(base_preset.get("headers")),
            "request": _plain_dict(base_preset.get("request")),
            "env": _string_dict(base_preset.get("env")),
            "capabilities": {"supports_resume": provider in LLM_RESUME_PROVIDERS},
        }

    provider = str(resolved.get("provider") or "").strip().lower()
    reasoning_effort = _normalize_optional_reasoning_effort(
        raw=reasoning_effort,
        field_name="utility llm reasoning_effort",
        provider=provider,
    )
    resolved["model"] = model
    resolved["reasoning_effort"] = reasoning_effort
    if preset_inherited:
        resolved["preset"] = resolved_preset_id
        resolved["selected_name"] = selected_name

    meta: dict[str, Any] = {
        "llm_config": llm_meta,
        "main_llm": main_resolution_meta,
        "selected_preset_source": preset_source,
        "selected_name": selected_name,
        "resolved_preset_id": resolved.get("preset"),
        "resolved": {
            "preset": resolved.get("preset"),
            "preset_source": preset_source,
            "preset_source_detail": preset_source_detail,
            "preset_inherited": preset_inherited,
            "model": model,
            "model_source": model_source,
            "model_source_detail": model_source_detail,
            "model_inherited": model_inherited,
            "reasoning_effort": reasoning_effort,
            "reasoning_effort_source": effort_source,
            "reasoning_effort_source_detail": effort_source_detail,
            "reasoning_effort_inherited": effort_inherited,
        },
        "runtime_overrides": {
            "preset": (str(utility_llm_preset).strip() if utility_llm_preset else None),
            "model": (str(utility_llm_model).strip() if utility_llm_model else None),
            "reasoning_effort": (str(utility_llm_effort).strip() if utility_llm_effort else None),
        },
    }
    return resolved, meta


def _raise_effort_migration_error(*, field_name: str, replacement: str) -> None:
    raise ReviewflowError(f"{field_name} is no longer supported. Migrate to `{replacement}`.")


def _validate_no_legacy_effort_controls(*, raw: dict[str, Any], field_scope: str) -> None:
    deprecated_fields = (
        "plan_reasoning_effort",
        "step_reasoning_effort",
        "synth_reasoning_effort",
    )
    for name in deprecated_fields:
        if raw.get(name) not in (None, "", [], {}):
            _raise_effort_migration_error(field_name=f"{field_scope}.{name}", replacement="llm.reasoning_effort")


def _reviewflow_defaults_meta(resolution_meta: dict[str, Any]) -> dict[str, Any]:
    reviewflow_defaults = resolution_meta.get("reviewflow_defaults")
    if isinstance(reviewflow_defaults, dict):
        return dict(reviewflow_defaults)
    legacy_defaults = resolution_meta.get("legacy_codex_defaults")
    if isinstance(legacy_defaults, dict):
        return dict(legacy_defaults)
    return {}


def apply_llm_env(base_env: dict[str, str], *, resolved: dict[str, Any]) -> dict[str, str]:
    env = dict(base_env)
    env.update(_string_dict(resolved.get("env")))
    return env


def build_curated_subprocess_env(
    *,
    inherited_env: dict[str, str] | None = None,
    extra_env: dict[str, str] | None = None,
    home_override: Path | None = None,
) -> dict[str, str]:
    source = inherited_env if inherited_env is not None else os.environ
    env: dict[str, str] = {}
    for key in CURATED_ENV_INHERIT_KEYS:
        value = str(source.get(key) or "").strip()
        if value:
            env[key] = value
    if home_override is not None:
        env["HOME"] = str(home_override)
    if extra_env:
        env.update({str(k): str(v) for k, v in extra_env.items() if str(v)})
    return env


def augment_cli_provider_session_env(
    *,
    env: dict[str, str],
    provider: str,
    inherited_env: dict[str, str] | None = None,
) -> dict[str, str]:
    prefixes = CLI_PROVIDER_SESSION_ENV_PREFIXES.get(str(provider or "").strip().lower())
    if not prefixes:
        return env
    source = inherited_env if inherited_env is not None else os.environ
    merged = dict(env)
    for key, raw_value in source.items():
        if not any(key.startswith(prefix) for prefix in prefixes):
            continue
        value = str(raw_value or "").strip()
        if value:
            merged[key] = value
    return merged


def _dedupe_paths(paths: list[Path]) -> list[Path]:
    seen: set[str] = set()
    out: list[Path] = []
    for path in paths:
        resolved = str(path.resolve(strict=False))
        if resolved in seen:
            continue
        seen.add(resolved)
        out.append(path)
    return out


def load_reviewflow_multipass_defaults(
    *, config_path: Path | None = None
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Load reviewflow-level multipass defaults from the active reviewflow config.

    Schema:
      [multipass]
      enabled = true
      max_steps = 20
      step_workers = 4
      plan_reasoning_effort = "xhigh"
      step_reasoning_effort = "medium"
      synth_reasoning_effort = "xhigh"
    """

    path = config_path or _default_reviewflow_config_path()
    raw = load_toml(path)
    mp = raw.get("multipass", {}) if isinstance(raw, dict) else {}
    mp = mp if isinstance(mp, dict) else {}

    enabled = mp.get("enabled")
    if not isinstance(enabled, bool):
        enabled = DEFAULT_MULTIPASS_ENABLED

    max_steps = mp.get("max_steps")
    if not isinstance(max_steps, int):
        max_steps = DEFAULT_MULTIPASS_MAX_STEPS

    step_workers = mp.get("step_workers")
    if isinstance(step_workers, bool) or not isinstance(step_workers, int):
        step_workers = DEFAULT_MULTIPASS_STEP_WORKERS

    _validate_no_legacy_effort_controls(raw=mp, field_scope="[multipass]")

    grounding_mode_raw = mp.get("grounding_mode")
    if grounding_mode_raw is None:
        grounding_mode = DEFAULT_MULTIPASS_GROUNDING_MODE
    elif isinstance(grounding_mode_raw, str):
        grounding_mode = grounding_mode_raw.strip().lower()
        if grounding_mode not in MULTIPASS_GROUNDING_MODES:
            raise ReviewflowError(
                "Invalid [multipass].grounding_mode in reviewflow config. "
                "Expected one of: strict, warn, off."
            )
    else:
        raise ReviewflowError(
            "Invalid [multipass].grounding_mode in reviewflow config. "
            "Expected one of: strict, warn, off."
        )
    if max_steps < 1:
        max_steps = 1
    if max_steps > MULTIPASS_MAX_STEPS_HARD_CAP:
        max_steps = MULTIPASS_MAX_STEPS_HARD_CAP
    if step_workers < 1:
        step_workers = 1
    if step_workers > MULTIPASS_STEP_WORKERS_HARD_CAP:
        step_workers = MULTIPASS_STEP_WORKERS_HARD_CAP

    cfg: dict[str, Any] = {
        "enabled": bool(enabled),
        "max_steps": int(max_steps),
        "step_workers": int(step_workers),
        "grounding_mode": grounding_mode,
    }
    meta: dict[str, Any] = {
        "config_path": str(path),
        "loaded": bool(raw),
        "multipass": dict(cfg),
    }
    return cfg, meta


def load_reviewflow_codex_defaults(
    *, config_path: Path | None = None
) -> tuple[dict[str, str], dict[str, Any]]:
    path = config_path or _default_reviewflow_config_path()
    raw = load_toml(path)
    wanted_keys = ("model", "model_reasoning_effort", "plan_mode_reasoning_effort")

    source_table = "codex"
    codex = raw.get("codex", {}) if isinstance(raw, dict) else {}
    codex = codex if isinstance(codex, dict) else {}
    if codex.get("plan_mode_reasoning_effort") not in (None, "", [], {}):
        _raise_effort_migration_error(
            field_name="[codex].plan_mode_reasoning_effort",
            replacement="llm.reasoning_effort",
        )
    if not any(isinstance(codex.get(key), str) and codex.get(key).strip() for key in wanted_keys):
        root_defaults = raw if isinstance(raw, dict) else {}
        if root_defaults.get("plan_mode_reasoning_effort") not in (None, "", [], {}):
            _raise_effort_migration_error(
                field_name="[root].plan_mode_reasoning_effort",
                replacement="llm.reasoning_effort",
            )
        if any(isinstance(root_defaults.get(key), str) and root_defaults.get(key).strip() for key in wanted_keys):
            codex = root_defaults
            source_table = "root"

    defaults: dict[str, str] = {}
    for key in wanted_keys:
        val = codex.get(key)
        if isinstance(val, str) and val.strip():
            defaults[key] = val.strip()

    meta: dict[str, Any] = {
        "config_path": str(path),
        "loaded": bool(raw),
        "codex": dict(defaults),
        "codex_source_table": source_table if defaults else "unset",
    }
    return defaults, meta


def _string_dict(raw: object) -> dict[str, str]:
    if not isinstance(raw, dict):
        return {}
    out: dict[str, str] = {}
    for key, value in raw.items():
        name = str(key or "").strip()
        if not name:
            continue
        out[name] = str(value)
    return out


def _plain_dict(raw: object) -> dict[str, Any]:
    if not isinstance(raw, dict):
        return {}
    out: dict[str, Any] = {}
    for key, value in raw.items():
        name = str(key or "").strip()
        if not name:
            continue
        out[name] = value
    return out


def _string_list(raw: object) -> list[str]:
    if not isinstance(raw, list):
        return []
    return [str(item).strip() for item in raw if str(item).strip()]


def _raise_removed_gemini_support(*, context: str) -> None:
    supported = ", ".join(BUILTIN_LLM_PRESET_IDS)
    raise ReviewflowError(
        "Gemini support was removed from CURe. "
        f"{context} Use supported presets instead: {supported}."
    )


def builtin_llm_presets() -> dict[str, dict[str, Any]]:
    return {
        "codex-cli": {
            "transport": "cli",
            "provider": "codex",
            "command": "codex",
            "endpoint": None,
            "base_url": None,
            "api_key": None,
            "store": None,
            "include": [],
            "metadata": {},
            "headers": {},
            "request": {},
            "env": {},
            "reasoning_effort": "high",
            "text_verbosity": None,
            "max_output_tokens": None,
        },
        "claude-cli": {
            "transport": "cli",
            "provider": "claude",
            "command": "claude",
            "endpoint": None,
            "base_url": None,
            "api_key": None,
            "store": None,
            "include": [],
            "metadata": {},
            "headers": {},
            "request": {},
            "env": {},
            "model": CLAUDE_CLI_DEFAULT_MODEL,
            "reasoning_effort": CLAUDE_CLI_DEFAULT_REASONING_EFFORT,
            "text_verbosity": None,
            "max_output_tokens": None,
        },
        "openai-responses": {
            "transport": "http",
            "provider": "openai",
            "command": None,
            "endpoint": "responses",
            "base_url": "https://api.openai.com/v1",
            "store": None,
            "include": [],
            "metadata": {},
            "headers": {},
            "request": {},
            "env": {},
        },
        "openrouter-responses": {
            "transport": "http",
            "provider": "openrouter",
            "command": None,
            "endpoint": "responses",
            "base_url": "https://openrouter.ai/api/v1",
            "store": None,
            "include": [],
            "metadata": {},
            "headers": {},
            "request": {},
            "env": {},
        },
    }


def _preset_compat_id_from_explicit_block(raw_preset: dict[str, Any]) -> str | None:
    transport = str(raw_preset.get("transport") or "").strip().lower()
    provider = str(raw_preset.get("provider") or "").strip().lower()
    endpoint = str(raw_preset.get("endpoint") or "responses").strip().lower()
    base_url = str(raw_preset.get("base_url") or "").strip().rstrip("/")
    command = str(raw_preset.get("command") or "").strip()

    if transport == "cli" and provider == "codex" and command in {"", "codex"}:
        return "codex-cli"
    if transport == "cli" and provider == "claude" and command in {"", "claude"}:
        return "claude-cli"
    if (
        transport == "http"
        and provider == "openai"
        and endpoint == "responses"
        and base_url in {"", "https://api.openai.com/v1"}
    ):
        return "openai-responses"
    if (
        transport == "http"
        and provider == "openrouter"
        and endpoint == "responses"
        and base_url in {"", "https://openrouter.ai/api/v1"}
    ):
        return "openrouter-responses"
    return None


def _normalized_preset_overrides(raw_preset: dict[str, Any]) -> dict[str, Any]:
    _validate_no_legacy_effort_controls(raw=raw_preset, field_scope="[llm_presets]")
    return {
        "model": str(raw_preset.get("model") or "").strip() or None,
        "reasoning_effort": str(raw_preset.get("reasoning_effort") or "").strip() or None,
        "text_verbosity": str(raw_preset.get("text_verbosity") or "").strip() or None,
        "max_output_tokens": (
            int(raw_preset.get("max_output_tokens"))
            if isinstance(raw_preset.get("max_output_tokens"), int)
            else None
        ),
        "request": _plain_dict(raw_preset.get("request")),
        "api_key": str(raw_preset.get("api_key") or "").strip() or None,
        "store": raw_preset.get("store") if isinstance(raw_preset.get("store"), bool) else None,
        "include": _string_list(raw_preset.get("include")),
        "metadata": _plain_dict(raw_preset.get("metadata")),
        "headers": _string_dict(raw_preset.get("headers")),
        "env": _string_dict(raw_preset.get("env")),
    }


def _merge_builtin_preset(*, preset_id: str, raw_preset: dict[str, Any], source_mode: str) -> dict[str, Any]:
    builtins = builtin_llm_presets()
    if preset_id not in builtins:
        raise ReviewflowError(
            f"Unknown built-in llm preset: {preset_id!r}. Expected one of: {', '.join(BUILTIN_LLM_PRESET_IDS)}"
        )
    merged = dict(builtins[preset_id])
    overrides = _normalized_preset_overrides(raw_preset)
    for key, value in overrides.items():
        if key in {"request", "metadata", "headers", "env"}:
            merged[key] = dict(value)
            continue
        if key == "include":
            merged[key] = list(value)
            continue
        if value not in (None, "", [], {}):
            merged[key] = value
    merged["preset"] = preset_id
    merged["_source_mode"] = source_mode
    merged["_explicit_overrides"] = sorted(
        key for key, value in overrides.items() if value not in (None, "", [], {})
    )
    return merged


def load_reviewflow_llm_config(
    *, config_path: Path | None = None
) -> tuple[dict[str, Any], dict[str, Any]]:
    path = config_path or _default_reviewflow_config_path()
    raw = load_toml(path)
    llm = raw.get("llm", {}) if isinstance(raw, dict) else {}
    llm = llm if isinstance(llm, dict) else {}
    _validate_no_legacy_effort_controls(raw=llm, field_scope="[llm]")
    default_preset = str(llm.get("default_preset") or "").strip() or None
    if default_preset == "gemini-cli":
        _raise_removed_gemini_support(context="The built-in preset `gemini-cli` is no longer available.")
    utility_raw = llm.get("utility", {})
    if utility_raw in (None, ""):
        utility_raw = {}
    if utility_raw and not isinstance(utility_raw, dict):
        raise ReviewflowError("[llm.utility] must be a table when configured.")
    utility_section = utility_raw if isinstance(utility_raw, dict) else {}
    utility = {
        "preset": str(utility_section.get("preset") or "").strip() or None,
        "model": str(utility_section.get("model") or "").strip() or None,
        "reasoning_effort": str(utility_section.get("reasoning_effort") or "").strip() or None,
    }

    presets_raw = raw.get("llm_presets", {}) if isinstance(raw, dict) else {}
    presets_raw = presets_raw if isinstance(presets_raw, dict) else {}
    presets: dict[str, dict[str, Any]] = {}
    deprecated_explicit_presets: list[str] = []
    invalid_mixed_presets: list[str] = []
    removed_gemini_presets: list[str] = []
    for raw_name, raw_preset in presets_raw.items():
        name = str(raw_name or "").strip()
        if not name or not isinstance(raw_preset, dict):
            continue
        builtin_id = str(raw_preset.get("preset") or "").strip()
        transport = str(raw_preset.get("transport") or "").strip().lower()
        provider = str(raw_preset.get("provider") or "").strip().lower()
        removed_keys = {"transport", "provider", "endpoint", "base_url", "command"}
        present_removed = [key for key in removed_keys if key in raw_preset]
        if builtin_id == "gemini-cli" or (transport == "cli" and provider == "gemini"):
            removed_gemini_presets.append(name)
            continue
        if builtin_id:
            if present_removed:
                invalid_mixed_presets.append(name)
                continue
            preset = _merge_builtin_preset(preset_id=builtin_id, raw_preset=raw_preset, source_mode="builtin")
        else:
            compat_id = _preset_compat_id_from_explicit_block(raw_preset)
            if compat_id is None:
                continue
            deprecated_explicit_presets.append(name)
            preset = _merge_builtin_preset(
                preset_id=compat_id,
                raw_preset=raw_preset,
                source_mode="deprecated_explicit",
            )
        presets[name] = preset

    if invalid_mixed_presets:
        raise ReviewflowError(
            "llm preset blocks cannot mix `preset = ...` with explicit transport/provider/command/base_url/endpoint "
            f"fields: {', '.join(sorted(invalid_mixed_presets))}"
        )
    if removed_gemini_presets:
        _raise_removed_gemini_support(
            context=(
                "Remove or migrate Gemini llm preset blocks: "
                f"{', '.join(sorted(removed_gemini_presets))}."
            ),
        )

    cfg = {"default_preset": default_preset, "presets": presets, "utility": utility}
    meta: dict[str, Any] = {
        "config_path": str(path),
        "loaded": bool(raw),
        "default_preset": default_preset,
        "utility": dict(utility),
        "preset_names": sorted(presets.keys()),
        "builtin_preset_ids": list(BUILTIN_LLM_PRESET_IDS),
        "deprecated_explicit_presets": sorted(deprecated_explicit_presets),
    }
    return cfg, meta


def _normalize_agent_runtime_profile(value: object, *, source: str) -> str | None:
    text = str(value or "").strip().lower()
    if not text:
        return None
    if text not in AGENT_RUNTIME_PROFILE_CHOICES:
        raise ReviewflowError(
            f"Invalid agent runtime profile from {source}: {text!r}. "
            f"Expected one of: {', '.join(AGENT_RUNTIME_PROFILE_CHOICES)}"
        )
    return text


def load_reviewflow_agent_runtime_config(
    *, config_path: Path | None = None
) -> tuple[dict[str, Any], dict[str, Any]]:
    path = config_path or _default_reviewflow_config_path()
    raw = load_toml(path)
    section = raw.get("agent_runtime", {}) if isinstance(raw, dict) else {}
    section = section if isinstance(section, dict) else {}
    if "gemini" in section:
        _raise_removed_gemini_support(
            context="Remove the `[agent_runtime.gemini]` block from the CURe config.",
        )

    profile = _normalize_agent_runtime_profile(section.get("profile"), source="config")
    cfg = {"profile": profile}
    meta = {
        "config_path": str(path),
        "loaded": bool(raw),
        "agent_runtime": {
            "profile": profile,
        },
    }
    return cfg, meta


def resolve_agent_runtime_profile(
    *,
    cli_value: str | None,
    config_path: Path | None = None,
    config_enabled: bool = True,
) -> tuple[str, str, dict[str, Any], dict[str, Any]]:
    cfg, meta = load_reviewflow_agent_runtime_config(config_path=config_path)
    cli_profile = _normalize_agent_runtime_profile(cli_value, source="cli")
    if cli_profile is not None:
        return cli_profile, "cli", cfg, meta

    env_profile = _normalize_agent_runtime_profile(
        _read_supported_env_value("CURE_AGENT_RUNTIME_PROFILE", "REVIEWFLOW_AGENT_RUNTIME_PROFILE"),
        source="env",
    )
    if env_profile is not None:
        return env_profile, "env", cfg, meta

    if config_enabled:
        config_profile = _normalize_agent_runtime_profile(cfg.get("profile"), source="config")
        if config_profile is not None:
            return config_profile, "config", cfg, meta

    return DEFAULT_AGENT_RUNTIME_PROFILE, "default", cfg, meta


def _base_codex_runtime_defaults(base_config_path: Path) -> dict[str, Any]:
    raw = load_toml(base_config_path)
    return {
        "path": str(base_config_path),
        "loaded": bool(raw),
        "model": str(raw.get("model") or "").strip() or None,
        "sandbox_mode": str(raw.get("sandbox_mode") or "").strip() or None,
        "web_search": str(raw.get("web_search") or "").strip() or None,
        "reasoning_effort": str(raw.get("model_reasoning_effort") or "").strip() or None,
    }


def _synthetic_legacy_codex_preset(
    *, base_codex_config_path: Path, reviewflow_config_path: Path | None
) -> dict[str, Any]:
    legacy_defaults, _ = load_reviewflow_codex_defaults(config_path=reviewflow_config_path)
    preset = dict(builtin_llm_presets()[DEFAULT_IMPLICIT_CODEX_PRESET])
    explicit_overrides: list[str] = []
    if legacy_defaults.get("model") not in (None, ""):
        explicit_overrides.append("model")
    if legacy_defaults.get("model_reasoning_effort") not in (None, ""):
        explicit_overrides.append("reasoning_effort")
    preset.update(
        {
            "model": legacy_defaults.get("model"),
            "reasoning_effort": (
                legacy_defaults.get("model_reasoning_effort") or preset.get("reasoning_effort")
            ),
            "_source_mode": "synthetic_legacy_codex",
            "_explicit_overrides": explicit_overrides,
        }
    )
    return preset


def _autodetect_cli_preset_from_env(env: Mapping[str, str] | None = None) -> tuple[str | None, str | None]:
    current_env = os.environ if env is None else env
    claude_detected = any(str(current_env.get(key) or "").strip() for key in ("CLAUDE_CODE_SESSION", "CLAUDE_HOME"))
    codex_detected = any(str(current_env.get(key) or "").strip() for key in ("CODEX_THREAD_ID", "CODEX_HOME"))
    if claude_detected and not codex_detected:
        return "claude-cli", "detected_env"
    if codex_detected and not claude_detected:
        return "codex-cli", "detected_env"
    return None, None


def detect_installed_local_agents() -> dict[str, str]:
    installed: dict[str, str] = {}
    for agent in ("codex", "claude"):
        path = shutil.which(agent)
        if path:
            installed[agent] = path
    return installed


def resolve_local_agent_selection(
    *,
    base_codex_config_path: Path,
    reviewflow_config_path: Path | None,
    config_enabled: bool,
    cli_preset: str | None = None,
    cli_agent: str | None = None,
    env: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    installed = detect_installed_local_agents()
    installed_agents = sorted(installed.keys())
    hinted_preset, hinted_source = _autodetect_cli_preset_from_env(env)
    hinted_agent = LOCAL_AGENT_NAME_BY_PRESET.get(str(hinted_preset or "").strip())
    if hinted_agent not in installed:
        hinted_agent = None

    result: dict[str, Any] = {
        "installed_agents": installed_agents,
        "installed_agent_paths": dict(installed),
        "hinted_agent": hinted_agent,
        "hint_source": hinted_source if hinted_agent else None,
        "saved_preference": None,
        "saved_preference_source": None,
        "saved_preset": None,
        "saved_provider": None,
        "effective_agent": None,
        "effective_preset": None,
        "effective_provider": None,
        "source": None,
        "status": "missing",
        "detail": "no supported local coding agent executable is installed on PATH",
        "ready": False,
        "blocking": True,
    }

    explicit_agent = str(cli_agent or "").strip().lower()
    if explicit_agent:
        preset = LOCAL_AGENT_PRESET_BY_NAME.get(explicit_agent)
        if preset is None:
            raise ReviewflowError("Unsupported agent. Expected one of: codex, claude")
        if explicit_agent not in installed:
            result.update(
                {
                    "saved_preference": explicit_agent,
                    "saved_preference_source": "cli_agent",
                    "effective_agent": explicit_agent,
                    "effective_preset": preset,
                    "effective_provider": explicit_agent,
                    "source": "cli_agent",
                    "status": "unavailable_cli_agent",
                    "detail": f"`{explicit_agent}` is not installed on PATH",
                    "ready": False,
                    "blocking": True,
                }
            )
            return result
        result.update(
            {
                "saved_preference": explicit_agent,
                "saved_preference_source": "cli_agent",
                "saved_preset": preset,
                "saved_provider": explicit_agent,
                "effective_agent": explicit_agent,
                "effective_preset": preset,
                "effective_provider": explicit_agent,
                "source": "cli_agent",
                "status": "ready",
                "detail": f"using explicit agent override `{explicit_agent}`",
                "ready": True,
                "blocking": False,
            }
        )
        return result

    cli_selected = str(cli_preset or "").strip()
    if cli_selected:
        resolved, _ = resolve_llm_config(
            base_codex_config_path=base_codex_config_path,
            reviewflow_config_path=reviewflow_config_path,
            cli_preset=cli_selected,
            cli_model=None,
            cli_effort=None,
            cli_plan_effort=None,
            cli_verbosity=None,
            cli_max_output_tokens=None,
            cli_request_overrides={},
            cli_header_overrides={},
            deprecated_codex_model=None,
            deprecated_codex_effort=None,
            deprecated_codex_plan_effort=None,
        )
        provider = str(resolved.get("provider") or "").strip().lower()
        if provider not in LOCAL_AGENT_PRESET_BY_NAME:
            result.update(
                {
                    "effective_preset": resolved.get("preset"),
                    "effective_provider": provider or None,
                    "source": "cli_preset",
                    "status": "not_applicable",
                    "detail": f"explicit preset `{cli_selected}` does not use a local codex/claude CLI provider",
                    "ready": True,
                    "blocking": False,
                }
            )
            return result
        preset = LOCAL_AGENT_PRESET_BY_NAME[provider]
        if provider not in installed:
            result.update(
                {
                    "effective_agent": provider,
                    "effective_preset": preset,
                    "effective_provider": provider,
                    "source": "cli_preset",
                    "status": "broken_cli_preset",
                    "detail": f"explicit preset `{cli_selected}` resolved to `{provider}`, but `{provider}` is not installed on PATH",
                    "ready": False,
                    "blocking": True,
                }
            )
            return result
        result.update(
            {
                "effective_agent": provider,
                "effective_preset": preset,
                "effective_provider": provider,
                "source": "cli_preset",
                "status": "ready",
                "detail": f"using one-shot preset override `{cli_selected}`",
                "ready": True,
                "blocking": False,
            }
        )
        return result

    llm_cfg = {"default_preset": None}
    if config_enabled:
        llm_cfg, _ = load_reviewflow_llm_config(config_path=reviewflow_config_path)
    raw_saved_preset = str(llm_cfg.get("default_preset") or "").strip() or None
    if raw_saved_preset:
        resolved, _ = resolve_llm_config(
            base_codex_config_path=base_codex_config_path,
            reviewflow_config_path=reviewflow_config_path,
            cli_preset=None,
            cli_model=None,
            cli_effort=None,
            cli_plan_effort=None,
            cli_verbosity=None,
            cli_max_output_tokens=None,
            cli_request_overrides={},
            cli_header_overrides={},
            deprecated_codex_model=None,
            deprecated_codex_effort=None,
            deprecated_codex_plan_effort=None,
        )
        provider = str(resolved.get("provider") or "").strip().lower()
        result.update(
            {
                "saved_preference": raw_saved_preset,
                "saved_preference_source": "cure.toml",
                "saved_preset": resolved.get("preset"),
                "saved_provider": provider or None,
            }
        )
        if provider not in LOCAL_AGENT_PRESET_BY_NAME:
            result.update(
                {
                    "effective_preset": resolved.get("preset"),
                    "effective_provider": provider or None,
                    "source": "cure.toml",
                    "status": "invalid_saved_preference",
                    "detail": (
                        f"saved default preset `{raw_saved_preset}` does not resolve to the required local "
                        "codex/claude CLI provider"
                    ),
                    "ready": False,
                    "blocking": True,
                }
            )
            return result
        if provider not in installed:
            result.update(
                {
                    "effective_agent": provider,
                    "effective_preset": LOCAL_AGENT_PRESET_BY_NAME[provider],
                    "effective_provider": provider,
                    "source": "cure.toml",
                    "status": "broken_saved_preference",
                    "detail": f"saved default preset `{raw_saved_preset}` resolves to `{provider}`, but `{provider}` is not installed on PATH",
                    "ready": False,
                    "blocking": True,
                }
            )
            return result
        result.update(
            {
                "effective_agent": provider,
                "effective_preset": LOCAL_AGENT_PRESET_BY_NAME[provider],
                "effective_provider": provider,
                "source": "cure.toml",
                "status": "ready",
                "detail": f"using saved default preset `{raw_saved_preset}`",
                "ready": True,
                "blocking": False,
            }
        )
        return result

    if len(installed_agents) == 1:
        selected = installed_agents[0]
        result.update(
            {
                "effective_agent": selected,
                "effective_preset": LOCAL_AGENT_PRESET_BY_NAME[selected],
                "effective_provider": selected,
                "source": "auto_single_installed",
                "status": "auto_selectable",
                "detail": f"exactly one supported local agent is installed: `{selected}`",
                "ready": True,
                "blocking": False,
            }
        )
        return result
    if len(installed_agents) > 1:
        hint_text = f"; hinted default is `{hinted_agent}`" if hinted_agent else ""
        result.update(
            {
                "source": None,
                "status": "ambiguous",
                "detail": "multiple supported local agents are installed and no saved choice exists" + hint_text,
                "ready": False,
                "blocking": True,
            }
        )
        return result
    return result


def resolve_llm_config(
    *,
    base_codex_config_path: Path,
    reviewflow_config_path: Path | None,
    cli_preset: str | None,
    cli_model: str | None,
    cli_effort: str | None,
    cli_plan_effort: str | None,
    cli_verbosity: str | None,
    cli_max_output_tokens: int | None,
    cli_request_overrides: dict[str, Any] | None,
    cli_header_overrides: dict[str, str] | None,
    deprecated_codex_model: str | None,
    deprecated_codex_effort: str | None,
    deprecated_codex_plan_effort: str | None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    if cli_plan_effort not in (None, ""):
        _raise_effort_migration_error(field_name="--llm-plan-effort", replacement="--llm-effort")
    if deprecated_codex_effort not in (None, ""):
        _raise_effort_migration_error(field_name="--codex-effort", replacement="--llm-effort")
    if deprecated_codex_plan_effort not in (None, ""):
        _raise_effort_migration_error(field_name="--codex-plan-effort", replacement="--llm-effort")
    llm_cfg, llm_meta = load_reviewflow_llm_config(config_path=reviewflow_config_path)
    presets = llm_cfg.get("presets", {})
    presets = presets if isinstance(presets, dict) else {}
    builtin_presets = builtin_llm_presets()

    selected_name = str(cli_preset or "").strip()
    preset_source = "cli" if selected_name else ""
    if not selected_name:
        selected_name = str(llm_cfg.get("default_preset") or "").strip()
        preset_source = "cure.toml" if selected_name else ""
    if not selected_name:
        detected_name, detected_source = _autodetect_cli_preset_from_env()
        selected_name = str(detected_name or "").strip()
        preset_source = str(detected_source or "").strip()
    if selected_name == "gemini-cli":
        _raise_removed_gemini_support(context="The built-in preset `gemini-cli` is no longer available.")
    if selected_name:
        base_preset, resolved_preset_id = _resolve_named_llm_preset(
            selected_name=selected_name,
            presets=presets,
            builtin_presets=builtin_presets,
        )
    else:
        selected_name = DEFAULT_IMPLICIT_CODEX_PRESET
        preset_source = IMPLICIT_CODEX_PRESET_SOURCE
        base_preset = _synthetic_legacy_codex_preset(
            base_codex_config_path=base_codex_config_path,
            reviewflow_config_path=reviewflow_config_path,
        )
        resolved_preset_id = DEFAULT_IMPLICIT_CODEX_PRESET

    transport = str(base_preset.get("transport") or "").strip().lower()
    provider = str(base_preset.get("provider") or "").strip().lower()

    legacy_defaults, legacy_meta = load_reviewflow_codex_defaults(config_path=reviewflow_config_path)
    base_codex_meta = _base_codex_runtime_defaults(base_codex_config_path)

    explicit_preset_fields = {
        str(item).strip()
        for item in (
            base_preset.get("_explicit_overrides")
            if isinstance(base_preset.get("_explicit_overrides"), list)
            else []
        )
        if str(item).strip()
    }
    preset_source_mode = str(base_preset.get("_source_mode") or "").strip()

    def _preset_source_detail(field: str) -> str:
        if field in explicit_preset_fields:
            return "preset_explicit"
        if preset_source_mode in {"builtin", "builtin_direct", "deprecated_explicit"}:
            return "preset_builtin"
        if preset_source_mode == "synthetic_legacy_codex":
            return "preset_explicit"
        return "preset"

    def _pick(
        *, field: str, generic_value: Any, deprecated_value: Any = None, allow_deprecated: bool = False, base_value: Any = None
    ) -> tuple[Any, str, str]:
        if generic_value not in (None, ""):
            return generic_value, "cli", "cli"
        if allow_deprecated and provider == "codex" and deprecated_value not in (None, ""):
            return deprecated_value, "deprecated_codex_cli", "deprecated_codex_cli"
        preset_value = base_preset.get(field)
        if preset_value not in (None, "", [], {}):
            return preset_value, "preset", _preset_source_detail(field)
        if provider == "codex":
            legacy_key = {
                "reasoning_effort": "model_reasoning_effort",
                "plan_reasoning_effort": "plan_mode_reasoning_effort",
            }.get(field, field)
            legacy_value = legacy_defaults.get(legacy_key)
            if legacy_value not in (None, ""):
                return legacy_value, "reviewflow_defaults", "reviewflow_defaults"
            if base_value not in (None, ""):
                return base_value, "base_codex_config", "base_codex_config"
        return None, "unset", "unset"

    model, model_source, model_source_detail = _pick(
        field="model",
        generic_value=(str(cli_model).strip() if cli_model else None),
        deprecated_value=(str(deprecated_codex_model).strip() if deprecated_codex_model else None),
        allow_deprecated=True,
        base_value=base_codex_meta.get("model"),
    )
    reasoning_effort, reasoning_effort_source, reasoning_effort_source_detail = _pick(
        field="reasoning_effort",
        generic_value=(str(cli_effort).strip() if cli_effort else None),
        base_value=base_codex_meta.get("reasoning_effort"),
    )
    text_verbosity, text_verbosity_source, _ = _pick(
        field="text_verbosity",
        generic_value=(str(cli_verbosity).strip() if cli_verbosity else None),
    )
    max_output_tokens, max_output_tokens_source, _ = _pick(
        field="max_output_tokens",
        generic_value=cli_max_output_tokens,
    )

    reasoning_effort = _normalize_optional_reasoning_effort(
        raw=reasoning_effort,
        field_name="reasoning_effort",
        provider=provider,
    )

    request = dict(_plain_dict(base_preset.get("request")))
    if cli_request_overrides:
        request.update(cli_request_overrides)
    headers = dict(_string_dict(base_preset.get("headers")))
    if cli_header_overrides:
        headers.update({str(k): str(v) for k, v in cli_header_overrides.items()})

    resolved = {
        "preset": resolved_preset_id,
        "selected_name": selected_name,
        "transport": transport,
        "provider": provider,
        "command": str(base_preset.get("command") or provider).strip() if transport == "cli" else None,
        "endpoint": str(base_preset.get("endpoint") or "responses").strip() if transport == "http" else None,
        "base_url": str(base_preset.get("base_url") or "").strip() or None,
        "api_key": str(base_preset.get("api_key") or "").strip() or None,
        "model": model,
        "reasoning_effort": reasoning_effort,
        "text_verbosity": text_verbosity,
        "max_output_tokens": int(max_output_tokens) if isinstance(max_output_tokens, int) else None,
        "store": base_preset.get("store") if isinstance(base_preset.get("store"), bool) else None,
        "include": _string_list(base_preset.get("include")),
        "metadata": _plain_dict(base_preset.get("metadata")),
        "headers": headers,
        "request": request,
        "env": _string_dict(base_preset.get("env")),
        "capabilities": {"supports_resume": provider in LLM_RESUME_PROVIDERS},
    }

    meta: dict[str, Any] = {
        "llm_config": llm_meta,
        "reviewflow_defaults": legacy_meta,
        "base_codex_config": base_codex_meta,
        "selected_preset_source": preset_source,
        "selected_name": selected_name,
        "resolved_preset_id": resolved_preset_id,
        "resolved": {
            "model": model,
            "model_source": model_source,
            "model_source_detail": model_source_detail,
            "reasoning_effort": reasoning_effort,
            "reasoning_effort_source": reasoning_effort_source,
            "reasoning_effort_source_detail": reasoning_effort_source_detail,
            "text_verbosity": text_verbosity,
            "text_verbosity_source": text_verbosity_source,
            "max_output_tokens": resolved["max_output_tokens"],
            "max_output_tokens_source": max_output_tokens_source,
            "sandbox_mode": base_codex_meta.get("sandbox_mode"),
            "web_search": base_codex_meta.get("web_search"),
        },
        "runtime_overrides": {
            "preset": (str(cli_preset).strip() if cli_preset else None),
            "model": (str(cli_model).strip() if cli_model else None),
            "reasoning_effort": (str(cli_effort).strip() if cli_effort else None),
            "text_verbosity": (str(cli_verbosity).strip() if cli_verbosity else None),
            "max_output_tokens": cli_max_output_tokens if isinstance(cli_max_output_tokens, int) else None,
            "request": dict(cli_request_overrides or {}),
            "headers": dict(cli_header_overrides or {}),
            "deprecated_codex_model": (str(deprecated_codex_model).strip() if deprecated_codex_model else None),
        },
    }
    return resolved, meta


def build_http_response_request(resolved: dict[str, Any], *, prompt: str) -> dict[str, Any]:
    provider = str(resolved.get("provider") or "").strip().lower()
    base_url = str(resolved.get("base_url") or "").rstrip("/")
    endpoint = str(resolved.get("endpoint") or "responses").strip().lower()
    if provider not in HTTP_LLM_PROVIDERS:
        raise ReviewflowError(f"Unsupported HTTP llm provider: {provider!r}")
    if endpoint != "responses":
        raise ReviewflowError(f"Unsupported HTTP endpoint for reviewflow: {endpoint!r}")
    if not base_url:
        raise ReviewflowError("HTTP llm preset is missing base_url.")
    api_key = str(resolved.get("api_key") or "").strip()
    if not api_key:
        raise ReviewflowError(f"HTTP llm preset {resolved.get('preset')!r} is missing api_key.")

    url = f"{base_url}/responses"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    extra_headers = _string_dict(resolved.get("headers"))
    if provider == "openrouter":
        allowed = {"HTTP-Referer", "X-OpenRouter-Title", "X-OpenRouter-Categories", "X-Title"}
        extra_headers = {k: v for k, v in extra_headers.items() if k in allowed}
    headers.update(extra_headers)

    payload: dict[str, Any] = {"model": resolved.get("model"), "input": prompt}
    reasoning_effort = str(resolved.get("reasoning_effort") or "").strip()
    if reasoning_effort:
        payload["reasoning"] = {"effort": reasoning_effort}
    text_verbosity = str(resolved.get("text_verbosity") or "").strip()
    if text_verbosity:
        payload["text"] = {"verbosity": text_verbosity}
    if isinstance(resolved.get("store"), bool):
        payload["store"] = resolved["store"]
    include = _string_list(resolved.get("include"))
    if include:
        payload["include"] = include
    metadata = _plain_dict(resolved.get("metadata"))
    if metadata:
        payload["metadata"] = metadata
    if isinstance(resolved.get("max_output_tokens"), int):
        payload["max_output_tokens"] = int(resolved["max_output_tokens"])
    payload.update(_plain_dict(resolved.get("request")))
    return {"url": url, "headers": headers, "json": payload}


def resolve_codex_flags(
    *,
    base_config_path: Path,
    reviewflow_config_path: Path | None,
    cli_model: str | None,
    cli_effort: str | None,
    cli_plan_effort: str | None,
) -> tuple[list[str], dict[str, Any]]:
    base_cfg = load_toml(base_config_path)
    base_meta: dict[str, Any] = {"path": str(base_config_path), "loaded": bool(base_cfg)}

    base_model = base_cfg.get("model") if isinstance(base_cfg.get("model"), str) else None
    base_sandbox_mode = base_cfg.get("sandbox_mode") if isinstance(base_cfg.get("sandbox_mode"), str) else None
    base_web_search = base_cfg.get("web_search") if isinstance(base_cfg.get("web_search"), str) else None
    base_effort = (
        base_cfg.get("model_reasoning_effort")
        if isinstance(base_cfg.get("model_reasoning_effort"), str)
        else None
    )
    rf_defaults, rf_meta = load_reviewflow_codex_defaults(config_path=reviewflow_config_path)

    def _pick(key: str, base: str | None, cli: str | None) -> tuple[str | None, str]:
        if cli and cli.strip():
            return cli.strip(), "cli"
        rf = rf_defaults.get(key)
        if rf:
            return rf, "cure.toml"
        if base and str(base).strip():
            return str(base).strip(), "base_config"
        return None, "unset"

    model, model_src = _pick("model", base_model, cli_model)
    effort, effort_src = _pick("model_reasoning_effort", base_effort, cli_effort)
    if cli_plan_effort not in (None, ""):
        _raise_effort_migration_error(field_name="--llm-plan-effort", replacement="--llm-effort")
    effort = _normalize_optional_reasoning_effort(
        raw=effort,
        field_name="model_reasoning_effort",
        provider="codex",
    )

    flags: list[str] = []
    if model:
        flags.extend(["-m", model])
    if isinstance(base_sandbox_mode, str) and base_sandbox_mode in {"read-only", "workspace-write", "danger-full-access"}:
        flags.extend(["--sandbox", base_sandbox_mode])
    if base_web_search == "live":
        flags.append("--search")
    if effort:
        flags.extend(["-c", f"model_reasoning_effort={toml_string(effort)}"])

    meta: dict[str, Any] = {
        "base": base_meta,
        "reviewflow_defaults": rf_meta,
        "resolved": {
            "model": model,
            "model_source": model_src,
            "model_reasoning_effort": effort,
            "model_reasoning_effort_source": effort_src,
            "sandbox_mode": base_sandbox_mode,
            "web_search": base_web_search,
        },
        "flags": list(flags),
    }
    return flags, meta


def _resolve_review_intelligence_config_error(*, path: Path) -> ReviewflowError:
    return ReviewflowError(
        "Built-in prompt profiles require at least one active `[[review_intelligence.sources]]` entry "
        f"in {path}.\n"
        "Example:\n"
        f"{REVIEW_INTELLIGENCE_CONFIG_EXAMPLE.rstrip()}"
    )


def _review_intelligence_notes(raw: object, *, field_name: str) -> tuple[str, ...]:
    if raw is None:
        return ()
    if isinstance(raw, str):
        note = raw.strip()
        return (note,) if note else ()
    if not isinstance(raw, list):
        raise ReviewflowError(f"Invalid {field_name}: expected a string or array of strings.")
    notes: list[str] = []
    for item in raw:
        if not isinstance(item, str):
            raise ReviewflowError(f"Invalid {field_name}: expected a string or array of strings.")
        note = item.strip()
        if not note:
            raise ReviewflowError(f"Invalid {field_name}: notes must not be empty.")
        notes.append(note)
    return tuple(notes)


def _review_intelligence_sources(cfg: ReviewIntelligenceConfig) -> tuple[ReviewIntelligenceSource, ...]:
    return tuple(source for source in cfg.sources if source.mode != "off")


def _review_intelligence_source_mode(cfg: ReviewIntelligenceConfig, name: str) -> str | None:
    wanted = str(name or "").strip().lower()
    for source in cfg.sources:
        if source.name == wanted:
            return source.mode
    return None


def _review_intelligence_capability_signal(
    *, status: str, detail: str, path: str | None = None, host: str | None = None
) -> dict[str, Any]:
    payload: dict[str, Any] = {"status": status, "detail": detail}
    if path:
        payload["path"] = path
    if host:
        payload["host"] = host
    return payload


def _review_intelligence_status_counts(sources: list[dict[str, Any]]) -> dict[str, int]:
    counts = {state: 0 for state in sorted(REVIEW_INTELLIGENCE_CAPABILITY_STATES)}
    for source in sources:
        status = str(source.get("status") or "").strip().lower()
        if status in counts:
            counts[status] += 1
    return counts


def _runtime_capability_status(name: str) -> tuple[str, str]:
    path = shutil.which(name)
    if path:
        return "available", path
    return "unavailable", "not found on PATH"


def _doctor_check_to_capability(check: DoctorCheck, *, missing_is_unknown: bool = False) -> tuple[str, str]:
    if check.status == "ok":
        return "available", check.detail
    if missing_is_unknown:
        return "unknown", check.detail
    return "unavailable", check.detail


def _review_intelligence_runtime_github_capability(
    *,
    source: ReviewIntelligenceSource,
    env: dict[str, str],
    pr: PullRequestRef | None,
    staged_pr_context_path: Path | None,
) -> dict[str, Any]:
    gh_cfg = _resolve_optional_path(env.get("GH_CONFIG_DIR"))
    gh_cli_status, gh_cli_detail = _runtime_capability_status("gh")
    staged_pr_context_available = bool(staged_pr_context_path is not None and staged_pr_context_path.is_file())
    gh_cfg_available = bool(gh_cfg is not None and gh_cfg.is_dir())
    host = str(pr.host if pr is not None else "").strip() or None
    public_supported = bool(host and _supports_public_github_fallback(host))
    if public_supported:
        public_status = "unknown"
        public_detail = (
            "public github.com fallback is target-compatible but not preflighted for this run"
        )
    elif host:
        public_status = "unavailable"
        public_detail = "public GitHub fallback is not supported for this host"
    else:
        public_status = "unknown"
        public_detail = "public fallback stays target-dependent until a PR target is known"

    gh_auth_status = "available" if gh_cli_status == "available" and gh_cfg_available else "unknown"
    if gh_auth_status == "available":
        gh_auth_detail = f"staged gh config dir ready at {gh_cfg}"
    elif gh_cli_status == "available":
        gh_auth_detail = "gh is installed, but CURe did not stage authenticated gh config for this run"
    else:
        gh_auth_detail = "gh is unavailable, so authenticated gh access is unavailable"

    if staged_pr_context_available:
        status = "available"
        detail = "staged PR context is already available; use it first for GitHub context"
    elif gh_auth_status == "available":
        status = "available"
        detail = "authenticated gh access is staged for this review when extra GitHub context is needed"
    elif public_status == "unknown":
        status = "unknown"
        detail = "extra GitHub context was not preflighted; use staged context first and probe only if needed"
    else:
        status = "unavailable"
        detail = "no staged or preflighted GitHub context is available beyond the local checkout"

    return {
        "name": source.name,
        "mode": source.mode,
        "family": "github",
        "required": (source.mode == "required"),
        "preflight_required": (source.mode == "required"),
        "status": status,
        "detail": detail,
        "signals": {
            "staged_pr_context": _review_intelligence_capability_signal(
                status=("available" if staged_pr_context_available else "unavailable"),
                detail=(
                    f"staged PR context ready at {staged_pr_context_path}"
                    if staged_pr_context_available
                    else "no staged PR context path is available"
                ),
                path=(str(staged_pr_context_path) if staged_pr_context_available else None),
            ),
            "gh_cli": _review_intelligence_capability_signal(
                status=gh_cli_status,
                detail=gh_cli_detail,
            ),
            "gh_auth": _review_intelligence_capability_signal(
                status=gh_auth_status,
                detail=gh_auth_detail,
                path=(str(gh_cfg) if gh_cfg_available else None),
            ),
            "public_fallback": _review_intelligence_capability_signal(
                status=public_status,
                detail=public_detail,
                host=host,
            ),
        },
    }


def _review_intelligence_runtime_jira_capability(
    *,
    source: ReviewIntelligenceSource,
    env: dict[str, str],
    runtime_policy: dict[str, Any] | None,
) -> dict[str, Any]:
    staged_paths = runtime_policy.get("staged_paths") if isinstance(runtime_policy, dict) else {}
    jira_cfg = _resolve_optional_path(env.get("JIRA_CONFIG_FILE"))
    jira_cfg_available = bool(jira_cfg is not None and jira_cfg.is_file())
    rf_jira = _resolve_optional_path((staged_paths or {}).get("rf_jira"))
    rf_jira_available = bool(rf_jira is not None and rf_jira.is_file())
    jira_cli_status, jira_cli_detail = _runtime_capability_status("jira")

    missing: list[str] = []
    if not jira_cfg_available:
        missing.append("staged Jira config")
    if not rf_jira_available:
        missing.append("rf-jira helper")
    if jira_cli_status != "available":
        missing.append("jira CLI")

    if not missing:
        status = "available"
        detail = "staged Jira config and helper are ready if ticket context becomes relevant"
    else:
        status = "unavailable"
        detail = "missing " + ", ".join(missing)

    return {
        "name": source.name,
        "mode": source.mode,
        "family": "jira",
        "required": (source.mode == "required"),
        "preflight_required": (source.mode == "required"),
        "status": status,
        "detail": detail,
        "signals": {
            "config": _review_intelligence_capability_signal(
                status=("available" if jira_cfg_available else "unavailable"),
                detail=(
                    f"staged Jira config ready at {jira_cfg}"
                    if jira_cfg_available
                    else "CURe did not stage a Jira config for this run"
                ),
                path=(str(jira_cfg) if jira_cfg_available else None),
            ),
            "helper": _review_intelligence_capability_signal(
                status=("available" if rf_jira_available else "unavailable"),
                detail=(
                    f"rf-jira helper ready at {rf_jira}"
                    if rf_jira_available
                    else "rf-jira helper was not staged for this run"
                ),
                path=(str(rf_jira) if rf_jira_available else None),
            ),
            "jira_cli": _review_intelligence_capability_signal(
                status=jira_cli_status,
                detail=jira_cli_detail,
            ),
        },
    }


def _review_intelligence_doctor_github_capability(
    *,
    source: ReviewIntelligenceSource,
    target: DoctorTargetContext | None,
) -> dict[str, Any]:
    gh = _doctor_executable_check("gh")
    gh_auth = _doctor_gh_auth_check(host=(target.pr.host if target is not None else "github.com"))
    gh_status, gh_detail = _doctor_check_to_capability(gh, missing_is_unknown=(target is None))
    gh_auth_status, gh_auth_detail = _doctor_check_to_capability(gh_auth, missing_is_unknown=(target is None))
    if target is not None:
        if target.public_fallback_supported and target.public_pr_metadata_reachable:
            public_status = "available"
            public_detail = target.public_pr_metadata_detail
        elif target.public_fallback_supported:
            public_status = "unavailable"
            public_detail = target.public_pr_metadata_detail
        else:
            public_status = "unavailable"
            public_detail = "public GitHub fallback is not supported for this host"
    else:
        public_status = "unknown"
        public_detail = "public fallback stays target-dependent until `doctor --pr-url` is provided"

    if gh_auth_status == "available" or public_status == "available":
        status = "available"
        detail = (
            "authenticated gh access is available"
            if gh_auth_status == "available"
            else "public GitHub fallback is reachable for this target"
        )
    elif target is None:
        status = "unknown"
        detail = "target-specific GitHub capability stays lazy until a PR target is known"
    else:
        status = "unavailable"
        detail = "no authenticated gh access or reachable public GitHub fallback is available"

    return {
        "name": source.name,
        "mode": source.mode,
        "family": "github",
        "required": (source.mode == "required"),
        "preflight_required": (source.mode == "required"),
        "status": status,
        "detail": detail,
        "signals": {
            "staged_pr_context": _review_intelligence_capability_signal(
                status=("available" if target is not None else "unknown"),
                detail=(
                    "doctor target supplied; normal review flows will stage PR context first"
                    if target is not None
                    else "doctor has not resolved a PR target, so staged PR context is unknown"
                ),
            ),
            "gh_cli": _review_intelligence_capability_signal(
                status=gh_status,
                detail=gh_detail,
            ),
            "gh_auth": _review_intelligence_capability_signal(
                status=gh_auth_status,
                detail=gh_auth_detail,
                host=(target.pr.host if target is not None else "github.com"),
            ),
            "public_fallback": _review_intelligence_capability_signal(
                status=public_status,
                detail=public_detail,
                host=(target.pr.host if target is not None else None),
            ),
        },
    }


def _review_intelligence_doctor_jira_capability(source: ReviewIntelligenceSource) -> dict[str, Any]:
    jira = _doctor_executable_check("jira")
    jira_cfg = _default_jira_config_path()
    jira_cli_status, jira_cli_detail = _doctor_check_to_capability(jira)
    jira_cfg_available = jira_cfg.is_file()
    if jira_cfg_available and jira_cli_status == "available":
        status = "available"
        detail = "jira CLI and config are present for Jira-backed review context"
    else:
        status = "unavailable"
        detail = "jira CLI or config is missing"
    return {
        "name": source.name,
        "mode": source.mode,
        "family": "jira",
        "required": (source.mode == "required"),
        "preflight_required": (source.mode == "required"),
        "status": status,
        "detail": detail,
        "signals": {
            "config": _review_intelligence_capability_signal(
                status=("available" if jira_cfg_available else "unavailable"),
                detail=(str(jira_cfg) if jira_cfg_available else f"missing: {jira_cfg}"),
                path=str(jira_cfg),
            ),
            "jira_cli": _review_intelligence_capability_signal(
                status=jira_cli_status,
                detail=jira_cli_detail,
            ),
        },
    }


def resolve_review_intelligence_capabilities(
    cfg: ReviewIntelligenceConfig,
    *,
    env: dict[str, str] | None = None,
    runtime_policy: dict[str, Any] | None = None,
    pr: PullRequestRef | None = None,
    staged_pr_context_path: Path | None = None,
    doctor_target: DoctorTargetContext | None = None,
) -> dict[str, Any]:
    resolved_sources: list[dict[str, Any]] = []
    env_dict = env if isinstance(env, dict) else {}
    for source in _review_intelligence_sources(cfg):
        if source.name == "github":
            if doctor_target is not None or (env is None and runtime_policy is None and pr is None):
                capability = _review_intelligence_doctor_github_capability(source=source, target=doctor_target)
            else:
                capability = _review_intelligence_runtime_github_capability(
                    source=source,
                    env=env_dict,
                    pr=pr,
                    staged_pr_context_path=staged_pr_context_path,
                )
        elif source.name == "jira":
            if doctor_target is not None or (env is None and runtime_policy is None and pr is None):
                capability = _review_intelligence_doctor_jira_capability(source)
            else:
                capability = _review_intelligence_runtime_jira_capability(
                    source=source,
                    env=env_dict,
                    runtime_policy=runtime_policy,
                )
        else:
            capability = {
                "name": source.name,
                "mode": source.mode,
                "family": "custom",
                "required": (source.mode == "required"),
                "preflight_required": False,
                "status": "unknown",
                "detail": "CURe has no built-in capability resolver for this source family in v1",
                "signals": {},
            }
        resolved_sources.append(capability)

    return {
        "required_sources": [
            source["name"]
            for source in resolved_sources
            if bool(source.get("required"))
        ],
        "status_counts": _review_intelligence_status_counts(resolved_sources),
        "sources": resolved_sources,
    }


def attach_review_intelligence_capabilities(
    review_intelligence_meta: dict[str, Any],
    capability_summary: dict[str, Any] | None,
) -> dict[str, Any]:
    base = dict(review_intelligence_meta)
    if not capability_summary:
        return base
    capability_sources = capability_summary.get("sources") if isinstance(capability_summary, dict) else []
    capability_by_name = {
        str(item.get("name") or "").strip().lower(): dict(item)
        for item in capability_sources
        if isinstance(item, dict) and str(item.get("name") or "").strip()
    }
    sources = base.get("sources") if isinstance(base.get("sources"), list) else []
    enriched_sources: list[dict[str, Any]] = []
    for source in sources:
        if not isinstance(source, dict):
            continue
        enriched = dict(source)
        capability = capability_by_name.get(str(source.get("name") or "").strip().lower())
        if capability is not None:
            enriched["capability"] = capability
        enriched_sources.append(enriched)
    base["sources"] = enriched_sources
    base["capabilities"] = dict(capability_summary)
    return base


def _review_intelligence_source_guidance(
    source: ReviewIntelligenceSource, *, capability: dict[str, Any] | None = None
) -> str:
    capability_status = str((capability or {}).get("status") or "unknown").strip().lower() or "unknown"
    if source.name == "github":
        if capability_status == "available":
            detail = (
                "Staged PR context is already available. Use it first, then use `gh` / public GitHub context only "
                "when extra PR discussion or linked-issue context materially helps."
            )
        elif capability_status == "unavailable":
            detail = "Rely on staged PR context and local `git`; extra GitHub context is not currently available."
        else:
            detail = (
                "Prefer staged PR context first. Additional GitHub context may be available, but do not probe for it "
                "broadly before it is needed."
            )
    elif source.name == "jira":
        if source.mode == "when-referenced":
            detail = "Use Jira only when the change, PR, or commits reference a ticket and that context would clarify the review."
        elif source.mode == "required":
            detail = "Jira context is required for this review; confirm the relevant ticket context before finalizing."
        else:
            detail = "Use Jira when ticket context is readily available and materially clarifies the change."
        if capability_status == "unavailable":
            detail = f"{detail} Jira access is currently unavailable."
        elif capability_status == "unknown":
            detail = f"{detail} Availability remains lazy until the review actually needs it."
    else:
        detail = (
            f"Use `{source.name}` only if it is available and materially improves understanding of the code under review."
        )
    if source.notes:
        detail = f"{detail} {' '.join(source.notes)}"
    return f"- `{source.name}` (`{source.mode}`, `{capability_status}`): {detail}"


def _review_intelligence_meta_dict(
    cfg: ReviewIntelligenceConfig, *, path: Path, loaded: bool
) -> dict[str, Any]:
    return {
        "config_path": str(path),
        "loaded": loaded,
        "review_intelligence": {
            "notes": list(cfg.notes),
            "sources": [
                {
                    "name": source.name,
                    "mode": source.mode,
                    "notes": list(source.notes),
                }
                for source in cfg.sources
            ],
        },
    }


def load_review_intelligence_config(
    *, config_path: Path | None = None, require_active_sources: bool = False
) -> tuple[ReviewIntelligenceConfig, dict[str, Any]]:
    path = config_path or _default_reviewflow_config_path()
    raw = load_toml(path)
    review_intelligence = raw.get("review_intelligence", {}) if isinstance(raw, dict) else {}
    review_intelligence = review_intelligence if isinstance(review_intelligence, dict) else {}

    legacy_keys = {
        key
        for key in (
            "allow_hosts",
            "external_fetch_gateway",
            "max_bytes",
            "policy_mode",
            "timeout_seconds",
            "tool_prompt_fragment",
        )
        if key in review_intelligence
    }
    if legacy_keys:
        raise ReviewflowError(
            "Legacy review-intelligence config keys are no longer supported: "
            f"{', '.join(sorted(legacy_keys))}\n"
            "Use the structured schema:\n"
            f"{REVIEW_INTELLIGENCE_CONFIG_EXAMPLE.rstrip()}"
        )
    if isinstance(raw, dict) and ("crawl" in raw):
        raise ReviewflowError(
            "Deprecated `[crawl]` config is no longer supported.\n"
            "Use the structured schema:\n"
            f"{REVIEW_INTELLIGENCE_CONFIG_EXAMPLE.rstrip()}"
        )

    notes = _review_intelligence_notes(
        review_intelligence.get("notes"),
        field_name="[review_intelligence].notes",
    )
    sources_raw = review_intelligence.get("sources")
    if sources_raw is None:
        sources_raw = []
    if not isinstance(sources_raw, list):
        raise ReviewflowError("Invalid `[review_intelligence].sources`: expected an array of tables.")

    seen_source_names: set[str] = set()
    sources: list[ReviewIntelligenceSource] = []
    for idx, raw_source in enumerate(sources_raw):
        if not isinstance(raw_source, dict):
            raise ReviewflowError("Invalid `[review_intelligence].sources`: expected an array of tables.")
        name = str(raw_source.get("name") or "").strip().lower()
        if not name:
            raise ReviewflowError(
                f"Invalid `[review_intelligence].sources[{idx}].name`: expected a non-empty string."
            )
        if name in seen_source_names:
            raise ReviewflowError(f"Duplicate review-intelligence source name: {name}")
        seen_source_names.add(name)

        mode = str(raw_source.get("mode") or "").strip().lower()
        if mode not in REVIEW_INTELLIGENCE_SOURCE_MODES:
            allowed = ", ".join(sorted(REVIEW_INTELLIGENCE_SOURCE_MODES))
            raise ReviewflowError(
                f"Invalid review-intelligence source mode for `{name}`: expected one of {allowed}."
            )
        if mode == "required" and name not in _BUILTIN_REVIEW_INTELLIGENCE_SOURCE_NAMES:
            allowed = ", ".join(sorted(_BUILTIN_REVIEW_INTELLIGENCE_SOURCE_NAMES))
            raise ReviewflowError(
                f"Unknown required review-intelligence source `{name}`. Only built-in sources may be `required`: {allowed}."
            )
        source_notes = _review_intelligence_notes(
            raw_source.get("notes"),
            field_name=f"[review_intelligence].sources[{idx}].notes",
        )
        sources.append(
            ReviewIntelligenceSource(
                name=name,
                mode=mode,
                notes=source_notes,
            )
        )

    cfg = ReviewIntelligenceConfig(notes=notes, sources=tuple(sources))
    if require_active_sources:
        require_builtin_review_intelligence(cfg, config_path=path)
    return cfg, _review_intelligence_meta_dict(cfg, path=path, loaded=bool(raw))


def build_review_intelligence_guidance(
    cfg: ReviewIntelligenceConfig,
    *,
    capability_summary: dict[str, Any] | None = None,
) -> str:
    lines = [
        "## Review-Intelligence Guidance",
        "- Start with the staged PR context when it is already available.",
        "- Use local `git` as the authoritative source for code changes.",
        "- Use additional review-intelligence sources only when they materially improve understanding of the code under review.",
    ]
    capability_sources = capability_summary.get("sources") if isinstance(capability_summary, dict) else []
    capability_by_name = {
        str(source.get("name") or "").strip().lower(): source
        for source in capability_sources
        if isinstance(source, dict) and str(source.get("name") or "").strip()
    }
    if capability_by_name:
        lines.append("- Treat `available` sources as opportunistic helpers, and do not broad-probe optional sources up front.")
    active_sources = _review_intelligence_sources(cfg)
    if active_sources:
        lines.append("")
        lines.append("Configured sources:")
        lines.extend(
            _review_intelligence_source_guidance(
                source,
                capability=capability_by_name.get(source.name),
            )
            for source in active_sources
        )
    if cfg.notes:
        lines.append("")
        lines.append("Additional notes:")
        lines.extend(f"- {note}" for note in cfg.notes)
    return "\n".join(lines).strip() + "\n"


def require_builtin_review_intelligence(
    cfg: ReviewIntelligenceConfig, *, config_path: Path | None = None
) -> None:
    if _review_intelligence_sources(cfg):
        return
    raise _resolve_review_intelligence_config_error(path=(config_path or _default_reviewflow_config_path()))


def _chunkhound_config_error(*, reason: str, path: Path) -> ReviewflowError:
    return ReviewflowError(
        f"{reason}\n"
        f"Reviewflow ChunkHound config path: {path}\n"
        "Example:\n"
        f"{CHUNKHOUND_CONFIG_EXAMPLE.rstrip()}"
    )


def _read_chunkhound_json_config(path: Path) -> dict[str, Any]:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as e:
        raise ReviewflowError(f"ChunkHound base config not found: {path}") from e
    except Exception as e:
        raise ReviewflowError(f"ChunkHound base config is invalid JSON: {path} ({e})") from e
    if not isinstance(raw, dict):
        raise ReviewflowError(f"ChunkHound base config must be a JSON object: {path}")
    return raw


def _parse_chunkhound_numeric_override(raw: object, *, field_name: str, allow_float: bool = False) -> int | float:
    if allow_float and isinstance(raw, (int, float)) and float(raw) > 0:
        return float(raw)
    if isinstance(raw, int) and raw > 0:
        return int(raw)
    raise ReviewflowError(f"Invalid [chunkhound].{field_name}: expected a positive number.")


def load_reviewflow_chunkhound_config(
    *, config_path: Path | None = None, require: bool = True
) -> tuple[ReviewflowChunkHoundConfig | None, dict[str, Any]]:
    path = config_path or _default_reviewflow_config_path()
    raw = load_toml(path)
    section = raw.get("chunkhound") if isinstance(raw, dict) else None

    if section is None:
        if require:
            raise _chunkhound_config_error(reason="Missing required `[chunkhound]` section.", path=path)
        return None, {"config_path": str(path), "loaded": bool(raw), "chunkhound": None}

    if not isinstance(section, dict):
        raise _chunkhound_config_error(reason="`[chunkhound]` must be a table.", path=path)

    base_config_path_raw = str(section.get("base_config_path") or "").strip()
    if not base_config_path_raw:
        raise _chunkhound_config_error(reason="`[chunkhound].base_config_path` is required.", path=path)
    base_config_path = Path(base_config_path_raw).expanduser()
    if not base_config_path.is_absolute():
        raise _chunkhound_config_error(reason="`[chunkhound].base_config_path` must be an absolute path.", path=path)
    base_config_path = base_config_path.resolve(strict=False)
    _ = _read_chunkhound_json_config(base_config_path)

    indexing = section.get("indexing")
    indexing = indexing if isinstance(indexing, dict) else {}
    research = section.get("research")
    research = research if isinstance(research, dict) else {}

    if "include" in indexing and (not isinstance(indexing.get("include"), list)):
        raise ReviewflowError("Invalid [chunkhound].indexing.include: expected an array of strings.")
    if "exclude" in indexing and (not isinstance(indexing.get("exclude"), list)):
        raise ReviewflowError("Invalid [chunkhound].indexing.exclude: expected an array of strings.")

    indexing_include = tuple(_string_list(indexing.get("include"))) if ("include" in indexing) else None
    indexing_exclude = tuple(_string_list(indexing.get("exclude"))) if ("exclude" in indexing) else None
    per_file_timeout_seconds = (
        _parse_chunkhound_numeric_override(
            indexing.get("per_file_timeout_seconds"),
            field_name="indexing.per_file_timeout_seconds",
            allow_float=True,
        )
        if ("per_file_timeout_seconds" in indexing)
        else None
    )
    per_file_timeout_min_size_kb = (
        int(
            _parse_chunkhound_numeric_override(
                indexing.get("per_file_timeout_min_size_kb"),
                field_name="indexing.per_file_timeout_min_size_kb",
                allow_float=False,
            )
        )
        if ("per_file_timeout_min_size_kb" in indexing)
        else None
    )
    if "algorithm" in research and (not isinstance(research.get("algorithm"), str)):
        raise ReviewflowError("Invalid [chunkhound].research.algorithm: expected a non-empty string.")
    research_algorithm = str(research.get("algorithm") or "").strip() if ("algorithm" in research) else None
    if research_algorithm == "":
        raise ReviewflowError("Invalid [chunkhound].research.algorithm: expected a non-empty string.")

    cfg = ReviewflowChunkHoundConfig(
        base_config_path=base_config_path,
        indexing_include=indexing_include,
        indexing_exclude=indexing_exclude,
        per_file_timeout_seconds=per_file_timeout_seconds,
        per_file_timeout_min_size_kb=per_file_timeout_min_size_kb,
        research_algorithm=research_algorithm,
    )
    meta: dict[str, Any] = {
        "config_path": str(path),
        "loaded": bool(raw),
        "chunkhound": {
            "base_config_path": str(base_config_path),
            "base_config_fingerprint": json_fingerprint(base_config_path),
            "indexing": {
                "include": list(indexing_include) if indexing_include is not None else None,
                "exclude": list(indexing_exclude) if indexing_exclude is not None else None,
                "per_file_timeout_seconds": per_file_timeout_seconds,
                "per_file_timeout_min_size_kb": per_file_timeout_min_size_kb,
            },
            "research": {"algorithm": research_algorithm},
        },
    }
    return cfg, meta


def resolve_chunkhound_reviewflow_config(cfg: ReviewflowChunkHoundConfig) -> dict[str, Any]:
    base = _read_chunkhound_json_config(cfg.base_config_path)
    resolved = dict(base)

    indexing = base.get("indexing")
    indexing = dict(indexing) if isinstance(indexing, dict) else {}
    if cfg.indexing_include is not None:
        indexing.pop("_include", None)
        indexing["include"] = list(cfg.indexing_include)
    if cfg.indexing_exclude is not None:
        indexing["exclude"] = list(cfg.indexing_exclude)
    if cfg.per_file_timeout_seconds is not None:
        indexing["per_file_timeout_seconds"] = cfg.per_file_timeout_seconds
    if cfg.per_file_timeout_min_size_kb is not None:
        indexing["per_file_timeout_min_size_kb"] = cfg.per_file_timeout_min_size_kb
    if indexing:
        resolved["indexing"] = indexing

    research = base.get("research")
    research = dict(research) if isinstance(research, dict) else {}
    if cfg.research_algorithm is not None:
        research["algorithm"] = cfg.research_algorithm
    if research:
        resolved["research"] = research

    return resolved


def fingerprint_chunkhound_reviewflow_config(meta: dict[str, Any]) -> str:
    chunkhound = meta.get("chunkhound") if isinstance(meta.get("chunkhound"), dict) else {}
    canonical = json.dumps(chunkhound, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def load_chunkhound_runtime_config(
    *, config_path: Path | None = None, require: bool = True
) -> tuple[ReviewflowChunkHoundConfig, dict[str, Any], dict[str, Any]]:
    cfg, meta = load_reviewflow_chunkhound_config(config_path=config_path, require=require)
    if cfg is None:
        raise ReviewflowError("ChunkHound runtime config is unavailable.")
    resolved = resolve_chunkhound_reviewflow_config(cfg)
    return cfg, meta, resolved


def _doctor_executable_check(name: str) -> DoctorCheck:
    path = shutil.which(name)
    if path:
        return DoctorCheck(name=name, status="ok", detail=path)
    return DoctorCheck(name=name, status="fail", detail="not found on PATH")


def _default_jira_config_path() -> Path:
    rf = _loaded_shell_module()
    if rf is not None:
        candidate = getattr(rf, "_default_jira_config_path", None)
        if callable(candidate) and candidate is not _default_jira_config_path:
            return candidate()
    env_path = _resolve_optional_path(os.environ.get("JIRA_CONFIG_FILE"))
    if env_path is not None:
        return env_path
    return (Path.home() / ".config" / ".jira" / ".config.yml").resolve(strict=False)


def _doctor_gh_auth_check(*, host: str = "github.com") -> DoctorCheck:
    if shutil.which("gh") is None:
        return DoctorCheck(name="gh-auth", status="fail", detail="`gh` is not installed")
    try:
        run_cmd(["gh", "auth", "status", "--hostname", host], check=True)
    except ReviewflowSubprocessError as e:
        msg = e.stderr.strip() or e.stdout.strip() or "not authenticated"
        return DoctorCheck(name="gh-auth", status="fail", detail=msg)
    return DoctorCheck(name="gh-auth", status="ok", detail=f"authenticated for {host}")


def _supports_public_github_fallback(host: str) -> bool:
    return host == "github.com"


def _doctor_public_pr_probe(pr: PullRequestRef) -> tuple[bool, str]:
    if not _supports_public_github_fallback(pr.host):
        return False, f"anonymous public fallback is not supported for {pr.host}"
    path = f"/repos/{pr.owner}/{pr.repo}/pulls/{pr.number}"
    req = urllib.request.Request(
        f"https://api.github.com{path}",
        headers={
            "Accept": "application/vnd.github+json",
            "User-Agent": "cure/0.1.0",
            "X-GitHub-Api-Version": "2022-11-28",
        },
        method="GET",
    )
    try:
        with urllib.request.urlopen(req) as resp:
            body = resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        return False, f"anonymous public PR metadata probe failed ({e.code}): {body.strip() or path}"
    except urllib.error.URLError as e:
        return False, f"anonymous public PR metadata probe failed: {e}"
    try:
        payload = json.loads(body)
    except Exception as e:
        return False, f"anonymous public PR metadata probe returned invalid JSON: {e}"
    if not isinstance(payload, dict):
        return False, "anonymous public PR metadata probe returned an unexpected payload"
    return True, "anonymous public GitHub PR metadata is reachable"


def _resolve_doctor_target_context(pr_url: str | None) -> DoctorTargetContext | None:
    text = str(pr_url or "").strip()
    if not text:
        return None
    pr = parse_pr_url(text)
    public_fallback_supported = _supports_public_github_fallback(pr.host)
    public_reachable = False
    public_detail = f"anonymous public fallback is not supported for {pr.host}"
    if public_fallback_supported:
        public_reachable, public_detail = _doctor_public_pr_probe(pr)
    return DoctorTargetContext(
        pr_url=text,
        pr=pr,
        public_fallback_supported=public_fallback_supported,
        public_pr_metadata_reachable=public_reachable,
        public_pr_metadata_detail=public_detail,
    )


def _doctor_optional_check(*, name: str, detail: str) -> DoctorCheck:
    return DoctorCheck(name=name, status="warn", detail=detail)


def _doctor_repo_local_chunkhound_payload(
    *,
    runtime: ReviewflowRuntime,
    target: DoctorTargetContext | None,
) -> dict[str, Any]:
    from cure_flows import discover_repo_local_chunkhound_config

    resolved_runtime_config: dict[str, Any] | None = None
    if runtime.config_enabled:
        try:
            _, _, resolved_runtime_config = load_chunkhound_runtime_config(
                config_path=runtime.config_path,
                require=True,
            )
        except ReviewflowError:
            resolved_runtime_config = None

    return discover_repo_local_chunkhound_config(
        invocation_cwd=Path.cwd(),
        pr=(target.pr if target is not None else None),
        resolved_runtime_config=resolved_runtime_config,
    )


def _doctor_repo_local_chunkhound_check(discovery: dict[str, Any]) -> DoctorCheck:
    state = str(discovery.get("candidate_state") or "absent").strip() or "absent"
    reason = str(discovery.get("reason") or "").strip() or None
    repo_root = str(discovery.get("repo_root") or "").strip() or "<unknown>"
    config_path = str(discovery.get("config_path") or "").strip() or "<none>"
    db_provider = str(discovery.get("db_provider") or "").strip() or "<unknown>"
    db_path = str(discovery.get("db_path") or "").strip() or "<none>"
    repo_identity = str(discovery.get("repo_identity") or "").strip() or "<unknown>"
    expected_repo_identity = str(discovery.get("expected_repo_identity") or "").strip() or "<not_requested>"
    runtime_match_state = str(discovery.get("runtime_match_state") or "not_requested").strip() or "not_requested"
    target_match_state = str(discovery.get("target_match_state") or "not_requested").strip() or "not_requested"

    if state == "candidate":
        return DoctorCheck(
            name="repo-local-chunkhound",
            status="warn",
            detail=(
                "ask-first repo-local ChunkHound candidate found at "
                f"{config_path} (repo_root={repo_root}; db_provider={db_provider}; "
                f"db_path={db_path}; runtime_match={runtime_match_state}; "
                f"target_match={target_match_state})"
            ),
        )

    if reason == "missing_repo_root_config":
        return DoctorCheck(
            name="repo-local-chunkhound",
            status="ok",
            detail=f"no repo-root chunkhound.json or .chunkhound.json detected under {repo_root}",
        )

    if reason == "cwd_not_git_worktree":
        return DoctorCheck(
            name="repo-local-chunkhound",
            status="warn",
            detail="current working directory is not a git worktree; repo-local ChunkHound hint detection skipped",
        )

    return DoctorCheck(
        name="repo-local-chunkhound",
        status="warn",
        detail=(
            f"repo-local ChunkHound hint not ready to assume "
            f"(state={state}; reason={reason or 'unknown'}; config_path={config_path}; "
            f"repo_root={repo_root}; db_provider={db_provider}; db_path={db_path}; "
            f"runtime_match={runtime_match_state}; target_match={target_match_state}; "
            f"repo_identity={repo_identity}; expected_repo_identity={expected_repo_identity})"
        ),
    )


def _doctor_executor_network_check(agent_runtime: dict[str, Any]) -> DoctorCheck | None:
    if not bool(agent_runtime.get("supported")):
        return None
    provider = str(agent_runtime.get("provider") or "").strip().lower()
    if provider not in {"codex", "claude"}:
        return None
    return DoctorCheck(
        name="executor-network",
        status="warn",
        detail=(
            f"{provider} executor needs internet / network access to obtain code-under-review context; "
            "this advisory does not prove external sandbox access in every environment"
        ),
    )


def _doctor_acknowledged_sources(*, target: DoctorTargetContext | None) -> dict[str, Any]:
    gh = _doctor_executable_check("gh")
    git = _doctor_executable_check("git")
    jira = _doctor_executable_check("jira")
    target_host = (target.pr.host if target is not None else "github.com")
    gh_auth = _doctor_gh_auth_check(host=target_host)
    jira_cfg = _default_jira_config_path()
    payload: dict[str, Any] = {
        "github": {
            "host": target_host,
            "gh_cli": {"status": gh.status, "detail": gh.detail},
            "gh_auth": {"status": gh_auth.status, "detail": gh_auth.detail},
            "git": {"status": git.status, "detail": git.detail},
        },
        "jira": {
            "required_for_pr_reviews": False,
            "config": {
                "status": ("ok" if jira_cfg.is_file() else "warn"),
                "detail": (str(jira_cfg) if jira_cfg.is_file() else f"missing: {jira_cfg}"),
            },
            "cli": {
                "status": ("ok" if jira.status == "ok" else "warn"),
                "detail": jira.detail,
            },
        },
    }
    if target is not None:
        payload["github"]["public_fallback"] = {
            "supported": target.public_fallback_supported,
            "status": ("ok" if target.public_pr_metadata_reachable else "warn"),
            "detail": target.public_pr_metadata_detail,
        }
    return payload


def _doctor_path_payload(*, path: Path, source: str, exists: bool, enabled: bool = True) -> dict[str, Any]:
    payload: dict[str, Any] = {"path": str(path), "source": source, "exists": bool(exists)}
    if not enabled:
        payload["enabled"] = False
    return payload


def _resolved_doctor_agent_runtime(
    runtime: ReviewflowRuntime,
    *,
    cli_profile: str | None = None,
    args: argparse.Namespace | None = None,
) -> dict[str, Any]:
    profile, profile_source, _, _ = resolve_agent_runtime_profile(
        cli_value=cli_profile,
        config_path=runtime.config_path,
        config_enabled=runtime.config_enabled,
    )
    llm_resolved, llm_meta = resolve_llm_config(
        base_codex_config_path=runtime.codex_base_config_path,
        reviewflow_config_path=runtime.config_path,
        cli_preset=getattr(args, "llm_preset", None),
        cli_model=getattr(args, "llm_model", None),
        cli_effort=getattr(args, "llm_effort", None),
        cli_plan_effort=getattr(args, "llm_plan_effort", None),
        cli_verbosity=getattr(args, "llm_verbosity", None),
        cli_max_output_tokens=getattr(args, "llm_max_output_tokens", None),
        cli_request_overrides=parse_llm_request_overrides(getattr(args, "llm_set", [])),
        cli_header_overrides=parse_llm_header_overrides(getattr(args, "llm_header", [])),
        deprecated_codex_model=getattr(args, "codex_model", None),
        deprecated_codex_effort=getattr(args, "codex_effort", None),
        deprecated_codex_plan_effort=getattr(args, "codex_plan_effort", None),
    )
    provider = str(llm_resolved.get("provider") or "").strip().lower()
    transport = str(llm_resolved.get("transport") or "").strip().lower()
    selection = resolve_local_agent_selection(
        base_codex_config_path=runtime.codex_base_config_path,
        reviewflow_config_path=runtime.config_path,
        config_enabled=runtime.config_enabled,
        cli_preset=getattr(args, "llm_preset", None),
        env=os.environ,
    )
    payload: dict[str, Any] = {
        "profile": profile,
        "profile_source": profile_source,
        "preset": llm_resolved.get("preset"),
        "preset_source": llm_meta.get("selected_preset_source"),
        "provider": provider,
        "transport": transport,
        "command": llm_resolved.get("command"),
        "installed_agents": selection.get("installed_agents"),
        "saved_preference": selection.get("saved_preference"),
        "saved_preference_source": selection.get("saved_preference_source"),
        "effective_agent": selection.get("effective_agent"),
        "selection_status": selection.get("status"),
        "selection_detail": selection.get("detail"),
    }
    if transport != "cli" or provider not in CLI_LLM_PROVIDERS:
        payload["supported"] = False
        payload["detail"] = "agent runtime profiles apply only to CLI coding-agent providers"
        return payload

    payload["supported"] = True
    if provider == "codex":
        payload.update(
            {
                "dangerously_bypass_approvals_and_sandbox": True,
                "sandbox_mode": None,
                "approval_policy": None,
            }
        )
    elif provider == "claude":
        payload.update(
            {
                "dangerously_skip_permissions": True,
                "permission_mode": None,
            }
        )
    return payload


def _doctor_runtime_payload(
    runtime: ReviewflowRuntime,
    *,
    cli_profile: str | None = None,
    pr_url: str | None = None,
    args: argparse.Namespace | None = None,
) -> dict[str, Any]:
    target = _resolve_doctor_target_context(pr_url)
    repo_local_chunkhound = _doctor_repo_local_chunkhound_payload(runtime=runtime, target=target)
    agent_selection = resolve_local_agent_selection(
        base_codex_config_path=runtime.codex_base_config_path,
        reviewflow_config_path=runtime.config_path,
        config_enabled=runtime.config_enabled,
        cli_preset=getattr(args, "llm_preset", None),
        env=os.environ,
    )
    config_exists = runtime.config_path.is_file()
    if runtime.config_enabled:
        try:
            review_intelligence_cfg, review_intelligence_meta = load_review_intelligence_config(
                config_path=runtime.config_path,
                require_active_sources=False,
            )
            review_intelligence_payload = attach_review_intelligence_capabilities(
                review_intelligence_meta["review_intelligence"],
                resolve_review_intelligence_capabilities(
                    review_intelligence_cfg,
                    doctor_target=target,
                ),
            )
        except ReviewflowError as e:
            review_intelligence_payload = {
                "config_path": str(runtime.config_path),
                "loaded": False,
                "error": str(e).splitlines()[0],
            }
    else:
        review_intelligence_payload = {
            "config_path": str(runtime.config_path),
            "loaded": False,
            "enabled": False,
            "sources": [],
            "capabilities": {
                "required_sources": [],
                "status_counts": {state: 0 for state in sorted(REVIEW_INTELLIGENCE_CAPABILITY_STATES)},
                "sources": [],
            },
        }
    payload: dict[str, Any] = {
        "cure_config": _doctor_path_payload(
            path=runtime.config_path,
            source=runtime.config_source,
            exists=config_exists,
            enabled=runtime.config_enabled,
        ),
        "sandbox_root": _doctor_path_payload(
            path=runtime.paths.sandbox_root,
            source=runtime.sandbox_root_source,
            exists=runtime.paths.sandbox_root.exists(),
        ),
        "cache_root": _doctor_path_payload(
            path=runtime.paths.cache_root,
            source=runtime.cache_root_source,
            exists=runtime.paths.cache_root.exists(),
        ),
        "codex_base_config": _doctor_path_payload(
            path=runtime.codex_base_config_path,
            source=runtime.codex_base_config_source,
            exists=runtime.codex_base_config_path.is_file(),
        ),
        "agent_runtime": _resolved_doctor_agent_runtime(runtime, cli_profile=cli_profile, args=args),
        "agent_selection": agent_selection,
        "acknowledged_sources": _doctor_acknowledged_sources(target=target),
        "review_intelligence": review_intelligence_payload,
        "repo_local_chunkhound": repo_local_chunkhound,
    }
    if target is not None:
        payload["target"] = {
            "kind": "pull_request",
            "pr_url": target.pr_url,
            "host": target.pr.host,
            "owner": target.pr.owner,
            "repo": target.pr.repo,
            "number": target.pr.number,
            "public_fallback_supported": target.public_fallback_supported,
            "public_pr_metadata_reachable": target.public_pr_metadata_reachable,
            "public_pr_metadata_detail": target.public_pr_metadata_detail,
        }

    if not runtime.config_enabled:
        payload["chunkhound_base_config"] = {
            "path": None,
            "source": "disabled",
            "exists": False,
            "enabled": False,
        }
        return payload

    try:
        chunkhound_cfg, _ = load_reviewflow_chunkhound_config(config_path=runtime.config_path, require=True)
    except ReviewflowError as e:
        payload["chunkhound_base_config"] = {
            "path": None,
            "source": "config",
            "exists": False,
            "error": str(e).splitlines()[0],
        }
        return payload

    assert chunkhound_cfg is not None
    payload["chunkhound_base_config"] = _doctor_path_payload(
        path=chunkhound_cfg.base_config_path,
        source="config",
        exists=chunkhound_cfg.base_config_path.is_file(),
    )
    return payload


def _doctor_runtime_checks(
    runtime: ReviewflowRuntime,
    *,
    cli_profile: str | None = None,
    pr_url: str | None = None,
    args: argparse.Namespace | None = None,
) -> list[DoctorCheck]:
    checks: list[DoctorCheck] = []
    target = _resolve_doctor_target_context(pr_url)
    agent_runtime = _resolved_doctor_agent_runtime(runtime, cli_profile=cli_profile, args=args)
    agent_selection = resolve_local_agent_selection(
        base_codex_config_path=runtime.codex_base_config_path,
        reviewflow_config_path=runtime.config_path,
        config_enabled=runtime.config_enabled,
        cli_preset=getattr(args, "llm_preset", None),
        env=os.environ,
    )
    repo_local_chunkhound = _doctor_repo_local_chunkhound_payload(runtime=runtime, target=target)
    config_path = runtime.config_path
    config_prefix = f"{config_path} (source={runtime.config_source})"
    if not runtime.config_enabled:
        checks.append(DoctorCheck(name="cure-config", status="warn", detail=f"{config_prefix} (disabled by --no-config)"))
    elif config_path.is_file():
        checks.append(DoctorCheck(name="cure-config", status="ok", detail=config_prefix))
    else:
        checks.append(DoctorCheck(name="cure-config", status="fail", detail=f"missing: {config_prefix}"))

    path_defaults, _ = load_reviewflow_paths_defaults(config_path=config_path)
    sandbox_detail = f"{runtime.paths.sandbox_root} (source={runtime.sandbox_root_source})"
    if runtime.sandbox_root_source == "config" and path_defaults.get("sandbox_root") is not None:
        sandbox_detail += " (configured)"
    if runtime.paths.sandbox_root.exists():
        checks.append(DoctorCheck(name="sandbox-root", status="ok", detail=sandbox_detail))
    else:
        checks.append(DoctorCheck(name="sandbox-root", status="warn", detail=f"{sandbox_detail} (will be created on demand)"))

    cache_detail = f"{runtime.paths.cache_root} (source={runtime.cache_root_source})"
    if runtime.cache_root_source == "config" and path_defaults.get("cache_root") is not None:
        cache_detail += " (configured)"
    if runtime.paths.cache_root.exists():
        checks.append(DoctorCheck(name="cache-root", status="ok", detail=cache_detail))
    else:
        checks.append(DoctorCheck(name="cache-root", status="warn", detail=f"{cache_detail} (will be created on demand)"))

    if not runtime.config_enabled:
        checks.append(DoctorCheck(name="chunkhound-config", status="warn", detail="disabled by --no-config"))
    else:
        try:
            chunkhound_cfg, _ = load_reviewflow_chunkhound_config(config_path=config_path, require=True)
        except ReviewflowError as e:
            checks.append(DoctorCheck(name="chunkhound-config", status="fail", detail=str(e).splitlines()[0]))
        else:
            assert chunkhound_cfg is not None
            chunkhound_detail = f"{chunkhound_cfg.base_config_path} (source=config)"
            if chunkhound_cfg.base_config_path.is_file():
                checks.append(DoctorCheck(name="chunkhound-config", status="ok", detail=chunkhound_detail))
            else:
                checks.append(DoctorCheck(name="chunkhound-config", status="fail", detail=f"missing base_config_path: {chunkhound_detail}"))

    if target is not None:
        checks.append(
            DoctorCheck(
                name="review-target",
                status="ok",
                detail=f"{target.pr.owner}/{target.pr.repo}#{target.pr.number} ({target.pr.host})",
            )
        )

    jira_cfg = _default_jira_config_path()
    if jira_cfg.is_file():
        checks.append(DoctorCheck(name="jira-config", status="ok", detail=str(jira_cfg)))
    elif target is not None:
        checks.append(
            _doctor_optional_check(
                name="jira-config",
                detail=f"missing: {jira_cfg} (optional for normal PR review lifecycle flows; only needed for Jira-driven workflows)",
            )
        )
    else:
        checks.append(
            _doctor_optional_check(
                name="jira-config",
                detail=f"missing: {jira_cfg} (target-dependent; not required for all review flows)",
            )
        )

    if runtime.codex_base_config_path.is_file():
        checks.append(DoctorCheck(name="codex-config", status="ok", detail=f"{runtime.codex_base_config_path} (source={runtime.codex_base_config_source})"))
    else:
        checks.append(DoctorCheck(name="codex-config", status="warn", detail=f"missing: {runtime.codex_base_config_path} (source={runtime.codex_base_config_source})"))

    agent_runtime_detail = (
        f"profile={agent_runtime.get('profile')} "
        f"provider={agent_runtime.get('provider')} "
        f"preset={agent_runtime.get('preset')} "
        f"preset_source={agent_runtime.get('preset_source')} "
        f"profile_source={agent_runtime.get('profile_source')}"
    )
    checks.append(
        DoctorCheck(
            name="agent-runtime",
            status=("ok" if bool(agent_runtime.get("supported")) else "warn"),
            detail=agent_runtime_detail if bool(agent_runtime.get("supported")) else f"{agent_runtime_detail} ({agent_runtime.get('detail')})",
        )
    )
    installed_agents = ", ".join(agent_selection.get("installed_agents") or []) or "<none>"
    selection_detail = (
        f"installed=[{installed_agents}] "
        f"saved={agent_selection.get('saved_preference') or '<none>'} "
        f"effective={agent_selection.get('effective_agent') or '<none>'} "
        f"status={agent_selection.get('status')}"
    )
    checks.append(
        DoctorCheck(
            name="agent-selection",
            status=("fail" if bool(agent_selection.get("blocking")) else "ok"),
            detail=f"{selection_detail} ({agent_selection.get('detail')})",
        )
    )

    checks.append(_doctor_executable_check("chunkhound"))
    gh_check = _doctor_executable_check("gh")
    jira_check = _doctor_executable_check("jira")
    codex_check = _doctor_executable_check("codex")
    if target is not None:
        git_check = _doctor_executable_check("git")
        checks.append(git_check)
        public_ok = target.public_fallback_supported and target.public_pr_metadata_reachable
        if gh_check.status == "ok":
            checks.append(gh_check)
        elif public_ok and git_check.status == "ok":
            checks.append(
                DoctorCheck(
                    name="gh",
                    status="ok",
                    detail=f"{gh_check.detail} (not required for public github.com PR lifecycle flows such as `pr` and `zip`; anonymous fallback confirmed)",
                )
            )
        else:
            checks.append(gh_check)

        if jira_check.status == "ok":
            checks.append(jira_check)
        else:
            checks.append(
                _doctor_optional_check(
                    name="jira",
                    detail=f"{jira_check.detail} (optional for normal PR review lifecycle flows; only needed for Jira-driven workflows)",
                )
            )

        gh_auth = _doctor_gh_auth_check(host=target.pr.host)
        if gh_auth.status == "ok":
            checks.append(gh_auth)
        elif public_ok and git_check.status == "ok":
            checks.append(
                DoctorCheck(
                    name="gh-auth",
                    status="ok",
                    detail=f"{gh_auth.detail} (anonymous public github.com fallback confirmed)",
                )
            )
        else:
            checks.append(gh_auth)

        if git_check.status != "ok":
            checks.append(
                DoctorCheck(
                    name="github-pr-access",
                    status="fail",
                    detail="`git` is required for PR clone/checkout.",
                )
            )
        elif gh_auth.status == "ok":
            checks.append(
                DoctorCheck(
                    name="github-pr-access",
                    status="ok",
                    detail=f"authenticated GitHub access is available for {target.pr.host}",
                )
            )
        elif public_ok:
            checks.append(
                DoctorCheck(
                    name="github-pr-access",
                    status="ok",
                    detail=target.public_pr_metadata_detail,
                )
            )
        else:
            checks.append(
                DoctorCheck(
                    name="github-pr-access",
                    status="fail",
                    detail=f"no usable GitHub PR source of truth for {target.pr.owner}/{target.pr.repo}#{target.pr.number}",
                )
            )
    else:
        checks.append(
            gh_check
            if gh_check.status == "ok"
            else _doctor_optional_check(
                name="gh",
                detail=f"{gh_check.detail} (target-dependent; public github.com PR lifecycle flows can use fallback)",
            )
        )
        checks.append(
            jira_check
            if jira_check.status == "ok"
            else _doctor_optional_check(
                name="jira",
                detail=f"{jira_check.detail} (target-dependent; only needed for Jira-driven workflows)",
            )
        )
    checks.append(codex_check)
    provider = str(agent_runtime.get("provider") or "").strip().lower()
    command = str(agent_runtime.get("command") or "").strip()
    if bool(agent_runtime.get("supported")) and provider and command and (provider != "codex"):
        selected = _doctor_executable_check(command)
        checks.append(DoctorCheck(name="agent-runtime-command", status=selected.status, detail=f"{provider}: {selected.detail}"))
    if target is None:
        gh_auth = _doctor_gh_auth_check()
        checks.append(
            gh_auth
            if gh_auth.status == "ok"
            else _doctor_optional_check(
                name="gh-auth",
                detail=f"{gh_auth.detail} (target-dependent; public github.com PR lifecycle flows can use fallback)",
            )
        )
    checks.append(_doctor_repo_local_chunkhound_check(repo_local_chunkhound))
    executor_network = _doctor_executor_network_check(agent_runtime)
    if executor_network is not None:
        checks.append(executor_network)
    return checks


__all__ = [
    "AGENT_RUNTIME_PROFILE_CHOICES",
    "BUILTIN_LLM_PRESET_IDS",
    "CHUNKHOUND_CONFIG_EXAMPLE",
    "CLI_LLM_PROVIDERS",
    "CLI_PROVIDER_SESSION_ENV_PREFIXES",
    "CODEX_REASONING_EFFORT_CHOICES",
    "CURATED_ENV_INHERIT_KEYS",
    "DEFAULT_AGENT_RUNTIME_PROFILE",
    "DEFAULT_LEGACY_CODEX_PRESET",
    "DEFAULT_MULTIPASS_ENABLED",
    "DEFAULT_MULTIPASS_MAX_STEPS",
    "DEFAULT_MULTIPASS_STEP_WORKERS",
    "DEFAULT_REVIEW_INTELLIGENCE_POLICY_MODE",
    "DoctorCheck",
    "HTTP_LLM_PROVIDERS",
    "LLM_RESUME_PROVIDERS",
    "LLM_TRANSPORT_CHOICES",
    "MULTIPASS_MAX_STEPS_HARD_CAP",
    "MULTIPASS_STEP_WORKERS_HARD_CAP",
    "REVIEW_INTELLIGENCE_CONFIG_EXAMPLE",
    "ReviewIntelligenceConfig",
    "ReviewIntelligenceSource",
    "ReviewflowChunkHoundConfig",
    "ReviewflowRuntime",
    "_default_jira_config_path",
    "_dedupe_paths",
    "_doctor_runtime_checks",
    "_doctor_runtime_payload",
    "_plain_dict",
    "_raise_removed_gemini_support",
    "_set_disabled_reviewflow_config_path",
    "_string_dict",
    "_string_list",
    "augment_cli_provider_session_env",
    "apply_llm_env",
    "build_curated_subprocess_env",
    "build_http_response_request",
    "build_llm_meta",
    "build_review_intelligence_guidance",
    "attach_review_intelligence_capabilities",
    "builtin_llm_presets",
    "fingerprint_chunkhound_reviewflow_config",
    "load_chunkhound_runtime_config",
    "load_review_intelligence_config",
    "load_reviewflow_agent_runtime_config",
    "load_reviewflow_chunkhound_config",
    "load_reviewflow_codex_base_config_path",
    "load_reviewflow_codex_defaults",
    "load_reviewflow_llm_config",
    "load_reviewflow_multipass_defaults",
    "load_reviewflow_paths_defaults",
    "load_toml",
    "parse_llm_header_overrides",
    "parse_llm_key_value",
    "parse_llm_request_overrides",
    "require_builtin_review_intelligence",
    "resolve_agent_runtime_profile",
    "resolve_chunkhound_reviewflow_config",
    "resolve_codex_base_config_path",
    "resolve_codex_flags",
    "resolve_llm_config",
    "resolve_llm_config_from_args",
    "resolve_multipass_stage_llm_config",
    "resolve_reviewflow_config_path",
    "resolve_review_intelligence_capabilities",
    "resolve_runtime",
    "resolve_runtime_paths",
    "resolve_ui_enabled",
    "resolve_verbosity",
    "toml_string",
]
