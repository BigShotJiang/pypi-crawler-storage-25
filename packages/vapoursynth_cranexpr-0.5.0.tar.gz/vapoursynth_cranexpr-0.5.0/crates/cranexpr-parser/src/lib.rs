mod errors;
mod sorting_network;

pub use errors::ParseError;

use cranexpr_ast::{BinOp, BoundaryMode, Expr, TernaryOp, UnOp};
use cranexpr_lexer::{TokenKind, tokenize_with_text};

fn add_unary_op(stack: &mut Vec<Expr>, op: UnOp) -> Result<(), ParseError> {
  let x = stack.pop().ok_or(ParseError::StackUnderflow)?;
  stack.push(Expr::Unary(op, Box::new(x)));
  Ok(())
}

fn add_binary_op(stack: &mut Vec<Expr>, op: BinOp) -> Result<(), ParseError> {
  let right = stack.pop().ok_or(ParseError::StackUnderflow)?;
  let left = stack.pop().ok_or(ParseError::StackUnderflow)?;
  stack.push(Expr::Binary(op, Box::new(left), Box::new(right)));
  Ok(())
}

fn add_ternary_op(stack: &mut Vec<Expr>, op: TernaryOp) -> Result<(), ParseError> {
  let c = stack.pop().ok_or(ParseError::StackUnderflow)?;
  let b = stack.pop().ok_or(ParseError::StackUnderflow)?;
  let a = stack.pop().ok_or(ParseError::StackUnderflow)?;
  stack.push(Expr::Ternary(op, Box::new(a), Box::new(b), Box::new(c)));
  Ok(())
}

/// Parses an expression into a sequence of ASTs.
///
/// # Errors
///
/// Returns a [`ParseError`] if the expression is malformed.
pub fn parse_expr(expr: &str) -> Result<Vec<Expr>, ParseError> {
  let mut stack = Vec::new();
  let mut side_effects = Vec::new();

  // We don't filter out whitespace tokens because they're significant when it
  // comes to differentiating between subtraction (`x - y`) and
  // negative literals (`-x`).
  let mut tokens = tokenize_with_text(expr).peekable();

  while let Some((kind, text)) = tokens.next() {
    match kind {
      TokenKind::Whitespace => { /* usually insignificant */ }
      TokenKind::Literal {
        kind: _,
        suffix_start: _,
      } => {
        let value = text
          .parse::<f32>()
          .map_err(|_| ParseError::InvalidLiteral(text.to_string()))?;
        stack.push(Expr::Lit(value));
      }
      TokenKind::Ident => {
        // An identifier followed by an open bracket is relative or absolute pixel access.
        if tokens
          .peek()
          .is_some_and(|(k, _)| *k == TokenKind::OpenBracket)
        {
          tokens.next(); // Consume `[`.

          // Check for empty brackets `[]` which indicates absolute access.
          if tokens
            .peek()
            .is_some_and(|(k, _)| *k == TokenKind::CloseBracket)
          {
            tokens.next(); // Consume `]`.

            // Parse optional boundary mode suffix.
            let boundary_mode = if tokens.peek().is_some_and(|(k, _)| *k == TokenKind::Colon) {
              tokens.next(); // Consume `:`.
              // Skip whitespace.
              while tokens
                .peek()
                .is_some_and(|(k, _)| *k == TokenKind::Whitespace)
              {
                tokens.next();
              }
              let (mode_kind, mode_text) = tokens.next().ok_or(ParseError::StackUnderflow)?;
              if mode_kind != TokenKind::Ident {
                return Err(ParseError::StackUnderflow);
              }
              match mode_text {
                "c" => Some(BoundaryMode::Clamp),
                "m" => Some(BoundaryMode::Mirror),
                _ => return Err(ParseError::StackUnderflow),
              }
            } else {
              Some(BoundaryMode::Clamp) // Default to clamp if no suffix
            };

            let y = stack.pop().ok_or(ParseError::StackUnderflow)?;
            let x = stack.pop().ok_or(ParseError::StackUnderflow)?;

            stack.push(Expr::AbsAccess {
              clip: text.to_string(),
              x: Box::new(x),
              y: Box::new(y),
              boundary_mode,
            });
          } else {
            // Relative access parsing
            // Parse relX (must be an integer literal).
            let (rel_x_kind, rel_x_text) = tokens.next().ok_or(ParseError::StackUnderflow)?;
            let rel_x = match rel_x_kind {
              TokenKind::Literal { .. } => rel_x_text
                .parse::<i32>()
                .map_err(|_| ParseError::StackUnderflow)?,
              TokenKind::Minus => {
                // Negative integer literal.
                let (lit_kind, lit_text) = tokens.next().ok_or(ParseError::StackUnderflow)?;
                if !matches!(lit_kind, TokenKind::Literal { .. }) {
                  return Err(ParseError::StackUnderflow);
                }
                -(lit_text
                  .parse::<i32>()
                  .map_err(|_| ParseError::StackUnderflow)?)
              }
              _ => return Err(ParseError::StackUnderflow),
            };

            // Skip whitespace and optional comma.
            while tokens
              .peek()
              .is_some_and(|(k, _)| matches!(k, TokenKind::Whitespace | TokenKind::Comma))
            {
              tokens.next();
            }

            // Parse relY.
            let (rel_y_kind, rel_y_text) = tokens.next().ok_or(ParseError::StackUnderflow)?;
            let rel_y = match rel_y_kind {
              TokenKind::Literal { .. } => rel_y_text
                .parse::<i32>()
                .map_err(|_| ParseError::StackUnderflow)?,
              TokenKind::Minus => {
                let (lit_kind, lit_text) = tokens.next().ok_or(ParseError::StackUnderflow)?;
                if !matches!(lit_kind, TokenKind::Literal { .. }) {
                  return Err(ParseError::StackUnderflow);
                }
                -(lit_text
                  .parse::<i32>()
                  .map_err(|_| ParseError::StackUnderflow)?)
              }
              _ => return Err(ParseError::StackUnderflow),
            };

            // Expect close bracket, but skip whitespace first.
            while tokens
              .peek()
              .is_some_and(|(k, _)| *k == TokenKind::Whitespace)
            {
              tokens.next();
            }
            let (rbracket_kind, _) = tokens.next().ok_or(ParseError::StackUnderflow)?;
            if rbracket_kind != TokenKind::CloseBracket {
              return Err(ParseError::StackUnderflow);
            }

            // Parse optional boundary mode suffix.
            let boundary_override = if tokens.peek().is_some_and(|(k, _)| *k == TokenKind::Colon) {
              tokens.next(); // Consume `:`.
              // Skip whitespace.
              while tokens
                .peek()
                .is_some_and(|(k, _)| *k == TokenKind::Whitespace)
              {
                tokens.next();
              }
              let (mode_kind, mode_text) = tokens.next().ok_or(ParseError::StackUnderflow)?;
              if mode_kind != TokenKind::Ident {
                return Err(ParseError::StackUnderflow);
              }
              match mode_text {
                "c" => Some(BoundaryMode::Clamp),
                "m" => Some(BoundaryMode::Mirror),
                _ => return Err(ParseError::StackUnderflow),
              }
            } else {
              None
            };

            stack.push(Expr::RelAccess {
              clip: text.to_string(),
              rel_x,
              rel_y,
              boundary_mode: boundary_override,
            });
          }
        }
        // An identifier followed by a dot is the start of frame property access.
        else if tokens.peek().is_some_and(|(k, _)| *k == TokenKind::Dot) {
          tokens.next(); // Consume dot.
          let (prop_kind, prop_text) = tokens.next().ok_or(ParseError::MissingFramePropertyName)?;
          if prop_kind != TokenKind::Ident {
            return Err(ParseError::PropertyNameNotAnIdentifier);
          }
          stack.push(Expr::Prop(text.to_string(), prop_text.to_string()));
        }
        // Drops the top N values from the stack. `drop` is equivalent to
        // `drop1`.
        else if let Some(steps) = text.strip_prefix("drop") {
          let steps = steps.parse::<usize>().unwrap_or(1);
          let new_len = stack
            .len()
            .checked_sub(steps)
            .ok_or(ParseError::DropOutOfBounds)?;
          stack.truncate(new_len);
        }
        // Duplicates the topmost stack value.
        //
        // `dupN` allows a value N steps up in the stack to be
        // duplicated. The top value of the stack has index 0 meaning
        // that `dup` is equivalent to `dup0`.
        else if let Some(steps) = text.strip_prefix("dup") {
          let steps = steps.parse::<usize>().unwrap_or(0);
          let idx = stack
            .len()
            .checked_sub(steps + 1)
            .ok_or(ParseError::DupOutOfBounds)?;
          let to_dupe = stack.get(idx).ok_or(ParseError::DupOutOfBounds)?;
          stack.push(to_dupe.clone());
        }
        // `swapN` allows a value N steps up in the stack to be swapped.
        // The top value of the stack has index 0 meaning that `swap` is
        // equivalent to `swap1`. This is because `swapN` always swaps
        // with the topmost value at index 0.
        else if let Some(steps) = text.strip_prefix("swap") {
          let steps = steps.parse::<usize>().unwrap_or(1);
          let idx = stack
            .len()
            .checked_sub(steps + 1)
            .ok_or(ParseError::SwapOutOfBounds)?;
          let len = stack.len();
          stack.swap(idx, len - 1);
        }
        // `sortN` pops N values from the stack, sorts them, and pushes them
        // back in descending order (smallest on top).
        else if let Some(count) = text.strip_prefix("sort") {
          let count = count
            .parse::<usize>()
            .map_err(|_| ParseError::InvalidSortSize(text.to_string()))?;
          let pairs = sorting_network::sorting_network(count)
            .ok_or_else(|| ParseError::InvalidSortSize(text.to_string()))?;
          if stack.len() < count {
            return Err(ParseError::SortOutOfBounds);
          }
          let start = stack.len() - count;
          // Apply each comparator pair as a min/max swap on the Expr stack.
          // Each (i, j) becomes: vals[i] = min(vals[i], vals[j]),
          //                      vals[j] = max(vals[i], vals[j]).
          for &(i, j) in &pairs {
            let si = start + i;
            let sj = start + j;
            let a = stack[si].clone();
            let b = stack[sj].clone();
            stack[si] = Expr::Binary(BinOp::Max, Box::new(a.clone()), Box::new(b.clone()));
            stack[sj] = Expr::Binary(BinOp::Min, Box::new(a), Box::new(b));
          }
        }
        // `var!`: Pops the top value from the stack and stores it in a variable
        // named `var`.
        else if tokens.peek().is_some_and(|(k, _)| *k == TokenKind::Bang) {
          tokens.next(); // Consume `!`.
          let value = stack.pop().ok_or(ParseError::StackUnderflow)?;
          side_effects.push(Expr::Store(text.to_string(), Box::new(value)));
        }
        // `var@`: Pushes the value of the variable `var` onto the stack.
        else if tokens.peek().is_some_and(|(k, _)| *k == TokenKind::At) {
          tokens.next(); // Consume `@`.

          // Assert that the variable has been previously initialized by a
          // `var!` expression.
          if !side_effects
            .iter()
            .any(|e| matches!(e, Expr::Store(name, _) if name == text))
          {
            return Err(ParseError::UninitializedVariable(text.to_string()));
          }
          stack.push(Expr::Load(text.to_string()));
        } else {
          match text {
            "abs" => add_unary_op(&mut stack, UnOp::Abs),
            "pow" => add_binary_op(&mut stack, BinOp::Pow),
            "exp" => add_unary_op(&mut stack, UnOp::Exp),
            "floor" => add_unary_op(&mut stack, UnOp::Floor),
            "round" => add_unary_op(&mut stack, UnOp::Round),
            "log" => add_unary_op(&mut stack, UnOp::Log),
            "max" => add_binary_op(&mut stack, BinOp::Max),
            "min" => add_binary_op(&mut stack, BinOp::Min),
            "not" => add_unary_op(&mut stack, UnOp::Not),
            "sgn" => add_unary_op(&mut stack, UnOp::Sign),
            "sqrt" => add_unary_op(&mut stack, UnOp::Sqrt),
            "sin" => add_unary_op(&mut stack, UnOp::Sine),
            "tan" => add_unary_op(&mut stack, UnOp::Tangent),
            "trunc" => add_unary_op(&mut stack, UnOp::Trunc),
            "cos" => add_unary_op(&mut stack, UnOp::Cosine),
            "clip" | "clamp" => add_ternary_op(&mut stack, TernaryOp::Clip),
            "atan2" => add_binary_op(&mut stack, BinOp::Atan2),
            "bitand" => add_binary_op(&mut stack, BinOp::BitAnd),
            "bitor" => add_binary_op(&mut stack, BinOp::BitOr),
            "bitxor" => add_binary_op(&mut stack, BinOp::BitXor),
            "bitnot" => add_unary_op(&mut stack, UnOp::BitNot),
            "and" => add_binary_op(&mut stack, BinOp::And),
            "or" => add_binary_op(&mut stack, BinOp::Or),
            "xor" => add_binary_op(&mut stack, BinOp::Xor),
            _ => {
              stack.push(Expr::Ident(text.to_string()));
              Ok(())
            }
          }?;
        }
      }
      TokenKind::Plus => add_binary_op(&mut stack, BinOp::Add)?,
      TokenKind::Minus => {
        // First check if the next token is a literal.
        if tokens
          .peek()
          .is_some_and(|(token_kind, _)| matches!(token_kind, TokenKind::Literal { .. }))
        {
          let (_, text) = tokens.next().ok_or(ParseError::StackUnderflow)?;
          let value = text
            .parse::<f32>()
            .map_err(|_| ParseError::InvalidLiteral(text.to_string()))?;
          stack.push(Expr::Lit(0.0 - value));
        } else {
          add_binary_op(&mut stack, BinOp::Sub)?;
        }
      }
      TokenKind::Star => add_binary_op(&mut stack, BinOp::Mul)?,
      TokenKind::Slash => add_binary_op(&mut stack, BinOp::Div)?,
      TokenKind::Gt => add_binary_op(&mut stack, BinOp::Gt)?,
      TokenKind::Gte => add_binary_op(&mut stack, BinOp::Gte)?,
      TokenKind::Lt => add_binary_op(&mut stack, BinOp::Lt)?,
      TokenKind::Lte => add_binary_op(&mut stack, BinOp::Lte)?,
      TokenKind::Eq => add_binary_op(&mut stack, BinOp::Eq)?,
      TokenKind::Percent => add_binary_op(&mut stack, BinOp::Rem)?,
      TokenKind::Question => {
        // Ternary follows the pattern `A B C ?`, which evaluates to `B` if
        // `A > 0`, and `C` otherwise.
        let no = stack.pop().ok_or(ParseError::StackUnderflow)?;
        let yes = stack.pop().ok_or(ParseError::StackUnderflow)?;
        let cond = stack.pop().ok_or(ParseError::StackUnderflow)?;

        stack.push(Expr::IfElse(Box::new(cond), Box::new(yes), Box::new(no)));
      }
      _ => return Err(ParseError::UnrecognizedToken(text.to_string())),
    }
  }

  if stack.len() != 1 {
    if stack.is_empty() {
      return Err(ParseError::ExpressionEvaluatesToNothing);
    }
    return Err(ParseError::ExpressionDoesNotEvaluateToSingleValue);
  }

  side_effects.extend(stack);
  Ok(side_effects)
}

#[cfg(test)]
mod tests {
  use insta::assert_yaml_snapshot;
  use rstest::rstest;

  use super::*;

  #[rstest]
  fn test_literals() {
    assert_yaml_snapshot!(parse_expr("1234").unwrap());
  }

  #[rstest]
  fn test_example() {
    assert_yaml_snapshot!(parse_expr("x y 64 * + z 256 * + 3 /").unwrap());
  }

  #[rstest]
  fn test_dup() {
    assert_yaml_snapshot!(parse_expr("x dup *").unwrap());
    assert_yaml_snapshot!(parse_expr("x x y - dup 1.0 * dup1 0.0 * ? -").unwrap());
  }

  #[rstest]
  fn test_swap() {
    assert_yaml_snapshot!(parse_expr("3.14 dup 0 > swap 0 < -").unwrap());
  }

  #[rstest]
  fn test_prop() {
    assert_yaml_snapshot!(parse_expr("x.PlaneStatsAverage").unwrap());
  }

  #[rstest]
  fn test_exponent() {
    assert_yaml_snapshot!(parse_expr("x 1e-06 + y.PlaneStatsAverage *").unwrap());
  }

  #[rstest]
  fn test_negative_literal() {
    assert_yaml_snapshot!(parse_expr("-4 -5 - 6 -").unwrap());
  }

  #[rstest]
  fn test_clip() {
    assert_yaml_snapshot!(parse_expr("x 16 235 clip").unwrap());
  }

  #[rstest]
  fn test_atan2() {
    assert_yaml_snapshot!(parse_expr("y x atan2").unwrap());
  }

  #[rstest]
  fn test_eq_op() {
    assert_yaml_snapshot!(parse_expr("x y =").unwrap());
  }

  #[rstest]
  fn test_gte_op() {
    assert_yaml_snapshot!(parse_expr("x y >=").unwrap());
  }

  #[rstest]
  fn test_lte_op() {
    assert_yaml_snapshot!(parse_expr("x y <=").unwrap());
  }

  #[rstest]
  fn test_and_or() {
    assert_yaml_snapshot!(parse_expr("x 0 > y 0 > and").unwrap());
    assert_yaml_snapshot!(parse_expr("x 0 > y 0 > or").unwrap());
  }

  #[rstest]
  fn test_xor() {
    assert_yaml_snapshot!(parse_expr("x 0 > y 0 > xor").unwrap());
  }

  #[rstest]
  fn test_variables() {
    assert_yaml_snapshot!(parse_expr("x 2 / my_var! my_var@ my_var@ *").unwrap());
  }

  #[rstest]
  fn test_store_does_not_affect_stack() {
    assert_yaml_snapshot!(
      parse_expr("7 6 5 4 3 2 1 0 dup4 max_val! dup3 min_val! drop8 x min_val@ max_val@ clamp")
        .unwrap()
    );
  }

  #[rstest]
  fn test_load_before_store_is_error() {
    let err = parse_expr("foo@ x 2 * foo!").unwrap_err();
    assert_eq!(err.to_string(), "Reference to uninitialized variable: foo@");
  }
}
