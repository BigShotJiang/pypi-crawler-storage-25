use const_str::cstr;
use cranexpr_ast::BoundaryMode;
use num_traits::FromPrimitive;
use std::{
  ffi::{CStr, c_void},
  ptr,
};
use vapours::{frame::VapoursVideoFrame, generic::HoldsVideoFormat};
use vapoursynth4_rs::{
  ColorFamily, SampleType, VideoInfo,
  core::CoreRef,
  frame::{Frame, FrameContext, VideoFrame},
  key,
  map::{Key, MapRef},
  node::{
    ActivationReason, Dependencies, Filter, FilterDependency, Node, RequestPattern, VideoNode,
  },
  utils::is_constant_video_format,
};

use cranexpr_codegen::{MainFunction, compile_jit};

use crate::{
  component_type::{ComponentType, FromVideoFormat},
  errors::CranexprError,
};
use cranexpr_transforms::{PropVisitor, Visitor};

#[derive(Clone, Copy, Debug, PartialEq)]
enum PlaneOp {
  Process,
  Copy,
  Undefined,
}

pub(crate) struct CranexprFilter {
  nodes: Vec<VideoNode>,
  vi: VideoInfo,
  planes: [PlaneOp; 3],
  bytecode: [Option<MainFunction>; 3],
  required_frame_props: [Vec<(usize, String)>; 3],
  frame_prop_keys: [Vec<Key>; 3],
}

impl Filter for CranexprFilter {
  type Error = CranexprError;
  type FrameType = VideoFrame;
  type FilterData = ();

  #[inline]
  fn create(
    input: MapRef<'_>,
    output: MapRef<'_>,
    _data: Option<Box<Self::FilterData>>,
    mut core: CoreRef<'_>,
  ) -> Result<(), Self::Error> {
    let Some(num_inputs) = input.num_elements(key!(c"clips")) else {
      return Err(CranexprError::NumberOfClips);
    };

    let nodes = (0..num_inputs)
      .map(|i| input.get_video_node(key!(c"clips"), i).unwrap())
      .collect::<Vec<_>>();
    let video_infos = nodes
      .iter()
      .map(|node| node.info().clone())
      .collect::<Vec<_>>();
    for vi in &video_infos {
      if !is_constant_video_format(vi) {
        return Err(CranexprError::VariableFormat);
      }
    }

    let mut vi = video_infos[0].clone();
    if let Ok(format) = input.get_int_saturated(key!(c"format"), 0) {
      let f = core.get_video_format_by_id(format as u32);
      if f.color_family != ColorFamily::Undefined {
        if vi.format.num_planes != f.num_planes {
          return Err(CranexprError::PlanesMismatch);
        }
        vi.format = core.query_video_format(
          f.color_family,
          f.sample_type,
          f.bits_per_sample,
          f.sub_sampling_w,
          f.sub_sampling_h,
        );
      }
    }

    let num_exprs = input.num_elements(key!(c"expr")).unwrap();
    if num_exprs > vi.format.num_planes {
      return Err(CranexprError::MoreExpressionsThanPlanes);
    }

    let mut expr = [""; 3];
    for i in 0..num_exprs {
      expr[i as usize] = input.get_utf8(key!(c"expr"), i).unwrap();
    }

    // Fill the rest of the exprs with the last specified one.
    for i in num_exprs..3 {
      expr[i as usize] = expr[num_exprs as usize - 1];
    }

    let Some(boundary_mode) =
      BoundaryMode::from_i64(input.get_int(key!(c"boundary"), 0).unwrap_or(0))
    else {
      return Err(CranexprError::UnrecognizedBoundaryMode);
    };

    let mut planes = [PlaneOp::Undefined; 3];
    let mut bytecode: [Option<MainFunction>; 3] = [None, None, None];
    let mut required_frame_props: [Vec<(usize, String)>; 3] = [Vec::new(), Vec::new(), Vec::new()];
    let mut frame_prop_keys: [Vec<Key>; 3] = [Vec::new(), Vec::new(), Vec::new()];

    for i in 0..vi.format.num_planes as usize {
      planes[i] = if expr[i].is_empty() {
        if vi.depth() == video_infos[0].depth() && vi.sample_type() == video_infos[0].sample_type()
        {
          PlaneOp::Copy
        } else {
          PlaneOp::Undefined
        }
      } else {
        PlaneOp::Process
      };

      if planes[i] != PlaneOp::Process {
        continue;
      }

      let ast = cranexpr_parser::parse_expr(expr[i])?;
      let mut visitor = PropVisitor::new(num_inputs as usize);

      for node in &ast {
        visitor.visit_expr(node);
      }

      if let Some(err) = visitor.error {
        return Err(err.into());
      }

      let required_props: Vec<(usize, String)> = visitor.props.into_iter().collect();
      let mut prop_keys = Vec::with_capacity(required_props.len());
      for (_, prop_name) in &required_props {
        prop_keys.push(
          Key::new(prop_name.as_str())
            .map_err(|_| CranexprError::InvalidFramePropertyName(prop_name.clone()))?,
        );
      }

      let dst_type = ComponentType::from_video_format(&vi);
      let src_types = video_infos
        .iter()
        .map(ComponentType::from_video_format)
        .collect::<Vec<_>>();

      bytecode[i] = Some(compile_jit(
        &ast,
        dst_type,
        &src_types,
        Some(boundary_mode),
        &required_props,
      )?);

      required_frame_props[i] = required_props;
      frame_prop_keys[i] = prop_keys;
    }

    let filter = Self {
      nodes: nodes.clone(),
      vi: vi.clone(),
      planes,
      bytecode,
      required_frame_props,
      frame_prop_keys,
    };

    let deps = nodes
      .iter()
      .map(|node| FilterDependency {
        source: node.as_ptr(),
        request_pattern: if filter.vi.num_frames <= node.info().num_frames {
          RequestPattern::StrictSpatial
        } else {
          RequestPattern::NoFrameReuse
        },
      })
      .collect::<Vec<FilterDependency>>();

    core.create_video_filter(
      output,
      cstr!("Expr"),
      &vi,
      Box::new(filter),
      Dependencies::new(&deps).unwrap(),
    );

    Ok(())
  }

  #[inline]
  fn get_frame(
    &self,
    n: i32,
    activation_reason: ActivationReason,
    _frame_data: *mut *mut c_void,
    mut ctx: FrameContext,
    core: CoreRef<'_>,
  ) -> Result<Option<VideoFrame>, Self::Error> {
    match activation_reason {
      ActivationReason::Initial => {
        for node in &self.nodes {
          ctx.request_frame_filter(n, node);
        }
      }
      ActivationReason::AllFramesReady => {
        let src = self
          .nodes
          .iter()
          .map(|node| node.get_frame_filter(n, &mut ctx))
          .collect::<Vec<_>>();

        let height = src[0].frame_height(0);
        let width = src[0].frame_width(0);
        let mut dst = core.new_video_frame2(
          &self.vi.format,
          width,
          height,
          &[
            if self.planes[0] == PlaneOp::Copy {
              src[0].as_ptr()
            } else {
              ptr::null()
            },
            if self.planes[1] == PlaneOp::Copy {
              src[0].as_ptr()
            } else {
              ptr::null()
            },
            if self.planes[2] == PlaneOp::Copy {
              src[0].as_ptr()
            } else {
              ptr::null()
            },
          ],
          &[0, 1, 2],
          Some(&src[0]),
        );

        for (plane_idx, (_plane_op, expr)) in self
          .planes
          .iter()
          .zip(self.bytecode.iter())
          .enumerate()
          .filter(|(_i, (plane_op, _expr))| **plane_op == PlaneOp::Process)
        {
          let width = dst.frame_width(plane_idx as i32);
          let height = dst.frame_height(plane_idx as i32);

          let expr = unsafe { expr.as_ref().unwrap_unchecked() };

          let src_ptrs: Vec<*const u8> = src.iter().map(|f| f.plane(plane_idx as i32)).collect();
          let src_strides: Vec<i64> = src
            .iter()
            .map(|f| f.stride(plane_idx as i32) as i64)
            .collect();

          let mut frame_props = Vec::with_capacity(self.required_frame_props[plane_idx].len());
          for (i, (clip_idx, _)) in self.required_frame_props[plane_idx].iter().enumerate() {
            let key = &self.frame_prop_keys[plane_idx][i];
            let mut val = f32::NAN;
            if let Some(props) = src[*clip_idx].properties() {
              if let Ok(float_val) = props.get_float(key, 0) {
                val = float_val as f32;
              } else if let Ok(int_val) = props.get_int(key, 0) {
                #[allow(clippy::cast_precision_loss)]
                {
                  val = int_val as f32;
                }
              } else if let Ok(bin_val) = props.get_binary(key, 0)
                && !bin_val.is_empty()
              {
                val = f32::from(bin_val[0]);
              }
            }
            frame_props.push(val);
          }

          let dst_stride = dst.stride(plane_idx as i32) as i64;

          match self.vi.sample_type() {
            SampleType::Integer => match self.vi.format.bytes_per_sample {
              1 => unsafe {
                expr.invoke(
                  dst.as_mut_slice::<u8>(plane_idx as i32),
                  dst_stride,
                  &src_ptrs,
                  &src_strides,
                  width,
                  height,
                  n,
                  &frame_props,
                );
              },
              2 => unsafe {
                expr.invoke(
                  dst.as_mut_slice::<u16>(plane_idx as i32),
                  dst_stride,
                  &src_ptrs,
                  &src_strides,
                  width,
                  height,
                  n,
                  &frame_props,
                );
              },
              _ => unreachable!(),
            },
            SampleType::Float => unsafe {
              expr.invoke(
                dst.as_mut_slice::<f32>(plane_idx as i32),
                dst_stride,
                &src_ptrs,
                &src_strides,
                width,
                height,
                n,
                &frame_props,
              );
            },
          }
        }

        return Ok(Some(dst));
      }
      ActivationReason::Error => {}
    }

    Ok(None)
  }

  const NAME: &'static CStr = cstr!("Expr");
  const ARGS: &'static CStr = cstr!("clips:vnode[];expr:data[];format:int:opt;boundary:int:opt;");
  const RETURN_TYPE: &'static CStr = cstr!("clip:vnode;");
}
