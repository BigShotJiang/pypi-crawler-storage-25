"""Curated event vocabulary for Evidentia structured logs (v0.7.0).

Rather than letting every caller invent its own ``event.action`` string,
we enumerate the full set here. Operators building SIEM alerts, FedRAMP
3PAOs running audit queries, and Big-4 reviewers correlating evidence
all need a stable vocabulary they can pin to. Ad-hoc action names break
audit-trail continuity across releases; a registry fixes the vocabulary
so a query like ``event.action:evidentia.collect.finding_retrieved`` is
meaningful at v0.6.0, v0.7.0, and v0.8.0 alike.

Adding a new event:
    1. Append to :class:`EventAction`.
    2. Document in ``docs/log-schema.md``.
    3. Add a test in ``tests/unit/test_audit/test_events.py`` asserting the
       name matches the ``evidentia.<namespace>.<verb>`` convention.

ECS categorization primers (see https://www.elastic.co/guide/en/ecs/):

- ``event.category`` = coarse bucket (``configuration``, ``iam``, ``process``)
- ``event.type`` = action-specific sub-type (``info``, ``change``, ``error``)
- ``event.outcome`` = outcome (``success``, ``failure``, ``unknown``)

NIST SP 800-53 Rev 5 AU-3 (Content of Audit Records) requires each
audit record to capture: what happened, when, where, source, outcome,
and identity. The structured logger populates all six from the fields
documented below plus the :class:`EventAction` vocabulary.
"""

from __future__ import annotations

from enum import Enum


class EventAction(str, Enum):
    """Authoritative list of ``event.action`` values emitted by Evidentia.

    Names follow the ``evidentia.<namespace>.<verb>`` convention so SIEM
    operators can filter by prefix (e.g., ``event.action:evidentia.collect.*``).
    Unknown actions are accepted by the logger but tagged with a warning
    so audit-reviewers see the full picture while we learn what emitters
    are missing from this registry.
    """

    # Collection lifecycle ─ the verbs that move a collector from "starting"
    # to "completed". A run begins with COLLECT_STARTED, ends with either
    # COLLECT_COMPLETED (clean) or COLLECT_FAILED / COLLECT_ABORTED.
    COLLECT_STARTED = "evidentia.collect.started"
    COLLECT_FINDING_RETRIEVED = "evidentia.collect.finding_retrieved"
    COLLECT_FINDING_SKIPPED = "evidentia.collect.finding_skipped"
    COLLECT_PAGE_FETCHED = "evidentia.collect.page_fetched"
    COLLECT_RETRY = "evidentia.collect.retry"
    COLLECT_COMPLETED = "evidentia.collect.completed"
    COLLECT_FAILED = "evidentia.collect.failed"
    COLLECT_ABORTED = "evidentia.collect.aborted"
    # v0.10.1 — emitted after `evidentia collect convert --format ocsf`
    # successfully writes an OCSF Compliance Finding bundle, so an
    # auditor can replay the source-to-OCSF conversion from the audit
    # trail (input path, output path, finding count).
    COLLECT_OCSF_EMITTED = "evidentia.collect.ocsf_emitted"

    # Authentication events ─ tracks credential resolution at collection time.
    # Required by NIST SP 800-53 AU-2 (Event Logging) to identify the
    # authenticating principal on every evidence record.
    AUTH_CREDENTIAL_RESOLVED = "evidentia.auth.credential_resolved"
    AUTH_CREDENTIAL_REFRESH = "evidentia.auth.credential_refresh"
    AUTH_CREDENTIAL_FAILED = "evidentia.auth.credential_failed"

    # Configuration events ─ config loaded, overridden, or rejected.
    # Required for H12 (config audit trail) of the enterprise checklist.
    CONFIG_LOADED = "evidentia.config.loaded"
    CONFIG_RESOLVED = "evidentia.config.resolved"
    CONFIG_OVERRIDE_APPLIED = "evidentia.config.override_applied"
    CONFIG_INVALID = "evidentia.config.invalid"

    # Signing events ─ GPG and Sigstore cover distinct signing paths.
    # SIGSTORE_SKIPPED_AIRGAP emitted when Sigstore is requested but
    # air-gap mode forbids the Fulcio/Rekor network calls.
    SIGN_GPG_SIGNED = "evidentia.sign.gpg_signed"
    SIGN_SIGSTORE_SIGNED = "evidentia.sign.sigstore_signed"
    SIGN_SIGSTORE_SKIPPED_AIRGAP = "evidentia.sign.sigstore_skipped_airgap"
    SIGN_FAILED = "evidentia.sign.signing_failed"

    # Verification events ─ mirror SIGN_* for the verify path. Digest and
    # signature outcomes are emitted separately so auditors can filter on
    # either dimension.
    VERIFY_STARTED = "evidentia.verify.started"
    VERIFY_DIGEST_PASSED = "evidentia.verify.digest_passed"
    VERIFY_DIGEST_FAILED = "evidentia.verify.digest_failed"
    VERIFY_SIGNATURE_PASSED = "evidentia.verify.signature_passed"
    VERIFY_SIGNATURE_FAILED = "evidentia.verify.signature_failed"
    VERIFY_COMPLETED = "evidentia.verify.completed"

    # Manifest events ─ completeness attestation B5 emits these. Empty-set
    # attestation is a first-class event so "no findings" is distinguishable
    # from "collection failed" in the audit log.
    MANIFEST_GENERATED = "evidentia.manifest.generated"
    MANIFEST_EMPTY_SET_ATTESTED = "evidentia.manifest.empty_set_attested"
    MANIFEST_INCOMPLETE = "evidentia.manifest.incomplete"

    # AI generation events (v0.7.1) ─ emitted by evidentia-ai's risk-statement
    # and plain-English-explanation generators. Distinct namespace from
    # collect.* because these outputs are generated by an LLM rather than
    # collected from a source system; an auditor querying for "what produced
    # this artifact" needs to distinguish the two paths.
    #
    # Per-call events fire once per gap/control. The matching ``*_BATCH_COMPLETED``
    # event fires once at end-of-batch with succeeded/total counts, so SIEM
    # operators can distinguish "100 risks generated across 100 batches" from
    # "100 risks generated in 1 batch" without double-counting per-call events.
    AI_RISK_GENERATED = "evidentia.ai.risk_generated"
    AI_RISK_FAILED = "evidentia.ai.risk_failed"
    AI_RISK_RETRY = "evidentia.ai.risk_retry"
    AI_RISK_BATCH_COMPLETED = "evidentia.ai.risk_batch_completed"
    AI_EXPLAIN_GENERATED = "evidentia.ai.explain_generated"
    AI_EXPLAIN_FAILED = "evidentia.ai.explain_failed"
    AI_EXPLAIN_RETRY = "evidentia.ai.explain_retry"
    AI_EXPLAIN_CACHE_HIT = "evidentia.ai.explain_cache_hit"
    AI_EXPLAIN_BATCH_COMPLETED = "evidentia.ai.explain_batch_completed"

    # v0.8.0 P0.1: AI determinism + faithfulness evaluation harness
    # (DFAH per arXiv 2601.15322). Each ``evidentia eval`` invocation
    # emits a STARTED + COMPLETED pair, plus one
    # DETERMINISM_VIOLATION / FAITHFULNESS_VIOLATION event per
    # failed sample so an auditor can reconstruct exactly which
    # sample(s) triggered a CI gate failure.
    AI_EVAL_STARTED = "evidentia.ai.eval_started"
    AI_EVAL_DETERMINISM_VIOLATION = "evidentia.ai.eval_determinism_violation"
    AI_EVAL_FAITHFULNESS_VIOLATION = "evidentia.ai.eval_faithfulness_violation"
    AI_EVAL_COMPLETED = "evidentia.ai.eval_completed"
    # v0.8.2 P3.2: first-class Sigstore signing for `evidentia eval`
    # output. Fired once per eval invocation that opts in to --sign;
    # the bundle path lands in evidentia.bundle_path so an auditor
    # can correlate the EvalResult JSON with its Sigstore proof.
    AI_EVAL_OUTPUT_SIGNED = "evidentia.ai.eval_output_signed"
    # v0.8.3 P1.2: faithfulness-check completion. Fired per-prompt
    # when the harness ran the faithfulness check (DFAHarness.run
    # with check_faithfulness=True). Distinct from the per-claim
    # AI_EVAL_FAITHFULNESS_VIOLATION events — _CHECKED is the
    # "we ran the check" record; _VIOLATION fires only on actual
    # below-threshold per-claim failures. Pairs with the v0.8.1
    # AI_RISK_TRACE_EMITTED event in the audit-stream for the
    # full DFAH narrative.
    AI_EVAL_FAITHFULNESS_CHECKED = "evidentia.ai.eval_faithfulness_checked"

    # v0.8.0 P0.2: Policy Reasoning Trace emit (arXiv 2509.23291).
    # Fired once per RiskStatement (or future trace-bearing
    # artifact) when the operator opts in to ``--emit-trace``.
    # Lets auditors reconstruct exactly which artifacts carry a
    # trace and which do not, plus the trace's overall_confidence
    # for fast filtering of low-confidence outputs.
    AI_RISK_TRACE_EMITTED = "evidentia.ai.risk_trace_emitted"

    # v0.8.6 P1: MCP per-tool authorization audit trail. Fired by
    # ``evidentia_mcp.scope.enforce_cimd_scope`` once per tool call
    # routed through the CIMD-enforcement gate. AUTHORIZED + DENIED
    # are mutually exclusive per call; both carry the calling
    # client_id + the requested tool_name + the registered scope
    # allowlist so an auditor can reconstruct the gate's decision
    # without re-running the request. Pairs with the v0.8.5-shipped
    # ``CIMDDocument.has_scope`` predicate. When the MCP server is
    # built without a CIMDRegistry attached (the v0.8.5 default), the
    # gate passes all calls through and these events do NOT fire —
    # absence of the events is itself an audit signal that the
    # operator did not opt into per-tool gating.
    AI_MCP_TOOL_AUTHORIZED = "evidentia.mcp.tool_authorized"
    AI_MCP_TOOL_DENIED = "evidentia.mcp.tool_denied"

    # v0.9.0 P1: POA&M (Plan-of-Action-and-Milestones) lifecycle events.
    # Emitted by the POA&M store + CLI/REST/OSCAL surfaces (P2) on every
    # state transition that an auditor would expect to see in the audit
    # trail. The vocabulary matches the FedRAMP POA&M Template Completion
    # Guide v3.0 + NIST SP 800-53A Rev 5 Appendix F lifecycle states.
    #
    # Event field shape (in addition to the canonical run_id +
    # timestamp + outcome fields):
    #   - poam_id: ControlGap.id of the POA&M item being acted on
    #   - control_id: framework + control_id pair for cross-reference
    #   - milestone_id: present on _MILESTONE_REACHED only; identifies
    #     the specific Milestone whose state changed
    #   - prior_state / new_state: present on _UPDATED + _CLOSED +
    #     _VERIFIED; captures the transition for audit-trail diffing
    POAM_CREATED = "evidentia.poam.created"
    """Fired when a POA&M item lands in the store for the first time
    (typically via ``evidentia poam create --from-gap-report <path>``
    in v0.9.0 P2). Captures the operator + the source gap report +
    the auto-generated milestone schedule (if any)."""

    POAM_UPDATED = "evidentia.poam.updated"
    """Fired on every persisted edit to a POA&M item that ISN'T a
    state-transition (description fixes, evidence_ref updates, tag
    additions). State transitions emit the more specific verbs
    below (_MILESTONE_REACHED, _OVERDUE, _CLOSED, _VERIFIED)."""

    POAM_MILESTONE_REACHED = "evidentia.poam.milestone_reached"
    """Fired when a single milestone's status transitions to
    COMPLETED. Distinct from POAM_CLOSED (the whole POA&M closing)
    because a multi-milestone POA&M can have several milestones
    completed before the overall POA&M is verified and closed.
    Carries the milestone_id + prior_state + new_state."""

    POAM_OVERDUE = "evidentia.poam.overdue"
    """Fired by the cycle-calendar query path (v0.9.0 P3 CONMON
    integration) OR by an explicit operator-set transition to the
    OVERDUE state. The derived-overdue case (target_date < today
    + status in {PLANNED, IN_PROGRESS}) emits this event WITHOUT
    persisting the OVERDUE state — it's a query-time attention
    signal. The operator-set case persists status=OVERDUE and
    emits this event from save_poam."""

    POAM_CLOSED = "evidentia.poam.closed"
    """Fired when the LAST open milestone on a POA&M item transitions
    to COMPLETED, or when the operator explicitly marks the POA&M
    as fully remediated via ``ControlGap.status = REMEDIATED``.
    Pairs with POAM_VERIFIED to bracket the auditor sign-off cycle."""

    POAM_VERIFIED = "evidentia.poam.verified"
    """Fired when an auditor (or the operator on the auditor's
    behalf, with appropriate provenance) confirms a closed POA&M.
    Terminal — no further events fire on the same POA&M unless a
    NEW gap is filed referencing it."""

    # v0.9.0 P3: CONMON (Continuous Monitoring) cycle-calendar events.
    # Emitted by the CONMON CLI query path when an operator
    # (REST surface deferred to v0.9.1 if walk-through identifies
    # operator demand; v0.9.0 ships CLI only per §31.1)
    # query identifies a due or overdue cycle. The cadence library
    # (evidentia_core.conmon.calendar) is pure-function; audit
    # emit happens at the query layer, not in the library, so a
    # given cycle can be "due" multiple times in a row without
    # multiplying audit records — operators only emit when they
    # actively query the calendar.
    #
    # Event field shape (in addition to canonical run_id + timestamp
    # + outcome):
    #   - cadence_slug: ConmonCadence.slug identifying the cycle
    #   - framework: ConmonCadence.framework
    #   - activity: ConmonCadence.activity
    #   - last_completed: ISO-8601 date string of the anchor
    #   - next_due: ISO-8601 date string of the computed next-due
    #   - days_until_due (optional): negative for overdue
    CONMON_CYCLE_DUE = "evidentia.conmon.cycle_due"
    """Fired when a CONMON cycle is within the operator-configured
    due-soon window (default 14 days from query date). Surfaces in
    operator dashboards alongside POA&M attention buckets."""

    CONMON_CYCLE_OVERDUE = "evidentia.conmon.cycle_overdue"
    """Fired when a CONMON cycle's next-due date is in the past
    relative to the query date. Auditor-visible signal that an
    organization is behind on its monitoring obligations."""

    # CONMON daemon lifecycle events (v0.9.3 P1.1) — emitted by the
    # `evidentia conmon watch --poll` long-running daemon as it
    # transitions through its lifecycle. STARTED captures
    # daemon-config attestation at boot; STOPPED captures graceful
    # exit. Together with CONMON_CYCLE_DUE/OVERDUE they form the
    # auditor-visible monitoring-of-the-monitor signal: if there's
    # a STARTED with no matching STOPPED, the daemon crashed.
    #   evidentia.daemon payload:
    #   - poll_interval_seconds: int
    #   - state_file: str (operator-supplied path)
    #   - window_days: int
    #   - cadences_tracked: int (count of slugs in the state file)
    CONMON_DAEMON_STARTED = "evidentia.conmon.daemon_started"
    """Fired at daemon boot. Captures the operator-supplied config
    so auditors can verify the poll cadence matches policy."""

    CONMON_DAEMON_STOPPED = "evidentia.conmon.daemon_stopped"
    """Fired at graceful shutdown (SIGINT/SIGTERM handler). Absence
    of this event after a STARTED is itself an auditor signal — the
    daemon either crashed or was killed."""

    CONMON_DAEMON_POLL_FAILED = "evidentia.conmon.daemon_poll_failed"
    """Fired (with outcome=failure) when a poll cycle skipped due to
    a state-file read/parse error or a derive-status exception. The
    daemon retries at the next interval; emitting this distinct
    action lets SIEM filters separate daemon-health problems from
    genuine CONMON_CYCLE_OVERDUE signals."""

    CONMON_CYCLE_MARKED_COMPLETED = "evidentia.conmon.cycle_marked_completed"
    """Fired when an operator runs `evidentia conmon mark-completed
    <slug> --when YYYY-MM-DD` to record cycle completion. The
    audit-event is the auditor's primary evidence that the cycle
    was actually performed, NOT just scheduled. Payload includes
    the previous last_completed value (or null on first mark) to
    enable cycle-by-cycle reconciliation."""

    # CONMON alerting events (v0.9.3 P1.2) — emitted when the daemon
    # dispatches or suppresses an alert via the operator-configured
    # alerting channels (SMTP + webhook reference impls in
    # evidentia_integrations.alerting). Dedup state lives in the
    # daemon's state file under a reserved key so operators
    # inspecting one file see both anchor dates + dedup history.
    #   evidentia.alert payload:
    #   - cadence_slug: ConmonCadence.slug
    #   - state: "due_soon" | "overdue"
    #   - channel: "smtp" | "webhook" | custom-name
    #   - suppression_window_hours: int (for SUPPRESSED only)
    CONMON_ALERT_DISPATCHED = "evidentia.conmon.alert_dispatched"
    """Fired per (channel, cycle) pair when an alert is successfully
    dispatched. Auditors can reconstruct the alert flow from the
    audit log alone — no need to inspect the channel's outbox."""

    CONMON_ALERT_SUPPRESSED = "evidentia.conmon.alert_suppressed"
    """Fired when an alert would have been dispatched but the
    deduplication window suppressed it. Auditors can verify the
    daemon isn't spamming operators without missing genuine
    transitions."""

    CONMON_HEALTH_REPORT_GENERATED = "evidentia.conmon.health_report_generated"
    """Fired when ``evidentia conmon health`` or
    ``GET /api/conmon/health`` produces a report. Payload includes
    the overall health score + per-framework counts so auditors can
    reconstruct the operator's CONMON posture at any historical
    point from the audit log alone."""

    CONMON_DAEMON_STATUS_QUERIED = "evidentia.conmon.daemon_status_queried"
    """Fired when an operator queries ``GET /api/conmon/daemon-status``
    (v0.9.4 P2.1). The endpoint returns a JSON snapshot of the
    daemon's runtime state (last poll timestamp, outcome, tracked
    cadence count, etc.) by reading a sidecar status file the
    daemon writes after each poll cycle. Audit event records the
    query so SIEM operators can detect unusual polling-of-the-
    monitor patterns."""

    # AI governance events (v0.9.3 P2) — emitted by the
    # `evidentia ai-gov` CLI + `/api/ai-gov/*` REST surfaces when
    # operators classify, register, update, or retire AI systems in
    # the inventory. Auditors trace EU AI Act compliance posture +
    # NIST AI RMF function coverage via these events.
    #   evidentia.ai_system payload:
    #   - system_id: UUID
    #   - eu_ai_act_tier: "unacceptable" | "high" | "limited" | "minimal"
    #   - deployment_status: "proposed" | ... | "retired"
    AI_SYSTEM_CLASSIFIED = "evidentia.ai_governance.system_classified"
    """Fired when `evidentia ai-gov classify` produces a
    classification (whether persisted or one-shot)."""

    AI_SYSTEM_REGISTERED = "evidentia.ai_governance.system_registered"
    """Fired on first-time registration of an AI system in the
    inventory. Tier + provider + owner captured in payload."""

    AI_SYSTEM_UPDATED = "evidentia.ai_governance.system_updated"
    """Fired when an existing registry entry's descriptor,
    classification, or deployment_status is updated."""

    AI_SYSTEM_RETIRED = "evidentia.ai_governance.system_retired"
    """Fired when an AI system's deployment_status transitions to
    RETIRED via the ``evidentia ai-gov retire`` CLI verb or
    ``ai-gov update --deployment-status retired``. Distinct from
    deletion (see AI_SYSTEM_DELETED) — retired records are kept
    for audit history with the operator + timestamp + reason
    preserved."""

    AI_SYSTEM_DELETED = "evidentia.ai_governance.system_deleted"
    """Fired when an AI system registry entry is HARD-deleted via
    ``DELETE /api/ai-gov/systems/{id}``. Distinct from retirement
    (see AI_SYSTEM_RETIRED) — the entry is removed from the
    registry, breaking historical audit-trail continuity for that
    system_id. Auditors filtering on ``event.action:evidentia.ai_
    governance.system_deleted`` see hard-delete events; the audit
    log itself is the only remaining record. Added v0.9.4 Step 5.A
    (F-V94-Q12) to disambiguate from the retire semantic."""

    # ── Federal AI governance (v0.9.6 P3) ──
    # FIPS 199 + OMB M-24-10 + SCR emit surfaces. Each writes one
    # event to the audit log so the SSP / ATO / continuous-monitoring
    # reviewer can trace the provenance of inventory metadata.
    AI_SYSTEM_FIPS_CATEGORIZED = "evidentia.ai_governance.system_fips_categorized"
    """Fired when FIPS 199 categorization is set or updated on an
    AI system registry entry via ``evidentia ai-gov categorize-fips``
    or ``ai-gov update``. Payload carries C / I / A ratings + the
    high-water-mark overall."""

    AI_SYSTEM_OMB_CLASSIFIED = "evidentia.ai_governance.system_omb_classified"
    """Fired when OMB M-24-10 impact category is set or updated via
    ``evidentia ai-gov set-omb-impact`` or ``ai-gov update``. Payload
    carries the new category (rights_impacting / safety_impacting /
    rights_and_safety_impacting / neither)."""

    AI_SYSTEM_SCR_EMITTED = "evidentia.ai_governance.system_scr_emitted"
    """Fired when a Significant Change Request form is emitted via
    ``evidentia ai-gov update --emit-scr <path>``. Payload carries
    the SCR category (routine_recurring / adaptive / transformative)
    + the output path for cross-reference."""

    # Retention + WORM lifecycle events (v0.7.12 P1) — audit-trail
    # actions on records under retention metadata. The PURGED variant
    # serves as the canonical legal-counsel-defensible artifact for
    # GDPR Article 17 (right-to-erasure) executions: every purge
    # call emits one event with the operator identity + GDPR
    # request reference, persisted to the audit log INDEPENDENT of
    # the record itself (which has been deleted).
    RETENTION_RECORD_PUT = "evidentia.retention.record_put"
    RETENTION_RECORD_EXTENDED = "evidentia.retention.record_extended"
    RETENTION_LEGAL_HOLD_APPLIED = "evidentia.retention.legal_hold_applied"
    RETENTION_LEGAL_HOLD_RELEASED = "evidentia.retention.legal_hold_released"
    RETENTION_LIFECYCLE_TRANSITIONED = "evidentia.retention.lifecycle_transitioned"
    RETENTION_RECORD_PURGED = "evidentia.retention.record_purged"
    RETENTION_GDPR_PURGE = "evidentia.retention.gdpr_purge"

    # ── Evidence store WORM lineage (v0.9.6 P2) ──
    # Closes the v0.9.5 P3.2 deferral: the v0.9.5 cycle shipped the
    # EvidenceArtifact.version / lineage_id / predecessor_id data
    # model + new_version() helper; v0.9.6 ships the WORM
    # enforcement at the store layer + the audit trail for it.
    EVIDENCE_VERSION_PERSISTED = "evidentia.evidence.version_persisted"
    EVIDENCE_WORM_VIOLATION_BLOCKED = "evidentia.evidence.worm_violation_blocked"
    EVIDENCE_LINEAGE_QUERIED = "evidentia.evidence.lineage_queried"

    # ── Multi-tenant RBAC boundary crossing (v0.9.8 P1.5) ──
    # Closes the v0.9.7 P2.3 docstring promise that
    # ``check_permission_multi_tenant`` would emit an audit event on
    # cross-tenant escalation. v0.9.7 shipped the EventAction
    # reservation as a comment in `evidentia_core.rbac.multi_tenant`
    # but did NOT fire the event; v0.9.8 wires the emit so SIEM
    # operators see a deterministic record when an identity holding
    # the policy's :attr:`cross_tenant_admin_role` is granted scope
    # outside its claimed tenant.
    #
    # Payload (in addition to canonical run_id + timestamp + outcome):
    #   - identity: the bare identity (without the ``@@<tenant>`` suffix)
    #   - claimed_tenant: tenant from the identity's ``@@<claim>`` (or
    #     None when no claim was present + default_tenant resolved)
    #   - escalation_role: the policy's cross_tenant_admin_role at the
    #     moment of decision
    #   - action: the action string that triggered the check
    #   - outcome: "success" when the escalation granted access;
    #     "failure" when even the escalation denied
    #
    # Distinct from AUTH_* events: those gate the IDENTITY itself
    # (authentication); this one gates a permission DECISION made
    # AFTER identity is known. Pairs naturally with AI_MCP_TOOL_*
    # events when the MCP scope-enforcement layer is upstream of the
    # multi-tenant RBAC check (CIMD scope first, then per-tenant
    # role; an attacker would need both gates to leak through).
    RBAC_TENANT_BOUNDARY_CROSSED = "evidentia.rbac.tenant_boundary_crossed"
    """Fired when :func:`evidentia_core.rbac.multi_tenant.
    check_permission_multi_tenant` grants (or explicitly denies via
    escalation-role degradation) access through the cross-tenant
    admin path. v0.9.8 P1.5 closes the v0.9.7 docstring promise.
    Auditors filtering on ``event.action:evidentia.rbac.tenant_
    boundary_crossed`` see every escalation decision the policy
    permitted — the absence of these events while
    cross_tenant_admin_role != DENY is itself an audit signal that
    no escalation has occurred."""


class EventCategory(str, Enum):
    """ECS ``event.category`` values Evidentia uses.

    ECS defines a controlled vocabulary for event.category. We use a
    subset relevant to GRC evidence collection.
    """

    CONFIGURATION = "configuration"
    IAM = "iam"
    AUTHENTICATION = "authentication"
    PROCESS = "process"
    FILE = "file"
    NETWORK = "network"


class EventType(str, Enum):
    """ECS ``event.type`` values Evidentia uses."""

    INFO = "info"
    ACCESS = "access"
    ALLOWED = "allowed"
    CHANGE = "change"
    CREATION = "creation"
    DELETION = "deletion"
    END = "end"
    START = "start"
    ERROR = "error"


class EventOutcome(str, Enum):
    """ECS ``event.outcome`` values — pinned to the three-value ECS enum."""

    SUCCESS = "success"
    FAILURE = "failure"
    UNKNOWN = "unknown"
