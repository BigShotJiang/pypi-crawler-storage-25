# Equation_library

A class that allows you to solve quadratic and linear equations.

Methods:
        linear_one_variable: solves the linear equation with one variable,
        quadratic: solves the quadratic equation.