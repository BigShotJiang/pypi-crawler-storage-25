"""Command line interface for nemorosa."""

import sys
from argparse import ArgumentParser

import anyio
from apscheduler.schedulers.asyncio import AsyncIOScheduler

from . import config, logger
from .clients import get_torrent_clients, init_torrent_clients
from .core import get_core, init_core
from .db import cleanup_database, get_database, init_database
from .notifier import get_notifier, init_notifier
from .scheduler import init_job_manager
from .trackers import cleanup_api, get_target_apis, init_api
from .webserver import run_webserver


def setup_argument_parser():
    """Set up command line argument parser.

    Returns:
        ArgumentParser: Configured argument parser.
    """
    parser = ArgumentParser(
        description=(
            "Music torrent cross-seeding tool with automatic file mapping "
            "and seamless injection"
        )
    )

    # Operation modes
    mode_group = parser.add_mutually_exclusive_group()
    mode_group.add_argument(
        "-s",
        "--server",
        action="store_true",
        help="start nemorosa in server mode",
    )
    mode_group.add_argument(
        "-t",
        "--torrent",
        type=str,
        help="process a single torrent by infohash",
    )
    mode_group.add_argument(
        "-r",
        "--retry-undownloaded",
        action="store_true",
        help="retry downloading torrents from undownloaded_torrents table",
    )
    mode_group.add_argument(
        "-p",
        "--post-process",
        action="store_true",
        help="post-process injected torrents",
    )
    mode_group.add_argument(
        "--test-notification",
        action="store_true",
        help="send a test notification to configured services",
    )

    # Global options
    global_group = parser.add_argument_group("Global options")
    global_group.add_argument(
        "-l",
        "--loglevel",
        metavar="LOGLEVEL",
        choices=["debug", "info", "warning", "error", "critical"],
        help="loglevel for log file",
    )
    global_group.add_argument(
        "--config",
        help="Path to YAML configuration file",
    )
    global_group.add_argument(
        "--no-download",
        action="store_true",
        help="if set, don't download .torrent files, only save URLs",
    )

    # Server options
    server_group = parser.add_argument_group("Server options")
    server_group.add_argument(
        "--host",
        help="server host",
    )
    server_group.add_argument(
        "--port",
        type=int,
        help="server port",
    )

    return parser


def setup_config(config_path):
    """Set up configuration.

    Args:
        config_path: Path to configuration file (or None for auto-detection).
    """

    # Use new configuration processing module to initialize global config
    try:
        config.init_config(config_path)
        logger.info("Configuration loaded successfully")
    except ValueError as e:
        logger.error("Configuration error: %s", e)
        logger.error("Please check your configuration file and try again")
        sys.exit(1)


def override_config_with_args(args):
    """Override configuration with command line arguments.

    Args:
        args: Parsed command line arguments.
    """
    # Override loglevel if specified
    if args.loglevel is not None:
        config.cfg.global_config.loglevel = config.LogLevel(args.loglevel)

    # Override no_download if specified
    if args.no_download:
        config.cfg.global_config.no_download = True

    # Override server host if specified
    if args.host is not None:
        config.cfg.server.host = args.host

    # Override server port if specified
    if args.port is not None:
        config.cfg.server.port = args.port


async def async_init():
    """Initialize core components asynchronously.

    This function is used by both CLI and webserver modes to set up the application.

    Initialization order (unidirectional dependency chain):
        1. Scheduler (AsyncIOScheduler, no dependencies)
        2. Database
        3. Notifier (optional, depends on config)
        4. Torrent clients (receives database, scheduler, notifier via DI)
        5. Cache rebuild (if client URLs changed)
        6. API connections
        7. Core processor
        8. Job manager (receives scheduler, core, torrent_clients — fully constructed)
    """
    # 1. Create and start scheduler (no dependencies, created first)
    scheduler = AsyncIOScheduler()
    scheduler.start()
    logger.debug("Scheduler started")

    # 2. Initialize database
    logger.debug("Initializing database...")
    await init_database()
    logger.info("Database initialized successfully")

    database = get_database()

    # 3. Initialize notifier (before torrent client, so it can be injected)
    notifier = None
    if config.cfg.global_config.notification_urls:
        init_notifier(config.cfg.global_config.notification_urls)
        notifier = get_notifier()

    # 4. Initialize torrent clients (with scheduler, not job_manager)
    for dl_config in config.cfg.downloaders:
        logger.debug(
            "Connecting to torrent client at %s...",
            dl_config.url,
        )
    await init_torrent_clients(
        config.cfg.downloaders,
        database=database,
        scheduler=scheduler,
        notifier=notifier,
    )
    logger.info(
        "Successfully connected to %d torrent client(s)",
        len(config.cfg.downloaders),
    )

    # 5. Sync client torrents cache with current configuration
    current_keys = {dl.client_key for dl in config.cfg.downloaders}
    cached_keys = await database.get_cached_client_keys()

    # Remove stale cache for clients no longer in config
    stale_keys = cached_keys - current_keys
    for key in stale_keys:
        await database.clear_client_torrents_cache(key)
        logger.info("Cleared stale cache for client: %s", key)

    # Build cache for new clients not yet cached
    new_keys = current_keys - cached_keys
    if new_keys:
        logger.info("Building cache for %d new client(s)...", len(new_keys))
        for torrent_client in get_torrent_clients():
            if torrent_client.client_key in new_keys:
                all_torrents = await torrent_client.get_torrents(
                    fields=[
                        "hash",
                        "name",
                        "total_size",
                        "files",
                        "trackers",
                        "download_dir",
                    ]
                )
                await torrent_client.rebuild_client_torrents_cache(all_torrents)
                logger.success(
                    "Built cache with %s torrents from client",
                    len(all_torrents),
                )

    # 6. Initialize API connections
    await init_api(config.cfg.target_sites)
    logger.info(
        "API connections established for %s target sites", len(get_target_apis())
    )

    # 7. Initialize core processor
    await init_core()
    logger.debug("Core processor initialized")

    # 8. Initialize job manager (all deps available, one-shot construction)
    await init_job_manager(
        scheduler=scheduler,
        database=database,
        core=get_core(),
        torrent_clients=get_torrent_clients(),
    )


def main():
    """Main function."""
    # Step 1: Setup event loop
    logger.init_logger()

    # Step 2: Parse command line arguments
    parser = setup_argument_parser()
    args = parser.parse_args()

    # Step 3: Load configuration
    setup_config(args.config)

    # Step 4: Override configuration with command line arguments
    override_config_with_args(args)

    # Step 5: Update log level with final loglevel from config
    logger.set_log_level(config.cfg.global_config.loglevel)

    # Log configuration summary
    logger.section("===== Configuration Summary =====")
    logger.debug("Config file: %s", args.config or "auto-detected")
    logger.debug("No download: %s", config.cfg.global_config.no_download)
    logger.debug("Log level: %s", config.cfg.global_config.loglevel)
    logger.debug("Torrent clients configured: %d", len(config.cfg.downloaders))
    for i, dl in enumerate(config.cfg.downloaders, 1):
        logger.debug("  Client %d: %s", i, dl.url)
    check_trackers = config.cfg.global_config.check_trackers
    logger.debug(
        "CHECK_TRACKERS: %s",
        check_trackers if check_trackers else "All trackers allowed",
    )

    # Display target sites configuration
    logger.debug("Target sites configured: %d", len(config.cfg.target_sites))
    for i, site in enumerate(config.cfg.target_sites, 1):
        logger.debug("  Site %d: %s", i, site.server)

    logger.section("===== Nemorosa Starting =====")

    # Decide operation based on command line arguments
    if args.server:
        # Server mode
        run_webserver()
    else:
        anyio.run(_async_main, args, backend_options={"use_uvloop": True})

    logger.section("===== Nemorosa Finished =====")


async def _async_main(args):
    """Async main function for non-server operations."""

    try:
        # Initialize core components (database, API connections, scheduler)
        await async_init()

        # Get processor instance
        processor = get_core()

        if args.torrent:
            # Single torrent mode
            logger.debug("Processing single torrent: %s", args.torrent)
            result = await processor.process_single_torrent(args.torrent)

            # Print result
            logger.debug("Processing result: %s", result.status)
            logger.debug("Message: %s", result.message)
        elif args.retry_undownloaded:
            # Re-download undownloaded torrents
            await processor.retry_undownloaded_torrents()
        elif args.post_process:
            # Post-process injected torrents only
            await processor.post_process_injected_torrents()
        elif args.test_notification:
            # Test notification
            if config.cfg.global_config.notification_urls:
                success = await get_notifier().send_test()
                if success:
                    logger.success("Test notification sent successfully")
                else:
                    logger.error("Failed to send test notification")
            else:
                logger.warning("No notification URLs configured")
        else:
            # Normal torrent processing flow
            await processor.process_torrents()
    finally:
        # Wait for torrent monitoring to complete all tracked torrents
        for client in get_torrent_clients():
            if client.monitoring:
                logger.debug(
                    "Stopping torrent monitoring and waiting for tracked "
                    "torrents to complete..."
                )
                await client.wait_for_monitoring_completion()

        # Close all API client sessions
        await cleanup_api()

        # Cleanup database
        await cleanup_database()
