"""Create a package if it does not exist.

Example::

    python examples/ensure_package.py repository-name package-name
"""

from __future__ import annotations

import sys

from repka_sdk import PackageInput
from repka_sdk import to_primitive

from _common import build_client


repository_ref = sys.argv[1]
package_name = sys.argv[2]

with build_client() as client:
    package = client.packages.ensure(
        repository_ref,
        PackageInput(name=package_name),
    )
    print(to_primitive(package))
