"""List repositories and nested packages/releases with the async client.

Example::

    python examples/async_list_entities.py
"""

from __future__ import annotations

import asyncio

from repka_sdk import to_primitive

from _common import build_async_client


async def main() -> None:
    """Run the async entity listing example."""

    async with build_async_client() as client:
        repositories = await client.repositories.list()
        print("repositories", to_primitive(repositories))
        if repositories:
            packages = await client.packages.list(repositories[0].id)
            print("packages", to_primitive(packages))
            if packages:
                releases = await client.releases.list(packages[0].id)
                print("releases", to_primitive(releases))


asyncio.run(main())
