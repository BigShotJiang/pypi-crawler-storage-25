"""Create or update a release and upload one file into it.

Example::

    python examples/ensure_release.py package-name "Release 1.0.0" 1.0.0 ./dist/app.tar.gz
"""

from __future__ import annotations

import sys

from repka_sdk import ReleaseInput
from repka_sdk import to_primitive

from _common import build_client


package_ref = sys.argv[1]
release_name = sys.argv[2]
version_tag = sys.argv[3]
file_path = sys.argv[4]

with build_client() as client:
    release = client.releases.ensure(
        package_ref,
        ReleaseInput(name=release_name, tags=["latest"]),
        version_tag=version_tag,
    )
    release = client.releases.add_assets(
        release.id, client.assets.upload_many([file_path])
    )
    print(to_primitive(release))
