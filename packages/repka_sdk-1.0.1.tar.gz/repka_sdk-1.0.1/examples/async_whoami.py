"""Print the current authenticated Repka user with the async client.

Example::

    python examples/async_whoami.py
"""

from __future__ import annotations

import asyncio

from repka_sdk import to_primitive

from _common import build_async_client


async def main() -> None:
    """Run the async whoami example."""

    async with build_async_client() as client:
        print(to_primitive(await client.auth.whoami()))


asyncio.run(main())
