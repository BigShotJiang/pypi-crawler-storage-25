"""Print the current authenticated Repka user.

Example::

    python examples/whoami.py
"""

from __future__ import annotations

from repka_sdk import to_primitive

from _common import build_client


with build_client() as client:
    print(to_primitive(client.auth.whoami()))
