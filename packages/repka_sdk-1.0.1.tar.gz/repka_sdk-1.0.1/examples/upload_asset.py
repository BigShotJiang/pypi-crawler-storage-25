"""Upload one local file as a reusable release asset.

Example::

    python examples/upload_asset.py ./dist/app.tar.gz
"""

from __future__ import annotations

from repka_sdk import to_primitive

from _common import arg_path
from _common import build_client


with build_client() as client:
    uploaded = client.assets.upload(arg_path(1))
    print(to_primitive(uploaded))
