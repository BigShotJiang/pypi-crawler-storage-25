from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

from repka_sdk import BasicAuthProvider
from repka_sdk import AsyncRepkaClient
from repka_sdk import RepkaClient

DEFAULT_SERVER_URL = "https://rm.nextgis.com"


def _flag(value: Optional[str]) -> bool:
    """Parse an environment flag value."""

    if value is None:
        return False
    return value.strip().lower() in {"1", "true", "yes", "on"}


def build_client() -> RepkaClient:
    """Build an example client from environment variables."""

    server_url = os.environ.get("REPKA_SERVER_URL", DEFAULT_SERVER_URL)
    username = os.environ.get("REPKA_USERNAME")
    password = os.environ.get("REPKA_PASSWORD")
    provider = None
    if username and password:
        provider = BasicAuthProvider(username, password)
    return RepkaClient(
        server_url,
        auth_provider=provider,
        verify=not _flag(os.environ.get("REPKA_INSECURE")),
    )


def build_async_client() -> AsyncRepkaClient:
    """Build an async example client from environment variables."""

    server_url = os.environ.get("REPKA_SERVER_URL", DEFAULT_SERVER_URL)
    username = os.environ.get("REPKA_USERNAME")
    password = os.environ.get("REPKA_PASSWORD")
    provider = None
    if username and password:
        provider = BasicAuthProvider(username, password)
    return AsyncRepkaClient(
        server_url,
        auth_provider=provider,
        verify=not _flag(os.environ.get("REPKA_INSECURE")),
    )


def arg_path(index: int) -> Path:
    """Return a command-line path argument as an absolute path."""

    import sys

    return Path(sys.argv[index]).expanduser().resolve()
