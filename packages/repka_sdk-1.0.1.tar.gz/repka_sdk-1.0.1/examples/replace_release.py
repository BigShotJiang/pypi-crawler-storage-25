"""Replace a release payload with newly uploaded files.

Example::

    python examples/replace_release.py 123 "Release 1.0.1" 1.0.1 ./dist/app.tar.gz
"""

from __future__ import annotations

import sys

from repka_sdk import ReleaseInput
from repka_sdk import to_primitive

from _common import build_client


release_ref = sys.argv[1]
release_name = sys.argv[2]
version_tag = sys.argv[3]
paths = sys.argv[4:]

with build_client() as client:
    assets = client.assets.upload_many(paths)
    release = client.releases.replace(
        release_ref,
        ReleaseInput(
            name=release_name,
            tags=["latest"],
            assets=assets,
        ),
        version_tag=version_tag,
    )
    print(to_primitive(release))
