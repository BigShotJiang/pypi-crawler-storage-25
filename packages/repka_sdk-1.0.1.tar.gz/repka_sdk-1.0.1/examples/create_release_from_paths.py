"""Create a release by uploading local files first.

Example::

    python examples/create_release_from_paths.py package-name "Release 1.0.0" 1.0.0 ./dist/app.tar.gz
"""

from __future__ import annotations

import sys

from repka_sdk import ReleaseInput
from repka_sdk import to_primitive

from _common import build_client


package_ref = sys.argv[1]
release_name = sys.argv[2]
version_tag = sys.argv[3]
paths = sys.argv[4:]

with build_client() as client:
    release = client.releases.create_from_paths(
        package_ref,
        paths,
        ReleaseInput(name=release_name, tags=["latest"]),
        version_tag=version_tag,
    )
    print(to_primitive(release))
