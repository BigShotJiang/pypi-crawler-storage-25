"""Create a release from assets that were uploaded earlier.

Example::

    python examples/create_release_from_uploaded_assets.py package-name "Release 1.0.0" 1.0.0 upload-token:app.tar.gz
"""

from __future__ import annotations

import sys

from repka_sdk import ReleaseAssetInput
from repka_sdk import ReleaseInput
from repka_sdk import to_primitive

from _common import build_client


package_ref = sys.argv[1]
release_name = sys.argv[2]
version_tag = sys.argv[3]
assets = [
    ReleaseAssetInput(upload_name=token, name=name)
    for token, name in [value.split(":", 1) for value in sys.argv[4:]]
]

with build_client() as client:
    release = client.releases.create(
        package_ref,
        ReleaseInput(name=release_name, assets=assets),
        version_tag=version_tag,
    )
    print(to_primitive(release))
