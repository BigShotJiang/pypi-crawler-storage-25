"""List repositories and nested packages and releases.

Example::

    python examples/list_entities.py
"""

from __future__ import annotations

from repka_sdk import to_primitive

from _common import build_client


with build_client() as client:
    repositories = client.repositories.list()
    print("repositories", to_primitive(repositories))
    if repositories:
        packages = client.packages.list(repositories[0].id)
        print("packages", to_primitive(packages))
        if packages:
            releases = client.releases.list(packages[0].id)
            print("releases", to_primitive(releases))
