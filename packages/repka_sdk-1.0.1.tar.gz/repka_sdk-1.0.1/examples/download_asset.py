"""Download an asset to a local destination.

Example::

    python examples/download_asset.py 123 ./downloads/app.tar.gz
"""

from __future__ import annotations

import sys

from _common import arg_path
from _common import build_client


asset_ref = sys.argv[1]
destination = arg_path(2)

with build_client() as client:
    print(client.assets.download(asset_ref, destination))
