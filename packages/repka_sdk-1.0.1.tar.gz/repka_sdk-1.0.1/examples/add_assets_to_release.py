"""Upload files and append them to an existing release.

Example::

    python examples/add_assets_to_release.py 123 ./dist/app.tar.gz
"""

from __future__ import annotations

import sys

from repka_sdk import to_primitive

from _common import build_client


release_ref = sys.argv[1]
paths = sys.argv[2:]

with build_client() as client:
    assets = client.assets.upload_many(paths)
    release = client.releases.add_assets(release_ref, assets)
    print(to_primitive(release))
