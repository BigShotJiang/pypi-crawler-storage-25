# Repka Server Backlog Candidates

These items were observed while running SDK integration tests against a live
Repka server.

## API returns null for nested collections

- Endpoints: `GET /api/packet/:id`, `GET /api/release/:id`, `GET /api/asset/:id`
- Observed behavior: empty `releases` and `files` are serialized as `null`.
- Expected behavior: empty collections should be serialized as `[]`.
- Impact: strongly typed clients must special-case nullable lists.
- SDK workaround: parsers normalize `releases: null` and `files: null` to empty
  lists.

## Repository option validation rejects zero values

- Endpoints: `POST /api/repo`, `PUT /api/repo/:id`
- Observed behavior: `options.keep_releases = 0` and `options.ttl = 0` fail
  validation as missing required fields.
- Expected behavior: either accept `0` as a valid disabled value or document
  `min=1` validation.
- Impact: API schema suggests these fields are numeric values, but server-side
  validation treats zero as absent.
- SDK workaround: integration tests use positive values. No SDK default rewrite
  is applied because changing explicit zeroes would hide user intent.

## Release update cannot safely clear files

- Endpoint: `PUT /api/release/:id`
- Observed behavior: updating a release with an empty `files` list can
  disconnect without an HTTP response. This was seen both for metadata-only
  update of an empty release and for replacing a release that previously had
  files.
- Expected behavior: `files: []` should remove all release files or return a
  structured 4xx/5xx error.
- Impact: clients cannot rely on `PUT` for release replacement that removes
  assets.
- SDK workaround: for metadata-only updates of releases without assets, the SDK
  omits the `files` field. Clearing all assets from a release is intentionally
  rejected by the SDK because the server path is unsafe and replacing the release
  would change its id.

## Asset download can close connection without an HTTP response

- Endpoint: `GET /api/asset/:id/download`
- Observed behavior: downloading asset `15108` on staging sometimes returns a
  structured `404 asset not found` and sometimes closes the connection before
  sending an HTTP response.
- Expected behavior: unavailable assets should always return a structured 404
  or another structured error response.
- Impact: clients cannot distinguish a missing asset from a transient server
  failure by status code when the connection is closed early.
- SDK workaround: stream error bodies are read before mapping HTTP errors, so a
  structured 404 becomes `RepkaNotFoundError` instead of an unread response
  failure. Integration tests skip this fixed live asset when the server reports
  it as missing or drops the connection.
