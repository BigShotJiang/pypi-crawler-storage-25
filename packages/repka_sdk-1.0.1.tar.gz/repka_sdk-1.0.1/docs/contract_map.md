# Contract Map

## Endpoints

- `GET /api/repo`
- `GET /api/repo/{id}`
- `POST /api/repo`
- `PUT /api/repo/{id}`
- `DELETE /api/repo/{id}`
- `GET /api/packet?repository={id}`
- `GET /api/packet/{id}`
- `POST /api/packet`
- `PUT /api/packet/{id}`
- `DELETE /api/packet/{id}`
- `GET /api/release?packet={id}`
- `GET /api/release?tag=value&option=key:value`
- `GET /api/release/{id}`
- `POST /api/release`
- `PUT /api/release/{id}`
- `DELETE /api/release/{id}`
- `POST /api/upload`
- `GET /api/asset/{id}/download`
- `GET /api/asset/{id}/rights`
- `GET /api/repo/{id}/qgis_xml`
- `GET /api/repo/{id}/qgis_protect_plugin`
- `GET /api/repo/{id}/qgis_protect_plugin/{plugin}`
- `GET /api/repo/{id}/borsch?packet_name={name}&release_tag={tag}`
- `GET /api/repo/{id}/installer/{packet}/{subpath}`
- `GET /api/repo/{id}/deb/dists/{dist}/{subpath}`
- `GET /api/repo/{id}/deb/pool/{asset}/download/{name}`
- `GET /api/repo/{id}/deb/key.gpg`
- `GET /api/healthcheck`
- `GET /api/version`
- `GET /api/options`
- `GET /api/stats`
- `POST /api/login`
- `GET /api/current_user`
- `GET /api/logout`
- `GET /api/oauth2/options`
- `GET /api/oauth2/user`
- `GET /api/settings`
- `PUT /api/settings`
- `POST /api/settings/test_ldap`
- `PUT /api/settings/test_ldap`
- `GET /api/sign_code`
- `GET /api/jobs`
- `GET /api/apple_cert/{filename}`
- `POST /api/apple_cert`
- `PUT /api/apple_cert`
- `GET /api/user`
- `GET /api/user/{id}`
- `GET /api/user/{id}/avatar`
- `POST /api/user`
- `PUT /api/user/{id}`
- `DELETE /api/user/{id}`
- `GET /api/group`
- `GET /api/group/{id}`
- `POST /api/group`
- `PUT /api/group/{id}`
- `DELETE /api/group/{id}`
- `GET /api/sync/{type}`
- `GET /api/sync/{type}/repo/{repo}`

## Payload highlights

- Repository create/update uses `{name, description, type, options, permissions}`.
- Package create/update uses `{name, description, author, repository, sync_packet}`.
- Release create uses `{name, description, packet, tags, options, files}`.
- Release update uses `{name, description, tags, options, files}`.
- Upload returns `{file, name, options}`.
- `files` items use `{id?, upload_name?, name, description}`.
- Admin, settings, sync, and protected repository-content endpoints are exposed
  as raw dictionaries/bytes because their shapes are backend-specific.

## Internal storage

- Tags are stored as `tag1|tag2|tag3`.
- Release options are stored as `key:value|key:value`.
- Public SDK normalizes both into structured types.

## Canonical UI routes

- Repository: `/repo/{id}`
- Package: `/packet/{id}`
- Release: `/release/{id}/edit`
