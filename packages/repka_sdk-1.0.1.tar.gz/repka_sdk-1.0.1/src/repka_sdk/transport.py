from __future__ import annotations

from contextlib import asynccontextmanager
from contextlib import contextmanager
from importlib.metadata import PackageNotFoundError
from importlib.metadata import version
from typing import Any
from typing import Dict
from typing import Iterable
from typing import Iterator
from typing import Optional
from typing import Sequence

import httpx

from .auth import AuthProvider
from .config import validate_server_url
from .exceptions import RepkaTransportError
from .exceptions import exception_from_status
from ._logging import get_logger


SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}
logger = get_logger(__name__)


def _default_user_agent() -> str:
    try:
        package_version = version("repka-sdk")
    except PackageNotFoundError:
        package_version = "0.1.0"
    return f"repka-sdk/{package_version}"


def _default_headers(headers: Optional[Dict[str, str]]) -> Dict[str, str]:
    merged = {"User-Agent": _default_user_agent()}
    for key, value in (headers or {}).items():
        if key.lower() == "user-agent":
            merged.pop("User-Agent", None)
        merged[key] = value
    return merged


def _extract_error(response: httpx.Response) -> RepkaTransportError:
    payload: Any = None
    message = response.text or f"HTTP {response.status_code}"
    content_type = response.headers.get("content-type", "")
    if "json" in content_type:
        try:
            payload = response.json()
        except ValueError:
            payload = None
        else:
            if isinstance(payload, dict):
                message = str(
                    payload.get("error") or payload.get("message") or message
                )
    return exception_from_status(
        response.status_code,
        message,
        details=payload,
    )


def _parse_response(response: httpx.Response) -> Any:
    if not response.content:
        return None
    content_type = response.headers.get("content-type", "")
    if "json" in content_type:
        return response.json()
    return response.content


class SyncTransport:
    """Synchronous HTTP transport for Repka API requests."""

    def __init__(
        self,
        base_url: str,
        *,
        auth_provider: Optional[AuthProvider] = None,
        timeout: float = 30.0,
        verify: bool = True,
        retries: int = 2,
        headers: Optional[Dict[str, str]] = None,
    ) -> None:
        self.base_url = validate_server_url(base_url)
        logger.debug("Creating sync transport for %s", self.base_url)
        self.retries = max(retries, 0)
        self._client = httpx.Client(
            base_url=self.base_url,
            timeout=timeout,
            verify=verify,
            auth=auth_provider.get_httpx_auth() if auth_provider else None,
            headers=_default_headers(headers),
            follow_redirects=True,
        )

    def close(self) -> None:
        """Close the service resources."""

        self._client.close()

    def request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Any] = None,
        data: Optional[Any] = None,
        files: Optional[Any] = None,
        headers: Optional[Dict[str, str]] = None,
        expected_status: Optional[Sequence[int]] = None,
    ) -> Any:
        """Send an API request and return the parsed response."""

        attempts = self.retries + 1 if method.upper() in SAFE_METHODS else 1
        last_error: Optional[Exception] = None
        for _ in range(attempts):
            try:
                logger.debug("HTTP %s %s", method.upper(), path)
                response = self._client.request(
                    method=method,
                    url=path,
                    params=params,
                    json=json,
                    data=data,
                    files=files,
                    headers=headers,
                )
            except httpx.HTTPError as exc:
                last_error = exc
                continue

            if (
                expected_status is not None
                and response.status_code not in expected_status
            ):
                raise _extract_error(response)
            if response.status_code >= 400:
                logger.warning(
                    "HTTP %s %s failed with %s",
                    method.upper(),
                    path,
                    response.status_code,
                )
                raise _extract_error(response)
            logger.debug(
                "HTTP %s %s returned %s",
                method.upper(),
                path,
                response.status_code,
            )
            return _parse_response(response)

        raise RepkaTransportError(str(last_error or "Request failed"))

    @contextmanager
    def stream(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Iterator[httpx.Response]:
        """Open a streaming API response context."""

        try:
            with self._client.stream(
                method,
                path,
                params=params,
                headers=headers,
            ) as response:
                if response.status_code >= 400:
                    response.read()
                    raise _extract_error(response)
                yield response
        except httpx.HTTPError as exc:
            raise RepkaTransportError(str(exc)) from exc


class AsyncTransport:
    """Asynchronous HTTP transport for Repka API requests."""

    def __init__(
        self,
        base_url: str,
        *,
        auth_provider: Optional[AuthProvider] = None,
        timeout: float = 30.0,
        verify: bool = True,
        retries: int = 2,
        headers: Optional[Dict[str, str]] = None,
    ) -> None:
        self.base_url = validate_server_url(base_url)
        logger.debug("Creating async transport for %s", self.base_url)
        self.retries = max(retries, 0)
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=timeout,
            verify=verify,
            auth=auth_provider.get_httpx_auth() if auth_provider else None,
            headers=_default_headers(headers),
            follow_redirects=True,
        )

    async def aclose(self) -> None:
        """Close the service resources asynchronously."""

        await self._client.aclose()

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Any] = None,
        data: Optional[Any] = None,
        files: Optional[Any] = None,
        headers: Optional[Dict[str, str]] = None,
        expected_status: Optional[Sequence[int]] = None,
    ) -> Any:
        """Send an API request and return the parsed response."""

        attempts = self.retries + 1 if method.upper() in SAFE_METHODS else 1
        last_error: Optional[Exception] = None
        for _ in range(attempts):
            try:
                logger.debug("HTTP %s %s", method.upper(), path)
                response = await self._client.request(
                    method=method,
                    url=path,
                    params=params,
                    json=json,
                    data=data,
                    files=files,
                    headers=headers,
                )
            except httpx.HTTPError as exc:
                last_error = exc
                continue

            if (
                expected_status is not None
                and response.status_code not in expected_status
            ):
                raise _extract_error(response)
            if response.status_code >= 400:
                logger.warning(
                    "HTTP %s %s failed with %s",
                    method.upper(),
                    path,
                    response.status_code,
                )
                raise _extract_error(response)
            logger.debug(
                "HTTP %s %s returned %s",
                method.upper(),
                path,
                response.status_code,
            )
            return _parse_response(response)

        raise RepkaTransportError(str(last_error or "Request failed"))

    @asynccontextmanager
    async def stream(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Iterable[httpx.Response]:
        """Open a streaming API response context."""

        try:
            async with self._client.stream(
                method,
                path,
                params=params,
                headers=headers,
            ) as response:
                if response.status_code >= 400:
                    await response.aread()
                    raise _extract_error(response)
                yield response
        except httpx.HTTPError as exc:
            raise RepkaTransportError(str(exc)) from exc
