from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional
from typing import Union
from urllib.parse import urlparse


_API_PATTERNS = {
    "repository": re.compile(r"^/api/repo/(?P<id>\d+)(?:/.*)?$"),
    "package": re.compile(r"^/api/packet/(?P<id>\d+)(?:/.*)?$"),
    "release": re.compile(r"^/api/release/(?P<id>\d+)(?:/.*)?$"),
    "asset": re.compile(r"^/api/asset/(?P<id>\d+)(?:/download)?/?$"),
}

_UI_PATTERNS = {
    "repository": re.compile(r"^/repo/(?P<id>\d+)(?:/edit)?/?$"),
    "package": re.compile(r"^/packet/(?P<id>\d+)(?:/edit)?/?$"),
    "release": re.compile(r"^/release/(?P<id>\d+)(?:/edit)?/?$"),
}


@dataclass
class ParsedUrlReference:
    """Parsed reference extracted from a Repka URL."""

    entity_type: str
    entity_id: int
    source: str
    url: str


def is_numeric_reference(reference: Union[int, str]) -> bool:
    """Return whether a reference is an integer identifier."""

    if isinstance(reference, int):
        return True
    return str(reference).strip().isdigit()


def parse_repka_url(reference: str) -> Optional[ParsedUrlReference]:
    """Parse a Repka UI or API URL into an entity reference."""

    parsed = urlparse(reference)
    if not parsed.scheme or not parsed.netloc:
        return None

    path = parsed.path.rstrip("/") or "/"
    for entity_type, pattern in _API_PATTERNS.items():
        match = pattern.match(path)
        if match:
            return ParsedUrlReference(
                entity_type=entity_type,
                entity_id=int(match.group("id")),
                source="api",
                url=reference,
            )

    for entity_type, pattern in _UI_PATTERNS.items():
        match = pattern.match(path)
        if match:
            return ParsedUrlReference(
                entity_type=entity_type,
                entity_id=int(match.group("id")),
                source="ui",
                url=reference,
            )
    return None


def build_api_url(
    base_url: str,
    entity_type: str,
    entity_id: int,
    *,
    download: bool = False,
) -> str:
    """Build an API URL for a Repka entity reference."""

    normalized = base_url.rstrip("/")
    if entity_type == "repository":
        return f"{normalized}/api/repo/{entity_id}"
    if entity_type == "package":
        return f"{normalized}/api/packet/{entity_id}"
    if entity_type == "release":
        return f"{normalized}/api/release/{entity_id}"
    if entity_type == "asset":
        suffix = "/download" if download else ""
        return f"{normalized}/api/asset/{entity_id}{suffix}"
    raise ValueError(f"Unsupported entity type: {entity_type}")


def build_ui_url(base_url: str, entity_type: str, entity_id: int) -> str:
    """Build a UI URL for a Repka entity reference."""

    normalized = base_url.rstrip("/")
    if entity_type == "repository":
        return f"{normalized}/repo/{entity_id}"
    if entity_type == "package":
        return f"{normalized}/packet/{entity_id}"
    if entity_type == "release":
        return f"{normalized}/release/{entity_id}/edit"
    raise ValueError(f"Unsupported entity type: {entity_type}")
