from __future__ import annotations

import logging


LOGGER_NAME = "repka_sdk"


def get_logger(name: str) -> logging.Logger:
    """Return a logger under the Repka SDK namespace."""

    return logging.getLogger(name)


def configure_logging(verbose: bool = False) -> None:
    """Configure CLI logging without affecting normal command output."""

    logger = logging.getLogger(LOGGER_NAME)
    if not verbose:
        logger.setLevel(logging.WARNING)
        return

    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(
            logging.Formatter("%(levelname)s %(name)s: %(message)s")
        )
        logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
