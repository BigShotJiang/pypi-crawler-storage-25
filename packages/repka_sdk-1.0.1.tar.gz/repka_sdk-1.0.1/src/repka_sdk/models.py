from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field
from dataclasses import fields
from dataclasses import is_dataclass
from datetime import datetime
from enum import IntEnum
from pathlib import Path
from typing import Any
from typing import Dict
from typing import Iterable
from typing import List
from typing import Mapping
from typing import Optional
from typing import Sequence
from typing import Tuple
from typing import Union


SPECIAL_RELEASE_TAGS = {"latest", "experimental"}


class RepositoryType(IntEnum):
    """Repository type values used by the Repka API."""

    ANY = 0
    DEBIAN = 1
    DOCKER = 2
    BORSCH = 3
    INSTALLER = 4
    QGIS = 5
    MAVEN = 6

    @property
    def slug(self) -> str:
        """Return the API slug for the repository type."""

        mapping = {
            RepositoryType.ANY: "any",
            RepositoryType.DEBIAN: "ubuntu",
            RepositoryType.DOCKER: "docker",
            RepositoryType.BORSCH: "borsch",
            RepositoryType.INSTALLER: "installer",
            RepositoryType.QGIS: "qgis",
            RepositoryType.MAVEN: "maven",
        }
        return mapping[self]

    @classmethod
    def from_value(
        cls, value: Union["RepositoryType", int, str, None]
    ) -> Optional["RepositoryType"]:
        """Create a repository type from a slug, integer value, or enum."""

        if value is None:
            return None
        if isinstance(value, RepositoryType):
            return value
        if isinstance(value, int):
            return cls(value)
        normalized = str(value).strip().lower()
        for candidate in cls:
            if candidate.slug == normalized:
                return candidate
        return cls(int(normalized))


@dataclass
class SignKey:
    """Repository signing key metadata."""

    public_key: str = ""
    fingerprint: str = ""


@dataclass
class Permission:
    """Repository permission entry."""

    id: int
    type: int
    name: str = ""
    login: str = ""


@dataclass
class RepositoryOptions:
    """Repository cleanup and retention options."""

    cleanup: bool = False
    keep_releases: int = 0
    ttl: int = 0

    @classmethod
    def from_mapping(cls, values: Mapping[str, Any]) -> "RepositoryOptions":
        """Build repository options from API-style key/value data."""

        cleanup_value = str(values.get("cleanup", "false")).strip().lower()
        cleanup = cleanup_value in {"1", "true", "yes", "on"}
        keep_releases = int(values.get("keep_releases", 0) or 0)
        ttl = int(values.get("ttl", 0) or 0)
        return cls(
            cleanup=cleanup,
            keep_releases=keep_releases,
            ttl=ttl,
        )


@dataclass
class ReleaseOptions:
    """Release option key/value collection."""

    values: Dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        normalized = {
            str(key): str(value)
            for key, value in dict(self.values).items()
            if value is not None
        }
        self.values = normalized

    @classmethod
    def from_pairs(
        cls, pairs: Optional[Iterable[Mapping[str, Any]]]
    ) -> "ReleaseOptions":
        """Build release options from API option pairs."""

        options: Dict[str, str] = {}
        for item in pairs or []:
            key = item.get("key")
            value = item.get("value")
            if key is None or value is None:
                continue
            options[str(key)] = str(value)
        return cls(options)

    @classmethod
    def from_strings(cls, pairs: Optional[Iterable[str]]) -> "ReleaseOptions":
        """Build release options from ``key:value`` strings."""

        options: Dict[str, str] = {}
        for item in pairs or []:
            if ":" not in item:
                continue
            key, value = item.split(":", 1)
            options[key] = value
        return cls(options)

    def to_pairs(self) -> List[Dict[str, str]]:
        """Return API option pairs sorted by key."""

        return [
            {"key": key, "value": value}
            for key, value in self.normalized_items()
        ]

    def to_query_values(self) -> List[str]:
        """Return option values suitable for query parameters."""

        return [f"{key}:{value}" for key, value in self.normalized_items()]

    def normalized_items(self) -> List[Tuple[str, str]]:
        """Return option items sorted by key."""

        return sorted(self.values.items(), key=lambda item: item[0])

    def matches_subset(self, other: "ReleaseOptions") -> bool:
        """Check whether these options contain another option set."""

        for key, value in other.values.items():
            if self.values.get(key) != value:
                return False
        return True

    def copy(self) -> "ReleaseOptions":
        """Return a shallow copy of the release options."""

        return ReleaseOptions(dict(self.values))


@dataclass
class Asset:
    """Asset metadata returned by the Repka API."""

    id: Optional[int]
    name: str
    description: str = ""
    size: int = 0
    downloads: int = 0


@dataclass
class UploadedAsset:
    """Metadata for an asset uploaded before release creation."""

    upload_name: str
    name: str
    description: str = ""
    options: ReleaseOptions = field(default_factory=ReleaseOptions)


@dataclass
class ReleaseAssetInput:
    """Asset reference accepted by release create and update operations."""

    name: str
    description: str = ""
    id: Optional[int] = None
    upload_name: Optional[str] = None

    @classmethod
    def from_asset(cls, asset: Asset) -> "ReleaseAssetInput":
        """Build release asset input from an existing asset."""

        return cls(
            id=asset.id,
            name=asset.name,
            description=asset.description,
        )

    @classmethod
    def from_uploaded_asset(
        cls,
        asset: UploadedAsset,
    ) -> "ReleaseAssetInput":
        """Build release asset input from an uploaded asset token."""

        return cls(
            upload_name=asset.upload_name,
            name=asset.name,
            description=asset.description,
        )


@dataclass
class Release:
    """Release metadata returned by the Repka API."""

    id: int
    name: str
    description: str = ""
    tags: List[str] = field(default_factory=list)
    options: ReleaseOptions = field(default_factory=ReleaseOptions)
    assets: List[Asset] = field(default_factory=list)
    downloads: int = 0
    created: Optional[datetime] = None
    updated: Optional[datetime] = None
    package_id: Optional[int] = None

    def version_tag(self) -> Optional[str]:
        """Return the positional version tag for the release."""

        tags = normalize_tags(self.tags)
        for candidate in reversed(tags):
            if candidate not in SPECIAL_RELEASE_TAGS:
                return candidate
        return None


@dataclass
class Package:
    """Package metadata returned by the Repka API."""

    id: int
    name: str
    description: str = ""
    author: str = ""
    owner: str = ""
    repository_id: Optional[int] = None
    repository_type: Optional[RepositoryType] = None
    key: str = ""
    sync_package_id: int = 0
    created: Optional[datetime] = None
    updated: Optional[datetime] = None
    releases: List[Release] = field(default_factory=list)


@dataclass
class Repository:
    """Repository metadata returned by the Repka API."""

    id: int
    name: str
    description: str = ""
    type: RepositoryType = RepositoryType.ANY
    options: RepositoryOptions = field(default_factory=RepositoryOptions)
    created: Optional[datetime] = None
    updated: Optional[datetime] = None
    link: str = ""
    key: Optional[SignKey] = None
    owner: str = ""
    packages: List[Package] = field(default_factory=list)
    permissions: List[Permission] = field(default_factory=list)


@dataclass
class ServerConfig:
    """Saved Repka server configuration."""

    name: str
    url: str
    default: bool = False
    username: Optional[str] = None


@dataclass
class UserInfo:
    """Current user information returned by the Repka API."""

    id: int
    login: str
    name: str
    nextgis_guid: str = ""
    login_type: int = 0
    email: str = ""
    locale: str = ""
    groups: List[str] = field(default_factory=list)
    created: Optional[datetime] = None
    updated: Optional[datetime] = None


@dataclass
class AuthStatus:
    """Authentication status for a resolved Repka configuration."""

    server: Optional[ServerConfig]
    source: Optional[str]
    username: Optional[str]
    authenticated: bool
    user: Optional[UserInfo] = None


@dataclass
class RepositoryInput:
    """Repository fields accepted by create, update, and ensure operations."""

    name: Optional[str] = None
    description: Optional[str] = None
    repository_type: Optional[RepositoryType] = None
    options: Optional[RepositoryOptions] = None
    permissions: Optional[List[Permission]] = None


@dataclass
class PackageInput:
    """Package fields accepted by create, update, and ensure operations."""

    name: Optional[str] = None
    description: Optional[str] = None
    author: Optional[str] = None
    sync_package_id: Optional[int] = None


@dataclass
class ReleaseInput:
    """Release fields accepted by create, update, and ensure operations."""

    name: Optional[str] = None
    description: Optional[str] = None
    tags: Optional[List[str]] = None
    options: Optional[ReleaseOptions] = None
    assets: Optional[List[ReleaseAssetInput]] = None


def normalize_tags(tags: Optional[Sequence[str]]) -> List[str]:
    """Return cleaned release tags without duplicates."""

    unique: List[str] = []
    for tag in tags or []:
        normalized = str(tag).strip()
        if not normalized:
            continue
        if normalized not in unique:
            unique.append(normalized)
    return unique


def normalize_asset_inputs(
    assets: Optional[Sequence[Union[Asset, UploadedAsset, ReleaseAssetInput]]],
) -> Optional[List[ReleaseAssetInput]]:
    """Normalize supported asset references into release asset inputs."""

    if assets is None:
        return None

    normalized: List[ReleaseAssetInput] = []
    for asset in assets:
        if isinstance(asset, ReleaseAssetInput):
            normalized.append(asset)
            continue
        if isinstance(asset, UploadedAsset):
            normalized.append(ReleaseAssetInput.from_uploaded_asset(asset))
            continue
        if isinstance(asset, Asset):
            normalized.append(ReleaseAssetInput.from_asset(asset))
            continue
        raise TypeError(f"Unsupported release asset: {asset!r}")
    return normalized


def sort_assets(
    assets: Sequence[Union[Asset, ReleaseAssetInput]],
) -> List[Any]:
    """Return assets in a stable order for comparison and serialization."""

    return sorted(
        assets,
        key=lambda asset: (
            getattr(asset, "name", ""),
            getattr(asset, "id", 0) or 0,
            getattr(asset, "upload_name", "") or "",
        ),
    )


def parse_datetime(value: Optional[str]) -> Optional[datetime]:
    """Parse an API datetime value and ignore invalid values."""

    if not value:
        return None
    try:
        if value.endswith("Z"):
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        return datetime.fromisoformat(value)
    except ValueError:
        return None


def to_primitive(value: Any) -> Any:
    """Convert SDK objects into JSON-serializable primitives."""

    if isinstance(value, Path):
        return str(value)
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, RepositoryType):
        return value.slug
    if isinstance(value, ReleaseOptions):
        return dict(value.normalized_items())
    if isinstance(value, list):
        return [to_primitive(item) for item in value]
    if isinstance(value, tuple):
        return [to_primitive(item) for item in value]
    if isinstance(value, dict):
        return {str(key): to_primitive(item) for key, item in value.items()}
    if is_dataclass(value):
        return {
            field_info.name: to_primitive(getattr(value, field_info.name))
            for field_info in fields(value)
        }
    return value
