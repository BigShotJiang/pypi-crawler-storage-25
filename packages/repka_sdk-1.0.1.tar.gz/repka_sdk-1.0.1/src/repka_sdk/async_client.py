from __future__ import annotations

from typing import Optional

from .auth import AuthProvider
from .config import DEFAULT_SERVER_URL
from ._logging import get_logger
from .services.admin import AsyncAdminService
from .services.assets import AsyncAssetService
from .services.auth import AsyncAuthService
from .services.packages import AsyncPackageService
from .services.release_search import AsyncSearchService
from .services.releases import AsyncReleaseService
from .services.repositories import AsyncRepositoryService
from .services.server import AsyncServerService
from .services.sync import AsyncSyncService
from .transport import AsyncTransport

logger = get_logger(__name__)


class AsyncRepkaClient:
    """Asynchronous entry point for Repka API operations."""

    def __init__(
        self,
        base_url: str = DEFAULT_SERVER_URL,
        *,
        auth_provider: Optional[AuthProvider] = None,
        timeout: float = 30.0,
        verify: bool = True,
        retries: int = 2,
    ) -> None:
        """Create an asynchronous client bound to a Repka server."""

        logger.debug("Initializing AsyncRepkaClient for %s", base_url)
        self.transport = AsyncTransport(
            base_url,
            auth_provider=auth_provider,
            timeout=timeout,
            verify=verify,
            retries=retries,
        )
        self.repositories = AsyncRepositoryService(self.transport)
        self.packages = AsyncPackageService(self.transport, self.repositories)
        self.assets = AsyncAssetService(self.transport)
        self.admin = AsyncAdminService(self.transport)
        self.server = AsyncServerService(self.transport)
        self.sync = AsyncSyncService(self.transport)
        self.releases = AsyncReleaseService(
            self.transport,
            self.repositories,
            self.packages,
            self.assets,
        )
        self.auth = AsyncAuthService(self.transport, auth_provider)
        self.search = AsyncSearchService(
            self.repositories,
            self.packages,
            self.releases,
        )

    async def aclose(self) -> None:
        """Close the underlying asynchronous HTTP transport."""

        logger.debug("Closing AsyncRepkaClient")
        await self.transport.aclose()

    async def __aenter__(self) -> "AsyncRepkaClient":
        return self

    async def __aexit__(self, exc_type, exc_value, traceback) -> None:
        await self.aclose()
