from __future__ import annotations

from pathlib import Path
from typing import Any
from typing import List
from typing import Optional

import typer

from ..exceptions import RepkaConfigurationError
from ..exceptions import RepkaNotFoundError
from .app import asset_app
from .logic import build_client
from .logic import choose_release
from .logic import execute
from .logic import result
from .logic import state as cli_state


@asset_app.command("upload")
def asset_upload(
    ctx: typer.Context,
    files: List[Path] = typer.Argument(..., help="Files to upload."),
) -> None:
    """Upload one or more assets."""

    state = cli_state(ctx)

    def operation() -> Any:
        if state.dry_run:
            return {"dry_run": True, "action": "asset.upload", "files": files}
        with build_client(state) as client:
            return client.assets.upload_many(files)

    execute(state, operation)


@asset_app.command("download")
def asset_download(
    ctx: typer.Context,
    reference: str = typer.Argument(
        ...,
        help="Asset ID, asset URL, or release ID/URL when --all is used.",
    ),
    destination: Path = typer.Argument(
        Path("."),
        help="Destination path.",
    ),
    all_assets: bool = typer.Option(
        False,
        "--all",
        help="Download all assets from the release reference.",
    ),
) -> None:
    """Download an asset."""

    state = cli_state(ctx)

    def operation() -> Any:
        with build_client(state) as client:
            if all_assets:
                release = client.releases.get(reference)
                return [
                    client.assets.download(asset.id, destination)
                    for asset in release.assets
                    if asset.id is not None
                ]
            return client.assets.download(reference, destination)

    execute(state, operation)


@asset_app.command("list")
def asset_list(
    ctx: typer.Context,
    release: Optional[str] = typer.Argument(
        None,
        help="Release ID, name, or URL. Omit to choose interactively.",
    ),
    package: Optional[str] = typer.Option(
        None,
        "--package",
        "-p",
        help="Parent package ID, name, or URL.",
    ),
    repo: Optional[str] = typer.Option(
        None,
        "--repo",
        "-r",
        help="Parent repository ID, name, or URL.",
    ),
    field: Optional[List[str]] = typer.Option(
        None,
        "--field",
        "-F",
        help="Table field to print. Can be repeated or comma-separated.",
    ),
    all_fields: bool = typer.Option(
        False,
        "--all",
        help="Print all available table fields.",
    ),
) -> None:
    """List assets attached to a release."""

    state = cli_state(ctx)

    def operation() -> Any:
        with build_client(state) as client:
            selected_release = choose_release(
                client,
                release,
                package=package,
                repo=repo,
            )
            return result(
                selected_release.assets,
                "list",
                fields=field,
                all_fields=all_fields,
            )

    execute(state, operation)


@asset_app.command("get")
def asset_get(
    ctx: typer.Context,
    reference: str = typer.Argument(..., help="Asset ID or name."),
    release: Optional[str] = typer.Option(
        None,
        "--release",
        "-r",
        help="Release ID, name, or URL that contains the asset.",
    ),
    package: Optional[str] = typer.Option(
        None,
        "--package",
        "-p",
        help="Parent package ID, name, or URL.",
    ),
    repo: Optional[str] = typer.Option(
        None,
        "--repo",
        help="Parent repository ID, name, or URL.",
    ),
) -> None:
    """Show an asset attached to a release."""

    state = cli_state(ctx)

    def operation() -> Any:
        if release is None:
            raise RepkaConfigurationError(
                "Asset get requires --release because the server has no "
                "asset detail endpoint"
            )
        with build_client(state) as client:
            selected_release = choose_release(
                client,
                release,
                package=package,
                repo=repo,
            )
            for asset in selected_release.assets:
                if str(asset.id) == reference or asset.name == reference:
                    return asset
            raise RepkaNotFoundError("Asset not found in release")

    execute(state, operation)


@asset_app.command("rights")
def asset_rights(
    ctx: typer.Context,
    reference: str = typer.Argument(..., help="Asset ID or URL."),
) -> None:
    """Show current-user rights for an asset."""

    state = cli_state(ctx)

    def operation() -> Any:
        with build_client(state) as client:
            return client.assets.rights(reference)

    execute(state, operation)
