from __future__ import annotations

from typing import Any
from typing import List
from typing import Optional

import typer

from ..exceptions import RepkaNotFoundError
from ..models import PackageInput
from ..services.common import package_matches_input
from .app import package_app
from .logic import build_client
from .logic import choose_package
from .logic import choose_repository
from .logic import execute
from .logic import result
from .logic import state as cli_state


@package_app.command("create")
def package_create(
    ctx: typer.Context,
    repo: str = typer.Option(
        ...,
        "--repo",
        "-r",
        help="Parent repository ID, name, or URL.",
    ),
    name: str = typer.Option(..., "--name", "-n", help="Package name."),
    description: str = typer.Option(
        "",
        "--description",
        "-d",
        help="Package description.",
    ),
    author: str = typer.Option("", "--author", "-a", help="Package author."),
    sync_package_id: int = typer.Option(
        0,
        "--sync-package-id",
        help="Source package ID used for synchronization.",
    ),
) -> None:
    """Create a package."""

    state = cli_state(ctx)

    def operation() -> Any:
        write = PackageInput(
            name=name,
            description=description,
            author=author,
            sync_package_id=sync_package_id,
        )
        if state.dry_run:
            return {
                "dry_run": True,
                "action": "package.create",
                "repo": repo,
                "payload": write,
            }
        with build_client(state) as client:
            return client.packages.create(repo, write)

    execute(state, operation)


@package_app.command("get")
def package_get(
    ctx: typer.Context,
    reference: Optional[str] = typer.Argument(
        None,
        help="Package ID, name, or URL. Omit to choose interactively.",
    ),
    repo: Optional[str] = typer.Option(
        None,
        "--repo",
        "-r",
        help="Parent repository ID, name, or URL.",
    ),
) -> None:
    """Show a package."""

    state = cli_state(ctx)

    def operation() -> Any:
        with build_client(state) as client:
            package = choose_package(client, reference, repo=repo)
            return client.packages.get(package.id)

    execute(state, operation)


@package_app.command("list")
def package_list(
    ctx: typer.Context,
    repo: Optional[str] = typer.Option(
        None,
        "--repo",
        "-r",
        help="Repository ID, name, or URL. Required; prompted when omitted.",
    ),
    filter_text: Optional[str] = typer.Option(
        None,
        "--filter",
        "-f",
        help="Text filter applied by the Repka API.",
    ),
    sort: Optional[str] = typer.Option(
        None,
        "--sort",
        "-S",
        help="Sort expression accepted by the Repka API, for example name or -name.",
    ),
    field: Optional[List[str]] = typer.Option(
        None,
        "--field",
        "-F",
        help="Table field to print. Can be repeated; use 'all' for every field.",
    ),
    all_fields: bool = typer.Option(
        False,
        "--all",
        help="Print all available table fields.",
    ),
) -> None:
    """List packages."""

    state = cli_state(ctx)

    def operation() -> Any:
        with build_client(state) as client:
            selected_repo = repo or choose_repository(client)
            return result(
                client.packages.list(
                    repository=selected_repo,
                    filter_text=filter_text,
                    sort=sort,
                ),
                "list",
                fields=field,
                all_fields=all_fields,
            )

    execute(state, operation)


@package_app.command("update")
def package_update(
    ctx: typer.Context,
    reference: str = typer.Argument(..., help="Package ID, name, or URL."),
    repo: Optional[str] = typer.Option(
        None,
        "--repo",
        "-r",
        help="Parent repository ID, name, or URL.",
    ),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="New name."),
    description: Optional[str] = typer.Option(
        None,
        "--description",
        "-d",
        help="New description.",
    ),
    author: Optional[str] = typer.Option(
        None,
        "--author",
        "-a",
        help="New author.",
    ),
    sync_package_id: Optional[int] = typer.Option(
        None,
        "--sync-package-id",
        help="New source package ID used for synchronization.",
    ),
) -> None:
    """Update a package."""

    state = cli_state(ctx)

    def operation() -> Any:
        write = PackageInput(
            name=name,
            description=description,
            author=author,
            sync_package_id=sync_package_id,
        )
        with build_client(state) as client:
            package = choose_package(client, reference, repo=repo)
            if state.dry_run:
                return {
                    "dry_run": True,
                    "action": "package.update",
                    "target": package,
                    "payload": write,
                }
            return client.packages.update(package.id, write)

    execute(state, operation)


@package_app.command("delete")
def package_delete(
    ctx: typer.Context,
    reference: str = typer.Argument(..., help="Package ID, name, or URL."),
    repo: Optional[str] = typer.Option(
        None,
        "--repo",
        "-r",
        help="Parent repository ID, name, or URL.",
    ),
) -> None:
    """Delete a package."""

    state = cli_state(ctx)

    def operation() -> Any:
        with build_client(state) as client:
            package = choose_package(client, reference, repo=repo)
            if state.dry_run:
                return {
                    "dry_run": True,
                    "action": "package.delete",
                    "target": package,
                }
            client.packages.delete(package.id)
            return {"deleted": True, "id": package.id}

    execute(state, operation)


@package_app.command("ensure")
def package_ensure(
    ctx: typer.Context,
    repo: str = typer.Option(
        ...,
        "--repo",
        "-r",
        help="Parent repository ID, name, or URL.",
    ),
    name: str = typer.Option(..., "--name", "-n", help="Package name."),
    description: Optional[str] = typer.Option(
        None,
        "--description",
        "-d",
        help="Package description.",
    ),
    author: Optional[str] = typer.Option(
        None,
        "--author",
        "-a",
        help="Package author.",
    ),
    sync_package_id: Optional[int] = typer.Option(
        None,
        "--sync-package-id",
        help="Source package ID used for synchronization.",
    ),
) -> None:
    """Create or update a package idempotently."""

    state = cli_state(ctx)

    def operation() -> Any:
        write = PackageInput(
            name=name,
            description=description,
            author=author,
            sync_package_id=sync_package_id,
        )
        with build_client(state) as client:
            if state.dry_run:
                try:
                    existing = client.packages.get(name, repository=repo)
                except RepkaNotFoundError:
                    action = "create"
                else:
                    action = (
                        "noop"
                        if package_matches_input(existing, write)
                        else "update"
                    )
                return {
                    "dry_run": True,
                    "action": f"package.ensure.{action}",
                    "repo": repo,
                    "payload": write,
                }
            return client.packages.ensure(repo, write)

    execute(state, operation)
