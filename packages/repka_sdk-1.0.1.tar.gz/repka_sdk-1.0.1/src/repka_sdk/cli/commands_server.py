from __future__ import annotations

from typing import Any
from typing import List
from typing import Optional

import typer

from ..config import BUILTIN_SOURCE
from ..config import DEFAULT_SERVER_NAME
from ..config import DOTENV_SERVER_NAME
from ..config import RESERVED_SERVER_NAMES
from ..config import default_server_config
from ..config import get_dotenv_server
from ..config import list_system_servers
from ..config import remove_dotenv_server
from ..config import remove_system_credentials
from ..config import remove_system_server
from ..config import rename_system_server
from ..config import resolve_configuration
from ..config import save_system_server
from ..config import set_default_server
from ..config import write_dotenv_server
from ..exceptions import RepkaConfigurationError
from ..exceptions import RepkaNotFoundError
from ..exceptions import RepkaValidationError
from ..models import RepositoryType
from ..models import ServerConfig
from .app import server_app
from .logic import build_client
from .logic import execute
from .logic import print_list
from .logic import result
from .logic import state as cli_state


@server_app.command("add")
def server_add(
    ctx: typer.Context,
    name: str = typer.Argument(..., help="Server configuration name."),
    url: str = typer.Argument(..., help="Server URL."),
    default: bool = typer.Option(
        False,
        "--default",
        "-d",
        help="Mark this server as the default.",
    ),
) -> None:
    """Add a system server to the local configuration."""

    state = cli_state(ctx)

    def operation() -> Any:
        if name in RESERVED_SERVER_NAMES:
            raise RepkaValidationError(f"Server name is reserved: {name}")
        server = ServerConfig(name=name, url=url, default=default)
        if state.dry_run:
            return {"dry_run": True, "action": "server.add", "server": server}
        save_system_server(server)
        return result(
            server,
            "message",
            message=f"Server '{server.name}' added: {server.url}",
        )

    execute(state, operation)


@server_app.command("set-url")
def server_set_url(
    ctx: typer.Context,
    name: str = typer.Argument(
        ...,
        help="Server name or reserved dotenv server.",
    ),
    url: str = typer.Argument(..., help="Server URL."),
    username: Optional[str] = typer.Option(
        None,
        "--username",
        "-u",
        help="Login saved with the server URL.",
    ),
) -> None:
    """Set or update a server URL."""

    state = cli_state(ctx)

    def operation() -> Any:
        if name == DEFAULT_SERVER_NAME:
            raise RepkaValidationError(
                "Built-in server 'nextgis' URL cannot be changed"
            )
        server = ServerConfig(name=name, url=url, username=username)
        if state.dry_run:
            return {
                "dry_run": True,
                "action": "server.set-url",
                "server": server,
            }
        if name == DOTENV_SERVER_NAME:
            write_dotenv_server(server)
            saved = ServerConfig(
                name=DOTENV_SERVER_NAME,
                url=url,
                default=True,
                username=username,
            )
            return result(
                saved,
                "message",
                message=f"Server '{saved.name}' URL set: {saved.url}",
            )
        existing = resolve_configuration(name)
        if existing.server is not None and existing.source == "system":
            server.default = existing.server.default
            if username is None:
                server.username = existing.server.username
        save_system_server(server)
        return result(
            server,
            "message",
            message=f"Server '{server.name}' URL set: {server.url}",
        )

    execute(state, operation)


@server_app.command("get-url")
def server_get_url(
    ctx: typer.Context,
    name: Optional[str] = typer.Argument(
        None,
        help="Server name, URL, nextgis, or dotenv. Uses --server/default when omitted.",
    ),
) -> None:
    """Print the resolved server URL."""

    state = cli_state(ctx)

    def operation() -> str:
        server_name = name or state.server_name
        resolved = resolve_configuration(server_name)
        if resolved.server is None:
            if server_name == DOTENV_SERVER_NAME:
                raise RepkaConfigurationError(
                    "Dotenv server is not configured; set REPKA_SERVER_URL in .env"
                )
            raise RepkaConfigurationError("Repka server is not configured")
        return resolved.server.url

    execute(state, operation)


@server_app.command("list")
def server_list(
    ctx: typer.Context,
    field: Optional[List[str]] = typer.Option(
        None,
        "--field",
        "-F",
        help="Table field to print. Can be repeated; use 'all' for every field.",
    ),
    all_fields: bool = typer.Option(
        False,
        "--all",
        help="Print all available table fields.",
    ),
) -> None:
    """List configured servers."""

    state = cli_state(ctx)
    execute(
        state,
        lambda: result(
            _list_servers_for_cli(),
            "list",
            fields=field,
            all_fields=all_fields,
        ),
    )


@server_app.command("status")
def server_status(ctx: typer.Context) -> None:
    """Show the selected/default server and healthcheck result."""

    state = cli_state(ctx)

    def operation() -> Any:
        resolved = resolve_configuration(state.server_name)
        if resolved.server is None:
            raise RepkaConfigurationError("Repka server is not configured")
        with build_client(state, resolved) as client:
            health = client.server.healthcheck()
        payload = {
            "name": resolved.server.name,
            "url": resolved.server.url,
            "source": resolved.source,
            "username": resolved.username or "",
            "credentials": bool(resolved.username and resolved.password),
            "health": health,
        }
        health_text = "ok"
        if isinstance(health, dict):
            health_text = str(
                health.get("status") or health.get("message") or "ok"
            )
        return result(
            payload,
            "message",
            message=(
                f"{payload['name']} ({payload['source']}): "
                f"{payload['url']} - {health_text}"
            ),
        )

    execute(state, operation)


@server_app.command("remote-version")
def server_remote_version(ctx: typer.Context) -> None:
    """Show the resolved Repka server version."""

    state = cli_state(ctx)

    def operation() -> Any:
        with build_client(state) as client:
            return client.server.version()

    execute(state, operation)


@server_app.command("options")
def server_options(ctx: typer.Context) -> None:
    """Show public options from the resolved Repka server."""

    state = cli_state(ctx)

    def operation() -> Any:
        with build_client(state) as client:
            return client.server.options()

    execute(state, operation)


@server_app.command("stats")
def server_stats(ctx: typer.Context) -> None:
    """Show statistics from the resolved Repka server."""

    state = cli_state(ctx)

    def operation() -> Any:
        with build_client(state) as client:
            return client.server.stats()

    execute(state, operation)


@server_app.command("remote-repos")
def server_remote_repos(
    ctx: typer.Context,
    repository_type: Optional[str] = typer.Argument(
        None,
        help="Repository type: any, ubuntu, docker, borsch, installer, qgis, maven.",
    ),
    field: Optional[List[str]] = typer.Option(
        None,
        "--field",
        "-F",
        help="Table field to print. Can be repeated; use 'all' for every field.",
    ),
    all_fields: bool = typer.Option(
        False,
        "--all",
        help="Print all available table fields.",
    ),
) -> None:
    """List remote repositories available for synchronization."""

    state = cli_state(ctx)

    def operation() -> Any:
        selected_type = repository_type or _prompt_repository_type()
        with build_client(state) as client:
            return result(
                client.sync.list_remote_repositories(selected_type),
                "list",
                fields=field,
                all_fields=all_fields,
            )

    execute(state, operation)


@server_app.command("remote-packages")
def server_remote_packages(
    ctx: typer.Context,
    repository_type: Optional[str] = typer.Argument(
        None,
        help="Repository type: any, ubuntu, docker, borsch, installer, qgis, maven.",
    ),
    repository: Optional[str] = typer.Argument(
        None,
        help="Remote repository identifier.",
    ),
    field: Optional[List[str]] = typer.Option(
        None,
        "--field",
        "-F",
        help="Table field to print. Can be repeated; use 'all' for every field.",
    ),
    all_fields: bool = typer.Option(
        False,
        "--all",
        help="Print all available table fields.",
    ),
) -> None:
    """List remote packages available for synchronization."""

    state = cli_state(ctx)

    def operation() -> Any:
        selected_type = repository_type or _prompt_repository_type()
        with build_client(state) as client:
            selected_repository = repository
            if selected_repository is None:
                remote_repositories = client.sync.list_remote_repositories(
                    selected_type
                )
                selected_repository = _choose_remote_item(
                    remote_repositories,
                    "repository",
                )
            return result(
                client.sync.list_remote_packages(
                    selected_type,
                    selected_repository,
                ),
                "list",
                fields=field,
                all_fields=all_fields,
            )

    execute(state, operation)


@server_app.command("remove")
def server_remove(
    ctx: typer.Context,
    name: str = typer.Argument(..., help="Server configuration name."),
) -> None:
    """Remove a configured server."""

    state = cli_state(ctx)

    def operation() -> Any:
        if state.dry_run:
            return {"dry_run": True, "action": "server.remove", "name": name}
        if name == DEFAULT_SERVER_NAME:
            raise RepkaValidationError(
                "Built-in server 'nextgis' cannot be removed"
            )
        if name == DOTENV_SERVER_NAME:
            remove_dotenv_server()
            return result(
                {"removed": True, "server": DOTENV_SERVER_NAME},
                "message",
                message="Server 'dotenv' removed",
            )
        try:
            remove_system_credentials(name)
            removed = remove_system_server(name)
        except ValueError as exc:
            raise RepkaConfigurationError(str(exc)) from exc
        return result(
            {"removed": True, "server": removed},
            "message",
            message=f"Server '{removed.name}' removed",
        )

    execute(state, operation)


@server_app.command("rename")
def server_rename(
    ctx: typer.Context,
    old_name: str = typer.Argument(..., help="Current server name."),
    new_name: str = typer.Argument(..., help="New server name."),
) -> None:
    """Rename a configured server."""

    state = cli_state(ctx)

    def operation() -> Any:
        if (
            old_name in RESERVED_SERVER_NAMES
            or new_name in RESERVED_SERVER_NAMES
        ):
            raise RepkaValidationError(
                "Reserved server names cannot be renamed"
            )
        if state.dry_run:
            return {
                "dry_run": True,
                "action": "server.rename",
                "old_name": old_name,
                "new_name": new_name,
            }
        try:
            renamed = rename_system_server(old_name, new_name)
        except ValueError as exc:
            raise RepkaConfigurationError(str(exc)) from exc
        return result(
            renamed,
            "message",
            message=f"Server '{old_name}' renamed to '{new_name}'",
        )

    execute(state, operation)


@server_app.command("set-default")
def server_set_default(
    ctx: typer.Context,
    name: str = typer.Argument(..., help="Server configuration name."),
) -> None:
    """Select the default configured server."""

    state = cli_state(ctx)

    def operation() -> Any:
        if name == DOTENV_SERVER_NAME:
            raise RepkaValidationError(
                "Dotenv server is selected with --server, not set-default"
            )
        if state.dry_run:
            return {
                "dry_run": True,
                "action": "server.set-default",
                "name": name,
            }
        selected = set_default_server(name)
        return result(
            selected,
            "message",
            message=f"Server '{selected.name}' is now default",
        )

    execute(state, operation)


def _list_servers_for_cli() -> List[dict[str, Any]]:
    resolved_default = resolve_configuration()

    def is_default(name: str, url: str, source: str) -> bool:
        if (
            resolved_default.server is None
            or resolved_default.source != source
        ):
            return False
        return (
            resolved_default.server.name == name
            or resolved_default.server.url == url
        )

    rows: List[dict[str, Any]] = [
        {
            "name": DEFAULT_SERVER_NAME,
            "url": default_server_config().url,
            "source": BUILTIN_SOURCE,
            "default": is_default(
                DEFAULT_SERVER_NAME,
                default_server_config().url,
                BUILTIN_SOURCE,
            ),
            "username": "",
        }
    ]
    dotenv_server = get_dotenv_server()
    if dotenv_server is not None:
        rows.append(
            {
                "name": DOTENV_SERVER_NAME,
                "url": dotenv_server.url,
                "source": "dotenv",
                "default": is_default(
                    DOTENV_SERVER_NAME,
                    dotenv_server.url,
                    "dotenv",
                ),
                "username": dotenv_server.username or "",
            }
        )
    for server in list_system_servers():
        if server.name in RESERVED_SERVER_NAMES:
            for row in rows:
                if row["name"] == server.name:
                    row["username"] = server.username or row["username"]
                    row["source"] = "system"
                    row["default"] = is_default(
                        server.name, server.url, "system"
                    )
                    break
            continue
        rows.append(
            {
                "name": server.name,
                "url": server.url,
                "source": "system",
                "default": is_default(server.name, server.url, "system"),
                "username": server.username or "",
            }
        )
    return rows


def _prompt_repository_type() -> str:
    options = ", ".join(item.slug for item in RepositoryType)
    typer.echo(f"Repository types: {options}")
    return typer.prompt("Repository type", default=RepositoryType.BORSCH.slug)


def _choose_remote_item(items: Any, label: str) -> str:
    if not isinstance(items, list) or not items:
        raise RepkaNotFoundError(f"Remote {label} not found")
    if len(items) == 1:
        return _remote_item_reference(items[0])
    print_list(items)
    default = _remote_item_reference(items[0])
    return typer.prompt(f"Select remote {label}", default=default)


def _remote_item_reference(item: Any) -> str:
    if isinstance(item, dict):
        for key in ["id", "name", "key", "repository", "repo", "value"]:
            value = item.get(key)
            if value not in {None, ""}:
                return str(value)
    return str(item)
