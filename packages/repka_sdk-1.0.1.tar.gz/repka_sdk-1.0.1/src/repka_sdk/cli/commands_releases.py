from __future__ import annotations

from pathlib import Path
from typing import Any
from typing import List
from typing import Optional

import typer

from ..exceptions import RepkaValidationError
from ..models import ReleaseInput
from ..models import normalize_tags
from ..services.common import add_latest_tag
from .app import release_app
from .logic import build_client
from .logic import choose_package
from .logic import choose_release
from .logic import collect_release_assets
from .logic import execute
from .logic import parse_release_options
from .logic import result
from .logic import state as cli_state


@release_app.command("create")
def release_create(
    ctx: typer.Context,
    package: str = typer.Option(
        ...,
        "--package",
        "-p",
        help="Parent package ID, name, or URL.",
    ),
    name: str = typer.Option(..., "--name", "-n", help="Release name."),
    description: Optional[str] = typer.Option(
        None,
        "--description",
        "-d",
        help="Release description.",
    ),
    tag: Optional[List[str]] = typer.Option(
        None,
        "--tag",
        "-g",
        help="Release tag. Can be repeated.",
    ),
    latest: bool = typer.Option(
        False,
        "--latest",
        "-l",
        help="Add the special latest tag.",
    ),
    option: Optional[List[str]] = typer.Option(
        None,
        "--option",
        "-o",
        help="Release option as key=value or key:value.",
    ),
    file: Optional[List[Path]] = typer.Option(
        None,
        "--file",
        "-F",
        help="Local file to upload into the release. Can be repeated.",
    ),
    uploaded: Optional[List[str]] = typer.Option(
        None,
        "--uploaded",
        "-u",
        help="Uploaded asset as upload_name:name[:description].",
    ),
    version_tag: Optional[str] = typer.Option(
        None,
        "--version-tag",
        "-V",
        help="Release version tag.",
    ),
) -> None:
    """Create a release."""

    state = cli_state(ctx)

    def operation() -> Any:
        with build_client(state) as client:
            tags = normalize_tags(tag)
            if latest and not tags and version_tag:
                tags = [version_tag]
            if latest:
                tags = add_latest_tag(tags)
            assets = collect_release_assets(client, file, uploaded)
            write = ReleaseInput(
                name=name,
                description=description,
                tags=tags or None,
                options=parse_release_options(option),
                assets=assets,
            )
            if state.dry_run:
                return {
                    "dry_run": True,
                    "action": "release.create",
                    "package": package,
                    "payload": write,
                }
            return client.releases.create(
                package, write, version_tag=version_tag
            )

    execute(state, operation)


@release_app.command("get")
def release_get(
    ctx: typer.Context,
    reference: Optional[str] = typer.Argument(
        None,
        help="Release ID, name, or URL. Omit to choose interactively.",
    ),
    package: Optional[str] = typer.Option(
        None,
        "--package",
        "-p",
        help="Parent package ID, name, or URL.",
    ),
    repo: Optional[str] = typer.Option(
        None,
        "--repo",
        "-r",
        help="Parent repository ID, name, or URL.",
    ),
) -> None:
    """Show a release."""

    state = cli_state(ctx)

    def operation() -> Any:
        with build_client(state) as client:
            release = choose_release(
                client,
                reference,
                package=package,
                repo=repo,
            )
            return client.releases.get(
                release.id,
                package=package,
                repository=repo,
            )

    execute(state, operation)


@release_app.command("list")
def release_list(
    ctx: typer.Context,
    package: Optional[str] = typer.Option(
        None,
        "--package",
        "-p",
        help="Package ID, name, or URL. Required; prompted when omitted.",
    ),
    repo: Optional[str] = typer.Option(
        None,
        "--repo",
        "-r",
        help="Parent repository ID, name, or URL.",
    ),
    filter_text: Optional[str] = typer.Option(
        None,
        "--filter",
        "-f",
        help="Text filter applied by the Repka API.",
    ),
    sort: Optional[str] = typer.Option(
        None,
        "--sort",
        "-S",
        help="Sort expression accepted by the Repka API, for example name or -name.",
    ),
    tag: Optional[List[str]] = typer.Option(
        None,
        "--tag",
        "-g",
        help="Release tag filter. Can be repeated.",
    ),
    option: Optional[List[str]] = typer.Option(
        None,
        "--option",
        "-o",
        help="Release option as key=value or key:value.",
    ),
    field: Optional[List[str]] = typer.Option(
        None,
        "--field",
        "-F",
        help="Table field to print. Can be repeated; use 'all' for every field.",
    ),
    all_fields: bool = typer.Option(
        False,
        "--all",
        help="Print all available table fields.",
    ),
) -> None:
    """List releases."""

    state = cli_state(ctx)

    def operation() -> Any:
        with build_client(state) as client:
            selected_package = package or choose_package(client, repo=repo)
            return result(
                client.releases.list(
                    package=selected_package,
                    repository=repo,
                    filter_text=filter_text,
                    sort=sort,
                    tags=tag,
                    options=parse_release_options(option),
                ),
                "list",
                fields=field,
                all_fields=all_fields,
            )

    execute(state, operation)


@release_app.command("update")
def release_update(
    ctx: typer.Context,
    reference: str = typer.Argument(..., help="Release ID, name, or URL."),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="New name."),
    description: Optional[str] = typer.Option(
        None,
        "--description",
        "-d",
        help="New description.",
    ),
    tag: Optional[List[str]] = typer.Option(
        None,
        "--tag",
        "-g",
        help="Replacement release tag. Can be repeated.",
    ),
    latest: bool = typer.Option(
        False,
        "--latest",
        "-l",
        help="Add or keep the special latest tag.",
    ),
    option: Optional[List[str]] = typer.Option(
        None,
        "--option",
        "-o",
        help="Release option as key=value or key:value.",
    ),
    version_tag: Optional[str] = typer.Option(
        None,
        "--version-tag",
        "-V",
        help="Release version tag.",
    ),
) -> None:
    """Update a release."""

    state = cli_state(ctx)

    def operation() -> Any:
        write = ReleaseInput(
            name=name,
            description=description,
            options=parse_release_options(option),
        )
        with build_client(state) as client:
            release = client.releases.get(reference)
            tags = normalize_tags(tag)
            if latest and not tags and version_tag:
                tags = [version_tag]
            if latest:
                tags = add_latest_tag(tags or release.tags)
            if tags:
                write.tags = tags
            if state.dry_run:
                return {
                    "dry_run": True,
                    "action": "release.update",
                    "target": release,
                    "payload": write,
                }
            return client.releases.update(
                release.id, write, version_tag=version_tag
            )

    execute(state, operation)


@release_app.command("delete")
def release_delete(
    ctx: typer.Context,
    reference: str = typer.Argument(..., help="Release ID, name, or URL."),
) -> None:
    """Delete a release."""

    state = cli_state(ctx)

    def operation() -> Any:
        with build_client(state) as client:
            release = client.releases.get(reference)
            if state.dry_run:
                return {
                    "dry_run": True,
                    "action": "release.delete",
                    "target": release,
                }
            client.releases.delete(release.id)
            return {"deleted": True, "id": release.id}

    execute(state, operation)


@release_app.command("ensure")
def release_ensure(
    ctx: typer.Context,
    package: str = typer.Option(
        ...,
        "--package",
        "-p",
        help="Parent package ID, name, or URL.",
    ),
    name: str = typer.Option(..., "--name", "-n", help="Release name."),
    description: Optional[str] = typer.Option(
        None,
        "--description",
        "-d",
        help="Release description.",
    ),
    tag: Optional[List[str]] = typer.Option(
        None,
        "--tag",
        "-g",
        help="Release tag. Can be repeated.",
    ),
    latest: bool = typer.Option(
        False,
        "--latest",
        "-l",
        help="Add the special latest tag.",
    ),
    option: Optional[List[str]] = typer.Option(
        None,
        "--option",
        "-o",
        help="Release option as key=value or key:value.",
    ),
    file: Optional[List[Path]] = typer.Option(
        None,
        "--file",
        "-F",
        help="Local file to upload into the release. Can be repeated.",
    ),
    uploaded: Optional[List[str]] = typer.Option(
        None,
        "--uploaded",
        "-u",
        help="Uploaded asset as upload_name:name[:description].",
    ),
    version_tag: Optional[str] = typer.Option(
        None,
        "--version-tag",
        "-V",
        help="Version tag used to find an existing release.",
    ),
    enrich_assets: bool = typer.Option(
        False,
        "--enrich-assets",
        help=(
            "Keep existing assets with other names and replace assets with "
            "matching names."
        ),
    ),
) -> None:
    """Create or update a release idempotently."""

    state = cli_state(ctx)

    def operation() -> Any:
        with build_client(state) as client:
            tags = normalize_tags(tag)
            if latest and not tags:
                if not version_tag:
                    raise RepkaValidationError(
                        "--latest without --tag requires --version-tag"
                    )
                tags = [version_tag]
            if latest:
                tags = add_latest_tag(tags)
            assets = collect_release_assets(client, file, uploaded)
            write = ReleaseInput(
                name=name,
                description=description,
                tags=tags or None,
                options=parse_release_options(option),
                assets=assets,
            )
            if state.dry_run:
                return {
                    "dry_run": True,
                    "action": "release.ensure",
                    "package": package,
                    "payload": write,
                    "version_tag": version_tag,
                    "enrich_assets": enrich_assets,
                }
            return client.releases.ensure(
                package,
                write,
                version_tag=version_tag,
                enrich_assets=enrich_assets,
            )

    execute(state, operation)


@release_app.command("replace")
def release_replace(
    ctx: typer.Context,
    reference: str = typer.Argument(..., help="Release ID, name, or URL."),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="New name."),
    description: Optional[str] = typer.Option(
        None,
        "--description",
        "-d",
        help="New description.",
    ),
    tag: Optional[List[str]] = typer.Option(
        None,
        "--tag",
        "-g",
        help="Replacement release tag. Can be repeated.",
    ),
    latest: bool = typer.Option(
        False,
        "--latest",
        "-l",
        help="Add the special latest tag.",
    ),
    option: Optional[List[str]] = typer.Option(
        None,
        "--option",
        "-o",
        help="Release option as key=value or key:value.",
    ),
    file: Optional[List[Path]] = typer.Option(
        None,
        "--file",
        "-F",
        help="Local file to upload into the release. Can be repeated.",
    ),
    uploaded: Optional[List[str]] = typer.Option(
        None,
        "--uploaded",
        "-u",
        help="Uploaded asset as upload_name:name[:description].",
    ),
    version_tag: Optional[str] = typer.Option(
        None,
        "--version-tag",
        "-V",
        help="Release version tag.",
    ),
) -> None:
    """Replace release metadata and assets."""

    state = cli_state(ctx)

    def operation() -> Any:
        with build_client(state) as client:
            tags = normalize_tags(tag)
            if latest and not tags and version_tag:
                tags = [version_tag]
            if latest:
                tags = add_latest_tag(tags)
            assets = collect_release_assets(client, file, uploaded)
            write = ReleaseInput(
                name=name,
                description=description,
                tags=tags or None,
                options=parse_release_options(option),
                assets=assets,
            )
            release = client.releases.get(reference)
            if state.dry_run:
                return {
                    "dry_run": True,
                    "action": "release.replace",
                    "target": release,
                    "payload": write,
                }
            return client.releases.replace(
                release.id, write, version_tag=version_tag
            )

    execute(state, operation)


@release_app.command("add-assets")
def release_add_assets(
    ctx: typer.Context,
    reference: str = typer.Argument(..., help="Release ID, name, or URL."),
    file: Optional[List[Path]] = typer.Option(
        None,
        "--file",
        "-F",
        help="Local file to upload into the release. Can be repeated.",
    ),
    uploaded: Optional[List[str]] = typer.Option(
        None,
        "--uploaded",
        "-u",
        help="Uploaded asset as upload_name:name[:description].",
    ),
) -> None:
    """Append assets to a release."""

    state = cli_state(ctx)

    def operation() -> Any:
        with build_client(state) as client:
            assets = collect_release_assets(client, file, uploaded)
            if not assets:
                raise RepkaValidationError("At least one asset is required")
            release = client.releases.get(reference)
            if state.dry_run:
                return {
                    "dry_run": True,
                    "action": "release.add-assets",
                    "target": release,
                    "assets": assets,
                }
            return client.releases.add_assets(release.id, assets)

    execute(state, operation)
