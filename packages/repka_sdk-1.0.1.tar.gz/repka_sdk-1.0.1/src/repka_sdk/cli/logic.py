from __future__ import annotations

import json
import textwrap
import sys
from dataclasses import dataclass
from dataclasses import is_dataclass
from pathlib import Path
from typing import Any
from typing import Callable
from typing import Dict
from typing import List
from typing import Optional
from typing import Sequence
from typing import Union

import typer

from ..auth import BasicAuthProvider
from ..client import RepkaClient
from ..config import ResolvedConfiguration
from ..config import DOTENV_SERVER_NAME
from ..config import resolve_configuration
from ..exceptions import RepkaAmbiguousResultError
from ..exceptions import RepkaAuthError
from ..exceptions import RepkaConfigurationError
from ..exceptions import RepkaConflictError
from ..exceptions import RepkaError
from ..exceptions import RepkaNotFoundError
from ..exceptions import RepkaServerError
from ..exceptions import RepkaTransportError
from ..exceptions import RepkaValidationError
from ..models import Asset
from ..models import AuthStatus
from ..models import Package
from ..models import Permission
from ..models import Release
from ..models import ReleaseAssetInput
from ..models import ReleaseOptions
from ..models import Repository
from ..models import ServerConfig
from ..models import UploadedAsset
from ..models import UserInfo
from ..models import normalize_asset_inputs
from ..models import to_primitive


@dataclass
class CLIContext:
    """Runtime options shared by CLI commands."""

    server_name: Optional[str]
    json_output: bool
    timeout: float
    verify: bool
    verbose: bool
    dry_run: bool


@dataclass
class CommandResult:
    """CLI command result with rendering mode metadata."""

    value: Any
    mode: str = "detail"
    options: Dict[str, Any] = None


def result(
    value: Any,
    mode: str = "detail",
    **options: Any,
) -> CommandResult:
    """Wrap a command result for CLI rendering."""

    return CommandResult(value=value, mode=mode, options=options)


def state(ctx: typer.Context) -> CLIContext:
    """Return the active CLI context."""

    return ctx.obj


def print_value(
    cli_state: CLIContext, value: Any, mode: str = "detail"
) -> None:
    """Print a command result in JSON, list, or detail format."""

    options: Dict[str, Any] = {}
    if isinstance(value, CommandResult):
        mode = value.mode
        options = value.options or {}
        value = value.value
    if value is None:
        return
    if cli_state.json_output:
        typer.echo(
            json.dumps(to_primitive(value), indent=2, ensure_ascii=False)
        )
        return

    if mode == "message":
        typer.echo(str(options.get("message") or value))
        return
    if mode == "list" and isinstance(value, list):
        _print_list(
            value,
            fields=options.get("fields"),
            all_fields=bool(options.get("all_fields", False)),
        )
        return
    if mode == "detail":
        _print_detail(value, options=options)
        return
    if isinstance(value, str):
        typer.echo(value)
        return
    typer.echo(json.dumps(to_primitive(value), indent=2, ensure_ascii=False))


def error_payload(error: RepkaError) -> Dict[str, Any]:
    """Build a JSON-serializable error payload."""

    return {
        "error": True,
        "type": error.__class__.__name__,
        "message": error.message,
        "details": error.details,
    }


def exit_code(error: RepkaError) -> int:
    """Return the CLI exit code for a Repka error."""

    if isinstance(error, (RepkaAuthError, RepkaConfigurationError)):
        return 3
    if isinstance(error, RepkaNotFoundError):
        return 4
    if isinstance(error, (RepkaAmbiguousResultError, RepkaConflictError)):
        return 5
    if isinstance(error, RepkaValidationError):
        return 6
    if isinstance(error, (RepkaTransportError, RepkaServerError)):
        return 10
    return 2


def fail(cli_state: CLIContext, error: RepkaError) -> None:
    """Print an error and stop command execution."""

    if cli_state.json_output:
        typer.echo(
            json.dumps(error_payload(error), indent=2, ensure_ascii=False)
        )
    else:
        typer.echo(error.message, err=True)
    raise typer.Exit(code=exit_code(error))


def execute(
    cli_state: CLIContext,
    callback: Callable[[], Any],
    *,
    mode: str = "detail",
) -> None:
    """Run a command callback and render the result."""

    try:
        value = callback()
    except RepkaError as error:
        fail(cli_state, error)
    if isinstance(value, CommandResult):
        print_value(cli_state, value)
    else:
        print_value(cli_state, value, mode=mode)


def resolve_runtime_configuration(
    cli_state: CLIContext,
) -> ResolvedConfiguration:
    """Resolve configuration for a CLI command."""

    resolved = resolve_configuration(cli_state.server_name)
    if resolved.server is None:
        if cli_state.server_name == "dotenv":
            raise RepkaConfigurationError(
                "Dotenv server is not configured; set REPKA_SERVER_URL in .env"
            )
        raise RepkaConfigurationError("Repka server is not configured")
    return resolved


def build_client(
    cli_state: CLIContext,
    resolved: Optional[ResolvedConfiguration] = None,
) -> RepkaClient:
    """Build a Repka client from CLI state and resolved configuration."""

    config = resolved or resolve_runtime_configuration(cli_state)
    auth_provider = None
    if config.username and config.password:
        auth_provider = BasicAuthProvider(config.username, config.password)
    return RepkaClient(
        config.server.url,
        auth_provider=auth_provider,
        timeout=cli_state.timeout,
        verify=cli_state.verify,
    )


def parse_permissions(values: Optional[Sequence[str]]) -> List[Permission]:
    """Parse CLI permission values."""

    permissions: List[Permission] = []
    for value in values or []:
        try:
            identifier, permission_type = value.split(":", 1)
        except ValueError as exc:
            raise RepkaValidationError(
                f"Invalid permission format: {value}"
            ) from exc
        permissions.append(
            Permission(id=int(identifier), type=int(permission_type))
        )
    return permissions


def parse_release_options(
    values: Optional[Sequence[str]],
) -> Optional[ReleaseOptions]:
    """Parse CLI release option values."""

    if not values:
        return None
    normalized: Dict[str, str] = {}
    for value in values:
        if "=" in value:
            key, option_value = value.split("=", 1)
        elif ":" in value:
            key, option_value = value.split(":", 1)
        else:
            raise RepkaValidationError(f"Invalid option format: {value}")
        normalized[key] = option_value
    return ReleaseOptions(normalized)


def parse_uploaded_assets(
    values: Optional[Sequence[str]],
) -> List[ReleaseAssetInput]:
    """Parse uploaded asset references from CLI values."""

    assets: List[ReleaseAssetInput] = []
    for value in values or []:
        parts = value.split(":", 2)
        if len(parts) < 2:
            raise RepkaValidationError(
                f"Invalid uploaded asset format: {value}"
            )
        upload_name = parts[0]
        name = parts[1]
        description = parts[2] if len(parts) > 2 else ""
        assets.append(
            ReleaseAssetInput(
                upload_name=upload_name,
                name=name,
                description=description,
            )
        )
    return assets


def collect_release_assets(
    client: RepkaClient,
    files: Optional[Sequence[Path]],
    uploaded: Optional[Sequence[str]],
) -> Optional[List[ReleaseAssetInput]]:
    """Collect release asset inputs from uploaded tokens and local files."""

    assets = parse_uploaded_assets(uploaded)
    if files:
        uploaded_assets = client.assets.upload_many(files)
        assets.extend(normalize_asset_inputs(uploaded_assets) or [])
    return assets or None


def build_auth_status(
    resolved: ResolvedConfiguration,
    user: Optional[UserInfo],
) -> AuthStatus:
    """Build an authentication status model for CLI output."""

    authenticated = user is not None and user.login.lower() != "guest"
    return AuthStatus(
        server=resolved.server,
        source=resolved.source,
        username=resolved.username,
        authenticated=authenticated,
        user=user,
    )


def resolve_server_for_login(
    cli_state: CLIContext,
    *,
    name: Optional[str],
    url: Optional[str],
    source: str = "system",
) -> ServerConfig:
    """Resolve or prompt for the server used by login."""

    if source == "dotenv":
        resolved = resolve_configuration(name or DOTENV_SERVER_NAME)
        if not url:
            if resolved.server:
                url = resolved.server.url
            else:
                url = typer.prompt("Server URL")
        return ServerConfig(name=DOTENV_SERVER_NAME, url=url, default=True)

    if name == DOTENV_SERVER_NAME:
        raise RepkaValidationError(
            "The dotenv server stores credentials in .env"
        )

    initial = resolve_configuration(name or cli_state.server_name)
    if not name:
        default_name = initial.server.name if initial.server else "default"
        name = typer.prompt("Server name", default=default_name)
    if not url:
        if initial.server and name == initial.server.name:
            url = initial.server.url
        else:
            resolved = resolve_configuration(name or cli_state.server_name)
            if resolved.server:
                url = resolved.server.url
            else:
                url = typer.prompt("Server URL")
    return ServerConfig(name=name, url=url, default=False)


def password_value(password: Optional[str], password_stdin: bool) -> str:
    """Return a password from CLI option, stdin, or interactive prompt."""

    if password_stdin:
        return sys.stdin.read().strip()
    if password:
        return password
    return typer.prompt("Password", hide_input=True)


def prompt_required(value: Optional[str], label: str) -> str:
    """Prompt for a required string value when it was omitted."""

    if value:
        return value
    return typer.prompt(label)


def choose_repository(
    client: RepkaClient,
    reference: Optional[str] = None,
) -> Repository:
    """Return a repository, prompting when a reference is absent or ambiguous."""

    if reference and (reference.isdigit() or reference.startswith("http")):
        return client.repositories.get(reference)
    repositories = client.repositories.list(filter_text=reference)
    if reference:
        exact = _exact_name_matches(repositories, reference)
        if len(exact) == 1:
            return exact[0]
        if len(exact) > 1:
            return choose_from_list(exact, "repository")
        return client.repositories.get(reference)
    return choose_from_list(repositories, "repository")


def choose_package(
    client: RepkaClient,
    reference: Optional[str] = None,
    *,
    repo: Optional[Union[str, Repository]] = None,
) -> Package:
    """Return a package, prompting for parent repository when needed."""

    if reference and (reference.isdigit() or reference.startswith("http")):
        return client.packages.get(reference, repository=repo)
    resolved_repo = repo or choose_repository(client)
    packages = client.packages.list(
        repository=resolved_repo,
        filter_text=reference,
    )
    if reference:
        exact = _exact_name_matches(packages, reference)
        if len(exact) == 1:
            return exact[0]
        if len(exact) > 1:
            return choose_from_list(exact, "package")
        return client.packages.get(reference, repository=resolved_repo)
    return choose_from_list(packages, "package")


def choose_release(
    client: RepkaClient,
    reference: Optional[str] = None,
    *,
    package: Optional[Union[str, Package]] = None,
    repo: Optional[Union[str, Repository]] = None,
) -> Release:
    """Return a release, prompting for parent package when needed."""

    if reference and (reference.isdigit() or reference.startswith("http")):
        return client.releases.get(reference, package=package, repository=repo)
    resolved_package = package or choose_package(client, repo=repo)
    releases = client.releases.list(
        package=resolved_package,
        repository=repo,
        filter_text=reference,
    )
    if reference:
        exact = _exact_name_matches(releases, reference)
        if len(exact) == 1:
            return exact[0]
        if len(exact) > 1:
            return choose_from_list(exact, "release")
        return client.releases.get(
            reference,
            package=resolved_package,
            repository=repo,
        )
    return choose_from_list(releases, "release", prompt_single=True)


def choose_from_list(
    items: Sequence[Any],
    label: str,
    *,
    prompt_single: bool = False,
) -> Any:
    """Prompt for one item from a non-empty sequence."""

    if not items:
        raise RepkaNotFoundError(f"{label.capitalize()} not found")
    if len(items) == 1 and not prompt_single:
        return items[0]
    _print_list(items)
    first_id = getattr(items[0], "id", None)
    selected = typer.prompt(
        f"Select {label} id",
        type=int,
        default=first_id,
    )
    for item in items:
        if getattr(item, "id", None) == selected:
            typer.echo()
            return item
    raise RepkaValidationError(f"Invalid {label} id")


def print_list(
    values: Sequence[Any],
    *,
    fields: Optional[Sequence[str]] = None,
    all_fields: bool = False,
) -> None:
    """Print a list with the standard CLI table renderer."""

    _print_list(values, fields=fields, all_fields=all_fields)


def _print_list(
    values: Sequence[Any],
    *,
    fields: Optional[Sequence[str]] = None,
    all_fields: bool = False,
) -> None:
    if not values:
        return
    sorted_values = _sort_list_values(values)
    selected_fields = _list_fields(sorted_values, fields, all_fields)
    if selected_fields:
        _print_table(sorted_values, selected_fields)
        return
    for item in sorted_values:
        _print_detail(item)


def _sort_list_values(values: Sequence[Any]) -> List[Any]:
    items = list(values)
    first = items[0]
    if isinstance(first, Repository):
        return sorted(
            items,
            key=lambda item: (
                item.type.slug,
                item.name.casefold(),
                item.id,
            ),
        )
    if isinstance(first, Package):
        return sorted(items, key=lambda item: (item.name.casefold(), item.id))
    if isinstance(first, Release):
        return sorted(items, key=lambda item: item.id)
    return items


def _list_fields(
    values: Sequence[Any],
    requested: Optional[Sequence[str]],
    all_fields: bool,
) -> List[str]:
    requested_fields = _requested_field_names(requested)
    if "all" in requested_fields:
        all_fields = True
        requested_fields = [
            field for field in requested_fields if field != "all"
        ]
    if requested_fields:
        return requested_fields
    if all_fields:
        return _all_field_names(values)
    first = values[0]
    if isinstance(first, Repository):
        return ["id", "type", "name", "description"]
    if isinstance(first, Package):
        return ["id", "name", "description"]
    if isinstance(first, Release):
        return ["id", "name", "tags", "downloads"]
    if isinstance(first, Asset):
        return ["id", "name", "description", "size", "downloads"]
    if isinstance(first, UploadedAsset):
        return ["upload_name", "name", "description"]
    if isinstance(first, ServerConfig):
        return ["name", "url", "default", "username"]
    if isinstance(first, dict):
        return list(_flatten_table_item(first).keys())
    if is_dataclass(first):
        return list(_flatten_table_item(first).keys())
    return []


def _requested_field_names(
    requested: Optional[Sequence[str]],
) -> List[str]:
    fields: List[str] = []
    for value in requested or []:
        for field in str(value).split(","):
            normalized = field.strip()
            if normalized:
                fields.append(normalized)
    return fields


def _all_field_names(values: Sequence[Any]) -> List[str]:
    names: List[str] = []
    for item in values:
        for name in _flatten_table_item(item).keys():
            if name not in names:
                names.append(name)
    return names


def _print_table(values: Sequence[Any], field_names: Sequence[str]) -> None:
    rows = []
    for item in values:
        flattened = _flatten_table_item(item)
        rows.append(
            [_format_cell(flattened.get(field)) for field in field_names]
        )

    widths = [
        _table_column_width(
            str(field),
            [row[index] for row in rows],
        )
        for index, field in enumerate(field_names)
    ]
    typer.secho(_format_row(field_names, widths), bold=True)
    for row in rows:
        typer.echo(_format_wrapped_row(row, widths))


def _table_column_width(header: str, values: Sequence[str]) -> int:
    natural = max(len(header), *(len(value) for value in values))
    cap = 40
    if header.endswith("description") or header == "description":
        cap = 72
    elif header in {"name", "url"}:
        cap = 32
    elif header in {"id", "type", "downloads", "size"}:
        cap = 12
    return max(len(header), min(natural, cap))


def _format_row(values: Sequence[Any], widths: Sequence[int]) -> str:
    return "  ".join(
        str(value).ljust(width) for value, width in zip(values, widths)
    )


def _format_wrapped_row(values: Sequence[str], widths: Sequence[int]) -> str:
    wrapped = [
        _wrap_cell(value, width) for value, width in zip(values, widths)
    ]
    height = max(len(cell_lines) for cell_lines in wrapped)
    lines = []
    for line_index in range(height):
        line_values = [
            cell_lines[line_index] if line_index < len(cell_lines) else ""
            for cell_lines in wrapped
        ]
        lines.append(_format_row(line_values, widths).rstrip())
    return "\n".join(lines)


def _wrap_cell(value: str, width: int) -> List[str]:
    if not value:
        return [""]
    wrapped = textwrap.wrap(
        value,
        width=width,
        break_long_words=False,
        break_on_hyphens=False,
    )
    return wrapped or [""]


def _format_cell(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, list):
        if all(not isinstance(item, (dict, list)) for item in value):
            return ",".join(_format_tag(str(item)) for item in value)
        return str(len(value))
    if isinstance(value, dict):
        return str(len(value))
    return str(value)


def _flatten_table_item(item: Any) -> Dict[str, Any]:
    primitive = to_primitive(item)
    if not isinstance(primitive, dict):
        return {"value": primitive}
    flattened: Dict[str, Any] = {}
    for key, value in primitive.items():
        _flatten_table_value(flattened, key, value)
    return flattened


def _flatten_table_value(
    flattened: Dict[str, Any],
    name: str,
    value: Any,
) -> None:
    if isinstance(value, dict):
        if not value:
            flattened[name] = 0
            return
        for child_name, child_value in value.items():
            _flatten_table_value(
                flattened, f"{name}.{child_name}", child_value
            )
        return
    if isinstance(value, list):
        if _list_should_be_counted(name, value):
            flattened[name] = len(value)
        else:
            flattened[name] = value
        return
    flattened[name] = value


def _list_should_be_counted(name: str, value: Sequence[Any]) -> bool:
    if name in {"assets", "files", "packages", "permissions", "releases"}:
        return True
    return any(isinstance(item, (dict, list)) for item in value)


def _format_tag(value: str) -> str:
    if value == "latest":
        return "[latest]"
    return value


def _print_detail(
    value: Any,
    *,
    options: Optional[Dict[str, Any]] = None,
) -> None:
    if isinstance(value, str):
        typer.echo(value)
        return
    if isinstance(value, list):
        _print_list(value)
        return
    if isinstance(value, Repository):
        _print_repository_detail(value, options or {})
        return
    if isinstance(value, Release):
        _print_release_detail(value)
        return
    primitive = to_primitive(value)
    if isinstance(primitive, dict):
        _print_mapping(primitive)
        return
    typer.echo(json.dumps(primitive, indent=2, ensure_ascii=False))


def _print_mapping(values: Dict[str, Any], prefix: str = "") -> None:
    for key, value in values.items():
        name = f"{prefix}{key}"
        if isinstance(value, dict):
            typer.secho(f"{name}:", bold=not prefix)
            _print_mapping(value, prefix="  ")
        elif isinstance(value, list):
            typer.secho(f"{name}:", bold=not prefix, nl=False)
            typer.echo(f" {json.dumps(value, ensure_ascii=False)}")
        else:
            typer.secho(f"{name}:", bold=not prefix, nl=False)
            typer.echo(f" {value}")


def _print_release_detail(release: Release) -> None:
    primitive = to_primitive(release)
    assets = primitive.pop("assets", [])
    for key, value in primitive.items():
        if key == "tags":
            typer.secho(f"{key}:", bold=True, nl=False)
            typer.echo(f" {_format_cell(value)}")
        elif isinstance(value, dict):
            typer.secho(f"{key}:", bold=True)
            _print_mapping(value, prefix="  ")
        elif isinstance(value, list):
            typer.secho(f"{key}:", bold=True, nl=False)
            typer.echo(f" {_format_cell(value)}")
        else:
            typer.secho(f"{key}:", bold=True, nl=False)
            typer.echo(f" {value}")

    if assets:
        typer.echo()
        typer.secho("assets", bold=True)
        _print_table(
            assets, ["id", "name", "description", "size", "downloads"]
        )


def _print_repository_detail(
    repository: Repository,
    options: Dict[str, Any],
) -> None:
    primitive = to_primitive(repository)
    packages = primitive.pop("packages", [])
    primitive.pop("permissions", None)
    release_count = sum(
        len(package.get("releases", [])) for package in packages
    )
    package_count = len(packages)

    for key, value in primitive.items():
        if isinstance(value, dict):
            typer.secho(f"{key}:", bold=True)
            _print_mapping(value, prefix="  ")
        elif isinstance(value, list):
            typer.secho(f"{key}:", bold=True, nl=False)
            typer.echo(f" {json.dumps(value, ensure_ascii=False)}")
        else:
            typer.secho(f"{key}:", bold=True, nl=False)
            typer.echo(f" {value}")

    typer.secho("package_count:", bold=True, nl=False)
    typer.echo(f" {package_count}")
    typer.secho("release_count:", bold=True, nl=False)
    typer.echo(f" {release_count}")

    if options.get("show_packages") and packages:
        typer.echo()
        typer.secho("packages", bold=True)
        _print_table(
            [
                {
                    "id": package.get("id"),
                    "name": package.get("name"),
                    "author": package.get("author", ""),
                    "releases": len(package.get("releases", [])),
                }
                for package in packages
            ],
            ["id", "name", "author", "releases"],
        )

    if options.get("show_releases") and packages:
        releases = []
        for package in packages:
            for release in package.get("releases", []):
                releases.append((package.get("name"), release))
        if releases:
            typer.echo()
            typer.secho("releases", bold=True)
            _print_table(
                [
                    {
                        "package": package_name,
                        "id": release.get("id"),
                        "name": release.get("name"),
                        "tags": release.get("tags", []),
                        "downloads": release.get("downloads", 0),
                    }
                    for package_name, release in releases
                ],
                ["package", "id", "name", "tags", "downloads"],
            )


def _exact_name_matches(items: Sequence[Any], name: str) -> List[Any]:
    expected = name.strip().lower()
    return [
        item
        for item in items
        if getattr(item, "name", "").strip().lower() == expected
    ]


def _summary(item: Any) -> str:
    if isinstance(item, Repository):
        return f"{item.id}\t{item.name}\t{item.type.slug}"
    if isinstance(item, Package):
        return f"{item.id}\t{item.name}\trepo={item.repository_id}"
    if isinstance(item, Release):
        return f"{item.id}\t{item.name}\ttags={','.join(item.tags)}"
    if isinstance(item, Asset):
        return f"{item.id}\t{item.name}"
    return str(item)
