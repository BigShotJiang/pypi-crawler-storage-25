from __future__ import annotations

from typing import Any
from typing import Optional

import typer

from ..auth import BasicAuthProvider
from ..client import RepkaClient
from ..config import DOTENV_SERVER_NAME
from ..config import ResolvedConfiguration
from ..config import remove_env_credentials
from ..config import remove_system_credentials
from ..config import resolve_configuration
from ..config import save_system_server
from ..config import store_system_credentials
from ..config import write_env_credentials
from ..exceptions import RepkaError
from ..exceptions import RepkaConfigurationError
from ..exceptions import RepkaServerError
from ..exceptions import RepkaTransportError
from ..exceptions import RepkaValidationError
from ..models import ServerConfig
from .app import auth_app
from .logic import build_auth_status
from .logic import build_client
from .logic import execute
from .logic import password_value
from .logic import prompt_required
from .logic import resolve_runtime_configuration
from .logic import resolve_server_for_login
from .logic import result
from .logic import state as cli_state


@auth_app.command("login")
def auth_login(
    ctx: typer.Context,
    server: Optional[str] = typer.Argument(
        None,
        help="Server identifier: configured name, URL, nextgis, or dotenv.",
    ),
    username: Optional[str] = typer.Option(
        None,
        "--username",
        "-u",
        help="Repka username.",
    ),
    password: Optional[str] = typer.Option(
        None,
        "--password",
        "-p",
        help="Repka password.",
    ),
    password_stdin: bool = typer.Option(
        False,
        "--password-stdin",
        help="Read the password from stdin.",
    ),
    name: Optional[str] = typer.Option(
        None,
        "--name",
        help="Server configuration name. Kept for compatibility; prefer SERVER.",
    ),
    url: Optional[str] = typer.Option(
        None,
        "--url",
        help="Server URL.",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Overwrite existing stored credentials without confirmation.",
    ),
) -> None:
    """Authenticate and store Repka credentials."""

    state = cli_state(ctx)

    def operation() -> Any:
        server_identifier = server or name or state.server_name
        login_source = _auth_source_for_server(server_identifier)
        server_config = resolve_server_for_login(
            state,
            name=server_identifier,
            url=url,
            source=login_source,
        )
        _confirm_auth_overwrite(
            server_config,
            login_source,
            force=force,
        )
        login_username = prompt_required(username, "Username")
        login_password = password_value(password, password_stdin)
        provider = BasicAuthProvider(login_username, login_password)
        with RepkaClient(
            server_config.url,
            auth_provider=provider,
            timeout=state.timeout,
            verify=state.verify,
        ) as client:
            user = client.auth.whoami()

        if login_source == "dotenv":
            write_env_credentials(
                ServerConfig(
                    name=DOTENV_SERVER_NAME,
                    url=server_config.url,
                    default=True,
                ),
                login_username,
                login_password,
            )
        elif login_source == "system":
            save_system_server(server_config)
            store_system_credentials(
                server_config.name, login_username, login_password
            )

        status = build_auth_status(
            ResolvedConfiguration(
                server=server_config,
                username=login_username,
                password=None,
                source=login_source,
            ),
            user,
        )
        return result(
            status,
            "message",
            message=f"Logged in to '{server_config.name}' as {login_username}",
        )

    execute(state, operation)


@auth_app.command("logout")
def auth_logout(
    ctx: typer.Context,
    server: Optional[str] = typer.Argument(
        None,
        help="Server identifier: configured name, URL, nextgis, or dotenv.",
    ),
) -> None:
    """Remove stored Repka credentials."""

    state = cli_state(ctx)

    def operation() -> Any:
        server_identifier = server or state.server_name
        logout_source = _auth_source_for_server(server_identifier)
        if logout_source == "dotenv":
            remove_env_credentials()
            return result(
                {"logout": True, "source": logout_source},
                "message",
                message="Logged out from 'dotenv'",
            )
        elif logout_source == "system":
            resolved = resolve_configuration(server_identifier)
            if resolved.server is None:
                resolved = resolve_runtime_configuration(state)
            remove_system_credentials(resolved.server.name)
            payload = {
                "logout": True,
                "source": logout_source,
                "server": resolved.server.name,
            }
            return result(
                payload,
                "message",
                message=f"Logged out from '{resolved.server.name}'",
            )

    execute(state, operation)


@auth_app.command("status")
def auth_status(ctx: typer.Context) -> None:
    """Check whether current credentials can authenticate."""

    state = cli_state(ctx)

    def operation() -> Any:
        resolved = resolve_configuration(state.server_name)
        if resolved.server is None:
            if state.server_name == DOTENV_SERVER_NAME:
                raise RepkaConfigurationError(
                    "Dotenv server is not configured; set REPKA_SERVER_URL in .env"
                )
            status = "not_configured"
            payload = {"status": status}
            return result(payload, "message", message=status)
        status = "unknown"
        try:
            with build_client(state, resolved) as client:
                user = client.auth.whoami()
        except (RepkaTransportError, RepkaServerError):
            status = "unknown"
        except RepkaError:
            status = "failed"
        else:
            status = "success" if user.login.lower() != "guest" else "guest"
        payload = {"status": status}
        return result(payload, "message", message=status)

    execute(state, operation)


@auth_app.command("params")
def auth_params(ctx: typer.Context) -> None:
    """Show current login parameters without checking credentials."""

    state = cli_state(ctx)

    def operation() -> Any:
        resolved = resolve_runtime_configuration(state)
        payload = {
            "server": resolved.server.name,
            "url": resolved.server.url,
            "source": resolved.source,
            "username": resolved.username or "",
            "credentials": bool(resolved.username and resolved.password),
        }
        return result(
            payload,
            "message",
            message=(
                f"{payload['server']} ({payload['source']}): "
                f"{payload['username'] or 'anonymous'}"
            ),
        )

    execute(state, operation)


def _auth_source_for_server(server: Optional[str]) -> str:
    if server == DOTENV_SERVER_NAME:
        return "dotenv"
    return "system"


def _confirm_auth_overwrite(
    server: ServerConfig,
    source: str,
    *,
    force: bool,
) -> None:
    if force or not _auth_record_exists(server, source):
        return
    confirmed = typer.confirm(
        f"Credentials for server '{server.name}' already exist. Overwrite?",
        default=False,
    )
    if not confirmed:
        raise RepkaValidationError("Login aborted")


def _auth_record_exists(server: ServerConfig, source: str) -> bool:
    resolved = resolve_configuration(server.name)
    if source == "dotenv":
        resolved = resolve_configuration(DOTENV_SERVER_NAME)
    return bool(resolved.username or resolved.password)
