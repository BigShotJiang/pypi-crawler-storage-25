from __future__ import annotations

import webbrowser
from typing import Any
from typing import List
from typing import Optional

import typer

from ..exceptions import RepkaValidationError
from .app import app
from .logic import build_client
from .logic import choose_package
from .logic import choose_release
from .logic import choose_repository
from .logic import execute
from .logic import parse_release_options
from .logic import resolve_runtime_configuration
from .logic import result
from .logic import state as cli_state


@app.command("whoami")
def whoami(ctx: typer.Context) -> None:
    """Return the current Repka user."""

    state = cli_state(ctx)

    def operation() -> Any:
        resolved = resolve_runtime_configuration(state)
        with build_client(state, resolved) as client:
            user = client.auth.whoami()
        return {
            "server": {
                "name": resolved.server.name,
                "url": resolved.server.url,
                "source": resolved.source,
            },
            "user": user,
        }

    execute(state, operation)


@app.command("find")
def find(
    ctx: typer.Context,
    entity: str = typer.Argument(
        ...,
        help="Entity to search: repo, package, release.",
    ),
    query: Optional[str] = typer.Argument(
        None,
        help="Optional search text, ID, or URL.",
    ),
    repo: Optional[str] = typer.Option(
        None,
        "--repo",
        "-r",
        help="Parent repository ID, name, or URL for package/release search.",
    ),
    package: Optional[str] = typer.Option(
        None,
        "--package",
        "-p",
        help="Parent package ID, name, or URL for release search.",
    ),
    tag: Optional[List[str]] = typer.Option(
        None,
        "--tag",
        "-g",
        help="Release tag filter. Can be repeated.",
    ),
    option: Optional[List[str]] = typer.Option(
        None,
        "--option",
        "-o",
        help="Release option filter as key=value or key:value. Can be repeated.",
    ),
    field: Optional[List[str]] = typer.Option(
        None,
        "--field",
        "-F",
        help="Table field to print. Can be repeated; use 'all' for every field.",
    ),
    all_fields: bool = typer.Option(
        False,
        "--all",
        help="Print all available table fields.",
    ),
) -> None:
    """Search repositories, packages, or releases."""

    state = cli_state(ctx)

    def operation() -> Any:
        release_options = parse_release_options(option)
        with build_client(state) as client:
            if entity in {"repo", "repository", "repositories"}:
                if query and (query.isdigit() or query.startswith("http")):
                    return client.repositories.get(query)
                return result(
                    client.search.find_repositories(query),
                    "list",
                    fields=field,
                    all_fields=all_fields,
                )
            if entity in {"package", "packages"}:
                selected_repo = repo or choose_repository(client)
                if query and (query.isdigit() or query.startswith("http")):
                    return client.packages.get(query, repository=selected_repo)
                return result(
                    client.search.find_packages(
                        query,
                        repository=selected_repo,
                    ),
                    "list",
                    fields=field,
                    all_fields=all_fields,
                )
            if entity in {"release", "releases"}:
                selected_package = package
                if not (tag or release_options):
                    selected_package = package or choose_package(
                        client,
                        repo=repo,
                    )
                if query and (query.isdigit() or query.startswith("http")):
                    return client.releases.get(
                        query, package=selected_package, repository=repo
                    )
                return result(
                    client.search.find_releases(
                        query,
                        package=selected_package,
                        repository=repo,
                        tags=tag,
                        options=release_options,
                    ),
                    "list",
                    fields=field,
                    all_fields=all_fields,
                )
            raise RepkaValidationError(
                "Entity must be repo, package or release"
            )

    execute(state, operation)


@app.command("browse")
def browse(
    ctx: typer.Context,
    entity: Optional[str] = typer.Argument(
        None,
        help="Entity to open: repo, package, release. Omit to open home page.",
    ),
    reference: Optional[str] = typer.Argument(
        None,
        help="Entity ID, name, or URL. Omit to choose interactively.",
    ),
    print_url: bool = typer.Option(
        False,
        "--print-url",
        "-P",
        help="Print the URL instead of opening it in a browser.",
    ),
    repo: Optional[str] = typer.Option(
        None,
        "--repo",
        "-r",
        help="Parent repository ID, name, or URL.",
    ),
) -> None:
    """Open or print a Repka UI URL."""

    state = cli_state(ctx)

    def operation() -> str:
        resolved = resolve_runtime_configuration(state)
        if entity is None:
            url = resolved.server.url
            if not print_url and not state.dry_run:
                webbrowser.open(url)
            return url
        with build_client(state, resolved) as client:
            if entity in {"repo", "repository"}:
                repository = choose_repository(client, reference)
                url = client.repositories.browse_url(repository.id)
            elif entity == "package":
                package_item = choose_package(client, reference, repo=repo)
                url = client.packages.browse_url(package_item.id)
            elif entity == "release":
                release_item = choose_release(
                    client,
                    reference,
                    repo=repo,
                )
                url = client.releases.browse_url(release_item.id)
            else:
                raise RepkaValidationError(
                    "Entity must be repo, package or release"
                )
            if not print_url and not state.dry_run:
                webbrowser.open(url)
            return url

    execute(state, operation)
