from __future__ import annotations

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version
from typing import Optional

import typer

from .logic import CLIContext
from .._logging import configure_logging


CONTEXT_SETTINGS = {"help_option_names": ["-h", "--help"]}

app = typer.Typer(help="Repka CLI", context_settings=CONTEXT_SETTINGS)
auth_app = typer.Typer(
    help="Authentication commands",
    context_settings=CONTEXT_SETTINGS,
)
server_app = typer.Typer(
    help="Server configuration commands",
    context_settings=CONTEXT_SETTINGS,
)
repo_app = typer.Typer(
    help="Repository commands", context_settings=CONTEXT_SETTINGS
)
package_app = typer.Typer(
    help="Package commands", context_settings=CONTEXT_SETTINGS
)
release_app = typer.Typer(
    help="Release commands", context_settings=CONTEXT_SETTINGS
)
asset_app = typer.Typer(
    help="Asset commands", context_settings=CONTEXT_SETTINGS
)

app.add_typer(auth_app, name="auth")
app.add_typer(server_app, name="server")
app.add_typer(repo_app, name="repo")
app.add_typer(package_app, name="package")
app.add_typer(release_app, name="release")
app.add_typer(asset_app, name="asset")


def _version_callback(value: bool) -> None:
    if not value:
        return
    try:
        package_version = version("repka-sdk")
    except PackageNotFoundError:
        package_version = "0.1.0"
    typer.echo(f"repka {package_version}")
    raise typer.Exit()


@app.callback()
def main(
    ctx: typer.Context,
    server: Optional[str] = typer.Option(
        None,
        "--server",
        "-s",
        help="Configured server name or URL.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        "-j",
        help="Print JSON instead of formatted text.",
    ),
    timeout: float = typer.Option(
        30.0,
        "--timeout",
        "-t",
        help="HTTP request timeout in seconds.",
    ),
    insecure: bool = typer.Option(
        False,
        "--insecure",
        "-k",
        help="Disable TLS certificate verification.",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Enable debug logs on stderr.",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        "-n",
        help="Show the planned write operation without sending it.",
    ),
    show_version: Optional[bool] = typer.Option(
        None,
        "--version",
        help="Print the CLI version and exit.",
        callback=_version_callback,
        is_eager=True,
    ),
) -> None:
    """Configure global CLI options."""

    configure_logging(verbose)
    ctx.obj = CLIContext(
        server_name=server,
        json_output=json_output,
        timeout=timeout,
        verify=not insecure,
        verbose=verbose,
        dry_run=dry_run,
    )


def register_commands() -> None:
    """Import command modules so they register with the Typer app."""

    from . import commands_assets  # noqa: F401
    from . import commands_auth  # noqa: F401
    from . import commands_packages  # noqa: F401
    from . import commands_releases  # noqa: F401
    from . import commands_repositories  # noqa: F401
    from . import commands_root  # noqa: F401
    from . import commands_server  # noqa: F401


register_commands()
