from __future__ import annotations

from typing import Any
from typing import List
from typing import Optional

import typer

from ..models import RepositoryInput
from ..models import RepositoryOptions
from ..models import RepositoryType
from .app import repo_app
from .logic import CLIContext
from .logic import build_client
from .logic import choose_repository
from .logic import execute
from .logic import parse_permissions
from .logic import result
from .logic import state as cli_state


@repo_app.command("create")
def repo_create(
    ctx: typer.Context,
    name: str = typer.Argument(..., help="Repository name."),
    repository_type: str = typer.Option(
        ...,
        "--type",
        "-T",
        help="Repository type: any, ubuntu, docker, borsch, installer, qgis, maven.",
    ),
    description: str = typer.Option(
        "",
        "--description",
        "-d",
        help="Repository description.",
    ),
    cleanup: bool = typer.Option(
        False,
        "--cleanup/--no-cleanup",
        help="Enable or disable repository cleanup.",
    ),
    keep_releases: int = typer.Option(
        0,
        "--keep-releases",
        help="Number of releases to keep during cleanup.",
    ),
    ttl: int = typer.Option(0, "--ttl", help="Cleanup TTL in days."),
    permission: Optional[List[str]] = typer.Option(
        None,
        "--permission",
        "-P",
        help="Permission as principal_id:type. Can be repeated.",
    ),
) -> None:
    """Create a repository."""

    state = cli_state(ctx)

    def operation() -> Any:
        write = RepositoryInput(
            name=name,
            description=description,
            repository_type=RepositoryType.from_value(repository_type),
            options=RepositoryOptions(
                cleanup=cleanup,
                keep_releases=keep_releases,
                ttl=ttl,
            ),
            permissions=parse_permissions(permission),
        )
        if state.dry_run:
            return {"dry_run": True, "action": "repo.create", "payload": write}
        with build_client(state) as client:
            return client.repositories.create(write)

    execute(state, operation)


@repo_app.command("get")
def repo_get(
    ctx: typer.Context,
    reference: Optional[str] = typer.Argument(
        None,
        help="Repository ID, name, or URL. Omit to choose interactively.",
    ),
    show_packages: bool = typer.Option(
        False,
        "--show-packages",
        help="Show repository packages after the package and release counts.",
    ),
    show_releases: bool = typer.Option(
        False,
        "--show-releases",
        help="Show releases grouped by package after repository details.",
    ),
) -> None:
    """Show a repository."""

    state = cli_state(ctx)
    execute(
        state,
        lambda: _repo_get(
            state,
            reference,
            show_packages=show_packages,
            show_releases=show_releases,
        ),
        mode="detail",
    )


def _repo_get(
    state: CLIContext,
    reference: Optional[str],
    *,
    show_packages: bool,
    show_releases: bool,
) -> Any:
    with build_client(state) as client:
        repository = choose_repository(client, reference)
        return result(
            client.repositories.get(repository.id),
            "detail",
            show_packages=show_packages,
            show_releases=show_releases,
        )


@repo_app.command("list")
def repo_list(
    ctx: typer.Context,
    filter_text: Optional[str] = typer.Option(
        None,
        "--filter",
        "-f",
        help="Text filter applied by the Repka API.",
    ),
    sort: Optional[str] = typer.Option(
        None,
        "--sort",
        "-S",
        help="Sort expression accepted by the Repka API, for example name or -name.",
    ),
    repository_type: Optional[str] = typer.Option(
        None,
        "--type",
        "-T",
        help="Repository type: any, ubuntu, docker, borsch, installer, qgis, maven.",
    ),
    field: Optional[List[str]] = typer.Option(
        None,
        "--field",
        "-F",
        help="Table field to print. Can be repeated; use 'all' for every field.",
    ),
    all_fields: bool = typer.Option(
        False,
        "--all",
        help="Print all available table fields.",
    ),
) -> None:
    """List repositories."""

    state = cli_state(ctx)

    def operation() -> Any:
        with build_client(state) as client:
            return result(
                client.repositories.list(
                    filter_text=filter_text,
                    sort=sort,
                    repository_type=repository_type,
                ),
                "list",
                fields=field,
                all_fields=all_fields,
            )

    execute(state, operation)


@repo_app.command("update")
def repo_update(
    ctx: typer.Context,
    reference: str = typer.Argument(..., help="Repository ID, name, or URL."),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="New name."),
    description: Optional[str] = typer.Option(
        None,
        "--description",
        "-d",
        help="New description.",
    ),
    cleanup: Optional[bool] = typer.Option(
        None,
        "--cleanup/--no-cleanup",
        help="Enable or disable repository cleanup.",
    ),
    keep_releases: Optional[int] = typer.Option(
        None,
        "--keep-releases",
        help="Number of releases to keep during cleanup.",
    ),
    ttl: Optional[int] = typer.Option(
        None, "--ttl", help="Cleanup TTL in days."
    ),
    permission: Optional[List[str]] = typer.Option(
        None,
        "--permission",
        "-P",
        help="Permission as principal_id:type. Can be repeated.",
    ),
    clear_permissions: bool = typer.Option(
        False,
        "--clear-permissions",
        help="Remove all repository permissions.",
    ),
) -> None:
    """Update a repository."""

    state = cli_state(ctx)

    def operation() -> Any:
        with build_client(state) as client:
            existing = client.repositories.get(reference)
            permissions = None
            if clear_permissions:
                permissions = []
            elif permission:
                permissions = parse_permissions(permission)

            options = None
            if (
                cleanup is not None
                or keep_releases is not None
                or ttl is not None
            ):
                options = RepositoryOptions(
                    cleanup=existing.options.cleanup
                    if cleanup is None
                    else cleanup,
                    keep_releases=(
                        existing.options.keep_releases
                        if keep_releases is None
                        else keep_releases
                    ),
                    ttl=existing.options.ttl if ttl is None else ttl,
                )

            write = RepositoryInput(
                name=name,
                description=description,
                options=options,
                permissions=permissions,
            )
            if state.dry_run:
                return {
                    "dry_run": True,
                    "action": "repo.update",
                    "target": existing.id,
                    "payload": write,
                }
            return client.repositories.update(existing.id, write)

    execute(state, operation)


@repo_app.command("delete")
def repo_delete(
    ctx: typer.Context,
    reference: str = typer.Argument(..., help="Repository ID, name, or URL."),
) -> None:
    """Delete a repository."""

    state = cli_state(ctx)

    def operation() -> Any:
        with build_client(state) as client:
            repository = client.repositories.get(reference)
            if state.dry_run:
                return {
                    "dry_run": True,
                    "action": "repo.delete",
                    "target": repository,
                }
            client.repositories.delete(repository.id)
            return {"deleted": True, "id": repository.id}

    execute(state, operation)
