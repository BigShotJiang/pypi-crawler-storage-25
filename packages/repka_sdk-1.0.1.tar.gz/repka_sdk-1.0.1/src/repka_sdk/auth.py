from __future__ import annotations

from abc import ABC
from abc import abstractmethod
from typing import Optional

import httpx


class AuthProvider(ABC):
    """Base interface for HTTP authentication providers."""

    @abstractmethod
    def get_httpx_auth(self) -> Optional[httpx.Auth]:
        """Return authentication data for httpx."""

        raise NotImplementedError

    @abstractmethod
    def get_username(self) -> Optional[str]:
        """Return the configured username."""

        raise NotImplementedError


class BasicAuthProvider(AuthProvider):
    """Username and password authentication provider."""

    def __init__(self, username: str, password: str) -> None:
        self._username = username
        self._password = password

    def get_httpx_auth(self) -> Optional[httpx.Auth]:
        """Return authentication data for httpx."""

        return httpx.BasicAuth(self._username, self._password)

    def get_username(self) -> Optional[str]:
        """Return the configured username."""

        return self._username
