from __future__ import annotations

from typing import List
from typing import Optional
from typing import Sequence
from typing import Union

from ..models import Package
from ..models import Release
from ..models import ReleaseOptions
from ..models import Repository
from .packages import AsyncPackageService
from .packages import PackageService
from .releases import AsyncReleaseService
from .releases import ReleaseService
from .repositories import AsyncRepositoryService
from .repositories import RepositoryService


class SearchService:
    """Synchronous service for cross-entity search."""

    def __init__(
        self,
        repositories: RepositoryService,
        packages: PackageService,
        releases: ReleaseService,
    ) -> None:
        self.repositories = repositories
        self.packages = packages
        self.releases = releases

    def find_repositories(
        self,
        query: Optional[str] = None,
    ) -> List[Repository]:
        """Find repositories by exact or fuzzy name."""

        return self.repositories.list(filter_text=query)

    def find_packages(
        self,
        query: Optional[str] = None,
        *,
        repository: Optional[Union[int, str, Repository]] = None,
    ) -> List[Package]:
        """Find packages by exact or fuzzy name."""

        return self.packages.list(repository=repository, filter_text=query)

    def find_releases(
        self,
        query: Optional[str] = None,
        *,
        package: Optional[Union[int, str, Package]] = None,
        repository: Optional[Union[int, str, Repository]] = None,
        tags: Optional[Sequence[str]] = None,
        options: Optional[ReleaseOptions] = None,
    ) -> List[Release]:
        """Find releases by name, tags, or options."""

        if tags or options:
            return self.releases.list(tags=tags, options=options)
        return self.releases.list(
            package=package,
            repository=repository,
            filter_text=query,
        )


class AsyncSearchService:
    """Asynchronous service for cross-entity search."""

    def __init__(
        self,
        repositories: AsyncRepositoryService,
        packages: AsyncPackageService,
        releases: AsyncReleaseService,
    ) -> None:
        self.repositories = repositories
        self.packages = packages
        self.releases = releases

    async def find_repositories(
        self,
        query: Optional[str] = None,
    ) -> List[Repository]:
        """Find repositories by exact or fuzzy name."""

        return await self.repositories.list(filter_text=query)

    async def find_packages(
        self,
        query: Optional[str] = None,
        *,
        repository: Optional[Union[int, str, Repository]] = None,
    ) -> List[Package]:
        """Find packages by exact or fuzzy name."""

        return await self.packages.list(
            repository=repository, filter_text=query
        )

    async def find_releases(
        self,
        query: Optional[str] = None,
        *,
        package: Optional[Union[int, str, Package]] = None,
        repository: Optional[Union[int, str, Repository]] = None,
        tags: Optional[Sequence[str]] = None,
        options: Optional[ReleaseOptions] = None,
    ) -> List[Release]:
        """Find releases by name, tags, or options."""

        if tags or options:
            return await self.releases.list(tags=tags, options=options)
        return await self.releases.list(
            package=package,
            repository=repository,
            filter_text=query,
        )
