from __future__ import annotations

from typing import Union

from ..models import RepositoryType
from ..transport import AsyncTransport
from ..transport import SyncTransport


def _repository_type_value(value: Union[RepositoryType, int, str]) -> int:
    return int(RepositoryType.from_value(value).value)


class SyncService:
    """Synchronous service for remote synchronization discovery."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    def list_remote_repositories(
        self,
        repository_type: Union[RepositoryType, int, str],
    ):
        """Return remote repositories available for synchronization."""

        type_value = _repository_type_value(repository_type)
        return self._transport.request("GET", f"/api/sync/{type_value}")

    def list_remote_packages(
        self,
        repository_type: Union[RepositoryType, int, str],
        repository: Union[int, str],
    ):
        """Return remote packages available for synchronization."""

        type_value = _repository_type_value(repository_type)
        return self._transport.request(
            "GET",
            f"/api/sync/{type_value}/repo/{repository}",
        )


class AsyncSyncService:
    """Asynchronous service for remote synchronization discovery."""

    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    async def list_remote_repositories(
        self,
        repository_type: Union[RepositoryType, int, str],
    ):
        """Return remote repositories available for synchronization."""

        type_value = _repository_type_value(repository_type)
        return await self._transport.request("GET", f"/api/sync/{type_value}")

    async def list_remote_packages(
        self,
        repository_type: Union[RepositoryType, int, str],
        repository: Union[int, str],
    ):
        """Return remote packages available for synchronization."""

        type_value = _repository_type_value(repository_type)
        return await self._transport.request(
            "GET",
            f"/api/sync/{type_value}/repo/{repository}",
        )
