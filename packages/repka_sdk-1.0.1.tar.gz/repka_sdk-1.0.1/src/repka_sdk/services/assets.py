from __future__ import annotations

from pathlib import Path
from typing import Iterable
from typing import List
from typing import Optional
from typing import Union

from ..exceptions import RepkaConfigurationError
from ..models import ReleaseOptions
from ..models import UploadedAsset
from ..transport import AsyncTransport
from ..transport import SyncTransport
from .common import parse_reference_id


class AssetService:
    """Synchronous service for asset operations."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    def upload(self, path: Union[str, Path]) -> UploadedAsset:
        """Upload a local asset file."""

        file_path = Path(path)
        with file_path.open("rb") as stream:
            payload = self._transport.request(
                "POST",
                "/api/upload",
                files={
                    "file": (
                        file_path.name,
                        stream,
                        "application/octet-stream",
                    )
                },
            )
        return UploadedAsset(
            upload_name=str(payload["file"]),
            name=str(payload.get("name", file_path.name)),
            options=ReleaseOptions(payload.get("options", {})),
        )

    def upload_many(
        self, paths: Iterable[Union[str, Path]]
    ) -> List[UploadedAsset]:
        """Upload multiple local asset files."""

        return [self.upload(path) for path in paths]

    def download(
        self,
        reference: Union[int, str],
        destination: Optional[Union[str, Path]] = None,
        *,
        chunk_size: int = 65536,
    ) -> Union[bytes, Path]:
        """Download an asset to a local destination."""

        asset_id = parse_reference_id(reference, "asset")
        if asset_id is None:
            raise RepkaConfigurationError(
                "Asset reference must be an id or URL"
            )

        with self._transport.stream(
            "GET", f"/api/asset/{asset_id}/download"
        ) as response:
            if destination is None:
                return b"".join(response.iter_bytes(chunk_size=chunk_size))

            destination_path = Path(destination)
            if destination_path.exists() and destination_path.is_dir():
                filename = _filename_from_headers(response.headers) or str(
                    asset_id
                )
                destination_path = destination_path / filename

            with destination_path.open("wb") as stream:
                for chunk in response.iter_bytes(chunk_size=chunk_size):
                    stream.write(chunk)
        return destination_path

    def rights(self, reference: Union[int, str]):
        """Return current-user rights for an asset."""

        asset_id = parse_reference_id(reference, "asset")
        if asset_id is None:
            raise RepkaConfigurationError(
                "Asset reference must be an id or URL"
            )
        return self._transport.request("GET", f"/api/asset/{asset_id}/rights")


class AsyncAssetService:
    """Asynchronous service for asset operations."""

    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    async def upload(self, path: Union[str, Path]) -> UploadedAsset:
        """Upload a local asset file."""

        file_path = Path(path)
        with file_path.open("rb") as stream:
            payload = await self._transport.request(
                "POST",
                "/api/upload",
                files={
                    "file": (
                        file_path.name,
                        stream,
                        "application/octet-stream",
                    )
                },
            )
        return UploadedAsset(
            upload_name=str(payload["file"]),
            name=str(payload.get("name", file_path.name)),
            options=ReleaseOptions(payload.get("options", {})),
        )

    async def upload_many(
        self,
        paths: Iterable[Union[str, Path]],
    ) -> List[UploadedAsset]:
        """Upload multiple local asset files."""

        result: List[UploadedAsset] = []
        for path in paths:
            result.append(await self.upload(path))
        return result

    async def download(
        self,
        reference: Union[int, str],
        destination: Optional[Union[str, Path]] = None,
        *,
        chunk_size: int = 65536,
    ) -> Union[bytes, Path]:
        """Download an asset to a local destination."""

        asset_id = parse_reference_id(reference, "asset")
        if asset_id is None:
            raise RepkaConfigurationError(
                "Asset reference must be an id or URL"
            )

        async with self._transport.stream(
            "GET",
            f"/api/asset/{asset_id}/download",
        ) as response:
            if destination is None:
                chunks: List[bytes] = []
                async for chunk in response.aiter_bytes(chunk_size=chunk_size):
                    chunks.append(chunk)
                return b"".join(chunks)

            destination_path = Path(destination)
            if destination_path.exists() and destination_path.is_dir():
                filename = _filename_from_headers(response.headers) or str(
                    asset_id
                )
                destination_path = destination_path / filename

            with destination_path.open("wb") as stream:
                async for chunk in response.aiter_bytes(chunk_size=chunk_size):
                    stream.write(chunk)
        return destination_path

    async def rights(self, reference: Union[int, str]):
        """Return current-user rights for an asset."""

        asset_id = parse_reference_id(reference, "asset")
        if asset_id is None:
            raise RepkaConfigurationError(
                "Asset reference must be an id or URL"
            )
        return await self._transport.request(
            "GET",
            f"/api/asset/{asset_id}/rights",
        )


def _filename_from_headers(headers) -> Optional[str]:
    content_disposition = headers.get("content-disposition", "")
    marker = 'filename="'
    if marker not in content_disposition:
        return None
    return content_disposition.split(marker, 1)[1].split('"', 1)[0]
