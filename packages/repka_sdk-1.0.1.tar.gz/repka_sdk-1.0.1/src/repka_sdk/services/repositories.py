from __future__ import annotations

from typing import List
from typing import Optional
from typing import Union
from urllib.parse import quote

from ..exceptions import RepkaConfigurationError
from ..exceptions import RepkaNotFoundError
from ..models import Repository
from ..models import RepositoryType
from ..models import RepositoryInput
from ..transport import AsyncTransport
from ..transport import SyncTransport
from ..url_parser import build_ui_url
from .common import build_repository_payload
from .common import ensure_exact_name_match
from .common import merge_repository_input
from .common import parse_reference_id
from .common import parse_release
from .common import parse_repository
from .common import repository_matches_input


def _path_part(value: Union[int, str]) -> str:
    return quote(str(value).strip("/"), safe="")


def _wildcard_path(value: str) -> str:
    return quote(value.strip("/"), safe="/")


def _require_version_tag(version_tag: Optional[str]) -> str:
    if not version_tag:
        raise RepkaConfigurationError("version_tag is required")
    return version_tag


class RepositoryService:
    """Synchronous service for repository operations."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    def list(
        self,
        *,
        sort: Optional[str] = None,
        filter_text: Optional[str] = None,
        repository_type: Optional[Union[RepositoryType, int, str]] = None,
    ) -> List[Repository]:
        """Return matching entities."""

        params = {}
        if sort:
            params["sort"] = sort
        if filter_text:
            params["filter"] = filter_text
        if repository_type is not None:
            params["type"] = int(
                RepositoryType.from_value(repository_type).value
            )
        data = self._transport.request("GET", "/api/repo", params=params)
        return [parse_repository(item) for item in data]

    def get(self, reference: Union[int, str]) -> Repository:
        """Return one entity by ID, URL, or name."""

        repository_id = parse_reference_id(reference, "repository")
        if repository_id is not None:
            data = self._transport.request("GET", f"/api/repo/{repository_id}")
            return parse_repository(data)

        repositories = self.list(filter_text=str(reference))
        return ensure_exact_name_match(
            repositories, "Repository", str(reference)
        )

    def create(self, write: RepositoryInput) -> Repository:
        """Create an entity."""

        payload = build_repository_payload(write)
        created = self._transport.request(
            "POST",
            "/api/repo",
            json=payload,
            expected_status=[201],
        )
        return self.get(int(created["id"]))

    def update(
        self,
        reference: Union[int, str],
        write: RepositoryInput,
    ) -> Repository:
        """Update an entity."""

        repository = self.get(reference)
        merged = merge_repository_input(repository, write)
        self._transport.request(
            "PUT",
            f"/api/repo/{repository.id}",
            json=build_repository_payload(merged),
        )
        return self.get(repository.id)

    def delete(self, reference: Union[int, str]) -> None:
        """Delete an entity."""

        repository = self.get(reference)
        self._transport.request("DELETE", f"/api/repo/{repository.id}")

    def ensure(self, write: RepositoryInput) -> Repository:
        """Create or update an entity idempotently."""

        if not write.name:
            return self.create(write)
        try:
            existing = self.get(write.name)
        except RepkaNotFoundError:
            return self.create(write)
        if repository_matches_input(existing, write):
            return existing
        return self.update(existing.id, write)

    def browse_url(self, reference: Union[int, str]) -> str:
        """Return the UI URL for an entity."""

        repository = self.get(reference)
        return build_ui_url(
            self._transport.base_url, "repository", repository.id
        )

    def borsch_release(
        self,
        reference: Union[int, str],
        *,
        package_name: str,
        version_tag: Optional[str] = None,
    ):
        """Return a borsch release by package name and tag."""

        repository = self.get(reference)
        resolved_version_tag = _require_version_tag(version_tag)
        data = self._transport.request(
            "GET",
            f"/api/repo/{repository.id}/borsch",
            params={
                "packet_name": package_name,
                "release_tag": resolved_version_tag,
            },
        )
        return parse_release(data)

    def qgis_xml(self, reference: Union[int, str]) -> bytes:
        """Return QGIS repository XML."""

        repository = self.get(reference)
        return self._transport.request(
            "GET",
            f"/api/repo/{repository.id}/qgis_xml",
        )

    def qgis_protect_plugins(self, reference: Union[int, str]):
        """Return protected QGIS plugin metadata."""

        repository = self.get(reference)
        return self._transport.request(
            "GET",
            f"/api/repo/{repository.id}/qgis_protect_plugin",
        )

    def qgis_protect_plugin(
        self,
        reference: Union[int, str],
        plugin: str,
        *,
        version: Optional[str] = None,
        qgis: Optional[str] = None,
    ):
        """Return one protected QGIS plugin access descriptor."""

        repository = self.get(reference)
        params = {}
        if version:
            params["version"] = version
        if qgis:
            params["qgis"] = qgis
        return self._transport.request(
            "GET",
            (
                f"/api/repo/{repository.id}/qgis_protect_plugin/"
                f"{_path_part(plugin)}"
            ),
            params=params,
        )

    def installer_content(
        self,
        reference: Union[int, str],
        packet: str,
        subpath: str,
        *,
        version_tag: Optional[str] = None,
    ) -> bytes:
        """Return installer repository content."""

        repository = self.get(reference)
        params = {"release_tag": version_tag} if version_tag else None
        return self._transport.request(
            "GET",
            (
                f"/api/repo/{repository.id}/installer/{_path_part(packet)}/"
                f"{_wildcard_path(subpath)}"
            ),
            params=params,
        )

    def debian_content(
        self,
        reference: Union[int, str],
        dist: str,
        subpath: str,
    ) -> bytes:
        """Return Debian repository metadata content."""

        repository = self.get(reference)
        return self._transport.request(
            "GET",
            (
                f"/api/repo/{repository.id}/deb/dists/{_path_part(dist)}/"
                f"{_wildcard_path(subpath)}"
            ),
        )

    def debian_archive(
        self,
        reference: Union[int, str],
        asset: Union[int, str],
        name: str,
    ) -> bytes:
        """Download a Debian archive through the repository route."""

        repository = self.get(reference)
        return self._transport.request(
            "GET",
            (
                f"/api/repo/{repository.id}/deb/pool/{_path_part(asset)}"
                f"/download/{_path_part(name)}"
            ),
        )

    def debian_key(self, reference: Union[int, str]) -> bytes:
        """Return repository Debian public key bytes."""

        repository = self.get(reference)
        return self._transport.request(
            "GET",
            f"/api/repo/{repository.id}/deb/key.gpg",
        )


class AsyncRepositoryService:
    """Asynchronous service for repository operations."""

    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    async def list(
        self,
        *,
        sort: Optional[str] = None,
        filter_text: Optional[str] = None,
        repository_type: Optional[Union[RepositoryType, int, str]] = None,
    ) -> List[Repository]:
        """Return matching entities."""

        params = {}
        if sort:
            params["sort"] = sort
        if filter_text:
            params["filter"] = filter_text
        if repository_type is not None:
            params["type"] = int(
                RepositoryType.from_value(repository_type).value
            )
        data = await self._transport.request("GET", "/api/repo", params=params)
        return [parse_repository(item) for item in data]

    async def get(self, reference: Union[int, str]) -> Repository:
        """Return one entity by ID, URL, or name."""

        repository_id = parse_reference_id(reference, "repository")
        if repository_id is not None:
            data = await self._transport.request(
                "GET", f"/api/repo/{repository_id}"
            )
            return parse_repository(data)

        repositories = await self.list(filter_text=str(reference))
        return ensure_exact_name_match(
            repositories, "Repository", str(reference)
        )

    async def create(self, write: RepositoryInput) -> Repository:
        """Create an entity."""

        payload = build_repository_payload(write)
        created = await self._transport.request(
            "POST",
            "/api/repo",
            json=payload,
            expected_status=[201],
        )
        return await self.get(int(created["id"]))

    async def update(
        self,
        reference: Union[int, str],
        write: RepositoryInput,
    ) -> Repository:
        """Update an entity."""

        repository = await self.get(reference)
        merged = merge_repository_input(repository, write)
        await self._transport.request(
            "PUT",
            f"/api/repo/{repository.id}",
            json=build_repository_payload(merged),
        )
        return await self.get(repository.id)

    async def delete(self, reference: Union[int, str]) -> None:
        """Delete an entity."""

        repository = await self.get(reference)
        await self._transport.request("DELETE", f"/api/repo/{repository.id}")

    async def browse_url(self, reference: Union[int, str]) -> str:
        """Return the UI URL for an entity."""

        repository = await self.get(reference)
        return build_ui_url(
            self._transport.base_url, "repository", repository.id
        )

    async def borsch_release(
        self,
        reference: Union[int, str],
        *,
        package_name: str,
        version_tag: Optional[str] = None,
    ):
        """Return a borsch release by package name and tag."""

        repository = await self.get(reference)
        resolved_version_tag = _require_version_tag(version_tag)
        data = await self._transport.request(
            "GET",
            f"/api/repo/{repository.id}/borsch",
            params={
                "packet_name": package_name,
                "release_tag": resolved_version_tag,
            },
        )
        return parse_release(data)

    async def qgis_xml(self, reference: Union[int, str]) -> bytes:
        """Return QGIS repository XML."""

        repository = await self.get(reference)
        return await self._transport.request(
            "GET",
            f"/api/repo/{repository.id}/qgis_xml",
        )

    async def qgis_protect_plugins(self, reference: Union[int, str]):
        """Return protected QGIS plugin metadata."""

        repository = await self.get(reference)
        return await self._transport.request(
            "GET",
            f"/api/repo/{repository.id}/qgis_protect_plugin",
        )

    async def qgis_protect_plugin(
        self,
        reference: Union[int, str],
        plugin: str,
        *,
        version: Optional[str] = None,
        qgis: Optional[str] = None,
    ):
        """Return one protected QGIS plugin access descriptor."""

        repository = await self.get(reference)
        params = {}
        if version:
            params["version"] = version
        if qgis:
            params["qgis"] = qgis
        return await self._transport.request(
            "GET",
            (
                f"/api/repo/{repository.id}/qgis_protect_plugin/"
                f"{_path_part(plugin)}"
            ),
            params=params,
        )

    async def installer_content(
        self,
        reference: Union[int, str],
        packet: str,
        subpath: str,
        *,
        version_tag: Optional[str] = None,
    ) -> bytes:
        """Return installer repository content."""

        repository = await self.get(reference)
        params = {"release_tag": version_tag} if version_tag else None
        return await self._transport.request(
            "GET",
            (
                f"/api/repo/{repository.id}/installer/{_path_part(packet)}/"
                f"{_wildcard_path(subpath)}"
            ),
            params=params,
        )

    async def debian_content(
        self,
        reference: Union[int, str],
        dist: str,
        subpath: str,
    ) -> bytes:
        """Return Debian repository metadata content."""

        repository = await self.get(reference)
        return await self._transport.request(
            "GET",
            (
                f"/api/repo/{repository.id}/deb/dists/{_path_part(dist)}/"
                f"{_wildcard_path(subpath)}"
            ),
        )

    async def debian_archive(
        self,
        reference: Union[int, str],
        asset: Union[int, str],
        name: str,
    ) -> bytes:
        """Download a Debian archive through the repository route."""

        repository = await self.get(reference)
        return await self._transport.request(
            "GET",
            (
                f"/api/repo/{repository.id}/deb/pool/{_path_part(asset)}"
                f"/download/{_path_part(name)}"
            ),
        )

    async def debian_key(self, reference: Union[int, str]) -> bytes:
        """Return repository Debian public key bytes."""

        repository = await self.get(reference)
        return await self._transport.request(
            "GET",
            f"/api/repo/{repository.id}/deb/key.gpg",
        )
