from __future__ import annotations

from pathlib import Path
from typing import Iterable
from typing import List
from typing import Optional
from typing import Sequence
from typing import Union

from ..exceptions import RepkaAmbiguousResultError
from ..exceptions import RepkaConfigurationError
from ..exceptions import RepkaNotFoundError
from ..models import Asset
from ..models import Package
from ..models import Release
from ..models import ReleaseAssetInput
from ..models import ReleaseOptions
from ..models import ReleaseInput
from ..models import Repository
from ..models import UploadedAsset
from ..models import normalize_asset_inputs
from ..url_parser import build_ui_url
from ..transport import AsyncTransport
from ..transport import SyncTransport
from .assets import AsyncAssetService
from .assets import AssetService
from .common import build_release_payload
from .common import enrich_release_assets
from .common import ensure_exact_name_match
from .common import extract_version_tag
from .common import merge_release_input
from .common import parse_reference_id
from .common import parse_release
from .common import prepare_release_input
from .common import release_has_latest
from .common import release_matches_input
from .packages import AsyncPackageService
from .packages import PackageService
from .repositories import AsyncRepositoryService
from .repositories import RepositoryService


class ReleaseService:
    """Synchronous service for release operations."""

    def __init__(
        self,
        transport: SyncTransport,
        repositories: RepositoryService,
        packages: PackageService,
        assets: Optional[AssetService] = None,
    ) -> None:
        self._transport = transport
        self._repositories = repositories
        self._packages = packages
        self._assets = assets

    def _resolve_package(
        self,
        package: Union[int, str, Package],
        repository: Optional[Union[int, str, Repository]] = None,
    ) -> Package:
        if isinstance(package, Package):
            return package
        return self._packages.get(package, repository=repository)

    def _build_update_payload(
        self,
        release: Release,
        write: ReleaseInput,
    ):
        payload = build_release_payload(write)
        if not release.assets and normalize_asset_inputs(write.assets) == []:
            payload.pop("files", None)
        return payload

    def _reject_asset_clearing(
        self, release: Release, write: ReleaseInput
    ) -> None:
        if release.assets and normalize_asset_inputs(write.assets) == []:
            raise RepkaConfigurationError(
                "Clearing all assets from an existing release is disabled: "
                "the Repka server cannot update a release to an empty file "
                "list safely, and the SDK will not replace the release "
                "because that would change its id"
            )

    def list(
        self,
        package: Optional[Union[int, str, Package]] = None,
        *,
        repository: Optional[Union[int, str, Repository]] = None,
        sort: Optional[str] = None,
        filter_text: Optional[str] = None,
        tags: Optional[Sequence[str]] = None,
        options: Optional[ReleaseOptions] = None,
    ) -> List[Release]:
        """Return matching entities."""

        if package is None and not (tags or options):
            raise RepkaConfigurationError(
                "Package is required for release listing"
            )
        if package is not None:
            resolved_package = self._resolve_package(package, repository)
            params = {"packet": resolved_package.id}
            if sort:
                params["sort"] = sort
            if filter_text:
                params["filter"] = filter_text
            data = self._transport.request(
                "GET", "/api/release", params=params
            )
            return [
                parse_release(item, package_id=resolved_package.id)
                for item in data or []
            ]

        if tags or options:
            params = {}
            if tags:
                params["tag"] = list(tags)
            if options:
                params["option"] = options.to_query_values()
            data = self._transport.request(
                "GET", "/api/release", params=params
            )
            return [parse_release(item) for item in data]

        return []

    def get(
        self,
        reference: Union[int, str],
        *,
        package: Optional[Union[int, str, Package]] = None,
        repository: Optional[Union[int, str, Repository]] = None,
    ) -> Release:
        """Return one entity by ID, URL, or name."""

        release_id = parse_reference_id(reference, "release")
        if release_id is not None:
            data = self._transport.request("GET", f"/api/release/{release_id}")
            resolved_package_id = None
            if package is not None:
                resolved_package_id = self._resolve_package(
                    package, repository
                ).id
            return parse_release(data, package_id=resolved_package_id)

        releases = self.list(
            package=package,
            repository=repository,
            filter_text=str(reference),
        )
        return ensure_exact_name_match(releases, "Release", str(reference))

    def create(
        self,
        package: Union[int, str, Package],
        write: ReleaseInput,
        *,
        version_tag: Optional[str] = None,
    ) -> Release:
        """Create an entity."""

        resolved_package = self._resolve_package(package)
        prepared = prepare_release_input(
            write,
            version_tag=version_tag,
            require_version_tag=False,
        )
        payload = build_release_payload(
            prepared, package_id=resolved_package.id
        )
        created = self._transport.request(
            "POST",
            "/api/release",
            json=payload,
            expected_status=[201],
        )
        release = self.get(int(created["id"]))
        if release_has_latest(release):
            self._reconcile_latest(resolved_package.id, release.id)
            release = self.get(release.id)
        return release

    def update(
        self,
        reference: Union[int, str],
        write: ReleaseInput,
        *,
        package: Optional[Union[int, str, Package]] = None,
        repository: Optional[Union[int, str, Repository]] = None,
        version_tag: Optional[str] = None,
    ) -> Release:
        """Update an entity."""

        release = self.get(reference, package=package, repository=repository)
        merged = merge_release_input(release, write)
        merged = prepare_release_input(
            merged,
            version_tag=version_tag,
            require_version_tag=False,
        )
        self._reject_asset_clearing(release, merged)
        self._transport.request(
            "PUT",
            f"/api/release/{release.id}",
            json=self._build_update_payload(release, merged),
        )
        updated = self.get(
            release.id,
            package=package,
            repository=repository,
        )
        if release_has_latest(updated):
            self._reconcile_latest(updated.package_id, updated.id)
            updated = self.get(
                updated.id,
                package=package,
                repository=repository,
            )
        return updated

    def delete(
        self,
        reference: Union[int, str],
        *,
        package: Optional[Union[int, str, Package]] = None,
        repository: Optional[Union[int, str, Repository]] = None,
    ) -> None:
        """Delete an entity."""

        release = self.get(reference, package=package, repository=repository)
        self._transport.request("DELETE", f"/api/release/{release.id}")

    def ensure(
        self,
        package: Union[int, str, Package],
        write: ReleaseInput,
        *,
        version_tag: Optional[str] = None,
        enrich_assets: bool = False,
    ) -> Release:
        """Create or update an entity idempotently."""

        resolved_package = self._resolve_package(package)
        prepared = prepare_release_input(write, version_tag=version_tag)
        target_version = extract_version_tag(prepared, version_tag)
        target_options = write.options or ReleaseOptions()
        candidate = self._find_existing_release(
            resolved_package.id,
            target_version,
            target_options,
        )
        if candidate is None:
            return self.create(
                resolved_package, prepared, version_tag=target_version
            )

        desired = (
            enrich_release_assets(candidate, prepared)
            if enrich_assets
            else prepared
        )
        if release_matches_input(candidate, desired):
            if release_has_latest(candidate):
                self._reconcile_latest(resolved_package.id, candidate.id)
                return self.get(candidate.id)
            return candidate
        return self.update(candidate.id, desired, version_tag=target_version)

    def replace(
        self,
        reference: Union[int, str],
        write: ReleaseInput,
        *,
        package: Optional[Union[int, str, Package]] = None,
        repository: Optional[Union[int, str, Repository]] = None,
        version_tag: Optional[str] = None,
    ) -> Release:
        """Replace an entity payload."""

        release = self.get(reference, package=package, repository=repository)
        replace_write = merge_release_input(release, write)
        if write.assets is None:
            replace_write.assets = []
        if write.tags is None:
            replace_write.tags = list(release.tags)
        if write.options is None:
            replace_write.options = ReleaseOptions()
        self._reject_asset_clearing(release, replace_write)
        return self.update(
            release.id,
            replace_write,
            version_tag=version_tag,
        )

    def add_assets(
        self,
        reference: Union[int, str],
        assets: Sequence[Union[Asset, UploadedAsset, ReleaseAssetInput]],
        *,
        package: Optional[Union[int, str, Package]] = None,
        repository: Optional[Union[int, str, Repository]] = None,
    ) -> Release:
        """Append assets to a release."""

        release = self.get(reference, package=package, repository=repository)
        combined_assets = [
            ReleaseAssetInput.from_asset(asset) for asset in release.assets
        ]
        combined_assets.extend(normalize_asset_inputs(assets) or [])
        return self.update(
            release.id,
            ReleaseInput(assets=combined_assets),
        )

    def create_from_paths(
        self,
        package: Union[int, str, Package],
        paths: Iterable[Union[str, Path]],
        write: ReleaseInput,
        *,
        version_tag: Optional[str] = None,
    ) -> Release:
        """Upload files and create a release from them."""

        if self._assets is None:
            raise RepkaNotFoundError("Asset service is not configured")
        uploaded = self._assets.upload_many(paths)
        merged = ReleaseInput(
            name=write.name,
            description=write.description,
            tags=write.tags,
            options=write.options,
            assets=normalize_asset_inputs(uploaded),
        )
        return self.create(package, merged, version_tag=version_tag)

    def browse_url(
        self,
        reference: Union[int, str],
        *,
        package: Optional[Union[int, str, Package]] = None,
        repository: Optional[Union[int, str, Repository]] = None,
    ) -> str:
        """Return the UI URL for an entity."""

        release = self.get(reference, package=package, repository=repository)
        return build_ui_url(self._transport.base_url, "release", release.id)

    def _find_existing_release(
        self,
        package_id: int,
        version_tag: str,
        options: ReleaseOptions,
    ) -> Optional[Release]:
        matches = [
            release
            for release in self.list(package_id)
            if version_tag in release.tags
            and release.options.matches_subset(options)
        ]
        if not matches:
            return None
        exact = [release for release in matches if release.options == options]
        if len(exact) == 1:
            return exact[0]
        if len(matches) == 1:
            return matches[0]
        raise RepkaAmbiguousResultError("Release lookup is ambiguous")

    def _find_release_package_id(self, release_id: int) -> Optional[int]:
        return None

    def _reconcile_latest(
        self, package_id: Optional[int], release_id: int
    ) -> None:
        if package_id is None:
            return
        for release in self.list(package_id):
            if release.id == release_id or not release_has_latest(release):
                continue
            new_tags = [tag for tag in release.tags if tag != "latest"]
            if new_tags == release.tags:
                continue
            self.update(release.id, ReleaseInput(tags=new_tags))


class AsyncReleaseService:
    """Asynchronous service for release operations."""

    def __init__(
        self,
        transport: AsyncTransport,
        repositories: AsyncRepositoryService,
        packages: AsyncPackageService,
        assets: Optional[AsyncAssetService] = None,
    ) -> None:
        self._transport = transport
        self._repositories = repositories
        self._packages = packages
        self._assets = assets

    async def _resolve_package(
        self,
        package: Union[int, str, Package],
        repository: Optional[Union[int, str, Repository]] = None,
    ) -> Package:
        if isinstance(package, Package):
            return package
        return await self._packages.get(package, repository=repository)

    def _build_update_payload(
        self,
        release: Release,
        write: ReleaseInput,
    ):
        payload = build_release_payload(write)
        if not release.assets and normalize_asset_inputs(write.assets) == []:
            payload.pop("files", None)
        return payload

    def _reject_asset_clearing(
        self, release: Release, write: ReleaseInput
    ) -> None:
        if release.assets and normalize_asset_inputs(write.assets) == []:
            raise RepkaConfigurationError(
                "Clearing all assets from an existing release is disabled: "
                "the Repka server cannot update a release to an empty file "
                "list safely, and the SDK will not replace the release "
                "because that would change its id"
            )

    async def list(
        self,
        package: Optional[Union[int, str, Package]] = None,
        *,
        repository: Optional[Union[int, str, Repository]] = None,
        sort: Optional[str] = None,
        filter_text: Optional[str] = None,
        tags: Optional[Sequence[str]] = None,
        options: Optional[ReleaseOptions] = None,
    ) -> List[Release]:
        """Return matching entities."""

        if package is None and not (tags or options):
            raise RepkaConfigurationError(
                "Package is required for release listing"
            )
        if package is not None:
            resolved_package = await self._resolve_package(package, repository)
            params = {"packet": resolved_package.id}
            if sort:
                params["sort"] = sort
            if filter_text:
                params["filter"] = filter_text
            data = await self._transport.request(
                "GET", "/api/release", params=params
            )
            return [
                parse_release(item, package_id=resolved_package.id)
                for item in data
            ]

        if tags or options:
            params = {}
            if tags:
                params["tag"] = list(tags)
            if options:
                params["option"] = options.to_query_values()
            data = await self._transport.request(
                "GET", "/api/release", params=params
            )
            return [parse_release(item) for item in data]

        return []

    async def get(
        self,
        reference: Union[int, str],
        *,
        package: Optional[Union[int, str, Package]] = None,
        repository: Optional[Union[int, str, Repository]] = None,
    ) -> Release:
        """Return one entity by ID, URL, or name."""

        release_id = parse_reference_id(reference, "release")
        if release_id is not None:
            data = await self._transport.request(
                "GET", f"/api/release/{release_id}"
            )
            resolved_package_id = None
            if package is not None:
                resolved_package_id = (
                    await self._resolve_package(package, repository)
                ).id
            return parse_release(data, package_id=resolved_package_id)

        releases = await self.list(
            package=package,
            repository=repository,
            filter_text=str(reference),
        )
        return ensure_exact_name_match(releases, "Release", str(reference))

    async def create(
        self,
        package: Union[int, str, Package],
        write: ReleaseInput,
        *,
        version_tag: Optional[str] = None,
    ) -> Release:
        """Create an entity."""

        resolved_package = await self._resolve_package(package)
        prepared = prepare_release_input(
            write,
            version_tag=version_tag,
            require_version_tag=False,
        )
        payload = build_release_payload(
            prepared, package_id=resolved_package.id
        )
        created = await self._transport.request(
            "POST",
            "/api/release",
            json=payload,
            expected_status=[201],
        )
        release = await self.get(int(created["id"]))
        if release_has_latest(release):
            await self._reconcile_latest(resolved_package.id, release.id)
            release = await self.get(release.id)
        return release

    async def update(
        self,
        reference: Union[int, str],
        write: ReleaseInput,
        *,
        package: Optional[Union[int, str, Package]] = None,
        repository: Optional[Union[int, str, Repository]] = None,
        version_tag: Optional[str] = None,
    ) -> Release:
        """Update an entity."""

        release = await self.get(
            reference, package=package, repository=repository
        )
        merged = merge_release_input(release, write)
        merged = prepare_release_input(
            merged,
            version_tag=version_tag,
            require_version_tag=False,
        )
        self._reject_asset_clearing(release, merged)
        await self._transport.request(
            "PUT",
            f"/api/release/{release.id}",
            json=self._build_update_payload(release, merged),
        )
        updated = await self.get(
            release.id,
            package=package,
            repository=repository,
        )
        if release_has_latest(updated):
            await self._reconcile_latest(updated.package_id, updated.id)
            updated = await self.get(
                updated.id,
                package=package,
                repository=repository,
            )
        return updated

    async def delete(
        self,
        reference: Union[int, str],
        *,
        package: Optional[Union[int, str, Package]] = None,
        repository: Optional[Union[int, str, Repository]] = None,
    ) -> None:
        """Delete an entity."""

        release = await self.get(
            reference, package=package, repository=repository
        )
        await self._transport.request("DELETE", f"/api/release/{release.id}")

    async def ensure(
        self,
        package: Union[int, str, Package],
        write: ReleaseInput,
        *,
        version_tag: Optional[str] = None,
        enrich_assets: bool = False,
    ) -> Release:
        """Create or update an entity idempotently."""

        resolved_package = await self._resolve_package(package)
        prepared = prepare_release_input(write, version_tag=version_tag)
        target_version = extract_version_tag(prepared, version_tag)
        target_options = write.options or ReleaseOptions()
        candidate = await self._find_existing_release(
            resolved_package.id,
            target_version,
            target_options,
        )
        if candidate is None:
            return await self.create(
                resolved_package, prepared, version_tag=target_version
            )

        desired = (
            enrich_release_assets(candidate, prepared)
            if enrich_assets
            else prepared
        )
        if release_matches_input(candidate, desired):
            if release_has_latest(candidate):
                await self._reconcile_latest(resolved_package.id, candidate.id)
                return await self.get(candidate.id)
            return candidate
        return await self.update(
            candidate.id, desired, version_tag=target_version
        )

    async def replace(
        self,
        reference: Union[int, str],
        write: ReleaseInput,
        *,
        package: Optional[Union[int, str, Package]] = None,
        repository: Optional[Union[int, str, Repository]] = None,
        version_tag: Optional[str] = None,
    ) -> Release:
        """Replace an entity payload."""

        release = await self.get(
            reference, package=package, repository=repository
        )
        replace_write = merge_release_input(release, write)
        if write.assets is None:
            replace_write.assets = []
        if write.tags is None:
            replace_write.tags = list(release.tags)
        if write.options is None:
            replace_write.options = ReleaseOptions()
        self._reject_asset_clearing(release, replace_write)
        return await self.update(
            release.id,
            replace_write,
            version_tag=version_tag,
        )

    async def add_assets(
        self,
        reference: Union[int, str],
        assets: Sequence[Union[Asset, UploadedAsset, ReleaseAssetInput]],
        *,
        package: Optional[Union[int, str, Package]] = None,
        repository: Optional[Union[int, str, Repository]] = None,
    ) -> Release:
        """Append assets to a release."""

        release = await self.get(
            reference, package=package, repository=repository
        )
        combined_assets = [
            ReleaseAssetInput.from_asset(asset) for asset in release.assets
        ]
        combined_assets.extend(normalize_asset_inputs(assets) or [])
        return await self.update(
            release.id,
            ReleaseInput(assets=combined_assets),
        )

    async def create_from_paths(
        self,
        package: Union[int, str, Package],
        paths: Iterable[Union[str, Path]],
        write: ReleaseInput,
        *,
        version_tag: Optional[str] = None,
    ) -> Release:
        """Upload files and create a release from them."""

        if self._assets is None:
            raise RepkaNotFoundError("Asset service is not configured")
        uploaded = await self._assets.upload_many(paths)
        merged = ReleaseInput(
            name=write.name,
            description=write.description,
            tags=write.tags,
            options=write.options,
            assets=normalize_asset_inputs(uploaded),
        )
        return await self.create(package, merged, version_tag=version_tag)

    async def browse_url(
        self,
        reference: Union[int, str],
        *,
        package: Optional[Union[int, str, Package]] = None,
        repository: Optional[Union[int, str, Repository]] = None,
    ) -> str:
        """Return the UI URL for an entity."""

        release = await self.get(
            reference, package=package, repository=repository
        )
        return build_ui_url(self._transport.base_url, "release", release.id)

    async def _find_existing_release(
        self,
        package_id: int,
        version_tag: str,
        options: ReleaseOptions,
    ) -> Optional[Release]:
        matches = [
            release
            for release in await self.list(package_id)
            if version_tag in release.tags
            and release.options.matches_subset(options)
        ]
        if not matches:
            return None
        exact = [release for release in matches if release.options == options]
        if len(exact) == 1:
            return exact[0]
        if len(matches) == 1:
            return matches[0]
        raise RepkaAmbiguousResultError("Release lookup is ambiguous")

    async def _find_release_package_id(self, release_id: int) -> Optional[int]:
        return None

    async def _reconcile_latest(
        self,
        package_id: Optional[int],
        release_id: int,
    ) -> None:
        if package_id is None:
            return
        for release in await self.list(package_id):
            if release.id == release_id or not release_has_latest(release):
                continue
            new_tags = [tag for tag in release.tags if tag != "latest"]
            if new_tags == release.tags:
                continue
            await self.update(release.id, ReleaseInput(tags=new_tags))
