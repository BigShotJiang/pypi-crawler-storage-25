from __future__ import annotations

from pathlib import Path
from typing import Any
from typing import Dict
from typing import Optional
from typing import Union
from urllib.parse import quote

from ..transport import AsyncTransport
from ..transport import SyncTransport


def _params(
    *,
    sort: Optional[str] = None,
    filter_text: Optional[str] = None,
) -> Dict[str, str]:
    result: Dict[str, str] = {}
    if sort:
        result["sort"] = sort
    if filter_text:
        result["filter"] = filter_text
    return result


def _path_part(value: Union[int, str]) -> str:
    return quote(str(value).strip("/"), safe="")


class AdminService:
    """Synchronous service for administrative endpoints."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    def settings(self):
        return self._transport.request("GET", "/api/settings")

    def update_settings(self, payload: Dict[str, Any]):
        return self._transport.request("PUT", "/api/settings", json=payload)

    def test_ldap(self, payload: Dict[str, Any], *, method: str = "POST"):
        return self._transport.request(
            method.upper(),
            "/api/settings/test_ldap",
            json=payload,
        )

    def sign_code(self) -> bytes:
        return self._transport.request("GET", "/api/sign_code")

    def jobs(self):
        return self._transport.request("GET", "/api/jobs")

    def download_apple_cert(self, filename: str) -> bytes:
        return self._transport.request(
            "GET",
            f"/api/apple_cert/{_path_part(filename)}",
        )

    def upload_apple_cert(
        self,
        path: Union[str, Path],
        *,
        method: str = "POST",
    ):
        file_path = Path(path)
        with file_path.open("rb") as stream:
            return self._transport.request(
                method.upper(),
                "/api/apple_cert",
                files={
                    "file": (
                        file_path.name,
                        stream,
                        "application/octet-stream",
                    )
                },
            )

    def list_users(
        self,
        *,
        sort: Optional[str] = None,
        filter_text: Optional[str] = None,
    ):
        return self._transport.request(
            "GET",
            "/api/user",
            params=_params(sort=sort, filter_text=filter_text),
        )

    def get_user(self, user: Union[int, str]):
        return self._transport.request("GET", f"/api/user/{_path_part(user)}")

    def user_avatar(self, user: Union[int, str]) -> bytes:
        return self._transport.request(
            "GET",
            f"/api/user/{_path_part(user)}/avatar",
        )

    def create_user(self, payload: Dict[str, Any]):
        return self._transport.request(
            "POST",
            "/api/user",
            json=payload,
            expected_status=[201],
        )

    def update_user(self, user: Union[int, str], payload: Dict[str, Any]):
        return self._transport.request(
            "PUT",
            f"/api/user/{_path_part(user)}",
            json=payload,
        )

    def delete_user(self, user: Union[int, str]):
        return self._transport.request(
            "DELETE",
            f"/api/user/{_path_part(user)}",
        )

    def list_groups(
        self,
        *,
        sort: Optional[str] = None,
        filter_text: Optional[str] = None,
    ):
        return self._transport.request(
            "GET",
            "/api/group",
            params=_params(sort=sort, filter_text=filter_text),
        )

    def get_group(self, group: Union[int, str]):
        return self._transport.request(
            "GET",
            f"/api/group/{_path_part(group)}",
        )

    def create_group(self, payload: Dict[str, Any]):
        return self._transport.request(
            "POST",
            "/api/group",
            json=payload,
            expected_status=[201],
        )

    def update_group(self, group: Union[int, str], payload: Dict[str, Any]):
        return self._transport.request(
            "PUT",
            f"/api/group/{_path_part(group)}",
            json=payload,
        )

    def delete_group(self, group: Union[int, str]):
        return self._transport.request(
            "DELETE",
            f"/api/group/{_path_part(group)}",
        )


class AsyncAdminService:
    """Asynchronous service for administrative endpoints."""

    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    async def settings(self):
        return await self._transport.request("GET", "/api/settings")

    async def update_settings(self, payload: Dict[str, Any]):
        return await self._transport.request(
            "PUT",
            "/api/settings",
            json=payload,
        )

    async def test_ldap(
        self, payload: Dict[str, Any], *, method: str = "POST"
    ):
        return await self._transport.request(
            method.upper(),
            "/api/settings/test_ldap",
            json=payload,
        )

    async def sign_code(self) -> bytes:
        return await self._transport.request("GET", "/api/sign_code")

    async def jobs(self):
        return await self._transport.request("GET", "/api/jobs")

    async def download_apple_cert(self, filename: str) -> bytes:
        return await self._transport.request(
            "GET",
            f"/api/apple_cert/{_path_part(filename)}",
        )

    async def upload_apple_cert(
        self,
        path: Union[str, Path],
        *,
        method: str = "POST",
    ):
        file_path = Path(path)
        with file_path.open("rb") as stream:
            return await self._transport.request(
                method.upper(),
                "/api/apple_cert",
                files={
                    "file": (
                        file_path.name,
                        stream,
                        "application/octet-stream",
                    )
                },
            )

    async def list_users(
        self,
        *,
        sort: Optional[str] = None,
        filter_text: Optional[str] = None,
    ):
        return await self._transport.request(
            "GET",
            "/api/user",
            params=_params(sort=sort, filter_text=filter_text),
        )

    async def get_user(self, user: Union[int, str]):
        return await self._transport.request(
            "GET",
            f"/api/user/{_path_part(user)}",
        )

    async def user_avatar(self, user: Union[int, str]) -> bytes:
        return await self._transport.request(
            "GET",
            f"/api/user/{_path_part(user)}/avatar",
        )

    async def create_user(self, payload: Dict[str, Any]):
        return await self._transport.request(
            "POST",
            "/api/user",
            json=payload,
            expected_status=[201],
        )

    async def update_user(
        self, user: Union[int, str], payload: Dict[str, Any]
    ):
        return await self._transport.request(
            "PUT",
            f"/api/user/{_path_part(user)}",
            json=payload,
        )

    async def delete_user(self, user: Union[int, str]):
        return await self._transport.request(
            "DELETE",
            f"/api/user/{_path_part(user)}",
        )

    async def list_groups(
        self,
        *,
        sort: Optional[str] = None,
        filter_text: Optional[str] = None,
    ):
        return await self._transport.request(
            "GET",
            "/api/group",
            params=_params(sort=sort, filter_text=filter_text),
        )

    async def get_group(self, group: Union[int, str]):
        return await self._transport.request(
            "GET",
            f"/api/group/{_path_part(group)}",
        )

    async def create_group(self, payload: Dict[str, Any]):
        return await self._transport.request(
            "POST",
            "/api/group",
            json=payload,
            expected_status=[201],
        )

    async def update_group(
        self,
        group: Union[int, str],
        payload: Dict[str, Any],
    ):
        return await self._transport.request(
            "PUT",
            f"/api/group/{_path_part(group)}",
            json=payload,
        )

    async def delete_group(self, group: Union[int, str]):
        return await self._transport.request(
            "DELETE",
            f"/api/group/{_path_part(group)}",
        )
