from __future__ import annotations

from ..transport import AsyncTransport
from ..transport import SyncTransport


class ServerService:
    """Synchronous service for server metadata endpoints."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    def healthcheck(self):
        """Return server healthcheck response."""

        return self._transport.request("GET", "/api/healthcheck")

    def version(self):
        """Return server version response."""

        return self._transport.request("GET", "/api/version")

    def options(self):
        """Return public server options."""

        return self._transport.request("GET", "/api/options")

    def stats(self):
        """Return server statistics."""

        return self._transport.request("GET", "/api/stats")

    def oauth2_options(self):
        """Return OAuth2 client options."""

        return self._transport.request("GET", "/api/oauth2/options")

    def oauth2_user(self):
        """Return OAuth2 user callback data."""

        return self._transport.request("GET", "/api/oauth2/user")


class AsyncServerService:
    """Asynchronous service for server metadata endpoints."""

    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    async def healthcheck(self):
        """Return server healthcheck response."""

        return await self._transport.request("GET", "/api/healthcheck")

    async def version(self):
        """Return server version response."""

        return await self._transport.request("GET", "/api/version")

    async def options(self):
        """Return public server options."""

        return await self._transport.request("GET", "/api/options")

    async def stats(self):
        """Return server statistics."""

        return await self._transport.request("GET", "/api/stats")

    async def oauth2_options(self):
        """Return OAuth2 client options."""

        return await self._transport.request("GET", "/api/oauth2/options")

    async def oauth2_user(self):
        """Return OAuth2 user callback data."""

        return await self._transport.request("GET", "/api/oauth2/user")
