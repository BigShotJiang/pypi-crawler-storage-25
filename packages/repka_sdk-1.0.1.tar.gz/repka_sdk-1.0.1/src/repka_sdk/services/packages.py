from __future__ import annotations

from typing import List
from typing import Optional
from typing import Union

from ..exceptions import RepkaConfigurationError
from ..exceptions import RepkaNotFoundError
from ..models import Package
from ..models import PackageInput
from ..models import Repository
from ..transport import AsyncTransport
from ..transport import SyncTransport
from ..url_parser import build_ui_url
from .common import build_package_payload
from .common import ensure_exact_name_match
from .common import merge_package_input
from .common import package_matches_input
from .common import parse_package
from .common import parse_reference_id
from .repositories import AsyncRepositoryService
from .repositories import RepositoryService


class PackageService:
    """Synchronous service for package operations."""

    def __init__(
        self,
        transport: SyncTransport,
        repositories: RepositoryService,
    ) -> None:
        self._transport = transport
        self._repositories = repositories

    def _resolve_repository(
        self, repository: Union[int, str, Repository]
    ) -> Repository:
        if isinstance(repository, Repository):
            return repository
        return self._repositories.get(repository)

    def list(
        self,
        repository: Union[int, str, Repository],
        *,
        sort: Optional[str] = None,
        filter_text: Optional[str] = None,
    ) -> List[Package]:
        """Return matching entities."""

        resolved_repository = self._resolve_repository(repository)
        params = {"repository": resolved_repository.id}
        if sort:
            params["sort"] = sort
        if filter_text:
            params["filter"] = filter_text
        data = self._transport.request("GET", "/api/packet", params=params)
        if not isinstance(data, list):
            raise RepkaNotFoundError(f"Unexpected response format: {data}")
        return [
            parse_package(
                item,
                repository_id=resolved_repository.id,
                repository_type=resolved_repository.type,
            )
            for item in data
        ]

    def get(
        self,
        reference: Union[int, str],
        *,
        repository: Optional[Union[int, str, Repository]] = None,
    ) -> Package:
        """Return one entity by ID, URL, or name."""

        package_id = parse_reference_id(reference, "package")
        if package_id is not None:
            data = self._transport.request("GET", f"/api/packet/{package_id}")
            return parse_package(data)

        if repository is None:
            raise RepkaConfigurationError(
                "Repository is required for package lookup by name"
            )
        packages = self.list(repository=repository, filter_text=str(reference))
        return ensure_exact_name_match(packages, "Package", str(reference))

    def create(
        self,
        repository: Union[int, str, Repository],
        write: PackageInput,
    ) -> Package:
        """Create an entity."""

        resolved_repository = self._resolve_repository(repository)
        payload = build_package_payload(resolved_repository.id, write)
        created = self._transport.request(
            "POST",
            "/api/packet",
            json=payload,
            expected_status=[201],
        )
        return self.get(int(created["id"]))

    def update(
        self,
        reference: Union[int, str],
        write: PackageInput,
        *,
        repository: Union[int, str, Repository],
    ) -> Package:
        """Update an entity."""

        package = self.get(reference, repository=repository)
        merged = merge_package_input(package, write)
        self._transport.request(
            "PUT",
            f"/api/packet/{package.id}",
            json={
                "name": merged.name,
                "description": merged.description or "",
                "author": merged.author or "",
                "sync_packet": int(merged.sync_package_id or 0),
            },
        )
        return self.get(package.id)

    def delete(
        self,
        reference: Union[int, str],
        *,
        repository: Optional[Union[int, str, Repository]] = None,
    ) -> None:
        """Delete an entity."""

        package = self.get(reference, repository=repository)
        self._transport.request("DELETE", f"/api/packet/{package.id}")

    def ensure(
        self,
        repository: Union[int, str, Repository],
        write: PackageInput,
    ) -> Package:
        """Create or update an entity idempotently."""

        if not write.name:
            raise RepkaNotFoundError("Package name is required")
        resolved_repository = self._resolve_repository(repository)
        try:
            existing = self.get(write.name, repository=resolved_repository)
        except RepkaNotFoundError:
            return self.create(resolved_repository, write)

        if package_matches_input(existing, write):
            return existing
        return self.update(existing.id, write, repository=resolved_repository)

    def browse_url(
        self,
        reference: Union[int, str],
        *,
        repository: Optional[Union[int, str, Repository]] = None,
    ) -> str:
        """Return the UI URL for an entity."""

        package = self.get(reference, repository=repository)
        return build_ui_url(self._transport.base_url, "package", package.id)


class AsyncPackageService:
    """Asynchronous service for package operations."""

    def __init__(
        self,
        transport: AsyncTransport,
        repositories: AsyncRepositoryService,
    ) -> None:
        self._transport = transport
        self._repositories = repositories

    async def _resolve_repository(
        self,
        repository: Union[int, str, Repository],
    ) -> Repository:
        if isinstance(repository, Repository):
            return repository
        return await self._repositories.get(repository)

    async def list(
        self,
        repository: Optional[Union[int, str, Repository]] = None,
        *,
        sort: Optional[str] = None,
        filter_text: Optional[str] = None,
    ) -> List[Package]:
        """Return matching entities."""

        resolved_repository = await self._resolve_repository(repository)
        params = {"repository": resolved_repository.id}
        if sort:
            params["sort"] = sort
        if filter_text:
            params["filter"] = filter_text
        data = await self._transport.request(
            "GET", "/api/packet", params=params
        )
        return [
            parse_package(
                item,
                repository_id=resolved_repository.id,
                repository_type=resolved_repository.type,
            )
            for item in data
        ]

    async def get(
        self,
        reference: Union[int, str],
        *,
        repository: Optional[Union[int, str, Repository]] = None,
    ) -> Package:
        """Return one entity by ID, URL, or name."""

        package_id = parse_reference_id(reference, "package")
        if package_id is not None:
            data = await self._transport.request(
                "GET", f"/api/packet/{package_id}"
            )
            return parse_package(data)

        if repository is None:
            raise RepkaConfigurationError(
                "Repository is required for package lookup by name"
            )
        packages = await self.list(
            repository=repository, filter_text=str(reference)
        )
        return ensure_exact_name_match(packages, "Package", str(reference))

    async def create(
        self,
        repository: Union[int, str, Repository],
        write: PackageInput,
    ) -> Package:
        """Create an entity."""

        resolved_repository = await self._resolve_repository(repository)
        payload = build_package_payload(resolved_repository.id, write)
        created = await self._transport.request(
            "POST",
            "/api/packet",
            json=payload,
            expected_status=[201],
        )
        return await self.get(int(created["id"]))

    async def update(
        self,
        reference: Union[int, str],
        write: PackageInput,
        *,
        repository: Optional[Union[int, str, Repository]] = None,
    ) -> Package:
        """Update an entity."""

        package = await self.get(reference, repository=repository)
        merged = merge_package_input(package, write)
        await self._transport.request(
            "PUT",
            f"/api/packet/{package.id}",
            json={
                "name": merged.name,
                "description": merged.description or "",
                "author": merged.author or "",
                "sync_packet": int(merged.sync_package_id or 0),
            },
        )
        return await self.get(package.id)

    async def delete(
        self,
        reference: Union[int, str],
        *,
        repository: Optional[Union[int, str, Repository]] = None,
    ) -> None:
        """Delete an entity."""

        package = await self.get(reference, repository=repository)
        await self._transport.request("DELETE", f"/api/packet/{package.id}")

    async def ensure(
        self,
        repository: Union[int, str, Repository],
        write: PackageInput,
    ) -> Package:
        """Create or update an entity idempotently."""

        if not write.name:
            raise RepkaNotFoundError("Package name is required")
        resolved_repository = await self._resolve_repository(repository)
        try:
            existing = await self.get(
                write.name, repository=resolved_repository
            )
        except RepkaNotFoundError:
            return await self.create(resolved_repository, write)

        if package_matches_input(existing, write):
            return existing
        return await self.update(
            existing.id,
            write,
            repository=resolved_repository,
        )

    async def browse_url(
        self,
        reference: Union[int, str],
        *,
        repository: Optional[Union[int, str, Repository]] = None,
    ) -> str:
        """Return the UI URL for an entity."""

        package = await self.get(reference, repository=repository)
        return build_ui_url(self._transport.base_url, "package", package.id)
