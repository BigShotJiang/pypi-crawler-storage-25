from __future__ import annotations

from typing import Any
from typing import Dict
from typing import Iterable
from typing import List
from typing import Optional
from typing import Sequence
from typing import Union

from ..exceptions import RepkaAmbiguousResultError
from ..exceptions import RepkaConfigurationError
from ..exceptions import RepkaNotFoundError
from ..exceptions import RepkaValidationError
from ..models import Asset
from ..models import Package
from ..models import PackageInput
from ..models import Permission
from ..models import Release
from ..models import ReleaseAssetInput
from ..models import ReleaseOptions
from ..models import ReleaseInput
from ..models import Repository
from ..models import RepositoryOptions
from ..models import RepositoryType
from ..models import RepositoryInput
from ..models import SPECIAL_RELEASE_TAGS
from ..models import SignKey
from ..models import UserInfo
from ..models import normalize_asset_inputs
from ..models import normalize_tags
from ..models import parse_datetime
from ..models import sort_assets
from ..url_parser import is_numeric_reference
from ..url_parser import parse_repka_url


def parse_reference_id(
    reference: Union[int, str],
    expected_entity: str,
) -> Optional[int]:
    """Parse an ID from a numeric reference or Repka URL."""

    if is_numeric_reference(reference):
        return int(str(reference).strip())

    parsed = parse_repka_url(str(reference))
    if parsed is None:
        return None
    if parsed.entity_type != expected_entity:
        raise RepkaValidationError(
            f"Expected {expected_entity} reference, got {parsed.entity_type}"
        )
    return parsed.entity_id


def require_single_match(items: Sequence[Any], label: str) -> Any:
    """Return the only item or raise a lookup error."""

    if not items:
        raise RepkaNotFoundError(f"{label} not found")
    if len(items) > 1:
        raise RepkaAmbiguousResultError(f"{label} is ambiguous")
    return items[0]


def filter_exact_name(items: Sequence[Any], name: str) -> List[Any]:
    """Return items with a case-insensitive exact name match."""

    expected = name.strip().lower()
    return [
        item
        for item in items
        if getattr(item, "name", "").strip().lower() == expected
    ]


def parse_sign_key(data: Optional[Dict[str, Any]]) -> Optional[SignKey]:
    """Parse signing key metadata from API data."""

    if not data:
        return None
    return SignKey(
        public_key=str(data.get("pub", "")),
        fingerprint=str(data.get("fpr", "")),
    )


def parse_permissions(
    data: Optional[Iterable[Dict[str, Any]]],
) -> List[Permission]:
    """Parse permission entries from API data."""

    return [
        Permission(
            id=int(item.get("id", 0)),
            type=int(item.get("type", 0)),
            name=str(item.get("name", "")),
            login=str(item.get("login", "")),
        )
        for item in data or []
    ]


def parse_repository_options(
    data: Optional[Iterable[Dict[str, Any]]],
) -> RepositoryOptions:
    """Parse repository options from API data."""

    mapping: Dict[str, Any] = {}
    for item in data or []:
        key = item.get("key")
        value = item.get("value")
        if key is None:
            continue
        mapping[str(key)] = value
    return RepositoryOptions.from_mapping(mapping)


def parse_asset(data: Dict[str, Any]) -> Asset:
    """Parse asset metadata from API data."""

    return Asset(
        id=int(data.get("id")) if data.get("id") is not None else None,
        name=str(data.get("name", "")),
        description=str(data.get("description", "")),
        size=int(data.get("size", 0) or 0),
        downloads=int(data.get("downloads", 0) or 0),
    )


def parse_release(
    data: Dict[str, Any],
    *,
    package_id: Optional[int] = None,
) -> Release:
    """Parse release metadata from API data."""

    assets = [parse_asset(item) for item in data.get("files", []) or []]
    return Release(
        id=int(data["id"]),
        name=str(data.get("name", "")),
        description=str(data.get("description", "")),
        tags=normalize_tags(data.get("tags", [])),
        options=ReleaseOptions.from_pairs(data.get("options", [])),
        assets=assets,
        downloads=int(data.get("downloads", 0) or 0),
        created=parse_datetime(data.get("created")),
        updated=parse_datetime(data.get("updated")),
        package_id=package_id,
    )


def parse_package(
    data: Dict[str, Any],
    *,
    repository_id: Optional[int] = None,
    repository_type: Optional[RepositoryType] = None,
) -> Package:
    """Parse package metadata from API data."""

    nested_repository_id = data.get("repo_id")
    nested_repository_type = data.get("repo_type")
    releases = [
        parse_release(item, package_id=int(data["id"]))
        for item in data.get("releases", []) or []
    ]
    package_repository_type = repository_type
    if nested_repository_type is not None:
        package_repository_type = RepositoryType.from_value(
            nested_repository_type
        )

    return Package(
        id=int(data["id"]),
        name=str(data.get("name", "")),
        description=str(data.get("description", "")),
        author=str(data.get("author", "")),
        owner=str(data.get("owner", "")),
        repository_id=int(nested_repository_id)
        if nested_repository_id is not None
        else repository_id,
        repository_type=package_repository_type,
        key=str(data.get("key", "")),
        sync_package_id=int(data.get("sync_packet", 0) or 0),
        created=parse_datetime(data.get("created")),
        updated=parse_datetime(data.get("updated")),
        releases=releases,
    )


def parse_repository(data: Dict[str, Any]) -> Repository:
    """Parse repository metadata from API data."""

    repository_id = int(data["id"])
    repository_type = RepositoryType.from_value(data.get("type", 0))
    packages = [
        parse_package(
            item, repository_id=repository_id, repository_type=repository_type
        )
        for item in data.get("packets", []) or []
    ]
    return Repository(
        id=repository_id,
        name=str(data.get("name", "")),
        description=str(data.get("description", "")),
        type=repository_type or RepositoryType.ANY,
        options=parse_repository_options(data.get("options", [])),
        created=parse_datetime(data.get("created")),
        updated=parse_datetime(data.get("updated")),
        link=str(data.get("link", "")),
        key=parse_sign_key(data.get("key")),
        owner=str(data.get("owner", "")),
        packages=packages,
        permissions=parse_permissions(data.get("permissions", [])),
    )


def parse_user(data: Dict[str, Any]) -> UserInfo:
    """Parse user metadata from API data."""

    groups = [
        str(item.get("name", ""))
        for item in data.get("groups", []) or []
        if item.get("name")
    ]
    return UserInfo(
        id=int(data.get("id", 0) or 0),
        login=str(data.get("login", "")),
        name=str(data.get("name", "")),
        nextgis_guid=str(data.get("nextgis_guid", "")),
        login_type=int(data.get("login_type", 0) or 0),
        email=str(data.get("email", "")),
        locale=str(data.get("locale", "")),
        groups=groups,
        created=parse_datetime(data.get("created")),
        updated=parse_datetime(data.get("updated")),
    )


def serialize_permissions(
    permissions: Sequence[Permission],
) -> List[Dict[str, int]]:
    """Serialize permissions for API payloads."""

    return [
        {"id": int(permission.id), "type": int(permission.type)}
        for permission in permissions
    ]


def serialize_repository_options(options: RepositoryOptions) -> Dict[str, Any]:
    """Serialize repository options for API payloads."""

    return {
        "cleanup": bool(options.cleanup),
        "keep_releases": int(options.keep_releases),
        "ttl": int(options.ttl),
    }


def serialize_release_assets(
    assets: Sequence[ReleaseAssetInput],
) -> List[Dict[str, Any]]:
    """Serialize release assets for API payloads."""

    serialized: List[Dict[str, Any]] = []
    for asset in sort_assets(list(assets)):
        item: Dict[str, Any] = {
            "name": asset.name,
            "description": asset.description,
        }
        if asset.id is not None:
            item["id"] = int(asset.id)
        if asset.upload_name:
            item["upload_name"] = asset.upload_name
        serialized.append(item)
    return serialized


def repository_matches_input(
    repository: Repository,
    write: RepositoryInput,
) -> bool:
    """Check whether a repository already matches input fields."""

    if write.name is not None and repository.name != write.name:
        return False
    if (
        write.description is not None
        and repository.description != write.description
    ):
        return False
    if (
        write.repository_type is not None
        and repository.type != write.repository_type
    ):
        return False
    if write.options is not None and repository.options != write.options:
        return False
    if write.permissions is not None:
        current = sorted(
            [(item.id, item.type) for item in repository.permissions],
            key=lambda item: item[0],
        )
        desired = sorted(
            [(item.id, item.type) for item in write.permissions],
            key=lambda item: item[0],
        )
        if current != desired:
            return False
    return True


def package_matches_input(package: Package, write: PackageInput) -> bool:
    """Check whether a package already matches input fields."""

    if write.name is not None and package.name != write.name:
        return False
    if (
        write.description is not None
        and package.description != write.description
    ):
        return False
    if write.author is not None and package.author != write.author:
        return False
    if (
        write.sync_package_id is not None
        and package.sync_package_id != write.sync_package_id
    ):
        return False
    return True


def _asset_inputs_from_assets(
    assets: Sequence[Asset],
) -> List[ReleaseAssetInput]:
    return [ReleaseAssetInput.from_asset(asset) for asset in assets]


def release_matches_input(release: Release, write: ReleaseInput) -> bool:
    """Check whether a release already matches input fields."""

    if write.name is not None and release.name != write.name:
        return False
    if (
        write.description is not None
        and release.description != write.description
    ):
        return False
    if write.tags is not None and normalize_tags(
        release.tags
    ) != normalize_tags(write.tags):
        return False
    if write.options is not None and release.options != write.options:
        return False
    if write.assets is not None:
        current_assets = serialize_release_assets(
            _asset_inputs_from_assets(release.assets)
        )
        desired_assets = serialize_release_assets(write.assets)
        if current_assets != desired_assets:
            return False
    return True


def merge_repository_input(
    repository: Repository,
    write: RepositoryInput,
) -> RepositoryInput:
    """Merge partial repository input with existing repository data."""

    return RepositoryInput(
        name=repository.name if write.name is None else write.name,
        description=(
            repository.description
            if write.description is None
            else write.description
        ),
        repository_type=repository.type
        if write.repository_type is None
        else write.repository_type,
        options=repository.options if write.options is None else write.options,
        permissions=repository.permissions
        if write.permissions is None
        else write.permissions,
    )


def merge_package_input(package: Package, write: PackageInput) -> PackageInput:
    """Merge partial package input with existing package data."""

    return PackageInput(
        name=package.name if write.name is None else write.name,
        description=package.description
        if write.description is None
        else write.description,
        author=package.author if write.author is None else write.author,
        sync_package_id=(
            package.sync_package_id
            if write.sync_package_id is None
            else write.sync_package_id
        ),
    )


def merge_release_input(release: Release, write: ReleaseInput) -> ReleaseInput:
    """Merge partial release input with existing release data."""

    return ReleaseInput(
        name=release.name if write.name is None else write.name,
        description=release.description
        if write.description is None
        else write.description,
        tags=list(release.tags)
        if write.tags is None
        else normalize_tags(write.tags),
        options=release.options.copy()
        if write.options is None
        else write.options.copy(),
        assets=(
            _asset_inputs_from_assets(release.assets)
            if write.assets is None
            else write.assets
        ),
    )


def enrich_release_assets(
    release: Release,
    write: ReleaseInput,
) -> ReleaseInput:
    """Merge release assets by name, replacing same-name assets."""

    assets = normalize_asset_inputs(write.assets)
    if assets is None:
        return write

    merged_assets = _asset_inputs_from_assets(release.assets)
    indexes = {asset.name: index for index, asset in enumerate(merged_assets)}
    for asset in assets:
        index = indexes.get(asset.name)
        if index is None:
            indexes[asset.name] = len(merged_assets)
            merged_assets.append(asset)
        else:
            merged_assets[index] = asset

    return ReleaseInput(
        name=write.name,
        description=write.description,
        tags=list(write.tags) if write.tags is not None else None,
        options=write.options.copy() if write.options is not None else None,
        assets=merged_assets,
    )


def build_repository_payload(write: RepositoryInput) -> Dict[str, Any]:
    """Build an API payload for repository create or update."""

    if not write.name:
        raise RepkaConfigurationError("Repository name is required")
    if write.repository_type is None:
        raise RepkaConfigurationError("Repository type is required")
    if write.options is None:
        raise RepkaConfigurationError("Repository options are required")
    if write.permissions is None:
        raise RepkaConfigurationError("Repository permissions are required")
    return {
        "name": write.name,
        "description": write.description or "",
        "type": int(write.repository_type.value),
        "options": serialize_repository_options(write.options),
        "permissions": serialize_permissions(write.permissions),
    }


def build_package_payload(
    repository_id: int,
    write: PackageInput,
) -> Dict[str, Any]:
    """Build an API payload for package create or update."""

    if not write.name:
        raise RepkaConfigurationError("Package name is required")
    return {
        "name": write.name,
        "description": write.description or "",
        "author": write.author or "",
        "repository": repository_id,
        "sync_packet": int(write.sync_package_id or 0),
    }


def build_release_payload(
    write: ReleaseInput,
    *,
    package_id: Optional[int] = None,
) -> Dict[str, Any]:
    """Build an API payload for release create or update."""

    if not write.name:
        raise RepkaConfigurationError("Release name is required")
    payload: Dict[str, Any] = {
        "name": write.name,
        "description": write.description or "",
    }
    tags = normalize_tags(write.tags)
    if tags:
        payload["tags"] = tags
    if write.options is not None:
        options = write.options.to_pairs()
        if options:
            payload["options"] = options
    assets = normalize_asset_inputs(write.assets)
    if assets:
        payload["files"] = serialize_release_assets(assets)
    if package_id is not None:
        payload["packet"] = int(package_id)
    return payload


def validate_release_tags(
    tags: Sequence[str],
    *,
    version_tag: Optional[str] = None,
) -> str:
    """Validate release tags and return the version tag."""

    normalized = normalize_tags(tags)
    if not normalized:
        raise RepkaConfigurationError("Release version tag is required")

    if version_tag is not None:
        if version_tag in SPECIAL_RELEASE_TAGS:
            raise RepkaConfigurationError(
                "Release version tag cannot be a special tag"
            )
        if version_tag not in normalized:
            raise RepkaConfigurationError(
                "Release version tag must be present in release tags"
            )
        return version_tag

    for tag in reversed(normalized):
        if tag not in SPECIAL_RELEASE_TAGS:
            return tag
    raise RepkaConfigurationError("Release version tag is required")


def _sort_release_tags(
    tags: Sequence[str],
    version_tag: str,
) -> List[str]:
    normalized = normalize_tags(tags)
    result = [
        tag
        for tag in normalized
        if tag != version_tag and tag not in SPECIAL_RELEASE_TAGS
    ]
    result.append(version_tag)
    for special in ["latest", "experimental"]:
        if special in normalized:
            result.append(special)
    return result


def prepare_release_input(
    write: ReleaseInput,
    *,
    version_tag: Optional[str] = None,
    require_version_tag: bool = True,
) -> ReleaseInput:
    """Return release input with normalized and validated tags."""

    tags = normalize_tags(write.tags)
    if version_tag and version_tag not in tags:
        if tags and tags[-1] == "latest":
            tags.insert(len(tags) - 1, version_tag)
        else:
            tags.append(version_tag)
    if not tags and not require_version_tag:
        return ReleaseInput(
            name=write.name,
            description=write.description,
            tags=None,
            options=write.options,
            assets=write.assets,
        )
    resolved_version_tag = validate_release_tags(tags, version_tag=version_tag)
    tags = _sort_release_tags(tags, resolved_version_tag)
    return ReleaseInput(
        name=write.name,
        description=write.description,
        tags=tags,
        options=write.options,
        assets=write.assets,
    )


def extract_version_tag(
    write: ReleaseInput,
    explicit_version_tag: Optional[str] = None,
) -> str:
    """Return the release version tag used for idempotent lookup."""

    tags = normalize_tags(write.tags)
    if explicit_version_tag:
        if tags:
            validate_release_tags(tags, version_tag=explicit_version_tag)
        return explicit_version_tag
    return validate_release_tags(tags)


def add_latest_tag(tags: Optional[Sequence[str]]) -> List[str]:
    """Return tags with the ``latest`` tag included."""

    normalized = normalize_tags(tags)
    if "latest" not in normalized:
        normalized.append("latest")
    return normalized


def require_release_options(
    options: Optional[ReleaseOptions],
) -> ReleaseOptions:
    """Return release options or an empty option set."""

    return options.copy() if options is not None else ReleaseOptions()


def ensure_exact_name_match(
    items: Sequence[Any], label: str, name: str
) -> Any:
    """Return the only exact name match or raise a lookup error."""

    return require_single_match(filter_exact_name(items, name), label)


def release_has_latest(release: Release) -> bool:
    """Return whether a release has the ``latest`` tag."""

    return "latest" in normalize_tags(release.tags)
