from __future__ import annotations

from typing import Optional

from ..auth import AuthProvider
from ..models import UserInfo
from ..transport import AsyncTransport
from ..transport import SyncTransport
from .common import parse_user


class AuthService:
    """Synchronous service for authentication operations."""

    def __init__(
        self,
        transport: SyncTransport,
        auth_provider: Optional[AuthProvider],
    ) -> None:
        self._transport = transport
        self._auth_provider = auth_provider

    def whoami(self) -> UserInfo:
        """Return the current Repka user."""

        data = self._transport.request("GET", "/api/current_user")
        return parse_user(data)

    def login(self, username: str, password: str):
        """Authenticate through the server session endpoint."""

        return self._transport.request(
            "POST",
            "/api/login",
            json={"username": username, "password": password},
        )

    def logout(self) -> None:
        """Invalidate the current server session."""

        self._transport.request("GET", "/api/logout")

    def configured_username(self) -> Optional[str]:
        """Return the username from the auth provider."""

        if self._auth_provider is None:
            return None
        return self._auth_provider.get_username()


class AsyncAuthService:
    """Asynchronous service for authentication operations."""

    def __init__(
        self,
        transport: AsyncTransport,
        auth_provider: Optional[AuthProvider],
    ) -> None:
        self._transport = transport
        self._auth_provider = auth_provider

    async def whoami(self) -> UserInfo:
        """Return the current Repka user."""

        data = await self._transport.request("GET", "/api/current_user")
        return parse_user(data)

    async def login(self, username: str, password: str):
        """Authenticate through the server session endpoint."""

        return await self._transport.request(
            "POST",
            "/api/login",
            json={"username": username, "password": password},
        )

    async def logout(self) -> None:
        """Invalidate the current server session."""

        await self._transport.request("GET", "/api/logout")

    def configured_username(self) -> Optional[str]:
        """Return the username from the auth provider."""

        if self._auth_provider is None:
            return None
        return self._auth_provider.get_username()
