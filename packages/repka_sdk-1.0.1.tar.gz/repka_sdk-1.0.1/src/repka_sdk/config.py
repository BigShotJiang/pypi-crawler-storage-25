from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Dict
from typing import List
from typing import Optional
from urllib.parse import urlparse

import keyring
from dotenv import dotenv_values
from dotenv import set_key
from dotenv import unset_key

from .exceptions import RepkaValidationError
from .models import ServerConfig
from ._logging import get_logger


ENV_SERVER_NAME = "REPKA_SERVER_NAME"
ENV_SERVER_URL = "REPKA_SERVER_URL"
ENV_USERNAME = "REPKA_USERNAME"
ENV_PASSWORD = "REPKA_PASSWORD"
ENV_DEFAULT_SERVER = "REPKA_DEFAULT_SERVER"

CONFIG_FOLDER_NAME = "repka-sdk"
CONFIG_FILE_NAME = "servers.json"
DEFAULT_DOTENV_PATH = ".env"
DEFAULT_SERVER_NAME = "nextgis"
DEFAULT_SERVER_URL = "https://rm.nextgis.com"
BUILTIN_SOURCE = "builtin"
DOTENV_SERVER_NAME = "dotenv"
RESERVED_SERVER_NAMES = {DEFAULT_SERVER_NAME, DOTENV_SERVER_NAME}
logger = get_logger(__name__)


@dataclass
class ResolvedConfiguration:
    """Resolved server and credentials configuration."""

    server: Optional[ServerConfig]
    username: Optional[str]
    password: Optional[str]
    source: Optional[str]


def get_config_dir(custom_config_dir: Optional[Path] = None) -> Path:
    """Return the directory that stores Repka SDK configuration."""

    if custom_config_dir is not None:
        return custom_config_dir

    xdg_config_home = os.environ.get("XDG_CONFIG_HOME")
    if xdg_config_home:
        return Path(xdg_config_home) / CONFIG_FOLDER_NAME
    return Path.home() / ".config" / CONFIG_FOLDER_NAME


def get_config_file(custom_config_dir: Optional[Path] = None) -> Path:
    """Return the JSON configuration file path."""

    return get_config_dir(custom_config_dir) / CONFIG_FILE_NAME


def _service_name(server_name: str) -> str:
    return f"repka-sdk:{server_name}"


def _dotenv_path(dotenv_path: Optional[Path] = None) -> Path:
    return Path(dotenv_path or DEFAULT_DOTENV_PATH)


def default_server_config() -> ServerConfig:
    """Return the built-in NextGIS Repka server."""

    return ServerConfig(
        name=DEFAULT_SERVER_NAME,
        url=DEFAULT_SERVER_URL,
        default=True,
    )


def validate_server_url(url: str) -> str:
    """Return a normalized HTTP(S) URL or raise a validation error."""

    normalized = str(url or "").strip().rstrip("/")
    parsed = urlparse(normalized)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise RepkaValidationError(
            "Server URL must be an absolute http or https URL"
        )
    return normalized


def _load_config_data(
    custom_config_dir: Optional[Path] = None,
) -> Dict[str, object]:
    config_file = get_config_file(custom_config_dir)
    if not config_file.exists():
        return {"servers": []}

    with config_file.open("r", encoding="utf-8") as stream:
        data = json.load(stream)
    if "servers" not in data:
        data["servers"] = []
    return data


def _save_config_data(
    data: Dict[str, object],
    custom_config_dir: Optional[Path] = None,
) -> None:
    config_dir = get_config_dir(custom_config_dir)
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = get_config_file(custom_config_dir)
    with config_file.open("w", encoding="utf-8") as stream:
        json.dump(data, stream, indent=2, sort_keys=True)


def list_system_servers(
    custom_config_dir: Optional[Path] = None,
) -> List[ServerConfig]:
    """Return servers saved in the user configuration."""

    data = _load_config_data(custom_config_dir)
    result: List[ServerConfig] = []
    for item in data.get("servers", []):
        result.append(
            ServerConfig(
                name=item["name"],
                url=item["url"],
                default=bool(item.get("default", False)),
                username=item.get("username"),
            )
        )
    return result


def save_system_server(
    server: ServerConfig,
    custom_config_dir: Optional[Path] = None,
) -> None:
    """Save or update a server in the user configuration."""

    logger.info("Saving server configuration %s", server.name)
    if server.name == DOTENV_SERVER_NAME:
        raise ValueError("Server name is reserved: dotenv")
    server.url = validate_server_url(server.url)
    data = _load_config_data(custom_config_dir)
    servers = list(data.get("servers", []))
    updated = False
    if server.default:
        for item in servers:
            item["default"] = False

    for item in servers:
        if item["name"] == server.name:
            item.update(
                {
                    "name": server.name,
                    "url": server.url,
                    "default": server.default,
                    "username": server.username,
                }
            )
            updated = True
            break

    if not updated:
        servers.append(
            {
                "name": server.name,
                "url": server.url,
                "default": server.default,
                "username": server.username,
            }
        )

    data["servers"] = servers
    _save_config_data(data, custom_config_dir)


def remove_system_server(
    server_name: str,
    custom_config_dir: Optional[Path] = None,
) -> ServerConfig:
    """Remove a server from the user configuration."""

    logger.info("Removing server configuration %s", server_name)
    data = _load_config_data(custom_config_dir)
    servers = list(data.get("servers", []))
    removed: Optional[ServerConfig] = None
    kept = []
    for item in servers:
        if item["name"] == server_name:
            removed = ServerConfig(
                name=item["name"],
                url=item["url"],
                default=bool(item.get("default", False)),
                username=item.get("username"),
            )
            continue
        kept.append(item)
    if removed is None:
        raise ValueError(f"Unknown server: {server_name}")
    data["servers"] = kept
    _save_config_data(data, custom_config_dir)
    return removed


def rename_system_server(
    old_name: str,
    new_name: str,
    custom_config_dir: Optional[Path] = None,
) -> ServerConfig:
    """Rename a server in the user configuration."""

    logger.info("Renaming server configuration %s to %s", old_name, new_name)
    if new_name in RESERVED_SERVER_NAMES:
        raise ValueError(f"Server name is reserved: {new_name}")
    data = _load_config_data(custom_config_dir)
    servers = list(data.get("servers", []))
    for item in servers:
        if item["name"] == new_name:
            raise ValueError(f"Server already exists: {new_name}")

    renamed: Optional[ServerConfig] = None
    for item in servers:
        if item["name"] != old_name:
            continue
        item["name"] = new_name
        renamed = ServerConfig(
            name=item["name"],
            url=item["url"],
            default=bool(item.get("default", False)),
            username=item.get("username"),
        )
        break
    if renamed is None:
        raise ValueError(f"Unknown server: {old_name}")
    data["servers"] = servers
    _save_config_data(data, custom_config_dir)
    return renamed


def set_default_server(
    server_name: str,
    custom_config_dir: Optional[Path] = None,
) -> ServerConfig:
    """Mark a saved server as the default one."""

    if server_name == DEFAULT_SERVER_NAME:
        data = _load_config_data(custom_config_dir)
        servers = list(data.get("servers", []))
        for item in servers:
            item["default"] = False
        data["servers"] = servers
        _save_config_data(data, custom_config_dir)
        return default_server_config()

    servers = list_system_servers(custom_config_dir)
    selected: Optional[ServerConfig] = None
    for server in servers:
        server.default = server.name == server_name
        if server.default:
            selected = server
        save_system_server(server, custom_config_dir)

    if selected is None:
        raise ValueError(f"Unknown server: {server_name}")
    return selected


def get_system_server(
    server_name: Optional[str] = None,
    custom_config_dir: Optional[Path] = None,
) -> Optional[ServerConfig]:
    """Return a configured server by name, URL, or explicit default selection."""

    servers = list_system_servers(custom_config_dir)
    if server_name:
        for server in servers:
            if server.name == server_name or server.url == server_name:
                return server
        return None

    for server in servers:
        if server.default:
            return server
    return None


def store_system_credentials(
    server_name: str,
    username: str,
    password: str,
    custom_config_dir: Optional[Path] = None,
) -> None:
    """Store credentials for a configured server in the system keyring."""

    keyring.set_password(_service_name(server_name), username, password)
    server = get_system_server(server_name, custom_config_dir)
    if server is not None:
        server.username = username
        save_system_server(server, custom_config_dir)


def remove_system_credentials(
    server_name: str,
    custom_config_dir: Optional[Path] = None,
) -> None:
    """Remove saved keyring credentials for a configured server."""

    server = get_system_server(server_name, custom_config_dir)
    if server is None or not server.username:
        return
    try:
        keyring.delete_password(_service_name(server_name), server.username)
    except keyring.errors.PasswordDeleteError:
        pass
    server.username = None
    save_system_server(server, custom_config_dir)


def read_dotenv_config(dotenv_path: Optional[Path] = None) -> Dict[str, str]:
    """Read Repka configuration variables from a dotenv file."""

    path = _dotenv_path(dotenv_path)
    if not path.exists():
        return {}
    values = dotenv_values(str(path))
    return {
        str(key): str(value)
        for key, value in values.items()
        if value is not None
    }


def get_dotenv_server(
    dotenv_path: Optional[Path] = None,
) -> Optional[ServerConfig]:
    """Return the reserved dotenv server when it is configured."""

    values = read_dotenv_config(dotenv_path)
    server_url = values.get(ENV_SERVER_URL)
    if not server_url:
        return None
    return ServerConfig(
        name=DOTENV_SERVER_NAME,
        url=server_url,
        default=True,
        username=values.get(ENV_USERNAME),
    )


def write_dotenv_server(
    server: ServerConfig,
    dotenv_path: Optional[Path] = None,
) -> Path:
    """Write only the dotenv server URL."""

    path = _dotenv_path(dotenv_path)
    if not path.exists():
        path.touch()
    server.url = validate_server_url(server.url)
    values = read_dotenv_config(path)
    for variable in [ENV_SERVER_NAME, ENV_DEFAULT_SERVER]:
        _unset_dotenv_key(path, variable, values)
    set_key(str(path), ENV_SERVER_URL, server.url)
    if server.username is not None:
        set_key(str(path), ENV_USERNAME, server.username)
    return path


def write_env_credentials(
    server: ServerConfig,
    username: str,
    password: str,
    dotenv_path: Optional[Path] = None,
) -> Path:
    """Write dotenv server URL and credential values."""

    path = write_dotenv_server(server, dotenv_path)
    set_key(str(path), ENV_USERNAME, username)
    set_key(str(path), ENV_PASSWORD, password)
    return path


def remove_env_credentials(dotenv_path: Optional[Path] = None) -> Path:
    """Remove Repka credential variables from a dotenv file."""

    path = _dotenv_path(dotenv_path)
    if not path.exists():
        return path
    values = read_dotenv_config(path)
    for variable in [
        ENV_SERVER_NAME,
        ENV_DEFAULT_SERVER,
        ENV_USERNAME,
        ENV_PASSWORD,
    ]:
        _unset_dotenv_key(path, variable, values)
    return path


def remove_dotenv_server(dotenv_path: Optional[Path] = None) -> Path:
    """Remove the reserved dotenv server and its credentials."""

    path = remove_env_credentials(dotenv_path)
    if not path.exists():
        return path
    values = read_dotenv_config(path)
    for variable in [ENV_SERVER_NAME, ENV_SERVER_URL, ENV_DEFAULT_SERVER]:
        _unset_dotenv_key(path, variable, values)
    return path


def _unset_dotenv_key(
    path: Path,
    variable: str,
    values: Dict[str, str],
) -> None:
    if variable not in values:
        logger.debug(
            "Key %s not removed from %s - key doesn't exist.",
            variable,
            path,
        )
        return
    unset_key(str(path), variable)


def _server_matches(
    server_name: Optional[str],
    candidate_name: Optional[str],
    candidate_url: Optional[str],
) -> bool:
    if not server_name:
        return True
    return server_name in {candidate_name, candidate_url}


def resolve_configuration(
    server_name: Optional[str] = None,
    *,
    dotenv_path: Optional[Path] = None,
    custom_config_dir: Optional[Path] = None,
) -> ResolvedConfiguration:
    """Resolve runtime configuration from dotenv, environment, or system data."""

    logger.debug(
        "Resolving configuration for server %s", server_name or "<default>"
    )
    dotenv_values_map = read_dotenv_config(dotenv_path)
    dotenv_server_url = dotenv_values_map.get(ENV_SERVER_URL)
    if server_name == DOTENV_SERVER_NAME and not dotenv_server_url:
        return ResolvedConfiguration(
            server=None,
            username=None,
            password=None,
            source=None,
        )
    if dotenv_server_url and _server_matches(
        server_name,
        DOTENV_SERVER_NAME,
        dotenv_server_url,
    ):
        return ResolvedConfiguration(
            server=ServerConfig(
                name=DOTENV_SERVER_NAME,
                url=dotenv_server_url,
                default=True,
                username=dotenv_values_map.get(ENV_USERNAME),
            ),
            username=dotenv_values_map.get(ENV_USERNAME),
            password=dotenv_values_map.get(ENV_PASSWORD),
            source="dotenv",
        )

    if server_name == DEFAULT_SERVER_NAME:
        system_server = get_system_server(server_name, custom_config_dir)
        server = system_server or default_server_config()
        password = None
        if server.username:
            password = keyring.get_password(
                _service_name(server.name), server.username
            )
        return ResolvedConfiguration(
            server=server,
            username=server.username,
            password=password,
            source="system" if system_server else BUILTIN_SOURCE,
        )

    env_server_url = os.environ.get(ENV_SERVER_URL)
    env_server_name = os.environ.get(ENV_SERVER_NAME) or os.environ.get(
        ENV_DEFAULT_SERVER
    )
    if env_server_url and _server_matches(
        server_name, env_server_name, env_server_url
    ):
        return ResolvedConfiguration(
            server=ServerConfig(
                name=env_server_name or "env",
                url=env_server_url,
                default=True,
                username=os.environ.get(ENV_USERNAME),
            ),
            username=os.environ.get(ENV_USERNAME),
            password=os.environ.get(ENV_PASSWORD),
            source="env",
        )

    server = get_system_server(server_name, custom_config_dir)
    if server is None:
        if server_name is None:
            return ResolvedConfiguration(
                server=default_server_config(),
                username=None,
                password=None,
                source=BUILTIN_SOURCE,
            )
        return ResolvedConfiguration(
            server=None,
            username=None,
            password=None,
            source=None,
        )

    password = None
    if server.username:
        password = keyring.get_password(
            _service_name(server.name), server.username
        )
    return ResolvedConfiguration(
        server=server,
        username=server.username,
        password=password,
        source="system",
    )
