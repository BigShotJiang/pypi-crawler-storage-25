from __future__ import annotations

from typing import Any, Optional


class RepkaError(Exception):
    """Base exception for Repka SDK errors."""

    def __init__(
        self,
        message: str,
        *,
        status_code: Optional[int] = None,
        details: Optional[Any] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.details = details


class RepkaTransportError(RepkaError):
    """Transport-level Repka SDK error."""

    pass


class RepkaAuthError(RepkaError):
    """Authentication Repka SDK error."""

    pass


class RepkaPermissionError(RepkaError):
    """Permission Repka SDK error."""

    pass


class RepkaNotFoundError(RepkaError):
    """Missing entity Repka SDK error."""

    pass


class RepkaConflictError(RepkaError):
    """Conflict Repka SDK error."""

    pass


class RepkaValidationError(RepkaError):
    """Validation Repka SDK error."""

    pass


class RepkaServerError(RepkaError):
    """Server-side Repka SDK error."""

    pass


class RepkaAmbiguousResultError(RepkaError):
    """Ambiguous lookup Repka SDK error."""

    pass


class RepkaConfigurationError(RepkaError):
    """Configuration Repka SDK error."""

    pass


def exception_from_status(
    status_code: int,
    message: str,
    *,
    details: Optional[Any] = None,
) -> RepkaError:
    """Create a Repka exception for an HTTP status code."""

    if status_code == 400 or status_code == 422:
        return RepkaValidationError(
            message,
            status_code=status_code,
            details=details,
        )
    if status_code == 401:
        return RepkaAuthError(
            message,
            status_code=status_code,
            details=details,
        )
    if status_code == 403:
        return RepkaPermissionError(
            message,
            status_code=status_code,
            details=details,
        )
    if status_code == 404:
        return RepkaNotFoundError(
            message,
            status_code=status_code,
            details=details,
        )
    if status_code == 409:
        return RepkaConflictError(
            message,
            status_code=status_code,
            details=details,
        )
    if status_code >= 500:
        return RepkaServerError(
            message,
            status_code=status_code,
            details=details,
        )
    return RepkaTransportError(
        message,
        status_code=status_code,
        details=details,
    )
