from __future__ import annotations

from typing import Optional

from .auth import AuthProvider
from .config import DEFAULT_SERVER_URL
from ._logging import get_logger
from .services.admin import AdminService
from .services.assets import AssetService
from .services.auth import AuthService
from .services.packages import PackageService
from .services.release_search import SearchService
from .services.releases import ReleaseService
from .services.repositories import RepositoryService
from .services.server import ServerService
from .services.sync import SyncService
from .transport import SyncTransport

logger = get_logger(__name__)


class RepkaClient:
    """Synchronous entry point for Repka API operations."""

    def __init__(
        self,
        base_url: str = DEFAULT_SERVER_URL,
        *,
        auth_provider: Optional[AuthProvider] = None,
        timeout: float = 30.0,
        verify: bool = True,
        retries: int = 2,
    ) -> None:
        """Create a client bound to a Repka server."""

        logger.debug("Initializing RepkaClient for %s", base_url)
        self.transport = SyncTransport(
            base_url,
            auth_provider=auth_provider,
            timeout=timeout,
            verify=verify,
            retries=retries,
        )
        self.repositories = RepositoryService(self.transport)
        self.packages = PackageService(self.transport, self.repositories)
        self.assets = AssetService(self.transport)
        self.admin = AdminService(self.transport)
        self.server = ServerService(self.transport)
        self.sync = SyncService(self.transport)
        self.releases = ReleaseService(
            self.transport,
            self.repositories,
            self.packages,
            self.assets,
        )
        self.auth = AuthService(self.transport, auth_provider)
        self.search = SearchService(
            self.repositories,
            self.packages,
            self.releases,
        )

    def close(self) -> None:
        """Close the underlying HTTP transport."""

        logger.debug("Closing RepkaClient")
        self.transport.close()

    def __enter__(self) -> "RepkaClient":
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        self.close()
