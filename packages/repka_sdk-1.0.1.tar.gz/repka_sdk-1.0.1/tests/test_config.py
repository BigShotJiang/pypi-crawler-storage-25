from __future__ import annotations

from pathlib import Path

from repka_sdk.config import ENV_DEFAULT_SERVER
from repka_sdk.config import ENV_PASSWORD
from repka_sdk.config import ENV_SERVER_NAME
from repka_sdk.config import ENV_SERVER_URL
from repka_sdk.config import ENV_USERNAME
from repka_sdk.config import BUILTIN_SOURCE
from repka_sdk.config import read_dotenv_config
from repka_sdk.config import remove_env_credentials
from repka_sdk.config import resolve_configuration
from repka_sdk.config import save_system_server
from repka_sdk.config import set_default_server
from repka_sdk.config import store_system_credentials
from repka_sdk.config import write_env_credentials
from repka_sdk.config import write_dotenv_server
from repka_sdk.models import ServerConfig


def test_configuration_precedence_dotenv_over_env_and_system(
    tmp_path: Path,
    monkeypatch,
    fake_keyring,
) -> None:
    config_dir = tmp_path / "config"
    dotenv_path = tmp_path / ".env"

    save_system_server(
        ServerConfig(name="system", url="https://system.test", default=True),
        config_dir,
    )
    store_system_credentials(
        "system", "system-user", "system-pass", config_dir
    )

    monkeypatch.setenv(ENV_SERVER_URL, "https://env.test")
    monkeypatch.setenv(ENV_USERNAME, "env-user")
    monkeypatch.setenv(ENV_PASSWORD, "env-pass")

    write_env_credentials(
        ServerConfig(name="dotenv", url="https://dotenv.test"),
        "dotenv-user",
        "dotenv-pass",
        dotenv_path,
    )

    resolved = resolve_configuration(
        dotenv_path=dotenv_path,
        custom_config_dir=config_dir,
    )

    assert resolved.source == "dotenv"
    assert resolved.server is not None
    assert resolved.server.url == "https://dotenv.test"
    assert resolved.username == "dotenv-user"
    assert resolved.password == "dotenv-pass"


def test_configuration_falls_back_to_nextgis_default(
    tmp_path: Path,
) -> None:
    resolved = resolve_configuration(custom_config_dir=tmp_path / "config")

    assert resolved.source == BUILTIN_SOURCE
    assert resolved.server is not None
    assert resolved.server.url == "https://rm.nextgis.com"


def test_system_server_is_used_only_after_set_default(
    tmp_path: Path,
) -> None:
    config_dir = tmp_path / "config"
    save_system_server(
        ServerConfig(name="staging", url="https://staging.test"),
        config_dir,
    )

    fallback = resolve_configuration(custom_config_dir=config_dir)
    set_default_server("staging", config_dir)
    selected = resolve_configuration(custom_config_dir=config_dir)

    assert fallback.source == BUILTIN_SOURCE
    assert fallback.server is not None
    assert fallback.server.name == "nextgis"
    assert selected.source == "system"
    assert selected.server is not None
    assert selected.server.name == "staging"


def test_set_default_server_can_restore_builtin_nextgis(
    tmp_path: Path,
) -> None:
    config_dir = tmp_path / "config"
    save_system_server(
        ServerConfig(name="staging", url="https://staging.test"),
        config_dir,
    )
    set_default_server("staging", config_dir)

    restored = set_default_server("nextgis", config_dir)
    resolved = resolve_configuration(custom_config_dir=config_dir)

    assert restored.name == "nextgis"
    assert resolved.source == BUILTIN_SOURCE
    assert resolved.server is not None
    assert resolved.server.name == "nextgis"


def test_dotenv_uses_reserved_server_without_stored_name(
    tmp_path: Path,
) -> None:
    dotenv_path = tmp_path / ".env"
    dotenv_path.write_text(
        "REPKA_SERVER_NAME=legacy\nREPKA_DEFAULT_SERVER=legacy\n",
        encoding="utf-8",
    )

    write_env_credentials(
        ServerConfig(name="ignored", url="https://dotenv.test"),
        "dotenv-user",
        "dotenv-pass",
        dotenv_path,
    )

    values = read_dotenv_config(dotenv_path)
    assert values[ENV_SERVER_URL] == "https://dotenv.test"
    assert ENV_SERVER_NAME not in values
    assert ENV_DEFAULT_SERVER not in values

    resolved = resolve_configuration("dotenv", dotenv_path=dotenv_path)

    assert resolved.source == "dotenv"
    assert resolved.server is not None
    assert resolved.server.name == "dotenv"
    assert resolved.server.url == "https://dotenv.test"


def test_dotenv_logout_keeps_server_url(tmp_path: Path) -> None:
    dotenv_path = tmp_path / ".env"
    write_env_credentials(
        ServerConfig(name="dotenv", url="https://dotenv.test"),
        "dotenv-user",
        "dotenv-pass",
        dotenv_path,
    )

    remove_env_credentials(dotenv_path)
    values = read_dotenv_config(dotenv_path)

    assert values[ENV_SERVER_URL] == "https://dotenv.test"
    assert ENV_USERNAME not in values
    assert ENV_PASSWORD not in values


def test_missing_dotenv_keys_are_logged_not_printed(
    tmp_path: Path,
    capsys,
) -> None:
    dotenv_path = tmp_path / ".env"

    write_dotenv_server(
        ServerConfig(name="dotenv", url="https://dotenv.test"),
        dotenv_path,
    )

    captured = capsys.readouterr()
    assert captured.out == ""
    assert captured.err == ""


def test_missing_reserved_dotenv_server_is_unresolved(
    tmp_path: Path,
) -> None:
    resolved = resolve_configuration(
        "dotenv",
        dotenv_path=tmp_path / ".env",
        custom_config_dir=tmp_path / "config",
    )

    assert resolved.server is None
    assert resolved.source is None
