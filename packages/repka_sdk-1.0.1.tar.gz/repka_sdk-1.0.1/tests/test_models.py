from __future__ import annotations

from repka_sdk.models import Asset
from repka_sdk.models import Release
from repka_sdk.models import ReleaseOptions
from repka_sdk.models import Repository
from repka_sdk.models import RepositoryOptions
from repka_sdk.models import RepositoryType
from repka_sdk.models import normalize_asset_inputs
from repka_sdk.models import to_primitive
from repka_sdk.models import UploadedAsset
from repka_sdk.services.common import parse_package
from repka_sdk.services.common import parse_release


def test_release_options_subset_and_pairs() -> None:
    current = ReleaseOptions({"dist": "stable", "arch": "x64"})
    required = ReleaseOptions({"dist": "stable"})

    assert current.matches_subset(required)
    assert not required.matches_subset(current)
    assert current.to_pairs() == [
        {"key": "arch", "value": "x64"},
        {"key": "dist", "value": "stable"},
    ]


def test_to_primitive_serializes_nested_dataclasses() -> None:
    release = Release(
        id=2,
        name="1.2.3",
        tags=["1.2.3", "latest"],
        options=ReleaseOptions({"dist": "stable"}),
        assets=[Asset(id=7, name="plugin.zip", size=100)],
    )
    repository = Repository(
        id=1,
        name="test",
        type=RepositoryType.BORSCH,
        options=RepositoryOptions(cleanup=True, keep_releases=5, ttl=72),
    )

    payload = to_primitive({"repository": repository, "release": release})

    assert payload["repository"]["type"] == "borsch"
    assert payload["release"]["options"] == {"dist": "stable"}
    assert payload["release"]["assets"][0]["name"] == "plugin.zip"


def test_normalize_asset_inputs_from_uploaded_asset() -> None:
    uploaded = UploadedAsset(upload_name="temp-123", name="a.zip")

    result = normalize_asset_inputs([uploaded])

    assert result is not None
    assert result[0].upload_name == "temp-123"
    assert result[0].name == "a.zip"


def test_parsers_treat_null_nested_lists_as_empty() -> None:
    package = parse_package(
        {
            "id": 1,
            "name": "pkg",
            "releases": None,
        }
    )
    release = parse_release(
        {
            "id": 2,
            "name": "1.0.0",
            "files": None,
        }
    )

    assert package.releases == []
    assert release.assets == []
