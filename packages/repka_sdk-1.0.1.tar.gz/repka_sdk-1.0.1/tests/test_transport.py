from __future__ import annotations

import httpx
import pytest
import respx

from repka_sdk import RepkaClient
from repka_sdk.exceptions import RepkaNotFoundError
from repka_sdk.exceptions import RepkaValidationError
from repka_sdk.transport import AsyncTransport
from repka_sdk.transport import SyncTransport


def test_client_defaults_to_nextgis_server() -> None:
    client = RepkaClient()
    try:
        assert client.transport.base_url == "https://rm.nextgis.com"
    finally:
        client.close()


@respx.mock
def test_sync_transport_maps_http_errors() -> None:
    respx.get("https://rm.test/api/repo/1").mock(
        return_value=httpx.Response(
            404, json={"error": "repository not found"}
        )
    )
    transport = SyncTransport("https://rm.test")

    with pytest.raises(RepkaNotFoundError):
        transport.request("GET", "/api/repo/1")


@respx.mock
def test_sync_transport_maps_stream_http_errors() -> None:
    respx.get("https://rm.test/api/asset/15108/download").mock(
        return_value=httpx.Response(404, json={"error": "asset not found"})
    )
    transport = SyncTransport("https://rm.test")

    with pytest.raises(RepkaNotFoundError):
        with transport.stream("GET", "/api/asset/15108/download"):
            pass


@respx.mock
def test_sync_transport_sends_user_agent() -> None:
    route = respx.get("https://rm.test/api/current_user").mock(
        return_value=httpx.Response(
            200,
            json={"id": 2, "login": "editor", "name": "Editor"},
        )
    )
    transport = SyncTransport("https://rm.test")

    transport.request("GET", "/api/current_user")

    assert route.calls.last.request.headers["user-agent"].startswith(
        "repka-sdk/"
    )


def test_transport_rejects_invalid_server_url() -> None:
    with pytest.raises(RepkaValidationError):
        SyncTransport("rm.test")


@pytest.mark.asyncio
@respx.mock
async def test_async_transport_returns_json() -> None:
    respx.get("https://rm.test/api/current_user").mock(
        return_value=httpx.Response(
            200,
            json={"id": 2, "login": "editor", "name": "Editor"},
        )
    )
    transport = AsyncTransport("https://rm.test")

    payload = await transport.request("GET", "/api/current_user")

    assert payload["login"] == "editor"
    await transport.aclose()
