from __future__ import annotations

from typing import Any
from typing import Dict
from typing import List

import pytest

from repka_sdk.exceptions import RepkaConfigurationError
from repka_sdk.models import Package
from repka_sdk.models import PackageInput
from repka_sdk.models import ReleaseAssetInput
from repka_sdk.models import ReleaseOptions
from repka_sdk.models import ReleaseInput
from repka_sdk.models import Repository
from repka_sdk.models import RepositoryType
from repka_sdk.services.packages import PackageService
from repka_sdk.services.assets import AssetService
from repka_sdk.services.admin import AdminService
from repka_sdk.services.common import build_release_payload
from repka_sdk.services.releases import ReleaseService
from repka_sdk.services.repositories import RepositoryService
from repka_sdk.services.server import ServerService
from repka_sdk.services.sync import SyncService


class DummyPackageTransport:
    def __init__(self) -> None:
        self.package = {
            "id": 5,
            "name": "pkg",
            "description": "old",
            "author": "alice",
            "sync_packet": 0,
            "repo_id": 1,
            "repo_type": 3,
        }
        self.put_calls: List[Dict[str, Any]] = []
        self.post_calls: List[Dict[str, Any]] = []

    def request(self, method: str, path: str, **kwargs):
        if method == "GET" and path == "/api/packet":
            return [self.package]
        if method == "GET" and path == "/api/packet/5":
            return self.package
        if method == "PUT" and path == "/api/packet/5":
            self.put_calls.append(kwargs["json"])
            self.package.update(kwargs["json"])
            return {"message": "updated"}
        if method == "POST" and path == "/api/packet":
            self.post_calls.append(kwargs["json"])
            return {"id": 5}
        raise AssertionError(f"Unexpected call: {method} {path} {kwargs}")


class DummyRepositoryTransport:
    base_url = "https://rm.test"

    def __init__(self) -> None:
        self.calls: List[Dict[str, Any]] = []

    def request(self, method: str, path: str, **kwargs):
        self.calls.append({"method": method, "path": path, **kwargs})
        if method == "GET" and path == "/api/repo/1":
            return {
                "id": 1,
                "name": "repo",
                "type": 3,
                "options": [],
                "permissions": [],
                "packets": [],
            }
        if method == "GET" and path == "/api/repo/1/borsch":
            return {
                "id": 7,
                "name": "1.0.0",
                "tags": ["1.0.0"],
                "options": [],
                "files": [],
            }
        if method == "GET" and path == "/api/repo/1/qgis_xml":
            return b"<plugins />"
        if method == "GET" and path == "/api/repo/1/deb/key.gpg":
            return b"key"
        raise AssertionError(f"Unexpected call: {method} {path} {kwargs}")


class DummyMetadataTransport:
    def __init__(self) -> None:
        self.calls: List[Dict[str, Any]] = []

    def request(self, method: str, path: str, **kwargs):
        self.calls.append({"method": method, "path": path, **kwargs})
        if path == "/api/stats":
            return {"repositories_count": 1}
        if path == "/api/sync/3":
            return [{"id": 1, "name": "remote"}]
        if path == "/api/sync/3/repo/1":
            return [{"id": 5, "name": "pkg"}]
        if path == "/api/settings":
            return {"local": {"enable": True}}
        if path == "/api/user":
            return [{"id": 1, "login": "admin"}]
        if path == "/api/group/2":
            return {"id": 2, "name": "editors"}
        raise AssertionError(f"Unexpected call: {method} {path} {kwargs}")


class DummyAssetTransport:
    def request(self, method: str, path: str, **kwargs):
        if method == "GET" and path == "/api/asset/7/rights":
            return {"read": True, "write": False}
        raise AssertionError(f"Unexpected call: {method} {path} {kwargs}")


class DummyRepositoryService:
    def get(self, reference):
        return Repository(id=1, name="repo", type=RepositoryType.BORSCH)

    def list(self):
        return [Repository(id=1, name="repo", type=RepositoryType.BORSCH)]


class DummyReleaseTransport:
    def __init__(self) -> None:
        self.release_state = {
            1: {
                "id": 1,
                "name": "0.9.0",
                "description": "old latest",
                "tags": ["0.9.0", "latest"],
                "options": [{"key": "dist", "value": "stable"}],
                "files": [
                    {
                        "id": 11,
                        "name": "old.zip",
                        "description": "",
                        "size": 1,
                        "downloads": 0,
                    }
                ],
            },
            2: {
                "id": 2,
                "name": "1.0.0",
                "description": "candidate",
                "tags": ["1.0.0"],
                "options": [{"key": "dist", "value": "stable"}],
                "files": [
                    {
                        "id": 22,
                        "name": "new.zip",
                        "description": "",
                        "size": 1,
                        "downloads": 0,
                    }
                ],
            },
            4: {
                "id": 4,
                "name": "1.1.0",
                "description": "empty release",
                "tags": ["1.1.0"],
                "options": [{"key": "dist", "value": "stable"}],
                "files": [],
            },
        }
        self.put_calls: List[Dict[str, Any]] = []
        self.post_calls: List[Dict[str, Any]] = []
        self.delete_calls: List[int] = []

    @property
    def base_url(self) -> str:
        return "https://rm.test"

    def request(self, method: str, path: str, **kwargs):
        if method == "GET" and path == "/api/release":
            packet_id = kwargs["params"]["packet"]
            assert packet_id == 10
            return [self.release_state[1], self.release_state[2]]
        if method == "GET" and path.startswith("/api/release/"):
            release_id = int(path.rsplit("/", 1)[1])
            return self.release_state[release_id]
        if method == "PUT" and path.startswith("/api/release/"):
            release_id = int(path.rsplit("/", 1)[1])
            payload = kwargs["json"]
            self.put_calls.append({"id": release_id, "payload": payload})
            self.release_state[release_id] = {
                **self.release_state[release_id],
                "name": payload["name"],
                "description": payload["description"],
                "tags": payload.get("tags", []),
                "options": payload.get("options", []),
                "files": payload.get(
                    "files",
                    self.release_state[release_id]["files"],
                ),
            }
            return {"message": "updated"}
        if method == "POST" and path == "/api/release":
            payload = kwargs["json"]
            release_id = 3
            self.post_calls.append(payload)
            self.release_state[release_id] = {
                "id": release_id,
                "name": payload["name"],
                "description": payload["description"],
                "tags": payload.get("tags", []),
                "options": payload.get("options", []),
                "files": payload.get("files", []),
            }
            return {"id": release_id}
        if method == "DELETE" and path.startswith("/api/release/"):
            release_id = int(path.rsplit("/", 1)[1])
            self.delete_calls.append(release_id)
            self.release_state.pop(release_id, None)
            return {"message": "deleted"}
        raise AssertionError(f"Unexpected call: {method} {path} {kwargs}")


class DummyPackageService:
    def get(self, reference, repository=None):
        return Package(id=10, name="pkg")

    def list(self, repository=None):
        return [Package(id=10, name="pkg")]


def test_package_ensure_updates_when_fields_changed() -> None:
    service = PackageService(DummyPackageTransport(), DummyRepositoryService())

    updated = service.ensure(
        1,
        PackageInput(name="pkg", description="new", author="alice"),
    )

    assert updated.description == "new"


def test_repository_specialized_endpoints() -> None:
    transport = DummyRepositoryTransport()
    service = RepositoryService(transport)

    release = service.borsch_release(
        1,
        package_name="pkg",
        version_tag="1.0.0",
    )
    qgis_xml = service.qgis_xml(1)
    debian_key = service.debian_key(1)

    assert release.id == 7
    assert qgis_xml == b"<plugins />"
    assert debian_key == b"key"
    assert transport.calls[1]["params"] == {
        "packet_name": "pkg",
        "release_tag": "1.0.0",
    }


def test_server_and_sync_services() -> None:
    transport = DummyMetadataTransport()

    assert ServerService(transport).stats() == {"repositories_count": 1}
    assert SyncService(transport).list_remote_repositories("borsch") == [
        {"id": 1, "name": "remote"}
    ]
    assert SyncService(transport).list_remote_packages("borsch", 1) == [
        {"id": 5, "name": "pkg"}
    ]


def test_asset_rights() -> None:
    assert AssetService(DummyAssetTransport()).rights(7) == {
        "read": True,
        "write": False,
    }


def test_admin_service_basic_endpoints() -> None:
    transport = DummyMetadataTransport()
    service = AdminService(transport)

    assert service.settings() == {"local": {"enable": True}}
    assert service.list_users() == [{"id": 1, "login": "admin"}]
    assert service.get_group(2) == {"id": 2, "name": "editors"}


def test_release_ensure_is_idempotent_for_matching_release() -> None:
    transport = DummyReleaseTransport()
    service = ReleaseService(
        transport,
        DummyRepositoryService(),
        DummyPackageService(),
    )

    release = service.ensure(
        10,
        ReleaseInput(
            name="1.0.0",
            tags=["1.0.0"],
            options=ReleaseOptions({"dist": "stable"}),
        ),
        version_tag="1.0.0",
    )

    assert release.id == 2
    assert transport.put_calls == []


def test_release_ensure_enriches_assets_by_name() -> None:
    transport = DummyReleaseTransport()
    transport.release_state[2]["files"].append(
        {
            "id": 33,
            "name": "keep.zip",
            "description": "",
            "size": 1,
            "downloads": 0,
        }
    )
    service = ReleaseService(
        transport,
        DummyRepositoryService(),
        DummyPackageService(),
    )

    release = service.ensure(
        10,
        ReleaseInput(
            name="1.0.0",
            tags=["1.0.0"],
            options=ReleaseOptions({"dist": "stable"}),
            assets=[
                ReleaseAssetInput(
                    name="new.zip",
                    upload_name="uploaded-new",
                ),
                ReleaseAssetInput(
                    name="extra.zip",
                    upload_name="uploaded-extra",
                ),
            ],
        ),
        version_tag="1.0.0",
        enrich_assets=True,
    )

    assert release.id == 2
    assert transport.put_calls[-1]["payload"]["files"] == [
        {
            "name": "extra.zip",
            "description": "",
            "upload_name": "uploaded-extra",
        },
        {"name": "keep.zip", "description": "", "id": 33},
        {
            "name": "new.zip",
            "description": "",
            "upload_name": "uploaded-new",
        },
    ]


def test_release_create_adds_missing_tag_from_version_tag() -> None:
    transport = DummyReleaseTransport()
    service = ReleaseService(
        transport,
        DummyRepositoryService(),
        DummyPackageService(),
    )

    release = service.create(
        10,
        ReleaseInput(name="1.1.0", tags=["latest"]),
        version_tag="1.1.0",
    )

    assert release.tags == ["1.1.0", "latest"]
    assert transport.post_calls[-1]["tags"] == ["1.1.0", "latest"]


def test_release_payload_omits_absent_tags_options_and_assets() -> None:
    payload = build_release_payload(
        ReleaseInput(
            name="untagged",
            description="minimal",
        ),
        package_id=10,
    )

    assert payload == {
        "name": "untagged",
        "description": "minimal",
        "packet": 10,
    }


def test_release_create_without_tags_or_options_omits_payload_fields() -> None:
    transport = DummyReleaseTransport()
    service = ReleaseService(
        transport,
        DummyRepositoryService(),
        DummyPackageService(),
    )

    release = service.create(10, ReleaseInput(name="untagged"))

    assert release.tags == []
    assert release.options.values == {}
    assert "tags" not in transport.post_calls[-1]
    assert "options" not in transport.post_calls[-1]
    assert "files" not in transport.post_calls[-1]


def test_release_ensure_requires_version_tag_or_tags() -> None:
    service = ReleaseService(
        DummyReleaseTransport(),
        DummyRepositoryService(),
        DummyPackageService(),
    )

    with pytest.raises(RepkaConfigurationError):
        service.ensure(10, ReleaseInput(name="1.1.0"))


def test_release_create_sorts_wrong_version_tag_position() -> None:
    service = ReleaseService(
        DummyReleaseTransport(),
        DummyRepositoryService(),
        DummyPackageService(),
    )

    release = service.create(
        10,
        ReleaseInput(
            name="1.1.0",
            tags=["latest", "1.1.0", "experimental", "channel"],
        ),
        version_tag="1.1.0",
    )

    assert release.tags == ["channel", "1.1.0", "latest", "experimental"]


def test_release_update_adds_missing_tag_from_version_tag() -> None:
    transport = DummyReleaseTransport()
    service = ReleaseService(
        transport,
        DummyRepositoryService(),
        DummyPackageService(),
    )

    updated = service.update(
        2,
        ReleaseInput(tags=["latest"]),
        version_tag="1.1.0",
        package=10,
    )

    assert updated.tags == ["1.1.0", "latest"]
    assert transport.put_calls[0]["payload"]["tags"] == [
        "1.1.0",
        "latest",
    ]


def test_release_update_sorts_wrong_version_tag_position() -> None:
    transport = DummyReleaseTransport()
    service = ReleaseService(
        transport,
        DummyRepositoryService(),
        DummyPackageService(),
    )

    updated = service.update(
        2,
        ReleaseInput(tags=["latest", "1.0.0", "experimental", "channel"]),
        version_tag="1.0.0",
        package=10,
    )

    assert updated.tags == ["channel", "1.0.0", "latest", "experimental"]


def test_release_update_reconciles_latest_across_package() -> None:
    transport = DummyReleaseTransport()
    service = ReleaseService(
        transport,
        DummyRepositoryService(),
        DummyPackageService(),
    )

    updated = service.update(
        2,
        ReleaseInput(
            name="1.0.0",
            description="candidate",
            tags=["1.0.0", "latest"],
            options=ReleaseOptions({"dist": "stable"}),
        ),
        package=10,
    )

    assert "latest" in updated.tags
    assert transport.release_state[1]["tags"] == ["0.9.0"]
    assert transport.release_state[2]["tags"] == ["1.0.0", "latest"]


def test_release_update_omits_empty_files_for_empty_release() -> None:
    transport = DummyReleaseTransport()
    service = ReleaseService(
        transport,
        DummyRepositoryService(),
        DummyPackageService(),
    )

    updated = service.update(
        4,
        ReleaseInput(description="metadata only"),
        package=10,
    )

    assert updated.description == "metadata only"
    assert transport.put_calls[-1]["payload"]["description"] == "metadata only"
    assert "files" not in transport.put_calls[-1]["payload"]


def test_release_replace_rejects_asset_clearing() -> None:
    transport = DummyReleaseTransport()
    service = ReleaseService(
        transport,
        DummyRepositoryService(),
        DummyPackageService(),
    )

    with pytest.raises(RepkaConfigurationError):
        service.replace(
            2,
            ReleaseInput(
                name="1.0.1",
                description="replaced",
                tags=["1.0.1"],
                options=ReleaseOptions({"dist": "stable"}),
                assets=[],
            ),
            package=10,
        )

    assert transport.post_calls == []
    assert transport.delete_calls == []
