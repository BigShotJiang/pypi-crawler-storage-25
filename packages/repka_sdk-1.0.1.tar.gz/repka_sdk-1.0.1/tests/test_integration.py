from __future__ import annotations

from contextlib import suppress
import os
from pathlib import Path
from typing import Iterator
from typing import List
from typing import Optional
from uuid import uuid4

import pytest

from repka_sdk.async_client import AsyncRepkaClient
from repka_sdk.auth import BasicAuthProvider
from repka_sdk.auth import AuthProvider
from repka_sdk.client import RepkaClient
from repka_sdk.config import ENV_PASSWORD
from repka_sdk.config import ENV_SERVER_URL
from repka_sdk.config import ENV_USERNAME
from repka_sdk.config import BUILTIN_SOURCE
from repka_sdk.config import ResolvedConfiguration
from repka_sdk.config import resolve_configuration
from repka_sdk.exceptions import RepkaConfigurationError
from repka_sdk.exceptions import RepkaError
from repka_sdk.exceptions import RepkaNotFoundError
from repka_sdk.exceptions import RepkaTransportError
from repka_sdk.models import Package
from repka_sdk.models import PackageInput
from repka_sdk.models import ReleaseInput
from repka_sdk.models import ReleaseOptions
from repka_sdk.models import Repository
from repka_sdk.models import RepositoryInput
from repka_sdk.models import RepositoryOptions
from repka_sdk.models import RepositoryType


pytestmark = pytest.mark.integration


def _flag(value: Optional[str]) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def _auth_provider(
    config: ResolvedConfiguration,
) -> Optional[AuthProvider]:
    if config.username and config.password:
        return BasicAuthProvider(config.username, config.password)
    return None


def _unique_name(prefix: str) -> str:
    return f"{prefix}-{uuid4().hex[:12]}"


@pytest.fixture(scope="module")
def integration_config() -> ResolvedConfiguration:
    config = resolve_configuration()
    if (
        config.server is None
        or not config.server.url
        or config.source == BUILTIN_SOURCE
    ):
        pytest.skip(
            f"Integration config is not available. Set {ENV_SERVER_URL} "
            "or add it to .env."
        )
    return config


@pytest.fixture(scope="module")
def client(
    integration_config: ResolvedConfiguration,
) -> Iterator[RepkaClient]:
    assert integration_config.server is not None
    with RepkaClient(
        integration_config.server.url,
        auth_provider=_auth_provider(integration_config),
        verify=not _flag(os.environ.get("REPKA_INSECURE")),
    ) as repka_client:
        yield repka_client


@pytest.fixture()
def authenticated_client(
    client: RepkaClient,
    integration_config: ResolvedConfiguration,
) -> RepkaClient:
    if not (integration_config.username and integration_config.password):
        pytest.skip(
            f"Set {ENV_USERNAME} and {ENV_PASSWORD} for modifying tests."
        )
    return client


def test_integration_whoami(
    client: RepkaClient,
    integration_config: ResolvedConfiguration,
) -> None:
    if not (integration_config.username and integration_config.password):
        pytest.skip(
            f"Set {ENV_USERNAME} and {ENV_PASSWORD} for authenticated tests."
        )

    user = client.auth.whoami()

    assert user.id > 0
    assert user.login


def test_integration_repository_list(client: RepkaClient) -> None:
    repositories = client.repositories.list()

    assert isinstance(repositories, list)
    for repository in repositories[:5]:
        assert repository.id > 0
        assert repository.name
        assert repository.type is not None


def test_integration_repository_create_update_delete(
    authenticated_client: RepkaClient,
) -> None:
    repository_name = _unique_name("repka-sdk-it-repo")
    repository: Optional[Repository] = None

    try:
        repository = authenticated_client.repositories.create(
            RepositoryInput(
                name=repository_name,
                description="created by integration test",
                repository_type=RepositoryType.BORSCH,
                options=RepositoryOptions(
                    cleanup=True,
                    keep_releases=2,
                    ttl=7,
                ),
                permissions=[],
            )
        )

        assert repository.name == repository_name
        assert repository.type == RepositoryType.BORSCH
        assert repository.options.cleanup is True
        assert repository.options.keep_releases == 2
        assert repository.options.ttl == 7

        updated = authenticated_client.repositories.update(
            repository.id,
            RepositoryInput(
                description="updated by integration test",
                options=RepositoryOptions(
                    cleanup=False,
                    keep_releases=1,
                    ttl=1,
                ),
            ),
        )

        assert updated.id == repository.id
        assert updated.description == "updated by integration test"
        assert updated.options.cleanup is False
    finally:
        if repository is not None:
            with suppress(RepkaError):
                authenticated_client.repositories.delete(repository.id)

    with pytest.raises(RepkaNotFoundError):
        authenticated_client.repositories.get(repository.id)


def test_integration_package_create_ensure_update_delete(
    authenticated_client: RepkaClient,
) -> None:
    repository: Optional[Repository] = None
    package: Optional[Package] = None

    try:
        repository = authenticated_client.repositories.create(
            RepositoryInput(
                name=_unique_name("repka-sdk-it-package-repo"),
                description="package integration test repository",
                repository_type=RepositoryType.BORSCH,
                options=RepositoryOptions(keep_releases=1, ttl=1),
                permissions=[],
            )
        )
        package = authenticated_client.packages.create(
            repository,
            PackageInput(
                name=_unique_name("repka-sdk-it-package"),
                description="created by integration test",
                author="repka-sdk",
            ),
        )

        assert package.repository_id in {None, repository.id}
        assert package.description == "created by integration test"
        assert package.author == "repka-sdk"

        ensured = authenticated_client.packages.ensure(
            repository,
            PackageInput(
                name=package.name,
                description="created by integration test",
                author="repka-sdk",
            ),
        )

        assert ensured.id == package.id

        updated = authenticated_client.packages.update(
            package.id,
            PackageInput(description="updated by integration test"),
            repository=repository,
        )

        assert updated.id == package.id
        assert updated.description == "updated by integration test"
    finally:
        if package is not None:
            with suppress(RepkaError):
                authenticated_client.packages.delete(package.id)
        if repository is not None:
            with suppress(RepkaError):
                authenticated_client.repositories.delete(repository.id)

    with pytest.raises(RepkaNotFoundError):
        authenticated_client.packages.get(package.id)


def test_integration_release_create_update_replace_delete_with_asset(
    authenticated_client: RepkaClient,
    tmp_path: Path,
) -> None:
    repository: Optional[Repository] = None
    package: Optional[Package] = None
    release_id: Optional[int] = None
    release_ids: List[int] = []
    asset_path = tmp_path / "artifact.txt"
    asset_path.write_text("repka sdk integration asset\n", encoding="utf-8")

    try:
        repository = authenticated_client.repositories.create(
            RepositoryInput(
                name=_unique_name("repka-sdk-it-release-repo"),
                description="release integration test repository",
                repository_type=RepositoryType.BORSCH,
                options=RepositoryOptions(keep_releases=1, ttl=1),
                permissions=[],
            )
        )
        package = authenticated_client.packages.create(
            repository,
            PackageInput(
                name=_unique_name("repka-sdk-it-release-package"),
                description="release integration test package",
            ),
        )
        minimal_release = authenticated_client.releases.create(
            package,
            ReleaseInput(
                name="untagged",
                description="created without tags or options",
            ),
        )
        release_ids.append(minimal_release.id)

        assert minimal_release.name == "untagged"
        assert minimal_release.tags == []
        assert minimal_release.options.values == {}
        assert minimal_release.assets == []

        release = authenticated_client.releases.create_from_paths(
            package,
            [asset_path],
            ReleaseInput(
                name="1.0.0",
                description="created by integration test",
                tags=["latest"],
                options=ReleaseOptions({"channel": "integration"}),
            ),
            version_tag="1.0.0",
        )
        release_id = release.id
        release_ids.append(release.id)

        assert release.name == "1.0.0"
        assert release.tags == ["1.0.0", "latest"]
        assert release.options.values == {"channel": "integration"}
        assert [asset.name for asset in release.assets] == [asset_path.name]

        updated_with_asset = authenticated_client.releases.update(
            release.id,
            ReleaseInput(
                description="metadata updated after asset upload",
                tags=["1.0.0"],
                options=ReleaseOptions({"channel": "integration-updated"}),
            ),
            package=package,
        )

        assert updated_with_asset.description == (
            "metadata updated after asset upload"
        )
        assert updated_with_asset.tags == ["1.0.0"]
        assert [asset.name for asset in updated_with_asset.assets] == [
            asset_path.name
        ]
        assert updated_with_asset.options.values == {
            "channel": "integration-updated"
        }

        with pytest.raises(RepkaConfigurationError):
            authenticated_client.releases.replace(
                updated_with_asset.id,
                ReleaseInput(
                    name="1.0.1",
                    description="replaced by integration test",
                    tags=["1.0.1"],
                    options=ReleaseOptions(
                        {"channel": "integration-replaced"}
                    ),
                    assets=[],
                ),
                package=package,
            )
    finally:
        for release_id in release_ids:
            with suppress(RepkaError):
                authenticated_client.releases.delete(release_id)
        if package is not None:
            with suppress(RepkaError):
                authenticated_client.packages.delete(package.id)
        if repository is not None:
            with suppress(RepkaError):
                authenticated_client.repositories.delete(repository.id)

    with pytest.raises(RepkaNotFoundError):
        assert release_id is not None
        authenticated_client.releases.get(release_id)


def test_integration_release_ensure_enriches_assets_by_name(
    authenticated_client: RepkaClient,
    tmp_path: Path,
) -> None:
    repository: Optional[Repository] = None
    package: Optional[Package] = None
    release_id: Optional[int] = None
    first_same_path = tmp_path / "same.txt"
    old_path = tmp_path / "old.txt"
    new_path = tmp_path / "new.txt"
    downloaded_path = tmp_path / "downloaded-same.txt"

    first_same_path.write_text("same: first\n", encoding="utf-8")
    old_path.write_text("old: kept\n", encoding="utf-8")
    new_path.write_text("new: added\n", encoding="utf-8")

    try:
        repository = authenticated_client.repositories.create(
            RepositoryInput(
                name=_unique_name("repka-sdk-it-ensure-repo"),
                description="ensure enrichment integration test repository",
                repository_type=RepositoryType.BORSCH,
                options=RepositoryOptions(keep_releases=1, ttl=1),
                permissions=[],
            )
        )
        package = authenticated_client.packages.create(
            repository,
            PackageInput(
                name=_unique_name("repka-sdk-it-ensure-package"),
                description="ensure enrichment integration test package",
            ),
        )

        first_assets = authenticated_client.assets.upload_many(
            [first_same_path, old_path]
        )
        first_release = authenticated_client.releases.ensure(
            package,
            ReleaseInput(
                name="2.0.0",
                description="created by ensure",
                tags=["latest"],
                options=ReleaseOptions({"state": "123"}),
                assets=first_assets,
            ),
            version_tag="2.0.0",
            enrich_assets=True,
        )
        release_id = first_release.id

        assert first_release.tags == ["2.0.0", "latest"]
        assert first_release.options.values == {"state": "123"}
        assert sorted(asset.name for asset in first_release.assets) == [
            "old.txt",
            "same.txt",
        ]

        first_same_path.write_text("same: second\n", encoding="utf-8")
        second_assets = authenticated_client.assets.upload_many(
            [first_same_path, new_path]
        )
        second_release = authenticated_client.releases.ensure(
            package,
            ReleaseInput(
                name="2.0.0",
                description="created by ensure",
                tags=["latest"],
                options=ReleaseOptions({"state": "123"}),
                assets=second_assets,
            ),
            version_tag="2.0.0",
            enrich_assets=True,
        )

        assert second_release.id == first_release.id
        assert second_release.options.values == {"state": "123"}
        assert sorted(asset.name for asset in second_release.assets) == [
            "new.txt",
            "old.txt",
            "same.txt",
        ]

        same_asset = next(
            asset
            for asset in second_release.assets
            if asset.name == "same.txt"
        )
        assert same_asset.id is not None
        downloaded = authenticated_client.assets.download(
            same_asset.id,
            downloaded_path,
        )

        assert isinstance(downloaded, Path)
        assert downloaded.read_text(encoding="utf-8") == "same: second\n"
    finally:
        if release_id is not None:
            with suppress(RepkaError):
                authenticated_client.releases.delete(release_id)
        if package is not None:
            with suppress(RepkaError):
                authenticated_client.packages.delete(package.id)
        if repository is not None:
            with suppress(RepkaError):
                authenticated_client.repositories.delete(repository.id)

    with pytest.raises(RepkaNotFoundError):
        assert release_id is not None
        authenticated_client.releases.get(release_id)


def test_integration_repository_get_first_available(
    client: RepkaClient,
) -> None:
    repositories = client.repositories.list()
    if not repositories:
        pytest.skip("No repositories are available on the integration server.")

    repository = client.repositories.get(repositories[0].id)

    assert repository.id == repositories[0].id
    assert repository.name


def test_integration_package_list_first_repository(
    client: RepkaClient,
) -> None:
    repositories = client.repositories.list()
    if not repositories:
        pytest.skip("No repositories are available on the integration server.")

    packages = client.packages.list(repositories[0])

    assert isinstance(packages, list)
    for package in packages[:5]:
        assert package.id > 0
        assert package.name
        assert package.repository_id in {None, repositories[0].id}


def test_integration_package_get_first_available(
    client: RepkaClient,
) -> None:
    repositories = client.repositories.list()
    if not repositories:
        pytest.skip("No repositories are available on the integration server.")
    packages = client.packages.list(repositories[0])
    if not packages:
        pytest.skip("No packages are available in the first repository.")

    package = client.packages.get(packages[0].id)

    assert package.id == packages[0].id
    assert package.name


def test_integration_release_list_first_package(
    client: RepkaClient,
) -> None:
    repositories = client.repositories.list()
    if not repositories:
        pytest.skip("No repositories are available on the integration server.")
    packages = client.packages.list(repositories[0])
    if not packages:
        pytest.skip("No packages are available in the first repository.")

    releases = client.releases.list(packages[0])

    assert isinstance(releases, list)
    for release in releases[:5]:
        assert release.id > 0
        assert release.name


def test_integration_asset_download_15108(
    client: RepkaClient,
    tmp_path: Path,
) -> None:
    asset_id = int(os.environ.get("REPKA_INTEGRATION_ASSET_ID", "15108"))

    try:
        downloaded = client.assets.download(asset_id, tmp_path)
    except RepkaNotFoundError:
        pytest.skip(f"Asset {asset_id} is not available on this server.")
    except RepkaTransportError as exc:
        pytest.skip(f"Asset {asset_id} download is not available: {exc}")

    assert isinstance(downloaded, Path)
    assert downloaded.exists()
    assert downloaded.is_file()
    assert downloaded.stat().st_size > 0


@pytest.mark.asyncio
async def test_integration_async_repository_list(
    integration_config: ResolvedConfiguration,
) -> None:
    assert integration_config.server is not None
    async with AsyncRepkaClient(
        integration_config.server.url,
        auth_provider=_auth_provider(integration_config),
        verify=not _flag(os.environ.get("REPKA_INSECURE")),
    ) as client:
        repositories = await client.repositories.list()

    assert isinstance(repositories, list)
