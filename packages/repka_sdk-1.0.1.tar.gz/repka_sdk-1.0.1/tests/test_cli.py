from __future__ import annotations

import httpx
import json
import respx

from repka_sdk.cli import app


@respx.mock
def test_cli_whoami_json(runner, monkeypatch) -> None:
    monkeypatch.setenv("REPKA_SERVER_URL", "https://rm.test")
    monkeypatch.setenv("REPKA_USERNAME", "editor")
    monkeypatch.setenv("REPKA_PASSWORD", "secret")

    respx.get("https://rm.test/api/current_user").mock(
        return_value=httpx.Response(
            200,
            json={"id": 2, "login": "editor", "name": "Editor"},
        )
    )

    result = runner.invoke(app, ["--json", "whoami"])

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["server"]["url"] == "https://rm.test"
    assert payload["user"]["login"] == "editor"


def test_cli_repo_create_dry_run(runner) -> None:
    result = runner.invoke(
        app,
        [
            "--json",
            "--dry-run",
            "repo",
            "create",
            "sdk-repo",
            "--type",
            "borsch",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["dry_run"] is True
    assert payload["action"] == "repo.create"


def test_cli_server_add_rejects_invalid_url(runner) -> None:
    result = runner.invoke(app, ["server", "add", "bad", "rm.test"])

    assert result.exit_code == 6
    assert "absolute http or https URL" in result.stderr


@respx.mock
def test_cli_repo_list_prints_headers(runner, monkeypatch) -> None:
    monkeypatch.setenv("REPKA_SERVER_URL", "https://rm.test")
    respx.get("https://rm.test/api/repo").mock(
        return_value=httpx.Response(
            200,
            json=[
                {
                    "id": 2,
                    "name": "qgis-repo",
                    "type": 5,
                    "options": [],
                    "packets": [],
                    "permissions": [],
                },
                {
                    "id": 1,
                    "name": "borsch-repo",
                    "type": 3,
                    "options": [],
                    "packets": [],
                    "permissions": [],
                },
            ],
        )
    )

    result = runner.invoke(app, ["repo", "list"])

    assert result.exit_code == 0
    assert result.stdout.splitlines()[0].split() == [
        "id",
        "type",
        "name",
        "description",
    ]
    assert result.stdout.splitlines()[1].split() == [
        "1",
        "borsch",
        "borsch-repo",
    ]
    assert result.stdout.splitlines()[2].split() == [
        "2",
        "qgis",
        "qgis-repo",
    ]


@respx.mock
def test_cli_repo_list_accepts_selected_and_all_fields(
    runner,
    monkeypatch,
) -> None:
    monkeypatch.setenv("REPKA_SERVER_URL", "https://rm.test")
    respx.get("https://rm.test/api/repo").mock(
        return_value=httpx.Response(
            200,
            json=[
                {
                    "id": 1,
                    "name": "repo",
                    "description": "visible",
                    "type": 3,
                    "options": [{"key": "cleanup", "value": "true"}],
                    "key": {"public_key": "public", "fingerprint": "finger"},
                    "packets": [],
                    "permissions": [],
                }
            ],
        )
    )

    selected = runner.invoke(
        app,
        ["repo", "list", "--field", "description", "--field", "name"],
    )

    assert selected.exit_code == 0
    assert selected.stdout.splitlines()[0].split() == ["description", "name"]
    assert "visible" in selected.stdout

    all_fields = runner.invoke(app, ["repo", "list", "--all"])

    assert all_fields.exit_code == 0
    headers = all_fields.stdout.splitlines()[0].split()
    assert "description" in headers
    assert "options.cleanup" in headers
    assert "key.public_key" in headers


@respx.mock
def test_cli_repo_list_accepts_comma_fields_and_wraps_long_description(
    runner,
    monkeypatch,
) -> None:
    monkeypatch.setenv("REPKA_SERVER_URL", "https://rm.test")
    long_description = " ".join(["long description"] * 12)
    respx.get("https://rm.test/api/repo").mock(
        return_value=httpx.Response(
            200,
            json=[
                {
                    "id": 10,
                    "name": "wrapped",
                    "description": long_description,
                    "type": 3,
                    "options": [],
                    "packets": [],
                    "permissions": [],
                }
            ],
        )
    )

    result = runner.invoke(
        app,
        ["repo", "list", "--field", "id,name,description"],
    )

    assert result.exit_code == 0
    assert result.stdout.splitlines()[0].split() == [
        "id",
        "name",
        "description",
    ]
    assert max(len(line) for line in result.stdout.splitlines()) < 120


def test_cli_browse_without_args_prints_home(runner) -> None:
    result = runner.invoke(app, ["browse", "--print-url"])

    assert result.exit_code == 0
    assert result.stdout.strip() == "https://rm.nextgis.com"


@respx.mock
def test_cli_package_get_interactive_selects_by_id(
    runner,
    monkeypatch,
) -> None:
    monkeypatch.setenv("REPKA_SERVER_URL", "https://rm.test")
    respx.get("https://rm.test/api/repo").mock(
        return_value=httpx.Response(
            200,
            json=[
                {
                    "id": 1,
                    "name": "nextgis",
                    "type": 5,
                    "options": [],
                    "packets": [],
                    "permissions": [],
                },
                {
                    "id": 2,
                    "name": "nextgis",
                    "type": 3,
                    "options": [],
                    "packets": [],
                    "permissions": [],
                },
            ],
        )
    )
    respx.get("https://rm.test/api/packet").mock(
        return_value=httpx.Response(
            200,
            json=[
                {
                    "id": 101,
                    "name": "pkg",
                    "description": "selected",
                    "repo_id": 1,
                    "repo_type": 5,
                }
            ],
        )
    )
    respx.get("https://rm.test/api/packet/101").mock(
        return_value=httpx.Response(
            200,
            json={
                "id": 101,
                "name": "pkg",
                "description": "selected",
                "repo_id": 1,
                "repo_type": 5,
            },
        )
    )

    result = runner.invoke(app, ["package", "get"], input="1\n101\n")

    assert result.exit_code == 0
    assert result.stdout.splitlines()[0].split()[:3] == ["id", "type", "name"]
    assert "1. 1" not in result.stdout
    assert "Repository is ambiguous" not in result.stdout
    assert "id: 101" in result.stdout


@respx.mock
def test_cli_repo_get_summarizes_nested_entities(
    runner,
    monkeypatch,
) -> None:
    monkeypatch.setenv("REPKA_SERVER_URL", "https://rm.test")
    repository_payload = {
        "id": 1,
        "name": "repo",
        "type": 3,
        "options": [],
        "permissions": [],
        "packets": [
            {
                "id": 10,
                "name": "pkg",
                "releases": [
                    {
                        "id": 100,
                        "name": "Release 1",
                        "tags": ["1.0.0"],
                        "options": [],
                        "files": [],
                    }
                ],
            }
        ],
    }
    respx.get("https://rm.test/api/repo/1").mock(
        return_value=httpx.Response(200, json=repository_payload)
    )

    result = runner.invoke(app, ["repo", "get", "1"])

    assert result.exit_code == 0
    assert "package_count: 1" in result.stdout
    assert "release_count: 1" in result.stdout
    assert "packages" not in result.stdout

    expanded = runner.invoke(
        app,
        ["repo", "get", "1", "--show-packages", "--show-releases"],
    )

    assert expanded.exit_code == 0
    assert "packages" in expanded.stdout
    assert "releases" in expanded.stdout


@respx.mock
def test_cli_find_release_accepts_repeated_options_without_package_prompt(
    runner,
    monkeypatch,
) -> None:
    monkeypatch.setenv("REPKA_SERVER_URL", "https://rm.test")
    route = respx.get("https://rm.test/api/release").mock(
        return_value=httpx.Response(
            200,
            json=[
                {
                    "id": 100,
                    "name": "Release 1",
                    "tags": [],
                    "options": [],
                    "files": [],
                }
            ],
        )
    )

    result = runner.invoke(
        app,
        [
            "find",
            "release",
            "--option",
            "dist=stable",
            "--option",
            "arch:x86_64",
        ],
    )

    assert result.exit_code == 0
    assert route.called
    assert (
        "option",
        "arch:x86_64",
    ) in route.calls.last.request.url.params.multi_items()
    assert (
        "option",
        "dist:stable",
    ) in route.calls.last.request.url.params.multi_items()


@respx.mock
def test_cli_find_release_highlights_latest_and_counts_assets(
    runner,
    monkeypatch,
) -> None:
    monkeypatch.setenv("REPKA_SERVER_URL", "https://rm.test")
    respx.get("https://rm.test/api/release").mock(
        return_value=httpx.Response(
            200,
            json=[
                {
                    "id": 101,
                    "name": "newer",
                    "tags": ["2.0", "latest"],
                    "options": [],
                    "files": [{"id": 1, "name": "a"}, {"id": 2, "name": "b"}],
                },
                {
                    "id": 100,
                    "name": "older",
                    "tags": ["1.0"],
                    "options": [],
                    "files": [],
                },
            ],
        )
    )

    result = runner.invoke(
        app,
        [
            "find",
            "release",
            "--tag",
            "latest",
            "--field",
            "id",
            "--field",
            "tags",
            "--field",
            "assets",
        ],
    )

    assert result.exit_code == 0
    lines = result.stdout.splitlines()
    headers = lines[0].split()
    assert "assets" in headers
    assert "[latest]" in result.stdout
    assert lines[1].split()[0] == "100"
    assert lines[2].split()[0] == "101"
    assets_index = headers.index("assets")
    assert lines[2].split()[assets_index] == "2"


@respx.mock
def test_cli_release_get_interactive_prompts_for_single_release(
    runner,
    monkeypatch,
) -> None:
    monkeypatch.setenv("REPKA_SERVER_URL", "https://rm.test")
    respx.get("https://rm.test/api/repo").mock(
        return_value=httpx.Response(
            200,
            json=[
                {
                    "id": 1,
                    "name": "repo",
                    "type": 3,
                    "options": [],
                    "packets": [],
                    "permissions": [],
                },
                {
                    "id": 2,
                    "name": "other",
                    "type": 3,
                    "options": [],
                    "packets": [],
                    "permissions": [],
                },
            ],
        )
    )
    respx.get("https://rm.test/api/packet").mock(
        return_value=httpx.Response(
            200,
            json=[
                {"id": 10, "name": "pkg", "repo_id": 1, "repo_type": 3},
                {"id": 11, "name": "other", "repo_id": 1, "repo_type": 3},
            ],
        )
    )
    respx.get("https://rm.test/api/release").mock(
        return_value=httpx.Response(
            200,
            json=[
                {
                    "id": 100,
                    "name": "1.0.0",
                    "tags": ["1.0.0"],
                    "options": [],
                    "files": [],
                }
            ],
        )
    )
    respx.get("https://rm.test/api/release/100").mock(
        return_value=httpx.Response(
            200,
            json={
                "id": 100,
                "name": "1.0.0",
                "tags": ["1.0.0"],
                "options": [],
                "files": [],
            },
        )
    )

    result = runner.invoke(app, ["release", "get"], input="1\n10\n100\n")

    assert result.exit_code == 0
    assert "Select release id" in result.stdout
    assert "id: 100" in result.stdout


@respx.mock
def test_cli_release_get_prints_assets_as_table(
    runner,
    monkeypatch,
) -> None:
    monkeypatch.setenv("REPKA_SERVER_URL", "https://rm.test")
    respx.get("https://rm.test/api/release/100").mock(
        return_value=httpx.Response(
            200,
            json={
                "id": 100,
                "name": "1.0.0",
                "tags": ["1.0.0", "latest"],
                "options": [],
                "files": [
                    {
                        "id": 501,
                        "name": "artifact.zip",
                        "description": "archive",
                        "size": 12,
                        "downloads": 3,
                    }
                ],
            },
        )
    )

    result = runner.invoke(app, ["release", "get", "100"])

    assert result.exit_code == 0
    assert "tags: 1.0.0,[latest]" in result.stdout
    assert "assets" in result.stdout
    assert "artifact.zip" in result.stdout
    assert "[{" not in result.stdout


@respx.mock
def test_cli_asset_list_get_and_download_all(
    runner,
    monkeypatch,
    tmp_path,
) -> None:
    monkeypatch.setenv("REPKA_SERVER_URL", "https://rm.test")
    release_payload = {
        "id": 100,
        "name": "1.0.0",
        "tags": ["1.0.0"],
        "options": [],
        "files": [
            {
                "id": 501,
                "name": "artifact.zip",
                "description": "archive",
                "size": 12,
                "downloads": 3,
            }
        ],
    }
    respx.get("https://rm.test/api/release/100").mock(
        return_value=httpx.Response(200, json=release_payload)
    )
    respx.get("https://rm.test/api/asset/501/download").mock(
        return_value=httpx.Response(
            200,
            content=b"asset",
            headers={
                "content-disposition": 'attachment; filename="artifact.zip"'
            },
        )
    )

    listed = runner.invoke(
        app,
        ["asset", "list", "100", "--field", "id,name,downloads"],
    )
    got = runner.invoke(app, ["asset", "get", "501", "--release", "100"])
    downloaded = runner.invoke(
        app,
        ["asset", "download", "--all", "100", str(tmp_path)],
    )

    assert listed.exit_code == 0
    assert listed.stdout.splitlines()[0].split() == ["id", "name", "downloads"]
    assert got.exit_code == 0
    assert "name: artifact.zip" in got.stdout
    assert downloaded.exit_code == 0
    assert (tmp_path / "artifact.zip").read_bytes() == b"asset"


def test_cli_server_list_includes_nextgis_but_hides_empty_dotenv(
    runner,
) -> None:
    result = runner.invoke(app, ["server", "list"])

    assert result.exit_code == 0
    assert "nextgis" in result.stdout
    assert "dotenv" not in result.stdout


def test_cli_server_set_url_and_get_url_for_dotenv(runner) -> None:
    set_result = runner.invoke(
        app,
        [
            "server",
            "set-url",
            "dotenv",
            "https://dotenv.test",
            "--username",
            "editor",
        ],
    )
    list_result = runner.invoke(app, ["server", "list"])
    get_result = runner.invoke(app, ["server", "get-url", "dotenv"])

    assert set_result.exit_code == 0
    assert list_result.exit_code == 0
    assert "dotenv" in list_result.stdout
    assert "editor" in list_result.stdout
    assert get_result.exit_code == 0
    assert get_result.stdout.strip() == "https://dotenv.test"


def test_cli_server_mutations_use_human_messages(runner) -> None:
    added = runner.invoke(app, ["server", "add", "staging", "https://rm.test"])
    removed = runner.invoke(app, ["server", "remove", "staging"])

    assert added.exit_code == 0
    assert added.stdout.strip() == "Server 'staging' added: https://rm.test"
    assert removed.exit_code == 0
    assert removed.stdout.strip() == "Server 'staging' removed"


@respx.mock
def test_cli_server_default_is_explicit(runner) -> None:
    added = runner.invoke(
        app,
        ["server", "add", "staging", "https://rm.staging.test"],
    )
    respx.get("https://rm.nextgis.com/api/healthcheck").mock(
        return_value=httpx.Response(200, json={"status": "ok"})
    )
    respx.get("https://rm.staging.test/api/healthcheck").mock(
        return_value=httpx.Response(200, json={"status": "ok"})
    )
    listed = runner.invoke(app, ["server", "list"])
    status = runner.invoke(app, ["server", "status"])
    selected = runner.invoke(app, ["server", "set-default", "staging"])
    listed_after_default = runner.invoke(app, ["server", "list"])
    status_after_default = runner.invoke(app, ["server", "status"])

    assert added.exit_code == 0
    assert listed.exit_code == 0
    lines = listed.stdout.splitlines()
    headers = lines[0].split()
    default_index = headers.index("default")
    source_index = headers.index("source")
    nextgis = lines[1].split()
    staging = lines[2].split()
    assert nextgis[0] == "nextgis"
    assert nextgis[source_index] == "builtin"
    assert nextgis[default_index] == "True"
    assert staging[0] == "staging"
    assert staging[source_index] == "system"
    assert staging[default_index] == "False"
    assert status.stdout.strip() == (
        "nextgis (builtin): https://rm.nextgis.com - ok"
    )
    assert selected.exit_code == 0
    assert status_after_default.stdout.strip() == (
        "staging (system): https://rm.staging.test - ok"
    )
    lines = listed_after_default.stdout.splitlines()
    headers = lines[0].split()
    default_index = headers.index("default")
    nextgis = lines[1].split()
    staging = lines[2].split()
    assert nextgis[default_index] == "False"
    assert staging[default_index] == "True"

    restored = runner.invoke(app, ["server", "set-default", "nextgis"])
    restored_list = runner.invoke(app, ["server", "list"])
    restored_status = runner.invoke(app, ["server", "status"])

    assert restored.exit_code == 0
    assert restored_status.stdout.strip() == (
        "nextgis (builtin): https://rm.nextgis.com - ok"
    )
    lines = restored_list.stdout.splitlines()
    headers = lines[0].split()
    default_index = headers.index("default")
    nextgis = lines[1].split()
    staging = lines[2].split()
    assert nextgis[default_index] == "True"
    assert staging[default_index] == "False"


@respx.mock
def test_cli_server_status_is_sanitized_json(runner, monkeypatch) -> None:
    monkeypatch.setenv("REPKA_SERVER_URL", "https://rm.test")
    monkeypatch.setenv("REPKA_USERNAME", "editor")
    monkeypatch.setenv("REPKA_PASSWORD", "secret")
    respx.get("https://rm.test/api/healthcheck").mock(
        return_value=httpx.Response(200, json={"status": "ok"})
    )

    result = runner.invoke(app, ["--json", "server", "status"])

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["url"] == "https://rm.test"
    assert payload["credentials"] is True
    assert payload["health"] == {"status": "ok"}
    assert "password" not in payload
    assert "resolved" not in payload


@respx.mock
def test_cli_server_remote_repos_prompts_for_type(
    runner,
    monkeypatch,
) -> None:
    monkeypatch.setenv("REPKA_SERVER_URL", "https://rm.test")
    respx.get("https://rm.test/api/sync/3").mock(
        return_value=httpx.Response(
            200,
            json=[{"id": "repo-1", "name": "Remote repo"}],
        )
    )

    result = runner.invoke(app, ["server", "remote-repos"], input="\n")

    assert result.exit_code == 0
    assert "Repository types:" in result.stdout
    assert "repo-1" in result.stdout


@respx.mock
def test_cli_server_remote_packages_prompts_for_type_and_repository(
    runner,
    monkeypatch,
) -> None:
    monkeypatch.setenv("REPKA_SERVER_URL", "https://rm.test")
    respx.get("https://rm.test/api/sync/3").mock(
        return_value=httpx.Response(
            200,
            json=[
                {"id": "repo-1", "name": "Remote repo 1"},
                {"id": "repo-2", "name": "Remote repo 2"},
            ],
        )
    )
    packages = respx.get("https://rm.test/api/sync/3/repo/repo-2").mock(
        return_value=httpx.Response(
            200,
            json=[{"id": "pkg-1", "name": "Remote package"}],
        )
    )

    result = runner.invoke(
        app,
        ["server", "remote-packages"],
        input="\nrepo-2\n",
    )

    assert result.exit_code == 0
    assert packages.called
    assert "Remote package" in result.stdout


def test_cli_dotenv_server_requires_config(runner) -> None:
    result = runner.invoke(
        app, ["--server", "dotenv", "browse", "--print-url"]
    )

    assert result.exit_code == 3
    assert "Dotenv server is not configured" in result.stderr


def test_cli_auth_params_shows_current_login_parameters(
    runner,
    monkeypatch,
) -> None:
    monkeypatch.setenv("REPKA_SERVER_URL", "https://rm.test")
    monkeypatch.setenv("REPKA_USERNAME", "editor")
    monkeypatch.setenv("REPKA_PASSWORD", "secret")

    result = runner.invoke(app, ["--json", "auth", "params"])

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["url"] == "https://rm.test"
    assert payload["username"] == "editor"
    assert payload["credentials"] is True
    assert "password" not in payload


@respx.mock
def test_cli_auth_status_reports_unknown_when_server_unavailable(
    runner,
    monkeypatch,
) -> None:
    monkeypatch.setenv("REPKA_SERVER_URL", "https://rm.test")
    respx.get("https://rm.test/api/current_user").mock(
        side_effect=httpx.ConnectError("offline")
    )

    result = runner.invoke(app, ["auth", "status"])

    assert result.exit_code == 0
    assert result.stdout.strip() == "unknown"


@respx.mock
def test_cli_auth_status_json_contains_only_status(
    runner,
    monkeypatch,
) -> None:
    monkeypatch.setenv("REPKA_SERVER_URL", "https://rm.test")
    monkeypatch.setenv("REPKA_USERNAME", "editor")
    monkeypatch.setenv("REPKA_PASSWORD", "secret")
    respx.get("https://rm.test/api/current_user").mock(
        return_value=httpx.Response(
            200,
            json={"id": 2, "login": "editor", "name": "Editor"},
        )
    )

    result = runner.invoke(app, ["--json", "auth", "status"])

    assert result.exit_code == 0
    assert json.loads(result.stdout) == {"status": "success"}


@respx.mock
def test_cli_auth_login_asks_before_overwriting(
    runner,
    fake_keyring,
) -> None:
    server = runner.invoke(
        app,
        ["server", "add", "staging", "https://rm.test"],
    )
    assert server.exit_code == 0
    respx.get("https://rm.test/api/current_user").mock(
        return_value=httpx.Response(
            200,
            json={"id": 2, "login": "editor", "name": "Editor"},
        )
    )

    first = runner.invoke(
        app,
        [
            "auth",
            "login",
            "staging",
            "--username",
            "editor",
            "--password",
            "secret",
            "--force",
        ],
    )
    second = runner.invoke(
        app,
        [
            "auth",
            "login",
            "staging",
            "--username",
            "editor",
            "--password",
            "secret",
        ],
        input="n\n",
    )

    assert first.exit_code == 0
    assert second.exit_code == 6
    assert "Login aborted" in second.stderr
