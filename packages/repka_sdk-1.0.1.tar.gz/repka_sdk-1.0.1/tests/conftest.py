from __future__ import annotations

from pathlib import Path
from typing import Dict
from typing import Tuple

import pytest
from typer.testing import CliRunner

from repka_sdk.config import ENV_DEFAULT_SERVER
from repka_sdk.config import ENV_PASSWORD
from repka_sdk.config import ENV_SERVER_NAME
from repka_sdk.config import ENV_SERVER_URL
from repka_sdk.config import ENV_USERNAME


REPKA_ENV_VARS = [
    ENV_SERVER_NAME,
    ENV_SERVER_URL,
    ENV_USERNAME,
    ENV_PASSWORD,
    ENV_DEFAULT_SERVER,
]


@pytest.fixture(autouse=True)
def isolated_runtime_config(request, tmp_path: Path, monkeypatch) -> None:
    if request.node.get_closest_marker("integration"):
        return

    for variable in REPKA_ENV_VARS:
        monkeypatch.delenv(variable, raising=False)

    monkeypatch.setattr(
        "repka_sdk.config.DEFAULT_DOTENV_PATH",
        str(tmp_path / ".env"),
    )
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "xdg-config"))


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


@pytest.fixture
def fake_keyring(monkeypatch):
    store: Dict[Tuple[str, str], str] = {}

    def set_password(service: str, username: str, password: str) -> None:
        store[(service, username)] = password

    def get_password(service: str, username: str):
        return store.get((service, username))

    def delete_password(service: str, username: str) -> None:
        store.pop((service, username), None)

    monkeypatch.setattr("repka_sdk.config.keyring.set_password", set_password)
    monkeypatch.setattr("repka_sdk.config.keyring.get_password", get_password)
    monkeypatch.setattr(
        "repka_sdk.config.keyring.delete_password", delete_password
    )
    return store
