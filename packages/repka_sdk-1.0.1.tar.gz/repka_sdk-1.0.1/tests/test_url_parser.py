from __future__ import annotations

from repka_sdk.url_parser import build_api_url
from repka_sdk.url_parser import build_ui_url
from repka_sdk.url_parser import parse_repka_url


def test_parse_api_and_ui_urls() -> None:
    api_ref = parse_repka_url("https://rm.test/api/repo/12")
    ui_ref = parse_repka_url("https://rm.test/release/77/edit")

    assert api_ref is not None
    assert api_ref.entity_type == "repository"
    assert api_ref.entity_id == 12

    assert ui_ref is not None
    assert ui_ref.entity_type == "release"
    assert ui_ref.entity_id == 77


def test_build_urls() -> None:
    assert build_api_url("https://rm.test", "asset", 4, download=True) == (
        "https://rm.test/api/asset/4/download"
    )
    assert build_ui_url("https://rm.test/", "package", 9) == (
        "https://rm.test/packet/9"
    )
