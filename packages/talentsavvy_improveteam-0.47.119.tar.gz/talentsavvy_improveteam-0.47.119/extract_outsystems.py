#!/usr/bin/env python3
"""
OutSystems Data Extraction Script

This script extracts SDLC events from OutSystems via the LifeTime API v2 and inserts
them into the code_commit_event, build_event, and deployment_event tables.

Usage:
    Database mode:
        python extract_outsystems.py -p <product_name> [-s <start_date>]

    CSV mode:
        python extract_outsystems.py [-s <start_date>]

Events extracted:
    - Code Committed  : from Application Versions created in Development (code_commit_event)
    - Build Created   : from Deployment Plans, one row per application (build_event)
    - Deployed        : from completed Deployment Plans, one row per application (deployment_event)

Notes:
    - Providing -p/--product runs the script in database mode.
    - Omitting -p/--product runs the script in CSV mode.
    - OutSystems is trunk-based. For Code Committed, source_branch is null and target_branch = version number.
      For Build Created and Deployed, source_branch = version number.
    - environment in deployment_event maps to the OutSystems target Environment name.
    - Only Deployment Plans with status 'finished_successful' produce Deployed events.
    - Hash deduplication is handled by database triggers on all three tables.
    - data_source = 'deployment' in data_source_config.
"""

import argparse
import json
import logging
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

base_dir = os.path.dirname(os.path.abspath(__file__))
common_dir = os.path.join(base_dir, "common")
if not os.path.isdir(common_dir):
    base_dir = os.path.dirname(base_dir)
    common_dir = os.path.join(base_dir, "common")

if os.path.isdir(common_dir) and base_dir not in sys.path:
    sys.path.insert(0, base_dir)

import requests

from common.utils import Utils
from common.code_commit_event import CodeCommitEvent

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('outsystems_extractor')

CodeCommitEvent.LOGGER = logger

class OutSystemsExtractor:
    """Extracts SDLC events from OutSystems via the LifeTime API v2."""

    def __init__(self):
        self.stats = {
            'code_commit_events_inserted': 0,
            'code_commit_events_duplicates': 0,
            'build_events_inserted': 0,
            'build_events_duplicates': 0,
            'deployment_events_inserted': 0,
            'deployment_events_duplicates': 0,
        }

    def get_config_from_database(self, cursor) -> Dict:
        """Get OutSystems configuration from data_source_config table."""
        query = """
        SELECT config_item, config_value
        FROM data_source_config
        WHERE data_source = 'deployment'
        AND config_item IN ('Organization', 'Personal Access Token', 'Applications', 'Include Applications')
        """
        cursor.execute(query)
        results = cursor.fetchall()

        config = {}
        for config_item, config_value in results:
            if config_item == 'Applications':
                try:
                    apps = json.loads(config_value) if config_value else []
                    config['applications'] = apps if apps else []
                except (json.JSONDecodeError, TypeError):
                    config['applications'] = []
            elif config_item == 'Organization':
                config['lifetime_host'] = config_value
            elif config_item == 'Personal Access Token':
                config['api_token'] = config_value
            elif config_item == 'Include Applications':
                config['include_applications'] = Utils.to_bool(config_value, default=True)

        return config

    def get_last_modified_date(self, cursor) -> Optional[datetime]:
        """Get the last modified date from the build_event table."""
        query = "SELECT MAX(timestamp_utc) FROM build_event"
        cursor.execute(query)
        result = cursor.fetchone()
        if result[0]:
            dt = result[0]
            if dt.tzinfo is not None:
                dt = dt.replace(tzinfo=None)
            return dt
        return datetime(2000, 1, 1)

    def run_extraction(
        self,
        cursor,
        config: Dict,
        start_date: Optional[str],
        last_modified: Optional[datetime],
        export_path: str = None,
    ):
        """
        Run extraction: fetch events from OutSystems and save to DB or CSV.

        Args:
            cursor: Database cursor (None for CSV mode)
            config: Configuration dictionary
            start_date: Start date from command line (optional, YYYY-MM-DD)
            last_modified: Last modified datetime from database or checkpoint
            export_path: Export path for CSV mode
        """
        lifetime_host = config.get('lifetime_host', '').rstrip('/')
        api_token = config.get('api_token', '')
        app_filter = config.get('applications', [])
        include_applications = config.get('include_applications', True)

        if not lifetime_host or not api_token:
            Utils.fatal(
                "Missing required configuration: 'Organization' or 'Personal Access Token'",
                context="run_extraction",
                logger=logger,
            )

        lifetime_url = f"https://{lifetime_host}.outsystemsenterprise.com/lifetimeapi/rest/v2"

        # Determine extraction start date
        if start_date:
            try:
                extraction_start = datetime.strptime(start_date, '%Y-%m-%d')
            except ValueError:
                Utils.fatal(
                    "Invalid date format. Please use YYYY-MM-DD format.",
                    context="run_extraction",
                    logger=logger,
                )
        else:
            extraction_start = last_modified if last_modified else datetime(2000, 1, 1)
            if extraction_start.tzinfo is not None:
                extraction_start = extraction_start.replace(tzinfo=None)

        logger.info(f"Starting OutSystems extraction from {extraction_start}")
        logger.info(f"LifeTime API URL: {lifetime_url}")

        # --- Set up save functions ---
        if cursor:
            def save_commit_fn(events):
                if not events:
                    return 0, 0
                _, inserted, dupes = CodeCommitEvent.save_events_to_database(events, cursor)
                self.stats['code_commit_events_inserted'] += inserted
                self.stats['code_commit_events_duplicates'] += dupes
                return inserted, dupes

            def save_build_fn(events):
                if not events:
                    return 0, 0
                inserted, dupes = save_build_events_to_database(events, cursor)
                self.stats['build_events_inserted'] += inserted
                self.stats['build_events_duplicates'] += dupes
                return inserted, dupes

            def save_deploy_fn(events):
                if not events:
                    return 0, 0
                inserted, dupes = save_deployment_events_to_database(events, cursor)
                self.stats['deployment_events_inserted'] += inserted
                self.stats['deployment_events_duplicates'] += dupes
                return inserted, dupes

        else:
            # CSV mode — create files lazily
            commit_csv_file = None
            build_csv_file = None
            deploy_csv_file = None

            def save_commit_fn(events):
                nonlocal commit_csv_file
                if not events:
                    return 0, 0
                if not commit_csv_file:
                    commit_csv_file = Utils.create_csv_file(
                        "outsystems_commit_events", export_path, logger
                    )
                Utils.save_events_to_csv(
                    events, commit_csv_file, logger,
                    checkpoint_prefix="outsystems", export_path=export_path
                )
                return len(events), 0

            def save_build_fn(events):
                nonlocal build_csv_file
                if not events:
                    return 0, 0
                if not build_csv_file:
                    build_csv_file = Utils.create_csv_file(
                        "outsystems_build_events", export_path, logger
                    )
                Utils.save_events_to_csv(
                    events, build_csv_file, logger,
                    checkpoint_prefix="outsystems", export_path=export_path
                )
                return len(events), 0

            def save_deploy_fn(events):
                nonlocal deploy_csv_file
                if not events:
                    return 0, 0
                if not deploy_csv_file:
                    deploy_csv_file = Utils.create_csv_file(
                        "outsystems_deployment_events", export_path, logger
                    )
                Utils.save_events_to_csv(
                    events, deploy_csv_file, logger,
                    checkpoint_prefix="outsystems", export_path=export_path
                )
                return len(events), 0

        # --- Fetch environments ---
        environments = fetch_environments(lifetime_url, api_token)
        if not environments:
            Utils.fatal(
                "Failed to fetch environments from LifeTime API",
                context="run_extraction",
                logger=logger,
            )
        logger.info(f"Discovered {len(environments)} environments")

        # --- Fetch applications ---
        # Fetch all applications unfiltered for key->name resolution in deployment processing.
        all_applications = fetch_applications(lifetime_url, api_token, [], True)
        app_key_to_name = {app.get('Key', ''): app.get('Name', '') for app in all_applications}

        # Apply the configured inclusion/exclusion filter to determine which apps to
        # extract Code Committed events for.
        applications = fetch_applications(lifetime_url, api_token, app_filter, include_applications)
        if not applications:
            logger.warning("No applications found matching the configured filter")
            return
        logger.info(f"Processing {len(applications)} applications")

        # Build a skip predicate covering both inclusion and exclusion modes.
        if app_filter:
            filter_lower_set = {name.lower() for name in app_filter}
            if include_applications:
                def should_skip_app(name: str) -> bool:
                    return name.lower() not in filter_lower_set
            else:
                def should_skip_app(name: str) -> bool:
                    return name.lower() in filter_lower_set
        else:
            def should_skip_app(name: str) -> bool:
                return False

        # --- Fetch module key -> name map ---
        module_key_to_name = fetch_modules(lifetime_url, api_token)
        logger.info(f"Fetched {len(module_key_to_name)} modules")

        # --- Extract Code Committed events from Application Versions ---
        def _fetch_versions(app):
            app_key = app.get('Key', '')
            app_name = app.get('Name', '')
            if not app_key or not app_name:
                return app_name, []
            versions = fetch_application_versions(lifetime_url, api_token, app_key, extraction_start)
            return app_name, versions

        valid_apps = [app for app in applications if app.get('Key') and app.get('Name')]
        app_versions_results = {}
        with ThreadPoolExecutor(max_workers=10) as executor:
            futures = {executor.submit(_fetch_versions, app): app for app in valid_apps}
            for future in as_completed(futures):
                app_name, versions = future.result()
                app_versions_results[app_name] = versions
                logger.info(f"Found {len(versions)} new versions for {app_name}")

        # Build version_key -> version info dict for use in Build/Deployed events
        version_key_to_info: Dict[str, Dict] = {}

        for app in valid_apps:
            app_key = app.get('Key', '')
            app_name = app.get('Name', '')
            versions = app_versions_results.get(app_name, [])

            for version in versions:
                v_key = version.get('Key', '')
                if v_key:
                    version_key_to_info[v_key] = {
                        'version_number': version.get('Version', ''),
                        'created_on_raw': version.get('CreatedOn', ''),
                        'app_name': app_name,
                    }

            commit_events = []
            for version in versions:
                app_version_number = version.get('Version', '')
                changelog = version.get('ChangeLog', '')

                for mv in version.get('ModuleVersions', []):
                    created_on_raw = mv.get('CreatedOn', '')
                    if not created_on_raw:
                        continue
                    timestamp_utc = parse_lifetime_timestamp(created_on_raw)
                    if timestamp_utc is None:
                        continue

                    module_key = mv.get('ModuleKey', '')
                    module_name = module_key_to_name.get(module_key, module_key)

                    event = CodeCommitEvent.create_event(
                        timestamp_utc=timestamp_utc,
                        repo_name=app_name,
                        event_type='Code Committed',
                        source_branch=None,
                        target_branch=app_version_number,
                        revision=mv.get('GeneralHash', ''),
                        author=mv.get('CreatedBy', ''),
                        comment=changelog,
                        extended_attributes={
                            'author_email': mv.get('CreatedByUsername', ''),
                            'module': module_name,
                        },
                    )
                    commit_events.append(event)

            if commit_events:
                inserted, _ = save_commit_fn(commit_events)
                logger.info(f"Code Committed: {inserted} events saved for {app_name}")

        # --- Extract Build Created and Deployed events from Deployment Plans ---
        since_iso = extraction_start.strftime('%Y-%m-%d')
        deployments = fetch_deployments(lifetime_url, api_token, since_iso)
        logger.info(f"Found {len(deployments)} deployment plans since {extraction_start}")

        build_events_batch = []
        deploy_events_batch = []

        total_deployments = len(deployments)

        # Fetch deployment statuses in parallel (needed to determine Deployed events)
        def _fetch_status(deployment):
            deployment_key = deployment.get('Key', '')
            if not deployment_key:
                return deployment, None
            return deployment, fetch_deployment_status(lifetime_url, api_token, deployment_key)

        logger.info(f"Fetching status for {total_deployments} deployment plans...")
        deployment_statuses = []
        with ThreadPoolExecutor(max_workers=10) as executor:
            futures = {executor.submit(_fetch_status, d): i for i, d in enumerate(deployments)}
            completed = 0
            for future in as_completed(futures):
                deployment_statuses.append(future.result())
                completed += 1
                if completed % 50 == 0 or completed == total_deployments:
                    logger.info(f"  Fetched {completed}/{total_deployments} deployment statuses")

        # Resolve any ApplicationVersionKeys referenced by deployments but missing from
        # version_key_to_info (e.g. rollbacks or promotions of older versions).
        missing_version_keys: Dict[str, str] = {}  # version_key -> app_key
        for deployment, _ in deployment_statuses:
            for op in deployment.get('ApplicationOperations', []):
                vk = op.get('ApplicationVersionKey', '')
                ak = op.get('ApplicationKey', '')
                if vk and ak and vk not in version_key_to_info:
                    app_name = app_key_to_name.get(ak, '')
                    if should_skip_app(app_name):
                        continue
                    missing_version_keys[vk] = ak

        if missing_version_keys:
            logger.info(f"Fetching {len(missing_version_keys)} application version(s) referenced by deployments but not in recent versions...")

            def _fetch_single_version(version_key, app_key):
                url = f"{lifetime_url}/applications/{app_key}/versions/{version_key}"
                return version_key, app_key, _make_api_request(url, api_token)

            with ThreadPoolExecutor(max_workers=10) as executor:
                futures = {
                    executor.submit(_fetch_single_version, vk, ak): vk
                    for vk, ak in missing_version_keys.items()
                }
                for future in as_completed(futures):
                    version_key, app_key, version_data = future.result()
                    if version_data and isinstance(version_data, dict):
                        app_name = app_key_to_name.get(app_key, app_key)
                        version_key_to_info[version_key] = {
                            'version_number': version_data.get('Version', ''),
                            'created_on_raw': version_data.get('CreatedOn', ''),
                            'app_name': app_name,
                        }
                    else:
                        logger.warning(f"Could not resolve version metadata for ApplicationVersionKey={version_key} — Build Created and Deployed events for this version will be skipped")

        for deployment, status_response in deployment_statuses:
            deployment_key = deployment.get('Key', '')
            status_str = (status_response or {}).get('DeploymentStatus', '') if status_response else ''
            status_lower = status_str.lower()

            source_env_key = deployment.get('SourceEnvironmentKey', '')
            target_env_key = deployment.get('TargetEnvironmentKey', '')
            source_env_name = environments.get(source_env_key, source_env_key)
            target_env_name = environments.get(target_env_key, target_env_key)
            requested_by = deployment.get('CreatedBy', '')

            # Deployed timestamp: last entry in DeploymentLog
            deploy_log = (status_response or {}).get('DeploymentLog', [])
            last_log_instant = deploy_log[-1].get('Instant', '') if deploy_log else ''
            deploy_timestamp = parse_lifetime_timestamp(last_log_instant) if last_log_instant else None

            app_operations = deployment.get('ApplicationOperations', [])
            for op in app_operations:
                op_app_key = op.get('ApplicationKey', '')
                app_name = app_key_to_name.get(op_app_key, '')

                # Skip apps excluded by the configured filter
                if not app_name or should_skip_app(app_name):
                    continue

                # Resolve version info from the version_key_to_info dict
                app_version_key = op.get('ApplicationVersionKey', '')
                version_info = version_key_to_info.get(app_version_key, {})
                version_number = version_info.get('version_number', '')
                version_created_on_raw = version_info.get('created_on_raw', '')
                build_timestamp = parse_lifetime_timestamp(version_created_on_raw) if version_created_on_raw else None

                if not build_timestamp:
                    logger.warning(
                        f"No version metadata for ApplicationVersionKey={app_version_key} "
                        f"in deployment {deployment_key} — skipping Build Created and Deployed events"
                    )
                    continue

                # Build Created event
                build_event = {
                    'timestamp_utc': build_timestamp,
                    'event': 'Build Created',
                    'repo': app_name,
                    'source_branch': version_number,
                    'build_id': app_version_key,
                    'workflow_name': deployment_key,
                    'build_number': version_number,
                    'actor': requested_by,
                    'comment': None,
                }
                build_events_batch.append(build_event)

                # Deployed event — only for finished_successful plans
                if status_lower == 'finished_successful' and deploy_timestamp:
                    deployment_notes = deployment.get('Notes') or None
                    comment_dict = {'source_environment': source_env_name}
                    if deployment_notes:
                        comment_dict['notes'] = deployment_notes
                    deploy_comment = json.dumps(comment_dict)
                    parts = version_number.split('.') if version_number else []
                    is_major_release = len(parts) == 2 and all(p.isdigit() for p in parts)
                    deploy_event = {
                        'timestamp_utc': deploy_timestamp,
                        'event': 'Deployed',
                        'build_name': deployment_key,
                        'repo': app_name,
                        'source_branch': version_number,
                        'build_id': app_version_key,
                        'environment': target_env_name,
                        'release_version': version_number,
                        'is_major_release': is_major_release,
                        'comment': deploy_comment,
                    }
                    deploy_events_batch.append(deploy_event)

        if build_events_batch:
            inserted, _ = save_build_fn(build_events_batch)
            logger.info(f"Build Created: {inserted} events saved")

        if deploy_events_batch:
            inserted, _ = save_deploy_fn(deploy_events_batch)
            logger.info(f"Deployed: {inserted} events saved")

        # Print summary
        if cursor:
            logger.info(
                f"Total inserted — "
                f"Code Committed: {self.stats['code_commit_events_inserted']} "
                f"(skipped {self.stats['code_commit_events_duplicates']}), "
                f"Build Created: {self.stats['build_events_inserted']} "
                f"(skipped {self.stats['build_events_duplicates']}), "
                f"Deployed: {self.stats['deployment_events_inserted']} "
                f"(skipped {self.stats['deployment_events_duplicates']})"
            )
        else:
            logger.info("Extraction completed")


# =============================================================================
# API HELPERS
# =============================================================================

def _make_api_request(
    url: str,
    api_token: str,
    params: Dict = None,
) -> Optional[Any]:
    """
    Make a GET request to the LifeTime API with retry logic.

    Args:
        url: Full API URL
        api_token: LifeTime Service API token
        params: Optional query parameters

    Returns:
        Parsed JSON response (dict or list) or None on failure
    """
    headers = {
        'Authorization': f'Bearer {api_token}',
        'Content-Type': 'application/json',
    }

    max_retries = 3
    retry_delay = 1

    for attempt in range(max_retries):
        try:
            response = requests.get(url, headers=headers, params=params, timeout=30)

            if response.status_code == 200:
                return response.json()
            elif response.status_code in (401, 403):
                Utils.fatal(
                    Utils.format_http_error(
                        "GET",
                        response.url,
                        response.status_code,
                        getattr(response, 'reason', '') or '',
                        response.text,
                        response.headers.get('Content-Type'),
                    ),
                    context="_make_api_request",
                    logger=logger,
                )
            elif response.status_code == 404:
                logger.warning(
                    Utils.format_http_error(
                        "GET",
                        response.url,
                        response.status_code,
                        getattr(response, 'reason', '') or '',
                        response.text,
                        response.headers.get('Content-Type'),
                    )
                )
                return None
            else:
                logger.warning(
                    Utils.format_http_error(
                        "GET",
                        response.url,
                        response.status_code,
                        getattr(response, 'reason', '') or '',
                        response.text,
                        response.headers.get('Content-Type'),
                    )
                )
                if attempt < max_retries - 1:
                    time.sleep(retry_delay * (2 ** attempt))
                    continue
                break

        except requests.exceptions.RequestException as e:
            logger.warning(f"Request failed (attempt {attempt + 1}): {e}")
            if attempt < max_retries - 1:
                time.sleep(retry_delay * (2 ** attempt))
                continue
            Utils.fatal(
                f"OutSystems API request failed after retries: {e}",
                context="_make_api_request",
                logger=logger,
            )

    return None


def fetch_environments(lifetime_url: str, api_token: str) -> Dict[str, str]:
    """
    Fetch all environments.

    Returns:
        {environment_key: environment_name}
    """
    url = f"{lifetime_url}/environments"
    data = _make_api_request(url, api_token)
    if not data or not isinstance(data, list):
        return {}
    return {env.get('Key', ''): env.get('Name', '') for env in data if env.get('Key')}


def fetch_applications(
    lifetime_url: str,
    api_token: str,
    app_filter: List[str],
    include_applications: bool = True,
) -> List[Dict]:
    """
    Fetch applications, applying inclusion or exclusion filtering.

    Args:
        app_filter: List of application names to include or exclude.
        include_applications: When True, return only apps in app_filter (inclusion mode).
                              When False, return all apps except those in app_filter (exclusion mode).
                              An empty app_filter in exclusion mode returns all applications.

    Returns:
        List of application dicts.
    """
    url = f"{lifetime_url}/applications"
    params = {'IncludeModules': 'false', 'IncludeEnvStatus': 'false'}
    data = _make_api_request(url, api_token, params=params)
    if not data or not isinstance(data, list):
        return []

    if app_filter:
        filter_lower = {name.lower() for name in app_filter}
        if include_applications:
            return [app for app in data if app.get('Name', '').lower() in filter_lower]
        else:
            return [app for app in data if app.get('Name', '').lower() not in filter_lower]
    return data


def fetch_modules(lifetime_url: str, api_token: str) -> Dict[str, str]:
    """
    Fetch all modules and return a dict mapping module Key -> module Name.
    """
    url = f"{lifetime_url}/modules"
    data = _make_api_request(url, api_token)
    if not data or not isinstance(data, list):
        return {}
    return {m.get('Key', ''): m.get('Name', '') for m in data if m.get('Key')}


def fetch_application_versions(
    lifetime_url: str,
    api_token: str,
    app_key: str,
    since: datetime,
) -> List[Dict]:
    """
    Fetch Application Versions created after `since`.

    The LifeTime API does not support pagination for this endpoint; all versions
    up to MaximumVersionsToReturn are returned in a single response, newest first.

    Returns:
        List of version dicts with CreatedOn > since (naive UTC).
    """
    url = f"{lifetime_url}/applications/{app_key}/versions"

    data = _make_api_request(url, api_token, params={'MaximumVersionsToReturn': 100000})
    if not data or not isinstance(data, list):
        return []

    result = []
    for version in data:
        created_on_raw = version.get('CreatedOn', '')
        if not created_on_raw:
            continue
        timestamp = parse_lifetime_timestamp(created_on_raw)
        if timestamp is None:
            continue
        if timestamp <= since:
            break
        result.append(version)

    return result


def fetch_deployments(
    lifetime_url: str,
    api_token: str,
    min_date_iso: str,
) -> List[Dict]:
    """
    Fetch Deployment Plans created on or after min_date_iso.

    Args:
        min_date_iso: Date string in YYYY-MM-DD format, e.g. '2025-01-01'

    Returns:
        List of deployment plan dicts.
    """
    url = f"{lifetime_url}/deployments"
    params = {'MinDate': min_date_iso}
    data = _make_api_request(url, api_token, params=params)
    if not data or not isinstance(data, list):
        return []
    return data


def fetch_deployment_status(
    lifetime_url: str,
    api_token: str,
    deployment_key: str,
) -> Optional[Dict]:
    """
    Fetch the status of a Deployment Plan.

    Returns:
        Full status response dict, or None if unavailable.
        Relevant keys: 'DeploymentStatus', 'DeploymentLog' (list of {Instant, Message}).
    """
    url = f"{lifetime_url}/deployments/{deployment_key}/status"
    data = _make_api_request(url, api_token)
    if not data or not isinstance(data, dict):
        return None
    return data


def parse_lifetime_timestamp(raw: str) -> Optional[datetime]:
    """
    Parse a LifeTime API timestamp string to a naive UTC datetime.

    Accepts ISO 8601 formats including timezone offsets and the trailing Z.
    """
    if not raw:
        return None
    try:
        # Remove trailing Z and handle +00:00
        normalized = raw.replace('Z', '+00:00')
        dt = datetime.fromisoformat(normalized)
        if dt.tzinfo is not None:
            dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
        return dt
    except (ValueError, AttributeError):
        logger.warning(f"Could not parse timestamp: {raw}")
        return None


# =============================================================================
# DATABASE SAVE FUNCTIONS
# =============================================================================

def save_build_events_to_database(events: List[Dict], cursor) -> tuple:
    """Save build events to build_event table. Returns (inserted, duplicates)."""
    from psycopg2.extras import execute_values
    if not events:
        return 0, 0

    cursor.execute("SELECT COUNT(*) FROM build_event")
    count_before = cursor.fetchone()[0]

    values = [
        (
            e.get('timestamp_utc'),
            e.get('event'),
            e.get('repo'),
            e.get('source_branch'),
            e.get('build_id'),
            e.get('build_number'),
            e.get('comment'),
            e.get('actor'),
            e.get('workflow_name'),
        )
        for e in events
    ]

    execute_values(
        cursor,
        """
        INSERT INTO build_event (
            timestamp_utc, event, repo, source_branch, build_id,
            build_number, comment, actor, workflow_name
        ) VALUES %s
        ON CONFLICT ON CONSTRAINT build_event_hash_unique DO NOTHING
        """,
        values,
    )

    cursor.connection.commit()

    cursor.execute("SELECT COUNT(*) FROM build_event")
    count_after = cursor.fetchone()[0]
    inserted = count_after - count_before
    duplicates = len(events) - inserted
    logger.info(f"Build events: inserted {inserted}, skipped {duplicates} duplicates")
    return inserted, duplicates


def save_deployment_events_to_database(
    events: List[Dict],
    cursor,
) -> tuple:
    """Save deployment events to deployment_event table. Returns (inserted, duplicates)."""
    from psycopg2.extras import execute_values
    if not events:
        return 0, 0

    cursor.execute("SELECT COUNT(*) FROM deployment_event")
    count_before = cursor.fetchone()[0]

    values = []
    for e in events:
        values.append((
            e.get('timestamp_utc'),
            e.get('event'),
            e.get('build_name'),
            e.get('repo'),
            e.get('source_branch'),
            e.get('build_id'),
            e.get('comment'),
            e.get('environment'),
            e.get('is_major_release', False),
            e.get('release_version', ''),
        ))

    execute_values(
        cursor,
        """
        INSERT INTO deployment_event (
            timestamp_utc, event, build_name, repo, source_branch, build_id,
            comment, environment, is_major_release, release_version
        ) VALUES %s
        ON CONFLICT ON CONSTRAINT deployment_event_hash_unique DO NOTHING
        """,
        values,
    )

    cursor.connection.commit()

    cursor.execute("SELECT COUNT(*) FROM deployment_event")
    count_after = cursor.fetchone()[0]
    inserted = count_after - count_before
    duplicates = len(events) - inserted
    logger.info(f"Deployment events: inserted {inserted}, skipped {duplicates} duplicates")
    return inserted, duplicates


# =============================================================================
# ENTRY POINT
# =============================================================================

def main():
    """Main function to run OutSystems extraction."""
    parser = argparse.ArgumentParser(
        description="Extract OutSystems SDLC events into code_commit_event, build_event, and deployment_event."
    )
    parser.add_argument(
        '-p', '--product',
        help='Product name (if provided, saves to database; otherwise saves to CSV)',
    )
    parser.add_argument('-s', '--start-date', help='Start date in YYYY-MM-DD format')
    args = parser.parse_args()

    extractor = OutSystemsExtractor()

    if args.product is None:
        # CSV Mode: load configuration from config.json
        config_path = os.path.join(common_dir, 'config.json')
        with open(config_path, 'r') as f:
            raw_config = json.load(f)

        apps_str = raw_config.get('OUTSYSTEMS_APPLICATIONS', '')
        apps_list = [a.strip() for a in apps_str.split(',') if a.strip()] if apps_str else []

        config = {
            'lifetime_host': raw_config.get('OUTSYSTEMS_ORGANIZATION', ''),
            'api_token': raw_config.get('OUTSYSTEMS_API_TOKEN', ''),
            'applications': apps_list,
            'include_applications': Utils.to_bool(raw_config.get('OUTSYSTEMS_INCLUDE_APPLICATIONS'), default=True),
        }

        last_modified = Utils.load_checkpoint('outsystems')
        extractor.run_extraction(None, config, args.start_date, last_modified)

    else:
        # Database Mode
        from database import DatabaseConnection
        db = DatabaseConnection()
        with db.product_scope(args.product) as conn:
            with conn.cursor() as cursor:
                config = extractor.get_config_from_database(cursor)
                last_modified = extractor.get_last_modified_date(cursor)
                extractor.run_extraction(cursor, config, args.start_date, last_modified)

    return 0


if __name__ == '__main__':
    sys.exit(main())