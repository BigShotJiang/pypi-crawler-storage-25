#!/usr/bin/env python3
"""
Extract GitHub Copilot org metrics (seats, daily usage, detailed breakdowns) to CSV.

Usage:
  python extract_copilot.py                    # CSV mode: common/config.json
  python extract_copilot.py -p <product>       # DB mode: data_source_config (ai_coding_assistant)
  python extract_copilot.py -s 2026-03-01      # Optional start date (YYYY-MM-DD)

CSV mode reads COPILOT_ORGANIZATION and COPILOT_API_TOKEN from
config.json (falls back to GITHUB_*). Output directory is EXPORT_PATH at the
top of the same file (EXPORT_PATH in common.utils).

CSV mode writes three files per run under EXPORT_PATH:
  copilot_seats_YYYYMMDD_HHMMSS.csv
  copilot_usage_YYYYMMDD_HHMMSS.csv
  copilot_usage_details_YYYYMMDD_HHMMSS.csv
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from datetime import date, datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple

import requests

base_dir = os.path.dirname(os.path.abspath(__file__))
common_dir = os.path.join(base_dir, "common")
if not os.path.isdir(common_dir):
    base_dir = os.path.dirname(base_dir)
    common_dir = os.path.join(base_dir, "common")
if os.path.isdir(common_dir) and base_dir not in sys.path:
    sys.path.insert(0, base_dir)

from common.utils import EXPORT_PATH, Utils

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger("extract_copilot")

API_BASE = "https://api.github.com"
API_VERSION = "2026-03-10"

_METRICS = [
    "user_initiated_interaction_count",
    "code_generation_activity_count",
    "code_acceptance_activity_count",
    "loc_suggested_to_add_sum",
    "loc_suggested_to_delete_sum",
    "loc_added_sum",
    "loc_deleted_sum",
]

SUMMARY_COLS = ["user_id", "user_login", "day", "used_agent", "used_chat"] + _METRICS
DETAIL_COLS = ["user_id", "user_login", "day", "ide", "language", "feature", "model"] + _METRICS
SEATS_COLS = [
    "user_id",
    "user_login",
    "assigned_at",
    "last_activity_at",
    "last_activity_editor",
    "pending_cancellation_date",
]


def build_github_headers(api_token: str, accept: str = "application/vnd.github+json", api_version: Optional[str] = None) -> Dict[str, str]:
    headers = {
        "Accept": accept,
        "Authorization": f"Bearer {api_token}",
    }
    if api_version:
        headers["X-GitHub-Api-Version"] = api_version
    return headers


def _export_path() -> str:
    return EXPORT_PATH


def _error_detail(response: requests.Response) -> str:
    try:
        return response.json().get("message", response.text)
    except Exception:
        return response.text


def _to_utc_naive_string(raw: Any) -> Optional[str]:
    if raw is None:
        return None
    s = str(raw).strip()
    if not s:
        return None
    dt = Utils.convert_to_utc(s)
    if dt is None:
        return s
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def _flatten_download_links(links: Any) -> List[str]:
    """Turn API download_links (strings and/or objects) into a list of URLs."""
    if links is None:
        return []
    if isinstance(links, str):
        s = links.strip()
        return [s] if s.startswith("http") else []
    if not isinstance(links, list):
        return []
    out: List[str] = []
    for item in links:
        if isinstance(item, str) and item.strip():
            out.append(item.strip())
        elif isinstance(item, dict):
            for key in ("url", "href", "download_url", "uri"):
                v = item.get(key)
                if isinstance(v, str) and v.strip().startswith("http"):
                    out.append(v.strip())
                    break
    return out


def _coerce_metrics_report_response(raw: Any, fallback_day: str) -> Optional[dict]:
    """Normalize GitHub Copilot metrics report JSON (object, string, or list shapes)."""
    if raw is None:
        return None

    if isinstance(raw, str):
        s = raw.strip()
        if not s:
            return None
        if s.startswith("http://") or s.startswith("https://"):
            return {"report_day": fallback_day, "download_links": [s]}
        if s.startswith("{"):
            try:
                raw = json.loads(s)
            except json.JSONDecodeError:
                return None
        elif s.startswith("["):
            try:
                raw = json.loads(s)
            except json.JSONDecodeError:
                return None
        else:
            return None

    if isinstance(raw, list):
        flat = _flatten_download_links(raw)
        return {"report_day": fallback_day, "download_links": flat} if flat else None

    if isinstance(raw, dict):
        day = raw.get("report_day") or fallback_day
        links = raw.get("download_links")
        if links is None:
            links = raw.get("download_urls") or raw.get("urls")
        if links is None and isinstance(raw.get("download_link"), str):
            links = [raw["download_link"]]
        flat = _flatten_download_links(links)
        return {"report_day": day, "download_links": flat}

    return None


def get_report_links(url: str, headers: Dict[str, str], params: Optional[dict] = None) -> Optional[dict]:
    try:
        response = requests.get(url, headers=headers, params=params, timeout=60)
    except requests.exceptions.RequestException as e:
        return None
    fallback_day = (params or {}).get("day") or ""
    if response.status_code == 200:
        try:
            raw = response.json()
        except ValueError:
            raw = response.text.strip() or None
        coerced = _coerce_metrics_report_response(raw, fallback_day)
        return coerced
    else:
        return None


def fetch_ndjson(url: str) -> Optional[str]:
    response = requests.get(url, timeout=120)
    if response.status_code != 200:
        return None
    return response.text


def fetch_seats(org: str, headers: Dict[str, str]) -> Dict[int, dict]:
    seats: Dict[int, dict] = {}
    page = 1
    while True:
        url = f"{API_BASE}/orgs/{org}/copilot/billing/seats"
        response = requests.get(url, headers=headers, params={"per_page": 100, "page": page}, timeout=60)
        if response.status_code !=200:
            detail = _error_detail(response)
            Utils.fatal(f"Copilot billing seats request failed ({response.status_code}): {detail}", logger=logger)
        data = response.json()
        page_seats = data.get("seats", [])
        for seat in page_seats:
            assignee = seat.get("assignee") or {}
            uid = assignee.get("id")
            if uid:
                assignee_login = (
                    (assignee.get("login") or None)
                    or (assignee.get("user_login") or None)
                )
                seats[int(uid)] = {
                    "user_login": assignee_login,
                    "assigned_at": _to_utc_naive_string(seat.get("created_at")),
                    "last_activity_at": _to_utc_naive_string(seat.get("last_activity_at")),
                    "last_activity_editor": seat.get("last_activity_editor"),
                    "pending_cancellation_date": seat.get("pending_cancellation_date"),
                }
        if len(page_seats) < 100:
            break
        page += 1
    return seats


def _m(obj: dict) -> Dict[str, Any]:
    return {f: obj.get(f) for f in _METRICS}


def _fmt_bool(val: Any) -> str:
    if val is None:
        return ""
    return "true" if bool(val) else "false"


def parse_report_into_rows(
    ndjson_text: str, summary_rows: List[dict], detail_rows: List[dict]
) -> None:
    for line in ndjson_text.splitlines():
        line = line.strip()
        if not line:
            continue
        r = json.loads(line)
        if not (r.get("enterprise_id") or "").strip():
            continue
        uid = r.get("user_id")
        ulogin = r.get("user_login")
        day = r.get("day")
        ctx = {"user_id": uid, "user_login": ulogin, "day": day}

        summary_rows.append(
            {
                **ctx,
                "used_agent": _fmt_bool(r.get("used_agent")),
                "used_chat": _fmt_bool(r.get("used_chat")),
                **_m(r),
            }
        )

        for entry in r.get("totals_by_ide", []):
            detail_rows.append(
                {
                **ctx,
                "ide": entry.get("ide"),
                "language": None,
                "feature": None,
                "model": None,
                **_m(entry),
                }
            )

        for entry in r.get("totals_by_feature", []):
            detail_rows.append(
                {
                **ctx,
                "ide": None,
                "language": None,
                "feature": entry.get("feature"),
                "model": None,
                **_m(entry),
                }
            )

        for entry in r.get("totals_by_language_feature", []):
            detail_rows.append(
                {
                **ctx,
                "ide": None,
                "language": entry.get("language"),
                "feature": entry.get("feature"),
                "model": None,
                **_m(entry),
                }
            )

        for entry in r.get("totals_by_language_model", []):
            detail_rows.append(
                {
                **ctx,
                "ide": None,
                "language": entry.get("language"),
                "feature": None,
                "model": entry.get("model"),
                **_m(entry),
                }
            )

        for entry in r.get("totals_by_model_feature", []):
            detail_rows.append(
                {
                **ctx,
                "ide": None,
                "language": None,
                "feature": entry.get("feature"),
                "model": entry.get("model"),
                **_m(entry),
                }
            )


def _db_upsert_seats(cursor, rows: List[dict]) -> int:
    if not rows:
        return 0
    sql = """
        INSERT INTO ai_coding_assistant_seat (
            user_id, user_login, assigned_at, last_activity_at,
            last_activity_editor, pending_cancellation_date
        ) VALUES (%s, %s, %s, %s, %s, %s)
        ON CONFLICT ON CONSTRAINT ai_coding_assistant_seat_product_user_unique DO UPDATE SET
            user_login = COALESCE(NULLIF(EXCLUDED.user_login, ''), ai_coding_assistant_seat.user_login),
            assigned_at = COALESCE(EXCLUDED.assigned_at, ai_coding_assistant_seat.assigned_at),
            last_activity_at = COALESCE(EXCLUDED.last_activity_at, ai_coding_assistant_seat.last_activity_at),
            last_activity_editor = COALESCE(EXCLUDED.last_activity_editor, ai_coding_assistant_seat.last_activity_editor),
            pending_cancellation_date = COALESCE(
                EXCLUDED.pending_cancellation_date,
                ai_coding_assistant_seat.pending_cancellation_date
            )
    """
    n = 0
    for row in rows:
        uid = row.get("user_id")
        if uid is None:
            continue
        cursor.execute(
            sql,
            (
                uid,
                (row.get("user_login") or None) or None,
                (row.get("assigned_at") or None) or None,
                (row.get("last_activity_at") or None) or None,
                (row.get("last_activity_editor") or None) or None,
                (row.get("pending_cancellation_date") or None) or None,
            ),
        )
        n += 1
    return n


def _db_upsert_usage(cursor, rows: List[dict]) -> int:
    if not rows:
        return 0
    sql = """
        INSERT INTO ai_coding_assistant_usage (
            user_id, user_login, day, used_agent, used_chat,
            user_initiated_interaction_count, code_generation_activity_count,
            code_acceptance_activity_count, loc_suggested_to_add_sum,
            loc_suggested_to_delete_sum, loc_added_sum, loc_deleted_sum
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT ON CONSTRAINT ai_coding_assistant_usage_product_user_day_unique DO UPDATE SET
            user_login = EXCLUDED.user_login,
            used_agent = EXCLUDED.used_agent,
            used_chat = EXCLUDED.used_chat,
            user_initiated_interaction_count = EXCLUDED.user_initiated_interaction_count,
            code_generation_activity_count = EXCLUDED.code_generation_activity_count,
            code_acceptance_activity_count = EXCLUDED.code_acceptance_activity_count,
            loc_suggested_to_add_sum = EXCLUDED.loc_suggested_to_add_sum,
            loc_suggested_to_delete_sum = EXCLUDED.loc_suggested_to_delete_sum,
            loc_added_sum = EXCLUDED.loc_added_sum,
            loc_deleted_sum = EXCLUDED.loc_deleted_sum
    """
    n = 0
    for row in rows:
        uid = row.get("user_id")
        day = row.get("day")
        if uid is None or not day:
            continue
        cursor.execute(
            sql,
            (
                uid,
                (row.get("user_login") or None) or None,
                day,
                None if row.get("used_agent") in ("", None) else bool(str(row.get("used_agent")).lower() == "true"),
                None if row.get("used_chat") in ("", None) else bool(str(row.get("used_chat")).lower() == "true"),
                *(row.get(k) for k in _METRICS),
            ),
        )
        n += 1
    return n


def _db_upsert_usage_details(cursor, rows: List[dict]) -> int:
    if not rows:
        return 0
    sql = """
        INSERT INTO ai_coding_assistant_usage_details (
            user_id, user_login, day, ide, language, feature, model,
            user_initiated_interaction_count, code_generation_activity_count,
            code_acceptance_activity_count, loc_suggested_to_add_sum,
            loc_suggested_to_delete_sum, loc_added_sum, loc_deleted_sum
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT ON CONSTRAINT ai_coding_assistant_usage_details_natural_uq DO UPDATE SET
            user_login = EXCLUDED.user_login,
            user_initiated_interaction_count = EXCLUDED.user_initiated_interaction_count,
            code_generation_activity_count = EXCLUDED.code_generation_activity_count,
            code_acceptance_activity_count = EXCLUDED.code_acceptance_activity_count,
            loc_suggested_to_add_sum = EXCLUDED.loc_suggested_to_add_sum,
            loc_suggested_to_delete_sum = EXCLUDED.loc_suggested_to_delete_sum,
            loc_added_sum = EXCLUDED.loc_added_sum,
            loc_deleted_sum = EXCLUDED.loc_deleted_sum
    """
    n = 0
    for row in rows:
        uid = row.get("user_id")
        day = row.get("day")
        if uid is None or not day:
            continue
        user_login = (row.get("user_login") or None) or None
        ide = (row.get("ide") or None) or None
        language = (row.get("language") or None) or None
        feature = (row.get("feature") or None) or None
        model = (row.get("model") or None) or None
        metrics = tuple(row.get(k) for k in _METRICS)
        cursor.execute(
            sql,
            (
                uid,
                user_login,
                day,
                ide,
                language,
                feature,
                model,
                *metrics,
            ),
        )
        n += 1
    return n


def get_config_from_file() -> Tuple[str, str]:
    """CSV-mode (no -p): read org and PAT from common/config.json.

    Uses COPILOT_ORGANIZATION / COPILOT_API_TOKEN when set, otherwise
    GITHUB_ORGANIZATION / GITHUB_API_TOKEN. Output uses EXPORT_PATH from the same
    JSON (module-level in common.utils).
    """
    cfg_path = os.path.join(common_dir, "config.json")
    with open(cfg_path, encoding="utf-8") as f:
        cfg = json.load(f)
    org = (
        cfg.get("COPILOT_ORGANIZATION")
        or cfg.get("GITHUB_ORGANIZATION")
        or cfg.get("GITHUB_ORG")
        or ""
    ).strip()
    token = (cfg.get("COPILOT_API_TOKEN") or cfg.get("GITHUB_API_TOKEN") or "").strip()
    return org, token


def get_last_loaded_day_from_database(cursor) -> Optional[datetime.date]:
    cursor.execute(
        """
        SELECT MAX(day)
        FROM ai_coding_assistant_usage
        """
    )
    row = cursor.fetchone()
    return row[0] if row and row[0] else None


def resolve_day_range(
    start_date_arg: Optional[str],
    export_path: str,
    last_loaded_day: Optional[datetime.date] = None,
    force_latest_day: bool = False,
    use_fs_checkpoint: bool = True,
) -> Optional[Tuple[datetime, datetime]]:
    """Inclusive day range as datetime at UTC midnight for start/end days. None if nothing to fetch."""
    today_utc = datetime.now(timezone.utc).date()
    end_day = today_utc

    if start_date_arg:
        start_day = datetime.strptime(start_date_arg, "%Y-%m-%d").date()
    else:
        if last_loaded_day is not None:
            start_day = last_loaded_day
        else:
            if use_fs_checkpoint:
                last = Utils.load_checkpoint("copilot", export_path)
                if last:
                    if last.tzinfo:
                        last = last.astimezone(timezone.utc).replace(tzinfo=None)
                    start_day = last.date()
                else:
                    start_day = end_day - timedelta(days=27)
            else:
                start_day = end_day - timedelta(days=27)

    if start_day > end_day:
        if force_latest_day:
            start_day = end_day
        else:
            return None

    start_dt = datetime.combine(start_day, datetime.min.time(), tzinfo=timezone.utc)
    end_dt = datetime.combine(end_day, datetime.min.time(), tzinfo=timezone.utc)
    return start_dt, end_dt


def run_extract(
    org: str,
    api_token: str,
    start_date_arg: Optional[str],
    export_path: str,
    cursor=None,
    last_loaded_day: Optional[datetime.date] = None,
    force_latest_day: bool = False,
    use_fs_checkpoint: bool = True,
) -> int:
    if not org:
        Utils.fatal("Extraction failed: Organization is required.", context="main", logger=logger)
    if not api_token:
        Utils.fatal("Extraction failed: Personal Access Token is required.", context="main", logger=logger)

    headers = build_github_headers(api_token, api_version=API_VERSION)
    resolved = resolve_day_range(
        start_date_arg,
        export_path,
        last_loaded_day=last_loaded_day,
        force_latest_day=force_latest_day,
        use_fs_checkpoint=use_fs_checkpoint,
    )
    if resolved is None:
        if cursor is not None:
            logger.info("Copilot extract: nothing to do (database is current through last available day).")
        else:
            logger.info(
                "Copilot extract: nothing to do (checkpoint is current through last available day). "
                "No CSV files written."
            )
        return 0

    start_dt, end_dt = resolved
    start_day = start_dt.date()
    end_day = end_dt.date()

    base_url = f"{API_BASE}/orgs/{org}/copilot/metrics/reports/users-1-day"
    fetch_jobs: List[Tuple[str, dict, str]] = []
    d = start_day
    while d <= end_day:
        day_str = d.strftime("%Y-%m-%d")
        fetch_jobs.append((base_url, {"day": day_str}, day_str))
        d += timedelta(days=1)

    logger.info("Copilot metrics for org %s: %s .. %s (%s days)", org, start_day, end_day, len(fetch_jobs))

    logger.info("Fetching Copilot billing seats ...")
    seats = fetch_seats(org, headers)
    logger.info("  Seats: %s", len(seats))

    summary_rows: List[dict] = []
    detail_rows: List[dict] = []
    days_fetched = 0
    last_successful_day: Optional[date] = None

    for job_url, job_params, label in fetch_jobs:
        result = get_report_links(job_url, headers, job_params)
        if result is None:
            continue
        if not isinstance(result, dict):
            continue
        links = result.get("download_links", [])
        if not links:
            continue
        report_day = result.get("report_day", label)

        summary_before = len(summary_rows)
        detail_before = len(detail_rows)
        for link in links:
            text = fetch_ndjson(link)
            if text:
                parse_report_into_rows(text, summary_rows, detail_rows)
        days_fetched += 1

        users_today = len(summary_rows) - summary_before
        if users_today > 0:
            logger.info("  [%s] %s users with activity", label, users_today)

        if len(summary_rows) > summary_before or len(detail_rows) > detail_before:
            try:
                last_successful_day = datetime.strptime(report_day, "%Y-%m-%d").date()
            except Exception:
                last_successful_day = None

    logger.info("Days with data: %s; summary rows: %s; detail rows: %s", days_fetched, len(summary_rows), len(detail_rows))

    login_map: Dict[Any, str] = {r["user_id"]: r.get("user_login") or "" for r in summary_rows}
    for r in detail_rows:
        uid = r.get("user_id")
        if uid not in login_map or not login_map.get(uid):
            login_map[uid] = r.get("user_login") or ""

    seats_rows = [
        {
            "user_id": uid,
            "user_login": login_map.get(uid) or seat_data.get("user_login") or "",
            **{k: v for k, v in seat_data.items() if k != "user_login"},
        }
        for uid, seat_data in seats.items()
    ]
    if cursor is not None:
        seat_n = _db_upsert_seats(cursor, seats_rows)
        usage_n = _db_upsert_usage(cursor, summary_rows)
        detail_n = _db_upsert_usage_details(cursor, detail_rows)
        logger.info(
            "Upserted rows - seat: %s, usage: %s, usage_details: %s",
            seat_n,
            usage_n,
            detail_n,
        )
    else:
        stamp_d = datetime.now().strftime("%Y%m%d")
        stamp_t = datetime.now().strftime("%H%M%S")
        os.makedirs(export_path, exist_ok=True)
        summary_path = os.path.join(export_path, f"copilot_usage_{stamp_d}_{stamp_t}.csv")
        detail_path = os.path.join(export_path, f"copilot_usage_details_{stamp_d}_{stamp_t}.csv")
        seats_path = os.path.join(export_path, f"copilot_seats_{stamp_d}_{stamp_t}.csv")

        for _path in (summary_path, detail_path, seats_path):
            open(_path, "w").close()

        Utils.save_events_to_csv(
            [{k: row.get(k) for k in SUMMARY_COLS} for row in summary_rows],
            summary_path,
            logger,
        )
        Utils.save_events_to_csv(
            [{k: row.get(k) for k in DETAIL_COLS} for row in detail_rows],
            detail_path,
            logger,
        )
        Utils.save_events_to_csv(
            [{k: row.get(k) for k in SEATS_COLS} for row in seats_rows],
            seats_path,
            logger,
        )

        logger.info("Saved %s", os.path.basename(summary_path))
        logger.info("Saved %s", os.path.basename(detail_path))
        logger.info("Saved %s", os.path.basename(seats_path))

    if cursor is None:
        if last_successful_day is not None:
            Utils.save_checkpoint(
                "copilot",
                datetime.combine(last_successful_day, datetime.min.time()).replace(tzinfo=timezone.utc),
                export_path,
            )
        else:
            logger.info("Copilot extract: no successful day parsed; checkpoint not advanced.")
    return 0


def main() -> int:
    try:
        parser = argparse.ArgumentParser(description="Extract GitHub Copilot usage to CSV")
        parser.add_argument("-p", "--product", help="Product name (reads ai_coding_assistant config from DB)")
        parser.add_argument("-s", "--start-date", help="Start date YYYY-MM-DD")
        args = parser.parse_args()

        export_path = _export_path()

        if args.product:
            from database import DatabaseConnection

            db = DatabaseConnection()
            try:
                with db.product_scope(args.product) as conn:
                    with conn.cursor() as cursor:
                        cfg = Utils.get_data_source_config(
                            cursor, "ai_coding_assistant", ["Organization", "Personal Access Token"]
                        )
                        org = cfg.get("Organization", "").strip()
                        token = cfg.get("Personal Access Token", "").strip()
                        last_loaded_day = get_last_loaded_day_from_database(cursor)
                        rc = run_extract(
                            org,
                            token,
                            args.start_date,
                            export_path,
                            cursor=cursor,
                            last_loaded_day=last_loaded_day,
                            force_latest_day=False,
                            use_fs_checkpoint=False,
                        )
                        conn.commit()
                        return rc
            except SystemExit:
                raise
            except Exception as e:
                Utils.fatal(f"Extraction failed: {e}", context="main", logger=logger)
        else:
            org, token = get_config_from_file()
            return run_extract(org, token, args.start_date, export_path, force_latest_day=False)
    except Exception as e:
        Utils.fatal(f"Unhandled exception: {e}", context="main", logger=logger)


if __name__ == "__main__":
    sys.exit(main())
