#!/usr/bin/env python3
"""
GitHub Data Extraction Script

This script extracts code events from GitHub repositories and saves them to the database.
Supports both fast and enriched extraction modes.

Usage:
    python extract_github.py -p <product_name> [-s <start_date>]

Modes:
    - Fast Mode: Used for initial extraction or when start_date is specified
      * Pull Request Created/Merged/Closed from /pulls API
      * Code Pushed, Initial Push, and Branch Deleted from /activity API
      * Code Committed from /commits API across all branches (with target_branch)
      * Tag Created from /tags API
      * Faster extraction with optimized pagination
    
    - Enriched Mode: Automatically used for incremental extraction (no start_date)
      * Pull Request Approved events with actual timestamps from /pulls/{pr_id}/reviews API
      * Code Committed from /commits API across all branches (with target_branch)

Events extracted:
    Both Modes:
    - Pull Request Created
    - Pull Request Merged
    - Pull Request Closed
    - Code Pushed (activity_type: "push")
    - Initial Push (activity_type: "branch_creation")
    - Branch Deleted (activity_type: "branch_deletion")
    - Code Committed (from /commits API across all branches, with target_branch)
    - Tag Created

    Enriched Mode (additional events extracted):
    - Pull Request Approved (with actual approval timestamps from /reviews API)

Extended Attributes:
    - Pull Request events (Created/Merged/Closed/Approved): pull_request_number, pull_request_title
    - Code Committed: parent_ids (list of parent commit SHAs)

Note:
    - Code Committed events are extracted from all existing branches, default branch first.
    - Commits are deduplicated by SHA across branches.
    - Extraction stops early per branch on reaching a previously-extracted SHA (all ancestry already captured).
    - Commits on deleted branches not merged to any surviving branch are not recoverable via the API.
"""

import argparse
import json
import logging
import os
import sys
import time
from datetime import datetime, timezone
from typing import List, Dict, Optional

base_dir = os.path.dirname(os.path.abspath(__file__))
common_dir = os.path.join(base_dir, "common")
if not os.path.isdir(common_dir):
    # go up one level to find "common" (for installed package structure)
    base_dir = os.path.dirname(base_dir)
    common_dir = os.path.join(base_dir, "common")

if os.path.isdir(common_dir) and base_dir not in sys.path:
    sys.path.insert(0, base_dir)

import requests

from common.code_commit_event import CodeCommitEvent
from common.utils import Utils

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('extract_github')

# Set logger for CodeCommitEvent
CodeCommitEvent.LOGGER = logger

class GitHubExtractor:
    """Extracts code events from GitHub repositories with extended_attributes support."""
    
    def __init__(self):
        self.db_connection = None

        # Tracks which permission categories have been denied at runtime (403 not rate-limit).
        # Keys: 'has_contents', 'has_pull_requests'. Values start True; set to False on first
        # permission-denied 403 so subsequent calls of that type are skipped immediately.
        self.token_permissions = {'has_contents': True, 'has_pull_requests': True}

        # Track extracted commits in memory (repo, commit_id)
        self.extracted_commits = set()

        # Commits extracted from the default branch (repo, commit_id).
        # Used as the safe early-stop anchor for non-default branch traversal:
        # only SHAs whose full ancestry was captured during the default branch's
        # complete run are eligible to stop the per-branch loop.
        self.main_commits = set()
        
        # Statistics
        self.stats = {
            'Pull Request Created': 0,
            'Pull Request Merged': 0,
            'Pull Request Closed': 0,
            'Pull Request Approved': 0,
            'Code Committed': 0,
            'Code Pushed': 0,
            'Initial Push': 0,
            'Branch Deleted': 0,
            'Tag Created': 0,
            'total_inserted': 0,
            'total_duplicates': 0
        }
        
    def get_config_from_database(self, cursor):
        """Get GitHub configuration from data_source_config table."""
        query = """
        SELECT config_item, config_value 
        FROM data_source_config 
        WHERE data_source = 'source_code_revision_control' 
        AND config_item IN ('Organization', 'Personal Access Token', 'Repos', 'Include Repos')
        """
        cursor.execute(query)
        results = cursor.fetchall()
        
        config = {}
        for config_item, config_value in results:
            if config_item == 'Repos':
                try:
                    repos = json.loads(config_value) if config_value else []
                    config['repos'] = repos if repos else []
                except (json.JSONDecodeError, TypeError):
                    config['repos'] = []
            elif config_item == 'Organization':
                config['owner'] = config_value
            elif config_item == 'Personal Access Token':
                config['api_token'] = config_value
            elif config_item == 'Include Repos':
                config['include_repos'] = Utils.to_bool(config_value, default=True)
            
        return config

    def _fetch_all_repos(self, owner: str, api_token: str) -> List[str]:
        repos = []
        for url in (f"https://api.github.com/orgs/{owner}/repos",):
            page = 1
            while True:
                allow_404 = "/orgs/" in url
                data = self._make_api_request(url, api_token, {'per_page': 100, 'page': page}, allow_404=allow_404)
                if not data or not isinstance(data, list):
                    break
                repos.extend([r.get('name') for r in data if r.get('name')])
                if len(data) < 100:
                    break
                page += 1
            if repos:
                break
        return repos
    
    def get_last_modified_date(self, cursor) -> Optional[datetime]:
        """Get the last modified date from the database."""
        last_modified = CodeCommitEvent.get_last_event(cursor)
        if last_modified:
            # Convert to naive datetime if timezone-aware
            if last_modified.tzinfo is not None:
                last_modified = last_modified.replace(tzinfo=None)
        return last_modified

    def _make_api_request(self, url: str, api_token: str, params: Dict = None, return_headers: bool = False, allow_404: bool = False, required_permission: str = None):
        """
        Make an API request to GitHub with retry logic.

        Args:
            url: Full API URL
            api_token: GitHub Personal Access Token
            params: Query parameters
            return_headers: If True, return tuple of (data, headers)
            required_permission: If set (e.g. 'contents' or 'pull_requests'), a
                403 permission-denied response will update self.token_permissions
                and return None rather than terminating the process.

        Returns:
            Response JSON as dict or list, or None if request fails
            If return_headers=True, returns tuple of (data, headers)
        """
        # Fast-path: skip the network call entirely when the required permission
        # is already known to be denied (set by a previous 403 response).
        if required_permission and self.token_permissions is not None:
            if not self.token_permissions.get(f'has_{required_permission}', True):
                if return_headers:
                    return None, None
                return None

        headers = {
            'Accept': 'application/vnd.github+json',
            'X-GitHub-Api-Version': '2022-11-28'
        }
        if api_token and api_token.strip():
            headers['Authorization'] = f'Bearer {api_token}'
        
        max_retries = 3
        retry_delay = 1
        
        for attempt in range(max_retries):
            try:
                response = requests.get(url, headers=headers, params=params, timeout=30)
                
                if response.status_code == 200:
                    data = response.json()
                    if return_headers:
                        return data, response.headers
                    return data
                elif response.status_code == 403:
                    # Rate limit exceeded only when remaining quota is zero.
                    # GitHub includes X-RateLimit-Reset on every response, so the
                    # presence of that header alone does not indicate a rate limit —
                    # X-RateLimit-Remaining must also be '0'.
                    reset_time = response.headers.get('X-RateLimit-Reset')
                    remaining = response.headers.get('X-RateLimit-Remaining')
                    if reset_time and remaining == '0':
                        wait_time = max(0, int(reset_time) - int(time.time()) + 10)
                        logger.warning(f"Rate limit exceeded. Waiting {wait_time} seconds...")
                        time.sleep(wait_time)
                        continue
                    retry_after = response.headers.get('Retry-After')
                    if retry_after:
                        wait_time = max(0, int(retry_after))
                        logger.warning(f"Secondary rate limit hit. Waiting {wait_time} seconds...")
                        time.sleep(wait_time)
                        continue
                    elif required_permission and self.token_permissions is not None:
                        # Permission-denied for a known permission type: record it
                        # so subsequent calls can be skipped without re-requesting.
                        perm_key = f'has_{required_permission}'
                        if self.token_permissions.get(perm_key, True):
                            self.token_permissions[perm_key] = False
                            logger.warning(
                                f"API token does not have the required '{required_permission}' "
                                f"permission (HTTP 403 from {url}). "
                                f"Related events will be skipped."
                            )
                        if return_headers:
                            return None, None
                        return None
                    else:
                        Utils.fatal(
                            Utils.format_http_error(
                                "GET",
                                response.url,
                                response.status_code,
                                getattr(response, "reason", "") or "",
                                response.text,
                                response.headers.get("Content-Type"),
                            ),
                            context="_make_api_request",
                            logger=logger,
                        )
                elif response.status_code == 404:
                    if allow_404:
                        if return_headers:
                            return None, response.headers
                        return None
                    Utils.fatal(
                        Utils.format_http_error(
                            "GET",
                            response.url,
                            response.status_code,
                            getattr(response, "reason", "") or "",
                            response.text,
                            response.headers.get("Content-Type"),
                        ),
                        context="_make_api_request",
                        logger=logger,
                    )
                elif response.status_code == 401:
                    Utils.fatal(
                        Utils.format_http_error(
                            "GET",
                            response.url,
                            response.status_code,
                            getattr(response, "reason", "") or "",
                            response.text,
                            response.headers.get("Content-Type"),
                        ),
                        context="_make_api_request",
                        logger=logger,
                    )
                else:
                    logger.warning(
                        Utils.format_http_error(
                            "GET",
                            response.url,
                            response.status_code,
                            getattr(response, "reason", "") or "",
                            response.text,
                            response.headers.get("Content-Type"),
                        )
                    )
                    if attempt < max_retries - 1:
                        time.sleep(retry_delay * (2 ** attempt))
                        continue
                    break
                        
            except requests.exceptions.RequestException as e:
                logger.warning(f"Request failed (attempt {attempt + 1}): {e}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay * (2 ** attempt))
                    continue
                break

        if return_headers:
            return None, None
        return None
    
    def _parse_link_header(self, link_header: str) -> Dict[str, str]:
        """
        Parse GitHub's Link header to extract pagination URLs.
        
        Args:
            link_header: Link header value from GitHub API response
            
        Returns:
            Dictionary mapping rel types (next, prev, first, last) to URLs
        """
        links = {}
        if not link_header:
            return links
        
        # Link header format: <url1>; rel="next", <url2>; rel="last"
        for link in link_header.split(','):
            parts = link.split(';')
            if len(parts) == 2:
                url = parts[0].strip().strip('<>')
                rel = parts[1].strip()
                # Extract rel value: rel="next" -> next
                if 'rel=' in rel:
                    rel_value = rel.split('=')[1].strip('"')
                    links[rel_value] = url
        
        return links
    
    # ============================================================================
    # EXTRACTION METHODS (FAST MODE)
    # ============================================================================

    def get_branches(self, owner: str, repo_name: str, api_token: str) -> List[str]:
        """
        Get all branches in the repository, with the default branch first.

        Args:
            owner: Repository owner
            repo_name: Repository name
            api_token: GitHub API token

        Returns:
            List of branch names, default branch at index 0
        """
        # Determine the default branch
        repo_url = f"https://api.github.com/repos/{owner}/{repo_name}"
        repo_data = self._make_api_request(repo_url, api_token, required_permission='contents')
        default_branch = repo_data.get('default_branch', 'main') if repo_data else 'main'

        # Fetch all branches
        url = f"https://api.github.com/repos/{owner}/{repo_name}/branches"
        params = {'per_page': 100, 'page': 1}

        all_branch_names = []
        page = 1

        while True:
            params['page'] = page
            data = self._make_api_request(url, api_token, params, required_permission='contents')
            if not data or not isinstance(data, list):
                break
            all_branch_names.extend([b['name'] for b in data])
            if len(data) < 100:
                break
            page += 1

        # Ensure default branch is first
        if default_branch in all_branch_names:
            all_branch_names.remove(default_branch)
        all_branch_names.insert(0, default_branch)

        logger.info(f"[Branches] Found {len(all_branch_names)} branches for repo '{repo_name}' (default: '{default_branch}')")
        return all_branch_names

    def process_repositories(self, owner: str, repos: List[str], api_token: str, start_date: datetime, is_enriched_mode: bool = False, save_fn=None):
        """Process all repositories, saving events periodically via save_fn."""
        for repo_name in repos:
            logger.info(f"Processing repository: {repo_name}")

            try:
                # 1. Pull Requests (PR Created/Merged/Closed)
                # Requires Pull requests:read permission
                pr_details = []
                if self.token_permissions['has_pull_requests']:
                    pr_events = self.fetch_pull_requests(owner, repo_name, api_token, start_date, store_details=is_enriched_mode, pr_details_out=pr_details if is_enriched_mode else None)
                    if pr_events:
                        save_fn(pr_events)

                # 1.5. Enriched Mode: Fetch PR Approved events with actual timestamps
                # Requires Pull requests:read permission
                if is_enriched_mode and pr_details and self.token_permissions['has_pull_requests']:
                    logger.info(f"[Enriched Mode] Fetching PR approvals for '{repo_name}'")
                    approval_events = self.enrich_pull_requests_with_approvals(
                        owner, repo_name, api_token, pr_details, start_date
                    )
                    if approval_events:
                        self.stats['Pull Request Approved'] += len(approval_events)
                        save_fn(approval_events)

                # 2. Activity Events (Code Pushed, Initial Push, Branch Deleted)
                # Requires Contents:read permission
                if self.token_permissions['has_contents']:
                    activity_events = self.fetch_activity_events(owner, repo_name, api_token, start_date)
                    if activity_events:
                        save_fn(activity_events)

                # 3. Get all branches (default branch first) + 4. Commits
                # Requires Contents:read permission
                if self.token_permissions['has_contents']:
                    branches = self.get_branches(owner, repo_name, api_token)
                    self.fetch_commits(owner, repo_name, api_token, start_date, branches, save_fn)

                # 5. Tags
                # Requires Contents:read permission (for individual commit detail lookups)
                if self.token_permissions['has_contents']:
                    tag_events = self.fetch_tags(owner, repo_name, api_token, start_date)
                    if tag_events:
                        save_fn(tag_events)

            except Exception as e:
                logger.error(f"Error processing repository {repo_name}: {e}")
                continue

    def fetch_pull_requests(self, owner: str, repo_name: str, api_token: str, start_date: datetime, store_details: bool = False, pr_details_out: List = None) -> List[Dict]:
        """
        Fetch pull requests and extract PR events with extended_attributes.
        
        Args:
            owner: Repository owner
            repo_name: Repository name
            api_token: GitHub API token
            start_date: Start date for filtering
            store_details: If True, store PR details in pr_details_out for enrichment
            pr_details_out: List to store PR details (required if store_details=True)
            
        Returns:
            List of PR events (Created/Merged/Closed)
        """
        url = f"https://api.github.com/repos/{owner}/{repo_name}/pulls"
        params = {
            'state': 'all',
            'sort': 'created',
            'direction': 'desc',
            'per_page': 100,
            'page': 1
        }
        
        events = []
        page = 1
        start_date_naive = start_date if not start_date.tzinfo else start_date.replace(tzinfo=None)
        
        while True:
            params['page'] = page
            logger.info(f"[PR] Fetching page {page} for repo '{repo_name}' from {url}?page={page}")

            data = self._make_api_request(url, api_token, params, required_permission='pull_requests')
            if not data or not isinstance(data, list):
                break

            prs = data
            if not prs:
                break
            
            # Track if any PRs on this page are recent enough
            has_recent_pr = False
                
            for pr in prs:
                pr_number = pr.get('number')
                title = pr.get('title', '')
                body = pr.get('body', '')
                author = pr.get('user', {}).get('login', '')
                contributor_id = str(pr.get('user', {}).get('id', '') or '')
                
                # Get branch information
                head = pr.get('head', {})
                base = pr.get('base', {})
                source_branch = head.get('ref', '')
                target_branch = base.get('ref', '')
                sha = head.get('sha', '')
                
                created_at = Utils.convert_to_utc(pr.get('created_at'))
                if not created_at:
                    continue
                
                # Check if PR is recent enough
                if created_at < start_date_naive:
                    continue
                
                has_recent_pr = True
                
                # Store PR details for enrichment if requested
                if store_details and pr_details_out is not None:
                    pr_details_out.append(pr)
                
                merged_at = Utils.convert_to_utc(pr.get('merged_at')) if pr.get('merged_at') else None
                closed_at = Utils.convert_to_utc(pr.get('closed_at')) if pr.get('closed_at') else None

                # Extended attributes for PR events
                extended_attrs = {
                    'pull_request_number': pr_number,
                    'pull_request_title': title,
                }
                if contributor_id:
                    extended_attrs['contributor_id'] = contributor_id
                events.append(CodeCommitEvent.create_event(
                    timestamp_utc=created_at,
                    repo_name=repo_name,
                    event_type='Pull Request Created',
                    source_branch=source_branch,
                    target_branch=target_branch,
                    revision=sha,
                    author=author,
                    comment=body if body else title,
                    extended_attributes=extended_attrs
                ))
                self.stats['Pull Request Created'] += 1

                # PR Merged event
                if merged_at:
                    merge_commit_sha = pr.get('merge_commit_sha', '')
                    events.append(CodeCommitEvent.create_event(
                        timestamp_utc=merged_at,
                        repo_name=repo_name,
                        event_type='Pull Request Merged',
                        source_branch=source_branch,
                        target_branch=target_branch,
                        revision=merge_commit_sha,
                        author=author,
                        comment=title,
                        extended_attributes=extended_attrs
                    ))
                    self.stats['Pull Request Merged'] += 1
                
                # PR Closed event (only if closed but not merged)
                elif closed_at and not merged_at:
                    events.append(CodeCommitEvent.create_event(
                        timestamp_utc=closed_at,
                        repo_name=repo_name,
                        event_type='Pull Request Closed',
                        source_branch=source_branch,
                        target_branch=target_branch,
                        revision=sha,
                        author=author,
                        comment=title,
                        extended_attributes=extended_attrs
                    ))
                    self.stats['Pull Request Closed'] += 1

            logger.info(f"[PR] Page {page}: Fetched {len(prs)} pull requests ({len([e for e in events if e])} events)")
            
            # Early termination: if no recent PRs on this page, stop
            if not has_recent_pr:
                logger.info(f"[PR] Stopping at page {page} - all PRs are older than start_date")
                break
            
            if len(prs) < 100:
                break
            page += 1
            
        logger.info(f"[PR] Fetched {len(events)} PR events for '{repo_name}'")
        logger.info(f"[PR] Completed processing pull requests for repo '{repo_name}'")
        return events

    def fetch_activity_events(self, owner: str, repo_name: str, api_token: str, start_date: datetime) -> List[Dict]:
        """
        Fetch repository activity events from activity API.
        
        Extracts:
        - Code Pushed (activity_type: "push")
        - Initial Push (activity_type: "branch_creation")
        - Branch Deleted (activity_type: "branch_deletion")
        
        Note: GitHub activity API uses Link header pagination, not query parameters.
        Activities are sorted by timestamp descending.
        """
        url = f"https://api.github.com/repos/{owner}/{repo_name}/activity"
        params = {
            'per_page': 100
        }
        
        events = []
        iteration = 1
        start_date_naive = start_date if not start_date.tzinfo else start_date.replace(tzinfo=None)
        
        while url:
            logger.info(f"[Activity] Fetching iteration {iteration} for repo '{repo_name}' from {url}")

            result = self._make_api_request(url, api_token, params if iteration == 1 else None, return_headers=True, required_permission='contents')
            if not result or result[0] is None:
                break
            
            data, response_headers = result
            if not isinstance(data, list):
                break

            activities = data
            if not activities:
                break
            
            # Track the earliest timestamp for early termination
            earliest_timestamp = None
                
            for activity in activities:
                timestamp = Utils.convert_to_utc(activity.get('timestamp'))
                if timestamp:
                    # Track earliest timestamp for early termination
                    if not earliest_timestamp or timestamp < earliest_timestamp:
                        earliest_timestamp = timestamp
                
                activity_type = activity.get('activity_type', '')
                
                # Process push, branch_creation, and branch_deletion activities
                if activity_type not in ('push', 'branch_creation', 'branch_deletion'):
                    continue
                
                if not timestamp:
                    continue
                
                # Skip if older than start_date
                if timestamp < start_date_naive:
                    continue
                
                actor = activity.get('actor', {}).get('login', '')
                ref = activity.get('ref', '')
                
                # Determine branch name
                if ref and ref.startswith('refs/heads/'):
                    branch_name = ref.replace('refs/heads/', '')
                else:
                    continue
                
                # Get before and after commits
                before_sha = activity.get('before', '')
                after_sha = activity.get('after', '')
                
                # Determine event type based on activity_type
                if activity_type == 'branch_creation':
                    event_type = 'Initial Push'
                    revision = after_sha
                    self.stats['Initial Push'] += 1
                elif activity_type == 'branch_deletion':
                    event_type = 'Branch Deleted'
                    revision = before_sha
                    self.stats['Branch Deleted'] += 1
                else:  # activity_type == 'push'
                    event_type = 'Code Pushed'
                    revision = after_sha
                    self.stats['Code Pushed'] += 1
                
                events.append(CodeCommitEvent.create_event(
                    timestamp_utc=timestamp,
                    repo_name=repo_name,
                    event_type=event_type,
                    source_branch='',
                    target_branch=branch_name,
                    revision=revision,
                    author=actor,
                    comment=''
                ))

            logger.info(f"[Activity] Iteration {iteration}: Fetched {len(activities)} activities")
            
            # Early termination: if earliest timestamp is older than start_date, stop
            if earliest_timestamp and earliest_timestamp < start_date_naive:
                logger.info(f"[Activity] Stopping at iteration {iteration} - earliest activity ({earliest_timestamp}) is older than start_date ({start_date_naive})")
                break
            
            # Parse Link header for next page URL
            link_header = response_headers.get('Link', '')
            links = self._parse_link_header(link_header)
            
            # Get next page URL
            url = links.get('next')
            if not url:
                logger.info(f"[Activity] No more pages available")
                break
            
            iteration += 1
            
        logger.info(f"[Activity] Fetched {len(events)} activity events for '{repo_name}'")
        logger.info(f"[Activity] Completed processing activity for repo '{repo_name}'")
        return events

    def fetch_commits(self, owner: str, repo_name: str, api_token: str, start_date: datetime, branches: List[str], save_fn):
        """
        Fetch commits from all branches, deduplicating by SHA, saving each page.

        Processes branches in order (default branch first). For each branch, pages
        backward through commits stopping early when a commit SHA already present in
        extracted_commits is encountered (all ancestry is already captured) or when
        the author date falls before start_date (clock-skew guard). Calls save_fn
        after every page of commits.

        Args:
            owner: Repository owner
            repo_name: Repository name
            api_token: GitHub API token
            start_date: Lower bound for commit author date
            branches: Ordered list of branch names, default branch first
            save_fn: Callable(events) — persists a batch of events immediately
        """
        start_date_naive = start_date if not start_date.tzinfo else start_date.replace(tzinfo=None)
        total_commit_count = 0
        default_branch = branches[0] if branches else None

        for branch in branches:
            url = f"https://api.github.com/repos/{owner}/{repo_name}/commits"
            params = {
                'sha': branch,
                'since': start_date_naive.isoformat() + 'Z',
                'per_page': 100,
                'page': 1
            }

            page = 1
            stop_branch = False
            branch_commit_count = 0
            # Frontier of parent SHAs belonging to new (not-yet-extracted) commits
            # that have not yet appeared in the API stream. Kept branch-local so that
            # we stop as soon as all branch-exclusive commits are found rather than
            # paging through the entire already-extracted default-branch ancestry.
            # Invariant: when unresolved is empty and we encounter an already-extracted
            # SHA, every commit reachable from this branch tip is already captured.
            unresolved = set()

            while not stop_branch:
                params['page'] = page
                logger.info(f"[Commit] Fetching page {page} for branch '{branch}' in repo '{repo_name}'")

                data = self._make_api_request(url, api_token, params, required_permission='contents')
                if not data or not isinstance(data, list):
                    break

                commits = data
                if not commits:
                    break

                page_events = []
                for commit in commits:
                    commit_sha = commit.get('sha', '')

                    # This SHA has arrived in the stream — remove from frontier
                    unresolved.discard(commit_sha)

                    if (repo_name, commit_sha) in self.extracted_commits:
                        # Already extracted. Safe to stop only when:
                        # 1. This SHA is in main_commits — meaning its full ancestry
                        #    was captured during the default branch's complete run
                        #    (not a partial non-default branch traversal), AND
                        # 2. The frontier is empty — no branch-exclusive commits are
                        #    still pending (handles merge-from-main interleaving).
                        if (repo_name, commit_sha) in self.main_commits and not unresolved:
                            stop_branch = True
                            break
                        continue

                    commit_data = commit.get('commit', {})
                    message = commit_data.get('message', '')
                    author_data = commit_data.get('author', {})
                    author = author_data.get('name', '')  # git-level name
                    # Top-level 'author' is the GitHub account object; null when git email is not linked to any GitHub account
                    gh_author = commit.get('author') or {}
                    contributor_id = str(gh_author.get('id', '') or '')

                    parents = commit.get('parents', [])
                    parent_ids = [p.get('sha', '') for p in parents if p.get('sha')]

                    commit_dt = Utils.convert_to_utc(author_data.get('date'))
                    if not commit_dt:
                        continue

                    # Client-side guard for clock-skew edge cases
                    if commit_dt < start_date_naive:
                        stop_branch = True
                        break

                    # Extend the frontier with parents we haven't extracted yet
                    for p_sha in parent_ids:
                        if (repo_name, p_sha) not in self.extracted_commits:
                            unresolved.add(p_sha)

                    extended_attrs = {'parent_ids': parent_ids}
                    if contributor_id:
                        extended_attrs['contributor_id'] = contributor_id

                    page_events.append(CodeCommitEvent.create_event(
                        timestamp_utc=commit_dt,
                        repo_name=repo_name,
                        event_type='Code Committed',
                        source_branch='',
                        target_branch=branch,
                        revision=commit_sha,
                        author=author,
                        comment=message,
                        extended_attributes=extended_attrs
                    ))
                    self.stats['Code Committed'] += 1
                    self.extracted_commits.add((repo_name, commit_sha))
                    if branch == default_branch:
                        self.main_commits.add((repo_name, commit_sha))
                    branch_commit_count += 1

                if page_events:
                    save_fn(page_events)

                if stop_branch or len(commits) < 100:
                    break
                page += 1

            total_commit_count += branch_commit_count
            logger.info(f"[Commit] Branch '{branch}': {branch_commit_count} new commits for repo '{repo_name}'")

        logger.info(f"[Commit] Fetched {total_commit_count} total commit events for repo '{repo_name}'")

    def fetch_tags(self, owner: str, repo_name: str, api_token: str, start_date: datetime) -> List[Dict]:
        """Fetch tags."""
        url = f"https://api.github.com/repos/{owner}/{repo_name}/tags"
        params = {'per_page': 100, 'page': 1}

        events = []
        page = 1

        while True:
            params['page'] = page
            logger.info(f"[Tags] Fetching page {page} for repo '{repo_name}' from {url}?page={page}")

            data = self._make_api_request(url, api_token, params, required_permission='contents')
            if not data or not isinstance(data, list):
                break

            tags = data
            if not tags:
                break
                
            for tag in tags:
                tag_name = tag.get('name', '')
                if not tag_name:
                    continue

                commit = tag.get('commit', {})
                commit_sha = commit.get('sha', '')
                
                # Fetch commit details to get timestamp and author
                if commit_sha:
                    commit_url = commit.get('url', '')
                    if commit_url:
                        commit_detail = self._make_api_request(commit_url, api_token, required_permission='contents')
                        if commit_detail:
                            commit_data = commit_detail.get('commit', {})
                            author_data = commit_data.get('author', {})
                            author = author_data.get('name', '')  # git-level name
                            # Top-level 'author' is the GitHub account object; null when git email is not linked to any GitHub account
                            gh_author = commit_detail.get('author') or {}
                            contributor_id = str(gh_author.get('id', '') or '')
                            created_dt = Utils.convert_to_utc(author_data.get('date'))
                            tag_ext = {}
                            if contributor_id:
                                tag_ext['contributor_id'] = contributor_id

                            if created_dt:
                                events.append(CodeCommitEvent.create_event(
                                    timestamp_utc=created_dt,
                                    repo_name=repo_name,
                                    event_type='Tag Created',
                                    source_branch='',
                                    target_branch=tag_name,
                                    revision=commit_sha,
                                    author=author,
                                    comment='',
                                    extended_attributes=tag_ext if tag_ext else None
                                ))
                                self.stats['Tag Created'] += 1

            logger.info(f"[Tags] Page {page}: Fetched {len(tags)} tags")
            
            if len(tags) < 100:
                break
            page += 1

        logger.info(f"[Tags] Fetched {len(events)} tag events for '{repo_name}'")
        logger.info(f"[Tags] Completed processing tags for repo '{repo_name}'")
        return events

    # ============================================================================
    # ENRICHED MODE
    # ============================================================================
    
    def fetch_pr_reviews(self, owner: str, repo_name: str, pr_number: int, api_token: str) -> List[Dict]:
        """
        Fetch reviews for a specific pull request.
        
        API: /repos/{owner}/{repo}/pulls/{pr_number}/reviews
        
        Args:
            owner: Repository owner
            repo_name: Repository name
            pr_number: Pull request number
            api_token: GitHub API token
            
        Returns:
            List of review dictionaries
        """
        url = f"https://api.github.com/repos/{owner}/{repo_name}/pulls/{pr_number}/reviews"
        params = {
            'per_page': 100,
            'page': 1
        }
        
        all_reviews = []
        page = 1
        
        while True:
            params['page'] = page
            
            data = self._make_api_request(url, api_token, params, required_permission='pull_requests')
            if not data or not isinstance(data, list):
                break
            
            reviews = data
            if not reviews:
                break
            
            all_reviews.extend(reviews)
            
            if len(reviews) < 100:
                break
            page += 1
        
        return all_reviews
    
    def enrich_pull_requests_with_approvals(
        self,
        owner: str,
        repo_name: str,
        api_token: str,
        pr_details: List[Dict],
        start_date: datetime
    ) -> List[Dict]:
        """
        Enrich pull requests with approval events.
        
        For each PR, fetches reviews using /pulls/{pr_number}/reviews API
        and creates Pull Request Approved events with actual approval timestamps.
        
        Args:
            owner: Repository owner
            repo_name: Repository name
            api_token: GitHub API token
            pr_details: List of PR details from fetch_pull_requests
            start_date: Start date for filtering
            
        Returns:
            List of Pull Request Approved events
        """
        enriched_events = []
        start_date_naive = start_date if not start_date.tzinfo else start_date.replace(tzinfo=None)
        
        for pr in pr_details:
            try:
                pr_number = pr.get('number')
                if not pr_number:
                    continue
                
                title = pr.get('title', '')
                head = pr.get('head', {})
                base = pr.get('base', {})
                source_branch = head.get('ref', '')
                target_branch = base.get('ref', '')
                sha = head.get('sha', '')
                
                reviews_url = f"https://api.github.com/repos/{owner}/{repo_name}/pulls/{pr_number}/reviews"
                logger.info(f"[Enrichment] Fetching reviews for PR #{pr_number} from {reviews_url}")
                
                # Fetch reviews for this PR
                reviews = self.fetch_pr_reviews(owner, repo_name, pr_number, api_token)
                
                if not reviews:
                    continue
                
                # Extended attributes for PR events
                extended_attrs = {
                    'pull_request_number': pr_number,
                    'pull_request_title': title
                }
                
                # Create Pull Request Approved events for each approval
                for review in reviews:
                    state = review.get('state', '')
                    
                    # Only process APPROVED reviews
                    if state != 'APPROVED':
                        continue
                    
                    submitted_at = Utils.convert_to_utc(review.get('submitted_at'))
                    if not submitted_at:
                        continue
                    
                    # Skip if older than start_date
                    if submitted_at < start_date_naive:
                        continue
                    
                    reviewer = review.get('user', {}).get('login', '')
                    if not reviewer:
                        continue
                    
                    enriched_events.append(CodeCommitEvent.create_event(
                        timestamp_utc=submitted_at,
                        repo_name=repo_name,
                        event_type='Pull Request Approved',
                        source_branch=source_branch,
                        target_branch=target_branch,
                        revision=sha,
                        author=reviewer,
                        comment=title,
                        extended_attributes=extended_attrs
                    ))
                
            except Exception as e:
                logger.error(f"[Enrichment] Error processing PR #{pr_number}: {e}")
                continue
        
        return enriched_events
    
    # ============================================================================
    # MAIN ORCHESTRATION
    # ============================================================================
    
    def run_extraction(self, cursor, config: Dict, start_date: Optional[str], last_modified: Optional[datetime], export_path: str = None):
        """
        Run extraction: fetch and save data.

        Args:
            cursor: Database cursor (None for CSV mode)
            config: Configuration dictionary
            start_date: Start date from command line (optional)
            last_modified: Last modified datetime from database or checkpoint
            export_path: Export path for CSV mode
        """
        # Track maximum timestamp for checkpoint saving
        max_timestamp = None

        if not config.get('owner'):
            Utils.fatal(
                "Missing required configuration: Organization (Owner)",
                context="run_extraction",
                logger=logger,
            )

        owner = config['owner']
        api_token = config.get('api_token', '')
        include_repos = config.get('include_repos', True)
        selected_repos = config.get('repos', [])
        selected_repo_set = set(selected_repos)
        repos = selected_repos if include_repos else [r for r in self._fetch_all_repos(owner, api_token) if r not in selected_repo_set]
        if not repos:
            Utils.fatal("No repositories resolved for extraction", context="run_extraction", logger=logger)

        # Determine start date and mode
        is_enriched_mode = False
        if start_date:
            start_date_dt = datetime.strptime(start_date, '%Y-%m-%d')
            # Convert to naive UTC datetime
            if start_date_dt.tzinfo is not None:
                start_date_dt = start_date_dt.astimezone(timezone.utc).replace(tzinfo=None)
            else:
                start_date_dt = start_date_dt.replace(tzinfo=timezone.utc).replace(tzinfo=None)
        else:
            if last_modified:
                # Convert to naive datetime if timezone-aware
                if last_modified.tzinfo is not None:
                    last_modified = last_modified.replace(tzinfo=None)
                start_date_dt = last_modified
                is_enriched_mode = True  # Enriched mode when doing incremental extraction
            else:
                start_date_dt = datetime(2024, 1, 1)

        # Set up save function — filters by start_date then persists
        start_date_naive = start_date_dt if not start_date_dt.tzinfo else start_date_dt.replace(tzinfo=None)

        if cursor:
            # Database mode
            def save_output_fn(events):
                filtered = []
                for event in events:
                    event_dt = event.get('timestamp_utc')
                    if event_dt:
                        if event_dt.tzinfo is not None:
                            event_dt = event_dt.astimezone(timezone.utc).replace(tzinfo=None)
                        if event_dt > start_date_naive:
                            event['timestamp_utc'] = event_dt
                            filtered.append(event)
                if filtered:
                    total, inserted, duplicates = CodeCommitEvent.save_events_to_database(filtered, cursor, cursor.connection)
                    cursor.connection.commit()
                    self.stats['total_inserted'] += inserted
                    self.stats['total_duplicates'] += duplicates
                    logger.debug(f"Committed {inserted} events to database ({duplicates} duplicates)")
        else:
            # CSV mode - create CSV file at the start
            csv_file = Utils.create_csv_file("github_events", export_path, logger)

            def save_output_fn(events):
                filtered = []
                for event in events:
                    event_dt = event.get('timestamp_utc')
                    if event_dt:
                        if event_dt.tzinfo is not None:
                            event_dt = event_dt.astimezone(timezone.utc).replace(tzinfo=None)
                        if event_dt > start_date_naive:
                            event['timestamp_utc'] = event_dt
                            filtered.append(event)
                if filtered:
                    result = Utils.save_events_to_csv(filtered, csv_file, logger, checkpoint_prefix="github", export_path=export_path)
                    if len(result) == 4 and result[3]:  # result[3] is max_ts
                        nonlocal max_timestamp
                        if not max_timestamp or result[3] > max_timestamp:
                            max_timestamp = result[3]
                    inserted = result[0] if len(result) > 0 else len(filtered)
                    duplicates = result[1] if len(result) > 1 else 0
                    self.stats['total_inserted'] += inserted
                    self.stats['total_duplicates'] += duplicates

        # Log the fetch information
        mode_str = "ENRICHED" if is_enriched_mode else "FAST"
        logger.info(f"Starting {mode_str} extraction from {start_date_dt}")
        logger.info(f"Owner: {owner}")
        logger.info(f"Repositories: {', '.join(repos)}")

        # Process repositories — events are saved periodically inside
        self.process_repositories(owner, repos, api_token, start_date_dt, is_enriched_mode, save_fn=save_output_fn)

        total_events = self.stats['total_inserted'] + self.stats['total_duplicates']
        inserted_count = self.stats['total_inserted']
        duplicate_count = self.stats['total_duplicates']

        # Print summary
        logger.info(f"Pull Request Created:      {self.stats['Pull Request Created']:>6}")
        logger.info(f"Pull Request Merged:       {self.stats['Pull Request Merged']:>6}")
        logger.info(f"Pull Request Closed:       {self.stats['Pull Request Closed']:>6}")
        logger.info(f"Pull Request Approved:     {self.stats['Pull Request Approved']:>6}")
        logger.info(f"Code Committed:            {self.stats['Code Committed']:>6}")
        logger.info(f"Code Pushed:               {self.stats['Code Pushed']:>6}")
        logger.info(f"Initial Push:              {self.stats['Initial Push']:>6}")
        logger.info(f"Branch Deleted:            {self.stats['Branch Deleted']:>6}")
        logger.info(f"Tag Created:               {self.stats['Tag Created']:>6}")
        logger.info(f"Total Events:              {total_events:>6}")
        logger.info(f"Inserted to DB:            {inserted_count:>6}")
        logger.info(f"Duplicates Skipped:        {duplicate_count:>6}")

def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description="Extract GitHub data")
    parser.add_argument('-p', '--product', help='Product name (if provided, saves to database; otherwise saves to CSV)')
    parser.add_argument('-s', '--start-date', help='Start date (YYYY-MM-DD)')
    
    args = parser.parse_args()
    
    extractor = GitHubExtractor()
    
    if args.product is None:
        # CSV Mode: Load configuration from config.json
        config = json.load(open(os.path.join(common_dir, "config.json")))
        
        # Build config dictionary
        repos_str = config.get("GITHUB_REPOS", '')
        repos_list = [repo.strip() for repo in repos_str.split(",") if repo.strip()]

        config = {
            'owner': config.get('GITHUB_ORGANIZATION'),
            'api_token': config.get('GITHUB_API_TOKEN'),
            'repos': repos_list,
            'include_repos': Utils.to_bool(config.get('GITHUB_INCLUDE_REPOS'), default=True),
        }

        # Use checkpoint file for last modified date
        last_modified = Utils.load_checkpoint("github")

        extractor.run_extraction(None, config, args.start_date, last_modified)

    else:
        # Database Mode: Connect to the database
        from database import DatabaseConnection
        db = DatabaseConnection()
        try:
            with db.product_scope(args.product) as conn:
                with conn.cursor() as cursor:
                    config = extractor.get_config_from_database(cursor)
                    last_modified = extractor.get_last_modified_date(cursor)
                    extractor.run_extraction(cursor, config, args.start_date, last_modified)
        except Exception as e:
            logger.error(f"Error during extraction: {str(e)}")
            return 1
    
    return 0

if __name__ == '__main__':
    exit_code = main()
    sys.exit(exit_code)

