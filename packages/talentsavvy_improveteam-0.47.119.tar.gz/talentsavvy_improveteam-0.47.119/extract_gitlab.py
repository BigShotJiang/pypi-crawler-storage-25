#!/usr/bin/env python3
"""
GitLab Data Extraction Script

This script extracts code events from GitLab repositories and saves them to the database.
Supports both fast and enriched extraction modes.

Usage:
    python extract_gitlab.py -p <product_name> [-s <start_date>]

Modes:
    - Fast Mode: Used for initial extraction or when start_date is specified
    - Enriched Mode: Automatically used for incremental extraction (no start_date)
      * In enriched mode, push events are checked for missing commits
      * Missing commits are fetched using /commits/{commit_id} API
      * Parent walking up to num_commits depth

Extended Attributes:
    - Code Committed: parent_ids (list of parent commit SHAs)
    - Code Pushed/Initial Push: num_commits (number of commits in push)
    - Pull Request Events: pull_request_number and pull_request_title

Note:
    - Merge commits (commits with 2+ parent_ids) are excluded from Code Committed events
"""

import argparse
import json
import logging
import os
import sys
import time
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Optional
import urllib3
from urllib.parse import quote
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

base_dir = os.path.dirname(os.path.abspath(__file__))
common_dir = os.path.join(base_dir, "common")
if not os.path.isdir(common_dir):
    # go up one level to find "common" (for installed package structure)
    base_dir = os.path.dirname(base_dir)
    common_dir = os.path.join(base_dir, "common")

if os.path.isdir(common_dir) and base_dir not in sys.path:
    sys.path.insert(0, base_dir)

import requests

from common.code_commit_event import CodeCommitEvent
from common.utils import Utils

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('extract_gitlab')

# Set logger for CodeCommitEvent
CodeCommitEvent.LOGGER = logger

class GitLabExtractor:
    """Extracts code events from GitLab repositories with extended_attributes support."""
    
    def __init__(self):
        self.db_connection = None
        
        # Track extracted commits in memory (repo, commit_id)
        self.extracted_commits = set()

        # Not used for GitLab (all=true returns a unified stream with no per-branch
        # iteration), but kept for structural parity with other extractors.
        self.main_commits = set()
        
        # Statistics
        self.stats = {
            'mr_created': 0,
            'mr_merged': 0,
            'mr_approved': 0,
            'code_committed': 0,
            'code_pushed': 0,
            'initial_push': 0,
            'branch_deleted': 0,
            'tag_created': 0,
            'total_inserted': 0,
            'total_duplicates': 0
        }
        
    def get_config_from_database(self, cursor):
        """Get GitLab configuration from data_source_config table."""
        query = """
        SELECT config_item, config_value 
        FROM data_source_config 
        WHERE data_source = 'source_code_revision_control' 
        AND config_item IN ('Organization', 'Personal Access Token', 'Projects', 'Repos', 'Include Projects', 'Include Repos')
        """
        cursor.execute(query)
        results = cursor.fetchall()
        
        config = {}
        for config_item, config_value in results:
            if config_item == 'Repos':
                try:
                    repos = json.loads(config_value) if config_value else []
                    config['repos'] = repos if repos else []
                except (json.JSONDecodeError, TypeError):
                    config['repos'] = []
            elif config_item == 'Organization':
                # Store base URL without /api/v4 suffix
                base_url = config_value.rstrip('/') if config_value else ''
                if base_url:
                    # Remove /api/v4 if it exists
                    if base_url.endswith('/api/v4'):
                        base_url = base_url[:-7]
                    # Ensure proper protocol
                if not base_url.startswith(('http://', 'https://')):
                    base_url = f"https://{base_url}"
                config['base_url'] = base_url
            elif config_item == 'Personal Access Token':
                config['api_token'] = config_value
            elif config_item == 'Projects':
                try:
                    projects = json.loads(config_value) if config_value else []
                    config['projects'] = projects if projects else []
                except (json.JSONDecodeError, TypeError):
                    config['projects'] = []
            elif config_item == 'Include Projects':
                config['include_projects'] = Utils.to_bool(config_value, default=True)
            elif config_item == 'Include Repos':
                config['include_repos'] = Utils.to_bool(config_value, default=True)
            
        return config
    
    def get_last_modified_date(self, cursor) -> Optional[datetime]:
        """Get the last modified date from the database."""
        last_modified = CodeCommitEvent.get_last_event(cursor)
        if last_modified:
            # Convert to naive datetime if timezone-aware
            if last_modified.tzinfo is not None:
                last_modified = last_modified.replace(tzinfo=None)
        return last_modified



    def _make_api_request(self, url: str, api_token: str, params: Dict = None) -> Optional[Dict]:
        """
        Make an API request to GitLab with retry logic.

        Args:
            url: Full API URL
            api_token: GitLab Access Token
            params: Query parameters

        Returns:
            Response JSON as dict or list, or None if request fails
        """
        headers = {
            'Content-Type': 'application/json'
        }
        if api_token and api_token.strip():
            headers['PRIVATE-TOKEN'] = api_token
        
        max_retries = 3
        retry_delay = 1
        
        for attempt in range(max_retries):
            try:
                response = requests.get(url, headers=headers, params=params, timeout=30, verify=False)
                
                if response.status_code == 200:
                    return response.json()
                elif response.status_code == 429:
                    # Rate limit exceeded
                    retry_after = response.headers.get('Retry-After', '60')
                    wait_time = int(retry_after) + 10
                    logger.warning(f"Rate limit exceeded. Waiting {wait_time} seconds...")
                    time.sleep(wait_time)
                    continue
                else:
                    if response.status_code in (401, 403, 404):
                        Utils.fatal(
                            Utils.format_http_error(
                                "GET",
                                response.url,
                                response.status_code,
                                getattr(response, "reason", "") or "",
                                response.text,
                                response.headers.get("Content-Type"),
                            ),
                            context="_make_api_request",
                            logger=logger,
                        )
                    logger.warning(
                        Utils.format_http_error(
                            "GET",
                            response.url,
                            response.status_code,
                            getattr(response, "reason", "") or "",
                            response.text,
                            response.headers.get("Content-Type"),
                        )
                    )
                    if attempt < max_retries - 1:
                        time.sleep(retry_delay * (2 ** attempt))
                        continue
                    Utils.fatal(
                        Utils.format_http_error(
                            "GET",
                            response.url,
                            response.status_code,
                            getattr(response, "reason", "") or "",
                            response.text,
                            response.headers.get("Content-Type"),
                        ),
                        context="_make_api_request",
                        logger=logger,
                    )
                        
            except requests.exceptions.RequestException as e:
                logger.warning(f"Request failed (attempt {attempt + 1}): {e}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay * (2 ** attempt))
                    continue
                Utils.fatal(
                    f"GitLab API network/request failure after {max_retries} attempts for {url}: {e}",
                    context="_make_api_request",
                    logger=logger,
                )
        return None
            
    # ============================================================================
    # EXTRACTION METHODS 
    # ============================================================================

    def process_repositories(self, base_url: str, project_paths: List[str], api_token: str, start_date: datetime, is_enriched_mode: bool = False, save_fn=None):
        """Process all repositories, saving events periodically via save_fn."""
        for project_id in project_paths:
            repo_name = project_id.split('/')[-1]
            logger.info(f"Processing repository: {repo_name}")

            try:
                # 1. Merge Requests (PR Created/Merged)
                mr_events = self.fetch_merge_requests(base_url, project_id, repo_name, api_token, start_date)
                if mr_events:
                    save_fn(mr_events)

                # 2. Approved Events
                approved_events = self.fetch_events(base_url, project_id, repo_name, api_token, start_date, 'approved')
                if approved_events:
                    save_fn(approved_events)

                # 3. Commits — all branches via all=true, saves per page internally
                self.fetch_commits(base_url, project_id, repo_name, api_token, start_date, save_fn)

                # 4. Push Events (Code Pushed, Initial Push, Branch Deleted)
                push_events = self.fetch_events(base_url, project_id, repo_name, api_token, start_date, 'pushed')
                if push_events:
                    save_fn(push_events)

                # 4.5. Enriched Mode: Fetch missing commits from push events
                if is_enriched_mode and push_events:
                    logger.info(f"[Enriched Mode] Processing push events for missing commits in '{repo_name}'")
                    enriched_commits = self.enrich_push_events_with_commits(
                        base_url, project_id, repo_name, api_token, push_events
                    )
                    if enriched_commits:
                        logger.info(f"[Enriched Mode] Added {len(enriched_commits)} enriched commits for '{repo_name}'")
                        save_fn(enriched_commits)

                # 5. Tags
                tag_events = self.fetch_tags(base_url, project_id, repo_name, api_token)
                if tag_events:
                    save_fn(tag_events)

            except Exception as e:
                logger.error(f"Error processing repository {repo_name}: {e}")
                raise

    def fetch_all_projects(self, base_url: str, api_token: str) -> List[Dict]:
        url = f"{base_url}/api/v4/projects"
        if api_token and str(api_token).strip():
            params = {'membership': 'true', 'per_page': 100, 'page': 1}
        else:
            params = {'visibility': 'public', 'per_page': 100, 'page': 1}
        page = 1
        projects = []
        while True:
            params['page'] = page
            data = self._make_api_request(url, api_token, params)
            if not data or not isinstance(data, list):
                break
            projects.extend(data)
            if len(data) < 100:
                break
            page += 1
        return projects

    def fetch_merge_requests(self, base_url: str, project_id: str, repo_name: str, api_token: str, start_date: datetime) -> List[Dict]:
        """Fetch merge requests and extract PR events with extended_attributes."""
        encoded_project_id = quote(str(project_id), safe='')
        url = f"{base_url}/api/v4/projects/{encoded_project_id}/merge_requests"
        params = {
            'state': 'all',
            'created_after': start_date.isoformat(),
            'per_page': 100,
            'page': 1
        }
        
        events = []
        page = 1
        
        while True:
            params['page'] = page
            logger.info(f"[MR] Fetching page {page} for repo '{repo_name}'...")

            data = self._make_api_request(url, api_token, params)
            if not data or not isinstance(data, list):
                break

            mrs = data
            if not mrs:
                break
                
            for mr in mrs:
                mr_id = mr.get('iid')
                title = mr.get('title', '')
                description = mr.get('description', '')
                source_branch = mr.get('source_branch', '')
                target_branch = mr.get('target_branch', '')
                mr_author = mr.get('author') or {}
                if not isinstance(mr_author, dict):
                    mr_author = {}
                author = mr_author.get('name', '')
                contributor_id = str(mr_author.get('id', '') or '')
                state = mr.get('state', '')
                sha = mr.get('sha', '')
                merge_commit_sha = mr.get('merge_commit_sha', '')

                created_dt = Utils.convert_to_utc(mr.get('created_at'))
                if not created_dt:
                    continue

                merged_dt = Utils.convert_to_utc(mr.get('merged_at')) if state == 'merged' else None

                # Extended attributes for PR events
                extended_attrs = {
                    'pull_request_number': mr_id,
                    'pull_request_title': title
                }
                if contributor_id:
                    extended_attrs['contributor_id'] = contributor_id
                # PR Created event
                events.append(CodeCommitEvent.create_event(
                    timestamp_utc=created_dt,
                    repo_name=repo_name,
                    event_type='Pull Request Created',
                    source_branch=source_branch,
                    target_branch=target_branch,
                    revision=sha,
                    author=author,
                    comment=description,
                    extended_attributes=extended_attrs
                ))
                self.stats['mr_created'] += 1

                # PR Merged event
                if state == 'merged' and merged_dt:
                    events.append(CodeCommitEvent.create_event(
                        timestamp_utc=merged_dt,
                        repo_name=repo_name,
                        event_type='Pull Request Merged',
                        source_branch=source_branch,
                        target_branch=target_branch,
                        revision=merge_commit_sha,
                        author=author,
                        comment=title,
                        extended_attributes=extended_attrs
                    ))
                    self.stats['mr_merged'] += 1

            logger.info(f"[MR] Page {page}: Fetched {len(mrs)} merge requests")
            
            if len(mrs) < 100:
                break
            page += 1
            
        logger.info(f"[MR] Fetched {len(events)} MR events for '{repo_name}'")
        logger.info(f"[MR] Completed processing merge requests for repo '{repo_name}'")
        return events

    def fetch_events(self, base_url: str, project_id: str, repo_name: str, api_token: str, start_date: datetime, action_name: str) -> List[Dict]:
        """Fetch events (approved or pushed) with extended_attributes."""
        encoded_project_id = quote(str(project_id), safe='')
        url = f"{base_url}/api/v4/projects/{encoded_project_id}/events"
        
        # Use start_date - 1 day for after param since it only accepts date (not datetime)
        after_date = (start_date - timedelta(days=1)).strftime('%Y-%m-%d')
        
        params = {
            'action': action_name,
            'after': after_date,
            'per_page': 100,
            'page': 1
        }
        
        events = []
        page = 1
        
        while True:
            params['page'] = page
            logger.info(f"[Events:{action_name}] Fetching page {page} for repo '{repo_name}'...")

            data = self._make_api_request(url, api_token, params)
            if not data or not isinstance(data, list):
                break

            events_data = data
            if not events_data:
                break
                
            for event_data in events_data:
                if action_name == 'approved':
                    event = self._extract_approved_event(event_data, repo_name, start_date)
                elif action_name == 'pushed':
                    event = self._extract_pushed_event(event_data, repo_name, start_date)
                else:
                    continue

                if event:
                    events.append(event)

            logger.info(f"[Events:{action_name}] Page {page}: Fetched {len(events_data)} events")
            
            if len(events_data) < 100:
                break
            page += 1
            
        logger.info(f"[Events:{action_name}] Fetched {len(events)} events for '{repo_name}'")
        logger.info(f"[Events:{action_name}] Completed processing events for repo '{repo_name}'")
        return events

    def _extract_approved_event(self, event_data: Dict, repo_name: str, start_date: datetime) -> Optional[Dict]:
        """Extract Pull Request Approved events."""
        event_dt = Utils.convert_to_utc(event_data.get('created_at'))
        if not event_dt:
            return None
        
        # Ensure start_date is naive for comparison (convert_to_utc returns naive UTC)
        start_date_naive = start_date if not start_date.tzinfo else start_date.replace(tzinfo=None)
        
        # Only create event if timestamp is >= start_date
        if event_dt < start_date_naive:
            return None

        author_obj = event_data.get('author', {})
        author = author_obj.get('name', '')
        contributor_id = str(author_obj.get('id', '') or '')
        mr_iid = event_data.get('target_iid')
        title = event_data.get('target_title', '')
        
        if not mr_iid:
            return None

        # Extended attributes for PR Approved
        extended_attrs = {
            'pull_request_number': mr_iid,
            'pull_request_title': title
        }
        if contributor_id:
            extended_attrs['contributor_id'] = contributor_id

        self.stats['mr_approved'] += 1

        return CodeCommitEvent.create_event(
            timestamp_utc=event_dt,
            repo_name=repo_name,
            event_type='Pull Request Approved',
            source_branch='',
            target_branch='',
            revision='',
            author=author,
            comment=title,
            extended_attributes=extended_attrs
        )

    def _extract_pushed_event(self, event_data: Dict, repo_name: str, start_date: datetime) -> Optional[Dict]:
        """Extract push-related events (Code Pushed, Initial Push, Branch Deleted) with extended_attributes."""
        event_dt = Utils.convert_to_utc(event_data.get('created_at'))
        if not event_dt:
            return None
        
        # Ensure start_date is naive for comparison (convert_to_utc returns naive UTC)
        start_date_naive = start_date if not start_date.tzinfo else start_date.replace(tzinfo=None)
        
        # Only create event if timestamp is >= start_date
        if event_dt < start_date_naive:
            return None

        author_obj = event_data.get('author', {})
        author = author_obj.get('name', '')
        contributor_id = str(author_obj.get('id', '') or '')
        push_data = event_data.get('push_data', {})
        if not push_data:
            return None

        action_name = event_data.get('action_name', '')
        push_action = push_data.get('action', '')
        ref = push_data.get('ref', '')
        ref_type = push_data.get('ref_type', '')
        commit_from = push_data.get('commit_from')
        commit_to = push_data.get('commit_to')
        commit_title = push_data.get('commit_title', '')
        commit_count = push_data.get('commit_count', 0)

        # Only process branch events
        if ref_type != 'branch':
            return None

        # Extended attributes for push events (Code Pushed and Initial Push)
        extended_attrs = None

        # Determine event type
        if action_name == 'pushed new' and push_action == 'created' and commit_from is None:
            event_type = 'Initial Push'
            revision = commit_to if commit_to else ''
            extended_attrs = {'num_commits': commit_count}
            if contributor_id:
                extended_attrs['contributor_id'] = contributor_id
            self.stats['initial_push'] += 1
        elif action_name == 'deleted' and push_action == 'removed' and commit_to is None:
            event_type = 'Branch Deleted'
            revision = commit_from if commit_from else ''
            self.stats['branch_deleted'] += 1
        elif action_name == 'pushed to' and push_action == 'pushed':
            event_type = 'Code Pushed'
            revision = commit_to if commit_to else ''
            extended_attrs = {'num_commits': commit_count}
            if contributor_id:
                extended_attrs['contributor_id'] = contributor_id
            self.stats['code_pushed'] += 1
        else:
            return None

        return CodeCommitEvent.create_event(
            timestamp_utc=event_dt,
            repo_name=repo_name,
            event_type=event_type,
            source_branch='',
            target_branch=ref,
            revision=revision,
            author=author,
            comment=commit_title if commit_title else f"{event_type} to {ref}",
            extended_attributes=extended_attrs
        )

    def fetch_tags(self, base_url: str, project_id: str, repo_name: str, api_token: str) -> List[Dict]:
        """Fetch tags."""
        encoded_project_id = quote(str(project_id), safe='')
        url = f"{base_url}/api/v4/projects/{encoded_project_id}/repository/tags"
        params = {'per_page': 100, 'page': 1}

        events = []
        page = 1

        while True:
            params['page'] = page
            logger.info(f"[Tags] Fetching page {page} for repo '{repo_name}'...")

            data = self._make_api_request(url, api_token, params)
            if not data or not isinstance(data, list):
                break

            tags = data
            if not tags:
                break
                
            for tag in tags:
                tag_name = tag.get('name', '')
                if not tag_name:
                    continue

                commit = tag.get('commit', {})
                commit_id = commit.get('id', '')
                created_dt = Utils.convert_to_utc(commit.get('created_at'))
                author = ''  # git-level name; stable GitLab user ID not available from tags API

                events.append(CodeCommitEvent.create_event(
                    timestamp_utc=created_dt,
                    repo_name=repo_name,
                    event_type='Tag Created',
                    source_branch='',
                    target_branch=tag_name,
                    revision=commit_id,
                    author=author,
                    comment=''
                ))
                self.stats['tag_created'] += 1

            logger.info(f"[Tags] Page {page}: Fetched {len(tags)} tags")
            
            if len(tags) < 100:
                break
            page += 1

        logger.info(f"[Tags] Fetched {len(events)} tag events for '{repo_name}'")
        logger.info(f"[Tags] Completed processing tags for repo '{repo_name}'")
        return events
        
    def fetch_commits(self, base_url: str, project_id: str, repo_name: str, api_token: str, start_date: datetime, save_fn):
        """
        Fetch commits from all branches using all=true, deduplicating by SHA.

        GitLab returns a single unified stream across all branches (newest-first).
        Stops early when a SHA already present in extracted_commits is encountered
        AND the unresolved parent frontier is empty (all branch-exclusive ancestry
        captured). Calls save_fn after each page.
        """
        encoded_project_id = quote(str(project_id), safe='')
        url = f"{base_url}/api/v4/projects/{encoded_project_id}/repository/commits"
        start_date_naive = start_date if not start_date.tzinfo else start_date.replace(tzinfo=None)
        params = {
            'all': 'true',
            'since': start_date.isoformat(),
            'per_page': 100,
            'page': 1
        }

        total_commit_count = 0
        page = 1
        # Frontier of parent SHAs from new commits not yet seen in the stream.
        # Guards against stopping prematurely when a known SHA appears before
        # branch-exclusive commits in the date-ordered unified stream.
        unresolved = set()

        while True:
            params['page'] = page
            logger.info(f"[Commit] Fetching page {page} for repo '{repo_name}'...")

            data = self._make_api_request(url, api_token, params)
            if not data or not isinstance(data, list):
                break

            commits = data
            if not commits:
                break

            page_events = []
            stop = False
            for commit in commits:
                commit_id = commit.get('id', '')

                # This SHA has arrived in the stream — remove from frontier
                unresolved.discard(commit_id)

                if (repo_name, commit_id) in self.extracted_commits:
                    # Stop only when the frontier is empty — if unresolved is
                    # non-empty, branch-exclusive commits are still pending.
                    if not unresolved:
                        stop = True
                        break
                    continue

                message = commit.get('message', '')
                author = commit.get('author_name', '')  # git-level name; stable GitLab user ID not available from commits API
                parent_ids = commit.get('parent_ids', [])

                commit_dt = Utils.convert_to_utc(commit.get('created_at'))
                if not commit_dt:
                    continue

                # Client-side guard for clock-skew edge cases
                if commit_dt < start_date_naive:
                    stop = True
                    break

                # Extend the frontier with parents we haven't extracted yet
                for p_id in parent_ids:
                    if (repo_name, p_id) not in self.extracted_commits:
                        unresolved.add(p_id)

                extended_attrs = {'parent_ids': parent_ids}

                page_events.append(CodeCommitEvent.create_event(
                    timestamp_utc=commit_dt,
                    repo_name=repo_name,
                    event_type='Code Committed',
                    source_branch='',
                    target_branch='',
                    revision=commit_id,
                    author=author,
                    comment=message,
                    extended_attributes=extended_attrs
                ))
                self.stats['code_committed'] += 1
                self.extracted_commits.add((repo_name, commit_id))

            if page_events:
                save_fn(page_events)
                total_commit_count += len(page_events)

            logger.info(f"[Commit] Page {page}: Fetched {len(commits)} commits")

            if stop or len(commits) < 100:
                break
            page += 1

        logger.info(f"[Commit] Fetched {total_commit_count} commit events for '{repo_name}'")
    
    def fetch_commit_by_id(self, base_url: str, project_id: str, repo_name: str, api_token: str, commit_id: str) -> Optional[Dict]:
        """Fetch a single commit by commit ID and return as Code Committed event."""
        encoded_project_id = quote(str(project_id), safe='')
        url = f"{base_url}/api/v4/projects/{encoded_project_id}/repository/commits/{commit_id}"
        
        logger.debug(f"[Commit Detail] Fetching commit {commit_id[:8]} for repo '{repo_name}'...")
        
        data = self._make_api_request(url, api_token)
        if not data:
            return None
        
        commit = data
        message = commit.get('message', '')
        author = commit.get('author_name', '')
        parent_ids = commit.get('parent_ids', [])
        
        commit_dt = Utils.convert_to_utc(commit.get('created_at'))
        if not commit_dt:
            return None

        # Skip merge commits (commits with 2+ parents)
        if len(parent_ids) >= 2:
            logger.debug(f"[Commit Detail] Skipping merge commit {commit_id[:8]}: {message[:50]}...")
            return None

        # Extended attributes for commits: store parent_ids
        extended_attrs = {'parent_ids': parent_ids}

        event = CodeCommitEvent.create_event(
            timestamp_utc=commit_dt,
            repo_name=repo_name,
            event_type='Code Committed',
            source_branch='',
            target_branch='',
            revision=commit_id,
            author=author,
            comment=message,
            extended_attributes=extended_attrs
        )
        
        # Track extracted commit in memory
        self.extracted_commits.add((repo_name, commit_id))
        
        return event
    
    def enrich_push_events_with_commits(self, base_url: str, project_id: str, repo_name: str, api_token: str, 
                                        push_events: List[Dict]) -> List[Dict]:
        """
        Enrich push events by fetching missing commits up to num_commits depth.
        
        For each push event (Initial Push or Code Pushed):
        - Check if the commit was already extracted from /commits API
        - If not, fetch it using /commits/{commit_id} API
        - Walk back through parents up to num_commits depth
        """
        enriched_events = []
        
        for push_event in push_events:
            event_type = push_event.get('event', '')
            if event_type not in ('Initial Push', 'Code Pushed'):
                continue
            
            commit_id = push_event.get('revision', '')
            if not commit_id:
                continue
            
            # Get num_commits from extended_attributes
            extended_attrs = push_event.get('extended_attributes', {})
            num_commits = extended_attrs.get('num_commits', 1) if extended_attrs else 1
            
            # Check if this commit was already extracted
            if (repo_name, commit_id) in self.extracted_commits:
                logger.debug(f"[Enrichment] Commit {commit_id[:8]} already extracted, skipping enrichment for this push")
                continue
            
            logger.info(f"[Enrichment] Enriching {event_type} for commit {commit_id[:8]} with depth {num_commits}")
            
            # Fetch commits up to num_commits depth
            current_commit_id = commit_id
            commits_fetched = 0
            
            while current_commit_id and commits_fetched < num_commits:
                # Fetch commit details
                commit_event = self.fetch_commit_by_id(base_url, project_id, repo_name, api_token, current_commit_id)
                
                if not commit_event:
                    logger.warning(f"[Enrichment] Failed to fetch commit {current_commit_id[:8]}, stopping enrichment")
                    break
                
                enriched_events.append(commit_event)
                commits_fetched += 1
                self.stats['code_committed'] += 1
                
                logger.debug(f"[Enrichment] Fetched commit {current_commit_id[:8]} ({commits_fetched}/{num_commits})")
                
                # Get parent for next iteration
                commit_extended_attrs = commit_event.get('extended_attributes', {})
                parent_ids = commit_extended_attrs.get('parent_ids', [])
                
                if parent_ids and len(parent_ids) > 0:
                    # Use first parent for linear history
                    current_commit_id = parent_ids[0]
                else:
                    # No more parents, stop
                    break
            
            logger.info(f"[Enrichment] Enriched {event_type}: fetched {commits_fetched} commits")
        
        return enriched_events
    
    def run_extraction(self, cursor, config: Dict, start_date: Optional[str], last_modified: Optional[datetime], export_path: str = None):
        """
        Run extraction: fetch and save data.

        Args:
            cursor: Database cursor (None for CSV mode)
            config: Configuration dictionary
            start_date: Start date from command line (optional)
            last_modified: Last modified datetime from database or checkpoint
            export_path: Export path for CSV mode
        """
        # Track maximum timestamp for checkpoint saving
        max_timestamp = None

        if not config.get('base_url'):
            Utils.fatal(
                "Missing required configuration: Organization (Base URL)",
                context="run_extraction",
                logger=logger,
            )

        base_url = config['base_url']
        api_token = config['api_token'] if config.get('api_token') else None
        include_projects = config.get('include_projects', True)
        include_repos = config.get('include_repos', True)
        selected_projects = config.get('projects', [])
        selected_repos = config.get('repos', [])

        if include_projects and not selected_projects:
            Utils.fatal(
                "Include Projects is enabled but no projects/groups are selected.",
                context="run_extraction",
                logger=logger,
            )
        if include_repos and not selected_repos:
            Utils.fatal(
                "Include Repos is enabled but no repositories are selected.",
                context="run_extraction",
                logger=logger,
            )

        all_projects = self.fetch_all_projects(base_url, api_token)
        if selected_projects:
            if include_projects:
                all_projects = [p for p in all_projects if any(p.get('path_with_namespace', '').startswith(f"{g}/") for g in selected_projects)]
            else:
                all_projects = [p for p in all_projects if not any(p.get('path_with_namespace', '').startswith(f"{g}/") for g in selected_projects)]
        selected_repo_set = set(selected_repos)
        project_paths = []
        for p in all_projects:
            full_path = p.get('path_with_namespace', '')
            repo_name = p.get('name', '')
            if not full_path:
                continue
            is_selected = full_path in selected_repo_set or repo_name in selected_repo_set
            if include_repos and selected_repo_set and not is_selected:
                continue
            if not include_repos and is_selected:
                continue
            project_paths.append(full_path)
        if not project_paths:
            Utils.fatal("No repositories resolved for extraction", context="run_extraction", logger=logger)

        # Determine start date and mode
        is_enriched_mode = False
        if start_date:
            start_date_dt = datetime.strptime(start_date, '%Y-%m-%d')
            # Convert to naive UTC datetime
            if start_date_dt.tzinfo is not None:
                start_date_dt = start_date_dt.astimezone(timezone.utc).replace(tzinfo=None)
            else:
                start_date_dt = start_date_dt.replace(tzinfo=timezone.utc).replace(tzinfo=None)
        else:
            if last_modified:
                # Convert to naive datetime if timezone-aware
                if last_modified.tzinfo is not None:
                    last_modified = last_modified.replace(tzinfo=None)
                start_date_dt = last_modified
                is_enriched_mode = True  # Enriched mode when doing incremental extraction
            else:
                start_date_dt = datetime(2024, 1, 1)

        # Set up save function — filters by start_date then persists
        start_date_naive = start_date_dt if not start_date_dt.tzinfo else start_date_dt.replace(tzinfo=None)

        if cursor:
            # Database mode
            def save_output_fn(events):
                filtered = []
                for event in events:
                    event_dt = event.get('timestamp_utc')
                    if event_dt:
                        if event_dt.tzinfo is not None:
                            event_dt = event_dt.astimezone(timezone.utc).replace(tzinfo=None)
                        if event_dt > start_date_naive:
                            event['timestamp_utc'] = event_dt
                            filtered.append(event)
                if filtered:
                    total, inserted, duplicates = CodeCommitEvent.save_events_to_database(filtered, cursor, cursor.connection)
                    cursor.connection.commit()
                    self.stats['total_inserted'] += inserted
                    self.stats['total_duplicates'] += duplicates
                    logger.debug(f"Committed {inserted} events to database ({duplicates} duplicates)")
        else:
            # CSV mode - create CSV file at the start
            csv_file = Utils.create_csv_file("gitlab_events", export_path, logger)

            def save_output_fn(events):
                filtered = []
                for event in events:
                    event_dt = event.get('timestamp_utc')
                    if event_dt:
                        if event_dt.tzinfo is not None:
                            event_dt = event_dt.astimezone(timezone.utc).replace(tzinfo=None)
                        if event_dt > start_date_naive:
                            event['timestamp_utc'] = event_dt
                            filtered.append(event)
                if filtered:
                    result = Utils.save_events_to_csv(filtered, csv_file, logger, checkpoint_prefix="gitlab", export_path=export_path)
                    if len(result) == 4 and result[3]:  # result[3] is max_ts
                        nonlocal max_timestamp
                        if not max_timestamp or result[3] > max_timestamp:
                            max_timestamp = result[3]
                    inserted = result[0] if len(result) > 0 else len(filtered)
                    duplicates = result[1] if len(result) > 1 else 0
                    self.stats['total_inserted'] += inserted
                    self.stats['total_duplicates'] += duplicates

        # Log the fetch information
        mode_str = "ENRICHED" if is_enriched_mode else "FAST"
        logger.info(f"Starting {mode_str} extraction from {start_date_dt}")
        logger.info(f"Base URL: {base_url}")
        logger.info(f"Repositories: {', '.join(project_paths)}")

        # Process repositories — events are saved periodically inside
        self.process_repositories(base_url, project_paths, api_token, start_date_dt, is_enriched_mode, save_fn=save_output_fn)

        total_events = self.stats['total_inserted'] + self.stats['total_duplicates']
        inserted_count = self.stats['total_inserted']
        duplicate_count = self.stats['total_duplicates']

        # Print summary
        logger.info(f"Merge Request Created:     {self.stats['mr_created']:>6}")
        logger.info(f"Merge Request Merged:      {self.stats['mr_merged']:>6}")
        logger.info(f"Merge Request Approved:    {self.stats['mr_approved']:>6}")
        logger.info(f"Code Committed:            {self.stats['code_committed']:>6}")
        logger.info(f"Code Pushed:               {self.stats['code_pushed']:>6}")
        logger.info(f"Initial Push:              {self.stats['initial_push']:>6}")
        logger.info(f"Branch Deleted:            {self.stats['branch_deleted']:>6}")
        logger.info(f"Tag Created:               {self.stats['tag_created']:>6}")
        logger.info(f"Total Events:              {total_events:>6}")
        logger.info(f"Inserted to DB:            {inserted_count:>6}")
        logger.info(f"Duplicates Skipped:        {duplicate_count:>6}")

def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description="Extract GitLab data")
    parser.add_argument('-p', '--product', help='Product name (if provided, saves to database; otherwise saves to CSV)')
    parser.add_argument('-s', '--start-date', help='Start date (YYYY-MM-DD)')
    
    args = parser.parse_args()
    
    extractor = GitLabExtractor()

    try:
        if args.product is None:
            # CSV Mode: Load configuration from config.json
            with open(os.path.join(common_dir, "config.json"), "r", encoding="utf-8") as f:
                config = json.load(f)

            # Build config dictionary
            repos_str = config.get("GITLAB_REPOS", '')
            repos_list = [repo.strip() for repo in repos_str.split(",") if repo.strip()]

            # Get base URL from config
            gitlab_api_url = config.get('GITLAB_API_URL', 'https://gitlab.com/api/v4')
            # Remove /api/v4 suffix if present
            base_url = gitlab_api_url.rstrip('/')
            if base_url.endswith('/api/v4'):
                base_url = base_url[:-7]
            if not base_url.startswith(('http://', 'https://')):
                base_url = f"https://{base_url}"

            config = {
                'base_url': base_url,
                'api_token': config.get('GITLAB_API_TOKEN'),
                'projects': [x.strip() for x in str(config.get('GITLAB_PROJECT', '')).split(',') if x.strip()],
                'repos': repos_list,
                'include_projects': Utils.to_bool(config.get('GITLAB_INCLUDE_PROJECTS'), default=True),
                'include_repos': Utils.to_bool(config.get('GITLAB_INCLUDE_REPOS'), default=True),
            }

            # Use checkpoint file for last modified date
            last_modified = Utils.load_checkpoint("gitlab")
            extractor.run_extraction(None, config, args.start_date, last_modified)
        else:
            # Database Mode: Connect to the database
            from database import DatabaseConnection
            db = DatabaseConnection()
            with db.product_scope(args.product) as conn:
                with conn.cursor() as cursor:
                    config = extractor.get_config_from_database(cursor)
                    last_modified = extractor.get_last_modified_date(cursor)
                    extractor.run_extraction(cursor, config, args.start_date, last_modified)
        return 0
    except Exception as e:
        Utils.fatal(
            f"Error during extraction: {str(e)}",
            context="main",
            logger=logger,
        )

if __name__ == '__main__':
    exit_code = main()
    sys.exit(exit_code)

