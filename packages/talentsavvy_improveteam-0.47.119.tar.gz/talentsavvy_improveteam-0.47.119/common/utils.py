import datetime
import json
import logging
import os
import re
import sys
from typing import Optional
from urllib.parse import urlparse, parse_qsl, urlencode

import pandas as pd
from dateutil.parser import isoparse

config = json.load(open(os.path.join(os.path.dirname(__file__), "config.json")))
EXPORT_PATH = config.get("EXPORT_PATH", os.path.join(os.path.dirname(__file__), "export"))

class Utils:
    DATE_FORMAT = "%Y-%m-%d"
    DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S"
    DATE_TIME_FORMAT_WITH_TZ = "%Y-%m-%dT%H:%M:%SZ"
    LOGGER = None

    @staticmethod
    def load_checkpoint(prefix, export_path=None) -> datetime:
        """
        This method loads the json checkpoint, exported last time

        :param prefix: filename prefix
        :param export_path: Optional export path, defaults to EXPORT_PATH
        :return: datetime (naive UTC)
        """
        if not prefix:
            return None
        try:
            # Use provided export_path or fall back to global EXPORT_PATH
            path_to_use = export_path if export_path is not None else EXPORT_PATH
            os.makedirs(path_to_use, exist_ok=True)
            filepath = os.path.join(path_to_use, f"{prefix}_checkpoint.json")
            if not os.path.exists(filepath):
                return None
            with open(filepath, "r") as f:
                ts_str = json.load(f).get(f"last_run")
                if ts_str:
                    return Utils.convert_to_utc(ts_str)
                return None
        except Exception as ex:
            print(ex)
            return None

    @staticmethod
    def save_checkpoint(prefix: str, last_dt: datetime, export_path=None):
        """
        This method saves the latest datetime to a checkpoint json file.
        Only updates the file when last_dt is strictly greater than the existing
        checkpoint value, so multiple incremental calls never move the watermark
        backwards (e.g. when two CSV files are written per batch and the second
        has an earlier max timestamp than the first).

        :param prefix: filename prefix
        :param last_dt: last date time (naive UTC)
        :param export_path: Optional export path, defaults to EXPORT_PATH
        :return: bool
        """
        if not last_dt or last_dt == '':
            Utils.LOGGER.warning("No last date found to save as checkpoint")
            return None
        try:
            # Use provided export_path or fall back to global EXPORT_PATH
            path_to_use = export_path if export_path is not None else EXPORT_PATH
            os.makedirs(path_to_use, exist_ok=True)
            filepath = os.path.join(path_to_use, f"{prefix}_checkpoint.json")

            # Normalise last_dt to naive UTC
            if type(last_dt) == str:
                last_dt = Utils.convert_to_utc(last_dt)
            elif last_dt.tzinfo is not None:
                last_dt = last_dt.astimezone(datetime.timezone.utc).replace(tzinfo=None)

            # Only write if the new timestamp is strictly greater than the existing one
            if os.path.exists(filepath):
                try:
                    with open(filepath, "r") as f:
                        existing_str = json.load(f).get("last_run")
                    if existing_str:
                        existing_dt = Utils.convert_to_utc(existing_str)
                        if existing_dt and last_dt <= existing_dt:
                            return True  # Checkpoint already at or ahead of this timestamp
                except Exception:
                    pass  # Unreadable checkpoint file — overwrite it

            with open(filepath, "w") as f:
                json.dump({"last_run": last_dt.isoformat(sep='T', timespec='auto')}, f)
            return True
        except Exception as ex:
            Utils.LOGGER.error(ex)
        return None

    @staticmethod
    def convert_to_utc(timestamp):
        """
        Convert a timestamp string to a naive UTC datetime using dateutil.isoparse.
        Returns None if parsing fails or input is falsy.
        """
        if not timestamp:
            return None
        try:
            dt = isoparse(timestamp)
        except Exception:
            # Fallback: attempt common 'Z' replacement
            try:
                dt = datetime.datetime.fromisoformat(str(timestamp).replace('Z', '+00:00'))
            except Exception:
                return None
        if dt.tzinfo is not None:
            return dt.astimezone(datetime.timezone.utc).replace(tzinfo=None)
        # Treat naive as UTC
        return dt

    @staticmethod
    def create_csv_file(csv_filename, export_path, logger=None):
        """
        Create a CSV file with timestamped filename.
        The header will be written when the first events are saved.
        
        :param csv_filename: Base CSV filename (e.g., "jira_events")
        :param export_path: Directory path where CSV file will be saved
        :param logger: Optional logger for info messages
        :return: Full path to the created CSV file
        """
        # Generate timestamped filename
        current_time = datetime.datetime.now()
        timestamp_str = current_time.strftime("%Y_%m_%d_%H_%M_%S")
        path_to_use = export_path if export_path is not None else EXPORT_PATH
        csv_file = os.path.join(path_to_use, f"{csv_filename}_{timestamp_str}.csv")
        
        # Create empty file - header will be written with first event
        with open(csv_file, 'w') as f:
            pass
        
        if logger:
            logger.info(f"Created CSV file: {csv_file}")
        
        return csv_file

    @staticmethod
    def save_events_to_csv(events, csv_file, logger=None, checkpoint_prefix=None, export_path=None):
        """
        Save events to CSV file by appending to existing file.
        Writes header if file is empty (first call).

        When checkpoint_prefix is provided the checkpoint JSON file is updated
        immediately after each write, so a crash mid-run only loses the current
        batch rather than the entire run.

        :param events: List of event dictionaries to save
        :param csv_file: Full path to the CSV file (created by create_csv_file())
        :param logger: Optional logger for info messages
        :param checkpoint_prefix: If set, save_checkpoint is called after each write
        :param export_path: Passed through to save_checkpoint (uses EXPORT_PATH default when None)
        :return: Tuple of (total_events, inserted_events, duplicates, max_timestamp)
        """
        if not events:
            return 0, 0, 0, None

        # Find the maximum timestamp from events and convert extended_attributes to JSON strings
        max_ts = None
        processed_events = []
        for event in events:
            # Convert extended_attributes dict to JSON string if present
            if event.get('extended_attributes') and isinstance(event.get('extended_attributes'), dict):
                event = event.copy()  # Don't modify original event
                # Ensure JSON is properly formatted - parse and re-serialize to normalize
                try:
                    normalized_json = json.dumps(event['extended_attributes'], ensure_ascii=False)
                    event['extended_attributes'] = normalized_json
                except (TypeError, ValueError) as e:
                    # If JSON serialization fails, log and set to None
                    if logger:
                        logger.warning(f"Failed to serialize extended_attributes to JSON: {e}")
                    event['extended_attributes'] = None
            
            if event.get('timestamp_utc'):
                if not max_ts or event['timestamp_utc'] > max_ts:
                    max_ts = event['timestamp_utc']
            
            processed_events.append(event)

        # Convert events to DataFrame
        df = pd.DataFrame(processed_events)
        
        # Check if file is empty (first write) to determine if header should be written
        file_is_empty = os.path.getsize(csv_file) == 0
        
        # Append to CSV file (with header if file is empty, otherwise without)
        # Use default quoting (QUOTE_MINIMAL) which handles JSON strings correctly
        df.to_csv(csv_file, mode='a', header=file_is_empty, index=False)
        
        if logger:
            logger.info(f"Saved {len(events)} events to {csv_file}")

        # Incrementally update the checkpoint after each successful write
        if checkpoint_prefix and max_ts:
            Utils.save_checkpoint(prefix=checkpoint_prefix, last_dt=max_ts, export_path=export_path)

        return len(events), len(events), 0, max_ts

    @staticmethod
    def extract_release_version(version_name: str, regex_config: dict = None) -> str:
        """
        Extract the release version from a version name using release_version_pattern.
        
        Args:
            version_name: Version name from Jira (e.g., "R25.5.0.0")
            regex_config: Dictionary containing regex_configuration with release_version_pattern
            
        Returns:
            Extracted release version (e.g., "25.5.0.0") or empty string if not found
        """
        if not version_name or not regex_config:
            return ''
        
        release_version_pattern_str = regex_config.get('release_version_pattern')
        if not release_version_pattern_str:
            return ''
        
        try:
            # Unescape backslashes (pattern comes from JSON with escaped backslashes)
            pattern_str = release_version_pattern_str.replace("\\\\", "\\")
            # Compile pattern (case-insensitive)
            pattern = re.compile(pattern_str, re.IGNORECASE)
            # Search for pattern in version name
            match = pattern.search(version_name)
            if match:
                # Replace hyphens with dots for consistency
                extracted_version = match.group(0).replace('-', '.')
                return extracted_version
            return ''
        except Exception as e:
            logging.warning(f"Error extracting release version from '{version_name}': {e}")
            return ''

    @staticmethod
    def extract_is_major_release(version_name: str, regex_config: dict = None) -> bool:
        """
        Determine if a version is a major release based on regex pattern matching.
        
        First extracts the release version using release_version_pattern, then checks
        if it matches is_major_release_pattern. If release_version_pattern is not available,
        directly matches the version_name against is_major_release_pattern.
        
        Args:
            version_name: Version name from Jira (e.g., "R25.5.0.0")
            regex_config: Dictionary containing regex_configuration with is_major_release_pattern
                         and optionally release_version_pattern
            
        Returns:
            True if version matches major release pattern, False otherwise
        """
        if not version_name:
            return False
        
        if not regex_config:
            return False
        
        version_name = version_name.strip()
        if not version_name:
            return False
        
        is_major_release_pattern_str = regex_config.get('is_major_release_pattern')
        if not is_major_release_pattern_str:
            return False
        
        try:
            # First, try to extract the release version using release_version_pattern
            # This handles cases like "R25.5.0.0" -> "25.5.0.0"
            release_version = Utils.extract_release_version(version_name, regex_config)
            
            # Use extracted version if available, otherwise use original version_name
            version_to_check = release_version if release_version else version_name
            
            # If we extracted a version with multiple parts (e.g., "25.5.0.0"),
            # extract just the major.minor part (first two parts) for pattern matching
            if release_version and '.' in release_version:
                parts = release_version.split('.')
                if len(parts) >= 2:
                    # Take first two numeric parts
                    version_to_check = f"{parts[0]}.{parts[1]}"
            
            # Unescape backslashes (pattern comes from JSON with escaped backslashes)
            pattern_str = is_major_release_pattern_str.replace("\\\\", "\\")
            # Compile pattern (case-insensitive)
            pattern = re.compile(pattern_str, re.IGNORECASE)
            # Match version against pattern
            is_major_release = bool(pattern.match(version_to_check))
            return is_major_release
        except Exception as e:
            logging.warning(f"Error matching is_major_release pattern for version '{version_name}': {e}")
            return False

    @staticmethod
    def format_http_error(
        method: str,
        url: str,
        status_code: int,
        reason: str = "",
        body: Optional[str] = None,
        content_type: Optional[str] = None,
    ) -> str:
        """
        Build a concise API failure message: method, URL path+query, status, optional JSON detail.
        Never includes HTML response bodies.
        """
        _SENSITIVE_QUERY_KEYS = frozenset({
            "token", "key", "secret", "password", "passwd", "signature",
            "access_token", "api_key", "apikey", "auth", "authorization",
            "client_secret", "private_key",
        })
        _QUERY_MAX_LEN = 200

        method_u = (method or "GET").upper().strip()
        parsed = urlparse(url or "")
        if parsed.path or parsed.query:
            # Normal case: we have a path and/or query, so log only those.
            if parsed.query:
                # Redact sensitive keys and truncate the query string.
                safe_params = []
                for k, v in parse_qsl(parsed.query, keep_blank_values=True):
                    if k.lower() in _SENSITIVE_QUERY_KEYS:
                        safe_params.append((k, "***"))
                    else:
                        safe_params.append((k, v))
                safe_query = urlencode(safe_params)
                if len(safe_query) > _QUERY_MAX_LEN:
                    safe_query = safe_query[:_QUERY_MAX_LEN] + "...[truncated]"
                path_q = (parsed.path or "/") + "?" + safe_query
            else:
                path_q = parsed.path or "/"
        elif not (parsed.scheme or parsed.netloc) and not (parsed.path or parsed.query):
            # Parsing yielded no usable components; fall back to the raw URL or a placeholder.
            path_q = url.strip() if url else "(unknown URL)"
        else:
            # URL has a scheme/netloc but no path/query (e.g., "https://example.com").
            # Log as root path to avoid including scheme/host/credentials.
            path_q = "/"

        r = (reason or "").strip()
        reason_part = f" ({r})" if r else ""
        base = f"API request failed: {method_u} {path_q} returned HTTP {status_code}{reason_part}."

        if not body:
            return base

        text = body.strip()
        if not text:
            return base

        ct = (content_type or "").lower()
        lead = text[:500].lstrip("\ufeff").lstrip()
        lead_lower = lead.lower()
        # Treat any HTML-like response (by content-type or leading "<") as HTML and omit the body.
        if "html" in ct or lead_lower.startswith("<"):
            return f"{base}"
        if "json" in ct or text.lstrip().startswith("{"):
            try:
                data = json.loads(text)
                if isinstance(data, dict):
                    msg = data.get("message") or data.get("errorMessage") or data.get("title")
                    if msg:
                        m = str(msg).strip()
                        if len(m) > 200:
                            m = m[:197] + "..."
                        return f"{base} Details: {m}"
            except (json.JSONDecodeError, TypeError, ValueError):
                pass

        # For non-HTML responses where we couldn't extract a structured message,
        # include a safely truncated snippet of the body to aid debugging.
        # Truncate before normalization to avoid processing very large bodies.
        raw_slice = text[:2000]
        normalized = re.sub(r"\s+", " ", raw_slice)
        snippet = normalized[:300]
        if len(normalized) > 300:
            snippet = snippet[:297] + "..."

        return f"{base} Response snippet: {snippet}"
    @staticmethod
    def fatal(message: str, context=None, logger=None, exit_code: int = 1) -> None:
        """
        Log an error and exit with non-zero code (default 1).

        :param message: Error message
        :param context: Optional context label (e.g. function name)
        :param logger: Optional logger; falls back to the root logger
        :param exit_code: Non-zero exit code to use (default 1)
        """
        in_exception = sys.exc_info()[0] is not None

        log = logger or logging.getLogger(__name__)
        log.error("%s", message, exc_info=in_exception)

        sys.exit(exit_code)

    @staticmethod
    def get_data_source_config(cursor, data_source: str, items: list) -> dict:
        """
        Fetch config key/value pairs from data_source_config for a given data source.

        Returns a plain dict keyed by config_item (e.g. 'Organization',
        'Personal Access Token'). Each caller maps keys to its own field names.

        :param cursor: Active database cursor
        :param data_source: Value of the data_source column (e.g. 'ai_coding_assistant')
        :param items: List of config_item values to fetch
        :return: {config_item: config_value, ...}
        """
        cursor.execute(
            """
            SELECT config_item, config_value
            FROM data_source_config
            WHERE data_source = %s
            AND config_item = ANY(%s)
            """,
            (data_source, items),
        )
        return {item: value for item, value in cursor.fetchall()}

    @staticmethod
    def to_bool(value, default=True):
        """Convert a value to a boolean, handling common string representations."""
        if value is None:
            return default
        if isinstance(value, bool):
            return value
        return str(value).strip().lower() != "false"