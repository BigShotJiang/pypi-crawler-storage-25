#!/usr/bin/env python3
"""
Generate MCP API Token

Generates a signed JWT token for MCP authentication.
Uses az_keyvault_client_secret as the signing key.

Usage:
    python generate_mcp_token.py --expiry-date "2025-12-31"
    python generate_mcp_token.py -e "2026-06-30"
    python generate_mcp_token.py -e "2026-06-30" --product-id 5 --tenant-id 2
"""

import argparse
import os
import sys
from datetime import datetime

import jwt


def generate_token(expiry_date: str, product_id: int | None = None, tenant_id: int | None = None) -> str:
    """Generate a signed JWT token with expiry date and optional product_id and tenant_id."""
    
    client_secret = os.environ.get("az_keyvault_client_secret")
    if not client_secret:
        raise ValueError("az_keyvault_client_secret environment variable is not set")
    
    # Parse end date
    try:
        expiry = datetime.strptime(expiry_date, "%Y-%m-%d")
        expiry_timestamp = int(expiry.timestamp())
    except ValueError:
        raise ValueError(f"Invalid date format: {expiry_date}. Use YYYY-MM-DD")
    
    # Create payload
    payload = {
        "exp": expiry_timestamp,
        "iat": int(datetime.now().timestamp()),
        "type": "mcp_api_token"
    }
    if product_id is not None:
        payload["product_id"] = product_id
    if tenant_id is not None:
        payload["tenant_id"] = tenant_id
    
    # Sign and return token
    token = jwt.encode(payload, client_secret, algorithm="HS256")
    return token


def main():
    parser = argparse.ArgumentParser(description="Generate MCP API Token")
    parser.add_argument(
        "-e", "--expiry-date",
        required=True,
        help="Token expiry date in YYYY-MM-DD format"
    )
    parser.add_argument(
        "--product-id",
        type=int,
        default=None,
        help="Optional product ID to include in token claims"
    )
    parser.add_argument(
        "--tenant-id",
        type=int,
        default=None,
        help="Optional tenant ID to include in token claims"
    )
    
    args = parser.parse_args()
    
    try:
        token = generate_token(args.expiry_date, args.product_id, args.tenant_id)
        print(f"\nMCP Token (expires {args.expiry_date}):\n")
        print(token)
        print("\n")
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()