"""Exception definitions for umeko_thermal."""


class ThermalError(Exception):
    """Base exception for umeko_thermal SDK."""


class ConnectionError(ThermalError):
    """Raised when serial port connection fails or is lost."""


class TimeoutError(ThermalError):
    """Raised when waiting for frame or command response times out."""


class FrameError(ThermalError):
    """Raised when frame data is corrupted or malformed."""


class UnsupportedSensorError(ThermalError):
    """Raised when an unsupported sensor frame format is detected."""
