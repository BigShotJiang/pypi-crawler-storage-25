"""ThermalCamera – main device controller."""

from __future__ import annotations

import re
import threading
import time
from dataclasses import dataclass
from typing import Generator

import serial
import serial.tools.list_ports

from umeko_thermal._exceptions import ConnectionError, TimeoutError
from umeko_thermal._frame import ThermalFrame
from umeko_thermal._protocol import try_parse_frame, parse_file_data


@dataclass
class FileInfo:
    name: str
    size: int
    type: str


@dataclass
class CalibrationEntry:
    id: int
    range_lower: float
    range_upper: float
    gain: float
    offset: float


class ThermalCamera:
    """High-level interface to the Umeko ESP32 thermal camera.

    Example::

        with ThermalCamera(port="COM3") as cam:
            for frame in cam.stream(max_frames=100):
                print(frame.max(), frame.min())
    """

    def __init__(
        self,
        port: str | None = None,
        baudrate: int = 115200,
        timeout: float = 1.0,
        auto_detect: bool = True,
    ):
        self._port = port
        self._baudrate = baudrate
        self._timeout = timeout
        self._auto_detect = auto_detect

        self._serial: serial.Serial | None = None
        self._connected = False
        self._reader_thread: threading.Thread | None = None
        self._reader_running = False
        self._response_buffer = ""
        self._response_event = threading.Event()
        self._lock = threading.Lock()

    # --------------------------------------------------------------------- #
    # Connection lifecycle
    # --------------------------------------------------------------------- #
    def connect(self) -> None:
        """Open the serial port and start the background response reader."""
        if self._connected:
            return

        if self._port is None and self._auto_detect:
            ports = serial.tools.list_ports.comports()
            if not ports:
                raise ConnectionError("No serial port found")
            self._port = ports[0].device

        if self._port is None:
            raise ConnectionError("No port specified and auto_detect is disabled")

        try:
            self._serial = serial.Serial(
                port=self._port,
                baudrate=self._baudrate,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                timeout=self._timeout,
            )
        except serial.SerialException as exc:
            raise ConnectionError(f"Failed to open {self._port}: {exc}") from exc

        self._connected = True
        self._reader_running = True
        self._response_buffer = ""
        self._response_event.clear()
        self._reader_thread = threading.Thread(target=self._reader_loop, daemon=True)
        self._reader_thread.start()

    def disconnect(self) -> None:
        """Close the serial port cleanly."""
        self._connected = False
        self._reader_running = False
        if self._serial is not None:
            try:
                self._serial.close()
            except Exception:
                pass
            self._serial = None
        if self._reader_thread is not None:
            self._reader_thread.join(timeout=1.0)
            self._reader_thread = None

    @property
    def is_connected(self) -> bool:
        return self._connected and (self._serial is not None) and self._serial.is_open

    def __enter__(self) -> "ThermalCamera":
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.disconnect()

    # --------------------------------------------------------------------- #
    # Internal helpers
    # --------------------------------------------------------------------- #
    def _reader_loop(self) -> None:
        """Background thread that accumulates text responses."""
        while self._reader_running and self._serial is not None:
            try:
                if self._serial.in_waiting > 0:
                    to_read = min(self._serial.in_waiting, 2048)
                    data = self._serial.read(to_read)
                    if data:
                        text = data.decode("utf-8", errors="replace")
                        with self._lock:
                            self._response_buffer += text
                        self._response_event.set()
                else:
                    time.sleep(0.01)
            except Exception:
                break

    def _clear_response(self) -> None:
        with self._lock:
            self._response_buffer = ""
        self._response_event.clear()

    def _wait_for_response(self, timeout: float) -> str:
        """Block until *timeout* seconds have passed, then return accumulated text."""
        self._response_event.wait(timeout=timeout)
        with self._lock:
            text = self._response_buffer
        return text

    def _send_raw(self, cmd: str, add_crlf: bool = True) -> None:
        if not self.is_connected or self._serial is None:
            raise ConnectionError("Not connected")
        full = f"{cmd}\r\n" if add_crlf else f"{cmd}\n"
        with self._lock:
            self._serial.write(full.encode("utf-8"))

    def _stop_stream_and_drain(self) -> None:
        """Send ``stop_stream`` and discard buffered data for ~0.5 s."""
        if self._serial is not None and self._serial.is_open:
            try:
                self._serial.write(b"stop_stream\n")
                self._serial.flush()
            except Exception:
                pass
            time.sleep(0.5)
            try:
                self._serial.reset_input_buffer()
            except Exception:
                pass

    def _pause_reader(self) -> None:
        """Stop the background reader thread (call before stream/show)."""
        self._reader_running = False
        if self._reader_thread is not None:
            self._reader_thread.join(timeout=0.5)
            self._reader_thread = None

    def _resume_reader(self) -> None:
        """Restart the background reader thread."""
        if self._connected and (self._reader_thread is None or not self._reader_thread.is_alive()):
            self._reader_running = True
            self._response_buffer = ""
            self._response_event.clear()
            self._reader_thread = threading.Thread(target=self._reader_loop, daemon=True)
            self._reader_thread.start()

    # --------------------------------------------------------------------- #
    # Streaming
    # --------------------------------------------------------------------- #
    def stream(
        self,
        max_frames: int | None = None,
        timeout: float | None = None,
        keepalive_interval: float = 0.5,
    ) -> Generator[ThermalFrame, None, None]:
        """Start continuous streaming and yield each parsed frame.

        The generator automatically sends ``stop_stream`` and drains the
        buffer when the caller stops iterating or an exception occurs.
        """
        if not self.is_connected:
            raise ConnectionError("Not connected")

        self._pause_reader()
        self._serial.reset_input_buffer()

        buffer = b""
        frames_yielded = 0
        last_keepalive = time.time()

        try:
            self._serial.write(b"stream\n")
            last_keepalive = time.time()

            while True:
                if max_frames is not None and frames_yielded >= max_frames:
                    break

                try:
                    chunk = self._serial.read(1024)
                except serial.SerialException:
                    break

                if chunk:
                    buffer += chunk

                # Parse as many complete frames as possible
                while True:
                    frame, buffer = try_parse_frame(buffer)
                    if frame is None:
                        break
                    frames_yielded += 1
                    yield frame

                now = time.time()
                if now - last_keepalive >= keepalive_interval:
                    try:
                        self._serial.write(b"stream\n")
                    except Exception:
                        pass
                    last_keepalive = now

        finally:
            self._stop_stream_and_drain()
            self._resume_reader()

    # --------------------------------------------------------------------- #
    # Device filesystem
    # --------------------------------------------------------------------- #
    def list_files(self, timeout: float = 3.0) -> list[FileInfo]:
        """List ``.bin`` thermal image files stored on the device."""
        if not self.is_connected:
            raise ConnectionError("Not connected")

        self._clear_response()
        self._serial.reset_input_buffer()

        old_timeout = self._serial.timeout
        try:
            self._serial.timeout = 2.0
            self._send_raw("ls")

            lines: list[str] = []
            start = time.time()
            while time.time() - start < timeout:
                line = self._serial.readline()
                if line:
                    lines.append(line.decode("utf-8", errors="ignore"))
                    if b"Total:" in line:
                        break

            results: list[FileInfo] = []
            for line in lines:
                if "File:" in line and "Size:" in line:
                    try:
                        fname_part = line.split("File:")[1].split(",")[0].strip()
                        fname = fname_part.split()[-1]
                        size_part = line.split("Size:")[1].strip()
                        size_str = size_part.split()[0]
                        size = int(size_str)
                        if fname.endswith(".bin"):
                            ftype = "unknown"
                            if size == 2048:
                                ftype = "32x32"
                            elif size == 3072:
                                ftype = "24x32"
                            elif size == 768:
                                ftype = "12x16"
                            results.append(FileInfo(name=fname, size=size, type=ftype))
                    except Exception:
                        continue
            return results
        finally:
            self._serial.timeout = old_timeout

    def read_file(self, filename: str, timeout: float = 2.0) -> ThermalFrame:
        """Read a ``.bin`` file from the device and parse it into a :class:`ThermalFrame`."""
        if not self.is_connected:
            raise ConnectionError("Not connected")

        self._serial.reset_input_buffer()
        old_timeout = self._serial.timeout
        try:
            self._serial.timeout = 1.0
            self._send_raw(f"cat /{filename}")

            # Discard the echo line
            self._serial.readline()

            # Read all data until timeout or buffer empty
            data = b""
            start = time.time()
            while time.time() - start < timeout:
                chunk = self._serial.read(4096)
                if not chunk:
                    break
                data += chunk
                if len(data) >= 4096:
                    break

            return parse_file_data(data)
        finally:
            self._serial.timeout = old_timeout

    def delete_file(self, filename: str) -> None:
        """Delete a file from the device."""
        if not self.is_connected:
            raise ConnectionError("Not connected")
        self._send_raw(f"rm /{filename}")
        time.sleep(0.2)

    def clear_all_files(self) -> None:
        """Delete all thermal images from the device."""
        if not self.is_connected:
            raise ConnectionError("Not connected")
        self._send_raw("clear_photos")
        time.sleep(0.3)

    # --------------------------------------------------------------------- #
    # Calibration
    # --------------------------------------------------------------------- #
    def list_calibrations(self, timeout: float = 2.0) -> list[CalibrationEntry]:
        """Read the device's calibration table."""
        if not self.is_connected:
            raise ConnectionError("Not connected")

        self._clear_response()
        self._serial.reset_input_buffer()

        old_timeout = self._serial.timeout
        try:
            self._serial.timeout = 1.0
            self._send_raw("cal list")
            time.sleep(0.5)
            text = self._wait_for_response(timeout)

            pattern = re.compile(
                r"ID:\s*(\d+),\s*Range:\s*\[([\d.]+),\s*([\d.]+)\]C,\s*Gain:\s*([\d.]+),\s*Offset:\s*([\d.-]+)"
            )
            results: list[CalibrationEntry] = []
            for match in pattern.finditer(text):
                cal_id, lower, upper, gain, offset = match.groups()
                results.append(
                    CalibrationEntry(
                        id=int(cal_id),
                        range_lower=float(lower),
                        range_upper=float(upper),
                        gain=float(gain),
                        offset=float(offset),
                    )
                )
            return results
        finally:
            self._serial.timeout = old_timeout

    # --------------------------------------------------------------------- #
    # Device control
    # --------------------------------------------------------------------- #
    def reboot_to_bootloader(self) -> None:
        """Reboot the device into bootloader mode."""
        if not self.is_connected:
            raise ConnectionError("Not connected")
        self._send_raw("bootloader")

    def reverse_screen_color(self) -> None:
        """Invert the on-device screen color."""
        if not self.is_connected:
            raise ConnectionError("Not connected")
        self._send_raw("color_reverse -r")

    def send_command(self, cmd: str, add_crlf: bool = True) -> None:
        """Send a raw command string to the device."""
        self._send_raw(cmd, add_crlf=add_crlf)

    # --------------------------------------------------------------------- #
    # Interactive show window
    # --------------------------------------------------------------------- #
    def show(
        self,
        scale: int = 10,
        colormap: str = "stream",
        keepalive_interval: float = 0.5,
    ) -> None:
        """Open a blocking Tkinter window that renders the live stream.

        This method runs entirely on the main thread using Tkinter's
        ``after`` scheduler.  It handles reading, parsing, rendering and
        keepalive automatically.  Closing the window unblocks the call.
        """
        from umeko_thermal._show import _run_show_window

        if not self.is_connected:
            raise ConnectionError("Not connected")

        _run_show_window(self, scale=scale, colormap=colormap, keepalive_interval=keepalive_interval)
