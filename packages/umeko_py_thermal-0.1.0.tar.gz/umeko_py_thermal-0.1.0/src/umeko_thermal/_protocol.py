"""Frame format constants and parsers for supported thermal sensors."""

from __future__ import annotations

import struct
import time
from typing import Tuple

from umeko_thermal._exceptions import FrameError, UnsupportedSensorError
from umeko_thermal._frame import ThermalFrame


# ---------- Heimann 32x32 ----------
HEIMANN_HEADER = b"BEGIN"
HEIMANN_FOOTER = b"END"
HEIMANN_WIDTH = 32
HEIMANN_HEIGHT = 32
HEIMANN_PIXEL_COUNT = HEIMANN_WIDTH * HEIMANN_HEIGHT  # 1024
HEIMANN_FRAME_SIZE = HEIMANN_PIXEL_COUNT * 2  # 2048 bytes (uint16)
HEIMANN_META_SIZE = 4  # t_max_raw(2) + t_min_raw(2)
HEIMANN_TOTAL_SIZE = len(HEIMANN_HEADER) + HEIMANN_META_SIZE + HEIMANN_FRAME_SIZE + len(HEIMANN_FOOTER)  # 2060

# ---------- MLX90640 32x24 ----------
MLX40_HEADER = b"MLX40BEGIN"
MLX40_FOOTER = b"MLX40END"
MLX40_WIDTH = 32
MLX40_HEIGHT = 24
MLX40_PIXEL_COUNT = MLX40_WIDTH * MLX40_HEIGHT  # 768
MLX40_FRAME_SIZE = MLX40_PIXEL_COUNT * 4  # 3072 bytes (float)
MLX40_META_SIZE = 8  # t_max(4) + t_min(4) float
MLX40_TOTAL_SIZE = len(MLX40_HEADER) + MLX40_META_SIZE + MLX40_FRAME_SIZE + len(MLX40_FOOTER)  # 3098

# ---------- MLX90641 16x12 ----------
MLX41_HEADER = b"MLX41BEGIN"
MLX41_FOOTER = b"MLX41END"
MLX41_WIDTH = 16
MLX41_HEIGHT = 12
MLX41_PIXEL_COUNT = MLX41_WIDTH * MLX41_HEIGHT  # 192
MLX41_FRAME_SIZE = MLX41_PIXEL_COUNT * 4  # 768 bytes (float)
MLX41_META_SIZE = 8  # t_max(4) + t_min(4) float
MLX41_TOTAL_SIZE = len(MLX41_HEADER) + MLX41_META_SIZE + MLX41_FRAME_SIZE + len(MLX41_FOOTER)  # 794

# File sizes used for device filesystem auto-detection
FILE_SIZE_32x32 = 32 * 32 * 2       # 2048 (Heimann uint16)
FILE_SIZE_24x32 = 24 * 32 * 4       # 3072 (MLX90640 float)
FILE_SIZE_12x16 = 12 * 16 * 4       # 768  (MLX90641 float)


def _raw_to_celsius(raw: int) -> float:
    """Convert Heimann raw uint16 to Celsius."""
    return raw * 0.1 - 273.15


def _parse_heimann_frame(data: bytes) -> ThermalFrame:
    """Parse Heimann 32x32 frame payload (without header/footer)."""
    if len(data) < HEIMANN_META_SIZE + HEIMANN_FRAME_SIZE:
        raise FrameError("Heimann frame payload too short")

    t_max_raw = struct.unpack("<H", data[0:2])[0]
    t_min_raw = struct.unpack("<H", data[2:4])[0]
    t_max = _raw_to_celsius(t_max_raw)
    t_min = _raw_to_celsius(t_min_raw)

    pixel_data = data[4:4 + HEIMANN_FRAME_SIZE]
    pixels = struct.unpack("<" + "H" * HEIMANN_PIXEL_COUNT, pixel_data)

    temp_matrix = []
    for y in range(HEIMANN_HEIGHT):
        row = []
        for x in range(HEIMANN_WIDTH):
            idx = y * HEIMANN_WIDTH + x
            row.append(_raw_to_celsius(pixels[idx]))
        temp_matrix.append(row)

    return ThermalFrame(
        data=temp_matrix,
        width=HEIMANN_WIDTH,
        height=HEIMANN_HEIGHT,
        sensor="heimann",
        t_max=t_max,
        t_min=t_min,
        timestamp=time.time(),
    )


def _parse_mlx40_frame(data: bytes) -> ThermalFrame:
    """Parse MLX90640 32x24 frame payload (without header/footer)."""
    if len(data) < MLX40_META_SIZE + MLX40_FRAME_SIZE:
        raise FrameError("MLX90640 frame payload too short")

    t_max = struct.unpack("<f", data[0:4])[0]
    t_min = struct.unpack("<f", data[4:8])[0]

    pixel_data = data[8:8 + MLX40_FRAME_SIZE]
    pixels = struct.unpack("<" + "f" * MLX40_PIXEL_COUNT, pixel_data)

    temp_matrix = []
    for y in range(MLX40_HEIGHT):
        row = []
        for x in range(MLX40_WIDTH):
            idx = y * MLX40_WIDTH + x
            row.append(pixels[idx])
        temp_matrix.append(row)

    return ThermalFrame(
        data=temp_matrix,
        width=MLX40_WIDTH,
        height=MLX40_HEIGHT,
        sensor="mlx90640",
        t_max=t_max,
        t_min=t_min,
        timestamp=time.time(),
    )


def _parse_mlx41_frame(data: bytes) -> ThermalFrame:
    """Parse MLX90641 16x12 frame payload (without header/footer)."""
    if len(data) < MLX41_META_SIZE + MLX41_FRAME_SIZE:
        raise FrameError("MLX90641 frame payload too short")

    t_max = struct.unpack("<f", data[0:4])[0]
    t_min = struct.unpack("<f", data[4:8])[0]

    pixel_data = data[8:8 + MLX41_FRAME_SIZE]
    pixels = struct.unpack("<" + "f" * MLX41_PIXEL_COUNT, pixel_data)

    temp_matrix = []
    for y in range(MLX41_HEIGHT):
        row = []
        for x in range(MLX41_WIDTH):
            idx = y * MLX41_WIDTH + x
            row.append(pixels[idx])
        temp_matrix.append(row)

    return ThermalFrame(
        data=temp_matrix,
        width=MLX41_WIDTH,
        height=MLX41_HEIGHT,
        sensor="mlx90641",
        t_max=t_max,
        t_min=t_min,
        timestamp=time.time(),
    )


def try_parse_frame(buffer: bytes) -> Tuple[ThermalFrame | None, bytes]:
    """Attempt to detect and parse a single frame from the raw byte buffer.

    Returns:
        (frame, remaining_buffer): If a frame is successfully parsed, ``frame`` is
        a :class:`ThermalFrame`; otherwise ``None``.
    """
    if len(buffer) < 5:
        return None, buffer

    # Search for all possible frame headers
    mlx40_pos = buffer.find(MLX40_HEADER)
    mlx41_pos = buffer.find(MLX41_HEADER)
    heimann_pos = buffer.find(HEIMANN_HEADER)

    valid_positions = []
    if mlx40_pos != -1:
        valid_positions.append((mlx40_pos, "mlx40"))
    if mlx41_pos != -1:
        valid_positions.append((mlx41_pos, "mlx41"))
    if heimann_pos != -1:
        valid_positions.append((heimann_pos, "heimann"))

    if not valid_positions:
        # Keep the last few bytes in case a header is split across reads
        buffer = buffer[-10:] if len(buffer) > 10 else buffer
        return None, buffer

    valid_positions.sort(key=lambda x: x[0])
    frame_pos, frame_type = valid_positions[0]

    if frame_pos > 0:
        buffer = buffer[frame_pos:]

    if frame_type == "mlx40":
        if len(buffer) < MLX40_TOTAL_SIZE:
            return None, buffer
        end_pos = len(MLX40_HEADER) + MLX40_META_SIZE + MLX40_FRAME_SIZE
        if buffer[end_pos:end_pos + len(MLX40_FOOTER)] == MLX40_FOOTER:
            try:
                frame = _parse_mlx40_frame(buffer[len(MLX40_HEADER):end_pos])
                return frame, buffer[MLX40_TOTAL_SIZE:]
            except FrameError:
                pass
        buffer = buffer[1:]
        return None, buffer

    if frame_type == "mlx41":
        if len(buffer) < MLX41_TOTAL_SIZE:
            return None, buffer
        end_pos = len(MLX41_HEADER) + MLX41_META_SIZE + MLX41_FRAME_SIZE
        if buffer[end_pos:end_pos + len(MLX41_FOOTER)] == MLX41_FOOTER:
            try:
                frame = _parse_mlx41_frame(buffer[len(MLX41_HEADER):end_pos])
                return frame, buffer[MLX41_TOTAL_SIZE:]
            except FrameError:
                pass
        buffer = buffer[1:]
        return None, buffer

    # heimann
    if len(buffer) < HEIMANN_TOTAL_SIZE:
        return None, buffer
    end_pos = len(HEIMANN_HEADER) + HEIMANN_META_SIZE + HEIMANN_FRAME_SIZE
    if buffer[end_pos:end_pos + len(HEIMANN_FOOTER)] == HEIMANN_FOOTER:
        try:
            frame = _parse_heimann_frame(buffer[len(HEIMANN_HEADER):end_pos])
            return frame, buffer[HEIMANN_TOTAL_SIZE:]
        except FrameError:
            pass
    buffer = buffer[1:]
    return None, buffer


def parse_file_data(data: bytes, size_hint: int | None = None) -> ThermalFrame:
    """Parse a .bin file payload from the device filesystem.

    The sensor type is inferred from the data length.  A small slack of ±16
    bytes is allowed to account for trailing newlines or echo output.
    """
    length = size_hint if size_hint is not None else len(data)

    def _match(target: int) -> bool:
        return abs(length - target) <= 16 and len(data) >= target

    if _match(FILE_SIZE_32x32):
        pixels = struct.unpack("<1024H", data[:FILE_SIZE_32x32])
        temp_matrix = []
        t_min = float("inf")
        t_max = float("-inf")
        for y in range(32):
            row = []
            for x in range(32):
                idx = y * 32 + x
                temp = _raw_to_celsius(pixels[idx])
                row.append(temp)
                t_min = min(t_min, temp)
                t_max = max(t_max, temp)
            temp_matrix.append(row)
        return ThermalFrame(
            data=temp_matrix,
            width=32,
            height=32,
            sensor="heimann",
            t_max=t_max,
            t_min=t_min,
            timestamp=time.time(),
        )

    if _match(FILE_SIZE_24x32):
        pixels = struct.unpack("<768f", data[:FILE_SIZE_24x32])
        temp_matrix = []
        t_min = float("inf")
        t_max = float("-inf")
        for y in range(24):
            row = []
            for x in range(32):
                idx = y * 32 + x
                row.append(pixels[idx])
                t_min = min(t_min, pixels[idx])
                t_max = max(t_max, pixels[idx])
            temp_matrix.append(row)
        return ThermalFrame(
            data=temp_matrix,
            width=32,
            height=24,
            sensor="mlx90640",
            t_max=t_max,
            t_min=t_min,
            timestamp=time.time(),
        )

    if _match(FILE_SIZE_12x16):
        pixels = struct.unpack("<192f", data[:FILE_SIZE_12x16])
        temp_matrix = []
        t_min = float("inf")
        t_max = float("-inf")
        for y in range(12):
            row = []
            for x in range(16):
                idx = y * 16 + x
                row.append(pixels[idx])
                t_min = min(t_min, pixels[idx])
                t_max = max(t_max, pixels[idx])
            temp_matrix.append(row)
        return ThermalFrame(
            data=temp_matrix,
            width=16,
            height=12,
            sensor="mlx90641",
            t_max=t_max,
            t_min=t_min,
            timestamp=time.time(),
        )

    raise UnsupportedSensorError(
        f"Cannot parse file data of length {len(data)} (hint={size_hint})"
    )
