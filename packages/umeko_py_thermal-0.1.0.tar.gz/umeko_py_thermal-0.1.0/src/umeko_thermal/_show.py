"""Blocking Tkinter live-stream viewer (no background threads)."""

from __future__ import annotations

import time
import tkinter as tk
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from umeko_thermal._camera import ThermalCamera
    from umeko_thermal._frame import ThermalFrame


def _run_show_window(
    cam: "ThermalCamera",
    scale: int = 10,
    colormap: str = "stream",
    keepalive_interval: float = 0.5,
) -> None:
    """Internal implementation of :meth:`ThermalCamera.show`."""

    # Pause the background reader so we own the serial port exclusively
    cam._pause_reader()
    cam._serial.reset_input_buffer()
    cam._serial.write(b"stream\n")

    root = tk.Tk()
    root.title("Umeko Thermal Stream")

    # We don't know the resolution yet; use a placeholder size
    canvas = tk.Canvas(root, width=320, height=320, bg="black")
    canvas.pack()

    info_label = tk.Label(root, text="Waiting for frame...", font=("Consolas", 10))
    info_label.pack(pady=(0, 5))

    # Mutable state used by the after-loop
    state = {
        "running": True,
        "buffer": b"",
        "current_frame": None,  # type: ThermalFrame | None
        "photo": None,
        "img_id": None,
        "last_keepalive": time.time(),
        "frame_count": 0,
    }

    def on_close() -> None:
        state["running"] = False
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_close)

    def _update_info(frame: "ThermalFrame") -> None:
        info_label.config(
            text=(
                f"sensor={frame.sensor}  "
                f"max={frame.max():.1f}C  min={frame.min():.1f}C  "
                f"mean={frame.mean():.1f}C  "
                f"frames={state['frame_count']}"
            )
        )

    def _loop() -> None:
        if not state["running"] or not cam.is_connected:
            return

        # 1. Read whatever is available
        try:
            avail = cam._serial.in_waiting
            if avail:
                chunk = cam._serial.read(min(avail, 4096))
                if chunk:
                    state["buffer"] += chunk
        except Exception:
            pass

        # 2. Parse complete frames
        from umeko_thermal._protocol import try_parse_frame

        parsed_any = False
        while True:
            frame, state["buffer"] = try_parse_frame(state["buffer"])
            if frame is None:
                break
            parsed_any = True
            state["current_frame"] = frame
            state["frame_count"] += 1

        # 3. Render if we have a frame
        if state["current_frame"] is not None:
            frame = state["current_frame"]
            try:
                pil_img = frame.to_image(scale=scale, colormap=colormap)
            except Exception:
                # If Pillow is somehow missing, skip rendering
                pil_img = None

            if pil_img is not None:
                from PIL import ImageTk

                state["photo"] = ImageTk.PhotoImage(pil_img)
                cw = pil_img.width
                ch = pil_img.height

                # Resize canvas to match image exactly once known
                if canvas.winfo_width() != cw or canvas.winfo_height() != ch:
                    canvas.config(width=cw, height=ch)
                    root.geometry(f"{cw}x{ch + info_label.winfo_req_height() + 10}")

                if state["img_id"] is not None:
                    canvas.itemconfig(state["img_id"], image=state["photo"])
                else:
                    state["img_id"] = canvas.create_image(
                        0, 0, anchor=tk.NW, image=state["photo"]
                    )

            _update_info(frame)

        # 4. Keepalive
        now = time.time()
        if now - state["last_keepalive"] >= keepalive_interval:
            try:
                cam._serial.write(b"stream\n")
            except Exception:
                pass
            state["last_keepalive"] = now

        # Schedule next tick (~20 FPS logic, 50 ms)
        root.after(50, _loop)

    # Kick off
    root.after(50, _loop)
    root.mainloop()

    # Cleanup after window closes
    cam._stop_stream_and_drain()
    cam._resume_reader()
