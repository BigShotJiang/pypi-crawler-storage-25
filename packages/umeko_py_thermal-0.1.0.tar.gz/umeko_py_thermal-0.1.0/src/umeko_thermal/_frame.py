"""ThermalFrame data model."""

from __future__ import annotations

import copy
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import numpy as np
    from PIL import Image

from umeko_thermal._colormaps import COLORMAPS, DEFAULT_COLORMAP_NAME


class ThermalFrame:
    """A single frame of thermal imaging data.

    Attributes:
        data: 2-D list of temperature values in Celsius.
        width: Number of horizontal pixels.
        height: Number of vertical pixels.
        sensor: Sensor type identifier (``"heimann"``, ``"mlx90640"``, ``"mlx90641"``).
        t_max: Maximum temperature reported by the frame metadata (may be ``None``).
        t_min: Minimum temperature reported by the frame metadata (may be ``None``).
        timestamp: Unix timestamp when the frame was received.
    """

    def __init__(
        self,
        data: list[list[float]],
        width: int,
        height: int,
        sensor: str,
        t_max: float | None,
        t_min: float | None,
        timestamp: float,
    ):
        self.data = data
        self.width = width
        self.height = height
        self.sensor = sensor
        self.t_max = t_max
        self.t_min = t_min
        self.timestamp = timestamp

    def get(self, x: int, y: int) -> float:
        """Return the temperature at pixel coordinate *(x, y)*."""
        if not (0 <= x < self.width and 0 <= y < self.height):
            raise IndexError(f"Coordinate ({x}, {y}) out of bounds ({self.width}x{self.height})")
        return self.data[y][x]

    def max(self) -> float:
        """Return the highest temperature in the frame."""
        if self.t_max is not None:
            return self.t_max
        return max(max(row) for row in self.data)

    def min(self) -> float:
        """Return the lowest temperature in the frame."""
        if self.t_min is not None:
            return self.t_min
        return min(min(row) for row in self.data)

    def mean(self) -> float:
        """Return the average temperature of all pixels."""
        total = 0.0
        count = 0
        for row in self.data:
            total += sum(row)
            count += len(row)
        return total / count if count else 0.0

    def to_list(self) -> list[list[float]]:
        """Return a deep copy of the 2-D temperature matrix."""
        return copy.deepcopy(self.data)

    def to_numpy(self) -> "np.ndarray":
        """Return the frame as a NumPy 2-D array with shape *(height, width)*."""
        import numpy as np

        return np.array(self.data, dtype=np.float32)

    def to_image(
        self,
        scale: int = 1,
        colormap: str | None = None,
        t_min: float | None = None,
        t_max: float | None = None,
    ) -> "Image.Image":
        """Render the frame as a PIL ``Image`` using a pseudo-color map.

        Args:
            scale: Integer upscaling factor for each pixel.
            colormap: Name of the built-in colormap. Defaults to ``"stream"``.
            t_min: Lower bound for normalization. Auto-computed if ``None``.
            t_max: Upper bound for normalization. Auto-computed if ``None``.

        Returns:
            A ``PIL.Image.Image`` in RGB mode.
        """
        from PIL import Image

        cmap = COLORMAPS.get(colormap or DEFAULT_COLORMAP_NAME)
        if cmap is None:
            raise ValueError(f"Unknown colormap: {colormap}. Available: {list(COLORMAPS.keys())}")

        t_min = t_min if t_min is not None else self.min()
        t_max = t_max if t_max is not None else self.max()
        if t_max - t_min < 0.001:
            t_max = t_min + 0.001

        # Build grayscale normalized image (0-255)
        grey_pixels = bytearray()
        for y in range(self.height):
            for x in range(self.width):
                temp = self.data[y][x]
                norm = int(255 * (temp - t_min) / (t_max - t_min))
                norm = max(0, min(255, norm))
                grey_pixels.append(norm)

        img = Image.frombytes("L", (self.width, self.height), bytes(grey_pixels))

        # Apply colormap
        rgb_pixels = bytearray()
        for grey in grey_pixels:
            rgb_pixels.extend(cmap[grey])

        rgb = Image.frombytes("RGB", (self.width, self.height), bytes(rgb_pixels))

        if scale > 1:
            rgb = rgb.resize((self.width * scale, self.height * scale), Image.NEAREST)

        return rgb

    def __repr__(self) -> str:
        return (
            f"<ThermalFrame {self.width}x{self.height} sensor={self.sensor!r} "
            f"t_min={self.min():.2f} t_max={self.max():.2f}>"
        )
