"""Built-in colormaps extracted from the original host application."""

from __future__ import annotations

import math


def _build_classic() -> list[tuple[int, int, int]]:
    """Classic colormap (black -> purple -> red -> yellow -> white)."""
    data = [
        (0, 0, 16), (0, 0, 24), (0, 0, 24), (0, 0, 33), (0, 0, 33), (0, 0, 41), (0, 0, 41), (0, 0, 49),
        (0, 0, 49), (0, 0, 57), (0, 0, 57), (0, 0, 66), (0, 0, 66), (0, 0, 74), (0, 0, 74), (0, 0, 82),
        (0, 0, 82), (0, 0, 90), (0, 0, 90), (0, 0, 99), (0, 0, 99), (0, 0, 107), (0, 0, 107), (0, 0, 115),
        (0, 0, 115), (0, 0, 123), (0, 0, 123), (0, 0, 132), (0, 0, 132), (0, 0, 140), (0, 0, 140), (0, 0, 140),
        (8, 0, 140), (8, 0, 132), (16, 0, 132), (16, 0, 132), (24, 0, 132), (24, 0, 123), (33, 0, 123), (33, 0, 123),
        (41, 0, 123), (41, 0, 115), (49, 0, 115), (49, 0, 115), (57, 0, 115), (57, 0, 107), (66, 0, 107), (66, 0, 107),
        (74, 0, 107), (74, 0, 99), (82, 0, 99), (82, 0, 99), (90, 0, 99), (90, 0, 90), (99, 0, 90), (99, 0, 90),
        (107, 0, 90), (107, 0, 82), (115, 0, 82), (115, 0, 82), (123, 0, 82), (123, 0, 74), (132, 0, 74), (132, 0, 74),
        (140, 0, 74), (140, 0, 66), (148, 0, 66), (148, 0, 66), (156, 0, 66), (156, 0, 57), (165, 0, 57), (165, 0, 57),
        (173, 0, 57), (173, 0, 49), (181, 0, 49), (181, 0, 49), (189, 0, 49), (189, 0, 41), (198, 0, 41), (198, 0, 41),
        (206, 0, 41), (206, 0, 33), (214, 0, 33), (214, 0, 33), (222, 0, 33), (222, 0, 24), (231, 0, 24), (231, 0, 24),
        (239, 0, 24), (239, 0, 16), (255, 0, 8), (255, 0, 8), (255, 4, 8), (255, 4, 8), (255, 8, 8), (255, 8, 8),
        (255, 12, 8), (255, 12, 8), (255, 16, 8), (255, 16, 0), (255, 20, 0), (255, 20, 0), (255, 24, 0), (255, 24, 0),
        (255, 28, 0), (255, 28, 0), (255, 32, 0), (255, 32, 0), (255, 36, 0), (255, 36, 0), (255, 40, 0), (255, 40, 0),
        (255, 44, 0), (255, 44, 0), (255, 48, 0), (255, 48, 0), (255, 52, 0), (255, 52, 0), (255, 56, 0), (255, 56, 0),
        (255, 60, 0), (255, 65, 0), (255, 69, 0), (255, 77, 0), (255, 81, 0), (255, 89, 0), (255, 93, 0), (255, 101, 0),
        (255, 105, 0), (255, 113, 0), (255, 117, 0), (255, 125, 0), (255, 130, 0), (255, 134, 0), (255, 142, 0),
        (255, 146, 0), (255, 154, 0), (255, 158, 0), (255, 166, 0), (255, 170, 0), (255, 178, 0), (255, 182, 0),
        (255, 190, 0), (255, 195, 0), (255, 203, 0),
    ]
    while len(data) < 256:
        data.append((255, 255, 255))
    return data


def _build_greys() -> list[tuple[int, int, int]]:
    return [(i, i, i) for i in range(256)]


def _build_greys_r() -> list[tuple[int, int, int]]:
    return [(255 - i, 255 - i, 255 - i) for i in range(256)]


def _build_hot() -> list[tuple[int, int, int]]:
    """Hot colormap (black -> red -> yellow -> white)."""
    data = []
    for i in range(256):
        if i < 85:
            r = int(i * 3)
            g = 0
            b = 0
        elif i < 170:
            r = 255
            g = int((i - 85) * 3)
            b = 0
        else:
            r = 255
            g = 255
            b = int((i - 170) * 3)
        data.append((r, g, b))
    return data


def _build_inferno() -> list[tuple[int, int, int]]:
    data = []
    for i in range(256):
        t = i / 255.0
        r = int(255 * min(1.0, t * 2.5))
        g = int(255 * max(0.0, min(1.0, (t - 0.3) * 2)))
        b = int(255 * max(0.0, min(1.0, (t - 0.6) * 2.5)))
        data.append((r, g, b))
    return data


def _build_viridis() -> list[tuple[int, int, int]]:
    data = []
    for i in range(256):
        t = i / 255.0
        r = int(68 + 187 * t)
        g = int(1 + 253 * t)
        b = int(84 + 171 * t)
        data.append((r, g, b))
    return data


def _build_turbo() -> list[tuple[int, int, int]]:
    """Turbo colormap (blue -> cyan -> green -> yellow -> red)."""
    data = []
    for i in range(256):
        t = i / 255.0
        r = int(128 + 127 * math.sin(t * math.pi * 2))
        g = int(128 + 127 * math.sin(t * math.pi * 2 + math.pi / 2))
        b = int(128 + 127 * math.sin(t * math.pi * 2 + math.pi))
        data.append((max(0, min(255, r)), max(0, min(255, g)), max(0, min(255, b))))
    return data


def _build_stream() -> list[tuple[int, int, int]]:
    """Stream colormap from original host app (black -> purple -> blue -> cyan -> green -> yellow -> orange -> red -> white)."""
    data = []
    for i in range(256):
        t = i / 255.0
        if t < 0.125:  # black -> purple
            r = int(128 * (t / 0.125))
            g = 0
            b = int(128 + 127 * (t / 0.125))
        elif t < 0.25:  # purple -> blue
            r = int(128 - 128 * ((t - 0.125) / 0.125))
            g = 0
            b = 255
        elif t < 0.375:  # blue -> cyan
            r = 0
            g = int(255 * ((t - 0.25) / 0.125))
            b = 255
        elif t < 0.5:  # cyan -> green
            r = 0
            g = 255
            b = int(255 - 255 * ((t - 0.375) / 0.125))
        elif t < 0.625:  # green -> yellow
            r = int(255 * ((t - 0.5) / 0.125))
            g = 255
            b = 0
        elif t < 0.75:  # yellow -> orange
            r = 255
            g = int(255 - 128 * ((t - 0.625) / 0.125))
            b = 0
        elif t < 0.875:  # orange -> red
            r = 255
            g = int(127 - 127 * ((t - 0.75) / 0.125))
            b = 0
        else:  # red -> white
            r = 255
            g = int(128 * ((t - 0.875) / 0.125))
            b = int(128 * ((t - 0.875) / 0.125))
        data.append((r, g, b))
    return data


COLORMAPS: dict[str, list[tuple[int, int, int]]] = {
    "classic": _build_classic(),
    "grey": _build_greys(),
    "grey_r": _build_greys_r(),
    "hot": _build_hot(),
    "inferno": _build_inferno(),
    "viridis": _build_viridis(),
    "turbo": _build_turbo(),
    "stream": _build_stream(),
}


DEFAULT_COLORMAP_NAME = "stream"
