"""Umeko Thermal – Python SDK for ESP32 thermal imaging cameras.

Supported sensors:
    * Heimann 32×32 (uint16 raw)
    * Melexis MLX90640 32×24 (float °C)
    * Melexis MLX90641 16×12 (float °C)

Example::

    from umeko_thermal import ThermalCamera

    with ThermalCamera(auto_detect=True) as cam:
        for frame in cam.stream(max_frames=100):
            print(f"max={frame.max():.1f}°C  min={frame.min():.1f}°C")
"""

from umeko_thermal._camera import CalibrationEntry, FileInfo, ThermalCamera
from umeko_thermal._exceptions import (
    ConnectionError,
    FrameError,
    ThermalError,
    TimeoutError,
    UnsupportedSensorError,
)
from umeko_thermal._frame import ThermalFrame

__all__ = [
    "ThermalCamera",
    "ThermalFrame",
    "FileInfo",
    "CalibrationEntry",
    "ThermalError",
    "ConnectionError",
    "TimeoutError",
    "FrameError",
    "UnsupportedSensorError",
]

__version__ = "0.1.0"
