# Umeko Thermal SDK 设计文档

> 版本：v0.1.0  
> 目标：为 ESP32 热成像仪提供一套简洁、稳定的 Python 串口 SDK，并发布到 PyPI。

---

## 1. 库信息

| 项目 | 内容 |
|------|------|
| PyPI 包名 | `umeko-py-thermal` |
| Python 模块名 | `umeko_thermal` |
| Python 版本 | >= 3.8 |
| 核心依赖 | `pyserial`, `numpy`, `Pillow` |

---

## 2. 设计原则

1. **开箱即用**：一行代码连接设备，一行代码获取温度矩阵。
2. **帧格式自识别**：流式数据自动识别 Heimann / MLX90640 / MLX90641 帧头，用户无需关心底层差异。
3. **阻塞与生成器兼顾**：`stream()` 为生成器，支持 `for frame in cam.stream()` 遍历；`show()` 为阻塞式窗口预览。
4. **资源安全**：支持上下文管理器 (`with` 语句)，确保串口可靠关闭。

---

## 3. 快速开始

```python
from umeko_thermal import ThermalCamera

# 自动发现或指定串口连接
cam = ThermalCamera(port="COM3")  # Linux 可用 "/dev/ttyUSB0"
cam.connect()

# 流式读取 100 帧
for frame in cam.stream(max_frames=100):
    print(f"最高温: {frame.max():.1f}°C")
    print(f"最低温: {frame.min():.1f}°C")
    print(f"中心温: {frame.get(15, 15):.1f}°C")

    # 转为 numpy 二维数组
    mat = frame.to_numpy()
    print(mat.shape)  # (32, 32) 或 (24, 32) 或 (12, 16)

# 断开连接
cam.disconnect()
```

---

## 4. 核心 API 参考

### 4.1 `ThermalCamera`

设备主控类，负责串口通信、命令发送、数据接收与帧解析。

#### 构造函数

```python
ThermalCamera(
    port: str | None = None,
    baudrate: int = 115200,
    timeout: float = 1.0,
    auto_detect: bool = True,
)
```

| 参数 | 说明 |
|------|------|
| `port` | 串口名称，如 `"COM3"` 或 `"/dev/ttyUSB0"`。为 `None` 时若 `auto_detect=True` 则自动扫描可用串口。 |
| `baudrate` | 波特率，默认 `115200`。 |
| `timeout` | 串口阻塞读取超时（秒），默认 `1.0`。 |
| `auto_detect` | 为 `True` 且 `port=None` 时，自动列出可用串口并尝试连接第一个。 |

#### 连接管理

```python
cam.connect() -> None
# 打开串口，启动后台监听线程（用于非流式命令的响应读取）。
# 异常：ConnectionError / serial.SerialException

cam.disconnect() -> None
# 安全关闭串口、停止流式传输、清空缓冲区。

cam.is_connected -> bool
# 只读属性，返回串口是否处于打开状态。
```

#### 上下文管理器

```python
with ThermalCamera(port="COM3") as cam:
    for frame in cam.stream(max_frames=200):
        process(frame)
# 退出 with 块时自动调用 disconnect()
```

---

### 4.2 流式传输

```python
cam.stream(
    max_frames: int | None = None,
    timeout: float | None = None,
    keepalive_interval: float = 0.5,
) -> Generator[ThermalFrame, None, None]
```

- 向设备发送 `stream\n` 启动连续传输。
- 以 **生成器** 形式逐帧 yield `ThermalFrame`。
- 自动识别三种帧格式：
  - `BEGIN` + 4 字节元数据 + 2048 字节像素 + `END` → Heimann 32×32
  - `MLX40BEGIN` + 8 字节元数据 + 3072 字节像素 + `MLX40END` → MLX90640 32×24
  - `MLX41BEGIN` + 8 字节元数据 + 768 字节像素 + `MLX41END` → MLX90641 16×12
- 内部每 `keepalive_interval` 秒自动发送一次 `stream\n` 作为心跳（与上位机保持一致）。
- 用户停止迭代（`break`）或发生异常时，SDK 自动发送 `stop_stream\n`，等待 **0.5 秒** 排空缓冲区，然后恢复后台读取线程。

| 参数 | 说明 |
|------|------|
| `max_frames` | 最大读取帧数，`None` 表示不限制。 |
| `timeout` | 单帧读取超时（秒），`None` 表示阻塞。 |
| `keepalive_interval` | 心跳包发送间隔，默认 `0.5` 秒。 |

**使用示例**：

```python
# 读取 200 帧
for frame in cam.stream(max_frames=200):
    process(frame)

# 带退出的条件循环
for frame in cam.stream():
    if frame.max() > 80.0:
        print("过热！")
        break
```

---

### 4.3 实时预览窗口（阻塞式）

```python
cam.show(
    scale: int = 10,
    colormap: str = "stream",
    keepalive_interval: float = 0.5,
) -> None
```

- 打开一个 **Tkinter 小窗口**，实时渲染热成像流。
- **完全在主线程运行**：使用 Tkinter `after` 调度器完成读取 → 解析 → 渲染 → 喂狗，**不使用额外线程**。
- 关闭窗口后，方法返回，SDK 自动发送 `stop_stream\n`、等待 0.5 秒排空串口缓冲、恢复后台读取线程。

| 参数 | 说明 |
|------|------|
| `scale` | 图像放大倍数，默认 `10`（32×32 → 320×320）。 |
| `colormap` | 内置色表名称，可选 `stream` / `inferno` / `hot` / `viridis` / `turbo` / `classic` / `grey` / `grey_r`。 |
| `keepalive_interval` | 自动发送 `stream\n` 保活的间隔。 |

**使用示例**：

```python
with ThermalCamera(port="COM3") as cam:
    cam.show(scale=15, colormap="inferno")
```

---

### 4.4 设备文件系统（热成像图管理）

下位机内置简易文件系统，可存储 `.bin` 热成像快照。

```python
cam.list_files(timeout: float = 3.0) -> list[FileInfo]
# 发送 `ls\r\n`，解析文件列表。
# 返回设备上所有 `.bin` 文件的信息列表。

cam.read_file(filename: str, timeout: float = 2.0) -> ThermalFrame
# 发送 `cat /{filename}\r\n`，读取二进制数据并解析为 ThermalFrame。
# 根据文件大小自动判断传感器类型（2048B/3072B/768B）。

cam.delete_file(filename: str) -> None
# 发送 `rm /{filename}\r\n` 删除指定文件。

cam.clear_all_files() -> None
# 发送 `clear_photos\r\n` 清空所有热成像图片。
```

#### `FileInfo`

```python
@dataclass
class FileInfo:
    name: str       # 文件名，如 "IMG_001.bin"
    size: int       # 字节数
    type: str       # "32x32", "24x32", "12x16" 或 "unknown"
```

---

### 4.5 温度校准

```python
cam.list_calibrations(timeout: float = 2.0) -> list[CalibrationEntry]
# 发送 `cal list`，解析返回的校准表。
```

#### `CalibrationEntry`

```python
@dataclass
class CalibrationEntry:
    id: int
    range_lower: float   # 温度范围下限 (°C)
    range_upper: float   # 温度范围上限 (°C)
    gain: float
    offset: float
```

> **注意**：校准的增删改涉及交互式文本命令与多参数输入，上位机中通过 GUI 完成。SDK 第一版暂不暴露 `add_cal` / `delete_cal` 接口，如需脚本化，可在后续版本追加。

---

### 4.6 设备控制

```python
cam.reboot_to_bootloader() -> None
# 发送 `bootloader\r\n`，设备重启进入 bootloader。

cam.reverse_screen_color() -> None
# 发送 `color_reverse -r\r\n`，反转屏幕颜色。

cam.send_command(cmd: str, add_crlf: bool = True) -> None
# 向下位机发送原始字符串命令。用于调试或扩展功能。
```

---

## 5. 数据模型

### 5.1 `ThermalFrame`

单次捕获或流式传输的一帧温度数据。

```python
class ThermalFrame:
    # 属性
    data: list[list[float]]       # 二维温度矩阵 (°C)
    width: int                    # 像素宽度
    height: int                   # 像素高度
    sensor: str                   # "heimann", "mlx90640", "mlx90641"
    t_max: float | None           # 帧内最高温（元数据或计算值）
    t_min: float | None           # 帧内最低温（元数据或计算值）
    timestamp: float              # 接收到帧的时间戳 (time.time())

    # 方法
    def get(self, x: int, y: int) -> float
    def max(self) -> float
    def min(self) -> float
    def mean(self) -> float
    def to_numpy(self) -> np.ndarray        # shape: (height, width)
    def to_list(self) -> list[list[float]]  # 深拷贝
    def to_image(
        self,
        scale: int = 1,
        colormap: str | None = None,
        t_min: float | None = None,
        t_max: float | None = None,
    ) -> PIL.Image.Image
```

#### `to_image` 说明

- 使用内置伪彩色色表将温度值映射为 RGB 图像。
- 通过 `scale` 参数进行整数倍 nearest-neighbor 放大。
- 不依赖 matplotlib，仅依赖 Pillow（已作为核心依赖）。
- 内置色表：`stream`（默认）、`inferno`、`hot`、`viridis`、`turbo`、`classic`、`grey`、`grey_r`。

---

## 6. 帧格式详细定义

### 6.1 Heimann 32×32（流式）

| 偏移 | 长度 | 内容 | 说明 |
|------|------|------|------|
| 0 | 5 | `BEGIN` | ASCII 帧头 |
| 5 | 2 | `t_max_raw` | uint16 LE，原始值 |
| 7 | 2 | `t_min_raw` | uint16 LE，原始值 |
| 9 | 2048 | `pixels[1024]` | 1024 × uint16 LE，逐行扫描 |
| 2057 | 3 | `END` | ASCII 帧尾 |
| **总计** | **2060** | | |

温度转换：`temp_C = raw * 0.1 - 273.15`

### 6.2 MLX90640 32×24（流式）

| 偏移 | 长度 | 内容 | 说明 |
|------|------|------|------|
| 0 | 10 | `MLX40BEGIN` | ASCII 帧头 |
| 10 | 4 | `t_max` | float LE，已是 °C |
| 14 | 4 | `t_min` | float LE，已是 °C |
| 18 | 3072 | `pixels[768]` | 768 × float LE |
| 3090 | 8 | `MLX40END` | ASCII 帧尾 |
| **总计** | **3098** | | |

### 6.3 MLX90641 16×12（流式）

| 偏移 | 长度 | 内容 | 说明 |
|------|------|------|------|
| 0 | 10 | `MLX41BEGIN` | ASCII 帧头 |
| 10 | 4 | `t_max` | float LE，已是 °C |
| 14 | 4 | `t_min` | float LE，已是 °C |
| 18 | 768 | `pixels[192]` | 192 × float LE |
| 786 | 8 | `MLX41END` | ASCII 帧尾 |
| **总计** | **794** | | |

### 6.4 设备文件 `.bin` 格式

| 文件大小 | 分辨率 | 传感器 | 数据类型 |
|----------|--------|--------|----------|
| 2048 B | 32×32 | Heimann | 1024 × uint16 LE |
| 3072 B | 32×24 | MLX90640 | 768 × float LE |
| 768 B | 16×12 | MLX90641 | 192 × float LE |

---

## 7. 异常体系

```python
class ThermalError(Exception):
    """SDK 基础异常"""

class ConnectionError(ThermalError):
    """串口连接、断开、丢失时抛出"""

class TimeoutError(ThermalError):
    """等待帧或命令响应超时"""

class FrameError(ThermalError):
    """帧数据损坏、长度不足"""

class UnsupportedSensorError(ThermalError):
    """检测到不支持的传感器帧格式"""
```

---

## 8. 项目文件结构

```
umeko-py-thermal/
├── README.md
├── LICENSE
├── pyproject.toml
├── docs/
│   └── SDK.md
├── src/
│   └── umeko_thermal/
│       ├── __init__.py
│       ├── _exceptions.py      # 异常定义
│       ├── _colormaps.py       # 内置色表数据
│       ├── _protocol.py        # 帧格式常量、解析器
│       ├── _frame.py           # ThermalFrame 数据模型
│       ├── _camera.py          # ThermalCamera 主类
│       └── _show.py            # show() 阻塞式窗口实现
└── tests/
    └── ...
```

---

## 9. 版本规划

| 版本 | 目标 |
|------|------|
| **v0.1.0** | `connect`/`disconnect`、`stream()`、`show()`、`list_files()`、`read_file()`、`to_numpy()`、`to_image()`、基础异常 |
| **v0.2.0** | CLI 工具、自动串口发现优化、更多单元测试 |
| **v0.3.0** | 校准管理（增删改）、多设备并发支持 |

---

*文档版本：v0.1.0*  
*基于上位机源码 `host_app.py`（~108 KB，ESP32 统一工具）分析整理*
