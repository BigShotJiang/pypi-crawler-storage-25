"""
Unique sentinel values. Based on PEP 661.
See: https://peps.python.org/pep-0661/#reference-implementation
"""

from __future__ import annotations

import inspect
from typing import LiteralString, Self, final, override

_sentinels: dict[str, Sentinel] = {}


def _get_calling_module_name() -> str:
    try:
        return (
            module.__name__
            if (module := inspect.getmodule(inspect.currentframe().f_back.f_back))  # pyright: ignore[reportOptionalMemberAccess]
            else __name__
        )
    except AttributeError:
        return __name__


@final
class Sentinel:
    """Class for creating unique sentinel values."""

    _id: str  # pyright: ignore[reportUninitializedInstanceVariable]

    @override
    def __new__(
        cls, name: LiteralString, /, *, module_name: str | None = None
    ) -> Sentinel:
        id = f"{module_name or _get_calling_module_name()}-{name}"

        if cached := _sentinels.get(id, None):
            return cached

        sentinel = super().__new__(cls)
        sentinel._id = id

        return _sentinels.setdefault(id, sentinel)

    @override
    def __repr__(self) -> str:
        return f'{self.__class__.__name__}("{self.name}", module_name="{self.module}")'

    @override
    def __reduce__(self) -> tuple[type[Self], tuple[str, str]]:
        return (self.__class__, (self.name, self.module))

    @property
    def name(self) -> str:
        """This `Sentinel`'s name."""

        return self._id.split("-")[-1]

    @property
    def module(self) -> str:
        """This `Sentinel`'s module's name."""

        return self._id.split("-")[0]
