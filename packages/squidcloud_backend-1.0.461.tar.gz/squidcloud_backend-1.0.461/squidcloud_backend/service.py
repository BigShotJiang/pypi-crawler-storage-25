"""SquidService base class — the main class users extend to create backend services.

Mirrors: backend/src/squid.service.ts
"""

from __future__ import annotations

import os
from typing import Any, ClassVar

from squidcloud_backend.context import get_request_config
from squidcloud_backend.decorators import _SQUID_DECORATORS
from squidcloud_backend.metadata import get_metadata
from squidcloud_backend.types import (
    AuthWithApiKey,
    AuthWithBearer,
    OpenApiResponse,
    RunContext,
    ServiceRequestConfig,
    WebhookResponse,
)


class SquidService:
    """Base class for Squid backend services.

    Users extend this class and apply decorators to methods.
    Mirrors the TypeScript SquidService class.

    Example::

        class MyService(SquidService):
            @executable()
            async def hello(self, name: str) -> str:
                return f"Hello, {name}!"
    """

    # Global state set by the worker on each request
    _global_secrets: ClassVar[dict[str, Any]] = {}
    _global_api_keys: ClassVar[dict[str, str]] = {}
    _global_backend_api_key: ClassVar[str] = ""
    _global_app_id: ClassVar[str] = ""
    _global_squid_client: ClassVar[Any] = None
    _global_assets_directory: str = ""

    def __init_subclass__(cls, **kwargs: Any) -> None:
        """Called when a class extends SquidService.

        Finalizes deferred decorator registrations and processes
        class-level decorators (@llm_service, @mcp_server).
        """
        super().__init_subclass__(**kwargs)

        meta = get_metadata()
        meta.register_service_class(cls)

        # Process deferred decorator registrations from method decorators
        for name in dir(cls):
            try:
                attr = getattr(cls, name, None)
            except Exception:
                continue
            if attr is None or not callable(attr):
                continue
            pending = getattr(attr, _SQUID_DECORATORS, None)
            if pending:
                for _decorator_name, register_fn in pending:
                    register_fn(cls, name)

        # Handle @llm_service class decorator
        llm_opts = getattr(cls, "__squid_llm_options__", None)
        if llm_opts:
            meta.llm_service(cls.__name__, llm_opts)

        # Handle @mcp_server class decorator
        mcp_opts = getattr(cls, "__squid_mcp_options__", None)
        if mcp_opts:
            meta.mcp_server(cls.__name__, mcp_opts)

    @property
    def region(self) -> str:
        """The application region (e.g., 'us-east-1.aws' or 'local')."""
        return os.environ.get("SQUID_REGION", "local")

    @property
    def backend_base_url(self) -> str:
        """The backend base URL for the application."""
        from squidcloud.http import build_url

        return build_url(self.region, self._global_app_id, "")

    @property
    def secrets(self) -> dict[str, Any]:
        """All custom secrets configured in the Squid console."""
        return self._global_secrets

    @property
    def api_keys(self) -> dict[str, str]:
        """All API keys configured in the Squid console."""
        return self._global_api_keys

    @property
    def context(self) -> RunContext:
        """The current request's RunContext. Only valid within a request scope."""
        return self._get_request_config().context

    @property
    def squid(self) -> Any:
        """The Squid client instance for database, storage, AI, etc.

        Returns a ``squidcloud.Squid`` instance from the ``squidcloud-client`` package.
        Initialized lazily with the backend API key and region.
        """
        if self._global_squid_client is None:
            from squidcloud import Squid

            SquidService._global_squid_client = Squid(
                app_id=self._global_app_id,
                api_key=self._global_backend_api_key,
                region=self.region,
            )
        return self._global_squid_client

    @property
    def assets_directory(self) -> str:
        """Path to the public assets directory in the code bundle."""
        return self._global_assets_directory

    def get_api_key(self) -> str:
        """Get the backend API key."""
        return self._global_backend_api_key

    def get_user_auth(self) -> AuthWithBearer | None:
        """Get the current user's bearer auth, or None if not bearer-authenticated."""
        config = self._get_request_config()
        if config.auth and config.auth.get("type") == "Bearer":
            return config.auth  # type: ignore[return-value]
        return None

    def get_api_key_auth(self) -> AuthWithApiKey | None:
        """Get the API key auth, or None if not API-key-authenticated."""
        config = self._get_request_config()
        if config.auth and config.auth.get("type") == "ApiKey":
            return config.auth  # type: ignore[return-value]
        return None

    def is_authenticated(self) -> bool:
        """Check if the current request has valid authentication."""
        return self._get_request_config().auth is not None

    def assert_is_authenticated(self) -> None:
        """Assert that the current request is authenticated.

        Raises:
            RuntimeError: If called outside of a request scope.
            PermissionError: If not authenticated.
        """
        self.assert_in_request_scope()
        if not self.is_authenticated():
            raise PermissionError("UNAUTHORIZED")

    def assert_in_request_scope(self) -> None:
        """Assert that we're inside a request scope.

        Raises:
            RuntimeError: If called outside of a request scope.
        """
        self._get_request_config()

    def assert_api_key_call(self) -> None:
        """Assert that the current request uses API key authentication.

        Raises:
            PermissionError: If not API-key-authenticated.
        """
        if self.get_api_key_auth() is None:
            raise PermissionError("UNAUTHORIZED")

    def create_webhook_response(
        self,
        body: Any = "",
        status_code: int | None = None,
        headers: dict[str, Any] | None = None,
    ) -> WebhookResponse:
        """Create a webhook response object.

        Args:
            body: Response body. Defaults to empty string.
            status_code: HTTP status code. Defaults to 200 if body is truthy, 204 otherwise.
            headers: Response headers. Defaults to empty dict.

        Returns:
            A WebhookResponse dict with ``__isWebhookResponse__`` marker.
        """
        if status_code is None:
            status_code = 200 if body else 204
        return WebhookResponse(
            body=body,
            statusCode=status_code,
            headers=headers or {},
            __isWebhookResponse__=True,
        )

    def throw_webhook_response(
        self,
        body: Any = "",
        status_code: int = 500,
        headers: dict[str, Any] | None = None,
    ) -> None:
        """Throw a webhook response (raises WebhookResponseException).

        Args:
            body: Response body.
            status_code: HTTP status code. Defaults to 500.
            headers: Response headers.

        Raises:
            WebhookResponseException: Always.
        """
        raise WebhookResponseException(
            WebhookResponse(
                body=body or "",
                statusCode=status_code,
                headers=headers or {},
                __isWebhookResponse__=True,
            )
        )

    def create_openapi_response(
        self,
        body: Any = "",
        status_code: int | None = None,
        headers: dict[str, Any] | None = None,
    ) -> OpenApiResponse:
        """Create an OpenAPI response object.

        Args:
            body: Response body. Defaults to empty string.
            status_code: HTTP status code. Defaults to 200 if body is truthy, 204 otherwise.
            headers: Response headers. Defaults to empty dict.

        Returns:
            An OpenApiResponse dict with ``__isOpenApiResponse__`` marker.
        """
        if status_code is None:
            status_code = 200 if body else 204
        return OpenApiResponse(
            body=body,
            statusCode=status_code,
            headers=headers or {},
            __isOpenApiResponse__=True,
        )

    def throw_openapi_response(
        self,
        body: Any = "",
        status_code: int = 500,
        headers: dict[str, Any] | None = None,
    ) -> None:
        """Throw an OpenAPI response (raises OpenApiResponseException).

        Raises:
            OpenApiResponseException: Always.
        """
        raise OpenApiResponseException(
            OpenApiResponse(
                body=body or "",
                statusCode=status_code,
                headers=headers or {},
                __isOpenApiResponse__=True,
            )
        )

    def _get_request_config(self) -> ServiceRequestConfig:
        """Internal: get current request config from context var."""
        return get_request_config()


class WebhookResponseException(Exception):
    """Raised by throw_webhook_response() to short-circuit and return a webhook response."""

    def __init__(self, response: WebhookResponse) -> None:
        self.response = response
        super().__init__("Webhook response")


class OpenApiResponseException(Exception):
    """Raised by throw_openapi_response() to short-circuit and return an OpenAPI response."""

    def __init__(self, response: OpenApiResponse) -> None:
        self.response = response
        super().__init__("OpenAPI response")
