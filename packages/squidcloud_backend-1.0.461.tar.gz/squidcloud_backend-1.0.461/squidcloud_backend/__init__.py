"""Squid Cloud Python backend SDK.

Provides decorators, base classes, and types for building Squid backend
services in Python.

Usage::

    from squidcloud_backend import SquidService, SquidProject, executable, webhook


    class MyService(SquidService):
        @webhook("hello")
        async def hello_webhook(self, request: WebhookRequest) -> WebhookResponse:
            return self.create_webhook_response(body={"message": "Hello!"})

        @executable()
        async def greet(self, name: str) -> str:
            return f"Hello, {name}!"


    project = SquidProject()
"""

from squidcloud_backend.decorators import (
    ai_function,
    ai_functions_configurator,
    client_connection_state_handler,
    executable,
    limits,
    llm_ask,
    llm_service,
    mcp_authorizer,
    mcp_server,
    mcp_tool,
    scheduler,
    secure_ai_agent,
    secure_ai_query,
    secure_api,
    secure_collection,
    secure_database,
    secure_distributed_lock,
    secure_graphql,
    secure_metric,
    secure_native_query,
    secure_storage,
    secure_topic,
    transform_collection,
    transform_database,
    trigger,
    webhook,
)
from squidcloud_backend.llm_service import SquidLlmService
from squidcloud_backend.project import SquidProject
from squidcloud_backend.service import (
    OpenApiResponseException,
    SquidService,
    WebhookResponseException,
)
from squidcloud_backend.types import (
    AiFunctionAttributes,
    AiFunctionMetadataOptions,
    AiFunctionParam,
    AiFunctionsConfiguratorMetadataOptions,
    Auth,
    AuthWithApiKey,
    AuthWithBearer,
    ClientConnectionState,
    CronExpression,
    LimiterConfig,
    LlmServiceOptions,
    McpAuthorizationRequest,
    McpServerOptions,
    McpToolMetadataOptions,
    OnIntegrationLifecycleInput,
    OpenApiResponse,
    QuotaLimitOptions,
    RateLimitOptions,
    RunContext,
    SchedulerOptions,
    SecureMetricOptions,
    ServiceRequestConfig,
    SquidFile,
    TriggerOptions,
    TriggerRequest,
    UserAiAskResponse,
    UserAiChatOptions,
    WebhookRequest,
    WebhookResponse,
)

__all__ = [
    # Types
    "AiFunctionAttributes",
    "AiFunctionMetadataOptions",
    "AiFunctionParam",
    "AiFunctionsConfiguratorMetadataOptions",
    # Auth & Context
    "Auth",
    "AuthWithApiKey",
    "AuthWithBearer",
    "ClientConnectionState",
    "CronExpression",
    "LimiterConfig",
    "LlmServiceOptions",
    "McpAuthorizationRequest",
    "McpServerOptions",
    "McpToolMetadataOptions",
    "OnIntegrationLifecycleInput",
    "OpenApiResponse",
    "OpenApiResponseException",
    "QuotaLimitOptions",
    "RateLimitOptions",
    "RunContext",
    "SchedulerOptions",
    "SecureMetricOptions",
    "ServiceRequestConfig",
    "SquidFile",
    "SquidLlmService",
    "SquidProject",
    # Core classes
    "SquidService",
    "TriggerOptions",
    "TriggerRequest",
    "UserAiAskResponse",
    "UserAiChatOptions",
    "WebhookRequest",
    "WebhookResponse",
    # Exceptions
    "WebhookResponseException",
    # Decorators
    "ai_function",
    "ai_functions_configurator",
    "client_connection_state_handler",
    "executable",
    "limits",
    "llm_ask",
    "llm_service",
    "mcp_authorizer",
    "mcp_server",
    "mcp_tool",
    "scheduler",
    "secure_ai_agent",
    "secure_ai_query",
    "secure_api",
    "secure_collection",
    "secure_database",
    "secure_distributed_lock",
    "secure_graphql",
    "secure_metric",
    "secure_native_query",
    "secure_storage",
    "secure_topic",
    "transform_collection",
    "transform_database",
    "trigger",
    "webhook",
]
