"""SquidLlmService — abstract base for custom LLM service implementations.

Mirrors: backend/src/llm-service.ts
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

from squidcloud_backend.service import SquidService

if TYPE_CHECKING:
    from squidcloud_backend.types import UserAiAskResponse, UserAiChatOptions


class SquidLlmService(SquidService, ABC):
    """Abstract base class for custom LLM service implementations.

    Extend this class and use the ``@llm_service`` and ``@llm_ask`` decorators
    to create a custom LLM provider.

    Example::

        @llm_service(options={"models": {"my-model": {"contextWindowTokens": 8000}}})
        class MyLlmService(SquidLlmService):
            @llm_ask()
            async def ask(self, prompt: str, options: UserAiChatOptions) -> UserAiAskResponse:
                response = await call_my_llm(prompt, options)
                return {"responseString": response}
    """

    @abstractmethod
    async def ask(self, prompt: str, options: UserAiChatOptions) -> UserAiAskResponse:
        """Handle an LLM ask request.

        Args:
            prompt: The user's prompt text.
            options: Chat options. See :class:`UserAiChatOptions`.

        Returns:
            A :class:`UserAiAskResponse` dict with at minimum ``responseString``.
        """
        ...
