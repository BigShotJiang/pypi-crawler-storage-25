"""Metadata collection system mirroring the TypeScript Meta class.

The Meta singleton accumulates all decorator registrations and produces
a JSON-serializable dict matching the ApplicationBundleData schema.

Mirrors: backend/src/metadata.ts
"""

from __future__ import annotations

import warnings
from typing import Any

from squidcloud_backend.types import (
    AI_AGENTS_INTEGRATION_ID,
    BUILT_IN_DB_INTEGRATION_ID,
    BUILT_IN_QUEUE_INTEGRATION_ID,
    BUILT_IN_STORAGE_INTEGRATION_ID,
    AiFunctionAttributes,
    AiFunctionParam,
    IntegrationLifecycleHooksMetadata,
    LimiterOptions,
    LlmServiceOptions,
    McpServerOptions,
    McpToolMetadataOptions,
    ServiceFunctionName,
)


def _merge_into_list(target: dict, key: str, value: Any) -> None:
    """Append value to a list at target[key], creating it if needed."""
    target.setdefault(key, []).append(value)


class Meta:
    """Singleton that collects metadata from all decorators.

    Mirrors the TypeScript Meta class in backend/src/metadata.ts.
    Each decorator calls a method here to register its metadata.
    The ``data`` dict matches the ApplicationBundleData JSON schema.
    """

    def __init__(self) -> None:
        self.data: dict[str, Any] = {
            "codeChecksum": "initial",
            "databases": {},
            "storage": {},
            "executables": {},
            "apis": {},
            "graphql": {},
            "triggers": {},
            "schedulers": {},
            "webhooks": {},
            "nativeQueries": {},
            "distributedLocks": {},
            "aiChatbots": {},
            "clientConnectionStateChangeHandlers": [],
            "aiFunctions": {},
            "aiFunctionsConfigurators": {},
            "openApiControllersMap": {},
            "queues": {},
            "metrics": {"security": {"write": [], "all": []}},
            "limits": {},
            "llms": {},
            "mcp": {},
            "integrationLifecycleHooks": {
                "onIntegrationCreated": False,
                "onIntegrationDeleted": False,
                "onIntegrationChanged": False,
            },
        }
        self._service_classes: dict[str, type] = {}

    def register_service_class(self, cls: type) -> None:
        """Register a SquidService subclass for discovery by the worker."""
        self._service_classes[cls.__name__] = cls

    def get_service_classes(self) -> dict[str, type]:
        """Get all registered service classes."""
        return dict(self._service_classes)

    # --- Security: Database ---

    def secure_database(
        self,
        action_type: str,
        service_function: ServiceFunctionName,
        integration_id: str = BUILT_IN_DB_INTEGRATION_ID,
    ) -> None:
        db = self._ensure_database(integration_id)
        security = db.setdefault("security", {})
        _merge_into_list(security, action_type, service_function)

    def secure_ai_query(
        self,
        service_function: ServiceFunctionName,
        integration_id: str = BUILT_IN_DB_INTEGRATION_ID,
    ) -> None:
        db = self._ensure_database(integration_id)
        security = db.setdefault("security", {})
        _merge_into_list(security, "aiQuery", service_function)

    def secure_collection(
        self,
        collection_name: str,
        action_type: str,
        service_function: ServiceFunctionName,
        integration_id: str = BUILT_IN_DB_INTEGRATION_ID,
    ) -> None:
        db = self._ensure_database(integration_id)
        collections = db.setdefault("collections", {})
        col = collections.setdefault(collection_name, {})
        security = col.setdefault("security", {})
        _merge_into_list(security, action_type, service_function)

    # --- Security: Storage ---

    def secure_storage(
        self,
        action_type: str,
        service_function: ServiceFunctionName,
        integration_id: str = BUILT_IN_STORAGE_INTEGRATION_ID,
    ) -> None:
        storage = self.data["storage"].setdefault(integration_id, {})
        security = storage.setdefault("security", {})
        _merge_into_list(security, action_type, service_function)

    # --- Security: Topic ---

    def secure_topic(
        self,
        topic_name: str,
        action_type: str,
        service_function: ServiceFunctionName,
        integration_id: str = BUILT_IN_QUEUE_INTEGRATION_ID,
    ) -> None:
        queue = self.data["queues"].setdefault(integration_id, {"topics": {}})
        topics = queue.setdefault("topics", {})
        topic = topics.setdefault(topic_name, {})
        security = topic.setdefault("security", {})
        _merge_into_list(security, action_type, service_function)

    # --- Security: Metric ---

    def secure_metric(
        self,
        metric_name_prefix: str,
        action_type: str,
        service_function: ServiceFunctionName,
    ) -> None:
        security = self.data["metrics"]["security"]
        _merge_into_list(
            security,
            action_type,
            {"namePrefix": metric_name_prefix, "serviceFunction": service_function},
        )

    # --- Security: API ---

    def secure_api(
        self,
        integration_id: str,
        endpoint_id: str | None,
        service_function: ServiceFunctionName,
    ) -> None:
        api = self.data["apis"].setdefault(integration_id, {"security": [], "endpoints": {}})
        if endpoint_id is not None:
            endpoints = api.setdefault("endpoints", {})
            endpoint = endpoints.setdefault(endpoint_id, {"security": []})
            endpoint["security"].append(service_function)
        else:
            api["security"].append(service_function)

    # --- Security: GraphQL ---

    def secure_graphql(
        self,
        integration_id: str,
        service_function: ServiceFunctionName,
    ) -> None:
        gql = self.data["graphql"].setdefault(integration_id, {"security": []})
        gql["security"].append(service_function)

    # --- Security: Native Query ---

    def secure_native_query(
        self,
        integration_id: str,
        service_function: ServiceFunctionName,
    ) -> None:
        _merge_into_list(self.data["nativeQueries"], integration_id, service_function)

    # --- Security: Distributed Lock ---

    def secure_distributed_lock(
        self,
        mutex: str | None,
        service_function: ServiceFunctionName,
    ) -> None:
        locks = self.data["distributedLocks"]
        if mutex is not None:
            mutexes = locks.setdefault("mutexes", {})
            m = mutexes.setdefault(mutex, {})
            _merge_into_list(m, "security", service_function)
        else:
            _merge_into_list(locks, "security", service_function)

    # --- Security: AI Agent ---

    def secure_ai_agent(
        self,
        agent_id: str | None,
        service_function: ServiceFunctionName,
    ) -> None:
        chatbots = self.data["aiChatbots"]
        integration = chatbots.setdefault(
            AI_AGENTS_INTEGRATION_ID, {"security": {"chat": []}, "profiles": {}}
        )
        if agent_id is not None:
            profiles = integration.setdefault("profiles", {})
            profile = profiles.setdefault(agent_id, {"security": {"chat": []}})
            profile["security"]["chat"].append(service_function)
        else:
            integration["security"]["chat"].append(service_function)

    # --- Transform: Database ---

    def transform_database(
        self,
        action_type: str,
        service_function: ServiceFunctionName,
        integration_id: str = BUILT_IN_DB_INTEGRATION_ID,
    ) -> None:
        db = self._ensure_database(integration_id)
        transform = db.setdefault("transform", {})
        transform[action_type] = {"type": action_type, "serviceFunction": service_function}

    def transform_collection(
        self,
        collection_name: str,
        action_type: str,
        service_function: ServiceFunctionName,
        integration_id: str = BUILT_IN_DB_INTEGRATION_ID,
    ) -> None:
        db = self._ensure_database(integration_id)
        collections = db.setdefault("collections", {})
        col = collections.setdefault(collection_name, {})
        transform = col.setdefault("transform", {})
        transform[action_type] = {"type": action_type, "serviceFunction": service_function}

    # --- Executable ---

    def executable(self, service_function: ServiceFunctionName) -> None:
        """Register an executable function.

        Both the plain method name and the qualified ``ClassName:methodName``
        are registered so that clients can call the function using either form.
        The qualified name always resolves unambiguously.
        """
        fn_name = service_function.split(":")[1] if ":" in service_function else service_function
        entry = {"serviceFunction": service_function}

        existing = self.data["executables"].get(fn_name)
        if existing and existing["serviceFunction"] != service_function:
            warnings.warn(
                f'Executable name collision: "{fn_name}" is registered by both '
                f'"{existing["serviceFunction"]}" and "{service_function}". '
                f"Use qualified names to avoid ambiguity.",
                stacklevel=2,
            )

        self.data["executables"][fn_name] = entry
        self.data["executables"][service_function] = entry

    # --- AI Function ---

    def ai_function(
        self,
        service_function: ServiceFunctionName,
        *,
        ai_function_id: str,
        description: str,
        params: list[AiFunctionParam],
        attributes: AiFunctionAttributes,
        categories: list[str],
        internal: bool,
    ) -> None:
        """Register an AI function. All fields are required (matching TS Required<AiFunctionMetadataOptions>)."""
        self.data["aiFunctions"][ai_function_id] = {
            "serviceFunction": service_function,
            "description": description,
            "params": params,
            "attributes": attributes,
            "categories": categories,
            "internal": internal,
        }

    # --- AI Functions Configurator ---

    def ai_functions_configurator(
        self,
        service_function: ServiceFunctionName,
        *,
        configurator_id: str,
        integration_types: list[str],
    ) -> None:
        self.data.setdefault("aiFunctionsConfigurators", {})[configurator_id] = {
            "serviceFunction": service_function,
            "integrationTypes": integration_types,
        }

    # --- Trigger ---

    def trigger(
        self,
        trigger_id: str,
        collection_name: str,
        service_function: ServiceFunctionName,
        integration_id: str,
        mutation_types: list[str] | None,
    ) -> None:
        if trigger_id in self.data["triggers"]:
            raise ValueError(f"Duplicate Trigger IDs: {trigger_id}")
        self.data["triggers"][trigger_id] = {
            "integrationId": integration_id,
            "collectionName": collection_name,
            "functionName": service_function,
            "mutationTypes": mutation_types,
        }

    # --- Scheduler ---

    def scheduler(
        self,
        scheduler_id: str,
        cron_expression: str,
        service_function: ServiceFunctionName,
        exclusive: bool,
    ) -> None:
        if scheduler_id in self.data["schedulers"]:
            raise ValueError(f"Duplicate Scheduler IDs: {scheduler_id}")
        self.data["schedulers"][scheduler_id] = {
            "cronExpression": cron_expression,
            "functionName": service_function,
            "exclusive": exclusive,
        }

    # --- Webhook ---

    def webhook(
        self,
        webhook_id: str,
        service_function: ServiceFunctionName,
    ) -> None:
        if webhook_id in self.data["webhooks"]:
            raise ValueError(f"Duplicate Webhook IDs: {webhook_id}")
        self.data["webhooks"][webhook_id] = {"functionName": service_function}

    # --- Limits ---

    def limits(
        self,
        service_function: ServiceFunctionName,
        options: LimiterOptions,
    ) -> None:
        self.data["limits"][service_function] = options

    # --- Client connection state handler ---

    def client_connection_change_handler(
        self,
        service_function: ServiceFunctionName,
    ) -> None:
        self.data["clientConnectionStateChangeHandlers"].append(service_function)

    # --- LLM Service ---

    def llm_service(
        self,
        service_name: str,
        options: LlmServiceOptions,
    ) -> None:
        models = options.get("models", {})
        if not models:
            raise ValueError(f"LLM service '{service_name}' must define at least one model")
        existing = self.data["llms"].get(service_name, {})
        if existing.get("models"):
            raise ValueError(f"LLM service '{service_name}' already has models defined")
        # Check for duplicate model names across all LLM services
        for other_name, other_llm in self.data["llms"].items():
            for model_name in models:
                if model_name in other_llm.get("models", {}):
                    raise ValueError(
                        f"Duplicate model name '{model_name}' in LLM services "
                        f"'{service_name}' and '{other_name}'"
                    )
        entry: dict[str, Any] = {"models": models}
        if "supportsFunctions" in options:
            entry["supportsFunctions"] = options["supportsFunctions"]
        self.data["llms"][service_name] = {**existing, **entry}

    def llm_ask(
        self,
        service_function: ServiceFunctionName,
    ) -> None:
        service_name = service_function.split(":")[0]
        llm = self.data["llms"].setdefault(service_name, {})
        if llm.get("ask"):
            raise ValueError(f"LLM service '{service_name}' already has an ask handler")
        llm["ask"] = service_function

    # --- MCP ---

    def mcp_server(
        self,
        service_name: str,
        options: McpServerOptions,
    ) -> None:
        # Validate no duplicate MCP server IDs
        for existing_name, existing in self.data["mcp"].items():
            if existing.get("options", {}).get("id") == options["id"]:
                raise ValueError(
                    f"Duplicate MCP server ID '{options['id']}' in "
                    f"'{service_name}' and '{existing_name}'"
                )
        self.data["mcp"][service_name] = {"options": options, "tools": []}

    def mcp_authorizer(
        self,
        service_function_name: ServiceFunctionName,
    ) -> None:
        service_name = service_function_name.split(":")[0]
        server = self.data["mcp"].setdefault(service_name, {"options": {}, "tools": []})
        if server.get("authorizer"):
            raise ValueError(f"MCP server '{service_name}' already has an authorizer")
        server["authorizer"] = service_function_name

    def mcp_tool(
        self,
        service_function_name: ServiceFunctionName,
        options: McpToolMetadataOptions,
    ) -> None:
        service_name = service_function_name.split(":")[0]
        server = self.data["mcp"].setdefault(service_name, {"options": {}, "tools": []})
        # Check for duplicate tool
        for tool in server["tools"]:
            if tool.get("serviceFunctionName") == service_function_name:
                raise ValueError(f"Duplicate MCP tool '{service_function_name}'")
        entry: dict[str, Any] = {
            "serviceFunctionName": service_function_name,
            "description": options["description"],
            "inputSchema": options["inputSchema"],
        }
        if "outputSchema" in options:
            entry["outputSchema"] = options["outputSchema"]
        server["tools"].append(entry)

    # --- Integration lifecycle hooks ---

    def set_integration_lifecycle_hooks(
        self,
        hooks: IntegrationLifecycleHooksMetadata,
    ) -> None:
        self.data["integrationLifecycleHooks"] = hooks

    # --- Helpers ---

    def _ensure_database(self, integration_id: str) -> dict:
        return self.data["databases"].setdefault(integration_id, {"collections": {}})


# Module-level singleton
_metadata_instance: Meta | None = None


def get_metadata() -> Meta:
    """Get the global Meta singleton, creating it if needed."""
    global _metadata_instance
    if _metadata_instance is None:
        _metadata_instance = Meta()
    return _metadata_instance


def reset_metadata() -> None:
    """Reset the global Meta singleton. Used in tests."""
    global _metadata_instance
    _metadata_instance = None
