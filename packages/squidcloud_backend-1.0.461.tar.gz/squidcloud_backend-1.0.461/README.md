# Squid Cloud Python Backend SDK

Python equivalent of `@squidcloud/backend` (the TypeScript backend SDK).
Provides decorators, `SquidService`, `SquidProject`, and types for building
Squid backend services in Python.

## Package: `squidcloud-backend`

Published to PyPI. Install with:
```bash
pip install squidcloud-backend
```

Depends on `squidcloud-client` (the Python client SDK) for `self.squid` access.

## File Structure

```
squidcloud_backend/
├── __init__.py          # Public API exports
├── types.py             # All TypedDict types, enums, type aliases
├── context.py           # Request-scoped context (contextvars — Python's AsyncLocalStorage)
├── metadata.py          # Meta singleton — collects decorator registrations
├── decorators.py        # All 27 decorators (@executable, @trigger, etc.)
├── service.py           # SquidService base class
├── project.py           # SquidProject entry point
└── llm_service.py       # SquidLlmService abstract base
```

## How It Works

### Decorator Registration

Python decorators execute before the class body is complete, so we use a
deferred registration pattern:

1. Each decorator stores a `(name, register_fn)` tuple on the function via
   the `__squid_decorators__` attribute
2. When the class is defined, `SquidService.__init_subclass__()` iterates all
   methods and calls each `register_fn(cls, method_name)`
3. `register_fn` calls the corresponding method on the `Meta` singleton
4. Class-level decorators (`@llm_service`, `@mcp_server`) store options as
   class attributes, processed in `__init_subclass__()`

### Request Context (contextvars)

The Python equivalent of Node.js `AsyncLocalStorage` is `contextvars.ContextVar`.
Per-request state (auth, RunContext) is stored in a context var and accessed
via `SquidService.context`, `SquidService.get_user_auth()`, etc.

```python
# The worker sets the context before calling a service method:
with RequestScope(ServiceRequestConfig(auth=auth, context=run_context)):
    result = service.my_method(*params)

# Inside the method, the service accesses it:
class MyService(SquidService):
    @executable()
    async def my_method(self) -> str:
        user = self.get_user_auth()  # reads from context var
        return f"Hello, {user['userId']}!"
```

### Environment Variables

The following environment variables are used:

| Variable | Description | Default |
|----------|-------------|---------|
| `SQUID_REGION` | Deployment region (e.g., `us-east-1.aws`) | `local` |
| `SQUID_APP_ID` | Application ID | — |

Secrets and API keys are NOT set via env vars — they are passed per-request
in the `ExecuteFunctionPayload` from the tenant/local-backend.

### Global State

The worker subprocess sets these class-level globals on `SquidService` before
each request:

- `_global_secrets` — Custom secrets from the Squid console
- `_global_api_keys` — API keys from the Squid console
- `_global_backend_api_key` — Internal backend API key
- `_global_app_id` — Application ID
- `_global_assets_directory` — Path to the `public/` assets directory

### self.squid — Accessing the Client SDK

`SquidService.squid` returns a `squidcloud.Squid` instance (from the
`squidcloud-client` package). It is initialized lazily using the backend API
key and region. Backend services can call any Squid API:

```python
class MyService(SquidService):
    @executable()
    async def summarize(self, url: str) -> str:
        content = await self.squid.web().get_url_content(url)
        return await self.squid.ai().agent("summarizer").ask(content)
```

## Types

All types use `TypedDict` for JSON compatibility and IDE autocompletion.
Key types:

- **Request/Response**: `WebhookRequest`, `WebhookResponse`, `TriggerRequest`,
  `OpenApiResponse`, `SquidFile`
- **Auth**: `AuthWithBearer`, `AuthWithApiKey`, `RunContext`, `ServiceRequestConfig`
- **Decorator options**: `TriggerOptions`, `SchedulerOptions`, `AiFunctionParam`,
  `LimiterConfig`, `McpServerOptions`, `LlmServiceOptions`
- **Enums**: `CronExpression` (50+ common cron schedules)
- **Action types**: `DatabaseActionType`, `StorageActionType`, `TopicActionType`,
  `MetricActionType`, `MutationType`

## Metadata Output

`SquidProject.metadata()` returns a dict matching the `ApplicationBundleData`
JSON schema. This is consumed by the platform to discover and route:
executables, webhooks, triggers, schedulers, security rules, AI functions,
LLM services, MCP servers, and rate/quota limits.

## Compatibility with TypeScript SDK

This SDK mirrors the TypeScript `@squidcloud/backend` package:

| TypeScript | Python |
|------------|--------|
| `class MyService extends SquidService` | `class MyService(SquidService)` |
| `@executable()` | `@executable()` |
| `@trigger('id', 'collection')` | `@trigger('id', 'collection')` |
| `@scheduler('id', CronExpression.EVERY_HOUR)` | `@scheduler('id', CronExpression.EVERY_HOUR)` |
| `@webhook('id')` | `@webhook('id')` |
| `@aiFunction('desc', params)` | `@ai_function('desc', params)` |
| `this.squid` | `self.squid` |
| `this.context` | `self.context` |
| `this.secrets` | `self.secrets` |
| `this.createWebhookResponse(...)` | `self.create_webhook_response(...)` |
| `new SquidProject()` | `SquidProject()` |
