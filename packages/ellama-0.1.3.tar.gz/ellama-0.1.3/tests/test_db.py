from time import time

import pytest

from ellama import Document, EllamaDB


@pytest.fixture(scope="module")
def db():
    return EllamaDB("test")


def test_db(db: EllamaDB):
    db.add_documents([
        Document(page_content="hello world", metadata={"time": time()}, id="one"),
        Document(page_content="goodbye and goodnight", metadata={"time": time()}, id="two")])
    docs = db.similarity_search_with_relevance_scores("Greetings, Earth!", k=1)
    assert len(docs) == 1
    assert docs[0].id == "one"

    docs = db.similarity_search_with_relevance_scores_by_id("one")
    assert docs[0][0].page_content == "hello world"
