# Ellama

Embeddings library (i.e. vector database) built over [Ollama](https://ollama.com/search?c=embedding).

```py
from ellama import EllamaDB, Document

db = EllamaDB("test")
db.add_documents([
    Document(page_content="hello world", id="salutation"),
    Document(page_content="goodbye and goodnight", id="farewell")])
docs = db.similarity_search_with_relevance_scores("Greetings, Earth!", k=1)
assert len(docs) == 1
assert docs[0].id == "salutation"
```
