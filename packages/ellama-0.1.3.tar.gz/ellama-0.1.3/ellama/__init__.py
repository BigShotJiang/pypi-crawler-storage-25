"""Embeddings using Ollama + FAISS + Langchain.

config env var defaults:
- OLLAMA_BASE_URL=http://localhost:11434
- OLLAMA_MODEL=qwen3-embedding:0.6b  (see <https://ollama.com/search?c=embedding>)
- CACHE_ROOT=.cache
"""
import functools
import logging
import os
from contextlib import contextmanager
from pathlib import Path, PurePath
from shutil import rmtree

from tqdm import tqdm

os.environ['LIBGL_DEBUG'] = "quiet" # suppres FAISS libGL missing drirc file warnings

from langchain_community.docstore.in_memory import InMemoryDocstore
from langchain_community.vectorstores import FAISS
from langchain_community.vectorstores.faiss import dependable_faiss_import
from langchain_core.documents import Document
from langchain_ollama import OllamaEmbeddings

__all__ = ['EllamaDB']
log = logging.getLogger(__name__)
faiss = dependable_faiss_import()
BASE_URL = os.getenv('OLLAMA_BASE_URL', "http://localhost:11434")
MODEL = os.getenv('OLLAMA_MODEL', 'qwen3-embedding:0.6b')
CACHE_ROOT = Path(os.getenv('CACHE_ROOT', ".cache"))


@contextmanager
def log_level(logger_name: str, level: int | str):
    logger = logging.getLogger(logger_name)
    old = logger.level
    logger.setLevel(level)
    try:
        yield
    finally:
        logger.setLevel(old)


@functools.cache
def get_embedder(model, base_url):
    embedder = OllamaEmbeddings(model=model, base_url=base_url)
    with tqdm(desc=f"pulling {model}") as t:
        for i in embedder._client.pull(model, stream=True):
            t.total = i.total
            if i.completed:
                t.update(i.completed - t.n)
    with log_level('httpx', logging.WARNING):
        size = len(embedder.embed_query("hello world"))
    return embedder, size


class EllamaDB:
    def __init__(self, name: str, model: str = MODEL, base_url: str = BASE_URL, cache_root: PurePath = CACHE_ROOT):
        self.db_path = db_path = Path(cache_root) / name
        embedder, size = get_embedder(model, base_url)
        if (db_path / "index.faiss").exists():
            self.faiss = FAISS.load_local(str(db_path), embedder, allow_dangerous_deserialization=True)
        else:
            rmtree(db_path, ignore_errors=True)
            self.faiss = FAISS(embedder, faiss.IndexFlatL2(size), InMemoryDocstore(), {})

    def __getattr__(self, *args, **kwargs):
        return getattr(self.faiss, *args, **kwargs)

    def save_local(self):
        self.faiss.save_local(str(self.db_path), self.db_path.name)

    def add_documents(self, docs: list[Document], save_local=True):
        with log_level('httpx', logging.WARNING):
            for doc in tqdm(docs, desc=f"{self.db_path.name}:indexing", unit="doc"):
                if (old := self.get_by_ids([doc.id])) != [doc]:
                    if old:
                        log.debug("updating:%r", doc.id)
                        self.delete([doc.id])
                    log.debug("adding:%r", doc.id)
                    self.faiss.add_documents([doc])
        if save_local:
            self.save_local()

    def similarity_search_with_relevance_scores(self, query: str, k: int = 4, **kwargs) -> list[Document]:
        """k: max documents returned by vector search"""
        from warnings import catch_warnings, filterwarnings
        with catch_warnings():
            filterwarnings(action="ignore", message="Relevance scores must be between 0 and 1", category=UserWarning)
            with log_level('httpx', logging.WARNING):
                scores = self.faiss.similarity_search_with_relevance_scores(query, k=k, **kwargs)
        # log.debug("similarity_search_with_relevance_scores:%r", {doc.metadata['title']: score for doc, score in scores})
        return [doc for doc, score in scores if score > 0]

    def similarity_search_with_relevance_scores_by_id(self, id: str, **kwargs) -> list[tuple[Document, float]]:
        index_id = next(i for i, j in self.index_to_docstore_id.items() if j == id)
        ntotal, d = self.index.ntotal, self.index.d
        embedding = faiss.rev_swig_ptr(self.index.get_xb(), ntotal * d).reshape(ntotal, d)[index_id]
        relevance_score_fn = self.faiss._select_relevance_score_fn()
        k = len(self.index_to_docstore_id)
        return [(doc, relevance_score_fn(score))
                for doc, score in self.similarity_search_with_score_by_vector(embedding, k=k, fetch_k=k, **kwargs)]

    def get_docs(self, filter: dict[str]) -> list[Document]:
        filter_func = self._create_filter_func(filter)
        return [doc for doc in self.get_by_ids(self.index_to_docstore_id.values()) if filter_func(doc.metadata)]
