"""Statistics indicators."""
from ._core import _a, _rollsum, _stdev, _highest, _lowest, _median, _mad, _variance, _zscore, _skew, _kurtosis, _quantile, _entropy, _tos_stdevall


def rollsum(data, period):
    return _rollsum(_a(data), period)


def stdev(data, period):
    return _stdev(_a(data), period)


def highest(data, period):
    return _highest(_a(data), period)


def lowest(data, period):
    return _lowest(_a(data), period)


def median(data, period):
    return _median(_a(data), period)


def mad(data, period):
    return _mad(_a(data), period)


def variance(data, period):
    return _variance(_a(data), period)


def zscore(data, period):
    return _zscore(_a(data), period)


def skew(data, period):
    return _skew(_a(data), period)


def kurtosis(data, period):
    return _kurtosis(_a(data), period)


def quantile(data, period, q=0.5):
    return _quantile(_a(data), period, q)


def entropy(data, period, bins=10):
    return _entropy(_a(data), period, bins)


def tos_stdevall(data):
    return _tos_stdevall(_a(data))
