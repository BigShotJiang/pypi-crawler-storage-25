"""Volume indicators."""
from ._core import _a, _obv, _ad, _adosc, _aobv, _cmf, _efi, _eom, _kvo, _mfi, _nvi, _pvi, _pvo, _pvol, _pvr, _pvt, _tsv, _vhm, _vp


def obv(close, volume):
    return _obv(_a(close), _a(volume))


def ad(high, low, close, volume):
    return _ad(_a(high), _a(low), _a(close), _a(volume))


def adosc(high, low, close, volume, fast=3, slow=10):
    return _adosc(_a(high), _a(low), _a(close), _a(volume), fast, slow)


def aobv(close, volume, fast=2, slow=5):
    return _aobv(_a(close), _a(volume), fast, slow)


def cmf(high, low, close, volume, period):
    return _cmf(_a(high), _a(low), _a(close), _a(volume), period)


def efi(close, volume, period):
    return _efi(_a(close), _a(volume), period)


def eom(high, low, volume, period):
    return _eom(_a(high), _a(low), _a(volume), period)


def kvo(high, low, close, volume, fast=34, slow=55, signal=13):
    return _kvo(_a(high), _a(low), _a(close), _a(volume), fast, slow, signal)


def mfi(high, low, close, volume, period):
    return _mfi(_a(high), _a(low), _a(close), _a(volume), period)


def nvi(close, volume):
    return _nvi(_a(close), _a(volume))


def pvi(close, volume):
    return _pvi(_a(close), _a(volume))


def pvo(volume, fast=12, slow=26, signal=9):
    return _pvo(_a(volume), fast, slow, signal)


def pvol(close, volume):
    return _pvol(_a(close), _a(volume))


def pvr(close, volume):
    return _pvr(_a(close), _a(volume))


def pvt(close, volume):
    return _pvt(_a(close), _a(volume))


def tsv(close, volume, period):
    return _tsv(_a(close), _a(volume), period)


def vhm(high, low, volume):
    return _vhm(_a(high), _a(low), _a(volume))


def vp(close, volume, width=10):
    return _vp(_a(close), _a(volume), width)
