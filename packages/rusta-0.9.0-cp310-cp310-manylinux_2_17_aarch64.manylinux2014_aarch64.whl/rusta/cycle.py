"""Cycle indicators."""
from ._core import _a, _ebsw, _reflex


def ebsw(data, period=40):
    return _ebsw(_a(data), period)


def reflex(data, period=20):
    return _reflex(_a(data), period)
