"""Performance indicators."""
from ._core import (
    _a, _drawdown, _log_return, _percent_return,
    _volatility, _value_at_risk, _sharpe_ratio,
    _sortino_ratio, _calmar_ratio, _profit_factor,
    _expectancy,
)

def drawdown(data): return _drawdown(_a(data))
def log_return(data): return _log_return(_a(data))
def percent_return(data): return _percent_return(_a(data))
def volatility(data, period=252): return _volatility(_a(data), period)
def value_at_risk(data, period=252, confidence=0.95): return _value_at_risk(_a(data), period, confidence)
def sharpe_ratio(data, risk_free_rate=0.0, period=252): return _sharpe_ratio(_a(data), risk_free_rate, period)
def sortino_ratio(data, risk_free_rate=0.0, period=252): return _sortino_ratio(_a(data), risk_free_rate, period)
def calmar_ratio(data, period=252): return _calmar_ratio(_a(data), period)
def profit_factor(data, period=252): return _profit_factor(_a(data), period)
def expectancy(data, period=252): return _expectancy(_a(data), period)
