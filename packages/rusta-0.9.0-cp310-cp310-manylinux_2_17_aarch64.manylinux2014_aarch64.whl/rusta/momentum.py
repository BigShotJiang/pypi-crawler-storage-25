"""Momentum indicators."""
from ._core import (
    _a, _macd, _rsi, _mom, _roc, _stoch, _kdj, _cci, _willr,
    _ao, _apo, _bias, _bop, _brar, _cfo, _cg, _cmo, _coppock,
    _crsi, _cti, _dm, _er, _eri, _exhc, _fisher, _inertia,
    _kst, _pgo, _ppo, _psl, _qqe, _rsx, _rvgi, _slope,
    _smc, _smi, _squeeze, _squeeze_pro, _stc, _stochf,
    _stochrsi, _tmo, _trix, _tsi, _uo,
)


def macd(data, fast=12, slow=26, signal=9):
    return _macd(_a(data), fast, slow, signal)


def rsi(data, period=14):
    return _rsi(_a(data), period)


def mom(data, period=10):
    return _mom(_a(data), period)


def roc(data, period=10):
    return _roc(_a(data), period)


def stoch(high, low, close, k_period=14, d_period=3):
    return _stoch(_a(high), _a(low), _a(close), k_period, d_period)


def kdj(high, low, close, period=9, k_smooth=3, d_smooth=3):
    return _kdj(_a(high), _a(low), _a(close), period, k_smooth, d_smooth)


def cci(high, low, close, period=14):
    return _cci(_a(high), _a(low), _a(close), period)


def willr(high, low, close, period=14):
    return _willr(_a(high), _a(low), _a(close), period)


def ao(high, low, fast=5, slow=34):
    return _ao(_a(high), _a(low), fast, slow)


def apo(data, fast=12, slow=26):
    return _apo(_a(data), fast, slow)


def bias(data, period=26):
    return _bias(_a(data), period)


def bop(open_, high, low, close):
    return _bop(_a(open_), _a(high), _a(low), _a(close))


def brar(open_, high, low, close, period=26):
    return _brar(_a(open_), _a(high), _a(low), _a(close), period)


def cfo(data, period=14):
    return _cfo(_a(data), period)


def cg(data, period=10):
    return _cg(_a(data), period)


def cmo(data, period=14):
    return _cmo(_a(data), period)


def coppock(data, roc1=11, roc2=14, period=10):
    return _coppock(_a(data), roc1, roc2, period)


def crsi(high, low, close, period=14, k=3):
    return _crsi(_a(high), _a(low), _a(close), period, k)


def cti(data, period=12):
    return _cti(_a(data), period)


def dm(high, low, period=14):
    return _dm(_a(high), _a(low), period)


def er(data, period=10):
    return _er(_a(data), period)


def eri(high, low, close, period=13):
    return _eri(_a(high), _a(low), _a(close), period)


def exhc(data, period=1):
    return _exhc(_a(data), period)


def fisher(high, low, period=9):
    return _fisher(_a(high), _a(low), period)


def inertia(data, period=20):
    return _inertia(_a(data), period)


def kst(data, roc1=10, roc2=15, roc3=20, roc4=30, sma1=10, sma2=10, sma3=10, sma4=15, signal=9):
    return _kst(_a(data), roc1, roc2, roc3, roc4, sma1, sma2, sma3, sma4, signal)


def pgo(high, low, close, period=14):
    return _pgo(_a(high), _a(low), _a(close), period)


def ppo(data, fast=12, slow=26, signal=9):
    return _ppo(_a(data), fast, slow, signal)


def psl(data, period=12):
    return _psl(_a(data), period)


def qqe(data, period=14, smooth=5, factor=4.236):
    return _qqe(_a(data), period, smooth, factor)


def rsx(data, period=14):
    return _rsx(_a(data), period)


def rvgi(open_, high, low, close, period=14):
    return _rvgi(_a(open_), _a(high), _a(low), _a(close), period)


def slope(data, period=5):
    return _slope(_a(data), period)


def smc(high, low, close, period=20):
    return _smc(_a(high), _a(low), _a(close), period)


def smi(high, low, close, period=14, signal=3):
    return _smi(_a(high), _a(low), _a(close), period, signal)


def squeeze(high, low, close, period=20):
    return _squeeze(_a(high), _a(low), _a(close), period)


def squeeze_pro(high, low, close, period=20):
    return _squeeze_pro(_a(high), _a(low), _a(close), period)


def stc(data, fast=23, slow=50, period=10):
    return _stc(_a(data), fast, slow, period)


def stochf(high, low, close, period=14):
    return _stochf(_a(high), _a(low), _a(close), period)


def stochrsi(data, period=14, k_period=3, d_period=3):
    return _stochrsi(_a(data), period, k_period, d_period)


def tmo(data, period=14):
    return _tmo(_a(data), period)


def trix(data, period=18):
    return _trix(_a(data), period)


def tsi(close, fast=25, slow=13):
    return _tsi(_a(close), fast, slow)


def uo(high, low, close, fast=7, medium=14, slow=28):
    return _uo(_a(high), _a(low), _a(close), fast, medium, slow)
