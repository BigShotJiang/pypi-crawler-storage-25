"""Transform indicators."""
from ._core import _a, _ha, _renko, _pivots


def ha(open_, high, low, close):
    return _ha(_a(open_), _a(high), _a(low), _a(close))


def renko(close, brick_size):
    return _renko(_a(close), brick_size)


def pivots(high, low, close, mode="floor"):
    return _pivots(_a(high), _a(low), _a(close), mode)
