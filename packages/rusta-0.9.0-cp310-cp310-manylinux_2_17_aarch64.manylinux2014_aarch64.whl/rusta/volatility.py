"""Volatility indicators."""
from ._core import _a, _true_range, _atr, _donchian, _bbands, _kc, _accbands, _massi, _natr, _rvi, _ui, _aberration, _atrts, _chandelier_exit, _hwc, _pdist, _thermo


def true_range(high, low, close):
    return _true_range(_a(high), _a(low), _a(close))


def atr(high, low, close, period=14):
    return _atr(_a(high), _a(low), _a(close), period)


def donchian(high, low, period=20):
    return _donchian(_a(high), _a(low), period)


def bbands(data, period=20, std=2.0):
    return _bbands(_a(data), period, std)


def kc(high, low, close, period=20, multiplier=2.0):
    return _kc(_a(high), _a(low), _a(close), period, multiplier)


def accbands(close, high, low, length=100):
    return _accbands(_a(close), _a(high), _a(low), length)


def massi(high, low, period=25):
    return _massi(_a(high), _a(low), period)


def natr(high, low, close, period=14):
    return _natr(_a(high), _a(low), _a(close), period)


def rvi(high, low, close, period=14):
    return _rvi(_a(high), _a(low), _a(close), period)


def ui(close, period=14):
    return _ui(_a(close), period)


def aberration(data, period=50):
    return _aberration(_a(data), period)


def atrts(high, low, close, period=22, multiplier=3.0):
    return _atrts(_a(high), _a(low), _a(close), period, multiplier)


def chandelier_exit(high, low, close, period=22, multiplier=3.0):
    return _chandelier_exit(_a(high), _a(low), _a(close), period, multiplier)


def hwc(data, period=20, multiplier=2.0):
    return _hwc(_a(data), period, multiplier)


def pdist(data, drift=1):
    return _pdist(_a(data), drift)


def thermo(data, period=20, long=50, short=0.5):
    return _thermo(_a(data), period, long, short)
