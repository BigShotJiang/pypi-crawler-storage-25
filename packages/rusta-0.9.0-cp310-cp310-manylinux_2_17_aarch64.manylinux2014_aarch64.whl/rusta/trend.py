"""Trend indicators."""
from ._core import (
    _a, _adx, _ht_trendline,
    _alphatrend, _amat, _aroon, _chop, _cksp,
    _decay, _decreasing, _dpo,
    _increasing, _long_run,
    _psar, _qstick, _rwi, _short_run, _trendflex,
    _ttm_trend, _vhf, _vortex, _zigzag,
)


def adx(high, low, close, period=14):
    return _adx(_a(high), _a(low), _a(close), period)


def ht_trendline(data):
    return _ht_trendline(_a(data))


def alphatrend(high, low, close, period=14):
    return _alphatrend(_a(high), _a(low), _a(close), period)


def amat(data, fast=8, slow=32):
    return _amat(_a(data), fast, slow)


def aroon(high, low, period=14):
    return _aroon(_a(high), _a(low), period)


def chop(high, low, close, period=14):
    return _chop(_a(high), _a(low), _a(close), period)


def cksp(high, low, close, period=10):
    return _cksp(_a(high), _a(low), _a(close), period)


def decay(data, period=5):
    return _decay(_a(data), period)


def decreasing(data, period=1):
    return _decreasing(_a(data), period)


def dpo(data, period=20):
    return _dpo(_a(data), period)


def increasing(data, period=1):
    return _increasing(_a(data), period)


def long_run(data, period=10):
    return _long_run(_a(data), period)


def psar(high, low, close, af_step=0.02, af_max=0.2):
    return _psar(_a(high), _a(low), _a(close), af_step, af_max)


def qstick(open_, close, period=14):
    return _qstick(_a(open_), _a(close), period)


def rwi(high, low, close, period=14):
    return _rwi(_a(high), _a(low), _a(close), period)


def short_run(data, period=10):
    return _short_run(_a(data), period)


def trendflex(data, period=20):
    return _trendflex(_a(data), period)


def ttm_trend(high, low, close, period=6):
    return _ttm_trend(_a(high), _a(low), _a(close), period)


def vhf(close, period=28):
    return _vhf(_a(close), period)


def vortex(high, low, close, period=14):
    return _vortex(_a(high), _a(low), _a(close), period)


def zigzag(high, low, depth=12, deviation=5, backstep=3):
    return _zigzag(_a(high), _a(low), depth, deviation, backstep)
