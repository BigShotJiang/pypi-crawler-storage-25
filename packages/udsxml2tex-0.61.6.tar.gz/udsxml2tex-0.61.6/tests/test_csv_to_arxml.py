"""Tests for the CSV → ARXML skeleton generator."""

from __future__ import annotations

import csv
from pathlib import Path

import pytest

from udsxml2tex.csv_to_arxml import generate_arxml_from_rtm
from udsxml2tex.parser import ArxmlParser
from udsxml2tex.rtm import load_rtm_csv


def _write_csv(path: Path, rows: list[dict]) -> None:
    fieldnames = ["req_id", "description", "source_ref", "traces_to",
                  "verified_by", "status", "comment"]
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow(r)


@pytest.fixture
def boot_csv(tmp_path: Path) -> Path:
    p = tmp_path / "boot.csv"
    _write_csv(p, [
        dict(req_id="REQ-001", description="ProgrammingSession",
             source_ref="OEM§1", traces_to="session:0x02",
             verified_by="", status="accepted", comment=""),
        dict(req_id="REQ-002", description="SecurityAccess L1",
             source_ref="OEM§2", traces_to="sid:0x27:0x01;security:0x01",
             verified_by="", status="accepted", comment=""),
        dict(req_id="REQ-003", description="RequestDownload",
             source_ref="OEM§3", traces_to="sid:0x34",
             verified_by="", status="accepted", comment=""),
        dict(req_id="REQ-004", description="TransferData",
             source_ref="OEM§4", traces_to="sid:0x36",
             verified_by="", status="accepted", comment=""),
        dict(req_id="REQ-005", description="EraseMemory",
             source_ref="OEM§5", traces_to="rid:0xFF00",
             verified_by="", status="accepted", comment=""),
        dict(req_id="REQ-006", description="App SW Fingerprint",
             source_ref="OEM§6", traces_to="did:0xF184",
             verified_by="", status="accepted", comment=""),
        # Drive-only row (DID 0xF200 is outside the boot identification
        # range 0xF180-0xF1FF) to be filtered out by domain="boot".
        dict(req_id="REQ-100", description="Read application data",
             source_ref="OEM§10", traces_to="did:0xF200",
             verified_by="", status="accepted", comment=""),
    ])
    return p


class TestGenerateArxmlFromRtm:
    def test_generates_well_formed_xml(self, boot_csv: Path,
                                       tmp_path: Path) -> None:
        out = tmp_path / "gen.arxml"
        entries = load_rtm_csv(boot_csv)
        generate_arxml_from_rtm(entries, output_path=out,
                                ecu_name="BootEcu", domain_filter="boot")
        assert out.exists()
        # Round-trip parse must succeed.
        spec = ArxmlParser().parse(out)
        sids = {svc.service_id for svc in spec.services}
        dids = {d.did_id for d in spec.dids}
        rids = {r.routine_id for r in spec.routines}
        session_ids = {s.session_id for s in spec.sessions}
        # Boot-relevant must be present.
        assert 0x27 in sids
        assert 0x34 in sids
        assert 0x36 in sids
        assert 0xF184 in dids
        assert 0xFF00 in rids
        assert 0x02 in session_ids

    def test_domain_filter_boot_excludes_drive_did(self, boot_csv: Path,
                                                   tmp_path: Path) -> None:
        out = tmp_path / "gen.arxml"
        entries = load_rtm_csv(boot_csv)
        generate_arxml_from_rtm(entries, output_path=out,
                                ecu_name="Boot", domain_filter="boot")
        spec = ArxmlParser().parse(out)
        # 0xF200 is outside the boot identification range — must NOT appear.
        assert 0xF200 not in {d.did_id for d in spec.dids}

    def test_domain_filter_all_keeps_everything(self, boot_csv: Path,
                                                tmp_path: Path) -> None:
        out = tmp_path / "gen.arxml"
        entries = load_rtm_csv(boot_csv)
        generate_arxml_from_rtm(entries, output_path=out,
                                ecu_name="Full", domain_filter="all")
        spec = ArxmlParser().parse(out)
        assert 0xF200 in {d.did_id for d in spec.dids}
        assert 0xF184 in {d.did_id for d in spec.dids}

    def test_empty_filter_result_raises(self, tmp_path: Path) -> None:
        p = tmp_path / "drive_only.csv"
        _write_csv(p, [
            dict(req_id="REQ-A", description="Read VIN",
                 source_ref="OEM§1", traces_to="did:0xF190",
                 verified_by="", status="accepted", comment=""),
        ])
        # The single DID 0xF190 falls inside the boot identification range,
        # so this CSV actually *does* produce a non-empty boot skeleton. Use
        # a clearly drive-only trace instead.
        p.write_text(
            "req_id,description,source_ref,traces_to,verified_by,status,comment\n"
            "REQ-A,SomeDriveOnly,OEM,dtc:0x123456,,accepted,\n",
            encoding="utf-8",
        )
        entries = load_rtm_csv(p)
        with pytest.raises(ValueError):
            generate_arxml_from_rtm(entries, output_path=tmp_path / "x.arxml",
                                    domain_filter="boot")

    def test_invalid_domain_raises(self) -> None:
        with pytest.raises(ValueError):
            generate_arxml_from_rtm([], domain_filter="bogus")
