"""Tests for the multi-language output feature (--langs / Web UI).

Covers:
- ``cli._parse_langs`` parsing/validation/dedup
- ``webserver._parse_langs_form`` parsing/dedup
- CLI ``--langs en,ja,de`` emits one file per language (md format)
"""

from __future__ import annotations

from pathlib import Path

import pytest

FIXTURES_DIR = Path(__file__).parent / "fixtures"
SAMPLE_ARXML = FIXTURES_DIR / "sample_dcm.arxml"


# ---- cli._parse_langs --------------------------------------------------- #


class TestParseLangsCli:
    def test_none_returns_fallback(self):
        from udsxml2tex.cli import _parse_langs
        assert _parse_langs(None, "en") == ["en"]
        assert _parse_langs(None, "ja+en") == ["ja+en"]

    def test_empty_string_returns_fallback(self):
        from udsxml2tex.cli import _parse_langs
        assert _parse_langs("", "en") == ["en"]
        assert _parse_langs("   ", "ja") == ["ja"]

    def test_comma_separated(self):
        from udsxml2tex.cli import _parse_langs
        assert _parse_langs("en,ja,de", "en") == ["en", "ja", "de"]

    def test_handles_whitespace_and_semicolons(self):
        from udsxml2tex.cli import _parse_langs
        assert _parse_langs(" en ,ja; de ", "en") == ["en", "ja", "de"]

    def test_deduplicates_preserving_order(self):
        from udsxml2tex.cli import _parse_langs
        assert _parse_langs("ja,en,ja,de,en", "en") == ["ja", "en", "de"]

    def test_unknown_code_raises(self):
        from udsxml2tex.cli import _parse_langs
        with pytest.raises(ValueError, match="Unknown language code"):
            _parse_langs("en,xx", "en")

    def test_bilingual_code_rejected_in_langs(self):
        # --langs only accepts monolingual codes (ja+en is for --lang only).
        from udsxml2tex.cli import _parse_langs
        with pytest.raises(ValueError):
            _parse_langs("ja+en", "en")


# ---- webserver._parse_langs_form --------------------------------------- #


class TestParseLangsForm:
    def test_none_defaults_to_en(self):
        from udsxml2tex.webserver import _parse_langs_form
        assert _parse_langs_form(None) == ["en"]

    def test_empty_defaults_to_en(self):
        from udsxml2tex.webserver import _parse_langs_form
        assert _parse_langs_form("") == ["en"]

    def test_basic_comma_list(self):
        from udsxml2tex.webserver import _parse_langs_form
        assert _parse_langs_form("en,ja,de") == ["en", "ja", "de"]

    def test_drops_unknown_codes(self):
        from udsxml2tex.webserver import _parse_langs_form
        assert _parse_langs_form("en,xx,ja") == ["en", "ja"]

    def test_deduplicates(self):
        from udsxml2tex.webserver import _parse_langs_form
        assert _parse_langs_form("en,en,ja") == ["en", "ja"]

    def test_only_unknowns_falls_back_to_en(self):
        from udsxml2tex.webserver import _parse_langs_form
        assert _parse_langs_form("xx,yy") == ["en"]


# ---- CLI end-to-end: --langs ------------------------------------------- #


class TestCliLangsEndToEnd:
    def test_single_lang_no_suffix(self, tmp_path):
        """--langs en (single) keeps the legacy unsuffixed filename."""
        from udsxml2tex.cli import main
        output = tmp_path / "spec.md"
        rc = main([
            str(SAMPLE_ARXML),
            "-o", str(output),
            "--format", "md",
            "--langs", "en",
        ])
        assert rc == 0
        assert output.exists()
        # No language-suffixed siblings.
        assert not (tmp_path / "spec_en.md").exists()
        assert not (tmp_path / "spec_ja.md").exists()

    def test_multi_langs_emit_per_language_files(self, tmp_path):
        from udsxml2tex.cli import main
        output = tmp_path / "spec.md"
        rc = main([
            str(SAMPLE_ARXML),
            "-o", str(output),
            "--format", "md",
            "--langs", "en,ja,de",
        ])
        assert rc == 0
        assert (tmp_path / "spec_en.md").exists()
        assert (tmp_path / "spec_ja.md").exists()
        assert (tmp_path / "spec_de.md").exists()
        # Unsuffixed file is *not* written in multi-lang mode.
        assert not (tmp_path / "spec.md").exists()

    def test_multi_langs_invalid_code(self, tmp_path):
        """An invalid --langs token causes a clean failure (rc != 0)."""
        from udsxml2tex.cli import main
        output = tmp_path / "spec.md"
        rc = main([
            str(SAMPLE_ARXML),
            "-o", str(output),
            "--format", "md",
            "--langs", "en,xx",
        ])
        assert rc != 0
