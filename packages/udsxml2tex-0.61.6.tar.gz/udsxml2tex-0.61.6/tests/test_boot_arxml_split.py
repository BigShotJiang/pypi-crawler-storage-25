"""Tests for the App+Boot ARXML split feature.

Covers:
* :func:`udsxml2tex.repo_scanner.is_boot_path` — heuristic boundaries
* :func:`udsxml2tex.repo_scanner.partition_by_ecu` — split into app/boot,
  4-group redundant-µC layout, sibling boot/app fold
* :func:`udsxml2tex.multi_ecu.loader.merge_boot_spec` — domain tagging
* :func:`udsxml2tex.repo_scanner.load_from_repo` — end-to-end merge in
  single-ECU mode using the bundled fixtures
"""

from __future__ import annotations

from pathlib import Path

import pytest

from udsxml2tex.multi_ecu.loader import merge_boot_spec
from udsxml2tex.multi_ecu.models import EcuConfig, EcuRole
from udsxml2tex.parser import ArxmlParser
from udsxml2tex.repo_scanner import (
    EcuPartition,
    RepoScanResult,
    is_boot_path,
    partition_by_ecu,
    scan_repo,
    load_from_repo,
)


FIXTURES = Path(__file__).parent / "fixtures"
APP_DCM = FIXTURES / "sample_dcm.arxml"
BOOT_DCM = FIXTURES / "sample_boot_dcm.arxml"
APP_CANTP = FIXTURES / "sample_cantp.arxml"
APP_DEM = FIXTURES / "sample_dem.arxml"
SECONDARY_DCM = FIXTURES / "sample_secondary_dcm.arxml"


# -----------------------------------------------------------------------------
# is_boot_path
# -----------------------------------------------------------------------------

class TestIsBootPath:
    def test_directory_segment_boot(self, tmp_path: Path) -> None:
        p = tmp_path / "boot" / "Dcm.arxml"
        p.parent.mkdir()
        p.write_text("x")
        assert is_boot_path(p, tmp_path) is True

    def test_directory_segment_fbl(self, tmp_path: Path) -> None:
        p = tmp_path / "fbl" / "config" / "Dcm.arxml"
        p.parent.mkdir(parents=True)
        p.write_text("x")
        assert is_boot_path(p, tmp_path) is True

    def test_directory_segment_bootloader(self, tmp_path: Path) -> None:
        p = tmp_path / "Bootloader" / "Dcm.arxml"
        p.parent.mkdir()
        p.write_text("x")
        assert is_boot_path(p, tmp_path) is True

    def test_directory_segment_uppercase_bl(self, tmp_path: Path) -> None:
        p = tmp_path / "BL" / "Dcm.arxml"
        p.parent.mkdir()
        p.write_text("x")
        assert is_boot_path(p, tmp_path) is True

    def test_filename_boot_suffix(self, tmp_path: Path) -> None:
        p = tmp_path / "Dcm_boot.arxml"
        p.write_text("x")
        assert is_boot_path(p, tmp_path) is True

    def test_filename_boot_prefix(self, tmp_path: Path) -> None:
        p = tmp_path / "boot_Dcm.arxml"
        p.write_text("x")
        assert is_boot_path(p, tmp_path) is True

    def test_no_match_for_app_path(self, tmp_path: Path) -> None:
        p = tmp_path / "app" / "Dcm.arxml"
        p.parent.mkdir()
        p.write_text("x")
        assert is_boot_path(p, tmp_path) is False

    def test_no_match_for_unrelated_filename(self, tmp_path: Path) -> None:
        # 'block' contains 'bl' as substring but not as separator-bounded
        # token, so it must not match.
        p = tmp_path / "BlockTransfer.arxml"
        p.write_text("x")
        assert is_boot_path(p, tmp_path) is False

    def test_no_match_for_drive_subtree(self, tmp_path: Path) -> None:
        p = tmp_path / "drive" / "diag" / "Dcm.arxml"
        p.parent.mkdir(parents=True)
        p.write_text("x")
        assert is_boot_path(p, tmp_path) is False


# -----------------------------------------------------------------------------
# partition_by_ecu — boot split inside one ECU
# -----------------------------------------------------------------------------

def _make_scan(root: Path, dcm: list[Path], cantp: list[Path] = (),
               dem: list[Path] = (), c_files: list[Path] = ()) -> RepoScanResult:
    cls: dict = {}
    for p in dcm:
        cls.setdefault(p, set()).add("Dcm")
    for p in cantp:
        cls.setdefault(p, set()).add("CanTp")
    for p in dem:
        cls.setdefault(p, set()).add("Dem")
    return RepoScanResult(
        root=root,
        dcm_arxmls=list(dcm),
        cantp_arxmls=list(cantp),
        dem_arxmls=list(dem),
        c_files=list(c_files),
        classifications={k: frozenset(v) for k, v in cls.items()},
    )


class TestPartitionBootSplit:
    def test_single_ecu_with_subtree_boot(self, tmp_path: Path) -> None:
        """ecu1/{app, boot}/Dcm.arxml → 1 partition with boot_dcm populated.

        The partition name is an implementation detail of the common-prefix
        stripping logic — what matters is that App and Boot were folded
        into a single ECU rather than appearing as two.
        """
        app_dcm = tmp_path / "ecu1" / "app" / "Dcm.arxml"
        boot_dcm = tmp_path / "ecu1" / "boot" / "Dcm.arxml"
        for p in (app_dcm, boot_dcm):
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text("x")
        scan = _make_scan(tmp_path, [app_dcm, boot_dcm])
        parts = partition_by_ecu(scan)
        assert len(parts) == 1
        part = parts[0]
        assert part.dcm_arxmls == [app_dcm]
        assert part.boot_dcm_arxmls == [boot_dcm]
        assert part.has_boot_group is True

    def test_redundant_mcu_four_groups(self, tmp_path: Path) -> None:
        """primary/{app,boot} + secondary/{app,boot} → 2 ECUs each with boot."""
        files = [
            tmp_path / "primary" / "app" / "Dcm.arxml",
            tmp_path / "primary" / "boot" / "Dcm.arxml",
            tmp_path / "secondary" / "app" / "Dcm.arxml",
            tmp_path / "secondary" / "boot" / "Dcm.arxml",
        ]
        for p in files:
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text("x")
        scan = _make_scan(tmp_path, files)
        parts = partition_by_ecu(scan)
        names = {p.name for p in parts}
        assert names == {"primary", "secondary"}
        for part in parts:
            assert len(part.dcm_arxmls) == 1
            assert len(part.boot_dcm_arxmls) == 1
            assert part.has_boot_group is True

    def test_sibling_boot_folds_into_app(self, tmp_path: Path) -> None:
        """Flat layout: app/Dcm.arxml + boot/Dcm.arxml → 1 ECU named 'app'."""
        app_dcm = tmp_path / "app" / "Dcm.arxml"
        boot_dcm = tmp_path / "boot" / "Dcm.arxml"
        for p in (app_dcm, boot_dcm):
            p.parent.mkdir()
            p.write_text("x")
        scan = _make_scan(tmp_path, [app_dcm, boot_dcm])
        parts = partition_by_ecu(scan)
        assert len(parts) == 1
        assert parts[0].name == "app"
        assert parts[0].dcm_arxmls == [app_dcm]
        assert parts[0].boot_dcm_arxmls == [boot_dcm]

    def test_no_boot_means_empty_boot_lists(self, tmp_path: Path) -> None:
        """Existing single-ECU repos must keep empty boot_* lists (BC check)."""
        dcm = tmp_path / "Dcm.arxml"
        dcm.write_bytes(APP_DCM.read_bytes())
        scan = _make_scan(tmp_path, [dcm])
        parts = partition_by_ecu(scan)
        assert len(parts) == 1
        assert parts[0].boot_dcm_arxmls == []
        assert parts[0].has_boot_group is False


# -----------------------------------------------------------------------------
# merge_boot_spec — domain tagging contract
# -----------------------------------------------------------------------------

class TestMergeBootSpec:
    @pytest.fixture
    def merged(self):
        app = ArxmlParser().parse(APP_DCM)
        boot = ArxmlParser().parse(BOOT_DCM)
        merge_boot_spec(app, boot)
        return app

    def test_overlap_marked_both(self, merged) -> None:
        # ProgrammingSession (0x02) exists in both fixtures.
        prog = [s for s in merged.sessions if s.session_id == 0x02]
        assert len(prog) == 1
        assert prog[0].domain == "both"

    def test_boot_only_session_appended(self, merged) -> None:
        # BootloaderSession (0x40) exists only in boot fixture.
        boot_sess = [s for s in merged.sessions if s.session_id == 0x40]
        assert len(boot_sess) == 1
        assert boot_sess[0].domain == "boot"

    def test_app_only_session_stays_drive(self, merged) -> None:
        # DefaultSession (0x01) exists only in app fixture.
        default = [s for s in merged.sessions if s.session_id == 0x01]
        assert len(default) == 1
        assert default[0].domain == "drive"

    def test_boot_only_did_appended_with_domain_boot(self, merged) -> None:
        f184 = [d for d in merged.dids if d.did_id == 0xF184]
        assert len(f184) == 1
        assert f184[0].domain == "boot"

    def test_merge_is_idempotent(self) -> None:
        # Running merge twice must not duplicate boot-only items.
        app = ArxmlParser().parse(APP_DCM)
        boot = ArxmlParser().parse(BOOT_DCM)
        merge_boot_spec(app, boot)
        sess_count = len(app.sessions)
        did_count = len(app.dids)
        boot2 = ArxmlParser().parse(BOOT_DCM)
        merge_boot_spec(app, boot2)
        assert len(app.sessions) == sess_count
        assert len(app.dids) == did_count


# -----------------------------------------------------------------------------
# load_from_repo — single-ECU end-to-end with boot subtree
# -----------------------------------------------------------------------------

class TestLoadFromRepoWithBoot:
    def test_single_ecu_with_boot_subtree(self, tmp_path: Path) -> None:
        # Mirror the fixtures into app/ and boot/ subtrees.
        (tmp_path / "app").mkdir()
        (tmp_path / "boot").mkdir()
        (tmp_path / "app" / "Dcm.arxml").write_bytes(APP_DCM.read_bytes())
        (tmp_path / "app" / "CanTp.arxml").write_bytes(APP_CANTP.read_bytes())
        (tmp_path / "app" / "Dem.arxml").write_bytes(APP_DEM.read_bytes())
        (tmp_path / "boot" / "Dcm.arxml").write_bytes(BOOT_DCM.read_bytes())

        spec, scan = load_from_repo(tmp_path)
        # Boot-only session must be present with domain="boot".
        boot_sess = [s for s in spec.sessions if s.session_id == 0x40]
        assert boot_sess, "BootloaderSession (0x40) not loaded from boot subtree"
        assert boot_sess[0].domain == "boot"
        # Overlap marked "both".
        prog = [s for s in spec.sessions if s.session_id == 0x02]
        assert prog and prog[0].domain == "both"
        # App-only stays "drive".
        default = [s for s in spec.sessions if s.session_id == 0x01]
        assert default and default[0].domain == "drive"
        # Scan still reports the boot files.
        assert any(is_boot_path(p, scan.root) for p in scan.dcm_arxmls)
