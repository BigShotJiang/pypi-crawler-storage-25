"""End-to-end ODX / PDX integration tests.

These exercise the library-integration surface area that Agent 7 owns:

* ``TexGenerator.generate_format(..., "odx" | "pdx", ...)``
* ``TexGenerator.generate_odx_dir`` / ``generate_pdx``
* CLI ``--format odx`` / ``--format pdx`` / ``--odx-supplement``
* Public re-exports from :mod:`udsxml2tex`
* The dispatcher in :mod:`udsxml2tex.odx.serializers`
* Multi-ECU ``--format pdx`` packaging

Some tests are skipped (``pytest.importorskip``) when the concurrent
agents have not landed every serializer / packager yet; once the full
integration phase finishes they all run.
"""

from __future__ import annotations

import os
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

# Skip the whole module gracefully if Agent 1's foundation is missing.
pytest.importorskip("udsxml2tex.odx")
pytest.importorskip("udsxml2tex.odx.mapper")

from udsxml2tex import ArxmlParser, CanTpParser, TexGenerator  # noqa: E402

FIXTURES_DIR = Path(__file__).parent / "fixtures"
SAMPLE_ARXML = FIXTURES_DIR / "sample_dcm.arxml"
SAMPLE_CANTP = FIXTURES_DIR / "sample_cantp.arxml"
SAMPLES_DIR = (
    Path(__file__).parent.parent / "src" / "udsxml2tex" / "samples"
)
SAMPLE_YAML = SAMPLES_DIR / "odx_supplement_sample.yaml"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _parse_sample_spec():
    """Parse the bundled fixture into a :class:`UdsSpecification`."""
    if not SAMPLE_ARXML.exists():
        pytest.skip(f"Test fixture not found: {SAMPLE_ARXML}")
    spec = ArxmlParser().parse(str(SAMPLE_ARXML))
    if SAMPLE_CANTP.exists():
        cantp = CanTpParser().parse(str(SAMPLE_CANTP))
        if cantp is not None:
            spec.cantp_config = cantp
    return spec


def _ensure_packager():
    """Skip the test cleanly if Agent 6's PDX packager is not yet present."""
    pytest.importorskip("udsxml2tex.odx.pdx_packager")


def _ensure_all_serializers():
    """Skip if any serializer is still missing — the dispatch table imports them all."""
    try:
        import udsxml2tex.odx.serializers  # noqa: F401
    except ImportError as exc:
        pytest.skip(f"Serializers not fully landed yet: {exc}")


# ---------------------------------------------------------------------------
# 1. Public re-exports
# ---------------------------------------------------------------------------


class TestPublicReexports:
    """Verify Agent 7's top-level re-exports are importable."""

    def test_import_odx_document(self):
        from udsxml2tex import OdxDocument  # noqa: F401

    def test_import_odx_category(self):
        from udsxml2tex import OdxCategory
        assert OdxCategory.DIAG_LAYER is not None

    def test_import_map_spec_to_odx(self):
        from udsxml2tex import map_spec_to_odx
        assert callable(map_spec_to_odx)

    def test_import_map_ecu_system_to_odx(self):
        from udsxml2tex import map_ecu_system_to_odx
        assert callable(map_ecu_system_to_odx)

    def test_import_load_supplement(self):
        from udsxml2tex import load_supplement
        assert callable(load_supplement)

    def test_import_empty_supplement(self):
        from udsxml2tex import empty_supplement
        sup = empty_supplement()
        assert sup is not None

    def test_all_includes_odx_names(self):
        import udsxml2tex
        for name in (
            "OdxDocument",
            "OdxCategory",
            "map_spec_to_odx",
            "map_ecu_system_to_odx",
            "load_supplement",
            "empty_supplement",
        ):
            assert name in udsxml2tex.__all__


# ---------------------------------------------------------------------------
# 2. Version bump
# ---------------------------------------------------------------------------


class TestVersionBump:

    def test_init_version_is_0_47_6(self):
        from udsxml2tex import __version__
        assert __version__ == "0.61.6"


# ---------------------------------------------------------------------------
# 3. Serializer dispatcher
# ---------------------------------------------------------------------------


class TestSerializerDispatcher:
    """Verify :func:`udsxml2tex.odx.serializers.serialize` routes by category."""

    def test_dispatcher_imports(self):
        _ensure_all_serializers()
        from udsxml2tex.odx.models_odx import OdxCategory
        from udsxml2tex.odx.serializers import _SERIALIZERS, serialize

        # Every defined category must have a serializer.
        for cat in OdxCategory:
            assert cat in _SERIALIZERS, f"Missing dispatch for {cat!r}"
        assert callable(serialize)

    def test_dispatcher_routes_each_category(self):
        _ensure_all_serializers()
        from udsxml2tex.odx.models_odx import OdxCategory
        from udsxml2tex.odx.serializers import _SERIALIZERS

        # Spot-check: every category's serializer is callable and tagged
        # with the matching name.
        expected_suffixes = {
            OdxCategory.DIAG_LAYER: "odx_d",
            OdxCategory.COMPARAM_SPEC: "odx_c",
            OdxCategory.COMPARAM_SUBSET: "odx_cs",
            OdxCategory.VEHICLE_INFO: "odx_v",
            OdxCategory.ECU_SHARED_DATA: "odx_e",
            OdxCategory.FLASH: "odx_f",
            OdxCategory.FUNCTION_DICTIONARY: "odx_fd",
            OdxCategory.MULTIPLE_ECU_JOB_SPEC: "odx_m",
        }
        for cat, suffix in expected_suffixes.items():
            fn = _SERIALIZERS[cat]
            assert callable(fn)
            assert fn.__name__ == f"serialize_{suffix}"


# ---------------------------------------------------------------------------
# 4. generate_format / generate_odx_dir / generate_pdx
# ---------------------------------------------------------------------------


class TestGenerateOdxFormat:

    def test_generate_odx_dir_writes_files(self, tmp_path):
        _ensure_packager()
        _ensure_all_serializers()
        spec = _parse_sample_spec()
        out_dir = tmp_path / "odx_out"

        result = TexGenerator().generate_format(spec, "odx", out_dir)
        assert isinstance(result, Path)
        assert result.is_dir()
        # At least the .odx-d document must exist.
        files = list(result.iterdir())
        assert files, "generate_odx_dir produced no files"
        suffixes = {f.suffix for f in files}
        assert ".odx-d" in suffixes

    def test_generate_odx_single_file(self, tmp_path):
        spec = _parse_sample_spec()
        out = tmp_path / "ecu.odx-d"
        result = TexGenerator().generate_odx(spec, out)
        assert result.exists()
        assert result.suffix == ".odx-d"
        body = result.read_bytes()
        assert body.startswith(b"<?xml")

    def test_generate_odx_appends_suffix(self, tmp_path):
        spec = _parse_sample_spec()
        out = tmp_path / "ecu"
        result = TexGenerator().generate_odx(spec, out)
        assert result.suffix == ".odx-d"


class TestGeneratePdxFormat:

    def test_generate_pdx_returns_zip(self, tmp_path):
        _ensure_packager()
        _ensure_all_serializers()
        spec = _parse_sample_spec()
        out = tmp_path / "ecu.pdx"

        result = TexGenerator().generate_format(spec, "pdx", out)
        assert isinstance(result, Path)
        assert result.exists()
        assert zipfile.is_zipfile(result)

    def test_generate_pdx_contains_index_and_diag(self, tmp_path):
        _ensure_packager()
        _ensure_all_serializers()
        spec = _parse_sample_spec()
        out = tmp_path / "ecu.pdx"
        TexGenerator().generate_pdx(spec, out)

        with zipfile.ZipFile(out) as zf:
            names = zf.namelist()
        assert any(n.lower() == "index.xml" for n in names), \
            f"index.xml missing from PDX: {names}"
        assert any(n.endswith(".odx-d") for n in names), \
            f"No .odx-d member in PDX: {names}"

    def test_generate_pdx_appends_suffix(self, tmp_path):
        _ensure_packager()
        _ensure_all_serializers()
        spec = _parse_sample_spec()
        # Caller passes no suffix; expect ".pdx" to be appended.
        out = tmp_path / "ecu"
        result = TexGenerator().generate_pdx(spec, out)
        assert result.suffix == ".pdx"
        assert result.exists()

    def test_generate_pdx_with_supplement(self, tmp_path):
        _ensure_packager()
        _ensure_all_serializers()
        if not SAMPLE_YAML.exists():
            pytest.skip(f"Sample supplement not found at {SAMPLE_YAML}")
        try:
            import yaml  # noqa: F401
        except ImportError:
            pytest.skip("PyYAML not installed; skipping supplement test")

        from udsxml2tex import load_supplement

        spec = _parse_sample_spec()
        sup = load_supplement(SAMPLE_YAML)
        out = tmp_path / "ecu.pdx"
        TexGenerator().generate_pdx(spec, out, supplement=sup)
        assert zipfile.is_zipfile(out)

        with zipfile.ZipFile(out) as zf:
            names = zf.namelist()
        # With a vehicle supplement, an ODX-V member is expected.
        assert any(n.endswith(".odx-v") for n in names), \
            f"No .odx-v member in PDX despite supplement: {names}"


class TestGenerateFormatUnknown:

    def test_unknown_format_raises(self, tmp_path):
        spec = _parse_sample_spec()
        with pytest.raises(ValueError, match="Unknown output format"):
            TexGenerator().generate_format(spec, "qqq", tmp_path / "x")


# ---------------------------------------------------------------------------
# 5. CLI invocation
# ---------------------------------------------------------------------------


class TestCliOdxPdx:

    def _cli(self, *args, cwd=None):
        env = dict(os.environ)
        # Force unbuffered logging to surface failures in the captured stderr.
        env.setdefault("PYTHONUNBUFFERED", "1")
        return subprocess.run(
            [sys.executable, "-m", "udsxml2tex", *args],
            capture_output=True,
            text=True,
            cwd=str(cwd) if cwd else None,
            env=env,
            timeout=120,
        )

    def test_cli_help_lists_odx_and_pdx(self):
        proc = self._cli("--help")
        # argparse exits 0 for --help.
        assert proc.returncode == 0
        # ``odx`` and ``pdx`` must appear among --format choices.
        assert "odx" in proc.stdout
        assert "pdx" in proc.stdout
        assert "--odx-supplement" in proc.stdout

    def test_cli_format_pdx_creates_archive(self, tmp_path):
        _ensure_packager()
        _ensure_all_serializers()
        if not SAMPLE_ARXML.exists():
            pytest.skip(f"Fixture missing: {SAMPLE_ARXML}")
        out = tmp_path / "out.pdx"
        proc = self._cli(
            str(SAMPLE_ARXML),
            "--format", "pdx",
            "-o", str(out),
        )
        assert proc.returncode == 0, (
            f"CLI failed (stdout=\n{proc.stdout}\nstderr=\n{proc.stderr})"
        )
        assert out.exists()
        assert zipfile.is_zipfile(out)

    def test_cli_format_odx_creates_directory(self, tmp_path):
        _ensure_packager()
        _ensure_all_serializers()
        if not SAMPLE_ARXML.exists():
            pytest.skip(f"Fixture missing: {SAMPLE_ARXML}")
        out_dir_base = tmp_path / "out"
        proc = self._cli(
            str(SAMPLE_ARXML),
            "--format", "odx",
            "-o", str(out_dir_base),
        )
        assert proc.returncode == 0, (
            f"CLI failed (stdout=\n{proc.stdout}\nstderr=\n{proc.stderr})"
        )
        # generate_odx_dir nests under <parent>/<stem>.
        expected = tmp_path / "out"
        assert expected.is_dir()
        assert any(p.suffix == ".odx-d" for p in expected.iterdir())

    def test_cli_with_supplement(self, tmp_path):
        _ensure_packager()
        _ensure_all_serializers()
        if not SAMPLE_ARXML.exists() or not SAMPLE_YAML.exists():
            pytest.skip("Fixture or sample supplement missing")
        try:
            import yaml  # noqa: F401
        except ImportError:
            pytest.skip("PyYAML not installed")

        out = tmp_path / "out.pdx"
        proc = self._cli(
            str(SAMPLE_ARXML),
            "--format", "pdx",
            "--odx-supplement", str(SAMPLE_YAML),
            "-o", str(out),
        )
        assert proc.returncode == 0, (
            f"CLI failed (stdout=\n{proc.stdout}\nstderr=\n{proc.stderr})"
        )
        assert out.exists()
        with zipfile.ZipFile(out) as zf:
            names = zf.namelist()
        assert any(n.endswith(".odx-v") for n in names)


# ---------------------------------------------------------------------------
# 6. Multi-ECU --format pdx
# ---------------------------------------------------------------------------


class TestMultiEcuPdx:

    def test_multi_ecu_system_pdx(self, tmp_path):
        _ensure_packager()
        _ensure_all_serializers()
        try:
            import yaml  # noqa: F401
        except ImportError:
            pytest.skip("PyYAML required for system mode")
        system_yaml = SAMPLES_DIR / "system_redundant.yaml"
        if not system_yaml.exists():
            pytest.skip(f"System sample not found: {system_yaml}")

        out_dir = tmp_path / "system_out"
        proc = subprocess.run(
            [
                sys.executable, "-m", "udsxml2tex",
                "--system", str(system_yaml),
                "--format", "pdx",
                "--system-output-dir", str(out_dir),
            ],
            capture_output=True,
            text=True,
            timeout=180,
        )
        # Some system samples may reference fixtures outside the repo —
        # in that case the CLI exits non-zero but we should not block the
        # rest of the test suite. Treat fixture-resolution failures as
        # skip rather than fail.
        if proc.returncode != 0 and "Failed to load system config" in proc.stderr:
            pytest.skip(
                "system_redundant.yaml could not be loaded in this "
                f"environment: {proc.stderr.strip()}"
            )
        assert proc.returncode == 0, (
            f"system pdx CLI failed (stdout=\n{proc.stdout}\n"
            f"stderr=\n{proc.stderr})"
        )
        sys_pdx = out_dir / "system.pdx"
        assert sys_pdx.exists()
        assert zipfile.is_zipfile(sys_pdx)
