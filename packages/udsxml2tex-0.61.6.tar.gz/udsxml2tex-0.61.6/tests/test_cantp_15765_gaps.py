"""Tests for ISO 15765-2 / CanTp coverage gap-closure.

Exercises the AUTOSAR ECUC parameters that were previously
``Unsupported`` / ``Extracted`` in ``docs/standards/iso-15765-2.md`` and
are now ``Rendered`` (or honestly ``Extracted``) after the gap-closure
work in ``cantp_parser.py``, ``models.py`` and the TeX/HTML templates.

The tests use synthetic ARXML files written to ``tmp_path`` to keep the
shared ``sample_cantp.arxml`` fixture untouched.
"""

from __future__ import annotations

from pathlib import Path
from textwrap import dedent

import pytest

from udsxml2tex import CanTpParser, TexGenerator
from udsxml2tex.models import CanTpConfig, UdsSpecification


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _write(tmp_path: Path, contents: str) -> Path:
    """Write an ARXML to a temp file and return its path."""
    path = tmp_path / "cantp_gaps.arxml"
    path.write_text(dedent(contents).lstrip(), encoding="utf-8")
    return path


# Full-fat ARXML exercising every new ECUC parameter introduced by the
# gap-closure. Channel SHORT-NAMEs identify which gap each block covers.
ARXML_ALL_NEW_PARAMS = """\
<?xml version="1.0" encoding="UTF-8"?>
<AUTOSAR xmlns="http://autosar.org/schema/r4.0">
  <AR-PACKAGES>
    <AR-PACKAGE>
      <SHORT-NAME>CanTp</SHORT-NAME>
      <ELEMENTS>
        <ECUC-MODULE-CONFIGURATION-VALUES>
          <SHORT-NAME>CanTp</SHORT-NAME>
          <CONTAINERS>

            <ECUC-CONTAINER-VALUE>
              <SHORT-NAME>CanTpGeneral</SHORT-NAME>
              <PARAMETER-VALUES>
                <ECUC-NUMERICAL-PARAM-VALUE>
                  <DEFINITION-REF>/AUTOSAR/EcuDefs/CanTp/CanTpGeneral/CanTpMainFunctionPeriod</DEFINITION-REF>
                  <VALUE>0.01</VALUE>
                </ECUC-NUMERICAL-PARAM-VALUE>
                <ECUC-TEXTUAL-PARAM-VALUE>
                  <DEFINITION-REF>/AUTOSAR/EcuDefs/CanTp/CanTpGeneral/CanTpReadParameterApi</DEFINITION-REF>
                  <VALUE>true</VALUE>
                </ECUC-TEXTUAL-PARAM-VALUE>
                <ECUC-TEXTUAL-PARAM-VALUE>
                  <DEFINITION-REF>/AUTOSAR/EcuDefs/CanTp/CanTpGeneral/CanTpDynIdSupport</DEFINITION-REF>
                  <VALUE>true</VALUE>
                </ECUC-TEXTUAL-PARAM-VALUE>
                <ECUC-TEXTUAL-PARAM-VALUE>
                  <DEFINITION-REF>/AUTOSAR/EcuDefs/CanTp/CanTpGeneral/CanTpGenericConnectionSupport</DEFINITION-REF>
                  <VALUE>true</VALUE>
                </ECUC-TEXTUAL-PARAM-VALUE>
                <ECUC-NUMERICAL-PARAM-VALUE>
                  <DEFINITION-REF>/AUTOSAR/EcuDefs/CanTp/CanTpGeneral/CanTpMaxChannelCnt</DEFINITION-REF>
                  <VALUE>16</VALUE>
                </ECUC-NUMERICAL-PARAM-VALUE>
              </PARAMETER-VALUES>
            </ECUC-CONTAINER-VALUE>

            <ECUC-CONTAINER-VALUE>
              <SHORT-NAME>CanTpChannel</SHORT-NAME>
              <SUB-CONTAINERS>
                <ECUC-CONTAINER-VALUE>
                  <SHORT-NAME>CanTpChannel_Mixed</SHORT-NAME>
                  <PARAMETER-VALUES>
                    <ECUC-TEXTUAL-PARAM-VALUE>
                      <DEFINITION-REF>/AUTOSAR/EcuDefs/CanTp/CanTpChannel/CanTpChannelMode</DEFINITION-REF>
                      <VALUE>FULL_DUPLEX</VALUE>
                    </ECUC-TEXTUAL-PARAM-VALUE>
                  </PARAMETER-VALUES>
                  <SUB-CONTAINERS>

                    <ECUC-CONTAINER-VALUE>
                      <SHORT-NAME>CanTpRxNSdu_Mixed</SHORT-NAME>
                      <PARAMETER-VALUES>
                        <ECUC-NUMERICAL-PARAM-VALUE>
                          <DEFINITION-REF>/AUTOSAR/EcuDefs/CanTp/CanTpChannel/CanTpRxNSdu/CanTpRxNSduId</DEFINITION-REF>
                          <VALUE>7</VALUE>
                        </ECUC-NUMERICAL-PARAM-VALUE>
                        <ECUC-NUMERICAL-PARAM-VALUE>
                          <DEFINITION-REF>/AUTOSAR/EcuDefs/CanTp/CanTpChannel/CanTpRxNSdu/CanTpRxWftMax</DEFINITION-REF>
                          <VALUE>4</VALUE>
                        </ECUC-NUMERICAL-PARAM-VALUE>
                        <ECUC-TEXTUAL-PARAM-VALUE>
                          <DEFINITION-REF>/AUTOSAR/EcuDefs/CanTp/CanTpChannel/CanTpRxNSdu/CanTpRxAddressingFormat</DEFINITION-REF>
                          <VALUE>MIXED</VALUE>
                        </ECUC-TEXTUAL-PARAM-VALUE>
                      </PARAMETER-VALUES>
                      <REFERENCE-VALUES>
                        <ECUC-REFERENCE-VALUE>
                          <DEFINITION-REF>/AUTOSAR/EcuDefs/CanTp/CanTpChannel/CanTpRxNSdu/CanTpRxNSduRef</DEFINITION-REF>
                          <VALUE-REF>/EcuC/Pdu/CanTpToPduR/RxMixed</VALUE-REF>
                        </ECUC-REFERENCE-VALUE>
                        <ECUC-REFERENCE-VALUE>
                          <DEFINITION-REF>/AUTOSAR/EcuDefs/CanTp/CanTpChannel/CanTpRxNSdu/CanTpRxNPduRef</DEFINITION-REF>
                          <VALUE-REF>/EcuC/Pdu/RxMixedNPdu</VALUE-REF>
                        </ECUC-REFERENCE-VALUE>
                      </REFERENCE-VALUES>
                      <SUB-CONTAINERS>

                        <!-- NAe sub-container holds NL_AE byte -->
                        <ECUC-CONTAINER-VALUE>
                          <SHORT-NAME>CanTpNAe</SHORT-NAME>
                          <PARAMETER-VALUES>
                            <ECUC-NUMERICAL-PARAM-VALUE>
                              <DEFINITION-REF>/AUTOSAR/EcuDefs/CanTp/CanTpChannel/CanTpRxNSdu/CanTpNAe/CanTpNAe</DEFINITION-REF>
                              <VALUE>0x42</VALUE>
                            </ECUC-NUMERICAL-PARAM-VALUE>
                          </PARAMETER-VALUES>
                        </ECUC-CONTAINER-VALUE>

                        <!-- Rx flow-control N-PDU sub-container -->
                        <ECUC-CONTAINER-VALUE>
                          <SHORT-NAME>CanTpRxFcNPdu</SHORT-NAME>
                          <PARAMETER-VALUES>
                            <ECUC-NUMERICAL-PARAM-VALUE>
                              <DEFINITION-REF>/AUTOSAR/EcuDefs/CanTp/CanTpChannel/CanTpRxNSdu/CanTpRxFcNPdu/CanTpRxFcNPduId</DEFINITION-REF>
                              <VALUE>33</VALUE>
                            </ECUC-NUMERICAL-PARAM-VALUE>
                          </PARAMETER-VALUES>
                          <REFERENCE-VALUES>
                            <ECUC-REFERENCE-VALUE>
                              <DEFINITION-REF>/AUTOSAR/EcuDefs/CanTp/CanTpChannel/CanTpRxNSdu/CanTpRxFcNPdu/CanTpRxFcNPduRef</DEFINITION-REF>
                              <VALUE-REF>/EcuC/Pdu/RxFcPdu</VALUE-REF>
                            </ECUC-REFERENCE-VALUE>
                          </REFERENCE-VALUES>
                        </ECUC-CONTAINER-VALUE>

                      </SUB-CONTAINERS>
                    </ECUC-CONTAINER-VALUE>

                    <ECUC-CONTAINER-VALUE>
                      <SHORT-NAME>CanTpTxNSdu_Mixed</SHORT-NAME>
                      <PARAMETER-VALUES>
                        <ECUC-NUMERICAL-PARAM-VALUE>
                          <DEFINITION-REF>/AUTOSAR/EcuDefs/CanTp/CanTpChannel/CanTpTxNSdu/CanTpTxNSduId</DEFINITION-REF>
                          <VALUE>9</VALUE>
                        </ECUC-NUMERICAL-PARAM-VALUE>
                        <ECUC-TEXTUAL-PARAM-VALUE>
                          <DEFINITION-REF>/AUTOSAR/EcuDefs/CanTp/CanTpChannel/CanTpTxNSdu/CanTpTxPaddingActivation</DEFINITION-REF>
                          <VALUE>false</VALUE>
                        </ECUC-TEXTUAL-PARAM-VALUE>
                      </PARAMETER-VALUES>
                      <REFERENCE-VALUES>
                        <ECUC-REFERENCE-VALUE>
                          <DEFINITION-REF>/AUTOSAR/EcuDefs/CanTp/CanTpChannel/CanTpTxNSdu/CanTpTxNSduRef</DEFINITION-REF>
                          <VALUE-REF>/EcuC/Pdu/CanTpToPduR/TxMixed</VALUE-REF>
                        </ECUC-REFERENCE-VALUE>
                        <ECUC-REFERENCE-VALUE>
                          <DEFINITION-REF>/AUTOSAR/EcuDefs/CanTp/CanTpChannel/CanTpTxNSdu/CanTpTxNPduRef</DEFINITION-REF>
                          <VALUE-REF>/EcuC/Pdu/TxMixedNPdu</VALUE-REF>
                        </ECUC-REFERENCE-VALUE>
                      </REFERENCE-VALUES>
                      <SUB-CONTAINERS>

                        <ECUC-CONTAINER-VALUE>
                          <SHORT-NAME>CanTpNAe</SHORT-NAME>
                          <PARAMETER-VALUES>
                            <ECUC-NUMERICAL-PARAM-VALUE>
                              <DEFINITION-REF>/AUTOSAR/EcuDefs/CanTp/CanTpChannel/CanTpTxNSdu/CanTpNAe/CanTpNAe</DEFINITION-REF>
                              <VALUE>0x55</VALUE>
                            </ECUC-NUMERICAL-PARAM-VALUE>
                          </PARAMETER-VALUES>
                        </ECUC-CONTAINER-VALUE>

                        <ECUC-CONTAINER-VALUE>
                          <SHORT-NAME>CanTpTxFcNPdu</SHORT-NAME>
                          <PARAMETER-VALUES>
                            <ECUC-NUMERICAL-PARAM-VALUE>
                              <DEFINITION-REF>/AUTOSAR/EcuDefs/CanTp/CanTpChannel/CanTpTxNSdu/CanTpTxFcNPdu/CanTpTxFcNPduConfirmationPduId</DEFINITION-REF>
                              <VALUE>77</VALUE>
                            </ECUC-NUMERICAL-PARAM-VALUE>
                          </PARAMETER-VALUES>
                          <REFERENCE-VALUES>
                            <ECUC-REFERENCE-VALUE>
                              <DEFINITION-REF>/AUTOSAR/EcuDefs/CanTp/CanTpChannel/CanTpTxNSdu/CanTpTxFcNPdu/CanTpTxFcNPduRef</DEFINITION-REF>
                              <VALUE-REF>/EcuC/Pdu/TxFcPdu</VALUE-REF>
                            </ECUC-REFERENCE-VALUE>
                          </REFERENCE-VALUES>
                        </ECUC-CONTAINER-VALUE>

                      </SUB-CONTAINERS>
                    </ECUC-CONTAINER-VALUE>

                  </SUB-CONTAINERS>
                </ECUC-CONTAINER-VALUE>
              </SUB-CONTAINERS>
            </ECUC-CONTAINER-VALUE>

          </CONTAINERS>
        </ECUC-MODULE-CONFIGURATION-VALUES>
      </ELEMENTS>
    </AR-PACKAGE>
  </AR-PACKAGES>
</AUTOSAR>
"""


# Minimal ARXML — only the bare-minimum container, none of the new ECUC
# parameters are present. Used to verify defaults survive.
ARXML_NO_NEW_PARAMS = """\
<?xml version="1.0" encoding="UTF-8"?>
<AUTOSAR xmlns="http://autosar.org/schema/r4.0">
  <AR-PACKAGES>
    <AR-PACKAGE>
      <SHORT-NAME>CanTp</SHORT-NAME>
      <ELEMENTS>
        <ECUC-MODULE-CONFIGURATION-VALUES>
          <SHORT-NAME>CanTp</SHORT-NAME>
          <CONTAINERS>
            <ECUC-CONTAINER-VALUE>
              <SHORT-NAME>CanTpGeneral</SHORT-NAME>
              <PARAMETER-VALUES>
                <ECUC-NUMERICAL-PARAM-VALUE>
                  <DEFINITION-REF>/AUTOSAR/EcuDefs/CanTp/CanTpGeneral/CanTpMainFunctionPeriod</DEFINITION-REF>
                  <VALUE>0.005</VALUE>
                </ECUC-NUMERICAL-PARAM-VALUE>
              </PARAMETER-VALUES>
            </ECUC-CONTAINER-VALUE>
            <ECUC-CONTAINER-VALUE>
              <SHORT-NAME>CanTpChannel</SHORT-NAME>
              <SUB-CONTAINERS>
                <ECUC-CONTAINER-VALUE>
                  <SHORT-NAME>CanTpChannel_Bare</SHORT-NAME>
                  <SUB-CONTAINERS>
                    <ECUC-CONTAINER-VALUE>
                      <SHORT-NAME>CanTpRxNSdu_Bare</SHORT-NAME>
                      <PARAMETER-VALUES>
                        <ECUC-NUMERICAL-PARAM-VALUE>
                          <DEFINITION-REF>/AUTOSAR/EcuDefs/CanTp/CanTpChannel/CanTpRxNSdu/CanTpBs</DEFINITION-REF>
                          <VALUE>0</VALUE>
                        </ECUC-NUMERICAL-PARAM-VALUE>
                      </PARAMETER-VALUES>
                    </ECUC-CONTAINER-VALUE>
                  </SUB-CONTAINERS>
                </ECUC-CONTAINER-VALUE>
              </SUB-CONTAINERS>
            </ECUC-CONTAINER-VALUE>
          </CONTAINERS>
        </ECUC-MODULE-CONFIGURATION-VALUES>
      </ELEMENTS>
    </AR-PACKAGE>
  </AR-PACKAGES>
</AUTOSAR>
"""


# ---------------------------------------------------------------------------
# Parser tests for newly-supported ECUC parameters
# ---------------------------------------------------------------------------


class TestCanTpGeneralGapClosure:
    """ISO 15765-2 §5 module-level switches."""

    def test_general_flags_parsed(self, tmp_path):
        path = _write(tmp_path, ARXML_ALL_NEW_PARAMS)
        config = CanTpParser().parse(path)

        assert config.read_parameter_api is True
        assert config.dyn_id_support is True
        assert config.generic_connection_support is True
        assert config.max_channel_cnt == 16

    def test_general_flags_default_when_absent(self, tmp_path):
        path = _write(tmp_path, ARXML_NO_NEW_PARAMS)
        config = CanTpParser().parse(path)

        assert config.read_parameter_api is False
        assert config.dyn_id_support is False
        assert config.generic_connection_support is False
        assert config.max_channel_cnt is None


class TestCanTpChannelGapClosure:
    """Per-channel ECUC parameters added by the gap-closure."""

    @pytest.fixture
    def config(self, tmp_path):
        path = _write(tmp_path, ARXML_ALL_NEW_PARAMS)
        return CanTpParser().parse(path)

    def test_rx_nsdu_id_and_ref(self, config):
        ch = config.channels[0]
        assert ch.rx_nsdu_id == 7
        assert ch.rx_nsdu_ref == "RxMixed"

    def test_tx_nsdu_id_and_ref(self, config):
        ch = config.channels[0]
        assert ch.tx_nsdu_id == 9
        assert ch.tx_nsdu_ref == "TxMixed"

    def test_rx_wft_max(self, config):
        ch = config.channels[0]
        assert ch.rx_wft_max == 4

    def test_rx_fc_npdu(self, config):
        ch = config.channels[0]
        assert ch.rx_fc_pdu_id == "33"
        assert ch.rx_fc_pdu_ref == "RxFcPdu"

    def test_tx_fc_npdu(self, config):
        ch = config.channels[0]
        assert ch.tx_fc_pdu_id == "77"
        assert ch.tx_fc_pdu_ref == "TxFcPdu"

    def test_rx_nae_and_tx_nae(self, config):
        ch = config.channels[0]
        assert ch.rx_nae == 0x42
        assert ch.tx_nae == 0x55

    def test_tx_padding_separate(self, config):
        ch = config.channels[0]
        # ECUC_CanTp_00269: explicit Tx padding off, regardless of Rx setting.
        assert ch.tx_padding_activation is False
        assert ch.effective_tx_padding_activation is False

    def test_defaults_when_absent(self, tmp_path):
        path = _write(tmp_path, ARXML_NO_NEW_PARAMS)
        config = CanTpParser().parse(path)
        ch = config.channels[0]

        assert ch.rx_nsdu_id is None
        assert ch.tx_nsdu_id is None
        assert ch.rx_nsdu_ref == ""
        assert ch.tx_nsdu_ref == ""
        assert ch.rx_fc_pdu_id == ""
        assert ch.tx_fc_pdu_id == ""
        assert ch.rx_nae is None
        assert ch.tx_nae is None
        assert ch.rx_wft_max is None
        assert ch.tx_padding_activation is None
        # Effective Tx padding falls back to the Rx flag.
        assert ch.effective_tx_padding_activation == ch.padding_activation


# ---------------------------------------------------------------------------
# Template smoke-tests
# ---------------------------------------------------------------------------


class TestCanTpGapTemplates:
    """Templates must render the new fields without crashing."""

    def _spec_with_new_params(self, tmp_path) -> UdsSpecification:
        path = _write(tmp_path, ARXML_ALL_NEW_PARAMS)
        config = CanTpParser().parse(path)
        spec = UdsSpecification()
        spec.transport_config = config
        return spec

    def test_tex_template_renders_new_fields(self, tmp_path):
        spec = self._spec_with_new_params(tmp_path)
        tex = TexGenerator().generate_string(spec)

        # New itemize lines + new tables
        assert "Read Parameter API" in tex
        assert "Dynamic N-PDU ID Support" in tex
        assert "Generic Connection Support" in tex
        assert "Max Channel Count" in tex
        assert "tab:cantp-npdu" in tex
        assert "tab:cantp-nsdu" in tex
        # WFTmax column header in timing table
        assert "WFTmax" in tex
        # NAe value rendered in the addressing/NSa column
        assert "{42}" in tex or "42" in tex  # 0x42 padded

    def test_html_template_renders_new_fields(self, tmp_path):
        spec = self._spec_with_new_params(tmp_path)
        out = tmp_path / "out.html"
        TexGenerator().generate_html(spec, out)
        html = out.read_text(encoding="utf-8")

        assert "Read Parameter API" in html
        assert "Dynamic N-PDU ID Support" in html
        assert "Generic Connection Support" in html
        assert "Max Channel Count" in html
        assert "N-PDU Routing" in html
        # Reference values appear in the routing table
        assert "RxMixed" in html or "TxMixed" in html
        assert "RxFcPdu" in html or "TxFcPdu" in html

    def test_tex_template_handles_absent_params(self, tmp_path):
        """Templates must not crash when new params are absent."""
        path = _write(tmp_path, ARXML_NO_NEW_PARAMS)
        config = CanTpParser().parse(path)
        spec = UdsSpecification()
        spec.transport_config = config

        tex = TexGenerator().generate_string(spec)
        # Optional flag sections must be omitted, not rendered with empty
        # values.
        assert "Read Parameter API" not in tex
        assert "Dynamic N-PDU ID Support" not in tex
        assert "Max Channel Count" not in tex
        # The Channel Overview table must still render the bare channel.
        assert "CanTpChannel_Bare" in tex or "Bare" in tex
