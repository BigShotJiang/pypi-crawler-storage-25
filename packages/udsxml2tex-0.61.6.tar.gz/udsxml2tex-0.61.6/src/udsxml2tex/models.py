"""Data models for UDS specification parsed from ARXML."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum
from typing import Optional


class SessionType(IntEnum):
    """UDS diagnostic session types."""

    DEFAULT = 0x01
    PROGRAMMING = 0x02
    EXTENDED = 0x03


@dataclass
class DiagSession:
    """Diagnostic session definition."""

    short_name: str
    session_id: int
    p2_server_max: float = 0.05  # seconds
    p2_star_server_max: float = 5.0  # seconds
    comm_ctrl_option_mask: int = 0  # DcmDspSessionCommCtrlOptionMask
    # ISO 14229-2 §9.2 — vendor / per-session ROE & service indication gates.
    # DcmDspSessionUsedForResponseOnEvent: if true the session may carry ROE
    # responses (default: false).
    used_for_response_on_event: bool = False
    # DcmDspSessionForServiceRequestIndication: if true the session triggers
    # the per-service-request indication callout to the upper layer (default:
    # false).
    for_service_request_indication: bool = False
    # Domain in which this session is supported.
    # Values: "drive" (application/drive domain only — the default), "boot"
    # (bootloader domain only), or "both" (supported in both domains). The
    # ARXML parser always emits the default "drive"; a bootloader overlay
    # (see ``udsxml2tex.boot_overlay``) may upgrade the value.
    domain: str = "drive"

    @property
    def session_id_hex(self) -> str:
        return f"0x{self.session_id:02X}"


@dataclass
class SecurityLevel:
    """Security access level definition."""

    short_name: str
    security_level: int
    num_max_attempts: int = 3
    attempt_delay: float = 0.0  # seconds – delay after failed attempts
    key_size: int = 0  # bytes
    seed_size: int = 0  # bytes
    adr_size: int = 0  # bytes – AccessDataRecord size
    num_provided_seed_attempts: int = 0  # DcmDspSecurityNumProvidedSeedAttempts
    algorithm_ref: str = ""  # DcmDspSecurityAlgorithmRef
    seed_key_increment_mode: str = ""  # DcmDspSecuritySeedAndKeyTypeIncrementMode
    delay_time_on_boot: float = 0.0  # DcmDspSecurityDelayTimeOnBoot
    attempt_counter_enabled: bool = True  # DcmDspSecurityAttemptCounterEnabled

    @property
    def security_level_hex(self) -> str:
        return f"0x{self.security_level:02X}"


@dataclass
class DataElement:
    """A data element within a DID or routine parameter."""

    short_name: str
    byte_position: int = 0
    bit_position: int = 0
    bit_size: int = 8
    description: str = ""
    data_type: str = "uint8"
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    unit: str = ""
    coding: str = ""
    endianness: str = ""  # BIG_ENDIAN, LITTLE_ENDIAN
    fixed_length: bool = True
    read_function: str = ""   # DcmDspDataReadFnc — C function called to read this element
    write_function: str = ""  # DcmDspDataWriteFnc — C function called to write this element
    global_variables: list[str] = field(default_factory=list)  # variables found by C scanner


@dataclass
class SubFunction:
    """UDS service sub-function definition."""

    short_name: str
    sub_function_id: int
    description: str = ""
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)
    suppress_pos_rsp: bool = False  # suppressPosRspMsgIndicationBit
    data_block_size: int = 0  # DcmDsdSubServiceDataBlockSize

    @property
    def sub_function_id_hex(self) -> str:
        return f"0x{self.sub_function_id:02X}"


@dataclass
class Did:
    """Data Identifier (DID) definition."""

    short_name: str
    did_id: int
    description: str = ""
    data_elements: list[DataElement] = field(default_factory=list)
    read_access: bool = True
    write_access: bool = False
    snapshot_record: bool = False
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)
    total_byte_length: int = 0
    # Domain in which this DID is supported ("drive" | "boot" | "both"). See
    # :class:`DiagSession.domain` for semantics.
    domain: str = "drive"

    @property
    def did_id_hex(self) -> str:
        return f"0x{self.did_id:04X}"


@dataclass
class RoutineParameter:
    """Parameter for a routine control service."""

    short_name: str
    direction: str = "in"  # "in", "out"
    byte_position: int = 0
    bit_size: int = 8
    description: str = ""
    data_type: str = "uint8"


@dataclass
class Routine:
    """Routine control definition."""

    short_name: str
    routine_id: int
    description: str = ""
    start_supported: bool = True
    stop_supported: bool = False
    result_supported: bool = False
    in_parameters: list[RoutineParameter] = field(default_factory=list)
    out_parameters: list[RoutineParameter] = field(default_factory=list)
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)
    max_number_of_options: int = 0  # DcmDspRoutineMaxNumberOfOptions
    access_type_required: bool = False  # DcmDspRoutineAccessTypeRequired
    start_function: Optional[str] = None   # C function name for routine start
    stop_function: Optional[str] = None    # C function name for routine stop
    result_function: Optional[str] = None  # C function name for routine result query
    global_variables: list[str] = field(default_factory=list)  # variables found by C scanner
    # Domain in which this routine is supported ("drive" | "boot" | "both").
    # See :class:`DiagSession.domain` for semantics.
    domain: str = "drive"

    @property
    def routine_id_hex(self) -> str:
        return f"0x{self.routine_id:04X}"


@dataclass
class NrcEntry:
    """Negative Response Code entry for a service."""

    nrc_code: int
    nrc_name: str
    description: str = ""

    @property
    def nrc_code_hex(self) -> str:
        return f"0x{self.nrc_code:02X}"


# Standard NRC definitions
STANDARD_NRCS: dict[int, str] = {
    0x10: "generalReject",
    0x11: "serviceNotSupported",
    0x12: "subFunctionNotSupported",
    0x13: "incorrectMessageLengthOrInvalidFormat",
    0x14: "responseTooLong",
    0x21: "busyRepeatRequest",
    0x22: "conditionsNotCorrect",
    0x24: "requestSequenceError",
    0x25: "noResponseFromSubnetComponent",
    0x26: "failurePreventsExecutionOfRequestedAction",
    0x31: "requestOutOfRange",
    0x33: "securityAccessDenied",
    0x35: "invalidKey",
    0x36: "exceededNumberOfAttempts",
    0x37: "requiredTimeDelayNotExpired",
    0x70: "uploadDownloadNotAccepted",
    0x71: "transferDataSuspended",
    0x72: "generalProgrammingFailure",
    0x73: "wrongBlockSequenceCounter",
    0x78: "requestCorrectlyReceivedResponsePending",
    0x7E: "subFunctionNotSupportedInActiveSession",
    0x7F: "serviceNotSupportedInActiveSession",
}

# NRC checking order per ISO 14229-1 for flowchart generation.
# Each entry: (nrc_code, short_question_label)
# The flowchart shows decision diamonds in this order; only NRCs
# present in the service's nrc_list are included.
NRC_CHECK_ORDER: list[tuple[int, str]] = [
    (0x11, "Service\\\\supported?"),
    (0x13, "Message length\\\\valid?"),
    (0x12, "Sub-function\\\\supported?"),
    (0x7F, "Service supported\\\\in active session?"),
    (0x7E, "Sub-function supported\\\\in active session?"),
    (0x33, "Security\\\\access granted?"),
    (0x35, "Key\\\\valid?"),
    (0x36, "Attempts\\\\not exceeded?"),
    (0x37, "Time delay\\\\expired?"),
    (0x24, "Request sequence\\\\correct?"),
    (0x22, "Conditions\\\\correct?"),
    (0x31, "Request\\\\in range?"),
    (0x70, "Upload/Download\\\\accepted?"),
    (0x71, "Transfer data\\\\not suspended?"),
    (0x72, "Programming\\\\OK?"),
    (0x73, "Block sequence\\\\correct?"),
    (0x14, "Response length\\\\OK?"),
    (0x10, "No general\\\\reject?"),
]


@dataclass
class UdsService:
    """UDS diagnostic service definition."""

    short_name: str
    service_id: int
    description: str = ""
    sub_functions: list[SubFunction] = field(default_factory=list)
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)
    nrc_list: list[NrcEntry] = field(default_factory=list)
    addressing_modes: list[str] = field(default_factory=list)  # physical, functional
    suppress_pos_rsp: bool = False  # suppressPosRspMsgIndicationBit
    request_min_length: int = 0  # DcmDsdServiceRequestMinLength
    request_max_length: int = 0  # DcmDsdServiceRequestMaxLength
    response_min_length: int = 0  # DcmDsdServiceResponseMinLength
    response_max_length: int = 0  # DcmDsdServiceResponseMaxLength
    # Domain in which this service is supported ("drive" | "boot" | "both").
    # See :class:`DiagSession.domain` for semantics.
    domain: str = "drive"

    @property
    def service_id_hex(self) -> str:
        return f"0x{self.service_id:02X}"

    @property
    def positive_response_id(self) -> int:
        return self.service_id + 0x40

    @property
    def positive_response_id_hex(self) -> str:
        return f"0x{self.positive_response_id:02X}"


# Standard UDS service names
UDS_SERVICE_NAMES: dict[int, str] = {
    0x10: "DiagnosticSessionControl",
    0x11: "ECUReset",
    0x14: "ClearDiagnosticInformation",
    0x19: "ReadDTCInformation",
    0x22: "ReadDataByIdentifier",
    0x23: "ReadMemoryByAddress",
    0x24: "ReadScalingDataByIdentifier",
    0x27: "SecurityAccess",
    0x28: "CommunicationControl",
    0x29: "Authentication",
    0x2A: "ReadDataByPeriodicIdentifier",
    0x2C: "DynamicallyDefineDataIdentifier",
    0x2E: "WriteDataByIdentifier",
    0x2F: "InputOutputControlByIdentifier",
    0x31: "RoutineControl",
    0x34: "RequestDownload",
    0x35: "RequestUpload",
    0x36: "TransferData",
    0x37: "RequestTransferExit",
    0x38: "RequestFileTransfer",
    0x3D: "WriteMemoryByAddress",
    0x3E: "TesterPresent",
    0x84: "SecuredDataTransmission",
    0x85: "ControlDTCSetting",
    0x86: "ResponseOnEvent",
    0x87: "LinkControl",
}

# ISO 14229-1 section order for UDS services
# Maps SID to its section order in the standard
ISO14229_SERVICE_ORDER: dict[int, int] = {
    0x10: 1,   # DiagnosticSessionControl (§9.2)
    0x11: 2,   # ECUReset (§9.3)
    0x27: 3,   # SecurityAccess (§9.4)
    0x28: 4,   # CommunicationControl (§9.5)
    0x29: 5,   # Authentication (§9.6)
    0x3E: 6,   # TesterPresent (§9.7)
    0x85: 7,   # ControlDTCSetting (§9.8)
    0x86: 8,   # ResponseOnEvent (§9.9)
    0x87: 9,   # LinkControl (§9.10)
    0x22: 10,  # ReadDataByIdentifier (§10.2)
    0x23: 11,  # ReadMemoryByAddress (§10.3)
    0x24: 12,  # ReadScalingDataByIdentifier (§10.4)
    0x2A: 13,  # ReadDataByPeriodicIdentifier (§10.5)
    0x2C: 14,  # DynamicallyDefineDataIdentifier (§10.6)
    0x2E: 15,  # WriteDataByIdentifier (§10.7)
    0x3D: 16,  # WriteMemoryByAddress (§10.8)
    0x14: 17,  # ClearDiagnosticInformation (§11.2)
    0x19: 18,  # ReadDTCInformation (§11.3)
    0x2F: 19,  # InputOutputControlByIdentifier (§12.2)
    0x31: 20,  # RoutineControl (§12.3)
    0x34: 21,  # RequestDownload (§13.2)
    0x35: 22,  # RequestUpload (§13.3)
    0x36: 23,  # TransferData (§13.4)
    0x37: 24,  # RequestTransferExit (§13.5)
    0x38: 25,  # RequestFileTransfer (§13.6)
    0x84: 26,  # SecuredDataTransmission (§14.2)
}


# DTC status byte bit definitions — ISO 14229-1:2020 §11.3.1
# Each entry: (bit_position, mask, short_name, description)
DTC_STATUS_BIT_DEFINITIONS: list[tuple[int, int, str, str]] = [
    (0, 0x01, "testFailed",                      "Monitor test failed in the current or last completed operation cycle"),
    (1, 0x02, "testFailedThisOperationCycle",     "Monitor test failed at least once in the current operation cycle"),
    (2, 0x04, "pendingDTC",                       "Monitor test failed in the current or previous operation cycle"),
    (3, 0x08, "confirmedDTC",                     "DTC has been confirmed (threshold reached)"),
    (4, 0x10, "testNotCompletedSinceLastClear",   "Monitor test has not run to completion since last DTC clear"),
    (5, 0x20, "testFailedSinceLastClear",         "Monitor test failed at least once since last DTC clear"),
    (6, 0x40, "testNotCompletedThisOperationCycle","Monitor test has not run to completion this operation cycle"),
    (7, 0x80, "warningIndicatorRequested",        "A warning indicator (e.g. MIL) is being requested by this DTC"),
]

# DTC severity level definitions — ISO 14229-1:2020 Annex C.3.1
# Each entry: (mask_byte, autosar_enum, description)
DTC_SEVERITY_LEVELS: list[tuple[int, str, str]] = [
    (0x20, "DEM_SEVERITY_MAINTENANCE_ONLY",   "Maintenance only — no immediate action required"),
    (0x40, "DEM_SEVERITY_CHECK_AT_NEXT_HALT", "Check at next halt — check vehicle at next workshop stop"),
    (0x80, "DEM_SEVERITY_CHECK_IMMEDIATELY",  "Check immediately — stop vehicle operation immediately"),
]

# Standard addressing modes per ISO 14229-1
# Maps SID -> list of addressing modes (physical, functional)
STANDARD_ADDRESSING_MODES: dict[int, list[str]] = {
    0x10: ["physical", "functional"],  # DiagnosticSessionControl
    0x11: ["physical", "functional"],  # ECUReset
    0x14: ["physical", "functional"],  # ClearDiagnosticInformation
    0x19: ["physical", "functional"],  # ReadDTCInformation
    0x22: ["physical", "functional"],  # ReadDataByIdentifier
    0x23: ["physical"],               # ReadMemoryByAddress
    0x24: ["physical"],               # ReadScalingDataByIdentifier
    0x27: ["physical"],               # SecurityAccess
    0x28: ["physical", "functional"],  # CommunicationControl
    0x29: ["physical"],               # Authentication
    0x2A: ["physical"],               # ReadDataByPeriodicIdentifier
    0x2C: ["physical"],               # DynamicallyDefineDataIdentifier
    0x2E: ["physical"],               # WriteDataByIdentifier
    0x2F: ["physical"],               # InputOutputControlByIdentifier
    0x31: ["physical"],               # RoutineControl
    0x34: ["physical"],               # RequestDownload
    0x35: ["physical"],               # RequestUpload
    0x36: ["physical"],               # TransferData
    0x37: ["physical"],               # RequestTransferExit
    0x38: ["physical"],               # RequestFileTransfer
    0x3D: ["physical"],               # WriteMemoryByAddress
    0x3E: ["physical", "functional"],  # TesterPresent
    0x84: ["physical"],               # SecuredDataTransmission
    0x85: ["physical", "functional"],  # ControlDTCSetting
    0x86: ["physical"],               # ResponseOnEvent
    0x87: ["physical"],               # LinkControl
}


# Standard sub-function definitions per ISO 14229-1
# Maps SID -> list of (sub_function_id, short_name)
STANDARD_SUB_FUNCTIONS: dict[int, list[tuple[int, str]]] = {
    # DiagnosticSessionControl (§9.2)
    0x10: [
        (0x01, "defaultSession"),
        (0x02, "programmingSession"),
        (0x03, "extendedDiagnosticSession"),
    ],
    # ECUReset (§9.3)
    0x11: [
        (0x01, "hardReset"),
        (0x02, "keyOffOnReset"),
        (0x03, "softReset"),
    ],
    # ReadDTCInformation (§11.3) — ISO 14229-1:2020 complete sub-function list
    0x19: [
        (0x01, "reportNumberOfDTCByStatusMask"),
        (0x02, "reportDTCByStatusMask"),
        (0x03, "reportDTCSnapshotIdentification"),
        (0x04, "reportDTCSnapshotRecordByDTCNumber"),
        (0x05, "reportDTCStoredDataByRecordNumber"),
        (0x06, "reportDTCExtDataRecordByDTCNumber"),
        (0x07, "reportNumberOfDTCBySeverityMaskRecord"),
        (0x08, "reportDTCBySeverityMaskRecord"),
        (0x09, "reportSeverityInformationOfDTC"),
        (0x0A, "reportSupportedDTC"),
        (0x0B, "reportFirstTestFailedDTC"),
        (0x0C, "reportFirstConfirmedDTC"),
        (0x0D, "reportMostRecentTestFailedDTC"),
        (0x0E, "reportMostRecentConfirmedDTC"),
        (0x14, "reportDTCFaultDetectionCounter"),
        (0x15, "reportDTCWithPermanentStatus"),
        (0x16, "reportDTCExtDataRecordByRecordNumber"),
        (0x17, "reportUserDefMemoryDTCByStatusMask"),
        (0x18, "reportUserDefMemoryDTCSnapshotRecordByDTCNumber"),
        (0x19, "reportUserDefMemoryDTCExtDataRecordByDTCNumber"),
        (0x1A, "reportSupportedDTCExtDataRecord"),
        (0x42, "reportWWHOBDDTCByMaskRecord"),
        (0x55, "reportWWHOBDDTCWithPermanentStatus"),
        (0x56, "reportDTCInformationByDTCReadinessGroupIdentifier"),
    ],
    # SecurityAccess (§9.4) — odd = requestSeed, even = sendKey
    0x27: [
        (0x01, "requestSeed (Level 1)"),
        (0x02, "sendKey (Level 1)"),
        (0x03, "requestSeed (Level 2)"),
        (0x04, "sendKey (Level 2)"),
    ],
    # CommunicationControl (§9.5)
    0x28: [
        (0x00, "enableRxAndTx"),
        (0x01, "enableRxAndDisableTx"),
        (0x02, "disableRxAndEnableTx"),
        (0x03, "disableRxAndTx"),
    ],
    # Authentication (§9.6)
    0x29: [
        (0x00, "deAuthenticate"),
        (0x01, "verifyCertificateUnidirectional"),
        (0x02, "verifyCertificateBidirectional"),
        (0x03, "proofOfOwnership"),
        (0x04, "transmitCertificate"),
        (0x05, "requestChallengeForAuthentication"),
        (0x06, "verifyProofOfOwnershipUnidirectional"),
        (0x07, "verifyProofOfOwnershipBidirectional"),
        (0x08, "authenticationConfiguration"),
    ],
    # RoutineControl (§12.3)
    0x31: [
        (0x01, "startRoutine"),
        (0x02, "stopRoutine"),
        (0x03, "requestRoutineResults"),
    ],
    # DynamicallyDefineDataIdentifier (§10.6)
    0x2C: [
        (0x01, "defineByIdentifier"),
        (0x02, "defineByMemoryAddress"),
        (0x03, "clearDynamicallyDefinedDataIdentifier"),
    ],
    # TesterPresent (§9.7)
    0x3E: [
        (0x00, "zeroSubFunction"),
    ],
    # ControlDTCSetting (§9.8)
    0x85: [
        (0x01, "on"),
        (0x02, "off"),
    ],
    # LinkControl (§9.10)
    0x87: [
        (0x01, "verifyModeTransitionWithFixedParameter"),
        (0x02, "verifyModeTransitionWithSpecificParameter"),
        (0x03, "transitionMode"),
    ],
    # ResponseOnEvent (§9.9)
    0x86: [
        (0x00, "stopResponseOnEvent"),
        (0x01, "onDTCStatusChange"),
        (0x02, "onTimerInterrupt"),
        (0x03, "onChangeOfDataIdentifier"),
        (0x04, "reportActivatedEvents"),
        (0x05, "startResponseOnEvent"),
        (0x06, "clearResponseOnEvent"),
        (0x07, "onComparisionOfValues"),
    ],
}


# UDS Request / Positive-Response message-format definitions per ISO 14229-1
# Maps SID -> (request_rows, response_rows)
# Each row: (byte_position, parameter_name, display_value, is_fixed_hex)
#   is_fixed_hex=True  -> render with \hexval (subscript-16)
#   is_fixed_hex=False -> render with \texttt (variable content)
UDS_MESSAGE_FORMATS: dict[int, tuple[list[tuple[str, str, str, bool]],
                                      list[tuple[str, str, str, bool]]]] = {
    # ---- DiagnosticSessionControl (§9.2) ----
    0x10: (
        [("#1", "Service ID (SID)", "10", True),
         ("#2", "sub-function = sessionType", "xx", False)],
        [("#1", "Response SID", "50", True),
         ("#2", "sub-function = sessionType", "xx", False),
         ("#3--#4", "P2ServerMax (high byte, low byte)", "xx xx", False),
         ("#5--#6", "P2*ServerMax / 10 (high byte, low byte)", "xx xx", False)],
    ),
    # ---- ECUReset (§9.3) ----
    0x11: (
        [("#1", "Service ID (SID)", "11", True),
         ("#2", "sub-function = resetType", "xx", False)],
        [("#1", "Response SID", "51", True),
         ("#2", "sub-function = resetType", "xx", False),
         ("#3", "powerDownTime", "xx", False)],
    ),
    # ---- ClearDiagnosticInformation (§11.2) ----
    0x14: (
        [("#1", "Service ID (SID)", "14", True),
         ("#2--#4", "groupOfDTC[]", "xx xx xx", False)],
        [("#1", "Response SID", "54", True)],
    ),
    # ---- ReadDTCInformation (§11.3) ----
    0x19: (
        [("#1", "Service ID (SID)", "19", True),
         ("#2", "sub-function = reportType", "xx", False),
         ("#3--#N", "DTC status mask / DTC number (report-type dependent)", "...", False)],
        [("#1", "Response SID", "59", True),
         ("#2", "sub-function = reportType", "xx", False),
         ("#3--#N", "data[] (report-type dependent)", "...", False)],
    ),
    # ---- ReadDataByIdentifier (§10.2) ----
    0x22: (
        [("#1", "Service ID (SID)", "22", True),
         ("#2--#3", "dataIdentifier[] (1st DID)", "xx xx", False),
         ("#4--#N", "dataIdentifier[] (additional DIDs, optional)", "...", False)],
        [("#1", "Response SID", "62", True),
         ("#2--#3", "dataIdentifier[]", "xx xx", False),
         ("#4--#N", "dataRecord[]", "...", False)],
    ),
    # ---- SecurityAccess (§9.4) ----
    0x27: (
        [("#1", "Service ID (SID)", "27", True),
         ("#2", "sub-function = securityAccessType", "xx", False),
         ("#3--#N", "securityAccessDataRecord / securityKey", "...", False)],
        [("#1", "Response SID", "67", True),
         ("#2", "sub-function = securityAccessType", "xx", False),
         ("#3--#N", "securitySeed (requestSeed response only)", "...", False)],
    ),
    # ---- CommunicationControl (§9.5) ----
    0x28: (
        [("#1", "Service ID (SID)", "28", True),
         ("#2", "sub-function = controlType", "xx", False),
         ("#3", "communicationType", "xx", False),
         ("#4--#5", "nodeIdentificationNumber (optional)", "xx xx", False)],
        [("#1", "Response SID", "68", True),
         ("#2", "sub-function = controlType", "xx", False)],
    ),
    # ---- Authentication (§9.6) ----
    0x29: (
        [("#1", "Service ID (SID)", "29", True),
         ("#2", "sub-function = authenticationTask", "xx", False),
         ("#3--#N", "authenticationParameter[]", "...", False)],
        [("#1", "Response SID", "69", True),
         ("#2", "sub-function = authenticationTask", "xx", False),
         ("#3", "authenticationReturnParameter", "xx", False),
         ("#4--#N", "authenticationParameter[]", "...", False)],
    ),
    # ---- WriteDataByIdentifier (§10.7) ----
    0x2E: (
        [("#1", "Service ID (SID)", "2E", True),
         ("#2--#3", "dataIdentifier[]", "xx xx", False),
         ("#4--#N", "dataRecord[]", "...", False)],
        [("#1", "Response SID", "6E", True),
         ("#2--#3", "dataIdentifier[]", "xx xx", False)],
    ),
    # ---- RoutineControl (§12.3) ----
    0x31: (
        [("#1", "Service ID (SID)", "31", True),
         ("#2", "sub-function = routineControlType", "xx", False),
         ("#3--#4", "routineIdentifier[]", "xx xx", False),
         ("#5--#N", "routineOptionRecord[]", "...", False)],
        [("#1", "Response SID", "71", True),
         ("#2", "sub-function = routineControlType", "xx", False),
         ("#3--#4", "routineIdentifier[]", "xx xx", False),
         ("#5--#N", "routineStatusRecord[]", "...", False)],
    ),
    # ---- RequestDownload (§13.2) ----
    0x34: (
        [("#1", "Service ID (SID)", "34", True),
         ("#2", "dataFormatIdentifier", "xx", False),
         ("#3", "addressAndLengthFormatIdentifier", "xx", False),
         ("#4--#m", "memoryAddress[]", "...", False),
         ("#(m+1)--#n", "memorySize[]", "...", False)],
        [("#1", "Response SID", "74", True),
         ("#2", "lengthFormatIdentifier", "xx", False),
         ("#3--#N", "maxNumberOfBlockLength", "...", False)],
    ),
    # ---- TransferData (§13.4) ----
    0x36: (
        [("#1", "Service ID (SID)", "36", True),
         ("#2", "blockSequenceCounter", "xx", False),
         ("#3--#N", "transferRequestParameterRecord[]", "...", False)],
        [("#1", "Response SID", "76", True),
         ("#2", "blockSequenceCounter", "xx", False),
         ("#3--#N", "transferResponseParameterRecord[]", "...", False)],
    ),
    # ---- RequestTransferExit (§13.5) ----
    0x37: (
        [("#1", "Service ID (SID)", "37", True),
         ("#2--#N", "transferRequestParameterRecord[]", "...", False)],
        [("#1", "Response SID", "77", True),
         ("#2--#N", "transferResponseParameterRecord[]", "...", False)],
    ),
    # ---- TesterPresent (§9.7) ----
    0x3E: (
        [("#1", "Service ID (SID)", "3E", True),
         ("#2", "sub-function", "xx", False)],
        [("#1", "Response SID", "7E", True),
         ("#2", "sub-function", "xx", False)],
    ),
    # ---- ControlDTCSetting (§9.8) ----
    0x85: (
        [("#1", "Service ID (SID)", "85", True),
         ("#2", "sub-function = DTCSettingType", "xx", False),
         ("#3--#N", "DTCSettingControlOptionRecord (optional)", "...", False)],
        [("#1", "Response SID", "C5", True),
         ("#2", "sub-function = DTCSettingType", "xx", False)],
    ),
    # ---- ResponseOnEvent (§9.9) ----
    0x86: (
        [("#1", "Service ID (SID)", "86", True),
         ("#2", "sub-function = eventType", "xx", False),
         ("#3", "eventWindowTime", "xx", False),
         ("#4--#N", "eventTypeRecord / serviceToRespondToRecord", "...", False)],
        [("#1", "Response SID", "C6", True),
         ("#2", "sub-function = eventType", "xx", False),
         ("#3", "numberOfIdentifiedEvents", "xx", False),
         ("#4", "eventWindowTime", "xx", False),
         ("#5--#N", "eventTypeRecord / serviceToRespondToRecord", "...", False)],
    ),
    # ---- RequestFileTransfer (§13.6) ----
    0x38: (
        [("#1", "Service ID (SID)", "38", True),
         ("#2", "modeOfOperation", "xx", False),
         ("#3--#4", "filePathAndNameLength", "xx xx", False),
         ("#5--#m", "filePathAndName[]", "...", False),
         ("#(m+1)", "dataFormatIdentifier", "xx", False),
         ("#(m+2)--#N", "fileSizeParameterLength", "...", False)],
        [("#1", "Response SID", "78", True),
         ("#2", "modeOfOperation", "xx", False),
         ("#3", "lengthFormatIdentifier", "xx", False),
         ("#4--#m", "maxNumberOfBlockLength", "...", False),
         ("#(m+1)", "dataFormatIdentifier", "xx", False),
         ("#(m+2)--#N", "fileSizeOrDirInfoParameterLength", "...", False)],
    ),
    # ---- ReadMemoryByAddress (§10.3) ----
    0x23: (
        [("#1", "Service ID (SID)", "23", True),
         ("#2", "addressAndLengthFormatIdentifier", "xx", False),
         ("#3--#m", "memoryAddress[]", "...", False),
         ("#(m+1)--#n", "memorySize[]", "...", False)],
        [("#1", "Response SID", "63", True),
         ("#2--#N", "dataRecord[]", "...", False)],
    ),
    # ---- InputOutputControlByIdentifier (§12.2) ----
    0x2F: (
        [("#1", "Service ID (SID)", "2F", True),
         ("#2--#3", "dataIdentifier[]", "xx xx", False),
         ("#4", "controlOptionRecord = controlEnableMaskRecord", "xx", False),
         ("#5--#N", "controlEnableMaskRecord[]", "...", False)],
        [("#1", "Response SID", "6F", True),
         ("#2--#3", "dataIdentifier[]", "xx xx", False),
         ("#4", "controlOptionRecord", "xx", False),
         ("#5--#N", "controlStatusRecord[]", "...", False)],
    ),
    # ---- ReadDataByPeriodicIdentifier (§10.5) ----
    0x2A: (
        [("#1", "Service ID (SID)", "2A", True),
         ("#2", "transmissionMode", "xx", False),
         ("#3--#N", "periodicDataIdentifier[]", "...", False)],
        [("#1", "Response SID", "6A", True),
         ("#2--#N", "periodicDataIdentifier + dataRecord", "...", False)],
    ),
    # ---- WriteMemoryByAddress (§10.8) ----
    0x3D: (
        [("#1", "Service ID (SID)", "3D", True),
         ("#2", "addressAndLengthFormatIdentifier", "xx", False),
         ("#3--#m", "memoryAddress[]", "...", False),
         ("#(m+1)--#n", "memorySize[]", "...", False),
         ("#(n+1)--#N", "dataRecord[]", "...", False)],
        [("#1", "Response SID", "7D", True),
         ("#2", "addressAndLengthFormatIdentifier", "xx", False),
         ("#3--#m", "memoryAddress[]", "...", False),
         ("#(m+1)--#n", "memorySize[]", "...", False)],
    ),
    # ---- RequestUpload (§13.3) ----
    0x35: (
        [("#1", "Service ID (SID)", "35", True),
         ("#2", "dataFormatIdentifier", "xx", False),
         ("#3", "addressAndLengthFormatIdentifier", "xx", False),
         ("#4--#m", "memoryAddress[]", "...", False),
         ("#(m+1)--#n", "memorySize[]", "...", False)],
        [("#1", "Response SID", "75", True),
         ("#2", "lengthFormatIdentifier", "xx", False),
         ("#3--#N", "maxNumberOfBlockLength", "...", False)],
    ),
    # ---- ReadScalingDataByIdentifier (§10.4) ----
    0x24: (
        [("#1", "Service ID (SID)", "24", True),
         ("#2--#3", "dataIdentifier[]", "xx xx", False)],
        [("#1", "Response SID", "64", True),
         ("#2--#3", "dataIdentifier[]", "xx xx", False),
         ("#4--#N", "scalingData (formulaIdentifier + scalingExtension)", "...", False)],
    ),
    # ---- DynamicallyDefineDataIdentifier (§10.6) ----
    0x2C: (
        [("#1", "Service ID (SID)", "2C", True),
         ("#2", "sub-function = definitionType", "xx", False),
         ("#3--#4", "dynamicallyDefinedDataIdentifier[]", "xx xx", False),
         ("#5--#N", "sourceDataIdentifier / memoryAddress / memorySize (definition-type dependent)", "...", False)],
        [("#1", "Response SID", "6C", True),
         ("#2", "sub-function = definitionType", "xx", False),
         ("#3--#4", "dynamicallyDefinedDataIdentifier[]", "xx xx", False)],
    ),
    # ---- SecuredDataTransmission (§14.2) ----
    0x84: (
        [("#1", "Service ID (SID)", "84", True),
         ("#2--#N", "securityDataRequestRecord[]", "...", False)],
        [("#1", "Response SID", "C4", True),
         ("#2--#N", "securityDataResponseRecord[]", "...", False)],
    ),
    # ---- LinkControl (§9.10) ----
    0x87: (
        [("#1", "Service ID (SID)", "87", True),
         ("#2", "sub-function = linkControlType", "xx", False),
         ("#3--#N", "linkBaudrateRecord[] (sub-function dependent)", "...", False)],
        [("#1", "Response SID", "C7", True),
         ("#2", "sub-function = linkControlType", "xx", False)],
    ),
}


@dataclass
class DtcExtendedDataRecord:
    """Extended data record associated with a DTC."""

    record_number: int
    short_name: str = ""
    data_size: int = 0  # bytes

    @property
    def record_number_hex(self) -> str:
        return f"0x{self.record_number:02X}"


@dataclass
class DtcSnapshotRecord:
    """Snapshot (freeze-frame) record associated with a DTC."""

    record_number: int
    short_name: str = ""
    dids: list[int] = field(default_factory=list)  # DID IDs captured in snapshot

    @property
    def record_number_hex(self) -> str:
        return f"0x{self.record_number:02X}"


@dataclass
class DtcDefinition:
    """DTC (Diagnostic Trouble Code) definition."""

    short_name: str
    dtc_id: int
    functional_unit: str = ""
    severity: str = ""
    description: str = ""
    extended_data_records: list[DtcExtendedDataRecord] = field(default_factory=list)
    snapshot_records: list[DtcSnapshotRecord] = field(default_factory=list)
    manufacturer_severity: str = ""  # DcmDspDtcManufacturerSeverity
    aging_cycle_counter_threshold: int = 0  # DcmDspDtcAgingCycleCounterThreshold
    aging_allowed: bool = True  # DcmDspDtcAgingAllowed
    priority: int = 0  # DcmDspDtcPriority
    dtc_kind: str = ""  # DcmDspDtcKind (EMISSION / NON_EMISSION)
    immediate_nv_storage: bool = False  # DcmDspDtcImmediateNvStorage
    occurrence_counter_processing: str = ""  # DcmDspDtcOccurrenceCounterProcessing

    @property
    def dtc_id_hex(self) -> str:
        return f"0x{self.dtc_id:06X}"


@dataclass
class MemoryRange:
    """Memory address range for ReadMemoryByAddress / WriteMemoryByAddress."""

    short_name: str
    start_address: int = 0
    end_address: int = 0
    read_access: bool = False
    write_access: bool = False
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)
    addressing_mode: str = ""  # DcmDspMemoryRangeAddressingMode
    memory_range_length: int = 0  # DcmDspMemoryRangeLength
    memory_id_value: int = 0  # DcmDspMemoryIdValue

    @property
    def start_address_hex(self) -> str:
        return f"0x{self.start_address:08X}"

    @property
    def end_address_hex(self) -> str:
        return f"0x{self.end_address:08X}"


@dataclass
class IoControlDid:
    """IO Control By Identifier DID definition."""

    short_name: str
    did_id: int
    control_mask_size: int = 0  # bits
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)
    return_control_to_ecu: bool = True
    reset_to_default: bool = False
    freeze_current_state: bool = False
    short_term_adjustment: bool = False
    control_option_record_size: int = 0  # DcmDspDidControlOptionRecordSize
    support_on_physical: bool = True  # DcmDspDidControlSupportOnPhysicalRequest
    support_on_functional: bool = False  # DcmDspDidControlSupportOnFunctionalRequest

    @property
    def did_id_hex(self) -> str:
        return f"0x{self.did_id:04X}"


@dataclass
class PeriodicDid:
    """Periodic Data Identifier definition."""

    short_name: str
    did_id: int
    transmission_mode: str = ""  # slowRate, mediumRate, fastRate
    supported_sessions: list[str] = field(default_factory=list)
    update_period: float = 0.0  # DcmDspPeriodicDidUpdatePeriod (ms)
    required_security_levels: list[str] = field(default_factory=list)

    @property
    def did_id_hex(self) -> str:
        return f"0x{self.did_id:04X}"


@dataclass
class ComControlSubNode:
    """Communication Control sub-node definition."""

    short_name: str
    communication_type: int = 0  # bitmask: bit0=normal, bit1=nm
    subnet_number: int = 0

    @property
    def communication_type_hex(self) -> str:
        return f"0x{self.communication_type:02X}"


@dataclass
class ComControlConfig:
    """CommunicationControl (0x28) configuration."""

    sub_nodes: list[ComControlSubNode] = field(default_factory=list)
    supported_sessions: list[str] = field(default_factory=list)
    suppressor_rx_using_mask: bool = False  # DcmDspComControlSuppressorRxUsingMask


@dataclass
class ResponseOnEventConfig:
    """ResponseOnEvent (0x86) configuration."""

    short_name: str = ""
    event_window_time: int = 0  # seconds
    store_event: bool = False
    service_to_respond_to: int = 0  # SID to trigger
    supported_sessions: list[str] = field(default_factory=list)
    event_type: str = ""  # onDTCStatusChange, onTimerInterrupt, etc.
    max_event_map_range_identifier: int = 0  # DcmDspRoeMaxEventMapRangeIdentifier
    transmission_mode: str = ""  # DcmDspRoeTransmissionMode

    @property
    def service_to_respond_to_hex(self) -> str:
        return f"0x{self.service_to_respond_to:02X}"


@dataclass
class RequestFileTransferConfig:
    """RequestFileTransfer (0x38) configuration."""

    short_name: str = ""
    max_file_path_length: int = 0
    max_file_size: int = 0
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)
    format_identifier: int = 0  # DcmDspRequestFileTransferFormatIdentifier
    data_block_size: int = 0  # DcmDspRequestFileTransferDataBlockSize
    address_length: int = 0  # DcmDspRequestFileTransferAddressLength
    length_length: int = 0  # DcmDspRequestFileTransferLengthLength


@dataclass
class ClearDtcNotification:
    """ClearDiagnosticInformation (0x14) notification configuration."""

    short_name: str = ""
    notification_class: str = ""  # e.g., DcmDspClearDTCNotificationClass


@dataclass
class DidRange:
    """DID range definition (consecutive DID block)."""

    short_name: str
    lower_did: int
    upper_did: int
    read_access: bool = True
    write_access: bool = False
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)
    has_gaps: bool = True  # DcmDspDidRangeHasGaps
    data_length: int = 0  # DcmDspDidRangeDataLength
    read_function: str = ""   # DcmDspDidRangeRead callback reference (last path segment)
    write_function: str = ""  # DcmDspDidRangeWrite callback reference (last path segment)

    @property
    def lower_did_hex(self) -> str:
        return f"0x{self.lower_did:04X}"

    @property
    def upper_did_hex(self) -> str:
        return f"0x{self.upper_did:04X}"


@dataclass
class CanTpChannel:
    """CAN Transport Protocol channel configuration (ISO 15765)."""

    short_name: str
    rx_pdu_id: str = ""
    tx_pdu_id: str = ""
    rx_addressing_format: str = "STANDARD"  # STANDARD, EXTENDED, MIXED
    tx_addressing_format: str = "STANDARD"
    bs: int = 0  # Block Size
    stmin: float = 0.0  # Separation Time minimum (ms)
    n_as: float = 0.0  # N_As timeout (s)
    n_bs: float = 0.0  # N_Bs timeout (s)
    n_cs: float = 0.0  # N_Cs timeout (s)
    n_ar: float = 0.0  # N_Ar timeout (s)
    n_br: float = 0.0  # N_Br timeout (s)
    n_cr: float = 0.0  # N_Cr timeout (s)
    padding_activation: bool = True
    padding_byte: int = 0xFF
    channel_mode: str = "FULL_DUPLEX"  # FULL_DUPLEX, HALF_DUPLEX
    max_data_length: int = 8  # 8 for classic CAN, 64 for CAN FD
    rx_ta_type: str = ""  # PHYSICAL, FUNCTIONAL
    tx_ta_type: str = ""  # PHYSICAL, FUNCTIONAL
    rx_nsa: int = 0  # Network Source Address
    rx_nta: int = 0  # Network Target Address
    tx_nsa: int = 0  # Tx Network Source Address
    tx_nta: int = 0  # Tx Network Target Address
    rx_fc_dl: int = 0  # CanTpRxFcDl (CAN-FD FC frame data length)
    tx_fc_dl: int = 0  # CanTpTxFcDl (CAN-FD FC frame data length)
    # --- ISO 15765-2 gap-closure additions ---
    rx_nsdu_id: Optional[int] = None  # ECUC_CanTp_00301 / CanTpRxNSduId
    tx_nsdu_id: Optional[int] = None  # ECUC_CanTp_00268 / CanTpTxNSduId
    rx_nsdu_ref: str = ""  # ECUC_CanTp_00241 / CanTpRxNSduRef (PduR ref last segment)
    tx_nsdu_ref: str = ""  # ECUC_CanTp_00261 / CanTpTxNSduRef
    rx_fc_pdu_id: str = ""  # ECUC_CanTp_00273 / CanTpRxFcNPduId (Rx-side FC frame id)
    rx_fc_pdu_ref: str = ""  # ECUC_CanTp_00272 / CanTpRxFcNPduRef
    tx_fc_pdu_id: str = ""  # ECUC_CanTp_00287 / CanTpTxFcNPduConfirmationPduId
    tx_fc_pdu_ref: str = ""  # ECUC_CanTp_00260 / CanTpTxFcNPduRef
    rx_nae: Optional[int] = None  # ECUC_CanTp_00285 / CanTpNAe.CanTpNAe (Rx side)
    tx_nae: Optional[int] = None  # ECUC_CanTp_00285 / CanTpNAe.CanTpNAe (Tx side)
    rx_wft_max: Optional[int] = None  # ECUC_CanTp_00251 / CanTpRxWftMax (per-RxNSdu)
    # Independent Tx padding activation per ECUC_CanTp_00269; None means "not
    # specified separately" (sender inherits padding_activation).
    tx_padding_activation: Optional[bool] = None

    @property
    def padding_byte_hex(self) -> str:
        return f"0x{self.padding_byte:02X}"

    @property
    def effective_tx_padding_activation(self) -> bool:
        """Return Tx padding setting, falling back to the global flag."""
        if self.tx_padding_activation is None:
            return self.padding_activation
        return self.tx_padding_activation


@dataclass
class CanTpConfig:
    """CAN Transport Protocol configuration parsed from CanTp ARXML."""

    channels: list[CanTpChannel] = field(default_factory=list)
    main_function_period: float = 0.005  # seconds
    can_fd_enabled: bool = False  # CanTpCanFdEnabled
    wft_max: int = 0  # CanTpWftMax
    change_parm_api: bool = False  # CanTpChangeParmApi
    tc: bool = False  # CanTpTc (transmit cancellation)
    dev_error_detect: bool = False  # CanTpDevErrorDetect
    version_info_api: bool = False  # CanTpVersionInfoApi
    padding_byte: int = 0xFF  # CanTpPaddingByte (global default)
    # --- ISO 15765-2 gap-closure additions ---
    read_parameter_api: bool = False  # ECUC_CanTp_00300 / CanTpReadParameterApi
    dyn_id_support: bool = False  # ECUC_CanTp_00302 / CanTpDynIdSupport
    generic_connection_support: bool = False  # ECUC_CanTp_00303 / CanTpGenericConnectionSupport
    max_channel_cnt: Optional[int] = None  # ECUC_CanTp_00304 / CanTpMaxChannelCnt


@dataclass
class DslConnection:
    """DSL connection (client endpoint) configuration."""

    short_name: str
    rx_pdu_id: str = ""
    tx_pdu_id: str = ""
    rx_addr: str = ""  # DcmDslConnectionRxAddr / Rx CAN ID
    tx_addr: str = ""  # DcmDslConnectionTxAddr / Tx CAN ID
    connection_mode: str = ""  # DcmDslConnectionMode (TYPE1 / TYPE2)
    end_of_connection_type: str = ""  # DcmDslConnectionDcmEndOfConnectionType
    periodic_tx_pdu_id: str = ""  # DcmDslPeriodicConnection Tx PDU
    roe_tx_pdu_id: str = ""  # DcmDslROEConnection Tx PDU
    # Connection-type discriminator. Set from the SHORT-NAME suffix of the
    # connection sub-container so callers can tell apart the three ISO 14229-2
    # §7.2 connection variants: "main" (DcmDslMainConnection,
    # request/response), "periodic" (DcmDslPeriodicConnection, ISO 14229-1
    # §10.9), "roe" (DcmDslResponseOnEventConnection / DcmDslROEConnection,
    # ISO 14229-1 §10.7) or "" if undetermined.
    connection_kind: str = ""
    # DcmDslPeriodicTxConfirmationPduId — Tx-confirmation PDU bound to the
    # periodic transmission slot (ISO 14229-1 §10.9 / SWS_Dcm DSL).
    periodic_tx_confirmation_pdu_id: str = ""


@dataclass
class ProtocolRow:
    """DcmDslProtocolRow — one protocol/client configuration."""

    short_name: str
    protocol_type: str = ""  # DCM_UDS_ON_CAN, etc.
    priority: int = 0  # DcmDslProtocolPriority (lower = higher priority)
    preempt_timeout: float = 0.0  # DcmDslProtocolPreemptTimeout (s)
    trans_type: str = ""  # DcmDslProtocolTransType (TYPE1 / TYPE2)
    max_response_length: int = 0  # DcmDslProtocolMaximumResponseLength
    connections: list[DslConnection] = field(default_factory=list)
    # DcmDslProtocolIsParallelExecutab — protocol may execute in parallel
    # with another protocol row (ISO 14229-2 §6, AUTOSAR DSL).
    parallel_executable: bool = False
    # DcmDslProtocolEndiannessConvention — response byte-order convention
    # (typically "BIG_ENDIAN" / "LITTLE_ENDIAN" / "OPAQUE").
    endianness: str = ""
    # DcmDslProtocolStackRef — reference path of the bound
    # DcmDspProtocolStackRecord container (raw VALUE-REF text or its tail).
    protocol_stack_ref: str = ""
    # DcmDslProtocolRxTesterSourceAddr / DcmDslProtocolTxTesterSourceAddr —
    # functional-addressing tester source addresses (ISO 14229-2 §7.2
    # Table 2). Stored as raw VALUE text (decimal or 0x-hex).
    rx_tester_source_addr: str = ""
    tx_tester_source_addr: str = ""


@dataclass
class DslBuffer:
    """DcmDslBuffer — one DSL buffer container (ISO 14229-2 §8.8).

    AUTOSAR allocates buffers under the global DcmDsl container; each
    buffer pairs an Rx PDU reference with a max byte size. udsxml2tex
    captures the parent container so HTML / TeX output can list the
    available buffer slots even when the per-buffer Rx-PDU-ref overrun
    behaviour is OEM-specific.
    """

    short_name: str
    # DcmDslBufferRxPduRef — reference path tail to the bound Rx PDU.
    rx_pdu_ref: str = ""
    # DcmDslBufferSize — buffer size in bytes (some OEMs encode this
    # instead of relying on the global DcmDslRxBufferSize).
    size: int = 0


@dataclass
class AuthenticationConfig:
    """Authentication service (0x29) configuration — ISO 14229-1:2020 §9.6."""

    short_name: str = ""
    role: str = ""  # DcmDspAuthenticationRole
    white_list: list[str] = field(default_factory=list)  # DcmDspAuthenticationWhiteList services
    certificate_id: str = ""  # DcmDspAuthenticationCertificateId
    psk_identity: str = ""  # DcmDspAuthenticationPSKIdentity
    num_max_attempts: int = 0  # DcmDspAuthenticationNumMaxAuthAttempts
    delay_time: float = 0.0  # DcmDspAuthenticationDelayTime (s)
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)


@dataclass
class AccessTimingRow:
    """Access Timing Parameter row — ISO 14229-2 / DcmDspTimingRow."""

    short_name: str
    p2_server_max: float = 0.05  # DcmDspTimingP2ServerMax (s)
    p2_star_server_max: float = 5.0  # DcmDspTimingP2StarServerMax (s)
    s3_server: float = 5.0  # DcmDspTimingS3Server (s)
    timing_type: str = ""  # DEFAULT, CURRENT, LIMIT


@dataclass
class UdsSpecification:
    """Complete UDS specification extracted from ARXML."""

    ecu_name: str = "ECU"
    description: str = ""
    sessions: list[DiagSession] = field(default_factory=list)
    security_levels: list[SecurityLevel] = field(default_factory=list)
    services: list[UdsService] = field(default_factory=list)
    dids: list[Did] = field(default_factory=list)
    routines: list[Routine] = field(default_factory=list)
    dtcs: list[DtcDefinition] = field(default_factory=list)
    memory_ranges: list[MemoryRange] = field(default_factory=list)
    io_control_dids: list[IoControlDid] = field(default_factory=list)
    periodic_dids: list[PeriodicDid] = field(default_factory=list)
    did_ranges: list[DidRange] = field(default_factory=list)
    com_control: Optional[ComControlConfig] = None
    response_on_event: list[ResponseOnEventConfig] = field(default_factory=list)
    dtc_status_availability_mask: int = 0xFF  # DcmDspDtcStatusAvailabilityMask
    max_num_resp_pend: int = 0  # DcmDslDiagRespMaxNumRespPend
    max_response_length: int = 0  # DcmDslProtocolMaximumResponseLength
    request_file_transfer: list[RequestFileTransferConfig] = field(default_factory=list)
    clear_dtc_notifications: list[ClearDtcNotification] = field(default_factory=list)
    protocol_name: str = "UDS on CAN"
    protocol_type: str = ""  # raw value from DcmDslProtocolType
    can_rx_id: str = ""
    can_tx_id: str = ""
    can_functional_id: str = ""
    s3_server: float = 5.0  # seconds – ISO 14229-2 S3Server timeout
    dsl_rx_buffer_size: int = 0
    dsl_tx_buffer_size: int = 0
    transport_config: Optional[CanTpConfig] = None
    connection_mode: str = ""  # DcmDslConnectionMode (ON_BOARD / OFF_BOARD)
    connection_end_of_type: str = ""  # DcmDslConnectionDcmEndOfConnectionType
    cdtc_status_mask: int = 0  # DcmDspCDTCStatusMask
    clear_dtc_group: int = 0xFFFFFF  # DcmDspClearDTCGroup
    module_main_function_period: float = 0.0  # DcmModuleMainFunctionPeriod
    enable_fim_trigger: bool = False  # DcmEnableFimTrigger
    dynamic_dids: list["DynamicDidDefinition"] = field(default_factory=list)
    protocol_priority: int = 0  # DcmDslProtocolPriority
    protocol_trans_type: str = ""  # DcmDslProtocolTransType
    protocol_preempt_timeout: float = 0.0  # DcmDslProtocolPreemptTimeout
    periodic_slow_rate: float = 0.0  # DcmDslPeriodicTransmissionSlowRate
    periodic_medium_rate: float = 0.0  # DcmDslPeriodicTransmissionMediumRate
    periodic_fast_rate: float = 0.0  # DcmDslPeriodicTransmissionFastRate
    # DcmDslDiagRespOnSecondDeclinedRequest — server behaviour on a second
    # declined request (NRC 0x22 vs. NRC 0x78 handling, ISO 14229-2 §9.2).
    # Raw VALUE text from the textual param (e.g. "true" / "false" or a
    # vendor enum). Empty string when unspecified.
    diag_resp_on_second_declined_request: str = ""
    # DcmDsdRxBufferSize — global DSD-side Rx buffer size (ISO 14229-2
    # §8.8). 0 when not declared.
    dsd_rx_buffer_size: int = 0
    # DcmDslBuffer containers (ISO 14229-2 §8.8) — list of DSL buffers.
    dsl_buffers: list["DslBuffer"] = field(default_factory=list)
    memory_compression_method: str = ""  # DcmDspMemoryCompressionMethod
    memory_encrypting_method: str = ""  # DcmDspMemoryEncryptingMethod
    dev_error_detect: bool = False  # DcmDevErrorDetect
    version_info_api: bool = False  # DcmVersionInfoApi
    task_time: float = 0.0  # DcmTaskTime
    respond_all_request: bool = True  # DcmRespondAllRequest
    # Multi-Client / Multi-Protocol (ISO 14229-1 Annex D)
    protocol_rows: list["ProtocolRow"] = field(default_factory=list)
    # Authentication (ISO 14229-1:2020 §9.6)
    authentication_config: Optional["AuthenticationConfig"] = None
    # Access Timing Parameters (ISO 14229-2)
    access_timing_rows: list["AccessTimingRow"] = field(default_factory=list)
    # DEM (Diagnostic Event Manager) configuration
    dem_general: Optional["DemGeneralConfig"] = None
    dem_operation_cycles: list["DemOperationCycle"] = field(default_factory=list)
    dem_event_parameters: list["DemEventParameter"] = field(default_factory=list)
    dem_indicators: list["DemIndicatorConfig"] = field(default_factory=list)
    dem_enable_conditions: list["DemEnableCondition"] = field(default_factory=list)
    dem_storage_conditions: list["DemStorageCondition"] = field(default_factory=list)
    dem_event_memories: list["DemEventMemoryConfig"] = field(default_factory=list)
    # DEM DTC entries extracted from DEM arxml (DemDTC containers)
    dem_dtcs: list["DemDtcEntry"] = field(default_factory=list)
    # DEM data class definitions
    dem_freeze_frame_classes: list["DemFreezeFrameClass"] = field(default_factory=list)
    dem_extended_data_classes: list["DemExtendedDataClass"] = field(default_factory=list)
    # DEM combined DTC definitions (multiple events mapped to one DTC)
    dem_combined_dtcs: list["DemCombinedDtcEntry"] = field(default_factory=list)
    # Upload / Download max block length (ISO 14229-1 §13) — DcmDspMaxBlockLength
    max_block_length: int = 0
    # LinkControl (0x87) supported baud rates — DcmDspLinkControlFixedBaudRate /
    # DcmDspLinkControlSpecificBaudRate entries
    link_control_baudrates: list["LinkControlBaudrateEntry"] = field(default_factory=list)
    # Named DTC groups for ClearDiagnosticInformation / ReadDTCInformation
    # (DcmDspGroupOfDTC containers — ISO 14229-1 §11)
    dtc_groups: list["DtcGroup"] = field(default_factory=list)
    # DoIP (ISO 13400) configuration
    doip_config: Optional["DoIpConfig"] = None
    # OBD (ISO 15031) / WWH-OBD configuration
    obd_config: Optional["ObdConfig"] = None
    # Communication ARXML (I-SIGNAL, FRAME, ECU topology)
    comm_config: Optional["CommunicationConfig"] = None
    # Adaptive Platform (AP) service interfaces
    ap_config: Optional["ApConfig"] = None

    # ---- Serialization ---------------------------------------------------

    def to_dict(self) -> dict:
        """Serialize to a plain dict (all nested dataclasses become dicts)."""
        from dataclasses import asdict as _asdict
        return _asdict(self)

    def to_json(self, indent: int = 2, ensure_ascii: bool = False) -> str:
        """Serialize to a JSON string."""
        import json as _json
        return _json.dumps(self.to_dict(), indent=indent,
                           ensure_ascii=ensure_ascii, default=str)

    def save_json(self, path: "str | Path") -> "Path":
        """Save specification to a JSON file. Returns the path written."""
        from pathlib import Path as _Path
        p = _Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(self.to_json(), encoding="utf-8")
        return p

    @classmethod
    def from_json(cls, json_str: str) -> "UdsSpecification":
        """Reconstruct a UdsSpecification from a JSON string produced by to_json()."""
        import json as _json
        from udsxml2tex._serialization import spec_from_dict as _sfd
        return _sfd(_json.loads(json_str))

    @classmethod
    def load_json(cls, path: "str | Path") -> "UdsSpecification":
        """Load a UdsSpecification from a JSON file."""
        from pathlib import Path as _Path
        return cls.from_json(_Path(path).read_text(encoding="utf-8"))

    def __or__(self, other: "UdsSpecification") -> "UdsSpecification":
        """Merge two specifications (self | other). other overrides duplicate IDs."""
        import copy
        result = copy.deepcopy(self)
        _merge_spec_inplace(result, other)
        return result


@dataclass
class DynamicDidDefinition:
    """DynamicallyDefineDataIdentifier (0x2C) definition."""

    short_name: str
    did_id: int = 0
    max_number_of_source_elements: int = 0
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)

    @property
    def did_id_hex(self) -> str:
        return f"0x{self.did_id:04X}"


# ---- DEM (Diagnostic Event Manager) models ----


@dataclass
class DemOperationCycle:
    """DEM operation cycle definition (DemOperationCycle container)."""

    short_name: str
    cycle_id: int = 0
    cycle_type: str = ""  # DEM_OPCYC_IGNITION, DEM_OPCYC_POWER, etc.
    autostart: bool = False  # DemOperationCycleAutostart
    automatic_end: bool = False  # DemOperationCycleAutomaticEnd (ECUC_Dem_00773)


@dataclass
class DemDebounceConfig:
    """DEM debounce algorithm configuration for an event."""

    algorithm: str = ""  # COUNTER_BASED, TIME_BASED, MONITOR_INTERNAL
    counter_failed_threshold: int = 127  # DemDebounceCounterFailedThreshold
    counter_passed_threshold: int = -128  # DemDebounceCounterPassedThreshold
    counter_increment_step: int = 1  # DemDebounceCounterIncrementStepSize
    counter_decrement_step: int = 1  # DemDebounceCounterDecrementStepSize
    counter_jump_up: bool = False  # DemDebounceCounterJumpUp
    counter_jump_down: bool = False  # DemDebounceCounterJumpDown
    counter_storage: bool = False  # DemDebounceCounterStorage
    time_failed_threshold: float = 0.0  # DemDebounceTimeFailedThreshold (s)
    time_passed_threshold: float = 0.0  # DemDebounceTimePassedThreshold (s)


@dataclass
class DemIndicatorConfig:
    """DEM indicator (e.g. MIL/warning lamp) configuration."""

    short_name: str
    indicator_id: int = 0  # DemIndicatorId
    behaviour: str = ""  # BLINKING, CONTINUOUS, SHORT_BUT_SLOW_FLASHING, etc.
    failure_cycle_counter_threshold: int = 0  # DemIndicatorFailureCycleCounterThreshold
    healing_cycle_counter_threshold: int = 0  # DemIndicatorHealingCycleCounterThreshold


@dataclass
class DemEnableCondition:
    """DEM enable condition definition."""

    short_name: str
    condition_id: int = 0  # DemEnableConditionId
    initial_status: bool = True  # DemEnableConditionStatus


@dataclass
class DemStorageCondition:
    """DEM storage condition definition."""

    short_name: str
    condition_id: int = 0  # DemStorageConditionId
    initial_status: bool = True  # DemStorageConditionStatus
    replacement_event_ref: str = ""  # DemStorageConditionReplacementEventRef


@dataclass
class DemEventMemoryConfig:
    """DEM event memory configuration (DemPrimaryMemory / DemUserDefinedMemory)."""

    short_name: str = "Primary"
    memory_type: str = "PRIMARY"  # PRIMARY, USER_DEFINED, MIRROR, PERMANENT
    max_number_event_entries: int = 0  # DemMaxNumberEventEntryPrimary etc.
    displacement_strategy: str = ""  # DEM_DISPLACEMENT_NONE / FULL / PRIO_OCC
    occurrence_counter_processing: str = ""  # DEM_PROCESS_OCCCTR_TF / CDTC
    event_memory_entry_storage_trigger: str = ""  # DEM_TRIGGER_ON_*
    freeze_frame_record_trigger: str = ""  # DEM_TRIGGER_ON_*
    extended_data_record_trigger: str = ""  # DEM_TRIGGER_ON_*
    type_of_freeze_frame_record_numeration: str = ""  # CALCULATED / CONFIGURED
    max_number_freeze_frame_records: int = 0  # DemMaxNumberFreezeFrameRecords


@dataclass
class DemEventParameter:
    """DEM event parameter — links an event to its DTC and configuration."""

    short_name: str
    event_id: int = 0  # DemEventId
    event_kind: str = ""  # DEM_EVENT_KIND_SWC / BSW
    confirmation_threshold: int = 1  # DemEventConfirmationThreshold
    operation_cycle_ref: str = ""  # DemOperationCycleRef (short name)
    enable_condition_group_ref: str = ""  # DemEnableConditionGroupRef
    # Individual DemEnableConditionRef entries referenced inside the enable
    # condition group container (ECUC_Dem_00614) — list of short names.
    enable_condition_refs: list[str] = field(default_factory=list)
    storage_condition_group_ref: str = ""  # DemStorageConditionGroupRef
    dtc_ref: str = ""  # DemDTCRef (short name of DemDTC)
    debounce: Optional[DemDebounceConfig] = None
    indicator_refs: list[str] = field(default_factory=list)  # DemIndicatorRef names
    recoverable_in_same_cycle: bool = True  # DemEventRecoverableInSameOperationCycle
    report_behavior: str = ""  # REPORT_BEFORE_INIT / REPORT_AFTER_INIT
    ff_prestorage_supported: bool = False  # DemFFPrestorageSupported
    # DemEventClass / DemEventClassRef — newer Dem schema reusable taxonomy
    event_class: str = ""  # DemEventClass (textual sub-element)
    event_class_ref: str = ""  # DemEventClassRef short name
    # DemEventDestination — Primary / Secondary / Mirror / Permanent
    event_destination: str = ""  # DemEventDestination (ECUC_Dem_00637)


@dataclass
class DemGeneralConfig:
    """DEM general configuration (DemGeneral container)."""

    status_bit_storage_test_failed: bool = True  # DemStatusBitStorageTestFailed
    status_bit_handling_tfslc: str = ""  # DemStatusBitHandlingTestFailedSinceLastClear
    reset_confirmed_bit_on_overflow: bool = True  # DemResetConfirmedBitOnOverflow
    operation_cycle_status_storage: bool = False  # DemOperationCycleStatusStorage
    suppression_support: bool = False  # DemSuppressionSupport
    availability_support: bool = False  # DemAvailabilitySupport
    trigger_fim_reports: bool = False  # DemTriggerFiMReports
    type_of_dtc_supported: str = ""  # DemTypeOfDTCSupported
    clear_dtc_limitation: str = ""  # DemClearDTCLimitation
    clear_dtc_behavior: str = ""  # DemClearDTCBehavior (NV vs volatile / RAM)
    # Additional general settings
    max_number_event_entry_permanent: int = 0  # DemMaxNumberEventEntryPermanent
    ob_cycle_count_threshold: int = 0  # DemObdCycleCountThreshold (OBD warm-up cycles)
    aging_requires_tested_cycle: bool = False  # DemAgingRequiresTestedCycle
    healing_requires_tested_cycle: bool = False  # DemHealingRequiresTestedCycle
    # DTC status availability mask (ISO 14229-1 §11.3.5.2.2). 0 = not configured.
    # Sourced from vendor-specific DemDtcStatusAvailabilityMask parameter
    # (when present) or derived from individual DemStatusBit* flags.
    dtc_status_availability_mask: int = 0
    # DTC severity availability mask (ISO 14229-1 §C.3.1) — DemDTCSeverityAvailabilityMask.
    dtc_severity_availability_mask: int = 0
    # DTC format identifier per ISO 14229-1 §11.3.6 — derived from DemTypeOfDTCSupported.
    # 0x00 = SAE-J2012-DA, 0x01 = ISO-14229-1, 0x02 = SAE-J1939-73,
    # 0x03 = ISO-11992-4, 0x04 = SAE-J2012-DA-Format04
    dtc_format_identifier: int = 0x01
    # DemDtcFormatType (ECUC_Dem) — declared DTC format type
    # ("UDS", "J1939", "OBD", "4-byte", etc.). Independent from the
    # derived dtc_format_identifier byte above.
    dtc_format_type: str = ""


@dataclass
class DemDtcEntry:
    """DTC definition from DEM arxml (DemDTC container) — ISO 14229-1 §11.3."""

    short_name: str
    dtc_value: int = 0  # DemDtcValue (24-bit DTC code per ISO 14229-1)
    severity: str = ""  # DemDTCAttributes/DemDTCSeverity
    kind: str = ""  # DemDTCAttributes/DemDTCKind (EMISSION / NON_EMISSION)
    functional_unit: int = 0  # DemDTCAttributes/DemDTCFunctionalUnit
    aging_cycle_ref: str = ""  # DemDTCAttributes/DemAgingCycleRef short name
    aging_cycle_counter_threshold: int = 0  # DemDTCAttributes/DemAgingCycleCounterThreshold
    aging_allowed: bool = True  # DemDTCAttributes/DemAgingAllowed
    priority: int = 0  # DemDTCAttributes/DemDTCPriority
    memory_entry_ref: str = ""  # DemDTCAttributes/DemMemoryEntryRef short name
    # OBD / WWH-OBD extensions (ISO 15031-6 / ISO 27145)
    ob_dtc_value: int = 0  # DemOBDDTCValue (2-byte OBD DTC code, 0 = not OBD)
    wwh_obd_dtc_class: str = ""  # DemWWHOBDDTCClass
    # Data class references (links to freeze-frame and extended-data definitions)
    freeze_frame_class_ref: str = ""  # DemFreezeFrameClassRef short name
    extended_data_class_ref: str = ""  # DemExtendedDataClassRef short name

    # DTC significance (ISO 14229-1 §11.3) — AUTOSAR DemDTCSignificance
    # DEM_EVENT_SIGNIFICANCE_OCCURRENCE / DEM_EVENT_SIGNIFICANCE_FAULT
    dtc_significance: str = ""

    # DemDtcFormatType (UDS / J1939 / OBD / 4-byte) — ECUC_Dem.
    dtc_format_type: str = ""

    # ---- DemDtcClass / DemDtcRefersTo / DemDtcProps (newer Dem schema) ----
    dtc_class: str = ""  # DemDtcClass (textual)
    dtc_refers_to: str = ""  # DemDtcRefersTo short name
    dtc_props: str = ""  # DemDtcProps (textual)
    # DemDtcAttributesRef — by-reference link to a shared DemDTCAttributes
    # container (in addition to the inline sub-container walk).
    dtc_attributes_ref: str = ""

    # ---- Per-DTC availability-mask overrides (ECUC_Dem_00738..00744) ----
    # Each bit is a tri-state: True = explicitly enabled, False = explicitly
    # disabled, None = parameter absent (use global derived mask).
    status_bits_test_failed: Optional[bool] = None
    status_bits_test_failed_this_op_cycle: Optional[bool] = None
    status_bits_pending_dtc: Optional[bool] = None
    status_bits_confirmed_dtc: Optional[bool] = None
    status_bits_test_not_completed_since_last_clear: Optional[bool] = None
    status_bits_test_failed_since_last_clear: Optional[bool] = None
    status_bits_test_not_completed_this_op_cycle: Optional[bool] = None
    status_bits_warning_indicator_requested: Optional[bool] = None

    # DemDTCSetting (per-DTC enable/disable group) — short name of the
    # DemDTCSetting container that links this DTC into one or more
    # enable-condition groups for ControlDTCSetting (SID 0x85).
    dtc_setting_group: str = ""

    @property
    def dtc_value_hex(self) -> str:
        return f"0x{self.dtc_value:06X}"

    def status_availability_mask_override(self, base_mask: int) -> int:
        """Apply per-DTC ``DemDtcStatusBits*`` overrides to *base_mask*.

        Bits are set/cleared based on each ``status_bits_*`` field; ``None``
        leaves the corresponding bit unchanged from the base mask.
        """
        bit_map = [
            (0x01, self.status_bits_test_failed),
            (0x02, self.status_bits_test_failed_this_op_cycle),
            (0x04, self.status_bits_pending_dtc),
            (0x08, self.status_bits_confirmed_dtc),
            (0x10, self.status_bits_test_not_completed_since_last_clear),
            (0x20, self.status_bits_test_failed_since_last_clear),
            (0x40, self.status_bits_test_not_completed_this_op_cycle),
            (0x80, self.status_bits_warning_indicator_requested),
        ]
        mask = base_mask & 0xFF
        for bit, val in bit_map:
            if val is True:
                mask |= bit
            elif val is False:
                mask &= ~bit & 0xFF
        return mask

    @property
    def has_status_bits_override(self) -> bool:
        """True if any ``DemDtcStatusBits*`` per-DTC override is set."""
        return any(
            v is not None
            for v in (
                self.status_bits_test_failed,
                self.status_bits_test_failed_this_op_cycle,
                self.status_bits_pending_dtc,
                self.status_bits_confirmed_dtc,
                self.status_bits_test_not_completed_since_last_clear,
                self.status_bits_test_failed_since_last_clear,
                self.status_bits_test_not_completed_this_op_cycle,
                self.status_bits_warning_indicator_requested,
            )
        )

    @property
    def severity_bits_hex(self) -> str:
        """Map DemDTCSeverity enum to ISO 14229-1 §C.3.1 byte value."""
        mapping = {
            "DEM_SEVERITY_NO_SEVERITY": "0x00",
            "DEM_SEVERITY_MAINTENANCE_ONLY": "0x20",
            "DEM_SEVERITY_CHECK_AT_NEXT_HALT": "0x40",
            "DEM_SEVERITY_CHECK_IMMEDIATELY": "0x80",
        }
        return mapping.get(self.severity, "---")


@dataclass
class LinkControlBaudrateEntry:
    """Supported baud rate entry for LinkControl (0x87) — ISO 14229-1 §9.10."""

    short_name: str
    baudrate_type: str = "FIXED"  # FIXED or SPECIFIC
    baudrate_value: int = 0  # DcmDspLinkControlFixedBaudRateRecord / SpecBaudrateRecord

    @property
    def baudrate_kbps(self) -> str:
        if self.baudrate_value == 0:
            return "---"
        return f"{self.baudrate_value / 1000:.0f}" if self.baudrate_value >= 1000 else str(self.baudrate_value)


@dataclass
class DtcGroup:
    """Named DTC group for ClearDiagnosticInformation / ReadDTCInformation — ISO 14229-1 §11."""

    short_name: str
    group_value: int = 0xFFFFFF  # DcmDspGroupOfDTCIdentifier

    @property
    def group_value_hex(self) -> str:
        return f"0x{self.group_value:06X}"


@dataclass
class DemCombinedDtcEntry:
    """Combined DTC definition from DEM ARXML (DemCombinedDTC container)."""

    short_name: str
    combined_dtc_value: int = 0  # DemCombinedDTCNumber (UDS DTC value)
    dtc_class_refs: list[str] = field(default_factory=list)  # referenced DemDTC short names
    event_refs: list[str] = field(default_factory=list)  # related event short names

    @property
    def combined_dtc_value_hex(self) -> str:
        return f"0x{self.combined_dtc_value:06X}"


@dataclass
class DemFreezeFrameClass:
    """Freeze frame class definition (DemFreezeFrameClass container) — ISO 14229-1 §11.3.3."""

    short_name: str
    did_refs: list[str] = field(default_factory=list)  # DID short names captured in FF
    # DemFreezeFrameCapture — CAPTURE_SYNCHRONOUS / CAPTURE_ASYNCHRONOUS_TO_REPORTING
    capture: str = ""  # ECUC_Dem_00772
    # DemFreezeFrameRecNumClass — record-number assignment class
    rec_num_class: str = ""  # ECUC_Dem_00723


@dataclass
class DemDataElement:
    """Individual data element inside a DemExtendedDataClass / DemDidClass.

    Models DemDataElementClass (ECUC_Dem_00685) — the per-element layout
    (byte position, data type, semantic) of an extended-data record or DID
    capture group.
    """

    short_name: str
    data_size: int = 0  # DemDataElementDataSize (bytes)
    data_type: str = ""  # DemDataElementDataType (UINT8, SINT16, ...)
    semantic: str = ""  # DemDataElementSemantic (e.g. AGING_COUNTER)
    update_indication_bit_position: int = -1  # DemDataElementUpdateIndicationBitPosition


@dataclass
class DemExtendedDataClass:
    """Extended data record class (DemExtendedDataClass) — ISO 14229-1 §11.3.4."""

    short_name: str
    record_number: int = 0  # DemExtendedDataRecordNumber (1-0xEF per ISO 14229-1)
    data_size: int = 0  # DemExtendedDataRecordSize (bytes)
    update_trigger: str = ""  # DEM_TRIGGER_ON_*
    # DemExtendedDataRecordClass (ECUC_Dem_00684) — record-class taxonomy
    # (e.g. STANDARD / EXTENDED, vendor-specific class name).
    record_class: str = ""
    # Individual DemDataElementClass entries inside the extended data record.
    data_elements: list[DemDataElement] = field(default_factory=list)

    @property
    def record_number_hex(self) -> str:
        return f"0x{self.record_number:02X}"


# ---------------------------------------------------------------------------
# DoIP (ISO 13400) models
# ---------------------------------------------------------------------------

@dataclass
class DoIpLogicalAddress:
    """Logical address entry in a DoIP configuration."""

    short_name: str
    address: int = 0
    ecu_ref: str = ""

    @property
    def address_hex(self) -> str:
        return f"0x{self.address:04X}"


@dataclass
class DoIpRoutingActivation:
    """Routing activation entry in a DoIP configuration."""

    short_name: str
    activation_number: int = 0
    activation_type: str = ""

    @property
    def activation_number_hex(self) -> str:
        return f"0x{self.activation_number:02X}"


@dataclass
class DoIpConfig:
    """DoIP (ISO 13400) configuration — diagnostics over IP."""

    short_name: str = ""
    vehicle_identification_response_time: float = 0.0  # seconds
    initial_vehicle_announcement_time: float = 0.0
    vehicle_announcement_interval: float = 0.0
    vehicle_announcement_count: int = 0
    max_udp_request_per_message: int = 1
    max_tcp_payload_len: int = 0
    eid: str = ""  # Entity ID (6-byte hex)
    gid: str = ""  # Group ID (6-byte hex)
    vins: list[str] = field(default_factory=list)
    activation_type: str = ""
    logical_addresses: list[DoIpLogicalAddress] = field(default_factory=list)
    routing_activations: list[DoIpRoutingActivation] = field(default_factory=list)


# ---------------------------------------------------------------------------
# OBD (ISO 15031 / ISO 27145 WWH-OBD) models
# ---------------------------------------------------------------------------

@dataclass
class ObdPid:
    """OBD PID (Parameter ID) definition."""

    short_name: str
    mode: int = 1       # OBD mode 01..09
    pid: int = 0        # PID number
    description: str = ""
    formula: str = ""
    unit: str = ""
    min_value: float = 0.0
    max_value: float = 0.0
    byte_size: int = 1

    @property
    def pid_hex(self) -> str:
        return f"0x{self.pid:02X}"

    @property
    def mode_str(self) -> str:
        return f"Mode 0{self.mode:X}"


@dataclass
class ObdConfig:
    """OBD / WWH-OBD configuration."""

    pids: list[ObdPid] = field(default_factory=list)
    supported_modes: list[int] = field(default_factory=list)
    wwh_obd_enabled: bool = False
    obd_mid_count: int = 0
    obd_dtc_availability_mask: int = 0


# OBD standard PID descriptions (mode, pid) → name
OBD_STANDARD_PIDS: dict[tuple[int, int], str] = {
    (1, 0x00): "PIDs supported [01-20]",
    (1, 0x01): "Monitor status since DTCs cleared",
    (1, 0x04): "Calculated engine load",
    (1, 0x05): "Engine coolant temperature",
    (1, 0x0C): "Engine speed",
    (1, 0x0D): "Vehicle speed",
    (1, 0x1C): "OBD standards this vehicle conforms to",
    (2, 0x02): "DTC that caused freeze frame",
    (3, 0x00): "Fuel system status",
    (9, 0x02): "Vehicle Identification Number (VIN)",
}


# ---------------------------------------------------------------------------
# Communication ARXML (ISO 11898 / AUTOSAR COM) models
# ---------------------------------------------------------------------------

@dataclass
class FrameSignal:
    """Signal mapping within a frame or PDU."""

    signal_ref: str = ""   # I-SIGNAL SHORT-NAME
    start_bit: int = 0
    bit_length: int = 0
    update_bit: int = -1   # -1 = no update bit


@dataclass
class ISignal:
    """AUTOSAR I-SIGNAL definition."""

    short_name: str
    length: int = 0        # bits
    start_bit: int = 0
    byte_order: str = "MOST-SIGNIFICANT-BYTE-FIRST"
    init_value: Optional[float] = None
    data_type: str = ""


@dataclass
class Frame:
    """CAN/LIN/FlexRay frame definition."""

    short_name: str
    frame_length: int = 0  # bytes
    signals: list[FrameSignal] = field(default_factory=list)

    @property
    def frame_length_bits(self) -> int:
        return self.frame_length * 8


@dataclass
class Pdu:
    """PDU (Protocol Data Unit) definition."""

    short_name: str
    pdu_type: str = ""     # I-PDU, N-PDU, etc.
    length: int = 0        # bytes
    signals: list[FrameSignal] = field(default_factory=list)


@dataclass
class EcuInstance:
    """ECU instance in the system description."""

    short_name: str
    category: str = ""
    connectors: list[str] = field(default_factory=list)
    comm_controllers: list[str] = field(default_factory=list)


@dataclass
class NetworkTopology:
    """Communication cluster / network topology."""

    short_name: str
    cluster_name: str = ""
    baudrate: int = 0
    channel_name: str = ""
    protocol: str = "CAN"  # CAN, LIN, FlexRay, Ethernet
    ecus: list[str] = field(default_factory=list)


@dataclass
class CommunicationConfig:
    """Communication ARXML configuration — frames, PDUs, signals, topology."""

    frames: list[Frame] = field(default_factory=list)
    pdus: list[Pdu] = field(default_factory=list)
    isignals: list[ISignal] = field(default_factory=list)
    ecu_instances: list[EcuInstance] = field(default_factory=list)
    networks: list[NetworkTopology] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Adaptive Platform (AUTOSAR AP) models
# ---------------------------------------------------------------------------

@dataclass
class ApMethod:
    """AUTOSAR AP service interface method."""

    short_name: str
    method_type: str = ""   # FIRE-AND-FORGET, REQUEST-RESPONSE
    input_params: list[str] = field(default_factory=list)
    return_params: list[str] = field(default_factory=list)


@dataclass
class ApEvent:
    """AUTOSAR AP service interface event."""

    short_name: str
    event_type: str = ""
    data_type_ref: str = ""


@dataclass
class ApField:
    """AUTOSAR AP service interface field."""

    short_name: str
    data_type_ref: str = ""
    getter: bool = True
    setter: bool = False
    notifier: bool = False


@dataclass
class ApServiceInterface:
    """AUTOSAR Adaptive Platform service interface definition."""

    short_name: str
    namespace: str = ""
    version: str = ""
    category: str = ""
    methods: list[ApMethod] = field(default_factory=list)
    events: list[ApEvent] = field(default_factory=list)
    fields: list[ApField] = field(default_factory=list)


@dataclass
class ApDiagnosticService:
    """AP diagnostic service instance (maps to UDS service)."""

    short_name: str
    uds_service_ref: str = ""
    diag_event_refs: list[str] = field(default_factory=list)


@dataclass
class ApConfig:
    """AUTOSAR Adaptive Platform configuration."""

    service_interfaces: list[ApServiceInterface] = field(default_factory=list)
    diag_services: list[ApDiagnosticService] = field(default_factory=list)
    ap_version: str = "R19-11"  # Detected AP schema version


# ---------------------------------------------------------------------------
# Merge helper (used by UdsSpecification.__or__)
# ---------------------------------------------------------------------------

def _promote_domain(a: str, b: str) -> str:
    """Combine two domain markers.

    Returns ``"both"`` whenever the two markers disagree (e.g. one side is
    ``"drive"`` and the other ``"boot"``), because the item is then known to
    apply to both domains. If the markers are equal, that value is returned;
    if either side is already ``"both"`` the result is also ``"both"``.

    Unknown / empty markers are treated as ``"drive"``.
    """
    valid = {"drive", "boot", "both"}
    av = a if a in valid else "drive"
    bv = b if b in valid else "drive"
    if av == bv:
        return av
    if av == "both" or bv == "both":
        return "both"
    return "both"


def _merge_spec_inplace(target: UdsSpecification, source: UdsSpecification) -> None:
    """Merge *source* into *target* in-place. source overrides duplicate IDs.

    For items carrying a ``domain`` field (sessions, services, DIDs, routines),
    the merged entry's ``domain`` is promoted via :func:`_promote_domain` so
    that conflicting markers (``"drive"`` vs ``"boot"``) become ``"both"`` —
    this preserves cross-domain coverage when application- and bootloader-side
    specs are merged.
    """

    def _merge_by(lst_t: list, lst_s: list, key: str) -> None:
        idx = {getattr(x, key): i for i, x in enumerate(lst_t)}
        for item in lst_s:
            k = getattr(item, key)
            if k in idx:
                existing = lst_t[idx[k]]
                # Combine domain markers across the merge boundary so the
                # promoted entry represents both source and target coverage.
                if hasattr(existing, "domain") and hasattr(item, "domain"):
                    item.domain = _promote_domain(existing.domain, item.domain)
                lst_t[idx[k]] = item
            else:
                idx[k] = len(lst_t)
                lst_t.append(item)

    _merge_by(target.sessions, source.sessions, "session_id")
    _merge_by(target.security_levels, source.security_levels, "security_level")
    _merge_by(target.services, source.services, "service_id")
    _merge_by(target.dids, source.dids, "did_id")
    _merge_by(target.routines, source.routines, "routine_id")
    _merge_by(target.dtcs, source.dtcs, "dtc_id")

    for attr in (
        "memory_ranges", "io_control_dids", "periodic_dids", "did_ranges",
        "response_on_event", "request_file_transfer", "clear_dtc_notifications",
        "protocol_rows", "access_timing_rows", "dynamic_dids",
        "link_control_baudrates", "dtc_groups",
        "dem_operation_cycles", "dem_event_parameters", "dem_indicators",
        "dem_enable_conditions", "dem_storage_conditions", "dem_event_memories",
        "dem_dtcs", "dem_freeze_frame_classes", "dem_extended_data_classes",
        "dem_combined_dtcs",
    ):
        getattr(target, attr).extend(getattr(source, attr))

    if source.transport_config is not None:
        target.transport_config = source.transport_config
    if source.com_control is not None:
        target.com_control = source.com_control
    if source.authentication_config is not None:
        target.authentication_config = source.authentication_config
    if source.dem_general is not None:
        target.dem_general = source.dem_general
    if source.doip_config is not None:
        target.doip_config = source.doip_config
    if source.obd_config is not None:
        target.obd_config = source.obd_config
    if source.comm_config is not None:
        target.comm_config = source.comm_config
    if source.ap_config is not None:
        target.ap_config = source.ap_config
    for attr in ("can_rx_id", "can_tx_id", "can_functional_id",
                 "protocol_name", "protocol_type", "description"):
        src_val = getattr(source, attr)
        if src_val:
            setattr(target, attr, src_val)
    if source.ecu_name and source.ecu_name != "ECU":
        target.ecu_name = source.ecu_name
    if source.max_block_length:
        target.max_block_length = source.max_block_length
