"""Requirements Traceability Matrix (RTM) support.

Implements the ASPICE SYS.2.BP4 / SWE.1.BP6 and ISO 26262-8 §6.4.5
"bidirectional traceability" concept for udsxml2tex: a DOORS-style
CSV table where each row maps a requirement onto one or more
implementation elements of the parsed ARXML (UDS service, DID, RID,
DTC, session, security level). At generation time the matrix is
joined with the spec and rendered as a dedicated chapter in the
LaTeX/PDF / HTML / Markdown output.

CSV columns (header row required, case-insensitive):

    req_id        — mandatory; unique requirement identifier
    description   — mandatory; requirement text
    source_ref    — mandatory; bibkey from rtm_sources.yaml (or
                    a free-text reference if no sources YAML is
                    provided)
    traces_to     — mandatory; semicolon-separated implementation
                    references, each in one of these forms:
                        sid:0x10            (service)
                        sid:0x10:0x03       (service + sub-function)
                        did:0xF187          (data identifier)
                        rid:0x0203          (routine identifier)
                        dtc:0x010000        (diagnostic trouble code)
                        session:0x03        (diagnostic session)
                        security:0x01       (security level)
    verified_by   — optional; test-case ID or document section
    status        — optional; one of "verified" / "accepted" /
                    "conditionally_accepted" / "rejected" /
                    "in_progress" / "not_yet" / "na"
                    (default: "not_yet"). ``accepted`` is a semantic
                    alias for ``verified`` and is the explicit
                    Accept-state for OEM requirements ingested into
                    a supplier-side spec. ``conditionally_accepted``
                    means "Accepted with conditions" — the OEM
                    requirement is in scope but the supplier-side
                    implementation deviates in some respect that the
                    HTML/PDF spec should call out. ``rejected`` means
                    "OEM requirement explicitly out of scope"; an
                    ARXML element matching a rejected req is a
                    compliance failure.

Sources YAML schema (list of dicts):

    - bibkey:    iso14229-1
      title:     ISO 14229-1:2020 ...
      publisher: ISO
      year:      2020
"""

from __future__ import annotations

import csv
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Optional


# ---------------------------------------------------------------------------
# Named-element catalogue used by condition_warnings() to resolve human
# language references like "ProgrammingSession" / "ECUReset" inside the
# Conditionally-Accepted Comment column. Each entry maps a name pattern
# (case-insensitive, matched as a whole word) onto the canonical
# (kind, hex_id) pair. Kept here so the dictionary is the single source
# of truth — both the regex builder and the warning renderer read it.
# ---------------------------------------------------------------------------

CONDITION_KEYWORDS: list[tuple[str, str, str]] = [
    # ---- Diagnostic sessions (ISO 14229-1 §10.2) -------------------------
    ("DefaultSession",                 "session",  "0x01"),
    ("default session",                "session",  "0x01"),
    ("ProgrammingSession",             "session",  "0x02"),
    ("programming session",            "session",  "0x02"),
    ("ExtendedDiagnosticSession",      "session",  "0x03"),
    ("extended diagnostic session",    "session",  "0x03"),
    ("ExtendedSession",                "session",  "0x03"),
    ("extended session",               "session",  "0x03"),
    ("SafetySystemDiagnosticSession",  "session",  "0x04"),
    ("safety system diagnostic session", "session", "0x04"),
    # ---- Application-layer services (ISO 14229-1 catalogue) --------------
    ("DiagnosticSessionControl",       "sid",  "0x10"),
    ("ECUReset",                       "sid",  "0x11"),
    ("ClearDiagnosticInformation",     "sid",  "0x14"),
    ("ReadDTCInformation",             "sid",  "0x19"),
    ("ReadDataByIdentifier",           "sid",  "0x22"),
    ("ReadMemoryByAddress",            "sid",  "0x23"),
    ("ReadScalingDataByIdentifier",    "sid",  "0x24"),
    ("SecurityAccess",                 "sid",  "0x27"),
    ("CommunicationControl",           "sid",  "0x28"),
    ("Authentication",                 "sid",  "0x29"),
    ("ReadDataByPeriodicIdentifier",   "sid",  "0x2A"),
    ("DynamicallyDefineDataIdentifier", "sid", "0x2C"),
    ("WriteDataByIdentifier",          "sid",  "0x2E"),
    ("InputOutputControlByIdentifier", "sid",  "0x2F"),
    ("RoutineControl",                 "sid",  "0x31"),
    ("RequestDownload",                "sid",  "0x34"),
    ("RequestUpload",                  "sid",  "0x35"),
    ("TransferData",                   "sid",  "0x36"),
    ("RequestTransferExit",            "sid",  "0x37"),
    ("RequestFileTransfer",            "sid",  "0x38"),
    ("WriteMemoryByAddress",           "sid",  "0x3D"),
    ("TesterPresent",                  "sid",  "0x3E"),
    ("AccessTimingParameter",          "sid",  "0x83"),
    ("SecuredDataTransmission",        "sid",  "0x84"),
    ("ControlDTCSetting",              "sid",  "0x85"),
    ("ResponseOnEvent",                "sid",  "0x86"),
    ("LinkControl",                    "sid",  "0x87"),
]


# Numeric-threshold patterns surfaced as informational notes — these are
# the OEM-mentioned values the user must compare against the parsed
# ARXML. Each entry is (label, regex, unit). Matches are listed under a
# separate "Numeric thresholds in OEM comment" line in the rendered
# warning block — they are notes, not failures, so the user can
# eyeball-check them against the live config table.
CONDITION_NUMERIC_PATTERNS: list[tuple[str, "re.Pattern[str]", str]] = [
    ("BS",            re.compile(r"\bBS\s*=\s*(\d+)\b", re.IGNORECASE),       "frames"),
    ("STmin",         re.compile(r"\bST\s*min\s*=\s*(\d+)\s*ms\b", re.IGNORECASE), "ms"),
    ("P2_Server_max", re.compile(r"\bP2(?:_Server)?_?max\s*[=:<>≤]?\s*(\d+)\s*ms\b",
                                   re.IGNORECASE), "ms"),
    ("P2*_Server_max", re.compile(r"\bP2\*(?:_Server)?_?max\s*[=:<>≤]?\s*(\d+)\s*ms\b",
                                    re.IGNORECASE), "ms"),
    ("S3_Server",     re.compile(r"\bS3(?:_Server)?\s*[=:<>≤]?\s*(\d+)\s*s\b",
                                   re.IGNORECASE), "s"),
    ("N_As",          re.compile(r"\bN_?As\s*[=:<>≤]?\s*(\d+)\s*ms\b", re.IGNORECASE), "ms"),
    ("N_Bs",          re.compile(r"\bN_?Bs\s*[=:<>≤]?\s*(\d+)\s*ms\b", re.IGNORECASE), "ms"),
    ("N_Cs",          re.compile(r"\bN_?Cs\s*[=:<>≤]?\s*(\d+)\s*ms\b", re.IGNORECASE), "ms"),
]


def _condition_keyword_pattern() -> "re.Pattern[str]":
    """Compile the CONDITION_KEYWORDS dictionary into one regex.

    Sorted longest-first so "ExtendedDiagnosticSession" wins over
    "ExtendedSession" when both could match the same span. Built once
    at import time; the regex is read-only.
    """
    names = sorted({k for k, _, _ in CONDITION_KEYWORDS},
                    key=len, reverse=True)
    return re.compile(
        r"(?<![A-Za-z0-9_])(" + "|".join(re.escape(n) for n in names)
        + r")(?![A-Za-z0-9_])",
        re.IGNORECASE,
    )


_CONDITION_KEYWORD_RE = _condition_keyword_pattern()
_CONDITION_KEYWORD_LOOKUP: dict[str, tuple[str, str]] = {
    k.lower(): (kind, hex_id) for k, kind, hex_id in CONDITION_KEYWORDS
}


@dataclass
class RtmTrace:
    """One implementation-element reference parsed from `traces_to`.

    `resolved` and `resolved_name` are populated by :func:`match_to_spec`
    and reflect whether the trace points at a real element parsed from
    the ARXML, and that element's short_name (when found). Both are part
    of the bidirectional-traceability contract: a row marked "accepted"
    whose trace stays `resolved=False` is a broken trace and is flagged
    in the rendered PDF.
    """

    kind: str  # one of: sid, did, rid, dtc, session, security
    primary: str  # hex string e.g. "0x10", "0xF187"
    secondary: Optional[str] = None  # sub-function hex when kind=="sid"
    resolved: bool = False
    resolved_name: Optional[str] = None

    def __str__(self) -> str:
        if self.secondary:
            return f"{self.kind}:{self.primary}:{self.secondary}"
        return f"{self.kind}:{self.primary}"

    def __hash__(self) -> int:  # keep usability in sets / dict keys
        return hash((self.kind, self.primary, self.secondary))


@dataclass
class RtmEntry:
    """One row of a requirements traceability matrix.

    The `status` field is normalised to lower-case during CSV load and
    accepts ``verified`` / ``accepted`` / ``in_progress`` / ``not_yet`` /
    ``na``. ``accepted`` is a semantic alias for ``verified`` — it
    expresses "the team has Accept'd this requirement as in-scope" and
    is the status that drives :py:meth:`RtmDocument.broken_entries`.
    """

    req_id: str
    description: str
    source_ref: str
    traces_to: list[RtmTrace]
    verified_by: str = ""
    status: str = "not_yet"
    # Free-text supplier-side comment. For ``conditionally_accepted``
    # rows this column carries the condition wording — what timing,
    # parameter range, session, or sub-function the supplier deviates
    # on. Surfaced in the HTML/PDF spec next to the badge and
    # cross-checked against the ARXML by :py:meth:`RtmDocument.condition_warnings`.
    comment: str = ""
    # Set during match_to_spec() if any trace resolves to a real spec item.
    resolved: bool = False
    # Free-text origin of this row (e.g. file basename) for diagnostics.
    origin: str = ""

    @property
    def is_accepted(self) -> bool:
        """True for statuses that assert "this req is implemented".

        ``verified`` and ``accepted`` are both accepted; the latter is
        the explicit Accept-state for OEM requirements ingested into
        the supplier-side spec.
        """
        return self.status in ("verified", "accepted")

    @property
    def is_conditionally_accepted(self) -> bool:
        """True for OEM reqs Accepted-with-conditions.

        The supplier-side implementation deviates from the OEM ask in
        some respect (timing, scope, parameter range). The matching
        ARXML element exists but the HTML/PDF spec must surface the
        deviation prominently.
        """
        return self.status == "conditionally_accepted"

    @property
    def is_rejected(self) -> bool:
        """True for OEM reqs explicitly out of scope.

        If an ARXML element traces to a rejected req, that's a
        compliance failure — the supplier shipped something the OEM
        said not to.
        """
        return self.status == "rejected"

    @property
    def is_broken_trace(self) -> bool:
        """Accepted requirement whose traces don't exist in the ARXML.

        This is the strongest red-flag class — the team declared the
        requirement is implemented, but the ARXML disagrees.
        """
        return self.is_accepted and not self.resolved


@dataclass
class RtmSource:
    """One entry from rtm_sources.yaml — a citable source."""

    bibkey: str
    title: str
    publisher: str = ""
    year: str = ""


@dataclass
class VerifiedCoverage:
    """An implementation element covered by at least one accepted requirement.

    The reverse of :class:`OrphanImpl`: for every spec element a
    verified/accepted requirement traces to, we record the back-reference
    so the rendered PDF can show "this SID is here because REQ-OEM-002
    asked for it". This makes the requirement→implementation link
    auditable from the implementation side too, satisfying ASPICE
    SYS.2.BP4 in both directions.
    """

    kind: str       # sid / did / rid / dtc / session / security
    primary: str    # "0x10", "0xF187", ...
    name: str       # short_name from the parsed ARXML
    req_ids: list[str] = field(default_factory=list)


@dataclass
class ImplStatus:
    """Aggregated RTM status for one implementation element.

    Returned by :py:meth:`RtmDocument.status_for` so HTML/PDF renderers
    can pick the right badge and decide whether to surface a warning
    banner. ``level`` is the worst-case label across all entries that
    trace to this (kind, primary):

        "rejected"               — at least one rejected req traces here
                                   (highest-severity warning)
        "conditionally_accepted" — at least one conditional req traces
                                   here (caution)
        "verified" / "accepted"  — at least one accepted req traces here
                                   (informational)
        "in_progress"            — only in-progress reqs
        "not_yet"                — only not-yet reqs
        "na"                     — only N/A reqs
        ""                       — no requirement references this element

    ``warning`` is the human-readable explanation when the status is
    not benign; empty string when nothing to flag.
    """

    level: str = ""
    req_ids: list[str] = field(default_factory=list)
    warning: str = ""

    @property
    def is_warning(self) -> bool:
        return self.level in ("rejected", "conditionally_accepted")

    @property
    def has_status(self) -> bool:
        return bool(self.level)


@dataclass
class OrphanImpl:
    """An ARXML element with no requirement tracing to it.

    These are the inverse direction of the bidirectional-traceability
    obligation in ASPICE SYS.2.BP4: not just "every req leads to impl"
    but also "every impl leads back to a req." Orphans frequently
    indicate scope creep, dead code, or a missing requirement entry.
    """

    kind: str       # sid / did / rid / dtc / session / security
    primary: str    # "0x10", "0xF187", ...
    name: str       # short_name from the parsed ARXML


@dataclass
class RtmDocument:
    """The full requirements-traceability dataset for a generation run."""

    entries: list[RtmEntry] = field(default_factory=list)
    sources: list[RtmSource] = field(default_factory=list)
    orphans: list[OrphanImpl] = field(default_factory=list)
    # Populated by :func:`match_to_spec`: every hex-id implemented in
    # the parsed ARXML, regardless of kind. Used to spot-check whether
    # a Conditionally-Accepted ``comment`` references an element the
    # supplier actually ships.
    implemented_hex: set[str] = field(default_factory=set)

    def coverage_pct(self) -> float:
        if not self.entries:
            return 0.0
        return 100.0 * sum(e.resolved for e in self.entries) / len(self.entries)

    # ---- Compliance accounting (Accept-state vs. ARXML reality) ------

    def accepted_entries(self) -> list[RtmEntry]:
        """Rows where the team Accept'd / verified the requirement."""
        return [e for e in self.entries if e.is_accepted]

    def broken_entries(self) -> list[RtmEntry]:
        """Accepted rows whose traces don't resolve in the parsed ARXML.

        These are the headline compliance failures — surface them
        prominently in the rendered RTM section so the reader cannot
        miss the discrepancy between OEM-Accept and supplier-impl.
        """
        return [e for e in self.entries if e.is_broken_trace]

    def compliance_pct(self) -> float:
        """% of Accept'd reqs whose ARXML implementation is present.

        Distinct from :py:meth:`coverage_pct`: coverage counts every
        row regardless of status (i.e. is the *matrix* well-formed);
        compliance counts only Accept'd rows (i.e. is the *product*
        in line with what we said we'd deliver).
        """
        accepted = self.accepted_entries()
        if not accepted:
            return 0.0
        return 100.0 * sum(e.resolved for e in accepted) / len(accepted)

    def verified_coverage(self) -> list["VerifiedCoverage"]:
        """Impl elements reached by at least one accepted requirement.

        Aggregates resolved traces of accepted entries into one row per
        (kind, primary) pair so the rendered RTM can list the REQ-IDs
        behind each implemented SID/DID/RID/DTC. This is the per-element
        reverse view that complements the Orphan table.
        """
        by_key: dict[tuple[str, str], VerifiedCoverage] = {}
        for e in self.entries:
            if not e.is_accepted:
                continue
            for tr in e.traces_to:
                if not tr.resolved:
                    continue
                key = (tr.kind, tr.primary)
                row = by_key.get(key)
                if row is None:
                    row = VerifiedCoverage(
                        kind=tr.kind,
                        primary=tr.primary,
                        name=tr.resolved_name or "",
                    )
                    by_key[key] = row
                if e.req_id not in row.req_ids:
                    row.req_ids.append(e.req_id)
        return sorted(by_key.values(), key=lambda v: (v.kind, v.primary))

    def source_by_key(self, bibkey: str) -> Optional[RtmSource]:
        for s in self.sources:
            if s.bibkey == bibkey:
                return s
        return None

    def status_for(self, kind: str, primary: object) -> ImplStatus:
        """Aggregated RTM acceptance status for one impl element.

        Walks every entry whose ``traces_to`` references
        ``(kind, primary)`` and folds their statuses into a single
        worst-case label so the HTML/PDF renderer can show a badge
        next to the element header — and surface a warning banner
        when the OEM accepted-with-conditions or outright rejected
        a feature the ARXML still implements.

        Severity order (worst first): rejected > conditionally_accepted
        > verified/accepted > in_progress > not_yet > na. Empty when
        no requirement references the element.

        ``primary`` accepts either a hex string ("0x10") or an int.
        """
        if isinstance(primary, int):
            primary_norm = f"0x{primary:X}"
        else:
            s = str(primary).strip()
            if s.lower().startswith("0x"):
                primary_norm = "0x" + s[2:].upper()
            else:
                try:
                    primary_norm = f"0x{int(s):X}"
                except ValueError:
                    primary_norm = s

        matched: list[RtmEntry] = []
        for e in self.entries:
            # Only OEM-sourced rows drive per-element badges / banners.
            # Standards-only or supplier-internal rows are excluded from
            # the compliance view — they are informational and live on
            # the References page.
            if not e.source_ref.startswith("oem-"):
                continue
            for tr in e.traces_to:
                if tr.kind == kind and tr.primary == primary_norm:
                    matched.append(e)
                    break
        if not matched:
            return ImplStatus()

        severity = {
            "rejected":               6,
            "conditionally_accepted": 5,
            "verified":               4,
            "accepted":               4,
            "in_progress":            3,
            "not_yet":                2,
            "na":                     1,
        }
        worst = max(matched, key=lambda e: severity.get(e.status, 0))
        level = worst.status
        if level == "verified":
            level = "accepted"
        req_ids = [e.req_id for e in matched]

        warning = ""
        if level == "rejected":
            rids = ", ".join(e.req_id for e in matched if e.is_rejected)
            warning = (
                f"OEM requirement {rids} explicitly REJECTS this element, "
                "but the ARXML still implements it — compliance failure."
            )
        elif level == "conditionally_accepted":
            rids = ", ".join(
                e.req_id for e in matched if e.is_conditionally_accepted
            )
            warning = (
                f"OEM requirement {rids} was CONDITIONALLY ACCEPTED — "
                "the supplier-side implementation deviates from the OEM ask. "
                "Review the requirement text before relying on this element."
            )
        return ImplStatus(level=level, req_ids=req_ids, warning=warning)

    def condition_warnings(self, entry: RtmEntry) -> list[str]:
        """Cross-check a Conditionally-Accepted entry's comment vs. ARXML.

        Two strict checks (both lexical, both feed the per-element
        traceability verdict):

        1. **Hex literals** (``0xABCD``) ≥ 0x10 are looked up directly
           against :attr:`implemented_hex`. Anything missing is flagged
           as "Condition mentions 0xABCD but no element with that ID
           is implemented in the ARXML."
        2. **Named UDS elements** drawn from :data:`CONDITION_KEYWORDS`
           (ISO 14229-1 session names, ISO 14229-1 service catalogue).
           A comment saying "ProgrammingSession" on an ECU that only
           implements DefaultSession produces a warning — closing the
           gap that pure hex-literal scanning missed (a name like
           "ProgrammingSession" does not contain "0x02" literally).

        Informational numeric extracts (BS, STmin, P2/P2*/S3, N_As/Bs/Cs)
        are returned by :meth:`condition_notes` instead — those do NOT
        downgrade the verdict because the tool cannot compare the OEM
        cited numbers against the live config automatically; the user
        must eyeball-check them.

        Returns an empty list when the comment has no relevant tokens
        OR every referenced element is implemented.
        """
        if not entry.is_conditionally_accepted or not entry.comment:
            return []
        if not self.implemented_hex:
            return []

        warnings: list[str] = []

        # --- 1. Hex literals --------------------------------------------------
        seen_hex: set[str] = set()
        for raw in re.findall(r"0[xX][0-9A-Fa-f]+", entry.comment):
            try:
                val = int(raw, 16)
            except ValueError:
                continue
            # Skip 1-digit hex — those are almost always subfunction
            # codes, session-IDs (0x01..0x03), or security-levels
            # quoted in prose. Element identifiers worth cross-checking
            # against the ARXML are at least 2 hex digits (≥ 0x10).
            if val < 0x10:
                continue
            norm = f"0x{val:X}"
            if norm in seen_hex:
                continue
            seen_hex.add(norm)
            if norm not in self.implemented_hex:
                warnings.append(
                    f"Condition mentions {norm}, but no element with "
                    "that ID is implemented in the ARXML."
                )

        # --- 2. Named UDS elements --------------------------------------------
        seen_names: set[str] = set()
        for m in _CONDITION_KEYWORD_RE.finditer(entry.comment):
            name = m.group(0)
            kind, hex_id = _CONDITION_KEYWORD_LOOKUP[name.lower()]
            # De-duplicate by canonical (kind, hex) so a comment that
            # mentions both "ExtendedSession" and
            # "ExtendedDiagnosticSession" only produces one warning.
            dedup = f"{kind}:{hex_id}"
            if dedup in seen_names:
                continue
            seen_names.add(dedup)
            # Skip the warning when the name's canonical hex IS in
            # the spec — the OEM is referring to something we have.
            if hex_id in self.implemented_hex:
                continue
            warnings.append(
                f"Condition mentions '{name}' ({kind}:{hex_id}), "
                "but no element with that ID is implemented in the ARXML."
            )

        return warnings

    def condition_notes(self, entry: RtmEntry) -> list[str]:
        """Informational numeric extracts from a Conditional comment.

        Surfaces BS / STmin / P2 / P2* / S3 / N_As / N_Bs / N_Cs values
        the OEM cites in the Comment, so the user can compare them
        against the parsed DcmDspSession / DcmDspAccessTiming / CanTp
        tables on the same HTML page. These are NOT warnings — the
        verdict logic ignores them on purpose, because lexical
        extraction cannot tell whether the OEM cited number is the
        target or the supplier deviation.
        """
        if not entry.is_conditionally_accepted or not entry.comment:
            return []
        notes: list[str] = []
        for label, pattern, unit in CONDITION_NUMERIC_PATTERNS:
            values = sorted({m.group(1) for m in pattern.finditer(entry.comment)})
            if values:
                notes.append(
                    f"{label} = " + " / ".join(values) + f" {unit}"
                )
        return notes

    def cite_string(self, kind: str, primary: object) -> str:
        """Build a ``\\cite{key1, key2}`` string for the given impl element.

        Iterates over every RTM entry whose ``traces_to`` list references
        this ``(kind, primary)`` element, collects the unique
        ``source_ref`` bibkeys, and emits one LaTeX cite call. Empty
        string when nothing matches or when none of the referencing
        entries have a bibkey that resolves in ``rtm_sources``.

        Order is preserved by first-appearance so the cite list is
        deterministic across runs. Used by section templates to
        embed inline references in body prose, replacing the
        standalone RTM chapter with footnote-style citations.

        ``primary`` accepts either a hex string ("0x10") or an int
        (0x10) — the latter is convenient inside Jinja templates that
        already hold the SID as an int.
        """
        if isinstance(primary, int):
            primary_norm = f"0x{primary:X}"
        else:
            s = str(primary).strip()
            if s.lower().startswith("0x"):
                primary_norm = "0x" + s[2:].upper()
            else:
                try:
                    primary_norm = f"0x{int(s):X}"
                except ValueError:
                    primary_norm = s
        bibkeys: list[str] = []
        seen: set[str] = set()
        for e in self.entries:
            for tr in e.traces_to:
                if tr.kind != kind or tr.primary != primary_norm:
                    continue
                ref = e.source_ref
                if not ref or ref in seen:
                    continue
                if self.source_by_key(ref) is None:
                    continue
                seen.add(ref)
                bibkeys.append(ref)
        if not bibkeys:
            return ""
        return "\\cite{" + ", ".join(bibkeys) + "}"


_TRACE_RE = re.compile(
    r"^(?P<kind>sid|did|rid|dtc|session|security)"
    r":(?P<primary>0[xX][0-9a-fA-F]+|\d+)"
    r"(?::(?P<secondary>0[xX][0-9a-fA-F]+|\d+))?$"
)

# Layer traces use string primaries (datalink/network/transport/application)
# rather than hex IDs, because protocol layers aren't identified by an
# AUTOSAR element. Parsed separately so callers can branch on kind="layer".
_LAYER_TRACE_RE = re.compile(
    r"^layer:(?P<primary>datalink|network|transport|session|application)$",
    re.IGNORECASE,
)
_LAYER_NAMES = {
    "datalink": "Data Link Layer",
    "network": "Network Layer",
    "transport": "Transport Layer",
    "session": "Session Layer",
    "application": "Application Layer",
}

# Annex traces identify ISO 14229-1 Annex features that map to an
# AUTOSAR DCM configuration concept rather than a single SID. Only
# topics that are genuinely placed in an ISO 14229-1:2020 Annex are
# listed here — main-body services (Auth 0x29, Periodic 0x2A, ROE 0x86,
# RFT 0x38, AccessTimingParameter, DDDID 0x2C, LinkControl 0x87) are
# traced via ``sid:`` kinds on their own service pages.
_ANNEX_TRACE_RE = re.compile(
    r"^annex:(?P<primary>nrc_catalogue|address_length_format|"
    r"security_state_chart|multiple_client)$",
    re.IGNORECASE,
)
_ANNEX_NAMES = {
    "nrc_catalogue":         "Annex A — Global parameter definitions (NRC catalogue)",
    "address_length_format": "Annex H — addressAndLengthFormatIdentifier examples",
    "security_state_chart":  "Annex I — Security access state chart",
    "multiple_client":       "Annex J — Multiple client environments",
}


def _parse_traces(value: str) -> list[RtmTrace]:
    out: list[RtmTrace] = []
    for raw in value.split(";"):
        token = raw.strip()
        if not token:
            continue
        m = _TRACE_RE.match(token)
        if m is None:
            lm = _LAYER_TRACE_RE.match(token)
            if lm is not None:
                primary = lm.group("primary").lower()
                out.append(RtmTrace(
                    kind="layer",
                    primary=primary,
                    secondary=None,
                    resolved=True,
                    resolved_name=_LAYER_NAMES.get(primary, primary),
                ))
                continue
            am = _ANNEX_TRACE_RE.match(token)
            if am is not None:
                primary = am.group("primary").lower()
                out.append(RtmTrace(
                    kind="annex",
                    primary=primary,
                    secondary=None,
                    resolved=False,  # resolved lazily by match_to_spec
                    resolved_name=_ANNEX_NAMES.get(primary, primary),
                ))
                continue
            raise ValueError(
                f"Invalid traces_to token {token!r} — expected forms like "
                "sid:0x10, sid:0x10:0x03, did:0xF187, rid:0x0203, "
                "dtc:0x010000, session:0x03, security:0x01, layer:datalink, "
                "annex:multiple_client"
            )
        primary = m.group("primary")
        if not primary.lower().startswith("0x"):
            primary = f"0x{int(primary):X}"
        else:
            primary = "0x" + primary[2:].upper()
        secondary = m.group("secondary")
        if secondary is not None:
            if not secondary.lower().startswith("0x"):
                secondary = f"0x{int(secondary):X}"
            else:
                secondary = "0x" + secondary[2:].upper()
        out.append(RtmTrace(kind=m.group("kind"), primary=primary, secondary=secondary))
    return out


def _normalize_status(raw: str) -> str:
    """Map a human-friendly status / acceptance-state token to the canonical lower-snake value.

    Accepts both the internal snake_case codes ("conditionally_accepted")
    and the OEM-spec wording ("Conditionally Accepted"). Unknown values
    pass through lower-cased so unknown statuses don't silently become
    "not_yet".
    """
    s = (raw or "").strip().lower()
    if not s:
        return "not_yet"
    s = s.replace("-", "_").replace(" ", "_")
    aliases = {
        "conditionally_accepted": "conditionally_accepted",
        "conditional":            "conditionally_accepted",
        "accept":                 "accepted",
        "accepted":               "accepted",
        "reject":                 "rejected",
        "rejected":               "rejected",
        "verified":               "verified",
        "in_progress":            "in_progress",
        "inprogress":             "in_progress",
        "wip":                    "in_progress",
        "not_yet":                "not_yet",
        "notyet":                 "not_yet",
        "pending":                "not_yet",
        "na":                     "na",
        "n_a":                    "na",
    }
    return aliases.get(s, s)


def load_rtm_csv(path: Path) -> list[RtmEntry]:
    """Parse one RTM CSV file. Header row required."""
    path = Path(path)
    entries: list[RtmEntry] = []
    with path.open(newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        if reader.fieldnames is None:
            return entries
        headers_lc = {h.lower().strip(): h for h in reader.fieldnames}
        for need in ("req_id", "description", "source_ref", "traces_to"):
            if need not in headers_lc:
                raise ValueError(
                    f"RTM CSV {path.name}: missing required column {need!r}. "
                    f"Headers seen: {reader.fieldnames}"
                )
        for row_no, row in enumerate(reader, start=2):
            req_id = (row.get(headers_lc["req_id"]) or "").strip()
            if not req_id:
                continue
            description = (row.get(headers_lc["description"]) or "").strip()
            source_ref = (row.get(headers_lc["source_ref"]) or "").strip()
            traces_raw = (row.get(headers_lc["traces_to"]) or "").strip()
            try:
                traces = _parse_traces(traces_raw)
            except ValueError as exc:
                raise ValueError(f"{path.name}:{row_no}: {exc}") from None
            verified_by = (row.get(headers_lc.get("verified_by", "")) or "").strip()
            status_col = headers_lc.get("status") or headers_lc.get("acceptance_state", "")
            status_raw = (row.get(status_col) or "") if status_col else ""
            status = _normalize_status(status_raw)
            comment_col = headers_lc.get("comment") or headers_lc.get("comments", "")
            comment = (row.get(comment_col) or "").strip() if comment_col else ""
            entries.append(
                RtmEntry(
                    req_id=req_id,
                    description=description,
                    source_ref=source_ref,
                    traces_to=traces,
                    verified_by=verified_by,
                    status=status,
                    comment=comment,
                    origin=path.name,
                )
            )
    return entries


def load_rtm_csvs(paths: Iterable[Path]) -> list[RtmEntry]:
    out: list[RtmEntry] = []
    for p in paths:
        out.extend(load_rtm_csv(Path(p)))
    return out


def load_rtm_sources(path: Path) -> list[RtmSource]:
    """Parse rtm_sources.yaml. Requires PyYAML."""
    import yaml  # type: ignore[import-untyped]

    raw = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if raw is None:
        return []
    if not isinstance(raw, list):
        raise ValueError(
            f"RTM sources file {Path(path).name}: top-level must be a list of "
            "dicts (got {type(raw).__name__})"
        )
    out: list[RtmSource] = []
    for i, item in enumerate(raw):
        if not isinstance(item, dict) or "bibkey" not in item:
            raise ValueError(
                f"RTM sources file {Path(path).name}: entry #{i} missing "
                "'bibkey' field"
            )
        out.append(
            RtmSource(
                bibkey=str(item["bibkey"]).strip(),
                title=str(item.get("title", "")).strip(),
                publisher=str(item.get("publisher", "")).strip(),
                year=str(item.get("year", "")).strip(),
            )
        )
    return out


_ANNEX_SPEC_CHECK: dict = {
    # Annex A — at least one NRC must be configured somewhere.
    "nrc_catalogue":         lambda s: any(
        getattr(svc, "nrc_list", []) for svc in getattr(s, "services", []) or []
    ),
    # Annex H — addressAndLengthFormatIdentifier params come from
    # DcmDspRequestFileTransfer (file transfer) or memory_ranges; both
    # encode addr/length bytes.
    "address_length_format": lambda s: bool(
        getattr(s, "request_file_transfer", []) or []
    ) or bool(getattr(s, "memory_ranges", []) or []),
    # Annex I — Security state chart needs at least one DcmDspSecurity row.
    "security_state_chart":  lambda s: bool(getattr(s, "security_levels", []) or []),
    # Annex J — Multiple client environment needs ≥2 DcmDslProtocolRow rows.
    "multiple_client":       lambda s: len(
        getattr(s, "protocol_rows", []) or []
    ) >= 2,
}


def _annex_is_implemented(spec: object, primary: str) -> bool:
    check = _ANNEX_SPEC_CHECK.get(primary)
    if check is None:
        return False
    try:
        return bool(check(spec))
    except Exception:  # noqa: BLE001
        return False


def match_to_spec(doc: RtmDocument, spec: object) -> RtmDocument:
    """Resolve each trace against the parsed ARXML.

    For every :class:`RtmTrace` we populate ``resolved`` and
    ``resolved_name`` from the matching spec element's ``short_name``,
    so the rendered RTM can display ``sid:0x10 (DiagnosticSessionControl)``
    instead of the raw token. The per-entry ``resolved`` is True iff
    at least one trace resolved.

    We also compute the reverse direction: every spec element that no
    requirement points at is recorded as an :class:`OrphanImpl` on the
    document. This is the second half of "bidirectional traceability"
    per ASPICE SYS.2.BP4 — an implementation element that no
    requirement asks for is itself a finding (scope creep, dead code,
    or missing requirement entry).

    The spec is duck-typed so this works for both `UdsSpecification`
    instances and any object that exposes attribute access to the
    relevant collections; missing attributes are treated as empty.
    """

    def _hex_int(v: str) -> Optional[int]:
        try:
            return int(v, 16) if v.lower().startswith("0x") else int(v)
        except (ValueError, AttributeError):
            return None

    def _build(items: object, hex_attr: str) -> dict[int, str]:
        """Map ``key_int -> short_name`` for one spec collection."""
        out: dict[int, str] = {}
        for it in items or []:
            key = _hex_int(getattr(it, hex_attr, "") or "")
            if key is not None:
                out[key] = (
                    getattr(it, "short_name", None)
                    or getattr(it, "name", None)
                    or ""
                )
        return out

    table: dict[str, dict[int, str]] = {
        "sid":      _build(getattr(spec, "services",        []), "service_id_hex"),
        "did":      _build(getattr(spec, "dids",            []), "did_id_hex"),
        "rid":      _build(getattr(spec, "routines",        []), "routine_id_hex"),
        "dtc":      _build(getattr(spec, "dtcs",            []), "dtc_id_hex"),
        "session":  _build(getattr(spec, "sessions",        []), "session_id_hex"),
        "security": _build(getattr(spec, "security_levels", []), "security_level_hex"),
    }

    # Forward direction: requirement -> impl.
    # Track OEM vs non-OEM references separately. The orphan view
    # (impl with no OEM requirement) drives the headline compliance
    # warning so it must ignore standards / supplier-internal rows.
    referenced_oem: dict[str, set[int]] = {k: set() for k in table}
    for entry in doc.entries:
        any_resolved = False
        is_oem = entry.source_ref.startswith("oem-")
        for tr in entry.traces_to:
            # Layer traces (datalink/network/transport/application) are
            # always considered resolved — they point at protocol layers
            # rather than ARXML elements. _parse_traces already set
            # resolved/resolved_name; leave them alone here.
            if tr.kind == "layer":
                any_resolved = True
                continue
            if tr.kind == "annex":
                tr.resolved = _annex_is_implemented(spec, tr.primary)
                if tr.resolved:
                    any_resolved = True
                continue
            primary_int = _hex_int(tr.primary)
            element_map = table.get(tr.kind, {})
            if primary_int is not None and primary_int in element_map:
                tr.resolved = True
                tr.resolved_name = element_map[primary_int]
                if is_oem:
                    referenced_oem[tr.kind].add(primary_int)
                any_resolved = True
            else:
                tr.resolved = False
                tr.resolved_name = None
        entry.resolved = any_resolved

    # Reverse direction: impl elements with no OEM requirement pointing
    # at them. Sessions are excluded from the orphan view — every ECU
    # has at least DefaultSession, and "you didn't write a req about
    # DefaultSession" is not a finding worth reporting.
    orphans: list[OrphanImpl] = []
    for kind, element_map in table.items():
        if kind == "session":
            continue
        refs = referenced_oem[kind]
        for key, name in sorted(element_map.items()):
            if key not in refs:
                orphans.append(OrphanImpl(
                    kind=kind,
                    primary=f"0x{key:X}",
                    name=name,
                ))
    doc.orphans = orphans
    impl_hex: set[str] = set()
    for element_map in table.values():
        for key in element_map.keys():
            impl_hex.add(f"0x{key:X}")
    doc.implemented_hex = impl_hex
    return doc


def load_rtm_document(
    csv_paths: Iterable[Path],
    sources_path: Optional[Path] = None,
) -> RtmDocument:
    """Convenience: load CSVs + sources into a single RtmDocument."""
    doc = RtmDocument(entries=load_rtm_csvs(csv_paths))
    if sources_path is not None:
        doc.sources = load_rtm_sources(Path(sources_path))
    return doc


__all__ = [
    "RtmTrace",
    "RtmEntry",
    "RtmSource",
    "RtmDocument",
    "OrphanImpl",
    "VerifiedCoverage",
    "ImplStatus",
    "load_rtm_csv",
    "load_rtm_csvs",
    "load_rtm_sources",
    "load_rtm_document",
    "match_to_spec",
]
