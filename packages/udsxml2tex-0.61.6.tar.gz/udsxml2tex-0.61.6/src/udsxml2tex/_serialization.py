"""JSON deserialization helpers for UdsSpecification.

This module is intentionally private (_serialization) and imported lazily
inside UdsSpecification.from_json() to avoid circular-import issues.
"""

from __future__ import annotations

from typing import Any

from udsxml2tex.models import (
    AccessTimingRow,
    AuthenticationConfig,
    CanTpChannel,
    CanTpConfig,
    ClearDtcNotification,
    ComControlConfig,
    ComControlSubNode,
    DataElement,
    DemCombinedDtcEntry,
    DemDebounceConfig,
    DemEnableCondition,
    DemEventMemoryConfig,
    DemEventParameter,
    DemExtendedDataClass,
    DemFreezeFrameClass,
    DemGeneralConfig,
    DemIndicatorConfig,
    DemOperationCycle,
    DemStorageCondition,
    DemDtcEntry,
    DiagSession,
    Did,
    DidRange,
    DslConnection,
    DtcDefinition,
    DtcExtendedDataRecord,
    DtcGroup,
    DtcSnapshotRecord,
    DynamicDidDefinition,
    IoControlDid,
    LinkControlBaudrateEntry,
    MemoryRange,
    NrcEntry,
    PeriodicDid,
    ProtocolRow,
    RequestFileTransferConfig,
    ResponseOnEventConfig,
    Routine,
    RoutineParameter,
    SecurityLevel,
    SubFunction,
    UdsService,
    UdsSpecification,
)


def _d(data: dict[str, Any], key: str, default: Any = None) -> Any:
    return data.get(key, default)


def _debounce(d: dict | None) -> DemDebounceConfig | None:
    if not d:
        return None
    return DemDebounceConfig(
        algorithm=_d(d, "algorithm", ""),
        counter_failed_threshold=_d(d, "counter_failed_threshold", 127),
        counter_passed_threshold=_d(d, "counter_passed_threshold", -128),
        counter_increment_step=_d(d, "counter_increment_step", 1),
        counter_decrement_step=_d(d, "counter_decrement_step", 1),
        counter_jump_up=_d(d, "counter_jump_up", False),
        counter_jump_down=_d(d, "counter_jump_down", False),
        counter_storage=_d(d, "counter_storage", False),
        time_failed_threshold=_d(d, "time_failed_threshold", 0.0),
        time_passed_threshold=_d(d, "time_passed_threshold", 0.0),
    )


def _service(d: dict) -> UdsService:
    return UdsService(
        short_name=_d(d, "short_name", ""),
        service_id=_d(d, "service_id", 0),
        description=_d(d, "description", ""),
        sub_functions=[SubFunction(**s) for s in _d(d, "sub_functions", [])],
        supported_sessions=_d(d, "supported_sessions", []),
        required_security_levels=_d(d, "required_security_levels", []),
        nrc_list=[NrcEntry(**n) for n in _d(d, "nrc_list", [])],
        addressing_modes=_d(d, "addressing_modes", []),
        suppress_pos_rsp=_d(d, "suppress_pos_rsp", False),
        request_min_length=_d(d, "request_min_length", 0),
        request_max_length=_d(d, "request_max_length", 0),
        response_min_length=_d(d, "response_min_length", 0),
        response_max_length=_d(d, "response_max_length", 0),
        domain=_d(d, "domain", "drive"),
    )


def _data_element(d: dict) -> DataElement:
    return DataElement(
        short_name=_d(d, "short_name", ""),
        byte_position=_d(d, "byte_position", 0),
        bit_position=_d(d, "bit_position", 0),
        bit_size=_d(d, "bit_size", 8),
        description=_d(d, "description", ""),
        data_type=_d(d, "data_type", "uint8"),
        min_value=_d(d, "min_value"),
        max_value=_d(d, "max_value"),
        unit=_d(d, "unit", ""),
        coding=_d(d, "coding", ""),
        endianness=_d(d, "endianness", ""),
        fixed_length=_d(d, "fixed_length", True),
        read_function=_d(d, "read_function", ""),
        write_function=_d(d, "write_function", ""),
        global_variables=_d(d, "global_variables", []),
    )


def _did(d: dict) -> Did:
    return Did(
        short_name=_d(d, "short_name", ""),
        did_id=_d(d, "did_id", 0),
        description=_d(d, "description", ""),
        data_elements=[_data_element(e) for e in _d(d, "data_elements", [])],
        read_access=_d(d, "read_access", True),
        write_access=_d(d, "write_access", False),
        snapshot_record=_d(d, "snapshot_record", False),
        supported_sessions=_d(d, "supported_sessions", []),
        required_security_levels=_d(d, "required_security_levels", []),
        total_byte_length=_d(d, "total_byte_length", 0),
        domain=_d(d, "domain", "drive"),
    )


def _routine_param(d: dict) -> RoutineParameter:
    return RoutineParameter(**d)


def _routine(d: dict) -> Routine:
    return Routine(
        short_name=_d(d, "short_name", ""),
        routine_id=_d(d, "routine_id", 0),
        description=_d(d, "description", ""),
        start_supported=_d(d, "start_supported", True),
        stop_supported=_d(d, "stop_supported", False),
        result_supported=_d(d, "result_supported", False),
        in_parameters=[_routine_param(p) for p in _d(d, "in_parameters", [])],
        out_parameters=[_routine_param(p) for p in _d(d, "out_parameters", [])],
        supported_sessions=_d(d, "supported_sessions", []),
        required_security_levels=_d(d, "required_security_levels", []),
        max_number_of_options=_d(d, "max_number_of_options", 0),
        access_type_required=_d(d, "access_type_required", False),
        domain=_d(d, "domain", "drive"),
    )


def _dtc(d: dict) -> DtcDefinition:
    return DtcDefinition(
        short_name=_d(d, "short_name", ""),
        dtc_id=_d(d, "dtc_id", 0),
        functional_unit=_d(d, "functional_unit", ""),
        severity=_d(d, "severity", ""),
        description=_d(d, "description", ""),
        extended_data_records=[
            DtcExtendedDataRecord(**e) for e in _d(d, "extended_data_records", [])
        ],
        snapshot_records=[
            DtcSnapshotRecord(**s) for s in _d(d, "snapshot_records", [])
        ],
        manufacturer_severity=_d(d, "manufacturer_severity", ""),
        aging_cycle_counter_threshold=_d(d, "aging_cycle_counter_threshold", 0),
        aging_allowed=_d(d, "aging_allowed", True),
        priority=_d(d, "priority", 0),
        dtc_kind=_d(d, "dtc_kind", ""),
        immediate_nv_storage=_d(d, "immediate_nv_storage", False),
        occurrence_counter_processing=_d(d, "occurrence_counter_processing", ""),
    )


def _cantp_config(d: dict | None) -> CanTpConfig | None:
    if not d:
        return None
    channels = [CanTpChannel(**ch) for ch in _d(d, "channels", [])]
    return CanTpConfig(
        channels=channels,
        main_function_period=_d(d, "main_function_period", 0.005),
        can_fd_enabled=_d(d, "can_fd_enabled", False),
        wft_max=_d(d, "wft_max", 0),
        change_parm_api=_d(d, "change_parm_api", False),
        tc=_d(d, "tc", False),
        dev_error_detect=_d(d, "dev_error_detect", False),
        version_info_api=_d(d, "version_info_api", False),
        padding_byte=_d(d, "padding_byte", 0xFF),
        read_parameter_api=_d(d, "read_parameter_api", False),
        dyn_id_support=_d(d, "dyn_id_support", False),
        generic_connection_support=_d(d, "generic_connection_support", False),
        max_channel_cnt=_d(d, "max_channel_cnt", None),
    )


def _com_control(d: dict | None) -> ComControlConfig | None:
    if not d:
        return None
    return ComControlConfig(
        sub_nodes=[ComControlSubNode(**n) for n in _d(d, "sub_nodes", [])],
        supported_sessions=_d(d, "supported_sessions", []),
        suppressor_rx_using_mask=_d(d, "suppressor_rx_using_mask", False),
    )


def _protocol_row(d: dict) -> ProtocolRow:
    return ProtocolRow(
        short_name=_d(d, "short_name", ""),
        protocol_type=_d(d, "protocol_type", ""),
        priority=_d(d, "priority", 0),
        preempt_timeout=_d(d, "preempt_timeout", 0.0),
        trans_type=_d(d, "trans_type", ""),
        max_response_length=_d(d, "max_response_length", 0),
        connections=[DslConnection(**c) for c in _d(d, "connections", [])],
    )


def _auth_config(d: dict | None) -> AuthenticationConfig | None:
    if not d:
        return None
    return AuthenticationConfig(**d)


def _dem_general(d: dict | None) -> DemGeneralConfig | None:
    if not d:
        return None
    return DemGeneralConfig(**d)


def _dem_event_param(d: dict) -> DemEventParameter:
    debounce = _debounce(d.get("debounce"))
    kwargs = {k: v for k, v in d.items() if k != "debounce"}
    return DemEventParameter(**kwargs, debounce=debounce)


def _diag_session(d: dict) -> DiagSession:
    """Build a DiagSession, tolerating old JSONs that lack the ``domain`` field."""
    return DiagSession(
        short_name=_d(d, "short_name", ""),
        session_id=_d(d, "session_id", 0),
        p2_server_max=_d(d, "p2_server_max", 0.05),
        p2_star_server_max=_d(d, "p2_star_server_max", 5.0),
        comm_ctrl_option_mask=_d(d, "comm_ctrl_option_mask", 0),
        domain=_d(d, "domain", "drive"),
    )


def spec_from_dict(d: dict) -> UdsSpecification:
    """Reconstruct a UdsSpecification from a plain dict (as produced by to_dict())."""
    return UdsSpecification(
        ecu_name=_d(d, "ecu_name", "ECU"),
        description=_d(d, "description", ""),
        sessions=[_diag_session(s) for s in _d(d, "sessions", [])],
        security_levels=[SecurityLevel(**s) for s in _d(d, "security_levels", [])],
        services=[_service(s) for s in _d(d, "services", [])],
        dids=[_did(dd) for dd in _d(d, "dids", [])],
        routines=[_routine(r) for r in _d(d, "routines", [])],
        dtcs=[_dtc(dt) for dt in _d(d, "dtcs", [])],
        memory_ranges=[MemoryRange(**m) for m in _d(d, "memory_ranges", [])],
        io_control_dids=[IoControlDid(**i) for i in _d(d, "io_control_dids", [])],
        periodic_dids=[PeriodicDid(**p) for p in _d(d, "periodic_dids", [])],
        did_ranges=[DidRange(**r) for r in _d(d, "did_ranges", [])],
        com_control=_com_control(_d(d, "com_control")),
        response_on_event=[ResponseOnEventConfig(**r) for r in _d(d, "response_on_event", [])],
        dtc_status_availability_mask=_d(d, "dtc_status_availability_mask", 0xFF),
        max_num_resp_pend=_d(d, "max_num_resp_pend", 0),
        max_response_length=_d(d, "max_response_length", 0),
        request_file_transfer=[
            RequestFileTransferConfig(**r) for r in _d(d, "request_file_transfer", [])
        ],
        clear_dtc_notifications=[
            ClearDtcNotification(**c) for c in _d(d, "clear_dtc_notifications", [])
        ],
        protocol_name=_d(d, "protocol_name", "UDS on CAN"),
        protocol_type=_d(d, "protocol_type", ""),
        can_rx_id=_d(d, "can_rx_id", ""),
        can_tx_id=_d(d, "can_tx_id", ""),
        can_functional_id=_d(d, "can_functional_id", ""),
        s3_server=_d(d, "s3_server", 5.0),
        dsl_rx_buffer_size=_d(d, "dsl_rx_buffer_size", 0),
        dsl_tx_buffer_size=_d(d, "dsl_tx_buffer_size", 0),
        transport_config=_cantp_config(_d(d, "transport_config")),
        connection_mode=_d(d, "connection_mode", ""),
        connection_end_of_type=_d(d, "connection_end_of_type", ""),
        cdtc_status_mask=_d(d, "cdtc_status_mask", 0),
        clear_dtc_group=_d(d, "clear_dtc_group", 0xFFFFFF),
        module_main_function_period=_d(d, "module_main_function_period", 0.0),
        enable_fim_trigger=_d(d, "enable_fim_trigger", False),
        dynamic_dids=[DynamicDidDefinition(**dd) for dd in _d(d, "dynamic_dids", [])],
        protocol_priority=_d(d, "protocol_priority", 0),
        protocol_trans_type=_d(d, "protocol_trans_type", ""),
        protocol_preempt_timeout=_d(d, "protocol_preempt_timeout", 0.0),
        periodic_slow_rate=_d(d, "periodic_slow_rate", 0.0),
        periodic_medium_rate=_d(d, "periodic_medium_rate", 0.0),
        periodic_fast_rate=_d(d, "periodic_fast_rate", 0.0),
        memory_compression_method=_d(d, "memory_compression_method", ""),
        memory_encrypting_method=_d(d, "memory_encrypting_method", ""),
        dev_error_detect=_d(d, "dev_error_detect", False),
        version_info_api=_d(d, "version_info_api", False),
        task_time=_d(d, "task_time", 0.0),
        respond_all_request=_d(d, "respond_all_request", True),
        protocol_rows=[_protocol_row(r) for r in _d(d, "protocol_rows", [])],
        authentication_config=_auth_config(_d(d, "authentication_config")),
        access_timing_rows=[AccessTimingRow(**r) for r in _d(d, "access_timing_rows", [])],
        dem_general=_dem_general(_d(d, "dem_general")),
        dem_operation_cycles=[DemOperationCycle(**c) for c in _d(d, "dem_operation_cycles", [])],
        dem_event_parameters=[_dem_event_param(e) for e in _d(d, "dem_event_parameters", [])],
        dem_indicators=[DemIndicatorConfig(**i) for i in _d(d, "dem_indicators", [])],
        dem_enable_conditions=[DemEnableCondition(**c) for c in _d(d, "dem_enable_conditions", [])],
        dem_storage_conditions=[
            DemStorageCondition(**c) for c in _d(d, "dem_storage_conditions", [])
        ],
        dem_event_memories=[DemEventMemoryConfig(**m) for m in _d(d, "dem_event_memories", [])],
        dem_dtcs=[DemDtcEntry(**dt) for dt in _d(d, "dem_dtcs", [])],
        dem_freeze_frame_classes=[
            DemFreezeFrameClass(**ff) for ff in _d(d, "dem_freeze_frame_classes", [])
        ],
        dem_extended_data_classes=[
            DemExtendedDataClass(**ed) for ed in _d(d, "dem_extended_data_classes", [])
        ],
        dem_combined_dtcs=[DemCombinedDtcEntry(**c) for c in _d(d, "dem_combined_dtcs", [])],
        max_block_length=_d(d, "max_block_length", 0),
        link_control_baudrates=[
            LinkControlBaudrateEntry(**b) for b in _d(d, "link_control_baudrates", [])
        ],
        dtc_groups=[DtcGroup(**g) for g in _d(d, "dtc_groups", [])],
    )
