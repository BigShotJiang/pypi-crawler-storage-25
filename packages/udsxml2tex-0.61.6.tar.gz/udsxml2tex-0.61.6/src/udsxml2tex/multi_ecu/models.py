"""Data model for multi-ECU diagnostic systems.

Models a diagnostic system composed of multiple AUTOSAR ECUs (each with its own
DCM/CanTp/DEM ARXML configuration) plus the routing relationships that describe
how diagnostic requests flow between them — typically a primary "gateway" MCU
that receives requests from the tester and forwards a subset of them to a
secondary "endpoint" MCU.

The design keeps the existing single-ECU `UdsSpecification` API completely
unchanged: an `EcuSystem` is a thin container holding one `UdsSpecification`
per ECU plus inter-ECU routing/topology metadata.

Public classes:
    EcuRole          — gateway | endpoint | peer
    RoutingMatch     — match criteria (SIDs, DIDs, RIDs by exact code or range)
    RoutingRule      — directed forwarding rule {from_ecu, to_ecu, match, via}
    EcuConnection    — physical inter-ECU connection (CAN, SPI, …)
    SystemTopology   — collection of EcuConnection
    EcuConfig        — per-ECU config: name, role, ARXML paths, parsed spec
    EcuSystem        — top-level container
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Optional

from udsxml2tex.models import UdsSpecification


class EcuRole(Enum):
    """How an ECU participates in the multi-ECU system.

    - GATEWAY: faces the diagnostic tester and may forward selected requests
      to other ECUs in the system. Typically there is exactly one gateway
      in a 1+1 redundant or N-ECU layout.
    - ENDPOINT: receives forwarded requests from the gateway only. Not
      reachable directly from the tester at the diagnostic layer (though
      may share the physical bus).
    - PEER: faces the tester directly without forwarding (each ECU is
      independently addressable). Used for "loosely coupled" multi-ECU
      vehicles where this tool is documenting several ECUs side by side.
    """
    GATEWAY = "gateway"
    ENDPOINT = "endpoint"
    PEER = "peer"


@dataclass
class RoutingMatch:
    """Match criteria for a routing rule.

    Multiple criteria are OR'd together; an empty match matches everything.
    SID/DID/RID can be specified as either an explicit list of codes or a
    [low, high] inclusive range.
    """
    sids: list[int] = field(default_factory=list)
    sid_range: Optional[tuple[int, int]] = None
    dids: list[int] = field(default_factory=list)
    did_range: Optional[tuple[int, int]] = None
    rids: list[int] = field(default_factory=list)
    rid_range: Optional[tuple[int, int]] = None

    def matches_sid(self, sid: int) -> bool:
        if sid in self.sids:
            return True
        if self.sid_range and self.sid_range[0] <= sid <= self.sid_range[1]:
            return True
        return False

    def matches_did(self, did: int) -> bool:
        if did in self.dids:
            return True
        if self.did_range and self.did_range[0] <= did <= self.did_range[1]:
            return True
        return False

    def matches_rid(self, rid: int) -> bool:
        if rid in self.rids:
            return True
        if self.rid_range and self.rid_range[0] <= rid <= self.rid_range[1]:
            return True
        return False

    def is_empty(self) -> bool:
        """True if no criteria are set (rule matches every request)."""
        return not (self.sids or self.sid_range or self.dids
                    or self.did_range or self.rids or self.rid_range)

    def description(self) -> str:
        """Human-readable summary, e.g. 'SID 0x22, 0x2E; DID 0x2000..0x2FFF'."""
        parts: list[str] = []
        if self.sids:
            parts.append("SID " + ", ".join(f"0x{s:02X}" for s in self.sids))
        if self.sid_range:
            parts.append(f"SID 0x{self.sid_range[0]:02X}..0x{self.sid_range[1]:02X}")
        if self.dids:
            parts.append("DID " + ", ".join(f"0x{d:04X}" for d in self.dids))
        if self.did_range:
            parts.append(f"DID 0x{self.did_range[0]:04X}..0x{self.did_range[1]:04X}")
        if self.rids:
            parts.append("RID " + ", ".join(f"0x{r:04X}" for r in self.rids))
        if self.rid_range:
            parts.append(f"RID 0x{self.rid_range[0]:04X}..0x{self.rid_range[1]:04X}")
        return "; ".join(parts) if parts else "all"

    def to_dict(self) -> dict:
        out: dict = {}
        if self.sids:
            out["sids"] = [f"0x{s:02X}" for s in self.sids]
        if self.sid_range:
            out["sid_range"] = [f"0x{self.sid_range[0]:02X}",
                                f"0x{self.sid_range[1]:02X}"]
        if self.dids:
            out["dids"] = [f"0x{d:04X}" for d in self.dids]
        if self.did_range:
            out["did_range"] = [f"0x{self.did_range[0]:04X}",
                                f"0x{self.did_range[1]:04X}"]
        if self.rids:
            out["rids"] = [f"0x{r:04X}" for r in self.rids]
        if self.rid_range:
            out["rid_range"] = [f"0x{self.rid_range[0]:04X}",
                                f"0x{self.rid_range[1]:04X}"]
        return out

    @classmethod
    def from_dict(cls, data: Optional[dict]) -> "RoutingMatch":
        if not data:
            return cls()

        def _to_int(v: Any) -> int:
            if isinstance(v, int):
                return v
            return int(str(v), 0)

        def _to_int_list(v: Any) -> list[int]:
            return [_to_int(x) for x in (v or [])]

        def _to_int_range(v: Any) -> Optional[tuple[int, int]]:
            if not v:
                return None
            lo, hi = v
            return (_to_int(lo), _to_int(hi))

        return cls(
            sids=_to_int_list(data.get("sids")),
            sid_range=_to_int_range(data.get("sid_range")),
            dids=_to_int_list(data.get("dids")),
            did_range=_to_int_range(data.get("did_range")),
            rids=_to_int_list(data.get("rids")),
            rid_range=_to_int_range(data.get("rid_range")),
        )


@dataclass
class RoutingRule:
    """A directed forwarding rule from one ECU to another."""
    from_ecu: str                      # Name (matches a key in EcuSystem.ecus)
    to_ecu: str
    match: RoutingMatch = field(default_factory=RoutingMatch)
    via: Optional[str] = None          # Physical channel (e.g., "internal_can", "spi")
    description: Optional[str] = None
    inferred: bool = False             # True when produced by ARXML auto-inference

    def to_dict(self) -> dict:
        out: dict = {
            "from": self.from_ecu,
            "to": self.to_ecu,
        }
        m = self.match.to_dict()
        if m:
            out["match"] = m
        if self.via:
            out["via"] = self.via
        if self.description:
            out["description"] = self.description
        if self.inferred:
            out["inferred"] = True
        return out

    @classmethod
    def from_dict(cls, data: dict) -> "RoutingRule":
        return cls(
            from_ecu=data["from"],
            to_ecu=data["to"],
            match=RoutingMatch.from_dict(data.get("match")),
            via=data.get("via"),
            description=data.get("description"),
            inferred=bool(data.get("inferred", False)),
        )


@dataclass
class EcuConnection:
    """A physical / link-layer connection between two ECUs."""
    from_ecu: str
    to_ecu: str
    medium: str = "CAN"
    description: Optional[str] = None

    def to_dict(self) -> dict:
        out = {"from": self.from_ecu, "to": self.to_ecu, "medium": self.medium}
        if self.description:
            out["description"] = self.description
        return out

    @classmethod
    def from_dict(cls, data: dict) -> "EcuConnection":
        return cls(
            from_ecu=data["from"],
            to_ecu=data["to"],
            medium=data.get("medium", "CAN"),
            description=data.get("description"),
        )


@dataclass
class SystemTopology:
    """Collection of EcuConnection objects describing the physical layout."""
    connections: list[EcuConnection] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {"connections": [c.to_dict() for c in self.connections]}

    @classmethod
    def from_dict(cls, data: Optional[dict]) -> "SystemTopology":
        if not data:
            return cls()
        return cls(connections=[EcuConnection.from_dict(c)
                                for c in (data.get("connections") or [])])


@dataclass
class EcuConfig:
    """Configuration for one ECU in the system.

    `arxml_files` may include any combination of DCM, CanTp, and other ARXML
    files that contribute to this ECU's spec. `dem_arxml` is parsed separately
    via `DemParser` to keep behaviour identical to single-ECU mode.
    `did_c_files` / `rid_c_files` are optional C/C++ sources that the loader
    feeds to `c_scanner.scan_{did,rid}_variables()` after parsing, so the
    generated spec carries the same global-variable enrichment as single-ECU
    mode. `spec` is `None` until the loader has parsed the files.

    A real ECU is almost always built from **two** independent ARXML groups:
    the application-domain DCM/CanTp/DEM configuration (covering normal
    drive-cycle diagnostics) and a separate bootloader-domain configuration
    (covering the programming session, RequestDownload/TransferData and the
    boot-side DIDs/RIDs). The two groups are typically owned by different
    teams and shipped from different Vector / EB / KSAR DaVinci projects, so
    udsxml2tex keeps them as two distinct field groups:

    * ``arxml_files`` / ``dem_arxml`` / ``did_c_files`` / ``rid_c_files`` —
      the application-domain group.
    * ``boot_arxml_files`` / ``boot_dem_arxml`` / ``boot_did_c_files`` /
      ``boot_rid_c_files`` — the bootloader-domain group (optional). When
      populated, the loader parses them into a second :class:`UdsSpecification`
      and merges it into the primary spec via
      :func:`udsxml2tex.multi_ecu.loader.merge_boot_spec`, which writes
      ``domain="boot"`` on bootloader-only items and ``domain="both"`` on
      items present in both groups (mirroring the
      :mod:`udsxml2tex.boot_overlay` semantics).
    """
    name: str
    role: EcuRole = EcuRole.PEER
    arxml_files: list[Path] = field(default_factory=list)
    dem_arxml: Optional[Path] = None
    did_c_files: list[Path] = field(default_factory=list)
    rid_c_files: list[Path] = field(default_factory=list)
    # --- Bootloader-domain ARXML group (optional) ---
    boot_arxml_files: list[Path] = field(default_factory=list)
    boot_dem_arxml: Optional[Path] = None
    boot_did_c_files: list[Path] = field(default_factory=list)
    boot_rid_c_files: list[Path] = field(default_factory=list)
    description: Optional[str] = None
    spec: Optional[UdsSpecification] = None

    def to_dict(self) -> dict:
        out: dict = {
            "role": self.role.value,
            "arxml_files": [str(p) for p in self.arxml_files],
        }
        if self.dem_arxml:
            out["dem_arxml"] = str(self.dem_arxml)
        if self.did_c_files:
            out["did_c_files"] = [str(p) for p in self.did_c_files]
        if self.rid_c_files:
            out["rid_c_files"] = [str(p) for p in self.rid_c_files]
        if self.boot_arxml_files:
            out["boot_arxml_files"] = [str(p) for p in self.boot_arxml_files]
        if self.boot_dem_arxml:
            out["boot_dem_arxml"] = str(self.boot_dem_arxml)
        if self.boot_did_c_files:
            out["boot_did_c_files"] = [str(p) for p in self.boot_did_c_files]
        if self.boot_rid_c_files:
            out["boot_rid_c_files"] = [str(p) for p in self.boot_rid_c_files]
        if self.description:
            out["description"] = self.description
        return out

    @classmethod
    def from_dict(cls, name: str, data: dict, base_dir: Path) -> "EcuConfig":
        role = EcuRole(data.get("role", "peer"))
        arxml_files = [_resolve_path(p, base_dir)
                       for p in (data.get("arxml_files") or [])]
        dem = data.get("dem_arxml")
        did_c = [_resolve_path(p, base_dir)
                 for p in (data.get("did_c_files") or [])]
        rid_c = [_resolve_path(p, base_dir)
                 for p in (data.get("rid_c_files") or [])]
        boot_arxml = [_resolve_path(p, base_dir)
                      for p in (data.get("boot_arxml_files") or [])]
        boot_dem = data.get("boot_dem_arxml")
        boot_did_c = [_resolve_path(p, base_dir)
                      for p in (data.get("boot_did_c_files") or [])]
        boot_rid_c = [_resolve_path(p, base_dir)
                      for p in (data.get("boot_rid_c_files") or [])]
        return cls(
            name=name,
            role=role,
            arxml_files=arxml_files,
            dem_arxml=_resolve_path(dem, base_dir) if dem else None,
            did_c_files=did_c,
            rid_c_files=rid_c,
            boot_arxml_files=boot_arxml,
            boot_dem_arxml=_resolve_path(boot_dem, base_dir) if boot_dem else None,
            boot_did_c_files=boot_did_c,
            boot_rid_c_files=boot_rid_c,
            description=data.get("description"),
        )


def _resolve_path(p: "str | Path", base_dir: Path) -> Path:
    """Resolve `p` relative to `base_dir` if it isn't absolute."""
    pp = Path(p)
    return pp if pp.is_absolute() else (base_dir / pp).resolve()


@dataclass
class EcuSystem:
    """Top-level container for a multi-ECU diagnostic system.

    Keys in `ecus` are arbitrary unique names (e.g. "primary", "secondary",
    "front_zone", "rear_zone"); they appear verbatim in routing rules and
    output documents. Convenience properties `primary` and `secondary` are
    provided for the common 1+1 case.
    """
    name: str = "UnnamedSystem"
    description: Optional[str] = None
    ecus: dict[str, EcuConfig] = field(default_factory=dict)
    routing_rules: list[RoutingRule] = field(default_factory=list)
    topology: SystemTopology = field(default_factory=SystemTopology)

    @property
    def primary(self) -> Optional[EcuConfig]:
        """The single GATEWAY ECU, or the first ECU when no role is set."""
        for cfg in self.ecus.values():
            if cfg.role == EcuRole.GATEWAY:
                return cfg
        return next(iter(self.ecus.values()), None)

    @property
    def secondary(self) -> Optional[EcuConfig]:
        """The first ENDPOINT ECU. Returns None when the system has only one ECU."""
        for cfg in self.ecus.values():
            if cfg.role == EcuRole.ENDPOINT:
                return cfg
        # Fallback: any ECU other than the primary
        prim = self.primary
        for cfg in self.ecus.values():
            if cfg is not prim:
                return cfg
        return None

    def get_ecu(self, name: str) -> EcuConfig:
        if name not in self.ecus:
            raise KeyError(
                f"Unknown ECU: {name!r}. Known ECUs: {list(self.ecus)}"
            )
        return self.ecus[name]

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "ecus": {n: e.to_dict() for n, e in self.ecus.items()},
            "routing": [r.to_dict() for r in self.routing_rules],
            "topology": self.topology.to_dict(),
        }

    @classmethod
    def from_dict(cls, data: dict, base_dir: Optional[Path] = None) -> "EcuSystem":
        bd = base_dir or Path(".")
        ecus = {
            name: EcuConfig.from_dict(name, cfg, bd)
            for name, cfg in (data.get("ecus") or {}).items()
        }
        rules = [RoutingRule.from_dict(r) for r in (data.get("routing") or [])]
        topo = SystemTopology.from_dict(data.get("topology"))
        return cls(
            name=data.get("name", "UnnamedSystem"),
            description=data.get("description"),
            ecus=ecus,
            routing_rules=rules,
            topology=topo,
        )

    def to_json(self, *, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)
