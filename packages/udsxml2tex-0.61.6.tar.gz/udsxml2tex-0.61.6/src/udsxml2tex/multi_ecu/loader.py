"""Loader for multi-ECU system configuration.

Reads a YAML or JSON file describing the ECUs, their ARXML inputs, and the
routing relationships between them; parses each ECU's ARXML files into a
`UdsSpecification`; and optionally runs ARXML-based routing inference.

Config file schema (YAML):

    name: MyVehicle
    description: 1+1 redundant MCU pair
    ecus:
      primary:
        role: gateway
        arxml_files:
          - primary/dcm.arxml
          - primary/cantp.arxml
        dem_arxml: primary/dem.arxml
        description: Tester-facing MCU
      secondary:
        role: endpoint
        arxml_files:
          - secondary/dcm.arxml
        description: Forwarded-only MCU

    routing:
      - from: primary
        to: secondary
        match:
          sids: [0x22, 0x2E]
          did_range: [0x2000, 0x2FFF]
        via: internal_can
        description: ADAS calibration DIDs

    topology:
      connections:
        - from: primary
          to: secondary
          medium: CAN
          description: 500 kbit/s internal CAN

Public API:
    load_system_config(path, *, parse_arxml=True, infer_routing=True) -> EcuSystem
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

from udsxml2tex.dem_parser import DemParser
from udsxml2tex.models import UdsSpecification
from udsxml2tex.multi_ecu.models import EcuConfig, EcuSystem
from udsxml2tex.parser import ArxmlParser

logger = logging.getLogger(__name__)


def load_system_config(
    path: "str | Path",
    *,
    parse_arxml: bool = True,
    infer_routing: bool = True,
) -> EcuSystem:
    """Load a system config and return a fully-populated `EcuSystem`.

    Args:
        path: Path to a YAML (.yaml/.yml) or JSON (.json) system config file.
        parse_arxml: When True, parse each ECU's ARXML files into a
                     `UdsSpecification` and store on `EcuConfig.spec`.
        infer_routing: When True (and parse_arxml is True), run ARXML-based
                       routing inference and append inferred rules to
                       `system.routing_rules`. Explicit rules from the config
                       are kept verbatim — inference only adds new rules.

    Returns:
        EcuSystem with `EcuConfig.spec` populated for each ECU.

    Raises:
        ImportError: If the file is YAML and PyYAML is not installed.
        FileNotFoundError: If the config file or any referenced ARXML is missing.
        ValueError: For unsupported file extensions or malformed configs.
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"System config not found: {p}")

    suffix = p.suffix.lower()
    if suffix in {".yaml", ".yml"}:
        try:
            import yaml  # type: ignore[import-not-found]
        except ImportError as e:
            raise ImportError(
                "PyYAML is required to load .yaml multi-ECU system configs. "
                "Install with: pip install udsxml2tex[yaml]"
            ) from e
        data = yaml.safe_load(p.read_text(encoding="utf-8"))
    elif suffix == ".json":
        data = json.loads(p.read_text(encoding="utf-8"))
    else:
        raise ValueError(
            f"Unsupported config format: {suffix!r}. Use .yaml/.yml/.json"
        )

    if not isinstance(data, dict):
        raise ValueError(
            f"System config root must be a mapping, got {type(data).__name__}"
        )

    system = EcuSystem.from_dict(data, base_dir=p.parent)

    if parse_arxml:
        for ecu in system.ecus.values():
            try:
                ecu.spec = _parse_ecu(ecu)
                _scan_c_sources(ecu)
            except Exception as e:  # noqa: BLE001
                logger.error("Failed to parse ECU %r: %s", ecu.name, e)
                raise

    if infer_routing and parse_arxml:
        from udsxml2tex.multi_ecu.inference import infer_routing_rules
        inferred = infer_routing_rules(system)
        # Inferred rules are appended; explicit rules in the config take
        # precedence (we never remove or modify explicit rules).
        if inferred:
            logger.info(
                "Inferred %d routing rule(s) from ARXML coverage gaps",
                len(inferred),
            )
            system.routing_rules.extend(inferred)

    return system


def _parse_ecu(ecu: EcuConfig) -> UdsSpecification:
    """Parse one ECU's ARXML files (and optional DEM) into a UdsSpecification."""
    if not ecu.arxml_files:
        raise ValueError(
            f"ECU {ecu.name!r}: no arxml_files configured — cannot parse"
        )
    for arxml in ecu.arxml_files:
        if not arxml.exists():
            raise FileNotFoundError(
                f"ECU {ecu.name!r}: ARXML not found: {arxml}"
            )
    parser = ArxmlParser()
    if len(ecu.arxml_files) == 1:
        spec = parser.parse(ecu.arxml_files[0])
    else:
        spec = parser.parse_multi(ecu.arxml_files)

    if ecu.dem_arxml:
        if not ecu.dem_arxml.exists():
            raise FileNotFoundError(
                f"ECU {ecu.name!r}: DEM ARXML not found: {ecu.dem_arxml}"
            )
        DemParser().parse(ecu.dem_arxml, spec)

    # Ensure the spec's ECU name matches the system's logical name; this drives
    # cross-references in the system integration document.
    if not spec.ecu_name or spec.ecu_name == "UnnamedECU":
        spec.ecu_name = ecu.name

    # Merge bootloader-domain ARXML group when configured. Parsed as a
    # second independent UdsSpecification, then folded into ``spec`` with
    # ``domain`` tags so the rendered output can distinguish drive- vs
    # boot-side items (mirrors udsxml2tex.boot_overlay).
    if ecu.boot_arxml_files:
        for arxml in ecu.boot_arxml_files:
            if not arxml.exists():
                raise FileNotFoundError(
                    f"ECU {ecu.name!r}: bootloader ARXML not found: {arxml}"
                )
        boot_parser = ArxmlParser()
        if len(ecu.boot_arxml_files) == 1:
            boot_spec = boot_parser.parse(ecu.boot_arxml_files[0])
        else:
            boot_spec = boot_parser.parse_multi(ecu.boot_arxml_files)
        if ecu.boot_dem_arxml:
            if not ecu.boot_dem_arxml.exists():
                raise FileNotFoundError(
                    f"ECU {ecu.name!r}: bootloader DEM ARXML not found: {ecu.boot_dem_arxml}"
                )
            DemParser().parse(ecu.boot_dem_arxml, boot_spec)
        merge_boot_spec(spec, boot_spec)
        logger.info(
            "ECU %r: merged bootloader spec (%d sessions, %d services, %d DIDs, %d routines, %d DTCs)",
            ecu.name,
            len(boot_spec.sessions),
            len(boot_spec.services),
            len(boot_spec.dids),
            len(boot_spec.routines),
            len(boot_spec.dtcs),
        )

    return spec


def merge_boot_spec(app_spec: UdsSpecification, boot_spec: UdsSpecification) -> None:
    """Fold *boot_spec* into *app_spec* with bootloader-domain tagging.

    The merge contract:

    * Sessions / services / DIDs / routines / DTCs that appear **only in the
      boot spec** are appended to *app_spec* with ``domain="boot"``.
    * Items that appear in **both** specs keep their position in *app_spec*
      but are re-tagged ``domain="both"``. Their other attributes are not
      overwritten — the application-domain definition wins, on the assumption
      that the supplier owns the drive-side ARXML and the bootloader-side
      ARXML often only carries identifier + minimal metadata.
    * Security levels are appended de-duplicated by ``level_id``.

    Identity is by canonical numeric id: ``session_id`` / ``service_id`` /
    ``did_id`` / ``routine_id`` / ``dtc_id``. The function is idempotent.
    """
    def _index(items, attr):
        return {getattr(it, attr): it for it in items}

    # Sessions
    by_id = _index(app_spec.sessions, "session_id")
    for sess in boot_spec.sessions:
        existing = by_id.get(sess.session_id)
        if existing is None:
            sess.domain = "boot"
            app_spec.sessions.append(sess)
        else:
            existing.domain = "both"

    # Services
    by_id = _index(app_spec.services, "service_id")
    for svc in boot_spec.services:
        existing = by_id.get(svc.service_id)
        if existing is None:
            svc.domain = "boot"
            app_spec.services.append(svc)
        else:
            existing.domain = "both"

    # DIDs
    by_id = _index(app_spec.dids, "did_id")
    for did in boot_spec.dids:
        existing = by_id.get(did.did_id)
        if existing is None:
            did.domain = "boot"
            app_spec.dids.append(did)
        else:
            existing.domain = "both"

    # Routines
    by_id = _index(app_spec.routines, "routine_id")
    for rid in boot_spec.routines:
        existing = by_id.get(rid.routine_id)
        if existing is None:
            rid.domain = "boot"
            app_spec.routines.append(rid)
        else:
            existing.domain = "both"

    # DTCs — no domain field on DtcDefinition; just append unique ones.
    existing_dtcs = {d.dtc_id for d in app_spec.dtcs}
    for dtc in boot_spec.dtcs:
        if dtc.dtc_id not in existing_dtcs:
            app_spec.dtcs.append(dtc)

    # Security levels — append unique by level_id (or short_name fallback).
    def _sec_key(s):
        return getattr(s, "level_id", None) or s.short_name
    existing_keys = {_sec_key(s) for s in app_spec.security_levels}
    for sec in boot_spec.security_levels:
        if _sec_key(sec) not in existing_keys:
            app_spec.security_levels.append(sec)


def _scan_c_sources(ecu: EcuConfig) -> None:
    """Run the DID/RID C scanners against `ecu.spec` if C files are configured.

    Mirrors the single-ECU flow in cli.py: enriches DataElement.global_variables
    and Routine.global_variables in-place. Missing files surface as
    FileNotFoundError so the loader's per-ECU error handling reports them
    against the right ECU.

    Both application-domain (``did_c_files`` / ``rid_c_files``) and
    bootloader-domain (``boot_did_c_files`` / ``boot_rid_c_files``) sources
    are scanned against the same merged spec; the spec already carries
    ``domain`` tags from :func:`merge_boot_spec` so the rendered output can
    cite either side correctly.
    """
    if ecu.spec is None:
        return
    all_did_c = list(ecu.did_c_files) + list(ecu.boot_did_c_files)
    all_rid_c = list(ecu.rid_c_files) + list(ecu.boot_rid_c_files)
    if all_did_c:
        for p in all_did_c:
            if not p.exists():
                raise FileNotFoundError(
                    f"ECU {ecu.name!r}: DID C source not found: {p}"
                )
        from udsxml2tex.c_scanner import scan_did_variables
        scan_did_variables(all_did_c, ecu.spec.dids)
        logger.info("ECU %r: scanned %d DID C source(s) (app=%d, boot=%d)",
                    ecu.name, len(all_did_c),
                    len(ecu.did_c_files), len(ecu.boot_did_c_files))
    if all_rid_c:
        for p in all_rid_c:
            if not p.exists():
                raise FileNotFoundError(
                    f"ECU {ecu.name!r}: RID C source not found: {p}"
                )
        from udsxml2tex.c_scanner import scan_rid_variables
        scan_rid_variables(all_rid_c, ecu.spec.routines)
        logger.info("ECU %r: scanned %d RID C source(s) (app=%d, boot=%d)",
                    ecu.name, len(all_rid_c),
                    len(ecu.rid_c_files), len(ecu.boot_rid_c_files))
