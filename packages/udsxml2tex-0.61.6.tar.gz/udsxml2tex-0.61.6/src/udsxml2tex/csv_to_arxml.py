"""Generate an AUTOSAR Dcm ARXML skeleton from an OEM requirement CSV.

Use case
--------

In a typical OEM/Tier-1 split, the application team owns the drive-cycle
diagnostic ARXMLs (Dcm/CanTp/DEM) but the **bootloader** is contracted out
to an external team that delivers a binary only. The OEM ships a
requirement-analysis CSV (loaded via :func:`udsxml2tex.rtm.load_rtm_csv`)
that lists every SID / DID / RID / DTC / Session / SecurityLevel the boot
team must implement. Until the boot team's ARXML lands, the application
team has no way to render a unified Boot+App spec — they have to choose
between leaving the boot side empty or hand-writing a stub ARXML.

This module closes that gap. Given a list of :class:`RtmEntry`, it emits a
minimal but well-formed Dcm ARXML containing every traced element so:

* :class:`udsxml2tex.parser.ArxmlParser` can parse it back in,
* :func:`udsxml2tex.multi_ecu.loader.merge_boot_spec` can fold it into
  the application spec with ``domain="boot"`` / ``"both"`` tags,
* the result becomes a contract that the application team hands to the
  boot team (and that the boot team's eventual real ARXML must satisfy).

The generated ARXML is intentionally minimal — only enough metadata to
keep ``ArxmlParser`` happy. Timing parameters (P2/P2*), security key
sizes etc. are left to the boot team's real ARXML; this file is a
*requirements skeleton*, not a configuration delivery.

The function :func:`generate_arxml_from_rtm` is the only public entry
point. The CLI wrapper lives in :mod:`udsxml2tex.cli`
(``--gen-arxml-from-csv``).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Optional

from lxml import etree as _etree

from udsxml2tex.rtm import RtmEntry, RtmTrace

logger = logging.getLogger(__name__)

# Default identifier ranges considered "bootloader-domain" when the caller
# asks the generator to filter the CSV down to only boot-relevant rows.
# These come straight from ISO 14229-1: SID 0x34/0x35/0x36/0x37 are the
# upload/download family, RID 0xFF00 / 0xFF01 are eraseMemory and
# checkProgrammingDependencies, DID 0xF180-0xF1FF are the identification
# DIDs the tester reads during programming, session 0x02 is
# ProgrammingSession, and security level 0x01 is the only one strictly
# required before RequestDownload.
_BOOT_SIDS: frozenset[int] = frozenset({
    0x10,   # DiagnosticSessionControl — gateway to programming session
    0x11,   # ECUReset — required after flash
    0x22,   # ReadDataByIdentifier — for F18x identification DIDs
    0x27,   # SecurityAccess
    0x28,   # CommunicationControl (silence the bus during flash)
    0x31,   # RoutineControl — for eraseMemory / checkProgrammingDependencies
    0x34,   # RequestDownload
    0x35,   # RequestUpload
    0x36,   # TransferData
    0x37,   # RequestTransferExit
    0x3E,   # TesterPresent
    0x85,   # ControlDTCSetting (suppress DTC logging during flash)
})

# DID range observed in ISO 14229-1 Annex C.1 as identification DIDs
# (App SW version, fingerprint, ECU manufacturer SW version, …).
_BOOT_DID_RANGE: tuple[int, int] = (0xF180, 0xF1FF)

# Routine IDs reserved by ISO 14229-1 §C.4 for OEM-defined boot routines.
_BOOT_RID_RANGE: tuple[int, int] = (0xFF00, 0xFFFF)


def _is_boot_relevant_trace(trace: RtmTrace) -> bool:
    """Return True when *trace* is part of the bootloader-domain contract.

    Heuristic mirrors the ISO 14229-1 reprogramming sequence (Annex C):
    download/upload services, identification DID range, OEM-routine RID
    range, ProgrammingSession (0x02) and the first security level (0x01).
    """
    try:
        primary = int(trace.primary, 16)
    except (TypeError, ValueError):
        return False
    if trace.kind == "sid":
        return primary in _BOOT_SIDS
    if trace.kind == "did":
        return _BOOT_DID_RANGE[0] <= primary <= _BOOT_DID_RANGE[1]
    if trace.kind == "rid":
        return _BOOT_RID_RANGE[0] <= primary <= _BOOT_RID_RANGE[1]
    if trace.kind == "session":
        return primary == 0x02
    if trace.kind == "security":
        return primary in (0x01, 0x03, 0x05, 0x07, 0x09)  # odd = seed levels
    if trace.kind == "dtc":
        # Programming-related DTCs are not standardised; the caller can
        # opt-out of DTC filtering via domain_filter="all". For "boot"
        # we deliberately exclude DTCs because they are a DEM concern.
        return False
    return False


@dataclass
class _Collected:
    """Bucketed unique IDs gathered from an RtmEntry stream.

    Stored as ``{int_id: short_name}`` so the ARXML emitter can use a
    human-readable SHORT-NAME (taken from the first occurrence's
    ``resolved_name`` or the requirement description) when the CSV
    carries one.
    """
    sessions: dict[int, str] = field(default_factory=dict)
    security_levels: dict[int, str] = field(default_factory=dict)
    services: dict[int, str] = field(default_factory=dict)
    dids: dict[int, str] = field(default_factory=dict)
    rids: dict[int, str] = field(default_factory=dict)
    dtcs: dict[int, str] = field(default_factory=dict)


def _short_name_for(trace: RtmTrace, entry: RtmEntry, default_prefix: str) -> str:
    """Derive a SHORT-NAME for the ARXML container.

    Preference order:

    1. ``trace.resolved_name`` if the trace already resolved against an
       upstream spec (rare for a "we don't have the ARXML yet" workflow
       but cheap to honour).
    2. The requirement's req_id, lightly sanitised to satisfy the
       AUTOSAR SHORT-NAME identifier rules ([A-Za-z][A-Za-z0-9_]*).
    3. ``default_prefix`` + the hex id (e.g. ``Did_F184``).
    """
    if trace.resolved_name:
        return _sanitise_short_name(trace.resolved_name)
    if entry.req_id:
        cand = _sanitise_short_name(entry.req_id)
        if cand:
            return cand
    try:
        n = int(trace.primary, 16)
    except (TypeError, ValueError):
        return default_prefix
    width = 2 if trace.kind in ("sid", "session", "security") else 4
    if trace.kind == "dtc":
        width = 6
    return f"{default_prefix}_{n:0{width}X}"


def _sanitise_short_name(name: str) -> str:
    """Coerce *name* into the AUTOSAR SHORT-NAME regex [A-Za-z][A-Za-z0-9_]*.

    Replaces every disallowed character with ``_`` and prepends ``N_`` if
    the first character is not a letter. Returns ``""`` for an empty/all-
    invalid input so callers can fall back to a positional default.
    """
    if not name:
        return ""
    out_chars = []
    for ch in name:
        if ch.isalnum() or ch == "_":
            out_chars.append(ch)
        else:
            out_chars.append("_")
    out = "".join(out_chars).strip("_")
    if not out:
        return ""
    if not out[0].isalpha():
        out = "N_" + out
    return out


def _collect(entries: Iterable[RtmEntry], *,
             domain_filter: str) -> _Collected:
    """Walk *entries* and bucket their traces by element kind.

    ``domain_filter``:

    * ``"boot"``  — keep only traces matching :func:`_is_boot_relevant_trace`.
    * ``"drive"`` — keep only traces that **don't** match that heuristic.
    * ``"both"`` / ``"all"`` — keep every traced element.
    """
    coll = _Collected()
    for entry in entries:
        for tr in entry.traces_to:
            if domain_filter == "boot" and not _is_boot_relevant_trace(tr):
                continue
            if domain_filter == "drive" and _is_boot_relevant_trace(tr):
                continue
            try:
                primary = int(tr.primary, 16)
            except (TypeError, ValueError):
                continue
            if tr.kind == "session":
                coll.sessions.setdefault(primary,
                    _short_name_for(tr, entry, "Session"))
            elif tr.kind == "security":
                coll.security_levels.setdefault(primary,
                    _short_name_for(tr, entry, "SecurityLevel"))
            elif tr.kind == "sid":
                coll.services.setdefault(primary,
                    _short_name_for(tr, entry, "Service"))
            elif tr.kind == "did":
                coll.dids.setdefault(primary,
                    _short_name_for(tr, entry, "Did"))
            elif tr.kind == "rid":
                coll.rids.setdefault(primary,
                    _short_name_for(tr, entry, "Routine"))
            elif tr.kind == "dtc":
                coll.dtcs.setdefault(primary,
                    _short_name_for(tr, entry, "Dtc"))
    return coll


# ---------------------------------------------------------------------------
# ARXML emission
# ---------------------------------------------------------------------------

_AR_NS = "http://autosar.org/schema/r4.0"
_NSMAP = {None: _AR_NS}


def _el(tag: str, parent=None, text: Optional[str] = None, **attrs):
    """Tiny helper to keep the emitter readable."""
    e = _etree.SubElement(parent, f"{{{_AR_NS}}}{tag}", **attrs) if parent is not None \
        else _etree.Element(f"{{{_AR_NS}}}{tag}", nsmap=_NSMAP, **attrs)
    if text is not None:
        e.text = text
    return e


def _num_param(parent, def_ref: str, value: str) -> None:
    p = _el("ECUC-NUMERICAL-PARAM-VALUE", parent)
    _el("DEFINITION-REF", p, def_ref, attrib={"DEST": "ECUC-INTEGER-PARAM-DEF"})
    _el("VALUE", p, value)


def _emit_session_container(parent, level: int, short_name: str) -> None:
    cv = _el("ECUC-CONTAINER-VALUE", parent)
    _el("SHORT-NAME", cv, short_name)
    _el("DEFINITION-REF", cv,
        "/AUTOSAR/Dcm/DcmDsp/DcmDspSession/DcmDspSessionRow",
        attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})
    pv = _el("PARAMETER-VALUES", cv)
    _num_param(pv,
               "/AUTOSAR/Dcm/DcmDsp/DcmDspSession/DcmDspSessionLevel",
               str(level))


def _emit_security_container(parent, level: int, short_name: str) -> None:
    cv = _el("ECUC-CONTAINER-VALUE", parent)
    _el("SHORT-NAME", cv, short_name)
    _el("DEFINITION-REF", cv,
        "/AUTOSAR/Dcm/DcmDsp/DcmDspSecurity/DcmDspSecurityRow",
        attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})
    pv = _el("PARAMETER-VALUES", cv)
    _num_param(pv,
               "/AUTOSAR/Dcm/DcmDsp/DcmDspSecurity/DcmDspSecurityRow/DcmDspSecurityLevel",
               str(level))


def _emit_did_container(parent, did_id: int, short_name: str) -> None:
    cv = _el("ECUC-CONTAINER-VALUE", parent)
    _el("SHORT-NAME", cv, short_name)
    _el("DEFINITION-REF", cv,
        "/AUTOSAR/Dcm/DcmDsp/DcmDspDid",
        attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})
    pv = _el("PARAMETER-VALUES", cv)
    _num_param(pv,
               "/AUTOSAR/Dcm/DcmDsp/DcmDspDid/DcmDspDidIdentifier",
               f"0x{did_id:04X}")


def _emit_routine_container(parent, rid: int, short_name: str) -> None:
    cv = _el("ECUC-CONTAINER-VALUE", parent)
    _el("SHORT-NAME", cv, short_name)
    _el("DEFINITION-REF", cv,
        "/AUTOSAR/Dcm/DcmDsp/DcmDspRoutine",
        attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})
    pv = _el("PARAMETER-VALUES", cv)
    _num_param(pv,
               "/AUTOSAR/Dcm/DcmDsp/DcmDspRoutine/DcmDspRoutineIdentifier",
               f"0x{rid:04X}")


def _emit_sid_container(parent, sid: int, short_name: str) -> None:
    cv = _el("ECUC-CONTAINER-VALUE", parent)
    _el("SHORT-NAME", cv, short_name)
    _el("DEFINITION-REF", cv,
        "/AUTOSAR/Dcm/DcmDsd/DcmDsdServiceTable/DcmDsdService",
        attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})
    pv = _el("PARAMETER-VALUES", cv)
    _num_param(pv,
               "/AUTOSAR/Dcm/DcmDsd/DcmDsdServiceTable/DcmDsdService/DcmDsdSidTabServiceId",
               f"0x{sid:02X}")


def _emit_subcontainer_group(dcmdsp_subs, group_name: str,
                             def_path: str,
                             emit_fn, items: dict) -> None:
    """Emit one of DcmDspSession / DcmDspSecurity / DcmDspDid / DcmDspRoutine."""
    if not items:
        return
    grp = _el("ECUC-CONTAINER-VALUE", dcmdsp_subs)
    _el("SHORT-NAME", grp, group_name)
    _el("DEFINITION-REF", grp, def_path,
        attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})
    sub = _el("SUB-CONTAINERS", grp)
    # Stable order: lowest ID first.
    for key in sorted(items.keys()):
        emit_fn(sub, key, items[key])


def generate_arxml_from_rtm(
    entries: Iterable[RtmEntry],
    *,
    output_path: Optional[Path] = None,
    ecu_name: str = "BootECU",
    module_short_name: str = "DcmBootSkeleton",
    domain_filter: str = "boot",
) -> bytes:
    """Build an AUTOSAR Dcm ARXML skeleton from *entries* and (optionally)
    write it to *output_path*. Returns the serialised XML bytes regardless.

    Args:
        entries:           RtmEntry list (typically the output of
                           :func:`udsxml2tex.rtm.load_rtm_csv` /
                           :func:`load_rtm_csvs`).
        output_path:       Destination ``*.arxml`` path. ``None`` skips the
                           file write (useful for tests / in-memory use).
        ecu_name:          AR-PACKAGE SHORT-NAME at the top of the file —
                           customarily ``"<EcuName>EcuC"`` so an importer
                           can tell which ECU it belongs to.
        module_short_name: ECUC-MODULE-CONFIGURATION-VALUES SHORT-NAME.
        domain_filter:     ``"boot"`` (default), ``"drive"``, ``"both"`` /
                           ``"all"``. See :func:`_collect`.

    Returns:
        The serialised ARXML bytes (UTF-8, declaration + pretty-printed).

    Raises:
        ValueError: ``domain_filter`` is not one of the accepted values, or
                    the filter produced an empty skeleton (no traceable
                    elements). The caller should treat the latter as a
                    requirements-analysis problem to surface to the user.
    """
    if domain_filter not in {"boot", "drive", "both", "all"}:
        raise ValueError(
            f"domain_filter must be one of boot/drive/both/all, "
            f"got {domain_filter!r}"
        )
    collected = _collect(list(entries), domain_filter=domain_filter)
    total = (
        len(collected.sessions) + len(collected.security_levels)
        + len(collected.services) + len(collected.dids)
        + len(collected.rids) + len(collected.dtcs)
    )
    if total == 0:
        raise ValueError(
            "CSV produced no traceable elements after domain filter "
            f"{domain_filter!r}. Check that the CSV's traces_to column "
            "carries at least one sid:/did:/rid:/session:/security: token "
            "matching the chosen domain."
        )

    # --- Build XML tree ---
    autosar = _el("AUTOSAR")
    autosar.set(
        "{http://www.w3.org/2001/XMLSchema-instance}schemaLocation",
        "http://autosar.org/schema/r4.0 AUTOSAR_4-3-0.xsd",
    )
    ar_packages = _el("AR-PACKAGES", autosar)
    pkg = _el("AR-PACKAGE", ar_packages)
    pkg_short_name = _sanitise_short_name(ecu_name) or "BootECU"
    if not pkg_short_name.endswith("EcuC"):
        pkg_short_name = pkg_short_name + "EcuC"
    _el("SHORT-NAME", pkg, pkg_short_name)
    sub_pkgs = _el("AR-PACKAGES", pkg)
    dcm_pkg = _el("AR-PACKAGE", sub_pkgs)
    _el("SHORT-NAME", dcm_pkg, "Dcm")
    elements = _el("ELEMENTS", dcm_pkg)

    module = _el("ECUC-MODULE-CONFIGURATION-VALUES", elements)
    _el("SHORT-NAME", module, _sanitise_short_name(module_short_name)
        or "DcmBootSkeleton")
    _el("DEFINITION-REF", module,
        "/AUTOSAR/Dcm",
        attrib={"DEST": "ECUC-MODULE-DEF"})
    containers = _el("CONTAINERS", module)

    # ----- DcmDsd (services) ------------------------------------------------
    if collected.services:
        dcmdsd = _el("ECUC-CONTAINER-VALUE", containers)
        _el("SHORT-NAME", dcmdsd, "DcmDsd")
        _el("DEFINITION-REF", dcmdsd, "/AUTOSAR/Dcm/DcmDsd",
            attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})
        dsd_subs = _el("SUB-CONTAINERS", dcmdsd)
        svc_tbl = _el("ECUC-CONTAINER-VALUE", dsd_subs)
        _el("SHORT-NAME", svc_tbl, "DcmDsdServiceTable")
        _el("DEFINITION-REF", svc_tbl,
            "/AUTOSAR/Dcm/DcmDsd/DcmDsdServiceTable",
            attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})
        svc_subs = _el("SUB-CONTAINERS", svc_tbl)
        for sid in sorted(collected.services.keys()):
            _emit_sid_container(svc_subs, sid, collected.services[sid])

    # ----- DcmDsp (sessions / security / DIDs / routines) ------------------
    dcmdsp = _el("ECUC-CONTAINER-VALUE", containers)
    _el("SHORT-NAME", dcmdsp, "DcmDsp")
    _el("DEFINITION-REF", dcmdsp, "/AUTOSAR/Dcm/DcmDsp",
        attrib={"DEST": "ECUC-PARAM-CONF-CONTAINER-DEF"})
    dsp_subs = _el("SUB-CONTAINERS", dcmdsp)

    _emit_subcontainer_group(
        dsp_subs, "DcmDspSession",
        "/AUTOSAR/Dcm/DcmDsp/DcmDspSession",
        _emit_session_container, collected.sessions,
    )
    _emit_subcontainer_group(
        dsp_subs, "DcmDspSecurity",
        "/AUTOSAR/Dcm/DcmDsp/DcmDspSecurity",
        _emit_security_container, collected.security_levels,
    )
    _emit_subcontainer_group(
        dsp_subs, "DcmDspDid",
        "/AUTOSAR/Dcm/DcmDsp/DcmDspDid",
        _emit_did_container, collected.dids,
    )
    _emit_subcontainer_group(
        dsp_subs, "DcmDspRoutine",
        "/AUTOSAR/Dcm/DcmDsp/DcmDspRoutine",
        _emit_routine_container, collected.rids,
    )

    # DTCs need a DEM ARXML, not Dcm — emit them as a top-level comment so the
    # user knows they were not lost. (Generating a full DEM skeleton is out
    # of scope for the boot-handoff workflow; the DEM remains an OEM/Tier-1
    # joint responsibility.)
    if collected.dtcs:
        comment = _etree.Comment(
            " DTCs referenced by the CSV but not emitted here (DEM is a "
            "separate ARXML): "
            + ", ".join(f"0x{n:06X}" for n in sorted(collected.dtcs.keys()))
        )
        module.addprevious(comment)

    xml_bytes = _etree.tostring(
        autosar, xml_declaration=True, encoding="UTF-8", pretty_print=True,
    )
    if output_path is not None:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_bytes(xml_bytes)
        logger.info(
            "csv_to_arxml: wrote %s "
            "(%d service(s), %d session(s), %d security level(s), "
            "%d DID(s), %d routine(s); %d DTC(s) noted as comment)",
            output_path,
            len(collected.services), len(collected.sessions),
            len(collected.security_levels), len(collected.dids),
            len(collected.rids), len(collected.dtcs),
        )
    return xml_bytes
