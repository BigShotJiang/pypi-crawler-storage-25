"""Best-effort processing-unit auto-detection for local LLM bootstrap.

Reports CPU cores, total RAM, discrete/integrated GPUs and any NPU
chips the host advertises. Used by:

- ``/chat/system-info`` — the Chat tab shows the detected hardware
  and recommends a model size that fits combined RAM + VRAM.
- ``ollama_setup.start_serve`` — derives ``OLLAMA_NUM_THREAD``,
  ``OLLAMA_FLASH_ATTENTION`` and ``OLLAMA_LLM_LIBRARY`` so the
  spawned ``ollama serve`` actually exercises the most capable
  backend present on the box.

Everything in this module is best-effort: when a probe fails (no
``nvidia-smi``, no Apple Silicon, etc.) it returns an empty list
rather than raising — the caller never has to guard against
``ImportError`` / ``FileNotFoundError`` themselves.

Important reality check on NPUs: Ollama's underlying llama.cpp
runtime as of 2026-Q2 still routes through CPU (AVX/NEON) or GPU
(CUDA / ROCm / Metal) backends. Apple's ANE, Intel Core Ultra NPU
and Qualcomm Hexagon NPU are detected and reported for transparency,
but Ollama does **not** dispatch tensor ops onto them — the UI must
say so to avoid raising user expectations.
"""

from __future__ import annotations

import json
import logging
import os
import platform
import re
import shutil
import subprocess
from dataclasses import dataclass, field, asdict
from typing import Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class CpuInfo:
    brand: str = ""
    logical_cores: int = 0
    physical_cores: int = 0
    arch: str = ""


@dataclass
class GpuInfo:
    vendor: str       # "nvidia" | "amd" | "apple" | "intel"
    name: str
    vram_gb: float = 0.0
    backend: str = ""  # "cuda" | "rocm" | "metal" | "opencl"


@dataclass
class NpuInfo:
    vendor: str        # "apple" | "intel" | "qualcomm" | "amd"
    name: str
    ollama_supported: bool = False  # llama.cpp NPU support is still nascent


@dataclass
class HardwareReport:
    cpu: CpuInfo = field(default_factory=CpuInfo)
    ram_gb: float = 0.0
    gpus: list[GpuInfo] = field(default_factory=list)
    npus: list[NpuInfo] = field(default_factory=list)

    @property
    def total_vram_gb(self) -> float:
        return sum(g.vram_gb for g in self.gpus)

    @property
    def effective_memory_gb(self) -> float:
        """RAM available for a CPU model OR VRAM (whichever Ollama
        will actually use for the loaded weights). When a discrete
        GPU is present the larger of (VRAM, RAM) governs the
        recommendation; on integrated/Apple Silicon, system RAM is
        shared with the GPU so we use RAM alone."""
        if not self.gpus:
            return self.ram_gb
        # On Apple Silicon, "VRAM" is just system RAM — don't double-count.
        if any(g.vendor == "apple" for g in self.gpus):
            return self.ram_gb
        # Discrete GPU(s) — pick the most capable single device's VRAM
        # since Ollama loads each model into one device.
        return max(self.total_vram_gb, self.ram_gb)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["total_vram_gb"] = round(self.total_vram_gb, 1)
        d["effective_memory_gb"] = round(self.effective_memory_gb, 1)
        return d


# ---------------------------------------------------------------------------
# CPU
# ---------------------------------------------------------------------------

def _detect_cpu() -> CpuInfo:
    logical = os.cpu_count() or 0
    physical = 0
    try:
        import psutil  # type: ignore[import-untyped]
        physical = psutil.cpu_count(logical=False) or 0
    except Exception:  # noqa: BLE001
        pass
    if not physical:
        physical = logical  # safe fallback — over-threading is the lesser evil
    brand = ""
    try:
        if platform.system() == "Darwin":
            brand = subprocess.check_output(
                ["sysctl", "-n", "machdep.cpu.brand_string"],
                text=True, timeout=2.0,
            ).strip()
        elif platform.system() == "Linux":
            try:
                with open("/proc/cpuinfo") as f:
                    for line in f:
                        if line.startswith("model name"):
                            brand = line.split(":", 1)[1].strip()
                            break
            except FileNotFoundError:
                pass
        elif platform.system() == "Windows":
            out = subprocess.check_output(
                ["wmic", "cpu", "get", "name"],
                text=True, timeout=4.0,
            )
            lines = [line.strip() for line in out.splitlines() if line.strip()]
            if len(lines) >= 2:
                brand = lines[1]
    except Exception:  # noqa: BLE001
        pass
    return CpuInfo(
        brand=brand,
        logical_cores=logical,
        physical_cores=physical,
        arch=platform.machine(),
    )


# ---------------------------------------------------------------------------
# RAM
# ---------------------------------------------------------------------------

def _detect_ram_gb() -> float:
    try:
        import psutil  # type: ignore[import-untyped]
        return psutil.virtual_memory().total / (1024 ** 3)
    except Exception:  # noqa: BLE001
        pass
    try:
        if platform.system() == "Darwin":
            out = subprocess.check_output(
                ["sysctl", "-n", "hw.memsize"], text=True, timeout=2.0,
            )
            return int(out.strip()) / (1024 ** 3)
        if platform.system() == "Linux":
            with open("/proc/meminfo") as f:
                for line in f:
                    if line.startswith("MemTotal:"):
                        return int(line.split()[1]) / (1024 ** 2)
    except Exception:  # noqa: BLE001
        pass
    return 0.0


# ---------------------------------------------------------------------------
# GPU probes (vendor-specific, all best-effort)
# ---------------------------------------------------------------------------

def _which(name: str) -> Optional[str]:
    return shutil.which(name)


def _detect_nvidia() -> list[GpuInfo]:
    nvidia_smi = _which("nvidia-smi")
    if not nvidia_smi:
        return []
    try:
        out = subprocess.check_output(
            [nvidia_smi,
             "--query-gpu=name,memory.total",
             "--format=csv,noheader,nounits"],
            text=True, timeout=4.0,
        )
    except Exception:  # noqa: BLE001
        return []
    gpus: list[GpuInfo] = []
    for line in out.strip().splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) < 2:
            continue
        try:
            vram_mib = float(parts[1])
        except ValueError:
            vram_mib = 0.0
        gpus.append(GpuInfo(
            vendor="nvidia",
            name=parts[0],
            vram_gb=round(vram_mib / 1024.0, 1),
            backend="cuda",
        ))
    return gpus


def _detect_amd() -> list[GpuInfo]:
    rocm_smi = _which("rocm-smi")
    if not rocm_smi:
        return []
    try:
        out = subprocess.check_output(
            [rocm_smi, "--showproductname", "--showmeminfo", "vram", "--json"],
            text=True, timeout=4.0,
        )
        data = json.loads(out)
    except Exception:  # noqa: BLE001
        return []
    gpus: list[GpuInfo] = []
    for card_id, card in data.items():
        if not isinstance(card, dict):
            continue
        name = card.get("Card series", card.get("Card model", card_id))
        vram_b_str = card.get("VRAM Total Memory (B)", "0")
        try:
            vram_b = int(vram_b_str)
        except ValueError:
            vram_b = 0
        gpus.append(GpuInfo(
            vendor="amd",
            name=name,
            vram_gb=round(vram_b / (1024 ** 3), 1),
            backend="rocm",
        ))
    return gpus


def _detect_apple() -> list[GpuInfo]:
    if platform.system() != "Darwin":
        return []
    if platform.machine() not in ("arm64", "aarch64"):
        # Intel Mac — no unified-memory Metal GPU worth offloading to here.
        return []
    # On Apple Silicon, the GPU shares system RAM. We report it
    # as a single device whose "VRAM" equals total RAM so the caller
    # can pick a model that fits.
    try:
        chip = subprocess.check_output(
            ["sysctl", "-n", "machdep.cpu.brand_string"],
            text=True, timeout=2.0,
        ).strip()
    except Exception:  # noqa: BLE001
        chip = "Apple Silicon"
    return [GpuInfo(
        vendor="apple",
        name=chip,
        vram_gb=round(_detect_ram_gb(), 1),
        backend="metal",
    )]


def _detect_gpus() -> list[GpuInfo]:
    out: list[GpuInfo] = []
    out.extend(_detect_nvidia())
    out.extend(_detect_amd())
    out.extend(_detect_apple())
    return out


# ---------------------------------------------------------------------------
# NPU probes — informational only, Ollama does not use these yet
# ---------------------------------------------------------------------------

def _detect_apple_ane() -> list[NpuInfo]:
    if platform.system() != "Darwin":
        return []
    if platform.machine() not in ("arm64", "aarch64"):
        return []
    # Every Apple Silicon Mac ships with a 16-core ANE. Reporting it
    # so the UI can be transparent about why it isn't being driven.
    try:
        chip = subprocess.check_output(
            ["sysctl", "-n", "machdep.cpu.brand_string"],
            text=True, timeout=2.0,
        ).strip()
    except Exception:  # noqa: BLE001
        chip = "Apple Silicon"
    return [NpuInfo(
        vendor="apple",
        name=f"{chip} Apple Neural Engine",
        ollama_supported=False,
    )]


def _detect_intel_npu() -> list[NpuInfo]:
    if platform.system() != "Linux":
        return []
    # Intel Core Ultra exposes the NPU as /dev/accel/accel0 (intel_vpu driver).
    if os.path.exists("/dev/accel/accel0"):
        return [NpuInfo(
            vendor="intel",
            name="Intel Core Ultra NPU (VPU)",
            ollama_supported=False,
        )]
    return []


def _detect_qualcomm_npu() -> list[NpuInfo]:
    # Snapdragon X / 8cx Windows-on-ARM laptops surface the Hexagon NPU
    # via the "Qualcomm Hexagon AI Engine" device. We can only see it
    # on Windows via WMI; skip for now and rely on a CPU brand check.
    cpu = _detect_cpu()
    if "Snapdragon" in cpu.brand or "Hexagon" in cpu.brand:
        return [NpuInfo(
            vendor="qualcomm",
            name="Qualcomm Hexagon NPU",
            ollama_supported=False,
        )]
    return []


def _detect_npus() -> list[NpuInfo]:
    out: list[NpuInfo] = []
    out.extend(_detect_apple_ane())
    out.extend(_detect_intel_npu())
    out.extend(_detect_qualcomm_npu())
    return out


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def detect() -> HardwareReport:
    """Run every probe and assemble a :class:`HardwareReport`."""
    return HardwareReport(
        cpu=_detect_cpu(),
        ram_gb=round(_detect_ram_gb(), 1),
        gpus=_detect_gpus(),
        npus=_detect_npus(),
    )


def recommended_model(report: HardwareReport) -> tuple[str, str]:
    """Pick a Qwen2.5 size class that fits the box.

    Returns ``(size_label, model_tag)``. The threshold table mirrors
    Ollama's published per-quantization VRAM/RAM footprints (Q4_K_M):

    - 70B  ~ 48 GB
    - 32B  ~ 22 GB
    - 14B  ~ 10 GB
    - 7B   ~ 6 GB
    - 3B   ~ 3 GB
    """
    eff = report.effective_memory_gb
    if eff <= 0:
        return "7b", "qwen2.5:7b"
    if eff >= 64:
        return "70b", "qwen2.5:72b"
    if eff >= 32:
        return "32b", "qwen2.5:32b"
    if eff >= 16:
        return "13b", "qwen2.5:14b"
    if eff >= 8:
        return "7b", "qwen2.5:7b"
    return "3b", "qwen2.5:3b"


def ollama_env_overrides(report: Optional[HardwareReport] = None) -> dict[str, str]:
    """Build the env-var overrides that maximise Ollama's hardware use.

    Returns a dict suitable for merging into ``os.environ`` before
    spawning ``ollama serve``. Variables set:

    - ``OLLAMA_NUM_THREAD`` — physical CPU cores (over-threading
      degrades llama.cpp throughput on most hosts).
    - ``OLLAMA_FLASH_ATTENTION=1`` — enable when an NVIDIA Ampere+
      or Apple Silicon GPU is present.
    - ``OLLAMA_LLM_LIBRARY`` — force the strongest available backend
      so multi-GPU boxes don't fall back to CPU when CUDA can't
      probe one card.

    Returns ``{}`` when nothing is worth overriding.
    """
    r = report or detect()
    env: dict[str, str] = {}
    if r.cpu.physical_cores:
        env["OLLAMA_NUM_THREAD"] = str(r.cpu.physical_cores)
    if r.gpus:
        # Flash-attention is supported on Ampere (sm_80+) and on
        # Apple Silicon (Metal). For AMD ROCm it depends on
        # gfx9xx — leave the user to opt in.
        if any(g.vendor in {"nvidia", "apple"} for g in r.gpus):
            env["OLLAMA_FLASH_ATTENTION"] = "1"
        # Steer Ollama to the right backend explicitly.
        if any(g.vendor == "nvidia" for g in r.gpus):
            env["OLLAMA_LLM_LIBRARY"] = "cuda"
        elif any(g.vendor == "apple" for g in r.gpus):
            env["OLLAMA_LLM_LIBRARY"] = "metal"
        elif any(g.vendor == "amd" for g in r.gpus):
            env["OLLAMA_LLM_LIBRARY"] = "rocm"
    return env


def summarize_for_ui(report: Optional[HardwareReport] = None) -> dict:
    r = report or detect()
    size, model = recommended_model(r)
    d = r.to_dict()
    d["recommended_size"] = size
    d["recommended_model"] = model
    d["ollama_env_overrides"] = ollama_env_overrides(r)
    return d


__all__ = [
    "CpuInfo",
    "GpuInfo",
    "NpuInfo",
    "HardwareReport",
    "detect",
    "recommended_model",
    "ollama_env_overrides",
    "summarize_for_ui",
]
