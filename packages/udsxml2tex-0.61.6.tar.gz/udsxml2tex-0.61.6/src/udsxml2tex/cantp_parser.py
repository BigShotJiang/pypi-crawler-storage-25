"""ARXML parser for AUTOSAR CanTp module configuration."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from lxml import etree

from udsxml2tex.models import CanTpChannel, CanTpConfig
from udsxml2tex.parser import _detect_namespace, _xpath, _xpath_text

logger = logging.getLogger(__name__)


class CanTpParser:
    """Parser for AUTOSAR CanTp ARXML files."""

    def __init__(self) -> None:
        self.ns: dict[str, str] = {}
        self.root: Optional[etree._Element] = None

    def parse(self, arxml_path: str | Path) -> CanTpConfig:
        """Parse a CanTp ARXML file and return transport configuration.

        Args:
            arxml_path: Path to the ARXML file.

        Returns:
            CanTpConfig with all parsed channel data.
        """
        arxml_path = Path(arxml_path)
        if not arxml_path.exists():
            raise FileNotFoundError(f"ARXML file not found: {arxml_path}")

        logger.info("Parsing CanTp ARXML file: %s", arxml_path)

        parser = etree.XMLParser(remove_blank_text=True, remove_comments=True)
        tree = etree.parse(str(arxml_path), parser)
        self.root = tree.getroot()
        self.ns = _detect_namespace(self.root)

        config = CanTpConfig()

        self._parse_general(config)
        self._parse_channels(config)

        logger.info("Parsed CanTp: %d channels", len(config.channels))

        return config

    def _parse_general(self, config: CanTpConfig) -> None:
        """Parse CanTpGeneral container for global settings."""
        assert self.root is not None

        # MainFunctionPeriod
        for path in [
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'CanTpGeneral')]",
            ".//ar:CONTAINER[contains(ar:SHORT-NAME/text(), 'CanTpGeneral')]",
        ]:
            containers = _xpath(self.root, path, self.ns)
            if containers:
                general = containers[0]
                period = self._get_param_float(
                    general, "CanTpMainFunctionPeriod", 0.005
                )
                config.main_function_period = period
                # CanTpCanFdEnabled (vendor alias of CanTpFlexibleDataRateSupport)
                fd_text = self._get_param_text(general, "CanTpCanFdEnabled")
                if not fd_text:
                    fd_text = self._get_param_text(
                        general, "CanTpFlexibleDataRateSupport"
                    )
                config.can_fd_enabled = fd_text.lower() in ("true", "1", "on")
                wft = self._get_param_int(
                    general, "CanTpWftMax", 0
                )
                config.wft_max = wft
                # Accept both vendor `CanTpChangeParmApi` and AUTOSAR
                # `CanTpChangeParameterApi`.
                change_parm = self._get_param_bool(
                    general, "CanTpChangeParmApi", False
                ) or self._get_param_bool(
                    general, "CanTpChangeParameterApi", False
                )
                config.change_parm_api = change_parm
                tc = self._get_param_bool(
                    general, "CanTpTc", False
                )
                config.tc = tc
                det = self._get_param_bool(
                    general, "CanTpDevErrorDetect", False
                )
                config.dev_error_detect = det
                ver = self._get_param_bool(
                    general, "CanTpVersionInfoApi", False
                )
                config.version_info_api = ver
                pad = self._get_param_int(
                    general, "CanTpPaddingByte", 0xFF
                )
                config.padding_byte = pad
                # ISO 15765-2 gap-closure additions:
                # CanTpReadParameterApi (ECUC_CanTp_00300)
                config.read_parameter_api = self._get_param_bool(
                    general, "CanTpReadParameterApi", False
                )
                # CanTpDynIdSupport (ECUC_CanTp_00302)
                config.dyn_id_support = self._get_param_bool(
                    general, "CanTpDynIdSupport", False
                )
                # CanTpGenericConnectionSupport (ECUC_CanTp_00303)
                config.generic_connection_support = self._get_param_bool(
                    general, "CanTpGenericConnectionSupport", False
                )
                # CanTpMaxChannelCnt (ECUC_CanTp_00304)
                config.max_channel_cnt = self._get_param_int_optional(
                    general, "CanTpMaxChannelCnt"
                )
                break

    def _parse_channels(self, config: CanTpConfig) -> None:
        """Parse CanTpChannel containers."""
        assert self.root is not None

        # Find CanTpChannel containers
        channel_containers = self._find_containers("CanTpChannel")

        for container in channel_containers:
            short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not short_name or short_name == "CanTpChannel":
                # Parent container — look at sub-containers
                subs = _xpath(
                    container,
                    "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                )
                for sub in subs:
                    self._parse_single_channel(sub, config)
                continue
            self._parse_single_channel(container, config)

    def _parse_single_channel(
        self, container: etree._Element, config: CanTpConfig
    ) -> None:
        """Parse a single CanTpChannel or CanTpRxNSdu/CanTpTxNSdu container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name:
            return

        channel_mode = self._get_param_text(
            container, "CanTpChannelMode", "FULL_DUPLEX"
        )

        # Parse RxNSdu and TxNSdu sub-containers
        rx_sdus = self._find_sub_containers(container, "CanTpRxNSdu")
        tx_sdus = self._find_sub_containers(container, "CanTpTxNSdu")

        # If this container itself has CanTp parameters, treat it as a channel
        if not rx_sdus and not tx_sdus:
            channel = self._build_channel_from_container(container, short_name)
            channel.channel_mode = channel_mode
            config.channels.append(channel)
            return

        # Build channels from Rx/Tx NSdu pairs
        for rx_sdu in rx_sdus:
            rx_name = _xpath_text(rx_sdu, "ar:SHORT-NAME", self.ns) or short_name
            channel = self._build_channel_from_rx_sdu(rx_sdu, rx_name)
            channel.channel_mode = channel_mode

            # Try to find matching Tx NSdu
            for tx_sdu in tx_sdus:
                self._enrich_with_tx_sdu(channel, tx_sdu)

            config.channels.append(channel)

        # If only TxNSdu exists (no RxNSdu), still capture it
        if not rx_sdus and tx_sdus:
            for tx_sdu in tx_sdus:
                tx_name = _xpath_text(tx_sdu, "ar:SHORT-NAME", self.ns) or short_name
                channel = CanTpChannel(short_name=tx_name)
                channel.channel_mode = channel_mode
                self._enrich_with_tx_sdu(channel, tx_sdu)
                config.channels.append(channel)

    def _build_channel_from_container(
        self, container: etree._Element, name: str
    ) -> CanTpChannel:
        """Build a CanTpChannel directly from parameter values."""
        return CanTpChannel(
            short_name=name,
            bs=self._get_param_int(container, "CanTpBs", 0),
            stmin=self._get_param_float(container, "CanTpSTmin", 0.0),
            n_as=self._get_param_float(container, "CanTpNas", 0.0),
            n_bs=self._get_param_float(container, "CanTpNbs", 0.0),
            n_cs=self._get_param_float(container, "CanTpNcs", 0.0),
            n_ar=self._get_param_float(container, "CanTpNar", 0.0),
            n_br=self._get_param_float(container, "CanTpNbr", 0.0),
            n_cr=self._get_param_float(container, "CanTpNcr", 0.0),
            padding_activation=self._get_param_bool(
                container, "CanTpPaddingActivation", True
            ),
            padding_byte=self._get_param_int(container, "CanTpPaddingByte", 0xFF),
            max_data_length=self._get_param_int(container, "CanTpDl", 8),
            rx_addressing_format=self._get_param_text(
                container, "CanTpRxAddressingFormat", "STANDARD"
            ),
            tx_addressing_format=self._get_param_text(
                container, "CanTpTxAddressingFormat", "STANDARD"
            ),
            rx_ta_type=self._get_param_text(
                container, "CanTpRxTaType", ""
            ),
            tx_ta_type=self._get_param_text(
                container, "CanTpTxTaType", ""
            ),
            rx_nsa=self._get_param_int(container, "CanTpRxNSa", 0),
            rx_nta=self._get_param_int(container, "CanTpRxNTa", 0),
            rx_fc_dl=self._get_param_int(container, "CanTpRxFcDl", 0),
            tx_fc_dl=self._get_param_int(container, "CanTpTxFcDl", 0),
        )

    def _build_channel_from_rx_sdu(
        self, rx_sdu: etree._Element, name: str
    ) -> CanTpChannel:
        """Build a CanTpChannel from an RxNSdu container."""
        rx_pdu_id = self._get_param_text(rx_sdu, "CanTpRxNPduId") or self._get_ref(
            rx_sdu, "CanTpRxNPduRef"
        )
        addressing = self._get_param_text(
            rx_sdu, "CanTpRxAddressingFormat", "STANDARD"
        )
        bs = self._get_param_int(rx_sdu, "CanTpBs", 0)
        stmin = self._get_param_float(rx_sdu, "CanTpSTmin", 0.0)
        n_ar = self._get_param_float(rx_sdu, "CanTpNar", 0.0)
        n_br = self._get_param_float(rx_sdu, "CanTpNbr", 0.0)
        n_cr = self._get_param_float(rx_sdu, "CanTpNcr", 0.0)
        padding = self._get_param_bool(rx_sdu, "CanTpPaddingActivation", True)
        padding_byte = self._get_param_int(rx_sdu, "CanTpPaddingByte", 0xFF)
        dl = self._get_param_int(rx_sdu, "CanTpDl") or self._get_param_int(
            rx_sdu, "CanTpRxDl", 8
        )

        channel = CanTpChannel(
            short_name=name,
            rx_pdu_id=rx_pdu_id or "",
            rx_addressing_format=addressing,
            bs=bs,
            stmin=stmin,
            n_ar=n_ar,
            n_br=n_br,
            n_cr=n_cr,
            padding_activation=padding,
            padding_byte=padding_byte,
            max_data_length=dl,
            rx_ta_type=self._get_param_text(rx_sdu, "CanTpRxTaType", ""),
            rx_nsa=self._get_param_int(rx_sdu, "CanTpRxNSa", 0),
            rx_nta=self._get_param_int(rx_sdu, "CanTpRxNTa", 0),
            rx_fc_dl=self._get_param_int(rx_sdu, "CanTpRxFcDl", 0),
        )

        # ISO 15765-2 gap-closure: per-RxNSdu identifiers, references, and
        # WFTmax. Each is optional in the ARXML so missing values leave the
        # field at its dataclass default.
        channel.rx_nsdu_id = self._get_param_int_optional(rx_sdu, "CanTpRxNSduId")
        nsdu_ref = self._get_ref(rx_sdu, "CanTpRxNSduRef")
        if nsdu_ref:
            channel.rx_nsdu_ref = nsdu_ref
        channel.rx_wft_max = self._get_param_int_optional(rx_sdu, "CanTpRxWftMax")

        # CanTpNAe sub-container holds the NL_AE byte for mixed addressing.
        nae_subs = self._find_sub_containers(rx_sdu, "CanTpNAe")
        if nae_subs:
            channel.rx_nae = self._get_param_int_optional(nae_subs[0], "CanTpNAe")

        # CanTpRxFcNPdu sub-container — the Rx-side flow-control PDU (ISO
        # 15765-2 §9.4.5).  Holds CanTpRxFcNPduId and CanTpRxFcNPduRef.
        fc_subs = self._find_sub_containers(rx_sdu, "CanTpRxFcNPdu")
        if fc_subs:
            fc = fc_subs[0]
            fc_id = self._get_param_text(fc, "CanTpRxFcNPduId")
            if fc_id:
                channel.rx_fc_pdu_id = fc_id
            fc_ref = self._get_ref(fc, "CanTpRxFcNPduRef")
            if fc_ref:
                channel.rx_fc_pdu_ref = fc_ref

        return channel

    def _enrich_with_tx_sdu(
        self, channel: CanTpChannel, tx_sdu: etree._Element
    ) -> None:
        """Add TxNSdu information to an existing channel."""
        tx_pdu_id = self._get_param_text(tx_sdu, "CanTpTxNPduId") or self._get_ref(
            tx_sdu, "CanTpTxNPduRef"
        )
        if tx_pdu_id:
            channel.tx_pdu_id = tx_pdu_id

        addressing = self._get_param_text(tx_sdu, "CanTpTxAddressingFormat")
        if addressing:
            channel.tx_addressing_format = addressing

        n_as = self._get_param_float(tx_sdu, "CanTpNas")
        if n_as:
            channel.n_as = n_as
        n_bs = self._get_param_float(tx_sdu, "CanTpNbs")
        if n_bs:
            channel.n_bs = n_bs
        n_cs = self._get_param_float(tx_sdu, "CanTpNcs")
        if n_cs:
            channel.n_cs = n_cs

        tx_ta = self._get_param_text(tx_sdu, "CanTpTxTaType")
        if tx_ta:
            channel.tx_ta_type = tx_ta

        tx_nsa = self._get_param_int(tx_sdu, "CanTpTxNSa")
        if tx_nsa:
            channel.tx_nsa = tx_nsa
        tx_nta = self._get_param_int(tx_sdu, "CanTpTxNTa")
        if tx_nta:
            channel.tx_nta = tx_nta

        tx_fc_dl = self._get_param_int(tx_sdu, "CanTpTxFcDl")
        if tx_fc_dl:
            channel.tx_fc_dl = tx_fc_dl

        # ISO 15765-2 gap-closure: per-TxNSdu identifiers, references, padding
        # and FC routing.
        tx_id = self._get_param_int_optional(tx_sdu, "CanTpTxNSduId")
        if tx_id is not None:
            channel.tx_nsdu_id = tx_id
        tx_nsdu_ref = self._get_ref(tx_sdu, "CanTpTxNSduRef")
        if tx_nsdu_ref:
            channel.tx_nsdu_ref = tx_nsdu_ref

        # CanTpTxPaddingActivation (ECUC_CanTp_00269) — separate from Rx.
        tx_pad_text = self._get_param_text(tx_sdu, "CanTpTxPaddingActivation")
        if tx_pad_text:
            channel.tx_padding_activation = tx_pad_text.lower() in (
                "true",
                "1",
                "on",
                "cantp_on",
            )

        # CanTpNAe sub-container on Tx side
        nae_subs = self._find_sub_containers(tx_sdu, "CanTpNAe")
        if nae_subs:
            nae_val = self._get_param_int_optional(nae_subs[0], "CanTpNAe")
            if nae_val is not None:
                channel.tx_nae = nae_val

        # CanTpTxFcNPdu sub-container — Tx-side flow-control PDU.
        fc_subs = self._find_sub_containers(tx_sdu, "CanTpTxFcNPdu")
        if fc_subs:
            fc = fc_subs[0]
            fc_id = self._get_param_text(fc, "CanTpTxFcNPduConfirmationPduId")
            if fc_id:
                channel.tx_fc_pdu_id = fc_id
            fc_ref = self._get_ref(fc, "CanTpTxFcNPduRef")
            if fc_ref:
                channel.tx_fc_pdu_ref = fc_ref

    # ---- Helper methods ----

    def _find_containers(self, name: str) -> list:
        """Find ECUC container values by SHORT-NAME."""
        assert self.root is not None
        patterns = [
            f".//ar:ECUC-CONTAINER-VALUE[ar:SHORT-NAME='{name}']",
            f".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), '{name}')]",
            f".//ar:CONTAINER[ar:SHORT-NAME='{name}']",
            f".//ar:CONTAINER[contains(ar:SHORT-NAME/text(), '{name}')]",
        ]
        for pattern in patterns:
            found = _xpath(self.root, pattern, self.ns)
            if found:
                return found
        return []

    def _find_sub_containers(
        self, parent: etree._Element, name: str
    ) -> list:
        """Find sub-containers by SHORT-NAME within a parent."""
        patterns = [
            f".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), '{name}')]",
            f"ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), '{name}')]",
        ]
        for pattern in patterns:
            found = _xpath(parent, pattern, self.ns)
            if found:
                return found
        return []

    def _get_param_int(
        self, container: etree._Element, param_name: str, default: int = 0
    ) -> int:
        """Get integer parameter value."""
        for path in [
            f".//ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
            f".//ar:PARAMETER-VALUES/ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
        ]:
            text = _xpath_text(container, path, self.ns)
            if text:
                try:
                    if text.startswith("0x") or text.startswith("0X"):
                        return int(text, 16)
                    return int(float(text))
                except ValueError:
                    pass
        return default

    def _get_param_int_optional(
        self, container: etree._Element, param_name: str
    ) -> Optional[int]:
        """Get integer parameter value or None when the parameter is absent.

        Useful for fields where 0 is a legal value distinct from "not
        configured" (e.g. CanTpRxNSduId, CanTpMaxChannelCnt).
        """
        for path in [
            f".//ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
            f".//ar:PARAMETER-VALUES/ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
        ]:
            text = _xpath_text(container, path, self.ns)
            if text:
                try:
                    if text.startswith("0x") or text.startswith("0X"):
                        return int(text, 16)
                    return int(float(text))
                except ValueError:
                    pass
        return None

    def _get_param_float(
        self, container: etree._Element, param_name: str, default: float = 0.0
    ) -> float:
        """Get float parameter value."""
        for path in [
            f".//ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
            f".//ar:PARAMETER-VALUES/ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
        ]:
            text = _xpath_text(container, path, self.ns)
            if text:
                try:
                    return float(text)
                except ValueError:
                    pass
        return default

    def _get_param_text(
        self, container: etree._Element, param_name: str, default: str = ""
    ) -> str:
        """Get text parameter value."""
        for path in [
            f".//ar:ECUC-TEXTUAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
            f".//ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
            f".//ar:PARAMETER-VALUES/ar:ECUC-TEXTUAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
        ]:
            text = _xpath_text(container, path, self.ns)
            if text:
                return text
        return default

    def _get_param_bool(
        self, container: etree._Element, param_name: str, default: bool = False
    ) -> bool:
        """Get boolean parameter value."""
        text = self._get_param_text(container, param_name)
        if text.lower() in ("true", "1", "on"):
            return True
        if text.lower() in ("false", "0", "off"):
            return False
        return default

    def _get_ref(
        self, container: etree._Element, param_name: str
    ) -> Optional[str]:
        """Get reference parameter value (last segment of path)."""
        for path in [
            f".//ar:ECUC-REFERENCE-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE-REF",
            f".//ar:REFERENCE-VALUES/ar:ECUC-REFERENCE-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE-REF",
        ]:
            results = _xpath(container, path, self.ns)
            if results:
                elem = results[0]
                text = elem.text if isinstance(elem, etree._Element) else str(elem)
                if text:
                    return text.rsplit("/", 1)[-1]
        return None
