"""Lightweight UDS request → response simulator.

Used by the web UI's "Interactive Request" panel (POST /ecu-test/simulate)
so users can craft a UDS request and see how the *parsed* ARXML
configuration would react — without any real ECU on the bus.

The simulator is deliberately conservative: it walks the
:class:`UdsSpecification` (services, sub-functions, DIDs, routines,
sessions, security levels) and returns either a synthesised positive
response or the ISO 14229-1 NRC the configuration implies. It does NOT
run real C code; if a DID has dynamic content, the response payload is
filled with ``0x00`` placeholders so byte alignment matches.

Public API:

    simulate_request(spec, request_hex) -> dict
        request_hex: e.g. ``"22 F1 90"`` / ``"2210 03"`` / ``"31 01 02 03"``
        returns:
            {
                "request_hex":  "22 F1 90",
                "response_hex": "62 F1 90 00 00 ...",
                "verdict":      "positive" | "negative",
                "decoded": {
                    "kind":         "request" | "response",
                    "sid":          "0x22",
                    "service":      "ReadDataByIdentifier",
                    "sub_function": "0x01" (optional),
                    "did":          "0xF190" (optional),
                    "routine":      "0x0203" (optional),
                    "nrc":          "0x33" (optional, on negative),
                    "nrc_name":     "securityAccessDenied" (optional),
                },
                "notes": [str, ...]
            }
"""

from __future__ import annotations

from typing import Any, Optional

from udsxml2tex.models import STANDARD_NRCS, UDS_SERVICE_NAMES


__all__ = ["simulate_request", "SimulationError"]


class SimulationError(ValueError):
    """Raised when the input request is malformed (not a hex string)."""


def _parse_hex(request_hex: str) -> list[int]:
    """Normalise free-form hex (``"22 F1 90"``, ``"2210 03"``, ``0x22 0xF1``)."""
    if not request_hex or not request_hex.strip():
        raise SimulationError("request_hex is empty")
    cleaned = request_hex.replace("0x", "").replace("0X", "")
    cleaned = cleaned.replace(",", " ").replace("-", " ")
    tokens = cleaned.split()
    joined = "".join(tokens)
    if len(joined) % 2 != 0:
        raise SimulationError(
            f"Hex string has odd nibble count: {request_hex!r}"
        )
    try:
        return [int(joined[i:i + 2], 16) for i in range(0, len(joined), 2)]
    except ValueError as exc:
        raise SimulationError(f"Invalid hex digit in {request_hex!r}") from exc


def _hex(bytes_: list[int]) -> str:
    return " ".join(f"{b:02X}" for b in bytes_)


def _nrc(sid: int, nrc_code: int, notes: list[str]) -> dict[str, Any]:
    nrc_name = STANDARD_NRCS.get(nrc_code, f"vendor_{nrc_code:02X}")
    return {
        "request_hex": "",  # filled by caller
        "response_hex": _hex([0x7F, sid, nrc_code]),
        "verdict": "negative",
        "decoded": {
            "kind": "response",
            "sid": f"0x{sid:02X}",
            "service": UDS_SERVICE_NAMES.get(sid, f"0x{sid:02X}"),
            "nrc": f"0x{nrc_code:02X}",
            "nrc_name": nrc_name,
        },
        "notes": notes,
    }


def _positive(
    sid: int,
    payload: list[int],
    extra_decoded: Optional[dict[str, Any]] = None,
    notes: Optional[list[str]] = None,
) -> dict[str, Any]:
    decoded: dict[str, Any] = {
        "kind": "response",
        "sid": f"0x{sid + 0x40:02X}",
        "service": UDS_SERVICE_NAMES.get(sid, f"0x{sid:02X}"),
    }
    if extra_decoded:
        decoded.update(extra_decoded)
    return {
        "request_hex": "",  # filled by caller
        "response_hex": _hex([sid + 0x40] + payload),
        "verdict": "positive",
        "decoded": decoded,
        "notes": notes or [],
    }


def _find_service(spec: Any, sid: int) -> Optional[Any]:
    for svc in getattr(spec, "services", []) or []:
        if getattr(svc, "service_id", -1) == sid:
            return svc
    return None


def _find_did(spec: Any, did_id: int) -> Optional[Any]:
    for d in getattr(spec, "dids", []) or []:
        if getattr(d, "did_id", -1) == did_id:
            return d
    return None


def _find_routine(spec: Any, rid: int) -> Optional[Any]:
    for r in getattr(spec, "routines", []) or []:
        if getattr(r, "routine_id", -1) == rid:
            return r
    return None


def _find_session(spec: Any, sub_id: int) -> Optional[Any]:
    for s in getattr(spec, "sessions", []) or []:
        if getattr(s, "session_id", -1) == sub_id:
            return s
    return None


def simulate_request(spec: Any, request_hex: str) -> dict[str, Any]:
    """Simulate the ECU's response to a raw UDS request."""
    req = _parse_hex(request_hex)
    sid = req[0]
    notes: list[str] = []
    norm_hex = _hex(req)

    # ----- 1. Service-not-supported (NRC 0x11) -----
    svc = _find_service(spec, sid)
    if svc is None:
        result = _nrc(sid, 0x11, [
            f"SID 0x{sid:02X} is not present in the parsed DcmDsdService list.",
        ])
        result["request_hex"] = norm_hex
        return result

    # ----- 2. Per-service handlers -----
    if sid == 0x10:  # DiagnosticSessionControl
        result = _handle_session_control(spec, svc, req, notes)
    elif sid == 0x11:  # ECUReset
        result = _handle_ecu_reset(svc, req, notes)
    elif sid == 0x14:  # ClearDiagnosticInformation
        result = _handle_clear_dtc(svc, req, notes)
    elif sid == 0x19:  # ReadDTCInformation
        result = _handle_read_dtc(spec, svc, req, notes)
    elif sid == 0x22:  # ReadDataByIdentifier
        result = _handle_read_did(spec, svc, req, notes)
    elif sid == 0x27:  # SecurityAccess
        result = _handle_security_access(spec, svc, req, notes)
    elif sid == 0x2E:  # WriteDataByIdentifier
        result = _handle_write_did(spec, svc, req, notes)
    elif sid == 0x31:  # RoutineControl
        result = _handle_routine_control(spec, svc, req, notes)
    elif sid == 0x3E:  # TesterPresent
        result = _handle_tester_present(svc, req, notes)
    else:
        # Generic SID we know about but don't model — synthesise a stub
        # positive reply (echo sub-function if any) so the user still
        # sees the round-trip shape.
        if svc.sub_functions and len(req) >= 2:
            result = _positive(sid, [req[1] & 0x7F], notes=[
                f"Generic stub response for SID 0x{sid:02X}; "
                "byte 1 echoes the requested sub-function (suppressPosRsp masked)."
            ])
        else:
            result = _positive(sid, [], notes=[
                f"Generic stub response for SID 0x{sid:02X}."
            ])
    result["request_hex"] = norm_hex
    return result


# ---------------------------------------------------------------------------
# Per-service handlers
# ---------------------------------------------------------------------------

def _handle_session_control(spec: Any, svc: Any, req: list[int],
                              notes: list[str]) -> dict[str, Any]:
    if len(req) < 2:
        return _nrc(0x10, 0x13, ["DiagnosticSessionControl needs a sub-function."])
    sub = req[1] & 0x7F
    sess_obj = _find_session(spec, sub)
    if sess_obj is None:
        return _nrc(0x10, 0x12, [
            f"Session 0x{sub:02X} not present in DcmDspSession.",
        ])
    # P2/P2* in ms (1ms / 10ms granularity per ISO 14229-1)
    p2 = int(getattr(sess_obj, "p2_server_max", 0.05) * 1000)
    p2_star = int(getattr(sess_obj, "p2_star_server_max", 5.0) * 100)
    p2 = max(0, min(p2, 0xFFFF))
    p2_star = max(0, min(p2_star, 0xFFFF))
    payload = [sub,
               (p2 >> 8) & 0xFF, p2 & 0xFF,
               (p2_star >> 8) & 0xFF, p2_star & 0xFF]
    notes.append(
        f"Session '{sess_obj.short_name}' P2={p2}ms, "
        f"P2*={p2_star * 10}ms (encoded as {p2_star} ×10ms)."
    )
    return _positive(0x10, payload,
                       extra_decoded={"sub_function": f"0x{sub:02X}",
                                       "session_name": sess_obj.short_name},
                       notes=notes)


def _handle_ecu_reset(svc: Any, req: list[int],
                       notes: list[str]) -> dict[str, Any]:
    if len(req) < 2:
        return _nrc(0x11, 0x13, ["ECUReset needs a sub-function."])
    sub = req[1] & 0x7F
    sf_match = next((sf for sf in svc.sub_functions
                       if sf.sub_function_id == sub), None)
    if sf_match is None:
        return _nrc(0x11, 0x12, [
            f"Reset sub-function 0x{sub:02X} not in DcmDsdSubService list.",
        ])
    return _positive(0x11, [sub],
                       extra_decoded={"sub_function": f"0x{sub:02X}",
                                       "sub_function_name": sf_match.short_name},
                       notes=notes)


def _handle_clear_dtc(svc: Any, req: list[int],
                       notes: list[str]) -> dict[str, Any]:
    if len(req) < 4:
        return _nrc(0x14, 0x13,
                     ["ClearDiagnosticInformation needs 3-byte groupOfDTC."])
    return _positive(0x14, [], notes=notes)


def _handle_read_dtc(spec: Any, svc: Any, req: list[int],
                       notes: list[str]) -> dict[str, Any]:
    if len(req) < 2:
        return _nrc(0x19, 0x13, ["ReadDTCInformation needs a sub-function."])
    sub = req[1] & 0x7F
    sf_match = next((sf for sf in svc.sub_functions
                       if sf.sub_function_id == sub), None)
    if sf_match is None:
        return _nrc(0x19, 0x12, [
            f"ReportType 0x{sub:02X} not declared in DcmDsdSubService list.",
        ])
    # 0x02 reportDTCByStatusMask: respond with the parsed DTC list.
    if sub == 0x02 and len(req) >= 3:
        avail_mask = getattr(spec, "dtc_status_availability_mask", 0xFF)
        payload = [sub, avail_mask & 0xFF]
        for dtc in (getattr(spec, "dtcs", []) or [])[:20]:
            did = getattr(dtc, "dtc_id", 0)
            payload += [(did >> 16) & 0xFF, (did >> 8) & 0xFF, did & 0xFF,
                          0x09]  # status: test failed + confirmed (stub)
        notes.append(
            f"reportDTCByStatusMask: returning {len(payload) // 4} DTCs "
            f"from parsed DEM (capped at 20)."
        )
        return _positive(0x19, payload,
                           extra_decoded={"sub_function": f"0x{sub:02X}"},
                           notes=notes)
    return _positive(0x19, [sub],
                       extra_decoded={"sub_function": f"0x{sub:02X}"},
                       notes=[*notes,
                                "Stub response — only header echoed (sub-function "
                                "not modelled in detail)."])


def _handle_read_did(spec: Any, svc: Any, req: list[int],
                       notes: list[str]) -> dict[str, Any]:
    if len(req) < 3 or (len(req) - 1) % 2 != 0:
        return _nrc(0x22, 0x13,
                     ["ReadDataByIdentifier needs one or more 16-bit DIDs."])
    payload: list[int] = []
    decoded_dids: list[str] = []
    for i in range(1, len(req), 2):
        did_id = (req[i] << 8) | req[i + 1]
        did = _find_did(spec, did_id)
        if did is None:
            return _nrc(0x22, 0x31, [
                f"DID 0x{did_id:04X} not in DcmDspDid list.",
            ])
        if not did.read_access:
            return _nrc(0x22, 0x31, [
                f"DID 0x{did_id:04X} ({did.short_name}) is write-only.",
            ])
        length = max(1, did.total_byte_length or 1)
        payload += [req[i], req[i + 1]] + [0x00] * length
        decoded_dids.append(
            f"0x{did_id:04X} ({did.short_name}, {length}B)"
        )
        notes.append(
            f"DID 0x{did_id:04X}: returning {length} stub byte(s) of 0x00."
        )
    return _positive(0x22, payload,
                       extra_decoded={"did": ", ".join(decoded_dids)},
                       notes=notes)


def _handle_security_access(spec: Any, svc: Any, req: list[int],
                              notes: list[str]) -> dict[str, Any]:
    if len(req) < 2:
        return _nrc(0x27, 0x13, ["SecurityAccess needs a sub-function."])
    sub = req[1] & 0x7F
    is_request_seed = (sub % 2) == 1
    # Map sub-function → security level (sub 0x01/0x02 → level 1, etc.)
    level_id = (sub + 1) // 2
    sec = next((s for s in getattr(spec, "security_levels", []) or []
                  if s.security_level == level_id), None)
    if sec is None:
        return _nrc(0x27, 0x12, [
            f"Sub-function 0x{sub:02X} (level {level_id}) not in "
            "DcmDspSecurityRow list.",
        ])
    if is_request_seed:
        # Stub a 4-byte seed
        payload = [sub, 0xDE, 0xAD, 0xBE, 0xEF]
        notes.append(
            f"requestSeed (level {level_id}): returning stub seed "
            "0xDEADBEEF; sendKey would echo sub-function with no payload."
        )
        return _positive(0x27, payload,
                           extra_decoded={"sub_function": f"0x{sub:02X}",
                                           "security_level": sec.short_name},
                           notes=notes)
    # sendKey: always returns positive in simulation
    return _positive(0x27, [sub],
                       extra_decoded={"sub_function": f"0x{sub:02X}",
                                       "security_level": sec.short_name},
                       notes=[*notes,
                                "sendKey simulated: assumed correct key."])


def _handle_write_did(spec: Any, svc: Any, req: list[int],
                        notes: list[str]) -> dict[str, Any]:
    if len(req) < 4:
        return _nrc(0x2E, 0x13,
                     ["WriteDataByIdentifier needs DID + at least 1 data byte."])
    did_id = (req[1] << 8) | req[2]
    did = _find_did(spec, did_id)
    if did is None:
        return _nrc(0x2E, 0x31, [
            f"DID 0x{did_id:04X} not in DcmDspDid list.",
        ])
    if not did.write_access:
        return _nrc(0x2E, 0x31, [
            f"DID 0x{did_id:04X} ({did.short_name}) is read-only.",
        ])
    expected = did.total_byte_length or len(req) - 3
    actual = len(req) - 3
    if expected and actual != expected:
        return _nrc(0x2E, 0x13, [
            f"DID 0x{did_id:04X} expects {expected} data bytes, got {actual}.",
        ])
    return _positive(0x2E, [req[1], req[2]],
                       extra_decoded={"did": f"0x{did_id:04X}",
                                       "did_name": did.short_name},
                       notes=[*notes,
                                f"Write accepted ({actual} byte(s))."])


def _handle_routine_control(spec: Any, svc: Any, req: list[int],
                              notes: list[str]) -> dict[str, Any]:
    if len(req) < 4:
        return _nrc(0x31, 0x13,
                     ["RoutineControl needs sub-function + 16-bit RID."])
    sub = req[1] & 0x7F
    rid = (req[2] << 8) | req[3]
    routine = _find_routine(spec, rid)
    if routine is None:
        return _nrc(0x31, 0x31, [
            f"RID 0x{rid:04X} not in DcmDspRoutine list.",
        ])
    if sub == 0x01 and not routine.start_supported:
        return _nrc(0x31, 0x12, [
            f"RID 0x{rid:04X} does not support startRoutine (0x01).",
        ])
    if sub == 0x02 and not routine.stop_supported:
        return _nrc(0x31, 0x12, [
            f"RID 0x{rid:04X} does not support stopRoutine (0x02).",
        ])
    if sub == 0x03 and not routine.result_supported:
        return _nrc(0x31, 0x12, [
            f"RID 0x{rid:04X} does not support requestRoutineResults (0x03).",
        ])
    out_bytes = sum(max(1, (p.bit_size + 7) // 8)
                      for p in routine.out_parameters) or 1
    payload = [sub, req[2], req[3], 0x00] + [0x00] * out_bytes
    notes.append(
        f"RID 0x{rid:04X}: routine info byte 0x00 + "
        f"{out_bytes} stub output byte(s)."
    )
    return _positive(0x31, payload,
                       extra_decoded={"sub_function": f"0x{sub:02X}",
                                       "routine": f"0x{rid:04X}",
                                       "routine_name": routine.short_name},
                       notes=notes)


def _handle_tester_present(svc: Any, req: list[int],
                             notes: list[str]) -> dict[str, Any]:
    if len(req) < 2:
        return _nrc(0x3E, 0x13, ["TesterPresent needs a sub-function."])
    sub = req[1]
    if sub & 0x80:
        # suppressPosRspMsgIndicationBit set — server stays silent.
        return {
            "request_hex": "",
            "response_hex": "",
            "verdict": "positive",
            "decoded": {
                "kind": "response",
                "sid": "0x7E (suppressed)",
                "service": "TesterPresent",
                "sub_function": f"0x{sub:02X}",
            },
            "notes": [*notes,
                        "suppressPosRspMsgIndicationBit set — no response sent."],
        }
    return _positive(0x3E, [sub & 0x7F], notes=notes)
