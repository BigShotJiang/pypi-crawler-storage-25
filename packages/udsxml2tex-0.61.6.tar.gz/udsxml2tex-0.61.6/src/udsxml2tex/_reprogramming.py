"""Bootloader reprogramming section renderers.

Each function returns a string of the requested format
(tex / html / md / rst) generated from a :class:`BootOverlay`.
The :class:`TexGenerator` wires them into the appropriate output
when an overlay is supplied.

All output is generic — no vendor / brand / OEM identifiers are baked in.
Use the generic actor labels ``Tester`` and ``ECU`` for tikz-uml sequence
diagrams. Use generic section titles like ``Bootloader / Reprogramming``
and ``Flash Memory Map``.
"""

from __future__ import annotations

from typing import Optional

from udsxml2tex.boot_overlay import (
    BootloaderInfo,
    BootOverlay,
    DomainCanIds,
    FlashSegment,
)
from udsxml2tex.i18n import Translator

__all__ = [
    "has_reprogramming_data",
    "render_reprogramming_section_tex",
    "render_reprogramming_section_html",
    "render_reprogramming_section_md",
    "render_reprogramming_section_rst",
    "render_programming_sequence_tikz",
    "render_flash_memory_map_tex",
    "render_flash_memory_map_html",
    "render_flash_memory_map_md",
    "render_flash_memory_map_rst",
    "render_boot_only_did_table_tex",
    "render_boot_only_did_table_html",
    "render_boot_only_did_table_md",
    "render_boot_only_did_table_rst",
    "render_boot_only_rid_table_tex",
    "render_boot_only_rid_table_html",
    "render_boot_only_rid_table_md",
    "render_boot_only_rid_table_rst",
    "render_can_id_comparison_tex",
    "render_can_id_comparison_html",
    "render_can_id_comparison_md",
    "render_can_id_comparison_rst",
]


# ---------------------------------------------------------------------------
# LaTeX escaping helpers (private)
# ---------------------------------------------------------------------------

_LATEX_ESCAPE_MAP = {
    "&": r"\&",
    "%": r"\%",
    "$": r"\$",
    "#": r"\#",
    "_": r"\_",
    "{": r"\{",
    "}": r"\}",
    "~": r"\textasciitilde{}",
    "^": r"\textasciicircum{}",
}


def _tex_escape(text: str) -> str:
    """Escape special LaTeX characters in text. Mirrors generator._latex_escape."""
    if not text:
        return ""
    result = []
    i = 0
    s = str(text)
    while i < len(s):
        ch = s[i]
        if ch == "\\" and i + 1 < len(s) and s[i + 1].isalpha():
            result.append(ch)
        elif ch in _LATEX_ESCAPE_MAP:
            result.append(_LATEX_ESCAPE_MAP[ch])
        else:
            result.append(ch)
        i += 1
    return "".join(result)


def _html_escape(text: str) -> str:
    """Escape HTML special characters."""
    if not text:
        return ""
    return (
        str(text)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#39;")
    )


def _md_escape(text: str) -> str:
    """Escape Markdown pipe characters so a value can sit inside a table cell."""
    if not text:
        return ""
    return str(text).replace("|", "\\|").replace("\n", " ")


def _hex_addr(value: int, width: int = 8) -> str:
    """Format ``value`` as ``0xNNNN...``. Width padding for visual alignment."""
    if value is None:
        return ""
    return f"0x{value:0{width}X}"


def _size_bytes(start: int, end: int) -> int:
    """Return inclusive segment size in bytes (``end - start + 1``)."""
    if end < start:
        return 0
    return end - start + 1


def _t(translator: Translator, key: str, default: str) -> str:
    """Look up a translation key, falling back to ``default`` rather than the key.

    Returns the first selected language only — single-line, plain text,
    safe for any output format (LaTeX, HTML, Markdown, RST). LaTeX
    renderers that want the full N-language stacked form for body
    labels / column headers should call :func:`_t_stack` instead.

    The standard :class:`Translator` returns the key itself when a
    translation is missing; this module wants a friendlier English
    fallback because the i18n keys are owned by another agent and may
    not yet exist.
    """
    if translator.is_multilingual:
        value = translator.t_first(key)
    else:
        value = translator.t(key)
    if value == key:
        return default
    return value


def _t_title(translator: Translator, key: str, default: str) -> str:
    """Title-context translation — alias for :func:`_t`.

    Section / chapter / figure-caption titles always render as a single
    line (the user's convention is "章立てのタイトルは英語で統一"),
    so titles use :func:`_t` semantics regardless of multilingual mode.
    """
    return _t(translator, key, default)


def _t_stack(translator: Translator, key: str, default: str) -> str:
    """LaTeX-only stacked translation for body labels / column headings.

    In monolingual mode behaves like :func:`_t`. In multilingual mode
    returns a LaTeX ``\\makecell[l]{lang1 \\\\ lang2 \\\\ ...}`` block
    that renders correctly inside table cells, ``\\textbf{...}``
    wrappers, and ordinary paragraphs.

    The returned string contains LaTeX control characters (``{``, ``}``,
    backslashes) by design, so call sites must NOT pass it through
    :func:`_tex_escape` — embed it raw in the f-string.
    """
    if not translator.is_multilingual:
        return _t(translator, key, default)
    value = translator.t_stack(key)
    if value == key:
        return default
    return value


# ---------------------------------------------------------------------------
# Public API: presence check
# ---------------------------------------------------------------------------


def has_reprogramming_data(overlay: Optional[BootOverlay]) -> bool:
    """Return True if ``overlay`` has any reprogramming-relevant data.

    The check is True when the overlay carries a :class:`BootloaderInfo`,
    bootloader-only DIDs / RIDs, or a bootloader CAN ID set. The drive-side
    CAN ID alone is not enough — it does not justify a Bootloader chapter.
    """
    if overlay is None:
        return False
    if overlay.bootloader is not None:
        return True
    if overlay.boot_only_dids:
        return True
    if overlay.boot_only_rids:
        return True
    if overlay.can_ids_boot is not None:
        return True
    return False


# ---------------------------------------------------------------------------
# LaTeX: programming sequence (tikz-uml)
# ---------------------------------------------------------------------------


def render_programming_sequence_tikz(
    steps: list[str],
    *,
    actor_tester: str = "Tester",
    actor_ecu: str = "ECU",
    lang: str = "en",
) -> str:
    """Generate a tikz-uml sequence diagram from a list of step strings.

    Each entry in ``steps`` becomes one :verb:`\\umlcall` from the tester to
    the ECU with the step text used as the ``op`` parameter. The diagram is
    wrapped in :verb:`\\begin{figure}[H]` with a caption.

    Empty ``steps`` produces a minimal figure with an explanatory comment so
    the LaTeX still compiles.
    """
    tr = Translator(lang)
    caption = _t_title(tr, "reprogramming_sequence", "Bootloader Reprogramming Sequence")
    label = "fig:bootloader-reprogramming-sequence"

    tester = _tex_escape(actor_tester)
    ecu = _tex_escape(actor_ecu)

    if not steps:
        # Minimal but valid figure so the include does not break compilation.
        return (
            "\\begin{figure}[H]\n"
            "\\centering\n"
            "% No programming_sequence steps were supplied in the boot overlay.\n"
            "\\begin{tikzpicture}\n"
            "\\begin{umlseqdiag}\n"
            f"\\umlbasicobject[fill=headerblue!15]{{{tester}}}\n"
            f"\\umlbasicobject[fill=headerblue!15]{{{ecu}}}\n"
            "\\end{umlseqdiag}\n"
            "\\end{tikzpicture}\n"
            f"\\caption{{{_tex_escape(caption)}}}\\label{{{label}}}\n"
            "\\end{figure}\n"
        )

    lines: list[str] = []
    lines.append("\\begin{figure}[H]")
    lines.append("\\centering")
    lines.append("\\begin{tikzpicture}")
    lines.append("\\begin{umlseqdiag}")
    lines.append(f"\\umlbasicobject[fill=headerblue!15]{{{tester}}}")
    lines.append(f"\\umlbasicobject[fill=headerblue!15]{{{ecu}}}")
    lines.append("")
    for step in steps:
        op = _tex_escape(step)
        lines.append(
            f"\\begin{{umlcall}}[op={{{op}}}]{{{tester}}}{{{ecu}}}"
        )
        lines.append("\\end{umlcall}")
    lines.append("\\end{umlseqdiag}")
    lines.append("\\end{tikzpicture}")
    lines.append(f"\\caption{{{_tex_escape(caption)}}}\\label{{{label}}}")
    lines.append("\\end{figure}")
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# Flash memory map (4 formats)
# ---------------------------------------------------------------------------


def render_flash_memory_map_tex(
    segments: list[FlashSegment],
    *,
    lang: str = "en",
) -> str:
    """LaTeX longtable of flash memory segments.

    Columns: Name | Start | End | Size (bytes) | Description.
    Returns an empty string when ``segments`` is empty.
    """
    if not segments:
        return ""

    tr = Translator(lang)
    name_h = _t_stack(tr, "name", "Name")
    start_h = _t_stack(tr, "start_address", "Start")
    end_h = _t_stack(tr, "end_address", "End")
    size_h = _t_stack(tr, "size_bytes", "Size (bytes)")
    desc_h = _t_stack(tr, "description", "Description")
    caption = _t_title(tr, "memory_map", "Flash Memory Map")

    lines: list[str] = []
    lines.append("\\begin{longtable}{|l|l|l|r|p{6cm}|}")
    lines.append(f"\\caption{{{_tex_escape(caption)}}}\\label{{tab:flash-memory-map}} \\\\")
    lines.append("\\hline")
    lines.append("\\rowcolor{gray!20}")
    lines.append(
        f"\\textbf{{{name_h}}} & "
        f"\\textbf{{{start_h}}} & "
        f"\\textbf{{{end_h}}} & "
        f"\\textbf{{{size_h}}} & "
        f"\\textbf{{{desc_h}}} \\\\ \\hline"
    )
    lines.append("\\endfirsthead")
    lines.append("\\hline")
    lines.append("\\rowcolor{gray!20}")
    lines.append(
        f"\\textbf{{{name_h}}} & "
        f"\\textbf{{{start_h}}} & "
        f"\\textbf{{{end_h}}} & "
        f"\\textbf{{{size_h}}} & "
        f"\\textbf{{{desc_h}}} \\\\ \\hline"
    )
    lines.append("\\endhead")
    for seg in segments:
        size = _size_bytes(seg.start, seg.end)
        lines.append(
            f"{_tex_escape(seg.name)} & "
            f"\\texttt{{{_hex_addr(seg.start)}}} & "
            f"\\texttt{{{_hex_addr(seg.end)}}} & "
            f"{size} & "
            f"{_tex_escape(seg.description)} \\\\ \\hline"
        )
    lines.append("\\end{longtable}")
    return "\n".join(lines) + "\n"


def render_flash_memory_map_html(
    segments: list[FlashSegment],
    *,
    lang: str = "en",
) -> str:
    """HTML ``<table>`` of flash memory segments."""
    if not segments:
        return ""
    tr = Translator(lang)
    name_h = _t(tr, "name", "Name")
    start_h = _t(tr, "start_address", "Start")
    end_h = _t(tr, "end_address", "End")
    size_h = _t(tr, "size_bytes", "Size (bytes)")
    desc_h = _t(tr, "description", "Description")
    caption = _t_title(tr, "memory_map", "Flash Memory Map")

    lines: list[str] = []
    lines.append('<table class="flash-memory-map">')
    lines.append(f"<caption>{_html_escape(caption)}</caption>")
    lines.append(
        f"<tr><th>{_html_escape(name_h)}</th>"
        f"<th>{_html_escape(start_h)}</th>"
        f"<th>{_html_escape(end_h)}</th>"
        f"<th>{_html_escape(size_h)}</th>"
        f"<th>{_html_escape(desc_h)}</th></tr>"
    )
    for seg in segments:
        size = _size_bytes(seg.start, seg.end)
        lines.append(
            f"<tr><td>{_html_escape(seg.name)}</td>"
            f"<td><code>{_hex_addr(seg.start)}</code></td>"
            f"<td><code>{_hex_addr(seg.end)}</code></td>"
            f"<td>{size}</td>"
            f"<td>{_html_escape(seg.description)}</td></tr>"
        )
    lines.append("</table>")
    return "\n".join(lines) + "\n"


def render_flash_memory_map_md(
    segments: list[FlashSegment],
    *,
    lang: str = "en",
) -> str:
    """Markdown table of flash memory segments."""
    if not segments:
        return ""
    tr = Translator(lang)
    name_h = _t(tr, "name", "Name")
    start_h = _t(tr, "start_address", "Start")
    end_h = _t(tr, "end_address", "End")
    size_h = _t(tr, "size_bytes", "Size (bytes)")
    desc_h = _t(tr, "description", "Description")

    lines: list[str] = []
    lines.append(f"| {name_h} | {start_h} | {end_h} | {size_h} | {desc_h} |")
    lines.append("|---|---|---|---|---|")
    for seg in segments:
        size = _size_bytes(seg.start, seg.end)
        lines.append(
            f"| {_md_escape(seg.name)} | "
            f"`{_hex_addr(seg.start)}` | "
            f"`{_hex_addr(seg.end)}` | "
            f"{size} | "
            f"{_md_escape(seg.description)} |"
        )
    return "\n".join(lines) + "\n"


def render_flash_memory_map_rst(
    segments: list[FlashSegment],
    *,
    lang: str = "en",
) -> str:
    """reStructuredText table of flash memory segments (simple csv-table)."""
    if not segments:
        return ""
    tr = Translator(lang)
    name_h = _t(tr, "name", "Name")
    start_h = _t(tr, "start_address", "Start")
    end_h = _t(tr, "end_address", "End")
    size_h = _t(tr, "size_bytes", "Size (bytes)")
    desc_h = _t(tr, "description", "Description")
    caption = _t_title(tr, "memory_map", "Flash Memory Map")

    lines: list[str] = []
    lines.append(f".. csv-table:: {caption}")
    lines.append(
        f'   :header: "{name_h}", "{start_h}", "{end_h}", "{size_h}", "{desc_h}"'
    )
    lines.append("   :widths: 15, 15, 15, 15, 40")
    lines.append("")
    for seg in segments:
        size = _size_bytes(seg.start, seg.end)
        # Quote each field to allow embedded commas.
        name = seg.name.replace('"', '""')
        desc = seg.description.replace('"', '""')
        lines.append(
            f'   "{name}", "{_hex_addr(seg.start)}", '
            f'"{_hex_addr(seg.end)}", "{size}", "{desc}"'
        )
    lines.append("")
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# Boot-only DIDs (4 formats)
# ---------------------------------------------------------------------------


def _valid_did_entries(boot_dids: list[dict]) -> list[dict]:
    """Drop entries missing the mandatory ``did_id`` key."""
    return [d for d in boot_dids if isinstance(d, dict) and "did_id" in d]


def _valid_rid_entries(boot_rids: list[dict]) -> list[dict]:
    """Drop entries missing the mandatory ``rid_id`` key."""
    return [r for r in boot_rids if isinstance(r, dict) and "rid_id" in r]


def render_boot_only_did_table_tex(
    boot_dids: list[dict],
    *,
    lang: str = "en",
) -> str:
    """LaTeX longtable of bootloader-only DIDs."""
    entries = _valid_did_entries(boot_dids)
    if not entries:
        return ""
    tr = Translator(lang)
    did_h = _t_stack(tr, "did_id", "DID")
    name_h = _t_stack(tr, "short_name", "Short Name")
    desc_h = _t_stack(tr, "description", "Description")
    caption = _t_title(tr, "boot_only_dids", "Bootloader-only DIDs")

    lines: list[str] = []
    lines.append("\\begin{longtable}{|l|l|p{8cm}|}")
    lines.append(f"\\caption{{{_tex_escape(caption)}}}\\label{{tab:boot-only-dids}} \\\\")
    lines.append("\\hline")
    lines.append("\\rowcolor{gray!20}")
    lines.append(
        f"\\textbf{{{did_h}}} & "
        f"\\textbf{{{name_h}}} & "
        f"\\textbf{{{desc_h}}} \\\\ \\hline"
    )
    lines.append("\\endfirsthead")
    lines.append("\\hline")
    lines.append("\\rowcolor{gray!20}")
    lines.append(
        f"\\textbf{{{did_h}}} & "
        f"\\textbf{{{name_h}}} & "
        f"\\textbf{{{desc_h}}} \\\\ \\hline"
    )
    lines.append("\\endhead")
    for entry in entries:
        did_id = entry.get("did_id")
        if isinstance(did_id, int):
            did_text = f"0x{did_id:04X}"
        else:
            did_text = str(did_id)
        short_name = str(entry.get("short_name", ""))
        description = str(entry.get("description", ""))
        lines.append(
            f"\\texttt{{{_tex_escape(did_text)}}} & "
            f"{_tex_escape(short_name)} & "
            f"{_tex_escape(description)} \\\\ \\hline"
        )
    lines.append("\\end{longtable}")
    return "\n".join(lines) + "\n"


def render_boot_only_did_table_html(
    boot_dids: list[dict],
    *,
    lang: str = "en",
) -> str:
    """HTML ``<table>`` of bootloader-only DIDs."""
    entries = _valid_did_entries(boot_dids)
    if not entries:
        return ""
    tr = Translator(lang)
    did_h = _t(tr, "did_id", "DID")
    name_h = _t(tr, "short_name", "Short Name")
    desc_h = _t(tr, "description", "Description")
    caption = _t_title(tr, "boot_only_dids", "Bootloader-only DIDs")

    lines: list[str] = []
    lines.append('<table class="boot-only-dids">')
    lines.append(f"<caption>{_html_escape(caption)}</caption>")
    lines.append(
        f"<tr><th>{_html_escape(did_h)}</th>"
        f"<th>{_html_escape(name_h)}</th>"
        f"<th>{_html_escape(desc_h)}</th></tr>"
    )
    for entry in entries:
        did_id = entry.get("did_id")
        if isinstance(did_id, int):
            did_text = f"0x{did_id:04X}"
        else:
            did_text = str(did_id)
        short_name = str(entry.get("short_name", ""))
        description = str(entry.get("description", ""))
        lines.append(
            f"<tr><td><code>{_html_escape(did_text)}</code></td>"
            f"<td>{_html_escape(short_name)}</td>"
            f"<td>{_html_escape(description)}</td></tr>"
        )
    lines.append("</table>")
    return "\n".join(lines) + "\n"


def render_boot_only_did_table_md(
    boot_dids: list[dict],
    *,
    lang: str = "en",
) -> str:
    """Markdown table of bootloader-only DIDs."""
    entries = _valid_did_entries(boot_dids)
    if not entries:
        return ""
    tr = Translator(lang)
    did_h = _t(tr, "did_id", "DID")
    name_h = _t(tr, "short_name", "Short Name")
    desc_h = _t(tr, "description", "Description")

    lines: list[str] = []
    lines.append(f"| {did_h} | {name_h} | {desc_h} |")
    lines.append("|---|---|---|")
    for entry in entries:
        did_id = entry.get("did_id")
        if isinstance(did_id, int):
            did_text = f"0x{did_id:04X}"
        else:
            did_text = str(did_id)
        short_name = str(entry.get("short_name", ""))
        description = str(entry.get("description", ""))
        lines.append(
            f"| `{_md_escape(did_text)}` | "
            f"{_md_escape(short_name)} | "
            f"{_md_escape(description)} |"
        )
    return "\n".join(lines) + "\n"


def render_boot_only_did_table_rst(
    boot_dids: list[dict],
    *,
    lang: str = "en",
) -> str:
    """reStructuredText csv-table of bootloader-only DIDs."""
    entries = _valid_did_entries(boot_dids)
    if not entries:
        return ""
    tr = Translator(lang)
    did_h = _t(tr, "did_id", "DID")
    name_h = _t(tr, "short_name", "Short Name")
    desc_h = _t(tr, "description", "Description")
    caption = _t_title(tr, "boot_only_dids", "Bootloader-only DIDs")

    lines: list[str] = []
    lines.append(f".. csv-table:: {caption}")
    lines.append(f'   :header: "{did_h}", "{name_h}", "{desc_h}"')
    lines.append("   :widths: 15, 25, 60")
    lines.append("")
    for entry in entries:
        did_id = entry.get("did_id")
        if isinstance(did_id, int):
            did_text = f"0x{did_id:04X}"
        else:
            did_text = str(did_id)
        short_name = str(entry.get("short_name", "")).replace('"', '""')
        description = str(entry.get("description", "")).replace('"', '""')
        lines.append(f'   "{did_text}", "{short_name}", "{description}"')
    lines.append("")
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# Boot-only RIDs (4 formats)
# ---------------------------------------------------------------------------


def render_boot_only_rid_table_tex(
    boot_rids: list[dict],
    *,
    lang: str = "en",
) -> str:
    """LaTeX longtable of bootloader-only RIDs."""
    entries = _valid_rid_entries(boot_rids)
    if not entries:
        return ""
    tr = Translator(lang)
    rid_h = _t_stack(tr, "rid_id", "RID")
    name_h = _t_stack(tr, "short_name", "Short Name")
    desc_h = _t_stack(tr, "description", "Description")
    caption = _t_title(tr, "boot_only_rids", "Bootloader-only RIDs")

    lines: list[str] = []
    lines.append("\\begin{longtable}{|l|l|p{8cm}|}")
    lines.append(f"\\caption{{{_tex_escape(caption)}}}\\label{{tab:boot-only-rids}} \\\\")
    lines.append("\\hline")
    lines.append("\\rowcolor{gray!20}")
    lines.append(
        f"\\textbf{{{rid_h}}} & "
        f"\\textbf{{{name_h}}} & "
        f"\\textbf{{{desc_h}}} \\\\ \\hline"
    )
    lines.append("\\endfirsthead")
    lines.append("\\hline")
    lines.append("\\rowcolor{gray!20}")
    lines.append(
        f"\\textbf{{{rid_h}}} & "
        f"\\textbf{{{name_h}}} & "
        f"\\textbf{{{desc_h}}} \\\\ \\hline"
    )
    lines.append("\\endhead")
    for entry in entries:
        rid_id = entry.get("rid_id")
        if isinstance(rid_id, int):
            rid_text = f"0x{rid_id:04X}"
        else:
            rid_text = str(rid_id)
        short_name = str(entry.get("short_name", ""))
        description = str(entry.get("description", ""))
        lines.append(
            f"\\texttt{{{_tex_escape(rid_text)}}} & "
            f"{_tex_escape(short_name)} & "
            f"{_tex_escape(description)} \\\\ \\hline"
        )
    lines.append("\\end{longtable}")
    return "\n".join(lines) + "\n"


def render_boot_only_rid_table_html(
    boot_rids: list[dict],
    *,
    lang: str = "en",
) -> str:
    """HTML ``<table>`` of bootloader-only RIDs."""
    entries = _valid_rid_entries(boot_rids)
    if not entries:
        return ""
    tr = Translator(lang)
    rid_h = _t(tr, "rid_id", "RID")
    name_h = _t(tr, "short_name", "Short Name")
    desc_h = _t(tr, "description", "Description")
    caption = _t_title(tr, "boot_only_rids", "Bootloader-only RIDs")

    lines: list[str] = []
    lines.append('<table class="boot-only-rids">')
    lines.append(f"<caption>{_html_escape(caption)}</caption>")
    lines.append(
        f"<tr><th>{_html_escape(rid_h)}</th>"
        f"<th>{_html_escape(name_h)}</th>"
        f"<th>{_html_escape(desc_h)}</th></tr>"
    )
    for entry in entries:
        rid_id = entry.get("rid_id")
        if isinstance(rid_id, int):
            rid_text = f"0x{rid_id:04X}"
        else:
            rid_text = str(rid_id)
        short_name = str(entry.get("short_name", ""))
        description = str(entry.get("description", ""))
        lines.append(
            f"<tr><td><code>{_html_escape(rid_text)}</code></td>"
            f"<td>{_html_escape(short_name)}</td>"
            f"<td>{_html_escape(description)}</td></tr>"
        )
    lines.append("</table>")
    return "\n".join(lines) + "\n"


def render_boot_only_rid_table_md(
    boot_rids: list[dict],
    *,
    lang: str = "en",
) -> str:
    """Markdown table of bootloader-only RIDs."""
    entries = _valid_rid_entries(boot_rids)
    if not entries:
        return ""
    tr = Translator(lang)
    rid_h = _t(tr, "rid_id", "RID")
    name_h = _t(tr, "short_name", "Short Name")
    desc_h = _t(tr, "description", "Description")

    lines: list[str] = []
    lines.append(f"| {rid_h} | {name_h} | {desc_h} |")
    lines.append("|---|---|---|")
    for entry in entries:
        rid_id = entry.get("rid_id")
        if isinstance(rid_id, int):
            rid_text = f"0x{rid_id:04X}"
        else:
            rid_text = str(rid_id)
        short_name = str(entry.get("short_name", ""))
        description = str(entry.get("description", ""))
        lines.append(
            f"| `{_md_escape(rid_text)}` | "
            f"{_md_escape(short_name)} | "
            f"{_md_escape(description)} |"
        )
    return "\n".join(lines) + "\n"


def render_boot_only_rid_table_rst(
    boot_rids: list[dict],
    *,
    lang: str = "en",
) -> str:
    """reStructuredText csv-table of bootloader-only RIDs."""
    entries = _valid_rid_entries(boot_rids)
    if not entries:
        return ""
    tr = Translator(lang)
    rid_h = _t(tr, "rid_id", "RID")
    name_h = _t(tr, "short_name", "Short Name")
    desc_h = _t(tr, "description", "Description")
    caption = _t_title(tr, "boot_only_rids", "Bootloader-only RIDs")

    lines: list[str] = []
    lines.append(f".. csv-table:: {caption}")
    lines.append(f'   :header: "{rid_h}", "{name_h}", "{desc_h}"')
    lines.append("   :widths: 15, 25, 60")
    lines.append("")
    for entry in entries:
        rid_id = entry.get("rid_id")
        if isinstance(rid_id, int):
            rid_text = f"0x{rid_id:04X}"
        else:
            rid_text = str(rid_id)
        short_name = str(entry.get("short_name", "")).replace('"', '""')
        description = str(entry.get("description", "")).replace('"', '""')
        lines.append(f'   "{rid_text}", "{short_name}", "{description}"')
    lines.append("")
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# CAN ID comparison (4 formats)
# ---------------------------------------------------------------------------


def _can_ids_to_columns(
    drive: Optional[DomainCanIds],
    boot: Optional[DomainCanIds],
) -> list[tuple[str, Optional[DomainCanIds]]]:
    """Return the list of (label, ids) pairs to render, dropping empty domains."""
    cols: list[tuple[str, Optional[DomainCanIds]]] = []
    if drive is not None:
        cols.append(("Drive", drive))
    if boot is not None:
        cols.append(("Boot", boot))
    return cols


def render_can_id_comparison_tex(
    drive: Optional[DomainCanIds],
    boot: Optional[DomainCanIds],
    *,
    lang: str = "en",
) -> str:
    """LaTeX comparison table of per-domain CAN IDs.

    Returns an empty string when neither drive nor boot is provided.
    """
    cols = _can_ids_to_columns(drive, boot)
    if not cols:
        return ""
    tr = Translator(lang)
    domain_h = _t_stack(tr, "domain", "Domain")
    physical_h = _t_stack(tr, "physical", "Physical")
    functional_h = _t_stack(tr, "functional", "Functional")
    telematics_h = _t_stack(tr, "telematics", "Telematics")
    caption = _t_title(tr, "can_ids", "CAN IDs")

    lines: list[str] = []
    lines.append("\\begin{table}[H]")
    lines.append("\\centering")
    lines.append(f"\\caption{{{_tex_escape(caption)}}}\\label{{tab:can-ids-domain}}")
    lines.append("\\begin{tabular}{|l|l|l|l|}")
    lines.append("\\hline")
    lines.append("\\rowcolor{gray!20}")
    lines.append(
        f"\\textbf{{{domain_h}}} & "
        f"\\textbf{{{physical_h}}} & "
        f"\\textbf{{{functional_h}}} & "
        f"\\textbf{{{telematics_h}}} \\\\ \\hline"
    )
    for label, ids in cols:
        if ids is None:
            continue
        lines.append(
            f"{_tex_escape(label)} & "
            f"\\texttt{{{_tex_escape(ids.physical)}}} & "
            f"\\texttt{{{_tex_escape(ids.functional)}}} & "
            f"\\texttt{{{_tex_escape(ids.telematics)}}} \\\\ \\hline"
        )
    lines.append("\\end{tabular}")
    lines.append("\\end{table}")
    return "\n".join(lines) + "\n"


def render_can_id_comparison_html(
    drive: Optional[DomainCanIds],
    boot: Optional[DomainCanIds],
    *,
    lang: str = "en",
) -> str:
    """HTML comparison table of per-domain CAN IDs."""
    cols = _can_ids_to_columns(drive, boot)
    if not cols:
        return ""
    tr = Translator(lang)
    domain_h = _t(tr, "domain", "Domain")
    physical_h = _t(tr, "physical", "Physical")
    functional_h = _t(tr, "functional", "Functional")
    telematics_h = _t(tr, "telematics", "Telematics")
    caption = _t_title(tr, "can_ids", "CAN IDs")

    lines: list[str] = []
    lines.append('<table class="can-ids-domain">')
    lines.append(f"<caption>{_html_escape(caption)}</caption>")
    lines.append(
        f"<tr><th>{_html_escape(domain_h)}</th>"
        f"<th>{_html_escape(physical_h)}</th>"
        f"<th>{_html_escape(functional_h)}</th>"
        f"<th>{_html_escape(telematics_h)}</th></tr>"
    )
    for label, ids in cols:
        if ids is None:
            continue
        lines.append(
            f"<tr><td>{_html_escape(label)}</td>"
            f"<td><code>{_html_escape(ids.physical)}</code></td>"
            f"<td><code>{_html_escape(ids.functional)}</code></td>"
            f"<td><code>{_html_escape(ids.telematics)}</code></td></tr>"
        )
    lines.append("</table>")
    return "\n".join(lines) + "\n"


def render_can_id_comparison_md(
    drive: Optional[DomainCanIds],
    boot: Optional[DomainCanIds],
    *,
    lang: str = "en",
) -> str:
    """Markdown comparison table of per-domain CAN IDs."""
    cols = _can_ids_to_columns(drive, boot)
    if not cols:
        return ""
    tr = Translator(lang)
    domain_h = _t(tr, "domain", "Domain")
    physical_h = _t(tr, "physical", "Physical")
    functional_h = _t(tr, "functional", "Functional")
    telematics_h = _t(tr, "telematics", "Telematics")

    lines: list[str] = []
    lines.append(f"| {domain_h} | {physical_h} | {functional_h} | {telematics_h} |")
    lines.append("|---|---|---|---|")
    for label, ids in cols:
        if ids is None:
            continue
        lines.append(
            f"| {_md_escape(label)} | "
            f"`{_md_escape(ids.physical)}` | "
            f"`{_md_escape(ids.functional)}` | "
            f"`{_md_escape(ids.telematics)}` |"
        )
    return "\n".join(lines) + "\n"


def render_can_id_comparison_rst(
    drive: Optional[DomainCanIds],
    boot: Optional[DomainCanIds],
    *,
    lang: str = "en",
) -> str:
    """reStructuredText comparison table of per-domain CAN IDs."""
    cols = _can_ids_to_columns(drive, boot)
    if not cols:
        return ""
    tr = Translator(lang)
    domain_h = _t(tr, "domain", "Domain")
    physical_h = _t(tr, "physical", "Physical")
    functional_h = _t(tr, "functional", "Functional")
    telematics_h = _t(tr, "telematics", "Telematics")
    caption = _t_title(tr, "can_ids", "CAN IDs")

    lines: list[str] = []
    lines.append(f".. csv-table:: {caption}")
    lines.append(
        f'   :header: "{domain_h}", "{physical_h}", "{functional_h}", "{telematics_h}"'
    )
    lines.append("   :widths: 20, 25, 25, 30")
    lines.append("")
    for label, ids in cols:
        if ids is None:
            continue
        physical = ids.physical.replace('"', '""')
        functional = ids.functional.replace('"', '""')
        telematics = ids.telematics.replace('"', '""')
        lines.append(
            f'   "{label}", "{physical}", "{functional}", "{telematics}"'
        )
    lines.append("")
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# Bootloader configuration summary (helpers used by render_*_section_*)
# ---------------------------------------------------------------------------


def _render_bootloader_config_tex(info: BootloaderInfo, *, lang: str = "en") -> str:
    """Render the scalar config block (reset addr, block size, checksum)."""
    tr = Translator(lang)
    reset_h = _t(tr, "reset_address", "Reset Address")
    block_h = _t(tr, "download_block_size", "Download Block Size (bytes)")
    checksum_h = _t(tr, "checksum_algorithm", "Checksum Algorithm")

    rows: list[tuple[str, str]] = []
    if info.reset_address is not None:
        rows.append((reset_h, _hex_addr(info.reset_address)))
    if info.download_block_size is not None:
        rows.append((block_h, str(info.download_block_size)))
    if info.checksum_algorithm:
        rows.append((checksum_h, info.checksum_algorithm))
    if not rows:
        return ""

    lines: list[str] = []
    lines.append("\\begin{table}[H]")
    lines.append("\\centering")
    lines.append("\\begin{tabular}{|l|l|}")
    lines.append("\\hline")
    lines.append("\\rowcolor{gray!20}")
    lines.append("\\textbf{Parameter} & \\textbf{Value} \\\\ \\hline")
    for k, v in rows:
        lines.append(f"{_tex_escape(k)} & \\texttt{{{_tex_escape(v)}}} \\\\ \\hline")
    lines.append("\\end{tabular}")
    lines.append("\\end{table}")
    return "\n".join(lines) + "\n"


def _render_bootloader_config_html(info: BootloaderInfo, *, lang: str = "en") -> str:
    tr = Translator(lang)
    reset_h = _t(tr, "reset_address", "Reset Address")
    block_h = _t(tr, "download_block_size", "Download Block Size (bytes)")
    checksum_h = _t(tr, "checksum_algorithm", "Checksum Algorithm")

    rows: list[tuple[str, str]] = []
    if info.reset_address is not None:
        rows.append((reset_h, _hex_addr(info.reset_address)))
    if info.download_block_size is not None:
        rows.append((block_h, str(info.download_block_size)))
    if info.checksum_algorithm:
        rows.append((checksum_h, info.checksum_algorithm))
    if not rows:
        return ""

    lines: list[str] = []
    lines.append('<table class="bootloader-config">')
    lines.append("<tr><th>Parameter</th><th>Value</th></tr>")
    for k, v in rows:
        lines.append(
            f"<tr><td>{_html_escape(k)}</td>"
            f"<td><code>{_html_escape(v)}</code></td></tr>"
        )
    lines.append("</table>")
    return "\n".join(lines) + "\n"


def _render_bootloader_config_md(info: BootloaderInfo, *, lang: str = "en") -> str:
    tr = Translator(lang)
    reset_h = _t(tr, "reset_address", "Reset Address")
    block_h = _t(tr, "download_block_size", "Download Block Size (bytes)")
    checksum_h = _t(tr, "checksum_algorithm", "Checksum Algorithm")

    rows: list[tuple[str, str]] = []
    if info.reset_address is not None:
        rows.append((reset_h, _hex_addr(info.reset_address)))
    if info.download_block_size is not None:
        rows.append((block_h, str(info.download_block_size)))
    if info.checksum_algorithm:
        rows.append((checksum_h, info.checksum_algorithm))
    if not rows:
        return ""
    lines: list[str] = ["| Parameter | Value |", "|---|---|"]
    for k, v in rows:
        lines.append(f"| {_md_escape(k)} | `{_md_escape(v)}` |")
    return "\n".join(lines) + "\n"


def _render_bootloader_config_rst(info: BootloaderInfo, *, lang: str = "en") -> str:
    tr = Translator(lang)
    reset_h = _t(tr, "reset_address", "Reset Address")
    block_h = _t(tr, "download_block_size", "Download Block Size (bytes)")
    checksum_h = _t(tr, "checksum_algorithm", "Checksum Algorithm")

    rows: list[tuple[str, str]] = []
    if info.reset_address is not None:
        rows.append((reset_h, _hex_addr(info.reset_address)))
    if info.download_block_size is not None:
        rows.append((block_h, str(info.download_block_size)))
    if info.checksum_algorithm:
        rows.append((checksum_h, info.checksum_algorithm))
    if not rows:
        return ""
    lines: list[str] = [".. csv-table:: Bootloader Configuration",
                        '   :header: "Parameter", "Value"',
                        "   :widths: 40, 60",
                        ""]
    for k, v in rows:
        lines.append(f'   "{k}", "{v}"')
    lines.append("")
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# Section composers (4 formats)
# ---------------------------------------------------------------------------


def render_reprogramming_section_tex(
    overlay: BootOverlay,
    *,
    lang: str = "en",
) -> str:
    """Render the full ``Bootloader / Reprogramming`` LaTeX section.

    Returns an empty string if ``overlay`` has no reprogramming data.
    """
    if not has_reprogramming_data(overlay):
        return ""
    tr = Translator(lang)
    section_title = _t_title(tr, "bootloader", "Bootloader / Reprogramming")
    seq_sub = _t_title(tr, "reprogramming_sequence", "Programming Sequence")
    map_sub = _t_title(tr, "memory_map", "Flash Memory Map")
    config_sub = _t(tr, "bootloader_config", "Bootloader Configuration")
    boot_did_sub = _t_title(tr, "boot_only_dids", "Bootloader-only DIDs")
    boot_rid_sub = _t_title(tr, "boot_only_rids", "Bootloader-only RIDs")
    can_sub = _t_title(tr, "can_ids", "Bootloader CAN IDs")

    parts: list[str] = []
    parts.append(
        "% =============================================================================\n"
        f"\\section{{{_tex_escape(section_title)}}}\n"
        "% =============================================================================\n"
    )

    bl = overlay.bootloader
    if bl is not None:
        if bl.programming_sequence:
            parts.append(f"\\subsection{{{_tex_escape(seq_sub)}}}\n")
            parts.append(
                render_programming_sequence_tikz(
                    bl.programming_sequence, lang=lang
                )
            )
        if bl.flash_segments:
            parts.append(f"\\subsection{{{_tex_escape(map_sub)}}}\n")
            parts.append(render_flash_memory_map_tex(bl.flash_segments, lang=lang))
        config_table = _render_bootloader_config_tex(bl, lang=lang)
        if config_table:
            parts.append(f"\\subsection{{{_tex_escape(config_sub)}}}\n")
            parts.append(config_table)

    if overlay.boot_only_dids:
        parts.append(f"\\subsection{{{_tex_escape(boot_did_sub)}}}\n")
        parts.append(render_boot_only_did_table_tex(overlay.boot_only_dids, lang=lang))

    if overlay.boot_only_rids:
        parts.append(f"\\subsection{{{_tex_escape(boot_rid_sub)}}}\n")
        parts.append(render_boot_only_rid_table_tex(overlay.boot_only_rids, lang=lang))

    if overlay.can_ids_drive is not None or overlay.can_ids_boot is not None:
        parts.append(f"\\subsection{{{_tex_escape(can_sub)}}}\n")
        parts.append(
            render_can_id_comparison_tex(
                overlay.can_ids_drive, overlay.can_ids_boot, lang=lang
            )
        )

    return "\n".join(p for p in parts if p)


def render_reprogramming_section_html(
    overlay: BootOverlay,
    *,
    lang: str = "en",
) -> str:
    """Render the full Bootloader chapter as an HTML fragment."""
    if not has_reprogramming_data(overlay):
        return ""
    tr = Translator(lang)
    section_title = _t_title(tr, "bootloader", "Bootloader / Reprogramming")
    seq_sub = _t_title(tr, "reprogramming_sequence", "Programming Sequence")
    map_sub = _t_title(tr, "memory_map", "Flash Memory Map")
    config_sub = _t(tr, "bootloader_config", "Bootloader Configuration")
    boot_did_sub = _t_title(tr, "boot_only_dids", "Bootloader-only DIDs")
    boot_rid_sub = _t_title(tr, "boot_only_rids", "Bootloader-only RIDs")
    can_sub = _t_title(tr, "can_ids", "Bootloader CAN IDs")

    parts: list[str] = []
    parts.append(f'<section class="bootloader-reprogramming">')
    parts.append(f"<h2>{_html_escape(section_title)}</h2>")

    bl = overlay.bootloader
    if bl is not None:
        if bl.programming_sequence:
            parts.append(f"<h3>{_html_escape(seq_sub)}</h3>")
            parts.append("<ol>")
            for step in bl.programming_sequence:
                parts.append(f"  <li>{_html_escape(step)}</li>")
            parts.append("</ol>")
        if bl.flash_segments:
            parts.append(f"<h3>{_html_escape(map_sub)}</h3>")
            parts.append(render_flash_memory_map_html(bl.flash_segments, lang=lang))
        config_table = _render_bootloader_config_html(bl, lang=lang)
        if config_table:
            parts.append(f"<h3>{_html_escape(config_sub)}</h3>")
            parts.append(config_table)

    if overlay.boot_only_dids:
        parts.append(f"<h3>{_html_escape(boot_did_sub)}</h3>")
        parts.append(
            render_boot_only_did_table_html(overlay.boot_only_dids, lang=lang)
        )

    if overlay.boot_only_rids:
        parts.append(f"<h3>{_html_escape(boot_rid_sub)}</h3>")
        parts.append(
            render_boot_only_rid_table_html(overlay.boot_only_rids, lang=lang)
        )

    if overlay.can_ids_drive is not None or overlay.can_ids_boot is not None:
        parts.append(f"<h3>{_html_escape(can_sub)}</h3>")
        parts.append(
            render_can_id_comparison_html(
                overlay.can_ids_drive, overlay.can_ids_boot, lang=lang
            )
        )

    parts.append("</section>")
    return "\n".join(p for p in parts if p) + "\n"


def render_reprogramming_section_md(
    overlay: BootOverlay,
    *,
    lang: str = "en",
) -> str:
    """Render the full Bootloader chapter as a Markdown fragment."""
    if not has_reprogramming_data(overlay):
        return ""
    tr = Translator(lang)
    section_title = _t_title(tr, "bootloader", "Bootloader / Reprogramming")
    seq_sub = _t_title(tr, "reprogramming_sequence", "Programming Sequence")
    map_sub = _t_title(tr, "memory_map", "Flash Memory Map")
    config_sub = _t(tr, "bootloader_config", "Bootloader Configuration")
    boot_did_sub = _t_title(tr, "boot_only_dids", "Bootloader-only DIDs")
    boot_rid_sub = _t_title(tr, "boot_only_rids", "Bootloader-only RIDs")
    can_sub = _t_title(tr, "can_ids", "Bootloader CAN IDs")

    parts: list[str] = [f"## {section_title}", ""]

    bl = overlay.bootloader
    if bl is not None:
        if bl.programming_sequence:
            parts.append(f"### {seq_sub}")
            parts.append("")
            for i, step in enumerate(bl.programming_sequence, start=1):
                parts.append(f"{i}. {step}")
            parts.append("")
        if bl.flash_segments:
            parts.append(f"### {map_sub}")
            parts.append("")
            parts.append(render_flash_memory_map_md(bl.flash_segments, lang=lang).rstrip())
            parts.append("")
        config_table = _render_bootloader_config_md(bl, lang=lang)
        if config_table:
            parts.append(f"### {config_sub}")
            parts.append("")
            parts.append(config_table.rstrip())
            parts.append("")

    if overlay.boot_only_dids:
        parts.append(f"### {boot_did_sub}")
        parts.append("")
        parts.append(
            render_boot_only_did_table_md(overlay.boot_only_dids, lang=lang).rstrip()
        )
        parts.append("")

    if overlay.boot_only_rids:
        parts.append(f"### {boot_rid_sub}")
        parts.append("")
        parts.append(
            render_boot_only_rid_table_md(overlay.boot_only_rids, lang=lang).rstrip()
        )
        parts.append("")

    if overlay.can_ids_drive is not None or overlay.can_ids_boot is not None:
        parts.append(f"### {can_sub}")
        parts.append("")
        parts.append(
            render_can_id_comparison_md(
                overlay.can_ids_drive, overlay.can_ids_boot, lang=lang
            ).rstrip()
        )
        parts.append("")

    return "\n".join(parts)


def render_reprogramming_section_rst(
    overlay: BootOverlay,
    *,
    lang: str = "en",
) -> str:
    """Render the full Bootloader chapter as an RST fragment."""
    if not has_reprogramming_data(overlay):
        return ""
    tr = Translator(lang)
    section_title = _t_title(tr, "bootloader", "Bootloader / Reprogramming")
    seq_sub = _t_title(tr, "reprogramming_sequence", "Programming Sequence")
    map_sub = _t_title(tr, "memory_map", "Flash Memory Map")
    config_sub = _t(tr, "bootloader_config", "Bootloader Configuration")
    boot_did_sub = _t_title(tr, "boot_only_dids", "Bootloader-only DIDs")
    boot_rid_sub = _t_title(tr, "boot_only_rids", "Bootloader-only RIDs")
    can_sub = _t_title(tr, "can_ids", "Bootloader CAN IDs")

    parts: list[str] = []
    parts.append(section_title)
    parts.append("=" * len(section_title))
    parts.append("")

    bl = overlay.bootloader
    if bl is not None:
        if bl.programming_sequence:
            parts.append(seq_sub)
            parts.append("-" * len(seq_sub))
            parts.append("")
            for i, step in enumerate(bl.programming_sequence, start=1):
                parts.append(f"{i}. {step}")
            parts.append("")
        if bl.flash_segments:
            parts.append(map_sub)
            parts.append("-" * len(map_sub))
            parts.append("")
            parts.append(render_flash_memory_map_rst(bl.flash_segments, lang=lang).rstrip())
            parts.append("")
        config_table = _render_bootloader_config_rst(bl, lang=lang)
        if config_table:
            parts.append(config_sub)
            parts.append("-" * len(config_sub))
            parts.append("")
            parts.append(config_table.rstrip())
            parts.append("")

    if overlay.boot_only_dids:
        parts.append(boot_did_sub)
        parts.append("-" * len(boot_did_sub))
        parts.append("")
        parts.append(
            render_boot_only_did_table_rst(overlay.boot_only_dids, lang=lang).rstrip()
        )
        parts.append("")

    if overlay.boot_only_rids:
        parts.append(boot_rid_sub)
        parts.append("-" * len(boot_rid_sub))
        parts.append("")
        parts.append(
            render_boot_only_rid_table_rst(overlay.boot_only_rids, lang=lang).rstrip()
        )
        parts.append("")

    if overlay.can_ids_drive is not None or overlay.can_ids_boot is not None:
        parts.append(can_sub)
        parts.append("-" * len(can_sub))
        parts.append("")
        parts.append(
            render_can_id_comparison_rst(
                overlay.can_ids_drive, overlay.can_ids_boot, lang=lang
            ).rstrip()
        )
        parts.append("")

    return "\n".join(parts)
