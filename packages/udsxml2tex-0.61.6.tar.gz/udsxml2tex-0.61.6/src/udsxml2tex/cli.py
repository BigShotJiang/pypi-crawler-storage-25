"""Command-line interface for udsxml2tex."""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Optional

from udsxml2tex import __version__
from udsxml2tex.generator import TexGenerator
from udsxml2tex.parser import ArxmlParser


_EPILOG = """\
Usage modes:
  1) CLI mode (default):
       udsxml2tex input.arxml -o output.tex
     Directly specify ARXML files for batch conversion.

  2) Interactive mode:
       udsxml2tex -I
     Step-by-step guided generation where you select ARXML type,
     file paths, items to include, and more.

  3) Config file mode:
       udsxml2tex --config udsxml2tex_config.json
     Load a previously saved configuration file to generate the spec.
     Config files can be saved from interactive mode.

  4) Python library usage:
       from udsxml2tex import ArxmlParser, TexGenerator
       spec = ArxmlParser().parse("input.arxml")
       TexGenerator().generate(spec, "output.tex")
     Import and use directly from Python code.
"""


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="udsxml2tex",
        description=(
            "Convert AUTOSAR DCM/CanTp/DEM arxml to UDS (ISO 14229/15765) "
            "specification documents (LaTeX/HTML/PDF/MD/RST/CSV/YAML/JSON/DOCX) "
            "and ISO 22901-1 ODX/PDX diagnostic exchange files."
        ),
        epilog=_EPILOG,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "input",
        nargs="*",
        help="Input ARXML file(s). Multiple files will be merged. "
             "Not required when using -I, --config, or --repo.",
    )
    parser.add_argument(
        "--repo",
        default=None,
        metavar="DIR",
        help=(
            "Auto-discover ARXML and C/C++ source files inside a BSW "
            "repository. Walks DIR, classifies every *.arxml by the "
            "AUTOSAR module it contains (Dcm / CanTp / Dem / DoIp), and "
            "feeds them to the parsers automatically. Mutually exclusive "
            "with positional ARXML inputs, --dem, --doip, --comm, "
            "--c-source, and --system. Use --repo-relevant-c=false to "
            "scan every C/C++ file under DIR instead of just UDS-related "
            "ones, and --repo-require-minimum to refuse to proceed when "
            "Dcm/CanTp/Dem are not all present."
        ),
    )
    parser.add_argument(
        "--repo-include-headers",
        action="store_true",
        help=(
            "When --repo is set, also scan *.h / *.hpp files for DID/RID "
            "global-variable references (slower; off by default)."
        ),
    )
    parser.add_argument(
        "--repo-relevant-c",
        default="true",
        choices=["true", "false"],
        help=(
            "When --repo is set, restrict the C scanner to files that "
            "contain a UDS-related identifier (DcmAppl_*, Dcm_Read*, "
            "ReadDataByIdentifier, ...). Defaults to true. Set false to "
            "forward every C/C++ source under the repo to the scanner."
        ),
    )
    parser.add_argument(
        "--repo-require-minimum",
        action="store_true",
        help=(
            "When --repo is set, exit non-zero if any of Dcm / CanTp / "
            "Dem ARXML modules are missing from the repository."
        ),
    )
    parser.add_argument(
        "--repo-mode",
        default="auto",
        choices=["auto", "single", "multi"],
        help=(
            "Single ECU vs multi-ECU dispatch for --repo. Default 'auto' "
            "groups ARXMLs by their top-level subdirectory under the repo "
            "root: ≥2 subdirectories each containing a Dcm ARXML triggers "
            "multi-ECU output (same layout as --system); otherwise the "
            "single-ECU pipeline runs. 'single' / 'multi' override the "
            "auto-detection."
        ),
    )
    parser.add_argument(
        "--repo-dry-run",
        action="store_true",
        help=(
            "When --repo is set, only print the scan summary (which "
            "ARXML / C files were discovered and how they were "
            "classified) and exit without parsing or generating output."
        ),
    )
    parser.add_argument(
        "-I",
        "--interactive",
        action="store_true",
        help="Launch interactive mode — step-by-step guided generation.",
    )
    parser.add_argument(
        "--config",
        default=None,
        metavar="FILE",
        help="Path to a JSON config file (saved from interactive mode).",
    )
    parser.add_argument(
        "-o",
        "--output",
        default=None,
        help="Output .tex file path. Default: <input_stem>_uds_spec.tex",
    )
    parser.add_argument(
        "--ecu-name",
        default=None,
        help="Override ECU name in the generated document.",
    )
    parser.add_argument(
        "--template-dir",
        default=None,
        help="Directory containing custom Jinja2 LaTeX templates.",
    )
    parser.add_argument(
        "--template",
        default="uds_spec.tex.j2",
        help="Template file name (default: uds_spec.tex.j2).",
    )
    parser.add_argument(
        "--pdf",
        action="store_true",
        help="Compile the generated .tex to PDF (requires latexmk or pdflatex).",
    )
    parser.add_argument(
        "--html",
        action="store_true",
        help="Generate an HTML document in addition to (or instead of) LaTeX.",
    )
    parser.add_argument(
        "--dem",
        default=None,
        metavar="FILE",
        help="Path to a separate DEM ARXML file to merge DEM data from.",
    )
    parser.add_argument(
        "--c-source",
        action="append",
        metavar="PATH",
        default=[],
        help=(
            "C source file or directory to scan for DID global variables. "
            "Can be specified multiple times. "
            "When provided, DID data-element tables in the output will include "
            "the global variable names referenced by each DID read/write function."
        ),
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Parse ARXML and print a summary without generating any output files.",
    )
    parser.add_argument(
        "--format",
        default="tex",
        choices=[
            "tex", "pdf", "html", "md", "rst", "csv",
            "yaml", "json", "docx", "odx", "pdx",
        ],
        metavar="FORMAT",
        help="Output format: tex (default), pdf, html, md, rst, csv, yaml, "
             "json, docx, odx, pdx. `pdf` is currently honoured by --system "
             "mode (per-ECU spec.tex + system.tex are compiled to .pdf via "
             "latexmk/pdflatex). For single-ECU mode, use --pdf alongside "
             "--format tex/html. `odx` writes the loose .odx-* family of "
             "files into the output directory; `pdx` packs everything into "
             "an ISO 22901-1 PDX archive (ZIP).",
    )
    parser.add_argument(
        "--odx-supplement",
        type=Path,
        default=None,
        metavar="FILE",
        help="Path to an ODX supplement YAML (vehicle info, flash layout, "
             "functional groups). Used only when --format=odx or pdx. "
             "Example: src/udsxml2tex/samples/odx_supplement_sample.yaml",
    )
    parser.add_argument(
        "--extra-vars",
        action="append",
        metavar="KEY=VALUE",
        default=[],
        help=(
            "Extra Jinja2 template variable (KEY=VALUE). "
            "Can be specified multiple times. Only applies to tex/html output."
        ),
    )
    from udsxml2tex.i18n import SUPPORTED_LANGS
    parser.add_argument(
        "--lang",
        default="en",
        choices=SUPPORTED_LANGS,
        help=(
            "Language for generated document labels (default: en). "
            "Monolingual: en, ja, de. "
            "Bilingual (labels rendered as 'primary / secondary'): "
            "ja+en, en+ja, de+en, en+de, ja+de, de+ja."
        ),
    )
    parser.add_argument(
        "--langs",
        default=None,
        metavar="LANGS",
        help=(
            "Comma-separated list of languages to emit, e.g. 'en,ja,de'. "
            "When set, one output is generated per language with the language "
            "code appended to the filename (or as a subdirectory for ZIP/CSV "
            "outputs). Overrides --lang. Allowed codes: en, ja, de."
        ),
    )
    parser.add_argument(
        "--boot-overlay",
        type=Path,
        default=None,
        metavar="FILE",
        help=(
            "Path to a bootloader-domain overlay YAML. Marks sessions / SIDs / "
            "DIDs / RIDs as drive / boot / both domain, and supplies bootloader-"
            "only data (flash segments, programming sequence, CAN IDs). "
            "Example: src/udsxml2tex/samples/boot_overlay_sample.yaml"
        ),
    )
    parser.add_argument(
        "--show-domain",
        default="auto",
        choices=["auto", "always", "never"],
        help=(
            "Render the Drive/Boot Domain column in SID/DID/RID/session tables. "
            "auto (default): show only when --boot-overlay marks any item as "
            "boot or both. always: always show. never: never show."
        ),
    )
    parser.add_argument(
        "--style-preset",
        default=None,
        choices=["minimal", "formal", "detailed"],
        help=(
            "Document style preset for tex/html. minimal = no header/logo, "
            "formal = boxed header + optional approval box, "
            "detailed = formal + landscape big tables + change-tracking macros. "
            "Default keeps the legacy layout."
        ),
    )
    parser.add_argument(
        "--header-config",
        type=Path,
        default=None,
        metavar="FILE",
        help=(
            "Path to a header / title-page config YAML (company name, author, "
            "issue number, logo path, optional approval box). "
            "Example: src/udsxml2tex/samples/header_config_sample.yaml"
        ),
    )
    parser.add_argument(
        "--rtm",
        type=Path,
        nargs="+",
        default=None,
        metavar="CSV",
        help=(
            "One or more Requirements Traceability Matrix CSV files (ASPICE "
            "SYS.2.BP4 / ISO 26262-8 §6.4.5 / ISO/IEC/IEEE 29148). Appends a "
            "'Requirements Traceability Matrix' chapter to the output that "
            "joins each requirement row against the parsed ARXML. Example: "
            "src/udsxml2tex/samples/rtm_oem_docan_standard.csv"
        ),
    )
    parser.add_argument(
        "--rtm-sources",
        type=Path,
        default=None,
        metavar="YAML",
        help=(
            "Companion YAML file listing citable sources for --rtm "
            "(bibkey/title/publisher/year). Source_ref values in CSV rows "
            "that match a bibkey are rendered as \\cite{} in LaTeX. "
            "Example: src/udsxml2tex/samples/rtm_sources_sample.yaml"
        ),
    )
    parser.add_argument(
        "--filter-dids",
        default=None,
        metavar="IDS",
        help="Comma-separated hex DID IDs to include (e.g. 0x1234,0x1235). "
             "Other DIDs are excluded from the output.",
    )
    parser.add_argument(
        "--filter-services",
        default=None,
        metavar="IDS",
        help="Comma-separated hex service IDs to include (e.g. 0x10,0x22).",
    )
    parser.add_argument(
        "--filter-dtcs",
        default=None,
        metavar="IDS",
        help="Comma-separated hex DTC IDs to include.",
    )
    parser.add_argument(
        "--diff",
        default=None,
        metavar="FILE",
        help="Compare parsed ARXML against FILE (ARXML or JSON) and print a diff report.",
    )
    parser.add_argument(
        "--validate",
        action="store_true",
        help="Run ISO 14229-1 consistency validation and print issues. "
             "Exits non-zero if errors are found.",
    )
    parser.add_argument(
        "--validate-json",
        action="store_true",
        help=(
            "Like --validate but output issues as a JSON array to stdout "
            "(for IDE integrations such as the VS Code extension). "
            "Each element: {severity, category, message, item_id}. "
            "Exits non-zero if errors are found."
        ),
    )
    parser.add_argument(
        "--watch",
        action="store_true",
        help="Watch input files for changes and re-generate automatically. "
             "Requires the watchdog package (pip install udsxml2tex[watch]).",
    )
    parser.add_argument(
        "--serve",
        action="store_true",
        help="Start the local web server (browser mode). "
             "Requires pip install udsxml2tex[web].",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8765,
        help="Port for --serve mode (default: 8765).",
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host for --serve mode (default: 127.0.0.1).",
    )
    parser.add_argument(
        "--generate-completion",
        choices=["bash", "zsh", "fish"],
        metavar="SHELL",
        help="Print a shell completion script and exit (bash, zsh, or fish).",
    )
    parser.add_argument(
        "--bootstrap-ollama",
        action="store_true",
        help="One-shot setup for the Chat tab's local LLM backend: download "
             "Ollama into ~/.local if missing, start `ollama serve`, pull a "
             "model, and print a ready-to-use llm.json snippet. Linux/macOS "
             "only. Customize with --bootstrap-model / --bootstrap-ctx / "
             "--bootstrap-ollama-port.",
    )
    parser.add_argument(
        "--bootstrap-model",
        metavar="MODEL",
        default=None,
        help="Model tag to pull during --bootstrap-ollama (default: qwen2.5:7b).",
    )
    parser.add_argument(
        "--bootstrap-ctx",
        type=int,
        metavar="N",
        default=None,
        help="num_ctx for the bootstrapped Ollama serve (default: 24576). "
             "Increase only if your spec JSON exceeds 24K tokens; decrease "
             "to fit on a smaller GPU.",
    )
    parser.add_argument(
        "--bootstrap-ollama-port",
        type=int,
        metavar="PORT",
        default=None,
        help="Port for the bootstrapped `ollama serve` (default: 11434).",
    )
    parser.add_argument(
        "--c-scan-depth",
        type=int,
        default=0,
        metavar="N",
        help="Transitive C-scan depth: follow function calls up to N levels deep "
             "(0 = direct body only, max 3).",
    )
    parser.add_argument(
        "--doip",
        default=None,
        metavar="FILE",
        help="Path to a DoIP ARXML file to extract ISO 13400 configuration from.",
    )
    parser.add_argument(
        "--comm",
        default=None,
        metavar="FILE",
        help="Path to a Communication ARXML file (I-SIGNAL, FRAME, PDU-TO-FRAME-MAPPING).",
    )
    parser.add_argument(
        "--validate-xsd",
        default=None,
        metavar="XSD",
        help="Validate input ARXML against XSD schema file before parsing.",
    )
    parser.add_argument(
        "--parallel",
        action="store_true",
        help="Parse multiple ARXML input files in parallel (ProcessPoolExecutor).",
    )
    parser.add_argument(
        "--progress",
        action="store_true",
        help="Display a tqdm progress bar during parse_multi() / parse_streaming() (requires `pip install udsxml2tex[progress]`).",
    )
    parser.add_argument(
        "--cache-dir",
        default=None,
        metavar="DIR",
        help="Directory to cache parsed specs by file hash for incremental parsing.",
    )
    parser.add_argument(
        "--json-schema",
        action="store_true",
        help="Print the JSON Schema for UdsSpecification to stdout and exit.",
    )
    parser.add_argument(
        "--gen-arxml-from-csv",
        action="append",
        default=[],
        metavar="CSV",
        help=(
            "Generate an AUTOSAR Dcm ARXML skeleton from an OEM "
            "requirement-analysis CSV (rtm.py format) and exit. Useful "
            "when the application team needs a placeholder Boot ARXML to "
            "hand off to an external bootloader supplier. Can be passed "
            "multiple times to merge several CSVs."
        ),
    )
    parser.add_argument(
        "--gen-arxml-output",
        default=None,
        metavar="PATH",
        help=(
            "Output path for --gen-arxml-from-csv. Defaults to "
            "./generated_boot.arxml when omitted."
        ),
    )
    parser.add_argument(
        "--gen-arxml-ecu-name",
        default="BootECU",
        metavar="NAME",
        help=(
            "AUTOSAR AR-PACKAGE SHORT-NAME for the generated skeleton. "
            "Default: BootECU."
        ),
    )
    parser.add_argument(
        "--gen-arxml-domain",
        default="boot",
        choices=["boot", "drive", "both", "all"],
        help=(
            "Which CSV rows to fold into the generated ARXML. "
            "'boot' (default) keeps only ISO 14229-1 reprogramming "
            "services / identification DID range / OEM-routine RID "
            "range / ProgrammingSession; 'drive' keeps everything else; "
            "'both' / 'all' keep everything."
        ),
    )
    parser.add_argument(
        "--byte-diagrams",
        default=None,
        metavar="DIR",
        help="Generate bytefield DID byte-layout .tex files into DIR.",
    )
    parser.add_argument(
        "--sequence-diagrams",
        default=None,
        metavar="DIR",
        help="Generate TikZ UML sequence diagram .tex files into DIR.",
    )
    parser.add_argument(
        "--visualizations",
        default=None,
        metavar="DIR",
        help=(
            "Generate heatmaps (session×service, security×DID) and timing "
            "diagrams into DIR. Outputs both standalone TikZ .tex and PNG "
            "(when matplotlib is installed; install via "
            "`pip install udsxml2tex[viz]`)."
        ),
    )
    parser.add_argument(
        "--viz-format",
        default="both",
        choices=["tikz", "png", "both"],
        help="Output format for --visualizations (default: both).",
    )
    parser.add_argument(
        "--llm-summarize",
        default=None,
        nargs="?",
        const="1page",
        choices=["short", "1page", "2page", "long"],
        help=(
            "Generate an LLM-authored Markdown executive summary of the spec "
            "and write it to --llm-output (default: spec_summary.md). "
            "Requires `pip install udsxml2tex[llm]` and ANTHROPIC_API_KEY."
        ),
    )
    parser.add_argument(
        "--llm-query",
        default=None,
        metavar="QUESTION",
        help=(
            "Ask the LLM a natural-language question about the spec "
            "(e.g. 'Which DIDs require security level 2?')."
        ),
    )
    parser.add_argument(
        "--llm-translate",
        default=None,
        metavar="LANG",
        choices=["en", "ja", "de"],
        help=(
            "Translate the LLM summary or query result into LANG "
            "(en|ja|de) before writing/printing."
        ),
    )
    parser.add_argument(
        "--llm-nrc-descriptions",
        action="store_true",
        help=(
            "Generate ECU-specific NRC descriptions via the LLM and print "
            "them as JSON to stdout (or --llm-output)."
        ),
    )
    parser.add_argument(
        "--llm-model",
        default=None,
        help=(
            "Model identifier for LLM features. For Anthropic: sonnet|opus|"
            "haiku alias or full model ID. For OpenAI-compatible: pass the "
            "server's model name (e.g. 'llama3.1:8b' for Ollama). "
            "Defaults to 'sonnet' for Anthropic."
        ),
    )
    parser.add_argument(
        "--llm-provider",
        default=None,
        choices=["anthropic", "openai"],
        help=(
            "LLM backend. 'anthropic' = Claude API (cloud, requires "
            "ANTHROPIC_API_KEY). 'openai' = OpenAI-compatible HTTP API "
            "(works with Ollama, llama.cpp, vLLM, LM Studio, OpenRouter, "
            "Azure OpenAI, real OpenAI). Default: from "
            "$UDSXML2TEX_LLM_PROVIDER, ~/.udsxml2tex/llm.json, or 'anthropic'."
        ),
    )
    parser.add_argument(
        "--llm-base-url",
        default=None,
        metavar="URL",
        help=(
            "Endpoint URL for --llm-provider=openai. Aliases: 'ollama' "
            "(http://localhost:11434/v1), 'llamacpp' (8080), 'lmstudio' "
            "(1234), 'vllm' (8000), 'openrouter', 'openai'. Defaults to "
            "Ollama on localhost."
        ),
    )
    parser.add_argument(
        "--llm-api-key",
        default=None,
        metavar="KEY",
        help=(
            "Override the API key. For Anthropic, beats ANTHROPIC_API_KEY. "
            "For OpenAI-compatible, beats OPENAI_API_KEY. Local servers "
            "(Ollama etc.) usually need any non-empty placeholder."
        ),
    )
    parser.add_argument(
        "--llm-config",
        default=None,
        metavar="FILE",
        help=(
            "Load LLM provider config from a JSON or TOML file. Schema: "
            "{provider, model, base_url, api_key, structured_mode, "
            "timeout}. Per-flag overrides above take precedence. "
            "Without this flag, ~/.udsxml2tex/llm.json (or .toml) is "
            "consulted automatically."
        ),
    )
    parser.add_argument(
        "--llm-structured-mode",
        default=None,
        choices=["auto", "json_schema", "json_object", "prompt"],
        help=(
            "Structured-output strategy for --llm-nrc-descriptions. 'auto' "
            "picks per-provider sensible default (json_schema for "
            "Anthropic, json_object for OpenAI-compatible)."
        ),
    )
    parser.add_argument(
        "--llm-output",
        default=None,
        metavar="FILE",
        help="Output file for --llm-summarize / --llm-query / --llm-nrc-descriptions.",
    )
    parser.add_argument(
        "--iso-version",
        default=None,
        choices=["2006", "2013", "2020"],
        help=(
            "Filter the parsed spec by ISO 14229-1 version. Drops services, "
            "NRCs, and ReadDTCInformation sub-functions that are not defined "
            "in the chosen revision."
        ),
    )
    parser.add_argument(
        "--iso-version-mode",
        default="warn",
        choices=["warn", "strict"],
        help=(
            "How to handle items not in the chosen ISO version: 'warn' (log "
            "only) or 'strict' (drop from spec). Default: warn."
        ),
    )
    parser.add_argument(
        "--autosar-compat-report",
        default=None,
        nargs="?",
        const="-",
        metavar="FILE",
        help=(
            "Generate an AUTOSAR version compatibility report (Markdown). "
            "Pass a path to write to file, or omit the path to print to stdout."
        ),
    )
    parser.add_argument(
        "--system",
        default=None,
        metavar="CONFIG",
        help=(
            "Path to a multi-ECU system config (.yaml/.yml/.json). When set, "
            "each ECU declared in the config is parsed independently and a "
            "system integration document is generated alongside per-ECU "
            "specs. Mutually exclusive with positional ARXML inputs."
        ),
    )
    parser.add_argument(
        "--no-routing-inference",
        action="store_true",
        help=(
            "Disable ARXML-based routing inference for --system mode. "
            "Only explicit routing rules from the config are used."
        ),
    )
    parser.add_argument(
        "--system-output-dir",
        default=None,
        metavar="DIR",
        help=(
            "Output directory for --system mode. The system integration "
            "document is written to <DIR>/system.<ext>; per-ECU outputs to "
            "<DIR>/<ecu_name>/spec.<ext>. Defaults to './uds-spec/'."
        ),
    )
    # ------------------------------------------------------------------ #
    # Change-history chapter                                              #
    # ------------------------------------------------------------------ #
    parser.add_argument(
        "--changelog-from",
        default=None,
        metavar="FILE",
        help=(
            "Generate a change-history chapter by diffing the current ARXML "
            "against FILE (baseline ARXML or JSON). Output file defaults to "
            "<stem>_changelog.<ext>. Use --changelog-format to choose the "
            "output format (tex|html|md). Use --lang for translated headings."
        ),
    )
    parser.add_argument(
        "--changelog-format",
        default="tex",
        choices=["tex", "html", "md"],
        help="Output format for --changelog-from (default: tex).",
    )
    parser.add_argument(
        "--changelog-old-label",
        default=None,
        metavar="LABEL",
        help="Human-readable label for the baseline version (e.g. 'v1.2.3').",
    )
    parser.add_argument(
        "--changelog-new-label",
        default=None,
        metavar="LABEL",
        help="Human-readable label for the new version (e.g. 'v1.3.0').",
    )
    # ------------------------------------------------------------------ #
    # ECU hardware testing                                                #
    # ------------------------------------------------------------------ #
    parser.add_argument(
        "--ecu-test",
        action="store_true",
        help=(
            "Run UDS test cases against a real ECU via CAN/ISO-TP. "
            "Requires `pip install udsxml2tex[ecu-test]` and a compatible "
            "CAN interface (e.g. Vector VN1610 with --ecu-interface=vector)."
        ),
    )
    parser.add_argument(
        "--ecu-interface",
        default="vector",
        metavar="IFACE",
        help=(
            "python-can interface name for --ecu-test "
            "(vector, socketcan, pcan, kvaser, virtual …). Default: vector."
        ),
    )
    parser.add_argument(
        "--ecu-channel",
        default="0",
        metavar="CH",
        help="CAN channel for --ecu-test (e.g. 0 for VN1610 channel 1). Default: 0.",
    )
    parser.add_argument(
        "--ecu-bitrate",
        type=int,
        default=500_000,
        metavar="BPS",
        help="CAN bus bitrate in bps for --ecu-test. Default: 500000.",
    )
    parser.add_argument(
        "--ecu-fd",
        action="store_true",
        help="Enable CAN FD mode for --ecu-test.",
    )
    parser.add_argument(
        "--ecu-rx-id",
        default=None,
        metavar="HEX",
        help=(
            "CAN ID (hex) for incoming frames (ECU → tester). "
            "Defaults to spec.can_rx_id from the ARXML."
        ),
    )
    parser.add_argument(
        "--ecu-tx-id",
        default=None,
        metavar="HEX",
        help=(
            "CAN ID (hex) for outgoing frames (tester → ECU). "
            "Defaults to spec.can_tx_id from the ARXML."
        ),
    )
    parser.add_argument(
        "--ecu-timeout",
        type=float,
        default=2.0,
        metavar="SEC",
        help="Default UDS response timeout in seconds for --ecu-test. Default: 2.0.",
    )
    parser.add_argument(
        "--ecu-categories",
        nargs="+",
        default=None,
        metavar="CAT",
        choices=["session", "security", "did_read", "did_write", "routine", "dtc", "negative"],
        help=(
            "Test categories to run (default: all). "
            "Choices: session security did_read did_write routine dtc negative."
        ),
    )
    parser.add_argument(
        "--ecu-key-plugin",
        default=None,
        metavar="FILE",
        help=(
            "Path to a Python file that defines a `key_functions` dict mapping "
            "security_level (int) → callable(seed: bytes, level: int) → bytes. "
            "Required to unlock security-gated test steps."
        ),
    )
    parser.add_argument(
        "--ecu-output",
        default="ecu_test_results",
        metavar="DIR",
        help=(
            "Output directory for --ecu-test reports (JSON + CSV + HTML + JUnit XML). "
            "Default: ecu_test_results/."
        ),
    )
    parser.add_argument(
        "--ecu-coverage",
        action="store_true",
        help=(
            "Analyze spec coverage of the generated test suite and write an "
            "HTML coverage report alongside the test results."
        ),
    )
    parser.add_argument(
        "--ecu-formal",
        action="store_true",
        help=(
            "Use the formal model-checking generator instead of the heuristic "
            "generator.  Builds a complete UDS state machine from the spec and "
            "enumerates ALL reachable (state, service_call) transitions via BFS, "
            "guaranteeing all-transitions (T1) coverage — both positive paths "
            "and every NRC-expected negative path from every reachable state."
        ),
    )
    parser.add_argument(
        "--ecu-test-rationale",
        action="store_true",
        help=(
            "Use the LLM to generate WHY-focused rationales for every test case "
            "and include them in the HTML report. "
            "Requires `pip install udsxml2tex[llm]` and a configured LLM provider."
        ),
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Enable verbose logging output.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    return parser


def _run_gen_arxml_mode(args) -> int:
    """Standalone subcommand: turn an OEM requirement-analysis CSV into a
    Dcm ARXML skeleton the boot supplier can implement against.

    Returns the process exit code. Does not render any spec — this is
    purely a hand-off helper. See :mod:`udsxml2tex.csv_to_arxml` for the
    domain-filter semantics.
    """
    from udsxml2tex.csv_to_arxml import generate_arxml_from_rtm
    from udsxml2tex.rtm import load_rtm_csvs

    csv_paths = [Path(p) for p in args.gen_arxml_from_csv]
    for p in csv_paths:
        if not p.exists():
            logging.error("CSV not found: %s", p)
            return 1
    try:
        entries = load_rtm_csvs(csv_paths)
    except Exception as e:  # noqa: BLE001 — log + bail
        logging.error("Failed to load RTM CSV(s): %s", e)
        return 1
    if not entries:
        logging.error(
            "No RTM entries parsed from CSV(s) %s", csv_paths
        )
        return 1
    out_path = Path(args.gen_arxml_output) if args.gen_arxml_output \
        else Path("generated_boot.arxml")
    try:
        generate_arxml_from_rtm(
            entries,
            output_path=out_path,
            ecu_name=args.gen_arxml_ecu_name,
            domain_filter=args.gen_arxml_domain,
        )
    except ValueError as e:
        logging.error("ARXML generation failed: %s", e)
        return 1
    logging.info("Wrote %s", out_path)
    return 0


def main(argv: list[str] | None = None) -> int:
    """Main entry point for the CLI.

    Args:
        argv: Command-line arguments. Defaults to sys.argv[1:].

    Returns:
        Exit code (0 for success).
    """
    parser = _build_parser()
    args = parser.parse_args(argv)

    # Configure logging
    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(levelname)s: %(message)s",
    )

    # --- JSON Schema output ---------------------------------------------
    if getattr(args, "json_schema", False):
        from udsxml2tex.schema import generate_json_schema
        import json as _json
        print(_json.dumps(generate_json_schema(), indent=2))
        return 0

    # --- CSV -> Boot ARXML generator (standalone subcommand) ------------
    if getattr(args, "gen_arxml_from_csv", None):
        return _run_gen_arxml_mode(args)

    # --- Shell completion -----------------------------------------------
    if args.generate_completion:
        from udsxml2tex.completion import print_completion
        print_completion(args.generate_completion)
        return 0

    # --- Ollama bootstrap (Chat tab one-shot setup) ---------------------
    if getattr(args, "bootstrap_ollama", False):
        from udsxml2tex.ollama_setup import run_from_cli
        return run_from_cli(
            model=args.bootstrap_model,
            ctx=args.bootstrap_ctx,
            host="127.0.0.1",
            port=args.bootstrap_ollama_port,
        )

    # --- Web server (browser mode) --------------------------------------
    if args.serve:
        try:
            from udsxml2tex.webserver import start_server
        except ImportError:
            logging.error(
                "Web server dependencies not installed. "
                "Run: pip install udsxml2tex[web]"
            )
            return 1
        start_server(host=args.host, port=args.port, open_browser=True)
        return 0

    # --- Interactive mode -----------------------------------------------
    if args.interactive:
        from udsxml2tex.interactive import InteractiveSession

        return InteractiveSession().run()

    # --- Config-file mode -----------------------------------------------
    if args.config:
        from udsxml2tex.config import GenerationConfig
        from udsxml2tex.interactive import generate_from_config

        try:
            config = GenerationConfig.load(args.config)
        except Exception as e:
            logging.error("Failed to load config: %s", e)
            return 1
        # Allow CLI overrides on top of config
        if args.output:
            config.output_path = args.output
        if args.ecu_name:
            config.ecu_name = args.ecu_name
        if args.template_dir:
            config.template_dir = args.template_dir
        if args.template != "uds_spec.tex.j2":
            config.template = args.template
        return generate_from_config(config)

    # --- Multi-ECU system mode (mutually exclusive with positional inputs)
    if getattr(args, "system", None):
        if args.input:
            logging.error(
                "--system is mutually exclusive with positional ARXML inputs."
            )
            return 1
        if getattr(args, "repo", None):
            logging.error("--repo is mutually exclusive with --system.")
            return 1
        return _run_multi_ecu_system(args)

    # --- Repository auto-discovery mode ---------------------------------
    if getattr(args, "repo", None):
        if args.input:
            logging.error(
                "--repo is mutually exclusive with positional ARXML inputs."
            )
            return 1
        for incompatible in ("dem", "doip", "comm"):
            if getattr(args, incompatible, None):
                logging.error(
                    "--repo is mutually exclusive with --%s "
                    "(the scanner discovers it automatically).",
                    incompatible,
                )
                return 1
        if getattr(args, "c_source", None):
            logging.error(
                "--repo is mutually exclusive with --c-source "
                "(the scanner walks the repository for C files)."
            )
            return 1
        return _run_repo_mode(args, parser)

    # --- Direct CLI mode ------------------------------------------------
    if not args.input:
        parser.print_help()
        return 1

    # Validate input files
    input_paths = [Path(p) for p in args.input]
    for p in input_paths:
        if not p.exists():
            logging.error("Input file not found: %s", p)
            return 1
        if not p.suffix.lower() == ".arxml":
            logging.warning(
                "File does not have .arxml extension: %s", p
            )

    # Determine output path
    if args.output:
        output_path = Path(args.output)
    else:
        stem = input_paths[0].stem
        suffix = ".html" if args.html and not args.pdf else ".tex"
        output_path = input_paths[0].parent / f"{stem}_uds_spec{suffix}"

    # XSD validation (before parsing)
    if getattr(args, "validate_xsd", None):
        xsd_path = Path(args.validate_xsd)
        if not xsd_path.exists():
            logging.error("XSD file not found: %s", xsd_path)
            return 1
        errs = ArxmlParser().validate_against_xsd(input_paths[0], xsd_path)
        if errs:
            for e in errs:
                logging.error("XSD: %s", e)
            return 1
        logging.info("XSD validation passed.")

    # Parse ARXML
    arxml_parser = ArxmlParser()
    _parallel = getattr(args, "parallel", False)
    _cache_dir = getattr(args, "cache_dir", None)
    _progress = getattr(args, "progress", False)
    try:
        if len(input_paths) == 1:
            spec = arxml_parser.parse(input_paths[0], cache_dir=_cache_dir)
        else:
            spec = arxml_parser.parse_multi(
                input_paths, parallel=_parallel, show_progress=_progress
            )
    except Exception as e:
        logging.error("Failed to parse ARXML: %s", e)
        return 1

    # Report validation warnings
    if arxml_parser.warnings:
        for w in arxml_parser.warnings:
            logging.warning("[%s] %s", w.section, w.message)

    # Merge separate DEM arxml if provided
    if args.dem:
        from udsxml2tex.dem_parser import DemParser

        dem_path = Path(args.dem)
        if not dem_path.exists():
            logging.error("DEM ARXML file not found: %s", dem_path)
            return 1
        try:
            DemParser().parse(dem_path, spec)
        except Exception as e:
            logging.error("Failed to parse DEM ARXML: %s", e)
            return 1

    # Override ECU name if specified
    if args.ecu_name:
        spec.ecu_name = args.ecu_name

    # Parse DoIP ARXML if provided
    if getattr(args, "doip", None):
        from udsxml2tex.doip_parser import DoIpParser
        from lxml import etree as _etree
        doip_path = Path(args.doip)
        if not doip_path.exists():
            logging.error("DoIP ARXML file not found: %s", doip_path)
            return 1
        try:
            _doip_root = _etree.parse(str(doip_path)).getroot()
            spec.doip_config = DoIpParser().parse(_doip_root)
        except Exception as e:
            logging.warning("DoIP ARXML parsing failed: %s", e)

    # Parse Communication ARXML if provided
    if getattr(args, "comm", None):
        from udsxml2tex.comm_arxml_parser import CommArxmlParser
        from lxml import etree as _etree
        comm_path = Path(args.comm)
        if not comm_path.exists():
            logging.error("Comm ARXML file not found: %s", comm_path)
            return 1
        try:
            _comm_root = _etree.parse(str(comm_path)).getroot()
            spec.comm_config = CommArxmlParser().parse(_comm_root)
        except Exception as e:
            logging.warning("Communication ARXML parsing failed: %s", e)

    # Scan C source files for DID global variables
    if args.c_source:
        from udsxml2tex.c_scanner import scan_did_variables

        c_paths = [Path(p) for p in args.c_source]
        try:
            scan_did_variables(
                c_paths,
                spec.dids,
                transitive_depth=getattr(args, "c_scan_depth", 0),
            )
        except Exception as e:
            logging.warning("C source scanning failed: %s", e)

    return _run_generation(
        spec,
        args,
        arxml_parser=arxml_parser,
        output_path=output_path,
        input_paths=input_paths,
        argv=argv,
    )


def _run_generation(
    spec,
    args,
    *,
    arxml_parser,
    output_path: Path,
    input_paths: list[Path],
    argv: Optional[list[str]] = None,
) -> int:
    """Post-parse pipeline shared between positional-input and --repo modes.

    Applies filters / version filters, runs any short-circuit modes
    (validate / diff / dry-run / LLM / changelog / ecu-test), then renders
    the chosen output format.
    """
    # --- Apply filters --------------------------------------------------
    _apply_filters(spec, args)

    # --- ISO 14229-1 version filtering ----------------------------------
    if getattr(args, "iso_version", None):
        from udsxml2tex.iso_versions import filter_spec_by_iso_version
        notes = filter_spec_by_iso_version(
            spec, args.iso_version,
            mode=getattr(args, "iso_version_mode", "warn"),
        )
        for note in notes:
            logging.warning("[ISO 14229-1:%s] %s", args.iso_version, note)

    # --- AUTOSAR compatibility report -----------------------------------
    if getattr(args, "autosar_compat_report", None) is not None:
        from udsxml2tex.autosar_compat import autosar_compat_report
        report = autosar_compat_report(spec, parser=arxml_parser)
        target = args.autosar_compat_report
        if target == "-":
            print(report.to_markdown())
        else:
            Path(target).write_text(report.to_markdown(), encoding="utf-8")
            logging.info("AUTOSAR compatibility report written to: %s", target)

    # --- Change-history chapter -----------------------------------------
    if getattr(args, "changelog_from", None):
        return _run_changelog(spec, args, input_paths[0])

    # --- ECU hardware test mode -----------------------------------------
    if getattr(args, "ecu_test", False):
        return _run_ecu_test(spec, args)

    # --- Validation mode ------------------------------------------------
    if args.validate or getattr(args, "validate_json", False):
        return _run_validate(spec, as_json=getattr(args, "validate_json", False))

    # --- Diff mode ------------------------------------------------------
    if args.diff:
        return _run_diff(spec, args.diff)

    # --- Dry-run mode: print summary and exit ---------------------------
    if args.dry_run:
        return _print_dry_run_summary(spec, arxml_parser)

    # --- LLM features (summarize / query / NRC descriptions) ------------
    if (args.llm_summarize is not None
            or args.llm_query is not None
            or args.llm_nrc_descriptions):
        return _run_llm(spec, args)

    # --- Parse extra_vars -----------------------------------------------
    extra_vars: dict = {}
    for kv in getattr(args, "extra_vars", []):
        if "=" in kv:
            k, _, v = kv.partition("=")
            extra_vars[k.strip()] = v.strip()
        else:
            logging.warning("Ignoring malformed --extra-vars entry: %r", kv)

    # --- Resolve language selection -------------------------------------
    # --langs (multi-language, comma-separated) overrides --lang.
    langs_arg = getattr(args, "langs", None)
    try:
        selected_langs = _parse_langs(langs_arg, getattr(args, "lang", "en"))
    except ValueError as e:
        logging.error("%s", e)
        return 2
    multi_lang = len(selected_langs) > 1

    # Add i18n translator to extra_vars when (single) lang is specified.
    # In multi-language mode each per-lang iteration sets its own _t below.
    if not multi_lang and (
        getattr(args, "lang", "en") != "en" or extra_vars
    ):
        from udsxml2tex.i18n import Translator
        extra_vars.setdefault("_t", Translator(getattr(args, "lang", "en")).t)

    # --- Generate output ------------------------------------------------
    fmt = getattr(args, "format", "tex")
    # Legacy --html flag maps to html format
    if getattr(args, "html", False) and fmt == "tex" and not getattr(args, "pdf", False):
        fmt = "html"

    # --- Bootloader-domain overlay (optional) ---------------------------
    boot_overlay_obj = None
    boot_overlay_path = getattr(args, "boot_overlay", None)
    if boot_overlay_path is not None:
        try:
            from udsxml2tex.boot_overlay import load_overlay as _load_boot_overlay
            from udsxml2tex import apply_boot_overlay as _apply_boot_overlay
            boot_overlay_obj = _load_boot_overlay(boot_overlay_path)
            _apply_boot_overlay(spec, boot_overlay_obj)
            logging.info("Applied boot overlay: %s", boot_overlay_path)
        except Exception as e:
            logging.error("Failed to load --boot-overlay %s: %s", boot_overlay_path, e)
            return 2

    # --- Header config (optional) ---------------------------------------
    header_config_obj = None
    header_config_path = getattr(args, "header_config", None)
    if header_config_path is not None:
        try:
            from udsxml2tex._style_presets import load_header_config
            header_config_obj = load_header_config(header_config_path)
            logging.info("Loaded header config: %s", header_config_path)
        except Exception as e:
            logging.error("Failed to load --header-config %s: %s",
                          header_config_path, e)
            return 2

    # --- Requirements Traceability Matrix (optional) --------------------
    rtm_doc = None
    rtm_csv_args = getattr(args, "rtm", None)
    rtm_sources_arg = getattr(args, "rtm_sources", None)
    if rtm_csv_args:
        try:
            from udsxml2tex.rtm import load_rtm_document, match_to_spec
            rtm_doc = load_rtm_document(rtm_csv_args, rtm_sources_arg)
            match_to_spec(rtm_doc, spec)
            logging.info(
                "Loaded RTM: %d entries (coverage %.0f%% against parsed ARXML)",
                len(rtm_doc.entries), rtm_doc.coverage_pct(),
            )
        except Exception as e:  # noqa: BLE001
            logging.error("Failed to load --rtm: %s", e)
            return 2

    style_preset = getattr(args, "style_preset", None)
    show_domain = getattr(args, "show_domain", "auto")

    try:
        tex_gen = TexGenerator(
            template_dir=args.template_dir,
            style_preset=style_preset,
            header_config=header_config_obj,
        )

        # Lang-sensitive formats are emitted once per --langs entry. Other
        # formats are language-agnostic (or use --lang only).
        LANG_SENSITIVE_FORMATS = {"tex", "html", "md", "rst"}
        effective_langs = (
            selected_langs
            if fmt in LANG_SENSITIVE_FORMATS
            else [selected_langs[0]]
        )

        def _lang_output_path(base: Path, lang_code: str, suffix: str) -> Path:
            """Append ``_<lang>`` to the stem in multi-language mode."""
            if multi_lang and fmt in LANG_SENSITIVE_FORMATS:
                stem = base.stem + f"_{lang_code}"
                return base.with_name(stem).with_suffix(suffix)
            return base.with_suffix(suffix)

        for lang_code in effective_langs:
            # Per-language extra_vars: each lang gets its own Translator-bound _t.
            per_extra_vars = dict(extra_vars)
            if multi_lang or lang_code != "en" or per_extra_vars:
                from udsxml2tex.i18n import Translator
                per_extra_vars["_t"] = Translator(lang_code).t

            if fmt == "tex":
                tex_output = _lang_output_path(output_path, lang_code, ".tex")
                result = tex_gen.generate(
                    spec, tex_output, template_name=args.template,
                    extra_vars=per_extra_vars or None,
                    show_domain=show_domain,
                    overlay=boot_overlay_obj,
                    lang=lang_code,
                    rtm=rtm_doc,
                )
                logging.info("LaTeX output written to: %s", result)
                if getattr(args, "pdf", False):
                    pdf_path = tex_gen.compile_pdf(result)
                    logging.info("PDF output written to: %s", pdf_path)

            elif fmt == "html":
                html_output = _lang_output_path(output_path, lang_code, ".html")
                tex_gen.generate_html(
                    spec, html_output,
                    show_domain=show_domain,
                    overlay=boot_overlay_obj,
                    lang=lang_code,
                )
                logging.info("HTML output written to: %s", html_output)

            elif fmt == "md":
                out = _lang_output_path(output_path, lang_code, ".md")
                tex_gen.generate_markdown(
                    spec, out,
                    overlay=boot_overlay_obj,
                    lang=lang_code,
                )
                logging.info("Markdown output written to: %s", out)

            elif fmt == "rst":
                out = _lang_output_path(output_path, lang_code, ".rst")
                tex_gen.generate_rst(
                    spec, out,
                    overlay=boot_overlay_obj,
                    lang=lang_code,
                )
                logging.info("RST output written to: %s", out)

        if fmt == "csv":
            csv_dir = output_path.parent / (output_path.stem + "_csv")
            files = tex_gen.generate_csv(spec, csv_dir)
            logging.info("CSV output written to: %s (%d file(s))", csv_dir, len(files))

        elif fmt == "yaml":
            out = output_path.with_suffix(".yaml")
            tex_gen.generate_yaml(spec, out)
            logging.info("YAML output written to: %s", out)

        elif fmt == "json":
            out = output_path.with_suffix(".json")
            tex_gen.generate_json(spec, out)
            logging.info("JSON output written to: %s", out)

        elif fmt == "docx":
            out = output_path.with_suffix(".docx")
            tex_gen.generate_docx(spec, out)
            logging.info("DOCX output written to: %s", out)

        elif fmt == "odx":
            supplement = _load_odx_supplement(getattr(args, "odx_supplement", None))
            odx_dir = output_path.parent / output_path.stem
            tex_gen.generate_odx_dir(spec, odx_dir, supplement=supplement)
            logging.info("ODX loose files written to: %s", odx_dir)

        elif fmt == "pdx":
            supplement = _load_odx_supplement(getattr(args, "odx_supplement", None))
            pdx_out = output_path.with_suffix(".pdx")
            result_path = tex_gen.generate_pdx(spec, pdx_out, supplement=supplement)
            logging.info("PDX archive written to: %s", result_path)

        # Byte-level DID diagrams
        if getattr(args, "byte_diagrams", None):
            bd_dir = Path(args.byte_diagrams)
            bd_dir.mkdir(parents=True, exist_ok=True)
            bd_path = tex_gen.generate_byte_diagrams(spec, bd_dir)
            logging.info("Byte diagrams written to: %s", bd_path)

        # UML sequence diagrams
        if getattr(args, "sequence_diagrams", None):
            sd_dir = Path(args.sequence_diagrams)
            sd_dir.mkdir(parents=True, exist_ok=True)
            sd_paths = tex_gen.generate_sequence_diagrams(spec, sd_dir)
            logging.info("Sequence diagrams written to: %s (%d file(s))", sd_dir, len(sd_paths))

        # Heatmaps + timing diagrams
        if getattr(args, "visualizations", None):
            from udsxml2tex.visualizations import generate_all_visualizations
            viz_dir = Path(args.visualizations)
            viz_dir.mkdir(parents=True, exist_ok=True)
            viz_fmt = getattr(args, "viz_format", "both") or "both"
            viz_paths = generate_all_visualizations(spec, viz_dir, format=viz_fmt)
            logging.info("Visualizations written to: %s (%d file(s))",
                         viz_dir, len(viz_paths))

        # Also generate HTML when --html is set alongside --pdf
        if getattr(args, "html", False) and getattr(args, "pdf", False):
            html_output = output_path.with_suffix(".html")
            tex_gen.generate_html(spec, html_output)
            logging.info("HTML output written to: %s", html_output)

    except FileNotFoundError as e:
        logging.error("%s", e)
        return 1
    except Exception as e:
        logging.error("Failed to generate output: %s", e)
        return 1

    # --- Watch mode (must be last) --------------------------------------
    if getattr(args, "watch", False):
        return _run_watch(args, argv)

    return 0


def _run_repo_mode(args, parser) -> int:
    """Auto-discover and parse every UDS-relevant file in a repository.

    Walks ``args.repo`` for ARXML / C-source files, classifies them, parses
    them through the standard parsers, then forwards the result into the
    standard generation pipeline. Auto-detects single-ECU vs multi-ECU
    layout via :func:`detect_ecu_mode`:

    * **Single ECU** → :func:`load_from_repo` → :func:`_run_generation`
      (same code path as positional-input mode; supports every output
      format, filter, validation mode, LLM feature, etc.).
    * **Multi-ECU** → :func:`load_system_from_repo` →
      :func:`_run_system_generation` (per-ECU specs + integration
      document, same layout as ``--system`` mode).

    Override with ``--repo-mode {auto, single, multi}``.
    """
    from udsxml2tex.parser import ArxmlParser
    from udsxml2tex.repo_scanner import (
        detect_ecu_mode,
        load_from_repo,
        load_system_from_repo,
        partition_by_ecu,
        scan_repo,
    )

    repo_root = Path(args.repo)
    if not repo_root.exists() or not repo_root.is_dir():
        logging.error("--repo path is not a directory: %s", repo_root)
        return 1

    # Dry-run mode: print scan classification and exit.
    if getattr(args, "repo_dry_run", False):
        try:
            scan = scan_repo(
                repo_root,
                include_headers=getattr(args, "repo_include_headers", False),
                relevant_c_only=(getattr(args, "repo_relevant_c", "true") == "true"),
            )
        except FileNotFoundError as e:
            logging.error("%s", e)
            return 1
        print(scan.summary())
        for p in scan.dcm_arxmls:
            print(f"  Dcm    : {p}")
        for p in scan.cantp_arxmls:
            print(f"  CanTp  : {p}")
        for p in scan.dem_arxmls:
            print(f"  Dem    : {p}")
        for p in scan.doip_arxmls:
            print(f"  DoIp   : {p}")
        if scan.cls_files:
            print(f"  .cls   : {len(scan.cls_files)} file(s) "
                  "(not auto-loaded — pass --template-dir manually)")
        if scan.missing_modules:
            print(f"  Missing modules: {scan.missing_modules}")
        # Show ECU partition and auto-detected mode.
        parts = partition_by_ecu(scan)
        mode = "multi" if len(parts) >= 2 else "single"
        print(f"  Mode (auto): {mode}  ({len(parts)} ECU partition(s))")
        for part in parts:
            print(f"    ECU {part.name!r}: "
                  f"{len(part.dcm_arxmls)} Dcm, "
                  f"{len(part.cantp_arxmls)} CanTp, "
                  f"{len(part.dem_arxmls)} Dem")
        return 0 if scan.dcm_arxmls else 1

    # Resolve the auto-vs-forced mode.
    requested_mode = (getattr(args, "repo_mode", "auto") or "auto").lower()
    try:
        scan = scan_repo(
            repo_root,
            include_headers=getattr(args, "repo_include_headers", False),
            relevant_c_only=(getattr(args, "repo_relevant_c", "true") == "true"),
        )
    except FileNotFoundError as e:
        logging.error("--repo: %s", e)
        return 1
    if not scan.dcm_arxmls:
        logging.error(
            "--repo: no Dcm module configuration found under %s. "
            "udsxml2tex needs at least one ARXML file containing an "
            "ECUC-MODULE-CONFIGURATION-VALUES with a Dcm SHORT-NAME.",
            scan.root,
        )
        return 1
    if getattr(args, "repo_require_minimum", False) and scan.missing_modules:
        logging.error(
            "--repo: minimum-set module(s) %s missing under %s.",
            scan.missing_modules, scan.root,
        )
        return 1
    if scan.missing_modules:
        logging.warning(
            "repo_scanner: minimum-set module(s) %s not found under %s — "
            "spec will be incomplete. Pass --repo-require-minimum to refuse "
            "this case.",
            scan.missing_modules, scan.root,
        )

    mode = requested_mode if requested_mode in ("single", "multi") \
        else detect_ecu_mode(scan)
    logging.info(
        "repo_scanner: %s — detected mode=%s (requested=%s)",
        scan.summary(), mode, requested_mode,
    )

    # ------------------------------------------------------------------ #
    # Multi-ECU branch                                                   #
    # ------------------------------------------------------------------ #
    if mode == "multi":
        try:
            system, _, parts = load_system_from_repo(
                repo_root,
                c_scan_depth=getattr(args, "c_scan_depth", 0),
                include_headers=getattr(args, "repo_include_headers", False),
                relevant_c_only=(getattr(args, "repo_relevant_c", "true") == "true"),
                infer_routing=not getattr(args, "no_routing_inference", False),
            )
        except Exception as e:  # noqa: BLE001
            logging.error("--repo (multi-ECU): %s", e)
            return 1
        logging.info(
            "Loaded %d-ECU system from %s: %s",
            len(system.ecus), repo_root,
            ", ".join(p.name for p in parts),
        )
        out_dir = Path(args.system_output_dir or "uds-spec")
        out_dir.mkdir(parents=True, exist_ok=True)
        fmt = (getattr(args, "format", "tex") or "tex").lower()
        return _run_system_generation(system, out_dir, fmt, args)

    # ------------------------------------------------------------------ #
    # Single-ECU branch                                                  #
    # ------------------------------------------------------------------ #
    try:
        spec, scan = load_from_repo(
            repo_root,
            c_scan_depth=getattr(args, "c_scan_depth", 0),
            include_headers=getattr(args, "repo_include_headers", False),
            relevant_c_only=(getattr(args, "repo_relevant_c", "true") == "true"),
            require_minimum_set=getattr(args, "repo_require_minimum", False),
        )
    except ValueError as e:
        logging.error("--repo: %s", e)
        return 1
    except FileNotFoundError as e:
        logging.error("--repo: %s", e)
        return 1
    except Exception as e:  # noqa: BLE001
        logging.error("--repo failed: %s", e)
        return 1

    if getattr(args, "ecu_name", None):
        spec.ecu_name = args.ecu_name

    if args.output:
        output_path = Path(args.output)
    else:
        stem = scan.root.name or "uds"
        suffix = ".html" if args.html and not args.pdf else ".tex"
        output_path = Path.cwd() / f"{stem}_uds_spec{suffix}"

    input_paths = list(scan.dcm_arxmls) if scan.dcm_arxmls else [scan.root]
    arxml_parser = ArxmlParser()

    return _run_generation(
        spec,
        args,
        arxml_parser=arxml_parser,
        output_path=output_path,
        input_paths=input_paths,
        argv=None,
    )


def _print_dry_run_summary(spec, arxml_parser) -> int:
    """Print a summary of the parsed ARXML data (rich-formatted when available)."""
    from udsxml2tex._rich_output import print_dry_run, use_rich

    if use_rich():
        print_dry_run(spec, arxml_parser.warnings)
        return 0

    from udsxml2tex.models import UDS_SERVICE_NAMES

    print(f"\n{'=' * 60}")
    print(f"  udsxml2tex -- Dry Run Summary")
    print(f"{'=' * 60}")
    print(f"  ECU Name:          {spec.ecu_name}")
    print(f"  Protocol:          {spec.protocol_name}")
    if spec.protocol_type:
        print(f"  Protocol Type:     {spec.protocol_type}")
    print(f"  S3 Server Timeout: {spec.s3_server} s")
    print()

    print(f"  Sessions:          {len(spec.sessions)}")
    for s in sorted(spec.sessions, key=lambda x: x.session_id):
        print(f"    0x{s.session_id:02X} - {s.short_name} "
              f"(P2={s.p2_server_max}s, P2*={s.p2_star_server_max}s)")

    print(f"  Security Levels:   {len(spec.security_levels)}")
    for s in sorted(spec.security_levels, key=lambda x: x.security_level):
        print(f"    Level {s.security_level} - {s.short_name} "
              f"(seed={s.seed_size}B, key={s.key_size}B)")

    print(f"  Services:          {len(spec.services)}")
    for s in sorted(spec.services, key=lambda x: x.service_id):
        name = UDS_SERVICE_NAMES.get(s.service_id, s.short_name)
        sf_count = len(s.sub_functions)
        nrc_count = len(s.nrc_list)
        print(f"    0x{s.service_id:02X} - {name} "
              f"({sf_count} sub-functions, {nrc_count} NRCs)")

    print(f"  DIDs:              {len(spec.dids)}")
    print(f"  Routines:          {len(spec.routines)}")
    print(f"  DTCs:              {len(spec.dtcs)}")
    print(f"  Memory Ranges:     {len(spec.memory_ranges)}")
    print(f"  IO Control DIDs:   {len(spec.io_control_dids)}")
    print(f"  Periodic DIDs:     {len(spec.periodic_dids)}")
    print(f"  DID Ranges:        {len(spec.did_ranges)}")
    print(f"  Dynamic DIDs:      {len(spec.dynamic_dids)}")

    if spec.transport_config:
        print(f"  CanTp Channels:    {len(spec.transport_config.channels)}")
        print(f"  CAN-FD:            {'Yes' if spec.transport_config.can_fd_enabled else 'No'}")

    if arxml_parser.warnings:
        print(f"\n  Warnings:          {len(arxml_parser.warnings)}")
        for w in arxml_parser.warnings:
            print(f"    [{w.section}] {w.message}")

    print(f"\n{'=' * 60}")
    return 0


def _apply_filters(spec, args) -> None:
    """Apply --filter-dids / --filter-services / --filter-dtcs to spec in-place."""
    def _parse_ids(s: Optional[str]) -> Optional[set[int]]:
        if not s:
            return None
        ids: set[int] = set()
        for tok in s.split(","):
            tok = tok.strip()
            if tok:
                try:
                    ids.add(int(tok, 0))
                except ValueError:
                    logging.warning("Ignoring invalid ID in filter: %r", tok)
        return ids if ids else None

    did_ids = _parse_ids(getattr(args, "filter_dids", None))
    svc_ids = _parse_ids(getattr(args, "filter_services", None))
    dtc_ids = _parse_ids(getattr(args, "filter_dtcs", None))

    if did_ids is not None:
        spec.dids = [d for d in spec.dids if d.did_id in did_ids]
    if svc_ids is not None:
        spec.services = [s for s in spec.services if s.service_id in svc_ids]
    if dtc_ids is not None:
        spec.dtcs = [d for d in spec.dtcs if d.dtc_id in dtc_ids]


def _parse_langs(langs_arg, fallback_lang: str) -> list[str]:
    """Parse the ``--langs`` argument into a list of monolingual codes.

    When ``langs_arg`` is empty/None, returns ``[fallback_lang]`` (preserves
    single-language ``--lang`` behavior including bilingual codes like
    ``ja+en``).

    When ``langs_arg`` is set, splits on commas/whitespace, validates each
    code against :data:`udsxml2tex.i18n.MONOLINGUAL_LANGS`, deduplicates
    while preserving order, and raises ``ValueError`` on unknown codes.
    """
    if not langs_arg:
        return [fallback_lang]
    from udsxml2tex.i18n import MONOLINGUAL_LANGS
    tokens = [
        t.strip()
        for t in str(langs_arg).replace(";", ",").split(",")
        if t.strip()
    ]
    seen: set[str] = set()
    out: list[str] = []
    for tok in tokens:
        if tok not in MONOLINGUAL_LANGS:
            raise ValueError(
                f"Unknown language code in --langs: {tok!r}. "
                f"Allowed: {', '.join(MONOLINGUAL_LANGS)}"
            )
        if tok not in seen:
            seen.add(tok)
            out.append(tok)
    return out or [fallback_lang]


def _load_odx_supplement(path):  # type: ignore[no-untyped-def]
    """Load an ODX supplement YAML if ``path`` is set, otherwise return ``None``.

    Logs and raises on parsing errors so the CLI's outer ``try`` block can
    convert them to a non-zero exit code.
    """
    if path is None:
        return None
    from udsxml2tex.odx import load_supplement
    return load_supplement(path)


def _run_multi_ecu_system(args) -> int:
    """Handle --system mode: parse a system YAML/JSON, generate per-ECU specs +
    a system integration document.

    Output layout under --system-output-dir (default ./uds-spec/):
        <DIR>/<ecu_name>/spec.<ext>          # one per ECU
        <DIR>/system.<ext>                   # integration document

    The output format is taken from --format (default tex). LaTeX, HTML, and
    Markdown are fully supported; other formats fall back to per-ECU output
    only and a Markdown system document.
    """
    try:
        from udsxml2tex.multi_ecu import (
            generate_system_html,
            generate_system_html_zip,
            generate_system_latex,
            generate_system_markdown,
            generate_system_structured_tex_zip,
            load_system_config,
        )
    except ImportError as e:
        logging.error("multi_ecu module not available: %s", e)
        return 1

    cfg_path = Path(args.system)
    out_dir = Path(args.system_output_dir or "uds-spec")
    out_dir.mkdir(parents=True, exist_ok=True)
    fmt = (args.format or "tex").lower()

    # Load + parse + infer
    try:
        system = load_system_config(
            cfg_path,
            parse_arxml=True,
            infer_routing=not args.no_routing_inference,
        )
    except Exception as e:  # noqa: BLE001
        logging.error("Failed to load system config %s: %s", cfg_path, e)
        return 1

    logging.info(
        "Loaded system %r with %d ECU(s); %d routing rule(s) "
        "(%d explicit, %d inferred)",
        system.name, len(system.ecus), len(system.routing_rules),
        sum(1 for r in system.routing_rules if not r.inferred),
        sum(1 for r in system.routing_rules if r.inferred),
    )

    return _run_system_generation(system, out_dir, fmt, args)


def _run_system_generation(system, out_dir: Path, fmt: str, args) -> int:
    """Render per-ECU and integration docs for an in-memory EcuSystem.

    Shared by --system (YAML-driven) and --repo (auto-detected multi-ECU)
    paths so the output layout stays identical.
    """
    from udsxml2tex.multi_ecu import (
        generate_system_html_zip,
        generate_system_markdown,
        generate_system_structured_tex_zip,
    )

    # Per-ECU outputs via the existing TexGenerator. For tex/pdf and html
    # we now emit a single unified system document covering all ECUs
    # (Option B — per-section ECU interleaving), so the per-ECU loop is
    # skipped for those formats and handled below. ODX/PDX is also handled
    # as a single archive covering all ECUs, so we skip per-ECU output too.
    tex_gen = TexGenerator()
    skip_per_ecu = fmt in ("tex", "pdf", "html", "odx", "pdx")
    per_ecu_ext = {
        "tex": ".tex", "pdf": ".tex", "html": ".zip", "md": ".md",
        "rst": ".rst", "yaml": ".yaml", "json": ".json", "docx": ".docx",
    }.get(fmt, ".tex")

    for name, ecu in system.ecus.items():
        if not ecu.spec:
            continue
        if skip_per_ecu:
            continue
        ecu_dir = out_dir / name
        ecu_dir.mkdir(parents=True, exist_ok=True)
        spec_out = ecu_dir / f"spec{per_ecu_ext}"
        try:
            if fmt in ("tex", "pdf"):
                # `pdf` writes spec.tex first, then compiles below.
                tex_gen.generate(ecu.spec, spec_out)
            elif fmt == "html":
                tex_gen.generate_html_zip(ecu.spec, spec_out)
            elif fmt == "md":
                tex_gen.generate_markdown(ecu.spec, spec_out)
            elif fmt == "rst":
                tex_gen.generate_rst(ecu.spec, spec_out)
            elif fmt == "yaml":
                tex_gen.generate_yaml(ecu.spec, spec_out)
            elif fmt == "json":
                tex_gen.generate_json(ecu.spec, spec_out)
            elif fmt == "docx":
                tex_gen.generate_docx(ecu.spec, spec_out)
            elif fmt == "csv":
                csv_dir = ecu_dir / "spec_csv"
                tex_gen.generate_csv(ecu.spec, csv_dir)
            else:
                logging.warning("Unsupported per-ECU format %r; skipping %s",
                                fmt, name)
                continue
            logging.info("ECU %r: wrote %s", name, spec_out)
            if fmt == "pdf":
                pdf_path = tex_gen.compile_pdf(spec_out)
                logging.info("ECU %r: PDF written to: %s", name, pdf_path)
        except Exception as e:  # noqa: BLE001
            logging.error("ECU %r generation failed: %s", name, e)
            return 1

    # System integration document
    try:
        if fmt in ("tex", "pdf"):
            # ONE unified structured LaTeX project covering all ECUs
            # (Option B). The ZIP extracts a complete root.tex + per-ECU
            # section trees + bundled udsspec.cls / tikz-uml.sty.
            sys_zip = out_dir / "system_uds_spec.zip"
            generate_system_structured_tex_zip(system, sys_zip)
            logging.info("Unified system structured LaTeX ZIP: %s", sys_zip)

            # Extract for direct compilation when --format pdf was asked.
            import zipfile as _zf
            unified_dir = out_dir / "system_unified"
            unified_dir.mkdir(parents=True, exist_ok=True)
            with _zf.ZipFile(sys_zip) as zf:
                zf.extractall(unified_dir)
            sys_path = unified_dir / "root.tex"
        elif fmt == "html":
            # ONE unified browsable HTML site covering all ECUs (Option B).
            sys_zip = out_dir / "system_uds_spec.zip"
            generate_system_html_zip(system, sys_zip)
            logging.info("Unified system HTML ZIP: %s", sys_zip)
            sys_path = sys_zip
        elif fmt in ("odx", "pdx"):
            from udsxml2tex import __version__ as _udsxml2tex_version
            from udsxml2tex.odx import map_ecu_system_to_odx
            from udsxml2tex.odx.pdx_packager import (  # Agent 6 provides this
                pack_pdx,
                write_loose_odx,
            )

            supplement = _load_odx_supplement(getattr(args, "odx_supplement", None))
            documents = map_ecu_system_to_odx(system, supplement)
            if fmt == "pdx":
                sys_path = out_dir / "system.pdx"
                pack_pdx(
                    documents,
                    sys_path,
                    tool_version=f"udsxml2tex/{_udsxml2tex_version}",
                )
            else:
                sys_path = out_dir / "system_odx"
                sys_path.mkdir(parents=True, exist_ok=True)
                write_loose_odx(documents, sys_path)
        else:
            sys_text = generate_system_markdown(system)
            sys_path = out_dir / "system.md"
            sys_path.write_text(sys_text, encoding="utf-8")
        logging.info("System integration document written to: %s", sys_path)

        if fmt == "pdf":
            # Compile the unified root.tex inside system_unified/ where
            # udsspec.cls / tikz-uml.sty / reference.bib are already laid
            # out by generate_system_structured_tex_zip.
            sys_pdf = tex_gen.compile_pdf(sys_path)
            logging.info("Unified system PDF: %s", sys_pdf)
    except Exception as e:  # noqa: BLE001
        logging.error("System integration document generation failed: %s", e)
        return 1

    return 0


def _build_llm_config_from_args(args):  # type: ignore[no-untyped-def]
    """Layer CLI flags on top of $UDSXML2TEX_LLM_* / config file / defaults."""
    from udsxml2tex.llm_integration import LLMConfig

    # Start from --llm-config when given, otherwise auto-resolve.
    if getattr(args, "llm_config", None):
        cfg = LLMConfig.from_file(args.llm_config)
    else:
        cfg = LLMConfig.auto()

    # Per-flag overrides — only when explicitly set.
    if getattr(args, "llm_provider", None):
        cfg.provider = args.llm_provider
    if getattr(args, "llm_model", None):
        cfg.model = args.llm_model
    if getattr(args, "llm_base_url", None):
        cfg.base_url = args.llm_base_url
    if getattr(args, "llm_api_key", None):
        cfg.api_key = args.llm_api_key
    if getattr(args, "llm_structured_mode", None):
        cfg.structured_mode = args.llm_structured_mode
    return cfg


def _run_ecu_test(spec, args) -> int:
    """Run UDS test cases against a real ECU via CAN / ISO-TP."""
    try:
        from udsxml2tex.ecu_test.generator import generate_test_suite
        from udsxml2tex.ecu_test.formal_generator import generate_formal_test_suite
        from udsxml2tex.ecu_test.transport import make_connection
        from udsxml2tex.ecu_test.executor import EcuTestExecutor
        from udsxml2tex.ecu_test.logger import write_reports
        from udsxml2tex.ecu_test.coverage import analyze_coverage
    except ImportError:
        logging.error(
            "ECU test dependencies not installed. "
            "Run: pip install udsxml2tex[ecu-test]"
        )
        return 1

    # Optional key-function plugin
    key_functions: dict = {}
    if getattr(args, "ecu_key_plugin", None):
        plugin_path = Path(args.ecu_key_plugin)
        if not plugin_path.exists():
            logging.error("Key plugin not found: %s", plugin_path)
            return 1
        import importlib.util as _ilu
        spec_mod = _ilu.spec_from_file_location("_ecu_key_plugin", plugin_path)
        mod = _ilu.module_from_spec(spec_mod)  # type: ignore[arg-type]
        spec_mod.loader.exec_module(mod)  # type: ignore[union-attr]
        key_functions = getattr(mod, "key_functions", {})
        if not key_functions:
            logging.warning(
                "Key plugin %s does not define a 'key_functions' dict — "
                "security access steps will be skipped.",
                plugin_path,
            )

    # Parse explicit CAN IDs from CLI (hex strings)
    rx_id = int(args.ecu_rx_id, 16) if getattr(args, "ecu_rx_id", None) else None
    tx_id = int(args.ecu_tx_id, 16) if getattr(args, "ecu_tx_id", None) else None

    try:
        conn = make_connection(
            spec,
            interface=args.ecu_interface,
            channel=args.ecu_channel,
            bitrate=args.ecu_bitrate,
            fd=getattr(args, "ecu_fd", False),
            rx_id=rx_id,
            tx_id=tx_id,
        )
    except ValueError as exc:
        logging.error("Cannot build CAN connection: %s", exc)
        return 1

    categories = getattr(args, "ecu_categories", None) or None
    use_formal = getattr(args, "ecu_formal", False)
    if use_formal:
        cases = generate_formal_test_suite(spec, categories=categories)
        logging.info(
            "Formal model-checking: generated %d test case(s) for ECU '%s' "
            "(all-transitions T1 coverage).",
            len(cases),
            spec.ecu_name,
        )
    else:
        cases = generate_test_suite(spec, categories=categories)
        logging.info(
            "Generated %d test case(s) for ECU '%s'.", len(cases), spec.ecu_name
        )

    # Coverage analysis (before execution — tests which spec items are exercised)
    coverage_report = None
    if getattr(args, "ecu_coverage", False):
        coverage_report = analyze_coverage(spec, cases)
        logging.info(
            "Coverage: %d/%d spec items exercised (%.0f%%).",
            coverage_report.covered_count,
            coverage_report.total,
            coverage_report.coverage_pct(),
        )

    try:
        with EcuTestExecutor(
            conn,
            key_functions=key_functions,
            default_timeout=args.ecu_timeout,
        ) as exe:
            suite = exe.run(
                cases,
                spec_name=spec.ecu_name,
                interface=args.ecu_interface,
                channel=args.ecu_channel,
            )
    except Exception as exc:  # noqa: BLE001
        logging.error("ECU test run failed: %s", exc)
        return 1

    # LLM test case rationale generation (optional, before writing reports)
    rationales: Optional[dict] = None
    if getattr(args, "ecu_test_rationale", False):
        try:
            from udsxml2tex.llm_integration import generate_test_rationale
            cfg = _build_llm_config_from_args(args)
            logging.info("Generating test rationales via LLM (%s)…", cfg.resolved_model())
            rationales = generate_test_rationale(spec, cases, config=cfg)
            logging.info("Rationales generated for %d test case(s).", len(rationales))
        except Exception as exc:  # noqa: BLE001
            logging.warning("LLM rationale generation failed (skipped): %s", exc)

    paths = write_reports(
        suite, out_dir=args.ecu_output, coverage=coverage_report, rationales=rationales,
    )
    logging.info(
        "ECU test complete — %d/%d passed (%.0f%%). Reports: %s",
        suite.passed,
        suite.total,
        suite.pass_rate,
        paths["html"],
    )
    if coverage_report is not None:
        logging.info("Coverage report: %s", paths.get("coverage", ""))
    if suite.failed > 0 or suite.errors > 0:
        logging.warning(
            "%d failed, %d error(s).", suite.failed, suite.errors
        )
        return 1
    return 0


def _run_llm(spec, args) -> int:
    """Dispatch --llm-summarize / --llm-query / --llm-nrc-descriptions."""
    try:
        from udsxml2tex import llm_integration as llm
    except ImportError as e:
        logging.error("%s", e)
        return 1

    target_lang = getattr(args, "llm_translate", None)
    out_path = getattr(args, "llm_output", None)
    cfg = _build_llm_config_from_args(args)
    logging.info(
        "LLM provider: %s, model: %s%s",
        cfg.provider, cfg.resolved_model() or cfg.model,
        f", base_url: {cfg.resolved_base_url()}" if cfg.provider == "openai" else "",
    )

    try:
        if args.llm_nrc_descriptions:
            descriptions = llm.complete_nrc_descriptions(spec, config=cfg)
            text = json.dumps(
                {f"0x{k:02X}": v for k, v in sorted(descriptions.items())},
                indent=2, ensure_ascii=False,
            )
        elif args.llm_query is not None:
            text = llm.query_spec(spec, args.llm_query, config=cfg)
            if target_lang:
                text = llm.translate_text(text, target_lang, config=cfg)
        else:
            length = args.llm_summarize or "1page"
            text = llm.summarize_spec(spec, length=length, config=cfg)
            if target_lang:
                text = llm.translate_text(text, target_lang, config=cfg)
    except Exception as e:  # noqa: BLE001
        logging.error("LLM call failed: %s", e)
        return 1

    if out_path:
        Path(out_path).write_text(text, encoding="utf-8")
        logging.info("LLM output written to: %s", out_path)
    else:
        print(text)
    return 0


def _run_changelog(spec, args, input_path: Path) -> int:
    """Diff spec against a baseline and write a change-history chapter."""
    baseline_path = Path(args.changelog_from)
    if not baseline_path.exists():
        logging.error("Baseline file not found: %s", baseline_path)
        return 1
    try:
        if baseline_path.suffix.lower() == ".json":
            from udsxml2tex.models import UdsSpecification as _UdsSpec
            spec_old = _UdsSpec.load_json(baseline_path)
        else:
            spec_old = ArxmlParser().parse(baseline_path)
    except Exception as e:
        logging.error("Failed to load baseline: %s", e)
        return 1

    fmt = getattr(args, "changelog_format", "tex")
    old_label = getattr(args, "changelog_old_label", None) or baseline_path.stem
    new_label = getattr(args, "changelog_new_label", None) or input_path.stem
    lang = getattr(args, "lang", "en")

    out_path: Path
    if args.output:
        out_path = Path(args.output)
    else:
        out_path = input_path.parent / f"{input_path.stem}_changelog"

    try:
        tex_gen = TexGenerator(template_dir=args.template_dir)
        result = tex_gen.generate_changelog_chapter(
            spec_old, spec, out_path,
            fmt=fmt, old_label=old_label, new_label=new_label, lang=lang,
        )
        logging.info("Change-history chapter written to: %s", result)
        return 0
    except Exception as e:
        logging.error("Failed to generate changelog: %s", e)
        return 1


def _run_validate(spec, *, as_json: bool = False) -> int:
    """Run ISO 14229-1 validation and print results. Returns 1 if errors found."""
    try:
        from udsxml2tex.validator import UdsValidator
    except ImportError:
        logging.error("validator module not available.")
        return 1

    result = UdsValidator().validate(spec)
    if as_json:
        import json as _json
        issues = [
            {
                "severity": i.severity,
                "category": i.category,
                "message": i.message,
                "item_id": i.item_id,
            }
            for i in result.issues
        ]
        print(_json.dumps(issues, ensure_ascii=False))
    else:
        from udsxml2tex._rich_output import print_validation
        print_validation(result)
    return 1 if result.has_errors() else 0


def _run_diff(spec_a, diff_target: str) -> int:
    """Compare spec_a against diff_target (ARXML or JSON) and print diff."""
    try:
        from udsxml2tex.diff import SpecDiffer
    except ImportError:
        logging.error("diff module not available.")
        return 1

    target_path = Path(diff_target)
    if not target_path.exists():
        logging.error("Diff target not found: %s", target_path)
        return 1

    try:
        if target_path.suffix.lower() == ".json":
            from udsxml2tex.models import UdsSpecification
            spec_b = UdsSpecification.load_json(target_path)
        else:
            spec_b = ArxmlParser().parse(target_path)
    except Exception as e:
        logging.error("Failed to load diff target: %s", e)
        return 1

    diff = SpecDiffer().diff(spec_a, spec_b)
    from udsxml2tex._rich_output import print_diff_markdown
    print_diff_markdown(diff.to_markdown())
    return 0


def _run_watch(args, argv: Optional[list[str]]) -> int:
    """Watch input files and re-run generation on changes."""
    try:
        from watchdog.observers import Observer  # type: ignore[import]
        from watchdog.events import FileSystemEventHandler  # type: ignore[import]
    except ImportError:
        logging.error(
            "watchdog is required for --watch mode. "
            "Install it with: pip install udsxml2tex[watch]"
        )
        return 1

    import time

    watch_paths = list(args.input)
    if getattr(args, "dem", None):
        watch_paths.append(args.dem)

    logging.info("Watching %d file(s) for changes. Press Ctrl+C to stop.", len(watch_paths))

    class _Handler(FileSystemEventHandler):
        def on_modified(self, event):  # type: ignore[override]
            if event.src_path in watch_paths:
                logging.info("Change detected: %s — regenerating…", event.src_path)
                # Re-run without --watch to avoid recursion
                filtered = [a for a in (argv or sys.argv[1:]) if a != "--watch"]
                main(filtered)

    observer = Observer()
    watched_dirs: set[str] = set()
    for p in watch_paths:
        d = str(Path(p).parent.resolve())
        if d not in watched_dirs:
            observer.schedule(_Handler(), d, recursive=False)
            watched_dirs.add(d)

    observer.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()
    return 0


if __name__ == "__main__":
    sys.exit(main())
