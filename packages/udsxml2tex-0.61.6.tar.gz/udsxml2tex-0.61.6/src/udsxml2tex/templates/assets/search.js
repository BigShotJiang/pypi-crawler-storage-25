/* udsxml2tex — in-document search.
 *
 * Reads window.SEARCH_INDEX (an array of {title, href, kind, hint, hay}
 * objects, supplied by the sibling search-index.js) and wires the
 * <input id="docsearch"> / <div id="docsearch-results"> elements that
 * _html_page() injects into the nav sidebar.
 *
 * Notes:
 *   - hrefs in the index are relative to the page root; we rewrite them
 *     against the current page using a simple base-path heuristic so the
 *     same index works on every page in the bundle.
 *   - Pure-substring matcher (case-insensitive). Token-ANDed across the
 *     whitespace-split query, scored by title-prefix > title-contains
 *     > hint-contains > hay-contains. Top 20 results are shown.
 *   - No external runtime dependency.
 */
(function () {
  "use strict";
  var idx = window.SEARCH_INDEX || [];
  var input = document.getElementById("docsearch");
  var box = document.getElementById("docsearch-results");
  if (!input || !box || !idx.length) return;

  // Compute "../" prefix to convert root-relative href into page-relative.
  function rootPrefix() {
    var p = window.location.pathname.replace(/\\/g, "/");
    // Strip filename → leave directory part
    var slash = p.lastIndexOf("/");
    var dir = slash >= 0 ? p.slice(0, slash) : "";
    // Count depth from the bundle root by looking at how many slashes
    // sit after the bundle root. Heuristic: count occurrences of '/' in
    // the directory part relative to the index page. Since we can't know
    // the root location for sure, fall back to walking the path until we
    // find an "index.html" sibling at the top. In practice the bundle is
    // always extracted as a folder, so we use the depth of '/sections/'.
    var i = dir.indexOf("/sections/");
    if (i < 0) return ""; // already at root
    var tail = dir.slice(i + 1);
    var depth = tail.split("/").filter(Boolean).length;
    return new Array(depth + 1).join("../");
  }
  var prefix = rootPrefix();

  function score(entry, tokens) {
    var t = entry._title;
    var h = entry._hint;
    var a = entry._hay;
    var s = 0;
    for (var i = 0; i < tokens.length; i++) {
      var tok = tokens[i];
      if (!tok) continue;
      if (t.indexOf(tok) === 0) s += 100;
      else if (t.indexOf(tok) >= 0) s += 40;
      else if (h.indexOf(tok) >= 0) s += 15;
      else if (a.indexOf(tok) >= 0) s += 5;
      else return -1; // token missing → drop
    }
    return s;
  }

  // Pre-normalise for case-insensitive search.
  for (var k = 0; k < idx.length; k++) {
    var e = idx[k];
    e._title = (e.title || "").toLowerCase();
    e._hint = (e.hint || "").toLowerCase();
    e._hay = (e.hay || "").toLowerCase();
  }

  var selIdx = -1;
  var current = [];

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return {"&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;"}[c];
    });
  }

  function render() {
    if (!current.length) {
      box.innerHTML = '<div class="empty">No matches.</div>';
      box.classList.add("show");
      return;
    }
    var html = "";
    for (var i = 0; i < current.length; i++) {
      var e = current[i];
      var cls = i === selIdx ? ' class="sel"' : "";
      html += '<a href="' + escapeHtml(prefix + e.href) + '"' + cls + '>'
           + escapeHtml(e.title)
           + '<span class="kind">' + escapeHtml(e.kind || "") + '</span></a>';
    }
    box.innerHTML = html;
    box.classList.add("show");
  }

  function update() {
    var q = input.value.trim().toLowerCase();
    if (!q) { box.classList.remove("show"); current = []; selIdx = -1; return; }
    var tokens = q.split(/\s+/);
    var scored = [];
    for (var i = 0; i < idx.length; i++) {
      var s = score(idx[i], tokens);
      if (s > 0) scored.push([s, i, idx[i]]);
    }
    scored.sort(function (a, b) { return b[0] - a[0]; });
    current = scored.slice(0, 20).map(function (r) { return r[2]; });
    selIdx = current.length ? 0 : -1;
    render();
  }

  input.addEventListener("input", update);
  input.addEventListener("focus", function () { if (input.value) update(); });
  input.addEventListener("keydown", function (ev) {
    if (!current.length) return;
    if (ev.key === "ArrowDown") {
      selIdx = (selIdx + 1) % current.length;
      render();
      ev.preventDefault();
    } else if (ev.key === "ArrowUp") {
      selIdx = (selIdx - 1 + current.length) % current.length;
      render();
      ev.preventDefault();
    } else if (ev.key === "Enter") {
      if (selIdx >= 0) {
        window.location.href = prefix + current[selIdx].href;
        ev.preventDefault();
      }
    } else if (ev.key === "Escape") {
      box.classList.remove("show");
      input.blur();
    }
  });
  document.addEventListener("click", function (ev) {
    if (ev.target !== input && !box.contains(ev.target)) {
      box.classList.remove("show");
    }
  });
})();
