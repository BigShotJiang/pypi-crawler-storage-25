/**
 * sample_did.c — Example DID read/write implementation
 *
 * This file demonstrates how udsxml2tex extracts global variable references
 * from DID service handler functions.  The tool scans for variables declared
 * at file scope (or extern-linked) that are read or written inside each
 * DID function matched by the ARXML DcmDspData ReadFnc / WriteFnc names.
 */

#include <stdint.h>
#include <string.h>

/* --------------------------------------------------------------------- */
/* Global state variables referenced by DID handlers                      */
/* --------------------------------------------------------------------- */

uint8_t  g_vin[17];                   /* Vehicle Identification Number  */
uint16_t g_app_version_major;
uint16_t g_app_version_minor;
uint8_t  g_app_version_patch;
uint8_t  g_ecu_serial_number[8];
uint8_t  g_output_control_mask;
uint8_t  g_io_control_state;

/* --------------------------------------------------------------------- */
/* DID 0xF190 — VehicleIdentificationNumber (read-only)                  */
/* --------------------------------------------------------------------- */

Std_ReturnType Did_0xF190_ReadData(uint8_t *Data)
{
    (void)memcpy(Data, g_vin, sizeof(g_vin));
    return E_OK;
}

/* --------------------------------------------------------------------- */
/* DID 0xF101 — ApplicationSoftwareVersion (read-only)                   */
/* --------------------------------------------------------------------- */

Std_ReturnType Did_0xF101_ReadData(uint8_t *Data)
{
    Data[0] = (uint8_t)(g_app_version_major >> 8);
    Data[1] = (uint8_t)(g_app_version_major);
    Data[2] = (uint8_t)(g_app_version_minor >> 8);
    Data[3] = (uint8_t)(g_app_version_minor);
    Data[4] = g_app_version_patch;
    return E_OK;
}

/* --------------------------------------------------------------------- */
/* DID 0xF18C — ECUSerialNumber (read-only)                              */
/* --------------------------------------------------------------------- */

Std_ReturnType Did_0xF18C_ReadData(uint8_t *Data)
{
    (void)memcpy(Data, g_ecu_serial_number, sizeof(g_ecu_serial_number));
    return E_OK;
}

/* --------------------------------------------------------------------- */
/* DID 0xD001 — OutputControlMask (read/write)                           */
/* --------------------------------------------------------------------- */

Std_ReturnType Did_0xD001_ReadData(uint8_t *Data)
{
    Data[0] = g_output_control_mask;
    Data[1] = g_io_control_state;
    return E_OK;
}

Std_ReturnType Did_0xD001_WriteData(const uint8_t *Data, uint16_t Length)
{
    if (Length < 2U) {
        return E_NOT_OK;
    }
    g_output_control_mask = Data[0];
    g_io_control_state    = Data[1];
    return E_OK;
}

/* --------------------------------------------------------------------- */
/* XCP/A2L-monitored measurement globals                                  */
/*                                                                        */
/* Each of these globals is a runtime measurement variable that the SW-C  */
/* publishes to XCP via the project's A2L MEASUREMENT table (i.e. they    */
/* are observable from a measurement & calibration tool like INCA,        */
/* CANape, or vMon over XCP-on-CAN/CAN-FD/Ethernet).                      */
/*                                                                        */
/* The UDS read handlers below expose the same values via                 */
/* ReadDataByIdentifier (SID 0x22) so a diagnostic tester can fetch them  */
/* without an XCP slave session. This makes the DID -> A2L-variable       */
/* mapping explicit: the C-scanner pass run by udsxml2tex --c-scan        */
/* walks each Rte_Read_Did_* body and emits the referenced global names   */
/* into the "Global Variables" column of the generated UDS spec.          */
/* --------------------------------------------------------------------- */

uint16_t XcpMeas_BattVoltage_mV;       /* A2L MEASUREMENT: battery voltage [mV] */
sint8_t  XcpMeas_CoolantTemp_degC;     /* A2L MEASUREMENT: coolant temp  [degC] */
uint16_t XcpMeas_EngineSpeed_rpm;      /* A2L MEASUREMENT: engine speed  [rpm]  */

/* --------------------------------------------------------------------- */
/* DID 0xF140 -- EcuBatteryVoltage (read-only)                            */
/* --------------------------------------------------------------------- */
Std_ReturnType Rte_Read_Did_F140_BattVoltage(uint8_t *Data)
{
    Data[0] = (uint8_t)(XcpMeas_BattVoltage_mV >> 8);
    Data[1] = (uint8_t)(XcpMeas_BattVoltage_mV);
    return E_OK;
}

/* --------------------------------------------------------------------- */
/* DID 0xF141 -- EngineCoolantTemp (read-only)                            */
/* --------------------------------------------------------------------- */
Std_ReturnType Rte_Read_Did_F141_CoolantTemp(uint8_t *Data)
{
    Data[0] = (uint8_t)XcpMeas_CoolantTemp_degC;
    return E_OK;
}

/* --------------------------------------------------------------------- */
/* DID 0xF142 -- EngineSpeed (read-only)                                  */
/* --------------------------------------------------------------------- */
Std_ReturnType Rte_Read_Did_F142_EngineSpeed(uint8_t *Data)
{
    Data[0] = (uint8_t)(XcpMeas_EngineSpeed_rpm >> 8);
    Data[1] = (uint8_t)(XcpMeas_EngineSpeed_rpm);
    return E_OK;
}
