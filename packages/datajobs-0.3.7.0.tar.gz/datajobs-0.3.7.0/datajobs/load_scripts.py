from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
from unittest import result
from pytz import timezone
from databricks.sdk import WorkspaceClient
from pyspark.sql import SparkSession
import sys
import time
import json
import os
import hashlib
import logging
import re
import pandas as pd
from .utils_logger import setup_logger
from .utils_postgres import DbConnections, execute_run_postgres
from .utils_databricks import execute_run_databricks

class LoadScripts:
    def __init__(self, base_dir: Optional[str] = None):
        self.logger = None

        self.config: Dict[str, Any] = {}
        self.template: Dict[str, Any] = {}
        self.jobs: Dict[str, List[Dict[str, Any]]] = {}
        self.execution_id: Optional[int] = None
        self.job_start_time: Optional[float] = None
        
        self.databricks_client = None
        try:
            self.databricks_client = WorkspaceClient()
        except Exception:
            self.databricks_client = None

        if base_dir:
            self.base_dir = base_dir

        elif os.getenv("BRV_BASE_DIR"):
            self.base_dir = os.getenv("BRV_BASE_DIR")
        else:
            self.base_dir = os.getcwd()
    
    def resolve_relative_path(self, raw_path: str) -> str:
        raw_path = raw_path.strip().lstrip("/\\")

        possible_paths = [
            os.path.join(self.base_dir, raw_path),
            os.path.join(self.base_dir, "datajobs", "jobs", raw_path),
            os.path.join(os.getcwd(), raw_path),
            os.path.join(os.getcwd(), "datajobs", "jobs", raw_path),
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "jobs", raw_path),
        ]

        for path in possible_paths:
            if os.path.exists(path):
                if self.logger:
                    self.logger.debug(f"Resolved '{raw_path}' → '{path}'")
                return os.path.abspath(path)

        raise FileNotFoundError(f"File not found: {raw_path}")

    def _workspace_candidates(self, file_path: str):
        normalized_path = file_path.strip().lstrip("/\\")
        candidates = []

        if file_path.startswith("/"):
            candidates.append(file_path)

        if self.base_dir and self.base_dir.startswith("/"):
            candidates.append(f"{self.base_dir.rstrip('/')}/{normalized_path}")

        candidates.append(f"/{normalized_path}")
        return candidates

    def _download_workspace_file(self, file_path: str) -> str:
        if self.databricks_client is None:
            raise FileNotFoundError(f"Databricks workspace client unavailable: {file_path}")

        for workspace_path in self._workspace_candidates(file_path):
            try:
                if self.logger:
                    self.logger.debug(f"Downloading workspace file: {workspace_path}")
                with self.databricks_client.workspace.download(workspace_path) as f:
                    return f.read().decode("utf-8")
            except Exception as e:
                if self.logger:
                    self.logger.debug(f"Workspace download failed for {workspace_path}: {e}")

        raise FileNotFoundError(f"Workspace file not found: {file_path}")

    def load_config(self, config_path: str):
        with open(config_path, 'r') as f:
            self.config = json.load(f)

    def split_config_object(self):
        if 'JOBS' in self.config:
            self.template = {k: v for k, v in self.config.items() if k != 'JOBS'}
            self.jobs = {'JOBS': self.config['JOBS']}
            return self.template, self.jobs
        else:
            self.logger.warning("Array 'JOBS' not found in job object.")
            return self.template, None

    def run_exe(self, s: str) -> int:
        # Use consistent hashing and ensure non-negative number
        return abs(hash(s)) % (sys.maxsize + 1)

    def init_other_variables(self):
        # Use UTC date to avoid timezone issues
        hash_string = (datetime.utcnow() - timedelta(days=1)).strftime("%Y%m%d%H%M%S")
        self.execution_id = self.run_exe(hash_string)
        self.job_start_time = time.time()
        if self.logger:
            self.logger.debug(f"base_dir resolved to: {self.base_dir}")
            self.logger.debug(f"cwd: {os.getcwd()}")

    def set_system_variables(self, job: Dict[str, Any]) -> Dict[str, Any]:
        self.init_other_variables()
        hash_string = f"{job['TEAM_NAME']}{job['DOMAIN_NAME']}{job['CATEGORY_NAME']}{job['JOB_ID']}"
        unique_rule_identifier = self.run_exe(hash_string)
        job['EXECUTION_ID'] = self.execution_id
        job['UNIQUE_RULE_IDENTIFIER'] = unique_rule_identifier
        job['UNIQUE_TIMESTAMP'] = datetime.utcnow().strftime("%Y%m%d%H%M%S%f")
        return job

    def replace_common_variables(self,sql_str, job):
        """
        Replaces placeholders in sql_str with corresponding values from the job dictionary.
        Any placeholder in the format <PLACEHOLDER_NAME> will be dynamically replaced.
        """
        final_sql = sql_str
        for key, value in job.items():
            placeholder = f'<{key}>'
            final_sql = final_sql.replace(placeholder, str(value))
        return final_sql

    def get_file_text(self, file_path: str, is_local: bool = False) -> str:
        """
        Read file content from local filesystem or Databricks workspace.
        """
        normalized_path = file_path.strip().lstrip("/\\")

        if is_local:
            local_candidates = [
                os.path.join(self.base_dir, normalized_path),
                os.path.join(self.base_dir, "datajobs", "jobs", normalized_path),
                os.path.join(os.getcwd(), normalized_path),
                os.path.join(os.getcwd(), "datajobs", "jobs", normalized_path),
                os.path.join(os.path.dirname(os.path.abspath(__file__)), "jobs", normalized_path),
            ]

            for full_path in local_candidates:
                if os.path.exists(full_path):
                    if self.logger:
                        self.logger.info(f"Reading local file: {full_path}")
                    try:
                        with open(full_path, 'r', encoding='utf-8') as file:
                            return file.read()
                    except UnicodeDecodeError:
                        if self.logger:
                            self.logger.warning(f"UTF-8 decoding failed for {full_path}, retrying with latin-1")
                        with open(full_path, 'r', encoding='latin-1') as file:
                            return file.read()

            if self.databricks_client is not None:
                return self._download_workspace_file(file_path)

            raise FileNotFoundError(f"File not found: {file_path} (BASE_DIR={self.base_dir})")

        return self._download_workspace_file(file_path)

    def set_custom_template(self, job: Dict[str, Any]) -> Dict[str, Any]:
        """Add SQL template paths to the job based on engine type.
        
        Args:
            job: job configuration dictionary
            
        Returns:
            Updated job with SQL template paths and formatted SQL results
        """
        custom_template_path =  job.get('JOB_SCRIPTS', '')
        if not custom_template_path:
            self.logger.debug("No JOB_SCRIPTS found in job, skipping adding SQL template")
            return job

        try:
            self.logger.debug(f"DEBUG: Found JOB_SCRIPTS: {custom_template_path}")
            self.logger.info(f"Processing SQL template from: {custom_template_path}")
            
            # Remove leading slash if present and normalize path
            if custom_template_path.startswith('/'):
                custom_template_path = custom_template_path[1:]

            self.logger.debug(f"DEBUG: Normalized path: {custom_template_path}")

            # Read the SQL content from the file
            template_sql_content = self.get_file_text(custom_template_path, is_local=True)
            template_sql_content = template_sql_content.strip()

            

           # Step 1: Apply CODE_SNIPPETS if present
            if 'CODE_SNIPPETS' in job:
                self.logger.debug("DEBUG: Found CODE_SNIPPETS in job")
                template_sql_content = self.inject_snippets_into_template(job, template_sql_content)

            self.logger.debug("DEBUG: Running tests folder injection")
            template_sql_content = self.inject_sql_folder(job, template_sql_content, "tests")

            self.logger.debug("DEBUG: Running validations folder injection")
            template_sql_content = self.inject_sql_folder(job, template_sql_content, "validations")
            # Final assignment
            job['JOB_SCRIPTS_SQL'] = template_sql_content

            self.logger.debug(f"DEBUG: SQL content loaded: {template_sql_content[:100]}...")  # First 100 chars
            self.logger.info(f"Executing SQL Template: {template_sql_content}")

            # Check if SQL content is empty
            if not template_sql_content:
                self.logger.debug("DEBUG: Template SQL content is empty")
                self.logger.warning("SQL template content is empty, skipping execution")
                return job

        except FileNotFoundError as e:
            self.logger.debug(f"DEBUG: File not found error: {str(e)}")
            self.logger.error(f"SQL template file not found: {custom_template_path}. Error: {str(e)}")
        except Exception as e:
            self.logger.debug(f"DEBUG: General error: {str(e)}")
            self.logger.error(f"Error processing SQL template: {str(e)}")    
        
        return job


    def extract_snippet_blocks(self, sql_text: str) -> Dict[str, str]:
        """
        Extracts SQL code blocks from a snippet file using markers like:
            #START <TAG>
            ...SQL code...
            #END <TAG>
        Returns a dict: { "TAG": "…sql code…" }
        """
        #pattern = r"#START\s+(#EXEC\s+)?<(?P<tag>[^>]+)>\s*(?P<code>.*?)#END\s+<\2>"
        pattern = r"#START\s+(#EXEC\s+)?<(?P<tag>[^>]+)>\s*(?P<code>.*?)#END\s+<(?P=tag)>"
        #pattern = r"#START\s+<(?P<tag>[^>]+)>\s*(?P<code>.*?)#END\s+<\1>"
        matches = re.finditer(pattern, sql_text, re.DOTALL | re.IGNORECASE)
        blocks = {}
        for match in matches:
            exec_flag = bool(match.group(1))
            tag = match.group("tag").strip()
            code = match.group("code").strip()
            blocks[tag] = {"code": code, "exec": exec_flag}
        return blocks

    def execute_sql_scalar(self, sql_text: str, engine_type: str) -> Any:
        """
        Runs the given SQL as a scalar query and returns the first cell.
        Handles Databricks or Postgres.
        """
        engine_type = engine_type.lower()

        if engine_type == 'postgres':
            # Postgres: use your helper
            db_connection = DbConnections()
            engine = db_connection.postgres_engine()
            result = execute_run_postgres(sql_text, engine, retrieve_result=True)
            if result and isinstance(result, list) and len(result) > 0:
                rows = result[0][1:]  # skip header
                if rows:
                    return rows[0][0]
            return None
        
        elif engine_type == 'databricks':
            result = execute_run_databricks(sql_text, retrieve_result=True)
            if result and isinstance(result, list) and len(result) > 1:  # ✅ need at least 2 elements (header + data)
                first_row = result[1]  # ✅ result[0]=headers, result[1]=first data row
                if first_row is not None and len(first_row) > 0:
                    val = first_row[0]
                    return str(val).strip() if val is not None else ""
            return ""



    def assign_snippet_blocks_to_job(self, job: Dict[str, Any]) -> Dict[str, Any]:
        """
        Assigns values from SQL snippet blocks into the job dictionary.
        For example:
            #START <SCHEMA>
            seacomp
            #END <SCHEMA>
        becomes job["SCHEMA"] = "seacomp"

        Args:
            job: job dictionary containing CODE_SNIPPETS.

        Returns:
            Updated job with direct assignments from snippet blocks.
        """
        snippet_blocks = {}
        engine_type = job.get("ENGINE_TYPE", "").lower()

        # Safely get and sort CODE_SNIPPETS
        snippets = sorted(job.get("CODE_SNIPPETS", []), key=lambda x: x.get("order", 0))

        for snippet_info in snippets:
            path = snippet_info.get("path")
            if not path:
                continue
            try:
                sql_text = self.get_file_text(path, is_local=True).strip()
                if "tests" in path.lower():
                    file_name = os.path.splitext(os.path.basename(path))[0]  # test_file1.sql → test_file1
                    snippet_blocks[file_name] = sql_text
                    continue 

                blocks = self.extract_snippet_blocks(sql_text)
                for tag, block_info in blocks.items():
                    if block_info["exec"]:
                        sql_to_run = self.replace_common_variables(block_info["code"], job)
                        result = self.execute_sql_scalar(sql_to_run, engine_type)
                        snippet_blocks[tag] = result.strip() if isinstance(result, str) else (str(result).strip() if result else "")
                    else:
                        snippet_blocks[tag] = block_info["code"]
            except FileNotFoundError:
                self.logger.debug(f"DEBUG: Snippet file not found: {path} -- Skipping.")
                self.logger.warning(f"Snippet file not found: {path} -- Skipping.")

        # Update job with block values
        job.update(snippet_blocks)
        return job

    def update_sql_blocks_file(self, folder_name: str) -> Dict[str, Any]:

        allowed = {
            "tests": "TEST",
            "validations": "VALIDATION"
        }

        try:
            if folder_name not in allowed:
                raise ValueError(f"Unsupported folder: {folder_name}")

            try:
                input_folder = self.resolve_relative_path(folder_name)
            except FileNotFoundError:
                input_folder = None

            output_folder = self.resolve_relative_path("code_snippets")
            output_file = os.path.join(output_folder, f"{folder_name}.sql")

            os.makedirs(output_folder, exist_ok=True)

            # ✅ Folder not found
            if not input_folder or not os.path.exists(input_folder):
                print(f"⚠️ Folder not found: {folder_name}")
                return {
                    "status": "warning",
                    "message": f"Folder not found: {folder_name}",
                    "blocks_created": 0
                }

            blocks = []

            for file in sorted(os.listdir(input_folder)):
                if file.endswith(".sql"):

                    file_name = os.path.splitext(file)[0]
                    file_name = file_name.replace(".sql", "").replace(".", "_").upper()

                    if folder_name == "tests":
                        block = f"""
#START <TESTS_{file_name}>
CREATE OR REPLACE TEMP VIEW temp_{file_name}_test_config_<RUN_ID> AS
<TEST_SCRIPT_{file_name}>
<LOG_RESULT>
SELECT * FROM temp_{file_name}_test_config_<RUN_ID>;
<BATCH_PROCESS_TEST_FAILED>
#END <TESTS_{file_name}>
    """.strip()

                    elif folder_name == "validations":
                        block = f"""
#START <VALIDATIONS_{file_name}>
--------------Validation Checks-----------------------
CREATE OR REPLACE TEMP VIEW dataset_<RUN_ID> AS
SELECT 
    *,
    concat_ws(',', <VALIDATION_SCRIPT_{file_name}>) AS error_messages
FROM extract_dataset_<RUN_ID>;
<INSERT_BATCH_REJECTS>
#END <VALIDATIONS_{file_name}>
    """.strip()

                    blocks.append(block)

            # ✅ No SQL files
            if not blocks:
                print(f"⚠️ No SQL files found in: {input_folder}")
                return {
                    "status": "warning",
                    "message": f"No SQL files found in {input_folder}",
                    "blocks_created": 0
                }

            new_content = "\n\n".join(blocks) + "\n"

            old_content = ""
            if os.path.exists(output_file):
                with open(output_file, "r") as f:
                    old_content = f.read()

            if new_content != old_content:
                with open(output_file, "w") as f:
                    f.write(new_content)

                return {
                    "status": "updated",
                    "message": f"{folder_name}.sql updated",
                    "blocks_created": len(blocks)
                }

            else:
                return {
                    "status": "no_change",
                    "message": f"No changes in {folder_name}.sql",
                    "blocks_created": len(blocks)
                }

        except Exception as e:
            print(f"❌ Error in update_sql_blocks_file ({folder_name}): {str(e)}")
            return {
                "status": "error",
                "message": str(e),
                "blocks_created": 0
            }


    def inject_snippets_into_template(self, job: Dict[str, Any], template_sql: str) -> str:
        """
        Replaces placeholders in template_sql with snippets defined in job["CODE_SNIPPETS"].
        Placeholders are:
        - #START <TAG>...#END <TAG>
        - or <TAG>
        """
        snippet_blocks = {}

        # Sort snippets by 'order'
        snippets = sorted(job.get("CODE_SNIPPETS", []), key=lambda x: x["order"])

        for snippet_info in snippets:
            path = snippet_info["path"]
            try:
                sql_text = self.get_file_text(path, is_local=True).strip()
                blocks = self.extract_snippet_blocks(sql_text)
                snippet_blocks.update(blocks)
            except FileNotFoundError as e:
                self.logger.debug(f"Snippet file not found: {path} -- Skipping.")

        # Replace placeholders in template_sql
        for tag, block_info in snippet_blocks.items():
            code = block_info["code"] 

            # Replace full block if exists
            block_pattern = rf"#START <{tag}>.*?#END <{tag}>"
            if re.search(block_pattern, template_sql, re.DOTALL):
                template_sql = re.sub(block_pattern, code, template_sql, flags=re.DOTALL)
            else:
                # Replace tag placeholder like <TAG>
                template_sql = template_sql.replace(f"<{tag}>", code)

        return template_sql
    
    
    def inject_sql_folder(self, job: Dict[str, Any], template_sql: str, folder_name: str) -> str:

        allowed = {
            "tests": "TEST",
            "validations": "VALIDATION"
        }

        try:
            if folder_name not in allowed:
                raise ValueError(f"Unsupported folder: {folder_name}")

            prefix = allowed[folder_name]
            try:
                base_path = self.resolve_relative_path(folder_name)
            except FileNotFoundError:
                base_path = None

            injected_scripts = {}
            template_sql = "" if template_sql is None else str(template_sql)

            # ✅ Folder not found
            if not base_path or not os.path.exists(base_path):
                print(f"⚠️ Folder not found: {folder_name}")
                job[f"{prefix}_INJECTED"] = {}
                return template_sql

            for file in os.listdir(base_path):
                if file.endswith(".sql"):
                    file_path = os.path.join(base_path, file)

                    with open(file_path, "r") as f:
                        sql_text = f.read().strip()

                    file_name = os.path.splitext(file)[0].upper()
                    key_name = f"{prefix}_SCRIPT_{file_name}"

                    patterns = [
                        rf"<{key_name}>",
                        rf"<{file_name}>",
                        rf"<DEFAULT_{file_name}>"
                    ]

                    for pattern in patterns:
                        template_sql = re.sub(
                            pattern,
                            lambda _: sql_text,
                            template_sql
                        )

                    injected_scripts[key_name] = sql_text

            job.update(injected_scripts)
            return template_sql

        except Exception as e:
            print(f" Error in inject_sql_folder ({folder_name}): {str(e)}")
            return template_sql
    
    def set_custom_template_queries(self, job: dict) -> dict:
        sql = job.get('JOB_SCRIPTS_SQL', '')

        prev_sql = None

        # Keep replacing until all nested placeholders are resolved
        while prev_sql != sql:
            prev_sql = sql
            sql = self.replace_common_variables(sql, job)

        job['JOB_SCRIPTS_SQL'] = sql

        return job

    
    def exec_custom_template_check_final_queries(self, job):
        engine_type = job.get("ENGINE_TYPE", "").lower()
        if engine_type == 'databricks':
            self.logger.debug("Running Databricks...")
            with open(f"generated_{job['JOB_NAME']}.sql", "w") as f:
                f.write(job["JOB_SCRIPTS_SQL"])
            try:
                execute_run_databricks(job["JOB_SCRIPTS_SQL"], False)
            except Exception as e:
                self.logger.debug(f"Error executing JOB_SCRIPTS_SQL on Databricks: {str(e)}")
                raise

        else:  # Assume Postgres
            self.logger.debug("Running Postgres...")
            with open(f"generated_{job['JOB_NAME']}.sql", "w") as f:
                f.write(job["JOB_SCRIPTS_SQL"])
            db_connection = DbConnections()
            engine = db_connection.postgres_engine()
            try:
                execute_run_postgres(job["JOB_SCRIPTS_SQL"], engine, False,load_script=True)
            except Exception as e:
                self.logger.debug(f"Error executing JOB_SCRIPTS_SQL on Postgres: {str(e)}")
                raise

        return job
    
    def prepare_sql_blocks(self):
        self.update_sql_blocks_file("tests")
        self.update_sql_blocks_file("validations")


    def assign_session_tags(self, job: Dict[str, Any]) -> Dict[str, Any]:
        """
        Assign session tags based on compute mode.
        """

        compute_mode = os.getenv("DATAJOBS_COMPUTE_MODE", "").lower()

        if compute_mode == "spark":
            job["SESSION_TAGS"] = "--"

        elif compute_mode == "warehouse":
            job["SESSION_TAGS"] = f"""
SET QUERY_TAGS['JOB_ID'] = '{job.get("JOB_ID", "")}',
    QUERY_TAGS['JOB_NAME'] = '{job.get("JOB_NAME", "")}',
    QUERY_TAGS['DOMAIN'] = '{job.get("DOMAIN_NAME", "")}',
    QUERY_TAGS['RUN_ID'] = '{job.get("RUN_ID", "")}',
    QUERY_TAGS['TEAM_NAME'] = '{job.get("TEAM_NAME", "")}';
    """.strip()

        else:
            # Optional: default fallback
            job["SESSION_TAGS"] = "--"

        return job
    
    def process_job(self) -> Dict[str, List[Dict[str, Any]]]:

        if self.template.get("CATEGORY_NAME") == 'JOB_SCRIPTS':
            self.prepare_sql_blocks()

            for idx, job in enumerate(self.jobs.get("JOBS", [])):

                start_time = time.time()
                run_id = datetime.now().strftime("%d%m%Y%H%M%S%f") 
                self.logger = setup_logger(run_id)   
                self.logger.info(f"Starting job | RUN_ID: {run_id}")

                try:
                    job = {**self.template, **job}
                    job["RUN_ID"] = run_id  
                    job = self.set_system_variables(job)
                    job = self.assign_session_tags(job)
                    job = self.assign_snippet_blocks_to_job(job)
                    job = self.set_custom_template(job)
                    job = self.set_custom_template_queries(job)
                    job = self.exec_custom_template_check_final_queries(job)

                    status = "SUCCESS"

                except Exception as e:
                    status = "FAILED"
                    self.logger.error(f"Job {job.get('JOB_ID')} failed: {str(e)}")

                end_time = time.time()
                execution_time = round(end_time - start_time, 2)

                job["STATUS"] = status
                job["EXECUTION_TIME"] = execution_time

                self.jobs["JOBS"][idx] = job

                print(
                    f"RUN_ID: {run_id} | "
                    f"JOB_ID: {job.get('JOB_ID')} | "
                    f"JOB_NAME: {job.get('JOB_NAME')} | "
                    f"STATUS: {status} | "
                    f"TIME: {execution_time} sec"
                )

        print("\nJOB EXECUTION COMPLETED")

        return self.jobs