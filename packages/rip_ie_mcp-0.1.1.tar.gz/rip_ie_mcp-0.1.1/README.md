# RIP.ie MCP Server

An MCP (Model Context Protocol) server for searching and browsing Irish death notices from [RIP.ie](https://rip.ie).

## Install from PyPI

```bash
pip install rip-ie-mcp
```

Or with uv:

```bash
uvx rip-ie-mcp
```

## Tools

### `search_death_notices`

Search for death notices with optional filters:

| Parameter | Type | Description |
|---|---|---|
| `firstname` | string | First name to search for |
| `surname` | string | Surname to search for |
| `county` | string | County name (e.g. Dublin, Cork, Galway) |
| `date_from` | string | Start date (`YYYY-MM-DD HH:MM:SS`) |
| `date_to` | string | End date (`YYYY-MM-DD HH:MM:SS`) |
| `funeral_arrangements_later` | boolean | Filter for notices where funeral arrangements are TBD |
| `page` | integer | Page number (default: 1) |
| `per_page` | integer | Results per page (default: 40, max: 100) |

All filters are optional and can be combined. Results are sorted by date (newest first), then surname alphabetically. Notices with multiple associated locations (e.g. birthplace and residence) are deduplicated and locations are combined.

### `get_death_notice`

Get full details of a specific death notice by ID, including:

- Full obituary text
- Photo URL
- Date of death and burial/funeral date
- Address and locations
- Webstream links
- Charity/donation info

### `list_counties`

Lists all 32 Irish counties (including Northern Ireland) with their IDs.

## Configuration

### Claude Code

Add to `~/.claude.json`:

```json
{
  "mcpServers": {
    "rip-ie": {
      "command": "uvx",
      "args": ["rip-ie-mcp"]
    }
  }
}
```

### Claude Desktop

Add to your Claude Desktop config (`~/Library/Application Support/Claude/claude_desktop_config.json` on macOS):

```json
{
  "mcpServers": {
    "rip-ie": {
      "command": "uvx",
      "args": ["rip-ie-mcp"]
    }
  }
}
```

### Development

```bash
git clone https://github.com/dmarkey/rip-ie-mcp.git
cd rip-ie-mcp
uv sync
uv run python -m rip_ie_mcp
```

## How it works

- **Search** uses the RIP.ie public GraphQL API (`https://rip.ie/api/graphql`) — no authentication required.
- **Detail** fetches the death notice page and extracts data from the embedded Next.js `__NEXT_DATA__` payload, which includes the full obituary, photo attachment, and funeral details.
- Photo images are served from `https://img-dedicated.rip.ie/`.
