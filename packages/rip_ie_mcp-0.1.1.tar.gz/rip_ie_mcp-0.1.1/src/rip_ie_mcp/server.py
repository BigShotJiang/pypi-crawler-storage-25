"""RIP.ie MCP Server - Search Irish death notices via the RIP.ie GraphQL API."""

import re
import httpx
from fastmcp import FastMCP
from pydantic import Field
from typing import Optional

mcp = FastMCP("rip-ie", instructions="Search and browse Irish death notices from RIP.ie")

API_URL = "https://rip.ie/api/graphql"
IMAGE_BASE_URL = "https://img-dedicated.rip.ie"
DETAIL_URL = "https://rip.ie/death-notice"

COUNTIES = {
    1: "Antrim", 2: "Armagh", 3: "Carlow", 4: "Cavan", 5: "Clare",
    6: "Cork", 7: "Derry", 8: "Donegal", 9: "Down", 10: "Dublin",
    11: "Fermanagh", 12: "Galway", 13: "Kerry", 14: "Kildare", 15: "Kilkenny",
    16: "Laois", 17: "Leitrim", 18: "Limerick", 19: "Longford", 20: "Louth",
    21: "Mayo", 22: "Meath", 23: "Monaghan", 24: "Offaly", 25: "Roscommon",
    26: "Sligo", 27: "Tipperary", 28: "Tyrone", 29: "Waterford", 30: "Westmeath",
    31: "Wexford", 32: "Wicklow",
}

COUNTY_NAME_TO_ID = {v.lower(): k for k, v in COUNTIES.items()}

SEARCH_QUERY = """
query searchDeathNoticesForListTableWithoutPhoto($list: ListInput!, $isTiledView: Boolean!) {
  searchDeathNoticesForList(query: $list, isTiledView: $isTiledView) {
    count
    perPage
    page
    nextPage
    records {
      id
      firstname
      surname
      nee
      createdAt
      dateOfDeath
      funeralArrangementsLater
      arrangementsChange
      county { id name }
      town { id name }
    }
  }
}
"""


def _photo_url(photo_attachment: dict | None) -> str | None:
    if photo_attachment and photo_attachment.get("file"):
        return f"{IMAGE_BASE_URL}/{photo_attachment['file']}"
    return None


async def _search_ripie(
    firstname: Optional[str] = None,
    surname: Optional[str] = None,
    county: Optional[str] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    funeral_arrangements_later: Optional[bool] = None,
    page: int = 1,
    per_page: int = 40,
) -> dict:
    search_fields = []
    if firstname:
        search_fields.append({"field": "a.escapedFirstname", "search": firstname})
    if surname:
        search_fields.append({"field": "a.escapedSurname", "search": surname})

    filters = []
    if date_from:
        filters.append({"field": "a.createdAt", "operator": "gte", "value": date_from})
    if date_to:
        filters.append({"field": "a.createdAt", "operator": "lte", "value": date_to})
    if county:
        county_id = COUNTY_NAME_TO_ID.get(county.lower())
        if county_id:
            filters.append({"field": "county.id", "operator": "eq", "value": str(county_id)})
        else:
            return {"error": f"Unknown county: {county}. Valid counties: {', '.join(sorted(COUNTIES.values()))}"}
    if funeral_arrangements_later is not None:
        filters.append({
            "field": "a.funeralArrangementsLater",
            "operator": "eq",
            "value": str(funeral_arrangements_later).lower(),
        })

    variables = {
        "list": {
            "page": page,
            "records": per_page,
            "searchFields": search_fields,
            "filters": filters,
            "orders": [
                {"field": "a.createdAtCastToDate", "type": "DESC"},
                {"field": "a.escapedSurname", "type": "ASC"},
            ],
        },
        "isTiledView": False,
    }

    async with httpx.AsyncClient() as client:
        resp = await client.post(
            API_URL,
            json={
                "operationName": "searchDeathNoticesForListTableWithoutPhoto",
                "variables": variables,
                "query": SEARCH_QUERY,
            },
            headers={"Content-Type": "application/json"},
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json()


async def _fetch_detail(notice_id: int) -> dict:
    """Fetch full death notice detail from the Next.js page props."""
    async with httpx.AsyncClient() as client:
        resp = await client.get(
            f"{DETAIL_URL}/{notice_id}",
            headers={"User-Agent": "Mozilla/5.0"},
            timeout=30,
        )
        resp.raise_for_status()
        html = resp.text

    match = re.search(r'"__NEXT_DATA__"[^>]*>({.*?})</script>', html)
    if not match:
        return {"error": "Could not parse death notice detail page."}

    import json
    data = json.loads(match.group(1))
    return data.get("props", {}).get("pageProps", {}).get("previewDeathNotice") or {}


def _format_search_results(data: dict) -> str:
    if "error" in data:
        return data["error"]

    if "errors" in data:
        return f"API error: {data['errors'][0]['message']}"

    result = data["data"]["searchDeathNoticesForList"]
    records = result["records"]

    if not records:
        return "No death notices found matching your search criteria."

    # Deduplicate by id, collecting all locations per person
    people = {}
    for r in records:
        pid = r["id"]
        if pid not in people:
            people[pid] = {
                "id": pid,
                "firstname": r["firstname"],
                "surname": r["surname"],
                "nee": r.get("nee", ""),
                "createdAt": r["createdAt"],
                "dateOfDeath": r.get("dateOfDeath"),
                "funeralArrangementsLater": r.get("funeralArrangementsLater", False),
                "arrangementsChange": r.get("arrangementsChange", "NONE"),
                "locations": [],
            }
        town = r.get("town") or {}
        county = r.get("county") or {}
        loc = f"{town.get('name', '')}, {county.get('name', '')}".strip(", ")
        if loc and loc not in people[pid]["locations"]:
            people[pid]["locations"].append(loc)

    lines = []
    lines.append(f"Found {len(people)} death notice(s) (page {result['page']}, next page: {result['nextPage']}):\n")

    for p in people.values():
        nee = f" (née {p['nee']})" if p["nee"] else ""
        name = f"{p['firstname']} {p['surname']}{nee}"
        locations = " / ".join(p["locations"])
        date = p["createdAt"][:10]
        death_date = f", Died: {p['dateOfDeath'][:10]}" if p.get("dateOfDeath") else ""
        arrangements = ""
        if p["funeralArrangementsLater"]:
            arrangements = " [Funeral arrangements later]"
        if p["arrangementsChange"] != "NONE":
            arrangements += f" [Arrangements: {p['arrangementsChange']}]"
        lines.append(f"- {name} — {locations} — Published: {date}{death_date}{arrangements}")
        lines.append(f"  {DETAIL_URL}/{p['id']}")

    return "\n".join(lines)


def _strip_html(html: str) -> str:
    text = re.sub(r"<br\s*/?>", "\n", html)
    text = re.sub(r"<p[^>]*>", "\n", text)
    text = re.sub(r"</p>", "", text)
    text = re.sub(r"<[^>]+>", "", text)
    text = re.sub(r"&amp;", "&", text)
    text = re.sub(r"&nbsp;", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _format_detail(data: dict) -> str:
    if "error" in data:
        return data["error"]
    if not data:
        return "Death notice not found."

    name = f"{data.get('firstname', '')} {data.get('surname', '')}"
    nee = f" (née {data['nee']})" if data.get("nee") else ""
    name += nee

    lines = [f"# {name}", ""]

    photo = _photo_url(data.get("photoAttachment"))
    if photo:
        lines.append(f"Photo: {photo}")
        lines.append("")

    if data.get("address"):
        lines.append(f"Address: {data['address']}")
    if data.get("dateOfDeath"):
        lines.append(f"Date of death: {data['dateOfDeath'][:10]}")
    if data.get("dateOfBirth"):
        lines.append(f"Date of birth: {data['dateOfBirth'][:10]}")
    lines.append(f"Published: {data.get('createdAt', '')[:10]}")

    # Locations
    counties = data.get("deathNoticeCounty", [])
    if counties:
        locs = []
        for c in counties:
            town = (c.get("town") or {}).get("name", "")
            county = (c.get("county") or {}).get("name", "")
            locs.append(f"{town}, {county}".strip(", "))
        lines.append(f"Location(s): {' / '.join(locs)}")

    lines.append("")

    # Description (the main notice text)
    if data.get("description"):
        lines.append(_strip_html(data["description"]))
        lines.append("")

    # Funeral details
    if data.get("funeralArrangementsLater"):
        lines.append("Funeral arrangements later.")
    if data.get("burialDate"):
        lines.append(f"Burial/funeral date: {data['burialDate'][:10]}")
    if data.get("funeralServiceWebstream"):
        lines.append(f"Webstream: {data['funeralServiceWebstream']}")
    if data.get("burialWebstream"):
        lines.append(f"Burial webstream: {data['burialWebstream']}")

    # Charities
    charities = data.get("eventMasterCharities", [])
    if charities:
        lines.append(f"Donations: {', '.join(str(c) for c in charities)}")
    if data.get("eventMasterCharityOther"):
        lines.append(f"Charity: {data['eventMasterCharityOther']}")

    lines.append("")
    lines.append(f"{DETAIL_URL}/{data['id']}")

    return "\n".join(lines)


@mcp.tool()
async def search_death_notices(
    firstname: Optional[str] = Field(default=None, description="First name to search for"),
    surname: Optional[str] = Field(default=None, description="Surname to search for"),
    county: Optional[str] = Field(default=None, description="County name (e.g. Dublin, Cork, Galway)"),
    date_from: Optional[str] = Field(default=None, description="Start date in format YYYY-MM-DD HH:MM:SS (e.g. 2026-03-27 00:00:00)"),
    date_to: Optional[str] = Field(default=None, description="End date in format YYYY-MM-DD HH:MM:SS (e.g. 2026-04-02 23:59:59)"),
    funeral_arrangements_later: Optional[bool] = Field(default=None, description="Filter for notices where funeral arrangements are TBD"),
    page: int = Field(default=1, description="Page number for pagination"),
    per_page: int = Field(default=40, description="Number of results per page (max 100)"),
) -> str:
    """Search for death notices on RIP.ie. All filters are optional and can be combined.

    At least one filter should be provided (name, county, or date range).
    Results are sorted by date (newest first), then surname alphabetically.
    Use get_death_notice for full details including photos.
    """
    per_page = min(per_page, 100)
    data = await _search_ripie(
        firstname=firstname,
        surname=surname,
        county=county,
        date_from=date_from,
        date_to=date_to,
        funeral_arrangements_later=funeral_arrangements_later,
        page=page,
        per_page=per_page,
    )
    return _format_search_results(data)


@mcp.tool()
async def get_death_notice(
    notice_id: int = Field(description="The death notice ID (from search results or RIP.ie URL)"),
) -> str:
    """Get full details of a specific death notice including description, funeral arrangements, photo, and family information."""
    data = await _fetch_detail(notice_id)
    return _format_detail(data)


@mcp.tool()
async def list_counties() -> str:
    """List all available Irish counties and their IDs for filtering death notices."""
    lines = ["Available counties:"]
    for cid, name in sorted(COUNTIES.items(), key=lambda x: x[1]):
        lines.append(f"  {name} (id: {cid})")
    return "\n".join(lines)


if __name__ == "__main__":
    mcp.run()
