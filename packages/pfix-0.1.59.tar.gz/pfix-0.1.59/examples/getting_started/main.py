#!/usr/bin/env python3
"""pfix demo — ZERO configuration, just `import pfix`

Set PFIX_AUTO_APPLY=true in .env and run:
    python examples/demo_auto.py

That's it. No decorators, no configure(), just import pfix.
"""

import pfix  # Auto-activates if PFIX_AUTO_APPLY=true in .env

from shared import fetch_json, average, greet


def main():
    print("=== pfix Demo (zero config) ===\n")

    print("1. fetch_json:")
    result = fetch_json('https://httpbin.org/json')
    print(f"   ✓ {type(result).__name__}")

    print("\n2. average([]):")
    result = average([])
    print(f"   ✓ {result}")

    print("\n3. greet('Alice', 30):")
    result = greet('Alice', 30)
    print(f"   ✓ {result}")


if __name__ == "__main__":
    main()  # No with block, no decorators, just import pfix
