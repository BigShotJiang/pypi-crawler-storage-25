"""
pfix.decorator — The @pfix decorator.

Usage:
    from pfix import pfix

    @pfix
    def my_function():
        ...

    @pfix(retries=3, auto_apply=True, hint="Processes CSV files")
    def process(path):
        ...

    @pfix(deps=["pandas", "numpy"], restart=True)
    def analyze():
        import pandas as pd
        ...
"""

from __future__ import annotations

import functools
import importlib
import os
import sys
from typing import Any, Callable, Optional, TypeVar, overload

from rich.console import Console

from .analyzer import analyze_exception, classify_error
from .config import get_config
from .dependency import detect_missing_from_error, install_packages, resolve_package_name
from .fixer import apply_fix
from .llm import request_fix

console = Console(stderr=True)
F = TypeVar("F", bound=Callable)


def _capture_runtime_error(exc: BaseException, func: Any = None, hints: Optional[dict] = None):
    """Capture exception to runtime TODO.md if enabled."""
    try:
        from .runtime_todo import get_collector
        collector = get_collector()
        if collector:
            context = {"function": getattr(func, '__name__', None)}
            if hints:
                context.update(hints)
            collector.capture(exc, context)
            collector.shutdown()
    except Exception:
        pass  # Never break user code for logging


@overload
def pfix(func: F) -> F: ...

@overload
def pfix(
    *,
    retries: Optional[int] = None,
    auto_apply: Optional[bool] = None,
    hint: str = "",
    deps: Optional[list[str]] = None,
    restart: Optional[bool] = None,
    on_error: Optional[Callable] = None,
    enabled: Optional[bool] = None,
) -> Callable[[F], F]: ...


def pfix(
    func: Optional[F] = None,
    *,
    retries: Optional[int] = None,
    auto_apply: Optional[bool] = None,
    hint: str = "",
    deps: Optional[list[str]] = None,
    restart: Optional[bool] = None,
    on_error: Optional[Callable] = None,
    enabled: Optional[bool] = None,
) -> Any:
    """Self-healing decorator. Catches errors, fixes code via LLM.

    Args:
        retries: Max fix attempts (default: config.max_retries).
        auto_apply: Apply fixes without asking (default: config.auto_apply).
        hint: Developer hint for LLM context.
        deps: Pre-install these packages before first run.
        restart: Restart the process after applying fix (default: config.auto_restart).
        on_error: Custom error handler, called before LLM analysis.
        enabled: Override global enabled flag.
    """
    def decorator(fn: F) -> F:
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            config = get_config()
            is_enabled = enabled if enabled is not None else config.enabled

            if not is_enabled:
                return fn(*args, **kwargs)

            # Pre-install declared deps
            if deps:
                _ensure_deps(deps)

            max_retries = retries if retries is not None else config.max_retries
            should_auto = auto_apply if auto_apply is not None else config.auto_apply
            should_restart = restart if restart is not None else config.auto_restart

            last_exc: Optional[BaseException] = None

            for attempt in range(max_retries + 1):
                try:
                    return fn(*args, **kwargs)
                except (KeyboardInterrupt, SystemExit):
                    raise
                except BaseException as exc:
                    last_exc = exc
                    if _handle_decorator_exception(
                        fn, exc, attempt, max_retries, hint, args, kwargs,
                        config, should_auto, should_restart, on_error
                    ):
                        continue
                    break

            if last_exc is not None:
                raise last_exc

        wrapper._pfix_decorated = True  # type: ignore
        wrapper._pfix_hint = hint  # type: ignore
        wrapper._pfix_deps = deps  # type: ignore
        return wrapper  # type: ignore

    if func is not None:
        return decorator(func)
    return decorator


# ── Async variant ───────────────────────────────────────────────────

def apfix(func: Optional[F] = None, **kwargs: Any) -> Any:
    """Async version of @pfix. CC≤5."""
    def decorator(fn: F) -> F:
        @functools.wraps(fn)
        async def wrapper(*args: Any, **kw: Any) -> Any:
            config = get_config()
            max_retries = kwargs.get("retries", config.max_retries)
            last_exc = None

            for attempt in range(max_retries + 1):
                try:
                    return await fn(*args, **kw)
                except (KeyboardInterrupt, SystemExit):
                    raise
                except BaseException as exc:
                    last_exc = exc
                    if _handle_decorator_exception(
                        fn, exc, attempt, max_retries, kwargs.get("hint", ""),
                        args, kw, config, kwargs.get("auto_apply"), 
                        kwargs.get("restart"), kwargs.get("on_error")
                    ):
                        continue
                    break

            if last_exc is not None:
                raise last_exc

        wrapper._pfix_decorated = True  # type: ignore
        return wrapper  # type: ignore

    if func is not None:
        return decorator(func)
    return decorator


def _handle_decorator_exception(
    fn, exc, attempt, max_retries, hint, args, kwargs, config, should_auto, should_restart, on_error
) -> bool:
    """Handle a single exception in the decorator loop. Returns True to retry. CC≤7."""
    if attempt >= max_retries:
        _capture_runtime_error(exc, fn, {"hint": hint} if hint else {})
        return False

    console.print(
        f"\n[red]💥 pfix caught: {type(exc).__name__}: {exc}[/]"
        f"  [dim](attempt {attempt + 1}/{max_retries})[/]"
    )

    if on_error:
        try: on_error(exc)
        except Exception: pass

    if _try_quick_dep_fix(exc):
        console.print("[green]  ↻ Dependency installed, retrying...[/]")
        return True

    # Full LLM path
    hints = {"hint": hint} if hint else {}
    hints["args_types"] = str({f"arg{i}": type(a).__name__ for i, a in enumerate(args)})

    ctx = analyze_exception(exc, func=fn, hints=hints)
    console.print(f"[blue]🔍 Analyzing ({classify_error(ctx)})...[/]")

    proposal = request_fix(ctx)
    if proposal.confidence < 0.1:
        console.print("[yellow]⚠ LLM confidence too low — skipping[/]")
        return False

    fixed = _apply_decorator_fix(ctx, proposal, config, should_auto)
    if fixed:
        return _after_fix_action(fn, should_restart)
    
    console.print("[yellow]  Fix not applied[/]")
    return False


def _apply_decorator_fix(ctx, proposal, config, should_auto) -> bool:
    """Apply fix with temporary config override. CC≤3."""
    old_auto = config.auto_apply
    if should_auto:
        config.auto_apply = True
    try:
        return apply_fix(ctx, proposal, confirm=not should_auto)
    finally:
        config.auto_apply = old_auto


def _after_fix_action(fn, should_restart) -> bool:
    """Perform post-fix action (restart or reload). CC≤3."""
    if should_restart:
        console.print("[green]  🔄 Restarting process...[/]")
        os.execv(sys.executable, [sys.executable] + sys.argv)
    
    if _try_reload_module(fn):
        console.print("[green]  ↻ Module reloaded, retrying...[/]")
        return True
    
    console.print("[yellow]  ⚠ Reload failed — restart needed[/]")
    return False


# ── Helpers ─────────────────────────────────────────────────────────


def _ensure_deps(deps: list[str]):
    missing = []
    for dep in deps:
        pkg = dep.split("==")[0].split(">=")[0].split("[")[0]
        try:
            __import__(pkg)
        except ImportError:
            missing.append(dep)
    if missing:
        console.print(f"[cyan]📦 Pre-installing: {', '.join(missing)}[/]")
        install_packages(missing)


def _try_quick_dep_fix(exc: BaseException) -> bool:
    if not isinstance(exc, (ModuleNotFoundError, ImportError)):
        return False
    module = detect_missing_from_error(str(exc))
    if not module:
        return False
    pkg = resolve_package_name(module)
    results = install_packages([pkg])
    return results.get(pkg, False)


def _try_reload_module(func: Any) -> bool:
    try:
        module = sys.modules.get(func.__module__)
        if module is not None:
            importlib.reload(module)
            return True
    except Exception:
        pass
    return False
