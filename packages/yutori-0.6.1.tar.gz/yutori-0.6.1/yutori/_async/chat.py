"""Chat namespace for the Yutori SDK (async)."""

from __future__ import annotations

from typing import Any, Iterable

from openai import AsyncOpenAI
from openai.types.chat import ChatCompletion, ChatCompletionMessageParam


class AsyncChatCompletions:
    """OpenAI-compatible chat completions for n1 API (async)."""

    def __init__(self, openai_client: AsyncOpenAI) -> None:
        self._client = openai_client

    async def create(
        self,
        messages: Iterable[ChatCompletionMessageParam],
        *,
        model: str = "n1.5-latest",
        tool_set: str | None = None,
        disable_tools: list[str] | None = None,
        json_schema: dict | None = None,
        **kwargs: Any,
    ) -> ChatCompletion:
        """Create a chat completion using the n1 API.

        Args:
            messages: List of messages following OpenAI Chat format.
            model: Model to use (default: "n1.5-latest").
            tool_set: (n1.5 only) Built-in tool set to use, e.g.
                ``"browser_tools_core-20260403"`` or
                ``"browser_tools_expanded-20260403"``.
            disable_tools: (n1.5 only) List of tool names to remove from the
                selected tool set.
            json_schema: (n1.5 only) JSON Schema for structured output.
                When provided, the model returns a ``parsed_json`` field
                on the response.
            **kwargs: Additional parameters (e.g., temperature).

        Returns:
            ChatCompletion object.
        """
        extra_body = kwargs.pop("extra_body", None) or {}
        if tool_set is not None:
            extra_body["tool_set"] = tool_set
        if disable_tools is not None:
            extra_body["disable_tools"] = disable_tools
        if json_schema is not None:
            extra_body["json_schema"] = json_schema

        if extra_body:
            kwargs["extra_body"] = extra_body

        return await self._client.chat.completions.create(model=model, messages=messages, **kwargs)


class AsyncChatNamespace:
    """Async namespace for n1 API operations (pixels-to-actions LLM)."""

    def __init__(self, base_url: str, api_key: str, timeout: float) -> None:
        self._openai_client = AsyncOpenAI(base_url=base_url, api_key=api_key, timeout=timeout)
        self.completions = AsyncChatCompletions(self._openai_client)

    async def close(self) -> None:
        await self._openai_client.close()
