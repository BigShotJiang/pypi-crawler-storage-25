#!/usr/bin/env python3
#
# Patchwork command line client
# Copyright (C) 2008 Nate Case <ncase@xes-inc.com>
#
# SPDX-License-Identifier: GPL-2.0-or-later

import configparser
import os
import sys

from . import api as pw_api
from . import checks
from . import events
from . import exceptions
from . import parser
from . import patches
from . import projects
from . import states
from . import utils

CONFIG_FILE = os.environ.get('PWCLIENTRC', os.path.expanduser('~/.pwclientrc'))

BACKEND_XMLRPC = 'xmlrpc'
BACKEND_REST = 'rest'
BACKENDS = (BACKEND_XMLRPC, BACKEND_REST)

auth_actions = ['check_create', 'update']


def main(argv=sys.argv[1:]):
    action_parser = parser.get_parser()

    if not argv:
        action_parser.print_help()
        sys.exit(0)

    args = action_parser.parse_args(argv)

    action = args.subcmd

    if not os.path.exists(CONFIG_FILE):
        sys.stderr.write(f'Config file not found at {CONFIG_FILE}.\n')
        sys.exit(1)

    # grab settings from config files
    config = configparser.ConfigParser()
    config.read([CONFIG_FILE])

    if config.has_section('base'):
        utils.migrate_old_config_file(CONFIG_FILE, config)
        sys.exit(1)

    if not config.has_section('options'):
        sys.stderr.write(
            f'No options section in {CONFIG_FILE}. Did you forget to uncomment it?\n'
        )
        sys.exit(1)

    if 'project' in args and args.project:
        project_str = args.project
    else:
        try:
            project_str = config.get('options', 'default')
        except (
            configparser.NoSectionError,
            configparser.NoOptionError,
        ):
            sys.stderr.write(
                f'No default project configured in {CONFIG_FILE}\n'
            )
            sys.exit(1)

    if not config.has_section(project_str):
        sys.stderr.write(
            f'No section for project {project_str} in {CONFIG_FILE}\n'
        )
        sys.exit(1)

    if not config.has_option(project_str, 'url'):
        sys.stderr.write(
            f'No URL for project {project_str} in {CONFIG_FILE}\n'
        )
        sys.exit(1)

    backend = config.get(project_str, 'backend', fallback=None)
    if backend is not None and backend not in BACKENDS:
        sys.stderr.write(
            f"The 'backend' option is invalid. Expected one of: rest, xmlrpc; "
            f"got: {backend}\n"
        )
        sys.exit(1)

    if backend is None:
        sys.stderr.write(
            f"The default backend will change from 'xmlrpc' to 'rest' in a "
            f"future version. You should explicitly set "
            f"'[{project_str}] backend' in pwclientrc to explicitly opt-in "
            f"to a specific backend\n"
        )

    backend = backend or BACKEND_XMLRPC

    if action in auth_actions:
        if backend == 'rest':
            if not (
                (
                    config.has_option(project_str, 'username')
                    and config.has_option(project_str, 'password')
                )
                or config.has_option(project_str, 'token')
            ):
                sys.stderr.write(
                    f"The {action} action requires authentication, but no "
                    f"username/password or\n"
                    f"token is configured\n"
                )
                sys.exit(1)
        else:
            if not (
                config.has_option(project_str, 'username')
                and config.has_option(project_str, 'password')
            ):
                sys.stderr.write(
                    f"The {action} action requires authentication, but no "
                    f"username or password\n"
                    f"is configured\n"
                )
                sys.exit(1)

    url = config.get(project_str, 'url')

    kwargs = {'debug': args.debug}
    if action in auth_actions:
        if config.has_option(project_str, 'token'):
            kwargs['token'] = config.get(project_str, 'token')
        else:
            kwargs['username'] = config.get(project_str, 'username')
            kwargs['password'] = config.get(project_str, 'password')

    try:
        if backend == 'rest':
            api = pw_api.REST(url, **kwargs)
        else:
            api = pw_api.XMLRPC(url, **kwargs)
    except exceptions.APIError as exc:
        sys.stderr.write(str(exc))
        sys.exit(1)

    patch_ids = args.id if 'id' in args and args.id else []
    if 'use_hashes' in args and args.use_hashes:
        patch_ids = [
            patches.patch_id_from_hash(api, project_str, x) for x in patch_ids
        ]
    else:
        try:
            patch_ids = [int(x) for x in patch_ids]
        except ValueError:
            sys.stderr.write('Patch IDs must be integers\n')
            sys.exit(1)

    match action:
        case 'list' | 'search':
            patches.action_list(
                api,
                project=project_str,
                submitter=args.submitter,
                delegate=args.delegate,
                state=args.state,
                archived=args.archived,
                msgid=args.msgid,
                series=args.series,
                name=args.patch_name,
                hash=args.hash,
                max_count=args.max_count,
                format_str=args.format,
            )
        case 'event_list':
            events.action_list(
                api,
                project=args.project,
                category=args.category,
                since=args.since,
                format_str=args.format,
            )
        case 'projects':
            projects.action_list(api)
        case 'states':
            states.action_list(api)
        case 'view':
            patches.action_view(api, patch_ids)
        case 'info':
            for patch_id in patch_ids:
                patches.action_info(api, patch_id)
        case 'get':
            for patch_id in patch_ids:
                patches.action_get(api, patch_id)
        case 'apply':
            for patch_id in patch_ids:
                ret = patches.action_apply(api, patch_id)
                if ret:
                    sys.stderr.write(f"Apply failed with exit status {ret}\n")
                    sys.exit(1)
        case 'git_am':
            cmd = ['git', 'am']

            do_signoff = None
            if args.signoff:
                do_signoff = args.signoff
            elif config.has_option('options', 'signoff'):
                do_signoff = config.getboolean('options', 'signoff')
            elif config.has_option(project_str, 'signoff'):
                do_signoff = config.getboolean(project_str, 'signoff')

            if do_signoff:
                cmd.append('-s')

            do_three_way = None
            if args.three_way:
                do_three_way = args.three_way
            elif config.has_option('options', '3way'):
                do_three_way = config.getboolean('options', '3way')
            elif config.has_option(project_str, '3way'):
                do_three_way = config.getboolean(project_str, '3way')

            if do_three_way:
                cmd.append('-3')

            do_msg_id = None
            if args.msg_id:
                do_msg_id = args.msg_id
            elif config.has_option('options', 'msgid'):
                do_msg_id = config.getboolean('options', 'msgid')
            elif config.has_option(project_str, 'msgid'):
                do_msg_id = config.getboolean(project_str, 'msgid')

            if do_msg_id:
                cmd.append('-m')

            for patch_id in patch_ids:
                ret = patches.action_apply(api, patch_id, cmd)
                if ret:
                    sys.stderr.write(
                        f"'git am' failed with exit status {ret}\n"
                    )
                    sys.exit(1)
        case 'update':
            if args.commit_ref and len(patch_ids) > 1:
                # update multiple IDs with a single commit-hash does not make sense
                sys.stderr.write(
                    'Declining update with COMMIT-REF on multiple IDs\n'
                )
                sys.exit(1)

            if not any([args.state, args.archived]):
                sys.stderr.write(
                    'Must specify one or more update options (-a or -s)\n'
                )
                sys.exit(1)

            for patch_id in patch_ids:
                patches.action_update(
                    api,
                    patch_id,
                    state=args.state,
                    archived=args.archived,
                    commit_ref=args.commit_ref,
                )
        case 'check_get':
            format_str = args.format
            for patch_id in patch_ids:
                checks.action_get(api, patch_id, format_str)
        case 'check_list':
            checks.action_list(api, args.patch_id, args.user)
        case 'check_info':
            patch_id = args.patch_id
            check_id = args.check_id
            checks.action_info(api, patch_id, check_id)
        case 'check_create':
            for patch_id in patch_ids:
                checks.action_create(
                    api,
                    patch_id,
                    args.context,
                    args.state,
                    args.target_url,
                    args.description,
                )
        case _:
            # we can't get here under normal circumstances
            sys.stderr.write('Invalid action')
            sys.exit(255)


if __name__ == "__main__":
    try:
        main()
    except (UnicodeEncodeError, UnicodeDecodeError):
        import traceback

        traceback.print_exc()
        sys.stderr.write(
            'Try exporting the LANG or LC_ALL env vars. See '
            'pwclient --help for more details.\n'
        )
        sys.exit(1)
