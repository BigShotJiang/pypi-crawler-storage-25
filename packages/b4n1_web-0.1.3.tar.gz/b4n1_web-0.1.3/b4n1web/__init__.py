"""
B4n1Web Python SDK
Zero-overhead, high-speed web execution for sovereign AI agents.

NOTE: The B4n1Web binary must be installed separately via:
    curl -sL https://web.b4n1.com/install | bash
"""

from .browser import AgentBrowser, BrowserMode, Page
from .errors import BinaryNotFoundError

__version__ = "0.1.1"
__author__ = "Bani Montoya"
__email__ = "banimontoya@gmail.com"

__all__ = ["AgentBrowser", "BrowserMode", "Page", "BinaryNotFoundError"]
