# Engram

AI agent memory that learns across conversations.

## Install

```bash
pip install git+https://github.com/aop60003/default.git
```

## Use

```bash
engram save "Minseong Jeong is the Space King of Galaxy Corp"
engram find "Space King"
engram who "Minseong Jeong"
```

That's it. 3 commands. No config, no API keys, no database setup.

## All Commands

```
engram save "text"                   Save information (auto-extracts entities & facts)
engram find "query"                  Search memory
engram who "name"                    Look up a person/org
engram remember "name" "fact"        Manually remember something
engram all                           List everything
engram status                        Health check
engram forget "name"                 Delete an entity
engram export                        Export to Markdown files
```

## Examples

```bash
# Store meeting notes
engram save "Met Alice Johnson, VP of Engineering at Google. Discussed cloud AI partnership."

# Store Korean
engram remember "정민성" "AI와 우주 탐사에 관심이 많다"

# Search later
engram find "Google partnership"
engram who "Alice Johnson"

# Check status
engram status
```

## What It Does Automatically

- **Extracts** people & organizations from text (English, Korean, Chinese, Japanese)
- **Masks PII** — phone numbers, credit cards, emails become `[REDACTED]`
- **Deduplicates** — same fact won't be stored twice
- **Detects conflicts** — "CEO" then "CTO" for same person gets flagged
- **Generates summaries** — auto-summary when you don't provide one
- **Learns across sessions** — every conversation builds on previous ones

## For Claude Code Users

Add slash commands to use memory inside Claude Code:

```bash
# Copy command files
mkdir -p ~/.claude/commands
# See docs/04-usage-guide/02-claude-code-setup.md for details
```

Then use: `/memory-save`, `/memory-find`, `/memory-who`, `/memory-remember`, `/memory-status`

## For Developers (Python SDK)

```python
from engram.integrations.sdk import EngramSDK

with EngramSDK() as sdk:
    sdk.store("Minseong Jeong is the Space King of Galaxy Corp")
    result = sdk.search("Space King")
    print(result.to_agent_context())
```

## How It Works

```
Text → NER Extraction → Quality Gate → SQLite+FTS5 → BM25 Search
                              ↓
                     Confidence Scoring
                     PII Masking
                     Duplicate Check
                     Conflict Detection
```

- **Storage**: SQLite + FTS5 (zero dependencies, genuine BM25)
- **Export**: Markdown files for human reading
- **Session**: Context carries over between conversations

## License

MIT
