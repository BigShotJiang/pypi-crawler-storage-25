"""End-to-end tests — full workflow scenarios."""

import pytest

from engram.config import EngramConfig
from engram.engine import MemoryEngine
from engram.models.entity import Tier
from engram.models.quality import Action
from engram.models.source import Source, SourceType
from engram.integrations.sdk import EngramSDK


@pytest.fixture
def engine(tmp_path):
    """Create and close engine for each test."""
    config = EngramConfig(base_dir=tmp_path / "engram", enable_markdown_export=True)
    eng = MemoryEngine(config)
    yield eng
    eng.close()


class TestE2EStoreSearchRetrieve:
    """Full cycle: store text → search → retrieve entity → get facts."""

    def test_full_cycle(self, engine):
        # Store information
        result = engine.store(
            "Simon Kim is the CEO of Hashed. He launched a $200M crypto fund.",
            source=Source(type=SourceType.DOCUMENT, confidence=0.9, author="press"),
        )
        assert len(result.entities_created) >= 1

        # Search
        search_result = engine.search("CEO")
        assert search_result.total_count >= 1
        assert any("Simon Kim" in h.entity.name for h in search_result.hits)

        # Retrieve entity
        entity = engine.get_entity("Simon Kim")
        assert entity is not None
        assert entity.entity_type == "person"

        # Get facts
        facts = engine.get_facts("Simon Kim")
        assert len(facts) >= 1

        # Verify Markdown export
        md_files = list(engine.config.export_dir.glob("*.md"))
        assert len(md_files) >= 1
        md_content = md_files[0].read_text()
        assert "Simon Kim" in md_content

    def test_multiple_stores_accumulate(self, engine):
        engine.store("Simon Kim is the CEO of Hashed.")
        engine.store("Vitalik Buterin co-founded Ethereum.")
        engine.store("Simon Kim invested in DeFi projects.")

        entities = engine.list_entities()
        assert len(entities) >= 2

        # Simon Kim should have accumulated facts
        facts = engine.get_facts("Simon Kim")
        assert len(facts) >= 1


class TestE2ESessionWorkflow:
    """Full session lifecycle: start → operations → end → carryover."""

    def test_session_lifecycle_with_carryover(self, engine):
        # Session 1
        s1 = engine.start_session("claude-code")
        engine.store("Simon Kim is the CEO of Hashed.", session_id=s1.session_id)
        engine.end_session(s1.session_id, summary="Discussed Simon Kim and Hashed")

        # Session 2 — should have context from session 1
        context = engine.get_session_context("claude-code")
        assert "Simon Kim" in context.get("previous_summary", "") or context["entity_count"] >= 1

        s2 = engine.start_session("claude-code")
        assert s2.parent_session_id == s1.session_id
        engine.end_session(s2.session_id)


class TestE2EQualityGate:
    """Quality gate in action: confidence, PII, conflicts."""

    def test_pii_masking_e2e(self, engine):
        engine.create_entity("Simon Kim")
        result = engine.add_fact(
            "Simon Kim",
            "Email: simon@hashed.com, Card: 4111-1111-1111-1111",
            source=Source(type=SourceType.USER_INPUT, confidence=1.0),
        )
        assert result.action in (Action.ACCEPT, Action.QUARANTINE)
        facts = engine.get_facts("Simon Kim")
        for f in facts:
            assert "4111-1111-1111-1111" not in f.raw_text
            assert "[REDACTED]" in f.raw_text

    def test_conflict_detection_e2e(self, engine):
        engine.create_entity("Simon Kim")
        engine.add_fact("Simon Kim", "CEO", predicate="role",
                       source=Source(type=SourceType.DOCUMENT, confidence=0.8))
        result = engine.add_fact("Simon Kim", "CTO", predicate="role",
                                source=Source(type=SourceType.DOCUMENT, confidence=0.85))
        assert result.has_conflicts or result.is_accepted

    def test_low_confidence_quarantine_e2e(self, tmp_path):
        config = EngramConfig(base_dir=tmp_path / "engram_quar", min_confidence=0.5)
        eng = MemoryEngine(config)
        try:
            eng.create_entity("Simon Kim")
            result = eng.add_fact(
                "Simon Kim", "plays golf",
                predicate="hobby",
                source=Source(type=SourceType.AGENT_INFERENCE, confidence=0.3),
            )
            assert result.is_quarantined
        finally:
            eng.close()


class TestE2ESDK:
    """SDK workflow: context manager, session, store/search."""

    def test_sdk_context_manager(self, tmp_path):
        config = EngramConfig(base_dir=tmp_path / "engram")
        with EngramSDK(config) as sdk:
            sdk.start_session("test-agent")
            sdk.store("Alice Smith is a data scientist at Google.")
            result = sdk.search("data scientist")
            assert result.total_count >= 0  # May or may not find depending on NER
            health = sdk.health()
            assert health["entity_count"] >= 0

    def test_sdk_tool_schemas(self):
        schemas = EngramSDK.get_tool_schemas()
        assert len(schemas) >= 3
        names = [s["function"]["name"] for s in schemas]
        assert "memory_search" in names
        assert "memory_store" in names


class TestE2ECLI:
    """CLI end-to-end via main() calls."""

    def test_full_cli_workflow(self, tmp_path):
        from engram.cli.app import main
        db = str(tmp_path / "cli_test.db")

        # Init
        assert main(["--db", db, "--quiet", "init"]) == 0

        # Create entity
        assert main(["--db", db, "create", "Simon Kim", "--type", "person"]) == 0

        # Add fact
        assert main(["--db", db, "add-fact", "Simon Kim", "CEO of Hashed"]) == 0

        # Store text
        assert main(["--db", db, "store", "Vitalik Buterin created Ethereum."]) == 0

        # Search
        assert main(["--db", db, "search", "CEO"]) == 0

        # Get entity
        assert main(["--db", db, "get", "Simon Kim"]) == 0

        # List entities
        assert main(["--db", db, "list"]) == 0

        # Health check
        assert main(["--db", db, "health"]) == 0

        # Export
        assert main(["--db", db, "export"]) == 0

        # Reindex
        assert main(["--db", db, "reindex"]) == 0


class TestE2EMarkdownExport:
    """Verify Markdown export content quality."""

    def test_exported_markdown_structure(self, engine):
        engine.store(
            "Simon Kim is the CEO of Hashed Inc.",
            source=Source(type=SourceType.DOCUMENT, confidence=0.9),
        )
        engine.export_markdown()

        md_files = list(engine.config.export_dir.glob("*.md"))
        assert len(md_files) >= 1

        content = md_files[0].read_text()
        assert content.startswith("#")
        assert "## Metadata" in content
        assert "Type" in content


class TestE2EMultiLanguage:
    """Multi-language support: English + Korean."""

    def test_korean_store_and_search(self, engine):
        engine.store("김민수는 삼성전자 주식회사의 CTO이다.")
        result = engine.search("김민수")
        assert isinstance(result.total_count, int)

    def test_mixed_language_store(self, engine):
        engine.store("Simon Kim은 Hashed의 CEO입니다.")
        entity = engine.get_entity("Simon Kim")
        # English NER should extract Simon Kim even in mixed text
