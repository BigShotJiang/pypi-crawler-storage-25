"""Tests for the tokenizer module."""

import pytest

from engram.search.tokenizer import tokenize, escape_fts5_query, build_fts5_query


class TestTokenize:
    def test_basic_english(self):
        tokens = tokenize("Simon Kim is the CEO", remove_stopwords=True)
        assert "simon" in tokens
        assert "kim" in tokens
        assert "ceo" in tokens
        # Stopwords removed
        assert "is" not in tokens
        assert "the" not in tokens

    def test_no_stopword_removal(self):
        tokens = tokenize("Simon is the CEO", remove_stopwords=False)
        assert "is" in tokens
        assert "the" in tokens

    def test_korean_text(self):
        tokens = tokenize("김민수는 하셰드의 대표이다", remove_stopwords=True)
        # Korean tokenizer keeps particles attached (space-delimited eojeol)
        assert any("김민수" in t for t in tokens)
        assert any("하셰드" in t for t in tokens)

    def test_mixed_language(self):
        tokens = tokenize("Simon Kim은 Hashed의 CEO입니다", remove_stopwords=False)
        assert "simon" in tokens
        assert "kim" in tokens
        assert "hashed" in tokens
        assert "ceo" in tokens

    def test_empty_string(self):
        assert tokenize("") == []

    def test_only_stopwords(self):
        tokens = tokenize("the is a an", remove_stopwords=True)
        assert tokens == []

    def test_cjk_characters(self):
        tokens = tokenize("马化腾是腾讯创始人", remove_stopwords=False)
        assert len(tokens) >= 1  # CJK should produce at least one token

    def test_special_characters_stripped(self):
        tokens = tokenize("hello! world? test.", remove_stopwords=False)
        assert "hello" in tokens
        assert "world" in tokens
        assert "test" in tokens

    def test_numbers_preserved(self):
        tokens = tokenize("GPT 5 model", remove_stopwords=False)
        assert "gpt" in tokens
        assert "5" in tokens or "gpt" in tokens

    def test_hyphenated_words_split(self):
        tokens = tokenize("state-of-the-art", remove_stopwords=False)
        assert "state" in tokens
        assert "art" in tokens

    def test_single_char_removed_with_stopwords(self):
        tokens = tokenize("I a X", remove_stopwords=True)
        # Single characters removed when stopword removal is on
        assert "i" not in tokens
        assert "a" not in tokens


class TestEscapeFTS5Query:
    def test_basic_query(self):
        result = escape_fts5_query("Simon Kim")
        assert '"simon"' in result
        assert '"kim"' in result

    def test_special_chars_escaped(self):
        result = escape_fts5_query('test* "quoted" (group)')
        # All tokens should be safely quoted
        assert '""' not in result or result == '""'

    def test_empty_query(self):
        result = escape_fts5_query("")
        assert result == '""'


class TestBuildFTS5Query:
    def test_removes_stopwords(self):
        result = build_fts5_query("who is the CEO of Hashed")
        assert '"ceo"' in result
        assert '"hashed"' in result
        assert '"who"' not in result
        assert '"is"' not in result
        assert '"the"' not in result

    def test_all_stopwords_fallback(self):
        result = build_fts5_query("the is a")
        # Should fall back to escaped raw query
        assert result  # Not empty

    def test_korean_query(self):
        result = build_fts5_query("김민수 대표")
        assert len(result) > 0
