"""Tests for PII detection and masking."""

import pytest

from engram.quality.pii import PIIDetector


@pytest.fixture
def detector():
    return PIIDetector()


class TestPIIDetection:
    def test_detect_credit_card(self, detector):
        matches = detector.scan("My card is 4111-1111-1111-1111 thanks")
        assert len(matches) == 1
        assert matches[0].pii_type == "credit_card"
        # Original should NOT contain the actual PII value
        assert "4111" not in matches[0].original
        assert "credit_card" in matches[0].original

    def test_detect_credit_card_no_dash(self, detector):
        matches = detector.scan("Card: 4111111111111111")
        assert len(matches) == 1
        assert matches[0].pii_type == "credit_card"

    def test_detect_ssn(self, detector):
        matches = detector.scan("SSN: 123-45-6789")
        assert len(matches) == 1
        assert matches[0].pii_type == "ssn"

    def test_detect_api_key_sk(self, detector):
        matches = detector.scan("Key: sk-abcdefghijklmnopqrstuvwxyz12")
        assert len(matches) == 1
        assert matches[0].pii_type == "api_key"

    def test_detect_api_key_github(self, detector):
        matches = detector.scan("Token: ghp_abcdefghijklmnopqrstuvwxyz12")
        assert len(matches) == 1
        assert matches[0].pii_type == "api_key"

    def test_detect_email(self, detector):
        matches = detector.scan("Contact: user@example.com for info")
        assert len(matches) == 1
        assert matches[0].pii_type == "email"
        # Original should NOT contain the actual PII value
        assert "user@example.com" not in matches[0].original

    def test_detect_korean_phone(self, detector):
        matches = detector.scan("전화번호: 010-1234-5678")
        assert len(matches) == 1
        assert matches[0].pii_type == "phone_kr"

    def test_detect_intl_phone(self, detector):
        matches = detector.scan("Call +82-10-1234-5678")
        assert len(matches) == 1
        assert matches[0].pii_type == "phone_intl"

    def test_detect_korean_rrn(self, detector):
        matches = detector.scan("주민번호: 900101-1234567")
        assert len(matches) == 1
        assert matches[0].pii_type == "rrn"

    def test_detect_multiple_pii(self, detector):
        text = "Email: test@test.com, Card: 4111-1111-1111-1111, Phone: 010-1234-5678"
        matches = detector.scan(text)
        types = {m.pii_type for m in matches}
        assert "email" in types
        assert "credit_card" in types
        assert "phone_kr" in types

    def test_no_pii(self, detector):
        matches = detector.scan("Simon Kim is the CEO of Hashed")
        assert len(matches) == 0

    def test_empty_string(self, detector):
        assert detector.scan("") == []


class TestPIIMasking:
    def test_mask_email(self, detector):
        result = detector.mask("Contact user@example.com for info")
        assert "[REDACTED]" in result
        assert "user@example.com" not in result

    def test_mask_preserves_other_text(self, detector):
        result = detector.mask("Name: Simon, Email: test@test.com, Role: CEO")
        assert "Simon" in result
        assert "CEO" in result
        assert "[REDACTED]" in result
        assert "test@test.com" not in result

    def test_mask_multiple(self, detector):
        text = "Card 4111-1111-1111-1111 and email user@test.com"
        result = detector.mask(text)
        assert result.count("[REDACTED]") == 2

    def test_mask_no_pii_unchanged(self, detector):
        text = "Just a normal sentence"
        assert detector.mask(text) == text

    def test_mask_with_provided_matches(self, detector):
        text = "Email: user@example.com"
        matches = detector.scan(text)
        result = detector.mask(text, matches)
        assert "user@example.com" not in result


class TestHasPII:
    def test_has_pii_true(self, detector):
        assert detector.has_pii("Card: 4111-1111-1111-1111")

    def test_has_pii_false(self, detector):
        assert not detector.has_pii("No sensitive info here")

    def test_has_pii_empty(self, detector):
        assert not detector.has_pii("")
