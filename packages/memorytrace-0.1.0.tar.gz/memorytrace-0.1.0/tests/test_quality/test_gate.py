"""Tests for the quality gate pipeline."""

import pytest

from engram.config import EngramConfig
from engram.models.entity import Entity, Tier
from engram.models.fact import Fact, FactStatus
from engram.models.quality import Action
from engram.models.source import Source, SourceType
from engram.quality.gate import QualityGate
from engram.storage.sqlite_store import SQLiteStorage


@pytest.fixture
def gate_setup(tmp_path):
    """Set up quality gate with storage."""
    db_path = tmp_path / "gate_test.db"
    config = EngramConfig(
        base_dir=tmp_path,
        min_confidence=0.3,
        auto_resolve_threshold=0.3,
        enable_pii_detection=True,
    )
    storage = SQLiteStorage(db_path)
    storage.initialize()

    entity = Entity(name="Simon Kim", entity_type="person", tier=Tier.CORE)
    storage.create_entity(entity)

    gate = QualityGate(config, storage)
    yield gate, storage, entity
    storage.close()


class TestQualityGateAccept:
    def test_accept_good_fact(self, gate_setup):
        gate, _, entity = gate_setup
        fact = Fact(
            entity_id=entity.id,
            subject="Simon Kim",
            predicate="location",
            object="Seoul",
            raw_text="Simon Kim is based in Seoul",
            source=Source(type=SourceType.USER_INPUT, confidence=0.9),
        )
        result = gate.validate(fact)
        assert result.is_accepted
        assert result.confidence > 0

    def test_accept_updates_confidence(self, gate_setup):
        gate, _, entity = gate_setup
        fact = Fact(
            entity_id=entity.id,
            subject="Simon Kim",
            predicate="role",
            object="CEO",
            raw_text="Simon Kim is CEO",
            source=Source(type=SourceType.DOCUMENT, confidence=0.9),
        )
        result = gate.validate(fact, extraction_method="regex")
        assert result.is_accepted
        # Document(0.85) × 0.9 × regex(0.7) ≈ 0.5355
        assert 0.5 < result.confidence < 0.6


class TestQualityGateQuarantine:
    def test_quarantine_low_confidence(self, gate_setup):
        gate, _, entity = gate_setup
        fact = Fact(
            entity_id=entity.id,
            subject="Simon Kim",
            predicate="hobby",
            object="golf",
            raw_text="Simon Kim plays golf",
            source=Source(type=SourceType.AGENT_INFERENCE, confidence=0.3),
        )
        result = gate.validate(fact, extraction_method="regex")
        assert result.is_quarantined
        assert "below threshold" in result.reason

    def test_quarantine_sets_unverified_status(self, gate_setup):
        gate, _, entity = gate_setup
        fact = Fact(
            entity_id=entity.id,
            subject="Test",
            predicate="test",
            object="test",
            raw_text="test",
            source=Source(type=SourceType.AGENT_INFERENCE, confidence=0.1),
        )
        gate.validate(fact, extraction_method="regex")
        assert fact.status == FactStatus.UNVERIFIED


class TestQualityGateConflict:
    def test_conflict_detection(self, gate_setup):
        gate, storage, entity = gate_setup
        # Add existing fact
        existing = Fact(
            entity_id=entity.id,
            subject="Simon Kim",
            predicate="role",
            object="CEO",
            raw_text="Simon Kim is CEO",
            source=Source(type=SourceType.DOCUMENT, confidence=0.8),
            confidence=0.8,
        )
        storage.add_fact(existing)

        # New conflicting fact with similar trust
        new_fact = Fact(
            entity_id=entity.id,
            subject="Simon Kim",
            predicate="role",
            object="CTO",
            raw_text="Simon Kim is CTO now",
            source=Source(type=SourceType.DOCUMENT, confidence=0.85),
        )
        result = gate.validate(new_fact)
        assert result.has_conflicts
        assert len(result.conflicts) == 1

    def test_auto_resolve_supersede(self, gate_setup):
        gate, storage, entity = gate_setup
        # Low-trust existing fact
        existing = Fact(
            entity_id=entity.id,
            subject="Simon Kim",
            predicate="role",
            object="Intern",
            raw_text="Simon Kim is an intern",
            source=Source(type=SourceType.AGENT_INFERENCE, confidence=0.3),
            confidence=0.3,
        )
        storage.add_fact(existing)

        # High-trust new fact
        new_fact = Fact(
            entity_id=entity.id,
            subject="Simon Kim",
            predicate="role",
            object="CEO",
            raw_text="Simon Kim is CEO",
            source=Source(type=SourceType.DIRECT_SPEECH, confidence=1.0),
        )
        result = gate.validate(new_fact)
        # Should auto-resolve (supersede) and accept
        assert result.is_accepted


class TestQualityGatePII:
    def test_pii_masked_in_accepted_fact(self, gate_setup):
        gate, _, entity = gate_setup
        fact = Fact(
            entity_id=entity.id,
            subject="Simon Kim",
            predicate="email",
            object="simon@hashed.com",
            raw_text="Simon Kim email is simon@hashed.com",
            source=Source(type=SourceType.USER_INPUT, confidence=1.0),
        )
        result = gate.validate(fact)
        assert result.is_accepted
        assert len(result.pii_matches) >= 1
        assert "simon@hashed.com" not in fact.raw_text
        assert "[REDACTED]" in fact.raw_text

    def test_pii_detection_disabled(self, tmp_path):
        config = EngramConfig(
            base_dir=tmp_path,
            enable_pii_detection=False,
        )
        db_path = tmp_path / "nopii.db"
        storage = SQLiteStorage(db_path)
        storage.initialize()
        entity = Entity(name="Test", entity_type="person")
        storage.create_entity(entity)

        gate = QualityGate(config, storage)
        fact = Fact(
            entity_id=entity.id,
            subject="Test",
            predicate="card",
            object="4111-1111-1111-1111",
            raw_text="Card: 4111-1111-1111-1111",
            source=Source(type=SourceType.USER_INPUT, confidence=1.0),
        )
        result = gate.validate(fact)
        assert result.is_accepted
        assert len(result.pii_matches) == 0
        assert "4111-1111-1111-1111" in fact.raw_text  # Not masked
        storage.close()


class TestQualityGateNoEntity:
    def test_fact_without_entity_id_skips_conflict_check(self, gate_setup):
        gate, _, _ = gate_setup
        fact = Fact(
            entity_id="",
            subject="Unknown",
            predicate="note",
            object="Something",
            raw_text="Something happened",
            source=Source(type=SourceType.USER_INPUT, confidence=1.0),
        )
        result = gate.validate(fact)
        assert result.is_accepted
