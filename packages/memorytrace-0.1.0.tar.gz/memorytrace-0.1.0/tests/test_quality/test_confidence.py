"""Tests for confidence scoring."""

import pytest

from engram.quality.confidence import compute_confidence
from engram.models.source import SourceType


class TestComputeConfidence:
    def test_direct_speech_high_confidence(self):
        score = compute_confidence(SourceType.DIRECT_SPEECH, 1.0, "manual")
        assert score == 0.95

    def test_agent_inference_low_confidence(self):
        score = compute_confidence(SourceType.AGENT_INFERENCE, 1.0, "manual")
        assert score == 0.4

    def test_regex_extraction_penalty(self):
        manual = compute_confidence(SourceType.DOCUMENT, 1.0, "manual")
        regex = compute_confidence(SourceType.DOCUMENT, 1.0, "regex")
        assert regex < manual
        assert regex == pytest.approx(0.85 * 0.7, abs=0.01)

    def test_llm_extraction_no_penalty(self):
        manual = compute_confidence(SourceType.DOCUMENT, 1.0, "manual")
        llm = compute_confidence(SourceType.DOCUMENT, 1.0, "llm")
        assert llm == manual

    def test_low_source_confidence(self):
        score = compute_confidence(SourceType.DIRECT_SPEECH, 0.5, "manual")
        assert score == pytest.approx(0.95 * 0.5, abs=0.01)

    def test_combined_factors(self):
        # web source (0.6) × low confidence (0.5) × regex (0.7)
        score = compute_confidence(SourceType.WEB, 0.5, "regex")
        assert score == pytest.approx(0.6 * 0.5 * 0.7, abs=0.01)

    def test_clamped_to_max_1(self):
        score = compute_confidence(SourceType.DIRECT_SPEECH, 1.5, "manual")
        assert score <= 1.0

    def test_clamped_to_min_0(self):
        score = compute_confidence(SourceType.AGENT_INFERENCE, -0.5, "regex")
        assert score >= 0.0

    def test_unknown_source_type_fallback(self):
        # If somehow an invalid source type is used, should not crash
        # This tests the .get() fallback
        score = compute_confidence(SourceType.USER_INPUT, 1.0, "unknown_method")
        assert 0.0 <= score <= 1.0

    def test_all_source_types_produce_valid_scores(self):
        for st in SourceType:
            score = compute_confidence(st, 0.8, "regex")
            assert 0.0 <= score <= 1.0, f"Invalid score for {st}: {score}"
