"""Integration tests for MemoryEngine."""

import pytest
from pathlib import Path

from engram.config import EngramConfig
from engram.engine import MemoryEngine
from engram.models.entity import Entity, Tier
from engram.models.quality import Action
from engram.models.source import Source, SourceType
from engram.models.search import SearchOptions


@pytest.fixture
def engine(tmp_path):
    config = EngramConfig(
        base_dir=tmp_path / "engram",
        enable_markdown_export=True,
    )
    eng = MemoryEngine(config)
    yield eng
    eng.close()


class TestEngineStore:
    def test_store_extracts_and_saves(self, engine):
        result = engine.store("Simon Kim is the CEO of Hashed.")
        assert len(result.entities_created) >= 1
        names = [e.name for e in result.entities_created]
        assert "Simon Kim" in names

    def test_store_creates_facts(self, engine):
        result = engine.store("Simon Kim is the CEO of Hashed.")
        assert len(result.facts_added) + len(result.facts_quarantined) >= 0

    def test_store_empty_text(self, engine):
        result = engine.store("")
        assert len(result.entities_created) == 0

    def test_store_with_source(self, engine):
        source = Source(type=SourceType.DIRECT_SPEECH, confidence=1.0, author="Simon")
        result = engine.store("Simon Kim launched a $200M fund.", source=source)
        assert len(result.entities_created) >= 1

    def test_store_deduplicates_entities(self, engine):
        engine.store("Simon Kim is the CEO.")
        result = engine.store("Simon Kim launched a fund.")
        # Simon Kim should be in updated, not created (already exists)
        created_names = [e.name for e in result.entities_created]
        assert "Simon Kim" not in created_names

    def test_store_exports_markdown(self, engine):
        engine.store("Simon Kim is the CEO of Hashed.")
        md_files = list(engine.config.export_dir.glob("*.md"))
        assert len(md_files) >= 1


class TestEngineSearch:
    def test_search_after_store(self, engine):
        engine.store("Simon Kim is the CEO of Hashed.")
        result = engine.search("CEO")
        assert result.total_count >= 1

    def test_search_with_options(self, engine):
        engine.store("Simon Kim is the CEO of Hashed.")
        result = engine.search("CEO", SearchOptions(max_results=1))
        assert len(result.hits) <= 1

    def test_search_no_results(self, engine):
        result = engine.search("nonexistent")
        assert result.total_count == 0


class TestEngineEntity:
    def test_get_entity(self, engine):
        engine.store("Simon Kim is the CEO.")
        entity = engine.get_entity("Simon Kim")
        assert entity is not None
        assert entity.name == "Simon Kim"

    def test_get_entity_not_found(self, engine):
        assert engine.get_entity("Nobody") is None

    def test_create_entity_manually(self, engine):
        entity = engine.create_entity("Hashed", entity_type="organization", tier=Tier.CORE)
        assert entity.name == "Hashed"
        assert entity.tier == Tier.CORE
        retrieved = engine.get_entity("Hashed")
        assert retrieved is not None

    def test_list_entities(self, engine):
        engine.create_entity("Alice Smith", entity_type="person")
        engine.create_entity("Bob Corp", entity_type="organization")
        all_entities = engine.list_entities()
        assert len(all_entities) == 2

    def test_list_entities_filter(self, engine):
        engine.create_entity("Alice Smith", entity_type="person")
        engine.create_entity("Bob Corp", entity_type="organization")
        orgs = engine.list_entities(entity_type="organization")
        assert len(orgs) == 1
        assert orgs[0].name == "Bob Corp"


class TestEngineFact:
    def test_add_fact(self, engine):
        engine.create_entity("Simon Kim")
        result = engine.add_fact("Simon Kim", "CEO of Hashed", predicate="role")
        assert result.is_accepted

    def test_add_fact_entity_not_found(self, engine):
        from engram.exceptions import EntityNotFoundError
        with pytest.raises(EntityNotFoundError):
            engine.add_fact("Nobody", "Some fact")

    def test_get_facts(self, engine):
        engine.create_entity("Simon Kim")
        engine.add_fact("Simon Kim", "CEO of Hashed", predicate="role")
        facts = engine.get_facts("Simon Kim")
        assert len(facts) >= 1


class TestEngineSession:
    def test_session_lifecycle(self, engine):
        session = engine.start_session("claude-code")
        assert session.is_active

        ended = engine.end_session(session.session_id, summary="Test session")
        assert not ended.is_active
        assert ended.summary == "Test session"

    def test_session_context(self, engine):
        s1 = engine.start_session("claude")
        engine.end_session(s1.session_id, summary="Discussed funding")

        context = engine.get_session_context("claude")
        assert context["entity_count"] >= 0
        assert context["previous_summary"] == "Discussed funding"

    def test_session_context_new_agent(self, engine):
        context = engine.get_session_context("new-agent")
        assert context["previous_summary"] == ""


class TestEngineMaintenance:
    def test_health_check(self, engine):
        health = engine.health_check()
        assert "entity_count" in health
        assert "status" in health

    def test_export_markdown(self, engine):
        engine.create_entity("Test Entity")
        count = engine.export_markdown()
        assert count >= 1

    def test_reindex(self, engine):
        engine.create_entity("Test Entity")
        count = engine.reindex()
        assert count >= 1
