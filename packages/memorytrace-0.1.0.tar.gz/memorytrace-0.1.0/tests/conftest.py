"""Shared test fixtures for Engram."""

import pytest
from pathlib import Path

from engram.config import EngramConfig
from engram.storage.sqlite_store import SQLiteStorage
from engram.models.entity import Entity, EntityState, Tier
from engram.models.fact import Fact
from engram.models.source import Source, SourceType


@pytest.fixture
def tmp_db(tmp_path: Path) -> Path:
    """Fresh SQLite database path for each test."""
    return tmp_path / "test_memory.db"


@pytest.fixture
def storage(tmp_db: Path) -> SQLiteStorage:
    """Initialized SQLiteStorage."""
    s = SQLiteStorage(tmp_db)
    s.initialize()
    yield s
    s.close()


@pytest.fixture
def config(tmp_path: Path) -> EngramConfig:
    """Test configuration."""
    return EngramConfig(
        base_dir=tmp_path / "engram",
        enable_markdown_export=False,
    )


@pytest.fixture
def sample_entity() -> Entity:
    """A single test entity."""
    return Entity(
        name="Simon Kim",
        entity_type="person",
        state=EntityState(role="CEO", affiliation="Hashed"),
        tier=Tier.CORE,
        summary="Blockchain investor and CEO of Hashed.",
    )


@pytest.fixture
def sample_entities() -> list[Entity]:
    """Diverse test entities."""
    return [
        Entity(
            name="Simon Kim",
            entity_type="person",
            state=EntityState(role="CEO", affiliation="Hashed"),
            tier=Tier.CORE,
        ),
        Entity(
            name="김민수",
            entity_type="person",
            state=EntityState(role="CTO"),
            tier=Tier.RECALL,
        ),
        Entity(
            name="Hashed",
            entity_type="organization",
            tier=Tier.CORE,
        ),
        Entity(
            name="Ethereum Foundation",
            entity_type="organization",
            tier=Tier.RECALL,
        ),
        Entity(
            name="Project Alpha",
            entity_type="project",
            tier=Tier.ARCHIVAL,
        ),
    ]


@pytest.fixture
def sample_fact(sample_entity: Entity) -> Fact:
    """A single test fact."""
    return Fact(
        entity_id=sample_entity.id,
        subject="Simon Kim",
        predicate="role",
        object="CEO",
        raw_text="Simon Kim is the CEO of Hashed",
        source=Source(
            type=SourceType.DOCUMENT,
            author="press",
            channel="news",
            confidence=0.9,
        ),
        confidence=0.85,
    )
