"""Tests for SQLite storage backend."""

import threading

import pytest

from engram.models.entity import Entity, EntityState, Tier
from engram.models.fact import Fact, FactStatus
from engram.models.relation import Relation
from engram.models.session import Session, SessionEvent
from engram.models.source import Source, SourceType
from engram.exceptions import EntityAlreadyExistsError
from engram.storage.sqlite_store import SQLiteStorage


class TestEntityCRUD:
    def test_create_and_get_entity(self, storage: SQLiteStorage, sample_entity: Entity):
        created = storage.create_entity(sample_entity)
        assert created.id == sample_entity.id

        retrieved = storage.get_entity(created.id)
        assert retrieved is not None
        assert retrieved.name == "Simon Kim"
        assert retrieved.entity_type == "person"
        assert retrieved.tier == Tier.CORE
        assert retrieved.state.role == "CEO"
        assert retrieved.state.affiliation == "Hashed"

    def test_get_entity_by_name(self, storage: SQLiteStorage, sample_entity: Entity):
        storage.create_entity(sample_entity)
        retrieved = storage.get_entity_by_name("Simon Kim")
        assert retrieved is not None
        assert retrieved.name == "Simon Kim"

    def test_get_entity_by_name_case_insensitive(self, storage: SQLiteStorage, sample_entity: Entity):
        storage.create_entity(sample_entity)
        retrieved = storage.get_entity_by_name("simon kim")
        assert retrieved is not None
        assert retrieved.name == "Simon Kim"

    def test_get_nonexistent_entity(self, storage: SQLiteStorage):
        assert storage.get_entity("nonexistent-id") is None
        assert storage.get_entity_by_name("Nobody") is None

    def test_create_duplicate_entity_raises(self, storage: SQLiteStorage, sample_entity: Entity):
        storage.create_entity(sample_entity)
        duplicate = Entity(name="Simon Kim", entity_type="person")
        with pytest.raises(EntityAlreadyExistsError):
            storage.create_entity(duplicate)

    def test_update_entity(self, storage: SQLiteStorage, sample_entity: Entity):
        storage.create_entity(sample_entity)
        sample_entity.state.role = "Founder"
        sample_entity.tier = Tier.ARCHIVAL
        updated = storage.update_entity(sample_entity)
        assert updated.state.role == "Founder"
        assert updated.tier == Tier.ARCHIVAL

        retrieved = storage.get_entity(sample_entity.id)
        assert retrieved.state.role == "Founder"

    def test_delete_entity(self, storage: SQLiteStorage, sample_entity: Entity):
        storage.create_entity(sample_entity)
        assert storage.delete_entity(sample_entity.id) is True
        assert storage.get_entity(sample_entity.id) is None

    def test_delete_nonexistent(self, storage: SQLiteStorage):
        assert storage.delete_entity("no-such-id") is False

    def test_list_entities(self, storage: SQLiteStorage, sample_entities: list[Entity]):
        for e in sample_entities:
            storage.create_entity(e)

        all_entities = storage.list_entities()
        assert len(all_entities) == 5

    def test_list_entities_filter_by_tier(self, storage: SQLiteStorage, sample_entities: list[Entity]):
        for e in sample_entities:
            storage.create_entity(e)

        core = storage.list_entities(tier=Tier.CORE)
        assert all(e.tier == Tier.CORE for e in core)

    def test_list_entities_filter_by_type(self, storage: SQLiteStorage, sample_entities: list[Entity]):
        for e in sample_entities:
            storage.create_entity(e)

        orgs = storage.list_entities(entity_type="organization")
        assert all(e.entity_type == "organization" for e in orgs)
        assert len(orgs) == 2

    def test_list_entities_pagination(self, storage: SQLiteStorage, sample_entities: list[Entity]):
        for e in sample_entities:
            storage.create_entity(e)

        page1 = storage.list_entities(limit=2, offset=0)
        page2 = storage.list_entities(limit=2, offset=2)
        assert len(page1) == 2
        assert len(page2) == 2
        assert page1[0].id != page2[0].id

    def test_entity_with_korean_name(self, storage: SQLiteStorage):
        entity = Entity(name="김민수", entity_type="person")
        created = storage.create_entity(entity)
        retrieved = storage.get_entity_by_name("김민수")
        assert retrieved is not None
        assert retrieved.name == "김민수"

    def test_entity_with_aliases(self, storage: SQLiteStorage):
        entity = Entity(name="Simon Kim", aliases=["김시몬", "SK"])
        storage.create_entity(entity)
        retrieved = storage.get_entity(entity.id)
        assert retrieved.aliases == ["김시몬", "SK"]

    def test_entity_count(self, storage: SQLiteStorage, sample_entities: list[Entity]):
        assert storage.entity_count() == 0
        for e in sample_entities:
            storage.create_entity(e)
        assert storage.entity_count() == 5


class TestFactCRUD:
    def test_add_and_get_fact(self, storage: SQLiteStorage, sample_entity: Entity, sample_fact: Fact):
        storage.create_entity(sample_entity)
        created = storage.add_fact(sample_fact)

        facts = storage.get_facts(sample_entity.id)
        assert len(facts) == 1
        assert facts[0].subject == "Simon Kim"
        assert facts[0].predicate == "role"
        assert facts[0].object == "CEO"
        assert facts[0].confidence == 0.85

    def test_get_current_facts(self, storage: SQLiteStorage, sample_entity: Entity):
        storage.create_entity(sample_entity)

        current = Fact(
            entity_id=sample_entity.id, subject="Simon Kim",
            predicate="role", object="CEO", raw_text="CEO",
        )
        expired = Fact(
            entity_id=sample_entity.id, subject="Simon Kim",
            predicate="role", object="CTO", raw_text="CTO",
            status=FactStatus.EXPIRED,
        )
        storage.add_fact(current)
        storage.add_fact(expired)

        current_facts = storage.get_current_facts(sample_entity.id)
        assert len(current_facts) == 1
        assert current_facts[0].object == "CEO"

    def test_update_fact(self, storage: SQLiteStorage, sample_entity: Entity, sample_fact: Fact):
        storage.create_entity(sample_entity)
        storage.add_fact(sample_fact)

        sample_fact.confidence = 0.95
        sample_fact.status = FactStatus.VERIFIED
        storage.update_fact(sample_fact)

        facts = storage.get_facts(sample_entity.id)
        assert facts[0].confidence == 0.95
        assert facts[0].status == FactStatus.VERIFIED

    def test_fact_count(self, storage: SQLiteStorage, sample_entity: Entity, sample_fact: Fact):
        storage.create_entity(sample_entity)
        assert storage.fact_count() == 0
        storage.add_fact(sample_fact)
        assert storage.fact_count() == 1

    def test_cascade_delete_facts(self, storage: SQLiteStorage, sample_entity: Entity, sample_fact: Fact):
        storage.create_entity(sample_entity)
        storage.add_fact(sample_fact)
        storage.delete_entity(sample_entity.id)
        assert storage.fact_count() == 0


class TestRelations:
    def test_add_and_get_relation(self, storage: SQLiteStorage, sample_entities: list[Entity]):
        for e in sample_entities[:2]:
            storage.create_entity(e)

        rel = Relation(
            from_entity_id=sample_entities[0].id,
            to_entity_id=sample_entities[1].id,
            relation_type="WORKS_WITH",
            metadata={"since": "2024"},
        )
        storage.add_relation(rel)

        rels = storage.get_relations(sample_entities[0].id, direction="outgoing")
        assert len(rels) == 1
        assert rels[0].relation_type == "WORKS_WITH"
        assert rels[0].metadata["since"] == "2024"

    def test_get_relations_both_directions(self, storage: SQLiteStorage, sample_entities: list[Entity]):
        for e in sample_entities[:2]:
            storage.create_entity(e)

        rel = Relation(
            from_entity_id=sample_entities[0].id,
            to_entity_id=sample_entities[1].id,
            relation_type="CEO_OF",
        )
        storage.add_relation(rel)

        from_rels = storage.get_relations(sample_entities[0].id, direction="both")
        to_rels = storage.get_relations(sample_entities[1].id, direction="both")
        assert len(from_rels) == 1
        assert len(to_rels) == 1


class TestSessions:
    def test_save_and_get_session(self, storage: SQLiteStorage):
        session = Session(agent_id="claude-code")
        storage.save_session(session)

        retrieved = storage.get_session(session.session_id)
        assert retrieved is not None
        assert retrieved.agent_id == "claude-code"
        assert retrieved.is_active

    def test_get_recent_sessions(self, storage: SQLiteStorage):
        for i in range(3):
            storage.save_session(Session(agent_id="claude"))

        recent = storage.get_recent_sessions("claude", limit=2)
        assert len(recent) == 2

    def test_session_events(self, storage: SQLiteStorage):
        session = Session(agent_id="test")
        storage.save_session(session)

        event = SessionEvent(
            session_id=session.session_id,
            event_type="search",
            target="Simon Kim",
            detail={"results": 3},
        )
        storage.add_session_event(event)


class TestConcurrency:
    def test_concurrent_writes_no_data_loss(self, storage: SQLiteStorage, sample_entity: Entity):
        """Multiple threads writing facts should not lose any."""
        storage.create_entity(sample_entity)

        def add_fact(n: int) -> None:
            fact = Fact(
                entity_id=sample_entity.id,
                subject="Simon Kim", predicate="note",
                object=f"Fact {n}", raw_text=f"Fact {n}",
            )
            storage.add_fact(fact)

        threads = [threading.Thread(target=add_fact, args=(i,)) for i in range(20)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        facts = storage.get_facts(sample_entity.id)
        assert len(facts) == 20


class TestFTSIndex:
    def test_fts_index_created_on_entity(self, storage: SQLiteStorage, sample_entity: Entity):
        storage.create_entity(sample_entity)
        rows = storage._conn.execute(
            "SELECT * FROM memory_fts WHERE entity_name = 'Simon Kim'"
        ).fetchall()
        assert len(rows) == 1

    def test_fts_index_updated_on_fact(self, storage: SQLiteStorage, sample_entity: Entity, sample_fact: Fact):
        storage.create_entity(sample_entity)
        storage.add_fact(sample_fact)
        rows = storage._conn.execute(
            "SELECT fact_text FROM memory_fts WHERE entity_id = ?",
            (sample_entity.id,),
        ).fetchall()
        assert len(rows) == 1
        assert "CEO" in rows[0]["fact_text"]

    def test_reindex_all(self, storage: SQLiteStorage, sample_entities: list[Entity]):
        for e in sample_entities:
            storage.create_entity(e)
        count = storage.reindex_all()
        assert count == 5
