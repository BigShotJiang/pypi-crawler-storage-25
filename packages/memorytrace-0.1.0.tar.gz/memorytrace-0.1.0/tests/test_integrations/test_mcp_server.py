"""Tests for MCP server tool functions (without running actual MCP server)."""

import pytest


class TestMCPServerImport:
    def test_mcp_server_module_importable(self):
        """The module should be importable even without mcp package."""
        # This tests that the module doesn't crash on import
        from engram.integrations import mcp_server
        assert hasattr(mcp_server, "run_server")
        assert hasattr(mcp_server, "_get_engine")
