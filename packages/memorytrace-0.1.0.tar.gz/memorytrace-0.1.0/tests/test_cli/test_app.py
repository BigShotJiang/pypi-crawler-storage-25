"""Tests for CLI app — invokes CLI via main() with argv."""

import json
import pytest
from io import StringIO
from unittest.mock import patch

from engram.cli.app import main


@pytest.fixture(autouse=True)
def use_tmp_db(tmp_path, monkeypatch):
    """Override default DB path for all CLI tests."""
    db_path = str(tmp_path / "test.db")
    monkeypatch.setenv("HOME", str(tmp_path))
    return db_path


class TestCLIInit:
    def test_init(self, use_tmp_db):
        code = main(["--db", use_tmp_db, "init"])
        assert code == 0

    def test_init_quiet(self, use_tmp_db):
        code = main(["--db", use_tmp_db, "--quiet", "init"])
        assert code == 0


class TestCLIStore:
    def test_store_text(self, use_tmp_db):
        main(["--db", use_tmp_db, "init"])
        code = main(["--db", use_tmp_db, "store", "Simon Kim is the CEO of Hashed."])
        assert code == 0

    def test_store_json_output(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        capsys.readouterr()  # clear init output
        main(["--db", use_tmp_db, "--json", "store", "Simon Kim is the CEO."])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert "entities_created" in data

    def test_store_empty_returns_0(self, use_tmp_db):
        main(["--db", use_tmp_db, "--quiet", "init"])
        code = main(["--db", use_tmp_db, "store", "hello world"])
        assert code == 0


class TestCLISearch:
    def test_search(self, use_tmp_db):
        main(["--db", use_tmp_db, "init"])
        main(["--db", use_tmp_db, "store", "Simon Kim is the CEO of Hashed."])
        code = main(["--db", use_tmp_db, "search", "CEO"])
        assert code == 0

    def test_search_json(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "store", "Simon Kim is the CEO of Hashed."])
        capsys.readouterr()  # clear previous output
        main(["--db", use_tmp_db, "--json", "search", "CEO"])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert "hits" in data

    def test_search_no_results(self, use_tmp_db):
        main(["--db", use_tmp_db, "init"])
        code = main(["--db", use_tmp_db, "search", "nonexistent"])
        assert code == 0


class TestCLIEntity:
    def test_create_and_get(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "init"])
        main(["--db", use_tmp_db, "create", "Alice Smith", "--type", "person"])
        code = main(["--db", use_tmp_db, "get", "Alice Smith"])
        assert code == 0
        captured = capsys.readouterr()
        assert "Alice Smith" in captured.out

    def test_get_not_found(self, use_tmp_db):
        main(["--db", use_tmp_db, "init"])
        code = main(["--db", use_tmp_db, "get", "Nobody"])
        assert code == 1

    def test_list(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "init"])
        main(["--db", use_tmp_db, "create", "Alice Smith"])
        main(["--db", use_tmp_db, "create", "Bob Corp", "--type", "organization"])
        main(["--db", use_tmp_db, "list"])
        captured = capsys.readouterr()
        assert "Alice Smith" in captured.out
        assert "Bob Corp" in captured.out

    def test_list_json(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "create", "Alice Smith"])
        capsys.readouterr()
        main(["--db", use_tmp_db, "--json", "list"])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert len(data) >= 1

    def test_list_filter_type(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "create", "Alice", "--type", "person"])
        main(["--db", use_tmp_db, "create", "Corp", "--type", "organization"])
        capsys.readouterr()
        main(["--db", use_tmp_db, "--json", "list", "--type", "organization"])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert all(e["type"] == "organization" for e in data)


class TestCLIFact:
    def test_add_fact(self, use_tmp_db):
        main(["--db", use_tmp_db, "init"])
        main(["--db", use_tmp_db, "create", "Simon Kim"])
        code = main(["--db", use_tmp_db, "add-fact", "Simon Kim", "CEO of Hashed"])
        assert code == 0

    def test_add_fact_json(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        main(["--db", use_tmp_db, "create", "Simon Kim"])
        capsys.readouterr()
        main(["--db", use_tmp_db, "--json", "add-fact", "Simon Kim", "CEO of Hashed"])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert "action" in data


class TestCLIHealth:
    def test_health(self, use_tmp_db):
        main(["--db", use_tmp_db, "init"])
        code = main(["--db", use_tmp_db, "health"])
        assert code == 0

    def test_health_json(self, use_tmp_db, capsys):
        main(["--db", use_tmp_db, "--quiet", "init"])
        capsys.readouterr()
        main(["--db", use_tmp_db, "--json", "health"])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert "entity_count" in data


class TestCLIMaintenance:
    def test_export(self, use_tmp_db):
        main(["--db", use_tmp_db, "init"])
        main(["--db", use_tmp_db, "create", "Test Entity"])
        code = main(["--db", use_tmp_db, "export"])
        assert code == 0

    def test_reindex(self, use_tmp_db):
        main(["--db", use_tmp_db, "init"])
        code = main(["--db", use_tmp_db, "reindex"])
        assert code == 0


class TestCLINoCommand:
    def test_no_command_shows_help(self, capsys):
        code = main([])
        assert code == 0

    def test_exit_code_on_error(self, use_tmp_db):
        code = main(["--db", use_tmp_db, "get", "Nonexistent"])
        assert code == 1
