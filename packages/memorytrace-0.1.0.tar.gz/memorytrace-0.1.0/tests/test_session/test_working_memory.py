"""Tests for working memory."""

import pytest

from engram.models.entity import Entity, EntityState
from engram.models.session import Session
from engram.session.working_memory import WorkingMemory
from engram.storage.sqlite_store import SQLiteStorage


@pytest.fixture
def wm_setup(tmp_path):
    db_path = tmp_path / "wm_test.db"
    storage = SQLiteStorage(db_path)
    storage.initialize()

    e1 = Entity(name="Simon Kim", entity_type="person", state=EntityState(role="CEO"))
    e2 = Entity(name="Hashed", entity_type="organization")
    storage.create_entity(e1)
    storage.create_entity(e2)

    session = Session(agent_id="test")
    wm = WorkingMemory(session)
    yield wm, storage, e1, e2
    storage.close()


class TestWorkingMemory:
    def test_touch_entity(self, wm_setup):
        wm, _, e1, _ = wm_setup
        wm.touch_entity(e1.id)
        assert e1.id in wm.active_entities

    def test_touch_entity_recency_order(self, wm_setup):
        wm, _, e1, e2 = wm_setup
        wm.touch_entity(e1.id)
        wm.touch_entity(e2.id)
        assert wm.active_entities[0] == e2.id
        # Touch e1 again — should be first
        wm.touch_entity(e1.id)
        assert wm.active_entities[0] == e1.id

    def test_get_active_entity_ids(self, wm_setup):
        wm, _, e1, e2 = wm_setup
        wm.touch_entity(e1.id)
        wm.touch_entity(e2.id)
        ids = wm.get_active_entity_ids(limit=1)
        assert len(ids) == 1

    def test_add_query(self, wm_setup):
        wm, _, _, _ = wm_setup
        wm.add_query("Simon Kim CEO")
        wm.add_query("Hashed fund")
        assert wm.recent_queries[0] == "Hashed fund"
        assert len(wm.recent_queries) == 2

    def test_query_limit(self, wm_setup):
        wm, _, _, _ = wm_setup
        for i in range(25):
            wm.add_query(f"query {i}")
        assert len(wm.recent_queries) == 20

    def test_get_active_context(self, wm_setup):
        wm, storage, e1, e2 = wm_setup
        wm.touch_entity(e1.id)
        wm.touch_entity(e2.id)
        context = wm.get_active_context(storage)
        assert "Simon Kim" in context
        assert "CEO" in context

    def test_get_active_context_empty(self, wm_setup):
        wm, storage, _, _ = wm_setup
        assert wm.get_active_context(storage) == ""
