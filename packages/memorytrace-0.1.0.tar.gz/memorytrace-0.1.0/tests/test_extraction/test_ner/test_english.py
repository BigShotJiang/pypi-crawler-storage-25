"""Tests for English NER — precision and recall."""

import pytest

from engram.extraction.ner.english import extract_english_entities


class TestEnglishPersonDetection:
    def test_basic_name(self):
        entities = extract_english_entities("Simon Kim is the CEO.")
        names = [e.name for e in entities]
        assert "Simon Kim" in names

    def test_three_word_name(self):
        entities = extract_english_entities("Mary Jane Watson arrived.")
        names = [e.name for e in entities]
        assert "Mary Jane Watson" in names

    def test_titled_name(self):
        entities = extract_english_entities("Dr. Grace Hopper invented COBOL.")
        names = [e.name for e in entities]
        assert "Grace Hopper" in names

    def test_multiple_names(self):
        entities = extract_english_entities("Elon Musk and Jeff Bezos met yesterday.")
        names = [e.name for e in entities]
        assert "Elon Musk" in names
        assert "Jeff Bezos" in names

    def test_deduplication(self):
        entities = extract_english_entities("Simon Kim said hello. Simon Kim left.")
        names = [e.name for e in entities]
        assert names.count("Simon Kim") == 1


class TestEnglishFalsePositiveRejection:
    """These should NOT be detected as person names."""

    def test_reject_section_headers(self):
        entities = extract_english_entities("Key Points: the main ideas.")
        names = [e.name for e in entities]
        assert "Key Points" not in names

    def test_reject_geographic_names(self):
        entities = extract_english_entities("North America is a continent.")
        names = [e.name for e in entities]
        assert "North America" not in names

    def test_reject_city_names(self):
        entities = extract_english_entities("He lives in New York and Los Angeles.")
        names = [e.name for e in entities]
        assert "New York" not in names
        assert "Los Angeles" not in names

    def test_reject_tech_terms(self):
        entities = extract_english_entities("Machine Learning is advancing rapidly.")
        names = [e.name for e in entities]
        assert "Machine Learning" not in names

    def test_reject_greetings(self):
        entities = extract_english_entities("Looking Forward to the meeting.")
        names = [e.name for e in entities]
        assert "Looking Forward" not in names


class TestEnglishOrganizationDetection:
    def test_org_with_inc(self):
        entities = extract_english_entities("Apple Inc. released a new product.")
        orgs = [e for e in entities if e.entity_type == "organization"]
        org_names = [e.name for e in orgs]
        assert any("Apple" in n for n in org_names)

    def test_org_with_foundation(self):
        entities = extract_english_entities("Ethereum Foundation announced grants.")
        orgs = [e for e in entities if e.entity_type == "organization"]
        org_names = [e.name for e in orgs]
        assert any("Ethereum Foundation" in n for n in org_names)

    def test_org_with_capital(self):
        entities = extract_english_entities("Sequoia Capital invested heavily.")
        orgs = [e for e in entities if e.entity_type == "organization"]
        org_names = [e.name for e in orgs]
        assert any("Sequoia Capital" in n for n in org_names)


class TestEnglishEdgeCases:
    def test_empty_string(self):
        assert extract_english_entities("") == []

    def test_no_entities(self):
        assert extract_english_entities("hello world, this is a test.") == []

    def test_single_word_uppercase(self):
        # Single uppercase word should not match
        entities = extract_english_entities("HELLO world")
        assert len(entities) == 0

    def test_mixed_with_korean(self):
        entities = extract_english_entities("Simon Kim은 Hashed의 CEO입니다")
        names = [e.name for e in entities]
        assert "Simon Kim" in names
