# 12. AI 에이전트 메모리 시스템 — 단점 분석 & 개선 청사진

> MemKraft의 한계를 분석하고, "진짜 작동하는" AI 에이전트 메모리 시스템을 설계하기 위한 개선 방향을 정리한다.

---

## Part 1: 단점 심층 분석 (8가지 관점)

---

### 관점 1. 아키텍처 & 시스템 설계

#### 단점 1-1: 단일 파일 모놀리스

`core.py` 하나에 2037줄, 40+ 메서드. NER, 검색, 파일 I/O, 유지보수, 프레젠테이션이 전부 한 클래스에 있다.

**왜 문제인가:**
- 검색 알고리즘만 개선하려 해도 NER/파일 I/O 코드와 엮여 있음
- 테스트 시 개별 모듈 단위 격리 불가
- 다른 스토리지 백엔드(SQLite, 벡터DB)로 교체 불가 — 인터페이스 추상화 없음

**개선 방향:**
```
memory_system/
├── core/
│   ├── engine.py          # 오케스트레이션 (얇은 조정 계층)
│   ├── entity.py          # 엔티티 CRUD
│   └── session.py         # 세션 관리
├── extraction/
│   ├── base.py            # 추출기 인터페이스
│   ├── regex_extractor.py # 기본 정규식 (MemKraft 방식)
│   ├── llm_extractor.py   # LLM 기반 추출 (선택)
│   └── ner.py             # 개체명 인식
├── search/
│   ├── base.py            # 검색 인터페이스
│   ├── bm25.py            # BM25 키워드 검색
│   ├── semantic.py        # 임베딩 시맨틱 검색 (선택)
│   └── hybrid.py          # BM25 + 시맨틱 혼합
├── storage/
│   ├── base.py            # 스토리지 인터페이스
│   ├── markdown.py        # 마크다운 파일 백엔드
│   ├── sqlite.py          # SQLite 백엔드
│   └── json_store.py      # JSON 백엔드
├── integrations/
│   ├── mcp_server.py      # MCP 서버
│   ├── tool_schema.py     # tool_use / function_calling 스키마
│   └── rest_api.py        # REST API (선택)
└── quality/
    ├── validator.py        # 쓰기 시 품질 검증
    ├── dedup.py            # 중복 탐지/병합
    └── decay.py            # 정보 노후화 관리
```

핵심: **인터페이스 추상화**로 각 계층을 독립적으로 교체 가능하게 만든다.

#### 단점 1-2: 동기식 블로킹 설계

모든 작업이 동기식. 검색하는 동안 에이전트는 대기해야 한다.

**개선 방향:**
- 비동기 I/O (`asyncio`) 지원 — 에이전트 프레임워크 대부분이 async
- 백그라운드 인덱싱 — 쓰기 시 즉시 반환, 인덱스는 비동기 업데이트
- 이벤트 기반 아키텍처 — 쓰기 이벤트 발생 시 인덱스/캐시 자동 갱신

#### 단점 1-3: 상태 관리의 부재

MemKraft는 매 호출마다 `MemKraft()` 인스턴스를 새로 생성한다. 인메모리 캐시, 인덱스, 세션 상태가 호출 간에 유지되지 않는다.

**개선 방향:**
- 상주 프로세스 (데몬 또는 서버) — 인덱스를 메모리에 유지
- 또는 SQLite 인덱스 — 프로세스 재시작 후에도 빠른 검색 가능
- 커넥션 풀링 패턴 — 여러 에이전트가 동시에 접근 가능

---

### 관점 2. AI/LLM 통합

#### 단점 2-1: AI를 위한 시스템인데 AI를 전혀 사용하지 않음

| 기능 | MemKraft 방식 | AI 활용 시 |
|------|--------------|-----------|
| 엔티티 추출 | 정규식 패턴 매칭 | LLM이 문맥 이해 후 추출 |
| 사실 추출 | `"X is Y"` 패턴 | LLM이 암묵적 사실도 추출 |
| 분류 (cognify) | 키워드 4개 매칭 | LLM이 의미 기반 분류 |
| 검색 | BM25 문자열 매칭 | 임베딩 시맨틱 검색 |
| 요약 | 불릿 포인트 복사 | LLM이 진짜 요약 생성 |
| 중복 탐지 | 문자열 유사도 0.85 | 의미적 동치 판단 |

**개선 방향 — "LLM-Optional" 아키텍처:**

```python
# 추출기 인터페이스
class Extractor(Protocol):
    def extract_entities(self, text: str) -> list[Entity]: ...
    def extract_facts(self, text: str) -> list[Fact]: ...

# 기본: 정규식 (제로 디펜던시)
class RegexExtractor(Extractor): ...

# 선택: LLM 기반 (의존성 추가 시)
class LLMExtractor(Extractor):
    def __init__(self, provider: str = "anthropic"):
        # anthropic SDK 또는 openai SDK 사용
        ...
    def extract_entities(self, text: str) -> list[Entity]:
        response = self.client.messages.create(
            model="claude-sonnet-4-6",
            messages=[{"role": "user", "content": f"Extract entities from: {text}"}],
            # 구조화된 출력으로 Entity 리스트 반환
        )
        return parse_entities(response)
```

**핵심 원칙: "제로 디펜던시를 기본으로, LLM을 플러그인으로"**
- `pip install memkraft` → 정규식 기반 기본 동작
- `pip install memkraft[llm]` → LLM 기반 고품질 추출/검색
- `pip install memkraft[full]` → 벡터DB + LLM + REST API

#### 단점 2-2: 에이전트 프레임워크 통합 인터페이스 부재

Claude, GPT, LangChain, CrewAI 등 어떤 에이전트 프레임워크와도 연결 불가.

**개선 방향:**

**MCP (Model Context Protocol) 서버:**
```python
# 에이전트가 자동으로 발견하고 호출할 수 있는 표준 인터페이스
@mcp.tool()
def memory_search(query: str, max_tokens: int = 500) -> str:
    """Search agent memory for relevant context."""
    results = engine.search(query, token_budget=max_tokens)
    return format_for_agent(results)

@mcp.tool()
def memory_store(content: str, source: str, confidence: float = 1.0) -> str:
    """Store new information in agent memory."""
    if confidence < 0.7:
        return "Confidence too low, not stored."
    engine.store(content, source=source, confidence=confidence)
    return "Stored successfully."
```

**Claude tool_use 스키마:**
```json
{
  "name": "memory_search",
  "description": "Search the agent's persistent memory",
  "input_schema": {
    "type": "object",
    "properties": {
      "query": {"type": "string"},
      "max_results": {"type": "integer", "default": 5},
      "max_tokens": {"type": "integer", "default": 500},
      "min_confidence": {"type": "number", "default": 0.0}
    },
    "required": ["query"]
  }
}
```

#### 단점 2-3: 에이전트가 "언제" 메모리를 사용할지 가이드 없음

**개선 방향 — 시스템 프롬프트 생성기:**

```python
def generate_system_prompt(session_id: str) -> str:
    """에이전트에 주입할 메모리 관련 시스템 프롬프트 생성"""
    recent_entities = engine.get_recent(limit=5)
    active_tasks = engine.get_open_tasks()
    
    return f"""
    ## Available Memory
    You have access to a persistent memory system with {engine.entity_count()} entities.
    
    Recently active: {', '.join(e.name for e in recent_entities)}
    Open tasks: {len(active_tasks)}
    
    Use memory_search when:
    - The user mentions a person, company, or project you've discussed before
    - You need facts about previous decisions or meetings
    - The user references "last time", "before", "we discussed"
    
    Use memory_store when:
    - New factual information is shared (not opinions or small talk)
    - A decision is made
    - An action item is assigned
    """
```

---

### 관점 3. 데이터 품질 & 신뢰성

#### 단점 3-1: 쓰기 시 품질 검증 없음 → 환각 전파

MemKraft는 `extract`에 전달된 모든 텍스트를 무조건 저장한다. 에이전트가 환각한 정보도 "확인된 사실"로 기록된다.

**개선 방향 — 다계층 품질 게이트:**

```
입력 텍스트
    │
    ├── [1단계] 신뢰도 점수 (confidence scoring)
    │   ├── 출처 유형별 기본 점수: 직접 발언(0.9) > 문서(0.8) > 에이전트 추론(0.5)
    │   ├── LLM 사용 시: 추출 확신도를 LLM이 자체 판단
    │   └── 임계값 미달 시 → inbox에 "미확인" 태그로 저장
    │
    ├── [2단계] 기존 데이터와 충돌 검사
    │   ├── "Simon Kim은 CEO다" vs 기존 "Simon Kim은 CTO다"
    │   ├── 충돌 시 → 자동 저장 안 함, 충돌 플래그 생성
    │   └── 사람 또는 에이전트가 해결
    │
    ├── [3단계] 교차 검증 (선택)
    │   ├── 동일 사실이 2개 이상 독립 출처에서 확인 → 확정
    │   └── 단일 출처 → "미확인" 태그 유지
    │
    └── [4단계] 시간 기반 자동 만료
        ├── 역할/소속: 6개월 후 재확인 필요 태그
        ├── 연락처: 1년 후 재확인 필요 태그
        └── 사실: 출처 신뢰도에 비례한 TTL
```

```python
class QualityGate:
    def validate(self, fact: Fact, existing: list[Fact]) -> ValidationResult:
        score = self._compute_confidence(fact)
        conflicts = self._find_conflicts(fact, existing)
        
        if score < self.threshold:
            return ValidationResult(action="quarantine", reason="low_confidence")
        if conflicts:
            return ValidationResult(action="flag_conflict", conflicts=conflicts)
        return ValidationResult(action="accept")
```

#### 단점 3-2: 출처(Source) 시스템이 텍스트일 뿐

`[Source: meeting, 2026-04-12]`는 사람이 읽기 좋지만 프로그래밍 방식으로 활용할 수 없다.

**개선 방향 — 구조화된 출처 메타데이터:**

```python
@dataclass
class Source:
    type: Literal["direct_speech", "document", "api", "web", "agent_inference"]
    author: str
    channel: str  # meeting, email, slack, etc.
    timestamp: datetime
    confidence: float  # 0.0 ~ 1.0
    url: Optional[str] = None
    session_id: Optional[str] = None
    
    @property
    def trust_score(self) -> float:
        """출처 유형별 기본 신뢰도 × 개별 확신도"""
        base = {"direct_speech": 0.95, "document": 0.85, "api": 0.80, 
                "web": 0.60, "agent_inference": 0.40}
        return base[self.type] * self.confidence
```

#### 단점 3-3: 사실의 시간적 차원이 없음

"Simon Kim은 CEO다"가 언제부터 언제까지 참인지 추적하지 않는다.

**개선 방향 — Temporal Fact:**

```python
@dataclass
class TemporalFact:
    subject: str           # "Simon Kim"
    predicate: str         # "role"
    object: str            # "CEO"
    valid_from: datetime   # 2024-01-01
    valid_to: Optional[datetime]  # None = 현재까지 유효
    source: Source
    superseded_by: Optional[str] = None  # 이 사실을 대체한 새 사실의 ID
```

이렇게 하면:
- "Simon Kim의 현재 역할은?" → `valid_to is None`인 가장 최신 사실
- "2023년에 Simon Kim은 뭘 했나?" → 해당 기간의 사실 조회
- 역할 변경 시 이전 사실의 `valid_to` 설정 + 새 사실 생성

---

### 관점 4. 성능 & 확장성

#### 단점 4-1: O(n) 전체 파일 스캔

모든 검색이 디스크의 모든 .md 파일을 읽는다. 인덱스(`build_index`)가 있지만 `search()`가 사용하지 않는다.

**개선 방향:**

```python
# 방법 1: SQLite 역인덱스 (제로 외부 의존성 유지)
import sqlite3  # 표준 라이브러리!

class SQLiteIndex:
    def __init__(self, db_path: str):
        self.conn = sqlite3.connect(db_path)
        self.conn.execute("""
            CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts 
            USING fts5(entity, content, source, timestamp)
        """)
    
    def search(self, query: str, limit: int = 10) -> list[dict]:
        return self.conn.execute(
            "SELECT * FROM memory_fts WHERE memory_fts MATCH ? LIMIT ?",
            (query, limit)
        ).fetchall()
    
    def index(self, entity: str, content: str, source: str):
        self.conn.execute(
            "INSERT INTO memory_fts VALUES (?, ?, ?, ?)",
            (entity, content, source, datetime.now().isoformat())
        )
```

**`sqlite3`는 Python 표준 라이브러리다.** "제로 디펜던시"를 유지하면서 FTS5 전문 검색을 사용할 수 있다.

```python
# 방법 2: 인메모리 역인덱스 (프로세스 상주 시)
class InvertedIndex:
    def __init__(self):
        self.index: dict[str, set[str]] = defaultdict(set)  # token → {file_paths}
        self.doc_cache: dict[str, str] = {}  # file_path → content
    
    def add(self, file_path: str, content: str):
        tokens = tokenize(content)
        for token in tokens:
            self.index[token].add(file_path)
        self.doc_cache[file_path] = content
    
    def search(self, query: str) -> list[str]:
        tokens = tokenize(query)
        candidates = set.intersection(*[self.index.get(t, set()) for t in tokens])
        return self._rank(candidates, tokens)
```

#### 단점 4-2: 동시 접근 불가

파일 락이 없어 두 에이전트가 동시에 같은 엔티티를 업데이트하면 데이터 손실.

**개선 방향:**

```python
import fcntl  # Unix 표준 라이브러리

class AtomicFileWriter:
    @contextmanager
    def locked_write(self, filepath: Path):
        """원자적 파일 쓰기: 임시 파일 → rename"""
        tmp = filepath.with_suffix('.tmp')
        lock = filepath.with_suffix('.lock')
        
        with open(lock, 'w') as lockfile:
            fcntl.flock(lockfile, fcntl.LOCK_EX)  # 배타적 락
            try:
                yield tmp
                tmp.rename(filepath)  # 원자적 rename
            finally:
                fcntl.flock(lockfile, fcntl.LOCK_UN)
                lock.unlink(missing_ok=True)
```

#### 단점 4-3: 캐싱 전략 부재

**개선 방향:**

```python
class MemoryCache:
    def __init__(self, max_size: int = 1000, ttl: int = 300):
        self._cache: OrderedDict[str, CacheEntry] = OrderedDict()
        self._max_size = max_size
        self._ttl = ttl  # seconds
    
    def get(self, key: str) -> Optional[Any]:
        if key in self._cache:
            entry = self._cache[key]
            if time.time() - entry.timestamp < self._ttl:
                self._cache.move_to_end(key)
                return entry.value
            del self._cache[key]
        return None
    
    def invalidate_on_write(self, entity: str):
        """엔티티 업데이트 시 관련 캐시 무효화"""
        keys_to_remove = [k for k in self._cache if entity in k]
        for k in keys_to_remove:
            del self._cache[k]
```

---

### 관점 5. 개발자 경험 (DX)

#### 단점 5-1: 구조화된 입출력이 없음

모든 메서드가 `print()`와 반환값을 혼용한다. 에이전트가 결과를 파싱하려면 stdout 텍스트를 정규식으로 파싱해야 한다.

**개선 방향 — 구조화된 응답 객체:**

```python
@dataclass
class SearchResult:
    query: str
    results: list[MemoryEntry]
    total_count: int
    search_time_ms: float
    token_count: int  # 에이전트가 토큰 예산 관리에 사용
    
    def to_json(self) -> str: ...
    def to_markdown(self) -> str: ...  # CLI 출력용
    def to_agent_context(self, max_tokens: int = 500) -> str: ...  # 에이전트용 압축

@dataclass
class MemoryEntry:
    entity: str
    content: str
    relevance_score: float
    confidence: float
    source: Source
    last_updated: datetime
    tier: Literal["core", "recall", "archival"]
```

```python
# CLI에서는 사람용 출력
results = engine.search("Simon Kim")
print(results.to_markdown())  # CLI만 print() 담당

# 에이전트에서는 구조화된 데이터
results = engine.search("Simon Kim")
context = results.to_agent_context(max_tokens=500)
```

#### 단점 5-2: 에러 처리 체계 부재

에러 시 `print("Error: ...")` + `return None`. exit code 항상 0.

**개선 방향:**

```python
# 명시적 예외 계층
class MemoryError(Exception): ...
class EntityNotFoundError(MemoryError): ...
class StorageError(MemoryError): ...
class ValidationError(MemoryError): ...
class ConflictError(MemoryError): ...

# CLI에서만 예외를 잡아 사용자 친화적 메시지로 변환
def main():
    try:
        result = engine.search(args.query)
        print(result.to_markdown())
    except EntityNotFoundError as e:
        print(f"Entity not found: {e}", file=sys.stderr)
        sys.exit(1)
    except StorageError as e:
        print(f"Storage error: {e}", file=sys.stderr)
        sys.exit(2)
```

#### 단점 5-3: 설정(Configuration) 시스템 없음

모든 값이 하드코딩: 300 bytes, 4000 bytes, 48시간, 0.85 유사도 등.

**개선 방향:**

```python
@dataclass
class MemoryConfig:
    # 스토리지
    base_dir: Path = Path("./memory")
    storage_backend: str = "markdown"  # "markdown" | "sqlite" | "json"
    
    # 검색
    search_backend: str = "bm25"  # "bm25" | "semantic" | "hybrid"
    max_search_results: int = 20
    default_token_budget: int = 500
    fuzzy_threshold: float = 0.3
    
    # 추출
    extractor_backend: str = "regex"  # "regex" | "llm"
    llm_provider: Optional[str] = None  # "anthropic" | "openai"
    
    # 품질
    min_confidence: float = 0.5
    conflict_resolution: str = "flag"  # "flag" | "auto" | "reject"
    
    # 유지보수
    thin_page_threshold: int = 300
    bloat_page_threshold: int = 4000
    inbox_overdue_hours: int = 48
    decay_days: int = 90
    dedup_similarity: float = 0.85
    
    @classmethod
    def from_file(cls, path: Path) -> "MemoryConfig":
        """memory.toml 또는 memory.yaml에서 로드"""
        ...
```

---

### 관점 6. 세션 & 대화 연속성

#### 단점 6-1: 세션 개념이 없다

일(day) 단위 JSONL 파일만 있고, 대화 ID가 없다.

**개선 방향 — 세션 모델:**

```python
@dataclass
class Session:
    session_id: str          # uuid4
    started_at: datetime
    ended_at: Optional[datetime]
    agent_id: str            # 어떤 에이전트의 세션인지
    parent_session: Optional[str]  # 이전 세션 연결
    
    entities_accessed: list[str]   # 이 세션에서 조회한 엔티티
    entities_modified: list[str]   # 이 세션에서 수정한 엔티티
    facts_added: list[str]         # 이 세션에서 추가한 사실
    
    summary: Optional[str]         # 세션 종료 시 자동 요약

class SessionManager:
    def start_session(self, agent_id: str) -> Session:
        """새 세션 시작. 이전 세션 자동 연결."""
        last = self._get_last_session(agent_id)
        session = Session(
            session_id=str(uuid4()),
            started_at=datetime.now(),
            agent_id=agent_id,
            parent_session=last.session_id if last else None,
        )
        return session
    
    def end_session(self, session: Session):
        """세션 종료. 변경 사항 요약 생성."""
        session.ended_at = datetime.now()
        session.summary = self._generate_summary(session)
        self._save(session)
    
    def get_session_diff(self, session_id: str) -> SessionDiff:
        """이전 세션과의 차이점 반환"""
        ...
    
    def get_context_carryover(self, agent_id: str) -> str:
        """다음 세션에 주입할 컨텍스트 생성"""
        last = self._get_last_session(agent_id)
        return f"""
        Last session: {last.summary}
        Entities discussed: {', '.join(last.entities_accessed)}
        Changes made: {', '.join(last.entities_modified)}
        """
```

#### 단점 6-2: 대화 간 컨텍스트 전달 없음

"아까 얘기한 그 사람"을 추적할 수 없다.

**개선 방향 — Working Memory (작업 메모리):**

```python
class WorkingMemory:
    """현재 세션의 단기 기억 — 대화 중 활성 컨텍스트"""
    
    def __init__(self, session: Session):
        self.session = session
        self.active_entities: list[str] = []  # 현재 대화에서 언급된 엔티티
        self.recent_queries: list[str] = []   # 최근 검색어
        self.context_stack: list[str] = []    # 대화 주제 스택
    
    def touch(self, entity: str):
        """엔티티가 언급되면 활성 목록에 추가"""
        if entity not in self.active_entities:
            self.active_entities.append(entity)
    
    def resolve_reference(self, text: str) -> Optional[str]:
        """'그 사람', '아까 그 회사' 같은 참조 해결"""
        if "그 사람" in text and self._last_person():
            return self._last_person()
        if "그 회사" in text and self._last_org():
            return self._last_org()
        return None
    
    def get_active_context(self, max_tokens: int = 300) -> str:
        """현재 대화 컨텍스트 요약 반환"""
        ...
```

---

### 관점 7. 보안 & 프라이버시

#### 단점 7-1: Path Traversal 취약점

`memkraft extract "/etc/passwd"` → 시스템 파일 읽기 가능.

**개선 방향:**

```python
def _validate_input(self, input_text: str) -> str:
    """입력이 파일 경로인 경우 안전성 검증"""
    path = Path(input_text).resolve()
    base = self.base_dir.resolve()
    
    # base_dir 외부 파일 접근 차단
    if not str(path).startswith(str(base)):
        raise SecurityError(f"Access denied: {path} is outside memory directory")
    
    # 민감 파일 패턴 차단
    sensitive = ['.ssh', '.env', 'passwd', 'shadow', 'credentials']
    if any(s in str(path).lower() for s in sensitive):
        raise SecurityError(f"Access denied: sensitive file pattern detected")
    
    return path.read_text()
```

#### 단점 7-2: 메모리에 민감 정보 무방비 저장

에이전트가 신용카드 번호, 비밀번호, API 키를 `extract`하면 그대로 Markdown에 저장.

**개선 방향 — PII 탐지 & 마스킹:**

```python
class PIIDetector:
    PATTERNS = {
        "credit_card": r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b',
        "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
        "api_key": r'\b(sk-|ak-|AKIA)[A-Za-z0-9]{20,}\b',
        "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "phone": r'\b\d{2,3}-\d{3,4}-\d{4}\b',
    }
    
    def scan(self, text: str) -> list[PIIMatch]:
        matches = []
        for pii_type, pattern in self.PATTERNS.items():
            for m in re.finditer(pattern, text):
                matches.append(PIIMatch(type=pii_type, span=m.span()))
        return matches
    
    def mask(self, text: str) -> str:
        """민감 정보를 마스킹하여 반환"""
        for match in self.scan(text):
            text = text[:match.start] + "[REDACTED]" + text[match.end:]
        return text
```

#### 단점 7-3: 접근 제어 없음

모든 데이터가 파일 시스템 권한에만 의존.

**개선 방향:**
- 엔티티별 접근 수준: `public`, `internal`, `confidential`
- 에이전트별 권한: 어떤 에이전트가 어떤 티어까지 접근 가능한지
- 감사 로그: 누가 언제 무엇을 읽고/썼는지

---

### 관점 8. 실세계 사용 패턴

#### 단점 8-1: 멀티 에이전트 시나리오 미지원

현실에서 여러 에이전트가 같은 메모리를 공유하는 경우가 흔하다 (리서치 에이전트 + 코딩 에이전트 + 분석 에이전트).

**개선 방향:**

```python
class SharedMemory:
    """여러 에이전트가 공유하는 메모리 공간"""
    
    def read(self, query: str, agent_id: str) -> list[MemoryEntry]:
        """읽기는 동시 접근 허용"""
        results = self.search(query)
        self.audit_log.record(agent_id, "read", query)
        return results
    
    def write(self, fact: Fact, agent_id: str) -> WriteResult:
        """쓰기는 락 기반 동시성 제어"""
        with self.lock(fact.entity):
            existing = self.get_entity(fact.entity)
            validation = self.quality_gate.validate(fact, existing)
            if validation.action == "accept":
                self._write(fact)
                self.audit_log.record(agent_id, "write", fact)
                self._notify_subscribers(fact)  # 다른 에이전트에 알림
                return WriteResult(success=True)
            return WriteResult(success=False, reason=validation.reason)
```

#### 단점 8-2: 메모리 크기 증가에 대한 전략 없음

시간이 지나면 메모리가 끝없이 커진다. 어떤 정보를 유지하고 어떤 정보를 정리할지 전략이 없다.

**개선 방향 — 메모리 생애주기 관리:**

```
신규 정보
    │
    ├── Working Memory (세션 내 단기)
    │   └── 세션 종료 시 → 중요도 평가
    │       ├── 중요 → Long-term Memory로 승격
    │       └── 사소 → 폐기
    │
    ├── Long-term Memory (장기 저장)
    │   ├── core (핵심, 절대 삭제 안 함)
    │   ├── recall (활성, 주기적 접근)
    │   └── archival (비활성, 장기 미접근)
    │       └── 1년 미접근 → 압축 요약 후 원본 삭제
    │
    └── Compressed Memory (요약된 과거)
        └── "2024년 Q1-Q2: Simon Kim과 3회 미팅, 주로 펀드 관련 논의"
```

```python
class MemoryLifecycle:
    def compact(self, entity: str, older_than: timedelta):
        """오래된 Timeline 항목들을 요약하여 압축"""
        entries = self.get_timeline(entity, before=datetime.now() - older_than)
        if len(entries) > 10:
            summary = self.summarizer.summarize(entries)  # LLM 또는 규칙 기반
            self.replace_entries(entity, entries, summary)
    
    def compute_importance(self, entity: str) -> float:
        """엔티티의 중요도 계산"""
        access_frequency = self.get_access_count(entity, days=30)
        link_count = len(self.get_backlinks(entity))
        recency = self.days_since_last_update(entity)
        
        return (access_frequency * 0.4 + link_count * 0.3 + 
                (1 / max(recency, 1)) * 0.3)
```

#### 단점 8-3: 피드백 루프 (메모리 자기 개선) 없음

에이전트가 검색 결과를 실제로 유용하게 사용했는지 추적하지 않는다.

**개선 방향 — 암묵적 피드백 수집:**

```python
class RelevanceFeedback:
    def record_search(self, query: str, results: list[MemoryEntry]):
        """검색 실행 기록"""
        self.pending_feedback[query] = results
    
    def record_usage(self, entity: str, context: str):
        """에이전트가 실제로 메모리 내용을 응답에 사용한 경우"""
        # 이 엔티티의 relevance 점수 상승
        self.boost_relevance(entity)
    
    def record_ignore(self, query: str):
        """검색 결과를 반환했지만 에이전트가 사용하지 않은 경우"""
        # 이 검색 결과들의 relevance 점수 하락
        for result in self.pending_feedback.get(query, []):
            self.decay_relevance(result.entity)
```

---

## Part 2: 구현 우선순위 제안

비슷한 시스템을 처음부터 만든다면, 다음 순서를 권장한다:

### Phase 1: 핵심 (MVP)
> 목표: 에이전트가 실제로 사용할 수 있는 최소 메모리 시스템

| 항목 | 설명 | 기술 선택 |
|------|------|-----------|
| 스토리지 | SQLite + FTS5 전문 검색 | `sqlite3` (표준 라이브러리) |
| 검색 | FTS5 기반 키워드 검색 | 제로 디펜던시 유지 |
| 구조화된 I/O | Pydantic 모델 또는 dataclass | 타입 안전한 입출력 |
| 품질 게이트 | 신뢰도 점수 + 충돌 검사 | 규칙 기반 |
| 세션 관리 | 세션 ID + 대화 연결 | UUID 기반 |
| 통합 | MCP 서버 1개 | Claude Code에서 바로 사용 |
| CLI | 사람용 인터페이스 | argparse |
| 원자적 쓰기 | 임시 파일 + rename + 파일 락 | `fcntl` |

### Phase 2: 지능 (Smart Layer)
> 목표: LLM을 활용한 추출/검색 품질 향상

| 항목 | 설명 |
|------|------|
| LLM 추출기 | 정규식 → LLM 플러그인으로 교체 가능 |
| 시맨틱 검색 | 임베딩 기반 검색 추가 (하이브리드) |
| 자동 요약 | 세션 종료 시 LLM 요약 |
| 시스템 프롬프트 생성 | 세션 시작 시 컨텍스트 자동 주입 |
| 토큰 예산 관리 | 검색 결과를 토큰 예산 내로 압축 |

### Phase 3: 확장 (Scale)
> 목표: 프로덕션 환경, 멀티 에이전트

| 항목 | 설명 |
|------|------|
| 멀티 에이전트 | 공유 메모리 + 접근 제어 |
| 벡터 DB | 대규모 시맨틱 검색 |
| REST API | 원격 접근 |
| 메모리 생애주기 | 자동 압축, 만료, 승격/강등 |
| 감사 로그 | 접근 기록 |
| PII 보호 | 민감 정보 탐지/마스킹 |
| 피드백 루프 | 검색 품질 자기 개선 |

---

## Part 3: 핵심 설계 원칙 요약

1. **"LLM-Optional"**: 기본은 제로 디펜던시로 동작, LLM은 품질 향상 플러그인
2. **"에이전트 퍼스트"**: 사람용 CLI는 부가 기능, 핵심은 프로그래밍 인터페이스 (MCP/SDK)
3. **"쓰기보다 읽기 최적화"**: 메모리는 쓰기보다 읽기가 훨씬 많음 → 인덱싱 투자
4. **"신뢰도 추적"**: 모든 사실에 신뢰도 점수, 모든 출처에 유형 분류
5. **"세션 연속성"**: 대화 간 컨텍스트가 자연스럽게 이어지는 것이 핵심 가치
6. **"방어적 쓰기"**: 환각, 충돌, PII를 차단하는 품질 게이트
7. **"토큰 인식"**: 검색 결과가 에이전트의 컨텍스트 윈도우를 존중
8. **"인터페이스 추상화"**: 스토리지/검색/추출을 교체 가능한 모듈로 설계
