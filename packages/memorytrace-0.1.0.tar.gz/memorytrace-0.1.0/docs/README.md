# Engram 문서

> GitHub: [aop60003/default](https://github.com/aop60003/default)

---

## 사용 가이드

| 문서 | 설명 |
|------|------|
| [Quickstart](./04-usage-guide/01-quickstart.md) | 설치, 터미널 사용법, SDK, CLI 전체 가이드 |
| [Claude Code 설정](./04-usage-guide/02-claude-code-setup.md) | 슬래시 명령어 등록 + 사용 방법 |

## MemKraft 분석 (Engram 개발 배경)

### 1. 프로젝트 분석

| 문서 | 설명 |
|------|------|
| [01-overview.md](./01-project-analysis/01-overview.md) | 프로젝트 개요 및 핵심 컨셉 |
| [02-tech-stack.md](./01-project-analysis/02-tech-stack.md) | 기술 스택 및 의존성 |
| [03-architecture.md](./01-project-analysis/03-architecture.md) | 아키텍처 및 데이터 흐름 |
| [04-directory-structure.md](./01-project-analysis/04-directory-structure.md) | 디렉토리 구조 및 주요 파일 |
| [05-cli-commands.md](./01-project-analysis/05-cli-commands.md) | CLI 명령어 레퍼런스 |
| [06-core-features.md](./01-project-analysis/06-core-features.md) | 핵심 기능 상세 분석 |
| [07-storage-model.md](./01-project-analysis/07-storage-model.md) | 스토리지 모델 및 데이터 스키마 |
| [08-design-decisions.md](./01-project-analysis/08-design-decisions.md) | 설계 결정 및 경쟁사 비교 |
| [09-setup-guide.md](./01-project-analysis/09-setup-guide.md) | 설치 및 실행 가이드 |

### 2. 문제점 분석

| 문서 | 설명 |
|------|------|
| [10-problem-analysis.md](./02-problem-analysis/10-problem-analysis.md) | 코드/버그/보안/테스트 문제점 |
| [11-agent-memory-critique.md](./02-problem-analysis/11-agent-memory-critique.md) | AI 에이전트 메모리 근본적 한계 |
| [13-markdown-storage-problems.md](./02-problem-analysis/13-markdown-storage-problems.md) | Markdown 저장소 14가지 문제점 |

### 3. 개선 청사진

| 문서 | 설명 |
|------|------|
| [12-improvements-blueprint.md](./03-improvement-plan/12-improvements-blueprint.md) | 8가지 관점 분석 + 구현 로드맵 |
