# Claude Code에서 Engram 설정하기

## 1단계: 설치

```bash
git clone https://github.com/aop60003/default.git ~/engram
cd ~/engram
pip install -e .
```

## 2단계: 초기화

```bash
python3 ~/engram/mem status
```

처음 실행하면 `~/.engram/memory.db`가 자동 생성됨.

## 3단계: 슬래시 명령어 등록

아래 파일들을 `~/.claude/commands/` 폴더에 생성:

### `~/.claude/commands/memory-save.md`

```markdown
Save information to Engram persistent memory.

Run this command:
\```bash
python3 ~/engram/mem save "$ARGUMENTS"
\```

After running, tell the user what entities and facts were saved.
```

### `~/.claude/commands/memory-find.md`

```markdown
Search Engram memory for relevant information.

Run this command:
\```bash
python3 ~/engram/mem find "$ARGUMENTS"
\```

Present the search results clearly.
```

### `~/.claude/commands/memory-who.md`

```markdown
Look up everything known about a person or organization.

Run this command:
\```bash
python3 ~/engram/mem who "$ARGUMENTS"
\```

Present the entity details and facts.
```

### `~/.claude/commands/memory-remember.md`

```markdown
Manually remember a fact about someone. Format: "Name" fact

Run this command:
\```bash
python3 ~/engram/mem remember $ARGUMENTS
\```

Confirm what was remembered.
```

### `~/.claude/commands/memory-status.md`

```markdown
Check Engram memory status.

Run these commands:
\```bash
python3 ~/engram/mem status
echo "---"
python3 ~/engram/mem all
\```
```

### `~/.claude/commands/memory-forget.md`

```markdown
Remove an entity from memory.

Run this command:
\```bash
python3 ~/engram/mem forget "$ARGUMENTS"
\```
```

### `~/.claude/commands/memory-context.md`

```markdown
Load previous conversation context from Engram memory.

Run this command:
\```bash
python3 -c "
from pathlib import Path
from engram.config import EngramConfig
from engram.engine import MemoryEngine
import json
engine = MemoryEngine(EngramConfig(base_dir=Path.home() / '.engram'))
ctx = engine.get_session_context('claude-code')
print(json.dumps(ctx, ensure_ascii=False, indent=2))
engine.close()
"
\```

Use the context to inform the current conversation.
```

## 4단계: 사용

Claude Code에서 `/`를 입력하면 메모리 명령어가 나타남:

```
/memory-save Minseong Jeong is the Space King of Galaxy Corp
/memory-find Space King
/memory-who Minseong Jeong
/memory-remember "Minseong Jeong" "Loves AI and space exploration"
/memory-status
/memory-context
```

## 활용 팁

### 대화 시작 시

```
/memory-context
```

이전 대화에서 논의한 엔티티와 사실이 로드됨.

### 중요한 정보가 나왔을 때

```
/memory-save 대화에서 나온 중요한 정보를 여기에 입력
```

### 특정 사람/조직 정보가 필요할 때

```
/memory-who 이름
/memory-find 검색어
```

### NER이 자동 추출 못하는 정보 (한국어 이름, 맥락 의존 정보)

```
/memory-remember "정민성" "2024년에 Galaxy Corp을 창립했다"
```
