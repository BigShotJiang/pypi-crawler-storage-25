# Engram 사용 가이드

## 설치

```bash
# 프로젝트 클론
git clone https://github.com/aop60003/default.git
cd default

# 설치 (Python 3.9+)
pip install -e .

# 메모리 DB 초기화
python3 mem status
```

---

## 1. 터미널에서 사용 (mem 스크립트)

가장 간단한 방법. 모든 명령어는 `python3 mem` 으로 시작.

### 정보 저장

```bash
python3 mem save "Minseong Jeong is the Space King of the Galaxy Corp."
# → New: Minseong Jeong
# → Learned 1 fact(s)

python3 mem save "Galaxy Corp is a space exploration company based in Seoul."
# → New: Galaxy Corp
# → Learned 1 fact(s)

python3 mem save "정민성은 서울대학교를 졸업했다."
# → New: 정민성, 서울대학교
```

### 검색

```bash
python3 mem find "Space King"
# → Minseong Jeong (person)
#     - Minseong Jeong is the Space King of the Galaxy Corp.

python3 mem find "Seoul"
# → Galaxy Corp (organization)
#     - Galaxy Corp is a space exploration company based in Seoul.
```

### 엔티티 조회

```bash
python3 mem who "Minseong Jeong"
# → Minseong Jeong [person]
#   Role: Space King of the Galaxy Corp
#   Facts (1):
#     - Minseong Jeong is the Space King of the Galaxy Corp.
```

### 수동 기억 추가

```bash
python3 mem remember "Minseong Jeong" "AI와 우주 탐사에 관심이 많다"
# → Remembered: accept (90%)

python3 mem remember "Minseong Jeong" "Engram 메모리 시스템을 개발했다"
# → Remembered: accept (90%)
```

### 전체 목록

```bash
python3 mem all
# → 3 entities:
#     Minseong Jeong (person) — ...
#     Galaxy Corp (organization) — ...
#     서울대학교 (organization) — ...
```

### 상태 확인

```bash
python3 mem status
# → Entities: 3
# → Facts: 4
# → Conflicts: 0
# → Status: healthy
```

### 삭제

```bash
python3 mem forget "임시 엔티티"
# → Forgot 임시 엔티티
```

---

## 2. Claude Code 슬래시 명령어

Claude Code에서 `/` 를 입력하면 Engram 메모리 명령어가 나타남.

| 명령어 | 기능 | 사용 예시 |
|--------|------|-----------|
| `/memory-save` | 정보 저장 | `/memory-save Minseong Jeong is the Space King of Galaxy Corp` |
| `/memory-find` | 검색 | `/memory-find Space King` |
| `/memory-who` | 엔티티 조회 | `/memory-who Minseong Jeong` |
| `/memory-remember` | 수동 기억 | `/memory-remember "Minseong Jeong" "AI 전문가"` |
| `/memory-status` | 상태 확인 | `/memory-status` |
| `/memory-forget` | 삭제 | `/memory-forget 임시 테스트` |
| `/memory-context` | 이전 대화 컨텍스트 로드 | `/memory-context` |

### 실제 사용 시나리오

**대화 1: 새로운 사람을 만났을 때**

```
사용자: 오늘 Minseong Jeong이라는 사람을 만났어. Galaxy Corp의 창립자래.
→ /memory-save Minseong Jeong is the founder of Galaxy Corp. He is interested in space exploration and AI.
```

**대화 2: 며칠 후 추가 정보**

```
사용자: Minseong Jeong이 $500M 투자 유치했다고 하더라
→ /memory-remember "Minseong Jeong" "Raised $500M funding for Galaxy Corp"
```

**대화 3: 나중에 기억이 필요할 때**

```
사용자: 그 우주 관련 회사 대표가 누구였지?
→ /memory-find 우주
→ /memory-who Minseong Jeong
```

---

## 3. Python SDK

프로그래밍 방식으로 사용할 때.

```python
from engram.integrations.sdk import EngramSDK

with EngramSDK() as sdk:
    # 세션 시작
    sdk.start_session("my-app")

    # 저장
    sdk.store("Minseong Jeong is the Space King of Galaxy Corp.")
    sdk.remember("Minseong Jeong", "Loves Python and AI")

    # 검색
    result = sdk.search("Space King")
    print(result.to_agent_context())
    # → [Minseong Jeong] (person) Role: Space King of Galaxy Corp

    # 엔티티 조회
    entity = sdk.get_entity("Minseong Jeong")
    facts = sdk.get_facts("Minseong Jeong")

    # 세션 종료 (자동 요약 생성)
    sdk.end_session("Discussed Minseong Jeong's role at Galaxy Corp")
```

### 세션 간 학습 흐름

```python
from pathlib import Path
from engram.config import EngramConfig
from engram.engine import MemoryEngine

engine = MemoryEngine(EngramConfig(base_dir=Path.home() / ".engram"))

# ── 세션 1: 첫 만남 ──
s1 = engine.start_session("claude-code")
engine.store("Minseong Jeong is the Space King of Galaxy Corp.", 
             session_id=s1.session_id)
engine.end_session(s1.session_id, summary="Met Minseong Jeong, Space King")

# ── 세션 2: 다음 날 ──
# 이전 대화 컨텍스트 자동 로드
context = engine.get_session_context("claude-code")
print(context["previous_summary"])
# → "Met Minseong Jeong, Space King"
print(context["key_facts"])
# → [{"entity": "Minseong Jeong", "fact": "Space King of Galaxy Corp"}]

s2 = engine.start_session("claude-code")
engine.store("Minseong Jeong raised $500M for Galaxy Corp.", 
             session_id=s2.session_id)
engine.end_session(s2.session_id)
# → 자동 요약: "Modified: Minseong Jeong. 1 facts added"

engine.close()
```

---

## 4. CLI (상세 제어)

전체 옵션이 필요할 때.

```bash
DB=~/.engram/memory.db
CMD="python3 -m engram.cli.app --db $DB"

# 초기화
$CMD init

# 저장 (출처/신뢰도 지정)
$CMD store "Minseong Jeong is the Space King." --source-type document --confidence 0.95

# JSON 출력 검색
$CMD --json search "Space King" --max-results 5 --min-confidence 0.5

# 엔티티 수동 생성 (타입/티어/요약 지정)
$CMD create "Galaxy Corp" --type organization --tier core --summary "Space exploration company"

# 사실 추가 (predicate 지정)
$CMD add-fact "Minseong Jeong" "Founded Galaxy Corp in 2024" --predicate action

# 충돌 확인 및 해결
$CMD conflicts
$CMD resolve <conflict_id> accept_new

# Markdown 내보내기
$CMD export

# 건강 체크
$CMD --json health

# 검색 인덱스 재빌드
$CMD reindex
```

---

## 핵심 개념

### 자동으로 하는 것

| 기능 | 설명 |
|------|------|
| NER (개체명 인식) | 텍스트에서 인물/조직 자동 추출 |
| 사실 추출 | "X is the Y of Z" 패턴에서 사실 추출 |
| PII 마스킹 | 전화번호, 카드번호, 이메일 등 자동 [REDACTED] |
| 중복 제거 | 동일한 사실 재저장 시 자동 거부 |
| 충돌 감지 | "CEO" → "CTO" 같은 모순 자동 감지 |
| 세션 요약 | 세션 종료 시 자동 요약 생성 |
| 엔티티 state 동기화 | "role", "location" 등 자동 업데이트 |

### 수동으로 하면 좋은 것

| 기능 | 방법 |
|------|------|
| 한국어 이름 엔티티 생성 | `mem remember "정민성" "사실"` |
| 엔티티 별칭 연결 | SDK에서 `engine.merge_entities("Minseong Jeong", "정민성")` |
| 충돌 해결 | `mem` 스크립트 또는 CLI |
| 메모리 정리 | SDK에서 `engine.maintenance()` |

### 데이터 저장 위치

```
~/.engram/
├── memory.db          ← SQLite 데이터베이스 (핵심)
├── memory.db-wal      ← WAL 로그 (자동 생성)
└── readable/          ← Markdown 내보내기 (사람 열람용)
    ├── minseong-jeong.md
    ├── galaxy-corp.md
    └── ...
```
