# 5. CLI 명령어 레퍼런스

## 설치 및 실행

```bash
# 설치
pipx install memkraft

# 또는 개발용
git clone https://github.com/seojoonkim/memkraft.git
cd memkraft && pip install -e .
```

## 명령어 분류

### 초기화

| 명령어 | 설명 | 예시 |
|--------|------|------|
| `init` | 메모리 디렉토리 구조 초기화 | `memkraft init` |

### 엔티티 관리 (Core Operations)

| 명령어 | 설명 | 예시 |
|--------|------|------|
| `track <name>` | 엔티티 모니터링 시작 | `memkraft track "Simon Kim" --type person --source "meeting"` |
| `update <name>` | 엔티티에 정보 추가 | `memkraft update "Simon Kim" --info "CEO of Hashed" --source "news"` |
| `list` | 추적 중인 모든 엔티티 표시 | `memkraft list` |
| `promote <name>` | 메모리 티어 변경 | `memkraft promote "Simon Kim" --tier core` |

### 추출 및 탐지 (Extraction & Detection)

| 명령어 | 설명 | 예시 |
|--------|------|------|
| `extract <text>` | 텍스트에서 엔티티/사실 자동 추출 | `memkraft extract "Simon Kim is CEO of Hashed"` |
| `detect <text>` | 엔티티 탐지 (파일 미생성) | `memkraft detect "Simon Kim met with Vitalik"` |
| `extract-facts <text>` | 숫자/날짜 사실을 팩트 레지스트리에 추가 | `memkraft extract-facts "Revenue grew 40% in Q3"` |
| `cognify` | inbox 항목을 구조화된 페이지로 처리 | `memkraft cognify` / `memkraft cognify --apply` |

### 검색 및 조회 (Search & Retrieval)

| 명령어 | 설명 | 예시 |
|--------|------|------|
| `lookup <query>` | 브레인 우선 검색 | `memkraft lookup "Hashed fund"` |
| `search <query>` | 퍼지 매칭 검색 | `memkraft search "Hashed fund"` |
| `query <query>` | 점진적 공개 검색 (3단계 깊이) | `memkraft query "Simon Kim" --level 2` |
| `agentic-search <query>` | 멀티홉 분해 검색 | `memkraft agentic-search "What is Simon Kim building?"` |

**Query 깊이 레벨:**
- `--level 1`: 간략 요약 (토큰 절약)
- `--level 2`: 중간 수준 상세
- `--level 3`: 전체 컨텍스트

### 분석 및 성찰 (Analysis & Reflection)

| 명령어 | 설명 | 예시 |
|--------|------|------|
| `brief <name>` | 미팅 준비 브리핑 생성 | `memkraft brief "Simon Kim"` |
| `log <event>` | 세션 이벤트 기록 | `memkraft log "discussed partnership" --tags "meeting,partnership"` |
| `retro` | 일일 회고 생성 | `memkraft retro` |
| `distill-decisions` | 의사결정 후보 식별 | `memkraft distill-decisions` |
| `open-loops` | 미해결 항목 추적 | `memkraft open-loops` |

### 유지보수 (Maintenance)

| 명령어 | 설명 | 예시 |
|--------|------|------|
| `dream` | 야간 건강 검사 실행 (7개 체크) | `memkraft dream` |
| `decay` | 오래된 사실 플래그 | `memkraft decay --days 90` |
| `dedup` | 중복 엔티티 탐지 및 병합 제안 | `memkraft dedup` |
| `index` | 검색 가능한 메모리 인덱스 빌드 | `memkraft index` |
| `diff` | 마지막 유지보수 이후 변경사항 표시 | `memkraft diff` |

### 조직 (Organization)

| 명령어 | 설명 | 예시 |
|--------|------|------|
| `links <name>` | 엔티티에 대한 백링크 표시 | `memkraft links "Simon Kim"` |
| `suggest-links` | 누락된 위키링크 추천 | `memkraft suggest-links` |
| `summarize` | 엔티티 요약 생성 | `memkraft summarize` |

## 환경 변수

| 변수 | 설명 | 기본값 |
|------|------|--------|
| `MEMKRAFT_DIR` | 메모리 디렉토리 경로 | `./memory/` |

## 주요 플래그

- `--apply`: 실제 변경 실행 (cognify 등에서 사용, 기본: 권고만 출력)
- `--source`: 출처 정보 지정
- `--type`: 엔티티 유형 (person, organization 등)
- `--tier`: 메모리 티어 (core, recall, archival)
- `--level`: 쿼리 깊이 (1, 2, 3)
- `--days`: 기간 설정 (decay 등에서 사용)
