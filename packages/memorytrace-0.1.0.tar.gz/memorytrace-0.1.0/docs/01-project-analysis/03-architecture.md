# 3. 아키텍처 및 데이터 흐름

## 전체 아키텍처

MemKraft는 **파일 기반 지식 그래프** 패턴을 따른다. 모든 데이터는 로컬 파일 시스템의 Markdown 파일로 저장되며, `[[wiki-links]]`를 통해 엔티티 간 관계를 표현한다.

```
┌─────────────────────────────────────────────────────────────┐
│                        CLI Layer                            │
│                     (cli.py - argparse)                      │
├─────────────────────────────────────────────────────────────┤
│                      Core Engine                            │
│                  (core.py - MemKraft 클래스)                  │
│                                                             │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐      │
│  │ Entity   │ │ Search   │ │ Dream    │ │ Cognify  │      │
│  │ Manager  │ │ Engine   │ │ Cycle    │ │ Pipeline │      │
│  ├──────────┤ ├──────────┤ ├──────────┤ ├──────────┤      │
│  │ track    │ │ BM25+IDF │ │ 7 health │ │ inbox    │      │
│  │ update   │ │ fuzzy    │ │ checks   │ │ classify │      │
│  │ extract  │ │ agentic  │ │ scoring  │ │ route    │      │
│  │ detect   │ │ multi-hop│ │ decay    │ │ apply    │      │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘      │
├─────────────────────────────────────────────────────────────┤
│                   File System Storage                       │
│                                                             │
│  memory/                                                    │
│  ├── entities/     (엔티티 페이지)                            │
│  ├── live-notes/   (실시간 추적)                              │
│  ├── decisions/    (의사결정 기록)                             │
│  ├── originals/    (독창적 사고)                              │
│  ├── inbox/        (미분류 항목)                              │
│  ├── tasks/        (작업 추적)                               │
│  ├── meetings/     (미팅 브리프)                              │
│  └── sessions/     (세션 로그 - JSONL)                       │
└─────────────────────────────────────────────────────────────┘
```

## 데이터 흐름

### 1. 초기화 (Init)

```
memkraft init
    │
    ├── memory/ 디렉토리 생성
    ├── 8개 하위 디렉토리 생성
    ├── RESOLVER.md 복사 (분류 결정 트리)
    └── TEMPLATES.md 복사 (페이지 템플릿)
```

### 2. 데이터 수집 (Ingestion)

두 가지 경로로 데이터가 유입된다:

**수동 경로:**
```
memkraft track "Simon Kim"
    → live-notes/simon-kim.md 생성 (slug 변환)
    → 템플릿 기반 초기 구조 작성

memkraft update "Simon Kim" --info "CEO of Hashed"
    → 기존 파일에 정보 추가
    → 상태 변화 감지 (role/affiliation 등)
    → Timeline에 출처 태깅된 엔트리 추가
```

**자동 경로:**
```
memkraft extract "Simon Kim is CEO of Hashed. They launched a new fund."
    │
    ├── 정규식 NER로 엔티티 탐지
    │   ├── Person: "Simon Kim"
    │   └── Organization: "Hashed"
    │
    ├── 각 엔티티별 페이지 생성/업데이트
    └── 사실 추출 및 Timeline에 기록
```

### 3. 검색 파이프라인 (Search)

**기본 검색 (`search`):**
```
쿼리 입력
    │
    ├── 토큰화 + 불용어 제거 (stopwords.json)
    ├── 전체 .md 파일 스캔
    ├── IDF 가중치 BM25 스코어 계산
    ├── 보너스 적용:
    │   ├── 구문 매칭 (연속 바이그램)
    │   ├── 헤딩 매칭
    │   └── 최신성 (파일 수정 시간)
    ├── (옵션) SequenceMatcher 퍼지 매칭
    └── 랭킹된 결과 + 컨텍스트 스니펫 반환
```

**에이전틱 검색 (`agentic_search`):**
```
복잡한 쿼리 입력
    │
    ├── 서브 쿼리로 분해
    ├── 각 서브 쿼리별 기본 검색 실행
    ├── [[wiki-links]] 백링크 탐색 (멀티홉)
    │   └── 설정 가능한 최대 홉 수
    ├── 재랭킹:
    │   ├── 관련성
    │   ├── 메모리 티어 (core > recall > archival)
    │   └── 최신성
    └── 충분성 임계값 판단 → 확장 여부 결정
```

### 4. Dream Cycle (유지보수)

```
memkraft dream
    │
    ├── 7가지 건강 검사:
    │   ├── 1. 불완전한 출처 표기
    │   ├── 2. 빈약한 엔티티 페이지 (< 300 bytes)
    │   ├── 3. 중복 엔티티 (정규화된 slug 비교)
    │   ├── 4. 오래된 inbox 항목 (> 48시간)
    │   ├── 5. 비대한 페이지 (> 4KB) + 압축 제안
    │   ├── 6. Key Points의 출처 없는 사실
    │   └── 7. 전체 건강도 점수 산출
    │
    └── 리포트 출력 (기본: 권고 모드)
```

### 5. Cognify 파이프라인

```
memkraft cognify
    │
    ├── inbox/ 항목 스캔
    ├── 휴리스틱 분류:
    │   ├── "decision" 키워드 → decisions/
    │   ├── "task" 키워드 → tasks/
    │   ├── 인물 관련 → entities/
    │   └── 기타 → 분류 불가 (수동 처리 권고)
    │
    └── --apply 플래그 시 실제 이동 실행
        (기본: 권고만 출력)
```

## 메모리 계층 (Memory Tiers)

각 엔티티 페이지는 3개 티어 중 하나에 속한다:

| 티어 | 설명 | 검색 가중치 |
|------|------|------------|
| **Core** | 핵심 인물/조직, 자주 참조 | 가장 높음 |
| **Recall** | 활발히 사용되는 정보 | 중간 |
| **Archival** | 과거 기록, 비활성 | 가장 낮음 |

`memkraft promote <name> --tier core` 명령으로 티어를 변경할 수 있다.

## 세션 로깅

```json
// sessions/YYYY-MM-DD.jsonl
{
  "timestamp": "2026-04-12T10:30:00",
  "event": "entity_updated",
  "entity": "simon-kim",
  "tags": ["person", "ceo"],
  "importance": "high",
  "cross_refs": ["hashed", "fund-launch"]
}
```

JSONL 형식으로 세션별 이벤트를 기록하며, 추후 회고(`retro`) 및 분석에 활용된다.
