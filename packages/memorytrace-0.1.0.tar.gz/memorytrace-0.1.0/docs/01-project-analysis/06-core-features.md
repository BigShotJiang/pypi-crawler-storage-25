# 6. 핵심 기능 상세 분석

## 1. 다국어 개체명 인식 (NER)

MemKraft는 외부 NLP 라이브러리 없이 정규식만으로 다국어 NER을 구현한다. `_detect_regex()` 메서드가 담당한다.

### 지원 엔티티 유형

| 유형 | 탐지 방식 | 예시 |
|------|-----------|------|
| **인물 (Person)** | 대문자 시작 영어 이름, 한국어 2~4음절, 중국어/일본어 CJK 이름 | "Simon Kim", "김서준", "田中太郎" |
| **조직 (Organization)** | 법인 접미사 패턴 (Inc., Corp., Ltd., GmbH 등), 한국 기업명 | "Hashed Inc.", "삼성전자" |
| **제품 (Product)** | 버전 번호가 포함된 제품명 | "GPT-5", "iPhone 16 Pro" |
| **장소 (Location)** | 주요 도시 및 지역명 사전 | "Seoul", "San Francisco" |
| **연락처 (Contact)** | 이메일 주소, URL 패턴 | "user@example.com" |

### 특징
- 영어, 한국어, 중국어, 일본어 4개 언어 지원
- 별도 모델 다운로드 불필요
- 정확도는 ML 기반보다 낮지만, 의존성 제로라는 트레이드오프

---

## 2. 검색 엔진

### 기본 검색 (BM25 + IDF)

전통적인 정보 검색 알고리즘을 Python 표준 라이브러리만으로 구현:

```
Score = Σ (tf(term, doc) × idf(term)) + bonuses
```

**스코어링 요소:**
1. **TF-IDF**: 문서 내 용어 빈도 × 역문서 빈도
2. **구문 매칭 보너스**: 쿼리의 연속 바이그램이 문서에 존재하면 가산점
3. **헤딩 매칭 보너스**: Markdown 헤딩(`#`)에 쿼리 용어가 포함되면 가산점
4. **최신성 보너스**: 최근 수정된 파일에 가산점 (파일 mtime 기반)
5. **퍼지 매칭**: `difflib.SequenceMatcher`로 유사 문자열 추가 매칭

### 에이전틱 검색 (Agentic Search)

단순 키워드 매칭을 넘어서는 다단계 추론 검색:

1. **쿼리 분해**: 복잡한 질문을 여러 서브 쿼리로 분할
2. **초기 검색**: 각 서브 쿼리에 대해 기본 검색 수행
3. **멀티홉 탐색**: 결과 문서의 `[[wiki-links]]`를 따라가며 관련 문서 탐색
4. **재랭킹**: 관련성 + 메모리 티어 + 최신성 종합 평가
5. **충분성 판단**: 임계값 도달 시 탐색 중단, 미달 시 확장

### 점진적 공개 쿼리 (Progressive Disclosure)

AI 에이전트의 컨텍스트 윈도우 토큰을 절약하기 위한 3단계 깊이:

| 레벨 | 반환 내용 | 용도 |
|------|-----------|------|
| Level 1 | 간략 요약 (1~2줄) | 빠른 확인 |
| Level 2 | 중간 수준 상세 | 일반적 조회 |
| Level 3 | 전체 컨텍스트 (Timeline 포함) | 심층 분석 |

---

## 3. Dream Cycle (야간 건강 검사)

자동화된 메모리 유지보수 시스템. 7가지 건강 검사를 수행한다:

| # | 검사 항목 | 기준 | 조치 |
|---|-----------|------|------|
| 1 | 불완전한 출처 표기 | `[Source:]` 태그 누락 | 출처 추가 권고 |
| 2 | 빈약한 엔티티 페이지 | 파일 크기 < 300 bytes | 정보 보강 권고 |
| 3 | 중복 엔티티 | 정규화된 slug 유사도 | 병합 제안 |
| 4 | 오래된 inbox 항목 | 생성 후 > 48시간 | 분류 처리 권고 |
| 5 | 비대한 페이지 | 파일 크기 > 4KB | 분할/압축 제안 |
| 6 | 출처 없는 Key Points | Key Points 내 미출처 사실 | 출처 보강 권고 |
| 7 | 전체 건강도 점수 | 위 검사 결과 종합 | 점수 및 등급 출력 |

**실행 모드:**
- 기본: 권고만 출력 (dry-run)
- `--apply`: 자동 수정 가능한 항목에 대해 실행

---

## 4. Cognify 파이프라인

`inbox/` 디렉토리의 미분류 항목을 자동으로 적절한 디렉토리로 라우팅한다.

### 분류 로직 (휴리스틱 기반)

```
입력 텍스트 분석
    │
    ├─ "decision", "결정", "선택" 키워드 감지
    │  └→ decisions/ 라우팅
    │
    ├─ "task", "TODO", "할 일" 키워드 감지
    │  └→ tasks/ 라우팅
    │
    ├─ 인물 이름 / 조직명 감지 (NER)
    │  └→ entities/ 라우팅
    │
    └─ 분류 불가
       └→ 수동 처리 권고
```

### 안전 장치
- 기본 모드: 권고만 출력 (`--apply` 없이)
- `--apply` 플래그 시에만 실제 파일 이동 실행
- 분류 불확실 항목은 이동하지 않음

---

## 5. 엔티티 추적 및 상태 관리

### Track → Update 워크플로

```bash
# 1. 추적 시작
memkraft track "Simon Kim" --type person --source "conference"

# 2. 정보 누적
memkraft update "Simon Kim" --info "CEO of Hashed" --source "news"
memkraft update "Simon Kim" --info "Launched $200M fund" --source "press-release"
memkraft update "Simon Kim" --info "Left Hashed" --source "linkedin"
```

### 자동 상태 변화 감지

`update` 시 역할(role), 소속(affiliation) 등의 변경을 자동 감지하여:
- Compiled Truth 섹션의 State 필드 업데이트
- Timeline에 상태 변경 이벤트 기록
- 이전 상태를 히스토리로 보존

### Slug 변환

엔티티 이름은 파일명용 slug로 자동 변환된다:
- "Simon Kim" → `simon-kim.md`
- 공백 → 하이픈, 소문자 변환, 특수문자 제거

---

## 6. 미팅 브리프 (Brief)

특정 인물/조직에 대한 미팅 준비 문서를 자동 생성한다.

```bash
memkraft brief "Simon Kim"
```

**생성되는 내용:**
- Executive Summary (핵심 정보 요약)
- 최근 상태 변화
- Key Points (주요 사실)
- 관련 엔티티 (`[[wiki-links]]` 기반)
- 최근 Timeline 항목
- 미해결 사항 (Open Loops)

---

## 7. 팩트 레지스트리

`extract-facts` 명령으로 텍스트에서 숫자/날짜 기반 사실을 추출하여 `fact-registry.md`에 중앙 집중 관리한다.

```bash
memkraft extract-facts "Revenue grew 40% in Q3 2025. Team size is now 150."
```

교차 도메인 팩트를 하나의 인덱스로 관리하여 검색 및 교차 참조에 활용한다.

---

## 8. 백링크 및 위키링크

Obsidian 스타일의 `[[wiki-links]]`를 사용하여 엔티티 간 관계를 표현한다.

```markdown
# Simon Kim

## Key Points
- CEO of [[Hashed]]
- Invested in [[Ethereum]] ecosystem
- Collaborates with [[Vitalik Buterin]]
```

- `links <name>`: 특정 엔티티를 참조하는 모든 백링크 표시
- `suggest-links`: 텍스트 분석을 통해 누락된 위키링크 추천
- 에이전틱 검색에서 멀티홉 탐색의 경로로 활용

---

## 9. Decay (정보 부패 관리)

시간이 지남에 따라 오래된 정보를 자동 식별한다.

```bash
memkraft decay --days 90
```

- 지정 기간 동안 업데이트되지 않은 사실을 플래그
- 정보의 신선도를 유지하기 위한 리뷰 대상 제시
- Archival 티어로 강등 제안
