# 2. 기술 스택 및 의존성

## 기술 스택 요약

| 계층 | 기술 |
|------|------|
| **언어** | Python 3.9+ (3.9 ~ 3.12 지원) |
| **의존성** | 없음 (Python 표준 라이브러리만 사용) |
| **스토리지** | 로컬 파일 시스템 (Markdown 파일) |
| **세션 로깅** | JSONL 포맷 |
| **검색 엔진** | 커스텀 BM25 스타일 IDF 가중치 토큰 스코어링 |
| **퍼지 매칭** | `difflib.SequenceMatcher` |
| **개체명 인식 (NER)** | 정규식 기반 다국어 엔티티 탐지 |
| **빌드 시스템** | setuptools (`pyproject.toml` + `setup.py`) |
| **테스트** | pytest (51개 테스트) |
| **배포** | PyPI 패키지 (CLI 엔트리포인트) |

## 의도적으로 사용하지 않는 기술

MemKraft는 "제로 디펜던시"를 철학으로 삼고 있다. 다음 기술들을 의도적으로 배제했다:

| 일반적 선택 | MemKraft 대안 | 이유 |
|-------------|---------------|------|
| 벡터 DB (Pinecone, Chroma 등) | 커스텀 BM25 + IDF 스코어링 | 외부 의존성 제거 |
| spaCy / Transformers (NER) | 정규식 기반 탐지 | 설치 용량 및 의존성 최소화 |
| rapidfuzz (퍼지 매칭) | `difflib.SequenceMatcher` | 표준 라이브러리 활용 |
| SQLite / PostgreSQL | Markdown 파일 | 사람이 읽을 수 있는 형식 유지 |
| FastAPI / Flask (API 서버) | CLI 인터페이스 | 단순성 우선 |
| Pillow (이미지 처리) | 순수 Python PNG 생성기 | 의존성 제거 |

## 사용하는 표준 라이브러리 모듈

- `argparse` - CLI 인자 파싱
- `pathlib` - 파일 경로 처리
- `json` - JSON 직렬화/역직렬화
- `datetime` - 날짜/시간 처리
- `re` - 정규식 패턴 매칭 (NER)
- `difflib` - 퍼지 문자열 매칭
- `math` - IDF 계산 (log)
- `collections` - Counter, defaultdict
- `shutil` - 파일 복사 (템플릿 초기화)
- `os` - 환경 변수 (`MEMKRAFT_DIR`)
- `zlib` - PNG 압축 (배너 생성 스크립트)
- `struct` - 바이너리 데이터 패킹 (PNG 생성)

## 패키징

```toml
# pyproject.toml 핵심 설정
[project]
name = "memkraft"
version = "0.1.0"
requires-python = ">=3.9"
dependencies = []  # 제로 디펜던시

[project.scripts]
memkraft = "memkraft.cli:main"
```

개발 의존성은 `pytest`만 존재한다.
