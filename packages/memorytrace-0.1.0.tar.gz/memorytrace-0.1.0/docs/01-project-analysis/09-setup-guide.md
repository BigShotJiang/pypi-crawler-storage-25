# 9. 설치 및 실행 가이드

## 요구사항

- **Python**: 3.9 이상 (3.9, 3.10, 3.11, 3.12 지원)
- **외부 의존성**: 없음
- **OS**: 크로스 플랫폼 (Linux, macOS, Windows)

## 설치 방법

### 방법 1: pipx (권장)

```bash
pipx install memkraft
```

### 방법 2: pip

```bash
pip install memkraft
```

### 방법 3: 소스에서 개발 설치

```bash
git clone https://github.com/seojoonkim/memkraft.git
cd memkraft
pip install -e .
```

## 빠른 시작

### 1. 메모리 초기화

```bash
memkraft init
```

현재 디렉토리에 `memory/` 폴더와 하위 구조가 생성된다.

### 2. 엔티티 추적 시작

```bash
# 인물 추적
memkraft track "Simon Kim" --type person --source "conference"

# 조직 추적
memkraft track "Hashed" --type organization --source "research"
```

### 3. 정보 업데이트

```bash
memkraft update "Simon Kim" --info "CEO of Hashed, blockchain investor" --source "linkedin"
memkraft update "Simon Kim" --info "Launched $200M crypto fund" --source "press-release"
```

### 4. 텍스트에서 자동 추출

```bash
# 텍스트에서 엔티티와 사실 자동 추출
memkraft extract "Simon Kim, CEO of Hashed, announced a $200M fund at ETH Denver." --source "news"

# 파일에서 추출
memkraft extract "$(cat meeting-notes.txt)" --source "meeting"
```

### 5. 검색

```bash
# 기본 검색
memkraft search "Hashed fund"

# 에이전틱 검색 (복잡한 질문)
memkraft agentic-search "What investments has Simon Kim made in DeFi?"

# 점진적 공개 쿼리
memkraft query "Simon Kim" --level 1   # 간략
memkraft query "Simon Kim" --level 3   # 상세
```

### 6. 미팅 준비

```bash
memkraft brief "Simon Kim"
```

### 7. 유지보수

```bash
# 건강 검사
memkraft dream

# 중복 확인
memkraft dedup

# inbox 분류
memkraft cognify          # 권고만
memkraft cognify --apply  # 실제 실행

# 오래된 정보 확인
memkraft decay --days 90
```

## 환경 설정

### 메모리 디렉토리 변경

기본값은 `./memory/`이며 환경 변수로 변경 가능:

```bash
export MEMKRAFT_DIR="/path/to/custom/memory"
memkraft init
```

## 일반적인 워크플로

### 일일 워크플로

```bash
# 1. 아침: 미팅 브리프 준비
memkraft brief "오늘 미팅 상대"

# 2. 미팅 중/후: 정보 기록
memkraft extract "미팅에서 논의된 내용..." --source "meeting"

# 3. 저녁: 유지보수
memkraft dream
memkraft cognify --apply
```

### AI 에이전트 통합 워크플로

```python
import subprocess

# 에이전트가 CLI를 호출하여 메모리 활용
def search_memory(query):
    result = subprocess.run(
        ["memkraft", "search", query],
        capture_output=True, text=True
    )
    return result.stdout

def add_memory(name, info, source):
    subprocess.run([
        "memkraft", "update", name,
        "--info", info,
        "--source", source
    ])
```

## 테스트 실행

```bash
# 개발 환경에서 테스트
cd memkraft
pip install -e ".[dev]"  # 또는 pip install pytest
pytest tests/
```

51개 테스트가 모든 핵심 기능을 커버한다.

## 문제 해결

### "memory/ 디렉토리를 찾을 수 없음"
```bash
memkraft init  # 먼저 초기화 필요
```

### 검색 결과가 없음
```bash
memkraft index  # 인덱스 재빌드
memkraft list   # 추적 중인 엔티티 확인
```

### 인코딩 문제 (한국어/CJK)
Python 3.9+에서 UTF-8이 기본이지만, 환경에 따라:
```bash
export PYTHONIOENCODING=utf-8
```
