# 1. 프로젝트 개요

## MemKraft란?

MemKraft는 **AI 에이전트를 위한 제로 디펜던시 복합 메모리 시스템**이다. 핵심 철학은 "모든 대화가 다음 대화를 더 똑똑하게 만든다"는 것으로, AI 에이전트가 세션마다 처음부터 시작하는 대신 지속적이고 구조화된 메모리를 갖도록 한다.

- **저자**: Seojun Kim (simonkim.nft@gmail.com)
- **라이선스**: MIT
- **버전**: 0.1.0 (Alpha)
- **설치**: `pipx install memkraft`

## 핵심 컨셉

### 1. Zero Dependencies (제로 의존성)
Python 표준 라이브러리만으로 구현. 벡터 DB, spaCy, 외부 API 없이 모든 기능이 동작한다.

### 2. Markdown as Database
모든 지식을 사람이 읽을 수 있는 Markdown 파일로 저장한다. Git으로 추적 가능하며, 벤더 종속 없이 어떤 텍스트 에디터로든 편집 가능하다.

### 3. Compiled Truth + Timeline
GBrain 프로젝트에서 차용한 이중 레이어 구조:
- **Compiled Truth** (상단): 현재 상태의 요약 (Executive Summary, 역할, 소속 등)
- **Timeline** (하단): 시간순 기록 (`[Source: who, channel, date]` 형식의 출처 표기 필수)

### 4. 출처 추적 (Source Attribution)
모든 사실에는 출처 태그가 필수다. Dream Cycle이 출처 없는 사실을 자동으로 감지하여 경고한다.
출처 우선순위: 직접 발언 > 1차 자료 > API > 웹 > 소셜 미디어

### 5. MECE 분류 원칙
RESOLVER.md 결정 트리를 통해 모든 정보가 정확히 하나의 "홈" 디렉토리를 갖도록 한다. 중복 저장 대신 `[[wiki-links]]`와 "See Also"로 교차 참조한다.

## 프로젝트 포지셔닝

MemKraft는 다음 도구들과 경쟁하는 포지션에 있다:

| 경쟁사 | 차이점 |
|--------|--------|
| Mem0 | 벡터 DB 기반 vs. MemKraft의 파일 기반 |
| Cognee | 그래프 DB + LLM 파이프라인 vs. 순수 Python |
| Zep | 서버 기반 메모리 vs. 로컬 파일 시스템 |
| Letta/MemGPT | 복잡한 메모리 계층 vs. 단순한 3-tier 구조 |
| GBrain | Compiled Truth 모델의 원류 (MemKraft가 차용) |

## 타겟 사용자

- AI 에이전트 개발자
- 지식 관리 시스템이 필요한 개인/팀
- 외부 의존성 없이 가벼운 메모리 시스템을 원하는 개발자
- 한국어/다국어 환경에서 작업하는 사용자
