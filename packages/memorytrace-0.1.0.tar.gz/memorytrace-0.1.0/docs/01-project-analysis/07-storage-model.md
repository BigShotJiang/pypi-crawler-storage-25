# 7. 스토리지 모델 및 데이터 스키마

## 설계 철학

MemKraft는 전통적인 데이터베이스 대신 **파일 시스템을 데이터베이스로** 사용한다.

| 전통적 DB | MemKraft 대응 |
|-----------|---------------|
| 테이블 | 디렉토리 |
| 레코드 | Markdown 파일 |
| 외래키 | `[[wiki-links]]` |
| 인덱스 | `fact-registry.md`, `memkraft index` |
| 트랜잭션 로그 | `sessions/*.jsonl` |
| 스키마 | `TEMPLATES.md` |
| 쿼리 엔진 | BM25 + IDF 검색 |

## 디렉토리별 스토리지 구조

### `memory/entities/` - 엔티티 페이지

**형식**: Markdown (템플릿 기반)

```markdown
# Simon Kim

## Executive Summary
Hashed의 CEO. 블록체인 투자 분야의 주요 인물.

## State
- **Role**: CEO
- **Affiliation**: Hashed
- **Tier**: core
- **Last Updated**: 2026-04-10

## Key Points
- $200M 규모 신규 펀드 출시 [Source: press-release, 2026-03-15]
- Ethereum 생태계 집중 투자 전략 [Source: conference, 2026-02-20]

## See Also
- [[Hashed]]
- [[Vitalik Buterin]]

---

## Timeline

### 2026-04-10
- 신규 투자 파트너십 논의 [Source: Simon Kim, meeting, 2026-04-10]

### 2026-03-15
- $200M 펀드 공식 발표 [Source: Hashed PR, press-release, 2026-03-15]

### 2026-02-20
- ETH Denver 컨퍼런스 키노트 발표 [Source: conference-notes, conference, 2026-02-20]
```

**구조 규칙:**
- 상단 = Compiled Truth (현재 상태의 진실)
- 하단 = Timeline (시간순 기록)
- 모든 사실에 `[Source: who, channel, date]` 필수

### `memory/live-notes/` - 실시간 추적 노트

**형식**: Markdown

`track` 명령으로 생성되는 활성 추적 페이지. `entities/`로 승격 전의 작업 공간.

### `memory/decisions/` - 의사결정 기록

**형식**: Markdown (의사결정 템플릿)

```markdown
# [결정 제목]

## 배경
[결정이 필요한 상황 설명]

## 선택지
1. 선택지 A: [설명]
2. 선택지 B: [설명]

## 결정
[최종 결정 내용]

## 근거
[결정의 이유와 근거]

## 관련 엔티티
- [[관련 인물/조직]]
```

### `memory/originals/` - 독창적 사고

**형식**: Markdown

사용자 고유의 프레임워크, 아이디어, 분석 등. 외부 정보가 아닌 독창적 콘텐츠를 저장한다.

### `memory/inbox/` - 미분류 항목

**형식**: Markdown

Cognify 파이프라인에 의해 분류될 때까지 대기하는 임시 저장소. 48시간 이상 체류 시 Dream Cycle이 경고한다.

### `memory/tasks/` - 작업 추적

**형식**: Markdown

진행 중인 작업, TODO 항목 관리.

### `memory/meetings/` - 미팅 노트

**형식**: Markdown

`brief` 명령으로 생성된 미팅 브리핑 및 미팅 후 노트.

### `memory/sessions/` - 세션 로그

**형식**: JSONL (JSON Lines)

```jsonl
{"timestamp":"2026-04-12T10:30:00","event":"entity_created","entity":"simon-kim","tags":["person"],"importance":"high"}
{"timestamp":"2026-04-12T10:31:00","event":"entity_updated","entity":"simon-kim","info":"CEO of Hashed","source":"news"}
{"timestamp":"2026-04-12T10:35:00","event":"search","query":"Hashed fund","results_count":3}
```

파일명: `YYYY-MM-DD.jsonl` (일별 파일)

### `memory/fact-registry.md` - 팩트 인덱스

**형식**: Markdown (자동 생성)

`extract-facts` 명령으로 추출된 숫자/날짜 사실의 중앙 인덱스. 교차 도메인 검색에 활용.

## 출처 계층 (Source Hierarchy)

정보 충돌 시 우선순위:

```
1. 직접 발언 (Direct Speech)      ← 가장 신뢰
2. 1차 자료 (Primary Sources)
3. API 데이터
4. 웹 소스
5. 소셜 미디어                     ← 가장 낮은 신뢰
```

## 메모리 티어

| 티어 | 설명 | 검색 가중치 | 대상 |
|------|------|------------|------|
| `core` | 핵심 엔티티 | 최고 | 자주 참조되는 주요 인물/조직 |
| `recall` | 활성 정보 | 중간 | 현재 관련성 있는 엔티티 |
| `archival` | 보관 정보 | 최저 | 과거 기록, 비활성 엔티티 |

## 파일 네이밍 규칙

모든 엔티티 파일명은 slug 형식:
- 소문자 변환
- 공백 → 하이픈(`-`)
- 특수문자 제거
- 확장자: `.md`

예시:
- "Simon Kim" → `simon-kim.md`
- "Hashed Inc." → `hashed-inc.md`
- "김서준" → 유니코드 보존 slug

## Git 통합

모든 데이터가 텍스트 파일이므로:
- `git diff`로 변경사항 추적 가능
- `git log`로 히스토리 조회 가능
- 브랜치/머지를 통한 협업 가능
- GitHub/GitLab으로 백업 가능
