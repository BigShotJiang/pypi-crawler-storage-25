# 13. Markdown 파일 저장소의 구조적 문제점

> MemKraft는 모든 데이터를 Markdown 파일로 저장한다.
> "사람이 읽을 수 있다"는 장점 이면에 숨어 있는 심각한 문제들을 분석한다.

---

## 1. 스키마 강제력이 없다

### 문제

Markdown은 자유 형식 텍스트다. TEMPLATES.md에 구조를 정의해도, 실제 파일이 그 구조를 따르는지 **검증할 방법이 없다.**

**TEMPLATES.md가 정의한 구조:**
```markdown
# [엔티티명]

## Executive Summary
...

## State
- **Role**: ...
- **Affiliation**: ...
- **Tier**: ...

## Key Points
- ...

## Timeline
### YYYY-MM-DD
- ...
```

**실제로 발생할 수 있는 상황:**

```markdown
# Simon Kim

그냥 아무 텍스트를 여기에 쓸 수 있다.
Executive Summary 섹션이 없어도 에러 안 남.

## state               ← 대소문자 불일치 (State vs state)
- Role: CEO            ← 볼드 누락 (**Role** vs Role)
- Affiliation Hashed   ← 콜론 누락

## 타임라인              ← 한글로 쓰면 Timeline 파싱 불가
2026-04-12 뭔가 했음    ← 날짜 형식 불일치, Source 태그 누락
```

**결과:**
- `_apply_state_changes()`가 `**Role**:` 패턴으로 파싱 → 볼드 없으면 추출 실패
- `dream()`의 출처 검사가 `[Source:` 패턴 매칭 → 형식 안 맞으면 모든 항목이 "출처 없음" 경고
- 사용자가 직접 편집한 파일은 높은 확률로 구조가 깨짐

### 비교: 데이터베이스의 스키마

```sql
-- 데이터베이스는 구조를 강제한다
CREATE TABLE entities (
    name TEXT NOT NULL,
    role TEXT,
    affiliation TEXT,
    tier TEXT CHECK(tier IN ('core', 'recall', 'archival')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
-- 잘못된 데이터 입력 시 → 에러 발생
INSERT INTO entities (tier) VALUES ('invalid');  -- CHECK 실패
```

Markdown에는 이런 안전장치가 없다. **잘못된 데이터도 조용히 저장된다.**

---

## 2. 구조화된 데이터 추출이 정규식에 의존

### 문제

Markdown에서 "Role이 CEO인 모든 엔티티"를 찾으려면:

```python
# MemKraft가 실제로 하는 방식
for md_file in all_md_files():
    content = md_file.read_text()
    match = re.search(r'\*\*Role\*\*:\s*(.+)', content)
    if match and 'CEO' in match.group(1):
        results.append(md_file)
```

**깨지는 경우들:**

| 파일 내용 | 파싱 결과 |
|-----------|-----------|
| `- **Role**: CEO` | O (매칭) |
| `- **Role** : CEO` | X (콜론 앞 공백) |
| `- **Role**: CEO of Hashed` | "CEO of Hashed" 전체 매칭 (CEO만 원할 때) |
| `- Role: CEO` | X (볼드 없음) |
| `- **역할**: CEO` | X (한국어 키) |
| `**Role**: CEO` | X (리스트 마커 `-` 없음) |
| Timeline에 "Promoted to **Role**: CTO" | 오탐 (Timeline 내용을 State로 오인) |

**비교: 구조화된 저장소**

```python
# JSON
data = json.loads(file.read())
ceos = [e for e in data["entities"] if e["role"] == "CEO"]

# SQLite
cursor.execute("SELECT * FROM entities WHERE role = 'CEO'")
```

구조화된 저장소에서는 한 줄로 끝나는 쿼리가, Markdown에서는 깨지기 쉬운 정규식이 된다.

---

## 3. 관계(Relation) 표현의 한계

### 문제

엔티티 간 관계를 `[[wiki-links]]`로 표현한다. 하지만 이것은:

```markdown
# Simon Kim
- CEO of [[Hashed]]
- Invested in [[Ethereum]]
- Collaborates with [[Vitalik Buterin]]
```

**문제점:**

1. **관계 유형이 없다**: "CEO of"인지, "Invested in"인지, "Collaborates with"인지는 주변 텍스트에만 있다. 프로그래밍 방식으로 관계 유형을 추출하려면 또 정규식 파싱이 필요하다.

2. **방향성이 없다**: `[[Hashed]]` 링크가 Simon Kim → Hashed인지 Hashed → Simon Kim인지 구분 불가. 백링크로 역방향을 추론하지만, 원본 링크의 의미(고용 관계? 투자 관계?)는 소실된다.

3. **링크 무결성 보장 없음**: `[[존재하지 않는 엔티티]]`를 써도 에러 없음. Dangling reference가 무한히 쌓일 수 있다.

4. **다대다 관계 표현 곤란**: "Simon Kim이 2024년에는 Hashed의 CEO, 2025년에는 New Company의 CEO"를 Markdown에서 구조적으로 표현하기 어렵다.

**비교: 그래프 모델**

```python
# 구조화된 관계
graph.add_edge("Simon Kim", "Hashed", relation="CEO_OF", since="2020-01-01")
graph.add_edge("Simon Kim", "Ethereum", relation="INVESTED_IN", amount="$10M")

# 쿼리: Simon Kim의 모든 투자
graph.get_edges("Simon Kim", relation="INVESTED_IN")
# → [("Ethereum", {"amount": "$10M"})]
```

---

## 4. 성능 — 파일 개수에 비례하는 선형 저하

### 문제

모든 검색/분석 연산이 **전체 .md 파일을 디스크에서 읽는다:**

```python
def _all_md_files(self):
    for subdir in self.subdirs:
        for md in subdir.glob("*.md"):
            yield md
```

| 파일 수 | 검색 시간 (추정) | 퍼지 검색 시간 (추정) |
|---------|-----------------|---------------------|
| 50 | ~100ms | ~300ms |
| 500 | ~1s | ~3s |
| 5,000 | ~10s | ~30s |
| 50,000 | ~100s | ~300s |

**왜 Markdown이 특히 느린가:**

1. **파일 시스템 오버헤드**: 각 파일 열기에 시스템 콜 필요 (open → read → close)
2. **파싱 오버헤드**: 텍스트를 읽고, 토큰화하고, 패턴 매칭해야 함
3. **인덱스 불가**: Markdown 파일 자체는 인덱싱 불가. 별도 인덱스를 만들면 동기화 문제 발생
4. **디스크 I/O**: SSD에서도 수천 개 소규모 파일 읽기는 하나의 DB 파일 읽기보다 느림

**비교:**

```
SQLite FTS5: 50,000 문서 전문 검색 → ~10ms
Markdown 전체 스캔: 50,000 파일 → ~100,000ms (10,000배 느림)
```

---

## 5. 원자성(Atomicity) 부재 — 데이터 손상 위험

### 문제

Markdown 파일 쓰기는 원자적이지 않다:

```python
# MemKraft의 실제 패턴
content = filepath.read_text()     # 1. 읽기
content += "\n- 새 정보\n"          # 2. 수정
filepath.write_text(content)       # 3. 쓰기 ← 여기서 중단되면?
```

**데이터 손상 시나리오:**

```
시나리오 1: 전원 차단
├── write_text() 시작
├── 파일 50% 기록됨
├── 전원 차단 ⚡
└── 결과: 파일이 절반만 남음 → 엔티티 데이터 영구 손실

시나리오 2: 디스크 풀
├── write_text() 시작
├── 디스크 용량 부족
└── 결과: 파일이 0 bytes로 truncate됨 → 빈 파일

시나리오 3: 동시 쓰기
├── 프로세스 A: read_text() → "원본 내용"
├── 프로세스 B: read_text() → "원본 내용"
├── 프로세스 A: write_text("원본 + A의 수정")
├── 프로세스 B: write_text("원본 + B의 수정")
└── 결과: A의 수정이 사라짐 (Lost Update)
```

**비교: 데이터베이스**

```
SQLite의 쓰기:
├── WAL(Write-Ahead Log)에 먼저 기록
├── 커밋 완료 확인
├── 그 후 실제 DB 파일 반영
└── 중단 시 → WAL로 복구 가능 (데이터 손실 없음)
```

---

## 6. 동시성(Concurrency) — 파일 레벨 충돌

### 문제

Markdown 파일은 파일 단위로만 잠글 수 있다. 하나의 엔티티 파일에 대해:

- **읽기-쓰기 충돌**: 한 에이전트가 읽는 동안 다른 에이전트가 쓰면 불완전한 데이터를 읽음
- **쓰기-쓰기 충돌**: 두 에이전트가 동시에 같은 엔티티를 업데이트하면 하나가 소실
- **파일 레벨 락**: 엔티티 파일 전체를 잠가야 함 → 섹션별 동시 수정 불가

**비교: 데이터베이스**

```
SQLite: 행(row) 레벨 잠금 가능
PostgreSQL: MVCC로 읽기-쓰기 충돌 없음
→ 같은 엔티티의 다른 필드를 동시에 수정 가능
```

---

## 7. 데이터 타입이 없다

### 문제

Markdown에서 모든 것은 텍스트다:

```markdown
## State
- **Role**: CEO                    ← 문자열
- **Founded**: 2020-01-15          ← 이게 날짜인지 문자열인지 알 수 없음
- **Fund Size**: $200M             ← 이게 숫자인지 문자열인지 알 수 없음
- **Active**: Yes                  ← 이게 불리언인지 문자열인지 알 수 없음
- **Tier**: core                   ← 이게 enum인지 문자열인지 알 수 없음
```

**결과:**
- 날짜 비교 불가: "2020-01-15"과 "January 15, 2020"이 같은 날짜인지 모름
- 숫자 비교 불가: "$200M"과 "$200,000,000"이 같은 금액인지 모름
- 정렬 불가: "Fund Size" 기준으로 엔티티를 정렬하려면 먼저 파싱해야 함
- 집계 불가: "모든 엔티티의 평균 Fund Size"를 계산하려면 모든 파일을 파싱해야 함

**비교:**

```sql
-- 데이터베이스에서는 한 줄
SELECT AVG(fund_size) FROM entities WHERE fund_size > 100000000;

-- Markdown에서는
for file in all_md_files():
    content = file.read_text()
    match = re.search(r'\*\*Fund Size\*\*:\s*\$?([\d,]+[MBK]?)', content)
    if match:
        amount = parse_money(match.group(1))  # "$200M" → 200000000 변환 필요
        ...
```

---

## 8. 마이그레이션 / 스키마 진화 불가

### 문제

템플릿을 변경하면 기존 파일들은 어떻게 되는가?

**예: "State" 섹션에 "Email" 필드를 추가하고 싶다**

```
새 템플릿:
## State
- **Role**: ...
- **Affiliation**: ...
- **Email**: ...        ← 신규 필드
- **Tier**: ...

문제: 기존 500개 파일에는 Email 필드가 없다.
→ 500개 파일을 열어서 하나씩 수정해야 함
→ 자동 마이그레이션 스크립트를 작성하려면 정규식 파싱 필요
→ 파일마다 형식이 미묘하게 달라 정규식이 모든 케이스를 커버하기 어려움
```

**예: "Timeline" 형식을 변경하고 싶다**

```
기존: ### 2026-04-12
      - 내용 [Source: who, channel, date]

신규: ### 2026-04-12 | meeting
      - 내용
      - Source: who
      - Confidence: 0.8

→ 기존의 모든 Timeline 항목을 새 형식으로 변환하는 것은
  정규식으로 완벽하게 처리하기 극히 어렵다
```

**비교:**

```sql
-- 데이터베이스 마이그레이션: 한 줄
ALTER TABLE entities ADD COLUMN email TEXT;
-- 기존 레코드 자동으로 email = NULL

-- 복잡한 마이그레이션도 SQL로 가능
UPDATE timeline SET confidence = 0.5 WHERE source_type = 'web';
```

---

## 9. 검색 시 토큰 낭비

### 문제

Markdown 문법 자체가 LLM의 토큰을 소비한다:

```markdown
# Simon Kim

## Executive Summary
Hashed의 CEO. 블록체인 투자 분야의 주요 인물.

## State
- **Role**: CEO
- **Affiliation**: Hashed
- **Tier**: core
- **Last Updated**: 2026-04-10

## Key Points
- $200M 규모 신규 펀드 출시 [Source: press-release, 2026-03-15]

---

## Timeline

### 2026-04-10
- 신규 투자 파트너십 논의 [Source: Simon Kim, meeting, 2026-04-10]
```

**토큰 분석 (GPT-4 tokenizer 기준 추정):**

| 요소 | 토큰 수 | 정보 가치 |
|------|---------|-----------|
| `# `, `## `, `### ` (헤딩 마커) | ~8 | 없음 (구조 표현용) |
| `- **`, `**:` (리스트+볼드) | ~12 | 없음 (포맷팅용) |
| `---` (수평선) | ~3 | 없음 |
| `[Source: ...]` 태그 | ~20 | 메타데이터 (에이전트에 불필요할 수 있음) |
| 실제 정보 내용 | ~50 | 있음 |
| **합계** | ~93 | **54%가 구조/포맷팅** |

**같은 정보를 JSON으로:**

```json
{"name":"Simon Kim","role":"CEO","affiliation":"Hashed","tier":"core",
 "summary":"블록체인 투자 분야의 주요 인물",
 "key_points":["$200M 신규 펀드 출시"],
 "recent":["2026-04-10: 투자 파트너십 논의"]}
```

토큰 수: ~55 → **41% 절약**

500 토큰 예산이라면:
- Markdown: ~5.4개 엔티티 분량
- JSON: ~9.1개 엔티티 분량 (68% 더 많은 정보)

---

## 10. Git 병합 충돌의 의미적 문제

### 문제

Markdown을 Git으로 관리할 때, 병합 충돌은 텍스트 레벨이지 의미 레벨이 아니다:

```
<<<<<<< HEAD
## State
- **Role**: CEO
- **Affiliation**: Hashed
=======
## State
- **Role**: CTO
- **Affiliation**: Hashed Labs
>>>>>>> feature-branch
```

Git은 이것이 "같은 사람의 역할이 바뀐 것"인지 "두 에이전트가 다른 정보를 가진 것"인지 모른다. 사람이 직접 해결해야 하며, 잘못 해결하면 데이터 손실.

**Timeline의 동시 추가:**
```
<<<<<<< HEAD
### 2026-04-12
- 미팅에서 CEO 확인 [Source: meeting]
=======
### 2026-04-12
- 링크드인에서 CTO로 표시 [Source: linkedin]
>>>>>>> other-branch
```

이것은 충돌이 아니라 **충돌하는 사실** — 둘 다 보존해야 하지만 Git은 하나를 선택하라고 한다.

---

## 11. 파일 시스템 의존적 제약

### 문제

| 제약 | 설명 |
|------|------|
| **파일명 길이** | 대부분 OS에서 255바이트 제한. 긴 엔티티명 잘림 |
| **특수문자** | `C++.md`, `node.js.md`, `AT&T.md` → OS별로 허용/불허 다름 |
| **대소문자** | macOS(HFS+): 대소문자 무시. `Simon-Kim.md` = `simon-kim.md`. Linux: 구분 |
| **경로 길이** | Windows: 260자 제한 (긴 디렉토리 구조에서 문제) |
| **동시 접근** | NFS/네트워크 드라이브에서 파일 락 동작이 비일관적 |
| **성능** | ext4: 디렉토리당 수만 파일 시 `readdir` 성능 저하 |
| **인코딩** | Windows에서 기본 인코딩이 CP949(한국어) → UTF-8 Markdown 깨짐 가능 |

**slug 변환의 함정:**
```python
# MemKraft의 slugify
"C++" → "c"          # 정보 손실 (어떤 엔티티인지 알 수 없음)
"node.js" → "nodejs"  # 점이 제거됨
"AT&T" → "att"        # &가 제거됨
"김민수" → "김민수"    # CJK는 보존되지만 OS 호환성 불확실
```

---

## 12. 부분 읽기/쓰기 불가

### 문제

"Simon Kim의 현재 Role만 읽고 싶다" → **파일 전체를 읽어야 한다.**

```python
# Markdown에서 Role 하나 읽기
content = Path("simon-kim.md").read_text()  # 전체 파일 읽기 (수 KB)
role = re.search(r'\*\*Role\*\*:\s*(.+)', content)  # 파싱

# SQLite에서 Role 하나 읽기
cursor.execute("SELECT role FROM entities WHERE name = 'Simon Kim'")
# → 해당 필드만 읽음
```

**Timeline에 하나의 항목만 추가하고 싶다:**
```python
# Markdown: 전체 읽기 → 수정 → 전체 쓰기
content = path.read_text()       # 10KB 읽기
content += "\n### 2026-04-12\n- 새 항목\n"
path.write_text(content)          # 10KB 전체 다시 쓰기

# SQLite: 한 행만 삽입
cursor.execute("INSERT INTO timeline VALUES (?, ?, ?)", ...)
# → 추가분만 기록
```

파일이 커질수록 이 비효율이 누적된다. 10KB 파일에 100바이트 추가를 위해 매번 10KB를 읽고 쓴다.

---

## 13. 백업/복구의 취약성

### 문제

| 시나리오 | Markdown | 데이터베이스 |
|----------|----------|-------------|
| 특정 시점 복구 | Git 커밋에서 전체 복원만 가능 | Point-in-time recovery |
| 부분 복구 | 특정 파일만 `git checkout` | 특정 테이블/행 복구 |
| 실시간 백업 | 불가 (파일 쓰기 중 복사 시 불완전) | WAL 기반 핫 백업 |
| 증분 백업 | Git이 해결 (변경분만 커밋) | WAL/binlog 기반 |
| 무결성 검증 | 없음 (파일이 유효한 Markdown인지 검증 불가) | `PRAGMA integrity_check` |

---

## 14. 실제 장애 시나리오

### 시나리오 A: 엔티티 폭발

에이전트가 뉴스 기사를 매일 `extract`한다. 기사에서 추출된 엔티티가 하루 50개.

```
1주: 350 파일
1달: 1,500 파일
6달: 9,000 파일
1년: 18,000 파일
```

검색 시간: 매일 느려짐. 1년 후 단순 검색에 ~30초. 에이전트 실시간 사용 불가능.

### 시나리오 B: 파일 비대화

Simon Kim에 대한 정보가 매일 추가된다.

```
1달: 5KB (정상)
6달: 30KB
1년: 60KB
2년: 120KB ← 파일 하나가 120KB
```

이 파일 하나를 읽기 위해 매번 120KB 디스크 I/O. update 시 120KB 전체를 읽고 다시 쓴다.
에이전트에 반환 시 ~30,000 토큰 소비 → 컨텍스트 윈도우의 상당 부분을 차지.

### 시나리오 C: 구조 드리프트

3명의 사용자가 수동으로 파일을 편집.

```
사용자 A: "## State" 아래에 임의 텍스트 추가
사용자 B: Timeline 형식을 자기 스타일로 변경  
사용자 C: 새로운 섹션 "## My Notes" 추가
```

6개월 후: 500개 파일 중 300개가 각자 다른 구조. 정규식 파싱이 30%의 파일에서 실패.
Dream Cycle이 대량의 false positive 경고를 출력. 사용자가 경고를 무시하게 됨.

### 시나리오 D: 인코딩 혼합

한국어/일본어/영어 혼용 환경.

```
파일 1: UTF-8 (정상)
파일 2: UTF-8 with BOM (Windows에서 생성)
파일 3: EUC-KR (구형 한국어 도구에서 편집)
```

`read_text()` 기본 인코딩(UTF-8)으로 파일 3을 읽으면 `UnicodeDecodeError` 또는 깨진 문자.
MemKraft에 인코딩 감지/처리 로직 없음.

---

## 종합: Markdown 저장소의 근본 한계

| 문제 영역 | 심각도 | 핵심 |
|-----------|--------|------|
| 스키마 강제력 없음 | **Critical** | 잘못된 데이터가 조용히 저장되고, 파싱 시 조용히 누락됨 |
| 구조화된 쿼리 불가 | **Critical** | 모든 질의가 정규식 파싱에 의존 → 깨지기 쉬움 |
| 원자성 없음 | **High** | 중단 시 데이터 손상, 동시 쓰기 시 데이터 손실 |
| 선형 스캔 성능 | **High** | 파일 증가에 비례하여 모든 연산이 느려짐 |
| 관계 표현 한계 | **High** | 관계 유형/방향/무결성 관리 불가 |
| 데이터 타입 없음 | **Medium** | 날짜/숫자 비교, 정렬, 집계 불가 |
| 토큰 낭비 | **Medium** | Markdown 문법이 ~46%의 토큰을 소비 |
| 마이그레이션 불가 | **Medium** | 스키마 변경 시 수동 일괄 수정 필요 |
| 파일 시스템 의존 | **Low** | OS별 파일명/인코딩/대소문자 차이 |

---

## 대안적 접근

### 추천: "이중 레이어" 아키텍처

**Markdown의 장점(사람이 읽을 수 있음)과 구조화된 저장소의 장점을 모두 취하는 방법:**

```
┌──────────────────────────────────────┐
│          Primary Storage             │
│        (SQLite + FTS5)               │
│  - 구조화된 스키마                     │
│  - 전문 검색 인덱스                    │
│  - ACID 트랜잭션                      │
│  - 원자적 읽기/쓰기                    │
│  - 에이전트가 직접 쿼리                 │
└──────────────┬───────────────────────┘
               │ 자동 동기화
               ▼
┌──────────────────────────────────────┐
│          Secondary Export            │
│        (Markdown 파일)               │
│  - 사람이 읽기 위한 뷰                 │
│  - Git 버전 관리용                    │
│  - 변경 시 자동 재생성                 │
│  - 읽기 전용 (수정은 DB를 통해)         │
└──────────────────────────────────────┘
```

```python
class DualLayerStorage:
    def __init__(self, base_dir: Path):
        self.db = sqlite3.connect(base_dir / "memory.db")
        self.md_dir = base_dir / "readable"  # Markdown export 디렉토리
        self._init_schema()
    
    def write(self, entity: Entity):
        """DB에 쓰고 Markdown도 자동 생성"""
        self.db.execute(
            "INSERT OR REPLACE INTO entities VALUES (?, ?, ?, ?, ?)",
            (entity.name, entity.role, entity.affiliation, entity.tier, 
             entity.updated_at.isoformat())
        )
        self.db.commit()
        self._export_markdown(entity)  # Markdown 자동 생성
    
    def search(self, query: str) -> list[Entity]:
        """DB에서 검색 (빠름, 구조화됨)"""
        return self.db.execute(
            "SELECT * FROM entities WHERE entities MATCH ?", (query,)
        ).fetchall()
    
    def _export_markdown(self, entity: Entity):
        """DB 데이터를 Markdown으로 내보내기 (사람 열람용)"""
        md = f"# {entity.name}\n\n"
        md += f"## State\n- **Role**: {entity.role}\n"
        md += f"- **Affiliation**: {entity.affiliation}\n"
        # ...
        (self.md_dir / f"{slugify(entity.name)}.md").write_text(md)
```

**이 접근의 장점:**
- 에이전트: SQLite에서 빠르고 구조화된 쿼리
- 사람: Markdown 파일에서 읽기 편한 형식
- Git: Markdown 파일로 변경 이력 추적
- 안전: ACID 트랜잭션으로 데이터 무결성 보장
- 성능: FTS5 인덱스로 밀리초 단위 검색
- `sqlite3`는 Python 표준 라이브러리 → 제로 디펜던시 유지 가능
