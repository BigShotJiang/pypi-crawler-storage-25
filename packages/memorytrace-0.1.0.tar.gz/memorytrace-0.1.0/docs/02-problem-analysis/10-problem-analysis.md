# 10. MemKraft 문제점 심층 분석

> 소스 코드 전체를 라인 단위로 분석한 결과를 정리한 문서

---

## 1. 코드 품질 (Code Quality)

### 1.1 God Object 안티패턴

`core.py`는 **~2037줄, 40+ 메서드**를 가진 단일 `MemKraft` 클래스로 구성되어 있다. 전형적인 God Object 안티패턴이다.

**문제:**
- NER, 검색, 파일 I/O, 유지보수, 로깅, 요약이 하나의 클래스에 혼재
- 데이터 접근 계층, 비즈니스 로직, 프레젠테이션이 분리되지 않음
- 모든 메서드가 `print()`를 직접 호출 → 라이브러리로 사용 시 불필요한 stdout 오염
- 하나의 기능 변경이 전체 클래스에 영향을 미침 (높은 blast radius)

```python
# 예: extract_conversations()는 print()와 return을 동시에 수행
# 프로그래밍 방식으로 호출하면 콘솔 출력이 불가피하게 발생
print(json.dumps(results, ...))  # stdout 오염
return results                    # 반환도 함
```

### 1.2 버그 및 로직 오류

#### Bug 1: `track()`이 성공 시 `None` 반환
- 타입 힌트: `-> Optional[Path]`
- 실제 동작: try 블록 끝에서 `return filepath`가 없음
- 결과: 호출자가 성공/실패를 구분할 수 없음
- 테스트가 파일 시스템을 직접 확인하기 때문에 발견되지 않음

#### Bug 2: `decay()`가 마크다운 포맷을 깨뜨림
```python
# line 1442
line = line.replace("- **", "- ⏳ ", 1)
# 입력: "- **2024-01-01**"
# 결과: "- ⏳ 2024-01-01**"  ← 닫는 ** 가 남아 마크다운 깨짐
```

#### Bug 3: `summarize()`에 무의미한 코드
```python
# line 1551 - 동일 문자열 치환 (no-op)
new_content = content.replace("# ", f"# ", 1)
# "# "을 "# "으로 치환 → 아무것도 하지 않음
```

#### Bug 4: `_detect_regex` 중복 엔티티 누적
- 같은 텍스트에서 동일 엔티티가 여러 번 매칭되면 결과 리스트에 중복 추가
- `set()` 호출이 2-word 이름 리스트에만 적용되고 전체 결과에는 미적용

#### Bug 5: `_extract_facts` 정규식 과도한 매칭
```python
# 패턴: (.+?)(?:\.|,|;|$)
# "Grace Hopper was a pioneering computer scientist who invented COBOL, she also served in the Navy"
# → "a pioneering computer scientist who invented COBOL" (쉼표에서 끊김)
# 한국어 패턴은 특정 어미로 끝나지 않는 입력과 전혀 매칭되지 않음
```

#### Bug 6: 한국어 조사 제거 정규식 오류
```python
# line 1789
([가-힣]+?)([이을를은는에로으와과도만이라서의]+)$
# '의'는 소유격이지 제거할 조사가 아님
# '이', '도' 등이 이름의 일부인 경우 이름이 잘려나감
# 예: "김도이" → 조사로 오인하여 "김"만 추출
```

### 1.3 보안 취약점

#### Path Traversal in `extract`
```python
# _resolve_extract_input (line 554-563)
Path(input_text).expanduser()  # 파일이 존재하면 읽음
```
- `memkraft extract "~/.ssh/id_rsa"` → SSH 개인키 내용이 파싱되어 엔티티 파일로 저장됨
- `memkraft extract "/etc/passwd"` → 시스템 파일 노출
- 4096 길이 제한은 긴 경로만 방지, 악의적 짧은 경로는 통과

#### Markdown Injection
- 사용자 입력에 `# OVERWRITE`나 `[malicious](javascript:...)` 포함 시 그대로 엔티티 파일에 기록
- 별도의 입력 살균(sanitization) 없음

### 1.4 코드 스멜

- **정규식 스프**: `_detect_regex`가 141줄 단일 함수, 중국어 성씨 세트가 300+ 문자 한 줄
- **일관성 없는 에러 처리**: 메서드마다 다른 에러 처리 패턴 (print + return None / print + return [] / 예외 무시)
- **매직 넘버 범람**: `300` bytes, `4000` bytes, `48` hours, `0.3` 퍼지 임계값, `0.85` 중복 유사도 등 하드코딩. 설정 불가.

---

## 2. 아키텍처 (Architecture)

### 2.1 파일 기반 스토리지의 확장성 한계

**모든 검색이 전체 파일을 디스크에서 읽음:**
```python
all_files = list(self._all_md_files())  # line 850-853
```
- BM25 IDF 계산에서 모든 파일을 **2번** 읽음 (IDF 계산 + 실제 스코어링)
- 1000개 엔티티 → 검색당 2000+ 파일 I/O
- `_all_md_files()`가 `search()`, `dream()`, `build_index()`, `suggest_links()`, `decay()`, `dedup()` 등 10+ 메서드에서 호출
- **캐싱 레이어 전혀 없음** — 매번 파일 시스템 재스캔

**`dedup()` O(n²) 복잡도:**
```python
# line 1479: 중첩 루프
for fact_a in facts:
    for fact_b in facts:
        # 1000 파일 × 10 사실 = 10,000,000 비교
```

### 2.2 동시성 / 경쟁 상태 (Race Conditions)

**파일 락 전무:**
```python
# 읽기-수정-쓰기 사이클 (모든 update 계열 메서드)
content = filepath.read_text()   # 1. 읽기
content += new_info               # 2. 수정
filepath.write_text(content)      # 3. 쓰기
# 두 프로세스가 동시 실행 시 하나의 업데이트가 소실됨
```

**`_write_fact_registry` TOCTOU 경쟁:**
- 파일 읽기 → 중복 확인 → 파일 쓰기 사이에 다른 프로세스가 쓰기 가능

### 2.3 강한 결합 (Tight Coupling)

- 프레젠테이션 계층(print)과 로직 계층이 분리 불가
- `cli.py`가 220줄짜리 `if/elif` 체인 — 디스패치 테이블이나 서브파서 액션 미사용
- MemKraft를 Python 라이브러리로 import 시 모든 메서드 호출이 콘솔 출력을 발생시킴

---

## 3. 검색 엔진 (Search Engine)

### 3.1 BM25라고 부르기 어려운 구현

```python
# line 902 - IDF만 구현
idf = (doc_count - df + 0.5) / (df + 0.5)
```

**실제 BM25와의 차이:**
| 요소 | 실제 BM25 | MemKraft |
|------|-----------|----------|
| IDF (역문서빈도) | O | O |
| TF (용어빈도) 정규화 | O (k1 파라미터) | X (존재 여부만) |
| 문서 길이 정규화 | O (b 파라미터) | X |

실제로는 **IDF 가중 불리언 매칭**에 불과하다. 토큰이 "있다/없다"만 판단하고 빈도는 무시한다.

### 3.2 퍼지 검색 성능 문제

```python
# fuzzy=True 시: 모든 파일의 모든 줄에 SequenceMatcher 적용
# SequenceMatcher: O(n*m) 복잡도
# 1000 파일 × 100줄 = 100,000회 SequenceMatcher 호출
```

### 3.3 토큰화 엣지 케이스

```python
# 토큰화 패턴: r'[\w\uAC00-\uD7AF\u4E00-\u9FFF]+'
```

| 입력 | 결과 | 문제 |
|------|------|------|
| `"GPT-5"` | `["gpt", "5"]` | 하이픈으로 분리됨 |
| `"node.js"` | `["node", "js"]` | 점으로 분리됨 |
| `"马化腾和李彦宏"` | 하나의 토큰 | CJK 단어 경계 미인식 → 토큰 검색 무용 |

### 3.4 "에이전틱 검색"의 실체

**README 주장:** 에이전틱 멀티홉 분해 검색
**실제 구현:** 정규식 기반 쿼리 분해 + 위키링크 그래프 탐색 + 재랭킹

| 진정한 에이전틱 검색 | MemKraft 구현 |
|---------------------|---------------|
| LLM이 중간 결과를 보고 다음 검색 결정 | 사전 정의된 정규식 패턴으로 분해 |
| 시맨틱 이해 기반 판단 | 키워드 매칭 |
| 자율적 탐색 경로 결정 | 고정된 위키링크 그래프 탐색 |

```python
# _decompose_query 실제 구현 (line 1670-1695)
# 단순 정규식 패턴:
r"who is (.+)"          # → 서브쿼리 생성
r"(.+)이/가 (.+)"       # ← 버그: "이/가"를 리터럴로 매칭, 교대(|) 아님
```

`"Who is the CEO of Hashed"` → `["the CEO of Hashed", "who is the CEO of Hashed"]` 로 분해 — 유용하지 않은 서브쿼리.

---

## 4. NER 시스템 (개체명 인식)

### 4.1 영어 이름 오탐율

```python
# 패턴: \b([A-Z][a-z]+ [A-Z][a-z]+)\b
# 대문자 시작 2단어 → 모두 인물로 인식
```

| 입력 | NER 결과 | 정답 |
|------|----------|------|
| "Key Points" | Person: "Key Points" | X (섹션 제목) |
| "North America" | Person: "North America" | X (지명) |
| "Looking Forward" | Person: "Looking Forward" | X (구문) |
| "Los Angeles" | Person: "Los Angeles" | X (도시) |

블록리스트에 ~80개 단어가 있지만 커버하지 못하는 패턴이 다수.

### 4.2 한국어 이름 탐지 — 사실상 사용 불가

```python
# 패턴: [\uAC00-\uD7AF]{2,4}
# → 한글 2~4글자면 무조건 매칭
```

**핵심 문제:** 한국어에서 거의 모든 단어가 2~4음절이다.

| 입력 | NER 결과 | 정답 |
|------|----------|------|
| "오늘 회의에서 논의했다" | "오늘", "회의", "논의" → 모두 Person | X |
| "서울에서 만났다" | "서울" → Person | X (지명) |
| "김민수가 발표했다" | "김민수" → Person | O |

불용어 리스트가 유일한 필터이지만, 한국어 단어 수만 개를 불용어로 등록하는 것은 불가능. **실제 한국어 텍스트에서 오탐율이 극도로 높을 것.**

### 4.3 CJK 이름 탐지 한계

**중국어:**
- 100개 성씨 세트로 첫 글자 매칭 → 비표준 성씨 미탐지
- 金(김/금)은 성씨이자 "금" → 문맥 없이 구분 불가

**일본어:**
- 85개 성씨만 지원 → 비표준 성씨 전부 미탐지
- 3글자 이상 이름(given name) 미처리

---

## 5. 테스트 (Testing)

### 5.1 테스트되지 않은 항목

| 미테스트 영역 | 위험도 |
|---------------|--------|
| `cli.py` main() 함수 — CLI 통합 테스트 전무 | 높음 |
| 동시 접근 (race condition) | 높음 |
| `cognify --apply` 실제 파일 라우팅 | 높음 |
| `diff` 명령어 전체 | 중간 |
| `brief --save` 플래그 | 중간 |
| `query`의 `--recent`, `--tag`, `--date` 필터 | 중간 |
| `MEMKRAFT_DIR` 환경 변수 | 중간 |
| `extract`의 stdin 입력 경로 | 중간 |
| 읽기 전용 파일 시스템에서의 동작 | 낮음 |
| 디스크 풀 상태에서의 쓰기 | 낮음 |
| `C++`, `node.js` 같은 특수문자 엔티티명 | 낮음 |

### 5.2 "크래시 안 함" 테스트 문제

다수의 테스트가 정확성이 아닌 "에러 없이 실행됨"만 검증:

```python
# 어서션 없는 테스트들
test_promote_nonexistent    # mk.promote("Nobody") 호출만 함
test_brief_nonexistent      # mk.brief("Nobody") 호출만 함
test_dream_live             # 크래시 안 하는지만 확인
test_cognify_empty_inbox    # 어서션 없음
test_distill_decisions_empty # 어서션 없음
```

### 5.3 테스트 데이터 편향

`mk_with_data` 픽스처가 단일 문장 `"Simon Kim is the CEO of Hashed in Seoul"`에만 의존. 이 하나의 데이터 형태에서만 동작을 검증하고 있어 다양한 입력 패턴에 대한 커버리지 부족.

---

## 6. API/CLI 설계

### 6.1 혼란스러운 명령어 중복

**검색 계열 4개 명령어:**
| 명령어 | 차이점 | 혼란 요소 |
|--------|--------|-----------|
| `search` | 퍼지 매칭 | `lookup`과 차이 불명확 |
| `lookup` | "브레인 우선" | `search`와 차이 불명확 |
| `query` | 점진적 공개 (3레벨) | 왜 `search --level`이 아닌가? |
| `agentic-search` | 멀티홉 | 실제로는 에이전틱이 아님 |

**추출 계열 혼란:**
| 명령어 | 동작 |
|--------|------|
| `extract` | NER + 사실 추출 + 파일 생성 |
| `detect` | NER만 수행 (파일 미생성) |
| `extract-facts` | 숫자/날짜 사실만 추출 |

### 6.2 에러 처리 부재

```python
# cli.py line 154: init 없이 실행해도 에러 없이 빈 결과만 반환
mc = MemKraft()  # memory/ 없어도 에러 안 남

# cli.py line 218: 항상 exit code 0 반환
# 실패해도 쉘 스크립트에서 감지 불가
```

### 6.3 입력 검증 부재

- `--max-hops`: 음수 허용
- `--days`: 0 또는 음수 허용
- `--max-length`: 0 허용
- 모두 예상치 못한 동작 유발 가능

---

## 7. 데이터 무결성 (Data Integrity)

### 7.1 백업/복구 메커니즘 부재

- `memkraft backup` / `memkraft restore` 없음
- `dream`, `decay()`가 파일을 in-place 수정
- 버그 발생 시 전체 지식 베이스가 복구 불가능하게 손상될 수 있음

### 7.2 비원자적 파일 쓰기

```python
filepath.write_text(content)
# 프로세스가 쓰기 도중 종료되면 파일이 부분 기록 → 손상
# 표준 관행: 임시 파일에 쓰고 → atomic rename
```

### 7.3 `_append_fact`의 조용한 데이터 손실

엔티티가 `live-notes/`에도 `entities/`에도 없으면 → 사실이 **조용히 버려짐** (에러 없음, 로그 없음, 반환값 없음).

---

## 8. 마케팅 vs 현실 (README 과장)

### 8.1 기능 과장

| README 주장 | 실제 구현 |
|-------------|-----------|
| "에이전틱 검색" | 정규식 쿼리 분해 + 그래프 탐색 (LLM 자율 판단 없음) |
| "자동 요약: 비대한 페이지 압축" | 기존 불릿 포인트를 HTML 주석으로 복사. 원본 내용 그대로 유지 |
| "팩트 중복 자동 감지 및 병합" | 감지만 수행, 병합하지 않음 (print만 출력) |
| "메모리가 복합적으로 축적" | 텍스트 단순 추가(append). 추론/관계 추출/스키마 진화 없음 |
| BM25 스타일 검색 | IDF만 구현, TF 정규화/문서 길이 정규화 없음 |

### 8.2 스텁/미완성 기능

| 기능 | 상태 |
|------|------|
| `cognify` 분류 | 4개 키워드 휴리스틱. ML/시맨틱 이해 없음 |
| `retro` 회고 | "fail"/"error" 포함 이벤트를 부정으로 분류. 극도로 단순 |
| `distill_decisions` | "decided"/"approved" 키워드 매칭만 수행 |
| 상태 전이 추적 | 4개 하드코딩 필드(Role, Affiliation, Status, Location)만 |

### 8.3 의심스러운 학술 인용

```python
# core.py line 431
# "Inspired by Recursive Language Models (Zhang et al., 2025)"
# arXiv:2512.24601 — 논문 제목과 저자가 검증 불가
# 4KB 임계값에 학술적 권위를 부여하려는 시도로 보임
```

### 8.4 빌드 시스템 불일치

| 파일 | `stopwords.json` 포함 |
|------|----------------------|
| `pyproject.toml` | O |
| `setup.py` | X |

`setup.py`로 빌드 시 불용어 파일 누락 → NER이 빈 리스트를 반환하며 조용히 성능 저하.

---

## 9. 종합 — 가장 심각한 문제 Top 10

| 순위 | 문제 | 심각도 | 분류 |
|------|------|--------|------|
| 1 | Path Traversal — `extract`로 시스템 파일 읽기 가능 | **Critical** | 보안 |
| 2 | 파일 락 없음 — 동시 사용 시 데이터 손실 | **High** | 무결성 |
| 3 | 한국어 NER 오탐율 극심 — 사실상 사용 불가 | **High** | 기능 |
| 4 | `track()` 성공 시 None 반환 — API 계약 위반 | **High** | 버그 |
| 5 | `decay()`가 마크다운 포맷 깨뜨림 | **High** | 버그 |
| 6 | 전체 파일 스캔 + 캐싱 없음 — 확장 불가 | **Medium** | 성능 |
| 7 | "에이전틱 검색" 마케팅 과장 | **Medium** | 신뢰성 |
| 8 | CLI 테스트 전무 + 어서션 없는 테스트 다수 | **Medium** | 품질 |
| 9 | 비원자적 파일 쓰기 — 중단 시 데이터 손상 | **Medium** | 무결성 |
| 10 | God Object 구조 — 유지보수/확장 곤란 | **Medium** | 구조 |
