"""Optional embedding-based semantic search.

Requires: pip install engram[semantic]
For embeddings API: pip install engram[llm]
"""

from __future__ import annotations

import json
import sqlite3
import struct
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from engram.models.entity import Entity, EntityState, Tier
from engram.models.search import SearchHit, SearchOptions, SearchResult


class SemanticSearch:
    """Embedding-based semantic search using numpy cosine similarity.

    Stores embeddings in a dedicated SQLite table alongside the main DB.
    For <10k entities, in-memory numpy comparison is fast enough.
    """

    def __init__(
        self,
        db_path: Path,
        embedding_provider: str = "openai",
        embedding_model: str = "text-embedding-3-small",
        embedding_dim: int = 1536,
    ):
        self.db_path = Path(db_path).resolve()
        self.embedding_provider = embedding_provider
        self.embedding_model = embedding_model
        self.embedding_dim = embedding_dim
        self._conn: Optional[sqlite3.Connection] = None
        self._client = None
        self._np = None

        try:
            import numpy as np
            self._np = np
        except ImportError:
            raise ImportError("numpy not installed. Run: pip install engram[semantic]")

        self._ensure_table()

    def _get_conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(str(self.db_path))
            self._conn.execute("PRAGMA busy_timeout=5000")
            self._conn.row_factory = sqlite3.Row
        return self._conn

    def _ensure_table(self) -> None:
        conn = self._get_conn()
        conn.execute("""
            CREATE TABLE IF NOT EXISTS embeddings (
                entity_id TEXT PRIMARY KEY,
                embedding BLOB NOT NULL,
                model TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        """)
        conn.commit()

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    def _get_embedding_client(self):
        """Lazy-load embedding API client."""
        if self._client is not None:
            return self._client
        if self.embedding_provider == "openai":
            try:
                from openai import OpenAI
                self._client = OpenAI()
            except ImportError:
                raise ImportError("OpenAI SDK not installed. Run: pip install engram[llm]")
        elif self.embedding_provider == "anthropic":
            raise NotImplementedError("Anthropic does not provide an embedding API. Use 'openai' provider.")
        return self._client

    def embed(self, text: str) -> bytes:
        """Compute embedding for text. Returns bytes (packed floats)."""
        client = self._get_embedding_client()
        response = client.embeddings.create(
            model=self.embedding_model,
            input=text[:8000],
        )
        vector = response.data[0].embedding
        return struct.pack(f"{len(vector)}f", *vector)

    def _bytes_to_vector(self, data: bytes):
        """Convert packed bytes back to numpy array."""
        n = len(data) // 4
        floats = struct.unpack(f"{n}f", data)
        return self._np.array(floats, dtype=self._np.float32)

    def index_entity(self, entity_id: str, text: str) -> None:
        """Compute and store embedding for an entity."""
        embedding_bytes = self.embed(text)
        conn = self._get_conn()
        conn.execute(
            """INSERT OR REPLACE INTO embeddings (entity_id, embedding, model, updated_at)
               VALUES (?, ?, ?, ?)""",
            (entity_id, embedding_bytes, self.embedding_model, datetime.now().isoformat()),
        )
        conn.commit()

    def remove_from_index(self, entity_id: str) -> None:
        conn = self._get_conn()
        conn.execute("DELETE FROM embeddings WHERE entity_id = ?", (entity_id,))
        conn.commit()

    def search(self, options: SearchOptions) -> SearchResult:
        """Semantic search using cosine similarity."""
        start = time.monotonic()
        np = self._np

        # Embed query
        query_bytes = self.embed(options.query)
        query_vec = self._bytes_to_vector(query_bytes)
        query_norm = np.linalg.norm(query_vec)
        if query_norm == 0:
            return SearchResult(query=options.query)

        query_vec = query_vec / query_norm

        # Load all embeddings
        conn = self._get_conn()
        rows = conn.execute("SELECT entity_id, embedding FROM embeddings").fetchall()

        if not rows:
            return SearchResult(query=options.query)

        # Compute cosine similarities
        scores: list[tuple[str, float]] = []
        for row in rows:
            vec = self._bytes_to_vector(row["embedding"])
            vec_norm = np.linalg.norm(vec)
            if vec_norm == 0:
                continue
            similarity = float(np.dot(query_vec, vec / vec_norm))
            scores.append((row["entity_id"], similarity))

        scores.sort(key=lambda x: x[1], reverse=True)
        scores = scores[:options.max_results]

        # Build hits
        hits: list[SearchHit] = []
        for entity_id, score in scores:
            entity_row = conn.execute(
                "SELECT * FROM entities WHERE id = ?", (entity_id,)
            ).fetchone()
            if not entity_row:
                continue

            state_data = json.loads(entity_row["state"]) if entity_row["state"] else {}
            entity = Entity(
                id=entity_row["id"],
                name=entity_row["name"],
                entity_type=entity_row["entity_type"],
                tier=Tier(entity_row["tier"]),
                summary=entity_row["summary"] or "",
                state=EntityState.from_dict(state_data),
            )

            hits.append(SearchHit(
                entity=entity,
                relevance_score=score,
                snippet=entity.summary[:200] if entity.summary else "",
            ))

        elapsed = (time.monotonic() - start) * 1000
        return SearchResult(
            query=options.query,
            hits=hits,
            total_count=len(hits),
            search_time_ms=round(elapsed, 2),
        )
