"""Hybrid search — Reciprocal Rank Fusion of FTS5 + semantic search."""

from __future__ import annotations

import time

from engram.models.search import SearchHit, SearchOptions, SearchResult
from engram.search.fts5_search import FTS5Search
from engram.search.semantic import SemanticSearch


class HybridSearch:
    """Reciprocal Rank Fusion (RRF) of keyword and semantic search.

    RRF score = sum over sources of 1 / (k + rank)
    where k=60 (standard constant).

    This is simple, effective, and well-studied — no learned weights needed.
    """

    def __init__(
        self,
        fts: FTS5Search,
        semantic: SemanticSearch,
        k: int = 60,
        fts_weight: float = 1.0,
        semantic_weight: float = 1.0,
    ):
        self.fts = fts
        self.semantic = semantic
        self.k = k
        self.fts_weight = fts_weight
        self.semantic_weight = semantic_weight

    def close(self) -> None:
        self.fts.close()
        self.semantic.close()

    def search(self, options: SearchOptions) -> SearchResult:
        """Execute hybrid search with RRF fusion."""
        start = time.monotonic()

        # Increase individual search limits to get better fusion
        expanded = SearchOptions(
            query=options.query,
            max_results=options.max_results * 3,
            max_tokens=0,  # No token limit for individual searches
            min_confidence=options.min_confidence,
            entity_types=options.entity_types,
            tiers=options.tiers,
            include_archived=options.include_archived,
        )

        # Run both searches
        fts_result = self.fts.search(expanded)
        sem_result = self.semantic.search(expanded)

        # RRF scoring
        scores: dict[str, float] = {}
        hit_map: dict[str, SearchHit] = {}

        for rank, hit in enumerate(fts_result.hits):
            eid = hit.entity.id
            scores[eid] = scores.get(eid, 0) + self.fts_weight / (self.k + rank + 1)
            if eid not in hit_map:
                hit_map[eid] = hit

        for rank, hit in enumerate(sem_result.hits):
            eid = hit.entity.id
            scores[eid] = scores.get(eid, 0) + self.semantic_weight / (self.k + rank + 1)
            if eid not in hit_map:
                hit_map[eid] = hit

        # Sort by RRF score
        sorted_ids = sorted(scores.keys(), key=lambda eid: scores[eid], reverse=True)
        sorted_ids = sorted_ids[:options.max_results]

        # Build final hits with token budget
        hits: list[SearchHit] = []
        total_tokens = 0
        for eid in sorted_ids:
            hit = hit_map[eid]
            hit.relevance_score = scores[eid]

            token_count = len(f"{hit.entity.name} {hit.snippet}") // 4
            if options.max_tokens > 0 and total_tokens + token_count > options.max_tokens:
                break
            hit.token_count = token_count
            hits.append(hit)
            total_tokens += token_count

        elapsed = (time.monotonic() - start) * 1000
        return SearchResult(
            query=options.query,
            hits=hits,
            total_count=len(scores),
            search_time_ms=round(elapsed, 2),
            total_tokens=total_tokens,
        )
