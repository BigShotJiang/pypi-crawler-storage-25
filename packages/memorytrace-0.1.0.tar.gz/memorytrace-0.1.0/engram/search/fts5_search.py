"""FTS5-based BM25 search — genuine Okapi BM25 via SQLite's built-in ranking."""

from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path
from typing import Optional

from engram.models.entity import Entity, EntityState, Tier
from engram.models.fact import Fact, FactStatus
from engram.models.search import SearchHit, SearchOptions, SearchResult
from engram.models.source import Source, SourceType
from engram.search.tokenizer import build_fts5_query


class FTS5Search:
    """Full-text search using SQLite FTS5's built-in BM25 ranking.

    FTS5 bm25() implements genuine Okapi BM25 with:
    - TF saturation (k1 parameter)
    - Document length normalization (b parameter)
    - IDF via document frequency counting

    Column weights (higher = more important):
    - entity_name: 10.0
    - summary: 5.0
    - fact_text: 3.0
    - state_text: 2.0
    - entity_type: 1.0
    - entity_id: 0.0 (not searchable)
    """

    # Column order in FTS table: entity_id, entity_name, entity_type, fact_text, state_text, summary
    # bm25() weights correspond to column order
    _BM25_WEIGHTS = (0.0, 10.0, 1.0, 3.0, 2.0, 5.0)
    _BM25_WEIGHTS_SQL = "0.0, 10.0, 1.0, 3.0, 2.0, 5.0"  # Pre-built constant for SQL

    def __init__(self, db_path: Path):
        self.db_path = Path(db_path).resolve()
        self._conn: Optional[sqlite3.Connection] = None

    def _get_conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(str(self.db_path))
            self._conn.execute("PRAGMA busy_timeout=5000")
            self._conn.row_factory = sqlite3.Row
        return self._conn

    def close(self) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    def search(self, options: SearchOptions) -> SearchResult:
        """Execute a BM25-ranked full-text search."""
        start = time.monotonic()

        fts_query = build_fts5_query(options.query)
        if not fts_query or fts_query == '""':
            return SearchResult(
                query=options.query,
                hits=[],
                total_count=0,
                search_time_ms=0.0,
            )

        conn = self._get_conn()

        # Search with BM25 ranking and join with entities table for full data
        # Weights are a class-level constant — never derived from user input
        sql = f"""
            SELECT
                e.*,
                bm25(memory_fts, {self._BM25_WEIGHTS_SQL}) AS rank,
                snippet(memory_fts, 3, '>>>', '<<<', '...', 40) AS snippet
            FROM memory_fts fts
            JOIN entities e ON e.id = fts.entity_id
            WHERE memory_fts MATCH ?
        """
        params: list = [fts_query]

        # Apply filters
        if options.entity_types:
            placeholders = ",".join("?" for _ in options.entity_types)
            sql += f" AND e.entity_type IN ({placeholders})"
            params.extend(options.entity_types)

        if options.tiers:
            placeholders = ",".join("?" for _ in options.tiers)
            sql += f" AND e.tier IN ({placeholders})"
            params.extend(options.tiers)

        if not options.include_archived:
            sql += " AND e.tier != 'archival'"

        if options.date_from:
            sql += " AND e.updated_at >= ?"
            params.append(options.date_from.isoformat())

        if options.date_to:
            sql += " AND e.updated_at <= ?"
            params.append(options.date_to.isoformat())

        sql += " ORDER BY rank LIMIT ?"
        params.append(options.max_results)

        try:
            rows = conn.execute(sql, params).fetchall()
        except sqlite3.OperationalError as e:
            err_msg = str(e).lower()
            # Only swallow FTS5 query syntax errors; re-raise others
            if "fts5" in err_msg or "syntax" in err_msg or "parse" in err_msg:
                return SearchResult(
                    query=options.query,
                    hits=[],
                    total_count=0,
                    search_time_ms=(time.monotonic() - start) * 1000,
                )
            raise

        # Build hits
        hits: list[SearchHit] = []
        total_tokens = 0

        for row in rows:
            entity = self._row_to_entity(row)
            snippet = row["snippet"] if row["snippet"] else ""
            # Clean snippet markers
            snippet = snippet.replace(">>>", "").replace("<<<", "")

            # Load facts for this entity if within confidence threshold
            facts = self._get_entity_facts(
                conn, entity.id, options.min_confidence
            )

            # Estimate token count (1 token ≈ 4 chars)
            entry_text = f"{entity.name} {snippet} {' '.join(f.raw_text for f in facts[:3])}"
            token_count = len(entry_text) // 4

            # Check token budget (max_tokens <= 0 means unlimited)
            if options.max_tokens > 0 and total_tokens + token_count > options.max_tokens:
                break

            hits.append(SearchHit(
                entity=entity,
                facts=facts[:5],  # Limit facts per hit
                relevance_score=abs(row["rank"]),  # bm25() returns negative scores
                snippet=snippet,
                token_count=token_count,
            ))
            total_tokens += token_count

        elapsed = (time.monotonic() - start) * 1000

        return SearchResult(
            query=options.query,
            hits=hits,
            total_count=len(rows),  # Total DB matches (may exceed len(hits) due to token budget)
            search_time_ms=round(elapsed, 2),
            total_tokens=total_tokens,
        )

    def _get_entity_facts(
        self, conn: sqlite3.Connection, entity_id: str, min_confidence: float
    ) -> list[Fact]:
        """Load current facts for an entity, filtered by confidence."""
        rows = conn.execute(
            """SELECT * FROM facts
               WHERE entity_id = ? AND valid_to IS NULL AND superseded_by IS NULL
               AND status NOT IN ('expired', 'retracted', 'conflicted')
               AND confidence >= ?
               ORDER BY confidence DESC, created_at DESC
               LIMIT 10""",
            (entity_id, min_confidence),
        ).fetchall()

        facts = []
        for r in rows:
            facts.append(Fact(
                id=r["id"],
                entity_id=r["entity_id"],
                subject=r["subject"],
                predicate=r["predicate"],
                object=r["object"],
                raw_text=r["raw_text"],
                source=Source(
                    type=SourceType(r["source_type"]),
                    author=r["source_author"] or "",
                    channel=r["source_channel"] or "",
                ),
                confidence=r["confidence"],
                status=FactStatus(r["status"]),
            ))
        return facts

    def _row_to_entity(self, row: sqlite3.Row) -> Entity:
        """Convert a joined row to Entity model."""
        state_data = json.loads(row["state"]) if row["state"] else {}
        return Entity(
            id=row["id"],
            name=row["name"],
            entity_type=row["entity_type"],
            tier=Tier(row["tier"]),
            summary=row["summary"] or "",
            aliases=json.loads(row["aliases"]) if row["aliases"] else [],
            state=EntityState.from_dict(state_data),
            access_count=row["access_count"] or 0,
        )
