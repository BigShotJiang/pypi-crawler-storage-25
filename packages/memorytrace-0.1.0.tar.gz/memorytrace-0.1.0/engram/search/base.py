"""Search backend protocol."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from engram.models.search import SearchOptions, SearchResult


@runtime_checkable
class SearchBackend(Protocol):
    """Abstract search interface — all search backends implement this."""

    def search(self, options: SearchOptions) -> SearchResult: ...

    def index_entity(self, entity_id: str) -> None: ...

    def remove_from_index(self, entity_id: str) -> None: ...

    def reindex_all(self) -> int: ...
