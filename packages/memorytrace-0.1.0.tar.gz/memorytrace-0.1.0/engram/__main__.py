"""Allow running as `python -m engram`."""

from engram.cli.app import main

if __name__ == "__main__":
    main()
