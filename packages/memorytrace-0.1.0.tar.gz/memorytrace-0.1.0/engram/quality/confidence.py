"""Confidence scoring for facts based on source type and extraction method."""

from __future__ import annotations

from engram.models.source import SourceType

# Base trust per source type
_SOURCE_BASE: dict[SourceType, float] = {
    SourceType.DIRECT_SPEECH: 0.95,
    SourceType.USER_INPUT: 0.90,
    SourceType.DOCUMENT: 0.85,
    SourceType.API: 0.80,
    SourceType.WEB: 0.60,
    SourceType.AGENT_INFERENCE: 0.40,
}

# Multiplier per extraction method
_EXTRACTION_MULT: dict[str, float] = {
    "regex": 0.7,
    "llm": 1.0,
    "manual": 1.0,
}


def compute_confidence(
    source_type: SourceType,
    source_confidence: float,
    extraction_method: str = "manual",
) -> float:
    """Compute final confidence score for a fact.

    confidence = base_trust(source_type) × source_confidence × extraction_multiplier
    Result is clamped to [0.0, 1.0].
    """
    base = _SOURCE_BASE.get(source_type, 0.5)
    method_mult = _EXTRACTION_MULT.get(extraction_method, 0.7)
    raw = base * max(0.0, min(1.0, source_confidence)) * method_mult
    return max(0.0, min(1.0, round(raw, 4)))
