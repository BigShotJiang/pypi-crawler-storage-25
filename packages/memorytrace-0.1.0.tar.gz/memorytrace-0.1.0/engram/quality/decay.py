"""Time-based decay — identifies stale facts that need review."""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Optional

from engram.models.fact import Fact


def find_stale_facts(
    facts: list[Fact],
    days: int = 90,
    reference_time: Optional[datetime] = None,
) -> list[Fact]:
    """Find facts that haven't been updated within the given period.

    Args:
        facts: Facts to check.
        days: Number of days before a fact is considered stale.
        reference_time: Time to compare against (default: now).

    Returns:
        List of stale facts.
    """
    now = reference_time or datetime.now()
    cutoff = now - timedelta(days=days)
    return [f for f in facts if f.is_current and f.created_at < cutoff]
