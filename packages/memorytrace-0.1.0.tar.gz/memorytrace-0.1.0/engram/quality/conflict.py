"""Conflict detection — finds when new facts contradict existing ones."""

from __future__ import annotations

import uuid

from engram.models.fact import Fact
from engram.models.quality import ConflictInfo
from engram.storage.base import StorageBackend


class ConflictDetector:
    """Detects when a new fact contradicts existing facts for the same entity+predicate."""

    def __init__(self, storage: StorageBackend):
        self.storage = storage

    def find_conflicts(self, new_fact: Fact) -> list[ConflictInfo]:
        """Check if new_fact conflicts with any current facts.

        A conflict occurs when:
        - Same entity_id AND same predicate
        - Different object value
        - Both are currently valid (valid_to is None)
        """
        existing = self.storage.get_current_facts(new_fact.entity_id)
        conflicts: list[ConflictInfo] = []

        for old in existing:
            if old.id == new_fact.id:
                continue
            if not self._same_predicate(new_fact, old):
                continue
            if self._same_object(new_fact, old):
                continue

            # Conflict found
            resolution = self._suggest_resolution(old, new_fact)
            conflicts.append(ConflictInfo(
                conflict_id=str(uuid.uuid4()),
                existing_fact=old,
                new_fact=new_fact,
                conflict_type="value_change",
                suggested_resolution=resolution,
            ))

        return conflicts

    def is_duplicate(self, new_fact: Fact) -> bool:
        """Check if an identical fact already exists (same entity+predicate+object)."""
        existing = self.storage.get_current_facts(new_fact.entity_id)
        for old in existing:
            if self._same_predicate(new_fact, old) and self._same_object(new_fact, old):
                return True
        return False

    def _same_predicate(self, a: Fact, b: Fact) -> bool:
        """Check if two facts refer to the same predicate (case-insensitive)."""
        return a.predicate.strip().lower() == b.predicate.strip().lower()

    def _same_object(self, a: Fact, b: Fact) -> bool:
        """Check if two facts have the same value (case-insensitive, normalized)."""
        import re
        norm_a = re.sub(r'\b(the|a|an)\b', '', a.object.strip().lower()).strip()
        norm_b = re.sub(r'\b(the|a|an)\b', '', b.object.strip().lower()).strip()
        return norm_a == norm_b

    def _suggest_resolution(self, old: Fact, new: Fact) -> str:
        """Suggest how to resolve a conflict based on trust scores."""
        old_trust = old.source.trust_score
        new_trust = new.source.trust_score

        trust_diff = new_trust - old_trust
        if trust_diff > 0.3:
            return "supersede"
        elif trust_diff < -0.3:
            return "keep_old"
        else:
            return "manual_review"
