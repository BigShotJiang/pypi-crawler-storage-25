"""PII (Personally Identifiable Information) detection and masking."""

from __future__ import annotations

import re
from typing import Optional

from engram.models.quality import PIIMatch

# PII detection patterns
_PII_PATTERNS: dict[str, re.Pattern] = {
    "credit_card": re.compile(
        r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b'
    ),
    "ssn": re.compile(
        r'\b\d{3}-\d{2}-\d{4}\b'
    ),
    "api_key": re.compile(
        r'\b(?:sk-|ak-|AKIA|ghp_|gho_|github_pat_)[A-Za-z0-9_\-]{20,}\b'
    ),
    "email": re.compile(
        r'\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Z|a-z]{2,}\b'
    ),
    "phone_kr": re.compile(
        r'\b0\d{1,2}-\d{3,4}-\d{4}\b'
    ),
    "phone_intl": re.compile(
        r'\+\d{1,3}[-\s]?\d{1,4}[-\s]?\d{3,4}[-\s]?\d{4}\b'
    ),
    "rrn": re.compile(
        # Korean Resident Registration Number (주민등록번호)
        r'\b\d{6}[-\s]?[1-4]\d{6}\b'
    ),
}

_REDACTED = "[REDACTED]"


class PIIDetector:
    """Detects and masks PII in text."""

    def scan(self, text: str) -> list[PIIMatch]:
        """Scan text for PII patterns. Returns list of matches."""
        matches: list[PIIMatch] = []
        for pii_type, pattern in _PII_PATTERNS.items():
            for m in pattern.finditer(text):
                # Store only type and length, not the original PII value
                original_display = f"[{pii_type}:{len(m.group())}chars]"
                matches.append(PIIMatch(
                    pii_type=pii_type,
                    start=m.start(),
                    end=m.end(),
                    original=original_display,
                ))
        # Sort by position (reverse for safe replacement)
        matches.sort(key=lambda x: x.start)
        return matches

    def mask(self, text: str, matches: Optional[list[PIIMatch]] = None) -> str:
        """Replace PII occurrences with [REDACTED].

        If matches not provided, scans first.
        """
        if matches is None:
            matches = self.scan(text)
        if not matches:
            return text

        # Replace from end to start to preserve positions
        result = text
        for m in sorted(matches, key=lambda x: x.start, reverse=True):
            result = result[:m.start] + _REDACTED + result[m.end:]
        return result

    def has_pii(self, text: str) -> bool:
        """Quick check: does text contain any PII?"""
        for pattern in _PII_PATTERNS.values():
            if pattern.search(text):
                return True
        return False
