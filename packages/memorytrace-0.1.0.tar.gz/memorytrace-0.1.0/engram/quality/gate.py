"""Quality gate — pipeline orchestrator for write validation."""

from __future__ import annotations

from engram.config import EngramConfig
from engram.models.fact import Fact, FactStatus
from engram.models.quality import Action, ConflictInfo, ValidationResult
from engram.quality.confidence import compute_confidence
from engram.quality.conflict import ConflictDetector
from engram.quality.pii import PIIDetector
from engram.storage.base import StorageBackend


class QualityGate:
    """Pipeline: confidence → PII masking → conflict detection → accept/reject/quarantine.

    Every write operation passes through this gate before reaching storage.
    """

    def __init__(self, config: EngramConfig, storage: StorageBackend):
        self.config = config
        self.conflict_detector = ConflictDetector(storage)
        self.pii_detector = PIIDetector()
        self.min_confidence = config.min_confidence
        self.auto_resolve_threshold = config.auto_resolve_threshold
        self.enable_pii = config.enable_pii_detection

    def validate(
        self,
        fact: Fact,
        extraction_method: str = "manual",
    ) -> ValidationResult:
        """Run the full quality gate pipeline on a fact.

        Returns ValidationResult with action:
        - ACCEPT: fact is good, store it
        - QUARANTINE: low confidence, store as unverified
        - FLAG_CONFLICT: conflicts with existing data
        - REJECT: should not be stored (e.g., all PII with no substance)
        """

        # Step 1: Compute confidence
        computed_conf = compute_confidence(
            source_type=fact.source.type,
            source_confidence=fact.source.confidence,
            extraction_method=extraction_method,
        )
        fact.confidence = computed_conf

        # Step 2: PII detection and masking
        pii_matches = []
        masked_text = None
        if self.enable_pii and fact.raw_text:
            pii_matches = self.pii_detector.scan(fact.raw_text)
            if pii_matches:
                masked_text = self.pii_detector.mask(fact.raw_text, pii_matches)
                fact.raw_text = masked_text
                # Also mask subject/object if they contain PII
                if self.pii_detector.has_pii(fact.object):
                    fact.object = self.pii_detector.mask(fact.object)
                if self.pii_detector.has_pii(fact.subject):
                    fact.subject = self.pii_detector.mask(fact.subject)

        # Step 3: Confidence threshold check
        if computed_conf < self.min_confidence:
            fact.status = FactStatus.UNVERIFIED
            return ValidationResult(
                action=Action.QUARANTINE,
                reason=f"Confidence {computed_conf:.2f} below threshold {self.min_confidence:.2f}",
                confidence=computed_conf,
                pii_matches=pii_matches,
                masked_text=masked_text,
            )

        # Step 3.5: Duplicate detection
        if fact.entity_id and self.conflict_detector.is_duplicate(fact):
            return ValidationResult(
                action=Action.REJECT,
                reason="Duplicate fact already exists",
                confidence=computed_conf,
                pii_matches=pii_matches,
                masked_text=masked_text,
            )

        # Step 4: Conflict detection
        if fact.entity_id:
            conflicts = self.conflict_detector.find_conflicts(fact)
            if conflicts:
                # Check if we can auto-resolve
                auto_resolved = self._try_auto_resolve(conflicts)
                if not auto_resolved:
                    fact.status = FactStatus.CONFLICTED
                    return ValidationResult(
                        action=Action.FLAG_CONFLICT,
                        reason=f"Conflicts with {len(conflicts)} existing fact(s)",
                        confidence=computed_conf,
                        conflicts=conflicts,
                        pii_matches=pii_matches,
                        masked_text=masked_text,
                    )

        # Step 5: Accept
        return ValidationResult(
            action=Action.ACCEPT,
            reason="Passed all quality checks",
            confidence=computed_conf,
            pii_matches=pii_matches,
            masked_text=masked_text,
        )

    def _try_auto_resolve(self, conflicts: list[ConflictInfo]) -> bool:
        """Attempt to auto-resolve conflicts if trust difference is large enough."""
        all_resolved = True
        for conflict in conflicts:
            if conflict.suggested_resolution == "supersede":
                # New fact has much higher trust — auto-supersede
                continue
            else:
                all_resolved = False
        return all_resolved
