"""Engram exception hierarchy."""


class EngramError(Exception):
    """Base exception for all Engram errors."""


class EntityNotFoundError(EngramError):
    """Raised when an entity lookup fails."""


class EntityAlreadyExistsError(EngramError):
    """Raised when creating an entity that already exists."""


class StorageError(EngramError):
    """Raised on storage backend failures (I/O, corruption, etc.)."""


class ValidationError(EngramError):
    """Raised when data fails quality gate validation."""


class ConflictError(EngramError):
    """Raised when a fact conflicts with existing data."""


class SessionError(EngramError):
    """Raised on session lifecycle errors."""


class ConfigError(EngramError):
    """Raised on configuration errors."""


class ExtractionError(EngramError):
    """Raised when entity/fact extraction fails."""


class SecurityError(EngramError):
    """Raised on security violations (path traversal, etc.)."""
