"""Fact data models with temporal dimension."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional

from engram.models.source import Source


class FactStatus(str, Enum):
    UNVERIFIED = "unverified"
    VERIFIED = "verified"
    CONFLICTED = "conflicted"
    EXPIRED = "expired"
    RETRACTED = "retracted"


@dataclass
class Fact:
    """A single piece of knowledge about an entity, with provenance and temporal bounds."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    entity_id: str = ""
    subject: str = ""
    predicate: str = ""
    object: str = ""
    raw_text: str = ""
    source: Source = field(default_factory=Source)
    confidence: float = 0.5
    status: FactStatus = FactStatus.UNVERIFIED
    valid_from: Optional[datetime] = None
    valid_to: Optional[datetime] = None  # None = currently valid
    superseded_by: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)

    def __post_init__(self) -> None:
        self.confidence = max(0.0, min(1.0, self.confidence))

    @property
    def is_current(self) -> bool:
        """Whether this fact is currently valid (not expired or superseded)."""
        if self.valid_to is not None:
            return False
        if self.superseded_by is not None:
            return False
        if self.status in (FactStatus.EXPIRED, FactStatus.RETRACTED):
            return False
        return True

    def supersede(self, new_fact_id: str) -> None:
        """Mark this fact as superseded by another."""
        self.superseded_by = new_fact_id
        self.valid_to = datetime.now()
        self.status = FactStatus.EXPIRED
