"""Search-related data models."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from engram.models.entity import Entity
from engram.models.fact import Fact


@dataclass
class SearchOptions:
    """Options for a memory search query."""

    query: str = ""
    max_results: int = 10
    max_tokens: int = 500  # token budget for agent context
    min_confidence: float = 0.0
    entity_types: list[str] = field(default_factory=list)
    tiers: list[str] = field(default_factory=list)
    date_from: Optional[datetime] = None
    date_to: Optional[datetime] = None
    include_archived: bool = False


@dataclass
class SearchHit:
    """A single search result."""

    entity: Entity
    facts: list[Fact] = field(default_factory=list)
    relevance_score: float = 0.0
    snippet: str = ""
    token_count: int = 0


@dataclass
class SearchResult:
    """Complete search response."""

    query: str = ""
    hits: list[SearchHit] = field(default_factory=list)
    total_count: int = 0
    search_time_ms: float = 0.0
    total_tokens: int = 0

    def to_agent_context(self, max_tokens: int = 500) -> str:
        """Serialize to compact text for LLM context injection."""
        if not self.hits:
            return f"No results found for '{self.query}'."

        parts: list[str] = []
        tokens_used = 0
        for hit in self.hits:
            entry = f"[{hit.entity.name}] ({hit.entity.entity_type})"
            if hit.entity.state.role:
                entry += f" Role: {hit.entity.state.role}"
            if hit.entity.state.affiliation:
                entry += f" @ {hit.entity.state.affiliation}"
            if hit.snippet:
                entry += f" | {hit.snippet}"
            # Rough token estimate: 1 token ≈ 4 chars
            entry_tokens = len(entry) // 4
            if tokens_used + entry_tokens > max_tokens:
                break
            parts.append(entry)
            tokens_used += entry_tokens

        return "\n".join(parts)

    def to_dict(self) -> dict:
        """Structured dict for MCP/SDK responses."""
        return {
            "query": self.query,
            "total_count": self.total_count,
            "search_time_ms": self.search_time_ms,
            "hits": [
                {
                    "entity_name": h.entity.name,
                    "entity_type": h.entity.entity_type,
                    "relevance_score": h.relevance_score,
                    "snippet": h.snippet,
                    "facts": [
                        {"text": f.raw_text, "confidence": f.confidence, "status": f.status.value}
                        for f in h.facts
                    ],
                }
                for h in self.hits
            ],
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=indent)
