"""Session and session event models."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class Session:
    """A conversation session with an AI agent."""

    session_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    agent_id: str = "default"
    started_at: datetime = field(default_factory=datetime.now)
    ended_at: Optional[datetime] = None
    parent_session_id: Optional[str] = None
    entities_accessed: list[str] = field(default_factory=list)
    entities_modified: list[str] = field(default_factory=list)
    facts_added: list[str] = field(default_factory=list)
    summary: Optional[str] = None
    metadata: dict = field(default_factory=dict)

    @property
    def is_active(self) -> bool:
        return self.ended_at is None

    @property
    def duration_seconds(self) -> Optional[float]:
        if self.ended_at is None:
            return None
        return (self.ended_at - self.started_at).total_seconds()

    @property
    def duration_minutes(self) -> Optional[float]:
        secs = self.duration_seconds
        if secs is None:
            return None
        return round(secs / 60, 1)


@dataclass
class SessionEvent:
    """An auditable event within a session."""

    id: Optional[int] = None  # auto-increment in DB
    session_id: str = ""
    event_type: str = ""  # search, read, write, update, delete
    target: str = ""  # entity_id or query string
    detail: dict = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
