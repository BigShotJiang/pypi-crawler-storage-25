"""Quality gate data models."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from engram.models.fact import Fact


class Action(str, Enum):
    ACCEPT = "accept"
    QUARANTINE = "quarantine"
    FLAG_CONFLICT = "flag_conflict"
    REJECT = "reject"


@dataclass
class ConflictInfo:
    """Information about a data conflict between facts."""

    conflict_id: str = ""
    existing_fact: Optional[Fact] = None
    new_fact: Optional[Fact] = None
    conflict_type: str = ""  # value_change, contradiction
    suggested_resolution: str = ""  # supersede, manual_review, keep_old


@dataclass
class PIIMatch:
    """A detected PII occurrence in text."""

    pii_type: str = ""  # credit_card, ssn, api_key, email, phone, rrn
    start: int = 0
    end: int = 0
    original: str = ""


@dataclass
class ValidationResult:
    """Result of quality gate validation."""

    action: Action = Action.ACCEPT
    reason: str = ""
    confidence: float = 0.0
    conflicts: list[ConflictInfo] = field(default_factory=list)
    pii_matches: list[PIIMatch] = field(default_factory=list)
    masked_text: Optional[str] = None  # text after PII masking

    @property
    def is_accepted(self) -> bool:
        return self.action == Action.ACCEPT

    @property
    def is_quarantined(self) -> bool:
        return self.action == Action.QUARANTINE

    @property
    def has_conflicts(self) -> bool:
        return self.action == Action.FLAG_CONFLICT
