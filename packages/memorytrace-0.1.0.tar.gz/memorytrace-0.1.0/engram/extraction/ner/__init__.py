"""Named Entity Recognition modules."""

from engram.extraction.ner.english import extract_english_entities
from engram.extraction.ner.korean import extract_korean_entities
from engram.extraction.ner.cjk import extract_cjk_entities

__all__ = ["extract_english_entities", "extract_korean_entities", "extract_cjk_entities"]
