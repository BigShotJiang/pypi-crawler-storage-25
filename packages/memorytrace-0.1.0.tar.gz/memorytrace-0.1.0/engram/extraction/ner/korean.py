"""Korean named entity recognition — dictionary + pattern based."""

from __future__ import annotations

import re

from engram.models.entity import Entity

# Common Korean surnames (top ~100)
_KOREAN_SURNAMES = frozenset({
    "김", "이", "박", "최", "정", "강", "조", "윤", "장", "임",
    "한", "오", "서", "신", "권", "황", "안", "송", "류", "전",
    "홍", "고", "문", "양", "손", "배", "백", "허", "유", "남",
    "심", "노", "하", "곽", "성", "차", "주", "우", "구", "민",
    "진", "나", "지", "엄", "채", "원", "천", "방", "공", "현",
    "함", "변", "염", "석", "선", "설", "마", "길", "연", "위",
    "표", "명", "기", "반", "라", "왕", "금", "옥", "육", "추",
    "탁", "도", "감", "봉", "모", "맹", "제", "빈", "판", "피",
    "섭", "어", "음", "사", "가", "복", "태", "목", "형", "편",
    "승", "뇌", "범", "상", "갈", "예", "경", "럼", "온", "소",
})

# Korean organization keywords
_KR_ORG_KEYWORDS = frozenset({
    "주식회사", "재단", "협회", "학회", "그룹", "홀딩스", "파트너스",
    "캐피탈", "벤처스", "랩", "랩스", "연구소", "대학교", "대학",
    "병원", "은행", "증권", "보험", "카드",
})

# Korean particles (조사) — must be stripped from name boundary
# Pre-sorted by length (longest first) for greedy matching
_KR_PARTICLES = tuple(sorted(
    ("은", "는", "이", "가", "을", "를", "의", "에", "와", "과",
     "도", "만", "으로", "로", "에서", "부터", "까지", "라고",
     "에게", "한테", "께서"),
    key=len, reverse=True,
))

# Pattern: Organization with keywords (keyword embedded or after space)
_KR_ORG_PATTERN = re.compile(
    r'((?:[가-힣A-Za-z]{1,15})\s*(?:' + '|'.join(sorted(_KR_ORG_KEYWORDS, key=len, reverse=True)) + r'))'
)

# Common Korean words that are NOT names (extended stopwords for NER)
_KR_NOT_NAMES = frozenset({
    "오늘", "내일", "어제", "우리", "저희", "여기", "거기", "저기",
    "이번", "다음", "지난", "올해", "작년", "내년", "현재", "최근",
    "모든", "많은", "새로", "다른", "같은", "이런", "그런", "저런",
    "하지", "그리", "따라", "또한", "그래", "아직", "이미", "바로",
    "서로", "다시", "매우", "아주", "정말", "진짜", "너무", "가장",
    "회의", "미팅", "보고", "발표", "논의", "결정", "진행", "완료",
    "사업", "투자", "개발", "관리", "운영", "성장", "확대", "축소",
    "기술", "시스템", "서비스", "플랫", "데이", "프로", "소프",
    "문제", "해결", "방안", "계획", "목표", "전략", "방향", "결과",
    "서비", "기업", "시장", "제품", "고객", "매출", "수익",
    "함께", "시작", "종료", "변경",
    "연구", "조사", "분석", "검토", "평가", "보완", "개선", "추진",
    "진행", "참석", "참여", "준비", "완료", "예정", "필요", "가능",
    "이다", "하다", "되다", "있다", "없다", "이며", "으며", "라고",
})


def extract_korean_entities(text: str) -> list[Entity]:
    """Extract Korean named entities from text.

    Uses surname dictionary + syllable count for person names.
    Uses organization keywords for organizations.
    """
    entities: list[Entity] = []
    seen_names: set[str] = set()

    # Pass 1: Organizations with keywords
    for m in _KR_ORG_PATTERN.finditer(text):
        org_name = m.group(0).strip()
        if org_name.lower() not in seen_names:
            seen_names.add(org_name.lower())
            entities.append(Entity(name=org_name, entity_type="organization"))

    # Pass 2: Korean person names (surname + given name)
    # Split text by spaces/punctuation, then check each word
    words = re.findall(r'[가-힣]+', text)
    for word in words:
        name = _strip_particles(word)
        if len(name) < 2 or len(name) > 3:
            continue
        surname = name[0]
        if surname not in _KOREAN_SURNAMES:
            continue
        if name in _KR_NOT_NAMES:
            continue
        if name.lower() in seen_names:
            continue

        seen_names.add(name.lower())
        entities.append(Entity(name=name, entity_type="person"))

    return entities


def _strip_particles(word: str) -> str:
    """Strip trailing Korean particles (조사) from a word."""
    # _KR_PARTICLES is pre-sorted longest first
    for particle in _KR_PARTICLES:
        if word.endswith(particle) and len(word) > len(particle):
            return word[:-len(particle)]
    return word
