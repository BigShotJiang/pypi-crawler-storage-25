"""English named entity recognition — context-aware pattern matching."""

from __future__ import annotations

import re

from engram.models.entity import Entity

# Titles that precede names
_TITLES = frozenset({
    "mr", "mrs", "ms", "dr", "prof", "professor", "sir", "lady",
    "president", "ceo", "cto", "cfo", "coo", "vp", "director",
})

# Words that look like names but aren't (expanded blocklist)
_BLOCKLIST = frozenset({
    # Common section headers / phrases
    "key points", "executive summary", "see also", "last updated",
    "time line", "timeline", "action items", "next steps", "open loops",
    "north america", "south america", "south korea", "north korea",
    "new york", "los angeles", "san francisco", "san diego", "san jose",
    "las vegas", "el paso", "hong kong", "sri lanka", "costa rica",
    "buenos aires", "rio grande", "cape town", "new zealand",
    "united states", "united kingdom", "saudi arabia", "south africa",
    # Tech / product terms
    "machine learning", "deep learning", "artificial intelligence",
    "open source", "real time", "high quality", "best practice",
    "cloud computing", "data science", "big data",
    # Common false positives
    "thank you", "good morning", "good afternoon", "good evening",
    "happy new", "merry christmas", "looking forward",
})

# Organization suffixes
_ORG_SUFFIXES = re.compile(
    r'\b(Inc\.?|Corp\.?|Ltd\.?|LLC|GmbH|Co\.|Foundation|Association'
    r'|Institute|University|Partners|Capital|Ventures|Labs?|Group'
    r'|Holdings|Technologies|Solutions|Networks|Studios?)\b',
    re.IGNORECASE,
)

# Pattern: Two or three consecutive capitalized words
# Use lookahead instead of \b for CJK-mixed text compatibility
_NAME_PATTERN = re.compile(
    r'(?<![a-zA-Z])([A-Z][a-z]{1,15}(?:\s+[A-Z][a-z]{1,15}){1,2})(?![a-zA-Z])'
)

# Pattern: Title + Name
_TITLED_NAME = re.compile(
    r'\b(?:Mr|Mrs|Ms|Dr|Prof|CEO|CTO)\.\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,2})\b'
)


def extract_english_entities(text: str) -> list[Entity]:
    """Extract English named entities from text.

    Uses context clues to classify as person vs organization:
    - Organization suffixes (Inc., Corp., Foundation, etc.) → organization
    - Title prefixes (Dr., CEO, etc.) → person
    - Default for capitalized name pairs → person
    """
    entities: list[Entity] = []
    seen_names: set[str] = set()

    # Pass 1: Titled names (high confidence)
    for m in _TITLED_NAME.finditer(text):
        name = m.group(1).strip()
        normalized = name.lower()
        if normalized not in seen_names and normalized not in _BLOCKLIST:
            seen_names.add(normalized)
            entities.append(Entity(name=name, entity_type="person"))

    # Pass 2: Organizations (suffix-based)
    for m in _ORG_SUFFIXES.finditer(text):
        # Look backwards for the organization name
        start = max(0, m.start() - 60)
        prefix = text[start:m.end()]
        org_match = re.search(
            r'([A-Z][A-Za-z]*(?:\s+[A-Z][A-Za-z]*)*\s+' + re.escape(m.group()) + r')',
            prefix,
        )
        if org_match:
            name = org_match.group(1).strip()
            normalized = name.lower()
            # Skip very short org names (likely false positives like "Buterin co")
            name_without_suffix = name.rsplit(None, 1)[0] if " " in name else name
            if len(name_without_suffix) < 3:
                continue
            if normalized not in seen_names:
                seen_names.add(normalized)
                entities.append(Entity(name=name, entity_type="organization"))

    # Pass 3: Capitalized name pairs (default → person)
    for m in _NAME_PATTERN.finditer(text):
        name = m.group(1).strip()
        normalized = name.lower()
        if normalized in seen_names:
            continue
        if normalized in _BLOCKLIST:
            continue
        # Skip if it's at start of sentence (could be regular words)
        pos = m.start()
        if pos > 0 and text[pos - 1] in '.!?\n':
            # Sentence start — lower confidence, still extract
            pass
        seen_names.add(normalized)
        entities.append(Entity(name=name, entity_type="person"))

    return entities
