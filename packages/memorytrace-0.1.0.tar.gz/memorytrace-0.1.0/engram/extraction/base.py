"""Extractor protocol — the contract all extractors implement."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from engram.models.entity import Entity
from engram.models.fact import Fact
from engram.models.relation import Relation


@runtime_checkable
class Extractor(Protocol):
    """Abstract extraction interface."""

    def extract_entities(self, text: str) -> list[Entity]: ...

    def extract_facts(self, text: str, entities: list[Entity]) -> list[Fact]: ...

    def extract_relations(self, text: str, entities: list[Entity]) -> list[Relation]: ...
