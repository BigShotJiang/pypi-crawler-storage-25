"""LLM-based extractor — high-quality extraction using Claude or GPT.

Requires: pip install engram[llm]
"""

from __future__ import annotations

import json
from typing import Optional

from engram.models.entity import Entity
from engram.models.fact import Fact
from engram.models.relation import Relation

_VALID_ENTITY_TYPES = frozenset({"person", "organization", "project", "concept"})
_MAX_NAME_LENGTH = 100

_ENTITY_PROMPT = """Extract named entities from the following text.
Return a JSON array of objects with fields: name, entity_type (person/organization/project/concept).
Only extract clearly identifiable entities. Do not guess.

Text:
{text}

Return ONLY the JSON array, no other text."""

_FACT_PROMPT = """Given the following text and known entities, extract factual statements.
Return a JSON array of objects with fields: subject, predicate, object, raw_text, confidence (0.0-1.0).

Known entities: {entities}

Text:
{text}

Return ONLY the JSON array, no other text."""

_RELATION_PROMPT = """Given the following text and known entities, extract relationships between entities.
Return a JSON array of objects with fields: from_name, to_name, relation_type (e.g., CEO_OF, WORKS_AT, INVESTED_IN).

Known entities: {entities}

Text:
{text}

Return ONLY the JSON array, no other text."""


class LLMExtractor:
    """LLM-based entity, fact, and relation extraction.

    Uses Claude (Anthropic) or GPT (OpenAI) for high-quality extraction.
    Falls back gracefully if API calls fail.
    """

    def __init__(
        self,
        provider: str = "anthropic",
        model: Optional[str] = None,
    ):
        self.provider = provider
        self._client = None

        if provider == "anthropic":
            self.model = model or "claude-sonnet-4-6"
            try:
                from anthropic import Anthropic
                self._client = Anthropic()
            except ImportError:
                raise ImportError(
                    "Anthropic SDK not installed. Run: pip install engram[llm]"
                )
        elif provider == "openai":
            self.model = model or "gpt-4o-mini"
            try:
                from openai import OpenAI
                self._client = OpenAI()
            except ImportError:
                raise ImportError(
                    "OpenAI SDK not installed. Run: pip install engram[llm]"
                )
        else:
            raise ValueError(f"Unknown provider: {provider}. Use 'anthropic' or 'openai'.")

    def _call_llm(self, prompt: str) -> str:
        """Call the LLM and return the response text."""
        if self.provider == "anthropic":
            response = self._client.messages.create(
                model=self.model,
                max_tokens=2048,
                messages=[{"role": "user", "content": prompt}],
            )
            return response.content[0].text
        else:
            response = self._client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=2048,
            )
            return response.choices[0].message.content or ""

    def _parse_json_response(self, text: str) -> list:
        """Parse JSON from LLM response, handling markdown code blocks."""
        text = text.strip()
        if text.startswith("```"):
            lines = text.split("\n")
            # Remove opening ``` line
            start = 1
            # Remove closing ``` line if present
            end = len(lines)
            if lines[-1].strip().startswith("```"):
                end = -1
            text = "\n".join(lines[start:end])
        try:
            result = json.loads(text)
            return result if isinstance(result, list) else []
        except json.JSONDecodeError:
            return []

    def extract_entities(self, text: str) -> list[Entity]:
        """Extract entities using LLM."""
        if not text.strip():
            return []
        try:
            prompt = _ENTITY_PROMPT.format(text=text[:4000])
            response = self._call_llm(prompt)
            items = self._parse_json_response(response)
            entities = []
            seen = set()
            for item in items:
                name = item.get("name", "").strip()
                if not name or name.lower() in seen:
                    continue
                if len(name) > _MAX_NAME_LENGTH:
                    name = name[:_MAX_NAME_LENGTH]
                entity_type = item.get("entity_type", "person")
                if entity_type not in _VALID_ENTITY_TYPES:
                    entity_type = "person"
                seen.add(name.lower())
                entities.append(Entity(
                    name=name,
                    entity_type=entity_type,
                ))
            return entities
        except Exception:
            return []

    def extract_facts(self, text: str, entities: list[Entity]) -> list[Fact]:
        """Extract facts using LLM."""
        if not text.strip() or not entities:
            return []
        try:
            entity_names = ", ".join(e.name for e in entities)
            entity_map = {e.name.lower(): e for e in entities}
            prompt = _FACT_PROMPT.format(text=text[:4000], entities=entity_names)
            response = self._call_llm(prompt)
            items = self._parse_json_response(response)
            facts = []
            for item in items:
                subject = item.get("subject", "").strip()
                entity = entity_map.get(subject.lower())
                if not entity:
                    continue
                facts.append(Fact(
                    entity_id=entity.id,
                    subject=entity.name,
                    predicate=item.get("predicate", "attribute"),
                    object=item.get("object", ""),
                    raw_text=item.get("raw_text", ""),
                    confidence=min(1.0, max(0.0, item.get("confidence", 0.7))),
                ))
            return facts
        except Exception:
            return []

    def extract_relations(self, text: str, entities: list[Entity]) -> list[Relation]:
        """Extract relations using LLM."""
        if not text.strip() or len(entities) < 2:
            return []
        try:
            entity_names = ", ".join(e.name for e in entities)
            entity_map = {e.name.lower(): e for e in entities}
            prompt = _RELATION_PROMPT.format(text=text[:4000], entities=entity_names)
            response = self._call_llm(prompt)
            items = self._parse_json_response(response)
            relations = []
            for item in items:
                from_entity = entity_map.get(item.get("from_name", "").lower())
                to_entity = entity_map.get(item.get("to_name", "").lower())
                if from_entity and to_entity:
                    relations.append(Relation(
                        from_entity_id=from_entity.id,
                        to_entity_id=to_entity.id,
                        relation_type=item.get("relation_type", "RELATED_TO"),
                    ))
            return relations
        except Exception:
            return []
