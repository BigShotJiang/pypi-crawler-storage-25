"""Working memory — short-term context within a single session."""

from __future__ import annotations

from engram.models.session import Session
from engram.storage.base import StorageBackend


class WorkingMemory:
    """Short-term memory within a single session.

    Tracks active entities and recent queries to provide
    context-aware search boosting and reference resolution.
    """

    def __init__(self, session: Session):
        self.session = session
        self.active_entities: list[str] = []  # entity IDs, most recent first
        self.recent_queries: list[str] = []
        self.facts_added_count: int = 0

    def touch_entity(self, entity_id: str) -> None:
        """Mark entity as active in this session (most recent first)."""
        if entity_id in self.active_entities:
            self.active_entities.remove(entity_id)
        self.active_entities.insert(0, entity_id)

    def get_active_entity_ids(self, limit: int = 5) -> list[str]:
        """Return the most recently accessed entity IDs."""
        return self.active_entities[:limit]

    def add_query(self, query: str) -> None:
        """Record a search query."""
        self.recent_queries.insert(0, query)
        if len(self.recent_queries) > 20:
            self.recent_queries = self.recent_queries[:20]

    def get_active_context(self, storage: StorageBackend, max_tokens: int = 300) -> str:
        """Return compact summary of what's been discussed in this session."""
        parts: list[str] = []
        tokens_used = 0

        for eid in self.active_entities[:5]:
            entity = storage.get_entity(eid)
            if entity:
                entry = f"{entity.name}"
                if entity.state.role:
                    entry += f" ({entity.state.role})"
                entry_tokens = len(entry) // 4
                if tokens_used + entry_tokens > max_tokens:
                    break
                parts.append(entry)
                tokens_used += entry_tokens

        if not parts:
            return ""
        return "Active context: " + ", ".join(parts)
