"""Session lifecycle management."""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Optional

from engram.exceptions import SessionError
from engram.models.session import Session, SessionEvent
from engram.storage.base import StorageBackend


class SessionManager:
    """Manages session lifecycle: start, track events, end, and context carryover."""

    def __init__(self, storage: StorageBackend):
        self.storage = storage
        self._active: dict[str, Session] = {}

    def start_session(self, agent_id: str = "default") -> Session:
        """Start a new session, linking to the previous one."""
        previous = self.storage.get_recent_sessions(agent_id, limit=1)
        session = Session(
            session_id=str(uuid.uuid4()),
            agent_id=agent_id,
            started_at=datetime.now(),
            parent_session_id=previous[0].session_id if previous else None,
        )
        self.storage.save_session(session)
        self._active[session.session_id] = session
        return session

    def end_session(self, session_id: str, summary: Optional[str] = None) -> Session:
        """End a session and persist it. Auto-generates summary if not provided."""
        session = self._active.pop(session_id, None)
        if session is None:
            session = self.storage.get_session(session_id)
        if session is None:
            raise SessionError(f"Session {session_id} not found")

        session.ended_at = datetime.now()
        if summary:
            session.summary = summary
        elif not session.summary:
            session.summary = self._auto_summary(session)
        self.storage.save_session(session)
        return session

    def _auto_summary(self, session: Session) -> str:
        """Auto-generate summary from session tracking data."""
        parts: list[str] = []
        if session.entities_modified:
            names: list[str] = []
            for eid in session.entities_modified[:5]:
                entity = self.storage.get_entity(eid)
                if entity:
                    names.append(entity.name)
            if names:
                parts.append(f"Modified: {', '.join(names)}")
        if session.entities_accessed:
            accessed_names: list[str] = []
            for eid in session.entities_accessed[:5]:
                if eid not in (session.entities_modified or []):
                    entity = self.storage.get_entity(eid)
                    if entity:
                        accessed_names.append(entity.name)
            if accessed_names:
                parts.append(f"Discussed: {', '.join(accessed_names)}")
        if session.facts_added:
            parts.append(f"{len(session.facts_added)} facts added")
        return ". ".join(parts) if parts else "Session with no significant changes"

    def get_active_session(self, session_id: str) -> Optional[Session]:
        """Get an active session by ID."""
        return self._active.get(session_id)

    def record_entity_access(self, session_id: str, entity_id: str) -> None:
        """Record that an entity was accessed in this session."""
        session = self._active.get(session_id)
        if session and entity_id not in session.entities_accessed:
            session.entities_accessed.append(entity_id)

    def record_entity_modified(self, session_id: str, entity_id: str) -> None:
        """Record that an entity was modified in this session."""
        session = self._active.get(session_id)
        if session:
            if entity_id not in session.entities_modified:
                session.entities_modified.append(entity_id)
            if entity_id not in session.entities_accessed:
                session.entities_accessed.append(entity_id)

    def record_fact_added(self, session_id: str, fact_id: str) -> None:
        """Record that a fact was added in this session."""
        session = self._active.get(session_id)
        if session:
            session.facts_added.append(fact_id)

    def log_event(self, session_id: str, event_type: str, target: str = "", detail: Optional[dict] = None) -> None:
        """Log an auditable event within a session."""
        event = SessionEvent(
            session_id=session_id,
            event_type=event_type,
            target=target,
            detail=detail or {},
            timestamp=datetime.now(),
        )
        self.storage.add_session_event(event)

    def get_context_carryover(self, agent_id: str) -> str:
        """Generate context string from recent sessions for system prompt injection.

        Resolves entity IDs to names for agent readability.
        Looks at last 3 completed sessions, not just 1.
        """
        recent = self.storage.get_recent_sessions(agent_id, limit=5)
        completed = [s for s in recent if s.ended_at]
        if not completed:
            return ""

        parts = []

        # Last session summary
        if completed[0].summary:
            parts.append(f"Previous session: {completed[0].summary}")

        # Resolve entity IDs to names across recent sessions
        all_entity_ids: list[str] = []
        for s in completed[:3]:
            all_entity_ids.extend(s.entities_accessed)
        # Deduplicate preserving order
        seen: set[str] = set()
        unique_ids: list[str] = []
        for eid in all_entity_ids:
            if eid not in seen:
                seen.add(eid)
                unique_ids.append(eid)

        entity_names: list[str] = []
        for eid in unique_ids[:10]:
            entity = self.storage.get_entity(eid)
            if entity:
                entity_names.append(entity.name)

        if entity_names:
            parts.append(f"Recently discussed: {', '.join(entity_names)}")

        total_facts = sum(len(s.facts_added) for s in completed[:3])
        if total_facts:
            parts.append(f"Facts added recently: {total_facts}")

        return " | ".join(parts) if parts else ""
