"""Context carryover between sessions — resolves IDs to names, aggregates history."""

from __future__ import annotations

from collections import Counter
from typing import Optional

from engram.storage.base import StorageBackend


def build_session_context(storage: StorageBackend, agent_id: str, session_limit: int = 5) -> dict:
    """Build a rich context summary for the start of a new session.

    Looks at the last N sessions (not just 1) to aggregate knowledge.
    Resolves entity IDs to human-readable names.
    """
    recent = storage.get_recent_sessions(agent_id, limit=session_limit)

    context: dict = {
        "entity_count": storage.entity_count(),
        "fact_count": storage.fact_count(),
        "pending_conflicts": len(storage.get_pending_conflicts()),
    }

    if not recent:
        context["previous_summary"] = ""
        context["previous_entities"] = []
        context["recent_topics"] = []
        context["sessions_reviewed"] = 0
        return context

    # Last completed session's summary
    last_completed = None
    for s in recent:
        if s.ended_at:
            last_completed = s
            break

    context["previous_summary"] = last_completed.summary if last_completed and last_completed.summary else ""

    # Aggregate entity access across recent sessions — resolve IDs to names
    entity_access_count: Counter = Counter()
    for s in recent:
        if s.ended_at:
            for eid in s.entities_accessed:
                entity_access_count[eid] += 1

    # Resolve top entity IDs to names
    top_entity_ids = [eid for eid, _ in entity_access_count.most_common(15)]
    resolved_entities: list[dict] = []
    for eid in top_entity_ids:
        entity = storage.get_entity(eid)
        if entity:
            resolved_entities.append({
                "name": entity.name,
                "type": entity.entity_type,
                "access_count": entity_access_count[eid],
            })

    context["previous_entities"] = [e["name"] for e in resolved_entities]
    context["recent_entity_details"] = resolved_entities

    # Include top facts for the most important entities (actual knowledge, not just names)
    key_facts: list[dict] = []
    for entity_info in resolved_entities[:5]:
        eid = next((eid for eid, _ in entity_access_count.most_common(15)
                     if storage.get_entity(eid) and storage.get_entity(eid).name == entity_info["name"]), None)
        if eid:
            facts = storage.get_current_facts(eid)
            top_facts = sorted(facts, key=lambda f: f.confidence, reverse=True)[:3]
            for f in top_facts:
                key_facts.append({
                    "entity": entity_info["name"],
                    "fact": f.raw_text,
                    "confidence": f.confidence,
                })
    context["key_facts"] = key_facts

    # Collect recent topics from session summaries
    recent_topics: list[str] = []
    for s in recent:
        if s.ended_at and s.summary:
            recent_topics.append(s.summary)
    context["recent_topics"] = recent_topics[:5]
    context["sessions_reviewed"] = len([s for s in recent if s.ended_at])

    return context
