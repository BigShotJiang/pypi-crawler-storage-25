"""Schema versioning and migration support."""

from __future__ import annotations

import sqlite3

CURRENT_VERSION = 1


def get_schema_version(conn: sqlite3.Connection) -> int:
    try:
        row = conn.execute("SELECT value FROM _meta WHERE key = 'schema_version'").fetchone()
        return int(row[0]) if row else 0
    except sqlite3.OperationalError:
        return 0


def migrate(conn: sqlite3.Connection) -> None:
    """Run any pending migrations."""
    version = get_schema_version(conn)
    if version >= CURRENT_VERSION:
        return
    # Future migrations go here:
    # if version < 2:
    #     _migrate_v1_to_v2(conn)
    conn.execute(
        "INSERT OR REPLACE INTO _meta (key, value) VALUES (?, ?)",
        ("schema_version", str(CURRENT_VERSION)),
    )
    conn.commit()
