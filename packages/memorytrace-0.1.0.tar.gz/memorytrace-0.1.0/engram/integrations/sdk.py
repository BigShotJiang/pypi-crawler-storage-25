"""Programmatic Python SDK — clean wrapper around MemoryEngine.

Usage:
    from engram.integrations.sdk import EngramSDK

    sdk = EngramSDK()
    sdk.store("Simon Kim is the CEO of Hashed.")
    results = sdk.search("CEO")
    sdk.close()
"""

from __future__ import annotations

from typing import Optional

from engram.config import EngramConfig
from engram.engine import MemoryEngine, StoreResult
from engram.models.entity import Entity, Tier
from engram.models.quality import ValidationResult
from engram.models.search import SearchOptions, SearchResult
from engram.models.session import Session
from engram.models.source import Source, SourceType


class EngramSDK:
    """High-level SDK for programmatic access to Engram.

    Provides a clean API without CLI concerns.
    All methods return structured objects — no print().
    """

    def __init__(self, config: Optional[EngramConfig] = None):
        self.engine = MemoryEngine(config)
        self._current_session: Optional[Session] = None

    def close(self) -> None:
        try:
            if self._current_session:
                self.end_session()
        finally:
            self.engine.close()

    def __enter__(self) -> EngramSDK:
        return self

    def __exit__(self, *args) -> None:
        self.close()

    # ── Session ──

    def start_session(self, agent_id: str = "sdk") -> Session:
        self._current_session = self.engine.start_session(agent_id)
        return self._current_session

    def end_session(self, summary: Optional[str] = None) -> Optional[Session]:
        if self._current_session:
            session = self.engine.end_session(self._current_session.session_id, summary)
            self._current_session = None
            return session
        return None

    @property
    def session_id(self) -> Optional[str]:
        return self._current_session.session_id if self._current_session else None

    # ── Store & Retrieve ──

    def store(
        self,
        text: str,
        source_type: str = "user_input",
        confidence: float = 1.0,
        author: str = "",
    ) -> StoreResult:
        source = Source(
            type=SourceType(source_type),
            confidence=confidence,
            author=author,
            channel="sdk",
        )
        return self.engine.store(text, source=source, session_id=self.session_id)

    def search(
        self,
        query: str,
        max_results: int = 10,
        max_tokens: int = 500,
        min_confidence: float = 0.0,
    ) -> SearchResult:
        options = SearchOptions(
            query=query,
            max_results=max_results,
            max_tokens=max_tokens,
            min_confidence=min_confidence,
        )
        return self.engine.search(query, options)

    def get_entity(self, name: str) -> Optional[Entity]:
        return self.engine.get_entity(name)

    def get_facts(self, entity_name: str) -> list:
        return self.engine.get_facts(entity_name)

    def add_fact(
        self,
        entity_name: str,
        fact_text: str,
        predicate: str = "attribute",
        source_type: str = "user_input",
        confidence: float = 1.0,
    ) -> ValidationResult:
        source = Source(type=SourceType(source_type), confidence=confidence, channel="sdk")
        return self.engine.add_fact(
            entity_name, fact_text, predicate=predicate,
            source=source, session_id=self.session_id,
        )

    def create_entity(
        self,
        name: str,
        entity_type: str = "person",
        tier: str = "recall",
        summary: str = "",
    ) -> Entity:
        return self.engine.create_entity(name, entity_type, Tier(tier), summary)

    def list_entities(self, entity_type: str = "", tier: str = "", limit: int = 100) -> list[Entity]:
        return self.engine.list_entities(
            tier=Tier(tier) if tier else None,
            entity_type=entity_type or None,
            limit=limit,
        )

    # ── Context ──

    def get_context(self, agent_id: str = "sdk") -> dict:
        return self.engine.get_session_context(agent_id)

    def health(self) -> dict:
        return self.engine.health_check()

    # ── Tool Schemas (for OpenAI function calling) ──

    @staticmethod
    def get_tool_schemas() -> list[dict]:
        """Return OpenAI-format function calling schemas for all tools."""
        return [
            {
                "type": "function",
                "function": {
                    "name": "memory_search",
                    "description": "Search persistent memory for relevant context",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "query": {"type": "string", "description": "Search query"},
                            "max_results": {"type": "integer", "default": 5},
                            "max_tokens": {"type": "integer", "default": 500},
                        },
                        "required": ["query"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "memory_store",
                    "description": "Store new factual information in memory",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "content": {"type": "string", "description": "Content to store"},
                            "source_type": {"type": "string", "default": "agent_inference"},
                            "confidence": {"type": "number", "default": 0.7},
                        },
                        "required": ["content"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "memory_get_entity",
                    "description": "Get all info about a specific entity",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string", "description": "Entity name"},
                        },
                        "required": ["name"],
                    },
                },
            },
        ]
