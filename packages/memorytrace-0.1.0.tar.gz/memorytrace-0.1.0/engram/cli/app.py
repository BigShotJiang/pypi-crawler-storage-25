"""CLI entry point for Engram."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Optional

from engram.config import EngramConfig
from engram.engine import MemoryEngine
from engram.models.entity import Tier
from engram.models.search import SearchOptions
from engram.models.source import Source, SourceType


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="engram",
        description="Engram — AI agent memory system",
    )
    parser.add_argument("--db", default=None, help="Database path")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parser.add_argument("--quiet", action="store_true", help="Suppress non-essential output")
    parser.add_argument("--verbose", action="store_true", help="Show detailed error info")

    sub = parser.add_subparsers(dest="command")

    # init
    sub.add_parser("init", help="Initialize memory database")

    _source_choices = ["user_input", "direct_speech", "document", "api", "web", "agent_inference"]

    # store
    p = sub.add_parser("store", help="Extract and store information from text")
    p.add_argument("text", nargs="?", help="Text to process (or read from stdin)")
    p.add_argument("--source-type", default="user_input", choices=_source_choices, help="Source type")
    p.add_argument("--confidence", type=float, default=1.0, help="Source confidence")
    p.add_argument("--author", default="", help="Source author")

    # search
    p = sub.add_parser("search", help="Search memory")
    p.add_argument("query", help="Search query")
    p.add_argument("--max-results", type=int, default=10)
    p.add_argument("--max-tokens", type=int, default=500)
    p.add_argument("--min-confidence", type=float, default=0.0)
    p.add_argument("--type", dest="entity_type", default="")
    p.add_argument("--tier", default="")

    # get
    p = sub.add_parser("get", help="Get entity details")
    p.add_argument("name", help="Entity name")

    # list
    p = sub.add_parser("list", help="List entities")
    p.add_argument("--type", dest="entity_type", default="")
    p.add_argument("--tier", default="")
    p.add_argument("--limit", type=int, default=50)

    # add-fact
    p = sub.add_parser("add-fact", help="Add a fact to an entity")
    p.add_argument("entity", help="Entity name")
    p.add_argument("fact", help="Fact text")
    p.add_argument("--predicate", default="attribute")
    p.add_argument("--source-type", default="user_input", choices=_source_choices)
    p.add_argument("--confidence", type=float, default=1.0)

    # create
    p = sub.add_parser("create", help="Create a new entity")
    p.add_argument("name", help="Entity name")
    p.add_argument("--type", dest="entity_type", default="person")
    p.add_argument("--tier", default="recall")
    p.add_argument("--summary", default="")

    # conflicts
    sub.add_parser("conflicts", help="Show pending conflicts")

    # resolve
    p = sub.add_parser("resolve", help="Resolve a conflict")
    p.add_argument("conflict_id", help="Conflict ID")
    p.add_argument("resolution", choices=["accept_new", "keep_old", "merge"])

    # health
    sub.add_parser("health", help="Run health checks")

    # export
    p = sub.add_parser("export", help="Export to Markdown")
    p.add_argument("--dir", default=None, help="Export directory")

    # reindex
    sub.add_parser("reindex", help="Rebuild search index")

    # serve
    p = sub.add_parser("serve", help="Start MCP server")
    p.add_argument("--transport", default="stdio", choices=["stdio", "sse"])
    p.add_argument("--port", type=int, default=8080)

    return parser


def _make_engine(args) -> MemoryEngine:
    """Create engine from CLI args."""
    config = EngramConfig()
    if args.db:
        db_path = Path(args.db).expanduser().resolve()
        config.base_dir = db_path.parent
        config.db_name = db_path.name
    return MemoryEngine(config)


def main(argv: Optional[list[str]] = None) -> int:
    """Main CLI entry point. Returns exit code."""
    parser = _build_parser()
    args = parser.parse_args(argv)

    if not args.command:
        parser.print_help()
        return 0

    from engram.cli.formatters import (
        format_entity,
        format_entity_list,
        format_search_result,
        format_store_result,
        format_health,
    )

    engine = None
    try:
        engine = _make_engine(args)

        if args.command == "init":
            if not args.quiet:
                print(f"Memory initialized at {engine.config.db_path}")
            return 0

        elif args.command == "store":
            max_input = 1024 * 1024  # 1MB limit for stdin
            text = args.text or sys.stdin.read(max_input)
            source = Source(
                type=SourceType(args.source_type),
                confidence=args.confidence,
                author=args.author,
                channel="cli",
            )
            result = engine.store(text, source=source)
            if args.json:
                print(result.to_json())
            else:
                print(format_store_result(result))

        elif args.command == "search":
            options = SearchOptions(
                query=args.query,
                max_results=args.max_results,
                max_tokens=args.max_tokens,
                min_confidence=args.min_confidence,
            )
            if args.entity_type:
                options.entity_types = [args.entity_type]
            if args.tier:
                options.tiers = [args.tier]
            result = engine.search(args.query, options)
            if args.json:
                print(result.to_json())
            else:
                print(format_search_result(result))

        elif args.command == "get":
            entity = engine.get_entity(args.name)
            if entity:
                facts = engine.get_facts(args.name)
                if args.json:
                    print(json.dumps({
                        "name": entity.name,
                        "type": entity.entity_type,
                        "tier": entity.tier.value,
                        "summary": entity.summary,
                        "facts": [{"text": f.raw_text, "confidence": f.confidence} for f in facts],
                    }, ensure_ascii=False, indent=2))
                else:
                    print(format_entity(entity, facts))
            else:
                print(f"  Entity '{args.name}' not found.", file=sys.stderr)
                engine.close()
                return 1

        elif args.command == "list":
            tier = Tier(args.tier) if args.tier else None
            entities = engine.list_entities(
                tier=tier,
                entity_type=args.entity_type or None,
                limit=args.limit,
            )
            if args.json:
                print(json.dumps([
                    {"name": e.name, "type": e.entity_type, "tier": e.tier.value}
                    for e in entities
                ], ensure_ascii=False, indent=2))
            else:
                print(format_entity_list(entities))

        elif args.command == "add-fact":
            source = Source(
                type=SourceType(args.source_type),
                confidence=args.confidence,
                channel="cli",
            )
            result = engine.add_fact(args.entity, args.fact, predicate=args.predicate, source=source)
            if args.json:
                print(json.dumps({"action": result.action.value, "confidence": result.confidence}, indent=2))
            else:
                print(f"  Result: {result.action.value} (confidence: {result.confidence:.2f})")

        elif args.command == "create":
            tier = Tier(args.tier)
            entity = engine.create_entity(args.name, entity_type=args.entity_type, tier=tier, summary=args.summary)
            if args.json:
                print(json.dumps({"id": entity.id, "name": entity.name}, ensure_ascii=False, indent=2))
            else:
                print(f"  Created: {entity.name} ({entity.entity_type}, {entity.tier.value})")

        elif args.command == "conflicts":
            conflicts = engine.storage.get_pending_conflicts()
            if args.json:
                print(json.dumps(conflicts, ensure_ascii=False, indent=2))
            else:
                if not conflicts:
                    print("  No pending conflicts.")
                else:
                    for c in conflicts:
                        print(f"  [{c['id'][:8]}] {c['conflict_type']} — {c.get('suggested_resolution', 'N/A')}")

        elif args.command == "resolve":
            engine.resolve_conflict(args.conflict_id, args.resolution)
            print(f"  Conflict {args.conflict_id[:8]} resolved: {args.resolution}")

        elif args.command == "health":
            health = engine.health_check()
            if args.json:
                print(json.dumps(health, indent=2))
            else:
                print(format_health(health))

        elif args.command == "export":
            if args.dir:
                engine.config.export_dir_name = args.dir
            count = engine.export_markdown()
            print(f"  Exported {count} entities to {engine.config.export_dir}")

        elif args.command == "reindex":
            count = engine.reindex()
            print(f"  Reindexed {count} entities.")

        elif args.command == "serve":
            _run_mcp_server(args)
            return 0

        return 0

    except KeyboardInterrupt:
        return 130
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        if hasattr(args, "verbose") and args.verbose:
            import traceback
            traceback.print_exc()
        return 1
    finally:
        if engine is not None:
            engine.close()


def _run_mcp_server(args) -> None:
    """Start MCP server (requires mcp package)."""
    try:
        from engram.integrations.mcp_server import run_server
        run_server(transport=args.transport, port=args.port)
    except ImportError:
        print("MCP server requires 'mcp' package. Install with: pip install engram[mcp]", file=sys.stderr)
        sys.exit(1)


def cli_entry() -> None:
    """Entry point for setuptools console_scripts (expects no return value)."""
    sys.exit(main())


if __name__ == "__main__":
    cli_entry()
