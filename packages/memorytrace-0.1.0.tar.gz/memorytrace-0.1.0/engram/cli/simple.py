#!/usr/bin/env python3
"""Engram — simple CLI interface.

Usage:
    engram init
    engram save "Minseong Jeong is the Space King of Galaxy Corp"
    engram find "Space King"
    engram who "Minseong Jeong"
    engram remember "Minseong Jeong" "Loves AI and space"
    engram all
    engram status
    engram forget "Old Entity"
    engram export
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

from engram.config import EngramConfig
from engram.engine import MemoryEngine

_DB_DIR = Path.home() / ".engram"
_engine = None


def _get_engine() -> MemoryEngine:
    global _engine
    if _engine is None:
        _engine = MemoryEngine(EngramConfig(base_dir=_DB_DIR))
    return _engine


def _print_help():
    print("""
  engram — AI agent memory system

  Commands:
    engram init                          Initialize memory
    engram save "text"                   Extract & store information
    engram find "query"                  Search memory
    engram who "name"                    Look up entity
    engram remember "name" "fact"        Manually add a fact
    engram all                           List all entities
    engram status                        Health check
    engram forget "name"                 Delete entity
    engram export                        Export to Markdown

  Examples:
    engram save "Minseong Jeong is the Space King of Galaxy Corp"
    engram find "Space King"
    engram who "Minseong Jeong"
    engram remember "정민성" "AI 전문가이다"

  Install:
    pip install git+https://github.com/aop60003/default.git
""")


def main() -> int:
    args = sys.argv[1:]

    if not args or args[0] in ("-h", "--help", "help"):
        _print_help()
        return 0

    cmd = args[0]
    rest = " ".join(args[1:]) if len(args) > 1 else ""

    try:
        engine = _get_engine()

        # ── init ──
        if cmd == "init":
            print(f"  Memory initialized at {engine.config.db_path}")

        # ── save ──
        elif cmd == "save":
            if not rest:
                print("  Usage: engram save \"text to remember\"")
                return 1
            result = engine.store(rest)
            created = [e.name for e in result.entities_created]
            updated = [e.name for e in result.entities_updated]
            if created:
                print(f"  New: {', '.join(created)}")
            if updated:
                print(f"  Updated: {', '.join(updated)}")
            if result.facts_added:
                print(f"  Learned {len(result.facts_added)} fact(s)")
            if not created and not updated and not result.facts_added:
                print("  Saved (no entities auto-detected)")

        # ── find ──
        elif cmd in ("find", "search"):
            if not rest:
                print("  Usage: engram find \"search query\"")
                return 1
            result = engine.search(rest)
            if not result.hits:
                print(f"  Nothing found for \"{rest}\"")
            else:
                for h in result.hits:
                    print(f"  {h.entity.name} ({h.entity.entity_type})")
                    if h.entity.summary:
                        print(f"    {h.entity.summary}")
                    for f in h.facts[:3]:
                        print(f"    - {f.raw_text}")

        # ── who ──
        elif cmd in ("who", "get"):
            if not rest:
                print("  Usage: engram who \"entity name\"")
                return 1
            entity = engine.get_entity(rest)
            if not entity:
                print(f"  \"{rest}\" not found.")
                return 1
            print(f"  {entity.name} [{entity.entity_type}]")
            if entity.summary:
                print(f"  {entity.summary}")
            if entity.state.role:
                print(f"  Role: {entity.state.role}")
            if entity.state.affiliation:
                print(f"  At: {entity.state.affiliation}")
            if entity.aliases:
                print(f"  Also known as: {', '.join(entity.aliases)}")
            facts = engine.get_facts(rest)
            if facts:
                print(f"  Facts ({len(facts)}):")
                for f in facts:
                    print(f"    - {f.raw_text}")

        # ── remember ──
        elif cmd == "remember":
            # Parse: remember "Name" "Fact"
            parts = _parse_quoted_args(args[1:])
            if len(parts) < 2:
                print('  Usage: engram remember "Name" "Fact to remember"')
                return 1
            name, fact = parts[0], " ".join(parts[1:])
            if not engine.get_entity(name):
                engine.create_entity(name)
                print(f"  Created: {name}")
            result = engine.add_fact(name, fact)
            print(f"  Remembered ({result.confidence:.0%} confidence)")

        # ── all / list ──
        elif cmd in ("all", "list"):
            entities = engine.list_entities(limit=50)
            if not entities:
                print("  No memories yet. Try: engram save \"some info\"")
            else:
                print(f"  {len(entities)} entities:")
                for e in entities:
                    line = f"    {e.name} ({e.entity_type})"
                    if e.summary:
                        line += f" — {e.summary[:50]}"
                    print(line)

        # ── status ──
        elif cmd == "status":
            h = engine.health_check()
            print(f"  Entities: {h['entity_count']}")
            print(f"  Facts:    {h['fact_count']}")
            print(f"  Conflicts: {h['pending_conflicts']}")
            print(f"  Status:   {h['status']}")
            print(f"  DB: {engine.config.db_path}")

        # ── forget ──
        elif cmd == "forget":
            if not rest:
                print("  Usage: engram forget \"entity name\"")
                return 1
            entity = engine.get_entity(rest)
            if entity:
                engine.storage.delete_entity(entity.id)
                print(f"  Forgot: {rest}")
            else:
                print(f"  \"{rest}\" not found.")

        # ── export ──
        elif cmd == "export":
            count = engine.export_markdown()
            print(f"  Exported {count} entities to {engine.config.export_dir}")

        # ── json ──
        elif cmd == "json":
            # engram json find "query" / engram json who "name"
            if len(args) < 3:
                print("  Usage: engram json find/who/all \"query\"")
                return 1
            subcmd = args[1]
            subrest = " ".join(args[2:])
            if subcmd == "find":
                result = engine.search(subrest)
                print(result.to_json())
            elif subcmd == "who":
                entity = engine.get_entity(subrest)
                if entity:
                    facts = engine.get_facts(subrest)
                    print(json.dumps({
                        "name": entity.name, "type": entity.entity_type,
                        "tier": entity.tier.value, "summary": entity.summary,
                        "role": entity.state.role, "affiliation": entity.state.affiliation,
                        "facts": [{"text": f.raw_text, "confidence": f.confidence} for f in facts],
                    }, ensure_ascii=False, indent=2))
                else:
                    print(json.dumps({"error": f"'{subrest}' not found"}, indent=2))
            elif subcmd == "all":
                entities = engine.list_entities(limit=100)
                print(json.dumps([
                    {"name": e.name, "type": e.entity_type, "tier": e.tier.value}
                    for e in entities
                ], ensure_ascii=False, indent=2))

        else:
            print(f"  Unknown command: {cmd}")
            _print_help()
            return 1

    except KeyboardInterrupt:
        return 130
    except Exception as e:
        print(f"  Error: {e}", file=sys.stderr)
        return 1
    finally:
        if _engine:
            _engine.close()

    return 0


def _parse_quoted_args(args: list) -> list[str]:
    """Parse arguments respecting quotes: 'Name' 'Fact here' → ['Name', 'Fact here']"""
    joined = " ".join(args)
    parts = []
    current = ""
    in_quote = False
    quote_char = ""
    for ch in joined:
        if ch in ('"', "'") and not in_quote:
            in_quote = True
            quote_char = ch
        elif ch == quote_char and in_quote:
            in_quote = False
            if current:
                parts.append(current)
                current = ""
        elif ch == " " and not in_quote and current:
            parts.append(current)
            current = ""
        elif ch != " " or in_quote:
            current += ch
    if current:
        parts.append(current)
    return parts


def cli_entry():
    sys.exit(main())


if __name__ == "__main__":
    cli_entry()
