"""CLI interface for Engram."""
