"""
PlotEZ - Mundane plotting made easy.

A Python library for simplified matplotlib plotting.
"""

from .backend import (
    ErrorBandConfig,
    ErrorPlotConfig,
    HistogramConfig,
    LinePlotConfig,
    ScatterPlotConfig,
    ebc,
    epc,
    error_band_configuration,
    error_plot_configuration,
    hgc,
    histogram_config,
    line_plot_configuration,
    lpc,
    scatter_plot_configuration,
    spc,
)
from .plotez import (
    n_plotter,
    plot_density,
    plot_errorband,
    plot_errorband_relative,
    plot_errorbar,
    plot_hist,
    plot_two_column_file,
    plot_with_dual_axes,
    plot_xxy,
    plot_xy,
    plot_xyy,
    two_subplots,
)
from .version import __version__

__all__ = [
    # Plotting functions
    "plot_two_column_file",
    "plot_xy",
    "plot_xyy",
    "plot_xxy",
    "plot_with_dual_axes",
    "two_subplots",
    "n_plotter",
    "plot_errorbar",
    "plot_errorband",
    "plot_errorband_relative",
    "plot_hist",
    "plot_density",
    # Config classes
    "ErrorBandConfig",
    "ErrorPlotConfig",
    "LinePlotConfig",
    "ScatterPlotConfig",
    "HistogramConfig",
    # Convenience / wrapper functions (long-form)
    "line_plot_configuration",
    "error_plot_configuration",
    "error_band_configuration",
    "scatter_plot_configuration",
    "histogram_config",
    # Convenience / wrapper functions (short aliases)
    "lpc",
    "epc",
    "ebc",
    "spc",
    "hgc",
    # Version
    "__version__",
]
