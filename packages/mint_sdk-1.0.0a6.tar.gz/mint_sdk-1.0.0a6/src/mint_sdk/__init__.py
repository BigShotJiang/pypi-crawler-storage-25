"""
MINT Plugin SDK

SDK for building analysis plugins that integrate with the MINT platform.
"""

from mint_sdk.context import PlatformContext

# Exceptions
from mint_sdk.exceptions import (
    ConfigurationException,
    ConflictException,
    NotFoundException,
    PermissionException,
    PluginException,
    PluginLifecycleException,
    RepositoryException,
    ValidationException,
)
from mint_sdk.export import auto_json_to_csv, auto_json_to_summary, auto_json_to_tree

# Local database (optional dependency)
from mint_sdk.local_database import LocalDatabase, LocalDatabaseConfig
from mint_sdk.logging import get_plugin_logger

# Migration framework (requires sqlalchemy — optional dependency)
try:
    from mint_sdk.migrations import (
        MigrationOps,
        MigrationResult,
        MigrationRunner,
        PluginMigration,
    )
except ImportError:
    pass
from mint_sdk.models import PluginCapabilities, PluginMetadata, PluginType
from mint_sdk.plugin import (
    AnalysisPlugin,
    HealthStatus,
    LifecycleHookResult,
    PluginHealth,
)

# Repository protocols and data models
from mint_sdk.repositories import (
    DesignData,
    # Data models
    Experiment,
    # Repository protocols
    ExperimentRepository,
    PlatformConfig,
    PluginAnalysisResult,
    PluginDataRepository,
    PluginExperimentData,  # backward compatibility alias for DesignData
    PluginRoleRepository,
    User,
    UserPluginRole,
    UserRepository,
)

# App factory and helpers
from mint_sdk.app import (
    PluginDependency,
    SPAStaticFiles,
    create_standalone_app,
    require_context,
)

# API Client
from mint_sdk.client import MINTClient

try:
    from mint_sdk._version import __version__
except ImportError:
    __version__ = "0.0.0"

__all__ = [
    # API Client
    "MINTClient",
    # Core plugin classes
    "AnalysisPlugin",
    "PluginMetadata",
    "PluginCapabilities",
    "PluginType",
    "PlatformContext",
    # Lifecycle types
    "HealthStatus",
    "PluginHealth",
    "LifecycleHookResult",
    # Exceptions
    "PluginException",
    "ValidationException",
    "PermissionException",
    "ConfigurationException",
    "RepositoryException",
    "NotFoundException",
    "ConflictException",
    "PluginLifecycleException",
    # Local database
    "LocalDatabase",
    "LocalDatabaseConfig",
    # Data models
    "Experiment",
    "DesignData",
    "PluginExperimentData",  # backward compatibility alias
    "PluginAnalysisResult",
    "User",
    "UserPluginRole",
    # Repository protocols
    "ExperimentRepository",
    "PluginDataRepository",
    "PluginRoleRepository",
    "UserRepository",
    "PlatformConfig",
    # Export utilities
    "auto_json_to_tree",
    "auto_json_to_csv",
    "auto_json_to_summary",
    # Logging
    "get_plugin_logger",
    # Migration framework
    "MigrationOps",
    "MigrationResult",
    "MigrationRunner",
    "PluginMigration",
    # App factory and helpers
    "create_standalone_app",
    "SPAStaticFiles",
    "PluginDependency",
    "require_context",
]
