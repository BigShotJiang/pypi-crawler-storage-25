"""Testing utilities for MINT plugins.

This subpackage gives plugin authors and platform maintainers a small
set of reusable helpers so integration tests stop re-inventing the same
scaffolding:

* :func:`make_test_plugin` — build a minimal :class:`AnalysisPlugin`
  subclass inline inside a test, with optional routes, hooks, and a
  configurable health status.
* :func:`build_test_app` — turn a plugin instance into a real
  :class:`fastapi.FastAPI` application (uses the SDK's
  :func:`create_standalone_app` so the plumbing matches production).
* :func:`write_standalone_plugin_module` — drop a tiny uvicorn-compatible
  plugin module into ``tmp_path`` so tests can ``SubprocessManager.start_plugin``
  a real child interpreter.
* :class:`RecordingContext` — an in-memory ``PlatformContext`` fake with
  a functional ``PluginDataRepository`` so plugin code can exercise
  ``save_design`` / ``load_analysis`` without any database.

These helpers intentionally live in the SDK (not the platform) so:

1. plugin repos can use them in their own integration suites,
2. platform tests import them and stop depending on ad-hoc
   ``MagicMock`` glue inside ``tests/``.
"""

from mint_sdk.testing.plugins import build_test_app, make_test_plugin
from mint_sdk.testing.recording_context import RecordingContext
from mint_sdk.testing.subprocess import write_standalone_plugin_module

__all__ = [
    "build_test_app",
    "make_test_plugin",
    "RecordingContext",
    "write_standalone_plugin_module",
]
