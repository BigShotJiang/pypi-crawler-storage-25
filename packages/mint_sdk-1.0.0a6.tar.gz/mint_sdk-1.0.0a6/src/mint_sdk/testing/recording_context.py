"""In-memory ``PlatformContext`` fake backed by Python dicts.

Lets plugin unit tests exercise the SDK's convenience methods
(``plugin.save_design``, ``plugin.load_analysis`` etc.) without a real
database or a running platform.  Every write is recorded so tests can
assert on the full sequence of interactions.
"""

from __future__ import annotations

from collections.abc import AsyncGenerator, Callable
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from typing import Any, Optional

from mint_sdk.context import PlatformContext
from mint_sdk.repositories import DesignData, PluginAnalysisResult


class _InMemoryPluginDataRepository:
    """Functional stand-in for ``PluginDataRepository`` backed by dicts."""

    def __init__(self) -> None:
        self.design: dict[int, DesignData] = {}
        self.analyses: dict[tuple[int, str], PluginAnalysisResult] = {}
        self._next_id = 1

    def _id(self) -> int:
        n = self._next_id
        self._next_id += 1
        return n

    async def save_experiment_data(
        self,
        experiment_id: int,
        plugin_id: str,
        data: dict[str, Any],
        schema_version: str = "1.0",
    ) -> DesignData:
        now = datetime.now(UTC)
        existing = self.design.get(experiment_id)
        record = DesignData(
            id=existing.id if existing else self._id(),
            experiment_id=experiment_id,
            plugin_id=plugin_id,
            data=dict(data),
            schema_version=schema_version,
            created_at=existing.created_at if existing else now,
            updated_at=now,
        )
        self.design[experiment_id] = record
        return record

    async def get_experiment_data(
        self, experiment_id: int
    ) -> Optional[DesignData]:
        return self.design.get(experiment_id)

    async def delete_experiment_data(self, experiment_id: int) -> bool:
        return self.design.pop(experiment_id, None) is not None

    async def save_analysis_result(
        self,
        experiment_id: int,
        plugin_id: str,
        result: dict[str, Any],
    ) -> PluginAnalysisResult:
        now = datetime.now(UTC)
        key = (experiment_id, plugin_id)
        existing = self.analyses.get(key)
        record = PluginAnalysisResult(
            id=existing.id if existing else self._id(),
            experiment_id=experiment_id,
            plugin_id=plugin_id,
            result=dict(result),
            created_at=existing.created_at if existing else now,
            updated_at=now,
        )
        self.analyses[key] = record
        return record

    async def get_analysis_result(
        self, experiment_id: int, plugin_id: str
    ) -> Optional[PluginAnalysisResult]:
        return self.analyses.get((experiment_id, plugin_id))

    async def get_analysis_results(
        self, experiment_id: int
    ) -> list[PluginAnalysisResult]:
        return [
            r for (eid, _), r in self.analyses.items() if eid == experiment_id
        ]

    async def delete_analysis_result(
        self, experiment_id: int, plugin_id: str
    ) -> bool:
        return self.analyses.pop((experiment_id, plugin_id), None) is not None


class RecordingContext(PlatformContext):
    """An in-memory ``PlatformContext`` useful for plugin unit tests.

    Only the subset of methods actually invoked by ``AnalysisPlugin``
    convenience helpers and typical plugin code is implemented.  Calls
    to unsupported repositories return ``None`` so plugins that guard
    with ``if repo is None`` still behave correctly.
    """

    def __init__(self, *, user: Optional[dict] = None) -> None:
        self._user = user
        self._data_repo = _InMemoryPluginDataRepository()

    # -- user --

    @property
    def is_authenticated(self) -> bool:
        return self._user is not None

    def get_current_user(self) -> Optional[dict]:
        return self._user

    def set_current_user(self, user: Optional[dict]) -> None:
        self._user = user

    def get_current_user_dependency(self) -> Callable:
        def _dep() -> Optional[dict]:
            return self._user

        return _dep

    def get_optional_user_dependency(self) -> Callable:
        return self.get_current_user_dependency()

    # -- repositories --

    def get_user_repository(self) -> Any:
        return None

    def get_experiment_repository(self) -> Any:
        return None

    def get_plugin_data_repository(self) -> Any:
        return self._data_repo

    def get_plugin_role_repository(self) -> Any:
        return None

    def get_analysis_artifact_repository(self) -> Any:
        return None

    def get_compound_list_repository(self) -> Any:
        return None

    def get_metadata_template_repository(self) -> Any:
        return None

    def get_tracing_preset_repository(self) -> Any:
        return None

    # -- plugin role --

    def require_plugin_role(self, *allowed_roles: str) -> Any:
        from fastapi import Depends

        def _noop() -> dict:
            return self._user or {}

        return Depends(_noop)

    # -- config --

    def get_config(self) -> Any:
        return None

    def get_plugin_config(self, plugin_name: str) -> dict:
        return {}

    async def set_plugin_config(self, plugin_name: str, config: dict) -> None:
        return None

    # -- shared db --

    @asynccontextmanager
    async def get_shared_db_session(self) -> AsyncGenerator[Any, None]:
        yield None  # type: ignore[misc]
