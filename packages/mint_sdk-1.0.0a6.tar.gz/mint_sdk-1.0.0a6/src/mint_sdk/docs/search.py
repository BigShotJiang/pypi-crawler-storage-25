"""Cross-SDK search with weighted scoring."""

from __future__ import annotations

from typing import Any


def search(
    query: str,
    python_data: dict[str, Any] | None,
    frontend_data: dict[str, Any] | None,
    *,
    limit: int = 20,
) -> list[dict[str, Any]]:
    """Search across both SDK manifests with weighted scoring.

    Scoring:
        - Name match: weight 3
        - Description match: weight 2
        - Prop/field/method name match: weight 1
    """
    q = query.lower()
    results: list[dict[str, Any]] = []

    for sdk_name, data in [("python", python_data), ("frontend", frontend_data)]:
        if data is None:
            continue
        for cat_name, cat_data in data.get("categories", {}).items():
            if not isinstance(cat_data, list):
                # CSS data is a dict of groups — search variable names
                if isinstance(cat_data, dict):
                    results.extend(_search_css(q, sdk_name, cat_name, cat_data))
                continue
            for item in cat_data:
                score, context = _score_item(q, item)
                if score > 0:
                    # Include description + source so an agent consuming
                    # `--json` can rank/triage results without N follow-up
                    # calls to `mint docs frontend <name>` per hit.
                    results.append({
                        "sdk": sdk_name,
                        "category": cat_name,
                        "group": item.get("group", ""),
                        "name": item.get("name", ""),
                        "kind": item.get("kind", ""),
                        "description": item.get("description", ""),
                        "source": item.get("source", ""),
                        "match_context": context,
                        "score": score,
                    })

    results.sort(key=lambda r: (-r["score"], r["name"]))
    return results[:limit]


def _score_item(query: str, item: dict[str, Any]) -> tuple[int, str]:
    """Score a single item against the query. Returns (score, match_context)."""
    score = 0
    context = ""

    name = item.get("name", "").lower()
    desc = item.get("description", "").lower()

    # Name match (weight 3)
    if query in name:
        score += 3
        context = item.get("name", "")

    # Description match (weight 2)
    if query in desc:
        score += 2
        if not context:
            context = item.get("description", "")[:60]

    # Prop/field/method/param name match (weight 1)
    for nested_key in ("props", "fields", "params", "abstract_methods", "concrete_methods", "methods", "members"):
        nested = item.get(nested_key, [])
        if isinstance(nested, list):
            for sub in nested:
                sub_name = sub.get("name", "").lower()
                if query in sub_name:
                    score += 1
                    if not context:
                        context = f"{nested_key}: {sub.get('name', '')}"
                    break  # Only count once per nested key

    # Emit name match (weight 1)
    for emit in item.get("emits", []):
        if query in emit.get("name", "").lower():
            score += 1
            if not context:
                context = f"emit: {emit.get('name', '')}"
            break

    return score, context


def _search_css(
    query: str,
    sdk_name: str,
    cat_name: str,
    css_data: dict[str, Any],
) -> list[dict[str, Any]]:
    """Search within CSS data (nested dict of groups)."""
    results: list[dict[str, Any]] = []
    for section_name, section_data in css_data.items():
        if isinstance(section_data, dict):
            # Grouped variables
            for group_name, variables in section_data.items():
                if isinstance(variables, list):
                    for var in variables:
                        var_name = var.get("name", "").lower()
                        if query in var_name:
                            results.append({
                                "sdk": sdk_name,
                                "category": f"css/{section_name}",
                                "group": group_name,
                                "name": var.get("name", ""),
                                "kind": "css-variable",
                                "match_context": var.get("value", ""),
                                "score": 3,
                            })
        elif isinstance(section_data, list):
            for item in section_data:
                if isinstance(item, dict):
                    item_name = item.get("name", "").lower()
                    if query in item_name:
                        results.append({
                            "sdk": sdk_name,
                            "category": f"css/{section_name}",
                            "group": "",
                            "name": item.get("name", ""),
                            "kind": "css-class",
                            "match_context": item.get("description", ""),
                            "score": 3,
                        })
    return results
