"""Extract documentation from the MINT Python SDK via runtime introspection."""

from __future__ import annotations

import inspect
from abc import ABC
from dataclasses import MISSING
from dataclasses import fields as dc_fields
from enum import Enum
from typing import Any

# Module → category mapping (derived from mint_sdk/__init__.py imports)
_MODULE_CATEGORY: dict[str, str] = {
    "mint_sdk.plugin": "plugin",
    "mint_sdk.models": "models",
    "mint_sdk.context": "context",
    "mint_sdk.repositories": "repositories",
    "mint_sdk.exceptions": "exceptions",
    "mint_sdk.local_database": "database",
    "mint_sdk.export": "export",
    "mint_sdk.logging": "logging",
}


def extract_python_sdk() -> dict[str, Any]:
    """Extract full documentation manifest from the mint_sdk package.

    Returns a dict with ``sdk``, ``version``, and ``categories`` keys.
    Each category maps to a list of documented items.
    """
    import mint_sdk

    version = getattr(mint_sdk, "__version__", "0.0.0")
    all_names: list[str] = list(getattr(mint_sdk, "__all__", []))

    categories: dict[str, list[dict[str, Any]]] = {}

    for name in all_names:
        obj = getattr(mint_sdk, name, None)
        if obj is None:
            continue

        category = _categorize_symbol(name, obj)
        item = _extract_symbol(name, obj)
        categories.setdefault(category, []).append(item)

    return {
        "sdk": "python",
        "version": version,
        "categories": categories,
    }


# ---------------------------------------------------------------------------
# Categorization
# ---------------------------------------------------------------------------


# Explicit overrides for symbols whose __module__ doesn't match
_NAME_CATEGORY: dict[str, str] = {
    "PlatformConfig": "repositories",
}


def _categorize_symbol(name: str, obj: Any) -> str:
    """Determine the category of a symbol from its source module."""
    if name in _NAME_CATEGORY:
        return _NAME_CATEGORY[name]
    module = getattr(obj, "__module__", "")
    for mod_prefix, cat in _MODULE_CATEGORY.items():
        if module == mod_prefix or module.startswith(mod_prefix + "."):
            return cat
    return "other"


# ---------------------------------------------------------------------------
# Top-level dispatch
# ---------------------------------------------------------------------------


def _extract_symbol(name: str, obj: Any) -> dict[str, Any]:
    """Route a symbol to the appropriate kind-specific extractor."""
    # Check for known aliases first
    if _is_alias(name, obj):
        return _extract_alias(name, obj)

    if inspect.isclass(obj):
        return _extract_class(name, obj)

    if inspect.isfunction(obj):
        return _extract_function(name, obj)

    # Type alias (e.g. PlatformConfig = dict[str, Any])
    return {
        "name": name,
        "kind": "alias",
        "type": _format_annotation(obj),
        "description": "",
    }


def _is_alias(name: str, obj: Any) -> bool:
    """Detect backward-compatibility aliases like PluginExperimentData."""
    import mint_sdk

    if name == "PluginExperimentData":
        design_data = getattr(mint_sdk, "DesignData", None)
        return obj is design_data
    return False


def _extract_alias(name: str, obj: Any) -> dict[str, Any]:
    """Extract info for a known alias."""
    target_name = obj.__name__ if hasattr(obj, "__name__") else str(obj)
    return {
        "name": name,
        "kind": "alias",
        "target": target_name,
        "description": f"Backward-compatibility alias for {target_name}.",
    }


# ---------------------------------------------------------------------------
# Class dispatch
# ---------------------------------------------------------------------------


def _extract_class(name: str, cls: type) -> dict[str, Any]:
    """Route to the appropriate class extractor based on kind."""
    if hasattr(cls, "__dataclass_fields__"):
        return _extract_dataclass(name, cls)
    if issubclass(cls, Enum):
        return _extract_enum(name, cls)
    if issubclass(cls, Exception):
        return _extract_exception(name, cls)
    if getattr(cls, "_is_protocol", False):
        return _extract_protocol(name, cls)
    if ABC in cls.__mro__:
        return _extract_abc_class(name, cls)
    # Regular class
    return _extract_regular_class(name, cls)


# ---------------------------------------------------------------------------
# Kind extractors
# ---------------------------------------------------------------------------


def _extract_dataclass(name: str, cls: type) -> dict[str, Any]:
    """Extract fields, defaults, and types from a dataclass."""
    fields = []
    for f in dc_fields(cls):
        field_info: dict[str, Any] = {
            "name": f.name,
            "type": _format_annotation(f.type),
        }
        if f.default is not MISSING:
            field_info["default"] = repr(f.default)
            field_info["required"] = False
        elif f.default_factory is not MISSING:
            field_info["default"] = "factory"
            field_info["required"] = False
        else:
            field_info["required"] = True

        fields.append(field_info)

    methods = _extract_public_methods(cls, skip_dunder=True)

    return {
        "name": name,
        "kind": "dataclass",
        "module": _module_path(cls),
        "description": _first_paragraph(cls),
        "fields": fields,
        "methods": methods,
    }


def _extract_enum(name: str, cls: type) -> dict[str, Any]:
    """Extract enum members and their values."""
    members = [
        {"name": m.name, "value": m.value}
        for m in cls  # type: ignore[arg-type]
    ]
    return {
        "name": name,
        "kind": "enum",
        "module": _module_path(cls),
        "description": _first_paragraph(cls),
        "members": members,
    }


def _extract_exception(name: str, cls: type) -> dict[str, Any]:
    """Extract exception hierarchy and __init__ signature."""
    parents = [
        base.__name__
        for base in cls.__mro__[1:]
        if base not in (object, Exception, BaseException)
        and issubclass(base, Exception)
    ]
    init = getattr(cls, "__init__", None)
    params = _extract_params(init) if init else []

    return {
        "name": name,
        "kind": "exception",
        "module": _module_path(cls),
        "description": _first_paragraph(cls),
        "parents": parents,
        "init_params": params,
    }


def _extract_protocol(name: str, cls: type) -> dict[str, Any]:
    """Extract method stubs from a Protocol class."""
    methods = []
    for attr_name in sorted(dir(cls)):
        if attr_name.startswith("_"):
            continue
        attr = getattr(cls, attr_name, None)
        if attr is None or not callable(attr):
            continue
        methods.append(_extract_method_info(attr_name, attr))

    return {
        "name": name,
        "kind": "protocol",
        "module": _module_path(cls),
        "description": _first_paragraph(cls),
        "methods": methods,
    }


def _extract_abc_class(name: str, cls: type) -> dict[str, Any]:
    """Extract abstract and concrete methods from an ABC."""
    abstract_names = getattr(cls, "__abstractmethods__", frozenset())

    abstract_methods = []
    concrete_methods = []
    properties = []

    for attr_name in sorted(dir(cls)):
        if attr_name.startswith("_") and not attr_name.startswith("__"):
            continue
        if attr_name.startswith("__") and attr_name != "__init__":
            continue

        attr = getattr(cls, attr_name, None)
        if attr is None:
            continue

        # Find the defining class and check if it's a property
        is_property = False
        for klass in cls.__mro__:
            if attr_name in klass.__dict__:
                raw = klass.__dict__[attr_name]
                if isinstance(raw, property):
                    is_property = True
                    prop_info = {
                        "name": attr_name,
                        "type": _format_annotation(
                            raw.fget.__annotations__.get("return", "")
                        )
                        if raw.fget
                        else "",
                        "description": _first_paragraph(raw.fget) if raw.fget else "",
                        "abstract": attr_name in abstract_names,
                    }
                    properties.append(prop_info)
                break

        if not is_property and callable(attr):
            method_info = _extract_method_info(attr_name, attr)
            method_info["abstract"] = attr_name in abstract_names
            if attr_name in abstract_names:
                abstract_methods.append(method_info)
            else:
                concrete_methods.append(method_info)

    return {
        "name": name,
        "kind": "class",
        "module": _module_path(cls),
        "description": _first_paragraph(cls),
        "properties": properties,
        "abstract_methods": abstract_methods,
        "concrete_methods": concrete_methods,
    }


def _extract_regular_class(name: str, cls: type) -> dict[str, Any]:
    """Extract info from a regular (non-ABC, non-dataclass) class."""
    methods = _extract_public_methods(cls, skip_dunder=False)
    properties = []

    for attr_name in sorted(dir(cls)):
        for klass in cls.__mro__:
            if attr_name in klass.__dict__:
                raw = klass.__dict__[attr_name]
                if isinstance(raw, property):
                    prop_info = {
                        "name": attr_name,
                        "type": _format_annotation(
                            raw.fget.__annotations__.get("return", "")
                        )
                        if raw.fget
                        else "",
                        "description": _first_paragraph(raw.fget) if raw.fget else "",
                    }
                    properties.append(prop_info)
                break

    return {
        "name": name,
        "kind": "class",
        "module": _module_path(cls),
        "description": _first_paragraph(cls),
        "properties": properties,
        "methods": methods,
    }


def _extract_function(name: str, func: Any) -> dict[str, Any]:
    """Extract signature and docstring from a standalone function."""
    return {
        "name": name,
        "kind": "function",
        "module": getattr(func, "__module__", ""),
        "description": _first_paragraph(func),
        "params": _extract_params(func),
        "return_type": _get_return_type(func),
    }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_public_methods(
    cls: type, *, skip_dunder: bool = True
) -> list[dict[str, Any]]:
    """Extract public methods from a class, excluding inherited object methods."""
    methods = []
    for attr_name in sorted(dir(cls)):
        if attr_name.startswith("_") and (skip_dunder or attr_name != "__init__"):
            continue

        # Only include methods defined on this class or its direct parents (not object)
        attr = None
        for klass in cls.__mro__:
            if klass is object:
                break
            if attr_name in klass.__dict__:
                raw = klass.__dict__[attr_name]
                if isinstance(raw, property):
                    attr = None  # skip properties
                    break
                attr = getattr(cls, attr_name, None)
                break

        if attr is not None and callable(attr):
            methods.append(_extract_method_info(attr_name, attr))

    return methods


def _extract_method_info(name: str, method: Any) -> dict[str, Any]:
    """Extract info from a single method."""
    info: dict[str, Any] = {
        "name": name,
        "description": _first_paragraph(method),
        "params": _extract_params(method),
        "return_type": _get_return_type(method),
    }
    if inspect.iscoroutinefunction(method):
        info["async"] = True
    return info


def _extract_params(func: Any) -> list[dict[str, Any]]:
    """Extract parameter info from a callable's signature."""
    try:
        sig = inspect.signature(func)
    except (ValueError, TypeError):
        return []

    params = []
    for pname, param in sig.parameters.items():
        if pname in ("self", "cls"):
            continue
        p: dict[str, Any] = {"name": pname}
        if param.annotation is not inspect.Parameter.empty:
            p["type"] = _format_annotation(param.annotation)
        if param.default is not inspect.Parameter.empty:
            p["default"] = repr(param.default)
        params.append(p)
    return params


def _get_return_type(func: Any) -> str:
    """Get the return type annotation as a string."""
    try:
        sig = inspect.signature(func)
    except (ValueError, TypeError):
        return ""
    if sig.return_annotation is inspect.Signature.empty:
        return ""
    return _format_annotation(sig.return_annotation)


def _format_annotation(ann: Any) -> str:
    """Convert a type annotation to a human-readable string."""
    if ann is None or ann == "":
        return ""
    if isinstance(ann, str):
        return ann
    if hasattr(ann, "__name__"):
        return ann.__name__
    # Handle typing generics (Optional, list[...], dict[...], etc.)
    return str(ann).replace("typing.", "").replace("mint_sdk.", "")


def _first_paragraph(obj: Any) -> str:
    """Extract the first paragraph of an object's docstring."""
    doc = inspect.getdoc(obj)
    if not doc:
        return ""
    # Take up to the first blank line
    lines = []
    for line in doc.splitlines():
        if line.strip() == "" and lines:
            break
        lines.append(line.strip())
    return " ".join(lines)


def _module_path(cls: type) -> str:
    """Return the module path for a class."""
    return getattr(cls, "__module__", "")
