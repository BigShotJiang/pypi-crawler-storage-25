"""
Base plugin class for MINT analysis plugins.

This module provides the AnalysisPlugin base class that all plugins must inherit
from, as well as lifecycle hooks and health status interfaces.
"""

from abc import ABC, abstractmethod
from collections.abc import AsyncGenerator, Callable
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import TYPE_CHECKING, Any, Optional

from mint_sdk.context import PlatformContext
from mint_sdk.models import PluginMetadata

if TYPE_CHECKING:
    from fastapi import APIRouter

    from mint_sdk.local_database import LocalDatabase
    from mint_sdk.repositories import DesignData, PluginAnalysisResult, PluginDataRepository


class HealthStatus(str, Enum):
    """Plugin health status values."""

    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


@dataclass(slots=True)
class PluginHealth:
    """Plugin health status report."""

    status: HealthStatus = HealthStatus.HEALTHY
    message: Optional[str] = None
    details: dict[str, Any] = field(default_factory=dict)
    checked_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    def to_dict(self) -> dict[str, Any]:
        """Convert to dict for API responses."""
        result = {
            "status": self.status.value,
            "checked_at": self.checked_at.isoformat(),
        }
        if self.message:
            result["message"] = self.message
        if self.details:
            result["details"] = self.details
        return result


@dataclass(slots=True)
class LifecycleHookResult:
    """Result from a lifecycle hook."""

    success: bool = True
    message: Optional[str] = None
    data: dict[str, Any] = field(default_factory=dict)


class AnalysisPlugin(ABC):
    """
    Abstract base class for analysis plugins.

    Plugins implement this interface to integrate with the MINT platform.
    They can run in two modes:
    - Standalone: No platform context, uses local SQLite for plugin tables
    - Integrated: Full platform context with PostgreSQL shared schema
    """

    #: Optional Pydantic model for typed plugin settings.
    #: When declared, ``self.settings`` returns a typed instance,
    #: ``apply_settings()`` auto-validates, and ``get_configurable_settings()``
    #: is auto-generated from model fields.
    #:
    #: Example::
    #:
    #:     class MySettings(BaseModel):
    #:         threshold: float = 2.5
    #:         method: str = "default"
    #:
    #:     class MyPlugin(AnalysisPlugin):
    #:         settings_model = MySettings
    settings_model: type | None = None

    def __init__(self) -> None:
        self._context: Optional[PlatformContext] = None
        self._standalone_db: Optional[LocalDatabase] = None
        self._settings: Any = None
        self._save_settings_callback: Optional[Callable[[dict[str, Any]], None]] = None

    @property
    @abstractmethod
    def metadata(self) -> PluginMetadata:
        """Return plugin metadata."""
        pass

    @abstractmethod
    def get_routers(self) -> list[tuple["APIRouter", str]]:
        """Return list of (router, sub_prefix) tuples.

        The sub_prefix is the path segment appended after the plugin's base
        route prefix. For example, returning (router, "/instruments") for a
        plugin with routes_prefix="/ms-planner" mounts routes at
        /api/ms-planner/instruments.

        Do NOT set prefix= on the APIRouter itself — the sub_prefix is the
        single source of truth for route paths in both standalone and
        integrated modes.
        """
        pass

    @abstractmethod
    async def initialize(self, context: Optional[PlatformContext] = None) -> None:
        """Initialize the plugin."""
        pass

    @abstractmethod
    async def shutdown(self) -> None:
        """Clean up plugin resources."""
        pass

    # --- Optional lifecycle hooks ---

    async def check_health(self) -> PluginHealth:
        """Check plugin health status."""
        return PluginHealth(status=HealthStatus.HEALTHY)

    async def on_before_experiment_save(self, experiment_id: int, data: dict[str, Any]) -> LifecycleHookResult:
        """Called before experiment data is saved."""
        return LifecycleHookResult(success=True)

    async def on_after_experiment_save(self, experiment_id: int, data: dict[str, Any]) -> None:
        """Called after experiment data is saved successfully."""
        pass

    async def on_experiment_status_change(self, experiment_id: int, old_status: str, new_status: str) -> None:
        """Called when experiment status changes."""
        pass

    # --- Properties ---

    @property
    def context(self) -> Optional[PlatformContext]:
        """Get the platform context (None if standalone)."""
        return self._context

    @property
    def is_standalone(self) -> bool:
        """Check if running in standalone mode."""
        return self._context is None

    # --- Optional overrides ---

    def get_frontend_config(self) -> dict[str, Any]:
        """Return frontend configuration for this plugin."""
        config: dict[str, Any] = {
            "name": self.metadata.name,
            "version": self.metadata.version,
            "routePrefix": self.metadata.routes_prefix,
            "analysisType": self.metadata.analysis_type,
        }
        if self.metadata.icon:
            config["icon"] = self.metadata.icon
        return config

    def get_frontend_dir(self) -> Optional[str]:
        """Return the path to the plugin's built frontend directory.

        Default implementation checks two locations:

        1. ``<plugin_module_dir>/frontend`` — bundled with the installed package
        2. ``<project_root>/frontend/dist`` — dev fallback (Vite build output)

        Override if your frontend lives elsewhere.
        """
        import sys

        mod = sys.modules.get(type(self).__module__)
        if mod is None or not hasattr(mod, "__file__") or mod.__file__ is None:
            return None
        from pathlib import Path

        plugin_dir = Path(mod.__file__).parent
        # Installed: frontend bundled alongside plugin module
        candidate = plugin_dir / "frontend"
        if candidate.is_dir():
            return str(candidate)
        # Dev: frontend/dist relative to project root (src layout: module/../../../frontend/dist)
        for levels in (3, 2):
            candidate = plugin_dir.parents[levels - 1] / "frontend" / "dist"
            if candidate.is_dir():
                return str(candidate)
        return None

    def get_compatible_platform_versions(self) -> Optional[tuple[str, str]]:
        """Return the range of compatible platform versions."""
        return None

    @property
    def settings(self) -> Any:
        """Current plugin settings.

        Returns a typed instance when ``settings_model`` is declared,
        otherwise the raw dict passed to ``apply_settings()``.
        If no settings have been applied yet, returns the model's defaults
        (when ``settings_model`` is set) or an empty dict.
        """
        if self._settings is not None:
            return self._settings
        if self.settings_model is not None:
            return self.settings_model()
        return {}

    def get_configurable_settings(self) -> list[dict[str, Any]]:
        """Return list of configurable settings for this plugin.

        When ``settings_model`` is declared, this is auto-generated from
        the Pydantic model fields.  Override to customise labels or
        descriptions beyond what the model provides.
        """
        if self.settings_model is None:
            return []
        return self._settings_from_model(self.settings_model)

    def apply_settings(self, settings: dict[str, Any]) -> None:
        """Apply saved configuration settings to the plugin.

        Called by the platform after ``initialize()`` with settings stored
        in the platform config.  When ``settings_model`` is declared, the
        dict is validated and converted into a typed instance accessible
        via ``self.settings``.

        Override this to add custom post-application logic (e.g. updating
        internal service state).  Call ``super().apply_settings(settings)``
        first to populate ``self.settings``.
        """
        if self.settings_model is not None:
            self._settings = self.settings_model.model_validate(settings)
        else:
            self._settings = dict(settings)

    def save_settings(self, settings: "dict[str, Any] | Any") -> None:
        """Persist plugin settings to the platform's centralized config store.

        Intended for use when the plugin's own UI mutates configuration
        (e.g. a built-in Settings page) and the change must survive restart.

        Accepts either a plain dict or a Pydantic model instance.  When
        ``settings_model`` is declared, the payload is validated and
        ``self._settings`` is refreshed so ``self.settings`` reflects the
        new values immediately.

        In integrated mode, the platform wires a callback at startup that
        writes to ``config.json`` → ``plugins.settings.{name}``.
        In standalone mode (no callback), updates in-memory state only;
        subclasses can override to add standalone persistence if needed.

        Raises:
            pydantic.ValidationError: if ``settings_model`` is declared and
                the payload fails validation.
        """
        data = settings.model_dump() if hasattr(settings, "model_dump") else dict(settings)

        if self.settings_model is not None:
            instance = self.settings_model.model_validate(data)
            self._settings = instance
            data = instance.model_dump()
        else:
            self._settings = data

        if self._save_settings_callback is not None:
            self._save_settings_callback(data)

    def _set_save_settings_callback(
        self, callback: Optional[Callable[[dict[str, Any]], None]]
    ) -> None:
        """Wire (or clear) the persistence callback.

        Called by the platform loader during plugin initialization.
        Plugins should not call this directly.
        """
        self._save_settings_callback = callback

    @staticmethod
    def _settings_from_model(model: type) -> list[dict[str, Any]]:
        """Derive configurable settings list from a Pydantic model."""
        result: list[dict[str, Any]] = []
        for name, field_info in model.model_fields.items():
            annotation = field_info.annotation
            # Map Python types to setting types
            if annotation is bool or annotation is Optional[bool]:
                stype = "boolean"
            elif annotation in (int, float) or annotation in (Optional[int], Optional[float]):
                stype = "number"
            else:
                stype = "string"

            entry: dict[str, Any] = {
                "key": name,
                "label": (field_info.title or name.replace("_", " ").title()),
                "type": stype,
                "description": field_info.description or "",
            }
            if field_info.is_required():
                entry["required"] = True
            elif field_info.default is not None:
                entry["default"] = field_info.default
            # Numeric constraints from field metadata
            for meta in field_info.metadata:
                if hasattr(meta, "ge"):
                    entry["min"] = meta.ge
                if hasattr(meta, "le"):
                    entry["max"] = meta.le
            result.append(entry)
        return result

    # --- Data export ---

    def export_tree(self, data: dict[str, Any]) -> list[dict[str, Any]]:
        """Convert plugin data to TreeNode list for hierarchical display.

        Override this to provide biology-aware tree structures specific to
        your plugin's data schema. Default uses compact JSON-to-tree mapping
        that filters nulls, empty lists, and collapses scalar nodes.

        Returns:
            List of dicts matching the frontend TreeNode interface:
            {id, label, type?, children?, badge?, metadata?}
        """
        from mint_sdk.export import auto_json_to_tree

        return auto_json_to_tree(data, compact=True)

    def export_summary(self, data: dict[str, Any]) -> dict[str, Any]:
        """Convert plugin data to a structured summary for compact display.

        Override this to provide plugin-specific summary formatting.
        Default uses generic JSON-to-summary mapping that detects
        arrays-of-objects and separates metadata from structural data.

        Returns:
            Dict with 'metadata' (scalar key-values) and 'sections'
            (list of table/group section dicts).
        """
        from mint_sdk.export import auto_json_to_summary

        return auto_json_to_summary(data)

    def export_csv(self, data: dict[str, Any]) -> str:
        """Convert plugin data to CSV string for download.

        Override this to provide plugin-specific CSV formatting.
        Default uses generic JSON-to-CSV flattening.

        Returns:
            CSV-formatted string.
        """
        from mint_sdk.export import auto_json_to_csv

        return auto_json_to_csv(data)

    # --- Convenience save/load methods ---

    def _get_data_repo(self) -> Optional["PluginDataRepository"]:
        """Get the PluginDataRepository, or None if standalone."""
        if self._context is None:
            return None
        return self._context.get_plugin_data_repository()

    @property
    def plugin_id(self) -> str:
        """The plugin identifier used for data persistence.

        Defaults to ``metadata.name``. Override this property if your plugin
        uses a different identifier for its stored data rows (e.g., for
        backward compatibility with existing database entries).
        """
        return self.metadata.name

    async def save_design(
        self,
        experiment_id: int,
        data: dict[str, Any],
        *,
        schema_version: str | None = None,
    ) -> Optional["DesignData"]:
        """Save design data for an experiment.

        Args:
            experiment_id: The experiment to save to.
            data: Design data dict.
            schema_version: Override schema version
                (defaults to ``metadata.schema_version``).

        Returns:
            The saved DesignData, or None if running standalone.
        """
        repo = self._get_data_repo()
        if repo is None:
            return None
        return await repo.save_experiment_data(
            experiment_id=experiment_id,
            plugin_id=self.plugin_id,
            data=data,
            schema_version=schema_version or self.metadata.schema_version,
        )

    async def load_design(self, experiment_id: int) -> Optional["DesignData"]:
        """Load design data for an experiment.

        Returns:
            The DesignData, or None if not found or standalone.
        """
        repo = self._get_data_repo()
        if repo is None:
            return None
        return await repo.get_experiment_data(experiment_id)

    async def save_analysis(
        self,
        experiment_id: int,
        result: dict[str, Any],
    ) -> Optional["PluginAnalysisResult"]:
        """Save analysis result for an experiment.

        Returns:
            The saved PluginAnalysisResult, or None if standalone.
        """
        repo = self._get_data_repo()
        if repo is None:
            return None
        return await repo.save_analysis_result(
            experiment_id=experiment_id,
            plugin_id=self.plugin_id,
            result=result,
        )

    async def load_analysis(
        self, experiment_id: int
    ) -> Optional["PluginAnalysisResult"]:
        """Load analysis result for this plugin on an experiment.

        Returns:
            The PluginAnalysisResult, or None if not found or standalone.
        """
        repo = self._get_data_repo()
        if repo is None:
            return None
        return await repo.get_analysis_result(experiment_id, self.plugin_id)

    async def save(
        self,
        experiment_id: int,
        *,
        design: dict[str, Any] | None = None,
        analysis: dict[str, Any] | None = None,
        schema_version: str | None = None,
    ) -> tuple[Optional["DesignData"], Optional["PluginAnalysisResult"]]:
        """Save design data and/or analysis result in one call.

        Only saves the columns for which data is provided.

        Returns:
            Tuple of (DesignData or None, PluginAnalysisResult or None).
        """
        design_result = None
        analysis_result = None
        if design is not None:
            design_result = await self.save_design(
                experiment_id, design, schema_version=schema_version
            )
        if analysis is not None:
            analysis_result = await self.save_analysis(experiment_id, analysis)
        return design_result, analysis_result

    async def load(
        self, experiment_id: int
    ) -> tuple[Optional["DesignData"], Optional["PluginAnalysisResult"]]:
        """Load both design data and analysis result.

        Returns:
            Tuple of (DesignData or None, PluginAnalysisResult or None).
        """
        design = await self.load_design(experiment_id)
        analysis = await self.load_analysis(experiment_id)
        return design, analysis

    async def delete_design(self, experiment_id: int) -> bool:
        """Delete design data for an experiment."""
        repo = self._get_data_repo()
        if repo is None:
            return False
        return await repo.delete_experiment_data(experiment_id)

    async def delete_analysis(self, experiment_id: int) -> bool:
        """Delete analysis result for this plugin on an experiment."""
        repo = self._get_data_repo()
        if repo is None:
            return False
        return await repo.delete_analysis_result(experiment_id, self.plugin_id)

    # --- Shared database support ---

    def get_shared_models(self) -> list[type]:
        """Return SQLModel/SQLAlchemy model classes for plugin tables.

        Override this to declare tables that will be created in the plugin's
        shared database schema (PostgreSQL when integrated, SQLite when standalone).

        Returns:
            List of model classes with __table__ attribute.
        """
        return []

    def get_migrations_package(self) -> str | None:
        """Return the import path to the plugin's migrations package.

        Override this to enable versioned schema migrations.  The package
        must contain modules with :class:`~mint_sdk.migrations.PluginMigration`
        subclasses (one ``Migration`` class per file).

        Example::

            def get_migrations_package(self) -> str:
                return "mld_plugin_ms_planner.migrations"

        Returns ``None`` (no migrations) by default.  Plugins that return
        ``None`` continue to use ``get_shared_models()`` + ``create_all``.
        """
        return None

    @asynccontextmanager
    async def get_plugin_db_session(self) -> AsyncGenerator[Any, None]:
        """Unified DB access -- PostgreSQL (platform) or SQLite (standalone).

        Yields an async session. When running integrated, delegates to the
        platform's shared schema session. When standalone, uses local SQLite.
        """
        if self._context:
            async with self._context.get_shared_db_session() as session:
                yield session
        else:
            if self._standalone_db is None:
                raise RuntimeError("Standalone database not initialized. Call _setup_standalone_db() in initialize().")
            async with self._standalone_db.get_async_session() as session:
                yield session

    # --- Standalone database (SQLite fallback) ---

    @property
    def standalone_db(self) -> Optional["LocalDatabase"]:
        """Get the standalone database instance, or None if not set up."""
        return self._standalone_db

    def _setup_standalone_db(self, storage_dir: "Any | None" = None) -> None:
        """Initialize the standalone SQLite database.

        Args:
            storage_dir: Override the storage directory for the database.
        """
        if self._standalone_db is not None:
            if getattr(self._standalone_db, "is_initialized", False):
                return
            # Close the partially initialized instance before replacing
            try:
                self._standalone_db.close()
            except Exception:
                pass
            self._standalone_db = None

        from pathlib import Path

        from mint_sdk.local_database import LocalDatabase, LocalDatabaseConfig

        config = LocalDatabaseConfig()
        if storage_dir is not None:
            config.storage_dir = Path(storage_dir) if not isinstance(storage_dir, Path) else storage_dir
        self._standalone_db = LocalDatabase(self.metadata.name, config)
        self._standalone_db.initialize(models=self.get_shared_models())

    def _teardown_standalone_db(self) -> None:
        """Close the standalone database."""
        if self._standalone_db is not None:
            self._standalone_db.close()
            self._standalone_db = None

    # --- Backward compatibility ---

    @property
    def local_db(self) -> Optional["LocalDatabase"]:
        """Backward compat: alias for standalone_db."""
        return self._standalone_db

    def get_local_models(self) -> list[type]:
        """Backward compat: alias for get_shared_models()."""
        return self.get_shared_models()

    def _setup_local_database(self, storage_dir: "Any | None" = None) -> None:
        """Backward compat: alias for _setup_standalone_db()."""
        self._setup_standalone_db(storage_dir)

    def _teardown_local_database(self) -> None:
        """Backward compat: alias for _teardown_standalone_db()."""
        self._teardown_standalone_db()
