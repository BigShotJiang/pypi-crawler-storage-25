"""Shared utilities for CLI command modules."""

from __future__ import annotations

import json
import sys


def get_client(*, base_url: str | None = None):
    """Create an MINTClient."""
    try:
        from mint_sdk.client import MINTClient

        return MINTClient(base_url=base_url) if base_url else MINTClient()
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def print_json(data: object) -> None:
    """Pretty-print a JSON-serializable object."""
    print(json.dumps(data, indent=2, default=str))
