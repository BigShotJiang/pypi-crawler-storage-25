"""MINT platform API client.

Usage:
    from mint_sdk.client import MINTClient

    client = MINTClient("http://localhost:8001")
    client.login("admin", "password")
    experiments = client.experiments.list()
"""

from mint_sdk.client._exceptions import (
    AuthenticationError,
    ConflictError,
    MINTAPIError,
    MINTConnectionError,
    MINTPermissionError,
    MINTValidationError,
    NotFoundError,
    RateLimitError,
    ServerError,
)
from mint_sdk.client.client import MINTClient

__all__ = [
    "MINTClient",
    "MINTAPIError",
    "AuthenticationError",
    "MINTPermissionError",
    "NotFoundError",
    "ConflictError",
    "MINTValidationError",
    "RateLimitError",
    "ServerError",
    "MINTConnectionError",
]
