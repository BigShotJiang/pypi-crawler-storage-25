"""Plugins resource for the MINT API client."""

from __future__ import annotations

from typing import Any

from mint_sdk.client._http import HTTPClient


class PluginsAPI:
    """Plugin listing operations."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def list(self) -> list[dict[str, Any]]:
        """List loaded plugins on the platform."""
        return self._http.get("/plugins")
