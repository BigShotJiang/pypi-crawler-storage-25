"""Tests for the ``settings_model`` pattern on ``AnalysisPlugin``.

Plugins declare a Pydantic ``BaseModel`` subclass as ``settings_model``.
The SDK then:

- auto-generates ``get_configurable_settings()`` from model fields,
- validates and stores typed settings via ``apply_settings()``,
- exposes typed access through the ``settings`` property.
"""

from __future__ import annotations

import pytest
from mint_sdk.models import PluginMetadata
from mint_sdk.plugin import AnalysisPlugin
from pydantic import BaseModel, Field, ValidationError


def _make_plugin(settings_model: type | None = None) -> AnalysisPlugin:
    """Create a minimal concrete plugin, optionally bound to a settings_model."""

    class _Plugin(AnalysisPlugin):
        @property
        def metadata(self) -> PluginMetadata:
            return PluginMetadata(
                name="settings-test",
                version="1.0.0",
                description="test",
                analysis_type="test",
                routes_prefix="/settings-test",
            )

        def get_routers(self):
            return []

        async def initialize(self, context=None):
            self._context = context

        async def shutdown(self):
            pass

    _Plugin.settings_model = settings_model
    return _Plugin()


class TestNoSettingsModel:
    """Backwards-compat path: plugins without a settings_model still work."""

    def test_get_configurable_settings_returns_empty_list(self):
        plugin = _make_plugin()
        assert plugin.get_configurable_settings() == []

    def test_settings_property_returns_empty_dict(self):
        plugin = _make_plugin()
        assert plugin.settings == {}

    def test_apply_settings_stores_raw_dict(self):
        plugin = _make_plugin()
        plugin.apply_settings({"foo": "bar", "count": 3})
        assert plugin.settings == {"foo": "bar", "count": 3}

    def test_apply_settings_copies_dict(self):
        plugin = _make_plugin()
        payload = {"foo": "bar"}
        plugin.apply_settings(payload)
        payload["mutated"] = True
        assert "mutated" not in plugin.settings


class TestSettingsModelFieldDerivation:
    """``get_configurable_settings()`` auto-generates from Pydantic fields."""

    def test_string_field_maps_to_string_type(self):
        class Settings(BaseModel):
            method: str = "default"

        entry = _make_plugin(Settings).get_configurable_settings()[0]
        assert entry["key"] == "method"
        assert entry["type"] == "string"
        assert entry["default"] == "default"

    def test_bool_field_maps_to_boolean_type(self):
        class Settings(BaseModel):
            verbose: bool = False

        entry = _make_plugin(Settings).get_configurable_settings()[0]
        assert entry["type"] == "boolean"
        assert entry["default"] is False

    def test_int_field_maps_to_number_type(self):
        class Settings(BaseModel):
            max_iter: int = 10

        entry = _make_plugin(Settings).get_configurable_settings()[0]
        assert entry["type"] == "number"
        assert entry["default"] == 10

    def test_float_field_maps_to_number_type(self):
        class Settings(BaseModel):
            threshold: float = 2.5

        entry = _make_plugin(Settings).get_configurable_settings()[0]
        assert entry["type"] == "number"
        assert entry["default"] == 2.5

    def test_auto_label_from_field_name(self):
        class Settings(BaseModel):
            max_iter_count: int = 10

        entry = _make_plugin(Settings).get_configurable_settings()[0]
        assert entry["label"] == "Max Iter Count"

    def test_explicit_title_overrides_auto_label(self):
        class Settings(BaseModel):
            threshold: float = Field(default=2.5, title="Detection Threshold")

        entry = _make_plugin(Settings).get_configurable_settings()[0]
        assert entry["label"] == "Detection Threshold"

    def test_description_is_forwarded(self):
        class Settings(BaseModel):
            threshold: float = Field(default=2.5, description="z-score cutoff")

        entry = _make_plugin(Settings).get_configurable_settings()[0]
        assert entry["description"] == "z-score cutoff"

    def test_missing_description_becomes_empty_string(self):
        class Settings(BaseModel):
            method: str = "default"

        entry = _make_plugin(Settings).get_configurable_settings()[0]
        assert entry["description"] == ""

    def test_numeric_ge_le_become_min_max(self):
        class Settings(BaseModel):
            ratio: float = Field(default=0.5, ge=0.0, le=1.0)

        entry = _make_plugin(Settings).get_configurable_settings()[0]
        assert entry["min"] == 0.0
        assert entry["max"] == 1.0

    def test_required_field_is_marked_required(self):
        class Settings(BaseModel):
            # No default → required
            api_key: str

        entry = _make_plugin(Settings).get_configurable_settings()[0]
        assert entry.get("required") is True
        # Required fields have no default key
        assert "default" not in entry

    def test_all_fields_appear_in_order(self):
        class Settings(BaseModel):
            alpha: int = 1
            beta: str = "x"
            gamma: bool = True

        entries = _make_plugin(Settings).get_configurable_settings()
        assert [e["key"] for e in entries] == ["alpha", "beta", "gamma"]


class TestApplySettings:
    """``apply_settings()`` validates and stores a typed model instance."""

    def test_stores_typed_instance(self):
        class Settings(BaseModel):
            threshold: float = 2.5
            method: str = "default"

        plugin = _make_plugin(Settings)
        plugin.apply_settings({"threshold": 5.0, "method": "robust"})

        assert isinstance(plugin.settings, Settings)
        assert plugin.settings.threshold == 5.0
        assert plugin.settings.method == "robust"

    def test_validates_types_and_rejects_bad_payload(self):
        class Settings(BaseModel):
            threshold: float

        plugin = _make_plugin(Settings)
        with pytest.raises(ValidationError):
            plugin.apply_settings({"threshold": "not-a-number"})

    def test_respects_numeric_constraints(self):
        class Settings(BaseModel):
            ratio: float = Field(ge=0.0, le=1.0)

        plugin = _make_plugin(Settings)
        with pytest.raises(ValidationError):
            plugin.apply_settings({"ratio": 1.5})

    def test_partial_payload_fills_defaults(self):
        class Settings(BaseModel):
            threshold: float = 2.5
            method: str = "default"

        plugin = _make_plugin(Settings)
        plugin.apply_settings({"method": "robust"})

        assert plugin.settings.threshold == 2.5
        assert plugin.settings.method == "robust"


class TestSettingsPropertyBeforeApply:
    """``settings`` returns model defaults when nothing has been applied yet."""

    def test_returns_model_defaults_when_settings_model_declared(self):
        class Settings(BaseModel):
            threshold: float = 2.5
            verbose: bool = False

        plugin = _make_plugin(Settings)
        assert isinstance(plugin.settings, Settings)
        assert plugin.settings.threshold == 2.5
        assert plugin.settings.verbose is False

    def test_returns_empty_dict_when_no_settings_model(self):
        assert _make_plugin().settings == {}


class TestSaveSettings:
    """``save_settings()`` persists plugin-initiated config changes via callback."""

    def test_invokes_callback_with_validated_dict(self):
        class Settings(BaseModel):
            threshold: float = 2.5
            method: str = "default"

        plugin = _make_plugin(Settings)
        captured: list[dict] = []
        plugin._set_save_settings_callback(captured.append)

        plugin.save_settings({"threshold": 5.0, "method": "robust"})

        assert captured == [{"threshold": 5.0, "method": "robust"}]

    def test_accepts_pydantic_model_instance(self):
        class Settings(BaseModel):
            threshold: float = 2.5

        plugin = _make_plugin(Settings)
        captured: list[dict] = []
        plugin._set_save_settings_callback(captured.append)

        plugin.save_settings(Settings(threshold=7.0))

        assert captured == [{"threshold": 7.0}]

    def test_updates_in_memory_settings_synchronously(self):
        class Settings(BaseModel):
            threshold: float = 2.5

        plugin = _make_plugin(Settings)
        plugin._set_save_settings_callback(lambda _data: None)

        plugin.save_settings({"threshold": 9.9})

        assert isinstance(plugin.settings, Settings)
        assert plugin.settings.threshold == 9.9

    def test_validates_and_rejects_invalid_payload(self):
        class Settings(BaseModel):
            ratio: float = Field(ge=0.0, le=1.0)

        plugin = _make_plugin(Settings)
        captured: list[dict] = []
        plugin._set_save_settings_callback(captured.append)

        with pytest.raises(ValidationError):
            plugin.save_settings({"ratio": 1.5})

        # Callback must not fire when validation fails
        assert captured == []

    def test_no_callback_does_not_raise(self):
        """Standalone mode: plugin without a wired callback updates memory silently."""

        class Settings(BaseModel):
            threshold: float = 2.5

        plugin = _make_plugin(Settings)
        plugin.save_settings({"threshold": 3.3})
        assert plugin.settings.threshold == 3.3

    def test_works_without_settings_model(self):
        plugin = _make_plugin()
        captured: list[dict] = []
        plugin._set_save_settings_callback(captured.append)

        plugin.save_settings({"key": "value", "n": 7})

        assert captured == [{"key": "value", "n": 7}]
        assert plugin.settings == {"key": "value", "n": 7}

    def test_callback_can_be_cleared(self):
        plugin = _make_plugin()
        seen: list[dict] = []
        plugin._set_save_settings_callback(seen.append)
        plugin._set_save_settings_callback(None)

        plugin.save_settings({"k": "v"})

        assert seen == []
