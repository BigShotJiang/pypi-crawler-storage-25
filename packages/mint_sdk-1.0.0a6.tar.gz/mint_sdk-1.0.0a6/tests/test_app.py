"""Tests for mint_sdk.app module (standalone app factory and helpers)."""

from __future__ import annotations

from typing import Any, Optional
from unittest.mock import AsyncMock, patch

import pytest
from mint_sdk.app import PluginDependency, create_standalone_app, require_context
from mint_sdk.models import PluginMetadata
from mint_sdk.plugin import AnalysisPlugin


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


class StubPlugin(AnalysisPlugin):
    """Minimal plugin for testing."""

    @property
    def metadata(self) -> PluginMetadata:
        return PluginMetadata(
            name="test-plugin",
            version="1.0.0",
            description="Test plugin",
            analysis_type="test",
            routes_prefix="/test",
        )

    def get_routers(self):
        return []

    async def initialize(self, context=None):
        self._context = context

    async def shutdown(self):
        pass


class MockContext:
    """Minimal mock PlatformContext."""
    pass


# ---------------------------------------------------------------------------
# PluginDependency
# ---------------------------------------------------------------------------


class TestPluginDependency:
    def test_raises_503_when_not_set(self):
        dep = PluginDependency[str]("TestService")
        from fastapi import HTTPException

        with pytest.raises(HTTPException) as exc_info:
            dep()
        assert exc_info.value.status_code == 503
        assert "TestService" in exc_info.value.detail

    def test_returns_instance_after_set(self):
        dep = PluginDependency[str]("MyService")
        dep.set("hello")
        assert dep() == "hello"

    def test_reset_clears_instance(self):
        dep = PluginDependency[str]("MyService")
        dep.set("hello")
        dep.reset()
        from fastapi import HTTPException

        with pytest.raises(HTTPException):
            dep()

    def test_repr_empty(self):
        dep = PluginDependency[str]("Svc")
        assert "empty" in repr(dep)

    def test_repr_set(self):
        dep = PluginDependency[str]("Svc")
        dep.set("x")
        assert "set" in repr(dep)


# ---------------------------------------------------------------------------
# require_context
# ---------------------------------------------------------------------------


class TestRequireContext:
    def test_returns_context_when_set(self):
        ctx = MockContext()
        assert require_context(ctx) is ctx

    def test_raises_503_when_none(self):
        from fastapi import HTTPException

        with pytest.raises(HTTPException) as exc_info:
            require_context(None)
        assert exc_info.value.status_code == 503
        assert "standalone" in exc_info.value.detail.lower()


# ---------------------------------------------------------------------------
# create_standalone_app
# ---------------------------------------------------------------------------


class TestCreateStandaloneApp:
    def test_creates_fastapi_app_from_class(self):
        app = create_standalone_app(StubPlugin)
        from fastapi import FastAPI

        assert isinstance(app, FastAPI)

    def test_creates_fastapi_app_from_instance(self):
        plugin = StubPlugin()
        app = create_standalone_app(plugin)
        from fastapi import FastAPI

        assert isinstance(app, FastAPI)

    def test_app_title_includes_plugin_name(self):
        app = create_standalone_app(StubPlugin)
        assert "test-plugin" in app.title

    def test_custom_title(self):
        app = create_standalone_app(StubPlugin, title="Custom Title")
        assert app.title == "Custom Title"

    def test_cors_middleware_added_by_default(self):
        app = create_standalone_app(StubPlugin)
        middleware_classes = [type(m).__name__ for m in app.user_middleware]
        # CORSMiddleware wraps as Middleware object
        assert any("CORS" in str(m) for m in app.user_middleware) or len(app.user_middleware) > 0

    def test_cors_disabled(self):
        app = create_standalone_app(StubPlugin, cors=False)
        assert len(app.user_middleware) == 0


# ---------------------------------------------------------------------------
# get_frontend_dir (default implementation on AnalysisPlugin)
# ---------------------------------------------------------------------------


class TestGetFrontendDir:
    def test_returns_str_or_none(self):
        plugin = StubPlugin()
        result = plugin.get_frontend_dir()
        # Default implementation searches relative to the subclass module;
        # may find a frontend/dist dir in the monorepo during tests.
        assert result is None or isinstance(result, str)

    def test_returns_string_or_none(self):
        plugin = StubPlugin()
        result = plugin.get_frontend_dir()
        assert result is None or isinstance(result, str)
