from mint_sdk.migrations.errors import (
    DestructiveMigrationError,
    MigrationChecksumError,
    MigrationError,
    SchemaVersionAheadError,
)


class TestMigrationErrors:
    def test_base_error_is_exception(self):
        err = MigrationError("something broke")
        assert isinstance(err, Exception)
        assert str(err) == "something broke"

    def test_destructive_error_includes_operation(self):
        err = DestructiveMigrationError("drop_column", "users", "email")
        assert "drop_column" in str(err)
        assert "users" in str(err)
        assert err.operation == "drop_column"
        assert err.table == "users"
        assert err.target == "email"

    def test_checksum_error_includes_versions(self):
        err = MigrationChecksumError("my_plugin", 3, "abc123de", "def456ab")
        assert "my_plugin" in str(err)
        assert err.plugin_name == "my_plugin"
        assert err.version == 3
        assert err.expected == "abc123de"
        assert err.actual == "def456ab"

    def test_schema_version_ahead_error(self):
        err = SchemaVersionAheadError("MS Planner", db_version=5, plugin_max_version=3)
        assert "MS Planner" in str(err)
        assert err.db_version == 5
        assert err.plugin_max_version == 3

    def test_all_errors_inherit_from_migration_error(self):
        assert issubclass(DestructiveMigrationError, MigrationError)
        assert issubclass(MigrationChecksumError, MigrationError)
        assert issubclass(SchemaVersionAheadError, MigrationError)
