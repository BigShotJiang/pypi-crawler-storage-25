from __future__ import annotations

import pytest

from mint_sdk.migrations.base import PluginMigration


class GoodMigration(PluginMigration):
    version = 1
    name = "initial"
    depends_on = None

    async def upgrade(self, op):
        pass


class DestructiveMigration(PluginMigration):
    version = 2
    name = "drop_old_column"
    depends_on = 1
    destructive = True

    async def upgrade(self, op):
        pass

    async def downgrade(self, op):
        pass


class TestPluginMigration:
    def test_version_and_name(self):
        m = GoodMigration()
        assert m.version == 1
        assert m.name == "initial"

    def test_depends_on_default_none(self):
        m = GoodMigration()
        assert m.depends_on is None

    def test_destructive_default_false(self):
        m = GoodMigration()
        assert m.destructive is False

    def test_destructive_can_be_set(self):
        m = DestructiveMigration()
        assert m.destructive is True

    def test_downgrade_is_optional(self):
        m = GoodMigration()
        assert m.has_downgrade is False

    def test_downgrade_detected_when_defined(self):
        m = DestructiveMigration()
        assert m.has_downgrade is True

    def test_repr(self):
        m = GoodMigration()
        assert "v001" in repr(m)
        assert "initial" in repr(m)

    def test_missing_version_raises(self):
        with pytest.raises(TypeError):

            class Bad(PluginMigration):
                name = "oops"

                async def upgrade(self, op):
                    pass

            Bad()

    def test_missing_name_raises(self):
        with pytest.raises(TypeError):

            class Bad(PluginMigration):
                version = 1

                async def upgrade(self, op):
                    pass

            Bad()
