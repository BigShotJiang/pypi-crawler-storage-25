from __future__ import annotations

import pytest
from sqlalchemy.ext.asyncio import create_async_engine

from mint_sdk.migrations.locking import _plugin_lock_id, advisory_lock


class TestPluginLockId:
    def test_deterministic(self):
        assert _plugin_lock_id("MS Planner") == _plugin_lock_id("MS Planner")

    def test_different_plugins_get_different_ids(self):
        assert _plugin_lock_id("MS Planner") != _plugin_lock_id("MS Designer")


class TestSQLiteLock:
    @pytest.mark.asyncio
    async def test_lock_acquires_and_releases(self):
        engine = create_async_engine("sqlite+aiosqlite:///:memory:")
        async with advisory_lock(engine, "test_plugin", dialect="sqlite"):
            pass
        await engine.dispose()

    @pytest.mark.asyncio
    async def test_lock_yields_connection(self):
        engine = create_async_engine("sqlite+aiosqlite:///:memory:")
        async with advisory_lock(engine, "test_plugin", dialect="sqlite") as conn:
            assert conn is not None
        await engine.dispose()
