# plato-neural

> PLATO neural inference engine — tile scoring, Q&A, and knowledge gap detection.

A 494M Qwen2.5-0.5B model fine-tuned on PLATO tiles provides:
- **98% confidence** answers across all PLATO domains
- **Perplexity-based** tile quality scoring (91.5% recognition rate)
- **Knowledge gap** detection via high-perplexity tiles
- **Interactive Q&A** at 49-68 tokens/sec on consumer GPUs

## Install

```bash
pip install plato-neural
```

## Quick Start

```python
from plato_neural import PlatoBrain

brain = PlatoBrain("path/to/plato-model")

# Ask a question
result = brain.ask("What is constraint theory?")
print(result['answer'])         # Generated answer
print(result['confidence'])     # 0.0 - 1.0
print(result['perplexity'])     # Lower = more confident

# Score a tile
score = brain.score(
    question="What is CT?",
    answer="Pythagorean snapping for exact coordinates."
)
print(score['quality'])  # excellent, good, fair, weak, poor

# Generate a new tile
tile = brain.generate_tile("ct", topic="holonomy verification")

brain.free()  # Release GPU memory
```

## Tile Quality Scoring

```python
from plato_neural import PlatoScorer

scorer = PlatoScorer("path/to/plato-model")

# Score from PLATO API
scorer.score_room("ct", plato_api="http://147.224.38.131:8847")

# Score local file
scorer.score_file("tiles.json")

# Find knowledge gaps
gaps = scorer.find_gaps(tiles, threshold_ppl=100)
```

## Quality Tiers

| Perplexity | Quality   | Meaning |
|-----------|-----------|---------|
| < 10      | Excellent | Model predicts perfectly |
| < 30      | Good      | Model is confident |
| < 100     | Fair      | Model recognizes pattern |
| < 500     | Weak      | Model struggles |
| > 500     | Poor      | Likely garbage or novel |

## Model

The default model is a Qwen2.5-0.5B fine-tuned on 3,393 PLATO tiles from 76 domains.

- **Parameters**: 494M
- **Training**: Full fine-tune, 2000 steps, loss 3.41→0.09
- **VRAM**: 1.0GB loaded (bf16), ~8GB peak during training
- **Quantized**: INT4 = 203MB (fits Jetson Nano), INT8 = 872MB

## License

MIT
