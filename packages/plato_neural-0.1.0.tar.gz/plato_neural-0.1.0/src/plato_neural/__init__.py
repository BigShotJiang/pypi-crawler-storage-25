"""PLATO neural inference engine — tile scoring, Q&A, and knowledge gap detection."""

__version__ = "0.1.0"
__all__ = ["PlatoBrain", "PlatoScorer"]

from plato_neural.brain import PlatoBrain
from plato_neural.scorer import PlatoScorer
