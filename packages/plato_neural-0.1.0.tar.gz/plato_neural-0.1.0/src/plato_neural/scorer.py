"""PLATO Tile Scorer — batch scoring, gap detection, PLATO API integration."""

import json
import urllib.request
from typing import Optional

from plato_neural.brain import PlatoBrain


class PlatoScorer:
    """Batch tile quality scorer with PLATO API integration."""

    def __init__(self, model_path: str, plato_api: str = "http://147.224.38.131:8847"):
        """Initialize scorer.
        
        Args:
            model_path: Path to fine-tuned PLATO model.
            plato_api: PLATO server API URL.
        """
        self.brain = PlatoBrain(model_path)
        self.plato_api = plato_api.rstrip("/")

    def score_tile(self, question: str, answer: str,
                   content: str = "") -> dict:
        """Score a single tile. See PlatoBrain.score()."""
        return self.brain.score(question, answer, content)

    def score_tiles(self, tiles: list, batch_size: int = 16) -> list:
        """Score a list of tiles.
        
        Args:
            tiles: List of dicts with 'question' and 'answer' keys.
            batch_size: Number of tiles to process at once.
        
        Returns:
            List of scored tile dicts with 'perplexity', 'quality', etc.
        """
        results = []
        for i in range(0, len(tiles), batch_size):
            batch = tiles[i : i + batch_size]
            for tile in batch:
                q = tile.get("question", "")
                a = tile.get("answer", "")
                c = tile.get("content", "")
                score = self.score_tile(q, a, c)
                score["domain"] = tile.get("domain", "unknown")
                score["question"] = q[:100]
                results.append(score)

            if (i + batch_size) % 500 == 0:
                n = min(i + batch_size, len(tiles))
                avg = sum(r["perplexity"] for r in results[-500:]) / min(len(results), 500)
                print(f"  Scored {n}/{len(tiles)}, avg PPL: {avg:.1f}")

        return results

    def score_file(self, path: str) -> list:
        """Score tiles from a JSON file.
        
        Args:
            path: Path to JSON file containing a list of tile dicts.
        
        Returns:
            List of scored tile dicts.
        """
        with open(path) as f:
            tiles = json.load(f)
        return self.score_tiles(tiles)

    def score_room(self, room: str) -> list:
        """Fetch and score all tiles from a PLATO room.
        
        Args:
            room: PLATO room name.
        
        Returns:
            List of scored tile dicts.
        """
        url = f"{self.plato_api}/room/{room}"
        resp = urllib.request.urlopen(url, timeout=15)
        data = json.loads(resp.read())
        tiles = data.get("tiles", [])
        return self.score_tiles(tiles)

    def find_gaps(self, tiles: list, threshold_ppl: float = 100) -> list:
        """Find knowledge gaps — tiles with high perplexity.
        
        Args:
            tiles: List of tile dicts.
            threshold_ppl: Perplexity threshold for gap detection.
        
        Returns:
            List of tile dicts sorted by perplexity (highest first).
        """
        scored = self.score_tiles(tiles)
        gaps = [s for s in scored if s["perplexity"] > threshold_ppl]
        gaps.sort(key=lambda x: -x["perplexity"])
        return gaps

    def free(self):
        """Release GPU memory."""
        self.brain.free()
