"""PLATO Neural Brain — inference engine for Q&A and tile generation."""

import time
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer


class PlatoBrain:
    """Neural PLATO inference engine.
    
    Uses a fine-tuned Qwen2.5-0.5B model to answer questions from PLATO
    knowledge, generate tiles, and score quality via perplexity.
    """

    def __init__(self, model_path: str):
        """Load the PLATO neural model.
        
        Args:
            model_path: Path to fine-tuned model directory.
        """
        self.tokenizer = AutoTokenizer.from_pretrained(
            model_path, local_files_only=True, trust_remote_code=True
        )
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        self.model = AutoModelForCausalLM.from_pretrained(
            model_path,
            local_files_only=True,
            torch_dtype=torch.bfloat16,
            device_map="auto",
            trust_remote_code=True,
        )
        self.model.eval()
        self._params = sum(p.numel() for p in self.model.parameters())

    @property
    def params(self) -> int:
        """Total model parameters."""
        return self._params

    def ask(self, question: str, temperature: float = 0.7,
            max_tokens: int = 200) -> dict:
        """Ask the PLATO brain a question.
        
        Args:
            question: The question to ask.
            temperature: Sampling temperature (0.0 = deterministic).
            max_tokens: Maximum tokens to generate.
        
        Returns:
            Dict with 'answer', 'confidence' (0-1), 'perplexity',
            'tokens_per_second', and 'latency_ms'.
        """
        prompt = f"Q: {question}\nA:"
        inputs = self.tokenizer(
            prompt, return_tensors="pt", truncation=True, max_length=512
        )
        inputs = {k: v.to(self.model.device) for k, v in inputs.items()}

        t0 = time.time()
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=max_tokens,
                do_sample=True,
                temperature=temperature,
                top_p=0.9,
                pad_token_id=self.tokenizer.pad_token_id,
            )
        elapsed = time.time() - t0

        answer = self.tokenizer.decode(
            outputs[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True
        ).strip()

        # Self-consistency score
        ppl = self._perplexity(f"Q: {question}\nA: {answer}")
        confidence = max(0.0, min(1.0, 1.0 / (1.0 + 0.01 * ppl)))
        gen_tokens = outputs.shape[1] - inputs["input_ids"].shape[1]

        return {
            "answer": answer,
            "confidence": round(confidence, 3),
            "perplexity": round(ppl, 1),
            "tokens_per_second": round(gen_tokens / max(elapsed, 0.001), 1),
            "latency_ms": round(elapsed * 1000, 1),
        }

    def score(self, question: str, answer: str,
              content: str = "") -> dict:
        """Score a tile's quality via perplexity.
        
        Lower perplexity = model "knows" this content = higher quality.
        
        Args:
            question: Tile question.
            answer: Tile answer.
            content: Optional additional content.
        
        Returns:
            Dict with 'perplexity', 'loss', 'quality', and 'confidence'.
        """
        if content and len(content) > 30:
            text = f"{content}\n\nQ: {question}\nA: {answer}"
        else:
            text = f"Q: {question}\nA: {answer}"

        ppl = self._perplexity(text)
        loss = torch.log(torch.tensor(ppl)).item() if ppl > 0 else 0.0

        if ppl < 10:
            quality = "excellent"
        elif ppl < 30:
            quality = "good"
        elif ppl < 100:
            quality = "fair"
        elif ppl < 500:
            quality = "weak"
        else:
            quality = "poor"

        return {
            "perplexity": round(ppl, 1),
            "loss": round(loss, 4),
            "quality": quality,
            "confidence": round(max(0.0, min(1.0, 1.0 / (1.0 + 0.01 * ppl))), 3),
        }

    def generate_tile(self, domain: str, topic: str = "",
                      temperature: float = 0.8) -> dict:
        """Generate a new PLATO tile.
        
        Args:
            domain: Target PLATO domain.
            topic: Optional topic focus.
            temperature: Sampling temperature.
        
        Returns:
            Dict with tile fields (domain, content, question, answer, confidence).
        """
        if topic:
            question = (
                f"Generate a knowledge tile for the '{domain}' domain "
                f"about {topic}. Include a question and detailed answer."
            )
        else:
            question = (
                f"What is a fundamental concept in the '{domain}' domain "
                f"of the Cocapn fleet? Provide a detailed technical answer."
            )

        result = self.ask(question, temperature=temperature, max_tokens=300)

        return {
            "domain": domain,
            "content": result["answer"],
            "question": question,
            "answer": result["answer"],
            "confidence": result["confidence"],
            "source": "plato-neural-engine",
            "generated_perplexity": result["perplexity"],
        }

    def free(self):
        """Release model from GPU memory."""
        del self.model
        del self.tokenizer
        torch.cuda.empty_cache()

    def _perplexity(self, text: str) -> float:
        """Compute perplexity for text."""
        inputs = self.tokenizer(
            text, return_tensors="pt", truncation=True, max_length=512
        )
        inputs = {k: v.to(self.model.device) for k, v in inputs.items()}

        with torch.no_grad():
            outputs = self.model(**inputs, labels=inputs["input_ids"])
            loss = outputs.loss.item()

        return torch.exp(torch.tensor(loss)).item()
