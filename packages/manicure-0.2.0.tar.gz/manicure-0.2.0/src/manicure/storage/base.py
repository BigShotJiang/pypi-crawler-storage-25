"""Abstract storage backend and data models.

Storage backends persist exchange artifacts (raw bodies, IR models)
and the append-only index used by the dashboard.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from manicure.ir import InternalRequest, InternalResponse
from manicure.overrides import (
    OverrideAuditEntry as OverrideAuditEntry,
)  # explicit re-export

# ── Stats models ────────────────────────────────────────────────────


class ReqStats(BaseModel):
    model_config = ConfigDict(frozen=True)

    system_parts: int = 0
    system_chars: int = 0
    tools_count: int = 0
    tools_chars: int = 0
    messages_count: int = 0
    messages_chars: int = 0
    total_chars: int = 0


class PipelineStats(BaseModel):
    model_config = ConfigDict(frozen=True)

    overrides_applied: list[OverrideAuditEntry] = Field(default_factory=list)
    chars_before: int = 0
    chars_after: int = 0
    tokens_approx: int = 0


class ResStats(BaseModel):
    model_config = ConfigDict(frozen=True)

    stop_reason: str | None = None
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_input_tokens: int = 0
    text_chars: int = 0
    tool_calls: int = 0


# ── Index entry ─────────────────────────────────────────────────────


class IndexEntry(BaseModel):
    model_config = ConfigDict(frozen=True)

    id: str
    ts: datetime
    provider: str
    model: str
    path: str
    req: ReqStats
    pipeline: PipelineStats | None = None
    res: ResStats | None = None
    mutated_manually: bool = False


# ── Exchange artifacts ──────────────────────────────────────────────


class ExchangeArtifacts(BaseModel):
    """All artifacts for a single proxy exchange."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    request_raw: bytes
    request_ir: InternalRequest
    request_curated_ir: InternalRequest | None = None
    response_raw: bytes | None = None
    response_ir: InternalResponse | None = None


# ── Abstract backend ───────────────────────────────────────────────


class StorageBackend(ABC):
    @abstractmethod
    async def append_index(self, entry: IndexEntry) -> None: ...

    @abstractmethod
    async def write_exchange(
        self, exchange_id: str, artifacts: ExchangeArtifacts
    ) -> None: ...

    @abstractmethod
    async def read_index(self, limit: int, offset: int) -> list[IndexEntry]: ...

    @abstractmethod
    async def read_exchange(self, exchange_id: str) -> ExchangeArtifacts: ...

    @abstractmethod
    async def read_index_entry(self, exchange_id: str) -> IndexEntry | None: ...
