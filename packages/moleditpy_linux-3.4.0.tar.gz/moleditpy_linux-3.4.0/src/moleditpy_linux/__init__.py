#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
MoleditPy — A Python-based molecular editing software

Author: Hiromichi Yokoyama
License: GPL-3.0 license
Repo: https://github.com/HiroYokoyama/python_molecular_editor
DOI: 10.5281/zenodo.17268532
"""

"""Top-level package for moleditpy_linux."""

import importlib.util

try:
    OBABEL_AVAILABLE = False
except ImportError:
    OBABEL_AVAILABLE = False

from .utils.constants import VERSION as __version__  # noqa: F401
