"""SQL schema parser for kinrg.

Extracts database structure (tables, columns, foreign keys) from:
- Raw SQL files (.sql): CREATE TABLE, ALTER TABLE, CREATE INDEX
- Inline SQL strings in code files (Python, JS/TS, etc.)
- Migration files (Alembic, Flyway, Knex, Laravel patterns)

Produces NodeInfo (Table, Column) and EdgeInfo (HAS_COLUMN, FOREIGN_KEY,
QUERIES, MIGRATES) that integrate into the existing knowledge graph.
"""

from __future__ import annotations

import logging
import re
from dataclasses import field
from pathlib import Path
from typing import Optional

from .parser import EdgeInfo, NodeInfo

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Regex patterns for SQL DDL parsing
# ---------------------------------------------------------------------------

# Match CREATE TABLE (with optional IF NOT EXISTS, schema prefix, quotes)
_CREATE_TABLE_RE = re.compile(
    r"CREATE\s+(?:OR\s+REPLACE\s+)?(?:TEMP(?:ORARY)?\s+)?"
    r"TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?"
    r"(?:(?P<schema>[`\"\w]+)\.)?"
    r"(?P<table>[`\"\w]+)"
    r"\s*\((?P<body>.*?)\)\s*(?:;|$)",
    re.IGNORECASE | re.DOTALL,
)

# Match ALTER TABLE ... ADD/MODIFY/DROP COLUMN
_ALTER_TABLE_RE = re.compile(
    r"ALTER\s+TABLE\s+(?:IF\s+EXISTS\s+)?"
    r"(?:(?:[`\"\w]+)\.)?"
    r"(?P<table>[`\"\w]+)\s+"
    r"(?P<action>ADD|MODIFY|ALTER|DROP|RENAME|CHANGE)\s+"
    r"(?:COLUMN\s+)?(?P<column>[`\"\w]+)",
    re.IGNORECASE,
)

# Match CREATE INDEX
_CREATE_INDEX_RE = re.compile(
    r"CREATE\s+(?:UNIQUE\s+)?INDEX\s+(?:IF\s+NOT\s+EXISTS\s+)?"
    r"(?:[`\"\w]+)\s+ON\s+"
    r"(?:(?:[`\"\w]+)\.)?"
    r"(?P<table>[`\"\w]+)\s*"
    r"\((?P<columns>[^)]+)\)",
    re.IGNORECASE,
)

# Match individual column definitions inside CREATE TABLE body
# This regex is intentionally permissive: it matches column_name TYPE(...) rest
# Each part is already split by _split_column_defs, so no DOTALL needed.
_COLUMN_DEF_RE = re.compile(
    r"\s*(?P<name>[`\"\w]+)\s+"
    r"(?P<type>\w+(?:\s*\([^)]*\))?)"
    r"(?P<rest>.*)",
    re.IGNORECASE,
)

# Match FOREIGN KEY constraints (inline or standalone)
_FK_INLINE_RE = re.compile(
    r"REFERENCES\s+"
    r"(?:(?P<schema>[`\"\w]+)\.)?"
    r"(?P<ref_table>[`\"\w]+)\s*"
    r"\(\s*(?P<ref_column>[`\"\w]+)\s*\)",
    re.IGNORECASE,
)

# Match standalone FOREIGN KEY constraint
_FK_STANDALONE_RE = re.compile(
    r"(?:CONSTRAINT\s+[`\"\w]+\s+)?"
    r"FOREIGN\s+KEY\s*\(\s*(?P<column>[`\"\w]+)\s*\)\s+"
    r"REFERENCES\s+"
    r"(?:(?:[`\"\w]+)\.)?"
    r"(?P<ref_table>[`\"\w]+)\s*"
    r"\(\s*(?P<ref_column>[`\"\w]+)\s*\)",
    re.IGNORECASE,
)

# Match PRIMARY KEY constraint
_PK_RE = re.compile(
    r"PRIMARY\s+KEY",
    re.IGNORECASE,
)

# Match NOT NULL constraint
_NOT_NULL_RE = re.compile(
    r"NOT\s+NULL",
    re.IGNORECASE,
)

# Match DEFAULT value
_DEFAULT_RE = re.compile(
    r"DEFAULT\s+(?P<value>[^,\)]+)",
    re.IGNORECASE,
)

# Match UNIQUE constraint
_UNIQUE_RE = re.compile(
    r"\bUNIQUE\b",
    re.IGNORECASE,
)

# Match inline SQL strings in code (Python, JS/TS, etc.)
_INLINE_SQL_RE = re.compile(
    r"(?:"
    r'(?:"""(?P<triple>.*?)""")'  # Python triple-quoted
    r"|"
    r"(?:\"(?P<double>[^\"]*?)\")"  # Double-quoted
    r"|"
    r"(?:'(?P<single>[^']*?)')"  # Single-quoted
    r"|"
    r"(?:`(?P<backtick>[^`]*?)`)"  # JS template literal
    r")",
    re.DOTALL,
)

# SQL keywords that indicate a table reference in inline SQL
_SQL_TABLE_REF_RE = re.compile(
    r"(?:FROM|JOIN|INTO|UPDATE|INSERT\s+INTO|DELETE\s+FROM|"
    r"CREATE\s+(?:OR\s+REPLACE\s+)?(?:TABLE|VIEW)|"
    r"ALTER\s+TABLE|DROP\s+TABLE|TRUNCATE\s+TABLE)"
    r"\s+((?:`[^`]+`|\"[^\"]+\"|\w+)(?:\.(?:`[^`]+`|\"[^\"]+\"|\w+))*)",
    re.IGNORECASE,
)


def _clean_name(name: str) -> str:
    """Remove quotes/backticks from identifiers."""
    return name.strip("`\"'[] ")


def _line_number_at(source: str, pos: int) -> int:
    """Get 1-based line number at character position."""
    return source[:pos].count("\n") + 1


# ---------------------------------------------------------------------------
# Main SQL file parser
# ---------------------------------------------------------------------------


def parse_sql_file(
    path: Path,
    source: bytes,
) -> tuple[list[NodeInfo], list[EdgeInfo]]:
    """Parse a .sql file and extract Table, Column nodes and relationship edges.

    Returns:
        Tuple of (nodes, edges) extracted from the SQL file.
    """
    text = source.decode("utf-8", errors="replace")
    file_path_str = str(path)
    nodes: list[NodeInfo] = []
    edges: list[EdgeInfo] = []

    # File node
    nodes.append(NodeInfo(
        kind="File",
        name=file_path_str,
        file_path=file_path_str,
        line_start=1,
        line_end=text.count("\n") + 1,
        language="sql",
        is_test=False,
    ))

    # Parse CREATE TABLE statements
    for match in _CREATE_TABLE_RE.finditer(text):
        schema_name = _clean_name(match.group("schema")) if match.group("schema") else None
        table_name = _clean_name(match.group("table"))
        body = match.group("body")
        line = _line_number_at(text, match.start())

        qualified_table = f"{schema_name}.{table_name}" if schema_name else table_name

        # Create Table node
        table_node = NodeInfo(
            kind="Table",
            name=table_name,
            file_path=file_path_str,
            line_start=line,
            line_end=_line_number_at(text, match.end()),
            language="sql",
            parent_name=schema_name,
            extra={
                "schema": schema_name,
                "full_name": qualified_table,
            },
        )
        nodes.append(table_node)

        # CONTAINS edge: File → Table
        edges.append(EdgeInfo(
            kind="CONTAINS",
            source=file_path_str,
            target=f"{file_path_str}::{qualified_table}",
            file_path=file_path_str,
            line=line,
        ))

        # Parse columns from table body
        _parse_columns(
            body, table_name, qualified_table, file_path_str, line, nodes, edges,
        )

        # Parse standalone FOREIGN KEY constraints
        for fk_match in _FK_STANDALONE_RE.finditer(body):
            col_name = _clean_name(fk_match.group("column"))
            ref_table = _clean_name(fk_match.group("ref_table"))
            ref_column = _clean_name(fk_match.group("ref_column"))

            edges.append(EdgeInfo(
                kind="FOREIGN_KEY",
                source=f"{file_path_str}::{qualified_table}.{col_name}",
                target=f"{ref_table}.{ref_column}",
                file_path=file_path_str,
                line=line,
                extra={
                    "from_table": qualified_table,
                    "from_column": col_name,
                    "to_table": ref_table,
                    "to_column": ref_column,
                },
            ))

    # Parse ALTER TABLE statements
    for match in _ALTER_TABLE_RE.finditer(text):
        table_name = _clean_name(match.group("table"))
        action = match.group("action").upper()
        column_name = _clean_name(match.group("column"))
        line = _line_number_at(text, match.start())

        edges.append(EdgeInfo(
            kind="MIGRATES",
            source=file_path_str,
            target=f"{table_name}",
            file_path=file_path_str,
            line=line,
            extra={
                "action": action,
                "column": column_name,
                "table": table_name,
            },
        ))

    # Parse CREATE INDEX statements
    for match in _CREATE_INDEX_RE.finditer(text):
        table_name = _clean_name(match.group("table"))
        columns = match.group("columns")
        line = _line_number_at(text, match.start())

        edges.append(EdgeInfo(
            kind="REFERENCES",
            source=file_path_str,
            target=f"{table_name}",
            file_path=file_path_str,
            line=line,
            extra={
                "type": "index",
                "columns": [_clean_name(c) for c in columns.split(",")],
                "table": table_name,
            },
        ))

    return nodes, edges


def _parse_columns(
    body: str,
    table_name: str,
    qualified_table: str,
    file_path_str: str,
    base_line: int,
    nodes: list[NodeInfo],
    edges: list[EdgeInfo],
) -> None:
    """Parse column definitions from CREATE TABLE body."""
    # Split body by commas (but not commas inside parentheses)
    parts = _split_column_defs(body)

    for part in parts:
        # Collapse all whitespace (newlines, tabs) into single spaces
        part = " ".join(part.split())
        if not part:
            continue

        # Skip constraint-only lines (PRIMARY KEY, UNIQUE, CHECK, FOREIGN KEY, INDEX, KEY)
        upper_part = part.strip().upper()
        if upper_part.startswith(("PRIMARY KEY", "UNIQUE", "CHECK", "CONSTRAINT",
                                  "FOREIGN KEY", "INDEX", "KEY")):
            continue

        col_match = _COLUMN_DEF_RE.match(part)
        if not col_match:
            continue

        col_name = _clean_name(col_match.group("name"))
        col_type = col_match.group("type").strip()
        rest = col_match.group("rest") if col_match.group("rest") else ""

        # Skip SQL keywords that aren't column names
        if col_name.upper() in ("PRIMARY", "UNIQUE", "CHECK", "CONSTRAINT",
                                "FOREIGN", "INDEX", "KEY"):
            continue

        # Extract column metadata
        is_pk = bool(_PK_RE.search(rest))
        is_not_null = bool(_NOT_NULL_RE.search(rest))
        is_unique = bool(_UNIQUE_RE.search(rest))
        default_match = _DEFAULT_RE.search(rest)
        default_val = default_match.group("value").strip() if default_match else None

        extra: dict = {
            "column_type": col_type,
            "table": qualified_table,
        }
        if is_pk:
            extra["primary_key"] = True
        if is_not_null:
            extra["not_null"] = True
        if is_unique:
            extra["unique"] = True
        if default_val:
            extra["default"] = default_val

        # Column node
        column_node = NodeInfo(
            kind="Column",
            name=col_name,
            file_path=file_path_str,
            line_start=base_line,
            line_end=base_line,
            language="sql",
            parent_name=qualified_table,
            params=col_type,
            extra=extra,
        )
        nodes.append(column_node)

        # HAS_COLUMN edge: Table → Column
        edges.append(EdgeInfo(
            kind="HAS_COLUMN",
            source=f"{file_path_str}::{qualified_table}",
            target=f"{file_path_str}::{qualified_table}.{col_name}",
            file_path=file_path_str,
            line=base_line,
        ))

        # Check for inline REFERENCES (foreign key)
        fk_match = _FK_INLINE_RE.search(rest)
        if fk_match:
            ref_table = _clean_name(fk_match.group("ref_table"))
            ref_column = _clean_name(fk_match.group("ref_column"))

            edges.append(EdgeInfo(
                kind="FOREIGN_KEY",
                source=f"{file_path_str}::{qualified_table}.{col_name}",
                target=f"{ref_table}.{ref_column}",
                file_path=file_path_str,
                line=base_line,
                extra={
                    "from_table": qualified_table,
                    "from_column": col_name,
                    "to_table": ref_table,
                    "to_column": ref_column,
                },
            ))


def _split_column_defs(body: str) -> list[str]:
    """Split CREATE TABLE body by commas, respecting parenthesized expressions."""
    parts: list[str] = []
    depth = 0
    current: list[str] = []

    for char in body:
        if char == "(":
            depth += 1
            current.append(char)
        elif char == ")":
            depth -= 1
            current.append(char)
        elif char == "," and depth == 0:
            parts.append("".join(current))
            current = []
        else:
            current.append(char)

    if current:
        parts.append("".join(current))

    return parts


# ---------------------------------------------------------------------------
# Inline SQL detection (for code files)
# ---------------------------------------------------------------------------


def extract_inline_sql_tables(
    source: str,
    file_path: str,
) -> list[EdgeInfo]:
    """Extract table references from inline SQL strings in code files.

    Scans string literals for SQL keywords (SELECT FROM, INSERT INTO, etc.)
    and creates QUERIES edges from the file to the referenced tables.

    Returns:
        List of EdgeInfo with kind='QUERIES'.
    """
    edges: list[EdgeInfo] = []
    seen_tables: set[str] = set()

    for str_match in _INLINE_SQL_RE.finditer(source):
        # Get the SQL content from whichever group matched
        sql_content = (
            str_match.group("triple")
            or str_match.group("double")
            or str_match.group("single")
            or str_match.group("backtick")
            or ""
        )

        if not sql_content:
            continue

        # Check if this string looks like SQL (has SQL keywords)
        upper_content = sql_content.upper()
        sql_keywords = ("SELECT", "INSERT", "UPDATE", "DELETE", "CREATE TABLE",
                        "ALTER TABLE", "DROP TABLE", "JOIN", "FROM")
        if not any(kw in upper_content for kw in sql_keywords):
            continue

        line = _line_number_at(source, str_match.start())

        # Extract table references
        for table_match in _SQL_TABLE_REF_RE.finditer(sql_content):
            table_name = _clean_name(table_match.group(1))

            # Skip common false positives
            if table_name.upper() in ("DUAL", "INFORMATION_SCHEMA",
                                       "PG_CATALOG", "SYS"):
                continue
            # Skip string interpolation patterns
            if table_name.startswith(("$", "{", "%")):
                continue

            # Deduplicate per file
            key = f"{file_path}::{table_name}"
            if key in seen_tables:
                continue
            seen_tables.add(key)

            edges.append(EdgeInfo(
                kind="QUERIES",
                source=file_path,
                target=table_name,
                file_path=file_path,
                line=line,
                extra={"table": table_name},
            ))

    return edges
