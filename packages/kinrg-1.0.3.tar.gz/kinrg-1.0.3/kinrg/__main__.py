"""Allow running as: python -m kinrg"""
from .cli import main

main()
