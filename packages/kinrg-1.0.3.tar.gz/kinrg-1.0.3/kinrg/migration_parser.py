"""Database migration file parser for kinrg.

Detects and parses migration files from common frameworks:
- TypeORM (.ts files with up(queryRunner) MigrationInterface)
- Alembic (versions/*.py with op.create_table / op.add_column)
- Django (migrations/*.py with migrations.Migration class)
- ActiveRecord/Rails (db/migrate/*.rb with create_table blocks)
- Raw SQL (.sql files in migration directories)

Produces NodeInfo (Migration, Table, Column) and EdgeInfo
(MIGRATES, HAS_COLUMN, FOREIGN_KEY) integrated into the knowledge graph.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path

from .parser import EdgeInfo, NodeInfo

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Type normalisation map
# ---------------------------------------------------------------------------

_NORMALIZE: dict[str, str] = {
    # SQLAlchemy / Alembic Python types
    "Integer": "INTEGER", "BigInteger": "BIGINT", "SmallInteger": "SMALLINT",
    "String": "VARCHAR", "Text": "TEXT", "Unicode": "VARCHAR",
    "UnicodeText": "TEXT", "Boolean": "BOOLEAN", "Float": "FLOAT",
    "Numeric": "DECIMAL", "DateTime": "TIMESTAMP", "Date": "DATE",
    "Time": "TIME", "LargeBinary": "BLOB", "JSON": "JSON", "UUID": "UUID",
    "ARRAY": "ARRAY", "Enum": "VARCHAR",
    # Django ORM field types
    "IntegerField": "INTEGER", "BigIntegerField": "BIGINT",
    "SmallIntegerField": "SMALLINT", "AutoField": "INTEGER",
    "BigAutoField": "BIGINT", "PositiveIntegerField": "INTEGER",
    "PositiveSmallIntegerField": "SMALLINT",
    "CharField": "VARCHAR", "TextField": "TEXT", "SlugField": "VARCHAR",
    "EmailField": "VARCHAR", "URLField": "VARCHAR", "UUIDField": "UUID",
    "IPAddressField": "VARCHAR", "GenericIPAddressField": "VARCHAR",
    "BooleanField": "BOOLEAN", "NullBooleanField": "BOOLEAN",
    "FloatField": "FLOAT", "DecimalField": "DECIMAL",
    "DateTimeField": "TIMESTAMP", "DateField": "DATE", "TimeField": "TIME",
    "DurationField": "BIGINT", "JSONField": "JSON", "BinaryField": "BLOB",
    "FileField": "VARCHAR", "ImageField": "VARCHAR",
    "ForeignKey": "INTEGER", "OneToOneField": "INTEGER",
    "ManyToManyField": "INTEGER",
    # TypeORM / TypeScript types
    "number": "INTEGER", "string": "VARCHAR", "boolean": "BOOLEAN",
    "Date": "TIMESTAMP", "Buffer": "BLOB", "object": "JSON",
    # Rails column types
    "integer": "INTEGER", "bigint": "BIGINT", "string": "VARCHAR",
    "text": "TEXT", "boolean": "BOOLEAN", "float": "FLOAT",
    "decimal": "DECIMAL", "datetime": "TIMESTAMP", "date": "DATE",
    "time": "TIME", "binary": "BLOB", "json": "JSON", "jsonb": "JSON",
    "uuid": "UUID", "references": "INTEGER",
    # Raw SQL aliases
    "INT": "INTEGER", "INT4": "INTEGER", "INT8": "BIGINT",
    "INT2": "SMALLINT", "SERIAL": "INTEGER", "BIGSERIAL": "BIGINT",
    "SMALLSERIAL": "SMALLINT",
    "VARCHAR": "VARCHAR", "NVARCHAR": "VARCHAR",
    "CHARACTER VARYING": "VARCHAR", "CHAR": "CHAR", "NCHAR": "CHAR",
    "BOOL": "BOOLEAN", "TINYINT": "SMALLINT",
    "DOUBLE": "FLOAT", "DOUBLE PRECISION": "FLOAT", "REAL": "FLOAT",
    "NUMERIC": "DECIMAL", "MONEY": "DECIMAL",
    "DATETIME": "TIMESTAMP", "TIMESTAMP": "TIMESTAMP",
    "BYTEA": "BLOB", "LONGBLOB": "BLOB", "MEDIUMBLOB": "BLOB",
    "LONGTEXT": "TEXT", "MEDIUMTEXT": "TEXT", "TINYTEXT": "TEXT",
    "JSONB": "JSON",
}


def normalize_type(raw: str) -> str:
    """Normalise a raw framework-specific type to a standard SQL type."""
    clean = raw.strip().rstrip("?").rstrip("[]")
    if clean in _NORMALIZE:
        return _NORMALIZE[clean]
    upper = clean.upper()
    if upper in _NORMALIZE:
        return _NORMALIZE[upper]
    base = re.sub(r"\s*\([^)]*\)", "", clean).strip()
    if base in _NORMALIZE:
        return _NORMALIZE[base]
    if base.upper() in _NORMALIZE:
        return _NORMALIZE[base.upper()]
    return upper or "TEXT"


# ---------------------------------------------------------------------------
# Migration file detection
# ---------------------------------------------------------------------------

_MIGRATION_PATH_RE = re.compile(
    r"(?:^|/)(?:migrations?|db/migrate|alembic/versions|"
    r"database/migrations|src/migrations)/",
    re.IGNORECASE,
)


def is_migration_file(file_path: str) -> bool:
    """Return True if the file path looks like a migration file."""
    norm = file_path.replace("\\", "/")
    return bool(_MIGRATION_PATH_RE.search(norm))


# ---------------------------------------------------------------------------
# Regex patterns per framework
# ---------------------------------------------------------------------------

# TypeORM
_TS_CLASS_RE = re.compile(r"export\s+class\s+(?P<name>\w+)", re.MULTILINE)
_TS_IMPLEMENTS_RE = re.compile(r"implements\s+MigrationInterface")
_TS_CREATE_TABLE_RE = re.compile(
    r'createTable\s*\(\s*new\s+Table\s*\(\s*\{[^}]*?name\s*:\s*["\'](?P<table>[^"\']+)["\']',
    re.DOTALL,
)
_TS_COL_BLOCK_RE = re.compile(
    r'\{\s*name\s*:\s*["\'](?P<cname>[^"\']+)["\'][^}]*?'
    r'type\s*:\s*["\'](?P<ctype>[^"\']+)["\'](?P<rest>[^}]*)\}',
    re.DOTALL,
)

# Alembic
_ALM_REVISION_RE = re.compile(r"revision\s*=\s*['\"](?P<rev>[^'\"]+)['\"]")
_ALM_CREATE_RE = re.compile(
    r"op\.create_table\s*\(\s*['\"](?P<table>[^'\"]+)['\"]", re.MULTILINE
)
_ALM_COL_RE = re.compile(
    r"sa\.Column\s*\(\s*['\"](?P<name>[^'\"]+)['\"],\s*sa\.(?P<type>\w+)",
    re.MULTILINE,
)
_ALM_FK_RE = re.compile(
    r"sa\.ForeignKeyConstraint\s*\(\s*\[(?P<cols>[^\]]+)\]\s*,\s*\[(?P<refs>[^\]]+)\]",
    re.MULTILINE,
)
_ALM_ADD_COL_RE = re.compile(
    r"op\.add_column\s*\(\s*['\"](?P<table>[^'\"]+)['\"].*?"
    r"sa\.Column\s*\(\s*['\"](?P<name>[^'\"]+)['\"],\s*sa\.(?P<type>\w+)",
    re.DOTALL,
)

# Django
_DJ_CLASS_RE = re.compile(
    r"class\s+Migration\s*\(\s*migrations\.Migration\s*\)"
)
_DJ_CREATE_RE = re.compile(
    r"migrations\.CreateModel\s*\(\s*name\s*=\s*['\"](?P<name>[^'\"]+)['\"]",
    re.MULTILINE,
)
_DJ_FIELD_RE = re.compile(
    r"\(\s*['\"](?P<fname>[^'\"]+)['\"],\s*models\.(?P<ftype>\w+(?:Field|Key))\(",
    re.MULTILINE,
)
_DJ_ADD_FIELD_RE = re.compile(
    r"migrations\.AddField\s*\(\s*model_name\s*=\s*['\"](?P<model>[^'\"]+)['\"].*?"
    r"field\s*=\s*models\.(?P<ftype>\w+)",
    re.DOTALL,
)

# Rails
_RB_CREATE_RE = re.compile(r"create_table\s+:(?P<table>\w+)", re.MULTILINE)
_RB_COL_RE = re.compile(r"t\.(?P<type>\w+)\s+:(?P<name>\w+)", re.MULTILINE)
_RB_ADD_COL_RE = re.compile(
    r"add_column\s+:(?P<table>\w+)\s*,\s*:(?P<name>\w+)\s*,\s*:(?P<type>\w+)",
    re.MULTILINE,
)
_RB_REF_RE = re.compile(
    r"add_reference\s+:(?P<table>\w+)\s*,\s*:(?P<ref>\w+)", re.MULTILINE
)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def parse_migration_file(
    file_path: str,
    content: bytes,
    language: str,
) -> tuple[list[NodeInfo], list[EdgeInfo]]:
    """Parse a migration file and return DB nodes + edges.

    Returns empty lists if the file format is unrecognised.
    """
    nodes: list[NodeInfo] = []
    edges: list[EdgeInfo] = []
    text = content.decode("utf-8", "replace")

    if language in ("typescript", "javascript") and (
        "MigrationInterface" in text or "queryRunner" in text
    ):
        _parse_typeorm(file_path, text, nodes, edges)
    elif language == "python" and "op.create_table" in text:
        _parse_alembic(file_path, text, nodes, edges)
    elif language == "python" and "migrations.Migration" in text:
        _parse_django(file_path, text, nodes, edges)
    elif language == "ruby" and (
        "create_table" in text or "add_column" in text
    ):
        _parse_rails(file_path, text, nodes, edges)
    elif file_path.lower().endswith(".sql"):
        _parse_sql(file_path, text, nodes, edges)

    return nodes, edges


# ---------------------------------------------------------------------------
# Qualified-name helpers (must match GraphStore._make_qualified logic)
# ---------------------------------------------------------------------------
# Table:  file_path="db", name=table  → qn = "db::{table}"
# Column: file_path="db", parent_name=table, name=col → qn = "db::{table}.{col}"
# Migration: file_path=fp, name=mig_name → qn = "{fp}::{mig_name}"


def _mig_qn(fp: str, name: str) -> str:
    return f"{fp}::{name}"


def _table_qn(table: str) -> str:
    return f"db::{table}"


def _col_qn(table: str, col: str) -> str:
    return f"db::{table}.{col}"


# ---------------------------------------------------------------------------
# Node / edge helpers
# ---------------------------------------------------------------------------


def _mig_node(file_path: str, name: str) -> NodeInfo:
    return NodeInfo(
        kind="Migration",
        name=name,
        file_path=file_path,
        line_start=1,
        line_end=1,
        language="sql",
        extra={"migration_file": file_path},
    )


def _table_node(file_path: str, table: str, orm: str, mig: str) -> NodeInfo:
    # Use synthetic file_path="db" so qn = "db::{table}" (globally unique)
    return NodeInfo(
        kind="Table",
        name=table,
        file_path="db",
        line_start=1,
        line_end=1,
        language="sql",
        extra={"table": table, "orm": orm, "from_migration": mig,
               "source_file": file_path},
    )


def _col_node(
    file_path: str,
    table: str,
    col: str,
    col_type: str,
    pk: bool = False,
    nullable: bool = True,
) -> NodeInfo:
    # parent_name=table → qn = "db::{table}.{col}"
    return NodeInfo(
        kind="Column",
        name=col,
        file_path="db",
        line_start=1,
        line_end=1,
        language="sql",
        parent_name=table,
        extra={
            "table": table,
            "column_type": normalize_type(col_type),
            "raw_type": col_type,
            "primary_key": pk,
            "nullable": nullable,
        },
    )


def _col_edge(fp: str, table: str, col: str) -> EdgeInfo:
    return EdgeInfo(kind="HAS_COLUMN", source=_table_qn(table),
                    target=_col_qn(table, col), file_path=fp, line=1)


def _mig_edge(fp: str, mig_name: str, table: str) -> EdgeInfo:
    return EdgeInfo(kind="MIGRATES", source=_mig_qn(fp, mig_name),
                    target=_table_qn(table), file_path=fp, line=1)


# ---------------------------------------------------------------------------
# Framework parsers
# ---------------------------------------------------------------------------


def _parse_typeorm(fp: str, text: str, nodes: list, edges: list) -> None:
    m = _TS_CLASS_RE.search(text)
    mig_name = m.group("name") if m else Path(fp).stem
    nodes.append(_mig_node(fp, mig_name))

    for cm in _TS_CREATE_TABLE_RE.finditer(text):
        tname = cm.group("table")
        nodes.append(_table_node(fp, tname, "typeorm", mig_name))
        edges.append(_mig_edge(fp, mig_name, tname))

        block = text[cm.end(): cm.end() + 3000]
        for col_m in _TS_COL_BLOCK_RE.finditer(block):
            cname = col_m.group("cname")
            ctype = col_m.group("ctype")
            rest = col_m.group("rest")
            pk = "isPrimary" in rest and "true" in rest
            nullable = "isNullable" not in rest or "true" in rest
            nodes.append(_col_node(fp, tname, cname, ctype, pk, nullable))
            edges.append(_col_edge(fp, tname, cname))


def _parse_alembic(fp: str, text: str, nodes: list, edges: list) -> None:
    rev_m = _ALM_REVISION_RE.search(text)
    mig_name = rev_m.group("rev") if rev_m else Path(fp).stem
    nodes.append(_mig_node(fp, mig_name))

    for cm in _ALM_CREATE_RE.finditer(text):
        tname = cm.group("table")
        nodes.append(_table_node(fp, tname, "alembic", mig_name))
        edges.append(_mig_edge(fp, mig_name, tname))

        depth, start, end = 0, cm.start(), cm.start()
        for i, ch in enumerate(text[cm.start():], cm.start()):
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0:
                    end = i + 1
                    break
        block = text[start:end]

        for col_m in _ALM_COL_RE.finditer(block):
            cname = col_m.group("name")
            ctype = col_m.group("type")
            after = block[col_m.end(): col_m.end() + 120]
            nodes.append(_col_node(fp, tname, cname, ctype,
                                   "primary_key=True" in after,
                                   "nullable=False" not in after))
            edges.append(_col_edge(fp, tname, cname))

        for fk_m in _ALM_FK_RE.finditer(block):
            cols = [c.strip().strip("'\"") for c in fk_m.group("cols").split(",")]
            refs = [r.strip().strip("'\"") for r in fk_m.group("refs").split(",")]
            for col_n, ref in zip(cols, refs):
                ref_t = ref.split(".")[0] if "." in ref else ref
                edges.append(EdgeInfo(kind="FOREIGN_KEY", source=_col_qn(tname, col_n),
                                      target=_table_qn(ref_t), file_path=fp, line=1))

    for m in _ALM_ADD_COL_RE.finditer(text):
        tname, cname, ctype = m.group("table"), m.group("name"), m.group("type")
        nodes.append(_col_node(fp, tname, cname, ctype))
        edges.append(_col_edge(fp, tname, cname))


def _parse_django(fp: str, text: str, nodes: list, edges: list) -> None:
    if not _DJ_CLASS_RE.search(text):
        return

    mig_name = Path(fp).stem
    nodes.append(_mig_node(fp, mig_name))

    for cm in _DJ_CREATE_RE.finditer(text):
        tname = cm.group("name").lower()
        nodes.append(_table_node(fp, tname, "django", mig_name))
        edges.append(_mig_edge(fp, mig_name, tname))

        block = text[cm.end(): cm.end() + 4000]
        for fm in _DJ_FIELD_RE.finditer(block):
            fname, ftype = fm.group("fname"), fm.group("ftype")
            nodes.append(_col_node(fp, tname, fname, ftype,
                                   ftype in ("AutoField", "BigAutoField")))
            edges.append(_col_edge(fp, tname, fname))

    for m in _DJ_ADD_FIELD_RE.finditer(text):
        tname, ftype = m.group("model").lower(), m.group("ftype")
        fname = f"field_{ftype.lower()}"
        nodes.append(_col_node(fp, tname, fname, ftype))
        edges.append(_col_edge(fp, tname, fname))


def _parse_rails(fp: str, text: str, nodes: list, edges: list) -> None:
    mig_name = Path(fp).stem
    nodes.append(_mig_node(fp, mig_name))

    for cm in _RB_CREATE_RE.finditer(text):
        tname = cm.group("table")
        nodes.append(_table_node(fp, tname, "rails", mig_name))
        edges.append(_mig_edge(fp, mig_name, tname))

        block_start = cm.end()
        end_m = re.search(r"\bend\b", text[block_start: block_start + 3000])
        block = text[block_start: block_start + (end_m.start() if end_m else 3000)]

        for col_m in _RB_COL_RE.finditer(block):
            ctype, cname = col_m.group("type"), col_m.group("name")
            nodes.append(_col_node(fp, tname, cname, ctype,
                                   cname == "id" or ctype == "primary_key"))
            edges.append(_col_edge(fp, tname, cname))

    for m in _RB_ADD_COL_RE.finditer(text):
        tname, cname, ctype = m.group("table"), m.group("name"), m.group("type")
        nodes.append(_col_node(fp, tname, cname, ctype))
        edges.append(_col_edge(fp, tname, cname))

    for m in _RB_REF_RE.finditer(text):
        tname, ref = m.group("table"), m.group("ref")
        col_name = f"{ref}_id"
        nodes.append(_col_node(fp, tname, col_name, "INTEGER"))
        edges.append(_col_edge(fp, tname, col_name))
        edges.append(EdgeInfo(kind="FOREIGN_KEY", source=_col_qn(tname, col_name),
                              target=_table_qn(ref), file_path=fp, line=1))


def _parse_sql(
    fp: str, text: str, nodes: list, edges: list
) -> None:
    from .sql_schema import parse_sql_file
    from pathlib import Path as _Path
    sql_nodes, sql_edges = parse_sql_file(_Path(fp), text.encode())
    # Skip the File node (first node) since it's already added by parser.py
    nodes.extend(n for n in sql_nodes if n.kind != "File")
    edges.extend(sql_edges)
