import logging
import re
from typing import Optional

from .parser import EdgeInfo, NodeInfo

logger = logging.getLogger(__name__)

# Django Models
_DJANGO_CLASS_RE = re.compile(r"class\s+(?P<name>\w+)\s*\([^)]*models\.Model[^)]*\):")
_DJANGO_FIELD_RE = re.compile(r"(?P<name>\w+)\s*=\s*models\.(?P<type>\w+Field|ForeignKey|OneToOneField|ManyToManyField)\((?P<args>[^)]*)\)")

# SQLAlchemy Models
_SA_CLASS_RE = re.compile(r"class\s+(?P<name>\w+)\s*\([^)]*Base[^)]*\):.*?")
_SA_FIELD_RE = re.compile(r"(?P<name>\w+)\s*=\s*(?:Column|mapped_column)\s*\((?P<args>[^)]*)\)")

# TypeORM Entities
_TYPEORM_ENTITY_RE = re.compile(r"@Entity\([^)]*\)\s*(?:export\s+)?class\s+(?P<name>\w+)", re.MULTILINE)
_TYPEORM_FIELD_RE = re.compile(r"@(Column|PrimaryGeneratedColumn|ManyToOne|OneToMany|OneToOne|ManyToMany)(?:\([^@]*?\))?\s*(?:export\s*)?(?:public\s*)?(?:private\s*)?(?P<name>\w+)\s*:\s*(?P<type>[\w\[\]]+)")

def post_process_orms(
    nodes: list[NodeInfo], 
    edges: list[EdgeInfo], 
    file_content: bytes, 
    language: str, 
    file_path: str
) -> None:
    """Upgrade Class nodes to Table nodes if they are ORM models.
    
    Mutates `nodes` and `edges` lists in-place.
    """
    if language not in ("python", "javascript", "typescript", "tsx"):
        return

    text = file_content.decode("utf-8", "replace")
    
    if language == "python":
        _post_process_django(nodes, edges, text, file_path)
        _post_process_sqlalchemy(nodes, edges, text, file_path)
    elif language in ("javascript", "typescript", "tsx"):
        _post_process_typeorm(nodes, edges, text, file_path)


def _find_class_node(nodes: list[NodeInfo], name: str) -> Optional[NodeInfo]:
    for n in nodes:
        if n.kind == "Class" and n.name == name:
            return n
    return None

def _post_process_django(nodes: list[NodeInfo], edges: list[EdgeInfo], text: str, file_path: str) -> None:
    """Detect Django models."""
    if "models.Model" not in text:
        return

    for m in _DJANGO_CLASS_RE.finditer(text):
        class_name = m.group("name")
        cnode = _find_class_node(nodes, class_name)
        if not cnode:
            continue
            
        # Upgrade class to Table
        cnode.kind = "Table"
        cnode.extra["orm"] = "django"
        cnode.extra["table"] = class_name.lower()
        
        # Scan body for fields
        start_idx = m.end()
        # simplified: scan whole file but only care about matches between this class and next top-level
        # for a rigorous AST bounds check, we can use cnode.line_start / line_end
        
        body = _get_class_body(text, cnode.line_start, cnode.line_end)
        for fm in _DJANGO_FIELD_RE.finditer(body):
            fname = fm.group("name")
            ftype = fm.group("type")
            fargs = fm.group("args")
            
            # Create Column node
            cnode_qn = f"{file_path}::{cnode.name}"
            col_qn = f"{cnode_qn}.{fname}"
            col_extra = {"column_type": ftype, "table": cnode.name, "primary_key": "primary_key=True" in fargs}
            if "ForeignKey" in ftype:
                ref_match = re.search(r"['\"]?(\w+)['\"]?", fargs)
                if ref_match:
                    ref_table = ref_match.group(1)
                    edges.append(EdgeInfo(
                        kind="FOREIGN_KEY",
                        source=col_qn,
                        target=ref_table,
                        file_path=file_path,
                        line=cnode.line_start,
                        extra="{\"from_table\": \"%s\", \"from_column\": \"%s\", \"to_table\": \"%s\"}" 
                              % (cnode.name, fname, ref_table)
                    ))
            
            nodes.append(NodeInfo(
                name=fname,
                kind="Column",
                file_path=file_path,
                language="python",
                line_start=cnode.line_start,
                line_end=cnode.line_end,
                parent_name=cnode.name,
                extra=col_extra
            ))
            
            # HAS_COLUMN edge
            edges.append(EdgeInfo(
                kind="HAS_COLUMN",
                source=cnode_qn,
                target=col_qn,
                file_path=file_path,
                line=cnode.line_start
            ))

def _post_process_sqlalchemy(nodes: list[NodeInfo], edges: list[EdgeInfo], text: str, file_path: str) -> None:
    """Detect SQLAlchemy models."""
    if "Column(" not in text and "mapped_column(" not in text:
        return

    for m in _SA_CLASS_RE.finditer(text):
        class_name = m.group("name")
        cnode = _find_class_node(nodes, class_name)
        if not cnode:
            continue
            
        body = _get_class_body(text, cnode.line_start, cnode.line_end)
        
        table_name = class_name.lower()
        tb_match = re.search(r"__tablename__\s*=\s*['\"](\w+)['\"]", body)
        if tb_match:
            table_name = tb_match.group(1)
            
        cnode.kind = "Table"
        cnode.extra["orm"] = "sqlalchemy"
        cnode.extra["table"] = table_name
        for fm in _SA_FIELD_RE.finditer(body):
            fname = fm.group("name")
            fargs = fm.group("args")
            
            cnode_qn = f"{file_path}::{cnode.name}"
            col_qn = f"{cnode_qn}.{fname}"
            nodes.append(NodeInfo(
                name=fname,
                kind="Column",
                file_path=file_path,
                language="python",
                line_start=cnode.line_start,
                line_end=cnode.line_end,
                parent_name=table_name,
                extra={"table": table_name, "primary_key": "primary_key=True" in fargs}
            ))
            
            edges.append(EdgeInfo(
                kind="HAS_COLUMN",
                source=cnode_qn,
                target=col_qn,
                file_path=file_path,
                line=cnode.line_start
            ))
            
            # Detect Foreign Key
            fk_match = re.search(r"ForeignKey\(['\"]([^\"']+)['\"]", fargs)
            if fk_match:
                fk_target = fk_match.group(1) # e.g. users.id
                edges.append(EdgeInfo(
                    kind="FOREIGN_KEY",
                    source=col_qn,
                    target=fk_target.split(".")[0] if "." in fk_target else fk_target,
                    file_path=file_path,
                    line=cnode.line_start,
                    extra="{\"from_table\": \"%s\", \"from_column\": \"%s\"}" % (table_name, fname)
                ))

def _post_process_typeorm(nodes: list[NodeInfo], edges: list[EdgeInfo], text: str, file_path: str) -> None:
    """Detect TypeORM entities."""
    if "@Entity" not in text:
        return

    for m in _TYPEORM_ENTITY_RE.finditer(text):
        class_name = m.group("name")
        cnode = _find_class_node(nodes, class_name)
        if not cnode:
            continue
            
        cnode.kind = "Table"
        cnode.extra["orm"] = "typeorm"
        cnode.extra["table"] = class_name
        
        body = _get_class_body(text, cnode.line_start, cnode.line_end)
        for fm in _TYPEORM_FIELD_RE.finditer(body):
            decorator = fm.group(1)
            fname = fm.group("name")
            ftype = fm.group("type")
            
            cnode_qn = f"{file_path}::{cnode.name}"
            col_qn = f"{cnode_qn}.{fname}"
            nodes.append(NodeInfo(
                name=fname,
                kind="Column",
                file_path=file_path,
                language="typescript",
                line_start=cnode.line_start,
                line_end=cnode.line_end,
                parent_name=class_name,
                extra={"column_type": ftype, "table": class_name, "primary_key": decorator == "PrimaryGeneratedColumn"}
            ))
            
            edges.append(EdgeInfo(
                kind="HAS_COLUMN",
                source=cnode_qn,
                target=col_qn,
                file_path=file_path,
                line=cnode.line_start
            ))
            
            if decorator in ("ManyToOne", "OneToOne"):
                edges.append(EdgeInfo(
                    kind="FOREIGN_KEY",
                    source=col_qn,
                    target=ftype.replace("[]", ""),
                    file_path=file_path,
                    line=cnode.line_start,
                    extra="{\"from_table\": \"%s\", \"from_column\": \"%s\"}" % (class_name, fname)
                ))

def _get_class_body(text: str, line_start: Optional[int], line_end: Optional[int]) -> str:
    """Extract text lines between line_start and line_end (1-indexed)."""
    if not line_start or not line_end:
        return text
    lines = text.splitlines()
    start_idx = max(0, line_start - 1)
    end_idx = min(len(lines), line_end)
    return "\n".join(lines[start_idx:end_idx])
