"""MCP tools for database schema queries.

Provides tools to list tables, inspect table details, and analyze
database impact from code changes.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Optional

from ._common import _get_store

logger = logging.getLogger(__name__)


def list_tables(
    repo_root: Optional[str] = None,
    language: Optional[str] = None,
) -> dict[str, Any]:
    """List all database tables found in the codebase.

    Returns tables extracted from SQL files, Prisma schemas, ORM models, etc.

    Args:
        repo_root: Repository root path. Auto-detected if omitted.
        language: Optional filter by source language (sql, prisma, etc.).

    Returns:
        Dict with tables list, each containing name, columns, source file, etc.
    """
    store, _ = _get_store(repo_root)
    try:
        # Query all Table nodes
        conditions = ["kind = 'Table'"]
        params: list[str] = []
        if language:
            conditions.append("language = ?")
            params.append(language)

        where = " AND ".join(conditions)
        rows = store._conn.execute(
            f"SELECT * FROM nodes WHERE {where} ORDER BY name",  # nosec B608
            params,
        ).fetchall()

        tables = []
        for row in rows:
            extra = json.loads(row["extra"]) if row["extra"] else {}
            table_name = row["name"]

            # Get columns for this table
            col_rows = store._conn.execute(
                "SELECT * FROM nodes WHERE kind = 'Column' AND parent_name = ? "
                "AND file_path = ?",
                (extra.get("full_name", table_name), row["file_path"]),
            ).fetchall()

            # If no columns found with full_name, try just table_name
            if not col_rows:
                col_rows = store._conn.execute(
                    "SELECT * FROM nodes WHERE kind = 'Column' AND parent_name = ?",
                    (table_name,),
                ).fetchall()

            columns = []
            for col_row in col_rows:
                col_extra = json.loads(col_row["extra"]) if col_row["extra"] else {}
                columns.append({
                    "name": col_row["name"],
                    "type": col_extra.get("column_type", "unknown"),
                    "primary_key": col_extra.get("primary_key", False),
                    "not_null": col_extra.get("not_null", False),
                    "unique": col_extra.get("unique", False),
                    "default": col_extra.get("default"),
                })

            # Get foreign keys for this table
            fk_edges = store._conn.execute(
                "SELECT * FROM edges WHERE kind = 'FOREIGN_KEY' "
                "AND source_qualified LIKE ?",
                (f"%{table_name}%",),
            ).fetchall()

            foreign_keys = []
            for fk in fk_edges:
                fk_extra = json.loads(fk["extra"]) if fk["extra"] else {}
                foreign_keys.append({
                    "column": fk_extra.get("from_column", ""),
                    "references_table": fk_extra.get("to_table", ""),
                    "references_column": fk_extra.get("to_column", ""),
                })

            # Get code that queries this table
            query_edges = store._conn.execute(
                "SELECT * FROM edges WHERE kind = 'QUERIES' "
                "AND target_qualified = ?",
                (table_name,),
            ).fetchall()

            queried_by = [
                {"file": qe["file_path"], "line": qe["line"]}
                for qe in query_edges
            ]

            tables.append({
                "name": table_name,
                "schema": extra.get("schema"),
                "source_file": row["file_path"],
                "language": row["language"],
                "line_start": row["line_start"],
                "line_end": row["line_end"],
                "columns": columns,
                "column_count": len(columns),
                "foreign_keys": foreign_keys,
                "queried_by_count": len(queried_by),
                "orm": extra.get("orm"),
            })

        return {
            "total_tables": len(tables),
            "tables": tables,
        }
    finally:
        store.close()


def get_table(
    table_name: str,
    repo_root: Optional[str] = None,
    include_queries: bool = True,
) -> dict[str, Any]:
    """Get detailed information about a specific database table.

    Args:
        table_name: Name of the table to look up.
        repo_root: Repository root path. Auto-detected if omitted.
        include_queries: Include code files that query this table.

    Returns:
        Dict with table details including columns, foreign keys, and code references.
    """
    store, _ = _get_store(repo_root)
    try:
        # Find the table node
        rows = store._conn.execute(
            "SELECT * FROM nodes WHERE kind = 'Table' "
            "AND (name = ? OR name LIKE ?)",
            (table_name, f"%{table_name}%"),
        ).fetchall()

        if not rows:
            return {"error": f"Table '{table_name}' not found in the graph."}

        row = rows[0]
        extra = json.loads(row["extra"]) if row["extra"] else {}
        full_name = extra.get("full_name", row["name"])

        # Get all columns
        col_rows = store._conn.execute(
            "SELECT * FROM nodes WHERE kind = 'Column' "
            "AND (parent_name = ? OR parent_name = ?)",
            (row["name"], full_name),
        ).fetchall()

        columns = []
        for col_row in col_rows:
            col_extra = json.loads(col_row["extra"]) if col_row["extra"] else {}
            columns.append({
                "name": col_row["name"],
                "type": col_extra.get("column_type", "unknown"),
                "primary_key": col_extra.get("primary_key", False),
                "not_null": col_extra.get("not_null", False),
                "unique": col_extra.get("unique", False),
                "default": col_extra.get("default"),
                "has_default": col_extra.get("has_default", False),
            })

        # Get foreign keys (outgoing)
        fk_out = store._conn.execute(
            "SELECT * FROM edges WHERE kind = 'FOREIGN_KEY' "
            "AND source_qualified LIKE ?",
            (f"%{row['name']}%",),
        ).fetchall()

        # Get foreign keys (incoming - other tables referencing this one)
        fk_in = store._conn.execute(
            "SELECT * FROM edges WHERE kind = 'FOREIGN_KEY' "
            "AND target_qualified LIKE ?",
            (f"%{row['name']}%",),
        ).fetchall()

        foreign_keys_out = []
        for fk in fk_out:
            fk_extra = json.loads(fk["extra"]) if fk["extra"] else {}
            foreign_keys_out.append({
                "column": fk_extra.get("from_column"),
                "references_table": fk_extra.get("to_table"),
                "references_column": fk_extra.get("to_column"),
            })

        foreign_keys_in = []
        for fk in fk_in:
            fk_extra = json.loads(fk["extra"]) if fk["extra"] else {}
            foreign_keys_in.append({
                "from_table": fk_extra.get("from_table"),
                "from_column": fk_extra.get("from_column"),
                "column": fk_extra.get("to_column"),
            })

        result: dict[str, Any] = {
            "name": row["name"],
            "schema": extra.get("schema"),
            "full_name": full_name,
            "source_file": row["file_path"],
            "language": row["language"],
            "line_start": row["line_start"],
            "line_end": row["line_end"],
            "orm": extra.get("orm"),
            "columns": columns,
            "column_count": len(columns),
            "foreign_keys_out": foreign_keys_out,
            "foreign_keys_in": foreign_keys_in,
        }

        if include_queries:
            query_edges = store._conn.execute(
                "SELECT * FROM edges WHERE kind = 'QUERIES' "
                "AND target_qualified = ?",
                (row["name"],),
            ).fetchall()

            result["queried_by"] = [
                {
                    "file": qe["file_path"],
                    "line": qe["line"],
                    "extra": json.loads(qe["extra"]) if qe["extra"] else {},
                }
                for qe in query_edges
            ]
            result["queried_by_count"] = len(result["queried_by"])

        # Get migrations affecting this table
        migration_edges = store._conn.execute(
            "SELECT * FROM edges WHERE kind = 'MIGRATES' "
            "AND target_qualified = ?",
            (row["name"],),
        ).fetchall()

        result["migrations"] = [
            {
                "file": me["file_path"],
                "line": me["line"],
                "action": json.loads(me["extra"]).get("action") if me["extra"] else None,
                "column": json.loads(me["extra"]).get("column") if me["extra"] else None,
            }
            for me in migration_edges
        ]

        return result
    finally:
        store.close()
