# Kinrg IDE & AI Assistant Integration Guide

`kinrg` is designed to be completely agnostic and integrates via the **Model Context Protocol (MCP)**. This means any AI assistant or IDE that supports MCP can inherit the full power of `kinrg`'s codebase graph, semantic search, and blast-radius tracing.

Here is how to set up `kinrg` on various popular platforms.

---

## 0. Installation & Core Setup

Before configuring your IDE, you must install the `kinrg` CLI and build your project's Knowledge Graph.

### A. Install the CLI
Install globally via UV or Pip (supports specific versions):

```bash
# Install latest version from current directory
uv tool install .

# Or install specific version from pip (if published)
uv tool install kinrg@0.2.2

# Alternatively, using standard pip
pip install kinrg==0.2.2
```

### B. Core Actions
Navigate to your project folder and run these essential commands:

```bash
cd /path/to/your/project

# 1. Build the Graph Database
kinrg build

# 2. Watch for file changes (Auto-updates graph when you save)
kinrg watch

# 3. View the graph in your browser
kinrg visualize

# 4. Integrate rapidly with known IDEs
kinrg install
```

---

## 1. Visual Studio Code (Native via GitHub Copilot Chat)

Visual Studio Code officially supports MCP through the GitHub Copilot extension (requires Copilot Chat in your VSCode).

**Setup Steps:**
1. At the root of your project / workspace, create a `.vscode` folder if it doesn't already exist.
2. Inside `.vscode`, create a file named `mcp.json`.
3. Paste the following configuration:

```json
{
  "mcpServers": {
    "kinrg": {
      "command": "/Users/hotienky/.local/bin/kinrg",
      "args": [
        "serve"
      ]
    }
  }
}
```
> [!NOTE]
> Ensure the `command` points to the exact absolute path where `kinrg` was installed by `uv tool install .`. Using `uvx` often fails in UI-launched extensions because VS Code does not inherently inherit your full `$PATH`.

4. Restart VS Code or reload the window (`Cmd+Shift+P` -> `Developer: Reload Window`).

---

## 2. Cursor

Cursor has first-class MCP support and makes adding servers incredibly easy.

**Setup Steps:**
1. Open Cursor Settings (`Cmd + ,`).
2. Navigate to **Features** > **MCP Servers**.
3. Click **+ Add New MCP Server**.
4. Configure as follows:
   - **Name**: `kinrg`
   - **Type**: `command`
   - **Command**: `/Users/hotienky/.local/bin/kinrg serve`
5. Hit Save. Wait for the server to say "Connected" (green indicator).

---

## 3. Cline / Continue

If you prefer VSCode extensions like Cline or Continue, they both fully embrace MCP.

### For Cline:
1. Open the Cline panel.
2. Click the `</>` (MCP Servers) icon at the top of the interface.
3. Add `kinrg` directly in the UI, or manually edit the global configure file located at `~/Library/Application Support/Code/User/globalStorage/saoudrizwan.claude-dev/settings/cline_mcp_settings.json`:

```json
{
  "mcpServers": {
    "kinrg": {
      "command": "/Users/hotienky/.local/bin/kinrg",
      "args": ["serve"]
    }
  }
}
```

### For Continue:
Edit `~/.continue/config.json` and add `kinrg` to `mcpServers`.

---

## 4. Windsurf

Windsurf reads MCP global configurations natively under your user directory.

**Setup Steps:**
1. Open your global `~/.codeium/windsurf/mcp_config.json`.
2. Append the server configuration:

```json
{
  "mcpServers": {
    "kinrg": {
      "command": "/Users/hotienky/.local/bin/kinrg",
      "args": ["serve"]
    }
  }
}
```
3. Restart Windsurf.

---

## 5. Claude Desktop App

If you want to chat directly inside the Claude Desktop macOS App alongside your code.

**Setup Steps:**
1. Open Claude Desktop.
2. Click the Claude Menu -> **Settings...** 
3. Navigate to **Developer**, click **Edit Config** (this opens `~/Library/Application Support/Claude/claude_desktop_config.json`).
4. Add `kinrg`:

```json
{
  "mcpServers": {
    "kinrg": {
      "command": "/Users/hotienky/.local/bin/kinrg",
      "args": ["serve"]
    }
  }
}
```
5. Completely Quit (`Cmd+Q`) and restart Claude Desktop. Click the 🔨 hammer icon to see the available tools.

---

## 6. Antigravity

Antigravity is natively integrated by default through the `kinrg install` automatic setup.

If the server shows an Error indicator (Red Dot):
1. Click **Open MCP Config** in the Antigravity UI. (Ensure you open `~/.gemini/antigravity/mcp_config.json`, not a local `.vscode/mcp.json`).
2. Supply the absolute path exactly like the ones above.

---

## Troubleshooting: "Executable file not found in $PATH"

> [!WARNING]
> If any IDE throws a `executable file not found` error regarding `uvx` or `kinrg`, it means your GUI app environment wasn't launched with your bash/zsh `$PATH` variables.
> 
> **Solution:** Always use the absolute path. Find exactly where `kinrg` is installed (often `~/.local/bin/kinrg` or via `which kinrg`), and replace the shorthand `uvx` / `kinrg` command with the raw absolute path in your config.
