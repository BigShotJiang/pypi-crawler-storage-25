# Publisher Guide

This document explains how to publish the components of `kinrg` to global repositories so that any user worldwide can install them.

## 1. Publishing `kinrg` (Python CLI) to PyPI

By publishing to PyPI (Python Package Index), anyone can run `uv tool install kinrg` or `pip install kinrg`.

### Prerequisites
1. Create an account on [PyPI (pypi.org)](https://pypi.org/).
2. Navigate to your Account Settings -> API tokens, and generate a new token (Save it somewhere safe).

### Build & Publish Steps
1. Navigate to the root folder (where `pyproject.toml` is located):
   ```bash
   cd /path/to/kindy-review-graph
   ```
2. Build the package wheel and source distribution:
   ```bash
   # Using UV (Recommended)
   uv build
   
   # Or using standard python build
   pip install build && python3 -m build
   ```
   *This will generate a `dist/` folder containing your `.whl` and `.tar.gz` files.*
3. Publish to PyPI:
   ```bash
   # Using UV (Recommended)
   uv publish
   # It will prompt for your Token. For username leave it blank or use `__token__` per PyPI instructions.
   
   # Or using twine
   pip install twine
   twine upload dist/*
   ```

---

## 2. Publishing `kinrg-vscode` to the VS Code Marketplace

By publishing here, users can search "Kinrg" directly in the VSCode Extensions tab.

### Prerequisites
1. Create a [Microsoft Account](https://signup.live.com/).
2. Create a Publisher Profile at the [Visual Studio Marketplace Management portal](https://marketplace.visualstudio.com/manage).
3. Obtain a **Personal Access Token (PAT)**:
   - Go to [Azure DevOps](https://dev.azure.com/).
   - Click the User settings icon > Personal access tokens > New Token.
   - For Organization, select "All accessible organizations".
   - Under Scopes, select "Custom defined" and check **Marketplace** (Acquire, manage, publish).

### Build & Publish Steps
1. Navigate to the VSCode extension directory:
   ```bash
   cd /path/to/kindy-review-graph/kinrg-vscode
   ```
2. Update the `package.json`:
   - Ensure the `"publisher": "your-publisher-name"` field matches the exact profile name you created in the VS Marketplace.
   - Update the `"repository"` URL if needed.
3. Login using your PAT:
   ```bash
   npx vsce login <your-publisher-name>
   # Paste your Personal Access Token when prompted.
   ```
4. Publish the Extension:
   ```bash
   # Make sure your project compiles
   npm run compile
   
   # Ship it to the Microsoft servers!
   npx vsce publish
   ```
   *Note: It usually takes a few minutes for the status to change from "Verifying" to "Published" on the marketplace.*
