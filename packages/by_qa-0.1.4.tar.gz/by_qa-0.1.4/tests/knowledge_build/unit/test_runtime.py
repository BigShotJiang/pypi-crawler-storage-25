"""Tests for knowledge-build runtime wiring."""

from importlib.util import find_spec

from by_qa.config import Settings
from by_qa.knowledge_build.runtime import (
    build_document_chunking_service,
    validate_knowledge_build_settings,
)


def test_validate_knowledge_build_settings_only_requires_embedding_config():
    """Knowledge-build should require only embedding-related configuration."""
    settings = Settings(
        EMBEDDING_MODEL_NAME="bge-m3",
        EMBEDDING_BASE_URL="https://embedding.example.com",
        EMBEDDING_DIMENSION=1024,
    )

    validate_knowledge_build_settings(settings)


def test_build_document_chunking_service_uses_embedding_batch_max_texts_setting():
    """Runtime wiring should pass the embedding batch size limit into the service."""
    settings = Settings(
        EMBEDDING_MODEL_NAME="bge-m3",
        EMBEDDING_BASE_URL="https://embedding.example.com",
        EMBEDDING_DIMENSION=1024,
        EMBEDDING_BATCH_MAX_TEXTS=7,
    )

    service = build_document_chunking_service(settings)

    assert service.embedding_batch_max_texts == 7


def test_knowledge_build_no_longer_exposes_standalone_api_package():
    """Deprecated standalone knowledge-build API code should be removed."""
    assert find_spec("by_qa.knowledge_build.api") is None
