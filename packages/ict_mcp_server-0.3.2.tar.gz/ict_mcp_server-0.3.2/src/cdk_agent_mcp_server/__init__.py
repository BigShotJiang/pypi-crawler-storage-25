"""CDK Agent MCP Server — generate, validate, and deploy AWS CDK from natural language."""
