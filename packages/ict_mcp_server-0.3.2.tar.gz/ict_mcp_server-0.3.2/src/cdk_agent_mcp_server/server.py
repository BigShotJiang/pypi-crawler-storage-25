"""CDK Agent MCP Server — delegates to AWS MCP servers for validation, docs, and pricing.

- IaC MCP Server: cfn-lint, cfn-guard, troubleshooting (local tools, no Knowledge MCP dependency)
- Knowledge MCP: doc search (called directly, bypassing IaC MCP's broken parser)
- Pricing MCP: real AWS pricing data

Persistent sessions avoid re-spawning 88 packages per call.

Run via: uvx cdk-agent-mcp-server
"""

import json
import logging
import os
import subprocess
import tempfile
from pathlib import Path

import boto3
from mcp.server.fastmcp import FastMCP, Context
from mcp.client.stdio import stdio_client, StdioServerParameters
from mcp.client.streamable_http import streamablehttp_client
from mcp import ClientSession

logger = logging.getLogger(__name__)

mcp = FastMCP("cdk-agent")

REGION = os.environ.get("AWS_REGION", os.environ.get("AWS_DEFAULT_REGION", "us-east-1"))
KNOWLEDGE_MCP_URL = "https://knowledge-mcp.global.api.aws"

# --- Persistent MCP sessions (avoid re-spawning per call) ---

_iac_session_ctx = None
_iac_session = None
_pricing_session_ctx = None
_pricing_session = None


async def _get_iac_session() -> ClientSession:
    """Get or create a persistent IaC MCP Server session."""
    global _iac_session_ctx, _iac_session
    if _iac_session is not None:
        return _iac_session
    env = {**os.environ, "FASTMCP_LOG_LEVEL": "ERROR"}
    _iac_session_ctx = stdio_client(StdioServerParameters(
        command="uvx", args=["awslabs.aws-iac-mcp-server@latest"], env=env,
    ))
    read, write = await _iac_session_ctx.__aenter__()
    _iac_session = ClientSession(read, write)
    await _iac_session.__aenter__()
    await _iac_session.initialize()
    return _iac_session


async def _get_pricing_session() -> ClientSession:
    """Get or create a persistent Pricing MCP Server session."""
    global _pricing_session_ctx, _pricing_session
    if _pricing_session is not None:
        return _pricing_session
    env = {**os.environ, "FASTMCP_LOG_LEVEL": "ERROR", "AWS_REGION": REGION}
    _pricing_session_ctx = stdio_client(StdioServerParameters(
        command="uvx", args=["awslabs.aws-pricing-mcp-server@latest"], env=env,
    ))
    read, write = await _pricing_session_ctx.__aenter__()
    _pricing_session = ClientSession(read, write)
    await _pricing_session.__aenter__()
    await _pricing_session.initialize()
    return _pricing_session


async def _call_iac(tool_name: str, args: dict) -> str:
    """Call a tool on the persistent IaC MCP Server session."""
    session = await _get_iac_session()
    result = await session.call_tool(tool_name, args)
    texts = [c.text for c in result.content if hasattr(c, "text")]
    if result.isError:
        raise RuntimeError(f"IaC MCP {tool_name}: {' '.join(texts)}")
    return "\n".join(texts)


async def _call_pricing(tool_name: str, args: dict) -> str:
    """Call a tool on the persistent Pricing MCP Server session."""
    session = await _get_pricing_session()
    result = await session.call_tool(tool_name, args)
    texts = [c.text for c in result.content if hasattr(c, "text")]
    if result.isError:
        raise RuntimeError(f"Pricing MCP {tool_name}: {' '.join(texts)}")
    return "\n".join(texts)


async def _search_docs(query: str, k: int = 3) -> str:
    """Search AWS Knowledge MCP directly (bypasses IaC MCP's broken parser)."""
    try:
        async with streamablehttp_client(KNOWLEDGE_MCP_URL) as (read, write, _):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await session.call_tool("SearchDocumentation", {
                    "search_phrase": query, "max_results": k,
                })
                return "\n".join(c.text for c in result.content if hasattr(c, "text"))
    except Exception as e:
        logger.warning(f"Knowledge MCP search failed: {e}")
        return ""


# --- Helpers ---

def _bedrock(system: str, user: str, max_tokens: int = 8192) -> str:
    client = boto3.client("bedrock-runtime", region_name=REGION)
    r = client.converse(
        modelId="us.anthropic.claude-sonnet-4-20250514-v1:0",
        system=[{"text": system}],
        messages=[{"role": "user", "content": [{"text": user}]}],
        inferenceConfig={"maxTokens": max_tokens},
    )
    return r["output"]["message"]["content"][0]["text"]


def _extract(text: str, lang: str = "") -> str:
    if "```" not in text:
        return text.strip()
    tag = f"```{lang}" if lang else "```"
    if tag in text:
        return text.split(tag)[-1].split("```")[0].strip()
    return text.split("```")[1].split("```")[0].strip()


def _run_cdk_synth(code: str) -> dict:
    with tempfile.TemporaryDirectory(prefix="cdk-agent-") as d:
        Path(d, "lib").mkdir()
        Path(d, "lib", "stack.ts").write_text(code)
        Path(d, "bin").mkdir()
        Path(d, "bin", "app.ts").write_text(
            'import * as cdk from "aws-cdk-lib";\n'
            'const S = Object.values(require("../lib/stack")).find((v: any) => typeof v === "function") as any;\n'
            'const app = new cdk.App();\nnew S(app, "SynthStack");\n'
        )
        Path(d, "cdk.json").write_text('{"app":"npx ts-node bin/app.ts"}')
        Path(d, "tsconfig.json").write_text('{"compilerOptions":{"target":"ES2020","module":"commonjs","lib":["es2020"],"strict":true,"esModuleInterop":true,"outDir":"cdk.out"}}')
        Path(d, "package.json").write_text('{"dependencies":{"aws-cdk-lib":"^2","constructs":"^10","ts-node":"^10","typescript":"^5"}}')
        try:
            subprocess.run(["npm", "install", "--silent"], cwd=d, capture_output=True, timeout=120)
            r = subprocess.run(["npx", "cdk", "synth", "--no-staging", "--quiet"], cwd=d, capture_output=True, text=True, timeout=120)
            if r.returncode == 0:
                tmpl = Path(d, "cdk.out", "SynthStack.template.json")
                return {"success": True, "template": json.loads(tmpl.read_text()) if tmpl.exists() else None}
            return {"success": False, "error": (r.stderr or r.stdout)[:3000]}
        except Exception as e:
            return {"success": False, "error": str(e)}


# --- MCP Tools ---

@mcp.tool()
async def clarify_requirements(ctx: Context, description: str) -> str:
    """Analyze a request and return clarifying questions before designing architecture.

    WORKFLOW: This is Step 1. Call this FIRST when a user asks to build infrastructure.
    Present the returned questions to the user, collect their answers, then pass those
    answers as the 'requirements' parameter to design_architecture or full_pipeline.

    If the user's request is already detailed with clear constraints, you may skip this
    and call design_architecture directly.

    Args:
        description: What the user wants to build. Example: "I need a serverless API"
    """
    ctx.info("🤔 Analyzing requirements for clarification...")

    docs = await _search_docs(f"AWS architecture decisions {description}")

    questions = _bedrock(
        """You are an AWS solutions architect conducting requirements gathering.
Given the user's description, return a JSON object with:
- "understood": brief summary of what you understood
- "assumptions": list of assumptions you'd make if no clarification given
- "questions": list of objects with "id", "question", "options" (array of choices), "default" (recommended choice), "why" (why this matters for architecture/cost)
- "suggested_defaults": object mapping question id to recommended default option
- "follow_up_tool": "design_architecture" (tells the agent what to call next with the answers)
- "answer_format": "Pass all answers as a single string to the 'requirements' parameter of design_architecture or full_pipeline"

Focus on questions that materially affect architecture decisions:
- Scale/traffic expectations
- Authentication/authorization needs
- Data model and access patterns
- Compliance/regulatory requirements
- Cost sensitivity (optimize for cost vs performance)
- Region/availability requirements
- Existing infrastructure to integrate with

Limit to 3-6 high-impact questions. ONLY valid JSON.""",
        f"Description: {description}\n\nRelevant AWS patterns:\n{docs[:4000]}" if docs else f"Description: {description}",
        max_tokens=4096,
    )
    return _extract(questions, "json")


@mcp.tool()
async def design_architecture(ctx: Context, description: str, requirements: str = "") -> str:
    """Design an AWS architecture from natural language.

    Args:
        description: What you want to build. Example: "REST API with auth, DynamoDB users table, S3 uploads"
        requirements: Answers to clarifying questions or additional constraints (from clarify_requirements or user).
    """
    enriched = f"{description}\n\nRequirements/Constraints:\n{requirements}" if requirements else description
    ctx.info(f"📋 Designing: {enriched[:100]}")

    ctx.info("🔍 Searching AWS docs (Knowledge MCP)...")
    docs = await _search_docs(f"AWS CDK architecture patterns {enriched}")

    ctx.info("🧠 Generating architecture plan...")
    plan = _bedrock(
        "You are an AWS architect. Output a JSON plan with: name, description, nodes (id, service, config), edges (from, to, type). ONLY valid JSON.",
        f"Description: {enriched}\n\nAWS Documentation:\n{docs[:5000]}" if docs else f"Description: {enriched}",
        max_tokens=4096,
    )
    return _extract(plan, "json")


@mcp.tool()
async def confirm_plan(ctx: Context, architecture_plan: str) -> str:
    """Summarize an architecture plan for human/agent approval before generating code.

    WORKFLOW: This is the approval gate. Present the summary to the user and ask for
    confirmation. If approved, pass the plan to generate_cdk_stack. If the user wants
    changes, modify the plan and call confirm_plan again, or call design_architecture
    with updated requirements.

    Args:
        architecture_plan: JSON plan from design_architecture.
    """
    ctx.info("📋 Preparing plan summary for review...")

    try:
        plan = json.loads(architecture_plan)
    except json.JSONDecodeError:
        return json.dumps({"error": "Invalid JSON plan", "raw": architecture_plan})

    services = [n.get("service", "unknown") for n in plan.get("nodes", [])]
    summary = _bedrock(
        """Summarize this AWS architecture plan for a human reviewer. Include:
- **What it does**: 1-2 sentence description
- **Services used**: list with brief role of each
- **Data flow**: how requests/data move through the system
- **Complexity**: Low / Medium / High
- **Estimated cost tier**: Free-tier eligible / Low (<$50/mo) / Medium ($50-500/mo) / High (>$500/mo)
- **Security posture**: auth method, encryption, network isolation
- **Potential concerns**: anything the reviewer should consider

Be concise but thorough. Use markdown formatting.""",
        json.dumps(plan),
        max_tokens=4096,
    )

    return json.dumps({
        "summary": summary,
        "services": services,
        "node_count": len(plan.get("nodes", [])),
        "edge_count": len(plan.get("edges", [])),
        "plan": plan,
        "next_steps": "If approved, pass the plan to generate_cdk_stack. To modify, update the plan JSON and re-confirm.",
    })


@mcp.tool()
async def generate_cdk_stack(ctx: Context, architecture_plan: str) -> str:
    """Generate CDK TypeScript from an architecture plan.

    Args:
        architecture_plan: JSON plan from design_architecture, or natural language.
    """
    ctx.info("🏗️ Generating CDK code...")

    try:
        plan = json.loads(architecture_plan)
        services = list(set(n["service"] for n in plan.get("nodes", [])))
    except (json.JSONDecodeError, KeyError):
        services = []
        plan = architecture_plan

    # Search docs directly via Knowledge MCP (not IaC MCP's broken search)
    doc_parts = []
    for svc in services[:6]:
        ctx.info(f"🔍 CDK docs for {svc} (Knowledge MCP)...")
        docs = await _search_docs(f"AWS CDK {svc} L2 construct TypeScript")
        if docs:
            doc_parts.append(f"--- {svc} ---\n{docs[:3000]}")

    # Samples via IaC MCP (search_cdk_samples_and_constructs is local, doesn't use Knowledge MCP)
    if services:
        ctx.info("🔍 CDK samples (IaC MCP)...")
        try:
            samples = await _call_iac("search_cdk_samples_and_constructs", {
                "query": " ".join(services[:4]), "language": "typescript",
            })
            doc_parts.append(f"--- samples ---\n{samples[:3000]}")
        except Exception as e:
            ctx.warning(f"   ⚠️ Samples: {e}")

    ctx.info("🧠 Generating CDK TypeScript...")
    code = _bedrock(
        """Generate a complete CDK TypeScript stack. Rules:
- aws-cdk-lib L2 constructs only
- IAM via grant* methods
- Resource refs via Lambda env vars
- RemovalPolicy.DESTROY
- All imports + export Stack class
- ONLY TypeScript code.""",
        f"Plan:\n{json.dumps(plan, indent=2) if isinstance(plan, dict) else plan}\n\nCDK Docs:\n{''.join(doc_parts)}",
    )
    code = _extract(code, "typescript")
    ctx.info(f"✅ Generated {len(code.splitlines())} lines")
    return code


@mcp.tool()
async def validate_and_repair(ctx: Context, cdk_code: str, max_attempts: int = 3) -> str:
    """Validate CDK with real cdk synth + cfn-lint (IaC MCP) + cfn-guard (IaC MCP), auto-repair.

    Args:
        cdk_code: CDK TypeScript stack code.
        max_attempts: Max repair iterations (default 3).
    """
    current = cdk_code

    for attempt in range(1, max_attempts + 1):
        ctx.info(f"🔍 Validation attempt {attempt}/{max_attempts}")

        ctx.info("🔄 Running cdk synth...")
        synth = _run_cdk_synth(current)
        if not synth["success"]:
            ctx.warning(f"⚠️ cdk synth failed: {synth['error'][:200]}")
            if attempt < max_attempts:
                ctx.info("🔧 Repairing...")
                current = _extract(_bedrock(
                    "Fix this CDK TypeScript to pass cdk synth. ONLY corrected TypeScript.",
                    f"Code:\n```typescript\n{current}\n```\n\nError:\n{synth['error']}",
                ), "typescript")
                continue
            return json.dumps({"status": "FAILED", "error": synth["error"], "cdk_code": current})

        ctx.info("✅ cdk synth passed")
        template_str = json.dumps(synth.get("template", {}))

        # cfn-lint via IaC MCP (local, no Knowledge MCP)
        ctx.info("🔎 Running cfn-lint (IaC MCP)...")
        lint_result = ""
        try:
            lint_result = await _call_iac("validate_cloudformation_template", {
                "template_content": template_str, "regions": [REGION],
            })
            ctx.info(f"   cfn-lint: {lint_result[:300]}")
        except Exception as e:
            ctx.warning(f"   ⚠️ cfn-lint: {e}")

        # cfn-guard via IaC MCP (local, no Knowledge MCP)
        ctx.info("🛡️ Running cfn-guard (IaC MCP)...")
        guard_result = ""
        try:
            guard_result = await _call_iac("check_cloudformation_template_compliance", {
                "template_content": template_str,
            })
            ctx.info(f"   cfn-guard: {guard_result[:300]}")
        except Exception as e:
            ctx.warning(f"   ⚠️ cfn-guard: {e}")

        has_errors = lint_result and any(kw in lint_result for kw in ["E1", "E2", "E3"])
        has_guard_fail = guard_result and "FAIL" in guard_result

        if not has_errors and not has_guard_fail:
            ctx.info(f"✅ All validation passed (attempt {attempt})")
            return json.dumps({
                "status": "VALID", "attempt": attempt, "cdk_code": current,
                "cfn_template": synth.get("template"),
                "lint_result": lint_result[:2000], "guard_result": guard_result[:2000],
            })

        if attempt < max_attempts:
            issues = f"cfn-lint:\n{lint_result[:2000]}\n\ncfn-guard:\n{guard_result[:2000]}"
            ctx.info("🔧 Repairing...")
            current = _extract(_bedrock(
                "Fix this CDK TypeScript to resolve validation errors. ONLY corrected TypeScript.",
                f"Code:\n```typescript\n{current}\n```\n\nErrors:\n{issues}",
            ), "typescript")

    return json.dumps({"status": "ISSUES_REMAINING", "cdk_code": current,
                        "lint": lint_result[:2000], "guard": guard_result[:2000]})


@mcp.tool()
async def estimate_cost(ctx: Context, services: str) -> str:
    """Estimate costs using AWS Pricing MCP Server.

    Args:
        services: Comma-separated service names. Example: "lambda,dynamodb,s3"
    """
    ctx.info(f"💰 Getting pricing for: {services}")

    svc_map = {
        "lambda": "AWSLambda", "dynamodb": "AmazonDynamoDB", "s3": "AmazonS3",
        "apigateway": "AmazonApiGateway", "cognito": "AmazonCognito", "sqs": "AWSQueueService",
        "sns": "AmazonSNS", "cloudfront": "AmazonCloudFront", "rds": "AmazonRDS",
        "ecs": "AmazonECS", "eventbridge": "AmazonEventBridge",
    }

    results = []
    for svc in services.split(","):
        svc = svc.strip().lower()
        if not svc:
            continue
        service_code = svc_map.get(svc, svc)
        ctx.info(f"   📊 {svc}...")
        try:
            pricing = await _call_pricing("get_pricing", {"service_code": service_code, "region": REGION})
            results.append(f"--- {svc} ---\n{pricing[:2000]}")
        except Exception as e:
            ctx.warning(f"   ⚠️ {svc}: {e}")

    ctx.info("📋 Generating cost summary...")
    return _bedrock(
        "Summarize this AWS pricing data into a monthly cost estimate at low traffic (<1M req/month). Per-service breakdown table + total.",
        "\n\n".join(results), max_tokens=2048,
    )


@mcp.tool()
async def lookup_cdk_construct(ctx: Context, service: str, topic: str = "") -> str:
    """Look up CDK construct docs + samples.

    Args:
        service: AWS service (e.g. "dynamodb", "lambda", "sqs")
        topic: Optional topic (e.g. "dead letter queue", "CORS")
    """
    query = f"AWS CDK {service} L2 construct" + (f" {topic}" if topic else "")
    ctx.info(f"🔍 {query}")

    parts = []

    # Docs via Knowledge MCP directly
    docs = await _search_docs(query)
    if docs:
        parts.append(f"## CDK Documentation\n{docs}")

    # Samples via IaC MCP (local)
    try:
        samples = await _call_iac("search_cdk_samples_and_constructs", {"query": f"{service} {topic}".strip(), "language": "typescript"})
        parts.append(f"## Code Samples\n{samples}")
    except Exception as e:
        ctx.warning(f"⚠️ Samples: {e}")

    # Best practices via IaC MCP (local)
    try:
        best = await _call_iac("cdk_best_practices", {})
        parts.append(f"## Best Practices\n{best[:2000]}")
    except Exception as e:
        ctx.warning(f"⚠️ Best practices: {e}")

    return "\n\n".join(parts) if parts else f"No docs found for CDK {service} {topic}"


@mcp.tool()
def generate_diagram(architecture_plan_json: str) -> str:
    """Generate Mermaid diagram from architecture plan JSON.

    Args:
        architecture_plan_json: JSON with nodes and edges.
    """
    try:
        plan = json.loads(architecture_plan_json)
    except json.JSONDecodeError:
        return "Error: Invalid JSON"

    icons = {"apigateway": "🌐", "lambda": "λ", "dynamodb": "📊", "s3": "🪣", "cognito": "🔐",
             "sqs": "📨", "sns": "📢", "eventbridge": "⚡", "stepfunctions": "🔄",
             "cloudfront": "🌍", "rds-aurora": "🐘", "ecs-fargate": "🐳"}
    lines = ["graph LR"]
    for n in plan.get("nodes", []):
        lines.append(f'  {n["id"]}["{icons.get(n["service"], "📦")} {n["service"]}"]')
    for e in plan.get("edges", []):
        lines.append(f'  {e["from"]} -->|{e["type"]}| {e["to"]}')
    return "\n".join(lines)


@mcp.tool()
def deploy_stack(ctx: Context, cdk_code: str, stack_name: str = "CdkAgentStack", approved: bool = False) -> str:
    """Deploy CDK code via real cdk deploy. Requires approved=true.

    Args:
        cdk_code: CDK TypeScript stack code.
        stack_name: CloudFormation stack name.
        approved: Must be true to deploy. False = dry run.
    """
    if not approved:
        ctx.info("🔍 Dry run (set approved=true to deploy)")
        synth = _run_cdk_synth(cdk_code)
        resources = len(synth.get("template", {}).get("Resources", {})) if synth["success"] else 0
        return json.dumps({"status": "DRY_RUN", "valid": synth["success"],
                           "resources": resources, "error": synth.get("error")})

    ctx.info(f"🚀 Deploying '{stack_name}'...")
    with tempfile.TemporaryDirectory(prefix="cdk-deploy-") as d:
        Path(d, "lib").mkdir()
        Path(d, "lib", "stack.ts").write_text(cdk_code)
        Path(d, "bin").mkdir()
        Path(d, "bin", "app.ts").write_text(
            f'import * as cdk from "aws-cdk-lib";\n'
            f'const S = Object.values(require("../lib/stack")).find((v: any) => typeof v === "function") as any;\n'
            f'const app = new cdk.App();\nnew S(app, "{stack_name}");\n'
        )
        Path(d, "cdk.json").write_text('{"app":"npx ts-node bin/app.ts"}')
        Path(d, "tsconfig.json").write_text('{"compilerOptions":{"target":"ES2020","module":"commonjs","lib":["es2020"],"strict":true,"esModuleInterop":true,"outDir":"cdk.out"}}')
        Path(d, "package.json").write_text('{"dependencies":{"aws-cdk-lib":"^2","constructs":"^10","ts-node":"^10","typescript":"^5"}}')

        ctx.info("📦 npm install...")
        subprocess.run(["npm", "install", "--silent"], cwd=d, capture_output=True, timeout=120)
        ctx.info("☁️ cdk deploy...")
        r = subprocess.run(["npx", "cdk", "deploy", "--require-approval", "never", "--outputs-file", "outputs.json"],
                           cwd=d, capture_output=True, text=True, timeout=600)

        if r.returncode == 0:
            outputs = {}
            f = Path(d, "outputs.json")
            if f.exists():
                outputs = json.loads(f.read_text()).get(stack_name, {})
            ctx.info(f"🎉 Deployed! Outputs: {outputs}")
            return json.dumps({"status": "DEPLOYED", "stack_name": stack_name, "outputs": outputs})

        ctx.error(f"❌ Failed: {r.stderr[:300]}")
        return json.dumps({"status": "FAILED", "error": (r.stderr or r.stdout)[:3000]})


@mcp.tool()
async def troubleshoot_deployment(ctx: Context, stack_name: str) -> str:
    """Troubleshoot a failed CloudFormation deployment using AWS IaC MCP Server.

    Args:
        stack_name: Name of the failed stack.
    """
    ctx.info(f"🔍 Troubleshooting '{stack_name}'...")
    return await _call_iac("troubleshoot_cloudformation_deployment", {
        "stack_name": stack_name, "region": REGION,
    })


@mcp.tool()
def destroy_stack(ctx: Context, stack_name: str, approved: bool = False) -> str:
    """Destroy a CloudFormation stack. Requires approved=true.

    Args:
        stack_name: Stack to destroy.
        approved: Must be true.
    """
    if not approved:
        return json.dumps({"status": "CANCELLED"})
    ctx.info(f"🗑️ Destroying '{stack_name}'...")
    try:
        cfn = boto3.client("cloudformation", region_name=REGION)
        cfn.delete_stack(StackName=stack_name)
        cfn.get_waiter("stack_delete_complete").wait(StackName=stack_name, WaiterConfig={"Delay": 10, "MaxAttempts": 60})
        ctx.info("✅ Deleted")
        return json.dumps({"status": "DELETED", "stack_name": stack_name})
    except Exception as e:
        return json.dumps({"status": "FAILED", "error": str(e)})


@mcp.tool()
async def full_pipeline(ctx: Context, description: str, requirements: str = "") -> str:
    """End-to-end: describe → plan → confirm → diagram → CDK → validate → costs.

    Args:
        description: What to build. Example: "Serverless API with auth and DynamoDB"
        requirements: Answers to clarifying questions or constraints (from clarify_requirements). If empty, proceeds with defaults.
    """
    enriched = f"{description}\n\nRequirements/Constraints:\n{requirements}" if requirements else description
    ctx.info(f"🚀 Full pipeline: {enriched[:100]}")

    ctx.info("━━━ Step 1/6: Architecture ━━━")
    plan_json = await design_architecture(ctx, enriched)
    try:
        plan = json.loads(plan_json)
    except json.JSONDecodeError:
        return f"Failed to parse plan:\n{plan_json}"

    ctx.info("━━━ Step 2/6: Plan Confirmation ━━━")
    confirmation = json.loads(await confirm_plan(ctx, plan_json))
    ctx.info(f"   Services: {', '.join(confirmation['services'])}")
    ctx.info(f"   Nodes: {confirmation['node_count']}, Edges: {confirmation['edge_count']}")

    ctx.info("━━━ Step 3/6: Diagram ━━━")
    diagram = generate_diagram(plan_json)

    ctx.info("━━━ Step 4/6: CDK Code ━━━")
    code = await generate_cdk_stack(ctx, plan_json)

    ctx.info("━━━ Step 5/6: Validation ━━━")
    validation = json.loads(await validate_and_repair(ctx, code))
    if validation["status"] == "VALID":
        code = validation["cdk_code"]

    ctx.info("━━━ Step 6/6: Cost Estimate ━━━")
    services = ",".join(set(n["service"] for n in plan.get("nodes", [])))
    cost = await estimate_cost(ctx, services)

    ctx.info("🎉 Pipeline complete!")
    status = "✅ validated" if validation["status"] == "VALID" else "⚠️ " + validation["status"]

    return f"""## Plan Review
{confirmation['summary']}

## Architecture Plan
```json
{json.dumps(plan, indent=2)}
```

## Diagram
```mermaid
{diagram}
```

## CDK Stack ({status})
```typescript
{code}
```

## Cost Estimate
{cost}

## Next Steps
Call `deploy_stack` with the CDK code and `approved=true` to deploy.
"""


def main():
    import sys
    if "--serve" in sys.argv:
        port = 8080
        for i, arg in enumerate(sys.argv):
            if arg == "--port" and i + 1 < len(sys.argv):
                port = int(sys.argv[i + 1])

        from starlette.middleware.cors import CORSMiddleware

        # Stateful mode: required for CoT streaming via notifications/message
        mcp.settings.stateless_http = False
        app = mcp.streamable_http_app()
        app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"], expose_headers=["mcp-session-id"])

        import uvicorn
        uvicorn.run(app, host="0.0.0.0", port=port)
    else:
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
