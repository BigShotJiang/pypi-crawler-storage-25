"""Codec unit tests."""
