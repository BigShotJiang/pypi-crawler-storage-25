"""FlashCore package"""
