from fastapi import FastAPI, HTTPException, status, Depends
from pydantic import BaseModel
from src.infrastructure.redis_client import get_redis_client, reserve_inventory
from src.domain.config import settings

app = FastAPI(
    title="FlashCore API",
    description="High-Concurrency Flash Sale Drop Engine",
    version="1.0.0",
    docs_url="/docs",
    redoc_url=None,
)

class ReserveRequest(BaseModel):
    product_id: str
    user_id: str
    quantity: int = 1

class ReserveResponse(BaseModel):
    status: str
    message: str
    transaction_id: str | None = None

@app.get("/health", tags=["System"])
async def health_check():
    """Health check endpoint for Docker/Orchestrators."""
    return {"status": "healthy", "environment": settings.ENVIRONMENT}

@app.post("/api/v1/reserve", response_model=ReserveResponse, status_code=status.HTTP_200_OK, tags=["Inventory"])
async def reserve_item(request: ReserveRequest, redis=Depends(get_redis_client)):
    """
    Attempt to reserve inventory for a flash sale item.
    Uses atomic Lua scripting to prevent overselling.
    """
    success, transaction_id = await reserve_inventory(
        redis, 
        request.product_id, 
        request.user_id, 
        request.quantity
    )
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Inventory exhausted or insufficient quantity available."
        )
        
    return ReserveResponse(
        status="success",
        message="Inventory reserved successfully.",
        transaction_id=transaction_id
    )

# To initialize some dummy stock for testing:
@app.post("/api/v1/admin/stock", tags=["Admin"])
async def set_stock(product_id: str, quantity: int, redis=Depends(get_redis_client)):
    """Admin endpoint to set initial stock (In production, this should be secured)."""
    await redis.set(f"stock:{product_id}", quantity)
    return {"message": f"Stock for {product_id} set to {quantity}"}
