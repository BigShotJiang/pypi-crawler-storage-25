import redis.asyncio as redis
from typing import Tuple
import uuid
from src.domain.config import settings

# Lua Script for Atomic Inventory Deduction
# This guarantees that checking stock and decrementing it happens in a single atomic step,
# preventing race conditions (overselling) during massive traffic spikes.
RESERVE_SCRIPT = """
local stock_key = KEYS[1]
local quantity = tonumber(ARGV[1])

local current_stock = redis.call('GET', stock_key)
if current_stock and tonumber(current_stock) >= quantity then
    redis.call('DECRBY', stock_key, quantity)
    return 1
else
    return 0
end
"""

async def get_redis_client():
    """Dependency injection for Redis client."""
    client = redis.Redis(
        host=settings.REDIS_HOST,
        port=settings.REDIS_PORT,
        password=settings.REDIS_PASSWORD,
        db=settings.REDIS_DB,
        decode_responses=True
    )
    try:
        yield client
    finally:
        await client.aclose()

async def reserve_inventory(client: redis.Redis, product_id: str, user_id: str, quantity: int) -> Tuple[bool, str | None]:
    """
    Executes the Lua script to atomically reserve inventory.
    """
    stock_key = f"stock:{product_id}"
    
    # Execute the Lua script
    result = await client.eval(RESERVE_SCRIPT, 1, stock_key, quantity)
    
    if result == 1:
        # Generate a unique transaction ID for the reservation
        transaction_id = f"txn_{uuid.uuid4().hex}"
        # In a real system, we would push this transaction_id to a Kafka/Redis queue 
        # for the order processing worker to finalize the payment.
        await client.hset(f"reservation:{transaction_id}", mapping={
            "product_id": product_id,
            "user_id": user_id,
            "quantity": quantity,
            "status": "pending_payment"
        })
        # Set expiry for the reservation (e.g., user has 10 mins to pay)
        await client.expire(f"reservation:{transaction_id}", 600)
        
        return True, transaction_id
        
    return False, None
