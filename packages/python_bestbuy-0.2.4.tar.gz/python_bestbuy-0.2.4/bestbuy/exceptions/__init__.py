"""Custom exceptions for the Best Buy API client."""

from __future__ import annotations

from dataclasses import dataclass


class BestBuyError(Exception):
    """Base exception for all Best Buy API errors."""

    pass


class ConfigError(BestBuyError):
    """Raised when there's an error with client configuration."""

    pass


class AuthenticationError(BestBuyError):
    """Raised when authentication fails."""

    pass


class SessionRequiredError(BestBuyError):
    """Raised when an operation requires an active session but none exists."""

    pass


class APIError(BestBuyError):
    """Raised when the API returns an error.

    Used to handle errors from both Commerce and Catalog APIs.

    Attributes:
        message: Human-readable error message
        code: Error code from the API (if available)
        sku: SKU that caused the error (if available)
        response_text: Raw response text (XML or JSON)
    """

    def __init__(
        self,
        message: str,
        code: str | None = None,
        sku: str | None = None,
        response_text: str | None = None,
    ):
        self.message = message
        self.code = code
        self.sku = sku
        self.response_text = response_text

        # Build error message
        parts = [message]
        if code:
            parts.append(f"Error code: {code}")
        if sku:
            parts.append(f"SKU: {sku}")

        super().__init__(" | ".join(parts))


# Commerce-specific exceptions


@dataclass
class OrderErrorMessage:
    """A single message from a commerce order error response.

    Attributes:
        code: The error code (from the ``item-id`` XML attribute),
            e.g. ``"INVALID_CID"``, ``"MISSINGPARTNERID"``.
        text: The human-readable error message.
    """

    code: str
    text: str


class CommerceOrderError(APIError):
    """Raised when the Commerce API rejects an order (HTTP 400).

    Contains structured error messages from the
    ``<order-response><messages>`` element. Multiple messages may be
    present when several validation errors occur simultaneously.

    Inherits from :class:`APIError` so existing ``except APIError``
    catch blocks still work. Callers can also catch
    ``CommerceOrderError`` specifically for structured access to the
    error messages list.

    Attributes:
        messages: List of structured error messages with codes.
    """

    def __init__(
        self,
        messages: list[OrderErrorMessage],
        response_text: str | None = None,
    ) -> None:
        self.messages = messages
        primary = (
            messages[0]
            if messages
            else OrderErrorMessage(code="UNKNOWN", text="Unknown order error")
        )

        parts = [primary.text]
        if primary.code:
            parts.append(f"Error code: {primary.code}")
        if len(messages) > 1:
            parts.append(f"{len(messages)} total errors")

        # Initialize APIError fields directly (skip APIError.__init__
        # to control the str representation)
        self.message = primary.text
        self.code = primary.code
        self.sku = None
        self.response_text = response_text
        BestBuyError.__init__(self, " | ".join(parts))
