"""Catalog API operations for Best Buy."""

from collections.abc import AsyncIterator, Iterator
from typing import List, Optional

from .base import BaseOperations
from .pagination import AsyncPaginator, Paginator
from ..models import (
    CatalogStore,
    CatalogStoresResponse,
    CategoriesResponse,
    Category,
    OpenBoxProduct,
    OpenBoxResponse,
    Product,
    ProductsResponse,
    RealTimeAvailabilityResponse,
    RecommendationsResponse,
    Warranty,
)


class _ProductOpsBase(BaseOperations):
    """Shared request-building logic for the Products API."""

    def _build_get_request(
        self,
        sku: int | str,
        show: Optional[List[str]] = None,
    ):
        params = {"apiKey": self.client.options.api_key}
        if show:
            params["show"] = ",".join(show)
        return self.client.client.build_request(
            method="GET",
            url=f"/v1/products/{sku}.json",
            params=params,
        )

    def _build_search_request(
        self,
        query: Optional[str] = None,
        show: Optional[List[str]] = None,
        sort: Optional[str] = None,
        sort_order: Optional[str] = None,
        page: int = 1,
        page_size: int = 10,
        facet: Optional[str] = None,
        cursor_mark: Optional[str] = None,
    ):
        params = {
            "apiKey": self.client.options.api_key,
            "page": page,
            "pageSize": page_size,
        }
        if show:
            params["show"] = ",".join(show)
        if sort:
            sort_str = sort
            if sort_order:
                sort_str = f"{sort}.{sort_order}"
            params["sort"] = sort_str
        if facet:
            params["facet"] = facet
        if cursor_mark:
            params["cursorMark"] = cursor_mark
        # Build URL with query in path (Best Buy API v1 style).
        # BB rejects the .json path suffix; use format=json query param instead.
        url = f"/v1/products({query})" if query else "/v1/products"
        params["format"] = "json"
        return self.client.client.build_request(
            method="GET",
            url=url,
            params=params,
        )

    def _build_warranties_request(self, sku: int | str):
        params = {"apiKey": self.client.options.api_key}
        return self.client.client.build_request(
            method="GET",
            url=f"/v1/products/{sku}/warranties.json",
            params=params,
        )

    def _build_real_time_availability_request(
        self,
        sku: int | str,
        postal_code: Optional[str] = None,
        store_id: Optional[int | str] = None,
    ):
        if not postal_code and not store_id:
            raise ValueError("Either postal_code or store_id must be provided")
        params = {"apiKey": self.client.options.api_key, "format": "json"}
        if postal_code:
            params["postalCode"] = postal_code
        if store_id:
            params["storeId"] = str(store_id)
        return self.client.client.build_request(
            method="GET",
            url=f"/v1/products/{sku}/stores.json",
            params=params,
        )

    def _build_availability_request(
        self,
        sku: int | str,
        store_ids: List[int | str],
    ):
        if not store_ids:
            raise ValueError("store_ids must contain at least one store ID")
        ids = ",".join(str(s) for s in store_ids)
        url = f"/v1/products(sku={sku})+stores(storeId in({ids}))"
        params = {"apiKey": self.client.options.api_key, "format": "json"}
        return self.client.client.build_request(
            method="GET",
            url=url,
            params=params,
        )


class ProductOperations(_ProductOpsBase):
    """Operations for the Products API."""

    def get(
        self,
        sku: int | str,
        show: Optional[List[str]] = None,
    ) -> Product:
        """Get a single product by SKU.

        Args:
            sku: The Best Buy product SKU.
            show: Optional list of attributes to return. If None, returns all.

        Returns:
            The product details.
        """
        response = self.client.request(self._build_get_request(sku, show))
        return Product.model_validate(response.json())

    def search(
        self,
        query: Optional[str] = None,
        show: Optional[List[str]] = None,
        sort: Optional[str] = None,
        sort_order: Optional[str] = None,
        page: int = 1,
        page_size: int = 10,
        facet: Optional[str] = None,
        cursor_mark: Optional[str] = None,
    ) -> ProductsResponse:
        """Search for products.

        Args:
            query: Search query string (e.g., "manufacturer=canon&salePrice<1000").
            show: Optional list of attributes to return.
            sort: Attribute to sort by.
            sort_order: Sort direction ("asc" or "desc").
            page: Page number (1-indexed).
            page_size: Number of results per page (max 100).
            facet: Facet attribute and count (e.g., "manufacturer,5").
            cursor_mark: Cursor mark for deep pagination.

        Returns:
            ProductsResponse containing matching products.
        """
        response = self.client.request(
            self._build_search_request(
                query, show, sort, sort_order, page, page_size, facet, cursor_mark
            )
        )
        return ProductsResponse.model_validate(response.json())

    def list(
        self,
        show: Optional[List[str]] = None,
        sort: Optional[str] = None,
        sort_order: Optional[str] = None,
        page: int = 1,
        page_size: int = 10,
    ) -> ProductsResponse:
        """List all products.

        Args:
            show: Optional list of attributes to return.
            sort: Attribute to sort by.
            sort_order: Sort direction ("asc" or "desc").
            page: Page number (1-indexed).
            page_size: Number of results per page (max 100).

        Returns:
            ProductsResponse containing products.
        """
        return self.search(
            query=None,
            show=show,
            sort=sort,
            sort_order=sort_order,
            page=page,
            page_size=page_size,
        )

    def get_warranties(
        self,
        sku: int | str,
    ) -> List[Warranty]:
        """Get warranties for a product.

        Args:
            sku: The Best Buy product SKU.

        Returns:
            List of Warranty objects offered for this product.
        """
        response = self.client.request(self._build_warranties_request(sku))
        return [Warranty.model_validate(w) for w in response.json()]

    def get_real_time_availability(
        self,
        sku: int | str,
        postal_code: Optional[str] = None,
        store_id: Optional[int | str] = None,
    ) -> RealTimeAvailabilityResponse:
        """Check real-time in-store availability for a product.

        Exactly one of ``postal_code`` or ``store_id`` must be provided.

        Args:
            sku: The Best Buy product SKU.
            postal_code: ZIP code to search around.
            store_id: A specific Best Buy store ID to check.

        Returns:
            RealTimeAvailabilityResponse with per-store availability info.
        """
        response = self.client.request(
            self._build_real_time_availability_request(sku, postal_code, store_id)
        )
        return RealTimeAvailabilityResponse.model_validate(response.json())

    def availability(
        self,
        sku: int | str,
        store_ids: List[int | str],
    ) -> ProductsResponse:
        """Check availability of a product across multiple stores.

        Uses Best Buy's compound query syntax to fetch both product data and
        per-store availability in a single request. Each product in the
        response will have its ``stores`` field populated with
        ``ProductStoreAvailability`` entries.

        Args:
            sku: The Best Buy product SKU.
            store_ids: List of Best Buy store IDs to check.

        Returns:
            ProductsResponse with nested store availability data.
        """
        response = self.client.request(self._build_availability_request(sku, store_ids))
        return ProductsResponse.model_validate(response.json())

    def stream(
        self,
        query: Optional[str] = None,
        show: Optional[List[str]] = None,
        sort: Optional[str] = None,
        sort_order: Optional[str] = None,
        facet: Optional[str] = None,
        page_size: int = 100,
    ) -> Iterator[Product]:
        """Stream all matching products using cursor mark pagination.

        Yields individual products, automatically fetching subsequent pages
        via cursor marks. Equivalent to the JS SDK's productsAsStream().

        Args:
            query: Search query string (e.g., "manufacturer=canon&salePrice<1000").
            show: Optional list of attributes to return.
            sort: Attribute to sort by.
            sort_order: Sort direction ("asc" or "desc").
            facet: Facet attribute and count (e.g., "manufacturer,5").
            page_size: Number of results per page (max 100).

        Yields:
            Individual Product objects.
        """
        cursor_mark = "*"
        while True:
            request = self._build_search_request(
                query=query,
                show=show,
                sort=sort,
                sort_order=sort_order,
                page_size=page_size,
                facet=facet,
                cursor_mark=cursor_mark,
            )
            response = self.client.request(request)
            data = response.json()
            for item_data in data.get("products", []):
                yield Product.model_validate(item_data)
            next_cursor = data.get("nextCursorMark")
            if not next_cursor or next_cursor == cursor_mark:
                break
            cursor_mark = next_cursor

    def search_pages(
        self,
        query: Optional[str] = None,
        show: Optional[List[str]] = None,
        sort: Optional[str] = None,
        sort_order: Optional[str] = None,
        page_size: int = 10,
        max_pages: Optional[int] = None,
    ) -> Paginator[ProductsResponse, Product]:
        """Search for products with automatic pagination.

        Returns a Paginator that can iterate over all pages or items.

        Args:
            query: Search query string (e.g., "manufacturer=canon&salePrice<1000").
            show: Optional list of attributes to return.
            sort: Attribute to sort by.
            sort_order: Sort direction ("asc" or "desc").
            page_size: Number of results per page (max 100).
            max_pages: Maximum number of pages to fetch (None for all).

        Returns:
            Paginator for iterating over pages or products.

        Example:
            # Iterate over pages
            for page in client.products.search_pages(query="onSale=true"):
                for product in page.products:
                    print(product.name)

            # Iterate over all products directly
            for product in client.products.search_pages(query="onSale=true").items():
                print(product.name)
        """

        def fetch_page(page: int) -> ProductsResponse:
            return self.search(
                query=query,
                show=show,
                sort=sort,
                sort_order=sort_order,
                page=page,
                page_size=page_size,
            )

        return Paginator(
            fetch_page=fetch_page,
            items_attr="products",
            page_size=page_size,
            max_pages=max_pages,
        )

    def list_pages(
        self,
        show: Optional[List[str]] = None,
        sort: Optional[str] = None,
        sort_order: Optional[str] = None,
        page_size: int = 10,
        max_pages: Optional[int] = None,
    ) -> Paginator[ProductsResponse, Product]:
        """List all products with automatic pagination.

        Returns a Paginator that can iterate over all pages or items.

        Args:
            show: Optional list of attributes to return.
            sort: Attribute to sort by.
            sort_order: Sort direction ("asc" or "desc").
            page_size: Number of results per page (max 100).
            max_pages: Maximum number of pages to fetch (None for all).

        Returns:
            Paginator for iterating over pages or products.
        """
        return self.search_pages(
            query=None,
            show=show,
            sort=sort,
            sort_order=sort_order,
            page_size=page_size,
            max_pages=max_pages,
        )


class AsyncProductOperations(_ProductOpsBase):
    """Async operations for the Products API."""

    async def get(
        self,
        sku: int | str,
        show: Optional[List[str]] = None,
    ) -> Product:
        """Get a single product by SKU."""
        response = await self.client.request(self._build_get_request(sku, show))
        return Product.model_validate(response.json())

    async def search(
        self,
        query: Optional[str] = None,
        show: Optional[List[str]] = None,
        sort: Optional[str] = None,
        sort_order: Optional[str] = None,
        page: int = 1,
        page_size: int = 10,
        facet: Optional[str] = None,
        cursor_mark: Optional[str] = None,
    ) -> ProductsResponse:
        """Search for products."""
        response = await self.client.request(
            self._build_search_request(
                query, show, sort, sort_order, page, page_size, facet, cursor_mark
            )
        )
        return ProductsResponse.model_validate(response.json())

    async def list(
        self,
        show: Optional[List[str]] = None,
        sort: Optional[str] = None,
        sort_order: Optional[str] = None,
        page: int = 1,
        page_size: int = 10,
    ) -> ProductsResponse:
        """List all products."""
        return await self.search(
            query=None,
            show=show,
            sort=sort,
            sort_order=sort_order,
            page=page,
            page_size=page_size,
        )

    async def get_warranties(
        self,
        sku: int | str,
    ) -> List[Warranty]:
        """Get warranties for a product."""
        response = await self.client.request(self._build_warranties_request(sku))
        return [Warranty.model_validate(w) for w in response.json()]

    async def get_real_time_availability(
        self,
        sku: int | str,
        postal_code: Optional[str] = None,
        store_id: Optional[int | str] = None,
    ) -> RealTimeAvailabilityResponse:
        """Check real-time in-store availability for a product."""
        response = await self.client.request(
            self._build_real_time_availability_request(sku, postal_code, store_id)
        )
        return RealTimeAvailabilityResponse.model_validate(response.json())

    async def availability(
        self,
        sku: int | str,
        store_ids: List[int | str],
    ) -> ProductsResponse:
        """Check availability of a product across multiple stores."""
        response = await self.client.request(
            self._build_availability_request(sku, store_ids)
        )
        return ProductsResponse.model_validate(response.json())

    async def stream(
        self,
        query: Optional[str] = None,
        show: Optional[List[str]] = None,
        sort: Optional[str] = None,
        sort_order: Optional[str] = None,
        facet: Optional[str] = None,
        page_size: int = 100,
    ) -> AsyncIterator[Product]:
        """Stream all matching products using cursor mark pagination.

        Yields individual products, automatically fetching subsequent pages
        via cursor marks. Equivalent to the JS SDK's productsAsStream().

        Args:
            query: Search query string (e.g., "manufacturer=canon&salePrice<1000").
            show: Optional list of attributes to return.
            sort: Attribute to sort by.
            sort_order: Sort direction ("asc" or "desc").
            facet: Facet attribute and count (e.g., "manufacturer,5").
            page_size: Number of results per page (max 100).

        Yields:
            Individual Product objects.
        """
        cursor_mark = "*"
        while True:
            request = self._build_search_request(
                query=query,
                show=show,
                sort=sort,
                sort_order=sort_order,
                page_size=page_size,
                facet=facet,
                cursor_mark=cursor_mark,
            )
            response = await self.client.request(request)
            data = response.json()
            for item_data in data.get("products", []):
                yield Product.model_validate(item_data)
            next_cursor = data.get("nextCursorMark")
            if not next_cursor or next_cursor == cursor_mark:
                break
            cursor_mark = next_cursor

    def search_pages(
        self,
        query: Optional[str] = None,
        show: Optional[List[str]] = None,
        sort: Optional[str] = None,
        sort_order: Optional[str] = None,
        page_size: int = 10,
        max_pages: Optional[int] = None,
    ) -> AsyncPaginator[ProductsResponse, Product]:
        """Search for products with automatic pagination.

        Returns an AsyncPaginator that can iterate over all pages or items.

        Args:
            query: Search query string (e.g., "manufacturer=canon&salePrice<1000").
            show: Optional list of attributes to return.
            sort: Attribute to sort by.
            sort_order: Sort direction ("asc" or "desc").
            page_size: Number of results per page (max 100).
            max_pages: Maximum number of pages to fetch (None for all).

        Returns:
            AsyncPaginator for iterating over pages or products.

        Example:
            # Iterate over pages
            async for page in client.products.search_pages(query="onSale=true"):
                for product in page.products:
                    print(product.name)

            # Iterate over all products directly
            async for product in client.products.search_pages(query="onSale=true").items():
                print(product.name)
        """

        async def fetch_page(page: int) -> ProductsResponse:
            return await self.search(
                query=query,
                show=show,
                sort=sort,
                sort_order=sort_order,
                page=page,
                page_size=page_size,
            )

        return AsyncPaginator(
            fetch_page=fetch_page,
            items_attr="products",
            page_size=page_size,
            max_pages=max_pages,
        )

    def list_pages(
        self,
        show: Optional[List[str]] = None,
        sort: Optional[str] = None,
        sort_order: Optional[str] = None,
        page_size: int = 10,
        max_pages: Optional[int] = None,
    ) -> AsyncPaginator[ProductsResponse, Product]:
        """List all products with automatic pagination."""
        return self.search_pages(
            query=None,
            show=show,
            sort=sort,
            sort_order=sort_order,
            page_size=page_size,
            max_pages=max_pages,
        )


class _CategoryOpsBase(BaseOperations):
    """Shared request-building logic for the Categories API."""

    def _build_get_request(
        self,
        category_id: str,
        show: Optional[List[str]] = None,
    ):
        params = {"apiKey": self.client.options.api_key}
        if show:
            params["show"] = ",".join(show)
        return self.client.client.build_request(
            method="GET",
            url=f"/v1/categories/{category_id}.json",
            params=params,
        )

    def _build_search_request(
        self,
        query: Optional[str] = None,
        show: Optional[List[str]] = None,
        page: int = 1,
        page_size: int = 10,
        cursor_mark: Optional[str] = None,
    ):
        params = {
            "apiKey": self.client.options.api_key,
            "page": page,
            "pageSize": page_size,
        }
        if show:
            params["show"] = ",".join(show)
        if cursor_mark:
            params["cursorMark"] = cursor_mark
        # BB rejects the .json path suffix; use format=json query param instead.
        url = f"/v1/categories({query})" if query else "/v1/categories"
        params["format"] = "json"
        return self.client.client.build_request(
            method="GET",
            url=url,
            params=params,
        )


class CategoryOperations(_CategoryOpsBase):
    """Operations for the Categories API."""

    def get(
        self,
        category_id: str,
        show: Optional[List[str]] = None,
    ) -> Category:
        """Get a single category by ID.

        Args:
            category_id: The category ID.
            show: Optional list of attributes to return.

        Returns:
            The category details.
        """
        response = self.client.request(self._build_get_request(category_id, show))
        return Category.model_validate(response.json())

    def search(
        self,
        query: Optional[str] = None,
        show: Optional[List[str]] = None,
        page: int = 1,
        page_size: int = 10,
    ) -> CategoriesResponse:
        """Search for categories.

        Args:
            query: Search query string.
            show: Optional list of attributes to return.
            page: Page number (1-indexed).
            page_size: Number of results per page (max 100).

        Returns:
            CategoriesResponse containing matching categories.
        """
        response = self.client.request(
            self._build_search_request(query, show, page, page_size)
        )
        return CategoriesResponse.model_validate(response.json())

    def list(
        self,
        show: Optional[List[str]] = None,
        page: int = 1,
        page_size: int = 10,
    ) -> CategoriesResponse:
        """List all categories.

        Args:
            show: Optional list of attributes to return.
            page: Page number (1-indexed).
            page_size: Number of results per page (max 100).

        Returns:
            CategoriesResponse containing categories.
        """
        return self.search(
            query=None,
            show=show,
            page=page,
            page_size=page_size,
        )

    def stream(
        self,
        query: Optional[str] = None,
        show: Optional[List[str]] = None,
        page_size: int = 100,
    ) -> Iterator[Category]:
        """Stream all matching categories using cursor mark pagination.

        Yields individual categories, automatically fetching subsequent pages
        via cursor marks. Equivalent to the JS SDK's categoriesAsStream().

        Args:
            query: Search query string.
            show: Optional list of attributes to return.
            page_size: Number of results per page (max 100).

        Yields:
            Individual Category objects.
        """
        cursor_mark = "*"
        while True:
            request = self._build_search_request(
                query=query,
                show=show,
                page_size=page_size,
                cursor_mark=cursor_mark,
            )
            response = self.client.request(request)
            data = response.json()
            for item_data in data.get("categories", []):
                yield Category.model_validate(item_data)
            next_cursor = data.get("nextCursorMark")
            if not next_cursor or next_cursor == cursor_mark:
                break
            cursor_mark = next_cursor

    def search_pages(
        self,
        query: Optional[str] = None,
        show: Optional[List[str]] = None,
        page_size: int = 10,
        max_pages: Optional[int] = None,
    ) -> Paginator[CategoriesResponse, Category]:
        """Search for categories with automatic pagination.

        Args:
            query: Search query string.
            show: Optional list of attributes to return.
            page_size: Number of results per page (max 100).
            max_pages: Maximum number of pages to fetch (None for all).

        Returns:
            Paginator for iterating over pages or categories.
        """

        def fetch_page(page: int) -> CategoriesResponse:
            return self.search(
                query=query,
                show=show,
                page=page,
                page_size=page_size,
            )

        return Paginator(
            fetch_page=fetch_page,
            items_attr="categories",
            page_size=page_size,
            max_pages=max_pages,
        )

    def list_pages(
        self,
        show: Optional[List[str]] = None,
        page_size: int = 10,
        max_pages: Optional[int] = None,
    ) -> Paginator[CategoriesResponse, Category]:
        """List all categories with automatic pagination.

        Args:
            show: Optional list of attributes to return.
            page_size: Number of results per page (max 100).
            max_pages: Maximum number of pages to fetch (None for all).

        Returns:
            Paginator for iterating over pages or categories.
        """
        return self.search_pages(
            query=None,
            show=show,
            page_size=page_size,
            max_pages=max_pages,
        )


class AsyncCategoryOperations(_CategoryOpsBase):
    """Async operations for the Categories API."""

    async def get(
        self,
        category_id: str,
        show: Optional[List[str]] = None,
    ) -> Category:
        """Get a single category by ID."""
        response = await self.client.request(self._build_get_request(category_id, show))
        return Category.model_validate(response.json())

    async def search(
        self,
        query: Optional[str] = None,
        show: Optional[List[str]] = None,
        page: int = 1,
        page_size: int = 10,
    ) -> CategoriesResponse:
        """Search for categories."""
        response = await self.client.request(
            self._build_search_request(query, show, page, page_size)
        )
        return CategoriesResponse.model_validate(response.json())

    async def list(
        self,
        show: Optional[List[str]] = None,
        page: int = 1,
        page_size: int = 10,
    ) -> CategoriesResponse:
        """List all categories."""
        return await self.search(
            query=None,
            show=show,
            page=page,
            page_size=page_size,
        )

    async def stream(
        self,
        query: Optional[str] = None,
        show: Optional[List[str]] = None,
        page_size: int = 100,
    ) -> AsyncIterator[Category]:
        """Stream all matching categories using cursor mark pagination.

        Yields individual categories, automatically fetching subsequent pages
        via cursor marks. Equivalent to the JS SDK's categoriesAsStream().

        Args:
            query: Search query string.
            show: Optional list of attributes to return.
            page_size: Number of results per page (max 100).

        Yields:
            Individual Category objects.
        """
        cursor_mark = "*"
        while True:
            request = self._build_search_request(
                query=query,
                show=show,
                page_size=page_size,
                cursor_mark=cursor_mark,
            )
            response = await self.client.request(request)
            data = response.json()
            for item_data in data.get("categories", []):
                yield Category.model_validate(item_data)
            next_cursor = data.get("nextCursorMark")
            if not next_cursor or next_cursor == cursor_mark:
                break
            cursor_mark = next_cursor

    def search_pages(
        self,
        query: Optional[str] = None,
        show: Optional[List[str]] = None,
        page_size: int = 10,
        max_pages: Optional[int] = None,
    ) -> AsyncPaginator[CategoriesResponse, Category]:
        """Search for categories with automatic pagination."""

        async def fetch_page(page: int) -> CategoriesResponse:
            return await self.search(
                query=query,
                show=show,
                page=page,
                page_size=page_size,
            )

        return AsyncPaginator(
            fetch_page=fetch_page,
            items_attr="categories",
            page_size=page_size,
            max_pages=max_pages,
        )

    def list_pages(
        self,
        show: Optional[List[str]] = None,
        page_size: int = 10,
        max_pages: Optional[int] = None,
    ) -> AsyncPaginator[CategoriesResponse, Category]:
        """List all categories with automatic pagination."""
        return self.search_pages(
            query=None,
            show=show,
            page_size=page_size,
            max_pages=max_pages,
        )


class _RecommendationOpsBase(BaseOperations):
    """Shared request-building logic for the Recommendations API."""

    def _build_category_request(self, endpoint: str, category_id: Optional[str] = None):
        params = {"apiKey": self.client.options.api_key}
        if category_id:
            url = f"/v1/products/{endpoint}(categoryId={category_id})"
        else:
            url = f"/v1/products/{endpoint}"
        params["format"] = "json"
        return self.client.client.build_request(method="GET", url=url, params=params)

    def _build_sku_request(self, endpoint: str, sku: int | str):
        params = {"apiKey": self.client.options.api_key, "format": "json"}
        return self.client.client.build_request(
            method="GET",
            url=f"/v1/products/{sku}/{endpoint}",
            params=params,
        )


class RecommendationOperations(_RecommendationOpsBase):
    """Operations for the Recommendations API."""

    def trending(
        self,
        category_id: Optional[str] = None,
    ) -> RecommendationsResponse:
        """Get trending products.

        Returns top ten products based on customer views over a rolling
        three hour time period.

        Args:
            category_id: Optional category ID to filter by.

        Returns:
            RecommendationsResponse containing trending products.
        """
        response = self.client.request(
            self._build_category_request("trendingViewed", category_id),
        )
        return RecommendationsResponse.model_validate(response.json())

    def most_viewed(
        self,
        category_id: Optional[str] = None,
    ) -> RecommendationsResponse:
        """Get most viewed products.

        Returns top ten most frequently viewed products on BESTBUY.COM.

        Args:
            category_id: Optional category ID to filter by.

        Returns:
            RecommendationsResponse containing most viewed products.
        """
        response = self.client.request(
            self._build_category_request("mostViewed", category_id),
        )
        return RecommendationsResponse.model_validate(response.json())

    def also_viewed(self, sku: int | str) -> RecommendationsResponse:
        """Get products also viewed with the specified product.

        Args:
            sku: The product SKU.

        Returns:
            RecommendationsResponse containing also viewed products.
        """
        response = self.client.request(self._build_sku_request("alsoViewed", sku))
        return RecommendationsResponse.model_validate(response.json())

    def also_bought(self, sku: int | str) -> RecommendationsResponse:
        """Get products also bought with the specified product.

        Args:
            sku: The product SKU.

        Returns:
            RecommendationsResponse containing also bought products.
        """
        response = self.client.request(self._build_sku_request("alsoBought", sku))
        return RecommendationsResponse.model_validate(response.json())

    def viewed_ultimately_bought(self, sku: int | str) -> RecommendationsResponse:
        """Get products ultimately bought after viewing the specified product.

        Args:
            sku: The product SKU.

        Returns:
            RecommendationsResponse containing viewed ultimately bought products.
        """
        response = self.client.request(
            self._build_sku_request("viewedUltimatelyBought", sku),
        )
        return RecommendationsResponse.model_validate(response.json())


class AsyncRecommendationOperations(_RecommendationOpsBase):
    """Async operations for the Recommendations API."""

    async def trending(
        self,
        category_id: Optional[str] = None,
    ) -> RecommendationsResponse:
        """Get trending products."""
        response = await self.client.request(
            self._build_category_request("trendingViewed", category_id),
        )
        return RecommendationsResponse.model_validate(response.json())

    async def most_viewed(
        self,
        category_id: Optional[str] = None,
    ) -> RecommendationsResponse:
        """Get most viewed products."""
        response = await self.client.request(
            self._build_category_request("mostViewed", category_id),
        )
        return RecommendationsResponse.model_validate(response.json())

    async def also_viewed(self, sku: int | str) -> RecommendationsResponse:
        """Get products also viewed with the specified product."""
        response = await self.client.request(
            self._build_sku_request("alsoViewed", sku),
        )
        return RecommendationsResponse.model_validate(response.json())

    async def also_bought(self, sku: int | str) -> RecommendationsResponse:
        """Get products also bought with the specified product."""
        response = await self.client.request(
            self._build_sku_request("alsoBought", sku),
        )
        return RecommendationsResponse.model_validate(response.json())

    async def viewed_ultimately_bought(self, sku: int | str) -> RecommendationsResponse:
        """Get products ultimately bought after viewing the specified product."""
        response = await self.client.request(
            self._build_sku_request("viewedUltimatelyBought", sku),
        )
        return RecommendationsResponse.model_validate(response.json())


class _StoreOpsBase(BaseOperations):
    """Shared request-building logic for the Stores API."""

    def _build_get_request(
        self,
        store_id: int,
        show: Optional[List[str]] = None,
    ):
        params = {"apiKey": self.client.options.api_key}
        if show:
            params["show"] = ",".join(show)
        return self.client.client.build_request(
            method="GET",
            url=f"/v1/stores/{store_id}.json",
            params=params,
        )

    def _build_search_request(
        self,
        query: Optional[str] = None,
        show: Optional[List[str]] = None,
        page: int = 1,
        page_size: int = 10,
        cursor_mark: Optional[str] = None,
    ):
        params = {
            "apiKey": self.client.options.api_key,
            "page": page,
            "pageSize": page_size,
        }
        if show:
            params["show"] = ",".join(show)
        if cursor_mark:
            params["cursorMark"] = cursor_mark
        url = f"/v1/stores({query})" if query else "/v1/stores"
        params["format"] = "json"
        return self.client.client.build_request(
            method="GET",
            url=url,
            params=params,
        )

    @staticmethod
    def _build_area_query(
        postal_code: Optional[str] = None,
        lat: Optional[float] = None,
        lng: Optional[float] = None,
        distance: int = 10,
    ) -> str:
        """Build an area query string from location parameters.

        Returns:
            The area query string (e.g. ``"area(55423,10)"``).

        Raises:
            ValueError: If neither postal_code nor lat/lng are provided.
        """
        if postal_code:
            return f"area({postal_code},{distance})"
        elif lat is not None and lng is not None:
            return f"area({lat},{lng},{distance})"
        else:
            raise ValueError("Either postal_code or lat/lng must be provided")


class StoreOperations(_StoreOpsBase):
    """Operations for the Stores API."""

    def get(
        self,
        store_id: int,
        show: Optional[List[str]] = None,
    ) -> CatalogStore:
        """Get a single store by ID.

        Args:
            store_id: The Best Buy store ID.
            show: Optional list of attributes to return.

        Returns:
            The store details.
        """
        response = self.client.request(self._build_get_request(store_id, show))
        return CatalogStore.model_validate(response.json())

    def search(
        self,
        query: Optional[str] = None,
        show: Optional[List[str]] = None,
        page: int = 1,
        page_size: int = 10,
    ) -> CatalogStoresResponse:
        """Search for stores.

        Args:
            query: Search query string (e.g., "postalCode=55423").
            show: Optional list of attributes to return.
            page: Page number (1-indexed).
            page_size: Number of results per page (max 100).

        Returns:
            CatalogStoresResponse containing matching stores.
        """
        response = self.client.request(
            self._build_search_request(query, show, page, page_size)
        )
        return CatalogStoresResponse.model_validate(response.json())

    def list(
        self,
        show: Optional[List[str]] = None,
        page: int = 1,
        page_size: int = 10,
    ) -> CatalogStoresResponse:
        """List all stores.

        Args:
            show: Optional list of attributes to return.
            page: Page number (1-indexed).
            page_size: Number of results per page (max 100).

        Returns:
            CatalogStoresResponse containing stores.
        """
        return self.search(
            query=None,
            show=show,
            page=page,
            page_size=page_size,
        )

    def search_by_area(
        self,
        postal_code: Optional[str] = None,
        lat: Optional[float] = None,
        lng: Optional[float] = None,
        distance: int = 10,
        show: Optional[List[str]] = None,
        page: int = 1,
        page_size: int = 10,
    ) -> CatalogStoresResponse:
        """Search for stores within a specified area.

        Args:
            postal_code: ZIP code to search around.
            lat: Latitude to search around (use with lng).
            lng: Longitude to search around (use with lat).
            distance: Search radius in miles (default 10).
            show: Optional list of attributes to return.
            page: Page number (1-indexed).
            page_size: Number of results per page (max 100).

        Returns:
            CatalogStoresResponse containing nearby stores.
        """
        query = self._build_area_query(postal_code, lat, lng, distance)
        return self.search(
            query=query,
            show=show,
            page=page,
            page_size=page_size,
        )

    def stream(
        self,
        query: Optional[str] = None,
        show: Optional[List[str]] = None,
        page_size: int = 100,
    ) -> Iterator[CatalogStore]:
        """Stream all matching stores using cursor mark pagination.

        Yields individual stores, automatically fetching subsequent pages
        via cursor marks. Equivalent to the JS SDK's storesAsStream().

        Args:
            query: Search query string (e.g., "postalCode=55423").
            show: Optional list of attributes to return.
            page_size: Number of results per page (max 100).

        Yields:
            Individual CatalogStore objects.
        """
        cursor_mark = "*"
        while True:
            request = self._build_search_request(
                query=query,
                show=show,
                page_size=page_size,
                cursor_mark=cursor_mark,
            )
            response = self.client.request(request)
            data = response.json()
            for item_data in data.get("stores", []):
                yield CatalogStore.model_validate(item_data)
            next_cursor = data.get("nextCursorMark")
            if not next_cursor or next_cursor == cursor_mark:
                break
            cursor_mark = next_cursor

    def search_pages(
        self,
        query: Optional[str] = None,
        show: Optional[List[str]] = None,
        page_size: int = 10,
        max_pages: Optional[int] = None,
    ) -> Paginator[CatalogStoresResponse, CatalogStore]:
        """Search for stores with automatic pagination.

        Args:
            query: Search query string (e.g., "postalCode=55423").
            show: Optional list of attributes to return.
            page_size: Number of results per page (max 100).
            max_pages: Maximum number of pages to fetch (None for all).

        Returns:
            Paginator for iterating over pages or stores.
        """

        def fetch_page(page: int) -> CatalogStoresResponse:
            return self.search(
                query=query,
                show=show,
                page=page,
                page_size=page_size,
            )

        return Paginator(
            fetch_page=fetch_page,
            items_attr="stores",
            page_size=page_size,
            max_pages=max_pages,
        )

    def list_pages(
        self,
        show: Optional[List[str]] = None,
        page_size: int = 10,
        max_pages: Optional[int] = None,
    ) -> Paginator[CatalogStoresResponse, CatalogStore]:
        """List all stores with automatic pagination.

        Args:
            show: Optional list of attributes to return.
            page_size: Number of results per page (max 100).
            max_pages: Maximum number of pages to fetch (None for all).

        Returns:
            Paginator for iterating over pages or stores.
        """
        return self.search_pages(
            query=None,
            show=show,
            page_size=page_size,
            max_pages=max_pages,
        )

    def search_by_area_pages(
        self,
        postal_code: Optional[str] = None,
        lat: Optional[float] = None,
        lng: Optional[float] = None,
        distance: int = 10,
        show: Optional[List[str]] = None,
        page_size: int = 10,
        max_pages: Optional[int] = None,
    ) -> Paginator[CatalogStoresResponse, CatalogStore]:
        """Search for stores by area with automatic pagination.

        Args:
            postal_code: ZIP code to search around.
            lat: Latitude to search around (use with lng).
            lng: Longitude to search around (use with lat).
            distance: Search radius in miles (default 10).
            show: Optional list of attributes to return.
            page_size: Number of results per page (max 100).
            max_pages: Maximum number of pages to fetch (None for all).

        Returns:
            Paginator for iterating over pages or stores.
        """
        query = self._build_area_query(postal_code, lat, lng, distance)
        return self.search_pages(
            query=query,
            show=show,
            page_size=page_size,
            max_pages=max_pages,
        )


class AsyncStoreOperations(_StoreOpsBase):
    """Async operations for the Stores API."""

    async def get(
        self,
        store_id: int,
        show: Optional[List[str]] = None,
    ) -> CatalogStore:
        """Get a single store by ID."""
        response = await self.client.request(self._build_get_request(store_id, show))
        return CatalogStore.model_validate(response.json())

    async def search(
        self,
        query: Optional[str] = None,
        show: Optional[List[str]] = None,
        page: int = 1,
        page_size: int = 10,
    ) -> CatalogStoresResponse:
        """Search for stores."""
        response = await self.client.request(
            self._build_search_request(query, show, page, page_size)
        )
        return CatalogStoresResponse.model_validate(response.json())

    async def list(
        self,
        show: Optional[List[str]] = None,
        page: int = 1,
        page_size: int = 10,
    ) -> CatalogStoresResponse:
        """List all stores."""
        return await self.search(
            query=None,
            show=show,
            page=page,
            page_size=page_size,
        )

    async def search_by_area(
        self,
        postal_code: Optional[str] = None,
        lat: Optional[float] = None,
        lng: Optional[float] = None,
        distance: int = 10,
        show: Optional[List[str]] = None,
        page: int = 1,
        page_size: int = 10,
    ) -> CatalogStoresResponse:
        """Search for stores within a specified area."""
        query = self._build_area_query(postal_code, lat, lng, distance)
        return await self.search(
            query=query,
            show=show,
            page=page,
            page_size=page_size,
        )

    async def stream(
        self,
        query: Optional[str] = None,
        show: Optional[List[str]] = None,
        page_size: int = 100,
    ) -> AsyncIterator[CatalogStore]:
        """Stream all matching stores using cursor mark pagination.

        Yields individual stores, automatically fetching subsequent pages
        via cursor marks. Equivalent to the JS SDK's storesAsStream().

        Args:
            query: Search query string (e.g., "postalCode=55423").
            show: Optional list of attributes to return.
            page_size: Number of results per page (max 100).

        Yields:
            Individual CatalogStore objects.
        """
        cursor_mark = "*"
        while True:
            request = self._build_search_request(
                query=query,
                show=show,
                page_size=page_size,
                cursor_mark=cursor_mark,
            )
            response = await self.client.request(request)
            data = response.json()
            for item_data in data.get("stores", []):
                yield CatalogStore.model_validate(item_data)
            next_cursor = data.get("nextCursorMark")
            if not next_cursor or next_cursor == cursor_mark:
                break
            cursor_mark = next_cursor

    def search_pages(
        self,
        query: Optional[str] = None,
        show: Optional[List[str]] = None,
        page_size: int = 10,
        max_pages: Optional[int] = None,
    ) -> AsyncPaginator[CatalogStoresResponse, CatalogStore]:
        """Search for stores with automatic pagination."""

        async def fetch_page(page: int) -> CatalogStoresResponse:
            return await self.search(
                query=query,
                show=show,
                page=page,
                page_size=page_size,
            )

        return AsyncPaginator(
            fetch_page=fetch_page,
            items_attr="stores",
            page_size=page_size,
            max_pages=max_pages,
        )

    def list_pages(
        self,
        show: Optional[List[str]] = None,
        page_size: int = 10,
        max_pages: Optional[int] = None,
    ) -> AsyncPaginator[CatalogStoresResponse, CatalogStore]:
        """List all stores with automatic pagination."""
        return self.search_pages(
            query=None,
            show=show,
            page_size=page_size,
            max_pages=max_pages,
        )

    def search_by_area_pages(
        self,
        postal_code: Optional[str] = None,
        lat: Optional[float] = None,
        lng: Optional[float] = None,
        distance: int = 10,
        show: Optional[List[str]] = None,
        page_size: int = 10,
        max_pages: Optional[int] = None,
    ) -> AsyncPaginator[CatalogStoresResponse, CatalogStore]:
        """Search for stores by area with automatic pagination."""
        query = self._build_area_query(postal_code, lat, lng, distance)
        return self.search_pages(
            query=query,
            show=show,
            page_size=page_size,
            max_pages=max_pages,
        )


class _OpenBoxOpsBase(BaseOperations):
    """Shared request-building logic for the Open Box API (beta)."""

    def _build_list_request(self, page: int = 1, page_size: int = 10):
        return self.client.client.build_request(
            method="GET",
            url="/beta/products/openBox",
            params={
                "apiKey": self.client.options.api_key,
                "format": "json",
                "page": page,
                "pageSize": page_size,
            },
        )

    def _build_get_request(self, sku: int | str):
        return self.client.client.build_request(
            method="GET",
            url=f"/beta/products/{sku}/openBox",
            params={"apiKey": self.client.options.api_key, "format": "json"},
        )

    def _build_search_request(self, query: str, page: int = 1, page_size: int = 10):
        return self.client.client.build_request(
            method="GET",
            url=f"/beta/products/openBox({query})",
            params={
                "apiKey": self.client.options.api_key,
                "format": "json",
                "page": page,
                "pageSize": page_size,
            },
        )


class OpenBoxOperations(_OpenBoxOpsBase):
    """Operations for the Open Box API (beta).

    Open box items are products returned by customers that are sold at a
    discount. Three call shapes are supported, matching the Best Buy JS SDK:

    - ``list()`` -> all open-box items
    - ``get(sku)`` -> open-box offers for a specific SKU
    - ``search(query)`` -> filtered open-box items (e.g. by categoryId)
    """

    def list(self, page: int = 1, page_size: int = 10) -> OpenBoxResponse:
        """List all products currently available as open box.

        Args:
            page: Page number (1-indexed).
            page_size: Number of results per page.

        Returns:
            OpenBoxResponse containing open-box products.
        """
        response = self.client.request(self._build_list_request(page, page_size))
        return OpenBoxResponse.model_validate(response.json())

    def get(self, sku: int | str) -> OpenBoxResponse:
        """Get open-box offers for a specific product.

        Args:
            sku: The Best Buy product SKU.

        Returns:
            OpenBoxResponse containing open-box offers for the given SKU.
        """
        response = self.client.request(self._build_get_request(sku))
        return OpenBoxResponse.model_validate(response.json())

    def search(
        self,
        query: str,
        page: int = 1,
        page_size: int = 10,
    ) -> OpenBoxResponse:
        """Search open-box products with a filter query.

        Args:
            query: Filter expression (e.g. ``"categoryId=abcat0502000"``).
            page: Page number (1-indexed).
            page_size: Number of results per page.

        Returns:
            OpenBoxResponse containing matching open-box products.
        """
        response = self.client.request(
            self._build_search_request(query, page, page_size),
        )
        return OpenBoxResponse.model_validate(response.json())

    def stream(
        self,
        query: Optional[str] = None,
        page_size: int = 10,
    ) -> Iterator[OpenBoxProduct]:
        """Stream all open box products using page-based pagination.

        Yields individual open-box products, automatically fetching
        subsequent pages until all results are returned.

        Args:
            query: Optional filter expression (e.g. ``"categoryId=abcat0502000"``).
            page_size: Number of results per page.

        Yields:
            Individual OpenBoxProduct objects.
        """
        page = 1
        while True:
            if query:
                request = self._build_search_request(query, page, page_size)
            else:
                request = self._build_list_request(page, page_size)
            response = self.client.request(request)
            data = response.json()
            results = data.get("results", [])
            for item_data in results:
                yield OpenBoxProduct.model_validate(item_data)
            if len(results) < page_size:
                break
            page += 1


class AsyncOpenBoxOperations(_OpenBoxOpsBase):
    """Async operations for the Open Box API (beta)."""

    async def list(self, page: int = 1, page_size: int = 10) -> OpenBoxResponse:
        """List all products currently available as open box."""
        response = await self.client.request(
            self._build_list_request(page, page_size),
        )
        return OpenBoxResponse.model_validate(response.json())

    async def get(self, sku: int | str) -> OpenBoxResponse:
        """Get open-box offers for a specific product."""
        response = await self.client.request(self._build_get_request(sku))
        return OpenBoxResponse.model_validate(response.json())

    async def search(
        self,
        query: str,
        page: int = 1,
        page_size: int = 10,
    ) -> OpenBoxResponse:
        """Search open-box products with a filter query."""
        response = await self.client.request(
            self._build_search_request(query, page, page_size),
        )
        return OpenBoxResponse.model_validate(response.json())

    async def stream(
        self,
        query: Optional[str] = None,
        page_size: int = 10,
    ) -> AsyncIterator[OpenBoxProduct]:
        """Stream all open box products using page-based pagination.

        Yields individual open-box products, automatically fetching
        subsequent pages until all results are returned.

        Args:
            query: Optional filter expression (e.g. ``"categoryId=abcat0502000"``).
            page_size: Number of results per page.

        Yields:
            Individual OpenBoxProduct objects.
        """
        page = 1
        while True:
            if query:
                request = self._build_search_request(query, page, page_size)
            else:
                request = self._build_list_request(page, page_size)
            response = await self.client.request(request)
            data = response.json()
            results = data.get("results", [])
            for item_data in results:
                yield OpenBoxProduct.model_validate(item_data)
            if len(results) < page_size:
                break
            page += 1
