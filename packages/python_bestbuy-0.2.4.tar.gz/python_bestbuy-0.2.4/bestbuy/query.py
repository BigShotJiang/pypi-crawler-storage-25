"""Query builder for Best Buy Catalog API search expressions.

Provides a Pythonic DSL for constructing BB's parenthesized query language.
The builder produces strings compatible with the ``query`` parameter on
``search()``, ``stream()``, and ``search_pages()`` methods.

Usage::

    from bestbuy.query import where, search, area

    # Simple comparison
    q = where("manufacturer") == "apple"

    # Chained AND / OR
    q = (where("manufacturer") == "apple") & (where("salePrice") < 1000)
    q = (where("onSale") == True) | (where("freeShipping") == True)

    # IN operator
    q = where("sku").is_in([43900, 2088495])

    # Wildcard / existence check
    q = where("driveCapacityGb").exists()

    # Keyword search
    q = search("laptop")

    # Geo area query (stores)
    q = area("55423", 10)

    # Pass to any search method
    client.products.search(query=str(q))
"""

from typing import Any, Optional, Sequence, Union


def _format_value(value: Any) -> str:
    """Format a Python value for the BB query string."""
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


class Query:
    """Base class for all query expressions."""

    def __and__(self, other: "Query") -> "And":
        return And(self, other)

    def __or__(self, other: "Query") -> "Or":
        return Or(self, other)

    def _render(self, parent_type: Optional[str] = None) -> str:
        """Render to BB query string, with parentheses if needed.

        Args:
            parent_type: ``"and"`` or ``"or"`` if this node is a child
                of a compound expression, ``None`` at top level.
        """
        raise NotImplementedError

    def __str__(self) -> str:
        return self._render()

    def __repr__(self) -> str:
        return f"{type(self).__name__}({str(self)!r})"

    def __bool__(self) -> bool:
        return True


class Condition(Query):
    """A single field comparison (e.g. ``salePrice<1000``)."""

    def __init__(self, field: str, op: str, value: Any) -> None:
        self.field = field
        self.op = op
        self.value = value

    def _render(self, parent_type: Optional[str] = None) -> str:
        return f"{self.field}{self.op}{_format_value(self.value)}"


class InCondition(Query):
    """Set membership test (e.g. ``sku in(43900,2088495)``)."""

    def __init__(self, field: str, values: Sequence[Any]) -> None:
        self.field = field
        self.values = values

    def _render(self, parent_type: Optional[str] = None) -> str:
        formatted = ",".join(_format_value(v) for v in self.values)
        return f"{self.field} in({formatted})"


class SearchCondition(Query):
    """Keyword search (e.g. ``search=laptop&search=stainless``)."""

    def __init__(self, keywords: Sequence[str]) -> None:
        self.keywords = keywords

    def _render(self, parent_type: Optional[str] = None) -> str:
        return "&".join(f"search={kw}" for kw in self.keywords)


class AreaCondition(Query):
    """Geographic area query (e.g. ``area(55423,10)``)."""

    def __init__(self, location: str, distance: Optional[int] = None) -> None:
        self.location = location
        self.distance = distance

    def _render(self, parent_type: Optional[str] = None) -> str:
        if self.distance is not None:
            return f"area({self.location},{self.distance})"
        return f"area({self.location})"


class And(Query):
    """AND combination of two queries (``left&right``).

    Wraps itself in parentheses when nested inside an OR expression,
    matching BB's documented query examples.
    """

    def __init__(self, left: Query, right: Query) -> None:
        self.left = left
        self.right = right

    def _render(self, parent_type: Optional[str] = None) -> str:
        s = f"{self.left._render('and')}&{self.right._render('and')}"
        if parent_type == "or":
            return f"({s})"
        return s


class Or(Query):
    """OR combination of two queries (``left|right``).

    Wraps itself in parentheses when nested inside an AND expression,
    matching BB's documented query examples.
    """

    def __init__(self, left: Query, right: Query) -> None:
        self.left = left
        self.right = right

    def _render(self, parent_type: Optional[str] = None) -> str:
        s = f"{self.left._render('or')}|{self.right._render('or')}"
        if parent_type == "and":
            return f"({s})"
        return s


class Field:
    """A queryable attribute. Returned by :func:`where`.

    Supports comparison operators that produce :class:`Query` objects::

        where("salePrice") < 1000   # Condition("salePrice", "<", 1000)
        where("sku").is_in([1, 2])  # InCondition("sku", [1, 2])
        where("color").exists()     # Condition("color", "=", "*")
    """

    def __init__(self, name: str) -> None:
        self.name = name

    def __eq__(self, value: Any) -> Condition:  # type: ignore[override]
        return Condition(self.name, "=", value)

    def __ne__(self, value: Any) -> Condition:  # type: ignore[override]
        return Condition(self.name, "!=", value)

    def __lt__(self, value: Any) -> Condition:
        return Condition(self.name, "<", value)

    def __gt__(self, value: Any) -> Condition:
        return Condition(self.name, ">", value)

    def __le__(self, value: Any) -> Condition:
        return Condition(self.name, "<=", value)

    def __ge__(self, value: Any) -> Condition:
        return Condition(self.name, ">=", value)

    def is_in(self, values: Sequence[Any]) -> InCondition:
        """Test membership in a list of values.

        Args:
            values: List of values to test against.

        Returns:
            An InCondition query expression.
        """
        return InCondition(self.name, values)

    def exists(self) -> Condition:
        """Check that the attribute has any value (wildcard ``*``).

        Returns:
            A Condition using the ``*`` wildcard.
        """
        return Condition(self.name, "=", "*")


def where(field_name: str) -> Field:
    """Start building a query condition for the given attribute.

    Args:
        field_name: The BB API attribute name (e.g. ``"salePrice"``,
            ``"categoryPath.name"``).

    Returns:
        A :class:`Field` object supporting comparison operators.
    """
    return Field(field_name)


def search(*keywords: str) -> Union[SearchCondition, And]:
    """Build a keyword search query.

    Multiple keywords are combined with AND logic, matching BB's
    ``search=`` parameter behavior.

    Args:
        keywords: One or more search terms.

    Returns:
        A query expression for keyword search.
    """
    if not keywords:
        raise ValueError("At least one search keyword is required")
    return SearchCondition(keywords)


def area(
    postal_code: Optional[str] = None,
    distance: Optional[int] = None,
    *,
    lat: Optional[float] = None,
    lng: Optional[float] = None,
) -> AreaCondition:
    """Build a geographic area query for the Stores API.

    Provide either ``postal_code`` or ``lat``/``lng`` coordinates.

    Args:
        postal_code: ZIP code to search around.
        distance: Search radius in miles.
        lat: Latitude (keyword-only).
        lng: Longitude (keyword-only).

    Returns:
        An AreaCondition query expression.
    """
    if postal_code:
        return AreaCondition(str(postal_code), distance)
    if lat is not None and lng is not None:
        return AreaCondition(f"{lat},{lng}", distance)
    raise ValueError("Either postal_code or lat/lng must be provided")
