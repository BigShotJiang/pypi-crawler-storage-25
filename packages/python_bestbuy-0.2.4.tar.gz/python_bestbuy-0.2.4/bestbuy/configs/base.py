import logging
from typing import Dict

from pydantic import BaseModel, ConfigDict


class BaseConfig(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    api_key: str
    base_url: str | None = None
    content_type: str | None = None
    headers: Dict[str, str] | None = None
    log_level: int = logging.WARNING
    logger: logging.Logger | None = None
    max_retries: int = 0
    requests_per_second: int = 5
    retry_interval_ms: int = 2000
    timeout_ms: int = 60_000
