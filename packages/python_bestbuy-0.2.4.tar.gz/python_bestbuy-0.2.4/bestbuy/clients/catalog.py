from importlib.metadata import PackageNotFoundError, version as _pkg_version
from typing import Any, Dict

import httpx

from ..configs import CatalogConfig
from ..models import VersionInfo
from ..operations.catalog import (
    AsyncCategoryOperations,
    AsyncOpenBoxOperations,
    AsyncProductOperations,
    AsyncRecommendationOperations,
    AsyncStoreOperations,
    CategoryOperations,
    OpenBoxOperations,
    ProductOperations,
    RecommendationOperations,
    StoreOperations,
)
from .base import AsyncClient, Client


def _package_version() -> str:
    """Return the installed bestbuy package version, or 'unknown'."""
    try:
        return _pkg_version("bestbuy")
    except PackageNotFoundError:
        return "unknown"


def _build_version_request(client_obj):  # type: ignore[no-untyped-def]
    """Build the /version.txt request (shared by sync and async clients)."""
    return client_obj.client.build_request(
        method="GET",
        url="/version.txt",
        params={"apiKey": client_obj.options.api_key},
    )


class CatalogClient(Client):
    """Synchronous client for the Best Buy Catalog API."""

    config_parser = CatalogConfig

    def __init__(
        self,
        client: httpx.Client | None = None,
        options: Dict[str, Any] | CatalogConfig | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(client, options, **kwargs)
        self.products = ProductOperations(self)
        self.categories = CategoryOperations(self)
        self.recommendations = RecommendationOperations(self)
        self.stores = StoreOperations(self)
        self.openbox = OpenBoxOperations(self)

    def version(self) -> VersionInfo:
        """Get the Best Buy API version and installed package version.

        Matches the ``version()`` helper from the Best Buy JavaScript SDK:
        fetches plain-text ``/version.txt`` from the API and combines it
        with the installed ``bestbuy`` package version.
        """
        response = self.request(_build_version_request(self))
        return VersionInfo(
            api_version=response.text.strip(),
            package_version=_package_version(),
        )

    @property
    def base_url(self):
        if self.options.base_url is not None:
            return self.options.base_url
        return "https://api.bestbuy.com"


class AsyncCatalogClient(AsyncClient):
    """Asynchronous client for the Best Buy Catalog API."""

    config_parser = CatalogConfig

    def __init__(
        self,
        client: httpx.AsyncClient | None = None,
        options: Dict[str, Any] | CatalogConfig | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(client, options, **kwargs)
        self.products = AsyncProductOperations(self)
        self.categories = AsyncCategoryOperations(self)
        self.recommendations = AsyncRecommendationOperations(self)
        self.stores = AsyncStoreOperations(self)
        self.openbox = AsyncOpenBoxOperations(self)

    async def version(self) -> VersionInfo:
        """Get the Best Buy API version and installed package version."""
        response = await self.request(_build_version_request(self))
        return VersionInfo(
            api_version=response.text.strip(),
            package_version=_package_version(),
        )

    @property
    def base_url(self):
        if self.options.base_url is not None:
            return self.options.base_url
        return "https://api.bestbuy.com"
