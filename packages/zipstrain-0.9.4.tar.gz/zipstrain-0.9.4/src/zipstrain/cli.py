"""
zipstrain.utils
========================
This module contains the command-line interface (CLI) implementation for the zipstrain application.
"""
import click as click
from zipstrain import __version__
import zipstrain.utils as ut
import zipstrain.compare as cp
import zipstrain.profile as pf
import zipstrain.task_manager as tm
import zipstrain.database as db
import zipstrain.build_db as bdb
import zipstrain.matrix_pairs as mp
import polars as pl
import pathlib
import sys
import time
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box
from rich.progress import Progress, BarColumn, TextColumn, TimeElapsedColumn, SpinnerColumn, TaskProgressColumn


@click.group()
@click.version_option(version=__version__, prog_name="zipstrain")
def cli():
    """ZipStrain CLI"""
    pass

@cli.group()
def utilities():
    """The commands in this group are related to various utility functions that mainly prepare input files for profiling and comparison."""
    pass


def _emit_stderr_log(prefix: str, **fields: object) -> None:
    payload = " ".join(f"{key}={value}" for key, value in fields.items())
    click.echo(f"{prefix} {payload}".rstrip(), err=True)
    sys.stderr.flush()


class _ThrottledMatrixLogger:
    def __init__(self, prefix: str, detail_formatter):
        self.prefix = prefix
        self.detail_formatter = detail_formatter
        self.last_percent_bucket = -1
        self.last_log_time = 0.0
        self.logged_advance = False

    def __call__(self, event: dict[str, object]) -> None:
        phase = str(event.get("phase", ""))
        completed = int(event.get("completed", 0))
        total = int(event.get("total", 0))
        now = time.monotonic()

        if phase in {"start", "done"}:
            self.last_percent_bucket = -1 if total <= 0 else int((completed / max(total, 1)) * 100) // 5
            self.last_log_time = now
            if phase == "start":
                self.logged_advance = False
            _emit_stderr_log(
                f"{self.prefix} {phase.upper()}",
                completed=completed,
                total=total,
                **self.detail_formatter(event),
            )
            return

        if phase != "advance":
            return

        percent_bucket = int((completed / max(total, 1)) * 100) // 5 if total > 0 else 0
        should_log = (
            (not self.logged_advance)
            or
            total <= 20
            or completed == total
            or percent_bucket > self.last_percent_bucket
            or (now - self.last_log_time) >= 5.0
        )
        if not should_log:
            return

        self.logged_advance = True
        self.last_percent_bucket = percent_bucket
        self.last_log_time = now
        _emit_stderr_log(
            f"{self.prefix} PROGRESS",
            completed=completed,
            total=total,
            percent=f"{(completed / max(total, 1)) * 100:.1f}" if total > 0 else "0.0",
            **self.detail_formatter(event),
        )

@utilities.command("build-null-model")
@click.option('--error-rate', '-e', default=0.001, help="Error rate for the sequencing technology.")
@click.option('--max-total-reads', '-m', default=10000, help="Maximum coverage to consider for a base")
@click.option('--p-threshold', '-p', default=0.05, help="Significance threshold for the Poisson distribution.")
@click.option('--output-file', '-o', required=True, help="Path to save the output Parquet file.")
@click.option('--model-type', '-t', default="poisson", type=click.Choice(['poisson']), help="Type of null model to build.")
def build_null_model(error_rate, max_total_reads, p_threshold, output_file, model_type):
    """
    Build a null model for sequencing errors based on the Poisson distribution.

    Args:
    error_rate (float): Error rate for the sequencing technology.
    max_total_reads (int): Maximum total reads to consider.
    p_threshold (float): Significance threshold for the Poisson distribution.
    """
    if model_type == "poisson":
        df_thresh = ut.build_null_poisson(error_rate, max_total_reads, p_threshold)
    else:
        raise ValueError(f"Unsupported model type: {model_type}")
    df_thresh = pl.DataFrame(df_thresh, schema=["cov", "max_error_count"])
    df_thresh.write_parquet(output_file)

@utilities.command("merge_parquet")
@click.option('--input-dir', '-i', required=True, help="Directory containing Parquet files to merge.") 
@click.option('--output-file', '-o', required=True, help="Path to save the merged Parquet file.")
@click.option(
    '--batch-size',
    type=int,
    default=-1,
    show_default=True,
    help="Number of parquet files to merge per stage. Use -1 for the current single-pass behavior.",
)
def merge_parquet(input_dir, output_file, batch_size):
    """
    Merge multiple Parquet files in a directory into a single Parquet file.

    Args:
    input_dir (str): Directory containing Parquet files to merge.
    output_file (str): Path to save the merged Parquet file.
    batch_size (int): Maximum number of parquet files to merge per staged batch.
    """
    def _emit_progress(message: str) -> None:
        click.echo(message, err=True)
        sys.stderr.flush()

    ut.merge_parquet_files(
        input_dir=input_dir,
        output_file=output_file,
        batch_size=batch_size,
        progress_callback=_emit_progress,
    )


@utilities.command("adjust-sequence-errors")
@click.option('--profile-parquet', '-p', required=True, help="Input profile parquet file.")
@click.option('--null-model', '-n', required=True, help="Null model parquet file.")
@click.option('--output-file', '-o', required=True, help="Path to save the sequence-adjusted profile parquet.")
def adjust_sequence_errors(profile_parquet, null_model, output_file):
    """
    Apply ZipStrain's sequence-error adjustment to an existing profile parquet.

    The output preserves the input column order and drops temporary columns used
    during the adjustment.
    """
    try:
        pf.adjust_profile_parquet_for_sequence_errors(
            profile_parquet=pathlib.Path(profile_parquet),
            null_model_parquet=pathlib.Path(null_model),
            output_file=pathlib.Path(output_file),
        )
    except ValueError as exc:
        raise click.UsageError(str(exc)) from exc


@utilities.command("process_mpileup")
@click.option('--batch-size', '-s', default=10000, help="Buffer size for processing stdin from samtools.")
@click.option('--output-file', '-o', required=True, help="Location to save the output Parquet file.")
def process_mpileup(batch_size, output_file):
    """
    Process mpileup files and save the results in a Parquet file.

    Args:
    gene_range_table_loc (str): Path to the gene range table in TSV format.
    batch_bed (str): Path to the batch BED file.
    output_file (str): Path to save the output Parquet file.
    """
    ut.process_mpileup_function(batch_size, output_file)
    
@utilities.command("make_bed")
@click.option('--db-fasta-dir', '-d', required=True, help="Path to the database in fasta format.")
@click.option('--max-scaffold-length', '-m', default=500000, help="Maximum scaffold length to split into multiple entries.")
@click.option('--output-file', '-o', required=True, help="Path to save the output BED file.")
def make_bed(db_fasta_dir, max_scaffold_length, output_file):
    """
    Create a BED file from the database in fasta format.

    Args:
    db_fasta_dir (str): Path to the fasta file.
    max_scaffold_length (int): Splits scaffolds longer than this into multiple entries of length <= max_scaffold_length.
    output_file (str): Path to save the output BED file.
    """
    bed_df = ut.make_the_bed(db_fasta_dir, max_scaffold_length)
    bed_df.write_csv(output_file, separator='\t', include_header=False)

@utilities.command("get_genome_lengths")
@click.option('--stb-file', '-s', required=True, help="Path to the scaffold-to-genome mapping file.")
@click.option('--bed-file', '-b', required=True, help="Path to the BED file.")
@click.option('--output-file', '-o', required=True, help="Path to save the output Parquet file.")
def get_genome_lengths(stb_file, bed_file, output_file):
    """
    Extract the genome length information from the scaffold-to-genome mapping table.

    Args:
    stb_file (str): Path to the scaffold-to-genome mapping file.
    bed_file (str): Path to the BED file containing genomic regions.
    output_file (str): Path to save the output Parquet file.
    """
    stb = pl.scan_csv(stb_file, separator='\t',has_header=False).with_columns(
        pl.col("column_1").alias("scaffold"),
        pl.col("column_2").alias("genome")
    )
    
    bed_table = pl.scan_csv(bed_file, separator='\t',has_header=False).with_columns(
        pl.col("column_1").alias("scaffold"),
        pl.col("column_2").cast(pl.Int64).alias("start"),
        pl.col("column_3").cast(pl.Int64).alias("end")
    ).select(["scaffold", "start", "end"])
    genome_length = ut.extract_genome_length(stb, bed_table)
    genome_length.sink_parquet(output_file, compression='zstd')

@utilities.command("merge-stat-tables")
@click.option('--stat-table', '-s', multiple=True, required=True, help="Stat parquet file to include. Repeat for multiple files.")
@click.option('--output-file', '-o', required=True, help="Path to save the merged stat table.")
def merge_stat_tables(stat_table, output_file):
    """
    Concatenate stat tables and add a sample column inferred from each file name.
    """
    def _emit_progress(message: str) -> None:
        click.echo(message, err=True)
        sys.stderr.flush()

    ut.merge_stat_tables(
        stat_tables=list(stat_table),
        output_file=output_file,
        progress_callback=_emit_progress,
    )


@utilities.command("get-coverage-stats")
@click.option('--profile-parquet', '-p', required=True, help="Classic profile parquet file.")
@click.option('--gene-bed', '-g', required=True, help="Gene BED/range file. Supports 4 columns (gene, scaffold, start, end) or 5 columns (+ genome).")
@click.option('--genome-bed', '-b', required=True, help="Genome BED file. Supports 3 columns (scaffold, start, end) or 4 columns (+ genome).")
@click.option('--output-dir', '-o', required=True, help="Directory to write the gene/genome stats parquet files.")
@click.option('--prefix', required=True, help="Prefix for the output files.")
def get_coverage_stats(profile_parquet, gene_bed, genome_bed, output_dir, prefix):
    """
    Build coverage-only gene and genome stats from an existing profile parquet.
    """
    summary = ut.get_coverage_stats(
        profile_parquet=profile_parquet,
        gene_bed_file=gene_bed,
        genome_bed_file=genome_bed,
        output_dir=output_dir,
        prefix=prefix,
    )
    click.echo(
        f"gene_stats={summary['gene_stats_file']} "
        f"genome_stats={summary['genome_stats_file']} "
        f"gene_rows={summary['gene_rows']} "
        f"genome_rows={summary['genome_rows']} "
        f"cov_sites_column={summary['cov_sites_column']}"
    )


@utilities.command("generate-genome-pairs")
@click.option('--profile-dir', '-p', required=True, help="Directory containing classic ZipStrain profile parquets.")
@click.option('--output-file', '-o', required=True, help="Output parquet file with all non-redundant profile pairs.")
@click.option('--write-batch-size', type=int, default=100000, show_default=True, help="How many pairs to buffer before writing a parquet row group.")
def generate_genome_pairs(profile_dir, output_file, write_batch_size):
    """Generate a pair table ready for chunk-genome-compare or other compare utilities."""
    def _emit_progress(message: str) -> None:
        click.echo(message, err=True)
        sys.stderr.flush()

    summary = ut.generate_genome_pairs(
        profile_dir=profile_dir,
        output_file=output_file,
        write_batch_size=write_batch_size,
        progress_callback=_emit_progress,
    )
    click.echo(
        f"wrote={summary['output_file']} "
        f"profiles={summary['profiles']} "
        f"pairs={summary['pairs']}"
    )


@utilities.command("chunk-genome-compare")
@click.option('--pair-table', '-p', required=True, help="Pair table parquet/csv/tsv with profile locations.")
@click.option('--stb-file', '-s', required=True, help="Path to the scaffold-to-genome mapping file.")
@click.option('--output-file', '-o', required=True, help="Path to save the merged genome comparison parquet.")
@click.option('--workers', '-w', type=int, default=None, help="Parallel workers inside this compare chunk. Defaults to CPU count capped by pair count.")
@click.option('--min-cov', '-c', default=5, show_default=True, help="Minimum coverage to consider a position.")
@click.option('--min-gene-compare-len', '-l', default=100, show_default=True, help="Minimum gene length to consider for comparison.")
@click.option('--genome', '-g', default="all", show_default=True, help="Optional genome scope.")
@click.option('--ani-method', '-a', default="popani", show_default=True, help="ANI calculation method to use.")
@click.option('--calculate', default="all", show_default=True, help="Genome metrics to compute: ani, ibs, identical_genes. Combine with '+', or use all.")
@click.option('--engine', type=click.Choice(["polars", "duckdb"]), default="polars", show_default=True, help="Execution engine for compare.")
@click.option('--duckdb-memory-limit', default=None, help="DuckDB memory limit (for scoped filtering or duckdb engine).")
@click.option('--duckdb-temp-directory', default=None, help="Directory DuckDB can use for spill files.")
@click.option('--duckdb-threads', type=int, default=None, help="Number of DuckDB worker threads.")
def chunk_genome_compare(pair_table, stb_file, output_file, workers, min_cov, min_gene_compare_len, genome, ani_method, calculate, engine, duckdb_memory_limit, duckdb_temp_directory, duckdb_threads):
    """Run classic genome compare over one pair-table chunk using Python-side parallel workers."""
    def _emit_progress(message: str) -> None:
        click.echo(message, err=True)
        sys.stderr.flush()

    summary = ut.chunk_genome_compare(
        pair_table=pair_table,
        output_file=output_file,
        stb_file=stb_file,
        workers=workers,
        min_cov=min_cov,
        min_gene_compare_len=min_gene_compare_len,
        genome_scope=genome,
        ani_method=ani_method,
        calculate=calculate,
        engine=engine,
        duckdb_memory_limit=duckdb_memory_limit,
        duckdb_temp_directory=duckdb_temp_directory,
        duckdb_threads=duckdb_threads,
        progress_callback=_emit_progress,
    )
    click.echo(
        f"wrote={summary['output_file']} "
        f"pairs={summary['pairs']} "
        f"rows={summary['rows']} "
        f"workers={summary['workers']} "
        f"elapsed_s={summary['elapsed_seconds']:.2f} "
        f"avg_wall_s_per_pair={summary['avg_wall_seconds_per_pair']:.4f} "
        f"avg_compute_s_per_pair={summary['avg_compute_seconds_per_pair']:.4f} "
        f"avg_s_per_genome_row={summary['avg_seconds_per_genome_row']:.4f} "
        f"avg_genome_rows_per_pair={summary['avg_genome_rows_per_pair']:.2f}"
    )
    
@utilities.command("strain_heterogeneity")
@click.option('--profile-file', '-p', required=True, help="Path to the profile Parquet file.")
@click.option('--stb-file', '-s', required=True, help="Path to the scaffold-to-genome mapping file.")
@click.option('--min-cov', '-c', default=5, help="Minimum coverage to consider a position.")
@click.option('--freq-threshold', '-f', default=0.8, help="Frequency threshold to define dominant nucleotide.")
@click.option('--output-file', '-o', required=True, help="Path to save the output Parquet file.")
def strain_heterogeneity(profile_file, stb_file, min_cov, freq_threshold, output_file):
    """
    Calculate strain heterogeneity for each genome based on nucleotide frequencies.

    Args:
    profile_file (str): Path to the profile Parquet file.
    stb_file (str): Path to the scaffold-to-genome mapping file.
    min_cov (int): Minimum coverage to consider a position.
    freq_threshold (float): Frequency threshold to define dominant nucleotide.
    output_file (str): Path to save the output Parquet file.
    """
    profile = pl.scan_parquet(profile_file)
    stb = pl.scan_csv(stb_file, separator="\t", has_header=False).with_columns(
        pl.col("column_1").alias("scaffold"),
        pl.col("column_2").alias("genome")
    ).select(["scaffold", "genome"])
    
    het_profile = pf.get_strain_hetrogeneity(profile, stb, min_cov=min_cov, freq_threshold=freq_threshold)
    het_profile.sink_parquet(output_file, compression='zstd')

@utilities.command("build-profile-db")
@click.option('--profile-db-csv', '-p', required=True, help="Path to the profile database CSV file.")
@click.option('--output-file', '-o', required=True, help="Path to save the output Parquet file.")
def build_profile_db(profile_db_csv, output_file):
    """
    Build a profile database from the given CSV file.

    Args:
    profile_db_csv (str): Path to the profile database CSV file.
    """
    profile_db = db.ProfileDatabase.from_csv(pathlib.Path(profile_db_csv))
    profile_db.save_as_new_database(pathlib.Path(output_file))


@utilities.command("build-matrix-db")
@click.option('--profile-dir', '-p', required=True, help="Directory containing classic ZipStrain profile parquets.")
@click.option('--output-file', '-o', required=True, help="Output DuckDB matrix database.")
@click.option('--genome', '-g', default="all", show_default=True, help="Optional genome scope.")
@click.option('--bed-file', '-b', default=None, help="Optional BED file to define scaffold extents instead of inferring min/max positions from profiles.")
@click.option(
    '--count-dtype',
    type=click.Choice(sorted(mp.COUNT_DTYPES.keys())),
    default="uint16",
    show_default=True,
    help="Stored dtype for whole-genome matrix blobs.",
)
@click.option(
    '--memory-limit-gb',
    type=float,
    default=16.0,
    show_default=True,
    help="Approximate maximum memory budget for the entire matrix build process.",
)
def build_matrix_db(profile_dir, output_file, genome, bed_file, count_dtype, memory_limit_gb):
    """
    Build an experimental DuckDB database of per-sample, per-genome dense matrices.

    Each genome is stored on one whole-genome axis inferred from the selected
    scaffolds, with one synthetic zero separator row inserted between
    scaffolds of the same genome. Each stored matrix is shaped positions x 4
    (A/T/C/G) and is intended for the experimental matrix compare utilities.
    """
    progress_console = Console(stderr=True)
    use_progress_bar = sys.stderr.isatty()

    if use_progress_bar:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            TextColumn("{task.completed}/{task.total}"),
            TextColumn("stored={task.fields[stored_rows]}"),
            TimeElapsedColumn(),
            console=progress_console,
            transient=True,
        ) as progress:
            task_id = progress.add_task(
                "Building matrix DB",
                total=1,
                completed=0,
                stored_rows="0",
            )

            def _progress_callback(event: dict[str, object]) -> None:
                total = int(event.get("total", 0)) or 1
                completed = int(event.get("completed", 0))
                stored_rows = str(event.get("stored_rows", 0))
                progress.update(
                    task_id,
                    total=total,
                    completed=completed,
                    stored_rows=stored_rows,
                )

            summary = mp.build_matrix_db(
                profile_dir=pathlib.Path(profile_dir),
                output_file=pathlib.Path(output_file),
                genome=genome,
                bed_file=pathlib.Path(bed_file) if bed_file is not None else None,
                count_dtype=count_dtype,
                memory_limit_gb=memory_limit_gb,
                progress_callback=_progress_callback,
            )
    else:
        progress_logger = _ThrottledMatrixLogger(
            "MATRIX-BUILD",
            lambda event: {"stored_rows": event.get("stored_rows", 0)},
        )
        summary = mp.build_matrix_db(
            profile_dir=pathlib.Path(profile_dir),
            output_file=pathlib.Path(output_file),
            genome=genome,
            bed_file=pathlib.Path(bed_file) if bed_file is not None else None,
            count_dtype=count_dtype,
            memory_limit_gb=memory_limit_gb,
            progress_callback=progress_logger,
        )
    click.echo(
        f"wrote={summary.output_file} "
        f"samples={summary.sample_count} "
        f"scaffolds={summary.scaffold_count} "
        f"stored_rows={summary.stored_rows}"
    )


@utilities.command("matrix-compare")
@click.option('--matrix-db-file', '-m', required=True, help="Input DuckDB matrix database from build-matrix-db.")
@click.option('--output-file', '-o', required=True, help="Output ANI parquet file.")
@click.option('--min-cov', '-c', default=5, show_default=True, help="Minimum site coverage required in both samples.")
@click.option('--genome', '-g', default="all", show_default=True, help="Optional genome scope.")
@click.option('--memory-limit-gb', type=float, default=16.0, show_default=True, help="Approximate memory budget for compare.")
@click.option('--position-tile-size', type=int, default=None, help="Optional override for positions processed per genome tile.")
@click.option('--calculate', default="all", show_default=True, help="Matrix metrics to compute: ani or ani+ibs. 'all' currently means ani+ibs.")
@click.option(
    '--backend',
    type=click.Choice(mp.MATRIX_PAIR_BACKENDS),
    default="numpy",
    show_default=True,
    help="Compute backend. Torch backends use CPU/CUDA/MPS depending on selection.",
)
def matrix_compare(matrix_db_file, output_file, min_cov, genome, memory_limit_gb, position_tile_size, calculate, backend):
    """
    Run experimental genome-level matrix compare on all non-redundant, non-self sample pairs.

    This command generates all unique sample pairs from the matrix DB, groups
    them by anchor sample, materializes one anchor genome matrix plus as many
    target genome matrices as fit the memory budget, and writes genome-level
    ANI or ANI+IBS rows.
    """
    progress_console = Console(stderr=True)
    use_progress_bar = sys.stderr.isatty()

    if use_progress_bar:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            TextColumn("{task.completed}/{task.total}"),
            TextColumn("chunks={task.fields[target_chunks]}"),
            TimeElapsedColumn(),
            console=progress_console,
            transient=True,
        ) as progress:
            task_id = progress.add_task(
                "Comparing matrix DB",
                total=1,
                completed=0,
                target_chunks="0",
            )

            def _progress_callback(event: dict[str, object]) -> None:
                total = int(event.get("total", 0)) or 1
                completed = int(event.get("completed", 0))
                target_chunks = str(event.get("target_chunks", 0))
                progress.update(
                    task_id,
                    total=total,
                    completed=completed,
                    target_chunks=target_chunks,
                )

            summary = mp.matrix_compare(
                matrix_db_file=pathlib.Path(matrix_db_file),
                output_file=pathlib.Path(output_file),
                min_cov=min_cov,
                genome=genome,
                memory_limit_gb=memory_limit_gb,
                position_tile_size=position_tile_size,
                backend=backend,
                calculate=calculate,
                progress_callback=_progress_callback,
            )
    else:
        progress_logger = _ThrottledMatrixLogger(
            "MATRIX-COMPARE",
            lambda event: {"target_chunks": event.get("target_chunks", 0)},
        )
        summary = mp.matrix_compare(
            matrix_db_file=pathlib.Path(matrix_db_file),
            output_file=pathlib.Path(output_file),
            min_cov=min_cov,
            genome=genome,
            memory_limit_gb=memory_limit_gb,
            position_tile_size=position_tile_size,
            backend=backend,
            calculate=calculate,
            progress_callback=progress_logger,
        )
    click.echo(
        f"wrote={summary.output_file} "
        f"requested_pairs={summary.requested_pairs} "
        f"rows={summary.written_rows} "
        f"scaffolds={summary.scaffold_count} "
        f"anchor_groups={summary.anchor_groups} "
        f"target_chunks={summary.target_chunks}"
    )


@utilities.command("build-genome-db")
@click.option('--tool', '-t', required=True, type=click.Choice(sorted(bdb.ADAPTERS.keys())), help="Abundance tool format to parse (for example, sylph).")
@click.option('--abundance-table', '-a', required=True, help="Path to abundance table (csv/tsv/parquet).")
@click.option('--cache-dir', '-c', required=True, help="Genome cache directory. Reuses already-downloaded genomes.")
@click.option('--output-dir', '-o', required=True, help="Directory where concatenated reference FASTA and STB are written.")
@click.option('--download-retries', type=int, default=8, show_default=True, help="Max download attempts per genome before skipping.")
@click.option('--retry-backoff-seconds', type=float, default=10.0, show_default=True, help="Base seconds for exponential retry backoff.")
@click.option('--download-workers', type=int, default=1, show_default=True, help="Parallel genome download workers.")
def build_genome_db(tool, abundance_table, cache_dir, output_dir, download_retries, retry_backoff_seconds, download_workers):
    """
    Build a reference bundle from an abundance table.

    This command extracts genomes with non-zero abundance in at least one sample,
    reuses/downloads them via a local cache directory, and writes:
      - reference_genomes.fna
      - reference_genomes.stb
    into the output directory.
    """
    if download_retries < 1:
        raise ValueError("--download-retries must be >= 1")
    if retry_backoff_seconds < 0:
        raise ValueError("--retry-backoff-seconds must be >= 0")
    if download_workers < 1:
        raise ValueError("--download-workers must be >= 1")

    console = Console()
    progress_callback = None
    if console.is_terminal:
        progress = Progress(
            TextColumn("[bold cyan]Genome Cache"),
            BarColumn(),
            TextColumn("{task.completed}/{task.total} processed"),
            TextColumn("remaining: {task.fields[remaining]}"),
            TextColumn("{task.fields[last_event]}"),
            TimeElapsedColumn(),
            console=console,
            transient=True,
        )
        progress_state = {"task_id": None}

        def _progress_callback(event: str, fetched: int, remaining: int, total: int, accession: str | None) -> None:
            total_display = max(total, 1)
            if event == "downloaded":
                last_event = f"downloaded {accession}"
            elif event == "failed":
                last_event = f"failed {accession}"
            elif event == "already_present":
                last_event = f"cached {accession}"
            elif event == "retry":
                last_event = f"retrying {accession}"
            elif event == "done":
                last_event = "downloads complete"
            elif event == "assembling_reference":
                last_event = "building concatenated reference"
            elif event == "completed":
                last_event = "done"
            else:
                last_event = "starting"

            if progress_state["task_id"] is None:
                progress_state["task_id"] = progress.add_task(
                    "genomes",
                    total=total_display,
                    completed=min(fetched, total_display),
                    remaining=max(remaining, 0),
                    last_event=last_event,
                )
            else:
                progress.update(
                    progress_state["task_id"],
                    total=total_display,
                    completed=min(fetched, total_display),
                    remaining=max(remaining, 0),
                    last_event=last_event,
                )

        progress_callback = _progress_callback
        with progress:
            out_fasta, out_stb, extracted, report, summary = bdb.build_reference_from_abundance(
                tool_name=tool,
                abundance_table=pathlib.Path(abundance_table),
                cache_dir=pathlib.Path(cache_dir),
                output_dir=pathlib.Path(output_dir),
                progress_callback=progress_callback,
                max_download_attempts=download_retries,
                backoff_base_seconds=retry_backoff_seconds,
                download_workers=download_workers,
            )
    else:
        out_fasta, out_stb, extracted, report, summary = bdb.build_reference_from_abundance(
            tool_name=tool,
            abundance_table=pathlib.Path(abundance_table),
            cache_dir=pathlib.Path(cache_dir),
            output_dir=pathlib.Path(output_dir),
            max_download_attempts=download_retries,
            backoff_base_seconds=retry_backoff_seconds,
            download_workers=download_workers,
        )
    failed_rows = report.filter(pl.col("status") == "failed") if report.height else report
    rate_limited_failures = (
        failed_rows.filter(pl.col("error").fill_null("").str.contains("Too Many Requests", literal=True)).height
        if failed_rows.height
        else 0
    )
    report_file = pathlib.Path(output_dir) / "genome_db_build_report.txt"
    report_lines = [
        "Genome DB Build Report",
        f"Tool: {tool}",
        f"Selected genomes (non-zero): {summary['selected_genomes']}",
        f"Cached before run: {summary['cached_before_download']}",
        f"Download attempts (new): {summary['attempted_downloads']}",
        f"Downloaded now: {summary['downloaded_now']}",
        f"Failed downloads: {summary['failed_downloads']}",
        f"Skipped after retries: {summary['missing_after_retries']}",
        f"Retry attempts/genome: {download_retries}",
        f"Retry backoff base (s): {retry_backoff_seconds}",
        f"Download workers: {download_workers}",
        f"Available in cache after run: {summary['cached_after_download']}",
        f"Concatenated FASTA: {out_fasta}",
        f"STB file: {out_stb}",
        f"Cache directory: {pathlib.Path(cache_dir)}",
        "",
        f"Failed IDs ({failed_rows.height}):",
    ]
    if failed_rows.height == 0:
        report_lines.append("- none")
    else:
        for row in failed_rows.select("accession", "error").iter_rows(named=True):
            error = row["error"] if row["error"] not in (None, "") else "no error message"
            report_lines.append(f"- {row['accession']}: {error}")
    if rate_limited_failures > 0:
        report_lines.extend(
            [
                "",
                "Rate-limit hint:",
                "- Reduce --download-workers (for example, 1-2)",
                "- Increase --download-retries (for example, 8)",
                "- Increase --retry-backoff-seconds (for example, 10-20)",
            ]
        )
    report_file.write_text("\n".join(report_lines) + "\n")
    report_table = Table(box=box.SIMPLE_HEAVY, show_header=False, pad_edge=False)
    report_table.add_column("metric", style="bold cyan")
    report_table.add_column("value", style="white")
    report_table.add_row("Tool", tool)
    report_table.add_row("Selected genomes (non-zero)", str(summary["selected_genomes"]))
    report_table.add_row("Cached before run", str(summary["cached_before_download"]))
    report_table.add_row("Download attempts (new)", str(summary["attempted_downloads"]))
    report_table.add_row("Downloaded now", str(summary["downloaded_now"]))
    report_table.add_row("Failed downloads", str(summary["failed_downloads"]))
    report_table.add_row("Skipped after retries", str(summary["missing_after_retries"]))
    report_table.add_row("Retry attempts/genome", str(download_retries))
    report_table.add_row("Retry backoff base (s)", str(retry_backoff_seconds))
    report_table.add_row("Download workers", str(download_workers))
    report_table.add_row("Available in cache after run", str(summary["cached_after_download"]))
    if rate_limited_failures > 0:
        report_table.add_row("Rate-limited failures", str(rate_limited_failures))
    report_table.add_row("Concatenated FASTA", str(out_fasta))
    report_table.add_row("STB file", str(out_stb))
    report_table.add_row("Cache directory", str(pathlib.Path(cache_dir)))
    report_table.add_row("Report file", str(report_file))
    Console().print(Panel(report_table, title="Genome DB Build Report", border_style="green"))


@utilities.command("build-genome-comparison-config")
@click.option('--profile-db', '-p', required=True, help="Path to the profile database Parquet file.")
@click.option('--gene-db-id', '-g', required=True, help="Gene database ID.")
@click.option('--reference-genome-id', '-r', required=True, help="Reference fasta ID.")
@click.option('--scope', '-s', default="all", help="Genome scope for comparison.")
@click.option('--min-cov', '-c', default=5, help="Minimum coverage to consider a position.")
@click.option('--min-gene-compare-len', '-l', default=200, help="Minimum gene length to consider for comparison.")
@click.option('--stb-file-loc', '-t', required=True, help="Path to the scaffold-to-genome mapping file.")
@click.option('--current-comp-table', '-a', default=None, help="Path to the current comparison table in Parquet format.")
@click.option('--output-file', '-o', required=True, help="Path to save the output configuration JSON file.")
def build_genome_comparison_config(profile_db, gene_db_id, reference_genome_id, scope, min_cov, min_gene_compare_len, stb_file_loc, current_comp_table, output_file):
    """
    Build a comparison configuration JSON file from the given parameters.

    Args:
    profile_db (str): Path to the profile database Parquet file.
    gene_db_id (str): Gene database ID.
    reference_genome_id (str): Reference genome ID.
    scope (str): Genome scope for comparison.
    min_cov (int): Minimum coverage to consider a position.
    min_gene_compare_len (int): Minimum gene length to consider for comparison.
    stb_file_loc (str): Path to the scaffold-to-genome mapping file.
    current_comp_table (str): Path to the current comparison table in Parquet format.
    output_file (str): Path to save the output configuration JSON file.
    """
    conf_obj=db.GenomeComparisonConfig(
        gene_db_id=gene_db_id,
        reference_id=reference_genome_id,
        scope=scope,
        min_cov=min_cov,
        min_gene_compare_len=min_gene_compare_len,
        stb_file_loc=stb_file_loc,
    )
    profile_db=db.ProfileDatabase(profile_db)
    comp_obj=db.GenomeComparisonDatabase(
        profile_db=profile_db,
        config=conf_obj,
        comp_db_loc=current_comp_table
    )
    comp_obj.dump_obj(pathlib.Path(output_file))


@utilities.command("build-gene-comparison-config")
@click.option('--profile-db', '-p', required=True, help="Path to the profile database Parquet file.")
@click.option('--gene-db-id', '-g', required=True, help="Gene database ID.")
@click.option('--reference-genome-id', '-r', required=True, help="Reference fasta ID.")
@click.option('--scope', '-s', default="all:all", help="Genome scope for comparison.")
@click.option('--min-cov', '-c', default=5, help="Minimum coverage to consider a position.")
@click.option('--min-gene-compare-len', '-l', default=200, help="Minimum gene length to consider for comparison.")
@click.option('--stb-file-loc', '-t', required=True, help="Path to the scaffold-to-genome mapping file.")
@click.option('--current-comp-table', '-a', default=None, help="Path to the current comparison table in Parquet format.")
@click.option('--output-file', '-o', required=True, help="Path to save the output configuration JSON file.")
def build_gene_comparison_config(profile_db, gene_db_id, reference_genome_id, scope, min_cov, min_gene_compare_len, stb_file_loc, current_comp_table, output_file):
    """
    Build a gene comparison configuration JSON file from the given parameters.

    Args:
    profile_db (str): Path to the profile database Parquet file.
    gene_db_id (str): Gene database ID.
    reference_genome_id (str): Reference genome ID.
    scope (str): Genome scope for comparison.
    min_cov (int): Minimum coverage to consider a position.
    min_gene_compare_len (int): Minimum gene length to consider for comparison.
    stb_file_loc (str): Path to the scaffold-to-genome mapping file.
    current_comp_table (str): Path to the current comparison table in Parquet format.
    output_file (str): Path to save the output configuration JSON file.
    """
    conf_obj=db.GeneComparisonConfig(
        gene_db_id=gene_db_id,
        reference_genome_id=reference_genome_id,
        scope=scope,
        min_cov=min_cov,
        min_gene_compare_len=min_gene_compare_len,
        stb_file_loc=stb_file_loc,
    )
    profile_db_obj=db.ProfileDatabase(profile_db)
    
    comp_obj=db.GeneComparisonDatabase(
        profile_db=profile_db_obj,
        config=conf_obj,
        comp_db_loc=current_comp_table
    )
    comp_obj.dump_obj(pathlib.Path(output_file))


@utilities.command("to-complete-table")
@click.option("--genome-comparison-object", "-g", required=True, help="Path to the genome comparison object in json format.")
@click.option("--output-file", "-o", required=True, help="Path to save the completed pairs csv file.")
def to_complete_table(genome_comparison_object, output_file):
    """
    Generate a table of completed genome comparison pairs and save it to a csv file.

    Parameters:
    genome_comparison_object (str): Path to the genome comparison object in json format.
    output_file (str): Path to save the completed pairs Parquet file.
    """
    genome_comp_db=db.GenomeComparisonDatabase.load_obj(pathlib.Path(genome_comparison_object))
    completed_pairs=genome_comp_db.to_complete_input_table()
    completed_pairs.sink_csv(pathlib.Path(output_file), engine="streaming")

@utilities.command("presence-profile")
@click.option('--profile-file', '-p', required=True, help="Path to the profile Parquet file.")
@click.option('--stb-file', '-s', required=True, help="Path to the scaffold-to-genome mapping file.")
@click.option('--bed-file', '-b', required=True, help="Path to the BED file.")
@click.option('--read-loc-file', '-r', required=True, help="Path to the read location table.")
@click.option('--min-cov-fug', '-c', default=0.1, help="Minimum coverage to use fug.")
@click.option('--fug-threshold', '-f', default=2, help="FUG threshold.")
@click.option('--ber', '-e', default=0.5, help="Minimum ratio of breadth over expected breadth to consider presence.")
@click.option('--output-file', '-o', required=True, help="Path to save the output Parquet file.")
def presence_profile(profile_file, stb_file, bed_file, read_loc_file, min_cov_fug, fug_threshold, ber, output_file):
    """
    Generate a presence profile for genomes based on the given profile and read location data.

    Args:
    profile_file (str): Path to the profile Parquet file.
    stb_file (str): Path to the scaffold-to-genome mapping file.
    bed_file (str): Path to the BED file.
    read_loc_file (str): Path to the read location table.
    min_cov_fug (float): Minimum coverage to use fug.
    fug_threshold (float): FUG threshold.
    ber (float): Minimum ratio of breadth over expected breadth to consider presence.
    output_file (str): Path to save the output Parquet file.
    """
    profile = pl.scan_parquet(profile_file)
    stb = pl.scan_csv(stb_file, separator="\t", has_header=False).with_columns(
        pl.col("column_1").alias("scaffold"),
        pl.col("column_2").alias("genome")
    ).select(["scaffold", "genome"])
    bed = pl.scan_csv(bed_file, separator="\t", has_header=False).with_columns(
        pl.col("column_1").alias("scaffold"),
        pl.col("column_2").cast(pl.Int64).alias("start"),
        pl.col("column_3").cast(pl.Int64).alias("end")
    ).select(["scaffold", "start", "end"])
    read_loc_table = pl.scan_parquet(read_loc_file).rename({
        "chrom":"scaffold",
        "pos":"loc"
    })
    presence_df = ut.get_genome_stats(
        profile=profile,
        stb=stb,
        bed=bed,
        read_loc_table=read_loc_table,
        min_cov_use_fug=min_cov_fug,
        fug=fug_threshold,
        ber=ber
    )
    presence_df.sink_parquet(output_file, compression='zstd')

@utilities.command("process-read-locs")
@click.option("--output-file", "-o", required=True, help="Path to save the processed read locations Parquet file.")
def process_read_locs(output_file):
    """
    Process read locations and save them to a Parquet file.

    Args:
    output_file (str): Path to save the output Parquet file.
    """
    ut.process_read_location(output_file=pathlib.Path(output_file))

@utilities.command("generate_stb")
@click.option('--genomes-dir-file', '-g', required=True, help="Path to the genomes directory file. A text file with each line containing a genome fasta file path.")
@click.option('--output-file', '-o', required=True, help="Path to save the output scaffold-to-genome mapping file.")
@click.option('--extension', '-e', default=".fasta", help="File extension of the genome fasta files.")
def generate_stb(genomes_dir_file, output_file, extension):
    """
    Generate a scaffold-to-genome mapping file from the given genomes directory file.

    Args:
    genomes_dir_file (str): Path to the genomes directory file.
    output_file (str): Path to save the output scaffold-to-genome mapping file.
    extension (str): File extension of the genome fasta files.
    """
    with open(output_file, 'w') as out_f:
        for genome in pathlib.Path(genomes_dir_file).glob(f"*{extension}"):
            genome_name = genome.stem
            with open(genome, 'r') as gf:
                for line in gf:
                    if line.startswith('>'):
                        scaffold_name = line[1:].strip().split()[0]
                        out_f.write(f"{scaffold_name}\t{genome_name}\n")
    
        
    


@utilities.command("gene-range-table")
@click.option('--gene-file', '-g', required=True, help="location of gene file. Prodigal's nucleotide fasta output")
@click.option('--output-file', '-o', required=True, help="location to save output tsv file")
def get_gene_range_table(gene_file, output_file):
    """
    Main function to build and save the gene location table.

    Args:
    gene_file (str): Path to the gene FASTA file.
    output_file (str): Path to save the output TSV file.
    """
    gene_locs=pf.build_gene_range_table(pathlib.Path(gene_file))
    gene_locs.write_csv(pathlib.Path(output_file), separator="\t", include_header=False)


@cli.group()
def compare():
    """The commands in this group are related to comparing profiled samples."""
    pass

@utilities.command("single_compare_genome")
@click.option('--mpileup-contig-1', '-m1', required=True, help="Path to the first mpileup file.")
@click.option('--mpileup-contig-2', '-m2', required=True, help="Path to the second mpileup file.")
@click.option('--stb-file', '-s', required=True, help="Path to the scaffold to genome mapping file.")
@click.option('--min-cov', '-c', default=5, help="Minimum coverage to consider a position.")
@click.option('--min-gene-compare-len', '-l', default=100, help="Minimum gene length to consider for comparison.")
@click.option('--output-file', '-o', required=True, help="Path to save the parquet file.")
@click.option('--genome', '-g', default="all", help="If provided, do the comparison only for the specified genome.")
@click.option('--ani-method', '-a', default="popani", help="ANI calculation method to use (e.g., 'popani', 'conani', 'cosani_0.4').")
@click.option('--calculate', default="all", show_default=True, help="Genome metrics to compute: ani, ibs, identical_genes. Combine with '+', or use all.")
@click.option('--engine', type=click.Choice(["polars", "duckdb"]), default="polars", show_default=True, help="Execution engine for compare.")
@click.option('--duckdb-memory-limit', default=None, help="DuckDB memory limit (e.g., 2GB, 1024MB).")
@click.option('--duckdb-temp-directory', default=None, help="Directory DuckDB can use for spill files.")
@click.option('--duckdb-threads', type=int, default=None, help="Number of DuckDB worker threads.")
def single_compare_genome(mpileup_contig_1, mpileup_contig_2, stb_file, min_cov, min_gene_compare_len, output_file, genome, ani_method, calculate, engine, duckdb_memory_limit, duckdb_temp_directory, duckdb_threads):
    """
    Main function to compare two mpileup files and calculate genome and gene statistics.
    
    Args:
    mpileup_contig_1 (str): Path to the first mpileup file.
    mpileup_contig_2 (str): Path to the second mpileup file.
    min_cov (int): Minimum coverage to consider a position.
    min_gene_compare_len (int): Minimum gene length to consider for comparison.
    output_file (str): Path to save the parquet file.
    genome (str): If provided, do the comparison only for the specified genome.
    stb_file (str): Path to the scaffold to genome mapping file.
    """
    mpile_contig_1_name = pathlib.Path(mpileup_contig_1).name
    mpile_contig_2_name = pathlib.Path(mpileup_contig_2).name
    if duckdb_threads is not None and duckdb_threads < 1:
        raise ValueError("--duckdb-threads must be >= 1")
    calculations = cp.parse_genome_calculations(calculate)
    output_cols = cp.genome_metric_output_columns(calculations)

    mpile_1_for_compare = mpileup_contig_1
    mpile_2_for_compare = mpileup_contig_2
    if engine == "polars" and genome != "all":
        mpile_1_for_compare, mpile_2_for_compare = cp.duckdb_prefilter_by_scope(
            mpile1=mpileup_contig_1,
            mpile2=mpileup_contig_2,
            genome_scope=genome,
            memory_limit=duckdb_memory_limit,
            temp_directory=duckdb_temp_directory,
            threads=duckdb_threads,
        )

    if engine == "duckdb":
        cp.duckdb_compare_genomes_to_parquet(
            mpile1=mpileup_contig_1,
            mpile2=mpileup_contig_2,
            output_file=output_file,
            stb_file=stb_file,
            sample_1_name=mpile_contig_1_name,
            sample_2_name=mpile_contig_2_name,
            min_cov=min_cov,
            min_gene_compare_len=min_gene_compare_len,
            genome_scope=genome,
            ani_method=ani_method,
            calculate=calculations,
            memory_limit=duckdb_memory_limit,
            temp_directory=duckdb_temp_directory,
            threads=duckdb_threads,
        )
        return

    comp = cp.compare_genomes(
        mpile_contig_1=mpile_1_for_compare,
        mpile_contig_2=mpile_2_for_compare,
        min_cov=min_cov,
        min_gene_compare_len=min_gene_compare_len,
        genome_scope=genome,
        ani_method=ani_method,
        duckdb_memory_limit=duckdb_memory_limit,
        duckdb_temp_directory=duckdb_temp_directory,
        duckdb_threads=duckdb_threads,
        engine="polars",
        stb_file=stb_file,
        calculate=calculations,
    ).with_columns(
        sample_1=pl.lit(mpile_contig_1_name),
        sample_2=pl.lit(mpile_contig_2_name),
    ).select(output_cols + ["sample_1", "sample_2"])
    comp.sink_parquet(output_file, compression='zstd')

@utilities.command("single_compare_gene")
@click.option('--mpileup-contig-1', '-m1', required=True, help="Path to the first mpileup file.")
@click.option('--mpileup-contig-2', '-m2', required=True, help="Path to the second mpileup file.")
@click.option('--stb-file', '-s', required=True, help="Path to the scaffold to genome mapping file.")
@click.option('--min-cov', '-c', default=5, help="Minimum coverage to consider a position.")
@click.option('--min-gene-compare-len', '-l', default=100, help="Minimum gene length to consider for comparison.")
@click.option('--output-file', '-o', required=True, help="Path to save the parquet file.")
@click.option('--scope', '-g', default="all:all", help="If provided, do the comparison only for the specified genome-gene pair.")
@click.option('--ani-method', '-a', default="popani", help="ANI calculation method to use (e.g., 'popani', 'conani', 'cosani_0.4').")
@click.option('--engine', type=click.Choice(["polars", "duckdb"]), default="polars", show_default=True, help="Execution engine for compare.")
@click.option('--duckdb-memory-limit', default=None, help="DuckDB memory limit (e.g., 2GB, 1024MB).")
@click.option('--duckdb-temp-directory', default=None, help="Directory DuckDB can use for spill files.")
@click.option('--duckdb-threads', type=int, default=None, help="Number of DuckDB worker threads.")
def single_compare_gene(mpileup_contig_1, mpileup_contig_2, stb_file, min_cov, min_gene_compare_len, output_file, scope, ani_method, engine, duckdb_memory_limit, duckdb_temp_directory, duckdb_threads):
    """
    Compare two mpileup files and calculate gene-level comparison statistics.
    
    Args:
    mpileup_contig_1 (str): Path to the first mpileup file.
    mpileup_contig_2 (str): Path to the second mpileup file.
    stb_file (str): Path to the scaffold to genome mapping file.
    min_cov (int): Minimum coverage to consider a position.
    min_gene_compare_len (int): Minimum gene length to consider for comparison.
    output_file (str): Path to save the parquet file.
    scope (str): If provided, do the comparison only for the specified genome-gene pair.
    ani_method (str): ANI calculation method to use.
    """

    mpile_contig_1_name = pathlib.Path(mpileup_contig_1).name
    mpile_contig_2_name = pathlib.Path(mpileup_contig_2).name
    if duckdb_threads is not None and duckdb_threads < 1:
        raise ValueError("--duckdb-threads must be >= 1")

    _ = stb_file
    if ":" not in scope:
        raise ValueError("scope must be in 'GENOME:GENE' format (e.g., all:all).")
    genome_scope, gene_scope = scope.split(":", 1)

    mpile_1_for_compare = mpileup_contig_1
    mpile_2_for_compare = mpileup_contig_2
    if engine == "polars" and (genome_scope != "all" or gene_scope != "all"):
        mpile_1_for_compare, mpile_2_for_compare = cp.duckdb_prefilter_by_scope(
            mpile1=mpileup_contig_1,
            mpile2=mpileup_contig_2,
            genome_scope=genome_scope,
            gene_scope=gene_scope,
            memory_limit=duckdb_memory_limit,
            temp_directory=duckdb_temp_directory,
            threads=duckdb_threads,
        )

    if engine == "duckdb":
        cp.duckdb_compare_genes_to_parquet(
            mpile1=mpileup_contig_1,
            mpile2=mpileup_contig_2,
            output_file=output_file,
            sample_1_name=mpile_contig_1_name,
            sample_2_name=mpile_contig_2_name,
            min_cov=min_cov,
            min_gene_compare_len=min_gene_compare_len,
            genome_scope=genome_scope,
            gene_scope=gene_scope,
            ani_method=ani_method,
            memory_limit=duckdb_memory_limit,
            temp_directory=duckdb_temp_directory,
            threads=duckdb_threads,
        )
        return

    gene_comp = cp.compare_genes(
        mpile_contig_1=mpile_1_for_compare,
        mpile_contig_2=mpile_2_for_compare,
        min_cov=min_cov,
        min_gene_compare_len=min_gene_compare_len,
        genome_scope=genome_scope,
        gene_scope=gene_scope,
        ani_method=ani_method,
        duckdb_memory_limit=duckdb_memory_limit,
        duckdb_temp_directory=duckdb_temp_directory,
        duckdb_threads=duckdb_threads,
        engine="polars",
    ).with_columns(
        sample_1=pl.lit(mpile_contig_1_name),
        sample_2=pl.lit(mpile_contig_2_name),
    ).select(
        "genome",
        "gene",
        "total_positions",
        "share_allele_pos",
        "ani",
        "sample_1",
        "sample_2",
    )
    gene_comp.sink_parquet(output_file, compression='zstd')

@utilities.command("prepare_profiling", help="Prepare the files needed for profiling bam files and save them in the specified output directory.")
@click.option('--reference-fasta', '-r', required=True, help="Path to the reference genome in FASTA format.")
@click.option('--gene-fasta', '-g', default=None, help="Optional path to the gene annotations in FASTA format.")
@click.option('--stb-file', '-s', required=True, help="Path to the scaffold-to-genome mapping file.")
@click.option('--output-dir', '-o', required=True, help="Directory to save the profiling database.")
def prepare_profiling(reference_fasta, gene_fasta, stb_file, output_dir):
    """
    Prepare the files needed for profiling bam files and save them in the specified output directory.
    """
    output_dir=pathlib.Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    bed_df = ut.make_the_bed(reference_fasta)
    bed_df.write_csv(output_dir / "genomes_bed_file.bed", separator='\t', include_header=False)
    if gene_fasta is None:
        pl.DataFrame(schema={"gene": pl.Utf8, "scaffold": pl.Utf8, "start": pl.Int64, "end": pl.Int64}).write_csv(
            output_dir / "gene_range_table.tsv",
            separator='\t',
            include_header=False,
        )
    else:
        gene_range_table = pf.build_gene_range_table(pathlib.Path(gene_fasta))
        gene_range_table.write_csv(output_dir / "gene_range_table.tsv", separator='\t', include_header=False)
    
    stb = pl.scan_csv(stb_file, separator='\t',has_header=False).with_columns(
        pl.col("column_1").alias("scaffold"),
        pl.col("column_2").alias("genome")
    )

    bed_df = bed_df.lazy()
    genome_length = ut.extract_genome_length(stb, bed_df)
    genome_length.sink_parquet(output_dir / "genome_lengths.parquet", compression='zstd')


@utilities.command("profile-single")
@click.option('--bed-file', '-b', required=True, help="Path to the BED file describing regions to be profiled.")
@click.option('--bam-file', '-a', required=True, help="Path to the BAM file to be profiled.")
@click.option('--stb-file', '-s', required=True, help="Path to the scaffold-to-genome mapping file.")
@click.option('--null-model', '-m', required=True, help="Path to the null model parquet file.") 
@click.option('--gene-range-table', '-g', default=None, help="Optional path to the gene range table.")
@click.option('--num-chunks', '-n', default=24, show_default=True, help="Number of BED chunks to create for profiling.")
@click.option('--max-concurrency', '-c', default=4, show_default=True, help="Maximum number of profiling chunks to run concurrently.")
@click.option('--output-dir', '-o', required=True, help="Directory to save the profiling output.")
def profile_single(bed_file, bam_file, stb_file, null_model, gene_range_table, num_chunks, max_concurrency, output_dir):
    """
    Profile a single BAM file using the provided BED file and optional gene range table.
    
    """
    output_dir=pathlib.Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    stb= pl.scan_csv(stb_file, separator='\t',has_header=False).with_columns(
        pl.col("column_1").alias("scaffold"),
        pl.col("column_2").alias("genome")
    )
    null_model=pl.scan_parquet(null_model)
    pf.profile_bam(
        bed_file=bed_file,
        bam_file=bam_file,
        gene_range_table=gene_range_table,
        stb=stb,
        null_model=null_model,
        output_dir=output_dir,
        num_chunks=num_chunks,
        max_concurrency=max_concurrency,
    )

@cli.command("profile")
@click.option('--input-table', '-i', required=True, help="Path to the input table in TSV format containing sample names and paths to bam files.")
@click.option('--stb-file', '-s', required=True, help="Path to the scaffold-to-genome mapping file.")
@click.option('--null-model', '-u', required=True, help="Path to the null model parquet file.")
@click.option('--gene-range-table', '-g', default=None, help="Optional path to the gene range table file.")
@click.option('--bed-file', '-b', required=True, help="Path to the BED file for profiling regions.")
@click.option('--genome-length-file', '-l', required=True, help="Path to the genome length file.")
@click.option('--run-dir', '-r', required=True, help="Directory to save the run data.")
@click.option('--num-procs', '-n', default=8, help="Number of processors to use for each profiling task.")
@click.option('--max-concurrent-batches', '-m', default=5, help="Maximum number of concurrent batches to run.")
@click.option('--poll-interval', '-p', default=1, help="Polling interval in seconds to check the status of batches.")
@click.option('--execution-mode', '-e', default="local", help="Execution mode: 'local' or 'slurm'.")
@click.option('--slurm-config', '-c', default=None, help="Path to the SLURM configuration file in json format. Required if execution mode is 'slurm'.")
@click.option('--container-engine', '-o', default="local", help="Container engine to use: 'local', 'docker' or 'apptainer'.")
@click.option('--task-per-batch', '-t', default=10, help="Number of tasks to include in each batch.")
def profile(input_table, stb_file, null_model, gene_range_table, bed_file, genome_length_file, run_dir, num_procs, max_concurrent_batches, poll_interval, execution_mode, slurm_config, container_engine, task_per_batch):
    """
    Run BAM file profiling in batches using the specified execution mode and container engine.

    Args:
    input_table (str): Path to the input table in TSV format containing sample names and BAM file paths.
    stb_file (str): Path to the scaffold-to-genome mapping file.
    null_model (str): Path to the null model parquet file.
    gene_range_table (str | None): Optional path to the gene range table file.
    bed_file (str): Path to the BED file for profiling regions.
    genome_length_file (str): Path to the genome length file.
    run_dir (str): Directory to save the run data.
    num_procs (int): Number of processors to use for each profiling task.
    max_concurrent_batches (int): Maximum number of concurrent batches to run.
    poll_interval (int): Polling interval in seconds to check the status of batches.
    execution_mode (str): Execution mode: 'local' or 'slurm'.
    slurm_config (str): Path to the SLURM configuration file in json format. Required if execution mode is 'slurm'.
    container_engine (str): Container engine to use: 'local', 'docker' or 'apptainer'.
    task_per_batch (int): Number of tasks to include in each batch.
    """
    # Load the BAM files table
    bams_lf = pl.scan_csv(input_table)
    
    # Validate required columns exist
    required_columns = {"sample_name", "bamfile"}
    actual_columns = set(bams_lf.collect_schema().names())
    if not required_columns.issubset(actual_columns):
        missing = required_columns - actual_columns
        raise ValueError(f"Input table missing required columns: {missing}")
    
    run_dir = pathlib.Path(run_dir)
    slurm_conf = None
    if execution_mode == "slurm":
        if slurm_config is None:
            raise ValueError("SLURM configuration file must be provided when execution mode is 'slurm'.")
        slurm_conf = tm.SlurmConfig.from_json(slurm_config)
    
    if container_engine == "local":
        container_engine_obj = tm.LocalEngine(address="")
    elif container_engine == "docker":
        container_engine_obj = tm.DockerEngine(address="parsaghadermazi/zipstrain:amd64")
    elif container_engine == "apptainer":
        container_engine_obj = tm.ApptainerEngine(address="docker://parsaghadermazi/zipstrain:amd64")
    else:
        raise ValueError("Invalid container engine. Choose from 'local', 'docker', or 'apptainer'.")
    
    tm.lazy_run_profile(
        run_dir=run_dir,
        container_engine=container_engine_obj,
        bams_lf=bams_lf,
        stb_file=pathlib.Path(stb_file),
        null_model_file=pathlib.Path(null_model),
        gene_range_table=pathlib.Path(gene_range_table) if gene_range_table is not None else None,
        bed_file=pathlib.Path(bed_file),
        genome_length_file=pathlib.Path(genome_length_file),
        num_procs=num_procs,
        tasks_per_batch=task_per_batch,
        max_concurrent_batches=max_concurrent_batches,
        poll_interval=poll_interval,
        execution_mode=execution_mode,
        slurm_config=slurm_conf,
    )


@compare.command("genomes")
@click.option("--genome-comparison-object", "-g", required=True, help="Path to the genome comparison object in json format.")
@click.option("--run-dir", "-r", required=True, help="Directory to save the run data.")
@click.option("--max-concurrent-batches", "-m", default=5, help="Maximum number of concurrent batches to run.")
@click.option("--poll-interval", "-p", default=1, help="Polling interval in seconds to check the status of batches.")
@click.option("--execution-mode", "-e", default="local", help="Execution mode: 'local' or 'slurm'.")
@click.option("--slurm-config", "-s", default=None, help="Path to the SLURM configuration file in json format. Required if execution mode is 'slurm'.")
@click.option("--container-engine", "-c", default="local", help="Container engine to use: 'local', 'docker' or 'apptainer'.")
@click.option("--task-per-batch", "-t", default=10, help="Number of tasks to include in each batch.")
@click.option("--ani-method", "-a", default="popani", show_default=True, help="ANI calculation method passed to genome compare tasks.")
@click.option("--engine", type=click.Choice(["polars", "duckdb"]), default="polars", show_default=True, help="Comparison engine for compare tasks.")
@click.option("--calculate", default="all", show_default=True, help="Genome metrics to compute: ani, ibs, identical_genes. Combine with '+', or use all.")
@click.option("--duckdb-memory-limit", "-d", default=None, help="DuckDB memory limit for compare tasks (e.g., 2GB).")
@click.option("--duckdb-threads", type=int, default=None, help="Number of DuckDB worker threads for compare tasks.")
def compare_genomes(genome_comparison_object, run_dir, max_concurrent_batches, poll_interval, execution_mode, slurm_config, container_engine, task_per_batch, ani_method, engine, calculate, duckdb_memory_limit, duckdb_threads):
    """
    Run genome comparisons in batches using the specified execution mode and container engine.

    Args:
    genome_comparison_object (str): Path to the genome comparison object in json format.
    run_dir (str): Directory to save the run data.
    max_concurrent_batches (int): Maximum number of concurrent batches to run.
    poll_interval (int): Polling interval in seconds to check the status of batches.
    execution_mode (str): Execution mode: 'local' or 'slurm'.
    slurm_config (str): Path to the SLURM configuration file in json format. Required if execution mode is 'slurm'.
    container_engine (str): Container engine to use: 'local', 'docker' or 'apptainer'.
    task_per_batch (int): Number of tasks to include in each batch.
    """
    genome_comp_db=db.GenomeComparisonDatabase.load_obj(pathlib.Path(genome_comparison_object))
    run_dir=pathlib.Path(run_dir)
    if duckdb_threads is not None and duckdb_threads < 1:
        raise ValueError("--duckdb-threads must be >= 1")
    cp.parse_genome_calculations(calculate)
    slurm_conf=None
    if execution_mode == "slurm":
        if slurm_config is None:
            raise ValueError("SLURM configuration file must be provided when execution mode is 'slurm'.")
        slurm_conf = tm.SlurmConfig.from_json(slurm_config)
    
    if container_engine == "local":
        container_engine_obj = tm.LocalEngine(address="")
    elif container_engine == "docker":
        container_engine_obj = tm.DockerEngine(address="parsaghadermazi/zipstrain:amd64") #could go to a toml or json config file
    elif container_engine == "apptainer":
        container_engine_obj = tm.ApptainerEngine(address="docker://parsaghadermazi/zipstrain:amd64") #could go to a toml or json config file
    else:
        raise ValueError("Invalid container engine. Choose from 'local', 'docker', or 'apptainer'.")
    tm.lazy_run_compares(
        comps_db=genome_comp_db,
        container_engine=container_engine_obj,
        run_dir=run_dir,
        max_concurrent_batches=max_concurrent_batches,
        execution_mode=execution_mode,
        slurm_config=slurm_conf,
        ani_method=ani_method,
        compare_engine=engine,
        calculate=calculate,
        duckdb_memory_limit=duckdb_memory_limit,
        duckdb_threads=duckdb_threads,
        tasks_per_batch=task_per_batch,
        poll_interval=poll_interval,
    )



@compare.command("build-comp-database")
@click.option("--profile-db-dir", "-p", required=True, help="Directory containing profile either in parquet format.")
@click.option("--config-file", "-c", required=True, help="Path to the  genome comparsion database config file in json format.")
@click.option("--output-dir", "-o", required=True, help="Directory to genome comparison database object.")
@click.option("--comp-db-file", "-f", required=False, help="The initial database file. If provided only additional comparisons will be added to this database.")
def build_comp_database(profile_db_dir, config_file, output_dir, comp_db_file):
    """
    Build a genome comparison database from the given profiles and configuration.

    Parameters:
    profile_db_dir (str): Directory containing profile either in parquet format.
    config_file (str): Path to the genome comparison database config file in json format.
    """
    profile_db_dir=pathlib.Path(profile_db_dir)
    profile_db=db.ProfileDatabase(
        db_loc=profile_db_dir,
    )
    existing_db_loc=pathlib.Path(comp_db_file) if comp_db_file is not None else None
    if existing_db_loc is not None and not existing_db_loc.exists():
        raise FileNotFoundError(f"{existing_db_loc} does not exist.")
    obj=db.GenomeComparisonDatabase(
        profile_db=profile_db,
        config=db.GenomeComparisonConfig.from_json(pathlib.Path(config_file)),
        comp_db_loc=existing_db_loc,
    )
    obj.dump_obj(pathlib.Path(output_dir))


@compare.command("genes")
@click.option("--gene-comparison-object", "-g", required=True, help="Path to the gene comparison object in json format.")
@click.option("--run-dir", "-r", required=True, help="Directory to save the run data.")
@click.option("--max-concurrent-batches", "-m", default=5, help="Maximum number of concurrent batches to run.")
@click.option("--poll-interval", "-p", default=1, help="Polling interval in seconds to check the status of batches.")
@click.option("--execution-mode", "-e", default="local", help="Execution mode: 'local' or 'slurm'.")
@click.option("--slurm-config", "-s", default=None, help="Path to the SLURM configuration file in json format. Required if execution mode is 'slurm'.")
@click.option("--container-engine", "-c", default="local", help="Container engine to use: 'local', 'docker' or 'apptainer'.")
@click.option("--task-per-batch", "-t", default=10, help="Number of tasks to include in each batch.")
@click.option("--ani-method", "-n", default="popani", help="ANI calculation method to use (e.g., 'popani', 'conani', 'cosani_0.4').")
@click.option("--engine", type=click.Choice(["polars", "duckdb"]), default="polars", show_default=True, help="Comparison engine for compare tasks.")
@click.option("--duckdb-memory-limit", "-d", default=None, help="DuckDB memory limit for compare tasks (e.g., 2GB).")
@click.option("--duckdb-threads", type=int, default=None, help="Number of DuckDB worker threads for compare tasks.")
def compare_genes(gene_comparison_object, run_dir, max_concurrent_batches, poll_interval, execution_mode, slurm_config, container_engine, task_per_batch, ani_method, engine, duckdb_memory_limit, duckdb_threads):
    """
    Run gene comparisons in batches using the specified execution mode and container engine.

    Args:
    genome_comparison_object (str): Path to the genome comparison object in json format.
    run_dir (str): Directory to save the run data.
    max_concurrent_batches (int): Maximum number of concurrent batches to run.
    poll_interval (int): Polling interval in seconds to check the status of batches.
    execution_mode (str): Execution mode: 'local' or 'slurm'.
    slurm_config (str): Path to the SLURM configuration file in json format. Required if execution mode is 'slurm'.
    container_engine (str): Container engine to use: 'local', 'docker' or 'apptainer'.
    task_per_batch (int): Number of tasks to include in each batch.
    ani_method (str): ANI calculation method to use.
    """
    genome_comp_db=db.GeneComparisonDatabase.load_obj(pathlib.Path(gene_comparison_object))
    run_dir=pathlib.Path(run_dir)
    if duckdb_threads is not None and duckdb_threads < 1:
        raise ValueError("--duckdb-threads must be >= 1")
    slurm_conf=None
    if execution_mode == "slurm":
        if slurm_config is None:
            raise ValueError("SLURM configuration file must be provided when execution mode is 'slurm'.")
        slurm_conf = tm.SlurmConfig.from_json(slurm_config)
    
    if container_engine == "local":
        container_engine_obj = tm.LocalEngine(address="")
    elif container_engine == "docker":
        container_engine_obj = tm.DockerEngine(address="parsaghadermazi/zipstrain:amd64")
    elif container_engine == "apptainer":
        container_engine_obj = tm.ApptainerEngine(address="docker://parsaghadermazi/zipstrain:amd64")
    else:
        raise ValueError("Invalid container engine. Choose from 'local', 'docker', or 'apptainer'.")
    
    tm.lazy_run_gene_compares(
        comps_db=genome_comp_db,
        container_engine=container_engine_obj,
        run_dir=run_dir,
        max_concurrent_batches=max_concurrent_batches,
        execution_mode=execution_mode,
        slurm_config=slurm_conf,
        compare_engine=engine,
        tasks_per_batch=task_per_batch,
        poll_interval=poll_interval,
        ani_method=ani_method,
        duckdb_memory_limit=duckdb_memory_limit,
        duckdb_threads=duckdb_threads,
    )
        
@cli.command("test")
def test():
    """Run basic tests to ensure ZipStrain is setup correctly."""
    ### Check samtools installation
    if all([ut.check_samtools()]):
        click.echo("ZipStrain setup looks good!")
    else:
        click.echo("There are issues with the ZipStrain setup. Please check the above messages.")

if __name__ == "__main__":
    cli()
