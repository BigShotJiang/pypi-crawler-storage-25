"""Built-in control-loop wrappers used by the Node daemon.

The daemon calls one of these on every assignment. The functions are
deliberately written to be drop-in replacements for one another and
to never import their heavy deps at module load — the daemon should
be importable on a barebones Pi.

Custom integrations: write your own `control_loop(client, session,
should_stop, **_)` and pass `--loop my_module:control_loop` to the
daemon. `import_callable` resolves it.

Collection: the LeRobot wrapper records every (obs, action) pair to a
local SQLite staging cache and frames to a media buffer, then on loop
exit builds a LeRobot dataset and uploads it under the auto-created
Model. Reuses the existing high-level ``Interlatent`` client — the
daemon never touches collection internals directly.
"""
from __future__ import annotations

import importlib
import io
import logging
import time
from typing import Any, Callable, Optional

import numpy as np

_LOG = logging.getLogger("interlatent.node.control")


def import_callable(spec: str) -> Callable[..., Any]:
    """Resolve a `module.path:attr` spec to the attribute itself.

    Used for `--loop` overrides on the CLI.
    """
    if ":" not in spec:
        raise ValueError(
            f"--loop expects 'module:function', got {spec!r}"
        )
    module_path, _, attr = spec.partition(":")
    mod = importlib.import_module(module_path)
    fn = getattr(mod, attr, None)
    if fn is None:
        raise AttributeError(
            f"module {module_path!r} has no attribute {attr!r}"
        )
    if not callable(fn):
        raise TypeError(f"{spec!r} is not callable")
    return fn


# ---------------------------------------------------------------------------
# Built-in LeRobot wrapper
# ---------------------------------------------------------------------------


def lerobot_control_loop(
    *,
    client,
    session: dict,
    should_stop: Callable[[], bool],
    robot_kind: str,
    robot_port: Optional[str] = None,
    robot_extra: Optional[dict[str, str]] = None,
    robot_cameras: Optional[dict[str, str]] = None,
    api_key: Optional[str] = None,
    api_base: Optional[str] = None,
    **_: Any,
) -> None:
    """Generic LeRobot observe/act loop with episode collection.

    Reads frames + joint state from a LeRobot Robot, npz-encodes them
    for DRTC, dispatches the returned action chunk, AND records every
    step into the local Interlatent staging cache. On clean exit (or
    any exception) we attempt the upload so the episode lands in the
    user's env regardless of how the loop ended.

    Pacing is governed by the DRTC client's internal RTC cooldown; we
    don't enforce a manual fps here.
    """
    from interlatent import Interlatent

    robot = _make_lerobot_robot(
        robot_kind, port=robot_port, extra=robot_extra or {}, cameras=robot_cameras or {}
    )

    # Pull collection-relevant fields off the session payload (populated
    # by the backend's /poll handler when an Environment exists).
    ctx = session.get("collection_context") or {}
    env_slug = ctx.get("env_slug") or "default"
    failure_descriptions = ctx.get("failure_descriptions") or None
    success_descriptions = ctx.get("success_descriptions") or None
    session_id = session.get("id", "")
    server_model_id = session.get("model_id") or session_id
    fps = int(session.get("fps", 30) or 30)
    task = session.get("task", "") or env_slug

    il_client = Interlatent(
        api_key=api_key,
        base_url=api_base,
        record_activations=False,
        model_id=server_model_id,
        fps=fps,
    )
    # model=None is safe with record_activations=False — Watcher stores
    # the ref but never installs hooks. Pinning episode_id=session_id
    # keeps InferenceSession.id == Episode.episode_id end-to-end.
    il_client.watch(
        model=None,
        env_name=env_slug,
        model_id=server_model_id,
        task=task,
        capture_frames=True,
        failure_descriptions=failure_descriptions,
        success_descriptions=success_descriptions,
        episode_id=session_id,
    )

    robot.connect()
    _LOG.info(
        "LeRobot %r connected; entering control loop (collect → episode %s)",
        robot_kind, session_id,
    )
    upload_attempted = False
    try:
        while not should_stop():
            obs = robot.get_observation()
            # The policy expects observation.state + observation.images.*;
            # raw lerobot robot keys (<motor>.pos, <cam>) must be remapped.
            payload = _encode_npz(_to_policy_schema(obs))
            action = client.step(payload, codec="npz")
            if action is None:
                # No fresh action this tick — RTC client is paced;
                # don't tick the staging cache for empty actions either.
                continue
            action_to_send = _coerce_action_for_robot(action, obs)
            robot.send_action(action_to_send)
            il_client.tick(
                obs=_obs_for_tick(obs),
                action=action_to_send,
                frame=_frames_for_tick(obs),
            )
    finally:
        try:
            robot.disconnect()
        except Exception:
            _LOG.warning("Robot disconnect failed", exc_info=True)
        try:
            _LOG.info("Uploading episode %s to Interlatent...", session_id)
            upload_attempted = True
            il_client.upload(tags={
                "source": "node-daemon",
                "node_session_id": session_id,
            })
            _LOG.info("Upload complete for episode %s", session_id)
        except Exception:
            _LOG.exception("Upload failed for episode %s — staging cache "
                           "preserved on disk for retry", session_id)
        finally:
            # Belt-and-suspenders log so we never silently swallow a
            # collection-skipped path.
            if not upload_attempted:
                _LOG.warning("Loop exited without invoking upload for %s", session_id)


def _obs_for_tick(obs: dict) -> Any:
    """Project the LeRobot obs dict to a 1-D state vector for tick().

    The SDK staging cache stores ``observation.state`` as the canonical
    state column. Cameras are handled separately via the media buffer.
    """
    state = obs.get("observation.state")
    if state is None:
        # Fall back: concatenate any 1-D numeric arrays present.
        flat: list[float] = []
        for k, v in obs.items():
            if isinstance(v, np.ndarray) and v.ndim == 1:
                flat.extend(float(x) for x in v.tolist())
        return np.asarray(flat, dtype=np.float32)
    return np.asarray(state, dtype=np.float32)


def _frames_for_tick(obs: dict) -> Optional[dict]:
    """Pull any image-shaped entries out of the obs dict for media capture."""
    frames: dict[str, np.ndarray] = {}
    for k, v in obs.items():
        if not isinstance(v, np.ndarray):
            continue
        # Treat 3-D or 4-D uint8 arrays as images (camera frames).
        if v.dtype == np.uint8 and v.ndim in (3, 4):
            # Strip leading batch dim if present.
            arr = v[0] if v.ndim == 4 else v
            name = k.split(".")[-1] if "." in k else k
            frames[name] = arr
    return frames or None


def _build_camera_configs(cameras: dict[str, str]) -> dict[str, Any]:
    """Build lerobot OpenCV camera configs from a ``{name: device}`` map.

    Each ``name`` becomes the lerobot camera key, so the robot emits
    ``observation.images.<name>``. Pick names that match the policy's
    expected image keys and no ``rename_map`` is needed.

    ``device`` is a /dev path ("/dev/video0") or a bare index ("0").
    Resolution/fps default to 640x480@30 — the SO101 camera default.
    """
    if not cameras:
        return {}
    from lerobot.cameras.opencv import OpenCVCameraConfig

    out: dict[str, Any] = {}
    for name, device in cameras.items():
        idx_or_path: Any = int(device) if str(device).isdigit() else device
        out[name] = OpenCVCameraConfig(
            index_or_path=idx_or_path, width=640, height=480, fps=30
        )
    return out


def _make_lerobot_robot(
    kind: str,
    *,
    port: Optional[str],
    extra: dict[str, str],
    cameras: Optional[dict[str, str]] = None,
):
    """Instantiate a LeRobot Robot by name.

    For v1 we support the two follower configs we've verified — extending
    to more is a 3-line addition per type.
    """
    # Importing here keeps the daemon importable without lerobot installed.
    try:
        from lerobot.robots import make_robot_from_config
    except ImportError as e:
        raise RuntimeError(
            "lerobot is not installed. Install with `pip install "
            "interlatent[lerobot]` (or pass --loop module:fn for a "
            "custom adapter)."
        ) from e

    cam_configs = _build_camera_configs(cameras or {})

    kind_norm = kind.lower().strip()
    if kind_norm in ("so101", "so101_follower"):
        # lerobot consolidated its per-robot modules: SO101FollowerConfig
        # now lives in the shared `so_follower` module (covers SO100 +
        # SO101). Older lerobot shipped a dedicated `so101_follower`
        # module — support both layouts.
        try:
            from lerobot.robots.so_follower import SO101FollowerConfig
        except ImportError:
            from lerobot.robots.so101_follower import SO101FollowerConfig
        kwargs = _filter_kwargs(SO101FollowerConfig, extra)
        if cam_configs:
            kwargs["cameras"] = cam_configs
        cfg = SO101FollowerConfig(port=port or "", **kwargs)
        return make_robot_from_config(cfg)

    if kind_norm in ("koch", "koch_follower"):
        from lerobot.robots.koch_follower import KochFollowerConfig
        kwargs = _filter_kwargs(KochFollowerConfig, extra)
        if cam_configs:
            kwargs["cameras"] = cam_configs
        cfg = KochFollowerConfig(port=port or "", **kwargs)
        return make_robot_from_config(cfg)

    raise ValueError(
        f"Unsupported --robot {kind!r}. Built-in support: so101_follower, "
        f"koch_follower. For other LeRobot robots, write a thin adapter and "
        f"pass --loop module:fn."
    )


def _filter_kwargs(cfg_cls, extra: dict[str, str]) -> dict[str, Any]:
    """Pick only the keys `cfg_cls` actually declares.

    Lets the user pass --robot-arg key=value without us hardcoding which
    keys are valid for which config class.
    """
    try:
        import dataclasses
        if dataclasses.is_dataclass(cfg_cls):
            valid = {f.name for f in dataclasses.fields(cfg_cls)}
            return {k: v for k, v in extra.items() if k in valid}
    except Exception:
        pass
    return dict(extra)


# ---------------------------------------------------------------------------
# Codecs
# ---------------------------------------------------------------------------


def _to_policy_schema(obs: dict) -> dict:
    """Map a raw lerobot robot observation to the policy input schema.

    lerobot robots return joints as bare ``<motor>.pos`` scalars and
    cameras as bare ``<name>`` image arrays. lerobot policies instead
    expect a single ``observation.state`` vector plus
    ``observation.images.<name>`` image keys.

    Joint scalars are concatenated in robot-observation order — which
    is the motor order the policy's ``observation.state`` was trained
    on, so no explicit joint-name map is needed. Images are detected by
    uint8 dtype + 2-D-or-more shape and re-keyed under
    ``observation.images.``.
    """
    state_vals: list[float] = []
    out: dict[str, Any] = {}
    for key, value in obs.items():
        if key == "task":
            out["task"] = value
            continue
        arr = np.asarray(value)
        if arr.dtype == np.uint8 and arr.ndim >= 2:
            name = key.rsplit(".", 1)[-1]
            out[f"observation.images.{name}"] = arr
        else:
            state_vals.extend(float(x) for x in arr.flatten())
    if state_vals:
        out["observation.state"] = np.asarray(state_vals, dtype=np.float32)
    return out


def _encode_npz(obs: dict) -> bytes:
    """Encode a LeRobot observation dict into npz bytes.

    LeRobot observations are dicts of numpy arrays (joints, cameras).
    The DRTC server's npz codec produces a dict for the lerobot backend
    to consume via `_to_batch`.
    """
    flat: dict[str, np.ndarray] = {}
    for k, v in obs.items():
        if isinstance(v, np.ndarray):
            flat[k] = v
        else:
            try:
                flat[k] = np.asarray(v)
            except Exception:
                # Skip un-encodable keys rather than crashing the whole loop.
                _LOG.debug("Skipping unencodable obs key %r (type=%s)", k, type(v).__name__)
    buf = io.BytesIO()
    np.savez(buf, **flat)
    return buf.getvalue()


def _coerce_action_for_robot(action: np.ndarray, obs: dict) -> Any:
    """Convert the DRTC action vector into whatever shape LeRobot wants.

    LeRobot's `send_action` for follower robots typically accepts either
    a dict mapping joint names to floats or a 1-D array sized to the
    action_dim. We try both: dict first if the obs gives us key names,
    array fallback otherwise.
    """
    arr = np.asarray(action, dtype=np.float32).reshape(-1)
    # Best-effort: if the obs has an "observation.state" with named
    # joints (some lerobot robots expose this), we can't recover names
    # without robot metadata, so fall back to the array path. Robots
    # that demand named dicts will need a small adapter.
    return arr
