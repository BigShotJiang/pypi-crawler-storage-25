"""Node daemon — long-poll + heartbeat + control-loop dispatch.

The daemon owns three concurrent tasks:

1. **Heartbeat** (10s): POST /nodes/{id}/heartbeat. Lets the dashboard
   show the node as online.
2. **Poll** (long-poll, up to ~25s per request): GET /nodes/{id}/poll.
   Returns the current desired session for this node (or null).
   Whenever the assignment changes, we converge.
3. **Control loop** (when assigned): spawned in a background thread
   that owns the `connect_drtc()` client and the robot I/O.

Convergence rules:
    desired None  + actual None     -> noop
    desired None  + actual running  -> stop the loop, close client
    desired X     + actual None     -> open client + start loop with X
    desired X     + actual running Y -> stop, then start with X
                                        (shouldn't happen unless the
                                         backend was edited; backend
                                         refuses to overwrite a busy
                                         node — but we handle it
                                         anyway for robustness)
"""
from __future__ import annotations

import asyncio
import io
import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

import httpx
import numpy as np

_LOG = logging.getLogger("interlatent.node.daemon")


@dataclass
class NodeDaemonConfig:
    node_id: str
    token: str
    api_base: str
    # Interlatent user API key (ilat_...). The node `token` authenticates
    # heartbeat/poll against the nodes API, but the DRTC server validates
    # against `/environments` (require_auth), which rejects node tokens —
    # so DRTC inference must use the user API key instead.
    drtc_api_key: Optional[str] = None
    robot_kind: Optional[str] = None
    robot_port: Optional[str] = None
    robot_extra: dict[str, str] = field(default_factory=dict)
    # {camera_name: device} — name becomes the observation.images.<name> key.
    robot_cameras: dict[str, str] = field(default_factory=dict)
    loop_override: Optional[str] = None  # "module:callable"

    heartbeat_period_s: float = 10.0
    poll_wait_s: int = 25
    reconnect_backoff_s: float = 2.0
    max_backoff_s: float = 30.0


# ---------------------------------------------------------------------------
# Daemon
# ---------------------------------------------------------------------------


class NodeDaemon:
    def __init__(self, cfg: NodeDaemonConfig) -> None:
        self.cfg = cfg
        self._http = httpx.AsyncClient(
            base_url=cfg.api_base,
            headers={"x-api-key": cfg.token},
            timeout=httpx.Timeout(cfg.poll_wait_s + 10),
        )
        self._known_session_id: str = ""  # what we've executed against
        # Active control loop (None when idle)
        self._active: Optional[_ControlLoopHandle] = None
        # Resolved at start_session time; lazy so non-lerobot uses don't
        # eat the import.
        self._loop_fn: Optional[Callable[..., None]] = None

    # ------------------------------------------------------------------
    # Public entrypoint
    # ------------------------------------------------------------------

    def run_forever(self) -> None:
        try:
            asyncio.run(self._main())
        except KeyboardInterrupt:
            _LOG.info("Shutdown requested, stopping any active session...")
            self._stop_active_loop()

    async def _main(self) -> None:
        _LOG.info(
            "Node daemon online: node_id=%s api_base=%s",
            self.cfg.node_id, self.cfg.api_base,
        )
        try:
            await asyncio.gather(
                self._heartbeat_loop(),
                self._poll_loop(),
            )
        finally:
            await self._http.aclose()
            self._stop_active_loop()

    # ------------------------------------------------------------------
    # Heartbeat
    # ------------------------------------------------------------------

    async def _heartbeat_loop(self) -> None:
        backoff = self.cfg.reconnect_backoff_s
        while True:
            try:
                r = await self._http.post(
                    f"/api/v1/nodes/{self.cfg.node_id}/heartbeat"
                )
                if r.status_code >= 400:
                    _LOG.warning("Heartbeat %s: %s", r.status_code, r.text)
                    await asyncio.sleep(min(backoff, self.cfg.max_backoff_s))
                    backoff = min(backoff * 2, self.cfg.max_backoff_s)
                    continue
                backoff = self.cfg.reconnect_backoff_s
            except Exception as e:  # network blip
                _LOG.warning("Heartbeat failed: %s", e)
                await asyncio.sleep(min(backoff, self.cfg.max_backoff_s))
                backoff = min(backoff * 2, self.cfg.max_backoff_s)
                continue
            await asyncio.sleep(self.cfg.heartbeat_period_s)

    # ------------------------------------------------------------------
    # Long-poll + convergence
    # ------------------------------------------------------------------

    async def _poll_loop(self) -> None:
        backoff = self.cfg.reconnect_backoff_s
        while True:
            try:
                r = await self._http.get(
                    f"/api/v1/nodes/{self.cfg.node_id}/poll",
                    params={
                        "known_session_id": self._known_session_id,
                        "wait": self.cfg.poll_wait_s,
                    },
                )
                if r.status_code >= 400:
                    _LOG.warning("Poll %s: %s", r.status_code, r.text)
                    await asyncio.sleep(min(backoff, self.cfg.max_backoff_s))
                    backoff = min(backoff * 2, self.cfg.max_backoff_s)
                    continue
                backoff = self.cfg.reconnect_backoff_s
                data = r.json()
                if data.get("changed"):
                    # _converge runs a blocking connect_drtc() (the DRTC
                    # OpenSession can take 30s+ on a cold container). Run
                    # it off the event loop so the heartbeat coroutine
                    # keeps firing — otherwise the node looks offline and
                    # the backend drops its session assignment.
                    await asyncio.to_thread(self._converge, data.get("session"))
            except Exception as e:
                _LOG.warning("Poll failed: %s", e)
                await asyncio.sleep(min(backoff, self.cfg.max_backoff_s))
                backoff = min(backoff * 2, self.cfg.max_backoff_s)

    def _converge(self, session: Optional[dict]) -> None:
        desired_id = (session or {}).get("id", "") if session else ""
        if desired_id == self._known_session_id and self._active is not None:
            # Same session already running — noop.
            return

        # Always stop the prior loop before starting a new one.
        if self._active is not None:
            _LOG.info("Stopping current session %s", self._known_session_id)
            self._stop_active_loop()

        if session is None:
            self._known_session_id = ""
            return

        try:
            self._start_loop(session)
            self._known_session_id = desired_id
        except Exception as e:
            _LOG.exception("Failed to start session %s: %s", desired_id, e)
            # Don't update _known_session_id — next poll will retry once
            # the backend assignment changes (or the user fixes the issue
            # and re-assigns).
            self._known_session_id = ""

    # ------------------------------------------------------------------
    # Control-loop lifecycle
    # ------------------------------------------------------------------

    def _resolve_loop_fn(self) -> Callable[..., None]:
        """Pick the control-loop function exactly once.

        --loop module:fn wins. Otherwise the built-in LeRobot wrapper.
        """
        if self._loop_fn is not None:
            return self._loop_fn

        if self.cfg.loop_override:
            from .control import import_callable
            self._loop_fn = import_callable(self.cfg.loop_override)
        else:
            if not self.cfg.robot_kind:
                raise RuntimeError(
                    "No control loop available: pass --robot <name> for "
                    "the bundled LeRobot wrapper, or --loop "
                    "module:function for a custom adapter."
                )
            from .control import lerobot_control_loop
            self._loop_fn = lerobot_control_loop
        return self._loop_fn

    def _start_loop(self, session: dict) -> None:
        from interlatent.inference.integration.connect import connect_drtc

        client = connect_drtc(
            # DRTC auth needs the ilat_ user key; the node token is
            # rejected by the server's /environments probe.
            api_key=self.cfg.drtc_api_key or self.cfg.token,
            model_id=session.get("id", ""),
            policy_uri=session.get("policy_uri", ""),
            policy_backend=session.get("policy_backend", "lerobot"),
            task=session.get("task", ""),
            chunk_size=int(session.get("chunk_size", 32) or 32),
            action_dim=int(session.get("action_dim", 6) or 6),
            fps=float(session.get("fps", 30.0) or 30.0),
            server_address=session.get("drtc_endpoint") or None,
        )

        loop_fn = self._resolve_loop_fn()
        handle = _ControlLoopHandle(client=client)
        kwargs = {
            "client": client,
            "session": session,
            "should_stop": handle.should_stop,
            "robot_kind": self.cfg.robot_kind,
            "robot_port": self.cfg.robot_port,
            "robot_extra": self.cfg.robot_extra,
            "robot_cameras": self.cfg.robot_cameras,
            # The collection-aware lerobot wrapper uses these to spin up
            # an Interlatent client that uploads on session exit.
            "api_key": self.cfg.token,
            "api_base": self.cfg.api_base,
        }

        def _runner():
            try:
                loop_fn(**kwargs)
            except Exception:
                _LOG.exception("Control loop crashed")
            finally:
                try:
                    client.close()
                except Exception:
                    pass

        handle.thread = threading.Thread(
            target=_runner, name=f"node-loop-{session.get('id','')[:8]}", daemon=True
        )
        handle.thread.start()
        self._active = handle
        _LOG.info("Started session %s (policy=%s task=%r)",
                  session.get("id"), session.get("policy_uri"), session.get("task"))

    def _stop_active_loop(self) -> None:
        if self._active is None:
            return
        h = self._active
        self._active = None
        h.stop_flag.set()
        if h.thread is not None:
            h.thread.join(timeout=10.0)
            if h.thread.is_alive():
                _LOG.warning("Control-loop thread did not exit within 10s")


@dataclass
class _ControlLoopHandle:
    client: Any
    stop_flag: threading.Event = field(default_factory=threading.Event)
    thread: Optional[threading.Thread] = None

    def should_stop(self) -> bool:
        return self.stop_flag.is_set()
