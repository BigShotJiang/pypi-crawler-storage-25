"""LWW (Last-Write-Wins) action schedule.

The DRTC paper models the client's action queue as a CRDT: each
action is keyed by (action_step) and carries a control_timestamp.
When two messages arrive for the same step, the one with the larger
control_timestamp wins. The semilattice join is therefore associative
+ commutative + idempotent, which is what lets the network drop,
duplicate, or reorder messages without breaking trajectory continuity.

Concretely we keep a dict {action_step -> (control_timestamp, vector)}.
Pop returns the next-due action in step order. Old entries are
trimmed once the executor has consumed past them.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass
from typing import Iterable, Iterator, Optional

import numpy as np


@dataclass
class ScheduledAction:
    action_step: int
    control_timestamp: int
    vector: np.ndarray


class ActionSchedule:
    def __init__(self) -> None:
        self._data: dict[int, ScheduledAction] = {}
        self._cursor: int = 0  # next step to execute
        self._lock = threading.Lock()

    # --- merge ---------------------------------------------------------

    def merge(self, actions: Iterable[ScheduledAction]) -> int:
        """Apply LWW for each incoming action. Returns count actually
        installed (i.e. with a strictly newer control_timestamp)."""
        installed = 0
        with self._lock:
            for a in actions:
                if a.action_step < self._cursor:
                    continue  # already executed; ignore
                cur = self._data.get(a.action_step)
                if cur is None or a.control_timestamp > cur.control_timestamp:
                    self._data[a.action_step] = a
                    installed += 1
        return installed

    # --- consume -------------------------------------------------------

    def pop_due(self, up_to_step: int) -> list[ScheduledAction]:
        """Return all scheduled actions with step <= up_to_step, in
        order, and advance the executor cursor past them."""
        out: list[ScheduledAction] = []
        with self._lock:
            steps = sorted(s for s in self._data if s <= up_to_step)
            for s in steps:
                out.append(self._data.pop(s))
            if out:
                self._cursor = max(self._cursor, out[-1].action_step + 1)
        return out

    # --- introspection -------------------------------------------------

    def queue_depth(self) -> int:
        with self._lock:
            return len(self._data)

    def next_action_step(self) -> int:
        """First step the server should produce on the next request."""
        with self._lock:
            if not self._data:
                return self._cursor
            return max(self._data) + 1

    def scheduled_spans(self) -> list[tuple[int, int]]:
        """Compact run-length representation of {scheduled steps}.

        We send this up with each Observation so the server can pull
        in-painting context for exactly the range we already have.
        """
        with self._lock:
            if not self._data:
                return []
            steps = sorted(self._data)
        spans: list[tuple[int, int]] = []
        run_lo = run_hi = steps[0]
        for s in steps[1:]:
            if s == run_hi + 1:
                run_hi = s
            else:
                spans.append((run_lo, run_hi))
                run_lo = run_hi = s
        spans.append((run_lo, run_hi))
        return spans

    def cursor(self) -> int:
        with self._lock:
            return self._cursor

    def __iter__(self) -> Iterator[ScheduledAction]:
        with self._lock:
            return iter(sorted(self._data.values(), key=lambda a: a.action_step))
