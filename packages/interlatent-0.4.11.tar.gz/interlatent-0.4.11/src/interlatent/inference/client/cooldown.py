"""Inference-request cooldown counter.

DRTC gates re-requesting inference while one is in flight. The
counter ticks down once per control step; when it hits zero a new
request is allowed. If a response arrives first, the counter is
reset (via `arm`) to ``cooldown_steps``. If no response ever arrives,
the counter naturally reaches zero and the client re-issues the
request — drops are recovered without any explicit retry timer.

The counter lives on the client thread; sender/receiver call into it
under a lock.
"""

from __future__ import annotations

import threading


class Cooldown:
    def __init__(self, cooldown_steps: int) -> None:
        if cooldown_steps < 1:
            raise ValueError("cooldown_steps must be >= 1")
        self._n = 0
        self._max = cooldown_steps
        self._lock = threading.Lock()

    def arm(self, n: int | None = None) -> None:
        """Called when a request is sent OR a response is received.
        Resets the counter so we don't fire again immediately."""
        with self._lock:
            self._n = n if n is not None else self._max

    def tick(self) -> None:
        """Call once per control step."""
        with self._lock:
            if self._n > 0:
                self._n -= 1

    def ready(self) -> bool:
        with self._lock:
            return self._n == 0

    @property
    def remaining(self) -> int:
        with self._lock:
            return self._n
