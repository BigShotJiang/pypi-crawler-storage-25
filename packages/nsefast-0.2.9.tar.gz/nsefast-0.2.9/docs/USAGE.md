# nsefast — Usage Guide

> Public NSE India data only. Respects `robots.txt`, no anti-bot bypass.

## Install

```bash
pip install nsefast
# with optional extras
pip install "nsefast[pandas,postgres,api]"
```

For local development:

```bash
git clone https://github.com/nikhilshinde/nsefast
cd nsefast
pip install -e ".[dev]"
pytest -q
```

## Failure semantics (read this first)

Every public collector returns a **Polars DataFrame with its canonical
schema** on any failure (invalid input, network exception, HTTP non-200,
JSON decode error, malformed payload, polars construction error, robots
block). Collectors **never raise**. Empty DataFrame ≠ error — it just
means no data for that input.

```python
from nsefast.collectors.deals import bulk_deals
df = bulk_deals("not-a-date", "also-bad")   # logs a warning, returns empty df
assert df.is_empty()
assert df.columns == ["date","symbol","security_name","client_name",
                      "buy_sell","quantity","price","remarks","source_url"]
```

## Quick CLI tour

```bash
# Daily archives
nsefast collect equity-bhavcopy --date 2026-05-07
nsefast collect fo-bhavcopy     --date 2026-05-07
nsefast collect delivery        --date 2026-05-07
nsefast collect symbol-master

# Deals (date-range, 90-day chunked)
nsefast collect bulk-deals  --start 2026-04-01 --end 2026-05-07
nsefast collect block-deals --start 2026-04-01 --end 2026-05-07

# Corporate filings
nsefast collect corporate-announcements --start 2026-04-01 --end 2026-05-07
nsefast collect corporate-actions       --start 2026-04-01 --end 2026-05-07

# Live snapshots
nsefast collect option-chain    --symbol NIFTY
nsefast collect option-chain    --symbol RELIANCE
nsefast collect sector-strength
nsefast collect all-indices
nsefast collect 52w

# Discover all downloadable report URLs
nsefast collect-reports

# Build features
nsefast features swing --date 2026-05-07
```

All commands save partitioned Parquet under `data/parquet/<dataset>/…`.

## Python API

### Daily archives

```python
from nsefast.collectors import equity, derivatives, master

df = equity.daily_bhavcopy("2026-05-07")        # OHLCV per security
df = equity.delivery_data("2026-05-07")         # delivery quantity / %
df = derivatives.fo_bhavcopy("2026-05-07")      # F&O snapshot
df = master.symbol_master()                     # all listed symbols
```

### Date-range JSON collectors (90-day chunked, polite)

```python
from nsefast.collectors.deals import bulk_deals, block_deals
from nsefast.collectors.corporate import (
    corporate_announcements, corporate_actions,
    dividends, bonuses, splits, rights_issues, mergers_demergers,
)

deals = bulk_deals("2026-04-01", "2026-05-07")
ann   = corporate_announcements("2026-04-01", "2026-05-07")
divs  = dividends("2026-04-01", "2026-05-07")        # filtered slice
```

### Live snapshots

```python
from nsefast.collectors.derivatives import option_chain
from nsefast.collectors.indices import all_indices, sector_strength
from nsefast.collectors.equity import (
    fifty_two_week_high_low, fifty_two_week_high, fifty_two_week_low,
)

chain   = option_chain("NIFTY")          # CE & PE flattened, one row per leg
chain_r = option_chain("RELIANCE")       # auto-routes equity vs index endpoint

idx     = all_indices()                  # every index NSE publishes
strong  = sector_strength()              # sector-only, sorted by % change desc

w52     = fifty_two_week_high_low()      # 'category' column = "high" or "low"
highs   = fifty_two_week_high()
lows    = fifty_two_week_low()
```

### Storage

```python
from nsefast.storage.parquet_store import save_parquet, read_parquet

path = save_parquet(df, dataset="bulk_deals", partition="2026-05")
df2  = read_parquet("bulk_deals")

# DuckDB analytics over the parquet lake
from nsefast.storage.duckdb_store import register_view, query
register_view("bulk_deals")
top = query("SELECT symbol, SUM(quantity) AS q FROM bulk_deals "
            "GROUP BY symbol ORDER BY q DESC LIMIT 10")
```

### Optional PostgreSQL sink

```python
# pip install "nsefast[postgres]"
from nsefast.storage.postgres_store import write_dataframe
write_dataframe(df, table="bulk_deals", dsn="postgresql://user:pw@host/db")
```

## Canonical schemas

| Collector | Columns |
|---|---|
| `bulk_deals` / `block_deals` | `date, symbol, security_name, client_name, buy_sell, quantity, price, remarks, source_url` |
| `corporate_announcements` | `date, symbol, company_name, subject, details, attachment_url, source_url` |
| `corporate_actions` | `ex_date, record_date, symbol, company_name, purpose, face_value, source_url` |
| `option_chain*` | `symbol, underlying_value, expiry_date, strike_price, option_type, open_interest, change_in_oi, volume, implied_volatility, last_price, change, bid_qty, bid_price, ask_price, ask_qty, source_url, fetched_at` |
| `all_indices` / `sector_strength` | `index_name, last, change, percent_change, open, day_high, day_low, prev_close, year_high, year_low, advances, declines, unchanged, source_url, fetched_at` |
| `fifty_two_week_high_low` | `symbol, series, company_name, category, last_price, prev_high_low, prev_high_low_date, change, percent_change, source_url, fetched_at` |

## Network notes

- NSE blocks many datacenter IP ranges (AWS, GCP, Replit, etc.) at the
  edge. Run from a residential IP if collectors silently return empty.
- The HTTP client warms up cookies via `nseindia.com` before any
  `/api/...` call — if you build your own session, do the same.
- All endpoints are gated by `robots.txt`. Disallowed paths return empty.

## Smart signals & risk engine (`nsefast.processing.technicals`, `nsefast.swing.*`)

All helpers are crash-proof: they return the input frame unchanged (or
the canonical empty frame, for filters / portfolio_size /
correlation_clusters) on any error. Per-symbol math uses
`.over(group_col)`, so multi-symbol panels work out of the box.

### Indicator pack (`processing.technicals`)

| Helper | Adds | Notes |
|---|---|---|
| `add_sma(n)` / `add_ema(n)` | `sma_{n}` / `ema_{n}` | per-symbol |
| `add_rsi(n)` | `rsi_{n}` | saturates at 0/100 (no nulls in zero-loss windows) |
| `add_macd(fast, slow, signal)` | `macd`, `macd_signal`, `macd_hist` | |
| `add_bollinger(n, k)` | `bb_mid`, `bb_upper`, `bb_lower` | |
| `add_donchian(n)` | `dc_upper`, `dc_lower`, `dc_mid` | |
| `add_supertrend(n, mult)` | `st_upper`, `st_lower`, `st_dir` | basic-band, vectorised |
| `add_adx(n)` | `plus_di`, `minus_di`, `adx_{n}` | |
| `add_obv()` | `obv` | per-symbol cumulative |
| `add_all_technicals()` | full pack with library defaults | one call |

### Multi-timeframe scoring (`swing.scoring`)

```python
from nsefast.swing import (momentum_zscore, volume_zscore,
                           add_multi_timeframe_zscores)

panel = momentum_zscore(panel, lookback=20)        # mom_z_20
panel = volume_zscore(panel,   lookback=20)        # vol_z_20
panel = add_multi_timeframe_zscores(panel)         # all six (5/20/60)
```

### Relative strength (`swing.relative_strength`)

```python
from nsefast.swing import add_relative_strength, add_rs_score

panel = add_relative_strength(panel, benchmark_df, lookback=20)  # rs_20 (pp)
panel = add_rs_score(panel, rs_col="rs_20")                      # rs_20_score (0-100 percentile per date)
```

Benchmark dates are deduplicated to one row per `trade_date` so a noisy
benchmark frame can never fan out the price panel.

### Breakouts (`swing.breakouts`)

```python
from nsefast.swing import (
    add_52w_high_low, near_52w_high,
    donchian_breakout, consolidation_breakout,
    add_gap_pct, add_range_atr,
)

panel = add_52w_high_low(panel, window=252)         # high_52w / low_52w
near_52w_high(panel, within_pct=2.0)                # filter + pct_below_52w_high
donchian_breakout(panel, n=20)                      # close > prior n-bar high (today excluded)
consolidation_breakout(panel,
                       atr_period=14,
                       contraction_lookback=10,
                       expansion_mult=2.0)          # VCP-style
panel = add_gap_pct(panel)                          # uses prev_close if present
panel = add_range_atr(panel, period=14)             # bar range / ATR; > 1 = expansion
```

### Per-trade risk (`swing.risk`)

```python
from nsefast.swing.risk import (
    position_size, risk_reward,
    add_atr, add_atr_stop, add_position_size,
    add_chandelier_stop, add_trailing_atr_stop, add_swing_low_stop,
    add_vol_target_size,
)

# Equal-rupee risk
position_size(capital=500_000, entry=120, stop=115, risk_pct=1.0)
risk_reward(entry=120, stop=115, target=135)

# Stops (all crash-proof; auto-compute ATR if not present)
add_atr(panel, period=14)                            # atr column
add_atr_stop(panel, mult=2.0)                        # stop_loss
add_chandelier_stop(panel, period=22, mult=3.0)      # rolling-high anchored
add_trailing_atr_stop(panel, period=14, mult=3.0)    # per-symbol cum-max, monotonic
add_swing_low_stop(panel, window=10)                 # rolling min(low)

# Vol-targeted sizing (each position = same daily rupee P&L vol)
add_vol_target_size(panel, capital=500_000,
                    target_daily_vol_pct=0.5)        # vol_qty
```

> **Note** — `add_trailing_atr_stop`, `add_chandelier_stop`, and every
> rolling/cumulative helper assume input rows are sorted by
> `[symbol, trade_date]`. The history loader does this for you;
> if you build a panel by hand, sort first.

### Portfolio sizing (`swing.portfolio`)

```python
from nsefast.swing import portfolio_size, correlation_clusters

# Cluster picks by 60-day return correlation (greedy union-find)
clusters = correlation_clusters(history_df,
                                symbols=["TCS","INFY","WIPRO","HDFCBANK"],
                                lookback=60, threshold=0.7)
# → DataFrame[symbol, cluster_id]

# Water-fill allocation under all three caps
book = portfolio_size(
    picks_df,                       # has 'symbol', optionally 'sector', 'cluster_id', 'score'
    capital=10_00_000,
    max_positions=10,
    max_single_pct=10.0,
    max_sector_pct=30.0,
    max_cluster_pct=20.0,           # None to disable
    weight_col="score",             # or omit for equal-weight
)
# → DataFrame[symbol, weight, allocated_pct, allocated_rs, capped_by]
```

**Algorithm.** Each pass enforces single-name, sector, then cluster
caps, and redistributes any residual proportional to the *available
headroom* (smallest of single / sector / cluster room remaining) on
each name. Iterates up to 50 times. The shortfall, if any, is the
*cash residual* — caps genuinely make full deployment infeasible.

`capped_by` is recomputed against final weights with precedence
**single → cluster → sector** (tightest scope first), so the label
always names the binding cap.

`correlation_clusters` correlates each pair of symbols over only
the rows where both are non-NaN (`min_overlap = max(5, lookback//4)`),
so a freshly-listed name doesn't get pushed into a singleton cluster
just because it has a shorter history than its peers.

## Polite-use checklist

1. Don't reduce `REQUEST_DELAY_SECONDS` (default in `nsefast.config`).
2. Cache results to Parquet; don't re-fetch the same range repeatedly.
3. Don't run more than one collector instance against NSE concurrently.
4. Comply with NSE's terms of service. You are responsible for usage.
