# Publishing nsefast to PyPI

> **Replit cannot publish to PyPI for you.** PyPI requires your account
> credentials. Use these steps from your own machine (or a CI you control).

## One-time setup

1. Create a PyPI account: <https://pypi.org/account/register/>
2. Create an API token: <https://pypi.org/manage/account/token/>
   - Scope: "Entire account" (first publish) or "Project: nsefast" (after first publish).
3. Save the token in `~/.pypirc`:

   ```ini
   [pypi]
   username = __token__
   password = pypi-<your-long-token>

   [testpypi]
   username = __token__
   password = pypi-<your-test-token>
   ```

4. (Optional) Create a TestPyPI token at <https://test.pypi.org> for dry-runs.

## Build and publish

```bash
# 1. From a clean checkout, install build tooling
pip install --upgrade build twine

# 2. Bump the version in pyproject.toml and CHANGELOG.md
#    (PyPI rejects re-uploads of an existing version)

# 3. Wipe stale artifacts
rm -rf dist/ build/ *.egg-info

# 4. Build sdist + wheel
python -m build

# 5. Sanity-check the artifacts
twine check dist/*

# 6. (Optional) Dry-run on TestPyPI first
twine upload --repository testpypi dist/*
pip install --index-url https://test.pypi.org/simple/ nsefast

# 7. Real upload
twine upload dist/*
```

## After publish

- Tag the release: `git tag v0.1.0 && git push --tags`
- Verify install: `pip install nsefast` then `nsefast --help`
- Update the GitHub release notes from `CHANGELOG.md`.

## Automated publishing (optional)

Use the included `.github/workflows/publish.yml` — it builds + publishes
to PyPI on every pushed tag matching `v*`. Configure a `PYPI_API_TOKEN`
secret in your GitHub repo settings.

## Versioning

- Bump `version` in `pyproject.toml`.
- Add a section to `CHANGELOG.md`.
- Follow SemVer: bump **patch** for fixes, **minor** for new collectors,
  **major** for breaking schema changes.

## What ships in the wheel

`MANIFEST.in` excludes tests, the Rust crate, the `data/` cache, and
Replit `artifacts/`. The wheel contains only the `nsefast/` Python
package + README + LICENSE + CHANGELOG.

Verify locally:

```bash
python -m build
unzip -l dist/nsefast-*.whl
```
