# v0.3.0 — Event-driven backtester (design)

> Status: **scoping**. Nothing here is built yet. Current `swing.backtest`
> stays as the v0.2.x fixed-holding stub until v0.3.0 ships.

The v0.2.x `run_backtest` is a one-shot, fixed-holding bar simulator —
fine as a sanity check, useless for honest research. v0.3.0 replaces it
with a proper event-driven engine that respects Indian-market frictions
and walk-forward discipline.

The engine is **bar-close, daily, long-only first** (shorts after the
first stable release), runs purely on the existing partitioned-parquet
history, and never touches the network. Everything is Polars-native
and crash-proof per the library contract.

---

## 1. Event-driven loop

```
nsefast/swing/backtest/
├── __init__.py
├── engine.py        # BacktestEngine, run()
├── orders.py        # Signal, Order, Fill, Position, Trade dataclasses
├── exits.py         # StopLoss, ProfitTarget, TimeStop, TrailingStop, OCO
├── costs.py         # IndianEquityCosts (see §2)
├── slippage.py      # FixedBps, AtrFraction, VolumeImpact (see §3)
├── walkforward.py   # train/validate/test splitter + tuner (see §4)
├── report.py        # equity / drawdown / monthly / trade-log → HTML (see §5)
└── benchmark.py     # NIFTY 50 buy-and-hold comparator (see §6)
```

**Loop shape (one bar at a time, T+0 close-fill default):**

```
for date in trading_days:
    bar = panel.filter(trade_date == date)          # all symbols, this bar
    # 1. Close bar — process exits on open positions first
    for pos in book.open_positions:
        if exit_rule.fires(pos, bar):
            book.close(pos, fill=apply_costs(...))
    # 2. Score & generate entry signals from prior-bar info only
    signals = strategy.signals(panel.up_to(date - 1))
    # 3. Allocate via swing.portfolio.portfolio_size, respecting open book
    targets = allocator.size(signals, capital=book.cash + book.mtm())
    # 4. Open new positions at next-bar open (default) or this-bar close
    for tgt in targets:
        book.open(tgt, fill=apply_costs(...))
    # 5. Mark-to-market, snapshot equity
    book.snapshot(date)
```

Key design rules:

- **Exits are independent of entries.** Each open position carries its
  own bag of exit rules (`StopLoss`, `ProfitTarget`, `TimeStop`,
  `TrailingStop`) joined with **OCO** semantics — first to fire wins.
- **No look-ahead.** `signal_fn` only sees `panel.up_to(date - 1)`; the
  engine enforces this by passing a sliced view, not the full frame.
- **Entries fill at next-bar open by default** (`fill_when="next_open"`),
  with `fill_when="close"` for fast-and-loose tests. Stops fire intra-bar
  if `low <= stop` (long) and fill at `min(open, stop)` to model gaps
  honestly — never at the exact stop on a gap-down day.
- **Position object** carries: entry date / px / qty, ATR-at-entry,
  stop, target, time-stop expiry, sector & cluster IDs, cumulative
  cost paid. This is what the report layer reads.
- **`book.snapshot(date)`** writes `(date, cash, mtm, equity, n_open,
  n_closed_today)` to a per-bar equity series — the source of truth
  for §5 reports.

---

## 2. Indian equity cost model (`costs.py`)

A real round-trip on Indian delivery equity bleeds **0.4 % – 1.1 %**.
Defaults match a typical discount-broker (Zerodha / Upstox-style)
schedule for **delivery** (CNC); intraday (MIS) and F&O are separate
profiles selectable via `IndianEquityCosts.intraday()` /
`.fno_futures()` / `.fno_options()`.

Default delivery profile (per leg, in INR unless noted):

| Charge          | Buy                              | Sell                             | Notes |
|-----------------|----------------------------------|----------------------------------|---|
| Brokerage       | `min(20, 0.03% × turnover)` cap=0 by default | same | `flat_brokerage_inr` & `pct_brokerage` configurable |
| STT             | —                                | `0.1% × sell_turnover`           | delivery sell-side only |
| Exchange txn    | `0.00297% × turnover`            | `0.00297% × turnover`            | NSE cash |
| SEBI            | `₹10 / crore × turnover`         | same                             | |
| Stamp duty      | `0.015% × buy_turnover`          | —                                | buy-side only |
| GST             | `18% × (brokerage + exchange + SEBI)` | same                        | |
| DP charges      | —                                | `₹13.5 + 18% GST` per scrip per day | sell-side only, optional |

API:

```python
costs = IndianEquityCosts.delivery()                         # defaults above
costs = IndianEquityCosts.delivery(flat_brokerage_inr=0.0)   # zero-brokerage
costs = IndianEquityCosts.intraday()                         # MIS (no STT on buy, 0.025% sell)
total = costs.charge(side="buy",  qty=100, price=120.0)      # → CostBreakdown
```

`CostBreakdown` is a dataclass with one field per line item plus
`.total_inr` and `.bps_of_turnover` so the report can show which
charge ate the most P&L.

> **Honesty rule.** The engine subtracts costs from realized P&L on
> *every fill* — not retroactively per round-trip. An entry that gets
> stopped out the next day still pays both legs of brokerage, two GSTs,
> stamp duty, sell-side STT, and the exchange charge.

---

## 3. Slippage models (`slippage.py`)

Three pluggable models, all callable as `slippage(side, price, bar) → executed_price`:

1. **`FixedBps(bps=10)`** — flat 10 bps adverse fill. Sane default for
   liquid large-caps; demolishes scanner P&L on small-caps, which is
   the point.
2. **`AtrFraction(fraction=0.05)`** — slips by `fraction × ATR(bar)`.
   Ties slippage to realized volatility — wide-range bars cost more.
3. **`VolumeImpact(participation_pct=10, k=0.1)`** — square-root impact:
   `slip_bps = k × sqrt(order_qty / bar_volume × 10_000)`. Caps order
   size at `participation_pct` of bar volume; orders larger than that
   are split across bars (or rejected if `reject_oversized=True`).

Stops use `FixedBps` for the gap-down extra slippage on top of the
gap-fill price (so a stop at ₹100 with a gap to ₹95 fills at ~₹94.90,
not ₹100).

---

## 4. Walk-forward tuning (`walkforward.py`)

```
|<──── train ────>|<── validate ──>|<─ test ─>|
                   choose params      report
                                      results
```

API:

```python
splits = walk_forward_splits(
    history,
    train_years=3, validate_months=6, test_months=3,
    step_months=3,                 # rolling window step
    purge_days=5,                  # gap to avoid leakage from holding period
)
# → list[ Split(train_idx, validate_idx, test_idx, train_period, ...) ]

results = tune_walk_forward(
    splits,
    strategy_factory=lambda params: Strategy(**params),
    param_grid={"rsi_threshold": [55, 60, 65], "atr_mult": [2.0, 3.0]},
    metric="sharpe",                # or 'cagr', 'calmar', 'sortino'
    refit_each_split=True,
)
# → DataFrame[ split_id, best_params, train_metric, validate_metric, test_metric ]
```

Hard rules:

- **Test period is touched exactly once** per split — no peek-back, no
  re-tuning. Out-of-sample equity is the concatenation of the test
  segments, never the train or validate segments.
- **Purge gap** of `holding_days + 1` between train and validate, and
  between validate and test, prevents a trade opened in train from
  closing inside validate (the leakage that makes most public Indian
  backtests look great).
- **Anchored mode** (`anchored=True`) keeps train start fixed and grows
  it; default is rolling.

---

## 5. HTML report (`report.py`)

Single self-contained HTML file (no external CDN, charts inlined as
SVG). Implementation: Jinja2 + a tiny SVG charting helper — no Plotly /
Bokeh / great_tables dependency. Output goes to
`reports/<run_id>/report.html` with a sibling `trades.parquet`,
`equity.parquet`, `metrics.json` for downstream analysis.

Sections:

1. **Header**: strategy name, capital, period, params, total trades,
   final equity, CAGR, Sharpe, Sortino, max DD, Calmar, win rate,
   payoff, expectancy, avg holding days, total costs paid (₹ and bps
   of turnover).
2. **Equity curve** (SVG) — strategy vs benchmark, log-scale toggle.
3. **Drawdown chart** (SVG, area chart) with worst 5 DDs annotated.
4. **Monthly returns heatmap** (SVG) — years × months, red/green.
5. **Trade log table** (HTML, sortable client-side via tiny JS) — one
   row per closed trade with entry / exit / qty / pnl / costs /
   exit-reason (`stop` / `target` / `time` / `trail` / `eod`).
6. **Cost breakdown** — pie / stacked bar of where the rupees went.
7. **Per-symbol attribution** — top 10 winners and losers by ₹ P&L.
8. **Run metadata** — git SHA, library version, seed, walk-forward
   split definition.

CLI:

```bash
nsefast backtest run    --strategy momentum_breakout \
                        --start 2018-01-01 --end 2025-12-31 \
                        --capital 1000000 --report reports/mb_2025
nsefast backtest report --run-id mb_2025                # re-render only
```

---

## 6. Benchmark comparison (`benchmark.py`)

Always-on. The engine fetches `history.load_symbol("NIFTY 50")` from
the existing index history (or a user-supplied benchmark frame) over
the same period, computes a buy-and-hold equity curve at the same
starting capital, and threads it through every report:

- Equity curve overlay.
- Alpha / beta vs benchmark (rolling 60-day + full-period).
- Information ratio.
- Capture ratio (up-capture, down-capture).
- Months strategy beat benchmark / vice versa.

Strategies that don't beat NIFTY 50 buy-and-hold *after costs* fail
the report's headline check (red banner at the top).

---

## 7. Out-of-scope for v0.3.0 (kept for v0.4.0+)

- Intraday bar resolution (engine is bar-close daily).
- Shorts and F&O legs.
- ML-driven scoring layer (the engine accepts any signal frame, so
  callers can plug ML in themselves).
- Optimizer beyond grid search (no Bayesian / evolutionary tuning).
- Live / paper trading bridge.

These are deliberately deferred so v0.3.0 ships small and correct.

---

## 8. Test plan (must be green before tagging 0.3.0)

- Engine: no-look-ahead invariant (random shuffle of future bars must
  not change historical fills); deterministic given seed; survives
  empty / single-bar / single-symbol inputs.
- Costs: round-trip on a known fixture matches an external Zerodha
  brokerage-calculator screenshot to ±₹1.
- Slippage: `FixedBps(0)` reduces to frictionless reference; oversized
  orders under `VolumeImpact` get split or rejected as configured.
- Walk-forward: no leakage — assert that any trade closed in the test
  period was opened on or after `test_start`.
- Report: HTML file renders standalone (assertion: open in headless
  browser, no console errors, all SVG nodes present).
- Benchmark: alpha vs `NIFTY 50` matches a manually-computed reference
  on a fixture.

Target: **+50 tests on top of the current 213**, all offline.

---

## 9. ML / AI layer (the real v0.3.0 differentiator)

The backtester from §1–§6 is the *honest measuring stick*. The ML layer
is what generates the signal it measures. Both ship together as
v0.3.0 — the engine validates the models, the models give the engine
something worth running.

### 9.1 Feature store (`nsefast/swing/features_ml.py`)

One job: materialize ~50 numeric features per `(symbol, trade_date)`
into hive-partitioned parquet, deterministic, fully vectorized,
re-runnable. Trains any downstream model offline; never re-fetches.

```
data/parquet/ml_features/
└── year=YYYY/month=MM/part.parquet
```

Schema (target ~50 cols, all `Float64` unless noted):

| Family            | Examples |
|-------------------|---|
| Identity          | `symbol` (Utf8), `trade_date` (Date) |
| Returns           | `ret_1d`, `ret_5d`, `ret_20d`, `ret_60d` |
| Log-returns       | `logret_1d`, `logret_5d`, `logret_20d` |
| Z-scores          | `mom_z_5/20/60`, `vol_z_5/20/60` (from `swing.scoring`) |
| Trend pack        | `sma_20/50/200_dist_pct`, `ema_20/50_dist_pct`, `adx_14` |
| Oscillators       | `rsi_14`, `macd_hist`, `bb_pctb_20`, `stoch_14` |
| Volatility        | `atr_14_pct`, `realized_vol_20`, `range_atr_14` |
| Volume            | `vol_to_avg_20`, `obv_z_20`, `delivery_pct`, `delivery_z_20` |
| Breakouts         | `dist_52w_high_pct`, `dist_52w_low_pct`, `donchian_20_breakout` (UInt8) |
| Relative strength | `rs_20`, `rs_60`, `rs_20_score` (vs NIFTY 50) |
| Microstructure    | `gap_pct`, `intrabar_pos` ((close-low)/(high-low)), `body_pct` |
| Calendar          | `day_of_week` (UInt8), `day_of_month` (UInt8), `is_expiry_week` (UInt8) |
| Event flags       | `had_announcement_5d`, `had_corp_action_5d`, `had_bulk_deal_5d` (UInt8) |
| Targets           | `fwd_ret_5d`, `fwd_ret_10d`, `fwd_max_up_5d`, `fwd_max_down_5d`, `up3_in_5d` (UInt8) |

API:

```python
from nsefast.swing.features_ml import build_features, load_features

build_features(start="2018-01-01", end="2025-12-31",
               symbols=None, benchmark="NIFTY 50",
               write_parquet=True)
# → DataFrame, also persisted under data/parquet/ml_features/

X = load_features(start="2024-01-01", end="2024-12-31",
                  drop_nulls=True, drop_target_leakage=True)
```

Hard rules:

- **Every feature uses `.over("symbol")` for per-symbol windows** —
  no cross-symbol leakage from naive rolling windows.
- **Targets are computed but explicitly tagged** (`fwd_*`,
  `target_*` prefix) so `drop_target_leakage=True` strips them when
  training serves predictions.
- **No NaN imputation in the store** — that's the model's job.
  Store carries the raw signal; downstream pipelines impute / clip /
  winsorize as needed.
- **Determinism**: identical inputs → identical parquet bytes.
  Tested via SHA-256 of the output file on a fixed fixture.

CLI:

```bash
nsefast features ml --start 2018-01-01 --end 2025-12-31
nsefast features ml --append --since latest
```

### 9.2 Starter models (`nsefast/swing/ml/`)

```
nsefast/swing/ml/
├── __init__.py
├── ranker.py          # cross-sectional LightGBM ranker
├── classifier.py      # binary up-move classifier
├── training.py        # walk-forward refit loop, model persistence
├── inference.py       # predict() helpers + score injection
└── calibration.py     # isotonic / Platt for the classifier
```

Both models are **opt-in** behind `pip install "nsefast[ml]"` so the
core library stays lean — `lightgbm`, `scikit-learn`, `joblib` only
load when imported.

**Model A — cross-sectional ranker (`ranker.py`).** Predicts the
**rank** of `fwd_ret_5d` *within each `trade_date` group*, not the
absolute return. Ranking is more robust to regime shifts than
regression.

```python
from nsefast.swing.ml.ranker import RankerModel

m = RankerModel(objective="lambdarank", n_estimators=400,
                learning_rate=0.05, num_leaves=63)
m.fit(X_train, group_col="trade_date", target_col="fwd_ret_5d")
scored = m.predict(X_today)        # adds 'ml_score' column (0-100, per-date pct rank)

# Drop straight into the existing scanner
top_upside(bhav.join(scored, on="symbol"), score_col="ml_score", n=20)
```

**Model B — direction classifier (`classifier.py`).** Predicts
`P(fwd_max_up_5d > 3%)` — a calibrated probability, much easier to
gate trades on than a noisy point return.

```python
from nsefast.swing.ml.classifier import DirectionClassifier

m = DirectionClassifier(model="lightgbm",        # or 'logistic'
                        target_col="up3_in_5d",
                        calibration="isotonic")  # post-fit calibration
m.fit(X_train)
probs = m.predict_proba(X_today)                 # → 'p_up3_5d' column

# Risk gate: only take ranker picks where the classifier agrees
gated = scored.filter(pl.col("p_up3_5d") > 0.55)
```

> **Why both, not one?** The ranker maximizes ordering on a fixed
> universe per day (good for the scanner's top-N); the classifier
> gives a per-trade probability you can size with (Kelly-fraction
> adjusted, fed straight into `portfolio_size(weight_col=...)`).
> Used together: ranker proposes, classifier vetoes.

### 9.3 Walk-forward training (`training.py`)

Reuses the **exact same** splitter from §4 (`walk_forward_splits`) —
one source of truth for time-series CV across both backtester and
ML modules. Models are refit monthly on a trailing **2-year window**
by default.

```python
from nsefast.swing.ml.training import walk_forward_train

results = walk_forward_train(
    model_factory=lambda: RankerModel(...),
    features=X_full,
    refit_freq="monthly",           # or 'weekly', 'quarterly'
    train_window_years=2,
    purge_days=10,                  # > max forward-target horizon
    save_dir="models/ranker_v1/",
)
# → DataFrame[ refit_date, train_period, validate_score, n_train_rows, model_path ]
```

Hard rules:

- **Refit on close of `refit_date`, predict for `(refit_date,
  next_refit_date)`** — no peek-back into the next refit window.
- **Purge gap** ≥ `max(forward_target_horizon)` between train end and
  prediction start so a training row with `fwd_ret_5d` can't see a
  prediction date inside its own forward window.
- **Models persist as joblib** under
  `models/<name>_v<ver>/<refit_date>.joblib` plus a `manifest.json`
  with feature list, hyperparams, library versions, and the SHA-256
  of the feature parquet they trained on. `inference.predict()`
  loads the most recent model whose `refit_date <= today`.
- **Feature schema is locked at fit time.** Inference asserts column
  set and dtypes match — schema drift fails loudly, never silently.

### 9.4 Optional LLM event tagger (`nsefast/swing/ml/event_tagger.py`)

Today, `corporate_announcement_watchlist` is substring matching on
the `subject` field — it misses phrasing variants and over-fires on
boilerplate. Replace with a small classifier that turns each
announcement subject (+ first ~500 chars of body) into a structured
tag:

```python
{
  "event_type":   "earnings" | "guidance" | "order_win" | "fundraise"
                | "buyback" | "split" | "bonus" | "dividend" | "merger"
                | "litigation" | "regulatory" | "rating_action" | "other",
  "sentiment":    -1.0 .. 1.0,           # bear → bull
  "materiality":  0.0 .. 1.0,            # boilerplate → market-moving
  "model":        "openai:gpt-4o-mini" | "anthropic:claude-haiku" | "local:bert-..."
                                          # provenance for audit
}
```

Architecture:

- **Pluggable backend.** A thin interface `EventTagger.tag(subject,
  body) -> EventTag` with three implementations:
  1. `OpenAITagger` — uses the project's existing AI Integrations
     (no user API key needed; uses the proxy).
  2. `AnthropicTagger` — same proxy.
  3. `LocalTagger` — distilled BERT shipped via HuggingFace,
     fully offline. Slower fit, zero per-call cost.
- **Cache by SHA-256(subject + body)** in
  `data/parquet/event_tags/year=YYYY/month=MM/`. Re-tagging the
  same announcement is free.
- **Batch API** with concurrency cap (default 5) and the existing
  polite-throttle decorator from `http_client`.
- **Fail-safe**: any backend error returns `EventTag(event_type="other",
  sentiment=0.0, materiality=0.0)` — never raises, downstream
  pipelines stay crash-proof.

API:

```python
from nsefast.swing.ml.event_tagger import tag_announcements

tagged = tag_announcements(
    corporate_announcements("2025-01-01", "2025-12-31"),
    backend="openai",     # or 'anthropic', 'local'
    cache=True,
)
# Adds: event_type, sentiment, materiality, tagger_model

# Now the watchlist is event-aware
material = tagged.filter((pl.col("materiality") > 0.6)
                        & pl.col("event_type").is_in(["earnings","order_win","guidance"])
                        & (pl.col("sentiment") > 0.3))
```

Tied into the feature store: §9.1's `had_announcement_5d` flag
becomes a richer `material_pos_event_5d` (UInt8) and
`avg_event_sentiment_20d` (Float64) once the tagger has run over the
history. The ML models (§9.2) pick those up automatically — no code
changes required, just rerun `build_features --append`.

### 9.5 Scope discipline

In v0.3.0:

- Feature store, two starter models, walk-forward training, LLM
  tagger — all behind `nsefast[ml]`.

Out of scope (v0.4.0+):

- Deep-learning models (Transformers, TFT, N-BEATS).
- Reinforcement-learning agents.
- AutoML / Bayesian hyperparameter search.
- Online / incremental learning.
- Real-time streaming inference (the backtester is bar-close daily).

### 9.6 Test plan additions

On top of §8's +50 engine tests, the ML layer adds **+30 tests**
(target ≈ 295 total at 0.3.0 release):

- Feature store: deterministic SHA on a fixture, schema lock, no
  cross-symbol leakage (random-shuffle invariance), every `fwd_*`
  column is null on the most recent N bars (no future leakage).
- Ranker: monotonic — higher `ml_score` ⇒ higher mean realized
  `fwd_ret_5d` on a held-out fold; per-date scores sum to expected
  rank-percentile distribution.
- Classifier: calibration error (Brier / ECE) below threshold on
  held-out data; `predict_proba` row-sums to 1.
- Walk-forward: model trained on split *k* never sees data from
  split *k+1*'s test window (assertion on row indices).
- Event tagger: cache hit returns identical tag bytes; backend
  failure path returns the safe-default tag and logs a warning.

## 10. Release sequencing

| Tag      | Contents |
|----------|---|
| `0.2.8`  | Wire smart-signals + risk engine into `swing.scanner`; new `swing.setups` module with 3-4 canonical setups end-to-end. *Pre-work for the backtester so it has real strategies to validate against.* |
| `0.3.0a` | Engine + costs + slippage; CLI scaffold; no walk-forward / report yet. |
| `0.3.0b` | Walk-forward splitter + tuner (shared by engine and ML). |
| `0.3.0c` | ML feature store (§9.1) + ranker + classifier (§9.2) + walk-forward training (§9.3). |
| `0.3.0d` | LLM event tagger (§9.4) — opt-in, behind `nsefast[ml]`. |
| `0.3.0`  | Report + benchmark comparator + full §8 + §9.6 test plan green. |

Each step ships to PyPI on its own, behind the same crash-proof
contract as the rest of the library.

---

## Appendix A — Locked decisions (2026-05-07)

These are the answers to the open scoping questions raised while
drafting §1–§9. They are **fixed for v0.3.0**; revisit only via a new
RFC.

| # | Decision | Rationale |
|---|---|---|
| **A1** | Default fill timing = **next-bar open** (`fill_when="next_open"`). `fill_when="close"` available as an explicit opt-in for fast sanity tests. | Matches how an EOD swing system actually trades. Same-bar-close fills systematically over-state P&L. |
| **A2** | HTML report renderer = **Jinja2 + a small hand-rolled SVG helper**. No Plotly / Bokeh / `great_tables` / CDN dependency. | Single self-contained HTML file, zero runtime dependencies, opens offline, reads cleanly in any browser. |
| **A3** | Forward-target horizon = **5 days** is the canonical target (`fwd_ret_5d`, `up3_in_5d`). The store also computes `fwd_ret_10d` so a 2-week horizon is one config flip away. | Pure swing-trading horizon. Long enough that costs don't dominate, short enough that signal-to-noise stays usable. |
| **A4** | LLM event tagger default = **OpenAI via the existing AI Integrations proxy**. `Anthropic` and offline `Local` (distilled BERT) backends also ship behind the same `EventTagger` interface. | Lowest-friction first run: no user API key required. Anthropic and Local exist as escape hatches for cost / privacy / offline workflows. |
| **A5** | Training & backtesting universe = **NIFTY 500 active-on-date** by default (uses `master.symbols_history.active_symbols_on`). `universe="all_listed"` is the explicit override. | Penny-stock and just-listed names dominate raw scanner outputs and inflate backtest P&L. NIFTY 500 active-on-date is the smallest universe a serious Indian swing book actually trades, and it composes cleanly with survivorship handling already in `master.symbols_history`. |
