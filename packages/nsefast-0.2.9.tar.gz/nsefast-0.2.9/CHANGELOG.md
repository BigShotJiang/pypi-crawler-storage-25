# Changelog

All notable changes to **nsefast** are documented in this file.
The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and the project adheres to [Semantic Versioning](https://semver.org/).

## [0.2.9] - 2026-05-07

### Fixed — risk-per-trade sizing in `nsefast.swing.setups` (post 0.2.8 review)

0.2.8 shipped the four canonical setups but a code review caught a
real semantic gap: every setup attached an ATR / chandelier stop, yet
``qty`` was computed as ``allocated_rs / entry_price`` — i.e.
*capital-weight* sizing, not *risk-per-trade* sizing. The stop was
attached but never used to size the position. Fixed in 0.2.9:

- New ``risk_pct`` parameter (default ``1.0`` %) on every setup. The
  rupee risk per trade is now ``risk_rs = allocated_rs * risk_pct/100``
  (so a 10% capital allocation at 1% risk-pct ⇒ 0.1% of total capital
  risked on this trade).
- ``qty`` is now ``floor(risk_rs / (entry - stop))`` — a stop-out
  costs exactly ``risk_rs``, the load-bearing invariant of
  position-risk sizing.
- New columns in ``BOOK_SCHEMA``: ``risk_rs`` (rupee risk budget)
  and ``notional_rs`` (= ``qty × entry_price``, the actual rupee
  exposure once shares are integer-rounded). Schema went from 14 to
  16 columns.
- ``portfolio_size``'s sector / cluster / single-name caps still
  govern the ``allocated_pct`` axis — ``risk_pct`` only scales the
  per-trade risk budget *within* that allocation. Caps remain
  load-bearing.

### Added tests

- Risk-per-trade invariant: ``qty * (entry - stop) ≤ risk_rs`` on
  every book row.
- ``risk_pct`` linearity: doubling ``risk_pct`` doubles ``qty`` for
  identical picks (modulo integer-floor rounding).
- Cluster-cap end-to-end: ``max_cluster_pct=25`` on a basket where
  ``correlation_clusters`` actually merges symbols caps the per-cluster
  ``allocated_pct`` at 25%. Closes the architect-flagged coverage gap.

**230 tests pass.**

## [0.2.8] - 2026-05-07

### Added — canonical end-to-end setups (`nsefast.swing.setups`)

Until now the smart-signals (`mom_z`, `rs_score`, `donchian_breakout`,
`consolidation_breakout`, `near_52w_high`) and the risk engine
(`add_atr_stop`, `add_chandelier_stop`, `portfolio_size`,
`correlation_clusters`) were primitives — useful but you had to wire
them together by hand. This release ships **four canonical NSE-swing
setups** that take a long-format OHLCV history and return a
ready-to-trade book in one call:

- `momentum_breakout_setup` — Donchian-N breakout filtered by RS rank
  vs a benchmark, sized with an ATR stop. Defaults: 20-bar Donchian,
  20-bar RS, top-40% RS gate, 2×ATR stop.
- `relative_strength_leaders_setup` — top RS leaders (60-bar default,
  top 20% gate) within 5% of the 52-week high. Minervini / IBD shape.
  Sized with a 2.5×ATR stop.
- `consolidation_breakout_setup` — VCP-style range-expansion
  breakout. Score = ATR-expansion ratio. Sized with a chandelier stop
  so winners can breathe.
- `mean_reversion_setup` — RSI-oversold (≤30) above the 200-SMA, sized
  with a tight 1.5×ATR stop. The contrarian counterpart to the trend
  setups.
- `all_setups` — runs all four with library defaults and concatenates
  the books, splitting capital evenly by default.

All five share the canonical book schema (`BOOK_SCHEMA`) so they
compose: stack them, filter by `setup` column, hand the union to a
broker terminal or a backtester. Every error path returns the same
empty-with-schema frame; setups never raise.

14 new tests cover canonical-empty contract on every input gap (empty
history, missing columns, zero capital, missing benchmark for
RS-leaders), plus end-to-end book emission, sector-cap respect, and
single-name cap respect on synthetic ramp panels. **228 tests pass.**

### Documentation

- `docs/V030_BACKTESTER.md` (the v0.3.0 design doc) gained an
  appendix locking the three open scoping decisions: forward-target
  horizon = **5 days** (10 days also computed); LLM tagger default =
  **OpenAI via the existing AI Integrations proxy** (Anthropic and
  local distilled-BERT also supported); training/backtesting
  universe = **NIFTY 500 active-on-date** by default
  (`universe="all_listed"` override).

## [0.2.7] - 2026-05-07

### Fixed — risk engine correctness (post 0.2.6 architect review)

- **`portfolio_size` is now a true water-fill allocator.** The 0.2.6
  implementation only scaled weights *down* against caps and never
  redistributed the freed weight to uncapped names — so e.g. raw
  weights `80/10/10` with a 60 % single cap produced `60/10/10`
  (only 80 % deployed) when `60/20/20` was feasible. Each pass now
  enforces caps, then redistributes any residual proportionally to
  *available headroom* (the smallest of single / sector / cluster
  room remaining), iterating until no headroom is left or the book
  is fully deployed. Cash residual still appears only when caps
  genuinely make full deployment infeasible.
- **`capped_by` recomputed from final weights.** Labels are no longer
  first-write-wins during iteration. After convergence each row is
  matched against every active constraint with a tight tolerance,
  with precedence **single → cluster → sector** (tightest scope first)
  when more than one cap binds simultaneously.
- **`correlation_clusters` is now pairwise NaN-tolerant.** The 0.2.6
  impl dropped any row containing a NaN across the *whole* sub-panel,
  which caused symbols with staggered listing histories to fall out
  into singleton clusters even when they had plenty of overlapping
  bars. Now each pair is correlated on the rows where both series are
  non-NaN (with a `min_overlap = max(5, lookback//4)` floor).
- **Docs:** `add_trailing_atr_stop` now documents the input-row-order
  monotonicity assumption (sort by `[symbol, trade_date]` first).

2 new regression tests for water-fill, 1 for staggered-NaN clustering.
213 in the suite green.

## [0.2.6] - 2026-05-07

### Added — risk engine

Per-trade sizing was already in v0.2.x; this release adds the
portfolio-level controls real swing desks actually run with.

#### `nsefast.swing.portfolio` (new module)

- `portfolio_size(picks, capital, *, max_positions=10, max_single_pct=10,
  max_sector_pct=30, max_cluster_pct=None, sector_col="sector",
  cluster_col="cluster_id", weight_col=None)` — equal-weight (or
  ``weight_col``-driven) allocation across the top ``max_positions``
  picks, then iteratively water-fills against single-name, sector, and
  optional cluster caps. Output: ``symbol``, ``weight``,
  ``allocated_pct``, ``allocated_rs``, ``capped_by``. Residual
  (cash) when caps bind is intentional.
- `correlation_clusters(history, symbols=None, *, lookback=60,
  threshold=0.7)` — greedy union-find on pairwise daily-log-return
  correlation; returns ``symbol`` / ``cluster_id``. Feed straight into
  ``portfolio_size(..., max_cluster_pct=...)`` so a TCS / INFY / WIPRO
  trio is treated as one cluster, not three independent bets.

#### `nsefast.swing.risk` (extended)

- `add_chandelier_stop(period=22, mult=3.0)` — rolling ``high.max(period)
  - mult * atr``. Tightens after pullbacks but rides trends.
- `add_trailing_atr_stop(period=14, mult=3.0)` — per-symbol cumulative
  max of ``close - mult * atr``. Never moves down once set.
- `add_swing_low_stop(window=10)` — rolling ``low.min(window)``. Pure
  price-action stop, no ATR dependency.
- `add_vol_target_size(capital, target_daily_vol_pct=0.5)` —
  vol-targeted sizing: ``qty = (capital * target_daily_vol_pct/100) / atr``.
  Each position contributes the same daily rupee P&L volatility, the
  way most quant desks actually size book.

All four compute ATR if it isn't already on the frame, and never raise.

#### Dependencies

- Added `numpy>=1.23` (used by `correlation_clusters` for the
  pairwise-correlation matrix).

17 new tests in `tests/test_risk_engine.py`; 211 in the suite green.

## [0.2.5] - 2026-05-07

### Fixed — signal correctness (post 0.2.4 architect review)

- **RSI edge cases.** `add_rsi` previously emitted `null` on zero-loss
  windows, which silently broke RSI in sustained uptrends. Now:
  `avg_loss == 0 & avg_gain > 0 ⇒ 100`,
  `avg_gain == 0 & avg_loss > 0 ⇒ 0`,
  `both zero ⇒ 50`, warm-up still `null`.
- **SuperTrend direction.** `st_dir` was effectively stuck at `+1`
  because it tested `close > st_lower` (lower band sits well below price).
  Corrected: `+1` only when `close > st_upper`, `-1` only when
  `close < st_lower`, otherwise `null`. Documented the basic-band
  semantics clearly.
- **Relative strength row fan-out.** `add_relative_strength` left-joined
  the benchmark by date without enforcing one row per date — duplicate
  benchmark dates would multiply price rows. Now deduplicates the
  benchmark to one row per `trade_date` (`group_by(date).last()`) so the
  output row count always equals the input price row count.

5 new regression tests; 194 in the suite green.

## [0.2.4] - 2026-05-07

### Added — smart signals

A full technical-indicator pack plus the multi-timeframe, relative-strength,
and breakout primitives that turn single-day scores into real swing setups.

#### `nsefast.processing.technicals` — full indicator pack

Each function takes a long-format frame and adds new column(s) per symbol
via `.over("symbol")`. Crash-proof; missing-column → input returned unchanged.

- `add_sma(n)`            → `sma_{n}`
- `add_ema(n)`            → `ema_{n}`
- `add_rsi(n)`            → `rsi_{n}`
- `add_macd(fast, slow, signal)` → `macd`, `macd_signal`, `macd_hist`
- `add_bollinger(n, k)`   → `bb_mid`, `bb_upper`, `bb_lower`
- `add_donchian(n)`       → `dc_upper`, `dc_lower`, `dc_mid`
- `add_supertrend(n, mult)` → `st_upper`, `st_lower`, `st_dir` (fully
  Polars-vectorised approximation; basic ATR bands without the
  path-dependent flip state machine)
- `add_adx(n)`            → `plus_di`, `minus_di`, `adx_{n}`
- `add_obv()`             → `obv` (per-symbol cumulative)
- `add_all_technicals()`  applies the full pack with library defaults
- Backwards-compatible thin wrappers `sma`, `ema`, `rsi`, `macd` retained.

#### `nsefast.swing.scoring` — multi-timeframe Z-scores

- `momentum_zscore(lookback=20)` — Z-score of per-symbol log-returns over
  `lookback` bars, output column `mom_z_{lookback}`.
- `volume_zscore(lookback=20)`   — Z-score of raw volume per symbol,
  `vol_z_{lookback}`.
- `add_multi_timeframe_zscores(lookbacks=(5, 20, 60))` — six-column bundle
  in one call.

These replace single-day `% change` ranking, which drowns in noise across
symbols. `Z > 1.5` is a meaningful move; `Z > 2.5` is exceptional.

#### `nsefast.swing.relative_strength` — leader detection

- `add_relative_strength(prices, benchmark, lookback=20)` — adds
  `rs_{lookback}` = symbol's lookback-day return *minus* the benchmark's,
  in percentage points. Pass NIFTY 50 for absolute leaders, a sector index
  for sector leaders.
- `add_rs_score(rs_col="rs_20")` — cross-sectional 0–100 percentile rank of
  the RS column *within each trade_date*, directly comparable across days.

#### `nsefast.swing.breakouts` — bread-and-butter swing setups

- `add_52w_high_low(window=252)` → `high_52w`, `low_52w` rolling extremes.
- `near_52w_high(within_pct=2.0)` — filter to candidates within `within_pct`
  of their 52-week high; adds `pct_below_52w_high` for ranking.
- `donchian_breakout(n=20)` — close exceeds the prior `n`-bar high (Turtle
  entry), excluding today's bar; adds `dc_prior_high`.
- `consolidation_breakout(atr_period=14, contraction_lookback=20,
  expansion_mult=1.5)` — VCP-style: today's ATR > `expansion_mult` × prior
  min ATR over `contraction_lookback`, AND close makes a 20-bar high.
- `add_gap_pct()` — `(open - prev_close) / prev_close × 100`. Uses the
  bhavcopy `prev_close` column when present, otherwise per-symbol shift.
- `add_range_atr(period=14)` — today's bar range divided by `atr_{period}`;
  values > 1 = expansion days.

26 new unit tests (all 189 in the suite green). Library-wide contract holds:
every function returns a Polars DataFrame and never raises.

## [0.2.3] - 2026-05-07

### Fixed — adjustment correctness

Follow-up to v0.2.2 after architect review:

- **Percentage dividends** (e.g. `"Dividend 250%"`) are now parsed correctly.
  `parse_purpose` returns a new `dividend_pct` action type;
  `compute_adjustment_factors` converts it to rupees using the
  `face_value` column on the corporate-actions row. When `face_value` is
  missing or non-positive, the row is *skipped*, never fabricated.
  `parse_purpose` also now matches `"Dividend 5/- per share"`.
- **Same-day multi-actions consolidated.** When a symbol has multiple
  corporate actions on the same `ex_date` (e.g. bonus + split together),
  `compute_adjustment_factors` now emits one row per `(symbol, ex_date)`
  whose `factor` is the product of all parsed factors and whose
  `action_type` joins the components with `+`. This matches the documented
  one-row-per-key contract and avoids downstream confusion.

### Docs

- Library-wide contract clarified in README: every **collector**,
  **processing**, and **swing** function returns a Polars DataFrame and
  never raises. Helper accessors (`available_dates`, `latest_date`,
  `active_symbols_on`, `is_active`, `delisted_symbols`) intentionally
  return primitives (`list[date]`, `date | None`, `list[str]`, `bool`) for
  ergonomics — they still never raise.

## [0.2.2] - 2026-05-07

### Added — data-quality layer

The single biggest source of "fake alpha" in swing-trading research is bad
history hygiene. v0.2.2 ships the four foundations every backtest needs:

- **`nsefast.history`** — multi-day OHLCV loader.
  - `load_range(start, end, symbols=..., series="EQ")` reads the
    hive-partitioned `equity_bhavcopy` store and returns a long-format frame
    (`symbol, trade_date, open, high, low, close, prev_close, volume,
    turnover`) with consistent dtypes.
  - `load_symbol`, `available_dates`, `latest_date` for point queries.
  - `save_bhavcopy(df, trade_date=...)` normalises raw NSE uppercase columns
    (`SYMBOL`, `TOTTRDQTY`, `TIMESTAMP`, …) and writes the partitioned store
    in one call.
  - `normalize_bhavcopy(df)` is exposed for users with their own pipelines.

- **`nsefast.processing.adjustments`** — split / bonus / dividend handling.
  - `parse_purpose(text)` decodes NSE's free-text `purpose` field
    (`"Stock Split From Rs.10/- to Rs.5/-"`, `"Bonus 1:1"`,
    `"Dividend - Rs 5"`, …) into `(action_type, factor_or_amount)`.
  - `compute_adjustment_factors(actions_df, prices_df=None)` emits one row
    per `(symbol, ex_date)` with the multiplicative `factor`. Dividends are
    skipped when no prior close is available — we never fabricate prices.
  - `apply_adjustments(prices, factors)` adds `adj_open / adj_high / adj_low
    / adj_close / adj_prev_close / adj_volume`. Cumulative factor is the
    product of every factor whose `ex_date` is strictly after the row's
    `trade_date`; volume is divided so per-share units stay comparable.

- **`nsefast.master.symbols_history`** — survivorship.
  - `build_symbols_history()` walks every saved bhavcopy partition and
    persists `(symbol, trade_date, series)` to
    `data/parquet/symbols_history/year=YYYY/`.
  - `active_symbols_on(d)`, `is_active(symbol, d)`, `delisted_symbols(after)`
    give O(1) point-in-time membership queries — so backtests don't
    accidentally see today's universe in 2020.

- **`nsefast.master.index_constituents`** — investable universes.
  - `index_constituents("NIFTY 50")` fetches the live constituent CSV from
    `archives.nseindia.com`, normalised to `symbol, company_name, industry,
    series, isin, index_name, source_url, fetched_at`.
  - `KNOWN_INDICES` covers ~21 NSE indices: NIFTY 50/100/200/500, Next 50,
    Midcap 50/100/150, Smallcap 50/100/250, Microcap 250, Bank, IT, Auto,
    FMCG, Pharma, Metal, Energy, Realty, Financial Services.
  - `historical_index_constituents(...)` is a documented scaffold with the
    final shape; implementation lands with the rebalance crawler in v0.3.0.

26 new unit tests (all 159 in the suite still green). Every new function
follows the library-wide contract: returns a Polars DataFrame on every path
and **never raises**.

## [0.2.1] - 2026-05-07

### Fixed

- `swing.scanner`, `swing.watchlist`, `swing.backtest` empty-frame schemas now
  use the **same dtypes** as the success path (e.g. `score: Float64`,
  `pnl_pct: Float64`, `traded_qty: Int64`). Previous releases returned all-Utf8
  empty frames, which broke downstream `.sort()` / numeric aggregations on
  empty days.
- `swing.risk.add_atr` docstring clarified: TR follows Wilder's definition,
  smoothing is SMA (not Wilder's RMA). Behaviour unchanged.

## [0.2.0] - 2026-05-07

### Added — `nsefast.swing` research layer

A new top-level package that turns collector outputs into ranked swing-trading
research. Architecture stays clean: `collectors/` fetch, `processing/` engineer
features, `swing/` ranks & sizes, `storage/` persists.

- `swing.filters` — `series_eq_only`, `price_band`, `liquid_universe`,
  `min_avg_volume`, `exclude_symbols`, `exclude_surveillance`. Compose via
  `df.pipe(...)`. Each filter is a no-op when its required column is missing.
- `swing.scoring` — `momentum_score`, `volume_score`, `delivery_score`, plus
  `composite_score(weights={...})` which renormalizes when components are
  absent. `add_all_scores(df)` runs the full pipeline.
- `swing.risk` — scalar `position_size`, `risk_reward`; vector helpers
  `add_atr` (Wilder TR over `(symbol, trade_date)`), `add_atr_stop`,
  `add_position_size`. ATR is grouped by symbol when the column is present.
- `swing.scanner` — `top_upside`, `top_downside`, `avoid_list`,
  `sector_leaders`, `delivery_breakout`, `volume_breakout`.
- `swing.watchlist` — `bulk_block_watchlist` (aggregates by symbol),
  `corporate_announcement_watchlist` (keyword-tagged), `combined_watchlist`
  (source-tagged union).
- `swing.backtest` — minimal `run_backtest(history, signal_fn, holding_days)`
  walk-forward simulator + `summary_stats` (trades, win-rate, avg/total/best/
  worst PnL, naive Sharpe). Full backtesting + ML scoring lands in v0.3.0.
- 33 new unit tests (132 total, still no network), covering scoring edge
  cases (zero-divide volume, clipping), filter no-ops, ATR pipeline, scanner
  ranking, watchlist deduplication, backtest forward returns.

### Guarantees

- Every public swing function returns a Polars DataFrame with a canonical
  schema and **never raises** — same crash-proof contract as collectors.
- Empty / malformed inputs produce empty (not failing) outputs, so research
  pipelines that span weekends or missing data continue to run cleanly.

## [0.1.1] - 2026-05-06

### Added

- **Hive-partitioned parquet** — `save_parquet_partitioned(df, dataset, by=[…])`,
  `read_parquet_partitioned(dataset, filters=[(col, op, val), …])`,
  `derive_date_partitions(df, "trade_date", parts=("year","month","day"))`,
  `list_partitions(dataset)`. Pushdown predicates handled by PyArrow.
- **DuckDB analytics helpers** — `connect()`, `register_all(con)` registers
  one view per dataset, plus canned queries `top_gainers`, `top_losers`,
  `daily_summary`, `sector_leaderboard`. All views read with
  `hive_partitioning = true, union_by_name = true`.
- **Request cache layer** — `nsefast.cache.cached_get(session, url, ttl_seconds)`
  is a content-addressed on-disk cache (`data/cache/<sha>.bin` + meta sidecar).
  Default TTL 5 min. Never raises, never caches non-200, expires cleanly.
  CLI: `nsefast cache stats`, `nsefast cache clear`.
- **Structured logging** — `nsefast.logging_setup.setup_logging(level, fmt)`
  with `fmt="json"` emits one-line JSON per record (ts, level, logger, msg,
  plus any `extra={…}`). Configurable via `NSEFAST_LOG_FORMAT=json` and
  `NSEFAST_LOG_LEVEL=DEBUG`.
- **Install verification CLI** — `nsefast verify` smoke-tests imports,
  parquet roundtrip, duckdb in-memory query, and CLI registration. Pass
  `--network` to additionally test NSE warm-up + robots.txt fetch.
  `nsefast version` prints the installed version.
- 22 new unit tests covering all of the above (99 total, still no network).

### Fixed

- DuckDB view registration now inlines the validated parquet glob path
  (DuckDB does not accept prepared parameters alongside `hive_partitioning`).
  Single quotes in the path are SQL-escaped.

## [0.1.0] - 2026-05-06

### Added

- Initial public release.
- Polite HTTP client with warm-up cookie session, retries, and `robots.txt` enforcement.
- Live JSON collectors with full graceful-failure semantics:
  - `deals.bulk_deals(start, end)`, `deals.block_deals(start, end)`
  - `corporate.corporate_announcements(start, end)`, `corporate.corporate_actions(start, end)`
  - `corporate.dividends`, `bonuses`, `splits`, `rights_issues`, `mergers_demergers`, `record_and_ex_dates`
  - `derivatives.option_chain(symbol)`, `option_chain_equity`, `option_chain_index`
  - `indices.all_indices()`, `indices.sector_strength()`, `indices.is_sector_index(name)`
  - `equity.fifty_two_week_high_low()`, `fifty_two_week_high()`, `fifty_two_week_low()`
- Daily archive collectors:
  - `equity.daily_bhavcopy(date)`, `equity.delivery_data(date)`
  - `derivatives.fo_bhavcopy(date)`
  - `master.symbol_master()`
- Polars-first dataframe layer with canonical schemas per collector.
- Parquet canonical storage (`storage.parquet_store`), DuckDB analytics views
  (`storage.duckdb_store`), optional PostgreSQL (`storage.postgres_store`).
- Typer CLI: `nsefast collect …`, `nsefast features swing`, `nsefast export parquet`.
- Optional Rust core (`rust-core/`) exposing `fast_hash`, `dedup`, `snake_case` via PyO3.
- 77 unit tests covering field mapping, alternate field names, malformed payloads,
  network failures, HTTP errors, JSON decode errors, robots.txt blocks, schema
  ordering, chunk-window arithmetic, CE/PE leg flattening, and sector classification.

### Notes

- All public collectors return a Polars DataFrame with the canonical schema on
  **any** failure (network, JSON, malformed payload, polars error, etc.) and
  never raise — pipelines stay crash-proof.
- NSE blocks many datacenter IP ranges; from such hosts, collectors will
  return empty DataFrames rather than crash.
