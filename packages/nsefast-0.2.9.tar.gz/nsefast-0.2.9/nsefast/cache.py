"""On-disk request cache for repeated NSE fetches.

The cache is a content-addressed store under ``data/cache/<sha>.bin`` with a
sidecar ``<sha>.meta.json`` carrying the URL, status, headers, expiry, and
fetch timestamp. Default TTL is 5 minutes for live endpoints and 1 day for
archive downloads.

Usage::

    from nsefast.cache import cached_get
    resp_bytes = cached_get(session, url, ttl_seconds=300)

The cache is read/write but is *crash-proof*: a corrupt or unreadable cache
entry is silently ignored and refetched. The cache is opt-in — collectors
must explicitly call ``cached_get`` to use it.
"""

from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Mapping

import requests

from nsefast.config import REQUEST_TIMEOUT_SECONDS
from nsefast.logging_setup import get_logger

CACHE_DIR = "data/cache"
DEFAULT_TTL_SECONDS = 300

log = get_logger(__name__)


def _key(url: str, params: Mapping[str, str] | None) -> str:
    parts = [url]
    if params:
        for k in sorted(params):
            parts.append(f"{k}={params[k]}")
    return hashlib.sha256("\x1f".join(parts).encode("utf-8")).hexdigest()


def _paths(key: str) -> tuple[Path, Path]:
    base = Path(CACHE_DIR)
    return base / f"{key}.bin", base / f"{key}.meta.json"


def _read_cache(key: str) -> bytes | None:
    body_path, meta_path = _paths(key)
    if not body_path.exists() or not meta_path.exists():
        return None
    try:
        meta = json.loads(meta_path.read_text())
        if meta.get("expires_at", 0) < time.time():
            return None
        if int(meta.get("status", 0)) != 200:
            return None
        return body_path.read_bytes()
    except Exception as exc:  # noqa: BLE001 — never let cache crash a fetch
        log.debug("cache read miss for %s: %s", key, exc)
        return None


def _write_cache(
    key: str, url: str, status: int, body: bytes, ttl_seconds: int
) -> None:
    body_path, meta_path = _paths(key)
    try:
        body_path.parent.mkdir(parents=True, exist_ok=True)
        body_path.write_bytes(body)
        meta_path.write_text(
            json.dumps(
                {
                    "url": url,
                    "status": status,
                    "fetched_at": time.time(),
                    "expires_at": time.time() + ttl_seconds,
                    "size_bytes": len(body),
                }
            )
        )
    except Exception as exc:  # noqa: BLE001
        log.debug("cache write failed for %s: %s", key, exc)


def cached_get(
    session: requests.Session,
    url: str,
    *,
    params: Mapping[str, str] | None = None,
    ttl_seconds: int = DEFAULT_TTL_SECONDS,
    timeout: int = REQUEST_TIMEOUT_SECONDS,
) -> bytes | None:
    """Return response body bytes, served from cache when fresh.

    Returns ``None`` on network failure or non-200 responses. Never raises.
    """
    key = _key(url, params)
    cached = _read_cache(key)
    if cached is not None:
        log.debug("cache hit", extra={"url": url})
        return cached

    try:
        resp = session.get(url, params=params, timeout=timeout)
    except Exception as exc:  # noqa: BLE001
        log.warning("fetch failed", extra={"url": url, "err": str(exc)})
        return None

    if resp.status_code != 200:
        log.warning(
            "non-200", extra={"url": url, "status": resp.status_code}
        )
        return None

    _write_cache(key, url, resp.status_code, resp.content, ttl_seconds)
    return resp.content


def clear_cache() -> int:
    """Delete all cached entries. Returns the number of files removed."""
    base = Path(CACHE_DIR)
    if not base.exists():
        return 0
    count = 0
    for f in base.glob("*"):
        try:
            f.unlink()
            count += 1
        except OSError:
            pass
    return count


def cache_stats() -> dict:
    """Return ``{entries, size_bytes, oldest_age_seconds}``."""
    base = Path(CACHE_DIR)
    if not base.exists():
        return {"entries": 0, "size_bytes": 0, "oldest_age_seconds": 0}
    bin_files = list(base.glob("*.bin"))
    size = sum(f.stat().st_size for f in bin_files)
    now = time.time()
    oldest = max((now - f.stat().st_mtime for f in bin_files), default=0)
    return {
        "entries": len(bin_files),
        "size_bytes": size,
        "oldest_age_seconds": int(oldest),
    }
