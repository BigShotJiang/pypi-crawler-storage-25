"""Storage backends: Parquet (canonical), DuckDB (analytics), Postgres (optional)."""
