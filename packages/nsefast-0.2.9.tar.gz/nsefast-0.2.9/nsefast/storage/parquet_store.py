"""Partitioned Parquet storage.

Two partitioning modes:

1. **Manual partition** (legacy, backward compatible)::

       save_parquet(df, dataset="bulk_deals", partition="2026-05-07")
       # -> data/parquet/bulk_deals/2026-05-07/part.parquet

2. **Hive partitioning** by columns (recommended for large datasets)::

       save_parquet_partitioned(df, dataset="daily_bhavcopy",
                                by=["year", "month"])
       # -> data/parquet/daily_bhavcopy/year=2026/month=05/*.parquet

Hive-partitioned reads support pushdown predicates via ``read_parquet_partitioned``.
"""

from __future__ import annotations

from pathlib import Path

import polars as pl
import pyarrow as pa
import pyarrow.dataset as pads
import pyarrow.parquet as pq

from nsefast.config import PARQUET_DIR
from nsefast.logging_setup import get_logger

log = get_logger(__name__)


def save_parquet(
    df: pl.DataFrame,
    dataset: str,
    partition: str | None = None,
) -> str:
    """Write `df` under ``data/parquet/<dataset>[/<partition>]/part.parquet``."""
    base = Path(PARQUET_DIR) / dataset
    if partition:
        base = base / partition
    base.mkdir(parents=True, exist_ok=True)

    path = base / "part.parquet"
    df.write_parquet(path)
    log.info(
        "parquet write",
        extra={"dataset": dataset, "partition": partition,
               "rows": df.height, "path": str(path)},
    )
    return str(path)


def save_parquet_partitioned(
    df: pl.DataFrame,
    dataset: str,
    by: list[str],
) -> str:
    """Write `df` as a hive-partitioned dataset.

    The partition columns must already exist in the DataFrame. Use
    ``derive_date_partitions`` to add ``year``/``month``/``day`` from a
    date column.
    """
    if df.is_empty():
        log.debug("partitioned write skipped — empty df", extra={"dataset": dataset})
        return str(Path(PARQUET_DIR) / dataset)

    missing = [c for c in by if c not in df.columns]
    if missing:
        raise ValueError(
            f"partition columns {missing} not present in df columns {df.columns}"
        )

    base = Path(PARQUET_DIR) / dataset
    base.mkdir(parents=True, exist_ok=True)

    table: pa.Table = df.to_arrow()
    pq.write_to_dataset(
        table,
        root_path=str(base),
        partition_cols=by,
        existing_data_behavior="overwrite_or_ignore",
    )
    log.info(
        "parquet hive write",
        extra={"dataset": dataset, "by": by,
               "rows": df.height, "path": str(base)},
    )
    return str(base)


def derive_date_partitions(
    df: pl.DataFrame,
    date_col: str,
    parts: tuple[str, ...] = ("year", "month"),
) -> pl.DataFrame:
    """Add ``year``/``month``/``day`` integer columns derived from ``date_col``.

    Only columns named in ``parts`` are added. ``date_col`` may be a
    Polars Date/Datetime, or a string in ``YYYY-MM-DD`` format.
    """
    if date_col not in df.columns:
        raise ValueError(f"date column {date_col!r} not in df.columns={df.columns}")

    dt = df[date_col]
    if dt.dtype == pl.Utf8:
        dt = dt.str.strptime(pl.Date, format="%Y-%m-%d", strict=False)

    add: list[pl.Expr] = []
    if "year" in parts:
        add.append(dt.dt.year().alias("year"))
    if "month" in parts:
        add.append(dt.dt.month().alias("month"))
    if "day" in parts:
        add.append(dt.dt.day().alias("day"))
    return df.with_columns(add)


def read_parquet(dataset: str) -> pl.DataFrame:
    """Read every parquet file under a dataset directory (recursive)."""
    path = Path(PARQUET_DIR) / dataset
    if not path.exists():
        return pl.DataFrame()
    return pl.scan_parquet(str(path / "**/*.parquet")).collect()


def read_parquet_partitioned(
    dataset: str,
    filters: list[tuple[str, str, object]] | None = None,
) -> pl.DataFrame:
    """Read a hive-partitioned dataset with optional pushdown predicates.

    ``filters`` is a list of ``(column, op, value)`` tuples, e.g.::

        [("year", "==", 2026), ("month", ">=", 4)]
    """
    path = Path(PARQUET_DIR) / dataset
    if not path.exists():
        return pl.DataFrame()

    try:
        ds = pads.dataset(str(path), format="parquet", partitioning="hive")
        expr = None
        if filters:
            for col, op, val in filters:
                f = pads.field(col)
                clause = {
                    "==": f == val, "!=": f != val,
                    "<": f < val, "<=": f <= val,
                    ">": f > val, ">=": f >= val,
                }[op]
                expr = clause if expr is None else expr & clause
        table = ds.to_table(filter=expr)
        return pl.from_arrow(table)
    except Exception as exc:  # noqa: BLE001
        log.warning("partitioned read failed", extra={"dataset": dataset, "err": str(exc)})
        return pl.DataFrame()


def list_partitions(dataset: str) -> list[str]:
    """List partition subdirectories under a dataset (one level deep)."""
    path = Path(PARQUET_DIR) / dataset
    if not path.exists():
        return []
    return sorted(p.name for p in path.iterdir() if p.is_dir())
