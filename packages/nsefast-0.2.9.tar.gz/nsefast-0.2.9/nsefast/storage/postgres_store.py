"""Optional PostgreSQL storage. Requires ``pip install nsefast[postgres]``."""

from __future__ import annotations

import logging

import polars as pl

log = logging.getLogger(__name__)


def write_table(df: pl.DataFrame, table: str, conn_uri: str, if_exists: str = "append") -> int:
    """Write a Polars DataFrame to Postgres via SQLAlchemy/pandas.

    Returns the number of rows written. Lazily imports SQLAlchemy so the
    optional dependency isn't required for core usage.
    """
    try:
        from sqlalchemy import create_engine
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError(
            "PostgreSQL support requires sqlalchemy. Install with `pip install nsefast[postgres]`."
        ) from exc

    if df.is_empty():
        return 0

    engine = create_engine(conn_uri)
    pdf = df.to_pandas()
    pdf.to_sql(table, engine, if_exists=if_exists, index=False)
    return len(pdf)
