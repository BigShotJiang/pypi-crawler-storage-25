"""Equity collectors: bhavcopy, security-wise price/volume, gainers/losers, etc.

Most NSE equity data is published as daily ZIP/CSV reports under
``archives.nseindia.com``. The functions here build the canonical archive URLs
and return parsed Polars DataFrames.
"""

from __future__ import annotations

import io
import logging
import time
import zipfile
from datetime import date, datetime, timezone
from pathlib import Path

import polars as pl

from nsefast.config import (
    ARCHIVES_URL,
    BASE_URL,
    RAW_DIR,
    REQUEST_DELAY_SECONDS,
    REQUEST_TIMEOUT_SECONDS,
)
from nsefast.http_client import create_session
from nsefast.robots import can_fetch

log = logging.getLogger(__name__)


def _fmt_date(d: date | str) -> date:
    if isinstance(d, str):
        return datetime.strptime(d, "%Y-%m-%d").date()
    return d


def daily_bhavcopy(d: date | str) -> pl.DataFrame:
    """Equity daily bhavcopy. Published path:
    ``/content/historical/EQUITIES/<YYYY>/<MMM>/cm<DDMMMYYYY>bhav.csv.zip``
    """
    target = _fmt_date(d)
    yyyy = target.strftime("%Y")
    mmm = target.strftime("%b").upper()
    ddmmmyyyy = target.strftime("%d%b%Y").upper()
    url = f"{ARCHIVES_URL}/content/historical/EQUITIES/{yyyy}/{mmm}/cm{ddmmmyyyy}bhav.csv.zip"

    if not can_fetch(url):
        log.info("robots disallows %s", url)
        return pl.DataFrame()

    session = create_session()
    resp = session.get(url, timeout=30)
    if resp.status_code != 200:
        log.warning("bhavcopy %s -> HTTP %s", target, resp.status_code)
        return pl.DataFrame()

    Path(RAW_DIR).mkdir(parents=True, exist_ok=True)
    raw_path = Path(RAW_DIR) / f"cm{ddmmmyyyy}bhav.csv.zip"
    raw_path.write_bytes(resp.content)

    with zipfile.ZipFile(io.BytesIO(resp.content)) as zf:
        name = next((n for n in zf.namelist() if n.lower().endswith(".csv")), None)
        if not name:
            return pl.DataFrame()
        with zf.open(name) as fh:
            return pl.read_csv(fh.read(), try_parse_dates=True)


def security_wise_price_volume(symbol: str, start: date | str, end: date | str) -> pl.DataFrame:
    """Placeholder for security-wise price/volume archive.

    NSE serves this data via the public historical reports page. Implement the
    full crawl by walking the historical archive once you've confirmed the
    target URL pattern is permitted by robots.txt.
    """
    log.info(
        "security_wise_price_volume(%s, %s, %s) — not yet implemented",
        symbol,
        start,
        end,
    )
    return pl.DataFrame()


def historical_ohlcv(symbol: str, start: date | str, end: date | str) -> pl.DataFrame:
    """Historical OHLCV — typically derived from bhavcopy archives."""
    log.info("historical_ohlcv(%s, %s, %s) — not yet implemented", symbol, start, end)
    return pl.DataFrame()


def delivery_data(d: date | str) -> pl.DataFrame:
    """MTO (deliverable quantity) report for a date.

    Path: ``/archives/equities/mto/MTO_<DDMMYYYY>.DAT``
    """
    target = _fmt_date(d)
    ddmmyyyy = target.strftime("%d%m%Y")
    url = f"{ARCHIVES_URL}/archives/equities/mto/MTO_{ddmmyyyy}.DAT"

    if not can_fetch(url):
        return pl.DataFrame()

    session = create_session()
    resp = session.get(url, timeout=30)
    if resp.status_code != 200:
        log.warning("delivery %s -> HTTP %s", target, resp.status_code)
        return pl.DataFrame()

    # MTO files have a 4-line header before CSV-like rows.
    text = resp.text.splitlines()
    body = "\n".join(text[4:])
    try:
        return pl.read_csv(body.encode(), has_header=False, new_columns=[
            "record_type", "sr_no", "symbol", "series",
            "total_traded_qty", "deliverable_qty", "delivery_pct",
        ])
    except Exception as exc:  # noqa: BLE001
        log.warning("parse MTO failed: %s", exc)
        return pl.DataFrame()


def most_active() -> pl.DataFrame:
    """Most active securities — sourced from the live market-data JSON feed."""
    log.info("most_active — not yet implemented")
    return pl.DataFrame()


def top_gainers() -> pl.DataFrame:
    log.info("top_gainers — not yet implemented")
    return pl.DataFrame()


def top_losers() -> pl.DataFrame:
    log.info("top_losers — not yet implemented")
    return pl.DataFrame()


_FIFTY_TWO_WEEK_URL = f"{BASE_URL}/api/live-analysis-52Week"
_FIFTY_TWO_WEEK_REFERER = f"{BASE_URL}/market-data/52-week-high-equity-market"

_FIFTY_TWO_WEEK_COLUMNS = [
    "symbol",
    "series",
    "company_name",
    "category",            # "high" or "low"
    "last_price",
    "prev_high_low",
    "prev_high_low_date",
    "change",
    "percent_change",
    "source_url",
    "fetched_at",
]

_FIFTY_TWO_WEEK_ALIASES: dict[str, tuple[str, ...]] = {
    "symbol":             ("symbol",),
    "series":             ("series",),
    "company_name":       ("companyName", "company"),
    "last_price":         ("ltp", "lastPrice", "new52WHL"),
    "prev_high_low":      ("prev52WHL", "prevHigh", "prevLow"),
    "prev_high_low_date": ("prev52WHLD", "prevHighDate", "prevLowDate"),
    "change":             ("change",),
    "percent_change":     ("pChange", "percentChange"),
}


def _pick_52w(d: dict, keys: tuple[str, ...]):
    for k in keys:
        if k in d and d[k] not in (None, ""):
            return d[k]
    return None


def _flatten_52w(payload, source_url: str, fetched_at: str) -> pl.DataFrame:
    """Flatten /api/live-analysis-52Week payload. Both ``dataHigh`` and
    ``dataLow`` are emitted into the same DataFrame, distinguished by the
    ``category`` column. Never raises."""
    if not isinstance(payload, dict):
        return pl.DataFrame(schema={c: pl.Utf8 for c in _FIFTY_TWO_WEEK_COLUMNS})

    rows: list[dict] = []
    for category, key in (("high", "dataHigh"), ("low", "dataLow")):
        bucket = payload.get(key)
        if not isinstance(bucket, list):
            continue
        for entry in bucket:
            if not isinstance(entry, dict):
                continue
            try:
                row = {
                    col: _pick_52w(entry, _FIFTY_TWO_WEEK_ALIASES.get(col, (col,)))
                    for col in _FIFTY_TWO_WEEK_COLUMNS
                    if col not in ("category", "source_url", "fetched_at")
                }
                row["category"] = category
                row["source_url"] = source_url
                row["fetched_at"] = fetched_at
                rows.append(row)
            except Exception as exc:  # noqa: BLE001
                log.warning("skipping malformed 52w entry: %s", exc)
                continue

    if not rows:
        return pl.DataFrame(schema={c: pl.Utf8 for c in _FIFTY_TWO_WEEK_COLUMNS})

    try:
        df = pl.DataFrame(rows, infer_schema_length=len(rows))
    except Exception as exc:  # noqa: BLE001
        log.warning("52w construction failed: %s", exc)
        return pl.DataFrame(schema={c: pl.Utf8 for c in _FIFTY_TWO_WEEK_COLUMNS})

    casts: list[pl.Expr] = []
    for col in ("last_price", "prev_high_low", "change", "percent_change"):
        if col in df.columns:
            casts.append(
                pl.col(col).cast(pl.Utf8, strict=False)
                .str.replace_all(",", "")
                .cast(pl.Float64, strict=False).alias(col)
            )
    if casts:
        try:
            df = df.with_columns(casts)
        except Exception as exc:  # noqa: BLE001
            log.warning("52w numeric cast failed: %s", exc)

    for col in _FIFTY_TWO_WEEK_COLUMNS:
        if col not in df.columns:
            df = df.with_columns(pl.lit(None).alias(col))
    return df.select(_FIFTY_TWO_WEEK_COLUMNS)


def _fetch_52w() -> pl.DataFrame:
    if not can_fetch(_FIFTY_TWO_WEEK_URL):
        log.info("robots.txt disallows %s", _FIFTY_TWO_WEEK_URL)
        return pl.DataFrame(schema={c: pl.Utf8 for c in _FIFTY_TWO_WEEK_COLUMNS})

    headers = {
        "Accept": "application/json, text/plain, */*",
        "Referer": _FIFTY_TWO_WEEK_REFERER,
        "X-Requested-With": "XMLHttpRequest",
    }
    try:
        session = create_session()
        resp = session.get(_FIFTY_TWO_WEEK_URL, headers=headers, timeout=REQUEST_TIMEOUT_SECONDS)
    except Exception as exc:  # noqa: BLE001
        log.warning("52w fetch failed: %s", exc)
        return pl.DataFrame(schema={c: pl.Utf8 for c in _FIFTY_TWO_WEEK_COLUMNS})

    if resp.status_code != 200:
        log.warning("52w -> HTTP %s", resp.status_code)
        return pl.DataFrame(schema={c: pl.Utf8 for c in _FIFTY_TWO_WEEK_COLUMNS})

    try:
        payload = resp.json()
    except Exception as exc:  # noqa: BLE001
        log.warning("52w JSON decode failed: %s", exc)
        return pl.DataFrame(schema={c: pl.Utf8 for c in _FIFTY_TWO_WEEK_COLUMNS})

    fetched_at = datetime.now(timezone.utc).isoformat()
    try:
        df = _flatten_52w(payload, _FIFTY_TWO_WEEK_URL, fetched_at)
    except Exception as exc:  # noqa: BLE001
        log.warning("52w flatten failed: %s", exc)
        df = pl.DataFrame(schema={c: pl.Utf8 for c in _FIFTY_TWO_WEEK_COLUMNS})

    time.sleep(REQUEST_DELAY_SECONDS)
    return df


def fifty_two_week_high_low() -> pl.DataFrame:
    """Securities hitting fresh 52-week highs and lows today.

    Canonical schema: ``symbol, series, company_name, category, last_price,
    prev_high_low, prev_high_low_date, change, percent_change, source_url,
    fetched_at``. ``category`` is ``"high"`` or ``"low"``. Empty DataFrame
    on any failure.
    """
    try:
        return _fetch_52w()
    except Exception as exc:  # noqa: BLE001
        log.warning("fifty_two_week_high_low failed: %s", exc)
        return pl.DataFrame(schema={c: pl.Utf8 for c in _FIFTY_TWO_WEEK_COLUMNS})


def fifty_two_week_high() -> pl.DataFrame:
    """Securities at fresh 52-week highs today (filtered slice)."""
    df = fifty_two_week_high_low()
    if df.is_empty() or "category" not in df.columns:
        return df
    return df.filter(pl.col("category") == "high")


def fifty_two_week_low() -> pl.DataFrame:
    """Securities at fresh 52-week lows today (filtered slice)."""
    df = fifty_two_week_high_low()
    if df.is_empty() or "category" not in df.columns:
        return df
    return df.filter(pl.col("category") == "low")


def upper_lower_circuit() -> pl.DataFrame:
    log.info("upper_lower_circuit — not yet implemented")
    return pl.DataFrame()


def advances_declines() -> pl.DataFrame:
    log.info("advances_declines — not yet implemented")
    return pl.DataFrame()
