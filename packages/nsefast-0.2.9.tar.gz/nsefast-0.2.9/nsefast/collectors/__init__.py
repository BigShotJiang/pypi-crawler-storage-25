"""Data collectors. One module per NSE data domain."""
