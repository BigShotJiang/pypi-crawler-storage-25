"""Historical archive walker (capital market daily/monthly archives)."""

from __future__ import annotations

import logging
from datetime import date, timedelta

import polars as pl

from nsefast.collectors.equity import daily_bhavcopy

log = logging.getLogger(__name__)


def historical_bhavcopy_range(start: date, end: date) -> pl.DataFrame:
    """Concatenate daily bhavcopies between `start` and `end` (inclusive)."""
    frames: list[pl.DataFrame] = []
    cur = start
    while cur <= end:
        df = daily_bhavcopy(cur)
        if not df.is_empty():
            df = df.with_columns(pl.lit(cur.isoformat()).alias("trade_date"))
            frames.append(df)
        cur += timedelta(days=1)

    if not frames:
        return pl.DataFrame()
    return pl.concat(frames, how="diagonal_relaxed")


# ---- daily / monthly / archival market reports --------------------------
# These are PDF/CSV reports linked from the NSE "all reports" page. Use
# `collectors.report_links.collect_report_links()` to enumerate live URLs,
# then download via `http_client.download_file()`.

def settlement_statistics(start, end) -> pl.DataFrame:
    log.info("settlement_statistics(%s, %s) — scaffold", start, end)
    return pl.DataFrame()


def internet_trading_reports(start, end) -> pl.DataFrame:
    log.info("internet_trading_reports(%s, %s) — scaffold", start, end)
    return pl.DataFrame()


def business_growth_reports(start, end) -> pl.DataFrame:
    log.info("business_growth_reports(%s, %s) — scaffold", start, end)
    return pl.DataFrame()


def turnover_reports(start, end) -> pl.DataFrame:
    log.info("turnover_reports(%s, %s) — scaffold", start, end)
    return pl.DataFrame()
