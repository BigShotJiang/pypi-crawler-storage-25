"""Bulk / block / large deals and short selling.

Bulk and block deals are served by NSE's public JSON endpoints behind the
``/market-data/bulk-and-block-deals`` page. Both endpoints share the same
response shape (``{"data": [...]}``) and date convention (``DD-MM-YYYY``),
so we share parsing.

All collectors are defensive: any network or parse failure is logged and an
empty Polars DataFrame is returned so downstream pipelines never break.
"""

from __future__ import annotations

import logging
import time
from datetime import date, datetime, timedelta
from typing import Any, Iterable

import polars as pl

from nsefast.config import BASE_URL, REQUEST_DELAY_SECONDS, REQUEST_TIMEOUT_SECONDS
from nsefast.http_client import create_session
from nsefast.robots import can_fetch

log = logging.getLogger(__name__)

_BULK_DEALS_URL = f"{BASE_URL}/api/historical/bulk-deals"
_BLOCK_DEALS_URL = f"{BASE_URL}/api/historical/block-deals"
_DEALS_REFERER = f"{BASE_URL}/market-data/bulk-and-block-deals"

# NSE caps each historical query window — chunk longer ranges.
_MAX_WINDOW_DAYS = 90

# Canonical output schema. Every row in the returned DataFrame conforms to it.
_CANONICAL_COLUMNS = [
    "date",
    "symbol",
    "security_name",
    "client_name",
    "buy_sell",
    "quantity",
    "price",
    "remarks",
    "source_url",
]


def _to_date(d: date | str) -> date:
    if isinstance(d, str):
        return datetime.strptime(d, "%Y-%m-%d").date()
    return d


def _fmt_nse_date(d: date) -> str:
    return d.strftime("%d-%m-%Y")


def _chunk_ranges(start: date, end: date, max_days: int = _MAX_WINDOW_DAYS) -> Iterable[tuple[date, date]]:
    cur = start
    while cur <= end:
        chunk_end = min(cur + timedelta(days=max_days - 1), end)
        yield cur, chunk_end
        cur = chunk_end + timedelta(days=1)


# Field-name candidates (NSE has used a few spellings over time).
_FIELD_ALIASES: dict[str, tuple[str, ...]] = {
    "date":          ("BD_DT_DATE", "date", "BD_TIMESTAMP"),
    "symbol":        ("BD_SYMBOL", "symbol"),
    "security_name": ("BD_SCRIP_NAME", "BD_SECURITY", "security"),
    "client_name":   ("BD_CLIENT_NAME", "client"),
    "buy_sell":      ("BD_BUY_SELL", "buyOrSell"),
    "quantity":      ("BD_QTY_TRD", "quantity"),
    "price":         ("BD_TP_WATP", "BD_TP_PRICE", "tradePrice", "wap"),
    "remarks":       ("BD_REMARKS", "remarks"),
}


def _pick(row: dict[str, Any], aliases: tuple[str, ...]) -> Any:
    for key in aliases:
        if key in row and row[key] not in (None, ""):
            return row[key]
    return None


def _empty() -> pl.DataFrame:
    return pl.DataFrame(schema={c: pl.Utf8 for c in _CANONICAL_COLUMNS})


def _normalize_rows(rows: list[dict[str, Any]], source_url: str) -> pl.DataFrame:
    """Project NSE's raw JSON rows onto the canonical schema. Never raises."""
    if not rows:
        return _empty()

    out: list[dict[str, Any]] = []
    for row in rows:
        if not isinstance(row, dict):
            # Skip malformed entries silently; they shouldn't poison the batch.
            continue
        try:
            out.append(
                {
                    "date":          _pick(row, _FIELD_ALIASES["date"]),
                    "symbol":        _pick(row, _FIELD_ALIASES["symbol"]),
                    "security_name": _pick(row, _FIELD_ALIASES["security_name"]),
                    "client_name":   _pick(row, _FIELD_ALIASES["client_name"]),
                    "buy_sell":      _pick(row, _FIELD_ALIASES["buy_sell"]),
                    "quantity":      _pick(row, _FIELD_ALIASES["quantity"]),
                    "price":         _pick(row, _FIELD_ALIASES["price"]),
                    "remarks":       _pick(row, _FIELD_ALIASES["remarks"]),
                    "source_url":    source_url,
                }
            )
        except Exception as exc:  # noqa: BLE001
            log.warning("skipping malformed deal row: %s", exc)
            continue

    if not out:
        return _empty()

    try:
        df = pl.DataFrame(out, infer_schema_length=len(out))
    except Exception as exc:  # noqa: BLE001
        log.warning("polars construction failed: %s", exc)
        return _empty()

    # Cast numerics where present (NSE returns numbers as strings sometimes).
    casts = []
    if "quantity" in df.columns:
        casts.append(pl.col("quantity").cast(pl.Int64, strict=False).alias("quantity"))
    if "price" in df.columns:
        casts.append(
            pl.col("price")
            .cast(pl.Utf8, strict=False)
            .str.replace_all(",", "")
            .cast(pl.Float64, strict=False)
            .alias("price")
        )
    if casts:
        try:
            df = df.with_columns(casts)
        except Exception as exc:  # noqa: BLE001
            log.warning("numeric cast failed: %s", exc)

    return df


def _fetch_deals(url: str, start: date, end: date) -> pl.DataFrame:
    """Generic GET against an NSE historical-deals JSON endpoint."""
    if not can_fetch(url):
        log.info("robots.txt disallows %s", url)
        return _empty()

    session = create_session()
    # NSE's JSON endpoints require an XHR-ish Accept + a Referer to the
    # human-facing page, in addition to the warm-up cookies.
    headers = {
        "Accept": "application/json, text/plain, */*",
        "Referer": _DEALS_REFERER,
        "X-Requested-With": "XMLHttpRequest",
    }

    frames: list[pl.DataFrame] = []
    for chunk_start, chunk_end in _chunk_ranges(start, end):
        params = {"from": _fmt_nse_date(chunk_start), "to": _fmt_nse_date(chunk_end)}
        try:
            resp = session.get(
                url,
                params=params,
                headers=headers,
                timeout=REQUEST_TIMEOUT_SECONDS,
            )
        except Exception as exc:  # noqa: BLE001 — defensive fallback
            log.warning("deals fetch failed (%s..%s): %s", chunk_start, chunk_end, exc)
            time.sleep(REQUEST_DELAY_SECONDS)
            continue

        if resp.status_code != 200:
            log.warning(
                "deals %s..%s -> HTTP %s",
                chunk_start, chunk_end, resp.status_code,
            )
            time.sleep(REQUEST_DELAY_SECONDS)
            continue

        try:
            payload = resp.json()
        except Exception as exc:  # noqa: BLE001
            log.warning("deals JSON decode failed: %s", exc)
            time.sleep(REQUEST_DELAY_SECONDS)
            continue

        rows = payload.get("data") if isinstance(payload, dict) else payload
        if not isinstance(rows, list):
            log.warning("deals payload missing 'data' list")
            time.sleep(REQUEST_DELAY_SECONDS)
            continue

        # Build a stable source URL for traceability.
        traceable = f"{url}?from={params['from']}&to={params['to']}"
        try:
            df = _normalize_rows(rows, traceable)
            if not df.is_empty():
                frames.append(df)
        except Exception as exc:  # noqa: BLE001 — never crash the pipeline
            log.warning("deals normalize failed: %s", exc)

        time.sleep(REQUEST_DELAY_SECONDS)

    if not frames:
        return _empty()
    try:
        return pl.concat(frames, how="diagonal_relaxed")
    except Exception as exc:  # noqa: BLE001
        log.warning("deals concat failed: %s", exc)
        return _empty()


# ---- public collectors ---------------------------------------------------

def bulk_deals(start: date | str, end: date | str) -> pl.DataFrame:
    """Bulk deals for the inclusive [start, end] date range.

    Returns a Polars DataFrame with columns:
    ``date, symbol, security_name, client_name, buy_sell, quantity, price,
    remarks, source_url``. Returns an empty DataFrame on **any** failure
    (invalid input, network error, malformed payload, etc.).
    """
    try:
        return _fetch_deals(_BULK_DEALS_URL, _to_date(start), _to_date(end))
    except Exception as exc:  # noqa: BLE001 — never crash the pipeline
        log.warning("bulk_deals failed: %s", exc)
        return _empty()


def block_deals(start: date | str, end: date | str) -> pl.DataFrame:
    """Block deals for the inclusive [start, end] date range.

    Same canonical schema and same failure guarantee as ``bulk_deals``.
    """
    try:
        return _fetch_deals(_BLOCK_DEALS_URL, _to_date(start), _to_date(end))
    except Exception as exc:  # noqa: BLE001
        log.warning("block_deals failed: %s", exc)
        return _empty()


def short_selling(d: date | str) -> pl.DataFrame:
    log.info("short_selling(%s) — scaffold", d)
    return pl.DataFrame()


def large_deals(d: date | str) -> pl.DataFrame:
    log.info("large_deals(%s) — scaffold", d)
    return pl.DataFrame()
