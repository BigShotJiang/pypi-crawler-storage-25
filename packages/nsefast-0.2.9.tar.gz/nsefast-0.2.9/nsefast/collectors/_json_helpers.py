"""Shared helpers for collectors that hit NSE's JSON endpoints.

Centralizes date parsing, NSE's ``DD-MM-YYYY`` format, range chunking, and
the canonical empty-DataFrame factory so each collector only has to declare
its schema and field-alias map.

Every helper is defensive — they never raise on bad input; they return a
sensible empty value so downstream pipelines stay crash-proof.
"""

from __future__ import annotations

import logging
from datetime import date, datetime, timedelta
from typing import Any, Iterable

import polars as pl

log = logging.getLogger(__name__)

MAX_WINDOW_DAYS = 90


def to_date(d: date | str) -> date:
    """Parse ``YYYY-MM-DD`` strings or pass through ``date`` objects."""
    if isinstance(d, date):
        return d
    return datetime.strptime(d, "%Y-%m-%d").date()


def fmt_nse_date(d: date) -> str:
    """NSE historical endpoints expect ``DD-MM-YYYY``."""
    return d.strftime("%d-%m-%Y")


def chunk_ranges(
    start: date, end: date, max_days: int = MAX_WINDOW_DAYS
) -> Iterable[tuple[date, date]]:
    """Yield contiguous, non-overlapping inclusive date windows."""
    cur = start
    while cur <= end:
        chunk_end = min(cur + timedelta(days=max_days - 1), end)
        yield cur, chunk_end
        cur = chunk_end + timedelta(days=1)


def make_empty(columns: list[str]) -> pl.DataFrame:
    """Empty DataFrame with the canonical column set (all Utf8)."""
    return pl.DataFrame(schema={c: pl.Utf8 for c in columns})


def pick(row: dict[str, Any], aliases: tuple[str, ...]) -> Any:
    """Return the first non-empty value in ``row`` for any alias key."""
    for key in aliases:
        if key in row and row[key] not in (None, ""):
            return row[key]
    return None


def normalize_rows(
    rows: list[Any],
    columns: list[str],
    aliases: dict[str, tuple[str, ...]],
    source_url: str,
    extra_casts: list[pl.Expr] | None = None,
) -> pl.DataFrame:
    """Project raw NSE JSON rows onto a canonical schema. Never raises.

    ``aliases`` maps each canonical column name to a tuple of NSE field
    candidates. Rows that aren't dicts are silently skipped. Construction
    or cast failures fall back to an empty canonical DataFrame.
    """
    if not rows:
        return make_empty(columns)

    out: list[dict[str, Any]] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        try:
            projected = {col: pick(row, aliases.get(col, (col,))) for col in columns}
            projected["source_url"] = source_url
            out.append(projected)
        except Exception as exc:  # noqa: BLE001
            log.warning("skipping malformed row: %s", exc)
            continue

    if not out:
        return make_empty(columns)

    try:
        df = pl.DataFrame(out, infer_schema_length=len(out))
    except Exception as exc:  # noqa: BLE001
        log.warning("polars construction failed: %s", exc)
        return make_empty(columns)

    if extra_casts:
        try:
            df = df.with_columns(extra_casts)
        except Exception as exc:  # noqa: BLE001
            log.warning("cast failed: %s", exc)

    return df
