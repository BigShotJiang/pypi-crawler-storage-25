"""Market breadth: advances, declines, unchanged, 52-week H/L, circuits, top movers.

Most of these series are surfaced via the live market-data JSON endpoints on
nseindia.com. Wire each function to its specific endpoint after verifying it's
allowed by robots.txt. Until then they return empty DataFrames so the API
shape is stable for callers.
"""

from __future__ import annotations

import logging

import polars as pl

from nsefast.collectors.equity import (
    advances_declines,
    fifty_two_week_high_low,
    most_active,
    top_gainers,
    top_losers,
    upper_lower_circuit,
)

log = logging.getLogger(__name__)


def unchanged() -> pl.DataFrame:
    log.info("unchanged — scaffold")
    return pl.DataFrame()


def market_snapshot() -> pl.DataFrame:
    """Combine advances/declines/52w/circuits into one wide snapshot."""
    log.info("market_snapshot — scaffold")
    return pl.DataFrame()


__all__ = [
    "advances_declines",
    "fifty_two_week_high_low",
    "most_active",
    "top_gainers",
    "top_losers",
    "upper_lower_circuit",
    "unchanged",
    "market_snapshot",
]
