"""Derivatives: F&O bhavcopy, futures, options chain, OI, PCR, expiry, rollovers."""

from __future__ import annotations

import io
import logging
import time
import zipfile
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

import polars as pl

from nsefast.collectors._json_helpers import make_empty
from nsefast.config import (
    ARCHIVES_URL,
    BASE_URL,
    RAW_DIR,
    REQUEST_DELAY_SECONDS,
    REQUEST_TIMEOUT_SECONDS,
)
from nsefast.http_client import create_session
from nsefast.robots import can_fetch

log = logging.getLogger(__name__)


def _fmt_date(d: date | str) -> date:
    if isinstance(d, str):
        return datetime.strptime(d, "%Y-%m-%d").date()
    return d


def fo_bhavcopy(d: date | str) -> pl.DataFrame:
    """Daily F&O bhavcopy.
    Path: ``/content/historical/DERIVATIVES/<YYYY>/<MMM>/fo<DDMMMYYYY>bhav.csv.zip``
    """
    target = _fmt_date(d)
    yyyy = target.strftime("%Y")
    mmm = target.strftime("%b").upper()
    ddmmmyyyy = target.strftime("%d%b%Y").upper()
    url = f"{ARCHIVES_URL}/content/historical/DERIVATIVES/{yyyy}/{mmm}/fo{ddmmmyyyy}bhav.csv.zip"

    if not can_fetch(url):
        return pl.DataFrame()

    session = create_session()
    resp = session.get(url, timeout=30)
    if resp.status_code != 200:
        log.warning("fo_bhavcopy %s -> HTTP %s", target, resp.status_code)
        return pl.DataFrame()

    Path(RAW_DIR).mkdir(parents=True, exist_ok=True)
    (Path(RAW_DIR) / f"fo{ddmmmyyyy}bhav.csv.zip").write_bytes(resp.content)

    with zipfile.ZipFile(io.BytesIO(resp.content)) as zf:
        name = next((n for n in zf.namelist() if n.lower().endswith(".csv")), None)
        if not name:
            return pl.DataFrame()
        with zf.open(name) as fh:
            return pl.read_csv(fh.read(), try_parse_dates=True)


def futures_data(symbol: str) -> pl.DataFrame:
    log.info("futures_data(%s) — scaffold", symbol)
    return pl.DataFrame()


def option_chain_snapshot(symbol: str) -> pl.DataFrame:
    """Back-compat alias for :func:`option_chain`."""
    return option_chain(symbol)


def open_interest(symbol: str) -> pl.DataFrame:
    log.info("open_interest(%s) — scaffold", symbol)
    return pl.DataFrame()


def change_in_oi(symbol: str) -> pl.DataFrame:
    log.info("change_in_oi(%s) — scaffold", symbol)
    return pl.DataFrame()


def pcr(symbol: str) -> pl.DataFrame:
    log.info("pcr(%s) — scaffold", symbol)
    return pl.DataFrame()


def expiry_calendar() -> pl.DataFrame:
    log.info("expiry_calendar — scaffold")
    return pl.DataFrame()


def long_buildup() -> pl.DataFrame:
    log.info("long_buildup — scaffold")
    return pl.DataFrame()


def short_buildup() -> pl.DataFrame:
    log.info("short_buildup — scaffold")
    return pl.DataFrame()


def rollover() -> pl.DataFrame:
    log.info("rollover — scaffold")
    return pl.DataFrame()


# ---- segment-specific bhavcopies ----------------------------------------
# NSE publishes separate daily bhavcopies for currency (CD), commodity (COM),
# and interest-rate (IRD) derivatives. URL conventions differ from equity F&O
# and have changed over time, so these stay scaffolded until the exact path
# for each segment is verified against robots.txt for the target date range.

def currency_derivatives_bhavcopy(d: date | str) -> pl.DataFrame:
    log.info("currency_derivatives_bhavcopy(%s) — scaffold", d)
    return pl.DataFrame()


def commodity_derivatives_bhavcopy(d: date | str) -> pl.DataFrame:
    log.info("commodity_derivatives_bhavcopy(%s) — scaffold", d)
    return pl.DataFrame()


def interest_rate_derivatives_bhavcopy(d: date | str) -> pl.DataFrame:
    log.info("interest_rate_derivatives_bhavcopy(%s) — scaffold", d)
    return pl.DataFrame()


def most_active_contracts() -> pl.DataFrame:
    log.info("most_active_contracts — scaffold")
    return pl.DataFrame()


def most_active_underlying() -> pl.DataFrame:
    log.info("most_active_underlying — scaffold")
    return pl.DataFrame()


# =========================================================================
# Option Chain
# =========================================================================
#
# NSE serves the option chain as a JSON snapshot at:
#   /api/option-chain-equities?symbol=<SYM>
#   /api/option-chain-indices?symbol=<INDEX>
#
# Response shape (abbreviated):
#   {"records": {"data": [
#       {"strikePrice": 22000,
#        "expiryDate": "08-May-2026",
#        "CE": {underlyingValue, openInterest, changeinOpenInterest,
#               totalTradedVolume, impliedVolatility, lastPrice, change,
#               bidQty, bidprice, askPrice, askQty, ...},
#        "PE": {...}},
#       ...]}}
#
# CE or PE may be absent on a strike — we emit one row per present leg.

_OPTION_CHAIN_EQUITIES_URL = f"{BASE_URL}/api/option-chain-equities"
_OPTION_CHAIN_INDICES_URL = f"{BASE_URL}/api/option-chain-indices"
_OPTION_CHAIN_REFERER = f"{BASE_URL}/option-chain"

_INDEX_SYMBOLS = {"NIFTY", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY", "NIFTYNXT50"}

_OC_COLUMNS = [
    "symbol",
    "underlying_value",
    "expiry_date",
    "strike_price",
    "option_type",
    "open_interest",
    "change_in_oi",
    "volume",
    "implied_volatility",
    "last_price",
    "change",
    "bid_qty",
    "bid_price",
    "ask_price",
    "ask_qty",
    "source_url",
    "fetched_at",
]

# leg field name -> canonical column
_OC_LEG_FIELDS = {
    "open_interest":      ("openInterest",),
    "change_in_oi":       ("changeinOpenInterest", "changeInOpenInterest"),
    "volume":             ("totalTradedVolume",),
    "implied_volatility": ("impliedVolatility",),
    "last_price":         ("lastPrice",),
    "change":             ("change",),
    "bid_qty":            ("bidQty", "bidQuantity"),
    "bid_price":          ("bidprice", "bidPrice"),
    "ask_price":          ("askPrice",),
    "ask_qty":            ("askQty", "askQuantity"),
    "underlying_value":   ("underlyingValue",),
}


def _get(d: dict[str, Any], keys: tuple[str, ...]) -> Any:
    for k in keys:
        if k in d and d[k] not in (None, ""):
            return d[k]
    return None


def _flatten_leg(
    leg: dict[str, Any] | None,
    *,
    symbol: str,
    expiry_date: Any,
    strike_price: Any,
    option_type: str,
    fallback_underlying: Any,
    source_url: str,
    fetched_at: str,
) -> dict[str, Any] | None:
    """Project one CE or PE leg onto the canonical row dict. Returns None if
    the leg is missing or not a dict."""
    if not isinstance(leg, dict):
        return None
    row: dict[str, Any] = {
        "symbol": symbol,
        "underlying_value": _get(leg, _OC_LEG_FIELDS["underlying_value"]) or fallback_underlying,
        "expiry_date": expiry_date,
        "strike_price": strike_price,
        "option_type": option_type,
        "source_url": source_url,
        "fetched_at": fetched_at,
    }
    for canonical, aliases in _OC_LEG_FIELDS.items():
        if canonical in ("underlying_value",):
            continue
        row[canonical] = _get(leg, aliases)
    return row


def _flatten_option_chain(
    payload: Any, *, symbol: str, source_url: str, fetched_at: str,
) -> pl.DataFrame:
    """Flatten an NSE option-chain payload to one row per present CE/PE leg."""
    if not isinstance(payload, dict):
        return make_empty(_OC_COLUMNS)

    records = payload.get("records")
    if not isinstance(records, dict):
        return make_empty(_OC_COLUMNS)

    data = records.get("data")
    if not isinstance(data, list) or not data:
        return make_empty(_OC_COLUMNS)

    fallback_underlying = records.get("underlyingValue")

    rows: list[dict[str, Any]] = []
    for entry in data:
        if not isinstance(entry, dict):
            continue
        try:
            strike = entry.get("strikePrice")
            expiry = entry.get("expiryDate")
            for opt_type, leg_key in (("CE", "CE"), ("PE", "PE")):
                row = _flatten_leg(
                    entry.get(leg_key),
                    symbol=symbol,
                    expiry_date=expiry,
                    strike_price=strike,
                    option_type=opt_type,
                    fallback_underlying=fallback_underlying,
                    source_url=source_url,
                    fetched_at=fetched_at,
                )
                if row is not None:
                    rows.append(row)
        except Exception as exc:  # noqa: BLE001
            log.warning("skipping malformed option strike: %s", exc)
            continue

    if not rows:
        return make_empty(_OC_COLUMNS)

    try:
        df = pl.DataFrame(rows, infer_schema_length=len(rows))
    except Exception as exc:  # noqa: BLE001
        log.warning("option chain construction failed: %s", exc)
        return make_empty(_OC_COLUMNS)

    # Best-effort numeric casts (NSE intermittently returns strings).
    casts: list[pl.Expr] = []
    for col, dtype in (
        ("underlying_value", pl.Float64),
        ("strike_price", pl.Float64),
        ("open_interest", pl.Int64),
        ("change_in_oi", pl.Int64),
        ("volume", pl.Int64),
        ("implied_volatility", pl.Float64),
        ("last_price", pl.Float64),
        ("change", pl.Float64),
        ("bid_qty", pl.Int64),
        ("bid_price", pl.Float64),
        ("ask_price", pl.Float64),
        ("ask_qty", pl.Int64),
    ):
        if col in df.columns:
            casts.append(pl.col(col).cast(dtype, strict=False).alias(col))
    if casts:
        try:
            df = df.with_columns(casts)
        except Exception as exc:  # noqa: BLE001
            log.warning("option chain numeric cast failed: %s", exc)

    # Ensure canonical column order, even if some are all-null.
    for col in _OC_COLUMNS:
        if col not in df.columns:
            df = df.with_columns(pl.lit(None).alias(col))
    return df.select(_OC_COLUMNS)


def _fetch_option_chain(url: str, symbol: str) -> pl.DataFrame:
    """Single-snapshot GET against an NSE option-chain JSON endpoint."""
    if not isinstance(symbol, str) or not symbol.strip():
        return make_empty(_OC_COLUMNS)
    sym = symbol.strip().upper()

    if not can_fetch(url):
        log.info("robots.txt disallows %s", url)
        return make_empty(_OC_COLUMNS)

    headers = {
        "Accept": "application/json, text/plain, */*",
        "Referer": _OPTION_CHAIN_REFERER,
        "X-Requested-With": "XMLHttpRequest",
    }

    try:
        session = create_session()
        resp = session.get(
            url,
            params={"symbol": sym},
            headers=headers,
            timeout=REQUEST_TIMEOUT_SECONDS,
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("option-chain fetch failed for %s: %s", sym, exc)
        return make_empty(_OC_COLUMNS)

    if resp.status_code != 200:
        log.warning("option-chain %s -> HTTP %s", sym, resp.status_code)
        return make_empty(_OC_COLUMNS)

    try:
        payload = resp.json()
    except Exception as exc:  # noqa: BLE001
        log.warning("option-chain JSON decode failed for %s: %s", sym, exc)
        return make_empty(_OC_COLUMNS)

    fetched_at = datetime.now(timezone.utc).isoformat()
    traceable = f"{url}?symbol={sym}"
    try:
        df = _flatten_option_chain(
            payload, symbol=sym, source_url=traceable, fetched_at=fetched_at,
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("option-chain flatten failed for %s: %s", sym, exc)
        df = make_empty(_OC_COLUMNS)

    time.sleep(REQUEST_DELAY_SECONDS)
    return df


def option_chain_equity(symbol: str) -> pl.DataFrame:
    """Equity option chain snapshot.

    Canonical schema: ``symbol, underlying_value, expiry_date, strike_price,
    option_type, open_interest, change_in_oi, volume, implied_volatility,
    last_price, change, bid_qty, bid_price, ask_price, ask_qty, source_url,
    fetched_at``. Returns an empty DataFrame on **any** failure.
    """
    try:
        return _fetch_option_chain(_OPTION_CHAIN_EQUITIES_URL, symbol)
    except Exception as exc:  # noqa: BLE001
        log.warning("option_chain_equity failed for %s: %s", symbol, exc)
        return make_empty(_OC_COLUMNS)


def option_chain_index(symbol: str) -> pl.DataFrame:
    """Index option chain snapshot. Same schema and guarantee as equity."""
    try:
        return _fetch_option_chain(_OPTION_CHAIN_INDICES_URL, symbol)
    except Exception as exc:  # noqa: BLE001
        log.warning("option_chain_index failed for %s: %s", symbol, exc)
        return make_empty(_OC_COLUMNS)


def option_chain(symbol: str) -> pl.DataFrame:
    """Convenience: routes index symbols (NIFTY/BANKNIFTY/FINNIFTY/...)
    to the indices endpoint, everything else to the equities endpoint.
    """
    if not isinstance(symbol, str):
        return make_empty(_OC_COLUMNS)
    if symbol.strip().upper() in _INDEX_SYMBOLS:
        return option_chain_index(symbol)
    return option_chain_equity(symbol)
