"""Delivery data — re-exports from equity for namespace clarity."""

from nsefast.collectors.equity import delivery_data

__all__ = ["delivery_data"]
