"""Index data: Nifty 50, Bank Nifty, sector indices, constituents, weightage.

Sector strength is wired to NSE's ``/api/allIndices`` JSON snapshot. Other
helpers (constituents, weightage, historical OHLC) remain logged scaffolds
returning empty DataFrames until each endpoint is verified against
robots.txt.
"""

from __future__ import annotations

import logging
import time
from datetime import datetime, timezone
from typing import Any

import polars as pl

from nsefast.collectors._json_helpers import make_empty
from nsefast.config import BASE_URL, REQUEST_DELAY_SECONDS, REQUEST_TIMEOUT_SECONDS
from nsefast.http_client import create_session
from nsefast.robots import can_fetch

log = logging.getLogger(__name__)

# Sector-only Nifty index names (broad indices like NIFTY 50, NIFTY 500,
# NIFTY MIDCAP 100 are excluded — those belong in :func:`all_indices`).
# This list is reference-only; sector classification at runtime uses the
# regex below so renames and additions are picked up automatically.
SECTOR_INDICES = [
    "NIFTY BANK",
    "NIFTY IT",
    "NIFTY AUTO",
    "NIFTY PHARMA",
    "NIFTY FMCG",
    "NIFTY METAL",
    "NIFTY ENERGY",
    "NIFTY REALTY",
    "NIFTY FIN SERVICE",
    "NIFTY FINANCIAL SERVICES",
    "NIFTY MEDIA",
    "NIFTY PSU BANK",
    "NIFTY PVT BANK",
    "NIFTY PRIVATE BANK",
    "NIFTY INFRA",
    "NIFTY HEALTHCARE INDEX",
    "NIFTY CONSUMER DURABLES",
    "NIFTY OIL & GAS",
    "NIFTY SERVICES SECTOR",
    "NIFTY COMMODITIES",
    "NIFTY CONSUMPTION",
    "NIFTY MNC",
    "NIFTY CPSE",
    "NIFTY PSE",
]

# Token-based classifier: an index name is treated as a *sector* if it
# starts with NIFTY (or NIFTY NEXT/MIDCAP/SMALLCAP isn't broad-market) and
# contains a recognized sector keyword. Permissive on purpose so new NSE
# sector indices are picked up without code changes.
_SECTOR_KEYWORD_PATTERN = (
    r"\b("
    r"BANK|IT|AUTO|PHARMA|FMCG|METAL|ENERGY|REALTY|MEDIA|INFRA|"
    r"FIN(?:ANCIAL)?\s*SERV(?:ICE|ICES)?|HEALTHCARE|CONSUMER\s+DURABLES|"
    r"OIL\s*&?\s*GAS|SERVICES\s+SECTOR|COMMODITIES|CONSUMPTION|"
    r"MNC|CPSE|PSE|PSU|PVT|PRIVATE"
    r")\b"
)
# Broad indices that contain sector-like words but should NOT be classified
# as sectors (e.g. "NIFTY 50", "NIFTY 500", "NIFTY MIDCAP 100").
_BROAD_INDEX_PATTERN = (
    r"^NIFTY\s+("
    r"\d+|NEXT\s+\d+|MIDCAP(\s+\d+)?|SMALLCAP(\s+\d+)?|LARGEMIDCAP|"
    r"100|200|500|TOTAL\s+MARKET|MICROCAP)"
)

_ALL_INDICES_URL = f"{BASE_URL}/api/allIndices"
_INDICES_REFERER = f"{BASE_URL}/market-data/live-market-indices"

_SECTOR_COLUMNS = [
    "index_name",
    "last",
    "change",
    "percent_change",
    "open",
    "day_high",
    "day_low",
    "prev_close",
    "year_high",
    "year_low",
    "advances",
    "declines",
    "unchanged",
    "source_url",
    "fetched_at",
]

_SECTOR_ALIASES: dict[str, tuple[str, ...]] = {
    "index_name":     ("index", "indexName", "name"),
    "last":           ("last", "lastPrice", "ltp"),
    "change":         ("variation", "change"),
    "percent_change": ("percentChange", "pChange"),
    "open":           ("open", "openPrice"),
    "day_high":       ("high", "dayHigh"),
    "day_low":        ("low", "dayLow"),
    "prev_close":     ("previousClose", "prevClose"),
    "year_high":      ("yearHigh", "high52"),
    "year_low":       ("yearLow", "low52"),
    "advances":       ("advances",),
    "declines":       ("declines",),
    "unchanged":      ("unchanged",),
}


def _pick(d: dict[str, Any], keys: tuple[str, ...]) -> Any:
    for k in keys:
        if k in d and d[k] not in (None, ""):
            return d[k]
    return None


def _flatten_indices(payload: Any, source_url: str, fetched_at: str) -> pl.DataFrame:
    """Flatten an /api/allIndices payload onto the canonical schema. Never raises."""
    if not isinstance(payload, dict):
        return make_empty(_SECTOR_COLUMNS)
    rows_raw = payload.get("data")
    if not isinstance(rows_raw, list) or not rows_raw:
        return make_empty(_SECTOR_COLUMNS)

    rows: list[dict[str, Any]] = []
    for entry in rows_raw:
        if not isinstance(entry, dict):
            continue
        try:
            row = {col: _pick(entry, _SECTOR_ALIASES.get(col, (col,))) for col in _SECTOR_COLUMNS if col not in ("source_url", "fetched_at")}
            row["source_url"] = source_url
            row["fetched_at"] = fetched_at
            rows.append(row)
        except Exception as exc:  # noqa: BLE001
            log.warning("skipping malformed index entry: %s", exc)
            continue

    if not rows:
        return make_empty(_SECTOR_COLUMNS)

    try:
        df = pl.DataFrame(rows, infer_schema_length=len(rows))
    except Exception as exc:  # noqa: BLE001
        log.warning("indices construction failed: %s", exc)
        return make_empty(_SECTOR_COLUMNS)

    casts: list[pl.Expr] = []
    for col, dtype in (
        ("last", pl.Float64),
        ("change", pl.Float64),
        ("percent_change", pl.Float64),
        ("open", pl.Float64),
        ("day_high", pl.Float64),
        ("day_low", pl.Float64),
        ("prev_close", pl.Float64),
        ("year_high", pl.Float64),
        ("year_low", pl.Float64),
        ("advances", pl.Int64),
        ("declines", pl.Int64),
        ("unchanged", pl.Int64),
    ):
        if col in df.columns:
            casts.append(pl.col(col).cast(pl.Utf8, strict=False).str.replace_all(",", "").cast(dtype, strict=False).alias(col))
    if casts:
        try:
            df = df.with_columns(casts)
        except Exception as exc:  # noqa: BLE001
            log.warning("indices cast failed: %s", exc)

    for col in _SECTOR_COLUMNS:
        if col not in df.columns:
            df = df.with_columns(pl.lit(None).alias(col))
    return df.select(_SECTOR_COLUMNS)


def _fetch_all_indices() -> pl.DataFrame:
    if not can_fetch(_ALL_INDICES_URL):
        log.info("robots.txt disallows %s", _ALL_INDICES_URL)
        return make_empty(_SECTOR_COLUMNS)

    headers = {
        "Accept": "application/json, text/plain, */*",
        "Referer": _INDICES_REFERER,
        "X-Requested-With": "XMLHttpRequest",
    }
    try:
        session = create_session()
        resp = session.get(_ALL_INDICES_URL, headers=headers, timeout=REQUEST_TIMEOUT_SECONDS)
    except Exception as exc:  # noqa: BLE001
        log.warning("allIndices fetch failed: %s", exc)
        return make_empty(_SECTOR_COLUMNS)

    if resp.status_code != 200:
        log.warning("allIndices -> HTTP %s", resp.status_code)
        return make_empty(_SECTOR_COLUMNS)

    try:
        payload = resp.json()
    except Exception as exc:  # noqa: BLE001
        log.warning("allIndices JSON decode failed: %s", exc)
        return make_empty(_SECTOR_COLUMNS)

    fetched_at = datetime.now(timezone.utc).isoformat()
    try:
        df = _flatten_indices(payload, _ALL_INDICES_URL, fetched_at)
    except Exception as exc:  # noqa: BLE001
        log.warning("allIndices flatten failed: %s", exc)
        df = make_empty(_SECTOR_COLUMNS)

    time.sleep(REQUEST_DELAY_SECONDS)
    return df


# ---- public collectors ---------------------------------------------------

def all_indices() -> pl.DataFrame:
    """Snapshot of every index NSE publishes (broad + sector + thematic + strategy)."""
    try:
        return _fetch_all_indices()
    except Exception as exc:  # noqa: BLE001
        log.warning("all_indices failed: %s", exc)
        return make_empty(_SECTOR_COLUMNS)


def is_sector_index(name: str) -> bool:
    """Heuristic: True if ``name`` looks like a Nifty *sector* index.

    Uses keyword matching so renames (``NIFTY PVT BANK`` ↔
    ``NIFTY PRIVATE BANK``) and newly added sector indices are picked up
    automatically. Broad indices (``NIFTY 50``, ``NIFTY 500``,
    ``NIFTY MIDCAP 100``…) are explicitly excluded.
    """
    import re
    if not isinstance(name, str):
        return False
    upper = name.strip().upper()
    if not upper.startswith("NIFTY"):
        return False
    if re.search(_BROAD_INDEX_PATTERN, upper):
        return False
    return bool(re.search(_SECTOR_KEYWORD_PATTERN, upper))


def sector_strength() -> pl.DataFrame:
    """Sector-only slice of :func:`all_indices`, sorted by ``percent_change`` desc.

    Canonical schema: ``index_name, last, change, percent_change, open,
    day_high, day_low, prev_close, year_high, year_low, advances, declines,
    unchanged, source_url, fetched_at``. Empty DataFrame on any failure.

    Uses :func:`is_sector_index` for classification so NSE renames and new
    sector indices are picked up without code changes.
    """
    df = all_indices()
    if df.is_empty():
        return df
    try:
        names = df["index_name"].to_list()
        keep = [is_sector_index(n) for n in names]
        out = df.filter(pl.Series(keep))
        if "percent_change" in out.columns and not out.is_empty():
            out = out.sort("percent_change", descending=True, nulls_last=True)
        return out
    except Exception as exc:  # noqa: BLE001
        log.warning("sector_strength filter failed: %s", exc)
        return make_empty(_SECTOR_COLUMNS)


def sector_indices() -> pl.DataFrame:
    """Alias for :func:`sector_strength` — preserved for back-compat."""
    return sector_strength()


# ---- remaining scaffolds -------------------------------------------------

def historical_index_data(name: str, start, end) -> pl.DataFrame:
    log.info("historical_index_data(%s, %s, %s) — scaffold", name, start, end)
    return pl.DataFrame()


def nifty_50() -> pl.DataFrame:
    df = all_indices()
    if df.is_empty():
        return df
    return df.filter(pl.col("index_name") == "NIFTY 50")


def bank_nifty() -> pl.DataFrame:
    df = all_indices()
    if df.is_empty():
        return df
    return df.filter(pl.col("index_name") == "NIFTY BANK")


def index_ohlcv(name: str) -> pl.DataFrame:
    log.info("index_ohlcv(%s) — scaffold", name)
    return pl.DataFrame()


def index_constituents(name: str) -> pl.DataFrame:
    log.info("index_constituents(%s) — scaffold", name)
    return pl.DataFrame()


def index_weightage(name: str) -> pl.DataFrame:
    log.info("index_weightage(%s) — scaffold", name)
    return pl.DataFrame()
