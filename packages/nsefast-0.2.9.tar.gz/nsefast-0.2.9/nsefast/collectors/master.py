"""Master / reference data: symbols, ISINs, listings, ETFs, sector mapping."""

from __future__ import annotations

import io
import logging

import polars as pl

from nsefast.config import ARCHIVES_URL
from nsefast.http_client import create_session
from nsefast.robots import can_fetch

log = logging.getLogger(__name__)

EQUITY_LIST_URL = f"{ARCHIVES_URL}/content/equities/EQUITY_L.csv"


def symbol_master() -> pl.DataFrame:
    """Full equity symbol list from NSE archives."""
    if not can_fetch(EQUITY_LIST_URL):
        return pl.DataFrame()

    session = create_session()
    resp = session.get(EQUITY_LIST_URL, timeout=30)
    if resp.status_code != 200:
        log.warning("symbol_master HTTP %s", resp.status_code)
        return pl.DataFrame()
    return pl.read_csv(io.BytesIO(resp.content))


def isin_master() -> pl.DataFrame:
    """ISIN list — derived from the equity master by default."""
    df = symbol_master()
    if df.is_empty():
        return df
    cols = [c for c in df.columns if c.strip().lower() in {"symbol", " isin number", "isin number"}]
    return df.select(cols) if cols else df


def listed_securities() -> pl.DataFrame:
    return symbol_master()


def sme_securities() -> pl.DataFrame:
    log.info("sme_securities — scaffold")
    return pl.DataFrame()


def etf_list() -> pl.DataFrame:
    log.info("etf_list — scaffold")
    return pl.DataFrame()


def sector_mapping() -> pl.DataFrame:
    log.info("sector_mapping — scaffold")
    return pl.DataFrame()


def industry_mapping() -> pl.DataFrame:
    log.info("industry_mapping — scaffold")
    return pl.DataFrame()


def delisted_suspended() -> pl.DataFrame:
    log.info("delisted_suspended — scaffold")
    return pl.DataFrame()
