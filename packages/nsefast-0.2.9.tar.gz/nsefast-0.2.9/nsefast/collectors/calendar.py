"""Calendars: holidays, expiries, results, board meetings, IPO."""

from __future__ import annotations

import logging

import polars as pl

log = logging.getLogger(__name__)


def trading_holidays() -> pl.DataFrame:
    log.info("trading_holidays — scaffold")
    return pl.DataFrame()


def settlement_holidays() -> pl.DataFrame:
    log.info("settlement_holidays — scaffold")
    return pl.DataFrame()


def board_meeting_calendar() -> pl.DataFrame:
    log.info("board_meeting_calendar — scaffold")
    return pl.DataFrame()


def results_calendar() -> pl.DataFrame:
    log.info("results_calendar — scaffold")
    return pl.DataFrame()


def corporate_action_calendar() -> pl.DataFrame:
    log.info("corporate_action_calendar — scaffold")
    return pl.DataFrame()


def expiry_calendar() -> pl.DataFrame:
    log.info("expiry_calendar — scaffold")
    return pl.DataFrame()


def ipo_calendar() -> pl.DataFrame:
    log.info("ipo_calendar — scaffold")
    return pl.DataFrame()


def listing_dates() -> pl.DataFrame:
    """New listings calendar (mainboard + SME)."""
    log.info("listing_dates — scaffold")
    return pl.DataFrame()
