"""Risk / surveillance lists: ASM, GSM, F&O ban, price band, circuits, margins."""

from __future__ import annotations

import logging

import polars as pl

log = logging.getLogger(__name__)


def asm_list() -> pl.DataFrame:
    log.info("asm_list — scaffold")
    return pl.DataFrame()


def gsm_list() -> pl.DataFrame:
    log.info("gsm_list — scaffold")
    return pl.DataFrame()


def fo_ban() -> pl.DataFrame:
    log.info("fo_ban — scaffold")
    return pl.DataFrame()


def price_band() -> pl.DataFrame:
    log.info("price_band — scaffold")
    return pl.DataFrame()


def circuit_limits() -> pl.DataFrame:
    log.info("circuit_limits — scaffold")
    return pl.DataFrame()


def var_margin() -> pl.DataFrame:
    log.info("var_margin — scaffold")
    return pl.DataFrame()


def elm_margin() -> pl.DataFrame:
    log.info("elm_margin — scaffold")
    return pl.DataFrame()


def trade_to_trade() -> pl.DataFrame:
    log.info("trade_to_trade — scaffold")
    return pl.DataFrame()


def surveillance_actions() -> pl.DataFrame:
    log.info("surveillance_actions — scaffold")
    return pl.DataFrame()
