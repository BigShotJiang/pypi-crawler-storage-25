"""Discover downloadable report links from NSE public pages."""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from urllib.parse import urljoin

import polars as pl
from bs4 import BeautifulSoup

from nsefast.config import BASE_URL, PAGES, REQUEST_TIMEOUT_SECONDS
from nsefast.http_client import create_session
from nsefast.robots import can_fetch

log = logging.getLogger(__name__)

_FILE_EXTS = (".csv", ".zip", ".dat", ".txt", ".xlsx", ".xls", ".pdf")


def collect_report_links() -> pl.DataFrame:
    """Scan NSE landing pages and return all downloadable report links."""
    session = create_session()
    rows: list[dict] = []

    for page_name, page_url in PAGES.items():
        if not can_fetch(page_url):
            log.info("robots.txt disallows %s — skipping", page_url)
            continue

        try:
            response = session.get(page_url, timeout=REQUEST_TIMEOUT_SECONDS)
        except Exception as exc:  # noqa: BLE001
            log.warning("fetch %s failed: %s", page_url, exc)
            continue

        if response.status_code != 200:
            log.warning("fetch %s -> HTTP %s", page_url, response.status_code)
            continue

        soup = BeautifulSoup(response.text, "lxml")
        for a in soup.find_all("a", href=True):
            href = a.get("href", "")
            label = a.get_text(strip=True)
            url = urljoin(BASE_URL, href)

            if any(x in url.lower() for x in _FILE_EXTS):
                rows.append(
                    {
                        "source": "nse",
                        "page": page_name,
                        "label": label,
                        "url": url,
                        "file_type": url.split(".")[-1].split("?")[0].lower(),
                        "collected_at": datetime.now(timezone.utc).isoformat(),
                    }
                )

    if not rows:
        return pl.DataFrame()

    return pl.DataFrame(rows).unique(subset=["url"])
