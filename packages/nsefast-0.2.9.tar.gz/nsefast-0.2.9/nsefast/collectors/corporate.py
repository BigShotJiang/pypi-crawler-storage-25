"""Corporate filings: announcements, actions, board meetings, results, etc.

Announcements and actions are wired to NSE's public JSON endpoints behind
the corporate-filings pages. Both share the warm-up cookie session,
date chunking, and graceful failure semantics used by bulk/block deals.

Other domains (financial results, shareholding pattern, insider trading,
etc.) remain logged scaffolds returning empty DataFrames until each
endpoint is verified against robots.txt.
"""

from __future__ import annotations

import logging
import time
from datetime import date
from typing import Any

import polars as pl

from nsefast.collectors._json_helpers import (
    chunk_ranges,
    fmt_nse_date,
    make_empty,
    normalize_rows,
    to_date,
)
from nsefast.config import BASE_URL, REQUEST_DELAY_SECONDS, REQUEST_TIMEOUT_SECONDS
from nsefast.http_client import create_session
from nsefast.robots import can_fetch

log = logging.getLogger(__name__)

# ---- endpoints -----------------------------------------------------------

_ANNOUNCEMENTS_URL = f"{BASE_URL}/api/corporate-announcements"
_ANNOUNCEMENTS_REFERER = f"{BASE_URL}/companies-listing/corporate-filings-announcements"

_ACTIONS_URL = f"{BASE_URL}/api/corporates-corporateActions"
_ACTIONS_REFERER = f"{BASE_URL}/companies-listing/corporate-filings-actions"

# ---- canonical schemas + field aliases -----------------------------------

_ANNOUNCEMENTS_COLUMNS = [
    "date",
    "symbol",
    "company_name",
    "subject",
    "details",
    "attachment_url",
    "source_url",
]

_ANNOUNCEMENTS_ALIASES: dict[str, tuple[str, ...]] = {
    "date":           ("an_dt", "sort_date", "exchdisstime", "dissemDT", "date"),
    "symbol":         ("symbol", "scrip"),
    "company_name":   ("sm_name", "company", "companyName"),
    "subject":        ("desc", "subject", "subcategory"),
    "details":        ("attchmntText", "more", "details", "attachmentText"),
    "attachment_url": ("attchmntFile", "attachment", "attachmentUrl"),
}

_ACTIONS_COLUMNS = [
    "ex_date",
    "record_date",
    "symbol",
    "company_name",
    "purpose",
    "face_value",
    "source_url",
]

_ACTIONS_ALIASES: dict[str, tuple[str, ...]] = {
    "ex_date":      ("exDate", "ex_date", "exdate"),
    "record_date":  ("recDate", "record_date", "recordDate"),
    "symbol":       ("symbol", "scrip"),
    "company_name": ("comp", "company", "companyName"),
    "purpose":      ("subject", "purpose"),
    "face_value":   ("faceVal", "face_value", "faceValue"),
}


def _json_headers(referer: str) -> dict[str, str]:
    return {
        "Accept": "application/json, text/plain, */*",
        "Referer": referer,
        "X-Requested-With": "XMLHttpRequest",
    }


def _fetch(
    url: str,
    referer: str,
    columns: list[str],
    aliases: dict[str, tuple[str, ...]],
    start: date,
    end: date,
    extra_casts: list[pl.Expr] | None = None,
) -> pl.DataFrame:
    """Generic chunked fetch against an NSE corporate-filings JSON endpoint."""
    if not can_fetch(url):
        log.info("robots.txt disallows %s", url)
        return make_empty(columns)

    session = create_session()
    headers = _json_headers(referer)

    frames: list[pl.DataFrame] = []
    for chunk_start, chunk_end in chunk_ranges(start, end):
        params = {
            "index": "equities",
            "from_date": fmt_nse_date(chunk_start),
            "to_date": fmt_nse_date(chunk_end),
        }
        try:
            resp = session.get(
                url, params=params, headers=headers,
                timeout=REQUEST_TIMEOUT_SECONDS,
            )
        except Exception as exc:  # noqa: BLE001
            log.warning("corp fetch failed (%s..%s): %s", chunk_start, chunk_end, exc)
            time.sleep(REQUEST_DELAY_SECONDS)
            continue

        if resp.status_code != 200:
            log.warning("corp %s..%s -> HTTP %s", chunk_start, chunk_end, resp.status_code)
            time.sleep(REQUEST_DELAY_SECONDS)
            continue

        try:
            payload = resp.json()
        except Exception as exc:  # noqa: BLE001
            log.warning("corp JSON decode failed: %s", exc)
            time.sleep(REQUEST_DELAY_SECONDS)
            continue

        # NSE returns either a bare list or {"data": [...]}, depending on
        # endpoint and time of day. Accept both.
        if isinstance(payload, dict):
            rows = payload.get("data") or payload.get("rows")
        else:
            rows = payload
        if not isinstance(rows, list):
            log.warning("corp payload missing list rows")
            time.sleep(REQUEST_DELAY_SECONDS)
            continue

        traceable = (
            f"{url}?index=equities"
            f"&from_date={params['from_date']}&to_date={params['to_date']}"
        )
        try:
            df = normalize_rows(rows, columns, aliases, traceable, extra_casts)
            if not df.is_empty():
                frames.append(df)
        except Exception as exc:  # noqa: BLE001
            log.warning("corp normalize failed: %s", exc)

        time.sleep(REQUEST_DELAY_SECONDS)

    if not frames:
        return make_empty(columns)
    try:
        return pl.concat(frames, how="diagonal_relaxed")
    except Exception as exc:  # noqa: BLE001
        log.warning("corp concat failed: %s", exc)
        return make_empty(columns)


# ---- public collectors ---------------------------------------------------

def corporate_announcements(start: date | str, end: date | str) -> pl.DataFrame:
    """Corporate announcements for the inclusive [start, end] range.

    Canonical schema: ``date, symbol, company_name, subject, details,
    attachment_url, source_url``. Returns an empty DataFrame on **any**
    failure (invalid input, network error, malformed payload).
    """
    try:
        return _fetch(
            _ANNOUNCEMENTS_URL,
            _ANNOUNCEMENTS_REFERER,
            _ANNOUNCEMENTS_COLUMNS,
            _ANNOUNCEMENTS_ALIASES,
            to_date(start),
            to_date(end),
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("corporate_announcements failed: %s", exc)
        return make_empty(_ANNOUNCEMENTS_COLUMNS)


def corporate_actions(start: date | str, end: date | str) -> pl.DataFrame:
    """Corporate actions (dividend / bonus / split / rights / etc.) for
    the inclusive [start, end] range.

    Canonical schema: ``ex_date, record_date, symbol, company_name,
    purpose, face_value, source_url``. Same failure guarantee as
    ``corporate_announcements``.
    """
    extra_casts = [
        pl.col("face_value")
        .cast(pl.Utf8, strict=False)
        .str.replace_all(",", "")
        .cast(pl.Float64, strict=False)
        .alias("face_value")
    ]
    try:
        return _fetch(
            _ACTIONS_URL,
            _ACTIONS_REFERER,
            _ACTIONS_COLUMNS,
            _ACTIONS_ALIASES,
            to_date(start),
            to_date(end),
            extra_casts=extra_casts,
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("corporate_actions failed: %s", exc)
        return make_empty(_ACTIONS_COLUMNS)


# ---- remaining scaffolds (unchanged) -------------------------------------

def board_meetings(start: date | str, end: date | str) -> pl.DataFrame:
    log.info("board_meetings(%s, %s) — scaffold", start, end)
    return pl.DataFrame()


def financial_results(start: date | str, end: date | str) -> pl.DataFrame:
    log.info("financial_results(%s, %s) — scaffold", start, end)
    return pl.DataFrame()


def shareholding_pattern(symbol: str) -> pl.DataFrame:
    log.info("shareholding_pattern(%s) — scaffold", symbol)
    return pl.DataFrame()


def annual_reports(symbol: str) -> pl.DataFrame:
    log.info("annual_reports(%s) — scaffold", symbol)
    return pl.DataFrame()


def insider_trading(start: date | str, end: date | str) -> pl.DataFrame:
    log.info("insider_trading(%s, %s) — scaffold", start, end)
    return pl.DataFrame()


def takeover_disclosures(start: date | str, end: date | str) -> pl.DataFrame:
    log.info("takeover_disclosures(%s, %s) — scaffold", start, end)
    return pl.DataFrame()


def buyback_redemption() -> pl.DataFrame:
    log.info("buyback_redemption — scaffold")
    return pl.DataFrame()


def scheme_of_arrangement() -> pl.DataFrame:
    log.info("scheme_of_arrangement — scaffold")
    return pl.DataFrame()


def investor_presentations(symbol: str) -> pl.DataFrame:
    log.info("investor_presentations(%s) — scaffold", symbol)
    return pl.DataFrame()


# ---- corporate-action sub-types (filtered slices of corporate_actions) ---

def _filter_actions(start, end, needles: tuple[str, ...]) -> pl.DataFrame:
    df = corporate_actions(start, end)
    if df.is_empty() or "purpose" not in df.columns:
        return df
    pattern = "|".join(needles)
    return df.filter(
        pl.col("purpose").cast(pl.Utf8, strict=False).str.contains(f"(?i){pattern}")
    )


def dividends(start: date | str, end: date | str) -> pl.DataFrame:
    return _filter_actions(start, end, ("dividend",))


def bonuses(start: date | str, end: date | str) -> pl.DataFrame:
    return _filter_actions(start, end, ("bonus",))


def splits(start: date | str, end: date | str) -> pl.DataFrame:
    return _filter_actions(start, end, ("split", "sub-division", "sub division"))


def rights_issues(start: date | str, end: date | str) -> pl.DataFrame:
    return _filter_actions(start, end, ("rights",))


def mergers_demergers(start: date | str, end: date | str) -> pl.DataFrame:
    return _filter_actions(start, end, ("merger", "demerger", "amalgamation"))


def record_and_ex_dates(start: date | str, end: date | str) -> pl.DataFrame:
    """Record date / ex-date calendar — derived from corporate_actions."""
    df = corporate_actions(start, end)
    if df.is_empty():
        return df
    keep = [c for c in ("ex_date", "record_date", "symbol", "company_name", "purpose") if c in df.columns]
    return df.select(keep)
