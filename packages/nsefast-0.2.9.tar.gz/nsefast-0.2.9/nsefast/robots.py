"""robots.txt checks. We respect NSE's policy by default."""

from __future__ import annotations

import logging
from urllib.robotparser import RobotFileParser

ROBOTS_URL = "https://www.nseindia.com/robots.txt"

log = logging.getLogger(__name__)

_cached_parser: RobotFileParser | None = None


def _parser() -> RobotFileParser:
    global _cached_parser
    if _cached_parser is None:
        rp = RobotFileParser()
        rp.set_url(ROBOTS_URL)
        try:
            rp.read()
        except Exception as exc:  # noqa: BLE001
            log.warning("Could not read robots.txt: %s", exc)
        _cached_parser = rp
    return _cached_parser


def can_fetch(url: str, user_agent: str = "*") -> bool:
    """Return True if `user_agent` is permitted to fetch `url`."""
    try:
        return _parser().can_fetch(user_agent, url)
    except Exception as exc:  # noqa: BLE001
        log.warning("robots check failed for %s: %s", url, exc)
        return False
