"""Minimal walk-forward backtest harness.

This is a deliberately small v0.2.0 scaffold — full backtesting (cost models,
slippage, intraday fills, ML scoring) lands in v0.3.0.

The simulator consumes a long-format OHLCV history (one row per
``(symbol, trade_date)``), takes a user-supplied ``signal_fn`` that flags
entries, and computes a forward-return after a fixed holding period.

Outputs:

- :func:`run_backtest` returns one row per signal with ``entry_date``,
  ``exit_date``, ``entry_price``, ``exit_price``, ``pnl_pct``.
- :func:`summary_stats` summarises trades into win-rate, average PnL, total
  return, and a naive Sharpe ratio.

All functions return empty DataFrames on failure — they never raise.
"""

from __future__ import annotations

from typing import Callable

import polars as pl

from nsefast.logging_setup import get_logger
from nsefast.swing._common import empty_with_schema

log = get_logger(__name__)


_TRADE_SCHEMA: dict[str, pl.DataType] = {
    "symbol":      pl.Utf8,
    "entry_date":  pl.Utf8,
    "entry_price": pl.Float64,
    "exit_date":   pl.Utf8,
    "exit_price":  pl.Float64,
    "pnl_pct":     pl.Float64,
}
_STATS_SCHEMA: dict[str, pl.DataType] = {
    "trades":        pl.UInt32,
    "win_rate":      pl.Float64,
    "avg_pnl_pct":   pl.Float64,
    "total_pnl_pct": pl.Float64,
    "best_pct":      pl.Float64,
    "worst_pct":     pl.Float64,
    "sharpe":        pl.Float64,
}


def _empty_trades() -> pl.DataFrame:
    return empty_with_schema(_TRADE_SCHEMA)


def _empty_stats() -> pl.DataFrame:
    return empty_with_schema(_STATS_SCHEMA)


def run_backtest(
    history: pl.DataFrame,
    signal_fn: Callable[[pl.DataFrame], pl.Series],
    *,
    holding_days: int = 5,
    symbol_col: str = "symbol",
    date_col: str = "trade_date",
    price_col: str = "close",
) -> pl.DataFrame:
    """Walk forward through ``history`` and record fixed-holding-period trades.

    ``signal_fn(df)`` is called with the full history and must return a
    boolean Series the same length, with True marking entries on that bar.
    """
    needed = {symbol_col, date_col, price_col}
    if history.is_empty() or not needed.issubset(history.columns):
        return _empty_trades()

    try:
        df = history.sort([symbol_col, date_col])
        signals = signal_fn(df)
        if not isinstance(signals, pl.Series) or signals.len() != df.height:
            log.warning("signal_fn must return a boolean Series matching history rows")
            return _empty_trades()

        df = df.with_columns(signals.alias("_sig"))
        df = df.with_columns(
            pl.col(price_col).shift(-holding_days).over(symbol_col).alias("_exit_px"),
            pl.col(date_col).shift(-holding_days).over(symbol_col).alias("_exit_dt"),
        )
        trades = (df
                  .filter(pl.col("_sig") & pl.col("_exit_px").is_not_null())
                  .select(
                      pl.col(symbol_col).alias("symbol"),
                      pl.col(date_col).alias("entry_date"),
                      pl.col(price_col).alias("entry_price"),
                      pl.col("_exit_dt").alias("exit_date"),
                      pl.col("_exit_px").alias("exit_price"),
                      ((pl.col("_exit_px") - pl.col(price_col))
                       / pl.col(price_col) * 100.0).alias("pnl_pct"),
                  ))
        return trades
    except Exception as exc:  # noqa: BLE001
        log.warning("run_backtest failed: %s", exc)
        return _empty_trades()


def summary_stats(trades: pl.DataFrame) -> pl.DataFrame:
    """Aggregate per-trade results into a one-row summary DataFrame."""
    if trades.is_empty() or "pnl_pct" not in trades.columns:
        return _empty_stats()
    try:
        pnl = trades["pnl_pct"].cast(pl.Float64, strict=False).drop_nulls()
        if pnl.is_empty():
            return _empty_stats()

        std = pnl.std() or 0.0
        sharpe = float(pnl.mean() / std) if std > 0 else 0.0

        return pl.DataFrame([{
            "trades":        pnl.len(),
            "win_rate":      round(float((pnl > 0).sum() / pnl.len() * 100.0), 2),
            "avg_pnl_pct":   round(float(pnl.mean()), 3),
            "total_pnl_pct": round(float(pnl.sum()), 3),
            "best_pct":      round(float(pnl.max()), 3),
            "worst_pct":     round(float(pnl.min()), 3),
            "sharpe":        round(sharpe, 3),
        }])
    except Exception as exc:  # noqa: BLE001
        log.warning("summary_stats failed: %s", exc)
        return _empty_stats()
