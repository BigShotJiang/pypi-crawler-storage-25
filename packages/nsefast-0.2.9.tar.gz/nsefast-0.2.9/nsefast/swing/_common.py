"""Shared helpers for the swing layer.

The single rule: every public swing function returns a Polars DataFrame and
**never raises**. ``empty_with_schema(schema)`` builds the canonical empty
DataFrame with the *same dtypes* the success path would emit, so downstream
``.sort()`` / numeric ops behave identically on empty input.
"""

from __future__ import annotations

from typing import Mapping

import polars as pl


def empty_with_schema(schema: Mapping[str, pl.DataType]) -> pl.DataFrame:
    """Empty DataFrame with explicitly-typed columns (matches success path)."""
    return pl.DataFrame(schema=dict(schema))


def empty_like(cols: list[str]) -> pl.DataFrame:
    """Empty DataFrame with all columns string-typed.

    Prefer :func:`empty_with_schema` when the success path emits numerics.
    Kept for callers that genuinely want all-Utf8 (e.g. avoid_list).
    """
    return pl.DataFrame(schema={c: pl.Utf8 for c in cols})


def normalize_lower(df: pl.DataFrame) -> pl.DataFrame:
    """Lowercase column names so swing helpers can match canonical names."""
    if df.is_empty() and not df.columns:
        return df
    return df.rename({c: c.lower() for c in df.columns})


def has_columns(df: pl.DataFrame, cols: list[str]) -> bool:
    return set(cols).issubset(set(df.columns))
