"""Position sizing, stop loss, and risk/reward.

Two flavors:

- **Scalar helpers** (``position_size``, ``risk_reward``) for ad-hoc use.
- **DataFrame helpers** (``add_atr``, ``add_atr_stop``, ``add_position_size``)
  that add new columns without mutating inputs.

The ATR helper expects a long-format OHLC DataFrame already sorted by
``(symbol, trade_date)``. Use :func:`nsefast.processing.normalize.normalize_columns`
first if you're feeding raw NSE bhavcopy data.
"""

from __future__ import annotations

import math

import polars as pl

from nsefast.logging_setup import get_logger

log = get_logger(__name__)


# ---------- scalar helpers ---------------------------------------------------


def position_size(
    capital: float,
    entry: float,
    stop: float,
    risk_pct: float = 1.0,
) -> int:
    """Quantity such that ``(entry-stop) * qty == capital * risk_pct/100``.

    Returns 0 if the stop is above the entry (long-only assumption) or any
    input is non-finite.
    """
    try:
        diff = entry - stop
        if not math.isfinite(diff) or diff <= 0:
            return 0
        risk_rs = capital * (risk_pct / 100.0)
        return max(int(risk_rs / diff), 0)
    except Exception as exc:  # noqa: BLE001
        log.warning("position_size failed: %s", exc)
        return 0


def risk_reward(entry: float, stop: float, target: float) -> float:
    """Reward-to-risk multiple (``(target-entry) / (entry-stop)``).

    Returns ``0.0`` for invalid setups.
    """
    try:
        risk = entry - stop
        if risk <= 0 or not math.isfinite(risk):
            return 0.0
        reward = target - entry
        if not math.isfinite(reward):
            return 0.0
        return round(reward / risk, 3)
    except Exception as exc:  # noqa: BLE001
        log.warning("risk_reward failed: %s", exc)
        return 0.0


# ---------- DataFrame helpers ------------------------------------------------


def add_atr(
    df: pl.DataFrame,
    *,
    period: int = 14,
    high_col: str = "high",
    low_col: str = "low",
    close_col: str = "close",
    group_col: str = "symbol",
) -> pl.DataFrame:
    """Add an ``atr`` column = simple moving average of True Range over ``period``.

    True Range follows Wilder's definition
    ``max(H-L, |H - prev_close|, |L - prev_close|)`` but the smoothing here is
    a plain SMA, **not** Wilder's RMA. For most swing-trading filters the two
    are interchangeable; if you need exact Wilder smoothing, post-process the
    ``atr`` column with an EWM(alpha=1/period).

    No-op (returns input) if any of the required OHLC columns are missing.
    """
    needed = {high_col, low_col, close_col}
    if not needed.issubset(df.columns):
        log.debug("add_atr: missing one of %s", needed)
        return df
    try:
        prev_close = (
            pl.col(close_col).shift(1).over(group_col)
            if group_col in df.columns
            else pl.col(close_col).shift(1)
        )
        tr = pl.max_horizontal(
            pl.col(high_col) - pl.col(low_col),
            (pl.col(high_col) - prev_close).abs(),
            (pl.col(low_col) - prev_close).abs(),
        )
        atr_expr = (
            tr.rolling_mean(period).over(group_col)
            if group_col in df.columns
            else tr.rolling_mean(period)
        )
        return df.with_columns(atr_expr.alias("atr"))
    except Exception as exc:  # noqa: BLE001
        log.warning("add_atr failed: %s", exc)
        return df


def add_atr_stop(
    df: pl.DataFrame,
    *,
    mult: float = 2.0,
    atr_col: str = "atr",
    price_col: str = "close",
) -> pl.DataFrame:
    """Add a ``stop_loss`` column = ``price - mult * atr`` (long-only)."""
    if atr_col not in df.columns or price_col not in df.columns:
        log.debug("add_atr_stop: missing %s or %s", atr_col, price_col)
        return df
    try:
        return df.with_columns(
            (pl.col(price_col).cast(pl.Float64, strict=False)
             - pl.col(atr_col).cast(pl.Float64, strict=False) * mult)
            .alias("stop_loss")
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("add_atr_stop failed: %s", exc)
        return df


def add_position_size(
    df: pl.DataFrame,
    *,
    capital: float,
    risk_pct: float = 1.0,
    entry_col: str = "close",
    stop_col: str = "stop_loss",
) -> pl.DataFrame:
    """Add a ``qty`` column sized so that ``(entry-stop)*qty == capital*risk_pct/100``."""
    if entry_col not in df.columns or stop_col not in df.columns:
        log.debug("add_position_size: missing %s or %s", entry_col, stop_col)
        return df
    try:
        diff = (pl.col(entry_col).cast(pl.Float64, strict=False)
                - pl.col(stop_col).cast(pl.Float64, strict=False))
        risk_rs = capital * (risk_pct / 100.0)
        qty = pl.when(diff > 0).then(risk_rs / diff).otherwise(0).cast(pl.Int64)
        return df.with_columns(qty.alias("qty"))
    except Exception as exc:  # noqa: BLE001
        log.warning("add_position_size failed: %s", exc)
        return df


# ---------- alternative stops ------------------------------------------------
#
# Swing traders rarely use one fixed stop. Three common alternatives:
#
#   * Chandelier  — anchored to the rolling-high minus an ATR multiple.
#                   Tightens after pullbacks but stays loose enough to ride
#                   trends.
#   * Trailing    — running max of (close - mult*ATR) per symbol; never
#                   moves down once set. The classic "give back" trail.
#   * Swing-low   — the lowest low of the last ``window`` bars. Pure
#                   price-action stop, no ATR dependency.
#
# All three add one column and never raise. Each computes ATR if not
# already present.


def _ensure_atr(df: pl.DataFrame, period: int, group_col: str,
                high_col: str, low_col: str, close_col: str) -> pl.DataFrame:
    return df if "atr" in df.columns else add_atr(
        df, period=period, group_col=group_col,
        high_col=high_col, low_col=low_col, close_col=close_col,
    )


def add_chandelier_stop(
    df: pl.DataFrame,
    *,
    period: int = 22,
    mult: float = 3.0,
    high_col: str = "high",
    low_col: str = "low",
    close_col: str = "close",
    group_col: str = "symbol",
) -> pl.DataFrame:
    """Add ``chandelier_stop`` = ``rolling_max(high, period) - mult * atr``.

    The rolling max is per-symbol when ``group_col`` is present.
    """
    if not {high_col, low_col, close_col}.issubset(df.columns):
        log.debug("add_chandelier_stop: missing OHLC")
        return df
    try:
        out = _ensure_atr(df, period, group_col, high_col, low_col, close_col)
        if "atr" not in out.columns:
            return df
        g = group_col if group_col in out.columns else None
        h = pl.col(high_col).cast(pl.Float64, strict=False)
        roll_max = h.rolling_max(period).over(g) if g else h.rolling_max(period)
        return out.with_columns(
            (roll_max - mult * pl.col("atr")).alias("chandelier_stop")
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("add_chandelier_stop failed: %s", exc)
        return df


def add_trailing_atr_stop(
    df: pl.DataFrame,
    *,
    period: int = 14,
    mult: float = 3.0,
    price_col: str = "close",
    high_col: str = "high",
    low_col: str = "low",
    group_col: str = "symbol",
) -> pl.DataFrame:
    """Add ``trailing_stop`` = per-symbol cumulative max of ``close - mult*atr``.

    Once a stop level is set it never moves down — the canonical trailing
    behaviour. NaNs during ATR warm-up are ignored by ``cum_max``.

    .. note:: Monotonicity is in **input row order**. If your DataFrame
       is not already sorted by ``trade_date`` within each symbol, sort
       it first (``df.sort([group_col, "trade_date"])``); the same caveat
       applies to every rolling/cumulative helper in the library.
    """
    if not {high_col, low_col, price_col}.issubset(df.columns):
        log.debug("add_trailing_atr_stop: missing OHLC")
        return df
    try:
        out = _ensure_atr(df, period, group_col, high_col, low_col, price_col)
        if "atr" not in out.columns:
            return df
        g = group_col if group_col in out.columns else None
        raw = (pl.col(price_col).cast(pl.Float64, strict=False)
               - mult * pl.col("atr"))
        trail = raw.cum_max().over(g) if g else raw.cum_max()
        return out.with_columns(trail.alias("trailing_stop"))
    except Exception as exc:  # noqa: BLE001
        log.warning("add_trailing_atr_stop failed: %s", exc)
        return df


def add_swing_low_stop(
    df: pl.DataFrame,
    *,
    window: int = 10,
    low_col: str = "low",
    group_col: str = "symbol",
) -> pl.DataFrame:
    """Add ``swing_low_stop`` = rolling minimum of ``low`` over ``window`` bars.

    Pure price-action: no ATR dependency. Per-symbol when ``group_col``
    is present.
    """
    if low_col not in df.columns:
        log.debug("add_swing_low_stop: missing %s", low_col)
        return df
    try:
        g = group_col if group_col in df.columns else None
        l = pl.col(low_col).cast(pl.Float64, strict=False)
        roll_min = l.rolling_min(window).over(g) if g else l.rolling_min(window)
        return df.with_columns(roll_min.alias("swing_low_stop"))
    except Exception as exc:  # noqa: BLE001
        log.warning("add_swing_low_stop failed: %s", exc)
        return df


# ---------- volatility-targeted sizing ---------------------------------------


def add_vol_target_size(
    df: pl.DataFrame,
    *,
    capital: float,
    target_daily_vol_pct: float = 0.5,
    atr_col: str = "atr",
    price_col: str = "close",
    period: int = 14,
    high_col: str = "high",
    low_col: str = "low",
    group_col: str = "symbol",
) -> pl.DataFrame:
    """Add ``vol_qty`` = quantity such that each position contributes the
    same daily rupee volatility, ``capital * target_daily_vol_pct / 100``.

    Quantity formula::

        target_vol_rs = capital * target_daily_vol_pct / 100
        atr_pct       = atr / close
        qty           = target_vol_rs / (close * atr_pct)
                      = target_vol_rs / atr

    This is what most quant desks use instead of equal-rupee or
    equal-risk sizing — high-vol names get fewer shares, low-vol names
    get more, so each contributes the same daily P&L volatility.

    Computes ATR if not already present. Returns ``df`` unchanged on any
    missing dependency. ``vol_qty`` is an integer (truncated).
    """
    if price_col not in df.columns:
        log.debug("add_vol_target_size: missing %s", price_col)
        return df
    if not (capital > 0 and target_daily_vol_pct > 0):
        log.debug("add_vol_target_size: bad capital/target")
        return df
    try:
        out = (df if atr_col in df.columns
               else _ensure_atr(df, period, group_col, high_col, low_col, price_col))
        if atr_col not in out.columns:
            return df
        target_rs = capital * target_daily_vol_pct / 100.0
        safe_atr = pl.when(pl.col(atr_col) > 0).then(pl.col(atr_col)).otherwise(None)
        qty = (target_rs / safe_atr).cast(pl.Int64, strict=False)
        return out.with_columns(qty.alias("vol_qty"))
    except Exception as exc:  # noqa: BLE001
        log.warning("add_vol_target_size failed: %s", exc)
        return df
