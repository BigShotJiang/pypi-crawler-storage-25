"""Relative-strength scoring vs a benchmark (NIFTY, sector index, …).

A symbol is a "leader" when it both moves up *and* outperforms its
benchmark. Absolute momentum alone is famously fooled by broad rallies —
relative strength is the standard fix.

Two helpers:

- :func:`add_relative_strength` — adds ``rs_{lookback}`` = symbol's
  ``lookback``-day percent change minus the benchmark's, in percentage
  points.
- :func:`add_rs_score` — cross-sectional 0–100 percentile rank of
  ``rs_{lookback}`` *within each trade_date*, so it's directly comparable
  across days.

Both functions are crash-proof (return input unchanged on any error or
missing column).
"""

from __future__ import annotations

import polars as pl

from nsefast.logging_setup import get_logger

log = get_logger(__name__)


def _pct_change_over(col: pl.Expr, lookback: int, group_col: str | None) -> pl.Expr:
    """Return-over-lookback in percent: ``(col / col.shift(lookback) - 1) * 100``."""
    prev = col.shift(lookback).over(group_col) if group_col else col.shift(lookback)
    safe_prev = pl.when(prev > 0).then(prev).otherwise(None)
    return (col / safe_prev - 1.0) * 100.0


def add_relative_strength(
    prices_df: pl.DataFrame,
    benchmark_df: pl.DataFrame,
    *,
    lookback: int = 20,
    on: str = "close",
    benchmark_on: str | None = None,
    date_col: str = "trade_date",
    group_col: str = "symbol",
    output_col: str | None = None,
) -> pl.DataFrame:
    """Add an ``rs_{lookback}`` column = symbol return − benchmark return.

    ``prices_df`` is the long-format OHLCV panel (one row per
    ``(symbol, trade_date)``).
    ``benchmark_df`` must have ``date_col`` and a price column (defaults to
    ``on``); use ``benchmark_on`` to point at a different column name.

    Both returns are computed over ``lookback`` *rows* (typically days),
    expressed in percent. The output column name defaults to
    ``rs_{lookback}``; override with ``output_col``.

    Returns the input unchanged on any error or missing dependency.
    """
    out_col = output_col or f"rs_{lookback}"
    if prices_df is None or prices_df.is_empty():
        return prices_df if prices_df is not None else pl.DataFrame()
    if benchmark_df is None or benchmark_df.is_empty():
        log.debug("add_relative_strength: empty benchmark")
        return prices_df
    if on not in prices_df.columns or date_col not in prices_df.columns:
        log.debug("add_relative_strength: missing %s or %s in prices", on, date_col)
        return prices_df

    bcol = benchmark_on or on
    if bcol not in benchmark_df.columns or date_col not in benchmark_df.columns:
        log.debug("add_relative_strength: benchmark missing %s/%s", bcol, date_col)
        return prices_df

    try:
        g = group_col if group_col in prices_df.columns else None

        # Enforce one benchmark row per date to keep the left-join 1:N
        # (one symbol-row → at most one benchmark row). If the supplied
        # benchmark frame has duplicate dates we keep the *last* by
        # original order — never silently fan out the price panel.
        bench = (benchmark_df
                 .select([
                     pl.col(date_col).cast(pl.Date, strict=False),
                     pl.col(bcol).cast(pl.Float64, strict=False).alias("_bench_close"),
                 ])
                 .drop_nulls()
                 .group_by(date_col, maintain_order=True)
                 .agg(pl.col("_bench_close").last())
                 .sort(date_col)
                 .with_columns(
                     _pct_change_over(pl.col("_bench_close"), lookback, None)
                     .alias("_bench_ret")
                 )
                 .select([date_col, "_bench_ret"]))

        sym_ret = _pct_change_over(
            pl.col(on).cast(pl.Float64, strict=False), lookback, g
        ).alias("_sym_ret")

        out = (prices_df
               .with_columns(sym_ret)
               .join(bench, on=date_col, how="left")
               .with_columns(
                   (pl.col("_sym_ret") - pl.col("_bench_ret")).alias(out_col)
               )
               .drop(["_sym_ret", "_bench_ret"]))
        return out
    except Exception as exc:  # noqa: BLE001
        log.warning("add_relative_strength failed: %s", exc)
        return prices_df


def add_rs_score(
    df: pl.DataFrame,
    *,
    rs_col: str = "rs_20",
    date_col: str = "trade_date",
    output_col: str | None = None,
) -> pl.DataFrame:
    """Cross-sectional 0–100 percentile rank of ``rs_col`` within each
    ``date_col``. Higher = stronger relative outperformance that day."""
    out_col = output_col or f"{rs_col}_score"
    if df is None or df.is_empty():
        return df if df is not None else pl.DataFrame()
    if rs_col not in df.columns or date_col not in df.columns:
        log.debug("add_rs_score: missing %s or %s", rs_col, date_col)
        return df
    try:
        rank = (pl.col(rs_col).rank(method="average").over(date_col) - 1.0)
        size = (pl.col(rs_col).count().over(date_col) - 1.0)
        score = (pl.when(size > 0)
                   .then(100.0 * rank / size)
                   .otherwise(50.0)
                   .clip(0.0, 100.0))
        return df.with_columns(score.alias(out_col))
    except Exception as exc:  # noqa: BLE001
        log.warning("add_rs_score failed: %s", exc)
        return df
