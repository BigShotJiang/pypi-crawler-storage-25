"""Portfolio-level risk: position sizing across many picks, sector and
single-name caps, correlation-aware cluster caps.

Per-trade sizing lives in :mod:`nsefast.swing.risk`. This module composes
those primitives across a *basket* of picks so a 10-name swing portfolio
respects the same sector/concentration limits a real desk would enforce.

Public API
----------

- :func:`portfolio_size` — equal-weight (or weight-column) allocation of
  ``capital`` across the top ``max_positions`` picks, capped by single-name
  / sector / cluster percentages, with the residual left as cash.
- :func:`correlation_clusters` — group symbols whose ``lookback``-day
  return correlation exceeds ``threshold`` (greedy union-find). The output
  feeds straight back into ``portfolio_size`` via the ``cluster_col``
  argument.

Both return Polars DataFrames and never raise — input issues yield an
empty DataFrame with the documented schema.
"""

from __future__ import annotations

from typing import Iterable

import numpy as np
import polars as pl

from nsefast.logging_setup import get_logger

log = get_logger(__name__)


# ---- correlation clustering ------------------------------------------------


def _empty_clusters() -> pl.DataFrame:
    return pl.DataFrame(schema={"symbol": pl.Utf8, "cluster_id": pl.Int64})


def correlation_clusters(
    history: pl.DataFrame,
    symbols: Iterable[str] | None = None,
    *,
    lookback: int = 60,
    threshold: float = 0.7,
    symbol_col: str = "symbol",
    date_col: str = "trade_date",
    price_col: str = "close",
) -> pl.DataFrame:
    """Group symbols whose pairwise return correlation ≥ ``threshold``.

    Uses union-find on the most recent ``lookback`` *daily log returns*
    per symbol. Symbols with insufficient history land in their own
    singleton cluster. Output is a long DataFrame with columns
    ``symbol`` / ``cluster_id`` (0-based, contiguous).
    """
    if history is None or history.is_empty():
        return _empty_clusters()
    needed = {symbol_col, date_col, price_col}
    if not needed.issubset(history.columns):
        log.debug("correlation_clusters: missing %s", needed - set(history.columns))
        return _empty_clusters()

    try:
        if symbols is not None:
            syms = list(dict.fromkeys(symbols))  # preserve order, dedupe
            if not syms:
                return _empty_clusters()
            history = history.filter(pl.col(symbol_col).is_in(syms))

        wide = (history
                .select([symbol_col, date_col,
                         pl.col(price_col).cast(pl.Float64, strict=False)])
                .drop_nulls()
                .sort(date_col)
                .pivot(index=date_col, on=symbol_col, values=price_col,
                       aggregate_function="last"))

        # Tail to the most recent (lookback + 1) bars and convert to numpy
        wide = wide.tail(lookback + 1)
        if wide.height < 3:
            log.debug("correlation_clusters: not enough rows")
            cols = [c for c in wide.columns if c != date_col]
            return pl.DataFrame({"symbol": cols,
                                 "cluster_id": list(range(len(cols)))})

        cols = [c for c in wide.columns if c != date_col]
        prices = wide.select(cols).to_numpy().astype(float)
        # daily log returns
        rets = np.log(prices[1:] / np.where(prices[:-1] > 0, prices[:-1], np.nan))

        # symbols with too many NaNs go into singleton clusters
        valid_mask = (~np.isnan(rets)).sum(axis=0) >= max(5, lookback // 4)
        clusters = list(range(len(cols)))  # union-find parent array

        def find(x: int) -> int:
            while clusters[x] != x:
                clusters[x] = clusters[clusters[x]]
                x = clusters[x]
            return x

        def union(a: int, b: int) -> None:
            ra, rb = find(a), find(b)
            if ra != rb:
                clusters[max(ra, rb)] = min(ra, rb)

        valid_idx = [i for i, v in enumerate(valid_mask) if v]
        if len(valid_idx) >= 2:
            # Pairwise NaN-tolerant Pearson correlation: for each pair
            # use only rows where BOTH series are non-NaN. This avoids
            # under-clustering when symbols have staggered missingness
            # (e.g. one symbol is younger than another).
            min_overlap = max(5, lookback // 4)
            for ii in range(len(valid_idx)):
                a = rets[:, valid_idx[ii]]
                for jj in range(ii + 1, len(valid_idx)):
                    b = rets[:, valid_idx[jj]]
                    mask = ~(np.isnan(a) | np.isnan(b))
                    if mask.sum() < min_overlap:
                        continue
                    aa, bb = a[mask], b[mask]
                    sa, sb = aa.std(), bb.std()
                    if sa <= 0 or sb <= 0:
                        continue
                    c = float(((aa - aa.mean()) * (bb - bb.mean())).mean()
                              / (sa * sb))
                    if np.isfinite(c) and c >= threshold:
                        union(valid_idx[ii], valid_idx[jj])

        # Compact cluster ids
        roots = [find(i) for i in range(len(cols))]
        remap: dict[int, int] = {}
        compact = []
        for r in roots:
            if r not in remap:
                remap[r] = len(remap)
            compact.append(remap[r])
        return pl.DataFrame({"symbol": cols, "cluster_id": compact})
    except Exception as exc:  # noqa: BLE001
        log.warning("correlation_clusters failed: %s", exc)
        return _empty_clusters()


# ---- portfolio sizing ------------------------------------------------------


_PORTFOLIO_SCHEMA = {
    "symbol":         pl.Utf8,
    "weight":         pl.Float64,
    "allocated_pct":  pl.Float64,
    "allocated_rs":   pl.Float64,
    "capped_by":      pl.Utf8,
}


def _empty_portfolio() -> pl.DataFrame:
    return pl.DataFrame(schema=_PORTFOLIO_SCHEMA)


def portfolio_size(
    picks: pl.DataFrame,
    capital: float,
    *,
    max_positions: int = 10,
    max_single_pct: float = 10.0,
    max_sector_pct: float = 30.0,
    max_cluster_pct: float | None = None,
    sector_col: str = "sector",
    cluster_col: str = "cluster_id",
    weight_col: str | None = None,
    symbol_col: str = "symbol",
) -> pl.DataFrame:
    """Allocate ``capital`` across at most ``max_positions`` picks.

    True water-fill allocator:

    1. Take the first ``max_positions`` rows in the order supplied
       (caller pre-sorts by score / RS / whatever).
    2. Initial weight = ``weight_col`` if given else equal-weight
       (``1 / n``); normalised to sum to 1.
    3. Iterate (max 50 passes):

       a. Clip each weight at ``max_single_pct / 100``.
       b. Proportionally scale any sector group whose sum exceeds
          ``max_sector_pct / 100`` down to the cap.
       c. Same for clusters when ``max_cluster_pct`` is given.
       d. Compute residual = ``1.0 - sum(weights)``. If positive,
          redistribute proportional to *available headroom* on the
          uncapped names (limited by single/sector/cluster room each).
          Stops as soon as no headroom remains — that shortfall is the
          *cash residual* (not an error: caps make full deployment
          infeasible).

    Output columns: ``symbol``, ``weight`` (0-1), ``allocated_pct``
    (0-100), ``allocated_rs`` (rupees), ``capped_by`` (``""`` / single
    / sector / cluster). ``capped_by`` is recomputed *from the final
    weights* against each active constraint with a tight tolerance,
    so the label always names the binding cap. When more than one cap
    binds simultaneously, precedence is **single → cluster → sector**
    (tightest-scope first).

    Returns the canonical empty frame on any error. Never raises.
    """
    if picks is None or picks.is_empty() or capital <= 0:
        return _empty_portfolio()
    if symbol_col not in picks.columns:
        log.debug("portfolio_size: missing %s", symbol_col)
        return _empty_portfolio()

    try:
        df = picks.head(max_positions)
        n = df.height
        if n == 0:
            return _empty_portfolio()

        single_cap = max_single_pct / 100.0
        sector_cap = max_sector_pct / 100.0
        cluster_cap = (max_cluster_pct / 100.0) if max_cluster_pct else None

        # Initial weights
        if weight_col and weight_col in df.columns:
            raw = (df[weight_col].cast(pl.Float64, strict=False)
                                .fill_null(0.0)
                                .to_list())
            tot = sum(max(w, 0.0) for w in raw)
            weights = ([max(w, 0.0) / tot for w in raw]
                       if tot > 0 else [1.0 / n] * n)
        else:
            weights = [1.0 / n] * n

        symbols = df[symbol_col].to_list()
        sectors = (df[sector_col].to_list()
                   if sector_col in df.columns else [None] * n)
        clusters = (df[cluster_col].to_list()
                    if (cluster_cap is not None and cluster_col in df.columns)
                    else [None] * n)

        # Pre-build group → member-indices maps (skip None keys)
        def _groups(keys):
            g: dict = {}
            for i, k in enumerate(keys):
                if k is not None:
                    g.setdefault(k, []).append(i)
            return g

        sector_groups = _groups(sectors)
        cluster_groups = _groups(clusters) if cluster_cap is not None else {}

        TOL = 1e-9

        def _scale_groups(groups, cap):
            if cap is None:
                return False
            changed = False
            for _, idx in groups.items():
                s = sum(weights[i] for i in idx)
                if s > cap + TOL:
                    scale = cap / s
                    for i in idx:
                        weights[i] *= scale
                    changed = True
            return changed

        def _headroom(i):
            """How much extra weight name *i* can absorb without breaking any cap."""
            room = single_cap - weights[i]
            for groups, cap in (
                (sector_groups, sector_cap),
                (cluster_groups, cluster_cap),
            ):
                if cap is None:
                    continue
                # Find the group this row belongs to (membership is
                # exclusive: keys are scalar sector/cluster ids).
                for _, idx in groups.items():
                    if i in idx:
                        used = sum(weights[j] for j in idx)
                        room = min(room, cap - used)
                        break
            return max(0.0, room)

        for _ in range(50):
            # 1. Down-pass: enforce all caps.
            for i in range(n):
                if weights[i] > single_cap:
                    weights[i] = single_cap
            _scale_groups(sector_groups, sector_cap)
            _scale_groups(cluster_groups, cluster_cap)

            # 2. Up-pass: redistribute any residual to names with headroom.
            residual = 1.0 - sum(weights)
            if residual <= TOL:
                break
            headrooms = [_headroom(i) for i in range(n)]
            total_room = sum(headrooms)
            if total_room <= TOL:
                # Genuinely no room left — caps make full deployment
                # infeasible. Remainder is cash by design.
                break
            give = min(residual, total_room)
            for i in range(n):
                if total_room > 0:
                    weights[i] += give * headrooms[i] / total_room

        # Recompute capped_by from FINAL weights vs each active constraint.
        # Precedence: single (tightest scope) → cluster → sector.
        capped_by = [""] * n
        for i in range(n):
            if weights[i] >= single_cap - TOL:
                capped_by[i] = "single"
                continue
            if cluster_cap is not None and clusters[i] is not None:
                idx = cluster_groups.get(clusters[i], [])
                if abs(sum(weights[j] for j in idx) - cluster_cap) <= TOL * max(1, len(idx)):
                    capped_by[i] = "cluster"
                    continue
            if sectors[i] is not None:
                idx = sector_groups.get(sectors[i], [])
                if abs(sum(weights[j] for j in idx) - sector_cap) <= TOL * max(1, len(idx)):
                    capped_by[i] = "sector"

        out = pl.DataFrame({
            "symbol":        symbols,
            "weight":        weights,
            "allocated_pct": [w * 100.0 for w in weights],
            "allocated_rs":  [w * capital for w in weights],
            "capped_by":     capped_by,
        }, schema=_PORTFOLIO_SCHEMA)
        return out
    except Exception as exc:  # noqa: BLE001
        log.warning("portfolio_size failed: %s", exc)
        return _empty_portfolio()
