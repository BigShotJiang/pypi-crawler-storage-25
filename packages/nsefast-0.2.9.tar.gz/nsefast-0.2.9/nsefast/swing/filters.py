"""Universe filters for the swing scanner.

Each filter is a pure function over a Polars DataFrame and returns a *subset*
of rows. Filters are intentionally compose-able::

    df = (bhav_df
          .pipe(series_eq_only)
          .pipe(price_band, min_price=20, max_price=5000)
          .pipe(liquid_universe, min_turnover=1e7)
          .pipe(exclude_surveillance, asm_df=asm, gsm_df=gsm, fo_ban_df=ban))

If a required column is missing, the filter is a no-op (it returns the input
unchanged) and logs a debug message. Filters never raise.
"""

from __future__ import annotations

import polars as pl

from nsefast.logging_setup import get_logger

log = get_logger(__name__)


def _safe(df: pl.DataFrame, fn, label: str) -> pl.DataFrame:
    try:
        return fn(df)
    except Exception as exc:  # noqa: BLE001
        log.warning("filter %s failed; passing through: %s", label, exc)
        return df


def liquid_universe(
    df: pl.DataFrame,
    *,
    min_turnover: float = 1e7,
    turnover_col: str = "turnover",
) -> pl.DataFrame:
    """Drop rows where ``turnover_col`` is below ``min_turnover`` (₹)."""
    if turnover_col not in df.columns:
        log.debug("liquid_universe: %s not present, skipping", turnover_col)
        return df
    return _safe(
        df,
        lambda d: d.filter(pl.col(turnover_col).cast(pl.Float64, strict=False) >= min_turnover),
        "liquid_universe",
    )


def price_band(
    df: pl.DataFrame,
    *,
    min_price: float = 20.0,
    max_price: float = 10000.0,
    price_col: str = "close",
) -> pl.DataFrame:
    """Keep rows where ``price_col`` is within ``[min_price, max_price]``."""
    if price_col not in df.columns:
        log.debug("price_band: %s not present, skipping", price_col)
        return df
    return _safe(
        df,
        lambda d: d.filter(
            (pl.col(price_col).cast(pl.Float64, strict=False) >= min_price)
            & (pl.col(price_col).cast(pl.Float64, strict=False) <= max_price)
        ),
        "price_band",
    )


def series_eq_only(df: pl.DataFrame, *, series_col: str = "series") -> pl.DataFrame:
    """Keep only the EQ series (drops BE, BZ, T2T, SM, etc.)."""
    if series_col not in df.columns:
        return df
    return _safe(
        df,
        lambda d: d.filter(pl.col(series_col).cast(pl.Utf8) == "EQ"),
        "series_eq_only",
    )


def exclude_symbols(
    df: pl.DataFrame,
    symbols: list[str] | pl.DataFrame | None,
    *,
    symbol_col: str = "symbol",
) -> pl.DataFrame:
    """Drop rows whose ``symbol_col`` appears in ``symbols``.

    ``symbols`` can be a plain list, or a DataFrame with a ``symbol`` column.
    """
    if symbols is None:
        return df
    if symbol_col not in df.columns:
        return df

    if isinstance(symbols, pl.DataFrame):
        if "symbol" not in symbols.columns or symbols.is_empty():
            return df
        bad = set(symbols["symbol"].cast(pl.Utf8).to_list())
    else:
        bad = {str(s) for s in symbols}

    if not bad:
        return df

    return _safe(
        df,
        lambda d: d.filter(~pl.col(symbol_col).cast(pl.Utf8).is_in(list(bad))),
        "exclude_symbols",
    )


def exclude_surveillance(
    df: pl.DataFrame,
    *,
    asm_df: pl.DataFrame | None = None,
    gsm_df: pl.DataFrame | None = None,
    fo_ban_df: pl.DataFrame | None = None,
    symbol_col: str = "symbol",
) -> pl.DataFrame:
    """Drop ASM, GSM, and F&O-ban symbols in one call."""
    out = df
    for label, src in (("asm", asm_df), ("gsm", gsm_df), ("fo_ban", fo_ban_df)):
        if src is None:
            continue
        try:
            out = exclude_symbols(out, src, symbol_col=symbol_col)
        except Exception as exc:  # noqa: BLE001
            log.warning("exclude_surveillance(%s) failed: %s", label, exc)
    return out


def min_avg_volume(
    df: pl.DataFrame,
    *,
    min_volume: int = 100_000,
    vol_col: str = "avg_volume_20",
) -> pl.DataFrame:
    """Drop illiquid symbols by 20-day average volume."""
    if vol_col not in df.columns:
        log.debug("min_avg_volume: %s not present, skipping", vol_col)
        return df
    return _safe(
        df,
        lambda d: d.filter(pl.col(vol_col).cast(pl.Float64, strict=False) >= min_volume),
        "min_avg_volume",
    )
