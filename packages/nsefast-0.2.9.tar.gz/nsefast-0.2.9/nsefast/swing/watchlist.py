"""Multi-source watchlists from deals + corporate filings.

These functions turn raw collector output into deduplicated, source-tagged
watchlists. Each row carries a ``source`` column so downstream consumers
can weigh signals (e.g. trust a buyback announcement more than a small bulk
deal).
"""

from __future__ import annotations

from collections.abc import Iterable

import polars as pl

from nsefast.logging_setup import get_logger
from nsefast.swing._common import empty_with_schema

log = get_logger(__name__)


_DEFAULT_KEYWORDS = (
    "dividend", "bonus", "split", "buyback", "results",
    "merger", "acquisition", "demerger", "open offer",
)


def bulk_block_watchlist(
    deals_df: pl.DataFrame,
    *,
    min_qty: int = 10_000,
    n: int | None = 50,
) -> pl.DataFrame:
    """Active names from bulk- or block-deal feeds.

    Aggregates by ``symbol``, computing total ``traded_qty`` and ``trade_count``.
    """
    empty = empty_with_schema({
        "symbol": pl.Utf8, "traded_qty": pl.Int64,
        "trade_count": pl.UInt32, "source": pl.Utf8,
    })
    if deals_df.is_empty() or "symbol" not in deals_df.columns:
        return empty
    try:
        df = deals_df.with_columns(pl.col("quantity").cast(pl.Int64, strict=False))
        if min_qty > 0:
            df = df.filter(pl.col("quantity") >= min_qty)
        agg = (df
               .group_by("symbol")
               .agg(
                   pl.col("quantity").sum().alias("traded_qty"),
                   pl.len().alias("trade_count"),
               )
               .with_columns(pl.lit("deals").alias("source"))
               .sort("traded_qty", descending=True, nulls_last=True))
        return agg.head(n) if n else agg
    except Exception as exc:  # noqa: BLE001
        log.warning("bulk_block_watchlist failed: %s", exc)
        return empty


def corporate_announcement_watchlist(
    ann_df: pl.DataFrame,
    *,
    keywords: Iterable[str] = _DEFAULT_KEYWORDS,
    n: int | None = 100,
) -> pl.DataFrame:
    """Recent corporate filings whose ``subject`` matches any keyword.

    Match is case-insensitive substring on the ``subject`` column.
    """
    empty = empty_with_schema({
        "symbol": pl.Utf8, "subject": pl.Utf8,
        "matched_keyword": pl.Utf8, "source": pl.Utf8,
    })
    if ann_df.is_empty() or "symbol" not in ann_df.columns:
        return empty
    if "subject" not in ann_df.columns:
        return empty

    kws = [k.strip().lower() for k in keywords if k and k.strip()]
    if not kws:
        return empty

    try:
        subj_lc = pl.col("subject").cast(pl.Utf8).str.to_lowercase()
        match_expr = subj_lc.str.contains(kws[0], literal=True)
        for k in kws[1:]:
            match_expr = match_expr | subj_lc.str.contains(k, literal=True)

        # Identify which keyword matched (first hit wins).
        first_match = pl.lit(None, dtype=pl.Utf8)
        for k in reversed(kws):
            first_match = (
                pl.when(subj_lc.str.contains(k, literal=True))
                .then(pl.lit(k))
                .otherwise(first_match)
            )

        out = (ann_df
               .filter(match_expr)
               .with_columns(
                   first_match.alias("matched_keyword"),
                   pl.lit("corporate").alias("source"),
               )
               .select(["symbol", "subject", "matched_keyword", "source"]))
        return out.head(n) if n else out
    except Exception as exc:  # noqa: BLE001
        log.warning("corporate_announcement_watchlist failed: %s", exc)
        return empty


def combined_watchlist(
    *,
    deals_df: pl.DataFrame | None = None,
    ann_df: pl.DataFrame | None = None,
    deals_min_qty: int = 10_000,
    ann_keywords: Iterable[str] = _DEFAULT_KEYWORDS,
) -> pl.DataFrame:
    """Union of bulk/block + corporate watchlists, tagged by source.

    Returns ``symbol, source, detail`` where ``detail`` is the qty for
    deals rows or the matched keyword for corporate rows.
    """
    empty = empty_with_schema({
        "symbol": pl.Utf8, "source": pl.Utf8, "detail": pl.Utf8,
    })
    out: list[pl.DataFrame] = []

    try:
        if deals_df is not None and not deals_df.is_empty():
            d = bulk_block_watchlist(deals_df, min_qty=deals_min_qty, n=None)
            if not d.is_empty():
                out.append(d.select(
                    pl.col("symbol").cast(pl.Utf8),
                    pl.lit("deals").alias("source"),
                    pl.col("traded_qty").cast(pl.Utf8).alias("detail"),
                ))

        if ann_df is not None and not ann_df.is_empty():
            a = corporate_announcement_watchlist(
                ann_df, keywords=ann_keywords, n=None
            )
            if not a.is_empty():
                out.append(a.select(
                    pl.col("symbol").cast(pl.Utf8),
                    pl.lit("corporate").alias("source"),
                    pl.col("matched_keyword").cast(pl.Utf8).alias("detail"),
                ))

        if not out:
            return empty
        return (pl.concat(out, how="vertical_relaxed")
                .unique(subset=["symbol", "source", "detail"])
                .sort(["source", "symbol"]))
    except Exception as exc:  # noqa: BLE001
        log.warning("combined_watchlist failed: %s", exc)
        return empty
