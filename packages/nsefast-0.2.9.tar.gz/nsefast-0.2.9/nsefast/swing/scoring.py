"""0–100 composite scoring of swing candidates.

Each ``*_score`` function adds a single new column (``momentum_score``,
``volume_score``, ``delivery_score``) clipped to ``[0, 100]``. Higher is
more bullish. ``composite_score`` blends whichever component scores are
present using configurable weights.

All functions are pure and never raise. Missing input columns produce a
``NaN``-filled score column rather than crashing.
"""

from __future__ import annotations

from typing import Mapping

import polars as pl

from nsefast.logging_setup import get_logger

log = get_logger(__name__)

_COMPONENT_COLS = ("momentum_score", "volume_score", "delivery_score")


def _scale_to_100(col: pl.Expr, lo: float, hi: float) -> pl.Expr:
    span = max(hi - lo, 1e-9)
    return ((col - lo) / span * 100.0).clip(0.0, 100.0)


def momentum_score(
    df: pl.DataFrame,
    *,
    change_col: str = "percent_change",
    cap_pct: float = 10.0,
) -> pl.DataFrame:
    """Score ``[-cap_pct, +cap_pct]`` % change linearly to ``[0, 100]``.

    A ``-cap_pct`` move scores 0; ``+cap_pct`` scores 100; flat scores 50.
    """
    if change_col not in df.columns:
        log.debug("momentum_score: %s not present", change_col)
        return df.with_columns(pl.lit(None, dtype=pl.Float64).alias("momentum_score"))
    try:
        expr = pl.col(change_col).cast(pl.Float64, strict=False)
        return df.with_columns(
            _scale_to_100(expr, -cap_pct, cap_pct).alias("momentum_score")
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("momentum_score failed: %s", exc)
        return df.with_columns(pl.lit(None, dtype=pl.Float64).alias("momentum_score"))


def volume_score(
    df: pl.DataFrame,
    *,
    vol_col: str = "volume",
    avg_col: str = "avg_volume_20",
    cap_ratio: float = 5.0,
) -> pl.DataFrame:
    """Score ratio ``volume / avg_volume_20`` from 1× → 50, ``cap_ratio`` × → 100."""
    if vol_col not in df.columns or avg_col not in df.columns:
        log.debug("volume_score: %s or %s missing", vol_col, avg_col)
        return df.with_columns(pl.lit(None, dtype=pl.Float64).alias("volume_score"))
    try:
        ratio = (
            pl.col(vol_col).cast(pl.Float64, strict=False)
            / pl.when(pl.col(avg_col).cast(pl.Float64, strict=False) > 0)
                .then(pl.col(avg_col).cast(pl.Float64, strict=False))
                .otherwise(None)
        )
        return df.with_columns(
            _scale_to_100(ratio, 0.0, cap_ratio).alias("volume_score")
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("volume_score failed: %s", exc)
        return df.with_columns(pl.lit(None, dtype=pl.Float64).alias("volume_score"))


def delivery_score(
    df: pl.DataFrame,
    *,
    deliv_col: str = "delivery_pct",
) -> pl.DataFrame:
    """Score raw delivery % directly (it is already on a 0-100 scale)."""
    if deliv_col not in df.columns:
        log.debug("delivery_score: %s not present", deliv_col)
        return df.with_columns(pl.lit(None, dtype=pl.Float64).alias("delivery_score"))
    try:
        return df.with_columns(
            pl.col(deliv_col).cast(pl.Float64, strict=False)
            .clip(0.0, 100.0).alias("delivery_score")
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("delivery_score failed: %s", exc)
        return df.with_columns(pl.lit(None, dtype=pl.Float64).alias("delivery_score"))


_DEFAULT_WEIGHTS = {
    "momentum_score": 0.5,
    "volume_score":   0.3,
    "delivery_score": 0.2,
}


def composite_score(
    df: pl.DataFrame,
    weights: Mapping[str, float] | None = None,
) -> pl.DataFrame:
    """Add a ``score`` column = weighted average of present component scores.

    Components missing from the DataFrame are ignored and remaining weights
    are renormalised to sum to 1.0. Output is clipped to ``[0, 100]``.
    """
    weights = dict(weights or _DEFAULT_WEIGHTS)
    present = {c: w for c, w in weights.items() if c in df.columns}
    if not present:
        log.debug("composite_score: no component scores present")
        return df.with_columns(pl.lit(None, dtype=pl.Float64).alias("score"))

    total = sum(present.values()) or 1.0
    try:
        terms = [
            pl.col(c).cast(pl.Float64, strict=False).fill_null(0.0) * (w / total)
            for c, w in present.items()
        ]
        expr = terms[0]
        for t in terms[1:]:
            expr = expr + t
        return df.with_columns(expr.clip(0.0, 100.0).alias("score"))
    except Exception as exc:  # noqa: BLE001
        log.warning("composite_score failed: %s", exc)
        return df.with_columns(pl.lit(None, dtype=pl.Float64).alias("score"))


def add_all_scores(
    df: pl.DataFrame,
    weights: Mapping[str, float] | None = None,
) -> pl.DataFrame:
    """Convenience: momentum + volume + delivery + composite, all in one call."""
    return (df
            .pipe(momentum_score)
            .pipe(volume_score)
            .pipe(delivery_score)
            .pipe(composite_score, weights=weights))


# ---------- multi-timeframe Z-scores ----------------------------------------
#
# Single-day percent-change scores drown in noise once you look across
# symbols. The standard fix is to score each row by how many standard
# deviations *its own* recent history sits above its mean. Z > 1.5 is a
# meaningful move; Z > 2.5 is exceptional. These helpers operate on a
# long-format panel and are per-symbol via ``.over("symbol")``.


def _zscore_over(col: pl.Expr, lookback: int, group_col: str | None) -> pl.Expr:
    mean = col.rolling_mean(lookback).over(group_col) if group_col else col.rolling_mean(lookback)
    std  = col.rolling_std(lookback).over(group_col)  if group_col else col.rolling_std(lookback)
    safe_std = pl.when(std > 0).then(std).otherwise(None)
    return (col - mean) / safe_std


def momentum_zscore(
    df: pl.DataFrame,
    *,
    lookback: int = 20,
    col: str = "close",
    group_col: str = "symbol",
    output_col: str | None = None,
) -> pl.DataFrame:
    """Add ``mom_z_{lookback}`` = Z-score of the per-symbol return-over-lookback.

    Specifically: compute the daily log-return, then take its rolling
    Z-score over the same lookback window. Output is dimensionless and
    cross-sectionally comparable.
    """
    out_col = output_col or f"mom_z_{lookback}"
    if df is None or df.is_empty():
        return df if df is not None else pl.DataFrame()
    if col not in df.columns:
        log.debug("momentum_zscore: missing %s", col)
        return df.with_columns(pl.lit(None, dtype=pl.Float64).alias(out_col))
    try:
        g = group_col if group_col in df.columns else None
        base = pl.col(col).cast(pl.Float64, strict=False)
        prev = base.shift(1).over(g) if g else base.shift(1)
        safe_prev = pl.when(prev > 0).then(prev).otherwise(None)
        ret = (base / safe_prev).log()
        return df.with_columns(_zscore_over(ret, lookback, g).alias(out_col))
    except Exception as exc:  # noqa: BLE001
        log.warning("momentum_zscore failed: %s", exc)
        return df.with_columns(pl.lit(None, dtype=pl.Float64).alias(out_col))


def volume_zscore(
    df: pl.DataFrame,
    *,
    lookback: int = 20,
    col: str = "volume",
    group_col: str = "symbol",
    output_col: str | None = None,
) -> pl.DataFrame:
    """Add ``vol_z_{lookback}`` = per-symbol Z-score of raw volume."""
    out_col = output_col or f"vol_z_{lookback}"
    if df is None or df.is_empty():
        return df if df is not None else pl.DataFrame()
    if col not in df.columns:
        log.debug("volume_zscore: missing %s", col)
        return df.with_columns(pl.lit(None, dtype=pl.Float64).alias(out_col))
    try:
        g = group_col if group_col in df.columns else None
        base = pl.col(col).cast(pl.Float64, strict=False)
        return df.with_columns(_zscore_over(base, lookback, g).alias(out_col))
    except Exception as exc:  # noqa: BLE001
        log.warning("volume_zscore failed: %s", exc)
        return df.with_columns(pl.lit(None, dtype=pl.Float64).alias(out_col))


def add_multi_timeframe_zscores(
    df: pl.DataFrame,
    *,
    lookbacks: tuple[int, ...] = (5, 20, 60),
    group_col: str = "symbol",
) -> pl.DataFrame:
    """Add momentum and volume Z-scores at each lookback (default 5/20/60)."""
    out = df
    for lb in lookbacks:
        out = momentum_zscore(out, lookback=lb, group_col=group_col)
        out = volume_zscore(out,   lookback=lb, group_col=group_col)
    return out
