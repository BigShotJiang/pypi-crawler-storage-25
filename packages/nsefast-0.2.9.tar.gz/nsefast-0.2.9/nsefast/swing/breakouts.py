"""Breakout-style swing setups and bar-level stats.

All functions take a long-format frame sorted by ``(symbol, trade_date)``
and either:

- *add* a column (``add_*`` functions), or
- *filter* to setup matches (``near_*``, ``*_breakout`` functions, which
  internally call the corresponding ``add_*`` to compute what they need).

Crash-proof: any error or missing dependency returns the input unchanged
(for ``add_*``) or an empty DataFrame with the same schema (for filters).
"""

from __future__ import annotations

import polars as pl

from nsefast.logging_setup import get_logger
from nsefast.swing.risk import add_atr

log = get_logger(__name__)


def _gc(df: pl.DataFrame, group_col: str) -> str | None:
    return group_col if group_col in df.columns else None


# ---- 52-week high/low ------------------------------------------------------


def add_52w_high_low(
    df: pl.DataFrame,
    *,
    window: int = 252,
    high_col: str = "high",
    low_col: str = "low",
    group_col: str = "symbol",
) -> pl.DataFrame:
    """Add ``high_52w`` / ``low_52w`` rolling extremes (default 252 bars)."""
    if df is None or df.is_empty():
        return df if df is not None else pl.DataFrame()
    if not {high_col, low_col}.issubset(df.columns):
        log.debug("add_52w_high_low: missing %s/%s", high_col, low_col)
        return df
    try:
        g = _gc(df, group_col)
        h = pl.col(high_col).cast(pl.Float64, strict=False)
        l = pl.col(low_col).cast(pl.Float64, strict=False)
        hi = h.rolling_max(window).over(g) if g else h.rolling_max(window)
        lo = l.rolling_min(window).over(g) if g else l.rolling_min(window)
        return df.with_columns([hi.alias("high_52w"), lo.alias("low_52w")])
    except Exception as exc:  # noqa: BLE001
        log.warning("add_52w_high_low failed: %s", exc)
        return df


def near_52w_high(
    df: pl.DataFrame,
    *,
    within_pct: float = 2.0,
    window: int = 252,
    close_col: str = "close",
    group_col: str = "symbol",
) -> pl.DataFrame:
    """Filter rows where ``close >= high_52w * (1 - within_pct/100)``."""
    if df is None or df.is_empty():
        return df if df is not None else pl.DataFrame()
    if close_col not in df.columns:
        log.debug("near_52w_high: missing %s", close_col)
        return df.head(0)
    try:
        out = add_52w_high_low(df, window=window, group_col=group_col)
        threshold = pl.col("high_52w") * (1.0 - within_pct / 100.0)
        return (out
                .filter(pl.col("high_52w").is_not_null()
                        & (pl.col(close_col) >= threshold))
                .with_columns(
                    (100.0 * (pl.col("high_52w") - pl.col(close_col))
                     / pl.col("high_52w"))
                    .alias("pct_below_52w_high")
                ))
    except Exception as exc:  # noqa: BLE001
        log.warning("near_52w_high failed: %s", exc)
        return df.head(0)


# ---- Donchian breakout -----------------------------------------------------


def donchian_breakout(
    df: pl.DataFrame,
    *,
    n: int = 20,
    close_col: str = "close",
    high_col: str = "high",
    group_col: str = "symbol",
) -> pl.DataFrame:
    """Filter rows where today's close exceeds the prior ``n``-bar high.

    "Prior" excludes today's bar, so the comparison is to the rolling max
    of the last ``n`` bars *ending yesterday* — the classic Turtle entry.
    """
    if df is None or df.is_empty():
        return df if df is not None else pl.DataFrame()
    if not {close_col, high_col}.issubset(df.columns):
        log.debug("donchian_breakout: missing %s/%s", close_col, high_col)
        return df.head(0)
    try:
        g = _gc(df, group_col)
        h = pl.col(high_col).cast(pl.Float64, strict=False)
        prior_high = (h.shift(1).rolling_max(n).over(g) if g
                      else h.shift(1).rolling_max(n))
        return (df
                .with_columns(prior_high.alias("dc_prior_high"))
                .filter(pl.col("dc_prior_high").is_not_null()
                        & (pl.col(close_col) > pl.col("dc_prior_high"))))
    except Exception as exc:  # noqa: BLE001
        log.warning("donchian_breakout failed: %s", exc)
        return df.head(0)


# ---- Volatility-contraction breakout --------------------------------------


def consolidation_breakout(
    df: pl.DataFrame,
    *,
    atr_period: int = 14,
    contraction_lookback: int = 20,
    expansion_mult: float = 1.5,
    close_col: str = "close",
    group_col: str = "symbol",
) -> pl.DataFrame:
    """Filter rows where ATR has *expanded* sharply after a quiet period.

    A bar matches when ``today's ATR > expansion_mult × min(ATR over the
    prior ``contraction_lookback`` bars)`` *and* the close made a new
    20-bar high — i.e. volatility contraction → expansion → directional
    breakout. The classic Volatility Contraction Pattern (VCP) signal.
    """
    if df is None or df.is_empty():
        return df if df is not None else pl.DataFrame()
    needed = {"high", "low", close_col}
    if not needed.issubset(df.columns):
        log.debug("consolidation_breakout: missing one of %s", needed)
        return df.head(0)
    try:
        g = _gc(df, group_col)
        out = add_atr(df, period=atr_period, group_col=group_col)
        if "atr" not in out.columns:
            return df.head(0)
        prior_min_atr = (
            pl.col("atr").shift(1).rolling_min(contraction_lookback).over(g)
            if g
            else pl.col("atr").shift(1).rolling_min(contraction_lookback)
        )
        prior_high = (
            pl.col(close_col).shift(1).rolling_max(20).over(g)
            if g
            else pl.col(close_col).shift(1).rolling_max(20)
        )
        out = out.with_columns([
            prior_min_atr.alias("_min_atr"),
            prior_high.alias("_prior_high"),
        ])
        return (out
                .filter(pl.col("_min_atr").is_not_null()
                        & pl.col("_prior_high").is_not_null()
                        & (pl.col("atr") > expansion_mult * pl.col("_min_atr"))
                        & (pl.col(close_col) > pl.col("_prior_high")))
                .drop(["_min_atr", "_prior_high"]))
    except Exception as exc:  # noqa: BLE001
        log.warning("consolidation_breakout failed: %s", exc)
        return df.head(0)


# ---- Bar-level stats -------------------------------------------------------


def add_gap_pct(
    df: pl.DataFrame,
    *,
    open_col: str = "open",
    prev_close_col: str = "prev_close",
    close_col: str = "close",
    group_col: str = "symbol",
) -> pl.DataFrame:
    """Add ``gap_pct`` = ``(open - prev_close) / prev_close * 100``.

    Uses the row's ``prev_close_col`` if present (NSE bhavcopy provides
    this as ``PREVCLOSE``); otherwise falls back to the per-symbol
    ``close.shift(1)``.
    """
    if df is None or df.is_empty():
        return df if df is not None else pl.DataFrame()
    if open_col not in df.columns:
        log.debug("add_gap_pct: missing %s", open_col)
        return df
    try:
        if prev_close_col in df.columns:
            prev = pl.col(prev_close_col).cast(pl.Float64, strict=False)
        elif close_col in df.columns:
            g = _gc(df, group_col)
            base = pl.col(close_col).cast(pl.Float64, strict=False)
            prev = base.shift(1).over(g) if g else base.shift(1)
        else:
            return df
        safe_prev = pl.when(prev > 0).then(prev).otherwise(None)
        gap = (pl.col(open_col).cast(pl.Float64, strict=False) / safe_prev - 1.0) * 100.0
        return df.with_columns(gap.alias("gap_pct"))
    except Exception as exc:  # noqa: BLE001
        log.warning("add_gap_pct failed: %s", exc)
        return df


def add_range_atr(
    df: pl.DataFrame,
    *,
    period: int = 14,
    high_col: str = "high",
    low_col: str = "low",
    group_col: str = "symbol",
) -> pl.DataFrame:
    """Add ``range_atr`` = today's bar range divided by ``atr_{period}``.

    A value > 1 means today's bar is wider than the ATR-period average —
    useful for spotting "expansion" days. Computes ATR if not already
    present.
    """
    if df is None or df.is_empty():
        return df if df is not None else pl.DataFrame()
    if not {high_col, low_col}.issubset(df.columns):
        log.debug("add_range_atr: missing %s/%s", high_col, low_col)
        return df
    try:
        out = df if "atr" in df.columns else add_atr(
            df, period=period, group_col=group_col,
            high_col=high_col, low_col=low_col,
        )
        if "atr" not in out.columns:
            return df
        rng = (pl.col(high_col).cast(pl.Float64, strict=False)
               - pl.col(low_col).cast(pl.Float64, strict=False))
        safe_atr = pl.when(pl.col("atr") > 0).then(pl.col("atr")).otherwise(None)
        return out.with_columns((rng / safe_atr).alias("range_atr"))
    except Exception as exc:  # noqa: BLE001
        log.warning("add_range_atr failed: %s", exc)
        return df
