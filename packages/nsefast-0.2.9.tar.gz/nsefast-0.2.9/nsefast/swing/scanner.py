"""High-level swing scanners.

Each scanner consumes one or more collector DataFrames and returns a ranked
Polars DataFrame with the ``score`` column (when applicable). All functions
return an empty DataFrame on failure — never raise.
"""

from __future__ import annotations

import polars as pl

from nsefast.logging_setup import get_logger
from nsefast.swing._common import empty_like, empty_with_schema
from nsefast.swing.filters import (
    exclude_surveillance,
    exclude_symbols,
    liquid_universe,
    price_band,
    series_eq_only,
)
from nsefast.swing.scoring import add_all_scores

log = get_logger(__name__)


def _ranked_empty(extra: list[str] | None = None) -> pl.DataFrame:
    schema: dict[str, pl.DataType] = {
        "symbol":         pl.Utf8,
        "close":          pl.Float64,
        "percent_change": pl.Float64,
        "volume":         pl.Float64,
        "score":          pl.Float64,
    }
    if extra:
        for c in extra:
            schema.setdefault(c, pl.Utf8)
    return empty_with_schema(schema)


def _filter_universe(
    df: pl.DataFrame,
    *,
    min_turnover: float,
    min_price: float,
    max_price: float,
    asm_df: pl.DataFrame | None,
    gsm_df: pl.DataFrame | None,
    fo_ban_df: pl.DataFrame | None,
) -> pl.DataFrame:
    return (df
            .pipe(series_eq_only)
            .pipe(price_band, min_price=min_price, max_price=max_price)
            .pipe(liquid_universe, min_turnover=min_turnover)
            .pipe(exclude_surveillance,
                  asm_df=asm_df, gsm_df=gsm_df, fo_ban_df=fo_ban_df))


def top_upside(
    bhav_df: pl.DataFrame,
    *,
    n: int = 25,
    min_turnover: float = 1e7,
    min_price: float = 20.0,
    max_price: float = 10000.0,
    asm_df: pl.DataFrame | None = None,
    gsm_df: pl.DataFrame | None = None,
    fo_ban_df: pl.DataFrame | None = None,
    weights=None,
) -> pl.DataFrame:
    """Top ``n`` long-side swing candidates ranked by composite score (desc)."""
    if bhav_df.is_empty():
        return _ranked_empty()
    try:
        out = (bhav_df
               .pipe(_filter_universe,
                     min_turnover=min_turnover, min_price=min_price, max_price=max_price,
                     asm_df=asm_df, gsm_df=gsm_df, fo_ban_df=fo_ban_df)
               .pipe(add_all_scores, weights=weights))
        if out.is_empty() or "score" not in out.columns:
            return _ranked_empty()
        return out.sort("score", descending=True, nulls_last=True).head(n)
    except Exception as exc:  # noqa: BLE001
        log.warning("top_upside failed: %s", exc)
        return _ranked_empty()


def top_downside(
    bhav_df: pl.DataFrame,
    *,
    n: int = 25,
    min_turnover: float = 1e7,
    min_price: float = 20.0,
    max_price: float = 10000.0,
    asm_df: pl.DataFrame | None = None,
    gsm_df: pl.DataFrame | None = None,
    fo_ban_df: pl.DataFrame | None = None,
    weights=None,
) -> pl.DataFrame:
    """Top ``n`` short-side / weakest candidates (lowest composite score)."""
    if bhav_df.is_empty():
        return _ranked_empty()
    try:
        out = (bhav_df
               .pipe(_filter_universe,
                     min_turnover=min_turnover, min_price=min_price, max_price=max_price,
                     asm_df=asm_df, gsm_df=gsm_df, fo_ban_df=fo_ban_df)
               .pipe(add_all_scores, weights=weights))
        if out.is_empty() or "score" not in out.columns:
            return _ranked_empty()
        return out.sort("score", descending=False, nulls_last=True).head(n)
    except Exception as exc:  # noqa: BLE001
        log.warning("top_downside failed: %s", exc)
        return _ranked_empty()


def avoid_list(
    bhav_df: pl.DataFrame,
    *,
    asm_df: pl.DataFrame | None = None,
    gsm_df: pl.DataFrame | None = None,
    fo_ban_df: pl.DataFrame | None = None,
    max_volatility_pct: float = 15.0,
    change_col: str = "percent_change",
) -> pl.DataFrame:
    """Symbols to avoid: surveillance lists + extreme single-day moves.

    The result has columns ``symbol, reason``. ``reason`` is one of
    ``asm``, ``gsm``, ``fo_ban``, or ``volatility``.
    """
    cols = ["symbol", "reason"]
    if "symbol" not in bhav_df.columns and not all(
        s is not None and not s.is_empty() for s in (asm_df, gsm_df, fo_ban_df)
        if s is not None
    ):
        return empty_like(cols)

    out: list[pl.DataFrame] = []
    try:
        for label, src in (("asm", asm_df), ("gsm", gsm_df), ("fo_ban", fo_ban_df)):
            if src is None or src.is_empty() or "symbol" not in src.columns:
                continue
            out.append(src.select(
                pl.col("symbol").cast(pl.Utf8),
                pl.lit(label).alias("reason"),
            ))

        if (not bhav_df.is_empty()
                and change_col in bhav_df.columns
                and "symbol" in bhav_df.columns):
            volatile = (bhav_df
                        .filter(
                            pl.col(change_col).cast(pl.Float64, strict=False).abs()
                            >= max_volatility_pct
                        )
                        .select(
                            pl.col("symbol").cast(pl.Utf8),
                            pl.lit("volatility").alias("reason"),
                        ))
            out.append(volatile)

        if not out:
            return empty_like(cols)
        return pl.concat(out, how="vertical_relaxed").unique(subset=["symbol", "reason"])
    except Exception as exc:  # noqa: BLE001
        log.warning("avoid_list failed: %s", exc)
        return empty_like(cols)


def sector_leaders(
    sector_df: pl.DataFrame,
    *,
    n: int = 5,
) -> pl.DataFrame:
    """Top ``n`` sector indices by ``percent_change`` (desc).

    Pass the output of :func:`nsefast.collectors.indices.sector_strength`.
    """
    empty = empty_with_schema({"index_name": pl.Utf8, "percent_change": pl.Float64})
    if sector_df.is_empty():
        return empty
    try:
        keep = [c for c in ("index_name", "percent_change") if c in sector_df.columns]
        if "percent_change" not in keep:
            return empty
        return (sector_df
                .filter(pl.col("percent_change").is_not_null())
                .sort("percent_change", descending=True, nulls_last=True)
                .select(keep)
                .head(n))
    except Exception as exc:  # noqa: BLE001
        log.warning("sector_leaders failed: %s", exc)
        return empty


def delivery_breakout(
    df: pl.DataFrame,
    *,
    n: int = 25,
    min_delivery_pct: float = 70.0,
    deliv_col: str = "delivery_pct",
) -> pl.DataFrame:
    """Symbols with delivery % above ``min_delivery_pct`` (sticky-money signal).

    Expects a DataFrame with ``symbol`` + ``delivery_pct`` (e.g. the output of
    :func:`nsefast.collectors.equity.delivery_data`).
    """
    empty = empty_with_schema({"symbol": pl.Utf8, "delivery_pct": pl.Float64})
    if df.is_empty():
        return empty
    if deliv_col not in df.columns or "symbol" not in df.columns:
        return empty
    try:
        return (df
                .with_columns(pl.col(deliv_col).cast(pl.Float64, strict=False))
                .filter(pl.col(deliv_col) >= min_delivery_pct)
                .sort(deliv_col, descending=True, nulls_last=True)
                .select(["symbol", deliv_col])
                .head(n))
    except Exception as exc:  # noqa: BLE001
        log.warning("delivery_breakout failed: %s", exc)
        return empty


def volume_breakout(
    df: pl.DataFrame,
    *,
    n: int = 25,
    min_ratio: float = 2.0,
    vol_col: str = "volume",
    avg_col: str = "avg_volume_20",
) -> pl.DataFrame:
    """Symbols where ``volume / avg_volume_20 >= min_ratio``.

    Add ``avg_volume_20`` first via
    :func:`nsefast.processing.features.add_volume_breakout`.
    """
    empty = empty_with_schema({
        "symbol": pl.Utf8, "volume": pl.Float64,
        "avg_volume_20": pl.Float64, "vol_ratio": pl.Float64,
    })
    if df.is_empty():
        return empty
    if not {"symbol", vol_col, avg_col}.issubset(df.columns):
        return empty
    try:
        out = df.with_columns(
            (pl.col(vol_col).cast(pl.Float64, strict=False)
             / pl.col(avg_col).cast(pl.Float64, strict=False)).alias("vol_ratio")
        )
        return (out
                .filter(pl.col("vol_ratio") >= min_ratio)
                .sort("vol_ratio", descending=True, nulls_last=True)
                .select(["symbol", vol_col, avg_col, "vol_ratio"])
                .head(n))
    except Exception as exc:  # noqa: BLE001
        log.warning("volume_breakout failed: %s", exc)
        return empty
