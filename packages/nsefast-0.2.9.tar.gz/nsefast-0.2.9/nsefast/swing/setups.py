"""End-to-end canonical swing setups.

Each ``*_setup`` function consumes a long-format OHLCV history panel
(one row per ``(symbol, trade_date)``) and returns a **ready-to-trade
book** — symbols selected, ATR stops attached, position-sized under
single / sector / cluster caps. The output is a single DataFrame you
can hand straight to a broker terminal or a backtester.

These are the four canonical NSE-swing setups bundled with v0.2.8:

- :func:`momentum_breakout_setup` — Donchian-20 breakout filtered by
  positive relative strength vs a benchmark, sized with an ATR stop.
- :func:`relative_strength_leaders_setup` — top RS leaders within
  ``within_pct`` of their 52-week high, vol-targeted.
- :func:`consolidation_breakout_setup` — VCP-style range expansion,
  sized with a chandelier stop.
- :func:`mean_reversion_setup` — RSI-oversold above the 200-SMA, sized
  with an ATR stop. The contrarian counterpart to the trend setups.

Common contract
---------------

All four setups:

- Take ``history`` plus ``capital``. ``benchmark`` is required for the
  RS-based setups.
- Accept ``sector_meta`` (DataFrame with ``symbol`` + ``sector``) for
  sector-cap allocation, and ``cluster_lookback`` to compute correlation
  clusters on the fly.
- Operate on ``as_of`` (default: most recent ``trade_date`` in
  ``history``). Only the snapshot at ``as_of`` is selected; prior bars
  are used purely to compute the rolling signals.
- Return the canonical book schema documented in
  :data:`BOOK_SCHEMA` — every column always present, every error path
  returning the same empty-with-schema frame.
- **Never raise.** Any unexpected error path returns the canonical
  empty book (logged at ``warning``).
"""

from __future__ import annotations

from typing import Mapping

import polars as pl

from nsefast.logging_setup import get_logger
from nsefast.processing.technicals import add_rsi, add_sma
from nsefast.swing._common import empty_with_schema
from nsefast.swing.breakouts import (
    consolidation_breakout,
    donchian_breakout,
    near_52w_high,
)
from nsefast.swing.portfolio import correlation_clusters, portfolio_size
from nsefast.swing.relative_strength import add_relative_strength, add_rs_score
from nsefast.swing.risk import (
    add_atr,
    add_atr_stop,
    add_chandelier_stop,
)

log = get_logger(__name__)


BOOK_SCHEMA: Mapping[str, pl.DataType] = {
    "setup":          pl.Utf8,
    "as_of":          pl.Date,
    "symbol":         pl.Utf8,
    "entry_price":    pl.Float64,
    "atr":            pl.Float64,
    "stop_loss":      pl.Float64,
    "signal_score":   pl.Float64,
    "weight":         pl.Float64,
    "allocated_pct":  pl.Float64,
    "allocated_rs":   pl.Float64,
    "risk_rs":        pl.Float64,
    "qty":            pl.Int64,
    "notional_rs":    pl.Float64,
    "capped_by":      pl.Utf8,
    "sector":         pl.Utf8,
    "cluster_id":     pl.Int64,
}


def _empty_book() -> pl.DataFrame:
    return empty_with_schema(BOOK_SCHEMA)


# ---------- internals --------------------------------------------------------


def _resolve_as_of(history: pl.DataFrame, as_of, date_col: str):
    if as_of is not None:
        return as_of
    try:
        return history[date_col].max()
    except Exception:  # noqa: BLE001
        return None


def _attach_clusters(
    candidates: pl.DataFrame,
    history: pl.DataFrame,
    *,
    lookback: int,
    threshold: float,
    symbol_col: str,
    date_col: str,
    price_col: str,
) -> pl.DataFrame:
    """Compute correlation clusters for the candidate symbols and join them on."""
    if candidates.is_empty() or lookback <= 0:
        return candidates.with_columns(
            pl.lit(None, dtype=pl.Int64).alias("cluster_id")
        )
    try:
        cl = correlation_clusters(
            history,
            symbols=candidates[symbol_col].unique().to_list(),
            lookback=lookback, threshold=threshold,
            symbol_col=symbol_col, date_col=date_col, price_col=price_col,
        )
        if cl.is_empty():
            return candidates.with_columns(
                pl.lit(None, dtype=pl.Int64).alias("cluster_id")
            )
        return candidates.join(cl, on=symbol_col, how="left")
    except Exception as exc:  # noqa: BLE001
        log.warning("_attach_clusters failed: %s", exc)
        return candidates.with_columns(
            pl.lit(None, dtype=pl.Int64).alias("cluster_id")
        )


def _finalize_book(
    snap: pl.DataFrame,
    *,
    setup_name: str,
    as_of,
    capital: float,
    risk_pct: float,
    score_col: str,
    sector_meta: pl.DataFrame | None,
    cluster_lookback: int,
    cluster_threshold: float,
    history: pl.DataFrame,
    max_positions: int,
    max_single_pct: float,
    max_sector_pct: float,
    max_cluster_pct: float | None,
    symbol_col: str,
    date_col: str,
    price_col: str,
) -> pl.DataFrame:
    """Common tail: attach sector + cluster, allocate, return canonical book."""
    if snap.is_empty():
        return _empty_book()

    needed = {symbol_col, "entry_price", "atr", "stop_loss", score_col}
    if not needed.issubset(snap.columns):
        log.warning("_finalize_book: missing %s", needed - set(snap.columns))
        return _empty_book()

    try:
        # Drop rows with non-positive (entry - stop) — sizing would be NaN/0
        snap = snap.filter(
            pl.col("entry_price").is_not_null()
            & pl.col("stop_loss").is_not_null()
            & (pl.col("entry_price") > pl.col("stop_loss"))
            & pl.col(score_col).is_not_null()
        )
        if snap.is_empty():
            return _empty_book()

        # Rank by score, take top max_positions
        snap = (snap
                .sort(score_col, descending=True, nulls_last=True)
                .head(max(max_positions, 1)))

        # Attach sector
        if sector_meta is not None and not sector_meta.is_empty() \
                and {symbol_col, "sector"}.issubset(sector_meta.columns):
            snap = snap.join(
                sector_meta.select([symbol_col, "sector"]).unique(subset=[symbol_col]),
                on=symbol_col, how="left",
            )
        else:
            snap = snap.with_columns(pl.lit(None, dtype=pl.Utf8).alias("sector"))

        # Attach cluster_id
        snap = _attach_clusters(
            snap, history,
            lookback=cluster_lookback, threshold=cluster_threshold,
            symbol_col=symbol_col, date_col=date_col, price_col=price_col,
        )

        # Allocate
        alloc = portfolio_size(
            snap, capital=capital,
            max_positions=max_positions,
            max_single_pct=max_single_pct,
            max_sector_pct=max_sector_pct,
            max_cluster_pct=max_cluster_pct,
            weight_col=score_col,
            symbol_col=symbol_col, sector_col="sector", cluster_col="cluster_id",
        )
        if alloc.is_empty():
            return _empty_book()

        # ---- Risk-per-trade sizing -------------------------------------
        # `allocated_rs` from portfolio_size is the *capital allocation*
        # (weight × capital). `risk_rs` is the *rupee risk budget* per
        # name = allocated_rs × risk_pct/100 (so a 10% allocation at
        # 1% risk-pct ⇒ 0.1% of total capital risked on this trade).
        # qty is then sized so that a stop-out costs exactly risk_rs:
        #
        #     qty = floor(risk_rs / (entry - stop))
        #
        # `notional_rs` = qty × entry_price is the *actual* rupee
        # exposure once shares are integer-rounded — usually larger
        # than allocated_rs (the stop is much closer than the entry).
        # That's by design: capped via single-name leverage by
        # `max_single_pct`, not via notional.
        risk_pct_safe = max(float(risk_pct), 0.0) / 100.0
        joined = (alloc
                  .join(snap.select([
                      symbol_col, "entry_price", "atr", "stop_loss",
                      score_col, "sector", "cluster_id",
                  ]), on=symbol_col, how="left")
                  .with_columns(
                      (pl.col("allocated_rs") * risk_pct_safe).alias("risk_rs"),
                  )
                  .with_columns(
                      pl.when((pl.col("entry_price") - pl.col("stop_loss")) > 0)
                        .then((pl.col("risk_rs")
                               / (pl.col("entry_price") - pl.col("stop_loss")))
                              .cast(pl.Int64, strict=False))
                        .otherwise(pl.lit(0, dtype=pl.Int64))
                        .alias("qty"),
                      pl.lit(setup_name, dtype=pl.Utf8).alias("setup"),
                      pl.lit(as_of, dtype=pl.Date).alias("as_of"),
                      pl.col(score_col).alias("signal_score"),
                  )
                  .with_columns(
                      (pl.col("qty").cast(pl.Float64) * pl.col("entry_price"))
                      .alias("notional_rs")
                  ))

        return joined.select(list(BOOK_SCHEMA.keys()))
    except Exception as exc:  # noqa: BLE001
        log.warning("_finalize_book(%s) failed: %s", setup_name, exc)
        return _empty_book()


def _common_history_guard(
    history: pl.DataFrame, *, symbol_col: str, date_col: str, price_col: str,
) -> pl.DataFrame | None:
    """Return a sorted copy of ``history`` if it has the minimum columns."""
    needed = {symbol_col, date_col, price_col, "high", "low", "open"}
    if history is None or history.is_empty():
        return None
    if not needed.issubset(history.columns):
        log.warning("history missing %s", needed - set(history.columns))
        return None
    return history.sort([symbol_col, date_col])


# ---------- setups -----------------------------------------------------------


def momentum_breakout_setup(
    history: pl.DataFrame,
    *,
    capital: float,
    benchmark: pl.DataFrame | None = None,
    sector_meta: pl.DataFrame | None = None,
    as_of=None,
    n_donchian: int = 20,
    rs_lookback: int = 20,
    min_rs_score: float = 60.0,
    atr_period: int = 14,
    atr_mult: float = 2.0,
    risk_pct: float = 1.0,
    max_positions: int = 10,
    max_single_pct: float = 10.0,
    max_sector_pct: float = 30.0,
    max_cluster_pct: float | None = 20.0,
    cluster_lookback: int = 60,
    cluster_threshold: float = 0.7,
    symbol_col: str = "symbol",
    date_col: str = "trade_date",
    price_col: str = "close",
) -> pl.DataFrame:
    """Donchian-``n_donchian`` breakout filtered by relative-strength rank.

    A symbol qualifies on ``as_of`` when:

    - Today's close exceeds the prior ``n_donchian``-bar high (Turtle entry).
    - Its cross-sectional RS-rank vs the benchmark over ``rs_lookback`` bars
      is above ``min_rs_score`` (default top 40 %). If no benchmark is
      supplied, this filter is skipped.

    Stop = ``close - atr_mult * ATR``. Score = the RS percentile rank
    (so the strongest leader gets the largest weight after caps).
    """
    h = _common_history_guard(history, symbol_col=symbol_col,
                              date_col=date_col, price_col=price_col)
    if h is None:
        return _empty_book()

    as_of = _resolve_as_of(h, as_of, date_col)
    if as_of is None:
        return _empty_book()

    try:
        # 1. Augment the panel with ATR + (optional) RS score
        panel = add_atr(h, period=atr_period,
                        group_col=symbol_col, close_col=price_col)
        if benchmark is not None and not benchmark.is_empty():
            panel = add_relative_strength(
                panel, benchmark, lookback=rs_lookback,
                on=price_col, date_col=date_col, group_col=symbol_col,
            )
            rs_col = f"rs_{rs_lookback}"
            panel = add_rs_score(panel, rs_col=rs_col, date_col=date_col)
            score_col = f"{rs_col}_score"
        else:
            # No benchmark → score by raw rolling-N return rank.
            panel = panel.with_columns(
                ((pl.col(price_col) / pl.col(price_col).shift(rs_lookback)
                  .over(symbol_col) - 1.0) * 100.0).alias("_ret_n")
            )
            panel = panel.with_columns(
                (pl.col("_ret_n").rank("average").over(date_col) /
                 pl.col("_ret_n").count().over(date_col) * 100.0)
                .alias("_score")
            )
            score_col = "_score"

        # 2. Apply Donchian breakout filter (over the full panel)
        breakouts = donchian_breakout(panel, n=n_donchian,
                                      close_col=price_col,
                                      group_col=symbol_col)

        # 3. Restrict to as_of snapshot, apply RS-score cut, attach stop
        snap = (breakouts
                .filter(pl.col(date_col) == as_of)
                .filter(pl.col(score_col) >= min_rs_score)
                .with_columns(pl.col(price_col).alias("entry_price"))
                .pipe(add_atr_stop, mult=atr_mult,
                      atr_col="atr", price_col="entry_price"))

        return _finalize_book(
            snap, setup_name="momentum_breakout", as_of=as_of, capital=capital,
            risk_pct=risk_pct,
            score_col=score_col, sector_meta=sector_meta,
            cluster_lookback=cluster_lookback,
            cluster_threshold=cluster_threshold,
            history=h, max_positions=max_positions,
            max_single_pct=max_single_pct, max_sector_pct=max_sector_pct,
            max_cluster_pct=max_cluster_pct,
            symbol_col=symbol_col, date_col=date_col, price_col=price_col,
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("momentum_breakout_setup failed: %s", exc)
        return _empty_book()


def relative_strength_leaders_setup(
    history: pl.DataFrame,
    benchmark: pl.DataFrame,
    *,
    capital: float,
    sector_meta: pl.DataFrame | None = None,
    as_of=None,
    rs_lookback: int = 60,
    min_rs_score: float = 80.0,
    within_pct_of_high: float = 5.0,
    high_window: int = 252,
    atr_period: int = 14,
    atr_mult: float = 2.5,
    risk_pct: float = 1.0,
    max_positions: int = 10,
    max_single_pct: float = 10.0,
    max_sector_pct: float = 30.0,
    max_cluster_pct: float | None = 20.0,
    cluster_lookback: int = 60,
    cluster_threshold: float = 0.7,
    symbol_col: str = "symbol",
    date_col: str = "trade_date",
    price_col: str = "close",
) -> pl.DataFrame:
    """Top RS leaders within ``within_pct_of_high`` of their 52-week high.

    The classic Minervini / IBD setup: only buy the strongest names that
    are also showing they can hold near new highs (no broken leaders).

    Defaults: 60-bar RS, top 20% (RS score ≥ 80), within 5% of the
    rolling 252-bar high, 2.5×ATR stop, 10 positions max with 30%
    sector cap.
    """
    h = _common_history_guard(history, symbol_col=symbol_col,
                              date_col=date_col, price_col=price_col)
    if h is None or benchmark is None or benchmark.is_empty():
        return _empty_book()

    as_of = _resolve_as_of(h, as_of, date_col)
    if as_of is None:
        return _empty_book()

    try:
        panel = add_atr(h, period=atr_period,
                        group_col=symbol_col, close_col=price_col)
        panel = add_relative_strength(
            panel, benchmark, lookback=rs_lookback,
            on=price_col, date_col=date_col, group_col=symbol_col,
        )
        rs_col = f"rs_{rs_lookback}"
        panel = add_rs_score(panel, rs_col=rs_col, date_col=date_col)
        score_col = f"{rs_col}_score"

        # near_52w_high adds a high_52w col and filters
        leaders = near_52w_high(
            panel, within_pct=within_pct_of_high, window=high_window,
            close_col=price_col, group_col=symbol_col,
        )

        snap = (leaders
                .filter(pl.col(date_col) == as_of)
                .filter(pl.col(score_col) >= min_rs_score)
                .with_columns(pl.col(price_col).alias("entry_price"))
                .pipe(add_atr_stop, mult=atr_mult,
                      atr_col="atr", price_col="entry_price"))

        return _finalize_book(
            snap, setup_name="rs_leaders", as_of=as_of, capital=capital,
            risk_pct=risk_pct,
            score_col=score_col, sector_meta=sector_meta,
            cluster_lookback=cluster_lookback,
            cluster_threshold=cluster_threshold,
            history=h, max_positions=max_positions,
            max_single_pct=max_single_pct, max_sector_pct=max_sector_pct,
            max_cluster_pct=max_cluster_pct,
            symbol_col=symbol_col, date_col=date_col, price_col=price_col,
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("relative_strength_leaders_setup failed: %s", exc)
        return _empty_book()


def consolidation_breakout_setup(
    history: pl.DataFrame,
    *,
    capital: float,
    benchmark: pl.DataFrame | None = None,
    sector_meta: pl.DataFrame | None = None,
    as_of=None,
    atr_period: int = 14,
    contraction_lookback: int = 20,
    expansion_mult: float = 1.5,
    chandelier_period: int = 22,
    chandelier_mult: float = 3.0,
    risk_pct: float = 1.0,
    max_positions: int = 10,
    max_single_pct: float = 10.0,
    max_sector_pct: float = 30.0,
    max_cluster_pct: float | None = 20.0,
    cluster_lookback: int = 60,
    cluster_threshold: float = 0.7,
    symbol_col: str = "symbol",
    date_col: str = "trade_date",
    price_col: str = "close",
) -> pl.DataFrame:
    """VCP-style range-expansion breakout, sized with a chandelier stop.

    A symbol qualifies on ``as_of`` when ATR has expanded sharply
    (today's ATR > ``expansion_mult`` × min ATR over the last
    ``contraction_lookback`` bars) *and* the close prints a new
    20-bar high (the standard VCP breakout trigger).

    Score = the ATR-expansion ratio (today's ATR / prior min ATR) —
    sharper expansions get larger weights. Stop = chandelier (rolling
    high − ``chandelier_mult`` × ATR), which lets winners breathe.
    """
    h = _common_history_guard(history, symbol_col=symbol_col,
                              date_col=date_col, price_col=price_col)
    if h is None:
        return _empty_book()

    as_of = _resolve_as_of(h, as_of, date_col)
    if as_of is None:
        return _empty_book()

    try:
        panel = add_atr(h, period=atr_period,
                        group_col=symbol_col, close_col=price_col)
        panel = add_chandelier_stop(
            panel, period=chandelier_period, mult=chandelier_mult,
            close_col=price_col, group_col=symbol_col,
        )

        breakouts = consolidation_breakout(
            panel, atr_period=atr_period,
            contraction_lookback=contraction_lookback,
            expansion_mult=expansion_mult,
            close_col=price_col, group_col=symbol_col,
        )

        # Score: today's ATR / prior min ATR (expansion ratio); fall back
        # to ATR if the panel doesn't carry the rolling min.
        snap = (breakouts
                .filter(pl.col(date_col) == as_of)
                .with_columns([
                    pl.col(price_col).alias("entry_price"),
                    pl.col("chandelier_stop").alias("stop_loss"),
                ]))
        if snap.is_empty():
            return _empty_book()

        # Recompute the expansion ratio for scoring (consolidation_breakout
        # doesn't keep it as a column, by design).
        prior_min_atr = (
            pl.col("atr").shift(1)
              .rolling_min(contraction_lookback).over(symbol_col)
        )
        scored = (panel
                  .with_columns(prior_min_atr.alias("_prior_min_atr"))
                  .filter(pl.col(date_col) == as_of)
                  .with_columns(
                      pl.when(pl.col("_prior_min_atr") > 0)
                        .then(pl.col("atr") / pl.col("_prior_min_atr"))
                        .otherwise(pl.lit(None, dtype=pl.Float64))
                        .alias("expansion_ratio")
                  )
                  .select([symbol_col, "expansion_ratio"]))
        snap = snap.join(scored, on=symbol_col, how="left")

        return _finalize_book(
            snap, setup_name="consolidation_breakout", as_of=as_of,
            capital=capital, risk_pct=risk_pct,
            score_col="expansion_ratio",
            sector_meta=sector_meta,
            cluster_lookback=cluster_lookback,
            cluster_threshold=cluster_threshold,
            history=h, max_positions=max_positions,
            max_single_pct=max_single_pct, max_sector_pct=max_sector_pct,
            max_cluster_pct=max_cluster_pct,
            symbol_col=symbol_col, date_col=date_col, price_col=price_col,
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("consolidation_breakout_setup failed: %s", exc)
        return _empty_book()


def mean_reversion_setup(
    history: pl.DataFrame,
    *,
    capital: float,
    sector_meta: pl.DataFrame | None = None,
    as_of=None,
    rsi_period: int = 14,
    rsi_max: float = 30.0,
    sma_filter: int = 200,
    atr_period: int = 14,
    atr_mult: float = 1.5,
    risk_pct: float = 1.0,
    max_positions: int = 10,
    max_single_pct: float = 10.0,
    max_sector_pct: float = 30.0,
    max_cluster_pct: float | None = 20.0,
    cluster_lookback: int = 60,
    cluster_threshold: float = 0.7,
    symbol_col: str = "symbol",
    date_col: str = "trade_date",
    price_col: str = "close",
) -> pl.DataFrame:
    """RSI-oversold bounce above the long-term trend.

    A symbol qualifies on ``as_of`` when:

    - ``rsi_{rsi_period} <= rsi_max`` (default 30, oversold).
    - ``close >= sma_{sma_filter}`` (default 200, long-term uptrend
      intact — no falling-knife mean reversion).

    Stop = ``close - atr_mult * ATR`` (default tight 1.5×, since
    mean-reversion has a small expected MFE). Score = ``rsi_max - rsi``
    so the most oversold qualifying name gets the largest weight.
    """
    h = _common_history_guard(history, symbol_col=symbol_col,
                              date_col=date_col, price_col=price_col)
    if h is None:
        return _empty_book()

    as_of = _resolve_as_of(h, as_of, date_col)
    if as_of is None:
        return _empty_book()

    try:
        panel = add_atr(h, period=atr_period,
                        group_col=symbol_col, close_col=price_col)
        panel = add_rsi(panel, n=rsi_period, col=price_col,
                        group_col=symbol_col)
        panel = add_sma(panel, n=sma_filter, col=price_col,
                        group_col=symbol_col)

        rsi_col = f"rsi_{rsi_period}"
        sma_col = f"sma_{sma_filter}"
        if rsi_col not in panel.columns or sma_col not in panel.columns:
            log.warning("mean_reversion_setup: technicals missing %s/%s",
                        rsi_col, sma_col)
            return _empty_book()

        snap = (panel
                .filter(pl.col(date_col) == as_of)
                .filter(pl.col(rsi_col).is_not_null()
                        & pl.col(sma_col).is_not_null()
                        & (pl.col(rsi_col) <= rsi_max)
                        & (pl.col(price_col) >= pl.col(sma_col)))
                .with_columns([
                    pl.col(price_col).alias("entry_price"),
                    (rsi_max - pl.col(rsi_col)).alias("oversold_score"),
                ])
                .pipe(add_atr_stop, mult=atr_mult,
                      atr_col="atr", price_col="entry_price"))

        return _finalize_book(
            snap, setup_name="mean_reversion", as_of=as_of, capital=capital,
            risk_pct=risk_pct,
            score_col="oversold_score", sector_meta=sector_meta,
            cluster_lookback=cluster_lookback,
            cluster_threshold=cluster_threshold,
            history=h, max_positions=max_positions,
            max_single_pct=max_single_pct, max_sector_pct=max_sector_pct,
            max_cluster_pct=max_cluster_pct,
            symbol_col=symbol_col, date_col=date_col, price_col=price_col,
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("mean_reversion_setup failed: %s", exc)
        return _empty_book()


def all_setups(
    history: pl.DataFrame,
    *,
    capital: float,
    benchmark: pl.DataFrame | None = None,
    sector_meta: pl.DataFrame | None = None,
    as_of=None,
    per_setup_capital: float | None = None,
) -> pl.DataFrame:
    """Run all four setups with library defaults and concatenate the books.

    By default each setup gets ``capital / 4``; pass ``per_setup_capital``
    to override (e.g. allocate more to trend-following than mean-reversion).
    """
    each = per_setup_capital if per_setup_capital is not None else capital / 4.0
    parts = [
        momentum_breakout_setup(history, capital=each, benchmark=benchmark,
                                sector_meta=sector_meta, as_of=as_of),
    ]
    if benchmark is not None and not benchmark.is_empty():
        parts.append(relative_strength_leaders_setup(
            history, benchmark, capital=each,
            sector_meta=sector_meta, as_of=as_of))
    parts.append(consolidation_breakout_setup(
        history, capital=each, benchmark=benchmark,
        sector_meta=sector_meta, as_of=as_of))
    parts.append(mean_reversion_setup(
        history, capital=each, sector_meta=sector_meta, as_of=as_of))

    non_empty = [p for p in parts if not p.is_empty()]
    if not non_empty:
        return _empty_book()
    try:
        return pl.concat(non_empty, how="vertical_relaxed")
    except Exception as exc:  # noqa: BLE001
        log.warning("all_setups concat failed: %s", exc)
        return _empty_book()
