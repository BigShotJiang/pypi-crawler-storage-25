"""Polite HTTP session with retries and warm-up."""

from __future__ import annotations

import logging
import time
from pathlib import Path

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from nsefast.config import (
    BASE_URL,
    HEADERS,
    RAW_DIR,
    REQUEST_DELAY_SECONDS,
    REQUEST_TIMEOUT_SECONDS,
)

log = logging.getLogger(__name__)


def create_session() -> requests.Session:
    """Return a configured `requests.Session` warmed up against NSE."""
    session = requests.Session()

    retry = Retry(
        total=3,
        backoff_factor=1.5,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET"],
    )

    adapter = HTTPAdapter(max_retries=retry, pool_connections=20, pool_maxsize=20)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    session.headers.update(HEADERS)

    # Warm-up: NSE sets cookies on the homepage that subsequent endpoints expect.
    try:
        session.get(BASE_URL, timeout=REQUEST_TIMEOUT_SECONDS)
        time.sleep(REQUEST_DELAY_SECONDS)
    except Exception as exc:  # noqa: BLE001 — best-effort warm-up
        log.warning("NSE warm-up failed: %s", exc)

    return session


def download_file(session: requests.Session, url: str, dest_dir: str = RAW_DIR) -> str | None:
    """Download `url` to `dest_dir`. Returns the local path or None on failure."""
    try:
        resp = session.get(url, timeout=REQUEST_TIMEOUT_SECONDS, stream=True)
        if resp.status_code != 200:
            log.warning("download %s -> HTTP %s", url, resp.status_code)
            return None

        Path(dest_dir).mkdir(parents=True, exist_ok=True)
        filename = url.split("/")[-1].split("?")[0] or "download.bin"
        path = Path(dest_dir) / filename

        with open(path, "wb") as fh:
            for chunk in resp.iter_content(chunk_size=64 * 1024):
                if chunk:
                    fh.write(chunk)

        time.sleep(REQUEST_DELAY_SECONDS)
        return str(path)
    except Exception as exc:  # noqa: BLE001
        log.error("download %s failed: %s", url, exc)
        return None
