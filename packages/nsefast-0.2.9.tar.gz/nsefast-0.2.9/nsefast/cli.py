"""Typer CLI entry point: ``nsefast ...``"""

from __future__ import annotations

import os
import sys
import tempfile
from datetime import date, datetime
from pathlib import Path

import polars as pl
import typer
from rich import print

from nsefast import __version__
from nsefast.cache import cache_stats, clear_cache
from nsefast.collectors import (
    calendar as cal,
    corporate,
    deals,
    derivatives,
    equity,
    indices,
    market_breadth,
    master,
    surveillance,
)
from nsefast.collectors.report_links import collect_report_links
from nsefast.logging_setup import get_logger, setup_logging
from nsefast.processing.features import swing_features
from nsefast.processing.normalize import normalize_columns
from nsefast.storage.parquet_store import read_parquet, save_parquet

# NSE bhavcopy columns -> canonical names used by feature helpers.
_BHAV_RENAMES = {
    "tottrdqty": "total_traded_qty",
    "tottrdval": "total_traded_value",
    "open": "open",
    "high": "high",
    "low": "low",
    "close": "close",
}

setup_logging(level="INFO", fmt=os.environ.get("NSEFAST_LOG_FORMAT", "rich"))
log = get_logger(__name__)

app = typer.Typer(help="Fast NSE India data collector.")
collect_app = typer.Typer(help="Run a single collector.")
features_app = typer.Typer(help="Build feature sets.")
export_app = typer.Typer(help="Export data to other formats.")
app.add_typer(collect_app, name="collect")
app.add_typer(features_app, name="features")
app.add_typer(export_app, name="export")


def _parse_date(s: str) -> date:
    return datetime.strptime(s, "%Y-%m-%d").date()


# ---- top-level shortcuts -------------------------------------------------

@app.command("collect-reports")
def cmd_collect_reports() -> None:
    """Discover all downloadable report links from NSE public pages."""
    df = collect_report_links()
    if df.is_empty():
        print("[red]No report links found[/red]")
        return
    path = save_parquet(df, dataset="report_links")
    print(f"[green]Saved report links:[/green] {path}")
    print(df.head(10))


@app.command("collect-all")
def cmd_collect_all(
    date_str: str = typer.Option(None, "--date", help="Trade date YYYY-MM-DD"),
) -> None:
    """Run the full scaffold."""
    print("[yellow]Starting NSE full collection scaffold...[/yellow]")
    cmd_collect_reports()
    if date_str:
        cmd_equity_bhavcopy(date_str)
        cmd_fo_bhavcopy(date_str)
    print("[green]Done[/green]")


# ---- collect.<dataset> ---------------------------------------------------

@collect_app.command("equity-bhavcopy")
def cmd_equity_bhavcopy(date_str: str = typer.Option(..., "--date")) -> None:
    df = equity.daily_bhavcopy(_parse_date(date_str))
    if df.is_empty():
        print("[red]No bhavcopy data[/red]")
        return
    path = save_parquet(df, dataset="daily_bhavcopy", partition=date_str)
    print(f"[green]Saved[/green] {path}  rows={df.height}")


@collect_app.command("fo-bhavcopy")
def cmd_fo_bhavcopy(date_str: str = typer.Option(..., "--date")) -> None:
    df = derivatives.fo_bhavcopy(_parse_date(date_str))
    if df.is_empty():
        print("[red]No F&O bhavcopy data[/red]")
        return
    path = save_parquet(df, dataset="fo_bhavcopy", partition=date_str)
    print(f"[green]Saved[/green] {path}  rows={df.height}")


@collect_app.command("delivery")
def cmd_delivery(date_str: str = typer.Option(..., "--date")) -> None:
    df = equity.delivery_data(_parse_date(date_str))
    if df.is_empty():
        print("[red]No delivery data[/red]")
        return
    path = save_parquet(df, dataset="delivery", partition=date_str)
    print(f"[green]Saved[/green] {path}  rows={df.height}")


@collect_app.command("symbol-master")
def cmd_symbol_master() -> None:
    df = master.symbol_master()
    if df.is_empty():
        print("[red]No symbol master data[/red]")
        return
    path = save_parquet(df, dataset="symbol_master")
    print(f"[green]Saved[/green] {path}  rows={df.height}")


@collect_app.command("corporate-announcements")
def cmd_corp_ann(
    start: str = typer.Option(..., "--start"),
    end: str = typer.Option(..., "--end"),
) -> None:
    df = corporate.corporate_announcements(_parse_date(start), _parse_date(end))
    if df.is_empty():
        print("[yellow]No corporate announcements returned for that range[/yellow]")
        return
    path = save_parquet(df, dataset="corporate_announcements", partition=f"{start}_{end}")
    print(f"[green]Saved[/green] {path}  rows={df.height}")


@collect_app.command("bulk-deals")
def cmd_bulk_deals(
    start: str = typer.Option(..., "--start"),
    end: str = typer.Option(..., "--end"),
) -> None:
    df = deals.bulk_deals(_parse_date(start), _parse_date(end))
    if df.is_empty():
        print("[yellow]No bulk deals returned for that range[/yellow]")
        return
    path = save_parquet(df, dataset="bulk_deals", partition=f"{start}_{end}")
    print(f"[green]Saved[/green] {path}  rows={df.height}")


@collect_app.command("block-deals")
def cmd_block_deals(
    start: str = typer.Option(..., "--start"),
    end: str = typer.Option(..., "--end"),
) -> None:
    df = deals.block_deals(_parse_date(start), _parse_date(end))
    if df.is_empty():
        print("[yellow]No block deals returned for that range[/yellow]")
        return
    path = save_parquet(df, dataset="block_deals", partition=f"{start}_{end}")
    print(f"[green]Saved[/green] {path}  rows={df.height}")


@collect_app.command("indices")
def cmd_indices() -> None:
    df = indices.nifty_50()
    if df.is_empty():
        print("[yellow]No data (collector is a scaffold)[/yellow]")
        return
    save_parquet(df, dataset="indices")


@collect_app.command("asm")
def cmd_asm() -> None:
    df = surveillance.asm_list()
    if df.is_empty():
        print("[yellow]No data (collector is a scaffold)[/yellow]")
        return
    save_parquet(df, dataset="asm_list")


@collect_app.command("gsm")
def cmd_gsm() -> None:
    df = surveillance.gsm_list()
    if df.is_empty():
        print("[yellow]No data (collector is a scaffold)[/yellow]")
        return
    save_parquet(df, dataset="gsm_list")


@collect_app.command("fo-ban")
def cmd_fo_ban() -> None:
    df = surveillance.fo_ban()
    if df.is_empty():
        print("[yellow]No data (collector is a scaffold)[/yellow]")
        return
    save_parquet(df, dataset="fo_ban")


@collect_app.command("market-breadth")
def cmd_market_breadth() -> None:
    """Advances/declines, 52w H/L, circuits, gainers, losers, most active."""
    snap = market_breadth.market_snapshot()
    if snap.is_empty():
        print("[yellow]No data (market-breadth collectors are scaffolds)[/yellow]")
        return
    save_parquet(snap, dataset="market_breadth")


@collect_app.command("currency-bhavcopy")
def cmd_currency_bhavcopy(date_str: str = typer.Option(..., "--date")) -> None:
    df = derivatives.currency_derivatives_bhavcopy(_parse_date(date_str))
    if df.is_empty():
        print("[yellow]No data (collector is a scaffold)[/yellow]")
        return
    save_parquet(df, dataset="currency_bhavcopy", partition=date_str)


@collect_app.command("commodity-bhavcopy")
def cmd_commodity_bhavcopy(date_str: str = typer.Option(..., "--date")) -> None:
    df = derivatives.commodity_derivatives_bhavcopy(_parse_date(date_str))
    if df.is_empty():
        print("[yellow]No data (collector is a scaffold)[/yellow]")
        return
    save_parquet(df, dataset="commodity_bhavcopy", partition=date_str)


@collect_app.command("ird-bhavcopy")
def cmd_ird_bhavcopy(date_str: str = typer.Option(..., "--date")) -> None:
    df = derivatives.interest_rate_derivatives_bhavcopy(_parse_date(date_str))
    if df.is_empty():
        print("[yellow]No data (collector is a scaffold)[/yellow]")
        return
    save_parquet(df, dataset="ird_bhavcopy", partition=date_str)


@collect_app.command("corporate-actions")
def cmd_corp_actions(
    start: str = typer.Option(..., "--start"),
    end: str = typer.Option(..., "--end"),
) -> None:
    df = corporate.corporate_actions(_parse_date(start), _parse_date(end))
    if df.is_empty():
        print("[yellow]No corporate actions returned for that range[/yellow]")
        return
    path = save_parquet(df, dataset="corporate_actions", partition=f"{start}_{end}")
    print(f"[green]Saved[/green] {path}  rows={df.height}")


@collect_app.command("sector-strength")
def cmd_sector_strength() -> None:
    df = indices.sector_strength()
    if df.is_empty():
        print("[yellow]No sector strength data returned[/yellow]")
        return
    path = save_parquet(df, dataset="sector_strength")
    print(f"[green]Saved[/green] {path}  rows={df.height}")


@collect_app.command("all-indices")
def cmd_all_indices() -> None:
    df = indices.all_indices()
    if df.is_empty():
        print("[yellow]No indices data returned[/yellow]")
        return
    path = save_parquet(df, dataset="all_indices")
    print(f"[green]Saved[/green] {path}  rows={df.height}")


@collect_app.command("52w")
def cmd_52w() -> None:
    df = equity.fifty_two_week_high_low()
    if df.is_empty():
        print("[yellow]No 52-week high/low data returned[/yellow]")
        return
    path = save_parquet(df, dataset="fifty_two_week")
    print(f"[green]Saved[/green] {path}  rows={df.height}")


@collect_app.command("option-chain")
def cmd_option_chain(
    symbol: str = typer.Option(..., "--symbol", help="Equity ticker or NIFTY/BANKNIFTY/FINNIFTY"),
) -> None:
    df = derivatives.option_chain(symbol)
    if df.is_empty():
        print(f"[yellow]No option chain returned for {symbol!r}[/yellow]")
        return
    path = save_parquet(df, dataset="option_chain", partition=symbol.upper())
    print(f"[green]Saved[/green] {path}  rows={df.height}")


@collect_app.command("holidays")
def cmd_holidays() -> None:
    df = cal.trading_holidays()
    if df.is_empty():
        print("[yellow]No data (collector is a scaffold)[/yellow]")
        return
    save_parquet(df, dataset="trading_holidays")


# ---- features ------------------------------------------------------------

@features_app.command("swing")
def cmd_features_swing(date_str: str = typer.Option(..., "--date")) -> None:
    df = read_parquet(f"daily_bhavcopy/{date_str}")
    if df.is_empty():
        df = read_parquet("daily_bhavcopy")
    if df.is_empty():
        print("[red]No source data — run `collect equity-bhavcopy` first[/red]")
        return

    # Normalize column names, then map NSE bhavcopy fields to canonical names
    # so feature helpers (volume/breakout/delivery) work without manual prep.
    df = normalize_columns(df)
    rename_map = {src: dst for src, dst in _BHAV_RENAMES.items() if src in df.columns}
    if rename_map:
        df = df.rename(rename_map)
    if "total_traded_qty" in df.columns and "volume" not in df.columns:
        df = df.with_columns(pl.col("total_traded_qty").alias("volume"))

    out = swing_features(df)
    path = save_parquet(out, dataset="features_swing", partition=date_str)
    print(f"[green]Saved[/green] {path}  rows={out.height}")


# ---- export --------------------------------------------------------------

@export_app.command("parquet")
def cmd_export_parquet(dataset: str = typer.Option(..., "--dataset")) -> None:
    df = read_parquet(dataset)
    if df.is_empty():
        print(f"[red]Dataset {dataset!r} not found[/red]")
        return
    print(df.head(20))
    print(f"[green]rows[/green] = {df.height}")


# ---- verify --------------------------------------------------------------

@app.command("version")
def cmd_version() -> None:
    """Print the installed nsefast version."""
    print(f"nsefast {__version__}")


@app.command("verify")
def cmd_verify(
    network: bool = typer.Option(
        False, "--network", help="Also test a live NSE warm-up + robots.txt fetch"
    ),
) -> None:
    """Smoke-test the install: imports, parquet roundtrip, duckdb, optional network.

    Exits non-zero if any check fails. Run after ``pip install nsefast``.
    """
    failures: list[str] = []

    print(f"[bold]nsefast {__version__}[/bold] — install verification\n")

    # 1. core imports
    try:
        import duckdb, polars, pyarrow, requests, typer  # noqa: F401
        print("[green]✓[/green] core deps importable "
              f"(polars {polars.__version__}, duckdb {duckdb.__version__})")
    except Exception as exc:  # noqa: BLE001
        failures.append(f"imports: {exc}")
        print(f"[red]✗[/red] core import failed: {exc}")

    # 2. parquet roundtrip
    try:
        with tempfile.TemporaryDirectory() as tmp:
            df = pl.DataFrame({"a": [1, 2, 3], "b": ["x", "y", "z"]})
            p = Path(tmp) / "verify.parquet"
            df.write_parquet(p)
            back = pl.read_parquet(p)
            assert back.height == 3
        print("[green]✓[/green] parquet write/read roundtrip")
    except Exception as exc:  # noqa: BLE001
        failures.append(f"parquet: {exc}")
        print(f"[red]✗[/red] parquet roundtrip failed: {exc}")

    # 3. duckdb in-memory query
    try:
        import duckdb
        v = duckdb.connect(":memory:").execute("SELECT 1+1 AS x").fetchone()
        assert v[0] == 2
        print("[green]✓[/green] duckdb in-memory query")
    except Exception as exc:  # noqa: BLE001
        failures.append(f"duckdb: {exc}")
        print(f"[red]✗[/red] duckdb failed: {exc}")

    # 4. CLI entry point
    if not (collect_app and features_app and export_app):
        failures.append("cli: subcommands missing")
        print("[red]✗[/red] CLI subcommands missing")
    else:
        print("[green]✓[/green] CLI subcommands registered "
              "(collect / features / export / cache / verify)")

    # 5. optional network check
    if network:
        try:
            from nsefast.http_client import create_session
            from nsefast.robots import can_fetch
            sess = create_session()
            ok = can_fetch("https://www.nseindia.com/api/allIndices")
            print(f"[green]✓[/green] robots.txt fetched (allIndices allowed = {ok})")
            print(f"[green]✓[/green] HTTP session warmed up: cookies={len(sess.cookies)}")
        except Exception as exc:  # noqa: BLE001
            failures.append(f"network: {exc}")
            print(f"[yellow]![/yellow] network check failed (often expected from "
                  f"datacenter IPs): {exc}")

    print()
    if failures:
        print(f"[red]FAILED[/red] — {len(failures)} check(s) failed")
        raise typer.Exit(1)
    print("[green]All checks passed[/green]")


# ---- cache ---------------------------------------------------------------

cache_app = typer.Typer(help="Inspect / clear the on-disk request cache.")
app.add_typer(cache_app, name="cache")


@cache_app.command("stats")
def cmd_cache_stats() -> None:
    s = cache_stats()
    print(f"entries: {s['entries']}")
    print(f"size:    {s['size_bytes'] / 1024:.1f} KB")
    print(f"oldest:  {s['oldest_age_seconds']} s")


@cache_app.command("clear")
def cmd_cache_clear() -> None:
    n = clear_cache()
    print(f"[green]Removed[/green] {n} cache file(s)")


if __name__ == "__main__":
    app()
