"""Trading feature engineering on top of normalized OHLCV / delivery data."""

from __future__ import annotations

import polars as pl


def add_delivery_features(df: pl.DataFrame) -> pl.DataFrame:
    cols = set(df.columns)
    if {"deliverable_qty", "total_traded_qty"}.issubset(cols):
        df = df.with_columns(
            ((pl.col("deliverable_qty") / pl.col("total_traded_qty")) * 100)
            .alias("delivery_pct_calc")
        )
    return df


def add_volume_breakout(df: pl.DataFrame, window: int = 20) -> pl.DataFrame:
    if "volume" not in df.columns:
        return df
    return df.with_columns(
        pl.col("volume").rolling_mean(window).alias("avg_volume_20")
    ).with_columns(
        (pl.col("volume") > pl.col("avg_volume_20") * 1.5).alias("volume_breakout")
    )


def swing_features(df: pl.DataFrame) -> pl.DataFrame:
    """Compose typical swing-trading features in one pass."""
    df = add_delivery_features(df)
    df = add_volume_breakout(df)
    return df
