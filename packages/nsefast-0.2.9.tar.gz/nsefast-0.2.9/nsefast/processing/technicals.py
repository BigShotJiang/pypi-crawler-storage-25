"""Common technical indicators on long-format Polars DataFrames.

Every function here:

- Takes a long-format frame already sorted by ``(symbol, trade_date)`` and
  adds one or more new columns *without mutating the input*.
- Computes per-symbol via ``.over(group_col)`` when the group column is
  present, so a multi-symbol panel and a single-symbol time series both
  work.
- Returns the input unchanged on any error or missing dependency column —
  it never raises (matches the library-wide contract).

Columns added (one or a small fixed set per call):

- :func:`add_sma`              → ``sma_{n}``
- :func:`add_ema`              → ``ema_{n}``
- :func:`add_rsi`              → ``rsi_{n}``
- :func:`add_macd`             → ``macd``, ``macd_signal``, ``macd_hist``
- :func:`add_bollinger`        → ``bb_mid``, ``bb_upper``, ``bb_lower``
- :func:`add_donchian`         → ``dc_upper``, ``dc_lower``, ``dc_mid``
- :func:`add_supertrend`       → ``st_upper``, ``st_lower``, ``st_dir``
                                 (Polars-vectorised approximation, see
                                 docstring)
- :func:`add_adx`              → ``plus_di``, ``minus_di``, ``adx_{n}``
- :func:`add_obv`              → ``obv``
- :func:`add_all_technicals`   → all of the above with sensible defaults.

Backward-compatible thin wrappers (``sma``, ``ema``, ``rsi``, ``macd``)
are kept for any callers using the v0.2.x function names.
"""

from __future__ import annotations

from typing import Iterable

import polars as pl

from nsefast.logging_setup import get_logger

log = get_logger(__name__)


# ---- helpers ---------------------------------------------------------------


def _rolling(expr: pl.Expr, fn: str, n: int, group_col: str | None) -> pl.Expr:
    """``expr.<fn>(n)`` partitioned by ``group_col`` when provided."""
    base = getattr(expr, fn)(n)
    return base.over(group_col) if group_col else base


def _ewm(expr: pl.Expr, span: int, group_col: str | None) -> pl.Expr:
    base = expr.ewm_mean(span=span, adjust=False)
    return base.over(group_col) if group_col else base


def _shift(expr: pl.Expr, n: int, group_col: str | None) -> pl.Expr:
    base = expr.shift(n)
    return base.over(group_col) if group_col else base


def _gc(df: pl.DataFrame, group_col: str | None) -> str | None:
    """Return ``group_col`` only if the column actually exists in ``df``."""
    return group_col if (group_col and group_col in df.columns) else None


def _safe(fn):
    """Decorator: any unhandled error → log + return ``df`` unchanged."""
    def wrapper(df: pl.DataFrame, *args, **kwargs):
        if df is None or df.is_empty():
            return df if df is not None else pl.DataFrame()
        try:
            return fn(df, *args, **kwargs)
        except Exception as exc:  # noqa: BLE001
            log.warning("%s failed: %s", fn.__name__, exc)
            return df
    wrapper.__name__ = fn.__name__
    wrapper.__doc__ = fn.__doc__
    return wrapper


# ---- single-line indicators ------------------------------------------------


@_safe
def add_sma(df: pl.DataFrame, *, n: int = 20, col: str = "close",
            group_col: str = "symbol") -> pl.DataFrame:
    """Simple moving average → ``sma_{n}``."""
    if col not in df.columns:
        return df
    g = _gc(df, group_col)
    return df.with_columns(
        _rolling(pl.col(col).cast(pl.Float64, strict=False), "rolling_mean", n, g)
        .alias(f"sma_{n}")
    )


@_safe
def add_ema(df: pl.DataFrame, *, n: int = 20, col: str = "close",
            group_col: str = "symbol") -> pl.DataFrame:
    """Exponential moving average → ``ema_{n}`` (``adjust=False``)."""
    if col not in df.columns:
        return df
    g = _gc(df, group_col)
    return df.with_columns(
        _ewm(pl.col(col).cast(pl.Float64, strict=False), n, g).alias(f"ema_{n}")
    )


@_safe
def add_rsi(df: pl.DataFrame, *, n: int = 14, col: str = "close",
            group_col: str = "symbol") -> pl.DataFrame:
    """Wilder-style RSI → ``rsi_{n}``. Smoothed with SMA (close to Wilder for
    n ≥ 14; swap to ``ewm_mean(alpha=1/n)`` if exact Wilder smoothing is
    needed)."""
    if col not in df.columns:
        return df
    g = _gc(df, group_col)
    base = pl.col(col).cast(pl.Float64, strict=False)
    delta = base.diff().over(g) if g else base.diff()
    gain = pl.when(delta > 0).then(delta).otherwise(0.0)
    loss = pl.when(delta < 0).then(-delta).otherwise(0.0)
    avg_gain = gain.rolling_mean(n).over(g) if g else gain.rolling_mean(n)
    avg_loss = loss.rolling_mean(n).over(g) if g else loss.rolling_mean(n)
    # Edge cases: zero-loss windows ⇒ RSI 100 (sustained uptrend);
    # zero-gain windows ⇒ RSI 0; both zero (flat) ⇒ RSI 50.
    rsi_expr = (
        pl.when(avg_gain.is_null() | avg_loss.is_null()).then(None)
          .when((avg_loss == 0) & (avg_gain == 0)).then(50.0)
          .when(avg_loss == 0).then(100.0)
          .when(avg_gain == 0).then(0.0)
          .otherwise(100.0 - 100.0 / (1.0 + avg_gain / avg_loss))
    )
    return df.with_columns(rsi_expr.alias(f"rsi_{n}"))


# ---- multi-column indicators -----------------------------------------------


@_safe
def add_macd(df: pl.DataFrame, *, fast: int = 12, slow: int = 26,
             signal: int = 9, col: str = "close",
             group_col: str = "symbol") -> pl.DataFrame:
    """MACD → ``macd``, ``macd_signal``, ``macd_hist``."""
    if col not in df.columns:
        return df
    g = _gc(df, group_col)
    base = pl.col(col).cast(pl.Float64, strict=False)
    macd = (_ewm(base, fast, g) - _ewm(base, slow, g)).alias("macd")
    out = df.with_columns(macd)
    sig = _ewm(pl.col("macd"), signal, g).alias("macd_signal")
    out = out.with_columns(sig)
    return out.with_columns((pl.col("macd") - pl.col("macd_signal")).alias("macd_hist"))


@_safe
def add_bollinger(df: pl.DataFrame, *, n: int = 20, k: float = 2.0,
                  col: str = "close", group_col: str = "symbol") -> pl.DataFrame:
    """Bollinger bands → ``bb_mid``, ``bb_upper``, ``bb_lower``."""
    if col not in df.columns:
        return df
    g = _gc(df, group_col)
    base = pl.col(col).cast(pl.Float64, strict=False)
    mid = _rolling(base, "rolling_mean", n, g).alias("bb_mid")
    sd  = _rolling(base, "rolling_std",  n, g).alias("_bb_sd")
    out = df.with_columns([mid, sd])
    return (out
            .with_columns([
                (pl.col("bb_mid") + k * pl.col("_bb_sd")).alias("bb_upper"),
                (pl.col("bb_mid") - k * pl.col("_bb_sd")).alias("bb_lower"),
            ])
            .drop("_bb_sd"))


@_safe
def add_donchian(df: pl.DataFrame, *, n: int = 20,
                 high_col: str = "high", low_col: str = "low",
                 group_col: str = "symbol") -> pl.DataFrame:
    """Donchian channels → ``dc_upper``, ``dc_lower``, ``dc_mid``."""
    if not {high_col, low_col}.issubset(df.columns):
        return df
    g = _gc(df, group_col)
    h = pl.col(high_col).cast(pl.Float64, strict=False)
    l = pl.col(low_col).cast(pl.Float64, strict=False)
    upper = _rolling(h, "rolling_max", n, g).alias("dc_upper")
    lower = _rolling(l, "rolling_min", n, g).alias("dc_lower")
    out = df.with_columns([upper, lower])
    return out.with_columns(
        ((pl.col("dc_upper") + pl.col("dc_lower")) / 2.0).alias("dc_mid")
    )


@_safe
def add_supertrend(df: pl.DataFrame, *, n: int = 10, mult: float = 3.0,
                   high_col: str = "high", low_col: str = "low",
                   close_col: str = "close",
                   group_col: str = "symbol") -> pl.DataFrame:
    """SuperTrend (vectorised approximation).

    Adds ``st_upper`` / ``st_lower`` (basic ATR bands around the H+L
    midpoint) and ``st_dir`` (``+1`` when ``close > st_upper`` ⇒ price has
    broken above the upper band, ``-1`` when ``close < st_lower`` ⇒
    broken below the lower band, otherwise ``null``).

    This is the standard *basic* band formulation without the
    path-dependent flip state machine — sufficient for most swing-trading
    filters and fully Polars-vectorised. If you need the full state-machine
    SuperTrend, post-process per symbol.
    """
    if not {high_col, low_col, close_col}.issubset(df.columns):
        return df
    g = _gc(df, group_col)
    h = pl.col(high_col).cast(pl.Float64, strict=False)
    l = pl.col(low_col).cast(pl.Float64, strict=False)
    c = pl.col(close_col).cast(pl.Float64, strict=False)
    prev_c = c.shift(1).over(g) if g else c.shift(1)
    tr = pl.max_horizontal(h - l, (h - prev_c).abs(), (l - prev_c).abs())
    atr = tr.rolling_mean(n).over(g) if g else tr.rolling_mean(n)
    mid = (h + l) / 2.0
    upper = (mid + mult * atr).alias("st_upper")
    lower = (mid - mult * atr).alias("st_lower")
    out = df.with_columns([upper, lower])
    return out.with_columns(
        pl.when(pl.col(close_col) > pl.col("st_upper")).then(1)
          .when(pl.col(close_col) < pl.col("st_lower")).then(-1)
          .otherwise(None)
          .cast(pl.Int8)
          .alias("st_dir")
    )


@_safe
def add_adx(df: pl.DataFrame, *, n: int = 14,
            high_col: str = "high", low_col: str = "low",
            close_col: str = "close",
            group_col: str = "symbol") -> pl.DataFrame:
    """ADX → ``plus_di``, ``minus_di``, ``adx_{n}`` (SMA-smoothed)."""
    if not {high_col, low_col, close_col}.issubset(df.columns):
        return df
    g = _gc(df, group_col)
    h = pl.col(high_col).cast(pl.Float64, strict=False)
    l = pl.col(low_col).cast(pl.Float64, strict=False)
    c = pl.col(close_col).cast(pl.Float64, strict=False)
    prev_h = h.shift(1).over(g) if g else h.shift(1)
    prev_l = l.shift(1).over(g) if g else l.shift(1)
    prev_c = c.shift(1).over(g) if g else c.shift(1)

    up_move = h - prev_h
    dn_move = prev_l - l
    plus_dm  = pl.when((up_move > dn_move) & (up_move > 0)).then(up_move).otherwise(0.0)
    minus_dm = pl.when((dn_move > up_move) & (dn_move > 0)).then(dn_move).otherwise(0.0)
    tr = pl.max_horizontal(h - l, (h - prev_c).abs(), (l - prev_c).abs())

    sm_tr   = tr.rolling_mean(n).over(g) if g else tr.rolling_mean(n)
    sm_pdm  = plus_dm.rolling_mean(n).over(g)  if g else plus_dm.rolling_mean(n)
    sm_mdm  = minus_dm.rolling_mean(n).over(g) if g else minus_dm.rolling_mean(n)

    safe_tr = pl.when(sm_tr > 0).then(sm_tr).otherwise(None)
    plus_di  = (100.0 * sm_pdm / safe_tr).alias("plus_di")
    minus_di = (100.0 * sm_mdm / safe_tr).alias("minus_di")
    out = df.with_columns([plus_di, minus_di])

    denom = pl.col("plus_di") + pl.col("minus_di")
    dx = (100.0 * (pl.col("plus_di") - pl.col("minus_di")).abs()
          / pl.when(denom > 0).then(denom).otherwise(None))
    adx = dx.rolling_mean(n).over(g) if g else dx.rolling_mean(n)
    return out.with_columns(adx.alias(f"adx_{n}"))


@_safe
def add_obv(df: pl.DataFrame, *, close_col: str = "close",
            volume_col: str = "volume",
            group_col: str = "symbol") -> pl.DataFrame:
    """On-Balance Volume → ``obv`` (cumulative, per-symbol)."""
    if not {close_col, volume_col}.issubset(df.columns):
        return df
    g = _gc(df, group_col)
    c = pl.col(close_col).cast(pl.Float64, strict=False)
    v = pl.col(volume_col).cast(pl.Float64, strict=False)
    prev_c = c.shift(1).over(g) if g else c.shift(1)
    signed = pl.when(c > prev_c).then(v).when(c < prev_c).then(-v).otherwise(0.0)
    cum = signed.cum_sum().over(g) if g else signed.cum_sum()
    return df.with_columns(cum.alias("obv"))


# ---- bundled convenience ---------------------------------------------------


def add_all_technicals(
    df: pl.DataFrame,
    *,
    group_col: str = "symbol",
    ema_windows: Iterable[int] = (20, 50, 200),
    rsi_period: int = 14,
    bb_period: int = 20,
    donchian_period: int = 20,
    adx_period: int = 14,
    supertrend_period: int = 10,
    supertrend_mult: float = 3.0,
) -> pl.DataFrame:
    """Apply the full indicator pack with library defaults."""
    out = df
    for w in ema_windows:
        out = add_ema(out, n=w, group_col=group_col)
    out = add_rsi(out, n=rsi_period, group_col=group_col)
    out = add_macd(out, group_col=group_col)
    out = add_bollinger(out, n=bb_period, group_col=group_col)
    out = add_donchian(out, n=donchian_period, group_col=group_col)
    out = add_supertrend(out, n=supertrend_period, mult=supertrend_mult,
                         group_col=group_col)
    out = add_adx(out, n=adx_period, group_col=group_col)
    out = add_obv(out, group_col=group_col)
    return out


# ---- backward-compatible thin wrappers -------------------------------------


def sma(df: pl.DataFrame, column: str = "close", window: int = 20) -> pl.DataFrame:
    """Backwards-compat wrapper for :func:`add_sma` (no per-symbol grouping)."""
    return add_sma(df, n=window, col=column, group_col="")


def ema(df: pl.DataFrame, column: str = "close", window: int = 20) -> pl.DataFrame:
    """Backwards-compat wrapper for :func:`add_ema` (no per-symbol grouping)."""
    return add_ema(df, n=window, col=column, group_col="")


def rsi(df: pl.DataFrame, column: str = "close", window: int = 14) -> pl.DataFrame:
    """Backwards-compat wrapper for :func:`add_rsi` (no per-symbol grouping)."""
    return add_rsi(df, n=window, col=column, group_col="")


def macd(df: pl.DataFrame, column: str = "close",
         fast: int = 12, slow: int = 26, signal: int = 9) -> pl.DataFrame:
    """Backwards-compat wrapper for :func:`add_macd` (no per-symbol grouping)."""
    return add_macd(df, fast=fast, slow=slow, signal=signal, col=column,
                    group_col="")
