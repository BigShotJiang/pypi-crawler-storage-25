"""Post-collection processing: normalize, features, technicals."""
