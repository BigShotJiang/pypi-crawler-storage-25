"""Split / bonus / dividend price adjustments.

Consumes the canonical ``corporate_actions`` schema
(``ex_date, record_date, symbol, company_name, purpose, face_value,
source_url``) and produces:

- :func:`compute_adjustment_factors` — one row per ``(symbol, ex_date)`` with
  ``factor`` such that ``price_before_ex × factor == adjusted_price``.
- :func:`apply_adjustments` — adds ``adj_open / adj_high / adj_low /
  adj_close / adj_volume`` columns to a long-format OHLCV frame.

Conventions
-----------

- Bonus ``a:b`` (``a`` new for every ``b`` held): factor ``= b / (a + b)``
- Split where face value drops from ``F_old`` to ``F_new``: factor
  ``= F_new / F_old`` (e.g. Rs 10 → Rs 5 ⇒ 0.5).
- Dividend of ``d`` rupees: factor ``= (close_prev_ex - d) / close_prev_ex``
  computed against the close on the trading day immediately before
  ``ex_date``. If the close cannot be located, the dividend is *skipped*
  rather than guessed (we never silently fabricate prices).
- Volume is adjusted *inversely* (``adj_volume = volume / factor``) so a
  2-for-1 split doubles historical reported volume to per-share comparable
  units.
- Price columns and volume on or after each ``ex_date`` are unchanged.

Every function returns a Polars DataFrame and never raises.
"""

from __future__ import annotations

import re
from datetime import date

import polars as pl

from nsefast.logging_setup import get_logger

log = get_logger(__name__)


_FACTOR_SCHEMA: dict[str, pl.DataType] = {
    "symbol":      pl.Utf8,
    "ex_date":     pl.Date,
    "action_type": pl.Utf8,        # "split" | "bonus" | "dividend"
    "factor":      pl.Float64,     # multiply pre-ex prices by this
    "raw_purpose": pl.Utf8,
}


def _empty_factors() -> pl.DataFrame:
    return pl.DataFrame(schema=_FACTOR_SCHEMA)


# ---- purpose-string parsing ------------------------------------------------

_BONUS_RE   = re.compile(r"bonus[^0-9]*(\d+)\s*:\s*(\d+)", re.I)
_SPLIT_RE_FV = re.compile(
    r"(?:split|sub[- ]?division).*?rs\.?\s*([\d.]+).*?(?:to|/-?\s*to).*?rs\.?\s*([\d.]+)",
    re.I,
)
_SPLIT_RE_RATIO = re.compile(r"(?:split|sub[- ]?division)[^0-9]*(\d+)\s*:\s*(\d+)", re.I)
_DIV_PCT_RE = re.compile(r"dividend[^%0-9]*([\d.]+)\s*%", re.I)
_DIV_RS_RE  = re.compile(r"dividend[^0-9%]*(?:rs\.?|inr)\s*([\d.]+)", re.I)
_DIV_BARE_RE = re.compile(r"dividend[^0-9%]*([\d.]+)\s*(?:per|/-)", re.I)


def parse_purpose(purpose: str) -> tuple[str | None, float | None]:
    """Best-effort parse of NSE's free-text ``purpose`` field.

    Returns ``(action_type, value)`` where:

    - ``action_type`` is ``"bonus"``, ``"split"``, ``"dividend"``,
      ``"dividend_pct"``, or ``None`` if the string couldn't be matched.
    - ``value`` is:
        * for ``bonus`` / ``split`` — the price-adjustment ``factor`` (0–1).
        * for ``dividend`` — the rupee amount per share.
        * for ``dividend_pct`` — the percentage of face value (e.g. 250.0 for
          "Dividend 250%"). Conversion to rupees needs ``face_value`` and is
          handled in :func:`compute_adjustment_factors`.

    Returns ``(None, None)`` for any unparseable / ambiguous input.
    """
    if not isinstance(purpose, str) or not purpose.strip():
        return None, None

    text = purpose.strip()
    try:
        m = _BONUS_RE.search(text)
        if m:
            a, b = int(m.group(1)), int(m.group(2))
            if a + b > 0:
                return "bonus", b / (a + b)

        m = _SPLIT_RE_FV.search(text)
        if m:
            f_old, f_new = float(m.group(1)), float(m.group(2))
            if f_old > 0:
                return "split", f_new / f_old

        m = _SPLIT_RE_RATIO.search(text)
        if m:
            old, new = int(m.group(1)), int(m.group(2))
            if new > 0:
                return "split", old / new

        m = _DIV_PCT_RE.search(text)
        if m:
            return "dividend_pct", float(m.group(1))

        m = _DIV_RS_RE.search(text) or _DIV_BARE_RE.search(text)
        if m:
            return "dividend", float(m.group(1))
    except Exception as exc:  # noqa: BLE001
        log.debug("parse_purpose(%r) failed: %s", text, exc)

    return None, None


# ---- factor computation ----------------------------------------------------


def compute_adjustment_factors(
    actions_df: pl.DataFrame,
    *,
    prices_df: pl.DataFrame | None = None,
    close_col: str = "close",
    date_col: str = "trade_date",
) -> pl.DataFrame:
    """Turn raw corporate-actions rows into ``(symbol, ex_date, factor)``.

    Splits and bonuses are derived purely from the ``purpose`` text.
    Dividends additionally need ``prices_df`` (long OHLCV from
    :func:`nsefast.history.load_range`) so we can look up the prior-day
    close — without it, dividend rows are dropped.
    """
    if actions_df is None or actions_df.is_empty():
        return _empty_factors()
    needed = {"symbol", "ex_date", "purpose"}
    if not needed.issubset(actions_df.columns):
        log.debug("compute_adjustment_factors: missing %s",
                  needed - set(actions_df.columns))
        return _empty_factors()

    has_face_value = "face_value" in actions_df.columns

    try:
        cols = [
            pl.col("symbol").cast(pl.Utf8),
            pl.col("ex_date").cast(pl.Utf8, strict=False)
              .str.strptime(pl.Date, format=None, strict=False).alias("ex_date"),
            pl.col("purpose").cast(pl.Utf8),
        ]
        if has_face_value:
            cols.append(pl.col("face_value").cast(pl.Float64, strict=False))
        df = actions_df.select(cols).drop_nulls(
            subset=["symbol", "ex_date", "purpose"]
        )

        rows: list[dict] = []
        for r in df.iter_rows(named=True):
            action, value = parse_purpose(r["purpose"])
            if action is None or value is None:
                continue
            if action in ("split", "bonus"):
                if 0 < value < 1:
                    rows.append({
                        "symbol":      r["symbol"],
                        "ex_date":     r["ex_date"],
                        "action_type": action,
                        "factor":      value,
                        "raw_purpose": r["purpose"],
                    })
            elif action in ("dividend", "dividend_pct"):
                if prices_df is None or prices_df.is_empty():
                    continue
                if action == "dividend_pct":
                    fv = r.get("face_value") if has_face_value else None
                    if fv is None or fv <= 0:
                        # Refuse to guess — silently skipping is safer than
                        # fabricating an adjustment from an unknown base.
                        log.debug(
                            "skip %% dividend for %s on %s — no face_value",
                            r["symbol"], r["ex_date"],
                        )
                        continue
                    div_rs = (value / 100.0) * float(fv)
                else:
                    div_rs = value
                f = _dividend_factor(prices_df, r["symbol"], r["ex_date"],
                                     div_rs, close_col=close_col, date_col=date_col)
                if f is not None and 0 < f < 1:
                    rows.append({
                        "symbol":      r["symbol"],
                        "ex_date":     r["ex_date"],
                        "action_type": "dividend",
                        "factor":      f,
                        "raw_purpose": r["purpose"],
                    })

        if not rows:
            return _empty_factors()
        raw = pl.DataFrame(rows, schema=_FACTOR_SCHEMA)

        # Consolidate same-day multi-actions into one row per (symbol, ex_date).
        consolidated = (raw
            .group_by(["symbol", "ex_date"], maintain_order=True)
            .agg([
                pl.col("factor").product().alias("factor"),
                pl.col("action_type").str.join("+").alias("action_type"),
                pl.col("raw_purpose").str.join(" | ").alias("raw_purpose"),
            ])
            .select(list(_FACTOR_SCHEMA))
            .sort(["symbol", "ex_date"]))
        return consolidated
    except Exception as exc:  # noqa: BLE001
        log.warning("compute_adjustment_factors failed: %s", exc)
        return _empty_factors()


def _dividend_factor(
    prices_df: pl.DataFrame,
    symbol: str,
    ex_date: date,
    dividend: float,
    *,
    close_col: str,
    date_col: str,
) -> float | None:
    try:
        prior = (prices_df
                 .filter((pl.col("symbol") == symbol) & (pl.col(date_col) < ex_date))
                 .sort(date_col)
                 .tail(1))
        if prior.is_empty() or close_col not in prior.columns:
            return None
        prev_close = float(prior[close_col][0])
        if prev_close <= 0 or dividend >= prev_close:
            return None
        return (prev_close - dividend) / prev_close
    except Exception as exc:  # noqa: BLE001
        log.debug("_dividend_factor(%s,%s) failed: %s", symbol, ex_date, exc)
        return None


# ---- apply adjustments -----------------------------------------------------


_PRICE_COLS = ("open", "high", "low", "close", "prev_close")


def apply_adjustments(
    prices_df: pl.DataFrame,
    factors_df: pl.DataFrame,
    *,
    date_col: str = "trade_date",
    volume_col: str = "volume",
) -> pl.DataFrame:
    """Add ``adj_*`` columns to a long-format OHLCV frame.

    For each ``(symbol, trade_date)``, the cumulative adjustment factor is
    the product of every ``factor`` whose ``ex_date > trade_date``. Prices
    are multiplied by it; volume is divided by it (so unit-share volume is
    comparable across splits).
    """
    if prices_df is None or prices_df.is_empty():
        return prices_df if prices_df is not None else pl.DataFrame()
    if factors_df is None or factors_df.is_empty():
        return _passthrough_adj(prices_df, volume_col=volume_col)

    try:
        f = (factors_df
             .select(
                 pl.col("symbol").cast(pl.Utf8),
                 pl.col("ex_date").cast(pl.Date),
                 pl.col("factor").cast(pl.Float64),
             )
             .drop_nulls())

        # Compute per-(symbol, trade_date) cumulative factor:
        # product of every factor whose ex_date is strictly AFTER the trade_date.
        keys = prices_df.select([
            pl.col("symbol").cast(pl.Utf8),
            pl.col(date_col).cast(pl.Date).alias(date_col),
        ]).unique()

        per_row = (keys
                   .join(f, on="symbol", how="left")
                   .with_columns(
                       pl.when(pl.col("ex_date").is_null()
                               | (pl.col("ex_date") <= pl.col(date_col)))
                         .then(pl.lit(1.0))
                         .otherwise(pl.col("factor"))
                         .alias("_eff")
                   )
                   .group_by(["symbol", date_col])
                   .agg(pl.col("_eff").product().alias("_factor")))

        out = (prices_df
               .with_columns(pl.col("symbol").cast(pl.Utf8))
               .join(per_row, on=["symbol", date_col], how="left")
               .with_columns(pl.col("_factor").fill_null(1.0)))

        adj_exprs: list[pl.Expr] = []
        for col in _PRICE_COLS:
            if col in prices_df.columns:
                adj_exprs.append(
                    (pl.col(col).cast(pl.Float64, strict=False) * pl.col("_factor"))
                    .alias(f"adj_{col}")
                )
        if volume_col in prices_df.columns:
            adj_exprs.append(
                (pl.col(volume_col).cast(pl.Float64, strict=False)
                 / pl.col("_factor")).alias(f"adj_{volume_col}")
            )
        if not adj_exprs:
            return prices_df

        return (out
                .with_columns(adj_exprs)
                .drop("_factor")
                .sort(["symbol", date_col]))
    except Exception as exc:  # noqa: BLE001
        log.warning("apply_adjustments failed: %s", exc)
        return _passthrough_adj(prices_df, volume_col=volume_col)


def _passthrough_adj(df: pl.DataFrame, *, volume_col: str = "volume") -> pl.DataFrame:
    """Add ``adj_*`` columns equal to the originals (when no factors apply)."""
    try:
        adds: list[pl.Expr] = []
        for col in _PRICE_COLS:
            if col in df.columns:
                adds.append(pl.col(col).cast(pl.Float64, strict=False).alias(f"adj_{col}"))
        if volume_col in df.columns:
            adds.append(pl.col(volume_col).cast(pl.Float64, strict=False)
                        .alias(f"adj_{volume_col}"))
        return df.with_columns(adds) if adds else df
    except Exception as exc:  # noqa: BLE001
        log.warning("_passthrough_adj failed: %s", exc)
        return df
