"""Column name and dtype normalization."""

from __future__ import annotations

import re

import polars as pl


def clean_column_name(name: str) -> str:
    name = str(name).strip().lower()
    name = re.sub(r"[^a-z0-9]+", "_", name)
    return name.strip("_")


def normalize_columns(df: pl.DataFrame) -> pl.DataFrame:
    """Snake-case all column names."""
    return df.rename({col: clean_column_name(col) for col in df.columns})
