"""nsefast — fast NSE India data collector."""

__version__ = "0.2.9"
