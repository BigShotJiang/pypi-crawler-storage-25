"""Central configuration: URLs, headers, paths, tunables."""

BASE_URL = "https://www.nseindia.com"
ARCHIVES_URL = "https://archives.nseindia.com"

PAGES = {
    "all_reports": "https://www.nseindia.com/all-reports",
    "derivatives_reports": "https://www.nseindia.com/all-reports-derivatives",
    "historical_reports": "https://www.nseindia.com/resources/historical-reports-capital-market-daily-monthly-archives",
    "corporate_announcements": "https://www.nseindia.com/companies-listing/corporate-filings-announcements",
    "corporate_actions": "https://www.nseindia.com/companies-listing/corporate-filings-actions",
    "board_meetings": "https://www.nseindia.com/companies-listing/corporate-filings-board-meetings",
    "financial_results": "https://www.nseindia.com/companies-listing/corporate-filings-financial-results",
    "shareholding_pattern": "https://www.nseindia.com/companies-listing/corporate-filings-shareholding-pattern",
    "annual_reports": "https://www.nseindia.com/companies-listing/corporate-filings-annual-reports",
    "insider_trading": "https://www.nseindia.com/companies-listing/corporate-filings-insider-trading",
    "bulk_deals": "https://www.nseindia.com/market-data/bulk-and-block-deals",
    "asm_list": "https://www.nseindia.com/reports/asm",
    "gsm_list": "https://www.nseindia.com/reports/gsm",
    "fo_ban": "https://www.nseindia.com/products-services/equity-derivatives-list-underlyings-information",
    "trading_holidays": "https://www.nseindia.com/resources/exchange-communication-holidays",
}

HEADERS = {
    "User-Agent": "Mozilla/5.0 nsefast/0.1.0 research-bot",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://www.nseindia.com/",
}

REQUEST_DELAY_SECONDS = 1.5
REQUEST_TIMEOUT_SECONDS = 20

RAW_DIR = "data/raw"
CLEAN_DIR = "data/clean"
PARQUET_DIR = "data/parquet"
DUCKDB_PATH = "data/nsefast.duckdb"
