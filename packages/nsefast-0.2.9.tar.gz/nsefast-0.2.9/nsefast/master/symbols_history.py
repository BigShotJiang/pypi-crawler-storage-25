"""Symbol survivorship — which symbols were tradeable on which date.

The single biggest source of fake alpha in backtests is using *today's*
universe to scan *yesterday's* prices. This module solves that by deriving
a history of active symbols directly from the bhavcopy presence record.

API
---

- :func:`build_symbols_history` walks every saved bhavcopy day and writes
  one row per ``(symbol, trade_date)`` to
  ``data/parquet/symbols_history/...``.
- :func:`load_symbols_history` reads that store.
- :func:`active_symbols_on(d)` and :func:`is_active(symbol, d)` are O(1) point
  queries against the loaded frame.
- :func:`delisted_symbols(after)` returns symbols whose last appearance was
  before ``after`` — useful for tagging delisting events.

All functions return Polars DataFrames / lists / bools and never raise.
"""

from __future__ import annotations

from datetime import date

import polars as pl

from nsefast.history import (
    available_dates,
    load_range,
)
from nsefast.logging_setup import get_logger
from nsefast.storage.parquet_store import (
    derive_date_partitions,
    read_parquet_partitioned,
    save_parquet_partitioned,
)

log = get_logger(__name__)

DATASET = "symbols_history"

_SCHEMA: dict[str, pl.DataType] = {
    "symbol":     pl.Utf8,
    "trade_date": pl.Date,
    "series":     pl.Utf8,
}


def _empty() -> pl.DataFrame:
    return pl.DataFrame(schema=_SCHEMA)


def build_symbols_history(
    *,
    start: date | str | None = None,
    end: date | str | None = None,
    source_dataset: str = "equity_bhavcopy",
    target_dataset: str = DATASET,
) -> pl.DataFrame:
    """Walk saved bhavcopy partitions and persist symbol presence per date.

    If ``start`` / ``end`` are ``None``, every available partition is used.
    Returns the resulting long-format DataFrame.
    """
    try:
        dates = available_dates(dataset=source_dataset)
        if not dates:
            log.info("build_symbols_history: no source data in %s", source_dataset)
            return _empty()
        s = dates[0] if start is None else start
        e = dates[-1] if end is None else end

        df = load_range(s, e, dataset=source_dataset, series=None)
        if df.is_empty():
            return _empty()

        keep = ["symbol", "trade_date"] + (["series"] if "series" in df.columns else [])
        out = (df.select(keep)
               .drop_nulls(subset=["symbol", "trade_date"])
               .unique(subset=["symbol", "trade_date"])
               .sort(["trade_date", "symbol"]))

        with_parts = derive_date_partitions(out, "trade_date", parts=("year",))
        save_parquet_partitioned(with_parts, target_dataset, by=["year"])
        log.info("symbols_history built", extra={
            "rows": out.height,
            "symbols": out["symbol"].n_unique() if not out.is_empty() else 0,
            "dates": len(dates),
        })
        return out
    except Exception as exc:  # noqa: BLE001
        log.warning("build_symbols_history failed: %s", exc)
        return _empty()


def load_symbols_history(
    *,
    dataset: str = DATASET,
    start: date | str | None = None,
    end: date | str | None = None,
) -> pl.DataFrame:
    """Load the persisted symbol-history frame, optionally date-filtered."""
    try:
        df = read_parquet_partitioned(dataset)
        if df.is_empty():
            return _empty()
        if "trade_date" in df.columns:
            df = df.with_columns(pl.col("trade_date").cast(pl.Date, strict=False))
        if start is not None:
            df = df.filter(pl.col("trade_date") >= pl.lit(start).cast(pl.Date, strict=False))
        if end is not None:
            df = df.filter(pl.col("trade_date") <= pl.lit(end).cast(pl.Date, strict=False))
        return df.sort(["trade_date", "symbol"])
    except Exception as exc:  # noqa: BLE001
        log.warning("load_symbols_history failed: %s", exc)
        return _empty()


def active_symbols_on(
    d: date | str,
    *,
    history: pl.DataFrame | None = None,
) -> list[str]:
    """List of symbols that had a bhavcopy row on ``d``."""
    try:
        df = history if history is not None else load_symbols_history()
        if df.is_empty():
            return []
        target = d if isinstance(d, date) else pl.lit(d).cast(pl.Date).item()
        return sorted(set(
            df.filter(pl.col("trade_date") == target)["symbol"].to_list()
        ))
    except Exception as exc:  # noqa: BLE001
        log.warning("active_symbols_on(%s) failed: %s", d, exc)
        return []


def is_active(
    symbol: str,
    d: date | str,
    *,
    history: pl.DataFrame | None = None,
) -> bool:
    try:
        df = history if history is not None else load_symbols_history()
        if df.is_empty():
            return False
        target = d if isinstance(d, date) else pl.lit(d).cast(pl.Date).item()
        return df.filter(
            (pl.col("symbol") == symbol) & (pl.col("trade_date") == target)
        ).height > 0
    except Exception as exc:  # noqa: BLE001
        log.warning("is_active(%s,%s) failed: %s", symbol, d, exc)
        return False


def delisted_symbols(
    after: date | str,
    *,
    history: pl.DataFrame | None = None,
) -> list[str]:
    """Symbols whose latest bhavcopy appearance is strictly before ``after``."""
    try:
        df = history if history is not None else load_symbols_history()
        if df.is_empty():
            return []
        last = (df.group_by("symbol")
                .agg(pl.max("trade_date").alias("last_seen")))
        cutoff = after if isinstance(after, date) else pl.lit(after).cast(pl.Date).item()
        gone = last.filter(pl.col("last_seen") < cutoff)["symbol"].to_list()
        return sorted(set(gone))
    except Exception as exc:  # noqa: BLE001
        log.warning("delisted_symbols(%s) failed: %s", after, exc)
        return []
