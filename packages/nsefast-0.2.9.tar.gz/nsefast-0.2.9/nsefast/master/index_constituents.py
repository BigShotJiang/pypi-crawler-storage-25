"""Index membership — constrain scans to a real, investable universe.

NSE publishes static constituent CSVs at ``archives.nseindia.com`` for the
major indices. Each CSV looks like::

    Company Name, Industry, Symbol, Series, ISIN Code

We normalise that to ``symbol, company_name, industry, series, isin,
index_name, fetched_at`` and return a Polars DataFrame.

Historical (point-in-time) membership is *not* exposed by NSE as a single
download; reconstructing it requires walking index-rebalance announcements.
:func:`historical_index_constituents` is a documented scaffold returning an
empty DataFrame for now — the API shape is stable so callers can wire it up
once the rebalance crawler lands in v0.3.0.

Every function returns a Polars DataFrame and never raises.
"""

from __future__ import annotations

import io
from datetime import date, datetime, timezone

import polars as pl

from nsefast.config import ARCHIVES_URL, REQUEST_TIMEOUT_SECONDS
from nsefast.http_client import create_session
from nsefast.logging_setup import get_logger
from nsefast.robots import can_fetch

log = get_logger(__name__)


KNOWN_INDICES: dict[str, str] = {
    "NIFTY 50":            f"{ARCHIVES_URL}/content/indices/ind_nifty50list.csv",
    "NIFTY NEXT 50":       f"{ARCHIVES_URL}/content/indices/ind_niftynext50list.csv",
    "NIFTY 100":           f"{ARCHIVES_URL}/content/indices/ind_nifty100list.csv",
    "NIFTY 200":           f"{ARCHIVES_URL}/content/indices/ind_nifty200list.csv",
    "NIFTY 500":           f"{ARCHIVES_URL}/content/indices/ind_nifty500list.csv",
    "NIFTY MIDCAP 50":     f"{ARCHIVES_URL}/content/indices/ind_niftymidcap50list.csv",
    "NIFTY MIDCAP 100":    f"{ARCHIVES_URL}/content/indices/ind_niftymidcap100list.csv",
    "NIFTY MIDCAP 150":    f"{ARCHIVES_URL}/content/indices/ind_niftymidcap150list.csv",
    "NIFTY SMALLCAP 50":   f"{ARCHIVES_URL}/content/indices/ind_niftysmallcap50list.csv",
    "NIFTY SMALLCAP 100":  f"{ARCHIVES_URL}/content/indices/ind_niftysmallcap100list.csv",
    "NIFTY SMALLCAP 250":  f"{ARCHIVES_URL}/content/indices/ind_niftysmallcap250list.csv",
    "NIFTY MICROCAP 250":  f"{ARCHIVES_URL}/content/indices/ind_niftymicrocap250_list.csv",
    "NIFTY BANK":          f"{ARCHIVES_URL}/content/indices/ind_niftybanklist.csv",
    "NIFTY IT":            f"{ARCHIVES_URL}/content/indices/ind_niftyitlist.csv",
    "NIFTY AUTO":          f"{ARCHIVES_URL}/content/indices/ind_niftyautolist.csv",
    "NIFTY FMCG":          f"{ARCHIVES_URL}/content/indices/ind_niftyfmcglist.csv",
    "NIFTY PHARMA":        f"{ARCHIVES_URL}/content/indices/ind_niftypharmalist.csv",
    "NIFTY METAL":         f"{ARCHIVES_URL}/content/indices/ind_niftymetallist.csv",
    "NIFTY ENERGY":        f"{ARCHIVES_URL}/content/indices/ind_niftyenergylist.csv",
    "NIFTY REALTY":        f"{ARCHIVES_URL}/content/indices/ind_niftyrealtylist.csv",
    "NIFTY FINANCIAL SERVICES": f"{ARCHIVES_URL}/content/indices/ind_niftyfinancelist.csv",
}


_CANONICAL_COLUMNS = [
    "symbol", "company_name", "industry", "series",
    "isin", "index_name", "source_url", "fetched_at",
]

_SCHEMA: dict[str, pl.DataType] = {
    "symbol":       pl.Utf8,
    "company_name": pl.Utf8,
    "industry":     pl.Utf8,
    "series":       pl.Utf8,
    "isin":         pl.Utf8,
    "index_name":   pl.Utf8,
    "source_url":   pl.Utf8,
    "fetched_at":   pl.Utf8,
}

# CSV header → canonical column
_HEADER_ALIASES = {
    "symbol":       "symbol",
    "company name": "company_name",
    "industry":     "industry",
    "series":       "series",
    "isin code":    "isin",
    "isin":         "isin",
}


def _empty() -> pl.DataFrame:
    return pl.DataFrame(schema=_SCHEMA)


def _normalise(raw: pl.DataFrame, *, index_name: str, source_url: str,
               fetched_at: str) -> pl.DataFrame:
    if raw.is_empty():
        return _empty()
    try:
        rename = {c: _HEADER_ALIASES.get(c.strip().lower(), c.strip().lower())
                  for c in raw.columns}
        df = raw.rename(rename)
        df = df.with_columns(
            pl.lit(index_name).alias("index_name"),
            pl.lit(source_url).alias("source_url"),
            pl.lit(fetched_at).alias("fetched_at"),
        )
        for col, dtype in _SCHEMA.items():
            if col not in df.columns:
                df = df.with_columns(pl.lit(None, dtype=dtype).alias(col))
            else:
                df = df.with_columns(pl.col(col).cast(dtype, strict=False))
        return df.select(_CANONICAL_COLUMNS)
    except Exception as exc:  # noqa: BLE001
        log.warning("index constituents normalise failed: %s", exc)
        return _empty()


def index_constituents(index: str = "NIFTY 50") -> pl.DataFrame:
    """Current constituents of ``index``.

    ``index`` is a key from :data:`KNOWN_INDICES` (case-insensitive).
    Returns an empty DataFrame for unknown indices, robots disallows,
    HTTP non-200, parse failure, or any other error.
    """
    if not isinstance(index, str):
        return _empty()
    key = next((k for k in KNOWN_INDICES if k.lower() == index.strip().lower()), None)
    if key is None:
        log.info("unknown index %r — known: %s", index, sorted(KNOWN_INDICES))
        return _empty()
    url = KNOWN_INDICES[key]
    if not can_fetch(url):
        log.info("robots.txt disallows %s", url)
        return _empty()

    try:
        session = create_session()
        resp = session.get(url, timeout=REQUEST_TIMEOUT_SECONDS)
    except Exception as exc:  # noqa: BLE001
        log.warning("index_constituents fetch failed: %s", exc)
        return _empty()

    if resp.status_code != 200:
        log.warning("index_constituents %s -> HTTP %s", key, resp.status_code)
        return _empty()

    try:
        raw = pl.read_csv(io.BytesIO(resp.content))
    except Exception as exc:  # noqa: BLE001
        log.warning("index_constituents CSV parse failed: %s", exc)
        return _empty()

    fetched_at = datetime.now(timezone.utc).isoformat()
    return _normalise(raw, index_name=key, source_url=url, fetched_at=fetched_at)


def historical_index_constituents(
    index: str,
    on_date: date | str,
) -> pl.DataFrame:
    """Point-in-time membership for ``index`` on ``on_date``.

    Currently a documented scaffold — NSE doesn't publish this as a single
    download. The implementation will land in v0.3.0 once the rebalance-
    announcement crawler is in place. Returns the canonical empty schema
    today so callers can wire against it now.
    """
    log.info("historical_index_constituents(%s, %s) — scaffold (v0.3.0)",
             index, on_date)
    return _empty()
