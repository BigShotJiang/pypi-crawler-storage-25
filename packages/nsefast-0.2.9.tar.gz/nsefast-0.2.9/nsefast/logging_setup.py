"""Structured logging for nsefast.

Two output formats:
- ``rich`` (default, human-friendly, used by the CLI)
- ``json`` (one JSON object per line, used in production / log aggregators)

Usage::

    from nsefast.logging_setup import setup_logging, get_logger
    setup_logging(level="INFO", fmt="json")
    log = get_logger(__name__)
    log.info("fetched", extra={"collector": "bulk_deals", "rows": 142,
                               "duration_ms": 312, "url": "https://..."})
"""

from __future__ import annotations

import json
import logging
import os
import sys
import time
from typing import Any

_STD_ATTRS = {
    "name", "msg", "args", "levelname", "levelno", "pathname", "filename",
    "module", "exc_info", "exc_text", "stack_info", "lineno", "funcName",
    "created", "msecs", "relativeCreated", "thread", "threadName",
    "processName", "process", "taskName",
}


class JsonFormatter(logging.Formatter):
    """One JSON object per record. Extra fields are merged into the top level."""

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(record.created))
                  + f".{int(record.msecs):03d}Z",
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        for key, val in record.__dict__.items():
            if key in _STD_ATTRS or key.startswith("_"):
                continue
            try:
                json.dumps(val)
                payload[key] = val
            except (TypeError, ValueError):
                payload[key] = repr(val)

        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False)


_CONFIGURED = False


def setup_logging(level: str | int = "INFO", fmt: str = "rich") -> None:
    """Configure root logging exactly once.

    ``fmt`` is one of ``"rich"`` or ``"json"``. The default can also be set
    with the ``NSEFAST_LOG_FORMAT`` env var.
    """
    global _CONFIGURED
    if _CONFIGURED:
        return

    fmt = os.environ.get("NSEFAST_LOG_FORMAT", fmt).lower()
    level = os.environ.get("NSEFAST_LOG_LEVEL", str(level)).upper()

    root = logging.getLogger()
    root.setLevel(level)
    for handler in list(root.handlers):
        root.removeHandler(handler)

    if fmt == "json":
        handler: logging.Handler = logging.StreamHandler(sys.stderr)
        handler.setFormatter(JsonFormatter())
    else:
        try:
            from rich.logging import RichHandler

            handler = RichHandler(rich_tracebacks=True, show_path=False)
            handler.setFormatter(logging.Formatter("%(message)s", datefmt="[%X]"))
        except ImportError:
            handler = logging.StreamHandler(sys.stderr)
            handler.setFormatter(
                logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
            )

    root.addHandler(handler)
    _CONFIGURED = True


def get_logger(name: str) -> logging.Logger:
    """Convenience wrapper so callers don't import ``logging`` directly."""
    return logging.getLogger(name)
