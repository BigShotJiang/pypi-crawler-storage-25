// SPDX-FileCopyrightText: Copyright 2025 Au-Zone Technologies
// SPDX-License-Identifier: Apache-2.0

#![cfg_attr(nightly, feature(f16))]

use pyo3::prelude::*;

pub mod decoder;
pub mod image;
pub mod tensor;
pub mod tracker;

pub struct FunctionTimer {
    name: String,
    start: std::time::Instant,
}

impl FunctionTimer {
    pub fn new(name: String) -> Self {
        Self {
            name,
            start: std::time::Instant::now(),
        }
    }
}

impl Drop for FunctionTimer {
    fn drop(&mut self) {
        log::trace!("{} elapsed: {:?}", self.name, self.start.elapsed())
    }
}

#[pymodule]
pub mod edgefirst_hal {
    pub use super::*;

    #[pymodule_init]
    fn init(m: &Bound<'_, PyModule>) -> PyResult<()> {
        env_logger::Builder::from_env(env_logger::Env::default().default_filter_or("info")).init();

        m.add_function(wrap_pyfunction!(version, m)?)?;
        m.add_function(wrap_pyfunction!(build_info, m)?)?;

        m.add_class::<tensor::PyTensor>()?;
        m.add_class::<tensor::PyTensorMemory>()?;
        m.add_class::<tensor::PyQuantization>()?;
        m.add_class::<image::PyPixelFormat>()?;
        m.add_class::<image::Normalization>()?;
        m.add_class::<image::PyRect>()?;
        m.add_class::<image::PyRotation>()?;
        m.add_class::<image::PyFlip>()?;
        m.add_class::<image::PyColorMode>()?;
        m.add_class::<image::PyMaskResolution>()?;
        m.add_class::<image::PyImageProcessor>()?;
        m.add_class::<image::PyEglDisplayKind>()?;
        m.add_function(wrap_pyfunction!(image::align_width_for_gpu_pitch, m)?)?;
        m.add_function(wrap_pyfunction!(image::align_width_for_pixel_format, m)?)?;
        m.add_function(wrap_pyfunction!(
            image::gpu_dma_buf_pitch_alignment_bytes,
            m
        )?)?;
        #[cfg(target_os = "linux")]
        {
            m.add_class::<image::PyEglDisplayInfo>()?;
            m.add_function(wrap_pyfunction!(image::probe_egl_displays, m)?)?;
        }
        m.add_class::<decoder::PyDecoder>()?;
        m.add_class::<decoder::PyProtoData>()?;
        m.add_class::<decoder::PyNms>()?;
        m.add_class::<decoder::PyDecoderType>()?;
        m.add_class::<decoder::PyDecoderVersion>()?;
        m.add_class::<decoder::PyDimName>()?;
        m.add_class::<decoder::PyOutput>()?;

        m.add_class::<tracker::PyTrackInfo>()?;
        m.add_class::<tracker::PyByteTrack>()?;
        m.add_class::<tracker::PyActiveTrackInfo>()?;

        Ok(())
    }

    #[pyfunction]
    fn version() -> String {
        env!("CARGO_PKG_VERSION").to_string()
    }

    /// Returns build configuration information including f16 implementation
    #[pyfunction]
    fn build_info() -> String {
        #[cfg(nightly)]
        let f16_impl = "native f16 (nightly, optimized)";
        #[cfg(not(nightly))]
        let f16_impl = "half::f16 (stable, compatible)";

        format!(
            "edgefirst-hal v{}\nf16 implementation: {}",
            env!("CARGO_PKG_VERSION"),
            f16_impl
        )
    }
}
