#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2026 Carsten Igel.
#
# This file is part of simplepycons
# (see https://github.com/carstencodes/simplepycons).
#
# This file is published using the MIT license.
# Refer to LICENSE for more information
#
""""""
# pylint: disable=C0302
# Justification: Code is generated

from typing import TYPE_CHECKING

from .base_icon import Icon

if TYPE_CHECKING:
    from collections.abc import Iterable


class OnePasswordIcon(Icon):
    """"""
    @property
    def name(self) -> "str":
        return "1password"

    @property
    def original_file_name(self) -> "str":
        return "1password.svg"

    @property
    def title(self) -> "str":
        return "1Password"

    @property
    def primary_color(self) -> "str":
        return "#145FE4"

    @property
    def raw_svg(self) -> "str":
        return ''' <svg xmlns="http://www.w3.org/2000/svg"
 role="img" viewBox="0 0 24 24">
    <title>1Password</title>
     <path d="M12 0c6.627 0 12 5.373 12 12 0 6.628-5.373 12-12 12S0
 18.628 0 12C0 5.373 5.373 0 12 0m-.893 4.86c-.485
 0-.727.001-.913.095a.87.87 0 0
 0-.378.379c-.094.185-.095.428-.095.912v2.747c0 .12 0
 .182.016.238q.02.075.065.138a1 1 0 0 0
 .175.162l.695.564c.113.092.17.139.19.194a.22.22 0 0 1 0
 .15c-.02.056-.077.102-.19.194l-.695.564a1 1 0 0 0-.175.162.4.4 0 0
 0-.065.138 1 1 0 0 0-.016.238v6.019c0 .485 0 .728.095.913a.87.87 0 0
 0 .378.378c.186.094.428.094.913.094h1.786c.485 0 .727 0
 .913-.094a.87.87 0 0 0
 .378-.378c.095-.185.095-.428.095-.913v-2.747c0-.12
 0-.182-.016-.238a.4.4 0 0 0-.065-.138 1 1 0 0
 0-.175-.162l-.695-.564c-.113-.092-.17-.138-.191-.193a.22.22 0 0 1
 0-.152c.02-.055.078-.1.19-.193l.696-.564a1 1 0 0 0 .175-.162.4.4 0 0
 0 .065-.138 1 1 0 0 0 .016-.238V6.246c0-.484 0-.727-.095-.912a.87.87
 0 0 0-.378-.379c-.186-.094-.428-.094-.913-.094Z" />
</svg>'''

    @property
    def guidelines_url(self) -> "str | None":
        _value: "str" = ''''''
        if len(_value) > 0:
            return _value
        return None

    @property
    def source(self) -> "str":
        return ''''''

    @property
    def license(self) -> "tuple[str | None, str | None]":
        _type: "str | None" = ''''''
        _url: "str | None" = ''''''

        if _type is not None and len(_type) == 0:
            _type = None

        if _url is not None and len(_url) == 0:
            _url = None

        return _type, _url

    @property
    def aliases(self) -> "Iterable[str]":
        yield from []
