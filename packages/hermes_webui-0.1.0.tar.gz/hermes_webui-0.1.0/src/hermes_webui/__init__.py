def main() -> None:
    print("Hello from hermes-webui!")
