"""cadenza_lab — distribution alias for the cadenza package.

The PyPI distribution name is ``cadenza-lab`` while the importable module is
``cadenza``. This thin alias lets users write::

    import cadenza_lab as cadenza
    cadenza.stack.register_world_model("smolvla", model=policy)
    cadenza.stack.run(robot="go1", goal="...")

Every name resolves to its counterpart on the underlying ``cadenza`` module —
this file owns no state of its own.
"""

import sys as _sys
import cadenza as _cadenza

# Re-export top-level names already populated by cadenza/__init__.py.
from cadenza import *  # noqa: F401,F403

# Make submodule attribute access work the same way: cadenza_lab.stack must be
# the *same* module object as cadenza.stack so registration state is shared.
import cadenza.stack as _stack

_sys.modules[__name__ + ".stack"] = _stack
stack = _stack


def __getattr__(name):
    """Forward unknown attributes (including cadenza's lazy ones) to cadenza."""
    return getattr(_cadenza, name)
