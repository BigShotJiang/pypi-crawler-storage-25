"""Download the Gene Ontology registry."""

import json
import logging
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any, ClassVar

import yaml

from bioregistry.alignment_model import Record, make_record
from bioregistry.constants import RAW_DIRECTORY, URI_FORMAT_KEY
from bioregistry.external.alignment_utils import Aligner, build_getter

__all__ = [
    "GoAligner",
    "get_go",
]

logger = logging.getLogger(__name__)

# Xrefs from GO that aren't generally useful
SKIP = {
    "TO_GIT",
    "OBO_SF_PO",
    "OBO_SF2_PO",
    "OBO_SF2_PECO",
    "PECO_GIT",
    "PO_GIT",
    "PSO_GIT",
    "EO_GIT",
}
BLOCK = {
    ("WBls", "http://www.wormbase.org/get?name=$1"),
    ("WB_REF", "http://www.wormbase.org/get?name=$1"),
    ("WBPhenotype", "http://www.wormbase.org/get?name=$1"),
    ("EnsemblFungi", "http://www.ensemblgenomes.org/id/$1"),
    ("EnsemblMetazoa", "http://www.ensemblgenomes.org/id/$1"),
    ("EnsemblPlants", "http://www.ensemblgenomes.org/id/$1"),
    ("EnsemblProtists", "http://www.ensemblgenomes.org/id/$1"),
}

# The key is redundant of the value
REDUNDANT = {
    "AspGD": "AspGD_LOCUS",
}

DIRECTORY = Path(__file__).parent.resolve()
RAW_PATH = RAW_DIRECTORY / "go.yml"
PROCESSED_PATH = DIRECTORY / "processed.json"
GO_URL = "https://raw.githubusercontent.com/geneontology/go-site/master/metadata/db-xrefs.yaml"
PROCESSING_GO_PATH = DIRECTORY / "processing_go.json"


def parse_go(path: Path) -> dict[str, Record]:
    """Parse raw GO registry."""
    with path.open() as file:
        raw_entries = yaml.full_load(file)
    records = {
        entry["database"]: _process_record(entry)
        for entry in raw_entries
        if entry["database"] not in SKIP and entry["database"] not in REDUNDANT
    }
    return records


get_go = build_getter(
    processed_path=PROCESSED_PATH,
    raw_path=RAW_PATH,
    url=GO_URL,
    func=parse_go,
)


def _process_record(data: Mapping[str, Any]) -> Record:
    """Prepare GO data to be added to the bioregistry for each GO registry entry."""
    external_id = data["database"]

    rv = {
        "name": data["name"],
    }

    description = data.get("description")
    if description:
        rv["description"] = description

    homepages = [
        homepage
        for homepage in data.get("generic_urls", [])
        if not any(
            homepage.startswith(homepage_prefix)
            for homepage_prefix in [
                "http://purl.obolibrary.org",
            ]
        )
    ]
    if len(homepages) > 1:
        logger.info(f"{external_id} multiple homepages {homepages}")
    if homepages:
        rv["homepage"] = homepages[0]

    entity_types = data.get("entity_types", [])
    if len(entity_types) > 1:
        logger.info(f"{external_id} multiple entity types")
        # TODO handle
    elif len(entity_types) == 1:
        entity_type = entity_types[0]
        uri_format = entity_type.get("url_syntax")
        if uri_format and not any(
            uri_format.startswith(formatter_prefix)
            for formatter_prefix in [
                "http://purl.obolibrary.org",
                "https://purl.obolibrary.org",
            ]
        ):
            uri_format = uri_format.replace("[example_id]", "$1")
            if (external_id, uri_format) not in BLOCK:
                rv[URI_FORMAT_KEY] = uri_format

    if "synonyms" in data:
        rv["prefix_synonyms"] = data["synonyms"]

    return make_record(rv)


class GoAligner(Aligner):
    """An aligner for the Gene Ontology (GO) registry."""

    key = "go"
    getter = get_go
    curation_header: ClassVar[Sequence[str]] = "name", "description"

    def get_skip(self) -> Mapping[str, str]:
        """Get the skipped GO identifiers."""
        with PROCESSING_GO_PATH.open() as file:
            j = json.load(file)
        return j["skip"]  # type:ignore


if __name__ == "__main__":
    GoAligner.cli()
