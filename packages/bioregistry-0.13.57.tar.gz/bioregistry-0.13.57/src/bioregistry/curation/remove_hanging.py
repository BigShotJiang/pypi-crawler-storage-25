"""Remove mappings to external prefixes that don't exist anymore."""

import json

import click

from bioregistry.constants import BIOREGISTRY_PATH
from bioregistry.external.align import aligner_resolver


@click.command()
def main() -> None:
    """Remove mappings to external prefixes that don't exist anymore."""
    registry = json.loads(BIOREGISTRY_PATH.read_text())

    for aligner_cls in aligner_resolver:
        click.echo(aligner_cls.key)
        data = aligner_cls.getter(force_download=False)
        for record in registry.values():
            mappings = record.get("mappings")
            if not mappings:
                continue
            value = mappings.get(aligner_cls.key)
            if not value:
                continue
            if value not in data:
                del record["mappings"][aligner_cls.key]
                del record[aligner_cls.key]

    for v in registry.values():
        if "mappings" in v and not v["mappings"]:
            del v["mappings"]

    BIOREGISTRY_PATH.write_text(
        json.dumps(registry, indent=2, ensure_ascii=False), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
