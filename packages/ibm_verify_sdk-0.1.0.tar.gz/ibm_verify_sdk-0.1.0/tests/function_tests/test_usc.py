"""
Functional tests for the usc module — password reset flow.

These tests make real API calls. Set environment variables before running:

    export IBM_VERIFY_TENANT_URL="https://your-tenant.verify.ibm.com"
    export IBM_VERIFY_USERNAME="your-username"
    export IBM_VERIFY_NEW_PASSWORD="new-password-to-set"

The test uses emailotp as the reset method. It will initiate the reset,
prompt for the OTP sent to the user's email, validate it, then complete the
reset with the new password.

Run with:
    python -m pytest tests/function_tests/test_usc.py -v --run-otp-validation
"""

import os

import pytest

from ibm_verify_sdk import (
    IbmVerifyClient,
    InitiatePasswordResetResponse,
    CompletePasswordResetResponse,
    ValidatePasswordResetResponse,
    UscPasswordResetStep,
)

TENANT_URL = os.environ.get("IBM_VERIFY_TENANT_URL", "")
USERNAME = os.environ.get("IBM_VERIFY_USERNAME", "")
NEW_PASSWORD = os.environ.get("IBM_VERIFY_NEW_PASSWORD", "")


@pytest.fixture(scope="module")
def client():
    if not TENANT_URL:
        pytest.skip("IBM_VERIFY_TENANT_URL must be set")
    c = IbmVerifyClient(tenant_url=TENANT_URL, access_token="")
    yield c
    c.close()


def test_password_reset_initiation(client):
    if not USERNAME:
        pytest.skip("IBM_VERIFY_USERNAME must be set")
    steps = [UscPasswordResetStep(method="emailotp")]
    response = client.usc.initiate_password_reset(user_name=USERNAME, steps=steps)
    assert response.status_code == 200
    assert isinstance(response.data, InitiatePasswordResetResponse)
    assert response.data.trxId is not None
    assert response.data.nextStep is not None
    assert response.data.nextStep.method == "emailotp"


def test_password_reset_full_flow(request, client):
    if not request.config.getoption("--run-otp-validation"):
        pytest.skip("Pass --run-otp-validation to run interactive password reset test")
    if not USERNAME:
        pytest.skip("IBM_VERIFY_USERNAME must be set")
    if not NEW_PASSWORD:
        pytest.skip("IBM_VERIFY_NEW_PASSWORD must be set")

    # Step 1: initiate
    steps = [UscPasswordResetStep(method="emailotp")]
    init = client.usc.initiate_password_reset(user_name=USERNAME, steps=steps)
    assert init.status_code == 200
    assert isinstance(init.data, InitiatePasswordResetResponse)
    trx_id = init.data.trxId

    # Step 2: validate OTP
    with open("/dev/tty", "r+") as tty:
        tty.write(f"\nEnter OTP sent to {USERNAME}'s email: ")
        tty.flush()
        otp = tty.readline().strip()

    validate = client.usc.validate_password_reset(trx_id=trx_id, otp=otp)
    assert validate.status_code == 200
    assert isinstance(validate.data, ValidatePasswordResetResponse)
    assert validate.data.stepsRemaining == 0

    # Step 3: complete reset
    complete = client.usc.complete_password_reset(trx_id=trx_id, password=NEW_PASSWORD)
    assert complete.status_code == 200
    assert isinstance(complete.data, CompletePasswordResetResponse)
    assert complete.data.userId is not None
