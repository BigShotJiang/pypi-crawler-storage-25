"""
Functional tests for the factors module.

These tests make real API calls. Set environment variables before running:

    export IBM_VERIFY_TENANT_URL="https://your-tenant.verify.ibm.com"
    export IBM_VERIFY_ACCESS_TOKEN_ADMIN="your-admin-token"
    export IBM_VERIFY_USER_ID="your-user-id"
    export IBM_VERIFY_EMAIL_ADDRESS="user@example.com"
    export IBM_VERIFY_PHONE_NUMBER="+15551234567"

OTP validation tests (optional, requires manual OTP entry):
    Run with --run-otp-validation to enable interactive OTP prompts.

Run with:
    python -m pytest tests/function_tests/test_factors.py -v
    python -m pytest tests/function_tests/test_factors.py -v --run-otp-validation
"""

import os

import pytest

from ibm_verify_sdk import (
    IbmVerifyClient,
    CreateEmailOtpResponse,
    CreatePhoneOtpResponse,
    GetFido2RegistrationsResponse,
    TransientVerifyEmailOtpResponse,
    TransientVerifyPhoneOtpResponse,
    VerifyEmailOtpResponse,
    VerifyPhoneOtpResponse,
)

TENANT_URL = os.environ.get("IBM_VERIFY_TENANT_URL", "")
ACCESS_TOKEN_ADMIN = os.environ.get("IBM_VERIFY_ACCESS_TOKEN_ADMIN", "")
USER_ID = os.environ.get("IBM_VERIFY_USER_ID", "")
EMAIL_ADDRESS = os.environ.get("IBM_VERIFY_EMAIL_ADDRESS", "")
PHONE_NUMBER = os.environ.get("IBM_VERIFY_PHONE_NUMBER", "")


@pytest.fixture(scope="module")
def admin_client():
    if not TENANT_URL or not ACCESS_TOKEN_ADMIN:
        pytest.skip("IBM_VERIFY_TENANT_URL and IBM_VERIFY_ACCESS_TOKEN_ADMIN must be set")
    c = IbmVerifyClient(
        tenant_url=TENANT_URL,
        access_token=ACCESS_TOKEN_ADMIN,
        versions={"factors": "v2.0"},
    )
    yield c
    c.close()


# --- Enrollment create/delete ---

def test_create_and_delete_email_otp(request, admin_client):
    if not USER_ID or not EMAIL_ADDRESS:
        pytest.skip("IBM_VERIFY_USER_ID and IBM_VERIFY_EMAIL_ADDRESS must be set")
    create = admin_client.factors.create_email_otp(
        user_id=USER_ID, email_address=EMAIL_ADDRESS, enabled=True,
    )
    assert create.status_code == 201
    assert isinstance(create.data, CreateEmailOtpResponse)
    assert create.data.id is not None
    verify = admin_client.factors.verify_email_otp(id=create.data.id)
    assert verify.status_code == 201
    assert verify.data.state == "PENDING"
    if request.config.getoption("--run-otp-validation"):
        with open("/dev/tty", "r+") as tty:
            tty.write(f"\nEnter OTP sent to {EMAIL_ADDRESS}: ")
            tty.flush()
            otp = tty.readline().strip()
        validate = admin_client.factors.validate_email_otp(id=create.data.id, trxn_id=verify.data.id, otp=otp)
        assert validate.status_code in (200, 204)
    delete = admin_client.factors.delete_email_otp(id=create.data.id)
    assert delete.status_code in (200, 204)


def test_create_and_delete_sms_otp(request, admin_client):
    if not USER_ID or not PHONE_NUMBER:
        pytest.skip("IBM_VERIFY_USER_ID and IBM_VERIFY_PHONE_NUMBER must be set")
    create = admin_client.factors.create_sms_otp(
        user_id=USER_ID, phone_number=PHONE_NUMBER, enabled=True,
    )
    assert create.status_code == 201
    assert isinstance(create.data, CreatePhoneOtpResponse)
    assert create.data.id is not None
    verify = admin_client.factors.verify_sms_otp(id=create.data.id)
    assert verify.status_code == 201
    assert verify.data.state == "PENDING"
    if request.config.getoption("--run-otp-validation"):
        with open("/dev/tty", "r+") as tty:
            tty.write(f"\nEnter OTP sent to {PHONE_NUMBER}: ")
            tty.flush()
            otp = tty.readline().strip()
        validate = admin_client.factors.validate_sms_otp(id=create.data.id, trxn_id=verify.data.id, otp=otp)
        assert validate.status_code in (200, 204)
    delete = admin_client.factors.delete_sms_otp(id=create.data.id)
    assert delete.status_code in (200, 204)


def test_create_and_delete_voice_otp(request, admin_client):
    if not USER_ID or not PHONE_NUMBER:
        pytest.skip("IBM_VERIFY_USER_ID and IBM_VERIFY_PHONE_NUMBER must be set")
    create = admin_client.factors.create_voice_otp(
        user_id=USER_ID, phone_number=PHONE_NUMBER, enabled=True,
    )
    assert create.status_code == 201
    assert isinstance(create.data, CreatePhoneOtpResponse)
    assert create.data.id is not None
    verify = admin_client.factors.verify_voice_otp(id=create.data.id)
    assert verify.status_code == 201
    assert verify.data.state == "PENDING"
    if request.config.getoption("--run-otp-validation"):
        with open("/dev/tty", "r+") as tty:
            tty.write(f"\nEnter OTP sent to {PHONE_NUMBER}: ")
            tty.flush()
            otp = tty.readline().strip()
        validate = admin_client.factors.validate_voice_otp(id=create.data.id, trxn_id=verify.data.id, otp=otp)
        assert validate.status_code in (200, 204)
    delete = admin_client.factors.delete_voice_otp(id=create.data.id)
    assert delete.status_code in (200, 204)


# --- Transient verification initiation (no OTP entry needed) ---

def test_transient_verify_email_otp_initiation(admin_client):
    if not EMAIL_ADDRESS:
        pytest.skip("IBM_VERIFY_EMAIL_ADDRESS must be set")
    response = admin_client.factors.transient_verify_email_otp(email_address=EMAIL_ADDRESS)
    assert response.status_code == 201
    assert isinstance(response.data, TransientVerifyEmailOtpResponse)
    assert response.data.id is not None
    assert response.data.state == "PENDING"


def test_transient_verify_sms_otp_initiation(admin_client):
    if not PHONE_NUMBER:
        pytest.skip("IBM_VERIFY_PHONE_NUMBER must be set")
    response = admin_client.factors.transient_verify_sms_otp(phone_number=PHONE_NUMBER)
    assert response.status_code == 201
    assert isinstance(response.data, TransientVerifyPhoneOtpResponse)
    assert response.data.id is not None
    assert response.data.state == "PENDING"


# --- Transient verification completion (interactive, requires --run-otp-validation) ---

def test_transient_verify_email_otp_full_flow(request, admin_client):
    if not request.config.getoption("--run-otp-validation"):
        pytest.skip("Pass --run-otp-validation to run interactive OTP tests")
    if not EMAIL_ADDRESS:
        pytest.skip("IBM_VERIFY_EMAIL_ADDRESS must be set")

    init = admin_client.factors.transient_verify_email_otp(email_address=EMAIL_ADDRESS)
    assert init.data.state == "PENDING"

    with open("/dev/tty", "r+") as tty:
        tty.write(f"\nEnter OTP sent to {EMAIL_ADDRESS}: ")
        tty.flush()
        otp = tty.readline().strip()
    result = admin_client.factors.validate_transient_email_otp(trxn_id=init.data.id, otp=otp)
    assert result.status_code in (200, 204)


def test_transient_verify_sms_otp_full_flow(request, admin_client):
    if not request.config.getoption("--run-otp-validation"):
        pytest.skip("Pass --run-otp-validation to run interactive OTP tests")
    if not PHONE_NUMBER:
        pytest.skip("IBM_VERIFY_PHONE_NUMBER must be set")

    init = admin_client.factors.transient_verify_sms_otp(phone_number=PHONE_NUMBER)
    assert init.data.state == "PENDING"

    with open("/dev/tty", "r+") as tty:
        tty.write(f"\nEnter OTP sent to {PHONE_NUMBER}: ")
        tty.flush()
        otp = tty.readline().strip()
    result = admin_client.factors.validate_transient_sms_otp(trxn_id=init.data.id, otp=otp)
    assert result.status_code in (200, 204)


# --- FIDO2 ---

def test_get_fido2_registrations(admin_client):
    response = admin_client.factors.get_fido2_registrations()
    assert response.status_code == 200
    assert isinstance(response.data, GetFido2RegistrationsResponse)
    assert response.data.fido2 is not None
