"""
Functional tests for the passwordpolicies module.

These tests make real API calls. Set environment variables before running:

    export IBM_VERIFY_TENANT_URL="https://your-tenant.verify.ibm.com"
    export IBM_VERIFY_ACCESS_TOKEN_ADMIN="your-admin-token"

Run with:
    python -m pytest tests/function_tests/test_passwordpolicies.py -v
"""

import os

import pytest

from ibm_verify_sdk import (
    IbmVerifyClient,
    GetPasswordPoliciesResponse,
    PasswordPolicy,
)

TENANT_URL = os.environ.get("IBM_VERIFY_TENANT_URL", "")
ACCESS_TOKEN_ADMIN = os.environ.get("IBM_VERIFY_ACCESS_TOKEN_ADMIN", "")


@pytest.fixture(scope="module")
def admin_client():
    if not TENANT_URL or not ACCESS_TOKEN_ADMIN:
        pytest.skip("IBM_VERIFY_TENANT_URL and IBM_VERIFY_ACCESS_TOKEN_ADMIN must be set")
    c = IbmVerifyClient(
        tenant_url=TENANT_URL,
        access_token=ACCESS_TOKEN_ADMIN,
        versions={"passwordpolicies": "v3.0"},
    )
    yield c
    c.close()


def test_get_password_policies(admin_client):
    response = admin_client.passwordpolicies.get_password_policies()
    assert response.status_code == 200
    assert isinstance(response.data, GetPasswordPoliciesResponse)
    assert response.data.Resources is not None
    assert len(response.data.Resources) > 0
    assert all(isinstance(p, PasswordPolicy) for p in response.data.Resources)
