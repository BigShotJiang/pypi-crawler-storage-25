"""
Functional tests for the authnmethods module.

These tests make real API calls. Set environment variables before running:

    export IBM_VERIFY_TENANT_URL="https://your-tenant.verify.ibm.com"
    export IBM_VERIFY_ACCESS_TOKEN_ADMIN="your-admin-token"
    export IBM_VERIFY_USERNAME="your-username"
    export IBM_VERIFY_PASSWORD="your-password"

Run with:
    python -m pytest tests/function_tests/test_authnmethods.py -v
"""

import os

import pytest

from ibm_verify_sdk import (
    IbmVerifyClient,
    AuthenticatePasswordResponse,
    GetPasswordMethodsResponse,
)

TENANT_URL = os.environ.get("IBM_VERIFY_TENANT_URL", "")
ACCESS_TOKEN_ADMIN = os.environ.get("IBM_VERIFY_ACCESS_TOKEN_ADMIN", "")
USERNAME = os.environ.get("IBM_VERIFY_USERNAME", "")
PASSWORD = os.environ.get("IBM_VERIFY_PASSWORD", "")


@pytest.fixture(scope="module")
def admin_client():
    if not TENANT_URL or not ACCESS_TOKEN_ADMIN:
        pytest.skip("IBM_VERIFY_TENANT_URL and IBM_VERIFY_ACCESS_TOKEN_ADMIN must be set")
    c = IbmVerifyClient(
        tenant_url=TENANT_URL,
        access_token=ACCESS_TOKEN_ADMIN,
    )
    yield c
    c.close()


@pytest.fixture(scope="module")
def cloud_directory_id(admin_client):
    response = admin_client.authnmethods.get_password_methods()
    assert response.status_code == 200
    methods = response.data.password or []
    match = next((m for m in methods if m.name.lower() == "cloud directory"), None)
    if match is None:
        pytest.skip("No 'Cloud Directory' identity source found")
    return match.id


def test_get_password_methods(admin_client):
    response = admin_client.authnmethods.get_password_methods()
    assert response.status_code == 200
    assert isinstance(response.data, GetPasswordMethodsResponse)
    assert response.data.password is not None


def test_get_password_methods_with_search(admin_client):
    response = admin_client.authnmethods.get_password_methods(search='name contains "Cloud"')
    assert response.status_code == 200
    assert isinstance(response.data, GetPasswordMethodsResponse)


def test_authenticate_password(admin_client, cloud_directory_id):
    if not USERNAME or not PASSWORD:
        pytest.skip("IBM_VERIFY_USERNAME and IBM_VERIFY_PASSWORD must be set")
    response = admin_client.authnmethods.authenticate_password(
        id=cloud_directory_id,
        username=USERNAME,
        password=PASSWORD,
    )
    assert response.status_code == 200
    assert isinstance(response.data, AuthenticatePasswordResponse)


def test_authenticate_password_with_jwt(admin_client, cloud_directory_id):
    if not USERNAME or not PASSWORD:
        pytest.skip("IBM_VERIFY_USERNAME and IBM_VERIFY_PASSWORD must be set")
    response = admin_client.authnmethods.authenticate_password(
        id=cloud_directory_id,
        username=USERNAME,
        password=PASSWORD,
        return_jwt=True,
    )
    assert response.status_code == 200
    assert isinstance(response.data, AuthenticatePasswordResponse)
    assert response.data.assertion is not None
    assert response.data.assertion is not None
