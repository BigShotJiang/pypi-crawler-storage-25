"""
Functional tests for the users module.

These tests make real API calls. Set environment variables before running:

    export IBM_VERIFY_TENANT_URL="https://your-tenant.verify.ibm.com"

    # Token with user-level permissions (e.g. delegated/user token)
    export IBM_VERIFY_ACCESS_TOKEN_USER="your-user-token"

    # Token with admin-level permissions
    export IBM_VERIFY_ACCESS_TOKEN_ADMIN="your-admin-token"

Run with:
    python -m pytest tests/function_tests/test_users.py -v
"""

import os

import pytest

from ibm_verify_sdk import IbmVerifyClient, GetAccountDetailsResponse, GetUsersResponse


TENANT_URL = os.environ.get("IBM_VERIFY_TENANT_URL", "")
ACCESS_TOKEN_USER = os.environ.get("IBM_VERIFY_ACCESS_TOKEN_USER", "")
ACCESS_TOKEN_ADMIN = os.environ.get("IBM_VERIFY_ACCESS_TOKEN_ADMIN", "")


@pytest.fixture(scope="module")
def user_client():
    if not TENANT_URL or not ACCESS_TOKEN_USER:
        pytest.skip("IBM_VERIFY_TENANT_URL and IBM_VERIFY_ACCESS_TOKEN_USER must be set")
    c = IbmVerifyClient(
        tenant_url=TENANT_URL,
        access_token=ACCESS_TOKEN_USER,
        versions={"users": "v2.0"},
    )
    yield c
    c.close()


@pytest.fixture(scope="module")
def admin_client():
    if not TENANT_URL or not ACCESS_TOKEN_ADMIN:
        pytest.skip("IBM_VERIFY_TENANT_URL and IBM_VERIFY_ACCESS_TOKEN_ADMIN must be set")
    c = IbmVerifyClient(
        tenant_url=TENANT_URL,
        access_token=ACCESS_TOKEN_ADMIN,
        versions={"users": "v2.0"},
    )
    yield c
    c.close()


def test_get_account_details_returns_model(user_client):
    response = user_client.users.get_account_details()
    assert response.status_code == 200
    assert isinstance(response.data, GetAccountDetailsResponse)
    assert response.data.id is not None
    assert response.data.userName is not None


def test_get_users_returns_model(admin_client):
    response = admin_client.users.get_users()
    assert response.status_code == 200
    assert isinstance(response.data, GetUsersResponse)
    assert response.data.totalResults is not None