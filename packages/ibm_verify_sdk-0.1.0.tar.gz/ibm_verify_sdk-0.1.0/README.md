# ibm-verify-sdk

A Python API client library for IBM Verify.

## Requirements

- Python 3.9+
- pip

## Installation

```bash
make venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
```

This creates a virtual environment, installs the package in editable mode, and installs `pytest` and `python-dotenv`.

## Quick start

```python
from ibm_verify_sdk import IbmVerifyClient

client = IbmVerifyClient(
    tenant_url="https://your-tenant.verify.ibm.com",
    access_token="your-access-token",
    versions={"users": "v2.0"},
)

response = client.users.get_account_details()
print(response.data.userName)

client.close()
```

## Available modules

| Module | Access | Version |
|---|---|---|
| `users` | `client.users` | `v1.0`, `v2.0` |
| `factors` | `client.factors` | `v1.0`, `v2.0` |
| `applications` | `client.applications` | `v1.0` |
| `authnmethods` | `client.authnmethods` | `v1.0` |
| `usc` | `client.usc` | `v1.0` |
| `password_policies` | `client.password_policies` | `v3.0` |

To use a specific version of a module, pass a `versions` dict when creating the client:

```python
client = IbmVerifyClient(
    tenant_url="https://your-tenant.verify.ibm.com",
    access_token="your-access-token",
    versions={
        "users": "v2.0",
        "factors": "v2.0",
    },
)
```

## Running the example script

```bash
python examples/client_examples.py
```

## Running the functional tests

Functional tests make real API calls and require credentials to be set in a `.env` file.

**First-time setup:**

```bash
make init_env
```

This copies `.env.example` to `.env`. Open `.env` and fill in your values:

```
IBM_VERIFY_TENANT_URL=https://your-tenant.verify.ibm.com
IBM_VERIFY_ACCESS_TOKEN_ADMIN=your-admin-token
IBM_VERIFY_ACCESS_TOKEN_USER=your-user-token
IBM_VERIFY_USER_ID=your-user-id
IBM_VERIFY_EMAIL_ADDRESS=user@example.com
IBM_VERIFY_PHONE_NUMBER=+15551234567
```

The `.env` file is ignored by git and loaded automatically when running tests.

**Run the tests:**

```bash
python -m pytest tests/function_tests/ -v
```

To run only the users tests:

```bash
python -m pytest tests/function_tests/test_users.py -v
```

If the environment variables are not set, all tests will be skipped automatically.
