from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, Optional, Type

from ibm_verify_sdk.models import ApiResponse

from .models import GetAccountDetailsResponse, GetUsersResponse, UpdateAccountDetailsRequest

if TYPE_CHECKING:
    from ibm_verify_sdk.client import IbmVerifyClient


class UsersModule:
    """Base class. Each version is a subclass registered via @UsersModule.register()."""

    DEFAULT_VERSION = "v1.0"
    _registry: Dict[str, Type[UsersModule]] = {}

    def __init__(self, client: IbmVerifyClient) -> None:
        self._client = client

    def _path(self, path: str) -> str:
        return f"/{self.DEFAULT_VERSION}{path}"

    @classmethod
    def register(cls, version: str):
        """Decorator to register a subclass for a given version string."""
        def decorator(subclass: Type[UsersModule]) -> Type[UsersModule]:
            cls._registry[version] = subclass
            return subclass
        return decorator

    @classmethod
    def create(cls, client: IbmVerifyClient, version: Optional[str] = None) -> UsersModule:
        """Return the correct version-specific module instance."""
        v = version or cls.DEFAULT_VERSION
        subclass = cls._registry.get(v)
        if subclass is None:
            raise ValueError(f"No UsersModule implementation for version '{v}'")
        return subclass(client)


@UsersModule.register("v1.0")
class UsersModuleV1(UsersModule):
    DEFAULT_VERSION = "v1.0"


@UsersModule.register("v2.0")
class UsersModuleV2(UsersModule):
    DEFAULT_VERSION = "v2.0"

    def get_account_details(self) -> ApiResponse[GetAccountDetailsResponse]:
        """Retrieves the account details of the authenticated user in Cloud Directory."""
        return self._client._request("GET", self._path("/Me"), model=GetAccountDetailsResponse, accept="application/scim+json")

    def update_account_details(self, *, body: UpdateAccountDetailsRequest) -> ApiResponse[GetAccountDetailsResponse]:
        """Replaces the authenticated user's attributes in Cloud Directory."""
        return self._client._request(
            "PUT", self._path("/Me"), model=GetAccountDetailsResponse,
            json=body.model_dump(by_alias=True, exclude_none=True),
            accept="application/scim+json",
        )

    def get_users(self) -> ApiResponse[GetUsersResponse]:
        """Retrieves a list of users that belong to a specified tenant."""
        return self._client._request("GET", self._path("/Users"), model=GetUsersResponse, accept="application/scim+json")
