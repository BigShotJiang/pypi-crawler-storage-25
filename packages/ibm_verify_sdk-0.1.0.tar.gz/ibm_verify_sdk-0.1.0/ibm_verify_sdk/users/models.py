from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field


class GetUsersResponse(BaseModel):
    schemas: Optional[List[str]] = None
    totalResults: Optional[int] = None
    startIndex: Optional[int] = None
    itemsPerPage: Optional[int] = None
    Resources: Optional[List[GetAccountDetailsResponse]] = None


class UserMeta(BaseModel):
    resourceType: Optional[str] = None
    created: Optional[str] = None
    lastModified: Optional[str] = None
    location: Optional[str] = None
    deactivated: Optional[str] = None


class UserName(BaseModel):
    formatted: Optional[str] = None
    familyName: Optional[str] = None
    givenName: Optional[str] = None
    middleName: Optional[str] = None


class UserEmail(BaseModel):
    value: Optional[str] = None
    type: Optional[str] = None


class UserAddress(BaseModel):
    locality: Optional[str] = None
    country: Optional[str] = None
    type: Optional[str] = None
    streetAddress: Optional[str] = None
    postalCode: Optional[str] = None
    formatted: Optional[str] = None
    primary: Optional[bool] = None
    region: Optional[str] = None


class UserPhoneNumber(BaseModel):
    value: Optional[str] = None
    type: Optional[str] = None


class UserGroup(BaseModel):
    displayName: Optional[str] = None
    id: Optional[str] = None
    value: Optional[str] = None
    ref: Optional[str] = Field(None, alias="$ref")


class CustomAttribute(BaseModel):
    name: Optional[str] = None
    values: Optional[List[str]] = None


class LinkedAccount(BaseModel):
    externalId: Optional[str] = None
    realm: Optional[str] = None


class LastMFA(BaseModel):
    type: Optional[str] = None
    value: Optional[str] = None


class AttachedPasswordPolicy(BaseModel):
    value: Optional[str] = None
    ref: Optional[str] = Field(None, alias="$ref")
    name: Optional[str] = None


class IbmUserExtension(BaseModel):
    userCategory: Optional[str] = None
    emailVerified: Optional[str] = None
    realm: Optional[str] = None
    unqualifiedUserName: Optional[str] = None
    twoFactorAuthentication: Optional[bool] = None
    pwdReset: Optional[bool] = None
    pwdChangedTime: Optional[str] = None
    pwdAccountLockedTime: Optional[str] = None
    pwdExpirationWarned: Optional[str] = None
    pwdFailureTime: Optional[List[str]] = None
    pwdGraceUseTime: Optional[List[str]] = None
    delegate: Optional[str] = None
    customAttributes: Optional[List[CustomAttribute]] = None
    linkedAccounts: Optional[List[LinkedAccount]] = None
    lastLogin: Optional[str] = None
    lastLoginType: Optional[str] = None
    lastLoginRealm: Optional[str] = None
    lastMFA: Optional[List[LastMFA]] = None
    accountExpires: Optional[str] = None
    attachedPasswordPolicy: Optional[AttachedPasswordPolicy] = None


class EnterpriseUserManager(BaseModel):
    value: Optional[str] = None
    ref: Optional[str] = Field(None, alias="$ref")
    displayName: Optional[str] = None


class EnterpriseUserExtension(BaseModel):
    department: Optional[str] = None
    employeeNumber: Optional[str] = None
    manager: Optional[EnterpriseUserManager] = None


class NotificationExtension(BaseModel):
    notifyType: Optional[str] = None


class UpdateAccountDetailsRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    schemas: List[str]
    userName: str
    externalId: Optional[str] = None
    title: Optional[str] = None
    password: Optional[str] = None
    name: Optional[UserName] = None
    displayName: Optional[str] = None
    preferredLanguage: Optional[str] = None
    active: Optional[bool] = None
    emails: Optional[List[UserEmail]] = None
    addresses: Optional[List[UserAddress]] = None
    phoneNumbers: Optional[List[UserPhoneNumber]] = None
    ibm_extension: Optional[IbmUserExtension] = Field(
        None, alias="urn:ietf:params:scim:schemas:extension:ibm:2.0:User"
    )
    enterprise_extension: Optional[EnterpriseUserExtension] = Field(
        None, alias="urn:ietf:params:scim:schemas:extension:enterprise:2.0:User"
    )
    notification_extension: Optional[NotificationExtension] = Field(
        None, alias="urn:ietf:params:scim:schemas:extension:ibm:2.0:Notification"
    )


class GetAccountDetailsResponse(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    schemas: Optional[List[str]] = None
    id: Optional[str] = None
    externalId: Optional[str] = None
    meta: Optional[UserMeta] = None
    userName: Optional[str] = None
    title: Optional[str] = None
    name: Optional[UserName] = None
    displayName: Optional[str] = None
    preferredLanguage: Optional[str] = None
    active: Optional[bool] = None
    emails: Optional[List[UserEmail]] = None
    addresses: Optional[List[UserAddress]] = None
    phoneNumbers: Optional[List[UserPhoneNumber]] = None
    groups: Optional[List[UserGroup]] = None
    ibm_extension: Optional[IbmUserExtension] = Field(
        None, alias="urn:ietf:params:scim:schemas:extension:ibm:2.0:User"
    )
    enterprise_extension: Optional[EnterpriseUserExtension] = Field(
        None, alias="urn:ietf:params:scim:schemas:extension:enterprise:2.0:User"
    )
