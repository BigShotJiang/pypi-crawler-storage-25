from __future__ import annotations

from typing import TYPE_CHECKING, Dict, Optional, Type

from ibm_verify_sdk.models import ApiResponse

from .models import GetPasswordPoliciesResponse

if TYPE_CHECKING:
    from ibm_verify_sdk.client import IbmVerifyClient


class PasswordPoliciesModule:
    """Base class. Each version is a subclass registered via @PasswordPoliciesModule.register()."""

    DEFAULT_VERSION = "v3.0"
    _registry: Dict[str, Type[PasswordPoliciesModule]] = {}

    def __init__(self, client: IbmVerifyClient) -> None:
        self._client = client

    def _path(self, path: str) -> str:
        return f"/{self.DEFAULT_VERSION}{path}"

    @classmethod
    def register(cls, version: str):
        """Decorator to register a subclass for a given version string."""
        def decorator(subclass: Type[PasswordPoliciesModule]) -> Type[PasswordPoliciesModule]:
            cls._registry[version] = subclass
            return subclass
        return decorator

    @classmethod
    def create(cls, client: IbmVerifyClient, version: Optional[str] = None) -> PasswordPoliciesModule:
        """Return the correct version-specific module instance."""
        v = version or cls.DEFAULT_VERSION
        subclass = cls._registry.get(v)
        if subclass is None:
            raise ValueError(f"No PasswordPoliciesModule implementation for version '{v}'")
        return subclass(client)


@PasswordPoliciesModule.register("v3.0")
class PasswordPoliciesModuleV3(PasswordPoliciesModule):
    DEFAULT_VERSION = "v3.0"

    def get_password_policies(self) -> ApiResponse[GetPasswordPoliciesResponse]:
        """Retrieve the list of password policies for the tenant."""
        return self._client._request(
            "GET",
            self._path("/PasswordPolicies"),
            model=GetPasswordPoliciesResponse,
            accept="application/scim+json",
        )
