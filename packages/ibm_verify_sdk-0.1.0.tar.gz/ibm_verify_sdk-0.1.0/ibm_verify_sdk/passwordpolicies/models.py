from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel


class PasswordStrength(BaseModel):
    pwdMinLength: Optional[int] = None
    passwordMaxConsecutiveRepeatedChars: Optional[int] = None
    passwordMaxRepeatedChars: Optional[int] = None
    passwordMinAlphaChars: Optional[int] = None
    passwordMinDiffChars: Optional[int] = None
    passwordMinOtherChars: Optional[int] = None
    passwordMinLowerCaseChars: Optional[int] = None
    passwordMinUpperCaseChars: Optional[int] = None
    passwordMinNumberChars: Optional[int] = None
    passwordMinSpecialChars: Optional[int] = None


class PasswordSecurity(BaseModel):
    pwdMinAge: Optional[int] = None
    pwdExpireWarning: Optional[int] = None
    pwdInHistory: Optional[int] = None
    pwdLockout: Optional[bool] = None
    pwdLockoutDuration: Optional[int] = None
    pwdMaxAge: Optional[int] = None
    pwdMaxFailure: Optional[int] = None


class PasswordPolicy(BaseModel):
    id: Optional[str] = None
    name: Optional[str] = None
    description: Optional[str] = None
    predefined: Optional[bool] = None
    passwordStrength: Optional[PasswordStrength] = None
    passwordSecurity: Optional[PasswordSecurity] = None


class GetPasswordPoliciesResponse(BaseModel):
    totalMembers: Optional[int] = None
    Resources: Optional[List[PasswordPolicy]] = None
