from __future__ import annotations

from datetime import datetime
from typing import Dict, List, Optional

from pydantic import BaseModel


class EmailOtpAttributes(BaseModel):
    emailAddress: str


class PhoneOtpAttributes(BaseModel):
    phoneNumber: str


class CreateEmailOtpResponse(BaseModel):
    id: str
    userId: str
    type: str
    created: datetime
    updated: datetime
    attempted: Optional[datetime] = None
    enabled: bool
    validated: bool
    attributes: EmailOtpAttributes


class CreatePhoneOtpResponse(BaseModel):
    id: str
    userId: str
    type: str
    created: datetime
    updated: datetime
    attempted: Optional[datetime] = None
    enabled: bool
    validated: bool
    attributes: PhoneOtpAttributes


class VerifyEmailOtpResponse(BaseModel):
    id: str
    userId: str
    type: str
    created: datetime
    updated: datetime
    expiry: datetime
    state: str
    updatedBy: Optional[str] = None
    correlation: str
    emailAddress: str
    attempts: int
    retries: int


class VerifyPhoneOtpResponse(BaseModel):
    id: str
    userId: str
    type: str
    created: datetime
    updated: datetime
    expiry: datetime
    state: str
    updatedBy: Optional[str] = None
    correlation: str
    phoneNumber: str
    attempts: int
    retries: int


class TransientVerifyEmailOtpResponse(BaseModel):
    id: str
    type: str
    created: datetime
    updated: datetime
    expiry: datetime
    state: str
    updatedBy: Optional[str] = None
    correlation: str
    emailAddress: str
    attempts: int
    retries: int


class TransientVerifyPhoneOtpResponse(BaseModel):
    id: str
    type: str
    created: datetime
    updated: datetime
    expiry: datetime
    state: str
    updatedBy: Optional[str] = None
    correlation: str
    phoneNumber: str
    attempts: int
    retries: int


class Fido2Attributes(BaseModel):
    attestationType: Optional[str] = None
    attestationFormat: Optional[str] = None
    nickname: Optional[str] = None
    aaGuid: Optional[str] = None
    userVerified: Optional[bool] = None
    userPresent: Optional[bool] = None
    icon: Optional[str] = None
    description: Optional[str] = None
    credentialId: Optional[str] = None
    credentialPublicKey: Optional[str] = None
    rpId: Optional[str] = None
    counter: Optional[int] = None
    transports: Optional[List[str]] = None
    x5c: Optional[List[str]] = None
    backupEligibility: Optional[bool] = None
    backupState: Optional[bool] = None


class Fido2References(BaseModel):
    rpUuid: Optional[str] = None


class Fido2Registration(BaseModel):
    id: str
    userId: str
    type: str
    created: datetime
    updated: datetime
    attempted: Optional[datetime] = None
    enabled: bool
    validated: bool
    attributes: Fido2Attributes
    references: Optional[Fido2References] = None
    assertion: Optional[str] = None


class GetFido2RegistrationsResponse(BaseModel):
    fido2: List[Fido2Registration]


class UpdateFido2RegistrationAttributes(BaseModel):
    transports: Optional[List[str]] = None
    x5c: Optional[List[str]] = None


class UpdateFido2RegistrationRequest(BaseModel):
    enabled: bool
    attributes: UpdateFido2RegistrationAttributes
    references: str


class Fido2RelyingPartyMetadataConfig(BaseModel):
    enforcement: Optional[bool] = None
    includeAll: Optional[bool] = None
    includedMetadata: Optional[List[str]] = None
    includedMetadataServices: Optional[List[str]] = None


class Fido2PubKeyCredParam(BaseModel):
    alg: int
    type: str


class Fido2RelyingParty(BaseModel):
    id: str
    rpId: str
    origins: Optional[List[str]] = None
    name: Optional[str] = None
    allowedAttestationFormats: Optional[List[str]] = None
    allowedAttestationTypes: Optional[List[str]] = None
    metadataConfig: Optional[Fido2RelyingPartyMetadataConfig] = None
    attestationCredProtect: Optional[str] = None
    pubKeyCredParams: Optional[List[Fido2PubKeyCredParam]] = None
    enabled: Optional[bool] = None
    webAuthn: Optional[bool] = None


class GetFido2RelyingPartiesResponse(BaseModel):
    relyingparties: List[Fido2RelyingParty]


class Fido2AllowCredential(BaseModel):
    id: str
    type: str


class Fido2ExtensionValue(BaseModel):
    valueType: str


class Fido2AssertionOptionsResponse(BaseModel):
    rpId: str
    timeout: int
    challenge: str
    allowCredentials: List[Fido2AllowCredential]
    userVerification: str
    extensions: Optional[Dict[str, Fido2ExtensionValue]] = None
