from __future__ import annotations

from typing import TYPE_CHECKING, Dict, Optional, Type

from ibm_verify_sdk.models import ApiResponse

from .models import (
    CreateEmailOtpResponse,
    CreatePhoneOtpResponse,
    Fido2AssertionOptionsResponse,
    Fido2Registration,
    GetFido2RelyingPartiesResponse,
    GetFido2RegistrationsResponse,
    TransientVerifyEmailOtpResponse,
    TransientVerifyPhoneOtpResponse,
    UpdateFido2RegistrationAttributes,
    VerifyEmailOtpResponse,
    VerifyPhoneOtpResponse,
)

if TYPE_CHECKING:
    from ibm_verify_sdk.client import IbmVerifyClient


class FactorsModule:
    """Base class. Each version is a subclass registered via @FactorsModule.register()."""

    DEFAULT_VERSION = "v1.0"
    _registry: Dict[str, Type[FactorsModule]] = {}

    def __init__(self, client: IbmVerifyClient) -> None:
        self._client = client

    def _path(self, path: str) -> str:
        return f"/{self.DEFAULT_VERSION}{path}"

    @classmethod
    def register(cls, version: str):
        """Decorator to register a subclass for a given version string."""
        def decorator(subclass: Type[FactorsModule]) -> Type[FactorsModule]:
            cls._registry[version] = subclass
            return subclass
        return decorator

    @classmethod
    def create(cls, client: IbmVerifyClient, version: Optional[str] = None) -> FactorsModule:
        """Return the correct version-specific module instance."""
        v = version or cls.DEFAULT_VERSION
        subclass = cls._registry.get(v)
        if subclass is None:
            raise ValueError(f"No FactorsModule implementation for version '{v}'")
        return subclass(client)


@FactorsModule.register("v1.0")
class FactorsModuleV1(FactorsModule):
    DEFAULT_VERSION = "v1.0"


@FactorsModule.register("v2.0")
class FactorsModuleV2(FactorsModule):
    DEFAULT_VERSION = "v2.0"

    def create_email_otp(
        self,
        *,
        user_id: str,
        email_address: str,
        enabled: bool,
    ) -> ApiResponse[CreateEmailOtpResponse]:
        """Enroll an email OTP factor for a user."""
        return self._client._request(
            "POST", self._path("/factors/emailotp"), model=CreateEmailOtpResponse,
            json={"userId": user_id, "emailAddress": email_address, "enabled": enabled},
        )

    def create_sms_otp(
        self,
        *,
        user_id: str,
        phone_number: str,
        enabled: bool,
    ) -> ApiResponse[CreatePhoneOtpResponse]:
        """Enroll an SMS OTP factor for a user."""
        return self._client._request(
            "POST", self._path("/factors/smsotp"), model=CreatePhoneOtpResponse,
            json={"userId": user_id, "phoneNumber": phone_number, "enabled": enabled},
        )

    def create_voice_otp(
        self,
        *,
        user_id: str,
        phone_number: str,
        enabled: bool,
    ) -> ApiResponse[CreatePhoneOtpResponse]:
        """Enroll a voice OTP factor for a user."""
        return self._client._request(
            "POST", self._path("/factors/voiceotp"), model=CreatePhoneOtpResponse,
            json={"userId": user_id, "phoneNumber": phone_number, "enabled": enabled},
        )

    def delete_email_otp(self, *, id: str) -> ApiResponse[None]:
        """Delete an email OTP enrollment."""
        return self._client._request("DELETE", self._path(f"/factors/emailotp/{id}"))

    def delete_sms_otp(self, *, id: str) -> ApiResponse[None]:
        """Delete an SMS OTP enrollment."""
        return self._client._request("DELETE", self._path(f"/factors/smsotp/{id}"))

    def delete_voice_otp(self, *, id: str) -> ApiResponse[None]:
        """Delete a voice OTP enrollment."""
        return self._client._request("DELETE", self._path(f"/factors/voiceotp/{id}"))

    def verify_email_otp(self, *, id: str) -> ApiResponse[VerifyEmailOtpResponse]:
        """Initiate a verification for an email OTP enrollment."""
        return self._client._request(
            "POST", self._path(f"/factors/emailotp/{id}/verifications"), model=VerifyEmailOtpResponse
        )

    def verify_sms_otp(self, *, id: str) -> ApiResponse[VerifyPhoneOtpResponse]:
        """Initiate a verification for an SMS OTP enrollment."""
        return self._client._request(
            "POST", self._path(f"/factors/smsotp/{id}/verifications"), model=VerifyPhoneOtpResponse
        )

    def verify_voice_otp(self, *, id: str) -> ApiResponse[VerifyPhoneOtpResponse]:
        """Initiate a verification for a voice OTP enrollment."""
        return self._client._request(
            "POST", self._path(f"/factors/voiceotp/{id}/verifications"), model=VerifyPhoneOtpResponse
        )

    def validate_email_otp(self, *, id: str, trxn_id: str, otp: str) -> ApiResponse[None]:
        """Submit the OTP code to complete a verification for an email OTP enrollment."""
        return self._client._request(
            "POST",
            self._path(f"/factors/emailotp/{id}/verifications/{trxn_id}"),
            json={"otp": otp},
        )

    def validate_sms_otp(self, *, id: str, trxn_id: str, otp: str) -> ApiResponse[None]:
        """Submit the OTP code to complete a verification for an SMS OTP enrollment."""
        return self._client._request(
            "POST",
            self._path(f"/factors/smsotp/{id}/verifications/{trxn_id}"),
            json={"otp": otp},
        )

    def validate_voice_otp(self, *, id: str, trxn_id: str, otp: str) -> ApiResponse[None]:
        """Submit the OTP code to complete a verification for a voice OTP enrollment."""
        return self._client._request(
            "POST",
            self._path(f"/factors/voiceotp/{id}/verifications/{trxn_id}"),
            json={"otp": otp},
        )

    def transient_verify_email_otp(
        self,
        *,
        email_address: str,
    ) -> ApiResponse[TransientVerifyEmailOtpResponse]:
        """Initiate a transient email OTP verification (no prior enrollment required)."""
        return self._client._request(
            "POST",
            self._path("/factors/emailotp/transient/verifications"),
            model=TransientVerifyEmailOtpResponse,
            json={"emailAddress": email_address},
        )

    def transient_verify_sms_otp(
        self,
        *,
        phone_number: str,
    ) -> ApiResponse[TransientVerifyPhoneOtpResponse]:
        """Initiate a transient SMS OTP verification (no prior enrollment required)."""
        return self._client._request(
            "POST",
            self._path("/factors/smsotp/transient/verifications"),
            model=TransientVerifyPhoneOtpResponse,
            json={"phoneNumber": phone_number},
        )

    def transient_verify_voice_otp(
        self,
        *,
        phone_number: str,
    ) -> ApiResponse[TransientVerifyPhoneOtpResponse]:
        """Initiate a transient voice OTP verification (no prior enrollment required)."""
        return self._client._request(
            "POST",
            self._path("/factors/voiceotp/transient/verifications"),
            model=TransientVerifyPhoneOtpResponse,
            json={"phoneNumber": phone_number},
        )

    def get_transient_email_otp_verification(self, *, trxn_id: str) -> ApiResponse[TransientVerifyEmailOtpResponse]:
        """Retrieve the state of a transient email OTP verification by transaction ID."""
        return self._client._request(
            "GET",
            self._path(f"/factors/emailotp/transient/verifications/{trxn_id}"),
            model=TransientVerifyEmailOtpResponse,
        )

    def get_transient_sms_otp_verification(self, *, trxn_id: str) -> ApiResponse[TransientVerifyPhoneOtpResponse]:
        """Retrieve the state of a transient SMS OTP verification by transaction ID."""
        return self._client._request(
            "GET",
            self._path(f"/factors/smsotp/transient/verifications/{trxn_id}"),
            model=TransientVerifyPhoneOtpResponse,
        )

    def get_transient_voice_otp_verification(self, *, trxn_id: str) -> ApiResponse[TransientVerifyPhoneOtpResponse]:
        """Retrieve the state of a transient voice OTP verification by transaction ID."""
        return self._client._request(
            "GET",
            self._path(f"/factors/voiceotp/transient/verifications/{trxn_id}"),
            model=TransientVerifyPhoneOtpResponse,
        )

    def validate_transient_email_otp(self, *, trxn_id: str, otp: str) -> ApiResponse[None]:
        """Submit the OTP code to complete a transient email OTP verification."""
        return self._client._request(
            "POST",
            self._path(f"/factors/emailotp/transient/verifications/{trxn_id}"),
            json={"otp": otp},
        )

    def validate_transient_sms_otp(self, *, trxn_id: str, otp: str) -> ApiResponse[None]:
        """Submit the OTP code to complete a transient SMS OTP verification."""
        return self._client._request(
            "POST",
            self._path(f"/factors/smsotp/transient/verifications/{trxn_id}"),
            json={"otp": otp},
        )

    def validate_transient_voice_otp(self, *, trxn_id: str, otp: str) -> ApiResponse[None]:
        """Submit the OTP code to complete a transient voice OTP verification."""
        return self._client._request(
            "POST",
            self._path(f"/factors/voiceotp/transient/verifications/{trxn_id}"),
            json={"otp": otp},
        )

    def get_fido2_registrations(self) -> ApiResponse[GetFido2RegistrationsResponse]:
        """Retrieve all FIDO2 registrations for the authenticated user."""
        return self._client._request(
            "GET",
            self._path("/factors/fido2/registrations"),
            model=GetFido2RegistrationsResponse,
        )

    def get_fido2_registration(self, *, id: str) -> ApiResponse[Fido2Registration]:
        """Retrieve a single FIDO2 registration by ID."""
        return self._client._request(
            "GET",
            self._path(f"/factors/fido2/registrations/{id}"),
            model=Fido2Registration,
        )

    def update_fido2_registration(
        self,
        *,
        id: str,
        enabled: bool,
        attributes: UpdateFido2RegistrationAttributes,
        references: str,
    ) -> ApiResponse[Fido2Registration]:
        """Update an existing FIDO2 registration."""
        return self._client._request(
            "PUT",
            self._path(f"/factors/fido2/registrations/{id}"),
            model=Fido2Registration,
            json={
                "enabled": enabled,
                "attributes": attributes.model_dump(exclude_none=True),
                "references": references,
            },
        )

    def delete_fido2_registration(self, *, id: str) -> ApiResponse[None]:
        """Delete a FIDO2 registration by ID."""
        return self._client._request(
            "DELETE",
            self._path(f"/factors/fido2/registrations/{id}"),
        )

    def get_fido2_relying_parties(self) -> ApiResponse[GetFido2RelyingPartiesResponse]:
        """Retrieve all FIDO2 relying parties."""
        return self._client._request(
            "GET",
            self._path("/factors/fido2/relyingparties"),
            model=GetFido2RelyingPartiesResponse,
        )

    def get_fido2_assertion_options(
        self,
        *,
        id: str,
        user_id: str,
        user_verification: str,
    ) -> ApiResponse[Fido2AssertionOptionsResponse]:
        """Retrieve FIDO2 assertion options for a relying party."""
        return self._client._request(
            "POST",
            self._path(f"/factors/fido2/relyingparties/{id}/assertion/options"),
            model=Fido2AssertionOptionsResponse,
            json={"userId": user_id, "userVerification": user_verification},
        )
