from __future__ import annotations

from typing import Any, Dict, Optional, Type, TypeVar

import requests

from .applications import ApplicationsModule
from .authnmethods import AuthnMethodsModule
from .factors import FactorsModule
from .models import ApiResponse
from .passwordpolicies import PasswordPoliciesModule
from .usc import UscModule
from .users import UsersModule

T = TypeVar("T")


class APIClientError(Exception):
    """Raised when an API call fails."""


class IbmVerifyClient:
    def __init__(
        self,
        tenant_url: str,
        access_token: str,
        timeout: float = 30.0,
        versions: Optional[Dict[str, str]] = None,
    ) -> None:
        self.tenant_url = tenant_url.rstrip("/")
        self.access_token = access_token
        self.timeout = timeout
        self.session = requests.Session()

        headers: Dict[str, str] = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": f"Bearer {access_token}",
        }

        self.session.headers.update(headers)

        _versions = versions or {}
        self.applications = ApplicationsModule.create(self, version=_versions.get("applications"))
        self.users = UsersModule.create(self, version=_versions.get("users"))
        self.factors = FactorsModule.create(self, version=_versions.get("factors"))
        self.usc = UscModule.create(self, version=_versions.get("usc"))
        self.authnmethods = AuthnMethodsModule.create(self, version=_versions.get("authnmethods"))
        self.passwordpolicies = PasswordPoliciesModule.create(self, version=_versions.get("passwordpolicies"))

    def close(self) -> None:
        self.session.close()

    def _request(
        self,
        method: str,
        path: str,
        *,
        model: Optional[Type[T]] = None,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        accept: Optional[str] = None,
    ) -> ApiResponse:
        url = f"{self.tenant_url}{path}"
        headers = {"Accept": accept} if accept else {}
        try:
            response = self.session.request(
                method=method,
                url=url,
                json=json,
                params=params,
                headers=headers,
                timeout=self.timeout,
            )
            response.raise_for_status()
        except requests.RequestException as exc:
            raise APIClientError(f"{method} {url} failed: {exc}") from exc

        if not response.content:
            raw = None
        elif "json" in response.headers.get("Content-Type", ""):
            raw = response.json()
        else:
            raw = response.text

        data = model.model_validate(raw) if model and raw is not None else raw
        return ApiResponse(
            status_code=response.status_code, 
            headers=dict(response.headers), 
            raw=raw,
            data=data
        )
