from __future__ import annotations

from typing import List, Literal, Optional

from pydantic import BaseModel


PasswordMethodType = Literal["maasconnect", "ibmldap", "onpremldap"]


class PasswordMethod(BaseModel):
    id: str
    name: str
    type: PasswordMethodType
    location: str


class GetPasswordMethodsResponse(BaseModel):
    password: Optional[List[PasswordMethod]] = None


class AuthenticatePasswordAttribute(BaseModel):
    name: str
    values: List[str]


class AuthenticatePasswordGroup(BaseModel):
    name: Optional[str] = None
    displayName: Optional[str] = None
    sourceId: Optional[str] = None


class AuthenticatePasswordResponse(BaseModel):
    id: Optional[str] = None
    attributes: Optional[List[AuthenticatePasswordAttribute]] = None
    groups: Optional[List[AuthenticatePasswordGroup]] = None
    assertion: Optional[str] = None
