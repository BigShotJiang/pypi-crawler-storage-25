from __future__ import annotations

from typing import TYPE_CHECKING, Dict, Optional, Type

from ibm_verify_sdk.models import ApiResponse

from .models import AuthenticatePasswordResponse, GetPasswordMethodsResponse

if TYPE_CHECKING:
    from ibm_verify_sdk.client import IbmVerifyClient


class AuthnMethodsModule:
    """Base class. Each version is a subclass registered via @AuthnMethodsModule.register()."""

    DEFAULT_VERSION = "v1.0"
    _registry: Dict[str, Type[AuthnMethodsModule]] = {}

    def __init__(self, client: IbmVerifyClient) -> None:
        self._client = client

    def _path(self, path: str) -> str:
        return f"/{self.DEFAULT_VERSION}{path}"

    @classmethod
    def register(cls, version: str):
        """Decorator to register a subclass for a given version string."""
        def decorator(subclass: Type[AuthnMethodsModule]) -> Type[AuthnMethodsModule]:
            cls._registry[version] = subclass
            return subclass
        return decorator

    @classmethod
    def create(cls, client: IbmVerifyClient, version: Optional[str] = None) -> AuthnMethodsModule:
        """Return the correct version-specific module instance."""
        v = version or cls.DEFAULT_VERSION
        subclass = cls._registry.get(v)
        if subclass is None:
            raise ValueError(f"No AuthnMethodsModule implementation for version '{v}'")
        return subclass(client)


@AuthnMethodsModule.register("v1.0")
class AuthnMethodsModuleV1(AuthnMethodsModule):
    DEFAULT_VERSION = "v1.0"

    def get_password_methods(self, *, search: Optional[str] = None) -> ApiResponse[GetPasswordMethodsResponse]:
        """Retrieve the list of valid password-based identity sources."""
        return self._client._request(
            "GET",
            self._path("/authnmethods/password"),
            model=GetPasswordMethodsResponse,
            params={"search": search} if search is not None else None,
        )

    def authenticate_password(
        self,
        *,
        id: str,
        username: str,
        password: str,
        return_jwt: Optional[bool] = None,
    ) -> ApiResponse[AuthenticatePasswordResponse]:
        """Authenticate a username and password against an identity source."""
        params = {"returnJwt": str(return_jwt).lower()} if return_jwt is not None else None
        return self._client._request(
            "POST",
            self._path(f"/authnmethods/password/{id}"),
            model=AuthenticatePasswordResponse,
            json={"username": username, "password": password},
            params=params,
        )
