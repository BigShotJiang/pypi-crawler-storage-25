from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Generic, Optional, TypeVar

from pydantic import BaseModel

T = TypeVar("T")


class ApiResponse(BaseModel, Generic[T]):
    """Standard envelope returned by all public module methods."""
    status_code: int
    headers: Dict[str, str]
    data: Optional[T]
    raw: Optional[Any]

