from __future__ import annotations

from typing import List, Literal, Optional

from pydantic import BaseModel


UscPasswordResetMethod = Literal[
    "emailLink", "emailotp", "smsotp", "voiceotp", "totp", "fingerprint", "userpresence"
]


class UscPasswordResetStepData(BaseModel):
    correlation: Optional[str] = None
    baseVerificationUrl: Optional[str] = None
    targetUrl: Optional[str] = None
    enrollmentId: Optional[str] = None
    transientValue: Optional[str] = None


class UscPasswordResetStep(BaseModel):
    method: Optional[UscPasswordResetMethod] = None
    data: Optional[UscPasswordResetStepData] = None


class InitiatePasswordResetRequest(BaseModel):
    userName: str
    steps: List[UscPasswordResetStep]
    stateId: Optional[str] = None


class UscPasswordResetNextStep(BaseModel):
    methodType: Optional[str] = None
    method: Optional[UscPasswordResetMethod] = None
    httpMethod: Optional[str] = None
    creationTime: Optional[str] = None
    expiryTime: Optional[str] = None
    uri: Optional[str] = None


class InitiatePasswordResetResponse(BaseModel):
    trxId: Optional[str] = None
    stepsRemaining: Optional[int] = None
    nextStep: Optional[UscPasswordResetNextStep] = None


class CompletePasswordResetRequest(BaseModel):
    password: str
    otp: Optional[str] = None


class CompletePasswordResetResponse(BaseModel):
    userId: Optional[str] = None
    stateId: Optional[str] = None


class ValidatePasswordResetRequest(BaseModel):
    otp: str


class ValidatePasswordResetResponse(BaseModel):
    trxId: Optional[str] = None
    stepsRemaining: Optional[int] = None
    nextStep: Optional[UscPasswordResetNextStep] = None
    userId: Optional[str] = None
