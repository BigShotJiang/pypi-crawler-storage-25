from __future__ import annotations

from typing import TYPE_CHECKING, Dict, List, Optional, Type

from ibm_verify_sdk.models import ApiResponse

from .models import CompletePasswordResetResponse, InitiatePasswordResetResponse, UscPasswordResetStep, ValidatePasswordResetResponse

if TYPE_CHECKING:
    from ibm_verify_sdk.client import IbmVerifyClient


class UscModule:
    """Base class. Each version is a subclass registered via @UscModule.register()."""

    DEFAULT_VERSION = "v1.0"
    _registry: Dict[str, Type[UscModule]] = {}

    def __init__(self, client: IbmVerifyClient) -> None:
        self._client = client

    def _path(self, path: str) -> str:
        return f"/{self.DEFAULT_VERSION}{path}"

    @classmethod
    def register(cls, version: str):
        """Decorator to register a subclass for a given version string."""
        def decorator(subclass: Type[UscModule]) -> Type[UscModule]:
            cls._registry[version] = subclass
            return subclass
        return decorator

    @classmethod
    def create(cls, client: IbmVerifyClient, version: Optional[str] = None) -> UscModule:
        """Return the correct version-specific module instance."""
        v = version or cls.DEFAULT_VERSION
        subclass = cls._registry.get(v)
        if subclass is None:
            raise ValueError(f"No UscModule implementation for version '{v}'")
        return subclass(client)


@UscModule.register("v1.0")
class UscModuleV1(UscModule):
    DEFAULT_VERSION = "v1.0"

    def initiate_password_reset(
        self,
        *,
        user_name: str,
        steps: List[UscPasswordResetStep],
        state_id: Optional[str] = None,
    ) -> ApiResponse[InitiatePasswordResetResponse]:
        """Initiate a reset password request by using an authentication mechanism."""
        body: Dict = {
            "userName": user_name,
            "steps": [s.model_dump(exclude_none=True) for s in steps],
        }
        if state_id is not None:
            body["stateId"] = state_id
        return self._client._request(
            "POST",
            self._path("/usc/password/resetter"),
            model=InitiatePasswordResetResponse,
            json=body,
        )

    def complete_password_reset(
        self,
        *,
        trx_id: str,
        password: str,
        otp: Optional[str] = None,
    ) -> ApiResponse[CompletePasswordResetResponse]:
        """Verify the final step and reset the user's forgotten password."""
        body: Dict = {"password": password}
        if otp is not None:
            body["otp"] = otp
        return self._client._request(
            "PUT",
            self._path(f"/usc/password/resetter/{trx_id}"),
            model=CompletePasswordResetResponse,
            json=body,
        )

    def validate_password_reset(
        self,
        *,
        trx_id: str,
        otp: str,
    ) -> ApiResponse[ValidatePasswordResetResponse]:
        """Validate an authentication step in the reset password flow."""
        return self._client._request(
            "POST",
            self._path(f"/usc/password/resetter/{trx_id}/validator"),
            model=ValidatePasswordResetResponse,
            json={"otp": otp},
        )
