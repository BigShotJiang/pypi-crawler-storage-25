from __future__ import annotations

from typing import List

from pydantic import BaseModel


class ApplicationLink(BaseModel):
    pendingRequest: bool
    icon: str
    id: str
    linkName: str
    url: str


class Application(BaseModel):
    name: str
    links: List[ApplicationLink]
    description: str
    status: List[str]
    category: List[str]
    id: str
    discretionaryApp: bool


class GetApplicationsResponse(BaseModel):
    totalCount: int
    applications: List[Application]
