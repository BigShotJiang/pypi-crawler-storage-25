from __future__ import annotations

from typing import TYPE_CHECKING, Dict, Optional, Type

from ibm_verify_sdk.models import ApiResponse

from .models import GetApplicationsResponse

if TYPE_CHECKING:
    from ibm_verify_sdk.client import IbmVerifyClient


class ApplicationsModule:
    """Base class. Each version is a subclass registered via @ApplicationsModule.register()."""

    DEFAULT_VERSION = "v1.0"
    _registry: Dict[str, Type[ApplicationsModule]] = {}

    def __init__(self, client: IbmVerifyClient) -> None:
        self._client = client

    def _path(self, path: str) -> str:
        return f"/{self.DEFAULT_VERSION}{path}"

    @classmethod
    def register(cls, version: str):
        """Decorator to register a subclass for a given version string."""
        def decorator(subclass: Type[ApplicationsModule]) -> Type[ApplicationsModule]:
            cls._registry[version] = subclass
            return subclass
        return decorator

    @classmethod
    def create(cls, client: IbmVerifyClient, version: Optional[str] = None) -> ApplicationsModule:
        """Return the correct version-specific module instance."""
        v = version or cls.DEFAULT_VERSION
        subclass = cls._registry.get(v)
        if subclass is None:
            raise ValueError(f"No ApplicationsModule implementation for version '{v}'")
        return subclass(client)


@ApplicationsModule.register("v1.0")
class ApplicationsModuleV1(ApplicationsModule):
    DEFAULT_VERSION = "v1.0"

    def get_applications(self, *, search: Optional[str] = None) -> ApiResponse[GetApplicationsResponse]:
        """Fetches the applications that are entitled to a user."""
        return self._client._request(
            "GET",
            self._path("/user/applications"),
            model=GetApplicationsResponse,
            params={"search": search} if search is not None else None,
        )
