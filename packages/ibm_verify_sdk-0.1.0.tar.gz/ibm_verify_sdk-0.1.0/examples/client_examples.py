from ibm_verify_sdk import IbmVerifyClient, OtpType


def main() -> None:
    tenant_url = "https://your-tenant.verify.ibm.com"
    access_token = "your-access-token-here"

    # get_account_details requires the v2.0 users module
    client = IbmVerifyClient(
        tenant_url=tenant_url,
        access_token=access_token,
        versions={"users": "v2.0"},
    )

    response = client.users.get_account_details()
    print("Status:", response.status_code)
    print("Account details:", response.data)

    client.close()


if __name__ == "__main__":
    main()
