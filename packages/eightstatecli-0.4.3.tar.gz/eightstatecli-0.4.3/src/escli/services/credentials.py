"""
Credential service — vends API keys from gate (internal.eightstate.co).

If the user is authenticated via `escli auth login`, keys are fetched from
the gate service with headroom-aware rotation. Otherwise falls back to
local env vars or config.

Retry support:
  call_with_retry(service, fn) vends a key, calls fn, and on credit/rate
  errors (402, 429) reports the failure to gate and retries with the next
  key from the pool. Gate cooldowns the failed key so the next vend returns
  a different one.
"""

import json
import os
import pathlib
import sys
import time

GATE_URL = os.environ.get("ESCLI_GATE_URL", "https://internal.eightstate.co")
CONFIG_DIR = pathlib.Path(os.environ.get("ESCLI_CONFIG_DIR", pathlib.Path.home() / ".escli"))
CONFIG_FILE = CONFIG_DIR / "config.json"

RETRYABLE_STATUSES = frozenset({402, 429})


# ── Config ────────────────────────────────────────────────────────

def _load_config() -> dict:
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def get_cli_token() -> str | None:
    """Get the stored CLI token from config."""
    cfg = _load_config()
    profile = cfg.get("active_profile", "default")
    return cfg.get("profiles", {}).get(profile, {}).get("cli_token")


# ── Vending & reporting ───────────────────────────────────────────

def vend_key(service: str) -> dict | None:
    """
    Fetch an API key for a service from gate.
    Returns {"api_key": str, "fingerprint": str, "base_url": str | None} or None.
    """
    token = get_cli_token()
    if not token:
        return None

    try:
        import httpx
        resp = httpx.post(
            f"{GATE_URL}/api/keys/vend",
            json={"service": service},
            headers={"Authorization": f"Bearer {token}"},
            timeout=10,
        )
        if resp.status_code == 200:
            data = resp.json()
            if data.get("success"):
                return {
                    "api_key": data["api_key"],
                    "fingerprint": data["fingerprint"],
                    "base_url": data.get("base_url"),
                }
    except Exception:
        pass

    return None


def report_key(service: str, fingerprint: str, status: int,
               remaining: int | None = None, limit: int | None = None,
               reset: str | None = None, retry_after: int | None = None,
               tier: str | None = None,
               tokens_in: int | None = None, tokens_out: int | None = None,
               audio_seconds: float | None = None,
               usage_units: float | None = None, usage_sku: str | None = None):
    """Report rate limit state and usage metadata back to gate."""
    token = get_cli_token()
    if not token:
        return

    try:
        import httpx
        httpx.post(
            f"{GATE_URL}/api/keys/report",
            json={
                "service": service,
                "fingerprint": fingerprint,
                "status": status,
                "remaining": remaining,
                "limit": limit,
                "reset": reset,
                "retry_after": retry_after,
                "tier": tier,
                "tokens_in": tokens_in,
                "tokens_out": tokens_out,
                "audio_seconds": audio_seconds,
                "usage_units": usage_units,
                "usage_sku": usage_sku,
            },
            headers={"Authorization": f"Bearer {token}"},
            timeout=5,
        )
    except Exception:
        pass


def get_key_for_service(service: str, env_var: str | None = None) -> str | None:
    """
    Get an API key for a service. Priority:
    1. Environment variable (if specified)
    2. Gate credential vending
    3. None
    """
    if env_var:
        key = os.environ.get(env_var)
        if key:
            return key

    result = vend_key(service)
    if result:
        return result["api_key"]

    return None


# ── Retry wrapper ─────────────────────────────────────────────────

class VendedKey:
    """Credential vended from gate (or from env var)."""
    __slots__ = ("api_key", "fingerprint", "base_url")

    def __init__(self, api_key: str, fingerprint: str, base_url: str | None = None):
        self.api_key = api_key
        self.fingerprint = fingerprint
        self.base_url = base_url


class ServiceCallError(Exception):
    """All vended keys exhausted after retries."""
    def __init__(self, status_code: int, message: str = ""):
        self.status_code = status_code
        self.message = message
        super().__init__(f"keys exhausted (last status {status_code}): {message}")


def _extract_status(exc: Exception) -> int | None:
    """Extract HTTP status code from various exception types."""
    # httpx.HTTPStatusError
    resp = getattr(exc, "response", None)
    if resp is not None and hasattr(resp, "status_code"):
        return resp.status_code
    # urllib.error.HTTPError
    if hasattr(exc, "code") and isinstance(getattr(exc, "code"), int):
        return exc.code
    # openai.APIStatusError
    if hasattr(exc, "status_code") and isinstance(exc.status_code, int):
        return exc.status_code
    return None


def call_with_retry(service: str, fn, max_attempts: int = 3,
                    env_var: str | None = None):
    """
    Vend key → call fn(VendedKey) → retry on credit/rate errors.

    On 402/429 from fn, reports the failure to gate (which cooldowns /
    disables the key) then vends the next key and retries.

    Returns:
        fn result on success.
        None if no keys available at all (no pool, no env var).
    Raises:
        ServiceCallError if all keys exhausted after max_attempts.
        Any non-retryable exception from fn propagates as-is.
    """
    # Env var bypass — user-provided key, no retry
    if env_var:
        key = os.environ.get(env_var)
        if key:
            return fn(VendedKey(api_key=key, fingerprint="env"))

    last_error = None
    for _ in range(max_attempts):
        result = vend_key(service)
        if not result:
            break

        vended = VendedKey(
            api_key=result["api_key"],
            fingerprint=result["fingerprint"],
            base_url=result.get("base_url"),
        )
        try:
            return fn(vended)
        except Exception as e:
            status = _extract_status(e)
            if status is not None and status in RETRYABLE_STATUSES:
                report_key(service, vended.fingerprint, status)
                last_error = ServiceCallError(status, str(e)[:200])
                continue
            raise

    if last_error:
        raise last_error
    return None
