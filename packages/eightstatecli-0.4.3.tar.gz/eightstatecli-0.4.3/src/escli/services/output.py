"""
Structured output envelope and error types for agent consumption.

Every --json response uses the standard envelope:
  {"ok": true,  "data": {...}, "error": null, "meta": {...}}
  {"ok": false, "data": null,  "error": {...}, "meta": {...}}

Error objects include machine-readable codes and remediation hints.
"""

import json as jsonlib
import sys
import time
from typing import Any


class CliError(Exception):
    """Structured CLI error with code, category, and remediation."""

    def __init__(
        self,
        code: str,
        message: str,
        category: str = "user",  # user, system, transient
        exit_code: int = 1,
        retryable: bool = False,
        remediation: list[dict] | None = None,
        details: dict | None = None,
    ):
        super().__init__(message)
        self.code = code
        self.category = category
        self.exit_code = exit_code
        self.retryable = retryable
        self.remediation = remediation or []
        self.details = details

    def to_dict(self) -> dict:
        d: dict = {
            "code": self.code,
            "category": self.category,
            "message": str(self),
            "retryable": self.retryable,
        }
        if self.remediation:
            d["remediation"] = self.remediation
        if self.details:
            d["details"] = self.details
        return d


# ── Common errors ────────────────────────────────────────────────

class AuthError(CliError):
    def __init__(self, message: str = "not authenticated", **kwargs):
        super().__init__(
            code="cli.auth.required",
            message=message,
            category="user",
            exit_code=4,
            remediation=[{"action": "run", "command": "escli auth login"}],
            **kwargs,
        )


class NotFoundError(CliError):
    def __init__(self, resource: str, **kwargs):
        super().__init__(
            code="cli.not_found",
            message=f"not found: {resource}",
            category="user",
            exit_code=5,
            **kwargs,
        )


class ValidationError(CliError):
    def __init__(self, message: str, **kwargs):
        super().__init__(
            code="cli.validation",
            message=message,
            category="user",
            exit_code=2,
            **kwargs,
        )


class TransientError(CliError):
    def __init__(self, message: str, retry_after: int | None = None, **kwargs):
        remediation = [{"action": "retry"}]
        if retry_after:
            remediation[0]["backoff_seconds"] = retry_after
        super().__init__(
            code="cli.transient",
            message=message,
            category="transient",
            exit_code=8,
            retryable=True,
            remediation=remediation,
            **kwargs,
        )


class ApiError(CliError):
    def __init__(self, status: int, message: str, **kwargs):
        retryable = status in (429, 500, 502, 503, 504)
        category = "transient" if retryable else "system"
        code = {
            401: "cli.auth.invalid",
            403: "cli.auth.forbidden",
            404: "cli.not_found",
            429: "cli.rate_limited",
        }.get(status, f"cli.api.{status}")

        remediation = []
        if status == 401:
            remediation = [{"action": "run", "command": "escli auth login"}]
        elif status == 429:
            remediation = [{"action": "retry", "backoff_seconds": 30}]
        elif status >= 500:
            remediation = [{"action": "retry", "backoff_seconds": 5}]

        super().__init__(
            code=code,
            message=message,
            category=category,
            exit_code=8 if retryable else 1,
            retryable=retryable,
            remediation=remediation,
            **kwargs,
        )


# ── Envelope ─────────────────────────────────────────────────────

def success(data: Any = None, meta: dict | None = None) -> dict:
    """Build a success envelope."""
    return {"ok": True, "data": data, "error": None, "meta": meta or {}}


def failure(error: CliError | dict | str, meta: dict | None = None) -> dict:
    """Build a failure envelope."""
    if isinstance(error, CliError):
        err = error.to_dict()
    elif isinstance(error, dict):
        err = error
    else:
        err = {"code": "cli.error", "category": "system", "message": str(error), "retryable": False}
    return {"ok": False, "data": None, "error": err, "meta": meta or {}}


def emit_json(envelope: dict):
    """Print a JSON envelope to stdout."""
    print(jsonlib.dumps(envelope))


def emit_error(error: CliError, use_json: bool = False) -> int:
    """Print an error and return the exit code."""
    if use_json:
        emit_json(failure(error))
    else:
        print(f"  ✗ {error}", file=sys.stderr)
        for r in error.remediation:
            if r.get("command"):
                print(f"  → run: {r['command']}", file=sys.stderr)
            elif r.get("hint"):
                print(f"  → {r['hint']}", file=sys.stderr)
    return error.exit_code
