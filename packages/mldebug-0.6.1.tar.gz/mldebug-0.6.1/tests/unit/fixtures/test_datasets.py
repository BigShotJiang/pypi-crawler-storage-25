from mldebug.domain.feature_type import FeatureType
from tests.fixtures.datasets import generate_mixed_tabular_dataset


def test_generated_mixed_tabular_dataset_has_consistent_structure() -> None:
    n = 100
    n_features = 10

    reference, current, schema = generate_mixed_tabular_dataset(
        n=n, n_features=n_features
    )

    assert len(reference) == n_features
    assert len(current) == n_features
    assert len(schema) == n_features

    assert reference.keys() == current.keys() == schema.keys()

    assert set(schema.values()) == {FeatureType.NUMERIC, FeatureType.CATEGORICAL}

    for k in reference:
        assert len(reference[k]) == n
        assert len(current[k]) == n
