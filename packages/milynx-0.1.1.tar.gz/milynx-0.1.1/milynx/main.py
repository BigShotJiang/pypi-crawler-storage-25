import typer
from milynx.core.engine import  add_component
from milynx.core.engine import run_init
from milynx.core.detector import detect_project_type

app = typer.Typer()

@app.command()
def add(component: str):
    project_type = detect_project_type()

    context = {
        "project_type": project_type
    }

    add_component(component, context)

@app.command()
def init(
    project_type: str = typer.Argument(None),
    wizard: bool = typer.Option(False, "--wizard"),
    no: str = typer.Option(None, "--no"),
    only: str = typer.Option(None, "--only")
    ):
    run_init(project_type, wizard, no, only)

if __name__ == "__main__":
    app()