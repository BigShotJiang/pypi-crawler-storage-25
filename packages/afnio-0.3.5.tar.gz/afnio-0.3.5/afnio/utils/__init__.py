# afnio/utils/__init__.py
"""
Utility subpackage for `afnio`.

This module provides shared utilities used across the framework, including
helpers for agent construction, data loading, and dataset abstractions.

**Submodules:**

- [`agents`][afnio.utils.agents]: Predefined agent architectures.
- [`data`][afnio.utils.data]: Data loading and batching utilities.
- [`datasets`][afnio.utils.datasets]: Predefined dataset classes.
"""

from afnio.utils import agents, data, datasets

__all__ = ["agents", "data", "datasets"]

# Please keep this list sorted
assert __all__ == sorted(__all__)
