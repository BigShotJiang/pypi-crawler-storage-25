from abc import abstractmethod
from typing import List, Optional, TypeVar

from logis.biz.sim.task.model import TaskManifest
from logis.iface import IControl
from logis.task import ITaskHandler

from ..data_type.component import BlueprintKind
from .component import IComponent
from .proxy import ISimProxy


class IBlueprint(ISimProxy, ITaskHandler, IComponent, IControl):
    """
    所有蓝图组件的抽象基类
    """

    @abstractmethod
    def get_task_manifest[T](self) -> Optional[TaskManifest[T]]:
        """
        获取任务清单
        """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.name: Optional[str] = None
        self.create_edit_id: Optional[str] = None
        self.type_id: Optional[str] = None
        self.type_name: Optional[str] = None

    @classmethod
    def verbose_name(cls, *args, **kwargs):
        return cls.__name__

    @staticmethod
    @abstractmethod
    def kinds(*args, **kwargs) -> List[BlueprintKind]:
        """
        之所以有这个，是因为历史逻辑依靠此标志来分组
        """
        pass

    def is_kind_of(self, kind: BlueprintKind) -> bool:
        """
        判断是否是某种蓝图
        """
        return kind in (self.kinds() or [])

BlueprintClass = TypeVar("BlueprintClass", bound=IBlueprint)
