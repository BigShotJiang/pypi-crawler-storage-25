import os
import logging
from pydantic_ai import Agent
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.providers.ollama import OllamaProvider
from typing import Optional, Callable, TYPE_CHECKING, Any, cast
from pydantic_ai.messages import ModelMessage, ModelRequest, UserPromptPart, ModelResponse, TextPart

from .config import Config
from .tools import EngineContext


# Logging setup
logger = logging.getLogger("subconscious")


# Map provider display names (as stored in settings) to pydantic-ai prefixes and env-var names
_PROVIDER_MAP = {
  # Native pydantic-ai providers
  "openai":                           ("openai",      "OPENAI_API_KEY"),
  "anthropic":                        ("anthropic",   "ANTHROPIC_API_KEY"),
  "gemini":                           ("google-gla",  "GOOGLE_API_KEY"),
  "groq":                             ("groq",        "GROQ_API_KEY"),
  "mistral":                          ("mistral",     "MISTRAL_API_KEY"),
  "xai":                              ("xai",         "XAI_API_KEY"),
  "bedrock":                          ("bedrock",     "AWS_ACCESS_KEY_ID"),
  "cerebras":                         ("cerebras",    "CEREBRAS_API_KEY"),
  "cohere":                           ("cohere",      "CO_API_KEY"),
  "hugging face":                     ("huggingface", "HUGGINGFACEHUB_API_TOKEN"),
  "openrouter":                       ("openrouter",  "OPENROUTER_API_KEY"),
  # OpenAI-compatible providers (use openai prefix with custom base_url)
  "alibaba cloud model studio":       ("openai",      "DASHSCOPE_API_KEY"),
  "azure ai foundry":                 ("openai",      "AZURE_OPENAI_API_KEY"),
  "deepseek":                         ("deepseek",    "DEEPSEEK_API_KEY"),
  "fireworks ai":                     ("openai",      "FIREWORKS_API_KEY"),
  "github models":                    ("openai",      "GITHUB_TOKEN"),
  "litellm":                          ("openai",      "LITELLM_API_KEY"),
  "nebius ai studio":                 ("openai",      "NEBIUS_API_KEY"),
  "ollama":                           ("ollama",      None),             # no API key needed for local
  "perplexity":                       ("openai",      "PERPLEXITY_API_KEY"),
  "sambanova":                        ("openai",      "SAMBANOVA_API_KEY"),
  "together ai":                      ("openai",      "TOGETHER_API_KEY"),
}


def _provider_prefix(provider: str) -> str:
  """Return the pydantic-ai model-string prefix for a provider name."""
  return _PROVIDER_MAP.get(provider.lower(), (provider.lower(), None))[0]


def _provider_env_var(provider: str) -> Optional[str]:
  """Return the environment-variable name that holds the API key for this provider."""
  return _PROVIDER_MAP.get(provider.lower(), (None, None))[1]


class AgentManager:
  """Manages AI agents built from the encrypted model configs."""

  def __init__(self, config: Config):
    self.config = config

  # ------------------------------------------------------------------
  # Public helpers
  # ------------------------------------------------------------------

  def set_env_for_model(self, model_cfg: dict) -> None:
    """
    Given one model-config dict (as stored in secrets["models"]),
    set the appropriate environment variable so pydantic-ai can authenticate.
    model_cfg keys: provider, model, api_key, (optional) system_prompt
    """
    provider = (model_cfg.get("provider") or "").strip()
    api_key  = (model_cfg.get("api_key")  or "").strip()
    env_var  = _provider_env_var(provider)

    if env_var and api_key:
      os.environ[env_var] = api_key
      logger.debug(f"Set {env_var} for provider '{provider}'")
    elif not api_key:
      logger.warning(f"No api_key stored for provider '{provider}' (model id={model_cfg.get('id')})")

  def build_agent(self, model_cfg: dict, tools: Optional[list[Callable]] = None) -> Agent:
    """
    Construct a pydantic-ai Agent from a stored model config dict.
    Ensures the matching env-var is set first.

    Args:
      model_cfg: Provider/model/key dict as stored in secrets["models"].
      tools:     Optional list of pydantic-ai tool callables to attach.
                 When provided, EngineContext is used as the deps type so
                 tools receive the DB session and workspace context.
    """
    self.set_env_for_model(model_cfg)

    provider = (model_cfg.get("provider") or "").strip()
    raw_model = (model_cfg.get("model") or "").strip()
    system_prompt = (model_cfg.get("system_prompt") or "You are a helpful assistant.").strip()
    base_url = (model_cfg.get("base_url") or "").strip()

    prefix = _provider_prefix(provider)

    # Build fully-qualified model string, e.g. "openai:gpt-4o"
    if ":" in raw_model:
      full_model_str = raw_model          # already qualified
    elif raw_model:
      full_model_str = f"{prefix}:{raw_model}"
    else:
      raise ValueError(f"Model name is empty in config for provider '{provider}'")

    logger.debug(f"Building agent with model: {full_model_str}, tools: {len(tools or [])} attached")

    # For Ollama, use OpenAIChatModel with OllamaProvider to allow a custom base_url
    model_instance: Any = full_model_str
    if provider.lower() == "ollama":
      ollama_base_url = (base_url or "http://localhost:11434/v1").rstrip("/")
      if not ollama_base_url.endswith("/v1"):
        ollama_base_url += "/v1"
      model_instance = OpenAIChatModel(raw_model, provider=OllamaProvider(base_url=ollama_base_url))
      logger.debug(f"Ollama base_url: {ollama_base_url}")

    if tools:
      agent_kwargs: Any = dict(
        model=model_instance,
        system_prompt=system_prompt,
        tools=tools,
        deps_type=EngineContext,
      )
      return cast(Agent, Agent(**agent_kwargs))

    return Agent(model=model_instance, system_prompt=system_prompt)  # type: ignore[return-value]

  def get_best_model_cfg(self) -> Optional[dict]:
    """Return the first usable model config from encrypted storage, or None."""
    self.config.read_keyring()
    secrets = self.config.secrets or {}
    models = secrets.get("models", {})
    for model_id, cfg in models.items():
      if cfg.get("model") and cfg.get("provider"):
        return {"id": model_id, **cfg}
    return None
