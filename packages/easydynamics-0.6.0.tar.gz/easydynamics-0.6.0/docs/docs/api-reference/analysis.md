::: easydynamics.analysis
