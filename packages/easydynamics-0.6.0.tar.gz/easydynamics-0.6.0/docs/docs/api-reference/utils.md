::: easydynamics.utils
