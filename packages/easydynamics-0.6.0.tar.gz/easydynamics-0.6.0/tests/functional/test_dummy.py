# SPDX-FileCopyrightText: 2025-2026 EasyDynamics contributors <https://github.com/easyscience>
# SPDX-License-Identifier: BSD-3-Clause


def test_dummy():
    calculated = 2 + 2
    expected = 4
    assert calculated == expected
