# SPDX-FileCopyrightText: 2026 EasyScience contributors <https://github.com/easyscience>
# SPDX-License-Identifier: BSD-3-Clause

from copy import copy

import numpy as np
import pytest
from easyscience.variable import Parameter
from scipy.integrate import simpson

from easydynamics.sample_model import ComponentCollection
from easydynamics.sample_model import Gaussian
from easydynamics.sample_model import Lorentzian
from easydynamics.sample_model import Polynomial


class TestComponentCollection:
    @pytest.fixture
    def component_collection(self):
        model = ComponentCollection(display_name='TestComponentCollection')
        component1 = Gaussian(
            display_name='TestGaussian1',
            area=1.0,
            center=0.0,
            width=1.0,
            unit='meV',
            unique_name='TestGaussian1',
        )
        component2 = Lorentzian(
            display_name='TestLorentzian1',
            area=2.0,
            center=1.0,
            width=0.5,
            unit='meV',
            unique_name='TestLorentzian1',
        )
        model.append_component(component1)
        model.append_component(component2)
        return model

    def test_init(self):
        # WHEN THEN
        component_collection = ComponentCollection(display_name='InitModel')

        # EXPECT
        assert component_collection.display_name == 'InitModel'
        assert component_collection.components == []

    def test_init_with_components(self):
        # WHEN THEN
        component1 = Gaussian(
            display_name='TestGaussian1', area=1.0, center=0.0, width=1.0, unit='meV'
        )
        component2 = Lorentzian(
            display_name='TestLorentzian1', area=2.0, center=1.0, width=0.5, unit='meV'
        )
        component_collection = ComponentCollection(
            display_name='InitModel', components=[component1, component2]
        )

        # EXPECT
        assert component_collection.display_name == 'InitModel'
        assert len(component_collection.components) == 2
        assert component_collection.components[0] is component1
        assert component_collection.components[1] is component2

    def test_init_with_invalid_components_raises(self):
        # WHEN THEN EXPECT
        with pytest.raises(TypeError, match='Component must be'):
            ComponentCollection(components=['NotAComponent'])

    def test_init_with_invalid_list_of_components_raises(self):
        # WHEN THEN EXPECT
        with pytest.raises(TypeError, match='components must be a list of'):
            ComponentCollection(components='NotAList')

    def test_init_with_invalid_unit_raises(self):
        # WHEN THEN EXPECT
        with pytest.raises(TypeError, match='unit must be'):
            ComponentCollection(unit=123)

    # ───── Component Management ─────

    def test_append_component(self, component_collection):
        # WHEN
        component = Gaussian(
            display_name='TestComponent', area=1.0, center=0.0, width=1.0, unit='meV'
        )
        # THEN
        component_collection.append_component(component)
        # EXPECT
        assert component_collection.components[-1] is component

    def test_append_component_collection(self, component_collection):
        # WHEN
        component = Gaussian(
            display_name='TestComponent', area=1.0, center=0.0, width=1.0, unit='meV'
        )
        component_collection2 = ComponentCollection()
        component_collection2.append_component(component)
        # THEN
        component_collection.append_component(component_collection2)
        # EXPECT
        assert component_collection.components[-1] is component

    def test_append_existing_component_raises(self, component_collection):
        # WHEN THEN
        component = component_collection.components[0]
        # EXPECT
        with pytest.raises(ValueError, match='is already in the collection'):
            component_collection.append_component(component)

    def test_append_invalid_component_raises(self, component_collection):
        # WHEN THEN EXPECT
        with pytest.raises(TypeError, match='Component must be '):
            component_collection.append_component('NotAComponent')

    def test_remove_component(self, component_collection):
        # WHEN THEN
        component_collection.remove_component('TestGaussian1')
        # EXPECT
        assert 'TestGaussian1' not in component_collection.components

    def test_remove_component_raises(self, component_collection):
        # WHEN THEN EXPECT
        with pytest.raises(TypeError, match='Component name must be a string'):
            component_collection.remove_component(123)

    def test_remove_nonexistent_component_raises(self, component_collection):
        # WHEN THEN EXPECT
        with pytest.raises(KeyError, match="No component named 'NonExistentComponent' exists"):
            component_collection.remove_component('NonExistentComponent')

    def test_getitem(self, component_collection):
        # WHEN
        component = Gaussian(
            display_name='TestComponent', area=1.0, center=0.0, width=1.0, unit='meV'
        )
        # THEN
        component_collection.append_component(component)
        # EXPECT
        assert component_collection.components[-1] is component

    def test_component_setter(self, component_collection):
        # WHEN
        new_components = [Lorentzian()]
        # THEN
        component_collection.components = new_components
        # EXPECT
        assert len(component_collection.components) == 1
        assert component_collection.components[0] is new_components[0]

    def test_component_setter_invalid_raises(self, component_collection):
        # WHEN THEN EXPECT
        with pytest.raises(TypeError, match=r' must be instances of ModelComponent.'):
            component_collection.components = ['NotAComponent']

        with pytest.raises(TypeError, match='components must be a list of'):
            component_collection.components = 'NotAList'

    def test_is_empty(self):
        # WHEN THEN
        component_collection = ComponentCollection(display_name='EmptyModel')
        # EXPECT
        assert component_collection.is_empty is True

        # WHEN THEN
        component = Gaussian(
            display_name='TestComponent', area=1.0, center=0.0, width=1.0, unit='meV'
        )
        component_collection.append_component(component)
        # EXPECT
        assert component_collection.is_empty is False

    def test_is_empty_setter(self, component_collection):
        # WHEN THEN EXPECT
        with pytest.raises(AttributeError, match=r'is_empty is a read-only property.'):
            component_collection.is_empty = True

    def test_component_setter_empty_list(self, component_collection):
        component_collection.components = []
        assert component_collection.components == []

    def test_list_component_names(self, component_collection):
        # WHEN THEN
        components = component_collection.list_component_names()
        # EXPECT
        assert len(components) == 2
        assert components[0] == 'TestGaussian1'
        assert components[1] == 'TestLorentzian1'

    def test_clear_components(self, component_collection):
        # WHEN THEN
        component_collection.clear_components()
        # EXPECT
        assert len(component_collection.components) == 0

    def test_convert_unit(self, component_collection):
        # WHEN THEN
        component_collection.convert_unit('eV')
        # EXPECT
        for component in component_collection.components:
            assert component.unit == 'eV'

    def test_convert_unit_incorrect_unit_raises(self, component_collection):
        # WHEN THEN EXPECT
        with pytest.raises(TypeError, match=r'Unit must be a string or sc.Unit'):
            component_collection.convert_unit(123)

    def test_convert_unit_failure_rolls_back(self, component_collection):
        # WHEN THEN
        # Introduce a faulty component that will fail conversion
        class FaultyComponent(Gaussian):
            def convert_unit(self, _unit: str) -> None:
                raise RuntimeError('Conversion failed.')

        faulty_component = FaultyComponent(
            display_name='FaultyComponent', area=1.0, center=0.0, width=1.0, unit='meV'
        )
        component_collection.append_component(faulty_component)

        original_units = {
            component.display_name: component.unit for component in component_collection.components
        }

        # EXPECT
        with pytest.raises(RuntimeError, match=r'Conversion failed.'):
            component_collection.convert_unit('eV')

        # Check that all components have their original units
        for component in component_collection.components:
            assert component.unit == original_units[component.display_name]

    def test_set_unit(self, component_collection):
        # WHEN THEN EXPECT
        with pytest.raises(
            AttributeError,
            match=r'Unit is read-only. Use convert_unit to change the unit',
        ):
            component_collection.unit = 'eV'

    def test_evaluate(self, component_collection):
        # WHEN
        x = np.linspace(-5, 5, 100)
        result = component_collection.evaluate(x)
        # EXPECT
        expected_result = component_collection.components[0].evaluate(
            x
        ) + component_collection.components[1].evaluate(x)
        np.testing.assert_allclose(result, expected_result, rtol=1e-5)

    def test_evaluate_no_components_returns_zero(self):
        # WHEN THEN
        component_collection = ComponentCollection(display_name='EmptyModel')
        x = np.linspace(-5, 5, 100)
        # EXPECT
        result = component_collection.evaluate(x)
        assert np.all(result == pytest.approx(0.0))
        assert result.shape == x.shape

    def test_evaluate_component(self, component_collection):
        # WHEN  THEN
        x = np.linspace(-5, 5, 100)
        result1 = component_collection.evaluate_component(x, 'TestGaussian1')
        result2 = component_collection.evaluate_component(x, 'TestLorentzian1')

        # EXPECT
        expected_result1 = component_collection.components[0].evaluate(x)
        expected_result2 = component_collection.components[1].evaluate(x)
        np.testing.assert_allclose(result1, expected_result1, rtol=1e-5)
        np.testing.assert_allclose(result2, expected_result2, rtol=1e-5)

    def test_evaluate_nonexistent_component_raises(self, component_collection):
        # WHEN
        x = np.linspace(-5, 5, 100)

        # THEN EXPECT
        with pytest.raises(KeyError, match="No component named 'NonExistentComponent' exists"):
            component_collection.evaluate_component(x, 'NonExistentComponent')

    def test_evaluate_component_no_components_raises(self):
        # WHEN THEN
        component_collection = ComponentCollection(display_name='EmptyModel')
        x = np.linspace(-5, 5, 100)
        # EXPECT
        with pytest.raises(ValueError, match=r'No components in the model to evaluate.'):
            component_collection.evaluate_component(x, 'AnyComponent')

    def test_evaluate_component_invalid_name_type_raises(self, component_collection):
        # WHEN
        x = np.linspace(-5, 5, 100)

        # THEN EXPECT
        with pytest.raises(
            TypeError,
            match=r"Component unique name must be a string, got <class 'int'> instead.",
        ):
            component_collection.evaluate_component(x, 123)

    # ───── Utilities ─────

    def test_normalize_area(self, component_collection):
        # WHEN THEN
        component_collection.normalize_area()
        # EXPECT
        x = np.linspace(-10000, 10000, 1000000)  # Lorentzians have long tails
        result = component_collection.evaluate(x)
        numerical_area = simpson(result, x)
        assert np.isclose(numerical_area, 1.0, rtol=1e-4)

    def test_normalize_area_no_components_raises(self):
        # WHEN THEN
        component_collection = ComponentCollection(display_name='EmptyModel')
        # EXPECT
        with pytest.raises(ValueError, match=r'No components in the model to normalize.'):
            component_collection.normalize_area()

    @pytest.mark.parametrize(
        'area_value',
        [np.nan, 0.0, np.inf],
        ids=['NaN area', 'Zero area', 'Infinite area'],
    )
    def test_normalize_area_not_finite_area_raises(self, component_collection, area_value):
        # WHEN THEN
        component_collection.components[0].area = area_value
        component_collection.components[1].area = area_value

        # EXPECT
        with pytest.raises(ValueError, match=r'cannot normalize'):
            component_collection.normalize_area()

    def test_normalize_area_non_area_component_warns(self, component_collection):
        # WHEN
        component1 = Polynomial(display_name='TestPolynomial', coefficients=[1, 2, 3], unit='meV')
        component_collection.append_component(component1)

        # THEN EXPECT
        with pytest.warns(UserWarning, match="does not have an 'area' "):
            component_collection.normalize_area()

    def test_get_all_parameters(self, component_collection):
        # WHEN THEN
        parameters = component_collection.get_all_parameters()
        # EXPECT
        assert len(parameters) == 6

        expected_names = {
            'TestGaussian1 area',
            'TestGaussian1 center',
            'TestGaussian1 width',
            'TestLorentzian1 area',
            'TestLorentzian1 center',
            'TestLorentzian1 width',
        }
        actual_names = {param.name for param in parameters}
        assert actual_names == expected_names
        assert all(isinstance(param, Parameter) for param in parameters)

    def test_get_parameters_no_components(self):
        component_collection = ComponentCollection(display_name='EmptyModel')
        # WHEN THEN
        parameters = component_collection.get_all_parameters()
        # EXPECT
        assert len(parameters) == 0

    def test_get_fit_parameters(self, component_collection):
        # WHEN

        # Fix one parameter and make another dependent
        component_collection.components[0].area.fixed = True
        component_collection.components[1].width.make_dependent_on(
            'comp1_width',
            {'comp1_width': component_collection.components[0].width},
        )

        # THEN
        fit_parameters = component_collection.get_fit_parameters()

        # EXPECT
        assert len(fit_parameters) == 4

        expected_names = {
            'TestGaussian1 center',
            'TestGaussian1 width',
            'TestLorentzian1 area',
            'TestLorentzian1 center',
        }
        actual_names = {param.name for param in fit_parameters}
        assert actual_names == expected_names
        assert all(isinstance(param, Parameter) for param in fit_parameters)

    def test_fix_and_free_all_parameters(self, component_collection):
        # WHEN THEN
        component_collection.fix_all_parameters()

        # EXPECT
        for param in component_collection.get_all_parameters():
            assert param.fixed is True

        # WHEN
        component_collection.free_all_parameters()

        # THEN
        for param in component_collection.get_all_parameters():
            assert param.fixed is False

    def test_contains(self, component_collection):
        assert 'TestGaussian1' in component_collection
        assert 'TestLorentzian1' in component_collection
        assert 'NonExistentComponent' not in component_collection

        gaussian_component = component_collection.components[0]
        lorentzian_component = component_collection.components[1]
        assert gaussian_component in component_collection
        assert lorentzian_component in component_collection

        # WHEN THEN
        fake_component = Gaussian(
            display_name='FakeGaussian', area=1.0, center=0.0, width=1.0, unit='meV'
        )
        # EXPECT
        assert fake_component not in component_collection
        assert 123 not in component_collection  # Invalid type

    def test_repr_contains_name_and_components(self, component_collection):
        # WHEN THEN
        rep = repr(component_collection)
        # EXPECT
        assert 'ComponentCollection' in rep
        assert 'TestGaussian' in rep

    def test_to_dict(self, component_collection):
        # WHEN THEN
        model_dict = component_collection.to_dict()

        # EXPECT
        assert model_dict['display_name'] == component_collection.display_name
        assert model_dict['unit'] == component_collection.unit
        assert len(model_dict['components']) == len(component_collection.components)

        for comp, comp_dict in zip(
            component_collection.components, model_dict['components'], strict=True
        ):
            assert comp_dict['@class'] == type(comp).__name__
            assert comp_dict['display_name'] == comp.display_name
            assert comp_dict['unit'] == comp.unit

    def test_from_dict(self, component_collection):
        # WHEN
        model_dict = component_collection.to_dict()

        # THEN
        new_model = ComponentCollection.from_dict(model_dict)

        # EXPECT
        assert new_model.display_name == component_collection.display_name
        assert len(new_model.components) == len(component_collection.components)

        # Compare each component and its parameters
        for orig_comp, new_comp in zip(
            component_collection.components, new_model.components, strict=True
        ):
            assert type(new_comp) is type(orig_comp)
            assert new_comp.display_name == orig_comp.display_name
            assert new_comp.unit == orig_comp.unit

            orig_params = orig_comp.get_all_parameters()
            new_params = new_comp.get_all_parameters()
            assert len(orig_params) == len(new_params)
            for param_orig, param_new in zip(orig_params, new_params, strict=True):
                assert param_new.name == param_orig.name
                assert param_new.value == param_orig.value
                assert param_new.fixed == param_orig.fixed

    def test_copy(self, component_collection):
        # WHEN
        component_collection.temperature = 300
        component_collection.components[0].area.min = 0.5
        component_collection.components[0].area.fixed = True
        component_collection.components[0].area.max = 5.0
        component_collection.components[1].width.min = 0.1
        component_collection.components[1].width.fixed = True
        component_collection.components[1].width.max = 2.0

        # THEN
        model_copy = copy(component_collection)

        # EXPECT collection-level checks
        assert model_copy is not component_collection
        assert model_copy.display_name == component_collection.display_name
        assert len(model_copy.components) == len(component_collection.components)

        # EXPECT: deep copy, same order
        for orig_comp, copied_comp in zip(
            component_collection.components, model_copy.components, strict=True
        ):
            # New object
            assert copied_comp is not orig_comp

            # Same type and display name
            assert type(copied_comp) is type(orig_comp)
            assert copied_comp.display_name == orig_comp.display_name
            assert copied_comp.unit == orig_comp.unit

            # Parameters are deep-copied and equivalent
            orig_params = orig_comp.get_all_parameters()
            copied_params = copied_comp.get_all_parameters()

            assert len(orig_params) == len(copied_params)

            for param_orig, param_copy in zip(orig_params, copied_params, strict=True):
                assert param_copy is not param_orig
                assert param_copy.value == param_orig.value
                assert param_copy.min == param_orig.min
                assert param_copy.max == param_orig.max
                assert param_copy.fixed == param_orig.fixed
