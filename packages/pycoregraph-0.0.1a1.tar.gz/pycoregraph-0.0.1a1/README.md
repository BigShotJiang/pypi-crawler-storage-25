# CoReGraph : **Co**rrelation-based dynamic gene **Re**gulatory **Graph**s

A Python package for dynamic lagged gene correlation analysis along pseudotime trajectories.

## Requirments

```bash
python >= 3.10
```

## Installation

```bash
pip install coregraph
```