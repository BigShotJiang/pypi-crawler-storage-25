__version__ = "0.0.1a1"

# Models
from coregraph.models import (
    CoReGraph_Cors,
    CoReGraph_Graphics,
    CoReGraph,
    StarGraph,
)

# Analysis
from coregraph.analysis.queries import (
    get_correlation,
    get_all_correlations,
    get_mac,
    get_mac_results,
    get_regulated_genes,
    get_regulator_genes,
)

# Graphics
from coregraph.graphics.plots import (
    plot_expression,
    plot_correlations,
)

from coregraph.graphics.animations import (
    animate_correlations,
)

from coregraph.graphics.network import (
    animate_network,
)

from coregraph.analysis.subset import (
    starry,
    subset_coregraph,
)

__all__ = [
    "CoReGraph",
    "CoReGraph_Cors",
    "CoReGraph_Graphics",
    "StarGraph",
    "get_correlation",
    "get_all_correlations",
    "get_mac",
    "get_mac_results",
    "get_regulated_genes",
    "get_regulator_genes",
    "plot_expression",
    "plot_correlations",
    "animate_correlations",
    "animate_network",
    "starry",
    "subset_coregraph"
]