## DECORATORS ##

from functools import wraps


def requires_cors(func):
    @wraps(func)
    def wrapper(coregraph, *args, **kwargs):
        if coregraph.cors.window is None:
            raise RuntimeError(
                "Correlations have not been calculated yet. "
                "Run `calculate_all_cors()` first."
            )
        return func(coregraph, *args, **kwargs)
    return wrapper


def requires_bins(func):
    @wraps(func)
    def wrapper(coregraph, *args, **kwargs):
        if coregraph.graphics.n_bins is None:
            raise RuntimeError(
                "Bins have not been discretized yet. "
                "Run `calculate_bins()` first."
            )
        return func(coregraph, *args, **kwargs)
    return wrapper


def requires_FDR(func):
    @wraps(func)
    def wrapper(coregraph, *args, **kwargs):
        if coregraph.cors.FDR is None:
            raise RuntimeError(
                "FDR has not been computed yet. "
                "Run `calculate_FDR()` first."
            )
        return func(coregraph, *args, **kwargs)
    return wrapper