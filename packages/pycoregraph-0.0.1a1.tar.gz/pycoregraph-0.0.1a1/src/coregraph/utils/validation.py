## VALIDATION ##

import math


def _solve_step(step, n_steps, window, n_cells):
    if (step == None) and (n_steps == None):
        return 1, n_cells-window+1
    if (step != None) and (n_steps != None):
        raise ValueError("Specify either 'step' or 'n_steps, not both.")
    if (step != None):
        if (step >= (n_cells - window)):
            raise ValueError("'step' is too high for provided window")
        else:
            n_steps = (n_cells - window) // step + 1
            return step, n_steps
    if n_steps >= (n_cells - window):
        raise ValueError("'n_steps' is too high for provided window")
    else:
        step = math.ceil((n_cells - window) / n_steps)
        return step, n_steps

def _solve_total_dim3(step, window, n_cells):
    max_dim = (n_cells - window) // step + 1
    return max_dim * (max_dim + 1) //2