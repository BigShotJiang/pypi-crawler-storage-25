## FORMATTING ##

import numpy as np


def _set_numerical_format(dtype: str):
        '''Assign correct numerical parametrs depending on dtype sepcified from user'''
        if isinstance(dtype, str):
            if dtype.lower() == 'float':
                return [np.float64, np.array([1,15])]
            elif dtype.lower() == 'int':
                return [np.int64, np.array([1000,0])]
        else:
            raise ValueError("dtype must be 'int' or 'float'")
            
            