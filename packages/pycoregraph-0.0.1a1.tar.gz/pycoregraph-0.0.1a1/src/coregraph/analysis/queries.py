## QUERIES ##

from __future__ import annotations

import numpy as np
import pandas as pd

from coregraph.utils.decorators import (requires_cors, requires_FDR)


@requires_cors
def get_correlation(C: CoReGraph, regulator: str, target: str, ref_lag: tuple[int, int]) -> float:
    '''Get correlation value between two genes at a specific (reference, lag) window pair.'''  
    ref, lag = ref_lag

    if (ref % C.cors.step != 0) or (lag % C.cors.step != 0):
        raise ValueError(f"ref_lag must be multiples of step={C.cors.step}")

    reg_idx = C.gene_to_idx[regulator]
    tar_idx = C.gene_to_idx[target]

    if ref <= lag:
        tensor_i = reg_idx
        tensor_j = tar_idx
        search_ref = ref
        search_lag = lag
    else:
        tensor_i = tar_idx
        tensor_j = reg_idx
        search_ref = lag
        search_lag = ref

    dim3 = np.argwhere((C.cors.reflag[:, 0] == search_ref) & (C.cors.reflag[:, 1] == search_lag))[0][0]

    value = (C.cors.tensor[tensor_i, tensor_j, dim3] / C.cors.num_format[0])

    return float(value)


@requires_cors
def get_all_correlations(C: CoReGraph, regulator: str, target: str, ref: int) -> np.ndarray:
    '''Get all lagged correlations between two genes for a fixed reference window.'''
    if (ref % C.cors.step != 0) :
        raise ValueError(f"ref must be a multiple of step={C.cors.step}")

    correlations = np.empty(C.cors.n_steps, dtype=C.cors.dtype)

    for i in range(C.cors.n_steps):
        lag = i * C.cors.step
        correlations[i] = get_correlation(C,regulator,target,(ref, lag))

    return correlations


@requires_cors
def get_mac(C: CoReGraph, regulator: str, target: str) -> dict:
    '''Get maximal absolute correlation (MAC) and corresponding reference/lag pair for two genes.'''
    reg_idx = C.gene_to_idx[regulator]
    tar_idx = C.gene_to_idx[target]

    return {
        "ref": int(C.cors.LAG_id[0, reg_idx, tar_idx]), 
        "lag": int(C.cors.LAG_id[1, reg_idx, tar_idx]),
        "cor": float(C.cors.MAC[reg_idx, tar_idx] / C.cors.num_format[0])
        }


@requires_cors
def get_mac_results(C: CoReGraph) -> tuple[pd.DataFrame, pd.DataFrame]:
    '''Get MAC and LAG matrices.'''
    mac_df = pd.DataFrame(C.cors.MAC / C.cors.num_format[0], index=C.gene_id, columns=C.gene_id)
    lag_df = pd.DataFrame(C.cors.LAG, index=C.gene_id, columns=C.gene_id)

    return mac_df, lag_df


@requires_cors
@requires_FDR
def get_regulated_genes(C: CoReGraph, regulator: str, cor_threshold: float=0.0) -> pd.DataFrame:
    '''Get genes regulated by a regulator gene.'''
    reg_idx = C.gene_to_idx[regulator]

    values = (C.cors.MAC[reg_idx, :] / C.cors.num_format[0])

    df = pd.DataFrame({
        "gene": C.gene_id,
        "correlation": values,
        "lag": C.cors.LAG[reg_idx, :]
        })

    df = df[np.abs(df["correlation"]) > cor_threshold]

    df = df.sort_values(by="correlation", key=np.abs, ascending=False)

    return df.set_index("gene")


@requires_cors
@requires_FDR
def get_regulator_genes(C: CoReGraph, target: str, cor_threshold: float=0.0) -> pd.DataFrame:
    '''Get genes regulated by a regulator gene.'''
    tar_idx = C.gene_to_idx[target]

    values = (C.cors.MAC[:, tar_idx] / C.cors.num_format[0])

    df = pd.DataFrame({
        "gene": C.gene_id,
        "correlation": values,
        "lag": C.cors.LAG[:, tar_idx]
        })

    df = df[np.abs(df["correlation"]) > cor_threshold]

    df = df.sort_values(by="correlation", key=np.abs, ascending=False)

    return df.set_index("gene")


