## REDUCTIONS ##

import numpy as np
import pandas as pd

from tqdm import tqdm

from coregraph.models.coregraph import CoReGraph
from coregraph.models.stargraph import StarGraph

from coregraph.analysis.correlations import _calculate_star_cors
from coregraph.analysis.fdr import _calculate_star_FDR
from coregraph.utils.validation import _solve_step


def starry(x, central_gene, window, FDR_thr=0.05, n_perms=100, FDR_cutoffs=501, step=None, n_steps=None, verbose=False): 
    '''Wrapped function to estimate starry gene regulatory network centered on a given gene'''
    n_genes, n_cells = x.data.shape
    target_row       = x.gene_id.index(central_gene) 
    step, n_steps    = _solve_step(step, n_steps, window, n_cells)

    ## Calculate MAC ##
    MAC      = np.zeros((n_genes), dtype=np.float64)

    np.seterr(divide='ignore', invalid='ignore')
    iterator = tqdm(range(0, n_cells-window+1, step), desc="Calculating Correlations", disable=not verbose)
    for i in iterator:
        MAC = _calculate_star_cors(x.data, target_row, MAC, window, i, step)

    ## Calculate FDR ##
    FDR = _calculate_star_FDR(x.data, target_row, MAC, window, n_perms, FDR_cutoffs, step)
    FDR = pd.DataFrame(FDR)
    FDR.columns            = ["cors", "MACs_observed", "MACs_ave_perm", "FDR"]
    FDR[["MACs_observed"]] = FDR[["MACs_observed"]].astype(int)

    cor_thr   = min(FDR['cors'][FDR['FDR'] < FDR_thr])
    MAC       = pd.DataFrame(MAC, index=x.gene_id, columns=['MAC'])
    MAC       = MAC.sort_values(by='MAC', key=abs, ascending=False)

    ## Create a new object and fill in it ##
    star = StarGraph()
    star.central_gene = central_gene
    star.window       = window
    star.step         = step
    star.n_steps      = n_steps
    star.MAC          = MAC
    star.FDR          = FDR
    star.set_FDR_threshold(FDR_thr)
    
    return star


def subset_coregraph(C: CoReGraph, gene_list: list[str]) -> CoReGraph:
    id_dict = {}
    for i, b in enumerate(C.gene_id):
        id_dict[b] = i

    shared_id = [id_dict[g] for g in gene_list]
    shared_id.sort()
    subdata   = C.data[shared_id,:]
    subid     = [C.gene_id[g] for g in shared_id]

    subobject = CoReGraph(subdata, C.pseudotime, subid, C.cell_id)
    return subobject
