## FDR ##

import numpy as np

from coregraph.analysis.correlations import (_calculate_LEAP_cors, _calculate_star_cors)


def _calculate_FDR(data, MAC, window, n_perms = 100, FDR_cutoffs = 101, step=1, num_format=np.array([1,15]), dtype=np.float64):
    '''Calculate False Discovery Rate by permutations'''

    MAC_true  = np.absolute(MAC.copy())
    samp_size = np.minimum(100, data.shape[0])
    MACs_perm = np.zeros((n_perms, samp_size, samp_size))
    np.fill_diagonal(MAC_true, -1)

    # simplified MAC_counter function
    for n in range(0, n_perms):
        np.random.seed(n)
        data_perm = data[0:samp_size,:].copy()
        inds      = np.random.choice(data.shape[0], size=samp_size, replace=False)

        for z in range(0, samp_size):
            data_perm[z,:] = np.random.permutation(data[inds[z],:])
  
        MAC_p, _ = _calculate_LEAP_cors(data_perm, window, 0, step, num_format, dtype)
        MAC_p = np.absolute(MAC_p)
        np.fill_diagonal(MAC_p, -1)
        MACs_perm[n] = MAC_p

    # Calculate FDR 
    cors          = np.linspace(0, 1, FDR_cutoffs)
    num_cors_perm = np.full(FDR_cutoffs, 0)
    MACs_observed = np.full(FDR_cutoffs, 0)

    for r in range(0, FDR_cutoffs):
        num_cors_perm[r] += np.sum(MACs_perm >= cors[r])
        MACs_observed[r] += np.sum(MAC_true >= cors[r])

    perm_size     = samp_size*samp_size-samp_size
    obs_size      = MAC_true.shape[0]*MAC_true.shape[1]-MAC_true.shape[0]
    MACs_ave_perm = num_cors_perm/n_perms*(obs_size/perm_size)
    fdr           = np.full(FDR_cutoffs, np.nan)

    for s in range(0,FDR_cutoffs):
        if MACs_observed[s] == 0:
            fdr[s] = 0
        else:
            fdr[s] = MACs_ave_perm[s]/MACs_observed[s]

    results = np.column_stack((cors, MACs_observed, MACs_ave_perm, fdr))
       
    return results[::-1]

def _calculate_star_FDR(data, target_row, MAC, window, n_perms = 100, FDR_cutoffs = 101, step=1, num_format=np.array([1,15]), dtype=np.float64):
    '''Calculate False Discovery Rate by permutations for a single reference row against all rows.'''

    MAC_true  = np.absolute(MAC.copy())
    samp_size = np.minimum(100, data.shape[0])
    MACs_perm = np.zeros((n_perms, samp_size))
    MAC_true[target_row] = -1

    # simplified MAC_counter function
    for n in range(0, n_perms):
        np.random.seed(n)
        ref_perm  = data[target_row,:].copy()
        data_perm = data[0:samp_size-1,:].copy()
        data_perm = np.concatenate((ref_perm.reshape((1,-1)), data_perm))
        inds      = np.random.choice(data.shape[0], size=samp_size, replace=False)

        for z in range(0, samp_size):
            data_perm[z,:] = np.random.permutation(data[inds[z],:])
  
        MAC_p        = _calculate_star_cors(data_perm, 0, np.zeros((samp_size), dtype=dtype), window, i=0, step=step, num_format=num_format, dtype=dtype)
        MAC_p        = np.absolute(MAC_p)
        MAC_p[0]     = -1
        MACs_perm[n] = MAC_p

    ### Calculate FDR ###
    cors          = np.linspace(0, 1, FDR_cutoffs)
    num_cors_perm = np.full(FDR_cutoffs, 0)
    MACs_observed = np.full(FDR_cutoffs, 0)

    for r in range(0, FDR_cutoffs):
        num_cors_perm[r] += np.sum(MACs_perm >= cors[r])
        MACs_observed[r] += np.sum(MAC_true >= cors[r])

    perm_size     = samp_size-1
    obs_size      = MAC_true.shape[0]-1
    MACs_ave_perm = num_cors_perm/n_perms*(obs_size/perm_size)
    fdr           = np.full(FDR_cutoffs, np.nan)

    for s in range(0,FDR_cutoffs):
        if MACs_observed[s] == 0:
            fdr[s] = 0
        else:
            fdr[s] = MACs_ave_perm[s]/MACs_observed[s]

    results = np.column_stack((cors, MACs_observed, MACs_ave_perm, fdr))
       
    return results[::-1]