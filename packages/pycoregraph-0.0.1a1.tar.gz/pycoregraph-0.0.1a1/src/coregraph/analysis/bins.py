## BINS ##

import numpy as np


def _calculate_bins(data, pseudotime, n_bins):
    '''Discretize pseudotime expression in bins'''
    
    bin_range = (pseudotime.max() - pseudotime.min())/n_bins
    bin_seq   = pseudotime.min() + np.arange(1,n_bins)*bin_range
    bins      = (np.digitize(pseudotime, bin_seq)*bin_range)+(bin_range/2)
    
    mean_res  = np.empty((data.shape[0], n_bins), dtype=np.float64)
    std_res   = np.empty((data.shape[0], n_bins), dtype=np.float64)
    for i, b in enumerate(np.unique(bins)):
        mean_res[:,i] = np.mean(data[:,bins==b], axis=1)
        std_res[:,i]  = np.mean(data[:,bins==b], axis=1)

    mean    = mean_res
    std     = std_res
    scaled  = mean/np.max(mean, axis=1)[:, None]

    return bins, mean, std, scaled
