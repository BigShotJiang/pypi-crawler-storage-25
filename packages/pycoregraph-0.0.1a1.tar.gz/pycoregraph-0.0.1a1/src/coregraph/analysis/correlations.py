## CORRELATIONS ##

import numpy as np


def _calculate_all_cors(data, window, i, tensor, reflag, MAC, LAG_id, LAG, LAG_means, dim3_start, step=1, num_format=np.array([1,15]), dtype=np.float64):
    '''Calculate all lagged correlations for a unique given reference i'''
    dim3 = dim3_start
    n_genes, n_cells = data.shape

    data_ref     = data[:,i:window+i]
    mean_ref     = np.mean(data_ref, axis=1)
    cent_ref     = data_ref.T - mean_ref
    rowsumx_ref  = np.sum(cent_ref, axis=0).reshape(1, -1)
    rowsumx2_ref = np.sum(np.square(cent_ref), axis=0).reshape(1, -1)

    for j in range(i, n_cells-window+1, step):
        data_lag     = data[:,j:window+j]
        mean_lag     = np.mean(data_lag, axis=1)
        cent_lag     = data_lag.T - mean_lag
        rowsumx_lag  = np.sum(cent_lag, axis=0).reshape(1, -1)
        rowsumx2_lag = np.sum(np.square(cent_lag), axis=0).reshape(1, -1)

        Cor = (np.dot(cent_ref.T, cent_lag) - (1 / window) * np.dot(rowsumx_ref.T, rowsumx_lag)) / \
            np.dot(np.sqrt(rowsumx2_ref - rowsumx_ref**2 / window).T, np.sqrt(rowsumx2_lag - rowsumx_lag**2 / window))
        
        np.fill_diagonal(Cor, 1)
        Cor              = np.round(np.nan_to_num(Cor, nan=0)*num_format[0], num_format[1])
        Cor              = Cor.astype(dtype)
        tensor[:,:,dim3] = Cor
        LAG_means[dim3]  = mean_lag
        reflag[dim3,0]   = i
        reflag[dim3,1]   = j

        # Update MAC
        ind       = np.abs(MAC) < np.abs(Cor)
        MAC[ind]         = Cor[ind]
        LAG[ind]         = j-i
        LAG_id[0][ind]   = i
        LAG_id[1][ind]   = j
        #
        dim3 += 1

    return dim3, MAC, LAG_id, LAG, LAG_means

def _calculate_LEAP_cors(data, window, i=0, step=1, num_format=np.array([1,15]), dtype=np.float64):
    '''Calculate all lagged correlations for a unique given reference i using LEAP traditional algorithm'''
    n_genes, n_cells = data.shape
    MAC              = np.zeros((n_genes, n_genes))
    LAG              = np.zeros((n_genes, n_genes))

    data_ref     = data[:,i:window+i]
    mean_ref     = np.mean(data_ref, axis=1)
    cent_ref     = data_ref.T - mean_ref
    rowsumx_ref  = np.sum(cent_ref, axis=0).reshape(1, -1)
    rowsumx2_ref = np.sum(np.square(cent_ref), axis=0).reshape(1, -1)

    for j in range(i, n_cells - window, step):
        data_lag     = data[:,j:window+j]
        mean_lag     = np.mean(data_lag, axis=1)
        cent_lag     = data_lag.T - mean_lag
        rowsumx_lag  = np.sum(cent_lag, axis=0).reshape(1, -1)
        rowsumx2_lag = np.sum(np.square(cent_lag), axis=0).reshape(1, -1)

        Cor = np.dot(cent_ref.T, cent_lag) - (1 / window) * np.dot(rowsumx_ref.T, rowsumx_lag) / \
            np.dot(np.sqrt(rowsumx2_ref - rowsumx_ref**2 / window).T, np.sqrt(rowsumx2_lag - rowsumx_lag**2 / window))
        
        np.fill_diagonal(Cor, 1)
        Cor              = np.round(np.nan_to_num(Cor, nan=0)*num_format[0], num_format[1])
        Cor              = Cor.astype(dtype)
        # Update MAC
        ind = np.where(np.abs(MAC) > np.abs(Cor))
        LAG[ind] = j - i
        MAC[ind] = Cor[ind]

    return MAC, LAG


def _calculate_star_cors(data, target_row, MAC, window, i, step=1, num_format=np.array([1,15]), dtype=np.float64):
    '''Calculate all lagged correlations for a unique given reference i using a single reference row against all rows.'''

    n_genes, n_cells = data.shape

    # Take reference row only
    data_ref = data[target_row, i:window+i]
    mean_ref = np.mean(data_ref)
    cent_ref = data_ref - mean_ref

    sum_ref  = np.sum(cent_ref)
    sum_ref2 = np.sum(np.square(cent_ref), axis=0)

    for j in range(i, n_cells - window, step):
        data_lag = data[:, j:window+j]
        mean_lag = np.mean(data_lag, axis=1)
        cent_lag = data_lag - mean_lag[:, None]

        rowsumx_lag  = np.sum(cent_lag, axis=1)
        rowsumx2_lag = np.sum(cent_lag * cent_lag, axis=1)
        cross = np.dot(cent_lag, cent_ref)

        Cor = (cross - (rowsumx_lag * sum_ref) / window) / \
            (np.sqrt(rowsumx2_lag - (rowsumx_lag * rowsumx_lag) / window) * np.sqrt(sum_ref2 - (sum_ref * sum_ref) / window))
        
        Cor = np.round(np.nan_to_num(Cor, nan=0)*num_format[0], num_format[1])
        Cor = Cor.astype(dtype)

        ind      = np.where(np.abs(MAC) < np.abs(Cor))
        MAC[ind] = Cor[ind]

    return MAC