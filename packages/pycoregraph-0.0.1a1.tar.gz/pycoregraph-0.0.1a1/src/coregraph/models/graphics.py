## GRAPHICS ##

from dataclasses import dataclass

import numpy as np


@dataclass
class CoReGraph_Graphics:
    '''
    Container for graphical data.

    Attributes
    ----------
    n_bins : int
        Bin number used to discretize pseudotime
    bin_id : ndarray
        Vector of bin attributed to each cell
    mean : ndarray
        Binned mean expression
    std : ndarray
        Binned standard deviation 
    scaled : ndarray
        Binned scaled expression
    '''

    n_bins: int | None = None
    bin_id: np.ndarray | None = None
    mean: np.ndarray | None = None
    std: np.ndarray | None = None
    scaled: np.ndarray | None = None


    def __repr__(self):
        return f'CoReGraph_Graphics(n_bins: {self.n_bins})'

    def __str__(self):
        return f'CoReGraph_Graphics object'