## COREGRAPH ##

from __future__ import annotations

from typing import Optional

import warnings
import numpy as np
import pandas as pd

from tqdm import tqdm

from coregraph.models.cors import (CoReGraph_Cors)
from coregraph.models.graphics import (CoReGraph_Graphics)
from coregraph.analysis.correlations import (_calculate_all_cors)
from coregraph.analysis.bins import (_calculate_bins)
from coregraph.analysis.fdr import (_calculate_FDR)

from coregraph.utils.validation import (_solve_step, _solve_total_dim3)
from coregraph.utils.formatting import (_set_numerical_format)
from coregraph.utils.decorators import (requires_cors)

class CoReGraph:
    '''
    Main CoreGraph object.

    Attributes
    ----------
    data : ndarray
        Original matrix with genes in rows and pseudotime-sorted cells in columns
    n_genes : int 
        Total number of genes
    n_cells : int 
        Total number of cells
    pseudotime : ndarray
        Pseudotime associated to each cells 
    gene_id : list 
        Vector of gene names
    cell_id : list 
        Vector of cell names
    gene_to_idx : dict
        Dictionnary of {gene: gene_id}
    cell_to_idx : dict
        Dictionnary of {cell: cell_id}
    cors : CoReGraph_Cors
        CoReGraph_Cors object containing correlations once calculated
    graphics : CoReGraph_Graphics
        CoReGraph_Graphics object containing binned epxressions once calculated to draw plots
    '''  

    ## INITIALIZATION AND CLASS METHODS ##

    def __init__(self, matrix: np.ndarray, pseudotime: Optional[np.ndarray]=None, genes=None, cells=None):
        self.data        = np.asarray(matrix)
        self.n_genes     = self.data.shape[0]
        self.n_cells     = self.data.shape[1]

        self.pseudotime  = (np.asarray(pseudotime) if pseudotime is not None else np.arange(self.n_cells))
        self.gene_id     = (list(genes) if genes is not None else list(range(self.n_genes)))
        self.cell_id     = (list(cells) if cells is not None else list(range(self.n_cells)))
        self.gene_to_idx = {str(gene): int(idx) for idx, gene in enumerate(self.gene_id)}
        self.cell_to_idx = {str(cell): int(idx) for idx, cell in enumerate(self.cell_id)}

        self.cors        = CoReGraph_Cors()
        self.graphics    = CoReGraph_Graphics()

    @classmethod
    def from_pandas(cls, dataframe: pd.DataFrame, with_pseudotime: bool=False):
        if with_pseudotime:
            return cls(matrix=dataframe.iloc[1:], pseudotime=dataframe.iloc[0], genes=dataframe.index[1:], cells=dataframe.columns)

        return cls(matrix=dataframe, genes=dataframe.index, cells=dataframe.columns)


    ## __DUNDERS__ ##

    def __repr__(self):
        msg = f'CoReGraph({self.n_genes} genes, {self.n_cells} cells)'
        if self.cors.window is not None:
            msg += f'\n└ cors(window={self.cors.window})'
        if self.graphics.n_bins is not None:
            msg += f'\n└ graphics(n_bins={self.graphics.n_bins})'
        return msg

    def __str__(self):
        msg = f'CoReGraph object with {self.n_genes} genes and {self.n_cells} cells.'
        if self.cors.window is not None:
            msg += f'\n-- Correlations calculated with a window of {self.cors.window} cells.'
        if self.graphics.n_bins is not None:
            msg += f'\n-- Discretized with {self.graphics.n_bins} bins.'
        return msg

    def __getattr__(self, name):
        for target in [self.cors, self.graphics]:
            attr = getattr(target, name, None)
            if attr is not None:
                return attr
        raise AttributeError(f"'{type(self).__name__}' object has no attribute '{name}'")


    ## CORRELATIONS CALCULATION METHOD ##

    def calculate_all_cors(self, window: int, step: int | None = None, n_steps: int | None = None, verbose: bool=False, dtype: str="float"):
        '''
        Calculate all lagged correlations.

        Parameters
        ----------
        window : int
            Number of cells in the window for applying lags (usually n_cells*2/3)
        step : int | None
            Step to apply while shifting window
        n_steps : int | None
            Total number of steps to consider while shifting window
        verbose : bool
            Wether show progression bar (slightly slow down the process)
        dtype : type
            Data type used to store results. Should be 'float' or 'int' (recommanded to reduce memory use).

        Return
        ------
        Update tensor, window, reflag, MAC, LAG_id, LAG, LAG_means, LAG_scaled attributes, as well as step, n_steps, dtype and num_format
        '''

        n_genes, n_cells           = self.data.shape
        resolved_dtype, num_format = _set_numerical_format(dtype)
        step, n_steps              = _solve_step(step, n_steps, window, n_cells)

        # Initialize a new instance of CoReGraph_Cors object only if necessary
        if (self.cors.window == window) and (self.cors.dtype == resolved_dtype[0]) and (self.cors.step == step):
            raise ValueError(f'Correlation with window={window} and step={step} have already been calculated.')
       
       # Warning if some cells are excluded
        excluded_cells =  n_cells - (window + ((n_steps-1) * step))
        if excluded_cells != 0:
            warnings.warn(f'Provided step and window exclude the last {excluded_cells} cells.')

        # Remove warning while dividing by zero and managing defined num type
        np.seterr(divide='ignore', invalid='ignore')
        
        # Initialize loops and empty objects
        total_dim3 = _solve_total_dim3(step, window, n_cells)
        tensor     = np.empty((n_genes, n_genes, total_dim3), dtype=resolved_dtype)
        MAC        = np.zeros((n_genes, n_genes), dtype=resolved_dtype)
        LAG_id     = np.empty((2, n_genes, n_genes), dtype=np.int64)
        LAG        = np.zeros((n_genes, n_genes), dtype=np.int64)
        reflag     = np.empty((total_dim3, 2))
        dim3       = 0
        LAG_means  = np.empty((total_dim3, n_genes), dtype=np.float64)

        # Iterate through refs (iterator) and lags (inner function)
        iterator = tqdm(range(0, n_cells-window+1, step), desc="Calculating Correlations", disable=not verbose)
        for i in iterator:
            dim3, MAC, LAG_id, LAG, LAG_means = _calculate_all_cors(self.data, window, i, tensor, reflag, MAC, LAG_id, LAG, LAG_means, dim3, step, num_format, resolved_dtype)
        
        # Fill in attributes
        self.cors.MAC       = MAC
        self.cors.LAG_id    = LAG_id
        self.cors.LAG       = LAG
        self.cors.LAG_means = LAG_means
        self.cors.tensor    = tensor
        self.cors.window    = window
        self.cors.step      = step
        self.cors.n_steps   = n_steps
        self.cors.reflag    = reflag
        max = np.max(self.cors.LAG_means.T, axis=1).T
        min = np.min(self.cors.LAG_means.T, axis=1).T
        self.cors.LAG_scaled = (self.cors.LAG_means - min) / (max - min)
        self.cors.dtype      = resolved_dtype
        self.cors.num_format = num_format


    ## FDR CALCULATION METHOD ##

    @requires_cors 
    def calculate_FDR(self, n_perms = 100, FDR_cutoffs = 101):
        '''
        Calculate permutations to estimate False Discovery Rate (FDR).

        Parameters
        ----------
        n_perms : int
            Number of permutation to perform for estimation
        FDR_cutoffs : int
            Resolution of FDR estimate, number of bins between 0 to 1 that are displayed in results.

        Return
        ------
        Update FDR attribute

        '''

        FDR = _calculate_FDR(self.data, self.cors.MAC/self.cors.num_format[0], self.cors.window, n_perms, FDR_cutoffs, self.cors.step)
        FDR = pd.DataFrame(FDR, columns=["cors", "MACs_observed", "MACs_ave_perm", "FDR"])
        FDR[["MACs_observed"]] = FDR[["MACs_observed"]].astype(int)
        self.cors.FDR = FDR


    ## BIN DISCRETIZATION METHOD ##

    def calculate_bins(self, n_bins: int):
        '''
        Calculate pseudotime bins.

        Parameters
        ----------
        n_bins : int
            Number of bins to consider for pseudotime discretization
        '''
        # Initialize a new instance of CoReGraph_Graphics object only if necessary
        if self.graphics.n_bins == n_bins:
            raise ValueError(f'Bins for n_bins={n_bins} have already been calculated.')

        self.graphics.bin_id, self.graphics.mean, self.graphics.std, self.graphics.scaled = _calculate_bins(self.data, self.pseudotime, n_bins)
        self.graphics.n_bins = n_bins



  

   