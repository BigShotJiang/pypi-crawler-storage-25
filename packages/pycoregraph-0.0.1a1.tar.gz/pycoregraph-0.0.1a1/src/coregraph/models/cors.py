## CORS ##

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass
class CoReGraph_Cors:
    '''
    Container for correlation results.

    Attributes
    ----------
    window : int
        Window used for the current correlations
    step : int
        Step used while looping over pseudotime
    n_steps : int
        Total number of steps considered along pseudotime
    tensor : (3D)ndarray
        Result of all lagged or not correlations
    reflag : ndarray
        Vector of (ref,lag) corresponding to tensor dimensions
    MAC : ndarray
        Maximum Absolute Correlation values
    LAG_id : ndarray
        Reflag corresponding to the dimension used for MAC
    LAG : ndarray
        Number of cells corresponding to the lag used for MAC
    LAG_means : (3D)ndarray 
        Gene mean expressions calculated for each window
    LAG_scaled : (3D)ndarray 
        Gene scaled expressions calculated for each window
    FDR : DataFrame
        Pandas DataFrame recapitulating metrics for False Dicovery Rate estimation
    dtype : str
        Numpy type of object to store correlation values (should be 'int' or 'float')
    num_format : ndarray
        Numpy array of two elements used to define the numerical format [scale_factor, n_decimals]
    '''

    window: int | None = None
    step: int | None = None
    n_steps: int | None = None
    tensor: np.ndarray | None = None
    reflag: np.ndarray | None = None
    MAC: np.ndarray | None = None
    LAG_id: np.ndarray | None = None
    LAG: np.ndarray | None = None
    LAG_means: np.ndarray | None = None
    LAG_scaled: np.ndarray | None = None
    FDR: pd.DataFrame | None = None
    dtype: np.dtype | None = None
    num_format: np.ndarray | None = None


    def __repr__(self):
        return f'CoReGraph_Cors(window: {self.window}, step: {self.step})'

    def __str__(self):
        return f'CoReGraph_Cors object'