## STARGRAPH ##

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass
class StarGraph:
    '''
    Local star-shaped regulatory network.
    '''

    central_gene: str | None = None
    window: int | None = None
    step: int | None = None
    n_steps: int | None = None
    FDR_thr: float | None = None
    cors_thr: float | None = None
    MAC: pd.DataFrame | None = None
    FDR: pd.DataFrame | None = None
    gene_list: list[str] | None = None


    def __repr__(self):
        return f'StarGraph(central_gene: {self.central_gene}, window: {self.window})'

    def __str__(self):
        return f'StarGraph object'


    def set_correlation_threshold(self, threshold: float):
        self.cors_thr = threshold
        self.FDR_thr = np.max(self.FDR.loc[self.FDR['cors'] > threshold, 'FDR'])
        self.gene_list = (self.MAC.loc[np.abs(self.MAC['MAC']) >= threshold].index.tolist())

    def set_FDR_threshold(self, threshold: float):
        self.fdr_threshold = threshold
        self.correlation_threshold = np.min(self.FDR.loc[self.FDR['FDR'] < threshold, 'cors'])
        self.gene_list = (self.MAC.loc[np.abs(self.MAC['MAC']) >= self.correlation_threshold].index.tolist())