## ANIMATIONS ##

from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches

from matplotlib.animation import FuncAnimation

from coregraph.graphics.colors import ColorBlind
from coregraph.analysis.queries import (get_all_correlations)
from coregraph.utils.decorators import (requires_cors, requires_bins)


@requires_bins
@requires_cors
def animate_correlations(C: CoReGraph, regulator: str, target: str, ref: int, scaled: bool=False, decimals: int=15, color: list=(ColorBlind[0], ColorBlind[3]), linewidth: float=1, figsize: tuple=(8,4)):
    '''Animate lagged correlations.'''
    if C.graphics.n_bins is None:
        raise ValueError("Bins have not been calculated.")
    
    values        = (C.graphics.scaled if scaled else C.graphics.mean)
    reg_idx       = C.gene_to_idx[regulator]
    tar_idx       = C.gene_to_idx[target]
    y_max         = np.max([values[reg_idx, :], values[tar_idx, :]]) * 1.1
    all_cors      = get_all_correlations(C, regulator, target, ref)
    all_cors_norm = (all_cors / np.max(np.abs(all_cors)))
    
    fig, ax = plt.subplots(1, 2, figsize=figsize, width_ratios=[25, 1],)
    x       = np.unique(C.graphics.bin_id)

    # Regulator and target lines
    ax[0].plot(x, values[reg_idx, :], color=color[0])
    ax[0].plot(x, values[tar_idx, :], color=color[1],)

    fixed_rect  = ax[0].add_patch(patches.Rectangle((ref, 0), C.cors.window, y_max, facecolor=color[0], alpha=0.1,))
    moving_rect = ax[0].add_patch(patches.Rectangle((0, 0), C.cors.window, y_max, facecolor=color[1], alpha=0.1,))

    cor_text = ax[0].annotate("", (C.n_cells * 0.01, y_max * 0.8))
    lag_text = ax[0].annotate("", (C.n_cells * 0.01, y_max * 0.9))

    def update(frame):
        lag = frame * C.cors.step
        moving_rect.set_x(lag)
        cor = all_cors[frame]
        cor_text.set_text(f"cor = {np.round(cor, decimals)}")
        lag_text.set_text(f"lag = {lag}")

        return (moving_rect, cor_text, lag_text)

    ani = FuncAnimation(fig, update, frames=C.cors.n_steps, blit=True)
    #HTML(ani.to_jshtml())
    return ani


