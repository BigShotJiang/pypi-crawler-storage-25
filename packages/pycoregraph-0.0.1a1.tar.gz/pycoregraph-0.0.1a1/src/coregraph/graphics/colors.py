## COLORS ##

# Colorblind friendly set of colors
Blues      = ['#016BA0','#5F9ED1','#A1C8EB','#3399FF', '#006ddb','#330066']
YReds      = ['#FF0000','#FF9933','#F0E442','#ffff6d','#FF7070']
Greys      = ['#131313','#555555','#809099','#CFCFCF','#F2F4F4']
Others     = ['#FFBBAB']

ColorBlind = [Blues[0], YReds[0], Blues[1], YReds[1], Blues[2], YReds[2], Blues[3], YReds[3], Blues[4], YReds[4], Blues[5], Others[0], Greys[0], Greys[1], Greys[2], Greys[3], Greys[4]]