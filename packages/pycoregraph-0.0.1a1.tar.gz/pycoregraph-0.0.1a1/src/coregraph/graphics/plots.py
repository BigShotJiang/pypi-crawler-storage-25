## PLOTS ##

from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches

from coregraph.graphics.colors import ColorBlind
from coregraph.analysis.queries import (get_correlation)
from coregraph.utils.decorators import (requires_cors, requires_bins)


@requires_bins
def plot_expression(C: CoReGraph, genes: str | list[str], scaled: bool=False, std: bool=False, color=None, linewidth: float=1, figsize: tuple=(8,4)):
    '''Plot gene expression along pseudotime.'''

    ### TODO : make std parameter functional ###

    if C.graphics.n_bins is None:
        raise ValueError("Bins have not been calculated.")
    
    if isinstance(genes, str):
        genes = [genes]

    # Handle colors — one per gene if not specified
    if color is None:
        colors = plt.cm.tab10(np.linspace(0, 1, len(genes)))
    elif isinstance(color, str):
        colors = [color] * len(genes)
    else:
        colors = color

    values  = (C.graphics.scaled if scaled else C.graphics.mean)
    fig, ax = plt.subplots(figsize=figsize)
    x       = np.unique(C.graphics.bin_id)

    for gene, colo in zip(genes, colors):
        if (gene not in C.gene_to_idx):
            raise ValueError(f"Unknown gene: {gene}")

        idx = C.gene_to_idx[gene]
        ax.plot(x, values[idx, :], label=gene, color=colo, linewidth=linewidth)

    ax.set_xlabel("Pseudotime")
    ax.set_ylabel("Scaled Expression" if scaled else "Expression")
    ax.legend()

    fig.tight_layout()
    return ax


@requires_bins
@requires_cors
def plot_correlations(C: CoReGraph, regulator: str, target: str, ref_lag: tuple[int, int], scaled: bool=False, decimals: int=15, color: list=(ColorBlind[0], ColorBlind[3]), linewidth: float=1, figsize: tuple=(8,4)) :
    '''Plot lagged correlations between genes.'''
    if C.graphics.n_bins is None:
        raise ValueError("Bins have not been calculated.")
    
    values  = (C.graphics.scaled if scaled else C.graphics.mean)
    reg_idx = C.gene_to_idx[regulator]
    tar_idx = C.gene_to_idx[target]
    y_max   = np.max([values[reg_idx, :], values[tar_idx, :]]) * 1.1

    fig, ax = plt.subplots(figsize=figsize)
    x       = np.unique(C.graphics.bin_id)
    
    ax.plot(x, values[reg_idx, :], color=color[0], linewidth=linewidth)
    ax.plot(x, values[tar_idx, :], color=color[1], linewidth=linewidth)

    ref, lag = ref_lag
    ax.add_patch(patches.Rectangle((ref, 0), C.cors.window, y_max, facecolor=color[0], alpha=0.1,))
    ax.add_patch(patches.Rectangle((lag, 0), C.cors.window, y_max, facecolor=color[1], alpha=0.1,))

    cor = get_correlation(C, regulator, target, ref_lag)
    ax.annotate(f"cor = {np.round(cor, decimals)}", (C.n_cells * 0.01, y_max * 0.85,))
    ax.set_xlim(0, C.n_cells)
    ax.set_ylim(0, y_max)
    ax.set_xlabel("Pseudotime")
    ax.set_ylabel("Scaled Expression" if scaled else "Expression")
    ax.set_title(f'{regulator} [{ref_lag[0]}] -> {target} [{ref_lag[1]}]')

    ax.legend([regulator, target])

    return ax