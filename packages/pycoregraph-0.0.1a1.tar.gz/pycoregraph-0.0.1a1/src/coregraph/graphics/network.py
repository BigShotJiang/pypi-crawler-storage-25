## NETWORK ##

from __future__ import annotations

import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import matplotlib.colors as mcolors

from matplotlib.animation import FuncAnimation

from coregraph.analysis.queries import (get_all_correlations, get_mac)
from coregraph.utils.decorators import (requires_cors, requires_FDR)


def _build_correlation_tensor(C, genes, correlation_threshold):
    '''
    Build tensor (n_genes, n_genes, n_steps) containing all dynamic correlations.
    '''
    n          = len(genes)
    cor_tensor = np.zeros((n, n, C.cors.n_steps), dtype=C.cors.dtype)

    for i, regulator in enumerate(genes):
        for j, target in enumerate(genes):
            if i == j:
                continue
    
            ref_lag_cor = get_mac(C, regulator, target)
            ref         = ref_lag_cor["ref"]

            all_cors = get_all_correlations(C, regulator, target, ref)
            all_cors[np.abs(all_cors) < correlation_threshold] = 0

            cor_tensor[i, j, :] = all_cors[:C.cors.n_steps]

    return cor_tensor


def _build_adjacency_tensor(cor_tensor):
    '''
    Keep strongest direction only between pairs.
    '''
    adjacency = np.abs(cor_tensor) > np.abs(cor_tensor.transpose(1, 0, 2))
    filtered  = cor_tensor.copy()
    filtered[~adjacency] = 0

    return filtered


def _compute_node_sizes(C, genes, node_ratio=1):
    '''
    Compute node size evolution through time.
    '''
    gene_indices = [C.gene_to_idx[g] for g in genes]

    return (node_ratio * 1000 * C.cors.LAG_scaled[:C.cors.n_steps, gene_indices])


def _build_graph_layout(genes):
    '''
    Create stable graph layout.
    '''
    G = nx.DiGraph()
    G.add_nodes_from(range(len(genes)))
    pos = nx.spring_layout(G, seed=33)

    return G, pos


def _compute_edge_style(G, cmap, norm, edge_ratio):
    '''
    Compute edge colors and widths.
    '''
    weights     = nx.get_edge_attributes(G, 'weight')
    edge_colors = [cmap(norm(w)) for w in weights.values()]
    edge_widths = [abs(w) * edge_ratio for w in weights.values()]

    return (weights, edge_colors, edge_widths)


def _draw_network_frame(ax, G, pos, genes, adjacency_matrix, node_sizes, cmap, norm, edge_ratio, font_size, min_target_margin, min_source_margin):
    '''
    Draw single network frame.
    '''
    ax.clear()
    G.clear_edges()
    n = len(genes)

    # Add edges
    for i in range(n):
        for j in range(n):
            weight = adjacency_matrix[i, j]
            if weight != 0:
                G.add_edge(i, j, weight=weight)

    # Edge style
    (weights, edge_colors, edge_widths) = _compute_edge_style(G, cmap, norm, edge_ratio)

    # Draw nodes
    nx.draw_networkx_nodes(G, pos, ax=ax, node_size=node_sizes, node_color='skyblue')

    # Draw labels
    nx.draw_networkx_labels(G, pos, labels={i: gene for i, gene in enumerate(genes)}, ax=ax, font_size=font_size)

    # Draw edges
    edges = nx.draw_networkx_edges(G, pos, ax=ax, edge_color=edge_colors, width=edge_widths, arrowstyle='-|>', min_target_margin=min_target_margin, min_source_margin=min_source_margin,)

    for edge in edges:
        edge.set_joinstyle("miter")
        edge.set_capstyle("butt")


@requires_cors
@requires_FDR
def animate_network(
    C: CoReGraph,
    genes: list[str],
    fdr_threshold: float=0.01,
    correlation_threshold: float | None = None,
    edge_ratio: float=1,
    node_ratio: float=1,
    min_target_margin: float=15,
    min_source_margin: float=15,
    font_size: int=8,
    figsize: tuple=(6, 6)
):
    '''
    Animate dynamic gene regulatory network.

    Parameters
    ----------
    C : CoreGraph
        CoreGraph object.

    genes : list[str]
        Genes to include in network.

    fdr_threshold : float
        FDR threshold used to infer minimum correlation threshold.

    correlation_threshold : float | None
        Correlation threshold.

    edge_ratio : float
        Edge width scaling factor.

    node_ratio : float
        Node size scaling factor.

    figsize : tuple
        Figure size.
   '''
    # Validate threshold
    if correlation_threshold is None:
        correlation_threshold = np.min(C.cors.FDR.loc[C.cors.FDR["FDR"] < fdr_threshold, "cors"])

    # Filter genes
    genes = [g for g in genes if g in C.gene_to_idx]

    # Build correlation tensor and graph
    cor_tensor = _build_correlation_tensor(C, genes, correlation_threshold)
    cor_tensor = _build_adjacency_tensor(cor_tensor)
    node_sizes = _compute_node_sizes(C, genes, node_ratio=node_ratio)
    G, pos     = _build_graph_layout(genes)

    # Figure
    fig, ax = plt.subplots(figsize=figsize)
    cmap    = cm.bwr
    vmin    = cor_tensor.min()
    vmax    = cor_tensor.max()

    if vmin == vmax:
        vmax += 1e-10

    norm = mcolors.TwoSlopeNorm(vmin=vmin, vcenter=0.0, vmax=vmax)

    # Edge normalization
    if C.cors.dtype == np.int64:
        edge_ratio *= 0.01
    else:
        edge_ratio *= 10


    # Update function
    def update(frame):
        adjacency_matrix = cor_tensor[:, :, frame]
        _draw_network_frame(
            ax=ax,
            G=G,
            pos=pos,
            genes=genes,
            adjacency_matrix=adjacency_matrix,
            node_sizes=node_sizes[frame],
            cmap=cmap,
            norm=norm,
            edge_ratio=edge_ratio,
            font_size=font_size,
            min_target_margin=min_target_margin,
            min_source_margin=min_source_margin,
        )

        ax.set_title(f"Time step {frame * C.cors.step}")

        return ax

    # Create animation
    if plt.rcParams["animation.embed_limit"] < 250:
        plt.rcParams["animation.embed_limit"] = 250

    ani = FuncAnimation(fig, update, frames=C.cors.n_steps, interval=1000, repeat=True, blit=False)
    plt.close(fig)
    # HTML(ani.to_jshtml())
    return ani