import coregraph


def test_package_import():
    assert coregraph is not None


def test_public_api():
    assert hasattr(coregraph, "CoReGraph")
    assert hasattr(coregraph, "StarGraph")