import numpy as np

from coregraph import CoReGraph


def test_initialization():

    x = np.random.rand(10, 20)

    cg = CoReGraph(x)

    assert cg.n_genes == 10
    assert cg.n_cells == 20