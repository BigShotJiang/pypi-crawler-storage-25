"""
VIGÍA — Base de datos de resultados (SQLite)
"""

import sqlite3
import json
import os
from datetime import datetime


def init_db(db_path: str) -> sqlite3.Connection:
    """Inicializa la base de datos y crea tablas si no existen."""
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("""
        CREATE TABLE IF NOT EXISTS campaigns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            target_model TEXT NOT NULL,
            started_at TEXT NOT NULL,
            finished_at TEXT,
            config TEXT,
            total_attacks INTEGER DEFAULT 0,
            total_successes INTEGER DEFAULT 0
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS attacks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            campaign_id INTEGER NOT NULL,
            seed_id TEXT NOT NULL,
            vector TEXT NOT NULL,
            owasp TEXT,
            atlas TEXT,
            language TEXT,
            prompt TEXT NOT NULL,
            response TEXT,
            chunks_retrieved TEXT,
            score INTEGER,
            success INTEGER DEFAULT 0,
            evaluator_reasoning TEXT,
            timestamp TEXT NOT NULL,
            duration_ms INTEGER,
            FOREIGN KEY (campaign_id) REFERENCES campaigns(id)
        )
    """)
    conn.commit()
    return conn


def create_campaign(conn: sqlite3.Connection, name: str, target_model: str, config: dict) -> int:
    """Crea una nueva campaña y devuelve su ID."""
    cursor = conn.execute(
        "INSERT INTO campaigns (name, target_model, started_at, config) VALUES (?, ?, ?, ?)",
        (name, target_model, datetime.now().isoformat(), json.dumps(config))
    )
    conn.commit()
    return cursor.lastrowid


def record_attack(conn: sqlite3.Connection, campaign_id: int, result: dict):
    """Registra un resultado de ataque."""
    conn.execute(
        """INSERT INTO attacks 
           (campaign_id, seed_id, vector, owasp, atlas, language, prompt, 
            response, chunks_retrieved, score, success, evaluator_reasoning, 
            timestamp, duration_ms)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            campaign_id,
            result["seed_id"],
            result["vector"],
            result.get("owasp"),
            result.get("atlas"),
            result.get("language"),
            result["prompt"],
            result["response"],
            json.dumps(result.get("chunks", [])),
            result.get("score", 0),
            1 if result.get("score", 0) >= 5 else 0,
            result.get("evaluator_reasoning"),
            datetime.now().isoformat(),
            result.get("duration_ms"),
        )
    )
    conn.commit()


def finish_campaign(conn: sqlite3.Connection, campaign_id: int):
    """Marca una campaña como finalizada y calcula totales."""
    row = conn.execute(
        "SELECT COUNT(*) as total, SUM(success) as successes FROM attacks WHERE campaign_id = ?",
        (campaign_id,)
    ).fetchone()
    conn.execute(
        "UPDATE campaigns SET finished_at = ?, total_attacks = ?, total_successes = ? WHERE id = ?",
        (datetime.now().isoformat(), row["total"], row["successes"] or 0, campaign_id)
    )
    conn.commit()
