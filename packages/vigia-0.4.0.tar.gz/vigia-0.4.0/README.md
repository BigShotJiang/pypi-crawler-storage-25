# VIGÍA

**Framework de red teaming automatizado para LLMs en español.**

Casi toda la investigación de seguridad en LLMs se hace en inglés, pero las empresas españolas están desplegando chatbots RAG en castellano para banca, sanidad y administración pública. Esos chatbots tienen guardrails entrenados mayoritariamente en inglés. VIGÍA automatiza la auditoría de seguridad con ataques diseñados nativamente en español, técnicas de code-switching entre lenguas ibéricas, y vectores que explotan cómo los modelos procesan el castellano.

## Qué hace

VIGÍA lanza ataques automatizados contra tu chatbot (local o remoto), evalúa si ha filtrado información sensible usando un LLM como juez, y genera un informe con los resultados mapeados a OWASP Top 10 for LLMs y MITRE ATLAS.

## Resultados

### Benchmark RAG — 19 seeds × 5 modelos (threshold ≥ 5)

| Modelo | Tipo | Tasa vuln | Vulns | Críticos (≥7) | Score medio | Score máx |
|--------|------|:---------:|:-----:|:-------------:|:-----------:|:---------:|
| Claude Haiku 4.5 | Comercial | 21.1% | 4/19 | 1 | 1.9 | 9 |
| Llama 3.1 8B | Open source | 31.6% | 6/19 | 6 | 2.9 | 9 |
| Gemma2 2B | Open source | 68.4% | 13/19 | 6 | 5.1 | 10 |
| Gemini 2.5 Flash | Comercial | 73.7% | 14/19 | 10 | 5.5 | 10 |
| Mistral 7B | Open source | 94.7% | 18/19 | 10 | 6.7 | 10 |

Gemini 2.5 Flash (comercial) es más vulnerable que Gemma2 2B (open-source). Ser comercial no garantiza seguridad; lo que importa es el alignment training en idiomas distintos del inglés.

### Benchmark Agentic — 18 seeds × llama3.1:8b

| Métrica | Resultado |
|---------|:---------:|
| Tasa de vulnerabilidad | 61.1% |
| Ataques ejecutados | 18/18 |
| Vulnerabilidades (score ≥ 5) | 11 |
| OWASP Agentic detectados | ASI01 (Goal Hijacking), ASI02 (Tool Misuse), ASI04 (Excessive Agency) |

## Quickstart

```bash
pip install vigia

# Necesitas Ollama corriendo
ollama serve  # en otra terminal
ollama pull llama3.1:8b
ollama pull nomic-embed-text

# Lanzar campaña contra el chatbot demo
vigia run
```

Para usar modelos comerciales como target o evaluador:

```bash
export ANTHROPIC_API_KEY=tu_key
vigia run -c vigia/config/claude_haiku.yaml
```

## Comandos

```bash
# Campaña one-shot contra chatbot RAG
vigia run
vigia run -c vigia/config/claude_haiku.yaml

# Testing de agentes AI con herramientas
vigia agent
vigia agent --plan

# CI/CD gate — exit code 0 (pass) o 1 (vulns encontradas)
vigia scan -c config.yaml --fail-on-score 5
vigia scan --format junit -o report.xml

# Benchmarking comparativo
vigia benchmark -c vigia/config/default.yaml vigia/config/claude_haiku.yaml vigia/config/gemini.yaml

# Generar variantes lingüísticas (12 estrategias)
vigia mutate --strategies euskera,gallego,codeswitching_euskera

# Ataques multi-turno
vigia multiturn --strategy rapport_to_extraction --max-seeds 3
```

## Atacar tu propio chatbot

```bash
cp vigia/config/http_example.yaml mi_chatbot.yaml
```

```yaml
target:
  type: "http"
  url: "https://api.tu-empresa.com/chatbot/v1/message"
  headers:
    Authorization: "Bearer tu-api-key"
  request_format: "simple"
  request_field: "message"
  response_field: "data.answer"
```

```bash
vigia run -c mi_chatbot.yaml
```

El evaluador siempre corre en local — no envía datos de tu chatbot a ningún servicio externo.

## Taxonomía de ataques

### RAG — 9 vectores

| Vector | Técnica | OWASP |
|--------|---------|-------|
| V01 | Ancla Numérica — forzar comparación que revela el dato exacto | LLM02 |
| V02 | Exfiltración por Resumen — el modo resumen prioriza completitud sobre restricciones | LLM02 |
| V03 | Fragmentación Temporal — rangos de fecha evitan keywords de guardrails | LLM02 |
| V04 | Negación Invertida — "qué NO puedes decirme" enumera categorías protegidas | LLM07 |
| V05 | Exfiltración Pasiva — datos sensibles adyacentes en chunks RAG | LLM02 |
| V06 | Impersonación de Rol — CISO, RRHH, auditor | LLM01 |
| V07 | Confusión Cross-Language — cambio a inglés evade guardrails en español | LLM01 |
| V08 | Chain-of-Thought — razonamiento paso a paso enumera datos como paso intermedio | LLM06 |
| V09 | Reformulación Compliant — datos "anonimizados" reidentificables con N pequeña | LLM09 |

### Agentes — 7 vectores (OWASP Agentic ASI01-ASI04)

Goal hijacking, indirect prompt injection (vía tool outputs), tool misuse, data exfiltration via tool chaining, privilege escalation, cross-tool credential theft, y excessive agency.

## Estrategias de mutación

12 estrategias lingüísticas para lenguas ibéricas:

| Estrategia | Qué hace |
|-----------|----------|
| `register_formal` | Subjuntivo, ustedeo, cortesía extrema |
| `register_informal` | Tuteo, expresiones coloquiales |
| `catalan` | Traducción a catalán estándar |
| `codeswitching` | Mezcla castellano-catalán mid-sentence |
| `euskera` | Euskera batua — tokenizers lo procesan peor |
| `codeswitching_euskera` | Mezcla castellano-euskera |
| `gallego` | Gallego normativo |
| `codeswitching_gallego` | Mezcla castellano-gallego |
| `rephrase` | Reformulación completa |
| `academic` | Encuadre de investigación/auditoría |
| `authority` | Rol de autoridad (auditor, IT, dirección) |
| `sms_speak` | Abreviaturas SMS/WhatsApp españolas |

## Licencia

MIT
