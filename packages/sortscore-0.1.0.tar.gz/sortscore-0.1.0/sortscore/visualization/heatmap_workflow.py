"""Utilities for generating heatmap visualizations from analysis outputs.

This module centralizes the heatmap generation logic. It prepares the data for amino acid
and codon heatmaps and delegates plotting to `plot_heatmap`.
"""

import logging
import os
from types import SimpleNamespace
from typing import Optional, Tuple, List

import pandas as pd

from sortscore.analysis.variant_aggregation import aggregate_aa_data
from sortscore.utils.load_experiment import ExperimentConfig
from sortscore.visualization.heatmaps import plot_heatmap


def _score_column_name(experiment: ExperimentConfig) -> str:
    """Return the appropriate score column name based on avg_method."""
    if experiment.avg_method == 'simple-avg':
        return 'avgscore'
    suffix = experiment.avg_method.replace('-', '_')
    return f'avgscore_{suffix}'


def _build_aa_heatmap_config(experiment: ExperimentConfig) -> SimpleNamespace:
    """Create a lightweight config object tailored for AA heatmaps."""
    # AA heatmaps always use AA coordinates and an AA wild-type sequence.
    # The plotting code expects an "experiment-like" object with the same
    # attributes as ExperimentConfig (including num_positions).
    from sortscore.utils.sequence_parsing import get_reference_sequence

    wt_aa_seq = get_reference_sequence(experiment.wt_seq, "aa")
    return SimpleNamespace(
        experiment_name=experiment.experiment_name,
        num_aa=experiment.num_aa,
        num_positions=experiment.num_aa,
        min_pos=experiment.min_pos,
        max_pos=experiment.max_pos,
        wt_seq=wt_aa_seq,
        mutagenesis_type='aa',
        mutagenesis_variants=experiment.mutagenesis_variants
    )


def _compute_wt_score(
    data: pd.DataFrame,
    score_col: str,
    annotate_col: str,
    annotate_value: str
) -> Optional[float]:
    """Compute WT score from annotated rows if present."""
    if annotate_col not in data.columns:
        return pd.NA
    subset = data[data[annotate_col] == annotate_value]
    if len(subset) == 0 or score_col not in subset.columns:
        return pd.NA
    score_val = subset[score_col].mean()
    return float(score_val) if pd.notna(score_val) else pd.NA


def _tick_marks(
    values: pd.Series,
    wt_score: Optional[float],
    wt_label: str
) -> Tuple[Optional[List[float]], Optional[List[str]]]:
    """Generate tick positions and labels for colorbars."""
    if wt_score is None or pd.isna(wt_score):
        return None, None
    data_min = values.min()
    data_max = values.max()
    if pd.isna(data_min) or pd.isna(data_max):
        return None, None
    tick_values = [data_min, wt_score, data_max]
    tick_labels = [f'{data_min:.0f}', wt_label, f'{data_max:.0f}']
    return tick_values, tick_labels


def generate_heatmap_visualizations(
    scores_df: pd.DataFrame,
    experiment: ExperimentConfig,
    output_dir: str,
    fig_format: str = 'png',
    export_positional_averages: bool = False,
) -> None:
    """
    Generate amino acid and codon heatmaps for a completed analysis run.

    Parameters
    ----------
    scores_df : pd.DataFrame
        DataFrame containing final scored variants.
    experiment : ExperimentConfig
        Experiment configuration used for plotting context.
    output_dir : str
        Base output directory (figures will be written under ``output_dir/figures``).
    fig_format : str, optional
        Export figure format (default: ``'png'``).
    export_positional_averages : bool, optional
        Whether to export positional averages with colors for structure visualization.
    """
    logger = logging.getLogger(__name__)
    logger.info("Generating visualizations...")

    score_col = _score_column_name(experiment)
    figures_dir = os.path.join(output_dir, 'figures')
    os.makedirs(figures_dir, exist_ok=True)

    # Amino acid heatmap generation
    if 'aa_seq_diff' in scores_df.columns:
        has_aa_annotations = 'annotate_aa' in scores_df.columns
        has_dna_diff = 'dna_seq_diff' in scores_df.columns

        # AA score tables can be passed even when the experiment is DNA-based.
        # If this is already AA-level data, do not re-aggregate.
        if experiment.mutagenesis_type == 'aa' or (has_aa_annotations and not has_dna_diff):
            logger.info("AA data creation: scores_df shape %s", scores_df.shape)
            aa_data = scores_df[['aa_seq_diff', 'annotate_aa', score_col]].copy()
            logger.info("AA data created: aa_data shape %s", aa_data.shape)
        else:
            # For DNA variant type, aggregate to AA level
            aa_data = aggregate_aa_data(scores_df, score_col)
            logger.info(
                "AA data aggregated: aa_data shape %s; columns: %s",
                aa_data.shape,
                ", ".join(aa_data.columns),
            )

        wt_score = _compute_wt_score(aa_data, score_col, 'annotate_aa', 'synonymous')
        if pd.isna(wt_score):
            # Some AA tables label no-change entries as wt_dna and may not contain additional synonymous rows.
            wt_score = _compute_wt_score(aa_data, score_col, 'annotate_aa', 'wt_dna')
        if pd.isna(wt_score) and 'annotate_dna' in scores_df.columns:
            # In DNA/codon workflows, fall back to DNA WT anchor when AA aggregation
            # contains only missense rows.
            wt_score = _compute_wt_score(scores_df, score_col, 'annotate_dna', 'wt_dna')
        if pd.isna(wt_score):
            raise ValueError(
                "Cannot generate AA heatmap: missing required wt_score from "
                "'annotate_aa' == 'synonymous' or 'wt_dna', and no 'annotate_dna' == 'wt_dna' fallback "
                f"using score column '{score_col}'."
            )
        wt_score = float(wt_score)
        logger.info("Synonymous-WT score from AA data: %s", wt_score)

        tick_values, tick_labels = _tick_marks(aa_data[score_col], wt_score, "WT Avg")
        aa_config = _build_aa_heatmap_config(experiment)

        plot_kwargs = dict(
            tick_values=tick_values,
            tick_labels=tick_labels,
            export_heatmap=True,
            output=figures_dir,
            fig_format=fig_format,
            export_matrix=True,
            export_positional_averages=export_positional_averages,
            biophysical_properties=experiment.biophysical_prop,
        )

        plot_heatmap(
            aa_data,
            score_col,
            aa_config,
            wt_score=wt_score,
            heatmap_basename="aa_heatmap",
            matrix_basename="aa_heatmap_matrix",
            **plot_kwargs,
        )

        aa_heatmap_file = os.path.join(figures_dir, f"{experiment.experiment_name}_aa_heatmap.{fig_format}")
        logger.info("Saved AA heatmap to %s", aa_heatmap_file)

    # Codon heatmap generation (DNA-level plots only make sense when plotting DNA-level scores)
    if experiment.mutagenesis_type == 'codon' and 'annotate_dna' in scores_df.columns:
        wt_score_codon = _compute_wt_score(scores_df, score_col, 'annotate_dna', 'wt_dna')
        if pd.isna(wt_score_codon):
            raise ValueError(
                f"Cannot generate codon heatmap: missing required wt_score from "
                f"'annotate_dna' == 'wt_dna' using score column '{score_col}'."
            )
        wt_score_codon = float(wt_score_codon)
        logger.info("Found WT score for codon heatmap: %s", wt_score_codon)

        tick_values_codon, tick_labels_codon = _tick_marks(
            scores_df[score_col],
            wt_score_codon,
            "WT",
        )

        plot_kwargs = dict(
            tick_values=tick_values_codon,
            tick_labels=tick_labels_codon,
            export_heatmap=True,
            output=figures_dir,
            fig_format=fig_format,
            export_matrix=True,
            export_positional_averages=export_positional_averages,
            biophysical_properties=experiment.biophysical_prop,
        )

        plot_heatmap(
            scores_df,
            score_col,
            experiment,
            wt_score=wt_score_codon,
            heatmap_basename="codon_heatmap",
            matrix_basename="codon_heatmap_matrix",
            **plot_kwargs,
        )

        codon_heatmap_file = os.path.join(figures_dir, f"{experiment.experiment_name}_codon_heatmap.{fig_format}")
        logger.info("Saved codon heatmap to %s", codon_heatmap_file)
