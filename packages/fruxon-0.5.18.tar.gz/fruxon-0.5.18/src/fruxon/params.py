"""Parsing of the various ways a CLI caller can supply agent parameters.

Top-class CLIs accept the same value in several forms because callers are in
different contexts: a person typing at a terminal, a CI step pasting JSON, a
script piping data over stdin, a Makefile reading from a file. We collapse
all of those into one ``dict[str, object]`` here so the ``run`` command
doesn't have to care which path was used.

Supported forms (mix freely on a single command):

* ``-p key=value``                — string value (most common)
* ``-p key=-``                    — read value from stdin until EOF
                                    (``echo prompt | fruxon run X -p prompt=-``)
* ``-p key=@./file.json``         — read value from a JSON / text file
* ``-p key:=42``                  — typed value (parsed as JSON; lets you
                                    pass numbers, booleans, arrays, nested
                                    objects without quoting headaches)
* ``-p @./params.json``           — splat a JSON object into the params dict
* ``--params ./params.json``      — same as above, more discoverable
* ``--params -`` (or ``--stdin``) — read the whole JSON object from stdin

The shapes don't conflict: if two sources name the same key, later wins
in the order they're processed (``--params`` first, then ``-p`` flags in
order). That matches how every other major CLI resolves overlap.
"""

from __future__ import annotations

import json
import sys
from collections.abc import Iterable
from pathlib import Path


class ParamError(ValueError):
    """Raised when a parameter input can't be parsed.

    The message is shaped for direct ``_say_err(str(e), hint=...)`` rendering
    in the CLI — short, declarative, no trailing punctuation.
    """


def parse(
    *,
    flag_values: Iterable[str] | None,
    params_file: str | None,
    stdin_input: bool,
    stdin_reader=None,
) -> dict[str, object] | None:
    """Collapse every supported input form into one params dict.

    Returns ``None`` when no parameter input was supplied — callers should
    treat that as "send no ``parameters`` field in the request body" rather
    than ``{}`` (which is semantically different to most backends).

    ``stdin_reader`` is parameterized for tests; production callers leave
    it ``None`` and we read ``sys.stdin``.
    """
    result: dict[str, object] = {}
    saw_input = False

    # Stdin is a one-shot resource: ``-p key=-``, ``--stdin``, and
    # ``--params -`` all consume it. Cache the first read so we can serve
    # later consumers from memory and surface a clear error if two flags
    # both want stdin to themselves (the second read returns empty, which
    # is almost certainly not what the user meant).
    stdin_cache: dict[str, str] = {}

    def read_stdin_once() -> str:
        if "value" not in stdin_cache:
            stdin_cache["value"] = (stdin_reader or sys.stdin).read()
        return stdin_cache["value"]

    if params_file is not None:
        saw_input = True
        result.update(_load_params_file(params_file, read_stdin_once=read_stdin_once))

    if stdin_input:
        saw_input = True
        result.update(_parse_stdin_object(read_stdin_once()))

    if flag_values:
        for raw in flag_values:
            saw_input = True
            key, value = _parse_flag(raw, read_stdin_once=read_stdin_once)
            if key is None:
                # `-p @file.json` form — splat the file directly into the dict.
                if not isinstance(value, dict):
                    raise ParamError(
                        f"`-p @{value}` must contain a JSON object at the top level"
                        if isinstance(value, str)
                        else "`-p @file` must contain a JSON object at the top level"
                    )
                result.update(value)
            else:
                result[key] = value

    return result if saw_input else None


def _parse_flag(raw: str, *, read_stdin_once) -> tuple[str | None, object]:
    """Parse a single ``-p ...`` argument.

    Returns ``(key, value)`` for the common forms, or ``(None, value)`` for
    the ``-p @file.json`` splat form (which contributes a whole object).
    ``read_stdin_once`` is the cached-stdin reader from :func:`parse`,
    used for the ``key=-`` shorthand.
    """
    raw = raw.strip()
    if not raw:
        raise ParamError("Empty parameter")

    # Whole-object splat: `-p @path/to/params.json`
    if raw.startswith("@"):
        path = raw[1:]
        if not path:
            raise ParamError("`-p @<path>` is missing the file path")
        return None, _load_json_file(path)

    # Typed value: `key:=42`, `key:=true`, `key:=[1,2,3]`, `key:={"a":1}`
    typed_sep = _find_unquoted(raw, ":=")
    if typed_sep != -1:
        key = raw[:typed_sep].strip()
        if not key:
            raise ParamError(f"Missing key before `:=` in `{raw}`")
        rhs = raw[typed_sep + 2 :]
        return key, _parse_typed_value(rhs, original=raw)

    # Standard scalar: `key=value`. RHS can also be `@file` to pull
    # the value from disk (string contents, or JSON parsed when valid).
    if "=" not in raw:
        raise ParamError(f"Invalid parameter `{raw}` — use `key=value`, `key:=42`, or `@file.json`")
    key, rhs = raw.split("=", 1)
    key = key.strip()
    if not key:
        raise ParamError(f"Missing key before `=` in `{raw}`")

    # Stdin shorthand: `key=-` consumes stdin as the value, preserving
    # newlines so long-form prompts survive intact. Trailing newline from
    # the shell heredoc is stripped because that's almost never wanted.
    if rhs == "-":
        text = read_stdin_once()
        if text.endswith("\n"):
            text = text[:-1]
        return key, text

    if rhs.startswith("@"):
        path = rhs[1:]
        if not path:
            raise ParamError(f"`{key}=@<path>` is missing the file path")
        return key, _load_value_file(path)

    return key, rhs


def _parse_typed_value(rhs: str, *, original: str) -> object:
    """Decode the right-hand side of ``key:=…`` as a JSON literal."""
    rhs = rhs.strip()
    if rhs.startswith("@"):
        path = rhs[1:]
        if not path:
            raise ParamError(f"`{original}` is missing the file path after `@`")
        return _load_json_file(path)
    try:
        return json.loads(rhs)
    except json.JSONDecodeError as exc:
        raise ParamError(f"`{original}` — `{rhs}` is not valid JSON ({exc.msg})") from exc


def _load_params_file(path: str, *, read_stdin_once) -> dict[str, object]:
    """Load the top-level JSON object passed via ``--params``.

    Accepts ``-`` as a sentinel for "read from stdin" so callers can do
    ``cat params.json | fruxon run my-agent --params -``.
    """
    if path == "-":
        return _parse_stdin_object(read_stdin_once())
    data = _load_json_file(path)
    if not isinstance(data, dict):
        raise ParamError(f"`--params {path}` must contain a JSON object at the top level")
    return data


def _parse_stdin_object(raw: str) -> dict[str, object]:
    if not raw or raw.isspace():
        raise ParamError("No JSON found on stdin")
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ParamError(f"Invalid JSON on stdin: {exc.msg}") from exc
    if not isinstance(data, dict):
        raise ParamError("Stdin must contain a JSON object at the top level")
    return data


def _load_json_file(path: str) -> object:
    """Read a file as JSON. Used for whole-object splats and typed scalars."""
    try:
        text = Path(path).expanduser().read_text(encoding="utf-8")
    except FileNotFoundError as exc:
        raise ParamError(f"File not found: {path}") from exc
    except OSError as exc:
        raise ParamError(f"Could not read {path}: {exc.strerror or exc}") from exc
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise ParamError(f"Invalid JSON in {path}: {exc.msg}") from exc


def _load_value_file(path: str) -> object:
    """Read a file as a parameter value.

    JSON files (``.json``) parse to their structured value so callers can do
    ``-p config=@settings.json``; everything else loads as raw text so
    ``-p prompt=@prompt.md`` works for the long-form-prompt use case.
    """
    raw = _read_text(path)
    if path.endswith(".json"):
        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ParamError(f"Invalid JSON in {path}: {exc.msg}") from exc
    return raw


def _read_text(path: str) -> str:
    try:
        return Path(path).expanduser().read_text(encoding="utf-8")
    except FileNotFoundError as exc:
        raise ParamError(f"File not found: {path}") from exc
    except OSError as exc:
        raise ParamError(f"Could not read {path}: {exc.strerror or exc}") from exc


def _find_unquoted(text: str, needle: str) -> int:
    """Find ``needle`` outside of single- or double-quoted runs.

    Lets users write ``-p tags:=["a:=b"]`` without the inner ``:=`` being
    mistaken for the type separator. Heavy-handed quoting parsers aren't
    worth it at the CLI argv layer — single pass is enough for the cases
    that show up in practice.
    """
    in_quote: str | None = None
    i = 0
    n = len(needle)
    while i <= len(text) - n:
        ch = text[i]
        if in_quote:
            if ch == in_quote and text[i - 1] != "\\":
                in_quote = None
            i += 1
            continue
        if ch in ("'", '"'):
            in_quote = ch
            i += 1
            continue
        if text[i : i + n] == needle:
            return i
        i += 1
    return -1
