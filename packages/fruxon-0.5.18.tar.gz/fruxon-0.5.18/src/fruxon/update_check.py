"""Background check for a newer ``fruxon`` release on PyPI.

Runs at the tail of each CLI command and prints a one-liner to stderr if a
newer version is available. Cached for 24 h under
``$FRUXON_CONFIG_DIR/last-update-check.json`` so we don't hit PyPI every
invocation. Failures are completely silent — a broken update check should
never block a user from running their agent.

The same env-var knobs that govern branding govern the notifier:

* ``FRUXON_NO_BANNER=1`` — disables it (it's part of the chrome).
* ``NO_COLOR=1``         — disables the styled rendering.
* ``CI=true``            — disables it (don't noise up CI logs).
* ``FRUXON_NO_UPDATE_CHECK=1`` — opt-out without disabling other chrome.
"""

from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request
from collections.abc import Callable
from importlib import metadata
from pathlib import Path

from fruxon import credentials

PYPI_URL = "https://pypi.org/pypi/fruxon/json"
CACHE_FILE = "last-update-check.json"

# How often we ask PyPI. 24h is long enough that a typical daily user only
# triggers one request per day, short enough that they hear about a release
# the day after it ships.
CACHE_TTL_SECONDS = 24 * 60 * 60

# Network timeout. Generous enough to forgive a slow link, short enough that
# the CLI doesn't feel laggy when PyPI itself is wobbly.
REQUEST_TIMEOUT_SECONDS = 2.0


def maybe_notify(
    *,
    current: str | None = None,
    fetcher: Callable[[], str] | None = None,
    now: Callable[[], float] | None = None,
) -> str | None:
    """Return a one-line "update available" message, or ``None`` for nothing.

    Caller decides where to print it (stderr in the CLI, suppressed in
    tests, …). All side-effects beyond the cache file write live in the
    caller — keeps this module trivial to test.

    Parameters are injectable for tests; production callers leave them all
    ``None``.
    """
    if not _enabled():
        return None

    if current is None:
        try:
            current = metadata.version("fruxon")
        except metadata.PackageNotFoundError:
            # Running from source. There's no "current version" to compare
            # against, so don't pester the user.
            return None

    now_fn = now or time.time
    cache = _load_cache()
    if cache and (now_fn() - cache.get("checked_at", 0)) < CACHE_TTL_SECONDS:
        latest = cache.get("latest")
    else:
        try:
            latest = (fetcher or _fetch_latest)()
        except Exception:
            # Any failure is silent. A missing/slow/flaky PyPI is never an
            # excuse to disrupt the user's command.
            return None
        _save_cache({"checked_at": now_fn(), "latest": latest})

    if not latest:
        return None
    if _is_newer(latest, current):
        return f"A newer fruxon is available: v{current} → v{latest}. Upgrade with `pip install -U fruxon`."
    return None


def _fetch_latest() -> str | None:
    """Hit PyPI's public JSON endpoint and return the released version.

    Uses ``urllib`` to avoid taking a heavyweight HTTP dependency for one
    cold-path call per day.
    """
    req = urllib.request.Request(
        PYPI_URL,
        headers={"Accept": "application/json", "User-Agent": "fruxon-cli/update-check"},
    )
    try:
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT_SECONDS) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, json.JSONDecodeError, TimeoutError, OSError):
        return None
    return payload.get("info", {}).get("version")


def _enabled() -> bool:
    if os.environ.get("FRUXON_NO_UPDATE_CHECK", "").strip().lower() in {"1", "true", "yes"}:
        return False
    if os.environ.get("FRUXON_NO_BANNER", "").strip().lower() in {"1", "true", "yes"}:
        return False
    if os.environ.get("CI", "").strip().lower() in {"1", "true", "yes"}:
        return False
    return True


def _cache_path() -> Path:
    return credentials.config_dir() / CACHE_FILE


def _load_cache() -> dict | None:
    path = _cache_path()
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def _save_cache(payload: dict) -> None:
    path = _cache_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload) + "\n", encoding="utf-8")
    except OSError:
        # If we can't write the cache, the next run just checks PyPI again.
        # Not worth interrupting the user over.
        pass


def _is_newer(latest: str, current: str) -> bool:
    """Compare two version strings using packaging's ordering when available.

    Falls back to a lexicographic tuple compare on dotted-integer segments
    if ``packaging`` isn't installed (it usually is, since pip pulls it in,
    but the SDK doesn't list it as a direct dependency).
    """
    try:
        from packaging.version import InvalidVersion, Version

        try:
            return Version(latest) > Version(current)
        except InvalidVersion:
            return False
    except ImportError:
        return _tuple_version(latest) > _tuple_version(current)


def _tuple_version(v: str) -> tuple[int, ...]:
    parts: list[int] = []
    for piece in v.split("."):
        digits = ""
        for ch in piece:
            if ch.isdigit():
                digits += ch
            else:
                break
        parts.append(int(digits) if digits else 0)
    return tuple(parts)
