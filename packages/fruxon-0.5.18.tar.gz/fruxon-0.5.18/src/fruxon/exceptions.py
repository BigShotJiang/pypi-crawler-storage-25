"""Exceptions for the Fruxon SDK."""

from pathlib import Path


class FruxonError(Exception):
    """Base exception for all Fruxon SDK errors."""


class FruxonAPIError(FruxonError):
    """Raised when the Fruxon API returns an error response."""

    def __init__(self, status: int, title: str, detail: str):
        self.status = status
        self.title = title
        self.detail = detail
        super().__init__(f"{status} {title}: {detail}")


class AuthenticationError(FruxonAPIError):
    """Raised on 401 Unauthorized responses."""


class ForbiddenError(FruxonAPIError):
    """Raised on 403 Forbidden responses."""


class InsufficientScopeError(ForbiddenError):
    """Raised when a 403 carries an ``insufficient_scope`` problem-detail body.

    The Fruxon API surfaces missing-scope failures with a typed body
    ``{error: "insufficient_scope", required, granted, hint}`` so
    clients can render an actionable error without parsing prose. This
    subclass of :class:`ForbiddenError` carries the three structured
    fields so a CLI can show ``✗ This key can't agents:write
    (granted: agents:read, traces:read).  Mint: fruxon keys create
    --preset builder``.
    """

    def __init__(
        self,
        status: int,
        title: str,
        detail: str,
        required: str,
        granted: list[str],
        hint: str,
    ):
        super().__init__(status, title, detail)
        self.required = required
        self.granted = granted
        self.hint = hint


class NotFoundError(FruxonAPIError):
    """Raised on 404 Not Found responses."""


class ValidationError(FruxonAPIError):
    """Raised on 400 or 422 responses."""


class FruxonConnectionError(FruxonError):
    """Raised when the API is unreachable."""


class MultipleAgentsError(FruxonError):
    """Raised when multiple agent entry points are detected."""

    def __init__(self, entry_points: list[tuple[Path, str]]):
        self.entry_points = entry_points
        super().__init__(f"Multiple agents detected: {len(entry_points)} entry points found")
