"""Client for the unauthenticated CLI-auth endpoints on the Fruxon API.

Backs ``fruxon login``'s browser flow:

* :func:`start_grant` — POST ``/v1/cliAuth:start``. Returns the
  ``grantCode`` + verification URL the CLI must open in the browser.
* :func:`poll_grant` — GET ``/v1/cliAuth/{grantCode}``. Returns one of
  :class:`PollPending`, :class:`PollApproved`, :class:`PollExpired`.

Lives outside :mod:`fruxon.fruxon` because the main :class:`FruxonClient`
class requires an API key at construction time — and these endpoints
exist precisely to get one. Cleaner to keep them on a separate, narrow
surface than to bolt an "auth-less mode" onto FruxonClient.

The on-the-wire shape matches Stripe CLI / Supabase CLI:
  - ``start`` returns ``{grantCode, verificationUrl, expiresInSeconds, pollIntervalSeconds}``
  - ``poll`` returns 202 (pending) / 200 + body (approved) / 410 (expired+consumed).

Only stdlib networking — keeping the SDK install slim. Same pattern as
the rest of :mod:`fruxon.fruxon`.
"""

from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass

from fruxon._ssl import context_for as _ssl_context_for
from fruxon.exceptions import FruxonAPIError, FruxonConnectionError

# Path constants. Kept in sync with ``Routes.CliAuth*`` on the backend.
# camelCase mirrors the backend's AIP-136 convention (no kebab-case).
_PATH_START = "/v1/cliAuth:start"
_PATH_POLL_TEMPLATE = "/v1/cliAuth/{code}"

# Default timeout for a single HTTP call. The polling loop runs many of
# these so a long timeout per request would hide the user from server
# trouble for minutes; 30s is plenty for either endpoint.
DEFAULT_TIMEOUT_SECONDS = 30.0


@dataclass(frozen=True)
class GrantStart:
    """Response from ``POST /v1/cliAuth:start``."""

    grant_code: str
    verification_url: str
    expires_in_seconds: int
    poll_interval_seconds: int


@dataclass(frozen=True)
class PollPending:
    """The grant is still waiting for the user to approve in the browser."""


@dataclass(frozen=True)
class PollApproved:
    """The user approved; here are the credentials the CLI should save.

    ``tenant_slug`` is what the CLI persists as its ``org`` — every
    authenticated API route resolves the ``{tenant}`` path segment by
    slug. ``tenant_id`` is the opaque Guid, kept for reference only;
    storing it as the org produces credentials that 404 on every call.
    """

    api_key: str
    tenant_id: str
    tenant_slug: str | None
    tenant_name: str | None


@dataclass(frozen=True)
class PollExpired:
    """Terminal — the grant expired or has already been consumed.

    The CLI's recovery is the same in both cases (start over), so we
    don't distinguish them in the public type. Mirrors what the
    backend collapses into a 410 Gone response.
    """


PollResult = PollPending | PollApproved | PollExpired


def start_grant(base_url: str, *, timeout: float = DEFAULT_TIMEOUT_SECONDS) -> GrantStart:
    """Begin a CLI login flow. Returns the verification URL + grant code.

    Network errors raise :class:`FruxonConnectionError`; API errors
    (rate limit, 5xx) raise :class:`FruxonAPIError`. The CLI surfaces
    these with their normal hint mapping.
    """
    url = base_url.rstrip("/") + _PATH_START
    req = urllib.request.Request(
        url,
        method="POST",
        # Empty body — backend accepts an empty POST. ``Content-Type``
        # set so the server's request-parser doesn't 415 on us.
        data=b"{}",
        headers={
            "Accept": "application/json",
            "Content-Type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=_ssl_context_for(base_url)) as resp:
            body = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        _raise_api_error(e)
    except urllib.error.URLError as e:
        raise FruxonConnectionError(str(e.reason)) from e

    return GrantStart(
        grant_code=str(body["grantCode"]),
        verification_url=str(body["verificationUrl"]),
        expires_in_seconds=int(body.get("expiresInSeconds", 600)),
        poll_interval_seconds=int(body.get("pollIntervalSeconds", 2)),
    )


def poll_grant(
    base_url: str,
    grant_code: str,
    *,
    timeout: float = DEFAULT_TIMEOUT_SECONDS,
) -> PollResult:
    """Check the grant's status. Maps HTTP codes to the typed result union.

    HTTP semantics:
      - 200 OK + body → :class:`PollApproved`
      - 202 Accepted  → :class:`PollPending`
      - 410 Gone      → :class:`PollExpired`
      - 4xx / 5xx     → :class:`FruxonAPIError`

    The mapping lives here (not in callers) so the CLI's polling loop
    can branch on a clean type union instead of inspecting HTTP codes.
    """
    url = base_url.rstrip("/") + _PATH_POLL_TEMPLATE.format(code=urllib.parse.quote(grant_code, safe=""))
    req = urllib.request.Request(
        url,
        method="GET",
        headers={"Accept": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=_ssl_context_for(base_url)) as resp:
            status = resp.status
            if status == 202:
                # Read+discard the body so the connection can be reused.
                resp.read()
                return PollPending()
            payload = json.loads(resp.read().decode("utf-8"))
            return PollApproved(
                api_key=str(payload["apiKey"]),
                tenant_id=str(payload.get("tenantId", "")),
                tenant_slug=_str_or_none(payload.get("tenantSlug")),
                tenant_name=_str_or_none(payload.get("tenantName")),
            )
    except urllib.error.HTTPError as e:
        if e.code == 410:
            return PollExpired()
        # 4xx / 5xx other than 410 are real API errors — surface them.
        _raise_api_error(e)
    except urllib.error.URLError as e:
        raise FruxonConnectionError(str(e.reason)) from e


def _str_or_none(value: object) -> str | None:
    if isinstance(value, str) and value:
        return value
    return None


def _raise_api_error(error: urllib.error.HTTPError) -> None:
    """Replicate :func:`fruxon.fruxon._raise_api_error` for this module.

    Pulled out instead of imported to keep this file standalone and
    importable before :mod:`fruxon.fruxon` is initialized (which itself
    imports a lot — keyring, rich, etc. via the CLI chain). The error
    bodies on these endpoints have the same shape as the rest of the
    API, so the parser is intentionally identical.
    """
    try:
        body = json.loads(error.read().decode("utf-8"))
        title = body.get("title") or body.get("message") or "Error"
        detail = body.get("detail") or body.get("details") or ""
    except (json.JSONDecodeError, UnicodeDecodeError):
        title = "Error"
        detail = str(error)
    raise FruxonAPIError(status=error.code, title=title, detail=detail) from error
