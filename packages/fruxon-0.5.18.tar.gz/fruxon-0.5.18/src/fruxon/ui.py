"""Shared visual language for the Fruxon CLI.

Every user-facing line goes through one of the four ``say_*`` helpers so
the CLI stays visually coherent across commands. Pattern lifted from the
best-in-class CLIs we studied (gh, stripe, claude code): a single leading
glyph in a consistent color tells the user the *kind* of message at a
glance — success, failure, warning, neutral info — before they read a
single word.

All four write to stderr so they never contaminate stdout, which is
reserved for the pipe-safe primary result of each command (a streamed
text body, a JSON payload).
"""

from __future__ import annotations

import os
from importlib import metadata

from rich.console import Console
from rich.text import Text

# ─────────────────────────────────────────────────────────────────────────────
# Brand
# ─────────────────────────────────────────────────────────────────────────────

# Default Fruxon brand color — kept in sync with --color-fd-primary on the
# docs/app sides. Overridable per-user via ``FRUXON_BRAND_COLOR``.
DEFAULT_BRAND_COLOR = "#c43a2a"

# Brand mark glyph used in the compact header and welcome surfaces. Picked
# in the spirit of Claude Code's ✻ — a single dingbat in the brand color
# beats a six-line ASCII slab for routine CLI output: present, on-brand,
# and doesn't eat vertical space every time you run a command.
# Override-able via ``FRUXON_GLYPH`` if you want a different mark.
DEFAULT_GLYPH = "✻"

# Where users go to mint an API key. Overridable so this works against
# staging / self-hosted dashboards without source edits.
DEFAULT_DASHBOARD_URL = "https://app.fruxon.com/settings/api-keys"

# Public docs site. Surfaced in the welcome screen, the agent-mode
# manifest, and the top-level ``--help`` epilog so users (and LLMs)
# always have one click to "what does this thing do." Overridable for
# the same reason the dashboard URL is — staging / self-hosted setups
# may run their own docs mirror.
DEFAULT_DOCS_URL = "https://docs.fruxon.com"
DEFAULT_CLI_DOCS_URL = "https://docs.fruxon.com/guides/cli"


def brand_color() -> str | None:
    """Resolve the active brand color.

    Honors three signals, in order:

    1. ``NO_COLOR`` (any value) — return ``None`` so rich emits plain text.
       Standard convention; see https://no-color.org.
    2. ``FRUXON_BRAND_COLOR`` — explicit override (any rich-compatible
       color string: ``#c43a2a``, ``red``, ``bright_magenta``, etc.).
    3. The default :data:`DEFAULT_BRAND_COLOR`.
    """
    if "NO_COLOR" in os.environ:
        return None
    return os.environ.get("FRUXON_BRAND_COLOR") or DEFAULT_BRAND_COLOR


def glyph() -> str:
    return os.environ.get("FRUXON_GLYPH") or DEFAULT_GLYPH


def dashboard_url() -> str:
    return os.environ.get("FRUXON_DASHBOARD_URL") or DEFAULT_DASHBOARD_URL


def dashboard_root() -> str:
    """Best-effort dashboard root — strip the ``/settings/api-keys`` tail.

    The dashboard URL we store points at the API-keys page (the most
    common entry for ``fruxon login``). Deep links — connect-an-integration,
    fill-config-secrets — want the root, so we lop the trailing settings
    path off when present and fall back to the configured URL otherwise.
    """
    url = dashboard_url().rstrip("/")
    for tail in ("/settings/api-keys", "/settings"):
        if url.endswith(tail):
            return url[: -len(tail)] or url
    return url


def integration_connect_url(integration_id: str, config_id: str | None = None) -> str:
    """Build the dashboard URL where a user finishes connecting an integration.

    Used by post-write commands (``integrations create``, ``agents
    revisions create``) to print a clickable link the moment a config
    needs human input — OAuth consent, secret values the CLI didn't
    supply, etc. The path matches the dashboard's integration-detail
    routes; if it ever moves, override via ``FRUXON_DASHBOARD_URL`` and
    the deep link follows.
    """
    base = dashboard_root()
    if config_id:
        return f"{base}/integrations/{integration_id}/configs/{config_id}"
    return f"{base}/integrations/{integration_id}"


def docs_url() -> str:
    """Resolve the public docs root. Overridable via ``FRUXON_DOCS_URL``."""
    return os.environ.get("FRUXON_DOCS_URL") or DEFAULT_DOCS_URL


def cli_docs_url() -> str:
    """Resolve the CLI-guide page URL. Overridable via ``FRUXON_CLI_DOCS_URL``."""
    return os.environ.get("FRUXON_CLI_DOCS_URL") or DEFAULT_CLI_DOCS_URL


def resolve_output_format(
    explicit: str | None,
    *,
    human_default: str = "text",
    agent_default: str = "json",
) -> str:
    """Pick the right ``--output`` format for the current invocation.

    Rule: if the user passed ``--output X`` explicitly, honor it. If
    not, return ``human_default`` for an interactive person and
    ``agent_default`` when :func:`is_agent_mode` is true. AI agents
    almost universally want parseable output; making them ask for
    ``--output json`` on every command is friction with no upside.

    Use ``human_default="text"`` / ``agent_default="json"`` for any
    command that has both rendering paths. ``human_default="table"``
    for commands whose human-facing form is a table (``agents list``).
    """
    if explicit is not None:
        return explicit
    return agent_default if is_agent_mode() else human_default


def is_agent_mode() -> bool:
    """Whether the CLI is being driven by another program (AI agent, CI).

    Detected via, in order:

    * ``FRUXON_AGENT_MODE=1`` — explicit opt-in. Use this when you want
      parseable output from a script and don't want to set the other
      signals.
    * ``CLAUDECODE=1`` — Claude Code sets this in the env of every shell
      command it spawns. If we're running underneath an agent that wants
      the result, not the chrome, we should oblige.
    * ``CI=true`` / ``CI=1`` — the universal "non-interactive automation"
      signal; build pipelines, scheduled jobs, and most agent runtimes
      set this.

    In agent mode, ``banner_enabled()`` is automatically false and the
    bare ``fruxon`` welcome emits a JSON manifest instead of a styled
    block. The intent is: an LLM or script reading our stdout should
    get a parseable, predictable surface — not a banner it has to learn
    to ignore.
    """
    truthy = {"1", "true", "yes"}
    for var in ("FRUXON_AGENT_MODE", "CLAUDECODE", "CI"):
        if os.environ.get(var, "").strip().lower() in truthy:
            return True
    return False


def banner_enabled() -> bool:
    """Whether to show any branding chrome at all.

    Set ``FRUXON_NO_BANNER=1`` to suppress the logo + one-line header
    everywhere — useful in CI logs or for users who just want output.
    Agent mode (see :func:`is_agent_mode`) also disables the banner
    implicitly so AI agents get a clean parseable surface.
    """
    if os.environ.get("FRUXON_NO_BANNER", "").strip().lower() in {"1", "true", "yes"}:
        return False
    if is_agent_mode():
        return False
    return True


def get_version() -> str:
    """Resolve the package version.

    Three sources, in order of fidelity:

    1. ``fruxon._version`` — generated by hatch-vcs at build time. This
       is the only source that knows we're on a dev commit *past* the
       last tag (e.g. ``0.5.3.dev1+g3c52e8b``). We surface that as
       ``0.5.3-dev`` so a developer running from a clone never sees a
       stale tag version.
    2. ``importlib.metadata`` — the installed distribution's metadata.
       Authoritative when fruxon was installed normally (pip / uv).
    3. ``"dev"`` — last resort when neither is available.

    The dev-source case used to lie about being v0.4.0 even on HEAD,
    because step 2 was the only check. Adding step 1 makes the banner
    truthful in `PYTHONPATH=src python3 -m fruxon` workflows.
    """
    try:
        from fruxon._version import __version__ as vcs_version
    except ImportError:
        vcs_version = ""

    if vcs_version:
        # hatch-vcs encodes dev state as PEP 440 local version segments
        # (``0.5.3.dev1+g3c52e8b.d20260513``). Strip those to a short
        # ``0.5.3-dev`` for the banner — anyone debugging can read the
        # full string from ``fruxon._version.__version__``.
        if ".dev" in vcs_version or "+" in vcs_version:
            base = vcs_version.split(".dev")[0].split("+")[0]
            return f"{base}-dev"
        return vcs_version

    try:
        return metadata.version("fruxon")
    except metadata.PackageNotFoundError:
        return "dev"


# ─────────────────────────────────────────────────────────────────────────────
# Console
# ─────────────────────────────────────────────────────────────────────────────


def _force_truecolor() -> bool:
    """Heuristic for terminals that *do* render 24-bit color but don't
    advertise it via the standard ``COLORTERM`` env var.

    The motivating case is PyCharm's built-in terminal (JediTerm). It
    has supported 24-bit color for years but doesn't set
    ``COLORTERM=truecolor``, so Rich auto-detects "256-color," our
    brand hex (``#c43a2a``) gets downgraded to ANSI Red, and PyCharm's
    IDE theme then remaps ANSI Red to a warm orange — the brand
    asterisk ends up clearly orange in PyCharm even though every
    other terminal renders it as the intended brick-red.

    Forcing the Console into truecolor mode here makes Rich emit the
    raw ``\\x1b[38;2;R;G;Bm`` escape that JediTerm honors. Users
    don't need to change their IDE settings.

    Limited to JediTerm (and obvious siblings) so we don't enable
    truecolor blindly on terminals that genuinely can't render it —
    that would surface as visible escape gibberish.
    """
    # Rich already detects truecolor from this; no override needed.
    if os.environ.get("COLORTERM", "").lower() in {"truecolor", "24bit"}:
        return False
    return "JediTerm" in os.environ.get("TERMINAL_EMULATOR", "")


stderr = Console(stderr=True, color_system="truecolor" if _force_truecolor() else "auto")


# ─────────────────────────────────────────────────────────────────────────────
# Welcome + compact header
# ─────────────────────────────────────────────────────────────────────────────


def print_welcome(*, tips: list[str] | None = None) -> None:
    """Multi-line welcome shown on bare ``fruxon``.

    Designed in the spirit of Claude Code's startup: brand glyph + name on
    one bold line, then a tiny dimmed help block. Compact enough that it
    doesn't dominate the terminal, but unambiguously branded.
    """
    if not banner_enabled():
        return

    color = brand_color()
    glyph_style = color or ""
    title_style = f"bold {color}" if color else "bold"

    head = Text()
    head.append(f"{glyph()} ", style=glyph_style)
    head.append("Welcome to Fruxon", style=title_style)
    head.append(f"  v{get_version()}", style="dim")
    stderr.print(head)

    if tips:
        stderr.print()
        for line in tips:
            # Rich's Console.print honors `[bold]…[/]` markup inside the
            # string. Applying `style="dim"` on top means everything is dim
            # by default, with the marked-up spans rendered as bold-dim —
            # the exact treatment Claude Code uses for its tip block.
            stderr.print(f"  {line}", style="dim")


def print_banner(*, subtitle: str | None = None) -> None:
    """One-line branded header used on routine subcommands like ``fruxon run``.

    Goes to stderr so it doesn't contaminate piped output — every command's
    primary result (text stream, JSON dump) lands on stdout.
    """
    if not banner_enabled():
        return

    color = brand_color()
    line = Text()
    line.append(f"{glyph()} ", style=color or "")
    line.append("Fruxon", style=f"bold {color}" if color else "bold")
    line.append(f"  v{get_version()}", style="dim")
    if subtitle:
        line.append("  ·  ", style="dim")
        line.append(subtitle, style="dim")
    stderr.print(line)


# ─────────────────────────────────────────────────────────────────────────────
# Per-line message helpers
# ─────────────────────────────────────────────────────────────────────────────

GLYPH_OK = "✓"
GLYPH_ERR = "✗"
GLYPH_WARN = "▲"
GLYPH_INFO = "›"


def say_ok(message: str, *, hint: str | None = None) -> None:
    """Successful step or final confirmation. Glyph in brand color."""
    color = brand_color()
    g = f"[{color}]{GLYPH_OK}[/{color}]" if color else GLYPH_OK
    stderr.print(f"  {g} {message}")
    if hint:
        stderr.print(f"     [dim]{hint}[/dim]")


def say_err(message: str, *, hint: str | None = None) -> None:
    """Recoverable error. The caller usually exits 1 after this."""
    stderr.print(f"  [bold red]{GLYPH_ERR}[/bold red] [bold]{message}[/bold]")
    if hint:
        stderr.print(f"     [dim]{hint}[/dim]")


def say_warn(message: str, *, hint: str | None = None) -> None:
    """Non-fatal — we proceeded but the user should know."""
    stderr.print(f"  [bold yellow]{GLYPH_WARN}[/bold yellow] {message}")
    if hint:
        stderr.print(f"     [dim]{hint}[/dim]")


def say_info(message: str, *, hint: str | None = None) -> None:
    """Neutral status update — what's happening, who's signed in, etc."""
    color = brand_color()
    g = f"[{color}]{GLYPH_INFO}[/{color}]" if color else GLYPH_INFO
    stderr.print(f"  {g} {message}")
    if hint:
        stderr.print(f"     [dim]{hint}[/dim]")


# ─────────────────────────────────────────────────────────────────────────────
# Small utilities
# ─────────────────────────────────────────────────────────────────────────────


def format_duration(ms: int | float) -> str:
    """Render a millisecond duration in human-friendly units.

    The CLI surfaces durations everywhere — sync footers, streaming
    footers, per-tool timing, the trace summary, the output table — and
    raw milliseconds get unreadable fast (``12810ms`` is harder to scan
    than ``12.8s``, and a five-minute run as ``312000ms`` is hostile).

    Bucketing:

    * ``< 1s``    → ``"850ms"``      — precision matters at sub-second
    * ``< 1m``    → ``"12.8s"``      — one decimal keeps the seconds
                                      boundary readable without noise
    * ``< 1h``    → ``"5m 12s"``     — both parts shown so 1m 0s isn't
                                      indistinguishable from 1m 59s
    * ``>= 1h``   → ``"2h 14m"``     — seconds become rounding noise here

    Negative inputs (which shouldn't happen — clock skew, off-by-one)
    fall through with an ``ms`` suffix so we don't quietly hide bad
    data. Zero returns ``"0ms"`` because every caller already guards
    against printing a zero duration; the format is a backstop.
    """
    ms = int(ms)
    if ms < 1000:
        return f"{ms}ms"
    if ms < 60_000:
        return f"{ms / 1000:.1f}s"
    if ms < 3_600_000:
        minutes, rem_ms = divmod(ms, 60_000)
        seconds = rem_ms // 1000
        return f"{minutes}m {seconds}s"
    hours, rem_ms = divmod(ms, 3_600_000)
    minutes = rem_ms // 60_000
    return f"{hours}h {minutes}m"


def redact_key(key: str) -> str:
    """Mask an API key for display.

    Reveals only the **last 4 characters** behind a fixed-width mask —
    enough for a user to recognize *which* key is in play, useless to
    anyone reading over their shoulder, in a screen-share, or in a
    pasted bug report. This output surfaces in ``doctor``, ``whoami``,
    ``config list/set``, and ``login/logout``, so the exposure budget
    has to be tight.

    We deliberately do **not** show leading characters. Mature CLIs
    only reveal a prefix when it's a non-secret *type marker* (Stripe's
    ``sk_live_``, GitHub's ``gho_``); Fruxon keys have no such stable
    prefix, so any leading chars shown would be real secret entropy.
    Last-4 only is the AWS-CLI / Stripe convention.

    Very short values (≤ 4 chars — only seen with malformed/test input)
    are masked entirely; there's no safe slice of a 4-char secret.
    """
    if len(key) <= 4:
        return "•" * len(key)
    return "•••••" + key[-4:]


def render_markdown(text: str) -> None:
    """Render ``text`` as markdown to stdout via rich.

    Used for agent responses that contain headings / lists / code blocks.
    Caller decides *whether* to call this (typically: only when stdout is
    a TTY, so piped consumers still get raw bytes).

    We use a stdout-bound ``Console`` rather than the module-level
    ``stderr`` console so the markdown lands on stdout (where the rest of
    the response would go), staying behaviorally consistent with the
    plain-text print path.
    """
    from rich.console import Console
    from rich.markdown import Markdown

    stdout_console = Console(soft_wrap=True)
    # `code_theme="ansi_dark"` blends with most terminal themes; rich will
    # pick a sensible default if this name isn't recognized.
    stdout_console.print(Markdown(text, code_theme="ansi_dark"))


def stdout_is_tty() -> bool:
    """Tell whether stdout is a terminal — drives "should we render rich
    output?" decisions. Rendered chrome on a piped consumer's stdout would
    break their parser."""
    import sys

    try:
        return sys.stdout.isatty()
    except (AttributeError, ValueError):
        return False


def open_browser(url: str) -> None:
    """Best-effort browser open. Silently ignores failures — the URL is
    already printed above, so the user can always click or copy/paste."""
    import webbrowser

    try:
        webbrowser.open(url, new=2)  # `new=2` = new tab when supported
    except Exception:
        pass


def maybe_print_update_notice() -> None:
    """Print a one-line "newer version available" hint on stderr, if any.

    Cached, gated by env vars, network-failure-tolerant — implementation
    lives in :mod:`fruxon.update_check`. We swallow any failure here too,
    so a bug in the notifier can't break a command that's already done
    its real job. Only prints when stderr is a TTY so scripts/CI stay quiet.
    """
    if not stderr.is_terminal:
        return
    try:
        from fruxon.update_check import maybe_notify

        message = maybe_notify()
    except Exception:
        return
    if message:
        stderr.print()
        say_info(message)
