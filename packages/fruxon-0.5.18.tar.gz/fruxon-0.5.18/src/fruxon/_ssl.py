"""TLS context resolution for every CLI/SDK call site.

Single source of truth so the four codepaths that make HTTPS requests
(``FruxonClient``, ``cli_auth``, ``cli/_schema``, ``doctor``) agree on
when verification is skipped, when a custom CA bundle is loaded, and
when the insecure escape hatch fires. Drift between sites is the bug
this module exists to prevent.

The resolution rules, in order:

1. **Loopback hosts** (``localhost``, ``127.0.0.1``, ``::1``) → unverified.
   Local dev backends serve a self-signed cert and we don't want every
   contributor installing it into their trust store. Same pattern as
   ``kubectl``, ``gcloud``, ``docker``.
2. **Custom CA bundle** (``FRUXON_CA_BUNDLE=/path/to/ca.pem``) → default
   context with the bundle added via ``load_verify_locations``. For
   corporate proxies that MITM TLS with an internal CA.
3. **Explicit insecure opt-in** (``FRUXON_INSECURE=1``) → unverified,
   with a one-shot stderr warning. For staging boxes with self-signed
   certs where #2 isn't practical. Loud on purpose.
4. **Default** → ``None``, which tells ``urlopen`` to use
   ``ssl.create_default_context()`` (verifies, checks hostname, honors
   ``SSL_CERT_FILE`` / ``SSL_CERT_DIR``).
"""

from __future__ import annotations

import os
import ssl
import sys
import urllib.parse

_LOOPBACK_HOSTS = frozenset({"localhost", "127.0.0.1", "::1"})

# Module-level so the FRUXON_INSECURE warning fires once per process,
# not once per request. Resets between tests via the fixture below.
_insecure_warned = False


def context_for(base_url: str) -> ssl.SSLContext | None:
    """Return the TLS context to use for requests to ``base_url``.

    ``None`` means "use urllib's default secure context" — the right
    answer for everything except dev/proxy edge cases.
    """
    host = urllib.parse.urlparse(base_url).hostname or ""
    if host in _LOOPBACK_HOSTS:
        return ssl._create_unverified_context()  # noqa: S323 — loopback only

    bundle = os.environ.get("FRUXON_CA_BUNDLE", "").strip()
    if bundle:
        ctx = ssl.create_default_context()
        ctx.load_verify_locations(cafile=bundle)
        return ctx

    if _insecure_enabled():
        _warn_insecure_once(host)
        return ssl._create_unverified_context()  # noqa: S323 — opt-in

    return None


def _insecure_enabled() -> bool:
    return os.environ.get("FRUXON_INSECURE", "").strip().lower() in {"1", "true", "yes"}


def _warn_insecure_once(host: str) -> None:
    global _insecure_warned
    if _insecure_warned:
        return
    _insecure_warned = True
    print(
        f"warning: FRUXON_INSECURE=1 — TLS verification disabled for {host or 'requests'}. "
        "Don't use this against production.",
        file=sys.stderr,
    )


def _reset_warning_state_for_tests() -> None:
    """Test helper — let each test observe the one-shot warning fresh."""
    global _insecure_warned
    _insecure_warned = False
