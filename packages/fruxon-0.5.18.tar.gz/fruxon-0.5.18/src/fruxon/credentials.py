"""Persistent CLI credentials.

The CLI accepts the API key + org from three sources, in this priority
order (first non-empty wins):

1. Explicit flags on the command — ``--api-key`` / ``--org``.
2. Environment variables — ``FRUXON_API_KEY`` / ``FRUXON_ORG``.
3. Stored credentials managed by ``fruxon login``.

The stored layer is split for safety:

* **Secrets (``api_key``)** → OS keychain via :mod:`keyring`. On macOS
  that's Keychain; on Linux it's Secret Service (libsecret / KWallet);
  on Windows it's Credential Manager. Same pattern GitHub CLI, Supabase
  CLI, and Claude Code use — leaked screenshots / `cat ~/.fruxon/*`
  copy-paste accidents stop being a credential-exposure risk.
* **Non-secrets (``org``, ``base_url``)** → plain JSON under
  ``~/.fruxon/credentials``. These aren't sensitive and benefit from
  being trivially inspectable.

When the keyring is unavailable (sandboxed containers, certain CI
runners, corp policies that disable libsecret), :func:`save` transparently
falls back to writing the key into the JSON file with ``0600`` perms.
``FRUXON_NO_KEYRING=1`` forces this fallback for users who'd rather
opt out entirely.

JSON is intentional: tomllib is read-only on Python 3.11+, and we want
something stdlib-only that we can both read *and* write across the SDK's
supported Pythons (3.10+).

Naming note: the user-facing noun is "organization" / "org". The
backend still routes via ``/v1/tenants/{X}/...`` because that's its
internal architecture term; the CLI doesn't expose that detail.
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass
from pathlib import Path

CONFIG_DIR_NAME = ".fruxon"
CREDENTIALS_FILE = "credentials"

# Service/username pair used as the keyring lookup key. One key per
# install — multiple orgs share the same secret because Fruxon API keys
# are user-scoped, not org-scoped (the org gets selected per-request).
_KEYRING_SERVICE = "fruxon-cli"
_KEYRING_USERNAME = "api-key"

_logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class StoredCredentials:
    """The subset of CLI config that lives on disk.

    Kept deliberately minimal — anything we don't actually need across
    CLI runs (parameters, session IDs, etc.) belongs on the command
    line, not in the credentials file.
    """

    api_key: str | None = None
    org: str | None = None
    base_url: str | None = None


def config_dir() -> Path:
    """Resolve the directory holding the CLI's per-user state.

    Override via ``FRUXON_CONFIG_DIR`` — useful for tests and for users
    who keep dotfiles under XDG paths. Falls back to ``$HOME/.fruxon``.
    """
    override = os.environ.get("FRUXON_CONFIG_DIR")
    if override:
        return Path(override).expanduser()
    return Path.home() / CONFIG_DIR_NAME


def credentials_path() -> Path:
    return config_dir() / CREDENTIALS_FILE


def load() -> StoredCredentials:
    """Read the stored credentials: keyring for the secret, file for the rest.

    Missing or malformed files yield an empty record; a malformed file
    shouldn't crash routine commands. The keyring lookup is also
    swallowed on error — same rationale.

    Precedence: keyring wins over a file-stored ``api_key`` when both
    exist (the keyring is the more secure store). This lets us migrate
    existing users from file→keyring transparently on their next
    ``fruxon login``.
    """
    file_data = _load_file()
    file_api_key = _str_or_none(file_data.get("api_key"))

    keyring_api_key = _keyring_get()
    api_key = keyring_api_key or file_api_key

    return StoredCredentials(
        api_key=api_key,
        org=_str_or_none(file_data.get("org")),
        base_url=_str_or_none(file_data.get("base_url")),
    )


def save(creds: StoredCredentials) -> Path:
    """Persist ``creds``: API key to keyring, the rest to the file.

    When the keyring is unavailable the API key falls back to the file
    (still mode ``0600``); :func:`save` returns the file path either
    way so callers can surface "saved to X" in the success message.

    Atomic-rename pattern for the file — a crash mid-write doesn't
    leave a half-baked credentials file.
    """
    path = credentials_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        path.parent.chmod(0o700)
    except OSError:
        # Some filesystems (e.g. on Windows) reject chmod — not fatal.
        pass

    # Try keyring first. On success, the file payload omits the secret
    # entirely — no copies of the key anywhere on disk. On failure, the
    # file holds it as the only persistent store.
    payload: dict[str, str] = {}
    if creds.org:
        payload["org"] = creds.org
    if creds.base_url:
        payload["base_url"] = creds.base_url

    keyring_ok = False
    if creds.api_key:
        keyring_ok = _keyring_set(creds.api_key)
        if not keyring_ok:
            payload["api_key"] = creds.api_key
        else:
            # Sweep up any stale file-stored copy from a pre-keyring
            # install so the secret only lives in one place.
            _drop_file_api_key_if_present()

    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    try:
        tmp.chmod(0o600)
    except OSError:
        pass
    os.replace(tmp, path)
    return path


def keyring_is_active() -> bool:
    """Whether the API key is stored in the OS keychain rather than in the file.

    Used by ``fruxon doctor`` / ``fruxon whoami`` to surface "secrets in
    keychain" vs "secrets in file" so users on locked-down hosts know
    which storage mode is active.
    """
    return _keyring_get() is not None


def clear() -> bool:
    """Forget the stored credentials — keyring entry + file.

    Returns ``True`` if anything was removed (either store). Idempotent;
    safe to call when nothing's stored.
    """
    removed = False
    if _keyring_delete():
        removed = True
    path = credentials_path()
    if path.exists():
        path.unlink()
        removed = True
    return removed


def resolve_api_key(cli_value: str | None) -> str | None:
    """Apply the documented precedence to find the API key for a CLI command.

    Order: explicit flag > env var > stored credentials.
    """
    if cli_value:
        return cli_value
    env = os.environ.get("FRUXON_API_KEY")
    if env:
        return env
    return load().api_key


def resolve_org(cli_value: str | None) -> str | None:
    """Same precedence as :func:`resolve_api_key` but for the organization identifier."""
    if cli_value:
        return cli_value
    env = os.environ.get("FRUXON_ORG")
    if env:
        return env
    return load().org


def resolve_base_url(cli_value: str | None) -> str | None:
    """Same precedence; used so ``fruxon login --base-url`` sticks across runs."""
    if cli_value:
        return cli_value
    env = os.environ.get("FRUXON_BASE_URL")
    if env:
        return env
    return load().base_url


def _str_or_none(value: object) -> str | None:
    if isinstance(value, str) and value:
        return value
    return None


# ─────────────────────────────────────────────────────────────────────────────
# File and keyring backends
# ─────────────────────────────────────────────────────────────────────────────


def _load_file() -> dict:
    """Read the JSON file into a dict, or ``{}`` on any failure."""
    path = credentials_path()
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}
    return data if isinstance(data, dict) else {}


def _drop_file_api_key_if_present() -> None:
    """Remove a stale ``api_key`` field from the JSON file.

    Migration helper for users who started on file-only storage —
    once we successfully write the key into the keyring we want to
    delete the file copy so the secret only lives in one place.
    No-op if the file doesn't have an api_key field (or doesn't exist).
    """
    data = _load_file()
    if "api_key" not in data:
        return
    data.pop("api_key", None)
    path = credentials_path()
    tmp = path.with_name(path.name + ".tmp")
    try:
        tmp.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
        tmp.chmod(0o600)
        os.replace(tmp, path)
    except OSError:
        # Best-effort cleanup — if we can't rewrite the file the
        # keyring still has the canonical value, so the stale file
        # copy is just dead weight (not an additional exposure).
        pass


def _keyring_disabled() -> bool:
    """Honor the ``FRUXON_NO_KEYRING`` opt-out.

    Set ``FRUXON_NO_KEYRING=1`` to skip the OS keychain entirely and
    force file-only storage. Useful inside hardened containers where
    libsecret would prompt for a passphrase on every read.
    """
    return os.environ.get("FRUXON_NO_KEYRING", "").strip().lower() in {"1", "true", "yes"}


def _keyring_get() -> str | None:
    """Read the API key from the OS keychain. ``None`` when unavailable."""
    if _keyring_disabled():
        return None
    try:
        import keyring  # local import — cold-import cost only on credential paths
    except ImportError:
        return None
    try:
        value = keyring.get_password(_KEYRING_SERVICE, _KEYRING_USERNAME)
    except Exception as exc:  # noqa: BLE001 — keyring backends throw heterogeneous errors
        # Common causes: no D-Bus session on a headless Linux box; the
        # user denied access in the macOS Keychain prompt. Log at debug
        # so it shows up under ``-d`` but doesn't spam normal runs.
        _logger.debug("keyring read failed: %s", exc)
        return None
    return value if value else None


def _keyring_set(api_key: str) -> bool:
    """Write the API key to the OS keychain. Returns ``True`` on success."""
    if _keyring_disabled():
        return False
    try:
        import keyring
    except ImportError:
        return False
    try:
        keyring.set_password(_KEYRING_SERVICE, _KEYRING_USERNAME, api_key)
    except Exception as exc:  # noqa: BLE001
        _logger.debug("keyring write failed: %s", exc)
        return False
    return True


def _keyring_delete() -> bool:
    """Remove the API key from the OS keychain. Returns ``True`` if anything was removed."""
    if _keyring_disabled():
        return False
    try:
        import keyring
    except ImportError:
        return False
    try:
        keyring.delete_password(_KEYRING_SERVICE, _KEYRING_USERNAME)
        return True
    except Exception:  # noqa: BLE001 — "not found" raises in some backends
        return False
