"""``fruxon doctor`` — diagnose local setup.

Surfaces every signal that affects whether ``fruxon run`` will work for you:
interpreter version, SDK version, credentials file state, resolved API key
/ org / base URL, and (unless ``--offline``) network reachability of
the API. Each row tells you what's healthy and what isn't, with an
actionable hint on every problem.

The actual checks live in :mod:`fruxon.doctor`; this module owns the CLI
shape and rendering.
"""

from __future__ import annotations

import json
import sys
from typing import Annotated

import typer

from fruxon.cli import app
from fruxon.ui import print_banner, resolve_output_format, say_err, say_ok, say_warn, stderr


@app.command()
def doctor(
    skip_network: Annotated[
        bool,
        typer.Option(
            "--offline",
            help="Skip the reachability check against the API — useful on planes / locked-down networks.",
        ),
    ] = False,
    output: Annotated[
        str | None,
        typer.Option(
            "--output",
            "-o",
            help=(
                "Output format: text (default for humans), json (machines, default in "
                "agent mode). Under FRUXON_AGENT_MODE / CLAUDECODE / CI the implicit "
                "default flips to json."
            ),
        ),
    ] = None,
):
    """Diagnose your local setup.

    Walks through interpreter version, SDK version, credentials file
    state, resolved API key / org / base URL, and (unless ``--offline``)
    network reachability of the API. Each row tells you what's healthy
    and what isn't, with an actionable hint on every problem.

    Exit code is 0 when everything's green, 1 when there's any warning
    or failure — handy as a CI precheck before integration tests.
    """
    from fruxon.doctor import overall_status, run_checks

    output = resolve_output_format(output, human_default="text", agent_default="json")
    if output not in {"text", "json"}:
        say_err(
            f"Unknown output format: [bold]{output}[/bold]",
            hint="Valid formats: text, json.",
        )
        raise typer.Exit(code=1)

    results = run_checks(skip_network=skip_network)
    overall = overall_status(results)

    if output == "json":
        payload = {
            "overall": overall,
            "checks": [
                {
                    "title": r.title,
                    "status": r.status,
                    "detail": r.detail,
                    "hint": r.hint,
                }
                for r in results
            ],
        }
        sys.stdout.write(json.dumps(payload) + "\n")
        sys.stdout.flush()
        # Same exit-code semantics in either format so agent-mode callers
        # can branch on the process exit, not the text glyphs.
        if overall != "ok":
            raise typer.Exit(code=1)
        return

    if stderr.is_terminal:
        print_banner(subtitle="doctor")

    stderr.print()
    for r in results:
        if r.status == "ok":
            say_ok(f"[bold]{r.title}[/bold] · {r.detail}", hint=r.hint)
        elif r.status == "warn":
            say_warn(f"[bold]{r.title}[/bold] · {r.detail}", hint=r.hint)
        else:
            say_err(f"[bold]{r.title}[/bold] · {r.detail}", hint=r.hint)

    # Skill-catalog tip — surfaces the procedural guides to anyone who
    # runs `fruxon doctor` to verify setup (Claude Code does this on
    # most first-touch interactions). One-line nudge; not noisy when
    # everything's already green.
    stderr.print()
    stderr.print(
        "     [dim]Guides:[/dim] [bold]fruxon skills show fruxon-meet[/bold]  "
        "[dim](orientation hub — links to every other Fruxon skill)[/dim]"
    )

    stderr.print()
    if overall == "ok":
        say_ok("All checks passed.")
    elif overall == "warn":
        say_warn(
            "All required checks passed — but some optional setup is missing.",
            hint="Address the warnings above for the best experience.",
        )
        raise typer.Exit(code=1)
    else:
        say_err(
            "Some checks failed.",
            hint="Fix the items above and re-run `fruxon doctor`.",
        )
        raise typer.Exit(code=1)
