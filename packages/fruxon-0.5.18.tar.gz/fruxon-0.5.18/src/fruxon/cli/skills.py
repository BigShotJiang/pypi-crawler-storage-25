"""``fruxon skills`` — discover and read Fruxon's procedural-knowledge skills.

The backend ships a catalog of *system skills* (``SystemSkills.cs``):
each one is a markdown instruction set + a recommended tool list. Some
encode domain expertise (``customer-support``, ``content-writing``);
others encode procedural knowledge about Fruxon itself
(``fruxon-build-agent``, ``fruxon-use-integrations``,
``fruxon-debug-revision``).

This module exposes that catalog to the CLI so an LLM driving the CLI
(Claude Code, Cursor, …) can pipe ``fruxon skills show
fruxon-build-agent`` straight into its context before authoring an
agent revision — no docs site, no copy-paste, no separate
distribution. The same skills attach to agents on the Fruxon side; one
source of truth, two consumers.
"""

from __future__ import annotations

import json
from typing import Annotated

import typer

from fruxon.cli import app
from fruxon.cli._shared import build_client
from fruxon.exceptions import FruxonError
from fruxon.ui import resolve_output_format, say_err, stderr

skills_app = typer.Typer(
    help="Browse and read Fruxon's procedural-knowledge skills catalog.",
    no_args_is_help=True,
)
app.add_typer(skills_app, name="skills")


@skills_app.command("list")
def skills_list(
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option("--output", "-o", help="Output format: text (default), json."),
    ] = None,
):
    """List every skill visible to your org.

    Includes both built-in skills (the catalog Fruxon ships — domain
    expertise plus Fruxon-meta guides) and any custom skills your tenant
    has authored or imported. Surfaces id + name + description so you
    can pick the right one to pipe via `fruxon skills show <id>`.

    Examples:
        fruxon skills list
        fruxon skills list -o json | jq '.[] | select(.id|startswith("fruxon-"))'
    """
    output = resolve_output_format(output, human_default="text", agent_default="json")
    client = build_client(org, base_url)
    try:
        skills = client.list_skills()
    except FruxonError as e:
        say_err(str(e))
        raise typer.Exit(code=1) from e

    if output == "json":
        print(json.dumps(skills, indent=2))
        return

    if not skills:
        stderr.print("[dim]No skills available.[/dim]")
        return

    stderr.print()
    for s in skills:
        sid = s.get("id", "")
        name = s.get("displayName", "")
        desc = s.get("description", "")
        # Two-line entry per skill: bold id+name, dim description wrapped
        # below. Compact enough to scan a 30-skill catalog at a glance.
        stderr.print(f"  [bold]{sid}[/bold]  [dim]·[/dim]  {name}")
        if desc:
            stderr.print(f"     [dim]{desc}[/dim]")
        stderr.print()


@skills_app.command("show")
def skills_show(
    skill_id: Annotated[str, typer.Argument(help="Skill identifier (from `fruxon skills list`).")],
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option(
            "--output",
            "-o",
            help="Output format: markdown (default — prints the instructions), json (full record).",
        ),
    ] = None,
):
    """Print a skill's procedural knowledge to stdout.

    By default emits the skill's `instructions` markdown to stdout —
    pipe it straight into an LLM session to load the procedural
    context. With `-o json`, prints the full skill record (id,
    displayName, description, instructions, tools, resources).

    Examples:
        fruxon skills show fruxon-build-agent
        fruxon skills show fruxon-build-agent | pbcopy
        fruxon skills show fruxon-build-agent -o json
    """
    # `markdown` is our user-facing default; resolve_output_format only
    # knows "text" / "json" / "table". Special-case the markdown shorthand
    # so callers can ask for it explicitly without confusion.
    output_norm = (output or "markdown").lower()
    if output_norm not in ("markdown", "text", "json"):
        say_err(
            f"Unknown output format: [bold]{output}[/bold]",
            hint="Valid formats: markdown (default), json.",
        )
        raise typer.Exit(code=1)

    client = build_client(org, base_url)
    try:
        skill = client.get_skill(skill_id)
    except FruxonError as e:
        say_err(str(e), hint="Run [bold]fruxon skills list[/bold] to see what's available.")
        raise typer.Exit(code=1) from e

    if not skill:
        say_err(f"Skill [bold]{skill_id}[/bold] returned an empty record.")
        raise typer.Exit(code=1)

    if output_norm == "json":
        print(json.dumps(skill, indent=2))
        return

    instructions = skill.get("instructions") or ""
    print(instructions)
