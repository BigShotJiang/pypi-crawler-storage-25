"""Helpers shared across ``fruxon`` CLI command modules.

As the CLI grew past a couple of commands — ``agents``, ``integrations``,
``tools``, with more of the agent-build lifecycle to come — the
credential-resolution dance and the "load a JSON request body from a
file" routine started getting copy-pasted. They live here so every
subcommand resolves credentials and reads request files with identical
precedence, error messages, and exit codes.
"""

from __future__ import annotations

import json
import sys

import typer

from fruxon import credentials
from fruxon.fruxon import FruxonClient
from fruxon.ui import integration_connect_url, say_err, stderr


def build_client(org: str | None, base_url: str | None) -> FruxonClient:
    """Resolve credentials and instantiate a client, or exit 1 with a clear error.

    Precedence: ``FRUXON_API_KEY`` env var → stored credentials (from
    ``fruxon login``). There is intentionally no per-command
    ``--api-key`` flag — keys passed on the command line leak to
    shell history, process listings, CI logs, and tmux scrollback.
    The env-var path is just as flexible for CI and strictly safer.
    """
    api_key = credentials.resolve_api_key(None)
    org = credentials.resolve_org(org)
    resolved_base = credentials.resolve_base_url(base_url) or FruxonClient.DEFAULT_BASE_URL

    if not api_key:
        say_err(
            "No API key found.",
            hint="Run [bold]fruxon login[/bold] or set [bold]$FRUXON_API_KEY[/bold].",
        )
        raise typer.Exit(code=1)
    if not org:
        say_err(
            "No org found.",
            hint="Run [bold]fruxon login --org <id>[/bold], pass [bold]--org[/bold], or set [bold]$FRUXON_ORG[/bold].",
        )
        raise typer.Exit(code=1)

    return FruxonClient(api_key=api_key, org=org, base_url=resolved_base)


def load_json_body(file: str, *, what: str) -> dict:
    """Read and parse a ``--file`` JSON request body into a dict.

    The write commands (``agents test``, ``integrations create/update``,
    ``tools create/update/test``, …) all take a structured JSON payload
    from a file. ``-`` reads stdin so the body can be piped. The payload
    must be a JSON *object*; a bare array, a scalar, malformed JSON, or a
    missing path each exits 1 with a pointed message rather than letting
    a cryptic error surface from deeper in the stack.

    ``what`` names the expected payload (e.g. ``"a CreateIntegration
    object"``) so the error hint is specific to the calling command.
    """
    try:
        raw = sys.stdin.read() if file == "-" else open(file, encoding="utf-8").read()
    except OSError as exc:
        say_err(f"Couldn't read file: {exc}", hint="Pass a path to a JSON file, or `-` for stdin.")
        raise typer.Exit(code=1) from exc

    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        say_err(
            f"File is not valid JSON: {exc}",
            hint=f"The file must contain {what}.",
        )
        raise typer.Exit(code=1) from exc

    if not isinstance(parsed, dict):
        say_err(
            "File must contain a JSON object.",
            hint=f"Expected {what}, got a {type(parsed).__name__}.",
        )
        raise typer.Exit(code=1)
    return parsed


def config_needs_user_input(config: dict) -> bool:
    """Decide whether an integration config still needs a human at the dashboard.

    Heuristic — designed for the post-write "smooth out the next step"
    nudge, not for security-grade gating. Two signals trigger it:

    * **User-level auth.** ``auth.level == "USER"`` means each user
      authorizes their own account on first run — surface the dashboard
      link so they can pre-connect instead of bouncing through OAuth
      mid-run.
    * **No auth parameters supplied.** When the CLI created the config
      shell without inline credentials (the common case for OAuth and
      most bearer-token flows), ``auth.parameters`` is empty and the
      config is unusable until filled in.

    A config that already carries inline auth parameters is treated as
    "done" — we have no way to tell if the values are actually valid
    without round-tripping verify, and a false-positive nudge after a
    fully-configured create is more annoying than helpful.
    """
    if not isinstance(config, dict):
        return False
    auth = config.get("auth")
    if not isinstance(auth, dict):
        # No auth block on the config payload at all — nothing for us
        # to nudge against. The integration may not require auth.
        return False
    level = (auth.get("level") or "").upper()
    if level == "USER":
        return True
    params = auth.get("parameters")
    if not isinstance(params, dict) or not params:
        return True
    return False


def print_connect_nudge(configs: list[dict], *, verb: str = "Configure") -> None:
    """Print a clickable dashboard link for each config that needs human input.

    Called after write commands that may have created/referenced
    integration configs whose secrets or OAuth consent the CLI can't
    supply. The whole point is to put the "next step" inside the
    terminal — the user doesn't have to context-switch to find the
    right dashboard page.

    No-op when ``configs`` is empty or every entry already looks
    complete. Always writes to stderr so stdout pipes stay clean.
    """
    pending = [c for c in configs if isinstance(c, dict) and config_needs_user_input(c)]
    if not pending:
        return
    stderr.print()
    label = "integration needs" if len(pending) == 1 else "integrations need"
    stderr.print(f"     [yellow]↗[/yellow] {len(pending)} {label} setup — open to connect:")
    for c in pending:
        integration_id = c.get("integrationId") or "(unknown)"
        config_id = c.get("id")
        url = integration_connect_url(integration_id, config_id)
        display_name = c.get("displayName") or integration_id
        auth = c.get("auth") if isinstance(c.get("auth"), dict) else {}
        scope = "per-user OAuth" if (auth.get("level") or "").upper() == "USER" else "tenant credentials"
        stderr.print(f"       · [bold]{display_name}[/bold]  [dim]({scope})[/dim]  [link]{url}[/link]")
    # Suppress the unused-arg warning while letting callers still pass a verb
    # for parity with future variations of this helper.
    _ = verb
