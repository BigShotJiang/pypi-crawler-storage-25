"""``fruxon chat <agent>`` — interactive REPL with session continuity.

The killer-app surface for terminal users. Each typed message becomes a
streaming agent invocation; the session ID returned with the first
response is threaded into every subsequent call so multi-turn memory
works the way users expect.

A small set of slash commands cover the meta-actions you actually need
inside a chat:

* ``/help``   — list commands
* ``/exit``   — quit the chat (also: Ctrl-D, Ctrl-C, empty line)
* ``/clear``  — start a fresh session (no continuity)
* ``/edit``   — pop ``$EDITOR`` to compose a multi-line message
* ``/session``— show the current session ID

Tool calls and tool results render the same way they do for
``fruxon run`` so the visual language is consistent across the CLI.
"""

from __future__ import annotations

import sys
from typing import Annotated

import typer

from fruxon import credentials
from fruxon.cli import app
from fruxon.exceptions import FruxonError
from fruxon.fruxon import FruxonClient
from fruxon.ui import brand_color, print_banner, say_err, say_info, say_ok, stderr


@app.command(
    short_help="Open an interactive REPL with an agent (multi-turn — pair with `run` for one-shots).",
)
def chat(
    agent: Annotated[str, typer.Argument(help="Agent identifier to chat with")],
    org: Annotated[str | None, typer.Option("--org", "-o", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    input_key: Annotated[
        str,
        typer.Option(
            "--input-key",
            help="Name of the parameter the agent expects the user's message under.",
        ),
    ] = "prompt",
    session_id: Annotated[
        str | None,
        typer.Option(
            "--session",
            "-s",
            help="Resume an existing session by ID instead of starting fresh.",
        ),
    ] = None,
    param: Annotated[
        list[str] | None,
        typer.Option(
            "--param",
            "-p",
            help="Static parameters sent with every turn (key=value, repeatable).",
        ),
    ] = None,
    verbose: Annotated[
        bool,
        typer.Option(
            "--verbose",
            "-v",
            help=(
                "Expand every tool call into a multi-line detail block "
                "(full args + full result). Failures auto-expand regardless."
            ),
        ),
    ] = False,
):
    """Open an interactive REPL with an agent.

    Multi-turn: type, get a streamed reply, type again — the session ID
    is threaded automatically so the agent remembers context. For
    one-shot scripted invocations, use `fruxon run` instead.

    The user's message is sent under the ``--input-key`` parameter
    (default: ``prompt``); any ``-p key=value`` flags are sent unchanged
    on every turn (useful for things like ``-p temperature:=0.2``). The
    server's returned ``sessionId`` is threaded into the next turn for
    multi-turn memory.

    Type ``/help`` for slash commands.

    Examples:
        fruxon chat support-agent
        fruxon chat support-agent --input-key question
        fruxon chat support-agent -p lang=en --session sess-abc
    """
    # Resolve credentials with the same precedence as every other command.
    resolved_api_key = credentials.resolve_api_key(None)
    resolved_org = credentials.resolve_org(org)
    resolved_base_url = credentials.resolve_base_url(base_url) or FruxonClient.DEFAULT_BASE_URL

    if not resolved_api_key:
        say_err(
            "No API key found.",
            hint="Run [bold]fruxon login[/bold] before chatting.",
        )
        raise typer.Exit(code=1)
    if not resolved_org:
        say_err(
            "No org found.",
            hint="Run [bold]fruxon login --org <id>[/bold] or pass [bold]--org[/bold].",
        )
        raise typer.Exit(code=1)

    # Static params shared across every turn. Parsed once up-front so the
    # REPL loop doesn't re-pay the cost.
    static_params = _parse_static_params(param)

    client = FruxonClient(
        api_key=resolved_api_key,
        org=resolved_org,
        base_url=resolved_base_url,
    )

    if stderr.is_terminal:
        print_banner(subtitle=f"chat · {agent}")
        stderr.print()
        say_info(
            f"Talking to [bold]{agent}[/bold]",
            hint="/help for commands · /exit to quit · empty line also quits.",
        )

    _repl(
        client=client,
        agent=agent,
        input_key=input_key,
        static_params=static_params,
        session_id=session_id,
        verbose=verbose,
    )


# ─────────────────────────────────────────────────────────────────────────────
# REPL loop
# ─────────────────────────────────────────────────────────────────────────────


def _repl(
    *,
    client: FruxonClient,
    agent: str,
    input_key: str,
    static_params: dict[str, object],
    session_id: str | None,
    verbose: bool = False,
) -> None:
    """The main read-stream-print loop.

    Slash commands (``/help``, ``/exit``, ``/clear``, ``/edit``,
    ``/session``) handle meta-actions inline so the user never has to
    leave the REPL.
    """
    while True:
        try:
            line = _read_user_line()
        except (EOFError, KeyboardInterrupt):
            # Ctrl-D / Ctrl-C exit gracefully — no traceback dump.
            stderr.print()
            say_info("Bye.")
            return

        if not line.strip():
            stderr.print()
            say_info("Bye.")
            return

        if line.startswith("/"):
            command, _, rest = line[1:].partition(" ")
            command = command.strip().lower()
            if command in {"exit", "quit", "q"}:
                say_info("Bye.")
                return
            if command in {"help", "h", "?"}:
                _print_help()
                continue
            if command == "clear":
                session_id = None
                say_ok("Started a new session.")
                continue
            if command == "session":
                say_info(f"Session: {session_id or '(new — first turn yet to be sent)'}")
                continue
            if command == "edit":
                try:
                    from fruxon.cli.run import _edit_in_editor, _EditorError

                    line = _edit_in_editor(rest, key="message")
                except _EditorError as exc:
                    say_err(str(exc), hint="Set $EDITOR to your preferred editor.")
                    continue
            else:
                stderr.print(f"  [dim]Unknown command:[/dim] /{command}  [dim](try /help)[/dim]")
                continue

        # Send the user's message and stream the response.
        params: dict[str, object] = dict(static_params)
        params[input_key] = line
        try:
            session_id = _send_turn(
                client=client,
                agent=agent,
                parameters=params,
                session_id=session_id,
                verbose=verbose,
            )
        except FruxonError as exc:
            say_err(str(exc))


def _send_turn(
    *,
    client: FruxonClient,
    agent: str,
    parameters: dict[str, object],
    session_id: str | None,
    verbose: bool = False,
) -> str | None:
    """Stream one turn through the shared :class:`_StreamView` surface.

    Delegates rendering to the same Claude-Code-style view used by
    ``fruxon run``: one Rich Live region on stderr with an append-only
    transcript (text paragraphs + ``⏺`` tool blocks) and a footer of
    spinner rows for in-flight tools. When stderr/stdout aren't TTYs
    (pipes, CI logs, test harness), it falls back to raw stdout text +
    plain stderr tool rows.
    """
    from fruxon.cli.run import _render_done, _StreamView

    view = _StreamView(
        live=stderr.is_terminal and sys.stdout.isatty(),
        verbose=verbose,
    )
    new_session = session_id

    # Blank line before the turn keeps successive responses visually
    # separated in the REPL — mimics the cadence of a real chat.
    stderr.print()

    try:
        for event in client.stream(agent, parameters=parameters, session_id=session_id):
            if event.event == "text":
                chunk = event.data.get("chunk")
                if isinstance(chunk, str) and chunk:
                    view.push_text(chunk)
                continue

            if event.event == "tool_call":
                view.push_tool_call(event.data)
                continue

            if event.event == "tool_result":
                view.push_tool_result(event.data)
                continue

            if event.event == "error":
                view.close()
                message = event.data.get("message") or "Unknown error"
                say_err(str(message))
                return new_session

            if event.event == "done":
                view.close()
                _render_done(event.data)
                payload_session = event.data.get("sessionId")
                if isinstance(payload_session, str) and payload_session:
                    new_session = payload_session
                continue
    finally:
        view.close()

    stderr.print()  # trailing blank before the next prompt
    return new_session


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────


def _read_user_line() -> str:
    """Read one line from the user with a brand-colored prompt.

    Falls back to plain ``input()`` when stderr isn't a TTY (test harness,
    pipes) so the test suite can drive the REPL via input fixtures.
    """
    color = brand_color()
    # rich's Prompt would also work but we want minimal chrome — just a
    # colored caret. Plain input() with an ANSI-formatted prompt fits.
    if color and stderr.is_terminal:
        # Use a writable raw escape for the prompt so it renders in color.
        prompt = f"\x1b[1;38;2;{_hex_to_rgb(color)}m›\x1b[0m "
    else:
        prompt = "> "
    return input(prompt)


def _hex_to_rgb(color: str) -> str:
    """Convert ``#rrggbb`` → ``"r;g;b"`` for ANSI true-color sequences.

    Falls back to neutral gray for any non-hex input (named colors like
    ``cyan``) so the prompt doesn't crash on a custom brand color.
    """
    if not (color.startswith("#") and len(color) == 7):
        return "150;150;150"
    try:
        r = int(color[1:3], 16)
        g = int(color[3:5], 16)
        b = int(color[5:7], 16)
    except ValueError:
        return "150;150;150"
    return f"{r};{g};{b}"


def _parse_static_params(flags: list[str] | None) -> dict[str, object]:
    """Parse `-p key=value` flags for the chat REPL.

    Reuses :func:`fruxon.params.parse` so the same forms (typed, file,
    splat) work the same way as ``fruxon run``. Stdin-reading forms
    (``--stdin``, ``key=-``) are nonsensical inside an interactive
    chat — the loop owns stdin — so we explicitly disable them.
    """
    from fruxon.params import ParamError
    from fruxon.params import parse as parse_params

    if not flags:
        return {}
    try:
        parsed = parse_params(
            flag_values=flags,
            params_file=None,
            stdin_input=False,
        )
    except ParamError as exc:
        say_err(str(exc), hint="See [bold]fruxon run --help[/bold] for accepted forms.")
        raise typer.Exit(code=1) from exc
    return parsed or {}


def _print_help() -> None:
    stderr.print()
    stderr.print("  [bold]Slash commands[/bold]")
    stderr.print("    [bold]/help[/bold]        show this list")
    stderr.print("    [bold]/exit[/bold]        quit the chat (also: empty line, Ctrl-D, Ctrl-C)")
    stderr.print("    [bold]/clear[/bold]       start a new session (drops conversation memory)")
    stderr.print("    [bold]/edit[/bold]        compose a multi-line message in $EDITOR")
    stderr.print("    [bold]/session[/bold]     show the current session ID")
    stderr.print()
