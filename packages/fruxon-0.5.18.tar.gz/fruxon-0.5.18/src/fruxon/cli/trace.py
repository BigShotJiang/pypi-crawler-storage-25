"""``fruxon trace`` — fetch and render a past execution's trace.

A run produces an ``executionRecordId``; this command fetches that
record plus its step-by-step trace and pretty-prints both. The CLI
surface today is single-record-by-id; listing recent records is a
natural Phase 4 follow-on but isn't needed to close the "I can't see
what happened" gap.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Annotated

import typer

from fruxon import credentials
from fruxon.cli import app
from fruxon.exceptions import FruxonError
from fruxon.fruxon import FruxonClient
from fruxon.models import ExecutionRecord
from fruxon.ui import format_duration, print_banner, resolve_output_format, say_err, say_ok, stderr


@app.command()
def trace(
    agent: Annotated[str, typer.Argument(help="Agent identifier the run belongs to.")],
    record_id: Annotated[
        str, typer.Argument(help="Execution record ID (the `executionRecordId` from a previous run).")
    ],
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option(
            "--output",
            "-o",
            help=(
                "Output format: text (default for humans), json (machines, default in "
                "agent mode). Under FRUXON_AGENT_MODE / CLAUDECODE / CI the implicit "
                "default flips to json."
            ),
        ),
    ] = None,
    no_trace: Annotated[
        bool,
        typer.Option(
            "--summary-only",
            help="Skip the step-by-step trace; just show the record summary.",
        ),
    ] = False,
):
    """Inspect a past agent execution.

    Pulls the execution record (when/duration/cost/status) plus the
    detailed step-by-step trace. Pair with ``--output json`` to feed
    the data into other tools, or ``--summary-only`` to keep the
    output short when you just want to confirm a run happened.

    Examples:
        fruxon trace my-agent rec-abc123
        fruxon trace my-agent rec-abc123 --summary-only
        fruxon trace my-agent rec-abc123 --output json | jq .trace
    """
    output = resolve_output_format(output, human_default="text", agent_default="json")
    if output not in {"text", "json"}:
        say_err(
            f"Unknown output format: [bold]{output}[/bold]",
            hint="Valid formats: text, json.",
        )
        raise typer.Exit(code=1)
    # Credential resolution mirrors every other command — env > stored.
    resolved_api_key = credentials.resolve_api_key(None)
    resolved_org = credentials.resolve_org(org)
    resolved_base = credentials.resolve_base_url(base_url) or FruxonClient.DEFAULT_BASE_URL

    if not resolved_api_key:
        say_err(
            "No API key found.",
            hint="Run [bold]fruxon login[/bold], pass [bold]--api-key[/bold], or set [bold]$FRUXON_API_KEY[/bold].",
        )
        raise typer.Exit(code=1)
    if not resolved_org:
        say_err(
            "No org found.",
            hint="Run [bold]fruxon login --org <id>[/bold] or pass [bold]--org[/bold].",
        )
        raise typer.Exit(code=1)

    client = FruxonClient(api_key=resolved_api_key, org=resolved_org, base_url=resolved_base)

    try:
        if stderr.is_terminal and output == "text":
            with stderr.status(f"[bold]Fetching record [cyan]{record_id}[/cyan]…[/bold]"):
                record = client.get_execution_record(agent, record_id)
                trace_payload = None if no_trace else client.get_execution_trace(agent, record_id)
        else:
            record = client.get_execution_record(agent, record_id)
            trace_payload = None if no_trace else client.get_execution_trace(agent, record_id)
    except FruxonError as e:
        say_err(str(e), hint=_hint(e, agent, record_id))
        raise typer.Exit(code=1) from e

    if output == "json":
        payload: dict = {"record": _record_to_dict(record)}
        if trace_payload is not None:
            payload["trace"] = trace_payload
        print(json.dumps(payload, indent=2))
        return

    if stderr.is_terminal:
        print_banner(subtitle=f"trace · {record_id}")
    stderr.print()
    _render_record(record)
    if trace_payload is not None:
        stderr.print()
        _render_trace(trace_payload)


# ─────────────────────────────────────────────────────────────────────────────
# Rendering
# ─────────────────────────────────────────────────────────────────────────────


def _render_record(r: ExecutionRecord) -> None:
    """Top-of-output summary: agent, status, when, duration, cost, tokens."""
    say_ok(f"[bold]{r.id}[/bold]")
    _kv("agent", f"{r.agent_id} (revision {r.agent_revision})" if r.agent_revision else r.agent_id)
    _kv("status", r.status or "—")
    _kv("started", _format_ts(r.start_time))
    if r.end_time is not None:
        _kv("ended", _format_ts(r.end_time))
    if r.duration_ms is not None:
        _kv("duration", format_duration(r.duration_ms))
    if r.input_tokens or r.output_tokens:
        _kv(
            "tokens",
            f"in [bold]{r.input_tokens:,}[/bold] · out [bold]{r.output_tokens:,}[/bold]",
        )
    if r.total_cost:
        _kv("cost", f"${r.total_cost:.4f}")


def _render_trace(payload: dict) -> None:
    """Walk the trace payload and surface step-level highlights.

    The server's trace shape is intentionally rich — full tool metadata,
    LLM message logs, nested step trees. We summarize the top level
    (count + status) and render each top-level step as a single line
    that's enough for "what happened, in what order." Deep inspection
    is still available via ``--json``.
    """
    trace_block = payload.get("trace") if isinstance(payload, dict) else None
    if not isinstance(trace_block, dict):
        say_ok("Trace [bold]received[/bold] (no structured steps to render)")
        return

    steps = trace_block.get("steps") or trace_block.get("traces")
    if not isinstance(steps, list) or not steps:
        say_ok("Trace [bold]received[/bold] (empty step list)")
        return

    say_ok(f"Trace · [bold]{len(steps)} step(s)[/bold]")
    for idx, step in enumerate(steps, start=1):
        _render_step_summary(idx, step)


def _render_step_summary(idx: int, step: object) -> None:
    """One-line summary of a trace step, kept terse for skim-ability."""
    if not isinstance(step, dict):
        stderr.print(f"     [dim]{idx}.[/dim] (non-dict step)")
        return
    kind = step.get("kind") or step.get("type") or "step"
    name = step.get("name") or step.get("displayName") or ""
    status = step.get("status")
    duration = step.get("duration")
    parts = [f"[bold]{kind}[/bold]"]
    if name:
        parts.append(str(name))
    suffix = []
    if isinstance(duration, (int, float)) and duration:
        suffix.append(format_duration(duration))
    # Backend status enums use SCREAMING_SNAKE — see the backend's
    # ``StepTraceStatus`` (SUCCESS / ERROR) and ``AgentExecutionRecordStatus``
    # (IN_PROGRESS / WAITING_FOR_HUMAN / COMPLETED / FAILED / CANCELLED).
    # We compare upper-cased so the SDK doesn't have to track which surface
    # emits which enum — any non-success value gets the red treatment.
    if isinstance(status, str) and status.upper() not in {"COMPLETED", "SUCCESS", "OK"}:
        suffix.append(f"[red]{status}[/red]")
    line = "     [dim]" + f"{idx}.[/dim]  " + " · ".join(parts)
    if suffix:
        line += "  [dim](" + " · ".join(suffix) + ")[/dim]"
    stderr.print(line)


def _record_to_dict(r: ExecutionRecord) -> dict:
    return {
        "id": r.id,
        "agentId": r.agent_id,
        "agentRevision": r.agent_revision,
        "status": r.status,
        "startTime": r.start_time,
        "endTime": r.end_time,
        "durationMs": r.duration_ms,
        "inputTokens": r.input_tokens,
        "outputTokens": r.output_tokens,
        "totalCost": r.total_cost,
    }


def _format_ts(ms: int) -> str:
    """Render an epoch-ms timestamp as a short ISO-8601 UTC string.

    Local-time would be friendlier for humans but harder to correlate
    with server logs; ISO+UTC is unambiguous and matches what shows up
    in the dashboard's execution-record view.
    """
    if not ms:
        return "—"
    try:
        return datetime.fromtimestamp(ms / 1000, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    except (OverflowError, OSError, ValueError):
        return f"{ms} (raw)"


def _kv(key: str, value: str) -> None:
    stderr.print(f"     [dim]{key:<10}[/dim] {value}")


def _hint(error: FruxonError, agent: str, record_id: str) -> str | None:
    from fruxon.exceptions import NotFoundError

    if isinstance(error, NotFoundError):
        return (
            f"No record [bold]{record_id}[/bold] found for agent [bold]{agent}[/bold]. "
            "Confirm both IDs from a recent `fruxon run` output."
        )
    return None
