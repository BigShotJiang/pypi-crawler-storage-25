"""``fruxon integrations`` — manage external integrations from the terminal.

An *integration* is a connection to an external service — an HTTP API, a
SaaS product, an MCP server. It's the container that tools live under.
This is the first rung of the agent-build loop: connect an integration,
define tools on it (``fruxon tools``), then reference those tools from an
agent's flow.

Read commands (``list`` / ``get``) take simple flags; write commands
(``create`` / ``update`` / ``verify``) take a ``--file`` JSON body,
because the payloads (``CreateIntegration``, ``VerifyAuthConfigRequest``)
carry structured ``configMetadata`` / ``authConfig`` objects, not
key=value pairs — same pattern as ``fruxon agents test``.
"""

from __future__ import annotations

import json
from typing import Annotated

import typer

from fruxon.cli import app
from fruxon.cli._shared import build_client, load_json_body, print_connect_nudge
from fruxon.exceptions import FruxonError
from fruxon.fruxon import Integration
from fruxon.ui import (
    integration_connect_url,
    print_banner,
    resolve_output_format,
    say_err,
    say_info,
    say_ok,
    stderr,
)

integrations_app = typer.Typer(
    help="Manage external integrations in your org.",
    no_args_is_help=True,
)
app.add_typer(integrations_app, name="integrations")

mcp_app = typer.Typer(
    help="Inspect and enable the MCP server for an integration.",
    no_args_is_help=True,
)
integrations_app.add_typer(mcp_app, name="mcp")


# ─────────────────────────────────────────────────────────────────────────────
# list
# ─────────────────────────────────────────────────────────────────────────────


@integrations_app.command("list")
def integrations_list(
    search: Annotated[str | None, typer.Option("--search", help="Filter by free-text search.")] = None,
    type_: Annotated[
        list[str] | None,
        typer.Option("--type", help="Filter by integration type. Repeatable."),
    ] = None,
    tag: Annotated[list[str] | None, typer.Option("--tag", help="Filter by tag. Repeatable.")] = None,
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option(
            "--output",
            "-o",
            help=(
                "Output format: table (default for humans), json (machines, default in "
                "agent mode), id (one ID per line, pipe-safe)."
            ),
        ),
    ] = None,
):
    """List the integrations in your org.

    Examples:
        fruxon integrations list
        fruxon integrations list --type CUSTOM --tag crm
        fruxon integrations list --output id | xargs -n1 -I{} fruxon tools list {}
    """
    output = resolve_output_format(output, human_default="table", agent_default="json")
    if output not in {"table", "json", "id"}:
        say_err(f"Unknown output format: [bold]{output}[/bold]", hint="Valid formats: table, json, id.")
        raise typer.Exit(code=1)

    client = build_client(org, base_url)
    try:
        if stderr.is_terminal and output != "id":
            with stderr.status("[bold]Fetching integrations…[/bold]"):
                integrations = client.list_integrations(search=search, types=type_, tags=tag)
        else:
            integrations = client.list_integrations(search=search, types=type_, tags=tag)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e

    if not integrations:
        if output == "json":
            print("[]")
            return
        if output == "id":
            return
        say_info(
            "No integrations match." if (search or type_ or tag) else "No integrations in this org yet.",
            hint="Create one with [bold]fruxon integrations create --file <int.json>[/bold].",
        )
        return

    if output == "id":
        for i in integrations:
            print(i.id)
        return
    if output == "json":
        print(json.dumps([_to_dict(i) for i in integrations], indent=2))
        return

    if stderr.is_terminal:
        print_banner(subtitle=f"integrations · {len(integrations)}")
    stderr.print()
    stderr.print(_build_table(integrations))


# ─────────────────────────────────────────────────────────────────────────────
# get
# ─────────────────────────────────────────────────────────────────────────────


@integrations_app.command("get")
def integrations_get(
    integration: Annotated[str, typer.Argument(help="Integration identifier to fetch.")],
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option("--output", "-o", help="Output format: text (default), json."),
    ] = None,
):
    """Show one integration's details.

    Examples:
        fruxon integrations get github
        fruxon integrations get github --output json
    """
    output = resolve_output_format(output, human_default="text", agent_default="json")
    if output not in {"text", "json"}:
        say_err(f"Unknown output format: [bold]{output}[/bold]", hint="Valid formats: text, json.")
        raise typer.Exit(code=1)

    client = build_client(org, base_url)
    try:
        if stderr.is_terminal and output == "text":
            with stderr.status(f"[bold]Fetching [cyan]{integration}[/cyan]…[/bold]"):
                fetched = client.get_integration(integration)
        else:
            fetched = client.get_integration(integration)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e

    if output == "json":
        print(json.dumps(_to_dict(fetched), indent=2))
        return

    if stderr.is_terminal:
        print_banner(subtitle=f"integration · {fetched.id}")
    stderr.print()
    say_ok(f"[bold]{fetched.display_name or fetched.id}[/bold]")
    if fetched.description:
        stderr.print(f"     [dim]{fetched.description}[/dim]")
    stderr.print()
    _say_kv("id", fetched.id)
    _say_kv("type", fetched.type or "[dim]—[/dim]")
    if fetched.tags:
        _say_kv("tags", ", ".join(fetched.tags))
    stderr.print()
    stderr.print(f"     [dim]Tools:[/dim] fruxon tools list [bold]{fetched.id}[/bold]")


# ─────────────────────────────────────────────────────────────────────────────
# create / update
# ─────────────────────────────────────────────────────────────────────────────


@integrations_app.command("create")
def integrations_create(
    file: Annotated[
        str | None,
        typer.Option("--file", "-f", help="CreateIntegration JSON body. `-` reads stdin."),
    ] = None,
    schema: Annotated[
        bool,
        typer.Option("--schema", help="Print the JSON schema for --file (CreateIntegration) and exit."),
    ] = False,
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option("--output", "-o", help="Output format: text (default), json."),
    ] = None,
):
    """Create an integration from a JSON definition file.

    `--file` is a CreateIntegration body: `id`, `displayName`,
    `description`, and the `configMetadata` describing auth + connection
    settings.

    By design, this command creates the integration *shape* only —
    which auth methods are supported, which parameters the user will
    fill in. The actual credential values (API keys, OAuth grants)
    live in tenant-level configs and are entered through the
    dashboard. Keeps secrets out of terminal scrollback, shell
    history, JSON files on disk, and CI logs.

    Examples:
        fruxon integrations create --file ./github.json
        cat github.json | fruxon integrations create --file -
        fruxon integrations create --schema > schema.json

    Procedural guide:
        fruxon skills show fruxon-create-integration
    """
    from fruxon.cli._schema import print_schema

    if schema:
        print_schema("CreateIntegration", base_url=base_url)
        return
    if not file:
        say_err(
            "Missing required option [bold]--file[/bold].",
            hint="Pass a JSON file, or [bold]--schema[/bold] to see the shape.",
        )
        raise typer.Exit(code=1)

    output = _resolve_write_output(output)
    body = load_json_body(file, what="a CreateIntegration object (id, displayName, configMetadata, …)")
    client = build_client(org, base_url)
    try:
        result = client.create_integration(body)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e
    _render_write_result(result, output, verb="Created", body=body)


@integrations_app.command("update")
def integrations_update(
    integration: Annotated[str, typer.Argument(help="Integration identifier to update.")],
    file: Annotated[
        str | None,
        typer.Option("--file", "-f", help="UpdateIntegration JSON body. `-` reads stdin."),
    ] = None,
    schema: Annotated[
        bool,
        typer.Option("--schema", help="Print the JSON schema for --file (UpdateIntegration) and exit."),
    ] = False,
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option("--output", "-o", help="Output format: text (default), json."),
    ] = None,
):
    """Update an integration from a JSON definition file.

    Omit credential fields from the body to keep existing values
    unchanged — the API never returns secrets, so it can't round-trip them.

    Examples:
        fruxon integrations update github --file ./github.json
        fruxon integrations update github --schema > schema.json
    """
    from fruxon.cli._schema import print_schema

    if schema:
        print_schema("UpdateIntegration", base_url=base_url)
        return
    if not file:
        say_err(
            "Missing required option [bold]--file[/bold].",
            hint="Pass a JSON file, or [bold]--schema[/bold] to see the shape.",
        )
        raise typer.Exit(code=1)

    output = _resolve_write_output(output)
    body = load_json_body(file, what="an UpdateIntegration object")
    client = build_client(org, base_url)
    try:
        result = client.update_integration(integration, body)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e
    _render_write_result(result, output, verb="Updated", body=body)


# ─────────────────────────────────────────────────────────────────────────────
# open — browser launcher to the dashboard integration page
# ─────────────────────────────────────────────────────────────────────────────


@integrations_app.command("open")
def integrations_open(
    integration: Annotated[str, typer.Argument(help="Integration identifier to open in the browser.")],
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
):
    """Open the dashboard integration page in the default browser.

    Configs (the actual credentials) are entered through the
    dashboard for security — this command jumps you straight to the
    right page. Useful as the final step of an agent-driven setup:
    the agent creates the integration via CLI, then tells the human
    to run `fruxon integrations open <id>` to finish the job.

    Prints the URL in non-TTY contexts (CI, piped output) so callers
    can still copy it.
    """
    # base_url is accepted purely to keep the dashboard URL resolution
    # consistent with sibling commands (FRUXON_DASHBOARD_URL etc.).
    _ = base_url
    import webbrowser

    url = integration_connect_url(integration)
    stderr.print(f"[yellow]↗[/yellow] Opening [link]{url}[/link]")
    opened = False
    try:
        opened = webbrowser.open(url, new=2)
    except Exception:  # noqa: BLE001 — webbrowser is best-effort
        opened = False
    if not opened:
        stderr.print("     [dim]Couldn't auto-launch the browser — copy the URL above.[/dim]")


# ─────────────────────────────────────────────────────────────────────────────
# verify
# ─────────────────────────────────────────────────────────────────────────────


@integrations_app.command("verify")
def integrations_verify(
    integration: Annotated[str, typer.Argument(help="Integration identifier to verify.")],
    file: Annotated[
        str | None,
        typer.Option("--file", "-f", help="VerifyAuthConfigRequest JSON body. `-` reads stdin."),
    ] = None,
    schema: Annotated[
        bool,
        typer.Option("--schema", help="Print the JSON schema for --file (VerifyAuthConfigRequest) and exit."),
    ] = False,
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option("--output", "-o", help="Output format: text (default), json."),
    ] = None,
):
    """Verify that an integration's auth config can actually connect.

    `--file` is a VerifyAuthConfigRequest body (`authMetadataId`,
    `authConfig`, `configParameters`). A failed *check* is a normal
    result — the failure detail is printed and the exit code is 1, so
    this works as a pre-flight gate. Only transport errors raise.

    Examples:
        fruxon integrations verify github --file ./auth.json
        fruxon integrations verify github --schema > schema.json
    """
    from fruxon.cli._schema import print_schema

    if schema:
        print_schema("VerifyAuthConfigRequest", base_url=base_url)
        return
    if not file:
        say_err(
            "Missing required option [bold]--file[/bold].",
            hint="Pass a JSON file, or [bold]--schema[/bold] to see the shape.",
        )
        raise typer.Exit(code=1)

    output = _resolve_write_output(output)
    body = load_json_body(file, what="a VerifyAuthConfigRequest object (authMetadataId, authConfig, …)")
    client = build_client(org, base_url)
    try:
        if stderr.is_terminal and output == "text":
            with stderr.status(f"[bold]Verifying [cyan]{integration}[/cyan]…[/bold]"):
                result = client.verify_integration(integration, body)
        else:
            result = client.verify_integration(integration, body)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e

    success = bool(result.get("success"))
    if output == "json":
        print(json.dumps(result, indent=2))
        if not success:
            raise typer.Exit(code=1)
        return

    if stderr.is_terminal:
        print_banner(subtitle=f"verify · {integration}")
    stderr.print()
    if success:
        say_ok(f"[bold]{integration}[/bold] · auth config verified")
        auth_url = result.get("authorizationUrl")
        if auth_url:
            stderr.print(f"     [dim]Authorization URL:[/dim] [link]{auth_url}[/link]")
    else:
        say_err(
            f"[bold]{integration}[/bold] · verification failed",
            hint=result.get("error") or "The auth config was rejected by the integration.",
        )
        raise typer.Exit(code=1)


# ─────────────────────────────────────────────────────────────────────────────
# configs — tenant-level integration configs
# ─────────────────────────────────────────────────────────────────────────────

configs_app = typer.Typer(
    help="List and inspect tenant-level integration configs (reusable auth + connection settings).",
    no_args_is_help=True,
)
integrations_app.add_typer(configs_app, name="configs")


@configs_app.command("list")
def integration_configs_list(
    integration: Annotated[str, typer.Argument(help="Integration to list configs for.")],
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option(
            "--output",
            "-o",
            help=(
                "Output format: table (default for humans), json (machines, default in "
                "agent mode), id (one UUID per line, pipe-safe)."
            ),
        ),
    ] = None,
):
    """List the tenant-level configs registered for an integration.

    An agent revision can reference one of these by ``id`` via
    ``integrationConfigs[i].tenantConfigId``, instead of inlining auth
    parameters into the revision itself.

    Examples:
        fruxon integrations configs list github
        fruxon integrations configs list github --output id
    """
    output = resolve_output_format(output, human_default="table", agent_default="json")
    if output not in {"table", "json", "id"}:
        say_err(f"Unknown output format: [bold]{output}[/bold]", hint="Valid formats: table, json, id.")
        raise typer.Exit(code=1)

    client = build_client(org, base_url)
    try:
        if stderr.is_terminal and output != "id":
            with stderr.status(f"[bold]Fetching configs for [cyan]{integration}[/cyan]…[/bold]"):
                configs = client.list_integration_configs(integration)
        else:
            configs = client.list_integration_configs(integration)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e

    if not configs:
        if output == "json":
            print("[]")
            return
        if output == "id":
            return
        say_info(
            f"No tenant-level configs for [bold]{integration}[/bold] yet.",
            hint=(
                "Configure one in the dashboard, or inline credentials into the agent "
                "revision's [bold]integrationConfigs[/bold]."
            ),
        )
        return

    if output == "id":
        for c in configs:
            cid = c.get("id") if isinstance(c, dict) else None
            if cid:
                print(cid)
        return
    if output == "json":
        print(json.dumps(configs, indent=2))
        return

    if stderr.is_terminal:
        print_banner(subtitle=f"configs · {integration} · {len(configs)}")
    stderr.print()
    stderr.print(_build_configs_table(configs))
    # If any of the listed configs still need a human (per-user OAuth or
    # empty secret parameters), print the connect link inline so the user
    # doesn't have to hunt for it.
    print_connect_nudge(configs)


@configs_app.command("get")
def integration_configs_get(
    integration: Annotated[str, typer.Argument(help="Integration the config belongs to.")],
    config_id: Annotated[str, typer.Argument(help="Config UUID to fetch.")],
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
):
    """Print one integration config's full payload as JSON.

    Always emits JSON — these configs carry nested auth/parameter metadata
    that doesn't compress usefully into a text view. Pipe through ``jq`` to
    extract the field you need.
    """
    client = build_client(org, base_url)
    try:
        body = client.get_integration_config(integration, config_id)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e
    print(json.dumps(body, indent=2))


def _build_configs_table(configs: list[dict]):
    from rich.table import Table

    table = Table(show_header=True, header_style="bold", show_edge=False, pad_edge=False, box=None, padding=(0, 1))
    table.add_column("ID", style="bold", no_wrap=True, overflow="ellipsis", max_width=36)
    table.add_column("Name", no_wrap=True, overflow="ellipsis", max_width=28)
    table.add_column("Auth", no_wrap=True, style="dim")
    for c in configs:
        if not isinstance(c, dict):
            continue
        auth = c.get("auth") if isinstance(c.get("auth"), dict) else {}
        auth_method = auth.get("integrationAuthMetadataId") or "[dim]—[/dim]"
        table.add_row(c.get("id") or "", c.get("displayName") or "", auth_method)
    return table


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────


def _resolve_write_output(output: str | None) -> str:
    """Resolve + validate the output format for a write command (text/json)."""
    output = resolve_output_format(output, human_default="text", agent_default="json")
    if output not in {"text", "json"}:
        say_err(f"Unknown output format: [bold]{output}[/bold]", hint="Valid formats: text, json.")
        raise typer.Exit(code=1)
    return output


def _render_write_result(result: Integration, output: str, *, verb: str, body: dict | None = None) -> None:
    """Render the result of a create/update — a confirmation line, or JSON.

    When ``body`` is supplied we read ``configMetadata.authMetadata`` off
    the request the caller just submitted to name the specific auth
    method(s) the user now needs to fill in. This makes the handoff
    line specific ("Paste your GitHub Personal Access Token") instead
    of generic ("Connect / add credentials"), which is the difference
    between a slick UX and a vague one.
    """
    if output == "json":
        print(json.dumps(_to_dict(result), indent=2))
        return
    if stderr.is_terminal:
        print_banner(subtitle=f"integration · {result.id}")
    stderr.print()
    say_ok(f"{verb} integration [bold]{result.id}[/bold]")
    stderr.print(f"     [dim]Next:[/dim] fruxon tools create [bold]{result.id}[/bold] --file <tool.json>")

    # Surface the dashboard link with auth-method-specific copy. We
    # restrict secret writes to the dashboard on purpose (see the
    # `create` docstring), so this link is the one place the user
    # finishes the job.
    auth_methods = []
    if body:
        cfg_meta = body.get("configMetadata") or {}
        auth_methods = cfg_meta.get("authMetadata") or []

    connect_url = integration_connect_url(result.id)
    if not auth_methods:
        # Integration has nothing to configure (e.g. a SYSTEM-type tool
        # bundle). Skip the connect line entirely rather than nudging
        # the user toward a page that has nothing to do.
        return

    stderr.print()
    stderr.print("     [yellow]↗[/yellow] Tools are live, but agents can't call them until you connect:")
    stderr.print(f"        [link]{connect_url}[/link]")
    for auth in auth_methods:
        label = auth.get("displayName") or auth.get("id") or "credentials"
        stderr.print(f"        [dim]↳ Paste {label}[/dim]")


def _build_table(integrations: list[Integration]):
    from rich.table import Table

    table = Table(show_header=True, header_style="bold", show_edge=False, pad_edge=False, box=None, padding=(0, 1))
    table.add_column("ID", style="bold", no_wrap=True, overflow="ellipsis", max_width=28)
    table.add_column("Type", no_wrap=True)
    table.add_column("Name", no_wrap=True, overflow="ellipsis", max_width=24)
    table.add_column("Tags", style="dim", no_wrap=True, overflow="ellipsis", max_width=24)
    for i in integrations:
        table.add_row(i.id, i.type or "[dim]—[/dim]", i.display_name or "", ", ".join(i.tags) if i.tags else "")
    return table


def _to_dict(i: Integration) -> dict:
    """Serialize for ``--output json`` — camelCase to match the API payload."""
    return {
        "id": i.id,
        "displayName": i.display_name,
        "description": i.description,
        "type": i.type,
        "tags": i.tags,
    }


def _say_kv(key: str, value: str) -> None:
    stderr.print(f"     [dim]{key:<8}[/dim] {value}")


def _hint_for_error(error: FruxonError) -> str | None:
    from fruxon.exceptions import AuthenticationError, ForbiddenError, NotFoundError

    if isinstance(error, AuthenticationError):
        return "Run [bold]fruxon whoami[/bold] to confirm your key, then [bold]fruxon login[/bold] to refresh."
    if isinstance(error, ForbiddenError):
        return "Your key doesn't grant access to this resource. Confirm with [bold]fruxon whoami[/bold]."
    if isinstance(error, NotFoundError):
        return "Run [bold]fruxon integrations list[/bold] to see what's available."
    return None


# ─────────────────────────────────────────────────────────────────────────────
# mcp — inspect + enable the MCP server for an integration
# ─────────────────────────────────────────────────────────────────────────────


@mcp_app.command("status")
def integrations_mcp_status(
    integration: Annotated[str, typer.Argument(help="Integration identifier to inspect.")],
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option("--output", "-o", help="Output format: text (default), json."),
    ] = None,
):
    """Show the MCP server settings for an integration.

    Read-only. Returns `enabled`, the published config it routes
    through, the bound key's displayable prefix, and the call / sandbox
    URLs. Never returns the raw secret — that's revealed only by
    `mcp enable` on first activation, or by rotation in the dashboard.

    Examples:
        fruxon integrations mcp status github
        fruxon integrations mcp status github --output json
    """
    output = resolve_output_format(output, human_default="text", agent_default="json")
    if output not in {"text", "json"}:
        say_err(f"Unknown output format: [bold]{output}[/bold]", hint="Valid formats: text, json.")
        raise typer.Exit(code=1)

    client = build_client(org, base_url)
    try:
        cfg = client.get_mcp_config(integration)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e

    if output == "json":
        print(json.dumps(cfg, indent=2))
        return

    if stderr.is_terminal:
        print_banner(subtitle=f"mcp · {integration}")
    stderr.print()
    say_ok(
        f"MCP server is [bold]{'enabled' if cfg.get('enabled') else 'disabled'}[/bold] for [bold]{integration}[/bold]"
    )
    if cfg.get("enabled"):
        if cfg.get("keyPrefix"):
            _say_kv("key", f"{cfg['keyPrefix']}…")
        if cfg.get("configId"):
            _say_kv("config", str(cfg["configId"]))
        if cfg.get("callUrl"):
            _say_kv("url", cfg["callUrl"])


@mcp_app.command("enable")
def integrations_mcp_enable(
    integration: Annotated[str, typer.Argument(help="Integration identifier to enable MCP for.")],
    config_id: Annotated[
        str | None,
        typer.Option(
            "--config",
            help="Tenant config ID to back tool execution. Required on first enable.",
        ),
    ] = None,
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option("--output", "-o", help="Output format: text (default), json."),
    ] = None,
):
    """Enable the MCP server for an integration.

    First-time enable auto-mints a dedicated key with the
    `mcp:invoke` scope and prints the raw secret ONCE. Paste it into
    Claude Desktop / Cursor immediately — it cannot be retrieved
    later. Subsequent calls (re-enable after disable) reuse the
    existing bound key without re-revealing the secret.

    By design the secret is shown only in this terminal session;
    rotation is dashboard-only to keep secret-minting auditable.

    Examples:
        fruxon integrations mcp enable github --config <uuid>
        fruxon integrations mcp enable github                # re-enable
    """
    output = resolve_output_format(output, human_default="text", agent_default="json")
    if output not in {"text", "json"}:
        say_err(f"Unknown output format: [bold]{output}[/bold]", hint="Valid formats: text, json.")
        raise typer.Exit(code=1)

    body: dict[str, object] = {"enabled": True}
    if config_id is not None:
        body["configId"] = config_id

    client = build_client(org, base_url)
    try:
        cfg = client.update_mcp_config(integration, body)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e

    if output == "json":
        print(json.dumps(cfg, indent=2))
        return

    if stderr.is_terminal:
        print_banner(subtitle=f"mcp · {integration}")
    stderr.print()
    if cfg.get("apiKey"):
        # First-time mint. One-shot reveal — same UX as `fruxon keys
        # create`. After this line the secret leaves the server's
        # memory and the SDK's process and is unrecoverable.
        say_ok(f"MCP enabled for [bold]{integration}[/bold]")
        stderr.print()
        stderr.print("     [bold yellow]Save this now — it won't be shown again.[/bold yellow]")
        print(cfg["apiKey"])
        stderr.print()
        stderr.print("     [dim]Paste into Claude Desktop / Cursor MCP config. URL:[/dim]")
        if cfg.get("callUrl"):
            stderr.print(f"     {cfg['callUrl']}")
    else:
        say_ok(f"MCP enabled for [bold]{integration}[/bold] (key already bound)")
        if cfg.get("keyPrefix"):
            _say_kv("key", f"{cfg['keyPrefix']}…")
        if cfg.get("callUrl"):
            _say_kv("url", cfg["callUrl"])
