"""``fruxon config`` — read/edit the persistent CLI config.

Exposes the credentials file as a flat key/value store. Login covers the
happy path (sign in once, forget the file exists), but power users still
need a way to inspect, tweak individual fields, or clear a single value
without nuking the whole record:

    fruxon config list
    fruxon config get org
    fruxon config set org=acme-corp
    fruxon config unset org

The keyspace is intentionally narrow — same three fields ``login`` manages
(``api_key``, ``org``, ``base_url``). Anything more belongs in request
flags, not in a stored profile.
"""

from __future__ import annotations

from typing import Annotated

import typer

from fruxon import credentials
from fruxon.cli import app
from fruxon.credentials import StoredCredentials
from fruxon.ui import print_banner, redact_key, say_err, say_info, say_ok, say_warn, stderr

config_app = typer.Typer(
    help=(
        "Read and edit the persistent CLI config. "
        "Non-secrets (org, base_url) live in ~/.fruxon/credentials; "
        "the API key lives in your OS keychain."
    ),
    no_args_is_help=True,
)
app.add_typer(config_app, name="config")

_CONFIG_KEYS = ("api_key", "org", "base_url")


def _ensure_config_key(key: str) -> str:
    if key not in _CONFIG_KEYS:
        say_err(
            f"Unknown config key: [bold]{key}[/bold]",
            hint=f"Valid keys: {', '.join(_CONFIG_KEYS)}.",
        )
        raise typer.Exit(code=1)
    return key


def _api_key_source_label(api_key: str | None) -> str | None:
    """Describe where the API key was loaded from for the ``config list`` footer.

    Three cases:
      * keyring active     → "OS keychain (via keyring)"
      * file fallback      → the credentials file path
      * nothing stored     → ``None`` (caller skips the row)

    Reads :func:`credentials.keyring_is_active` so we report the *actual*
    storage status, not just where ``save`` would have written. A user
    on a system without a working keyring sees the file path here, which
    is what they need to know if they ever want to ``cat`` it.
    """
    if not api_key:
        return None
    if credentials.keyring_is_active():
        return "OS keychain (via keyring)"
    return f"{credentials.credentials_path()} (keyring unavailable — fallback)"


def _redact_for_display(key: str, value: str | None) -> str:
    """Hide the API key by default; org IDs and URLs are not sensitive."""
    if value is None:
        return "—"
    if key == "api_key":
        return redact_key(value)
    return value


@config_app.command("list")
def config_list():
    """Show every stored config value, with the API key redacted."""
    if stderr.is_terminal:
        print_banner(subtitle="config")

    creds = credentials.load()
    payload = {k: getattr(creds, k) for k in _CONFIG_KEYS}

    stderr.print()
    if not any(payload.values()):
        say_info(
            "No config stored.",
            hint="Run [bold]fruxon login[/bold] or [bold]fruxon config set <key>=<value>[/bold].",
        )
        return

    for key in _CONFIG_KEYS:
        value = payload[key]
        say_ok(f"[bold]{key}[/bold] · {_redact_for_display(key, value)}")
    # Surface both storage locations so users know where each piece
    # actually lives — secrets in the OS keychain, non-secrets in the
    # plain JSON file. The previous footer mentioned only the file,
    # which gave the wrong impression that ``cat ~/.fruxon/credentials``
    # would reveal the API key.
    api_key_source = _api_key_source_label(payload["api_key"])
    stderr.print()
    stderr.print(f"    [dim]non-secrets · {credentials.credentials_path()}[/dim]")
    if api_key_source:
        stderr.print(f"    [dim]api_key     · {api_key_source}[/dim]")


@config_app.command("get")
def config_get(
    key: Annotated[str, typer.Argument(help="Config key to read (api_key, org, base_url).")],
):
    """Print a single config value to stdout — empty if unset.

    Unredacted on purpose: ``get`` is the explicit form, the caller asked
    for the raw value (typical use: ``KEY=$(fruxon config get api_key)``).
    """
    _ensure_config_key(key)
    value = getattr(credentials.load(), key)
    if value:
        # Print to stdout so it can be captured in shell substitution.
        print(value)


@config_app.command("set")
def config_set(
    assignments: Annotated[
        list[str],
        typer.Argument(
            help="One or more `key=value` assignments (e.g. org=acme).",
        ),
    ],
):
    """Store one or more config values without going through the login flow.

    Examples:
        fruxon config set org=acme-corp
        fruxon config set base_url=https://staging.fruxon.com
        fruxon config set api_key=fxn_... org=acme          # multi-set
    """
    if not assignments:
        say_err("Pass at least one key=value pair.", hint="Run [bold]fruxon config --help[/bold].")
        raise typer.Exit(code=1)

    if stderr.is_terminal:
        print_banner(subtitle="config")

    creds = credentials.load()
    updates: dict[str, str] = {}
    for raw in assignments:
        if "=" not in raw:
            say_err(
                f"Invalid assignment: [bold]{raw}[/bold]",
                hint="Use [bold]key=value[/bold] (e.g. org=acme-corp).",
            )
            raise typer.Exit(code=1)
        key, value = raw.split("=", 1)
        key = key.strip()
        value = value.strip()
        _ensure_config_key(key)
        if not value:
            say_err(
                f"Empty value for [bold]{key}[/bold].",
                hint="Use [bold]fruxon config unset[/bold] to clear a value instead.",
            )
            raise typer.Exit(code=1)
        # base_url quirks: every API doc starts paths with `/v1/...`, so
        # users (and agents) naturally tack `/v1` onto base_url. The SDK
        # then builds `…/v1/v1/...` and silently 404s. Strip it once, with
        # a visible warning so the user understands what happened.
        if key == "base_url":
            value = value.rstrip("/")
            if value.endswith("/v1"):
                stripped = value[: -len("/v1")]
                say_warn(
                    f"Dropping trailing [bold]/v1[/bold] from base_url — keeping [bold]{stripped}[/bold].",
                    hint="The SDK appends /v1 itself; including it produces /v1/v1/... requests.",
                )
                value = stripped
        updates[key] = value

    new_creds = StoredCredentials(
        api_key=updates.get("api_key", creds.api_key),
        org=updates.get("org", creds.org),
        base_url=updates.get("base_url", creds.base_url),
    )
    credentials.save(new_creds)

    stderr.print()
    for key, value in updates.items():
        say_ok(f"Set [bold]{key}[/bold] · {_redact_for_display(key, value)}")


@config_app.command("unset")
def config_unset(
    keys: Annotated[
        list[str],
        typer.Argument(help="One or more config keys to clear (api_key, org, base_url)."),
    ],
):
    """Clear one or more config keys without touching the others.

    To clear everything at once use [bold]fruxon logout[/bold].
    """
    if not keys:
        say_err(
            "Pass at least one key to clear.",
            hint="Run [bold]fruxon config --help[/bold].",
        )
        raise typer.Exit(code=1)

    if stderr.is_terminal:
        print_banner(subtitle="config")

    creds = credentials.load()
    cleared: list[str] = []
    for key in keys:
        _ensure_config_key(key)
        if getattr(creds, key):
            cleared.append(key)

    new_creds = StoredCredentials(
        api_key=None if "api_key" in keys else creds.api_key,
        org=None if "org" in keys else creds.org,
        base_url=None if "base_url" in keys else creds.base_url,
    )

    # If everything is now empty, remove the file entirely instead of
    # leaving a `{}` shell behind. Symmetric with what ``logout`` does.
    if not (new_creds.api_key or new_creds.org or new_creds.base_url):
        credentials.clear()
    else:
        credentials.save(new_creds)

    stderr.print()
    if not cleared:
        say_info("Nothing to clear — those keys were already unset.")
        return
    for key in cleared:
        say_ok(f"Cleared [bold]{key}[/bold]")
