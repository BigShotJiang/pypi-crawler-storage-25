---
name: fruxon-meet
description: >
  Quick orientation to Fruxon — what it is, what an "agent" / "revision" /
  "flow" / "integration" / "tool" is, and the CLI's main entry points. Load
  this when the user mentions Fruxon for the first time, or asks "how does
  Fruxon work" / "what can the fruxon CLI do" / "where do I start".
---

# Meet Fruxon

Fruxon is an AgentOps platform — you author multi-step LLM workflows
("agents"), connect them to integrations (Slack, GitHub, Jira, Google
Drive, …), test them against draft definitions, and deploy them as
versioned revisions. The `fruxon` CLI is the programmatic surface — the
same actions the web UI does, scriptable.

## The four core nouns

**Agent** — a named workflow. Has metadata (id, displayName, type,
tags) and a current deployed revision. Identified by an `id` like
`my_research_agent` (lowercase + underscores).

**Revision** — a versioned snapshot of an agent's behavior: its
**flow**, parameter schema, integration configs, LLM provider configs,
and assets. Revisions are immutable once created; you create a new one
to change behavior and `deploy` it to make it live.

**Flow** — the graph that defines what the agent does. Made of
**steps** (typed nodes) wired by **edges**. Every flow has exactly one
`ENTRY_POINT` and one `EXIT_POINT`; the work happens in `AGENT` /
`TOOL` / `CLAUDE_BOX` steps in between.

**Integration** — a connection to a third-party service (Slack, GitHub,
…) carrying auth credentials. **Tools** are the individual operations
that integration exposes (`slack.send_message`, `github.list_commits`,
…). An agent step uses tools that are pinned to a specific
`integrationConfig` belonging to its revision.

## The CLI surface (top-level commands)

```
fruxon login                       # one-time auth
fruxon doctor                      # diagnose CLI/env state
fruxon agents list                 # browse agents
fruxon agents get <id>             # inspect one
fruxon agents create               # provision a new agent shell
fruxon agents test <id>            # run a draft flow without publishing
fruxon agents revisions create     # author a new revision
fruxon agents revisions deploy     # ship any revision
fruxon run <id> -p key=value       # execute the deployed revision
fruxon chat <id>                   # interactive chat
fruxon trace <id> <record-id>      # inspect an execution
fruxon integrations list           # browse integrations
fruxon integrations create         # add one from a JSON spec
fruxon tools list <integration>    # browse tools under an integration
fruxon tools create <integration>  # add one
fruxon skills list                 # the procedural how-to guides (this set)
fruxon skills show <name>          # print a skill to stdout
```

Every **write command** that takes `--file` also accepts `--schema` —
prints the JSON Schema for the request body so an LLM authoring it has
the exact shape, all enums, and the polymorphic step variants.

## The build-an-agent loop

```bash
fruxon integrations list                                # know what's connected
fruxon tools list <integration>                         # know its tools
fruxon agents revisions create <agent> --schema         # see the body shape
# author CreateAgentRevision JSON
fruxon agents test <agent> --file rev.json -p k=v       # dry-run
fruxon agents revisions create <agent> --file rev.json --deploy
```

If you're authoring an agent for the first time, load the
`fruxon-build-agent` skill — it walks through this loop in detail with
worked examples.

## Attribution

Every write the CLI makes carries an actor identifier (`claude-code`,
`cursor`, `cli`, `web`, …) auto-detected from the environment. The
backend stamps it next to `createdBy` on every revision and deploy, so
"who really did this?" has two answers — the user (authoritative) and
the tool (informational). No setup required.

## When to use which skill

- **fruxon-meet** (this one) — orientation.
- **fruxon-build-agent** — author a working agent revision end-to-end.
- **fruxon-use-integrations** — wire tools into a step.
- **fruxon-debug-revision** — diagnose a revision that won't deploy or
  fails at run time.
