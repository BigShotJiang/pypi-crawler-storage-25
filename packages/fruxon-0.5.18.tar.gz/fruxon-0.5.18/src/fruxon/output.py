"""Output formatting for the ``fruxon run`` non-stream path.

Three formats today: ``text`` (just the response body — pipe-safe default),
``json`` (the full ``ExecutionResult`` as JSON), and ``table`` (a tabular
breakdown for humans reading the terminal). Adding more is a single new
function plus a name in :data:`FORMATS`.

The split between "format" (what the bytes look like) and "destination"
(stdout) is deliberate: every formatter writes a string that's safe to
pipe, which lets us keep the branded chrome strictly on stderr.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fruxon.fruxon import ExecutionResult

FORMATS = ("text", "json", "table")


class UnknownFormatError(ValueError):
    """Raised when ``--output`` gets a value not in :data:`FORMATS`."""


@dataclass(frozen=True)
class Formatted:
    """A formatter's output, split into two halves.

    ``stdout`` is the part that should land on stdout (pipe-safe, no ANSI
    chrome). ``stderr_table`` is a ``rich.table.Table`` object for the
    table format only — the CLI prints it to stderr via rich's renderer so
    box-drawing and color don't end up in pipes. Most formatters leave it
    ``None``.
    """

    stdout: str
    stderr_table: object | None = None


def format_result(result: ExecutionResult, fmt: str) -> Formatted:
    """Render an ``ExecutionResult`` in the requested format.

    Raises :class:`UnknownFormatError` for unknown formats so callers can
    convert that into a CLI error with a clear list of valid options.
    """
    handler = _HANDLERS.get(fmt)
    if handler is None:
        raise UnknownFormatError(fmt)
    return handler(result)


def _format_text(result: ExecutionResult) -> Formatted:
    """Just the response body, exactly as the agent returned it.

    This is what most callers want for piping: ``fruxon run … | jq``,
    ``| less``, ``| grep``, etc. Trace metadata stays out of stdout — it's
    available via ``--output json`` for callers that want it.
    """
    return Formatted(stdout=result.response)


def _format_json(result: ExecutionResult) -> Formatted:
    """The full result as JSON, indented for readability.

    Pretty-printed by default because the typical consumer is either a
    human reading it in a terminal or a script that re-parses it (where
    indentation doesn't matter). Single-line output is one ``--no-indent``
    flag away if it becomes a common ask.
    """
    payload = {
        "response": result.response,
        "sessionId": result.session_id,
        "executionRecordId": result.execution_record_id,
        "trace": {
            "agentId": result.trace.agent_id,
            "agentRevision": result.trace.agent_revision,
            "duration": result.trace.duration,
            "inputCost": result.trace.input_cost,
            "outputCost": result.trace.output_cost,
            "totalCost": result.trace.total_cost,
        },
        "links": result.links,
    }
    return Formatted(stdout=json.dumps(payload, indent=2))


def _format_table(result: ExecutionResult) -> Formatted:
    """Human-friendly tabular breakdown.

    Response text lands on stdout (still pipe-safe). The execution
    breakdown ships as a rich ``Table`` rendered to stderr — that way
    ``fruxon run … --output table > body.txt`` saves just the response and
    the metadata pretty-prints inline on the terminal.
    """
    from rich.table import Table

    table = Table(
        show_header=False,
        show_edge=False,
        pad_edge=False,
        box=None,
        padding=(0, 2),
    )
    table.add_column(style="dim")
    table.add_column(style="bold")
    table.add_row("Agent", result.trace.agent_id or "—")
    table.add_row("Revision", str(result.trace.agent_revision) if result.trace.agent_revision else "—")
    table.add_row("Session", result.session_id or "—")
    table.add_row("Record", result.execution_record_id or "—")
    if result.trace.duration:
        from fruxon.ui import format_duration

        table.add_row("Duration", format_duration(result.trace.duration))
    if result.trace.total_cost:
        table.add_row(
            "Cost",
            f"${result.trace.total_cost:.4f} (in ${result.trace.input_cost:.4f} · out ${result.trace.output_cost:.4f})",
        )

    return Formatted(stdout=result.response, stderr_table=table)


_HANDLERS = {
    "text": _format_text,
    "json": _format_json,
    "table": _format_table,
}
