"""Tests for the PyPI update notifier."""

from __future__ import annotations

import pytest

from fruxon import update_check


@pytest.fixture(autouse=True)
def isolated(tmp_path, monkeypatch):
    """Point the cache at a tempdir and clear conflicting env vars."""
    monkeypatch.setenv("FRUXON_CONFIG_DIR", str(tmp_path))
    for var in ("FRUXON_NO_UPDATE_CHECK", "FRUXON_NO_BANNER", "CI"):
        monkeypatch.delenv(var, raising=False)
    return tmp_path


class TestTupleVersionFallback:
    """When `packaging` isn't available, we fall back to tuple comparison."""

    def test_orders_dotted_integers(self):
        assert update_check._tuple_version("0.4.0") > update_check._tuple_version("0.3.99")

    def test_strips_pre_release_suffix_per_segment(self):
        # "0.3.1rc2" → (0, 3, 1) — drops the non-digit suffix so it sorts
        # alongside a real release with the same numeric prefix.
        assert update_check._tuple_version("0.3.1rc2") == (0, 3, 1)

    def test_empty_segments_become_zero(self):
        assert update_check._tuple_version("..") == (0, 0, 0)


class TestCacheFailureModes:
    def test_malformed_cache_file_is_ignored(self, tmp_path):
        path = update_check._cache_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("{not json")
        # Bad cache shouldn't crash — just refetch.
        called = {"n": 0}

        def fetcher():
            called["n"] += 1
            return "9.9.9"

        update_check.maybe_notify(current="0.3.1", fetcher=fetcher)
        assert called["n"] == 1

    def test_save_cache_swallows_oserror(self, tmp_path, monkeypatch):
        # Force the path's parent.mkdir to raise, simulate a read-only FS.
        def boom(*args, **kwargs):
            raise OSError("read-only")

        monkeypatch.setattr("fruxon.update_check.Path.write_text", boom)
        # maybe_notify shouldn't raise even though the cache write fails.
        msg = update_check.maybe_notify(current="0.3.1", fetcher=lambda: "9.9.9")
        assert msg is not None


class TestFetchLatest:
    def test_returns_none_on_url_error(self, monkeypatch):
        import urllib.error

        def opener(*a, **kw):
            raise urllib.error.URLError("DNS")

        monkeypatch.setattr("fruxon.update_check.urllib.request.urlopen", opener)
        assert update_check._fetch_latest() is None

    def test_extracts_version_from_payload(self, monkeypatch):
        import json

        class _Resp:
            def __init__(self, payload):
                self._payload = payload

            def __enter__(self):
                return self

            def __exit__(self, *args):
                pass

            def read(self):
                return self._payload

        def opener(req, timeout):
            return _Resp(json.dumps({"info": {"version": "9.9.9"}}).encode("utf-8"))

        monkeypatch.setattr("fruxon.update_check.urllib.request.urlopen", opener)
        assert update_check._fetch_latest() == "9.9.9"


class TestVersionComparison:
    def test_newer_patch(self):
        assert update_check._is_newer("0.3.2", "0.3.1") is True

    def test_newer_minor(self):
        assert update_check._is_newer("0.4.0", "0.3.9") is True

    def test_same_version(self):
        assert update_check._is_newer("0.3.1", "0.3.1") is False

    def test_older(self):
        assert update_check._is_newer("0.3.0", "0.3.1") is False


class TestEnvGating:
    def test_disabled_by_no_update_check(self, monkeypatch):
        monkeypatch.setenv("FRUXON_NO_UPDATE_CHECK", "1")
        assert update_check.maybe_notify(current="0.3.1", fetcher=lambda: "9.9.9") is None

    def test_disabled_by_no_banner(self, monkeypatch):
        # If branding chrome is off, the update banner is chrome too.
        monkeypatch.setenv("FRUXON_NO_BANNER", "1")
        assert update_check.maybe_notify(current="0.3.1", fetcher=lambda: "9.9.9") is None

    def test_disabled_in_ci(self, monkeypatch):
        monkeypatch.setenv("CI", "true")
        assert update_check.maybe_notify(current="0.3.1", fetcher=lambda: "9.9.9") is None


class TestNotifyMessage:
    def test_returns_message_when_newer_available(self):
        msg = update_check.maybe_notify(current="0.3.1", fetcher=lambda: "0.4.0")
        assert msg is not None
        assert "0.3.1" in msg
        assert "0.4.0" in msg
        assert "pip install -U fruxon" in msg

    def test_returns_none_when_already_current(self):
        assert update_check.maybe_notify(current="0.4.0", fetcher=lambda: "0.4.0") is None


class TestCaching:
    def test_uses_cache_within_ttl(self):
        calls = {"n": 0}

        def fetcher():
            calls["n"] += 1
            return "9.9.9"

        # First call hits the fetcher and writes the cache.
        first = update_check.maybe_notify(current="0.3.1", fetcher=fetcher, now=lambda: 1000.0)
        assert first is not None
        assert calls["n"] == 1

        # Second call within the TTL doesn't hit the fetcher.
        second = update_check.maybe_notify(current="0.3.1", fetcher=fetcher, now=lambda: 1500.0)
        assert second is not None
        assert calls["n"] == 1

    def test_refreshes_cache_after_ttl(self):
        calls = {"n": 0}

        def fetcher():
            calls["n"] += 1
            return "9.9.9"

        update_check.maybe_notify(current="0.3.1", fetcher=fetcher, now=lambda: 1000.0)
        # Bump time well past the 24h TTL.
        future = 1000.0 + update_check.CACHE_TTL_SECONDS + 1
        update_check.maybe_notify(current="0.3.1", fetcher=fetcher, now=lambda: future)
        assert calls["n"] == 2


class TestFailureModes:
    def test_fetcher_failure_returns_none_silently(self):
        def boom():
            raise RuntimeError("PyPI down")

        # A broken update check must NEVER raise from this function — the
        # CLI relies on swallowing failures so the user's actual command
        # can proceed.
        assert update_check.maybe_notify(current="0.3.1", fetcher=boom) is None

    def test_fetcher_returns_none_returns_none(self):
        assert update_check.maybe_notify(current="0.3.1", fetcher=lambda: None) is None

    def test_no_installed_version_returns_none(self, monkeypatch):
        # Running from source (no installed distribution): there's no
        # current version to compare against, so the notifier bails before
        # bothering PyPI. Simulate by making metadata.version raise.
        from importlib.metadata import PackageNotFoundError

        def boom(_name):
            raise PackageNotFoundError("fruxon")

        monkeypatch.setattr(update_check.metadata, "version", boom)
        assert (
            update_check.maybe_notify(
                current=None,
                fetcher=lambda: pytest.fail("should not have called PyPI"),
            )
            is None
        )
