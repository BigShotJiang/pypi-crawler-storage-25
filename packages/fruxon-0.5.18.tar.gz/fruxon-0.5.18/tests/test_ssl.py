"""Tests for ``fruxon._ssl.context_for`` — the single resolver every
HTTPS call site shares. The point of these tests is to lock in the
precedence order so a future edit can't quietly let, say, a custom CA
bundle override the loopback escape hatch (which would be confusing
since loopback verification was never enabled to begin with)."""

from __future__ import annotations

import ssl
from pathlib import Path

import pytest

from fruxon import _ssl as ssl_mod


@pytest.fixture(autouse=True)
def _reset_warning(monkeypatch: pytest.MonkeyPatch) -> None:
    ssl_mod._reset_warning_state_for_tests()


@pytest.mark.parametrize(
    "url",
    [
        "http://localhost:8080",
        "https://localhost:8443",
        "https://127.0.0.1:8443",
        "https://[::1]:8443",
    ],
)
def test_loopback_returns_unverified_context(url: str) -> None:
    ctx = ssl_mod.context_for(url)
    assert ctx is not None
    assert ctx.verify_mode == ssl.CERT_NONE
    assert ctx.check_hostname is False


def test_remote_host_returns_none_by_default() -> None:
    assert ssl_mod.context_for("https://api.fruxon.com") is None


def test_ca_bundle_loads_default_context_with_extra_ca(monkeypatch: pytest.MonkeyPatch, tmp_path) -> None:
    # We don't need a *valid* cert here, just a PEM file Python's ssl
    # module will accept. Copy the system bundle so the call succeeds
    # end-to-end without depending on certifi being installed.
    cafile = ssl.get_default_verify_paths().cafile
    if not cafile:
        pytest.skip("no system CA bundle available to copy")
    bundle = tmp_path / "ca.pem"
    bundle.write_bytes(Path(cafile).read_bytes())
    monkeypatch.setenv("FRUXON_CA_BUNDLE", str(bundle))

    ctx = ssl_mod.context_for("https://api.fruxon.com")

    assert ctx is not None
    assert ctx.verify_mode == ssl.CERT_REQUIRED
    assert ctx.check_hostname is True


def test_ca_bundle_ignored_for_loopback(monkeypatch: pytest.MonkeyPatch, tmp_path) -> None:
    # Loopback wins over CA bundle: the dev case is "I'm hitting my own
    # self-signed local server" and we shouldn't try to verify against a
    # bundle that won't contain the local cert.
    monkeypatch.setenv("FRUXON_CA_BUNDLE", str(tmp_path / "nonexistent.pem"))
    ctx = ssl_mod.context_for("https://localhost:8443")
    assert ctx is not None
    assert ctx.verify_mode == ssl.CERT_NONE


def test_insecure_env_disables_verification(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.setenv("FRUXON_INSECURE", "1")
    ctx = ssl_mod.context_for("https://staging.example.com")
    assert ctx is not None
    assert ctx.verify_mode == ssl.CERT_NONE
    err = capsys.readouterr().err
    assert "FRUXON_INSECURE" in err
    assert "staging.example.com" in err


def test_insecure_warning_fires_only_once(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]) -> None:
    monkeypatch.setenv("FRUXON_INSECURE", "1")
    ssl_mod.context_for("https://a.example.com")
    ssl_mod.context_for("https://b.example.com")
    err = capsys.readouterr().err
    assert err.count("FRUXON_INSECURE") == 1


def test_ca_bundle_beats_insecure(monkeypatch: pytest.MonkeyPatch, tmp_path) -> None:
    # If a user has both set, prefer the safer (verifying) path. Mostly
    # a sanity check — having both set is almost certainly a mistake.
    cafile = ssl.get_default_verify_paths().cafile
    if not cafile:
        pytest.skip("no system CA bundle available to copy")
    bundle = tmp_path / "ca.pem"
    bundle.write_bytes(Path(cafile).read_bytes())
    monkeypatch.setenv("FRUXON_CA_BUNDLE", str(bundle))
    monkeypatch.setenv("FRUXON_INSECURE", "1")

    ctx = ssl_mod.context_for("https://api.fruxon.com")
    assert ctx is not None
    assert ctx.verify_mode == ssl.CERT_REQUIRED
