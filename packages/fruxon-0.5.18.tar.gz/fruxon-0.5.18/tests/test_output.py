"""Tests for ``fruxon.output`` formatters."""

from __future__ import annotations

import json

import pytest

from fruxon.fruxon import ExecutionResult, ExecutionTrace
from fruxon.output import FORMATS, UnknownFormatError, format_result


def _sample() -> ExecutionResult:
    return ExecutionResult(
        response="Here is the answer.",
        trace=ExecutionTrace(
            agent_id="agent-1",
            agent_revision=3,
            duration=5000,
            input_cost=0.001,
            output_cost=0.002,
            total_cost=0.003,
        ),
        session_id="sess-abc",
        links=[{"href": "https://example"}],
        execution_record_id="rec-123",
    )


class TestText:
    def test_returns_only_response_body(self):
        out = format_result(_sample(), "text")
        assert out.stdout == "Here is the answer."
        assert out.stderr_table is None


class TestJson:
    def test_includes_full_payload(self):
        out = format_result(_sample(), "json")
        assert out.stderr_table is None
        payload = json.loads(out.stdout)
        assert payload["response"] == "Here is the answer."
        assert payload["sessionId"] == "sess-abc"
        assert payload["executionRecordId"] == "rec-123"
        assert payload["trace"]["agentId"] == "agent-1"
        assert payload["trace"]["duration"] == 5000
        assert payload["trace"]["totalCost"] == 0.003
        assert payload["links"] == [{"href": "https://example"}]

    def test_pretty_prints_by_default(self):
        # Indented output is what humans see in their terminal; scripts that
        # care can re-parse trivially.
        out = format_result(_sample(), "json")
        assert "\n  " in out.stdout


class TestTable:
    def test_response_on_stdout_table_on_stderr(self):
        out = format_result(_sample(), "table")
        assert out.stdout == "Here is the answer."
        assert out.stderr_table is not None

    def test_table_includes_agent_revision_session_cost(self):
        from rich.console import Console

        out = format_result(_sample(), "table")
        # Render the rich Table to a string so we can assert content
        # without coupling to the box-drawing layout.
        buf = Console(record=True, width=120)
        buf.print(out.stderr_table)
        rendered = buf.export_text()
        assert "agent-1" in rendered
        # Durations route through ``format_duration``: a 5000ms run reads
        # as ``5.0s`` once we cross the one-second threshold.
        assert "5.0s" in rendered
        assert "$0.0030" in rendered
        assert "sess-abc" in rendered

    def test_table_omits_zero_cost_and_duration_rows(self):
        from rich.console import Console

        result = ExecutionResult(
            response="ok",
            trace=ExecutionTrace(
                agent_id="agent-1",
                agent_revision=0,
                duration=0,
                input_cost=0.0,
                output_cost=0.0,
                total_cost=0.0,
            ),
            session_id="",
            links=[],
            execution_record_id="",
        )
        out = format_result(result, "table")
        buf = Console(record=True, width=120)
        buf.print(out.stderr_table)
        rendered = buf.export_text()
        # Don't pollute the table with rows whose value is "0 ms" / "$0.0000"
        # — they're never the answer to the question someone's asking.
        assert "Duration" not in rendered
        assert "Cost" not in rendered


class TestUnknown:
    def test_raises_with_format_name(self):
        with pytest.raises(UnknownFormatError) as info:
            format_result(_sample(), "xml")
        assert "xml" in str(info.value)


class TestRegistry:
    def test_formats_constant_lists_every_handler(self):
        # If a contributor adds a handler but forgets to surface it in
        # ``FORMATS``, the CLI's ``--output`` choices will silently exclude
        # it. This pins the invariant.
        from fruxon.output import _HANDLERS

        assert set(FORMATS) == set(_HANDLERS.keys())
