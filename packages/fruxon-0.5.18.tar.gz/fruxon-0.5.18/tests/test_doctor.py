"""Tests for ``fruxon.doctor`` health checks."""

from __future__ import annotations

import urllib.error
import urllib.request
from io import BytesIO

import pytest

from fruxon import credentials, doctor


@pytest.fixture(autouse=True)
def isolated(tmp_path, monkeypatch):
    """Isolate every test from the user's real credentials and env vars."""
    monkeypatch.setenv("FRUXON_CONFIG_DIR", str(tmp_path))
    for var in ("FRUXON_API_KEY", "FRUXON_ORG", "FRUXON_BASE_URL"):
        monkeypatch.delenv(var, raising=False)
    return tmp_path


class TestPythonVersion:
    def test_always_returns_ok(self):
        result = doctor.check_python_version()
        assert result.status == "ok"
        assert "." in result.detail  # e.g. "3.12.4"


class TestSdkVersion:
    def test_reports_installed_version(self):
        # The SDK is installed editable in the test venv, so metadata exists.
        result = doctor.check_sdk_version()
        assert result.status == "ok"
        assert result.detail.startswith("v")


class TestCredentialsFile:
    def test_missing_file_warns(self):
        assert doctor.check_credentials_file().status == "warn"

    def test_empty_file_warns(self):
        credentials.save(credentials.StoredCredentials(org="acme"))
        # tenant-only file (no key) is still incomplete.
        result = doctor.check_credentials_file()
        assert result.status == "warn"
        assert "API key" in result.detail

    def test_full_file_passes(self):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        assert doctor.check_credentials_file().status == "ok"


class TestApiKey:
    def test_no_key_fails(self):
        assert doctor.check_api_key().status == "fail"

    def test_env_key_passes(self, monkeypatch):
        monkeypatch.setenv("FRUXON_API_KEY", "fxn_from_env")
        result = doctor.check_api_key()
        assert result.status == "ok"
        assert "from $FRUXON_API_KEY" in (result.hint or "")

    def test_file_key_passes(self):
        credentials.save(credentials.StoredCredentials(api_key="fxn_from_file"))
        result = doctor.check_api_key()
        assert result.status == "ok"
        assert "credentials file" in (result.hint or "")

    def test_redacts_value(self, monkeypatch):
        monkeypatch.setenv("FRUXON_API_KEY", "fxn_live_supersecretkey12345")
        result = doctor.check_api_key()
        # Only the last 4 chars survive; no leading secret entropy leaks.
        assert "supersecretkey" not in result.detail
        assert "fxn" not in result.detail
        assert result.detail == "•••••2345"


class TestOrg:
    def test_no_org_warns(self):
        # Tenant is optional (you can always pass --org per command) so
        # this is a warning, not a failure.
        assert doctor.check_org().status == "warn"

    def test_env_org_passes(self, monkeypatch):
        monkeypatch.setenv("FRUXON_ORG", "acme")
        result = doctor.check_org()
        assert result.status == "ok"
        assert result.detail == "acme"


class TestBaseUrl:
    def test_defaults_to_prod(self):
        result = doctor.check_base_url()
        assert result.status == "ok"
        assert result.detail == "https://api.fruxon.com"
        assert "default" in (result.hint or "")


class TestConnectivity:
    def test_success_when_server_responds(self):
        # Inject a fake opener that returns a context-manager-like object.
        class _Resp:
            def __enter__(self):
                return self

            def __exit__(self, *args):
                pass

        result = doctor.check_connectivity(opener=lambda *a, **kw: _Resp())
        assert result.status == "ok"

    def test_http_error_still_counts_as_reachable(self):
        # A 404/401 means we *did* reach the server; reachability passes.
        # We deliberately don't surface the status code in the detail
        # string: showing "server replied 401" next to a green ✓ reads as
        # alarming even though it's correct (auth status belongs to the
        # ``check_auth`` row below).
        def opener(*a, **kw):
            raise urllib.error.HTTPError(
                url="https://api.fruxon.com",
                code=404,
                msg="Not Found",
                hdrs=None,
                fp=BytesIO(b""),
            )

        result = doctor.check_connectivity(opener=opener)
        assert result.status == "ok"
        # Detail is just the base URL — no scary status-code annotation.
        assert "404" not in result.detail
        assert result.detail == "https://api.fruxon.com"

    def test_network_failure_is_a_fail(self):
        def opener(*a, **kw):
            raise urllib.error.URLError("DNS failure")

        result = doctor.check_connectivity(opener=opener)
        assert result.status == "fail"
        assert "DNS failure" in result.detail

    def test_malformed_base_url_fails(self, monkeypatch):
        monkeypatch.setenv("FRUXON_BASE_URL", "not-a-url")
        result = doctor.check_connectivity(opener=lambda *a, **kw: None)
        assert result.status == "fail"
        assert "malformed" in result.detail


class TestAuthProbe:
    """``check_auth`` hits an authenticated endpoint to confirm the key works."""

    def _stub_response(self, monkeypatch=None):
        # Return a stub opener that simulates a successful 2xx response.
        class _Resp:
            def __enter__(self):
                return self

            def __exit__(self, *args):
                pass

        return lambda *a, **kw: _Resp()

    def test_skipped_when_no_api_key(self):
        result = doctor.check_auth(opener=self._stub_response())
        assert result.status == "warn"
        assert "skipped" in result.detail.lower()

    def test_skipped_when_no_org(self, monkeypatch):
        monkeypatch.setenv("FRUXON_API_KEY", "fxn_x")
        # No tenant configured
        result = doctor.check_auth(opener=self._stub_response())
        assert result.status == "warn"
        assert "skipped" in result.detail.lower()

    def test_success_when_endpoint_responds_2xx(self, monkeypatch):
        monkeypatch.setenv("FRUXON_API_KEY", "fxn_x")
        monkeypatch.setenv("FRUXON_ORG", "acme")
        result = doctor.check_auth(opener=self._stub_response())
        assert result.status == "ok"
        assert "accepted" in result.detail

    def test_401_fails_with_login_hint(self, monkeypatch):
        from io import BytesIO

        monkeypatch.setenv("FRUXON_API_KEY", "fxn_x")
        monkeypatch.setenv("FRUXON_ORG", "acme")

        def opener(*a, **kw):
            raise urllib.error.HTTPError(
                url="https://api.fruxon.com",
                code=401,
                msg="Unauthorized",
                hdrs=None,
                fp=BytesIO(b""),
            )

        result = doctor.check_auth(opener=opener)
        assert result.status == "fail"
        assert "401" in result.detail
        assert "fruxon login" in (result.hint or "")

    def test_403_calls_out_org_access(self, monkeypatch):
        from io import BytesIO

        monkeypatch.setenv("FRUXON_API_KEY", "fxn_x")
        monkeypatch.setenv("FRUXON_ORG", "acme")

        def opener(*a, **kw):
            raise urllib.error.HTTPError(
                url="https://api.fruxon.com",
                code=403,
                msg="Forbidden",
                hdrs=None,
                fp=BytesIO(b""),
            )

        result = doctor.check_auth(opener=opener)
        assert result.status == "fail"
        assert "403" in result.detail
        assert "acme" in result.detail

    def test_404_flags_org_id_typo(self, monkeypatch):
        from io import BytesIO

        monkeypatch.setenv("FRUXON_API_KEY", "fxn_x")
        monkeypatch.setenv("FRUXON_ORG", "typoed-tenant")

        def opener(*a, **kw):
            raise urllib.error.HTTPError(
                url="https://api.fruxon.com",
                code=404,
                msg="Not Found",
                hdrs=None,
                fp=BytesIO(b""),
            )

        result = doctor.check_auth(opener=opener)
        assert result.status == "fail"
        assert "typoed-tenant" in result.detail

    def test_other_status_warns(self, monkeypatch):
        from io import BytesIO

        monkeypatch.setenv("FRUXON_API_KEY", "fxn_x")
        monkeypatch.setenv("FRUXON_ORG", "acme")

        def opener(*a, **kw):
            raise urllib.error.HTTPError(
                url="https://api.fruxon.com",
                code=500,
                msg="Server Error",
                hdrs=None,
                fp=BytesIO(b""),
            )

        result = doctor.check_auth(opener=opener)
        assert result.status == "warn"
        assert "500" in result.detail

    def test_network_failure_warns_and_defers_to_reachability(self, monkeypatch):
        monkeypatch.setenv("FRUXON_API_KEY", "fxn_x")
        monkeypatch.setenv("FRUXON_ORG", "acme")

        def opener(*a, **kw):
            raise urllib.error.URLError("connection refused")

        result = doctor.check_auth(opener=opener)
        # Not a "fail" — reachability check above will surface the
        # actionable error. This one defers so we don't double-report.
        assert result.status == "warn"
        assert "reachability" in (result.hint or "")


class TestShellCompletion:
    def test_detects_fragment_in_rc_file(self, tmp_path, monkeypatch):
        # Pretend our home is a tempdir with a .zshrc that references fruxon.
        monkeypatch.setattr("fruxon.doctor.Path.home", lambda: tmp_path)
        (tmp_path / ".zshrc").write_text("# fruxon completion\nautoload -U compinit\n")
        result = doctor.check_shell_completion()
        assert result.status == "ok"
        assert "installed" in result.detail

    def test_missing_completion_still_ok_with_install_hint(self, tmp_path, monkeypatch):
        monkeypatch.setattr("fruxon.doctor.Path.home", lambda: tmp_path)
        result = doctor.check_shell_completion()
        # Stays "ok" so doctor doesn't degrade for an optional feature.
        assert result.status == "ok"
        assert "not installed" in result.detail
        assert "fruxon --install-completion" in (result.hint or "")


class TestRunChecks:
    def test_runs_every_check_including_network_by_default(self):
        # No real network in tests — confirm the network check is in the list
        # by counting (without a mocked opener it would actually hit the net).
        # Use a monkeypatched opener via the public helper to keep it offline.
        results = doctor.run_checks(skip_network=True)
        titles = [r.title for r in results]
        assert titles == [
            "Python interpreter",
            "Fruxon SDK",
            "Credentials file",
            "API key",
            "Organization",
            "Base URL",
            "Shell completion",
        ]

    def test_includes_auth_probe_when_network_allowed(self, tmp_path, monkeypatch):
        # ``check_auth`` joins the list whenever skip_network is False. We
        # don't need it to actually succeed — just to appear.
        monkeypatch.setenv("FRUXON_API_KEY", "fxn_x")
        monkeypatch.setenv("FRUXON_ORG", "acme")
        # Patch out the real network calls so the test stays offline.
        monkeypatch.setattr(
            doctor,
            "check_connectivity",
            lambda **_: doctor.CheckResult("API reachability", "ok", "stubbed"),
        )
        monkeypatch.setattr(
            doctor,
            "check_auth",
            lambda **_: doctor.CheckResult("Authenticated probe", "ok", "stubbed"),
        )
        results = doctor.run_checks(skip_network=False)
        titles = [r.title for r in results]
        assert "API reachability" in titles
        assert "Authenticated probe" in titles

    def test_skip_network_omits_reachability(self):
        results = doctor.run_checks(skip_network=True)
        assert all(r.title != "API reachability" for r in results)


class TestOverallStatus:
    def _r(self, status):
        return doctor.CheckResult(title="t", status=status, detail="d")

    def test_all_ok(self):
        assert doctor.overall_status([self._r("ok"), self._r("ok")]) == "ok"

    def test_any_warn(self):
        assert doctor.overall_status([self._r("ok"), self._r("warn")]) == "warn"

    def test_any_fail_overrides_warn(self):
        assert doctor.overall_status([self._r("warn"), self._r("fail")]) == "fail"
