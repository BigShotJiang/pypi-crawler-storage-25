"""Tests for the ``--schema`` flag's underlying machinery.

``fruxon.cli._schema`` pulls the deployed OpenAPI spec, walks the
``$ref`` closure from a single root, and emits a self-contained JSON
Schema document. The contract worth pinning down:

- the result is rooted at the requested type and has a ``$defs`` map;
- ``components/schemas`` refs get rewritten to ``$defs`` refs;
- the closure is transitive (a type referenced by a referenced type is
  included);
- an unknown type fails loudly (typer.Exit(1)) with no half-printed JSON;
- the spec is fetched once per base URL (cached).
"""

from __future__ import annotations

import json
from io import StringIO
from unittest.mock import patch

import pytest
import typer

from fruxon.cli import _schema


@pytest.fixture(autouse=True)
def _clear_cache():
    _schema._spec_cache.clear()
    yield
    _schema._spec_cache.clear()


FAKE_SPEC = {
    "components": {
        "schemas": {
            "Root": {
                "type": "object",
                "description": "The root type.",
                "properties": {
                    "child": {"$ref": "#/components/schemas/Child"},
                    "primitives": {"type": "array", "items": {"type": "string"}},
                },
            },
            "Child": {
                "type": "object",
                "description": "A nested type.",
                "properties": {
                    "leaf": {"$ref": "#/components/schemas/Leaf"},
                },
            },
            "Leaf": {
                "type": "string",
                "description": "A leaf type.",
            },
            "Unrelated": {
                "type": "object",
                "description": "Not reachable from Root.",
            },
        }
    }
}


def _run_print_schema(type_name: str) -> dict:
    """Capture the JSON printed by ``print_schema`` and return it parsed."""
    buf = StringIO()
    with patch.object(_schema, "_fetch_spec", return_value=FAKE_SPEC), patch("sys.stdout", buf):
        _schema.print_schema(type_name, base_url="https://example.test")
    return json.loads(buf.getvalue())


def test_root_is_a_ref_to_the_requested_type():
    out = _run_print_schema("Root")
    assert out["$ref"] == "#/$defs/Root"
    assert out["$schema"].startswith("https://json-schema.org/")


def test_refs_are_rewritten_to_defs():
    out = _run_print_schema("Root")
    root = out["$defs"]["Root"]
    assert root["properties"]["child"]["$ref"] == "#/$defs/Child"


def test_allof_inheritance_is_flattened():
    """OpenAPI polymorphism emits each variant as ``allOf: [{$ref: Base},
    {variant fields, additionalProperties: false}]``. The unflattened form
    fails strict JSON Schema validation — neither branch accepts the other's
    fields. The flattened form merges base + variant into one self-contained
    object that validators can actually use.
    """
    spec = {
        "components": {
            "schemas": {
                "Base": {
                    "type": "object",
                    "required": ["type"],
                    "properties": {
                        "type": {"type": "string"},
                        "id": {"type": "string"},
                    },
                    "additionalProperties": False,
                    "discriminator": {"propertyName": "type"},
                },
                "Variant": {
                    "description": "A variant of Base.",
                    "allOf": [
                        {"$ref": "#/components/schemas/Base"},
                        {
                            "type": "object",
                            "properties": {"extra": {"type": "string"}},
                            "additionalProperties": False,
                        },
                    ],
                },
            }
        }
    }
    buf = StringIO()
    with patch.object(_schema, "_fetch_spec", return_value=spec), patch("sys.stdout", buf):
        _schema.print_schema("Variant", base_url="https://example.test")
    out = json.loads(buf.getvalue())
    variant = out["$defs"]["Variant"]

    # Merged into a flat object, allOf gone.
    assert "allOf" not in variant
    assert variant["type"] == "object"
    # Base properties carried through.
    assert set(variant["properties"]) == {"type", "id", "extra"}
    # Base required-ness preserved.
    assert variant["required"] == ["type"]
    # Discriminator propagated from base so polymorphic dispatch survives.
    assert variant["discriminator"]["propertyName"] == "type"
    # The variant's own description is what shows up.
    assert variant["description"] == "A variant of Base."

    # And — the contract that matters — a concrete body validates strictly.
    # ``jsonschema`` is an optional dev dep (the SDK itself doesn't need it
    # at runtime — only this test does), so skip cleanly when it's missing
    # rather than turning the release pipeline red on a transitive omission.
    jsonschema = pytest.importorskip("jsonschema")
    jsonschema.validate({"type": "v", "id": "x", "extra": "ok"}, out)


def test_discriminator_mapping_values_are_rewritten():
    """OpenAPI's discriminator.mapping holds bare path strings — not $ref
    objects — that point at #/components/schemas/X. They must also rebase
    onto $defs or downstream tooling can't resolve the polymorphic variant.
    """
    spec = {
        "components": {
            "schemas": {
                "Base": {
                    "type": "object",
                    "description": "A polymorphic base.",
                    "properties": {"type": {"type": "string"}},
                    "discriminator": {
                        "propertyName": "type",
                        "mapping": {"A": "#/components/schemas/VariantA"},
                    },
                },
                "VariantA": {"type": "object", "description": "Variant A."},
            }
        }
    }
    buf = StringIO()
    with patch.object(_schema, "_fetch_spec", return_value=spec), patch("sys.stdout", buf):
        _schema.print_schema("Base", base_url="https://example.test")
    out = json.loads(buf.getvalue())
    assert out["$defs"]["Base"]["discriminator"]["mapping"]["A"] == "#/$defs/VariantA"


def test_closure_is_transitive_and_excludes_unrelated_types():
    out = _run_print_schema("Root")
    assert set(out["$defs"]) == {"Root", "Child", "Leaf"}


def test_unknown_type_exits_nonzero_without_emitting_partial_json(capsys):
    with pytest.raises(typer.Exit) as exc:
        with patch.object(_schema, "_fetch_spec", return_value=FAKE_SPEC):
            _schema.print_schema("DoesNotExist", base_url="https://example.test")
    assert exc.value.exit_code == 1
    # Nothing on stdout — the caller often pipes us into another tool, so a
    # half-document is worse than no document.
    assert capsys.readouterr().out == ""


def test_spec_is_cached_per_base_url():
    calls = []

    def fake_fetch(base_url: str) -> dict:
        calls.append(base_url)
        # First call populates the cache; subsequent calls must hit the cache
        # rather than this function.
        _schema._spec_cache[base_url] = FAKE_SPEC
        return FAKE_SPEC

    with patch.object(_schema, "_fetch_spec", side_effect=fake_fetch), patch("sys.stdout", StringIO()):
        _schema.print_schema("Root", base_url="https://example.test")
        _schema.print_schema("Child", base_url="https://example.test")

    # The second print_schema goes through _fetch_spec again (our patch),
    # but in production the real _fetch_spec consults _spec_cache first —
    # tested indirectly by exercising the real function once:
    _schema._spec_cache.clear()
    with patch("urllib.request.urlopen") as urlopen:
        cm = urlopen.return_value.__enter__.return_value
        cm.read.return_value = json.dumps(FAKE_SPEC).encode()
        cm.__iter__ = lambda self: iter([])
        # urllib.request.urlopen returns a context manager whose body
        # json.load() reads — easier to patch json.load directly.
        with patch("json.load", return_value=FAKE_SPEC):
            _schema._fetch_spec("https://example.test")
            _schema._fetch_spec("https://example.test")
        # Only the first call hit urlopen.
        assert urlopen.call_count == 1
