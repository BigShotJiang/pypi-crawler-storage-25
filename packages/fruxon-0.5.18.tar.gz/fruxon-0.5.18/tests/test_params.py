"""Tests for the smart parameter parser."""

from __future__ import annotations

import io
import json

import pytest

from fruxon.params import ParamError, parse


def _p(*flags: str, params_file: str | None = None, stdin: bool = False, stdin_text: str = ""):
    """Shorthand for the most common ``parse()`` call shape."""
    return parse(
        flag_values=list(flags),
        params_file=params_file,
        stdin_input=stdin,
        stdin_reader=io.StringIO(stdin_text),
    )


class TestNoInput:
    def test_returns_none_when_nothing_supplied(self):
        assert parse(flag_values=None, params_file=None, stdin_input=False) is None

    def test_returns_none_when_flag_list_is_empty(self):
        assert _p() is None


class TestScalarFlag:
    def test_basic_key_value(self):
        assert _p("question=Hello") == {"question": "Hello"}

    def test_value_can_contain_equals(self):
        assert _p("expr=a=b=c") == {"expr": "a=b=c"}

    def test_multiple_flags_merge(self):
        assert _p("q=Hello", "lang=en") == {"q": "Hello", "lang": "en"}

    def test_later_flag_overrides_earlier(self):
        # Matches every major CLI's resolution for repeated keys.
        assert _p("q=first", "q=second") == {"q": "second"}

    def test_missing_separator_errors_clearly(self):
        with pytest.raises(ParamError, match="key=value"):
            _p("question")

    def test_empty_key_errors(self):
        with pytest.raises(ParamError, match="Missing key"):
            _p("=value")


class TestTypedFlag:
    """`key:=…` parses the RHS as JSON so you can pass non-string scalars."""

    def test_number(self):
        assert _p("count:=42") == {"count": 42}

    def test_float(self):
        assert _p("temp:=0.7") == {"temp": 0.7}

    def test_boolean_lowercase(self):
        assert _p("verbose:=true") == {"verbose": True}

    def test_null(self):
        assert _p("seed:=null") == {"seed": None}

    def test_array(self):
        assert _p("tags:=[1,2,3]") == {"tags": [1, 2, 3]}

    def test_nested_object(self):
        assert _p('config:={"max":10,"min":1}') == {"config": {"max": 10, "min": 1}}

    def test_string_must_be_quoted(self):
        # Bare strings are invalid JSON — force the user to quote them so
        # there's no ambiguity vs `key=value` form.
        assert _p('name:="alice"') == {"name": "alice"}

    def test_invalid_json_errors(self):
        with pytest.raises(ParamError, match="not valid JSON"):
            _p("count:=not_json")

    def test_separator_inside_quotes_is_not_a_separator(self):
        # The string `a:=b` inside quotes shouldn't trick the parser.
        assert _p('tag:="a:=b"') == {"tag": "a:=b"}


class TestValueFromFile:
    def test_plain_text_file(self, tmp_path):
        f = tmp_path / "prompt.md"
        f.write_text("Long-form prompt content\nover multiple lines\n")
        assert _p(f"prompt=@{f}") == {"prompt": "Long-form prompt content\nover multiple lines\n"}

    def test_json_file_parses_to_object(self, tmp_path):
        f = tmp_path / "config.json"
        f.write_text('{"max": 10, "labels": ["a", "b"]}')
        assert _p(f"config=@{f}") == {"config": {"max": 10, "labels": ["a", "b"]}}

    def test_missing_file_errors(self):
        with pytest.raises(ParamError, match="File not found"):
            _p("config=@/no/such/file.json")

    def test_typed_value_from_file(self, tmp_path):
        # `key:=@file.json` always parses as JSON regardless of extension.
        f = tmp_path / "raw"
        f.write_text("[1, 2, 3]")
        assert _p(f"tags:=@{f}") == {"tags": [1, 2, 3]}


class TestSplatFlag:
    def test_object_splat_merges_into_params(self, tmp_path):
        f = tmp_path / "params.json"
        f.write_text('{"a": 1, "b": "two"}')
        assert _p(f"@{f}") == {"a": 1, "b": "two"}

    def test_splat_with_individual_flags(self, tmp_path):
        f = tmp_path / "base.json"
        f.write_text('{"a": 1, "b": 2}')
        # Splat first, then an individual flag overrides one key.
        assert _p(f"@{f}", "b=override") == {"a": 1, "b": "override"}

    def test_splat_non_object_errors(self, tmp_path):
        f = tmp_path / "array.json"
        f.write_text("[1, 2, 3]")
        with pytest.raises(ParamError, match="JSON object at the top level"):
            _p(f"@{f}")

    def test_splat_missing_path_errors(self):
        with pytest.raises(ParamError, match="missing the file path"):
            _p("@")


class TestParamsFile:
    def test_loads_object_from_file(self, tmp_path):
        f = tmp_path / "p.json"
        f.write_text('{"q": "hi", "n": 1}')
        assert _p(params_file=str(f)) == {"q": "hi", "n": 1}

    def test_non_object_errors(self, tmp_path):
        f = tmp_path / "p.json"
        f.write_text('"just a string"')
        with pytest.raises(ParamError, match="JSON object at the top level"):
            _p(params_file=str(f))

    def test_combines_with_flags(self, tmp_path):
        # File-supplied keys are overridden by later -p flags.
        f = tmp_path / "p.json"
        f.write_text('{"a": "from file", "b": "from file"}')
        assert _p("b=from flag", params_file=str(f)) == {
            "a": "from file",
            "b": "from flag",
        }


class TestStdin:
    def test_reads_full_json_from_stream(self):
        assert _p(stdin=True, stdin_text='{"x": 1}') == {"x": 1}

    def test_dash_path_alias_for_stdin(self):
        assert _p(params_file="-", stdin_text='{"x": 1}') == {"x": 1}

    def test_empty_stdin_errors(self):
        with pytest.raises(ParamError, match="No JSON found"):
            _p(stdin=True, stdin_text="")

    def test_non_object_stdin_errors(self):
        with pytest.raises(ParamError, match="object at the top level"):
            _p(stdin=True, stdin_text='"hello"')


class TestStdinValueShorthand:
    """``-p key=-`` reads the value from stdin until EOF."""

    def test_reads_stdin_into_named_value(self):
        assert _p("prompt=-", stdin_text="Long-form prompt\nspanning lines") == {
            "prompt": "Long-form prompt\nspanning lines"
        }

    def test_strips_single_trailing_newline(self):
        # Heredoc / echo adds a trailing newline that's almost never wanted
        # as part of the value. Strip exactly one to handle the common case
        # without clobbering deliberate trailing blanks.
        assert _p("prompt=-", stdin_text="hello\n") == {"prompt": "hello"}

    def test_combines_with_other_flags(self):
        assert _p("prompt=-", "lang=en", stdin_text="hi") == {
            "prompt": "hi",
            "lang": "en",
        }

    def test_multiple_keys_share_stdin(self):
        # Two `key=-` flags should both get the same cached stdin content
        # rather than the second one seeing an empty stream.
        result = _p("a=-", "b=-", stdin_text="shared")
        assert result == {"a": "shared", "b": "shared"}


class TestEdgeCases:
    def test_blank_flag_errors(self):
        with pytest.raises(ParamError, match="Empty parameter"):
            _p("   ")

    def test_empty_typed_value_separator(self):
        with pytest.raises(ParamError, match="Missing key"):
            _p(":=42")

    def test_typed_value_from_missing_file(self):
        with pytest.raises(ParamError, match="File not found"):
            _p("k:=@/no/such/file.json")

    def test_typed_value_missing_path(self):
        with pytest.raises(ParamError, match="missing the file path"):
            _p("k:=@")

    def test_value_file_missing_path(self):
        with pytest.raises(ParamError, match="missing the file path"):
            _p("k=@")

    def test_invalid_json_in_json_value_file(self, tmp_path):
        f = tmp_path / "broken.json"
        f.write_text("{ not json")
        with pytest.raises(ParamError, match="Invalid JSON"):
            _p(f"k=@{f}")

    def test_invalid_json_in_params_file(self, tmp_path):
        f = tmp_path / "broken.json"
        f.write_text("{ not json")
        with pytest.raises(ParamError, match="Invalid JSON"):
            _p(params_file=str(f))

    def test_invalid_json_on_stdin(self):
        with pytest.raises(ParamError, match="Invalid JSON on stdin"):
            _p(stdin=True, stdin_text="{ broken")


class TestPrecedence:
    def test_flag_overrides_params_file(self, tmp_path):
        f = tmp_path / "p.json"
        f.write_text('{"k": "from-file"}')
        assert _p("k=from-flag", params_file=str(f)) == {"k": "from-flag"}

    def test_later_flag_wins_over_earlier(self):
        assert _p("k=first", "k=second", "k=third") == {"k": "third"}

    def test_combined_sources_merge(self, tmp_path):
        f = tmp_path / "p.json"
        f.write_text(json.dumps({"a": 1, "b": 2}))
        assert _p("c:=3", params_file=str(f)) == {"a": 1, "b": 2, "c": 3}
