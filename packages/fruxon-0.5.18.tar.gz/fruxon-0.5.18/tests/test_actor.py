"""Tests for the actor-attribution header (``X-Fruxon-Actor``).

Every write a Fruxon CLI / SDK caller makes should carry two distinct
identities: the authenticated user (via API key, server-resolved) and
the *actor* — the tool that made the call (Claude Code, the CLI, the
web UI, …). The backend records both. Without this, an LLM that
authors an agent revision on a user's behalf is indistinguishable from
the user hand-editing the same revision — and "which percentage of
revisions are LLM-authored?" becomes unanswerable.

This module pins the auto-detection rules — they're what makes the
attribution reliable in practice. A user who runs `fruxon` directly
gets tagged `cli`; the same `fruxon` call inside Claude Code's harness
gets tagged `claude-code` automatically (Claude Code sets `CLAUDECODE=1`
on every spawn). An explicit `FRUXON_ACTOR` always wins.
"""

from __future__ import annotations

import sys
from unittest.mock import patch

import pytest

from fruxon.fruxon import FruxonClient, _detect_actor


@pytest.fixture(autouse=True)
def _clear_env(monkeypatch):
    for var in ("FRUXON_ACTOR", "CLAUDECODE", "CURSOR_TRACE_ID", "OPENAI_CODEX", "BOLT_TRACE_ID"):
        monkeypatch.delenv(var, raising=False)


@pytest.fixture
def fake_argv():
    """Patch ``sys.argv[0]`` so detection sees a CLI-shaped invocation."""
    with patch.object(sys, "argv", ["/usr/local/bin/fruxon", "agents", "list"]):
        yield


# ─────────────────────────── _detect_actor ─────────────────────────────


def test_explicit_env_wins(monkeypatch, fake_argv):
    monkeypatch.setenv("FRUXON_ACTOR", "ci-bot")
    monkeypatch.setenv("CLAUDECODE", "1")
    assert _detect_actor() == "ci-bot"


def test_claude_code_detected(monkeypatch, fake_argv):
    monkeypatch.setenv("CLAUDECODE", "1")
    assert _detect_actor() == "claude-code"


def test_cursor_detected(monkeypatch, fake_argv):
    monkeypatch.setenv("CURSOR_TRACE_ID", "abc123")
    assert _detect_actor() == "cursor"


def test_codex_detected(monkeypatch, fake_argv):
    monkeypatch.setenv("OPENAI_CODEX", "1")
    assert _detect_actor() == "codex"


def test_bolt_detected(monkeypatch, fake_argv):
    monkeypatch.setenv("BOLT_TRACE_ID", "abc")
    assert _detect_actor() == "bolt"


def test_default_cli_when_invoked_as_fruxon(fake_argv):
    assert _detect_actor() == "cli"


def test_no_actor_when_used_as_library():
    """Imported and used from Python — not the CLI, no harness markers.

    Returning None (rather than 'cli') keeps the header off the wire so
    SDK-as-library calls aren't misattributed to the CLI tool.
    """
    with patch.object(sys, "argv", ["python", "my_script.py"]):
        assert _detect_actor() is None


def test_empty_explicit_env_clears_actor(monkeypatch, fake_argv):
    """``FRUXON_ACTOR=`` (empty / whitespace) is the documented way to opt
    out of attribution — return None so the header is omitted, even
    when CLI auto-detection would otherwise kick in."""
    monkeypatch.setenv("FRUXON_ACTOR", "   ")
    assert _detect_actor() is None


# ───────────────────────── header injection ─────────────────────────────


def test_actor_param_overrides_detection():
    client = FruxonClient(api_key="k", org="o", actor="explicit-actor")
    headers = client._auth_headers({"Accept": "application/json"})
    assert headers["X-Fruxon-Actor"] == "explicit-actor"


def test_actor_header_omitted_when_unknown(monkeypatch):
    """When no actor can be detected, omit the header entirely.

    A missing header is unambiguous on the server side; a header with a
    placeholder value (e.g. 'unknown') would pollute the attribution
    column and force every dashboard to special-case the placeholder.
    """
    monkeypatch.setattr(sys, "argv", ["python", "x.py"])
    client = FruxonClient(api_key="k", org="o")
    headers = client._auth_headers({"Accept": "application/json"})
    assert "X-Fruxon-Actor" not in headers


def test_api_key_always_present():
    """Whether or not the actor is set, the API key header must be sent."""
    client = FruxonClient(api_key="key-123", org="o", actor=None)
    headers = client._auth_headers({})
    assert headers["X-API-KEY"] == "key-123"
