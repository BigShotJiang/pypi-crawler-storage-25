"""Tests for the on-disk credentials store and CLI-time precedence."""

from __future__ import annotations

import json
import os
import stat
from pathlib import Path

import pytest

from fruxon import credentials


@pytest.fixture(autouse=True)
def isolated_config_dir(tmp_path, monkeypatch):
    """Point every test at a per-test config dir.

    Honors the ``FRUXON_CONFIG_DIR`` env var so we never touch the real
    ``~/.fruxon`` while tests run, and clears the other Fruxon env vars
    so resolver tests can rely on the file/CLI inputs alone.
    """
    monkeypatch.setenv("FRUXON_CONFIG_DIR", str(tmp_path))
    for var in ("FRUXON_API_KEY", "FRUXON_ORG", "FRUXON_BASE_URL"):
        monkeypatch.delenv(var, raising=False)
    return tmp_path


class TestLoadSaveClear:
    def test_load_returns_empty_when_file_missing(self):
        creds = credentials.load()
        assert creds == credentials.StoredCredentials()

    def test_save_then_load_roundtrip(self):
        original = credentials.StoredCredentials(
            api_key="fxn_test",
            org="acme",
            base_url="https://staging.fruxon.com",
        )
        path = credentials.save(original)

        assert path == credentials.credentials_path()
        assert path.is_file()
        assert credentials.load() == original

    def test_save_omits_empty_fields_from_payload(self):
        credentials.save(credentials.StoredCredentials(api_key="fxn_test"))
        payload = json.loads(credentials.credentials_path().read_text())
        assert payload == {"api_key": "fxn_test"}

    def test_save_file_is_user_only_readable(self):
        # 0600 means "owner can read/write, group and other have no access."
        # Important for a file holding raw API keys on shared machines.
        if os.name == "nt":
            pytest.skip("File permission bits aren't meaningful on Windows.")
        credentials.save(credentials.StoredCredentials(api_key="fxn_test"))
        mode = credentials.credentials_path().stat().st_mode
        assert stat.S_IMODE(mode) == 0o600

    def test_clear_removes_file_and_reports_action(self):
        credentials.save(credentials.StoredCredentials(api_key="fxn_test"))
        assert credentials.clear() is True
        assert not credentials.credentials_path().exists()
        # Second call should report there was nothing to remove.
        assert credentials.clear() is False

    def test_malformed_file_yields_empty_record(self):
        # If the file gets corrupted (manual edit, partial write), routine
        # commands shouldn't crash — they should just fall back to env / flags.
        path = credentials.credentials_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("{not valid json")
        assert credentials.load() == credentials.StoredCredentials()

    def test_non_dict_top_level_yields_empty_record(self):
        path = credentials.credentials_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text('["fxn_test"]')
        assert credentials.load() == credentials.StoredCredentials()

    def test_empty_string_values_treated_as_absent(self):
        # Defensive — manual edits often leave "" instead of removing the key.
        path = credentials.credentials_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"api_key": "", "org": "acme"}))
        assert credentials.load() == credentials.StoredCredentials(org="acme")


class TestResolvers:
    """The three resolver functions implement: flag > env > file precedence."""

    def test_flag_wins_over_env_and_file(self, monkeypatch):
        monkeypatch.setenv("FRUXON_API_KEY", "from_env")
        credentials.save(credentials.StoredCredentials(api_key="from_file"))
        assert credentials.resolve_api_key("from_flag") == "from_flag"

    def test_env_wins_over_file(self, monkeypatch):
        monkeypatch.setenv("FRUXON_API_KEY", "from_env")
        credentials.save(credentials.StoredCredentials(api_key="from_file"))
        assert credentials.resolve_api_key(None) == "from_env"

    def test_file_used_when_flag_and_env_absent(self):
        credentials.save(credentials.StoredCredentials(api_key="from_file"))
        assert credentials.resolve_api_key(None) == "from_file"

    def test_returns_none_when_nothing_configured(self):
        assert credentials.resolve_api_key(None) is None

    def test_org_resolver_uses_its_own_env_var(self, monkeypatch):
        monkeypatch.setenv("FRUXON_ORG", "from_env")
        credentials.save(credentials.StoredCredentials(org="from_file"))
        assert credentials.resolve_org(None) == "from_env"

    def test_base_url_resolver_uses_its_own_env_var(self, monkeypatch):
        monkeypatch.setenv("FRUXON_BASE_URL", "https://from-env.fruxon.com")
        credentials.save(credentials.StoredCredentials(base_url="https://from-file.fruxon.com"))
        assert credentials.resolve_base_url(None) == "https://from-env.fruxon.com"


class TestConfigDir:
    def test_env_override_takes_precedence_over_home(self, tmp_path, monkeypatch):
        # Already set by the fixture, but verify it points where we expect.
        assert credentials.config_dir() == tmp_path

    def test_falls_back_to_home_when_env_absent(self, monkeypatch):
        monkeypatch.delenv("FRUXON_CONFIG_DIR", raising=False)
        assert credentials.config_dir() == Path.home() / credentials.CONFIG_DIR_NAME


class TestKeyringBackend:
    """``fruxon login`` puts the API key in the OS keychain when one is
    available, falling back to the JSON file otherwise. These tests
    exercise both modes by monkeypatching the keyring helpers directly
    — the conftest forces ``FRUXON_NO_KEYRING=1`` to keep tests off
    the real OS keychain.
    """

    def _fake_keyring(self, monkeypatch):
        """Install an in-memory keyring backend for one test.

        Replaces the three private helpers in :mod:`fruxon.credentials`
        with closures over a dict. Tests can inspect the dict to assert
        what got stored.
        """
        # ``FRUXON_NO_KEYRING`` is set in conftest; clear it so the
        # helpers actually call our fake instead of short-circuiting.
        monkeypatch.delenv("FRUXON_NO_KEYRING", raising=False)
        store: dict[tuple[str, str], str] = {}

        def fake_get():
            return store.get((credentials._KEYRING_SERVICE, credentials._KEYRING_USERNAME))

        def fake_set(value):
            store[(credentials._KEYRING_SERVICE, credentials._KEYRING_USERNAME)] = value
            return True

        def fake_delete():
            key = (credentials._KEYRING_SERVICE, credentials._KEYRING_USERNAME)
            if key in store:
                del store[key]
                return True
            return False

        monkeypatch.setattr(credentials, "_keyring_get", fake_get)
        monkeypatch.setattr(credentials, "_keyring_set", fake_set)
        monkeypatch.setattr(credentials, "_keyring_delete", fake_delete)
        return store

    def test_save_puts_api_key_in_keyring_not_file(self, monkeypatch):
        """When the keyring works, the API key is stored there only —
        no copy in the JSON file. That's the whole security win: a
        leaked ``cat ~/.fruxon/credentials`` doesn't expose the secret.
        """
        store = self._fake_keyring(monkeypatch)
        credentials.save(credentials.StoredCredentials(api_key="fxn_secret", org="acme"))

        # API key landed in the keyring.
        key = (credentials._KEYRING_SERVICE, credentials._KEYRING_USERNAME)
        assert store[key] == "fxn_secret"

        # Non-secret config still in the file...
        on_disk = credentials.credentials_path().read_text()
        assert "acme" in on_disk
        # ...but the api_key is NOT in the file payload.
        assert "fxn_secret" not in on_disk

    def test_load_prefers_keyring_over_file(self, monkeypatch):
        """If both stores have a value (migration window), keyring wins.
        This is what makes the file→keyring upgrade transparent on the
        user's next ``fruxon login``."""
        store = self._fake_keyring(monkeypatch)
        # Seed: an older install with the key in the file.
        credentials.credentials_path().parent.mkdir(parents=True, exist_ok=True)
        credentials.credentials_path().write_text('{"api_key": "old_file_key", "org": "acme"}')
        # New install puts a value in the keyring.
        store[(credentials._KEYRING_SERVICE, credentials._KEYRING_USERNAME)] = "new_keyring_key"

        loaded = credentials.load()
        assert loaded.api_key == "new_keyring_key"
        assert loaded.org == "acme"

    def test_save_sweeps_stale_file_api_key_after_keyring_success(self, monkeypatch):
        """If an older install had the key in the file, a successful
        keyring write must also strip the stale file copy so the secret
        only lives in one place."""
        self._fake_keyring(monkeypatch)
        credentials.credentials_path().parent.mkdir(parents=True, exist_ok=True)
        credentials.credentials_path().write_text('{"api_key": "old_file_key", "org": "acme"}')

        credentials.save(credentials.StoredCredentials(api_key="new_key", org="acme"))

        on_disk = credentials.credentials_path().read_text()
        assert "old_file_key" not in on_disk
        assert "new_key" not in on_disk

    def test_save_falls_back_to_file_when_keyring_fails(self, monkeypatch):
        """Locked-down hosts (no D-Bus, sealed containers) get the
        file fallback — the user can still sign in, just without the
        keychain hardening."""
        monkeypatch.delenv("FRUXON_NO_KEYRING", raising=False)

        def failing_set(_value):
            return False

        monkeypatch.setattr(credentials, "_keyring_set", failing_set)
        monkeypatch.setattr(credentials, "_keyring_get", lambda: None)
        monkeypatch.setattr(credentials, "_keyring_delete", lambda: False)

        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        on_disk = credentials.credentials_path().read_text()
        assert "fxn_x" in on_disk

    def test_clear_removes_keyring_entry(self, monkeypatch):
        """``fruxon logout`` must wipe the keyring too — leaving the
        key in place after a logout would be a real security bug."""
        store = self._fake_keyring(monkeypatch)
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        assert store  # sanity — keyring has the entry

        credentials.clear()
        assert not store
        assert not credentials.credentials_path().exists()

    def test_env_var_forces_file_only_storage(self, monkeypatch):
        """``FRUXON_NO_KEYRING=1`` is the escape hatch for users who
        explicitly don't want OS-keychain integration (corp policies,
        passphrase prompts on every read, etc.)."""
        # conftest already sets this; just verify the contract.
        assert os.environ["FRUXON_NO_KEYRING"] == "1"
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        on_disk = credentials.credentials_path().read_text()
        # Falls back to file storage transparently.
        assert "fxn_x" in on_disk
