"""Test-wide fixtures and environment scrubbing.

Run as part of every test by virtue of pytest auto-loading ``conftest.py``
from the tests directory. Nothing here is test-specific — it's the
"contract" we want every test to start from.
"""

from __future__ import annotations

import pytest

# Environment variables that toggle CLI behavior. Some of them propagate
# from the developer's shell (notably ``CLAUDECODE=1`` when running
# pytest from inside Claude Code, or ``CI=true`` in a build pipeline).
# Letting them leak into the test process makes assertions about the
# default human-facing UI flaky — tests would pass locally but fail in
# CI, or vice versa. Scrub them at session scope so every test starts
# from a clean "interactive human, no overrides" baseline.
_SCRUB_ENV = (
    "FRUXON_AGENT_MODE",
    "CLAUDECODE",
    "CI",
    "FRUXON_NO_BANNER",
    "FRUXON_NO_UPDATE_CHECK",
    "FRUXON_CA_BUNDLE",
    "FRUXON_INSECURE",
    "FRUXON_BRAND_COLOR",
    "FRUXON_GLYPH",
    "NO_COLOR",
    "COLORTERM",
    "TERMINAL_EMULATOR",
)


@pytest.fixture(autouse=True)
def _scrub_cli_env(monkeypatch: pytest.MonkeyPatch, tmp_path_factory: pytest.TempPathFactory) -> None:
    """Remove dev-shell env vars that change CLI defaults, and isolate
    the on-disk credentials store.

    Tests that want one of these signals on must set it explicitly via
    ``monkeypatch.setenv`` — making the dependency visible in the test
    rather than implicit in whoever's shell happens to be running.

    Forces ``FRUXON_NO_KEYRING=1`` so the credentials module falls back
    to file-only storage in tests. The real OS keychain persists across
    test runs (you'd contaminate the developer's actual Keychain on
    macOS!) and is interactive on some Linux backends — both wrong
    defaults for a test harness. Tests that specifically exercise the
    keyring path monkeypatch the helpers in ``fruxon.credentials``
    directly.

    Points ``FRUXON_CONFIG_DIR`` at a per-test temp directory. Without
    this, any test calling ``credentials.save()`` / ``credentials.clear()``
    reads and writes the *developer's real* ``~/.fruxon/credentials`` —
    a full test run silently overwrites whatever the user was signed in
    as. Each test gets its own fresh, empty config dir instead.
    """
    for var in _SCRUB_ENV:
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv("FRUXON_NO_KEYRING", "1")
    config_dir = tmp_path_factory.mktemp("fruxon-config")
    monkeypatch.setenv("FRUXON_CONFIG_DIR", str(config_dir))
