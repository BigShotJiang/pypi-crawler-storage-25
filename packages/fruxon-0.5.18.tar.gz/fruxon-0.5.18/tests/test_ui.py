"""Tests for the small presentation helpers in :mod:`fruxon.ui`.

The big surfaces (banners, ``say_*`` lines) are covered indirectly by
the CLI tests because what matters there is the rendered output. The
pure helpers in this module — formatting, redaction — get direct unit
coverage because they're cheap to pin and easy to regress.
"""

from __future__ import annotations

import pytest

from fruxon.ui import format_duration, redact_key


class TestFormatDurationSubSecond:
    """Below one second we want raw millisecond precision — the
    difference between 5ms and 500ms matters when you're staring at a
    tool-call line."""

    def test_zero(self):
        assert format_duration(0) == "0ms"

    def test_small_integer(self):
        assert format_duration(7) == "7ms"

    def test_hundreds(self):
        assert format_duration(850) == "850ms"

    def test_just_below_one_second(self):
        assert format_duration(999) == "999ms"

    def test_accepts_float_input(self):
        # SSE timing math can produce floats (endTime − startTime is
        # numeric — we don't want it to crash on a float we forgot to cast).
        assert format_duration(123.7) == "123ms"


class TestFormatDurationSeconds:
    """1s–60s: one decimal at the seconds boundary keeps the value
    readable without trailing noise (``12.8s`` vs ``12810ms``)."""

    def test_exact_one_second(self):
        assert format_duration(1000) == "1.0s"

    def test_one_decimal_at_seconds(self):
        assert format_duration(12_810) == "12.8s"

    def test_rounds_down(self):
        # ``f"{x:.1f}"`` uses banker's rounding; we just need it to be
        # deterministic and not crash. 5949 → 5.9, not 6.0.
        assert format_duration(5_949) == "5.9s"

    def test_just_below_one_minute(self):
        assert format_duration(59_999) == "60.0s"


class TestFormatDurationMinutes:
    """1m–60m: show both parts so 1m 0s isn't indistinguishable from
    1m 59s in scrollback."""

    def test_exact_one_minute(self):
        assert format_duration(60_000) == "1m 0s"

    def test_minute_with_seconds(self):
        assert format_duration(125_400) == "2m 5s"

    def test_just_below_one_hour(self):
        assert format_duration(3_599_000) == "59m 59s"


class TestFormatDurationHours:
    """Past one hour: seconds become rounding noise. ``2h 14m`` is what
    every readable progress UI prints; copy them."""

    def test_exact_one_hour(self):
        assert format_duration(3_600_000) == "1h 0m"

    def test_hours_with_minutes(self):
        assert format_duration(8_100_000) == "2h 15m"

    def test_long_run(self):
        # 25h 30m — confirm we don't accidentally roll over into days.
        assert format_duration(25 * 3_600_000 + 30 * 60_000) == "25h 30m"


class TestFormatDurationEdgeCases:
    def test_negative_ms_falls_through_with_ms_suffix(self):
        # Shouldn't happen — clock skew, off-by-one — but if it does we
        # want to surface the raw value, not silently print a positive
        # duration.
        assert format_duration(-5) == "-5ms"

    @pytest.mark.parametrize(
        "value,expected",
        [
            (999, "999ms"),
            (1000, "1.0s"),
            (59_999, "60.0s"),
            (60_000, "1m 0s"),
            (3_599_999, "59m 59s"),
            (3_600_000, "1h 0m"),
        ],
    )
    def test_bucket_boundaries(self, value, expected):
        # Parametrized boundary table — each line is a single-byte change
        # away from the next bucket. Easy to extend when new buckets land.
        assert format_duration(value) == expected


class TestRedactKey:
    """``redact_key`` reveals only the last 4 chars behind a fixed mask —
    enough to identify *which* key is in play, no secret entropy exposed
    on a shared terminal or in a pasted bug report."""

    def test_long_key_reveals_only_last_four(self):
        result = redact_key("fxn_live_supersecretkey12345")
        assert result == "•••••2345"
        # No leading chars of the secret leak through.
        assert "fxn" not in result
        assert "supersecret" not in result

    def test_mask_width_is_fixed_regardless_of_key_length(self):
        # A short and a long key redact to the same shape — the mask
        # doesn't hint at the underlying length.
        assert redact_key("fxn_short") == "•••••hort"
        assert redact_key("a" * 200) == "•••••aaaa"

    def test_very_short_key_fully_masked(self):
        # ≤ 4 chars: there's no safe slice, mask the whole thing.
        assert redact_key("ab") == "••"
        assert redact_key("abcd") == "••••"

    def test_empty_key(self):
        # Defensive — an empty key shouldn't crash the redaction helper.
        assert redact_key("") == ""


class TestAgentMode:
    """``is_agent_mode`` decides whether the CLI is being driven by an
    AI agent or automation — flipping the UX from styled chrome to a
    parseable surface. Detection must be cheap, deterministic, and
    only fire on signals that genuinely mean "not a human at a TTY."
    """

    def test_explicit_fruxon_agent_mode(self, monkeypatch):
        from fruxon.ui import is_agent_mode

        monkeypatch.setenv("FRUXON_AGENT_MODE", "1")
        assert is_agent_mode() is True

    def test_claudecode_env_signals_agent_mode(self, monkeypatch):
        """Claude Code sets ``CLAUDECODE=1`` in every spawned shell —
        the universal "an LLM is calling you" signal in that ecosystem."""
        from fruxon.ui import is_agent_mode

        monkeypatch.setenv("CLAUDECODE", "1")
        assert is_agent_mode() is True

    def test_ci_env_signals_agent_mode(self, monkeypatch):
        from fruxon.ui import is_agent_mode

        monkeypatch.setenv("CI", "true")
        assert is_agent_mode() is True

    def test_no_signals_means_human(self, monkeypatch):
        """All scrubbing happens in conftest — by default the test
        environment looks like an interactive human at the terminal."""
        from fruxon.ui import is_agent_mode

        assert is_agent_mode() is False

    def test_falsy_values_do_not_trigger(self, monkeypatch):
        """``CI=0`` / ``CI=false`` / ``CLAUDECODE=`` (empty) shouldn't
        flip agent mode — the env var existing isn't enough; it has to
        be a truthy value. This matches the convention every other
        ``CI``-aware tool uses."""
        from fruxon.ui import is_agent_mode

        monkeypatch.setenv("CI", "false")
        monkeypatch.setenv("CLAUDECODE", "0")
        monkeypatch.setenv("FRUXON_AGENT_MODE", "")
        assert is_agent_mode() is False

    def test_agent_mode_disables_banner(self, monkeypatch):
        """The whole point of agent mode is that AI callers don't get
        ANSI banners in their parsed output. Verify ``banner_enabled``
        composes the two signals correctly."""
        from fruxon.ui import banner_enabled

        monkeypatch.setenv("FRUXON_AGENT_MODE", "1")
        assert banner_enabled() is False


class TestForceTruecolor:
    """``_force_truecolor`` opts specific terminals into 24-bit color
    when they support it but don't advertise it via ``COLORTERM``.
    Motivating case: PyCharm's JediTerm. Without the override, the
    brand color downgrades to ANSI Red, which the IDE theme remaps
    to a warm orange — visibly off-brand.
    """

    def test_jediterm_forces_truecolor(self, monkeypatch):
        from fruxon.ui import _force_truecolor

        monkeypatch.delenv("COLORTERM", raising=False)
        monkeypatch.setenv("TERMINAL_EMULATOR", "JetBrains-JediTerm")
        assert _force_truecolor() is True

    def test_explicit_colorterm_skips_override(self, monkeypatch):
        """If ``COLORTERM`` is already ``truecolor``, Rich's own
        auto-detection handles it — no need to override."""
        from fruxon.ui import _force_truecolor

        monkeypatch.setenv("COLORTERM", "truecolor")
        monkeypatch.setenv("TERMINAL_EMULATOR", "JetBrains-JediTerm")
        assert _force_truecolor() is False

    def test_unknown_terminal_does_not_force(self, monkeypatch):
        """Forcing truecolor blindly on terminals that can't render
        it would surface as visible escape gibberish — limit the
        override to known-good emulators."""
        from fruxon.ui import _force_truecolor

        monkeypatch.delenv("COLORTERM", raising=False)
        monkeypatch.setenv("TERMINAL_EMULATOR", "some-random-thing")
        assert _force_truecolor() is False

    def test_no_terminal_emulator_env_does_not_force(self, monkeypatch):
        from fruxon.ui import _force_truecolor

        monkeypatch.delenv("COLORTERM", raising=False)
        monkeypatch.delenv("TERMINAL_EMULATOR", raising=False)
        assert _force_truecolor() is False
