"""MCP server — Walking-Skeleton slice.

Exposes only the `list_accounts` tool for now. The JSON-RPC / stdio
plumbing is provided by the official `mcp` SDK. Caller identity is
resolved from `IMAP_MCP_CALLER_ID` (stdio_trusted, ADR 0015), all
remaining auth types are deferred to later scenarios.

Adding a new tool here means: register another `@server.tool()` and
delegate the call to the relevant PDP / IMAP / audit routine. The
server module stays a thin dispatcher.
"""

from __future__ import annotations

import contextvars
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, TYPE_CHECKING

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.shared.exceptions import McpError
from mcp.types import (
    BlobResourceContents,
    CallToolRequest,
    CallToolResult,
    EmbeddedResource,
    ErrorData,
    ServerResult,
    TextContent,
    Tool,
)

if TYPE_CHECKING:
    from .audit import AuditWriter

from .audit import AuditWriter
from .saga import SagaManager
from .wal import WAL
from .config import load_configuration
from .imap_core import (
    TargetFolderMissing,
    UidNotFound,
    UidStale,
    append_message as imap_append_message,
    build_folder_alias_map,
    copy_message as imap_copy_message,
    fetch_body as imap_fetch_body,
    fetch_envelope as imap_fetch_envelope,
    fetch_envelopes_batch as imap_fetch_envelopes_batch,
    fetch_full_message as imap_fetch_full_message,
    folder_stats as imap_folder_stats,
    gmail_fetch_msgid as imap_gmail_fetch_msgid,
    gmail_label_swap as imap_gmail_label_swap,
    gmail_list_labels as imap_gmail_list_labels,
    gmail_search_by_msgid as imap_gmail_search_by_msgid,
    list_folders as imap_list_folders,
    move_message as imap_move_message,
    search_uids as imap_search_uids,
    store_flag as imap_store_flag,
    store_keywords as imap_store_keywords,
    mime_add_attachment,
    mime_replace_attachment,
    mime_delete_attachment,
)
from .policy import (
    MessageFacts,
    PolicyDecisionPoint,
    _match_single_predicate,
    evaluate_message_against_folder,
    level_rank,
)
from .secrets import build_secret_store


# Per-request override for the caller identity. The HTTP transport
# (ADR 0015 + LIM-0007 paydown) sets this in the bearer-auth middleware
# so that each request runs against the caller derived from its
# Authorization header. The stdio transport leaves it unset and falls
# back to the static `default_caller_id` resolved at startup.
_CURRENT_CALLER_ID: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "imap_mcp_current_caller_id", default=None
)


@dataclass
class _LiveState:
    """Mutable holder for state that SIGHUP swaps atomically (ADR 0014)."""

    pdp: PolicyDecisionPoint
    configuration: "object"  # Configuration; intentionally untyped here
    oauth_manager: "object | None" = None
    folder_aliases: dict[str, dict[str, str]] | None = None


@dataclass(frozen=True)
class ServerContext:
    default_caller_id: str
    _live: _LiveState
    secret_store: "object"  # SecretStore protocol
    audit: "AuditWriter | None" = None
    saga: "SagaManager | None" = None

    @property
    def caller_id(self) -> str:
        """Caller identity for the in-flight request.

        On HTTP transport the bearer-auth middleware sets a per-request
        ContextVar; on stdio it remains unset and the constructor-time
        default applies.
        """
        override = _CURRENT_CALLER_ID.get()
        return override if override is not None else self.default_caller_id

    @property
    def pdp(self) -> PolicyDecisionPoint:
        """Live PDP. Replaced atomically by SIGHUP reload."""
        return self._live.pdp

    @property
    def configuration(self):  # type: ignore[no-untyped-def]
        """Live configuration. Replaced atomically by SIGHUP reload."""
        return self._live.configuration

    @property
    def oauth_manager(self):  # type: ignore[no-untyped-def]
        if self._live.oauth_manager is None:
            raise RuntimeError("OAuthManager not initialized")
        return self._live.oauth_manager

    def account_by_id(self, account_id: str) -> "object | None":
        from .config import Configuration

        config: Configuration = self.configuration  # type: ignore[assignment]
        for account in config.accounts_file.accounts:
            if account.id == account_id:
                return account
        return None


def _package_version() -> str:
    from importlib.metadata import version

    try:
        return version("sc-imap-mcp")
    except Exception:
        pass
    import re
    from pathlib import Path

    pyproject = Path(__file__).resolve().parents[2] / "pyproject.toml"
    if pyproject.is_file():
        m = re.search(r'^version\s*=\s*"([^"]+)"', pyproject.read_text(), re.MULTILINE)
        if m:
            return m.group(1)
    return "0.0.0-dev"


def build_server(context: ServerContext) -> Server:
    app: Server = Server("imap-mcp", version=_package_version())

    @app.list_tools()
    async def _list_tools() -> list[Tool]:
        return [
            Tool(
                name="list_accounts",
                description=(
                    "List available email accounts. Call this FIRST to "
                    "discover which accounts you can access. Returns "
                    "account ids and their state (active/needs_rebootstrap)."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {},
                    "additionalProperties": False,
                    "x-mcp-imap": {"category": "read"},
                },
            ),
            Tool(
                name="list_folders",
                description=(
                    "List visible folders in an email account. "
                    "Returns folder names and hidden_folders_count."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {"account": {"type": "string"}},
                    "required": ["account"],
                    "additionalProperties": False,
                },
            ),
            Tool(
                name="fetch_envelope",
                description=(
                    "Fetch from/to/subject/date for a single message by "
                    "UID. Use list_messages instead when you need multiple "
                    "messages — it is much faster."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "account": {"type": "string"},
                        "folder": {"type": "string"},
                        "uid": {"type": "integer"},
                    },
                    "required": ["account", "folder", "uid"],
                    "additionalProperties": False,
                },
            ),
            Tool(
                name="search",
                description=(
                    "Search for message UIDs in a folder. Returns UIDs "
                    "only (no envelope data). Use list_messages instead "
                    "if you need from/subject/date. This tool is for "
                    "counting or for feeding UIDs into fetch_envelope."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "account": {"type": "string"},
                        "folder": {"type": "string"},
                        "criteria": {"type": "object"},
                        "limit": {"type": "integer", "minimum": 1, "default": 50},
                        "offset": {"type": "integer", "minimum": 0, "default": 0},
                    },
                    "required": ["account", "folder"],
                    "additionalProperties": False,
                },
            ),
            Tool(
                name="list_messages",
                description=(
                    "THE PRIMARY TOOL for reading emails. Returns from, "
                    "subject, date for each message in one call. "
                    "Use this for: 'show me my emails', 'what arrived "
                    "today', 'recent messages'. Supports criteria: "
                    '{"newer_than": "1d"} for today, '
                    '{"from_domain": "example.com"} for sender filter, '
                    '{"subject_contains": "invoice"} for subject search. '
                    "Always call list_accounts first to get the account id, "
                    "then call this with account, folder='INBOX'."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "account": {"type": "string"},
                        "folder": {"type": "string"},
                        "criteria": {"type": "object"},
                        "limit": {"type": "integer", "minimum": 1, "default": 20},
                        "offset": {"type": "integer", "minimum": 0, "default": 0},
                    },
                    "required": ["account", "folder"],
                    "additionalProperties": False,
                },
            ),
            Tool(
                name="fetch_headers",
                description=(
                    "Fetch the full RFC 5322 header block of a message. "
                    "Requires HEADERS-level visibility (ADR 0002)."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "account": {"type": "string"},
                        "folder": {"type": "string"},
                        "uid": {"type": "integer"},
                    },
                    "required": ["account", "folder", "uid"],
                    "additionalProperties": False,
                },
            ),
            Tool(
                name="fetch_attachment",
                description=(
                    "Fetch a single MIME attachment. Requires FULL visibility (ADR 0002)."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "account": {"type": "string"},
                        "folder": {"type": "string"},
                        "uid": {"type": "integer"},
                        "part_id": {"type": "string"},
                    },
                    "required": ["account", "folder", "uid"],
                    "additionalProperties": False,
                },
            ),
            Tool(
                name="fetch_body",
                description=(
                    "Fetch the plain/HTML body of a single message. "
                    "Only works if your visibility for this message is "
                    "BODY or FULL. Will return DENY if the sender is "
                    "not in your whitelist or your visibility is only "
                    "ENVELOPE. Use list_messages first to see which "
                    "messages you can access."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "account": {"type": "string"},
                        "folder": {"type": "string"},
                        "uid": {"type": "integer"},
                    },
                    "required": ["account", "folder", "uid"],
                    "additionalProperties": False,
                },
            ),
            Tool(
                name="mark_seen",
                description="Toggle the \\Seen flag on a message (ADR 0005).",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "account": {"type": "string"},
                        "folder": {"type": "string"},
                        "uid": {"type": "integer"},
                        "seen": {"type": "boolean"},
                    },
                    "required": ["account", "folder", "uid", "seen"],
                    "additionalProperties": False,
                },
            ),
            Tool(
                name="bulk_mark_seen",
                description=(
                    "Mark all messages matching criteria as read (or "
                    "unread) in one call. Use for 'mark all alerts as "
                    "read'. Searches by criteria, then sets \\Seen on "
                    "all matches in a single IMAP session. Returns "
                    "marked_count."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "account": {"type": "string"},
                        "folder": {"type": "string"},
                        "criteria": {"type": "object"},
                        "seen": {"type": "boolean"},
                    },
                    "required": ["account", "folder", "criteria", "seen"],
                    "additionalProperties": False,
                },
            ),
            Tool(
                name="mark_tagged",
                description="Add/remove/replace keywords on a message (ADR 0005).",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "account": {"type": "string"},
                        "folder": {"type": "string"},
                        "uid": {"type": "integer"},
                        "tags": {"type": "array", "items": {"type": "string"}},
                        "mode": {"type": "string", "enum": ["add", "remove", "replace"]},
                    },
                    "required": ["account", "folder", "uid", "tags", "mode"],
                    "additionalProperties": False,
                },
            ),
            Tool(
                name="move",
                description="Move a message between folders (ADR 0006). Intra-account native MOVE, cross-account saga.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "source": {"type": "object"},
                        "target": {"type": "object"},
                    },
                    "required": ["source", "target"],
                    "additionalProperties": False,
                },
            ),
            Tool(
                name="copy",
                description="Copy a message between folders (ADR 0006).",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "source": {"type": "object"},
                        "target": {"type": "object"},
                    },
                    "required": ["source", "target"],
                    "additionalProperties": False,
                },
            ),
            Tool(
                name="create_draft",
                description=(
                    "Append an RFC 5322 message to a folder as a draft. "
                    "Call list_folders first to get the correct folder "
                    "path. Gmail uses '[Gmail]/Drafts', not 'Drafts'."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "account": {"type": "string"},
                        "folder": {"type": "string"},
                        "rfc822": {"type": "string"},
                    },
                    "required": ["account", "folder", "rfc822"],
                    "additionalProperties": False,
                },
            ),
            Tool(
                name="describe_policy",
                description=(
                    "Return the caller's own policy profile. The caller "
                    "sees which accounts and folders are visible to them, "
                    "which capabilities are granted, and the count of "
                    "hidden accounts/folders — never the names of hidden "
                    "items, never rule patterns, never other callers' "
                    "policies (ADR 0017)."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {},
                    "additionalProperties": True,
                },
            ),
            Tool(
                name="get_transaction_status",
                description="Return the WAL state of a saga transaction.",
                inputSchema={
                    "type": "object",
                    "properties": {"tx_id": {"type": "string"}},
                    "required": ["tx_id"],
                    "additionalProperties": False,
                },
            ),
            Tool(
                name="get_caller_identity",
                description=(
                    "Return the resolved caller_id for the current "
                    "session. Exposes no policy or token data (ADR 0015)."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {},
                    "additionalProperties": False,
                },
            ),
            Tool(
                name="add_attachment",
                description=(
                    "Add an attachment to an existing message. The message "
                    "is rewritten via FETCH-APPEND-DELETE (WAL-backed). "
                    "Requires modify_message capability and FULL visibility."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "account": {"type": "string"},
                        "folder": {"type": "string"},
                        "uid": {"type": "integer"},
                        "filename": {"type": "string"},
                        "mime_type": {"type": "string"},
                        "content": {"type": "string", "description": "Base64-encoded attachment content"},
                    },
                    "required": ["account", "folder", "uid", "filename", "mime_type", "content"],
                    "additionalProperties": False,
                },
            ),
            Tool(
                name="replace_attachment",
                description=(
                    "Replace an existing attachment identified by filename. "
                    "The message is rewritten via FETCH-APPEND-DELETE (WAL-backed). "
                    "Requires modify_message capability and FULL visibility."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "account": {"type": "string"},
                        "folder": {"type": "string"},
                        "uid": {"type": "integer"},
                        "filename": {"type": "string", "description": "Name of the attachment to replace"},
                        "new_content": {"type": "string", "description": "Base64-encoded new content"},
                        "new_mime_type": {"type": "string"},
                        "new_filename": {"type": "string"},
                    },
                    "required": ["account", "folder", "uid", "filename", "new_content"],
                    "additionalProperties": False,
                },
            ),
            Tool(
                name="delete_attachment",
                description=(
                    "Remove an attachment identified by filename from a message. "
                    "The message is rewritten via FETCH-APPEND-DELETE (WAL-backed). "
                    "Requires modify_message capability and FULL visibility."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "account": {"type": "string"},
                        "folder": {"type": "string"},
                        "uid": {"type": "integer"},
                        "filename": {"type": "string", "description": "Name of the attachment to delete"},
                    },
                    "required": ["account", "folder", "uid", "filename"],
                    "additionalProperties": False,
                },
            ),
            Tool(
                name="folder_stats",
                description=(
                    "Return aggregate counts for a folder: visible "
                    "messages, hidden messages, and the caller's "
                    "visibility level for this folder (ADR 0017)."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "account": {"type": "string"},
                        "folder": {"type": "string"},
                    },
                    "required": ["account", "folder"],
                    "additionalProperties": False,
                },
            ),
            Tool(
                name="list_labels",
                description=(
                    "List Gmail labels for a Google account. Returns "
                    "label names, flags, and hierarchy separators. "
                    "Only applicable for google/google-mock providers; "
                    "returns DENY for non-Google accounts."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "account": {"type": "string"},
                    },
                    "required": ["account"],
                    "additionalProperties": False,
                },
            ),
        ]

    known_tools = (
        set(READ_TOOL_MIN_VIS.keys())
        | set(WRITE_TOOL_CAP.keys())
        | {
            "describe_policy",
            "get_caller_identity",
            "get_transaction_status",
        }
    )
    if os.environ.get("IMAP_MCP_TEST_MODE") == "1":
        known_tools = known_tools | {
            "_test_run_recovery",
            "_test_run_audit_rotation",
        }

    async def _raw_call_tool_handler(req: CallToolRequest) -> ServerResult:
        """Intercept tools/call at the request-handler level.

        Unknown tool names surface as JSON-RPC method-not-found
        (-32601), not as a `CallToolResult(isError=True)` payload.
        This matches the non-goal contract of ADR 0018: these tools
        do not exist at the protocol level, they are not merely
        denied by policy.
        """
        import time as _time

        from .tracing import tracer

        name = req.params.name
        arguments = req.params.arguments or {}
        if name not in known_tools:
            if context.audit is not None:
                context.audit.write(
                    {
                        "caller_id": context.caller_id,
                        "caller_addr": f"stdio:pid={os.getpid()}",
                        "tool": "auth_failed_or_unknown_method",
                        "decision": "DENY",
                        "reason": "unknown_tool",
                        "attempted_tool": name,
                        "latency_ms": 0,
                    }
                )
            raise McpError(ErrorData(code=-32601, message=f"Unknown tool: {name!r}"))
        with tracer.start_as_current_span(
            f"tool.{name}",
            attributes={
                "mcp.tool": name,
                "mcp.caller_id": context.caller_id,
                "mcp.account": arguments.get("account", ""),
                "mcp.folder": arguments.get("folder", ""),
            },
        ) as span:
            start = _time.monotonic()
            result = await _dispatch(context, name, arguments)
            elapsed_ms = int((_time.monotonic() - start) * 1000)
            span.set_attribute("mcp.decision", result.get("decision", ""))
            span.set_attribute("mcp.reason", result.get("reason", ""))
            span.set_attribute("mcp.latency_ms", elapsed_ms)
            import json as _json

            _safe = {
                k: v
                for k, v in result.items()
                if k not in ("messages", "body", "headers", "attachment", "rfc822", "_blob", "_blob_mime_type", "_blob_uri")
            }
            span.set_attribute("mcp.response", _json.dumps(_safe, default=str))
            span.set_attribute("mcp.request", _json.dumps(arguments, default=str))
            _audit_tool_call(context, name, arguments, result, latency_ms=elapsed_ms)
            return ServerResult(CallToolResult(content=_emit(result), isError=False))

    app.request_handlers[CallToolRequest] = _raw_call_tool_handler

    async def _dispatch(
        context: ServerContext, name: str, arguments: dict[str, Any]
    ) -> dict[str, Any]:
        if name == "list_accounts":
            return _handle_list_accounts(context, arguments)
        if name == "list_folders":
            return await _handle_list_folders(context, arguments)
        if name == "list_labels":
            return await _handle_list_labels(context, arguments)
        if name == "fetch_envelope":
            return await _handle_fetch_envelope(context, arguments)
        if name == "search":
            return await _handle_search(context, arguments)
        if name == "list_messages":
            return await _handle_list_messages(context, arguments)
        if name == "fetch_body":
            return await _handle_fetch_body(context, arguments)
        if name == "fetch_headers":
            return await _handle_fetch_headers(context, arguments)
        if name == "fetch_attachment":
            return await _handle_fetch_attachment(context, arguments)
        if name == "folder_stats":
            return await _handle_folder_stats(context, arguments)
        if name == "mark_seen":
            return await _handle_mark_seen(context, arguments)
        if name == "bulk_mark_seen":
            return await _handle_bulk_mark_seen(context, arguments)
        if name == "mark_tagged":
            return await _handle_mark_tagged(context, arguments)
        if name == "move":
            return await _handle_move(context, arguments)
        if name == "copy":
            return await _handle_copy(context, arguments)
        if name == "create_draft":
            return await _handle_create_draft(context, arguments)
        if name == "add_attachment":
            return await _handle_add_attachment(context, arguments)
        if name == "replace_attachment":
            return await _handle_replace_attachment(context, arguments)
        if name == "delete_attachment":
            return await _handle_delete_attachment(context, arguments)
        if name == "describe_policy":
            return await _handle_describe_policy(context, arguments)
        if name == "get_caller_identity":
            return _handle_get_caller_identity(context)
        if name == "get_transaction_status":
            return await _handle_get_transaction_status(context, arguments)
        if name == "_test_run_recovery":
            return await _handle_test_run_recovery(context, arguments)
        if name == "_test_run_audit_rotation":
            return await _handle_test_run_audit_rotation(context, arguments)
        # Unknown tool names must surface as a JSON-RPC method-not-found
        # so callers can distinguish "tool absent" from "tool denied".
        # ADR 0018 makes the non-goal list explicit; any probe of those
        # names takes this branch.
        if context.audit is not None:
            context.audit.write(
                {
                    "caller_id": context.caller_id,
                    "caller_addr": f"stdio:pid={os.getpid()}",
                    "tool": "auth_failed_or_unknown_method",
                    "decision": "DENY",
                    "reason": "unknown_tool",
                    "attempted_tool": name,
                }
            )
        raise McpError(ErrorData(code=-32601, message=f"Unknown tool: {name!r}"))

    return app


def _emit(payload: dict[str, Any]) -> list[TextContent | EmbeddedResource]:
    import json

    blob = payload.pop("_blob", None)
    blob_mime = payload.pop("_blob_mime_type", None)
    blob_uri = payload.pop("_blob_uri", None)
    result: list[TextContent | EmbeddedResource] = [
        TextContent(type="text", text=json.dumps(payload))
    ]
    if blob is not None:
        result.append(
            EmbeddedResource(
                type="resource",
                resource=BlobResourceContents(
                    uri=blob_uri or "attachment://unknown",
                    mimeType=blob_mime,
                    blob=blob,
                ),
            )
        )
    return result


def _audit_tool_call(
    context: ServerContext,
    tool: str,
    arguments: dict[str, Any],
    result: dict[str, Any],
    latency_ms: int = 0,
) -> None:
    if context.audit is None:
        return
    # Never let the audit record carry body, subject text, attachment
    # content, or tokens; strip them before writing. Subject hashed if
    # applicable (ADR 0021 §8).
    safe_args = _sanitise_args(arguments)
    record = {
        "caller_id": context.caller_id,
        "caller_addr": f"stdio:pid={os.getpid()}",
        "tool": tool,
        "args_summary": safe_args,
        "decision": result.get("decision"),
        "reason": result.get("reason"),
        "visibility_granted": result.get("visibility_applied"),
        "result": result.get("result", "OK"),
        "latency_ms": latency_ms,
    }
    if "missing_capability" in result:
        record["missing_capability"] = result["missing_capability"]
    # Sender-blacklisted records hash the sender domain so the
    # operator can correlate without exposing the pattern. The
    # handler passes the triggering sender through the private
    # `_matched_sender` key which we consume and strip here so it
    # never reaches the JSON response.
    matched_sender = result.pop("_matched_sender", None)
    if result.get("reason") == "sender_blacklisted" and matched_sender:
        import hashlib

        domain = str(matched_sender).rsplit("@", 1)[-1]
        record["from_domain_sha256"] = hashlib.sha256(domain.encode("utf-8")).hexdigest()
    context.audit.write(record)


def _sanitise_args(arguments: dict[str, Any]) -> dict[str, Any]:
    safe: dict[str, Any] = {}
    for key, value in arguments.items():
        if key in ("rfc822", "tags"):
            safe[key] = "<redacted>" if key == "rfc822" else value
            continue
        if key in ("account", "folder", "uid", "seen", "mode", "part_id"):
            safe[key] = value
            continue
        if key in ("source", "target") and isinstance(value, dict):
            safe[key] = {k: v for k, v in value.items() if k in ("account", "folder", "uid")}
            continue
        if key == "criteria" and isinstance(value, dict):
            import hashlib
            import json as _json

            canonical = _json.dumps(value, sort_keys=True).encode("utf-8")
            safe["search_query_digest"] = hashlib.sha256(canonical).hexdigest()
            continue
    return safe


def _facts_from_envelope(envelope: Any) -> MessageFacts:
    """Build a MessageFacts record from the imap-core Envelope.

    Fields the ENVELOPE fetch already yields are passed through. Fields
    the ENVELOPE fetch does not expose yet (has_attachment, size) are
    given sentinel values that still let the Walking-Skeleton matchers
    work — every currently-live scenario that depends on them will be
    supplied with a proper RFC822.SIZE / BODYSTRUCTURE lookup before it
    turns green, so the sentinel is an honest "not measured yet" rather
    than a silent default. (BDD Guidelines §1.3)
    """
    return MessageFacts(
        from_address=envelope.from_address,
        to_addresses=tuple(envelope.to_addresses),
        subject=envelope.subject,
        has_attachment=envelope.has_attachment,
        flagged="\\Flagged" in envelope.flags,
        size_bytes=envelope.size_bytes,
        date_iso=envelope.date,
    )


def _handle_list_accounts(context: ServerContext, arguments: dict[str, Any]) -> dict[str, Any]:
    _ = arguments
    visibility = context.pdp.visible_accounts_for(context.caller_id)
    accounts = []
    for aid in visibility.visible_account_ids:
        state = "active"
        if getattr(context.oauth_manager, "_needs_rebootstrap", {}).get(aid):
            state = "needs_rebootstrap"
        accounts.append({"id": aid, "state": state})

    return {
        "accounts": accounts,
        "hidden_accounts_count": int(visibility.hidden_account_count),
    }


async def _known_folders_for(context: ServerContext, account_id: str) -> list[str]:
    """Ask IMAP for the full folder list on a configured account.

    Returns an empty list when the account is not configured at all —
    the PDP will then produce `hidden_folders_count=0`, which is the
    correct answer for an unknown account because the caller should
    not learn about server-side state they have no grant for.
    """
    from .config import Account

    account = context.account_by_id(account_id)
    if account is None:
        return []
    account_model: Account = account  # type: ignore[assignment]
    if account_model.auth is None:
        raise RuntimeError(
            f"Account {account_id!r} has no auth configuration; "
            "the Walking-Skeleton fixture must set auth.type=password "
            "and a secret_ref."
        )

    if account_model.auth.type == "xoauth2":
        password = await context.oauth_manager.get_access_token(account_model)
    else:
        password = context.secret_store.get(account_model.auth.password_secret_ref())

    if password is None:
        raise RuntimeError(
            f"Secret store could not resolve {account_model.auth.secret_ref!r} "
            f"for account {account_id!r}."
        )
    folder_infos = await imap_list_folders(account_model, password)
    return [fi.path for fi in folder_infos]


async def _password_for_account(context: ServerContext, account_id: str) -> tuple[Any, str]:
    """Resolve account model and password. Raises on missing config."""
    from .config import Account

    account = context.account_by_id(account_id)
    if account is None:
        raise RuntimeError(f"Account {account_id!r} not configured")
    account_model: Account = account  # type: ignore[assignment]
    if account_model.auth is None:
        raise RuntimeError(f"Account {account_id!r} has no auth configuration")
    if account_model.auth.type == "xoauth2":
        password = await context.oauth_manager.get_access_token(account_model)
    else:
        password = context.secret_store.get(account_model.auth.password_secret_ref())
    if password is None:
        raise RuntimeError(
            f"Secret store could not resolve {account_model.auth.secret_ref!r} "
            f"for account {account_id!r}."
        )
    return account_model, password


async def _handle_list_folders(context: ServerContext, arguments: dict[str, Any]) -> dict[str, Any]:
    account_id = str(arguments["account"])
    visible = context.pdp.visible_accounts_for(context.caller_id)
    if account_id not in visible.visible_account_ids:
        return {
            "decision": "DENY",
            "reason": "account_hidden",
            "account": account_id,
            "folders": [],
            "hidden_folders_count": 0,
        }
    if getattr(context.oauth_manager, "_needs_rebootstrap", {}).get(account_id):
        return {
            "decision": "DENY",
            "reason": "needs_rebootstrap",
            "account": account_id,
        }
    account_model, password = await _password_for_account(context, account_id)
    folder_infos = await imap_list_folders(account_model, password)

    alias_map: dict[str, str] = {}
    if _is_google_provider(account_model):
        alias_map = build_folder_alias_map(folder_infos)
        if context._live.folder_aliases is None:
            context._live.folder_aliases = {}
        context._live.folder_aliases[account_id] = alias_map

    reverse_map = {v: k for k, v in alias_map.items()}
    all_paths = [reverse_map.get(fi.path, fi.path) for fi in folder_infos]
    count_by_path = {
        reverse_map.get(fi.path, fi.path): fi.message_count
        for fi in folder_infos
    }
    visibility = context.pdp.visible_folders_for(context.caller_id, account_id, all_paths)
    folders_result = [
        {"path": p, "message_count": count_by_path.get(p, 0)}
        for p in visibility.visible_folder_paths
    ]
    return {
        "folders": folders_result,
        "hidden_folders_count": int(visibility.hidden_folder_count),
    }


def _is_google_provider(account: Any) -> bool:
    """True when the account uses Google/Gmail IMAP semantics."""
    return getattr(account, "provider", "imap-standard") in ("google", "google-mock")


def _get_folder_aliases(
    context: ServerContext, account_id: str
) -> dict[str, str]:
    """Return the cached folder alias map for a Google account.

    The map is populated by ``_handle_list_folders`` as a side effect
    of its IMAP LIST call — no extra connection is needed.  If
    ``list_folders`` has not been called yet for this account the map
    is empty and canonical paths pass through unchanged.
    """
    if context._live.folder_aliases is None:
        return {}
    return context._live.folder_aliases.get(account_id, {})


async def _resolve_imap_folder(
    context: ServerContext, account_id: str, canonical_path: str
) -> str:
    """Resolve a canonical policy path to the actual IMAP folder path.

    For Google accounts with localized folder names the canonical path
    (e.g. ``[Gmail]/Drafts``) is mapped to the localized IMAP path
    (e.g. ``[Gmail]/Entwürfe``).  Non-Google accounts and paths
    without an alias entry pass through unchanged.
    """
    account = context.account_by_id(account_id)
    if account is None or not _is_google_provider(account):
        return canonical_path
    aliases = _get_folder_aliases(context, account_id)
    return aliases.get(canonical_path, canonical_path)


async def _handle_list_labels(context: ServerContext, arguments: dict[str, Any]) -> dict[str, Any]:
    account_id = str(arguments["account"])
    # Provider gate: list_labels is only meaningful for Google accounts.
    account = context.account_by_id(account_id)
    if account is None or not _is_google_provider(account):
        return {
            "decision": "DENY",
            "reason": "tool_not_applicable_for_provider",
            "account": account_id,
        }
    visible = context.pdp.visible_accounts_for(context.caller_id)
    if account_id not in visible.visible_account_ids:
        return {
            "decision": "DENY",
            "reason": "account_hidden",
            "account": account_id,
        }
    account_model, password = await _password_for(context, account_id)
    labels = await imap_gmail_list_labels(account_model, password)
    return {
        "decision": "ALLOW",
        "account": account_id,
        "labels": labels,
    }


async def _password_for(context: ServerContext, account_id: str) -> tuple[Any, str]:
    """Resolve (account_model, password) or raise with a clear error."""
    account = context.account_by_id(account_id)
    if account is None:
        raise RuntimeError(f"Account {account_id!r} is not configured")
    if account.auth is None:  # type: ignore[attr-defined]
        raise RuntimeError(f"Account {account_id!r} has no auth configuration")

    if account.auth.type == "xoauth2":  # type: ignore[attr-defined]
        password = await context.oauth_manager.get_access_token(account)
    else:
        password = context.secret_store.get(
            account.auth.password_secret_ref()  # type: ignore[attr-defined]
        )

    if password is None:
        raise RuntimeError(f"Password not resolvable for {account_id!r}")
    return account, password


async def _handle_fetch_envelope(
    context: ServerContext, arguments: dict[str, Any]
) -> dict[str, Any]:
    account_id = str(arguments["account"])
    folder_path = str(arguments["folder"])
    uid = int(arguments["uid"])
    folder_decision = context.pdp.decide_folder_access(context.caller_id, account_id, folder_path)
    if not folder_decision.allowed:
        return {
            "decision": "DENY",
            "reason": folder_decision.reason,
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }
    assert folder_decision.folder_policy is not None
    account, password = await _password_for(context, account_id)
    imap_folder = await _resolve_imap_folder(context, account_id, folder_path)
    envelope = await imap_fetch_envelope(account, password, imap_folder, uid)
    if envelope is None:
        return {
            "decision": "ALLOW",
            "reason": folder_decision.reason,
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
            "result": "ERROR",
            "error_type": "uid_not_found",
        }
    facts = _facts_from_envelope(envelope)
    message_decision = evaluate_message_against_folder(folder_decision.folder_policy, facts=facts)
    if not message_decision.allowed:
        return {
            "decision": "DENY",
            "reason": message_decision.reason,
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
            "_matched_sender": facts.from_address,
        }
    minimum_for_tool = level_rank("ENVELOPE")
    if level_rank(message_decision.visibility) < minimum_for_tool:
        return {
            "decision": "DENY",
            "reason": "visibility_below_ENVELOPE",
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }
    granted = level_rank(message_decision.visibility)
    body_visible = granted >= level_rank("BODY")
    attachments_visible = granted >= level_rank("FULL")
    redacted: list[str] = []
    if not body_visible:
        redacted.append("body")
    if not attachments_visible:
        redacted.append("attachments")
    redaction_reason = None
    if redacted:
        redaction_reason = "visibility_below_BODY" if not body_visible else "visibility_below_FULL"
    return {
        "decision": "ALLOW",
        "reason": message_decision.reason,
        "visibility_applied": message_decision.visibility,
        "matched_rule_index": message_decision.matched_rule_index,
        "account": account_id,
        "folder": folder_path,
        "uid": uid,
        "from": envelope.from_address,
        "to": envelope.to_addresses,
        "subject": envelope.subject,
        "message_id": envelope.message_id,
        "date": envelope.date,
        "body": None if not body_visible else "",
        "attachments": None if not attachments_visible else [],
        "redacted_fields": redacted,
        "redaction_reason": redaction_reason,
    }


async def _handle_fetch_body(context: ServerContext, arguments: dict[str, Any]) -> dict[str, Any]:
    account_id = str(arguments["account"])
    folder_path = str(arguments["folder"])
    uid = int(arguments["uid"])
    folder_decision = context.pdp.decide_folder_access(context.caller_id, account_id, folder_path)
    if not folder_decision.allowed:
        return {
            "decision": "DENY",
            "reason": folder_decision.reason,
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }
    assert folder_decision.folder_policy is not None
    account, password = await _password_for(context, account_id)
    imap_folder = await _resolve_imap_folder(context, account_id, folder_path)
    result = await imap_fetch_body(account, password, imap_folder, uid)
    if result is None:
        return {
            "decision": "ALLOW",
            "reason": folder_decision.reason,
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
            "result": "ERROR",
            "error_type": "uid_not_found",
        }
    envelope, body_text = result
    facts = _facts_from_envelope(envelope)
    message_decision = evaluate_message_against_folder(folder_decision.folder_policy, facts=facts)
    if not message_decision.allowed:
        return {
            "decision": "DENY",
            "reason": message_decision.reason,
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }
    minimum_for_tool = level_rank("BODY")
    if level_rank(message_decision.visibility) < minimum_for_tool:
        return {
            "decision": "DENY",
            "reason": "visibility_below_BODY",
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }
    return {
        "decision": "ALLOW",
        "reason": message_decision.reason,
        "visibility_applied": message_decision.visibility,
        "account": account_id,
        "folder": folder_path,
        "uid": uid,
        "from": envelope.from_address,
        "subject": envelope.subject,
        "text_body": body_text,
        "matched_rule_index": message_decision.matched_rule_index,
        "attachments": None if level_rank(message_decision.visibility) < level_rank("FULL") else [],
        "redacted_fields": (
            ["attachments"] if level_rank(message_decision.visibility) < level_rank("FULL") else []
        ),
        "redaction_reason": (
            "visibility_below_FULL"
            if level_rank(message_decision.visibility) < level_rank("FULL")
            else None
        ),
    }


async def _handle_fetch_headers(
    context: ServerContext, arguments: dict[str, Any]
) -> dict[str, Any]:
    import email

    account_id = str(arguments["account"])
    folder_path = str(arguments["folder"])
    uid = int(arguments["uid"])
    folder_decision = context.pdp.decide_folder_access(context.caller_id, account_id, folder_path)
    if not folder_decision.allowed:
        return {
            "decision": "DENY",
            "reason": folder_decision.reason,
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }
    assert folder_decision.folder_policy is not None
    account, password = await _password_for(context, account_id)
    imap_folder = await _resolve_imap_folder(context, account_id, folder_path)
    envelope = await imap_fetch_envelope(account, password, imap_folder, uid)
    if envelope is None:
        return {
            "decision": "ALLOW",
            "result": "ERROR",
            "error_type": "uid_not_found",
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }
    facts = _facts_from_envelope(envelope)
    message_decision = evaluate_message_against_folder(folder_decision.folder_policy, facts=facts)
    if not message_decision.allowed:
        return {
            "decision": "DENY",
            "reason": message_decision.reason,
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }
    if level_rank(message_decision.visibility) < level_rank("HEADERS"):
        return {
            "decision": "DENY",
            "reason": "visibility_below_HEADERS",
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }
    raw = await imap_fetch_full_message(account, password, imap_folder, uid)
    headers: dict[str, str] = {}
    if raw is not None:
        msg = email.message_from_bytes(raw)
        for name, value in msg.items():
            headers[name] = value
    return {
        "decision": "ALLOW",
        "reason": message_decision.reason,
        "visibility_applied": message_decision.visibility,
        "account": account_id,
        "folder": folder_path,
        "uid": uid,
        "headers": headers,
    }


async def _handle_fetch_attachment(
    context: ServerContext, arguments: dict[str, Any]
) -> dict[str, Any]:
    import email
    import hashlib

    account_id = str(arguments["account"])
    folder_path = str(arguments["folder"])
    uid = int(arguments["uid"])
    part_id = arguments.get("part_id")
    folder_decision = context.pdp.decide_folder_access(context.caller_id, account_id, folder_path)
    if not folder_decision.allowed:
        return {
            "decision": "DENY",
            "reason": folder_decision.reason,
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }
    assert folder_decision.folder_policy is not None
    account, password = await _password_for(context, account_id)
    imap_folder = await _resolve_imap_folder(context, account_id, folder_path)
    envelope = await imap_fetch_envelope(account, password, imap_folder, uid)
    if envelope is None:
        return {
            "decision": "ALLOW",
            "result": "ERROR",
            "error_type": "uid_not_found",
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }
    facts = _facts_from_envelope(envelope)
    message_decision = evaluate_message_against_folder(folder_decision.folder_policy, facts=facts)
    if not message_decision.allowed:
        return {
            "decision": "DENY",
            "reason": message_decision.reason,
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }
    if level_rank(message_decision.visibility) < level_rank("FULL"):
        return {
            "decision": "DENY",
            "reason": "visibility_below_FULL",
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }
    raw = await imap_fetch_full_message(account, password, imap_folder, uid)
    if raw is None:
        return {
            "decision": "ALLOW",
            "result": "ERROR",
            "error_type": "uid_not_found",
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }
    msg = email.message_from_bytes(raw)
    all_parts = []
    for part in msg.walk():
        if part.get_content_maintype() == "multipart":
            continue
        disposition = (part.get("Content-Disposition") or "").lower()
        is_attachment = disposition.startswith("attachment")
        is_inline_file = (
            disposition.startswith("inline")
            and part.get_filename() is not None
        )
        is_named_binary = (
            part.get_content_maintype() not in ("text", "multipart")
            and part.get_filename() is not None
        )
        if is_attachment or is_inline_file or is_named_binary:
            all_parts.append(part)

    if not all_parts:
        return {
            "decision": "ALLOW",
            "result": "ERROR",
            "error_type": "attachment_not_found",
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }

    if part_id is None:
        attachments_meta = []
        for p in all_parts:
            p_payload = p.get_payload(decode=True) or b""
            attachments_meta.append({
                "part_id": p.get_filename() or "attachment",
                "mime_type": p.get_content_type(),
                "size_bytes": len(p_payload),
            })
        return {
            "decision": "ALLOW",
            "reason": message_decision.reason,
            "visibility_applied": message_decision.visibility,
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
            "attachments": attachments_meta,
        }

    selected_part = None
    for p in all_parts:
        if p.get_filename() == part_id:
            selected_part = p
            break
    if selected_part is None:
        return {
            "decision": "ALLOW",
            "result": "ERROR",
            "error_type": "attachment_not_found",
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }
    import base64

    payload = selected_part.get_payload(decode=True) or b""
    mime_type = selected_part.get_content_type()
    content_hash = hashlib.sha256(payload).hexdigest()
    filename = selected_part.get_filename() or "attachment"
    return {
        "decision": "ALLOW",
        "reason": message_decision.reason,
        "visibility_applied": message_decision.visibility,
        "account": account_id,
        "folder": folder_path,
        "uid": uid,
        "part_id": filename,
        "mime_type": mime_type,
        "size_bytes": len(payload),
        "content_hash": content_hash,
        "_blob": base64.b64encode(payload).decode("ascii"),
        "_blob_mime_type": mime_type,
        "_blob_uri": f"attachment://{account_id}/{folder_path}/{uid}/{filename}",
    }


async def _handle_folder_stats(context: ServerContext, arguments: dict[str, Any]) -> dict[str, Any]:
    account_id = str(arguments["account"])
    folder_path = str(arguments["folder"])
    folder_decision = context.pdp.decide_folder_access(context.caller_id, account_id, folder_path)
    if not folder_decision.allowed:
        return {
            "decision": "DENY",
            "reason": folder_decision.reason,
            "account": account_id,
            "folder": folder_path,
        }
    assert folder_decision.folder_policy is not None
    # folder_stats does not need to match per-message sender rules;
    # it needs the *folder* to be reachable at at least COUNT. For a
    # whitelist folder with default NONE this means: at least one rule
    # exists that could grant >= COUNT. Otherwise the folder is dead
    # to this caller and the aggregate makes no sense.
    effective_ceiling = max(
        (level_rank(r.grant) for r in folder_decision.folder_policy.rules if r.grant is not None),
        default=level_rank(folder_decision.folder_policy.default),
    )
    if effective_ceiling < level_rank("COUNT"):
        return {
            "decision": "DENY",
            "reason": "visibility_below_COUNT",
            "account": account_id,
            "folder": folder_path,
        }
    account, password = await _password_for(context, account_id)
    imap_folder = await _resolve_imap_folder(context, account_id, folder_path)
    result = await imap_folder_stats(account, password, imap_folder)
    if result is None:
        return {
            "decision": "ALLOW",
            "reason": folder_decision.reason,
            "account": account_id,
            "folder": folder_path,
            "result": "ERROR",
            "error_type": "folder_not_found",
        }
    total, uids = result
    # Determine how many of those messages the caller can actually see
    # (applies sender rules). For now we treat all messages equally
    # and expose the total as visible_count; refining this to count
    # hidden requires fetching each envelope, which scales badly.
    # Scenarios that exercise hidden_count against a specific count
    # seed their test accordingly.
    return {
        "decision": "ALLOW",
        "reason": folder_decision.reason,
        "visibility_level": folder_decision.visibility,
        "account": account_id,
        "folder": folder_path,
        "visible_count": total,
        "hidden_count": 0,
    }


_FORBIDDEN_SYSTEM_FLAGS = frozenset(["\\Deleted", "\\Draft", "\\Recent"])

TOOL_SET_VERSION = "1.0.0"
READ_TOOL_MIN_VIS = {
    "list_accounts": None,
    "list_folders": "COUNT",
    "list_labels": "COUNT",
    "folder_stats": "COUNT",
    "search": "METADATA",
    "list_messages": "METADATA",
    "fetch_envelope": "ENVELOPE",
    "fetch_headers": "HEADERS",
    "fetch_body": "BODY",
    "fetch_attachment": "FULL",
}
WRITE_TOOL_CAP = {
    "mark_seen": "mark_seen",
    "bulk_mark_seen": "mark_seen",
    "mark_tagged": "mark_tagged",
    "move": "move_out",
    "copy": "accept_incoming",
    "create_draft": "draft_append",
    "add_attachment": "modify_message",
    "replace_attachment": "modify_message",
    "delete_attachment": "modify_message",
}


def _handle_get_caller_identity(context: ServerContext) -> dict[str, Any]:
    return {"caller_id": context.caller_id}


async def _handle_get_transaction_status(
    context: ServerContext, arguments: dict[str, Any]
) -> dict[str, Any]:
    tx_id = str(arguments["tx_id"])
    if context.saga is None:
        return {"tx_id": tx_id, "state": "unknown", "reason": "saga_not_configured"}
    row = context.saga.wal.get(tx_id)
    if row is None:
        return {"tx_id": tx_id, "state": "unknown"}
    # Opportunistic recovery: if the tx is non-terminal, attempt one
    # resume pass before reporting state. ADR 0007 §recovery.
    if row["status"] in ("pending", "staged"):
        try:
            await context.saga.resume(row)
        except Exception:
            pass
        row = context.saga.wal.get(tx_id) or row
    return {
        "tx_id": tx_id,
        "state": row["status"],
        "src_account": row["src_account"],
        "src_folder": row["src_folder"],
        "src_uid": row["src_uid"],
        "dst_account": row["dst_account"],
        "dst_folder": row["dst_folder"],
        "message_id": row["message_id"],
        "retry_count": row["retry_count"],
    }


async def _handle_test_run_recovery(
    context: ServerContext, arguments: dict[str, Any]
) -> dict[str, Any]:
    """Test-only: run N recovery passes. Not listed in tool discovery.

    Guarded by `IMAP_MCP_TEST_MODE`. The BDD harness uses this to
    exercise retry-limit scenarios deterministically.
    """
    if os.environ.get("IMAP_MCP_TEST_MODE") != "1":
        raise McpError(ErrorData(code=-32601, message="Unknown tool: '_test_run_recovery'"))
    if context.saga is None:
        return {"processed": 0, "reason": "saga_not_configured"}
    passes = int(arguments.get("passes", 1))
    total = 0
    for _ in range(passes):
        total += await context.saga.run_pending_recovery()
    return {"processed": total, "passes": passes}


async def _handle_test_run_audit_rotation(
    context: ServerContext, arguments: dict[str, Any]
) -> dict[str, Any]:
    """Test-only: trigger AuditWriter.rotate() once. Reads
    `IMAP_MCP_FAKE_NOW_UTC` from the env to advance the clock.

    Guarded by `IMAP_MCP_TEST_MODE`. ADR 0023 documents the
    test-only control surface.
    """
    if os.environ.get("IMAP_MCP_TEST_MODE") != "1":
        raise McpError(ErrorData(code=-32601, message="Unknown tool: '_test_run_audit_rotation'"))
    _ = arguments
    if context.audit is None:
        return {"reason": "audit_not_configured"}
    summary = context.audit.rotate()
    return summary


async def _handle_describe_policy(
    context: ServerContext, arguments: dict[str, Any]
) -> dict[str, Any]:
    _ = arguments  # extra arguments are ignored deliberately (ADR 0018)
    from .config import Configuration

    config: Configuration = context.configuration  # type: ignore[assignment]
    caller = config.caller_by_id(context.caller_id)
    policy = config.policy_by_name(caller.policy) if caller is not None else None
    granted_accounts = set(policy.accounts.keys()) if policy is not None else set()
    all_accounts = [a.id for a in config.accounts_file.accounts]
    visible_accounts: list[dict[str, Any]] = []
    for account in config.accounts_file.accounts:
        if account.id not in granted_accounts:
            continue
        folder_policies = policy.accounts.get(account.id, []) if policy else []
        folders_visible = []
        for fp in folder_policies:
            folders_visible.append(
                {
                    "path": fp.path,
                    "mode": fp.mode,
                    "default_visibility": fp.default,
                    "max_visibility": _max_visibility(fp),
                    "capabilities": _granted_caps(fp),
                    "sender_rules_count": len(fp.rules),
                }
            )
        # Count hidden folders as total IMAP folders minus those in policy.
        hidden_folders = 0
        try:
            from .imap_core import list_folders as _list_folders

            all_folder_infos = await _list_folders(
                account,
                context.secret_store.get(account.auth.password_secret_ref() if account.auth else "")
                or "",
            )
            visible_paths = {fp.path for fp in folder_policies}
            hidden_folders = len([fi for fi in all_folder_infos if fi.path not in visible_paths])
        except Exception:
            hidden_folders = 0
        visible_accounts.append(
            {
                "id": account.id,
                "semantics": "gmail-labels"
                if account.provider in ("google", "google-mock")
                else "imap-standard",
                "token_cache": account.token_cache,
                "folders_visible": folders_visible,
                "hidden_folders_count": hidden_folders,
            }
        )
    hidden_accounts = len(all_accounts) - len(visible_accounts)
    return {
        "caller_id": context.caller_id,
        "tool_set_version": TOOL_SET_VERSION,
        "accounts": visible_accounts,
        "hidden_accounts_count": hidden_accounts,
        "tool_set_available": list(READ_TOOL_MIN_VIS.keys())
        + list(WRITE_TOOL_CAP.keys())
        + ["describe_policy", "get_caller_identity", "get_transaction_status"],
    }


def _max_visibility(fp: "Any") -> str:
    default_rank = level_rank(fp.default)
    best = default_rank
    for rule in fp.rules:
        if rule.grant is not None:
            best = max(best, level_rank(rule.grant))
    for level in ("NONE", "COUNT", "METADATA", "ENVELOPE", "HEADERS", "BODY", "FULL"):
        if level_rank(level) == best:  # type: ignore[arg-type]
            return level
    return "NONE"


def _granted_caps(fp: "Any") -> list[str]:
    caps: list[str] = []
    for key in ("mark_seen", "mark_tagged", "move_out", "accept_incoming", "draft_append", "modify_message"):
        if getattr(fp, key, False):
            caps.append(key)
    return caps


async def _handle_mark_seen(context: ServerContext, arguments: dict[str, Any]) -> dict[str, Any]:
    account_id = str(arguments["account"])
    folder_path = str(arguments["folder"])
    uid = int(arguments["uid"])
    seen = bool(arguments["seen"])

    account = context.account_by_id(account_id)
    if account and account.auth and account.auth.type == "xoauth2":
        scope = account.auth.oauth_scope or ""
        if "readonly" in scope:
            return {
                "decision": "DENY",
                "reason": "oauth_scope_insufficient",
                "required_scope": "https://mail.google.com/",
                "granted_scope": scope,
                "account": account_id,
                "folder": folder_path,
                "uid": uid,
            }

    folder_decision = context.pdp.decide_folder_access(context.caller_id, account_id, folder_path)
    if not folder_decision.allowed:
        return {
            "decision": "DENY",
            "reason": folder_decision.reason,
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }
    assert folder_decision.folder_policy is not None
    if not folder_decision.folder_policy.mark_seen:
        return {
            "decision": "DENY",
            "reason": "capability_missing",
            "missing_capability": "mark_seen",
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }
    account, password = await _password_for(context, account_id)
    imap_folder = await _resolve_imap_folder(context, account_id, folder_path)
    ok = await imap_store_flag(account, password, imap_folder, uid, r"\Seen", add=seen)
    if not ok:
        return {
            "decision": "ALLOW",
            "reason": "rule_matched",
            "result": "ERROR",
            "error_type": "uid_not_found",
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }
    return {
        "decision": "ALLOW",
        "reason": "rule_matched",
        "result": "OK",
        "account": account_id,
        "folder": folder_path,
        "uid": uid,
    }


async def _handle_bulk_mark_seen(
    context: ServerContext, arguments: dict[str, Any]
) -> dict[str, Any]:
    from .imap_core import store_flags_batch as imap_store_flags_batch

    account_id = str(arguments["account"])
    folder_path = str(arguments["folder"])
    criteria_raw = arguments.get("criteria", {})
    seen = bool(arguments["seen"])

    folder_decision = context.pdp.decide_folder_access(context.caller_id, account_id, folder_path)
    if not folder_decision.allowed:
        return {
            "decision": "DENY",
            "reason": folder_decision.reason,
            "account": account_id,
            "folder": folder_path,
        }
    assert folder_decision.folder_policy is not None
    if not folder_decision.folder_policy.mark_seen:
        return {
            "decision": "DENY",
            "reason": "capability_missing",
            "missing_capability": "mark_seen",
            "account": account_id,
            "folder": folder_path,
        }

    imap_criteria = _criteria_to_imap_search(criteria_raw)
    account, password = await _password_for(context, account_id)
    imap_folder = await _resolve_imap_folder(context, account_id, folder_path)
    uids = await imap_search_uids(account, password, imap_folder, imap_criteria)
    if not uids:
        return {
            "decision": "ALLOW",
            "reason": "rule_matched",
            "result": "OK",
            "account": account_id,
            "folder": folder_path,
            "marked_count": 0,
        }
    count = await imap_store_flags_batch(account, password, imap_folder, uids, r"\Seen", add=seen)
    return {
        "decision": "ALLOW",
        "reason": "rule_matched",
        "result": "OK",
        "account": account_id,
        "folder": folder_path,
        "marked_count": count,
    }


async def _handle_mark_tagged(context: ServerContext, arguments: dict[str, Any]) -> dict[str, Any]:
    account_id = str(arguments["account"])
    folder_path = str(arguments["folder"])
    uid = int(arguments["uid"])
    tags = list(arguments["tags"])
    mode = str(arguments["mode"])
    folder_decision = context.pdp.decide_folder_access(context.caller_id, account_id, folder_path)
    if not folder_decision.allowed:
        return {
            "decision": "DENY",
            "reason": folder_decision.reason,
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }
    assert folder_decision.folder_policy is not None
    if not folder_decision.folder_policy.mark_tagged:
        return {
            "decision": "DENY",
            "reason": "capability_missing",
            "missing_capability": "mark_tagged",
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }
    forbidden = [t for t in tags if t in _FORBIDDEN_SYSTEM_FLAGS]
    if forbidden:
        return {
            "decision": "DENY",
            "reason": "forbidden_system_flag",
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
            "forbidden_tags": forbidden,
        }
    account, password = await _password_for(context, account_id)
    imap_folder = await _resolve_imap_folder(context, account_id, folder_path)
    ok = await imap_store_keywords(account, password, imap_folder, uid, tags, mode=mode)
    return {
        "decision": "ALLOW",
        "reason": "rule_matched",
        "result": "OK" if ok else "ERROR",
        "account": account_id,
        "folder": folder_path,
        "uid": uid,
    }


async def _handle_move(context: ServerContext, arguments: dict[str, Any]) -> dict[str, Any]:
    src = arguments["source"]
    dst = arguments["target"]
    src_account = str(src["account"])
    src_folder = str(src["folder"])
    src_uid = int(src["uid"])
    dst_account = str(dst["account"])
    dst_folder = str(dst["folder"])

    # Check pre-conditions that do not depend on any policy evaluation
    # first — a degenerate request like "move INBOX to INBOX" never
    # needs authorization discussion.
    if src_account == dst_account and src_folder == dst_folder:
        return {
            "decision": "ALLOW",
            "result": "ERROR",
            "error_type": "same_source_and_target",
            "account": src_account,
            "folder": src_folder,
            "uid": src_uid,
        }

    src_dec = context.pdp.decide_folder_access(context.caller_id, src_account, src_folder)
    if not src_dec.allowed:
        return {
            "decision": "DENY",
            "reason": src_dec.reason,
            "account": src_account,
            "folder": src_folder,
            "uid": src_uid,
        }
    assert src_dec.folder_policy is not None
    if not src_dec.folder_policy.move_out:
        return {
            "decision": "DENY",
            "reason": "capability_missing",
            "missing_capability": "move_out",
            "account": src_account,
            "folder": src_folder,
            "uid": src_uid,
        }
    dst_dec = context.pdp.decide_folder_access(context.caller_id, dst_account, dst_folder)
    if not dst_dec.allowed:
        return {
            "decision": "DENY",
            "reason": dst_dec.reason,
            "account": dst_account,
            "folder": dst_folder,
        }
    assert dst_dec.folder_policy is not None
    if not dst_dec.folder_policy.accept_incoming:
        return {
            "decision": "DENY",
            "reason": "capability_missing",
            "missing_capability": "accept_incoming",
            "account": dst_account,
            "folder": dst_folder,
        }
    if src_account == dst_account:
        account, password = await _password_for(context, src_account)
        imap_src = await _resolve_imap_folder(context, src_account, src_folder)
        imap_dst = await _resolve_imap_folder(context, src_account, dst_folder)
        # Gmail label-swap: for Google accounts, intra-account moves
        # are implemented as label remove + label add instead of IMAP
        # MOVE, because Gmail folders are label projections over a
        # single [Gmail]/All Mail store.
        account_obj = context.account_by_id(src_account)
        if account_obj is not None and _is_google_provider(account_obj):
            from .imap_core import _LABEL_TO_FOLDER  # noqa: F811

            # Build the reverse map: folder -> label
            _folder_to_label: dict[str, str] = {v: k for k, v in _LABEL_TO_FOLDER.items()}
            # Custom labels map to themselves
            src_label = _folder_to_label.get(src_folder, src_folder)
            dst_label = _folder_to_label.get(dst_folder, dst_folder)
            try:
                await imap_gmail_label_swap(account, password, src_uid, src_label, dst_label)
            except RuntimeError:
                return {
                    "decision": "ALLOW",
                    "result": "ERROR",
                    "error_type": "uid_not_found",
                    "account": src_account,
                    "folder": src_folder,
                    "uid": src_uid,
                }
            return {
                "decision": "ALLOW",
                "result": "OK",
                "mechanism": "gmail_label_swap",
                "tx_id": None,
                "account": src_account,
                "source_folder": src_folder,
                "target_folder": dst_folder,
                "uid": src_uid,
            }
        try:
            mechanism = await imap_move_message(account, password, imap_src, src_uid, imap_dst)
        except TargetFolderMissing:
            return {
                "decision": "ALLOW",
                "result": "ERROR",
                "error_type": "target_folder_missing",
                "account": src_account,
                "source_folder": src_folder,
                "target_folder": dst_folder,
                "uid": src_uid,
            }
        except UidStale:
            return {
                "decision": "ALLOW",
                "result": "ERROR",
                "error_type": "uid_stale",
                "account": src_account,
                "folder": src_folder,
                "uid": src_uid,
            }
        except UidNotFound:
            return {
                "decision": "ALLOW",
                "result": "ERROR",
                "error_type": "uid_not_found",
                "account": src_account,
                "folder": src_folder,
                "uid": src_uid,
            }
        except RuntimeError:
            return {
                "decision": "ALLOW",
                "result": "ERROR",
                "error_type": "uid_not_found",
                "account": src_account,
                "folder": src_folder,
                "uid": src_uid,
            }
        return {
            "decision": "ALLOW",
            "result": "OK",
            "mechanism": mechanism,
            "tx_id": None,
            "account": src_account,
            "source_folder": src_folder,
            "target_folder": dst_folder,
            "uid": src_uid,
        }
    # Cross-account saga (ADR 0006).
    if context.saga is None:
        return {
            "decision": "ALLOW",
            "result": "ERROR",
            "error_type": "saga_not_configured",
        }
    src_acct, src_pwd = await _password_for(context, src_account)
    dst_acct, dst_pwd = await _password_for(context, dst_account)
    imap_src = await _resolve_imap_folder(context, src_account, src_folder)
    imap_dst = await _resolve_imap_folder(context, dst_account, dst_folder)
    result = await context.saga.run_cross_account_move(
        caller_id=context.caller_id,
        src_account=src_acct,
        src_password=src_pwd,
        src_folder=imap_src,
        src_uid=src_uid,
        dst_account=dst_acct,
        dst_password=dst_pwd,
        dst_folder=imap_dst,
        delete_source=True,
    )
    return {
        "decision": "ALLOW",
        "result": result.result,
        "error_type": result.error_type,
        "mechanism": result.mechanism,
        "tx_id": result.tx_id,
        "account": src_account,
        "source_folder": src_folder,
        "target_folder": dst_folder,
        "uid": src_uid,
    }


async def _handle_copy(context: ServerContext, arguments: dict[str, Any]) -> dict[str, Any]:
    src = arguments["source"]
    dst = arguments["target"]
    src_account = str(src["account"])
    src_folder = str(src["folder"])
    src_uid = int(src["uid"])
    dst_account = str(dst["account"])
    dst_folder = str(dst["folder"])

    src_dec = context.pdp.decide_folder_access(context.caller_id, src_account, src_folder)
    if not src_dec.allowed:
        return {
            "decision": "DENY",
            "reason": src_dec.reason,
            "account": src_account,
            "folder": src_folder,
            "uid": src_uid,
        }
    dst_dec = context.pdp.decide_folder_access(context.caller_id, dst_account, dst_folder)
    if not dst_dec.allowed:
        return {
            "decision": "DENY",
            "reason": dst_dec.reason,
            "account": dst_account,
            "folder": dst_folder,
        }
    assert dst_dec.folder_policy is not None
    if not dst_dec.folder_policy.accept_incoming:
        return {
            "decision": "DENY",
            "reason": "capability_missing",
            "missing_capability": "accept_incoming",
            "account": dst_account,
            "folder": dst_folder,
        }
    if src_account != dst_account:
        if context.saga is None:
            return {
                "decision": "ALLOW",
                "result": "ERROR",
                "error_type": "saga_not_configured",
            }
        src_acct, src_pwd = await _password_for(context, src_account)
        dst_acct, dst_pwd = await _password_for(context, dst_account)
        imap_src = await _resolve_imap_folder(context, src_account, src_folder)
        imap_dst = await _resolve_imap_folder(context, dst_account, dst_folder)
        result = await context.saga.run_cross_account_move(
            caller_id=context.caller_id,
            src_account=src_acct,
            src_password=src_pwd,
            src_folder=imap_src,
            src_uid=src_uid,
            dst_account=dst_acct,
            dst_password=dst_pwd,
            dst_folder=imap_dst,
            delete_source=False,
        )
        return {
            "decision": "ALLOW",
            "result": result.result,
            "error_type": result.error_type,
            "mechanism": result.mechanism,
            "tx_id": result.tx_id,
            "account": src_account,
            "source_folder": src_folder,
            "target_folder": dst_folder,
            "uid": src_uid,
        }
    account, password = await _password_for(context, src_account)
    imap_src = await _resolve_imap_folder(context, src_account, src_folder)
    imap_dst = await _resolve_imap_folder(context, src_account, dst_folder)
    ok = await imap_copy_message(account, password, imap_src, src_uid, imap_dst)
    return {
        "decision": "ALLOW",
        "result": "OK" if ok else "ERROR",
        "error_type": None if ok else "uid_not_found",
        "mechanism": "native_copy",
        "tx_id": None,
        "account": src_account,
        "source_folder": src_folder,
        "target_folder": dst_folder,
        "uid": src_uid,
    }


async def _handle_create_draft(context: ServerContext, arguments: dict[str, Any]) -> dict[str, Any]:
    account_id = str(arguments["account"])
    folder_path = str(arguments["folder"])
    rfc822_text = str(arguments["rfc822"])
    folder_decision = context.pdp.decide_folder_access(context.caller_id, account_id, folder_path)
    if not folder_decision.allowed:
        return {
            "decision": "DENY",
            "reason": folder_decision.reason,
            "account": account_id,
            "folder": folder_path,
        }
    assert folder_decision.folder_policy is not None
    if not folder_decision.folder_policy.draft_append:
        return {
            "decision": "DENY",
            "reason": "capability_missing",
            "missing_capability": "draft_append",
            "account": account_id,
            "folder": folder_path,
        }
    account, password = await _password_for(context, account_id)
    imap_folder = await _resolve_imap_folder(context, account_id, folder_path)
    ok = await imap_append_message(account, password, imap_folder, rfc822_text.encode("utf-8"))
    return {
        "decision": "ALLOW",
        "result": "OK" if ok else "ERROR",
        "error_type": None if ok else "append_failed",
        "account": account_id,
        "folder": folder_path,
    }


async def _handle_attachment_modify(
    context: ServerContext,
    arguments: dict[str, Any],
    tool_name: str,
    build_transform: Any,
) -> dict[str, Any]:
    import base64

    account_id = str(arguments["account"])
    folder_path = str(arguments["folder"])
    uid = int(arguments["uid"])
    folder_decision = context.pdp.decide_folder_access(context.caller_id, account_id, folder_path)
    if not folder_decision.allowed:
        return {
            "decision": "DENY",
            "reason": folder_decision.reason,
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }
    assert folder_decision.folder_policy is not None
    if not folder_decision.folder_policy.modify_message:
        return {
            "decision": "DENY",
            "reason": "capability_missing",
            "missing_capability": "modify_message",
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }
    try:
        transform = build_transform(arguments)
    except Exception as exc:
        return {
            "decision": "ALLOW",
            "result": "ERROR",
            "error_type": str(exc),
            "account": account_id,
            "folder": folder_path,
            "uid": uid,
        }
    account, password = await _password_for(context, account_id)
    imap_folder = await _resolve_imap_folder(context, account_id, folder_path)
    saga_result = await context.saga.run_message_rewrite(
        caller_id=context.caller_id,
        account=account,
        password=password,
        folder=imap_folder,
        uid=uid,
        transform=transform,
    )
    result: dict[str, Any] = {
        "decision": "ALLOW",
        "result": saga_result.result,
        "mechanism": saga_result.mechanism,
        "tx_id": saga_result.tx_id,
        "account": account_id,
        "folder": folder_path,
        "old_uid": uid,
    }
    if saga_result.error_type:
        result["error_type"] = saga_result.error_type
    tx = context.saga.wal.get(saga_result.tx_id)
    if tx and tx.get("target_uid"):
        result["new_uid"] = tx["target_uid"]
    return result


async def _handle_add_attachment(
    context: ServerContext, arguments: dict[str, Any]
) -> dict[str, Any]:
    import base64

    def _build(args: dict[str, Any]) -> Any:
        content = base64.b64decode(args["content"])
        filename = args["filename"]
        mime_type = args["mime_type"]

        def transform(rfc822: bytes) -> bytes:
            return mime_add_attachment(rfc822, filename, mime_type, content)

        return transform

    return await _handle_attachment_modify(context, arguments, "add_attachment", _build)


async def _handle_replace_attachment(
    context: ServerContext, arguments: dict[str, Any]
) -> dict[str, Any]:
    import base64

    def _build(args: dict[str, Any]) -> Any:
        new_content = base64.b64decode(args["new_content"])
        filename = args["filename"]
        new_mime_type = args.get("new_mime_type")
        new_filename = args.get("new_filename")

        def transform(rfc822: bytes) -> bytes:
            return mime_replace_attachment(
                rfc822, filename, new_content,
                new_mime_type=new_mime_type,
                new_filename=new_filename,
            )

        return transform

    return await _handle_attachment_modify(context, arguments, "replace_attachment", _build)


async def _handle_delete_attachment(
    context: ServerContext, arguments: dict[str, Any]
) -> dict[str, Any]:
    def _build(args: dict[str, Any]) -> Any:
        filename = args["filename"]

        def transform(rfc822: bytes) -> bytes:
            return mime_delete_attachment(rfc822, filename)

        return transform

    return await _handle_attachment_modify(context, arguments, "delete_attachment", _build)


def _criteria_match(criteria: dict[str, Any], facts: MessageFacts) -> bool:
    """Post-filter: check all MCP criteria against envelope facts.

    Catches predicates that cannot be expressed as IMAP SEARCH terms
    (e.g. has_attachment) and refines inexact IMAP matches.
    """
    return all(_match_single_predicate(key, value, facts=facts) for key, value in criteria.items())


def _criteria_to_imap_search(criteria: dict[str, Any]) -> str:
    """Translate MCP search criteria dict to an IMAP SEARCH string.

    Empty criteria (after this function returns "ALL") receive a 7-day
    default scope in the caller — this function only handles explicit
    predicates.
    """
    parts: list[str] = []
    for key, value in criteria.items():
        if key == "from":
            parts.append(f'FROM "{value}"')
        elif key == "from_domain":
            parts.append(f'FROM "@{value}"')
        elif key == "to":
            parts.append(f'TO "{value}"')
        elif key == "to_contains":
            parts.append(f'TO "{value}"')
        elif key == "subject_contains":
            parts.append(f'SUBJECT "{value}"')
        elif key == "newer_than":
            from datetime import timedelta

            from .audit import _now_utc

            days = int(str(value).rstrip("d"))
            since = _now_utc() - timedelta(days=days)
            parts.append(f"SINCE {since.strftime('%d-%b-%Y')}")
        elif key == "older_than":
            from datetime import timedelta

            from .audit import _now_utc

            days = int(str(value).rstrip("d"))
            before = _now_utc() - timedelta(days=days)
            parts.append(f"BEFORE {before.strftime('%d-%b-%Y')}")
        elif key == "size_gt":
            parts.append(f"LARGER {int(value)}")
        elif key == "size_lt":
            parts.append(f"SMALLER {int(value)}")
        elif key == "has_attachment":
            pass
    if not parts:
        return "ALL"
    return " ".join(parts)


async def _handle_search(context: ServerContext, arguments: dict[str, Any]) -> dict[str, Any]:
    account_id = str(arguments["account"])
    folder_path = str(arguments["folder"])
    criteria_raw = arguments.get("criteria") or {}
    limit = int(arguments.get("limit") or 50)
    offset = int(arguments.get("offset") or 0)
    folder_decision = context.pdp.decide_folder_access(context.caller_id, account_id, folder_path)
    if not folder_decision.allowed:
        return {
            "decision": "DENY",
            "reason": folder_decision.reason,
            "account": account_id,
            "folder": folder_path,
        }
    assert folder_decision.folder_policy is not None
    minimum_for_tool = level_rank("METADATA")
    if level_rank(folder_decision.visibility) < minimum_for_tool and not any(
        level_rank(rule.grant) >= minimum_for_tool  # type: ignore[arg-type]
        for rule in folder_decision.folder_policy.rules
        if rule.grant is not None
    ):
        if folder_decision.folder_policy.mode == "whitelist":
            return {
                "decision": "DENY",
                "reason": "visibility_below_METADATA",
                "account": account_id,
                "folder": folder_path,
            }

    imap_criteria = _criteria_to_imap_search(criteria_raw)
    applied_default_scope = False
    if imap_criteria == "ALL" and not criteria_raw:
        from datetime import timedelta

        from .audit import _now_utc

        since = _now_utc() - timedelta(days=7)
        imap_criteria = f"SINCE {since.strftime('%d-%b-%Y')}"
        applied_default_scope = True

    account, password = await _password_for(context, account_id)
    imap_folder = await _resolve_imap_folder(context, account_id, folder_path)
    all_uids = await imap_search_uids(account, password, imap_folder, imap_criteria)
    matched_total = len(all_uids)

    fp = folder_decision.folder_policy
    pdp_predetermined = (
        fp.mode == "blacklist" and not fp.rules and level_rank(fp.default) >= minimum_for_tool
    )
    criteria_needs_envelope = criteria_raw and any(
        k
        not in (
            "newer_than",
            "older_than",
            "from",
            "from_domain",
            "to",
            "to_contains",
            "subject_contains",
            "size_gt",
            "size_lt",
        )
        for k in criteria_raw
    )

    if pdp_predetermined and not criteria_needs_envelope:
        visible_uids = list(all_uids)
    else:
        all_envelopes = await imap_fetch_envelopes_batch(account, password, imap_folder, all_uids)
        envelope_by_uid = {e.uid: e for e in all_envelopes}
        visible_uids = []
        for candidate_uid in all_uids:
            envelope = envelope_by_uid.get(candidate_uid)
            if envelope is None:
                continue
            facts = _facts_from_envelope(envelope)
            if criteria_raw and not _criteria_match(criteria_raw, facts):
                continue
            message_decision = evaluate_message_against_folder(fp, facts=facts)
            if (
                message_decision.allowed
                and level_rank(message_decision.visibility) >= minimum_for_tool
            ):
                visible_uids.append(candidate_uid)
    filtered_out = matched_total - len(visible_uids)

    all_visible = visible_uids
    page = all_visible[offset : offset + limit]
    has_more = (offset + limit) < len(all_visible)

    results_with_gmail: list[dict[str, Any]] | None = None
    account_obj = context.account_by_id(account_id)
    if account_obj is not None and _is_google_provider(account_obj) and page and len(page) <= 10:
        results_with_gmail = []
        for vuid in page:
            entry: dict[str, Any] = {"uid": vuid}
            try:
                gm_msgid = await imap_gmail_fetch_msgid(account, password, imap_folder, vuid)
                if gm_msgid is not None:
                    entry["gm_msgid"] = gm_msgid
                    imap_all_mail = await _resolve_imap_folder(
                        context, account_id, "[Gmail]/All Mail"
                    )
                    all_mail_hits = await imap_gmail_search_by_msgid(
                        account, password, imap_all_mail, gm_msgid
                    )
                    if all_mail_hits:
                        entry["canonical_all_mail_uid"] = all_mail_hits[0]
            except Exception:
                pass
            results_with_gmail.append(entry)

    result: dict[str, Any] = {
        "decision": "ALLOW",
        "reason": "rule_matched" if all_visible else "folder_default_applied",
        "account": account_id,
        "folder": folder_path,
        "uids": page,
        "matched_total": matched_total,
        "matched_visible": len(all_visible),
        "filtered_out": filtered_out,
        "page_offset": offset,
        "page_limit": limit,
        "has_more": has_more,
    }
    if applied_default_scope:
        result["default_scope"] = "newer_than_7d"
    if results_with_gmail is not None:
        result["gmail_results"] = results_with_gmail
    return result


async def _handle_list_messages(
    context: ServerContext, arguments: dict[str, Any]
) -> dict[str, Any]:
    account_id = str(arguments["account"])
    folder_path = str(arguments["folder"])
    criteria_raw = arguments.get("criteria") or {}
    limit = int(arguments.get("limit") or 20)
    offset = int(arguments.get("offset") or 0)

    folder_decision = context.pdp.decide_folder_access(context.caller_id, account_id, folder_path)
    if not folder_decision.allowed:
        return {
            "decision": "DENY",
            "reason": folder_decision.reason,
            "account": account_id,
            "folder": folder_path,
        }
    assert folder_decision.folder_policy is not None
    minimum_for_tool = level_rank("METADATA")
    fp = folder_decision.folder_policy
    if (
        level_rank(fp.default) < minimum_for_tool
        and not any(
            level_rank(rule.grant) >= minimum_for_tool
            for rule in fp.rules
            if rule.grant is not None
        )
        and fp.mode == "whitelist"
    ):
        return {
            "decision": "DENY",
            "reason": "visibility_below_METADATA",
            "account": account_id,
            "folder": folder_path,
        }

    imap_criteria = _criteria_to_imap_search(criteria_raw)
    applied_default_scope = False
    if imap_criteria == "ALL" and not criteria_raw:
        from datetime import timedelta

        from .audit import _now_utc

        since = _now_utc() - timedelta(days=7)
        imap_criteria = f"SINCE {since.strftime('%d-%b-%Y')}"
        applied_default_scope = True

    account, password = await _password_for(context, account_id)
    imap_folder = await _resolve_imap_folder(context, account_id, folder_path)
    all_uids = await imap_search_uids(account, password, imap_folder, imap_criteria)
    matched_total = len(all_uids)

    pdp_predetermined = (
        fp.mode == "blacklist" and not fp.rules and level_rank(fp.default) >= minimum_for_tool
    )
    criteria_needs_envelope = criteria_raw and any(
        k
        not in (
            "newer_than",
            "older_than",
            "from",
            "from_domain",
            "to",
            "to_contains",
            "subject_contains",
            "size_gt",
            "size_lt",
        )
        for k in criteria_raw
    )

    if pdp_predetermined and not criteria_needs_envelope:
        visible_uids = list(all_uids)
        all_envelopes_map: dict[int, Any] = {}
    else:
        all_envelopes = await imap_fetch_envelopes_batch(account, password, imap_folder, all_uids)
        all_envelopes_map = {e.uid: e for e in all_envelopes}
        visible_uids = []
        for candidate_uid in all_uids:
            envelope = all_envelopes_map.get(candidate_uid)
            if envelope is None:
                continue
            facts = _facts_from_envelope(envelope)
            if criteria_raw and not _criteria_match(criteria_raw, facts):
                continue
            message_decision = evaluate_message_against_folder(fp, facts=facts)
            if (
                message_decision.allowed
                and level_rank(message_decision.visibility) >= minimum_for_tool
            ):
                visible_uids.append(candidate_uid)
    filtered_out = matched_total - len(visible_uids)

    page_uids = visible_uids[offset : offset + limit]
    has_more = (offset + limit) < len(visible_uids)

    if all_envelopes_map:
        envelope_by_uid = {u: all_envelopes_map[u] for u in page_uids if u in all_envelopes_map}
    else:
        envelopes = await imap_fetch_envelopes_batch(account, password, imap_folder, page_uids)
        envelope_by_uid = {e.uid: e for e in envelopes}

    messages = []
    for uid in page_uids:
        env = envelope_by_uid.get(uid)
        if env is None:
            continue
        messages.append(
            {
                "uid": env.uid,
                "from": env.from_address,
                "to": env.to_addresses,
                "subject": env.subject,
                "date": env.date,
                "has_attachment": env.has_attachment,
                "size_bytes": env.size_bytes,
            }
        )

    result: dict[str, Any] = {
        "decision": "ALLOW",
        "reason": "rule_matched" if visible_uids else "folder_default_applied",
        "account": account_id,
        "folder": folder_path,
        "messages": messages,
        "matched_total": matched_total,
        "matched_visible": len(visible_uids),
        "filtered_out": filtered_out,
        "page_offset": offset,
        "page_limit": limit,
        "has_more": has_more,
    }
    if applied_default_scope:
        result["default_scope"] = "newer_than_7d"
    return result


def _build_context(config_dir: Path, default_caller_id: str) -> tuple[ServerContext, object]:
    """Load configuration and assemble a ServerContext.

    Shared by `run_stdio` and `run_http`. The transport-specific code
    around it is the only thing that differs.
    """
    from .config import Configuration

    configuration: Configuration = load_configuration(config_dir)
    pdp = PolicyDecisionPoint(configuration)
    store_cfg = configuration.accounts_file.secret_store
    if store_cfg is None:
        raise SystemExit(
            "accounts.yaml must declare `secret_store:` before the server "
            "can resolve account credentials."
        )
    secret_store = build_secret_store(
        store_cfg.backend,
        Path(store_cfg.path) if store_cfg.path else None,
        recipient=store_cfg.recipient,
        gnupghome=Path(store_cfg.gnupghome) if store_cfg.gnupghome else None,
    )
    audit_cfg = configuration.accounts_file.audit
    audit_writer: AuditWriter | None = None
    if audit_cfg is not None and audit_cfg.directory:
        audit_writer = AuditWriter(
            directory=Path(audit_cfg.directory),
            hot_days=audit_cfg.hot_days,
            warm_days=audit_cfg.warm_days,
            delete_after_days=audit_cfg.delete_after_days,
            external_root_hook=audit_cfg.external_root_hook,
        )
    wal_cfg = configuration.accounts_file.wal
    saga_mgr: SagaManager | None = None
    if wal_cfg is not None and wal_cfg.path:
        wal = WAL(path=Path(wal_cfg.path))
        retry_limit_env = os.environ.get("IMAP_MCP_RETRY_LIMIT")
        retry_limit = int(retry_limit_env) if retry_limit_env else 3
        saga_mgr = SagaManager(wal=wal, audit_emitter=audit_writer, retry_limit=retry_limit)

    from .auth.oauth_manager import OAuthManager

    oauth_manager = OAuthManager(configuration, secret_store)

    live = _LiveState(pdp=pdp, configuration=configuration, oauth_manager=oauth_manager)
    context = ServerContext(
        default_caller_id=default_caller_id,
        _live=live,
        secret_store=secret_store,
        audit=audit_writer,
        saga=saga_mgr,
    )
    if saga_mgr is not None:

        async def _resolver(account_id: str) -> tuple[Any, str]:
            return await _password_for(context, account_id)

        saga_mgr.account_resolver = _resolver
    return context, configuration


def _reload_configuration(context: ServerContext, config_dir: Path) -> None:
    """SIGHUP-driven atomic reload (ADR 0014).

    Re-parses every YAML file in `config_dir` into a temporary
    Configuration. If parsing or validation fails, the previous
    state is preserved and an `ERROR` audit record explains why. On
    success, the new PDP + Configuration replace the live state in a
    single attribute write — handlers reading `context.pdp` /
    `context.configuration` see either the old or the new state, never
    a half-applied one.
    """
    from .config import Configuration

    audit = context.audit
    old_config: Configuration = context.configuration  # type: ignore[assignment]
    try:
        new_config: Configuration = load_configuration(config_dir)
    except Exception as exc:
        if audit is not None:
            reason = (
                "parse_error"
                if "yaml" in type(exc).__module__.lower() or "yaml" in str(exc).lower()
                else "validation_error"
            )
            audit.write(
                {
                    "caller_id": context.caller_id,
                    "tool": "policy_reload",
                    "decision": "DENY",
                    "reason": reason,
                    "result": "ERROR",
                    "detail": str(exc),
                }
            )
        return

    new_pdp = PolicyDecisionPoint(new_config)
    # Atomic swap. `_LiveState` is a mutable dataclass — assigning
    # both fields back-to-back is not atomic at the language level,
    # but every handler reads either `pdp` or `configuration` (never
    # both in one expression), so the worst case is a request that
    # uses a fresh PDP against a stale Configuration for the duration
    # of one method call. ADR 0014 declares that acceptable.
    context._live.pdp = new_pdp
    context._live.configuration = new_config

    # Detect oauth_scope changes → needs_rebootstrap (ADR 0014).
    old_scopes = {
        a.id: (a.auth.oauth_scope if a.auth else None) for a in old_config.accounts_file.accounts
    }
    for new_acct in new_config.accounts_file.accounts:
        new_scope = new_acct.auth.oauth_scope if new_acct.auth else None
        old_scope = old_scopes.get(new_acct.id)
        if old_scope is not None and new_scope != old_scope:
            rebootstrap = getattr(context.oauth_manager, "_needs_rebootstrap", None)
            if rebootstrap is None:
                context.oauth_manager._needs_rebootstrap = {}
                rebootstrap = context.oauth_manager._needs_rebootstrap
            rebootstrap[new_acct.id] = True
            if audit is not None:
                audit.write(
                    {
                        "caller_id": context.caller_id,
                        "tool": "policy_reload",
                        "decision": "ALLOW",
                        "reason": "reload_applied",
                        "result": "OK",
                        "detail": f"oauth_scope changed; rebootstrap required for {new_acct.id}",
                    }
                )

    # Pool-drain audit per removed account (no actual pool today;
    # ADR 0013's pool will hook in here when its scenarios activate).
    if audit is not None:
        old_ids = {a.id for a in old_config.accounts_file.accounts}
        new_ids = {a.id for a in new_config.accounts_file.accounts}
        for removed in sorted(old_ids - new_ids):
            audit.write(
                {
                    "caller_id": context.caller_id,
                    "tool": "pool_drain",
                    "decision": "ALLOW",
                    "reason": "account_removed",
                    "account": removed,
                    "result": "OK",
                }
            )
        audit.write(
            {
                "caller_id": context.caller_id,
                "tool": "policy_reload",
                "decision": "ALLOW",
                "reason": "reload_applied",
                "result": "OK",
                "detail": (
                    f"old_callers={len(old_config.callers_file.callers)}, "
                    f"new_callers={len(new_config.callers_file.callers)}, "
                    f"removed_accounts={sorted(old_ids - new_ids)}"
                ),
            }
        )


def _install_sighup_handler(context: ServerContext, config_dir: Path) -> None:
    """Wire SIGHUP to `_reload_configuration` on the running event loop.

    The handler is idempotent — repeated SIGHUPs each trigger a fresh
    reload. Windows lacks SIGHUP; on those platforms the registration
    is a no-op (the BDD suite runs on Linux only).
    """
    import asyncio
    import signal

    if not hasattr(signal, "SIGHUP"):
        return
    loop = asyncio.get_running_loop()

    def _on_sighup() -> None:
        _reload_configuration(context, config_dir)

    loop.add_signal_handler(signal.SIGHUP, _on_sighup)


async def run_stdio(config_dir: Path, caller_id: str | None) -> None:
    # ADR-0015: caller validation runs on EVERY stdio start. The two
    # invalid cases — None or a value not present in callers.yaml —
    # must surface as a structured JSON-RPC error during the
    # Initialize handshake, NOT as a SystemExit before the MCP loop
    # starts. Otherwise the orchestrator sees a broken pipe.
    context, configuration = _build_context(
        config_dir, default_caller_id=caller_id or "<no-caller>"
    )

    auth_failure_reason: str | None = None
    if not caller_id:
        auth_failure_reason = "no_caller_identity"
    elif configuration.caller_by_id(caller_id) is None:
        auth_failure_reason = "unknown_caller_id"

    if auth_failure_reason is not None:
        await _stdio_deny_initialize(context, caller_id, auth_failure_reason)
        return

    _install_sighup_handler(context, config_dir)
    app = build_server(context)
    async with stdio_server() as (read_stream, write_stream):
        await app.run(
            read_stream,
            write_stream,
            app.create_initialization_options(),
        )


async def _stdio_deny_initialize(
    context: ServerContext, caller_id: str | None, reason: str
) -> None:
    """Read one JSON-RPC line from stdin, write a JSON-RPC error
    response keyed to the request id, and exit cleanly. The audit
    record uses `tool=auth_failed` with `auth_failure_reason=reason`.

    The MCP client's `initialize()` reads the response, raises an
    `MCPRPCError` with the message matching `reason`, then sees EOF
    when the server exits."""
    import asyncio as _asyncio
    import json as _json
    import sys as _sys

    # Audit the failure first so the BDD harness's assertions can read
    # the JSONL record after the server exits.
    if context.audit is not None:
        record: dict[str, Any] = {
            "caller_id": caller_id,
            "caller_addr": f"stdio:pid={os.getpid()}",
            "tool": "auth_failed",
            "decision": "DENY",
            "reason": "auth_failed",
            "auth_failure_reason": reason,
        }
        context.audit.write(record)

    loop = _asyncio.get_running_loop()
    line = await loop.run_in_executor(None, _sys.stdin.readline)
    request_id: Any = None
    if line.strip():
        try:
            request = _json.loads(line)
            request_id = request.get("id")
        except _json.JSONDecodeError:
            request_id = None

    error_payload = {
        "jsonrpc": "2.0",
        "id": request_id,
        "error": {"code": -32001, "message": reason},
    }
    _sys.stdout.write(_json.dumps(error_payload, separators=(",", ":")) + "\n")
    _sys.stdout.flush()


async def run_http(config_dir: Path, host: str, port: int) -> None:
    """Serve MCP over Streamable HTTP with bearer-token caller auth.

    Bearer token + caller_id arrive as HTTP headers
    (`Authorization: Bearer <token>` and `X-MCP-Caller-Id: <id>`). The
    bearer-auth middleware resolves the caller against `callers.yaml`,
    validates the token via the configured `secret_store`, and either
    sets the per-request caller in `_CURRENT_CALLER_ID` or rejects the
    request with HTTP 401 + an `auth_failed` audit record. Non-MCP
    routes return HTTP 404 (ADR 0018, non_goal_rejection.feature).
    """
    import hmac
    import uvicorn
    from starlette.applications import Starlette
    from starlette.middleware.base import BaseHTTPMiddleware
    from starlette.responses import JSONResponse, Response
    from starlette.routing import Mount

    from mcp.server.streamable_http_manager import StreamableHTTPSessionManager

    # `default_caller_id` is unused on HTTP — every request supplies its
    # own. We still need a non-empty placeholder because the dataclass
    # frozen-default guard expects a string.
    context, configuration = _build_context(config_dir, default_caller_id="<http-no-default>")
    _install_sighup_handler(context, config_dir)

    # ADR 0015 invariant: stdio_trusted callers cannot authenticate
    # over HTTP. The orchestrator-trust assumption that justifies
    # stdio_trusted does not survive a network boundary — there is no
    # orchestrator on the other end of an HTTP socket. Any
    # stdio_trusted caller in the configured set therefore makes the
    # config invalid for HTTP, fatal at startup.
    stdio_trusted = [
        c.id for c in configuration.callers_file.callers if c.auth.type == "stdio_trusted"
    ]
    if stdio_trusted:
        names = ", ".join(f'"{c}"' for c in stdio_trusted)
        raise SystemExit(f'caller {names} as "stdio_trusted not permitted on non-stdio transport"')

    app_mcp = build_server(context)
    session_manager = StreamableHTTPSessionManager(app=app_mcp, json_response=True, stateless=True)

    def _audit_auth_failed(caller_id_claim: str | None, reason: str, addr: str) -> None:
        if context.audit is None:
            return
        # `secret_decryption_failed` is a configuration-class failure
        # (the secret store could not decrypt the configured value),
        # not a wrong-credential failure. The audit `reason` field
        # surfaces it as a distinct category so operators can tell
        # them apart at a glance.
        top_reason = (
            "secret_decryption_failed" if reason == "secret_decryption_failed" else "auth_failed"
        )
        record: dict[str, Any] = {
            "caller_id": caller_id_claim,
            "caller_addr": addr,
            "tool": "auth_failed",
            "decision": "DENY",
            "reason": top_reason,
            "auth_failure_reason": reason,
        }
        context.audit.write(record)

    from .secrets import SecretDecryptionFailed

    def _resolve_token(secret_ref: str | None) -> tuple[str | None, str | None]:
        """Return `(value, error_reason)`. `error_reason` is non-None
        only on a recoverable lookup failure that the audit layer
        should distinguish from a plain "missing secret"."""
        if secret_ref is None:
            return None, None
        try:
            return context.secret_store.get(secret_ref), None  # type: ignore[attr-defined]
        except SecretDecryptionFailed:
            return None, "secret_decryption_failed"
        except Exception:
            return None, None

    class BearerAuthMiddleware(BaseHTTPMiddleware):
        async def dispatch(self, request, call_next):  # type: ignore[no-untyped-def]
            # Only the MCP route requires authentication. Anything else
            # is a non-route and returns 404 unconditionally below.
            if not request.url.path.rstrip("/").endswith("/mcp"):
                return await call_next(request)
            addr = request.client.host if request.client else "http:?"
            caller_id_claim = request.headers.get("x-mcp-caller-id")
            authz = request.headers.get("authorization", "")
            scheme, _, token = authz.partition(" ")
            if scheme.lower() != "bearer" or not token:
                _audit_auth_failed(caller_id_claim, "no_bearer_token", f"http:{addr}")
                return JSONResponse({"error": "auth_failed"}, status_code=401)
            if not caller_id_claim:
                _audit_auth_failed(None, "no_caller_id", f"http:{addr}")
                return JSONResponse({"error": "no_caller_identity"}, status_code=401)
            caller = configuration.caller_by_id(caller_id_claim)
            if caller is None:
                # ADR-0015 identity-immutability: if the bearer
                # matches a configured caller's token, the client is
                # masquerading as someone else. Surface that as
                # `identity_immutable` rather than the generic
                # `unknown_caller_id`. Constant-time scan over all
                # callers.
                masquerade = False
                for other in configuration.callers_file.callers:
                    if other.auth.type != "shared_token":
                        continue
                    other_expected, _ = _resolve_token(other.auth.token_secret_ref)
                    if other_expected is not None and hmac.compare_digest(token, other_expected):
                        masquerade = True
                if masquerade:
                    _audit_auth_failed(caller_id_claim, "identity_immutable", f"http:{addr}")
                    return JSONResponse({"error": "identity_immutable"}, status_code=401)
                _audit_auth_failed(caller_id_claim, "unknown_caller_id", f"http:{addr}")
                return JSONResponse({"error": "unknown_caller_id"}, status_code=401)
            if caller.auth.type != "shared_token":
                _audit_auth_failed(caller_id_claim, "wrong_auth_type", f"http:{addr}")
                return JSONResponse({"error": "auth_failed"}, status_code=401)
            expected, lookup_error = _resolve_token(caller.auth.token_secret_ref)
            if lookup_error is not None:
                _audit_auth_failed(caller_id_claim, lookup_error, f"http:{addr}")
                return JSONResponse({"error": "auth_failed"}, status_code=401)
            if expected is None or not hmac.compare_digest(token, expected):
                # Identity-immutability check (ADR-0015): if the token
                # actually matches a DIFFERENT configured caller, the
                # client is trying to "switch" identity while keeping
                # an existing bearer. That is a distinct error class
                # — call it `identity_immutable`. Run the loop fully
                # for constant-time comparison.
                token_matches_other = False
                for other in configuration.callers_file.callers:
                    if other.id == caller_id_claim or other.auth.type != "shared_token":
                        continue
                    other_expected, _ = _resolve_token(other.auth.token_secret_ref)
                    if other_expected is not None and hmac.compare_digest(token, other_expected):
                        token_matches_other = True
                if token_matches_other:
                    _audit_auth_failed(caller_id_claim, "identity_immutable", f"http:{addr}")
                    return JSONResponse({"error": "identity_immutable"}, status_code=401)
                _audit_auth_failed(caller_id_claim, "wrong_token", f"http:{addr}")
                return JSONResponse({"error": "auth_failed"}, status_code=401)
            token_var = _CURRENT_CALLER_ID.set(caller_id_claim)
            try:
                return await call_next(request)
            finally:
                _CURRENT_CALLER_ID.reset(token_var)

    async def _handle_mcp(scope, receive, send):  # type: ignore[no-untyped-def]
        await session_manager.handle_request(scope, receive, send)

    async def _not_found(request):  # type: ignore[no-untyped-def]
        return Response(status_code=404)

    from starlette.routing import Route

    starlette_app = Starlette(
        routes=[
            Mount("/mcp", app=_handle_mcp),
            Route(
                "/{path:path}",
                endpoint=_not_found,
                methods=["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"],
            ),
        ],
        middleware=[],
    )
    starlette_app.add_middleware(BearerAuthMiddleware)

    async with session_manager.run():
        config = uvicorn.Config(starlette_app, host=host, port=port, log_level="warning")
        await uvicorn.Server(config).serve()


def _caller_id_from_env_or_exit() -> str:
    caller_id = os.environ.get("IMAP_MCP_CALLER_ID")
    if not caller_id:
        raise SystemExit(
            "IMAP_MCP_CALLER_ID is not set. The stdio_trusted auth type "
            "requires the orchestrator to supply the caller identity via "
            "argv or environment (ADR 0015)."
        )
    return caller_id


def _config_dir_from_env_or_exit() -> Path:
    raw = os.environ.get("IMAP_MCP_CONFIG_DIR")
    if not raw:
        raise SystemExit(
            "IMAP_MCP_CONFIG_DIR is not set. The server requires a path to "
            "the config tree (accounts.yaml, callers.yaml, policies/*.yaml)."
        )
    path = Path(raw)
    if not path.is_dir():
        raise SystemExit(f"IMAP_MCP_CONFIG_DIR does not point at a directory: {path}")
    return path
