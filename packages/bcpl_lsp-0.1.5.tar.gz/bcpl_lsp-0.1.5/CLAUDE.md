# BCPL LSP

Language Server Protocol implementation for Martin Richards' canonical BCPL.

## Build & Run

```bash
uv run bcpl-lsp --stdio          # Launch LSP server
uv run pytest                     # Run tests
uv run ruff check src/ tests/     # Lint
```

## Architecture

- `src/bcpl_lsp/parser/` — Lexer and recursive descent parser producing AST
- `src/bcpl_lsp/analysis/` — Symbol table, name resolution, diagnostics
- `src/bcpl_lsp/features/` — LSP feature handlers (completion, definition, etc.)
- `src/bcpl_lsp/workspace/` — Document state management, GET resolution
- `src/bcpl_lsp/server.py` — Main pygls server entry point

## BCPL Dialect

Targets Martin Richards' canonical BCPL with uppercase keywords (LET, IF, THEN, etc.).
