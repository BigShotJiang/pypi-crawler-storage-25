"""Tests for document symbol logic."""

from __future__ import annotations

from lsprotocol import types

from bcpl_lsp.analysis.symbols import Symbol, SymbolKind
from bcpl_lsp.features.document_symbol import get_document_symbols
from bcpl_lsp.parser.ast_nodes import Range


def test_empty_symbols():
    assert get_document_symbols([]) == []


def test_function_symbol():
    sym = Symbol(
        name="start", kind=SymbolKind.FUNCTION,
        range=Range(0, 4, 5, 1), params=["argv"],
    )
    result = get_document_symbols([sym])
    assert len(result) == 1
    assert result[0].name == "start"
    assert result[0].kind == types.SymbolKind.Function
    assert result[0].detail == "(argv)"


def test_function_no_params():
    sym = Symbol(
        name="init", kind=SymbolKind.FUNCTION,
        range=Range(0, 4, 2, 1),
    )
    result = get_document_symbols([sym])
    assert len(result) == 1
    assert result[0].detail == ""


def test_global_symbol_shows_slot():
    sym = Symbol(
        name="output", kind=SymbolKind.GLOBAL,
        range=Range(1, 2, 1, 8), global_number=149,
    )
    result = get_document_symbols([sym])
    assert len(result) == 1
    assert result[0].name == "output"
    assert result[0].kind == types.SymbolKind.Variable
    assert result[0].detail == ": 149"


def test_parameters_excluded():
    sym = Symbol(
        name="x", kind=SymbolKind.PARAMETER,
        range=Range(0, 10, 0, 11),
    )
    result = get_document_symbols([sym])
    assert len(result) == 0


def test_constant_symbol():
    sym = Symbol(
        name="MAXLINE", kind=SymbolKind.CONSTANT,
        range=Range(2, 2, 2, 9),
    )
    result = get_document_symbols([sym])
    assert len(result) == 1
    assert result[0].kind == types.SymbolKind.Constant


def test_section_symbol():
    sym = Symbol(
        name="BLIB", kind=SymbolKind.SECTION,
        range=Range(0, 0, 0, 4),
    )
    result = get_document_symbols([sym])
    assert len(result) == 1
    assert result[0].kind == types.SymbolKind.Module


def test_range_mapping():
    sym = Symbol(
        name="foo", kind=SymbolKind.FUNCTION,
        range=Range(10, 4, 20, 1),
    )
    result = get_document_symbols([sym])
    r = result[0].range
    assert r.start.line == 10
    assert r.start.character == 4
    assert r.end.line == 20
    assert r.end.character == 1


def test_multiple_symbols():
    syms = [
        Symbol(name="start", kind=SymbolKind.FUNCTION, range=Range(0, 4, 5, 1)),
        Symbol(name="x", kind=SymbolKind.PARAMETER, range=Range(0, 10, 0, 11)),
        Symbol(name="BUFSIZE", kind=SymbolKind.CONSTANT, range=Range(7, 2, 7, 9)),
        Symbol(name="output", kind=SymbolKind.GLOBAL, range=Range(10, 2, 10, 8), global_number=149),
    ]
    result = get_document_symbols(syms)
    names = [s.name for s in result]
    assert "start" in names
    assert "BUFSIZE" in names
    assert "output" in names
    assert "x" not in names  # parameter excluded
