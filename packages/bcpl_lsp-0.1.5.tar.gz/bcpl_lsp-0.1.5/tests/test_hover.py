"""Tests for hover logic."""

from __future__ import annotations

from bcpl_lsp.analysis.references import Reference, ReferenceContext
from bcpl_lsp.analysis.scope_resolver import ResolvedReference
from bcpl_lsp.analysis.symbols import Symbol, SymbolKind
from bcpl_lsp.features.hover import get_hover, _format_hover
from bcpl_lsp.parser.ast_nodes import Range


def _make_resolved(sym: Symbol) -> ResolvedReference:
    ref = Reference(
        name=sym.name, range=Range(5, 0, 5, len(sym.name)),
        uri="test.b", context=ReferenceContext.OTHER,
    )
    return ResolvedReference(reference=ref, symbol=sym)


def test_hover_returns_none_when_no_resolved():
    assert get_hover(None) is None


def test_hover_returns_none_when_no_symbol():
    ref = Reference(
        name="x", range=Range(0, 0, 0, 1),
        uri="test.b", context=ReferenceContext.OTHER,
    )
    rr = ResolvedReference(reference=ref, symbol=None)
    assert get_hover(rr) is None


def test_hover_function_with_params():
    sym = Symbol(
        name="lookup", kind=SymbolKind.FUNCTION,
        range=Range(0, 4, 0, 10), params=["key", "table"],
    )
    text = _format_hover(sym)
    assert "LET lookup(key, table) = ..." in text
    assert "bcpl" in text  # code block language


def test_hover_function_with_global_slot():
    sym = Symbol(
        name="start", kind=SymbolKind.FUNCTION,
        range=Range(0, 4, 0, 9), params=[],
        global_number=1,
    )
    text = _format_hover(sym)
    assert "LET start" in text
    assert "GLOBAL slot: 1" in text


def test_hover_manifest_constant():
    sym = Symbol(
        name="bufsize", kind=SymbolKind.CONSTANT,
        range=Range(0, 0, 0, 7), value_text="256",
    )
    text = _format_hover(sym)
    assert "bufsize = 256" in text
    assert "MANIFEST" in text


def test_hover_manifest_no_value():
    sym = Symbol(
        name="flag", kind=SymbolKind.CONSTANT,
        range=Range(0, 0, 0, 4),
    )
    text = _format_hover(sym)
    assert "flag" in text
    assert "MANIFEST" in text


def test_hover_global_entry():
    sym = Symbol(
        name="count", kind=SymbolKind.GLOBAL,
        range=Range(0, 0, 0, 5), global_number=200,
        uri="/globals.b",
    )
    text = _format_hover(sym)
    assert "count : 200" in text
    assert "GLOBAL" in text
    assert "/globals.b" in text


def test_hover_static():
    sym = Symbol(
        name="counter", kind=SymbolKind.STATIC,
        range=Range(0, 0, 0, 7),
    )
    text = _format_hover(sym)
    assert "counter" in text
    assert "STATIC" in text


def test_hover_parameter():
    sym = Symbol(
        name="n", kind=SymbolKind.PARAMETER,
        range=Range(0, 0, 0, 1),
    )
    text = _format_hover(sym)
    assert "n" in text
    assert "Parameter" in text


def test_hover_variable():
    sym = Symbol(
        name="result", kind=SymbolKind.VARIABLE,
        range=Range(0, 0, 0, 6),
    )
    text = _format_hover(sym)
    assert "result" in text
    assert "Local variable" in text


def test_hover_section():
    sym = Symbol(
        name="MAIN", kind=SymbolKind.SECTION,
        range=Range(0, 0, 0, 4),
    )
    text = _format_hover(sym)
    assert 'SECTION "MAIN"' in text


def test_get_hover_returns_hover_object():
    sym = Symbol(
        name="start", kind=SymbolKind.FUNCTION,
        range=Range(0, 4, 0, 9), params=["x"],
    )
    rr = _make_resolved(sym)
    hover = get_hover(rr)
    assert hover is not None
    assert hover.contents.kind.value == "markdown"
    assert "LET start(x)" in hover.contents.value
    # Hover range should match the reference range
    assert hover.range.start.line == 5
    assert hover.range.start.character == 0
