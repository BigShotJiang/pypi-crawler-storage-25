GET "libhdr"

LET start() BE
$( writef("Hello, BCPL world!*n")
$)
