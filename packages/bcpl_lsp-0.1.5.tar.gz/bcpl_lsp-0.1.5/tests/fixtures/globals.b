SECTION "globals"

GET "libhdr"

GLOBAL $(
  count : 200
  limit : 201
$)

MANIFEST $(
  bufsize = 256
  maxval  = 1000
$)

STATIC $(
  total = 0
  flag  = TRUE
$)

LET start() BE
$( count := 0
   limit := maxval
   FOR i = 1 TO limit DO
   $( count := count + 1
      total := total + i
   $)
   writef("count=%n total=%n*n", count, total)
$)
