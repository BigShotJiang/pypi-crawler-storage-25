GET "libhdr"

LET start() BE
$( LET x = :=
   writef("syntax error above*n")
$)
