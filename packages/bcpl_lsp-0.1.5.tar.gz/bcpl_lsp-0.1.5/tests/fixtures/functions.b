GET "libhdr"

LET factorial(n) = n = 0 -> 1, n * factorial(n - 1)

AND gcd(a, b) = b = 0 -> a, gcd(b, a REM b)

LET start() BE
$( LET n = 10
   LET result = factorial(n)
   writef("factorial(%n) = %n*n", n, result)
   writef("gcd(12, 8) = %n*n", gcd(12, 8))
$)
