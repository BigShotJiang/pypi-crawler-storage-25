GET "circular_b.b"

LET func_a() = 1
