GET "circular_a.b"

LET func_b() = 2
