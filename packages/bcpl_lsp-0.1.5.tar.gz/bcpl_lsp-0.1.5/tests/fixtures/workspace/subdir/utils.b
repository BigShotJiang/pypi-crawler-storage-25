SECTION "utils"

LET helper(x) = x + 1
