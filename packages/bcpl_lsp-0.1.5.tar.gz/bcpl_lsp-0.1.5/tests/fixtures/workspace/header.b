GET "subdir/utils"

MANIFEST
$(
    version = 1
$)
