GET "header.b"

SECTION "main"

LET start() = VALOF
$(
    writef("Hello*N")
    RESULTIS 0
$)
