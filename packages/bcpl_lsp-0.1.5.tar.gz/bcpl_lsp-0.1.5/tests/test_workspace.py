"""Tests for workspace indexer and GET resolver."""

from pathlib import Path

from bcpl_lsp.workspace.document import DocumentState
from bcpl_lsp.workspace.get_resolver import GetResolver
from bcpl_lsp.workspace.indexer import WorkspaceIndex

FIXTURES = Path(__file__).parent / "fixtures" / "workspace"


class TestWorkspaceIndex:
    def test_discover_finds_b_files(self):
        idx = WorkspaceIndex(FIXTURES)
        discovered = idx.discover()
        names = {p.name for p in discovered}
        assert "main.b" in names
        assert "header.b" in names
        assert "utils.b" in names

    def test_discover_ignores_non_bcpl(self, tmp_path):
        (tmp_path / "readme.txt").write_text("not bcpl")
        (tmp_path / "code.b").write_text("LET x = 1")
        idx = WorkspaceIndex(tmp_path)
        discovered = idx.discover()
        assert len(discovered) == 1
        assert discovered[0].name == "code.b"

    def test_files_returns_tracked_paths(self):
        idx = WorkspaceIndex(FIXTURES)
        idx.discover()
        files = idx.files()
        assert len(files) >= 3
        assert all(isinstance(f, str) for f in files)

    def test_ensure_parsed_returns_document_state(self):
        idx = WorkspaceIndex(FIXTURES)
        idx.discover()
        main_path = str(FIXTURES / "main.b")
        state = idx.ensure_parsed(main_path)
        assert isinstance(state, DocumentState)
        assert state.ast is not None

    def test_ensure_parsed_caches_result(self):
        idx = WorkspaceIndex(FIXTURES)
        idx.discover()
        main_path = str(FIXTURES / "main.b")
        state1 = idx.ensure_parsed(main_path)
        state2 = idx.ensure_parsed(main_path)
        assert state1 is state2

    def test_invalidate_clears_cache(self):
        idx = WorkspaceIndex(FIXTURES)
        idx.discover()
        main_path = str(FIXTURES / "main.b")
        idx.ensure_parsed(main_path)
        idx.invalidate(main_path)
        assert idx.get_state(main_path) is None

    def test_update_reparses(self):
        idx = WorkspaceIndex(FIXTURES)
        idx.discover()
        main_path = str(FIXTURES / "main.b")
        state1 = idx.ensure_parsed(main_path)
        state2 = idx.update(main_path, 'LET newvar = 42')
        assert state2 is not state1
        assert idx.get_state(main_path) is state2

    def test_get_state_returns_none_for_unknown(self):
        idx = WorkspaceIndex(FIXTURES)
        assert idx.get_state("/nonexistent") is None

    def test_remove_untracks_file(self):
        idx = WorkspaceIndex(FIXTURES)
        idx.discover()
        main_path = str(FIXTURES / "main.b")
        idx.ensure_parsed(main_path)
        idx.remove(main_path)
        assert main_path not in idx.files()
        assert idx.get_state(main_path) is None


class TestGetResolver:
    def test_resolve_finds_file_in_same_dir(self):
        resolver = GetResolver()
        result = resolver.resolve("header.b", FIXTURES / "main.b")
        assert result is not None
        assert result.name == "header.b"

    def test_resolve_case_insensitive(self, tmp_path):
        (tmp_path / "MyHeader.b").write_text("LET x = 1")
        resolver = GetResolver()
        result = resolver.resolve("myheader.b", tmp_path / "test.b")
        assert result is not None
        assert result.name == "MyHeader.b"

    def test_resolve_adds_extension(self):
        resolver = GetResolver()
        # "subdir/utils" should resolve to "subdir/utils.b"
        result = resolver.resolve("subdir/utils", FIXTURES / "header.b")
        assert result is not None
        assert result.name == "utils.b"

    def test_resolve_uses_search_paths(self, tmp_path):
        lib_dir = tmp_path / "lib"
        lib_dir.mkdir()
        (lib_dir / "libhdr.b").write_text("MANIFEST $( x = 1 $)")
        resolver = GetResolver(search_paths=[lib_dir])
        result = resolver.resolve("libhdr.b", tmp_path / "main.b")
        assert result is not None
        assert result.parent == lib_dir

    def test_resolve_returns_none_for_missing(self):
        resolver = GetResolver()
        result = resolver.resolve("nonexistent.b", FIXTURES / "main.b")
        assert result is None

    def test_resolve_chain_includes_transitive(self):
        resolver = GetResolver()
        chain = resolver.resolve_chain(FIXTURES / "main.b")
        names = [p.name for p in chain]
        assert names[0] == "main.b"
        assert "header.b" in names
        assert "utils.b" in names

    def test_resolve_chain_breaks_circular(self):
        resolver = GetResolver()
        chain = resolver.resolve_chain(FIXTURES / "circular_a.b")
        names = [p.name for p in chain]
        assert "circular_a.b" in names
        assert "circular_b.b" in names
        # Each file appears exactly once
        assert len(names) == len(set(names))
