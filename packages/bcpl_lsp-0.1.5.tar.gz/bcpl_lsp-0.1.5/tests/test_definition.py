"""Tests for go-to-definition logic."""

from __future__ import annotations

from pathlib import Path

from bcpl_lsp.analysis.references import Reference, ReferenceContext
from bcpl_lsp.analysis.scope_resolver import ResolvedReference, ScopeResolver
from bcpl_lsp.analysis.symbols import Symbol, SymbolKind, SymbolTableBuilder
from bcpl_lsp.features.definition import get_definition
from bcpl_lsp.parser.ast_nodes import Range
from bcpl_lsp.parser.lexer import Lexer
from bcpl_lsp.parser.parser import Parser
from bcpl_lsp.workspace.document import DocumentState


def parse(source: str):
    tokens = Lexer(source).tokenize()
    return Parser(tokens).parse()


def make_state(source: str, uri: str = "") -> DocumentState:
    tokens = Lexer(source).tokenize()
    ast = Parser(tokens).parse()
    builder = SymbolTableBuilder(uri=uri)
    builder.build(ast)
    return DocumentState(
        uri=uri, source=source, tokens=tokens, ast=ast,
        symbols=builder.all_symbols, diagnostics=[],
    )


class SimpleIndex:
    def __init__(self, states: dict[str, DocumentState]) -> None:
        self._states = states

    def ensure_parsed(self, path: str, source: str | None = None) -> DocumentState:
        return self._states[path]


class SimpleGetResolver:
    def __init__(self, chains: dict[str, list[str]] | None = None) -> None:
        self._chains = chains or {}

    def resolve_chain(self, file_path: Path) -> list[Path]:
        key = str(file_path)
        return [Path(p) for p in self._chains.get(key, [key])]


def test_get_definition_returns_none_when_no_resolved():
    assert get_definition(None) is None


def test_get_definition_returns_none_when_no_symbol():
    ref = Reference(
        name="x", range=Range(0, 0, 0, 1),
        uri="test.b", context=ReferenceContext.OTHER,
    )
    rr = ResolvedReference(reference=ref, symbol=None)
    assert get_definition(rr) is None


def test_get_definition_returns_location_for_symbol():
    sym = Symbol(
        name="start", kind=SymbolKind.FUNCTION,
        range=Range(0, 4, 0, 9), uri="/test.b",
    )
    ref = Reference(
        name="start", range=Range(2, 0, 2, 5),
        uri="/test.b", context=ReferenceContext.CALL,
    )
    rr = ResolvedReference(reference=ref, symbol=sym)
    loc = get_definition(rr)
    assert loc is not None
    assert loc.uri == "file:///test.b"
    assert loc.range.start.line == 0
    assert loc.range.start.character == 4


def test_get_definition_preserves_file_uri():
    sym = Symbol(
        name="f", kind=SymbolKind.FUNCTION,
        range=Range(0, 0, 0, 1), uri="file:///already/uri.b",
    )
    ref = Reference(
        name="f", range=Range(1, 0, 1, 1),
        uri="test.b", context=ReferenceContext.CALL,
    )
    loc = get_definition(ResolvedReference(reference=ref, symbol=sym))
    assert loc is not None
    assert loc.uri == "file:///already/uri.b"


def test_definition_via_scope_resolver():
    """Integration: resolve_at -> get_definition for a local function call."""
    source = "LET start() BE f()\nAND f() = 42"
    state = make_state(source, uri="/test.b")
    index = SimpleIndex({"/test.b": state})
    resolver = SimpleGetResolver({"/test.b": ["/test.b"]})
    scope = ScopeResolver(index=index, resolver=resolver)

    # Find ref to 'f' in the call at line 0
    resolved_file = scope.resolve("/test.b")
    f_refs = [rr for rr in resolved_file.resolved_refs if rr.reference.name == "f"]
    assert len(f_refs) >= 1

    loc = get_definition(f_refs[0])
    assert loc is not None
    assert loc.uri == "file:///test.b"


def test_definition_cross_file_global():
    """Go-to-definition follows a GLOBAL to its defining file."""
    source_a = "GLOBAL $(\n  count : 200\n$)"
    state_a = make_state(source_a, uri="/a.b")

    source_b = "LET start() BE count := 0"
    state_b = make_state(source_b, uri="/b.b")

    index = SimpleIndex({"/a.b": state_a, "/b.b": state_b})
    resolver = SimpleGetResolver({"/b.b": ["/b.b", "/a.b"]})
    scope = ScopeResolver(index=index, resolver=resolver)

    resolved_file = scope.resolve("/b.b")
    count_refs = [rr for rr in resolved_file.resolved_refs if rr.reference.name == "count"]
    assert len(count_refs) >= 1

    loc = get_definition(count_refs[0])
    assert loc is not None
    # The symbol comes from /a.b
    assert loc.uri == "file:///a.b"
