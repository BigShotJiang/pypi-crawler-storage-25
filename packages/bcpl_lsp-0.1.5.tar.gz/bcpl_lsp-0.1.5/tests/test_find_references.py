"""Tests for find-all-references."""

from __future__ import annotations

from pathlib import Path

from bcpl_lsp.analysis.scope_resolver import ScopeResolver
from bcpl_lsp.analysis.symbols import SymbolTableBuilder
from bcpl_lsp.features.references import _find_references
from bcpl_lsp.parser.lexer import Lexer
from bcpl_lsp.parser.parser import Parser
from bcpl_lsp.workspace.document import DocumentState


class SimpleIndex:
    """Mock WorkspaceIndex that holds pre-parsed document states."""

    def __init__(self, states: dict[str, DocumentState]) -> None:
        self._states = states

    def ensure_parsed(self, path: str, source: str | None = None) -> DocumentState:
        return self._states[path]

    def files(self) -> list[str]:
        return list(self._states.keys())

    def get_state(self, path: str) -> DocumentState | None:
        return self._states.get(path)


class SimpleGetResolver:
    """Mock GetResolver that returns a fixed chain."""

    def __init__(self, chains: dict[str, list[str]] | None = None) -> None:
        self._chains = chains or {}

    def resolve_chain(self, file_path: Path) -> list[Path]:
        key = str(file_path)
        paths = self._chains.get(key, [key])
        return [Path(p) for p in paths]


def make_state(source: str, uri: str = "") -> DocumentState:
    tokens = Lexer(source).tokenize()
    parser = Parser(tokens)
    ast = parser.parse()
    builder = SymbolTableBuilder(uri=uri)
    builder.build(ast)
    return DocumentState(
        uri=uri,
        source=source,
        tokens=tokens,
        ast=ast,
        symbols=builder.all_symbols,
        diagnostics=[],
    )


def test_find_refs_same_file():
    source = "LET f(x) = x + 1\nAND g() = f(2)"
    state = make_state(source, uri="/test.b")
    index = SimpleIndex({"/test.b": state})
    resolver = SimpleGetResolver({"/test.b": ["/test.b"]})
    sr = ScopeResolver(index=index, resolver=resolver)

    # Find the position of 'f' in g's body (line 1)
    # "AND g() = f(2)" — 'f' is at col 10
    locs = _find_references(sr, index, "/test.b", 1, 10, include_declaration=False)
    # Should find at least one reference to f (the call in g)
    assert len(locs) >= 1
    for loc in locs:
        assert loc.uri.endswith("/test.b") or loc.uri == "/test.b"


def test_find_refs_include_declaration():
    source = "LET f(x) = x + 1\nAND g() = f(2)"
    state = make_state(source, uri="/test.b")
    index = SimpleIndex({"/test.b": state})
    resolver = SimpleGetResolver({"/test.b": ["/test.b"]})
    sr = ScopeResolver(index=index, resolver=resolver)

    locs_with_decl = _find_references(sr, index, "/test.b", 1, 10, include_declaration=True)
    locs_without_decl = _find_references(sr, index, "/test.b", 1, 10, include_declaration=False)
    # With declaration should have at least one more location
    assert len(locs_with_decl) >= len(locs_without_decl)


def test_find_refs_cross_file():
    source_a = "GLOBAL $(\n  count : 200\n$)"
    state_a = make_state(source_a, uri="/a.b")

    source_b = "LET start() BE count := 0"
    state_b = make_state(source_b, uri="/b.b")

    index = SimpleIndex({"/a.b": state_a, "/b.b": state_b})
    resolver = SimpleGetResolver({
        "/a.b": ["/a.b"],
        "/b.b": ["/b.b", "/a.b"],
    })
    sr = ScopeResolver(index=index, resolver=resolver)

    # Resolve file b first so the reference to 'count' is resolved
    sr.resolve("/b.b")

    # Find 'count' reference — in "LET start() BE count := 0", count is at col 19
    locs = _find_references(sr, index, "/b.b", 0, 19, include_declaration=True)
    # Should find at least the declaration in a.b and the reference in b.b
    assert len(locs) >= 2
    uris = {loc.uri for loc in locs}
    assert any("a.b" in u for u in uris)
    assert any("b.b" in u for u in uris)


def test_find_refs_global_matches_by_slot():
    # Two files define globals with the same name but different slots
    source_a = "GLOBAL $(\n  count : 200\n$)"
    state_a = make_state(source_a, uri="/a.b")

    source_b = "GLOBAL $(\n  count : 300\n$)\nLET start() BE count := 0"
    state_b = make_state(source_b, uri="/b.b")

    index = SimpleIndex({"/a.b": state_a, "/b.b": state_b})
    resolver = SimpleGetResolver({
        "/a.b": ["/a.b"],
        "/b.b": ["/b.b"],  # b doesn't GET a, so its own count:300 is used
    })
    sr = ScopeResolver(index=index, resolver=resolver)

    # Resolve both files
    sr.resolve("/a.b")
    sr.resolve("/b.b")

    # References to count in b.b should match slot 300, not 200
    locs = _find_references(sr, index, "/b.b", 2, 19, include_declaration=True)
    # All returned locations should be from b.b (slot 300)
    for loc in locs:
        assert "b.b" in loc.uri


def test_find_refs_no_match():
    source = "LET start() BE RETURN"
    state = make_state(source, uri="/test.b")
    index = SimpleIndex({"/test.b": state})
    resolver = SimpleGetResolver({"/test.b": ["/test.b"]})
    sr = ScopeResolver(index=index, resolver=resolver)

    # Position with no reference
    locs = _find_references(sr, index, "/test.b", 0, 0, include_declaration=False)
    assert locs == []
