"""Tests for the BCPL symbol table."""

from bcpl_lsp.analysis.symbols import Symbol, SymbolKind, SymbolTableBuilder
from bcpl_lsp.parser.ast_nodes import Range
from bcpl_lsp.parser.lexer import Lexer
from bcpl_lsp.parser.parser import Parser


def build_symbols(source: str, uri: str = ""):
    tokens = Lexer(source).tokenize()
    parser = Parser(tokens)
    ast = parser.parse()
    builder = SymbolTableBuilder(uri=uri)
    builder.build(ast)
    return builder.all_symbols, builder.global_scope


def test_function_symbols():
    symbols, scope = build_symbols("LET start() BE RETURN")
    names = {s.name for s in symbols}
    assert "start" in names
    start_sym = scope.lookup("start")
    assert start_sym is not None
    assert start_sym.kind == SymbolKind.FUNCTION


def test_function_params():
    symbols, scope = build_symbols("LET add(x, y) = x + y")
    param_syms = [s for s in symbols if s.kind == SymbolKind.PARAMETER]
    param_names = {s.name for s in param_syms}
    assert param_names == {"x", "y"}


def test_global_symbols():
    symbols, scope = build_symbols("GLOBAL $(\n  count : 200\n  limit : 201\n$)")
    count = scope.lookup("count")
    assert count is not None
    assert count.kind == SymbolKind.GLOBAL
    assert count.global_number == 200


def test_manifest_symbols():
    symbols, scope = build_symbols("MANIFEST $(\n  bufsize = 256\n$)")
    buf = scope.lookup("bufsize")
    assert buf is not None
    assert buf.kind == SymbolKind.CONSTANT


def test_static_symbols():
    symbols, scope = build_symbols("STATIC $(\n  total = 0\n$)")
    total = scope.lookup("total")
    assert total is not None
    assert total.kind == SymbolKind.STATIC


def test_section_symbol():
    symbols, scope = build_symbols('SECTION "mysection"\nLET start() BE RETURN')
    sec = scope.lookup("mysection")
    assert sec is not None
    assert sec.kind == SymbolKind.SECTION


def test_all_visible():
    symbols, scope = build_symbols(
        "GLOBAL $(\n  g1 : 100\n$)\nMANIFEST $(\n  m1 = 42\n$)\nLET foo() BE RETURN"
    )
    visible = scope.all_visible()
    assert "g1" in visible
    assert "m1" in visible
    assert "foo" in visible


def test_manifest_value_text_number():
    symbols, scope = build_symbols("MANIFEST $(\n  bufsize = 256\n$)")
    buf = scope.lookup("bufsize")
    assert buf is not None
    assert buf.value_text == "256"


def test_manifest_value_text_ident():
    symbols, scope = build_symbols("MANIFEST $(\n  limit = maxval\n$)")
    sym = scope.lookup("limit")
    assert sym is not None
    assert sym.value_text == "maxval"


def test_manifest_value_text_binary_expr():
    symbols, scope = build_symbols("MANIFEST $(\n  size = n + 1\n$)")
    sym = scope.lookup("size")
    assert sym is not None
    assert sym.value_text == "n + 1"


def test_manifest_value_text_unary_expr():
    symbols, scope = build_symbols("MANIFEST $(\n  neg = -1\n$)")
    sym = scope.lookup("neg")
    assert sym is not None
    assert sym.value_text == "-1"


def test_manifest_value_text_none_for_auto_increment():
    symbols, scope = build_symbols("MANIFEST $(\n  first = 0\n  second\n$)")
    sym = scope.lookup("second")
    assert sym is not None
    assert sym.value_text is None


def test_manifest_value_text_nested_binary():
    symbols, scope = build_symbols("MANIFEST $(\n  val = a + b * c\n$)")
    sym = scope.lookup("val")
    assert sym is not None
    assert sym.value_text == "a + b * c"


def test_globals_fixture(globals_source):
    symbols, scope = build_symbols(globals_source)
    names = {s.name for s in symbols}
    assert "count" in names
    assert "limit" in names
    assert "bufsize" in names
    assert "maxval" in names
    assert "total" in names
    assert "flag" in names
    assert "start" in names


def test_symbol_uri_defaults_to_empty():
    r = Range(0, 0, 0, 0)
    sym = Symbol(name="x", kind=SymbolKind.VARIABLE, range=r)
    assert sym.uri == ""


def test_symbol_definition_range_defaults_to_none():
    r = Range(0, 0, 0, 0)
    sym = Symbol(name="x", kind=SymbolKind.VARIABLE, range=r)
    assert sym.definition_range is None


def test_builder_propagates_uri():
    uri = "file:///tmp/test.b"
    symbols, scope = build_symbols("LET start() BE RETURN", uri=uri)
    for sym in symbols:
        assert sym.uri == uri


def test_builder_propagates_uri_to_all_symbol_kinds():
    uri = "file:///tmp/test.b"
    source = (
        'SECTION "sec"\n'
        "GLOBAL $(\n  g1 : 100\n$)\n"
        "MANIFEST $(\n  m1 = 42\n$)\n"
        "STATIC $(\n  s1 = 0\n$)\n"
        "LET foo(x) = x"
    )
    symbols, _ = build_symbols(source, uri=uri)
    assert len(symbols) > 0
    for sym in symbols:
        assert sym.uri == uri, f"Symbol {sym.name} ({sym.kind}) missing uri"
