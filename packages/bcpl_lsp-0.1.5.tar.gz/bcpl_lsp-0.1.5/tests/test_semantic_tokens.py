"""Tests for semantic tokens feature."""

from __future__ import annotations

from bcpl_lsp.features.semantic_tokens import (
    SEMANTIC_TOKENS_LEGEND,
    TOKEN_TYPES,
    compute_semantic_tokens,
    _modifier_bits,
)
from bcpl_lsp.parser.lexer import Lexer


def tokenize(source: str):
    return Lexer(source).tokenize()


def decode_tokens(data: list[int]) -> list[dict]:
    """Decode the delta-encoded semantic token data into readable dicts."""
    result = []
    line = 0
    col = 0
    i = 0
    while i < len(data):
        delta_line = data[i]
        delta_col = data[i + 1]
        length = data[i + 2]
        type_idx = data[i + 3]
        mods = data[i + 4]
        if delta_line > 0:
            line += delta_line
            col = delta_col
        else:
            col += delta_col
        result.append({
            "line": line,
            "col": col,
            "length": length,
            "type": TOKEN_TYPES[type_idx],
            "mods": mods,
        })
        i += 5
    return result


def test_legend_has_expected_types():
    assert "function" in SEMANTIC_TOKENS_LEGEND.token_types
    assert "keyword" in SEMANTIC_TOKENS_LEGEND.token_types
    assert "comment" in SEMANTIC_TOKENS_LEGEND.token_types
    assert "number" in SEMANTIC_TOKENS_LEGEND.token_types


def test_legend_has_expected_modifiers():
    assert "declaration" in SEMANTIC_TOKENS_LEGEND.token_modifiers
    assert "readonly" in SEMANTIC_TOKENS_LEGEND.token_modifiers


def test_keywords_get_keyword_type():
    tokens = tokenize("LET IF THEN ELSE")
    data = compute_semantic_tokens(tokens, None, "test.b")
    decoded = decode_tokens(data)
    for tok in decoded:
        assert tok["type"] == "keyword"


def test_number_literal():
    tokens = tokenize("42")
    data = compute_semantic_tokens(tokens, None, "test.b")
    decoded = decode_tokens(data)
    nums = [t for t in decoded if t["type"] == "number"]
    assert len(nums) == 1
    assert nums[0]["length"] == 2


def test_string_literal():
    tokens = tokenize('"hello"')
    data = compute_semantic_tokens(tokens, None, "test.b")
    decoded = decode_tokens(data)
    strings = [t for t in decoded if t["type"] == "string"]
    assert len(strings) == 1


def test_comment_token():
    tokens = tokenize("// a comment")
    data = compute_semantic_tokens(tokens, None, "test.b")
    decoded = decode_tokens(data)
    comments = [t for t in decoded if t["type"] == "comment"]
    assert len(comments) == 1


def test_identifier_defaults_to_variable():
    tokens = tokenize("LET x = 1")
    data = compute_semantic_tokens(tokens, None, "test.b")
    decoded = decode_tokens(data)
    idents = [t for t in decoded if t["type"] == "variable"]
    assert len(idents) >= 1


def test_delta_encoding_multiline():
    source = "LET\nIF"
    tokens = tokenize(source)
    data = compute_semantic_tokens(tokens, None, "test.b")
    # First token at (0, 0), second at (1, 0)
    # Delta: [0, 0, 3, kw, 0, 1, 0, 2, kw, 0]
    assert data[0] == 0  # delta_line for LET
    assert data[5] == 1  # delta_line for IF
    assert data[6] == 0  # delta_col for IF (new line)


def test_modifier_bits():
    assert _modifier_bits("declaration") == 1  # bit 0
    assert _modifier_bits("definition") == 2   # bit 1
    assert _modifier_bits("readonly") == 4     # bit 2
    assert _modifier_bits("declaration", "readonly") == 5  # bits 0+2


def test_mixed_source():
    source = 'LET start() = VALOF $( RESULTIS 42 $)'
    tokens = tokenize(source)
    data = compute_semantic_tokens(tokens, None, "test.b")
    decoded = decode_tokens(data)
    types_found = {t["type"] for t in decoded}
    assert "keyword" in types_found
    assert "variable" in types_found
    assert "number" in types_found
