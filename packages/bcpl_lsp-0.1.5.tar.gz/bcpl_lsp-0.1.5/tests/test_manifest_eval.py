"""Tests for MANIFEST constant expression evaluator."""

from bcpl_lsp.analysis.manifest_eval import evaluate_manifest_block
from bcpl_lsp.parser.lexer import Lexer
from bcpl_lsp.parser.parser import Parser
from bcpl_lsp.parser.ast_nodes import ManifestBlock


def _parse_manifest(source: str) -> ManifestBlock:
    tokens = Lexer(source).tokenize()
    ast = Parser(tokens).parse()
    for decl in ast.declarations:
        if isinstance(decl, ManifestBlock):
            return decl
    raise ValueError("No MANIFEST block found")


def test_integer_literal():
    block = _parse_manifest("MANIFEST $(\n  x = 42\n$)")
    result = evaluate_manifest_block(block)
    assert result == {"x": 42}


def test_arithmetic():
    block = _parse_manifest("MANIFEST $(\n  x = 10 + 5\n$)")
    result = evaluate_manifest_block(block)
    assert result == {"x": 15}


def test_subtraction():
    block = _parse_manifest("MANIFEST $(\n  x = 10 - 3\n$)")
    result = evaluate_manifest_block(block)
    assert result == {"x": 7}


def test_multiplication():
    block = _parse_manifest("MANIFEST $(\n  x = 4 * 3\n$)")
    result = evaluate_manifest_block(block)
    assert result == {"x": 12}


def test_division():
    block = _parse_manifest("MANIFEST $(\n  x = 10 / 3\n$)")
    result = evaluate_manifest_block(block)
    assert result == {"x": 3}


def test_shift_left():
    block = _parse_manifest("MANIFEST $(\n  x = 1 << 4\n$)")
    result = evaluate_manifest_block(block)
    assert result == {"x": 16}


def test_shift_right():
    block = _parse_manifest("MANIFEST $(\n  x = 16 >> 2\n$)")
    result = evaluate_manifest_block(block)
    assert result == {"x": 4}


def test_auto_increment():
    block = _parse_manifest("MANIFEST $(\n  a = 0\n  b\n  c\n$)")
    result = evaluate_manifest_block(block)
    assert result == {"a": 0, "b": 1, "c": 2}


def test_auto_increment_from_nonzero():
    block = _parse_manifest("MANIFEST $(\n  x = 5\n  y\n  z\n$)")
    result = evaluate_manifest_block(block)
    assert result == {"x": 5, "y": 6, "z": 7}


def test_reference_to_previous():
    block = _parse_manifest("MANIFEST $(\n  base = 100\n  next = base + 1\n$)")
    result = evaluate_manifest_block(block)
    assert result == {"base": 100, "next": 101}


def test_known_constants():
    block = _parse_manifest("MANIFEST $(\n  x = maxval + 1\n$)")
    result = evaluate_manifest_block(block, {"maxval": 255})
    assert result == {"x": 256}


def test_negative_literal():
    block = _parse_manifest("MANIFEST $(\n  x = -1\n$)")
    result = evaluate_manifest_block(block)
    assert result == {"x": -1}


def test_nested_expression():
    block = _parse_manifest("MANIFEST $(\n  x = 2 + 3 * 4\n$)")
    result = evaluate_manifest_block(block)
    # Parser precedence determines grouping
    assert "x" in result


def test_division_by_zero():
    block = _parse_manifest("MANIFEST $(\n  x = 10 / 0\n$)")
    result = evaluate_manifest_block(block)
    assert "x" not in result


def test_unresolvable_reference():
    block = _parse_manifest("MANIFEST $(\n  x = unknown\n$)")
    result = evaluate_manifest_block(block)
    assert "x" not in result


def test_dot_separated_names():
    """Manifest entries with dot-separated names (struct-like patterns)."""
    block = _parse_manifest(
        "MANIFEST $(\n  pkt.link = 0\n  pkt.id = 1\n  pkt.type = 5\n$)"
    )
    result = evaluate_manifest_block(block)
    assert result == {"pkt.link": 0, "pkt.id": 1, "pkt.type": 5}
