"""Tests for global vector audit report."""

from pathlib import Path

from bcpl_lsp.analysis.global_registry import GlobalRegistry
from bcpl_lsp.analysis.scope_resolver import ScopeResolver
from bcpl_lsp.migration.global_report import generate_report
from bcpl_lsp.workspace.get_resolver import GetResolver
from bcpl_lsp.workspace.indexer import WorkspaceIndex


def _make_index(tmp_path: Path, files: dict[str, str]) -> WorkspaceIndex:
    for name, content in files.items():
        (tmp_path / name).write_text(content)
    index = WorkspaceIndex(tmp_path)
    index.discover()
    return index


def test_report_has_table(tmp_path):
    index = _make_index(tmp_path, {
        "main.b": "GLOBAL $(\n  start : 1\n  stop : 2\n$)",
    })
    registry = GlobalRegistry(index)
    registry.scan()
    resolver = GetResolver()
    scope = ScopeResolver(index, resolver)
    report = generate_report(registry, scope, index)
    assert "# Global Vector Audit Report" in report
    assert "| Slot |" in report
    assert "start" in report
    assert "stop" in report


def test_report_shows_conflicts(tmp_path):
    index = _make_index(tmp_path, {
        "a.b": "GLOBAL $(\n  foo : 10\n$)",
        "b.b": "GLOBAL $(\n  bar : 10\n$)",
    })
    registry = GlobalRegistry(index)
    registry.scan()
    resolver = GetResolver()
    scope = ScopeResolver(index, resolver)
    report = generate_report(registry, scope, index)
    assert "## Conflicts" in report
    assert "Slot 10" in report


def test_report_shows_gaps(tmp_path):
    index = _make_index(tmp_path, {
        "main.b": "GLOBAL $(\n  a : 1\n  b : 5\n$)",
    })
    registry = GlobalRegistry(index)
    registry.scan()
    resolver = GetResolver()
    scope = ScopeResolver(index, resolver)
    report = generate_report(registry, scope, index)
    assert "## Gaps" in report


def test_report_empty_workspace(tmp_path):
    index = _make_index(tmp_path, {})
    registry = GlobalRegistry(index)
    registry.scan()
    resolver = GetResolver()
    scope = ScopeResolver(index, resolver)
    report = generate_report(registry, scope, index)
    assert "Total slots used:** 0" in report
