"""Tests for global vector slot tracking."""

from pathlib import Path

from bcpl_lsp.analysis.global_registry import GlobalRegistry
from bcpl_lsp.workspace.indexer import WorkspaceIndex


def _make_index(tmp_path: Path, files: dict[str, str]) -> WorkspaceIndex:
    for name, content in files.items():
        (tmp_path / name).write_text(content)
    index = WorkspaceIndex(tmp_path)
    index.discover()
    return index


def test_single_file_globals(tmp_path):
    index = _make_index(tmp_path, {
        "main.b": "GLOBAL $(\n  start : 1\n  stop  : 2\n$)",
    })
    reg = GlobalRegistry(index)
    reg.scan()
    assert reg.lookup_slot(1)[0].name == "start"
    assert reg.lookup_slot(2)[0].name == "stop"


def test_conflict_detection(tmp_path):
    index = _make_index(tmp_path, {
        "a.b": "GLOBAL $(\n  foo : 10\n$)",
        "b.b": "GLOBAL $(\n  bar : 10\n$)",
    })
    reg = GlobalRegistry(index)
    reg.scan()
    conflicts = reg.conflicts()
    assert len(conflicts) == 1
    assert conflicts[0].slot == 10
    names = {a.name for a in conflicts[0].allocations}
    assert names == {"foo", "bar"}


def test_no_conflict_same_name(tmp_path):
    """Same name in same slot across files is not a conflict."""
    index = _make_index(tmp_path, {
        "a.b": "GLOBAL $(\n  start : 1\n$)",
        "b.b": "GLOBAL $(\n  start : 1\n$)",
    })
    reg = GlobalRegistry(index)
    reg.scan()
    assert len(reg.conflicts()) == 0


def test_gap_detection(tmp_path):
    index = _make_index(tmp_path, {
        "main.b": "GLOBAL $(\n  a : 1\n  b : 3\n  c : 5\n$)",
    })
    reg = GlobalRegistry(index)
    reg.scan()
    gaps = reg.gaps()
    assert 2 in gaps
    assert 4 in gaps
    assert 1 not in gaps


def test_usage_summary(tmp_path):
    index = _make_index(tmp_path, {
        "main.b": "GLOBAL $(\n  x : 10\n  y : 12\n$)",
    })
    reg = GlobalRegistry(index)
    reg.scan()
    summary = reg.usage_summary()
    assert summary.total_used == 2
    assert summary.min_slot == 10
    assert summary.max_slot == 12
    assert 11 in summary.gaps


def test_lookup_name(tmp_path):
    index = _make_index(tmp_path, {
        "main.b": "GLOBAL $(\n  start : 1\n  stop : 2\n$)",
    })
    reg = GlobalRegistry(index)
    reg.scan()
    allocs = reg.lookup_name("start")
    assert len(allocs) == 1
    assert allocs[0].slot == 1


def test_empty_workspace(tmp_path):
    index = _make_index(tmp_path, {})
    reg = GlobalRegistry(index)
    reg.scan()
    assert reg.usage_summary().total_used == 0
    assert reg.gaps() == []
    assert reg.conflicts() == []
