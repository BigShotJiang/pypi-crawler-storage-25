"""Tests for completion logic."""

from __future__ import annotations

from lsprotocol import types

from bcpl_lsp.analysis.symbols import Symbol, SymbolKind
from bcpl_lsp.features.completion import get_completions, KEYWORD_SNIPPETS
from bcpl_lsp.parser.ast_nodes import Range
from bcpl_lsp.parser.tokens import KEYWORDS


def test_completions_include_all_keywords():
    result = get_completions([])
    labels = {item.label for item in result.items}
    for kw in KEYWORDS:
        assert kw in labels


def test_keyword_snippets_have_snippet_format():
    result = get_completions([])
    for item in result.items:
        if item.label in KEYWORD_SNIPPETS:
            assert item.insert_text_format == types.InsertTextFormat.Snippet
            assert item.insert_text is not None
            assert item.detail is not None


def test_keyword_without_snippet_has_no_insert_text():
    result = get_completions([])
    non_snippet_kw = [item for item in result.items
                      if item.label in KEYWORDS and item.label not in KEYWORD_SNIPPETS]
    for item in non_snippet_kw:
        assert item.insert_text is None
        assert item.kind == types.CompletionItemKind.Keyword


def test_function_symbol_completion():
    sym = Symbol(
        name="lookup", kind=SymbolKind.FUNCTION,
        range=Range(0, 4, 0, 10), params=["key", "table"],
    )
    result = get_completions([sym])
    match = [item for item in result.items if item.label == "lookup"]
    assert len(match) == 1
    assert match[0].kind == types.CompletionItemKind.Function
    assert match[0].detail == "(key, table)"


def test_global_symbol_completion():
    sym = Symbol(
        name="output", kind=SymbolKind.GLOBAL,
        range=Range(0, 0, 0, 6), global_number=149,
    )
    result = get_completions([sym])
    match = [item for item in result.items if item.label == "output"]
    assert len(match) == 1
    assert match[0].kind == types.CompletionItemKind.Variable
    assert match[0].detail == ": 149"


def test_constant_symbol_completion():
    sym = Symbol(
        name="MAXLINE", kind=SymbolKind.CONSTANT,
        range=Range(0, 0, 0, 7),
    )
    result = get_completions([sym])
    match = [item for item in result.items if item.label == "MAXLINE"]
    assert len(match) == 1
    assert match[0].kind == types.CompletionItemKind.Constant


def test_section_symbols_excluded():
    sym = Symbol(
        name="MAIN", kind=SymbolKind.SECTION,
        range=Range(0, 0, 0, 4),
    )
    result = get_completions([sym])
    match = [item for item in result.items if item.label == "MAIN"]
    assert len(match) == 0


def test_completion_list_not_incomplete():
    result = get_completions([])
    assert result.is_incomplete is False
