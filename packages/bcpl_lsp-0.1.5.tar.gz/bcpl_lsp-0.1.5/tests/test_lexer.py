"""Tests for the BCPL lexer."""

from bcpl_lsp.parser.lexer import Lexer
from bcpl_lsp.parser.tokens import TokenType


def test_keywords():
    tokens = Lexer("LET IF THEN ELSE").tokenize()
    types = [t.type for t in tokens if t.type != TokenType.EOF]
    assert types == [TokenType.LET, TokenType.IF, TokenType.THEN, TokenType.ELSE]


def test_identifiers():
    tokens = Lexer("foo bar_baz x123").tokenize()
    idents = [t for t in tokens if t.type == TokenType.IDENT]
    assert [t.text for t in idents] == ["foo", "bar_baz", "x123"]


def test_numbers():
    tokens = Lexer("42 #xFF #b1010 #o77").tokenize()
    nums = [t for t in tokens if t.type == TokenType.NUMBER]
    assert [t.text for t in nums] == ["42", "#xFF", "#b1010", "#o77"]


def test_strings():
    tokens = Lexer('"hello" "world*n"').tokenize()
    strs = [t for t in tokens if t.type == TokenType.STRING]
    assert len(strs) == 2
    assert strs[0].text == '"hello"'
    assert strs[1].text == '"world*n"'


def test_char_constants():
    tokens = Lexer("'A' '*n'").tokenize()
    chars = [t for t in tokens if t.type == TokenType.CHARCONST]
    assert len(chars) == 2


def test_operators():
    tokens = Lexer(":= ~= <= >= << >> ->").tokenize()
    types = [t.type for t in tokens if t.type != TokenType.EOF]
    assert types == [
        TokenType.ASSIGN, TokenType.NEQ, TokenType.LE, TokenType.GE,
        TokenType.LSHIFT, TokenType.RSHIFT, TokenType.COND,
    ]


def test_block_delimiters():
    tokens = Lexer("$( $) { }").tokenize()
    types = [t.type for t in tokens if t.type != TokenType.EOF]
    assert types == [TokenType.LBRACE, TokenType.RBRACE, TokenType.LBRACE, TokenType.RBRACE]


def test_line_comment():
    tokens = Lexer("LET // comment\nIF").tokenize()
    non_trivial = [t for t in tokens if t.type not in (TokenType.EOF, TokenType.NEWLINE)]
    assert non_trivial[0].type == TokenType.LET
    assert non_trivial[1].type == TokenType.COMMENT
    assert non_trivial[2].type == TokenType.IF


def test_double_bar_comment():
    tokens = Lexer("LET || comment\nIF").tokenize()
    non_trivial = [t for t in tokens if t.type not in (TokenType.EOF, TokenType.NEWLINE)]
    assert non_trivial[0].type == TokenType.LET
    assert non_trivial[1].type == TokenType.COMMENT
    assert non_trivial[1].text == "|| comment"
    assert non_trivial[2].type == TokenType.IF


def test_double_bar_comment_at_end():
    tokens = Lexer("LET x = 1 || end of line").tokenize()
    comments = [t for t in tokens if t.type == TokenType.COMMENT]
    assert len(comments) == 1
    assert comments[0].text == "|| end of line"


def test_single_bar_still_logor():
    tokens = Lexer("a | b").tokenize()
    types = [t.type for t in tokens if t.type not in (TokenType.EOF,)]
    assert TokenType.LOGOR in types
    assert TokenType.COMMENT not in types


def test_block_comment():
    tokens = Lexer("LET /* block\ncomment */ IF").tokenize()
    non_trivial = [t for t in tokens if t.type not in (TokenType.EOF, TokenType.NEWLINE)]
    assert non_trivial[0].type == TokenType.LET
    assert non_trivial[1].type == TokenType.COMMENT
    assert non_trivial[2].type == TokenType.IF


def test_position_tracking():
    tokens = Lexer("LET x = 42").tokenize()
    let_tok = tokens[0]
    assert let_tok.line == 0
    assert let_tok.column == 0
    x_tok = [t for t in tokens if t.type == TokenType.IDENT][0]
    assert x_tok.line == 0
    assert x_tok.column == 4


def test_hello_fixture(hello_source):
    tokens = Lexer(hello_source).tokenize()
    # Should tokenize without errors
    assert not any(t.type == TokenType.ERROR for t in tokens)
    assert tokens[-1].type == TokenType.EOF


def test_globals_fixture(globals_source):
    tokens = Lexer(globals_source).tokenize()
    assert not any(t.type == TokenType.ERROR for t in tokens)
    # Check that GLOBAL, MANIFEST, STATIC keywords are found
    kw_types = {t.type for t in tokens}
    assert TokenType.GLOBAL in kw_types
    assert TokenType.MANIFEST in kw_types
    assert TokenType.STATIC in kw_types
