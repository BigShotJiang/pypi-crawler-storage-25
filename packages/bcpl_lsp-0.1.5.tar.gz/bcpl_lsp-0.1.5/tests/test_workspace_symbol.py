"""Tests for workspace symbol search."""

from __future__ import annotations

from bcpl_lsp.analysis.symbols import SymbolTableBuilder
from bcpl_lsp.features.workspace_symbol import _workspace_symbols
from bcpl_lsp.parser.lexer import Lexer
from bcpl_lsp.parser.parser import Parser
from bcpl_lsp.workspace.document import DocumentState


class SimpleIndex:
    """Mock WorkspaceIndex for testing."""

    def __init__(self, states: dict[str, DocumentState]) -> None:
        self._states = states

    def files(self) -> list[str]:
        return list(self._states.keys())

    def get_state(self, path: str) -> DocumentState | None:
        return self._states.get(path)

    def ensure_parsed(self, path: str, source: str | None = None) -> DocumentState:
        return self._states[path]


def make_state(source: str, uri: str = "") -> DocumentState:
    tokens = Lexer(source).tokenize()
    parser = Parser(tokens)
    ast = parser.parse()
    builder = SymbolTableBuilder(uri=uri)
    builder.build(ast)
    return DocumentState(
        uri=uri,
        source=source,
        tokens=tokens,
        ast=ast,
        symbols=builder.all_symbols,
        diagnostics=[],
    )


def test_empty_query_returns_all():
    source = "LET start() BE RETURN\nAND helper() = 1"
    state = make_state(source, uri="file:///test.b")
    index = SimpleIndex({"/test.b": state})
    results = _workspace_symbols(index, "")
    names = {r.name for r in results}
    assert "start" in names
    assert "helper" in names


def test_substring_match():
    source = "LET start() BE RETURN\nAND helper() = 1"
    state = make_state(source, uri="file:///test.b")
    index = SimpleIndex({"/test.b": state})
    results = _workspace_symbols(index, "hel")
    names = {r.name for r in results}
    assert "helper" in names
    assert "start" not in names


def test_case_insensitive():
    source = "LET MyFunc() BE RETURN"
    state = make_state(source, uri="file:///test.b")
    index = SimpleIndex({"/test.b": state})
    results = _workspace_symbols(index, "myfunc")
    assert len(results) == 1
    assert results[0].name == "MyFunc"


def test_excludes_parameters():
    source = "LET add(x, y) = x + y"
    state = make_state(source, uri="file:///test.b")
    index = SimpleIndex({"/test.b": state})
    results = _workspace_symbols(index, "")
    names = {r.name for r in results}
    assert "add" in names
    assert "x" not in names
    assert "y" not in names


def test_multiple_files():
    state_a = make_state("LET alpha() BE RETURN", uri="file:///a.b")
    state_b = make_state("LET beta() BE RETURN", uri="file:///b.b")
    index = SimpleIndex({"/a.b": state_a, "/b.b": state_b})
    results = _workspace_symbols(index, "")
    names = {r.name for r in results}
    assert "alpha" in names
    assert "beta" in names


def test_globals_and_manifests():
    source = "GLOBAL $(\n  count : 200\n$)\nMANIFEST $(\n  bufsize = 256\n$)"
    state = make_state(source, uri="file:///test.b")
    index = SimpleIndex({"/test.b": state})
    results = _workspace_symbols(index, "")
    names = {r.name for r in results}
    assert "count" in names
    assert "bufsize" in names


def test_no_match():
    source = "LET start() BE RETURN"
    state = make_state(source, uri="file:///test.b")
    index = SimpleIndex({"/test.b": state})
    results = _workspace_symbols(index, "nonexistent")
    assert results == []


def test_location_uri():
    source = "LET start() BE RETURN"
    state = make_state(source, uri="file:///test.b")
    index = SimpleIndex({"/test.b": state})
    results = _workspace_symbols(index, "start")
    assert len(results) == 1
    assert results[0].location.uri.startswith("file://")
