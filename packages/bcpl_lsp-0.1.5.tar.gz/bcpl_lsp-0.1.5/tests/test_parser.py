"""Tests for the BCPL parser."""

from bcpl_lsp.parser.ast_nodes import (
    GetDirective,
    GlobalBlock,
    LetDecl,
    ManifestBlock,
    Program,
    Section,
    StaticBlock,
)
from bcpl_lsp.parser.lexer import Lexer
from bcpl_lsp.parser.parser import Parser


def parse(source: str) -> tuple[Program, list]:
    tokens = Lexer(source).tokenize()
    parser = Parser(tokens)
    ast = parser.parse()
    return ast, parser.errors


def test_get_directive():
    ast, errors = parse('GET "libhdr"')
    assert len(ast.declarations) == 1
    assert isinstance(ast.declarations[0], GetDirective)
    assert ast.declarations[0].filename == "libhdr"


def test_let_function():
    ast, errors = parse("LET start() BE\n$( RETURN\n$)")
    assert len(ast.declarations) == 1
    decl = ast.declarations[0]
    assert isinstance(decl, LetDecl)
    assert decl.name == "start"
    assert decl.is_function
    assert decl.params == []


def test_let_with_params():
    ast, errors = parse("LET add(x, y) = x + y")
    decl = ast.declarations[0]
    assert isinstance(decl, LetDecl)
    assert decl.name == "add"
    assert decl.params == ["x", "y"]
    assert decl.is_function


def test_let_variable():
    ast, errors = parse("LET start() BE\n$( LET x = 42\n$)")
    assert len(errors) == 0


def test_global_block():
    ast, errors = parse("GLOBAL $(\n  count : 200\n  limit : 201\n$)")
    assert len(ast.declarations) == 1
    block = ast.declarations[0]
    assert isinstance(block, GlobalBlock)
    assert len(block.entries) == 2
    assert block.entries[0].name == "count"
    assert block.entries[0].number == 200


def test_manifest_block():
    ast, errors = parse("MANIFEST $(\n  bufsize = 256\n  maxval = 1000\n$)")
    block = ast.declarations[0]
    assert isinstance(block, ManifestBlock)
    assert len(block.entries) == 2
    assert block.entries[0].name == "bufsize"


def test_static_block():
    ast, errors = parse("STATIC $(\n  total = 0\n  flag = TRUE\n$)")
    block = ast.declarations[0]
    assert isinstance(block, StaticBlock)
    assert len(block.entries) == 2


def test_section():
    ast, errors = parse('SECTION "test"\nGET "libhdr"\nLET start() BE RETURN')
    assert len(ast.declarations) == 1
    sec = ast.declarations[0]
    assert isinstance(sec, Section)
    assert sec.name == "test"
    assert len(sec.declarations) >= 2


def test_for_loop():
    ast, errors = parse("LET start() BE\n$( FOR i = 1 TO 10 DO writef(\"%n*n\", i)\n$)")
    assert len(errors) == 0


def test_error_recovery(errors_source):
    ast, errors = parse(errors_source)
    # Should produce errors but still parse the rest
    assert len(errors) > 0
    # Should still find the GET and LET declarations
    assert len(ast.declarations) >= 1


def test_hello_fixture(hello_source):
    ast, errors = parse(hello_source)
    assert len(errors) == 0
    assert len(ast.declarations) >= 1


def test_functions_fixture(functions_source):
    ast, errors = parse(functions_source)
    # Should find GET, LET factorial, AND gcd, LET start
    decls = ast.declarations
    assert len(decls) >= 2


def test_globals_fixture(globals_source):
    ast, errors = parse(globals_source)
    # Should have SECTION containing GET, GLOBAL, MANIFEST, STATIC, LET
    assert len(ast.declarations) >= 1
