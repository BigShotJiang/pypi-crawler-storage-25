"""Tests for call graph construction."""

from __future__ import annotations

from pathlib import Path

from bcpl_lsp.analysis.call_graph import CallGraph
from bcpl_lsp.analysis.scope_resolver import ScopeResolver
from bcpl_lsp.analysis.symbols import SymbolTableBuilder
from bcpl_lsp.parser.lexer import Lexer
from bcpl_lsp.parser.parser import Parser
from bcpl_lsp.workspace.document import DocumentState


def make_state(source: str, uri: str = "") -> DocumentState:
    tokens = Lexer(source).tokenize()
    ast = Parser(tokens).parse()
    builder = SymbolTableBuilder(uri=uri)
    builder.build(ast)
    return DocumentState(
        uri=uri, source=source, tokens=tokens, ast=ast,
        symbols=builder.all_symbols, diagnostics=[],
    )


class SimpleIndex:
    def __init__(self, states: dict[str, DocumentState]) -> None:
        self._states = states

    def ensure_parsed(self, path: str, source: str | None = None) -> DocumentState:
        return self._states[path]

    def files(self) -> list[str]:
        return list(self._states.keys())


class SimpleGetResolver:
    def __init__(self, chains: dict[str, list[str]] | None = None) -> None:
        self._chains = chains or {}

    def resolve_chain(self, file_path: Path) -> list[Path]:
        key = str(file_path)
        return [Path(p) for p in self._chains.get(key, [key])]


def _make_graph(sources: dict[str, str], chains: dict[str, list[str]] | None = None):
    """Helper: build a CallGraph from source strings."""
    states = {path: make_state(src, uri=path) for path, src in sources.items()}
    if chains is None:
        chains = {p: [p] for p in sources}
    index = SimpleIndex(states)
    resolver = SimpleGetResolver(chains)
    scope = ScopeResolver(index=index, resolver=resolver)
    graph = CallGraph(scope, index)
    return graph


def test_simple_call():
    source = "LET start() BE f()\nAND f() = 42"
    graph = _make_graph({"/test.b": source})

    callers = graph.callers_of("f")
    assert len(callers) == 1
    assert callers[0].caller_name == "start"
    assert callers[0].callee_name == "f"

    callees = graph.callees_of("start")
    assert len(callees) == 1
    assert callees[0].callee_name == "f"


def test_no_callers():
    source = "LET start() = 42"
    graph = _make_graph({"/test.b": source})
    assert graph.callers_of("start") == []


def test_multiple_calls_from_same_function():
    source = "LET start() BE $( f(); g() $)\nAND f() = 1\nAND g() = 2"
    graph = _make_graph({"/test.b": source})

    callees = graph.callees_of("start")
    callee_names = {s.callee_name for s in callees}
    assert "f" in callee_names
    assert "g" in callee_names


def test_cross_file_call():
    # Cross-file visibility in BCPL requires GLOBAL declarations
    source_a = "GLOBAL $(\n  helper : 100\n$)\nLET helper() = 99"
    source_b = "LET start() BE helper()"
    chains = {
        "/a.b": ["/a.b"],
        "/b.b": ["/b.b", "/a.b"],
    }
    graph = _make_graph({"/a.b": source_a, "/b.b": source_b}, chains)

    callers = graph.callers_of("helper")
    assert len(callers) == 1
    assert callers[0].caller_name == "start"


def test_callees_of_unknown_function():
    source = "LET start() = 42"
    graph = _make_graph({"/test.b": source})
    assert graph.callees_of("nonexistent") == []


def test_mutual_recursion():
    source = "LET f() BE g()\nAND g() BE f()"
    graph = _make_graph({"/test.b": source})

    f_callees = graph.callees_of("f")
    assert any(s.callee_name == "g" for s in f_callees)

    g_callees = graph.callees_of("g")
    assert any(s.callee_name == "f" for s in g_callees)


def test_invalidate_clears_graph():
    source = "LET start() BE f()\nAND f() = 42"
    graph = _make_graph({"/test.b": source})

    # Force build
    assert len(graph.callers_of("f")) == 1

    graph.invalidate()
    # Should rebuild on next query
    assert len(graph.callers_of("f")) == 1
