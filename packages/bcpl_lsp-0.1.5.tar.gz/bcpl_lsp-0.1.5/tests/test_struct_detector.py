"""Tests for struct candidate detection."""

from pathlib import Path

from bcpl_lsp.migration.struct_detector import detect_structs
from bcpl_lsp.workspace.indexer import WorkspaceIndex


def _make_index(tmp_path: Path, files: dict[str, str]) -> WorkspaceIndex:
    for name, content in files.items():
        (tmp_path / name).write_text(content)
    index = WorkspaceIndex(tmp_path)
    index.discover()
    return index


def test_detect_dot_pattern(tmp_path):
    index = _make_index(tmp_path, {
        "types.b": (
            "MANIFEST $(\n"
            "  pkt.link = 0\n"
            "  pkt.id   = 1\n"
            "  pkt.type = 2\n"
            "$)"
        ),
    })
    candidates = detect_structs(index)
    assert len(candidates) == 1
    c = candidates[0]
    assert c.name == "Pkt"
    assert len(c.fields) == 3
    field_names = [f.name for f in c.fields]
    assert "link" in field_names
    assert "id" in field_names
    assert "type" in field_names


def test_no_struct_single_field(tmp_path):
    """A single field is not enough for a struct candidate."""
    index = _make_index(tmp_path, {
        "types.b": "MANIFEST $(\n  pkt.link = 0\n$)",
    })
    candidates = detect_structs(index)
    assert len(candidates) == 0


def test_fields_sorted_by_offset(tmp_path):
    index = _make_index(tmp_path, {
        "types.b": (
            "MANIFEST $(\n"
            "  buf.size = 5\n"
            "  buf.data = 0\n"
            "  buf.next = 3\n"
            "$)"
        ),
    })
    candidates = detect_structs(index)
    assert len(candidates) == 1
    offsets = [f.offset for f in candidates[0].fields]
    assert offsets == sorted(offsets)


def test_struct_size(tmp_path):
    index = _make_index(tmp_path, {
        "types.b": (
            "MANIFEST $(\n"
            "  node.left  = 0\n"
            "  node.right = 1\n"
            "  node.value = 2\n"
            "$)"
        ),
    })
    candidates = detect_structs(index)
    assert candidates[0].size == 3


def test_multiple_structs(tmp_path):
    index = _make_index(tmp_path, {
        "types.b": (
            "MANIFEST $(\n"
            "  pkt.link = 0\n"
            "  pkt.id   = 1\n"
            "  buf.data = 0\n"
            "  buf.size = 1\n"
            "$)"
        ),
    })
    candidates = detect_structs(index)
    assert len(candidates) == 2
    names = {c.name for c in candidates}
    assert names == {"Pkt", "Buf"}


def test_no_structs_in_empty_workspace(tmp_path):
    index = _make_index(tmp_path, {})
    assert detect_structs(index) == []
