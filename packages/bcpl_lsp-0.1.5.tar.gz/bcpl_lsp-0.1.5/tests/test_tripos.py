"""Tests for TRIPOS corpus parsing — validates real-world BCPL code."""

from bcpl_lsp.parser.ast_nodes import Program
from bcpl_lsp.parser.lexer import Lexer
from bcpl_lsp.parser.parser import Parser


def parse(source: str) -> tuple[Program, list]:
    tokens = Lexer(source).tokenize()
    parser = Parser(tokens)
    ast = parser.parse()
    return ast, parser.errors


def test_tripos_libhdr(tripos_libhdr_source: str):
    """Parse TRIPOS g/libhdr — a large header with GLOBAL and MANIFEST blocks."""
    ast, errors = parse(tripos_libhdr_source)
    assert not errors, f"Parse errors in libhdr: {errors[:3]}"
    assert len(ast.declarations) >= 2
    # Should contain GLOBAL and MANIFEST blocks
    types = {type(d).__name__ for d in ast.declarations}
    assert "GlobalBlock" in types
    assert "ManifestBlock" in types


def test_tripos_cg_intcode(tripos_cg_intcode_source: str):
    """Parse TRIPOS intcode/cg-intcode.b — a large code generator."""
    ast, errors = parse(tripos_cg_intcode_source)
    assert not errors, f"Parse errors in cg-intcode: {errors[:3]}"
    assert len(ast.declarations) >= 5
    # Should contain a SECTION
    types = {type(d).__name__ for d in ast.declarations}
    assert "Section" in types


def test_tripos_cli_init(tripos_cli_init_source: str):
    """Parse TRIPOS pdp11/sys/bcpl/cli-init — a medium-sized command utility."""
    ast, errors = parse(tripos_cli_init_source)
    assert not errors, f"Parse errors in cli-init: {errors[:3]}"
    assert len(ast.declarations) >= 1


def test_backslash_or():
    """\\/ is alternate syntax for | (logical OR)."""
    ast, errors = parse('LET x = a \\/ b')
    assert not errors


def test_backslash_not():
    """\\ is alternate syntax for ~ (bitwise NOT)."""
    ast, errors = parse('LET x = \\y')
    assert not errors


def test_case_insensitive_keywords():
    """Keywords should be recognized regardless of case."""
    ast, errors = parse('LET f() BE FOR i = 1 to 10 do x := x + i')
    assert not errors


def test_labeled_brackets():
    """Labeled section brackets like $(1 ... $)1 should parse."""
    ast, errors = parse('LET f() BE $(1 x := 1 $)1')
    assert not errors


def test_compound_assignment():
    """Compound assignment operators like +:= should parse."""
    ast, errors = parse('LET f() BE x +:= 1')
    assert not errors


def test_sequence_operator():
    """The <> sequence operator should parse."""
    ast, errors = parse('LET f() BE writes("hi") <> newline()')
    assert not errors


def test_multiline_string():
    """Multi-line strings with *\\n* continuation should lex correctly."""
    source = 'LET s = "hello*\n*world"'
    ast, errors = parse(source)
    assert not errors


def test_test_without_then():
    """TEST should work without explicit THEN/DO keyword."""
    ast, errors = parse('LET f() BE TEST x $(  y() $) ELSE z()')
    assert not errors


def test_test_then_if_else():
    """Nested IF inside TEST body should not steal TEST's ELSE."""
    source = """\
LET f() BE
  TEST a THEN
    IF b DO c()
  ELSE
    d()
"""
    ast, errors = parse(source)
    assert not errors
