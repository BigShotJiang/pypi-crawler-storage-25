"""Tests for dependency graph generation."""

import json
from pathlib import Path

from bcpl_lsp.migration.dependency_graph import (
    DependencyGraph,
    build_file_graph,
    build_section_graph,
)
from bcpl_lsp.workspace.get_resolver import GetResolver
from bcpl_lsp.workspace.indexer import WorkspaceIndex


def _make_index(tmp_path: Path, files: dict[str, str]) -> WorkspaceIndex:
    for name, content in files.items():
        (tmp_path / name).write_text(content)
    index = WorkspaceIndex(tmp_path)
    index.discover()
    return index


def test_dot_export():
    g = DependencyGraph(label="test")
    g.add_edge("a", "b")
    g.add_edge("a", "c")
    dot = g.to_dot()
    assert 'digraph "test"' in dot
    assert '"a" -> "b"' in dot
    assert '"a" -> "c"' in dot


def test_json_export():
    g = DependencyGraph(label="test")
    g.add_edge("a", "b")
    data = json.loads(g.to_json())
    assert data["label"] == "test"
    assert "a" in data["nodes"]
    assert "b" in data["nodes"]
    assert {"from": "a", "to": "b"} in data["edges"]


def test_file_graph_from_get(tmp_path):
    index = _make_index(tmp_path, {
        "main.b": 'GET "lib.b"\nLET start() BE RETURN',
        "lib.b": "MANIFEST $(\n  x = 1\n$)",
    })
    resolver = GetResolver()
    graph = build_file_graph(index, resolver)
    assert len(graph.edges) == 1
    src, tgt = graph.edges[0]
    assert "main.b" in src
    assert "lib.b" in tgt


def test_section_graph(tmp_path):
    index = _make_index(tmp_path, {
        "main.b": (
            'SECTION "main"\n'
            "GLOBAL $(\n  start : 1\n$)\n"
            "LET start() BE RETURN"
        ),
        "lib.b": (
            'SECTION "lib"\n'
            "GLOBAL $(\n  helper : 1\n$)\n"
            "LET helper() BE RETURN"
        ),
    })
    graph = build_section_graph(index)
    # Both sections define slot 1, so they share a dependency
    assert "main" in graph.nodes
    assert "lib" in graph.nodes


def test_empty_workspace(tmp_path):
    index = _make_index(tmp_path, {})
    resolver = GetResolver()
    graph = build_file_graph(index, resolver)
    assert len(graph.nodes) == 0
    assert len(graph.edges) == 0
