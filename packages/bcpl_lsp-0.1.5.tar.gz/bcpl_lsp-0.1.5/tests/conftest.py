"""Shared test fixtures."""

from pathlib import Path

import pytest

FIXTURES_DIR = Path(__file__).parent / "fixtures"


@pytest.fixture
def hello_source() -> str:
    return (FIXTURES_DIR / "hello.b").read_text()


@pytest.fixture
def functions_source() -> str:
    return (FIXTURES_DIR / "functions.b").read_text()


@pytest.fixture
def globals_source() -> str:
    return (FIXTURES_DIR / "globals.b").read_text()


@pytest.fixture
def errors_source() -> str:
    return (FIXTURES_DIR / "errors.b").read_text()


@pytest.fixture
def tripos_libhdr_source() -> str:
    return (FIXTURES_DIR / "tripos_libhdr.b").read_text()


@pytest.fixture
def tripos_cg_intcode_source() -> str:
    return (FIXTURES_DIR / "tripos_cg_intcode.b").read_text()


@pytest.fixture
def tripos_cli_init_source() -> str:
    return (FIXTURES_DIR / "tripos_cli_init.b").read_text()
