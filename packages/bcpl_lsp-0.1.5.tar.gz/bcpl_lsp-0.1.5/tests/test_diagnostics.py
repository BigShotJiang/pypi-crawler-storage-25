"""Tests for semantic diagnostics."""

from bcpl_lsp.analysis.diagnostics import Severity, semantic_diagnostics
from bcpl_lsp.analysis.references import Reference, ReferenceContext
from bcpl_lsp.analysis.scope_resolver import ResolvedFile, ResolvedReference
from bcpl_lsp.analysis.symbols import Symbol, SymbolKind
from bcpl_lsp.parser.ast_nodes import Range


def _range(line: int = 0, col: int = 0) -> Range:
    return Range(line, col, line, col + 5)


def test_unresolved_symbol_produces_warning():
    ref = Reference(name="unknown", range=_range(1, 0), uri="test.b", context=ReferenceContext.OTHER)
    resolved = ResolvedFile(path="test.b", symbols=[], resolved_refs=[], unresolved_refs=[ref])

    diags = semantic_diagnostics(resolved, [])

    warnings = [d for d in diags if d.severity == Severity.WARNING]
    assert len(warnings) == 1
    assert "unknown" in warnings[0].message


def test_duplicate_global_slot_produces_warning():
    r = _range()
    sym_a = Symbol(name="foo", kind=SymbolKind.GLOBAL, range=r, global_number=100, uri="a.b")
    sym_b = Symbol(name="bar", kind=SymbolKind.GLOBAL, range=r, global_number=100, uri="b.b")
    # Duplicates are now checked within file symbols, not across workspace
    resolved = ResolvedFile(path="test.b", symbols=[sym_a, sym_b], resolved_refs=[], unresolved_refs=[])

    diags = semantic_diagnostics(resolved, [sym_a, sym_b])

    warnings = [d for d in diags if d.severity == Severity.WARNING and "Duplicate" in d.message]
    assert len(warnings) == 1
    assert "100" in warnings[0].message
    assert "foo" in warnings[0].message


def test_no_duplicate_warning_for_different_slots():
    r = _range()
    sym_a = Symbol(name="foo", kind=SymbolKind.GLOBAL, range=r, global_number=100, uri="a.b")
    sym_b = Symbol(name="bar", kind=SymbolKind.GLOBAL, range=r, global_number=101, uri="b.b")
    resolved = ResolvedFile(path="test.b", symbols=[sym_a, sym_b], resolved_refs=[], unresolved_refs=[])

    diags = semantic_diagnostics(resolved, [sym_a, sym_b])

    dup_warnings = [d for d in diags if "Duplicate" in d.message]
    assert len(dup_warnings) == 0


def test_no_duplicate_warning_for_same_name():
    """Same slot + same name (e.g. multiple libhdr copies) is harmless."""
    r = _range()
    sym_a = Symbol(name="stop", kind=SymbolKind.GLOBAL, range=r, global_number=2, uri="a.b")
    sym_b = Symbol(name="stop", kind=SymbolKind.GLOBAL, range=r, global_number=2, uri="b.b")
    resolved = ResolvedFile(path="test.b", symbols=[sym_a, sym_b], resolved_refs=[], unresolved_refs=[])

    diags = semantic_diagnostics(resolved, [sym_a, sym_b])

    dup_warnings = [d for d in diags if "Duplicate" in d.message]
    assert len(dup_warnings) == 0


def test_unused_local_variable_produces_hint():
    r = _range()
    unused_sym = Symbol(name="x", kind=SymbolKind.VARIABLE, range=r, uri="test.b")
    resolved = ResolvedFile(path="test.b", symbols=[unused_sym], resolved_refs=[], unresolved_refs=[])

    diags = semantic_diagnostics(resolved, [])

    hints = [d for d in diags if d.severity == Severity.HINT]
    assert len(hints) == 1
    assert "x" in hints[0].message


def test_used_local_variable_no_hint():
    r = _range()
    sym = Symbol(name="x", kind=SymbolKind.VARIABLE, range=r, uri="test.b")
    ref = Reference(name="x", range=_range(2, 0), uri="test.b", context=ReferenceContext.OTHER)
    rr = ResolvedReference(reference=ref, symbol=sym)
    resolved = ResolvedFile(path="test.b", symbols=[sym], resolved_refs=[rr], unresolved_refs=[])

    diags = semantic_diagnostics(resolved, [])

    hints = [d for d in diags if d.severity == Severity.HINT]
    assert len(hints) == 0


def test_missing_get_suggestion_produces_info():
    r = _range()
    # Symbol available in a header file
    header_sym = Symbol(name="writef", kind=SymbolKind.GLOBAL, range=r, uri="libhdr.b")
    # Unresolved reference in the current file
    ref = Reference(name="writef", range=_range(3, 0), uri="test.b", context=ReferenceContext.CALL)
    resolved = ResolvedFile(path="test.b", symbols=[], resolved_refs=[], unresolved_refs=[ref])

    diags = semantic_diagnostics(resolved, [header_sym])

    infos = [d for d in diags if d.severity == Severity.INFO]
    assert len(infos) == 1
    assert "writef" in infos[0].message
    assert "libhdr.b" in infos[0].message


def test_no_info_when_symbol_in_same_file():
    r = _range()
    # Symbol is in the same file as the reference — should not suggest GET
    same_file_sym = Symbol(name="helper", kind=SymbolKind.FUNCTION, range=r, uri="test.b")
    ref = Reference(name="helper", range=_range(5, 0), uri="test.b", context=ReferenceContext.CALL)
    resolved = ResolvedFile(path="test.b", symbols=[], resolved_refs=[], unresolved_refs=[ref])

    diags = semantic_diagnostics(resolved, [same_file_sym])

    infos = [d for d in diags if d.severity == Severity.INFO]
    assert len(infos) == 0
