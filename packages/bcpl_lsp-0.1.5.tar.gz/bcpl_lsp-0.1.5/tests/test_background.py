"""Tests for reverse dependency map, invalidate_chain, and BackgroundIndexer."""

from __future__ import annotations

import time
from pathlib import Path

from bcpl_lsp.workspace.background import BackgroundIndexer
from bcpl_lsp.workspace.indexer import WorkspaceIndex


def _write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


class TestReverseDependencyMap:
    """Tests for the reverse dependency map built during discover()."""

    def test_single_get(self, tmp_path: Path) -> None:
        _write(tmp_path / "lib.b", "LET helper() = 1\n")
        _write(tmp_path / "main.b", 'GET "lib.b"\nLET start() = helper()\n')

        idx = WorkspaceIndex(tmp_path)
        idx.discover()

        deps = idx.dependents(str(tmp_path / "lib.b"))
        assert str(tmp_path / "main.b") in deps

    def test_no_dependents(self, tmp_path: Path) -> None:
        _write(tmp_path / "standalone.b", "LET start() = 1\n")

        idx = WorkspaceIndex(tmp_path)
        idx.discover()

        deps = idx.dependents(str(tmp_path / "standalone.b"))
        assert deps == []

    def test_transitive_dependents(self, tmp_path: Path) -> None:
        _write(tmp_path / "base.b", "LET base() = 1\n")
        _write(tmp_path / "mid.b", 'GET "base.b"\nLET mid() = base()\n')
        _write(tmp_path / "top.b", 'GET "mid.b"\nLET top() = mid()\n')

        idx = WorkspaceIndex(tmp_path)
        idx.discover()

        deps = idx.dependents(str(tmp_path / "base.b"))
        dep_set = set(deps)
        assert str(tmp_path / "mid.b") in dep_set
        assert str(tmp_path / "top.b") in dep_set

    def test_multiple_files_get_same_target(self, tmp_path: Path) -> None:
        _write(tmp_path / "shared.b", "LET shared() = 1\n")
        _write(tmp_path / "a.b", 'GET "shared.b"\nLET a() = shared()\n')
        _write(tmp_path / "b.b", 'GET "shared.b"\nLET b() = shared()\n')

        idx = WorkspaceIndex(tmp_path)
        idx.discover()

        deps = idx.dependents(str(tmp_path / "shared.b"))
        dep_set = set(deps)
        assert str(tmp_path / "a.b") in dep_set
        assert str(tmp_path / "b.b") in dep_set


class TestInvalidateChain:
    """Tests for invalidate_chain propagation."""

    def test_invalidates_file_and_dependents(self, tmp_path: Path) -> None:
        _write(tmp_path / "lib.b", "LET helper() = 1\n")
        _write(tmp_path / "main.b", 'GET "lib.b"\nLET start() = helper()\n')

        idx = WorkspaceIndex(tmp_path)
        idx.discover()

        # Parse both files
        idx.ensure_parsed(str(tmp_path / "lib.b"))
        idx.ensure_parsed(str(tmp_path / "main.b"))

        assert idx.get_state(str(tmp_path / "lib.b")) is not None
        assert idx.get_state(str(tmp_path / "main.b")) is not None

        # Invalidate lib.b — should also invalidate main.b
        idx.invalidate_chain(str(tmp_path / "lib.b"))

        assert idx.get_state(str(tmp_path / "lib.b")) is None
        assert idx.get_state(str(tmp_path / "main.b")) is None

    def test_invalidate_chain_transitive(self, tmp_path: Path) -> None:
        _write(tmp_path / "base.b", "LET base() = 1\n")
        _write(tmp_path / "mid.b", 'GET "base.b"\nLET mid() = base()\n')
        _write(tmp_path / "top.b", 'GET "mid.b"\nLET top() = mid()\n')

        idx = WorkspaceIndex(tmp_path)
        idx.discover()

        for name in ("base.b", "mid.b", "top.b"):
            idx.ensure_parsed(str(tmp_path / name))

        idx.invalidate_chain(str(tmp_path / "base.b"))

        for name in ("base.b", "mid.b", "top.b"):
            assert idx.get_state(str(tmp_path / name)) is None

    def test_invalidate_leaf_does_not_affect_others(self, tmp_path: Path) -> None:
        _write(tmp_path / "lib.b", "LET helper() = 1\n")
        _write(tmp_path / "main.b", 'GET "lib.b"\nLET start() = helper()\n')

        idx = WorkspaceIndex(tmp_path)
        idx.discover()

        idx.ensure_parsed(str(tmp_path / "lib.b"))
        idx.ensure_parsed(str(tmp_path / "main.b"))

        # Invalidating main.b (leaf) should not affect lib.b
        idx.invalidate_chain(str(tmp_path / "main.b"))

        assert idx.get_state(str(tmp_path / "main.b")) is None
        assert idx.get_state(str(tmp_path / "lib.b")) is not None


class TestBackgroundIndexer:
    """Tests for the BackgroundIndexer."""

    def test_processes_files(self, tmp_path: Path) -> None:
        _write(tmp_path / "a.b", "LET a() = 1\n")
        _write(tmp_path / "b.b", "LET b() = 2\n")

        idx = WorkspaceIndex(tmp_path)
        idx.discover()

        assert idx.get_state(str(tmp_path / "a.b")) is None
        assert idx.get_state(str(tmp_path / "b.b")) is None

        bg = BackgroundIndexer(idx)
        bg.start()

        # Wait for background indexing to complete
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            a = idx.get_state(str(tmp_path / "a.b"))
            b = idx.get_state(str(tmp_path / "b.b"))
            if a is not None and b is not None:
                break
            time.sleep(0.05)

        bg.stop()

        assert idx.get_state(str(tmp_path / "a.b")) is not None
        assert idx.get_state(str(tmp_path / "b.b")) is not None

    def test_prioritize(self, tmp_path: Path) -> None:
        # Create several files
        for i in range(5):
            _write(tmp_path / f"file{i}.b", f"LET f{i}() = {i}\n")

        idx = WorkspaceIndex(tmp_path)
        idx.discover()

        bg = BackgroundIndexer(idx)
        # Prioritize file3 before starting
        bg.prioritize(str(tmp_path / "file3.b"))
        bg.start()

        # Wait for prioritized file to be indexed
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            if idx.get_state(str(tmp_path / "file3.b")) is not None:
                break
            time.sleep(0.05)

        bg.stop()

        assert idx.get_state(str(tmp_path / "file3.b")) is not None

    def test_stop_is_safe(self, tmp_path: Path) -> None:
        idx = WorkspaceIndex(tmp_path)
        bg = BackgroundIndexer(idx)
        bg.start()
        bg.stop()
        # Double stop should not raise
        bg.stop()
