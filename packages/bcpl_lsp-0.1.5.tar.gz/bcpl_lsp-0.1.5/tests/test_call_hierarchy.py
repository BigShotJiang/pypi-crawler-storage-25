"""Tests for LSP call hierarchy feature."""

from __future__ import annotations

from pathlib import Path

from lsprotocol import types

from bcpl_lsp.analysis.call_graph import CallGraph
from bcpl_lsp.analysis.scope_resolver import ScopeResolver
from bcpl_lsp.analysis.symbols import Symbol, SymbolKind, SymbolTableBuilder
from bcpl_lsp.features.call_hierarchy import _find_symbol_by_name, _symbol_to_call_item
from bcpl_lsp.parser.ast_nodes import Range
from bcpl_lsp.parser.lexer import Lexer
from bcpl_lsp.parser.parser import Parser
from bcpl_lsp.workspace.document import DocumentState


def make_state(source: str, uri: str = "") -> DocumentState:
    tokens = Lexer(source).tokenize()
    ast = Parser(tokens).parse()
    builder = SymbolTableBuilder(uri=uri)
    builder.build(ast)
    return DocumentState(
        uri=uri, source=source, tokens=tokens, ast=ast,
        symbols=builder.all_symbols, diagnostics=[],
    )


class SimpleIndex:
    def __init__(self, states: dict[str, DocumentState]) -> None:
        self._states = states

    def ensure_parsed(self, path: str, source: str | None = None) -> DocumentState:
        return self._states[path]

    def files(self) -> list[str]:
        return list(self._states.keys())


class SimpleGetResolver:
    def __init__(self, chains: dict[str, list[str]] | None = None) -> None:
        self._chains = chains or {}

    def resolve_chain(self, file_path: Path) -> list[Path]:
        key = str(file_path)
        return [Path(p) for p in self._chains.get(key, [key])]


def test_symbol_to_call_item():
    sym = Symbol(
        name="start", kind=SymbolKind.FUNCTION,
        range=Range(0, 4, 0, 9), uri="/test.b",
    )
    item = _symbol_to_call_item(sym)
    assert item.name == "start"
    assert item.kind == types.SymbolKind.Function
    assert item.uri == "file:///test.b"
    assert item.range.start.line == 0
    assert item.range.start.character == 4


def test_symbol_to_call_item_preserves_file_uri():
    sym = Symbol(
        name="f", kind=SymbolKind.FUNCTION,
        range=Range(0, 0, 0, 1), uri="file:///already/uri.b",
    )
    item = _symbol_to_call_item(sym)
    assert item.uri == "file:///already/uri.b"


def test_symbol_to_call_item_global_kind():
    sym = Symbol(
        name="g", kind=SymbolKind.GLOBAL,
        range=Range(0, 0, 0, 1), uri="/test.b",
    )
    item = _symbol_to_call_item(sym)
    assert item.kind == types.SymbolKind.Variable


def test_find_symbol_by_name():
    source = "LET start() BE f()\nAND f() = 42"
    state = make_state(source, uri="/test.b")
    index = SimpleIndex({"/test.b": state})
    resolver = SimpleGetResolver({"/test.b": ["/test.b"]})
    scope = ScopeResolver(index=index, resolver=resolver)

    sym = _find_symbol_by_name("f", scope, index)
    assert sym is not None
    assert sym.name == "f"
    assert sym.kind in (SymbolKind.FUNCTION, SymbolKind.VARIABLE)


def test_find_symbol_by_name_not_found():
    source = "LET start() = 42"
    state = make_state(source, uri="/test.b")
    index = SimpleIndex({"/test.b": state})
    resolver = SimpleGetResolver({"/test.b": ["/test.b"]})
    scope = ScopeResolver(index=index, resolver=resolver)

    sym = _find_symbol_by_name("nonexistent", scope, index)
    assert sym is None


def test_call_hierarchy_integration():
    """Integration test: build call graph and verify hierarchy data."""
    source = "LET start() BE f()\nAND f() BE g()\nAND g() = 42"
    state = make_state(source, uri="/test.b")
    index = SimpleIndex({"/test.b": state})
    resolver = SimpleGetResolver({"/test.b": ["/test.b"]})
    scope = ScopeResolver(index=index, resolver=resolver)

    graph = CallGraph(scope, index)

    # f is called by start, and f calls g
    callers = graph.callers_of("f")
    assert len(callers) == 1
    assert callers[0].caller_name == "start"

    callees = graph.callees_of("f")
    assert len(callees) == 1
    assert callees[0].callee_name == "g"

    # g is called by f
    callers_g = graph.callers_of("g")
    assert len(callers_g) == 1
    assert callers_g[0].caller_name == "f"
