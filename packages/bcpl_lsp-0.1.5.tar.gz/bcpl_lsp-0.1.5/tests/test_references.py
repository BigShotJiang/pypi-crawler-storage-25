"""Tests for reference collection and scope resolution."""

from __future__ import annotations

from pathlib import Path

from bcpl_lsp.analysis.references import ReferenceCollector, ReferenceContext
from bcpl_lsp.analysis.scope_resolver import ScopeResolver
from bcpl_lsp.analysis.symbols import SymbolTableBuilder
from bcpl_lsp.parser.lexer import Lexer
from bcpl_lsp.parser.parser import Parser
from bcpl_lsp.workspace.document import DocumentState


def parse(source: str):
    tokens = Lexer(source).tokenize()
    parser = Parser(tokens)
    return parser.parse()


# ---------------------------------------------------------------------------
# ReferenceCollector tests
# ---------------------------------------------------------------------------


def test_collect_finds_ident_refs():
    ast = parse("LET start() = x + y")
    collector = ReferenceCollector(uri="test.b")
    refs = collector.collect(ast)
    names = {r.name for r in refs}
    assert "x" in names
    assert "y" in names


def test_collect_call_context():
    ast = parse("LET start() BE f(x)")
    collector = ReferenceCollector(uri="test.b")
    refs = collector.collect(ast)
    f_refs = [r for r in refs if r.name == "f"]
    assert len(f_refs) == 1
    assert f_refs[0].context == ReferenceContext.CALL


def test_collect_argument_context():
    ast = parse("LET start() BE f(x)")
    collector = ReferenceCollector(uri="test.b")
    refs = collector.collect(ast)
    x_refs = [r for r in refs if r.name == "x"]
    assert len(x_refs) == 1
    assert x_refs[0].context == ReferenceContext.ARGUMENT


def test_collect_assignment_target_context():
    ast = parse("LET start() BE x := 1")
    collector = ReferenceCollector(uri="test.b")
    refs = collector.collect(ast)
    x_refs = [r for r in refs if r.name == "x"]
    assert len(x_refs) == 1
    assert x_refs[0].context == ReferenceContext.ASSIGNMENT_TARGET


def test_collect_assignment_source_context():
    ast = parse("LET start() BE x := y")
    collector = ReferenceCollector(uri="test.b")
    refs = collector.collect(ast)
    y_refs = [r for r in refs if r.name == "y"]
    assert len(y_refs) == 1
    assert y_refs[0].context == ReferenceContext.ASSIGNMENT_SOURCE


def test_collect_index_base_context():
    ast = parse("LET start() = v!0")
    collector = ReferenceCollector(uri="test.b")
    refs = collector.collect(ast)
    v_refs = [r for r in refs if r.name == "v"]
    assert len(v_refs) == 1
    assert v_refs[0].context == ReferenceContext.INDEX_BASE


def test_collect_index_offset_context():
    ast = parse("LET start() = v!i")
    collector = ReferenceCollector(uri="test.b")
    refs = collector.collect(ast)
    i_refs = [r for r in refs if r.name == "i"]
    assert len(i_refs) == 1
    assert i_refs[0].context == ReferenceContext.INDEX_OFFSET


def test_collect_field_access_context():
    ast = parse("LET start() = x%y")
    collector = ReferenceCollector(uri="test.b")
    refs = collector.collect(ast)
    x_refs = [r for r in refs if r.name == "x"]
    y_refs = [r for r in refs if r.name == "y"]
    assert len(x_refs) == 1
    assert x_refs[0].context == ReferenceContext.FIELD_ACCESS
    assert len(y_refs) == 1
    assert y_refs[0].context == ReferenceContext.FIELD_ACCESS


def test_collect_call_targets():
    ast = parse("LET start() BE $( f(x)\n g(y) $)")
    collector = ReferenceCollector(uri="test.b")
    targets = collector.collect_call_targets(ast)
    names = {r.name for r in targets}
    assert names == {"f", "g"}
    for t in targets:
        assert t.context == ReferenceContext.CALL


def test_collect_uri_propagated():
    ast = parse("LET start() = x")
    collector = ReferenceCollector(uri="file:///tmp/test.b")
    refs = collector.collect(ast)
    assert all(r.uri == "file:///tmp/test.b" for r in refs)


# ---------------------------------------------------------------------------
# ScopeResolver tests
# ---------------------------------------------------------------------------


class MockDocumentState:
    """Minimal mock for WorkspaceIndex returns."""
    pass


class SimpleIndex:
    """Mock WorkspaceIndex that holds pre-parsed document states."""

    def __init__(self, states: dict[str, DocumentState]) -> None:
        self._states = states

    def ensure_parsed(self, path: str, source: str | None = None) -> DocumentState:
        return self._states[path]

    def dependents(self, path: str) -> list[str]:
        return []


class SimpleGetResolver:
    """Mock GetResolver that returns a fixed chain."""

    def __init__(self, chains: dict[str, list[str]] | None = None) -> None:
        self._chains = chains or {}

    def resolve_chain(self, file_path: Path) -> list[Path]:
        key = str(file_path)
        paths = self._chains.get(key, [key])
        return [Path(p) for p in paths]


def make_state(source: str, uri: str = "") -> DocumentState:
    """Parse source into a DocumentState."""
    tokens = Lexer(source).tokenize()
    parser = Parser(tokens)
    ast = parser.parse()
    builder = SymbolTableBuilder(uri=uri)
    builder.build(ast)
    return DocumentState(
        uri=uri,
        source=source,
        tokens=tokens,
        ast=ast,
        symbols=builder.all_symbols,
        diagnostics=[],
    )


def test_scope_resolver_local_symbols():
    source = "LET start() BE f(x)\nAND f(n) = n + 1"
    state = make_state(source, uri="/test.b")
    index = SimpleIndex({"/test.b": state})
    resolver = SimpleGetResolver({"/test.b": ["/test.b"]})
    scope_resolver = ScopeResolver(index=index, resolver=resolver)

    result = scope_resolver.resolve("/test.b")
    resolved_names = {rr.reference.name for rr in result.resolved_refs}
    # 'f' is called inside start(), so it should be resolved
    # 'n' is a param of f and used in f's body
    assert "f" in resolved_names
    assert "n" in resolved_names


def test_scope_resolver_cross_file_globals():
    # File A defines a GLOBAL
    source_a = "GLOBAL $(\n  count : 200\n$)"
    state_a = make_state(source_a, uri="/a.b")

    # File B uses that global
    source_b = "LET start() BE count := 0"
    state_b = make_state(source_b, uri="/b.b")

    index = SimpleIndex({"/a.b": state_a, "/b.b": state_b})
    resolver = SimpleGetResolver({"/b.b": ["/b.b", "/a.b"]})
    scope_resolver = ScopeResolver(index=index, resolver=resolver)

    result = scope_resolver.resolve("/b.b")
    resolved_names = {rr.reference.name for rr in result.resolved_refs}
    assert "count" in resolved_names


def test_scope_resolver_cross_file_manifest():
    source_a = "MANIFEST $(\n  bufsize = 256\n$)"
    state_a = make_state(source_a, uri="/a.b")

    source_b = "LET start() = bufsize"
    state_b = make_state(source_b, uri="/b.b")

    index = SimpleIndex({"/a.b": state_a, "/b.b": state_b})
    resolver = SimpleGetResolver({"/b.b": ["/b.b", "/a.b"]})
    scope_resolver = ScopeResolver(index=index, resolver=resolver)

    result = scope_resolver.resolve("/b.b")
    resolved_names = {rr.reference.name for rr in result.resolved_refs}
    assert "bufsize" in resolved_names


def test_scope_resolver_unresolved():
    source = "LET start() BE unknown()"
    state = make_state(source, uri="/test.b")
    index = SimpleIndex({"/test.b": state})
    resolver = SimpleGetResolver({"/test.b": ["/test.b"]})
    scope_resolver = ScopeResolver(index=index, resolver=resolver)

    result = scope_resolver.resolve("/test.b")
    unresolved_names = {r.name for r in result.unresolved_refs}
    assert "unknown" in unresolved_names


def test_scope_resolver_caching():
    source = "LET start() = x"
    state = make_state(source, uri="/test.b")
    index = SimpleIndex({"/test.b": state})
    resolver = SimpleGetResolver({"/test.b": ["/test.b"]})
    scope_resolver = ScopeResolver(index=index, resolver=resolver)

    result1 = scope_resolver.resolve("/test.b")
    result2 = scope_resolver.resolve("/test.b")
    assert result1 is result2  # Same object from cache


def test_scope_resolver_invalidate():
    source = "LET start() = x"
    state = make_state(source, uri="/test.b")
    index = SimpleIndex({"/test.b": state})
    resolver = SimpleGetResolver({"/test.b": ["/test.b"]})
    scope_resolver = ScopeResolver(index=index, resolver=resolver)

    result1 = scope_resolver.resolve("/test.b")
    scope_resolver.invalidate("/test.b")
    result2 = scope_resolver.resolve("/test.b")
    assert result1 is not result2  # Fresh resolve after invalidate


def test_scope_resolver_resolve_at():
    source = "LET start() BE f(x)"
    state = make_state(source, uri="/test.b")
    index = SimpleIndex({"/test.b": state})
    resolver = SimpleGetResolver({"/test.b": ["/test.b"]})
    scope_resolver = ScopeResolver(index=index, resolver=resolver)

    # 'f' and 'x' are unresolved (not defined in this file)
    # Let's check resolve_at finds them
    result = scope_resolver.resolve("/test.b")
    if result.unresolved_refs:
        ref = result.unresolved_refs[0]
        rr = scope_resolver.resolve_at("/test.b", ref.range.start_line, ref.range.start_col)
        assert rr is not None
        assert rr.reference.name == ref.name
