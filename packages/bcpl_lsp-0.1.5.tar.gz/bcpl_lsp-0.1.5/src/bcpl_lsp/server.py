"""BCPL Language Server — main entry point."""

from __future__ import annotations
import logging

from pathlib import Path

from lsprotocol import types
from pygls.lsp.server import LanguageServer


from bcpl_lsp.analysis.diagnostics import Severity, semantic_diagnostics
from bcpl_lsp.analysis.scope_resolver import ScopeResolver
from bcpl_lsp.features.call_hierarchy import (
    invalidate_call_graph,
    register as register_call_hierarchy,
)
from bcpl_lsp.features.completion import get_completions
from bcpl_lsp.features.definition import register as register_definition
from bcpl_lsp.features.document_symbol import get_document_symbols
from bcpl_lsp.features.hover import register as register_hover
from bcpl_lsp.features.references import register as register_references
from bcpl_lsp.features.rename import register as register_rename
from bcpl_lsp.features.semantic_tokens import register as register_semantic_tokens
from bcpl_lsp.features.workspace_symbol import register as register_workspace_symbol
from bcpl_lsp.workspace.background import BackgroundIndexer
from bcpl_lsp.workspace.document import DocumentState, analyze_document
from bcpl_lsp.workspace.get_resolver import GetResolver
from bcpl_lsp.workspace.indexer import WorkspaceIndex

log = logging.getLogger("bcpl-lsp")

server = LanguageServer(
    name="bcpl-lsp",
    version="0.1.5",
    text_document_sync_kind=types.TextDocumentSyncKind.Full,
)

# Per-document analysis cache
_doc_states: dict[str, DocumentState] = {}

# Workspace-wide state (initialized on workspace/initialized)
_workspace_index: WorkspaceIndex | None = None
_get_resolver: GetResolver | None = None
_scope_resolver: ScopeResolver | None = None
_background_indexer: BackgroundIndexer | None = None

SEVERITY_MAP = {
    Severity.ERROR: types.DiagnosticSeverity.Error,
    Severity.WARNING: types.DiagnosticSeverity.Warning,
    Severity.INFO: types.DiagnosticSeverity.Information,
    Severity.HINT: types.DiagnosticSeverity.Hint,
}


@server.feature(types.INITIALIZED)
def initialized(ls: LanguageServer, params: types.InitializedParams) -> None:
    """Set up workspace index, GET resolver, and scope resolver."""
    global _workspace_index, _get_resolver, _scope_resolver, _background_indexer

    workspace_folders = ls.workspace.folders
    if workspace_folders:
        root = Path(list(workspace_folders.values())[0].uri.removeprefix("file://"))
    else:
        root = Path.cwd()

    log.info("Initializing workspace at %s", root)

    _workspace_index = WorkspaceIndex(root)
    files = _workspace_index.discover()
    log.info("Discovered %d BCPL files", len(files))

    # Default search paths: g/ subdirectory (TRIPOS headers convention)
    search_paths = []
    g_dir = root / "g"
    if g_dir.is_dir():
        search_paths.append(g_dir)
        log.info("Added search path: %s", g_dir)
    _get_resolver = GetResolver(search_paths=search_paths)
    _scope_resolver = ScopeResolver(_workspace_index, _get_resolver)
    log.info("Scope resolver ready")

    # Start background indexing
    _background_indexer = BackgroundIndexer(_workspace_index)
    _background_indexer.start()
    log.info("Background indexer started")


def _analyze_and_publish(ls: LanguageServer, uri: str, source: str) -> None:
    """Analyze a document and publish diagnostics."""
    file_name = uri.rsplit("/", 1)[-1]
    log.debug("Analyzing %s", file_name)
    state = analyze_document(uri, source)
    _doc_states[uri] = state

    # Keep workspace index in sync
    file_path = uri.removeprefix("file://")
    if _workspace_index is not None:
        _workspace_index.update(file_path, source)
        _workspace_index.invalidate_chain(file_path)
    if _scope_resolver is not None:
        _scope_resolver.invalidate(file_path)
    invalidate_call_graph()

    # Collect semantic diagnostics if scope resolver is available
    all_diagnostics = list(state.diagnostics)
    if _scope_resolver is not None:
        resolved = _scope_resolver.resolve(file_path)
        all_symbols = []
        if _workspace_index is not None:
            for fp in _workspace_index.files():
                ws = _workspace_index.get_state(fp)
                if ws is not None:
                    all_symbols.extend(ws.symbols)
        all_diagnostics.extend(semantic_diagnostics(resolved, all_symbols))

    log.debug("Published %d diagnostics for %s", len(all_diagnostics), file_name)

    lsp_diagnostics = [
        types.Diagnostic(
            range=types.Range(
                start=types.Position(line=d.line, character=d.column),
                end=types.Position(line=d.end_line, character=d.end_column),
            ),
            message=d.message,
            severity=SEVERITY_MAP.get(d.severity, types.DiagnosticSeverity.Error),
            source="bcpl-lsp",
        )
        for d in all_diagnostics
    ]

    ls.text_document_publish_diagnostics(
        types.PublishDiagnosticsParams(uri=uri, diagnostics=lsp_diagnostics)
    )


@server.feature(types.TEXT_DOCUMENT_DID_OPEN)
def did_open(ls: LanguageServer, params: types.DidOpenTextDocumentParams) -> None:
    log.info("Opened %s", params.text_document.uri.rsplit("/", 1)[-1])
    if _background_indexer is not None:
        file_path = params.text_document.uri.removeprefix("file://")
        _background_indexer.prioritize(file_path)
    _analyze_and_publish(ls, params.text_document.uri, params.text_document.text)


@server.feature(types.TEXT_DOCUMENT_DID_CHANGE)
def did_change(ls: LanguageServer, params: types.DidChangeTextDocumentParams) -> None:
    doc = ls.workspace.get_document(params.text_document.uri)
    _analyze_and_publish(ls, params.text_document.uri, doc.source)


@server.feature(types.TEXT_DOCUMENT_DID_CLOSE)
def did_close(ls: LanguageServer, params: types.DidCloseTextDocumentParams) -> None:
    log.info("Closed %s", params.text_document.uri.rsplit("/", 1)[-1])
    _doc_states.pop(params.text_document.uri, None)


@server.feature(types.WORKSPACE_DID_CHANGE_WATCHED_FILES)
def did_change_watched_files(
    ls: LanguageServer, params: types.DidChangeWatchedFilesParams,
) -> None:
    """Handle external file changes (git checkout, disk edits, etc.)."""
    if _workspace_index is None:
        return

    log.debug("Watched files changed: %d events", len(params.changes))
    for change in params.changes:
        path = change.uri.removeprefix("file://")

        if change.type == types.FileChangeType.Deleted:
            _workspace_index.remove(path)
            _doc_states.pop(change.uri, None)
        elif change.type == types.FileChangeType.Created:
            # Add newly created file and parse it
            try:
                source = Path(path).read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            _workspace_index.update(path, source)
        else:
            # Changed — invalidate and re-parse from disk
            _workspace_index.invalidate_chain(path)
            try:
                source = Path(path).read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            _workspace_index.update(path, source)

        if _scope_resolver is not None:
            _scope_resolver.invalidate(path)

    invalidate_call_graph()


_LOG_LEVEL_MAP = {
    "debug": logging.DEBUG,
    "info": logging.INFO,
    "warning": logging.WARNING,
    "error": logging.ERROR,
}


@server.feature(types.WORKSPACE_DID_CHANGE_CONFIGURATION)
def did_change_configuration(
    ls: LanguageServer, params: types.DidChangeConfigurationParams,
) -> None:
    """Adjust log level when the user changes bcpl.logLevel."""
    settings = params.settings or {}
    bcpl_settings = settings.get("bcpl", {}) if isinstance(settings, dict) else {}
    level_str = bcpl_settings.get("logLevel", "info") if isinstance(bcpl_settings, dict) else "info"
    level = _LOG_LEVEL_MAP.get(level_str, logging.INFO)

    root_logger = logging.getLogger("bcpl-lsp")
    root_logger.setLevel(level)
    # Also set the root logger so all our module loggers inherit
    logging.getLogger().setLevel(level)
    # Only show pygls wire noise in debug mode
    pygls_level = logging.DEBUG if level == logging.DEBUG else logging.WARNING
    logging.getLogger("pygls").setLevel(pygls_level)
    log.info("Log level changed to %s", level_str)


@server.feature(types.SHUTDOWN)
def shutdown(ls: LanguageServer, params: None) -> None:
    log.info("Shutting down")
    if _background_indexer is not None:
        _background_indexer.stop()


@server.feature(
    types.TEXT_DOCUMENT_COMPLETION,
    types.CompletionOptions(trigger_characters=[".", " "]),
)
def completion(ls: LanguageServer, params: types.CompletionParams) -> types.CompletionList:
    log.debug("Completion at %s:%d:%d", params.text_document.uri.rsplit("/", 1)[-1],
             params.position.line, params.position.character)
    state = _doc_states.get(params.text_document.uri)
    symbols = state.symbols if state else []
    return get_completions(symbols)


@server.feature(types.TEXT_DOCUMENT_DOCUMENT_SYMBOL)
def document_symbol(
    ls: LanguageServer, params: types.DocumentSymbolParams
) -> list[types.DocumentSymbol]:
    log.debug("Document symbols for %s", params.text_document.uri.rsplit("/", 1)[-1])
    state = _doc_states.get(params.text_document.uri)
    symbols = state.symbols if state else []
    return get_document_symbols(symbols)


# Register Phase 2 features
register_call_hierarchy(server)
register_definition(server)
register_hover(server)
register_references(server)
register_rename(server)
register_semantic_tokens(server)
register_workspace_symbol(server)


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(name)s: %(message)s")
    # Suppress pygls wire-protocol noise (JSON-RPC dumps) unless debug
    logging.getLogger("pygls").setLevel(logging.WARNING)
    log.info("BCPL LSP server starting")
    server.start_io()


if __name__ == "__main__":
    main()
