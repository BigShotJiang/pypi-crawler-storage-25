"""textDocument/definition handler for BCPL."""

from __future__ import annotations
import logging


from lsprotocol import types
from pygls.lsp.server import LanguageServer


from bcpl_lsp.analysis.scope_resolver import ResolvedReference
from bcpl_lsp.analysis.symbols import Symbol


log = logging.getLogger("bcpl-lsp")

def _symbol_to_location(sym: Symbol) -> types.Location | None:
    """Convert a Symbol to an LSP Location."""
    uri = sym.uri
    if not uri:
        return None
    # Ensure URI has file:// scheme
    if not uri.startswith("file://"):
        uri = f"file://{uri}"
    r = sym.range
    return types.Location(
        uri=uri,
        range=types.Range(
            start=types.Position(line=r.start_line, character=r.start_col),
            end=types.Position(line=r.end_line, character=r.end_col),
        ),
    )


def get_definition(
    resolved: ResolvedReference | None,
) -> types.Location | None:
    """Return the definition Location for a resolved reference, or None."""
    if resolved is None or resolved.symbol is None:
        return None
    return _symbol_to_location(resolved.symbol)


def register(server: LanguageServer) -> None:
    """Register the textDocument/definition handler."""

    @server.feature(types.TEXT_DOCUMENT_DEFINITION)
    def definition(
        ls: LanguageServer, params: types.DefinitionParams
    ) -> types.Location | None:
        from bcpl_lsp.server import _doc_states, _scope_resolver

        uri = params.text_document.uri
        if uri not in _doc_states or _scope_resolver is None:
            return None

        # Convert URI to file path for scope resolver
        path = uri.removeprefix("file://")
        line = params.position.line
        col = params.position.character

        resolved = _scope_resolver.resolve_at(path, line, col)
        result = get_definition(resolved)
        if result:
            log.debug("Definition: %s:%d:%d → %s", uri.rsplit("/", 1)[-1], line, col, result.uri.rsplit("/", 1)[-1])
        else:
            log.debug("Definition: %s:%d:%d → not found", uri.rsplit("/", 1)[-1], line, col)
        return result
