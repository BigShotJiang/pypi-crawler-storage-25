"""textDocument/rename and textDocument/prepareRename handlers for BCPL."""

from __future__ import annotations
import logging


from lsprotocol import types
from pygls.lsp.server import LanguageServer


from bcpl_lsp.analysis.scope_resolver import ScopeResolver
from bcpl_lsp.analysis.symbols import SymbolKind
from bcpl_lsp.parser.ast_nodes import Range as ASTRange
from bcpl_lsp.workspace.indexer import WorkspaceIndex

log = logging.getLogger("bcpl-lsp")

# Symbols that cannot be renamed.
_NON_RENAMEABLE_KINDS = frozenset({SymbolKind.SECTION})


def _ast_range_to_lsp(r: ASTRange) -> types.Range:
    return types.Range(
        start=types.Position(line=r.start_line, character=r.start_col),
        end=types.Position(line=r.end_line, character=r.end_col),
    )


def _ensure_uri(uri: str) -> str:
    if not uri.startswith("file://"):
        return f"file://{uri}"
    return uri


def prepare_rename(
    scope_resolver: ScopeResolver,
    path: str,
    line: int,
    col: int,
) -> types.Range | None:
    """Validate that the symbol at the given position is renameable.

    Returns the range of the symbol if renameable, None otherwise.
    """
    resolved = scope_resolver.resolve_at(path, line, col)
    if resolved is None:
        return None

    # Must resolve to a known symbol
    if resolved.symbol is None:
        return None

    # Sections are not renameable
    if resolved.symbol.kind in _NON_RENAMEABLE_KINDS:
        return None

    return _ast_range_to_lsp(resolved.reference.range)


def compute_rename_edits(
    scope_resolver: ScopeResolver,
    workspace_index: WorkspaceIndex,
    path: str,
    line: int,
    col: int,
    new_name: str,
) -> types.WorkspaceEdit | None:
    """Compute a WorkspaceEdit that renames the symbol at (path, line, col)."""
    resolved = scope_resolver.resolve_at(path, line, col)
    if resolved is None or resolved.symbol is None:
        return None

    target_symbol = resolved.symbol
    if target_symbol.kind in _NON_RENAMEABLE_KINDS:
        return None

    target_name = target_symbol.name

    # Collect all edits across workspace files
    changes: dict[str, list[types.TextEdit]] = {}
    all_files = workspace_index.files()

    for file_path in all_files:
        resolved_file = scope_resolver.resolve(file_path)

        # Check symbol definitions in this file
        for sym in resolved_file.symbols:
            if sym.name == target_name and sym.kind == target_symbol.kind:
                uri = _ensure_uri(file_path)
                changes.setdefault(uri, []).append(
                    types.TextEdit(
                        range=_ast_range_to_lsp(sym.range),
                        new_text=new_name,
                    )
                )

        # Check references that resolve to the same symbol
        for rr in resolved_file.resolved_refs:
            if rr.symbol is not None and rr.symbol.name == target_name and rr.symbol.kind == target_symbol.kind:
                uri = _ensure_uri(file_path)
                changes.setdefault(uri, []).append(
                    types.TextEdit(
                        range=_ast_range_to_lsp(rr.reference.range),
                        new_text=new_name,
                    )
                )

    if not changes:
        return None

    return types.WorkspaceEdit(changes=changes)


def register(server: LanguageServer) -> None:
    """Register rename handlers on the server."""

    @server.feature(types.TEXT_DOCUMENT_PREPARE_RENAME)
    def on_prepare_rename(
        ls: LanguageServer, params: types.PrepareRenameParams
    ) -> types.Range | None:
        from bcpl_lsp.server import _doc_states, _scope_resolver

        uri = params.text_document.uri
        if uri not in _doc_states or _scope_resolver is None:
            return None

        path = uri.removeprefix("file://")
        result = prepare_rename(
            _scope_resolver,
            path,
            params.position.line,
            params.position.character,
        )
        log.debug("PrepareRename: %s:%d:%d → %s", uri.rsplit("/", 1)[-1],
                 params.position.line, params.position.character,
                 "renameable" if result else "not renameable")
        return result

    @server.feature(types.TEXT_DOCUMENT_RENAME)
    def on_rename(
        ls: LanguageServer, params: types.RenameParams
    ) -> types.WorkspaceEdit | None:
        from bcpl_lsp.server import _doc_states, _scope_resolver, _workspace_index

        uri = params.text_document.uri
        if uri not in _doc_states or _scope_resolver is None or _workspace_index is None:
            return None

        path = uri.removeprefix("file://")
        result = compute_rename_edits(
            _scope_resolver,
            _workspace_index,
            path,
            params.position.line,
            params.position.character,
            params.new_name,
        )
        n_files = len(result.changes) if result and result.changes else 0
        log.debug("Rename: %s:%d:%d → '%s' (%d files)", uri.rsplit("/", 1)[-1],
                 params.position.line, params.position.character, params.new_name, n_files)
        return result
