"""textDocument/documentSymbol handler for BCPL."""

from __future__ import annotations

from lsprotocol import types

from bcpl_lsp.analysis.symbols import Symbol, SymbolKind

SYMBOL_KIND_MAP: dict[SymbolKind, types.SymbolKind] = {
    SymbolKind.FUNCTION: types.SymbolKind.Function,
    SymbolKind.VARIABLE: types.SymbolKind.Variable,
    SymbolKind.CONSTANT: types.SymbolKind.Constant,
    SymbolKind.GLOBAL: types.SymbolKind.Variable,
    SymbolKind.STATIC: types.SymbolKind.Variable,
    SymbolKind.PARAMETER: types.SymbolKind.Variable,
    SymbolKind.SECTION: types.SymbolKind.Module,
}


def get_document_symbols(symbols: list[Symbol]) -> list[types.DocumentSymbol]:
    """Convert symbols to LSP DocumentSymbol list."""
    result: list[types.DocumentSymbol] = []

    for sym in symbols:
        # Skip parameters — they clutter the outline
        if sym.kind == SymbolKind.PARAMETER:
            continue

        detail = ""
        if sym.kind == SymbolKind.FUNCTION and sym.params:
            detail = f"({', '.join(sym.params)})"
        elif sym.kind == SymbolKind.GLOBAL and sym.global_number is not None:
            detail = f": {sym.global_number}"

        r = sym.range
        lsp_range = types.Range(
            start=types.Position(line=r.start_line, character=r.start_col),
            end=types.Position(line=r.end_line, character=r.end_col),
        )

        result.append(types.DocumentSymbol(
            name=sym.name,
            kind=SYMBOL_KIND_MAP.get(sym.kind, types.SymbolKind.Variable),
            range=lsp_range,
            selection_range=lsp_range,
            detail=detail,
        ))

    return result
