"""workspace/symbol handler for BCPL."""

from __future__ import annotations
import logging


from lsprotocol import types
from pygls.lsp.server import LanguageServer


from bcpl_lsp.analysis.symbols import SymbolKind
from bcpl_lsp.workspace.indexer import WorkspaceIndex

SYMBOL_KIND_MAP: dict[SymbolKind, types.SymbolKind] = {
    SymbolKind.FUNCTION: types.SymbolKind.Function,
    SymbolKind.VARIABLE: types.SymbolKind.Variable,
    SymbolKind.CONSTANT: types.SymbolKind.Constant,
    SymbolKind.GLOBAL: types.SymbolKind.Variable,
    SymbolKind.STATIC: types.SymbolKind.Variable,
    SymbolKind.PARAMETER: types.SymbolKind.Variable,
    SymbolKind.SECTION: types.SymbolKind.Module,
}


log = logging.getLogger("bcpl-lsp")

def _workspace_symbols(
    workspace_index: WorkspaceIndex,
    query: str,
) -> list[types.SymbolInformation]:
    """Search all indexed symbols matching query substring."""
    query_lower = query.lower()
    results: list[types.SymbolInformation] = []

    for file_path in workspace_index.files():
        state = workspace_index.get_state(file_path)
        if state is None:
            state = workspace_index.ensure_parsed(file_path)

        for sym in state.symbols:
            if sym.kind == SymbolKind.PARAMETER:
                continue
            if query_lower and query_lower not in sym.name.lower():
                continue

            r = sym.range
            uri = sym.uri or f"file://{file_path}"
            if not uri.startswith("file://"):
                uri = f"file://{uri}"

            results.append(types.SymbolInformation(
                name=sym.name,
                kind=SYMBOL_KIND_MAP.get(sym.kind, types.SymbolKind.Variable),
                location=types.Location(
                    uri=uri,
                    range=types.Range(
                        start=types.Position(line=r.start_line, character=r.start_col),
                        end=types.Position(line=r.end_line, character=r.end_col),
                    ),
                ),
            ))

    return results


def register(server: LanguageServer) -> None:
    @server.feature(types.WORKSPACE_SYMBOL)
    def workspace_symbol(
        ls: LanguageServer, params: types.WorkspaceSymbolParams
    ) -> list[types.SymbolInformation]:
        from bcpl_lsp.server import _workspace_index

        if _workspace_index is None:
            return []

        results = _workspace_symbols(_workspace_index, params.query)
        log.debug("Workspace symbols: query='%s' → %d results", params.query, len(results))
        return results
