"""textDocument/semanticTokens/full handler for BCPL."""

from __future__ import annotations
import logging


from lsprotocol import types
from pygls.lsp.server import LanguageServer


from bcpl_lsp.analysis.scope_resolver import ResolvedReference, ScopeResolver
from bcpl_lsp.analysis.symbols import SymbolKind
from bcpl_lsp.parser.tokens import Token, TokenType

log = logging.getLogger("bcpl-lsp")

# --- Legend definition ---

TOKEN_TYPES = [
    "function",
    "variable",
    "parameter",
    "namespace",     # SECTION
    "enumMember",    # MANIFEST constant
    "property",      # GLOBAL
    "keyword",
    "comment",
    "string",
    "number",
]

TOKEN_MODIFIERS = [
    "declaration",
    "definition",
    "readonly",
]

SEMANTIC_TOKENS_LEGEND = types.SemanticTokensLegend(
    token_types=TOKEN_TYPES,
    token_modifiers=TOKEN_MODIFIERS,
)

_TYPE_INDEX = {name: i for i, name in enumerate(TOKEN_TYPES)}
_MOD_INDEX = {name: i for i, name in enumerate(TOKEN_MODIFIERS)}

# Keywords that are token types (not IDENT)
_KEYWORD_TOKEN_TYPES = {tt for tt in TokenType if tt.name in {
    "LET", "BE", "IF", "THEN", "ELSE", "TEST", "FOR", "TO", "BY", "DO",
    "WHILE", "UNTIL", "REPEAT", "REPEATWHILE", "REPEATUNTIL",
    "SWITCHON", "CASE", "DEFAULT", "ENDCASE", "BREAK", "LOOP",
    "RETURN", "RESULTIS", "AND", "OR", "NOT", "TRUE", "FALSE",
    "GLOBAL", "MANIFEST", "STATIC", "GET", "SECTION", "NEEDS",
    "INTO", "OF", "VEC", "TABLE", "VALOF", "EQV", "NEQV",
    "ABS", "REM", "MOD", "UNLESS", "GOTO",
}}

# Map SymbolKind to semantic token type name
_SYMBOL_KIND_TO_TOKEN_TYPE: dict[SymbolKind, str] = {
    SymbolKind.FUNCTION: "function",
    SymbolKind.VARIABLE: "variable",
    SymbolKind.PARAMETER: "parameter",
    SymbolKind.SECTION: "namespace",
    SymbolKind.CONSTANT: "enumMember",
    SymbolKind.GLOBAL: "property",
    SymbolKind.STATIC: "variable",
}


def _modifier_bits(*modifiers: str) -> int:
    bits = 0
    for m in modifiers:
        idx = _MOD_INDEX.get(m)
        if idx is not None:
            bits |= 1 << idx
    return bits


def compute_semantic_tokens(
    tokens: list[Token],
    scope_resolver: ScopeResolver | None,
    path: str,
) -> list[int]:
    """Compute the encoded semantic token data array.

    Processes the token stream and uses resolved symbol information
    to assign accurate semantic types to identifiers.
    """
    # Build a lookup from (line, col) -> resolved reference for identifiers
    ref_lookup: dict[tuple[int, int], ResolvedReference] = {}
    definition_positions: set[tuple[int, int]] = set()

    if scope_resolver is not None:
        resolved_file = scope_resolver.resolve(path)

        for rr in resolved_file.resolved_refs:
            r = rr.reference.range
            ref_lookup[(r.start_line, r.start_col)] = rr

        # Track definition positions from symbols
        for sym in resolved_file.symbols:
            definition_positions.add((sym.range.start_line, sym.range.start_col))

    # Build the encoded data
    raw_tokens: list[tuple[int, int, int, int, int]] = []  # (line, col, len, type, mods)

    for tok in tokens:
        token_type: int | None = None
        modifiers = 0
        length = len(tok.text)

        if tok.type == TokenType.COMMENT:
            token_type = _TYPE_INDEX["comment"]
        elif tok.type == TokenType.STRING or tok.type == TokenType.CHARCONST:
            token_type = _TYPE_INDEX["string"]
        elif tok.type == TokenType.NUMBER:
            token_type = _TYPE_INDEX["number"]
        elif tok.type in _KEYWORD_TOKEN_TYPES:
            token_type = _TYPE_INDEX["keyword"]
        elif tok.type == TokenType.IDENT:
            pos = (tok.line, tok.column)
            rr = ref_lookup.get(pos)
            if rr is not None and rr.symbol is not None:
                kind = rr.symbol.kind
                type_name = _SYMBOL_KIND_TO_TOKEN_TYPE.get(kind, "variable")
                token_type = _TYPE_INDEX[type_name]
                if kind == SymbolKind.CONSTANT:
                    modifiers |= _modifier_bits("readonly")
            elif pos in definition_positions:
                # It's a definition site — check resolved file symbols
                if scope_resolver is not None:
                    resolved_file = scope_resolver.resolve(path)
                    for sym in resolved_file.symbols:
                        if sym.range.start_line == tok.line and sym.range.start_col == tok.column:
                            type_name = _SYMBOL_KIND_TO_TOKEN_TYPE.get(sym.kind, "variable")
                            token_type = _TYPE_INDEX[type_name]
                            modifiers |= _modifier_bits("declaration", "definition")
                            if sym.kind == SymbolKind.CONSTANT:
                                modifiers |= _modifier_bits("readonly")
                            break
            else:
                # Unknown identifier — default to variable
                token_type = _TYPE_INDEX["variable"]

        if token_type is not None:
            raw_tokens.append((tok.line, tok.column, length, token_type, modifiers))

    # Encode as delta format
    data: list[int] = []
    prev_line = 0
    prev_col = 0
    for line, col, length, type_idx, mods in raw_tokens:
        delta_line = line - prev_line
        delta_col = col - prev_col if delta_line == 0 else col
        data.extend([delta_line, delta_col, length, type_idx, mods])
        prev_line = line
        prev_col = col

    return data


def register(server: LanguageServer) -> None:
    """Register semantic tokens handler on the server."""

    @server.feature(
        types.TEXT_DOCUMENT_SEMANTIC_TOKENS_FULL,
        SEMANTIC_TOKENS_LEGEND,
    )
    def semantic_tokens_full(
        ls: LanguageServer, params: types.SemanticTokensParams
    ) -> types.SemanticTokens | None:
        from bcpl_lsp.server import _doc_states, _scope_resolver

        uri = params.text_document.uri
        state = _doc_states.get(uri)
        if state is None:
            return None

        path = uri.removeprefix("file://")
        data = compute_semantic_tokens(state.tokens, _scope_resolver, path)
        log.debug("Semantic tokens: %s → %d data values", uri.rsplit("/", 1)[-1], len(data))
        return types.SemanticTokens(data=data)
