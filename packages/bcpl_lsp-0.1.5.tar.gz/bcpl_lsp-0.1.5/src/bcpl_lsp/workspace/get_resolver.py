"""GET directive resolution for BCPL's include system."""

from __future__ import annotations

from pathlib import Path

from bcpl_lsp.parser.ast_nodes import GetDirective, Node, Section
from bcpl_lsp.parser.lexer import Lexer
from bcpl_lsp.parser.parser import Parser


class GetResolver:
    """Resolves ``GET "filename"`` directives to filesystem paths.

    Search order:
    1. Same directory as the source file.
    2. Each directory in *search_paths* (e.g. the ``g/`` headers directory).

    Matching is case-insensitive.  Extensionless names are tried as-is,
    then with ``.b`` and ``.bcpl`` appended.
    """

    def __init__(self, search_paths: list[Path] | None = None) -> None:
        """
        Parameters
        ----------
        search_paths:
            Ordered list of directories to search after the source directory.
        """
        self._search_paths: list[Path] = list(search_paths or [])

    @property
    def search_paths(self) -> list[Path]:
        return list(self._search_paths)

    def set_search_paths(self, paths: list[Path]) -> None:
        """Replace the current search paths."""
        self._search_paths = list(paths)

    def resolve(self, filename: str, from_file: Path) -> Path | None:
        """Resolve a single GET filename relative to *from_file*.

        Returns the resolved ``Path`` or ``None`` if not found.
        """
        dirs = [from_file.parent] + self._search_paths
        candidates = [filename]
        if "." not in Path(filename).name:
            candidates.append(filename + ".b")
            candidates.append(filename + ".bcpl")

        for search_dir in dirs:
            if not search_dir.is_dir():
                continue
            for candidate in candidates:
                match = self._find_case_insensitive(search_dir, candidate)
                if match is not None:
                    return match
        return None

    @staticmethod
    def _find_case_insensitive(base: Path, name: str) -> Path | None:
        """Walk path components case-insensitively from *base*."""
        parts = Path(name).parts
        current = base
        for part in parts:
            if not current.is_dir():
                return None
            try:
                children = {c.name.lower(): c for c in current.iterdir()}
            except OSError:
                return None
            match = children.get(part.lower())
            if match is None:
                return None
            current = match
        if current.is_file():
            return current
        return None

    def resolve_chain(self, file_path: Path) -> list[Path]:
        """Return the ordered list of all files transitively included by *file_path*.

        The result includes *file_path* itself as the first element.
        Circular GET chains are detected and broken (the cycle-closing
        file is not included a second time).
        """
        result: list[Path] = []
        seen: set[Path] = set()

        def _walk(fp: Path) -> None:
            resolved = fp.resolve()
            if resolved in seen:
                return
            seen.add(resolved)
            result.append(fp)

            try:
                source = fp.read_text(encoding="utf-8", errors="replace")
            except OSError:
                return

            lexer = Lexer(source)
            tokens = lexer.tokenize()
            parser = Parser(tokens)
            ast = parser.parse()

            _collect_gets(ast.declarations, fp)

        def _collect_gets(nodes: list[Node], fp: Path) -> None:
            for node in nodes:
                if isinstance(node, GetDirective) and node.filename:
                    target = self.resolve(node.filename, fp)
                    if target is not None:
                        _walk(target)
                elif isinstance(node, Section):
                    _collect_gets(node.declarations, fp)

        _walk(file_path)
        return result
