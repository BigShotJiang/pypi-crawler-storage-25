"""Document state management for the BCPL LSP."""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from bcpl_lsp.analysis.diagnostics import Diagnostic, diagnostics_from_parse_errors
from bcpl_lsp.analysis.symbols import Symbol, SymbolTableBuilder
from bcpl_lsp.parser.ast_nodes import Program
from bcpl_lsp.parser.lexer import Lexer
from bcpl_lsp.parser.parser import Parser
from bcpl_lsp.parser.tokens import Token

# BCPL markers to look for when sniffing extensionless files.
# Matches common top-level constructs and block delimiters.
_BCPL_SNIFF_RE = re.compile(
    r"""(?mx)
    ^ \s* (?: GET \s+ " | SECTION \s+ " | LET \s+ | AND \s+ | MANIFEST \s* \n | GLOBAL \s* \n )
    | \$\( | \$\)
    """,
)

_SNIFF_BYTES = 4096  # only inspect the first 4 KB


def looks_like_bcpl(source: str) -> bool:
    """Quick sniff: return True if *source* looks like BCPL.

    Checks the first few KB for characteristic BCPL constructs.
    Files with a ``.b`` or ``.bcpl`` extension bypass this check
    (handled by the caller).
    """
    head = source[:_SNIFF_BYTES]
    return _BCPL_SNIFF_RE.search(head) is not None


@dataclass
class DocumentState:
    """Cached analysis state for a single document."""
    uri: str
    source: str = ""
    tokens: list[Token] = field(default_factory=list)
    ast: Program | None = None
    symbols: list[Symbol] = field(default_factory=list)
    diagnostics: list[Diagnostic] = field(default_factory=list)


def analyze_document(uri: str, source: str) -> DocumentState:
    """Lex, parse, and analyze a BCPL document.

    For extensionless files, a quick sniff is performed first.
    If the content does not look like BCPL, an empty state is returned.
    """
    state = DocumentState(uri=uri, source=source)

    # For extensionless files, bail out early if not BCPL
    path = uri.removeprefix("file://")
    if "." not in path.rsplit("/", 1)[-1] and not looks_like_bcpl(source):
        return state

    # Lex
    lexer = Lexer(source)
    state.tokens = lexer.tokenize()

    # Parse
    parser = Parser(state.tokens)
    state.ast = parser.parse()

    # Build symbol table
    builder = SymbolTableBuilder(uri=uri)
    builder.build(state.ast)
    state.symbols = builder.all_symbols

    # Collect diagnostics
    state.diagnostics = diagnostics_from_parse_errors(parser.errors)

    return state
