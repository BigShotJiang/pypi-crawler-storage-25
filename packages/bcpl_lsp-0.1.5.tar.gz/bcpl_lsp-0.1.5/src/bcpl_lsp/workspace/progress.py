"""LSP progress reporting for workspace indexing."""

from __future__ import annotations

import uuid
from typing import TYPE_CHECKING

from lsprotocol.types import (
    WorkDoneProgressBegin,
    WorkDoneProgressEnd,
    WorkDoneProgressReport,
)

if TYPE_CHECKING:
    from pygls.lsp.server import LanguageServer


class IndexingProgress:
    """Reports indexing progress via LSP ``$/progress`` notifications."""

    def __init__(self, server: LanguageServer) -> None:
        self._server = server
        self._token: str = ""

    def begin(self, total_files: int) -> None:
        """Start a new progress sequence."""
        self._token = str(uuid.uuid4())
        self._server.progress.create(self._token)
        self._server.progress.begin(
            self._token,
            WorkDoneProgressBegin(
                title="Indexing BCPL workspace",
                message=f"0/{total_files} files",
                percentage=0,
            ),
        )

    def report(self, current: int, total: int, message: str = "") -> None:
        """Report incremental progress."""
        pct = int((current / total) * 100) if total > 0 else 100
        msg = message or f"{current}/{total} files"
        self._server.progress.report(
            self._token,
            WorkDoneProgressReport(message=msg, percentage=pct),
        )

    def end(self) -> None:
        """Signal completion."""
        self._server.progress.end(
            self._token,
            WorkDoneProgressEnd(message="Indexing complete"),
        )
