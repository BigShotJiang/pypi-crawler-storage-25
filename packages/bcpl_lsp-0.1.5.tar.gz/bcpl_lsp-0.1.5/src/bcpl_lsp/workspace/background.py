"""Background indexer that parses workspace files on a thread pool."""

from __future__ import annotations

import logging
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from bcpl_lsp.workspace.indexer import WorkspaceIndex

log = logging.getLogger(__name__)


class BackgroundIndexer:
    """Parses files on a thread pool during idle time.

    Open files are prioritised, then their GET chains, then everything else.
    """

    def __init__(self, index: WorkspaceIndex, workers: int = 2) -> None:
        self._index = index
        self._workers = workers
        self._pool: ThreadPoolExecutor | None = None
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()
        # Priority paths are processed first (insertion order)
        self._priority: list[str] = []

    def start(self) -> None:
        """Begin background parsing on a daemon thread."""
        if self._thread is not None:
            return
        self._stop_event.clear()
        self._pool = ThreadPoolExecutor(max_workers=self._workers)
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        """Signal the background thread to stop and wait for it."""
        self._stop_event.set()
        if self._pool is not None:
            self._pool.shutdown(wait=False)
            self._pool = None
        if self._thread is not None:
            self._thread.join(timeout=5)
            self._thread = None

    def prioritize(self, path: str) -> None:
        """Move *path* to the front of the processing queue."""
        with self._lock:
            # Remove if already present, then prepend
            try:
                self._priority.remove(path)
            except ValueError:
                pass
            self._priority.insert(0, path)

    def _run(self) -> None:
        """Main loop: submit files for parsing until stopped."""
        all_files = self._index.files()

        while not self._stop_event.is_set():
            path = self._next_path(all_files)
            if path is None:
                break

            if self._stop_event.is_set():
                break

            pool = self._pool
            if pool is None:
                break

            try:
                future = pool.submit(self._parse_file, path)
                future.result(timeout=30)
            except Exception:
                log.debug("Background parse failed for %s", path, exc_info=True)

    def _next_path(self, all_files: list[str]) -> str | None:
        """Return the next file to parse, prioritised files first."""
        with self._lock:
            if self._priority:
                return self._priority.pop(0)

        # Fall back to any file that hasn't been parsed yet
        for path in all_files:
            state = self._index.get_state(path)
            if state is None:
                return path
        return None

    def _parse_file(self, path: str) -> None:
        """Parse a single file if it hasn't been parsed yet."""
        if self._index.get_state(path) is not None:
            return
        try:
            source = Path(path).read_text(encoding="utf-8", errors="replace")
        except OSError:
            log.debug("Cannot read %s for background indexing", path)
            return
        self._index.ensure_parsed(path, source)
        log.debug("Background indexed %s", path)
