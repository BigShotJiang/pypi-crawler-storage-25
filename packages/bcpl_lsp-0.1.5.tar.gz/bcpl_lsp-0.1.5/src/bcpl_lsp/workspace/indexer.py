"""Workspace-wide file discovery and lazy parse cache."""

from __future__ import annotations

import hashlib
import re
import threading
from dataclasses import dataclass
from pathlib import Path

from bcpl_lsp.workspace.document import DocumentState, analyze_document, looks_like_bcpl

_GET_RE = re.compile(r'GET\s+"([^"]+)"', re.IGNORECASE)


@dataclass
class FileEntry:
    """Tracked file in the workspace."""

    path: Path
    content_hash: str = ""
    state: DocumentState | None = None


class WorkspaceIndex:
    """Discovers and caches parsed state for all BCPL files in a workspace.

    Thread-safe: pygls dispatches on a thread pool, so all mutations
    are guarded by a lock.
    """

    def __init__(self, root: Path, extensions: tuple[str, ...] = (".b", ".bcpl")) -> None:
        """Create an index rooted at *root*.

        Parameters
        ----------
        root:
            Workspace root directory.
        extensions:
            File extensions recognised as BCPL without sniffing.
        """
        self._root = root
        self._extensions = extensions
        self._files: dict[str, FileEntry] = {}
        self._lock = threading.Lock()
        # Reverse dependency map: path -> set of files that GET it
        self._reverse_deps: dict[str, set[str]] = {}

    @property
    def root(self) -> Path:
        return self._root

    def discover(self) -> list[Path]:
        """Walk *root* and register every BCPL file found.

        Files with a recognised extension are added unconditionally.
        Extensionless files are sniffed via ``looks_like_bcpl()``.

        Returns the list of newly discovered paths.
        """
        discovered: list[Path] = []
        for child in self._root.rglob("*"):
            if not child.is_file():
                continue
            suffix = child.suffix.lower()
            if suffix in self._extensions:
                is_bcpl = True
            elif suffix == "":
                # Extensionless file — sniff contents
                try:
                    text = child.read_text(encoding="utf-8", errors="replace")
                except OSError:
                    continue
                is_bcpl = looks_like_bcpl(text)
            else:
                continue

            if is_bcpl:
                key = str(child)
                with self._lock:
                    if key not in self._files:
                        self._files[key] = FileEntry(path=child)
                        discovered.append(child)

        # Build reverse dependency map by scanning GET directives
        self._build_reverse_deps()
        return discovered

    def _build_reverse_deps(self) -> None:
        """Scan all tracked files for GET directives and build the reverse map."""
        reverse: dict[str, set[str]] = {}
        with self._lock:
            paths = list(self._files.keys())

        for path in paths:
            try:
                source = Path(path).read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue

            for m in _GET_RE.finditer(source):
                target = self._resolve_get(m.group(1), Path(path))
                if target is not None:
                    target_key = str(target)
                    reverse.setdefault(target_key, set()).add(path)

        with self._lock:
            self._reverse_deps = reverse

    def _resolve_get(self, filename: str, from_file: Path) -> Path | None:
        """Resolve a GET filename to a path, searching the same directory."""
        parent = from_file.parent
        candidates = [filename]
        if "." not in Path(filename).name:
            candidates.append(filename + ".b")
            candidates.append(filename + ".bcpl")
        for candidate in candidates:
            target = parent / candidate
            if target.is_file():
                return target.resolve()
        return None

    def dependents(self, path: str) -> list[str]:
        """Return files that GET this file, directly or transitively."""
        result: list[str] = []
        seen: set[str] = set()
        queue = [path]
        while queue:
            current = queue.pop(0)
            with self._lock:
                deps = self._reverse_deps.get(current, set())
            for dep in deps:
                if dep not in seen:
                    seen.add(dep)
                    result.append(dep)
                    queue.append(dep)
        return result

    def invalidate_chain(self, path: str) -> None:
        """Invalidate *path* and all its transitive dependents."""
        self.invalidate(path)
        for dep in self.dependents(path):
            self.invalidate(dep)

    def files(self) -> list[str]:
        """Return all tracked file paths (as strings)."""
        with self._lock:
            return list(self._files.keys())

    def ensure_parsed(self, path: str, source: str | None = None) -> DocumentState:
        """Return the ``DocumentState`` for *path*, parsing if necessary.

        If *source* is provided it is used directly; otherwise the file
        is read from disk.  Results are cached until ``invalidate()`` is
        called.
        """
        with self._lock:
            entry = self._files.get(path)
            if entry is None:
                entry = FileEntry(path=Path(path))
                self._files[path] = entry
            if entry.state is not None:
                return entry.state

        # Parse outside the lock to avoid holding it during I/O
        if source is None:
            source = Path(path).read_text(encoding="utf-8", errors="replace")

        content_hash = hashlib.md5(source.encode()).hexdigest()
        state = analyze_document(f"file://{path}", source)

        with self._lock:
            entry.content_hash = content_hash
            entry.state = state
        return state

    def invalidate(self, path: str) -> None:
        """Mark *path* for re-parse on next ``ensure_parsed()`` call."""
        with self._lock:
            entry = self._files.get(path)
            if entry is not None:
                entry.state = None

    def get_state(self, path: str) -> DocumentState | None:
        """Return the cached state for *path* without triggering a parse."""
        with self._lock:
            entry = self._files.get(path)
            if entry is not None:
                return entry.state
            return None

    def update(self, path: str, source: str) -> DocumentState:
        """Update the source for *path*, re-parse, and cache the result."""
        content_hash = hashlib.md5(source.encode()).hexdigest()
        state = analyze_document(f"file://{path}", source)

        with self._lock:
            entry = self._files.get(path)
            if entry is None:
                entry = FileEntry(path=Path(path))
                self._files[path] = entry
            entry.content_hash = content_hash
            entry.state = state
        return state

    def remove(self, path: str) -> None:
        """Stop tracking *path*."""
        with self._lock:
            self._files.pop(path, None)
