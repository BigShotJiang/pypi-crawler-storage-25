"""File and SECTION dependency graph for BCPL workspaces."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from bcpl_lsp.parser.ast_nodes import GetDirective, Section
from bcpl_lsp.workspace.get_resolver import GetResolver
from bcpl_lsp.workspace.indexer import WorkspaceIndex


@dataclass
class DependencyGraph:
    """Directed dependency graph with DOT and JSON export."""

    nodes: set[str] = field(default_factory=set)
    edges: list[tuple[str, str]] = field(default_factory=list)
    label: str = "dependency_graph"

    def add_edge(self, source: str, target: str) -> None:
        self.nodes.add(source)
        self.nodes.add(target)
        self.edges.append((source, target))

    def to_dot(self) -> str:
        """Export as Graphviz DOT format."""
        lines = [f'digraph "{self.label}" {{']
        lines.append("  rankdir=LR;")
        for node in sorted(self.nodes):
            safe = node.replace('"', '\\"')
            lines.append(f'  "{safe}";')
        for src, tgt in sorted(self.edges):
            s = src.replace('"', '\\"')
            t = tgt.replace('"', '\\"')
            lines.append(f'  "{s}" -> "{t}";')
        lines.append("}")
        return "\n".join(lines)

    def to_json(self) -> str:
        """Export as JSON with nodes and edges arrays."""
        data = {
            "label": self.label,
            "nodes": sorted(self.nodes),
            "edges": [{"from": src, "to": tgt} for src, tgt in sorted(self.edges)],
        }
        return json.dumps(data, indent=2)


def build_file_graph(
    index: WorkspaceIndex,
    resolver: GetResolver,
) -> DependencyGraph:
    """Build a file-level dependency graph from GET directives.

    Each node is a file path (relative to workspace root).
    Each edge represents a GET directive from one file to another.
    """
    graph = DependencyGraph(label="file_dependencies")
    root = index.root

    for path_str in index.files():
        state = index.ensure_parsed(path_str)
        source_name = _relative(path_str, root)
        graph.nodes.add(source_name)

        if state.ast is None:
            continue

        for decl in state.ast.declarations:
            if isinstance(decl, GetDirective) and decl.filename:
                target = resolver.resolve(decl.filename, Path(path_str))
                if target is not None:
                    target_name = _relative(str(target), root)
                    graph.add_edge(source_name, target_name)


    return graph


def build_section_graph(index: WorkspaceIndex) -> DependencyGraph:
    """Build a SECTION-level dependency graph from GLOBAL slot usage.

    Nodes are SECTION names. An edge from A to B means section A uses
    a global slot defined in section B.
    """
    graph = DependencyGraph(label="section_dependencies")

    # Map: global_slot -> defining section name
    slot_to_section: dict[int, str] = {}
    # Map: section_name -> set of global slots used (referenced as symbols)
    section_globals: dict[str, set[int]] = {}

    for path_str in index.files():
        state = index.ensure_parsed(path_str)
        if state.ast is None:
            continue

        current_section: str | None = None
        for decl in state.ast.declarations:
            if isinstance(decl, Section):
                current_section = decl.name
                graph.nodes.add(current_section)
                _collect_section_globals(
                    decl, current_section, slot_to_section, section_globals,
                )

    # Build edges: section A uses slot defined in section B
    for section, slots in section_globals.items():
        for slot in slots:
            defining = slot_to_section.get(slot)
            if defining is not None and defining != section:
                graph.add_edge(section, defining)

    return graph


def _collect_section_globals(
    section: Section,
    section_name: str,
    slot_to_section: dict[int, str],
    section_globals: dict[str, set[int]],
) -> None:
    """Collect global slot definitions within a section."""
    from bcpl_lsp.parser.ast_nodes import GlobalBlock

    for decl in section.declarations:
        if isinstance(decl, GlobalBlock):
            for entry in decl.entries:
                if entry.number is not None:
                    slot_to_section[entry.number] = section_name
                    section_globals.setdefault(section_name, set()).add(entry.number)


def _relative(path: str, root: Path) -> str:
    """Make a path relative to root, falling back to the basename."""
    try:
        return str(Path(path).relative_to(root))
    except ValueError:
        return Path(path).name
