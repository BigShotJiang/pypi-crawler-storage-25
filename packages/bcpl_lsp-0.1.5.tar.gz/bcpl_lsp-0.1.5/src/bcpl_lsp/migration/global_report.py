"""Global vector audit report in Markdown format."""

from __future__ import annotations

from pathlib import Path

from bcpl_lsp.analysis.global_registry import GlobalRegistry
from bcpl_lsp.analysis.scope_resolver import ScopeResolver
from bcpl_lsp.analysis.symbols import SymbolKind
from bcpl_lsp.workspace.indexer import WorkspaceIndex


def generate_report(
    registry: GlobalRegistry,
    scope_resolver: ScopeResolver,
    index: WorkspaceIndex,
) -> str:
    """Generate a Markdown global vector audit report.

    Produces a table: slot | name | defining file | call sites.
    """
    root = index.root
    summary = registry.usage_summary()

    lines: list[str] = []
    lines.append("# Global Vector Audit Report")
    lines.append("")

    # Summary
    lines.append("## Summary")
    lines.append("")
    lines.append(f"- **Total slots used:** {summary.total_used}")
    if summary.min_slot is not None:
        lines.append(f"- **Slot range:** {summary.min_slot} .. {summary.max_slot}")
    lines.append(f"- **Conflicts:** {len(summary.conflicts)}")
    lines.append(f"- **Gaps:** {len(summary.gaps)}")
    lines.append("")

    # Allocation table
    lines.append("## Slot Allocations")
    lines.append("")
    lines.append("| Slot | Name | Defining File | References |")
    lines.append("|------|------|---------------|------------|")

    for slot in sorted(summary.allocations.keys()):
        allocs = summary.allocations[slot]
        for alloc in allocs:
            def_file = _relative(alloc.file, root)
            refs = _find_references(alloc.name, index, scope_resolver, alloc.file)
            ref_str = ", ".join(_relative(r, root) for r in refs) if refs else "-"
            lines.append(f"| {slot} | {alloc.name} | {def_file} | {ref_str} |")

    # Conflicts
    if summary.conflicts:
        lines.append("")
        lines.append("## Conflicts")
        lines.append("")
        for conflict in summary.conflicts:
            names = ", ".join(f"{a.name} ({_relative(a.file, root)})" for a in conflict.allocations)
            lines.append(f"- **Slot {conflict.slot}:** {names}")

    # Gaps
    if summary.gaps:
        lines.append("")
        lines.append("## Gaps")
        lines.append("")
        gap_str = ", ".join(str(g) for g in summary.gaps[:50])
        if len(summary.gaps) > 50:
            gap_str += f" ... ({len(summary.gaps)} total)"
        lines.append(f"Unused slots: {gap_str}")

    lines.append("")
    return "\n".join(lines)


def _find_references(
    name: str,
    index: WorkspaceIndex,
    scope_resolver: ScopeResolver,
    defining_file: str,
) -> list[str]:
    """Find files that reference a global symbol by name."""
    ref_files: set[str] = set()
    for path_str in index.files():
        if path_str == defining_file:
            continue
        resolved = scope_resolver.resolve(path_str)
        for rr in resolved.resolved_refs:
            if rr.reference.name == name and rr.symbol and rr.symbol.kind == SymbolKind.GLOBAL:
                ref_files.add(path_str)
                break
    return sorted(ref_files)


def _relative(path: str, root: Path) -> str:
    """Make a path relative to root, falling back to the basename."""
    try:
        return str(Path(path).relative_to(root))
    except ValueError:
        return Path(path).name
