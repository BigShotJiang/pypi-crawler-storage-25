"""Detect MANIFEST offset patterns as struct candidates for migration."""

from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import dataclass, field

from bcpl_lsp.analysis.manifest_eval import evaluate_manifest_block
from bcpl_lsp.parser.ast_nodes import ManifestBlock
from bcpl_lsp.workspace.indexer import WorkspaceIndex


@dataclass
class StructField:
    """A field within a detected struct candidate."""

    name: str
    offset: int


@dataclass
class StructCandidate:
    """A MANIFEST pattern that looks like a struct definition."""

    name: str
    fields: list[StructField] = field(default_factory=list)
    usage_sites: list[str] = field(default_factory=list)

    @property
    def size(self) -> int:
        """Estimated struct size (max offset + 1)."""
        if not self.fields:
            return 0
        return max(f.offset for f in self.fields) + 1


# Pattern: prefix.field or prefix_field
_DOT_PATTERN = re.compile(r"^([a-zA-Z]\w*)\.([a-zA-Z]\w*)$")
_UNDERSCORE_PATTERN = re.compile(r"^([a-zA-Z]\w*)_([a-zA-Z]\w*)$")


def _extract_prefix_field(name: str) -> tuple[str, str] | None:
    """Extract (prefix, field) from a dot-separated or underscore-separated name."""
    m = _DOT_PATTERN.match(name)
    if m:
        return m.group(1), m.group(2)
    return None


def _group_by_prefix(
    constants: dict[str, int],
) -> dict[str, list[tuple[str, int]]]:
    """Group constants by their dot-separated prefix."""
    groups: dict[str, list[tuple[str, int]]] = defaultdict(list)
    for name, value in constants.items():
        result = _extract_prefix_field(name)
        if result:
            prefix, field_name = result
            groups[prefix].append((field_name, value))
    return dict(groups)


def _is_struct_like(fields: list[tuple[str, int]]) -> bool:
    """Determine if a group of fields looks like a struct definition.

    Heuristic: at least 2 fields, offsets are small non-negative integers,
    and they aren't all the same value.
    """
    if len(fields) < 2:
        return False
    offsets = [v for _, v in fields]
    if any(o < 0 for o in offsets):
        return False
    if len(set(offsets)) < 2:
        return False
    # Offsets should be reasonably small (struct-like, not bitmasks)
    if max(offsets) > 1000:
        return False
    return True


def _find_usage_sites(
    index: WorkspaceIndex,
    field_names: set[str],
) -> list[str]:
    """Find files that reference any of the field names."""
    sites: set[str] = set()
    for path_str in index.files():
        state = index.ensure_parsed(path_str)
        for sym in state.symbols:
            if sym.name in field_names:
                sites.add(path_str)
                break
    return sorted(sites)


def detect_structs(index: WorkspaceIndex) -> list[StructCandidate]:
    """Scan workspace MANIFEST blocks for struct-like offset patterns.

    Looks for dot-separated naming conventions like:
        pkt.link = 0
        pkt.id   = 1
        pkt.type = 5

    Returns a list of StructCandidate objects.
    """
    # Collect all MANIFEST constants across the workspace
    all_constants: dict[str, int] = {}

    for path_str in index.files():
        state = index.ensure_parsed(path_str)
        if state.ast is None:
            continue
        for decl in state.ast.declarations:
            _collect_manifest_constants(decl, all_constants)

    # Group by prefix
    groups = _group_by_prefix(all_constants)

    # Build candidates
    candidates = []
    for prefix, fields in sorted(groups.items()):
        if not _is_struct_like(fields):
            continue
        sorted_fields = sorted(fields, key=lambda f: f[1])
        struct_fields = [StructField(name=name, offset=offset) for name, offset in sorted_fields]

        # Build full field names for usage search
        full_names = {f"{prefix}.{name}" for name, _ in fields}
        usage = _find_usage_sites(index, full_names)

        candidates.append(StructCandidate(
            name=prefix.capitalize(),
            fields=struct_fields,
            usage_sites=usage,
        ))

    return candidates


def _collect_manifest_constants(node: object, out: dict[str, int]) -> None:
    """Recursively collect evaluated MANIFEST constants from AST nodes."""
    from bcpl_lsp.parser.ast_nodes import Section

    if isinstance(node, ManifestBlock):
        out.update(evaluate_manifest_block(node, out))
    elif isinstance(node, Section):
        for decl in node.declarations:
            _collect_manifest_constants(decl, out)
