"""Symbol table with scope tracking for BCPL."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto

from bcpl_lsp.parser.ast_nodes import (
    AndDecl,
    BinaryExpr,
    Block,
    ForStmt,
    GlobalBlock,
    GlobalEntry,
    IdentExpr,
    LetDecl,
    ManifestBlock,
    ManifestEntry,
    Node,
    NumberLit,
    Program,
    Range,
    Section,
    StaticBlock,
    StaticEntry,
    UnaryExpr,
    ValofExpr,
)


class SymbolKind(Enum):
    FUNCTION = auto()
    VARIABLE = auto()
    CONSTANT = auto()   # MANIFEST entry
    GLOBAL = auto()     # GLOBAL entry
    STATIC = auto()     # STATIC entry
    PARAMETER = auto()
    SECTION = auto()


@dataclass(slots=True)
class Symbol:
    name: str
    kind: SymbolKind
    range: Range
    params: list[str] = field(default_factory=list)
    global_number: int | None = None
    value_text: str | None = None
    uri: str = ""
    definition_range: Range | None = None


@dataclass
class Scope:
    parent: Scope | None = None
    symbols: dict[str, Symbol] = field(default_factory=dict)

    def define(self, symbol: Symbol) -> None:
        self.symbols[symbol.name] = symbol

    def lookup(self, name: str) -> Symbol | None:
        if name in self.symbols:
            return self.symbols[name]
        if self.parent:
            return self.parent.lookup(name)
        return None

    def all_visible(self) -> dict[str, Symbol]:
        result = {}
        if self.parent:
            result.update(self.parent.all_visible())
        result.update(self.symbols)
        return result


class SymbolTableBuilder:
    """Walks AST to build a symbol table."""

    def __init__(self, uri: str = "") -> None:
        self.uri = uri
        self.global_scope = Scope()
        self.current_scope = self.global_scope
        self.all_symbols: list[Symbol] = []

    def build(self, program: Program) -> None:
        for decl in program.declarations:
            self._visit(decl)

    def _visit(self, node: Node) -> None:
        if isinstance(node, Section):
            sym = Symbol(name=node.name, kind=SymbolKind.SECTION, range=node.range, uri=self.uri)
            self.global_scope.define(sym)
            self.all_symbols.append(sym)
            for decl in node.declarations:
                self._visit(decl)

        elif isinstance(node, (LetDecl, AndDecl)):
            kind = SymbolKind.FUNCTION if node.is_function else SymbolKind.VARIABLE
            sym = Symbol(
                name=node.name, kind=kind, range=node.range, params=list(node.params),
                uri=self.uri,
            )
            self.current_scope.define(sym)
            self.all_symbols.append(sym)

            if node.params:
                self._push_scope()
                for param in node.params:
                    psym = Symbol(
                        name=param, kind=SymbolKind.PARAMETER,
                        range=node.range,  # Approximate — params don't have individual ranges yet
                        uri=self.uri,
                    )
                    self.current_scope.define(psym)
                    self.all_symbols.append(psym)

            if node.body:
                self._visit(node.body)

            if node.params:
                self._pop_scope()

        elif isinstance(node, GlobalBlock):
            for entry in node.entries:
                self._visit_global_entry(entry)

        elif isinstance(node, ManifestBlock):
            for entry in node.entries:
                self._visit_manifest_entry(entry)

        elif isinstance(node, StaticBlock):
            for entry in node.entries:
                self._visit_static_entry(entry)

        elif isinstance(node, Block):
            self._push_scope()
            for stmt in node.statements:
                self._visit(stmt)
            self._pop_scope()

        elif isinstance(node, ForStmt):
            self._push_scope()
            if node.var:
                sym = Symbol(name=node.var, kind=SymbolKind.VARIABLE, range=node.range, uri=self.uri)
                self.current_scope.define(sym)
                self.all_symbols.append(sym)
            if node.body:
                self._visit(node.body)
            self._pop_scope()

        elif isinstance(node, ValofExpr):
            self._push_scope()
            if node.body:
                self._visit(node.body)
            self._pop_scope()

        else:
            # Walk child nodes for any other compound nodes
            self._visit_children(node)

    def _visit_children(self, node: Node) -> None:
        """Visit child nodes that may contain nested declarations."""
        for attr_name in ("body", "then_body", "else_body", "condition"):
            child = getattr(node, attr_name, None)
            if isinstance(child, Node):
                self._visit(child)
        for attr_name in ("statements", "args", "values"):
            children = getattr(node, attr_name, None)
            if isinstance(children, list):
                for child in children:
                    if isinstance(child, Node):
                        self._visit(child)

    def _visit_global_entry(self, entry: GlobalEntry) -> None:
        sym = Symbol(
            name=entry.name, kind=SymbolKind.GLOBAL, range=entry.range,
            global_number=entry.number, uri=self.uri,
        )
        self.global_scope.define(sym)
        self.all_symbols.append(sym)

    def _visit_manifest_entry(self, entry: ManifestEntry) -> None:
        sym = Symbol(
            name=entry.name, kind=SymbolKind.CONSTANT, range=entry.range,
            value_text=self._expr_text(entry.value), uri=self.uri,
        )
        self.global_scope.define(sym)
        self.all_symbols.append(sym)

    @staticmethod
    def _expr_text(node: Node | None) -> str | None:
        if node is None:
            return None
        if isinstance(node, NumberLit):
            return node.value
        if isinstance(node, IdentExpr):
            return node.name
        if isinstance(node, BinaryExpr):
            left = SymbolTableBuilder._expr_text(node.left) or "?"
            right = SymbolTableBuilder._expr_text(node.right) or "?"
            return f"{left} {node.op} {right}"
        if isinstance(node, UnaryExpr):
            operand = SymbolTableBuilder._expr_text(node.operand) or "?"
            return f"{node.op}{operand}"
        return "..."

    def _visit_static_entry(self, entry: StaticEntry) -> None:
        sym = Symbol(
            name=entry.name, kind=SymbolKind.STATIC, range=entry.range,
            uri=self.uri,
        )
        self.global_scope.define(sym)
        self.all_symbols.append(sym)

    def _push_scope(self) -> None:
        self.current_scope = Scope(parent=self.current_scope)

    def _pop_scope(self) -> None:
        if self.current_scope.parent:
            self.current_scope = self.current_scope.parent
