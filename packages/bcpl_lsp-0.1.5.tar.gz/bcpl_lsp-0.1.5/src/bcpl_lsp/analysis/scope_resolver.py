"""Cross-file symbol resolution — the central engine."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from bcpl_lsp.analysis.references import Reference, ReferenceCollector
from bcpl_lsp.analysis.symbols import Symbol, SymbolKind, SymbolTableBuilder
from bcpl_lsp.workspace.document import DocumentState
from bcpl_lsp.workspace.get_resolver import GetResolver
from bcpl_lsp.workspace.indexer import WorkspaceIndex


@dataclass
class ResolvedReference:
    """A reference paired with its resolved definition (if found)."""

    reference: Reference
    symbol: Symbol | None = None


@dataclass
class ResolvedFile:
    """Fully resolved analysis for a single file."""

    path: str
    symbols: list[Symbol] = field(default_factory=list)
    resolved_refs: list[ResolvedReference] = field(default_factory=list)
    unresolved_refs: list[Reference] = field(default_factory=list)


class ScopeResolver:
    """Cross-file symbol resolution.

    For a given file:
    1. Get the GET chain from ``GetResolver``.
    2. Ensure all chain files are parsed via ``WorkspaceIndex``.
    3. Merge GLOBAL and MANIFEST symbols from the chain into a combined
       scope (later files override earlier).
    4. Resolve each ``Reference`` to its defining ``Symbol``
       (local scope first, then combined scope).
    5. For GLOBAL entries, match by slot number across files.

    Results are cached per file and invalidated when any file in the
    GET chain changes.
    """

    def __init__(self, index: WorkspaceIndex, resolver: GetResolver) -> None:
        self._index = index
        self._resolver = resolver
        self._cache: dict[str, ResolvedFile] = {}

    def resolve(self, path: str) -> ResolvedFile:
        """Resolve all references in the file at *path*.

        Returns a ``ResolvedFile`` with resolved and unresolved references.
        Uses the cache if the file and its GET chain are unchanged.
        """
        if path in self._cache:
            return self._cache[path]

        # 1. Get the GET chain
        chain = self._resolver.resolve_chain(Path(path))

        # 2. Ensure all chain files are parsed
        states: list[DocumentState] = []
        for chain_path in chain:
            state = self._index.ensure_parsed(str(chain_path))
            states.append(state)

        # 3. Build combined scope from GLOBAL and MANIFEST symbols across chain
        combined_symbols: dict[str, Symbol] = {}
        global_by_slot: dict[int, Symbol] = {}
        for state in states:
            for sym in state.symbols:
                if sym.kind in (SymbolKind.GLOBAL, SymbolKind.CONSTANT):
                    combined_symbols[sym.name] = sym
                    if sym.kind == SymbolKind.GLOBAL and sym.global_number is not None:
                        global_by_slot[sym.global_number] = sym

        # 4. Get the file's own symbols via SymbolTableBuilder
        file_state = self._index.ensure_parsed(path)
        builder = SymbolTableBuilder(uri=path)
        if file_state.ast is not None:
            builder.build(file_state.ast)

        # Build flat lookup from all local symbols (includes params in nested scopes)
        local_by_name: dict[str, Symbol] = {}
        for sym in builder.all_symbols:
            local_by_name[sym.name] = sym

        # 5. Collect references
        collector = ReferenceCollector(uri=path)
        refs: list[Reference] = []
        if file_state.ast is not None:
            refs = collector.collect(file_state.ast)

        # 6. Resolve each reference
        resolved_refs: list[ResolvedReference] = []
        unresolved_refs: list[Reference] = []

        for ref in refs:
            # Try local scope first (includes nested scopes like params)
            sym = local_by_name.get(ref.name)
            if sym is not None:
                resolved_refs.append(ResolvedReference(reference=ref, symbol=sym))
                continue

            # Then combined (cross-file) scope
            sym = combined_symbols.get(ref.name)
            if sym is not None:
                resolved_refs.append(ResolvedReference(reference=ref, symbol=sym))
                continue

            unresolved_refs.append(ref)

        result = ResolvedFile(
            path=path,
            symbols=file_state.symbols,
            resolved_refs=resolved_refs,
            unresolved_refs=unresolved_refs,
        )
        self._cache[path] = result
        return result

    def invalidate(self, path: str) -> None:
        """Invalidate the cached resolution for *path* and any file that includes it."""
        self._cache.pop(path, None)

        # Use reverse dependency map to find affected files efficiently
        for dep_path in self._index.dependents(path):
            self._cache.pop(dep_path, None)

    def resolve_at(self, path: str, line: int, col: int) -> ResolvedReference | None:
        """Find the reference at the given position and return its resolution."""
        resolved_file = self.resolve(path)

        # Check resolved references
        for rr in resolved_file.resolved_refs:
            r = rr.reference.range
            if r.start_line <= line <= r.end_line:
                if (line > r.start_line or col >= r.start_col) and \
                   (line < r.end_line or col <= r.end_col):
                    return rr

        # Check unresolved references
        for ref in resolved_file.unresolved_refs:
            r = ref.range
            if r.start_line <= line <= r.end_line:
                if (line > r.start_line or col >= r.start_col) and \
                   (line < r.end_line or col <= r.end_col):
                    return ResolvedReference(reference=ref, symbol=None)

        return None
