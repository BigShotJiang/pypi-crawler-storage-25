"""AST reference collector — finds every identifier usage with context."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto

from bcpl_lsp.parser.ast_nodes import (
    Assignment,
    CallExpr,
    FieldExpr,
    IdentExpr,
    IndexExpr,
    Node,
    Range,
)


class ReferenceContext(Enum):
    """How an identifier is being used at a reference site."""

    CALL = auto()              # f(...)
    ASSIGNMENT_TARGET = auto() # x := ...
    ASSIGNMENT_SOURCE = auto() # ... := x
    INDEX_BASE = auto()        # x!i
    INDEX_OFFSET = auto()      # v!x
    FIELD_ACCESS = auto()      # x%y
    ARGUMENT = auto()          # f(x)
    OTHER = auto()


@dataclass(slots=True)
class Reference:
    """A single reference to a name in the source."""

    name: str
    range: Range
    uri: str
    context: ReferenceContext


class ReferenceCollector:
    """Walk an AST collecting every ``IdentExpr`` as a ``Reference``.

    Also collects ``CallExpr`` targets separately for call-graph
    construction.
    """

    def __init__(self, uri: str = "") -> None:
        self._uri = uri

    def collect(self, ast: Node) -> list[Reference]:
        """Collect all references from *ast*.

        Returns a list of ``Reference`` objects with context annotations.
        """
        refs: list[Reference] = []
        self._walk(ast, ReferenceContext.OTHER, refs)
        return refs

    def collect_call_targets(self, ast: Node) -> list[Reference]:
        """Collect only call-expression targets from *ast*.

        Each returned ``Reference`` has ``context == ReferenceContext.CALL``.
        """
        all_refs = self.collect(ast)
        return [r for r in all_refs if r.context == ReferenceContext.CALL]

    def _walk(self, node: Node, context: ReferenceContext, refs: list[Reference]) -> None:
        if isinstance(node, IdentExpr):
            refs.append(Reference(
                name=node.name,
                range=node.range,
                uri=self._uri,
                context=context,
            ))
            return

        if isinstance(node, CallExpr):
            if node.func is not None:
                self._walk(node.func, ReferenceContext.CALL, refs)
            for arg in node.args:
                self._walk(arg, ReferenceContext.ARGUMENT, refs)
            return

        if isinstance(node, Assignment):
            if node.target is not None:
                self._walk(node.target, ReferenceContext.ASSIGNMENT_TARGET, refs)
            if node.value is not None:
                self._walk(node.value, ReferenceContext.ASSIGNMENT_SOURCE, refs)
            return

        if isinstance(node, IndexExpr):
            if node.base is not None:
                self._walk(node.base, ReferenceContext.INDEX_BASE, refs)
            if node.index is not None:
                self._walk(node.index, ReferenceContext.INDEX_OFFSET, refs)
            return

        if isinstance(node, FieldExpr):
            if node.base is not None:
                self._walk(node.base, ReferenceContext.FIELD_ACCESS, refs)
            if node.offset is not None:
                self._walk(node.offset, ReferenceContext.FIELD_ACCESS, refs)
            return

        # Generic: walk all child nodes with OTHER context (unless overridden above)
        self._walk_children(node, refs)

    def _walk_children(self, node: Node, refs: list[Reference]) -> None:
        """Walk all child nodes of a generic node with OTHER context."""
        import dataclasses

        for f in dataclasses.fields(node):
            if f.name == "range":
                continue
            value = getattr(node, f.name, None)
            if isinstance(value, Node):
                self._walk(value, ReferenceContext.OTHER, refs)
            elif isinstance(value, list):
                for item in value:
                    if isinstance(item, Node):
                        self._walk(item, ReferenceContext.OTHER, refs)
