"""Global vector slot tracking across the workspace."""

from __future__ import annotations

from dataclasses import dataclass

from bcpl_lsp.analysis.symbols import SymbolKind
from bcpl_lsp.workspace.indexer import WorkspaceIndex


@dataclass
class SlotAllocation:
    """A single global vector slot allocation."""

    slot: int
    name: str
    file: str


@dataclass
class SlotConflict:
    """Multiple symbols claiming the same global vector slot."""

    slot: int
    allocations: list[SlotAllocation]


@dataclass
class GlobalRegistryReport:
    """Summary of global vector slot usage."""

    allocations: dict[int, list[SlotAllocation]]
    conflicts: list[SlotConflict]
    gaps: list[int]
    total_used: int
    min_slot: int | None
    max_slot: int | None


class GlobalRegistry:
    """Aggregates GLOBAL block entries workspace-wide.

    Scans all files in a WorkspaceIndex, collects every GLOBAL entry,
    and maps slot numbers to their defining symbols and files.
    """

    def __init__(self, index: WorkspaceIndex) -> None:
        self._index = index
        self._allocations: dict[int, list[SlotAllocation]] = {}

    def scan(self) -> None:
        """Scan all indexed files and collect global slot allocations."""
        self._allocations.clear()
        for path_str in self._index.files():
            state = self._index.ensure_parsed(path_str)
            for sym in state.symbols:
                if sym.kind == SymbolKind.GLOBAL and sym.global_number is not None:
                    alloc = SlotAllocation(
                        slot=sym.global_number,
                        name=sym.name,
                        file=path_str,
                    )
                    self._allocations.setdefault(sym.global_number, []).append(alloc)

    @property
    def allocations(self) -> dict[int, list[SlotAllocation]]:
        return dict(self._allocations)

    def conflicts(self) -> list[SlotConflict]:
        """Return slots with more than one allocation (potential conflicts)."""
        result = []
        for slot, allocs in sorted(self._allocations.items()):
            # Only a conflict if different names claim the same slot
            names = {a.name for a in allocs}
            if len(names) > 1:
                result.append(SlotConflict(slot=slot, allocations=list(allocs)))
        return result

    def gaps(self) -> list[int]:
        """Return unused slot numbers within the allocated range."""
        if not self._allocations:
            return []
        min_slot = min(self._allocations)
        max_slot = max(self._allocations)
        return [s for s in range(min_slot, max_slot + 1) if s not in self._allocations]

    def usage_summary(self) -> GlobalRegistryReport:
        """Return a full summary of global vector usage."""
        return GlobalRegistryReport(
            allocations=dict(self._allocations),
            conflicts=self.conflicts(),
            gaps=self.gaps(),
            total_used=len(self._allocations),
            min_slot=min(self._allocations) if self._allocations else None,
            max_slot=max(self._allocations) if self._allocations else None,
        )

    def lookup_slot(self, slot: int) -> list[SlotAllocation]:
        """Return all allocations for a given slot number."""
        return list(self._allocations.get(slot, []))

    def lookup_name(self, name: str) -> list[SlotAllocation]:
        """Return all allocations for a given symbol name."""
        result = []
        for allocs in self._allocations.values():
            for alloc in allocs:
                if alloc.name == name:
                    result.append(alloc)
        return result
