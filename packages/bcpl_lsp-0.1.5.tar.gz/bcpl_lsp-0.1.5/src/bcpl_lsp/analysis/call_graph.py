"""Call graph construction from resolved references across workspace."""

from __future__ import annotations

from dataclasses import dataclass

from bcpl_lsp.analysis.references import ReferenceContext
from bcpl_lsp.analysis.scope_resolver import ResolvedFile, ScopeResolver
from bcpl_lsp.analysis.symbols import SymbolKind
from bcpl_lsp.parser.ast_nodes import Range
from bcpl_lsp.workspace.indexer import WorkspaceIndex


@dataclass(slots=True)
class CallSite:
    """A single caller -> callee edge in the call graph."""

    caller_name: str
    caller_uri: str
    callee_name: str
    callee_uri: str
    range: Range


class CallGraph:
    """Build caller/callee maps from resolved references across a workspace.

    Walks every file known to the WorkspaceIndex, resolves references
    via ScopeResolver, and records call edges where a CALL-context
    reference resolves to a function or global symbol.

    Special handling for BCPL coroutine patterns:
    - ``createco(fn, size)`` registers *fn* as a coroutine entry point
    - ``callco`` and ``cowait`` are tracked as coroutine-style calls
    """

    _COROUTINE_CREATORS = {"createco"}
    _COROUTINE_CALLERS = {"callco", "cowait"}

    def __init__(self, scope_resolver: ScopeResolver, index: WorkspaceIndex) -> None:
        self._scope_resolver = scope_resolver
        self._index = index
        # callee_name -> list of CallSite
        self._incoming: dict[str, list[CallSite]] = {}
        # caller_name -> list of CallSite
        self._outgoing: dict[str, list[CallSite]] = {}
        self._built = False

    def build(self) -> None:
        """Resolve every file and populate caller/callee maps."""
        self._incoming.clear()
        self._outgoing.clear()

        for file_path in self._index.files():
            resolved = self._scope_resolver.resolve(file_path)
            self._process_file(resolved)

        self._built = True

    def _process_file(self, resolved: ResolvedFile) -> None:
        """Extract call edges from a single resolved file."""
        # Build a map of symbol ranges in this file so we can figure out
        # which function a reference appears inside of.
        func_symbols = [
            s for s in resolved.symbols
            if s.kind in (SymbolKind.FUNCTION, SymbolKind.GLOBAL)
        ]

        for rr in resolved.resolved_refs:
            ref = rr.reference
            sym = rr.symbol
            if sym is None:
                continue

            is_call = ref.context == ReferenceContext.CALL
            is_coroutine_arg = False

            # Check for createco(fn, size) pattern: the first argument
            # to createco is a coroutine entry point.
            if ref.context == ReferenceContext.ARGUMENT:
                is_coroutine_arg = self._is_coroutine_entry_arg(ref, resolved)

            if not is_call and not is_coroutine_arg:
                continue

            # Determine which function this call is inside
            caller = self._find_enclosing_function(ref.range, func_symbols)
            if caller is None:
                continue

            callee_name = sym.name
            callee_uri = sym.uri or resolved.path

            site = CallSite(
                caller_name=caller.name,
                caller_uri=caller.uri or resolved.path,
                callee_name=callee_name,
                callee_uri=callee_uri,
                range=ref.range,
            )

            self._incoming.setdefault(callee_name, []).append(site)
            self._outgoing.setdefault(caller.name, []).append(site)

    def _is_coroutine_entry_arg(self, ref, resolved: ResolvedFile) -> bool:
        """Check if *ref* is the first argument to createco()."""
        for rr in resolved.resolved_refs:
            if (
                rr.reference.context == ReferenceContext.CALL
                and rr.reference.name in self._COROUTINE_CREATORS
            ):
                # The createco call and the ref should be on the same line
                # and the ref should come after the call target.
                if rr.reference.range.start_line == ref.range.start_line:
                    if ref.range.start_col > rr.reference.range.start_col:
                        return True
        return False

    @staticmethod
    def _find_enclosing_function(ref_range: Range, func_symbols):
        """Find the function symbol whose range encloses *ref_range*."""
        best = None
        for sym in func_symbols:
            sr = sym.range
            if sr.start_line > ref_range.start_line:
                continue
            if sr.end_line < ref_range.end_line:
                continue
            if sr.start_line == ref_range.start_line and sr.start_col > ref_range.start_col:
                continue
            if sr.end_line == ref_range.end_line and sr.end_col < ref_range.end_col:
                continue
            # Pick the most tightly enclosing (latest start)
            if best is None or sr.start_line > best.range.start_line or (
                sr.start_line == best.range.start_line and sr.start_col > best.range.start_col
            ):
                best = sym
        return best

    def callers_of(self, symbol_name: str) -> list[CallSite]:
        """Return all call sites that call *symbol_name*."""
        if not self._built:
            self.build()
        return list(self._incoming.get(symbol_name, []))

    def callees_of(self, symbol_name: str) -> list[CallSite]:
        """Return all call sites for calls made by *symbol_name*."""
        if not self._built:
            self.build()
        return list(self._outgoing.get(symbol_name, []))

    def invalidate(self) -> None:
        """Mark the graph as stale so it rebuilds on next query."""
        self._built = False
        self._incoming.clear()
        self._outgoing.clear()
