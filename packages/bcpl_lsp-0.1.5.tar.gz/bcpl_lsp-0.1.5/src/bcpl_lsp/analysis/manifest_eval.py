"""MANIFEST constant expression evaluator."""

from __future__ import annotations

from bcpl_lsp.parser.ast_nodes import (
    BinaryExpr,
    IdentExpr,
    ManifestBlock,
    ManifestEntry,
    NumberLit,
    UnaryExpr,
)


def evaluate(node: object | None, known_constants: dict[str, int]) -> int | None:
    """Evaluate a MANIFEST entry value expression to an integer.

    Handles integer literals, arithmetic (+, -, *, /), REM, shifts (<<, >>),
    and references to other known constants.

    Returns None if the expression cannot be evaluated.
    """
    if node is None:
        return None

    if isinstance(node, NumberLit):
        return _parse_number(node.value)

    if isinstance(node, IdentExpr):
        return known_constants.get(node.name)

    if isinstance(node, UnaryExpr):
        operand = evaluate(node.operand, known_constants)
        if operand is None:
            return None
        if node.op == "-":
            return -operand
        if node.op == "+":
            return operand
        if node.op == "NOT":
            return ~operand
        return None

    if isinstance(node, BinaryExpr):
        left = evaluate(node.left, known_constants)
        right = evaluate(node.right, known_constants)
        if left is None or right is None:
            return None
        return _apply_op(node.op, left, right)

    return None


def _parse_number(value: str) -> int | None:
    """Parse a BCPL number literal (decimal, hex #x, octal #o, binary #b)."""
    if not value:
        return None
    try:
        v = value.strip()
        if v.startswith("#x") or v.startswith("#X"):
            return int(v[2:], 16)
        if v.startswith("#o") or v.startswith("#O"):
            return int(v[2:], 8)
        if v.startswith("#b") or v.startswith("#B"):
            return int(v[2:], 2)
        if v.startswith("#"):
            # Plain # prefix is hex in some BCPL dialects
            return int(v[1:], 16)
        return int(v)
    except ValueError:
        return None


def _apply_op(op: str, left: int, right: int) -> int | None:
    """Apply a binary operator to two integer values."""
    if op == "+":
        return left + right
    if op == "-":
        return left - right
    if op == "*":
        return left * right
    if op == "/":
        return left // right if right != 0 else None
    if op == "REM":
        return left % right if right != 0 else None
    if op == "<<":
        return left << right
    if op == ">>":
        return left >> right
    if op == "&":
        return left & right
    if op == "|":
        return left | right
    if op == "XOR":
        return left ^ right
    return None


def evaluate_manifest_block(
    block: ManifestBlock,
    known_constants: dict[str, int] | None = None,
) -> dict[str, int]:
    """Evaluate all entries in a MANIFEST block.

    Handles auto-increment: entries without an explicit value get the
    previous entry's value + 1 (starting from 0 for the first entry).

    Returns a dict mapping constant names to their evaluated integer values.
    Constants that cannot be evaluated are omitted.
    """
    constants = dict(known_constants) if known_constants else {}
    result: dict[str, int] = {}
    next_auto: int = 0

    for entry in block.entries:
        if not isinstance(entry, ManifestEntry):
            continue

        if entry.value is not None:
            val = evaluate(entry.value, constants)
            if val is not None:
                result[entry.name] = val
                constants[entry.name] = val
                next_auto = val + 1
        else:
            # Auto-increment
            result[entry.name] = next_auto
            constants[entry.name] = next_auto
            next_auto += 1

    return result
