"""BCPL Language Server Protocol implementation."""

__version__ = "0.1.0"
