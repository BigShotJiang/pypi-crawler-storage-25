"""Streaming tokenizer for BCPL source code."""

from __future__ import annotations

from .tokens import KEYWORDS, Token, TokenType


class Lexer:
    """Tokenizes BCPL source text into a stream of tokens."""

    def __init__(self, source: str) -> None:
        self.source = source
        self.pos = 0
        self.line = 0
        self.column = 0

    def _peek(self) -> str:
        if self.pos < len(self.source):
            return self.source[self.pos]
        return ""

    def _peek_ahead(self, n: int = 1) -> str:
        pos = self.pos + n
        if pos < len(self.source):
            return self.source[pos]
        return ""

    def _advance(self) -> str:
        ch = self.source[self.pos]
        self.pos += 1
        if ch == "\n":
            self.line += 1
            self.column = 0
        else:
            self.column += 1
        return ch

    def _make_token(self, type: TokenType, text: str, line: int, column: int, offset: int) -> Token:
        return Token(type=type, text=text, line=line, column=column, offset=offset)

    def _skip_whitespace(self) -> None:
        while self.pos < len(self.source) and self.source[self.pos] in " \t\r":
            self._advance()

    def _read_line_comment(self, prefix: str = "//") -> Token:
        line, col, offset = self.line, self.column, self.pos
        self._advance()  # first char
        self._advance()  # second char
        start = self.pos
        while self.pos < len(self.source) and self.source[self.pos] != "\n":
            self._advance()
        text = prefix + self.source[start : self.pos]
        return self._make_token(TokenType.COMMENT, text, line, col, offset)

    def _read_block_comment(self) -> Token:
        line, col, offset = self.line, self.column, self.pos
        self._advance()  # /
        self._advance()  # *
        depth = 1
        start = self.pos
        while self.pos < len(self.source) and depth > 0:
            if self.source[self.pos] == "/" and self._peek_ahead() == "*":
                depth += 1
                self._advance()
                self._advance()
            elif self.source[self.pos] == "*" and self._peek_ahead() == "/":
                depth -= 1
                self._advance()
                self._advance()
            else:
                self._advance()
        text = "/*" + self.source[start : self.pos]
        return self._make_token(TokenType.COMMENT, text, line, col, offset)

    def _read_string(self) -> Token:
        line, col, offset = self.line, self.column, self.pos
        quote = self._advance()  # " or '
        token_type = TokenType.STRING if quote == '"' else TokenType.CHARCONST
        chars = [quote]
        while self.pos < len(self.source):
            ch = self._advance()
            chars.append(ch)
            if ch == "*" and self.pos < len(self.source):
                next_ch = self.source[self.pos]
                if next_ch == "\n":
                    # Multi-line string continuation: *\n then optional whitespace and *
                    chars.append(self._advance())  # consume \n
                    while self.pos < len(self.source) and self.source[self.pos] in " \t\r":
                        self._advance()  # skip leading whitespace
                    if self.pos < len(self.source) and self.source[self.pos] == "*":
                        self._advance()  # skip continuation *
                else:
                    # BCPL uses * as escape character inside strings
                    chars.append(self._advance())
            elif ch == quote:
                break
        return self._make_token(token_type, "".join(chars), line, col, offset)

    def _read_number(self) -> Token:
        line, col, offset = self.line, self.column, self.pos
        start = self.pos

        if self.source[self.pos] == "#":
            self._advance()  # #
            if self.pos < len(self.source) and self.source[self.pos] in "bBoOxX":
                base_ch = self._advance()
                if base_ch in "bB":
                    while self.pos < len(self.source) and self.source[self.pos] in "01_":
                        self._advance()
                elif base_ch in "oO":
                    while self.pos < len(self.source) and self.source[self.pos] in "01234567_":
                        self._advance()
                elif base_ch in "xX":
                    while self.pos < len(self.source) and self.source[self.pos] in "0123456789abcdefABCDEF_":
                        self._advance()
            else:
                # # followed by decimal digits (octal in some BCPL dialects)
                while self.pos < len(self.source) and self.source[self.pos] in "01234567_":
                    self._advance()
        else:
            while self.pos < len(self.source) and (self.source[self.pos].isdigit() or self.source[self.pos] == "_"):
                self._advance()

        return self._make_token(TokenType.NUMBER, self.source[start : self.pos], line, col, offset)

    def _read_word(self) -> Token:
        line, col, offset = self.line, self.column, self.pos
        start = self.pos
        while self.pos < len(self.source) and (self.source[self.pos].isalnum() or self.source[self.pos] in "._"):
            self._advance()
        text = self.source[start : self.pos]
        token_type = KEYWORDS.get(text.upper(), TokenType.IDENT)
        return self._make_token(token_type, text, line, col, offset)

    def tokenize(self) -> list[Token]:
        """Tokenize the entire source, returning all tokens including EOF."""
        tokens: list[Token] = []
        while self.pos < len(self.source):
            self._skip_whitespace()
            if self.pos >= len(self.source):
                break

            ch = self._peek()
            line, col, offset = self.line, self.column, self.pos

            # Newlines
            if ch == "\n":
                self._advance()
                tokens.append(self._make_token(TokenType.NEWLINE, "\n", line, col, offset))
                continue

            # Comments
            if ch == "/" and self._peek_ahead() == "/":
                tokens.append(self._read_line_comment("//"))
                continue
            if ch == "/" and self._peek_ahead() == "*":
                tokens.append(self._read_block_comment())
                continue
            if ch == "|" and self._peek_ahead() == "|":
                tokens.append(self._read_line_comment("||"))
                continue

            # Strings and char constants
            if ch == '"' or ch == "'":
                tokens.append(self._read_string())
                continue

            # Numbers (decimal or #-prefixed)
            if ch.isdigit():
                tokens.append(self._read_number())
                continue

            # Words (identifiers and keywords)
            if ch.isalpha() or ch == "_":
                tokens.append(self._read_word())
                continue

            # Hash for number literals
            if ch == "#" and self.pos + 1 < len(self.source) and (
                self.source[self.pos + 1].isdigit() or self.source[self.pos + 1] in "bBoOxX"
            ):
                tokens.append(self._read_number())
                continue

            # Two-character operators
            if ch == ":" and self._peek_ahead() == "=":
                self._advance()
                self._advance()
                tokens.append(self._make_token(TokenType.ASSIGN, ":=", line, col, offset))
                continue
            if ch == "~" and self._peek_ahead() == "=":
                self._advance()
                self._advance()
                tokens.append(self._make_token(TokenType.NEQ, "~=", line, col, offset))
                continue
            if ch == "\\" and self._peek_ahead() == "=":
                self._advance()
                self._advance()
                tokens.append(self._make_token(TokenType.NEQ, "\\=", line, col, offset))
                continue
            if ch == "\\" and self._peek_ahead() == "/":
                self._advance()
                self._advance()
                tokens.append(self._make_token(TokenType.LOGOR, "\\/", line, col, offset))
                continue
            if ch == "\\":
                # Standalone \ is alternate spelling for ~ (bitwise NOT)
                self._advance()
                tokens.append(self._make_token(TokenType.BITNOT, "\\", line, col, offset))
                continue
            if ch == "<" and self._peek_ahead() == ">":
                self._advance()
                self._advance()
                tokens.append(self._make_token(TokenType.SEQ, "<>", line, col, offset))
                continue
            if ch == "<" and self._peek_ahead() == "=":
                self._advance()
                self._advance()
                tokens.append(self._make_token(TokenType.LE, "<=", line, col, offset))
                continue
            if ch == ">" and self._peek_ahead() == "=":
                self._advance()
                self._advance()
                tokens.append(self._make_token(TokenType.GE, ">=", line, col, offset))
                continue
            if ch == "<" and self._peek_ahead() == "<":
                self._advance()
                self._advance()
                tokens.append(self._make_token(TokenType.LSHIFT, "<<", line, col, offset))
                continue
            if ch == ">" and self._peek_ahead() == ">":
                self._advance()
                self._advance()
                tokens.append(self._make_token(TokenType.RSHIFT, ">>", line, col, offset))
                continue
            if ch == "-" and self._peek_ahead() == ">":
                self._advance()
                self._advance()
                tokens.append(self._make_token(TokenType.COND, "->", line, col, offset))
                continue

            # $ directives: $( $) $< $> $$
            if ch == "$":
                next_ch = self._peek_ahead()
                if next_ch == "(":
                    self._advance()
                    self._advance()
                    # Consume optional label after $( (digits, letters, dots)
                    while self.pos < len(self.source) and (self.source[self.pos].isalnum() or self.source[self.pos] == "."):
                        self._advance()
                    tokens.append(self._make_token(TokenType.LBRACE, self.source[offset:self.pos], line, col, offset))
                    continue
                if next_ch == ")":
                    self._advance()
                    self._advance()
                    # Consume optional label after $) (digits, letters, dots)
                    while self.pos < len(self.source) and (self.source[self.pos].isalnum() or self.source[self.pos] == "."):
                        self._advance()
                    tokens.append(self._make_token(TokenType.RBRACE, self.source[offset:self.pos], line, col, offset))
                    continue
                if next_ch in "<>":
                    # Conditional compilation: $<TAG, $>TAG — just consume the tag name
                    self._advance()  # $
                    self._advance()  # < or >
                    start = self.pos
                    while self.pos < len(self.source) and self.source[self.pos] not in " \t\r\n":
                        self._advance()
                    text = "$" + next_ch + self.source[start : self.pos]
                    tokens.append(self._make_token(TokenType.COMMENT, text, line, col, offset))
                    continue
                if next_ch == "$":
                    # $$TAG := expr — conditional compilation assignment, skip entire line
                    self._advance()  # $
                    self._advance()  # $
                    start = self.pos
                    while self.pos < len(self.source) and self.source[self.pos] != "\n":
                        self._advance()
                    text = "$$" + self.source[start : self.pos]
                    tokens.append(self._make_token(TokenType.COMMENT, text, line, col, offset))
                    continue

            # Compound assignment operators: +:=, -:=, *:=, /:=, &:=, |:=
            if ch in "+-*/&|" and self._peek_ahead() == ":" and self._peek_ahead(2) == "=":
                compound_map = {"+": TokenType.PLUS_ASSIGN, "-": TokenType.MINUS_ASSIGN,
                                "*": TokenType.STAR_ASSIGN, "/": TokenType.SLASH_ASSIGN,
                                "&": TokenType.AND_ASSIGN, "|": TokenType.OR_ASSIGN}
                self._advance()
                self._advance()
                self._advance()
                tokens.append(self._make_token(compound_map[ch], ch + ":=", line, col, offset))
                continue

            # Single-character tokens
            single_map: dict[str, TokenType] = {
                "+": TokenType.PLUS,
                "-": TokenType.MINUS,
                "*": TokenType.STAR,
                "/": TokenType.SLASH,
                "=": TokenType.EQ,
                "<": TokenType.LT,
                ">": TokenType.GT,
                "&": TokenType.LOGAND,
                "|": TokenType.LOGOR,
                "~": TokenType.BITNOT,
                "!": TokenType.BANG,
                "%": TokenType.PERCENT,
                "@": TokenType.AT,
                "(": TokenType.LPAREN,
                ")": TokenType.RPAREN,
                "[": TokenType.LBRACKET,
                "]": TokenType.RBRACKET,
                ",": TokenType.COMMA,
                ";": TokenType.SEMICOLON,
                ":": TokenType.COLON,
                "{": TokenType.LBRACE,
                "}": TokenType.RBRACE,
                "#": TokenType.HASH,
                "?": TokenType.QUERY,
                ".": TokenType.DOT,
            }
            if ch in single_map:
                self._advance()
                tokens.append(self._make_token(single_map[ch], ch, line, col, offset))
                continue

            # Unknown character
            self._advance()
            tokens.append(self._make_token(TokenType.ERROR, ch, line, col, offset))

        tokens.append(self._make_token(TokenType.EOF, "", self.line, self.column, self.pos))
        return tokens
