"""Parse error types for BCPL."""

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ParseError:
    message: str
    line: int       # 0-based
    column: int     # 0-based
    end_line: int   # 0-based
    end_column: int # 0-based
