"""Token types for the BCPL lexer."""

from dataclasses import dataclass
from enum import Enum, auto


class TokenType(Enum):
    # Keywords
    LET = auto()
    BE = auto()
    IF = auto()
    THEN = auto()
    ELSE = auto()
    TEST = auto()
    FOR = auto()
    TO = auto()
    BY = auto()
    DO = auto()
    WHILE = auto()
    UNTIL = auto()
    REPEAT = auto()
    REPEATWHILE = auto()
    REPEATUNTIL = auto()
    SWITCHON = auto()
    CASE = auto()
    DEFAULT = auto()
    ENDCASE = auto()
    BREAK = auto()
    LOOP = auto()
    RETURN = auto()
    RESULTIS = auto()
    AND = auto()
    OR = auto()
    NOT = auto()
    TRUE = auto()
    FALSE = auto()
    GLOBAL = auto()
    MANIFEST = auto()
    STATIC = auto()
    GET = auto()
    SECTION = auto()
    NEEDS = auto()
    INTO = auto()
    OF = auto()
    VEC = auto()
    TABLE = auto()
    VALOF = auto()
    EQV = auto()
    NEQV = auto()
    ABS = auto()
    REM = auto()
    MOD = auto()  # synonym for REM
    UNLESS = auto()
    GOTO = auto()

    # Literals
    NUMBER = auto()
    STRING = auto()
    CHARCONST = auto()

    # Identifier
    IDENT = auto()

    # Operators
    PLUS = auto()       # +
    MINUS = auto()      # -
    STAR = auto()       # *
    SLASH = auto()      # /
    EQ = auto()         # =
    NEQ = auto()        # ~= or \=
    LT = auto()         # <
    GT = auto()         # >
    LE = auto()         # <=
    GE = auto()         # >=
    LSHIFT = auto()     # <<
    RSHIFT = auto()     # >>
    LOGAND = auto()     # &
    LOGOR = auto()      # |
    BITNOT = auto()     # ~
    BANG = auto()        # !
    PERCENT = auto()    # %
    AT = auto()         # @
    ASSIGN = auto()     # :=
    PLUS_ASSIGN = auto()   # +:=
    MINUS_ASSIGN = auto()  # -:=
    STAR_ASSIGN = auto()   # *:=
    SLASH_ASSIGN = auto()  # /:=
    AND_ASSIGN = auto()   # &:=
    OR_ASSIGN = auto()    # |:=
    EQV_ASSIGN = auto()   # EQV:=
    NEQV_ASSIGN = auto()  # NEQV:= / XOR:=
    COND = auto()       # ->
    QUERY = auto()      # ? (don't-care value in TABLE)
    SEQ = auto()        # <> (sequence operator)

    # Delimiters
    LPAREN = auto()     # (
    RPAREN = auto()     # )
    LBRACKET = auto()   # [
    RBRACKET = auto()   # ]
    COMMA = auto()      # ,
    SEMICOLON = auto()  # ;
    COLON = auto()      # :
    LBRACE = auto()     # $( or {
    RBRACE = auto()     # $) or }
    HASH = auto()       # #

    DOT = auto()        # . (section separator)

    # Special
    COMMENT = auto()
    NEWLINE = auto()
    EOF = auto()
    ERROR = auto()


# Map keyword strings to token types
KEYWORDS: dict[str, TokenType] = {
    "LET": TokenType.LET,
    "BE": TokenType.BE,
    "IF": TokenType.IF,
    "THEN": TokenType.THEN,
    "ELSE": TokenType.ELSE,
    "TEST": TokenType.TEST,
    "FOR": TokenType.FOR,
    "TO": TokenType.TO,
    "BY": TokenType.BY,
    "DO": TokenType.DO,
    "WHILE": TokenType.WHILE,
    "UNTIL": TokenType.UNTIL,
    "REPEAT": TokenType.REPEAT,
    "REPEATWHILE": TokenType.REPEATWHILE,
    "REPEATUNTIL": TokenType.REPEATUNTIL,
    "SWITCHON": TokenType.SWITCHON,
    "CASE": TokenType.CASE,
    "DEFAULT": TokenType.DEFAULT,
    "ENDCASE": TokenType.ENDCASE,
    "BREAK": TokenType.BREAK,
    "LOOP": TokenType.LOOP,
    "RETURN": TokenType.RETURN,
    "RESULTIS": TokenType.RESULTIS,
    "AND": TokenType.AND,
    "OR": TokenType.OR,
    "NOT": TokenType.NOT,
    "TRUE": TokenType.TRUE,
    "FALSE": TokenType.FALSE,
    "GLOBAL": TokenType.GLOBAL,
    "MANIFEST": TokenType.MANIFEST,
    "STATIC": TokenType.STATIC,
    "GET": TokenType.GET,
    "SECTION": TokenType.SECTION,
    "NEEDS": TokenType.NEEDS,
    "INTO": TokenType.INTO,
    "OF": TokenType.OF,
    "VEC": TokenType.VEC,
    "TABLE": TokenType.TABLE,
    "VALOF": TokenType.VALOF,
    "EQV": TokenType.EQV,
    "NEQV": TokenType.NEQV,
    "ABS": TokenType.ABS,
    "REM": TokenType.REM,
    "MOD": TokenType.MOD,
    "UNLESS": TokenType.UNLESS,
    "GOTO": TokenType.GOTO,
    "NE": TokenType.NEQ,
    "GE": TokenType.GE,
    "LE": TokenType.LE,
    "GR": TokenType.GT,
    "LS": TokenType.LT,
    "LSHIFT": TokenType.LSHIFT,
    "RSHIFT": TokenType.RSHIFT,
    "LOGAND": TokenType.LOGAND,
    "LOGOR": TokenType.LOGOR,
}


@dataclass(frozen=True, slots=True)
class Token:
    type: TokenType
    text: str
    line: int      # 0-based
    column: int    # 0-based
    offset: int    # byte offset in source
