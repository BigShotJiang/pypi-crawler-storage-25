Download PI data in batch.

## Usage

- Install the requirements: `poetry install`
- Prepare a config, e.g., `config/config.json`
- Run the command, e.g., `poetry run pi download --config-path configs/config.json`

Additional dependencies due to windows compatibility:
- Please follow this to install the related packages for linux: https://pypi.org/project/requests-kerberos/
    - e.g., `apt-get install gcc python3-dev libkrb5-dev`

## Dev


Create a file named `.env`

```
AWS_PROFILE="[YOUR_AWS_PROFILE]"

AWS_ACCESS_KEY_ID='testing'
AWS_SECRET_ACCESS_KEY='testing'
AWS_SECURITY_TOKEN='testing'
AWS_SESSION_TOKEN='testing'
AWS_DEFAULT_REGION='us-east-1'
```

## Publish

Log in to aws codeartifact:

```
aws codeartifact login --tool pip --repository [YOUR_REPO] --domain [YOUR_DOMAIN] --domain-owner [ID] --region eu-west-1
```

1. Build the package using `poetry build`
2. Publish using twine: `twine upload dist/* `
    1. Use the instructions at the codeartifact repository `[YOUR REPO]` on aws.
    2. For example, use this: `twine upload --repository codeartifact dist/*   `


## FAQ

### I use pipx to install this package, but it says request_kerberos is not installed.

Use the `inject` command to install the `requests-kerberos` dependency:

```bash
pipx inject pi-downloader requests-kerberos
```