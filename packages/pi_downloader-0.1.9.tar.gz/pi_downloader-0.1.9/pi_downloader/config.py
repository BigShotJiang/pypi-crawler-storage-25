import datetime
import json
from functools import cached_property
from pathlib import Path
from typing import Literal, Optional

import yaml


class Config:
    """Build config for the downloader

    :param path: path to config file
    :param config_repr: dictionary that contains all the required configs
    :param overwrite: content to overwrite the config
    """

    def __init__(
        self,
        path: Optional[Path] = None,
        config_repr: Optional[dict] = None,
        overwrite: Optional[dict] = {},
    ):
        self.path = path
        self.overwrite = overwrite

        if self.path is not None:
            self.config = self._load(self.path)
        elif config_repr is not None:
            self.config = config_repr
        else:
            raise ValueError(
                "`path` and `config_repr` can not be None at the same time"
            )

    @staticmethod
    def _load(path: Path) -> dict:
        with open(path, "r") as fp:
            if path.suffix.lower() in [".yaml", ".yml"]:
                return yaml.safe_load(fp)
            elif path.suffix.lower() == ".json":
                return json.load(fp)
            else:
                raise ValueError(
                    f"Unsupported file format: {path.suffix}. Only .json, .yaml, and .yml are supported."
                )

    @cached_property
    def attributes(self) -> list[dict[str, str]]:
        return self.config.get("attributes", [])

    @cached_property
    def element_base_path(self) -> str:
        return self.config.get("element_base_path", "")

    @cached_property
    def interval(self) -> int | None:

        if self.overwrite.get("interval"):
            interval = self.overwrite.get("interval")
        else:
            interval = self.config.get("interval")

        if interval is None:
            raise ValueError(
                f"Specify interval in config {self.path}: current value {interval}"
            )
        return int(interval)

    @cached_property
    def interval_unit(self) -> Literal["s", "m", "h", "d"]:
        if self.overwrite.get("interval_unit"):
            interval_unit = self.overwrite.get("interval_unit")
        else:
            interval_unit = self.config.get("interval_unit")

        return interval_unit

    @cached_property
    def interval_in_minutes(self) -> int | float:
        """Calculate the number of minutes for the interval"""

        unit_to_min = {"m": 1, "h": 60, "d": 60 * 24, "s": 1 / 60}

        return self.interval * unit_to_min[self.interval_unit]

    @cached_property
    def segment_length(self) -> int:
        """number of days for each download segment
        We need this parameter to cut the batch dates into segments.
        """
        segment_length = self.config.get("segment_length", 1)
        return segment_length

    @cached_property
    def start_date(self) -> datetime.datetime:
        if self.overwrite.get("start_date"):
            start_date = self.overwrite.get("start_date")
        else:
            start_date = self.config["start_date"]

        return datetime.datetime.strptime(start_date, "%Y-%m-%d")

    @cached_property
    def end_date(self) -> datetime.datetime:
        if self.overwrite.get("end_date"):
            end_date = self.overwrite.get("end_date")
        else:
            end_date = self.config["end_date"]
        return datetime.datetime.strptime(end_date, "%Y-%m-%d")

    @cached_property
    def webapi(self) -> str:
        return self.config["webapi"]

    @cached_property
    def output(self) -> dict[str, Path]:
        return {k: Path(v) for k, v in self.config.get("output", {}).items()}

    @cached_property
    def name(self) -> str:
        return self.config.get("name", "")

    def __repr__(self) -> str:
        return f"Config {self.name}"
