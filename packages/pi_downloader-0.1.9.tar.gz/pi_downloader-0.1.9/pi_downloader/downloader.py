"""
Python script to download time series data from
AVEVA PI using WebAPI calls
"""

import datetime
import json
from copy import deepcopy
from functools import cached_property

import orjsonl
from loguru import logger
from tqdm import tqdm

from pi_downloader.config import Config
from pi_downloader.utils.auth import OsiAuth
from pi_downloader.utils.web import DataRetriever


class PIDownloader:
    """Download AF from OSIPI

    :param auth: auth for PI
    :param config: config for the download
    :param retriever: data downloader
    """

    def __init__(
        self,
        auth: OsiAuth,
        config: Config,
        retriever: DataRetriever,
        with_tqdm: bool = False,
    ):
        self.auth = auth
        self.config = config
        self.retriever = retriever
        self.with_tqdm = with_tqdm

        for k in self.config.output:
            logger.debug(
                f"Creating the folder for outputs: {self.config.output[k].parent}"
            )
            self.config.output[k].parent.mkdir(exist_ok=True, parents=True)

    def download(self, cache: bool = True) -> list[dict]:
        """Download data based on specification of config"""

        logger.info(f"Downloading for {self.config.name}")

        datetime_ranges = self._chunk_datetime()

        data = []

        if self.with_tqdm:
            loop_through = tqdm(datetime_ranges)
            loop_through.set_description(
                f"{self.config.start_date}-{self.config.end_date}"
            )
        else:
            loop_through = datetime_ranges

        for download_start, download_end in loop_through:
            try:
                batch_data = self.download_segment(download_start, download_end)
                data += batch_data
                if cache:
                    logger.debug(
                        f"Caching in the jsonl file: {self.config.output['jsonl']}"
                    )
                    orjsonl.extend(self.config.output["jsonl"], batch_data)
            except Exception as e:
                logger.error(
                    f"{self.config.name}: {download_start} - {download_end}: Error downloading': {e}"
                )

        return data

    def _chunk_datetime(self) -> list[tuple[datetime.datetime, datetime.datetime]]:

        segment_delta = datetime.timedelta(days=self.config.segment_length)
        download_start = self.config.start_date
        download_end = self.config.start_date + segment_delta

        datetime_ranges = []

        if download_end >= self.config.end_date:
            datetime_ranges.append((download_start, self.config.end_date))
        else:
            while download_start < self.config.end_date:
                datetime_ranges.append(
                    (download_start, download_end - datetime.timedelta(microseconds=1))
                )

                download_start += segment_delta
                download_end = min(download_start + segment_delta, self.config.end_date)

        return datetime_ranges

    @staticmethod
    def _convert_str_to_dt(data_entry: dict) -> dict:
        """Convert the timestamp in the return data to datetime"""
        data_entry["Timestamp"] = datetime.datetime.strptime(
            data_entry["Timestamp"], "%Y-%m-%dT%H:%M:%SZ"
        )
        return data_entry

    @staticmethod
    def _add_attribute_name(data_entry: dict, attribute_path: str) -> dict:
        """The returned data from PI doesn't have the path in it.

        We add the path as Parameter in the data
        """
        data_entry["Parameter"] = attribute_path
        return data_entry

    def __call__(self, save: bool = True, cache: bool = True) -> list[dict]:
        data = self.download(cache=cache)

        if save:
            with open(self.config.output["json"], "+w") as fp:
                json.dump(data, fp)

        return data

    def download_segment(
        self, start: datetime.datetime, end: datetime.datetime
    ) -> list[dict]:
        """Download one segment"""
        logger.info(f"Downloading time segment {start} - {end}...")

        data = []

        for attribute in self.config.attributes:
            logger.debug(f"Downloading attribute {attribute} for {start} - {end}")
            attribute_path = attribute["path"]

            attribute_webid = self.webids[attribute_path]

            raw_data = self.get_interpolated_data(
                self.config.webapi, attribute_webid, start, end, self.config.interval_in_minutes
            )

            data += [self._add_attribute_name(d, attribute_path) for d in raw_data]

        return data

    def get_interpolated_data(
        self, webapi, webid, start_date, end_date, interval
    ) -> list[dict]:
        """download the interpolated data from PI."""
        url = (
                f"{webapi}/streams/{webid}/interpolated?"
                f"startTime={start_date}&endTime={end_date}&interval={interval}m"
                "&selectedFields=Items.Timestamp;Items.Value;Items.Good;Items.Questionable"
            )
        try:
            logger.debug(f"Send request: {url}")
            response = self.retriever.get(url, auth=self.auth)
            if response.status_code == 200:
                data = response.json()["Items"]
            else:
                data = []

            return data

        except Exception as e:
            logger.error(f"Error retreiving WebId from '{url}': {e}")
            return []

    @cached_property
    def webids(self) -> dict[str, str]:
        """a webid is a dynamic id from PI system

        We retrieve all the web ids for each attribute
        """

        webids = {}
        for attribute in self.config.attributes:
            attribute_path = attribute["path"]
            webids[attribute_path] = self.get_webid(attribute_path)

        return webids

    def get_webid(self, attribute_path: str) -> str | None:
        try:
            path_in_url = rf"{self.config.element_base_path}\{attribute_path}"
            url = rf"{self.config.webapi}attributes"
            params = {"path": rf"{path_in_url}", "selectedFields": "WebId"}

            logger.debug(f"Send request: {url} with payload {params}")
            response = self.retriever.get(
                url,
                params=params,
                auth=self.auth,
            )

            data = response.json()
            return data["WebId"]

        except Exception as e:
            logger.error(f"Error retreiving WebId from '{url}': {e}")
            return None
