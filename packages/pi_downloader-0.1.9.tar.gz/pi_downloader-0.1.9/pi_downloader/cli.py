import sys

import click
from loguru import logger



from pi_downloader.config import Config
from pi_downloader.downloader import PIDownloader
from pi_downloader.utils.auth import OsiAuth
from pi_downloader.utils.web import DataRetriever

logger.remove()
logger.add(sys.stderr, level="WARNING")

try:
    from requests_kerberos import OPTIONAL, HTTPKerberosAuth
except Exception as e:
    logger.warning(f"Kerberos auth is not available: {e}")


@click.group()
def pi_downloader():
    click.echo("pi downloader")


@pi_downloader.command()
@click.option("--config", help="Path to the config file")
@click.option(
    "--auth-method",
    default="aws",
    type=click.Choice(["aws", "basic", "win"], case_sensitive=False),
    help="Auth method: aws (Secrets Manager), basic (username/password), or win (Kerberos)",
)
@click.option(
    "--secret-id",
    default="osipi_user_credentials",
    show_default=True,
    help="AWS Secrets Manager secret id for auth_method=aws",
)
@click.option(
    "--region",
    default="eu-west-1",
    show_default=True,
    help="AWS region for auth_method=aws",
)
@click.option(
    "--credential-file",
    type=click.Path(exists=True, dir_okay=False),
    help="Path to a JSON credential file for auth_method=basic",
)
@click.option(
    "--username",
    help="Username for auth_method=basic",
)
@click.option(
    "--password",
    help="Password for auth_method=basic",
)
def download(config, auth_method, secret_id, region, credential_file, username, password):
    config = Config(path=config)

    logger.info(f"Authorizing using {auth_method}")
    if auth_method == "aws":
        logger.info("Using AWS authentication")
        auth = OsiAuth(secret_id=secret_id, region=region)
    elif auth_method == "basic":
        logger.info("Using basic authentication")
        if credential_file is None and username is None:
            username = click.prompt("PI username")
        if credential_file is None and password is None:
            password = click.prompt("PI password", hide_input=True)

        auth = OsiAuth(
            username=username,
            password=password,
            credential_file=credential_file,
        )
    elif auth_method == "win":
        logger.info("Using Kerberos authentication")
        auth = HTTPKerberosAuth(mutual_authentication=OPTIONAL)
    else:
        raise ValueError(f"Authorization method {auth_method} is not supported.")

    downloader = PIDownloader(
        auth=auth, config=config, retriever=DataRetriever(), with_tqdm=True
    )

    logger.info(f"Downloader thread for {config.name} started")

    downloader()


if __name__ == "__main__":
    pi_downloader()
