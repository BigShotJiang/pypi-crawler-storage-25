import json
from functools import cached_property
from pathlib import Path
from typing import Optional

import boto3
from requests.auth import HTTPBasicAuth


class OsiAuth(HTTPBasicAuth):
    """Class to handle OSI PI authentication using AWS Secrets Manager.

    :param secret_id: the secret id in secret manager
    :param region: region of the aws account
    """

    def __init__(
        self,
        secret_id: str = "osipi_user_credentials",
        region: str = "eu-west-1",
        username: Optional[str] = None,
        password: Optional[str] = None,
        credential_file: Optional[str | Path] = None,
    ):

        self.secret_id = secret_id
        self.region = region
        self.credentials = self._resolve_credentials(
            username=username,
            password=password,
            credential_file=credential_file,
        )

        super().__init__(self.credentials["userName"], self.credentials["passWord"])

    def _resolve_credentials(
        self,
        username: Optional[str],
        password: Optional[str],
        credential_file: Optional[str | Path],
    ) -> dict[str, str]:
        if username is not None or password is not None:
            if not username or not password:
                raise ValueError("Both username and password must be provided.")
            return {"userName": username, "passWord": password}

        if credential_file is not None:
            return self._get_cred_from_file(credential_file)

        return self._get_cred_from_secret_manager()

    @staticmethod
    def _normalize_cred(cred: dict) -> dict[str, str]:
        username = cred.get("userName") or cred.get("username")
        password = cred.get("passWord") or cred.get("password")

        if not username or not password:
            raise ValueError(
                "Credential content must include username/userName and password/passWord."
            )

        return {"userName": username, "passWord": password}

    def _get_cred_from_file(self, credential_file: str | Path) -> dict[str, str]:
        with open(credential_file, "r") as fp:
            return self._normalize_cred(json.load(fp))

    def _get_cred_from_secret_manager(self) -> dict[str, str]:
        return self._normalize_cred(
            json.loads(
                self.aws_secret_client.get_secret_value(SecretId=self.secret_id)[
                    "SecretString"
                ]
            )
        )

    def _get_cred(self) -> dict:
        # Backward-compatible alias.
        return self._get_cred_from_secret_manager()

    @cached_property
    def aws_secret_client(self) -> boto3.client:
        return boto3.client("secretsmanager", region_name=self.region)
