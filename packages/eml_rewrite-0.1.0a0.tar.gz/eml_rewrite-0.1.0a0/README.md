# eml-rewrite

**Pre-release. Patent pending.** Not for redistribution.

F-family fusion pattern rewriter for symbolic expressions. Detects
equivalent rewrites that strictly reduce predicted EML cost (per
[`eml-cost`](../eml-cost-pkg)). Provable non-regression: every proposed
rewrite either improves the cost or is filtered out.

## Status

Pre-release. Covered by Monogate Research patent applications #11 and
#12 (filed 2026-04-25). Public release follows post-prosecution licensing.

## Library API

```python
from eml_rewrite import suggest, best, score, Suggestion
import sympy as sp

x = sp.Symbol("x", real=True)

# Find improving rewrites (provably non-regressing)
sugg = suggest(sp.exp(x) / (1 + sp.exp(x)))
# [Suggestion(pattern_name="sigmoid",
#             rewritten=1/(1 + exp(-x)),
#             score_before=3, score_after=2, reduction=1)]

# Pick the lowest-score rewrite, or original if no improvement
best(sp.sinh(x) / sp.cosh(x))
# tanh(x)

best(sp.exp(sp.exp(x)))
# exp(exp(x))   ← original; nothing in library matches
```

## Pattern library (9)

1. `exp(x)/(1+exp(x))` → `1/(1+exp(-x))` — sigmoid canonicalization
2. `sinh(x)/cosh(x)` → `tanh(x)` — F-family fusion
3. `(exp(x)+exp(-x))/2` → `cosh(x)` — hyperbolic fusion
4. `(exp(x)-exp(-x))/2` → `sinh(x)` — hyperbolic fusion
5. `sin(x)² + cos(x)²` → `1` — Pythagorean identity
6. `cosh(x)² - sinh(x)²` → `1` — hyperbolic identity
7. `exp(log(x))`, `log(exp(x))` → `x` — inverse pair
8. `log(a/b)` → `log(a) - log(b)` — when score improves
9. `log(x^n)` → `n·log(x)` — when score improves

## Command line

```
eml-rewrite scan FILE [FILE ...]    # report rewrites without applying
eml-rewrite fix  FILE [FILE ...]    # show rewrites that would be applied
eml-rewrite analyze "exp(sin(x))"   # full Pfaffian profile + suggestions
```

Example:

```
$ eml-rewrite analyze "exp(x)/(1 + exp(x))"
Expression:           exp(x)/(1 + exp(x))
  pfaffian_r:           1
  max_path_r:           1
  eml_depth:            2
  structural_overhead:  3
  corrections:          Corrections(c_osc=0, c_composite=0, delta_fused=0)
  predicted_depth:      4
  is_pfaffian_not_eml:  False

Suggested rewrites (1):
  [sigmoid] 1/(1 + exp(-x))  (-1 cost units)
```

## Provable non-regression

The library's headline guarantee:

```python
for expr in any_collection:
    for s in suggest(expr, only_improvements=True):
        assert s.score_after < s.score_before  # always
```

Every rewrite returned with `only_improvements=True` strictly reduces
the EML predicted depth. The test suite validates this on a hand-checked
panel; the engine filters non-improvements before returning them.

## Installation (pre-release, local only)

```bash
pip install -e /path/to/eml-rewrite-pkg
```

Requires `eml-cost` (also pre-release).

## License

`PROPRIETARY-PRE-RELEASE`. See LICENSE.
