"""Tests for ContextVar-based turn tracking."""

from __future__ import annotations

import asyncio

import pytest

from voxgraph.context import (
    TurnContext,
    get_current_session_id,
    get_current_turn,
    get_current_turn_id,
    vox_turn_context,
)


class TestTurnContext:
    """Tests for the TurnContext dataclass."""

    def test_immutable(self):
        ctx = TurnContext(turn_id="t1", session_id="s1", job_id="j1")
        with pytest.raises(AttributeError):
            ctx.turn_id = "modified"  # type: ignore

    def test_fields(self):
        ctx = TurnContext(turn_id="abc", session_id="def", job_id="ghi")
        assert ctx.turn_id == "abc"
        assert ctx.session_id == "def"
        assert ctx.job_id == "ghi"


class TestContextManager:
    """Tests for the vox_turn_context context manager."""

    def test_sets_and_resets_context(self):
        assert get_current_turn() is None

        with vox_turn_context("t1", "s1", "j1") as ctx:
            assert get_current_turn() is not None
            assert ctx.turn_id == "t1"

        assert get_current_turn() is None

    def test_resets_on_exception(self):
        with pytest.raises(ValueError):
            with vox_turn_context("t1", "s1", "j1"):
                raise ValueError("boom")

        # Context should be cleaned up even after exception
        assert get_current_turn() is None

    def test_nesting(self):
        with vox_turn_context("outer", "s1", "j1"):
            assert get_current_turn_id() == "outer"

            with vox_turn_context("inner", "s2", "j2"):
                assert get_current_turn_id() == "inner"
                assert get_current_session_id() == "s2"

            # Outer context restored after inner exits
            assert get_current_turn_id() == "outer"

        assert get_current_turn() is None


class TestConvenienceAccessors:
    """Tests for get_current_turn_id and get_current_session_id."""

    def test_returns_none_when_no_context(self):
        assert get_current_turn_id() is None
        assert get_current_session_id() is None

    def test_returns_values_when_context_set(self):
        with vox_turn_context("t1", "s1", "j1"):
            assert get_current_turn_id() == "t1"
            assert get_current_session_id() == "s1"


class TestAsyncIsolation:
    """Tests that context is properly isolated between concurrent async tasks."""

    @pytest.mark.asyncio
    async def test_concurrent_tasks_isolated(self):
        """Two concurrent tasks should see their own context, not each other's."""
        results: dict[str, str | None] = {}

        async def task_a():
            with vox_turn_context("task_a_turn", "sess_a", "job_a"):
                await asyncio.sleep(0.01)  # yield control
                results["a"] = get_current_turn_id()

        async def task_b():
            with vox_turn_context("task_b_turn", "sess_b", "job_b"):
                await asyncio.sleep(0.01)  # yield control
                results["b"] = get_current_turn_id()

        await asyncio.gather(task_a(), task_b())

        assert results["a"] == "task_a_turn"
        assert results["b"] == "task_b_turn"

    @pytest.mark.asyncio
    async def test_no_context_leakage_after_task(self):
        """After a task with context finishes, the outer scope should have no context."""
        assert get_current_turn() is None

        async def inner():
            with vox_turn_context("inner", "s", "j"):
                return get_current_turn_id()

        result = await inner()
        assert result == "inner"
        assert get_current_turn() is None
