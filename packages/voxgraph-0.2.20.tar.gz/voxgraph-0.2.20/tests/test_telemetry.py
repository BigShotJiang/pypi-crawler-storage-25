"""Tests for the telemetry collector and sender."""

from __future__ import annotations

import asyncio

import pytest

from voxgraph.config import VoxConfig
from voxgraph.models import LogEntry, SessionMeta
from voxgraph.telemetry import TelemetryCollector, TelemetrySender


class TestTelemetryCollector:
    def test_record_log(self, collector: TelemetryCollector):
        entry = LogEntry(message="test", turn_id="t1")
        collector.record_log(entry)

        batch = collector.collect_batch(10)
        assert len(batch) == 1
        assert batch[0]["type"] == "log"

    def test_record_session_meta(self, collector: TelemetryCollector):
        meta = SessionMeta(session_id="vox_abc", prompt_version="v2.1")
        collector.record_session_meta(meta)

        batch = collector.collect_batch(10)
        assert len(batch) == 1
        assert batch[0]["type"] == "session_meta"
        assert batch[0]["data"]["prompt_version"] == "v2.1"

    def test_bounded_buffer_drops_oldest(self):
        """When buffer is full, oldest items are dropped."""
        small_collector = TelemetryCollector(max_buffer_size=3)

        for i in range(5):
            small_collector.record_log(LogEntry(message=f"msg_{i}"))

        assert small_collector.pending_count == 3
        assert small_collector.dropped_count == 2

        batch = small_collector.collect_batch(10)
        assert len(batch) == 3

    def test_collect_batch_respects_max_items(self, collector: TelemetryCollector):
        for i in range(10):
            collector.record_log(LogEntry(message=f"msg_{i}"))

        batch = collector.collect_batch(max_items=3)
        assert len(batch) == 3
        assert collector.pending_count == 7

    def test_empty_collect(self, collector: TelemetryCollector):
        batch = collector.collect_batch(10)
        assert batch == []


class TestTelemetrySender:
    @pytest.mark.asyncio
    async def test_debug_mode_no_api_key(self, vox_config: VoxConfig):
        """In debug mode without API key, sender should log and return True."""
        config = VoxConfig(debug=True, api_key="", flush_interval_s=0.1)
        collector = TelemetryCollector()
        sender = TelemetrySender(config, collector)
        sender.set_session_id("vox_test")

        await sender.start()
        collector.record_log(LogEntry(message="debug test"))

        await asyncio.sleep(0.3)
        await sender.drain()

    @pytest.mark.asyncio
    async def test_drain_flushes_all(self, vox_config: VoxConfig):
        """Drain should attempt to send all buffered items."""
        config = VoxConfig(debug=True, api_key="", flush_interval_s=10.0)
        collector = TelemetryCollector()
        sender = TelemetrySender(config, collector)
        sender.set_session_id("vox_test")

        await sender.start()

        for i in range(5):
            collector.record_log(LogEntry(message=f"msg_{i}"))

        assert collector.pending_count == 5

        await sender.drain()
        assert collector.pending_count == 0

    @pytest.mark.asyncio
    async def test_send_report_includes_new_fields(self):
        """_send_report must forward all 6 fields that session.py injects into report_dict."""
        import httpx
        from unittest.mock import MagicMock

        captured: list[dict] = []

        async def fake_post(url, *, json=None, **kwargs):
            captured.append(json or {})
            resp = MagicMock(spec=httpx.Response)
            resp.status_code = 200
            return resp

        config = VoxConfig(api_key="test-key", flush_interval_s=60.0)
        collector = TelemetryCollector()
        sender = TelemetrySender(config, collector)
        sender.set_session_id("vox_test")
        sender.set_conversation_id("conv-123")

        await sender.start()
        sender._client.post = fake_post  # type: ignore[method-assign]

        report_dict = {
            "job_id": "job-1",
            "room_id": "room-1",
            "started_at": 1000.0,
            "timestamp": 1060.0,
            "chat_history": {"items": []},
            "events": [],
            "duration_seconds": 60,
            "ended_reason": "user_initiated",
            "call_type": "inbound",
            "call_channel": "phone",
            "recording_url": "https://bucket.s3.region.amazonaws.com/recordings/conv-123.wav",
            "recording_started_at": 1000.5,
        }

        await sender._send_report(report_dict)

        assert len(captured) == 1, "Expected exactly one HTTP POST"
        payload = captured[0]
        assert payload["duration_seconds"] == 60
        assert payload["ended_reason"] == "user_initiated"
        assert payload["call_type"] == "inbound"
        assert payload["call_channel"] == "phone"
        assert payload["recording_url"] == "https://bucket.s3.region.amazonaws.com/recordings/conv-123.wav"
        assert payload["recording_started_at"] == 1000.5
        # tools field must be forwarded as-is
        assert payload.get("tools") is None  # report_dict had no tools key

    @pytest.mark.asyncio
    async def test_send_report_forwards_agent_tool_map(self):
        """_send_report forwards the per-agent tool snapshot list to the backend."""
        import httpx
        from unittest.mock import MagicMock

        captured: list[dict] = []

        async def fake_post(url, *, json=None, **kwargs):
            captured.append(json or {})
            resp = MagicMock(spec=httpx.Response)
            resp.status_code = 200
            return resp

        config = VoxConfig(api_key="test-key", flush_interval_s=60.0)
        collector = TelemetryCollector()
        sender = TelemetrySender(config, collector)
        sender.set_session_id("vox_test")
        sender.set_conversation_id("conv-456")

        await sender.start()
        sender._client.post = fake_post  # type: ignore[method-assign]

        # Per-agent snapshot format matching _extract_agent_tool_map output
        tool_map = [
            {
                "agent_id": "triage_agent",
                "sequence": 0,
                "tools": [{"name": "lookup", "description": "Look up account", "parameters": {}}],
            },
            {
                "agent_id": "booking_agent",
                "sequence": 1,
                "tools": [{"name": "create_booking", "description": "Create a booking", "parameters": {}}],
            },
        ]

        report_dict = {
            "job_id": "job-2",
            "room_id": "room-2",
            "started_at": 2000.0,
            "timestamp": 2060.0,
            "chat_history": {"items": []},
            "events": [],
            "tools": tool_map,
        }

        await sender._send_report(report_dict)

        assert len(captured) == 1
        payload = captured[0]
        assert payload["tools"] == tool_map, "tools snapshot list must be forwarded verbatim"

