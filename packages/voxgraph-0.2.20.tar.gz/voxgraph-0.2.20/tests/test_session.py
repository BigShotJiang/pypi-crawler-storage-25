"""Tests for VoxSession._extract_agent_tool_map()."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock

import pytest

from voxgraph.session import VoxSession


# ---------------------------------------------------------------------------
# Minimal stubs for LiveKit objects
# ---------------------------------------------------------------------------


def _make_function_tool(name: str, description: str, parameters: dict) -> MagicMock:
    """Return a minimal FunctionTool stand-in."""
    from livekit.agents import llm

    tool = MagicMock(spec=llm.FunctionTool)
    tool.info = MagicMock()
    tool.info.name = name
    tool.info.description = description
    return tool


def _make_config_update(agent_id: str, tool_objects: list | None) -> MagicMock:
    """Return a minimal AgentConfigUpdate stand-in."""
    from livekit.agents import llm

    item = MagicMock(spec=llm.AgentConfigUpdate)
    item.agent_id = agent_id
    item._tools = tool_objects
    return item


def _make_report(items: list) -> MagicMock:
    """Return a minimal SessionReport stand-in with chat_history.items."""
    chat_history = MagicMock()
    chat_history.items = items
    report = MagicMock()
    report.chat_history = chat_history
    return report


# ---------------------------------------------------------------------------
# Tier 1: Runtime Snapshots (event-driven, version-safe)
# ---------------------------------------------------------------------------


class TestToolMapRuntimeSnapshots:
    """Tier 1: runtime snapshots take priority over everything else."""

    def test_runtime_snapshots_preferred(self):
        """When runtime_snapshots is non-empty, ignore chat history entirely."""
        snapshots = [
            {"agent_id": "agent_a", "trigger": "session_start", "tools": [
                {"name": "tool_1", "description": "desc", "parameters": {}},
            ]},
        ]
        report = _make_report([])

        result = VoxSession._extract_agent_tool_map(report, None, snapshots)
        assert result is not None
        assert len(result) == 1
        assert result[0]["agent_id"] == "agent_a"
        assert result[0]["sequence"] == 0
        assert result[0]["tools"][0]["name"] == "tool_1"

    def test_multiple_runtime_snapshots_handoff(self):
        """Multiple snapshots from handoffs get sequential sequences."""
        snapshots = [
            {"agent_id": "triage", "trigger": "session_start", "tools": [
                {"name": "transfer", "description": "Transfer", "parameters": {}},
            ]},
            {"agent_id": "booking", "trigger": "handoff", "tools": [
                {"name": "book", "description": "Book", "parameters": {}},
                {"name": "cancel", "description": "Cancel", "parameters": {}},
            ]},
        ]
        report = _make_report([])

        result = VoxSession._extract_agent_tool_map(report, None, snapshots)
        assert result is not None
        assert len(result) == 2
        assert result[0]["agent_id"] == "triage"
        assert result[0]["sequence"] == 0
        assert len(result[0]["tools"]) == 1
        assert result[1]["agent_id"] == "booking"
        assert result[1]["sequence"] == 1
        assert len(result[1]["tools"]) == 2

    def test_dynamic_tool_update_snapshots(self):
        """Config update snapshot captures new tool state."""
        snapshots = [
            {"agent_id": "default", "trigger": "session_start", "tools": [
                {"name": "search", "description": "Search", "parameters": {}},
            ]},
            {"agent_id": "default", "trigger": "config_update", "tools": [
                {"name": "search", "description": "Search", "parameters": {}},
                {"name": "escalate", "description": "Escalate", "parameters": {}},
            ]},
        ]
        report = _make_report([])

        result = VoxSession._extract_agent_tool_map(report, None, snapshots)
        assert len(result) == 2
        assert len(result[0]["tools"]) == 1
        assert len(result[1]["tools"]) == 2


# ---------------------------------------------------------------------------
# Tier 2: Chat History (AgentConfigUpdate._tools, >= 1.5)
# ---------------------------------------------------------------------------


class TestToolMapChatHistory:
    """Tier 2: fall back to AgentConfigUpdate._tools in chat history."""

    def _call(self, report: Any) -> list[dict] | None:
        return VoxSession._extract_agent_tool_map(report)

    def test_returns_none_for_empty_chat_ctx(self):
        report = _make_report([])
        assert self._call(report) is None

    def test_returns_none_when_no_config_updates(self):
        from livekit.agents import llm
        regular_msg = MagicMock(spec=llm.ChatMessage)
        report = _make_report([regular_msg])
        assert self._call(report) is None

    def test_returns_none_when_config_update_has_no_tools(self):
        item = _make_config_update("my_agent", None)
        report = _make_report([item])
        assert self._call(report) is None

    def test_single_agent_single_snapshot(self, monkeypatch):
        from livekit.agents import llm
        fake_schema = {"parameters": {"type": "object", "properties": {}}}
        monkeypatch.setattr(llm.utils, "build_legacy_openai_schema", lambda t, **kw: fake_schema)

        tool = MagicMock(spec=llm.FunctionTool)
        tool.info.name = "get_weather"
        tool.info.description = "Get the current weather"

        item = _make_config_update("weather_agent", [tool])
        report = _make_report([item])

        result = self._call(report)
        assert result is not None
        assert len(result) == 1
        assert result[0]["agent_id"] == "weather_agent"
        assert result[0]["sequence"] == 0
        assert result[0]["tools"][0]["name"] == "get_weather"

    def test_multi_agent_handoff(self, monkeypatch):
        from livekit.agents import llm
        monkeypatch.setattr(
            llm.utils, "build_legacy_openai_schema",
            lambda t, **kw: {"parameters": {"type": "object"}}
        )

        tool_a = MagicMock(spec=llm.FunctionTool)
        tool_a.info.name = "transfer"
        tool_a.info.description = "Transfer to another agent"

        tool_b = MagicMock(spec=llm.FunctionTool)
        tool_b.info.name = "book_appointment"
        tool_b.info.description = "Book an appointment"

        items = [
            _make_config_update("triage_agent", [tool_a]),
            _make_config_update("booking_agent", [tool_b]),
        ]
        report = _make_report(items)

        result = self._call(report)
        assert result is not None
        assert len(result) == 2
        assert result[0]["agent_id"] == "triage_agent"
        assert result[1]["agent_id"] == "booking_agent"

    def test_dynamic_tool_update_same_agent(self, monkeypatch):
        from livekit.agents import llm
        monkeypatch.setattr(
            llm.utils, "build_legacy_openai_schema",
            lambda t, **kw: {"parameters": {}}
        )

        tool_v1 = MagicMock(spec=llm.FunctionTool)
        tool_v1.info.name = "search"
        tool_v1.info.description = "Search the database"

        tool_v2a = MagicMock(spec=llm.FunctionTool)
        tool_v2a.info.name = "search"
        tool_v2a.info.description = "Search the database"

        tool_v2b = MagicMock(spec=llm.FunctionTool)
        tool_v2b.info.name = "escalate"
        tool_v2b.info.description = "Escalate to supervisor"

        items = [
            _make_config_update("support_agent", [tool_v1]),
            _make_config_update("support_agent", [tool_v2a, tool_v2b]),
        ]
        report = _make_report(items)

        result = self._call(report)
        assert len(result) == 2
        assert len(result[0]["tools"]) == 1
        assert len(result[1]["tools"]) == 2

    def test_raw_function_tool_serialization(self):
        from livekit.agents import llm

        raw_tool = MagicMock(spec=llm.RawFunctionTool)
        raw_tool.info.name = "raw_op"
        raw_tool.info.raw_schema = {
            "name": "raw_op",
            "description": "A raw tool",
            "parameters": {"type": "object"},
        }

        item = _make_config_update("raw_agent", [raw_tool])
        report = _make_report([item])

        result = self._call(report)
        assert result is not None
        assert result[0]["tools"][0]["name"] == "raw_op"
        assert result[0]["tools"][0]["description"] == "A raw tool"

    def test_falls_back_to_report_items_when_no_chat_ctx(self):
        from livekit.agents import llm

        raw_tool = MagicMock(spec=llm.RawFunctionTool)
        raw_tool.info.name = "fallback_tool"
        raw_tool.info.raw_schema = {"name": "fallback_tool", "description": None, "parameters": {}}

        item = _make_config_update("fb_agent", [raw_tool])

        report = MagicMock(spec=[])
        report.chat_ctx = None
        report.items = [item]

        result = self._call(report)
        assert result is not None
        assert result[0]["tools"][0]["name"] == "fallback_tool"

    def test_graceful_degradation_on_bad_report(self):
        result = self._call(None)
        assert result is None


# ---------------------------------------------------------------------------
# Tier 3: Session.tools shutdown fallback (1.4.x)
# ---------------------------------------------------------------------------


class TestToolMapSessionFallback:
    """Tier 3: session.tools at shutdown (last resort for 1.4.x)."""

    def test_session_tools_fallback(self, monkeypatch):
        from livekit.agents import llm
        monkeypatch.setattr(
            llm.utils, "build_legacy_openai_schema",
            lambda t, **kw: {"parameters": {"type": "object"}}
        )

        tool = MagicMock(spec=llm.FunctionTool)
        tool.info.name = "hangup"
        tool.info.description = "Hang up the call"

        session = MagicMock()
        session.current_agent = None
        session.tools = [tool]

        report = _make_report([])

        result = VoxSession._extract_agent_tool_map(report, session, None)
        assert result is not None
        assert len(result) == 1
        assert result[0]["agent_id"] == "default"
        assert result[0]["tools"][0]["name"] == "hangup"

    def test_toolset_flattening(self, monkeypatch):
        from livekit.agents import llm
        monkeypatch.setattr(
            llm.utils, "build_legacy_openai_schema",
            lambda t, **kw: {"parameters": {}}
        )

        sub_tool = MagicMock(spec=llm.FunctionTool)
        sub_tool.info.name = "nested_tool"
        sub_tool.info.description = "A nested tool"

        toolset = MagicMock()
        toolset.tools = [sub_tool]

        session = MagicMock()
        session.current_agent = None
        session.tools = [toolset]

        report = _make_report([])

        result = VoxSession._extract_agent_tool_map(report, session, None)
        assert result is not None
        assert result[0]["tools"][0]["name"] == "nested_tool"

    def test_returns_none_when_session_has_no_tools(self):
        session = MagicMock()
        session.current_agent = None
        session.tools = []
        report = _make_report([])

        result = VoxSession._extract_agent_tool_map(report, session, None)
        assert result is None


# ---------------------------------------------------------------------------
# Tests for _extract_usage() version branching
# ---------------------------------------------------------------------------

def _make_metrics_event(
    event_type: str,
    *,
    llm_prompt: int = 0,
    llm_completion: int = 0,
    stt_duration: float = 0.0,
    tts_chars: int = 0,
    provider: str = "openai",
    model: str = "gpt-4o",
) -> MagicMock:
    """Return a mock AgentEvent carrying metrics."""
    from unittest.mock import MagicMock
    event = MagicMock()
    event.type = event_type
    metrics = MagicMock()
    meta = MagicMock()
    meta.model_provider = provider
    meta.model_name = model
    metrics.metadata = meta
    metrics.prompt_tokens = llm_prompt
    metrics.completion_tokens = llm_completion
    metrics.audio_duration = stt_duration
    metrics.characters_count = tts_chars
    event.metrics = metrics
    return event


class TestExtractUsage:
    """Unit tests for VoxSession._extract_usage() version-gate dispatch."""

    def test_legacy_path_returns_correct_shape(self, monkeypatch):
        monkeypatch.setattr(
            "voxgraph.session.livekit_has_model_usage_collector",
            lambda: False,
        )

        from unittest.mock import MagicMock, patch

        summary = MagicMock()
        summary.llm_prompt_tokens = 100
        summary.llm_completion_tokens = 50
        summary.stt_audio_duration = 12.5
        summary.tts_characters_count = 300

        mock_collector_instance = MagicMock()
        mock_collector_instance.get_summary.return_value = summary

        from livekit.agents.metrics.base import LLMMetrics

        event = MagicMock()
        event.type = "metrics_collected"
        event.metrics = MagicMock(spec=LLMMetrics)
        event.metrics.metadata = MagicMock()
        event.metrics.metadata.model_provider = "openai"
        event.metrics.metadata.model_name = "gpt-4o"

        with patch(
            "voxgraph.session.VoxSession._extract_usage_legacy.__func__"
            if False else "livekit.agents.metrics.UsageCollector",
            return_value=mock_collector_instance,
        ):
            result = VoxSession._extract_usage_legacy([event])

        assert "llm_prompt_tokens" in result
        assert "llm_completion_tokens" in result
        assert "stt_audio_duration_seconds" in result
        assert "tts_characters_count" in result

    def test_dispatcher_selects_legacy_when_version_below_15(self, monkeypatch):
        called = []
        monkeypatch.setattr(
            "voxgraph.session.livekit_has_model_usage_collector",
            lambda: False,
        )
        monkeypatch.setattr(
            VoxSession,
            "_extract_usage_legacy",
            staticmethod(lambda events: called.append("legacy") or {}),
        )
        VoxSession._extract_usage([])
        assert called == ["legacy"]

    def test_dispatcher_selects_v15_when_version_at_or_above_15(self, monkeypatch):
        called = []
        monkeypatch.setattr(
            "voxgraph.session.livekit_has_model_usage_collector",
            lambda: True,
        )
        monkeypatch.setattr(
            VoxSession,
            "_extract_usage_v15",
            staticmethod(lambda events: called.append("v15") or {}),
        )
        VoxSession._extract_usage([])
        assert called == ["v15"]

    def test_empty_events_returns_valid_shape_legacy(self, monkeypatch):
        monkeypatch.setattr(
            "voxgraph.session.livekit_has_model_usage_collector",
            lambda: False,
        )
        result = VoxSession._extract_usage([])
        if result:
            assert "llm_prompt_tokens" in result

    def test_empty_events_returns_valid_shape_v15(self, monkeypatch):
        monkeypatch.setattr(
            "voxgraph.session.livekit_has_model_usage_collector",
            lambda: True,
        )
        result = VoxSession._extract_usage([])
        if result:
            assert "llm_prompt_tokens" in result


# ---------------------------------------------------------------------------
# Tests for _compat.py helpers
# ---------------------------------------------------------------------------


class TestCompatHelpers:
    """Unit tests for livekit_version() and livekit_has_model_usage_collector()."""

    def test_livekit_version_returns_tuple(self):
        from voxgraph._compat import livekit_version
        ver = livekit_version()
        assert isinstance(ver, tuple)
        assert all(isinstance(x, int) for x in ver)

    def test_livekit_version_is_cached(self):
        from voxgraph._compat import livekit_version
        assert livekit_version() is livekit_version()

    def test_has_model_usage_collector_returns_bool(self):
        from voxgraph._compat import livekit_has_model_usage_collector
        result = livekit_has_model_usage_collector()
        assert isinstance(result, bool)

    def test_has_model_usage_collector_true_for_v15(self, monkeypatch):
        import voxgraph._compat as compat
        monkeypatch.setattr(compat, "_LIVEKIT_VERSION_CACHE", (1, 5, 0))
        monkeypatch.setattr(compat, "_LIVEKIT_VERSION_RESOLVED", True)
        assert compat.livekit_has_model_usage_collector() is True

    def test_has_model_usage_collector_false_for_v14(self, monkeypatch):
        import voxgraph._compat as compat
        monkeypatch.setattr(compat, "_LIVEKIT_VERSION_CACHE", (1, 4, 6))
        monkeypatch.setattr(compat, "_LIVEKIT_VERSION_RESOLVED", True)
        assert compat.livekit_has_model_usage_collector() is False


# ---------------------------------------------------------------------------
# Tests for _json_safe() recursive sanitizer
# ---------------------------------------------------------------------------


class TestJsonSafe:
    """Unit tests for VoxSession._json_safe()."""

    def test_primitives_pass_through(self):
        assert VoxSession._json_safe(42) == 42
        assert VoxSession._json_safe("hello") == "hello"
        assert VoxSession._json_safe(True) is True
        assert VoxSession._json_safe(None) is None
        assert VoxSession._json_safe(3.14) == 3.14

    def test_dicts_and_lists(self):
        data = {"a": [1, "two", None], "b": {"nested": True}}
        assert VoxSession._json_safe(data) == data

    def test_non_serializable_coerced_to_str(self):
        class FakeLLM:
            def __str__(self):
                return "FakeLLM(model=gpt-4o)"

        data = {"turn_detection": FakeLLM(), "min_delay": 0.5}
        result = VoxSession._json_safe(data)
        assert result["turn_detection"] == "FakeLLM(model=gpt-4o)"
        assert result["min_delay"] == 0.5
        # Must be JSON serializable
        import json
        json.dumps(result)

    def test_nested_non_serializable(self):
        class FakeObj:
            pass

        data = {"options": {"nested": [FakeObj(), 42]}}
        result = VoxSession._json_safe(data)
        assert isinstance(result["options"]["nested"][0], str)
        assert result["options"]["nested"][1] == 42

    def test_tuple_converted_to_list(self):
        data = {"vals": (1, 2, 3)}
        result = VoxSession._json_safe(data)
        assert result["vals"] == [1, 2, 3]

