"""Tests for multi-region endpoint resolution in config.py."""

from __future__ import annotations

import os

import pytest

from voxgraph.config import (
    DEFAULT_ENDPOINT,
    REGION_ENDPOINTS,
    VoxConfig,
    _resolve_endpoint,
    load_config,
)


# ---------------------------------------------------------------------------
# _resolve_endpoint() unit tests
# ---------------------------------------------------------------------------


class TestResolveEndpoint:
    """Unit tests for the _resolve_endpoint() helper."""

    def test_eu_key_returns_eu_endpoint(self):
        endpoint, region = _resolve_endpoint("vxg_eu_abc123def456")
        assert endpoint == "https://eu.api.voxgraph.ai"
        assert region == "eu"

    def test_eu_key_case_insensitive(self):
        endpoint, region = _resolve_endpoint("vxg_EU_abc123")
        assert endpoint == "https://eu.api.voxgraph.ai"
        assert region == "eu"

    def test_no_region_prefix_returns_default(self):
        endpoint, region = _resolve_endpoint("vxg_abc123def456")
        assert endpoint == DEFAULT_ENDPOINT
        assert region == "default"

    def test_empty_key_returns_default(self):
        endpoint, region = _resolve_endpoint("")
        assert endpoint == DEFAULT_ENDPOINT
        assert region == "default"

    def test_unknown_region_returns_default(self):
        """An unrecognized region code falls back to the default endpoint."""
        endpoint, region = _resolve_endpoint("vxg_mars_abc123")
        assert endpoint == DEFAULT_ENDPOINT
        assert region == "default"

    def test_malformed_key_returns_default(self):
        endpoint, region = _resolve_endpoint("not_a_valid_key")
        assert endpoint == DEFAULT_ENDPOINT
        assert region == "default"

    def test_key_with_extra_underscores(self):
        """Secret portion may contain underscores — only first two splits matter."""
        endpoint, region = _resolve_endpoint("vxg_eu_abc_123_def")
        assert endpoint == "https://eu.api.voxgraph.ai"
        assert region == "eu"


# ---------------------------------------------------------------------------
# load_config() integration tests
# ---------------------------------------------------------------------------


class TestLoadConfigRegion:
    """Integration tests for region resolution in load_config()."""

    def test_eu_api_key_routes_to_eu(self):
        config = load_config(api_key="vxg_eu_test123")
        assert config.endpoint == "https://eu.api.voxgraph.ai"
        assert config.region == "eu"

    def test_plain_api_key_routes_to_default(self):
        config = load_config(api_key="vxg_test123")
        assert config.endpoint == DEFAULT_ENDPOINT
        assert config.region == "default"

    def test_dev_endpoint_overrides_region(self, monkeypatch):
        """VOXGRAPH_DEV_ENDPOINT takes precedence over API key region."""
        monkeypatch.setenv("VOXGRAPH_DEV_ENDPOINT", "http://localhost:8000")
        config = load_config(api_key="vxg_eu_test123")
        assert config.endpoint == "http://localhost:8000"
        assert config.region == "dev"

    def test_dev_endpoint_cleared_uses_key_region(self, monkeypatch):
        """Without DEV_ENDPOINT, the API key region determines the endpoint."""
        monkeypatch.delenv("VOXGRAPH_DEV_ENDPOINT", raising=False)
        config = load_config(api_key="vxg_eu_test123")
        assert config.endpoint == "https://eu.api.voxgraph.ai"
        assert config.region == "eu"

    def test_env_var_api_key_region(self, monkeypatch):
        """API key from env var is also parsed for region."""
        monkeypatch.delenv("VOXGRAPH_DEV_ENDPOINT", raising=False)
        monkeypatch.setenv("VOXGRAPH_API_KEY", "vxg_eu_envkey123")
        config = load_config()
        assert config.endpoint == "https://eu.api.voxgraph.ai"
        assert config.region == "eu"

    def test_region_field_is_readonly(self):
        config = load_config(api_key="vxg_eu_test123")
        with pytest.raises(AttributeError):
            config.region = "us"  # type: ignore[misc]


# ---------------------------------------------------------------------------
# VoxConfig dataclass field defaults
# ---------------------------------------------------------------------------


class TestVoxConfigDefaults:
    """Verify VoxConfig field defaults are correct after the refactor."""

    def test_default_endpoint_constant(self):
        assert DEFAULT_ENDPOINT == "https://api.voxgraph.ai"

    def test_region_endpoints_has_eu(self):
        assert "eu" in REGION_ENDPOINTS
        assert REGION_ENDPOINTS["eu"] == "https://eu.api.voxgraph.ai"

    def test_default_config_values(self):
        config = VoxConfig()
        assert config.endpoint == DEFAULT_ENDPOINT
        assert config.region == "default"
