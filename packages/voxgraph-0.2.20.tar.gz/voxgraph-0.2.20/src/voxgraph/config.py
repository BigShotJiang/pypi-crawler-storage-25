"""Voxgraph SDK configuration.

The backend endpoint defaults to the Voxgraph production API. For local
development, set the ``VOXGRAPH_DEV_ENDPOINT`` env var in the consuming
project's environment (e.g. ``http://localhost:8000``).

Only api_key is required. agent_id and environment are optional.

Multi-region support: the SDK automatically routes to the correct regional
backend based on the API key prefix. Keys in the format ``vxg_{region}_...``
(e.g. ``vxg_eu_abc123``) are routed to the corresponding regional endpoint.
Keys without a region prefix default to the global endpoint.
"""

from __future__ import annotations

import os
import warnings
from dataclasses import dataclass, field

__all__ = ["VoxConfig", "load_config"]

# ---------------------------------------------------------------------------
# Regional endpoint map
# ---------------------------------------------------------------------------
# Default (global) endpoint — used when the API key has no region prefix.
DEFAULT_ENDPOINT = "https://api.voxgraph.ai"

# Region code → backend URL.  Add new regions here as they are deployed.
REGION_ENDPOINTS: dict[str, str] = {
    "eu": "https://eu.api.voxgraph.ai",
}


def _resolve_endpoint(api_key: str) -> tuple[str, str]:
    """Derive the regional endpoint and region code from an API key.

    Key formats:
        ``vxg_{region}_{secret}``  → regional endpoint  (e.g. ``vxg_eu_abc123``)
        ``vxg_{secret}``           → default endpoint    (e.g. ``vxg_abc123``)
        anything else              → default endpoint

    Returns:
        A ``(endpoint, region)`` tuple.  ``region`` is ``"default"`` when no
        region prefix is detected.
    """
    parts = api_key.split("_", 2)
    if len(parts) >= 3 and parts[0] == "vxg":
        region = parts[1].lower()
        if region in REGION_ENDPOINTS:
            return REGION_ENDPOINTS[region], region
    return DEFAULT_ENDPOINT, "default"


@dataclass(frozen=True, slots=True)
class VoxConfig:
    """Immutable SDK configuration.

    The endpoint is automatically resolved from the API key's region prefix.
    It can be overridden via the ``VOXGRAPH_DEV_ENDPOINT`` env var for local
    development.
    """

    api_key: str = ""
    agent_id: str = ""
    environment: str = "main"  # Prompt branch: "main", "dev", "staging", etc.
    endpoint: str = DEFAULT_ENDPOINT  # Auto-resolved from API key region prefix
    region: str = "default"    # Derived region code (e.g. "eu", "default")
    batch_size: int = 50
    flush_interval_s: float = 1.0
    max_buffer_size: int = 1000
    max_retries: int = 3
    request_timeout_s: float = 10.0
    debug: bool = False         # Internal — set via VOXGRAPH_DEBUG env var only
    tags: dict[str, str] = field(default_factory=dict)


def load_config(
    *,
    api_key: str | None = None,
    agent_id: str | None = None,
    environment: str | None = None,
    tags: dict[str, str] | None = None,
) -> VoxConfig:
    """Create a VoxConfig from explicit arguments, falling back to env vars.

    Users provide: api_key, agent_id, environment.

    The backend endpoint is automatically resolved from the API key's region
    prefix (e.g. ``vxg_eu_...`` → ``eu.api.voxgraph.ai``).  Keys without a
    region prefix are routed to the default global endpoint.

    Supported env vars (fallback when the kwarg is not supplied):
        VOXGRAPH_API_KEY          — API key for the Voxgraph backend (required)
        VOXGRAPH_AGENT_ID         — UUID of the voice AI agent (optional)
        VOXGRAPH_ENVIRONMENT      — Prompt branch, default "main" (optional)
        VOXGRAPH_DEBUG            — SDK debug logging; "1"/"true"/"yes" (optional)
        VOXGRAPH_DEV_ENDPOINT     — Override backend URL for local dev (optional)
    """
    debug = os.environ.get("VOXGRAPH_DEBUG", "").lower() in ("1", "true", "yes")
    resolved_key = api_key or os.environ.get("VOXGRAPH_API_KEY", "")
    if not resolved_key:
        warnings.warn(
            "Voxgraph SDK: no API key provided. Set api_key= or VOXGRAPH_API_KEY. "
            "All telemetry will be silently discarded until a valid key is supplied.",
            UserWarning,
            stacklevel=3,
        )

    # Resolve endpoint: DEV_ENDPOINT override takes absolute precedence.
    dev_override = os.environ.get("VOXGRAPH_DEV_ENDPOINT")
    if dev_override:
        endpoint = dev_override
        region = "dev"
    else:
        endpoint, region = _resolve_endpoint(resolved_key)

    return VoxConfig(
        api_key=resolved_key,
        agent_id=agent_id or os.environ.get("VOXGRAPH_AGENT_ID", ""),
        environment=environment or os.environ.get("VOXGRAPH_ENVIRONMENT", "main"),
        endpoint=endpoint,
        region=region,
        debug=debug,
        tags=tags or {},
    )
