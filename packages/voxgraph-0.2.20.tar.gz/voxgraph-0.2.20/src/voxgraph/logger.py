"""Structured logging handler for Voxgraph SDK.

Provides two capabilities:
1. A logging.Handler that automatically tags log messages with the current
   turn context (turn_id, session_id) via ContextVar.
2. A `vox_logger` proxy for structured SDK logging with keyword arguments.

Design rationale:
- Zero third-party dependencies — uses only stdlib logging + json
- Attaches as a handler to Python's root logger — non-intrusive
- Lazy evaluation: only formats messages if the log level is met
- Buffers log entries and forwards them to a collector callback
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any, Callable

from voxgraph.context import get_current_turn
from voxgraph.models import LogEntry, LogLevel

__all__ = [
    "VoxLogHandler",
    "install_vox_log_handler",
    "uninstall_vox_log_handler",
    "vox_logger",
]


class VoxLogHandler(logging.Handler):
    """A logging.Handler that captures log records tagged with Voxgraph turn context.

    The handler converts each LogRecord into a VoxGraph LogEntry and forwards
    it to a configurable collector callback. If no turn context is active,
    logs are still captured but without turn_id/session_id.
    """

    def __init__(
        self,
        collector: Callable[[LogEntry], None],
        *,
        min_level: int = logging.INFO,
    ) -> None:
        """Initialize the handler.

        Args:
            collector: Callback that receives each LogEntry.
            min_level: Minimum log level to capture (default: INFO).
        """
        super().__init__(level=min_level)
        self._collector = collector

    def emit(self, record: logging.LogRecord) -> None:
        """Process a log record — tag it and forward to collector."""
        try:
            turn = get_current_turn()

            # Build extra dict from record, excluding standard fields
            extra: dict[str, Any] = {}
            standard_keys = {
                "name", "msg", "args", "created", "filename", "funcName",
                "levelname", "levelno", "lineno", "module", "msecs",
                "pathname", "process", "processName", "relativeCreated",
                "stack_info", "thread", "threadName", "exc_info", "exc_text",
                "message", "taskName",
            }
            for key, value in record.__dict__.items():
                if key not in standard_keys and not key.startswith("_"):
                    try:
                        # Only include JSON-serializable values
                        if isinstance(value, (str, int, float, bool, type(None))):
                            extra[key] = value
                    except (TypeError, ValueError):
                        pass

            entry = LogEntry(
                timestamp=record.created,
                level=LogLevel(record.levelname) if record.levelname in LogLevel.__members__ else LogLevel.INFO,
                message=self.format(record),
                logger_name=record.name,
                turn_id=turn.turn_id if turn else None,
                session_id=turn.session_id if turn else None,
                extra=extra,
            )

            self._collector(entry)

        except Exception:
            # Never let the logging handler crash the application
            self.handleError(record)


# Sentinel to track installed handler for cleanup
_installed_handler: VoxLogHandler | None = None


def install_vox_log_handler(
    collector: Callable[[LogEntry], None],
    *,
    min_level: int = logging.INFO,
) -> VoxLogHandler:
    """Install the VoxLogHandler on the root logger.

    This is non-intrusive — it adds our handler alongside any existing handlers.
    Call `uninstall_vox_log_handler()` to remove it.

    Args:
        collector: Callback that receives each LogEntry.
        min_level: Minimum log level to capture.

    Returns:
        The installed handler instance.
    """
    global _installed_handler

    # Remove any previously installed handler
    if _installed_handler is not None:
        uninstall_vox_log_handler()

    handler = VoxLogHandler(collector, min_level=min_level)
    logging.getLogger().addHandler(handler)
    _installed_handler = handler
    return handler


def uninstall_vox_log_handler() -> None:
    """Remove the VoxLogHandler from the root logger."""
    global _installed_handler
    if _installed_handler is not None:
        logging.getLogger().removeHandler(_installed_handler)
        _installed_handler = None


# ---------------------------------------------------------------------------
# vox_logger — structured JSON logger (stdlib only, no structlog dependency)
#
# Provides a BoundLogger-style API: vox_logger.info("msg", key="value")
# Each call emits a JSON line to stderr via stdlib logging and automatically
# injects the current Voxgraph turn context (turn_id, session_id, job_id).
# ---------------------------------------------------------------------------

_UNDERLYING_LOGGER = logging.getLogger("voxgraph.user")


def _emit(level: int, level_name: str, event: str, **kwargs: Any) -> None:
    """Emit one structured JSON log line with turn context injected."""
    if not _UNDERLYING_LOGGER.isEnabledFor(level):
        return

    turn = get_current_turn()
    record: dict[str, Any] = {
        "event": event,
        "level": level_name,
        "logger": "voxgraph.user",
        "timestamp": time.time(),
    }
    if turn:
        record["vox_turn_id"] = turn.turn_id
        record["vox_session_id"] = turn.session_id
        record["vox_job_id"] = turn.job_id
    record.update(kwargs)

    _UNDERLYING_LOGGER.log(level, json.dumps(record))


class _VoxLogger:
    """Lightweight structured logger with a BoundLogger-compatible call style.

    Usage::

        vox_logger.info("prompt fetched", version="v3", latency_ms=42)
        vox_logger.warning("rate limited", retry_after=5)
        vox_logger.error("tool failed", tool="book_appointment", error=str(e))
    """

    def debug(self, event: str, **kwargs: Any) -> None:
        _emit(logging.DEBUG, "debug", event, **kwargs)

    def info(self, event: str, **kwargs: Any) -> None:
        _emit(logging.INFO, "info", event, **kwargs)

    def warning(self, event: str, **kwargs: Any) -> None:
        _emit(logging.WARNING, "warning", event, **kwargs)

    def warn(self, event: str, **kwargs: Any) -> None:
        _emit(logging.WARNING, "warning", event, **kwargs)

    def error(self, event: str, **kwargs: Any) -> None:
        _emit(logging.ERROR, "error", event, **kwargs)

    def critical(self, event: str, **kwargs: Any) -> None:
        _emit(logging.CRITICAL, "critical", event, **kwargs)

    def bind(self, **new_values: Any) -> "_BoundVoxLogger":
        """Return a new logger with the given key-value pairs pre-bound."""
        return _BoundVoxLogger(new_values)


class _BoundVoxLogger:
    """A _VoxLogger with pre-bound context key-value pairs."""

    def __init__(self, bound: dict[str, Any]) -> None:
        self._bound = bound

    def debug(self, event: str, **kwargs: Any) -> None:
        _emit(logging.DEBUG, "debug", event, **{**self._bound, **kwargs})

    def info(self, event: str, **kwargs: Any) -> None:
        _emit(logging.INFO, "info", event, **{**self._bound, **kwargs})

    def warning(self, event: str, **kwargs: Any) -> None:
        _emit(logging.WARNING, "warning", event, **{**self._bound, **kwargs})

    def warn(self, event: str, **kwargs: Any) -> None:
        _emit(logging.WARNING, "warning", event, **{**self._bound, **kwargs})

    def error(self, event: str, **kwargs: Any) -> None:
        _emit(logging.ERROR, "error", event, **{**self._bound, **kwargs})

    def critical(self, event: str, **kwargs: Any) -> None:
        _emit(logging.CRITICAL, "critical", event, **{**self._bound, **kwargs})

    def bind(self, **new_values: Any) -> "_BoundVoxLogger":
        return _BoundVoxLogger({**self._bound, **new_values})


vox_logger: _VoxLogger = _VoxLogger()

