"""Pydantic v2 data models for Voxgraph SDK telemetry payloads.

Lean SDK: only models for data the session report can't provide.
- LogEntry: context-tagged developer logs
- SessionMeta: prompt version, tags, cost (sent at session end)

Transcripts, latency, tool calls, events, and usage are all handled by
ctx.make_session_report() and sent via the /report endpoint.
"""

from __future__ import annotations

import time
from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

__all__ = [
    "LogLevel",
    "LogEntry",
    "SessionMeta",
]


class LogLevel(str, Enum):
    """Standard Python log levels."""

    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class LogEntry(BaseModel):
    """A single log line tagged with turn context."""

    model_config = ConfigDict(frozen=True)

    timestamp: float = Field(default_factory=time.time)
    level: LogLevel = LogLevel.INFO
    message: str = ""
    logger_name: str = ""
    turn_id: str | None = None
    session_id: str | None = None
    extra: dict[str, Any] = Field(default_factory=dict)



class SessionMeta(BaseModel):
    """SDK-exclusive metadata sent at session end.

    Contains prompt version, environment, tags, and cost — data the session
    report does not provide.
    """

    model_config = ConfigDict(frozen=True)

    session_id: str
    prompt_version: str = ""
    environment: str = "main"
    tags: dict[str, str] = Field(default_factory=dict)
