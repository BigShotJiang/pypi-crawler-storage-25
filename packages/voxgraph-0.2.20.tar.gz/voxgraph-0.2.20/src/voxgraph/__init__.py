"""Voxgraph SDK — Observability for LiveKit Voice Agents.

Usage:
    from voxgraph import VoxSession

    session = AgentSession(stt=..., llm=..., tts=...)
    vox = VoxSession(
        session,
        api_key="vxg_...",
        agent_id="550e8400-...",  # optional, for prompt fetch and agent routing
    )
    await vox.start(agent=my_agent, room=ctx.room)
"""

from voxgraph._version import __version__
from voxgraph.config import VoxConfig, load_config
from voxgraph.context import (
    TurnContext,
    get_current_session_id,
    get_current_turn,
    get_current_turn_id,
    vox_turn_context,
)
from voxgraph.logger import vox_logger
from voxgraph.session import VoxSession

__all__ = [
    # Core
    "VoxSession",
    "VoxConfig",
    "load_config",
    # Context
    "TurnContext",
    "vox_turn_context",
    "get_current_turn",
    "get_current_turn_id",
    "get_current_session_id",
    # Logging
    "vox_logger",
    # Version
    "__version__",
]
