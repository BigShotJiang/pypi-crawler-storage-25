from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable


def _print_text(text: str) -> str:
    cleaned = text.strip()
    print(cleaned)
    return cleaned


class _Listable:
    def listing(self) -> list[str]:
        names: list[str] = []
        for name in dir(self):
            if name.startswith("_"):
                continue
            value = getattr(self, name)
            if callable(value):
                names.append(name)
        names.sort()
        print("\n".join(names))
        return names

    def help(self) -> str:
        names = self.listing()
        text = "\n".join(f"{index}. {name}" for index, name in enumerate(names, start=1))
        print(text)
        return text


class _TextStore:
    def __init__(self, base_dir: Path) -> None:
        self.base_dir = base_dir
        packaged_ty_codes = base_dir / "data" / "TY_Codes"
        legacy_ty_codes = base_dir / "TY_Codes"
        self.ty_codes = packaged_ty_codes if packaged_ty_codes.exists() else legacy_ty_codes
        self.pl_programs = self.ty_codes / "PL" / "programs.txt"
        self.pl_problem_statements = self.ty_codes / "PL" / "problem_statements.txt"
        self.dstl_practical2 = self.ty_codes / "DSTL" / "practical2.txt"
        self.dstl_practical7 = self.ty_codes / "DSTL" / "practical7.txt"
        self.dstl_practical3 = self.ty_codes / "DSTL" / "Practical_3 (1).ipynb"

    def read(self, path: Path) -> str:
        return self._clean_text(path.read_text(encoding="utf-8"))

    def between(self, text: str, start: str, end: str | None = None) -> str:
        start_index = text.index(start)
        if end is None:
            return text[start_index:].strip()
        end_index = text.index(end, start_index)
        return text[start_index:end_index].strip()

    def _clean_text(self, text: str) -> str:
        return text.replace("\f", "")

    def numbered_problem_statements(self, numbers: Iterable[int]) -> str:
        lines = self.read(self.pl_problem_statements).splitlines()
        chosen: list[str] = []
        capture = False
        current = None

        wanted = set(numbers)
        for line in lines:
            stripped = line.strip()
            if not stripped:
                if capture and chosen and chosen[-1] != "":
                    chosen.append("")
                continue

            if stripped[:2].isdigit() and stripped[1] == ".":
                current = int(stripped.split(".", 1)[0])
                capture = current in wanted
                if capture:
                    chosen.append(stripped)
                continue

            if len(stripped) > 2 and stripped[0].isdigit() and stripped[1:3] == ". ":
                current = int(stripped.split(".", 1)[0])
                capture = current in wanted
                if capture:
                    chosen.append(stripped)
                continue

            if capture:
                chosen.append(stripped)

        return "\n".join(chosen).strip()

    def practical3_code(self) -> str:
        notebook = json.loads(self.read(self.dstl_practical3))
        blocks: list[str] = []
        for index, cell in enumerate(notebook.get("cells", []), start=1):
            if cell.get("cell_type") != "code":
                continue
            source = "".join(cell.get("source", [])).strip()
            if source:
                blocks.append(f"# Cell {index}\n{source}")
        return "\n\n".join(blocks).strip()


class _PLTopic(_Listable):
    def __init__(self, store: _TextStore, program_text: str, top_numbers: Iterable[int]) -> None:
        self._store = store
        self._program_text = program_text
        self._top_numbers = list(top_numbers)

    def top(self) -> str:
        return _print_text(self._store.numbered_problem_statements(self._top_numbers))

    def _show(self, start: str, end: str | None = None) -> str:
        return _print_text(self._store.between(self._program_text, start, end))


class _RawTextTopic(_Listable):
    def __init__(self, text_getter) -> None:
        self._text_getter = text_getter

    def show(self) -> str:
        return _print_text(self._text_getter())

    def instructions(self) -> str:
        return self.show()

    def help(self) -> str:
        text = "\n".join(
            [
                "1. show",
                "2. instructions",
                "",
                "Example:",
                "topic.show()",
                "topic.instructions()",
            ]
        )
        print(text)
        return text


class DSTLMongoDB(_Listable):
    def __init__(self, store: _TextStore) -> None:
        self._store = store

    def api_code(self) -> str:
        text = self._store.read(self._store.dstl_practical7)
        start = "Step 6: Create API (app.py)"
        end = "Step 7: Run API Server"
        section = self._store.between(text, start, end)
        return _print_text(section)

    def instructions(self) -> str:
        return _print_text(self._store.read(self._store.dstl_practical7))

    def show(self) -> str:
        return self.api_code()

    def help(self) -> str:
        text = "\n".join(
            [
                "1. api_code",
                "2. instructions",
                "3. show",
                "",
                "Example:",
                "dstl.mongodb.api_code()",
                "dstl.mongodb.instructions()",
            ]
        )
        print(text)
        return text


class PLActivationFunctions(_PLTopic):
    def basic_activation_function_visualizer(self) -> str:
        return self._show(
            "Problem 1: Basic Activation Function Visualizer",
            "Problem 2: Activation Functions on Real Data Distribution",
        )

    def activation_functions_on_real_data_distribution(self) -> str:
        return self._show(
            "Problem 2: Activation Functions on Real Data Distribution",
            "Problem 3: Effect of Activation Functions on Gradient Flow (Vanishing",
        )

    def effect_of_activation_functions_on_gradient_flow(self) -> str:
        return self._show(
            "Problem 3: Effect of Activation Functions on Gradient Flow (Vanishing",
            "Problem 4: Training a Neural Network with Different Activation Functions on",
        )

    def training_nn_with_different_activations_on_mnist(self) -> str:
        return self._show(
            "Problem 4: Training a Neural Network with Different Activation Functions on",
            "Problem 5: Decision Boundary Visualization with Different Activations",
        )

    def decision_boundary_visualization(self) -> str:
        return self._show(
            "Problem 5: Decision Boundary Visualization with Different Activations",
            "Problem 6: Activation Function Behavior in CNN Feature Maps",
        )

    def cnn_feature_map_activation_behavior(self) -> str:
        return self._show(
            "Problem 6: Activation Function Behavior in CNN Feature Maps",
            "Problem 7: Activation Function Output Range & Saturation Analysis",
        )

    def output_range_and_saturation_analysis(self) -> str:
        return self._show(
            "Problem 7: Activation Function Output Range & Saturation Analysis",
            "Problem 8: Custom Activation Function Benchmarking on Regression",
        )

    def custom_activation_benchmarking_on_regression(self) -> str:
        return self._show(
            "Problem 8: Custom Activation Function Benchmarking on Regression",
            "Problem 9: Activation Function Heatmap in a Network Layer (Weight ×",
        )

    def activation_heatmap_in_network_layer(self) -> str:
        return self._show(
            "Problem 9: Activation Function Heatmap in a Network Layer (Weight ×",
            "Problem 10: Interactive Activation Function Explorer with Noise Robustness",
        )

    def noisy_input_activation_explorer(self) -> str:
        return self._show(
            "Problem 10: Interactive Activation Function Explorer with Noise Robustness",
            "Based on Assignment 2 of NN",
        )


class PLNeuralNetworks(_PLTopic):
    def handwritten_digit_classification_tensorflow(self) -> str:
        return self._show(
            "1. Handwritten Digit Classification Using TensorFlow",
            "2. Binary Classification of Breast Cancer Dataset Using PyTorch",
        )

    def breast_cancer_classification_pytorch(self) -> str:
        return self._show(
            "2. Binary Classification of Breast Cancer Dataset Using PyTorch",
            "3. Iris Flower Classification Using TensorFlow",
        )

    def iris_flower_classification_tensorflow(self) -> str:
        return self._show(
            "3. Iris Flower Classification Using TensorFlow",
            "4. House Price Prediction Using PyTorch",
        )

    def house_price_prediction_pytorch(self) -> str:
        return self._show(
            "4. House Price Prediction Using PyTorch",
            "5. Fashion Item Classification Using TensorFlow",
        )

    def fashion_item_classification_tensorflow(self) -> str:
        return self._show(
            "5. Fashion Item Classification Using TensorFlow",
            "Based on Assignment 3 of NN",
        )


class PLFuzzyLogic(_PLTopic):
    def fuzzy_set_operations(self) -> str:
        return self._show(
            "1. Problem Statement: Implement fuzzy union, intersection, difference, and",
            "2.\u200b Problem Statement: Implement fuzzy membership functions to classify",
        )

    def fuzzy_membership_rainfall(self) -> str:
        return self._show(
            "2.\u200b Problem Statement: Implement fuzzy membership functions to classify",
            "3.\u200b Problem Statement: Implement fuzzy relation composition for a",
        )

    def fuzzy_relation_composition(self) -> str:
        return self._show(
            "3.\u200b Problem Statement: Implement fuzzy relation composition for a",
            "4.\u200b Problem Statement: Implement fuzzy inference for a fan speed controller",
        )

    def fuzzy_fan_speed_controller(self) -> str:
        return self._show(
            "4.\u200b Problem Statement: Implement fuzzy inference for a fan speed controller",
            "5.\u200b Problem Statement: Implement fuzzy decision-making to select the best",
        )

    def fuzzy_laptop_selection(self) -> str:
        return self._show(
            "5.\u200b Problem Statement: Implement fuzzy decision-making to select the best",
            "Based on Assignment 4 of NN",
        )

    def washing_machine_speed(self) -> str:
        return self._show(
            "1.\u200b Problem Statement: Design and implement a fuzzy inference system to",
            "2.\u200b Problem Statement: Design and implement a fuzzy inference system to",
        )

    def restaurant_tip_amount(self) -> str:
        return self._show(
            "2.\u200b Problem Statement: Design and implement a fuzzy inference system to",
            "3.\u200b Problem Statement: Design and implement a fuzzy inference system to",
        )

    def room_heater_level(self) -> str:
        return self._show(
            "3.\u200b Problem Statement: Design and implement a fuzzy inference system to",
            "4.\u200b Problem Statement: Design and implement a fuzzy inference system to",
        )

    def student_performance_estimation(self) -> str:
        return self._show(
            "4.\u200b Problem Statement: Design and implement a fuzzy inference system to",
            "5.\u200b Problem Statement: Design and implement a fuzzy inference system to",
        )

    def traffic_signal_duration(self) -> str:
        return self._show(
            "5.\u200b Problem Statement: Design and implement a fuzzy inference system to",
            "Based on Assignment 1 of Cloud Computing",
        )


class PLCloudComputing(_PLTopic):
    def private_cloud_setup(self) -> str:
        return self._show(
            "1. Create Two Ubuntu VMs (Private Cloud)",
            "2. Install Apache Web Server Inside a VM",
        )

    def install_apache_web_server(self) -> str:
        return self._show(
            "2. Install Apache Web Server Inside a VM",
            "3. Create a Snapshot (Backup)",
        )

    def create_snapshot(self) -> str:
        return self._show(
            "3. Create a Snapshot (Backup)",
            "4. Clone a VM to Simulate Scaling",
        )

    def clone_vm_to_simulate_scaling(self) -> str:
        return self._show(
            "4. Clone a VM to Simulate Scaling",
            "5. Configure Load Balancing with Nginx",
        )

    def configure_load_balancing_with_nginx(self) -> str:
        return self._show(
            "5. Configure Load Balancing with Nginx",
            "6. Transfer a File Between Two VMs",
        )

    def transfer_file_between_vms(self) -> str:
        return self._show(
            "6. Transfer a File Between Two VMs",
            "7. Monitor Resource Usage of VMs",
        )

    def monitor_vm_resource_usage(self) -> str:
        return self._show(
            "7. Monitor Resource Usage of VMs",
            "8. Automatically Start VMs on Host Boot",
        )

    def auto_start_vms(self) -> str:
        return self._show(
            "8. Automatically Start VMs on Host Boot",
            "9. Create Shared Storage Between Host and VM",
        )

    def create_shared_storage(self) -> str:
        return self._show(
            "9. Create Shared Storage Between Host and VM",
            "10. Shut Down All VMs Together",
        )

    def shutdown_all_vms(self) -> str:
        return self._show(
            "10. Shut Down All VMs Together",
            "Based on Assignment 2 of Cloud Computing",
        )

    def instructions(self) -> str:
        text = "\n".join(
            [
                "KVM / Virtual Machine Manager Steps:",
                "1. Install KVM packages: qemu-kvm, libvirt-daemon-system, libvirt-clients, virtinst, virt-manager.",
                "2. Start libvirt: sudo systemctl enable --now libvirtd",
                "3. Open Virtual Machine Manager: virt-manager",
                "4. Create VM 1: click Create a new virtual machine, choose local install media, select Ubuntu ISO, set CPU/RAM, create a qcow2 disk, and finish.",
                "5. Create VM 2: repeat the same process for a second Ubuntu VM.",
                "6. Start both VMs from Virtual Machine Manager and complete the Ubuntu installation inside each VM.",
                "7. Open each VM console in Virtual Machine Manager to log in and configure software like Apache or Nginx.",
                "8. For snapshots: right-click the VM in Virtual Machine Manager, open Snapshots, create a new snapshot, and revert from the same view when needed.",
                "9. For cloning: shut down the VM, then use Virtual Machine Manager clone options or copy the disk/definition through libvirt tools.",
                "10. For networking and IP checks: open the VM details in Virtual Machine Manager, confirm the NIC, then use `virsh domifaddr <vm-name>` if you need the guest IP from the host.",
                "11. For file transfer or shared storage: attach another disk from the VM details window or configure a shared folder path from the host side.",
                "12. For monitoring: review CPU, memory, disk, and NIC details in the VM window, or use `virsh dominfo <vm-name>` from the host.",
                "",
                "Command-line verification:",
                "virsh list --all",
                "",
                "Use `pl.cloud_computing.private_cloud_setup()` and the other topic methods for the full program text.",
            ]
        )
        return _print_text(text)

    def help(self) -> str:
        text = "\n".join(
            [
                "1. private_cloud_setup",
                "2. install_apache_web_server",
                "3. create_snapshot",
                "4. clone_vm_to_simulate_scaling",
                "5. configure_load_balancing_with_nginx",
                "6. transfer_file_between_vms",
                "7. monitor_vm_resource_usage",
                "8. auto_start_vms",
                "9. create_shared_storage",
                "10. shutdown_all_vms",
                "11. instructions",
                "",
                "Virtual Machine Manager Flow:",
                "Open `virt-manager` -> create two Ubuntu VMs -> install the OS in each VM -> start them -> open console -> configure services -> use snapshots/clones from the VM manager when needed.",
                "",
                "Host-side checks:",
                "`virsh list --all`",
                "`virsh domifaddr <vm-name>`",
                "`virsh dominfo <vm-name>`",
            ]
        )
        print(text)
        return text


class PLCloudApps(_PLTopic):
    def student_attendance_management_system(self) -> str:
        return self._show(
            "1. Student Attendance Management System",
            "2. Library Management System",
        )

    def library_management_system(self) -> str:
        return self._show(
            "2. Library Management System",
            "3. Employee Record Management System",
        )

    def employee_record_management_system(self) -> str:
        return self._show(
            "3. Employee Record Management System",
            "4. Student Result Processing System",
        )

    def student_result_processing_system(self) -> str:
        return self._show(
            "4. Student Result Processing System",
            "5. Road Project Monitoring System",
        )

    def road_project_monitoring_system(self) -> str:
        return self._show(
            "5. Road Project Monitoring System",
            "Based on Assignment 3 of Cloud Computing",
        )

    def instructions(self) -> str:
        lines = [
            "Run each cloud app with:",
            "dev_appserver.py app.yaml",
        ]
        return _print_text("\n".join(lines))


class PLCloudSim(_PLTopic):
    def priority_based_cloudlet_scheduling(self) -> str:
        return self._show(
            "1. Priority-Based Cloudlet Scheduling",
            "2. Shortest Job First (SJF) Scheduling",
        )

    def shortest_job_first_scheduling(self) -> str:
        return self._show(
            "2. Shortest Job First (SJF) Scheduling",
            "3. Longest Job First (LJF) Scheduling",
        )

    def longest_job_first_scheduling(self) -> str:
        return self._show(
            "3. Longest Job First (LJF) Scheduling",
            "4. Round Robin Scheduling",
        )

    def round_robin_scheduling(self) -> str:
        return self._show(
            "4. Round Robin Scheduling",
            "5. Min-Min Scheduling Algorithm",
        )

    def min_min_scheduling(self) -> str:
        return self._show(
            "5. Min-Min Scheduling Algorithm",
            "Based on Assignment 4 of Cloud Computing",
        )

    def instructions(self) -> str:
        text = "\n".join(
            [
                "Before running:",
                "Download and add the CloudSim library to your Java project.",
                "Import cloudsim-3.0.3.jar.",
                "Create each program in a separate Java file.",
                "",
                "Compile example:",
                "javac --release 11 -cp jars/cloudsim-3.0.3.jar:jars/cloudsim-examples-3.0.3.jar \\",
                "examples/org/cloudbus/cloudsim/examples/RroundScheduling.java",
                "",
                "Run example:",
                "java -cp jars/cloudsim-3.0.3.jar:jars/cloudsim-examples-3.0.3.jar \\",
                "examples/org/cloudbus/cloudsim/examples/RrScheduling",
                "",
                "Replace the file/class name with the scheduling program you want to run.",
            ]
        )
        return _print_text(text)

    def help(self) -> str:
        text = "\n".join(
            [
                "1. priority_based_cloudlet_scheduling",
                "2. shortest_job_first_scheduling",
                "3. longest_job_first_scheduling",
                "4. round_robin_scheduling",
                "5. min_min_scheduling",
                "6. instructions",
                "",
                "Compilation Help:",
                "javac --release 11 -cp jars/cloudsim-3.0.3.jar:jars/cloudsim-examples-3.0.3.jar \\",
                "examples/org/cloudbus/cloudsim/examples/RroundScheduling.java",
                "",
                "Run Help:",
                "java -cp jars/cloudsim-3.0.3.jar:jars/cloudsim-examples-3.0.3.jar \\",
                "examples/org/cloudbus/cloudsim/examples/RrScheduling",
                "",
                "Replace the file/class name as needed.",
            ]
        )
        print(text)
        return text


class PLCloudlet(PLCloudSim):
    pass


class PLApex(_PLTopic):
    def welcome_message(self) -> str:
        return self._show(
            "1. Display a Welcome Message",
            "2. Add Two Numbers",
        )

    def add_two_numbers(self) -> str:
        return self._show(
            "2. Add Two Numbers",
            "3. Find Whether a Number is Even or Odd",
        )

    def even_or_odd(self) -> str:
        return self._show(
            "3. Find Whether a Number is Even or Odd",
            "4. Find the Largest of Two Numbers",
        )

    def largest_of_two_numbers(self) -> str:
        return self._show(
            "4. Find the Largest of Two Numbers",
            "5. Print Numbers from 1 to 10",
        )

    def print_numbers_1_to_10(self) -> str:
        return self._show(
            "5. Print Numbers from 1 to 10",
            "6. Find the Factorial of a Number",
        )

    def factorial_of_number(self) -> str:
        return self._show(
            "6. Find the Factorial of a Number",
            "7. Reverse a String",
        )

    def reverse_string(self) -> str:
        return self._show(
            "7. Reverse a String",
            "8. Count the Number of Characters in a String",
        )

    def character_count(self) -> str:
        return self._show(
            "8. Count the Number of Characters in a String",
            "9. Store and Display Student Names Using List",
        )

    def student_names_using_list(self) -> str:
        return self._show(
            "9. Store and Display Student Names Using List",
            "10. Find the Sum of Elements in a List",
        )

    def sum_of_list_elements(self) -> str:
        return self._show(
            "10. Find the Sum of Elements in a List",
            "How to Run These Programs in Salesforce Developer Console",
        )

    def how_to_run(self) -> str:
        return self._show("How to Run These Programs in Salesforce Developer Console")


class PL:
    def __init__(self, base_dir: str | Path | None = None) -> None:
        root = Path(base_dir) if base_dir else Path(__file__).resolve().parent
        self._store = _TextStore(root)
        programs = self._store.read(self._store.pl_programs)
        self.activation_functions = PLActivationFunctions(self._store, programs, [1, 7, 8])
        self.neural_networks = PLNeuralNetworks(self._store, programs, [7, 8, 9, 10, 13])
        self.fuzzy_logic = PLFuzzyLogic(self._store, programs, [2, 3])
        self.cloud_computing = PLCloudComputing(self._store, programs, [4, 5, 6])
        self.cloud_apps = PLCloudApps(self._store, programs, [11, 12])
        self.cloudsim = PLCloudSim(self._store, programs, [4, 5])
        self.cloudlet = PLCloudlet(self._store, programs, [4, 5])
        self.apex = PLApex(self._store, programs, [11, 12])

    def listing(self) -> list[str]:
        names = [
            "activation_functions",
            "neural_networks",
            "fuzzy_logic",
            "cloud_computing",
            "cloud_apps",
            "cloudsim",
            "cloudlet",
            "apex",
        ]
        print("\n".join(names))
        return names

    def help(self) -> str:
        text = "\n".join(
            [
                "1. activation_functions",
                "2. neural_networks",
                "3. fuzzy_logic",
                "4. cloud_computing",
                "5. cloud_apps",
                "6. cloudsim",
                "7. cloudlet",
                "8. apex",
                "",
                "Example:",
                "pl.neural_networks.listing()",
                "pl.neural_networks.handwritten_digit_classification_tensorflow()",
            ]
        )
        print(text)
        return text


class DSTL(_Listable):
    def __init__(self, base_dir: str | Path | None = None) -> None:
        root = Path(base_dir) if base_dir else Path(__file__).resolve().parent
        self._store = _TextStore(root)
        self.pyspark = _RawTextTopic(lambda: self._store.read(self._store.dstl_practical2))
        self.time_series = _RawTextTopic(self._store.practical3_code)
        self.mongodb = DSTLMongoDB(self._store)

    def listing(self) -> list[str]:
        names = [
            "pyspark",
            "time_series",
            "mongodb",
        ]
        print("\n".join(names))
        return names

    def help(self) -> str:
        text = "\n".join(
            [
                "1. pyspark",
                "2. time_series",
                "3. mongodb",
                "",
                "Example:",
                "dstl.mongodb.help()",
                "dstl.mongodb.show()",
                "dstl.mongodb.instructions()",
            ]
        )
        print(text)
        return text

    def practical_2(self) -> str:
        return self.pyspark.show()

    def practical_3(self) -> str:
        return self.time_series.show()

    def practical_7(self) -> str:
        return self.mongodb.show()
