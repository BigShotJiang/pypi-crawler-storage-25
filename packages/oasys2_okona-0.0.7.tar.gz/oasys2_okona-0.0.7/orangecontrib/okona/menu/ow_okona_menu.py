__author__ = 'L. Rebuffi'

import webbrowser
from oasys2.canvas.menus.menu import OMenu

try:
    from orangecontrib.okona.widgets.tools.ow_microroughness_generator import OWMicroRoughnessGenerator
    from orangecontrib.okona.widgets.tools.ow_figure_error_generator import OWFigureErrorGenerator
except:
    pass

class OKONAMenu(OMenu):
    def __init__(self):
        super().__init__(name="OKONA")

        self.addSubMenu("Execute all the Surface Errors Generator widgets")
        self.addSeparator()
        self.addSubMenu("OKONA Documentation")

    def executeAction_1(self, action):
        try:
            found = False
            for node in self.canvas_main_window.current_document().scheme().nodes:
                widget = self.canvas_main_window.current_document().scheme().widget_for_node(node)
                if isinstance(widget, (OWFigureErrorGenerator, OWMicroRoughnessGenerator)):
                    widget._send_data(online=False)
                    widget._save_data(online=False)
                    found = True
            if found: super(OKONAMenu, self).showWarningMessage("All Surface Errors Generators has been executed")
            else:     super(OKONAMenu, self).showWarningMessage("No Surface Errors Generators has been found")
        except Exception as exception:
            super(OKONAMenu, self).showCriticalMessage(message=exception.args[0])

    def executeAction_2(self, action):
        try:
            webbrowser.open("https://github.com/oasys-kit/OKONA")
        except Exception as exception:
            super(OKONAMenu, self).showCriticalMessage(message=exception.args[0])

