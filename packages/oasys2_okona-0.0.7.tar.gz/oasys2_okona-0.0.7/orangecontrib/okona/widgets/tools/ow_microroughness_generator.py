#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #


#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import numpy as np
from AnyQt.QtWidgets import QMessageBox, QApplication
from AnyQt.QtCore import QRect

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from oasys2.canvas.util.canvas_util import add_widget_parameters_to_module
from oasys2.widget import gui as oasysgui
from oasys2.widget.gui import ConfirmDialog
from oasys2.widget.util import congruence
from oasys2.widget.widget import OWWidget, OWAction

from orangewidget import gui
from orangewidget.settings import Setting
from orangewidget.widget import Output

from wofryokona.util.surface_errors import generate_microroughness_from_broken_power_law

from orangecontrib.okona.util.okona_objects import SurfaceErrorsData

class OWMicroRoughnessGenerator(OWWidget):
    maintainer = "Luca Rebuffi"
    maintainer_email = "lrebuffi(@at@)anl.gov"
    keywords = ["data", "file", "load", "read"]
    category = "OKONA Optical Elements"
    name = "Micro-Roughness Generator"
    description = "OKONA: Micro-Roughness Generator"
    icon = "icons/roughness.png"
    priority = 2

    class Outputs:
        okona_data = Output(name="Surface Errors Data", type=SurfaceErrorsData, id="Surface Errors Data", default=True, auto_summary=False)

    patch_length       = Setting(1e-3)
    height_error_rms   = Setting(0.8e-9)
    correlation_length = Setting(35e-6)
    n_low              = Setting(1.55)
    n_high             = Setting(1.0)
    sampling_step      = Setting(1e-8)

    roughness_data_file = Setting("microroughness_data_file.txt")
    psd_data_file       = Setting("psd_data_file.txt")

    want_main_area = 1

    roughness_x    = None
    roughness_mrp  = None
    psd_wavelength = None
    psd_data       = None

    TABS_AREA_HEIGHT   = 515
    CONTROL_AREA_WIDTH = 450

    MAX_WIDTH = 1320
    MAX_HEIGHT = 650

    def __init__(self):
        super(OWMicroRoughnessGenerator, self).__init__()

        self.runaction = OWAction("Generate Data", self)
        self.runaction.triggered.connect(self._send_data)
        self.addAction(self.runaction)

        self.runaction = OWAction("Save Data", self)
        self.runaction.triggered.connect(self._save_data)
        self.addAction(self.runaction)

        self._button_box = oasysgui.widgetBox(self.controlArea, "", addSpace=False, orientation="horizontal", width=self.CONTROL_AREA_WIDTH - 10)

        button = gui.button(self._button_box, self, "Generate Data", callback=self._send_data)
        button.setStyleSheet("color: darkblue; font-weight: bold; height: 45px;")

        button = gui.button(self._button_box, self, "Save Data", callback=self._save_data)
        button.setStyleSheet("color: darkblue; font-weight: bold; height: 45px;")

        button = gui.button(self._button_box, self, "Reset Fields", callback=self._call_reset_settings)
        button.setStyleSheet("color: darkred; font-weight: bold; font-style: italic; height: 45px; width: 150px;")

        gui.separator(self.controlArea)

        geom = QApplication.primaryScreen().geometry()
        self.setGeometry(QRect(round(geom.width() * 0.05),
                               round(geom.height() * 0.05),
                               round(min(geom.width() * 0.98, self.MAX_WIDTH)),
                               round(min(geom.height() * 0.95, self.MAX_HEIGHT))))

        self.setMaximumHeight(self.geometry().height())
        self.setMaximumWidth(self.geometry().width())

        self.controlArea.setFixedWidth(self.CONTROL_AREA_WIDTH)

        self._tabs_setting = oasysgui.tabWidget(self.controlArea)
        self._tabs_setting.setFixedHeight(self.TABS_AREA_HEIGHT)
        self._tabs_setting.setFixedWidth(self.CONTROL_AREA_WIDTH - 5)

        self._tab_bas = oasysgui.createTabPage(self._tabs_setting, "Figure Error Settings")

        self._figure_error_box = oasysgui.widgetBox(self._tab_bas, "Input Parameters", addSpace=True, orientation="vertical")

        oasysgui.lineEdit(self._figure_error_box, self, "patch_length", "Patch Length [m]", labelWidth=320, valueType=float, orientation="horizontal")
        oasysgui.lineEdit(self._figure_error_box, self, "height_error_rms", "Height Error RMS [m]", labelWidth=320, valueType=float, orientation="horizontal")
        oasysgui.lineEdit(self._figure_error_box, self, "correlation_length", "Correlation Length [m]", labelWidth=320, valueType=float, orientation="horizontal")
        oasysgui.lineEdit(self._figure_error_box, self, "n_low",  "Slope at Low Frequencies", labelWidth=320, valueType=float, orientation="horizontal")
        oasysgui.lineEdit(self._figure_error_box, self, "n_high", "Slope at High Frequencies", labelWidth=320, valueType=float, orientation="horizontal")
        oasysgui.lineEdit(self._figure_error_box, self, "sampling_step", "Sampling Step [m]", labelWidth=320, valueType=float, orientation="horizontal")

        self._output_box = oasysgui.widgetBox(self._tab_bas, "Output Parameters", addSpace=True, orientation="vertical")

        file_box =  oasysgui.widgetBox(self._output_box, "", addSpace=False, orientation="horizontal")
        self._le_roughness_data_file = oasysgui.lineEdit(file_box, self, "roughness_data_file", "M-R data file", labelWidth=125, valueType=str, orientation="horizontal")
        gui.button(file_box, self, "...", callback=self._select_roughness_data_file, width=30)

        file_box =  oasysgui.widgetBox(self._output_box, "", addSpace=False, orientation="horizontal")
        self._le_psd_data_file = oasysgui.lineEdit(file_box, self, "psd_data_file", "PSD data file", labelWidth=125, valueType=str, orientation="horizontal")
        gui.button(file_box, self, "...", callback=self._select_psd_data_file, width=30)

        self._main_tabs = oasysgui.tabWidget(self.mainArea)
        self._plot_tab = oasysgui.createTabPage(self._main_tabs, "Result")
        self._plot_tabs = oasysgui.tabWidget(self._plot_tab)

        self._mr_tab = oasysgui.createTabPage(self._plot_tabs, "Micro-Roughness")
        self._psd_tab = oasysgui.createTabPage(self._plot_tabs, "PSD")

        self._microroughness_plot_canvas = self._get_standard_figure_canvas()
        self._mr_tab.layout().addWidget(self._microroughness_plot_canvas)
        self._psd_plot_canvas = self._get_standard_figure_canvas()
        self._psd_tab.layout().addWidget(self._psd_plot_canvas)

    @staticmethod
    def _get_standard_figure_canvas(): return FigureCanvas(Figure(figsize=(8, 6)))

    def _select_roughness_data_file(self):
        self._le_roughness_data_file.setText(oasysgui.selectFileFromDialog(self, self.roughness_data_file, "Micro-Roughness data file"))

    def _select_psd_data_file(self):
        self._le_psd_data_file.setText(oasysgui.selectFileFromDialog(self, self.psd_data_file, "PSD data file"))

    def _check_data(self):
        congruence.checkStrictlyPositiveNumber(self.patch_length, "Mirror Length")
        congruence.checkStrictlyPositiveNumber(self.height_error_rms, "Height Error RMS")
        congruence.checkStrictlyPositiveNumber(self.correlation_length, "Correlation Length")
        congruence.checkStrictlyPositiveNumber(self.n_low, "Slope at Low Frequencies")
        congruence.checkStrictlyPositiveNumber(self.n_high, "Slope at High Frequencies")
        congruence.checkStrictlyPositiveNumber(self.sampling_step, "Sampling Step")

    def _send_data(self, online=True):
        try:
            self._check_data()

            x, mr_profile, wavelength, psd = generate_microroughness_from_broken_power_law(patch_length=self.patch_length,
                                                                                            height_error_rms=self.height_error_rms,
                                                                                            correlation_length=self.correlation_length,
                                                                                            n_low=self.n_low,
                                                                                            n_high=self.n_high,
                                                                                            sampling_step=self.sampling_step)
            self.roughness_x    = x
            self.roughness_mrp  = mr_profile
            self.psd_wavelength = wavelength
            self.psd_data       = psd

            self._plot_microroughness_data()
            self._plot_psd_data()

            if online: QMessageBox.information(self, "Figure Error Generated", f"Click on Save Figure Error to save the file", QMessageBox.Ok)
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e.args[0]), QMessageBox.Ok)

            self.setStatusMessage("")
            self.progressBarFinished()

            if self.IS_DEVELOP: raise e

    def _save_data(self, online=True):
        try:
           if (not self.roughness_x is None and not self.roughness_mrp is None and
                   not self.psd_wavelength is None and not self.psd_data is None):

               np.savetxt(self.roughness_data_file,
                           np.column_stack([self.roughness_x, self.roughness_mrp]),
                           fmt="%.9e",
                           delimiter="\t",
                           header="# Position (m)\tHeight Error (m)")

               np.savetxt(self.psd_data_file,
                           np.column_stack([self.psd_wavelength, self.psd_data]),
                           fmt="%.9e",
                           delimiter="\t",
                           header="# Wavelength (um)\tPSD (nm^2 * um)")

               if online: QMessageBox.information(self, "Info", f"Files {self.roughness_data_file} and {self.psd_data_file} written on disk", QMessageBox.Ok)

               self.Outputs.okona_data.send(SurfaceErrorsData(microroughness_data_file=self.roughness_data_file,
                                                              power_spectral_density_data_file=self.psd_data_file))
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e.args[0]), QMessageBox.Ok)

            self.setStatusMessage("")
            self.progressBarFinished()

            if self.IS_DEVELOP: raise e

    def _plot_microroughness_data(self):
        figure = self._microroughness_plot_canvas.figure
        figure.clear()

        ax = figure.gca()
        ax.grid(True)
        ax.plot(self.roughness_x * 1000, self.roughness_mrp * 1e9)
        ax.set_title(f"Roughness (RMS: {np.std(self.roughness_mrp * 1e9):.3f} nm)", fontsize=8)
        ax.set_ylabel("Height (nm)")
        ax.set_xlabel("Position (mm)")
        ax.grid(True)

        figure.tight_layout()

        self._microroughness_plot_canvas.draw()

    def _plot_psd_data(self):
        figure = self._psd_plot_canvas.figure
        figure.clear()

        ax = figure.gca()
        ax.grid(True)
        ax.loglog(self.psd_wavelength, self.psd_data, 'darkorange')
        ax.set_title("Microroughness PSD")
        ax.set_xlabel("Spatial Wavelength (µm)")
        ax.set_ylabel(r"PSD (nm$^2$ µm)")
        ax.invert_xaxis()
        ax.axvline(self.correlation_length * 1e6, color='k', ls='--', label=f"Break @ {self.correlation_length * 1e6:.1f} µm")
        ax.legend()

        figure.tight_layout()

        self._psd_plot_canvas.draw()

    def _call_reset_settings(self):
        if ConfirmDialog.confirmed(parent=self, message="Confirm Reset of the Fields?"):
            try:    self._reset_settings()
            except: pass

add_widget_parameters_to_module(__name__)

