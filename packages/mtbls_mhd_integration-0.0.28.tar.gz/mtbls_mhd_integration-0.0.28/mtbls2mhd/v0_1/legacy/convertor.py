from pathlib import Path

from mhd_model.convertors.mhd.convertor import BaseMhdConvertor
from mhd_model.shared.model import Revision

from mtbls2mhd.config import Mtbls2MhdConfiguration, get_default_config
from mtbls2mhd.v0_1.legacy.builder import MhdLegacyDatasetBuilder


class LegacyProfileV01Convertor(BaseMhdConvertor):
    def __init__(
        self,
        target_mhd_model_schema_uri: str,
        target_mhd_model_profile_uri: str,
    ):
        self.target_mhd_model_schema_uri = target_mhd_model_schema_uri
        self.target_mhd_model_profile_uri = target_mhd_model_profile_uri

    def convert(
        self,
        repository_name: str,
        repository_identifier: str,
        mhd_identifier: None | str,
        repository_revision: None | Revision = None,
        config: None | Mtbls2MhdConfiguration = None,  # noqa: F821
        cached_mtbls_model_file_path: None | str = None,
        **kwargs,
    ):
        if not config:
            config = get_default_config()
        mhd_dataset_builder = MhdLegacyDatasetBuilder(config=config)
        mtbls_study_repository_website_url = (
            f"{config.study_http_base_url}/{repository_identifier}"
        )
        public_ftp_url = f"{config.public_ftp_base_url}/{repository_identifier}"
        public_http_url = f"{config.public_http_base_url}/{repository_identifier}"
        mtbls_study_path = Path(config.mtbls_studies_root_path) / Path(
            repository_identifier
        )
        try:
            success, message = mhd_dataset_builder.build(
                mhd_id=None,
                mtbls_study_id=repository_identifier,
                mtbls_study_path=mtbls_study_path,
                mtbls_study_repository_urls=[
                    mtbls_study_repository_website_url,
                    public_http_url,
                    public_ftp_url,
                ],
                target_mhd_model_schema_uri=self.target_mhd_model_schema_uri,
                target_mhd_model_profile_uri=self.target_mhd_model_profile_uri,
                cached_mtbls_model_file_path=cached_mtbls_model_file_path,
                revision=repository_revision,
                repository_name=repository_name,
                **kwargs,
            )
            return success, message
        except Exception as ex:
            import traceback

            traceback.print_exc()
            return False, str(ex)
