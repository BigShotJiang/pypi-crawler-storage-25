import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from cpsl.clients.capsule import (
    WaitForApprovalResponse,
    WaitForIntegrationResponse,
)
from cpsl.db import reset_active_identity, set_active_identity
from cpsl.msg import Message
from cpsl.session import (
    IntegrationTimeout,
    RequestContext,
    Session,
    SessionChannel,
    UserInfo,
    current_session,
)
from cpsl.task_types import TaskDescriptor


class RuntimeSessionTests(unittest.TestCase):
    def test_current_session_returns_active_session(self):
        session = Session(
            id="",
            user=UserInfo(id="owner-123", org_id="org_123"),
            channel=SessionChannel(type="chat"),
            history=[],
            data={},
        )
        token = set_active_identity(session)
        try:
            self.assertIs(current_session(), session)
        finally:
            reset_active_identity(token)

    def test_current_session_ignores_non_session_identity(self):
        ctx = RequestContext(user=UserInfo(id="user-123"), integrations={})
        token = set_active_identity(ctx)
        try:
            self.assertIsNone(current_session())
        finally:
            reset_active_identity(token)

    def test_task_descriptor_detects_session_parameter_anywhere(self):
        async def with_session(session, value):
            return value

        async def with_trailing_session(value, session=None):
            return value

        async def without_session(value):
            return value

        class Example:
            async def method_with_session(self, session, value):
                return value

            async def method_with_trailing_session(self, value, session=None):
                return value

            async def method_without_session(self, value):
                return value

        self.assertTrue(TaskDescriptor(with_session)._wants_session)
        self.assertTrue(TaskDescriptor(with_trailing_session)._wants_session)
        self.assertFalse(TaskDescriptor(without_session)._wants_session)
        self.assertTrue(TaskDescriptor(Example.method_with_session)._wants_session)
        self.assertTrue(TaskDescriptor(Example.method_with_trailing_session)._wants_session)
        self.assertFalse(TaskDescriptor(Example.method_without_session)._wants_session)


class SessionPromptTests(unittest.IsolatedAsyncioTestCase):
    def new_session(self) -> Session:
        return Session(
            id="sess-1",
            user=UserInfo(id="user-1", email="user@example.com"),
            channel=SessionChannel(type="chat"),
            history=[],
            data={},
        )

    async def test_prompt_approval_returns_true_and_marks_completed(self):
        session = self.new_session()
        replies: list[str] = []
        blocks: list[str] = []

        class StubSessionService:
            def wait_for_approval(self, _req):
                return WaitForApprovalResponse(approved=True)

        async def reply_cb(msg: Message):
            replies.append(msg.text)

        async def block_cb(block_json: str):
            blocks.append(block_json)

        session._session_stub = StubSessionService()
        session._reply_callback = reply_cb
        session._block_callback = block_cb

        approved = await session.prompt_approval("Send these drafts?")

        self.assertTrue(approved)
        self.assertEqual(replies, ["Send these drafts?"])
        self.assertEqual(len(blocks), 2)
        self.assertIn('"approval_prompt"', blocks[0])
        self.assertIn('"message": ""', blocks[0])
        self.assertIn('"completed": true', blocks[1])
        self.assertIn('"approved": true', blocks[1])

    async def test_prompt_integration_persists_reason_as_reply(self):
        session = self.new_session()
        replies: list[str] = []
        blocks: list[str] = []

        class StubSessionService:
            def wait_for_integration(self, _req):
                return WaitForIntegrationResponse(timed_out=True)

        async def reply_cb(msg: Message):
            replies.append(msg.text)

        async def block_cb(block_json: str):
            blocks.append(block_json)

        session._app_id = "app-1"
        session._session_stub = StubSessionService()
        session._reply_callback = reply_cb
        session._block_callback = block_cb

        with self.assertRaises(IntegrationTimeout):
            await session.prompt_integration("gmail", reason="Connect Gmail to draft replies.")

        self.assertEqual(replies, ["Connect Gmail to draft replies."])
        self.assertEqual(len(blocks), 1)
        self.assertIn('"integration_prompt"', blocks[0])
        self.assertIn('"reason": ""', blocks[0])


if __name__ == "__main__":
    unittest.main()
