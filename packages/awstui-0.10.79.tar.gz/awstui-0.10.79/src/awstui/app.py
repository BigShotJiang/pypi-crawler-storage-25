from __future__ import annotations

import json
from importlib.metadata import PackageNotFoundError, version as _pkg_version

import boto3
import pyperclip
from botocore.exceptions import ClientError, NoCredentialsError, ProfileNotFound
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.widgets import Footer, Header, Static, TabbedContent, TabPane
from textual import work

from awstui.models import ResourceDetails, TreeNode
from awstui.plugin import PluginRegistry
from awstui.services import discover_plugins
from awstui.widgets.detail_pane import DetailPane
from awstui.widgets.filter_dialog import FilterDialog
from awstui.widgets.nav_tree import AWSNavTree, NodeError, NodeSelected
from awstui.widgets.region_selector import RegionChanged, RegionSelector
from awstui.widgets.tags_pane import TagsPane, extract_tags


def _get_version() -> str:
    try:
        return _pkg_version("awstui")
    except PackageNotFoundError:
        return "unknown"


class AWSBrowserApp(App):
    """AWS TUI Browser."""

    TITLE = "awstui"
    BINDINGS = [
        Binding("1", "focus_region", "Region"),
        Binding("2", "focus_nav", "Nav"),
        Binding("3", "focus_detail", "Detail"),
        Binding("4", "focus_tags", "Tags"),
        Binding("a", "copy_arn", "Copy ARN"),
        Binding("u", "copy_uri", "Copy URI"),
        Binding("r", "copy_raw", "Copy Raw"),
        Binding("f", "filter_children", "Filter"),
        Binding("[", "shrink_pane", "Shrink"),
        Binding("]", "grow_pane", "Grow"),
    ]
    CSS = """
    #main {
        height: 1fr;
    }
    #nav-pane {
        width: 1fr;
        max-width: 40;
        min-width: 25;
        border-right: solid $primary;
    }
    #detail-pane {
        width: 2fr;
    }
    #tags-pane {
        width: 1fr;
        min-width: 25;
    }
    #identity-bar {
        dock: top;
        height: 1;
        padding: 0 1;
        background: $surface;
        color: $text-muted;
    }
    #region-bar {
        dock: top;
        height: 3;
        padding: 0 1;
        background: $surface;
    }
    """

    def __init__(
        self,
        profile: str | None = None,
        services: list[str] | None = None,
    ) -> None:
        super().__init__()
        self._profile: str | None = profile
        self._services: set[str] | None = (
            {s.lower() for s in services} if services else None
        )
        self._session: boto3.Session | None = None
        self._identity: str = ""
        self._region: str = "us-east-1"
        self._plugin_registry: PluginRegistry | None = None
        self._current_raw: object = {}
        self._current_subtitle: str = ""
        self._current_node: TreeNode | None = None
        self._selection_seq: int = 0
        self._current_container_node: TreeNode | None = None
        self._tag_summary_seq: int = -1

    def compose(self) -> ComposeResult:
        yield Header()
        yield Static(self._identity, id="identity-bar")
        with Horizontal(id="main"):
            with Vertical(id="nav-pane"):
                yield RegionSelector(self._region)
                yield AWSNavTree(self._session, [])  # placeholder, replaced on_mount
            yield DetailPane(id="detail-pane")
            yield TagsPane(id="tags-pane")
        yield Footer()

    def on_mount(self) -> None:
        try:
            self._session = self._build_session()
            self._region = self._session.region_name or "us-east-1"
        except ProfileNotFound as e:
            self.query_one("#detail-pane", DetailPane).show_error(str(e))
            return
        except NoCredentialsError:
            self.query_one("#detail-pane", DetailPane).show_error(
                "No AWS credentials found. Configure credentials and restart."
            )
            return

        # Fetch identity
        try:
            sts = self._session.client("sts")
            identity = sts.get_caller_identity()
            self._identity = identity.get("Arn", "Unknown")
        except (ClientError, Exception):
            self._identity = "Unknown (could not fetch identity)"

        if self._profile:
            self._identity = f"[profile: {self._profile}] {self._identity}"

        self._identity = f"awstui v{_get_version()} · {self._identity}"

        self.query_one("#identity-bar", Static).update(self._identity)

        # Discover plugins and rebuild tree
        self._plugin_registry = discover_plugins()
        plugins = self._plugin_registry.list_plugins()
        if self._services is not None:
            plugins = [p for p in plugins if p.service_name.lower() in self._services]

        nav_pane = self.query_one("#nav-pane", Vertical)
        # Remove placeholder tree and region selector
        nav_pane.remove_children()
        # Mount fresh widgets
        nav_pane.mount(RegionSelector(self._region))
        tree = AWSNavTree(self._session, plugins)
        nav_pane.mount(tree)
        tree.focus()

    def on_node_selected(self, message: NodeSelected) -> None:
        detail = self.query_one("#detail-pane", DetailPane)
        tags = self.query_one("#tags-pane", TagsPane)
        node_data = message.node_data
        if self._plugin_registry is None:
            return
        plugin = self._plugin_registry.get(node_data.service)

        if plugin is None:
            detail.show_placeholder()
            tags.show_placeholder()
            self._current_raw = {}
            self._current_subtitle = ""
            self._current_node = None
            return

        self._selection_seq += 1
        self._current_container_node = None
        self._current_node = node_data

        if node_data.node_type == "service":
            resource_details = ResourceDetails(
                title=plugin.name,
                subtitle=f"boto3 service: {plugin.service_name}",
                summary={},
                raw={},
            )
            if plugin.has_flat_root:
                detail.show_details(
                    resource_details,
                    empty_summary_status="Retrieving count ...",
                    include_tag_summary=True,
                )
                self._current_raw = {}
                self._current_container_node = node_data
                self._load_child_count(node_data, self._selection_seq)
            else:
                detail.show_details(resource_details)
                self._current_raw = {}
            self._current_subtitle = ""
            tags.show_placeholder()
            return

        try:
            details = plugin.get_details(self._session, node_data)
        except ClientError as e:
            error_code = e.response["Error"].get("Code", "")
            if error_code in (
                "AccessDenied",
                "AccessDeniedException",
                "UnauthorizedAccess",
            ):
                detail.show_error(
                    f"Access Denied: insufficient permissions to view {node_data.label}"
                )
            else:
                detail.show_error(f"Error loading details: {e}")
            tags.show_placeholder()
            self._current_raw = {}
            self._current_subtitle = ""
            return
        except Exception as e:
            detail.show_error(f"Error loading details: {e}")
            tags.show_placeholder()
            self._current_raw = {}
            self._current_subtitle = ""
            return

        # For container nodes (no summary of their own), show a fetching
        # placeholder *at mount time* and kick off a background count.
        is_container = not details.summary and node_data.expandable
        if is_container:
            detail.show_details(
                details,
                empty_summary_status="Retrieving count ...",
                include_tag_summary=True,
            )
            self._current_container_node = node_data
        else:
            detail.show_details(details)
        self._current_raw = details.raw
        self._current_subtitle = details.subtitle
        tags.show_tags(details.raw)

        if is_container:
            self._load_child_count(node_data, self._selection_seq)

    def on_node_error(self, message: NodeError) -> None:
        self.query_one("#detail-pane", DetailPane).show_error(message.error_message)
        self.query_one("#tags-pane", TagsPane).show_placeholder()
        self._current_raw = {}
        self._current_subtitle = ""
        self._current_node = None
        self._selection_seq += 1

    def action_focus_region(self) -> None:
        try:
            self.query_one(RegionSelector).focus()
        except Exception:
            pass

    def action_focus_nav(self) -> None:
        try:
            self.query_one(AWSNavTree).focus()
        except Exception:
            pass

    def action_focus_detail(self) -> None:
        try:
            self.query_one("#detail-pane", DetailPane).focus()
        except Exception:
            pass

    def action_focus_tags(self) -> None:
        try:
            self.query_one("#tags-pane", TagsPane).focus()
        except Exception:
            pass

    PANE_IDS = ("nav-pane", "detail-pane", "tags-pane")
    PANE_RESIZE_STEP = 4
    PANE_MIN_WIDTH = 20

    def _focused_pane(self):
        widget = self.focused
        while widget is not None:
            if widget.id in self.PANE_IDS:
                return widget
            widget = widget.parent
        return None

    def _resize_focused_pane(self, delta: int) -> None:
        pane = self._focused_pane()
        if pane is None:
            return
        current = pane.size.width
        new_width = max(self.PANE_MIN_WIDTH, current + delta)
        pane.styles.width = new_width
        if pane.id == "nav-pane":
            # Override the CSS max-width constraint so nav can grow freely.
            pane.styles.max_width = new_width

    def action_shrink_pane(self) -> None:
        self._resize_focused_pane(-self.PANE_RESIZE_STEP)

    def action_grow_pane(self) -> None:
        self._resize_focused_pane(self.PANE_RESIZE_STEP)

    def action_copy_arn(self) -> None:
        arn = self._find_arn(self._current_raw)
        if not arn and self._current_subtitle.startswith("arn:"):
            arn = self._current_subtitle
        if not arn:
            self.notify("No ARN available for this resource", severity="warning")
            return
        self._copy_text(arn, f"Copied ARN: {arn}")

    def action_copy_uri(self) -> None:
        uri = self._uri_for(self._current_node)
        if not uri:
            self.notify("No URI available for this resource", severity="warning")
            return
        self._copy_text(uri, f"Copied URI: {uri}")

    def action_filter_children(self) -> None:
        tree = self.query_one(AWSNavTree)
        parent = tree.cursor_node
        if parent is None or parent is tree.root:
            self.notify(
                "Select a parent node in the navigation tree first",
                severity="warning",
            )
            return
        if not parent.allow_expand:
            self.notify("Selected node has no children to filter", severity="warning")
            return
        if not parent.children:
            self.notify(
                "No children loaded yet — expand the node first",
                severity="warning",
            )
            return

        def apply(substring: str | None) -> None:
            if substring is None:
                return
            count = tree.filter_children(parent, substring)
            if not substring:
                self.notify("Filter cleared")
            else:
                noun = "match" if count == 1 else "matches"
                self.notify(f"{count} {noun} for '{substring}'")

        self.push_screen(FilterDialog(), apply)

    @staticmethod
    def _uri_for(node: TreeNode | None) -> str:
        if node is None:
            return ""
        meta = node.metadata
        if node.node_type == "bucket":
            bucket = meta.get("bucket_name", "")
            return f"s3://{bucket}" if bucket else ""
        if node.node_type == "object":
            bucket = meta.get("bucket_name", "")
            key = meta.get("key", "")
            return f"s3://{bucket}/{key}" if bucket and key else ""
        if node.node_type in ("private_image", "public_image"):
            repo_uri = meta.get("repository_uri", "")
            if not repo_uri:
                return ""
            tags = meta.get("image_tags") or []
            if tags:
                return f"{repo_uri}:{tags[0]}"
            digest = meta.get("image_digest", "")
            return f"{repo_uri}@{digest}" if digest else repo_uri
        return ""

    def action_copy_raw(self) -> None:
        if not self._current_raw:
            self.notify("No raw JSON available for this resource", severity="warning")
            return
        raw = json.dumps(self._current_raw, indent=2, default=str)
        self._copy_text(raw, "Copied raw JSON")

    def _copy_text(self, text: str, success_message: str) -> None:
        try:
            pyperclip.copy(text)
            self.notify(success_message)
        except pyperclip.PyperclipException:
            # No system clipboard tool available — fall back to OSC 52.
            self.copy_to_clipboard(text)
            self.notify(
                f"{success_message} (via terminal escape)",
                severity="warning",
            )

    @staticmethod
    def _noun_for(label: str) -> str:
        """Derive a lowercase noun from a container node label.

        'Users' -> 'users', 'DB Instances' -> 'instances',
        'Attached Policies' -> 'policies', 'Access Keys' -> 'keys'.
        """
        last = label.strip().split()[-1] if label.strip() else "items"
        return last.lower()

    @staticmethod
    def _pluralize(word: str) -> str:
        if not word:
            return "items"
        if word.endswith("y") and len(word) > 1 and word[-2] not in "aeiou":
            return word[:-1] + "ies"
        if word.endswith(("s", "x", "z", "ch", "sh")):
            return word + "es"
        return word + "s"

    @work(thread=True, exclusive=True, group="child_count")
    def _load_child_count(self, node: TreeNode, seq: int) -> None:
        plugin = (
            self._plugin_registry.get(node.service) if self._plugin_registry else None
        )
        if plugin is None or self._session is None:
            return

        try:
            if node.node_type == "service":
                children = plugin.get_root_nodes(self._session)
                # Derive noun from the first child's node_type (e.g. 'bucket', 'function').
                # Falls back to the plugin name if there are no children.
                base = (
                    children[0].node_type.replace("_", " ")
                    if children
                    else plugin.name.lower()
                )
                noun = self._pluralize(base)
            else:
                children = plugin.get_children(self._session, node)
                noun = self._noun_for(node.label)
            count = len(children)
            message = f"{count} {noun}"
        except ClientError as e:
            error_code = e.response["Error"].get("Code", "")
            if error_code in (
                "AccessDenied",
                "AccessDeniedException",
                "UnauthorizedAccess",
            ):
                message = "Access Denied: cannot count items"
            else:
                message = f"Error counting items: {e}"
        except Exception as e:
            message = f"Error counting items: {e}"

        self.call_from_thread(self._apply_child_count, seq, message)

    def _apply_child_count(self, seq: int, message: str) -> None:
        # Drop stale results if the user has since selected a different node.
        if seq != self._selection_seq:
            return
        try:
            self.query_one("#detail-pane", DetailPane).set_summary_status(message)
        except Exception:
            pass

    @work(thread=True, exclusive=True, group="tag_summary")
    def _load_tag_summary(self, node: TreeNode, seq: int) -> None:
        plugin = (
            self._plugin_registry.get(node.service) if self._plugin_registry else None
        )
        if plugin is None or self._session is None:
            return

        try:
            if node.node_type == "service":
                children = plugin.get_root_nodes(self._session)
            else:
                children = plugin.get_children(self._session, node)
        except Exception as e:
            self.call_from_thread(self._apply_tag_summary, seq, {"Error": f"{e}"})
            return

        self.call_from_thread(self._start_tag_summary_progress, seq, len(children))

        aggregated: dict[str, dict[str, int]] = {}
        for child in children:
            try:
                child_details = plugin.get_details(self._session, child)
            except Exception:
                self.call_from_thread(self._advance_tag_summary_progress, seq)
                continue
            for k, v in extract_tags(child_details.raw).items():
                counts = aggregated.setdefault(k, {})
                counts[v] = counts.get(v, 0) + 1
            self.call_from_thread(self._advance_tag_summary_progress, seq)

        self.call_from_thread(self._apply_tag_summary, seq, aggregated)

    def _apply_tag_summary(
        self, seq: int, aggregated: dict[str, dict[str, int]]
    ) -> None:
        if seq != self._selection_seq:
            return
        try:
            self.query_one("#detail-pane", DetailPane).set_tag_summary(aggregated)
        except Exception:
            pass

    def _start_tag_summary_progress(self, seq: int, total: int) -> None:
        if seq != self._selection_seq:
            return
        try:
            self.query_one("#detail-pane", DetailPane).start_tag_summary_progress(total)
        except Exception:
            pass

    def _advance_tag_summary_progress(self, seq: int) -> None:
        if seq != self._selection_seq:
            return
        try:
            self.query_one("#detail-pane", DetailPane).advance_tag_summary_progress()
        except Exception:
            pass

    def on_tabbed_content_tab_activated(
        self, event: TabbedContent.TabActivated
    ) -> None:
        if event.pane.id != "tab-tag-summary":
            return
        if self._current_container_node is None:
            return
        try:
            tag_pane = self.query_one("#tab-tag-summary", TabPane)
        except Exception:
            return
        # Only fetch once per selection — re-activating an already-populated
        # tab shouldn't re-trigger the work.
        if self._tag_summary_seq == self._selection_seq:
            return
        self._tag_summary_seq = self._selection_seq
        try:
            status = tag_pane.query_one(".tag-summary-status", Static)
            status.update("Retrieving tag summary ...")
        except Exception:
            tag_pane.mount(
                Static("Retrieving tag summary ...", classes="tag-summary-status")
            )
        self._load_tag_summary(self._current_container_node, self._selection_seq)

    def _find_arn(self, obj: object) -> str:
        """Recursively find an ARN in a raw API response.

        Looks for a key whose name (case-insensitive) ends with 'arn'
        and whose value is a string starting with 'arn:'.
        """
        if isinstance(obj, dict):
            for key, value in obj.items():
                if (
                    isinstance(key, str)
                    and key.lower().endswith("arn")
                    and isinstance(value, str)
                    and value.startswith("arn:")
                ):
                    return value
            for value in obj.values():
                found = self._find_arn(value)
                if found:
                    return found
        elif isinstance(obj, list):
            for item in obj:
                found = self._find_arn(item)
                if found:
                    return found
        return ""

    def _build_session(self, region_name: str | None = None) -> boto3.Session:
        kwargs: dict[str, str] = {}
        if self._profile:
            kwargs["profile_name"] = self._profile
        if region_name:
            kwargs["region_name"] = region_name
        return boto3.Session(**kwargs)

    def on_region_changed(self, message: RegionChanged) -> None:
        if message.region == self._region:
            return

        self._region = message.region
        self._session = self._build_session(region_name=self._region)

        tree = self.query_one(AWSNavTree)
        tree.session = self._session
        tree.reset_tree()

        self.query_one("#detail-pane", DetailPane).show_placeholder()
        self.query_one("#tags-pane", TagsPane).show_placeholder()
        self._current_raw = {}
        self._current_subtitle = ""
        self._current_node = None
        self._selection_seq += 1
        self._current_container_node = None
