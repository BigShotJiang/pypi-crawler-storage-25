import logging
import json as json_mod

from .buffer import LogBuffer
from .client import AsyncSender
from .config import Config


class LogCollectorHandler(logging.Handler):
    def __init__(self, server_url: str = "http://localhost:8080", service: str = "",
                 batch_size: int = 50, flush_interval: float = 2.0,
                 max_buffer_size: int = 10000, max_retries: int = 3):
        super().__init__()
        self._config = Config(
            server_url=server_url,
            service=service,
            batch_size=batch_size,
            flush_interval=flush_interval,
            max_buffer_size=max_buffer_size,
            max_retries=max_retries,
        )
        self._buffer = LogBuffer(max_size=self._config.max_buffer_size)
        self._sender = AsyncSender(self._config, self._buffer)
        self._sender.start()

    def emit(self, record: logging.LogRecord):
        try:
            entry = self._format_record(record)
            self._buffer.put(entry)
        except Exception:
            self.handleError(record)

    def _format_record(self, record: logging.LogRecord) -> dict:
        entry = {
            "timestamp": int(record.created * 1000),
            "service": self._config.service,
            "hostname": self._config.hostname,
            "level": record.levelname,
            "message": self.format(record),
            "logger": record.name,
        }

        extra = {}
        for key in ("user_id", "trace_id", "request_id"):
            if hasattr(record, key):
                extra[key] = getattr(record, key)

        if extra:
            entry["extra"] = json_mod.dumps(extra)

        return entry

    def close(self):
        self._sender.stop()
        self._sender.flush()
        super().close()
