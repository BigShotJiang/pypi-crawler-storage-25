import socket
from dataclasses import dataclass, field


@dataclass
class Config:
    server_url: str = "http://localhost:8080"
    service: str = ""
    hostname: str = field(default_factory=socket.gethostname)
    batch_size: int = 50
    flush_interval: float = 2.0
    max_buffer_size: int = 10000
    max_retries: int = 3
    request_timeout: float = 5.0
