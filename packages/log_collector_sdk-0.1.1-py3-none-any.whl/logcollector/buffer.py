import queue


class LogBuffer:
    def __init__(self, max_size: int = 10000):
        self._queue = queue.Queue(maxsize=max_size)
        self._dropped = 0

    def put(self, item: dict) -> bool:
        try:
            self._queue.put_nowait(item)
            return True
        except queue.Full:
            self._dropped += 1
            return False

    def get_batch(self, max_size: int) -> list:
        items = []
        for _ in range(max_size):
            try:
                items.append(self._queue.get_nowait())
            except queue.Empty:
                break
        return items

    def size(self) -> int:
        return self._queue.qsize()

    def dropped(self) -> int:
        return self._dropped
