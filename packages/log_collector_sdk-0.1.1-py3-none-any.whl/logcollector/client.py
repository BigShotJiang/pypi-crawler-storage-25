import atexit
import json
import logging
import threading
import time

import urllib.request
import urllib.error

from .buffer import LogBuffer
from .config import Config

logger = logging.getLogger(__name__)


class AsyncSender:
    def __init__(self, config: Config, buffer: LogBuffer):
        self._config = config
        self._buffer = buffer
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._running = False

    def start(self):
        self._running = True
        self._thread.start()
        atexit.register(self.flush)

    def stop(self):
        self._running = False

    def flush(self):
        batch = self._buffer.get_batch(self._config.batch_size)
        if not batch:
            return
        self._send_batch(batch)

    def _run(self):
        last_flush = time.time()
        while self._running:
            time.sleep(0.1)
            now = time.time()
            size = self._buffer.size()
            if size >= self._config.batch_size or (size > 0 and now - last_flush >= self._config.flush_interval):
                self.flush()
                last_flush = now

    def _send_batch(self, batch: list):
        body = json.dumps({"logs": batch}).encode("utf-8")
        url = self._config.server_url.rstrip("/") + "/api/v1/logs/bulk"

        for attempt in range(self._config.max_retries):
            try:
                req = urllib.request.Request(
                    url, data=body,
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                urllib.request.urlopen(req, timeout=self._config.request_timeout)
                return
            except urllib.error.URLError:
                if attempt < self._config.max_retries - 1:
                    time.sleep(1)
            except Exception:
                break

        logger.warning("logcollector: failed to send %d logs after %d attempts", len(batch), self._config.max_retries)
