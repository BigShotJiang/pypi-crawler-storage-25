# Language features: stdlib imports, nested functions, lambdas,
# multi-line strings, generators, all prior features

import math
import itertools


def make_multiplier(factor):
    def multiply(x):
        return x * factor

    return multiply


double = make_multiplier(2)
triple = make_multiplier(3)

print(double(5))
print(triple(4))

# Lambda
transform = lambda x: x * x + 1
print(transform(3))

# Generator expression
squares_gen = (i * i for i in range(5))
print(list(squares_gen))

# Multi-line string
description = """This is a
multi-line string
with three lines"""
print(len(description.split("\n")))

# Stdlib: math
print(math.floor(3.7))
print(math.ceil(3.2))

# Stdlib: itertools
pairs = list(itertools.product([1, 2], ["a", "b"]))
print(len(pairs))


# Class with decorator and comprehensions
def validate(func):
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)

    return wrapper


def validate2(func):
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)

    return wrapper


@validate2
def validate3(func):
    @validate
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)

    return wrapper


class DataProcessor:
    def __init__(self, data):
        self.data = data

    @validate
    def filtered(self, threshold):
        return [x for x in self.data if x > threshold]

    @validate
    @validate2
    def two_decorators(self):
        return 1

    @validate
    @staticmethod
    @validate2
    def three_decorators():
        return 1

    @validate3
    def foo():
        pass

    def stats(self):
        total = sum(self.data)
        count = len(self.data)
        return {"total": total, "count": count}


proc = DataProcessor([10, 20, 30, 5, 15, 25])
print(sorted(proc.filtered(12)))
print(proc.stats()["total"])

# Try/except with custom logic
try:
    values = [1, 2, 3]
    print(values[1])
except IndexError:
    print("index error")
finally:
    print("done")

# Nested comprehension with conditional
matrix = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
flat_evens = [x for row in matrix for x in row if x % 2 == 0]
print(sorted(flat_evens))

# While with break
i = 0
while True:
    if i >= 3:
        break
    i = i + 1
print(f"stopped at {i}")

# F-string with expression
items = ["alpha", "beta", "gamma"]
for idx, item in enumerate(items):
    print(f"{idx}:{item}")

foo = 1 + 2
foo += 1.2 + 2.2
foo += 10**1
print(foo)
