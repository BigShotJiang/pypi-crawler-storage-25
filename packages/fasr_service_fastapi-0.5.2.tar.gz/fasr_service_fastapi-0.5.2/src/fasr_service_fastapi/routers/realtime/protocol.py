from __future__ import annotations

from typing import Any
from uuid import uuid4


def new_event_id() -> str:
    return f"event_{uuid4().hex[:20]}"


def create_event(event_type: str, **kwargs: Any) -> dict[str, Any]:
    event = {"event_id": new_event_id(), "type": event_type}
    event.update(kwargs)
    return event


def create_session_created_event(session: dict[str, Any]) -> dict[str, Any]:
    return create_event("session.created", session=session)


def create_session_updated_event(session: dict[str, Any]) -> dict[str, Any]:
    return create_event("session.updated", session=session)


def create_speech_started_event(
    item_id: str,
    audio_start_ms: int = 0,
) -> dict[str, Any]:
    return create_event(
        "input_audio_buffer.speech_started",
        audio_start_ms=audio_start_ms,
        item_id=item_id,
    )


def create_speech_stopped_event(
    item_id: str | None,
    audio_end_ms: int = 0,
) -> dict[str, Any]:
    event = create_event(
        "input_audio_buffer.speech_stopped",
        audio_end_ms=audio_end_ms,
    )
    if item_id is not None:
        event["item_id"] = item_id
    return event


def create_transcription_text_event(
    item_id: str,
    text: str,
    delta: str,
) -> dict[str, Any]:
    return create_event(
        "conversation.item.input_audio_transcription.text",
        item_id=item_id,
        text=text,
        delta=delta,
    )


def create_transcription_completed_event(
    item_id: str,
    text: str,
) -> dict[str, Any]:
    return create_event(
        "conversation.item.input_audio_transcription.completed",
        item_id=item_id,
        text=text,
    )


def create_session_finished_event() -> dict[str, Any]:
    return create_event("session.finished")


def create_error_event(
    code: str,
    message: str,
    event_id: str | None = None,
    param: str | None = None,
) -> dict[str, Any]:
    error = {
        "type": "invalid_request_error",
        "code": code,
        "message": message,
    }
    if param is not None:
        error["param"] = param
    if event_id is not None:
        error["event_id"] = event_id
    return create_event("error", error=error)
