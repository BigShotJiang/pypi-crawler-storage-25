from __future__ import annotations

from typing import Dict

from fastapi import APIRouter, WebSocket
from pydantic import Field

from fasr.config import registry
from fasr.model import ASRModel, Model, VADModel
from fasr.service import BaseRouter
from fasr_service_fastapi.asr_scheduler import ASRInferenceScheduler

from .handler import RealtimeWebSocketHandler


class RealtimeRouter(BaseRouter):
    handler: RealtimeWebSocketHandler | None = None
    model_map: Dict[str, str] = Field(default_factory=dict)

    def setup(
        self,
        service_id: str = "",
        models: Dict[str, Model] | None = None,
        asr_scheduler: ASRInferenceScheduler | None = None,
    ) -> RealtimeRouter:
        models = models or {}
        vad_model = self._get_model(models, "vad_model", VADModel)
        asr_model = self._get_model(models, "asr_model", ASRModel)
        if vad_model is None or not vad_model.supports_streaming():
            raise ValueError("Realtime router requires a streaming VAD model.")

        if asr_model is None or not asr_model.supports_streaming():
            raise ValueError("Realtime router requires a streaming ASR model.")

        if self.handler is None:
            self.handler = RealtimeWebSocketHandler()
        self.handler.setup(
            service_id=service_id,
            vad_model=vad_model,
            asr_model=asr_model,
            asr_scheduler=asr_scheduler,
        )
        return self

    def _get_model(
        self,
        models: Dict[str, Model],
        argument_name: str,
        model_type: type[Model],
    ) -> Model | None:
        model_name = self.model_map.get(argument_name)
        if model_name is None:
            return None
        if model_name not in models:
            raise ValueError(
                f"Router model map references unknown model '{model_name}'."
            )
        model = models[model_name]
        if not isinstance(model, model_type):
            raise TypeError(
                f"Router model '{model_name}' must be {model_type.__name__}, "
                f"got {type(model).__name__}."
            )
        return model

    def create_router(self) -> APIRouter:
        router = APIRouter(tags=["realtime"])

        @router.websocket("/v1/realtime")
        @router.websocket("/api-ws/v1/realtime")
        async def realtime_endpoint(websocket: WebSocket) -> None:
            await websocket.accept()
            await self.handler.handle_websocket(websocket)

        return router


@registry.service_routers.register("realtime.v1")
def realtime_entrypoint(
    handler: RealtimeWebSocketHandler | None = None,
    model_map: Dict[str, str] | None = None,
) -> RealtimeRouter:
    """Create a realtime router with concrete defaults."""
    return RealtimeRouter(
        handler=handler,
        model_map=model_map or {},
    )
