from __future__ import annotations

from typing import Any
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field

from fasr.data.audio import AudioChunk
from fasr.data.stream import AudioBytesStream


class ASRSession(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    session_id: str = Field(default_factory=lambda: f"sess_{uuid4().hex}")
    service_id: str = ""
    sample_rate: int = 16000
    chunk_size_ms: int = 100
    input_audio_format: str = "pcm"
    input_audio_transcription: dict[str, Any] = Field(
        default_factory=lambda: {"language": None}
    )
    turn_detection: dict[str, Any] = Field(default_factory=dict)
    audio_buffer: AudioBytesStream | None = None
    response_id: str | None = None
    item_id: str | None = None
    previous_item_id: str | None = None
    last_text: str = ""
    speech_active: bool = False
    total_samples: int = 0
    last_audio_chunk: AudioChunk | None = None

    def setup(self) -> ASRSession:
        self.audio_buffer = AudioBytesStream(
            sample_rate=self.sample_rate,
            chunk_size_ms=self.chunk_size_ms,
        )
        return self

    def default_session_payload(self) -> dict[str, Any]:
        return {
            "id": self.session_id,
            "type": "realtime",
            "input_audio_format": self.input_audio_format,
            "sample_rate": self.sample_rate,
            "input_audio_transcription": self.input_audio_transcription,
            "turn_detection": self.turn_detection,
        }

    def reset_audio_buffer(self) -> None:
        self.audio_buffer = AudioBytesStream(
            sample_rate=self.sample_rate,
            chunk_size_ms=self.chunk_size_ms,
        )
        self.response_id = None
        self.item_id = None
        self.previous_item_id = None
        self.last_text = ""
        self.speech_active = False
        self.total_samples = 0
        self.last_audio_chunk = None

    def has_pending_audio(self) -> bool:
        if self.audio_buffer is None:
            return False
        return len(self.audio_buffer._buf) > 0
