from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
import json
from typing import Any
from uuid import uuid4

from fastapi import WebSocket, WebSocketDisconnect
from loguru import logger
import numpy as np
from pydantic import BaseModel, ConfigDict

from fasr.data.audio import AudioChunk
from fasr.data.waveform import Waveform
from fasr.model import ASRModel, VADModel
from fasr_service_fastapi.asr_scheduler import (
    ASR_PRIORITY_REALTIME,
    ASRInferenceScheduler,
)

from .protocol import (
    create_error_event,
    create_session_created_event,
    create_session_finished_event,
    create_session_updated_event,
    create_speech_started_event,
    create_speech_stopped_event,
    create_transcription_completed_event,
    create_transcription_text_event,
)
from .session import ASRSession


@dataclass
class ASRQueueItem:
    item_id: str
    chunk: AudioChunk | None
    use_vad_completion: bool
    stop: bool = False


@dataclass
class RealtimeRuntime:
    vad_model: VADModel | None = None
    send_lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    asr_queue: asyncio.Queue[ASRQueueItem] = field(default_factory=asyncio.Queue)
    last_text_by_item: dict[str, str] = field(default_factory=dict)
    asr_worker: asyncio.Task[None] | None = None


class RealtimeWebSocketHandler(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    service_id: str = ""
    vad_model: VADModel | None = None
    asr_model: ASRModel | None = None
    sample_rate: int = 16000
    chunk_size_ms: int = 100
    model_name: str = "realtime"
    min_asr_samples: int = 401
    min_vad_final_samples: int = 400
    asr_scheduler: ASRInferenceScheduler | None = None

    def setup(
        self,
        service_id: str = "",
        vad_model: VADModel | None = None,
        asr_model: ASRModel | None = None,
        asr_scheduler: ASRInferenceScheduler | None = None,
    ) -> RealtimeWebSocketHandler:
        if service_id:
            self.service_id = service_id
        if vad_model is not None:
            self.vad_model = vad_model
        if asr_model is not None:
            self.asr_model = asr_model
        if asr_scheduler is not None:
            self.asr_scheduler = asr_scheduler
        return self

    async def handle_websocket(self, websocket: WebSocket) -> None:
        session = ASRSession(
            service_id=self.service_id,
            sample_rate=self.sample_rate,
            chunk_size_ms=self.chunk_size_ms,
            turn_detection={"type": "server_vad"},
        ).setup()
        runtime = RealtimeRuntime(vad_model=self._create_session_vad_model())
        if self.asr_model is not None:
            runtime.asr_worker = asyncio.create_task(
                self._asr_worker_loop(websocket, session, runtime)
            )
        await self._send_event(
            websocket,
            create_session_created_event(session.default_session_payload()),
            session_id=session.session_id,
            runtime=runtime,
        )
        logger.info("Realtime websocket started: service_id={}", self.service_id)

        try:
            while True:
                message = await websocket.receive_text()
                payload = json.loads(message)
                await self._dispatch_event(websocket, session, runtime, payload)
        except WebSocketDisconnect:
            logger.info(
                "Realtime websocket disconnected: service_id={}", self.service_id
            )
        except RuntimeError as exc:
            if "WebSocket is not connected" in str(exc):
                logger.info(
                    "Realtime websocket disconnected: service_id={}",
                    self.service_id,
                )
            else:
                logger.exception(
                    "Realtime websocket failed: service_id={}", self.service_id
                )
                raise
        except Exception:
            logger.exception(
                "Realtime websocket failed: service_id={}", self.service_id
            )
            raise
        finally:
            self._cleanup_stream_states(session, runtime)
            await self._shutdown_runtime(runtime)

    async def _dispatch_event(
        self,
        websocket: WebSocket,
        session: ASRSession,
        runtime: RealtimeRuntime,
        payload: dict[str, Any],
    ) -> None:
        event_type = payload.get("type")
        if event_type == "session.update":
            await self._handle_session_update(websocket, session, runtime, payload)
            return
        if event_type == "input_audio_buffer.append":
            await self._handle_audio_append(websocket, session, runtime, payload)
            return
        if event_type == "input_audio_buffer.commit":
            await self._handle_audio_commit(websocket, session, runtime, payload)
            return
        if event_type == "session.finish":
            await self._handle_session_finish(websocket, session, runtime, payload)
            return
        await self._send_event(
            websocket,
            create_error_event(
                code="unsupported_event",
                message=f"Unsupported event type: {event_type}",
                event_id=payload.get("event_id"),
            ),
            session_id=session.session_id,
            runtime=runtime,
        )

    async def _handle_session_update(
        self,
        websocket: WebSocket,
        session: ASRSession,
        runtime: RealtimeRuntime,
        payload: dict[str, Any],
    ) -> None:
        session_update = payload.get("session", {})

        input_audio_format = session_update.get("input_audio_format")
        if input_audio_format is not None:
            session.input_audio_format = input_audio_format

        sample_rate = session_update.get("sample_rate")
        if sample_rate is not None:
            session.sample_rate = sample_rate

        input_audio_transcription = session_update.get("input_audio_transcription")
        if input_audio_transcription is not None:
            session.input_audio_transcription = input_audio_transcription

        if "turn_detection" in session_update:
            turn_detection = session_update.get("turn_detection")
            session.turn_detection = turn_detection or {}
            self._apply_turn_detection(runtime.vad_model, session.turn_detection)

        session.setup()
        await self._send_event(
            websocket,
            create_session_updated_event(session.default_session_payload()),
            session_id=session.session_id,
            runtime=runtime,
        )

    async def _handle_audio_append(
        self,
        websocket: WebSocket,
        session: ASRSession,
        runtime: RealtimeRuntime,
        payload: dict[str, Any],
    ) -> None:
        audio_b64 = payload.get("audio")
        if not audio_b64:
            await self._send_event(
                websocket,
                create_error_event(
                    code="invalid_audio",
                    message="Missing audio payload",
                    event_id=payload.get("event_id"),
                    param="audio",
                ),
                session_id=session.session_id,
                runtime=runtime,
            )
            return

        try:
            audio_bytes = __import__("base64").b64decode(audio_b64)
        except Exception:
            await self._send_event(
                websocket,
                create_error_event(
                    code="invalid_audio",
                    message="Failed to decode base64 audio",
                    event_id=payload.get("event_id"),
                    param="audio",
                ),
                session_id=session.session_id,
                runtime=runtime,
            )
            return

        if session.audio_buffer is None:
            session.setup()

        chunks = session.audio_buffer.push(audio_bytes)
        for chunk in chunks:
            if not self._is_empty_chunk(chunk):
                session.last_audio_chunk = chunk
            session.total_samples += len(chunk.waveform.data)
            await self._process_chunk(websocket, session, runtime, chunk)

    async def _handle_audio_commit(
        self,
        websocket: WebSocket,
        session: ASRSession,
        runtime: RealtimeRuntime,
        payload: dict[str, Any],
    ) -> None:
        if session.audio_buffer is None:
            session.setup()

        has_pending_audio = session.has_pending_audio()
        has_vad_state = self._has_vad_state(session, runtime)
        should_finalize_without_buffer = (
            (session.speech_active or has_vad_state)
            and not has_pending_audio
            and session.last_audio_chunk is not None
        )

        if not has_pending_audio and not should_finalize_without_buffer:
            return

        if runtime.vad_model is None and session.item_id is None:
            session.item_id = self._new_item_id()

        if runtime.vad_model is None and session.speech_active:
            await self._send_event(
                websocket,
                create_speech_stopped_event(
                    item_id=session.item_id,
                    audio_end_ms=self._audio_end_ms(session),
                ),
                session_id=session.session_id,
                runtime=runtime,
            )
            session.speech_active = False

        chunks = session.audio_buffer.flush()
        if not chunks and should_finalize_without_buffer:
            await self._finalize_active_segment_without_pending_buffer(
                websocket, session, runtime
            )
        for chunk in chunks:
            if not self._is_empty_chunk(chunk):
                session.last_audio_chunk = chunk
            session.total_samples += len(chunk.waveform.data)
            await self._process_chunk(websocket, session, runtime, chunk)

        await self._drain_asr_queue(runtime)

        if runtime.vad_model is None and session.item_id is not None:
            await self._send_event(
                websocket,
                create_transcription_completed_event(
                    item_id=session.item_id,
                    text=session.last_text,
                ),
                session_id=session.session_id,
                runtime=runtime,
            )
        self._cleanup_stream_states(session, runtime)
        session.previous_item_id = session.item_id
        session.item_id = None
        session.last_text = ""
        session.audio_buffer = None
        session.last_audio_chunk = None

    async def _handle_session_finish(
        self,
        websocket: WebSocket,
        session: ASRSession,
        runtime: RealtimeRuntime,
        payload: dict[str, Any],
    ) -> None:
        if (
            session.item_id is not None
            or session.has_pending_audio()
            or self._has_vad_state(session, runtime)
        ):
            await self._handle_audio_commit(websocket, session, runtime, payload)
        await self._send_event(
            websocket,
            create_session_finished_event(),
            session_id=session.session_id,
            runtime=runtime,
        )

    async def _process_chunk(
        self,
        websocket: WebSocket,
        session: ASRSession,
        runtime: RealtimeRuntime,
        chunk: AudioChunk,
    ) -> None:
        if self._is_empty_chunk(chunk):
            if chunk.is_last and session.speech_active:
                await self._send_event(
                    websocket,
                    create_speech_stopped_event(
                        item_id=session.item_id or self._new_item_id(),
                        audio_end_ms=self._audio_end_ms(session),
                    ),
                    session_id=session.session_id,
                    runtime=runtime,
                )
                session.speech_active = False
                if self.asr_model is not None:
                    self.asr_model.remove_state(chunk.stream_id)
                if session.item_id is not None:
                    runtime.last_text_by_item.pop(session.item_id, None)
                    session.item_id = None
            return

        if self._should_bypass_vad_for_short_final_chunk(chunk, runtime):
            await self._finalize_short_tail_without_vad(
                websocket, session, runtime, chunk
            )
            return

        emitted_chunks = [chunk]
        vad_model = runtime.vad_model
        if vad_model is not None:
            try:
                emitted_chunks = list(vad_model.push_chunk(chunk))
            except Exception:
                if self._should_bypass_vad_for_short_final_chunk(chunk, runtime):
                    await self._finalize_short_tail_without_vad(
                        websocket, session, runtime, chunk
                    )
                    return
                raise

        for emitted in emitted_chunks:
            if self._is_empty_chunk(emitted):
                if emitted.vad_state == "segment_end" and session.speech_active:
                    current_item_id = session.item_id
                    await self._send_event(
                        websocket,
                        create_speech_stopped_event(
                            item_id=current_item_id or self._new_item_id(),
                            audio_end_ms=self._audio_end_ms(session),
                        ),
                        session_id=session.session_id,
                        runtime=runtime,
                    )
                    session.speech_active = False
                    if (
                        self.asr_model is not None
                        and current_item_id is not None
                        and not self._is_empty_chunk(chunk)
                    ):
                        finalize_chunk = chunk.model_copy(
                            update={"is_start": False, "is_last": True}
                        )
                        logger.debug(
                            "Realtime ASR enqueue finalize(empty_end): session_id={}, stream_id={}, item_id={}, samples={}",
                            session.session_id,
                            finalize_chunk.stream_id,
                            current_item_id,
                            len(finalize_chunk.waveform.data),
                        )
                        await runtime.asr_queue.put(
                            ASRQueueItem(
                                item_id=current_item_id,
                                chunk=finalize_chunk,
                                use_vad_completion=True,
                            )
                        )
                    session.item_id = None
                continue
            is_mid_chunk = emitted.vad_state == "segment_mid"
            should_start_speech = not session.speech_active and (
                emitted.vad_state == "segment_start" or is_mid_chunk
            )
            if should_start_speech:
                if session.item_id is None:
                    session.item_id = self._new_item_id()
                session.last_text = ""
                session.speech_active = True
                await self._send_event(
                    websocket,
                    create_speech_started_event(
                        item_id=session.item_id,
                        audio_start_ms=self._audio_start_ms(session, emitted),
                    ),
                    session_id=session.session_id,
                    runtime=runtime,
                )

            if emitted.vad_state == "segment_end" and not session.speech_active:
                session.item_id = None
                continue

            if session.item_id is None:
                session.item_id = self._new_item_id()
            current_item_id = session.item_id

            should_stop_speech = session.speech_active and (
                emitted.vad_state == "segment_end" or (is_mid_chunk and emitted.is_last)
            )
            if should_stop_speech:
                await self._send_event(
                    websocket,
                    create_speech_stopped_event(
                        item_id=session.item_id,
                        audio_end_ms=(
                            int(emitted.end_ms)
                            if emitted.end_ms is not None
                            else self._audio_end_ms(session)
                        ),
                    ),
                    session_id=session.session_id,
                    runtime=runtime,
                )
                session.speech_active = False

            if self.asr_model is not None:
                logger.debug(
                    "Realtime ASR enqueue: session_id={}, stream_id={}, item_id={}, is_start={}, is_last={}, samples={}",
                    session.session_id,
                    emitted.stream_id,
                    current_item_id,
                    bool(emitted.is_start),
                    bool(emitted.is_last),
                    len(emitted.waveform.data),
                )
                await runtime.asr_queue.put(
                    ASRQueueItem(
                        item_id=current_item_id,
                        chunk=emitted,
                        use_vad_completion=vad_model is not None,
                    )
                )
                if emitted.vad_state == "segment_end" and not emitted.is_last:
                    finalize_chunk = emitted.model_copy(
                        update={"is_start": False, "is_last": True}
                    )
                    logger.debug(
                        "Realtime ASR enqueue finalize: session_id={}, stream_id={}, item_id={}, samples={}",
                        session.session_id,
                        finalize_chunk.stream_id,
                        current_item_id,
                        len(finalize_chunk.waveform.data),
                    )
                    await runtime.asr_queue.put(
                        ASRQueueItem(
                            item_id=current_item_id,
                            chunk=finalize_chunk,
                            use_vad_completion=True,
                        )
                    )
            if emitted.vad_state == "segment_end":
                session.item_id = None
            elif is_mid_chunk and emitted.is_last:
                session.item_id = None

    async def _asr_worker_loop(
        self,
        websocket: WebSocket,
        session: ASRSession,
        runtime: RealtimeRuntime,
    ) -> None:
        while True:
            queue_item = await runtime.asr_queue.get()
            if queue_item.stop:
                runtime.asr_queue.task_done()
                break
            try:
                if self.asr_model is None:
                    continue
                if queue_item.chunk is None:
                    continue
                logger.debug(
                    "Realtime ASR dequeue: session_id={}, stream_id={}, item_id={}, is_start={}, is_last={}, samples={}",
                    session.session_id,
                    queue_item.chunk.stream_id,
                    queue_item.item_id,
                    bool(queue_item.chunk.is_start),
                    bool(queue_item.chunk.is_last),
                    len(queue_item.chunk.waveform.data),
                )
                self._normalize_last_chunk_for_asr(
                    queue_item.chunk, session.sample_rate
                )
                span = self._push_asr_chunk(queue_item.chunk)
                if span is None:
                    continue
                text = span.text or span.raw_text or ""
                previous = runtime.last_text_by_item.get(queue_item.item_id, "")
                delta = self._compute_delta(previous, text)
                if queue_item.use_vad_completion and span.is_last:
                    await self._send_event(
                        websocket,
                        create_transcription_completed_event(
                            item_id=queue_item.item_id,
                            text=text,
                        ),
                        session_id=session.session_id,
                        runtime=runtime,
                    )
                    runtime.last_text_by_item.pop(queue_item.item_id, None)
                else:
                    runtime.last_text_by_item[queue_item.item_id] = text
                    session.last_text = text
                    await self._send_event(
                        websocket,
                        create_transcription_text_event(
                            item_id=queue_item.item_id,
                            text=text,
                            delta=delta,
                        ),
                        session_id=session.session_id,
                        runtime=runtime,
                    )
            except Exception as exc:
                if self.asr_model is not None and queue_item.chunk is not None:
                    self.asr_model.remove_state(queue_item.chunk.stream_id)
                runtime.last_text_by_item.pop(queue_item.item_id, None)
                logger.exception(
                    "Realtime ASR worker failed: session_id={}, item_id={}, error={}",
                    session.session_id,
                    queue_item.item_id,
                    exc,
                )
                await self._send_event(
                    websocket,
                    create_error_event(
                        code="asr_runtime_error",
                        message=str(exc),
                    ),
                    session_id=session.session_id,
                    runtime=runtime,
                )
            finally:
                runtime.asr_queue.task_done()

    async def _drain_asr_queue(self, runtime: RealtimeRuntime) -> None:
        if self.asr_model is None:
            return
        await runtime.asr_queue.join()

    async def _shutdown_runtime(self, runtime: RealtimeRuntime) -> None:
        if runtime.asr_worker is None:
            return
        await runtime.asr_queue.put(
            ASRQueueItem(
                item_id="",
                chunk=None,
                use_vad_completion=False,
                stop=True,
            )
        )
        await runtime.asr_worker

    async def _finalize_active_segment_without_pending_buffer(
        self,
        websocket: WebSocket,
        session: ASRSession,
        runtime: RealtimeRuntime,
    ) -> None:
        if session.last_audio_chunk is None:
            return
        finalize_chunk = session.last_audio_chunk.model_copy(
            update={"is_start": False, "is_last": True}
        )
        if runtime.vad_model is not None:
            logger.debug(
                "Realtime VAD finalize(no_pending_buffer): session_id={}, stream_id={}, samples={}",
                session.session_id,
                finalize_chunk.stream_id,
                len(finalize_chunk.waveform.data),
            )
            await self._process_chunk(websocket, session, runtime, finalize_chunk)
            return
        if session.item_id is None:
            return
        if self.asr_model is None:
            return
        await self._send_event(
            websocket,
            create_speech_stopped_event(
                item_id=session.item_id,
                audio_end_ms=self._audio_end_ms(session),
            ),
            session_id=session.session_id,
            runtime=runtime,
        )
        session.speech_active = False
        logger.debug(
            "Realtime ASR enqueue finalize(no_pending_buffer): session_id={}, stream_id={}, item_id={}, samples={}",
            session.session_id,
            finalize_chunk.stream_id,
            session.item_id,
            len(finalize_chunk.waveform.data),
        )
        await runtime.asr_queue.put(
            ASRQueueItem(
                item_id=session.item_id,
                chunk=finalize_chunk,
                use_vad_completion=False,
            )
        )

    async def _finalize_short_tail_without_vad(
        self,
        websocket: WebSocket,
        session: ASRSession,
        runtime: RealtimeRuntime,
        chunk: AudioChunk,
    ) -> None:
        if session.item_id is None:
            return
        if session.speech_active:
            await self._send_event(
                websocket,
                create_speech_stopped_event(
                    item_id=session.item_id,
                    audio_end_ms=self._audio_end_ms(session),
                ),
                session_id=session.session_id,
                runtime=runtime,
            )
            session.speech_active = False
        if self.asr_model is None:
            session.item_id = None
            return
        logger.debug(
            "Realtime ASR enqueue finalize(short_tail): session_id={}, stream_id={}, item_id={}, samples={}",
            session.session_id,
            chunk.stream_id,
            session.item_id,
            len(chunk.waveform.data),
        )
        await runtime.asr_queue.put(
            ASRQueueItem(
                item_id=session.item_id,
                chunk=chunk.model_copy(update={"is_start": False, "is_last": True}),
                use_vad_completion=True,
            )
        )
        session.item_id = None

    async def _send_event(
        self,
        websocket: WebSocket,
        event: dict[str, Any],
        session_id: str,
        runtime: RealtimeRuntime,
    ) -> None:
        async with runtime.send_lock:
            try:
                await websocket.send_json(event)
            except (WebSocketDisconnect, RuntimeError):
                return
        logger.debug(
            "Realtime event sent: session_id={}, event_type={}",
            session_id,
            event.get("type"),
        )

    def _audio_start_ms(self, session: ASRSession, chunk: AudioChunk) -> int:
        if chunk.start_ms is not None:
            return int(chunk.start_ms)
        total_ms = int(session.total_samples / session.sample_rate * 1000)
        chunk_ms = int(chunk.waveform.duration_ms)
        return max(total_ms - chunk_ms, 0)

    def _audio_end_ms(self, session: ASRSession) -> int:
        return int(session.total_samples / session.sample_rate * 1000)

    def _new_item_id(self) -> str:
        return f"item_{uuid4().hex[:20]}"

    def _push_asr_chunk(self, chunk: AudioChunk):
        if self.asr_model is None:
            return None
        if self.asr_scheduler is None:
            return self.asr_model.push_chunk(chunk)
        return self.asr_scheduler.submit_sync(
            f"{type(self.asr_model).__name__}.push_chunk",
            lambda: self.asr_model.push_chunk(chunk),
            priority=ASR_PRIORITY_REALTIME,
        )

    def _compute_delta(self, previous_text: str, current_text: str) -> str:
        if current_text.startswith(previous_text):
            return current_text[len(previous_text) :]
        return current_text

    def _cleanup_stream_states(
        self, session: ASRSession, runtime: RealtimeRuntime
    ) -> None:
        if session.audio_buffer is None:
            return
        stream_id = session.audio_buffer._id
        if runtime.vad_model is not None:
            runtime.vad_model.remove_state(stream_id)
        if self.asr_model is not None:
            self.asr_model.remove_state(stream_id)

    def _normalize_last_chunk_for_asr(
        self, chunk: AudioChunk, sample_rate: int
    ) -> None:
        if not chunk.is_last:
            return
        sample_count = len(chunk.waveform.data)
        if sample_count >= self.min_asr_samples:
            return
        pad_width = self.min_asr_samples - sample_count
        padded = np.pad(chunk.waveform.data, (0, pad_width), mode="constant")
        chunk.waveform = Waveform(
            data=padded.astype(np.float32, copy=False),
            sample_rate=sample_rate,
        )

    def _create_session_vad_model(self) -> VADModel | None:
        if self.vad_model is None:
            return None
        config = self.vad_model.model_dump()
        config["states"] = {}
        return type(self.vad_model)(**config)

    def _apply_turn_detection(
        self, vad_model: VADModel | None, turn_detection: dict[str, Any]
    ) -> None:
        if vad_model is None:
            return
        if turn_detection.get("type") != "server_vad":
            return
        silence_duration_ms = turn_detection.get("silence_duration_ms")
        threshold = turn_detection.get("threshold")

        if hasattr(vad_model, "apply_turn_detection"):
            vad_model.apply_turn_detection(
                silence_duration_ms=silence_duration_ms,
                threshold=threshold,
            )
            return

        if silence_duration_ms is not None and hasattr(
            vad_model, "max_end_silence_time"
        ):
            vad_model.max_end_silence_time = int(silence_duration_ms)

        if threshold is not None:
            if hasattr(vad_model, "speech_noise_thres"):
                vad_model.speech_noise_thres = float(threshold)
            elif hasattr(vad_model, "speech_threshold"):
                vad_model.speech_threshold = float(threshold)

    def _is_empty_chunk(self, chunk: AudioChunk) -> bool:
        return len(chunk.waveform.data) == 0

    def _has_vad_state(self, session: ASRSession, runtime: RealtimeRuntime) -> bool:
        return (
            runtime.vad_model is not None
            and session.last_audio_chunk is not None
            and runtime.vad_model.get_state(session.last_audio_chunk.stream_id)
            is not None
        )

    def _should_bypass_vad_for_short_final_chunk(
        self, chunk: AudioChunk, runtime: RealtimeRuntime
    ) -> bool:
        return (
            runtime.vad_model is not None
            and chunk.is_last
            and len(chunk.waveform.data) < self.min_vad_final_samples
        )
