from __future__ import annotations

import asyncio
import base64
from io import BytesIO
import time
from typing import Any, Dict

from fastapi import APIRouter
from loguru import logger
from pydantic import Field, PrivateAttr

from fasr.components import (
    AudioLoader,
    SpeechRecognizer,
    SpeechSentencizer,
    VoiceDetector,
)
from fasr.components.base import BaseComponent
from fasr.config import registry
from fasr.data.audio import Audio, AudioList
from fasr.model import ASRModel, Model, PuncModel, VADModel
from fasr.pipeline import AudioPipeline, Pipe
from fasr.service import BaseRouter
from fasr_service_fastapi.asr_scheduler import ASRInferenceScheduler, ScheduledASRModel
from fasr_service_fastapi.schema import (
    AudioInput,
    InferenceData,
    InferencePerformance,
    InferenceRequest,
    InferenceResponse,
    SentenceResult,
    TextResult,
)


class TranscribeRouter(BaseRouter):
    service_id: str = ""
    loader: AudioLoader = Field(default_factory=AudioLoader)
    detector: VoiceDetector = Field(default_factory=VoiceDetector)
    recognizer: SpeechRecognizer = Field(default_factory=SpeechRecognizer)
    sentencizer: SpeechSentencizer | None = None
    model_map: Dict[str, str] = Field(default_factory=dict)
    _pipeline: AudioPipeline | None = PrivateAttr(default=None)

    def setup(
        self,
        service_id: str = "",
        models: Dict[str, Model] | None = None,
        asr_scheduler: ASRInferenceScheduler | None = None,
    ) -> TranscribeRouter:
        if service_id:
            self.service_id = service_id
        models = models or {}
        vad_model = self._get_model(models, "vad_model", VADModel)
        asr_model = self._get_model(models, "asr_model", ASRModel)
        punc_model = self._get_model(models, "punc_model", PuncModel)
        if self.detector is not None and vad_model is not None:
            self.detector.model = vad_model
        if self.recognizer is not None and asr_model is not None:
            self.recognizer.model = asr_model
        if self.sentencizer is None and punc_model is not None:
            self.sentencizer = SpeechSentencizer()
        if self.sentencizer is not None and punc_model is not None:
            self.sentencizer.model = punc_model
        self._pipeline = self._build_pipeline(asr_scheduler=asr_scheduler)
        return self

    def _build_pipeline(
        self,
        asr_scheduler: ASRInferenceScheduler | None = None,
    ) -> AudioPipeline:
        """Build a transcribe pipeline from initialized router components."""
        if self.loader is None or self.detector is None or self.recognizer is None:
            raise ValueError("Transcribe components are not fully initialized.")
        recognizer = self.recognizer
        if asr_scheduler is not None and self.recognizer.model is not None:
            recognizer = self.recognizer.model_copy(deep=False)
            recognizer.model = ScheduledASRModel(
                model=self.recognizer.model,
                scheduler=asr_scheduler,
            )
        pipes: Dict[str, Pipe] = {
            "loader": Pipe.from_component(self.loader),
            "detector": Pipe.from_component(self.detector),
            "recognizer": Pipe.from_component(recognizer),
        }
        pipe_order = ["loader", "detector", "recognizer"]
        if self.sentencizer is not None and self.sentencizer.model is not None:
            pipes["sentencizer"] = Pipe.from_component(self.sentencizer)
            pipe_order.append("sentencizer")
        return AudioPipeline(pipes=pipes, pipe_order=pipe_order)

    def _get_model(
        self,
        models: Dict[str, Model],
        argument_name: str,
        model_type: type[Model],
    ) -> Model | None:
        model_name = self.model_map.get(argument_name)
        if model_name is None:
            return None
        if model_name not in models:
            raise ValueError(
                f"Router model map references unknown model '{model_name}'."
            )
        model = models[model_name]
        if not isinstance(model, model_type):
            raise TypeError(
                f"Router model '{model_name}' must be {model_type.__name__}, "
                f"got {type(model).__name__}."
            )
        return model

    def create_router(self) -> APIRouter:
        router = APIRouter(tags=["transcribe"])

        @router.post("/transcribe", response_model=InferenceResponse)
        async def transcribe(request: InferenceRequest) -> InferenceResponse:
            return await self.handle(request)

        @router.post("/inference", response_model=InferenceResponse)
        async def inference(request: InferenceRequest) -> InferenceResponse:
            return await self.handle(request)

        return router

    async def handle(self, request: InferenceRequest) -> InferenceResponse:
        t_batch0 = time.perf_counter()
        num_items = len(request.inputs)
        logger.info(
            "Transcribe request started: service_id={}, num_items={}",
            self.service_id,
            num_items,
        )

        if self.loader is None or self.detector is None or self.recognizer is None:
            wall = time.perf_counter() - t_batch0
            logger.error(
                "Transcribe request failed: service_id={}, num_items={}, reason=components_not_initialized, wall_seconds={:.4f}",
                self.service_id,
                num_items,
                wall,
            )
            if num_items == 0:
                return InferenceResponse(
                    data=[],
                    inference_performance=self._batch_performance(0, wall, 0.0),
                )

            err_list = [
                InferenceData(
                    serviceId=self.service_id,
                    spentSeconds=0,
                    spentDetails={},
                    text=TextResult(),
                    sentences=[],
                    is_bad=True,
                    bad_reason="transcribe components 未初始化",
                    bad_componet="transcribe",
                )
                for _ in range(num_items)
            ]
            return InferenceResponse(
                data=err_list,
                inference_performance=self._batch_performance(num_items, wall, 0.0),
            )

        audios = self._build_request_audios(request)
        valid_audios = AudioList([audio for audio in audios if not audio.is_bad])
        bad_items = len(audios) - len(valid_audios)

        try:
            if len(valid_audios) > 0:
                valid_audios = await asyncio.to_thread(self._run_pipeline, valid_audios)
        except Exception:
            wall = time.perf_counter() - t_batch0
            logger.exception(
                "Transcribe request crashed: service_id={}, num_items={}, valid_items={}, bad_items={}, wall_seconds={:.4f}",
                self.service_id,
                num_items,
                len(valid_audios),
                bad_items,
                wall,
            )
            raise

        response_results = []
        for audio in audios:
            if audio.is_bad:
                response_results.append(self._build_inference_data(audio))
                continue

            response_results.append(self._build_inference_data(audio))

        total_audio_s = 0.0
        for audio in audios:
            if audio.is_bad:
                continue
            if audio.duration is not None:
                total_audio_s += float(audio.duration)

        wall = time.perf_counter() - t_batch0
        logger.info(
            "Transcribe request finished: service_id={}, num_items={}, valid_items={}, bad_items={}, total_audio_seconds={:.4f}, wall_seconds={:.4f}",
            self.service_id,
            num_items,
            len(valid_audios),
            bad_items,
            total_audio_s,
            wall,
        )
        return InferenceResponse(
            data=response_results,
            inference_performance=self._batch_performance(
                num_items,
                wall,
                total_audio_s,
            ),
        )

    def _run_components(self, audios: AudioList) -> AudioList:
        audios = self._run_timed_component(audios, self.loader)
        audios = self._run_timed_component(audios, self.detector)
        if self.recognizer is not None:
            audios = self._run_timed_component(audios, self.recognizer)
        if self.sentencizer is not None and self.sentencizer.model is not None:
            audios = self._run_timed_component(audios, self.sentencizer)
        return audios

    def _run_pipeline(self, audios: AudioList) -> AudioList:
        if self._pipeline is None:
            raise ValueError("Transcribe pipeline is not initialized.")
        return self._pipeline.run(audios)

    def _run_timed_component(
        self,
        audios: AudioList,
        component: BaseComponent,
    ) -> AudioList:
        start = time.perf_counter()
        audios = audios | component
        spent = time.perf_counter() - start
        self._record_spent_time(audios, component.name or "component", spent)
        return audios

    def _record_spent_time(
        self,
        audios: AudioList,
        component_name: str,
        spent: float,
    ) -> None:
        spent = round(float(spent), 3)
        for audio in audios:
            if audio.spent_time is None:
                audio.spent_time = {}
            audio.spent_time[component_name] = round(
                audio.spent_time.get(component_name, 0.0) + spent,
                3,
            )

    def _build_request_audios(self, request: InferenceRequest) -> AudioList:
        audios = AudioList()
        for input_item in request.inputs:
            audios.append(self._create_audio_from_input(input_item))
        return audios

    def _create_audio_from_input(self, input_item: AudioInput) -> Audio:
        audio = Audio()

        if input_item.url:
            audio.url = input_item.url
        elif input_item.b64_str:
            audio_bytes = base64.b64decode(input_item.b64_str)
            audio.url = "input.wav"
            audio.load_bytes_io(BytesIO(audio_bytes))
        else:
            audio.is_bad = True
            audio.bad_reason = "必须提供 url 或 b64_str 之一"
            return audio

        if input_item.mono is not None:
            audio.mono = input_item.mono

        if input_item.hotword:
            hotwords = set(input_item.hotword.split())
            audio.hotwords = frozenset(hotwords)

        return audio

    def _extract_audio_text(self, audio: Audio) -> str:
        if audio.channels is None:
            return ""

        texts = []
        for channel in audio.channels:
            channel_text = channel.text or ""
            if channel_text:
                texts.append(channel_text)
        return "".join(texts).strip()

    def _build_inference_data(self, audio: Audio) -> InferenceData:
        if audio.is_bad:
            return InferenceData(
                serviceId=self.service_id,
                spentSeconds=0,
                spentDetails={},
                text=TextResult(),
                sentences=[],
                is_bad=True,
                bad_reason=str(audio.bad_reason)
                if audio.bad_reason
                else "audio is bad",
                bad_componet=audio.bad_component,
            )

        mono_text = ""
        left_text = ""
        right_text = ""
        sentences: list[SentenceResult] = []

        if audio.channels is not None:
            num_channels = len(audio.channels)
            for idx, channel in enumerate(audio.channels):
                if num_channels == 1:
                    channel_name = "mono"
                else:
                    channel_name = (
                        "left" if idx == 0 else "right" if idx == 1 else f"ch{idx}"
                    )

                channel_text = channel.text or ""
                if channel_name == "mono":
                    mono_text = channel_text
                elif channel_name == "left":
                    left_text = channel_text
                elif channel_name == "right":
                    right_text = channel_text

                if channel.sents is not None:
                    for sent in channel.sents:
                        sent_text = (sent.text or "").strip()
                        if sent_text == "":
                            continue
                        start_time = int(sent.start_ms or 0)
                        end_time = int(sent.end_ms or 0)
                        sentences.append(
                            SentenceResult(
                                text=sent_text,
                                startTime=start_time,
                                endTime=end_time,
                                duration=max(end_time - start_time, 0),
                                channel=channel_name,
                                sentenceIndex=0,
                            )
                        )
                elif channel.segments is not None:
                    for seg in channel.segments:
                        seg_text = (seg.text or "").strip()
                        if seg_text == "":
                            continue
                        start_time = int(seg.start_ms or 0)
                        end_time = int(seg.end_ms or 0)
                        sentences.append(
                            SentenceResult(
                                text=seg_text,
                                startTime=start_time,
                                endTime=end_time,
                                duration=max(end_time - start_time, 0),
                                channel=channel_name,
                                sentenceIndex=0,
                            )
                        )

        sentences.sort(key=lambda s: (s.startTime, s.endTime))
        for idx, sent in enumerate(sentences):
            sent.sentenceIndex = idx

        spent_details = (
            {key: round(value, 3) for key, value in audio.spent_time.items()}
            if audio.spent_time
            else {}
        )
        spent_seconds = round(sum(spent_details.values()), 3)

        if mono_text == "" and left_text == "" and right_text == "":
            mono_text = self._extract_audio_text(audio)

        return InferenceData(
            serviceId=self.service_id,
            spentSeconds=spent_seconds,
            spentDetails=spent_details,
            text=TextResult(mono=mono_text, left=left_text, right=right_text),
            sentences=sentences,
            is_bad=False,
            bad_reason=None,
            bad_componet=None,
        )

    def _batch_performance(
        self,
        num_items: int,
        batch_wall_seconds: float,
        total_audio_duration_seconds: float,
    ) -> InferencePerformance:
        wall = max(float(batch_wall_seconds), 1e-9)
        audio_s = max(float(total_audio_duration_seconds), 0.0)
        tps = round(num_items / wall, 4)
        audio_speed = round(audio_s / wall, 4)
        rtf = round(wall / audio_s, 4) if audio_s > 0 else 0.0
        return InferencePerformance(
            batch_wall_seconds=round(float(batch_wall_seconds), 4),
            num_items=num_items,
            throughput_items_per_second=tps,
            total_audio_duration_seconds=round(audio_s, 4),
            speedup=audio_speed,
            rtf=rtf,
        )


@registry.service_routers.register("transcribe.v1")
def transcribe_entrypoint(
    service_id: str = "",
    loader: AudioLoader | None = None,
    detector: VoiceDetector | None = None,
    recognizer: SpeechRecognizer | None = None,
    sentencizer: SpeechSentencizer | None = None,
    model_map: Dict[str, str] | None = None,
) -> TranscribeRouter:
    """Create a transcribe router with concrete default components."""
    return TranscribeRouter(
        service_id=service_id,
        loader=loader or AudioLoader(),
        detector=detector or VoiceDetector(),
        recognizer=recognizer or SpeechRecognizer(),
        sentencizer=sentencizer,
        model_map=model_map or {},
    )
