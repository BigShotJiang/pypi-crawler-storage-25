from __future__ import annotations

from typing import List

from pydantic import BaseModel, Field


class AudioInput(BaseModel):
    """Single audio input item."""

    url: str | None = Field(None, description="Audio URL")
    b64_str: str | None = Field(None, description="Base64 encoded audio payload")
    mono: bool | None = Field(None, description="Whether to convert to mono")
    hotword: str | None = Field(None, description="Space-separated hotwords")


class InferenceRequest(BaseModel):
    """Batch transcription request."""

    inputs: List[AudioInput] = Field(..., description="Audio input list")


class TextResult(BaseModel):
    """Aggregated text result by channel."""

    mono: str = Field("", description="Mono text")
    left: str = Field("", description="Left channel text")
    right: str = Field("", description="Right channel text")


class SentenceResult(BaseModel):
    """Sentence with timing metadata."""

    text: str = Field("", description="Sentence text")
    startTime: int = Field(0, description="Start time in milliseconds")
    endTime: int = Field(0, description="End time in milliseconds")
    duration: int = Field(0, description="Duration in milliseconds")
    channel: str = Field("", description="Channel name")
    sentenceIndex: int = Field(0, description="Sentence index")


class InferenceData(BaseModel):
    """Business result for one input item."""

    serviceId: str = Field(..., description="Service instance identifier")
    spentSeconds: float = Field(0, description="Elapsed seconds")
    spentDetails: dict[str, float] = Field(
        default_factory=dict, description="Elapsed time per component"
    )
    text: TextResult = Field(default_factory=TextResult, description="Channel text")
    sentences: List[SentenceResult] = Field(
        default_factory=list, description="Sentence results"
    )
    is_bad: bool = Field(False, description="Whether the item failed")
    bad_reason: str | None = Field(None, description="Failure reason")
    bad_componet: str | None = Field(None, description="Failed component")


class InferencePerformance(BaseModel):
    """Batch wall-clock performance metrics."""

    batch_wall_seconds: float = Field(..., description="Batch wall time in seconds")
    num_items: int = Field(..., description="Number of request items")
    throughput_items_per_second: float = Field(
        ..., description="Throughput in items per second"
    )
    total_audio_duration_seconds: float = Field(
        0, description="Total duration for successful items in seconds"
    )
    speedup: float = Field(0, description="Audio seconds processed per wall second")
    rtf: float = Field(0, description="Realtime factor")


class InferenceResponse(BaseModel):
    """API response for batch transcription."""

    data: List[InferenceData] = Field(..., description="Per-item inference results")
    inference_performance: InferencePerformance = Field(
        ..., description="Batch performance statistics"
    )
