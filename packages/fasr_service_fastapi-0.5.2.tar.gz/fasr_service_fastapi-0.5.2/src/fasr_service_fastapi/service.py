from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
import inspect
from pathlib import Path
import sys
from typing import Dict
from uuid import uuid1

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from loguru import logger
from pydantic import ConfigDict, PrivateAttr
import uvicorn
import uvicorn.server

try:
    import uvicorn._compat as uvicorn_compat
except ModuleNotFoundError:
    uvicorn_compat = None

from fasr.config import Config, registry
from fasr.model import Model
from fasr.service import ASRService
from fasr_service_fastapi.asr_scheduler import ASRInferenceScheduler
from fasr_service_fastapi.routers.realtime import RealtimeRouter
from fasr_service_fastapi.routers.transcribe import TranscribeRouter


def configure_service_logging(debug_logging: bool) -> None:
    logger.remove()
    logger.add(
        sys.stderr,
        level="DEBUG" if debug_logging else "INFO",
    )


@registry.services.register("fastapi.v1")
class FastAPIASRService(ASRService):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    host: str = "0.0.0.0"
    port: int = 8000
    service_id: str = ""
    debug_logging: bool = False
    models: Dict[str, Model]
    transcribe_router: TranscribeRouter | None = None
    realtime_router: RealtimeRouter | None = None
    demo_index_path: Path = Path(__file__).parent / "static" / "demo" / "index.html"
    demo_static_dir: Path = Path(__file__).parent / "static" / "demo"
    _asr_scheduler: ASRInferenceScheduler | None = PrivateAttr(default=None)

    def _build_app(self) -> FastAPI:
        @asynccontextmanager
        async def lifespan(_: FastAPI) -> AsyncIterator[None]:
            try:
                yield
            finally:
                pass

        app = FastAPI(title="FASR Service", lifespan=lifespan)
        app.mount(
            "/demo-assets",
            StaticFiles(directory=self.demo_static_dir),
            name="demo-assets",
        )
        if self.transcribe_router is not None:
            app.include_router(self.transcribe_router.create_router())
        if self.realtime_router is not None:
            app.include_router(self.realtime_router.create_router())

        @app.get("/", include_in_schema=False)
        @app.get("/demo", include_in_schema=False)
        async def demo_home() -> FileResponse:
            return FileResponse(self.demo_index_path)

        @app.get("/health")
        async def health() -> dict[str, object]:
            transcribe_components_loaded = self._transcribe_components_loaded()
            transcribe_models_loaded = self._transcribe_models_loaded()
            realtime_loaded = self._realtime_loaded()
            has_router = (
                self.transcribe_router is not None or self.realtime_router is not None
            )
            health_ready = (
                has_router
                and (
                    self.transcribe_router is None
                    or (transcribe_components_loaded and transcribe_models_loaded)
                )
                and (self.realtime_router is None or realtime_loaded)
            )
            return {
                "status": "healthy" if health_ready else "unhealthy",
                "transcribe_enabled": self.transcribe_router is not None,
                "transcribe_components_loaded": transcribe_components_loaded,
                "transcribe_models_loaded": transcribe_models_loaded,
                "realtime_enabled": self.realtime_router is not None,
                "realtime_loaded": realtime_loaded,
            }

        return app

    def _transcribe_components_loaded(self) -> bool:
        if self.transcribe_router is None:
            return False
        return (
            self.transcribe_router.loader is not None
            and self.transcribe_router.detector is not None
            and self.transcribe_router.recognizer is not None
        )

    def _transcribe_models_loaded(self) -> bool:
        if self.transcribe_router is None:
            return False
        return (
            self.transcribe_router.detector is not None
            and self.transcribe_router.detector.model is not None
            and self.transcribe_router.recognizer is not None
            and self.transcribe_router.recognizer.model is not None
        )

    def _realtime_loaded(self) -> bool:
        if self.realtime_router is None or self.realtime_router.handler is None:
            return False
        return (
            self.realtime_router.handler.vad_model is not None
            and self.realtime_router.handler.asr_model is not None
        )

    def setup(self) -> None:
        if self.transcribe_router is None and self.realtime_router is None:
            raise ValueError(
                "FastAPI ASR service requires at least one router. "
                "Configure [service.transcribe_router] or [service.realtime_router]."
            )
        configure_service_logging(self.debug_logging)
        if not self.service_id:
            self.service_id = str(uuid1())
        self._asr_scheduler = ASRInferenceScheduler(service_id=self.service_id)
        self._asr_scheduler.start()
        if self.transcribe_router is not None:
            self.transcribe_router.setup(
                service_id=self.service_id,
                models=self.models,
                asr_scheduler=self._asr_scheduler,
            )
        if self.realtime_router is not None:
            self.realtime_router.setup(
                service_id=self.service_id,
                models=self.models,
                asr_scheduler=self._asr_scheduler,
            )
        app = self._build_app()
        transcribe_components_loaded = self._transcribe_components_loaded()
        transcribe_models_loaded = self._transcribe_models_loaded()
        realtime_loaded = self._realtime_loaded()
        logger.info(
            "Starting ASR service: host={}, port={}, service_id={}, transcribe_enabled={}, transcribe_components_loaded={}, transcribe_models_loaded={}, realtime_enabled={}, realtime_loaded={}",
            self.host,
            self.port,
            self.service_id,
            self.transcribe_router is not None,
            transcribe_components_loaded,
            transcribe_models_loaded,
            self.realtime_router is not None,
            realtime_loaded,
        )

        if "loop_factory" not in inspect.signature(asyncio.run).parameters:
            patched_asyncio_run = asyncio.run

            def compat_asyncio_run(main, *, debug=None, loop_factory=None):
                return patched_asyncio_run(main, debug=debug)

            asyncio.run = compat_asyncio_run
            if uvicorn_compat is not None:
                uvicorn_compat.asyncio_run = compat_asyncio_run
            uvicorn.server.asyncio_run = compat_asyncio_run

        uvicorn.run(
            app,
            host=self.host,
            port=self.port,
            log_level="debug" if self.debug_logging else "info",
        )

    def get_default_config(self) -> Config:
        return Config().from_str(DEFAULT_CONFIG)


DEFAULT_CONFIG = """
[path]
cache_dir = null

[service]
@services = "fastapi.v1"
debug_logging = false

[service.models]

[service.models.qwen3_asr]
@asr_models = "qwen3asr"
size = "small"

[service.models.fsmn_online]
@vad_models = "fsmn_online"

[service.models.marblenet]
@vad_models = "marblenet"

[service.transcribe_router]
@service_routers = "transcribe.v1"

[service.transcribe_router.model_map]
vad_model = "marblenet"
asr_model = "qwen3_asr"

[service.realtime_router]
@service_routers = "realtime.v1"

[service.realtime_router.model_map]
vad_model = "fsmn_online"
asr_model = "qwen3_asr"
"""
