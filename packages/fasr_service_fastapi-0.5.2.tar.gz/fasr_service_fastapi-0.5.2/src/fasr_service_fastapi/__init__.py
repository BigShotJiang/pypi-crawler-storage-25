from __future__ import annotations

from fastapi import FastAPI

from fasr.model import ASRModel, VADModel
from fasr_service_fastapi.routers.realtime import (
    RealtimeRouter,
    RealtimeWebSocketHandler,
)

from .service import FastAPIASRService, configure_service_logging


def create_realtime_app(
    *,
    vad_model: VADModel,
    asr_model: ASRModel,
    sample_rate: int = 16000,
    vad_chunk_size_ms: int = 100,
    vad_model_name: str = "fsmn_online",
    asr_model_name: str = "stream_qwen3_0_6b",
    debug_logging: bool = False,
) -> FastAPI:
    configure_service_logging(debug_logging)
    handler = RealtimeWebSocketHandler(
        sample_rate=sample_rate,
        chunk_size_ms=vad_chunk_size_ms,
        model_name=asr_model_name,
    )
    router = RealtimeRouter(
        handler=handler,
        model_map={
            "vad_model": "vad_model",
            "asr_model": "asr_model",
        },
    )
    router.setup(
        service_id="realtime_test",
        models={
            "vad_model": vad_model,
            "asr_model": asr_model,
        },
    )

    app = FastAPI(title="fasr realtime asr service")
    app.include_router(router.create_router())

    @app.get("/health")
    async def health() -> dict[str, object]:
        return {
            "status": "ok",
            "vad_model": vad_model_name,
            "asr_model": asr_model_name,
            "models_loaded": handler.vad_model is not None
            and handler.asr_model is not None,
        }

    return app


__all__ = ["FastAPIASRService", "create_realtime_app"]
