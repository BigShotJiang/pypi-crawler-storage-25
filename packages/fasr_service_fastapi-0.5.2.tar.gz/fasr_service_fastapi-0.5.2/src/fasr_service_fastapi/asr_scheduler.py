from __future__ import annotations

from concurrent.futures import Future
from dataclasses import dataclass
from itertools import count
import os
from queue import PriorityQueue
import threading
from typing import Callable, List, TypeVar

from loguru import logger
from pydantic import Field

from fasr.config import Config
from fasr.data.audio import AudioChunk, AudioSpan
from fasr.model import ASRModel

T = TypeVar("T")

ASR_PRIORITY_REALTIME = 0
ASR_PRIORITY_TRANSCRIBE = 10


@dataclass
class ASRInferenceTask:
    fn: Callable[[], object]
    future: Future[object]
    label: str


class ASRInferenceScheduler:
    """Single-worker scheduler for shared ASR model inference calls."""

    def __init__(self, service_id: str = "") -> None:
        self.service_id = service_id
        self._tasks: PriorityQueue[tuple[int, int, ASRInferenceTask]] = PriorityQueue()
        self._task_sequence = count()
        self._worker: threading.Thread | None = None

    def start(self) -> None:
        if self._worker is not None and self._worker.is_alive():
            return
        self._worker = threading.Thread(
            target=self._worker_loop,
            name="asr-inference-worker",
            daemon=True,
        )
        self._worker.start()
        logger.info(
            "ASR inference scheduler started: service_id={}, pid={}, thread={}",
            self.service_id,
            os.getpid(),
            self._worker.name,
        )

    def submit_sync(
        self,
        label: str,
        fn: Callable[[], T],
        priority: int = ASR_PRIORITY_TRANSCRIBE,
    ) -> T:
        self.start()
        future: Future[object] = Future()
        self._tasks.put(
            (
                priority,
                next(self._task_sequence),
                ASRInferenceTask(fn=fn, future=future, label=label),
            )
        )
        logger.debug(
            "ASR inference task queued: service_id={}, pid={}, label={}, priority={}, queue_size={}",
            self.service_id,
            os.getpid(),
            label,
            priority,
            self._tasks.qsize(),
        )
        return future.result()  # type: ignore[return-value]

    def _worker_loop(self) -> None:
        while True:
            priority, _, task = self._tasks.get()
            logger.debug(
                "ASR inference task started: service_id={}, pid={}, thread={}, label={}, priority={}, queue_size={}",
                self.service_id,
                os.getpid(),
                threading.current_thread().name,
                task.label,
                priority,
                self._tasks.qsize(),
            )
            try:
                result = task.fn()
            except Exception as exc:
                task.future.set_exception(exc)
            else:
                task.future.set_result(result)
            finally:
                logger.debug(
                    "ASR inference task finished: service_id={}, pid={}, thread={}, label={}",
                    self.service_id,
                    os.getpid(),
                    threading.current_thread().name,
                    task.label,
                )
                self._tasks.task_done()


class ScheduledASRModel(ASRModel):
    """ASR model wrapper that serializes calls to a shared model instance."""

    model: ASRModel = Field(..., exclude=True)
    scheduler: ASRInferenceScheduler = Field(..., exclude=True)

    def load_checkpoint(self, checkpoint_dir: str | None):
        return None

    def get_config(self) -> Config:
        return self.model.get_config()

    def transcribe(
        self,
        batch: List[AudioSpan],
        **kwargs,
    ) -> List[AudioSpan]:
        return self.scheduler.submit_sync(
            f"{type(self.model).__name__}.transcribe",
            lambda: self.model.transcribe(batch, **kwargs),
            priority=ASR_PRIORITY_TRANSCRIBE,
        )

    def push_chunk(self, chunk: AudioChunk) -> AudioSpan | None:
        return self.scheduler.submit_sync(
            f"{type(self.model).__name__}.push_chunk",
            lambda: self.model.push_chunk(chunk),
            priority=ASR_PRIORITY_REALTIME,
        )

    def reset(self):
        return self.model.reset()

    def remove_state(self, key: str):
        return self.model.remove_state(key)

    def get_state(self, key: str):
        return self.model.get_state(key)
