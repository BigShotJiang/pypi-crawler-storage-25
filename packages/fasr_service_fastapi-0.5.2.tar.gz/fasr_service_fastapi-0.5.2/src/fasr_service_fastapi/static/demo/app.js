let ws = null;
let currentMode = "vad";
let shouldAutoReconnect = false;
let reconnectAttempts = 0;
let reconnectTimer = null;
const maxReconnectAttempts = 5;

let vadAudioContext = null;
let vadMediaStream = null;
let vadAudioNode = null;
let vadSilentGainNode = null;
let vadIsRecording = false;
let vadAnalyzer = null;
let vadAnalyzerData = null;
let visualizerAnimationFrameId = null;

let manualAudioData = null;
let completedSegments = [];
let currentSegmentText = "";
let currentStashText = "";
let speechStoppedAtByItemId = {};
let latencySamplesMs = [];

const debugEvents = [];
let debugPanelVisible = true;
const DEBUG_EVENT_MAX = 50;

function inferDefaultWebSocketUrl() {
    const wsProtocol = window.location.protocol === "https:" ? "wss" : "ws";
    return `${wsProtocol}://${window.location.host}/api-ws/v1/realtime`;
}

function inferDefaultTranscribeUrl() {
    return `${window.location.origin}/transcribe`;
}

function setDefaultWebSocketUrlIfNeeded() {
    const input = document.getElementById("wsUrl");
    if (!input.value.trim()) {
        input.value = inferDefaultWebSocketUrl();
    }
}

function setAppMessage(level, message) {
    const box = document.getElementById("appError");
    if (!message) {
        box.style.display = "none";
        box.textContent = "";
        box.className = "info-box app-error";
        return;
    }
    box.style.display = "block";
    box.textContent = message;
    box.className = `info-box app-error level-${level}`;
}

function pushServerDebugEvent(payload) {
    const eventType = payload?.type || "unknown";
    if (eventType === "input_audio_buffer.append") {
        return;
    }
    const entry = {
        ts: new Date().toLocaleTimeString(),
        eventType,
        eventId: payload?.event_id || "-",
        itemId: payload?.item_id || "-",
    };
    debugEvents.unshift(entry);
    if (debugEvents.length > DEBUG_EVENT_MAX) {
        debugEvents.length = DEBUG_EVENT_MAX;
    }
    renderDebugEvents();
}

function renderDebugEvents() {
    const container = document.getElementById("debugEvents");
    const lines = debugEvents.map(
        (item) =>
            `${item.ts} ${item.eventType} event_id=${item.eventId} item_id=${item.itemId}`
    );
    container.textContent = lines.join("\n");
}

function clearDebugEvents() {
    debugEvents.length = 0;
    renderDebugEvents();
}

function toggleDebugPanel() {
    debugPanelVisible = !debugPanelVisible;
    document.getElementById("debugPanelContent").style.display = debugPanelVisible
        ? "block"
        : "none";
}

function resetResults() {
    completedSegments = [];
    currentSegmentText = "";
    currentStashText = "";
    speechStoppedAtByItemId = {};
    latencySamplesMs = [];
    updateLatencyStats();
    updateResultsDisplay();
}

function updateResultsDisplay() {
    const completedText = completedSegments.join("");
    const fullText = `${completedText}${currentSegmentText}${currentStashText}`;
    const resultElement = document.getElementById("fullResult");
    resultElement.textContent = "";
    if (!fullText) {
        const empty = document.createElement("span");
        empty.style.color = "#999";
        empty.textContent = "等待识别...";
        resultElement.appendChild(empty);
    } else {
        const stable = document.createElement("span");
        stable.textContent = `${completedText}${currentSegmentText}`;
        resultElement.appendChild(stable);
        if (currentStashText) {
            const stash = document.createElement("span");
            stash.className = "stash-text";
            stash.textContent = currentStashText;
            resultElement.appendChild(stash);
        }
    }
    const totalChars = fullText.length;
    document.getElementById("vadCharCount").textContent = totalChars;
}

function updateLatencyStats(lastLatencyMs = null) {
    const lastEl = document.getElementById("latencyLastMs");
    const avgEl = document.getElementById("latencyAvgMs");
    const countEl = document.getElementById("latencyCount");
    if (lastLatencyMs == null) {
        lastEl.textContent = latencySamplesMs.length > 0
            ? latencySamplesMs[latencySamplesMs.length - 1].toFixed(2)
            : "-";
    } else {
        lastEl.textContent = lastLatencyMs.toFixed(2);
    }
    countEl.textContent = String(latencySamplesMs.length);
    if (latencySamplesMs.length === 0) {
        avgEl.textContent = "-";
        return;
    }
    const sum = latencySamplesMs.reduce((acc, x) => acc + x, 0);
    avgEl.textContent = (sum / latencySamplesMs.length).toFixed(2);
}

function switchMode(mode) {
    currentMode = mode;
    document.querySelectorAll(".tab").forEach((tab) => tab.classList.remove("active"));
    document.getElementById(`tab-${mode}`).classList.add("active");
    document
        .querySelectorAll(".mode-content")
        .forEach((content) => content.classList.remove("active"));
    document.getElementById(`${mode}-mode`).classList.add("active");
    document.getElementById("wsConfigRow").style.display =
        mode === "vad" ? "flex" : "none";
    setAppMessage("", "");
}

function updateVadStatus(state) {
    const dot = document.getElementById("vadStatusDot");
    const text = document.getElementById("vadStatusText");
    dot.className = "status-dot";
    if (state === "connecting") {
        text.textContent = "连接中...";
    } else if (state === "connected") {
        dot.classList.add("connected");
        text.textContent = "已连接";
    } else if (state === "recording") {
        dot.classList.add("recording");
        text.textContent = "录音中...";
    } else if (state === "reconnecting") {
        text.textContent = "重连中...";
    } else if (state === "error") {
        text.textContent = "连接异常";
    } else {
        text.textContent = "未连接";
    }
}

function sendEvent(payload) {
    if (!ws || ws.readyState !== WebSocket.OPEN) {
        return false;
    }
    ws.send(JSON.stringify(payload));
    return true;
}

function closeSocket() {
    if (reconnectTimer) {
        clearTimeout(reconnectTimer);
        reconnectTimer = null;
    }
    if (ws) {
        ws.close();
        ws = null;
    }
}

function scheduleReconnect() {
    if (!shouldAutoReconnect || reconnectAttempts >= maxReconnectAttempts) {
        setAppMessage("warning", "连接已断开，请手动重试。");
        return;
    }
    reconnectAttempts += 1;
    const delayMs = Math.min(1000 * 2 ** (reconnectAttempts - 1), 8000);
    updateVadStatus("reconnecting");
    reconnectTimer = setTimeout(async () => {
        try {
            await connectWebSocket(true);
            setAppMessage("", "");
        } catch (error) {
            setAppMessage("error", `重连失败: ${error.message}`);
            scheduleReconnect();
        }
    }, delayMs);
}

function getWebSocketConfig() {
    const wsUrl = document.getElementById("wsUrl").value.trim();
    if (!wsUrl.startsWith("ws://") && !wsUrl.startsWith("wss://")) {
        throw new Error("WebSocket URL 必须以 ws:// 或 wss:// 开头");
    }
    return { url: wsUrl };
}

function connectWebSocket(isReconnect = false) {
    return new Promise((resolve, reject) => {
        const wsConfig = getWebSocketConfig();
        closeSocket();
        shouldAutoReconnect = true;
        if (!isReconnect) {
            reconnectAttempts = 0;
        }
        updateVadStatus("connecting");
        ws = new WebSocket(wsConfig.url);
        let settled = false;

        ws.onopen = () => {
            updateVadStatus("connected");
            if (!settled) {
                settled = true;
                resolve();
            }
        };

        ws.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                pushServerDebugEvent(data);
                handleRealtimeMessage(data);
            } catch (_) {
                setAppMessage("warning", "收到非 JSON 消息，已忽略。");
            }
        };

        ws.onerror = () => {
            updateVadStatus("error");
            if (!settled) {
                settled = true;
                reject(new Error("WebSocket 连接失败"));
            }
        };

        ws.onclose = () => {
            ws = null;
            if (!settled) {
                settled = true;
                reject(new Error("WebSocket 已关闭"));
            }
            if (shouldAutoReconnect && vadIsRecording) {
                scheduleReconnect();
            } else {
                updateVadStatus("idle");
            }
        };
    });
}

function handleRealtimeMessage(data) {
    switch (data.type) {
        case "session.created":
            sendSessionUpdate();
            break;
        case "input_audio_buffer.speech_stopped": {
            const itemId = data.item_id;
            if (itemId) {
                speechStoppedAtByItemId[itemId] = performance.now();
            }
            break;
        }
        case "conversation.item.input_audio_transcription.text":
            if (data.text !== undefined) {
                currentSegmentText = data.text;
            }
            currentStashText = data.stash || "";
            updateResultsDisplay();
            break;
        case "conversation.item.input_audio_transcription.completed": {
            const itemId = data.item_id;
            if (itemId && speechStoppedAtByItemId[itemId] !== undefined) {
                const latencyMs = Math.max(
                    performance.now() - speechStoppedAtByItemId[itemId],
                    0
                );
                latencySamplesMs.push(latencyMs);
                delete speechStoppedAtByItemId[itemId];
                updateLatencyStats(latencyMs);
            }
            if (data.transcript) {
                completedSegments.push(data.transcript);
            } else if (data.text) {
                completedSegments.push(data.text);
            }
            currentSegmentText = "";
            currentStashText = "";
            updateResultsDisplay();
            break;
        }
        case "error":
            setAppMessage("error", data.error?.message || "服务端返回错误");
            break;
        default:
            break;
    }
}

function sendSessionUpdate() {
    const language = document.getElementById("language").value;
    const payload = {
        event_id: `event_update_${Date.now()}`,
        type: "session.update",
        session: {
            input_audio_format: "pcm",
            sample_rate: 16000,
            input_audio_transcription: {},
            turn_detection: { type: "server_vad" },
        },
    };
    if (language && language !== "auto") {
        payload.session.input_audio_transcription.language = language;
    }
    sendEvent(payload);
}

function onAudioSourceChange() {
    const source = document.getElementById("audioSource").value;
    document.getElementById("deviceSelectWrapper").style.display =
        source === "screen" ? "none" : "block";
    document.getElementById("screenShareInfo").style.display =
        source === "screen" ? "block" : "none";
}

async function getScreenShareAudioStream() {
    const stream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: true,
    });
    const audioTracks = stream.getAudioTracks();
    if (audioTracks.length === 0) {
        stream.getVideoTracks().forEach((t) => t.stop());
        throw new Error("未获取到系统音频，请勾选“共享系统音频”。");
    }
    stream.getVideoTracks().forEach((t) => t.stop());
    return new MediaStream(audioTracks);
}

function initVisualizer() {
    const container = document.getElementById("vadVisualizer");
    container.textContent = "";
    for (let i = 0; i < 60; i += 1) {
        const bar = document.createElement("div");
        bar.className = "audio-bar";
        bar.style.height = "4px";
        container.appendChild(bar);
    }
}

function updateVisualizer() {
    if (!vadAnalyzer || !vadAnalyzerData) {
        return;
    }
    vadAnalyzer.getByteFrequencyData(vadAnalyzerData);
    const bars = document.querySelectorAll("#vadVisualizer .audio-bar");
    const step = Math.max(Math.floor(vadAnalyzerData.length / bars.length), 1);
    bars.forEach((bar, i) => {
        const value = vadAnalyzerData[i * step] / 128;
        const height = Math.max(4, value * 70);
        bar.style.height = `${height}px`;
    });
}

function startVisualizerLoop() {
    stopVisualizerLoop();
    const loop = () => {
        if (!vadIsRecording) {
            return;
        }
        updateVisualizer();
        visualizerAnimationFrameId = requestAnimationFrame(loop);
    };
    visualizerAnimationFrameId = requestAnimationFrame(loop);
}

function stopVisualizerLoop() {
    if (visualizerAnimationFrameId !== null) {
        cancelAnimationFrame(visualizerAnimationFrameId);
        visualizerAnimationFrameId = null;
    }
}

function pcmToBase64(float32Array) {
    const pcm16 = new Int16Array(float32Array.length);
    for (let i = 0; i < float32Array.length; i += 1) {
        pcm16[i] = Math.max(-32768, Math.min(32767, float32Array[i] * 32768));
    }
    const bytes = new Uint8Array(pcm16.buffer);
    let binary = "";
    for (let i = 0; i < bytes.byteLength; i += 1) {
        binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
}

function bytesToBase64(bytes) {
    let binary = "";
    const chunkSize = 0x8000;
    for (let i = 0; i < bytes.length; i += chunkSize) {
        const chunk = bytes.subarray(i, i + chunkSize);
        binary += String.fromCharCode(...chunk);
    }
    return btoa(binary);
}

async function buildVadAudioNode(sourceNode) {
    if (vadAudioContext.audioWorklet && window.AudioWorkletNode) {
        const workletCode = `
            class PCMProcessor extends AudioWorkletProcessor {
                process(inputs) {
                    const input = inputs[0];
                    if (input && input[0]) {
                        this.port.postMessage(input[0].slice(0));
                    }
                    return true;
                }
            }
            registerProcessor('pcm-processor', PCMProcessor);
        `;
        const blob = new Blob([workletCode], { type: "application/javascript" });
        const workletUrl = URL.createObjectURL(blob);
        await vadAudioContext.audioWorklet.addModule(workletUrl);
        URL.revokeObjectURL(workletUrl);
        const node = new AudioWorkletNode(vadAudioContext, "pcm-processor");
        vadSilentGainNode = vadAudioContext.createGain();
        vadSilentGainNode.gain.value = 0;
        node.port.onmessage = (event) => {
            if (!vadIsRecording) {
                return;
            }
            sendEvent({
                event_id: `audio_${Date.now()}`,
                type: "input_audio_buffer.append",
                audio: pcmToBase64(event.data),
            });
        };
        sourceNode.connect(node);
        node.connect(vadSilentGainNode);
        vadSilentGainNode.connect(vadAudioContext.destination);
        return node;
    }
    const fallbackNode = vadAudioContext.createScriptProcessor(4096, 1, 1);
    fallbackNode.onaudioprocess = (event) => {
        if (!vadIsRecording) {
            return;
        }
        const input = event.inputBuffer.getChannelData(0);
        sendEvent({
            event_id: `audio_${Date.now()}`,
            type: "input_audio_buffer.append",
            audio: pcmToBase64(input),
        });
    };
    sourceNode.connect(fallbackNode);
    fallbackNode.connect(vadAudioContext.destination);
    return fallbackNode;
}

async function vadStart() {
    try {
        resetResults();
        await connectWebSocket();
        const sourceType = document.getElementById("audioSource").value;
        if (sourceType === "screen") {
            vadMediaStream = await getScreenShareAudioStream();
        } else {
            const selectedDeviceId = document.getElementById("audioDevice").value;
            const audioConstraints = { channelCount: 1, sampleRate: 16000 };
            if (selectedDeviceId) {
                audioConstraints.deviceId = { exact: selectedDeviceId };
            }
            vadMediaStream = await navigator.mediaDevices.getUserMedia({
                audio: audioConstraints,
            });
        }
        vadAudioContext = new (window.AudioContext || window.webkitAudioContext)({
            sampleRate: 16000,
        });
        const sourceNode = vadAudioContext.createMediaStreamSource(vadMediaStream);
        vadAnalyzer = vadAudioContext.createAnalyser();
        vadAnalyzer.fftSize = 256;
        vadAnalyzerData = new Uint8Array(vadAnalyzer.frequencyBinCount);
        sourceNode.connect(vadAnalyzer);
        vadAudioNode = await buildVadAudioNode(sourceNode);
        vadIsRecording = true;
        startVisualizerLoop();
        updateVadStatus("recording");
        document.getElementById("vadStartBtn").disabled = true;
        document.getElementById("vadStopBtn").disabled = false;
        setAppMessage("", "");
    } catch (error) {
        setAppMessage("error", `启动失败: ${error.message}`);
        updateVadStatus("error");
    }
}

async function vadStop() {
    shouldAutoReconnect = false;
    vadIsRecording = false;
    if (vadAudioNode) {
        vadAudioNode.disconnect();
        vadAudioNode = null;
    }
    if (vadSilentGainNode) {
        vadSilentGainNode.disconnect();
        vadSilentGainNode = null;
    }
    stopVisualizerLoop();
    if (vadAudioContext) {
        await vadAudioContext.close();
        vadAudioContext = null;
    }
    if (vadMediaStream) {
        vadMediaStream.getTracks().forEach((track) => track.stop());
        vadMediaStream = null;
    }
    sendEvent({ event_id: `event_finish_${Date.now()}`, type: "session.finish" });
    closeSocket();
    updateVadStatus("idle");
    document.getElementById("vadStartBtn").disabled = false;
    document.getElementById("vadStopBtn").disabled = true;
    document.getElementById("vadVisualizer").innerHTML =
        '<span style="color: #999;">音频可视化</span>';
}

function setFileLabelSelected(name, size, type) {
    const label = document.getElementById("fileLabel");
    label.classList.add("has-file");
    label.textContent = "";
    const top = document.createElement("div");
    top.textContent = `已选择: ${name}`;
    const info = document.createElement("div");
    info.style.fontSize = "12px";
    info.style.color = "#666";
    info.style.marginTop = "5px";
    info.textContent = `大小: ${(size / 1024).toFixed(1)} KB | 类型: ${type || "-"}`;
    label.appendChild(top);
    label.appendChild(info);
}

function resetFileLabel() {
    const label = document.getElementById("fileLabel");
    label.classList.remove("has-file");
    label.textContent = "";
    const top = document.createElement("div");
    top.textContent = "点击选择文件";
    const info = document.createElement("div");
    info.style.fontSize = "12px";
    info.style.color = "#999";
    info.style.marginTop = "5px";
    info.textContent = "支持常见音频格式";
    label.appendChild(top);
    label.appendChild(info);
}

function loadAudio(url, name) {
    const player = document.getElementById("audioPlayer");
    player.src = url;
    document.getElementById("audioPreview").style.display = "block";
    document.getElementById("audioInfo").textContent = `来源: ${name}`;
    fetch(url)
        .then((response) => response.arrayBuffer())
        .then((buffer) => {
            manualAudioData = buffer;
            setAppMessage("", "");
        })
        .catch((error) => {
            setAppMessage("warning", `音频加载失败: ${error.message}`);
        });
}

function handleFileSelect(event) {
    const file = event.target.files[0];
    if (!file) {
        return;
    }
    setFileLabelSelected(file.name, file.size, file.type);
    const url = URL.createObjectURL(file);
    loadAudio(url, file.name);
}

function extractTextFromTranscribeResponse(resp) {
    const first = resp?.data?.[0];
    if (!first) {
        return "";
    }
    if (first.text?.mono) {
        return first.text.mono;
    }
    if (Array.isArray(first.sentences) && first.sentences.length > 0) {
        return first.sentences.map((s) => s.text || "").join("");
    }
    return "";
}

function updateOfflineMetrics(resp) {
    const speedupEl = document.getElementById("offlineSpeedup");
    const rtfEl = document.getElementById("offlineRtf");
    const perf = resp?.inference_performance;
    if (!perf) {
        speedupEl.textContent = "-";
        rtfEl.textContent = "-";
        return;
    }
    const speedup = Number(perf.speedup);
    const rtf = Number(perf.rtf);
    speedupEl.textContent = Number.isFinite(speedup) ? speedup.toFixed(4) : "-";
    rtfEl.textContent = Number.isFinite(rtf) ? rtf.toFixed(4) : "-";
}

async function manualStart() {
    if (!manualAudioData) {
        setAppMessage("warning", "请先上传音频文件");
        return;
    }
    const startBtn = document.getElementById("manualStartBtn");
    startBtn.disabled = true;
    setAppMessage("", "");
    try {
        const b64 = bytesToBase64(new Uint8Array(manualAudioData));
        const payload = {
            inputs: [{ b64_str: b64, mono: true }],
        };
        const resp = await fetch(inferDefaultTranscribeUrl(), {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
        });
        if (!resp.ok) {
            throw new Error(`/transcribe 请求失败: HTTP ${resp.status}`);
        }
        const data = await resp.json();
        const text = extractTextFromTranscribeResponse(data);
        updateOfflineMetrics(data);
        currentSegmentText = "";
        currentStashText = "";
        completedSegments = [text || ""];
        updateResultsDisplay();
        setAppMessage("warning", text ? "文件转录完成" : "文件转录完成，但未返回文本");
    } catch (error) {
        setAppMessage("error", `文件转录失败: ${error.message}`);
    } finally {
        startBtn.disabled = false;
    }
}

async function loadAudioDevices() {
    const select = document.getElementById("audioDevice");
    select.innerHTML = '<option value="">加载中...</option>';
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach((track) => track.stop());
        const devices = await navigator.mediaDevices.enumerateDevices();
        const audioInputs = devices.filter((d) => d.kind === "audioinput");
        select.innerHTML = "";
        if (audioInputs.length === 0) {
            select.innerHTML = '<option value="">未检测到音频设备</option>';
            return;
        }
        audioInputs.forEach((device, index) => {
            const option = document.createElement("option");
            option.value = device.deviceId;
            option.textContent = device.label || `麦克风 ${index + 1}`;
            if (device.deviceId === "default" || index === 0) {
                option.selected = true;
            }
            select.appendChild(option);
        });
    } catch (error) {
        select.innerHTML = '<option value="">获取设备失败 - 请允许麦克风权限</option>';
        setAppMessage("warning", `无法获取设备列表: ${error.message}`);
    }
}

window.switchMode = switchMode;
window.onAudioSourceChange = onAudioSourceChange;
window.vadStart = vadStart;
window.vadStop = vadStop;
window.handleFileSelect = handleFileSelect;
window.manualStart = manualStart;
window.toggleDebugPanel = toggleDebugPanel;
window.clearDebugEvents = clearDebugEvents;

initVisualizer();
setDefaultWebSocketUrlIfNeeded();
resetFileLabel();
switchMode("vad");
loadAudioDevices();
navigator.mediaDevices.addEventListener("devicechange", loadAudioDevices);
