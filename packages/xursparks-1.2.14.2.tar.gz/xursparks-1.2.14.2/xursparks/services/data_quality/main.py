"""
Data Quality Validation Service

This module provides the central logic for executing data quality checks on Spark DataFrames.
It utilizes a rule-based engine to flag rows that violate specific constraints defined in 
external metadata/configuration.
"""
import datetime
from typing import Any, Dict

from pyspark.sql import DataFrame, SparkSession, functions as F
from pyspark.sql.window import Window

from xursparks.tools.logger import Logger
import logging

logging.getLogger("py4j").setLevel(logging.WARNING)

class XursparksDataQuality:
    """
    A class to perform data quality checks on a Spark DataFrame based on a set of rules.

    Process Flow:
    1. Initializes with a Spark DataFrame and a set of JSON-defined rules.
    2. Adds a surrogate `_row_id` for consistent row tracking.
    3. Registers the DataFrame as a temporary view to allow subquery-based rules.
    4. Evaluates each rule using either native Spark functions or Spark SQL.
    5. Aggregates results into a comprehensive validation report.
    """

    def __init__(self, df: DataFrame, dq_rules: Dict[str, Any], process_date=None):
        """
        Initializes the SparkDataQuality class.

        Args:
            df (DataFrame): The Spark DataFrame to be checked.
            dq_rules (dict): A dictionary containing the data quality rules.
                             It should have 'metadata' and 'assignments' keys (optionally under a 'message' key).
            process_date (date, optional): The process date to use for source_process in the results.
                                          Defaults to today's date if not provided.
        """
        if not isinstance(df, DataFrame):
            raise TypeError("The 'df' argument must be a Spark DataFrame.")
        
        if not isinstance(dq_rules, dict):
            raise ValueError("The 'dq_rules' argument must be a dictionary.")
        
        # Handle payloads with or without the 'message' wrapper
        self.dq_rules = dq_rules
        self.rules_data = dq_rules.get("message", dq_rules)
        
        if "metadata" not in self.rules_data or "assignments" not in self.rules_data:
            raise ValueError("The data quality rules must contain 'metadata' and 'assignments' keys.")

        self.process_date = process_date if process_date is not None else datetime.date.today()
        # Add a sequential row number to each row to serve as a primary key.
        window = Window.orderBy(F.monotonically_increasing_id())
        # Cache the DataFrame after adding _row_id to ensure stability during rule evaluation.
        self.df = df.withColumn("_row_id", F.row_number().over(window)).cache()

        # Derive the bare table name from metadata (e.g. "schema.table" -> "table")
        # and register the DataFrame as a temp view so subquery rules can reference it.
        metadata = self.rules_data.get("metadata", "")
        # Clean up metadata if it starts with '='
        metadata = metadata.lstrip('=')
        self._table_name = metadata.split('.')[-1] if '.' in metadata else metadata
        if self._table_name:
            self.df.createOrReplaceTempView(self._table_name)

    def _rule_valid(self, rule: Dict[str, Any]) -> str:
        """Rule handler for 'Valid' type."""
        field = rule.get("field")
        param = rule.get("param")
        if param and param.upper() == "DATE":
            return f"to_date({field}) IS NOT NULL"
        return "TRUE"

    def _rule_equals(self, rule: Dict[str, Any]) -> str:
        """Rule handler for 'Equals' type."""
        field = rule.get("field")
        param = rule.get("param")
        return f"{field} = '{param}'"

    def _rule_less_than(self, rule: Dict[str, Any]) -> str:
        """Rule handler for 'Less than' type."""
        field = rule.get("field")
        param = rule.get("param")
        return f"{field} < '{param}'"

    def _rule_greater_than(self, rule: Dict[str, Any]) -> str:
        """Rule handler for 'Greater than' type."""
        field = rule.get("field")
        param = rule.get("param")
        return f"{field} > '{param}'"

    def _rule_generic(self, rule: Dict[str, Any]) -> str:
        """Rule handler for 'Generic' type. Uses 'descriptions' for logic."""
        desc = rule.get("descriptions", "TRUE")
        return self._clean_rule_description(desc)

    def run_checks(self) -> Dict[str, Any]:
        """
        Runs the data quality checks defined in the dq_rules on the DataFrame.

        For each rule, it evaluates the rule based on its type and flags rows that violate it.
        A violation is recorded if the generated rule expression evaluates to False.
        The method is optimized to run all rule checks in a single pass over the data.

        Returns:
            A dictionary containing the results of the data quality checks,
            detailing which rows violated which rules.
        """
        rules = self.rules_data.get("assignments", [])
        Logger().log(f"DQ Rules found: {len(rules)}", level="debug")
        if not rules:
            return self._build_final_output({})

        # Mapping of rule types to implementation methods
        rule_handlers = {
            "Valid": self._rule_valid,
            "Equals": self._rule_equals,
            "Less than": self._rule_less_than,
            "Greater than": self._rule_greater_than,
            "Generic": self._rule_generic
        }

        # --- Step 1: Create a temporary DataFrame with a new column for each rule's result ---
        # Each rule column will store a struct containing the result (0/1) and description.
        # Track (rule_identifier, dq_assignment_label) pairs for unpivoting
        rule_mappings = []
        temp_df = self.df

        for rule in rules:
            rule_name = rule["rule"]
            rule_type = rule["rule_type"]
            dq_assignment = rule.get("dq_assignment", rule_name)
            
            rule_mappings.append((rule_name, dq_assignment))
            
            # Get the rule expression using the appropriate handler
            handler = rule_handlers.get(rule_type, self._rule_generic)
            rule_expr = handler(rule)
            
            # The rule description for results is the 'descriptions' field or the rule type
            rule_desc = rule.get("descriptions", rule_type)

            if rule_expr and "SELECT" in rule_expr.upper():
                # Subquery rule: evaluate via Spark SQL so table references are resolved.
                sql = (
                    f"SELECT _row_id, "
                    f"CASE WHEN {rule_expr} THEN 1 ELSE 0 END AS result "
                    f"FROM {self._table_name}"
                )
                Logger().log(f"Evaluating subquery rule: {rule_name}", level="debug")
                
                try:
                    rule_result_df = temp_df.sparkSession.sql(sql).withColumnRenamed("result", "_dq_res")
                    temp_df = temp_df.join(rule_result_df, on="_row_id", how="left")
                    temp_df = temp_df.withColumn(
                        rule_name,
                        F.struct(
                            F.col("_dq_res").alias("dq_rule_result"),
                            F.lit(rule_desc).alias("rule_description")
                        )
                    ).drop("_dq_res")
                    # Refresh the temp view to include newly added columns for subsequent rules.
                    temp_df.createOrReplaceTempView(self._table_name)
                except Exception as e:
                    Logger().log(f"Error evaluating subquery rule '{rule_name}': {str(e)}", level="debug")
                    temp_df = temp_df.withColumn(
                        rule_name,
                        F.struct(F.lit(0).alias("dq_rule_result"), F.lit(rule_desc).alias("rule_description"))
                    )
            else:
                # Simple expression rule: evaluate directly on the DataFrame.
                try:
                    temp_df = temp_df.withColumn(
                        rule_name,
                        F.struct(
                            F.when(F.expr(rule_expr), 1).otherwise(0).alias("dq_rule_result"),
                            F.lit(rule_desc).alias("rule_description")
                        )
                    )
                except Exception as e:
                    Logger().log(f"Error evaluating expression rule '{rule_name}': {str(e)}", level="debug")
                    temp_df = temp_df.withColumn(
                        rule_name,
                        F.struct(F.lit(0).alias("dq_rule_result"), F.lit(rule_desc).alias("rule_description"))
                    )

        # --- Step 2: Unpivot the rule columns to a long format for easier processing ---
        # This transforms the wide DataFrame into a long one with columns: _row_id, dq_assignment, rule_data
        stack_expr_parts = [f"'{dq_assign}', `{rule_name}`" for rule_name, dq_assign in rule_mappings]
        stack_expression = f"stack({len(rule_mappings)}, {', '.join(stack_expr_parts)}) as (dq_assignment, rule_data)"

        unpivoted_df = temp_df.select(F.col("_row_id"), F.expr(stack_expression))

        # --- Step 3: Aggregate all rule results by row ---
        results_df = unpivoted_df.groupBy("_row_id").agg(
            F.collect_list(
                F.struct(
                    F.col("dq_assignment"),
                    F.col("rule_data.rule_description").alias("rule_description"),
                    F.col("rule_data.dq_rule_result").cast("string").alias("dq_rule_result")
                )
            ).alias("violations")
        )

        # --- Step 4: Collect the aggregated results and format the final dictionary ---
        results_df = results_df.orderBy("_row_id")
        collected_results = results_df.collect()

        final_results_dict = {
            str(row["_row_id"]): [r.asDict() for r in row["violations"]]
            for row in collected_results
        }
            
        return self._build_final_output(final_results_dict)

    def _build_final_output(self, results_dict: Dict[str, Any]) -> Dict[str, Any]:
        """A helper method to construct the final output dictionary in the desired format."""
        metadata = self.rules_data.get("metadata", "")
        # Clean up metadata if it starts with '='
        metadata = metadata.lstrip('=')
        table_name = metadata.split('.')[-1] if '.' in metadata else metadata

        return {
            "metadata": metadata,
            "table_name": table_name,
            "source_process": self.process_date.isoformat() if hasattr(self.process_date, 'isoformat') else str(self.process_date),
            "results": results_dict
        }

    def _clean_rule_description(self, rule_desc: str) -> str:
        """
        Cleans the rule description by removing single-line comments and trimming whitespace.
        
        Args:
            rule_desc (str): The raw rule description from the metadata.
            
        Returns:
            str: The cleaned rule description.
        """
        if not rule_desc:
            return ""
            
        lines = rule_desc.splitlines()
        cleaned_lines = []
        for line in lines:
            # Remove single-line comments starting with --
            if '--' in line:
                line = line.split('--')[0]
            cleaned_lines.append(line.rstrip())
            
        return " ".join(cleaned_lines).strip()

### Example Usage


# This block is for demonstration purposes.
if __name__ == '__main__':
    # Initialize a SparkSession
    spark = SparkSession.builder \
        .appName("DataQualityExample") \
        .master("local[*]") \
        .getOrCreate()

    # 1. Sample DataFrame
    data = [
        # Row 1: All rules pass
        (2026, "2026-01-01", "COMPA", "DEPTA", 2026, "COMPA", "DEPTA"),
        # Row 2: budget_year fail (<= 2025)
        (2025, "2026-01-01", "COMPB", "DEPTB", 2025, "COMPB", "DEPTB"),
        # Row 3: date fail and generic length fail (length 2)
        (2026, None, "XY", "DEPTC", 2026, "COMPC", "DEPTC"),
        # Row 4: All pass
        (2027, "2027-05-06", "COMPD", "DEPTD", 2027, "COMPD", "DEPTD"),
    ]
    schema = ["budget_year", "max_budget_spend_date", "company", "department", "source_year", "source_company", "source_department"]
    my_dataframe = spark.createDataFrame(data, schema)

    # 1. Define the updated sample payload
    dq_rules_payload = {
        "message": {
            "metadata": "vantage_transformed.slpgc_monthly_budget_projections",
            "assignments": [
                {
                    "dq_assignment": "Valid Date",
                    "rule": "Valid-IS_VALID_DATE",
                    "rule_type": "Valid",
                    "field": "max_budget_spend_date",
                    "param": "DATE",
                    "descriptions": "Should be valid date"
                },
                {
                    "dq_assignment": "greater_than_year",
                    "rule": "Greater than-IS_MORE_THAN",
                    "rule_type": "Greater than",
                    "field": "budget_year",
                    "param": "2025",
                    "descriptions": "Greater Than Date"
                },
                {
                    "dq_assignment": "Generic-COMP_LENGTH--0004",
                    "rule": "Generic-COMP_LENGTH",
                    "rule_type": "Generic",
                    "field": None,
                    "param": None,
                    "descriptions": "length(company) >= 3"
                }
            ]
        }
    }

    # 3. Initialize the class and run the checks
    dq_checker = XursparksDataQuality(df=my_dataframe, dq_rules=dq_rules_payload)
    quality_results = dq_checker.run_checks()

    # 4. Print the results for review
    import json
    Logger().debug(json.dumps(quality_results, indent=4))

    # Stop the SparkSession
    spark.stop()
