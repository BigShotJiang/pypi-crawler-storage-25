"""
Data Quality Report Generator

This module provides the main interface for generating data quality reports.
It handles data loading, sampling, type checking, and coordinates the rendering 
of statistical summaries and visualizations.
"""
import os
import yaml
import warnings
import logging
from pathlib import Path
from typing import List, Tuple, Any

import pandas as pd

from .report import get_report, get_empty_report, get_comparison_report, get_error_report, get_test_report
from .data import check_dtypes, describe, load_dataframe, validate_dataframe, sample_dataframe, check_col_names, describe_invalid, check_data, convert_to_pandas
from .config import Settings

warnings.filterwarnings("ignore", category=UserWarning, module='visions')

logging.basicConfig(level=logging.DEBUG)
logging.getLogger('matplotlib').setLevel(logging.WARNING)
logging.getLogger('PIL').setLevel(logging.WARNING)
logger = logging.getLogger(__name__)

class DataReport:
    """
    Orchestrates the generation of data quality reports from various input formats.

    Process Flow:
    1. Loads configuration from initialization parameters, config files, or defaults.
    2. Validates and loads input data (File paths or DataFrames).
    3. Performs data sampling if enabled.
    4. Orchestrates data profiling (describing) for valid and invalid datasets.
    5. Renders the final HTML report using specialized renderers.
    """
    def __init__(self, 
                 file:str|None=None, 
                 df:pd.DataFrame|List[pd.DataFrame]|Tuple[pd.DataFrame,pd.DataFrame,List] =None, 
                 report_name:str|None=None, 
                 file_path:str|None=None,
                 data_types:dict|None=None,
                 description: str|None = None,
                 minimal: bool|None=False,
                 sample_mode: str = 'auto',
                 sample_size: float|None = None,
                 auto_sample_dataset_length: int|None= None,
                 alerts_list: List[str|None] = [],
                 config_file: str|None = None,
                 **kwargs):
        """
        Initializes the DataReport object with data and configuration.

        Process Flow:
        1. Consolidates configuration from kwargs, config file, and defaults.
        2. Sets up the application settings (Sampling, Visuals, etc.).
        3. Parses input data (DataFrame, Tuple of DataFrames, or File path).
        4. Applies sampling if configured.
        5. Inferred or validates data types.

        Args:
            file (str, optional): Path to the data file (.csv, .xlsx, .parquet, .orc).
            df (DataFrame|List|Tuple, optional): Pandas DataFrame or list/tuple of DataFrames.
            report_name (str, optional): Title of the report.
            file_path (str, optional): Target destination for the HTML report.
            data_types (dict, optional): Mapping of column names to expected types.
            description (str, optional): Optional metadata description of the dataset.
            minimal (bool, optional): If True, generates a slimmed-down report.
            sample_mode (str): Sampling strategy: 'auto', 'manual', or 'none'. Default 'auto'.
            sample_size (float, optional): Fraction to sample (0.0 to 1.0) if mode is 'manual'.
            auto_sample_dataset_length (int, optional): Threshold for auto-sampling.
            alerts_list (List[str], optional): Custom alerts to display in the report.
            config_file (str, optional): Path to a YAML configuration file.
            **kwargs: Overrides for any settings defined in the config.
        """
        logger.info("Initializing DataReport object")

        """Loading the config Section"""
        """The loading of config priority goes with highest priority first:
            - initialization DataReport parameters
            - config file
            - default values"""
        
        __non_config_params__ = ["self","kwargs","df","file", "config_file","sample_size", "sample_mode", "auto_sample_dataset_length","description","__non_config_params__", "alerts_list"]
        __user_set_params__ = {key: value for key, value in locals().items() if value is not None and key not in __non_config_params__}
        for k,v in kwargs.items():
            if v is not None and k not in __non_config_params__:
                __user_set_params__[k] = v
    
        logger.debug(f"__user_set_params__: {__user_set_params__}")
        if config_file != None:
            try:
                with open(config_file) as f:
                    __config_file_params__ = yaml.load(f, Loader=yaml.FullLoader)
                
                if __config_file_params__ is None:
                    raise ValueError(f"{config_file} is empty! proceeding with report generation.")

                logger.debug("Config file before being loaded in settings")
                logger.debug(__config_file_params__)
                self.config = Settings(**__config_file_params__)
                logger.debug("After loading it into Settings class")
                logger.debug(self.config)
                logger.info(f"Loaded configuration from {config_file}")

                for key, value in __user_set_params__.items():
                    setattr(self.config, key, value)

            except FileNotFoundError:
                logger.warning(f"{config_file} does not exist! continuing with generating report without it")

            except Exception as e:
                logger.error(f"Error loading config file: {e}")

            finally:
                self.__load_config__(__user_set_params__, sample_mode, auto_sample_dataset_length, sample_size)
        else:
            self.__load_init_config__(__user_set_params__=__user_set_params__,
                                       sample_mode=sample_mode, 
                                       auto_sample_dataset_length=auto_sample_dataset_length,
                                        sample_size=sample_size)

        """Checking dataframe input"""
        if description is None:
            self.dataset_description = None
        else:  
            self.dataset_description = [description]

        """Checking for alerts"""
        self.alerts_list = alerts_list
        logger.debug(" Checking for alerts here")
        if len(alerts_list) > 0:
            # If alerts is not empty set flag to render alerts
            setattr(self.config, "alerts", True)
            logger.debug(f"Alerts Config is {self.config.alerts}")

        if isinstance(df, dict):
            df_frames = list(df.values())
            self.df = []
            for frame in df_frames:
                self.df.append(frame if isinstance(frame, pd.DataFrame) else convert_to_pandas(frame) )
                
            self.df_names = list(df.keys())
            self.render_empty = False

        elif isinstance(df, tuple):
            self.df = df[0] if isinstance(df[0], pd.DataFrame) else convert_to_pandas(df[0])
            self.df_invalid = df[1] if isinstance(df[1], pd.DataFrame) else convert_to_pandas(df[1])
            self.errors = df[2] if isinstance(df[2],list) else [df[2]]
            self.empty_df_invalid = True if not validate_dataframe(self.df_invalid, self.config) else False
            self.render_empty = True if not validate_dataframe(self.df, self.config) else False
        
        else:
            if file is not None:
                if df is not None:
                    raise KeyError("Only 'file' or 'df' should be used one at a time!")
                self.df = load_dataframe(file)
                self.render_empty = False

            else:
                if df is None:
                    raise ValueError("Please provide your data in 'file' or 'df' parameters!")
                
                self.df = df
                self.render_empty = True if not validate_dataframe(df, self.config) else False # checks if dataframe is empty

        if self.config.sampling.get_sampling:
            self.df, sample_description = sample_dataframe(self.df, self.config)
            if sample_description is not None:
                if self.dataset_description is None:
                    self.dataset_description = [sample_description]
                elif isinstance(self.dataset_description, list):
                    self.dataset_description.append(sample_description)
                else:
                    self.dataset_description = [self.dataset_description, sample_description]
                print(f"after: {self.dataset_description}")

        """checking data types"""
        if data_types is not None:
            self.data_types = check_dtypes(check_col_names(data_types, df.columns))
        else:
            self.data_types = None

        logger.debug(f"self.render_empty: {self.render_empty}")
        logger.info("DataReport object initialized successfully")

    def __load_config__(self, __user_set_params__:dict, sample_mode, auto_sample_dataset_length, sample_size):
        """
        Internal helper to update the config object with user-provided parameters.

        Process Flow:
        1. Copies the current settings object.
        2. Updates it with the provided user parameters.
        3. Configures sampling settings based on the specified mode (auto/manual/none).

        Args:
            __user_set_params__ (dict): Parameters to update in the config.
            sample_mode (str): The sampling mode to apply.
            auto_sample_dataset_length (int): Dataset threshold for auto-sampling.
            sample_size (float): Manual sample fraction.
        """

        logger.debug(f"sample_mode: {sample_mode}")
        self.config = self.config.model_copy(update=__user_set_params__)

        logger.debug("Config Loaded:")
        logger.debug(self.config)
        logger.debug(f"sample_mode == 'auto': {sample_mode == 'auto'}")

        sample_mode = sample_mode.lower() if sample_mode is not None else None

        """Sampling settings"""
        if sample_mode == "auto":
            logger.debug("auto sampling chosen")
            if auto_sample_dataset_length is not None:
                self.config.sampling.auto_length = auto_sample_dataset_length

        elif sample_mode == "manual":
            if sample_size is not None:
                if sample_size > 1:
                    raise ValueError("Sample size should be a fraction less than 1")
                self.config.sampling.size = sample_size
            else:
                raise ValueError("Manual sample_mode requires you to provide a sample_size (fraction between 0 and 1)")
            
        elif sample_mode is None or sample_mode == "none":
            self.config.sampling.get_sampling = False

        else:
            raise ValueError("Invalid sample_mode. Please choose between 'auto', 'manual', or 'none'")

    def __load_init_config__(self, **kwargs):
        """
        Initializes a fresh Settings object and loads it with provided arguments.

        Args:
            **kwargs: Configuration overrides.
        """
        self.config = Settings()
        self.__load_config__(**kwargs)
        logger.debug("Initial Config Params")
        logger.debug(self.config)

    def describe_dataframe(self):
        """
        Generates a statistical description of the main dataset.

        Process Flow:
        1. Calls the `describe` utility to compute metrics for each column.
        2. Appends any existing dataset descriptions or alerts to the result.
        """
        logger.info("Describing dataframe")
        self.description = describe(df=self.df, data_types=self.data_types, config=self.config)
        if self.dataset_description is not None and self.dataset_description != "":
            if self.description.description is None:
                self.description.description = []
            
            self.description.description.extend(self.dataset_description)

        if self.config.alerts:
            self.description.alerts = self.alerts_list

        logger.info("Dataframe described successfully")

    def describe_invalid_dataframe(self):
        """
        Generates a description for rows that failed data quality validation.

        Process Flow:
        1. Calls `describe_invalid` utility to summarize errors.
        """
        logger.info("Describing invalid dataframe")
        self.description_invalid = describe_invalid(df=self.df_invalid, errors=self.errors, config=self.config)
        logger.info("Invalid dataframe described successfully")

    def get_data_quality_report(self, config:dict, **kwargs):
        """
        Generates a standard data quality report as an HTML string.

        Args:
            config (dict): Configuration settings for the report.
            **kwargs: Additional parameters for rendering.

        Returns:
            str: The rendered HTML report.
        """
        logger.info("Generating data quality report")
        self.describe_dataframe()
        report = get_report(self.description, config)
        logger.info("Data quality report generated successfully")
        return report.render()
    
    def _render_empty_report(self, config:dict):
        """
        Renders a report for an empty dataset.

        Args:
            config (dict): Configuration settings.

        Returns:
            str: The rendered HTML report.
        """
        logger.info("Rendering empty report")
        report = get_empty_report(self.df, config)
        logger.info("Empty report rendered successfully")
        return report.render()
    
    def _render_comparison(self, config:dict):
        """
        Renders a comparison report for multiple datasets.

        Args:
            config (dict): Configuration settings.

        Returns:
            str: The rendered HTML report.
        """
        logger.info("Rendering comparison report")
        self.describe_dataframe()
        report = get_comparison_report(self.description, self.df_names, config)
        logger.info("Comparison report rendered successfully")
        return report.render()
    
    def _render_error_report(self, config:dict):
        """
        Renders a specialized report focusing on data quality errors.

        Args:
            config (dict): Configuration settings.

        Returns:
            str: The rendered HTML report.
        """
        logger.info("Rendering error report")
        self.describe_invalid_dataframe()
        if self.render_empty:
            report = get_error_report(data=self.df,
                            invalid_data=self.description_invalid,
                            errors=self.errors, 
                            is_empty=self.render_empty,
                            config=config)
        
        else:
            self.describe_dataframe()
            report = get_error_report(data=self.description,
                                    invalid_data=self.description_invalid,
                                    errors=self.errors, 
                                    is_empty=self.render_empty, 
                                    config=config)
        logger.info("Error report rendered successfully")
        return report.render()
    
    def __render_test_report(self):
        """
        Internal helper to render a test-specific report.

        Returns:
            str: The rendered HTML report.
        """
        logger.info("Rendering test report")
        self.describe_dataframe()
        report = get_test_report(df=self.description, name=None)
        rendered_report = report.render(self.config)
        logger.info("Test report rendered successfully")
        return rendered_report

    def to_file_test(self):
        """
        Saves the test report to the configured file path.
        """
        logger.info(f"Saving test report to {self.config.file_path}")
        output = Path(self.config.file_path)
        output.write_text(self.__render_test_report(), encoding='utf-8')
        logger.info("Test report saved successfully")

    def to_file(self):
        """
        Generates the appropriate report type (Error, Empty, Comparison, or Standard) 
        and saves it to the configured file path.

        Process Flow:
        1. Determines which report type is needed based on available data.
        2. Renders the report to an HTML string (minified if configured).
        3. Writes the string to the output file.
        """
        logger.info(f"Saving report to {self.config.file_path}")
        output = Path(self.config.file_path)
        if hasattr(self, 'errors'):
            logger.info(f"saving error report as {self.config.file_path}")
            output.write_text(self._render_error_report(config=self.config), encoding='utf-8')
            logger.info(f"saved!")

        elif self.render_empty:
            logger.info(f"saving empty report as {self.config.file_path}")
            output.write_text(self._render_empty_report(config=self.config), encoding='utf-8')
            logger.info("saved!")

        elif isinstance(self.df, list):
            logger.info(f"saving comparison report!")
            output.write_text(self._render_comparison(config=self.config), encoding='utf-8')
            logger.info('saved!')
        
        else:
            logger.info(f"saving as {self.config.file_path}")
            if self.config.minimal:
                logger.info("saving minimal version of report!")
                from minify_html import minify
                minified_report = minify(self.get_data_quality_report(config=self.config))
                output.write_text(minified_report, encoding='utf-8')
            else:
                output.write_text(self.get_data_quality_report(config=self.config), encoding='utf-8')
            
            logger.info(f"saved!")