"""
String Variable Renderer

This module provides the rendering logic for string/textual variables, 
including summary tables and word cloud visualizations.
"""
import pandas as pd

from ..renderer import HTMLBase, HTMLTable, HTMLVariable, HTMLPlot, HTMLToggle, HTMLCollapse
from ...visuals import plot_to_base64, create_word_cloud
from .bottom.render_bottom_string import render_bottom_string

def render_string(data: dict, name:str, config:dict)->HTMLBase:
    """
    Renders the HTML component for a string variable.

    Process Flow:
    1. Prepares a summary table (distinct, missing, memory).
    2. Generates a word cloud plot from word frequencies.
    3. Bundles the component with a collapsible 'More details' section.

    Args:
        data (dict): The string-based summary data.
        name (str): The column name.
        config (dict): Report configuration.

    Returns:
        HTMLVariable: The rendered component for the string variable.
    """
    name = name.replace(" ", "-").lower()
    table = {
        "Distinct": data['distinct'],
        "Distinct (%)": "{:0.2f}%".format(data['distinct_perc']),
        "Missing": data['missing'],
        "Missing (%)": "{:0.2f}%".format(data["missing_perc"]),
        "Memory size": "{} bytes".format(data['memory'])
    }
    variable_body = {
        'table': HTMLTable(table),
        'plot': HTMLPlot(plot=create_word_cloud(data['word_counts'], minimal=config.minimal))
    }

    return HTMLVariable(
        name = name,
        type = data['type'],
        body = variable_body,
        bottom = HTMLCollapse(
            HTMLToggle("More details", name),
            render_bottom_string(data,name)
        )
    )