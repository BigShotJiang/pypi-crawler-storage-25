"""
Detailed Categorical Variable Renderer (Bottom Section)

This module defines the 'More details' section for categorical variables, 
providing length statistics, category counts, and value samples in a tabbed layout.
"""
from ....data.typeset import Categorical
from ...handler import Handler
from ...renderer import HTMLBase, HTMLContainer, HTMLTable, HTMLVariable, HTMLPlot, HTMLToggle, HTMLCollapse, HTMLDropdown
from ....visuals import plot_to_base64, create_tiny_histogram, create_histogram, create_distribution_plot, create_heatmap, create_interaction_plot

@Handler.register(Categorical)
def render_bottom_categorical(data: dict, col_name: str, *args, **kwargs):
    """
    Renders the detailed (collapsible) bottom section for categorical variables.

    Process Flow:
    1. Builds an 'Overview' tab containing string length stats (min, max, etc.) 
       and a sample of actual values.
    2. Builds a 'Categories' tab with a full frequency distribution table.
    3. Wraps the tabs in an HTMLContainer.

    Args:
        data (dict): The categorical profiling data.
        col_name (str): The name of the column.

    Returns:
        HTMLContainer: The tabbed container for the detailed categorical view.
    """
    variable_bottom = [
        HTMLContainer(
            type="default",
            name="Overview",
            id = 'overview',
            container_items= [
                HTMLContainer(type="box",
                              container_items=[
                                HTMLContainer(
                                    type = "column",
                                    container_items = HTMLTable(
                                        data = {
                                            "Max Length": data['max_length'],
                                            "Median Length": data['median_length'],
                                            "Mean Length": data['mean_length'],
                                            "Minimum Length": data['min_length']

                                        }
                                    )
                                ),
                                HTMLContainer(
                                    type ="column",
                                    container_items = HTMLTable(
                                        data = {f"{i+1}st Row" if i == 0 else f"{i+1}nd Row" if i == 1 else f"{i+1}rd Row" if i == 2 else f"{i+1}th Row": value for i, (key, value) in enumerate(data['samples'].items())}
                                    )

                                )]
                            )
            ]
        ),
        HTMLContainer(
            type="default",
            name="Categories",
            id="categories",
            container_items=[
                HTMLTable(
                    id=f"{col_name}-cat-samples",
                    name='Table',
                    data = data['cat_counts'].to_html(classes="table table-sm", border=0)
                )
            ]
        )
    ]
    return HTMLContainer(type="tabs",
                         col=col_name,
                         container_items=variable_bottom)