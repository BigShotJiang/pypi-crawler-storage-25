"""
HTML Component Renderers

This module defines a hierarchy of renderer classes used to convert statistical 
profiles and data metrics into HTML components using Jinja2 templates.
"""
from abc import ABC, abstractmethod
from typing import Any, Dict,List
from visions import VisionsBaseType

from .template_loader import template

class BaseRenderer(ABC):
    """
    Abstract base class for all report component renderers.

    Attributes:
        content (Dict): Data and configuration to be passed to the template.
        kwargs (Dict): Additional layout or style parameters.
    """
    def __init__(self, content: Dict[str, Any], name: str = None, id:str=None, type:VisionsBaseType=None, config:dict=None,**kwargs):
        """
        Initializes the renderer with content and optional metadata.

        Args:
            content (Dict): The core data to render.
            name (str, optional): The display name for the component.
            id (str, optional): A unique ID for HTML elements.
            type (VisionsBaseType, optional): The data type of the variable being rendered.
            config (dict, optional): Component-specific configuration.
        """
        self.content = content
        self.kwargs = kwargs

        if name is not None:
            self.content['name'] = name
        
        if config is not None:
            self.content['config'] = config

        if id is not None:
            self.content['id'] = id

        if type is not None:
            self.type = type
        

    @property
    def name(self) -> str:
        """Returns the component's name."""
        return self.content.get('name', None)
    
    @property
    def id(self) -> str:
        """Returns the component's unique ID."""
        return self.content.get('id', None)

    @abstractmethod
    def render(self) -> Any:
        """Abstract method to perform the actual rendering logic."""
        pass

class HTMLTable(BaseRenderer):
    """Renders data as an HTML table using the table.html template."""
    def __init__(self, data:Any=None, id:str=None, name:str=None, headers:List[str]=None, config:list|dict=None,**kwargs):
        """
        Initializes a table renderer.

        Args:
            data (Any): The table data (usually a list of rows or a DataFrame).
            headers (List[str], optional): Table column headers.
        """
        self.kwargs = kwargs
        super().__init__(id=id, name=name, config=config,content={'data': data, 'headers': headers}, **kwargs)

    def render(self):
        """Renders the table template."""
        if self.kwargs:
            return template("table.html").render(**self.content, **self.kwargs)
        else:
            return template("table.html").render(**self.content)
        
class HTMLToggle(BaseRenderer):
    """Renders a clickable toggle button for collapsing sections."""
    def __init__(self, text:str, id:str, **kwargs):
        super().__init__( content={'text': text, 'id': id}, **kwargs)

    def render(self):
        """Renders the toggle template."""
        return template("toggle.html").render(**self.content)
        
class HTMLCollapse(BaseRenderer):
    """
    Renders a block of content that can be toggled (expanded/collapsed).
    
    Requires an associated HTMLToggle.
    """
    def __init__(self, button: HTMLToggle, body:Any, **kwargs):
        super().__init__({'button':button, 'body':body}, **kwargs)
    
    def render(self):
        """Renders the collapse template."""
        return template("collapse.html").render(**self.content)
    
class HTMLVariable(BaseRenderer):
    """Renders the per-variable summary section, including type-specific details."""
    def __init__(self, name, body, bottom=None, **kwargs):
        super().__init__({"variable_name":name, "variable_body": body, "variable_bottom": bottom}, **kwargs)

    def render(self):
        """Renders the variable section template."""
        return template("variable.html").render(name = self.content['variable_name'], bottom=self.content['variable_bottom'], content = self.content['variable_body'], type=self.type)
    
class HTMLPlot(BaseRenderer):
    """Renders an image or interactive plot (Matplotlib/Plotly)."""
    def __init__(self, plot:Any, type="small", **kwargs):
        """
        Initializes a plot renderer.

        Args:
            plot (Any): The plot object or base64 image string.
            type (str): The size/category of the plot ('small', 'large', or 'categorical').
        """
        super().__init__({"plot": plot}, **kwargs)

        if type !="small" and type !="large" and type!='categorical':
            raise ValueError("Plot type should be either 'small' or 'large' or 'categorical'")
        else:
            self.type=type

    def render(self):
        """Renders the plot template."""
        return template("plot.html").render(**self.content, type=self.type)
    

class HTMLDropdown(BaseRenderer):
    """Renders a interactive dropdown menu component."""
    def __init__(self, id:str, dropdown_items: List[str], dropdown_content: Any,name:str=None, **kwargs):
        super().__init__(
                        {
                            'dropdown_items': dropdown_items,
                            'dropdown_content': dropdown_content
                        },
                        name,
                        id,
                        **kwargs)
    def render(self):
        """Renders the dropdown template."""
        return template("dropdown.html").render(**self.content)

class HTMLText(BaseRenderer):
    """Renders a simple block of text or list of strings."""
    def __init__(self, text:List[str]=None, **kwargs):
        if not isinstance(text,list):
            text = [text]
        super().__init__(content={'text':text}, **kwargs)

    def render(self):
        """Renders the text template."""
        return template("text.html").render(content = self.content, **self.kwargs)

class HTMLContainer(BaseRenderer):
    """
    Orchestrates the layout of multiple components within a shared container.
    Supports boxes, columns, tabs, and specific layout sections.
    """
    def __init__(self, type:str, container_items:list, name:str=None, id:str=None, col=None, **kwargs):
        """
        Initializes a layout container.

        Args:
            type (str): The type of container ('box', 'column', 'sections', 'tabs', 'default', 'test').
            container_items (list): The list of renderers to include in the container.
        """
        super().__init__({'container_items':container_items, 'name': name, 'id':id, 'col':col}, **kwargs)
        self.type = type
        self.kwargs = kwargs
        
    def render(self):
        """Dispatches to the specific container template based on type."""
        if self.type == 'box':
            return template("containers/box.html").render(container_items=self.content['container_items'], **self.kwargs)
        elif self.type == 'column':
            return template("containers/column.html").render(container_items=self.content['container_items'], **self.kwargs)
        elif self.type == 'sections':
            return template("containers/sections.html").render(
                container_items=self.content['container_items'], **self.kwargs)
        elif self.type == 'tabs':
            return template("containers/tabs.html").render(**self.content, **self.kwargs)
        elif self.type == 'default':
            return template("containers/default.html").render(**self.content, **self.kwargs)
        elif self.type == 'test':
            return template("containers/test.html").render(**self.content, **self.kwargs)
        else:
            raise ValueError(f"unknown Container ({self.type}) type!")

class HTMLBase(BaseRenderer):
    """The top-level renderer that wraps the entire report in a base layout (navbar, etc.)."""
    def __init__(self, body: Any, name: str, **kwargs):
        if name is None:
            name = "Profile Report"
        super().__init__(content={"body":body}, name=name, **kwargs)

    def render(self, **kwargs) -> str:
        """Renders the full HTML document."""
        nav_items = [self.content['name']]
        return template("base.html").render(**self.content, nav_items=nav_items, **kwargs)