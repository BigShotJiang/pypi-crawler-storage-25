"""
Report Layout Orchestration

This module coordinates the creation of various report sections (Overview, Samples, 
Variables, Correlations, etc.) by instantiating component renderers.
"""
import logging
logger = logging.getLogger(__name__)
from typing import Any, List

from ..data.descriptions import TableDescription
from .renderer import BaseRenderer, HTMLContainer, HTMLTable, HTMLPlot, HTMLText
from .render_sections import (render_variables_section, 
                                                    render_missing_section,
                                                    render_correlation_section, 
                                                    render_interactions_section, 
                                                    render_dropdown_section)

def create_overview_section(data: TableDescription, dataset_statistics: dict, config:dict) -> HTMLContainer:
    """
    Creates the 'Overview' box which contains statistics, variable types, and alerts.

    Process Flow:
    1. Creates nested containers for 'Dataset Statistics' and 'Variable Types' tables.
    2. Adds a 'Description' tab if a dataset description is provided.
    3. Adds an 'Alerts' tab if alerting is enabled in the configuration.
    4. Wraps everything in a tabbed HTMLContainer.

    Args:
        data (TableDescription): The dataset profile.
        dataset_statistics (dict): Formatted metrics for display.
        config (dict): Report configuration.

    Returns:
        HTMLContainer: The populated overview section.
    """
    overview = HTMLContainer(
            type="default",
            name="Overview",
            id="overview-tab",
            container_items=[
                HTMLContainer(
                    type="column",
                    container_items=HTMLTable(
                        data=dataset_statistics,
                        name="Dataset Statistics"
                    )),
                HTMLContainer(
                    type="column",
                    container_items=HTMLTable(
                        data=data.variable_types,
                        name="Variable Types"
                    )
                )
            ]
        )
    
    overview_contents = [overview]

    if data.description is not None:
        description = HTMLContainer(
            type="default",
            name="Description",
            id="description-tab",
            container_items=[
                HTMLText(
                    text = data.description
                )
            ]
        )

        overview_contents.append(description)

    if config.alerts:
        alerts = HTMLContainer(
            type="default",
            name="Alerts",
            id="alerts-tab",
            flex=True,
            container_items=[
                HTMLTable(
                    id="alerts",
                    data=data.alerts
                )
            ]
        )
        overview_contents.append(alerts)

    return HTMLContainer(
        type="box",
        name="Overview",
        id="overview_section",
        container_items=[
            HTMLContainer(
                type="tabs",
                container_items=overview_contents
            )
        ]
    )

def render_report(data: TableDescription, config: dict) -> List[BaseRenderer]:
    """
    High-level function to assemble the full profile report content.

    Process Flow:
    1. Formats raw dataset statistics for display.
    2. Builds the Overview section (stats, types, alerts).
    3. Builds the Samples section (dataset head).
    4. Conditionally builds Variables, Missing Values, Correlations, and Interactions sections.
    5. Returns a list of all section renderers.

    Args:
        data (TableDescription): The profiled dataset data.
        config (dict): Execution configuration.

    Returns:
        List[BaseRenderer]: A list of section renderers ready for document-level rendering.
    """
    content = []

    dataset_statistics = {
        'Length of Dataset': data.dataset_statistics['dataset_length'],
        'Number of Variables': data.dataset_statistics['num_variables'],
        'Missing Cells': data.dataset_statistics['missing_cells'],
        'Missing Cells (%)': "{:0.2f}%".format(data.dataset_statistics['missing_cells_perc']),
        'Duplicate Rows': data.dataset_statistics['duplicate_rows'],
        'Duplicate Rows (%)': "{:0.2f}%".format(data.dataset_statistics['duplicate_rows_perc'])
    }

    overview_section = create_overview_section(data, dataset_statistics, config)
    content.extend([overview_section])

    if config.show_all_samples:
        samples = data.df.head(100).to_html(classes="table table-sm", 
                                           border=0, 
                                           index=False, 
                                           justify='left',
                                           table_id='samples_table')
    else:
        samples = data.df.head(10).to_html(classes="table table-sm", 
                                           border=0, 
                                           index=False, 
                                           justify='left',
                                           table_id='samples_table')

    samples_section = HTMLContainer(
        type="box",
        name="Sample",
        container_items=[
            HTMLTable(
                id="sample",
                data=samples
            )
        ]
    )
    content.extend([samples_section])

    if config.variables:
        variables_section = HTMLContainer(
            type="box",
            name="Variables",
            container_items=render_dropdown_section(items=render_variables_section(data, config=config), names=list(data.df), config=config)
        )
        content.extend([variables_section])

    if config.visualizations.missing:
        missing_section = render_missing_section(data, config)
        content.extend([missing_section])

    if config.visualizations.correlation:
        correlation_section = render_correlation_section(data.correlation, config)
        content.extend([correlation_section])

    if not config.minimal:
        if config.visualizations.interactions:
            interactions_section = HTMLContainer(
                type="box",
                name="Interactions",
                container_items=[
                    HTMLContainer(
                        type="tabs",
                        container_items=render_interactions_section(data.df, config)
                    )
                ]
            )
            content.extend([interactions_section])
    
    return content