"""
Detailed String Variable Renderer (Bottom Section)

This module defines the 'More details' section for string variables, 
providing length statistics, value samples, and detailed frequency distributions.
"""
import pandas as pd

from ....data.typeset import Text
from ...handler import Handler
from ...renderer import HTMLBase, HTMLContainer, HTMLTable, HTMLVariable, HTMLPlot, HTMLToggle, HTMLCollapse, HTMLDropdown
from ....visuals import plot_to_base64, create_tiny_histogram, create_histogram, create_distribution_plot, create_heatmap, create_interaction_plot


@Handler.register(Text)
def render_bottom_string(data: dict, col_name: str, *args, **kwargs):
    """
    Renders the detailed (collapsible) bottom section for string variables.

    Process Flow:
    1. Builds an 'Overview' tab containing character length stats (min, max, etc.) 
       and a sample of the first few values.
    2. Builds a 'Frequencies' tab with a detailed value frequency distribution table.
    3. Wraps the tabs in an HTMLContainer.

    Args:
        data (dict): The string profiling data.
        col_name (str): The name of the column.

    Returns:
        HTMLContainer: The tabbed container for the detailed string view.
    """

    variable_bottom = [
        HTMLContainer(
            type="default",
            name="Overview",
            id = 'overview',
            container_items= [
                HTMLContainer(type="box",
                              container_items=[
                                HTMLContainer(
                                type = "column",
                                container_items = HTMLTable(
                                    data = {
                                        "Max Length": data['max_length'],
                                        "Median Length": data['median_length'],
                                        "Mean Length": data['mean_length'],
                                        "Minimum Length": data['min_length']

                                    }
                                )
                                ),
                                HTMLContainer(
                                    type ="column",
                                    container_items = HTMLTable(
                                        data = {f"{i+1}st Row" if i == 0 else f"{i+1}nd Row" if i == 1 else f"{i+1}rd Row" if i == 2 else f"{i+1}th Row": value for i, (key, value) in enumerate(data['samples'].items())}
                                    )

                                )
                                            ])]
        ),
        HTMLContainer(
            type="default",
            name="Frequencies",
            id="frequency",
            container_items=[
                HTMLTable(
                    id=f"{col_name}-cat-samples",
                    name='Table',
                    data = data['variable_frequencies'].to_html(classes="table table-sm", border=0, justify='left')
                )
            ]
        )
    ]
    return HTMLContainer(type="tabs",
                         col=col_name,
                         container_items=variable_bottom)