"""
Report Section Renderers

This module defines functions for rendering major logical sections of the report, 
including individual variable summaries, missing data visualizations, 
correlations, and interactive plots.
"""
import pandas as pd

from visions import DateTime, Date

from .renderer import HTMLBase, HTMLContainer, HTMLTable, HTMLVariable, HTMLPlot, HTMLToggle, HTMLCollapse, HTMLDropdown
from .render_types import render_numerical, render_categorical, render_date, render_generic, render_string
from ..data.descriptions import TableDescription
from ..data.typeset import Numeric, Categorical, Text
from ..visuals import plot_to_base64, create_heatmap, create_interaction_plot, create_missing_bar_plot

def render_variable(data: dict, column: str, config:dict):
    """
    Dispatches a variable's summary to the appropriate type-specific renderer.

    Args:
        data (dict): The statistical summary of the variable.
        column (str): The name of the column.
        config (dict): Report configuration.

    Returns:
        Component: The rendered HTML component for the variable.
    """
    if data['type'] == Numeric:
        return render_numerical(data, column, config)
    
    elif data['type'] == Categorical:
        return render_categorical(data, column, config)
    
    elif data['type'] == Date or data['type'] == DateTime:
        return render_date(data, column, config)
    
    elif data['type'] == Text:
        return render_string(data, column, config)
    
    else:
        return render_generic(data, column, config)
    
def render_variables_section(data: TableDescription, config:dict, **kwargs) -> list:
    """
    Renders all variable summaries for the report.

    Args:
        data (TableDescription): The dataset profile.
        config (dict): Report configuration.

    Returns:
        list: A list of rendered variable components.
    """
    vars_list = []

    if config.variables:
        for key, value in data.variables.items():
            variable = render_variable(value, key, config)
            vars_list.append(variable)
    
    return vars_list
    

def render_missing_section(data: TableDescription, config:dict):
    """
    Renders the 'Missing Values' section with a bar plot.

    Args:
        data (TableDescription): The dataset profile.
        config (dict): Report configuration.

    Returns:
        HTMLContainer: The missing values section box.
    """
    if config.visualizations.missing:
        return HTMLContainer(
            type="box",
            name="Missing",
            container_items=[
                HTMLPlot(plot=create_missing_bar_plot(data.df, minimal=config.minimal),
                        type="large",
                        id="missingplot",
                        name="Missing Bar Plot")]
        )

def render_correlation_section(data: pd.DataFrame, config:dict):
    """
    Renders the 'Correlation' section with a heatmap and a raw data table.

    Args:
        data (pd.DataFrame): The correlation matrix.
        config (dict): Report configuration.

    Returns:
        HTMLContainer: The correlation section box with tabs.
    """
    if config.visualizations.correlation:
        return HTMLContainer(
            type="box",
            name="Correlation",
            container_items=[
                HTMLContainer(
                    type="tabs",
                    container_items=[
                        HTMLPlot(plot=create_heatmap(data, minimal=config.minimal),
                                type="large",
                                id="corr",
                                name="Heatmap"),
                        HTMLTable(
                            id='sample',
                            name="Table",
                            data=data.to_html(classes="table table-sm", border=0, justify='left', index=False))
                    ]
                )
            ]
        )

def render_interactions_section(data:pd.DataFrame, config:dict) -> list:
    """
    Renders the 'Interactions' section with scatter plots for numeric column pairs.

    Process Flow:
    1. Selects all numeric non-object columns.
    2. Builds a 2-level tab structure (Primary Variable -> Comparison Variable) 
       where each leaf is an interaction plot.

    Args:
        data (pd.DataFrame): The original dataset.
        config (dict): Report configuration.

    Returns:
        list: A nested tab structure of interaction plots.
    """
    if config.visualizations.interactions:
        df = data.select_dtypes(exclude=['object'])
        outer_tabs = []
        for column in df.columns:
            inner_tabs = []
            for inner_col in df.columns:
                inner_tabs.append(
                    HTMLContainer(
                        type="default",
                        name= inner_col,
                        id = f"{column}-{inner_col}-interaction-inner",
                        container_items = [HTMLPlot(
                            plot= create_interaction_plot(df[inner_col],df[column], minimal=config.minimal),
                            type = "large",
                            name = f"{column}-{inner_col} Interaction Plot",
                            id = f"{column}-{inner_col}_interaction_plot"
                        )]
                    )
                )
            outer_tabs.append(
                HTMLContainer(
                    type="tabs",
                    name = column,
                    id = f"{column}-interaction-outer",
                    container_items = inner_tabs
                )
            )
        return outer_tabs

def render_dropdown_section(items: list, names:list, config:dict, id="variables-dropdown" )-> list:
    """
    Wraps report items into a searchable dropdown component.

    Args:
        items (list): The original list of components.
        names (list): Names to populate in the dropdown menu.
        config (dict): Report configuration.
        id (str): Unique ID for the dropdown.

    Returns:
        list: A list containing the HTMLDropdown component.
    """
    return [
        HTMLDropdown(
        dropdown_items= names,
        dropdown_content= HTMLContainer(
            type="default",
            container_items= items),
        id=id
        )
    ]