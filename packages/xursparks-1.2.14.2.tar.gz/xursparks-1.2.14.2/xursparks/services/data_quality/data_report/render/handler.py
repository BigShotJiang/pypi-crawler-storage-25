"""
Render Handler Registry

This module provides a registration mechanism (decorators) for type-specific 
renderers. It allows the rendering engine to dispatch to the correct 
component based on the Visions data type.
"""
from visions import VisionsBaseType

from typing import Any

class Handler:
    """
    Registry for component-specific render functions.

    Attributes:
        handlers (dict): Mapping of data types to their registered render functions.
        default_handler (callable): Fallback render function if no specific type handler is found.
    """
    handlers = {}
    default_handler = None 

    @classmethod
    def register(cls, keyword):
        """
        Decorator to register a function as a handler for a specific data type.

        Args:
            keyword: The data type or keyword to register the handler for.
        """
        def decorator(func):
            cls.handlers[keyword] = func
            return func
        return decorator

    @classmethod
    def register_default(cls):
        """Decorator to register a function as the default fallback handler."""
        def decorator(func):
            cls.default_handler = func
            return func
        return decorator

    @classmethod
    def render_bottom(cls, type, data, *args, **kwargs):
        """
        Dispatches to the appropriate handler for the given type.

        Args:
            type: The data type.
            data: The data to render.
            *args, **kwargs: Additional arguments for the handler.

        Returns:
            Any: The output of the render function.

        Raises:
            ValueError: If no handler or default handler is found.
        """
        if type in cls.handlers:
            return cls.handlers[type](data, *args, **kwargs)
        elif cls.default_handler is not None: 
            return cls.default_handler(data)
        else:
            raise ValueError(f"No handler registered for {type}")