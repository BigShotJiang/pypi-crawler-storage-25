"""
Empty Dataset Report Rendering

This module provides a simplified renderer for cases where the input dataset is empty.
"""
import pandas as pd
from .renderer import HTMLBase, HTMLContainer, HTMLTable

def render_empty(df: pd.DataFrame, name:str):
    """
    Creates a minimal report body for an empty DataFrame.

    Args:
        df (pd.DataFrame): The empty DataFrame.
        name (str): The name/title of the report.

    Returns:
        List[HTMLContainer]: A list containing the sample section (which will be empty).
    """
    content = [
        HTMLContainer(
            type="box",
            name="Sample",
            container_items=[
                HTMLTable(
                    id = "sample",
                    data=df.to_html(classes="table table-sm", border=0)
                )
            ]
        )
    ]

    return content
