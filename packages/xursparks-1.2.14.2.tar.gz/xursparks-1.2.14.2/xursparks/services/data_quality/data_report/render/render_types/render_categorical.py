"""
Categorical Variable Renderer

This module provides the rendering logic for categorical variables, including 
overview tables and horizontal histograms.
"""
import pandas as pd

from ..renderer import HTMLBase, HTMLTable, HTMLVariable, HTMLPlot, HTMLToggle, HTMLCollapse
from ...visuals import plot_to_base64, create_horizontal_histogram
from .bottom.render_bottom_categorical import render_bottom_categorical


def render_categorical(data: dict, name:str, config:dict)->HTMLBase:
    """
    Renders the HTML component for a categorical variable.

    Process Flow:
    1. Prepares a summary table (distinct, missing, memory).
    2. Generates a horizontal histogram for value frequencies.
    3. Bundles the component with a collapsible 'More details' section.

    Args:
        data (dict): The categorical summary data.
        name (str): The column name.
        config (dict): Report configuration.

    Returns:
        HTMLVariable: The rendered component for the categorical variable.
    """
    name = name.replace(" ", "-").lower()
    table = {
        "Distinct": data['distinct'],
        "Distinct (%)": "{:0.2f}%".format(data['distinct_perc']),
        "Missing": data['missing'],
        "Missing (%)": "{:0.2f}%".format(data["missing_perc"]),
        "Memory size": "{} bytes".format(data['memory'])
    }
    variable_body = {
        'table': HTMLTable(table),
        'plot': HTMLPlot(plot=create_horizontal_histogram(data['histogram_counts'], minimal=config.minimal),
                         type="categorical")
    }

    return HTMLVariable(
        name = name,
        type = data['type'],
        body = variable_body,
        bottom = HTMLCollapse(
            HTMLToggle("More details", name),
            render_bottom_categorical(data,name)
        )
    )