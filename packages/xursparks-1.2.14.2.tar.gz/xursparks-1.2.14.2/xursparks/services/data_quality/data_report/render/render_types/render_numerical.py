"""
Numerical Variable Renderer

This module provides the rendering logic for numeric variables, including 
detailed statistical tables and distribution histograms.
"""
import pandas as pd

from ..handler import Handler
from .bottom.render_bottom_numerical import render_bottom_numerical
from ..renderer import HTMLBase, HTMLContainer, HTMLTable, HTMLVariable, HTMLPlot, HTMLCollapse, HTMLToggle
from ...visuals import plot_to_base64, create_tiny_histogram, create_histogram, create_distribution_plot, create_heatmap, create_interaction_plot

def render_numerical(data: dict, name: str, config:dict)-> HTMLBase:
    """
    Renders the HTML component for a numeric variable.

    Process Flow:
    1. Prepares two overview tables containing metrics like distinct counts, 
       missing values, infinite/zero/negative counts, and mean.
    2. Generates a tiny sparkline-style histogram for the distribution.
    3. Bundles the component with a collapsible 'More details' section.

    Args:
        data (dict): The numeric summary data.
        name (str): The column name.
        config (dict): Report configuration.

    Returns:
        HTMLVariable: The rendered component for the numeric variable.
    """
    name = name.replace(" ", "-").lower()
    overview_1 = {
        "Distinct": data['distinct'],
        "Distinct (%)": "{:0.2f}%".format(data['distinct_perc']),
        "Missing": data['missing'],
        "Missing (%)": "{:0.2f}%".format(data["missing_perc"]),
        "Infinite": data["infinite"],
        "Infinite (%)":"{:0.2f}%".format(data["infinite_perc"]) ,
        "Mean": "{:0.4f}".format(data["mean"])
    }

    overview_2 = {
        "Minimum": data['minimum'],
        "Maximum": data['maximum'],
        "Zeros": data['zeros'],
        "Zeros (%)": "{:0.2f}%".format(data['zeros_perc']),
        "Negative": data['negative'],
        "Negative (%)": "{:0.2f}%".format(data['negative_perc']),
        "Memory size": "{} bytes".format(data['memory']),
    }

    variable_body = {
        'table_1': HTMLTable(overview_1),
        'table_2': HTMLTable(overview_2),
        'plot': HTMLPlot(plot=create_tiny_histogram(data['histogram'], minimal=config.minimal))
    }

    return HTMLVariable(
        name = name,
        type = data['type'],
        body = variable_body,
        bottom=HTMLCollapse(
            HTMLToggle("More details", name),
            render_bottom_numerical(data, name)
        )
    )