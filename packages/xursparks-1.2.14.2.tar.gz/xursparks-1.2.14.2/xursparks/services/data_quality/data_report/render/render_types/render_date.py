"""
Date Variable Renderer

This module provides the rendering logic for date/datetime variables, 
including summary tables with min/max dates and time range.
"""
import pandas as pd

from ..renderer import HTMLBase, HTMLContainer, HTMLTable, HTMLVariable, HTMLPlot, HTMLToggle, HTMLCollapse, HTMLDropdown
from ...visuals import plot_to_base64, create_tiny_histogram, create_histogram, create_distribution_plot, create_heatmap, create_interaction_plot

def render_date(data: dict, name:str, config:dict)->HTMLBase:
    """
    Renders the HTML component for a date/datetime variable.

    Process Flow:
    1. Prepares summary tables (distinct, missing, memory, date range).
    2. Bundles the component with a vertical layout of tables.

    Args:
        data (dict): The date-based summary data.
        name (str): The column name.
        config (dict): Report configuration.

    Returns:
        HTMLVariable: The rendered component for the date variable.
    """
    name = name.replace(" ", "-").lower()
    table_1 = {
        "Distinct": data['distinct'],
        "Distinct (%)": "{:0.2f}%".format(data['distinct_perc']),
        "Missing": data['missing'],
        "Missing (%)": "{:0.2f}%".format(data["missing_perc"]),
        "Memory size": "{} bytes".format(data['memory'])
    }

    table_2 = {
        "Minimum": data['min_date'],
        "Maximum": data['max_date'],
        "Time range": f"{data['time_range']} days"
    }

    variable_body = {
        'table_1': HTMLTable(table_1),
        'table_2': HTMLTable(table_2),
        #'plot': HTMLPlot(plot=create_tiny_histogram(data['histogram'], minimal=config.minimal))
    }

    return HTMLVariable(
        name = name,
        type = data['type'],
        body = variable_body
    )