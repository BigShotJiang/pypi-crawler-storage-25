from visions import Date

from ...handler import Handler
from ...renderer import HTMLBase, HTMLContainer, HTMLTable, HTMLVariable, HTMLPlot, HTMLToggle, HTMLCollapse, HTMLDropdown
from ....visuals import plot_to_base64, create_tiny_histogram, create_histogram, create_distribution_plot, create_heatmap, create_interaction_plot

@Handler.register(Date)
def render_bottom_categorical(data, *args, **kwargs):
    return HTMLContainer(type="default")