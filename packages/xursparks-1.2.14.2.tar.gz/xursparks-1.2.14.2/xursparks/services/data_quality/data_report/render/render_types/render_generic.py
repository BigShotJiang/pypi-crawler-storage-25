"""
Generic Variable Renderer

This module provides the fallback rendering logic for variables with unknown 
or generic data types, displaying basic statistical metrics.
"""
from ..renderer import HTMLBase, HTMLVariable, HTMLTable

def render_generic(data: dict, name: str, config: dict):
    """
    Renders the HTML component for a generic variable.

    Args:
        data (dict): The summary data (distinct, missing, memory).
        name (str): The column name.
        config (dict): Report configuration.

    Returns:
        HTMLVariable: The rendered component for the generic variable.
    """
    name = name.replace(" ", "-").lower()
    table = {
        "Distinct": data['distinct'],
        "Distinct (%)": "{:0.2f}%".format(data['distinct_perc']),
        "Missing": data['missing'],
        "Missing (%)": "{:0.2f}%".format(data["missing_perc"]),
        "Memory size": "{} bytes".format(data['memory'])
    }

    variable_body = {
        'table': HTMLTable(table)
    }
    return HTMLVariable(
        name = name,
        type = data['type'],
        body = variable_body
    )