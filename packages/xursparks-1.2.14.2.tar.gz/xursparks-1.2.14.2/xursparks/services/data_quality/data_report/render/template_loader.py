"""
Jinja2 Template Loader

This module initializes the Jinja2 environment and provides a helper function 
to retrieve report templates from the package directory.
"""
import warnings
from typing import Any

import jinja2
from jinja2 import Environment, PackageLoader, select_autoescape

# Initialize jinja environment pointing to the templates directory
env = Environment(loader=PackageLoader("xursparks.services.data_quality.data_report", "render/templates"))

def template(template_name: str) -> jinja2.Template:
    """
    Retrieves a Jinja2 template by name.

    Args:
        template_name (str): The name of the template file (e.g., 'table.html').

    Returns:
        jinja2.Template: The loaded Jinja2 template object.

    Warnings:
        Issues a warning if the file extension '.html' is missing and auto-appends it.
    """
    if not template_name.endswith('.html'):
        warnings.warn(f"Template {template_name} does not have the correct file extension '.html'! adding '.html' to template name", stacklevel=2)
        template_name += ".html"

    return env.get_template(template_name)
