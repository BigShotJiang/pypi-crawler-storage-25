"""
Detailed Numerical Variable Renderer (Bottom Section)

This module defines the 'More details' section for numeric variables, 
providing exhaustive quantile and descriptive statistics, as well as large histograms.
"""
from ....data.typeset import Numeric
from ...handler import Handler
from ...renderer import HTMLBase, HTMLContainer, HTMLTable, HTMLVariable, HTMLPlot, HTMLToggle, HTMLCollapse, HTMLDropdown
from ....visuals import plot_to_base64, create_tiny_histogram, create_histogram, create_distribution_plot, create_heatmap, create_interaction_plot


@Handler.register(Numeric)
def render_bottom_numerical(data: dict, col_name: str, *args, **kwargs):
    """
    Renders the detailed (collapsible) bottom section for numeric variables.

    Process Flow:
    1. Prepares quantile statistics (min, max, median, quartiles, IQR).
    2. Prepares descriptive statistics (std dev, skew, CV, monotonicity).
    3. Builds an 'Overview' tab containing both statistical tables.
    4. Builds a 'Histogram' tab with a large frequency plot.
    5. Wraps the tabs in an HTMLContainer.

    Args:
        data (dict): The numeric profiling data.
        col_name (str): The name of the column.

    Returns:
        HTMLContainer: The tabbed container for the detailed numeric view.
    """
    def format_value(value):
        try:
            return "{:.2f}".format(value)
        except Exception as e:
            print(e)
            return value

    quantile_statistics = {
        "Minimum": data['quantile_stats']['minimum'],
        "Fifth (5th) Percentile": data['quantile_stats']['5th_percentile'],
        "First Quartile (Q1)":data['quantile_stats']['Q1'],
        "Median": data['quantile_stats']['median'],
        "Ninety-Fifth (95th) Percentile": data['quantile_stats']["95th_percentile"],
        "Maximum": data['quantile_stats']['maximum'],
        "Range": data['quantile_stats']['range'],
        "Interquartile Range (IQR)": data['quantile_stats']['IQR']
    }

    descriptive_statistics = {
        "Standard Deviation": format_value(data['descriptive_stats']['std_dev']),
        "Mean": format_value(data['descriptive_stats']["mean"]),
        "Coefficient of Variation (CV)": format_value(data['descriptive_stats']["CV"]),
        "Kurtosis": format_value(data['descriptive_stats']['kurtosis']),
        "Mean Absolute Deviation": format_value(data['descriptive_stats']["MAD"]),
        "Skew": format_value(data['descriptive_stats']['skew']),
        "Sum": format_value(data['descriptive_stats']['sum']),
        "Variance": format_value(data['descriptive_stats']['variance']),
        "Monotonicity": data['descriptive_stats']["monotonicity"]
    }


    variable_bottom = [
        HTMLContainer(
            type="box",
            name="Overview",
            container_items=[HTMLContainer(
                type="default",
                name="Statistics",
                id="stats",
                container_items=[
                    HTMLContainer(
                        type = "column",
                        container_items = HTMLTable(
                            data = quantile_statistics,
                            name = 'Quantile Statistics')
                    ),
                    HTMLContainer(
                        type = "column",
                        container_items = HTMLTable(
                            data = descriptive_statistics,
                            name = 'Descriptive Statistics'
                        )
                    )
                ]
            )]
        ),
        HTMLPlot(
            name="Histogram",
            type="large",
            id="histo",
            plot=plot_to_base64(create_histogram(data['histogram']))
        )
    ]

    return HTMLContainer(
        type="tabs",
        col=col_name,
        container_items=variable_bottom
    )