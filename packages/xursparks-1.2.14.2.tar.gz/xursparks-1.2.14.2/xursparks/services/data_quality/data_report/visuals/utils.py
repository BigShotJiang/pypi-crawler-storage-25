"""
Visualization Utilities

This module provides decorators and helper functions for handling plot errors 
and converting Matplotlib figures into base64-encoded strings for HTML embedding.
"""
import io
import base64
import matplotlib.pyplot as plt

def error_handler(func):
    """
    Decorator to gracefully handle errors during plot generation.
    Returns an empty plot if an exception occurs.
    """
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            print(f"Error in creating plot: {e}")
            fig, ax = plt.subplots()
            ax.set(frame_on=False)
            ax.set_yticks([])
            ax.set_xticks([])
            return fig

    return wrapper


def plot_to_base64_method(fig: plt.Figure, minimal: bool = False):
    """
    Converts a Matplotlib figure to a base64-encoded SVG string for HTML embedding.

    Args:
        fig (plt.Figure): The Matplotlib figure object.
        minimal (bool): Whether to use a lower DPI for a smaller file size.

    Returns:
        str: Base64-encoded SVG data URI.
    """
    buf = io.BytesIO()
    
    if minimal:
        fig.savefig(buf, format="svg", bbox_inches='tight', dpi=80)
    else:    
        fig.savefig(buf, format="svg", bbox_inches='tight')
    
    plt.close(fig)

    data = base64.b64encode(buf.getvalue()).decode("utf8")
    buf.close()
    return "data:image/svg+xml;base64,{}".format(data)

def plot_to_base64(func):
    """
    Decorator that automatically converts a function's returned plt.Figure 
    into a base64-encoded string.
    """
    def wrapper(*args, **kwargs):
        fig = func(*args, **kwargs)
        minimal = kwargs.get('minimal', False)
        return plot_to_base64_method(fig, minimal)
    return wrapper