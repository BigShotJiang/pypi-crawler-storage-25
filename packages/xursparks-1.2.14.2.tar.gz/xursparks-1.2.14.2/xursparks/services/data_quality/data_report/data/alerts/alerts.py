"""
Data Quality Alerts System

This module defines the alerting logic for the data quality report. It includes 
an enumeration of alert types, a base Alert class, and specialized alert subclasses 
for different data quality issues (missing values, duplicates, etc.).
"""
from enum import Enum, auto, unique
from typing import Optional, List
from ..typeset import Numeric

@unique
class AlertType(Enum):
    """Enumeration of all supported data quality alert types."""
    CONSTANT = auto()
    ZEROS = auto()
    HIGH_CORRELATION = auto()
    HIGH_CARDINALITY = auto()
    IMBALANCE = auto()
    SKEWNESS = auto()
    MISSING_VALUES = auto()
    INFINITE_VALUES = auto()
    DATE = auto()
    UNIFORM = auto()
    UNIQUE = auto()
    CONSTANT_LENGTH = auto()
    REJECTED = auto()
    UNSUPPORTED = auto()
    DUPLICATES = auto()
    EMPTY = auto()

class Alert:
    """
    Base class for data quality alerts.

    Attributes:
        alert_type (AlertType): The category of the alert.
        column_name (str): The column the alert refers to.
        values (dict): Relevant statistical metrics related to the alert.
    """
    def __init__(
            self,
            alert_type: AlertType,
            values: Optional[dict] = None,
            column_name: Optional[str] = None,
            fields: Optional[set] = None
    ):
        """Initializes a generic alert."""
        self.alert_type = alert_type
        self.column_name = column_name
        self.values = values

    @property
    def alert_name(self) -> str:
        """Returns the human-readable name of the alert type."""
        return self.alert_type.name
    
    def _get_description(self) -> str:
        """Generates a text description of the alert."""
        return "{} on column: {}".format(self.alert_name, self.column_name)
    
    def __repr__(self):
        return self._get_description()
    
class ConstantAlert(Alert):
    """Alert triggered when a column has only one unique value."""
    def __init__(self, values: Optional[dict] = None, column_name: Optional[str] = None ):
        super().__init__(
            alert_type= AlertType.CONSTANT,
            values=values,
            column_name=column_name,
            fields={'distinct', 'distinct_perc'},
        )
    
    def _get_description(self) -> str:
        return f"[{self.column_name}] has a constant value"
    
class DuplicatesAlert(Alert):
    """Alert triggered when a dataset contains duplicate rows."""
    def __init__(self, values: Optional[dict] = None, column_name: Optional[str] = None ):
        super().__init__(
            alert_type= AlertType.DUPLICATES,
            values=values,
            column_name=column_name,
            fields={'duplicate_rows', 'duplicate_rows_perc'},
        )
    
    def _get_description(self) -> str:
        return f"[{self.column_name}] has duplicate rows"
    
class InfiniteAlert(Alert):
    """Alert triggered when a numeric column contains infinite values."""
    def __init__(self, values: Optional[dict] = None, column_name: Optional[str] = None ):
        super().__init__(
            alert_type= AlertType.INFINITE_VALUES,
            values=values,
            column_name=column_name,
            fields={'infinite', 'infinite_perc'},
        )
    
    def _get_description(self) -> str:
        return f"[{self.column_name}] has infinite values"
    
class MissingAlert(Alert):
    """Alert triggered when a column contains missing (NaN) values."""
    def __init__(self, values: Optional[dict] = None, column_name: Optional[str] = None ):
        super().__init__(
            alert_type= AlertType.MISSING_VALUES,
            values=values,
            column_name=column_name,
            fields={'zeros', 'zeros_perc'},
        )
    
    def _get_description(self) -> str:
        return f"[{self.column_name}] contains missing values"
    
class UniqueAlert(Alert):
    """Alert triggered when all values in a column are unique (High Cardinality)."""
    def __init__(self, values: Optional[dict] = None, column_name: Optional[str] = None ):
        super().__init__(
            alert_type= AlertType.UNIQUE,
            values=values,
            column_name=column_name,
            fields={'zeros', 'zeros_perc'},
        )
    
    def _get_description(self) -> str:
        return f"[{self.column_name}] values are all unique"
    
class ZerosAlert(Alert):
    """Alert triggered when a numeric column contains zero values."""
    def __init__(self, values: Optional[dict] = None, column_name: Optional[str] = None ):
        super().__init__(
            alert_type= AlertType.ZEROS,
            values=values,
            column_name=column_name,
            fields={'zeros', 'zeros_perc'},
        )

    def _get_description(self) -> str:
        return f"[{self.column_name}] contains zeros"
    

def get_overview_alerts(dataset_stats: dict) -> List[Alert]:
    """
    Identifies alerts based on aggregate dataset statistics.

    Args:
        dataset_stats (dict): Global metrics for the dataset.

    Returns:
        List[Alert]: A list of detected overview-level alerts.
    """
    alerts = []
    
    if dataset_stats['duplicate_rows'] > 0:
        alerts.append(DuplicatesAlert)

    return alerts

def get_general_alerts(series_description: dict) -> List[Alert]:
    """
    Identifies common alerts applicable to any data type.

    Args:
        series_description (dict): Statistical summary for a series.

    Returns:
        List[Alert]: A list of detected general alerts.
    """
    alerts = []

    if series_description['distinct'] > 0:
        alerts.append(ConstantAlert)

    if series_description['distinct_perc'] == 100:
        alerts.append(UniqueAlert)

    if series_description['missing'] > 0:
        alerts.append(MissingAlert)
    
    return alerts

def get_numerical_alerts(series_description: dict) -> List[Alert]:
    """
    Identifies alerts specific to numerical data types.

    Args:
        series_description (dict): Statistical summary for a numeric series.

    Returns:
        List[Alert]: A list of detected numerical alerts.
    """
    alerts = []

    if series_description['infinite'] > 0:
        alerts.append(InfiniteAlert)
    if series_description['zeros'] > 0:
        alerts.append(ZerosAlert)

    return alerts

def get_variable_alerts(col_name: str, series_description: dict) -> List[Alert]:
    """
    Consolidates all alerts (general and type-specific) for a specific column.

    Args:
        col_name (str): The name of the column.
        series_description (dict): The summary dictionary for the column.

    Returns:
        List[Alert]: A fully initialized list of alerts for the column.
    """
    alerts = []
    
    alerts.extend(get_general_alerts(series_description))

    if series_description['type'] == Numeric:
        alerts.extend(get_numerical_alerts(series_description))

    for i, alert in enumerate(alerts):
        alerts[i].column_name = col_name
        alerts[i].values = series_description

    return alerts

def get_alerts(dataset_stats: dict, series_descriptions: dict) -> List[Alert]:
    """
    High-level orchestration function to collect all alerts for a report.

    Process Flow:
    1. Collects dataset-wide alerts (e.g., duplicates).
    2. Iterates through all columns and collects variable-level alerts.

    Args:
        dataset_stats (dict): Overview metrics.
        series_descriptions (dict): Mapping of column names to statistical profiles.

    Returns:
        List[Alert]: A comprehensive list of all data quality alerts.
    """
    alerts = []

    alerts.extend(get_overview_alerts(dataset_stats))

    for column_name, values in series_descriptions.items():
        alerts.extend(get_variable_alerts(column_name, values))

    return alerts