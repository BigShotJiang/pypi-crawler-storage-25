"""
Custom Data Types and Type Inference System

This module defines custom Visions types (Numeric, Text, Categorical) and a 
centralized typeset (XTypeSet) for inferring column data types during profiling.
"""
import warnings
from typing import Callable, Sequence, Set

from visions import create_type, VisionsBaseType
from visions import DateTime, Date, Generic
from visions.relations import IdentityRelation, InferenceRelation,TypeRelation
from visions.typesets import StandardSet, VisionsTypeset

import pandas as pd
from pandas.api import types as pdt

warnings.filterwarnings("ignore", category=UserWarning, module='visions.typesets.typeset')

class Numeric(VisionsBaseType):
    """Visions type representing numeric data (integers, floats)."""

    @staticmethod
    def get_relations() -> Sequence[TypeRelation]:
        """Defines the relationship between Numeric and Generic types."""
        return [IdentityRelation(Generic)]
    
    @classmethod
    def contains_op(cls, series: pd.Series, state:dict)->bool:
        """Checks if a series contains numeric data."""
        return pdt.is_numeric_dtype(series)
    
class Text(VisionsBaseType):
    """Visions type representing textual/object data."""

    @staticmethod
    def get_relations() -> Sequence[TypeRelation]:
        """Defines the relationship between Text and Generic types."""
        return [IdentityRelation(Generic)]
    
    @classmethod
    def contains_op(cls, series: pd.Series, state:dict) ->bool:
        """Checks if a series contains textual data."""
        series = series.dropna()
        return pdt.is_object_dtype(series)

def numeric_is_category(series: pd.Series, state: dict) -> bool:
    """Heuristic to determine if a numeric series should be treated as categorical."""
    n_unique = series.nunique()
    threshold = 5
    return 1 <= n_unique <= threshold

def string_is_category(series: pd.Series, state: dict) -> bool:
    """Heuristic to determine if a string series should be treated as categorical."""
    n_unique = series.nunique()
    unique_threshold = 0.5
    threshold = 50
    return (
        1 <= n_unique <= threshold and (n_unique / series.size) < unique_threshold
    )

def to_category(series: pd.Series, state: dict) -> pd.Series:
    """Transformer function to cast a series to the categorical data type."""
    return series.astype("category")

class Categorical(VisionsBaseType):
    """Visions type representing categorical data."""

    @staticmethod
    def get_relations() -> Sequence[TypeRelation]:
        """Defines inference relations from Numeric and Text to Categorical."""
        return [
            IdentityRelation(Generic),
            InferenceRelation(
                Numeric,
                relationship=lambda x, y: numeric_is_category(x,y),
                transformer=to_category,
            ),
            InferenceRelation(
                Text,
                relationship=lambda x, y: string_is_category(x,y),
                transformer=to_category,
            ),
        ]

    @staticmethod
    def contains_op(series: pd.Series, state: dict) -> bool:
        """Checks if a series is natively or can be inferred as categorical."""
        series = series.dropna()
        is_valid_dtype = pdt.is_categorical_dtype(series)
        if is_valid_dtype:
            return True
        return False

class XTypeSet(VisionsTypeset):
    """
    The central typeset used by Xursparks for data profiling.
    
    Includes Generic, Numeric, Categorical, Text, and DateTime types.
    """
    def __init__(self):
        """Initializes the typeset with a predefined list of Visions types."""
        types = {
            Generic,
            Numeric,
            Categorical,
            Text,
            DateTime,
            }
        super().__init__(types)




