"""
Correlation Utilities

This module computes correlation matrices for numeric columns in a dataset.
"""
import pandas as pd

def get_correlations(df: pd.DataFrame) -> dict:
    """
    Calculates the correlation matrix for all numeric columns.

    Args:
        df (pd.DataFrame): The dataset to analyze.

    Returns:
        dict: A rounded correlation matrix (3 decimal places).
    """
    return df.corr(numeric_only=True).round(3)