"""
Summary Calculation Algorithms

This module provides specialized algorithms for computing statistical summaries 
for data profiling, such as histograms and percentage calculations.
"""
import numpy as np
import pandas as pd


def compute_histogram(series: pd.Series,
                      name: str = "histogram") -> dict:
    """
    Computes a histogram for a numeric Pandas Series.

    Process Flow:
    1. Determines optimal bin edges using NumPy.
    2. Calculates frequency counts per bin.

    Args:
        series (pd.Series): The data to bin.
        name (str, optional): The key name for the result in the summary dict.

    Returns:
        dict: A dictionary containing the computed histogram (counts and bins).
    """
    summary = {}
    if len(series) == 0:
        return {name: []}
    
    bins = np.histogram_bin_edges(series, bins='auto')
    summary[name] = np.histogram(series, bins=bins)
    return summary

def get_percentage(divisor: int, dividend: int) -> float:
    """
    Safely calculates percentage with zero-division protection.

    Args:
        divisor (int): The part.
        dividend (int): The whole.

    Returns:
        float: The calculated percentage (0.0 if dividend is 0).
    """
    if dividend != 0:
        return (divisor / dividend) * 100
    else:
        return 0