"""
Dataframe Management and Loading Utilities

This module provides functions for loading datasets from various file formats 
(CSV, Excel, Parquet, ORC), sampling data for performance, and converting 
Spark DataFrames to Pandas.
"""
import os
import warnings

import pandas as pd
from pyspark.sql.types import StringType
from pyspark.sql.functions import to_timestamp
from pyspark.sql.functions import year, col

from ..config import Settings

def load_csv(file_path: str, **kwargs) -> pd.DataFrame:
    """Loads a CSV file into a Pandas DataFrame."""
    return pd.read_csv(file_path)

def load_excel(file_path: str, **kwargs) -> pd.DataFrame:
    """Loads an Excel file into a Pandas DataFrame."""
    return pd.read_excel(file_path, **kwargs)

def load_parquet(file_path: str, **kwargs) -> pd.DataFrame:
    """Loads a Parquet file into a Pandas DataFrame."""
    return pd.read_parquet(file_path, **kwargs)

def load_orc(file_path: str, **kwargs) -> pd.DataFrame:
    """Loads an ORC file into a Pandas DataFrame."""
    return pd.read_orc(file_path, **kwargs)

def sample_dataframe(df: pd.DataFrame, config: Settings):
    """
    Returns a sample of the dataframe based on configuration.

    Process Flow:
    1. Checks if auto-sampling is enabled.
    2. If auto is ON, samples only if the dataset length exceeds the threshold.
    3. If auto is OFF, samples according to the configured size.

    Args:
        df (pd.DataFrame): The dataframe to sample.
        config (Settings): Configuration settings containing sampling rules.

    Returns:
        tuple: (sampled_df (pd.DataFrame), description (str|None))
    """

    if config.sampling.auto:
        if df.shape[0] > config.sampling.auto_length:
            sampled_df = df.sample(frac=config.sampling.size)
            description = f"Report created with a sample of {config.sampling.size*100}% of the data"
        else:
            sampled_df = df
            description = None
    else:
        sampled_df = df.sample(frac=config.sampling.size)
        description = f"Report created with a sample of {config.sampling.size*100}% of the data"

    return sampled_df, description

def validate_dataframe(df: pd.DataFrame, config: Settings) -> bool:
    """
    Validates if a dataframe is suitable for report generation.

    Args:
        df (pd.DataFrame): The dataframe to validate.
        config (Settings): Configuration settings.

    Returns:
        bool: False if the dataframe is empty, True otherwise.
    """
    if df.empty:
        warnings.warn("DataFrame is empty! Generating Empty Report")
        return False
    else:

        return True

def load_dataframe(file_path: str) -> pd.DataFrame:
    """
    Loads a dataset from the filesystem based on file extension.

    Process Flow:
    1. Extracts the file extension.
    2. Dispatches the loading task to the appropriate format-specific loader.

    Args:
        file_path (str): The path to the file.

    Returns:
        pd.DataFrame: The loaded dataset.

    Raises:
        ValueError: If the file format is unsupported.
    """
    load_methods = {
    '.csv': load_csv,
    '.xlsx': load_excel,
    '.parquet': load_parquet,
    '.orc': load_orc
    }
    # Get the file extension
    _, file_extension = os.path.splitext(file_path)
    
    # Get the loading method from the dictionary
    load_method = load_methods.get(file_extension)
    
    # If the loading method exists, call it, else raise an error
    if load_method:
        return load_method(file_path)
    else:
        raise ValueError(f'Unsupported file format: {file_extension}')

def convert_to_pandas(spark_df) -> pd.DataFrame:
    """
    Converts a Spark DataFrame to a Pandas DataFrame with error handling for timestamps.

    Process Flow:
    1. Attempts a standard `toPandas()` conversion.
    2. If a `OutOfBoundsDatetime` error occurs, identifies timestamp columns.
    3. Casts problematic timestamps to strings or clips them to valid ranges.
    4. Re-attempts the conversion.

    Args:
        spark_df (DataFrame): The Spark DataFrame to convert.

    Returns:
        pd.DataFrame: The converted Pandas DataFrame.
    """
    try:
        df = spark_df.toPandas()


    except pd.errors.OutOfBoundsDatetime as e:
        print(f"ERROR: {e}")
        for column, dtype in spark_df.dtypes:
            print(f"{column}: {dtype}")
            if dtype =='timestamp':
                spark_df = spark_df.withColumn(column, spark_df[column].cast(StringType()))
                spark_df = spark_df.withColumn(column, to_timestamp(spark_df[column], 'yyyy-MM-dd HH:mm:ss'))

        try:
            df = spark_df.toPandas()

        except:
            for column, col_dtype in spark_df.dtypes:
                if str(col_dtype) == "timestamp":
                    filtered_df = spark_df.filter(year(col(column)) >= 2262)

            df = filtered_df.toPandas()

    return df

    
