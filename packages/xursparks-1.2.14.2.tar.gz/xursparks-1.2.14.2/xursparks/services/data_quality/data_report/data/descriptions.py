"""
Dataset Profile Data Structures

This module defines the data structures (dataclasses) used to store 
comprehensive descriptions and comparative metrics of datasets.
"""
from dataclasses import dataclass
from typing import Any, Dict, Optional, List

import pandas as pd

@dataclass
class TableDescription:
    """
    Data structure representing a complete statistical profile of a dataset.
    
    Attributes:
        df (pd.DataFrame): The original or sampled dataset.
        description (str): Custom description or metadata for the dataset.
        dataset_statistics (Dict): Aggregate metrics (memory, duplicates, etc.).
        correlation (pd.DataFrame): Correlation matrix for numeric fields.
        alerts (List[str]): Data quality warnings and observations.
        variable_types (Dict): Count of variables by their data types.
        variables (Optional[Dict]): Detailed summaries for each column.
        comparison (Dict): Comparative metrics if compared against other tables.
        shared_values (List[int]): Values shared with other datasets in a comparison.
    """
    df: pd.DataFrame = None
    description: str = None
    dataset_statistics: Dict = None
    correlation: pd.DataFrame = None
    alerts: List[str] = None
    variable_types: Dict = None
    variables: Optional[Dict] = None
    comparison: Dict = None
    shared_values: List[int] = None

@dataclass
class ComparisonDescription:
    """
    Data structure representing metrics for multi-dataset comparison.
    
    Attributes:
        df (List[pd.DataFrame]): List of datasets involved in the comparison.
        value_count (List[int]): Total row counts for each dataset.
        distinct_count (List[int]): Unique value counts for each dataset.
        shared_values (List[int]): Values common to all datasets in the group.
    """
    df: List[pd.DataFrame]
    value_count: List[int]
    distinct_count: List[int]
    shared_values: List[int]