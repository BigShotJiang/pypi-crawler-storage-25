"""
Series Description Utilities

This module provides functions to generate statistical profiles for individual 
Pandas Series. It handles type inference and dispatches to the appropriate 
profiling logic.
"""
import pandas as pd

from typing import Tuple

from . import Describer, XTypeSet


def describe_series(col_name: str, series: pd.Series, data_types:dict=None)->Tuple[str, dict]:
    """
    Computes a comprehensive statistical profile for a single Series.

    Process Flow:
    1. Determines the data type of the series (either user-provided or inferred).
    2. Uses the `Describer` to apply type-specific profiling functions.
    3. Returns the column name along with its aggregated summary.

    Args:
        col_name (str): The name of the column/series.
        series (pd.Series): The actual data to analyze.
        data_types (dict, optional): Manual type overrides for columns.

    Returns:
        Tuple[str, dict]: A tuple containing the column name and its summary dictionary.
    """
    describer = Describer()
    if data_types is not None and col_name in data_types:
        series_type = data_types[col_name]

    else:
        typeset = XTypeSet()
        series_type = typeset.infer_type(series)

    series_description = describer.summarize(dtype=series_type, series=series)
    series_description.update({'type': series_type})

    return col_name, series_description

def get_series_descriptions(df: pd.DataFrame, data_types: dict=None)-> dict:
    """
    Generates statistical profiles for all columns in a DataFrame.

    Process Flow:
    1. Iterates through each column in the DataFrame.
    2. Dispatches each column to `describe_series` for profiling.
    3. Consolidates all individual profiles into a single dictionary.

    Args:
        df (pd.DataFrame): The dataset to describe.
        data_types (dict, optional): Manual type overrides for specific columns.

    Returns:
        dict: A mapping of column names to their statistical profiles.
    """
    descriptions = {}
    for name, series in df.items():

        col_name, series_description = describe_series(name, series, data_types)
        descriptions.update({col_name: series_description})

        
    return descriptions
