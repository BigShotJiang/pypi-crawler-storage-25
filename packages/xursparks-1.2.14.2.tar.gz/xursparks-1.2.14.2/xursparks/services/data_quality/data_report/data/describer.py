"""
Variable Feature Profiler

This module defines the Describer class, which maps data types to specific 
statistical profiling functions (e.g., numeric statistics for Numeric types).
"""
import pandas as pd

from dataclasses import dataclass
from visions import VisionsTypeset, Generic, Date, DateTime
from typing import Dict, List, Callable, Optional

from .type_descriptions import describe_numeric, describe_categorical, describe_generic, describe_date, describe_string
from .typeset import Numeric, Categorical, Text


class Describer():
    """
    Managed mapping of data types to profiling functions.

    Attributes:
        mapping (dict): A dictionary where keys are Visions types and values 
                        are lists of functions to apply to a Series of that type.
    """

    def __init__(self, 
                type_mapping: Dict[str, List[Callable]] = {
                     Generic : [
                         describe_generic,
                     ],
                     Numeric : [
                         describe_generic,
                         describe_numeric
                     ],
                     Categorical : [
                         describe_generic,
                         describe_categorical
                     ],
                     Date: [
                        describe_generic,
                        describe_date
                     ],
                     DateTime: [
                        describe_generic,
                        describe_date
                     ],
                     Text: [
                         describe_generic,
                         describe_string
                     ]}):
        """
        Initializes the Describer with a type-to-function mapping.

        Args:
            type_mapping (dict, optional): Custom mapping of Visions types to profiling functions.
        """
        self.mapping = type_mapping
    
    def summarize(self, dtype, series, **kwargs)-> dict:
        """
        Applies all applicable profiling functions to a Series.

        Process Flow:
        1. Identifies the profiling functions mapped to the provided data type.
        2. Iteratively applies each function, aggregating the results into a single summary dictionary.
        3. Falls back to generic profiling if the specific type is unknown.

        Args:
            dtype: The Visions data type of the series.
            series (pd.Series): The data to summarize.

        Returns:
            dict: The aggregated statistical summary.
        """
        # give the series and typeset
        # for every applicable type apply the function to the series
        # update the summary dict with the new
        summary = {}
        if dtype in self.mapping:
            for func in self.mapping[dtype]:
                summary.update(func(series,summary))
        else:
            for func in self.mapping[Generic]:
                summary.update(func(series,summary))

        return summary
