"""
Data Package Utility Functions

This module provides helper functions for data type mapping and column validation 
during the report generation process.
"""
import pandas as pd

from .typeset import XTypeSet

def check_dtypes(dtypes: dict) -> dict:
    """
    Maps string-based data type names to their corresponding Visions type classes.

    Args:
        dtypes (dict): A dictionary mapping column names to type names (strings).

    Returns:
        dict: The updated dictionary with Visions type classes as values.
    """
    dtypes_mapping = {value.__name__: value for value in XTypeSet.types}

    for key, value in dtypes.items():
        if value in dtypes_mapping:
            dtypes[key] = dtypes_mapping[value]

    return dtypes

def check_col_names(dtypes: dict, cols: pd.Index) -> dict:
    """
    Validates that the column names provided in the data types dictionary exist in the dataset.

    Args:
        dtypes (dict): The data types mapping to validate.
        cols (pd.Index): The actual columns present in the DataFrame.

    Returns:
        dict: The original dictionary if all columns are valid.

    Raises:
        ValueError: If a provided column name is not found in the dataset.
    """
    for key in dtypes.keys():
        if key not in cols:
            raise ValueError(f'{key} is not a column in the given dataset!')
        
    return dtypes