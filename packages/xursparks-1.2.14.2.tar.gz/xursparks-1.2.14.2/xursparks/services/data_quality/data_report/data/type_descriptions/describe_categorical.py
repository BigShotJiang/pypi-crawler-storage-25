"""
Categorical Data Profiling

This module provides functions to describe categorical (string) data, including 
length statistics, uniqueness, and frequency distributions.
"""
import pandas as pd
import numpy as np

from typing import  Dict, Tuple

def get_samples(series: pd.Series) -> dict:
    """
    Extracts a sample of the first five values from the series.

    Args:
        series (pd.Series): The categorical data.

    Returns:
        dict: A dictionary of sampled values.
    """
    first_five = series.head(5)

    series_samples = {f"row_{value}": value for value in first_five }

    return series_samples

def get_cat_counts(series:pd.Series) -> pd.DataFrame:
    """
    Computes frequency counts and percentages for each category.

    Args:
        series (pd.Series): The categorical data.

    Returns:
        pd.DataFrame: A DataFrame with 'Counts' and 'Percentages' per category.
    """
    counts = series.value_counts()
    percent = series.value_counts(normalize=True)*100
    percent = percent.map("{:.2f}%".format)

    return pd.DataFrame({'Counts': counts, 'Percentages': percent})

def describe_categorical(series: pd.Series, summary: Dict) ->  Dict:
    """
    Describes a categorical series and updates the summary dictionary.

    Process Flow:
    1. Casts the series to string and computes character length statistics (max, min, median, mean).
    2. Calculates uniqueness metrics based on previous value counts.
    3. Collects samples and category frequency counts.

    Args:
        series (pd.Series): The categorical series to analyze.
        summary (dict): The summary dictionary to be updated.

    Returns:
        dict: The updated summary dictionary.
    """
    # make sure that the series has no numbers
    series = series.astype('string')

    max_length = series.str.len().max()
    min_length = series.str.len().min()
    median_length = series.str.len().median()
    mean_length = series.str.len().mean()
    unique = sum(summary['value_counts']==1)
    unique_perc = unique/len(summary['value_counts'])*100
    sample = get_samples(series)
    cat_counts = get_cat_counts(series)

    summary.update({
        "max_length": max_length,
        "min_length": min_length,
        "median_length": median_length,
        "mean_length": mean_length,
        "unique": unique,
        "unique_perc": unique_perc,
        "histogram_counts": series.value_counts().to_dict(),
        "samples": sample,
        "cat_counts": cat_counts
    })


    return summary