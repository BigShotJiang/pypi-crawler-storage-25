"""
Date Data Profiling

This module provides functions to describe date and datetime series, 
calculating range metrics and frequency distributions.
"""
import pandas as pd

from typing import Tuple

def describe_date(series: pd.Series, summary: dict)-> dict:
    """
    Describes a date-based series and updates the summary.

    Process Flow:
    1. Removes NaN values.
    2. Calculates minimum, maximum, and median dates.
    3. Computes the overall time range in days.
    4. Collects frequency counts for each date.

    Args:
        series (pd.Series): The date/datetime data to analyze.
        summary (dict): The summary dictionary to update.

    Returns:
        dict: The updated summary dictionary.
    """
    series = series.dropna()
    min_date = pd.to_datetime(series.min())
    max_date = pd.to_datetime(series.max())
    med_date = pd.to_datetime(min_date + (max_date-min_date))
    time_range = (max_date - min_date).days
    histogram_counts = series.value_counts().to_dict()
    summary.update(
            {'min_date': min_date,
             'median_date': med_date,
            'max_date': max_date,
            'time_range': time_range,
            'histogram_counts':histogram_counts})
    
    return summary
