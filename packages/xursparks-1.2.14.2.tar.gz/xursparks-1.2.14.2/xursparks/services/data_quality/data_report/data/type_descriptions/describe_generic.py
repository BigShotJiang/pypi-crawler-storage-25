"""
Generic Data Profiling

This module provides base profiling functions that are applicable to any 
data type, such as counting distinct values, missing cells, and memory usage.
"""
import pandas as pd

from typing import Tuple

def describe_generic(series: pd.Series, summary: dict) -> dict:
    """
    Computes universal statistical metrics for any Series.

    Process Flow:
    1. Calculates total row counts and distinct values.
    2. Identifies missing (null) values and calculates percentages.
    3. Computes memory usage of the series.
    4. Aggregates these metrics into the summary dictionary along with value counts.

    Args:
        series (pd.Series): The dataset column to analyze.
        summary (dict): The summary dictionary to update.

    Returns:
        dict: The updated summary dictionary.
    """
    value_counts = series.value_counts()

    series_len = len(series)
    distinct = series.nunique()
    missing = series.isnull().sum().sum()
    memory = series.memory_usage()

    def _get_percentage(divisor: int, dividend=series_len):
        if dividend != 0:
            return (divisor / dividend) * 100
        else:
            return 0

    series_stats ={
        "distinct": distinct,
        "distinct_perc": _get_percentage(distinct),
        "missing": missing,
        "missing_perc": _get_percentage(missing),
        "memory": memory,
        "value_counts": value_counts
    }

    summary.update(series_stats)

    return summary
