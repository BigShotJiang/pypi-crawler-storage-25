"""
Data Quality Reporting Configuration

This module defines the configuration schema for the data quality reporting service.
It uses Pydantic for validation and settings management, allowing for customizable
visuals, sampling, and report metadata.
"""
from pydantic import BaseModel
from pydantic_settings import BaseSettings
from typing import List

class Colors(BaseModel):
    """
    Configuration for report color palette.
    
    Attributes:
        base_colors (List[str]): Hex codes for charts and visual elements.
    """
    base_colors: List[str] = ['#17A2B8', "#28A745", "#0D6EFD", "#DC3545", "#FFC107"]

class Sampling(BaseModel):
    """
    Configuration for data sampling.
    
    Attributes:
        get_sampling (bool): Whether to enable sampling.
        auto (bool): Whether to automatically determine sampling size.
        size (float): Fraction of data to sample (0.0 to 1.0).
        auto_length (int): Dataset size threshold for automatic sampling.
    """
    get_sampling: bool = True
    auto: bool = True
    size: float = 0.1
    auto_length: int = 100000

class Visualizations(BaseModel):
    """
    Toggle for specific visualization types in the report.
    
    Attributes:
        correlation (bool): Enable correlation heatmap.
        missing (bool): Enable missing values bar chart.
        interactions (bool): Enable interaction scatter plots.
    """
    correlation: bool = True
    missing: bool = True
    interactions: bool = True

class Settings(BaseSettings):
    """
    Global settings for the Data Quality Report.
    
    Attributes:
        colors (Colors): Color palette settings.
        report_name (str): Title displayed in the report.
        minimal (bool): Whether to generate a minified, lightweight report.
        variables (bool): Whether to include detailed variable analysis.
        file_path (str): Output destination for the generated HTML.
        alerts (bool): Whether to show the alerts section.
        show_all_samples (bool): Whether to display data samples in the report.
        sampling (Sampling): Sampling strategy configuration.
        visualizations (Visualizations): Active visualization components.
    """
    colors: Colors = Colors()
    report_name: str = "Data Quality Report"
    minimal: bool = True
    variables: bool = True
    file_path: str = "report.html"
    alerts: bool = False
    show_all_samples: bool = True
    sampling: Sampling = Sampling()
    visualizations: Visualizations = Visualizations()