"""
Comparative Report Generator

This module provides the entry point for generating a report that compares 
metrics across multiple datasets.
"""
from typing import List
from pydantic_settings import BaseSettings

from ..data.descriptions import TableDescription
from ..render.renderer import HTMLBase
from ..render.render_compare import render_compare

def get_comparison_report(data:List[TableDescription], table_names: List[str],name:str, config:BaseSettings)-> HTMLBase:
    """
    Orchestrates the creation of a Comparison Report.

    Args:
        data (List[TableDescription]): Profiles of the datasets to compare.
        table_names (List[str]): Individual labels for each dataset.
        name (str): The overall title of the profile report.
        config (BaseSettings): Report generation configuration.

    Returns:
        HTMLBase: The final top-level renderer for the comparison report document.
    """

    return render_compare(data, table_names,name, config)