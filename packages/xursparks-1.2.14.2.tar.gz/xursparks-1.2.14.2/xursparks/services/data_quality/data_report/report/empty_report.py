"""
Empty Report Generator

This module provides the entry point for generating a report for empty datasets.
"""
import pandas as pd

from ..render.renderer import HTMLBase, HTMLContainer
from ..render.render_empty import render_empty

def get_empty_report(df: pd.DataFrame, config: dict) -> HTMLBase:
    """
    Orchestrates the creation of an Empty Dataset Report.

    Args:
        df (pd.DataFrame): The empty dataset.
        config (dict): Report generation configuration.

    Returns:
        HTMLBase: The final top-level renderer for the empty report document.
    """

    body = HTMLContainer(type="sections",
                         container_items = render_empty(df, config.report_name))


    return HTMLBase(body=body, name=config.report_name)