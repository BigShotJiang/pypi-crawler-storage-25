"""
Error Report Generator

This module provides the entry point for generating a report that highlights 
ingestion errors and invalid data.
"""
import pandas as pd

from ..data.descriptions import TableDescription
from ..render.renderer import BaseRenderer, HTMLBase, HTMLContainer
from ..render.render_error import render_error
from ..render.render import render_report
from ..render.render_empty import render_empty

def get_error_report(data: TableDescription | pd.DataFrame, invalid_data: TableDescription, errors: list, is_empty: bool, config: dict, **kwargs) -> BaseRenderer:
    """
    Orchestrates the creation of an Ingestion Error Report.

    Process Flow:
    1. Renders the specialized error section showing invalid rows.
    2. Appends the standard profile report (or empty report) for the valid portion of data.
    3. Bundles all sections into an HTMLBase renderer.

    Args:
        data (TableDescription): The valid portion of the dataset profile.
        invalid_data (TableDescription): The invalid portion of the dataset profile.
        errors (list): List of error messages.
        is_empty (bool): Whether the valid dataset is empty.
        config (dict): Report generation configuration.

    Returns:
        BaseRenderer: The final top-level renderer for the error report document.
    """

    content = [render_error(data, invalid_data, errors, is_empty=is_empty)]
    if is_empty:
        content.extend(render_empty(data, config.report_name))
    else:
        content.extend(render_report(data=data, config=config))
    
    body = HTMLContainer(
        type="sections",
        container_items = content
    )


    return HTMLBase(body=body, name=config.report_name)