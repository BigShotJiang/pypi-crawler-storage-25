"""
Test Report Generator

This module provides an entry point for generating test or experimental reports.
"""
import pandas as pd

from ..render.renderer import HTMLBase
from ..render.render_test import render_test

def get_test_report(df: pd.DataFrame, name: str) -> HTMLBase:
    """
    Orchestrates the creation of a Test Report.

    Args:
        df (pd.DataFrame): The dataset to test.
        name (str): The report title.

    Returns:
        HTMLBase: The top-level renderer for the test report document.
    """

    return render_test(df)