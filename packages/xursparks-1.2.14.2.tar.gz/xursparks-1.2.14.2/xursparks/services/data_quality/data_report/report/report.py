"""
Profile Report Generator

This module provides the top-level function to generate a full statistical 
profile report by combining logical sections into a base HTML layout.
"""
from ..data.descriptions import TableDescription
from ..render.render import render_report
from ..render.renderer import HTMLContainer, HTMLBase

from dataclasses import fields


def get_report(data: TableDescription, config: dict) -> HTMLBase:
    """
    Orchestrates the creation of a standard Data Profile Report.

    Process Flow:
    1. Collects rendered sections from the render_report function.
    2. Wraps these sections in a 'sections' type HTMLContainer.
    3. Bundles the body into an HTMLBase renderer with the configured report name.

    Args:
        data (TableDescription): The profiled dataset.
        config (dict): Report generation configuration.

    Returns:
        HTMLBase: The final top-level renderer for the report document.
    """

    body = HTMLContainer(
        type="sections",
        container_items = render_report(data=data, config=config)
    )

    return HTMLBase(body=body, name=config.report_name)
