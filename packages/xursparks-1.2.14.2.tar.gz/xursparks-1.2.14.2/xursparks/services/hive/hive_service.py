import pyspark.pandas as ps
from pyhive import hive
from ...tools.logger import Logger

class HiveLLAPConnection:
    """
    Hive LLAP connection class for Frappe ERPNext
    """
    
    def __init__(self, host:str = "3.0.174.32", 
                 port:int = 10000, 
                 database:str = "zzx_dev_test", 
                 username:str = "hadoop", 
                 password:str = "hadoop@1234"):
        self.host = host
        self.port = port
        self.database = database
        self.username = username
        self.password = password
        self.connection = None
        self.cursor = None
        self.logger = Logger()  # Initialize logger
    
    def connect(self):
        """
        Establish connection to Hive LLAP
        """
        try:
            self.connection = hive.Connection(
                host=self.host,
                port=self.port,
                username=self.username,
                password=self.password,
                database=self.database,
                auth='CUSTOM'  # Use CUSTOM for username/password auth
            )
            self.cursor = self.connection.cursor()
            self.logger.log(f"Successfully connected to Hive LLAP at {self.host}:{self.port}", "info")
            return True
        except Exception as e:
            self.logger.log(f"Failed to connect to Hive LLAP: {str(e)}", "error")
            return False
    
    def execute_query(self, query, return_type='dict'):
        """
        Execute SQL query on Hive LLAP
        
        Args:
            query (str): SQL query to execute
            return_type (str): 'dict', 'dataframe', or 'raw'
        
        Returns:
            dict/DataFrame/list: Query results in specified format
        """
        try:
            if not self.connection:
                if not self.connect():
                    return None
            
            self.cursor.execute(query)
            results = self.cursor.fetchall()
            columns = [desc[0] for desc in self.cursor.description]
            
            if return_type == 'dataframe':
                # Convert to pandas DataFrame
                df = ps.DataFrame(results, columns=columns)
                return df
            elif return_type == 'raw':
                # Return raw results with column names
                return {'data': results, 'columns': columns}
            else:
                # Convert to list of dictionaries (default)
                data = []
                for row in results:
                    data.append(dict(zip(columns, row)))
                return data
        except Exception as e:
            self.logger.log(f"Query execution failed: {str(e)}", "error")
            return None
    
    def get_project_financial_summary(self, filters=None, return_type='dict'):
        """
        Get data from project_financial_summary table
        
        Args:
            filters (dict): Filter conditions
            return_type (str): 'dict', 'dataframe', or 'raw'
        
        Returns:
            dict/DataFrame/list: Query results in specified format
        """
        base_query = "SELECT * FROM project_financial_summary"
        
        if filters:
            where_conditions = []
            for key, value in filters.items():
                if isinstance(value, str):
                    where_conditions.append(f"{key} = '{value}'")
                else:
                    where_conditions.append(f"{key} = {value}")
            
            if where_conditions:
                base_query += " WHERE " + " AND ".join(where_conditions)
        
        return self.execute_query(base_query, return_type)
    
    def query_to_dataframe(self, query):
        """
        Execute query and return pandas DataFrame
        
        Args:
            query (str): SQL query to execute
        
        Returns:
            pandas.DataFrame: Query results as DataFrame
        """
        return self.execute_query(query, return_type='dataframe')
    
    def table_to_dataframe(self, table_name, filters=None):
        """
        Get entire table as pandas DataFrame
        
        Args:
            table_name (str): Name of the table
            filters (dict): Optional filter conditions
        
        Returns:
            pandas.DataFrame: Table data as DataFrame
        """
        base_query = f"SELECT * FROM {table_name}"
        
        if filters:
            where_conditions = []
            for key, value in filters.items():
                if isinstance(value, str):
                    where_conditions.append(f"{key} = '{value}'")
                else:
                    where_conditions.append(f"{key} = {value}")
            
            if where_conditions:
                base_query += " WHERE " + " AND ".join(where_conditions)
        
        return self.execute_query(base_query, return_type='dataframe')
    
    def close_connection(self):
        """
        Close Hive LLAP connection
        """
        try:
            if self.cursor:
                self.cursor.close()
            if self.connection:
                self.connection.close()
            self.logger.log("Hive LLAP connection closed successfully", "info")
        except Exception as e:
            self.logger.log(f"Error closing Hive connection: {str(e)}", "error")