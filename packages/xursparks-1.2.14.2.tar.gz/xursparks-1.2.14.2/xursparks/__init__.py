"""
xursparks Library

A powerful Python library for orchestrating Spark data ingestion and transformation jobs.
This library provides a high-level API for handling common Spark operations, auditing, 
reporting, and data quality checks within the Xurpas ecosystem.

For recent changes, see the [Changelog](file:../../../CHANGELOG.md).
"""
__version__ = "1.2.14.2"

import datetime

import pyspark.pandas as ps
from pyspark.sql import DataFrame as SparkDataFrame

from .core.context import XursparksContext
from .core.utils import call_api, execute_subprocess, parse_date_pattern, safe_union

# =============================================================================
# SINGLETON CONTEXT
# =============================================================================
# This singleton instance holds the state for the entire job, preserving the
# original global behavior in a structured way. All module-level functions
# will delegate their calls to this instance.

_context = XursparksContext()


# =============================================================================
# PUBLIC API (BACKWARDS-COMPATIBLE WRAPPERS)
# =============================================================================
# These functions provide the exact same interface as the original library,
# ensuring that no existing code needs to be changed.

def initialize(args):
	"""
    Initializes the Xursparks job environment.

    This function sets up all necessary global configurations for a Spark job. It parses command-line
    arguments, reads configuration from a properties file, fetches global and job-specific settings
    from a context API, and initializes the Spark session.

    Process Flow:
    1.  Initializes global dictionaries (e.g., `jobArguments`, `sparkConfig`, `targetTable`).
    2.  Parses command-line arguments provided in the `args` list.
    3.  Reads the properties file specified by the 'properties-file' argument.
    4.  Fetches global configurations (e.g., Spark defaults, audit settings) from a central API.
    5.  Fetches job-specific context, including target table and source table (dependency) metadata.
    6.  Populates the `targetTable` and `sourceTables` dictionaries with this metadata.
    7.  Handles optional parameters, including JDBC and source/target specific options.
    8.  Sets up Kerberos authentication if keytab and principal are provided.
    9.  Calls `initializeSparkSession()` to create the Spark session.

    Args:
        args (list): A list of command-line arguments passed to the script.
    """
	_context.initialize(args)

def initializeSparkSession():
	"""Creates and initializes the SparkSession."""
	_context._initialize_spark_session()

def readSourceTableParquet(s3_path):
	"""Reads a Parquet file from a given S3 path."""
	doLog("Reading Parquet from: " + s3_path)
	return _context.spark_session.read.parquet(s3_path)

def loadSourceTable(**kwargs):
	"""A wrapper function to read a source table."""
	return _context.io.load_source_table(**kwargs)

def readSourceTable(dataStorage, schema, readOptions, processDate, columnFilter):
	"""Reads data from a source as defined by the provided metadata."""
	return _context.io.read_source_table(dataStorage, schema, readOptions, processDate, columnFilter)

def generateTablePaths(dataStorage, options):
	"""Generates a sequence of partition paths for a given date range."""
	return _context.io._generate_table_paths(dataStorage, options)

def readTableInStrictMode(dataStorage, schema, options, dataFrame):
	"""Reads data partitions in 'STRICT' mode."""
	return _context.io._read_in_strict_mode(dataStorage, schema, options, dataFrame)

def readTableInSearchMode(dataStorage, schema, options, dataFrame):
	"""Reads data partitions in 'SEARCH' mode."""
	return _context.io._read_in_search_mode(dataStorage, schema, options, dataFrame)

def readTableInLaxMode(dataStorage, schema, options, dataFrame):
	"""Reads data partitions in 'LAX' mode."""
	return _context.io._read_in_lax_mode(dataStorage, schema, options, dataFrame)

def writeToTargetTable(targetTable, writeDate):
	"""Writes a DataFrame to a target table location. (Deprecated)."""
	# This version is ambiguous and likely deprecated. Delegating to the more explicit one.
	writeData(targetTableDataset=targetTable, writeDate=writeDate)

def writeToTargetTable(dataStorage, dataset, writeOptions, jdbcWriteOptions, processDate):
	"""Writes a DataFrame to a target destination."""
	_context.io.write_to_target_table(dataStorage, dataset, writeOptions, jdbcWriteOptions, processDate)

def writeData(**kwargs):
	"""High-level wrapper to orchestrate the data writing process."""
	_context.io.write_data(**kwargs)

def doJobAuditing(data):
	"""Sends an audit report email."""
	# This function seems to be for internal use by handlePostWrite.
	# Exposing sendEmail is more flexible.
	_context.reporting.do_job_auditing(data)

def getDefaultJobProperties(propertyName):
	"""Retrieves a property from the '[default]' section."""
	return _context.get_specific_job_properties("default", propertyName)

def getWriteOptionProperties(propertyName):
	"""Retrieves a property from the '[write_options]' section."""
	return _context.get_specific_job_properties("write_options", propertyName)

def getJdbcOptionProperties(propertyName):
	"""Retrieves a property from the '[jdbc_options]' section."""
	return _context.get_specific_job_properties("jdbc_options", propertyName)

def getJobAuditProperties(propertyName):
	"""Retrieves a property from the '[job_audit]' section."""
	return _context.get_specific_job_properties("job_audit", propertyName)

def getSpecificJobProperties(groupName, propertyName):
	"""Retrieves a specific property from a given section."""
	return _context.get_specific_job_properties(groupName, propertyName)

def getDictionarFromProperties(groupName):
	"""Retrieves an entire section from the properties file as a dictionary."""
	return _context.get_dictionary_from_properties(groupName)

def getSparkSession():
	"""Returns the initialized SparkSession object."""
	return _context.spark_session

def setTargetTableDataset(targetTable):
	"""Sets the DataFrame to be written to the target table."""
	if isinstance(targetTable, ps.DataFrame):
		_context.target_table_dataset = _context.spark_session.createDataFrame(targetTable)
	elif isinstance(targetTable, SparkDataFrame):
		_context.target_table_dataset = targetTable
	else:
		raise TypeError("Unknown DataFrame type.")

def setProcessDate(process_date):
	"""Sets the process date."""
	_context.process_date = process_date

def tearDown():
	"""Stops the SparkSession."""
	_context.tear_down()

def executeSubProcess(options):
	"""Executes a subprocess command."""
	return execute_subprocess(options)

def handlePostWrite():
	"""Performs post-write auditing and reporting tasks."""
	_context.reporting.handle_post_write()

def getJobArguments(**kwargs):
	"""Retrieves job arguments passed at runtime."""
	key = kwargs.get("key")
	return _context.job_arguments.get(key) if key else _context.job_arguments

def getCustomJobArguments(**kwargs):
	"""Retrieves custom job arguments."""
	key = kwargs.get("key")
	return _context.custom_job_args.get(key) if key else _context.custom_job_args

def getSourceTables(**kwargs):
	"""Retrieves metadata for source tables."""
	key = kwargs.get("key")
	return _context.source_tables.get(key) if key else _context.source_tables

def getTargetTable():
	"""Retrieves the metadata for the main target table."""
	return _context.target_table

def setTargetTable(dataStorage):
	"""Sets the target table metadata dictionary."""
	_context.target_table = dataStorage

def getProcessDate():
	"""Retrieves the process date."""
	return _context.process_date

def getWriteDate():
	"""Retrieves the write date."""
	return _context.write_date

def generateTablePath(dataStorage):
	"""Generates the full partition path for writing data."""
	return _context.hive.generate_write_path()

def produceTablePath(dataStorage):
	"""Constructs the base part of a partition path."""
	return f"{dataStorage['path']}{dataStorage['partition_name'].lower()}="

def parseBaseDate(datePattern, processDate):
	"""Parses the initial part of a date pattern string."""
	# This logic is now inside the main parse_date_pattern function in utils.
	pass

def getSparkDefaultOptions():
	"""Retrieves the dictionary of default Spark options."""
	return _context.spark_default_options

def setWriteDate(thisDate:datetime):
	"""Sets the write date."""
	_context.write_date = thisDate

def getSourceTableOption(tableName):
	"""Retrieves the options for a specific source table."""
	return _context.source_table_options.get(tableName)

def getTargetTableOption():
	"""Retrieves the options for the target table."""
	return _context.target_table_options

def setTargetTableOption(options):
	"""Updates the target table options dictionary."""
	_context.target_table_options.update(options)

def getOptionalParams(**kwargs):
	"""Retrieves optional parameters for the job."""
	key = kwargs.get("key")
	return _context.optional_params.get(key) if key else _context.optional_params

def getSparkConfig(**kwargs):
	"""Retrieves Spark configuration properties."""
	key = kwargs.get("key")
	return _context.spark_config.get(key) if key else _context.spark_config
	
def uploadToS3(**kwargs):
	"""Uploads one or more local files to an S3 bucket."""
	_context.reporting.upload_to_s3(**kwargs)
	
def sendEmail(**kwargs):
	"""Sends an email using the configured SMTP server."""
	_context.reporting.send_email(**kwargs)

def fetchFileFromS3():
	"""Downloads all files from a specific S3 partition path."""
	return _context.reporting.fetch_file_from_s3()

def tapChatGPT(**kwargs):
	"""Sends a prompt to the OpenAI Chat Completions API."""
	return _context.reporting.tap_chat_gpt(**kwargs)

def updateS3Permission(**kwargs):
	"""Updates the Access Control List (ACL) for objects in an S3 subdirectory."""
	_context.reporting.update_s3_permission(**kwargs)

def generateDataQualityReport(**kwargs):
	"""Generates and emails a data quality report."""
	_context.reporting.generate_data_quality_report(**kwargs)

def createHiveTable():
	"""Creates a Hive table if it doesn't already exist."""
	_context.hive.create_hive_table()

def registerPartition(**kwargs):
	"""Registers a new partition in the Hive metastore."""
	_context.hive.register_partition(**kwargs)

def generateWritePath():
	"""Generates the full HDFS/S3 path for writing a partition."""
	return _context.hive.generate_write_path()

def generateWritePaths():
	"""Generates partition paths dynamically."""
	return _context.hive.generate_write_paths()

def get_hive_data_type(spark_data_type):
	"""Maps a PySpark DataType to its corresponding Hive data type string."""
	return _context.hive._get_hive_data_type(spark_data_type)

def runDataQualityChecks(compress:bool=False, content_type:str=None, 
						debug:bool=False, export_body:dict=None):
	"""
		Executes data quality checks on the target table dataset.
		Args:
			compress (bool): Defaults to False. Will natively implement HTTP gzip compression to `call_api`.
			content_type (str): Defaults to None. Will set the content type of the request.
			debug (bool): Defaults to False. Will enable debug mode.
			export_body (dict): Defaults to False. Will export the API request body to a file.
	"""
	return _context.reporting.run_data_quality_checks(compress=compress, content_type=content_type, debug=debug, export_body=export_body)

def doLog(message):
	"""Prints a message using the configured logger."""
	_context.reporting.do_log(message)

def safe_union(dfs, checkpoint=False):
	"""Safely unions a list of DataFrames, avoiding deep lineage and GC overhead."""
	return _safe_union(dfs, checkpoint)


# Backwards-compatible wrapper: expose `Xursparks` class for importers
class Xursparks:
    """Compatibility wrapper that calls module-level `initialize(args)`.

    Many existing jobs import `Xursparks` from the package and expect
    initialization to occur when instantiating the class. This thin wrapper
    preserves that behavior by delegating to the `initialize` function defined
    above.
    """
    def __init__(self, args):
        initialize(args)

    def get_job_arguments(self):
        return getJobArguments()
