import sys
import os

utils_path = r'c:\Users\LENOVO\Documents\Xurpas\xursparks\xursparks\core\utils.py'
content = """

def safe_union(dfs, checkpoint=False):
    \"\"\"
    Safely unions a list of DataFrames, avoiding deep lineage and GC overhead.
    
    Args:
        dfs (list): List of PySpark DataFrames to union.
        checkpoint (bool): If True, performs a localCheckpoint to truncate lineage.
        
    Returns:
        DataFrame: The unioned DataFrame.
    \"\"\"
    if not dfs:
        return None
    
    if len(dfs) == 1:
        return dfs[0]
    
    from functools import reduce
    
    # Binary union is more efficient for Spark plan optimization than linear reduce.
    def binary_union(dfs_list):
        if len(dfs_list) == 1:
            return dfs_list[0]
        if len(dfs_list) == 2:
            return dfs_list[0].union(dfs_list[1])
            
        mid = len(dfs_list) // 2
        return binary_union(dfs_list[:mid]).union(binary_union(dfs_list[mid:]))
    
    result = binary_union(dfs)
    
    # Truncate lineage if requested or if there are many unions to prevent GC overhead.
    if checkpoint or len(dfs) > 10:
        try:
            result = result.localCheckpoint()
        except Exception:
            # Fallback if localCheckpoint is not supported in the environment
            pass
            
    return result
"""

with open(utils_path, 'a', encoding='utf-8') as f:
    f.write(content)
print("Successfully appended safe_union to utils.py")
