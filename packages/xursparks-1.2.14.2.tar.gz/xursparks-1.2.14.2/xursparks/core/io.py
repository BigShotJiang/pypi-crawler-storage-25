import datetime
import json
import requests
import time

import pandas as pd
from pyspark.sql.types import StructType
from requests_ntlm import HttpNtlmAuth

from xursparks.services.google import XGoogleService as xgservice
from xursparks.services.http.api_reader import APIReader
from .utils import call_api, parse_date_pattern, safe_union


class IOService:
    """
    Handles all data input and output operations for a Xursparks job.
    """
    def __init__(self, context):
        """
        Initializes the IOService mapping.
        
        Args:
            context (XursparksContext): The job context holding spark sessions and configurations.
        """
        self.context = context

    def process_tables_config(self, job_tables_config):
        """
        Processes the table configuration directly from the API job definition.
        
        Process Flow:
            1. Extracts the primary write target definition including storage mechanisms (AWS/GCS/HDFS).
            2. Pulls supplementary options attached uniquely to the target (e.g., specific JDBC URLs).
            3. Iterates through the `dependencies` to setup the input dictionaries for source tables.
            4. Persists the formatted outputs dynamically into the `self.context`.
            
        Args:
            job_tables_config (dict): A dictionary representing the API JSON response for target contexts.
        
        Major Variables:
            - `target_table` (dict): Extracted target dictionary.
            - `source` (dict): Loop variable storing source context dicts.
        """
        # Process Target Table
        target_table = {}
        storage_type = job_tables_config.get("storage_type", "AWS").upper()
        if "AWS" in storage_type: target_table["storage_type"] = "s3a://"
        elif "GCS" in storage_type: target_table["storage_type"] = "gs://"
        elif "HDFS" in storage_type: target_table["storage_type"] = "hdfs://"
        else: target_table["storage_type"] = "s3a://"

        target_table["table_name"] = job_tables_config["table_name"]
        target_table["database_name"] = job_tables_config["database_name"]
        target_table["resource"] = job_tables_config.get("resource", "")
        target_table["folder"] = job_tables_config["folder"] + "/"
        
        if "local" in self.context.job_arguments.get("master", ""):
            target_table["path"] = job_tables_config["folder"]
        else:
            target_table["path"] = f"{target_table['storage_type']}{target_table['resource']}{job_tables_config['folder']}"

        target_table["write_mode"] = job_tables_config["write_mode"]
        target_table["redistribution"] = job_tables_config["redistribution"]
        target_table["partition_name"] = job_tables_config["partition_name"]
        target_table["partition_date_format"] = job_tables_config["partition_date_format"]
        target_table["format"] = job_tables_config["format"]
        target_table["number_of_partitions"] = job_tables_config["number_of_partitions"]
        self.context.target_table = target_table

        # Process Optional Parameters
        if "optional_parameters" in job_tables_config:
            for param in job_tables_config["optional_parameters"]:
                key = param.get("key")
                value = param.get("value")
                self.context.optional_params[key] = value
                if key == "options.target": self.context.target_table_options = json.loads(value)
                elif key.startswith("options.target."): self.context.target_table_options[key.replace("options.target.","")] = value
                elif key.startswith("options.jdbc."): self.context.jdbc_options[key.replace("options.jdbc.","")] = value
                elif key.startswith("options.source."): self.context.source_table_options[key.replace("options.source.","")] = json.loads(value)
            self.context.jdbc_options["dbtable"] = target_table["table_name"]

        # Process Dependencies (Source Tables)
        if "dependencies" in job_tables_config:
            for item in job_tables_config["dependencies"]:
                sjc = item["source_job_context"]
                source = {}
                storage_type = sjc.get("storage_type", "AWS").upper()
                if "AWS" in storage_type: source["storage_type"] = "s3a://"
                elif "GCS" in storage_type: source["storage_type"] = "gs://"
                elif "HDFS" in storage_type: source["storage_type"] = "hdfs://"
                else: source["storage_type"] = "s3a://"

                table_name = sjc["table_name"]
                source["table_name"] = table_name
                source["database_name"] = sjc["database_name"]
                source["resource"] = sjc.get("resource", "")
                source["path"] = f"{source['storage_type']}{source['resource']}{sjc['folder']}"
                source["write_mode"] = sjc["write_mode"]
                source["redistribution"] = sjc["redistribution"]
                source["partition_name"] = sjc["partition_name"]
                source["partition_date_format"] = sjc["partition_date_format"]
                source["format"] = sjc["format"]
                source["number_of_partitions"] = sjc["number_of_partitions"]
                source["read_start_date"] = parse_date_pattern(item["read_start_date"], self.context.process_date)
                source["read_end_date"] = parse_date_pattern(item["read_end_date"], self.context.process_date)
                source["read_mode"] = item["read_mode"]
                source["search_tolerance"] = int(item["search_tolerance"])
                self.context.source_tables[table_name] = source

    def load_source_table(self, **kwargs):
        """
        Wrapper to read a source table using keyword arguments.
        Delegates completely to `read_source_table`.
        """
        data_storage = kwargs.get("dataStorage")
        schema = kwargs.get("schema")
        read_options = kwargs.get("readOptions", {})
        process_date = kwargs.get("processDate")
        column_filter = kwargs.get("columnFilter")
        return self.read_source_table(data_storage, schema, read_options, process_date, column_filter)

    def read_source_table(self, data_storage, schema, read_options, process_date, column_filter):
        """
        Reads data from a source as defined by the provided metadata.
        
        Process Flow:
            1. Consolidates required `read_options` directly with context `spark_default_options`.
            2. Routes the reading mechanism conditionally (e.g. Google APIs, Native HTTP, File HDFS).
            3. Triggers DataFrame loading and optionally applies a column filter on successful read.
            
        Args:
            data_storage (dict): The target dictionary containing format, host, and path details.
            schema (StructType): Specific PySpark schema object to enforce.
            read_options (dict): Arbitrary spark read options overrides.
            process_date (datetime): Active job date reference.
            column_filter (Column): Pre-processing PySpark column logic to filter data.

        Returns:
            DataFrame: The resulting PySpark DataFrame.
        """
        spark = self.context.spark_session
        schema = schema or StructType([])

        if data_storage is None:
            self.context.reporting.do_log("ERROR: data_storage is None. Cannot read source table.")
            return spark.createDataFrame([], schema=schema)

        if schema:
            read_options['customSchema'] = schema

        source_table_option = self.context.source_table_options.get(data_storage.get("table_name"), {})
        
        master = self.context.job_arguments.get("master", "")
        if "local" not in master:
            options = {**self.context.spark_default_options, **source_table_option, **read_options}
        else:
            options = {**source_table_option, **read_options}

        df = spark.createDataFrame([], schema=schema)
        source_format = data_storage.get("format", "").upper()

        if source_format.startswith("GOOGLE"):
            debug = read_options.get("debug", False)
            df = xgservice(dataStorage=data_storage, readOptions=read_options, schema=schema, sparkSession=spark, debug=debug).processRequest()
        elif source_format == "API":
            df = self._read_from_api(read_options, df)
        else:
            df = self._read_from_file_system(data_storage, schema, options, df, column_filter)

        # df.printSchema()
        return df

    def _read_from_api(self, read_options, df):
        """
        Handles reading data iteratively from a traditional REST API.
        
        Process Flow:
            1. Prepares header blocks using user configurations depending
               on specific authentication needs (NTLM vs OAuth Bearer).
            2. Pulls data JSON arrays iteratively by parsing the API.
            3. Converts these into the target PySpark format using the local `APIReader` class.
            
        Args:
            read_options (dict): Options containing API credentials and structure arguments.
            df (DataFrame): The empty initial DataFrame skeleton to append to.
            
        Returns:
            DataFrame: Hydrated PySpark objects mapped correctly.
        """
        spark = self.context.spark_session
        mode = read_options.get("mode", "default")
        response_key = read_options.get("source_response_key", "value")

        if mode == "ntlm":
            debug = read_options.get("debug", False)
            if self.context._api_session is None:
                self.context._api_session = requests.Session()
                self.context._api_session.verify = self.context.ssl_verify
                
            source_storage = {
                "base_url": read_options.get("source_base_url"),
                "headers": read_options.get("source_headers"),
                "method": read_options.get("source_method", "GET"),
                "auth": HttpNtlmAuth(read_options.get("source_auth_user"), read_options.get("source_auth_password"))
            }
            return APIReader(args=source_storage, session=self.context._api_session, debug=debug).fetch_data()
        else:
            token_key_name = read_options.get("token_key_name", "token")
            debug = read_options.get("debug", False)
            
            if self.context._api_session is None:
                self.context._api_session = requests.Session()
                self.context._api_session.verify = self.context.ssl_verify

            def _get_new_token():
                token_storage = {
                    "base_url": read_options.get("token_base_url"),
                    "auth": read_options.get("token_auth"),
                    "headers": read_options.get("token_headers"),
                    "method": read_options.get("token_method", "GET"),
                    "data": read_options.get("token_data"),
                    "json": read_options.get("token_json"),
                    "files": read_options.get("token_files")
                }
                token_reader = APIReader(args=token_storage, session=self.context._api_session, debug=debug)
                token_response = token_reader.fetch_data()
                if not token_response:
                    raise Exception(f"Failed to fetch authentication token from {token_storage['base_url']}")
                return token_response.get(token_key_name)
                
            token_cache_key = read_options.get("token_base_url", "default_token_url")
            
            if token_cache_key not in self.context._api_token_cache or not self.context._api_token_cache[token_cache_key]:
                if debug:
                    self.context.reporting.do_log(f"Fetching new token for {token_cache_key}")
                self.context._api_token_cache[token_cache_key] = _get_new_token()

            source_storage = {
                "base_url": read_options.get("source_base_url"),
                "auth": read_options.get("source_auth"),
                "method": read_options.get("source_method", "GET"),
                "headers": read_options.get("source_headers"),
                "key": f"Bearer {self.context._api_token_cache[token_cache_key]}",
                "data": read_options.get("source_data"),
                "json": read_options.get("source_json"),
                "files": read_options.get("source_files")
            }
            
            try:
                api_response = APIReader(args=source_storage, session=self.context._api_session, debug=debug).fetch_data()
            except Exception as e:
                is_auth_error = False
                if hasattr(e, 'response') and e.response is not None:
                    if e.response.status_code in (401, 403):
                        is_auth_error = True
                elif any(err in str(e).lower() for err in ["401", "403", "unauthorized", "bearer token"]):
                    is_auth_error = True
                else:
                    # Fallback to retry authentication if error specifics are unclear but looks like an auth issue
                    is_auth_error = "auth" in str(e).lower()
                    
                if is_auth_error:
                    if debug:
                        self.context.reporting.do_log(f"API request failed with error '{str(e)}'. Re-authenticating...")
                    self.context._api_token_cache[token_cache_key] = _get_new_token()
                    source_storage["key"] = f"Bearer {self.context._api_token_cache[token_cache_key]}"
                    api_response = APIReader(args=source_storage, session=self.context._api_session, debug=debug).fetch_data()
                else:
                    raise
                    
            return_format = read_options.get("return_format", "dataframe")
            
            data_to_process = api_response.get(response_key) if response_key else api_response
            return APIReader(spark_session=spark, data=data_to_process, debug=debug).process_data(df=df, return_format=return_format)

    def _read_from_file_system(self, data_storage, schema, options, df, column_filter):
        """
        Handles reading from traditional datastores like S3, HDFS, JDBC.
        
        Process Flow:
            1. Triggers direct read functions if the source isn't time-partitioned (missing dates).
            2. Triggers JDBC driver reads if configured.
            3. Defers execution iteratively to time-based partition functions (`_read_in_strict_mode`, etc.).
            4. Ultimately filters parsed information if a `column_filter` lambda map exists.
            
        Args:
            data_storage (dict): Information dict regarding the target dataset format.
            schema (StructType): The enforced spark schema object.
            options (dict): Spark Read specific options override dictionaries.
            df (DataFrame): The initial empty target DataFrame chunk.
            column_filter (Column): Pyspark specific column logic.
            
        Major Variables:
            - `read_mode` (str): Defines how missing date partitions should conditionally halt or bypass operations.
            
        Returns:
            DataFrame: Hydrated PySpark objects extracted.
        """
        spark = self.context.spark_session
        options.setdefault("basePath", data_storage["path"])
        self.context.reporting.do_log(f"Reading : {options['basePath']}")

        if "read_start_date" not in data_storage or "read_end_date" not in data_storage or self.context.process_date is None:
            reader = spark.read.options(**options).format(data_storage["format"])
            if schema:
                reader = reader.schema(schema)
            df = reader.load()
        elif data_storage.get("format", "").upper() == "JDBC":
            reader = spark.read.format(data_storage["format"]).options(**options)
            if schema:
                reader = reader.schema(schema)
            df = reader.load()
        else:
            read_mode = data_storage.get("read_mode", "LAX")
            if read_mode == "STRICT":
                df = self._read_in_strict_mode(data_storage, schema, options, df)
            elif read_mode == "SEARCH":
                df = self._read_in_search_mode(data_storage, schema, options, df)
            else: # LAX
                df = self._read_in_lax_mode(data_storage, schema, options, df)

        if column_filter:
            df = df.filter(column_filter)
        
        options.pop("basePath", None)
        return df

    def _generate_table_paths(self, data_storage, options):
        """
        Generates a continuous array sequence of partition source sub-paths derived from loops 
        incorporating dynamic datetime strings over expected limits.
        
        Process Flow:
            1. Uses bounds between `read_start_date` and `read_end_date` (or up to `search_tolerance`).
            2. Iterates internally via `pandas.date_range`.
            3. Formats corresponding key partition directories sequentially based on `data_storage["partition_date_format"]`.
            
        Args:
            data_storage (dict): Reference dict describing how to construct partition schemas dynamically.
            options (dict): External configuration map.
            
        Returns:
            list: Assorted ordered complete path strings representing expected remote data buckets.
        """
        generated_table_paths = []

        if data_storage.get("read_start_date") is not None and data_storage.get("read_end_date") is not None and data_storage.get("read_start_date") != data_storage.get("read_end_date"):
            self.context.reporting.do_log("GENERATING PATHS FOR TABLE: " + data_storage["table_name"])
        else:
            self.context.reporting.do_log("GENERATING PATH FOR TABLE: " + data_storage["table_name"])

        start_date = data_storage.get("read_start_date").strftime("%Y-%m-%d")

        if data_storage.get("read_mode") == "SEARCH":
            end_date = (data_storage.get("read_start_date") - datetime.timedelta(days=int(data_storage.get("search_tolerance")))).strftime("%Y-%m-%d")
        else:
            end_date = data_storage.get("read_end_date").strftime("%Y-%m-%d")

        sdate = datetime.date(int(start_date.split("-")[0]), 
                    int(start_date.split("-")[1]), 
                    int(start_date.split("-")[2]))   # start date
        edate = datetime.date(int(end_date.split("-")[0]), 
                    int(end_date.split("-")[1]), 
                    int(end_date.split("-")[2]))   # end date

        date_range = pd.date_range(start=edate, end=sdate)
        for date in date_range:
            partition_names = data_storage.get("partition_name", "").lower().split(",")
            partition_format = data_storage.get("partition_date_format", "")
            partition_value = date.strftime(partition_format)

            partition_path = ""
            for pname in partition_names:
                if pname.strip():
                    partition_path += f"{pname.strip()}={partition_value}/"
            
            generated_table_paths.append(f'{data_storage.get("path", "")}{partition_path}')

        return reversed(generated_table_paths)

    def _read_in_strict_mode(self, data_storage, schema, options, df):
        """
        Iterates reading paths matching them stringently. 
        Will immediately throw an Exception if any generated date partition goes missing across loops.
        """
        self.context.reporting.do_log("Reading Table in STRICT mode.")
        spark = self.context.spark_session
        paths = self._generate_table_paths(data_storage, options)
        
        dfs = []
        for path in paths:
            if "excel" in data_storage.get('format', '').lower():
                path = path + options.get('filename', '')
            self.context.reporting.do_log("READING Partition: " + path)
            try:
                if len(schema) == 0:
                    read_df = spark.read.options(**options) \
                            .format(data_storage["format"]).load(path)
                else:
                    read_df = spark.read.options(**options) \
                            .format(data_storage["format"]).schema(schema).load(path)
                dfs.append(read_df)
            except Exception as e:
                raise Exception("Partition Path:" + path + " does not exist") from e
        
        if dfs:
            return safe_union(dfs)
        return df

    def _read_in_search_mode(self, data_storage, schema, options, df):
        """
        Iterates searching matching date paths decreasingly according to a tolerance setting, stopping
        and accepting solely the primary DataFrame read as complete immediately when successfully found.
        """
        self.context.reporting.do_log("Reading Table in SEARCH mode.")
        spark = self.context.spark_session
        self.context.reporting.do_log(f"format: {data_storage.get('format')}")
        self.context.reporting.do_log(f"options: {options}")
        for path in self._generate_table_paths(data_storage, options):
            if "xlsx" in data_storage.get('format', '').lower():
                path = path + options.get('filename', '')
            self.context.reporting.do_log("READING Partition(Search): " + path)
            try:
                if len(schema) == 0:
                    df = spark.read\
                            .format(data_storage["format"])\
                            .options(**options).load(path)
                else:
                    df = spark.read.options(**options) \
                            .format(data_storage["format"]).schema(schema).load(path)
                if df is not None:
                    self.context.reporting.do_log("Path: " + path + " exists.")
                    break
            except Exception as e:
                self.context.reporting.do_log("Path: " + path + " does not exist.")
        return df

    def _read_in_lax_mode(self, data_storage, schema, options, df):
        """
        Iterates backwards across possible date partitions joining multiple DataFrames while 
        ignoring silently any exceptions spawned by intermediate missing paths.
        """
        self.context.reporting.do_log("Reading Table in LAX mode.")
        spark = self.context.spark_session
        # In the refactored io.py, read_start_date is parsed into a datetime or None object. 
        # Checking for "*" from the original logic isn't exact here because `parse_date_pattern` returns None for "*"
        if data_storage.get("read_start_date") is None or data_storage.get("read_end_date") is None:
            if len(schema) == 0:
                df = spark.read.options(**options) \
                    .format(data_storage["format"]).load(data_storage["path"])
            else:
                df = spark.read.options(**options) \
                    .format(data_storage["format"]).schema(schema).load(data_storage["path"])
            return df
        
        paths = self._generate_table_paths(data_storage, options)
        dfs = []
        for path in paths:
            if "excel" in data_storage.get('format', '').lower():
                path = path + options.get('filename', '')
            self.context.reporting.do_log("READING Partition: " + path)
            try:
                if len(schema) == 0:
                    read_df = spark.read.options(**options) \
                            .format(data_storage["format"]).load(path)
                else:
                    read_df = spark.read.options(**options) \
                            .format(data_storage["format"]).schema(schema).load(path)
                dfs.append(read_df)
            except Exception as e:
                self.context.reporting.do_log("Partition Path: " + path + " does not exist")
        
        if dfs:
            return safe_union(dfs)
        return df

    def write_data(self, **kwargs):
        """
        High-level wrapper to orchestrate writing the final overarching dataset internally,
        including capturing accurate times and benchmarking log markers.
        
        Args:
            **kwargs: Arbitrary keyword arguments used for overwriting target dictionaries explicitly.
        """
        target_table = kwargs.get("targetTable", self.context.target_table)
        self.context.write_date = kwargs.get("writeDate", self.context.write_date)
        
        target_table_options = kwargs.get("targetTableOptions", {})
        self.context.target_table_options.update(target_table_options)

        target_dataset = kwargs.get("targetTableDataset", self.context.target_table_dataset)
        self.context.target_table_dataset = target_dataset

        jdbc_options = kwargs.get("jdbcOptions", {})
        self.context.jdbc_options.update(jdbc_options)

        self.write_to_target_table(
            target_table,
            target_dataset,
            self.context.target_table_options,
            self.context.jdbc_options,
            self.context.write_date
        )
        
        self.context.end_timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.context.end_time_epoch = time.perf_counter()
        elapsed_time = self.context.end_time_epoch - self.context.start_time_epoch
        self.context.reporting.do_log(f"start : {self.context.start_timestamp} | {self.context.start_time_epoch}")
        self.context.reporting.do_log(f"end : {self.context.end_timestamp} | {self.context.end_time_epoch}")
        self.context.reporting.do_log(f"elapsed : {elapsed_time}")

    def write_to_target_table(self, data_storage, dataset, write_options, jdbc_write_options, process_date):
        """
        Writes a configured DataFrame cleanly backing a structured persistent target destination internally directly from context variables.
        
        Process Flow:
            1. Pulls default PySpark properties natively avoiding external calls.
            2. Routes executions directly into JDBC writing endpoints if appropriately flagged.
            3. Derives standard HDFS paths generating keys natively via Hive `generate_write_path`.
            4. Adjusts redistribution strategies physically by leveraging `coalesce` or `repartition`.
            5. Flushes PySpark results correctly using Spark `.save()`.
            
        Args:
            data_storage (dict): Target information structure referencing keys and configurations.
            dataset (DataFrame): Physical dataset in process that requires persistence mapping.
            write_options (dict): Specialized runtime string modifications altering the write behavior mapping.
            jdbc_write_options (dict): Options distinctively matching JDBC endpoints override setups mappings.
            process_date (datetime): Context timeline variable dictating Hive mapping partitions mappings.
        """
        master = self.context.job_arguments.get("master", "")
        if "local" not in master:
            options = {**self.context.spark_default_options, **write_options}
        else:
            options = {**write_options}

        if data_storage.get("format", "").upper() == "JDBC":
            self.context.jdbc_options["dbtable"] = data_storage.get("table_name")
            all_options = {**self.context.jdbc_options, **jdbc_write_options, **options}
            self.context.reporting.do_log("WRITING as JDBC")
            dataset.write.options(**all_options).format(data_storage.get("format")) \
                .mode(data_storage.get("write_mode")).save()
        else:
            path = self.context.hive.generate_write_path()
            
            redistribution = data_storage.get("redistribution", "").upper()
            num_partitions = int(data_storage.get("number_of_partitions", 1))

            if redistribution == "REPARTITION":
                dataset = dataset.repartition(num_partitions)
            else: # COALESCE or default
                dataset = dataset.coalesce(num_partitions)

            if "filename" in (k.lower() for k in options):
                path += options.get("filename")
            
            self.context.reporting.do_log(f"WRITING to path: {path}")
            self.context.reporting.do_log(f"options: {options}")
            
            dataset.write.options(**options).format(data_storage.get("format")) \
                .mode(data_storage.get("write_mode")).save(path)

        self.context.reporting.do_log(f"targetTableDataStorage: {data_storage}")