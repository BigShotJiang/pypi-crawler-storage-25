import configparser
import datetime
import logging
import time

from pyspark.sql import SparkSession

from .hive import HiveService
from .io import IOService
from .reporting import ReportingService
from .utils import call_api, parse_date_pattern


class XursparksContext:
    """
    A singleton class to hold the entire state and configuration for a Xursparks job.
    """
    _instance = None

    def __new__(cls, *args, **kwargs):
        """
        Singleton pattern to ensure only one instance of XursparksContext exists.

        Args:
            *args: Variable length argument list.
            **kwargs: Arbitrary keyword arguments.
        """
        if not cls._instance:
            cls._instance = super(XursparksContext, cls).__new__(cls, *args, **kwargs)
        return cls._instance

    def __init__(self):
        """
        Initializes the context object state attributes, preventing re-initialization 
        if already initialized. Setup includes creating class variable stores 
        for configurations, job options, and timestamps. Also instantiates the 
        IO, Hive, and Reporting services.
        """
        # Prevent re-initialization
        if hasattr(self, '_initialized') and self._initialized:
            return

        self.job_arguments = {}
        self.custom_job_args = {}
        self.target_table_dataset = None
        self.write_date = None
        self.process_date = None
        self.target_table = {}
        self.target_table_options = {}
        self.source_table_options = {}
        self.jdbc_options = {}
        self.source_tables = {}
        self.spark_config = {}
        self.spark_default_options = {}
        self.audit_options = {}
        self.optional_params = {}
        self.start_timestamp = None
        self.start_time_epoch = None
        self.scope_env = "DEV"
        self.debug_mode = False
        self.job_type = "default"
        self.dq_rules = {}
        self.app_name = None
        self.job_properties = None
        self.spark_session = None
        self._api_session = None
        self._api_token_cache = {}

        # Initialize services
        self.io = IOService(self)
        self.hive = HiveService(self)
        self.reporting = ReportingService(self)

        self._initialized = True

    def initialize(self, args):
        """
        Initializes the Xursparks job environment by parsing arguments, fetching
        configurations, and setting up the Spark session.
        
        Process Flow:
            1. Sets up the start time counters.
            2. Parses command-line `args` into a local `self.job_arguments` map.
            3. Derives the application name and target processing dates.
            4. Loads the properties file using configparser.
            5. Invokes global configurations via API.
            6. Fetches job-specific table contexts from API.
            7. Retrieves Data Quality (DQ) configurations if requested.
            8. Calls internal `_initialize_spark_session`.

        Args:
            args (list): The list of arguments passed usually from sys.argv.
        """
        logging.getLogger("py4j").setLevel(logging.WARNING)

        self.start_timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.start_time_epoch = time.perf_counter()

        # 1. Parse command-line arguments
        for i, arg in enumerate(args):
            if i == 0:
                self.job_arguments["py-file"] = arg
            else:
                item = arg.replace("--", "")
                key, value = item.split("=", 1)
                self.job_arguments[str(key)] = value
                if item.startswith("customJobArgs"):
                    custom_arg = item.replace("customJobArgs=", "").split("=", 1)
                    self.custom_job_args[custom_arg[0]] = custom_arg[1]

        self.debug_mode = self.job_arguments.get("debug") == "true"
        self.job_type = self.job_arguments.get("job_type", "default").strip()
        
        # Determine initial SSL verification setting from CLI (default to True)
        self.ssl_verify = self.job_arguments.get("ssl-verify", "true").lower() == "true"

        # 2. Setup appName, dates, and properties
        self.app_name = f"{self.job_arguments['client-id']}.{self.job_arguments['target-table']}"
        self.process_date = datetime.datetime.strptime(self.job_arguments["process-date"], "%Y-%m-%d").date()
        self.write_date = self.process_date

        self.job_properties = configparser.ConfigParser()
        self.job_properties.read(self.job_arguments["properties-file"])
        
        # Override SSL verification from properties if present
        try:
            prop_ssl_verify = self.get_specific_job_properties("default", "api.ssl_verify").lower()
            if prop_ssl_verify in ["true", "false"]:
                self.ssl_verify = prop_ssl_verify == "true"
        except (configparser.NoOptionError, configparser.NoSectionError):
            pass


        # 3. Fetch global configurations
        global_config_url = self.get_specific_job_properties("default", "global.config")
        global_configs = call_api(apiURL=global_config_url, httpMode="get", context=self).json()["message"]
        for item in global_configs["global_parameters"]:
            key = item["key"]
            if key.startswith("spark.") or key.startswith("session."):
                config_key = key.replace("session.", "", 1) if key.startswith("session.") else key
                self.spark_config[config_key] = item["value"]
                if key.startswith("spark"):
                    self.spark_default_options[key] = item["value"]
            elif key.startswith("audit"):
                self.audit_options[key.replace("audit.", "")] = item["value"]
            elif key.startswith("environment"):
                self.scope_env = item["value"].upper()

        # 4. Fetch job-specific context (target and source tables)
        context_api_url = f"{self.get_specific_job_properties('default', 'job.context')}{self.job_arguments.get('client-id')}/{self.job_arguments.get('target-table').replace('.', '/', 1)}"
        job_tables_config = call_api(apiURL=context_api_url, httpMode="get", context=self).json()["message"]
        
        self.io.process_tables_config(job_tables_config)

        if "keytab" in self.job_arguments and "principal" in self.job_arguments:
            self.spark_config["spark.kerberos.keytab"] = self.job_arguments["keytab"]
            self.spark_config["spark.kerberos.principal"] = self.job_arguments["principal"]

        if "metadata" in self.job_arguments:
            dq_rules_response = call_api(apiURL=f"{self.get_specific_job_properties('default', 'dq.rules')}{self.job_arguments['metadata']}", httpMode="get", context=self).json()
            if isinstance(dq_rules_response, dict) and "message" in dq_rules_response:
                self.dq_rules = dq_rules_response["message"]
            else:
                self.dq_rules = dq_rules_response

        # 5. Initialize Spark Session
        self._initialize_spark_session()

    def _initialize_spark_session(self):
        """
        Creates and initializes the PySpark `SparkSession`.
        
        Process Flow:
            1. Logs spark session generation.
            2. Builds a SparkSession configuration using loaded map.
            3. Registers Hive Support and gets/creates the context.
        """
        self.reporting.do_log("SETTING UP SparkSession")
        try:
            builder = SparkSession.builder.appName(self.app_name)
            if "local" not in self.job_arguments.get("master", ""):
                builder = builder.master(self.job_arguments["master"]) \
                                 .config(map=self.spark_config) \
                                 .enableHiveSupport()
            self.spark_session = builder.getOrCreate()
        except Exception as e:
            raise e

    def get_specific_job_properties(self, group_name, property_name):
        """
        Retrieves a singular inner property from within a config group block.

        Args:
            group_name (str): The configuration section.
            property_name (str): The key mapping to the stored value inside the configuration.

        Returns:
            str: The property configuration value.
        """
        return self.job_properties.get(group_name, property_name)

    def get_dictionary_from_properties(self, group_name):
        """
        Retrieves an entire property block as a dictionary mapped using `items`.

        Args:
            group_name (str): The specific configuration section to retrieve.

        Returns:
            dict: The dictionary dictionary mapping properties.
        """
        return dict(self.job_properties.items(group_name))

    def tear_down(self):
        """
        Stops the bound SparkSession when the execution framework naturally winds down.
        """
        self.reporting.do_log("stopping sparkSession")
        if self.spark_session:
            self.spark_session.stop
            self.spark_session = None