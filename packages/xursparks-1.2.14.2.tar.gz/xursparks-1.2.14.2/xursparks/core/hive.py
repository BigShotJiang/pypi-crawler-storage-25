from pyspark.sql import HiveContext
from pyspark.sql.types import *

class HiveService:
    """
    Manages Hive table and partition operations.
    """
    def __init__(self, context):
        """
        Initializes the HiveService instance with the provided context.

        Args:
            context (XursparksContext): The global application context providing access
                to reporting services and spark sessions.
        """
        self.context = context

    def create_hive_table(self):
        """
        Creates a Hive table if it doesn't already exist.

        Process Flow:
            1. Retrieves target table variables like database, table name, and partition column
               from the active context's `target_table`.
            2. Derives Hive data types from the active Spark `target_table_dataset`.
            3. Uses `HiveContext` to construct and execute a `CREATE TABLE IF NOT EXISTS` 
               query directly into the Hive metastore, storing the backing data as PARQUET.

        Major Variables:
            - `hive_database` (str): The Hive database to build the table in.
            - `hive_table` (str): The specific name of the target table.
            - `column_types` (str): A comma-terminated formatted string of column schema definitions.
        """
        target_table = self.context.target_table
        dataset = self.context.target_table_dataset

        hive_database = target_table.get("database_name")
        hive_table = target_table.get("table_name")
        partition_column = target_table.get("partition_name").lower()

        column_types = ", ".join([f"`{col}` {self._get_hive_data_type(data_type)}" for col, data_type in dataset.dtypes])

        hive_context = HiveContext(self.context.spark_session)
        hive_query = f"""
            CREATE TABLE IF NOT EXISTS `{hive_database}`.`{hive_table}` (
                {column_types}
            ) 
            PARTITIONED BY ({partition_column} string)
            STORED AS PARQUET
            LOCATION '{target_table["path"]}'
        """
        self.context.reporting.do_log(f'hive query(create if not exist): {hive_query}')
        hive_context.sql(hive_query)

    def register_partition(self, **kwargs):
        """
        Registers a new partition in the Hive metastore for the target table.

        Process Flow:
            1. Extracts partition-related metadata from keyword arguments or defaults to the context. 
            2. Determines if the target represents a multi-level partition array (`partition_cols`).
            3. Formats an `ALTER TABLE ADD IF NOT EXISTS PARTITION` SQL query.
            4. Executes the query in PySpark to finalize the metastore update for the target `target_table`.

        Args:
            **kwargs: Arbitrary keyword arguments used for overwriting partition specifics:
                - `partition_location` (str): The explicit path to point the new partition towards.
                - `partition_names` (list of tuples): Specifier for multi-column partitions.
                - `partition_name` (str): Explicit primary partition column to register.

        Major Variables:
            - `partition_spec` (str): The dynamic string defining the equality logic inside the query (e.g., "p_date='2023-01-01'").
            - `hive_query` (str): The completed SQL statement executed by `self.context.spark_session.sql`.
        """
        self.context.reporting.do_log('******************** Registering Partition to Hive *******************')
        
        target_table = self.context.target_table
        hive_database = target_table.get("database_name")
        hive_table = target_table.get("table_name")
        
        partition_location = kwargs.get("partition_location", self.generate_write_path())
        partition_names_arg = kwargs.get("partition_names")  # Expecting list of tuples: [("col1", "val1"), ...]
        partition_name_arg = kwargs.get("partition_name")

        if partition_name_arg is None and partition_names_arg is None:
            partition_cols = target_table.get("partition_name").lower().split(",")
            partition_format = target_table.get("partition_date_format")
            partition_value = self.context.write_date.strftime(partition_format)
            partition_spec = ",".join([f"{col}='{partition_value}'" for col in partition_cols])
        elif partition_names_arg:
            partition_spec = ",".join([f"{col}='{val}'" for col, val in partition_names_arg])
        else: # partition_name_arg is provided
            partition_value = self.context.write_date.strftime(target_table.get("partition_date_format"))
            partition_spec = f"{partition_name_arg}='{partition_value}'"

        hive_query = f"""
            ALTER TABLE {hive_database}.{hive_table}
            ADD IF NOT EXISTS PARTITION ({partition_spec})
            LOCATION '{partition_location}'
        """
        self.context.reporting.do_log(f'hive query(add partition): {hive_query}')
        self.context.spark_session.sql(hive_query)

    def generate_write_path(self):
        """
        Generates the full HDFS/S3 path for writing a partition.

        Process Flow:
            1. Loops over the sequence of configured `partition_names`.
            2. Appends each partition key-value component progressively deeper.
            3. Returns the final path URL formatted based on `target_table["path"]`.

        Returns:
            str: the HDFS/AWS/GCS partition path specific to `self.context.write_date`.
        """
        target_table = self.context.target_table
        partition_names = target_table["partition_name"].lower().split(",")
        partition_format = target_table["partition_date_format"]
        partition_value = self.context.write_date.strftime(partition_format)

        partition_path = ""
        for pname in partition_names:
            partition_path += f"{pname}={partition_value}/"
        
        return f'{target_table["path"]}{partition_path}'

    def _get_hive_data_type(self, spark_data_type_str):
        """
        Maps a PySpark data type string to its corresponding Hive data type string.

        Args:
            spark_data_type_str (str): The original type definition retrieved from 
                the PySpark `dtypes` collection (e.g., 'int', 'boolean').

        Returns:
            str: The mapped capitalized equivalent suitable for Hive queries (e.g., 'INT').
        """
        mapping = {
            "string": "STRING",
            "int": "INT",
            "bigint": "BIGINT",
            "float": "FLOAT",
            "double": "DOUBLE",
            "boolean": "BOOLEAN",
            "timestamp": "TIMESTAMP",
            "date": "DATE",
            "decimal": "DECIMAL" # May need precision/scale
        }
        # Find the base type (e.g., 'decimal(10,2)' -> 'decimal')
        base_type = spark_data_type_str.split('(')[0]
        return mapping.get(base_type, "STRING")