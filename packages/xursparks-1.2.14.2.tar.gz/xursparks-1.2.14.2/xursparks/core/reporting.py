import logging
import os
import smtplib
import ssl
import sys
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formataddr

#from xurpas_data_quality import DataReport
from xursparks.services.data_quality.data_report import DataReport
from xursparks.services.data_quality.main import XursparksDataQuality
from xursparks.tools.logger import Logger
from .utils import call_api, execute_subprocess


class ReportingService:
    """
    Handles reporting, auditing, data quality checks, and emailing.
    """
    def __init__(self, context):
        """
        Initializes the ReportingService mapping tightly to the global context.
        
        Args:
            context (XursparksContext): The global application context providing access
            to configurations, parameters, and Spark datasets.
        """
        self.context = context

    def do_log(self, message, level="info"):
        """
        Prints a message using the centralized Logger.
        
        Args:
            message (str): The log content to emit.
            level (str): The log level (debug, info, warning, etc.)
        """
        Logger().log(message, level=level)

    def send_email(self, **kwargs):
        """
        Sends an email using the configured SMTP server mapping context audit params.
        
        Process Flow:
            1. Retrieves SMTP credentials from `self.context.audit_options`.
            2. Builds a standard `MIMEMultipart` header map containing metadata mappings.
            3. Attaches any Base64 encoded document arrays provided in the payload.
            4. Emits physically via an authenticated `smtplib.SMTP` thread.
            
        Args:
            **kwargs: Arbitrary dictionary keywords expecting:
                - `subject` (str): Output string mapped to the subject line.
                - `to_email` (list): Output string map of addresses mapped into `To:`.
                - `message` (str): Payload.
                - `files` (list): Physical paths mapping to files to distribute.
                - `rename` (list): Explicit overwriting alias strings for those files.
                - `body_content_type` (str): HTML mapping configuration vs plain.
        """
        audit_options = self.context.audit_options
        smtp_server = audit_options["server"]
        smtp_port = audit_options["port"]
        from_email = audit_options["sender"]
        email_password = audit_options["password"]

        subject = str(kwargs.get("subject"))
        to_email = kwargs.get("to_email")
        message = str(kwargs.get("message"))
        files = kwargs.get("files")
        rename = kwargs.get("rename")
        body_content_type = kwargs.get("body_content_type")

        msg = MIMEMultipart()
        msg['Subject'] = subject
        msg['From'] = from_email
        msg['To'] = ', '.join(to_email)

        body = MIMEText(message, body_content_type or 'plain')
        msg.attach(body)

        if files:
            rename = rename or [os.path.basename(f) for f in files]
            for file_path, new_name in zip(files, rename):
                with open(file_path, 'rb') as attachment_file:
                    part = MIMEBase('application', "octet-stream")
                    part.set_payload(attachment_file.read())
                encoders.encode_base64(part)
                part.add_header('Content-Disposition', f'attachment; filename="{new_name}"')
                msg.attach(part)

        with smtplib.SMTP(smtp_server, smtp_port) as s:
            s.ehlo()
            s.starttls()
            s.login(from_email, email_password)
            s.sendmail(from_email, to_email, msg.as_string())

    def generate_data_quality_report(self, **kwargs):
        """
        Generates and emails a data quality HTML report using `xurpas_data_quality`.
        
        Process Flow:
            1. Consolidates configuration properties describing the email recipient list (comma delimited).
            2. Triggers `DataReport` to compile a Pandas analysis block and HTML asset based upon `target_table_dataset`.
            3. Distributes the resulting HTML artifact downstream leveraging `send_email`.
            
        Args:
            **kwargs: Configuration override flags.
                - `dq_title` (str): Report visual heading.
                - `dq_file_path` (str): Location explicit to save output.
                - `dq_df` (pandas.DataFrame): Implicit data payload overriding dataset mappings.
        """
        ctx = self.context
        title = kwargs.get("dq_title", f'{ctx.target_table.get("database_name")}_{ctx.target_table.get("table_name")}')
        file_path = kwargs.get("dq_file_path", f'{os.path.dirname(__file__)}/{title}.html')
        df = kwargs.get("dq_df", ctx.target_table_dataset.toPandas())
        message = kwargs.get("dq_message", 'Please find the attached data quality report.')
        has_attachment = not (kwargs.get("dq_attachments", "").upper().startswith('F'))

        # Build recipient list
        recipients = set(ctx.audit_options.get("recipients", "").split(','))
        if kwargs.get("dq_recipients"):
            recipients.update(kwargs.get("dq_recipients").split(','))
        if ctx.optional_params.get("audit.recipients"):
            recipients.update(ctx.optional_params.get("audit.recipients").split(','))
        email_recipients = [r for r in recipients if r]

        subject = f'[{ctx.scope_env}] Data Profile [{title}] - {ctx.process_date}'

        if has_attachment:
            report = DataReport(df=df, report_name=title, file_path=file_path, **kwargs)
            report.to_file()
            files = [file_path]
            rename = [f'{title}.html']
            self.send_email(subject=subject, message=message, to_email=email_recipients, files=files, rename=rename, body_content_type='html')
        else:
            self.send_email(subject=subject, message=message, to_email=email_recipients, body_content_type='html')

    def run_data_quality_checks(self, compress: bool = False, content_type:str=None, debug:bool=False, export_body:dict=None):
        """
        Executes data quality checks mapping external rule blocks and posts the results back to an API cleanly.
        
        Process Flow:
            1. Spawns `XursparksDataQuality` validating row rules externally configured.
            2. Traverses and distills the evaluations preserving all payload arrays for comprehensive reporting.
            3. Compresses HTTP payloads explicitly resolving Entity size overload constraints if `compress` is toggled.
            4. Triggers `call_api` sequentially returning status messages accurately.
            
        Args:
            compress (bool): Defaults to False. Will natively implement HTTP gzip compression to `call_api`.
            content_type (str): Defaults to None. Will set the content type of the request.
            debug (bool): Defaults to False. Will enable debug mode.
            export_body (dict or bool): Defaults to False. If a dict, can contain 'filename' and 'path'.
        Returns:
            dict: Complex nested array string describing the entire payload generated.
            
        Major Variables:
            - `all_results` (dict): Complete list arrays dictating total validations output.
            - `violation_results` (dict): Extracted subset mapped to rules flagged mapping anomalies directly.
        """
        ctx = self.context
        if not ctx.target_table_dataset or not ctx.dq_rules:
            raise ValueError("targetTableDataset and dq_rules must be initialized.")

        try:
            dq_checker = XursparksDataQuality(df=ctx.target_table_dataset, dq_rules=ctx.dq_rules, process_date=ctx.process_date)
        except ValueError as e:
            raise ValueError(f"Failed to initialize Data Quality checker: {e}. Received dq_rules type: {type(ctx.dq_rules)}. Content: {str(ctx.dq_rules)[:200]}...")
        dq_evaluation_results = dq_checker.run_checks()

        # Use all results to ensure all evaluations are reported across the entire dataset.
        all_results = dq_evaluation_results.get("results", {})
        violation_results = {
            row_id: rules for row_id, rules in all_results.items() 
            if row_id == "1" or any(r.get("dq_rule_result") != "1" for r in rules)
        }
        violation_results_count = sum(1 for rules in violation_results.values() if any(r.get("dq_rule_result") != "1" for r in rules))
        
        payload = {**dq_evaluation_results, "results": all_results}
        
        self.do_log(f"[DQ] Total rows: {len(all_results)} | Violation rows: {violation_results_count}")

        dq_results_endpoint = ctx.get_specific_job_properties("default", "dq.results")
        try:
            api_response = call_api(apiURL=dq_results_endpoint, httpMode="POST", body=payload, 
                                    compress=compress, context=ctx, content_type=content_type, debug=debug, export_body=export_body)
            self.do_log(f"API response status code: {api_response.status_code}")
            api_response.raise_for_status()
        except Exception as e:
            raise Exception(f"Failed to post data quality results to {dq_results_endpoint}: {e}")

        return dq_evaluation_results