# Make core a package
