import collections
import datetime
import gzip
import json
import os
import re
import subprocess
import sys

import pandas as pd
import requests
from dateutil.relativedelta import relativedelta
from functools import reduce

from xursparks.tools.logger import Logger

def _truncate_json_recursive(obj, limit=10, is_root=True):
    """
    Recursively truncates a JSON-compatible object (dict or list).
    
    Args:
        obj: The object to truncate.
        limit (int): The maximum number of items to keep at the current level.
        is_root (bool): True if this is the root level (uses limit=10), False otherwise (uses limit=5).
    """
    current_limit = 10 if is_root else 5
    
    if isinstance(obj, dict):
        truncated_dict = {}
        keys = list(obj.keys())
        for key in keys[:current_limit]:
            truncated_dict[key] = _truncate_json_recursive(obj[key], is_root=False)
        if len(keys) > current_limit:
            truncated_dict["... (truncated)"] = f"Total items: {len(keys)}"
        return truncated_dict
    
    elif isinstance(obj, (list, tuple)):
        truncated_list = [_truncate_json_recursive(item, is_root=False) for item in obj[:current_limit]]
        if len(obj) > current_limit:
            truncated_list.append(f"... (truncated, total: {len(obj)})")
        return truncated_list
    
    return obj


def call_api(**kwargs):
    """
    A generic wrapper for making HTTP REST requests asynchronously mapping job contexts.
    
    Process Flow:
        1. Extracts target `apiURL` strings, payload arguments, and context objects.
        2. Retrieves standard Bearer tokens globally natively configured by Xursparks.
        3. For GET requests, issues the operation returning standard output.
        4. For POST requests, conditionally implements payload compression (`gzip`) if flagged,
           otherwise transmitting as plain `application/json`.
           
    Args:
        **kwargs: Valid dictionary parameters mapping overrides including:
            - `apiURL` (str): Output endpoint mapping API routes.
            - `httpMode` (str): Typically "GET" or "POST".
            - `body` (dict): Data payload dictionaries to attach to POST calls.
            - `headers` (dict): Headers to attach to the request.
            - `compress` (bool): Defaults logic enabling JSON payload gzip compression.
            - `context` (XursparksContext): Standard globally accessible context instance.
            - `content_type` (str): Defaults to "application/json".
            - `debug` (bool): Defaults logic enabling debug mode.
            - `export_body` (dict or bool): If provided as a dict, it can contain 'filename' and 'path'. 
              If True, uses defaults.
            
    Returns:
        requests.Response: Complete HTTP execution response dict.
    """
    api_url = kwargs.get("apiURL")
    http_mode = kwargs.get("httpMode", "GET")
    body = kwargs.get("body")
    headers = kwargs.get("headers", None)
    compress = kwargs.get("compress", False)
    context = kwargs.get("context")
    content_type = kwargs.get("content_type", "application/json")
    debug = kwargs.get("debug", False)
    export_body = kwargs.get("export_body", False)

    if headers is None:
        header_token = context.get_specific_job_properties("default", "api.token")
        headers = {'Authorization': header_token}

    if debug:
        truncated_kwargs = _truncate_json_recursive(kwargs, is_root=True)
        Logger().debug("call_api kwargs (Truncated):")
        Logger().debug(json.dumps(truncated_kwargs, indent=4, default=str))

    if export_body and body:
        try:
            # Determine target filename and path
            export_config = export_body if isinstance(export_body, dict) else {}
            
            # Get the executing script context to establish defaults
            try:
                # sys.argv[0] is typically the path to the script being run
                script_path = os.path.abspath(sys.argv[0])
                default_dir = os.path.dirname(script_path)
                default_filename = os.path.basename(script_path).rsplit('.', 1)[0] + "_body.json"
            except (AttributeError, IndexError):
                # Fallback to current working directory if sys.argv is unavailable
                default_dir = os.getcwd()
                default_filename = "call_api_body_export.json"

            # Use provided values from dict or fall back to script-based defaults
            final_path = export_config.get("path") or default_dir
            final_filename = export_config.get("filename") or default_filename

            if debug:
                Logger().debug(f"Exporting body to {final_path}/{final_filename}")
            
            # Ensure path exists
            if not os.path.exists(final_path):
                os.makedirs(final_path, exist_ok=True)
                
            file_path = os.path.join(final_path, final_filename)
            
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(json.dumps(body, indent=4, default=str))
            
            if debug:
                Logger().debug(f"Body exported to {file_path}")
        except Exception as e:
            if debug:
                Logger().debug(f"Failed to export body: {e}")

    verify = kwargs.get("verify", getattr(context, "ssl_verify", True))

    if not verify:
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    if http_mode.upper() == "GET":
        return requests.get(api_url, headers=headers, verify=verify)
    elif http_mode.upper() == "POST":
        if body:
            if compress:
                json_bytes = json.dumps(body).encode("utf-8")
                compressed = gzip.compress(json_bytes)
                headers.update({'Content-Encoding': 'gzip', 'Content-Type': content_type})
                if debug:
                    Logger().debug(f'apiURL: {api_url}')
                    Logger().debug(f'headers: {headers}')
                    Logger().debug(f'compressed: {compressed}')
                return requests.post(api_url, headers=headers, data=compressed, verify=verify)
            else:
                headers.update({'Content-Type': content_type})
                if debug:
                    Logger().debug(f'apiURL: {api_url}')
                    Logger().debug(f'headers: {headers}')
                    Logger().debug(f'body: {body}')
                return requests.post(api_url, headers=headers, json=body, verify=verify)
        else:
            return requests.post(api_url, headers=headers, verify=verify)

    else:
        raise Exception("Invalid httpMode.")

def parse_date_pattern(date_pattern, process_date):
    """
    Parses a dynamic custom date pattern string representation into an explicit datetime object.
    
    Process Flow:
        1. Identifies if the core logic revolves around actual CURRENT_DATE runtime or script logic TRANSACTION_DATE.
        2. Applies standard `%Y-%m-%d` strict strptime casting if standard dates are matched.
        3. Identifies and executes standard chronological mappings using `relativedelta` or `DateOffset` 
           expressions sequentially against base markers (e.g. MINUS_MONTHS_2).
        4. Standardizes boundary matching (e.g. "FIRST", "LAST") converting explicitly.
        
    Args:
        date_pattern (str): The configuration schema defining string extraction mappings logic.
        process_date (datetime): Execution bound job date string.
        
    Returns:
        datetime: Complete localized Python DateTime configuration mapping the finalized string representation.
        None: When parsing wildcard sequences mapped mapping "*".
        
    Major Variables:
        - `base_date` (datetime): Initial chronological hook parsing begins processing from.
        - `derived_date` (datetime): Continuous modification variable eventually output.
    """
    if not date_pattern or date_pattern == "*":
        return None

    if "TRANSACTION" in date_pattern or "CURRENT" in date_pattern:
        if "TRANSACTION_DATE" in date_pattern:
            base_date = process_date
        else: # CURRENT_DATE
            base_date = datetime.datetime.now()
    else:
        try:
            return datetime.datetime.strptime(date_pattern, "%Y-%m-%d")
        except ValueError:
            # Assuming it's a format string if not a keyword
            return datetime.datetime.now().strftime(date_pattern)

    derived_date = pd.to_datetime(base_date)

    # Years
    match = re.search(r"PLUS_YEARS_(\d+)", date_pattern)
    if match: derived_date += pd.DateOffset(years=int(match.group(1)))
    match = re.search(r"MINUS_YEARS_(\d+)", date_pattern)
    if match: derived_date -= pd.DateOffset(years=int(match.group(1)))

    # Months
    match = re.search(r"PLUS_MONTHS_(\d+)", date_pattern)
    if match: derived_date += pd.DateOffset(months=int(match.group(1)))
    match = re.search(r"MINUS_MONTHS_(\d+)", date_pattern)
    if match: derived_date -= pd.DateOffset(months=int(match.group(1)))

    # Weeks
    match = re.search(r"PLUS_WEEKS_(\d+)", date_pattern)
    if match: derived_date += pd.DateOffset(weeks=int(match.group(1)))
    match = re.search(r"MINUS_WEEKS_(\d+)", date_pattern)
    if match: derived_date -= pd.DateOffset(weeks=int(match.group(1)))

    # Days
    match = re.search(r"PLUS_DAYS_(\d+)", date_pattern)
    if match: derived_date += pd.DateOffset(days=int(match.group(1)))
    match = re.search(r"MINUS_DAYS_(\d+)", date_pattern)
    if match: derived_date -= pd.DateOffset(days=int(match.group(1)))

    # Month boundaries
    if "FIRST" in date_pattern:
        derived_date = derived_date.replace(day=1)
    if "LAST" in date_pattern:
        # Go to the first day of the next month and subtract one day
        derived_date = (derived_date.replace(day=1) + pd.DateOffset(months=1)) - pd.DateOffset(days=1)

    return derived_date.to_pydatetime()

def execute_subprocess(options):
    """
    Executes an arbitrary shell sequence safely capturing output as strings context mapping.
    
    Process Flow:
        1. Ensures mapped definitions contain a specific `command`.
        2. Logs diagnostic data parameters internally.
        3. Consolidates Python `subprocess.run` mapping dictionary flags enabling or preventing
           shell wrapping and text formatting explicitly.
           
    Args:
        options (dict): Specialized runtime string modifications parsing mapping execution details
            like `command`, `shell`, `capture_output`, `text`.
            
    Returns:
        str: Captured `stdout` execution stream results mapping.
    """
    command = options.get("command")
    if not command:
        return ""
        
    Logger().debug("------------ExecuteSubProcess---------------")
    Logger().debug("options: " + str(options))
    
    result = subprocess.run(
        [command],
        shell=options.get("shell", False),
        capture_output=options.get("capture_output", False),
        text=options.get("text", False),
        check=False  # Avoid raising exception on non-zero exit codes
    )
    return result.stdout

def safe_union(dfs, checkpoint=False):
    """
    Safely unions a list of DataFrames, avoiding deep lineage and GC overhead.
    
    Args:
        dfs (list): List of PySpark DataFrames to union.
        checkpoint (bool): If True, performs a localCheckpoint to truncate lineage.
        
    Returns:
        DataFrame: The unioned DataFrame.
    """
    if not dfs:
        return None
    
    if len(dfs) == 1:
        return dfs[0]
        
    # Binary union is more efficient for Spark plan optimization than linear reduce.
    def binary_union(dfs_list):
        if len(dfs_list) == 1:
            return dfs_list[0]
        if len(dfs_list) == 2:
            return dfs_list[0].union(dfs_list[1])
            
        mid = len(dfs_list) // 2
        return binary_union(dfs_list[:mid]).union(binary_union(dfs_list[mid:]))
    
    result = binary_union(dfs)
    
    # Truncate lineage if requested or if there are many unions to prevent GC overhead.
    if checkpoint or len(dfs) > 10:
        try:
            result = result.localCheckpoint()
        except Exception:
            # Fallback if localCheckpoint is not supported in the environment
            pass
            
    return result

def safe_union(dfs, checkpoint=False):
    """
    Safely unions a list of DataFrames, avoiding deep lineage and GC overhead.
    
    Args:
        dfs (list): List of PySpark DataFrames to union.
        checkpoint (bool): If True, performs a localCheckpoint to truncate lineage.
        
    Returns:
        DataFrame: The unioned DataFrame.
    """
    if not dfs:
        return None
    
    if len(dfs) == 1:
        return dfs[0]
    
    from functools import reduce
    
    # Binary union is more efficient for Spark plan optimization than linear reduce.
    def binary_union(dfs_list):
        if len(dfs_list) == 1:
            return dfs_list[0]
        if len(dfs_list) == 2:
            return dfs_list[0].union(dfs_list[1])
            
        mid = len(dfs_list) // 2
        return binary_union(dfs_list[:mid]).union(binary_union(dfs_list[mid:]))
    
    result = binary_union(dfs)
    
    # Truncate lineage if requested or if there are many unions to prevent GC overhead.
    if checkpoint or len(dfs) > 10:
        try:
            result = result.localCheckpoint()
        except Exception:
            # Fallback if localCheckpoint is not supported in the environment
            pass
            
    return result


def safe_union(dfs, checkpoint=False):
    """
    Safely unions a list of DataFrames, avoiding deep lineage and GC overhead.
    
    Args:
        dfs (list): List of PySpark DataFrames to union.
        checkpoint (bool): If True, performs a localCheckpoint to truncate lineage.
        
    Returns:
        DataFrame: The unioned DataFrame.
    """
    if not dfs:
        return None
    
    if len(dfs) == 1:
        return dfs[0]
    
    from functools import reduce
    
    # Binary union is more efficient for Spark plan optimization than linear reduce.
    def binary_union(dfs_list):
        if len(dfs_list) == 1:
            return dfs_list[0]
        if len(dfs_list) == 2:
            return dfs_list[0].union(dfs_list[1])
            
        mid = len(dfs_list) // 2
        return binary_union(dfs_list[:mid]).union(binary_union(dfs_list[mid:]))
    
    result = binary_union(dfs)
    
    # Truncate lineage if requested or if there are many unions to prevent GC overhead.
    if checkpoint or len(dfs) > 10:
        try:
            result = result.localCheckpoint()
        except Exception:
            # Fallback if localCheckpoint is not supported in the environment
            pass
            
    return result


def safe_union(dfs, checkpoint=False):
    """
    Safely unions a list of DataFrames, avoiding deep lineage and GC overhead.
    
    Args:
        dfs (list): List of PySpark DataFrames to union.
        checkpoint (bool): If True, performs a localCheckpoint to truncate lineage.
        
    Returns:
        DataFrame: The unioned DataFrame.
    """
    if not dfs:
        return None
    
    if len(dfs) == 1:
        return dfs[0]
    
    from functools import reduce
    
    # Binary union is more efficient for Spark plan optimization than linear reduce.
    def binary_union(dfs_list):
        if len(dfs_list) == 1:
            return dfs_list[0]
        if len(dfs_list) == 2:
            return dfs_list[0].union(dfs_list[1])
            
        mid = len(dfs_list) // 2
        return binary_union(dfs_list[:mid]).union(binary_union(dfs_list[mid:]))
    
    result = binary_union(dfs)
    
    # Truncate lineage if requested or if there are many unions to prevent GC overhead.
    if checkpoint or len(dfs) > 10:
        try:
            result = result.localCheckpoint()
        except Exception:
            # Fallback if localCheckpoint is not supported in the environment
            pass
            
    return result


def safe_union(dfs, checkpoint=False):
    """
    Safely unions a list of DataFrames, avoiding deep lineage and GC overhead.
    
    Args:
        dfs (list): List of PySpark DataFrames to union.
        checkpoint (bool): If True, performs a localCheckpoint to truncate lineage.
        
    Returns:
        DataFrame: The unioned DataFrame.
    """
    if not dfs:
        return None
    
    if len(dfs) == 1:
        return dfs[0]
    
    from functools import reduce
    
    # Binary union is more efficient for Spark plan optimization than linear reduce.
    def binary_union(dfs_list):
        if len(dfs_list) == 1:
            return dfs_list[0]
        if len(dfs_list) == 2:
            return dfs_list[0].union(dfs_list[1])
            
        mid = len(dfs_list) // 2
        return binary_union(dfs_list[:mid]).union(binary_union(dfs_list[mid:]))
    
    result = binary_union(dfs)
    
    # Truncate lineage if requested or if there are many unions to prevent GC overhead.
    if checkpoint or len(dfs) > 10:
        try:
            result = result.localCheckpoint()
        except Exception:
            # Fallback if localCheckpoint is not supported in the environment
            pass
            
    return result


def safe_union(dfs, checkpoint=False):
    """
    Safely unions a list of DataFrames, avoiding deep lineage and GC overhead.
    
    Args:
        dfs (list): List of PySpark DataFrames to union.
        checkpoint (bool): If True, performs a localCheckpoint to truncate lineage.
        
    Returns:
        DataFrame: The unioned DataFrame.
    """
    if not dfs:
        return None
    
    if len(dfs) == 1:
        return dfs[0]
    
    from functools import reduce
    
    # Binary union is more efficient for Spark plan optimization than linear reduce.
    def binary_union(dfs_list):
        if len(dfs_list) == 1:
            return dfs_list[0]
        if len(dfs_list) == 2:
            return dfs_list[0].union(dfs_list[1])
            
        mid = len(dfs_list) // 2
        return binary_union(dfs_list[:mid]).union(binary_union(dfs_list[mid:]))
    
    result = binary_union(dfs)
    
    # Truncate lineage if requested or if there are many unions to prevent GC overhead.
    if checkpoint or len(dfs) > 10:
        try:
            result = result.localCheckpoint()
        except Exception:
            # Fallback if localCheckpoint is not supported in the environment
            pass
            
    return result


def safe_union(dfs, checkpoint=False):
    """
    Safely unions a list of DataFrames, avoiding deep lineage and GC overhead.
    
    Args:
        dfs (list): List of PySpark DataFrames to union.
        checkpoint (bool): If True, performs a localCheckpoint to truncate lineage.
        
    Returns:
        DataFrame: The unioned DataFrame.
    """
    if not dfs:
        return None
    
    if len(dfs) == 1:
        return dfs[0]
    
    from functools import reduce
    
    # Binary union is more efficient for Spark plan optimization than linear reduce.
    def binary_union(dfs_list):
        if len(dfs_list) == 1:
            return dfs_list[0]
        if len(dfs_list) == 2:
            return dfs_list[0].union(dfs_list[1])
            
        mid = len(dfs_list) // 2
        return binary_union(dfs_list[:mid]).union(binary_union(dfs_list[mid:]))
    
    result = binary_union(dfs)
    
    # Truncate lineage if requested or if there are many unions to prevent GC overhead.
    if checkpoint or len(dfs) > 10:
        try:
            result = result.localCheckpoint()
        except Exception:
            # Fallback if localCheckpoint is not supported in the environment
            pass
            
    return result


def safe_union(dfs, checkpoint=False):
    """
    Safely unions a list of DataFrames, avoiding deep lineage and GC overhead.
    
    Args:
        dfs (list): List of PySpark DataFrames to union.
        checkpoint (bool): If True, performs a localCheckpoint to truncate lineage.
        
    Returns:
        DataFrame: The unioned DataFrame.
    """
    if not dfs:
        return None
    
    if len(dfs) == 1:
        return dfs[0]
    
    from functools import reduce
    
    # Binary union is more efficient for Spark plan optimization than linear reduce.
    def binary_union(dfs_list):
        if len(dfs_list) == 1:
            return dfs_list[0]
        if len(dfs_list) == 2:
            return dfs_list[0].union(dfs_list[1])
            
        mid = len(dfs_list) // 2
        return binary_union(dfs_list[:mid]).union(binary_union(dfs_list[mid:]))
    
    result = binary_union(dfs)
    
    # Truncate lineage if requested or if there are many unions to prevent GC overhead.
    if checkpoint or len(dfs) > 10:
        try:
            result = result.localCheckpoint()
        except Exception:
            # Fallback if localCheckpoint is not supported in the environment
            pass
            
    return result


def safe_union(dfs, checkpoint=False):
    """
    Safely unions a list of DataFrames, avoiding deep lineage and GC overhead.
    
    Args:
        dfs (list): List of PySpark DataFrames to union.
        checkpoint (bool): If True, performs a localCheckpoint to truncate lineage.
        
    Returns:
        DataFrame: The unioned DataFrame.
    """
    if not dfs:
        return None
    
    if len(dfs) == 1:
        return dfs[0]
    
    from functools import reduce
    
    # Binary union is more efficient for Spark plan optimization than linear reduce.
    def binary_union(dfs_list):
        if len(dfs_list) == 1:
            return dfs_list[0]
        if len(dfs_list) == 2:
            return dfs_list[0].union(dfs_list[1])
            
        mid = len(dfs_list) // 2
        return binary_union(dfs_list[:mid]).union(binary_union(dfs_list[mid:]))
    
    result = binary_union(dfs)
    
    # Truncate lineage if requested or if there are many unions to prevent GC overhead.
    if checkpoint or len(dfs) > 10:
        try:
            result = result.localCheckpoint()
        except Exception:
            # Fallback if localCheckpoint is not supported in the environment
            pass
            
    return result


def safe_union(dfs, checkpoint=False):
    """
    Safely unions a list of DataFrames, avoiding deep lineage and GC overhead.
    
    Args:
        dfs (list): List of PySpark DataFrames to union.
        checkpoint (bool): If True, performs a localCheckpoint to truncate lineage.
        
    Returns:
        DataFrame: The unioned DataFrame.
    """
    if not dfs:
        return None
    
    if len(dfs) == 1:
        return dfs[0]
    
    from functools import reduce
    
    # Binary union is more efficient for Spark plan optimization than linear reduce.
    def binary_union(dfs_list):
        if len(dfs_list) == 1:
            return dfs_list[0]
        if len(dfs_list) == 2:
            return dfs_list[0].union(dfs_list[1])
            
        mid = len(dfs_list) // 2
        return binary_union(dfs_list[:mid]).union(binary_union(dfs_list[mid:]))
    
    result = binary_union(dfs)
    
    # Truncate lineage if requested or if there are many unions to prevent GC overhead.
    if checkpoint or len(dfs) > 10:
        try:
            result = result.localCheckpoint()
        except Exception:
            # Fallback if localCheckpoint is not supported in the environment
            pass
            
    return result


def safe_union(dfs, checkpoint=False):
    """
    Safely unions a list of DataFrames, avoiding deep lineage and GC overhead.
    
    Args:
        dfs (list): List of PySpark DataFrames to union.
        checkpoint (bool): If True, performs a localCheckpoint to truncate lineage.
        
    Returns:
        DataFrame: The unioned DataFrame.
    """
    if not dfs:
        return None
    
    if len(dfs) == 1:
        return dfs[0]
    
    from functools import reduce
    
    # Binary union is more efficient for Spark plan optimization than linear reduce.
    def binary_union(dfs_list):
        if len(dfs_list) == 1:
            return dfs_list[0]
        if len(dfs_list) == 2:
            return dfs_list[0].union(dfs_list[1])
            
        mid = len(dfs_list) // 2
        return binary_union(dfs_list[:mid]).union(binary_union(dfs_list[mid:]))
    
    result = binary_union(dfs)
    
    # Truncate lineage if requested or if there are many unions to prevent GC overhead.
    if checkpoint or len(dfs) > 10:
        try:
            result = result.localCheckpoint()
        except Exception:
            # Fallback if localCheckpoint is not supported in the environment
            pass
            
    return result
