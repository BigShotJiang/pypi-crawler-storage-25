print(type(len))
