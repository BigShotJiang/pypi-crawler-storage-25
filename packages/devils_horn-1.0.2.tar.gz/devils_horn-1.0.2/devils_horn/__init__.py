import string
import argparse
from rich import print as pr
from rich.align import Align

class DevilHorn:
    def __init__(self):
        self.next_val = 0

    def devils_horn(self, key, display: bool = False):
        self.next_val = 0

        width = 35
        middle_gap = 10

        total_left = 0
        total_right = 0
        total_horns = key

        strsw = " " + string.ascii_lowercase + "_=/"

        for k in range(1, key + 1):

            l_inner = []
            for _ in range(11):
                l_inner.append(self.next_val)
                self.next_val = 1 if self.next_val == (len(strsw) - 1) else self.next_val + 1

            l_outer = [None]
            for _ in range(10):
                l_outer.append(self.next_val)
                self.next_val = 1 if self.next_val == (len(strsw) - 1) else self.next_val + 1

            r_inner = []
            for _ in range(11):
                r_inner.append(self.next_val)
                self.next_val = 1 if self.next_val == (len(strsw) - 1) else self.next_val + 1

            r_outer = [None]
            for _ in range(10):
                r_outer.append(self.next_val)
                self.next_val = 1 if self.next_val == (len(strsw) - 1) else self.next_val + 1

            sub_left = sum(l_inner) + sum(v for v in l_outer if v is not None)
            sub_right = sum(r_inner) + sum(v for v in r_outer if v is not None)

            total_left += sub_left
            total_right += sub_right

            if display:
                print(f"Devil's Horn {k}:\n")

            for i in range(11):
                val_l_in = str(l_inner[i])
                val_l_out = str(l_outer[i]) if l_outer[i] is not None else ""

                val_r_in = str(r_inner[i])
                val_r_out = str(r_outer[i]) if r_outer[i] is not None else ""

                if i == 0:
                    offset, gap = 0, 0
                elif i < 6:
                    offset, gap = -i, i * 2
                else:
                    offset, gap = -(10 - i), i * 2

                left_side = f"{val_l_in:>{width + offset}}{' ' * gap}{val_l_out:<3}"
                right_side = f"{' ' * middle_gap}{val_r_in:>{5 + offset}}{' ' * gap}{val_r_out}"

                if display:
                    pr(Align.left(left_side + right_side))

            if display:
                print("\n")

        return total_left, total_right, total_left + total_right, total_horns

    # ================= ENCRYPT =================
    def encrypt_message(self, message, display: bool = False):
        idx = []
        alphabet = " " + string.ascii_lowercase + string.punctuation

        total_left = 0
        total_right = 0
        total_sum = 0
        total_horns_used = 0
        lolo = 0

        for char in message.lower():
            if char in alphabet:
                index = alphabet.index(char)
                value = self.devils_horn(index, display=display)

                idx.append(str(value[2]))

                total_left += value[0]
                total_right += value[1]
                total_sum += value[2]
                total_horns_used += value[3]
                lolo += index

        return ":".join(idx), total_left, total_right, total_sum, total_horns_used, lolo

    # ================= DECRYPT =================
    def decrypt_message(self, encrypted_message):
        alphabet = " " + string.ascii_lowercase + string.punctuation

        forward_map = {}

        for char in alphabet:
            index = alphabet.index(char)
            value = self.devils_horn(index, display=False)
            forward_map[value[2]] = char

        decrypted = []
        numbers = encrypted_message.split(":")

        for num in numbers:
            if num.isdigit():
                decrypted.append(forward_map.get(int(num), "?"))

        return decrypted


# ================= CLI =================
def main():
    parser = argparse.ArgumentParser(description="Devil Horn Encryption Tool")

    parser.add_argument("-m", "--message", type=str, required=True, help="Message to encrypt")
    parser.add_argument("-d", "--display", action="store_true", help="Show horn visualization")

    args = parser.parse_args()

    dh = DevilHorn()

    encrypted, left, right, total, horns_used, lolo = dh.encrypt_message(
        args.message,
        display=args.display
    )

    decrypted = dh.decrypt_message(encrypted)

    pr("\n[bold red]=== DEVIL HORN RESULTS ===[/bold red]\n")

    pr(f"[green]Original:[/green] {args.message}")
    pr(f"[yellow]Encrypted:[/yellow] {encrypted}")
    pr(f"[cyan]Decrypted:[/cyan] {''.join(decrypted)}\n")

    pr(f"[magenta]Total Left:[/magenta] {left}")
    pr(f"[magenta]Total Right:[/magenta] {right}")
    pr(f"[magenta]Grand Total:[/magenta] {total}")
    pr(f"[magenta]Horns Used:[/magenta] {horns_used}")
    pr(f"[magenta]Lolo Sum:[/magenta] {lolo}")


if __name__ == "__main__":
    main()