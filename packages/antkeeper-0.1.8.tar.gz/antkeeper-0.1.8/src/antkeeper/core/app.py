"""Application framework for registering and managing workflow handlers.

Public API
----------
App
    Central registry for workflow handlers with decorator-based registration.
    Create one ``App`` instance per application, register handlers with
    ``@app.handler``, then pass the instance to a ``Runner`` for execution.
run_workflow
    Helper function for executing an ordered chain of handler steps with
    state threading and per-step persistence.

Internal helpers
----------------
_app_env
    Context manager that temporarily sets ``os.environ`` variables for the
    duration of a handler invocation and restores originals on exit.  Used
    internally by ``Runner``; not part of the public API.
"""
from __future__ import annotations

import functools
import os
from contextlib import contextmanager
from typing import Any, Callable, Generator, TYPE_CHECKING

from opentelemetry import trace

from antkeeper.core.domain import Handler, State

if TYPE_CHECKING:
    from antkeeper.core.runner import Runner


# -- Core ----------------------------------------------------------------------


@contextmanager
def _app_env(env: dict[str, Any] | None) -> Generator[None]:
    """Set environment variables for the duration of a block, then restore originals.

    A no-op context manager when ``env`` is ``None`` or an empty dict. For non-empty
    ``env``, saves the current values of all named variables, sets them in
    ``os.environ`` (converting each value with ``str()``), yields control, then
    restores the saved values in a ``finally`` block so that cleanup is guaranteed
    even if the body raises.

    If ``str()`` conversion raises for any value the exception propagates immediately;
    the ``finally`` block still restores any variables that were already set.

    Args:
        env: A mapping of environment variable names to values, or ``None``.

    Yields:
        None
    """
    if not env:
        yield
        return

    saved: dict[str, str | None] = {k: os.environ.get(k) for k in env}
    try:
        for k, v in env.items():
            os.environ[k] = str(v)
        yield
    finally:
        for k, original in saved.items():
            if original is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = original


class App:
    """Central registry for workflow handlers.

    The App class manages handler registration and retrieval, allowing workflows
    to be defined as decorated functions and later executed by runners. Each app
    instance maintains its own handler registry and log directory configuration.

    Example:
        >>> app = App(log_dir="logs/")
        >>> @app.handler
        ... def my_workflow(runner: Runner, state: State) -> State:
        ...     return {**state, "result": "done"}

    Attributes:
        handlers: Dictionary mapping handler names to their functions.
        log_dir: Directory path where Runner instances will write log files, or
            a callable that accepts a Runner and returns the path. Resolved once
            per Runner at initialization time.
        worktree_dir: Directory path where git worktrees will be created.
        state_dir: Directory path where Runner instances will write state files.
        env: Optional dict of environment variable names to values. Values may
            be callables that accept a Runner and return the resolved value.
            Callables are evaluated per-handler invocation with the active
            Runner passed as the argument, then applied to os.environ for the
            duration of that invocation and restored afterward.
    """
    def __init__(self, log_dir: str | Callable[[Runner], str] = "agents/logs/", worktree_dir: str = "trees/", state_dir: str = ".antkeeper/state/", env: dict[str, Any | Callable[[Runner], Any]] | None = None, handlers: dict[str, Callable] | None = None) -> None:
        """Initialize a new App instance.

        Creates an empty handler registry and sets directory paths for logs,
        worktrees, and state files that will be used by Runner instances.

        Args:
            log_dir: Directory for log files, or a callable accepting (runner)
                that returns the directory path. Defaults to "agents/logs/".
            worktree_dir: Directory for git worktrees. Defaults to "trees/".
            state_dir: Directory for state files. Defaults to ".antkeeper/state/".
            env: Optional dict of environment variable names to values. Values
                may be callables accepting (runner) that return the value.
                When set, values are resolved per handler invocation, exported
                to os.environ before each handler runs, and restored afterward.
                Static values are converted to str().
            handlers: Optional dict of pre-registered handlers to merge in.
        """
        self.handlers = {}
        self.log_dir = log_dir
        self.worktree_dir = worktree_dir
        self.state_dir = state_dir
        self.env = env
        if handlers:
            self.handlers.update(handlers)

    def add_handler(self, fn: Handler) -> None:
        """Register a function as a handler using its __name__ as the key.

        Programmatic equivalent of @app.handler. If a handler with the same
        name already exists, it is overwritten.

        Args:
            fn: The handler function to register.
        """
        self.handlers[fn.__name__] = fn

    def handler(self, fn: Handler) -> Handler:
        """Register a function as a workflow handler.

        This decorator registers a workflow handler function and wraps it for execution.
        The handler's name becomes its registry key for lookup by runners.

        Args:
            fn: A callable that accepts a Runner and State and returns a State.
                The function's name is used as the handler key.

        Returns:
            The wrapped handler function that can be invoked by runners.
        """
        @functools.wraps(fn)
        def wrapper(runner: Runner, state: State) -> State:
            """Invoke the wrapped handler, forwarding runner and state."""
            return fn(runner, state)

        name: str = fn.__name__
        self.handlers[name] = wrapper
        return wrapper

    def get_handler(self, name: str) -> Handler:
        """Retrieve a registered handler by name.

        Args:
            name: The handler function name to retrieve.

        Returns:
            The handler callable that accepts a Runner and State.

        Raises:
            ValueError: If no handler with the given name is registered.
        """
        try:
            return self.handlers[name]
        except KeyError:
            raise ValueError(f"Unknown handler: {name}")


def run_workflow(runner: Runner, state: State, steps: list[Handler]) -> State:
    """Execute a sequence of workflow steps with state threading.

    Each step receives the runner and the current state, processes it, and
    returns an updated state that is forwarded to the next step (the
    "state-threading" pattern).  All step transitions are logged.  State is
    persisted after each step completes.

    Args:
        runner: The Runner instance executing the workflow.  Used for logging
            and state persistence.
        state: The current state dictionary passed into the step sequence.
        steps: Ordered list of callables each accepting ``(runner, state)``
            and returning the updated ``State``.

    Returns:
        The final state after all steps have been executed.
    """
    tracer = trace.get_tracer("antkeeper")
    runner.logger.info(f"run_workflow started with {len(steps)} steps: {[s.__name__ for s in steps]}")
    for i, step in enumerate(steps):
        step_name = step.__name__
        runner.logger.info(f"Executing step: {step_name}")
        with tracer.start_as_current_span(
            "antkeeper.workflow.step",
            attributes={
                "run_id": state.get("run_id", ""),
                "workflow_name": state.get("workflow_name", ""),
                "step_name": step_name,
                "step_index": i,
                "step_total": len(steps),
            },
        ):
            state = step(runner, state)
        runner._persist_state(state)
        runner.logger.debug(f"Step completed: {step_name}, state keys: {list(state.keys())}")
    runner.logger.info("run_workflow completed")
    return state
