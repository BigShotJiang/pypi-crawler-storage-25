#!/usr/bin/env python3
"""
Data Platform MCP Server

Provides tools for AI agents to discover, fetch, and export Swedish statistical data.
Uses the MCP (Model Context Protocol) standard.
"""

import os
import json
import base64
import logging
import time
import urllib.parse
from datetime import datetime
from functools import lru_cache
from pathlib import Path
from typing import Any
import httpx

logger = logging.getLogger(__name__)


def _summarize_tool_args(name: str, arguments: dict[str, Any]) -> str:
    """Compact, log-friendly summary of MCP tool call arguments.

    Strips dataset payloads and freeform query text so log lines stay
    grep-able and below typical syslog line limits. Keeps the bits a
    human needs to diagnose: dataset_id, source filter, limits, lang.
    """
    keep = {
        "dataset_id", "lang", "language", "format", "limit",
        "start_year", "end_year", "max_results",
    }
    pairs: list[str] = []
    for k, v in arguments.items():
        if k in keep:
            pairs.append(f"{k}={v}")
        elif k == "query" and isinstance(v, str):
            pairs.append(f"query={v[:60]!r}")
        elif k == "sources" and isinstance(v, list):
            pairs.append(f"sources={v}")
        elif k == "selections" and isinstance(v, list):
            ids = [s.get("dataset_id") for s in v if isinstance(s, dict)]
            pairs.append(f"selections={len(v)}({','.join(filter(None, ids))[:80]})")
        elif k == "breakdown_filters" and isinstance(v, dict):
            pairs.append(f"breakdown_filters_keys={list(v.keys())}")
    return " ".join(pairs) if pairs else "(no args)"
import mcp.types as types
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool, ToolAnnotations

# Configuration
BACKEND_URL = os.getenv("MCP_BACKEND_URL", "https://utforskadata.se")
APP_URL = os.getenv("MCP_APP_URL", "https://utforskadata.se")
SESSION_API_URL = (
    os.getenv("MCP_SESSION_API_URL")
    or os.getenv("MCP_APP_URL")
    or BACKEND_URL
)
DEFAULT_LANG = os.getenv("MCP_DEFAULT_LANG", "sv")
SESSION_API_TIMEOUT = httpx.Timeout(20.0, connect=4.0)

# Apps SDK / ChatGPT widgets ship as text/html+skybridge resources. Clients
# that don't speak that mimetype (Claude Desktop, Cursor, mcp-inspector,
# generic agents) try to render the HTML and surface a confusing
# "Unsupported UI resource content format" warning even though the
# structured tool result works fine. Gate the widget _meta + the matching
# resource registration behind an opt-in env var so only the ChatGPT
# deployment advertises them.
MCP_WIDGETS_ENABLED = os.getenv("MCP_WIDGETS_ENABLED", "").lower() in {"1", "true", "yes"}


def _widget_meta(
    template_uri: str,
    invoked_label: str,
    description: str | None = None,
) -> dict[str, Any]:
    """Optional Apps SDK widget metadata, empty when widgets are disabled."""
    if not MCP_WIDGETS_ENABLED:
        return {}
    return {
        "openai/outputTemplate": template_uri,
        "openai/widgetAccessible": True,
        "openai/toolInvocation/invoked": invoked_label,
        "openai/widgetDescription": description or WIDGET_DESCRIPTION,
        "openai/widgetCSP": {
            "connect_domains": WIDGET_CSP_DOMAINS,
            "resource_domains": WIDGET_CSP_DOMAINS,
        },
        "openai/widgetDomain": WIDGET_DOMAIN,
    }


def _to_origin(value: str) -> str:
    parsed = urllib.parse.urlparse(value)
    if parsed.scheme and parsed.netloc:
        return f"{parsed.scheme}://{parsed.netloc}"
    return value.rstrip("/")


WIDGET_DOMAIN = _to_origin(APP_URL)
WIDGET_CSP_DOMAINS = list(
    dict.fromkeys([_to_origin(BACKEND_URL), _to_origin(APP_URL)])
)
WIDGET_DESCRIPTION = (
    "Interactive carousel of discovered datasets. "
    "Results shown here are authoritative for this query. "
    "Keep assistant narration brief and avoid unrelated recommendations."
)
WIDGET_RESOURCE_META = {
    "ui": {
        "prefersBorder": True,
        "csp": {
            "connectDomains": WIDGET_CSP_DOMAINS,
            "resourceDomains": WIDGET_CSP_DOMAINS,
        },
        "domain": WIDGET_DOMAIN,
    },
    "openai/widgetDescription": WIDGET_DESCRIPTION,
    "openai/widgetPrefersBorder": True,
    "openai/widgetCSP": {
        "connect_domains": WIDGET_CSP_DOMAINS,
        "resource_domains": WIDGET_CSP_DOMAINS,
    },
    "openai/widgetDomain": WIDGET_DOMAIN,
}


def _session_api_base_candidates() -> list[str]:
    candidates: list[str] = []
    for raw_base in [SESSION_API_URL, BACKEND_URL, APP_URL]:
        if not raw_base:
            continue
        base = raw_base.rstrip("/")
        api_base = base if base.endswith("/api/v2") else f"{base}/api/v2"
        if api_base not in candidates:
            candidates.append(api_base)
    return candidates

server = Server("data-platform")
DISCOVER_WIDGET_URI = "ui://widget/discover-datasets-carousel.html"
DISCOVER_WIDGET_MIME_TYPE = "text/html+skybridge"
DISCOVER_WIDGET_PATH = (
    Path(__file__).resolve().parent / "assets" / "discover-datasets-carousel.html"
)

REPORT_WIDGET_URI = "ui://widget/data-report.html"
REPORT_WIDGET_MIME_TYPE = "text/html+skybridge"
REPORT_WIDGET_PATH = (
    Path(__file__).resolve().parent / "assets" / "data-report.html"
)
REPORT_DESCRIPTION = (
    "AI-generated data report with key insights, charts, and analysis. "
    "The rendered report is the authoritative result. "
    "Keep assistant narration brief and avoid extra analysis outside the report."
)
REPORT_WIDGET_META = {
    "ui": {
        "prefersBorder": True,
        "csp": {
            "connectDomains": WIDGET_CSP_DOMAINS,
            "resourceDomains": WIDGET_CSP_DOMAINS,
        },
        "domain": WIDGET_DOMAIN,
    },
    "openai/widgetDescription": REPORT_DESCRIPTION,
    "openai/widgetPrefersBorder": True,
    "openai/widgetCSP": {
        "connect_domains": WIDGET_CSP_DOMAINS,
        "resource_domains": WIDGET_CSP_DOMAINS,
    },
    "openai/widgetDomain": WIDGET_DOMAIN,
}

_SWEDISH_HINTS = {
    "visa",
    "jämför",
    "över",
    "tid",
    "arbetslöshet",
    "befolkning",
    "bostadspriser",
    "kommun",
    "län",
    "sverige",
}
_ENGLISH_HINTS = {
    "show",
    "compare",
    "trend",
    "over",
    "time",
    "population",
    "unemployment",
    "inflation",
    "sweden",
}


@lru_cache(maxsize=1)
def load_discover_widget_html() -> str:
    """Load the discovery widget HTML used by Apps SDK output templates."""
    if not DISCOVER_WIDGET_PATH.exists():
        raise FileNotFoundError(
            f"Widget HTML not found at {DISCOVER_WIDGET_PATH}"
        )
    return DISCOVER_WIDGET_PATH.read_text(encoding="utf-8")


@lru_cache(maxsize=1)
def load_report_widget_html() -> str:
    """Load the report widget HTML used by Apps SDK output templates."""
    if not REPORT_WIDGET_PATH.exists():
        raise FileNotFoundError(
            f"Widget HTML not found at {REPORT_WIDGET_PATH}"
        )
    return REPORT_WIDGET_PATH.read_text(encoding="utf-8")


def _truncate(text: str | None, limit: int = 180) -> str:
    if not text:
        return ""
    cleaned = " ".join(text.split())
    if len(cleaned) <= limit:
        return cleaned
    return f"{cleaned[: limit - 1]}…"


def _extract_measure_names(
    dataset: dict[str, Any], language: str = "sv", limit: int = 4
) -> list[str]:
    measures = dataset.get("content_measures") or dataset.get("metrics") or []
    names: list[str] = []
    seen = set()
    for measure in measures:
        if not isinstance(measure, dict):
            continue
        if language == "en":
            label = (
                measure.get("label_en")
                or measure.get("name_en")
                or measure.get("label")
                or measure.get("name")
                or measure.get("label_sv")
                or measure.get("name_sv")
            )
        else:
            label = (
                measure.get("label_sv")
                or measure.get("name_sv")
                or measure.get("label")
                or measure.get("name")
                or measure.get("label_en")
                or measure.get("name_en")
            )
        if not label or label in seen:
            continue
        seen.add(label)
        names.append(label)
        if len(names) >= limit:
            break
    return names


def _extract_breakdown_hints(
    dataset: dict[str, Any], language: str = "sv", limit: int = 3
) -> list[str]:
    hints: list[str] = []
    seen = set()
    for breakdown in dataset.get("breakdowns") or []:
        if not isinstance(breakdown, dict):
            continue
        if language == "en":
            label = (
                breakdown.get("label_en")
                or breakdown.get("name_en")
                or breakdown.get("label")
                or breakdown.get("name")
                or breakdown.get("label_sv")
                or breakdown.get("name_sv")
                or breakdown.get("dimension_id")
            )
        else:
            label = (
                breakdown.get("label_sv")
                or breakdown.get("name_sv")
                or breakdown.get("label")
                or breakdown.get("name")
                or breakdown.get("label_en")
                or breakdown.get("name_en")
                or breakdown.get("dimension_id")
            )
        if not label or label in seen:
            continue
        seen.add(label)
        hints.append(label)
        if len(hints) >= limit:
            break
    return hints


def _summarize_temporal_fit(dataset: dict[str, Any]) -> dict[str, Any] | None:
    fit = dataset.get("temporal_fit")
    if not isinstance(fit, dict):
        return None
    status = fit.get("fit_status")
    explanation = fit.get("explanation")
    if not status and not explanation:
        return None
    return {
        "status": status,
        "explanation": explanation,
    }


def build_discovery_cards(payload: dict[str, Any]) -> list[dict[str, Any]]:
    """Build compact, UI-friendly dataset cards from discovery payload."""
    cards: list[dict[str, Any]] = []
    language = payload.get("language_used") or DEFAULT_LANG
    for dataset in payload.get("datasets", []) or []:
        dataset_id = dataset.get("id") or dataset.get("table_id")
        if not dataset_id:
            continue

        time_range = dataset.get("time_range") or {}
        cards.append(
            {
                "id": dataset_id,
                "name": dataset.get("name") or dataset_id,
                "description": _truncate(dataset.get("description")),
                "source": dataset.get("source"),
                "category": dataset.get("category"),
                "subject_area": dataset.get("subject_area"),
                "time_start": time_range.get("start"),
                "time_end": time_range.get("end"),
                "source_url": dataset.get("source_url"),
                "source_contact_name": dataset.get("source_contact_name"),
                "source_contact_email": dataset.get("source_contact_email"),
                "source_contact_phone": dataset.get("source_contact_phone"),
                "primary_dimension_type": dataset.get("primary_dimension_type"),
                "measures": _extract_measure_names(dataset, language=language),
                "breakdown_hints": _extract_breakdown_hints(dataset, language=language),
                "preselected_breakdowns": dataset.get("preselected_breakdowns"),
                "temporal_fit": _summarize_temporal_fit(dataset),
                "dimension_shape": dataset.get("dimension_shape") or {},
            }
        )

    return cards


def resolve_language(query: str, requested: str | None) -> dict[str, Any]:
    """Resolve effective language for a query (sv/en) using lightweight heuristics."""
    requested_clean = requested if requested in {"sv", "en"} else None
    lowered = (query or "").lower()

    if not lowered:
        return {
            "language_used": requested_clean or DEFAULT_LANG,
            "language_detected": None,
            "language_override": False,
        }

    has_swedish_chars = any(ch in lowered for ch in "åäö")
    score_sv = 2 if has_swedish_chars else 0
    score_en = 0

    tokens = [t for t in lowered.split() if t]
    for token in tokens:
        if token in _SWEDISH_HINTS:
            score_sv += 1
        if token in _ENGLISH_HINTS:
            score_en += 1

    detected = None
    if score_sv > score_en:
        detected = "sv"
    elif score_en > score_sv:
        detected = "en"

    language_used = requested_clean or detected or DEFAULT_LANG
    language_override = False
    if detected and detected != language_used and (has_swedish_chars or abs(score_sv - score_en) >= 2):
        language_used = detected
        language_override = True

    return {
        "language_used": language_used,
        "language_detected": detected,
        "language_override": language_override,
    }


def build_export_link(
    dataset_id: str,
    format: str = "csv",
    measure: str = None,
    start_year: int = None,
    end_year: int = None,
    breakdown_filters: dict = None,
    lang: str = None,
) -> str:
    """Build a link to export dataset data."""
    params = {"format": format}
    if measure:
        params["measure"] = measure
    if start_year:
        params["start_year"] = str(start_year)
    if end_year:
        params["end_year"] = str(end_year)
    if breakdown_filters:
        params["breakdown_filters"] = json.dumps(breakdown_filters)
    if lang:
        params["lang"] = lang
    return f"{BACKEND_URL}/api/v2/datasets/{dataset_id}/export?{urllib.parse.urlencode(params)}"


def build_session_link_from_intent(
    selections: list,
    title: str = None,
    description: str = None,
    lang: str = None,
    query: str = None,
) -> str:
    """Build a deep link that creates a session with preloaded data."""
    payload = {
        "version": "1",
        "lang": lang or DEFAULT_LANG,
        "selections": selections,
    }
    if title:
        payload["title"] = title
    if description:
        payload["description"] = description
    if query:
        payload["query"] = query

    # Base64url encode the payload
    payload_json = json.dumps(payload, ensure_ascii=False)
    payload_b64 = base64.urlsafe_b64encode(payload_json.encode()).decode().rstrip("=")

    return f"{APP_URL}/intent?payload={payload_b64}"


async def create_persisted_session_link(
    client: httpx.AsyncClient,
    selections: list[dict[str, Any]],
    *,
    title: str | None = None,
    description: str | None = None,
    query: str | None = None,
    lang: str | None = None,
    ) -> tuple[str, list[str]]:
    """Create one backend session, load selections, and return the app session link."""
    effective_lang = lang if lang in {"sv", "en"} else DEFAULT_LANG
    session_title = (
        title
        or query
        or f"MCP Session {datetime.now().strftime('%Y-%m-%d %H:%M')}"
    )

    create_response = None
    session_api_base = None
    for api_base in _session_api_base_candidates():
        try:
            attempt = await client.post(
                f"{api_base}/sessions",
                json={
                    "title": session_title,
                    "description": description or "",
                    "lang": effective_lang,
                },
                timeout=SESSION_API_TIMEOUT,
            )
        except httpx.HTTPError:
            continue
        if attempt.is_success:
            create_response = attempt
            session_api_base = api_base
            break

    if not create_response or not session_api_base:
        raise ValueError("Failed to create session via configured session API endpoints")

    session_payload = create_response.json()
    session_id = session_payload.get("id")
    if not session_id:
        raise ValueError("Missing session id in create-session response")

    warnings: list[str] = []
    for index, selection in enumerate(selections):
        load_response = await client.post(
            f"{session_api_base}/sessions/{session_id}/load",
            json={
                "dataset_id": selection.get("dataset_id"),
                "measures": selection.get("measures", []),
                "time": selection.get("time"),
                "breakdown_filters": selection.get("breakdown_filters"),
            },
            timeout=SESSION_API_TIMEOUT,
        )
        if not load_response.is_success:
            warnings.append(
                f"Selection {index + 1} ({selection.get('dataset_id', 'unknown')}) "
                f"could not be loaded ({load_response.status_code})."
            )

    link = f"{APP_URL}/sessions/{session_id}"
    query_params = {}
    # Important: when selections are provided, avoid attaching `q` so older
    # frontend builds still autoload persisted session items correctly.
    if query and not selections:
        query_params["q"] = query
    if effective_lang:
        query_params["lang"] = effective_lang
    if query_params:
        link += f"?{urllib.parse.urlencode(query_params)}"

    return link, warnings


@server.list_resources()
async def list_resources() -> list[types.Resource]:
    """List UI resources for Apps SDK output templates.

    Only advertised when MCP_WIDGETS_ENABLED is set — generic MCP clients
    don't render text/html+skybridge and surface a confusing warning if
    they try to read these resources.
    """
    if not MCP_WIDGETS_ENABLED:
        return []
    return [
        types.Resource(
            uri=DISCOVER_WIDGET_URI,
            name="discover_datasets_carousel",
            title="Discovered datasets carousel",
            description="Interactive dataset cards for discover_datasets results.",
            mimeType=DISCOVER_WIDGET_MIME_TYPE,
            _meta=WIDGET_RESOURCE_META,
        ),
        types.Resource(
            uri=REPORT_WIDGET_URI,
            name="data_report",
            title="Data report",
            description="AI-generated data report with insights, charts, and analysis.",
            mimeType=REPORT_WIDGET_MIME_TYPE,
            _meta=REPORT_WIDGET_META,
        ),
    ]


async def _read_resource_handler(req: types.ReadResourceRequest) -> types.ServerResult:
    """Read UI resource content by URI with metadata needed by Apps SDK submission checks."""
    uri = str(req.params.uri).rstrip("/")

    if uri == DISCOVER_WIDGET_URI.rstrip("/"):
        contents = [
            types.TextResourceContents(
                uri=req.params.uri,
                text=load_discover_widget_html(),
                mimeType=DISCOVER_WIDGET_MIME_TYPE,
                _meta=WIDGET_RESOURCE_META,
            )
        ]
    elif uri == REPORT_WIDGET_URI.rstrip("/"):
        contents = [
            types.TextResourceContents(
                uri=req.params.uri,
                text=load_report_widget_html(),
                mimeType=REPORT_WIDGET_MIME_TYPE,
                _meta=REPORT_WIDGET_META,
            )
        ]
    else:
        raise ValueError(f"Unknown resource: {req.params.uri}")

    return types.ServerResult(
        types.ReadResourceResult(
            contents=contents,
        )
    )


server.request_handlers[types.ReadResourceRequest] = _read_resource_handler


@server.list_tools()
async def list_tools() -> list[Tool]:
    """List available tools."""
    read_only_annotations = ToolAnnotations(
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=True,
    )
    session_link_annotations = ToolAnnotations(
        readOnlyHint=False,
        destructiveHint=False,
        idempotentHint=False,
        openWorldHint=True,
    )

    return [
        Tool(
            name="discover_datasets",
            description=(
                "Search Utforska Data for matching datasets and return ranked cards. "
                "The widget cards are the authoritative result; do not provide independent dataset "
                "recommendations. Each card includes `dimension_shape` — a map from canonical dimension "
                "key (e.g. \"Municipality\", \"Year\", \"Kön\") to {label, count, values|sample|range}. "
                "Pass that same key into fetch_data's breakdown_filters; the `label` field is the "
                "translated display name for the user. Each card also includes `source_url` and "
                "`source_contact_*` for provenance. After fetch_data returns, recommend "
                "`build_session_link` (interactive view in app) or `build_export_link` (CSV/JSON "
                "download) for the full dataset."
            ),
            annotations=read_only_annotations,
            _meta={
                "openai/toolInvocation/invoking": "Searching datasets…",
                "openai/toolInvocation/invoked": "Dataset search complete",
                **(
                    {
                        "openai/outputTemplate": DISCOVER_WIDGET_URI,
                        "openai/widgetAccessible": True,
                        "ui": {"resourceUri": DISCOVER_WIDGET_URI},
                    }
                    if MCP_WIDGETS_ENABLED
                    else {}
                ),
            },
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Natural language query describing what data you're looking for (e.g., 'housing prices in Sweden', 'immigration statistics')",
                    },
                    "language": {
                        "type": "string",
                        "enum": ["sv", "en"],
                        "default": "sv",
                        "description": "Response language",
                    },
                    "sources": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Filter by data sources (e.g., ['scb', 'skolverket', 'worldbank', 'jordbruksverket'])",
                    },
                    "categories": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Filter by categories (e.g., ['housing', 'population', 'education'])",
                    },
                    "max_results": {
                        "type": "integer",
                        "default": 5,
                        "description": "Maximum number of results to return",
                    },
                },
                "required": ["query"],
            },
        ),
        Tool(
            name="get_dataset_details",
            description="Get detailed information about a specific dataset including available measures (metrics), breakdowns (dimensions for filtering), and time range.",
            annotations=read_only_annotations,
            _meta={
                "openai/toolInvocation/invoking": "Loading dataset details…",
                "openai/toolInvocation/invoked": "Dataset details loaded",
            },
            inputSchema={
                "type": "object",
                "properties": {
                    "dataset_id": {
                        "type": "string",
                        "description": "Dataset ID from discover_datasets results",
                    },
                    "lang": {
                        "type": "string",
                        "enum": ["sv", "en"],
                        "default": "sv",
                        "description": "Response language",
                    },
                },
                "required": ["dataset_id"],
            },
        ),
        Tool(
            name="fetch_data",
            description=(
                "Fetch actual data from a dataset. Returns rows with values that can be used to "
                "answer questions directly. Use the canonical dimension keys from `discover_datasets` "
                "`dimension_shape` (e.g. \"Municipality\", \"Kön\") in `breakdown_filters` — never the "
                "translated `label`. When `breakdown_filters` is omitted (or partial), every value of "
                "the unfiltered dimensions is returned (e.g. all 290 municipalities, all gender codes). "
                "Large result sets are paginated: the response carries `total_count`, `offset`, "
                "`next_offset`, `truncated`, and `pagination_hint`. When `truncated` is true, either "
                "page through with `offset`, call `build_session_link` to open the full dataset in the "
                "app, or call `build_export_link` to give the user a CSV/JSON download."
            ),
            annotations=read_only_annotations,
            _meta={
                "openai/toolInvocation/invoking": "Fetching data…",
                "openai/toolInvocation/invoked": "Data fetched",
            },
            inputSchema={
                "type": "object",
                "properties": {
                    "dataset_id": {"type": "string", "description": "Dataset ID"},
                    "measure": {
                        "type": "string",
                        "description": "Specific measure/metric to fetch (from dataset details)",
                    },
                    "start_year": {
                        "type": "integer",
                        "description": "Filter data from this year",
                    },
                    "end_year": {
                        "type": "integer",
                        "description": "Filter data until this year",
                    },
                    "breakdown_filters": {
                        "type": "object",
                        "description": (
                            'Filter by breakdown dimensions (e.g., {"region": ["SE"], "sex": ["1", "2"]}). '
                            "Omit a dimension to keep all its values; omit the whole field to keep all values "
                            "for every dimension."
                        ),
                    },
                    "lang": {"type": "string", "enum": ["sv", "en"], "default": "sv"},
                    "limit": {
                        "type": "integer",
                        "default": 10000,
                        "description": (
                            "Maximum rows per page. Default 10000, which fits a typical full Kolada KPI "
                            "(290 municipalities × ~25 years). Use the response `next_offset` to fetch "
                            "the next page when needed."
                        ),
                    },
                    "offset": {
                        "type": "integer",
                        "default": 0,
                        "description": "Row offset for pagination — pass the previous response's `next_offset` to continue.",
                    },
                },
                "required": ["dataset_id"],
            },
        ),
        Tool(
            name="build_export_link",
            description=(
                "Generate a download link for the full dataset (with optional filters) in CSV or "
                "JSON format. Use this when the user wants a complete dataset that's too large to "
                "summarize inline, or for offline / spreadsheet workflows. Returns "
                "`{\"export_link\": \"<url>\"}` — present the link directly to the user."
            ),
            annotations=read_only_annotations,
            _meta={
                "openai/toolInvocation/invoking": "Creating export link…",
                "openai/toolInvocation/invoked": "Export link ready",
            },
            inputSchema={
                "type": "object",
                "properties": {
                    "dataset_id": {"type": "string", "description": "Dataset ID"},
                    "format": {
                        "type": "string",
                        "enum": ["csv", "json"],
                        "default": "csv",
                    },
                    "measure": {"type": "string"},
                    "start_year": {"type": "integer"},
                    "end_year": {"type": "integer"},
                    "breakdown_filters": {"type": "object"},
                    "lang": {"type": "string", "enum": ["sv", "en"], "default": "sv"},
                },
                "required": ["dataset_id"],
            },
        ),
        Tool(
            name="build_session_link",
            description=(
                "Create an app session preloaded with one or more dataset selections and return a "
                "deep link the user can click to open the interactive Utforska Data UI (charts, "
                "filters, comparisons). Use this whenever the user wants to keep exploring beyond a "
                "single fetch_data call — e.g. asking about \"all municipalities\", multiple "
                "metrics, or any cross-filter analysis. Each selection must include `dataset_id` "
                "and `measures` (measure names from the dataset's content_measures)."
            ),
            annotations=session_link_annotations,
            _meta={
                "openai/toolInvocation/invoking": "Creating session link…",
                "openai/toolInvocation/invoked": "Session link ready",
            },
            inputSchema={
                "type": "object",
                "properties": {
                    "selections": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "dataset_id": {"type": "string"},
                                "measures": {
                                    "type": "array",
                                    "items": {"type": "string"},
                                },
                                "time": {
                                    "type": "object",
                                    "properties": {
                                        "start_year": {"type": "integer"},
                                        "end_year": {"type": "integer"},
                                    },
                                },
                                "breakdown_filters": {"type": "object"},
                            },
                            "required": ["dataset_id"],
                        },
                        "description": "List of dataset selections to preload",
                    },
                    "title": {
                        "type": "string",
                        "description": "Optional session title",
                    },
                    "description": {
                        "type": "string",
                        "description": "Optional session description",
                    },
                    "query": {
                        "type": "string",
                        "description": "Optional search query to prefill discovery",
                    },
                    "lang": {"type": "string", "enum": ["sv", "en"], "default": "sv"},
                },
                "required": ["selections"],
            },
        ),
        Tool(
            name="generate_report",
            description=(
                "Generate an AI-powered data report with key insights, visualizations, and analysis "
                "from previously fetched metric data. Use this after fetching data with fetch_data to "
                "create a comprehensive visual report. Pass the fetched data rows as metric values."
            ),
            annotations=ToolAnnotations(
                readOnlyHint=False,
                destructiveHint=False,
                idempotentHint=False,
                openWorldHint=True,
            ),
            _meta={
                "openai/toolInvocation/invoking": "Generating data report…",
                "openai/toolInvocation/invoked": "Report ready",
                **(
                    {
                        "openai/outputTemplate": REPORT_WIDGET_URI,
                        "openai/widgetAccessible": True,
                        "ui": {"resourceUri": REPORT_WIDGET_URI},
                    }
                    if MCP_WIDGETS_ENABLED
                    else {}
                ),
            },
            inputSchema={
                "type": "object",
                "properties": {
                    "metrics": {
                        "type": "array",
                        "description": "List of metrics with their data to include in the report. Each metric should contain data previously fetched via fetch_data.",
                        "items": {
                            "type": "object",
                            "properties": {
                                "name": {
                                    "type": "string",
                                    "description": "Name of the metric (e.g., 'Population', 'Unemployment rate')",
                                },
                                "dataset": {
                                    "type": "string",
                                    "description": "Dataset name or ID the metric belongs to",
                                },
                                "values": {
                                    "type": "array",
                                    "items": {"type": "object"},
                                    "description": "Data rows from fetch_data results (the 'data' array). Each row should have 'year'/'time_period' and 'value' fields.",
                                },
                                "breakdown": {
                                    "type": "string",
                                    "description": "Optional breakdown dimension applied (e.g., 'by region', 'by gender')",
                                },
                            },
                            "required": ["name", "dataset", "values"],
                        },
                    },
                    "language": {
                        "type": "string",
                        "enum": ["sv", "en"],
                        "default": "sv",
                        "description": "Language for the report",
                    },
                    "selections": {
                        "type": "array",
                        "description": "Optional: dataset selections to create a session link for exploring the data in the app. Same format as build_session_link selections.",
                        "items": {
                            "type": "object",
                            "properties": {
                                "dataset_id": {"type": "string"},
                                "measures": {
                                    "type": "array",
                                    "items": {"type": "string"},
                                },
                                "time": {
                                    "type": "object",
                                    "properties": {
                                        "start_year": {"type": "integer"},
                                        "end_year": {"type": "integer"},
                                    },
                                },
                                "breakdown_filters": {"type": "object"},
                            },
                            "required": ["dataset_id"],
                        },
                    },
                },
                "required": ["metrics"],
            },
        ),
        Tool(
            name="build_session_export_link",
            description="Generate a download link that exports all loaded selections as one CSV or XLSX file.",
            annotations=read_only_annotations,
            _meta={
                "openai/toolInvocation/invoking": "Preparing export link…",
                "openai/toolInvocation/invoked": "Export link ready",
            },
            inputSchema={
                "type": "object",
                "properties": {
                    "selections": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "dataset_id": {"type": "string"},
                                "measures": {
                                    "type": "array",
                                    "items": {"type": "string"},
                                },
                                "time": {
                                    "type": "object",
                                    "properties": {
                                        "start_year": {"type": "integer"},
                                        "end_year": {"type": "integer"},
                                    },
                                },
                                "breakdown_filters": {"type": "object"},
                            },
                            "required": ["dataset_id"],
                        },
                        "description": "List of loaded metric selections to export",
                    },
                    "format": {
                        "type": "string",
                        "enum": ["csv", "xlsx"],
                        "default": "csv",
                    },
                    "query": {
                        "type": "string",
                        "description": "Optional query used for filename context",
                    },
                    "lang": {"type": "string", "enum": ["sv", "en"], "default": "sv"},
                },
                "required": ["selections"],
            },
        ),
    ]


@server.call_tool()
async def call_tool(
    name: str, arguments: dict[str, Any]
) -> list[TextContent] | types.CallToolResult:
    """Handle tool calls."""

    # Structured log per tool call. Keeps argument summary small so we
    # don't spam stdout with full dataset payloads — just the bits a
    # human (or grep) needs to spot abuse or correlate with a backend
    # log line. Outcome + latency get logged in the finally block.
    _call_started_at = time.monotonic()
    _arg_summary = _summarize_tool_args(name, arguments)
    _outcome = "success"
    _err_detail = ""
    logger.info("mcp.tool.start name=%s args=%s", name, _arg_summary)

    async with httpx.AsyncClient(timeout=30.0) as client:
        try:
            if name == "discover_datasets":
                # Validate query
                query = arguments.get("query", "").strip()
                if not query:
                    return [
                        TextContent(
                            type="text",
                            text=json.dumps(
                                {
                                    "error": "Query parameter is required and cannot be empty",
                                    "datasets": [],
                                },
                                indent=2,
                            ),
                        )
                    ]
                lang_info = resolve_language(query, arguments.get("language"))
                effective_language = lang_info["language_used"]
                # Call AI discovery endpoint
                response = await client.post(
                    f"{BACKEND_URL}/api/ai/discover",
                    json={
                        "query": arguments["query"],
                        "language": effective_language,
                        "max_results": arguments.get("max_results", 5),
                        "sources": arguments.get("sources"),
                        "categories": arguments.get("categories"),
                    },
                )
                response.raise_for_status()
                data = response.json()

                fallback_applied = False
                datasets = data.get("datasets") or []
                if (not datasets) and (
                    arguments.get("sources") is not None
                    or arguments.get("categories") is not None
                ):
                    fallback_response = await client.post(
                        f"{BACKEND_URL}/api/ai/discover",
                        json={
                            "query": arguments["query"],
                            "language": effective_language,
                            "max_results": arguments.get("max_results", 5),
                        },
                    )
                    fallback_response.raise_for_status()
                    fallback_data = fallback_response.json()
                    fallback_datasets = fallback_data.get("datasets") or []
                    if fallback_datasets:
                        data = fallback_data
                        datasets = fallback_datasets
                        fallback_applied = True

                # Add session link for continued exploration
                session_link_response = await client.post(
                    f"{BACKEND_URL}/agent/session-link",
                    json={
                        "query": arguments["query"],
                        "lang": effective_language,
                    },
                )
                session_link_response.raise_for_status()
                session_link_payload = session_link_response.json()
                data["session_link"] = session_link_payload.get("link")
                data["language_used"] = effective_language
                data["language_detected"] = lang_info.get("language_detected")
                data["language_override"] = lang_info.get("language_override")

                cards = build_discovery_cards(data)
                datasets = data.get("datasets") or []
                assistant_summary = "Dataset search complete."
                structured_content = {
                    "status": data.get("status", "ok"),
                    "query": query,
                    "language_used": effective_language,
                    "session_link": data.get("session_link"),
                    "cards": cards,
                    "count": len(datasets),
                    "filter_fallback_applied": fallback_applied,
                    "response_policy": {
                        "source_scope": "returned_datasets_only",
                        "allow_external_sources": False,
                        "allow_unrelated_narrative": False,
                    },
                }

                return types.CallToolResult(
                    content=[
                        TextContent(
                            type="text",
                            text=assistant_summary,
                        )
                    ],
                    structuredContent=structured_content,
                    _meta=_widget_meta(DISCOVER_WIDGET_URI, "Dataset search complete"),
                    isError=False,
                )

            elif name == "get_dataset_details":
                # Validate dataset_id
                dataset_id = arguments.get("dataset_id", "").strip()
                if not dataset_id:
                    return [
                        TextContent(
                            type="text",
                            text=json.dumps(
                                {
                                    "error": "dataset_id parameter is required and cannot be empty"
                                },
                                indent=2,
                            ),
                        )
                    ]

                lang = arguments.get("lang", DEFAULT_LANG)
                response = await client.get(
                    f"{BACKEND_URL}/api/v2/datasets/{dataset_id}",
                    params={"lang": lang},
                )
                response.raise_for_status()
                data = response.json()

                return [
                    TextContent(
                        type="text", text=json.dumps(data, ensure_ascii=False, indent=2)
                    )
                ]

            elif name == "fetch_data":
                # Validate dataset_id
                dataset_id = arguments.get("dataset_id", "").strip()
                if not dataset_id:
                    return [
                        TextContent(
                            type="text",
                            text=json.dumps(
                                {
                                    "error": "dataset_id parameter is required and cannot be empty"
                                },
                                indent=2,
                            ),
                        )
                    ]

                # Default to a generous page size so the common "give me every
                # value of every dimension" request (e.g. all 290 municipalities
                # × 25 years) fits in one round-trip. Callers can still pass
                # `limit` to cap the response or paginate explicitly.
                requested_limit = arguments.get("limit", 10000)
                requested_offset = arguments.get("offset", 0)
                params = {
                    "lang": arguments.get("lang", DEFAULT_LANG),
                    "limit": requested_limit,
                    "offset": requested_offset,
                }
                if arguments.get("measure"):
                    params["measure"] = arguments["measure"]
                if arguments.get("start_year"):
                    params["start_year"] = arguments["start_year"]
                if arguments.get("end_year"):
                    params["end_year"] = arguments["end_year"]

                # If the caller is filtering by breakdown dimensions,
                # validate the dimension keys against the dataset's
                # actual breakdowns BEFORE we fetch data. A typo like
                # `{"region": [...]}` on a dataset that exposes
                # `{"län": [...]}` would otherwise silently match zero
                # rows and look like "no data" instead of "wrong key".
                requested_filters = arguments.get("breakdown_filters") or {}
                if requested_filters:
                    if not isinstance(requested_filters, dict):
                        return [
                            TextContent(
                                type="text",
                                text=json.dumps(
                                    {
                                        "error": "breakdown_filters must be an object",
                                        "received_type": type(requested_filters).__name__,
                                    },
                                    indent=2,
                                ),
                            )
                        ]
                    details_response = await client.get(
                        f"{BACKEND_URL}/api/v2/datasets/{dataset_id}",
                        params={"lang": params["lang"]},
                    )
                    if details_response.status_code != 200:
                        details_response.raise_for_status()
                    details_payload = details_response.json()
                    valid_keys: set[str] = set()
                    for bd in (details_payload.get("breakdowns") or []):
                        if isinstance(bd, dict):
                            for key in ("name", "dimension_id", "label"):
                                val = bd.get(key)
                                if isinstance(val, str) and val:
                                    valid_keys.add(val)
                    unknown_keys = [k for k in requested_filters.keys() if k not in valid_keys]
                    if unknown_keys:
                        return [
                            TextContent(
                                type="text",
                                text=json.dumps(
                                    {
                                        "error": "Unknown breakdown filter key(s)",
                                        "unknown_keys": unknown_keys,
                                        "valid_keys": sorted(valid_keys),
                                        "suggestion": "Call get_dataset_details to see valid breakdown dimensions.",
                                    },
                                    indent=2,
                                ),
                            )
                        ]

                # Push breakdown filters down to SQL via the REST endpoint
                # so pagination math is honest — counting filtered rows in
                # Python after the fact would lie about `total_count`.
                if requested_filters:
                    params["breakdown_filters"] = json.dumps(requested_filters)

                response = await client.get(
                    f"{BACKEND_URL}/api/v2/datasets/{dataset_id}/data",
                    params=params,
                )
                response.raise_for_status()
                data = response.json()

                # Pagination hints — same shape for every dataset, every
                # dimension. When the response is partial, `next_offset`
                # is non-null and `truncated` is true.
                total_count = data.get("total_count")
                returned = data.get("count", len(data.get("data") or []))
                offset_value = data.get("offset", requested_offset)
                if isinstance(total_count, int):
                    next_offset = offset_value + returned
                    if next_offset >= total_count:
                        next_offset = None
                    data["next_offset"] = next_offset
                    data["truncated"] = next_offset is not None
                    data["page_limit"] = requested_limit
                    if data["truncated"]:
                        data["pagination_hint"] = (
                            f"Returned {returned} of {total_count} rows. "
                            f"Call fetch_data again with offset={next_offset} to continue."
                        )

                return [
                    TextContent(
                        type="text", text=json.dumps(data, ensure_ascii=False, indent=2)
                    )
                ]

            elif name == "build_export_link":
                # Validate dataset_id
                dataset_id = arguments.get("dataset_id", "").strip()
                if not dataset_id:
                    return [
                        TextContent(
                            type="text",
                            text=json.dumps(
                                {
                                    "error": "dataset_id parameter is required and cannot be empty"
                                },
                                indent=2,
                            ),
                        )
                    ]

                link = build_export_link(
                    dataset_id=dataset_id,
                    format=arguments.get("format", "csv"),
                    measure=arguments.get("measure"),
                    start_year=arguments.get("start_year"),
                    end_year=arguments.get("end_year"),
                    breakdown_filters=arguments.get("breakdown_filters"),
                    lang=arguments.get("lang", DEFAULT_LANG),
                )
                return [
                    TextContent(
                        type="text", text=json.dumps({"export_link": link}, indent=2)
                    )
                ]

            elif name == "build_session_link":
                # Validate selections
                selections = arguments.get("selections", [])
                if not selections or len(selections) == 0:
                    return [
                        TextContent(
                            type="text",
                            text=json.dumps(
                                {
                                    "error": "At least one dataset selection is required",
                                    "suggestion": "Provide selections with dataset_id and measures",
                                },
                                indent=2,
                            ),
                        )
                    ]

                # Validate each selection has required fields
                for i, sel in enumerate(selections):
                    if not sel.get("dataset_id"):
                        return [
                            TextContent(
                                type="text",
                                text=json.dumps(
                                    {
                                        "error": f"Selection {i} missing required 'dataset_id' field",
                                    },
                                    indent=2,
                                ),
                            )
                        ]
                    if not sel.get("measures") or len(sel.get("measures", [])) == 0:
                        return [
                            TextContent(
                                type="text",
                                text=json.dumps(
                                    {
                                        "error": f"Selection {i} missing required 'measures' field or it's empty",
                                    },
                                    indent=2,
                                ),
                            )
                        ]

                # Pre-check that every dataset_id actually exists before
                # we create a session and start loading metrics. Without
                # this, an invalid id would still produce a "successful"
                # session_link but with a `warnings` array — the user
                # opens the deep-link and finds an empty workspace. Fail
                # fast with a clear list of missing ids instead.
                missing_ids: list[str] = []
                for sel in selections:
                    ds_id = sel.get("dataset_id")
                    if not ds_id:
                        continue
                    check_response = await client.get(
                        f"{BACKEND_URL}/api/v2/datasets/{ds_id}",
                        params={"lang": arguments.get("lang", DEFAULT_LANG)},
                    )
                    if check_response.status_code == 404:
                        missing_ids.append(ds_id)
                    elif check_response.status_code >= 400:
                        check_response.raise_for_status()
                if missing_ids:
                    return [
                        TextContent(
                            type="text",
                            text=json.dumps(
                                {
                                    "error": "Unknown dataset_id(s)",
                                    "missing_dataset_ids": missing_ids,
                                    "suggestion": "Call discover_datasets to find valid dataset IDs before building a session link.",
                                },
                                indent=2,
                            ),
                        )
                    ]

                link, warnings = await create_persisted_session_link(
                    client,
                    selections=selections,
                    title=arguments.get("title"),
                    description=arguments.get("description"),
                    query=arguments.get("query"),
                    lang=arguments.get("lang", DEFAULT_LANG),
                )
                response_payload: dict[str, Any] = {"session_link": link}
                if warnings:
                    response_payload["warnings"] = warnings
                return [
                    TextContent(
                        type="text", text=json.dumps(response_payload, indent=2)
                    )
                ]

            elif name == "generate_report":
                metrics = arguments.get("metrics", [])
                if not metrics:
                    return [
                        TextContent(
                            type="text",
                            text=json.dumps(
                                {
                                    "error": "At least one metric is required to generate a report",
                                    "suggestion": "Use fetch_data first to get metric data, then pass it here",
                                },
                                indent=2,
                            ),
                        )
                    ]

                for i, m in enumerate(metrics):
                    if not m.get("name") or not m.get("values"):
                        return [
                            TextContent(
                                type="text",
                                text=json.dumps(
                                    {
                                        "error": f"Metric {i} missing required 'name' or 'values' field",
                                    },
                                    indent=2,
                                ),
                            )
                        ]

                effective_lang = arguments.get("language", DEFAULT_LANG)
                if effective_lang not in {"sv", "en"}:
                    effective_lang = DEFAULT_LANG

                # Call the report generation endpoint
                report_response = await client.post(
                    f"{BACKEND_URL}/api/ai/report/generate",
                    json={
                        "metrics": [
                            {
                                "name": m["name"],
                                "dataset": m.get("dataset", "Unknown"),
                                "values": m["values"],
                                "breakdown": m.get("breakdown"),
                            }
                            for m in metrics
                        ],
                        "language": effective_lang,
                        "style": "analytical",
                    },
                    timeout=60.0,
                )
                report_response.raise_for_status()
                report_data = report_response.json()

                # Optionally create a session link for the "Explore in app" button
                session_link = None
                selections = arguments.get("selections", [])
                if selections:
                    try:
                        session_link, _ = await create_persisted_session_link(
                            client,
                            selections=selections,
                            title=report_data.get("title"),
                            lang=effective_lang,
                        )
                    except Exception:
                        pass  # Non-critical: report still works without session link

                structured_content = {
                    "title": report_data.get("title", ""),
                    "key_insights": report_data.get("key_insights", []),
                    "story": report_data.get("story", ""),
                    "charts": report_data.get("charts", []),
                    "language": effective_lang,
                    "session_link": session_link,
                }

                assistant_summary = "Report ready."

                return types.CallToolResult(
                    content=[
                        TextContent(
                            type="text",
                            text=assistant_summary,
                        )
                    ],
                    structuredContent=structured_content,
                    _meta=_widget_meta(REPORT_WIDGET_URI, "Report ready", REPORT_DESCRIPTION),
                    isError=False,
                )

            elif name == "build_session_export_link":
                selections = arguments.get("selections", [])
                if not selections or len(selections) == 0:
                    return [
                        TextContent(
                            type="text",
                            text=json.dumps(
                                {
                                    "error": "At least one selection is required for export",
                                    "suggestion": "Load one or more metrics, then retry export",
                                },
                                indent=2,
                            ),
                        )
                    ]

                for index, selection in enumerate(selections):
                    if not selection.get("dataset_id"):
                        return [
                            TextContent(
                                type="text",
                                text=json.dumps(
                                    {
                                        "error": f"Selection {index} missing required 'dataset_id' field",
                                    },
                                    indent=2,
                                ),
                            )
                        ]
                    if not selection.get("measures"):
                        return [
                            TextContent(
                                type="text",
                                text=json.dumps(
                                    {
                                        "error": f"Selection {index} missing required 'measures' field",
                                    },
                                    indent=2,
                                ),
                            )
                        ]

                response = await client.post(
                    f"{BACKEND_URL}/agent/session-export-link",
                    json={
                        "selections": selections,
                        "format": arguments.get("format", "csv"),
                        "query": arguments.get("query"),
                        "lang": arguments.get("lang", DEFAULT_LANG),
                    },
                )
                response.raise_for_status()
                payload = response.json()
                return [
                    TextContent(
                        type="text",
                        text=json.dumps(
                            {"export_link": payload.get("link")},
                            ensure_ascii=False,
                            indent=2,
                        ),
                    )
                ]

            else:
                return [TextContent(type="text", text=f"Unknown tool: {name}")]

        except httpx.HTTPStatusError as e:
            _outcome = f"http_{e.response.status_code}"
            _err_detail = (e.response.text[:200] if e.response.text else "").replace("\n", " ")
            error_msg = {
                "error": f"API error: {e.response.status_code}",
                "details": (
                    e.response.text[:200] if e.response.text else "No details available"
                ),
            }

            # Add helpful messages for common errors
            if e.response.status_code == 404:
                error_msg["suggestion"] = (
                    "Dataset not found. Use discover_datasets to find valid dataset IDs."
                )
            elif e.response.status_code == 400:
                error_msg["suggestion"] = (
                    "Invalid request parameters. Check the dataset details for valid options."
                )
            elif e.response.status_code == 500:
                error_msg["suggestion"] = (
                    "Backend server error. The dataset may have data issues."
                )

            return [
                TextContent(
                    type="text",
                    text=json.dumps(error_msg, indent=2),
                )
            ]
        except httpx.RequestError as e:
            _outcome = "transport_error"
            _err_detail = str(e)[:200]
            return [
                TextContent(
                    type="text",
                    text=json.dumps(
                        {
                            "error": "Connection error",
                            "details": str(e),
                            "suggestion": "Ensure the backend server is running at "
                            + BACKEND_URL,
                        },
                        indent=2,
                    ),
                )
            ]
        except Exception as e:
            _outcome = "exception"
            _err_detail = f"{type(e).__name__}: {str(e)[:200]}"
            return [
                TextContent(
                    type="text",
                    text=json.dumps(
                        {"error": "Unexpected error", "details": str(e)}, indent=2
                    ),
                )
            ]
        finally:
            _elapsed_ms = int((time.monotonic() - _call_started_at) * 1000)
            logger.info(
                "mcp.tool.done name=%s outcome=%s elapsed_ms=%s%s",
                name,
                _outcome,
                _elapsed_ms,
                f" detail={_err_detail!r}" if _err_detail else "",
            )


async def _main():
    """Run the MCP server over stdio."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream, write_stream, server.create_initialization_options()
        )


def main() -> None:
    """Synchronous console entrypoint for uv/uvx."""
    import asyncio

    asyncio.run(_main())


if __name__ == "__main__":
    main()
