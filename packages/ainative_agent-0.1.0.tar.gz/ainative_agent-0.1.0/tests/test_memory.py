"""Tests for MemoryClient (ZeroMemory).

Refs #2372
"""

from __future__ import annotations

import pytest

from ainative_agent._http import HTTPClient
from ainative_agent.memory import MemoryClient
from ainative_agent.types import Memory, Profile, Reflection


@pytest.fixture
def memory_client(mock_http: HTTPClient) -> MemoryClient:
    return MemoryClient(mock_http)


MEMORY_DATA = {
    "id": "m-001",
    "content": "The sky is blue",
    "memory_type": "episodic",
    "importance": 0.7,
    "tags": ["fact"],
    "entity_id": "user-1",
    "metadata": {},
    "created_at": "2026-01-01T00:00:00Z",
}


class TestRemember:
    @pytest.mark.asyncio
    async def test_remember(self, memory_client: MemoryClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = MEMORY_DATA  # type: ignore[attr-defined]
        mem = await memory_client.remember("The sky is blue", entity_id="user-1", importance=0.7, tags=["fact"])
        assert isinstance(mem, Memory)
        assert mem.id == "m-001"
        assert mem.content == "The sky is blue"


class TestRecall:
    @pytest.mark.asyncio
    async def test_recall(self, memory_client: MemoryClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = [MEMORY_DATA]  # type: ignore[attr-defined]
        results = await memory_client.recall("sky color", entity_id="user-1")
        assert len(results) == 1
        assert isinstance(results[0], Memory)


class TestForget:
    @pytest.mark.asyncio
    async def test_forget(self, memory_client: MemoryClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = None  # type: ignore[attr-defined]
        await memory_client.forget("m-001")
        mock_http.request.assert_called_once_with("DELETE", "/public/memory/v2/forget/m-001")  # type: ignore[attr-defined]


class TestReflect:
    @pytest.mark.asyncio
    async def test_reflect(self, memory_client: MemoryClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = {  # type: ignore[attr-defined]
            "entity_id": "user-1",
            "insights": ["Prefers blue", "Observant"],
            "summary": "An observant user",
        }
        result = await memory_client.reflect("user-1")
        assert isinstance(result, Reflection)
        assert len(result.insights) == 2


class TestProfile:
    @pytest.mark.asyncio
    async def test_profile(self, memory_client: MemoryClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = {  # type: ignore[attr-defined]
            "entity_id": "user-1",
            "preferences": ["blue"],
            "behaviors": ["asks questions"],
            "facts": ["developer"],
            "summary": "A developer who likes blue",
        }
        result = await memory_client.profile("user-1")
        assert isinstance(result, Profile)
        assert "blue" in result.preferences


class TestEntities:
    @pytest.mark.asyncio
    async def test_entities(self, memory_client: MemoryClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = [  # type: ignore[attr-defined]
            {"id": "e1", "canonical_name": "user-1", "entity_type": "person", "aliases": [], "properties": {}, "memory_count": 5},
        ]
        entities = await memory_client.entities()
        assert len(entities) == 1
        assert entities[0].canonical_name == "user-1"

    @pytest.mark.asyncio
    async def test_entities_with_type(self, memory_client: MemoryClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = []  # type: ignore[attr-defined]
        await memory_client.entities(entity_type="person")
        call_args = mock_http.request.call_args  # type: ignore[attr-defined]
        assert call_args[1]["params"] == {"type": "person"}


class TestProcess:
    @pytest.mark.asyncio
    async def test_process(self, memory_client: MemoryClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = [MEMORY_DATA]  # type: ignore[attr-defined]
        messages = [{"role": "user", "content": "The sky is blue"}]
        result = await memory_client.process(messages)
        assert len(result) == 1
        assert isinstance(result[0], Memory)
