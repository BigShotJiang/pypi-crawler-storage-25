"""Shared test fixtures.

Refs #2372
"""

from __future__ import annotations

from typing import Any, Dict, Optional
from unittest.mock import AsyncMock

import pytest

from ainative_agent._http import HTTPClient
from ainative_agent.client import AINativeClient


@pytest.fixture
def mock_http() -> HTTPClient:
    """HTTPClient with a mocked request method."""
    http = HTTPClient(base_url="https://test.ainative.studio", api_key="test-key-000")
    http.request = AsyncMock()  # type: ignore[assignment]
    return http


@pytest.fixture
def client(mock_http: HTTPClient) -> AINativeClient:
    """AINativeClient wired to a mock HTTP client."""
    c = AINativeClient(api_key="test-key-000", base_url="https://test.ainative.studio")
    c._http = mock_http
    # Reset lazy-init caches so they pick up the new http
    c._agents = None
    c._tasks = None
    c._memory = None
    c._graph = None
    c._vectors = None
    c._files = None
    c._tables = None
    c._chat = None
    c._threads = None
    c._events = None
    return c
