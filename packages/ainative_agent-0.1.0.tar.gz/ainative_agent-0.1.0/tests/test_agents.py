"""Tests for AgentClient CRUD operations.

Refs #2372
"""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from ainative_agent._http import HTTPClient
from ainative_agent.agents import AgentClient
from ainative_agent.types import AgentRegistration


@pytest.fixture
def agent_client(mock_http: HTTPClient) -> AgentClient:
    return AgentClient(mock_http)


class TestAgentRegister:
    @pytest.mark.asyncio
    async def test_register_returns_model(self, agent_client: AgentClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = {  # type: ignore[attr-defined]
            "id": "agent-001",
            "name": "test-agent",
            "agent_type": "worker",
            "capabilities": ["read", "write"],
            "oversight_level": "LOGGING",
            "status": "active",
            "created_at": "2026-01-01T00:00:00Z",
        }
        result = await agent_client.register("test-agent", "worker", ["read", "write"])

        assert isinstance(result, AgentRegistration)
        assert result.id == "agent-001"
        assert result.name == "test-agent"
        assert result.capabilities == ["read", "write"]
        mock_http.request.assert_called_once_with(  # type: ignore[attr-defined]
            "POST",
            "/auth/agents/register",
            json={
                "name": "test-agent",
                "agent_type": "worker",
                "capabilities": ["read", "write"],
                "oversight_level": "LOGGING",
            },
        )

    @pytest.mark.asyncio
    async def test_register_with_model(self, agent_client: AgentClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = {  # type: ignore[attr-defined]
            "id": "agent-002",
            "name": "smart-agent",
            "agent_type": "reasoner",
            "model": "claude-3",
            "capabilities": ["reason"],
            "oversight_level": "APPROVAL",
            "status": "active",
            "created_at": "2026-01-01T00:00:00Z",
        }
        result = await agent_client.register(
            "smart-agent", "reasoner", ["reason"], model="claude-3", oversight_level="APPROVAL"
        )
        assert result.model == "claude-3"
        assert result.oversight_level == "APPROVAL"


class TestAgentList:
    @pytest.mark.asyncio
    async def test_list_returns_models(self, agent_client: AgentClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = [  # type: ignore[attr-defined]
            {"id": "a1", "name": "agent-1", "agent_type": "worker", "capabilities": [], "oversight_level": "LOGGING", "status": "active", "created_at": ""},
            {"id": "a2", "name": "agent-2", "agent_type": "worker", "capabilities": [], "oversight_level": "LOGGING", "status": "active", "created_at": ""},
        ]
        result = await agent_client.list()
        assert len(result) == 2
        assert all(isinstance(a, AgentRegistration) for a in result)


class TestAgentGet:
    @pytest.mark.asyncio
    async def test_get_by_id(self, agent_client: AgentClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = {  # type: ignore[attr-defined]
            "id": "agent-001",
            "name": "test",
            "agent_type": "worker",
            "capabilities": [],
            "oversight_level": "LOGGING",
            "status": "active",
            "created_at": "",
        }
        result = await agent_client.get("agent-001")
        assert result.id == "agent-001"
        mock_http.request.assert_called_once_with("GET", "/auth/agents/agent-001")  # type: ignore[attr-defined]


class TestAgentUpdate:
    @pytest.mark.asyncio
    async def test_update_name(self, agent_client: AgentClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = {  # type: ignore[attr-defined]
            "id": "agent-001",
            "name": "updated-name",
            "agent_type": "worker",
            "capabilities": [],
            "oversight_level": "LOGGING",
            "status": "active",
            "created_at": "",
        }
        result = await agent_client.update("agent-001", name="updated-name")
        assert result.name == "updated-name"


class TestAgentDelete:
    @pytest.mark.asyncio
    async def test_delete(self, agent_client: AgentClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = None  # type: ignore[attr-defined]
        await agent_client.delete("agent-001")
        mock_http.request.assert_called_once_with("DELETE", "/auth/agents/agent-001")  # type: ignore[attr-defined]


class TestAgentKeys:
    @pytest.mark.asyncio
    async def test_create_key(self, agent_client: AgentClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = {"key": "sk-xxx", "key_id": "k1"}  # type: ignore[attr-defined]
        result = await agent_client.create_key("agent-001", "my-key", ["read"])
        assert result["key"] == "sk-xxx"

    @pytest.mark.asyncio
    async def test_list_keys(self, agent_client: AgentClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = [  # type: ignore[attr-defined]
            {"id": "k1", "name": "key1", "key_prefix": "sk-", "scoped_capabilities": ["read"], "is_active": True, "created_at": ""},
        ]
        keys = await agent_client.list_keys("agent-001")
        assert len(keys) == 1
        assert keys[0].name == "key1"

    @pytest.mark.asyncio
    async def test_revoke_key(self, agent_client: AgentClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = None  # type: ignore[attr-defined]
        await agent_client.revoke_key("agent-001", "k1")
        mock_http.request.assert_called_once_with("DELETE", "/auth/agents/agent-001/keys/k1")  # type: ignore[attr-defined]
