"""Tests for AINativeClient instantiation, auth, and context manager.

Refs #2372
"""

from __future__ import annotations

import pytest

from ainative_agent import AINativeClient, APIError, AuthenticationError, RateLimitError
from ainative_agent._http import HTTPClient


class TestClientInit:
    """Client instantiation and configuration."""

    def test_default_base_url(self) -> None:
        c = AINativeClient(api_key="sk-test")
        assert c._http._base_url == "https://api.ainative.studio"

    def test_custom_base_url(self) -> None:
        c = AINativeClient(api_key="sk-test", base_url="https://custom.example.com")
        assert c._http._base_url == "https://custom.example.com"

    def test_trailing_slash_stripped(self) -> None:
        c = AINativeClient(api_key="sk-test", base_url="https://api.example.com/")
        assert c._http._base_url == "https://api.example.com"


class TestAuthHeaders:
    """Auth header injection."""

    def test_api_key_header(self) -> None:
        http = HTTPClient(api_key="sk-abc123")
        headers = http._build_headers()
        assert headers["X-API-Key"] == "sk-abc123"
        assert "Authorization" not in headers

    def test_bearer_token_header(self) -> None:
        http = HTTPClient(token="jwt-xyz")
        headers = http._build_headers()
        assert headers["Authorization"] == "Bearer jwt-xyz"
        assert "X-API-Key" not in headers

    def test_api_key_takes_precedence(self) -> None:
        http = HTTPClient(api_key="sk-key", token="jwt-token")
        headers = http._build_headers()
        assert headers["X-API-Key"] == "sk-key"
        assert "Authorization" not in headers

    def test_no_auth(self) -> None:
        http = HTTPClient()
        headers = http._build_headers()
        assert "X-API-Key" not in headers
        assert "Authorization" not in headers
        assert headers["Content-Type"] == "application/json"


class TestContextManager:
    """Async context manager protocol."""

    @pytest.mark.asyncio
    async def test_async_context_manager(self) -> None:
        async with AINativeClient(api_key="sk-test") as client:
            assert isinstance(client, AINativeClient)
        # After exit, client should have closed


class TestLazyProperties:
    """Module properties are lazily initialized."""

    def test_all_properties_exist(self) -> None:
        c = AINativeClient(api_key="sk-test")
        # Access all properties to ensure they are initialized
        assert c.agents is not None
        assert c.tasks is not None
        assert c.memory is not None
        assert c.graph is not None
        assert c.vectors is not None
        assert c.files is not None
        assert c.tables is not None
        assert c.chat is not None
        assert c.threads is not None
        assert c.events is not None

    def test_same_instance_on_repeated_access(self) -> None:
        c = AINativeClient(api_key="sk-test")
        assert c.agents is c.agents
        assert c.memory is c.memory


class TestErrorHierarchy:
    """Error classes inherit correctly."""

    def test_api_error_has_status(self) -> None:
        err = APIError("bad request", 400, "details")
        assert err.status_code == 400
        assert err.body == "details"
        assert str(err) == "bad request"

    def test_auth_error_is_api_error(self) -> None:
        err = AuthenticationError()
        assert isinstance(err, APIError)
        assert err.status_code == 401

    def test_rate_limit_error(self) -> None:
        err = RateLimitError(retry_after=30)
        assert isinstance(err, APIError)
        assert err.status_code == 429
        assert err.retry_after == 30
