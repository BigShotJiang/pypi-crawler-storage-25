"""Tests for TaskClient (swarm tasks).

Refs #2372
"""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from ainative_agent._http import HTTPClient
from ainative_agent.tasks import TaskClient
from ainative_agent.types import SwarmTask, SwarmTaskList


@pytest.fixture
def task_client(mock_http: HTTPClient) -> TaskClient:
    return TaskClient(mock_http)


TASK_DATA = {
    "task_id": "t-001",
    "status": "queued",
    "description": "Analyze logs",
    "agent_types": ["analyst"],
    "config": {},
    "result": None,
    "agents_used": [],
    "created_at": "2026-01-01T00:00:00Z",
    "updated_at": "2026-01-01T00:00:00Z",
}


class TestTaskSubmit:
    @pytest.mark.asyncio
    async def test_submit(self, task_client: TaskClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = TASK_DATA  # type: ignore[attr-defined]
        task = await task_client.submit("Analyze logs", agent_types=["analyst"])
        assert isinstance(task, SwarmTask)
        assert task.task_id == "t-001"
        assert task.status == "queued"

    @pytest.mark.asyncio
    async def test_submit_with_config(self, task_client: TaskClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = TASK_DATA  # type: ignore[attr-defined]
        await task_client.submit("Test", config={"max_steps": 10})
        call_args = mock_http.request.call_args  # type: ignore[attr-defined]
        assert call_args[1]["json"]["config"] == {"max_steps": 10}


class TestTaskGet:
    @pytest.mark.asyncio
    async def test_get(self, task_client: TaskClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = TASK_DATA  # type: ignore[attr-defined]
        task = await task_client.get("t-001")
        assert task.task_id == "t-001"


class TestTaskList:
    @pytest.mark.asyncio
    async def test_list(self, task_client: TaskClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = {"tasks": [TASK_DATA], "total": 1}  # type: ignore[attr-defined]
        result = await task_client.list()
        assert isinstance(result, SwarmTaskList)
        assert result.total == 1
        assert len(result.tasks) == 1

    @pytest.mark.asyncio
    async def test_list_with_filter(self, task_client: TaskClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = {"tasks": [], "total": 0}  # type: ignore[attr-defined]
        await task_client.list(status="running", limit=5)
        call_args = mock_http.request.call_args  # type: ignore[attr-defined]
        assert call_args[1]["params"]["status"] == "running"
        assert call_args[1]["params"]["limit"] == "5"


class TestTaskPoll:
    @pytest.mark.asyncio
    async def test_poll_completes(self, task_client: TaskClient, mock_http: HTTPClient) -> None:
        completed = {**TASK_DATA, "status": "completed", "result": {"output": "done"}}
        mock_http.request.side_effect = [  # type: ignore[attr-defined]
            {**TASK_DATA, "status": "running"},
            completed,
        ]
        results = []
        async for task in task_client.poll("t-001", interval=0.01):
            results.append(task)
        assert len(results) == 2
        assert results[-1].status == "completed"

    @pytest.mark.asyncio
    async def test_poll_immediate_complete(self, task_client: TaskClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = {**TASK_DATA, "status": "completed"}  # type: ignore[attr-defined]
        results = []
        async for task in task_client.poll("t-001", interval=0.01):
            results.append(task)
        assert len(results) == 1


class TestTaskCancel:
    @pytest.mark.asyncio
    async def test_cancel(self, task_client: TaskClient, mock_http: HTTPClient) -> None:
        mock_http.request.return_value = {**TASK_DATA, "status": "cancelled"}  # type: ignore[attr-defined]
        task = await task_client.cancel("t-001")
        assert task.status == "cancelled"
