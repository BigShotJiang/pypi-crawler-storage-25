"""Tests for BillingModule. Refs #2374, #2380."""

from unittest.mock import MagicMock

import pytest

from ainative_agent.billing import BillingModule


@pytest.fixture
def mock_request():
    return MagicMock()


@pytest.fixture
def billing(mock_request):
    return BillingModule(mock_request)


class TestGetUsage:
    def test_no_params(self, billing, mock_request):
        mock_request.return_value = {"total_cost_usd": 12.5, "total_requests": 100}
        result = billing.get_usage()
        mock_request.assert_called_once_with("GET", "/billing/usage", params={})
        assert result["total_cost_usd"] == 12.5

    def test_with_period(self, billing, mock_request):
        mock_request.return_value = {}
        billing.get_usage(period="weekly")
        mock_request.assert_called_once_with("GET", "/billing/usage", params={"period": "weekly"})

    def test_with_all_params(self, billing, mock_request):
        mock_request.return_value = {}
        billing.get_usage(period="daily", agent_id="ag-1", agent_type="assistant")
        mock_request.assert_called_once_with("GET", "/billing/usage", params={
            "period": "daily",
            "agent_id": "ag-1",
            "agent_type": "assistant",
        })


class TestSetBudget:
    def test_creates_budget(self, billing, mock_request):
        mock_request.return_value = {"id": "b-1", "agent_id": "ag-1", "limit_usd": 50}
        result = billing.set_budget("ag-1", 50, "monthly")
        mock_request.assert_called_once_with("POST", "/billing/budgets", json={
            "agent_id": "ag-1",
            "limit_usd": 50,
            "period": "monthly",
        })
        assert result["id"] == "b-1"

    def test_default_period(self, billing, mock_request):
        mock_request.return_value = {}
        billing.set_budget("ag-1", 100)
        call_kwargs = mock_request.call_args
        assert call_kwargs[1]["json"]["period"] == "monthly"


class TestGetBudgets:
    def test_returns_list(self, billing, mock_request):
        mock_request.return_value = [{"id": "b-1"}, {"id": "b-2"}]
        result = billing.get_budgets()
        mock_request.assert_called_once_with("GET", "/billing/budgets")
        assert len(result) == 2


class TestDeleteBudget:
    def test_deletes(self, billing, mock_request):
        billing.delete_budget("b-1")
        mock_request.assert_called_once_with("DELETE", "/billing/budgets/b-1")


class TestSetAlert:
    def test_creates_alert(self, billing, mock_request):
        mock_request.return_value = {"id": "a-1"}
        result = billing.set_alert("ag-1", 80, "dev@test.com")
        mock_request.assert_called_once_with("POST", "/billing/alerts", json={
            "agent_id": "ag-1",
            "threshold_percent": 80,
            "email": "dev@test.com",
        })
        assert result["id"] == "a-1"


class TestGetAlerts:
    def test_returns_list(self, billing, mock_request):
        mock_request.return_value = []
        result = billing.get_alerts()
        mock_request.assert_called_once_with("GET", "/billing/alerts")
        assert result == []


class TestDeleteAlert:
    def test_deletes(self, billing, mock_request):
        billing.delete_alert("a-1")
        mock_request.assert_called_once_with("DELETE", "/billing/alerts/a-1")


class TestGetDashboard:
    def test_returns_dashboard(self, billing, mock_request):
        mock_request.return_value = {"credit_balance": {"available_credits": 1000}}
        result = billing.get_dashboard()
        mock_request.assert_called_once_with("GET", "/billing/dashboard")
        assert result["credit_balance"]["available_credits"] == 1000


class TestGetCreditBalance:
    def test_returns_balance(self, billing, mock_request):
        mock_request.return_value = {"available_credits": 500, "plan": "pro"}
        result = billing.get_credit_balance()
        mock_request.assert_called_once_with("GET", "/billing/credits")
        assert result["available_credits"] == 500
