"""Tests for RegistryModule. Refs #2374, #2386."""

from unittest.mock import MagicMock

import pytest

from ainative_agent.registry import RegistryModule


@pytest.fixture
def mock_request():
    return MagicMock()


@pytest.fixture
def registry(mock_request):
    return RegistryModule(mock_request)


class TestCreate:
    def test_posts_config(self, registry, mock_request):
        config = {
            "name": "my-agent",
            "description": "Test",
            "agent_type": "assistant",
            "capabilities": ["chat"],
            "version": "1.0.0",
        }
        mock_request.return_value = {"id": "r-1", **config}
        result = registry.create(config)
        mock_request.assert_called_once_with("POST", "/registry/agents", json=config)
        assert result["id"] == "r-1"


class TestGet:
    def test_gets_by_id(self, registry, mock_request):
        mock_request.return_value = {"id": "r-1", "name": "my-agent"}
        result = registry.get("r-1")
        mock_request.assert_called_once_with("GET", "/registry/agents/r-1")
        assert result["name"] == "my-agent"


class TestSearch:
    def test_default_limit(self, registry, mock_request):
        mock_request.return_value = [{"id": "r-1"}]
        registry.search("assistant")
        mock_request.assert_called_once_with("GET", "/registry/agents/search", params={
            "q": "assistant",
            "limit": "20",
        })

    def test_custom_limit(self, registry, mock_request):
        mock_request.return_value = []
        registry.search("chat", 5)
        mock_request.assert_called_once_with("GET", "/registry/agents/search", params={
            "q": "chat",
            "limit": "5",
        })


class TestPublish:
    def test_publishes(self, registry, mock_request):
        registry.publish("r-1")
        mock_request.assert_called_once_with("POST", "/registry/agents/r-1/publish")


class TestUnpublish:
    def test_unpublishes(self, registry, mock_request):
        registry.unpublish("r-1")
        mock_request.assert_called_once_with("POST", "/registry/agents/r-1/unpublish")


class TestRate:
    def test_score_only(self, registry, mock_request):
        registry.rate("r-1", 5)
        mock_request.assert_called_once_with("POST", "/registry/agents/r-1/rate", json={
            "score": 5,
            "comment": None,
        })

    def test_score_with_comment(self, registry, mock_request):
        registry.rate("r-1", 4, "Great agent")
        mock_request.assert_called_once_with("POST", "/registry/agents/r-1/rate", json={
            "score": 4,
            "comment": "Great agent",
        })


class TestListVersions:
    def test_lists(self, registry, mock_request):
        mock_request.return_value = [{"version": "1.0.0"}, {"version": "1.1.0"}]
        result = registry.list_versions("r-1")
        mock_request.assert_called_once_with("GET", "/registry/agents/r-1/versions")
        assert len(result) == 2


class TestUpdate:
    def test_updates(self, registry, mock_request):
        mock_request.return_value = {"id": "r-1", "name": "updated"}
        result = registry.update("r-1", name="updated")
        mock_request.assert_called_once_with("PUT", "/registry/agents/r-1", json={"name": "updated"})
        assert result["name"] == "updated"


class TestDelete:
    def test_deletes(self, registry, mock_request):
        registry.delete("r-1")
        mock_request.assert_called_once_with("DELETE", "/registry/agents/r-1")
