"""Agents module (AAP - Agent-Authenticated Party).

Refs #2372
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from ainative_agent._http import HTTPClient
from ainative_agent.types import AgentKey, AgentRegistration, AuditLog


class AgentClient:
    """CRUD and lifecycle operations for registered agents."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    async def register(
        self,
        name: str,
        agent_type: str,
        capabilities: List[str],
        *,
        model: Optional[str] = None,
        oversight_level: str = "LOGGING",
    ) -> AgentRegistration:
        """Register a new agent."""
        payload: Dict[str, Any] = {
            "name": name,
            "agent_type": agent_type,
            "capabilities": capabilities,
            "oversight_level": oversight_level,
        }
        if model is not None:
            payload["model"] = model
        data = await self._http.request("POST", "/auth/agents/register", json=payload)
        return AgentRegistration.model_validate(data)

    async def list(self) -> List[AgentRegistration]:
        """List all registered agents."""
        data = await self._http.request("GET", "/auth/agents")
        return [AgentRegistration.model_validate(item) for item in data]

    async def get(self, agent_id: str) -> AgentRegistration:
        """Get a single agent by ID."""
        data = await self._http.request("GET", f"/auth/agents/{agent_id}")
        return AgentRegistration.model_validate(data)

    async def update(
        self,
        agent_id: str,
        *,
        name: Optional[str] = None,
        capabilities: Optional[List[str]] = None,
        oversight_level: Optional[str] = None,
    ) -> AgentRegistration:
        """Update an agent's configuration."""
        payload: Dict[str, Any] = {}
        if name is not None:
            payload["name"] = name
        if capabilities is not None:
            payload["capabilities"] = capabilities
        if oversight_level is not None:
            payload["oversight_level"] = oversight_level
        data = await self._http.request("PUT", f"/auth/agents/{agent_id}", json=payload)
        return AgentRegistration.model_validate(data)

    async def delete(self, agent_id: str) -> None:
        """Delete an agent."""
        await self._http.request("DELETE", f"/auth/agents/{agent_id}")

    async def create_token(
        self,
        agent_id: str,
        *,
        capabilities: Optional[List[str]] = None,
        task: Optional[str] = None,
        ttl_minutes: int = 60,
    ) -> Dict[str, str]:
        """Create a scoped JWT token for an agent."""
        payload: Dict[str, Any] = {"ttl_minutes": ttl_minutes}
        if capabilities is not None:
            payload["capabilities"] = capabilities
        if task is not None:
            payload["task"] = task
        data = await self._http.request("POST", f"/auth/agents/{agent_id}/token", json=payload)
        return data

    async def create_key(
        self,
        agent_id: str,
        name: str,
        scoped_capabilities: List[str],
    ) -> Dict[str, str]:
        """Create a persistent API key for an agent."""
        data = await self._http.request(
            "POST",
            f"/auth/agents/{agent_id}/keys",
            json={"name": name, "scoped_capabilities": scoped_capabilities},
        )
        return data

    async def list_keys(self, agent_id: str) -> List[AgentKey]:
        """List all API keys for an agent."""
        data = await self._http.request("GET", f"/auth/agents/{agent_id}/keys")
        return [AgentKey.model_validate(item) for item in data]

    async def revoke_key(self, agent_id: str, key_id: str) -> None:
        """Revoke an agent API key."""
        await self._http.request("DELETE", f"/auth/agents/{agent_id}/keys/{key_id}")

    async def audit(self, agent_id: str) -> List[AuditLog]:
        """Get audit log for an agent."""
        data = await self._http.request("GET", f"/auth/agents/{agent_id}/audit")
        return [AuditLog.model_validate(item) for item in data]

    async def capabilities(self) -> List[str]:
        """List all available agent capabilities."""
        return await self._http.request("GET", "/auth/agents/capabilities")
