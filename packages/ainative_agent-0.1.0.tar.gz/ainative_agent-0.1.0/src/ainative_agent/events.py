"""Events module (WebSocket real-time events).

Refs #2372
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import AsyncGenerator, List, Optional
from urllib.parse import quote

import websockets
import websockets.exceptions

from ainative_agent.types import AgentEvent

logger = logging.getLogger("ainative_agent.events")

_MAX_RECONNECT_ATTEMPTS = 5
_BASE_RECONNECT_DELAY = 2.0  # seconds


class EventClient:
    """Subscribe to real-time agent events via WebSocket."""

    def __init__(
        self,
        base_url: str = "https://api.ainative.studio",
        api_key: Optional[str] = None,
        token: Optional[str] = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._token = token

    def _ws_url(self) -> str:
        """Build WebSocket URL with auth token."""
        ws_base = self._base_url.replace("https://", "wss://").replace("http://", "ws://")
        auth_token = self._token or self._api_key or ""
        return f"{ws_base}/ws/v1/events?token={quote(auth_token, safe='')}"

    async def subscribe(
        self,
        channels: List[str],
        *,
        event_types: Optional[List[str]] = None,
    ) -> AsyncGenerator[AgentEvent, None]:
        """Subscribe to channels and yield events.

        Auto-reconnects with exponential backoff on connection loss
        (up to 5 attempts).
        """
        reconnect_attempts = 0

        while reconnect_attempts < _MAX_RECONNECT_ATTEMPTS:
            try:
                async with websockets.connect(self._ws_url()) as ws:
                    reconnect_attempts = 0  # reset on successful connection

                    # Subscribe to requested channels
                    for channel in channels:
                        await ws.send(json.dumps({"action": "subscribe", "channel": channel}))

                    async for raw_message in ws:
                        try:
                            data = json.loads(raw_message)
                            event = AgentEvent.model_validate(data)

                            # Filter by event type if requested
                            if event_types and event.event not in event_types:
                                continue

                            yield event
                        except (json.JSONDecodeError, Exception):
                            logger.debug("Skipping unparseable event message")
                            continue

            except websockets.exceptions.ConnectionClosed:
                reconnect_attempts += 1
                if reconnect_attempts >= _MAX_RECONNECT_ATTEMPTS:
                    logger.error("Max reconnect attempts reached, giving up")
                    return
                delay = _BASE_RECONNECT_DELAY * (2 ** (reconnect_attempts - 1))
                logger.info("WebSocket closed, reconnecting in %.1fs (attempt %d/%d)", delay, reconnect_attempts, _MAX_RECONNECT_ATTEMPTS)
                await asyncio.sleep(delay)

            except Exception:
                logger.exception("WebSocket error, stopping event stream")
                return
