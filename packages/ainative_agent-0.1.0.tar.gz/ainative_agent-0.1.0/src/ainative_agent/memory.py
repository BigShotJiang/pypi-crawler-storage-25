"""Memory module (ZeroMemory).

Refs #2372
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from ainative_agent._http import HTTPClient
from ainative_agent.types import Entity, Memory, Profile, Reflection


class MemoryClient:
    """Store, recall, and reflect on agent memories."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    async def remember(
        self,
        content: str,
        *,
        entity_id: Optional[str] = None,
        memory_type: str = "episodic",
        importance: float = 0.5,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Memory:
        """Store a new memory."""
        payload: Dict[str, Any] = {
            "content": content,
            "memory_type": memory_type,
            "importance": importance,
            "tags": tags or [],
        }
        if entity_id is not None:
            payload["entity_id"] = entity_id
        if metadata is not None:
            payload["metadata"] = metadata
        data = await self._http.request("POST", "/public/memory/v2/remember", json=payload)
        return Memory.model_validate(data)

    async def recall(
        self,
        query: str,
        *,
        entity_id: Optional[str] = None,
        layer: Optional[str] = None,
        limit: int = 10,
    ) -> List[Memory]:
        """Recall memories by semantic similarity."""
        payload: Dict[str, Any] = {"query": query, "limit": limit}
        if entity_id is not None:
            payload["entity_id"] = entity_id
        if layer is not None:
            payload["layer"] = layer
        data = await self._http.request("POST", "/public/memory/v2/recall", json=payload)
        return [Memory.model_validate(item) for item in data]

    async def forget(self, memory_id: str) -> None:
        """Delete a memory by ID."""
        await self._http.request("DELETE", f"/public/memory/v2/forget/{memory_id}")

    async def reflect(self, entity_id: str) -> Reflection:
        """Generate insights from an entity's memories."""
        data = await self._http.request("POST", f"/public/memory/v2/reflect/{entity_id}")
        return Reflection.model_validate(data)

    async def profile(self, entity_id: str) -> Profile:
        """Get a behavioral profile for an entity."""
        data = await self._http.request("GET", f"/public/memory/v2/profile/{entity_id}")
        return Profile.model_validate(data)

    async def relate(
        self,
        source_id: str,
        target_id: str,
        relationship_type: str,
        *,
        confidence: float = 0.8,
    ) -> Any:
        """Create a relationship between two entities."""
        return await self._http.request(
            "POST",
            "/public/memory/v2/relate",
            json={
                "source_id": source_id,
                "target_id": target_id,
                "relationship_type": relationship_type,
                "confidence": confidence,
            },
        )

    async def entities(self, *, entity_type: Optional[str] = None) -> List[Entity]:
        """List known entities."""
        params: Optional[Dict[str, str]] = None
        if entity_type is not None:
            params = {"type": entity_type}
        data = await self._http.request("GET", "/public/memory/v2/entities", params=params)
        return [Entity.model_validate(item) for item in data]

    async def process(self, messages: List[Dict[str, str]]) -> List[Memory]:
        """Extract memories from a conversation transcript."""
        data = await self._http.request(
            "POST", "/public/memory/v2/process", json={"messages": messages}
        )
        return [Memory.model_validate(item) for item in data]
