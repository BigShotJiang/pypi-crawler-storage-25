"""Billing module - usage tracking, budgets, alerts, and credits."""

from __future__ import annotations
from typing import Any, Callable


class BillingModule:
    """Client for billing and usage management APIs."""

    def __init__(self, request: Callable[..., Any]):
        self._request = request

    def get_usage(
        self,
        period: str | None = None,
        agent_id: str | None = None,
        agent_type: str | None = None,
    ) -> dict[str, Any]:
        """Get usage breakdown for the current billing period."""
        params: dict[str, str] = {}
        if period:
            params["period"] = period
        if agent_id:
            params["agent_id"] = agent_id
        if agent_type:
            params["agent_type"] = agent_type
        return self._request("GET", "/billing/usage", params=params)

    def set_budget(
        self,
        agent_id: str,
        limit_usd: float,
        period: str = "monthly",
    ) -> dict[str, Any]:
        """Set a spending budget for an agent."""
        return self._request("POST", "/billing/budgets", json={
            "agent_id": agent_id,
            "limit_usd": limit_usd,
            "period": period,
        })

    def get_budgets(self) -> list[dict[str, Any]]:
        """List all active budgets."""
        return self._request("GET", "/billing/budgets")

    def delete_budget(self, budget_id: str) -> None:
        """Delete a budget."""
        self._request("DELETE", f"/billing/budgets/{budget_id}")

    def set_alert(
        self,
        agent_id: str,
        threshold_percent: int,
        email: str,
    ) -> dict[str, Any]:
        """Set a spending alert for an agent."""
        return self._request("POST", "/billing/alerts", json={
            "agent_id": agent_id,
            "threshold_percent": threshold_percent,
            "email": email,
        })

    def get_alerts(self) -> list[dict[str, Any]]:
        """List all active alerts."""
        return self._request("GET", "/billing/alerts")

    def delete_alert(self, alert_id: str) -> None:
        """Delete an alert."""
        self._request("DELETE", f"/billing/alerts/{alert_id}")

    def get_dashboard(self) -> dict[str, Any]:
        """Get the billing dashboard summary."""
        return self._request("GET", "/billing/dashboard")

    def get_credit_balance(self) -> dict[str, Any]:
        """Get current credit balance."""
        return self._request("GET", "/billing/credits")
