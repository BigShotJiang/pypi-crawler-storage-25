"""AINative SDK error types.

Refs #2372
"""

from __future__ import annotations


class AINativeError(Exception):
    """Base exception for all AINative SDK errors."""

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message


class APIError(AINativeError):
    """Raised on non-2xx API responses."""

    def __init__(self, message: str, status_code: int, body: str | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body

    def __repr__(self) -> str:
        return f"APIError(status_code={self.status_code}, message={self.message!r})"


class AuthenticationError(APIError):
    """Raised on 401 responses."""

    def __init__(self, message: str = "Invalid or expired credentials") -> None:
        super().__init__(message, 401)


class NotFoundError(APIError):
    """Raised on 404 responses."""

    def __init__(self, message: str = "Resource not found") -> None:
        super().__init__(message, 404)


class RateLimitError(APIError):
    """Raised on 429 responses."""

    def __init__(self, message: str = "Rate limit exceeded", retry_after: int | None = None) -> None:
        super().__init__(message, 429)
        self.retry_after = retry_after


class NetworkError(AINativeError):
    """Raised on connection failures."""

    def __init__(self, message: str, cause: Exception | None = None) -> None:
        super().__init__(message)
        self.__cause__ = cause
