"""Vectors module.

Refs #2372
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from ainative_agent._http import HTTPClient
from ainative_agent.types import VectorRecord, VectorResult, VectorStats


class VectorClient:
    """Upsert, search, and manage vector embeddings."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    async def upsert(
        self,
        id: str,
        values: List[float],
        *,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Upsert a vector by ID."""
        payload: Dict[str, Any] = {"id": id, "values": values}
        if metadata is not None:
            payload["metadata"] = metadata
        await self._http.request("PUT", "/public/vectors/", json=payload)

    async def search(
        self,
        *,
        query: Optional[str] = None,
        vector: Optional[List[float]] = None,
        limit: int = 10,
        filter: Optional[Dict[str, Any]] = None,
    ) -> List[VectorResult]:
        """Search vectors by text query or raw vector."""
        payload: Dict[str, Any] = {"limit": limit}
        if query is not None:
            payload["query"] = query
        if vector is not None:
            payload["vector"] = vector
        if filter is not None:
            payload["filter"] = filter
        data = await self._http.request("POST", "/public/vectors/search", json=payload)
        return [VectorResult.model_validate(item) for item in data]

    async def get(self, id: str) -> VectorRecord:
        """Get a vector record by ID."""
        data = await self._http.request("GET", f"/public/vectors/{id}")
        return VectorRecord.model_validate(data)

    async def delete(self, id: str) -> None:
        """Delete a vector by ID."""
        await self._http.request("DELETE", f"/public/vectors/{id}")

    async def stats(self) -> VectorStats:
        """Get vector store statistics."""
        data = await self._http.request("GET", "/public/vectors/stats")
        return VectorStats.model_validate(data)
