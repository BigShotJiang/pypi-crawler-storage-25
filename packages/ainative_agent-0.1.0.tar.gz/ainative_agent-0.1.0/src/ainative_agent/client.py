"""AINativeClient -- main entry point for the Python SDK.

Refs #2372
"""

from __future__ import annotations

from typing import Any, Optional

from ainative_agent._http import HTTPClient
from ainative_agent.agents import AgentClient
from ainative_agent.chat import ChatClient
from ainative_agent.events import EventClient
from ainative_agent.files import FileClient
from ainative_agent.graph import GraphClient
from ainative_agent.memory import MemoryClient
from ainative_agent.tables import TableClient
from ainative_agent.tasks import TaskClient
from ainative_agent.threads import ThreadClient
from ainative_agent.vectors import VectorClient


class AINativeClient:
    """Async client for all AINative Agent APIs.

    Usage::

        async with AINativeClient(api_key="sk-...") as client:
            agents = await client.agents.list()
            memories = await client.memory.recall(query="project status")
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        token: Optional[str] = None,
        base_url: str = "https://api.ainative.studio",
        timeout: float = 30.0,
    ) -> None:
        self._http = HTTPClient(
            base_url=base_url,
            api_key=api_key,
            token=token,
            timeout=timeout,
        )

        self._agents: Optional[AgentClient] = None
        self._tasks: Optional[TaskClient] = None
        self._memory: Optional[MemoryClient] = None
        self._graph: Optional[GraphClient] = None
        self._vectors: Optional[VectorClient] = None
        self._files: Optional[FileClient] = None
        self._tables: Optional[TableClient] = None
        self._chat: Optional[ChatClient] = None
        self._threads: Optional[ThreadClient] = None
        self._events: Optional[EventClient] = None

        # Store config for EventClient
        self._base_url = base_url
        self._api_key = api_key
        self._token = token

    @property
    def agents(self) -> AgentClient:
        """Agent registration, keys, and audit."""
        if self._agents is None:
            self._agents = AgentClient(self._http)
        return self._agents

    @property
    def tasks(self) -> TaskClient:
        """Swarm task submission and polling."""
        if self._tasks is None:
            self._tasks = TaskClient(self._http)
        return self._tasks

    @property
    def memory(self) -> MemoryClient:
        """ZeroMemory: remember, recall, forget, reflect."""
        if self._memory is None:
            self._memory = MemoryClient(self._http)
        return self._memory

    @property
    def graph(self) -> GraphClient:
        """Context graph: entities, edges, GraphRAG, ontology."""
        if self._graph is None:
            self._graph = GraphClient(self._http)
        return self._graph

    @property
    def vectors(self) -> VectorClient:
        """Vector embeddings: upsert, search, delete."""
        if self._vectors is None:
            self._vectors = VectorClient(self._http)
        return self._vectors

    @property
    def files(self) -> FileClient:
        """File storage: upload, download, presigned URLs."""
        if self._files is None:
            self._files = FileClient(self._http)
        return self._files

    @property
    def tables(self) -> TableClient:
        """NoSQL tables: create, query, insert, update."""
        if self._tables is None:
            self._tables = TableClient(self._http)
        return self._tables

    @property
    def chat(self) -> ChatClient:
        """Chat completions with streaming."""
        if self._chat is None:
            self._chat = ChatClient(self._http)
        return self._chat

    @property
    def threads(self) -> ThreadClient:
        """Conversation threads."""
        if self._threads is None:
            self._threads = ThreadClient(self._http)
        return self._threads

    @property
    def events(self) -> EventClient:
        """Real-time WebSocket events."""
        if self._events is None:
            self._events = EventClient(
                base_url=self._base_url,
                api_key=self._api_key,
                token=self._token,
            )
        return self._events

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._http.close()

    async def __aenter__(self) -> AINativeClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
