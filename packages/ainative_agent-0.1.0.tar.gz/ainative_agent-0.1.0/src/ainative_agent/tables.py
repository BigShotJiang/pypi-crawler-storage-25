"""Tables module (NoSQL).

Refs #2372
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional
from urllib.parse import quote

from ainative_agent._http import HTTPClient
from ainative_agent.types import Table


class TableClient:
    """NoSQL table operations: create, query, insert, update, delete."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    async def create(self, name: str, *, schema: Optional[Dict[str, Any]] = None) -> Table:
        """Create a new table."""
        payload: Dict[str, Any] = {"name": name}
        if schema is not None:
            payload["schema"] = schema
        data = await self._http.request("POST", "/public/tables/", json=payload)
        return Table.model_validate(data)

    async def list(self) -> List[Table]:
        """List all tables."""
        data = await self._http.request("GET", "/public/tables/")
        return [Table.model_validate(item) for item in data]

    async def get(self, name: str) -> Table:
        """Get a table by name."""
        data = await self._http.request("GET", f"/public/tables/{quote(name, safe='')}")
        return Table.model_validate(data)

    async def delete(self, name: str) -> None:
        """Delete a table."""
        await self._http.request("DELETE", f"/public/tables/{quote(name, safe='')}")

    async def insert(self, table: str, rows: List[Dict[str, Any]]) -> Dict[str, int]:
        """Insert rows into a table."""
        return await self._http.request(
            "POST", f"/public/tables/{quote(table, safe='')}/rows", json={"rows": rows}
        )

    async def query(
        self,
        table: str,
        *,
        filter: Optional[Dict[str, Any]] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        sort: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Query rows from a table."""
        params: Dict[str, str] = {}
        if filter is not None:
            params["filter"] = json.dumps(filter)
        if limit is not None:
            params["limit"] = str(limit)
        if offset is not None:
            params["offset"] = str(offset)
        if sort is not None:
            params["sort"] = sort
        return await self._http.request(
            "GET", f"/public/tables/{quote(table, safe='')}/rows", params=params or None
        )

    async def update(
        self,
        table: str,
        filter: Dict[str, Any],
        updates: Dict[str, Any],
    ) -> Dict[str, int]:
        """Update rows matching a filter."""
        return await self._http.request(
            "PUT",
            f"/public/tables/{quote(table, safe='')}/rows",
            json={"filter": filter, "updates": updates},
        )

    async def delete_rows(self, table: str, filter: Dict[str, Any]) -> Dict[str, int]:
        """Delete rows matching a filter."""
        return await self._http.request(
            "DELETE",
            f"/public/tables/{quote(table, safe='')}/rows",
            json={"filter": filter},
        )
