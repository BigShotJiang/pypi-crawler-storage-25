"""Chat module with streaming support.

Refs #2372
"""

from __future__ import annotations

from typing import Any, AsyncIterator, Dict, List, Optional

import httpx

from ainative_agent._http import HTTPClient
from ainative_agent.errors import APIError, AuthenticationError, NetworkError, RateLimitError
from ainative_agent.types import ChatChunk, ChatRequest, ChatResponse


class ChatClient:
    """Chat completions with sync and streaming modes."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    async def complete(self, request: ChatRequest) -> ChatResponse:
        """Non-streaming chat completion."""
        payload = request.model_dump(exclude_none=True)
        payload["stream"] = False
        data = await self._http.request("POST", "/chat/completions", json=payload)
        return ChatResponse.model_validate(data)

    async def stream(self, request: ChatRequest) -> AsyncIterator[ChatChunk]:
        """Streaming chat completion via SSE.

        Yields ChatChunk objects as they arrive from the server.
        """
        payload = request.model_dump(exclude_none=True)
        payload["stream"] = True

        url = f"{self._http._base_url}/api/v1/chat/completions"
        headers = self._http._build_headers()

        try:
            async with httpx.AsyncClient() as client:
                async with client.stream(
                    "POST", url, json=payload, headers=headers, timeout=120.0
                ) as response:
                    if response.status_code == 401:
                        raise AuthenticationError()
                    if response.status_code == 429:
                        raise RateLimitError()
                    if response.status_code >= 400:
                        body = await response.aread()
                        raise APIError(f"API error: {response.status_code}", response.status_code, body.decode())

                    buffer = ""
                    async for chunk in response.aiter_text():
                        buffer += chunk
                        lines = buffer.split("\n")
                        buffer = lines.pop()

                        for line in lines:
                            line = line.strip()
                            if line.startswith("data: ") and line != "data: [DONE]":
                                yield ChatChunk.model_validate_json(line[6:])
        except httpx.ConnectError as exc:
            raise NetworkError("Stream connection failed", exc) from exc
