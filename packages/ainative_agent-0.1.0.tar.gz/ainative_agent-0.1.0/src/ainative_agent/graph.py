"""Context Graph module (GraphRAG).

Refs #2372
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional
from urllib.parse import quote

from ainative_agent._http import HTTPClient
from ainative_agent.types import (
    Contradiction,
    Edge,
    Entity,
    GraphPath,
    GraphStats,
    Ontology,
    SearchResult,
)


class GraphClient:
    """Context graph operations: entities, edges, traversal, GraphRAG, ontology."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    # -- Entities ---------------------------------------------------------------

    async def create_entity(
        self,
        name: str,
        type: str,
        *,
        aliases: Optional[List[str]] = None,
        properties: Optional[Dict[str, Any]] = None,
    ) -> Entity:
        """Create a graph entity."""
        payload: Dict[str, Any] = {"name": name, "type": type}
        if aliases is not None:
            payload["aliases"] = aliases
        if properties is not None:
            payload["properties"] = properties
        data = await self._http.request("POST", "/public/memory/v2/graph/entity", json=payload)
        return Entity.model_validate(data)

    async def list_entities(self, *, type: Optional[str] = None) -> List[Entity]:
        """List graph entities."""
        params: Optional[Dict[str, str]] = None
        if type is not None:
            params = {"type": type}
        data = await self._http.request("GET", "/public/memory/v2/graph/entities", params=params)
        return [Entity.model_validate(item) for item in data]

    async def merge_entities(
        self,
        source_name: str,
        target_name: str,
        *,
        keep: str = "source",
    ) -> Entity:
        """Merge two entities into one."""
        data = await self._http.request(
            "POST",
            "/public/memory/v2/graph/entity/merge",
            json={"source_name": source_name, "target_name": target_name, "keep": keep},
        )
        return Entity.model_validate(data)

    # -- Edges ------------------------------------------------------------------

    async def create_edge(
        self,
        source: str,
        target: str,
        predicate: str,
        *,
        confidence: float = 1.0,
        properties: Optional[Dict[str, Any]] = None,
    ) -> Edge:
        """Create an edge between two entities."""
        payload: Dict[str, Any] = {
            "source": source,
            "target": target,
            "predicate": predicate,
            "confidence": confidence,
        }
        if properties is not None:
            payload["properties"] = properties
        data = await self._http.request("POST", "/public/memory/v2/graph/edge", json=payload)
        return Edge.model_validate(data)

    # -- Traversal --------------------------------------------------------------

    async def traverse(
        self,
        start: str,
        *,
        max_hops: Optional[int] = None,
        predicate_filter: Optional[List[str]] = None,
    ) -> GraphPath:
        """Traverse the graph from a starting entity."""
        payload: Dict[str, Any] = {"start": start}
        if max_hops is not None:
            payload["max_hops"] = max_hops
        if predicate_filter is not None:
            payload["predicate_filter"] = predicate_filter
        data = await self._http.request("POST", "/public/memory/v2/graph/traverse", json=payload)
        return GraphPath.model_validate(data)

    async def neighbors(self, name: str) -> List[Entity]:
        """Get neighbors of an entity."""
        data = await self._http.request("GET", f"/public/memory/v2/graph/neighbors/{quote(name, safe='')}")
        return [Entity.model_validate(item) for item in data]

    # -- GraphRAG ---------------------------------------------------------------

    async def graphrag(
        self,
        query: str,
        *,
        limit: Optional[int] = None,
        graph_weight: Optional[float] = None,
    ) -> List[SearchResult]:
        """Hybrid vector + graph search."""
        payload: Dict[str, Any] = {"query": query}
        if limit is not None:
            payload["limit"] = limit
        if graph_weight is not None:
            payload["graph_weight"] = graph_weight
        data = await self._http.request("POST", "/public/memory/v2/graph/graphrag", json=payload)
        return [SearchResult.model_validate(item) for item in data]

    # -- Stats ------------------------------------------------------------------

    async def stats(self) -> GraphStats:
        """Get graph statistics."""
        data = await self._http.request("GET", "/public/memory/v2/graph/stats")
        return GraphStats.model_validate(data)

    # -- Ontology ---------------------------------------------------------------

    async def get_ontology(self) -> Ontology:
        """Get the current ontology."""
        data = await self._http.request("GET", "/public/memory/v2/graph/ontology")
        return Ontology.model_validate(data)

    async def set_ontology(self, ontology: Ontology) -> Ontology:
        """Set the ontology."""
        data = await self._http.request(
            "POST", "/public/memory/v2/graph/ontology", json=ontology.model_dump()
        )
        return Ontology.model_validate(data)

    async def infer_ontology(self) -> Ontology:
        """Auto-infer ontology from existing graph data."""
        data = await self._http.request("POST", "/public/memory/v2/graph/ontology/infer")
        return Ontology.model_validate(data)

    # -- Contradictions ---------------------------------------------------------

    async def get_contradictions(self) -> List[Contradiction]:
        """Get edge contradictions."""
        data = await self._http.request("GET", "/public/memory/v2/graph/contradictions")
        return [Contradiction.model_validate(item) for item in data]

    async def resolve_contradiction(self, edge_id: str, action: str) -> None:
        """Resolve a contradiction (accept_new, keep_both, reject_new)."""
        await self._http.request(
            "POST",
            f"/public/memory/v2/graph/contradictions/{edge_id}/resolve",
            json={"action": action},
        )

    # -- Templates --------------------------------------------------------------

    async def get_templates(self) -> List[Dict[str, str]]:
        """List available graph templates."""
        return await self._http.request("GET", "/public/memory/v2/graph/templates")

    async def apply_template(self, name: str, params: Dict[str, Any]) -> Any:
        """Apply a graph template."""
        return await self._http.request(
            "POST", f"/public/memory/v2/graph/templates/{quote(name, safe='')}/apply", json=params
        )
