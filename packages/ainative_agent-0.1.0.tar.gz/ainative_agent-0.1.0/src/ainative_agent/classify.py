"""Task classification helper for swarm routing. Ported from agent-sdk-python."""

PATTERNS: dict[str, list[str]] = {
    "backend": ["api", "endpoint", "database", "backend", "rest", "graphql", "server", "crud", "migration"],
    "frontend": ["ui", "frontend", "react", "vue", "svelte", "css", "component", "page", "layout"],
    "qa": ["test", "coverage", "qa", "bug", "regression", "e2e", "unit test", "integration test"],
    "devops": ["deploy", "ci/cd", "docker", "kubernetes", "infra", "pipeline", "monitoring"],
    "security": ["auth", "security", "oauth", "vulnerability", "compliance", "encryption", "sso"],
    "architect": ["architecture", "design", "system", "scale", "microservice", "pattern", "refactor"],
    "docs": ["docs", "documentation", "readme", "guide", "tutorial", "api reference"],
    "data": ["data", "analytics", "pipeline", "etl", "warehouse", "dashboard", "metrics"],
}


def classify_task(description: str) -> dict[str, object]:
    """Classify a task description into agent types with confidence score.

    Returns a dict with ``agent_types`` (list of up to 3 best-fit agent roles)
    and ``confidence`` (0.0–0.95 float).
    """
    lower = description.lower()
    scores: dict[str, int] = {}

    for agent_type, keywords in PATTERNS.items():
        scores[agent_type] = sum(1 for k in keywords if k in lower)

    sorted_scores = sorted(
        [(t, s) for t, s in scores.items() if s > 0],
        key=lambda x: x[1],
        reverse=True,
    )

    if not sorted_scores:
        return {"agent_types": ["architect", "backend", "qa"], "confidence": 0.3}

    max_score = sorted_scores[0][1]
    threshold = max(1, max_score * 0.5)
    selected = [t for t, s in sorted_scores if s >= threshold][:3]

    total_keywords = sum(len(v) for v in PATTERNS.values())
    matched = sum(scores.values())
    confidence = min(0.95, round(matched / (total_keywords * 0.1), 2))

    return {"agent_types": selected, "confidence": confidence}
