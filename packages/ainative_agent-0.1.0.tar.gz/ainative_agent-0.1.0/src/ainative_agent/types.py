"""Pydantic v2 models mirroring the TypeScript SDK type definitions.

Refs #2372
"""

from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field


# -- Auth / Config -----------------------------------------------------------

class ClientConfig(BaseModel):
    """Configuration passed to AINativeClient."""

    api_key: Optional[str] = None
    token: Optional[str] = None
    base_url: str = "https://api.ainative.studio"
    timeout: float = 30.0


# -- Agents (AAP) -----------------------------------------------------------

class AgentRegistration(BaseModel):
    id: str
    name: str
    agent_type: str
    model: Optional[str] = None
    capabilities: List[str] = Field(default_factory=list)
    oversight_level: str = "LOGGING"
    status: str = "active"
    created_at: str = ""


class AgentKey(BaseModel):
    id: str
    name: str
    key_prefix: str = ""
    scoped_capabilities: List[str] = Field(default_factory=list)
    is_active: bool = True
    created_at: str = ""


class AuditLog(BaseModel):
    id: str
    agent_id: str
    action: str
    resource: str
    details: Dict[str, Any] = Field(default_factory=dict)
    created_at: str = ""


# -- Swarm -------------------------------------------------------------------

class SwarmTask(BaseModel):
    task_id: str
    status: Literal["queued", "running", "completed", "failed", "cancelled"] = "queued"
    description: str = ""
    agent_types: List[str] = Field(default_factory=list)
    config: Dict[str, Any] = Field(default_factory=dict)
    result: Optional[Dict[str, Any]] = None
    agents_used: List[str] = Field(default_factory=list)
    created_at: str = ""
    updated_at: str = ""


class SwarmTaskList(BaseModel):
    tasks: List[SwarmTask] = Field(default_factory=list)
    total: int = 0


# -- Memory ------------------------------------------------------------------

class Memory(BaseModel):
    id: str
    content: str
    memory_type: str = "episodic"
    importance: float = 0.5
    tags: List[str] = Field(default_factory=list)
    entity_id: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    created_at: str = ""
    score: Optional[float] = None


class Reflection(BaseModel):
    entity_id: str
    insights: List[str] = Field(default_factory=list)
    summary: str = ""


class Profile(BaseModel):
    entity_id: str
    preferences: List[str] = Field(default_factory=list)
    behaviors: List[str] = Field(default_factory=list)
    facts: List[str] = Field(default_factory=list)
    summary: str = ""


# -- Graph -------------------------------------------------------------------

class Entity(BaseModel):
    id: str
    canonical_name: str
    entity_type: str
    aliases: List[str] = Field(default_factory=list)
    properties: Dict[str, Any] = Field(default_factory=dict)
    memory_count: int = 0


class Edge(BaseModel):
    id: str
    source_id: str
    target_id: str
    predicate: str
    confidence: float = 1.0
    properties: Dict[str, Any] = Field(default_factory=dict)


class GraphPath(BaseModel):
    nodes: List[Entity] = Field(default_factory=list)
    edges: List[Edge] = Field(default_factory=list)
    hops: int = 0


class GraphStats(BaseModel):
    entity_count: int = 0
    edge_count: int = 0
    density: float = 0.0
    top_entities: List[Dict[str, Any]] = Field(default_factory=list)


class SearchResult(BaseModel):
    id: str
    content: str
    score: float
    source: Literal["vector", "graph", "hybrid"] = "vector"
    metadata: Dict[str, Any] = Field(default_factory=dict)


class Ontology(BaseModel):
    entity_types: List[Dict[str, Any]] = Field(default_factory=list)
    predicates: Dict[str, List[str]] = Field(default_factory=dict)
    constraints: Dict[str, Any] = Field(default_factory=dict)


class Contradiction(BaseModel):
    edge_id: str
    predicate: str
    source: str
    target: str
    conflicting_edge_id: str
    created_at: str = ""


# -- Vectors -----------------------------------------------------------------

class VectorResult(BaseModel):
    id: str
    score: float
    metadata: Dict[str, Any] = Field(default_factory=dict)


class VectorRecord(BaseModel):
    id: str
    values: List[float] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class VectorStats(BaseModel):
    count: int = 0
    dimensions: int = 0


# -- Files -------------------------------------------------------------------

class FileRecord(BaseModel):
    id: str
    name: str
    content_type: str = "application/octet-stream"
    size: int = 0
    created_at: str = ""


# -- Tables ------------------------------------------------------------------

class Table(BaseModel):
    name: str
    row_count: int = 0
    schema_def: Dict[str, Any] = Field(default_factory=dict, alias="schema")
    created_at: str = ""

    model_config = {"populate_by_name": True}


# -- Chat --------------------------------------------------------------------

class ChatRequest(BaseModel):
    messages: List[Dict[str, str]]
    model: Optional[str] = None
    provider: Optional[str] = None
    tools: Optional[List[Dict[str, Any]]] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None


class ChatChoice(BaseModel):
    message: Dict[str, Any] = Field(default_factory=dict)
    finish_reason: str = ""


class ChatUsage(BaseModel):
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


class ChatResponse(BaseModel):
    id: str
    model: str = ""
    choices: List[ChatChoice] = Field(default_factory=list)
    usage: ChatUsage = Field(default_factory=ChatUsage)


class ChatChunk(BaseModel):
    id: str
    choices: List[Dict[str, Any]] = Field(default_factory=list)


# -- Threads -----------------------------------------------------------------

class Thread(BaseModel):
    id: str
    title: Optional[str] = None
    agent_types: List[str] = Field(default_factory=list)
    model: Optional[str] = None
    status: str = "active"
    message_count: int = 0
    last_message_at: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    created_at: str = ""


class ThreadMessage(BaseModel):
    id: str
    thread_id: str
    role: str
    content: Optional[str] = None
    tool_calls: Optional[List[Any]] = None
    tokens_used: Optional[int] = None
    created_at: str = ""


class ThreadWithMessages(Thread):
    messages: List[ThreadMessage] = Field(default_factory=list)


# -- Events ------------------------------------------------------------------

class AgentEvent(BaseModel):
    id: str
    event: str
    channel: str
    data: Dict[str, Any] = Field(default_factory=dict)
    timestamp: str = ""
