"""Registry module - agent registration, search, publishing, and versioning."""

from __future__ import annotations
from typing import Any, Callable


class RegistryModule:
    """Client for the agent registry APIs."""

    def __init__(self, request: Callable[..., Any]):
        self._request = request

    def create(self, config: dict[str, Any]) -> dict[str, Any]:
        """Register a new agent in the registry."""
        return self._request("POST", "/registry/agents", json=config)

    def get(self, agent_id: str) -> dict[str, Any]:
        """Get an agent registry entry by ID."""
        return self._request("GET", f"/registry/agents/{agent_id}")

    def search(self, query: str, limit: int = 20) -> list[dict[str, Any]]:
        """Search for agents in the registry."""
        return self._request("GET", "/registry/agents/search", params={
            "q": query,
            "limit": str(limit),
        })

    def publish(self, agent_id: str) -> None:
        """Publish an agent to make it publicly available."""
        self._request("POST", f"/registry/agents/{agent_id}/publish")

    def unpublish(self, agent_id: str) -> None:
        """Unpublish an agent."""
        self._request("POST", f"/registry/agents/{agent_id}/unpublish")

    def rate(self, agent_id: str, score: int, comment: str | None = None) -> None:
        """Rate an agent in the registry."""
        self._request("POST", f"/registry/agents/{agent_id}/rate", json={
            "score": score,
            "comment": comment,
        })

    def list_versions(self, agent_id: str) -> list[dict[str, Any]]:
        """List all versions of an agent."""
        return self._request("GET", f"/registry/agents/{agent_id}/versions")

    def update(self, agent_id: str, **kwargs: Any) -> dict[str, Any]:
        """Update an agent registry entry."""
        return self._request("PUT", f"/registry/agents/{agent_id}", json=kwargs)

    def delete(self, agent_id: str) -> None:
        """Delete an agent from the registry."""
        self._request("DELETE", f"/registry/agents/{agent_id}")
