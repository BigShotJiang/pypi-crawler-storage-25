"""Threads module.

Refs #2372
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from ainative_agent._http import HTTPClient
from ainative_agent.types import Thread, ThreadMessage, ThreadWithMessages


class ThreadClient:
    """Manage conversation threads."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    async def create(
        self,
        *,
        title: Optional[str] = None,
        agent_types: Optional[List[str]] = None,
        model: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Thread:
        """Create a new thread."""
        payload: Dict[str, Any] = {}
        if title is not None:
            payload["title"] = title
        if agent_types is not None:
            payload["agent_types"] = agent_types
        if model is not None:
            payload["model"] = model
        if metadata is not None:
            payload["metadata"] = metadata
        data = await self._http.request("POST", "/threads", json=payload)
        return Thread.model_validate(data)

    async def list(
        self,
        *,
        limit: Optional[int] = None,
        status: Optional[str] = None,
        search: Optional[str] = None,
    ) -> List[Thread]:
        """List threads."""
        params: Dict[str, str] = {}
        if limit is not None:
            params["limit"] = str(limit)
        if status is not None:
            params["status"] = status
        if search is not None:
            params["search"] = search
        data = await self._http.request("GET", "/threads", params=params or None)
        return [Thread.model_validate(item) for item in data]

    async def get(self, thread_id: str) -> ThreadWithMessages:
        """Get a thread with its messages."""
        data = await self._http.request("GET", f"/threads/{thread_id}")
        return ThreadWithMessages.model_validate(data)

    async def append(self, thread_id: str, role: str, content: str) -> ThreadMessage:
        """Append a message to a thread."""
        data = await self._http.request(
            "POST", f"/threads/{thread_id}/messages", json={"role": role, "content": content}
        )
        return ThreadMessage.model_validate(data)

    async def resume(self, thread_id: str) -> Any:
        """Resume a paused thread."""
        return await self._http.request("POST", f"/threads/{thread_id}/resume")

    async def fork(
        self,
        thread_id: str,
        message_id: str,
        *,
        title: Optional[str] = None,
    ) -> Thread:
        """Fork a thread from a specific message."""
        payload: Dict[str, Any] = {"message_id": message_id}
        if title is not None:
            payload["title"] = title
        data = await self._http.request("POST", f"/threads/{thread_id}/fork", json=payload)
        return Thread.model_validate(data)

    async def delete(self, thread_id: str) -> None:
        """Delete a thread."""
        await self._http.request("DELETE", f"/threads/{thread_id}")
