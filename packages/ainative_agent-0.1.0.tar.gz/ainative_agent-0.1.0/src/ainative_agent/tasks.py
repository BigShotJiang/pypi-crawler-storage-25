"""Tasks module (swarm task submission and polling).

Refs #2372
"""

from __future__ import annotations

import asyncio
from typing import Any, AsyncGenerator, Dict, List, Optional

from ainative_agent._http import HTTPClient
from ainative_agent.types import SwarmTask, SwarmTaskList

_TERMINAL_STATES = {"completed", "failed", "cancelled"}


class TaskClient:
    """Submit, poll, and manage swarm tasks."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    async def submit(
        self,
        description: str,
        *,
        agent_types: Optional[List[str]] = None,
        config: Optional[Dict[str, Any]] = None,
    ) -> SwarmTask:
        """Submit a new swarm task."""
        payload: Dict[str, Any] = {"description": description}
        if agent_types is not None:
            payload["agent_types"] = agent_types
        if config is not None:
            payload["config"] = config
        data = await self._http.request("POST", "/agent-swarm/tasks", json=payload)
        return SwarmTask.model_validate(data)

    async def get(self, task_id: str) -> SwarmTask:
        """Get a task by ID."""
        data = await self._http.request("GET", f"/agent-swarm/tasks/{task_id}")
        return SwarmTask.model_validate(data)

    async def list(
        self,
        *,
        status: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> SwarmTaskList:
        """List tasks with optional filtering."""
        params: Dict[str, str] = {}
        if status is not None:
            params["status"] = status
        if limit is not None:
            params["limit"] = str(limit)
        if offset is not None:
            params["offset"] = str(offset)
        data = await self._http.request("GET", "/agent-swarm/tasks", params=params or None)
        return SwarmTaskList.model_validate(data)

    async def cancel(self, task_id: str) -> SwarmTask:
        """Cancel a running task."""
        data = await self._http.request("POST", f"/agent-swarm/tasks/{task_id}/cancel")
        return SwarmTask.model_validate(data)

    async def poll(
        self,
        task_id: str,
        *,
        interval: float = 2.0,
        timeout: float = 300.0,
    ) -> AsyncGenerator[SwarmTask, None]:
        """Poll a task until it reaches a terminal state.

        Yields the task object every ``interval`` seconds.
        Raises ``TimeoutError`` if ``timeout`` is exceeded.
        """
        elapsed = 0.0
        while elapsed < timeout:
            task = await self.get(task_id)
            yield task
            if task.status in _TERMINAL_STATES:
                return
            await asyncio.sleep(interval)
            elapsed += interval
        raise TimeoutError(f"Task {task_id} did not complete within {timeout}s")
