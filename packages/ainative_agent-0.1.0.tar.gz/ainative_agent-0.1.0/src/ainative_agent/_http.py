"""Base HTTP client with retry logic and auth injection.

Refs #2372
"""

from __future__ import annotations

import asyncio
from typing import Any, Dict, Optional, Type, TypeVar

import httpx

from ainative_agent.errors import (
    APIError,
    AuthenticationError,
    NetworkError,
    NotFoundError,
    RateLimitError,
)

T = TypeVar("T")

_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}
_MAX_RETRIES = 3
_BASE_BACKOFF = 1.0  # seconds


class HTTPClient:
    """Async HTTP client wrapping httpx.AsyncClient with auth and retry."""

    def __init__(
        self,
        base_url: str = "https://api.ainative.studio",
        api_key: Optional[str] = None,
        token: Optional[str] = None,
        timeout: float = 30.0,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._token = token
        self._client = httpx.AsyncClient(timeout=timeout)

    def _build_headers(self) -> Dict[str, str]:
        headers: Dict[str, str] = {"Content-Type": "application/json"}
        if self._api_key:
            headers["X-API-Key"] = self._api_key
        elif self._token:
            headers["Authorization"] = f"Bearer {self._token}"
        return headers

    async def request(
        self,
        method: str,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, str]] = None,
    ) -> Any:
        """Send an HTTP request with automatic retry on transient errors.

        Retries up to 3 times with exponential backoff on 429 and 5xx responses.
        """
        url = f"{self._base_url}/api/v1{path}"
        headers = self._build_headers()
        last_error: Optional[Exception] = None

        for attempt in range(_MAX_RETRIES):
            try:
                response = await self._client.request(
                    method,
                    url,
                    json=json,
                    params=params,
                    headers=headers,
                )
            except httpx.ConnectError as exc:
                last_error = NetworkError("Connection failed", exc)
                if attempt < _MAX_RETRIES - 1:
                    await asyncio.sleep(_BASE_BACKOFF * (2 ** attempt))
                    continue
                raise last_error from exc
            except httpx.TimeoutException as exc:
                last_error = NetworkError("Request timed out", exc)
                if attempt < _MAX_RETRIES - 1:
                    await asyncio.sleep(_BASE_BACKOFF * (2 ** attempt))
                    continue
                raise last_error from exc

            if response.status_code < 400:
                if response.status_code == 204:
                    return None
                return response.json()

            # Retry on transient errors
            if response.status_code in _RETRYABLE_STATUS_CODES and attempt < _MAX_RETRIES - 1:
                retry_after = response.headers.get("Retry-After")
                delay = float(retry_after) if retry_after else _BASE_BACKOFF * (2 ** attempt)
                await asyncio.sleep(delay)
                continue

            # Non-retryable or final attempt -- raise
            self._raise_for_status(response)

        # Should not reach here, but satisfy type checker
        if last_error:
            raise last_error
        raise APIError("Request failed after retries", 500)  # pragma: no cover

    @staticmethod
    def _raise_for_status(response: httpx.Response) -> None:
        """Map HTTP status codes to typed exceptions."""
        status = response.status_code
        body = response.text

        if status == 401:
            raise AuthenticationError()
        if status == 404:
            raise NotFoundError(body or "Resource not found")
        if status == 429:
            retry_after_raw = response.headers.get("Retry-After")
            retry_after = int(retry_after_raw) if retry_after_raw else None
            raise RateLimitError(retry_after=retry_after)
        raise APIError(f"API error: {status}", status, body)

    async def close(self) -> None:
        """Close the underlying httpx client."""
        await self._client.aclose()
