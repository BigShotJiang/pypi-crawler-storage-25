"""Files module.

Refs #2372
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from ainative_agent._http import HTTPClient
from ainative_agent.types import FileRecord


class FileClient:
    """Upload, download, and manage files."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    async def upload(
        self,
        name: str,
        content_type: str = "application/octet-stream",
        size: int = 0,
    ) -> FileRecord:
        """Upload a file (metadata registration).

        For actual binary uploads, use the presigned URL workflow:
        1. Call upload() to register the file.
        2. Call presigned_url() to get a PUT URL.
        3. Upload binary data to the presigned URL.
        """
        data = await self._http.request(
            "POST",
            "/public/files/",
            json={"name": name, "content_type": content_type, "size": size},
        )
        return FileRecord.model_validate(data)

    async def download(self, file_id: str) -> Any:
        """Download file content by ID."""
        return await self._http.request("GET", f"/public/files/{file_id}/download")

    async def list(
        self,
        *,
        limit: Optional[int] = None,
        prefix: Optional[str] = None,
    ) -> List[FileRecord]:
        """List files."""
        params: Dict[str, str] = {}
        if limit is not None:
            params["limit"] = str(limit)
        if prefix is not None:
            params["prefix"] = prefix
        data = await self._http.request("GET", "/public/files/", params=params or None)
        return [FileRecord.model_validate(item) for item in data]

    async def delete(self, file_id: str) -> None:
        """Delete a file by ID."""
        await self._http.request("DELETE", f"/public/files/{file_id}")

    async def metadata(self, file_id: str) -> FileRecord:
        """Get file metadata."""
        data = await self._http.request("GET", f"/public/files/{file_id}")
        return FileRecord.model_validate(data)

    async def presigned_url(self, file_id: str, *, expires_in: int = 3600) -> str:
        """Generate a presigned URL for file access."""
        data = await self._http.request(
            "GET",
            f"/public/files/{file_id}/url",
            params={"expires_in": str(expires_in)},
        )
        return data["url"]
