from fasr_lid_firered.firered import FireRedForLID

__all__ = [
    "FireRedForLID",
]
