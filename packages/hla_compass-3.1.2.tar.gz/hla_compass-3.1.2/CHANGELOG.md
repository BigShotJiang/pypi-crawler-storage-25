# Changelog

All notable changes to the HLA-Compass SDK will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- N/A

### Removed
- N/A

### Changed
- N/A

### Fixed
- N/A

## [3.1.2] - 2026-05-15

### Fixed
- Supersedes the `3.1.1` release artifact for publish-output parity: `hla-compass publish --wait` now prints `moduleId:` to match the API JSON key, so log scrapers and SDK E2E extraction logic can reliably read the published module ID.

## [3.1.1] - 2026-05-15

### Added
- `hla-compass run --input <file>` as a backwards-compatible alias for `--parameters`, plus new `--wait`, `--timeout`, and `--poll-interval` flags so the CLI can block until a module run reaches a terminal state.
- `--env` flag on `hla-compass runs status` and `hla-compass runs logs` to target dev / staging / prod from a single login.

### Changed
- `pipeline-ui-template` restructured: `backend/handler.py` → `backend/main.py`, `ui/` → `frontend/` (with `vite.config.ts` + `standalone-entry.tsx`). `manifest.json` updated to point at the new entrypoint (`backend.main:configure`) and UI build path (`ui.distPath = frontend/dist`); inputs schema tightened to full JSON Schema with required `samplesheet` and `^s3://` pattern.

### Fixed
- `hla-compass run` no longer rejects the documented `--input` flag (CLI/test contract mismatch surfaced by the Lambda module smoke).

## [3.0.0] - 2026-04-16

### Added
- Typed scientific REST endpoints for HLA alleles, HLA frequencies, and protein coverage.

### Changed
- `get_hla_alleles()`, `get_hla_frequencies()`, and `get_protein_coverage()` now call typed REST endpoints only.
- Plain JWT user sessions can now use those helpers through `/v1/data/...`.

### Removed
- The SDK no longer performs an implicit direct-DB `ScientificQuery` fallback inside those high-level helpers.

### Migration
- High-level scientific helpers now require a reachable platform API endpoint.
- Module runtimes that still need direct database access should call `ScientificQuery` or `self.data.sql.query(...)` explicitly.
- API-key clients now use typed `/v1/api/data/...` endpoints instead of the raw SQL helper path.

## [2.1.3] - 2026-03-19

### Added
- `--sdk-path` / `HLA_COMPASS_SDK_PATH` to build/dev/serve/test/publish for local SDK validation.
- `--platform` to build/publish for explicit architecture targeting (multi-arch via buildx + `--push`).

### Removed
- Interactive module wizard + generator.
- Local dev server (`dev_server`) and mock testing utilities (`ModuleTester`, `MockContext`).
- CLI commands: `completions`, `config`, `data`, `list`, and legacy auth aliases.
- MCP descriptor generation during `build`.
- Async API client (`AsyncAPIClient`) and `httpx` dependency.
- `Module.serve` helper and runner serve-mode (`HLA_COMPASS_RUN_MODE=serve`).

### Changed
- `hla-compass test` now runs containerized tests by default.
- UI template dev flow uses `hla-compass serve` + Vite dev server proxy for `/api`.
- Scientific helpers (`get_hla_alleles`, `get_hla_frequencies`, `get_protein_coverage`) are now documented as scientific-query dependent convenience methods rather than plain JWT user endpoints.
- `predict_hla_binding` is documented as an async module-run wrapper that requires a configured binding module id.

### Fixed
- N/A

## [2.1.1] - 2026-03-18

### Added
- `hla-compass sign-image` for local Cosign-based signing of pre-built module images.
- `hla-compass verify-image` to validate registry trust policy resolution and run the local Trivy security gate before publish.
- `hla-compass publish --wait` and richer publish-status output, including trust-policy and security-scan details.
- OCI image labels and a configurable managed module runtime base image for `hla-compass build`.

### Changed
- `hla-compass init` now writes `backend/requirements.lock.txt` alongside `requirements.txt` and pins the generated SDK dependency in both files.
- External image publishing documentation now reflects the build, sign, verify, publish flow.

## [2.0.0] - 2024-11-XX

### Added
- `DataClient` with scoped SQL and Storage access
- `ModuleTester.quickstart()` for rapid testing
- Pydantic `Input` model support for typed inputs
- Storage helpers: `save_json`, `save_csv`, `save_excel`

### Changed
- Module execution now uses `RuntimeContext` with typed properties
- Manifest schema auto-generated from Pydantic models

## [1.0.0] - 2024-XX-XX

- Initial public release
