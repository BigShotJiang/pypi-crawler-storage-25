"""
HLA-Compass Python SDK

SDK for developing modules on the HLA-Compass platform.
"""

from importlib import import_module

from ._version import __version__

_LAZY_EXPORTS = {
    "Auth": (".auth", "Auth"),
    "AuthError": (".auth", "AuthError"),
    "APIClient": (".client", "APIClient"),
    "APIError": (".client", "APIError"),
    "ContextValidationError": (".context", "ContextValidationError"),
    "CreditReservation": (".context", "CreditReservation"),
    "RuntimeContext": (".context", "RuntimeContext"),
    "WorkflowMetadata": (".context", "WorkflowMetadata"),
    "DataAccessError": (".data", "DataAccessError"),
    "DataClient": (".data", "DataClient"),
    "HLAData": (".data", "HLAData"),
    "PeptideData": (".data", "PeptideData"),
    "ProteinData": (".data", "ProteinData"),
    "SampleData": (".data", "SampleData"),
    "ExecutionTimeoutError": (".module", "ExecutionTimeoutError"),
    "Module": (".module", "Module"),
    "ModuleError": (".module", "ModuleError"),
    "ValidationError": (".module", "ValidationError"),
    "PipelineModuleContext": (".pipeline_module", "PipelineModuleContext"),
    "Storage": (".storage", "Storage"),
    "StorageError": (".storage", "StorageError"),
    "ComputeType": (".types", "ComputeType"),
    "ExecutionContext": (".types", "ExecutionContext"),
    "JobStatus": (".types", "JobStatus"),
    "ModuleInput": (".types", "ModuleInput"),
    "ModuleOutput": (".types", "ModuleOutput"),
    "ModuleType": (".types", "ModuleType"),
}


def __getattr__(name: str):
    if name not in _LAZY_EXPORTS:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

    module_name, attr_name = _LAZY_EXPORTS[name]
    value = getattr(import_module(module_name, __name__), attr_name)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    return sorted(set(globals()) | set(__all__))


__all__ = [
    # Version
    "__version__",
    # Core classes
    "Module",
    "ModuleError",
    "ValidationError",
    "ExecutionTimeoutError",
    # API client
    "APIClient",
    "APIError",
    # Data access
    "DataClient",
    "DataAccessError",
    "PeptideData",
    "ProteinData",
    "SampleData",
    "HLAData",
    # Auth
    "Auth",
    "AuthError",
    # Storage
    "Storage",
    "StorageError",
    # Context
    "RuntimeContext",
    "ContextValidationError",
    "CreditReservation",
    "WorkflowMetadata",
    # Types
    "ExecutionContext",
    "ModuleInput",
    "ModuleOutput",
    "JobStatus",
    "ComputeType",
    "ModuleType",
]
