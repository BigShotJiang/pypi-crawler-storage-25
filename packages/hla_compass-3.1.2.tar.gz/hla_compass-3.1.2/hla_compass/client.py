"""
API client for HLA-Compass platform

This module provides the APIClient class that handles all communication
with the HLA-Compass REST API. It's used internally by the data access
classes (PeptideData, ProteinData, SampleData) to fetch scientific data.
"""

from __future__ import annotations

import json
import logging
import os
import platform
import re
import time
import uuid
from typing import Any, Callable, Dict, Iterator, List, Optional

import requests

from .auth import Auth
from .config import Config
from .hla import format_hla_allele_resolution, normalize_hla_locus, normalize_hla_resolution
from .utils import RateLimiter, parse_api_error

logger = logging.getLogger(__name__)

_COMPLETED_RUN_STATUSES = {"completed"}
_FAILED_RUN_STATUSES = {"failed", "cancelled", "cancel_requested", "timed_out", "timeout"}
_HLA_BINDING_METHODS = {"netmhcpan", "mhcflurry", "ensemble"}
_HLA_PEPTIDE_RE = re.compile(r"^[ACDEFGHIKLMNPQRSTVWY]+$")


class APIError(Exception):
    """API request error"""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        details: Optional[Dict] = None,
    ):
        super().__init__(message)
        self.status_code = status_code
        self.details = details or {}


class APIClient:
    """Client for interacting with the HLA-Compass API.

    Highlights
    ---------
    • **Iterators** – Use :meth:`iter_peptides`, :meth:`iter_proteins`, etc. to stream
      large result sets without manual paging::

          client = APIClient()
          for peptide in client.iter_peptides({"sequence": "SIINFEKL"}):
              print(peptide["sequence"], peptide["mass"])

    • **Rate limits** – Override defaults via environment variables
      ``HLA_RATE_LIMIT_MAX_REQUESTS`` and ``HLA_RATE_LIMIT_TIME_WINDOW``; inspect the
      active settings with :meth:`get_rate_limit_state`.

    • **Telemetry** – Attach a callback to capture structured metrics for every
      request (status, duration, retries)::

          def log_request(data: Dict[str, Any]) -> None:
              print("API", data["status_code"], data["duration_seconds"], data["url"])

          client = APIClient()
          client.set_telemetry_callback(log_request)
          client.get_peptide("pep_123")

    """

    def __init__(self, provider: Optional[str] = None, catalog: Optional[str] = None):
        """Initialize API client with authentication and a persistent session

        Args:
            provider: Data provider name (default: from config or 'alithea-bio')
            catalog: Data catalog name (default: from config or 'immunopeptidomics')
        """
        self.auth = Auth()
        self.config = Config()
        self.base_url = self.config.get_api_endpoint()

        # Set provider and catalog from args, config, or defaults
        self.provider = provider or self.config.get("data_provider", "alithea-bio")
        self.catalog = catalog or self.config.get("data_catalog", "immunopeptidomics")
        # Facades for data access (SQL + storage) via the same API client
        from .data import DataClient

        self.data = DataClient(provider=self.provider, catalog=self.catalog, api_client=self)
        self.catalog_storage = self.data.catalog_storage
        # Convenience facades for module + run operations
        self.modules = ModulesFacade(self)
        self.runs = RunsFacade(self)
        self.dataset_versions = DatasetVersionsFacade(self)
        self.uploads = UploadsFacade(self)
        self.datasets = DatasetsFacade(self)

        rl_settings = Config.get_rate_limit_settings()
        max_requests = rl_settings.get("max_requests", 100)
        time_window = rl_settings.get("time_window", 60)

        self.rate_limiter = RateLimiter(
            max_requests=max_requests,
            time_window=time_window,
        )
        circuit_cfg = Config.get_circuit_breaker_settings()
        self._cb_threshold = circuit_cfg.get("threshold", 5)
        self._cb_reset = circuit_cfg.get("reset_seconds", 60.0)
        self._cb_failures = 0
        self._cb_opened_at: Optional[float] = None
        self._rate_limit_state: Dict[str, Any] = {
            "max_requests": max_requests,
            "time_window": time_window,
            "last_wait_seconds": 0.0,
        }
        self._telemetry_callback: Optional[Callable[[Dict[str, Any]], None]] = None

        # Create a persistent HTTP session for connection reuse and default headers
        self.session = requests.Session()

        # Build a descriptive User-Agent
        try:
            from . import (
                __version__ as SDK_VERSION,  # Avoid hard dependency if import path changes
            )
        except Exception:
            SDK_VERSION = "unknown"

        ua = (
            f"hla-compass-sdk/{SDK_VERSION} "
            f"python/{platform.python_version()} "
            f"os/{platform.system()}-{platform.release()}"
        )

        self.session.headers.update(
            {
                "Accept": "application/json",
                "User-Agent": ua,
            }
        )

        # Retry behavior is centralized in _make_request so rate-limit,
        # telemetry, token-refresh, and circuit-breaker accounting see the
        # actual number of attempts. The default requests adapter performs no
        # status-code retries.

    def _headers(self) -> Dict[str, str]:
        """Compose request headers by combining session defaults with auth headers"""
        headers = dict(self.session.headers)
        headers.update(self.auth.get_headers())
        # Optional correlation id for cross-service tracing
        try:
            corr = self.config.get_correlation_id()
            if corr:
                headers["X-Correlation-Id"] = corr
        except Exception:
            pass
        return headers

    def _build_data_endpoint(self, entity: str, entity_id: Optional[str] = None) -> str:
        """Build a data API endpoint path.

        Args:
            entity: Entity name (e.g., 'peptides', 'proteins')
            entity_id: Optional entity ID for specific resource

        Returns:
            Complete endpoint path
        """
        base = f"/v1/data/{self.provider}/{self.catalog}/{entity}"
        if entity_id:
            return f"{base}/{entity_id}"
        return base

    def _uses_api_key_auth(self) -> bool:
        try:
            headers = self.auth.get_headers()
        except Exception:
            return False
        return any(str(key).lower() == "x-api-key" for key in (headers or {}).keys())

    def _build_scientific_rest_endpoint(self, suffix: str) -> str:
        prefix = "/v1/api/data" if self._uses_api_key_auth() else "/v1/data"
        clean_suffix = suffix.lstrip("/")
        return f"{prefix}/{self.provider}/{self.catalog}/{clean_suffix}"

    @staticmethod
    def _extract_hla_predictions(result_payload: Dict[str, Any]) -> List[Dict[str, Any]]:
        if isinstance(result_payload, dict):
            data = result_payload.get("data")
            if isinstance(data, dict) and isinstance(data.get("predictions"), list):
                return [item for item in data["predictions"] if isinstance(item, dict)]
            if isinstance(data, list):
                return [item for item in data if isinstance(item, dict)]
            if isinstance(result_payload.get("predictions"), list):
                return [item for item in result_payload["predictions"] if isinstance(item, dict)]
        raise APIError("Binding prediction run completed without a usable 'predictions' payload")

    @staticmethod
    def _normalize_module_run_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
        normalized = dict(payload)

        run_id = normalized.get("run_id") or normalized.get("runId") or normalized.get("id")
        if run_id:
            normalized.setdefault("run_id", str(run_id))

        module_id = normalized.get("module_id") or normalized.get("moduleId")
        module_block = normalized.get("module")
        if not module_id and isinstance(module_block, dict):
            module_id = module_block.get("id")
        if module_id:
            normalized.setdefault("module_id", str(module_id))

        return normalized

    def _resolve_hla_binding_module_id(self, module_id: Optional[str] = None) -> Optional[str]:
        if module_id:
            return str(module_id)

        for candidate in (
            os.environ.get("HLA_BINDING_MODULE_ID"),
            self.config.get("hla_binding_module_id"),
            self.config.get("hlaBindingModuleId"),
        ):
            if candidate:
                return str(candidate)
        return None

    def _make_request(
        self,
        method: str,
        endpoint: str,
        params: Dict = None,
        json_data: Dict = None,
        max_retries: int = 3,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Make an authenticated API request with retries and timeouts

        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint path (e.g., /v1/data/alithea-bio/immunopeptidomics/peptides)
            params: Query parameters
            json_data: JSON body data
            max_retries: Maximum number of retry attempts for transient errors

        Returns:
            Parsed JSON response

        Raises:
            APIError: If request fails
        """
        # Ensure we have authentication
        if not self.auth.is_authenticated():
            raise APIError("Not authenticated. Please run 'hla-compass auth login' first")

        # Circuit breaker guard
        now = time.time()
        if self._cb_opened_at and (now - self._cb_opened_at) < self._cb_reset:
            raise APIError("Circuit open due to repeated failures")
        if self._cb_opened_at and (now - self._cb_opened_at) >= self._cb_reset:
            self._cb_opened_at = None
            self._cb_failures = 0

        # Build full URL
        url = f"{self.base_url}{endpoint}"

        # Apply rate limiting
        self.rate_limiter.acquire()
        self._rate_limit_state["last_wait_seconds"] = self.rate_limiter.last_wait

        # Get combined headers (session defaults + auth)
        headers = self._headers()

        # Retry logic for transient errors
        # For POST requests, only allow retry when an idempotency key is provided.
        # Generate a stable idempotency key per call if not provided so that
        # internal retries are safe and deduplicated server-side.
        method_upper = (method or "").upper()
        if method_upper == "POST" and not idempotency_key:
            idempotency_key = str(uuid.uuid4())
        can_retry_post = method_upper != "POST" or (idempotency_key is not None)

        for attempt in range(max_retries):
            try:
                start_time = time.perf_counter()
                # Create a fresh set of headers per attempt and add a unique request id
                attempt_headers = dict(headers)
                request_id = str(uuid.uuid4())
                attempt_headers["X-Request-Id"] = request_id
                # Add idempotency key for POSTs to make retries safe
                if method_upper == "POST" and idempotency_key:
                    attempt_headers.setdefault("Idempotency-Key", idempotency_key)
                # Make request with configurable timeout (defaults: 5s connect, 30s read)
                timeouts = self.config.get_request_timeouts()
                response = self.session.request(
                    method=method,
                    url=url,
                    headers=attempt_headers,
                    params=params,
                    json=json_data,
                    timeout=(timeouts.get("connect", 5.0), timeouts.get("read", 30.0)),
                )
                duration = time.perf_counter() - start_time

                # Handle 401 - try to refresh token once
                if response.status_code == 401 and attempt == 0:
                    logger.info("Token expired, attempting refresh")
                    new_token = self.auth.refresh_token()
                    if new_token:
                        # Rebuild base headers to include new Authorization and retry
                        headers = self._headers()
                        continue  # Retry with new token
                    else:
                        raise APIError("Authentication expired. Please run 'hla-compass auth login' again")

                # Handle rate limiting with exponential backoff
                if response.status_code == 429:
                    if attempt < max_retries - 1:
                        retry_after = int(response.headers.get("Retry-After", 2**attempt))
                        logger.warning(f"Rate limited, retrying after {retry_after} seconds")
                        time.sleep(retry_after)
                        continue
                    else:
                        self._record_failure()
                        raise APIError("Rate limit exceeded. Please try again later.", 429)

                # Handle server errors with retry
                if response.status_code >= 500 and attempt < max_retries - 1:
                    # Only retry POSTs when idempotency is guaranteed
                    if method_upper == "POST" and not can_retry_post:
                        raise APIError(f"Server error {response.status_code}", response.status_code)
                    wait_time = 2**attempt  # Exponential backoff
                    logger.warning(f"Server error {response.status_code}, retrying in {wait_time} seconds")
                    time.sleep(wait_time)
                    continue

                # Check for other errors
                if response.status_code >= 400:
                    # Sanitize error message to avoid info disclosure
                    error_msg = parse_api_error(response, "API request failed")
                    # Include correlation ID in error message for debugging
                    error_msg_with_id = f"{error_msg} (request_id={request_id})"
                    error_details = None
                    try:
                        error_details = response.json()
                    except Exception:  # pragma: no cover - defensive
                        error_details = None
                    self._emit_telemetry(
                        method=method_upper,
                        url=url,
                        status_code=response.status_code,
                        duration=duration,
                        attempt=attempt,
                        retries=max_retries,
                        params=params,
                        idempotency_key=idempotency_key,
                        request_id=request_id,
                        error=error_msg,
                    )
                    self._record_failure()
                    raise APIError(error_msg_with_id, response.status_code, details=error_details)

                # Parse successful response (204 = empty body)
                if response.status_code == 204:
                    data = {}
                    self._record_success()
                else:
                    try:
                        data = response.json()
                    except ValueError as exc:
                        # Non-JSON response body
                        if not response.text:
                            data = {}
                        else:
                            error_msg = parse_api_error(response, "Invalid JSON response from API")
                            raise APIError(error_msg, response.status_code) from exc

                # Handle success wrapper format
                payload = data.get("data", data) if isinstance(data, dict) and data.get("success") else data

                self._emit_telemetry(
                    method=method_upper,
                    url=url,
                    status_code=response.status_code,
                    duration=duration,
                    attempt=attempt,
                    retries=max_retries,
                    params=params,
                    idempotency_key=idempotency_key,
                    request_id=request_id,
                )

                self._record_success()
                return payload

            except requests.Timeout as e:
                duration = time.perf_counter() - start_time
                self._emit_telemetry(
                    method=method_upper,
                    url=url,
                    status_code=None,
                    duration=duration,
                    attempt=attempt,
                    retries=max_retries,
                    params=params,
                    idempotency_key=idempotency_key,
                    request_id=request_id,
                    error="timeout",
                )

                if attempt < max_retries - 1:
                    wait_time = 2**attempt
                    logger.warning(f"Request timeout, retrying in {wait_time} seconds")
                    time.sleep(wait_time)
                    continue
                else:
                    self._record_failure()
                    raise APIError("Request timed out. Please check your connection and try again.") from e

            except requests.RequestException as e:
                duration = time.perf_counter() - start_time
                self._emit_telemetry(
                    method=method_upper,
                    url=url,
                    status_code=None,
                    duration=duration,
                    attempt=attempt,
                    retries=max_retries,
                    params=params,
                    idempotency_key=idempotency_key,
                    request_id=request_id,
                    error=str(e),
                )

                if attempt < max_retries - 1 and "connection" in str(e).lower():
                    wait_time = 2**attempt
                    logger.warning(f"Connection error, retrying in {wait_time} seconds")
                    time.sleep(wait_time)
                    continue
                else:
                    self._record_failure()
                    raise APIError(f"Network error: {str(e)}") from e

    def _iterate_paginated(
        self,
        fetcher: Callable[[int, int], List[Dict[str, Any]]],
        page_size: int,
        max_results: Optional[int],
    ) -> Iterator[Dict[str, Any]]:
        offset = 0
        yielded = 0

        while True:
            if max_results is not None:
                remaining = max_results - yielded
                if remaining <= 0:
                    break
                limit = min(page_size, remaining)
            else:
                limit = page_size

            page = fetcher(limit, offset)
            if not page:
                break

            for item in page:
                yield item
                yielded += 1
                if max_results is not None and yielded >= max_results:
                    return

            if len(page) < limit:
                break

            offset += limit

    # Peptide endpoints

    def get_peptides(self, filters: Dict = None, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """
        Search peptides with filters

        Args:
            filters: Search filters (sequence, min_length, max_length, etc.)
            limit: Maximum results to return
            offset: Pagination offset

        Returns:
            List of peptide records
        """
        params = {"limit": limit, "offset": offset}

        if filters:
            params.update(filters)

        result = self._make_request("GET", self._build_data_endpoint("peptides"), params=params)

        # Extract peptides from response
        if isinstance(result, dict):
            return result.get("peptides", result.get("items", []))
        return result if isinstance(result, list) else []

    def get_peptide(self, peptide_id: str) -> Dict[str, Any]:
        """Get a single peptide record.

        The data API exposes list-style GET endpoints (with filters) for core
        entities. Historically the SDK also offered ``/peptides/{id}`` lookups,
        but those paths are not consistently available. To keep this call useful
        across deployments, we translate the request into a filtered list query.

        Args:
            peptide_id: A numeric peptide id (peptide_id) or a sequence string.
        """
        value = str(peptide_id)
        if value.isdigit():
            items = self.get_peptides(filters={"peptide_ids": value}, limit=1, offset=0)
        else:
            items = self.get_peptides(filters={"sequence": value}, limit=1, offset=0)

        if items:
            return items[0]
        raise APIError("Not Found", status_code=404)

    def get_peptide_samples(self, peptide_id: str, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """List samples associated with a peptide id."""
        value = str(peptide_id)
        return self.get_samples(filters={"peptide_ids": value}, limit=limit, offset=offset)

    def get_peptide_proteins(self, peptide_id: str, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """List proteins associated with a peptide id."""
        value = str(peptide_id)
        return self.get_proteins(filters={"peptide_ids": value}, limit=limit, offset=offset)

    def iter_peptides(
        self,
        filters: Dict = None,
        page_size: int = 100,
        max_results: Optional[int] = None,
    ) -> Iterator[Dict[str, Any]]:
        """Yield peptides across pages without manual pagination."""

        def fetch(limit: int, offset: int) -> List[Dict[str, Any]]:
            return self.get_peptides(filters=filters, limit=limit, offset=offset)

        yield from self._iterate_paginated(fetch, page_size, max_results)

    # Protein endpoints

    def get_proteins(self, filters: Dict = None, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """
        Search proteins with filters

        Args:
            filters: Search filters (accession, gene_name, organism, etc.)
            limit: Maximum results to return
            offset: Pagination offset

        Returns:
            List of protein records
        """
        params = {"limit": limit, "offset": offset}

        if filters:
            params.update(filters)

        result = self._make_request("GET", self._build_data_endpoint("proteins"), params=params)

        # Extract proteins from response
        if isinstance(result, dict):
            return result.get("proteins", result.get("items", []))
        return result if isinstance(result, list) else []

    def get_protein(self, protein_id: str) -> Dict[str, Any]:
        """Get a single protein record.

        Args:
            protein_id: A numeric protein id (protein_id) or an accession.
        """
        value = str(protein_id)
        if value.isdigit():
            items = self.get_proteins(filters={"protein_ids": value}, limit=1, offset=0)
        else:
            items = self.get_proteins(filters={"accession": value}, limit=1, offset=0)

        if items:
            return items[0]
        raise APIError("Not Found", status_code=404)

    def get_protein_peptides(self, protein_id: str, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """List peptides associated with a protein id."""
        value = str(protein_id)
        return self.get_peptides(filters={"protein_ids": value}, limit=limit, offset=offset)

    def get_protein_coverage(self, protein_id: str) -> Dict[str, Any]:
        """Get protein coverage from the typed REST endpoint."""
        value = str(protein_id).strip()
        if not value:
            raise APIError("protein_id is required")
        result = self._make_request(
            "GET",
            self._build_scientific_rest_endpoint(f"proteins/{value}/coverage"),
        )
        if isinstance(result, dict):
            return result
        raise APIError("Unexpected protein coverage response format")

    def iter_proteins(
        self,
        filters: Dict = None,
        page_size: int = 100,
        max_results: Optional[int] = None,
    ) -> Iterator[Dict[str, Any]]:
        """Yield proteins across pages without manual pagination."""

        def fetch(limit: int, offset: int) -> List[Dict[str, Any]]:
            return self.get_proteins(filters=filters, limit=limit, offset=offset)

        yield from self._iterate_paginated(fetch, page_size, max_results)

    # Sample endpoints

    def get_samples(self, filters: Dict = None, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """
        Search samples with filters

        Args:
            filters: Search filters (tissue, disease, cell_line, etc.)
            limit: Maximum results to return
            offset: Pagination offset

        Returns:
            List of sample records
        """
        params = {"limit": limit, "offset": offset}

        if filters:
            params.update(filters)

        result = self._make_request("GET", self._build_data_endpoint("samples"), params=params)

        # Extract samples from response
        if isinstance(result, dict):
            return result.get("samples", result.get("items", []))
        return result if isinstance(result, list) else []

    def get_sample(self, sample_id: str) -> Dict[str, Any]:
        """Get a single sample record.

        Args:
            sample_id: A numeric sample id (sample_id).
        """
        value = str(sample_id)
        if not value.isdigit():
            raise APIError(
                "Sample lookup by name is not supported by the public API. "
                "Use get_samples(filters={'search': ...}) or pass a numeric sample id.",
                status_code=400,
            )

        items = self.get_samples(filters={"sample_ids": value}, limit=1, offset=0)

        if items:
            return items[0]
        raise APIError("Not Found", status_code=404)

    def get_sample_peptides(self, sample_id: str, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """List peptides observed in a sample."""
        value = str(sample_id)
        return self.get_peptides(filters={"sample_ids": value}, limit=limit, offset=offset)

    def iter_samples(
        self,
        filters: Dict = None,
        page_size: int = 100,
        max_results: Optional[int] = None,
    ) -> Iterator[Dict[str, Any]]:
        """Yield samples across pages without manual pagination."""

        def fetch(limit: int, offset: int) -> List[Dict[str, Any]]:
            return self.get_samples(filters=filters, limit=limit, offset=offset)

        yield from self._iterate_paginated(fetch, page_size, max_results)

    # HLA endpoints

    def get_hla_alleles(self, locus: Optional[str] = None, resolution: str = "2-digit") -> List[str]:
        """Get HLA alleles through the typed REST endpoint."""
        normalized_locus = normalize_hla_locus(locus)
        try:
            normalized_resolution = normalize_hla_resolution(resolution)
        except ValueError as exc:
            raise APIError(str(exc)) from exc

        params: Dict[str, Any] = {"resolution": normalized_resolution}
        if normalized_locus:
            params["locus"] = normalized_locus

        result = self._make_request(
            "GET",
            self._build_scientific_rest_endpoint("hla-alleles"),
            params=params,
        )
        if not isinstance(result, dict):
            raise APIError("Unexpected HLA allele response format")

        raw_alleles = result.get("alleles", [])
        if not isinstance(raw_alleles, list):
            raise APIError("Unexpected HLA allele response format")

        alleles: List[str] = []
        seen: set[str] = set()
        for raw_allele in raw_alleles:
            allele_name = str(raw_allele or "").strip()
            if not allele_name:
                continue
            resolved = format_hla_allele_resolution(allele_name, normalized_resolution)
            if resolved in seen:
                continue
            seen.add(resolved)
            alleles.append(resolved)
        return alleles

    def get_hla_frequencies(self, population: Optional[str] = None) -> Dict[str, float]:
        """Get HLA allele frequencies from the typed REST endpoint."""
        params: Dict[str, Any] | None = None
        if population:
            params = {"population": str(population).strip()}

        result = self._make_request(
            "GET",
            self._build_scientific_rest_endpoint("hla-frequencies"),
            params=params,
        )
        if not isinstance(result, dict):
            raise APIError("Unexpected HLA frequency response format")

        raw_frequencies = result.get("frequencies", {})
        if not isinstance(raw_frequencies, dict):
            raise APIError("Unexpected HLA frequency response format")
        return {str(allele): float(value or 0.0) for allele, value in raw_frequencies.items()}

    def wait_for_module_run(
        self,
        run_id: str,
        *,
        timeout: float = 600.0,
        poll_interval: float = 5.0,
    ) -> Dict[str, Any]:
        """Poll a module run until it reaches a terminal state."""
        deadline = time.monotonic() + max(float(timeout), 0.0)
        interval = max(float(poll_interval), 0.0)

        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise APIError(f"Timed out waiting for module run {run_id} after {timeout}s")

            status_response = self.get_module_run(run_id)
            status = str(status_response.get("status") or status_response.get("state") or "").lower()

            if status in _COMPLETED_RUN_STATUSES:
                return self.get_module_run_result(run_id)
            if status in _FAILED_RUN_STATUSES:
                error_info = status_response.get("error") or {}
                if isinstance(error_info, dict):
                    message = str(error_info.get("message") or status or "module run failed")
                else:
                    message = str(error_info or status or "module run failed")
                raise APIError(message)

            time.sleep(min(interval, remaining))

    def start_hla_binding_prediction(
        self,
        peptides: List[str],
        alleles: List[str],
        *,
        method: str = "netmhcpan",
        module_id: Optional[str] = None,
        version: Optional[str] = None,
        compute_profile: Optional[str] = None,
        wait: bool = False,
        timeout: float = 600.0,
        poll_interval: float = 5.0,
    ) -> Dict[str, Any]:
        """Start a binding-prediction module run using a configured module id.

        This is a convenience wrapper over the normal async module-run surface.
        It requires either an explicit ``module_id`` or a configured
        ``HLA_BINDING_MODULE_ID`` / ``hla_binding_module_id`` value.
        """
        resolved_module_id = self._resolve_hla_binding_module_id(module_id)
        if not resolved_module_id:
            raise APIError(
                "No HLA binding module is configured. Set HLA_BINDING_MODULE_ID "
                "or configure hla_binding_module_id in the SDK config, or call "
                "start_module_run() directly with your binding module."
            )

        normalized_method = str(method or "netmhcpan").strip().lower()
        if normalized_method not in _HLA_BINDING_METHODS:
            raise APIError(
                f"Unsupported HLA binding method {method!r}. "
                f"Supported methods: {', '.join(sorted(_HLA_BINDING_METHODS))}."
            )

        cleaned_peptides: List[str] = []
        for peptide in peptides or []:
            value = str(peptide or "").strip().upper()
            if not value:
                continue
            if not _HLA_PEPTIDE_RE.match(value):
                raise APIError(f"Invalid peptide sequence {value!r}. Peptides must contain only canonical amino acids.")
            if not 8 <= len(value) <= 15:
                raise APIError(f"Invalid peptide length for {value!r}. Peptides must be 8-15 amino acids long.")
            cleaned_peptides.append(value)
        if not cleaned_peptides:
            raise APIError("At least one peptide is required")

        cleaned_alleles = [str(allele).strip() for allele in (alleles or []) if str(allele).strip()]
        if not cleaned_alleles:
            raise APIError("At least one HLA allele is required")

        run_response = self.start_module_run(
            resolved_module_id,
            parameters={
                "peptides": cleaned_peptides,
                "alleles": cleaned_alleles,
                "method": normalized_method,
            },
            mode="workflow",
            compute_profile=compute_profile,
            version=version,
        )

        if not wait:
            return run_response

        run_id = run_response.get("runId") or run_response.get("id") or run_response.get("run_id")
        if not run_id:
            raise APIError("Binding prediction run started without returning a run identifier")
        return self.wait_for_module_run(str(run_id), timeout=timeout, poll_interval=poll_interval)

    def predict_hla_binding(
        self,
        peptides: List[str],
        alleles: List[str],
        method: str = "netmhcpan",
        batch_size: int = 100,
        module_id: Optional[str] = None,
        version: Optional[str] = None,
        compute_profile: Optional[str] = None,
        timeout: float = 600.0,
        poll_interval: float = 5.0,
    ) -> List[Dict[str, Any]]:
        """Predict HLA-peptide binding by dispatching a configured module run.

        Args:
            peptides: List of peptide sequences to evaluate.
            alleles: List of HLA alleles.
            method: Prediction method (default ``"netmhcpan"``).
            batch_size: Number of peptides per request; values <=0 disable batching.
            module_id: Optional binding module override. Falls back to
                ``HLA_BINDING_MODULE_ID`` or ``hla_binding_module_id`` config.
            version: Optional module version override.
            compute_profile: Optional compute profile override.
            timeout: Maximum seconds to wait for each batch result.
            poll_interval: Seconds between module-run status polls.

        Notes:
            This helper is not backed by a dedicated synchronous REST endpoint.
            It submits one or more workflow-mode module runs and waits for them.
        """
        if not peptides:
            return []

        if batch_size and batch_size > 0:
            batches = [peptides[i : i + batch_size] for i in range(0, len(peptides), batch_size)]
        else:
            batches = [list(peptides)]

        predictions: List[Dict[str, Any]] = []
        for batch in batches:
            result_payload = self.start_hla_binding_prediction(
                batch,
                alleles,
                method=method,
                module_id=module_id,
                version=version,
                compute_profile=compute_profile,
                wait=True,
                timeout=timeout,
                poll_interval=poll_interval,
            )
            predictions.extend(self._extract_hla_predictions(result_payload))

        return predictions

    # ------------------------------------------------------------------
    # Authentication helpers
    # ------------------------------------------------------------------

    def get_current_user(self) -> Dict[str, Any]:
        """Fetch the authenticated user payload."""

        payload = self._make_request("GET", "/v1/auth/me")
        if isinstance(payload, dict):
            return payload
        return {"user": payload}

    # Module endpoints

    def start_module_run(
        self,
        module_id: str,
        *,
        parameters: Optional[Dict[str, Any]] = None,
        mode: str = "interactive",
        compute_profile: Optional[str] = None,
        version: Optional[str] = None,
        navigation_data: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Start a module run via the canonical /v1/module-runs API."""
        payload: Dict[str, Any] = {
            "moduleId": module_id,
            "parameters": parameters or {},
            "mode": mode,
        }
        if compute_profile:
            payload["computeProfile"] = compute_profile
        if version:
            payload["version"] = version
        if navigation_data:
            payload["navigationData"] = navigation_data
        result = self._make_request("POST", "/v1/module-runs", json_data=payload)
        if isinstance(result, dict):
            return self._normalize_module_run_payload(result)
        return result

    def get_module_run(self, run_id: str) -> Dict[str, Any]:
        """Fetch module run status."""
        result = self._make_request("GET", f"/v1/module-runs/{run_id}")
        if isinstance(result, dict):
            return self._normalize_module_run_payload(result)
        return result

    def cancel_module_run(self, run_id: str) -> Dict[str, Any]:
        """Cancel an in-progress module run."""
        result = self._make_request("POST", f"/v1/module-runs/{run_id}/cancel")
        if isinstance(result, dict):
            return self._normalize_module_run_payload(result)
        return result

    def heartbeat_module_run(
        self,
        run_id: str,
        *,
        refresh_urls: Optional[bool] = None,
        progress: Optional[float] = None,
        progress_message: Optional[str] = None,
        estimated_completion: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Record a module run heartbeat and optionally refresh URLs.

        Args:
            run_id: The module run identifier.
            refresh_urls: When ``True``, generate fresh pre-signed URLs.
            progress: Execution progress percentage (0-100).
            progress_message: Human-readable progress description.
            estimated_completion: ISO 8601 timestamp of expected completion.
                When provided, the client sends the new structured
                ``progress = {percent, milestone, estimated_completion}``
                payload so the server can persist the richer snapshot.
        """
        payload: Dict[str, Any] = {}
        if refresh_urls is not None:
            payload["refreshUrls"] = bool(refresh_urls)
        if progress is not None:
            clamped = int(round(max(0.0, min(100.0, float(progress)))))
            if estimated_completion is not None:
                # Structured form — server persists {percent, milestone, eta}.
                structured: Dict[str, Any] = {
                    "percent": clamped,
                    "estimated_completion": str(estimated_completion),
                }
                if progress_message is not None:
                    structured["milestone"] = str(progress_message)
                payload["progress"] = structured
            else:
                # Legacy scalar form — preserves backward compatibility with
                # older API-gateway deployments.
                payload["progress"] = clamped
                if progress_message is not None:
                    payload["progressMessage"] = str(progress_message)
        elif progress_message is not None:
            payload["progressMessage"] = str(progress_message)
        result = self._make_request(
            "POST",
            f"/v1/module-runs/{run_id}/heartbeat",
            json_data=payload or None,
        )
        if isinstance(result, dict):
            return self._normalize_module_run_payload(result)
        return result

    def refresh_module_run_urls(self, run_id: str) -> Dict[str, Any]:
        """Refresh pre-signed URLs for module run artifacts."""
        result = self._make_request("POST", f"/v1/module-runs/{run_id}/urls")
        if isinstance(result, dict):
            return self._normalize_module_run_payload(result)
        return result

    def complete_module_run(
        self,
        run_id: str,
        *,
        status: str = "completed",
        summary: Optional[Dict[str, Any]] = None,
        error: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Mark a UI-only module run as completed or failed."""
        payload: Dict[str, Any] = {"status": status}
        if summary is not None:
            payload["summary"] = summary
        if error:
            payload["error"] = error
        result = self._make_request(
            "POST",
            f"/v1/module-runs/{run_id}/complete",
            json_data=payload,
        )
        if isinstance(result, dict):
            return self._normalize_module_run_payload(result)
        return result

    def revoke_module_run(self, run_id: str, *, reason: Optional[str] = None) -> Dict[str, Any]:
        """Revoke module run token access (admin)."""
        payload = {"reason": reason} if reason else None
        result = self._make_request(
            "POST",
            f"/v1/module-runs/{run_id}/revoke",
            json_data=payload,
        )
        if isinstance(result, dict):
            return self._normalize_module_run_payload(result)
        return result

    def get_module_run_logs(
        self,
        run_id: str,
        *,
        limit: Optional[int] = None,
        next_token: Optional[str] = None,
        order: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Return CloudWatch log events for the module run."""
        params: Dict[str, Any] = {}
        if limit is not None:
            params["limit"] = limit
        if next_token:
            params["nextToken"] = next_token
        if order:
            params["order"] = order
        result = self._make_request("GET", f"/v1/module-runs/{run_id}/logs", params=params or None)
        if isinstance(result, dict):
            return self._normalize_module_run_payload(result)
        return result

    def get_module_run_result(self, run_id: str) -> Dict[str, Any]:
        """Fetch module run output JSON."""
        result = self._make_request("GET", f"/v1/module-runs/{run_id}/result")
        if isinstance(result, dict):
            return self._normalize_module_run_payload(result)
        return result

    def list_modules(self, category: Optional[str] = None, limit: int = 100) -> List[Dict[str, Any]]:
        """List available modules"""
        params = {"limit": limit}
        if category:
            params["category"] = category

        result = self._make_request("GET", "/v1/modules", params=params)
        if isinstance(result, dict):
            return result.get("modules", result.get("items", []))
        return result if isinstance(result, list) else []

    def get_module(self, module_id: str) -> Dict[str, Any]:
        """Fetch a specific module by id."""
        return self._make_request("GET", f"/v1/modules/{module_id}")

    def list_module_runs(
        self,
        *,
        module_id: Optional[str] = None,
        status: Optional[str] = None,
        page: int = 1,
        limit: int = 20,
        order: str = "desc",
    ) -> Dict[str, Any]:
        """List module runs with basic filters."""
        params: Dict[str, Any] = {
            "page": page,
            "limit": limit,
            "order": order,
        }
        if module_id:
            params["moduleId"] = module_id
        if status:
            params["status"] = status
        result = self._make_request("GET", "/v1/module-runs", params=params)
        if isinstance(result, dict) and isinstance(result.get("runs"), list):
            normalized = dict(result)
            normalized["runs"] = [
                self._normalize_module_run_payload(run) if isinstance(run, dict) else run for run in result["runs"]
            ]
            return normalized
        return result

    def iter_modules(
        self,
        category: Optional[str] = None,
        page_size: int = 100,
        max_results: Optional[int] = None,
    ) -> Iterator[Dict[str, Any]]:
        """Yield modules across pages without manual pagination."""
        page = 1
        yielded = 0
        limit = max(int(page_size), 1)

        while True:
            params = {"limit": limit, "page": page}
            if category:
                params["category"] = category

            result = self._make_request("GET", "/v1/modules", params=params)
            if isinstance(result, dict):
                items = result.get("modules", result.get("items", []))
            else:
                items = result if isinstance(result, list) else []

            if not items:
                return

            for item in items:
                yield item
                yielded += 1
                if max_results is not None and yielded >= max_results:
                    return

            if len(items) < limit:
                return

            page += 1

    def upload_module(self, module_path: str, module_name: str, version: str) -> Dict[str, Any]:
        """Deprecated: Use publish_module_source() instead. This method will be removed in a future version.

        Upload module package to the real API endpoint using JSON (base64) payloads,
        with a multipart/form-data fallback for legacy environments.

        Args:
            module_path: Path to module zip file
            module_name: Name of the module
            version: Module version

        Returns:
            Upload response including module_id
        """
        # Validate file
        if not os.path.exists(module_path):
            raise APIError(f"Module package not found: {module_path}")
        file_size = os.path.getsize(module_path)
        if file_size > 50 * 1024 * 1024:  # 50MB limit
            raise APIError(f"Module package too large: {file_size / 1024 / 1024:.1f}MB (max 50MB)")

        # Prepare request
        url = f"{self.base_url}/v1/modules/upload"
        metadata = {
            "name": module_name,
            "version": version,
            "filename": os.path.basename(module_path),
            "size": file_size,
        }

        base_headers = self._headers()
        base_headers.setdefault("Accept", "application/json")
        idem = str(uuid.uuid4())
        base_headers.setdefault("Idempotency-Key", idem)

        for attempt in range(2):
            headers = dict(base_headers)
            headers.pop("Content-Type", None)

            try:
                with open(module_path, "rb") as fh:
                    fh.seek(0)
                    files = {
                        "module": (
                            os.path.basename(module_path),
                            fh,
                            "application/zip",
                        )
                    }
                    form_data = {"metadata": json.dumps(metadata)} if metadata else None

                    # Use configurable connect timeout and longer, configurable read timeout for uploads
                    _timeouts = self.config.get_request_timeouts()
                    _upload_read = self.config.get_upload_read_timeout()
                    resp = self.session.post(
                        url,
                        headers=headers,
                        files=files,
                        data=form_data,
                        timeout=(_timeouts.get("connect", 5.0), _upload_read),
                    )
            except OSError as exc:
                raise APIError(f"Failed to read module package: {exc}") from exc

            if resp.status_code == 401 and attempt == 0:
                if self.auth.refresh_token():
                    base_headers = self._headers()
                    base_headers.setdefault("Accept", "application/json")
                    base_headers.setdefault("Idempotency-Key", idem)
                    continue
                raise APIError(
                    "Authentication expired. Please run 'hla-compass auth login' again",
                    401,
                )

            if resp.status_code >= 400:
                # best-effort parse
                try:
                    err = resp.json()
                except Exception:
                    err = {"message": resp.text}
                raise APIError(
                    parse_api_error(resp, "Upload failed"),
                    resp.status_code,
                    details=err,
                )

            try:
                payload = resp.json()
            except Exception as exc:
                raise APIError("Invalid response from upload endpoint") from exc

            data = payload.get("data", payload)
            module_id = data.get("id") or data.get("module_id")
            if not module_id:
                raise APIError("Upload succeeded but module_id not returned")

            normalized = {"module_id": module_id}
            normalized.update(data)
            return normalized

        raise APIError("Upload failed after token refresh attempt")

    def get_rate_limit_state(self) -> Dict[str, Any]:
        """Return the active rate limit configuration and last wait duration."""
        return dict(self._rate_limit_state)

    def _emit_telemetry(
        self,
        *,
        method: str,
        url: str,
        status_code: Optional[int],
        duration: float,
        attempt: int,
        retries: int,
        params: Optional[Dict[str, Any]],
        idempotency_key: Optional[str],
        request_id: str,
        error: Optional[str] = None,
    ) -> None:
        payload = {
            "method": method,
            "url": url,
            "status_code": status_code,
            "duration_seconds": round(duration, 4),
            "attempt": attempt + 1,
            "max_retries": retries,
            "rate_limit_wait": self._rate_limit_state.get("last_wait_seconds"),
            "params": params or {},
            "idempotency_key": idempotency_key,
            "request_id": request_id,
            "error": error,
        }

        if self._telemetry_callback:
            try:
                self._telemetry_callback(dict(payload))
            except Exception as exc:  # pragma: no cover - user callback
                logger.warning("Telemetry callback raised an exception: %s", exc)

        log_method = logger.info
        if error or (status_code is not None and status_code >= 400):
            log_method = logger.warning

        sanitized = self._sanitize_telemetry_payload(payload)
        log_method("API request telemetry", extra={"api_request": sanitized})

    @staticmethod
    def _sanitize_telemetry_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
        """Return a redacted copy of telemetry suitable for logging."""
        sanitized = dict(payload)

        # Sanitize URL query parameters for sensitive-looking keys
        url = payload.get("url")
        if url and "?" in url:
            from urllib.parse import parse_qs, urlencode, urlparse, urlunparse

            parsed = urlparse(url)
            query = parse_qs(parsed.query)
            sensitive_keys = {
                "token",
                "key",
                "auth",
                "secret",
                "password",
                "apiKey",
                "access_token",
            }
            modified = False
            for k in query:
                if any(s in k.lower() for s in sensitive_keys):
                    query[k] = ["<redacted>"]
                    modified = True
            if modified:
                new_query = urlencode(query, doseq=True)
                sanitized["url"] = urlunparse(parsed._replace(query=new_query))

        params_value = payload.get("params")
        if isinstance(params_value, dict) and params_value:
            sanitized["params"] = {key: "<redacted>" for key in params_value.keys()}
        elif params_value:
            sanitized["params"] = "<redacted>"
        else:
            sanitized["params"] = {}

        if payload.get("idempotency_key"):
            sanitized["idempotency_key"] = "***"

        return sanitized

    def _record_failure(self):
        self._cb_failures += 1
        if self._cb_failures >= self._cb_threshold:
            self._cb_opened_at = time.time()

    def _record_success(self):
        self._cb_failures = 0
        self._cb_opened_at = None

    def register_module(self, module_id: str, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """
        Publish an uploaded module version using the real API endpoint.

        Args:
            module_id: Module ID from upload
            metadata: Module metadata (expects at least 'version')

        Returns:
            Publish response from the API
        """
        json_data = {
            "version": metadata.get("version", "1.0.0"),
            "notes": metadata.get("description", "Module published via SDK"),
        }
        return self._make_request("PUT", f"/v1/modules/{module_id}/publish", json_data=json_data)

    def suspend_module_version(self, module_id: str, version: str) -> Dict[str, Any]:
        """Suspend a published module version."""
        return self._make_request("POST", f"/v1/modules/{module_id}/versions/{version}/suspend")

    def delete_module(self, module_id: str, *, reason: Optional[str] = None) -> Dict[str, Any]:
        """Delete an entire module."""
        payload = {"reason": reason} if reason else None
        return self._make_request("DELETE", f"/v1/modules/{module_id}", json_data=payload)

    def publish_module_source(
        self,
        *,
        manifest: Dict[str, Any],
        source_zip: bytes,
        scope: str = "org",
        org_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Upload module source to the platform for server-side build.

        The platform builds the container image from source, scans it,
        and registers the module.
        """
        import base64

        payload: Dict[str, Any] = {
            "manifest": manifest,
            "sourceZipBase64": base64.b64encode(source_zip).decode("ascii"),
            "scope": scope,
        }
        if org_id:
            payload["orgId"] = org_id

        return self._make_request(
            "POST",
            "/v1/modules/publish",
            json_data=payload,
            idempotency_key=str(uuid.uuid4()),
        )

    def register_container_module(
        self, payload: Dict[str, Any], *, idempotency_key: Optional[str] = None
    ) -> Dict[str, Any]:
        """Deprecated: Use publish_module_source() instead. This method will be removed in a future version."""

        stable_key = idempotency_key or str(uuid.uuid4())
        return self._make_request(
            "POST",
            "/v1/modules/publish",
            json_data=payload,
            idempotency_key=stable_key,
        )

    def get_publish_config(self) -> Dict[str, Any]:
        """Retrieve registry/UI defaults for publishing modules."""

        return self._make_request("GET", "/v1/modules/publish/config")

    def get_module_publish_status(self, publish_id: str) -> Dict[str, Any]:
        """Retrieve the status of a module publish (intake) job."""

        return self._make_request("GET", f"/v1/modules/publish/{publish_id}")

    # Pipeline endpoints

    def import_nfcore_pipeline(
        self,
        pipeline: str,
        version: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        launch_config: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Import an official nf-core pipeline as an immutable snapshot.

        Args:
            pipeline: ``"nf-core/<repo>"`` (e.g. ``"nf-core/rnaseq"``).
            version: Git tag or ref (e.g. ``"3.14.0"``). Resolved to a commit
                SHA server-side and frozen.
            name: Optional display name override.
            description: Optional description override.
            launch_config: Optional launch config override (defaults to
                ``{"mode": "guided_form", "dataContextBindings": {"inputUriParam": "input"}}``).
        """
        payload: Dict[str, Any] = {
            "source": "nf-core",
            "pipeline": pipeline,
            "version": version,
        }
        if name:
            payload["name"] = name
        if description:
            payload["description"] = description
        if launch_config is not None:
            payload["launchConfig"] = launch_config
        return self._make_request("POST", "/v1/pipelines/import", json_data=payload)

    def import_github_pipeline(
        self,
        repository: str,
        ref: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        github_token: Optional[str] = None,
        launch_config: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Import a pipeline from an arbitrary GitHub repository."""
        payload: Dict[str, Any] = {
            "repository": repository,
            "ref": ref,
        }
        if name:
            payload["name"] = name
        if description:
            payload["description"] = description
        if github_token:
            payload["githubToken"] = github_token
        if launch_config is not None:
            payload["launchConfig"] = launch_config
        return self._make_request("POST", "/v1/pipelines/import-github", json_data=payload)

    def get_pipeline_upload_url(self, filename: str) -> Dict[str, Any]:
        """Request a presigned S3 URL for uploading a pipeline ZIP.

        Returns a dict with ``uploadUrl``, ``s3Uri``, and ``expiresIn``. PUT
        the ZIP to ``uploadUrl`` with ``Content-Type: application/zip`` before
        calling :meth:`register_pipeline`.
        """
        return self._make_request("POST", "/v1/pipelines/upload-url", json_data={"filename": filename})

    def create_catalog_import_upload(
        self,
        catalog_id: str,
        *,
        filename: str,
        content_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Request a presigned S3 URL for uploading data to a platform catalog.

        Pairs with the ``catalog-import`` SDK template (Initiative 9.A.1) and
        the future Step Functions orchestrator (9.A.3). The caller PUTs their
        CSV/Parquet/JSONL to ``uploadUrl``; the file lands at ``s3Uri``;
        ``importId`` identifies this single upload for downstream tracking.

        Args:
            catalog_id: UUID of the target catalog. Caller's organization
                must hold an active provider grant for it.
            filename: Used only to derive the file extension. The extension
                must be one of ``.csv``, ``.tsv``, ``.parquet``, ``.jsonl``,
                ``.json``, or ``.gz``. The on-disk name in S3 is normalised
                to ``data.{ext}`` regardless of the input filename.
            content_type: Optional MIME type. Defaults to
                ``application/octet-stream`` server-side.

        Returns:
            ``{"uploadUrl": str, "s3Uri": str, "importId": str, "expiresIn": int}``.

        Raises:
            APIError: 404 if the catalog isn't visible to your org, 400 if
                the filename has an unsupported extension.
        """
        body: Dict[str, Any] = {"filename": filename}
        if content_type is not None:
            body["contentType"] = content_type
        return self._make_request("POST", f"/v1/catalogs/{catalog_id}/upload-url", json_data=body)

    def upload_pipeline_zip(self, zip_path: str, *, filename: Optional[str] = None) -> Dict[str, Any]:
        """Upload a pipeline ZIP via presigned URL and return the stored ``s3Uri``.

        Convenience wrapper over :meth:`get_pipeline_upload_url` + PUT.
        """
        import os as _os

        if not _os.path.exists(zip_path):
            raise APIError(f"Pipeline ZIP not found: {zip_path}")
        chosen = filename or _os.path.basename(zip_path)
        presigned = self.get_pipeline_upload_url(chosen)
        upload_url = presigned.get("uploadUrl")
        if not upload_url:
            raise APIError("Server did not return an uploadUrl", details=presigned)
        with open(zip_path, "rb") as fh:
            put = requests.put(upload_url, data=fh, headers={"Content-Type": "application/zip"}, timeout=300)
        if not put.ok:
            raise APIError(f"Upload failed: HTTP {put.status_code}", status_code=put.status_code)
        return {"s3Uri": presigned.get("s3Uri"), "expiresIn": presigned.get("expiresIn")}

    def upload_run_input(
        self,
        local_path: str,
        *,
        filename: Optional[str] = None,
        content_type: Optional[str] = None,
    ) -> str:
        """Upload a small run-input file (samplesheet, params, custom config) and return its S3 URI.

        Used by :meth:`start_pipeline_run` when callers pass local paths
        instead of S3 URIs. Files land at
        ``s3://<pipelines-bucket>/pipelines/<org>/run-inputs/<random>/<filename>``
        which is on the per-org bucket allowlist.

        Pipeline ZIPs go through :meth:`upload_pipeline_zip` instead.
        """
        import mimetypes
        import os as _os

        if not _os.path.exists(local_path):
            raise APIError(f"File not found: {local_path}")
        chosen = filename or _os.path.basename(local_path)

        # Best-effort content-type detection for common run-input extensions.
        # Falls back to text/plain so the presigned URL signs deterministically.
        if not content_type:
            guessed, _ = mimetypes.guess_type(chosen)
            if chosen.endswith((".yaml", ".yml")):
                content_type = "application/x-yaml"
            elif chosen.endswith(".json"):
                content_type = "application/json"
            elif chosen.endswith((".csv", ".tsv", ".txt")):
                content_type = "text/plain"
            elif chosen.endswith((".config", ".groovy", ".nf")):
                content_type = "text/plain"
            elif chosen.endswith((".fasta", ".fa")):
                content_type = "text/plain"
            else:
                content_type = guessed or "text/plain"

        presigned = self._make_request(
            "POST",
            "/v1/pipelines/upload-url",
            json_data={"filename": chosen, "contentType": content_type},
        )
        upload_url = presigned.get("uploadUrl")
        s3_uri = presigned.get("s3Uri")
        if not upload_url or not s3_uri:
            raise APIError("Server did not return uploadUrl + s3Uri", details=presigned)

        with open(local_path, "rb") as fh:
            put = requests.put(upload_url, data=fh, headers={"Content-Type": content_type}, timeout=120)
        if not put.ok:
            raise APIError(
                f"Upload failed: HTTP {put.status_code}",
                status_code=put.status_code,
                details={"body": put.text[:500]},
            )
        return s3_uri

    def register_pipeline(
        self,
        *,
        name: str,
        s3_uri: str,
        engine: str = "NEXTFLOW",
        version: Optional[str] = None,
        description: Optional[str] = None,
        parameter_template: Optional[Dict[str, Any]] = None,
        launch_config: Optional[Dict[str, Any]] = None,
        is_public: bool = False,
    ) -> Dict[str, Any]:
        """Register a previously-uploaded pipeline ZIP as a platform pipeline."""
        payload: Dict[str, Any] = {
            "name": name,
            "engine": engine,
            "definitionS3Uri": s3_uri,
            "isPublic": is_public,
        }
        if version:
            payload["version"] = version
        if description:
            payload["description"] = description
        if parameter_template is not None:
            payload["parameterTemplate"] = parameter_template
        if launch_config is not None:
            payload["launchConfig"] = launch_config
        return self._make_request("POST", "/v1/pipelines", json_data=payload)

    def list_pipelines(
        self,
        *,
        engine: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """List pipelines visible to the caller's org."""
        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if engine:
            params["engine"] = engine
        if status:
            params["status"] = status
        result = self._make_request("GET", "/v1/pipelines", params=params)
        if isinstance(result, dict):
            return result.get("pipelines") or result.get("items") or []
        return result if isinstance(result, list) else []

    def get_pipeline(self, pipeline_id: str) -> Dict[str, Any]:
        """Fetch a pipeline by id."""
        return self._make_request("GET", f"/v1/pipelines/{pipeline_id}")

    def delete_pipeline(self, pipeline_id: str) -> Dict[str, Any]:
        """Delete a pipeline."""
        return self._make_request("DELETE", f"/v1/pipelines/{pipeline_id}")

    def add_params_preset(
        self,
        pipeline_id: str,
        name: str,
        file_path: str,
        *,
        description: Optional[str] = None,
        is_default: bool = False,
    ) -> Dict[str, Any]:
        """Register a developer-curated params-file preset on a pipeline.

        The preset YAML/JSON is uploaded to the pipeline's versioned S3
        prefix and registered in ``launchConfig.paramsFilePresets``. Run
        wizard users will see this preset in the picker; if
        ``is_default=True``, it auto-selects on page load.

        Args:
            pipeline_id: Pipeline UUID to attach the preset to.
            name: Human-readable preset name (e.g. "Human RNA-seq").
            file_path: Local path to the .yaml / .yml / .json file.
            description: Short blurb shown next to the preset in the
                wizard. Optional.
            is_default: Mark this preset as auto-selected. Only one
                preset per pipeline can be the default — registering a
                new default automatically clears the flag from any
                existing entry.

        Returns:
            The server response dict with the registered preset entry
            and the updated ``launchConfig``.

        Raises:
            APIError: file missing, unsupported extension, or server
                rejected the registration.
        """
        import base64 as _base64
        import os as _os

        if not _os.path.exists(file_path):
            raise APIError(f"Preset file not found: {file_path}")
        ext = _os.path.splitext(file_path)[1].lower()
        if ext not in (".yaml", ".yml", ".json"):
            raise APIError(f"Preset file must be .yaml / .yml / .json (got {ext or '<no extension>'})")

        with open(file_path, "rb") as fh:
            file_bytes = fh.read()

        body: Dict[str, Any] = {
            "name": name,
            "fileContent": _base64.b64encode(file_bytes).decode("ascii"),
            "filename": _os.path.basename(file_path),
            "isDefault": is_default,
        }
        if description:
            body["description"] = description

        return self._make_request(
            "POST",
            f"/v1/pipelines/{pipeline_id}/params-presets",
            json_data=body,
        )

    def delete_params_preset(self, pipeline_id: str, name: str) -> Dict[str, Any]:
        """Remove a registered params-file preset from a pipeline.

        The launchConfig entry is removed and the S3 object is
        best-effort deleted (only if it lives in the pipelines bucket).

        Returns the server response dict containing ``deleted`` (the
        preset name) and ``uri`` (the S3 URI that was registered).
        """
        from urllib.parse import quote

        return self._make_request(
            "DELETE",
            f"/v1/pipelines/{pipeline_id}/params-presets/{quote(name, safe='')}",
        )

    def start_pipeline_run(
        self,
        pipeline_id: str,
        *,
        parameters: Optional[Dict[str, Any]] = None,
        name: Optional[str] = None,
        data_context: Optional[Dict[str, Any]] = None,
        params_file: Optional[str] = None,
        params_file_uri: Optional[str] = None,
        samplesheet: Optional[str] = None,
        resource_profile: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Start a pipeline run (8.D.1 — accepts local paths or S3 URIs).

        Args:
            pipeline_id: Pipeline UUID.
            parameters: Inline params dict. Mutually exclusive with `params_file*`.
            name: Optional run display name (unique per org).
            data_context: Optional data-context binding.
            params_file: Local path to a YAML/JSON params file. SDK uploads
                it via presigned PUT and submits the resulting S3 URI.
                Mutually exclusive with ``params_file_uri`` and ``parameters``.
            params_file_uri: Pre-existing S3 URI to a params file.
                Mutually exclusive with ``params_file`` and ``parameters``.
            samplesheet: Local path OR S3 URI to a samplesheet CSV. Local paths
                are auto-uploaded; either way the URI is injected into
                ``parameters["input"]`` (nf-core convention). Mutually
                exclusive with a ``params_file*`` that already sets ``input``.
            resource_profile: Resource preset name (e.g. "Small", "Standard",
                "Large", "Alithea-Giga"). Defaults to the org's default preset.

        Returns the run dict from ``POST /v1/pipelines/{id}/runs``.
        """
        import os as _os

        # Auto-upload local files before constructing the request body.
        if params_file:
            if params_file_uri:
                raise APIError("params_file and params_file_uri are mutually exclusive", status_code=400)
            if _os.path.exists(params_file):
                params_file_uri = self.upload_run_input(params_file)
            else:
                raise APIError(f"params_file not found: {params_file}", status_code=400)

        if samplesheet:
            samplesheet_uri = samplesheet if samplesheet.startswith("s3://") else self.upload_run_input(samplesheet)
            if params_file_uri:
                raise APIError(
                    "samplesheet auto-injection conflicts with params_file_uri "
                    "(set params.input inside the params file instead)",
                    status_code=400,
                )
            parameters = dict(parameters or {})
            parameters["input"] = samplesheet_uri

        payload: Dict[str, Any] = {}
        if parameters is not None:
            payload["parameters"] = parameters
        if params_file_uri is not None:
            payload["paramsFileUri"] = params_file_uri
        if name:
            payload["name"] = name
        if data_context:
            payload["dataContext"] = data_context
        if resource_profile:
            payload["resourceProfile"] = resource_profile
        return self._make_request("POST", f"/v1/pipelines/{pipeline_id}/runs", json_data=payload)

    def list_pipeline_runs(
        self,
        *,
        pipeline_id: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """List pipeline runs for the caller's org (optionally filtered)."""
        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if pipeline_id:
            params["pipelineId"] = pipeline_id
        if status:
            params["status"] = status
        result = self._make_request("GET", "/v1/pipeline-runs", params=params)
        if isinstance(result, dict):
            return result.get("runs") or result.get("items") or []
        return result if isinstance(result, list) else []

    def get_pipeline_run(self, run_id: str) -> Dict[str, Any]:
        """Fetch pipeline run status and metadata."""
        return self._make_request("GET", f"/v1/pipeline-runs/{run_id}")

    def get_pipeline_run_tasks(self, run_id: str) -> List[Dict[str, Any]]:
        """Fetch task-level detail for a pipeline run (parsed from Nextflow trace)."""
        result = self._make_request("GET", f"/v1/pipeline-runs/{run_id}/tasks")
        if isinstance(result, dict):
            return result.get("tasks") or result.get("items") or []
        return result if isinstance(result, list) else []

    def get_pipeline_run_logs(
        self,
        run_id: str,
        *,
        limit: Optional[int] = None,
        next_token: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Fetch CloudWatch log events for a pipeline run."""
        params: Dict[str, Any] = {}
        if limit is not None:
            params["limit"] = limit
        if next_token:
            params["nextToken"] = next_token
        return self._make_request("GET", f"/v1/pipeline-runs/{run_id}/logs", params=params or None)

    # Unified data-ingestion endpoints (task 3.4)

    def create_ingest_job(
        self,
        *,
        schema_name: str,
        filename: str,
        expected_rows: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Create a new ingest job.

        Returns a presigned PUT URL the client uploads the CSV to. After the
        upload completes, call :meth:`finalize_ingest_job` to commit the
        rows + emit lineage edges.

        Args:
            schema_name: One of ``"samples"``, ``"peptides"``, ``"proteins"``.
            filename: A safe filename suffix used as the S3 object key.
            expected_rows: Optional caller hint, validated at finalize.
        """
        payload: Dict[str, Any] = {
            "schemaName": schema_name,
            "filename": filename,
        }
        if expected_rows is not None:
            payload["expectedRows"] = int(expected_rows)
        return self._make_request("POST", "/v1/ingest/jobs", json_data=payload)

    def get_ingest_job(self, job_id: str) -> Dict[str, Any]:
        """Poll an ingest job's status + per-row validation summary."""
        return self._make_request("GET", f"/v1/ingest/jobs/{job_id}")

    def finalize_ingest_job(
        self,
        job_id: str,
        *,
        dataset_version_label: str,
        sample_metadata: Optional[List[Dict[str, Any]]] = None,
        s3_uri: Optional[str] = None,
        schema_name: Optional[str] = None,
        expected_rows: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Register staged rows + emit lineage. Closes out the job.

        For callers who already staged via the MCP ``stage_ingest`` tool, only
        ``job_id`` + ``dataset_version_label`` are required. For callers who
        upload via the presigned PUT URL only and want the server to also
        stage on their behalf, pass ``s3_uri`` + ``schema_name``.
        """
        payload: Dict[str, Any] = {"datasetVersionLabel": dataset_version_label}
        if sample_metadata is not None:
            payload["sampleMetadata"] = sample_metadata
        if s3_uri is not None:
            payload["s3Uri"] = s3_uri
        if schema_name is not None:
            payload["schemaName"] = schema_name
        if expected_rows is not None:
            payload["expectedRows"] = int(expected_rows)
        return self._make_request("POST", f"/v1/ingest/jobs/{job_id}/finalize", json_data=payload)

    def upload_and_finalize(
        self,
        csv_path: str,
        *,
        schema_name: str,
        dataset_version_label: str,
        sample_metadata: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """Convenience: presigned-PUT a local CSV then finalize in one call.

        Three round-trips: ``POST /v1/ingest/jobs`` → ``PUT`` to S3 → ``POST
        /v1/ingest/jobs/{id}/finalize``. Returns the finalize response.
        """
        import os as _os

        if not _os.path.exists(csv_path):
            raise APIError(f"CSV not found at {csv_path}")

        filename = _os.path.basename(csv_path)
        created = self.create_ingest_job(schema_name=schema_name, filename=filename)
        upload_url = created.get("uploadUrl")
        s3_uri = created.get("s3Uri")
        if not upload_url or not s3_uri:
            raise APIError("create_ingest_job did not return uploadUrl/s3Uri", details=created)

        with open(csv_path, "rb") as fh:
            put = requests.put(
                upload_url,
                data=fh,
                headers=created.get("uploadHeaders") or {"Content-Type": "text/csv"},
                timeout=300,
            )
        if not put.ok:
            raise APIError(
                f"S3 upload failed: HTTP {put.status_code}",
                status_code=put.status_code,
            )

        return self.finalize_ingest_job(
            created["jobId"],
            dataset_version_label=dataset_version_label,
            sample_metadata=sample_metadata,
            s3_uri=s3_uri,
            schema_name=schema_name,
        )

    def cancel_pipeline_run(self, run_id: str) -> Dict[str, Any]:
        """Cancel an in-progress pipeline run."""
        return self._make_request("POST", f"/v1/pipeline-runs/{run_id}/cancel")

    def set_telemetry_callback(self, callback: Optional[Callable[[Dict[str, Any]], None]]) -> None:
        """Register a callback that receives request telemetry dictionaries."""
        self._telemetry_callback = callback


class ModulesFacade:
    """Convenience facade for module operations."""

    def __init__(self, api_client: "APIClient"):
        self._api = api_client

    def list(self, category: Optional[str] = None, limit: int = 100) -> List[Dict[str, Any]]:
        """List modules available to the current org."""
        return self._api.list_modules(category=category, limit=limit)

    def get(self, module_id: str) -> Dict[str, Any]:
        """Fetch module metadata by id."""
        return self._api.get_module(module_id)

    def run(
        self,
        module_id: str,
        params: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """Start a module run (params maps to APIClient.start_module_run parameters)."""
        if params is not None and "parameters" not in kwargs:
            kwargs["parameters"] = params
        return self._api.start_module_run(module_id, **kwargs)

    def suspend_version(self, module_id: str, version: str) -> Dict[str, Any]:
        """Suspend a specific module version."""
        return self._api.suspend_module_version(module_id, version)

    def delete(self, module_id: str, *, reason: Optional[str] = None) -> Dict[str, Any]:
        """Delete a module."""
        return self._api.delete_module(module_id, reason=reason)


class RunsFacade:
    """Convenience facade for module run operations."""

    def __init__(self, api_client: "APIClient"):
        self._api = api_client

    def list(
        self,
        *,
        module_id: Optional[str] = None,
        status: Optional[str] = None,
        page: int = 1,
        limit: int = 20,
        order: str = "desc",
    ) -> Dict[str, Any]:
        """List module runs with basic filters."""
        return self._api.list_module_runs(
            module_id=module_id,
            status=status,
            page=page,
            limit=limit,
            order=order,
        )

    def get(self, run_id: str) -> Dict[str, Any]:
        """Fetch module run status."""
        return self._api.get_module_run(run_id)

    def logs(
        self,
        run_id: str,
        *,
        limit: Optional[int] = None,
        next_token: Optional[str] = None,
        order: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Fetch CloudWatch log events for the module run."""
        return self._api.get_module_run_logs(
            run_id,
            limit=limit,
            next_token=next_token,
            order=order,
        )

    def results(self, run_id: str) -> Dict[str, Any]:
        """Fetch module run results."""
        return self._api.get_module_run_result(run_id)

    def cancel(self, run_id: str) -> Dict[str, Any]:
        """Cancel an in-progress module run."""
        return self._api.cancel_module_run(run_id)

    def heartbeat(
        self,
        run_id: str,
        *,
        refresh_urls: Optional[bool] = None,
        progress: Optional[float] = None,
        progress_message: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Record a module run heartbeat."""
        return self._api.heartbeat_module_run(
            run_id,
            refresh_urls=refresh_urls,
            progress=progress,
            progress_message=progress_message,
        )

    def refresh_urls(self, run_id: str) -> Dict[str, Any]:
        """Refresh pre-signed URLs for module run artifacts."""
        return self._api.refresh_module_run_urls(run_id)

    def complete(
        self,
        run_id: str,
        *,
        status: str = "completed",
        summary: Optional[Dict[str, Any]] = None,
        error: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Mark a UI-only module run as completed or failed."""
        return self._api.complete_module_run(
            run_id,
            status=status,
            summary=summary,
            error=error,
        )

    def revoke(self, run_id: str, *, reason: Optional[str] = None) -> Dict[str, Any]:
        """Revoke module run token access (admin)."""
        return self._api.revoke_module_run(run_id, reason=reason)


class DatasetVersionsFacade:
    """Convenience facade for dataset versioning and data-lineage operations.

    Provides methods for creating and browsing immutable dataset snapshots,
    archiving versions, and querying the data-lineage DAG (which datasets
    fed into which runs and what artifacts they produced).

    Access via ``client.dataset_versions``::

        client = APIClient()
        versions = client.dataset_versions.list(status="active")
        lineage  = client.dataset_versions.get_run_lineage(run_id)
    """

    def __init__(self, api_client: "APIClient"):
        self._api = api_client

    # ------------------------------------------------------------------
    # Dataset version CRUD
    # ------------------------------------------------------------------

    def create(
        self,
        name: str,
        sources: List[Dict[str, Any]],
        *,
        description: Optional[str] = None,
        label: Optional[str] = None,
        total_row_count: Optional[int] = None,
        content_hash: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create an immutable dataset version snapshot.

        Args:
            name: Human-readable unique name within the organisation.
            sources: List of source descriptors, each containing at least
                ``source_table`` and optionally ``source_schema``,
                ``filter_json``, ``row_count``, etc.
            description: Optional longer description of the snapshot.
            label: Short tag, e.g. ``"v1.0"`` or ``"pre-treatment-cohort"``.
            total_row_count: Aggregate row count across all sources.
            content_hash: SHA-256 fingerprint of the canonical content.

        Returns:
            The newly created dataset version record.
        """
        payload: Dict[str, Any] = {
            "name": name,
            "sources": sources,
        }
        if description is not None:
            payload["description"] = description
        if label is not None:
            payload["label"] = label
        if total_row_count is not None:
            payload["totalRowCount"] = total_row_count
        if content_hash is not None:
            payload["contentHash"] = content_hash
        return self._api._make_request("POST", "/v1/dataset-versions", json_data=payload)

    def list(
        self,
        *,
        status: Optional[str] = None,
        limit: int = 20,
        page: int = 1,
    ) -> Dict[str, Any]:
        """List dataset versions for the current organisation.

        Args:
            status: Optional filter by lifecycle status
                (``"active"``, ``"archived"``, ``"deleted"``).
            limit: Maximum number of records per page.
            page: 1-based page number.

        Returns:
            Paginated response containing ``items`` and pagination metadata.
        """
        params: Dict[str, Any] = {"limit": limit, "page": page}
        if status is not None:
            params["status"] = status
        return self._api._make_request("GET", "/v1/dataset-versions", params=params)

    def get(self, version_id: str) -> Dict[str, Any]:
        """Fetch a single dataset version by id.

        Args:
            version_id: UUID of the dataset version.

        Returns:
            The dataset version record including its sources.
        """
        return self._api._make_request("GET", f"/v1/dataset-versions/{version_id}")

    def archive(self, version_id: str) -> Dict[str, Any]:
        """Archive a dataset version (soft-delete).

        This sets the status to ``"archived"`` so the version no longer
        appears in default listings but is still retrievable by id.

        Args:
            version_id: UUID of the dataset version to archive.

        Returns:
            The updated dataset version record.
        """
        return self._api._make_request(
            "PATCH",
            f"/v1/dataset-versions/{version_id}",
            json_data={"status": "archived"},
        )

    # ------------------------------------------------------------------
    # Lineage queries
    # ------------------------------------------------------------------

    def get_run_lineage(self, run_id: str) -> Dict[str, Any]:
        """Retrieve the full lineage graph for a module run.

        Returns both the input dataset versions that fed into the run
        and the output artifacts it produced.

        Args:
            run_id: UUID of the module run.

        Returns:
            Lineage response containing ``inputs`` and ``outputs`` edge lists.
        """
        return self._api._make_request("GET", f"/v1/lineage/run/{run_id}")

    def get_downstream_runs(
        self,
        dataset_version_id: str,
        *,
        limit: int = 20,
    ) -> Dict[str, Any]:
        """List module runs that consumed a given dataset version.

        Args:
            dataset_version_id: UUID of the dataset version.
            limit: Maximum number of results.

        Returns:
            Paginated list of downstream module run references.
        """
        params: Dict[str, Any] = {"limit": limit}
        return self._api._make_request(
            "GET",
            f"/v1/lineage/dataset/{dataset_version_id}/downstream",
            params=params,
        )

    def get_artifact_lineage(self, artifact_uri: str) -> Dict[str, Any]:
        """Trace the lineage of an S3 artifact back to its producing run
        and the upstream dataset versions.

        Args:
            artifact_uri: Canonical S3 URI of the artifact, e.g.
                ``s3://bucket/org/runs/run-id/outputs/result.parquet``.

        Returns:
            Lineage record including the producing run and upstream inputs.
        """
        return self._api._make_request(
            "GET",
            "/v1/lineage/artifact",
            params={"uri": artifact_uri},
        )


# Size threshold above which a file is split into multiple parts for upload.
_UPLOAD_MULTIPART_THRESHOLD_BYTES = 100 * 1024 * 1024  # 100 MiB
# Default target size per part when splitting. S3 requires >= 5 MiB per part
# except the final one; 50 MiB keeps the part count reasonable up to ~500 GiB.
_UPLOAD_DEFAULT_PART_SIZE_BYTES = 50 * 1024 * 1024  # 50 MiB
# S3 hard maximum number of parts in a single multipart upload.
_UPLOAD_MAX_PARTS = 10_000


class UploadsFacade:
    """Convenience facade for raw-file uploads.

    Two-step multipart upload against the platform:

        result = client.uploads.init(filename="sample.mzML", size_bytes=size, part_count=1)
        # PUT each returned URL, collect the ETag header from each response
        client.uploads.complete(raw_file_id=result["rawFileId"], parts=parts)

    Or use :meth:`upload_file` for a one-shot local-file upload that handles
    part splitting, streaming PUTs, and completion automatically.
    """

    def __init__(self, api_client: "APIClient"):
        self._api = api_client

    def init(
        self,
        *,
        filename: str,
        size_bytes: Optional[int] = None,
        vendor_format: Optional[str] = None,
        part_count: int = 1,
    ) -> Dict[str, Any]:
        """Start a multipart upload. Returns init payload with pre-signed part URLs."""
        payload: Dict[str, Any] = {"filename": filename, "part_count": part_count}
        if size_bytes is not None:
            payload["size_bytes"] = size_bytes
        if vendor_format:
            payload["vendor_format"] = vendor_format
        return self._api._make_request("POST", "/v1/uploads/init", json_data=payload)

    def complete(
        self,
        *,
        raw_file_id: str,
        parts: List[Dict[str, Any]],
        sha256: Optional[str] = None,
        size_bytes: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Finalize a multipart upload. ``parts`` = [{'partNumber': n, 'etag': '"..."'}]."""
        payload: Dict[str, Any] = {"rawFileId": raw_file_id, "parts": parts}
        if sha256:
            payload["sha256"] = sha256
        if size_bytes is not None:
            payload["size_bytes"] = size_bytes
        return self._api._make_request("POST", "/v1/uploads/complete", json_data=payload)

    def upload_file(
        self,
        path: str,
        *,
        vendor_format: Optional[str] = None,
        part_size_bytes: int = _UPLOAD_DEFAULT_PART_SIZE_BYTES,
    ) -> Dict[str, Any]:
        """One-shot helper: read a local file, upload all parts, finalize.

        Returns the response from ``/v1/uploads/complete``.
        """
        import hashlib
        from os import path as _os_path
        from os import stat as _os_stat

        if not _os_path.isfile(path):
            raise APIError(f"File not found: {path}", status_code=400)

        size_bytes = _os_stat(path).st_size
        filename = _os_path.basename(path)

        if size_bytes <= _UPLOAD_MULTIPART_THRESHOLD_BYTES:
            part_count = 1
            effective_part_size = size_bytes or 1
        else:
            if part_size_bytes < 5 * 1024 * 1024:
                raise APIError("part_size_bytes must be >= 5 MiB", status_code=400)
            part_count = (size_bytes + part_size_bytes - 1) // part_size_bytes
            if part_count > _UPLOAD_MAX_PARTS:
                raise APIError(
                    f"File would require {part_count} parts (max {_UPLOAD_MAX_PARTS}); increase part_size_bytes",
                    status_code=400,
                )
            effective_part_size = part_size_bytes

        init_payload = self.init(
            filename=filename,
            size_bytes=size_bytes,
            vendor_format=vendor_format,
            part_count=part_count,
        )

        part_urls = init_payload.get("parts") or []
        if len(part_urls) != part_count:
            raise APIError(
                "Unexpected number of pre-signed URLs returned by /v1/uploads/init",
                status_code=502,
            )

        hasher = hashlib.sha256()
        completed_parts: List[Dict[str, Any]] = []

        with open(path, "rb") as fh:
            for entry in part_urls:
                part_number = int(entry["partNumber"])
                chunk = fh.read(effective_part_size) if part_count > 1 else fh.read()
                if not chunk and part_count == 1:
                    # Zero-byte file — S3 requires at least an empty PUT
                    chunk = b""
                hasher.update(chunk)
                # PUT directly to the pre-signed URL (no auth header; S3 validates sig)
                response = requests.put(entry["url"], data=chunk, timeout=(10.0, 300.0))
                if response.status_code >= 300:
                    raise APIError(
                        f"S3 upload failed for part {part_number}: {response.status_code}",
                        status_code=response.status_code,
                        details={"body": response.text[:500]},
                    )
                etag = response.headers.get("ETag") or ""
                completed_parts.append({"partNumber": part_number, "etag": etag})

        return self.complete(
            raw_file_id=init_payload["rawFileId"],
            parts=completed_parts,
            sha256=hasher.hexdigest(),
            size_bytes=size_bytes,
        )


class DatasetsFacade:
    """Convenience facade for the unified dataset registry.

    Register and finalize Parquet or SQL-table outputs from a module or
    pipeline run so they become discoverable and grantable via
    ``platform.datasets``.

    Typical module flow::

        ds = client.datasets.create_parquet(
            name="Peptide Identifications",
            run_id=module_run_id,
        )
        # Module writes *.parquet files under ds["uploadPrefix"]
        client.datasets.finalize(
            dataset_id=ds["id"],
            run_id=module_run_id,
            row_count=12345,
            artifacts=[
                {"s3_uri": f"{ds['uploadPrefix']}peaks-0001.parquet",
                 "format": "PARQUET", "size_bytes": 1048576},
            ],
        )

    For SQL outputs the module is responsible for creating and writing to
    the target table using its scoped DB connection; ``create_sql_table``
    just records the reference so downstream tooling can discover it.
    """

    def __init__(self, api_client: "APIClient"):
        self._api = api_client

    def create_parquet(
        self,
        *,
        name: str,
        run_id: Optional[str] = None,
        description: Optional[str] = None,
        visibility: str = "private",
        storage_ref: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Register a Parquet-dataset output. Returns ``{id, slug, uploadPrefix, ...}``.

        When ``storage_ref`` is omitted, the platform generates a canonical
        prefix under the caller org's per-org bucket:
        ``s3://<org-bucket>/processed/<slug>/<run_id>/``
        """
        payload: Dict[str, Any] = {
            "name": name,
            "kind": "parquet_dataset",
            "visibility": visibility,
        }
        if description is not None:
            payload["description"] = description
        if run_id is not None:
            payload["run_id"] = run_id
        if storage_ref is not None:
            payload["storage_ref"] = storage_ref
        return self._api._make_request("POST", "/v1/datasets", json_data=payload)

    def create_sql_table(
        self,
        *,
        name: str,
        schema: str,
        table: str,
        run_id: Optional[str] = None,
        description: Optional[str] = None,
        visibility: str = "private",
    ) -> Dict[str, Any]:
        """Register a reference to an Aurora table as an sql_table dataset.

        The caller is responsible for creating / writing the table using its
        own scoped DB connection. This just records the dataset row so other
        orgs can be granted read access.
        """
        payload: Dict[str, Any] = {
            "name": name,
            "kind": "sql_table",
            "storage_ref": f"{schema}.{table}",
            "visibility": visibility,
        }
        if description is not None:
            payload["description"] = description
        if run_id is not None:
            payload["run_id"] = run_id
        return self._api._make_request("POST", "/v1/datasets", json_data=payload)

    def finalize(
        self,
        *,
        dataset_id: str,
        run_id: str,
        row_count: Optional[int] = None,
        content_hash: Optional[str] = None,
        label: Optional[str] = None,
        artifacts: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """Create a dataset_version + lineage edges for a completed run.

        ``artifacts`` is an optional list of ``{s3_uri, format, size_bytes, checksum}``
        dicts describing each output file. If empty or omitted, only a
        dataset-level lineage edge is written.
        """
        payload: Dict[str, Any] = {"run_id": run_id}
        if row_count is not None:
            payload["row_count"] = row_count
        if content_hash is not None:
            payload["content_hash"] = content_hash
        if label is not None:
            payload["label"] = label
        if artifacts:
            payload["artifacts"] = artifacts
        return self._api._make_request(
            "POST",
            f"/v1/datasets/{dataset_id}/finalize",
            json_data=payload,
        )

    # ------------------------------------------------------------------
    # Discovery + reads
    # ------------------------------------------------------------------

    def list(
        self,
        *,
        kind: Optional[str] = None,
        owner_org: Optional[str] = None,
        visibility: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> Dict[str, Any]:
        """List datasets visible to the caller."""
        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if kind is not None:
            params["kind"] = kind
        if owner_org is not None:
            params["owner_org"] = owner_org
        if visibility is not None:
            params["visibility"] = visibility
        return self._api._make_request("GET", "/v1/datasets", params=params)

    def get(self, dataset_id: str) -> Dict[str, Any]:
        """Fetch dataset detail (version + lineage; grants when caller is owner)."""
        return self._api._make_request("GET", f"/v1/datasets/{dataset_id}")

    def read(self, dataset_id: str) -> Dict[str, Any]:
        """Fetch read references — pre-signed GET URLs for Parquet/raw,
        or the schema.table reference for sql_table datasets.
        """
        return self._api._make_request("GET", f"/v1/datasets/{dataset_id}/data")

    # ------------------------------------------------------------------
    # Grants
    # ------------------------------------------------------------------

    def grant(
        self,
        dataset_id: str,
        *,
        grantee_org_id: str,
        justification: str,
        permission: str = "read",
    ) -> Dict[str, Any]:
        """Grant another org read (or read_write) access to this dataset.

        Only the dataset owner can call this. ``justification`` is required
        and captured for audit.
        """
        return self._api._make_request(
            "POST",
            f"/v1/datasets/{dataset_id}/grants",
            json_data={
                "grantee_org_id": grantee_org_id,
                "justification": justification,
                "permission": permission,
            },
        )

    def revoke(self, dataset_id: str, grant_id: str) -> Dict[str, Any]:
        """Revoke an active grant. Only the dataset owner can call this."""
        return self._api._make_request(
            "DELETE",
            f"/v1/datasets/{dataset_id}/grants/{grant_id}",
        )
