"""Shared HLA normalization helpers used by the SDK surface."""

from __future__ import annotations


def normalize_hla_locus(locus: str | None) -> str | None:
    if locus is None:
        return None
    normalized = str(locus).strip().upper()
    if not normalized:
        return None
    if not normalized.startswith("HLA-"):
        normalized = f"HLA-{normalized}"
    return normalized


def normalize_hla_resolution(resolution: str) -> str:
    normalized = str(resolution or "2-digit").strip().lower()
    if normalized not in {"2-digit", "4-digit", "full"}:
        raise ValueError("Unsupported HLA resolution. Use one of: '2-digit', '4-digit', 'full'.")
    return normalized


def format_hla_allele_resolution(allele_name: str, resolution: str) -> str:
    if resolution == "full" or "*" not in allele_name:
        return allele_name

    prefix, suffix = allele_name.split("*", 1)
    segments = [segment for segment in suffix.split(":") if segment]
    if not segments:
        return allele_name
    if resolution == "2-digit":
        return f"{prefix}*{segments[0]}"
    return f"{prefix}*{':'.join(segments[:2])}" if len(segments) >= 2 else f"{prefix}*{segments[0]}"
