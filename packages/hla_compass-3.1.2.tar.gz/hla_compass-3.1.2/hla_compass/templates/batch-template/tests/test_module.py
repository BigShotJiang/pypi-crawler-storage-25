"""Basic tests for the Batch template module."""

from __future__ import annotations

from backend.main import BatchModule, _chunked, _greedy_assemble


def test_module_runs_with_sample_input(sample_input, test_context):
    """Module executes successfully with the bundled sample input.

    The sample uses a `data:` URI so the test runs without S3 — covers
    the assembly + checkpoint path end-to-end.
    """
    module = BatchModule(manifest_path="manifest.json")
    result = module.run(sample_input, test_context)
    assert result["status"] == "success", result
    payload = result["results"]
    # The four sample reads share overlaps that should produce at least
    # one contig of length >= 25.
    assert payload["contigs_count"] >= 1
    assert payload["longest_contig_length"] >= 25


def test_greedy_assembler_merges_overlapping_reads():
    """Smoke test for the toy assembler — overlapping reads should merge."""
    reads = [
        "ATGCGTACGTACGTAGCTAGC",  # ends with TAGCTAGC
        "TAGCTAGCGGGGTACGCATCG",  # starts with TAGCTAGC
    ]
    contigs = _greedy_assemble(reads, min_len=20)
    assert len(contigs) == 1
    assert contigs[0].startswith("ATGCGTACGT")
    assert contigs[0].endswith("CATCG")


def test_chunked_yields_correct_sizes():
    """The batching helper splits inputs into fixed-size chunks."""
    chunks = _chunked(["a", "b", "c", "d", "e"], size=2)
    assert chunks == [["a", "b"], ["c", "d"], ["e"]]


def test_module_has_required_metadata(manifest):
    """Manifest contains required fields and declares Batch compute."""
    assert manifest["name"]
    assert manifest["version"]
    assert manifest["execution"]["entrypoint"]
    assert manifest["computeType"] == "batch"
    assert manifest["resources"]["maxRuntimeSeconds"] >= 900
    # Batch carries explicit CPU + memory + scratch declarations.
    assert manifest["resources"]["cpu"] >= 1
    assert manifest["resources"]["memory"] >= 1024
    assert manifest["resources"]["scratchGB"] >= 1
