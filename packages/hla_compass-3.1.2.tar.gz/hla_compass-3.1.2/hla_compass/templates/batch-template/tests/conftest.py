"""Shared test fixtures for module tests."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

TEMPLATE_ROOT = Path(__file__).parent.parent
if str(TEMPLATE_ROOT) not in sys.path:
    sys.path.insert(0, str(TEMPLATE_ROOT))


@pytest.fixture()
def manifest() -> dict:
    """Load manifest.json from the module root."""
    manifest_path = TEMPLATE_ROOT / "manifest.json"
    return json.loads(manifest_path.read_text())


@pytest.fixture()
def sample_input() -> dict:
    """Load examples/sample_input.json."""
    path = TEMPLATE_ROOT / "examples" / "sample_input.json"
    return json.loads(path.read_text())


@pytest.fixture()
def test_context() -> dict:
    """Minimal runtime context for local testing."""
    return {
        "run_id": "test-run",
        "module_id": "test-module",
        "organization_id": "test-org",
        "user_id": "test-user",
        "environment": "dev",
        "correlation_id": "test-correlation",
        "requested_at": "2025-01-01T00:00:00Z",
        "mode": "test",
        "offline": True,
    }
