"""Batch-shaped module template.

Reference workload: a tiny de-novo assembly demo using a greedy-overlap
algorithm. Pure Python so the template runs end-to-end with no external
binaries — for real assemblies you'd shell out to SPAdes / Trinity
(see SKILL.md for the pattern).

The shape we're demonstrating:
  1. Download a large input from S3 to /scratch
  2. Run a long-running compute step
  3. Checkpoint progress periodically (Spot preemption is real)
  4. Upload the result back to S3
  5. Return a structured summary

If your tool needs:
  - <15 min runtime + no scratch → use `lambda-template` (cheaper, faster cold-start)
  - <60 min runtime + a UI → use `no-ui-template` (Fargate)
  - real Nextflow workflow → use `pipeline-ui-template`

…rather than this template. See SKILL.md for the decision matrix.
"""

from __future__ import annotations

import os
import pickle
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from hla_compass import Module


class Options(BaseModel):
    min_contig_length: int = Field(100, ge=1)
    checkpoint_every_seconds: int = Field(60, ge=10)


class Input(BaseModel):
    reads_uri: str
    options: Options = Field(default_factory=Options)


class _CheckpointState(BaseModel):
    """Pickle-serialised progress state. Anything `execute()` needs to
    resume after a Spot preemption goes here."""

    processed_reads: int = 0
    contigs: List[str] = Field(default_factory=list)


def _resolve_run_id(context: Dict[str, Any]) -> str:
    return context.get("run_id") or context.get("job_id") or context.get("runId") or "local-run"


def _scratch_dir() -> Path:
    """Where the platform mounts ephemeral scratch storage on Batch.

    `/scratch` is the canonical mount; falls back to `/tmp` for local
    `hla-compass test` runs that don't have the EFS mount.
    """
    for candidate in ("/scratch", "/tmp/scratch", "/tmp"):
        path = Path(candidate)
        if path.exists() and os.access(path, os.W_OK):
            return path
    return Path("/tmp")


_MIN_OVERLAP = 4
"""Minimum overlap length for the toy assembler.

4 is intentionally low so the bundled sample input + tests work; a real
assembler (SPAdes, Trinity, MEGAHIT) uses k-mer indices and a much
larger minimum k. This template's value is the long-running shape +
checkpoint pattern — swap the `_greedy_assemble` body for a `subprocess`
call to your real tool of choice.
"""


def _greedy_assemble(reads: List[str], min_len: int) -> List[str]:
    """Toy assembler: merges reads with overlapping ends, returns
    contigs longer than `min_len`. Real-world assembly is much harder
    and uses purpose-built tools — this is a stand-in workload that
    demonstrates the long-running shape without external dependencies.
    """
    contigs = list(reads)
    changed = True
    while changed:
        changed = False
        for i, a in enumerate(contigs):
            for j, b in enumerate(contigs):
                if i == j or not a or not b:
                    continue
                # Find longest suffix-of-a == prefix-of-b
                max_overlap = min(len(a), len(b))
                for k in range(max_overlap, _MIN_OVERLAP - 1, -1):
                    if a[-k:] == b[:k]:
                        contigs[i] = a + b[k:]
                        contigs[j] = ""
                        changed = True
                        break
                if changed:
                    break
            if changed:
                break
    return [c for c in contigs if len(c) >= min_len]


class BatchModule(Module):
    """Long-running de-novo assembly demo.

    The structure here is the canonical Batch shape:
      * Download input from S3 to /scratch (large files don't fit in /tmp)
      * Compute, checkpointing periodically so Spot preemption can resume
      * Upload result + summary

    Real assemblers shell out to SPAdes / Trinity / etc.; the toy
    greedy-overlap algorithm here keeps the template self-contained
    so `hla-compass test` works without external binaries.
    """

    Input = Input

    def execute(self, input_data: Input, context: Dict[str, Any]) -> Dict[str, Any]:
        scratch = _scratch_dir()
        run_id = _resolve_run_id(context)
        checkpoint_path = scratch / f"{run_id}.checkpoint.pkl"

        self.logger.info(
            "starting batch assembly",
            extra={
                "run_id": run_id,
                "reads_uri": input_data.reads_uri,
                "scratch": str(scratch),
                "min_contig_length": input_data.options.min_contig_length,
            },
        )

        # Step 1: load checkpoint if we're resuming a preempted run.
        state = _load_checkpoint(checkpoint_path) or _CheckpointState()

        # Step 2: download input. In production this is `self.data.storage.read_bytes(uri)`
        # written to /scratch; for the template demo we accept inline reads
        # via a comma-separated list embedded in the URI for portability.
        reads = _download_or_decode_reads(self, input_data.reads_uri, scratch / "input.fa")
        self.logger.info("loaded reads", extra={"run_id": run_id, "count": len(reads)})

        # Step 3: long-running compute with checkpointing.
        last_checkpoint = time.time()
        for batch in _chunked(reads, 64):
            new_contigs = _greedy_assemble(batch, input_data.options.min_contig_length)
            state.contigs.extend(new_contigs)
            state.processed_reads += len(batch)

            # Checkpoint every N seconds. Real Batch jobs can run for
            # hours and Spot preemption can hit at any moment — losing
            # all progress would be unacceptable for billable work.
            if time.time() - last_checkpoint > input_data.options.checkpoint_every_seconds:
                _save_checkpoint(checkpoint_path, state)
                last_checkpoint = time.time()
                self.logger.info(
                    "checkpoint saved",
                    extra={"run_id": run_id, "processed_reads": state.processed_reads},
                )

        # Step 4: upload the result. self.storage is always available —
        # per-org S3 R/W is granted to every module unconditionally.
        contigs_path = scratch / "contigs.fa"
        contigs_path.write_text(_format_fasta(state.contigs))
        artifact_url: Optional[str] = None
        if self.storage is not None:
            artifact_url = self.storage.save_text(f"results/{run_id}/contigs.fa", contigs_path.read_text())

        # Clean up checkpoint — the run is complete, no need to keep it.
        if checkpoint_path.exists():
            checkpoint_path.unlink()

        summary = {
            "reads_processed": state.processed_reads,
            "contigs_assembled": len(state.contigs),
            "artifact_url": artifact_url,
        }

        results = {
            "contigs_count": len(state.contigs),
            "longest_contig_length": max((len(c) for c in state.contigs), default=0),
            "shortest_contig_length": min((len(c) for c in state.contigs), default=0),
            "contigs_uri": artifact_url,
            "context": {
                "mode": context.get("mode"),
                "run_id": run_id,
                "scratch_path": str(scratch),
            },
        }

        return self.success(results=results, summary=summary)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _load_checkpoint(path: Path) -> Optional[_CheckpointState]:
    """Restore a previous run's progress, or return None for a fresh run."""
    if not path.exists():
        return None
    try:
        with path.open("rb") as f:
            data = pickle.load(f)  # noqa: S301 — only our own checkpoints land here
        return _CheckpointState.model_validate(data)
    except Exception:  # noqa: BLE001 — corrupt checkpoint = start fresh
        return None


def _save_checkpoint(path: Path, state: _CheckpointState) -> None:
    """Atomic-ish: write to .tmp then rename so a partial write can't
    corrupt the canonical checkpoint."""
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("wb") as f:
        pickle.dump(state.model_dump(), f)
    tmp.replace(path)


def _download_or_decode_reads(module: Module, reads_uri: str, dest: Path) -> List[str]:
    """Resolve an input URI into a list of read sequences.

    Production path: `self.data.storage.read_text(reads_uri)` for an
    s3:// URI; parse FASTA. Template demo path: accept a `data:` URI
    or a comma-separated literal so the bundled sample input works
    without S3 access.
    """
    if reads_uri.startswith("data:"):
        # `data:,SEQ1,SEQ2,SEQ3` — comma-separated reads embedded in URI.
        payload = reads_uri.split(",", 1)[1] if "," in reads_uri else ""
        return [r.strip() for r in payload.split(",") if r.strip()]

    if reads_uri.startswith("s3://") and module.data is not None:
        text = module.data.storage.read_text(reads_uri)
        # Naive FASTA parser: skip headers, accumulate sequence lines.
        reads: List[str] = []
        current: List[str] = []
        for line in text.splitlines():
            if line.startswith(">"):
                if current:
                    reads.append("".join(current))
                    current = []
            else:
                current.append(line.strip())
        if current:
            reads.append("".join(current))
        dest.write_text(text)
        return reads

    # Last-resort literal — useful for `hla-compass test` against the
    # bundled sample. Treat the URI as a single read.
    return [reads_uri]


def _chunked(items: List[str], size: int) -> List[List[str]]:
    return [items[i : i + size] for i in range(0, len(items), size)]


def _format_fasta(contigs: List[str]) -> str:
    return "\n".join(f">contig_{i}\n{seq}" for i, seq in enumerate(contigs)) + "\n"
