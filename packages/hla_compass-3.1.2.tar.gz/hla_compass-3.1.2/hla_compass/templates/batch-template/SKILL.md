# SKILL.md — HLA-Compass Batch Module

This is the canonical reference for building a Batch-shaped module on
HLA-Compass. **Read it end-to-end before you start coding.** Batch's
strengths (long runtimes, large memory, scratch storage) come with
operational requirements that don't apply to Lambda or Fargate
modules — most importantly, **Spot preemption is real and you must
plan for it**.

If you've already read `no-ui-template/SKILL.md`, this document covers
the differences. The execute-contract, helpers, and data-access APIs
are identical to the Fargate template — Batch adds operational
patterns (scratch, checkpointing, resource declarations).

---

## 1. The Batch execution model in one paragraph

AWS Batch schedules your container onto an EC2 instance from a
managed compute environment. The container survives for the full
duration of the job — there's no freeze/thaw cycle like Lambda. But
the underlying instance is typically Spot, so the job can be
**preempted** with ~2 minutes notice. Your job needs to checkpoint
progress to `/scratch` periodically so a fresh container can resume
from the last checkpoint instead of restarting from zero.

> Given an input, return a result in ≤24 hours. Survive Spot preemption.
> Don't depend on anything outside the input + the AWS resources your
> IAM role grants.

---

## 2. Hard constraints

| Constraint | Limit | Notes |
|---|---|---|
| **Maximum runtime** | 24 hours (default; configurable up to 14 days) | Module manifest declares `maxRuntimeSeconds` |
| **Memory** | up to ~64 GB on standard Spot instances | Declared in manifest as `resources.memory` (MiB) |
| **vCPUs** | up to 16 typical | Declared as `resources.cpu` |
| **Scratch (`/scratch`)** | configurable per job (default 50 GB) | Declared as `resources.scratchGB` |
| **Container image size** | up to 30 GB | No package-size limit like Lambda |
| **Concurrent jobs** | 1000 per Batch job queue | Account-level quota |
| **Spot preemption** | 2-min warning typical | Plan for it (see §5) |

The template ships defaults of:
- `maxRuntimeSeconds: 14400` (4 hours — typical assembly job)
- `memory: 8192` (8 GB)
- `cpu: 4` vCPUs
- `scratchGB: 50` (enough for typical inputs; bump for large datasets)

Tune these per-workload. The platform's resource profile picker shows
your declared requirements so users know the baseline cost.

---

## 3. The Module contract

Identical to Lambda + Fargate — extend `hla_compass.Module` and
implement `execute()`. The base class handles input validation, error
wrapping, logging, and return-shape contracts.

```python
from hla_compass import Module
from pydantic import BaseModel

class Input(BaseModel):
    reads_uri: str

class MyModule(Module):
    Input = Input

    def execute(self, input_data: Input, context: dict) -> dict:
        # ... long-running compute ...
        return self.success(results=..., summary=...)
```

See `no-ui-template/SKILL.md` for the full Module API surface — it's
the same. Below are the patterns specific to Batch.

---

## 4. Scratch storage (`/scratch`)

The platform mounts ephemeral disk at `/scratch`. Use it for:
- Downloaded inputs (FASTA / FASTQ files, reference genomes, etc.)
- Intermediate compute artifacts
- Checkpoint files
- Working directories for shelled-out binaries (SPAdes, Trinity, etc.)

Don't rely on `/scratch` content surviving across runs — when the
container exits, it's gone. Anything you want to keep, upload to S3
via `self.storage`.

The reference helper:
```python
def _scratch_dir() -> Path:
    """Where the platform mounts ephemeral scratch storage on Batch.

    `/scratch` is the canonical mount; falls back to `/tmp/scratch` /
    `/tmp` for local `hla-compass test` runs that don't have the EFS
    mount.
    """
    for candidate in ("/scratch", "/tmp/scratch", "/tmp"):
        path = Path(candidate)
        if path.exists() and os.access(path, os.W_OK):
            return path
    return Path("/tmp")
```

Use this at the top of your `execute()` rather than hard-coding
`/scratch` — it makes local test runs work without an EFS mount.

---

## 5. Spot preemption + checkpointing

Spot preemption can hit at any moment. The instance gets a 2-minute
warning, but your code shouldn't depend on receiving it (handlers
are unreliable at the OS level). The reliable approach: **checkpoint
periodically and resume from the last checkpoint**.

The template ships a complete checkpoint pattern:

```python
def _save_checkpoint(path: Path, state: _CheckpointState) -> None:
    """Atomic-ish: write to .tmp then rename so a partial write can't
    corrupt the canonical checkpoint."""
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("wb") as f:
        pickle.dump(state.model_dump(), f)
    tmp.replace(path)


def _load_checkpoint(path: Path) -> _CheckpointState | None:
    """Restore previous progress, or None for a fresh run."""
    if not path.exists():
        return None
    try:
        with path.open("rb") as f:
            return _CheckpointState.model_validate(pickle.load(f))
    except Exception:  # corrupt checkpoint = start fresh
        return None
```

### Checkpoint frequency

A reasonable rule: checkpoint roughly every minute, OR every batch of
work that took >30 seconds, whichever is more frequent. The cost of
re-doing a minute's work is small; the cost of re-doing 30 minutes is
not.

### What to checkpoint

Everything `execute()` needs to resume from where it left off:
- Index/cursor into the input (which records have been processed)
- Accumulated output (contigs assembled, peptides scored, etc.)
- Any external state that's expensive to recompute (downloaded
  reference genomes, pre-built indices, etc.)

### Checkpoint format

Pickle is fine for trusted in-process state. Use Pydantic's
`model_dump()` / `model_validate()` to round-trip via dicts — this
gives you schema-checked checkpoints that survive minor model
changes.

```python
class _CheckpointState(BaseModel):
    processed_reads: int = 0
    contigs: list[str] = Field(default_factory=list)
```

---

## 6. Shelling out to native binaries

Real Batch workloads usually call out to a purpose-built tool
(SPAdes, Trinity, BWA, GATK). Pattern:

```python
import subprocess
from pathlib import Path

def execute(self, input_data: Input, context: dict) -> dict:
    scratch = _scratch_dir()
    input_path = scratch / "input.fa"
    output_dir = scratch / "spades_output"
    output_dir.mkdir(exist_ok=True)

    # Download input from S3.
    self.data.storage.download(input_data.reads_uri, input_path)

    # Run SPAdes. Bake the binary into the container image at build
    # time — see §7 below.
    result = subprocess.run(
        ["spades.py", "-s", str(input_path), "-o", str(output_dir),
         "-t", str(input_data.options.threads)],
        capture_output=True, text=True, check=False,
    )
    if result.returncode != 0:
        self.error(
            "SPAdes failed",
            details={"stderr": result.stderr[-2000:], "returncode": result.returncode},
        )

    # Upload contigs.
    contigs_url = self.storage.save_text(
        f"results/{run_id}/contigs.fa",
        (output_dir / "contigs.fasta").read_text(),
    )

    return self.success(results={"contigs_uri": contigs_url}, summary={...})
```

### Resilience

- Pipe `stdout`/`stderr` to log files in `/scratch` so a long-running
  job's progress is visible via the run-logs API.
- Set `subprocess.run(..., check=False)` and inspect `returncode`
  yourself — that gives you a chance to surface a clean module error
  instead of a Python traceback.
- If the binary supports resume (most assemblers do), pass
  `--continue` or equivalent so a Spot-preempted job can pick up
  where it left off.

---

## 7. Including native binaries in the container

The `module-runtime` base image is Python 3.13 slim — it has Python
but not SPAdes. Add what you need to your `requirements.txt`'s sister
file `Dockerfile.deps` (the platform's intake-runner picks it up):

```text
# Dockerfile.deps — extra apt packages and binaries
RUN apt-get update && apt-get install -y \
    spades \
    bwa \
    samtools \
    && rm -rf /var/lib/apt/lists/*
```

For binaries not in apt:
```text
RUN curl -L https://github.com/example/tool/releases/download/v1.0/tool-linux.tar.gz \
        | tar -xz -C /usr/local/bin
```

Keep the image lean — every megabyte slows publish + cold-start.

---

## 8. Local development

```bash
# Scaffold a new module from this template
hla-compass init my-assembler --template batch

cd my-assembler

# Validate before running
hla-compass validate

# Run locally with the bundled sample input
hla-compass dev

# Run a containerized smoke test
hla-compass test --input examples/sample_input.json

# Unit tests
pytest tests/
```

The template's bundled sample uses a `data:` URI so the test runs
without S3 access — useful for the inner dev loop. Once you switch
to real S3 inputs, run `hla-compass test` against a small dataset
to verify the full path.

---

## 9. Publish flow

```bash
hla-compass publish --env dev --scope org --wait
```

What happens:
1. SDK ZIPs the module source.
2. SDK requests a presigned upload URL.
3. SDK PUTs the ZIP to S3.
4. Platform's intake-runner builds a container image:
   - Base image: `module-runtime` (Python 3.13 slim)
   - Installs `Dockerfile.deps` if present (apt packages, binaries)
   - Installs `backend/requirements.txt`
   - Copies your source
   - Trivy scan + Cosign signing
5. Platform pushes the image to ECR and registers the module's
   compute_type as `batch` in `platform.modules`.
6. AWS Batch job definition is created with your declared
   `memory`, `cpu`, `scratchGB`.

`--wait` blocks until the build finishes. Without it,
`hla-compass get-publish-status <module-id>` polls separately.

---

## 10. Common Batch anti-patterns

### ❌ Storing output in `/scratch` only
```python
# BAD — when the container exits, the file is gone
output_path = scratch / "results.fa"
results.write_to(output_path)
return self.success(results={"file": str(output_path)})
```

```python
# GOOD — upload to S3 via self.storage
output_path = scratch / "results.fa"
results.write_to(output_path)
url = self.storage.save_text(f"results/{run_id}/output.fa", output_path.read_text())
return self.success(results={"file_url": url})
```

### ❌ Running for hours without checkpointing
```python
# BAD — Spot preemption costs the entire run
def execute(self, input_data, context):
    contigs = []
    for read in big_dataset:
        contigs.append(self._process(read))  # 4 hours later, instance preempted
    return self.success(...)
```

```python
# GOOD — checkpoint every minute
def execute(self, input_data, context):
    state = _load_checkpoint(checkpoint_path) or _CheckpointState()
    last_checkpoint = time.time()
    for read in big_dataset[state.processed:]:
        state.contigs.append(self._process(read))
        state.processed += 1
        if time.time() - last_checkpoint > 60:
            _save_checkpoint(checkpoint_path, state)
            last_checkpoint = time.time()
    return self.success(...)
```

### ❌ Hard-coding `/scratch` without fallback
```python
# BAD — local `hla-compass test` doesn't mount EFS
output_path = Path("/scratch") / "output.fa"  # FileNotFoundError locally
```

```python
# GOOD — use the helper that falls back to /tmp
scratch = _scratch_dir()
output_path = scratch / "output.fa"
```

### ❌ Over-provisioning resources
```json
// BAD — request 64 vCPU + 256 GB for a job that only needs 4 vCPU + 8 GB
"resources": {
  "cpu": 64,
  "memory": 262144,
  "scratchGB": 500
}
```

The platform charges based on requested resources, not used. Profile
your workload first, then declare honestly.

### ❌ Not handling failed external commands
```python
# BAD — SPAdes failures vanish into the void
subprocess.run(["spades.py", ...])
return self.success(...)  # the user sees "success" with no contigs
```

```python
# GOOD — check the returncode and surface a structured error
result = subprocess.run(["spades.py", ...], capture_output=True, text=True, check=False)
if result.returncode != 0:
    self.error(
        f"SPAdes failed (exit {result.returncode})",
        details={"stderr": result.stderr[-2000:]},
    )
return self.success(...)
```

---

## 11. Migration paths

### Batch → Fargate (when your tool gets faster)
1. Change `manifest.json`: `"computeType": "fargate"`, drop the
   `scratchGB` declaration (Fargate has 20 GB default).
2. Remove `_scratch_dir()` helper if you only need ephemeral disk;
   Fargate's `/tmp` is fine for <20 GB workloads.
3. Re-publish.

### Batch → Lambda (when your tool gets very fast)
1. Switch templates: `hla-compass init <new> --template lambda`.
   Port your `execute()` body. Drop checkpointing — Lambda doesn't
   support resume after timeout.
2. Verify your workload fits in 15 min + 10 GB memory + 250 MB
   package + /tmp 512 MB.

### Batch → Pipeline (when your tool becomes a multi-step workflow)
1. Switch templates: `hla-compass init <new> --template pipeline-ui`.
   Port your compute into a Nextflow `main.nf`.
2. The platform dispatches via the Nextflow runner instead of direct
   Batch — same compute environment, but workflow orchestration is
   handled by Nextflow rather than your `execute()`.

---

## 12. When to NOT use this template

This template is wrong for:

- **Anything that completes in <15 minutes**. Lambda is cheaper and
  has faster cold-start. Use `lambda-template`.
- **Tools that need a UI**. Batch jobs run async in the background;
  there's no React frontend. Use `no-ui-template` (Fargate, sync) or
  `ui-template` if your tool produces an interactive result.
- **Multi-step Nextflow pipelines**. Use `pipeline-ui-template`
  rather than reimplementing workflow orchestration in `execute()`.
- **Real-time interactive tools**. Batch's startup latency (queue
  time + container pull) can be minutes. Not viable for <30s SLAs.

---

## 13. Reference: complete Batch run lifecycle

```
Caller (UI / API / MCP)
   ↓ POST /v1/module-runs
Platform module-runs handler
   ↓ acquire ACT reservation
   ↓ submit AWS Batch job
AWS Batch
   ↓ schedule container on Spot instance
   ↓ pull image from ECR
   ↓ start container
Module.__init__ (loads manifest)
   ↓ Module.run(input, context)
   ↓   → validate input via Pydantic
   ↓   → execute(input, context)  ← YOUR CODE
   ↓     → download from S3 to /scratch
   ↓     → loop: process + checkpoint to /scratch
   ↓     → upload result to S3
   ↓   → wrap in success / error envelope
Platform module-runs result handler
   ↓ settle ACT credits
   ↓ persist run results
Caller polls GET /v1/module-runs/{id}/results
```

Your `execute()` runs in step 3.b. Spot preemption can hit at any
point inside it — your checkpointing is the only thing that makes the
run resumable.

---

## 14. Common questions

**Q: How do I add a binary to the container?**
Create `Dockerfile.deps` next to `backend/requirements.txt` with
`apt-get install` lines. The platform's intake-runner picks it up at
build time.

**Q: How do I declare GPU resources?**
Add `"gpu": 1` to `resources` in the manifest. The platform routes
GPU-tagged jobs to a GPU-enabled compute environment.

**Q: My job fails with `No space left on device`.**
Either bump `resources.scratchGB` in the manifest, or stream large
files (process in chunks rather than loading everything to disk).

**Q: My job hits the 24-hour timeout.**
Two options:
- Bump `maxRuntimeSeconds` (up to 14 days for the AWS Batch limit).
- Split the work into multiple module runs orchestrated via
  `pipeline-ui-template`.

**Q: How do I read secrets?**
Don't bake them into the manifest. Use environment variables injected at
deploy time (`environment_variables.MY_VAR`) for non-sensitive config.
For true secrets, request a platform-managed AWS Secrets Manager binding
out-of-band — the platform doesn't currently expose a `permissions.secrets`
toggle, so secrets must be wired by a platform admin per module.

**Q: Why does my Spot preemption restart cost ACT credits?**
It doesn't — the platform only settles credits on successful
completion. A preempted run that resumes from checkpoint pays for
the resumed work; a preempted run that fails terminally is refunded.
