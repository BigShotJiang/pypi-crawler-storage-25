# CLAUDE.md — HLA-Compass Batch Module

## What This Is

An HLA-Compass module deployed as **AWS Batch**: long-running, scratch-
backed compute. Best fit for tools that need hours, large memory, or
lots of disk — de-novo assembly, variant calling, deep-learning
inference on large datasets.

## Guiding Principles

- **P0: Checkpoint frequently.** Spot preemption is real. Losing 4
  hours of work because a node got reclaimed is the worst experience.
- **P1: Use scratch storage.** /scratch survives the run; /tmp is
  small and can fill up.
- **P2: Declare resources honestly.** Over-provisioning is expensive;
  under-provisioning means OOM kills.

## Decision: Is Batch the right target?

Use **Batch** when:
- Compute takes >15 minutes (or could in some cases)
- Memory or CPU needs are large (>10 GB memory, >4 vCPU)
- You need persistent scratch disk (>1 GB during the run)
- Total runtime is bounded (<24 hours typical)

Switch to a different template if:
- **<15 min, fast compute** → use `lambda-template` (cheaper, faster cold-start)
- **<60 min + needs a UI** → use `no-ui-template` (Fargate, faster spin-up)
- **Already have a Nextflow workflow** → use `pipeline-ui-template` to
  wrap it instead of porting to direct Batch

## Key Commands

```bash
hla-compass dev                                       # Local run with sample_input.json
hla-compass validate                                  # Manifest + structure
hla-compass test --input examples/sample_input.json   # Containerized smoke run
pytest                                                # Unit tests
hla-compass publish --env dev --scope org --wait      # Source-upload publish
```

## Architecture

```
Module.__init__
   ↓
execute(input, context)
   ↓
download input → /scratch
   ↓
loop: process batch → checkpoint to /scratch every N seconds
   ↓
upload output → S3 via self.storage
   ↓
return self.success(results=..., summary=...)
```

- Extend `hla_compass.Module`, implement `execute()`.
- Use `_scratch_dir()` to get the writable scratch mount.
- Pickle progress to scratch periodically — Spot preemption can hit
  at any time.
- Upload final results via `self.storage`.

## Reference workload

A toy de-novo assembler using greedy-overlap. Pure Python so the
template runs end-to-end without external binaries. Real assemblers
(SPAdes, Trinity, MEGAHIT) are wrapped via `subprocess` — see SKILL.md
for the pattern.

## Available Helpers Inside `execute()`

| Helper | Access | Purpose |
|--------|--------|---------|
| `self.api` | `APIClient` | REST API: peptides, proteins, samples, modules, runs |
| `self.data` | `DataClient` | `self.data.sql.query()` for SQL, `self.data.storage.read_text()` for S3 |
| `self.storage` | `Storage` | Save run artifacts; long-running jobs almost always produce output files |
| `self.context` | `RuntimeContext` | run_id, module_id, organization_id, environment |

Per-org S3 R/W is granted to every module unconditionally. There's no
`permissions.storage` toggle — `self.storage` is always available.

## Import Convention

```python
from hla_compass import Module
from hla_compass.module import ModuleError, ValidationError
```

## Testing

```bash
pytest tests/
hla-compass test --input examples/sample_input.json
```

The bundled sample uses a `data:` URI so the assembler runs without
S3 access.

## Complete Reference

See **SKILL.md** for the full Batch-specific recipes, scratch storage
patterns, Spot preemption handling, and migration paths.
