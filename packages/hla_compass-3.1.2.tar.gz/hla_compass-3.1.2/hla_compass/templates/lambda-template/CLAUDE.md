# CLAUDE.md — HLA-Compass Lambda Module

## What This Is

An HLA-Compass module deployed as **AWS Lambda**: stateless, fast,
single-request execution. Best fit for tools that complete in
seconds-to-minutes and don't need persistent state.

## Guiding Principles

- **P0: Match the runtime.** Lambda freezes between invocations. Don't
  fight it — keep `execute()` self-contained.
- **P1: Stay under the constraints.** 15-min hard timeout, 10 GB memory,
  /tmp only (512 MB). 250 MB unzipped package limit.
- **P2: Cold-start matters.** Heavy imports in module top-level cost
  every cold caller a second or more.

## Decision: Is Lambda the right target?

Use **Lambda** when:
- Compute completes in <15 minutes
- Total memory needed is ≤10 GB
- No need for persistent disk beyond /tmp (512 MB)
- The job is stateless — each request is independent

Switch to a different template if:
- **>15 min runtime** → use `batch-template` (long-running compute on Spot)
- **Large model file** (>500 MB) → use `no-ui-template` (Fargate, larger image)
- **Persistent state across requests** → not a module — that's a service
- **Heavy GPU compute** → `batch-template` with GPU resource declaration

## Key Commands

```bash
hla-compass dev                                       # Run locally with examples/sample_input.json
hla-compass validate                                  # Manifest + structure + entrypoint
hla-compass test --input examples/sample_input.json   # Containerized smoke run
pytest                                                # Unit tests
hla-compass publish --env dev --scope org --wait      # Source-upload publish
```

## Architecture

```
Module.__init__  →  execute(input, context)  →  validate_inputs  →  pure compute  →  success
```

- Extend `hla_compass.Module`, implement `execute()`.
- Input validated by Pydantic `Input` model (defined in `backend/main.py`).
- Return `self.success(results=..., summary=...)`.
- Raise `self.error(message, details={})` on failure — surfaces structurally
  rather than as a 5xx.

## Reference workload

Peptide molecular-weight calculation. Pure Python, no external deps,
microseconds per peptide. Real bioinformatics work — every immunopeptidomics
pipeline does this as a sanity check.

The shape (`peptides: list[str]` → `peptides: list[{sequence, length, mass_da}]`)
is a good template for any Lambda-shaped tool: take a list of items,
compute something fast per-item, return the list with annotations.

## Available Helpers Inside `execute()`

| Helper | Access | Purpose |
|--------|--------|---------|
| `self.api` | `APIClient` | REST API: peptides, proteins, samples, modules, runs |
| `self.data` | `DataClient` | `self.data.sql.query()` for SQL, `self.data.storage` for S3 |
| `self.storage` | `Storage` | Save run artifacts under the run's S3 prefix |
| `self.context` | `RuntimeContext` | run_id, module_id, organization_id, environment |

Per-org S3 R/W is granted to every module unconditionally. There's no
`permissions.storage` toggle — `self.storage` is always available.

## Import Convention

```python
from hla_compass import Module
from hla_compass.module import ModuleError, ValidationError
```

## Testing

Local smoke test exercises the canonical OVA peptide (SIINFEKL → 963.51 Da):

```python
module = LambdaModule(manifest_path="manifest.json")
result = module.run({"peptides": ["SIINFEKL"]}, mock_context)
assert result["status"] == "success"
```

## Complete Reference

See **SKILL.md** for the full Lambda-specific recipes, constraint deep-dive,
and migration paths to Fargate / Batch when your workload outgrows Lambda.
