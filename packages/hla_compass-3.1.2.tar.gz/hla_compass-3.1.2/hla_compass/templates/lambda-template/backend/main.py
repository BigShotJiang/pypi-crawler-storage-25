"""Lambda-shaped module template.

Reference workload: peptide molecular-weight calculation. Pure Python,
no external deps, fast (microseconds per peptide), cold-start friendly.
This is the canonical "stateless single-request" shape Lambda is built
for. Real bioinformatics work — peptide MW is what every immunopeptidomics
pipeline needs as a sanity check.

If your tool needs to:
  - run for >15 minutes
  - load a >100 MB model file
  - keep state between requests
  - use scratch disk beyond 512 MB

…then you want the `batch-template` (long-running) or `no-ui-template`
(Fargate, larger memory) instead. See SKILL.md for the decision matrix.
"""

from __future__ import annotations

import os
from typing import Any, Dict, List

from pydantic import BaseModel, Field

from hla_compass import Module

# Monoisotopic residue masses (Da). Inline because Lambda cold-start
# matters and these never change. ~600 bytes.
_MONOISOTOPIC = {
    "A": 71.03711,
    "C": 103.00919,
    "D": 115.02694,
    "E": 129.04259,
    "F": 147.06841,
    "G": 57.02146,
    "H": 137.05891,
    "I": 113.08406,
    "K": 128.09496,
    "L": 113.08406,
    "M": 131.04049,
    "N": 114.04293,
    "P": 97.05276,
    "Q": 128.05858,
    "R": 156.10111,
    "S": 87.03203,
    "T": 101.04768,
    "V": 99.06841,
    "W": 186.07931,
    "Y": 163.06333,
}

# Average residue masses (Da). Same shape, different physical
# constants — used when the caller cares about chemical mass rather
# than the dominant isotopologue.
_AVERAGE = {
    "A": 71.0788,
    "C": 103.1388,
    "D": 115.0886,
    "E": 129.1155,
    "F": 147.1766,
    "G": 57.0519,
    "H": 137.1411,
    "I": 113.1594,
    "K": 128.1741,
    "L": 113.1594,
    "M": 131.1926,
    "N": 114.1038,
    "P": 97.1167,
    "Q": 128.1307,
    "R": 156.1875,
    "S": 87.0782,
    "T": 101.1051,
    "V": 99.1326,
    "W": 186.2132,
    "Y": 163.1760,
}

# Water mass (added once per peptide; the residue masses above don't
# include the terminal H + OH).
_H2O_MONO = 18.01056
_H2O_AVG = 18.0153


def _resolve_run_id(context: Dict[str, Any]) -> str:
    return context.get("run_id") or context.get("job_id") or context.get("runId") or "local-run"


def _resolve_environment(context: Dict[str, Any]) -> str:
    return (
        context.get("environment")
        or context.get("env")
        or os.getenv("HLA_COMPASS_ENV")
        or os.getenv("HLA_ENV")
        or "unknown"
    )


class Options(BaseModel):
    include_isotope_masses: bool = Field(True, description="True → monoisotopic; False → average mass")


class Input(BaseModel):
    peptides: List[str]
    options: Options = Field(default_factory=Options)


def _peptide_mass(sequence: str, *, monoisotopic: bool) -> float:
    """Return the molecular weight of a peptide.

    Caller has already validated the sequence (manifest pattern). We do
    one final cheap check for unknown residues; raising here surfaces
    the bad input as a module error rather than a 500.
    """
    table = _MONOISOTOPIC if monoisotopic else _AVERAGE
    water = _H2O_MONO if monoisotopic else _H2O_AVG
    total = water
    for residue in sequence:
        if residue not in table:
            raise ValueError(f"Unknown residue '{residue}' in sequence '{sequence}'")
        total += table[residue]
    return total


class LambdaModule(Module):
    """Stateless peptide-MW calculator.

    The whole compute is in `execute()` — no startup hooks, no
    background work. Lambda freezes the runtime between invocations
    so anything you start outside `execute()` may or may not be alive
    on the next request. Don't fight it: keep it stateless.
    """

    Input = Input

    def execute(self, input_data: Input, context: Dict[str, Any]) -> Dict[str, Any]:
        peptides = input_data.peptides
        monoisotopic = input_data.options.include_isotope_masses

        run_id = _resolve_run_id(context)
        environment = _resolve_environment(context)

        self.logger.info(
            "computing peptide masses",
            extra={
                "run_id": run_id,
                "peptide_count": len(peptides),
                "monoisotopic": monoisotopic,
            },
        )

        per_peptide: List[Dict[str, Any]] = []
        for sequence in peptides:
            try:
                mass = _peptide_mass(sequence, monoisotopic=monoisotopic)
            except ValueError as exc:
                # Surface the bad input as a module-level error. Lambda
                # invokers see a structured error response rather than
                # a 5xx — easier to debug and doesn't burn ACT credits
                # on a malformed run. `self.error` raises; the framework
                # catches it in `Module.run()` and returns an error envelope.
                self.error(str(exc), details={"sequence": sequence})
            per_peptide.append(
                {
                    "sequence": sequence,
                    "length": len(sequence),
                    "mass_da": round(mass, 4),
                }
            )

        masses = [p["mass_da"] for p in per_peptide]
        report = {
            "count": len(per_peptide),
            "min_mass_da": min(masses) if masses else 0.0,
            "max_mass_da": max(masses) if masses else 0.0,
            "mean_mass_da": round(sum(masses) / len(masses), 4) if masses else 0.0,
        }

        results = {
            "peptides": per_peptide,
            "summary": report,
            "context": {
                "mode": context.get("mode"),
                "run_id": run_id,
                "environment": environment,
                "monoisotopic": monoisotopic,
            },
        }

        summary = {
            "peptides_processed": len(per_peptide),
            "monoisotopic": monoisotopic,
        }

        return self.success(results=results, summary=summary)
