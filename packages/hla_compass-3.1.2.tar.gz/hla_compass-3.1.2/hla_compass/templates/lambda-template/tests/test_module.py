"""Basic tests for the Lambda template module."""

from __future__ import annotations

from backend.main import LambdaModule


def test_module_runs_with_sample_input(sample_input, test_context):
    """Module executes successfully with the sample input."""
    module = LambdaModule(manifest_path="manifest.json")
    result = module.run(sample_input, test_context)
    assert result["status"] == "success"
    payload = result["results"]
    assert len(payload["peptides"]) == 4
    # SIINFEKL is the canonical OVA epitope; monoisotopic mass = 962.5276 Da
    # (sum of S+I+I+N+F+E+K+L residues + H2O).
    siinfekl = next(p for p in payload["peptides"] if p["sequence"] == "SIINFEKL")
    assert 962.0 < siinfekl["mass_da"] < 963.0


def test_module_returns_error_envelope_on_unknown_residue(test_context):
    """Bad residues surface as a structured error envelope, not a 5xx.

    The framework's `Module.run()` catches the `ModuleError` raised by
    `self.error()` and converts it into a `{"status": "error", ...}`
    envelope. Tests assert the envelope shape rather than expecting an
    exception to bubble through `run()`.
    """
    module = LambdaModule(manifest_path="manifest.json")
    bad_input = {"peptides": ["SIINFEKLZ"], "options": {"include_isotope_masses": True}}
    result = module.run(bad_input, test_context)
    assert result["status"] == "error"
    assert "Unknown residue" in result["error"]["message"]


def test_module_has_required_metadata(manifest):
    """Manifest contains required fields and declares Lambda compute."""
    assert manifest["name"]
    assert manifest["version"]
    assert manifest["execution"]["entrypoint"]
    assert manifest["computeType"] == "lambda"
    # Lambda's hard timeout is 900s; we ship 600s as a safer default.
    assert manifest["resources"]["maxRuntimeSeconds"] <= 900
