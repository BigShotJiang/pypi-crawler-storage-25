# SKILL.md — HLA-Compass Lambda Module

This is the canonical reference for building a Lambda-shaped module on
HLA-Compass. **Read it end-to-end before you start coding.** Lambda has
hard, non-negotiable constraints; ignoring them leads to publish failures
or runtime crashes that look mysterious.

If you've already read `no-ui-template/SKILL.md`, this document covers
the differences. The execute-contract, helpers, and data-access APIs are
identical to the Fargate template — Lambda just adds constraints.

---

## 1. The Lambda execution model in one paragraph

AWS Lambda runs your code inside an ephemeral container that AWS spins up
on demand. The container survives between invocations *most of the time*
(warm), but can be killed at any moment (frozen → discarded). Your code
sees zero of this state machine. The contract is:

> Given an input, return a result in ≤15 minutes. Don't depend on
> anything outside the input + the AWS resources your IAM role grants.

Anything you do at module top-level runs once per container; anything
inside `execute()` runs once per request. Treat the container as throwaway.

---

## 2. Hard constraints

| Constraint | Limit | Failure mode |
|---|---|---|
| **Maximum runtime** | 15 minutes (900 s) | Lambda kills the container; module-run shows status `timeout` |
| **Maximum memory** | 10 GB | Container dies; ACT credits still consumed for elapsed time |
| **Ephemeral disk** (`/tmp`) | 512 MB by default, up to 10 GB if requested | Writes throw `OSError: No space left` |
| **Package size unzipped** | 250 MB | `hla-compass publish` rejects the build |
| **Package size zipped** | 50 MB | Same — caught at publish time |
| **Container image size** | 10 GB | Hard, but you'll hit the package-size limit first |
| **Concurrent executions per region** | Account-level quota (default 1000) | Subsequent invocations queue |

The runtime template's `manifest.json` ships defaults of:
- `maxRuntimeSeconds: 600` (10 min — gives headroom under Lambda's 15-min ceiling)
- `memory: 1024` (1 GB — tune per workload)

Bump them up for heavier workloads, but keep `maxRuntimeSeconds <= 900`.

---

## 3. The Module contract

You extend `hla_compass.Module` and implement `execute()`. The base class
handles input validation, error wrapping, logging, and return-shape
contracts. Your job is the pure-compute step.

```python
from hla_compass import Module
from pydantic import BaseModel

class Input(BaseModel):
    peptides: list[str]

class MyModule(Module):
    Input = Input

    def execute(self, input_data: Input, context: dict) -> dict:
        # ... your compute ...
        return self.success(results=..., summary=...)
```

### Required attributes
- `Input`: a Pydantic model. The base class instantiates it from the
  raw input dict before calling `execute()`. If validation fails, the
  framework surfaces a `ValidationError` automatically — you never
  see invalid data.

### Required methods
- `execute(self, input_data: Input, context: dict) -> dict`: pure
  compute. Receives the validated input + the runtime context dict
  (run_id, organization_id, environment, etc.).

### Return shapes
- `self.success(results: dict, summary: dict | None = None)` — happy path.
- `self.error(message: str, details: dict | None = None)` — surface a
  structured error. Raises a `ModuleError`; the framework converts it
  to a clean response. **Don't return `{"status": "error"}` directly**;
  use `self.error()` so the run-status pipeline stays consistent.

---

## 4. Cold-start best practices

Lambda's cold-start latency is dominated by:
1. Container image pull (one-time per container)
2. Python import-time work (every cold start)
3. Heavy initialization in module top-level

The first is fixed by the platform. The second two are yours.

**Do** at module top-level:
- Light imports (`from hla_compass import Module`)
- Define small constants (residue masses, regex patterns, lookup tables <1 MB)
- Define classes

**Don't** at module top-level:
- Load model files (`pickle.load(open(...))`) — every cold start eats it
- Open network connections (DB, HTTP) — Lambda freezes them anyway
- Do work that depends on the request

If you have a >100 MB lookup table, put it in S3 and lazy-load on first
`execute()` call inside an `@functools.cache`-decorated helper. The first
warm invocation pays the load; subsequent warm invocations are free.

---

## 5. /tmp filesystem

Lambda gives you 512 MB of writable scratch at `/tmp`. Quotas:
- It's gone when the container dies (which can be at any time)
- It's NOT shared between concurrent invocations of the same function
- It's persisted across warm invocations on the same container — useful
  for caching downloaded reference data within a hot container

Patterns:
- **Cache S3 downloads in /tmp**: check `os.path.exists("/tmp/ref.fa")`
  before downloading; saves bandwidth on warm starts.
- **Never store run output in /tmp** without uploading to S3 — when the
  container dies the output dies with it. Use `self.storage.save_*()`.
- **Bound your /tmp usage**: 512 MB fills fast. If a workload needs >100 MB
  of scratch, request a higher /tmp size in the manifest, OR switch to
  `batch-template`.

---

## 6. Available helpers inside `execute()`

Same as `no-ui-template`'s SKILL.md — these all work identically on
Lambda. Documented here for completeness:

### `self.api` — `APIClient`
REST client against the platform API. Auto-authenticated with the
caller's organization context.

```python
peptides = self.api.peptides.search(sequence="SIIN")
modules = self.api.modules.list(status="ACTIVE")
```

### `self.data.sql` — `ScientificQuery`
Direct SQL against the platform's scientific database.

```python
rows = self.data.sql.query(
    "SELECT sequence FROM peptides WHERE length > %s LIMIT 10",
    (8,),
)
```

### `self.data.storage` — `StorageClient`
S3-backed storage for inputs/outputs. Org-scoped paths.

```python
data = self.data.storage.read_text("s3://org-bucket/inputs/sheet.csv")
```

### `self.storage` — `Storage`
Run-output storage. Auto-saves under the run's S3 prefix. Per-org S3 R/W
is granted to every module unconditionally; there's no `permissions.storage`
toggle to opt in or out.

```python
url = self.storage.save_json("results/output.json", payload)
url = self.storage.save_csv("results/peptides.csv", rows)
```

### `self.context` — `RuntimeContext`
The runtime context dict passed to `execute()`. Useful keys:
- `run_id` — UUID of the current module run
- `organization_id` — caller's org
- `environment` — `dev`/`staging`/`prod`
- `mode` — `interactive`/`workflow`/`api`

---

## 7. Common Lambda anti-patterns

### ❌ Loading models at module top-level
```python
# BAD — every cold start re-loads
model = pickle.load(open("model.pkl", "rb"))

class MyModule(Module):
    def execute(self, ...):
        return model.predict(...)
```

```python
# GOOD — lazy-load + cache, pays once per warm container
@functools.cache
def _load_model():
    return pickle.load(open("model.pkl", "rb"))

class MyModule(Module):
    def execute(self, ...):
        return _load_model().predict(...)
```

### ❌ Background threads / async work
```python
# BAD — Lambda freezes after execute() returns; thread dies mid-flight
threading.Thread(target=upload_in_background).start()
return self.success(...)
```

```python
# GOOD — wait for the work, or fire it to a separate queue
upload_in_background()
return self.success(...)
```

### ❌ Mutable module-level state
```python
# BAD — warm containers share this; concurrent invocations corrupt it
_RESULTS_CACHE = {}

class MyModule(Module):
    def execute(self, ...):
        _RESULTS_CACHE[key] = result  # race condition
```

```python
# GOOD — keep state inside execute()
class MyModule(Module):
    def execute(self, ...):
        results = {}
        results[key] = result
```

### ❌ Heavy native deps you don't need
```text
# requirements.txt
torch>=2.0          # 2+ GB unzipped — won't fit
tensorflow>=2.13    # ditto
```

For ML inference, use a remote endpoint (SageMaker, an internal API)
or switch to `batch-template`.

### ❌ Trying to use /tmp as durable storage
```python
# BAD — /tmp evaporates when the container dies
with open("/tmp/results.json", "w") as f:
    json.dump(results, f)
return self.success(results={"file": "/tmp/results.json"})
```

```python
# GOOD — push to S3 via self.storage
url = self.storage.save_json("results/output.json", results)
return self.success(results={"file_url": url})
```

---

## 8. Local development

```bash
# Scaffold a new module from this template
hla-compass init my-tool --template lambda

cd my-tool

# Validate before running
hla-compass validate

# Run locally with the bundled sample input
hla-compass dev

# Run a containerized smoke test (mirrors how the platform runs it)
hla-compass test --input examples/sample_input.json

# Unit tests
pytest tests/
```

`hla-compass test` builds the same container the publish flow builds
and runs it against the sample input. If it passes here, the publish
will succeed. If it fails here, fix it locally — debugging in CodeBuild
is much slower.

---

## 9. Publish flow

```bash
hla-compass publish --env dev --scope org --wait
```

What happens:
1. SDK ZIPs the module source (manifest, backend/, examples/, tests/).
2. SDK requests a presigned upload URL from the platform API.
3. SDK PUTs the ZIP to S3.
4. Platform's intake-runner (CodeBuild) builds a container image:
   - Base image: `module-runtime` (Python 3.13 slim)
   - Installs your `backend/requirements.txt`
   - Copies your source
   - Trivy scan + Cosign signing
5. Platform pushes the image to ECR and registers the module's
   compute_type as `lambda` in `platform.modules`.
6. Module is callable via the API and (after Sprint 2 of the platform's
   roadmap) auto-exposed as an MCP tool.

`--wait` makes the SDK block until the build finishes. Without it,
`hla-compass get-publish-status <module-id>` polls separately.

---

## 10. Migration paths

### Lambda → Fargate (when your tool grows)
1. Change `manifest.json`: `"computeType": "fargate"`, bump
   `resources.memory` to 4096+ if needed.
2. Remove the Lambda-specific anti-patterns warnings — Fargate doesn't
   freeze, doesn't have a 15-min ceiling, has a real filesystem.
3. Re-publish.

That's it. The `Module` contract is identical; only the constraints
change.

### Lambda → Batch (when your tool needs hours)
1. Switch templates: `hla-compass init <new-name> --template batch`
   then port your `execute()` body. Batch has different scratch handling
   (mounted EFS rather than /tmp) and explicit checkpointing patterns
   that the Lambda template doesn't cover.
2. See `batch-template/SKILL.md` for the long-running posture details.

---

## 11. When to NOT use this template

This template is wrong for:

- **Anything stateful**. Lambda freezes; state is lost.
- **GPU-heavy ML inference**. Lambda has no GPUs; switch to `batch-template`.
- **Tools with >250 MB of dependencies**. Won't fit in the package limit.
- **Long-running pipelines** (Nextflow, Snakemake, etc.). Use `pipeline-ui-template`
  to wrap an existing pipeline, or `batch-template` for direct long-running compute.
- **Tools that need to talk to other modules in real-time**. That's a
  service, not a module — use the platform's run-chaining APIs instead.

---

## 12. Reference: complete module run lifecycle

```
Caller (UI / API / MCP)
   ↓ POST /v1/module-runs
Platform module-runs handler
   ↓ acquire ACT reservation
   ↓ enqueue Lambda invocation
AWS Lambda (your code)
   ↓ Module.__init__ (loads manifest)
   ↓ Module.run(input, context)
   ↓   → validate input via Pydantic
   ↓   → execute(input, context)  ← YOUR CODE
   ↓   → wrap in success / error envelope
Platform module-runs result handler
   ↓ settle ACT credits
   ↓ persist run results
   ↓ POST optional webhook
Caller polls GET /v1/module-runs/{id}/results
```

Your `execute()` runs in step 3. Everything else is platform-managed.

---

## 13. Common questions

**Q: How do I add an environment variable?**
Add it to `manifest.json` under `environment_variables`:
```json
"environment_variables": {
  "LOG_LEVEL": "DEBUG",
  "MY_FLAG": "true"
}
```
The platform injects them at deploy time.

**Q: How do I read secrets?**
Don't bake them into the manifest. Use environment variables injected at
deploy time (`environment_variables.MY_VAR`) for non-sensitive config.
For true secrets, request a platform-managed AWS Secrets Manager binding
out-of-band — the platform doesn't currently expose a `permissions.secrets`
toggle, so secrets must be wired by a platform admin per module.

**Q: Why does my module fail with `Module package exceeds 250MB`?**
You have a heavy dependency (likely numpy/pandas/scipy/torch). Either:
- Pin lighter versions
- Switch to `no-ui-template` (Fargate — no package limit)
- Move the heavy compute to a separate batch-template module that this
  Lambda calls

**Q: My module times out occasionally, even though it usually finishes
in 30 seconds.**
Lambda's first cold-start can take 1-3 seconds; check that your
`maxRuntimeSeconds` budget accommodates that. If individual requests
genuinely take >10 minutes occasionally, switch to `batch-template`.
