# Pipeline-UI Module Template

This template scaffolds a module that wraps a Nextflow pipeline with a
custom UI.

## Layout

```
manifest.json           # computeType = "pipeline"
backend/
  main.py               # Thin config Lambda (translates inputs → params)
  requirements.txt
pipeline/
  main.nf               # Your Nextflow workflow (you own this)
  nextflow_schema.json  # Optional JSON Schema for the parameter form
frontend/
  index.tsx             # React component rendered on the run page
  package.json
examples/
  sample_input.json     # Inputs for `hla-compass dev` / pytest
  samplesheet.csv       # Example Nextflow sample sheet
tests/
  conftest.py           # Shared pytest fixtures
  test_configure.py     # Unit tests for configure()
CLAUDE.md               # Agent-facing quickstart
```

## How it runs

```
User clicks "Run" in /tools
    ↓
Module UI (frontend/index.tsx) renders
    ↓
User submits → POST /v1/modules/:id/runs
    ↓
backend/main.py Lambda runs (validates, translates)
    ↓
Platform submits a Nextflow pipeline run using pipeline/main.nf
    ↓
Module run page shows status; "Advanced: pipeline execution" drill-down
links to the Nextflow DAG view.
```

## Key rules

1. **Only one pipeline per module.** The `pipeline/` directory ships
   as-is — the platform imports it once per publish.
2. **You own `pipeline/main.nf`.** The platform never modifies it.
3. **Lambda stays thin.** Heavy work belongs in the Nextflow DAG.
4. **Credits are charged on the pipeline run, not the module run.**
   Module run is 0 ACT; pipeline run owns the estimate + settlement.

## Feeding uploaded data into the pipeline

**UI pattern (explicit):** the form asks for a `samplesheet` S3 URI and
`configure()` maps it to `params.input`. Users upload via the platform's
storage UI first, then paste or pick the URI.

**Agent / API pattern (implicit):** callers include a `dataContext` on
the run:

```json
{
  "pipelineId": "…",
  "dataContext": {"type": "s3", "uri": "s3://bucket/file.csv"}
}
```

The platform auto-injects the URI as `params.input`, so no code in this
module needs to change.

See `internal-docs/guides/module-developer/pipeline-modules.md` for the
full upload → run walkthrough.

## Local dev

```bash
# Validate the manifest + structure
hla-compass validate

# Run the configure Lambda against examples/sample_input.json
hla-compass dev --input examples/sample_input.json

# Unit tests
pytest

# Build + publish (uploads the ZIP including pipeline/)
hla-compass publish --env dev --scope org --wait
```

## See also

* `hla_compass.pipeline_module` — the `@pipeline_module.handler` decorator.
* Platform endpoint: `POST /v1/modules/<id>/runs` — dispatch sees
  `compute.type = 'pipeline'` and routes through the pipeline runner.
* `internal-docs/guides/module-developer/pipeline-modules.md` — end-to-
  end guide for adding a pipeline, uploading data, and running it.

---

## Cross-cutting concerns (access control, CORS, deployment status, idempotency)

The four areas below drift fastest between templates. Read the canonical
appendix once, then come back here for template-specific details:

→ **[Module Author Skill Appendix](../../../../internal-docs/guides/module-developer/skill-appendix.md)**

Quick checklist before publishing:

- **Access control.** Verify your org has a `resource_access_grants` row for
  this module type (or the unified `access_requests` flow approved one).
  See appendix §1.
- **CORS.** Don't add CORS code in your handler — it's centralized via
  `add_security_headers`. Run `bash scripts/smoke/cors_preflight.sh dev`
  after any new HTTP route. Appendix §2.
- **Deployment status.** `'deployed'` is the only success terminal; only
  one deployed row per (module, version) at a time. Use `hla-compass
  publish-status` to inspect failures. Appendix §3.
- **Idempotency.** For agent-driven runs, accept an `idempotency_key`
  on `run_module` invocations to deduplicate retries. For publish, the
  SDK's `idempotency_key=` kwarg propagates to the `Idempotency-Key`
  HTTP header. Appendix §4.
