// Minimal Nextflow pipeline. Replace with your actual workflow.
//
// The platform submits this via AWS Batch with -params-file params.json,
// where params.json contains whatever your backend/main.py returned in
// the "parameters" dict.
//
// You own this file. The platform does NOT modify it at import/publish.

nextflow.enable.dsl = 2

params.input = null
params.outdir = null

workflow {
    if (!params.input) {
        error "params.input is required (pass via backend/main.py)"
    }
    if (!params.outdir) {
        error "params.outdir is required"
    }

    println "Running with input: ${params.input}"
    println "Writing outputs to: ${params.outdir}"
    // Add your real processes here.
}
