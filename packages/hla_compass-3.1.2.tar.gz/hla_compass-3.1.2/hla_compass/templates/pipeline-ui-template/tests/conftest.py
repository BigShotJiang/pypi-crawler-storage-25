"""Shared test fixtures for pipeline-module tests."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

TEMPLATE_ROOT = Path(__file__).parent.parent
if str(TEMPLATE_ROOT) not in sys.path:
    sys.path.insert(0, str(TEMPLATE_ROOT))


@pytest.fixture()
def manifest() -> dict:
    """Load manifest.json from the module root."""
    return json.loads((TEMPLATE_ROOT / "manifest.json").read_text())


@pytest.fixture()
def sample_input() -> dict:
    """Load examples/sample_input.json."""
    return json.loads((TEMPLATE_ROOT / "examples" / "sample_input.json").read_text())


@pytest.fixture()
def pipeline_context():
    """Minimal PipelineModuleContext for local tests."""
    from hla_compass.pipeline_module import PipelineModuleContext

    return PipelineModuleContext(
        module_id="test-module",
        module_run_id="test-run",
        organization_id="test-org",
        user_id="test-user",
        output_uri="s3://test-bucket/runs/test-run/",
    )
