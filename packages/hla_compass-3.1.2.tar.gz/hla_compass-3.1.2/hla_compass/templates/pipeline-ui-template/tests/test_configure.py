"""Tests for the configure Lambda.

The configure function translates UI inputs into Nextflow parameters.
Keep these tests fast: the real work happens in pipeline/main.nf at run
time, not here.

The handler in backend/main.py is decorated with
``@pipeline_module.handler``, which wraps it into a Lambda event handler.
Unit tests call the raw inner function via ``configure.__wrapped__`` and
also exercise the Lambda wrapper path.
"""

from __future__ import annotations

import pytest
from backend.main import configure

raw_configure = configure.__wrapped__


def test_configure_returns_parameters_for_sample_input(sample_input, pipeline_context):
    """Happy path: a valid samplesheet URI produces Nextflow params."""
    result = raw_configure(sample_input, pipeline_context)

    assert isinstance(result["parameters"], dict)
    assert result["parameters"]["input"] == sample_input["samplesheet"]
    assert result["parameters"]["outdir"] == pipeline_context.output_uri


def test_configure_uses_context_output_uri(pipeline_context):
    """outdir is taken from the platform-supplied output_uri, not user input."""
    result = raw_configure({"samplesheet": "s3://b/x.csv"}, pipeline_context)
    assert result["parameters"]["outdir"] == "s3://test-bucket/runs/test-run/"


def test_configure_rejects_missing_samplesheet(pipeline_context):
    """Missing required input surfaces as a validation error."""
    with pytest.raises(ValueError, match="samplesheet"):
        raw_configure({}, pipeline_context)


def test_configure_passes_run_name_when_present(pipeline_context):
    """Optional run_name flows through as the pipeline run display name."""
    result = raw_configure(
        {"samplesheet": "s3://b/x.csv", "run_name": "my-run"},
        pipeline_context,
    )
    assert result.get("name") == "my-run"


def test_lambda_wrapper_returns_ok_true_on_success(sample_input):
    """End-to-end Lambda invocation returns the platform-expected shape."""
    event = {
        "inputs": sample_input,
        "moduleId": "m1",
        "moduleRunId": "r1",
        "organizationId": "o1",
        "userId": "u1",
        "context": {"outputUri": "s3://bucket/runs/r1/"},
    }
    result = configure(event, None)
    assert result["ok"] is True
    assert result["parameters"]["input"] == sample_input["samplesheet"]
    assert result["parameters"]["outdir"] == "s3://bucket/runs/r1/"


def test_lambda_wrapper_returns_ok_false_on_validation_error():
    """A missing required input surfaces as ok=False with an error message."""
    event = {
        "inputs": {},
        "moduleId": "m1",
        "moduleRunId": "r1",
        "organizationId": "o1",
        "userId": "u1",
        "context": {"outputUri": "s3://bucket/runs/r1/"},
    }
    result = configure(event, None)
    assert result["ok"] is False
    assert "samplesheet" in result["error"]


def test_manifest_has_required_fields(manifest):
    """Manifest sanity check."""
    assert manifest["name"]
    assert manifest["version"]
    assert manifest["computeType"] == "pipeline"
    assert manifest["execution"]["entrypoint"] == "backend.main:configure"
    assert manifest["ui"]["distPath"] == "frontend/dist"
