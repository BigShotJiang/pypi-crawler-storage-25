/**
 * Module UI component for a Nextflow-pipeline-wrapped module.
 *
 * Props the platform injects at mount time:
 *   - schema:         parsed pipeline/nextflow_schema.json (if present)
 *   - allowedBuckets: string[] — S3 buckets the user can reference
 *   - orgContext:     { organizationId, userId }
 *   - defaultValues:  any persisted values for the form
 *   - onSubmit:       (inputs: Record<string, unknown>) => Promise<void>
 *
 * Return any React node. The user's submit button eventually calls
 * onSubmit(inputs); those inputs become the `inputs` dict passed to your
 * backend/main.py::configure function, which translates them into
 * Nextflow parameters.
 *
 * Replace this minimal form with whatever UX your pipeline needs.
 */

import React, { useState } from 'react';

interface PipelineModuleUIProps {
  allowedBuckets: string[];
  onSubmit: (inputs: Record<string, unknown>) => Promise<void>;
}

export default function PipelineModuleUI({ allowedBuckets, onSubmit }: PipelineModuleUIProps) {
  const [samplesheet, setSamplesheet] = useState('');
  const [runName, setRunName] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await onSubmit({ samplesheet, run_name: runName });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        Sample sheet S3 URI
        <input
          type="text"
          value={samplesheet}
          onChange={(e) => setSamplesheet(e.target.value)}
          placeholder="s3://my-bucket/samplesheet.csv"
          required
        />
      </label>
      <label>
        Run name (optional)
        <input type="text" value={runName} onChange={(e) => setRunName(e.target.value)} />
      </label>
      {allowedBuckets.length > 0 && (
        <small>
          Allowed buckets: {allowedBuckets.join(', ')}
        </small>
      )}
      <button type="submit" disabled={submitting}>
        {submitting ? 'Submitting…' : 'Run pipeline'}
      </button>
    </form>
  );
}
