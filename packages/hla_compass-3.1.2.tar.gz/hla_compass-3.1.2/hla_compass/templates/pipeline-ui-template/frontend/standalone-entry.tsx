/**
 * Standalone entry point for `hla-compass serve`.
 */
import React from 'react';
import { createRoot } from 'react-dom/client';
import PipelineModuleUI from './index';

const container = document.getElementById('root');
if (container) {
  createRoot(container).render(
    <PipelineModuleUI
      allowedBuckets={[]}
      onSubmit={async (inputs) => {
        console.log('Pipeline inputs', inputs);
      }}
    />,
  );
}
