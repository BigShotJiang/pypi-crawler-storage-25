"""Thin config Lambda for a Nextflow-pipeline-wrapped module.

This file runs as an AWS Lambda. It translates user inputs from the
module UI into Nextflow pipeline parameters. Keep it fast (< 5 seconds).
The actual pipeline work happens in the Nextflow `main.nf` that ships in
the `pipeline/` directory in the module root.

Return shape:
    {
        "parameters": {...},       # required — becomes -params-file
        "name": "my run",          # optional — display name for the run
        "output_uri": "s3://..."   # optional — override output prefix
    }

Raising an exception surfaces a validation error to the user.
"""

from __future__ import annotations

from hla_compass import pipeline_module


@pipeline_module.handler
def configure(inputs: dict, context: pipeline_module.PipelineModuleContext) -> dict:
    """Translate the user's inputs into Nextflow parameters."""
    samplesheet = inputs.get("samplesheet")
    if not samplesheet:
        # This message becomes the module run's failure reason in the UI.
        raise ValueError("samplesheet is required")

    return {
        "parameters": {
            "input": samplesheet,
            "outdir": context.output_uri,
            # Add pipeline-specific parameters here. The keys must match
            # what your pipeline/main.nf expects (commonly from its
            # nextflow_schema.json properties).
        },
        "name": inputs.get("run_name"),
    }
