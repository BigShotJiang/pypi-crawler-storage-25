# CLAUDE.md — HLA-Compass Pipeline-Wrapped Module

## What This Is

An HLA-Compass module that wraps a Nextflow pipeline. The Lambda is a
thin "configure" step — it translates UI inputs into Nextflow
`-params-file` parameters. The real work runs in `pipeline/main.nf` via
AWS Batch.

## Guiding Principles

- **P0: UI/UX/DX** — Developer and user experience first.
- **P1: Security** — Scoped, signed, auditable.
- **P2: Performance** — Efficient by default.
- **P3: Elegance/Maintainability** — Clean, readable code.

**GUIDANCE:** No workarounds, no placeholders, no speculative abstractions.

## Key Commands

```bash
hla-compass dev                    # Exercise the configure Lambda locally
hla-compass validate               # Validate manifest, pipeline/, and handler wiring
pytest                             # Unit tests for configure()
hla-compass publish --env dev --scope org --wait  # Upload zip (backend + pipeline + frontend)
```

## Architecture

```
User fills UI form  →  POST /v1/modules/{id}/runs
    ↓
backend/main.py::configure(inputs, context)  ← this Lambda (< 5s)
    ↓  returns {"parameters": {...}, "name": "..."}
Platform creates a pipeline run  →  AWS Batch submits Nextflow
    ↓
pipeline/main.nf executes with params.json
    ↓
Outputs land under context.output_uri (S3)
```

- Extend `@hla_compass.pipeline_module.handler`.
- Return `{"parameters": dict, "name": str?, "output_uri": str?}`.
- Raise any exception to surface a validation error to the user.
- Heavy work belongs in Nextflow, not this Lambda.

## Connecting uploaded data to this pipeline

Two supported patterns for pointing the pipeline at user data:

**1. User uploads via the UI, then picks the S3 URI as an input.**
The UI form exposes a `samplesheet` field; the configure Lambda maps it
into `params.input`. Simple and what this template does out of the box.

**2. Agent / API caller uses `dataContext` on the pipeline run.**
When the platform starts the run with
`dataContext: {"type": "s3", "uri": "s3://..."}`, the URI is auto-
injected as `params.input` before Nextflow launches. No code needed in
this module — the binding happens in the platform's run service. See
`internal-docs/guides/module-developer/pipeline-modules.md`.

## Available Helpers Inside `configure()`

| Helper | Access | Purpose |
|--------|--------|---------|
| `context.module_id` | str | Module UUID |
| `context.module_run_id` | str | Module run UUID |
| `context.organization_id` | str | Caller's org |
| `context.user_id` | str | Caller's user ID |
| `context.output_uri` | str\|None | Suggested S3 output prefix — pass as `params.outdir` |

The configure Lambda is deliberately thin: no DB, no API helpers. If
you need them, call them from Nextflow processes instead.

## Testing

```python
from backend.main import configure
from hla_compass.pipeline_module import PipelineModuleContext

ctx = PipelineModuleContext(
    module_id="m1", module_run_id="r1",
    organization_id="o1", user_id="u1",
    output_uri="s3://bucket/runs/r1/",
)
result = configure({"samplesheet": "s3://bucket/samples.csv"}, ctx)
assert result["parameters"]["input"] == "s3://bucket/samples.csv"
```

## Complete Reference

See **SKILL.md** in this directory for full pipeline schema, manifest
fields, and recipes for wrapping nf-core pipelines.
