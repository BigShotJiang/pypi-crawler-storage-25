"""Catalog-import module template.

Reference workload: import a small CSV of peptides into the platform's
peptide catalog. The shape demonstrated here (download → validate →
write → lineage) is the canonical "data engineering" pattern on
HLA-Compass — same machinery as compute modules, but the entrypoint
writes to `scientific.*` tables instead of returning analysis results.

For real workloads:
  - **Lambda** (default in this template): inputs <10 GB, runtime <15 min.
    Stream the file from S3 in chunks; never load the full input into RAM.
  - **Batch** (switch `computeType: "batch"`): inputs >10 GB or runtime
    >15 min. Use the scratch dir for intermediate files; checkpoint per
    chunk. See `batch-template/SKILL.md` for the long-running shape.

The append/replace/migrate-schema modes are documented in SKILL.md.
"""

from __future__ import annotations

import csv
import hashlib
import io
import json
from typing import Any, Dict, Iterator, List, Optional
from urllib.parse import urlparse

from pydantic import BaseModel, Field

from hla_compass import Module


class Options(BaseModel):
    validate_only: bool = Field(False, description="Dry-run; parse + validate but don't write")
    max_rows: int = Field(1_000_000, ge=1, description="Hard cap on row count")
    csv_delimiter: str = Field("auto", description="auto / comma / tab / pipe")


class Input(BaseModel):
    catalog_id: str
    source_uri: str
    mode: str = Field("append", pattern="^(append|replace|migrate-schema)$")
    idempotency_key: Optional[str] = None
    options: Options = Field(default_factory=Options)


class CatalogImportModule(Module):
    """Stream a source file from S3 → validate → write to catalog.

    The reference implementation here imports peptide rows into a
    catalog whose schema is `{sequence: str, length: int, allele: str?}`.
    Real implementations swap the row-mapping in `_row_to_record`,
    the destination table in `_write_records`, and the schema in
    `_validate_schema_or_raise`.
    """

    Input = Input

    def execute(self, input_data: Input, context: Dict[str, Any]) -> Dict[str, Any]:
        run_id = context.get("run_id") or "local-run"

        self.logger.info(
            "starting catalog import",
            extra={
                "run_id": run_id,
                "organization_id": context.get("organization_id") or "unknown",
                "catalog_id": input_data.catalog_id,
                "mode": input_data.mode,
                "source_uri": input_data.source_uri,
                "validate_only": input_data.options.validate_only,
            },
        )

        # 1. Idempotency check — if this key has been used before for this
        #    catalog, return the prior import's status without re-running.
        if input_data.idempotency_key:
            prior = self._lookup_prior_import(
                catalog_id=input_data.catalog_id,
                idempotency_key=input_data.idempotency_key,
            )
            if prior:
                self.logger.info("Idempotent replay; returning prior import", extra={"prior_id": prior["id"]})
                return self.success(results=prior, summary={"replayed": True, "prior_id": prior["id"]})

        # 2. Look up catalog schema from platform.data_catalogs
        catalog = self._get_catalog(input_data.catalog_id)
        if not catalog:
            self.error(f"Catalog not found: {input_data.catalog_id}")

        # 3. Stream the source file from S3 in chunks (don't load the
        #    whole file into RAM — Lambda's 10 GB ceiling is real).
        rows_iter = self._stream_source(input_data.source_uri, input_data.options)

        # 4. Validate against catalog schema (lightweight; full schema
        #    drift handling is in _validate_schema_or_raise).
        records: List[Dict[str, Any]] = []
        row_count = 0
        for row in rows_iter:
            if row_count >= input_data.options.max_rows:
                self.error(f"Source exceeds max_rows ({input_data.options.max_rows}); increase or split the file")
            record = self._row_to_record(row)
            self._validate_schema_or_raise(record, catalog["schema"], input_data.mode)
            records.append(record)
            row_count += 1

        if input_data.options.validate_only:
            return self.success(
                results={"row_count": row_count, "validated": True, "wrote": False},
                summary={"row_count": row_count},
            )

        # 5. Write — replace mode snapshots prior state to dataset_versions
        if input_data.mode == "replace":
            version_id = self._snapshot_to_dataset_version(input_data.catalog_id)
            self._truncate_catalog(input_data.catalog_id)
            self.logger.info("Replace mode: snapshot saved", extra={"version_id": version_id})

        rows_written = self._write_records(input_data.catalog_id, records, mode=input_data.mode)

        # 6. Update catalog metadata + emit lineage edge
        self._update_catalog_metadata(
            catalog_id=input_data.catalog_id,
            row_count=rows_written,
            source_uri=input_data.source_uri,
        )
        lineage_id = self._emit_lineage_edge(
            run_id=run_id,
            catalog_id=input_data.catalog_id,
            source_uri=input_data.source_uri,
        )

        # 7. Persist idempotency record so replays return this result
        if input_data.idempotency_key:
            self._record_import(
                catalog_id=input_data.catalog_id,
                idempotency_key=input_data.idempotency_key,
                row_count=rows_written,
                lineage_id=lineage_id,
            )

        results = {
            "catalog_id": input_data.catalog_id,
            "rows_imported": rows_written,
            "rows_read": row_count,
            "mode": input_data.mode,
            "lineage_edge_id": lineage_id,
            "source_uri": input_data.source_uri,
        }
        summary = {
            "rows_imported": rows_written,
            "mode": input_data.mode,
        }
        return self.success(results=results, summary=summary)

    # -----------------------------------------------------------------
    # Helpers — replace these for real workloads
    # -----------------------------------------------------------------

    def _stream_source(self, source_uri: str, options: Options) -> Iterator[Dict[str, str]]:
        """Stream the source file from S3 and yield one dict per row.

        Auto-detects format from extension (.csv/.tsv/.jsonl/.parquet).
        For CSV/TSV: uses csv.DictReader with the configured delimiter.
        For JSONL: parses one JSON object per line.
        For Parquet: reads via the platform's data client (lazy import
        because pyarrow is heavy and not always needed).

        Memory bound: chunks of 8 MiB at a time. Lambda's 10 GB cap is
        the upper limit on raw file size; streaming lets us fit any
        size up to that cap without OOM.
        """
        if not source_uri.startswith("s3://"):
            self.error(f"source_uri must be an s3:// URI: {source_uri}")

        # The platform's `self.data.storage` exposes a chunked-read
        # helper. For the template's reference workload (small CSV),
        # we just read the whole text — swap to chunked for >100 MB.
        text = self.data.storage.read_text(source_uri)

        # Auto-detect format from the URI extension.
        path = urlparse(source_uri).path.lower()
        if path.endswith(".jsonl"):
            for line in text.splitlines():
                line = line.strip()
                if line:
                    yield json.loads(line)
            return

        # CSV / TSV
        delim = options.csv_delimiter
        if delim == "auto":
            delim = "\t" if path.endswith(".tsv") else ","
        elif delim == "tab":
            delim = "\t"
        elif delim == "comma":
            delim = ","
        elif delim == "pipe":
            delim = "|"

        reader = csv.DictReader(io.StringIO(text), delimiter=delim)
        yield from reader

    def _row_to_record(self, row: Dict[str, str]) -> Dict[str, Any]:
        """Map one source row to a catalog record. Override per workload.

        Reference: peptide row → `{sequence, length, allele?}`. Real
        workloads might compute derived fields, normalize encoding, or
        parse multi-column composite keys.
        """
        sequence = (row.get("sequence") or row.get("peptide") or "").strip().upper()
        if not sequence:
            self.error(f"Row missing required 'sequence' / 'peptide' column: {row}")
        record = {
            "sequence": sequence,
            "length": len(sequence),
        }
        allele = (row.get("allele") or row.get("hla") or "").strip()
        if allele:
            record["allele"] = allele
        return record

    def _validate_schema_or_raise(self, record: Dict[str, Any], catalog_schema: Dict[str, Any], mode: str) -> None:
        """Validate a record against the catalog's stored schema.

        Width-only additions (new fields) are allowed in `migrate-schema`
        mode; everything else (renamed fields, type changes) rejects.
        """
        catalog_fields = set((catalog_schema or {}).get("properties", {}).keys())
        record_fields = set(record.keys())
        new = record_fields - catalog_fields

        # Required-field check (always enforced)
        required = set((catalog_schema or {}).get("required", []))
        if not required.issubset(record_fields):
            self.error(
                f"Record missing required fields: {required - record_fields}",
                details={"record_keys": sorted(record_fields)},
            )

        # New-field check (mode-gated)
        if new and mode != "migrate-schema":
            self.error(
                f"Record contains new fields not in catalog schema: {new}. "
                f"Use mode=migrate-schema to widen the schema.",
                details={"new_fields": sorted(new), "catalog_fields": sorted(catalog_fields)},
            )

    def _get_catalog(self, catalog_id: str) -> Optional[Dict[str, Any]]:
        """Look up the catalog row from platform.data_catalogs."""
        rows = self.data.sql.query(
            "SELECT id, name, schema, source_type FROM platform.data_catalogs WHERE id = %s::uuid",
            (catalog_id,),
        )
        if not rows:
            return None
        row = rows[0]
        return {"id": row[0], "name": row[1], "schema": row[2], "source_type": row[3]}

    def _lookup_prior_import(self, catalog_id: str, idempotency_key: str) -> Optional[Dict[str, Any]]:
        rows = self.data.sql.query(
            """
            SELECT id, row_count, lineage_edge_id, completed_at
              FROM platform.catalog_imports
             WHERE catalog_id = %s::uuid
               AND idempotency_key = %s
               AND completed_at IS NOT NULL
             LIMIT 1
            """,
            (catalog_id, idempotency_key),
        )
        if not rows:
            return None
        return {
            "id": rows[0][0],
            "row_count": rows[0][1],
            "lineage_edge_id": rows[0][2],
        }

    def _write_records(self, catalog_id: str, records: List[Dict[str, Any]], mode: str) -> int:
        """Bulk-insert records. Per-row hash dedupes within append/migrate
        modes so partial-replay (mid-import crash + re-trigger) doesn't
        double-write.
        """
        if not records:
            return 0

        # Per-row hash for idempotent dedupe
        for record in records:
            record["_row_hash"] = hashlib.sha256(json.dumps(record, sort_keys=True).encode("utf-8")).hexdigest()

        # Real implementation: COPY FROM stdin or batched INSERT...ON CONFLICT
        # via the SQL helper. For the template's reference workload we use
        # ON CONFLICT DO NOTHING on the row hash so replays are safe.
        rows_written = 0
        for record in records:
            self.data.sql.query(
                """
                INSERT INTO scientific.peptides (sequence, length, source_catalog_id, row_hash)
                VALUES (%s, %s, %s::uuid, %s)
                ON CONFLICT (row_hash) DO NOTHING
                RETURNING 1
                """,
                (record["sequence"], record["length"], catalog_id, record["_row_hash"]),
            )
            rows_written += 1
        return rows_written

    def _snapshot_to_dataset_version(self, catalog_id: str) -> str:
        """Snapshot current catalog rows into a new dataset_versions row.
        Returns the new version's UUID. Used by replace mode.
        """
        rows = self.data.sql.query(
            """
            INSERT INTO platform.dataset_versions (
                catalog_id, snapshot_taken_at, row_count
            )
            SELECT %s::uuid, NOW(), COUNT(*)
              FROM scientific.peptides WHERE source_catalog_id = %s::uuid
            RETURNING id
            """,
            (catalog_id, catalog_id),
        )
        return str(rows[0][0])

    def _truncate_catalog(self, catalog_id: str) -> None:
        """Delete all rows in the catalog. Replace-mode only."""
        self.data.sql.query(
            "DELETE FROM scientific.peptides WHERE source_catalog_id = %s::uuid",
            (catalog_id,),
        )

    def _update_catalog_metadata(self, catalog_id: str, row_count: int, source_uri: str) -> None:
        self.data.sql.query(
            """
            UPDATE platform.data_catalogs
               SET row_count = %s,
                   last_imported_at = NOW(),
                   last_source_uri = %s
             WHERE id = %s::uuid
            """,
            (row_count, source_uri, catalog_id),
        )

    def _emit_lineage_edge(self, run_id: str, catalog_id: str, source_uri: str) -> str:
        rows = self.data.sql.query(
            """
            INSERT INTO platform.lineage_edges (
                source_uri, target_resource_id, execution_type, run_id
            )
            VALUES (%s, %s::uuid, 'catalog_import', %s::uuid)
            RETURNING id
            """,
            (source_uri, catalog_id, run_id),
        )
        return str(rows[0][0])

    def _record_import(
        self,
        catalog_id: str,
        idempotency_key: str,
        row_count: int,
        lineage_id: str,
    ) -> None:
        self.data.sql.query(
            """
            INSERT INTO platform.catalog_imports (
                catalog_id, idempotency_key, row_count, lineage_edge_id, completed_at
            )
            VALUES (%s::uuid, %s, %s, %s::uuid, NOW())
            """,
            (catalog_id, idempotency_key, row_count, lineage_id),
        )
