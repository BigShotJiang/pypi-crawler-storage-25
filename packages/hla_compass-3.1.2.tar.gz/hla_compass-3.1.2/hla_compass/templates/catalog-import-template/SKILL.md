# SKILL.md — HLA-Compass Catalog Import Module

This is the canonical reference for building a catalog-import module on
HLA-Compass. **Read it end-to-end before you start coding.** The
catalog-import shape has hard contracts (idempotency, schema
discipline, append-vs-replace semantics) that, when broken, cause
silent data corruption. The patterns here exist to prevent that.

If you've already read `lambda-template/SKILL.md` (most catalog
imports run on Lambda by default), the runtime constraints are
identical. This document covers the data-engineering specifics on
top of that foundation.

---

## 1. Why a dedicated template?

Compute modules return analysis results to the caller. Catalog-import
modules **write to the platform's scientific tables** — a fundamentally
different operation with different contracts:

| Compute module | Catalog-import module |
|---|---|
| Stateless analysis | Stateful write |
| Result returned to caller | Side effect on `scientific.*` |
| Re-run = same result | Re-run = duplicate rows (without idempotency) |
| Failure = caller retries | Failure = manual cleanup or partial state |

The catalog-import template enforces the patterns that prevent the
bottom-row anti-patterns: per-row hash dedupe, idempotency keys,
explicit replace-mode semantics, lineage edge emission.

---

## 2. The three import modes

### `append` (default)

Add new rows to the catalog. Existing rows are untouched. Per-row
hash dedupe means re-importing the same source twice doesn't
double-write.

**When to use:**
- Weekly fresh-data flows (new samples from a collaborator)
- Initial load of a brand-new catalog
- Backfilling missed days

**Pre-condition:** caller's source schema matches the catalog's
stored schema exactly. Mismatches reject with `SCHEMA_DRIFT`.

### `replace`

Snapshot the current catalog state to `dataset_versions`, then
truncate + re-insert.

**When to use:**
- Reference catalog refresh (e.g. updated peptide DB from Uniprot)
- Bulk-delete + re-import after a contamination
- Versioned releases (each replace creates a queryable historical version)

**Pre-condition:** confidence in the new source. Replace is destructive
to the live catalog state. Prior version stays queryable for 30 days
via `?as_of=<version_id>` URL param; after that, garbage-collected.

### `migrate-schema`

Like `append` but accepts width-only schema additions (new fields).
Other schema changes (renamed columns, type changes) still reject.

**When to use:**
- Source added a new column you want to capture
- Migrating from a v1 schema to a v2 schema with extra fields

**Pre-condition:** new fields are explicitly nullable in the catalog
schema (existing rows won't have them; new rows can fill them in).

---

## 3. Idempotency contract

Every import accepts an optional `idempotency_key`. **Always pass one
in production.** Recommended pattern:

```python
import hashlib
content_hash = hashlib.sha256(open(local_path, "rb").read()).hexdigest()[:16]
idempotency_key = f"{source_uri}#{content_hash}"
```

The platform deduplicates two ways:
1. **At the import level**: `idempotency_key` lookup in
   `platform.catalog_imports`. Replays return the prior import's
   status without re-running.
2. **At the row level**: per-row hash (sha256 of canonical-JSON-
   sorted record dict). Mid-flight crashes + retries don't double-
   write rows.

The combination means: as long as you pass the same `idempotency_key`
on every retry, replays are completely safe — even mid-import crashes,
even partial-write recoveries.

---

## 4. Streaming source files

Lambda's 10 GB ceiling means you cannot afford to load the whole file
into RAM for any source >1 GB. Stream:

```python
def _stream_source(self, source_uri: str, options: Options) -> Iterator[Dict[str, str]]:
    # For files <100 MB: read once
    if self._estimate_size(source_uri) < 100_000_000:
        text = self.data.storage.read_text(source_uri)
        yield from csv.DictReader(io.StringIO(text), delimiter=",")
        return

    # For larger files: stream in 8 MiB chunks
    buffer = ""
    for chunk in self.data.storage.stream(source_uri, chunk_size=8_388_608):
        buffer += chunk.decode("utf-8")
        # Yield complete lines; keep the partial last line for the next chunk
        while "\n" in buffer:
            line, buffer = buffer.split("\n", 1)
            yield self._parse_line(line)
    if buffer.strip():
        yield self._parse_line(buffer)
```

Memory bound is `chunk_size + max_line_length`. Even for pathological
input (one row = 100 MB of JSON), 8 MiB chunks + 100 MB line cap fit
in Lambda's 1 GB default memory.

For files >10 GB: **switch to Batch.** Don't fight Lambda's ceiling.

---

## 5. Schema validation

The catalog stores its schema as a JSON Schema object in
`platform.data_catalogs.schema`. The reference `_validate_schema_or_raise`
implementation enforces:

- **Required fields** must be present (mode-independent)
- **New fields** rejected unless `mode=migrate-schema`
- **Type checks** delegated to JSON Schema (callers can plug in
  `jsonschema.validate()` for full conformance — the template's
  reference is property-shape-only for speed)

For fast validation at scale (millions of rows), consider:
- Pre-compile the schema validator once at module init
- Validate column-presence in batches (every 1000 rows) rather than
  per-row
- Strict-typing only the required fields; let optional fields be
  duck-typed at write time

---

## 6. Lineage emission

Every import writes a `lineage_edges` row tagging:
- `source_uri` — where the data came from
- `target_resource_id` — the catalog ID
- `execution_type` — `'catalog_import'`
- `run_id` — the module run that performed the import

This makes catalog provenance queryable via `get_data_lineage(catalog_id)`.
Auditors / collaborators can trace any row back to its source.

**Don't skip this step.** A catalog without lineage edges is a
catalog without provenance, which is a compliance failure under
D6.5 tier (b).

---

## 7. Available helpers inside `execute()`

Same as `lambda-template/SKILL.md` — these all work identically. Two
helpers see heavy catalog-import use:

### `self.data.sql.query(sql, params)`

Direct SQL against scientific + platform tables. Catalog-import
modules use this for:
- Catalog metadata reads (`platform.data_catalogs`)
- Bulk inserts into `scientific.*`
- Lineage edge emission
- Idempotency record persistence

For bulk inserts, prefer batched INSERT with ON CONFLICT clauses over
row-by-row writes. Postgres `ON CONFLICT (row_hash) DO NOTHING` makes
the per-row hash dedupe a one-statement affair.

### `self.data.storage`

S3 reads with built-in IAM scoping. The org-bucket resolver (Init
6.E.1) routes reads to the right bucket automatically; you just pass
the s3:// URI.

```python
text = self.data.storage.read_text("s3://bucket/file.csv")  # full file
for chunk in self.data.storage.stream("s3://bucket/big.parquet", chunk_size=8_388_608):
    ...  # streaming
```

---

## 8. Common catalog-import anti-patterns

### ❌ No idempotency key
```python
# BAD — every retry double-writes
module.run({"catalog_id": "...", "source_uri": "..."}, ...)
```

```python
# GOOD — replay-safe
content_hash = hashlib.sha256(file_bytes).hexdigest()[:16]
module.run({
    "catalog_id": "...",
    "source_uri": "...",
    "idempotency_key": f"{source_uri}#{content_hash}",
}, ...)
```

### ❌ Loading the whole file into RAM
```python
# BAD — Lambda OOMs at >1 GB
text = self.data.storage.read_text("s3://bucket/big.csv")
records = list(csv.DictReader(io.StringIO(text)))
```

```python
# GOOD — stream
for row in self._stream_source(source_uri, options):
    yield row
```

### ❌ Skipping the schema validation step
```python
# BAD — silently writes garbage rows when source schema drifts
self._write_records(catalog_id, records, mode="append")
```

```python
# GOOD — validate every row
for record in records:
    self._validate_schema_or_raise(record, catalog["schema"], mode)
self._write_records(catalog_id, records, mode="append")
```

### ❌ Skipping the lineage edge
```python
# BAD — catalog has no provenance
self._update_catalog_metadata(...)
return self.success(...)
```

```python
# GOOD — every import writes a lineage edge
self._update_catalog_metadata(...)
lineage_id = self._emit_lineage_edge(run_id, catalog_id, source_uri)
return self.success(results={"lineage_edge_id": lineage_id, ...})
```

### ❌ Replace mode without dataset_versions snapshot
```python
# BAD — prior data lost forever; impossible to roll back
self._truncate_catalog(catalog_id)
self._write_records(...)
```

```python
# GOOD — snapshot first, then truncate + write
version_id = self._snapshot_to_dataset_version(catalog_id)
self._truncate_catalog(catalog_id)
self._write_records(...)
# Prior version queryable for 30 days via ?as_of=<version_id>
```

---

## 9. Local development

```bash
# Scaffold a new catalog-import module
hla-compass init my-import --template catalog-import

cd my-import

# Validate
hla-compass validate

# Local run with the bundled sample input
hla-compass dev

# Containerised smoke test
hla-compass test --input examples/sample_input.json

# Unit tests
pytest tests/
```

The bundled tests cover schema validation + mode-specific row mapping
without hitting AWS. End-to-end tests (real S3 + real catalog write)
run via `hla-compass test` after publish, against a dev catalog.

---

## 10. Publish flow

```bash
hla-compass publish --env dev --scope org --wait
```

Catalog-import modules use the same publish machinery as compute
modules. The difference is in the runtime IAM policy:
- Reads from S3 (the source URI)
- Reads from `platform.data_catalogs` (catalog metadata)
- Writes to `scientific.*` (the destination tables)
- Writes to `platform.lineage_edges`, `platform.dataset_versions`,
  `platform.catalog_imports`

The platform's deployer auto-provisions the right IAM. You don't
need to write a custom policy.

---

## 11. Recurring imports

Once published, catalog-import modules are invokable on a schedule
via the platform's EventBridge integration (Init 9.C.1):

```bash
hla-compass pipeline ... # (TBD — Init 9 ships the schedule API)
```

The recurring-import flow:
1. EventBridge cron fires the catalog-import module's run endpoint
2. Module reads from `source_uri` (typically a stable, externally-
   updated S3 location)
3. New rows imported in `append` mode with idempotency key based on
   the source's last-modified timestamp
4. Lineage edge written, alarms fire on failure

---

## 12. Migration paths

### Catalog-import (Lambda) → Catalog-import (Batch)

When file size + compute time exceed Lambda's ceilings:
1. Change `manifest.json:computeType` from `"lambda"` to `"batch"`
2. Add resource declarations: `memory`, `cpu`, `scratchGB`
3. Add the checkpoint pattern from `batch-template/SKILL.md`:
   pickle the import state to `/scratch` every N seconds so a Spot
   preemption can resume from the last checkpoint
4. Re-publish

The `Module` contract is identical; only constraints + checkpoint
overhead change.

### Single-file imports → Multi-file orchestration

When you need to import multiple files in a coordinated way (e.g.
a metadata.json + 10 sample.parquet files into the same catalog
atomically):
1. Wrap the catalog-import module in a Step Functions DAG (Init 9.A.3)
2. Each step invokes the catalog-import module for one file
3. Final step: `mode=migrate-schema` for any new columns introduced
   by the multi-file batch

---

## 13. When to NOT use this template

This template is wrong for:

- **Computing analysis results** — use `lambda-template` or
  `no-ui-template` (Fargate). Catalog-import writes to scientific
  tables; analysis modules return results to the caller.
- **Real-time data ingestion** (streaming Kafka, etc.) — Lambda is
  request/response. For streams, build a different shape (Kinesis +
  Lambda consumer + write-side module).
- **Source not in S3** — extend the template's `_stream_source` to
  read from your source. SFTP, HTTPS, JDBC are all viable; just
  swap the read implementation.

---

## 14. Reference: complete catalog-import lifecycle

```
Caller (UI / API / MCP / EventBridge schedule)
   ↓ POST /v1/module-runs
Platform module-runs handler
   ↓ acquire ACT reservation
   ↓ enqueue Lambda invocation
AWS Lambda (your code)
   ↓ Module.__init__ (loads manifest)
   ↓ Module.run(input, context)
   ↓   → validate input via Pydantic
   ↓   → execute(input, context)  ← YOUR CODE
   ↓     → idempotency check (skip if known key)
   ↓     → catalog lookup
   ↓     → stream source (chunked S3 reads)
   ↓     → validate every row
   ↓     → write to scientific.* (with per-row hash dedupe)
   ↓     → emit lineage edge
   ↓     → update catalog metadata
   ↓     → record idempotency for replays
   ↓   → wrap in success / error envelope
Platform module-runs result handler
   ↓ settle ACT credits
   ↓ persist run results
Caller polls GET /v1/module-runs/{id}/results
```

---

## 15. Common questions

**Q: Can I import into multiple catalogs in one run?**
No — the template is single-catalog. For multi-catalog atomic imports,
wrap multiple catalog-import runs in a Step Functions DAG (Init 9.A.3).

**Q: How do I know if my idempotency key was used before?**
Query `platform.catalog_imports` filtered by `catalog_id +
idempotency_key`. The template's `_lookup_prior_import` does this
automatically.

**Q: Replace mode says "snapshot to dataset_versions". Where does that
live? How long does it survive?**
`platform.dataset_versions` table. Default retention: 30 days.
Configurable per-catalog via `data_catalogs.version_retention_days`.

**Q: My source has a column the catalog doesn't know about. What do?**
Use `mode=migrate-schema`. The new column gets added to the catalog's
stored schema; existing rows have NULL for the new column; new rows
populate it.

**Q: How do I delete rows without replacing the whole catalog?**
Out of scope for this template. For per-row deletion, build a
separate "catalog-prune" module that runs `DELETE FROM scientific.* WHERE
source_catalog_id = X AND ...`. Lineage edge tagged `'catalog_prune'`.
