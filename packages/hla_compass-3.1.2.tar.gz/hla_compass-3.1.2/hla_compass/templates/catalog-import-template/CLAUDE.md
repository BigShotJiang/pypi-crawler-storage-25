# CLAUDE.md — HLA-Compass Catalog Import Module

## What This Is

An HLA-Compass module that **ingests data into a platform catalog** —
the canonical "data engineering" pattern. Same publish/run/audit
machinery as compute modules, but the entrypoint writes to
`scientific.*` tables instead of returning analysis results.

Use this template when you need to:
- Bulk-load a CSV/TSV/JSONL/Parquet file from S3 into a platform catalog
- Append fresh data weekly via an EventBridge schedule
- Replace a catalog's contents (with versioning preserved)
- Onboard a new collaborator's data into an existing catalog

## Guiding Principles

- **P0: Idempotency.** Per-row hash dedupe + idempotency_key replay.
  An import that crashed mid-flight + got re-triggered must not
  double-write rows.
- **P1: Schema discipline.** Validate every row against the catalog's
  stored schema. Width-only additions (new fields) are gated behind
  explicit `mode=migrate-schema`.
- **P2: Streaming.** Never load the full source file into RAM. Lambda's
  10 GB ceiling is real; chunked reads scale linearly.

## Decision: Lambda or Batch?

**Default: Lambda** (this template's `computeType`).
- File size ≤10 GB
- Total compute ≤15 min
- Memory ≤10 GB

**Switch to Batch** if any of:
- File size >10 GB
- Multiple files merged into one import
- Per-row work is expensive (e.g. embedding generation, complex normalization)
- Need scratch storage for intermediate state

To switch: set `manifest.json:computeType: "batch"`, declare resources
(memory, cpu, scratchGB) per the batch-template's defaults, and follow
the checkpoint pattern from `batch-template/SKILL.md` for resume-on-
preemption support.

## Three Import Modes

| Mode | Behaviour | When to Use |
|---|---|---|
| `append` (default) | Add new rows; per-row hash dedupes against existing | Fresh data flowing in (weekly schedules, new samples) |
| `replace` | Snapshot current state to `dataset_versions`, then overwrite | Reference catalog refresh (e.g. updated peptide DB) |
| `migrate-schema` | Like append, but accepts width-only schema additions | Data source added a new column you want to capture |

Replace mode keeps prior versions queryable for 30 days via `?as_of=<version_id>`.

## Idempotency

Pass `idempotency_key` on every import. Recommended pattern:
`{source-uri}#{content-hash}`. Replays return the prior import's status
without re-running. Mid-flight crashes + retries are safe — the per-
row hash dedupes so no double-writes.

## Key Commands

```bash
hla-compass dev                                       # Local run with examples/sample_input.json
hla-compass validate                                  # Manifest + structure
hla-compass test --input examples/sample_input.json   # Containerized smoke run
pytest                                                # Unit tests
hla-compass publish --env dev --scope org --wait      # Source-upload publish
```

## Architecture

```
Module.__init__
   ↓
execute(input, context)
   ↓
1. Idempotency check  (replay if known key)
2. Catalog lookup     (validate against stored schema)
3. Stream source      (chunked S3 reads)
4. Validate rows      (schema check per mode)
5. Write              (replace = snapshot + truncate; append/migrate = upsert)
6. Update metadata    (catalog row count + last-imported timestamp)
7. Emit lineage edge  (provenance record)
8. Persist import     (idempotency record for future replays)
   ↓
return self.success(results=..., summary=...)
```

## Reference Workload

Imports a small CSV of peptides into the platform's peptide catalog.
Real workloads swap:
- `_row_to_record()` — column mapping + derived fields
- `_validate_schema_or_raise()` — schema-specific validation
- `_write_records()` — destination table + bulk-insert pattern

## Available Helpers Inside `execute()`

| Helper | Access | Purpose |
|--------|--------|---------|
| `self.api` | `APIClient` | REST API: peptides, proteins, samples, modules, runs |
| `self.data.sql` | `ScientificQuery` | Direct SQL against scientific + platform tables |
| `self.data.storage` | `StorageClient` | Stream S3 reads (`read_text`, `read_bytes`, chunked) |
| `self.context` | `RuntimeContext` | run_id, organization_id, environment |

## Testing

```python
module = CatalogImportModule(manifest_path="manifest.json")
result = module.run({
    "catalog_id": "00000000-0000-0000-0000-000000000001",
    "source_uri": "s3://test-bucket/peptides.csv",
    "mode": "append",
}, mock_context)
assert result["status"] == "success"
```

The bundled tests cover schema validation + mode-specific row mapping
without hitting AWS. End-to-end (real S3 + real catalog write) runs
via `hla-compass test` after publish.

## Complete Reference

See **SKILL.md** for the full catalog-import recipes, schema-evolution
patterns, large-file streaming strategies, and migration paths from
Lambda → Batch when workloads outgrow the 15-min ceiling.
