"""Tests for the catalog-import template.

Exercises the schema validation + idempotency + replace-mode contracts
against a stubbed Module.data interface. Real S3 reads + DB writes are
exercised in `hla-compass test` (containerised) and on dev via the
golden-path workflow.
"""

from __future__ import annotations

from typing import Any

import pytest
from backend.main import CatalogImportModule, Input
from pydantic import ValidationError

from hla_compass.module import ModuleError


def test_manifest_declares_lambda_compute(manifest):
    """Ensure the template defaults to Lambda — workloads >15min should
    flip to batch but the template starts simple."""
    assert manifest["computeType"] == "lambda"
    assert manifest["resources"]["maxRuntimeSeconds"] <= 900
    assert manifest["execution"]["entrypoint"] == "backend.main:CatalogImportModule"


def test_input_validates_required_fields():
    """Required fields are catalog_id, source_uri, mode."""
    with pytest.raises(ValidationError):
        Input(catalog_id="abc")  # missing source_uri + mode


def test_input_rejects_invalid_mode():
    """Mode must be append / replace / migrate-schema."""
    with pytest.raises(ValidationError):
        Input(
            catalog_id="00000000-0000-0000-0000-000000000001",
            source_uri="s3://bucket/file.csv",
            mode="overwrite",  # not a valid enum value
        )


def test_input_default_options():
    """Options defaults: validate_only=False, max_rows=1M, csv_delimiter=auto."""
    inp = Input(
        catalog_id="00000000-0000-0000-0000-000000000001",
        source_uri="s3://bucket/file.csv",
        mode="append",
    )
    assert inp.options.validate_only is False
    assert inp.options.max_rows == 1_000_000
    assert inp.options.csv_delimiter == "auto"


def test_row_to_record_normalizes_sequence(test_context):
    """The reference _row_to_record uppercases sequences and computes length."""
    module = CatalogImportModule(manifest_path="manifest.json")
    record = module._row_to_record({"sequence": "siinfekl", "allele": "HLA-A*02:01"})
    assert record["sequence"] == "SIINFEKL"
    assert record["length"] == 8
    assert record["allele"] == "HLA-A*02:01"


def test_row_to_record_accepts_peptide_alias(test_context):
    """Some nf-core pipelines emit `peptide` instead of `sequence`. Both work."""
    module = CatalogImportModule(manifest_path="manifest.json")
    record = module._row_to_record({"peptide": "GILGFVFTL"})
    assert record["sequence"] == "GILGFVFTL"
    assert record["length"] == 9
    assert "allele" not in record


def test_row_to_record_rejects_missing_sequence(test_context):
    """Bad input surfaces as a structured module error."""
    module = CatalogImportModule(manifest_path="manifest.json")
    with pytest.raises(ModuleError):
        module._row_to_record({"allele": "HLA-A*02:01"})  # no sequence/peptide column


def test_validate_schema_rejects_new_field_in_append_mode(test_context):
    """append mode does NOT accept new fields — only migrate-schema does."""
    module = CatalogImportModule(manifest_path="manifest.json")
    catalog_schema: dict[str, Any] = {
        "properties": {"sequence": {"type": "string"}, "length": {"type": "integer"}},
        "required": ["sequence"],
    }
    record = {"sequence": "SIINFEKL", "length": 8, "allele": "HLA-A*02:01"}  # `allele` is new
    with pytest.raises(ModuleError):
        module._validate_schema_or_raise(record, catalog_schema, mode="append")


def test_validate_schema_accepts_new_field_in_migrate_schema_mode(test_context):
    """migrate-schema mode accepts width-only additions."""
    module = CatalogImportModule(manifest_path="manifest.json")
    catalog_schema: dict[str, Any] = {
        "properties": {"sequence": {"type": "string"}, "length": {"type": "integer"}},
        "required": ["sequence"],
    }
    record = {"sequence": "SIINFEKL", "length": 8, "allele": "HLA-A*02:01"}
    module._validate_schema_or_raise(record, catalog_schema, mode="migrate-schema")  # no raise


def test_validate_schema_rejects_missing_required_field(test_context):
    """Required-field check is mode-independent."""
    module = CatalogImportModule(manifest_path="manifest.json")
    catalog_schema: dict[str, Any] = {
        "properties": {"sequence": {"type": "string"}, "length": {"type": "integer"}},
        "required": ["sequence"],
    }
    record = {"length": 8}  # missing required `sequence`
    with pytest.raises(ModuleError):
        module._validate_schema_or_raise(record, catalog_schema, mode="append")
