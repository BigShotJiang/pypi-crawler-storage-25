"""Thin decorator for module Lambdas that wrap a bundled Nextflow pipeline.

Pipeline-wrapped modules (``compute.type = "pipeline"``) ship as a single
ZIP containing:

* ``backend/handler.py`` — the config Lambda (this file wraps it).
* ``pipeline/`` — the Nextflow pipeline (``main.nf`` + optional
  ``nextflow_schema.json``).
* ``ui/`` — optional React component bundle.

The Lambda's only job is to translate user inputs from the module UI into
Nextflow ``-params-file`` parameters. Keep it fast (< 5 seconds). The
actual long-running compute happens in the pipeline run that the platform
submits on your behalf — not inside this Lambda.

Usage
-----
.. code-block:: python

    from hla_compass import pipeline_module

    @pipeline_module.handler
    def configure(inputs, context):
        samplesheet = inputs["samplesheet"]
        return {
            "parameters": {
                "input": samplesheet,
                "outdir": context.output_uri,
                "genome": inputs.get("reference_build", "GRCh38"),
            },
            # Optional: override the run's display name.
            "name": inputs.get("run_name"),
        }

Return shape
------------
The decorated function MUST return a dict with:

* ``parameters`` (dict, required) — what lands in the Nextflow params file.
* ``name`` (str, optional) — display name for the pipeline run.
* ``output_uri`` (str, optional) — override the output prefix.

Returning anything else is treated as a validation failure and surfaces to
the user as a 400 MODULE_VALIDATION_FAILED.

Error handling
--------------
Raise exceptions to surface actionable validation errors. The error
message becomes the ``status_message`` on the module run. The decorator
traps unexpected exceptions too — they produce a 502 with a generic
message (details in CloudWatch logs).
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any, Callable

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class PipelineModuleContext:
    """Runtime context passed to the decorated configure function.

    Populated from the event the platform invokes the Lambda with.
    """

    module_id: str
    module_run_id: str
    organization_id: str
    user_id: str
    output_uri: str | None


def _build_context(event: dict[str, Any]) -> PipelineModuleContext:
    ctx = event.get("context") or {}
    return PipelineModuleContext(
        module_id=str(event.get("moduleId") or ""),
        module_run_id=str(event.get("moduleRunId") or ""),
        organization_id=str(event.get("organizationId") or ""),
        user_id=str(event.get("userId") or ""),
        output_uri=ctx.get("outputUri"),
    )


def _response(**fields: Any) -> dict[str, Any]:
    """Shape the Lambda response the way module_runs_start expects."""
    return fields


def handler(
    func: Callable[[dict[str, Any], PipelineModuleContext], dict[str, Any]],
) -> Callable[[dict[str, Any], Any], dict[str, Any]]:
    """Wrap a configure function as an AWS Lambda handler.

    The wrapper:

    1. Parses the event into ``inputs`` + a :class:`PipelineModuleContext`.
    2. Invokes ``func(inputs, context)``.
    3. Validates the returned dict has ``parameters``.
    4. Returns ``{"ok": True, "parameters": {...}, ...}`` on success,
       ``{"ok": False, "error": "..."}`` on any failure.

    The platform's module dispatcher (``_pipeline_module_runs.py``) reads
    these shapes and translates them into pipeline-run submissions.
    """

    def _wrapped(event: dict[str, Any], _lambda_context: Any) -> dict[str, Any]:
        inputs = event.get("inputs")
        if not isinstance(inputs, dict):
            inputs = {}
        ctx = _build_context(event)
        try:
            result = func(inputs, ctx)
        except Exception as exc:  # surface as validation failure
            logger.warning(
                "pipeline_module_handler_raised",
                extra={"module_run_id": ctx.module_run_id, "error": str(exc)},
            )
            return _response(ok=False, error=str(exc))

        if not isinstance(result, dict):
            return _response(
                ok=False,
                error="handler must return a dict with a 'parameters' key",
            )
        parameters = result.get("parameters")
        if not isinstance(parameters, dict):
            return _response(
                ok=False,
                error="handler must return {'parameters': <dict>, ...}",
            )
        try:
            # The platform serializes this back to JSON when writing
            # params.json to S3; fail fast if anything isn't JSON-safe.
            json.dumps(parameters)
        except (TypeError, ValueError) as exc:
            return _response(
                ok=False,
                error=f"parameters must be JSON-serializable: {exc}",
            )

        payload: dict[str, Any] = {"ok": True, "parameters": parameters}
        if "name" in result and result["name"] is not None:
            payload["name"] = str(result["name"])
        if "output_uri" in result and result["output_uri"]:
            payload["output_uri"] = str(result["output_uri"])
        if "description" in result and result["description"]:
            payload["description"] = str(result["description"])
        return payload

    _wrapped.__wrapped__ = func  # type: ignore[attr-defined]
    return _wrapped


__all__ = ["PipelineModuleContext", "handler"]
