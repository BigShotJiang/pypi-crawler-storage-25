"""
Dev loop commands (dev, serve, test, run).
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
import uuid
from datetime import UTC, datetime
from pathlib import Path

import click

from ..auth import Auth
from ..client import APIClient, APIError
from ..config import Config
from .module import _module_compute_type, build
from .utils import (
    _ensure_verbose,
    console,
    ensure_docker_available,
    suggest_doctor,
    temporary_environment,
    verbose_option,
)


@click.group()
def dev_group():
    pass


def _build_default_payload(manifest):
    inputs = manifest.get("inputs", {})
    defaults = {}
    # Simplified defaults
    if isinstance(inputs, dict):
        for k, v in inputs.items():
            if isinstance(v, dict) and "default" in v:
                defaults[k] = v["default"]
    return defaults


def _build_runtime_context(manifest, mode="interactive"):
    return {
        "run_id": f"local-{uuid.uuid4().hex[:8]}",
        "job_id": "local",
        "module_id": manifest.get("name", "dev"),
        "environment": Config.get_environment(),
        "mode": mode,
        "requested_at": datetime.now(UTC).isoformat(),
    }


def _run_module_lambda_rie(
    image: str,
    payload_path: Path,
    context_path: Path,
    output_dir: Path,
    *,
    rie_port: int = 9000,
):
    """Invoke a Lambda container image locally via the AWS Lambda Runtime
    Interface Emulator (pre-baked into ``public.ecr.aws/lambda/python:*`` base
    images at ``/usr/local/bin/aws-lambda-rie``).

    The platform invokes Lambda modules with a JSON event containing either an
    inline ``payload`` + ``context`` (interactive path) or S3 URIs (async
    path). For local test we use the inline form: build the event from the
    user's ``examples/sample_input.json`` + a synthetic runtime context, POST
    it to the RIE invocation endpoint, persist the response.

    Returns 0 on success (Lambda response shape matches Module.run() success),
    1 on Lambda or module error, 2 on Docker / network failure.
    """
    import time as _time
    from urllib.error import URLError
    from urllib.request import Request, urlopen

    payload = json.loads(payload_path.read_text(encoding="utf-8"))
    runtime_ctx = json.loads(context_path.read_text(encoding="utf-8")) if context_path.exists() else {}

    # Lambda RIE event shape: pass-through dict that lambda_handler.handler()
    # interprets. lambda_handler.py reads event["payload"] / event["context"]
    # for the inline (test) path, falling back to event["payloadUri"] etc. for
    # the async S3 path.
    event = {"payload": payload, "context": runtime_ctx}

    container_name = f"hla-compass-lambda-rie-{uuid.uuid4().hex[:8]}"
    cmd = [
        "docker",
        "run",
        "--rm",
        "-d",
        "--name",
        container_name,
        "-p",
        f"{rie_port}:8080",
    ]

    # Pass through auth env vars so the module can reach the platform API
    # if it needs to (rare for local test, but consistent with non-Lambda path).
    auth = Auth()
    api_key = auth.get_api_key()
    access_token = auth.get_access_token()
    env_lines = []
    if api_key:
        env_lines.append(f"HLA_API_KEY={api_key}")
    if access_token:
        env_lines.append(f"HLA_ACCESS_TOKEN={access_token}")

    env_file = None
    try:
        if env_lines:
            env_file = tempfile.NamedTemporaryFile(mode="w", suffix=".env", delete=False)
            env_file.write("\n".join(env_lines) + "\n")
            env_file.close()
            cmd.extend(["--env-file", env_file.name])

        cmd.append(image)

        try:
            subprocess.run(cmd, check=True, capture_output=True)
        except subprocess.CalledProcessError as exc:
            console.print(
                f"[red]Failed to start Lambda RIE container: {exc.stderr.decode() if exc.stderr else exc}[/red]"
            )
            return 2

        # Wait for RIE to be ready (it accepts connections nearly immediately
        # but cold-starts can take ~1s).
        url = f"http://127.0.0.1:{rie_port}/2015-03-31/functions/function/invocations"
        ready = False
        for _ in range(30):
            try:
                # Health check: a HEAD/GET on the invocations URL won't actually
                # work, so just open a TCP connection to see if the port is up.
                import socket as _socket

                with _socket.socket(_socket.AF_INET, _socket.SOCK_STREAM) as s:
                    s.settimeout(0.5)
                    if s.connect_ex(("127.0.0.1", rie_port)) == 0:
                        ready = True
                        break
            except Exception:
                pass
            _time.sleep(0.5)
        if not ready:
            console.print(f"[red]Lambda RIE never started listening on port {rie_port}[/red]")
            subprocess.run(["docker", "logs", container_name], check=False)
            return 2

        try:
            req = Request(
                url,
                data=json.dumps(event).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urlopen(req, timeout=900) as resp:
                response_body = resp.read().decode("utf-8")
        except URLError as exc:
            console.print(f"[red]Lambda RIE invocation failed: {exc}[/red]")
            subprocess.run(["docker", "logs", container_name], check=False)
            return 2

        # Stream container logs back to the user (matches the non-Lambda path's
        # behavior of letting them see the module's stdout/stderr).
        console.print("\n[dim]── Lambda container logs ──[/dim]")
        subprocess.run(["docker", "logs", container_name], check=False)

        # Persist response to dist/test-output/output.json (matches the
        # non-Lambda path's contract so downstream code can read it the same way).
        output_dir.mkdir(parents=True, exist_ok=True)
        (output_dir / "output.json").write_text(response_body, encoding="utf-8")

        try:
            response_payload = json.loads(response_body)
        except json.JSONDecodeError:
            console.print(f"[red]Lambda RIE returned non-JSON response: {response_body[:500]}[/red]")
            return 1

        # Lambda RIE returns {"errorType": ..., "errorMessage": ...} on uncaught
        # exceptions. Treat that as a failure.
        if isinstance(response_payload, dict) and response_payload.get("errorType"):
            console.print(
                f"[red]Lambda invocation raised "
                f"{response_payload.get('errorType')}: {response_payload.get('errorMessage')}[/red]"
            )
            return 1

        return 0
    finally:
        # Always tear down the container; ignore failures (e.g. it already exited).
        subprocess.run(["docker", "rm", "-f", container_name], check=False, capture_output=True)
        if env_file is not None:
            Path(env_file.name).unlink(missing_ok=True)


def _run_module_container(
    image=None,
    manifest_path=None,
    payload_path=None,
    context_path=None,
    output_dir=None,
    *,
    image_tag=None,
):
    manifest_path = Path(manifest_path) if manifest_path is not None else None
    payload_path = Path(payload_path) if payload_path is not None else None
    context_path = Path(context_path) if context_path is not None else None
    output_dir = Path(output_dir) if output_dir is not None else None

    if not all([manifest_path, payload_path, context_path, output_dir]):
        raise ValueError("manifest_path, payload_path, context_path, and output_dir are required")

    selected_image = image_tag or image
    if not selected_image:
        raise ValueError("image or image_tag is required")

    if output_dir and output_dir.exists():
        for path in output_dir.iterdir():
            if path.is_dir():
                shutil.rmtree(path)
            else:
                path.unlink()

    cmd = [
        "docker",
        "run",
        "--rm",
        "-v",
        f"{payload_path.resolve()}:/var/input.json:ro",
        "-v",
        f"{context_path.resolve()}:/var/context.json:ro",
        "-v",
        f"{output_dir.resolve()}:/var/dev-out",
        "-v",
        f"{manifest_path.resolve()}:/app/manifest.json:ro",
        "-e",
        "HLA_COMPASS_OUTPUT=/var/dev-out/output.json",
    ]

    # Write credentials to a temp env-file to avoid leaking them in `ps` output
    auth = Auth()
    env_lines = []
    api_key = auth.get_api_key()
    if api_key:
        env_lines.append(f"HLA_API_KEY={api_key}")
    access_token = auth.get_access_token()
    if access_token:
        env_lines.append(f"HLA_ACCESS_TOKEN={access_token}")

    env_file = None
    try:
        if env_lines:
            env_file = tempfile.NamedTemporaryFile(mode="w", suffix=".env", delete=False)
            env_file.write("\n".join(env_lines) + "\n")
            env_file.close()
            cmd.extend(["--env-file", env_file.name])

        cmd.append(selected_image)

        return subprocess.run(cmd).returncode
    finally:
        if env_file is not None:
            Path(env_file.name).unlink(missing_ok=True)


@click.command()
@verbose_option
@click.option("--mode", default="interactive")
@click.option("--image-tag")
@click.option(
    "--platform",
    help="Docker build platform(s), e.g. linux/amd64 or linux/amd64,linux/arm64",
)
@click.option(
    "--sdk-path",
    type=click.Path(path_type=Path),
    envvar="HLA_COMPASS_SDK_PATH",
    help="Install the SDK from a local path inside the image (for development)",
)
@click.option("--payload", type=click.Path(path_type=Path))
@click.pass_context
def dev(ctx, mode, image_tag, platform, sdk_path, payload):
    """Run module in dev loop"""
    _ensure_verbose(ctx)
    ensure_docker_available()

    manifest_path = Path("manifest.json")
    if not manifest_path.exists():
        console.print("[red]manifest.json missing[/red]")
        sys.exit(1)

    manifest = json.loads(manifest_path.read_text())

    # Build image first
    report = ctx.invoke(build, tag=image_tag, push=False, platform=platform, sdk_path=sdk_path)
    image = report.get("image_tag")

    dist_dir = Path("dist")
    dist_dir.mkdir(exist_ok=True)

    payload_path = payload or dist_dir / "dev-input.json"
    if not payload:
        # Auto-detect examples/sample_input.json as default dev input
        sample_input = Path("examples/sample_input.json")
        if sample_input.exists():
            payload_path = sample_input
        else:
            payload_path.write_text(json.dumps(_build_default_payload(manifest)), encoding="utf-8")

    context_path = dist_dir / "dev-context.json"
    context_path.write_text(json.dumps(_build_runtime_context(manifest, mode)), encoding="utf-8")

    output_dir = dist_dir / "dev-output"
    output_dir.mkdir(exist_ok=True)

    console.print(f"[cyan]Running {image}...[/cyan]")
    try:
        while True:
            _run_module_container(image, manifest_path, payload_path, context_path, output_dir)
            if (output_dir / "output.json").exists():
                console.print((output_dir / "output.json").read_text())
            input("\nPress Enter to re-run...")
    except KeyboardInterrupt:
        pass


@click.command()
@verbose_option
@click.option("--port", default=8080)
@click.option(
    "--platform",
    help="Docker build platform(s), e.g. linux/amd64 or linux/amd64,linux/arm64",
)
@click.option(
    "--sdk-path",
    type=click.Path(path_type=Path),
    envvar="HLA_COMPASS_SDK_PATH",
    help="Install the SDK from a local path inside the image (for development)",
)
@click.pass_context
def serve(ctx, port, platform, sdk_path):
    """Serve module UI locally"""
    _ensure_verbose(ctx)
    ensure_docker_available()

    report = ctx.invoke(build, push=False, platform=platform, sdk_path=sdk_path)
    image = report.get("image_tag")

    cmd = ["docker", "run", "--rm", "-p", f"{port}:8080"]

    auth = Auth()
    env_lines = []
    api_key = auth.get_api_key()
    if api_key:
        env_lines.append(f"HLA_API_KEY={api_key}")
    access_token = auth.get_access_token()
    if access_token:
        env_lines.append(f"HLA_ACCESS_TOKEN={access_token}")

    env_file = None
    try:
        if env_lines:
            env_file = tempfile.NamedTemporaryFile(mode="w", suffix=".env", delete=False)
            env_file.write("\n".join(env_lines) + "\n")
            env_file.close()
            cmd.extend(["--env-file", env_file.name])

        cmd += ["--entrypoint", "python", image, "/app/container-serve.py"]
        rc = subprocess.run(cmd).returncode
        if rc != 0:
            sys.exit(rc)
    finally:
        if env_file is not None:
            Path(env_file.name).unlink(missing_ok=True)


@click.command()
@verbose_option
@click.option("--input", type=click.Path(path_type=Path))
@click.option("--output", type=click.Path(path_type=Path))
@click.option("--json", "json_format", is_flag=True)
@click.option(
    "--platform",
    help="Docker build platform(s), e.g. linux/amd64 or linux/amd64,linux/arm64",
)
@click.option(
    "--sdk-path",
    type=click.Path(path_type=Path),
    envvar="HLA_COMPASS_SDK_PATH",
    help="Install the SDK from a local path inside the image (for development)",
)
@click.pass_context
def test(ctx, input, output, json_format, platform, sdk_path):
    """Run tests"""
    _ensure_verbose(ctx)

    def _is_successful_result(payload) -> bool:
        if isinstance(payload, dict):
            status = payload.get("status")
            if status is not None:
                return status == "success"
            if payload.get("error") is not None:
                return False
        return True

    def _extract_error_message(payload) -> str | None:
        if not isinstance(payload, dict):
            return None
        error = payload.get("error")
        if isinstance(error, dict):
            return error.get("message") or error.get("type")
        if isinstance(error, str):
            return error
        return None

    ensure_docker_available()
    manifest_path = Path("manifest.json")
    if not manifest_path.exists():
        console.print("[red]manifest.json missing[/red]")
        sys.exit(1)

    manifest = json.loads(manifest_path.read_text())
    report = ctx.invoke(build, push=False, platform=platform, sdk_path=sdk_path)
    image = report.get("image_tag")

    dist_dir = Path("dist")
    dist_dir.mkdir(exist_ok=True)

    payload_path = input or dist_dir / "test-input.json"
    if not input:
        # Auto-detect examples/sample_input.json as default test input
        sample_input = Path("examples/sample_input.json")
        if sample_input.exists():
            payload_path = sample_input
        else:
            payload_path.write_text(json.dumps(_build_default_payload(manifest)), encoding="utf-8")

    context_path = dist_dir / "test-context.json"
    context_path.write_text(json.dumps(_build_runtime_context(manifest, mode="test")), encoding="utf-8")

    output_dir = dist_dir / "test-output"
    output_dir.mkdir(exist_ok=True)

    # Lambda modules use the AWS Lambda Runtime Interface Emulator (pre-baked
    # into the AWS Lambda Python base image) so local test fully mirrors how
    # the platform invokes the module in cloud Lambda. Non-Lambda modules use
    # the long-running-process path (volume-mounted I/O files).
    if _module_compute_type(manifest) == "lambda":
        rc = _run_module_lambda_rie(image, payload_path, context_path, output_dir)
    else:
        rc = _run_module_container(image, manifest_path, payload_path, context_path, output_dir)
    output_file = output_dir / "output.json"
    output_payload = None
    if output and output_file.exists():
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(output_file.read_text())

    if output_file.exists():
        if json_format:
            console.print(output_file.read_text())
        else:
            console.print(output_file.read_text())

    if output_file.exists():
        try:
            output_payload = json.loads(output_file.read_text())
        except json.JSONDecodeError:
            output_payload = None

    if output_payload is not None and not _is_successful_result(output_payload):
        error_message = _extract_error_message(output_payload)
        detail = f": {error_message}" if error_message else ""
        console.print(f"[red]Test failed{detail}[/red]")
        sys.exit(1)

    if rc != 0:
        sys.exit(rc)
    console.print("[green]✓ Test passed[/green]")


@click.command()
@verbose_option
@click.option("--env", type=click.Choice(["dev", "staging", "prod"]), help="Target environment")
@click.option(
    "--parameters",
    "--input",
    "parameters",
    type=click.Path(path_type=Path),
    help="Path to JSON file with module parameters. --input is accepted for backwards compatibility.",
)
@click.option("--wait/--no-wait", default=False, show_default=True, help="Wait until the run reaches a terminal state")
@click.option("--timeout", default=600.0, show_default=True, type=float, help="Seconds to wait when --wait is set")
@click.option("--poll-interval", default=5.0, show_default=True, type=float, help="Polling interval for --wait")
@click.option("--mode", default="interactive", show_default=True, help="Run mode")
@click.option("--compute-profile", help="Compute profile override")
@click.option("--version", help="Module version override")
@click.argument("module_id")
def run(env, parameters, wait, timeout, poll_interval, mode, compute_profile, version, module_id):
    """Run remote module"""
    with temporary_environment(env):
        payload = {}
        if parameters:
            try:
                payload = json.loads(parameters.read_text(encoding="utf-8"))
            except Exception as e:
                console.print(f"[red]Failed to read parameters file: {e}[/red]")
                sys.exit(1)

        client = APIClient()
        try:
            res = client.start_module_run(
                module_id,
                parameters=payload,
                mode=mode,
                compute_profile=compute_profile,
                version=version,
            )
        except APIError as e:
            status = f"{e.status_code}" if getattr(e, "status_code", None) else "unknown"
            console.print(f"[red]Failed to start module run ({status}): {e}[/red]")
            if getattr(e, "status_code", None) == 401:
                console.print("[dim]Hint: Run `hla-compass auth login` and retry.[/dim]")
            elif getattr(e, "status_code", None) == 403:
                console.print("[dim]Hint: Your user/org may not have permission to start module runs.[/dim]")
            suggest_doctor()
            sys.exit(1)

        run_id = None
        if isinstance(res, dict):
            run_id = res.get("runId") or res.get("id") or res.get("run_id")
        console.print(f"[green]✓[/green] Run started: {run_id or res}")
        if wait:
            if not run_id:
                console.print("[red]Cannot wait for run because the API response did not include a run id.[/red]")
                sys.exit(1)
            try:
                result = client.wait_for_module_run(
                    str(run_id),
                    timeout=timeout,
                    poll_interval=poll_interval,
                )
            except APIError as e:
                console.print(f"[red]Run failed:[/red] {e}")
                suggest_doctor()
                sys.exit(1)
            console.print(json.dumps(result, indent=2))
            console.print(f"[green]✓[/green] Run succeeded: {run_id}")
