"""Check for newer SDK versions on PyPI.

Caches the check result to avoid hitting PyPI on every CLI invocation.
At most one check per 24 hours; all errors are swallowed silently.

Set ``HLA_COMPASS_SKIP_VERSION_CHECK=1`` to disable (useful in CI).
"""

from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_CACHE_TTL_SECONDS = 86400  # 24 hours
_PYPI_URL = "https://pypi.org/pypi/hla-compass/json"


def _cache_path() -> Path:
    config_dir = os.environ.get("HLA_COMPASS_CONFIG_DIR") or os.path.expanduser("~/.hla-compass")
    return Path(config_dir) / ".version-cache"


def _read_cache() -> dict[str, Any] | None:
    try:
        path = _cache_path()
        if not path.exists():
            return None
        data = json.loads(path.read_text(encoding="utf-8"))
        if time.time() - data.get("checked_at", 0) < _CACHE_TTL_SECONDS:
            return data
        return None  # expired
    except Exception:
        return None


def _write_cache(latest: str) -> None:
    try:
        path = _cache_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps({"latest": latest, "checked_at": time.time()}),
            encoding="utf-8",
        )
    except Exception:
        pass  # non-critical


def _fetch_latest_version() -> str | None:
    """Fetch the latest version string from PyPI. Returns None on any failure."""
    try:
        import urllib.request

        req = urllib.request.Request(_PYPI_URL, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data.get("info", {}).get("version")
    except Exception:
        return None


def _version_tuple(v: str) -> tuple[int, ...]:
    """Parse a version string like '2.1.3' into a comparable tuple."""
    try:
        return tuple(int(p) for p in v.split(".")[:3])
    except (ValueError, AttributeError):
        return (0,)


def check_version(console: Any | None = None) -> None:  # noqa: ARG001
    """Print a warning if a newer SDK version is available.

    Always prints to stderr to avoid corrupting structured stdout output.
    This function is safe to call from any context — it never raises and
    completes quickly thanks to the 24-hour cache.
    """
    if os.environ.get("HLA_COMPASS_SKIP_VERSION_CHECK", "").strip() in {"1", "true", "yes"}:
        return

    try:
        from .._version import __version__ as current

        # Check cache first
        cached = _read_cache()
        if cached:
            latest = cached["latest"]
        else:
            latest = _fetch_latest_version()
            if latest:
                _write_cache(latest)

        if not latest:
            return

        if _version_tuple(latest) > _version_tuple(current):
            # Always print to stderr to avoid corrupting JSON/structured stdout output

            from rich.console import Console as _Console

            stderr_console = _Console(stderr=True)
            stderr_console.print(
                f"[dim]A newer version of hla-compass is available: "
                f"[bold]{latest}[/bold] (current: {current}). "
                f"Run: pip install --upgrade hla-compass[/dim]"
            )
    except Exception:
        pass  # Never let version check break the CLI
