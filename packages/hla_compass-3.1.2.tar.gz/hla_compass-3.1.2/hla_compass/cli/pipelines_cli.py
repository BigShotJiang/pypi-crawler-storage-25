"""Pipeline CLI commands — import, register, list, run, logs, status, cancel."""

from __future__ import annotations

import json
from pathlib import Path

import click

from ..client import APIClient, APIError
from .utils import console, error_console, verbose_option


@click.group(name="pipeline")
def pipeline():
    """Manage and run HLA-Compass pipelines (Nextflow, nf-core, custom ZIP)."""


@pipeline.command(name="import-nfcore")
@click.argument("pipeline_ref")
@click.option("--version", required=True, help="nf-core pipeline version tag (e.g. 3.14.0)")
@click.option("--name", help="Optional display name override")
@click.option("--description", help="Optional description override")
@verbose_option
def import_nfcore_cmd(pipeline_ref, version, name, description):
    """Import an official nf-core pipeline. PIPELINE_REF is e.g. 'nf-core/rnaseq'."""
    client = APIClient()
    try:
        result = client.import_nfcore_pipeline(
            pipeline_ref,
            version,
            name=name,
            description=description,
        )
        console.print(f"[green]Imported[/green] {pipeline_ref}@{version} → {result.get('id', '?')}")
        console.print(f"  name:       {result.get('name')}")
        console.print(f"  revision:   {result.get('resolvedRevision', '')[:12]}")
        console.print(f"  parameters: {result.get('parameterCount')} ({result.get('requiredParameterCount')} required)")
    except APIError as exc:
        error_console.print(f"[red]Import failed:[/red] {exc}")
        raise click.Abort() from exc


@pipeline.command(name="add-params-preset")
@click.argument("pipeline_id")
@click.argument("name")
@click.argument("file_path", type=click.Path(exists=True, dir_okay=False, path_type=Path))
@click.option("--description", help="Short blurb shown next to the preset in the run wizard")
@click.option(
    "--default/--no-default", "is_default", default=False, help="Mark this preset as auto-selected for new runs"
)
@verbose_option
def add_params_preset_cmd(pipeline_id, name, file_path, description, is_default):
    """Register a curated params-file preset on a pipeline.

    PIPELINE_ID is the pipeline UUID, NAME is the human-readable preset
    label (e.g. "Human RNA-seq"), and FILE_PATH points at a local
    .yaml / .yml / .json file. The file is uploaded to the pipeline's
    versioned S3 prefix and registered in launchConfig.paramsFilePresets.
    """
    client = APIClient()
    try:
        result = client.add_params_preset(
            pipeline_id,
            name=name,
            file_path=str(file_path),
            description=description,
            is_default=is_default,
        )
        preset = result.get("preset") or {}
        console.print(f"[green]Registered[/green] preset '{name}' on pipeline {pipeline_id}")
        console.print(f"  uri:        {preset.get('uri', '?')}")
        if description:
            console.print(f"  description: {description}")
        if is_default:
            console.print("  [yellow]marked as default — wizard will auto-select on page load[/yellow]")
    except APIError as exc:
        error_console.print(f"[red]Preset registration failed:[/red] {exc}")
        raise click.Abort() from exc


@pipeline.command(name="delete-params-preset")
@click.argument("pipeline_id")
@click.argument("name")
@click.confirmation_option(prompt="Delete this preset? The S3 file will also be removed.")
@verbose_option
def delete_params_preset_cmd(pipeline_id, name):
    """Remove a registered params-file preset from a pipeline."""
    client = APIClient()
    try:
        result = client.delete_params_preset(pipeline_id, name)
        console.print(f"[green]Deleted[/green] preset '{result.get('deleted', name)}'")
    except APIError as exc:
        error_console.print(f"[red]Preset delete failed:[/red] {exc}")
        raise click.Abort() from exc


@pipeline.command(name="import-github")
@click.argument("repository")
@click.option("--ref", required=True, help="Git ref (branch, tag, or commit SHA)")
@click.option("--name", help="Optional display name")
@click.option("--description", help="Optional description")
@click.option("--github-token", envvar="GITHUB_TOKEN", help="GitHub PAT (for private repos)")
@verbose_option
def import_github_cmd(repository, ref, name, description, github_token):
    """Import a pipeline from an arbitrary GitHub repo. REPOSITORY is 'org/repo'."""
    client = APIClient()
    try:
        result = client.import_github_pipeline(
            repository,
            ref,
            name=name,
            description=description,
            github_token=github_token,
        )
        console.print(f"[green]Imported[/green] {repository}@{ref} → {result.get('id', '?')}")
    except APIError as exc:
        error_console.print(f"[red]Import failed:[/red] {exc}")
        raise click.Abort() from exc


@pipeline.command(name="register")
@click.argument("zip_path", type=click.Path(exists=True, dir_okay=False, path_type=Path))
@click.option("--name", required=True, help="Pipeline display name")
@click.option("--version", help="Pipeline version label (e.g. v1.0.0)")
@click.option("--description", help="Optional description")
@click.option("--engine", default="NEXTFLOW", show_default=True, help="Pipeline engine")
@click.option(
    "--parameter-template",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    help="Path to parameter template JSON file",
)
@click.option("--public/--private", default=False, help="Publish to the public catalog")
@verbose_option
def register_cmd(zip_path, name, version, description, engine, parameter_template, public):
    """Upload a pipeline ZIP and register it as a platform pipeline."""
    client = APIClient()
    try:
        console.print(f"Uploading {zip_path.name} ({zip_path.stat().st_size:,} bytes)…")
        uploaded = client.upload_pipeline_zip(str(zip_path))
        s3_uri = uploaded["s3Uri"]
        console.print(f"  → {s3_uri}")

        template = None
        if parameter_template:
            template = json.loads(parameter_template.read_text())

        result = client.register_pipeline(
            name=name,
            s3_uri=s3_uri,
            engine=engine,
            version=version,
            description=description,
            parameter_template=template,
            is_public=public,
        )
        console.print(f"[green]Registered[/green] pipeline {result.get('id', '?')} ({name})")
    except APIError as exc:
        error_console.print(f"[red]Register failed:[/red] {exc}")
        raise click.Abort() from exc


@pipeline.command(name="list")
@click.option("--engine", help="Filter by engine (e.g. NEXTFLOW)")
@click.option("--status", help="Filter by status (e.g. ACTIVE)")
@click.option("--limit", default=50, show_default=True)
@verbose_option
def list_cmd(engine, status, limit):
    """List available pipelines."""
    from rich.table import Table

    client = APIClient()
    try:
        pipelines = client.list_pipelines(engine=engine, status=status, limit=limit)
    except APIError as exc:
        error_console.print(f"[red]List failed:[/red] {exc}")
        raise click.Abort() from exc

    table = Table(title="Pipelines")
    table.add_column("ID", style="cyan")
    table.add_column("Name", style="green")
    table.add_column("Engine", style="blue")
    table.add_column("Version", style="magenta")
    table.add_column("Status")
    for p in pipelines:
        table.add_row(
            str(p.get("id", ""))[:36],
            str(p.get("name", "")),
            str(p.get("engine", "")),
            str(p.get("version", "")),
            str(p.get("status", "")),
        )
    console.print(table)


@pipeline.command(name="run")
@click.argument("pipeline_id")
@click.option(
    "--params",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    help="Path to JSON file of inline pipeline parameters. Mutually exclusive with --params-file* and --samplesheet.",
)
@click.option(
    "--params-file",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    help="Local path to a YAML/JSON params file (nf-core convention). SDK uploads it before submit.",
)
@click.option(
    "--params-file-uri",
    help="Existing S3 URI to a YAML/JSON params file. Mutually exclusive with --params and --params-file.",
)
@click.option(
    "--samplesheet",
    help="Local path OR S3 URI to a samplesheet CSV. Local paths are auto-uploaded; either way the URI is set as params.input.",
)
@click.option("--name", help="Optional run display name (unique per org)")
@click.option(
    "--data-context",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    help="Path to JSON file of data context bindings",
)
@click.option(
    "--resource-profile",
    help="Resource preset name (e.g. Small, Standard, Large, Alithea-Giga). "
    "Defaults to the organization's default preset.",
)
@verbose_option
def run_cmd(pipeline_id, params, params_file, params_file_uri, samplesheet, name, data_context, resource_profile):
    """Start a pipeline run."""
    if sum(bool(x) for x in (params, params_file, params_file_uri)) > 1:
        error_console.print("[red]--params, --params-file, and --params-file-uri are mutually exclusive[/red]")
        raise click.Abort()
    client = APIClient()
    try:
        parameters = json.loads(params.read_text()) if params else None
        ctx = json.loads(data_context.read_text()) if data_context else None
        result = client.start_pipeline_run(
            pipeline_id,
            parameters=parameters,
            params_file=str(params_file) if params_file else None,
            params_file_uri=params_file_uri,
            samplesheet=samplesheet,
            name=name,
            data_context=ctx,
            resource_profile=resource_profile,
        )
        run_id = result.get("runId") or result.get("id")
        console.print(f"[green]Started[/green] run {run_id}")
        console.print(f"  status: {result.get('status', 'PENDING')}")
        run_slug = result.get("runSlug")
        if run_slug:
            console.print(f"  slug:   {run_slug}")
        rp = result.get("resourceProfile") or {}
        if rp.get("name"):
            console.print(f"  resource profile: {rp['name']}")
    except APIError as exc:
        error_console.print(f"[red]Run failed:[/red] {exc}")
        raise click.Abort() from exc


@pipeline.command(name="status")
@click.argument("run_id")
@verbose_option
def status_cmd(run_id):
    """Show pipeline run status."""
    client = APIClient()
    try:
        run = client.get_pipeline_run(run_id)
    except APIError as exc:
        error_console.print(f"[red]Status failed:[/red] {exc}")
        raise click.Abort() from exc

    console.print(f"Run [cyan]{run.get('id', run_id)}[/cyan]")
    console.print(f"  status:     {run.get('status', 'UNKNOWN')}")
    console.print(f"  pipeline:   {run.get('pipelineId', '')}")
    console.print(f"  name:       {run.get('name', '')}")
    console.print(f"  started:    {run.get('startedAt', '')}")
    console.print(f"  completed:  {run.get('completedAt', '')}")
    if run.get("reportUri"):
        console.print(f"  report:     {run['reportUri']}")


@pipeline.command(name="tasks")
@click.argument("run_id")
@verbose_option
def tasks_cmd(run_id):
    """Show task-level detail for a pipeline run (from Nextflow trace)."""
    from rich.table import Table

    client = APIClient()
    try:
        tasks = client.get_pipeline_run_tasks(run_id)
    except APIError as exc:
        error_console.print(f"[red]Tasks failed:[/red] {exc}")
        raise click.Abort() from exc

    if not tasks:
        console.print("[yellow]No tasks found (trace not yet uploaded?)[/yellow]")
        return

    table = Table(title=f"Tasks for run {run_id}")
    table.add_column("Task", style="cyan")
    table.add_column("Name", style="green")
    table.add_column("Status", style="magenta")
    table.add_column("CPU")
    table.add_column("Mem (GB)")
    table.add_column("Started", style="blue")
    for t in tasks:
        table.add_row(
            str(t.get("taskId", "")),
            str(t.get("taskName", "")),
            str(t.get("status", "")),
            str(t.get("cpus") or ""),
            str(t.get("memoryGb") or ""),
            str(t.get("startedAt") or ""),
        )
    console.print(table)


@pipeline.command(name="logs")
@click.argument("run_id")
@click.option("--limit", type=int, help="Max events to return")
@click.option("--next-token", help="Pagination token from a previous page")
@verbose_option
def logs_cmd(run_id, limit, next_token):
    """Fetch CloudWatch log events for a pipeline run."""
    client = APIClient()
    try:
        payload = client.get_pipeline_run_logs(run_id, limit=limit, next_token=next_token)
    except APIError as exc:
        error_console.print(f"[red]Logs failed:[/red] {exc}")
        raise click.Abort() from exc

    events = payload.get("events") or payload.get("logEvents") or []
    for evt in events:
        timestamp = evt.get("timestamp") or evt.get("time") or ""
        message = evt.get("message") or evt.get("logMessage") or ""
        console.print(f"[dim]{timestamp}[/dim] {message}")
    nt = payload.get("nextToken") or payload.get("nextForwardToken")
    if nt:
        console.print(f"\n[dim]next-token: {nt}[/dim]")


@pipeline.command(name="cancel")
@click.argument("run_id")
@verbose_option
def cancel_cmd(run_id):
    """Cancel an in-progress pipeline run."""
    client = APIClient()
    try:
        result = client.cancel_pipeline_run(run_id)
        console.print(f"[green]Cancelled[/green] {run_id} (status: {result.get('status', 'CANCELLED')})")
    except APIError as exc:
        error_console.print(f"[red]Cancel failed:[/red] {exc}")
        raise click.Abort() from exc


@pipeline.command(name="delete")
@click.argument("pipeline_id")
@click.confirmation_option(prompt="Delete this pipeline?")
@verbose_option
def delete_cmd(pipeline_id):
    """Delete a pipeline."""
    client = APIClient()
    try:
        client.delete_pipeline(pipeline_id)
        console.print(f"[green]Deleted[/green] {pipeline_id}")
    except APIError as exc:
        error_console.print(f"[red]Delete failed:[/red] {exc}")
        raise click.Abort() from exc
