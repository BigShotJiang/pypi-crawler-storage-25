"""
Shared CLI utilities, console, and common options.
"""

from __future__ import annotations

import logging
import os
import subprocess
import sys
from contextlib import contextmanager

import click
from rich.console import Console

console = Console()
error_console = Console(stderr=True)

VERBOSE_MODE = False
_VERBOSE_INITIALIZED = False


def _enable_verbose(ctx: click.Context | None = None):
    """Turn on verbose logging globally and remember the state."""
    global VERBOSE_MODE, _VERBOSE_INITIALIZED
    VERBOSE_MODE = True
    if ctx is not None:
        ctx.ensure_object(dict)
        ctx.obj["verbose"] = True

    if not _VERBOSE_INITIALIZED:
        logging.basicConfig(level=logging.DEBUG)
        _VERBOSE_INITIALIZED = True
        console.log("Verbose mode enabled")

    logging.getLogger().setLevel(logging.DEBUG)


def _ensure_verbose(ctx: click.Context | None = None):
    """Apply verbose mode when previously enabled on the parent context."""
    if ctx is None:
        return
    ctx.ensure_object(dict)
    if ctx.obj.get("verbose"):
        _enable_verbose(ctx)


def _handle_command_verbose(ctx: click.Context, _param: click.Option, value: bool):
    if value:
        _enable_verbose(ctx)
    return value


def verbose_option(command):
    """Decorator to add --verbose flag to commands."""
    return click.option(
        "--verbose",
        is_flag=True,
        expose_value=False,
        is_eager=True,
        help="Enable verbose logging output for troubleshooting",
        callback=_handle_command_verbose,
    )(command)


@contextmanager
def temporary_environment(env: str | None):
    if not env:
        yield
        return

    from ..config import Config

    previous_compass_env = os.environ.get("HLA_COMPASS_ENV")
    had_compass_env = "HLA_COMPASS_ENV" in os.environ
    previous_legacy_env = os.environ.get("HLA_ENV")
    had_legacy_env = "HLA_ENV" in os.environ
    previous_api_endpoint = os.environ.get("HLA_API_ENDPOINT")
    had_api_endpoint = "HLA_API_ENDPOINT" in os.environ
    previous_legacy_api_endpoint = os.environ.get("API_ENDPOINT")
    had_legacy_api_endpoint = "API_ENDPOINT" in os.environ

    Config.set_environment(env)
    os.environ.pop("HLA_ENV", None)
    if not had_api_endpoint and not had_legacy_api_endpoint:
        selected_endpoint = Config.get_api_endpoint_for_environment(env)
        if selected_endpoint:
            os.environ["HLA_API_ENDPOINT"] = selected_endpoint

    try:
        yield
    finally:
        if had_compass_env:
            os.environ["HLA_COMPASS_ENV"] = previous_compass_env if previous_compass_env is not None else ""
        else:
            os.environ.pop("HLA_COMPASS_ENV", None)

        if had_legacy_env:
            os.environ["HLA_ENV"] = previous_legacy_env if previous_legacy_env is not None else ""
        else:
            os.environ.pop("HLA_ENV", None)

        if had_api_endpoint:
            os.environ["HLA_API_ENDPOINT"] = previous_api_endpoint if previous_api_endpoint is not None else ""
        else:
            os.environ.pop("HLA_API_ENDPOINT", None)

        if had_legacy_api_endpoint:
            os.environ["API_ENDPOINT"] = (
                previous_legacy_api_endpoint if previous_legacy_api_endpoint is not None else ""
            )
        else:
            os.environ.pop("API_ENDPOINT", None)


def suggest_doctor() -> None:
    """Print a hint to run 'hla-compass doctor' after an error."""
    error_console.print("\n[dim]Tip: Run 'hla-compass doctor' to diagnose environment issues.[/dim]")


def ensure_docker_available() -> None:
    try:
        subprocess.run(
            ["docker", "version"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
        )
    except FileNotFoundError:
        console.print("[red]Docker CLI not found. Install Docker to continue.[/red]")
        sys.exit(1)
    except subprocess.CalledProcessError as exc:
        console.print("[red]Docker is not available:[/red]")
        console.print(exc.stderr.decode("utf-8") if exc.stderr else "")
        sys.exit(exc.returncode)
