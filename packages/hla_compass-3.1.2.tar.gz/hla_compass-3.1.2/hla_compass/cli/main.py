import logging

import click

from .._version import __version__
from .auth import auth
from .dev import dev, run, serve, test
from .doctor import doctor
from .mcp import mcp
from .module import build, init, validate
from .modules_cli import modules
from .pipelines_cli import pipeline
from .publish import publish, publish_status, sign_image, verify_image
from .runs import runs
from .utils import _enable_verbose


@click.group()
@click.version_option(version=__version__)
@click.option("--verbose", is_flag=True, help="Enable verbose logging")
@click.pass_context
def cli(ctx, verbose):
    """HLA-Compass SDK — build, test, and publish analysis modules.

    \b
    Quick start:
      hla-compass init my-module     Create a new module
      hla-compass test               Run module tests
      hla-compass publish --env dev  Publish to the platform
    """
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose
    if verbose:
        _enable_verbose(ctx)
    else:
        logging.getLogger().setLevel(logging.INFO)

    # Non-blocking version check (cached, once per 24h)
    from .utils import console
    from .version_check import check_version

    check_version(console=console)


# Register Auth commands
cli.add_command(auth)

# Register Module commands
cli.add_command(init)
cli.add_command(publish)
cli.add_command(publish_status)
cli.add_command(sign_image)
cli.add_command(verify_image)
cli.add_command(validate)

# Internal build command — used by dev/serve/test, hidden from --help
build.hidden = True
cli.add_command(build)

# Register Dev commands
cli.add_command(dev)
cli.add_command(serve)
cli.add_command(test)
cli.add_command(run)
cli.add_command(runs)

# Register Platform Module Commands
cli.add_command(modules)

# Register Pipeline commands
cli.add_command(pipeline)

# Register diagnostics
cli.add_command(doctor)

# Register MCP integration
cli.add_command(mcp)


def main():
    cli()


if __name__ == "__main__":
    main()
