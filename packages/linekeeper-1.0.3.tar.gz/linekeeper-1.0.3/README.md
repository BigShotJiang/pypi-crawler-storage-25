# 🧵 LineKeeper

> **Preserve line numbers when working with AI** | **Preserva la numeración de líneas cuando trabajas con IA**

[![PyPI version](https://img.shields.io/pypi/v/linekeeper.svg)](https://pypi.org/project/linekeeper/)
[![Python versions](https://img.shields.io/pypi/pyversions/linekeeper.svg)](https://pypi.org/project/linekeeper/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## 🌐 Language / Idioma

| [🇬🇧 English](#english) | [🇪🇸 Español](#español) | [🇫🇷 Français](#français) | [🇨🇳 中文](#中文) | [🇩🇪 Deutsch](#deutsch) | [🇯🇵 日本語](#日本語) |
|------------------------|------------------------|--------------------------|------------------|------------------------|----------------------|

---

## English

**Preserve line numbers when working with AI**

### 🔴 The Problem

When you copy code to DeepSeek, ChatGPT, or Claude, the AI loses track of exact line numbers. This causes frustration when the AI says *"on line 35"* but actually means a different line.

### 🟢 The Solution

LineKeeper adds explicit `[L001]`, `[L002]` markers to each line of your code.

**Before:**
```
Coffee
Pepper
Book
```

**After:**
```
[L001] Coffee
[L002] Pepper
[L003] Book
```

Now the AI can refer to `[L002]` and you know **exactly** which line it means.

### 📦 Installation

```bash
# Install the latest version
pip install linekeeper

# Upgrade to the latest version (if already installed)
pip install linekeeper --upgrade
```

### 🚀 Quick Start

```bash
# Number a file and display
linekeeper myfile.txt

# Number a file and copy to clipboard
linekeeper myfile.txt --clipboard

# Read from clipboard, add line numbers
linekeeper --clipboard

# Clean AI response (remove [Lxxx] markers)
linekeeper --limpiar --clipboard

# Save result to file
linekeeper myfile.txt --salida output.txt

# Show version
linekeeper --version

# Help
linekeeper --help
```

### ✨ Features

- ✅ **Multi-language** (English, Spanish, French, Chinese, German, Japanese)
- ✅ **Clipboard support** (copy and paste)
- ✅ **Save to file**
- ✅ **Clean AI responses**
- ✅ **Preserves empty lines**
- ✅ **Custom starting line number** (`--inicio`)

### 📖 Example

```bash
$ echo "Hello World" > test.txt
$ linekeeper test.txt
[L001] Hello World
```

---

## Español

**Preserva la numeración de líneas cuando trabajas con IA**

### 🔴 El Problema

Cuando copias código a DeepSeek, ChatGPT o Claude, la IA pierde la referencia exacta de las líneas. Esto causa frustración cuando la IA dice *"en la línea 35"* pero en realidad se refiere a otra línea.

### 🟢 La Solución

LineKeeper añade marcadores explícitos `[L001]`, `[L002]` al inicio de cada línea.

**Antes:**
```
Café
Pimienta
Libro
```

**Después:**
```
[L001] Café
[L002] Pimienta
[L003] Libro
```

Ahora la IA puede referirse a `[L002]` y tú sabes **exactamente** qué línea es.

### 📦 Instalación

```bash
# Instalar la última versión
pip install linekeeper

# Actualizar a la última versión (si ya está instalada)
pip install linekeeper --upgrade
```

### 🚀 Inicio Rápido

```bash
# Numerar archivo y mostrar
linekeeper miarchivo.txt

# Numerar archivo y copiar al portapapeles
linekeeper miarchivo.txt --clipboard

# Leer del portapapeles y numerar
linekeeper --clipboard

# Limpiar respuesta de IA (eliminar [Lxxx])
linekeeper --limpiar --clipboard

# Guardar resultado en archivo
linekeeper miarchivo.txt --salida salida.txt

# Ver versión
linekeeper --version

# Ayuda
linekeeper --help
```

### ✨ Características

- ✅ **Multi-idioma** (Español, Inglés, Francés, Chino, Alemán, Japonés)
- ✅ **Soporte para portapapeles** (copiar y pegar)
- ✅ **Guardar en archivo**
- ✅ **Limpiar respuestas de IA**
- ✅ **Preserva líneas vacías**
- ✅ **Número de línea inicial personalizable** (`--inicio`)

### 📖 Ejemplo

```bash
$ echo "Hola Mundo" > test.txt
$ linekeeper test.txt
[L001] Hola Mundo
```

---

## Français

**Préservez les numéros de ligne lors de vos échanges avec l'IA**

### 🔴 Le Problème

Lorsque vous copiez du code vers DeepSeek, ChatGPT ou Claude, l'IA perd la trace des numéros de ligne exacts. Cela cause de la frustration quand l'IA dit *"à la ligne 35"* mais veut en réalité dire une ligne différente.

### 🟢 La Solution

LineKeeper ajoute des balises explicites `[L001]`, `[L002]` au début de chaque ligne.

**Avant:**
```
Café
Poivre
Livre
```

**Après:**
```
[L001] Café
[L002] Poivre
[L003] Livre
```

Maintenant, l'IA peut faire référence à `[L002]` et vous savez **exactement** de quelle ligne il s'agit.

### 📦 Installation

```bash
# Installer la dernière version
pip install linekeeper

# Mettre à jour vers la dernière version
pip install linekeeper --upgrade
```

### 🚀 Utilisation Rapide

```bash
# Numéroter un fichier et afficher
linekeeper monfichier.txt

# Numéroter un fichier et copier dans le presse-papier
linekeeper monfichier.txt --clipboard

# Lire depuis le presse-papier et numéroter
linekeeper --clipboard

# Nettoyer la réponse de l'IA (supprimer [Lxxx])
linekeeper --limpiar --clipboard

# Sauvegarder le résultat dans un fichier
linekeeper monfichier.txt --salida sortie.txt

# Afficher la version
linekeeper --version

# Aide
linekeeper --help
```

### ✨ Fonctionnalités

- ✅ **Multi-langue** (Français, Anglais, Espagnol, Chinois, Allemand, Japonais)
- ✅ **Support du presse-papier**
- ✅ **Sauvegarde dans un fichier**
- ✅ **Nettoyage des réponses IA**
- ✅ **Préserve les lignes vides**
- ✅ **Numéro de ligne initial personnalisable** (`--inicio`)

### 📖 Exemple

```bash
$ echo "Bonjour le monde" > test.txt
$ linekeeper test.txt
[L001] Bonjour le monde
```

---

## 中文

**与 AI 协作时保留行号**

### 🔴 问题

当您将代码复制到 DeepSeek、ChatGPT 或 Claude 时，AI 会丢失准确的行号。当 AI 说*"在第 35 行"*时，实际上可能指的是另一行，这会造成困扰。

### 🟢 解决方案

LineKeeper 为每一行代码添加显式的 `[L001]`、`[L002]` 标记。

**之前:**
```
咖啡
胡椒
书
```

**之后:**
```
[L001] 咖啡
[L002] 胡椒
[L003] 书
```

现在 AI 可以引用 `[L002]`，您就能**精确**知道它指的是哪一行。

### 📦 安装

```bash
# 安装最新版本
pip install linekeeper

# 升级到最新版本
pip install linekeeper --upgrade
```

### 🚀 快速开始

```bash
# 为文件添加行号并显示
linekeeper 我的文件.txt

# 添加行号并复制到剪贴板
linekeeper 我的文件.txt --clipboard

# 从剪贴板读取并添加行号
linekeeper --clipboard

# 清理 AI 响应（删除 [Lxxx] 标记）
linekeeper --limpiar --clipboard

# 保存结果到文件
linekeeper 我的文件.txt --salida 输出.txt

# 显示版本
linekeeper --version

# 帮助
linekeeper --help
```

### ✨ 功能

- ✅ **多语言支持**（中文、英语、西班牙语、法语、德语、日语）
- ✅ **剪贴板支持**
- ✅ **保存到文件**
- ✅ **清理 AI 响应**
- ✅ **保留空行**
- ✅ **自定义起始行号**（`--inicio`）

### 📖 示例

```bash
$ echo "你好世界" > test.txt
$ linekeeper test.txt
[L001] 你好世界
```

---

## Deutsch

**Behalten Sie Zeilennummern bei der Arbeit mit KI**

### 🔴 Das Problem

Wenn Sie Code zu DeepSeek, ChatGPT oder Claude kopieren, verliert die KI den Überblick über die genauen Zeilennummern. Das führt zu Frustration, wenn die KI *"in Zeile 35"* sagt, aber tatsächlich eine andere Zeile meint.

### 🟢 Die Lösung

LineKeeper fügt explizite Markierungen `[L001]`, `[L002]` am Anfang jeder Zeile hinzu.

**Vorher:**
```
Kaffee
Pfeffer
Buch
```

**Nachher:**
```
[L001] Kaffee
[L002] Pfeffer
[L003] Buch
```

Jetzt kann sich die KI auf `[L002]` beziehen und Sie wissen **genau**, welche Zeile gemeint ist.

### 📦 Installation

```bash
# Installieren Sie die neueste Version
pip install linekeeper

# Aktualisieren Sie auf die neueste Version
pip install linekeeper --upgrade
```

### 🚀 Schnellstart

```bash
# Datei nummerieren und anzeigen
linekeeper meinedatei.txt

# Datei nummerieren und in Zwischenablage kopieren
linekeeper meinedatei.txt --clipboard

# Aus Zwischenablage lesen und nummerieren
linekeeper --clipboard

# KI-Antwort bereinigen ([Lxxx] entfernen)
linekeeper --limpiar --clipboard

# Ergebnis in Datei speichern
linekeeper meinedatei.txt --salida ausgabe.txt

# Version anzeigen
linekeeper --version

# Hilfe
linekeeper --help
```

### ✨ Funktionen

- ✅ **Mehrsprachig** (Deutsch, Englisch, Spanisch, Französisch, Chinesisch, Japanisch)
- ✅ **Zwischenablage-Unterstützung**
- ✅ **In Datei speichern**
- ✅ **KI-Antworten bereinigen**
- ✅ **Leerzeilen erhalten**
- ✅ **Benutzerdefinierte Startzeilennummer** (`--inicio`)

### 📖 Beispiel

```bash
$ echo "Hallo Welt" > test.txt
$ linekeeper test.txt
[L001] Hallo Welt
```

---

## 日本語

**AIとの作業で行番号を保持**

### 🔴 問題

コードを DeepSeek、ChatGPT、Claude にコピーすると、AI は正確な行番号を見失います。AI が*「35行目」*と言っても、実際には別の行を指していることがあり、混乱を招きます。

### 🟢 解決策

LineKeeper は、各行の先頭に `[L001]`、`[L002]` のような明示的なマーカーを追加します。

**前:**
```
コーヒー
胡椒
本
```

**後:**
```
[L001] コーヒー
[L002] 胡椒
[L003] 本
```

AI は `[L002]` を参照できるようになり、どの行を指しているか**正確に**わかります。

### 📦 インストール

```bash
# 最新バージョンをインストール
pip install linekeeper

# 最新バージョンにアップグレード
pip install linekeeper --upgrade
```

### 🚀 クイックスタート

```bash
# ファイルに行番号を追加して表示
linekeeper 私のファイル.txt

# 行番号を追加してクリップボードにコピー
linekeeper 私のファイル.txt --clipboard

# クリップボードから読み込んで行番号を追加
linekeeper --clipboard

# AIの応答をクリーンアップ（[Lxxx]を削除）
linekeeper --limpiar --clipboard

# 結果をファイルに保存
linekeeper 私のファイル.txt --salida 出力.txt

# バージョン表示
linekeeper --version

# ヘルプ
linekeeper --help
```

### ✨ 機能

- ✅ **多言語対応**（日本語、英語、スペイン語、フランス語、中国語、ドイツ語）
- ✅ **クリップボードサポート**
- ✅ **ファイルに保存**
- ✅ **AI応答をクリーンアップ**
- ✅ **空行を保持**
- ✅ **開始行番号をカスタマイズ**（`--inicio`）

### 📖 例

```bash
$ echo "こんにちは世界" > test.txt
$ linekeeper test.txt
[L001] こんにちは世界
```

---

## 📄 License

**MIT © 2026 Renzos666**

## 🔗 Links

| Platform | Link |
|----------|------|
| **PyPI** | [https://pypi.org/project/linekeeper/](https://pypi.org/project/linekeeper/) |
| **GitHub** | [https://github.com/Renzos666/LineKeeper](https://github.com/Renzos666/LineKeeper) |

---

## ⭐ Support

If you find this project useful, please consider giving it a star on GitHub!

Si encuentras útil este proyecto, ¡considera darle una estrella en GitHub!
