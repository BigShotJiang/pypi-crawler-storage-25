#!/usr/bin/env python3
"""
LineKeeper - Preserva la numeración de líneas cuando trabajas con IA
LineKeeper - Preserve line numbers when working with AI

Uso / Usage:
    python linekeeper.py archivo.cs
    python linekeeper.py archivo.cs --clipboard
    python linekeeper.py --clipboard
    python linekeeper.py --idioma es
"""

import sys
import re
import argparse
import locale

try:
    import pyperclip
except ImportError:
    pyperclip = None

# ============================================================
# TRADUCCIONES / TRANSLATIONS
# ============================================================

MENSAJES = {
    'es': {
        'nombre': "Español",
        'clipboard_leer': "📋 Texto obtenido del portapapeles",
        'clipboard_copiar': "📋 Resultado copiado al portapapeles",
        'archivo_ok': "📄 Archivo cargado: {}",
        'stdin_ok': "📥 Texto desde stdin",
        'error_sin_texto': "❌ Error: No se proporcionó texto. Usa --help para ayuda.",
        'error_pyperclip': "❌ Error: pyperclip no instalado. Ejecuta: pip install pyperclip",
        'error_archivo': "❌ Error: No se encuentra el archivo '{}'",
        'guardado_exito': "✅ Resultado guardado en {}",
        'estadisticas': "\n📊 Estadísticas:",
        'lineas_originales': "   - Líneas originales: {}",
        'lineas_marcadas': "   - Líneas con marcador: {}",
        'rango': "   - Rango: {} - {}",
        'respuesta_limpia': "✅ Respuesta limpia guardada en {}",
        'modo_limpiar': "🧹 Modo limpiar activado",
        'ayuda_titulo': "LineKeeper - Preserva líneas para IA",
        'ayuda_ejemplos': "Ejemplos:\n  linekeeper mi_codigo.py\n  linekeeper mi_codigo.py -c\n  linekeeper -c"
    },
    'en': {
        'nombre': "English",
        'clipboard_leer': "📋 Text obtained from clipboard",
        'clipboard_copiar': "📋 Result copied to clipboard",
        'archivo_ok': "📄 File loaded: {}",
        'stdin_ok': "📥 Text from stdin",
        'error_sin_texto': "❌ Error: No text provided. Use --help for help.",
        'error_pyperclip': "❌ Error: pyperclip not installed. Run: pip install pyperclip",
        'error_archivo': "❌ Error: File '{}' not found",
        'guardado_exito': "✅ Result saved to {}",
        'estadisticas': "\n📊 Statistics:",
        'lineas_originales': "   - Original lines: {}",
        'lineas_marcadas': "   - Lines with markers: {}",
        'rango': "   - Range: {} - {}",
        'respuesta_limpia': "✅ Clean response saved to {}",
        'modo_limpiar': "🧹 Clean mode activated",
        'ayuda_titulo': "LineKeeper - Preserve lines for AI",
        'ayuda_ejemplos': "Examples:\n  linekeeper my_code.py\n  linekeeper my_code.py -c\n  linekeeper -c"
    },
    'fr': {
        'nombre': "Français",
        'clipboard_leer': "📋 Texte obtenu du presse-papier",
        'clipboard_copiar': "📋 Résultat copié dans le presse-papier",
        'archivo_ok': "📄 Fichier chargé : {}",
        'stdin_ok': "📥 Texte depuis stdin",
        'error_sin_texto': "❌ Erreur : Aucun texte fourni. Utilisez --help pour obtenir de l'aide.",
        'error_pyperclip': "❌ Erreur : pyperclip non installé. Exécutez : pip install pyperclip",
        'error_archivo': "❌ Erreur : Fichier '{}' introuvable",
        'guardado_exito': "✅ Résultat enregistré dans {}",
        'estadisticas': "\n📊 Statistiques :",
        'lineas_originales': "   - Lignes originales : {}",
        'lineas_marcadas': "   - Lignes avec marqueurs : {}",
        'rango': "   - Plage : {} - {}",
        'respuesta_limpia': "✅ Réponse nettoyée enregistrée dans {}",
        'modo_limpiar': "🧹 Mode nettoyage activé",
        'ayuda_titulo': "LineKeeper - Préserve les lignes pour l'IA",
        'ayuda_ejemplos': "Exemples :\n  linekeeper mon_code.py\n  linekeeper mon_code.py -c\n  linekeeper -c"
    },
    'zh': {
        'nombre': "中文",
        'clipboard_leer': "📋 从剪贴板获取文本",
        'clipboard_copiar': "📋 结果已复制到剪贴板",
        'archivo_ok': "📄 已加载文件: {}",
        'stdin_ok': "📥 从标准输入读取文本",
        'error_sin_texto': "❌ 错误: 未提供文本。使用 --help 查看帮助",
        'error_pyperclip': "❌ 错误: 未安装 pyperclip。运行: pip install pyperclip",
        'error_archivo': "❌ 错误: 找不到文件 '{}'",
        'guardado_exito': "✅ 结果已保存到 {}",
        'estadisticas': "\n📊 统计信息:",
        'lineas_originales': "   - 原始行数: {}",
        'lineas_marcadas': "   - 带标记的行数: {}",
        'rango': "   - 范围: {} - {}",
        'respuesta_limpia': "✅ 清理后的响应已保存到 {}",
        'modo_limpiar': "🧹 清洁模式已激活",
        'ayuda_titulo': "LineKeeper - 为AI保留行号",
        'ayuda_ejemplos': "示例:\n  linekeeper my_code.py\n  linekeeper my_code.py -c\n  linekeeper -c"
    },
    'de': {
        'nombre': "Deutsch",
        'clipboard_leer': "📋 Text aus der Zwischenablage",
        'clipboard_copiar': "📋 Ergebnis in die Zwischenablage kopiert",
        'archivo_ok': "📄 Datei geladen: {}",
        'stdin_ok': "📥 Text von stdin",
        'error_sin_texto': "❌ Fehler: Kein Text angegeben. Verwenden Sie --help für Hilfe.",
        'error_pyperclip': "❌ Fehler: pyperclip nicht installiert. Führen Sie aus: pip install pyperclip",
        'error_archivo': "❌ Fehler: Datei '{}' nicht gefunden",
        'guardado_exito': "✅ Ergebnis gespeichert in {}",
        'estadisticas': "\n📊 Statistiken:",
        'lineas_originales': "   - Ursprüngliche Zeilen: {}",
        'lineas_marcadas': "   - Zeilen mit Markierungen: {}",
        'rango': "   - Bereich: {} - {}",
        'respuesta_limpia': "✅ Bereinigte Antwort gespeichert in {}",
        'modo_limpiar': "🧹 Bereinigungsmodus aktiviert",
        'ayuda_titulo': "LineKeeper - Zeilen für KI bewahren",
        'ayuda_ejemplos': "Beispiele:\n  linekeeper meine_datei.py\n  linekeeper meine_datei.py -c\n  linekeeper -c"
    },
    'ja': {
        'nombre': "日本語",
        'clipboard_leer': "📋 クリップボードからテキストを取得しました",
        'clipboard_copiar': "📋 結果をクリップボードにコピーしました",
        'archivo_ok': "📄 ファイルを読み込みました: {}",
        'stdin_ok': "📥 標準入力からテキストを読み込みました",
        'error_sin_texto': "❌ エラー: テキストが提供されていません。--help でヘルプを表示",
        'error_pyperclip': "❌ エラー: pyperclip がインストールされていません。実行: pip install pyperclip",
        'error_archivo': "❌ エラー: ファイル '{}' が見つかりません",
        'guardado_exito': "✅ 結果を {} に保存しました",
        'estadisticas': "\n📊 統計:",
        'lineas_originales': "   - 元の行数: {}",
        'lineas_marcadas': "   - マーカー付き行数: {}",
        'rango': "   - 範囲: {} - {}",
        'respuesta_limpia': "✅  cleaned response saved to {}",
        'modo_limpiar': "🧹 クリーンモードがアクティブになりました",
        'ayuda_titulo': "LineKeeper - AIのための行番号保持",
        'ayuda_ejemplos': "例:\n  linekeeper my_code.py\n  linekeeper my_code.py -c\n  linekeeper -c"
    }
}

# Idiomas soportados (códigos ISO 639-1)
IDIOMAS_SOPORTADOS = ['es', 'en', 'fr', 'zh', 'de', 'ja']

def detectar_idioma():
    """Detecta el idioma del sistema automáticamente"""
    try:
        idioma_sistema = locale.getdefaultlocale()[0]
        if idioma_sistema:
            # Extraer código base (ej: 'es_ES' -> 'es')
            codigo_base = idioma_sistema.split('_')[0].lower()
            if codigo_base in IDIOMAS_SOPORTADOS:
                return codigo_base
        return 'en'  # Inglés por defecto
    except:
        return 'en'

def obtener_mensaje(idioma, clave):
    """Obtiene un mensaje en el idioma especificado"""
    if idioma in MENSAJES and clave in MENSAJES[idioma]:
        return MENSAJES[idioma][clave]
    # Fallback a inglés
    return MENSAJES['en'].get(clave, f"[MISSING:{clave}]")

# ============================================================
# FUNCIONES PRINCIPALES
# ============================================================

def numerar_lineas(texto: str, inicio: int = 1, solo_no_vacias: bool = True) -> str:
    """
    Añade marcadores [Lxxx] al inicio de cada línea.
    
    Args:
        texto: Texto a procesar
        inicio: Número de la primera línea
        solo_no_vacias: Si True, las líneas vacías no reciben marcador
    
    Returns:
        Texto con marcadores de línea
    """
    # Preservar el tipo de salto de línea original
    if '\r\n' in texto:
        salto = '\r\n'
        lineas = texto.split('\r\n')
    else:
        salto = '\n'
        lineas = texto.split('\n')
    
    resultado = []
    for i, linea in enumerate(lineas, start=inicio):
        if solo_no_vacias and linea == "":
            resultado.append("")
        else:
            resultado.append(f"[L{i:03d}] {linea}")
    
    # Preservar líneas vacías al final
    return salto.join(resultado)

def extraer_referencias(respuesta: str) -> list:
    """Extrae todas las referencias a [Lxxx] de la respuesta de IA."""
    patron = r'\[L(\d{3,})\]'
    return re.findall(patron, respuesta)

def limpiar_respuesta(respuesta: str) -> str:
    """
    Elimina los marcadores [Lxxx] de la respuesta para lectura limpia.
    También elimina líneas vacías que queden después de eliminar los marcadores.
    """
    # Eliminar [Lxxx] (con posible espacio después)
    resultado = re.sub(r'\[L\d{2,}\]\s?', '', respuesta)
    # Normalizar saltos de línea a \n
    resultado = resultado.replace('\r\n', '\n').replace('\r', '\n')
    # Eliminar líneas completamente vacías
    lineas = resultado.split('\n')
    lineas_limpias = [linea for linea in lineas if linea.strip() != ""]
    return '\n'.join(lineas_limpias)
    
def main():
    # Detectar idioma automáticamente
    idioma = detectar_idioma()
    
    parser = argparse.ArgumentParser(
        description=obtener_mensaje(idioma, 'ayuda_titulo'),
        epilog=obtener_mensaje(idioma, 'ayuda_ejemplos')
    )
    
    parser.add_argument("archivo", nargs="?", help=("Archivo a procesar" if idioma == 'es' else "File to process"))
    parser.add_argument("--version", action="version", version="LineKeeper 1.0.3",
                    help=("Mostrar versión del programa" if idioma == 'es' else "Show program version"))
    parser.add_argument("--clipboard", "-c", action="store_true", 
                        help=("Copiar resultado al portapapeles (si hay archivo) o leer desde portapapeles (si no hay archivo)" if idioma == 'es' else "Copy result to clipboard (if file) or read from clipboard (if no file)"))
    parser.add_argument("--inicio", "-i", type=int, default=1, 
                        help=("Número de línea inicial (default: 1)" if idioma == 'es' else "Starting line number (default: 1)"))
    parser.add_argument("--limpiar", "-l", action="store_true",
                        help=("Limpiar respuesta de IA (eliminar [Lxxx])" if idioma == 'es' else "Clean AI response (remove [Lxxx])"))
    parser.add_argument("--salida", "-s", help=("Guardar resultado en archivo" if idioma == 'es' else "Save result to file"))
    parser.add_argument("--incluir-vacias", "-v", action="store_true",
                        help=("Incluir marcadores en líneas vacías" if idioma == 'es' else "Include markers on empty lines"))
    parser.add_argument("--idioma", choices=IDIOMAS_SOPORTADOS,
                        help=("Forzar idioma (es/en/fr/zh/de/ja)" if idioma == 'es' else "Force language (es/en/fr/zh/de/ja)"))
    
    args = parser.parse_args()
    
    # Sobrescribir idioma si se especifica --idioma
    if args.idioma:
        idioma = args.idioma
    
    # Verificar pyperclip si se necesita
    if args.clipboard and not pyperclip:
        print(obtener_mensaje(idioma, 'error_pyperclip'), file=sys.stderr)
        sys.exit(1)
    
    # Modo limpiar: recibe respuesta de IA y la limpia
    if args.limpiar:
        print(obtener_mensaje(idioma, 'modo_limpiar'), file=sys.stderr)
        
        # Si se usa --clipboard, leer del portapapeles
        if args.clipboard:
            if not pyperclip:
                print(obtener_mensaje(idioma, 'error_pyperclip'), file=sys.stderr)
                sys.exit(1)
            texto = pyperclip.paste()
            print(obtener_mensaje(idioma, 'clipboard_leer'), file=sys.stderr)
        else:
            # Si hay datos en stdin (pipe o redirección), usarlos
            if not sys.stdin.isatty():
                texto = sys.stdin.read()
            else:
                # Fallback: pedir al usuario que pegue
                texto = input("Pega la respuesta de IA: ")
        
        texto_limpio = limpiar_respuesta(texto)
        
        if args.salida:
            with open(args.salida, "w", encoding="utf-8") as f:
                f.write(texto_limpio)
            print(obtener_mensaje(idioma, 'respuesta_limpia').format(args.salida))
        else:
            print(texto_limpio)
        return
    
    # Caso 1: Hay archivo y --clipboard -> leer archivo, numerar, COPIAR al portapapeles
    if args.archivo and args.clipboard:
        # Leer archivo
        try:
            with open(args.archivo, "r", encoding="utf-8") as f:
                texto = f.read()
            print(obtener_mensaje(idioma, 'archivo_ok').format(args.archivo), file=sys.stderr)
        except FileNotFoundError:
            print(obtener_mensaje(idioma, 'error_archivo').format(args.archivo), file=sys.stderr)
            sys.exit(1)
        
        # Numerar líneas
        texto_numerado = numerar_lineas(texto, args.inicio, not args.incluir_vacias)
        
        # Copiar al portapapeles
        pyperclip.copy(texto_numerado)
        print(obtener_mensaje(idioma, 'clipboard_copiar'), file=sys.stderr)
        
        # Mostrar estadísticas
        if sys.stdout.isatty():
            lineas_originales = len(texto.splitlines())
            lineas_marcadas = len(texto_numerado.splitlines())
            print(obtener_mensaje(idioma, 'estadisticas'), file=sys.stderr)
            print(obtener_mensaje(idioma, 'lineas_originales').format(lineas_originales), file=sys.stderr)
            print(obtener_mensaje(idioma, 'lineas_marcadas').format(lineas_marcadas), file=sys.stderr)
            print(obtener_mensaje(idioma, 'rango').format(f"L{args.inicio:03d}", f"L{args.inicio + lineas_originales - 1:03d}"), file=sys.stderr)
        
        # No mostrar el texto en pantalla (solo se copia)
        return
    
    # Caso 2: Solo --clipboard (sin archivo) -> leer del portapapeles, numerar, mostrar en pantalla
    if args.clipboard and not args.archivo:
        texto = pyperclip.paste()
        print(obtener_mensaje(idioma, 'clipboard_leer'), file=sys.stderr)
        
        texto_numerado = numerar_lineas(texto, args.inicio, not args.incluir_vacias)
        
        # Mostrar en pantalla
        print(texto_numerado)
        
        # Mostrar estadísticas
        if sys.stdout.isatty():
            lineas_originales = len(texto.splitlines())
            lineas_marcadas = len(texto_numerado.splitlines())
            print(obtener_mensaje(idioma, 'estadisticas'), file=sys.stderr)
            print(obtener_mensaje(idioma, 'lineas_originales').format(lineas_originales), file=sys.stderr)
            print(obtener_mensaje(idioma, 'lineas_marcadas').format(lineas_marcadas), file=sys.stderr)
            print(obtener_mensaje(idioma, 'rango').format(f"L{args.inicio:03d}", f"L{args.inicio + lineas_originales - 1:03d}"), file=sys.stderr)
        return
    
    # Caso 3: Solo archivo (sin --clipboard) -> leer archivo, numerar, mostrar en pantalla
    if args.archivo and not args.clipboard:
        try:
            with open(args.archivo, "r", encoding="utf-8") as f:
                texto = f.read()
            print(obtener_mensaje(idioma, 'archivo_ok').format(args.archivo), file=sys.stderr)
        except FileNotFoundError:
            print(obtener_mensaje(idioma, 'error_archivo').format(args.archivo), file=sys.stderr)
            sys.exit(1)
        
        texto_numerado = numerar_lineas(texto, args.inicio, not args.incluir_vacias)
        
        # Salida
        if args.salida:
            with open(args.salida, "w", encoding="utf-8") as f:
                f.write(texto_numerado)
            print(obtener_mensaje(idioma, 'guardado_exito').format(args.salida), file=sys.stderr)
        else:
            print(texto_numerado)
        
        # Mostrar estadísticas
        if sys.stdout.isatty():
            lineas_originales = len(texto.splitlines())
            lineas_marcadas = len(texto_numerado.splitlines())
            print(obtener_mensaje(idioma, 'estadisticas'), file=sys.stderr)
            print(obtener_mensaje(idioma, 'lineas_originales').format(lineas_originales), file=sys.stderr)
            print(obtener_mensaje(idioma, 'lineas_marcadas').format(lineas_marcadas), file=sys.stderr)
            print(obtener_mensaje(idioma, 'rango').format(f"L{args.inicio:03d}", f"L{args.inicio + lineas_originales - 1:03d}"), file=sys.stderr)
        return
    
    # Caso 4: Ni archivo ni --clipboard -> leer desde stdin (pipe)
    texto = sys.stdin.read()
    if not texto.strip():
        print(obtener_mensaje(idioma, 'error_sin_texto'), file=sys.stderr)
        sys.exit(1)
    print(obtener_mensaje(idioma, 'stdin_ok'), file=sys.stderr)
    
    texto_numerado = numerar_lineas(texto, args.inicio, not args.incluir_vacias)
    
    if args.salida:
        with open(args.salida, "w", encoding="utf-8") as f:
            f.write(texto_numerado)
        print(obtener_mensaje(idioma, 'guardado_exito').format(args.salida), file=sys.stderr)
    else:
        print(texto_numerado)
    
    if sys.stdout.isatty():
        lineas_originales = len(texto.splitlines())
        lineas_marcadas = len(texto_numerado.splitlines())
        print(obtener_mensaje(idioma, 'estadisticas'), file=sys.stderr)
        print(obtener_mensaje(idioma, 'lineas_originales').format(lineas_originales), file=sys.stderr)
        print(obtener_mensaje(idioma, 'lineas_marcadas').format(lineas_marcadas), file=sys.stderr)
        print(obtener_mensaje(idioma, 'rango').format(f"L{args.inicio:03d}", f"L{args.inicio + lineas_originales - 1:03d}"), file=sys.stderr)

if __name__ == "__main__":
    main()