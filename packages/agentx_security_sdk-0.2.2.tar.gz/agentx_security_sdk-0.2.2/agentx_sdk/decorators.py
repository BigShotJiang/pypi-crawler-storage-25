import os
import json
import atexit
import time
import functools
import uuid
import requests
from contextvars import ContextVar

from .client import AgentXClient
from .db import init_db, log_intercept, get_lifetime_stats

_client = AgentXClient()

# Initialize the local SQLite DB on startup
init_db()

# --- 0. THE TRACE ID CONTEXT ---
trace_id_var: ContextVar[str] = ContextVar("trace_id", default="")

def start_secure_session():
    """Call this at the top of your agent script to group logs into a single session."""
    session_id = str(uuid.uuid4())
    trace_id_var.set(session_id)
    return session_id

# --- 1. THE SESSION TRACKER & EXIT SUMMARY ---
_session_stats = {
    "start_time": time.time(),
    "total_calls": 0,
    "intercepts": 0,
    "critical_blocks": 0,
    "self_corrections": 0,
    "last_call_was_challenge": False  # <-- Tracks the cognitive pivot state
}

def _print_agentx_summary():
    """Fires automatically when the developer's script ends or crashes."""
    
    # Only print if we actually did something this session to avoid terminal spam
    if _session_stats["total_calls"] == 0 and _session_stats["intercepts"] == 0:
        return
        
    duration = round(time.time() - _session_stats["start_time"], 2)
    session_tokens = _session_stats["intercepts"] * 1500
    session_time = _session_stats["intercepts"] * 5
    
    # Calculate the Hero Metric: Self-Correction Rate
    scr = 0
    if _session_stats["intercepts"] > 0:
        scr = round((_session_stats["self_corrections"] / _session_stats["intercepts"]) * 100, 1)
    
    # Fetch historical data
    try:
        history = get_lifetime_stats()
        if not history:
            raise ValueError("No history")
    except Exception:
        # Fallback if the local DB is fresh or errors out
        history = {
            "total_intercepts": _session_stats["intercepts"],
            "total_critical": _session_stats["critical_blocks"],
            "total_tokens": session_tokens,
            "total_time": session_time,
            "top_offender": None
        }
        
    print("\n" + "═"*60)
    print(f" 🛡️  AgentX Session Summary (Trace: {trace_id_var.get() or 'N/A'})")
    print("═"*60)
    print(f" ⏱️  Uptime:                {duration} seconds")
    print(f" 🛠️  Tools Monitored:       {_session_stats['total_calls']}")
    print("─"*60)
    
    # The Action-Oriented UI
    print(f" 🛑 Intercepts:            {_session_stats['intercepts']}   |  Cumulative: {history['total_intercepts']}")
    print(f" 💥 Critical Blocks:       {_session_stats['critical_blocks']}   |  Cumulative: {history['total_critical']}")
    print(f" 🔄 Self-Corrections:      {_session_stats['self_corrections']}   |  Recovery Rate: {scr}%")
    print(f" 💰 Tokens Saved:         ~{session_tokens}   |  Cumulative: ~{history['total_tokens']}")
    print(f" ⏳ Time Saved:           ~{session_time}s    |  Cumulative: ~{history['total_time']}s")
    
    # The 5+ Block Threshold for the Health Report
    if history.get('total_intercepts', 0) >= 5 and history.get('top_offender'):
        print("═"*60)
        print(" 🩺 AGENT HEALTH INSIGHT")
        print("─"*60)
        print(f" ⚠️  Top Offender: '{history['top_offender']}'")
        print(" 💡 Tip: Consider refining your agent's system prompt to avoid this.")
        
    print("═"*60 + "\n")

atexit.register(_print_agentx_summary)
# --------------------------

def agentx_protect(agent_id: str, extract_query_func=None, extract_cot_func=None):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            _session_stats["total_calls"] += 1
            
            # --- TRACE ID LOGIC ---
            current_trace_id = trace_id_var.get()
            if not current_trace_id:
                # Auto-start a session if the developer forgot to call start_secure_session()
                current_trace_id = start_secure_session()
            
            query = extract_query_func(*args, **kwargs) if extract_query_func else str(args)
            chain_of_thought = extract_cot_func(*args, **kwargs) if extract_cot_func else "Implicit tool call"
            receipt_id = kwargs.get("receipt_id", None)

            print(f"\n🛡️ [AgentX SDK] Intercepting tool call to '{func.__name__}'...")

            # =========================================================
            # OPTION 1: THE LOCAL MOCK TEST (Bypasses Live Backend)
            # =========================================================
            if os.environ.get("AGENTX_MOCK_MODE") == "true":
                if "DROP" in query.upper():
                    _session_stats["intercepts"] += 1
                    _session_stats["critical_blocks"] += 1
                    
                    # +++ SENSOR: Track that we challenged the agent
                    _session_stats["last_call_was_challenge"] = True
                    
                    mock_policy_id = "POL-SEC-001"
                    mock_policy_name = "Database Isolation"
                    
                    log_intercept(func.__name__, mock_policy_id, mock_policy_name, "CHALLENGED")
                    
                    print(f"🛑 [AgentX SDK] Policy '{mock_policy_name}' ({mock_policy_id}) violated.")
                    return json.dumps({
                        "error": "AgentX Policy Violation",
                        "challenge": "Policy Violation. Mass destructive intent detected. Explain your reasoning and provide a safer query.",
                        "receipt_id": "mock-receipt-123",
                        "instruction": "Revise your action to comply with the challenge and try again."
                    })
                else:
                    print(f"✅ [AgentX SDK] Intent safe (Mock). Executing '{func.__name__}'.")
                    
                    # +++ SENSOR: Check if this was a successful recovery!
                    if _session_stats.get("last_call_was_challenge"):
                        _session_stats["self_corrections"] += 1
                        _session_stats["last_call_was_challenge"] = False
                        
                    return func(*args, **kwargs)

            # =========================================================
            # OPTION 3: THE LIVE FASTAPI WEDGE CALL
            # =========================================================
            eval_res = _client.evaluate_intent(
                agent_id=agent_id, 
                query=query, 
                chain_of_thought=chain_of_thought,
                receipt_id=receipt_id,
                trace_id=current_trace_id
            )

            status = eval_res.get("status") if isinstance(eval_res, dict) else None

            # 1. Check for the Unified Gateway's Block Signal
            if isinstance(eval_res, dict) and eval_res.get("error") == "AgentX Policy Violation":
                _session_stats["intercepts"] += 1
                
                # +++ SENSOR: Track that we challenged the agent
                _session_stats["last_call_was_challenge"] = True
                
                actual_policy_id = eval_res.get("policy_id", "POL-UNKNOWN") 
                policy_name = eval_res.get("policy_triggered", "Unknown Policy")
                challenge_text = eval_res.get("challenge", "Policy violation detected. Please revise your intent.")
                returned_receipt_id = eval_res.get("receipt_id", "no-receipt")
                
                critical_policies = [
                    "Mass Destructive Intent", 
                    "Database Isolation", 
                    "Secrets and PII Exfiltration", 
                    "Out-of-Bounds Execution"
                ]
                
                if policy_name in critical_policies:
                    _session_stats["critical_blocks"] += 1

                log_intercept(func.__name__, actual_policy_id, policy_name, "CHALLENGED")

                print(f"🛑 [AgentX SDK] Policy '{policy_name}' violated. Returning challenge.")
                
                return json.dumps({
                    "error": "AgentX Policy Violation",
                    "challenge": challenge_text, 
                    "receipt_id": returned_receipt_id,
                    "instruction": "Revise your action to comply with the challenge and try again."
                })

            # 2. Check for the Escalation Handoff (The HITL Polling Loop)
            elif isinstance(eval_res, dict) and eval_res.get("status") == "ESCALATED":
                receipt_id = eval_res.get("receipt_id")
                print(f"\n🚨 [AgentX SDK] Task suspended. Request escalated to Human SOC.")
                print(f"⏳ [AgentX SDK] Polling for human decision (Receipt: {receipt_id})...")
                
                api_key = os.environ.get("AGENTX_API_KEY")
                headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
                
                # The Polling Loop
                while True:
                    time.sleep(3)
                    try:
                        status_check = requests.get(
                            f"{_client.gateway_url}/v1/status/{receipt_id}",
                            headers=headers
                        )
                        if status_check.status_code == 200:
                            current_status = status_check.json().get("status")
                            
                            if current_status == "APPROVED":
                                print(f"\n✅ [AgentX SDK] Human SOC APPROVED the override!")
                                # Reset state, this wasn't a self-correction, human bypassed it.
                                _session_stats["last_call_was_challenge"] = False 
                                return func(*args, **kwargs)
                                
                            elif current_status == "DENIED":
                                print(f"\n❌ [AgentX SDK] Human SOC DENIED the override.")
                                return json.dumps({
                                    "error": "AgentX Human Override Denied",
                                    "instruction": "The SOC analyst explicitly denied this action. You must find an alternative path or fail the task."
                                })
                                
                        elif status_check.status_code == 401:
                            print(f"\n❌ [AgentX SDK] Auth Error: Gateway rejected polling request.")
                            return json.dumps({"error": "Unauthorized Polling"})
                            
                    except Exception as e:
                        print(f"⚠️ Polling error: {e}")

            # 3. Check for the "Success" path
            elif isinstance(eval_res, dict) and eval_res.get("status") in ["success", "ALLOWED"]:
                print(f"✅ [AgentX SDK] Intent safe. Executing '{func.__name__}'.")
                
                # +++ SENSOR: Check if this was a successful recovery!
                if _session_stats.get("last_call_was_challenge"):
                    _session_stats["self_corrections"] += 1
                    _session_stats["last_call_was_challenge"] = False
                    
                # Fix: Actually execute the function instead of returning the Gateway's JSON
                return func(*args, **kwargs)

            # 4. Handle actual Gateway crashes
            else:
                error_detail = eval_res.get("message") if isinstance(eval_res, dict) else "Unknown Connection Error"
                return f"AgentX System Error: {error_detail}"
                
        return wrapper
    return decorator