import sqlite3
import time
import os

# Hidden file in the directory where the developer runs their agent
DB_PATH = ".agentx.db"

import sqlite3
import time
import os

DB_PATH = ".agentx.db"

def init_db():
    """Initializes the V2 database and performs an Alpha Wipe if legacy schema is detected."""
    legacy_detected = False
    
    # 1. Detect Legacy Schema
    if os.path.exists(DB_PATH):
        try:
            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()
            cursor.execute("PRAGMA table_info(event_log)")
            columns = [col[1] for col in cursor.fetchall()]
            
            # If the table exists but doesn't have our new 'policy_id' column, it's legacy.
            if len(columns) > 0 and 'policy_id' not in columns:
                legacy_detected = True
            conn.close()
        except sqlite3.Error:
            pass 

    # 2. The Safe Alpha Wipe
    if legacy_detected:
        print("\n🔄 [AgentX SDK] Legacy telemetry detected. Performing Alpha Wipe for v0.2.0 upgrade...")
        try:
            os.remove(DB_PATH)
            print("✅ [AgentX SDK] Clean slate! Welcome to the Policy ID architecture.")
        except PermissionError:
            print("⚠️ [AgentX SDK] Windows file lock prevented DB wipe. Please delete '.agentx.db' manually.")

    # 3. Create the New V2 Schema
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS event_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp REAL,
            tool_name TEXT,
            policy_id TEXT,     -- NEW: Strict Alphanumeric ID (e.g., POL-SEC-001)
            policy_name TEXT,   -- Kept strictly for the CLI UI display
            status TEXT,
            tokens_saved INTEGER,
            time_saved_mins INTEGER
        )
    ''')
    conn.commit()
    conn.close()

# Update your log_intercept function signature to accept the new ID!
def log_intercept(tool_name, policy_id, policy_name, status, tokens=1500, time_saved=5):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO event_log (timestamp, tool_name, policy_id, policy_name, status, tokens_saved, time_saved_mins)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (time.time(), tool_name, policy_id, policy_name, status, tokens, time_saved))
    conn.commit()
    conn.close()

def get_lifetime_stats():
    """Calculates cumulative stats and identifies the Top Offender using V2 Schema."""
    if not os.path.exists(DB_PATH):
        return None
        
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # 1. Total Intercepts
    cursor.execute("SELECT COUNT(*) FROM event_log WHERE status = 'CHALLENGED'")
    total_intercepts = cursor.fetchone()[0] or 0
    
    # 2. Critical Blocks (Updated to use policy_name)
    cursor.execute("SELECT COUNT(*) FROM event_log WHERE status = 'CHALLENGED' AND policy_name IN ('Mass Destructive Intent', 'Database Isolation')")
    total_critical = cursor.fetchone()[0] or 0
    
    # 3. Sum of Tokens and Time
    cursor.execute("SELECT SUM(tokens_saved), SUM(time_saved_mins) FROM event_log WHERE status = 'CHALLENGED'")
    row = cursor.fetchone()
    total_tokens = row[0] or 0
    total_time = row[1] or 0
    
    # 4. Top Offender (Select policy_name, Group by policy_id)
    cursor.execute('''
        SELECT policy_name, COUNT(*) as c 
        FROM event_log 
        WHERE status = 'CHALLENGED' 
        GROUP BY policy_id 
        ORDER BY c DESC LIMIT 1
    ''')
    top_offender_row = cursor.fetchone()
    top_offender = top_offender_row[0] if top_offender_row else None
    
    conn.close()
    
    return {
        "total_intercepts": total_intercepts,
        "total_critical": total_critical,
        "total_tokens": total_tokens,
        "total_time": total_time,
        "top_offender": top_offender
    }