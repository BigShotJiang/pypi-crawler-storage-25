"""Uninstall helpers for reddit-mcp client registrations and local config."""

from __future__ import annotations

import shutil

from fivemghost_shared_client.registration import unregister_all

from .console import console_print
from .config import CONFIG_DIR, LEGACY_CONFIG_DIR


def run_uninstall() -> None:
    """Remove reddit-mcp registrations and local config."""
    console_print("\n🧹 reddit-mcp uninstall\n")
    unregister_all(server_name="reddit-mcp")

    removed_any = False
    for config_dir in (CONFIG_DIR, LEGACY_CONFIG_DIR):
        if config_dir.exists():
            # Why: remove both current and legacy homes so upgrades do not leave stale cookie state behind.
            shutil.rmtree(config_dir)
            console_print(f"  ✅ Removed local reddit-mcp config: {config_dir}")
            removed_any = True
    if not removed_any:
        console_print(
            "  ℹ️  Local reddit-mcp config already absent: "
            f"{CONFIG_DIR} and {LEGACY_CONFIG_DIR}"
        )

    console_print("  ℹ️  If you installed via uv, remove the tool with: uv tool uninstall 5mghost-rover")
    console_print("")
