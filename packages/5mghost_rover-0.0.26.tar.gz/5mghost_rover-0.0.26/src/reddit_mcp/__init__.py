"""reddit-mcp — Reddit MCP server for batch Reddit data access."""

from importlib.metadata import PackageNotFoundError, version

from . import console

try:
    # Why: pyproject.toml is the package release source of truth; the CLI and
    # installer both rely on this value to detect stale entrypoints correctly.
    __version__ = version("5mghost-rover")
except PackageNotFoundError:
    __version__ = "0.0.26"
