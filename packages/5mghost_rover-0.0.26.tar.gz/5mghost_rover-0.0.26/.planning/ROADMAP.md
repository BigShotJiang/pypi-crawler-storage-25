# Roadmap: reddit-mcp

## Current Milestone

**vNext — Installer And Setup Architecture Simplification**

Goal: replace the current multi-entrypoint installer/setup stack with a single uv-based runtime model, a single setup orchestrator, and fail-fast success semantics that guarantee a usable AI-client-integrated install.

## Phases

- [ ] **Phase 1: Installer And Setup Architecture Simplification** - Standardize install/runtime/registration on uv plus a single setup state machine

## Phase Details

### Phase 1: Installer And Setup Architecture Simplification
**Goal**: Remove multi-path runtime drift, make setup outcomes explicit, and keep automatic AI client registration without fake-success fallbacks.
**Depends on**: current shipped reddit-mcp baseline on `main`
**Requirements**: INST-01, INST-02, INST-03, SETUP-01, SETUP-02, SETUP-03, REG-01, REG-02, REG-03, VER-01, VER-02, VER-03
**Success Criteria**:
  1. The supported install path uses `uv tool install`, and the supported runtime path is `reddit-mcp serve`.
  2. `reddit-mcp setup` owns install/auth/cookies/register/verify as explicit phases with no swallowed required failures.
  3. Supported AI clients are auto-detected and auto-registered to the same canonical runtime command, and setup fails if none are available.
  4. Hosted shell and PowerShell installers become thin wrappers around the canonical setup flow instead of independent recovery state machines.
  5. Tests cover failure semantics, runtime resolution, and registration correctness on supported platforms.

## Progress

| Phase | Plans Complete | Status |
|-------|----------------|--------|
| 1. Installer And Setup Architecture Simplification | 0/0 | Ready for discuss/plan |
