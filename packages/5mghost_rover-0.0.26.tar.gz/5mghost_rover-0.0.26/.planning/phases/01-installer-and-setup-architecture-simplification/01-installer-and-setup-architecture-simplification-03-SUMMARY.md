---
phase: 01-installer-and-setup-architecture-simplification
plan: 03
subsystem: hosted-installers
tags: [shell, powershell, installer, uv, setup-contract]
requires: [01, 02]
provides:
  - Thin uv-based hosted installers for macOS/Linux and Windows
  - Direct pass-through from installer wrappers to `reddit-mcp setup`
  - Regression coverage that rejects fake-success fallback behavior
affects: [auth_gateway_for_mcp, reddit-mcp]
tech-stack:
  added: []
  patterns: [thin-installer-wrapper, pass-through-exit-codes, template-contract-tests]
key-files:
  created: []
  modified:
    - auth_gateway_for_mcp/templates/reddit-mcp.sh.tpl
    - auth_gateway_for_mcp/templates/reddit-mcp.ps1.tpl
    - auth_gateway_for_mcp/tests/installer-endpoints.test.mjs
    - auth_gateway_for_mcp/tests/installers-renderer.test.mjs
key-decisions:
  - "Hosted installers now only ensure `uv`, run `uv tool install 5mghost-rover`, and invoke `reddit-mcp setup`."
  - "Installer success output is emitted only after `reddit-mcp setup` returns successfully."
  - "Python probing, Playwright install, bootstrap fallback, and auth/smoke-test wrapper logic were removed from the hosted installers."
patterns-established:
  - "Installer tests assert both required canonical commands and the absence of retired fallback/runtime patterns."
  - "The wrapper owns transport and prerequisite wiring, while setup semantics stay inside the CLI."
requirements-completed: [INST-01, SETUP-03, VER-03]
duration: 30min
completed: 2026-04-14
---

# Phase 1: Installer And Setup Architecture Simplification - Plan 03 Summary

**The hosted reddit installers are now thin uv-based wrappers: they install the tool, invoke `reddit-mcp setup`, and stop pretending they can recover or reinterpret setup failures.**

## Performance

- **Duration:** 30 min
- **Tasks:** 2
- **Files modified:** 4

## Accomplishments

- Rewrote the shell installer around `uv` installation, `uv tool install 5mghost-rover`, and direct `reddit-mcp setup` invocation.
- Rewrote the PowerShell installer to the same contract, including explicit exit-code pass-through for external commands.
- Deleted Python runtime probing, pip reinstall/self-repair logic, Playwright installer logic, and bootstrap fallback branches from both templates.
- Strengthened installer rendering and endpoint tests to assert the canonical uv/setup flow and reject false-success patterns.

## Task Commits

Execution for this plan was completed in one local pass and verified before summary creation. The branch commit after this summary captures the delivered state.

## Files Created/Modified

- `auth_gateway_for_mcp/templates/reddit-mcp.sh.tpl` - POSIX/macOS installer reduced to uv bootstrap, package install, and setup invocation.
- `auth_gateway_for_mcp/templates/reddit-mcp.ps1.tpl` - Windows installer reduced to the same uv-first wrapper contract with explicit exit-code propagation.
- `auth_gateway_for_mcp/tests/installer-endpoints.test.mjs` - Hosted endpoint assertions updated to the new thin-wrapper contract and absence of retired fallback strings.
- `auth_gateway_for_mcp/tests/installers-renderer.test.mjs` - Template-renderer assertions updated to the new canonical command contract.

## Decisions Made

- Kept current-session PATH repair minimal by prepending uv's tool bin directory instead of trying to mutate shell profiles inside the installer.
- Let `reddit-mcp setup` own all success/failure judgment after package install, instead of layering smoke tests or auth checks in the installer wrappers.

## Deviations from Plan

- `auth_gateway_for_mcp/src/installers.ts` did not require code changes because the renderer already performs pure template substitution; only templates and tests changed.

## Issues Encountered

- Node tests initially failed because this worktree lacked built `dist/` output and local dependencies. Installing Node deps, rebuilding `shared`, reinstalling `auth_gateway_for_mcp` deps, and then rebuilding restored the expected test environment.
- On this Windows environment, `npm run build` still fails to expose `tsc` on PATH. Verification used the equivalent `.\node_modules\.bin\tsc.cmd -p tsconfig.json` commands instead.

## User Setup Required

None for this wave.

## Next Phase Readiness

- README and release-readiness docs can now describe a real installer contract instead of a best-effort wrapper fiction.
- Final verification can now focus on CLI/setup semantics and documentation, because installer-owned fallback state has been removed.

---
*Phase: 01-installer-and-setup-architecture-simplification*
*Completed: 2026-04-14*
