# Phase 1: installer-and-setup-architecture-simplification - Discussion Log

> **Audit trail only.** Do not use as input to planning, research, or execution agents.
> Decisions are captured in CONTEXT.md — this log preserves the alternatives considered.

**Date:** 2026-04-14
**Phase:** 01-installer-and-setup-architecture-simplification
**Areas discussed:** runtime model, setup ownership, installer behavior, registration semantics, legacy patch layers

---

## Runtime model

| Option | Description | Selected |
|--------|-------------|----------|
| `pip` global script | Keep Python/pip-centric install and runtime behavior | |
| `uvx` | Use ephemeral `uvx --from ...` as the formal runtime path | |
| `uv tool install` + canonical CLI | Install via uv tools and run through a stable `reddit-mcp` command | ✓ |

**User's choice:** Standardize on `uv tool install`, with `reddit-mcp serve` as the only formal runtime command.
**Notes:** The user accepted moving away from multiple runtime truths and also accepted reducing reliance on a preinstalled system Python.

---

## Setup ownership

| Option | Description | Selected |
|--------|-------------|----------|
| Installer owns setup logic | Installer performs auth, cookies, registration, recovery, and success judgment itself | |
| Thin installer + separate setup | Installer only installs, then a separate command owns setup state transitions | ✓ |
| Manual multi-command flow | Users/AI run each step manually without a canonical orchestrator | |

**User's choice:** `reddit-mcp setup` should own the setup state machine, with explicit internal phases for install, auth, cookies, register, and verify.
**Notes:** The user specifically accepted that installer scripts may trigger `setup`, but that `setup` itself must own the success/failure contract.

---

## Installer behavior

| Option | Description | Selected |
|--------|-------------|----------|
| Interactive-first installer | Installer opens auth/browser flows as part of its main behavior | |
| Non-interactive-first installer | Installer stays focused on install + setup invocation and avoids owning interactive recovery branches | ✓ |
| Split interactive and non-interactive mainlines | Keep four main combinations across Windows/macOS and interactive/non-interactive modes | |

**User's choice:** Prefer a non-interactive-first installer architecture. Installer may auto-run `reddit-mcp setup`, but should not become the owner of auth/cookie/registration fallback logic.
**Notes:** This decision was driven by the actual usage pattern that most users will ask an AI to run commands, making non-interactive automation the primary path.

---

## Registration semantics

| Option | Description | Selected |
|--------|-------------|----------|
| Best-effort registration | Register what works, continue even if detection/registration partially fails | |
| Hard failure on missing or failed registration | Setup fails if no client is detected or if detected-client registration fails | ✓ |
| No auto-registration | Require manual MCP config everywhere | |

**User's choice:** Keep auto-registration, but treat detection/registration failure as a hard setup failure.
**Notes:** The user also required AI-actionable remediation output because many users will rely on AI to repair config automatically. Bundled skill installation is included in this same registration phase.

---

## Legacy patch layers

| Option | Description | Selected |
|--------|-------------|----------|
| Preserve `bootstrap` and `launcher.py` as core architecture | Keep current patch layers as long-term supported runtime paths | |
| Absorb and retire patch layers | Move useful behavior into `setup/register` and remove patch layers from the formal architecture | ✓ |
| Leave undecided for now | Defer architectural stance on these helpers | |

**User's choice:** `bootstrap` and `launcher.py` should not remain part of the target architecture.
**Notes:** During discussion, `bootstrap` was clarified as a local registration/skill-install catch-up command, and `launcher.py` was clarified as a runtime indirection layer created to paper over unstable entrypoints.

---

## the agent's Discretion

- Exact child command surface under `reddit-mcp setup`
- Exact machine-readable remediation format for AI-consumable registration errors

## Deferred Ideas

- Legacy migration support for historical installs is deferred because the product is not yet broadly externalized.
