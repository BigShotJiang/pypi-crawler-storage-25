# reddit-mcp GOTCHAS

- Reddit JSON API requests can return 403 with non-browser TLS fingerprints; keep using `curl_cffi` with browser impersonation.
- `reddit_session` expiry parsing depends on JWT base64url padding; missing padding makes expiry checks silently fail.
- Reddit quota is 100 requests / 10 minutes; batch calls must stay bounded (`max 25`) to avoid hitting 429 too quickly.
- macOS can still reuse a copied local Chrome / Edge profile for `setup-cookies`; Windows Chromium no longer does this reliably because modern cookie protection blocks cross-profile reuse.
- On Windows, explicit `setup-cookies` must use a dedicated app-owned browser profile (`~/.mkterswingman/reddit-mcp/browser-profile`) with a real local Chrome / Edge executable; Playwright-managed Chromium can be rejected by Reddit as a testing browser during interactive login.
- Cookie freshness fallback uses file age when JWT expiry cannot be decoded, so `meta.json` timestamps must be persisted reliably.
