# reddit-mcp E2E Checklist

This checklist is for the final real-machine validation before releasing behavior changes
to install, setup, or cookie import.

## When To Run

Run this checklist after any change that affects:

- `reddit-mcp setup`
- `reddit-mcp setup-cookies`
- cookie refresh / validation behavior
- packaged install / uninstall flow

## Preconditions

- `python3 --version` is 3.11+
- `python3 -m pip install -e .` succeeds locally
- `python3 -m pytest` passes
- A valid shared auth token exists at `~/.mkterswingman/auth.json`, or you are ready to log in during `setup`
- Chrome, Edge, or Chromium is installed locally
- You are already logged in to Reddit in one normal browser profile, or you are ready to log in during the run

Windows note:
- Do not assume `setup-cookies` can reuse your existing Chrome / Edge Reddit session directly
- On Windows, the supported interactive path is to let `reddit-mcp` open its own dedicated browser window and complete the Reddit login there

## Real E2E: Install + Cookie Import

1. Back up existing local state if you need to preserve it:
   `cp -R ~/.mkterswingman/reddit-mcp ~/.mkterswingman/reddit-mcp.backup-$(date +%Y%m%d-%H%M%S)`
2. Remove the current package:
   `python3 -m pip uninstall 5mghost-rover -y`
3. Install from the local source tree:
   `python3 -m pip install -e .`
4. Verify the CLI exists:
   `python3 -m reddit_mcp.cli version`
5. Run cookie-only setup if shared auth is already present:
   `python3 -m reddit_mcp.cli setup-cookies`
6. If a dedicated reddit-mcp browser window opens, complete the Reddit login in that window and wait for the command to detect `reddit_session`.
7. Verify local artifacts:
   `python3 -m reddit_mcp.cli check`
8. Verify MCP integration still works:
   `RUN_E2E=1 python3 -m pytest tests/test_e2e_codex.py -v`

## Pass Criteria

- `setup-cookies` finishes without `Cookie setup failed`
- `~/.mkterswingman/reddit-mcp/cookies.json` exists
- `~/.mkterswingman/reddit-mcp/meta.json` exists and contains `cookies_created_at`
- `python3 -m reddit_mcp.cli check` reports cookies as valid
- `tests/test_e2e_codex.py` passes on the target machine

## Failure Notes To Capture

Record these when the run fails:

- OS and browser used
- Whether Reddit was already logged in before the run
- The exact failing command
- Whether failure happened during profile discovery, CDP startup, cookie validation, or Codex MCP invocation
