import webbrowser
from dataclasses import dataclass
from typing import List

from typeguard import typechecked

from immich_autotag.config.manager import ConfigManager
from immich_autotag.config.models import UserConfig
from immich_autotag.logging.levels import LogLevel
from immich_autotag.logging.utils import log


@typechecked
def _generate_links(config: UserConfig) -> List[str]:
    host: str = config.server.host
    port: int = config.server.port
    links: List[str] = [f"- [Albums](http://{host}:{port}/albums)"]

    # Collect all autotag values from the new configuration structure

    from typing import Set

    @dataclass(frozen=True)
    class TagLabelPair:
        label: str
        tag: str

    tags_to_add: List[TagLabelPair] = []

    # From classification rules (input tags)
    if config.classification and config.classification.rules:
        seen_tags: Set[str] = set()
        for rule in config.classification.rules:
            if rule.tag_names:
                for tag in rule.tag_names:
                    if tag.startswith("autotag_input_") and tag not in seen_tags:
                        seen_tags.add(tag)
                        # Clean label: remove prefix and format
                        label = (
                            tag.replace("autotag_input_", "").replace("_", " ").title()
                        )
                        tags_to_add.append(
                            TagLabelPair(label=f"Input: {label}", tag=tag)
                        )

    # From classification (output tags)
    if config.classification:
        if config.classification.autotag_unknown:
            tags_to_add.append(
                TagLabelPair(
                    label="Classification: Unknown",
                    tag=config.classification.autotag_unknown,
                )
            )
        if config.classification.autotag_conflict:
            tags_to_add.append(
                TagLabelPair(
                    label="Classification: Conflict",
                    tag=config.classification.autotag_conflict,
                )
            )

    # From duplicate_processing
    if config.duplicate_processing:
        if config.duplicate_processing.autotag_album_conflict:
            tags_to_add.append(
                TagLabelPair(
                    label="Duplicates: Album conflict",
                    tag=config.duplicate_processing.autotag_album_conflict,
                )
            )
        if config.duplicate_processing.autotag_classification_conflict:
            tags_to_add.append(
                TagLabelPair(
                    label="Duplicates: Classification conflict",
                    tag=config.duplicate_processing.autotag_classification_conflict,
                )
            )
        if config.duplicate_processing.autotag_album_detection_conflict:
            tags_to_add.append(
                TagLabelPair(
                    label="Duplicates: Album detection conflict",
                    tag=config.duplicate_processing.autotag_album_detection_conflict,
                )
            )

    # From album_date_consistency
    if config.album_date_consistency and config.album_date_consistency.enabled:
        if config.album_date_consistency.autotag_album_date_mismatch:
            tags_to_add.append(
                TagLabelPair(
                    label="Consistency: Album date mismatch",
                    tag=config.album_date_consistency.autotag_album_date_mismatch,
                )
            )

    # Generate links for each tag
    for pair in tags_to_add:
        url = f"http://{host}:{port}/tags?path={pair.tag}"
        links.append(f"- [{pair.label}]({url})")

    links.append(
        (
            "\nFor configuration details, see: "
            "[README_config.md](https://github.com/txemi/"
            "immich-autotag/blob/main/immich_autotag/config/README_config.md)"
        )
    )
    return links


@typechecked
def _print_links_to_console(config: UserConfig, links: List[str]) -> None:
    print("\nImmich autotagging process started!")
    print("You can monitor the results and progress at the following links:")
    for line in links:
        if line.startswith("- [Albums]"):
            print(
                f"- Albums:        http://{config.server.host}:"
                f"{config.server.port}/albums"
            )
        elif line.startswith("- ["):
            # Extract label and url for pretty print
            import re

            m = re.match(r"- \[(.+)\]\((.+)\)", line)
            if m:
                label, url = m.group(1), m.group(2)
                print(f"- {label}: {url}")
    print("\nFor configuration details, see:")
    print(
        "https://github.com/txemi/immich-autotag/blob/main/"
        "immich_autotag/config/README_config.md\n"
    )


@typechecked
def _write_links_markdown(links: List[str]) -> None:
    from immich_autotag.run_output.manager import RunOutputManager

    try:
        run_exec = RunOutputManager.current().get_run_output_dir()
        md_path = run_exec.get_links_markdown_path()
        with open(md_path, "w", encoding="utf-8") as f:
            f.write("# Immich Autotagging Quick Links\n\n")
            f.write("\n".join(links))
            f.write("\n")
    except Exception as e:
        print(f"[WARN] Could not write links markdown: {e}")


@typechecked
def print_welcome_links(config: UserConfig) -> None:
    links = _generate_links(config)
    _print_links_to_console(config, links)
    _write_links_markdown(links)


@typechecked
def print_config_help() -> None:
    local_path = "immich_autotag/config/README_config.md"
    web_url = (
        "https://github.com/txemi/immich-autotag/blob/main/"
        "immich_autotag/config/README_config.md"
    )
    print("\nNo configuration found. Please see the configuration guide:")
    print(f"- Local file: {local_path}")
    print(f"- Online: {web_url}")
    try:
        webbrowser.open(web_url)
    except Exception:
        pass


def init_config_and_print_welcome() -> ConfigManager:
    """
    Initialize ConfigManager, log initialization, print welcome links, and return the manager.
    """
    manager = ConfigManager.get_instance()
    log("Initializing ConfigManager...", level=LogLevel.INFO)
    config = (
        manager.get_config()
    )  # This will trigger lazy loading of the configuration if it hasn't been loaded yet
    print_welcome_links(config)
    return manager
