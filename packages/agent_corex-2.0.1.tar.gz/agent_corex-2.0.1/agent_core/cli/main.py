"""
Agent-Core CLI interface.

Core commands:
  retrieve      Search for relevant tools by query
  start         Start the Agent-Core retrieval API server
  version       Show version
  health        Check API health
  config        Show configuration info

Gateway / tool management:
  serve         Start the MCP gateway server (used by Claude Desktop / Cursor)
  init          Detect AI tools and inject Agent-Corex as an MCP server
  eject         Remove agent-corex from AI tool configs
  list          List all MCP servers injected across detected tools
  update        Re-fetch registry and update injected server configs

Auth / account:
  login         Validate API key and store credentials
  logout        Remove stored credentials
  keys          Show masked API key + verify with backend

Diagnostics:
  detect        Detect installed AI tools and show config paths
  status        Show auth state, backend status, and injection status per tool
  doctor        Diagnose common setup issues (Python, PATH, config, backend)

Registry / install:
  mcp add       Enable an MCP server in your Agent-CoreX backend router
  registry      Browse the installable MCP server catalog
  install-mcp   Install an MCP server from the registry into all detected tools
  apply         Apply a skill.md file (install packs + env + MCP, end-to-end)
"""

from __future__ import annotations

import typer
from typing import Optional
import json
import pathlib
from agent_core.pack_manager import PackManager


def _version_callback(value: bool):
    if value:
        from agent_core import __version__

        typer.echo(f"agent-corex {__version__}")
        raise typer.Exit()


app = typer.Typer(
    name="agent-corex",
    help="Fast, accurate MCP tool retrieval engine — with gateway and enterprise support",
    no_args_is_help=True,
)

# ── mcp sub-app ───────────────────────────────────────────────────────────────
mcp_app = typer.Typer(
    name="mcp",
    help="Manage MCP servers in your Agent-CoreX backend router.",
    no_args_is_help=True,
)
app.add_typer(mcp_app)


@app.callback()
def _app_options(
    version: Optional[bool] = typer.Option(
        None,
        "--version",
        "-V",
        callback=_version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
):
    pass


# ── Shared detector/adapter helper ────────────────────────────────────────────


def _tool_pairs():
    """Return [(slug, detector, adapter), ...] for all 5 supported AI tools."""
    from agent_core.detectors import (
        ClaudeDesktopDetector,
        CursorDetector,
        VSCodeDetector,
        VSCodeInsidersDetector,
        VSCodiumDetector,
    )
    from agent_core.config_adapters import (
        ClaudeAdapter,
        CursorAdapter,
        VSCodeStableAdapter,
        VSCodeInsidersAdapter,
        VSCodiumAdapter,
    )

    return [
        ("claude", ClaudeDesktopDetector(), ClaudeAdapter()),
        ("cursor", CursorDetector(), CursorAdapter()),
        ("vscode", VSCodeDetector(), VSCodeStableAdapter()),
        ("vscode-insiders", VSCodeInsidersDetector(), VSCodeInsidersAdapter()),
        ("vscodium", VSCodiumDetector(), VSCodiumAdapter()),
    ]


# ═══════════════════════════════════════════════════════════════════════════
# Existing commands (preserved exactly)
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def retrieve(
    query: str = typer.Argument(..., help="Search query for tool retrieval"),
    top_k: int = typer.Option(5, "--top-k", "-k", help="Number of results to return"),
    method: str = typer.Option(
        "hybrid", "--method", "-m", help="Ranking method: keyword, hybrid, or embedding"
    ),
    config: Optional[str] = typer.Option(
        None, "--config", "-c", help="Path to mcp.json config file"
    ),
):
    """
    Retrieve the most relevant tools for a given query.

    Requires the [ml] extra:  pip install "agent-corex[ml]"

    Example:
        agent-corex retrieve "edit a file" --top-k 5 --method hybrid
    """
    try:
        from agent_core.retrieval.ranker import rank_tools
        from agent_core.tools.registry import ToolRegistry
        from agent_core.tools.mcp.mcp_loader import MCPLoader
        import pathlib

        registry = ToolRegistry()

        if config:
            config_path = pathlib.Path(config)
            if config_path.exists():
                try:
                    loader = MCPLoader(str(config_path))
                    manager = loader.load()
                    tools = manager.get_all_tools()
                except Exception as e:
                    typer.echo(f"Warning: Failed to load MCP servers: {e}", err=True)
                    tools = registry.get_all_tools()
            else:
                typer.echo(f"Config file not found: {config}", err=True)
                tools = registry.get_all_tools()
        else:
            tools = registry.get_all_tools()

        if not tools:
            typer.echo("No tools available", err=True)
            raise typer.Exit(1)

        results = rank_tools(query, tools, top_k=top_k, method=method)

        if not results:
            typer.echo(f"No tools found for query: {query}")
            raise typer.Exit(0)

        typer.echo(f"\nFound {len(results)} tool(s) for: '{query}'\n")
        for i, tool in enumerate(results, 1):
            typer.echo(f"{i}. {tool['name']}")
            typer.echo(f"   {tool.get('description', 'No description')}\n")

    except ImportError:
        typer.echo(
            "\n✗ ML dependencies are not installed.\n" '  Run: pip install "agent-corex[ml]"\n',
            err=True,
        )
        raise typer.Exit(1)
    except Exception as e:
        typer.echo(f"Error: {str(e)}", err=True)
        raise typer.Exit(1)


@app.command()
def start(
    host: str = typer.Option("127.0.0.1", "--host", "-h", help="Server host"),
    port: int = typer.Option(8000, "--port", "-p", help="Server port"),
    reload: bool = typer.Option(True, "--reload/--no-reload", help="Enable auto-reload"),
    config: Optional[str] = typer.Option(
        None, "--config", "-c", help="Path to mcp.json config file"
    ),
):
    """
    Start the Agent-Core retrieval API server.

    Requires the [server] extra:  pip install "agent-corex[server]"

    Example:
        agent-corex start --host 0.0.0.0 --port 8000
    """
    try:
        import uvicorn  # noqa: F401
    except ImportError:
        typer.echo(
            "\n✗ uvicorn is not installed.\n" '  Run: pip install "agent-corex[server]"\n',
            err=True,
        )
        raise typer.Exit(1)
    import os

    if config:
        os.environ["AGENT_CORE_CONFIG"] = config

    typer.echo(f"Starting Agent-Core API server at http://{host}:{port}")
    typer.echo("Press Ctrl+C to stop\n")

    uvicorn.run("agent_core.api.main:app", host=host, port=port, reload=reload, log_level="info")


@app.command()
def version():
    """Show Agent-Core version."""
    from agent_core import __version__

    typer.echo(f"Agent-Core {__version__}")


@app.command()
def health():
    """Check API health (requires running server)."""
    import httpx
    from agent_core import local_config

    base_url = local_config.get_base_url()
    typer.echo("Checking Agent-CoreX service...")
    try:
        resp = httpx.get(f"{base_url}/health", timeout=5)
        if resp.status_code == 200:
            typer.echo("✓ Service is healthy")
        else:
            typer.echo(f"✗ Service returned status {resp.status_code}", err=True)
            raise typer.Exit(1)
    except httpx.ConnectError:
        typer.echo("✗ Cannot connect to Agent-CoreX. Check your internet connection.", err=True)
        raise typer.Exit(1)
    except Exception as e:
        typer.echo(f"✗ Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(name="set-url")
def set_url(
    url: str = typer.Argument(..., help="Frontend URL (default: https://www.agent-corex.com)"),
):
    """
    Override the frontend login page URL (for local development only).

    \\b
    Examples:
        agent-corex set-url http://localhost:5173    # local dev
        agent-corex set-url https://www.agent-corex.com  # restore default
    """
    from agent_core import local_config

    url = url.rstrip("/")
    local_config.set_key("frontend_url", url)
    typer.echo(f"✓ Frontend URL set to: {url}")
    typer.echo("  'agent-corex login' will now open this URL in your browser.")


@app.command(name="config")
def show_config():
    """Show configuration information."""
    import pathlib
    from agent_core import __version__

    typer.echo(f"Agent-Core {__version__}\n")
    typer.echo("Configuration:")
    typer.echo(f"  Python version: {__import__('sys').version.split()[0]}")
    typer.echo(f"  Installation path: {pathlib.Path(__import__('agent_core').__file__).parent}")

    core_deps = {"typer": "Typer", "httpx": "httpx", "rich": "Rich"}
    optional_deps = {
        "sentence_transformers": ("Sentence Transformers", "[ml]"),
        "faiss": ("FAISS", "[ml]"),
        "fastapi": ("FastAPI", "[server]"),
        "uvicorn": ("uvicorn", "[server]"),
    }

    typer.echo("\nCore dependencies:")
    for module, name in core_deps.items():
        try:
            __import__(module)
            typer.echo(f"  ✓ {name}")
        except ImportError:
            typer.echo(f"  ✗ {name} (not installed)")

    typer.echo("\nOptional dependencies:")
    for module, (name, extra) in optional_deps.items():
        try:
            __import__(module)
            typer.echo(f"  ✓ {name}")
        except ImportError:
            typer.echo(f'  ✗ {name} — pip install "agent-corex{extra}" to enable')


# ═══════════════════════════════════════════════════════════════════════════
# New gateway / management commands
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def serve():
    """
    Start the MCP gateway server (stdio mode).

    This is the command injected into Claude Desktop / Cursor MCP configs:

    \\b
    {
      "agent-corex": {
        "command": "agent-corex",
        "args": ["serve"]
      }
    }

    Example:
        agent-corex serve
    """
    from agent_core.gateway.gateway_server import run

    run()


@app.command()
def init(
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompts"),
    uvx: bool = typer.Option(
        False,
        "--uvx",
        help=(
            "Inject a uvx-based entry (recommended for users without a global install). "
            "Uses 'uvx agent-corex mcp' instead of 'agent-corex serve' and passes "
            "AGENT_COREX_API_KEY via the MCP config env block."
        ),
    ),
):
    """
    Detect Claude Desktop / Cursor / VS Code and inject Agent-Corex as an MCP server.

    \\b
    What this does:
      1. Scans for Claude Desktop, Cursor, VS Code, VS Code Insiders, VSCodium
      2. Shows existing MCP servers that will be preserved
      3. Creates a timestamped backup of each config before writing
      4. Merges the agent-corex entry — never overwrites existing servers

    \\b
    Examples:
        agent-corex init                  # uses installed binary
        agent-corex init --uvx            # uses uvx (no global install needed)
        agent-corex init --uvx --yes      # skip confirmations
    """
    SERVER_NAME = "agent-corex"
    _VSCODE_NAMES = {"VS Code", "VS Code Insiders", "VSCodium"}

    if uvx:
        # Resolve the API key to embed in the env block.
        # If the user already has a key stored, pre-fill it so the config is
        # immediately functional.  Otherwise use a placeholder that they can
        # replace later.
        from agent_core import local_config as _lc

        _stored_key = _lc.get_api_key()
        if not _stored_key:
            typer.echo(
                "\n  No API key found. The MCP config will contain a placeholder.\n"
                "  Get your key at: https://www.agent-corex.com/dashboard/keys\n"
                "  Then re-run:     agent-corex init --uvx  (after agent-corex login --key <key>)\n"
            )
        _api_key_value = _stored_key or "<YOUR_AGENT_COREX_API_KEY>"

        _env_block = {"AGENT_COREX_API_KEY": _api_key_value}
        CLAUDE_CURSOR_DEF = {"command": "uvx", "args": ["agent-corex", "mcp"], "env": _env_block}
        VSCODE_DEF = {
            "type": "stdio",
            "command": "uvx",
            "args": ["agent-corex", "mcp"],
            "env": _env_block,
        }
    else:
        CLAUDE_CURSOR_DEF = {"command": "agent-corex", "args": ["serve"]}
        VSCODE_DEF = {"type": "stdio", "command": "agent-corex", "args": ["serve"]}

    # Build (detector, adapter, server_def) triples from the shared helper
    pairs = [
        (det, adp, VSCODE_DEF if det.name in _VSCODE_NAMES else CLAUDE_CURSOR_DEF)
        for _, det, adp in _tool_pairs()
    ]

    typer.echo("\nScanning for AI tools...\n")

    found_any = False
    vscode_written: list[str] = []  # track VS Code variants that were actually written
    for detector, adapter, server_def in pairs:
        if not detector.is_installed():
            typer.echo(f"  [-] {detector.name}: not detected")
            continue

        cfg_path = adapter.config_path()
        typer.echo(f"  [+] {detector.name}: {cfg_path}")
        found_any = True

        # Show existing servers so the user can see what will be preserved
        existing_servers = adapter.get_servers()
        other_servers = {k: v for k, v in existing_servers.items() if k != SERVER_NAME}

        if other_servers:
            typer.echo("      Existing servers (will be kept):")
            for name in other_servers:
                typer.echo(f"        - {name}")
        else:
            typer.echo("      No existing MCP servers — creating new block.")

        already = SERVER_NAME in existing_servers
        action = "Updated" if already else "Added"

        if not yes:
            verb = "Update" if already else "Add"
            confirmed = typer.confirm(
                f"      {verb} 'agent-corex' entry in {detector.name}?", default=True
            )
            if not confirmed:
                typer.echo("      Skipped.")
                continue

        bak = adapter.inject_server(SERVER_NAME, server_def)

        # Report the final state after the write
        final_servers = adapter.get_servers()
        typer.echo(f"      [+] {action}. MCP servers now contains {len(final_servers)} server(s):")
        for name in final_servers:
            marker = "  <-- agent-corex" if name == SERVER_NAME else ""
            typer.echo(f"            - {name}{marker}")
        if bak:
            typer.echo(f"      Backup: {bak}")

        if detector.name in _VSCODE_NAMES:
            vscode_written.append(detector.name)

    if not found_any:
        typer.echo("\nNo supported AI tools detected.")
        typer.echo("Supported: Claude Desktop, Cursor, VS Code, VS Code Insiders, VSCodium")
        typer.echo("Install one and re-run: agent-corex init")
        raise typer.Exit(1)

    typer.echo("\nDone. Restart the tool for changes to take effect.")

    if vscode_written:
        typer.echo(
            f"\n  Note ({', '.join(vscode_written)}): VS Code writes to settings.json while\n"
            "  running and may overwrite the entry. Fully close and reopen VS Code\n"
            "  so it reads the new config from disk on startup."
        )

    typer.echo("\nRun  agent-corex status  to verify.")


@app.command()
def login(
    api_key: Optional[str] = typer.Option(
        None, "--key", "-k", help="API key to store (acx_...) — skips browser flow"
    ),
    no_browser: bool = typer.Option(
        False, "--no-browser", help="Prompt for API key instead of opening browser"
    ),
):
    """
    Authenticate with Agent-Corex.

    \\b
    Default flow (browser-based, recommended):
      1. Opens browser to complete login
      2. CLI polls for completion automatically
      3. Session stored in ~/.agent-corex/config.json

    \\b
    API key flow (if you already have a key):
        agent-corex login --key acx_your_key_here
        agent-corex login --no-browser

    Example:
        agent-corex login
        agent-corex login --key acx_your_key_here
    """
    import webbrowser
    import time as _time
    from agent_core import local_config

    # ── API key flow (--key or --no-browser) ─────────────────────────────────
    if api_key or no_browser:
        from agent_core.gateway.auth_middleware import validate_api_key_format

        if not api_key:
            if not no_browser:
                login_url = local_config.get_login_url()
                typer.echo(f"\nOpening browser: {login_url}\n")
                try:
                    webbrowser.open(login_url)
                except Exception:
                    pass
                typer.echo("After logging in, copy your API key from the dashboard.\n")
            api_key = typer.prompt("Paste your API key (acx_...)", hide_input=True)

        api_key = api_key.strip()
        if not validate_api_key_format(api_key):
            typer.echo(
                "Invalid API key format. Keys must start with 'acx_' and be 8+ characters.",
                err=True,
            )
            raise typer.Exit(1)

        user_info: dict = {}
        try:
            import httpx

            base_url = local_config.get_base_url()
            with httpx.Client(base_url=base_url, timeout=5.0) as client:
                resp = client.post(
                    "/auth/login",
                    headers={"Authorization": f"Bearer {api_key}"},
                    json={"api_key": api_key},
                )
                if resp.status_code == 200:
                    user_info = resp.json()
                elif resp.status_code == 401:
                    typer.echo(
                        "Backend rejected the API key. Please check the key and try again.",
                        err=True,
                    )
                    raise typer.Exit(1)
        except ImportError:
            pass
        except Exception:
            typer.echo("(Could not reach backend — storing key locally for offline use.)")

        data = local_config.load()
        data["api_key"] = api_key
        if user_info:
            data["user"] = user_info
        local_config.save(data)
        name = user_info.get("name") or user_info.get("user_id", "")
        suffix = f" as {name}" if name else ""
        typer.echo(f"\n[+] Logged in{suffix}")
        typer.echo(f"  Credentials saved to {local_config.CONFIG_FILE}")
        return

    # ── Device-code browser flow (default) ───────────────────────────────────
    import httpx

    base_url = local_config.get_base_url()
    frontend_url = local_config.get_frontend_url()

    typer.echo("\nLogging in to Agent-CoreX...\n")

    # Step 1: Start CLI session
    try:
        resp = httpx.post(f"{base_url}/auth/cli/start", timeout=10.0)
        resp.raise_for_status()
        data = resp.json()
        device_code = data["device_code"]
        verification_url = data["verification_url"]
    except httpx.ConnectError:
        typer.echo(
            "[error] Cannot connect to Agent-CoreX. Check your internet connection.", err=True
        )
        typer.echo(
            "  Or:  agent-corex login --no-browser  to log in with an API key instead.",
            err=True,
        )
        raise typer.Exit(1)
    except (ValueError, KeyError):
        typer.echo("[error] Unexpected response from Agent-CoreX. Please try again.", err=True)
        typer.echo(
            "  Or:  agent-corex login --no-browser  to log in with an API key instead.",
            err=True,
        )
        raise typer.Exit(1)
    except Exception as exc:
        typer.echo(f"[error] Could not start login session: {exc}", err=True)
        typer.echo(
            "  Tip: agent-corex login --no-browser  to log in with an API key instead.",
            err=True,
        )
        raise typer.Exit(1)

    # Step 2: Show URL
    typer.echo("Open this URL to complete login:\n")
    typer.echo(f"  {verification_url}\n")
    try:
        webbrowser.open(verification_url)
        typer.echo("(Opened in your browser automatically)\n")
    except Exception:
        pass

    typer.echo("Waiting for authentication", nl=False)

    # Step 3: Poll
    deadline = _time.time() + 300
    while _time.time() < deadline:
        _time.sleep(2)
        typer.echo(".", nl=False)
        try:
            poll = httpx.post(
                f"{base_url}/auth/cli/poll", json={"device_code": device_code}, timeout=10.0
            )
            if poll.status_code != 200:
                continue
            result = poll.json()
        except Exception:
            continue
        status = result.get("status", "pending")
        if status == "expired":
            typer.echo("\n\n[error] Login session expired. Please try again.", err=True)
            raise typer.Exit(1)
        if status == "complete":
            typer.echo("\n")
            _save_jwt_session(result, local_config)
            return

    typer.echo("\n\n[error] Login timed out. Please try again.", err=True)
    raise typer.Exit(1)


def _save_jwt_session(result: dict, local_config) -> None:
    """Save JWT session returned from /auth/cli/poll to config."""
    import base64
    import json as _json
    import time as _time

    access_token = result.get("access_token", "")
    expires_at = int(_time.time()) + 3600
    email = result.get("email", "")

    # Decode JWT exp claim
    try:
        payload_b64 = access_token.split(".")[1]
        padding = 4 - len(payload_b64) % 4
        if padding != 4:
            payload_b64 += "=" * padding
        payload = _json.loads(base64.b64decode(payload_b64))
        if "exp" in payload:
            expires_at = payload["exp"]
        if not email:
            email = payload.get("email", "")
    except Exception:
        pass

    local_config.save_session(
        access_token=access_token,
        refresh_token=result.get("refresh_token", ""),
        user_id=result.get("user_id", ""),
        email=email,
        expires_at=expires_at,
    )
    typer.echo(f"✓ Logged in successfully!")
    if email:
        typer.echo(f"  User: {email}")
    typer.echo(f"  Session saved to {local_config.CONFIG_FILE}\n")
    typer.echo("You can now run:\n  agent-corex sync\n  agent-corex status\n")


@app.command()
def status():
    """
    Show auth state, config path, MCP injection status, and available tools.

    Example:
        agent-corex status
    """
    from agent_core import local_config, __version__
    from agent_core.gateway.tool_router import ToolRouter

    SERVER_NAME = "agent-corex"

    typer.echo(f"\nagent-corex  v{__version__}\n")

    ok = "[+]"
    no = "[-]"

    # ── Auth ────────────────────────────────────────────────────────────────
    typer.echo("Auth")
    if local_config.is_logged_in():
        user = local_config.get("user") or {}
        name = user.get("name") or user.get("user_id") or "(unknown)"
        typer.echo(f"  {ok} Logged in: Yes  ({name})")
    else:
        typer.echo(f"  {no} Logged in: No")
        typer.echo("    Run: agent-corex login")

    # ── Config ──────────────────────────────────────────────────────────────
    typer.echo("\nConfig")
    typer.echo(f"  Path:   {local_config.CONFIG_FILE}")
    typer.echo(f"  Exists: {'Yes' if local_config.CONFIG_FILE.exists() else 'No'}")

    # ── MCP clients ─────────────────────────────────────────────────────────
    typer.echo("\nMCP Clients")

    any_detected = False
    for _, detector, adapter in _tool_pairs():
        installed = detector.is_installed()
        cfg = adapter.config_path()

        if not installed:
            typer.echo(f"  {no} {detector.name}: not installed")
            continue

        any_detected = True
        injected = adapter.has_server(SERVER_NAME)
        inj_mark = ok if injected else no
        typer.echo(f"  {ok} {detector.name}: detected")
        typer.echo(f"      Config:             {cfg}")
        typer.echo(f"      agent-corex inject: {inj_mark} {'Yes' if injected else 'No'}")

    if not any_detected:
        typer.echo("  (No supported AI tools detected)")

    # ── Available tools ──────────────────────────────────────────────────────
    typer.echo("\nAvailable Tools")
    router = ToolRouter()
    tools = router.tools_list()

    free_tools = [t for t in tools if t.get("annotations", {}).get("tier") == "free"]
    ent_tools = [t for t in tools if t.get("annotations", {}).get("tier") == "enterprise"]

    typer.echo(f"  Free ({len(free_tools)}):")
    for t in free_tools:
        typer.echo(f"    {ok} {t['name']}")

    typer.echo(f"  Enterprise ({len(ent_tools)}):")
    locked = not local_config.is_logged_in()
    for t in ent_tools:
        mark = f"{no} [locked]" if locked else ok
        typer.echo(f"    {mark} {t['name']}")

    if locked and ent_tools:
        typer.echo("\n  Run  agent-corex login  to unlock enterprise tools.")

    # ── Sync status ──────────────────────────────────────────────────────────
    typer.echo("\nSync Status")
    if local_config.is_logged_in():
        import json as _json

        installed_file = local_config.CONFIG_DIR / "installed_servers.json"
        packs_file = local_config.CONFIG_DIR / "installed_packs.json"
        local_servers: list = []
        local_packs: list = []
        try:
            if installed_file.exists():
                local_servers = _json.loads(installed_file.read_text(encoding="utf-8"))
        except Exception:
            pass
        try:
            if packs_file.exists():
                local_packs = _json.loads(packs_file.read_text(encoding="utf-8"))
        except Exception:
            pass
        typer.echo(f"  Installed packs   : {', '.join(local_packs) if local_packs else '(none)'}")
        typer.echo(
            f"  Installed servers : {', '.join(local_servers) if local_servers else '(none)'}"
        )
        typer.echo("  Run: agent-corex sync  (to sync with backend)")
    else:
        typer.echo("  Not connected — run: agent-corex login")

    typer.echo("")


@app.command()
def sync(
    push_only: bool = typer.Option(
        False, "--push-only", help="Only push local state, skip pull/install"
    ),
):
    """
    Sync packs and servers between CLI and backend.

    \\b
    Steps:
      1. Pull enabled packs/servers from backend
      2. Install any missing locally
      3. Push local install state back to backend

    Requires login (run: agent-corex login).

    Example:
        agent-corex sync
        agent-corex sync --push-only
    """
    import json as _json
    import httpx
    from agent_core import local_config

    if not local_config.is_logged_in():
        typer.echo("Not logged in. Run: agent-corex login", err=True)
        raise typer.Exit(1)

    auth_header = local_config.get_auth_header()
    if not auth_header:
        typer.echo("No credentials found. Run: agent-corex login", err=True)
        raise typer.Exit(1)

    base_url = local_config.get_base_url()
    installed_file = local_config.CONFIG_DIR / "installed_servers.json"
    packs_file = local_config.CONFIG_DIR / "installed_packs.json"

    def _load_json_list(path: pathlib.Path) -> list:
        try:
            if path.exists():
                return _json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            pass
        return []

    def _save_json_list(path: pathlib.Path, data: list) -> None:
        path.write_text(_json.dumps(sorted(set(data)), indent=2), encoding="utf-8")

    if not push_only:
        # ── Step 1: Pull from backend ─────────────────────────────────────────
        typer.echo("\nPulling configuration...")
        try:
            resp = httpx.get(
                f"{base_url}/user/servers",
                headers={"Authorization": auth_header},
                timeout=15.0,
            )
            resp.raise_for_status()
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 401:
                typer.echo("[error] Authentication failed. Run: agent-corex login", err=True)
            else:
                typer.echo(f"[error] Sync failed (HTTP {exc.response.status_code})", err=True)
            raise typer.Exit(1)
        except Exception as exc:
            typer.echo(f"[error] Could not connect to Agent-CoreX: {exc}", err=True)
            raise typer.Exit(1)

        try:
            remote = resp.json()
        except Exception:
            typer.echo(
                "[error] Agent-CoreX returned an unexpected response. "
                "Try again or run: agent-corex login --no-browser",
                err=True,
            )
            raise typer.Exit(1)
        remote_servers: list = remote.get("enabled_servers", [])
        remote_packs: list = remote.get("enabled_packs", [])
        typer.echo(f"  Remote servers : {', '.join(remote_servers) or 'none'}")
        typer.echo(f"  Remote packs   : {', '.join(remote_packs) or 'none'}")

        # ── Step 2: Install missing ───────────────────────────────────────────
        # Read local state from PackManager (source of truth)
        installed_pack_data = PackManager.get_installed_packs()
        local_packs = set(installed_pack_data.keys())
        local_servers: set = set()
        for pack_data in installed_pack_data.values():
            for srv in pack_data.get("servers", []):
                if pack_data.get("enabled", {}).get(srv, True):
                    local_servers.add(srv)

        missing_servers = [s for s in remote_servers if s not in local_servers]
        missing_packs = [p for p in remote_packs if p not in local_packs]

        if missing_servers or missing_packs:
            typer.echo("\nInstalling missing items locally...")
            for pack in missing_packs:
                try:
                    PackManager.install_pack(pack)
                    local_packs.add(pack)
                    # Add the pack's servers to local_servers
                    for srv_def in PackManager.get_servers_for_pack(pack):
                        local_servers.add(srv_def["name"])
                    typer.echo(f"  Pack installed: {pack} ✓")
                except Exception:
                    local_packs.add(pack)
                    typer.echo(f"  Pack registered: {pack} (registered)")
            for srv in missing_servers:
                local_servers.add(srv)
                typer.echo(f"  Server registered: {srv} ✓")
        else:
            typer.echo("  Local state is up to date.")
    else:
        installed_pack_data = PackManager.get_installed_packs()
        local_packs = set(installed_pack_data.keys())
        local_servers = set()
        for pack_data in installed_pack_data.values():
            for srv in pack_data.get("servers", []):
                if pack_data.get("enabled", {}).get(srv, True):
                    local_servers.add(srv)

    # ── Step 3: Push local state ──────────────────────────────────────────────
    typer.echo("\nPushing local state...")
    try:
        push_resp = httpx.post(
            f"{base_url}/user/servers",
            headers={"Authorization": auth_header, "Content-Type": "application/json"},
            json={
                "installed_servers": sorted(local_servers),
                "installed_packs": sorted(local_packs),
            },
            timeout=15.0,
        )
        push_resp.raise_for_status()
        try:
            result = push_resp.json()
            typer.echo(
                f"  Synced {result.get('synced_servers', 0)} servers, "
                f"{result.get('synced_packs', 0)} packs."
            )
        except Exception:
            typer.echo("  Synced.")
    except Exception as exc:
        typer.echo(f"  [warn] Push failed (will retry next sync): {exc}")

    typer.echo("\n✓ Sync complete.\n")


@app.command(name="registry")
def list_registry():
    """
    Browse all installable MCP servers from the Agent-Corex registry.

    Example:
        agent-corex registry
    """
    try:
        import httpx
    except ImportError:
        typer.echo("httpx is required. Run: pip install httpx", err=True)
        raise typer.Exit(1)

    from agent_core import local_config

    base_url = local_config.get_base_url()
    typer.echo("\nFetching registry...\n")

    try:
        with httpx.Client(timeout=10.0) as client:
            resp = client.get(f"{base_url}/mcp_registry")
            resp.raise_for_status()
            servers = resp.json()
    except Exception as e:
        typer.echo(f"Failed to fetch registry: {e}", err=True)
        raise typer.Exit(1)

    if not servers:
        typer.echo("Registry is empty.")
        return

    # Group by category
    categories: dict[str, list] = {}
    for s in servers:
        cat = s.get("category", "general")
        categories.setdefault(cat, []).append(s)

    typer.echo(f"Available MCP Servers  ({len(servers)} total)\n")
    for cat, entries in sorted(categories.items()):
        typer.echo(f"  {cat.upper()}")
        for s in entries:
            env_note = f"  [needs: {', '.join(s['env_required'])}]" if s.get("env_required") else ""
            desc = s.get("description", "")[:55]
            typer.echo(f"    {s['name']:<22}  {desc}{env_note}")
        typer.echo("")

    typer.echo("Add via Agent-CoreX:  uvx agent-corex mcp add <name>")


# ── mcp add ───────────────────────────────────────────────────────────────────

_CLIENT_SLUGS = {
    "claude-code": "claude",
    "claude": "claude",
    "cursor": "cursor",
    "vscode": "vscode",
    "vscode-insiders": "vscode-insiders",
    "vscodium": "vscodium",
}


@mcp_app.command(name="add")
def mcp_add(
    name: str = typer.Argument(..., help="Server slug to enable, e.g. 'fetch' or 'github'"),
    client: Optional[str] = typer.Option(
        None,
        "--client",
        "-c",
        help=(
            "AI tool to inject agent-corex gateway into: "
            "claude-code | claude | cursor | vscode | vscode-insiders | vscodium | all. "
            "Omit to only enable the server in the backend."
        ),
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompts"),
):
    """
    Enable an MCP server in your Agent-CoreX backend router.

    Unlike Smithery-style local installs, this enables the server centrally in
    the Agent-CoreX MCP gateway so every AI tool using your API key gets access
    without touching local configs.

    Optionally pass --client to also inject the agent-corex gateway into a local
    AI tool (one-time setup, safe to re-run).

    \\b
    Examples:
        uvx agent-corex mcp add fetch
        uvx agent-corex mcp add github --client claude-code
        uvx agent-corex mcp add postgres --client cursor --yes
    """
    try:
        import httpx
    except ImportError:
        typer.echo("httpx is required. Run: pip install httpx", err=True)
        raise typer.Exit(1)

    from agent_core import local_config

    # ── Require login ───────────────────────────────────────────────────────
    if not local_config.is_logged_in():
        typer.echo("\nNot logged in. Run:\n\n    agent-corex login\n", err=True)
        typer.echo("Or get your API key at https://www.agent-corex.com/dashboard/settings")
        raise typer.Exit(1)

    api_key = local_config.get_api_key()
    base_url = local_config.get_base_url()

    # ── Confirm ─────────────────────────────────────────────────────────────
    if not yes:
        typer.confirm(f"\nEnable '{name}' in your Agent-CoreX backend?", default=True, abort=True)

    # ── Enable server in backend ─────────────────────────────────────────────
    typer.echo(f"\nEnabling '{name}' in Agent-CoreX backend...")
    try:
        with httpx.Client(timeout=10.0) as client_http:
            resp = client_http.post(
                f"{base_url}/mcp_servers/toggle",
                json={"server": name, "enabled": True},
                headers={"Authorization": f"Bearer {api_key}"},
            )
            if resp.status_code == 404:
                typer.echo(
                    f"\n  Server '{name}' not found in the registry.",
                    err=True,
                )
                typer.echo("  Browse available servers:  agent-corex registry")
                raise typer.Exit(1)
            resp.raise_for_status()
    except typer.Exit:
        raise
    except Exception as exc:
        typer.echo(f"\n  Failed to reach Agent-CoreX backend: {exc}", err=True)
        raise typer.Exit(1)

    typer.echo(f"  ✓ '{name}' is now enabled in your Agent-CoreX router.")

    # ── Optionally inject gateway into local tool ────────────────────────────
    if client:
        targets = list(_CLIENT_SLUGS.keys()) if client.lower() == "all" else [client.lower()]
        invalid = [t for t in targets if t not in _CLIENT_SLUGS and t != "all"]
        if invalid:
            typer.echo(
                f"\n  Unknown --client value(s): {', '.join(invalid)}. "
                "Choose from: claude-code, claude, cursor, vscode, vscode-insiders, vscodium, all",
                err=True,
            )
            raise typer.Exit(1)

        typer.echo("\nInjecting agent-corex gateway into local tool config...")
        from agent_core import local_config as _lc

        _uvx_flag = True  # always use uvx-based entry for `mcp add`
        _stored_key = _lc.get_api_key() or "<YOUR_AGENT_COREX_API_KEY>"
        server_def_base = {
            "command": "uvx",
            "args": ["agent-corex", "serve"],
            "env": {"AGENT_COREX_API_KEY": _stored_key},
        }
        server_def_vscode = {"type": "stdio", **server_def_base}

        _VSCODE_KEYS = {"vscode", "vscode-insiders", "vscodium"}
        all_pairs = _tool_pairs()

        slug_targets = {_CLIENT_SLUGS.get(t, t) for t in targets}

        any_injected = False
        for slug, detector, adapter in all_pairs:
            if slug_targets and slug not in slug_targets and client.lower() != "all":
                continue
            if not detector.is_installed():
                typer.echo(f"  [-] {detector.name}: not detected — skipping")
                continue
            sdef = server_def_vscode if slug in _VSCODE_KEYS else server_def_base
            action, bak = adapter.inject("agent-corex", sdef, overwrite=False)
            typer.echo(f"  [+] {action} in {detector.name}")
            any_injected = True

        if any_injected:
            typer.echo("\n  Restart your AI tool for changes to take effect.")

    typer.echo(
        f"\nDone. '{name}' is active in your Agent-CoreX router.\n"
        "All AI tools using your API key can now use it.\n"
        "Run  agent-corex status  to verify.\n"
    )


@app.command(name="install-mcp")
def install_mcp(
    name: str = typer.Argument(..., help="Registry server slug, e.g. 'github'"),
    tool: Optional[str] = typer.Option(
        None,
        "--tool",
        "-t",
        help="Target: claude | cursor | vscode | vscode-insiders | vscodium. All detected if omitted.",
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompts"),
):
    """
    Install a named MCP server from the registry into your local AI tools.

    \\b
    What this does:
      1. Fetches the server definition from the Agent-Corex registry
      2. Prompts for any required environment variables (e.g. API tokens)
      3. Injects the server into Claude Desktop, Cursor, and/or VS Code

    Example:
        agent-corex install-mcp github
        agent-corex install-mcp postgres --tool claude --yes
    """
    try:
        import httpx
    except ImportError:
        typer.echo("httpx is required. Run: pip install httpx", err=True)
        raise typer.Exit(1)

    from agent_core import local_config

    # ── Fetch registry entry ────────────────────────────────────────────────
    base_url = local_config.get_base_url()
    typer.echo(f"\nFetching '{name}' from registry...")

    try:
        with httpx.Client(timeout=10.0) as client:
            resp = client.get(f"{base_url}/mcp_registry/{name}")
            if resp.status_code == 404:
                typer.echo(f"\n  Server '{name}' not found in registry.", err=True)
                typer.echo("  Browse available servers:  agent-corex registry")
                raise typer.Exit(1)
            resp.raise_for_status()
            entry = resp.json()
    except typer.Exit:
        raise
    except Exception as e:
        typer.echo(f"\nFailed to reach registry: {e}", err=True)
        raise typer.Exit(1)

    # ── Show server info ────────────────────────────────────────────────────
    display_name = entry.get("display_name") or name
    cmd_str = entry["command"] + " " + " ".join(entry.get("args", []))
    typer.echo(f"\n  {display_name}")
    typer.echo(f"  {entry.get('description', '')}")
    typer.echo(f"  Command: {cmd_str}")
    if entry.get("install_note"):
        typer.echo(f"  Note:    {entry['install_note']}")

    # ── Collect environment variables ───────────────────────────────────────
    env_values: dict[str, str] = {}

    env_required: list[str] = entry.get("env_required", [])
    if env_required:
        typer.echo(f"\n  Required environment variables:")
        for key in env_required:
            val = typer.prompt(f"    {key}", hide_input=True)
            if val.strip():
                env_values[key] = val.strip()
            else:
                typer.echo(f"    (skipping {key} — server may not work without it)")

    env_optional: list[str] = entry.get("env_optional", [])
    if env_optional:
        typer.echo(f"\n  Optional environment variables (Enter to skip):")
        for key in env_optional:
            val = typer.prompt(f"    {key}", default="", show_default=False)
            if val.strip():
                env_values[key] = val.strip()

    # ── Build per-tool server definitions ──────────────────────────────────
    base_def: dict = {
        "command": entry["command"],
        "args": entry.get("args", []),
    }
    if env_values:
        base_def["env"] = env_values

    vscode_def = {"type": "stdio", **base_def}

    _VSCODE_KEYS = {"vscode", "vscode-insiders", "vscodium"}
    all_pairs = [
        (slug, det, adp, vscode_def if slug in _VSCODE_KEYS else base_def)
        for slug, det, adp in _tool_pairs()
    ]

    if tool:
        t = tool.lower()
        pairs = [(k, d, a, sd) for k, d, a, sd in all_pairs if k == t]
        if not pairs:
            typer.echo(
                f"\nUnknown tool: {tool!r}. "
                "Use: claude, cursor, vscode, vscode-insiders, vscodium",
                err=True,
            )
            raise typer.Exit(1)
    else:
        pairs = all_pairs

    # ── Inject into each detected tool ──────────────────────────────────────
    typer.echo(f"\nInstalling '{name}' into detected tools...\n")

    any_action = False
    for _, detector, adapter, server_def in pairs:
        if not detector.is_installed():
            typer.echo(f"  [-] {detector.name}: not detected — skipping")
            continue

        already = adapter.has_server(name)
        verb = "Update" if already else "Install"

        if not yes:
            confirmed = typer.confirm(f"  {verb} '{name}' in {detector.name}?", default=True)
            if not confirmed:
                typer.echo("      Skipped.")
                continue

        bak = adapter.inject_server(name, server_def)
        action = "Updated" if already else "Installed"
        typer.echo(f"  [+] {action} in {detector.name}")
        if bak:
            typer.echo(f"      Backup: {bak}")
        any_action = True

    if not any_action:
        typer.echo("\nNo changes made.")
    else:
        typer.echo("\nDone. Restart your tools for changes to take effect.")
        typer.echo("Run  agent-corex status  to verify.")


@app.command()
def logout(
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
):
    """
    Remove stored API key and user info from ~/.agent-corex/config.json.

    Example:
        agent-corex logout
        agent-corex logout --yes
    """
    from agent_core import local_config

    if not local_config.is_logged_in():
        typer.echo("Not logged in. Nothing to remove.")
        return

    user = local_config.get("user") or {}
    name = user.get("name") or user.get("user_id", "unknown")

    if not yes:
        confirmed = typer.confirm(f"Log out {name}?", default=True)
        if not confirmed:
            typer.echo("Aborted.")
            return

    data = local_config.load()
    for key in (
        "api_key",
        "user",
        "access_token",
        "refresh_token",
        "token_expires_at",
        "user_email",
    ):
        data.pop(key, None)
    local_config.save(data)

    typer.echo("Logged out.")


@app.command()
def keys():
    """
    Show the active API key and account info; verify with backend.

    Example:
        agent-corex keys
    """
    from agent_core import local_config

    if not local_config.is_logged_in():
        typer.echo("Not logged in. Run: agent-corex login", err=True)
        raise typer.Exit(1)

    api_key = local_config.get_api_key()
    user = local_config.get("user") or {}

    masked = api_key[:10] + "..." + api_key[-4:] if len(api_key) > 14 else api_key

    typer.echo("\nActive credentials")
    typer.echo(f"  API key : {masked}")
    typer.echo(f"  User ID : {user.get('user_id', '—')}")
    typer.echo(f"  Name    : {user.get('name', '—')}")

    typer.echo("\nVerifying key...")
    try:
        import httpx

        base_url = local_config.get_base_url()
        with httpx.Client(base_url=base_url, timeout=5.0) as client:
            resp = client.post(
                "/auth/login",
                headers={"Authorization": f"Bearer {api_key}"},
                json={"api_key": api_key},
            )
            if resp.status_code == 200:
                info = resp.json()
                typer.echo("[+] Key is valid.")
                data = local_config.load()
                data["user"] = info
                local_config.save(data)
            elif resp.status_code == 401:
                typer.echo("[-] Key is no longer valid. Run: agent-corex login", err=True)
            else:
                typer.echo(f"[?] Could not verify key (HTTP {resp.status_code}).")
    except ImportError:
        typer.echo("(httpx not installed — skipping remote verification)")
    except Exception:
        typer.echo("(Backend unreachable — cannot verify.)")


@app.command()
def detect():
    """
    Detect installed AI tools (Claude Desktop, Cursor, VS Code) and show config paths.

    Example:
        agent-corex detect
    """
    col_w = 20
    typer.echo(f"\n{'Tool':<{col_w}}  {'Installed':<10}  Config path")
    typer.echo("-" * 70)

    any_found = False
    for _, d, _ in _tool_pairs():
        installed = d.is_installed()
        cfg = d.config_path()
        if installed:
            any_found = True
        status = "Yes" if installed else "No"
        path = str(cfg) if cfg else "—"
        typer.echo(f"{d.name:<{col_w}}  {status:<10}  {path}")

    if not any_found:
        typer.echo("\nNo supported tools detected.")
        typer.echo("Install Claude Desktop, Cursor, or VS Code to get started.")
    else:
        typer.echo("\nRun  agent-corex init  to inject agent-corex into detected tools.")


@app.command()
def eject(
    tool: Optional[str] = typer.Option(
        None,
        "--tool",
        "-t",
        help="Target: claude | cursor | vscode | vscode-insiders | vscodium. Ejects from all if omitted.",
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompts"),
):
    """
    Remove the agent-corex MCP entry from Claude Desktop / Cursor / VS Code configs.

    Example:
        agent-corex eject
        agent-corex eject --tool claude --yes
    """
    SERVER_NAME = "agent-corex"
    all_pairs = _tool_pairs()

    if tool:
        t = tool.lower()
        pairs = [(k, d, a) for k, d, a in all_pairs if k == t]
        if not pairs:
            typer.echo(
                f"Unknown tool: {tool!r}. Use: claude, cursor, vscode, vscode-insiders, vscodium",
                err=True,
            )
            raise typer.Exit(1)
    else:
        pairs = all_pairs

    any_action = False
    for _, detector, adapter in pairs:
        if not detector.is_installed():
            typer.echo(f"  [-] {detector.name}: not detected — skipping")
            continue

        if not adapter.has_server(SERVER_NAME):
            typer.echo(f"  [-] {detector.name}: agent-corex not present — skipping")
            continue

        if not yes:
            confirmed = typer.confirm(f"  Remove agent-corex from {detector.name}?", default=True)
            if not confirmed:
                typer.echo("      Skipped.")
                continue

        bak = adapter.remove_server(SERVER_NAME)
        typer.echo(f"  [+] Removed from {detector.name}")
        if bak:
            typer.echo(f"      Backup: {bak}")
        any_action = True

    if not any_action:
        typer.echo("\nNo changes made.")
    else:
        typer.echo("\nDone. Restart the tool for changes to take effect.")


@app.command(name="list")
def list_servers(
    all_tools: bool = typer.Option(
        False,
        "--all",
        "-a",
        help="Include tools that are not installed (show empty rows).",
    ),
):
    """
    List all MCP servers currently injected across detected tools.

    Example:
        agent-corex list
        agent-corex list --all
    """
    any_output = False

    for _, detector, adapter in _tool_pairs():
        if not detector.is_installed():
            if all_tools:
                typer.echo(f"\n{detector.name}: not installed")
            continue

        servers = adapter.get_servers()
        typer.echo(f"\n{detector.name}  ({adapter.config_path()})")

        if not servers:
            typer.echo("  (no servers configured)")
            any_output = True
            continue

        # Column widths
        name_w = max(len(n) for n in servers) + 2
        for name, cfg in servers.items():
            cmd = cfg.get("command", "")
            args = " ".join(str(a) for a in cfg.get("args", []))
            typer.echo(f"  {name:<{name_w}}  {cmd} {args}".rstrip())
        any_output = True

    if not any_output:
        typer.echo("\nNo supported AI tools detected. Run  agent-corex detect  for details.")


@app.command()
def update(
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompts"),
    tool: Optional[str] = typer.Option(
        None,
        "--tool",
        "-t",
        help="Limit to one tool: claude | cursor | vscode | vscode-insiders | vscodium",
    ),
):
    """
    Re-fetch all installed MCP servers from the registry and update their configs.

    For every server injected across your AI tools, this command fetches the
    latest definition from the Agent-Corex registry and re-injects it if anything
    has changed (command, args, or env).

    Example:
        agent-corex update
        agent-corex update --tool claude --yes
    """
    try:
        import httpx
    except ImportError:
        typer.echo("httpx is required. Run: pip install httpx", err=True)
        raise typer.Exit(1)

    from agent_core import local_config

    base_url = local_config.get_base_url()
    all_pairs = _tool_pairs()

    if tool:
        t = tool.lower()
        all_pairs = [(k, d, a) for k, d, a in all_pairs if k == t]
        if not all_pairs:
            typer.echo(
                f"Unknown tool: {tool!r}. Use: claude, cursor, vscode, vscode-insiders, vscodium",
                err=True,
            )
            raise typer.Exit(1)

    _VSCODE_KEYS = {"vscode", "vscode-insiders", "vscodium"}

    # Cache registry responses so we only fetch each server name once
    _registry_cache: dict[str, dict | None] = {}

    def _fetch_entry(name: str) -> dict | None:
        if name in _registry_cache:
            return _registry_cache[name]
        try:
            with httpx.Client(timeout=8.0) as client:
                resp = client.get(f"{base_url}/mcp_registry/{name}")
                entry = resp.json() if resp.status_code == 200 else None
        except Exception:
            entry = None
        _registry_cache[name] = entry
        return entry

    def _build_def(entry: dict, vscode: bool) -> dict:
        base: dict = {"command": entry["command"], "args": entry.get("args", [])}
        if vscode:
            base = {"type": "stdio", **base}
        return base

    total_checked = total_updated = 0
    typer.echo("\nChecking for updates...\n")

    for slug, detector, adapter in all_pairs:
        if not detector.is_installed():
            continue

        servers = adapter.get_servers()
        is_vscode = slug in _VSCODE_KEYS

        for server_name, current_def in servers.items():
            if server_name == "agent-corex":
                continue  # agent-corex updates itself via pip

            total_checked += 1
            entry = _fetch_entry(server_name)
            if entry is None:
                typer.echo(f"  [?] {detector.name} / {server_name}: not in registry — skipping")
                continue

            new_def = _build_def(entry, is_vscode)

            # Compare only the fields we care about
            changed = (
                current_def.get("command") != new_def.get("command")
                or current_def.get("args") != new_def.get("args")
                or (is_vscode and current_def.get("type") != "stdio")
            )

            if not changed:
                typer.echo(f"  [=] {detector.name} / {server_name}: up to date")
                continue

            typer.echo(f"  [!] {detector.name} / {server_name}: update available")
            typer.echo(
                f"      current:  {current_def.get('command')} {' '.join(str(a) for a in current_def.get('args', []))}"
            )
            typer.echo(
                f"      registry: {new_def.get('command')} {' '.join(str(a) for a in new_def.get('args', []))}"
            )

            if not yes:
                confirmed = typer.confirm(
                    f"      Update '{server_name}' in {detector.name}?", default=True
                )
                if not confirmed:
                    typer.echo("      Skipped.")
                    continue

            # Preserve env vars the user set — only update command/args/type
            merged = {**current_def, **{k: v for k, v in new_def.items() if k != "env"}}
            bak = adapter.inject_server(server_name, merged)
            typer.echo(f"      [+] Updated")
            if bak:
                typer.echo(f"      Backup: {bak}")
            total_updated += 1

    typer.echo(f"\nChecked {total_checked} server(s). Updated {total_updated}.")
    if total_updated:
        typer.echo("Restart your AI tools for changes to take effect.")


@app.command()
def doctor():
    """
    Diagnose common setup issues.

    Checks Python version, dependencies, config file, backend connectivity,
    API key validity, and MCP injection status across all detected tools.

    Example:
        agent-corex doctor
    """
    import sys
    import shutil

    ok = "[+]"
    warn = "[!]"
    no = "[-]"
    issues: list[str] = []

    typer.echo("\nagent-corex doctor\n")

    # ── 1. Python version ────────────────────────────────────────────────────
    typer.echo("Python")
    major, minor = sys.version_info.major, sys.version_info.minor
    if major >= 3 and minor >= 8:
        typer.echo(f"  {ok} Python {major}.{minor} (>= 3.8 required)")
    else:
        typer.echo(f"  {no} Python {major}.{minor} — 3.8+ required")
        issues.append("Upgrade Python to 3.8 or newer.")

    # ── 2. Key dependencies ──────────────────────────────────────────────────
    typer.echo("\nDependencies")
    for pkg in ("httpx", "typer", "rich"):
        try:
            __import__(pkg)
            typer.echo(f"  {ok} {pkg}")
        except ImportError:
            typer.echo(f"  {no} {pkg} missing")
            issues.append(f"Install missing package:  pip install {pkg}")

    # ── 3. Config file ───────────────────────────────────────────────────────
    typer.echo("\nConfig")
    from agent_core import local_config

    cfg_path = local_config.CONFIG_FILE
    if cfg_path.exists():
        try:
            import json as _json

            _json.loads(cfg_path.read_text(encoding="utf-8"))
            typer.echo(f"  {ok} Config file exists and is valid JSON ({cfg_path})")
        except Exception:
            typer.echo(f"  {no} Config file exists but is not valid JSON ({cfg_path})")
            issues.append(f"Fix or delete corrupted config: {cfg_path}")
    else:
        typer.echo(f"  {warn} Config file not found — run  agent-corex login  first")
        issues.append("Run:  agent-corex login --key <your-api-key>")

    # ── 4. Auth ──────────────────────────────────────────────────────────────
    typer.echo("\nAuth")
    if local_config.is_logged_in():
        user = local_config.get("user") or {}
        name = user.get("name") or user.get("user_id") or "(unknown)"
        typer.echo(f"  {ok} Logged in as {name}")
    else:
        typer.echo(f"  {no} Not logged in")
        issues.append("Run:  agent-corex login --key <your-api-key>")

    # ── 5. Service connectivity ───────────────────────────────────────────────
    typer.echo("\nService")
    base_url = local_config.get_base_url()
    try:
        import httpx as _httpx

        resp = _httpx.get(f"{base_url}/health", timeout=5.0)
        if resp.status_code == 200:
            typer.echo(f"  {ok} Agent-CoreX service reachable")
        else:
            typer.echo(f"  {warn} Service responded with HTTP {resp.status_code}")
            issues.append(f"Agent-CoreX service returned unexpected status {resp.status_code}.")
    except Exception as e:
        typer.echo(f"  {no} Service unreachable: {e}")
        issues.append("Cannot reach Agent-CoreX. Check your internet connection.")

    # ── 6. API key verification ───────────────────────────────────────────────
    typer.echo("\nAPI Key")
    api_key = local_config.get("api_key")
    if not api_key:
        typer.echo(f"  {no} No API key stored")
    else:
        masked = api_key[:10] + "…" + api_key[-4:] if len(api_key) > 14 else "****"
        try:
            import httpx as _httpx

            resp = _httpx.post(
                f"{base_url}/auth/login",
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=5.0,
            )
            if resp.status_code == 200:
                typer.echo(f"  {ok} Key valid: {masked}")
            else:
                typer.echo(f"  {no} Key rejected (HTTP {resp.status_code}): {masked}")
                issues.append("API key is invalid. Run:  agent-corex login --key <new-key>")
        except Exception:
            typer.echo(f"  {warn} Key stored ({masked}) — could not verify (service unreachable)")

    # ── 7. Tool detection + injection ────────────────────────────────────────
    typer.echo("\nAI Tools")
    SERVER_NAME = "agent-corex"
    any_found = False
    any_injected = False
    for _, detector, adapter in _tool_pairs():
        if not detector.is_installed():
            typer.echo(f"  {no} {detector.name}: not installed")
            continue
        any_found = True
        injected = adapter.has_server(SERVER_NAME)
        mark = ok if injected else warn
        status = "injected" if injected else "NOT injected"
        typer.echo(f"  {mark} {detector.name}: {status}")
        if injected:
            any_injected = True

    if not any_found:
        typer.echo(f"  {no} No supported AI tools detected")
        issues.append("Install Claude Desktop, Cursor, or VS Code, then run  agent-corex init")
    elif not any_injected:
        issues.append("agent-corex is not injected into any tools. Run:  agent-corex init")

    # ── PATH check ───────────────────────────────────────────────────────────
    typer.echo("\nPATH")
    exe = shutil.which("agent-corex")
    if exe:
        typer.echo(f"  {ok} agent-corex found at {exe}")
    else:
        typer.echo(f"  {no} agent-corex not found in PATH")
        issues.append(
            "Add the Python Scripts directory to your PATH, or reinstall:  pip install agent-corex"
        )

    # ── Pack system ──────────────────────────────────────────────────────────
    typer.echo("\nPack System")
    installed_packs = PackManager.get_installed_packs()
    if installed_packs:
        typer.echo(f"  {ok} {len(installed_packs)} pack(s) installed")
        for pack_name, pack_data in installed_packs.items():
            servers = pack_data.get("servers", [])
            enabled = sum(1 for s in servers if pack_data.get("enabled", {}).get(s, False))
            typer.echo(f"      • {pack_name}: {enabled}/{len(servers)} servers enabled")
    else:
        typer.echo(f"  {warn} No packs installed")
        issues.append("Install a pack:  agent-corex install-pack vibe_coding_pack")

    # ── MCP Config ───────────────────────────────────────────────────────────
    typer.echo("\nMCP Configuration")
    mcp_config_file = pathlib.Path.home() / ".agent-corex" / "mcp.json"
    env_file = pathlib.Path.home() / ".agent-corex" / ".env"

    if mcp_config_file.exists():
        typer.echo(f"  {ok} mcp.json found: {mcp_config_file}")
        # Validate mcp.json
        from agent_core.mcp_config_generator import MCPConfigGenerator

        is_valid, errors = MCPConfigGenerator.validate_config(mcp_config_file)
        if is_valid:
            typer.echo(f"      ✓ Config is valid")
        else:
            for error in errors:
                typer.echo(f"      ✗ {error}")
                issues.append(f"Invalid mcp.json: {error}")
    else:
        typer.echo(f"  {warn} mcp.json not found")
        issues.append("Generate config:  agent-corex generate-mcp-config")

    if env_file.exists():
        from agent_core.env_manager import EnvManager

        env_vars = EnvManager.load_env()
        typer.echo(f"  {ok} .env file found with {len(env_vars)} variable(s)")
    else:
        typer.echo(f"  {warn} .env file not found")
        issues.append("Setup environment variables:  agent-corex setup-env")

    # ── Summary ──────────────────────────────────────────────────────────────
    typer.echo("\n" + "─" * 50)
    if not issues:
        typer.echo(f"{ok} All checks passed. Your setup looks healthy.")
    else:
        typer.echo(f"{warn} Found {len(issues)} issue(s):\n")
        for i, issue in enumerate(issues, 1):
            typer.echo(f"  {i}. {issue}")


@app.command(name="install-pack")
def install_pack(
    pack_name: str = typer.Argument(..., help="Pack name to install (e.g. vibe_coding_pack)"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompts"),
):
    """
    Install all MCP servers for a capability pack.

    A pack bundles multiple related capabilities and their MCP servers.

    This command:
    1. Registers the pack in ~/.agent-corex/installed_servers.json
    2. Marks servers as enabled
    3. Prepares to install them into detected AI tools

    \\b
    Example:
        agent-corex install-pack vibe_coding_pack
        agent-corex install-pack vibe_coding_pack --yes
    """
    # Get pack definition
    pack = PackManager.get_pack(pack_name)
    if not pack:
        typer.echo(f"\n✗ Pack '{pack_name}' not found.", err=True)
        available = list(PackManager.list_packs().keys())
        typer.echo(f"\nAvailable packs: {', '.join(available)}", err=True)
        raise typer.Exit(1)

    # Show pack info
    typer.echo(f"\n{pack['name']}")
    typer.echo(f"{pack['description']}")

    servers = PackManager.get_servers_for_pack(pack_name)
    typer.echo(f"\nServers to install ({len(servers)}):")
    for server in servers:
        env_note = (
            f"  (requires: {', '.join(server['env_required'])})" if server["env_required"] else ""
        )
        typer.echo(f"  • {server['name']}: {server['description']}{env_note}")

    # Confirm
    if not yes:
        confirmed = typer.confirm(
            f"\nRegister pack '{pack_name}' and install {len(servers)} server(s)?", default=True
        )
        if not confirmed:
            typer.echo("Aborted.")
            raise typer.Exit(0)

    # Register pack in installed_servers.json
    try:
        result = PackManager.install_pack(pack_name, enable_all=True)
        typer.echo(f"\n✓ Registered pack: {pack_name}")
        typer.echo(f"  Servers enabled: {len(result['servers'])}")
        for srv in result["servers"]:
            typer.echo(f"    • {srv}")
    except Exception as e:
        typer.echo(f"\n✗ Failed to register pack: {e}", err=True)
        raise typer.Exit(1)

    # Now inject into all detected tools
    typer.echo(f"\nInjecting servers into detected tools...")

    from agent_core.detectors import (
        ClaudeDesktopDetector,
        CursorDetector,
        VSCodeDetector,
        VSCodeInsidersDetector,
        VSCodiumDetector,
    )
    from agent_core.config_adapters import (
        ClaudeAdapter,
        CursorAdapter,
        VSCodeStableAdapter,
        VSCodeInsidersAdapter,
        VSCodiumAdapter,
    )

    tools = [
        ("claude", ClaudeDesktopDetector(), ClaudeAdapter()),
        ("cursor", CursorDetector(), CursorAdapter()),
        ("vscode", VSCodeDetector(), VSCodeStableAdapter()),
        ("vscode-insiders", VSCodeInsidersDetector(), VSCodeInsidersAdapter()),
        ("vscodium", VSCodiumDetector(), VSCodiumAdapter()),
    ]

    any_installed = False
    for tool_slug, detector, adapter in tools:
        if not detector.is_installed():
            continue

        for server in servers:
            server_name = server["name"]
            base_def = {
                "command": server["command"],
                "args": server.get("args", []),
            }
            if server.get("env"):
                base_def["env"] = server["env"]

            # VS Code needs "type": "stdio"
            if tool_slug in {"vscode", "vscode-insiders", "vscodium"}:
                server_def = {"type": "stdio", **base_def}
            else:
                server_def = base_def

            try:
                adapter.inject_server(server_name, server_def)
                any_installed = True
            except Exception as e:
                typer.echo(f"  ⚠ {detector.name}/{server_name}: {e}")

    if any_installed:
        typer.echo(f"\n✓ Servers injected into detected tools")
    else:
        typer.echo(f"\n⚠ No tools detected. Run: agent-corex init")

    typer.echo(f"\nNext steps:")
    typer.echo(f"  1. Run: agent-corex setup-env        (configure API keys)")
    typer.echo(f"  2. Run: agent-corex generate-mcp-config  (create unified config)")
    typer.echo(f"  3. Restart your AI tools for changes to take effect")

    # Notify backend (non-fatal — if not logged in, silently skip)
    _notify_backend_pack_installed(pack_name, [s["name"] for s in servers])


def _notify_backend_pack_installed(pack_name: str, server_names: list) -> None:
    """Push pack install state to backend. Non-fatal if not logged in or backend unreachable."""
    from agent_core import local_config

    auth_header = local_config.get_auth_header()
    if not auth_header:
        return  # Not logged in — skip notification

    base_url = local_config.get_base_url()

    # Read current local state from PackManager (source of truth — do NOT touch the files here)
    installed_pack_data = PackManager.get_installed_packs()
    all_packs = set(installed_pack_data.keys())
    all_servers: set = set()
    for pd in installed_pack_data.values():
        for srv in pd.get("servers", []):
            if pd.get("enabled", {}).get(srv, True):
                all_servers.add(srv)

    # Push to backend
    try:
        import httpx

        httpx.post(
            f"{base_url}/user/servers",
            headers={"Authorization": auth_header, "Content-Type": "application/json"},
            json={
                "installed_servers": sorted(all_servers),
                "installed_packs": sorted(all_packs),
            },
            timeout=10.0,
        )
    except Exception:
        pass  # Non-fatal


@app.command(name="apply")
def apply_skill(
    source: str = typer.Argument(
        ...,
        help="Path to a local skill.md file, or a URL to fetch it from.",
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip all confirmation prompts"),
):
    """
    Apply a skill.md file — install packs, configure env, and set up MCP.

    A skill.md is a declarative install spec inspired by Smithery, extended for
    Agent-CoreX packs and MCP orchestration. It can be a local file or a URL.

    \\b
    What this does:
      1. Fetch (or load) the skill.md
      2. Parse name, type, env requirements, MCP servers, and connect block
      3. Run optional pre-install command (e.g. npm install)
      4. Prompt for any missing environment variables
      5. Save env vars to ~/.agent-corex/.env
      6. Inject MCP servers into all detected AI tools (Claude, Cursor, VS Code…)
      7. Regenerate ~/.agent-corex/mcp.json
      8. Display test prompt so you can verify the skill works
      9. Sync install metadata to backend (if logged in)

    \\b
    Examples:
        agent-corex apply ./vibe_coding.skill.md
        agent-corex apply https://skills.agent-corex.com/vibe_coding.md
        agent-corex apply ./deploy.skill.md --yes
    """
    from agent_core import skill_parser, skill_installer

    # ── Load skill.md ────────────────────────────────────────────────────────
    is_url = source.startswith("http://") or source.startswith("https://")

    typer.echo(f"\nLoading skill from {'URL' if is_url else 'file'}: {source}")

    try:
        if is_url:
            spec = skill_parser.fetch_and_parse(source)
        else:
            import pathlib

            path = pathlib.Path(source)
            if not path.exists():
                typer.echo(f"\n✗ File not found: {source}", err=True)
                raise typer.Exit(1)
            spec = skill_parser.parse_file(str(path))
    except typer.Exit:
        raise
    except Exception as exc:
        typer.echo(f"\n✗ Failed to load skill.md: {exc}", err=True)
        raise typer.Exit(1)

    typer.echo(f"  ✓ Parsed skill: {spec.name!r} (type={spec.type})")

    # Show summary before proceeding
    if spec.requires:
        typer.echo(f"  Servers: {', '.join(spec.requires)}")
    if spec.env:
        req = [k for k, v in spec.env.items() if v == "required"]
        opt = [k for k, v in spec.env.items() if v == "optional"]
        if req:
            typer.echo(f"  Env required: {', '.join(req)}")
        if opt:
            typer.echo(f"  Env optional: {', '.join(opt)}")
    if spec.install:
        typer.echo(f"  Install cmd: {spec.install}")
    if spec.test:
        typer.echo(f"  Test: {spec.test!r}")

    if not yes:
        confirmed = typer.confirm("\nProceed with installation?", default=True)
        if not confirmed:
            typer.echo("Aborted.")
            raise typer.Exit(0)

    # ── Run installer ─────────────────────────────────────────────────────────
    try:
        installer = skill_installer.SkillInstaller(spec, yes=yes, verbose=True)
        success = installer.run()
        if not success:
            typer.echo("\nInstallation aborted by user.", err=True)
            raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as exc:
        typer.echo(f"\n✗ Installation failed: {exc}", err=True)
        raise typer.Exit(1)

    typer.echo("Restart your AI tools for MCP changes to take effect.\n")


@app.command(name="generate-mcp-config")
def generate_mcp_config():
    """
    Generate ~/.agent-corex/mcp.json from all installed MCP servers.

    This command:
    1. Scans all detected AI tools for MCP servers
    2. Merges them into a unified config file
    3. Injects environment variables if ~/.agent-corex/.env exists

    The generated config can be used by:
    - agent-corex serve (MCP gateway)
    - Local MCP client connections

    \\b
    Example:
        agent-corex generate-mcp-config
    """
    from agent_core.mcp_config_generator import MCPConfigGenerator

    typer.echo("\nGenerating MCP configuration...\n")
    typer.echo("Scanning installed tools:")

    try:
        config = MCPConfigGenerator.generate_config(include_env=True)
        config_file = MCPConfigGenerator.write_config(config)

        servers = config.get("mcpServers", {})

        typer.echo(f"\n✓ Generated {config_file}")
        typer.echo(f"  Servers collected: {len(servers)}")
        for name in sorted(servers.keys()):
            typer.echo(f"    • {name}")

        # Validate the config
        is_valid, errors = MCPConfigGenerator.validate_config(config_file)
        if is_valid:
            typer.echo(f"\n✓ Config is valid and ready to use")
        else:
            typer.echo(f"\n⚠ Config has warnings:")
            for error in errors:
                typer.echo(f"    • {error}")

        typer.echo(f"\nNext steps:")
        typer.echo(f"  • Run: agent-corex serve        (start MCP gateway)")
        typer.echo(f"  • Run: agent-corex status       (verify setup)")

    except Exception as e:
        typer.echo(f"\n✗ Error generating config: {e}", err=True)
        raise typer.Exit(1)


@app.command(name="setup-env")
def setup_env():
    """
    Set up environment variables for MCP servers in ~/.agent-corex/.env.

    This command:
    1. Prompts for common API keys and connection strings
    2. Saves them securely in ~/.agent-corex/.env
    3. These are automatically injected into all MCP servers

    Supported variables include:
    - OPENAI_API_KEY, ANTHROPIC_API_KEY
    - SUPABASE_URL, SUPABASE_KEY, SUPABASE_ACCESS_TOKEN
    - REDIS_URL, RAILWAY_API_KEY, RENDER_API_KEY
    - GITHUB_TOKEN, AGENT_COREX_API_KEY

    \\b
    Example:
        agent-corex setup-env
    """
    from agent_core.env_manager import EnvManager

    typer.echo("\n=== Agent-Corex Environment Setup ===\n")
    typer.echo("Configure API keys and connection strings.")
    typer.echo("Press Enter to skip a variable or keep the existing value.\n")

    # Interactive setup
    new_env = EnvManager.interactive_setup()

    if not new_env:
        typer.echo("\nNo environment variables set.")
        return

    # Validate
    is_valid, errors = EnvManager.validate_keys(new_env)

    if not is_valid:
        typer.echo("\n⚠ Validation warnings:")
        for error in errors:
            typer.echo(f"  • {error}")

    # Confirm save
    confirmed = typer.confirm(
        f"\nSave {len(new_env)} variable(s) to ~/.agent-corex/.env?", default=True
    )
    if not confirmed:
        typer.echo("Aborted.")
        return

    # Save
    try:
        env_file = EnvManager.save_env(new_env)
        masked = EnvManager.mask_values(new_env)

        typer.echo(f"\n✓ Saved {env_file}")
        typer.echo(f"  Variables configured: {len(new_env)}")
        for k, v in sorted(masked.items()):
            typer.echo(f"    • {k} = {v}")

        typer.echo(f"\nNext step:")
        typer.echo(f"  Run: agent-corex generate-mcp-config")
    except Exception as e:
        typer.echo(f"\n✗ Error saving environment: {e}", err=True)
        raise typer.Exit(1)


# ═══════════════════════════════════════════════════════════════════════════
# uvx-native commands: pack · mcp (group) · execute · plan
# ═══════════════════════════════════════════════════════════════════════════

# ── Pack sub-app ──────────────────────────────────────────────────────────────

_pack_app = typer.Typer(
    name="pack",
    help="Manage Agent-CoreX packs (install curated MCP server bundles).",
    no_args_is_help=True,
)
app.add_typer(_pack_app, name="pack")


@_pack_app.command("list")
def pack_list() -> None:
    """List all installed packs.

    Example:
        uvx agent-corex pack list
    """
    from agent_core.uvx.pack_manager import PackManager

    packs = PackManager().list_packs()

    if not packs:
        typer.echo("No packs installed.")
        typer.echo("Install one:  uvx agent-corex pack install <name>")
        return

    typer.echo(f"\nInstalled packs  ({len(packs)})\n")
    for name, meta in packs.items():
        servers = meta.get("mcp_servers", [])
        desc = meta.get("description", "")
        installed_at = meta.get("installed_at", "")[:10]
        typer.echo(f"  {name}")
        if desc:
            typer.echo(f"    {desc}")
        typer.echo(f"    MCP servers : {', '.join(servers) if servers else '—'}")
        typer.echo(f"    Installed   : {installed_at}")
        typer.echo("")


@_pack_app.command("install")
def pack_install(
    name: str = typer.Argument(..., help="Pack name to install, e.g. 'youtube-productivity'"),
) -> None:
    """Fetch a pack definition from the API and install its MCP servers.

    Example:
        uvx agent-corex pack install youtube-productivity
    """
    from agent_core.uvx.pack_manager import PackManager

    typer.echo(f"\nInstalling pack '{name}'...")

    try:
        result = PackManager().install_pack(name)
    except PermissionError as exc:
        typer.echo(f"\n✗ {exc}", err=True)
        raise typer.Exit(1)
    except ValueError as exc:
        typer.echo(f"\n✗ {exc}", err=True)
        raise typer.Exit(1)
    except RuntimeError as exc:
        typer.echo(f"\n✗ {exc}", err=True)
        raise typer.Exit(1)

    typer.echo(f"\n✓ Pack '{result['display_name']}' installed")
    if result.get("description"):
        typer.echo(f"  {result['description']}")

    added = result.get("servers_added", [])
    skipped = result.get("servers_skipped", [])

    if added:
        typer.echo(f"\n  MCP servers added   : {', '.join(added)}")
    if skipped:
        typer.echo(f"  MCP servers skipped : {', '.join(skipped)} (already installed)")

    if result.get("tools"):
        typer.echo(f"\n  Tools available: {', '.join(result['tools'])}")

    typer.echo("\nNext step:  uvx agent-corex mcp list  to verify installed servers.")


@_pack_app.command("remove")
def pack_remove(
    name: str = typer.Argument(..., help="Pack name to remove"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Remove a pack from the local registry.

    Note: MCP servers added by the pack are NOT removed automatically.
    Use  uvx agent-corex mcp remove <server>  to remove individual servers.

    Example:
        uvx agent-corex pack remove youtube-productivity
    """
    from agent_core.uvx.pack_manager import PackManager

    if not yes:
        confirmed = typer.confirm(f"Remove pack '{name}'?", default=True)
        if not confirmed:
            typer.echo("Aborted.")
            return

    removed = PackManager().remove_pack(name)

    if removed:
        typer.echo(f"✓ Pack '{name}' removed from registry.")
        typer.echo(
            "  MCP servers installed by this pack are still active.\n"
            "  Remove them with:  uvx agent-corex mcp remove <server>"
        )
    else:
        typer.echo(f"Pack '{name}' is not installed.", err=True)
        raise typer.Exit(1)


# ── MCP registry sub-app ──────────────────────────────────────────────────────
# ``uvx agent-corex mcp``          → starts the MCP gateway server (stdio)
# ``uvx agent-corex mcp list``     → lists registry servers
# ``uvx agent-corex mcp add <n>``  → installs server from API
# ``uvx agent-corex mcp remove <n>``

_mcp_app = typer.Typer(
    name="mcp",
    help=("Manage MCP servers in the local registry, " "or start the MCP gateway (no subcommand)."),
    invoke_without_command=True,
)
app.add_typer(_mcp_app, name="mcp")


@_mcp_app.callback()
def _mcp_callback(ctx: typer.Context) -> None:
    """
    Manage MCP servers — or start the MCP gateway when called with no subcommand.

    \\b
    With no subcommand:
        uvx agent-corex mcp        → starts the MCP gateway server (stdio mode)

    Subcommands:
        uvx agent-corex mcp list
        uvx agent-corex mcp add <name>
        uvx agent-corex mcp remove <name>
    """
    if ctx.invoked_subcommand is None:
        # No subcommand → start MCP gateway server (reuse existing gateway_server)
        from agent_core.gateway.gateway_server import run

        run()


@_mcp_app.command("list")
def mcp_registry_list() -> None:
    """List all MCP servers in the local registry.

    Example:
        uvx agent-corex mcp list
    """
    from agent_core.uvx.mcp_manager import MCPManager

    servers = MCPManager().list_servers()

    if not servers:
        typer.echo("No MCP servers installed in registry.")
        typer.echo("Add one:  uvx agent-corex mcp add <name>")
        return

    typer.echo(f"\nInstalled MCP servers  ({len(servers)})\n")
    for name, cfg in servers.items():
        cmd_str = cfg.get("command", "") + " " + " ".join(cfg.get("args", []))
        source = cfg.get("source", "manual")
        desc = cfg.get("description", "")
        env_req = cfg.get("env_required", [])
        installed_at = cfg.get("installed_at", "")[:10]

        typer.echo(f"  {name}")
        if desc:
            typer.echo(f"    {desc}")
        typer.echo(f"    Command  : {cmd_str.strip()}")
        typer.echo(f"    Source   : {source}")
        if env_req:
            typer.echo(f"    Env keys : {', '.join(env_req)}")
        typer.echo(f"    Added    : {installed_at}")
        typer.echo("")


@_mcp_app.command("add")
def mcp_registry_add(
    name: str = typer.Argument(..., help="Server name to add, e.g. 'filesystem'"),
) -> None:
    """Fetch an MCP server config from the API and add it to the registry.

    Example:
        uvx agent-corex mcp add filesystem
        uvx agent-corex mcp add github
    """
    from agent_core.uvx.mcp_manager import MCPManager

    typer.echo(f"\nFetching MCP server '{name}' from registry...")

    try:
        result = MCPManager().add_server(name)
    except PermissionError as exc:
        typer.echo(f"\n✗ {exc}", err=True)
        raise typer.Exit(1)
    except ValueError as exc:
        typer.echo(f"\n✗ {exc}", err=True)
        raise typer.Exit(1)
    except RuntimeError as exc:
        typer.echo(f"\n✗ {exc}", err=True)
        raise typer.Exit(1)

    cmd_str = result["command"] + " " + " ".join(result.get("args", []))
    typer.echo(f"\n✓ MCP server '{name}' added to registry")
    typer.echo(f"  Command : {cmd_str.strip()}")
    if result.get("description"):
        typer.echo(f"  Info    : {result['description']}")
    if result.get("env_required"):
        typer.echo(f"  Needs   : {', '.join(result['env_required'])}")
    typer.echo("\nTo start the gateway with all registry servers:\n" "  uvx agent-corex mcp")


@_mcp_app.command("remove")
def mcp_registry_remove(
    name: str = typer.Argument(..., help="Server name to remove"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Remove an MCP server from the local registry.

    Example:
        uvx agent-corex mcp remove filesystem
    """
    from agent_core.uvx.mcp_manager import MCPManager

    if not yes:
        confirmed = typer.confirm(f"Remove MCP server '{name}' from registry?", default=True)
        if not confirmed:
            typer.echo("Aborted.")
            return

    removed = MCPManager().remove_server(name)

    if removed:
        typer.echo(f"✓ MCP server '{name}' removed from registry.")
    else:
        typer.echo(f"MCP server '{name}' is not in the registry.", err=True)
        raise typer.Exit(1)


# ── execute ───────────────────────────────────────────────────────────────────


@app.command()
def execute(
    task: str = typer.Argument(..., help="Natural-language task description"),
    tool: Optional[str] = typer.Option(
        None, "--tool", "-t", help="Force a specific tool name (auto-selected if omitted)"
    ),
    top_k: int = typer.Option(5, "--top-k", "-k", help="Candidate tool pool size"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON result"),
) -> None:
    """Execute a task via the Agent-CoreX backend.

    Auto-selects the best tool via semantic retrieval, then calls /execute_tool.

    \\b
    Examples:
        uvx agent-corex execute "summarize my latest YouTube video"
        uvx agent-corex execute "list files in /tmp" --tool filesystem_list
        uvx agent-corex execute "deploy my app" --json
    """
    from agent_core.uvx.executor import Executor

    typer.echo(f"\nExecuting: {task!r}\n")

    try:
        result = Executor().execute_task(task, tool_name=tool, top_k=top_k)
    except PermissionError as exc:
        typer.echo(f"✗ {exc}", err=True)
        raise typer.Exit(1)
    except RuntimeError as exc:
        typer.echo(f"✗ {exc}", err=True)
        raise typer.Exit(1)

    if json_output:
        import json as _json

        typer.echo(_json.dumps(result, indent=2))
        return

    status_icon = "✓" if result.get("status") == "success" else "✗"
    typer.echo(f"{status_icon} Tool: {result['tool']}\n")

    output = result.get("result", "")
    if isinstance(output, str):
        typer.echo(output)
    else:
        import json as _json

        typer.echo(_json.dumps(output, indent=2))


# ── plan ──────────────────────────────────────────────────────────────────────


@app.command()
def plan(
    task: str = typer.Argument(..., help="Natural-language task description"),
    top_k: int = typer.Option(5, "--top-k", "-k", help="Number of candidate tools to show"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON plan"),
) -> None:
    """Generate a tool execution plan for a task (no execution, dry-run only).

    Retrieves the most relevant tools from the backend and shows them as
    ordered steps — useful for understanding what will run before you commit.

    \\b
    Examples:
        uvx agent-corex plan "summarize my latest YouTube video"
        uvx agent-corex plan "deploy my app to Railway" --top-k 3
        uvx agent-corex plan "analyse sales data" --json
    """
    from agent_core.uvx.executor import Executor

    typer.echo(f"\nGenerating plan for: {task!r}\n")

    try:
        result = Executor().get_tool_plan(task, top_k=top_k)
    except PermissionError as exc:
        typer.echo(f"✗ {exc}", err=True)
        raise typer.Exit(1)
    except RuntimeError as exc:
        typer.echo(f"✗ {exc}", err=True)
        raise typer.Exit(1)

    if json_output:
        import json as _json

        typer.echo(_json.dumps(result, indent=2))
        return

    steps = result.get("steps", [])
    if not steps:
        note = result.get("note", "No tools found.")
        typer.echo(f"  {note}")
        return

    typer.echo(f"  {len(steps)} tool(s) selected\n")
    for step in steps:
        score_pct = int(step.get("score", 0) * 100)
        server = f"  [{step['server']}]" if step.get("server") else ""
        typer.echo(f"  Step {step['step']}: {step['tool']}{server}  ({score_pct}% match)")
        if step.get("description"):
            typer.echo(f"           {step['description']}")
        typer.echo("")

    typer.echo(f'Run it:  uvx agent-corex execute "{task}"')


@app.command(name="mcp-config")
def mcp_config(
    uvx: bool = typer.Option(
        True,
        "--uvx/--binary",
        help="Show uvx-based config (default) or installed-binary config.",
    ),
    key: Optional[str] = typer.Option(
        None,
        "--key",
        "-k",
        help="API key to embed in the config (default: reads from stored credentials).",
    ),
) -> None:
    """
    Print ready-to-paste MCP config snippets for Claude / Cursor / VS Code.

    The AGENT_COREX_API_KEY value is read from your stored credentials
    (agent-corex login) or can be supplied with --key.
    If no key is available a placeholder is shown instead.

    \\b
    Get your API key at: https://www.agent-corex.com/dashboard/keys

    \\b
    Examples:
        agent-corex mcp-config              # uvx variant (default)
        agent-corex mcp-config --binary     # installed-binary variant
        agent-corex mcp-config --key acx_abc123
    """
    import json as _json

    from agent_core import local_config

    _KEYS_URL = "https://www.agent-corex.com/dashboard/keys"

    # Resolve API key
    api_key = key or local_config.get_api_key()
    if not api_key:
        typer.echo(
            f"\n  No API key configured.\n"
            f"  Get yours at: {_KEYS_URL}\n"
            f"  Then run:     agent-corex login --key <key>\n"
            f"  Or pass it directly: agent-corex mcp-config --key acx_...\n",
            err=True,
        )
        api_key = "<YOUR_AGENT_COREX_API_KEY>"

    if uvx:
        claude_cursor_def = {
            "command": "uvx",
            "args": ["agent-corex", "mcp"],
            "env": {"AGENT_COREX_API_KEY": api_key},
        }
        vscode_def = {
            "type": "stdio",
            "command": "uvx",
            "args": ["agent-corex", "mcp"],
            "env": {"AGENT_COREX_API_KEY": api_key},
        }
        launch_note = "uvx  (no global install of agent-corex required)"
    else:
        claude_cursor_def = {"command": "agent-corex", "args": ["serve"]}
        vscode_def = {"type": "stdio", "command": "agent-corex", "args": ["serve"]}
        launch_note = "installed binary  (agent-corex must be on PATH)"

    server_block_cc = {"mcpServers": {"agent-corex": claude_cursor_def}}
    server_block_vs = {"mcpServers": {"agent-corex": vscode_def}}

    typer.echo(f"\nAgent-CoreX MCP config  [{launch_note}]\n")
    typer.echo("─" * 60)

    typer.echo("\n Claude Desktop  (~/.claude/claude_desktop_config.json)")
    typer.echo(" Cursor          (~/.cursor/mcp.json)\n")
    typer.echo(_json.dumps(server_block_cc, indent=2))

    typer.echo("\n─" * 1 + "─" * 59)
    typer.echo('\n VS Code / Cursor settings.json  ("mcp" block)\n')
    typer.echo(_json.dumps(server_block_vs, indent=2))

    typer.echo("\n─" * 1 + "─" * 59)

    if uvx and api_key != "<YOUR_AGENT_COREX_API_KEY>":
        masked = api_key[:10] + "..." + api_key[-4:] if len(api_key) > 14 else "***"
        typer.echo(f"\n  API key : {masked}  (from stored credentials)")
    elif uvx:
        typer.echo(f"\n  API key : placeholder — replace before use")
        typer.echo(f"  Get key : {_KEYS_URL}")

    typer.echo("\nPaste the relevant block into your tool's config, then restart the tool.")
    if uvx:
        typer.echo("Tip: auto-inject with  agent-corex init --uvx  instead of pasting manually.")


if __name__ == "__main__":
    app()
