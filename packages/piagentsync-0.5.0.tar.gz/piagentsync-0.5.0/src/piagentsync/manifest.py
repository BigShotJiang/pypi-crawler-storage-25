"""Manifest parser using python-frontmatter."""

from pathlib import Path

import frontmatter  # type: ignore[import-untyped]

from .errors import ManifestNotFoundError, ManifestParseError
from .models import ProjectManifest


def parse_manifest(path: Path) -> ProjectManifest:
    """Parse YAML frontmatter from an AGENTS.md file.

    Raises:
        ManifestNotFoundError: If the file does not exist.
        ManifestParseError: If frontmatter is missing or malformed.
        pydantic.ValidationError: If required fields fail validation.
    """
    if not path.exists():
        raise ManifestNotFoundError(f"Manifest file not found: {path}")

    try:
        post = frontmatter.load(str(path))
    except Exception as e:
        raise ManifestParseError(f"Failed to parse frontmatter: {e}") from e

    if not post.metadata:
        raise ManifestParseError("No frontmatter found")

    return ProjectManifest(**post.metadata)
