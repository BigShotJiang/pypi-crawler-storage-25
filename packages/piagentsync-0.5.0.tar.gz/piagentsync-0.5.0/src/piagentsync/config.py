"""Configuration management for piagentsync."""

from functools import lru_cache
from pathlib import Path

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings

from .errors import VaultNotFoundError


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    vault_path: Path = Field(
        default=Path("~/vault"), description="Path to Obsidian vault"
    )
    global_opencode_path: Path = Field(
        default=Path("~/.config/opencode"),
        description="Path to global OpenCode config",
    )
    vault_github_user: str = Field(
        default="Piwero",
        description="GitHub username for vault repository (used in clone instructions)",
    )

    model_config = {
        "env_prefix": "PIAGENTSYNC_",
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "case_sensitive": False,
    }

    @field_validator("vault_path", "global_opencode_path", mode="after")
    @classmethod
    def expand_paths(cls, v: Path) -> Path:
        """Expand user home and resolve to absolute path."""
        return v.expanduser().resolve()


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return a cached Settings instance."""
    return Settings()


def ensure_vault_exists(settings: Settings) -> None:
    """Check that the vault directory exists.

    Raises:
        VaultNotFoundError: If vault does not exist, with a helpful clone message.
    """
    if not settings.vault_path.exists():
        clone_url = f"git@github.com:{settings.vault_github_user}/vault.git"
        raise VaultNotFoundError(
            f"Vault not found at {settings.vault_path.resolve()}\n"
            f"Clone it first: git clone {clone_url} ~/vault"
        )
