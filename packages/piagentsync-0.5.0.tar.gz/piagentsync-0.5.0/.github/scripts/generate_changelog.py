#!/usr/bin/env python3
"""Generate changelog entry from conventional commits and compute next version.

This script:
1. Finds the latest stable semantic version tag (vX.Y.Z)
2. Computes the next version based on the BUMP input (MAJOR/MINOR/PATCH/RC)
3. Gathers conventional commit messages since that tag
4. Categorizes and formats them into a changelog entry
5. Prepends the entry to CHANGELOG.md
6. Outputs GITHUB_OUTPUT variables: new_version and tag_name
"""

import os
import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path


def run_git(*args):
    """Run a git command and return stdout."""
    result = subprocess.run(
        ["git"] + list(args), capture_output=True, text=True, check=True
    )
    return result.stdout.strip()


def get_latest_stable_tag():
    """Get the latest vX.Y.Z tag (ignoring -rc tags)."""
    try:
        tags = run_git("tag", "-l", "v*", "--sort=-v:refname").splitlines()
    except subprocess.CalledProcessError:
        return None

    for tag in tags:
        # Match only pure semver without suffix
        if re.fullmatch(r"v\d+\.\d+\.\d+", tag):
            return tag
    return None


def parse_version(tag):
    """Parse vX.Y.Z into (major, minor, patch)."""
    if tag is None:
        return (0, 0, 0)
    m = re.match(r"v(\d+)\.(\d+)\.(\d+)", tag)
    if not m:
        return (0, 0, 0)
    return tuple(int(x) for x in m.groups())


def bump_version(major, minor, patch, bump_type):
    """Return (new_major, new_minor, new_patch, suffix)."""
    suffix = ""
    if bump_type == "MAJOR":
        major += 1
        minor = 0
        patch = 0
    elif bump_type == "MINOR":
        minor += 1
        patch = 0
    elif bump_type == "PATCH":
        patch += 1
    elif bump_type == "RC":
        patch += 1
        suffix = "-rc"
    else:
        raise ValueError(f"Unknown bump type: {bump_type}")
    return major, minor, patch, suffix


def get_commits_since_tag(tag):
    """Get commit messages from tag..HEAD (or all if tag is None)."""
    if tag is None:
        # All commits reachable from HEAD
        rev_range = "HEAD"
    else:
        rev_range = f"{tag}..HEAD"

    # Get conventional commits; format: <type>(<scope>): <subject>
    # We'll grab the full subject line (skip body for changelog)
    log = run_git("log", rev_range, "--pretty=format:%s", "--no-merges")
    commits = [line.strip() for line in log.splitlines() if line.strip()]
    return commits


def categorize_commits(commits):
    """Map conventional commit types to changelog headings."""
    mapping = {
        "feat": "Added",
        "fix": "Fixed",
        "perf": "Performance",
        "docs": "Documentation",
        "style": "Style",
        "refactor": "Refactored",
        "test": "Tests",
        "chore": "Chores",
        "ci": "CI/CD",
        "build": "Build",
        "revert": "Reverts",
    }
    categories: dict[str, list[str]] = {v: [] for v in mapping.values()}
    categories["Other"] = []

    for msg in commits:
        m = re.match(r"^([a-zA-Z]+)(?:\([^)]+\))?!?:\s*(.+)", msg)
        if m:
            commit_type = m.group(1).lower()
            heading = mapping.get(commit_type, "Other")
            categories[heading].append(f"- {msg}")
        else:
            # Non-conventional or cannot parse: include verbatim under Other
            categories["Other"].append(f"- {msg}")

    # Remove empty categories
    return {k: v for k, v in categories.items() if v}


def format_changelog_entry(version, date, categories):
    """Format a single changelog entry for the given version."""
    lines = [f"\n## [{version}] - {date}\n"]
    for heading in [
        "Added",
        "Fixed",
        "Performance",
        "Documentation",
        "Style",
        "Refactored",
        "Tests",
        "Chores",
        "CI/CD",
        "Build",
        "Reverts",
        "Other",
    ]:
        items = categories.get(heading)
        if items:
            lines.append(f"### {heading}\n" + "\n".join(items) + "\n")
    return "".join(lines).strip() + "\n"


def prepend_to_changelog(entry, changelog_path):
    """Prepend entry to CHANGELOG.md, after any header."""
    path = Path(changelog_path)
    if not path.exists():
        # Create minimal file with entry at top
        header = "# Changelog\n\nAll notable changes to this project will be documented in this file.\n\n"
        path.write_text(header + entry)
        return

    content = path.read_text(encoding="utf-8")
    # Find the position of the first existing "## [" section
    match = re.search(r"(?m)^## \[", content)
    if match:
        insert_pos = match.start()
        new_content = content[:insert_pos] + entry + content[insert_pos:]
    else:
        # No existing entries, just append after header (or at end)
        new_content = content.rstrip() + "\n\n" + entry

    path.write_text(new_content, encoding="utf-8")


def get_rc_tags(base_version):
    """Get all existing RC tags for a base version like v0.0.1.
    Returns list of (tag, number) tuples."""
    prefix = f"v{base_version}-rc"
    try:
        all_tags = run_git("tag", "-l", f"{prefix}*").splitlines()
    except subprocess.CalledProcessError:
        return []
    rc_tags = []
    rc_pattern = re.compile(rf"^{re.escape(prefix)}\.(\d+)$")
    for tag in all_tags:
        m = rc_pattern.match(tag)
        if m:
            num = int(m.group(1))
            rc_tags.append((tag, num))
    return rc_tags


def tag_exists(tag):
    """Check if a git tag exists."""
    try:
        existing = run_git("tag", "-l", tag)
        return tag in existing.splitlines()
    except subprocess.CalledProcessError:
        return False


def main():
    bump = os.getenv("BUMP")
    if not bump:
        print("Error: BUMP environment variable not set", file=sys.stderr)
        sys.exit(1)

    changelog_path = Path("CHANGELOG.md")

    latest_stable_tag = get_latest_stable_tag()
    major, minor, patch = parse_version(latest_stable_tag)
    new_major, new_minor, new_patch, suffix = bump_version(major, minor, patch, bump)
    base_version = f"{new_major}.{new_minor}.{new_patch}"

    # Determine the starting tag for commit collection
    # and the final version with RC number if needed.
    if suffix == "-rc":
        # For RCs, we want numbered suffixes like -rc.1, -rc.2, ...
        rc_tags = get_rc_tags(base_version)
        if rc_tags:
            # Start from the latest existing RC tag
            latest_rc_tag, max_num = max(rc_tags, key=lambda x: x[1])
            rc_num = max_num + 1
            start_tag = latest_rc_tag  # only include new commits since last RC
        else:
            # First RC for this base version; start from latest stable
            rc_num = 1
            start_tag = latest_stable_tag
        suffix = f"-rc.{rc_num}"
        new_version = f"{base_version}{suffix}"
    else:
        # For non-RC releases, start from latest stable tag (previous release)
        start_tag = latest_stable_tag
        new_version = base_version

    tag_name = f"v{new_version}"

    # Check if tag already exists
    if tag_exists(tag_name):
        print(
            f"Error: Tag '{tag_name}' already exists. Choose a different bump or delete the existing tag.",
            file=sys.stderr,
        )
        sys.exit(1)

    commits = get_commits_since_tag(start_tag)
    categories = categorize_commits(commits)

    date_str = datetime.now().strftime("%Y-%m-%d")
    entry = format_changelog_entry(new_version, date_str, categories)

    prepend_to_changelog(entry, changelog_path)

    # Set GITHUB_OUTPUT
    gh_output = os.getenv("GITHUB_OUTPUT")
    if gh_output:
        with open(gh_output, "a", encoding="utf-8") as f:
            f.write(f"new_version={new_version}\n")
            f.write(f"tag_name={tag_name}\n")
    else:
        # For local testing: print to stdout
        print(f"::set-output name=new_version::{new_version}")
        print(f"::set-output name=tag_name::{tag_name}")

    print(f"Generated changelog for {tag_name}")


if __name__ == "__main__":
    main()
