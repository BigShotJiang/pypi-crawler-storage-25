"""Tests for data models."""

from pathlib import Path

import pytest

from piagentsync.models import (
    EntryKind,
    ProjectManifest,
    SyncEntry,
    SyncResult,
)


def test_project_manifest_valid() -> None:
    """Parses a well-formed manifest with all fields correct."""
    manifest = ProjectManifest(
        project="myproject",
        workspace=Path("~/workspace/myproject"),
        notion_board_id="12345",
        notion_project_filter="myproject",
    )
    assert manifest.project == "myproject"
    # workspace should be expanded
    assert manifest.workspace.is_absolute()
    assert manifest.workspace.name == "myproject"


def test_project_manifest_invalid_slug() -> None:
    """Raises ValidationError for project slug with spaces or uppercase."""
    with pytest.raises(ValueError, match="project must be lowercase"):
        ProjectManifest(project="My Project", workspace=Path("/tmp/foo"))


def test_project_manifest_workspace_expanded() -> None:
    """Workspace path expands user home and resolves."""
    manifest = ProjectManifest(project="test", workspace=Path("~/myworkspace"))
    assert manifest.workspace.is_absolute()
    # It should be under the actual home directory, not containing tilde
    assert "~" not in str(manifest.workspace)


def test_sync_result_total() -> None:
    """Total property returns sum of written, skipped, errors."""
    result = SyncResult(
        written=[
            SyncEntry(
                name="a",
                source=Path("/src/a.md"),
                destination=Path("/dst/a.md"),
                kind=EntryKind.AGENT,
            )
        ],
        skipped=[
            SyncEntry(
                name="b",
                source=Path("/src/b.md"),
                destination=Path("/dst/b.md"),
                kind=EntryKind.SKILL,
            )
        ],
        errors=[
            (
                SyncEntry(
                    name="c",
                    source=Path("/src/c.md"),
                    destination=Path("/dst/c.md"),
                    kind=EntryKind.AGENT,
                ),
                "error",
            )
        ],
    )
    assert result.total == 3


def test_sync_result_summary_line_format() -> None:
    """summary_line returns correct string."""
    result = SyncResult(written=[], skipped=[], errors=[])
    assert (
        "0 written" in result.summary_line
        and "0 skipped" in result.summary_line
        and "0 errors" in result.summary_line
    )
    # Create a proper SyncEntry for testing
    e = SyncEntry(
        name="e", source=Path("/s"), destination=Path("/d"), kind=EntryKind.AGENT
    )
    result2 = SyncResult(written=[e], skipped=[e], errors=[(e, "oops")])
    assert result2.summary_line == "1 written · 1 skipped · 1 errors"


def test_entry_kind_values() -> None:
    """EntryKind has expected values."""
    assert EntryKind.AGENT == "agent"
    assert EntryKind.SKILL == "skill"
    assert EntryKind.CONTEXT_FILE == "context_file"
