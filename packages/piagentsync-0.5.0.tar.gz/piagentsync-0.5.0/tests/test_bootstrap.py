"""Tests for bootstrap command."""

import subprocess
from pathlib import Path
from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from piagentsync.cli import app

runner = CliRunner()


def test_bootstrap_vault_missing(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Exits 1 with helpful clone message when vault does not exist."""
    vault = tmp_path / "vault"
    monkeypatch.setenv("PIAGENTSYNC_VAULT_PATH", str(vault))
    result = runner.invoke(app, ["bootstrap"])
    assert result.exit_code == 1
    assert "Vault not found at" in result.stdout
    assert "Clone it first:" in result.stdout
    assert "git@github.com:Piwero/vault.git ~/vault" in result.stdout


def test_bootstrap_fresh_install(
    vault_with_global_agents: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Writes opencode.json and copies chief-pm on fresh install."""
    vault = vault_with_global_agents
    global_base = tmp_path / "config" / "opencode"
    monkeypatch.setenv("PIAGENTSYNC_VAULT_PATH", str(vault))
    monkeypatch.setenv("PIAGENTSYNC_GLOBAL_OPENCODE_PATH", str(global_base))

    with patch("subprocess.run") as mock_run:
        mock_run.return_value = subprocess.CompletedProcess(args=[], returncode=0)
        result = runner.invoke(app, ["bootstrap"])

    assert result.exit_code == 0
    opencode_path = global_base / "opencode.json"
    assert opencode_path.exists()
    content = opencode_path.read_text()
    assert '"obsidian"' in content
    assert '"notion"' in content
    assert "$HOME/vault" in content
    assert (global_base / "agents" / "chief-pm.md").exists()
    mock_run.assert_called_once_with(["opencode", "mcp", "auth", "notion"], check=False)


def test_bootstrap_skip_when_mcp_correct(
    vault_with_global_agents: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Skips writing when MCP already correctly configured."""
    vault = vault_with_global_agents
    global_base = tmp_path / "config" / "opencode"
    global_base.mkdir(parents=True)
    # Existing config with MCP already matching defaults, plus extra keys
    existing_config = {
        "model": "gpt-4",
        "provider": "openai",
        "mcp": {
            "notion": {
                "type": "remote",
                "url": "https://mcp.notion.com/mcp",
                "enabled": True,
            },
            "obsidian": {
                "type": "local",
                "command": ["sh", "-c", "npx @bitbonsai/mcpvault@latest $HOME/vault"],
                "enabled": True,
            },
        },
        "tools": {
            "notion_*": False,
            "obsidian_*": False,
        },
    }
    import json

    (global_base / "opencode.json").write_text(json.dumps(existing_config, indent=2))
    monkeypatch.setenv("PIAGENTSYNC_VAULT_PATH", str(vault))
    monkeypatch.setenv("PIAGENTSYNC_GLOBAL_OPENCODE_PATH", str(global_base))

    with patch("subprocess.run") as mock_run:
        result = runner.invoke(app, ["bootstrap"])

    assert result.exit_code == 0
    # File should be unchanged
    assert json.loads((global_base / "opencode.json").read_text()) == existing_config
    assert "already has mcp configured" in result.stdout.lower()
    mock_run.assert_not_called()  # auth not called when skipped


def test_bootstrap_merge_adds_mcp_to_existing(
    vault_with_global_agents: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Merges MCP into existing config that lacks MCP keys."""
    vault = vault_with_global_agents
    global_base = tmp_path / "config" / "opencode"
    global_base.mkdir(parents=True)
    # Existing config without MCP
    existing_config = {
        "model": "claude-3",
        "autoupdate": True,
    }
    import json

    (global_base / "opencode.json").write_text(json.dumps(existing_config, indent=2))
    monkeypatch.setenv("PIAGENTSYNC_VAULT_PATH", str(vault))
    monkeypatch.setenv("PIAGENTSYNC_GLOBAL_OPENCODE_PATH", str(global_base))

    with patch("subprocess.run") as mock_run:
        result = runner.invoke(app, ["bootstrap"])

    assert result.exit_code == 0
    new_config = json.loads((global_base / "opencode.json").read_text())
    # Original keys preserved
    assert new_config["model"] == "claude-3"
    assert new_config["autoupdate"] is True
    # MCP added
    assert new_config["mcp"]["notion"]["url"] == "https://mcp.notion.com/mcp"
    assert new_config["mcp"]["obsidian"]["enabled"] is True
    assert new_config["tools"]["notion_*"] is False
    assert "mcp" in result.stdout.lower() and "merged" in result.stdout.lower()
    mock_run.assert_called_once()


def test_bootstrap_force_overwrite(
    vault_with_global_agents: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """--force overwrites MCP block even if already correct, preserves other keys."""
    vault = vault_with_global_agents
    global_base = tmp_path / "config" / "opencode"
    global_base.mkdir(parents=True)
    # Existing config with MCP correct but we force
    existing_config = {
        "model": "gpt-4",
        "mcp": {
            "notion": {
                "type": "remote",
                "url": "https://mcp.notion.com/mcp",
                "enabled": True,
            },
            "obsidian": {
                "type": "local",
                "command": ["sh", "-c", "npx @bitbonsai/mcpvault@latest $HOME/vault"],
                "enabled": True,
            },
        },
        "tools": {
            "notion_*": False,
            "obsidian_*": False,
        },
    }
    import json

    (global_base / "opencode.json").write_text(json.dumps(existing_config, indent=2))
    monkeypatch.setenv("PIAGENTSYNC_VAULT_PATH", str(vault))
    monkeypatch.setenv("PIAGENTSYNC_GLOBAL_OPENCODE_PATH", str(global_base))

    with patch("subprocess.run") as mock_run:
        mock_run.return_value = subprocess.CompletedProcess(args=[], returncode=0)
        result = runner.invoke(app, ["bootstrap", "--force"])

    assert result.exit_code == 0
    new_config = json.loads((global_base / "opencode.json").read_text())
    # All keys preserved, MCP still correct
    assert new_config["model"] == "gpt-4"
    assert new_config["mcp"]["notion"]["url"] == "https://mcp.notion.com/mcp"
    assert new_config["tools"]["obsidian_*"] is False
    assert "Updated" in result.stdout
    mock_run.assert_called_once()  # auth called


def test_bootstrap_merge_preserves_other_mcp_servers(
    vault_with_global_agents: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Merging adds missing MCP servers but keeps existing ones."""
    vault = vault_with_global_agents
    global_base = tmp_path / "config" / "opencode"
    global_base.mkdir(parents=True)
    # Existing config with another MCP server
    existing_config = {
        "mcp": {
            "github": {
                "type": "remote",
                "url": "https://mcp.github.com/mcp",
                "enabled": True,
            }
        },
        "tools": {
            "github_*": True,
        },
    }
    import json

    (global_base / "opencode.json").write_text(json.dumps(existing_config, indent=2))
    monkeypatch.setenv("PIAGENTSYNC_VAULT_PATH", str(vault))
    monkeypatch.setenv("PIAGENTSYNC_GLOBAL_OPENCODE_PATH", str(global_base))

    with patch("subprocess.run"):
        result = runner.invoke(app, ["bootstrap"])

    assert result.exit_code == 0
    new_config = json.loads((global_base / "opencode.json").read_text())
    # Existing github server preserved
    assert new_config["mcp"]["github"]["url"] == "https://mcp.github.com/mcp"
    # Notion and obsidian added
    assert new_config["mcp"]["notion"]["enabled"] is True
    assert new_config["mcp"]["obsidian"]["enabled"] is True
    # Tools updated
    assert new_config["tools"]["notion_*"] is False
    assert new_config["tools"]["obsidian_*"] is False
    assert new_config["tools"]["github_*"] is True  # preserved


def test_bootstrap_missing_opencode_binary(
    vault_with_global_agents: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Shows warning if opencode binary not found."""
    vault = vault_with_global_agents
    global_base = tmp_path / "config" / "opencode"
    monkeypatch.setenv("PIAGENTSYNC_VAULT_PATH", str(vault))
    monkeypatch.setenv("PIAGENTSYNC_GLOBAL_OPENCODE_PATH", str(global_base))

    with patch("subprocess.run", side_effect=FileNotFoundError) as mock_run:
        result = runner.invoke(app, ["bootstrap"])

    assert result.exit_code == 0
    assert "opencode' command not found" in result.stdout.lower()
    mock_run.assert_called_once()


def test_bootstrap_auth_failure(
    vault_with_global_agents: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Shows warning if auth command returns non-zero."""
    vault = vault_with_global_agents
    global_base = tmp_path / "config" / "opencode"
    monkeypatch.setenv("PIAGENTSYNC_VAULT_PATH", str(vault))
    monkeypatch.setenv("PIAGENTSYNC_GLOBAL_OPENCODE_PATH", str(global_base))

    with patch("subprocess.run") as mock_run:
        mock_run.return_value = subprocess.CompletedProcess(args=[], returncode=1)
        result = runner.invoke(app, ["bootstrap"])

    assert result.exit_code == 0
    assert "exited with non-zero" in result.stdout.lower()
    mock_run.assert_called_once()


def test_bootstrap_missing_chief_pm_source(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Warns if chief-pm.md source is missing but continues."""
    vault = tmp_path / "vault"
    vault.mkdir()  # vault exists but no agents/global/chief-pm.md
    global_base = tmp_path / "config" / "opencode"
    monkeypatch.setenv("PIAGENTSYNC_VAULT_PATH", str(vault))
    monkeypatch.setenv("PIAGENTSYNC_GLOBAL_OPENCODE_PATH", str(global_base))

    with patch("subprocess.run"):
        result = runner.invoke(app, ["bootstrap"])

    assert result.exit_code == 0
    assert "vault/agents/global/chief-pm.md not found" in result.stdout.lower()
    assert (global_base / "opencode.json").exists()  # config still created


def test_bootstrap_chief_pm_sync_states(
    vault_with_global_agents: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test copied, updated, skipped states for chief-pm."""
    vault = vault_with_global_agents
    global_base = tmp_path / "config" / "opencode"
    monkeypatch.setenv("PIAGENTSYNC_VAULT_PATH", str(vault))
    monkeypatch.setenv("PIAGENTSYNC_GLOBAL_OPENCODE_PATH", str(global_base))

    src_chief = vault / "agents" / "global" / "chief-pm.md"
    dst_chief = global_base / "agents" / "chief-pm.md"

    # First run: copied
    with patch("subprocess.run"):
        result = runner.invoke(app, ["bootstrap"])
    assert result.exit_code == 0
    assert "Copied" in result.stdout
    assert dst_chief.exists()

    # Second run: skipped (identical)
    result = runner.invoke(app, ["bootstrap"])
    assert result.exit_code == 0
    assert (
        "already in sync" in result.stdout.lower() or "skipped" in result.stdout.lower()
    )

    # Modify destination to differ
    dst_chief.write_text("different content")
    # Third run: updated
    result = runner.invoke(app, ["bootstrap"])
    assert result.exit_code == 0
    assert "Updated" in result.stdout
    assert dst_chief.read_text() == src_chief.read_text()
