"""Tests for manifest parser."""

from pathlib import Path

import pytest
from pydantic import ValidationError

from piagentsync.errors import ManifestNotFoundError, ManifestParseError
from piagentsync.manifest import parse_manifest


def test_parse_valid_manifest(tmp_path: Path) -> None:
    """parses well-formed AGENTS.md, all fields correct."""
    md = tmp_path / "AGENTS.md"
    md.write_text(
        """---
project: myproj
workspace: ~/workspace/myproj
notion_board_id: abc123
notion_project_filter: myproj-filter
---
Body content ignored.
"""
    )
    manifest = parse_manifest(md)
    assert manifest.project == "myproj"
    assert manifest.workspace.is_absolute()
    assert manifest.notion_board_id == "abc123"
    assert manifest.notion_project_filter == "myproj-filter"


def test_parse_manifest_missing_file(tmp_path: Path) -> None:
    """Raises ManifestNotFoundError if path does not exist."""
    missing = tmp_path / "nope.md"
    with pytest.raises(ManifestNotFoundError):
        parse_manifest(missing)


def test_parse_manifest_no_frontmatter(tmp_path: Path) -> None:
    """Raises ManifestParseError if frontmatter is missing."""
    md = tmp_path / "AGENTS.md"
    md.write_text("# No frontmatter here")
    with pytest.raises(ManifestParseError):
        parse_manifest(md)


def test_parse_manifest_missing_required_field(tmp_path: Path) -> None:
    """Raises ValidationError when project field is missing."""
    md = tmp_path / "AGENTS.md"
    md.write_text("---\nworkspace: /tmp/foo\n---")
    with pytest.raises(ValidationError):
        parse_manifest(md)


def test_parse_manifest_invalid_project_slug(tmp_path: Path) -> None:
    """Raises ValidationError for invalid project slug."""
    md = tmp_path / "AGENTS.md"
    md.write_text("---\nproject: Invalid Slug\nworkspace: /tmp/foo\n---")
    with pytest.raises(ValidationError):
        parse_manifest(md)


def test_parse_manifest_workspace_expanded(tmp_path: Path) -> None:
    """workspace path expands user home and resolves."""
    md = tmp_path / "AGENTS.md"
    md.write_text('---\nproject: test\nworkspace: "~/testworkspace"\n---')
    manifest = parse_manifest(md)
    assert manifest.workspace.is_absolute()
    assert "~" not in str(manifest.workspace)


def test_parse_manifest_ignores_body(tmp_path: Path) -> None:
    """Body below frontmatter does not affect result."""
    md = tmp_path / "AGENTS.md"
    content = """---
project: testproj
workspace: /workspace/testproj
---
# Routing table
| Task | Agent |
|------|-------|
| foo  | bar   |
"""
    md.write_text(content)
    manifest = parse_manifest(md)
    assert manifest.project == "testproj"
    assert manifest.workspace == Path("/workspace/testproj")
