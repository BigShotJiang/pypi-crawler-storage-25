"""Pytest fixtures for piagentsync tests."""

from pathlib import Path

import pytest

from piagentsync.config import Settings
from piagentsync.manifest import parse_manifest
from piagentsync.models import ProjectManifest


@pytest.fixture
def vault_path(tmp_path: Path) -> Path:
    """Empty vault directory."""
    return tmp_path / "vault"


@pytest.fixture
def vault_with_supernova(vault_path: Path) -> Path:
    """Vault with a complete supernova project scaffold."""
    vault_path.mkdir(parents=True, exist_ok=True)
    project_dir = vault_path / "projects" / "supernova"
    project_dir.mkdir(parents=True, exist_ok=True)
    agents_dir = project_dir / "agents"
    agents_dir.mkdir()
    skills_dir = project_dir / "skills"
    skills_dir.mkdir()

    # AGENTS.md with valid frontmatter
    agents_md = project_dir / "AGENTS.md"
    agents_md.write_text(
        """---
project: supernova
workspace: ~/workspace/supernova
notion_board_id: 3305f9479a8d8055b3c3e86a9006cf91
notion_project_filter: supernova
---

# Supernova Agent Routing

## Stack

Docker, Kubernetes, Flux

## Agent routing

| Task | Agent |
|------|-------|
| deploy | flux-deployer |
| debug | debug-flux |
"""
    )

    # Sample agent and skill files
    (agents_dir / "proxmox-vm-manager.md").write_text(
        "# Proxmox VM Manager\nManages VMs."
    )
    (agents_dir / "flux-app-deployer.md").write_text(
        "# Flux App Deployer\nDeploys apps."
    )
    (skills_dir / "debug-flux.md").write_text("# Debug Flux Skill\nDebugging skills.")

    return vault_path


@pytest.fixture
def vault_with_global_agents(vault_path: Path) -> Path:
    """Vault with vault/agents/global/chief-pm.md."""
    vault_path.mkdir(parents=True, exist_ok=True)
    global_dir = vault_path / "agents" / "global"
    global_dir.mkdir(parents=True)
    (global_dir / "chief-pm.md").write_text("# Chief PM\nGlobal agent.")
    return vault_path


@pytest.fixture
def settings(vault_path: Path, tmp_path: Path) -> Settings:
    """Settings with vault_path pointed at tmp vault,
    global_opencode_path pointed at tmp_path / ".config" / "opencode"."""
    global_path = tmp_path / ".config" / "opencode"
    global_path.mkdir(parents=True, exist_ok=True)
    return Settings(vault_path=vault_path, global_opencode_path=global_path)


@pytest.fixture
def supernova_manifest(vault_with_supernova: Path) -> ProjectManifest:
    """Parsed ProjectManifest for the supernova project."""
    manifest_path = vault_with_supernova / "projects" / "supernova" / "AGENTS.md"
    return parse_manifest(manifest_path)


@pytest.fixture
def workspace_path(tmp_path: Path) -> Path:
    """Empty workspace directory at tmp_path / "workspace" / "supernova"."""
    w = tmp_path / "workspace" / "supernova"
    w.mkdir(parents=True)
    return w


@pytest.fixture
def workspace_with_supernova(workspace_path: Path) -> Path:
    """Workspace with .opencode/ containing agents, skills, and AGENTS.md."""
    opencode_dir = workspace_path / ".opencode"
    opencode_dir.mkdir(parents=True, exist_ok=True)

    # Create agents
    agents_dir = opencode_dir / "agents"
    agents_dir.mkdir()
    (agents_dir / "proxmox-vm-manager.md").write_text(
        "# Proxmox VM Manager\nManages VMs in workspace."
    )
    (agents_dir / "flux-app-deployer.md").write_text(
        "# Flux App Deployer\nDeploys apps in workspace."
    )

    # Create skills
    skills_dir = opencode_dir / "skills"
    skills_dir.mkdir()
    (skills_dir / "debug-flux.md").write_text(
        "# Debug Flux Skill\nDebugging in workspace."
    )

    # Create AGENTS.md
    (opencode_dir / "AGENTS.md").write_text(
        "---\nproject: supernova\nworkspace: ~/workspace/supernova\n---\n# Agents"
    )

    return workspace_path


@pytest.fixture
def global_opencode_with_agents(tmp_path: Path) -> Path:
    """Global opencode directory with chief-pm agent."""
    global_opencode = tmp_path / "global_opencode"
    agents_dir = global_opencode / "agents"
    agents_dir.mkdir(parents=True)
    (agents_dir / "chief-pm.md").write_text("# Chief PM\nGlobal agent in workspace.")
    return global_opencode


@pytest.fixture(autouse=True)
def clear_settings_cache() -> None:
    """Clear get_settings cache between tests."""
    from piagentsync.config import get_settings

    get_settings.cache_clear()
