# Getting Started — apikee Python

Complete guide for setting up, running, and releasing the `apikee` Python package.

---

## Prerequisites

| Tool | Version | Notes |
|------|---------|-------|
| Python | 3.10+ | |
| pip | latest | `pip install --upgrade pip` |
| git | any | |
| GitHub account | — | for CI/CD |
| PyPI account | — | for publishing ([pypi.org](https://pypi.org)) |

---

## 1. Clone and install

```bash
git clone https://github.com/apikee-dev/python.git
cd apikee-python

# Create virtual environment (strongly recommended)
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

# Install all extras (dev mode)
pip install -e ".[all]"
pip install pytest pytest-asyncio httpx ruff mypy
```

---

## 2. Environment variables

Copy the template and fill in your values:

```bash
cp .env.example .env
```

`.env.example`:
```bash
# ── Local signing secret ────────────────────────────────────────────────────
# Used to sign and verify API keys locally.
# Generate: python3 -c "import secrets; print(secrets.token_hex(32))"
APIKEE_SECRET=your-32-byte-hex-secret-here

# ── apikee.dev server mode (optional) ──────────────────────────────────────
# Leave blank to run in local-only mode.
# Get these from https://apikee.dev after creating a project.
APIKEE_SERVER_KEY=
APIKEE_PROJECT_ENV=my-app-production

# ── Example app ────────────────────────────────────────────────────────────
PORT=8000
```

Load in Python:
```python
from dotenv import load_dotenv   # pip install python-dotenv
load_dotenv()

import os
from apikee import Apikee

apikee = Apikee(
    secrets=[os.environ["APIKEE_SECRET"]],
    server_key=os.environ.get("APIKEE_SERVER_KEY") or None,
    project_env=os.environ.get("APIKEE_PROJECT_ENV", "my-app-production"),
)
```

> **Never commit `.env`** — it's already in `.gitignore`.

---

## 3. Run the tests

```bash
# Smoke test (zero deps — always run first)
python tests/smoke.py

# Full pytest suite
pytest tests/ -v

# With coverage
pytest tests/ --cov=apikee --cov-report=term-missing
```

---

## 4. Run a framework example

```bash
# FastAPI
pip install uvicorn
uvicorn examples/fastapi/main:app --reload
# → http://localhost:8000/docs

# Flask
python examples/flask/app.py
# → http://localhost:5000

# Starlette
uvicorn examples/starlette/app:app --reload
# → http://localhost:8000
```

---

## 5. Versioning

Versions follow **Semantic Versioning**: `MAJOR.MINOR.PATCH[-prerelease.N]`

| Version | Example | Meaning |
|---------|---------|---------|
| Stable | `1.2.3` | Production-ready |
| Alpha | `1.2.3-alpha.1` | Early preview, breaking changes possible |
| Beta | `1.2.3-beta.1` | Feature-complete, stabilising |
| RC | `1.2.3-rc.1` | Final testing before stable |

**Bump the version using the workflow:**

Go to **Actions → Version Bump → Run workflow**, choose the bump type.  
The workflow commits a version change and pushes a tag, which triggers the release.

Or bump manually:
```bash
# Edit pyproject.toml version field, then:
git add pyproject.toml
git commit -m "chore: bump version → 1.2.4"
git tag v1.2.4
git push origin HEAD --tags
```

---

## 6. Release workflow overview

```
git tag v1.2.3 → release.yml triggers → CI → build → PyPI → GitHub Release
                                              ↑
                                       also triggered by:
                                       v1.2.3-alpha.1  (alpha)
                                       v1.2.3-beta.1   (beta)
                                       v1.2.3-rc.1     (rc)
```

### Workflows at a glance

| File | Trigger | What it does |
|------|---------|-------------|
| `ci.yml` | push / PR | Lint, test matrix (3 Python × 3 OS), security scan |
| `release.yml` | tag push / manual | Full test → build wheel+sdist → PyPI → GitHub Release |
| `version-bump.yml` | manual / PR label | Bumps `pyproject.toml`, commits, pushes tag |
| `hotfix.yml` | manual | Fast-track patch from main → PyPI |

---

## 7. Required GitHub secrets

Go to **repo → Settings → Secrets and variables → Actions → New repository secret**.

| Secret | Required for | How to get it |
|--------|-------------|--------------|
| *(none — uses OIDC)* | PyPI publish | Configure at [pypi.org/manage/account/publishing](https://pypi.org/manage/account/publishing) |

> **OIDC trusted publishing** is the recommended approach. Configure it once on PyPI and the workflow publishes without any API token.
>
> If you prefer a token: create one at `pypi.org/manage/account/token/` with scope "Entire account" or just the `apikee` project, then add as `PYPI_API_TOKEN` and uncomment the token line in `release.yml`.

---

## 8. Branch strategy

```
main        ← stable releases + hotfixes
develop     ← integration branch
release/X.Y ← release preparation branch (optional)
hotfix/X.Y.Z← emergency patches off main
feature/*   ← new features off develop
```

**PR labels for auto-bump:**
Add one of these labels to any PR targeting `main`:
- `bump:patch` → e.g. `1.2.3 → 1.2.4`
- `bump:minor` → e.g. `1.2.3 → 1.3.0`
- `bump:major` → e.g. `1.2.3 → 2.0.0`

On merge, `version-bump.yml` runs automatically.

---

## 9. Project structure

```
apikee-python/
├── .github/
│   └── workflows/
│       ├── ci.yml            Tests on push/PR
│       ├── release.yml       Publish to PyPI on tag
│       ├── version-bump.yml  Auto-bump on PR merge
│       └── hotfix.yml        Fast-track patch release
├── apikee/
│   ├── __init__.py
│   ├── key.py                Local HMAC key engine
│   ├── core.py               Unified Apikee class + FastAPI/Starlette middleware
│   ├── crypto.py             X25519 + AES-256-GCM encrypted server channel
│   ├── server.py             apikee.dev HTTP client
│   ├── fastapi.py            SecuredFastAPI + ApikeeDepends + require_scope
│   └── flask.py              init_apikee + @apikee_required + @require_scope
├── examples/
│   ├── fastapi/              Runnable FastAPI Todo API
│   ├── flask/                Runnable Flask Notes API
│   └── starlette/            Runnable Starlette example
├── tests/
│   ├── smoke.py              Zero-dep standalone test
│   └── test_apikee.py        Full pytest suite
├── .env.example
├── .gitignore
├── pyproject.toml
├── pytest.ini
├── README.md
└── GETTING_STARTED.md        ← you are here
```

---

## 10. Common tasks

```bash
# Add a new module
touch apikee/my_module.py

# Run only fast tests
pytest tests/ -m "not slow" -v

# Check for security issues
pip install pip-audit && pip-audit .

# Lint
ruff check apikee/
ruff format apikee/

# Type-check
mypy apikee/ --ignore-missing-imports

# Build locally
pip install build && python -m build
```
