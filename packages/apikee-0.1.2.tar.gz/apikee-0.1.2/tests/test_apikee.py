"""
apikee-python test suite.
Run: pytest tests/ -v
"""

import pytest
from datetime import timedelta
from apikee import Apikee, ApikeeError

SECRET = "test-secret-do-not-use-in-production"


def make_apikee(**kwargs):
    return Apikee(secrets=[SECRET], **kwargs)


# ── Key creation & verification ──────────────────────────────────────────────

class TestLocalKeyEngine:
    def test_create_returns_apikee_prefix(self):
        gk = make_apikee()
        key = gk.create("acme-corp")
        assert key.startswith("apikee_")

    def test_create_and_verify_roundtrip(self):
        gk = make_apikee()
        key = gk.create("acme-corp", scopes=["read", "write"])
        claims = gk.verify(key)
        assert claims.tenant == "acme-corp"
        assert claims.scopes == ["read", "write"]

    def test_embedded_expiry(self):
        gk = make_apikee()
        key = gk.create("tenant", expires_in=timedelta(days=30))
        claims = gk.verify(key)
        assert claims.expires_at is not None

    def test_no_expiry(self):
        gk = make_apikee()
        key = gk.create("tenant", expires_in=None)
        claims = gk.verify(key)
        assert claims.expires_at is None

    def test_meta_roundtrip(self):
        gk = make_apikee()
        key = gk.create("tenant", meta={"plan": "pro", "seats": 5})
        claims = gk.verify(key)
        assert claims.meta["plan"] == "pro"

    def test_invalid_signature(self):
        gk = make_apikee()
        key = gk.create("tenant")
        tampered = key[:-4] + "XXXX"
        with pytest.raises(ApikeeError) as exc:
            gk.verify(tampered)
        assert exc.value.code in ("INVALID_SIGNATURE", "DECODE_ERROR")

    def test_expired_key(self):
        gk = make_apikee()
        key = gk.create("tenant", expires_in=timedelta(seconds=-1))
        with pytest.raises(ApikeeError) as exc:
            gk.verify(key)
        assert exc.value.code == "EXPIRED"

    def test_missing_prefix(self):
        gk = make_apikee()
        with pytest.raises(ApikeeError) as exc:
            gk.verify("Bearer some-random-token")
        assert exc.value.code == "INVALID_PREFIX"

    def test_wrong_secret(self):
        gk_a = Apikee(secrets=["secret-a"])
        gk_b = Apikee(secrets=["secret-b"])
        key = gk_a.create("tenant")
        with pytest.raises(ApikeeError) as exc:
            gk_b.verify(key)
        assert exc.value.code == "INVALID_SIGNATURE"

    def test_secret_rotation(self):
        old = Apikee(secrets=["old-secret"])
        key = old.create("tenant")
        rotated = Apikee(secrets=["new-secret", "old-secret"])
        claims = rotated.verify(key)
        assert claims.tenant == "tenant"

    def test_different_keys_different_ids(self):
        gk = make_apikee()
        key1 = gk.create("tenant")
        key2 = gk.create("tenant")
        claims1 = gk.verify(key1)
        claims2 = gk.verify(key2)
        assert claims1.id != claims2.id

    def test_environment_embedded(self):
        gk = make_apikee()
        key = gk.create("tenant", environment="staging")
        claims = gk.verify(key)
        assert claims.environment == "staging"


# ── FastAPI integration ───────────────────────────────────────────────────────

@pytest.mark.asyncio
class TestFastAPIIntegration:
    async def test_missing_key_returns_401(self):
        import httpx
        from apikee.fastapi import SecuredFastAPI

        app = SecuredFastAPI(secrets=[SECRET])

        @app.get("/ping")
        def ping():
            return {"ok": True}

        async with httpx.AsyncClient(app=app, base_url="http://test") as client:
            r = await client.get("/ping")
            assert r.status_code == 401
            assert r.json()["error"] == "MISSING_KEY"

    async def test_valid_key_returns_200(self):
        import httpx
        from apikee.fastapi import SecuredFastAPI

        app = SecuredFastAPI(secrets=[SECRET])

        @app.get("/ping")
        def ping():
            return {"ok": True}

        gk = make_apikee()
        key = gk.create("test-tenant")

        async with httpx.AsyncClient(app=app, base_url="http://test") as client:
            r = await client.get("/ping", headers={"x-api-key": key})
            assert r.status_code == 200

    async def test_claims_in_request_state(self):
        import httpx
        from fastapi import Request
        from apikee.fastapi import SecuredFastAPI

        app = SecuredFastAPI(secrets=[SECRET])

        @app.get("/me")
        def me(request: Request):
            return {"tenant": request.state.apikee.tenant}

        key = make_apikee().create("test-tenant")

        async with httpx.AsyncClient(app=app, base_url="http://test") as client:
            r = await client.get("/me", headers={"x-api-key": key})
            assert r.json()["tenant"] == "test-tenant"

    async def test_swagger_has_security_scheme(self):
        import httpx
        from apikee.fastapi import SecuredFastAPI

        app = SecuredFastAPI(secrets=[SECRET], title="Test API")

        async with httpx.AsyncClient(app=app, base_url="http://test") as client:
            r = await client.get("/openapi.json")
            schema = r.json()
            assert "ApikeeAuth" in schema["components"]["securitySchemes"]
            scheme = schema["components"]["securitySchemes"]["ApikeeAuth"]
            assert scheme["type"] == "apiKey"
            assert scheme["name"] == "x-api-key"
            assert scheme["in"] == "header"

    async def test_health_excluded_by_default(self):
        import httpx
        from apikee.fastapi import SecuredFastAPI

        app = SecuredFastAPI(secrets=[SECRET])

        @app.get("/health")
        def health():
            return {"status": "ok"}

        async with httpx.AsyncClient(app=app, base_url="http://test") as client:
            r = await client.get("/health")
            assert r.status_code == 200

    async def test_scope_guard(self):
        import httpx
        from fastapi import Depends
        from apikee.fastapi import SecuredFastAPI, require_scope

        app = SecuredFastAPI(secrets=[SECRET])

        @app.delete("/users/{uid}", dependencies=[Depends(require_scope("admin"))])
        def delete_user(uid: str):
            return {"deleted": uid}

        gk = make_apikee()
        read_key  = gk.create("tenant", scopes=["read"])
        admin_key = gk.create("tenant", scopes=["admin"])

        async with httpx.AsyncClient(app=app, base_url="http://test") as client:
            # read key → 403
            r = await client.delete("/users/1", headers={"x-api-key": read_key})
            assert r.status_code == 403
            assert r.json()["error"] == "INSUFFICIENT_SCOPE"

            # admin key → 200
            r = await client.delete("/users/1", headers={"x-api-key": admin_key})
            assert r.status_code == 200
