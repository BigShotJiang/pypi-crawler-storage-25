#!/usr/bin/env python3
"""
Standalone smoke test — no pytest needed.
Run: python tests/smoke.py
"""

from datetime import timedelta
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from apikee import Apikee, ApikeeError

PASS = "\033[92m✓\033[0m"
FAIL = "\033[91m✗\033[0m"
errors = []

def check(label: str, fn):
    try:
        fn()
        print(f"  {PASS}  {label}")
    except Exception as e:
        print(f"  {FAIL}  {label}: {e}")
        errors.append(label)

apikee = Apikee(secrets=["smoke-test-secret"])

print("\napikee smoke test\n")

# ── Key creation ──────────────────────────────────────────────────────────────
key = apikee.create("demo-tenant", scopes=["read", "write"],
                    expires_in=timedelta(hours=1), meta={"plan": "pro"})
print(f"  Key: {key[:40]}...")

check("key has apikee_ prefix",       lambda: assert_(key.startswith("apikee_")))
check("verify returns correct tenant", lambda: assert_(apikee.verify(key).tenant == "demo-tenant"))
check("scopes embedded correctly",     lambda: assert_(apikee.verify(key).scopes == ["read","write"]))
check("expiry is set",                 lambda: assert_(apikee.verify(key).expires_at is not None))
check("meta survives roundtrip",       lambda: assert_(apikee.verify(key).meta["plan"] == "pro"))

# ── Failure cases ─────────────────────────────────────────────────────────────
tampered = key[:-4] + "XXXX"
try:
    apikee.verify(tampered)
    errors.append("tamper detection")
    print(f"  {FAIL}  tamper detection: no error raised")
except ApikeeError as e:
    print(f"  {PASS}  tamper detection: [{e.code}]")

expired_key = apikee.create("t", expires_in=timedelta(seconds=-1))
try:
    apikee.verify(expired_key)
    errors.append("expiry check")
    print(f"  {FAIL}  expiry check: no error raised")
except ApikeeError as e:
    print(f"  {PASS}  expiry check: [{e.code}]")
    assert e.code == "EXPIRED", f"Expected EXPIRED, got {e.code}"

try:
    apikee.verify("Bearer some-token")
    errors.append("wrong prefix")
except ApikeeError as e:
    print(f"  {PASS}  wrong prefix: [{e.code}]")

# ── Secret rotation ───────────────────────────────────────────────────────────
old = Apikee(secrets=["old-secret"])
old_key = old.create("rotating-tenant")
rotated = Apikee(secrets=["new-secret", "old-secret"])
check("secret rotation",
      lambda: assert_(rotated.verify(old_key).tenant == "rotating-tenant"))

# ── Different keys have unique IDs ────────────────────────────────────────────
k1 = apikee.create("t")
k2 = apikee.create("t")
check("unique ids per key",
      lambda: assert_(apikee.verify(k1).id != apikee.verify(k2).id))

print()
if errors:
    print(f"FAILED: {len(errors)} check(s): {', '.join(errors)}")
    sys.exit(1)
else:
    print("All smoke checks passed ✓\n")


def assert_(cond: bool):
    if not cond:
        raise AssertionError("assertion failed")
