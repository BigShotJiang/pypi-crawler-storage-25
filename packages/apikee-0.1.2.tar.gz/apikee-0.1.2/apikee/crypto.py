"""
Asymmetric encrypted channel between SDK (client) and apikee.dev (server).

Flow:
  1. SDK generates an ephemeral X25519 keypair per session.
  2. Server public key (bundled / fetched once) used to derive a shared secret
     via ECDH → HKDF-SHA256 → 32-byte AES-256-GCM key.
  3. Payload encrypted client-side before any network call.
  4. Server decrypts with its private key, processes, returns encrypted response.
  5. SDK decrypts response with the same session key.

This means the raw API key is **never transmitted in plaintext** over the wire —
only ciphertext leaves the process. Even TLS interception sees only encrypted blobs.
"""

import os
import json
import base64
import struct
from typing import Any

try:
    from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    from cryptography.hazmat.primitives.hashes import SHA256
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.serialization import (
        Encoding, PublicFormat, NoEncryption, PrivateFormat
    )
    _CRYPTO_AVAILABLE = True
except ImportError:
    _CRYPTO_AVAILABLE = False

# Apikee server's static X25519 public key (base64-encoded, pinned in SDK)
# In production this would be fetched once and cached, or bundled at publish time.
_SERVER_PUBLIC_KEY_B64 = (
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="  # placeholder — replaced at publish
)

_VERSION = b"\x01"  # wire format version byte


def _require_crypto() -> None:
    if not _CRYPTO_AVAILABLE:
        raise ImportError(
            "Server mode requires the 'cryptography' package. "
            "Install it with: pip install apikee[server]"
        )


def generate_session_keypair() -> tuple[bytes, bytes]:
    """Return (private_bytes, public_bytes) for an ephemeral X25519 session key."""
    _require_crypto()
    priv = X25519PrivateKey.generate()
    priv_bytes = priv.private_bytes(Encoding.Raw, PrivateFormat.Raw, NoEncryption())
    pub_bytes = priv.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
    return priv_bytes, pub_bytes


def _derive_key(local_priv_bytes: bytes, remote_pub_bytes: bytes, info: bytes = b"apikee-v1") -> bytes:
    """ECDH + HKDF-SHA256 → 32-byte AES-GCM key."""
    _require_crypto()
    from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
    priv = X25519PrivateKey.from_private_bytes(local_priv_bytes)
    from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PublicKey
    pub = X25519PublicKey.from_public_bytes(remote_pub_bytes)
    shared = priv.exchange(pub)
    hkdf = HKDF(algorithm=SHA256(), length=32, salt=None, info=info)
    return hkdf.derive(shared)


def encrypt_payload(
    payload: dict[str, Any],
    server_pub_bytes: bytes | None = None,
) -> dict[str, str]:
    """
    Encrypt a dict payload for transmission to apikee.dev.

    Returns a dict with base64url-encoded fields ready to POST:
      { "v": "1", "epk": "...", "iv": "...", "ct": "..." }

    epk = ephemeral public key (sender includes so server can derive shared secret)
    iv  = 12-byte AES-GCM nonce
    ct  = ciphertext + 16-byte GCM auth tag
    """
    _require_crypto()
    if server_pub_bytes is None:
        server_pub_bytes = base64.b64decode(_SERVER_PUBLIC_KEY_B64)

    priv_bytes, pub_bytes = generate_session_keypair()
    aes_key = _derive_key(priv_bytes, server_pub_bytes)

    nonce = os.urandom(12)
    plaintext = json.dumps(payload, separators=(",", ":")).encode()
    ct = AESGCM(aes_key).encrypt(nonce, plaintext, None)

    b64u = base64.urlsafe_b64encode
    return {
        "v": "1",
        "epk": b64u(pub_bytes).decode().rstrip("="),
        "iv":  b64u(nonce).decode().rstrip("="),
        "ct":  b64u(ct).decode().rstrip("="),
    }


def decrypt_payload(
    envelope: dict[str, str],
    session_priv_bytes: bytes,
) -> dict[str, Any]:
    """
    Decrypt a response envelope from apikee.dev using our session private key.
    The server re-uses the same ephemeral public key we sent (epk) to re-derive
    the symmetric key from its own private key.
    """
    _require_crypto()

    def _b64d(s: str) -> bytes:
        pad = "=" * (-len(s) % 4)
        return base64.urlsafe_b64decode(s + pad)

    server_epk = _b64d(envelope["epk"])
    nonce = _b64d(envelope["iv"])
    ct = _b64d(envelope["ct"])

    aes_key = _derive_key(session_priv_bytes, server_epk)
    plaintext = AESGCM(aes_key).decrypt(nonce, ct, None)
    return json.loads(plaintext)
