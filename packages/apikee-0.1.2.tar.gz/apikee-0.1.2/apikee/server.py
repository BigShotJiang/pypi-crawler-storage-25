"""
ApikeeServer — encrypted connection to the apikee.dev developer platform.

All payloads are AES-256-GCM encrypted via ECDH key exchange before leaving
the process. The raw API key is never transmitted in plaintext.

Features:
  • Auto-create/upsert clients when issuing keys
  • Server-side validation with IP checks & fraud detection
  • Usage tracking & logs stored in apikee.dev
  • Auto-register endpoints on first request
  • Rate limiting (hour/day/week/month) via templates
  • Secret rotation with zero downtime
"""

from __future__ import annotations

import hashlib
import json
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from .crypto import encrypt_payload
from .key import sign_request

_BASE_URL = "https://apikee.dev/api/v1"


@dataclass
class ServerConfig:
    """Configuration for the apikee.dev server connection."""

    # Your apikee.dev project key (sk_... from the dashboard)
    server_key: str

    # project_env slug, e.g. "my-app-production"
    project_env: str

    # Auto-register endpoints the first time they are validated
    auto_register_endpoints: bool = True

    # Auto-create a client if the key's tenant is unknown to apikee.dev
    auto_create_clients: bool = True

    # Timeout for server calls in seconds
    timeout: float = 3.0

    # If True, server errors are silently ignored (local validation still runs)
    fail_open: bool = True

    # PEM-encoded RSA private key used to sign validation requests.
    # This is required when the project environment has a public key configured.
    private_key: str | None = None


@dataclass
class ServerValidationResult:
    """Result returned from server-side validation."""

    success: bool
    client_id: str | None = None
    project_env: str | None = None
    method_path: str | None = None
    duration_ms: int | None = None
    error: str | None = None
    # Rich data only returned when server validation passes
    rate_limit_remaining: dict | None = None
    fraud_signals: list | None = None


class ApikeeServer:
    """
    HTTP client for the apikee.dev REST API.
    All sensitive payloads are encrypted before transmission.
    """

    def __init__(self, config: ServerConfig) -> None:
        self._cfg = config
        self._session_priv: bytes | None = None
        self._session_pub: bytes | None = None
        self._endpoint_cache: set[str] = set()

    # ── Endpoint auto-registration ────────────────────────────────────────────
    def ensure_endpoint(self, method: str, path: str, name: str | None = None) -> None:
        """
        Register an endpoint with apikee.dev if not already seen this session.
        Called automatically by the middleware on first request to each route.
        """
        if not self._cfg.auto_register_endpoints:
            return
        key = f"{method.upper()}:{path}"
        if key in self._endpoint_cache:
            return
        self._endpoint_cache.add(key)
        try:
            self._post(
                "/endpoint",
                {
                    "method": method.upper(),
                    "path": path,
                    "name": name or f"{method.upper()} {path}",
                },
                params={"project_env": self._cfg.project_env},
                encrypt=False,  # endpoint metadata is not sensitive
            )
        except Exception:
            pass  # best-effort

    # ── Client / key management ───────────────────────────────────────────────
    def create_client_with_key(
        self,
        name: str,
        client_type: str = "service",
        key_name: str = "default",
        template_id: str | None = None,
        expires_at: datetime | None = None,
        meta: dict[str, Any] | None = None,
        ip_whitelist: list[str] | None = None,
    ) -> dict[str, Any]:
        """
        Create (or upsert) a client on apikee.dev and issue it a key.
        Returns the full client record; the raw key is in
        client['keys'][0]['key'] — copy it immediately, never stored again.
        """
        body: dict[str, Any] = {
            "name": name,
            "type": client_type,
            "keys": [
                {
                    "name": key_name,
                    **({"expiresAt": expires_at.isoformat()} if expires_at else {}),
                }
            ],
        }
        if template_id:
            body["templateId"] = template_id
        if meta:
            body["metadata"] = meta
        if ip_whitelist:
            body["ipWhitelist"] = ip_whitelist

        return self._post(
            "/client",
            body,
            params={"project_env": self._cfg.project_env},
            encrypt=True,
        )

    # ── Validation ────────────────────────────────────────────────────────────
    def validate(
        self,
        client_uuid: str,
        key_name: str,
        method: str,
        path: str,
        headers: dict[str, str],
        payload: dict[str, Any] | None = None,
    ) -> ServerValidationResult:
        """
        Send an encrypted validation request to apikee.dev.

        apikee.dev will:
          • Re-validate the key (expiry, scopes, signature via stored hash)
          • Check IP whitelist / fraud signals
          • Apply rate limits from the client's template
          • Log the request to MongoDB
          • Return success/failure + remaining rate limit budget

        The key itself is encrypted in the request body — never sent plaintext.
        """
        normalised_path = path if path.startswith("/") else f"/{path}"
        method_path = f"{method.upper()}:::{normalised_path}"
        timestamp = datetime.now(tz=timezone.utc).isoformat()
        body: dict[str, Any] = {
            "name": key_name,
            "timestamp": timestamp,
            "headers": dict(headers),
        }
        if payload:
            body["payload"] = payload

        extra_headers: dict[str, str] = {}
        if self._cfg.private_key:
            extra_headers["x-apikee-signature"] = sign_request(
                client_uuid,
                method_path,
                timestamp,
                self._cfg.private_key,
            )

        try:
            resp = self._post(
                f"/client/{client_uuid}",
                body,
                params={
                    "project_env": self._cfg.project_env,
                    "method_path": method_path,
                },
                encrypt=True,
                extra_headers=extra_headers,
            )
            return ServerValidationResult(
                success=resp.get("success", False),
                client_id=resp.get("clientId"),
                project_env=resp.get("project_env"),
                method_path=resp.get("method_path"),
                duration_ms=resp.get("durationMs"),
            )
        except Exception as exc:
            if self._cfg.fail_open:
                return ServerValidationResult(success=True, error=str(exc))
            return ServerValidationResult(success=False, error=str(exc))

    # ── Internals ─────────────────────────────────────────────────────────────
    def _post(
        self,
        path: str,
        body: dict,
        params: dict | None = None,
        encrypt: bool = False,
        extra_headers: dict[str, str] | None = None,
    ) -> dict:
        url = _BASE_URL + path
        if params:
            url += "?" + urllib.parse.urlencode(params)

        if encrypt:
            data = json.dumps(encrypt_payload(body), separators=(",", ":")).encode()
        else:
            data = json.dumps(body, separators=(",", ":")).encode()

        req = urllib.request.Request(
            url,
            data=data,
            headers={
                "Content-Type": "application/json",
                "x-api-key": self._cfg.server_key,
                "User-Agent": "apikee-python/0.1.2",
                "X-Apikee-Encrypted": "1" if encrypt else "0",
                **(extra_headers or {}),
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self._cfg.timeout) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as exc:
            raise RuntimeError(f"apikee.dev {exc.code}: {exc.read().decode()}") from exc
