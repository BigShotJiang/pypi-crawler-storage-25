"""
apikee — API key plugin. Zero-config when env vars are set.

    # Drop-in FastAPI replacement:
    from apikee.fastapi import SecuredFastAPI
    app = SecuredFastAPI()

    # Flask:
    from apikee.flask import init_apikee
    init_apikee(app)

    # Any ASGI / inline:
    from apikee import Apikee
    apikee = Apikee()
    app.add_middleware(apikee.middleware)
    claims = apikee.protect(request.headers.get("x-api-key"))

ENVIRONMENT VARIABLES
─────────────────────────────────────────────────────────────────────────────
  APIKEE_SECRET        (required) signing secret — openssl rand -hex 32
  APIKEE_SERVER_KEY    (optional) apikee.dev project key  → enables server mode
  APIKEE_PROJECT_ENV   (optional) project-env slug, e.g. my-api-production

Everything else has a default and is configurable only in code, not via env:
  header_name       = "x-api-key"
  default_expiry    = 90 days
  fail_open         = True   (allow through if server call fails)
  server_timeout    = 3.0 s
─────────────────────────────────────────────────────────────────────────────
"""

from __future__ import annotations

import os
from datetime import timedelta
from typing import Any

from .key import ApikeeKey, KeyOptions, ApikeeClaims


class ApikeeError(Exception):
    """Raised on key validation failure. .code has the machine-readable reason."""
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


def _e(name: str) -> str | None:
    """Read env var, return None if blank/missing."""
    v = os.environ.get(name, "")
    return v.strip() or None


class Apikee:
    """
    API key plugin. Reads APIKEE_SECRET (and optionally APIKEE_SERVER_KEY /
    APIKEE_PROJECT_ENV) from the environment. All other options have sane
    defaults and are set in code only.

    Zero-arg:
        apikee = Apikee()

    Explicit (overrides env):
        apikee = Apikee(
            secret="...",
            secrets=["current", "old"],  # rotation
            server_key="sk_live_...",
            project_env="my-api-production",
        )

    Options (code only, not env):
        header_name     = "x-api-key"
        default_expiry  = timedelta(days=90)
        fail_open       = True
        server_timeout  = 3.0
    """

    def __init__(
        self,
        *,
        # ── Secrets (env-var-aware) ──────────────────────────────────────
        secret: str | None = None,
        secrets: list[str] | None = None,
        # ── Server mode (env-var-aware) ──────────────────────────────────
        server_key: str | None = None,
        project_env: str | None = None,
        # ── Code-only options (defaults are always fine) ─────────────────
        header_name: str = "x-api-key",
        default_expiry: timedelta = timedelta(days=90),
        fail_open: bool = True,
        server_timeout: float = 3.0,
    ) -> None:
        # Resolve secrets: kwarg > APIKEE_SECRET env > error
        if secrets is not None:
            _secrets = [s for s in secrets if s.strip()]
        elif secret is not None:
            _secrets = [secret]
        else:
            primary = _e("APIKEE_SECRET")
            if not primary:
                raise ValueError(
                    "APIKEE_SECRET is not set.\n"
                    "  Generate one: openssl rand -hex 32\n"
                    "  Then: export APIKEE_SECRET=<value>\n"
                    "  Or pass it: Apikee(secret='...')"
                )
            _secrets = [primary]

        self._header        = header_name
        self._expiry        = default_expiry
        self._fail_open     = fail_open
        self._timeout       = server_timeout
        self._engine        = ApikeeKey(_secrets)

        # Resolve server mode: kwarg > env > None (local-only)
        _sk = server_key  or _e("APIKEE_SERVER_KEY")
        _pe = project_env or _e("APIKEE_PROJECT_ENV")

        self._server = None
        if _sk and _pe:
            from .server import ApikeeServer, ServerConfig
            self._server = ApikeeServer(ServerConfig(
                server_key=_sk,
                project_env=_pe,
                fail_open=fail_open,
                timeout=server_timeout,
            ))

    # ── Core ─────────────────────────────────────────────────────────────────

    def create(
        self,
        tenant: str,
        *,
        scopes: list[str] | None = None,
        expires_in: timedelta | None = None,
        meta: dict[str, Any] | None = None,
        environment: str = "production",
        # Server-mode extras (ignored in local-only mode)
        client_name: str | None = None,
        client_type: str = "service",
        template_id: str | None = None,
        ip_whitelist: list[str] | None = None,
    ) -> str:
        """Create a signed key. In server mode also creates the client on apikee.dev."""
        key = self._engine.create(KeyOptions(
            tenant=tenant,
            scopes=scopes or [],
            expires_in=expires_in if expires_in is not None else self._expiry,
            meta=meta or {},
            environment=environment,
        ))
        if self._server:
            try:
                self._server.create_client_with_key(
                    name=client_name or tenant,
                    client_type=client_type,
                    key_name=f"{tenant}-key",
                    template_id=template_id,
                    meta=meta,
                    ip_whitelist=ip_whitelist,
                )
            except Exception:
                pass
        return key

    def verify(self, key: str) -> ApikeeClaims:
        """Verify locally — pure CPU, ~0.1ms, zero I/O. Raises ApikeeError on failure."""
        return self._engine.verify(key)

    def protect(self, header_value: str | None) -> ApikeeClaims:
        """
        Inline guard — works in any framework without middleware.

            claims = apikee.protect(request.headers.get("x-api-key"))
        """
        if not header_value:
            raise ApikeeError("MISSING_KEY", f"'{self._header}' header is required")
        return self._engine.verify(header_value)

    # ── ASGI middleware ───────────────────────────────────────────────────────

    @property
    def middleware(self):
        """
        ASGI middleware class — add to FastAPI, Starlette, or any ASGI app.

            app.add_middleware(apikee.middleware)

        Claims are at request.state.apikee after passing.
        """
        from starlette.middleware.base import BaseHTTPMiddleware
        from starlette.requests import Request
        from starlette.responses import JSONResponse

        _h = self._header
        _e = self._engine
        _s = self._server

        class _M(BaseHTTPMiddleware):
            async def dispatch(self, request: Request, call_next):
                raw = request.headers.get(_h)
                if not raw:
                    return JSONResponse(
                        {"error": "MISSING_KEY", "message": f"'{_h}' header required"},
                        status_code=401,
                    )
                try:
                    request.state.apikee = _e.verify(raw)
                    if _s:
                        _s.ensure_endpoint(request.method, request.url.path)
                except ApikeeError as ex:
                    return JSONResponse(
                        {"error": ex.code, "message": ex.message}, status_code=401
                    )
                return await call_next(request)

        return _M

    def configure_swagger(self, app) -> None:
        """Inject ApikeeAuth security scheme into a FastAPI app's OpenAPI spec."""
        _orig = app.openapi
        _h = self._header

        def _patched():
            s = _orig()
            s.setdefault("components", {}).setdefault("securitySchemes", {})["ApikeeAuth"] = {
                "type": "apiKey", "in": "header", "name": _h,
                "description": "apikee_ signed key — tenant · scopes · expiry embedded",
            }
            s.setdefault("security", [{"ApikeeAuth": []}])
            return s

        app.openapi = _patched

    @property
    def server_mode(self) -> bool:
        return self._server is not None


# ── Module singleton ──────────────────────────────────────────────────────────

_instance: Apikee | None = None

def get_apikee() -> Apikee:
    """Shared instance built once from env vars. Convenience for non-DI contexts."""
    global _instance
    if _instance is None:
        _instance = Apikee()
    return _instance
