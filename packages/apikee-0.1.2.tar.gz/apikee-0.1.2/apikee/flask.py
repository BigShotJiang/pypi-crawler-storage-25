"""
apikee.flask — Flask integration.

Usage::

    from flask import Flask
    from apikee.flask import init_apikee, apikee_required, get_claims

    app = Flask(__name__)
    init_apikee(app, secrets=["sk-..."])

    @app.get("/data")
    @apikee_required
    def get_data():
        claims = get_claims()
        return {"tenant": claims.tenant}

Swagger (flask-openapi3 / flasgger)::

    init_apikee(app, secrets=["sk-..."], inject_swagger=True)
"""

from __future__ import annotations

from functools import wraps
from typing import Any

from .core import Apikee, ApikeeConfig, ApikeeError
from .key import ApikeeClaims

try:
    from flask import Flask, g, jsonify, request as flask_request
    _FLASK_AVAILABLE = True
except ImportError:
    _FLASK_AVAILABLE = False

__all__ = ["init_apikee", "apikee_required", "require_scope", "get_claims"]

_apikee_instance: Apikee | None = None


def init_apikee(
    app: "Flask",
    *,
    apikee: Apikee | None = None,
    secrets: list[str] | None = None,
    server_key: str | None = None,
    project_env: str | None = None,
    header_name: str = "x-api-key",
    exclude_paths: set[str] | None = None,
    inject_swagger: bool = True,
    config: ApikeeConfig | None = None,
) -> Apikee:
    """
    Attach apikee validation to a Flask app via before_request hook.

    Returns the Apikee instance in case you need it directly.
    """
    if not _FLASK_AVAILABLE:
        raise ImportError("Flask is not installed. Run: pip install flask")

    global _apikee_instance

    if apikee is not None:
        _apikee_instance = apikee
    elif config is not None:
        _apikee_instance = Apikee(config=config)
    elif secrets is not None:
        _apikee_instance = Apikee(secrets=secrets, server_key=server_key, project_env=project_env)
    else:
        raise ValueError("Provide either 'apikee', 'secrets', or 'config'")

    _excluded = exclude_paths or {"/health", "/ready", "/metrics"}

    @app.before_request
    def _validate():
        if flask_request.path in _excluded:
            return
        raw_key = flask_request.headers.get(header_name)
        if not raw_key:
            return jsonify({"error": "MISSING_KEY", "message": f"Header '{header_name}' is required"}), 401
        try:
            g.apikee = _apikee_instance.verify(raw_key)
        except ApikeeError as exc:
            return jsonify({"error": exc.code, "message": exc.message}), 401

    if inject_swagger:
        _patch_flask_swagger(app, header_name)

    return _apikee_instance


def _patch_flask_swagger(app: "Flask", header_name: str) -> None:
    """Inject ApikeeAuth into flasgger or flask-openapi3 if present."""
    try:
        # flasgger
        if hasattr(app, "swag") or "flasgger" in str(app.extensions):
            app.config.setdefault("SWAGGER", {}).setdefault("securityDefinitions", {})[
                "ApikeeAuth"
            ] = {"type": "apiKey", "in": "header", "name": header_name}
    except Exception:
        pass


def get_claims() -> ApikeeClaims:
    """Return the verified ApikeeClaims for the current Flask request."""
    from flask import g
    claims: ApikeeClaims | None = getattr(g, "apikee", None)
    if claims is None:
        from flask import abort
        abort(401, description="No verified claims found")
    return claims


def apikee_required(fn):
    """Decorator that enforces apikee validation on a single route."""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not hasattr(g, "apikee"):
            return jsonify({"error": "UNAUTHENTICATED", "message": "Missing apikee claims"}), 401
        return fn(*args, **kwargs)
    return wrapper


def require_scope(*scopes: str):
    """Decorator that additionally checks the key has required scopes."""
    required = set(scopes)
    def decorator(fn):
        @wraps(fn)
        @apikee_required
        def wrapper(*args, **kwargs):
            claims = get_claims()
            missing = required - set(claims.scopes)
            if missing:
                return jsonify({
                    "error": "INSUFFICIENT_SCOPE",
                    "message": f"Key missing required scopes: {', '.join(sorted(missing))}",
                }), 403
            return fn(*args, **kwargs)
        return wrapper
    return decorator
