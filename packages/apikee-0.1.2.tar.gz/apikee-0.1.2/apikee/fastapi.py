"""
apikee.fastapi — SecuredFastAPI plugin.

    from apikee.fastapi import SecuredFastAPI, ApikeeDepends, require_scope

    app = SecuredFastAPI()   # reads APIKEE_SECRET from env — that's it

    @app.get("/data")
    def data(claims = ApikeeDepends()):
        return {"tenant": claims.tenant}

    @app.delete("/admin", dependencies=[Depends(require_scope("admin"))])
    def admin(): ...
"""

from __future__ import annotations
from typing import Any, Callable

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.openapi.utils import get_openapi

from .core import Apikee, ApikeeError
from .key import ApikeeClaims


class SecuredFastAPI(FastAPI):
    """
    Drop-in replacement for FastAPI(). Reads APIKEE_SECRET from env automatically.

    Minimal:
        app = SecuredFastAPI()

    With options:
        app = SecuredFastAPI(
            secrets=["current", "old"],      # rotation
            server_key="sk_live_...",        # server mode (or set APIKEE_SERVER_KEY)
            project_env="my-api-production", # (or set APIKEE_PROJECT_ENV)
            header_name="x-api-key",         # default
            exclude_paths={"/health"},       # always open
        )

    After setup:
        - Every route requires a valid apikee key
        - /docs Swagger UI shows the lock and Authorize button
        - Claims available as request.state.apikee
    """

    def __init__(
        self,
        *,
        apikee: Apikee | None = None,
        secret: str | None = None,
        secrets: list[str] | None = None,
        server_key: str | None = None,
        project_env: str | None = None,
        header_name: str = "x-api-key",
        exclude_paths: set[str] | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)

        self._apikee = apikee or Apikee(
            secret=secret,
            secrets=secrets,
            server_key=server_key,
            project_env=project_env,
            header_name=header_name,
        )

        _excluded = exclude_paths or {"/docs", "/redoc", "/openapi.json", "/health", "/ready"}
        _ap = self._apikee

        # ── Middleware ────────────────────────────────────────────────────
        @self.middleware("http")
        async def _validate(request: Request, call_next: Callable):
            if request.url.path in _excluded:
                return await call_next(request)
            raw = request.headers.get(_ap._header)
            if not raw:
                from fastapi.responses import JSONResponse
                return JSONResponse(
                    {"error": "MISSING_KEY", "message": f"'{_ap._header}' header is required"},
                    status_code=401,
                )
            try:
                request.state.apikee = _ap.verify(raw)
                if _ap._server:
                    _ap._server.ensure_endpoint(request.method, request.url.path)
            except ApikeeError as e:
                from fastapi.responses import JSONResponse
                return JSONResponse({"error": e.code, "message": e.message}, status_code=401)
            return await call_next(request)

        # ── OpenAPI security scheme ───────────────────────────────────────
        _h = header_name

        def _openapi() -> dict[str, Any]:
            if self.openapi_schema:
                return self.openapi_schema
            schema = get_openapi(
                title=self.title, version=self.version,
                openapi_version=self.openapi_version,
                description=self.description,
                terms_of_service=self.terms_of_service,
                contact=self.contact, license_info=self.license_info,
                routes=self.routes, tags=self.openapi_tags, servers=self.servers,
            )
            schema.setdefault("components", {}).setdefault("securitySchemes", {})["ApikeeAuth"] = {
                "type": "apiKey", "in": "header", "name": _h,
                "description": "apikee_ signed key — tenant · scopes · expiry embedded",
            }
            schema.setdefault("security", [{"ApikeeAuth": []}])
            for item in schema.get("paths", {}).values():
                for op in item.values():
                    if isinstance(op, dict):
                        op.setdefault("security", [{"ApikeeAuth": []}])
            self.openapi_schema = schema
            return schema

        self.openapi = _openapi  # type: ignore[method-assign]

    @property
    def apikee(self) -> Apikee:
        return self._apikee


# ── Dependencies ──────────────────────────────────────────────────────────────

def get_claims(request: Request) -> ApikeeClaims:
    """FastAPI dependency — returns the verified ApikeeClaims for this request."""
    claims = getattr(request.state, "apikee", None)
    if claims is None:
        raise HTTPException(status_code=401, detail={"error": "UNAUTHENTICATED"})
    return claims


def ApikeeDepends() -> ApikeeClaims:  # noqa: N802
    """Shorthand for Depends(get_claims)."""
    return Depends(get_claims)  # type: ignore[return-value]


def require_scope(*scopes: str) -> Callable:
    """
    Dependency factory — enforce required scopes on a route.

        @app.delete("/x", dependencies=[Depends(require_scope("admin"))])
        def delete_x(): ...
    """
    _required = set(scopes)

    def _check(claims: ApikeeClaims = Depends(get_claims)) -> ApikeeClaims:
        missing = _required - set(claims.scopes)
        if missing:
            raise HTTPException(
                status_code=403,
                detail={"error": "INSUFFICIENT_SCOPE",
                        "message": f"Missing scope(s): {', '.join(sorted(missing))}"},
            )
        return claims

    return _check
