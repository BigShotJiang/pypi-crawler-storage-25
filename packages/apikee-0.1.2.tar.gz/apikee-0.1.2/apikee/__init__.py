"""
apikee — API key management plugin.

Quickstart:
    export APIKEE_SECRET=$(openssl rand -hex 32)

    # FastAPI
    from apikee.fastapi import SecuredFastAPI
    app = SecuredFastAPI()

    # Flask
    from apikee.flask import init_apikee
    init_apikee(app)

    # Any ASGI
    from apikee import Apikee
    app.add_middleware(Apikee().middleware)
"""

from .core import Apikee, ApikeeError, get_apikee
from .key import ApikeeClaims, KeyOptions, hash_key, sign_request, verify_request_signature

__all__ = [
    "Apikee",
    "ApikeeError",
    "ApikeeClaims",
    "KeyOptions",
    "get_apikee",
    "hash_key",
    "sign_request",
    "verify_request_signature",
]
__version__ = "0.1.2"
