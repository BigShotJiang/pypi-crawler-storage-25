"""
Local key creation and verification — zero I/O, pure CPU.

Key format:  apikee_<base62(msgpack(claims))>.<base62(hmac-sha256)>
"""

from __future__ import annotations

import hashlib
import hmac
import os
import struct
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any

# ── Optional fast msgpack; fall back to plain JSON ────────────────────────────
try:
    import msgpack as _msgpack  # type: ignore

    def _pack(obj: dict) -> bytes:
        return _msgpack.packb(obj, use_bin_type=True)

    def _unpack(data: bytes) -> dict:
        return _msgpack.unpackb(data, raw=False)

except ImportError:
    import json

    def _pack(obj: dict) -> bytes:  # type: ignore[misc]
        return json.dumps(obj, separators=(",", ":")).encode()

    def _unpack(data: bytes) -> dict:  # type: ignore[misc]
        return json.loads(data)


# ── Base62 ────────────────────────────────────────────────────────────────────
_ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
_BASE = 62


def _b62_encode(data: bytes) -> str:
    n = int.from_bytes(data, "big")
    if n == 0:
        return _ALPHABET[0]
    chars: list[str] = []
    while n:
        n, rem = divmod(n, _BASE)
        chars.append(_ALPHABET[rem])
    return "".join(reversed(chars))


def _b62_decode(s: str) -> bytes:
    n = 0
    for ch in s:
        n = n * _BASE + _ALPHABET.index(ch)
    length = (n.bit_length() + 7) // 8
    return n.to_bytes(max(length, 1), "big")


# ── ULID-like ID (timestamp prefix + random suffix, URL-safe) ─────────────────
def _new_id() -> str:
    ts = int(time.time() * 1000)
    rand = os.urandom(10)
    return _b62_encode(struct.pack(">Q", ts) + rand)[:22]


# ── Data classes ──────────────────────────────────────────────────────────────
PREFIX = "apikee_"
SEP = "."


@dataclass
class KeyOptions:
    """Options for creating a new local apikee key."""

    tenant: str
    scopes: list[str] = field(default_factory=list)
    # Supports parity with Node SDK duration styles:
    #   - timedelta
    #   - datetime (absolute expiry)
    #   - int/float seconds from now
    #   - string: "90d", "24h", "60m", "3600s"
    expires_in: timedelta | datetime | int | float | str | None = timedelta(days=90)
    not_before: datetime | None = None
    environment: str = "production"
    meta: dict[str, Any] = field(default_factory=dict)


@dataclass
class ApikeeClaims:
    """Decoded and verified claims from an apikee key."""

    id: str
    tenant: str
    scopes: list[str]
    expires_at: datetime | None
    not_before: datetime | None
    environment: str
    meta: dict[str, Any]
    raw_key: str  # original key string (for server forwarding)


# ── Core key logic ────────────────────────────────────────────────────────────
class ApikeeKey:
    """
    Creates and verifies locally-signed apikee keys.
    No network required for standard validation.
    """

    def __init__(self, secrets: list[str]) -> None:
        if not secrets:
            raise ValueError("At least one secret is required")
        self._secrets = [s.encode() for s in secrets]

    # ── creation ──────────────────────────────────────────────────────────────
    def create(self, options: KeyOptions) -> str:
        """
        Generate a signed apikee key with embedded claims.

        Returns the raw key string (e.g. "apikee_4xKm...Zp9.8aFc...3d").
        Store the return value — it is never persisted internally.
        """
        now = datetime.now(tz=timezone.utc)
        claims: dict[str, Any] = {
            "id":  _new_id(),
            "tid": options.tenant,
            "scp": options.scopes,
            "env": options.environment,
        }
        exp = _parse_expiry(now, options.expires_in)
        if exp is not None:
            claims["exp"] = exp
        if options.not_before is not None:
            claims["nbf"] = int(options.not_before.timestamp())
        if options.meta:
            claims["meta"] = options.meta

        payload = _pack(claims)
        sig = self._sign(payload)
        return PREFIX + _b62_encode(payload) + SEP + _b62_encode(sig)

    # ── verification ──────────────────────────────────────────────────────────
    def verify(self, key: str) -> ApikeeClaims:
        """
        Verify signature and claims. Returns ApikeeClaims on success.
        Raises ApikeeError on any failure.
        """
        from .core import ApikeeError

        if not key.startswith(PREFIX):
            raise ApikeeError("INVALID_PREFIX", "Key does not start with 'apikee_'")

        body = key[len(PREFIX):]
        parts = body.split(SEP, 1)
        if len(parts) != 2:
            raise ApikeeError("INVALID_FORMAT", "Key missing signature separator")

        payload_b62, sig_b62 = parts
        try:
            payload = _b62_decode(payload_b62)
            provided_sig = _b62_decode(sig_b62)
        except Exception:
            raise ApikeeError("DECODE_ERROR", "Key segments are not valid base62")

        if not self._verify_sig(payload, provided_sig):
            raise ApikeeError("INVALID_SIGNATURE", "Key signature is invalid")

        try:
            claims = _unpack(payload)
        except Exception:
            raise ApikeeError("DECODE_ERROR", "Payload could not be deserialised")

        now = int(time.time())
        if "exp" in claims and now > claims["exp"]:
            raise ApikeeError("EXPIRED", "Key has expired")
        if "nbf" in claims and now < claims["nbf"]:
            raise ApikeeError("NOT_YET_VALID", "Key is not yet valid")

        return ApikeeClaims(
            id=claims.get("id", ""),
            tenant=claims.get("tid", ""),
            scopes=claims.get("scp", []),
            expires_at=datetime.fromtimestamp(claims["exp"], tz=timezone.utc) if "exp" in claims else None,
            not_before=datetime.fromtimestamp(claims["nbf"], tz=timezone.utc) if "nbf" in claims else None,
            environment=claims.get("env", "production"),
            meta=claims.get("meta", {}),
            raw_key=key,
        )

    # ── internals ─────────────────────────────────────────────────────────────
    def _sign(self, payload: bytes) -> bytes:
        """Sign with the first (current) secret."""
        return hmac.new(self._secrets[0], payload, hashlib.sha256).digest()

    def _verify_sig(self, payload: bytes, provided: bytes) -> bool:
        """Constant-time check against ALL secrets (supports rotation)."""
        for secret in self._secrets:
            expected = hmac.new(secret, payload, hashlib.sha256).digest()
            if hmac.compare_digest(expected, provided):
                return True
        return False


def _parse_expiry(now: datetime, value: timedelta | datetime | int | float | str | None) -> int | None:
    if value is None:
        return None

    if isinstance(value, timedelta):
        return int((now + value).timestamp())

    if isinstance(value, datetime):
        dt = value if value.tzinfo is not None else value.replace(tzinfo=timezone.utc)
        return int(dt.timestamp())

    if isinstance(value, (int, float)):
        return int(now.timestamp() + float(value))

    if isinstance(value, str):
        m = __import__("re").fullmatch(r"(\d+)([dhms])", value.strip())
        if not m:
            raise ValueError(f"Cannot parse duration: {value}")
        n = int(m.group(1))
        unit = m.group(2)
        mul = {"d": 86400, "h": 3600, "m": 60, "s": 1}[unit]
        return int(now.timestamp() + n * mul)

    raise ValueError(f"Unsupported expires_in type: {type(value).__name__}")


def hash_key(raw_key: str) -> str:
    """Return a SHA-256 hex digest for storing key fingerprints safely."""
    return hashlib.sha256(raw_key.encode("utf-8")).hexdigest()


def sign_request(client_id: str, method_path: str, timestamp: str, private_key_pem: str) -> str:
    """
    Sign canonical validation message with RSA-SHA256 (base64url output).

    Canonical format: "{client_id}|{method_path}|{timestamp}".
    Requires optional extra: cryptography.
    """
    try:
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.asymmetric import padding
        from cryptography.hazmat.primitives.serialization import load_pem_private_key
    except Exception as exc:  # pragma: no cover - optional dependency path
        raise RuntimeError("cryptography is required for request signing") from exc

    import base64

    canonical = f"{client_id}|{method_path}|{timestamp}".encode("utf-8")
    key = load_pem_private_key(private_key_pem.encode("utf-8"), password=None)
    sig = key.sign(canonical, padding.PKCS1v15(), hashes.SHA256())
    return base64.urlsafe_b64encode(sig).decode("ascii").rstrip("=")


def verify_request_signature(
    client_id: str,
    method_path: str,
    timestamp: str,
    signature: str,
    public_key_pem: str,
) -> bool:
    """
    Verify RSA-SHA256 base64url signature of canonical validation message.
    Requires optional extra: cryptography.
    """
    try:
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.asymmetric import padding
        from cryptography.hazmat.primitives.serialization import load_pem_public_key
    except Exception:  # pragma: no cover - optional dependency path
        return False

    import base64

    canonical = f"{client_id}|{method_path}|{timestamp}".encode("utf-8")
    pad = "=" * (-len(signature) % 4)
    try:
        sig_bytes = base64.urlsafe_b64decode(signature + pad)
        key = load_pem_public_key(public_key_pem.encode("utf-8"))
        key.verify(sig_bytes, canonical, padding.PKCS1v15(), hashes.SHA256())
        return True
    except Exception:
        return False
