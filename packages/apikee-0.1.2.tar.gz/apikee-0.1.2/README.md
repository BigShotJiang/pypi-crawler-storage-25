# apikee · Python

[![PyPI](https://img.shields.io/pypi/v/apikee)](https://pypi.org/project/apikee/)

API key plugin for Python — FastAPI, Flask, and Starlette.

## Install

```bash
pip install apikee                # local mode, zero deps
pip install "apikee[fastapi]"     # + FastAPI middleware
pip install "apikee[server]"      # + encrypted server channel (apikee.dev)
pip install "apikee[all]"         # everything
```

## Configure (set 1 env var)

```bash
export APIKEE_SECRET=$(openssl rand -hex 32)

# Optional — enables server mode (usage tracking, rate limits, fraud detection)
export APIKEE_SERVER_KEY=sk_live_...
export APIKEE_PROJECT_ENV=my-api-production
```

## FastAPI

```python
from apikee.fastapi import SecuredFastAPI, ApikeeDepends, require_scope
from apikee import ApikeeClaims
from fastapi import Depends

app = SecuredFastAPI()  # reads APIKEE_SECRET — done

@app.post("/keys")         # public endpoint — issue keys to customers
def create_key(tenant: str, scopes: str = "read,write"):
    key = app.apikee.create(tenant, scopes=scopes.split(","))
    return {"key": key}   # store it — returned once

@app.get("/data")
def get_data(claims: ApikeeClaims = ApikeeDepends()):
    return {"tenant": claims.tenant, "scopes": claims.scopes}

@app.delete("/admin", dependencies=[Depends(require_scope("admin"))])
def admin_action(): ...
```

Open `/docs` — every endpoint shows the 🔒 lock. Click **Authorize**, paste a key.

## Flask

```python
from flask import Flask
from apikee.flask import init_apikee, apikee_required, require_scope, get_claims

app = Flask(__name__)
init_apikee(app)  # reads APIKEE_SECRET — done

@app.get("/data")
@apikee_required
def data():
    return {"tenant": get_claims().tenant}

@app.delete("/admin")
@require_scope("admin")
def admin(): ...
```

## Any ASGI

```python
from apikee import Apikee

apikee = Apikee()
app.add_middleware(apikee.middleware)   # claims at request.state.apikee

# Or inline, no middleware:
claims = apikee.protect(request.headers.get("x-api-key"))
```

## Key rotation (zero downtime)

```bash
export APIKEE_SECRET=new-secret        # new keys signed with this
# Old keys still validate during the rotation window — pass both to Apikee():
```
```python
apikee = Apikee(secrets=["new-secret", "old-secret"])
```

## Workflows

| Workflow | Trigger | Action |
|----------|---------|--------|
| `ci.yml` | push / PR | Lint + test matrix (Python 3.10–3.12 × 3 OS) |
| `release.yml` | tag `v*.*.*` or manual | Build → PyPI → GitHub Release |
| `version-bump.yml` | PR label or manual | Bump version, commit, push tag |
| `hotfix.yml` | manual | Fast-track patch from main |

**Release:** `git tag v1.2.3 && git push --tags`

**Secrets needed** (repo → Settings → Secrets → Actions):

| Secret | Notes |
|--------|-------|
| PyPI trusted publishing | Configure at pypi.org/manage/account/publishing — no token needed |
| `PYPI_API_TOKEN` | Alternative to OIDC — uncomment in `release.yml` |

## Docs

[apikee.com/docs](https://apikee.com/docs) · [apikee.dev](https://apikee.dev)
