"""
apikee FastAPI Example — reads APIKEE_SECRET from env
Run: pip install "apikee[fastapi]" uvicorn && uvicorn main:app --reload
Docs: http://localhost:8000/docs
"""
from datetime import timedelta
from typing import Optional
from fastapi import Depends, Request
from fastapi.responses import JSONResponse
from apikee.fastapi import SecuredFastAPI, ApikeeDepends, require_scope
from apikee import ApikeeClaims

app = SecuredFastAPI(
    title="apikee Todo API",
    exclude_paths={"/health", "/docs", "/redoc", "/openapi.json", "/keys"},
)
todos: dict[str, list] = {}

@app.get("/health", tags=["system"])
def health(): return {"status": "ok"}

@app.post("/keys", tags=["auth"])
def create_key(tenant: str, scopes: str = "read,write"):
    key = app.apikee.create(tenant, scopes=scopes.split(","), expires_in=timedelta(days=90))
    return {"key": key}

@app.get("/me", tags=["auth"])
def me(claims: ApikeeClaims = ApikeeDepends()):
    return {"id": claims.id, "tenant": claims.tenant, "scopes": claims.scopes}

@app.get("/todos", tags=["todos"])
def list_todos(claims: ApikeeClaims = ApikeeDepends()):
    return {"tenant": claims.tenant, "todos": todos.get(claims.tenant, [])}

@app.post("/todos", tags=["todos"])
def create_todo(title: str, claims: ApikeeClaims = ApikeeDepends()):
    if "write" not in claims.scopes:
        return JSONResponse({"error": "INSUFFICIENT_SCOPE"}, 403)
    bucket = todos.setdefault(claims.tenant, [])
    todo = {"id": len(bucket) + 1, "title": title, "done": False}
    bucket.append(todo)
    return todo

@app.delete("/todos/{tid}", tags=["todos"], dependencies=[Depends(require_scope("admin"))])
def delete_todo(tid: int, claims: ApikeeClaims = ApikeeDepends()):
    todos[claims.tenant] = [t for t in todos.get(claims.tenant, []) if t["id"] != tid]
    return {"deleted": tid}
