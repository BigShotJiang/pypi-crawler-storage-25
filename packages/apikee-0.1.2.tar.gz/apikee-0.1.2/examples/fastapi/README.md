# FastAPI Example

```bash
pip install "apikee[fastapi]" uvicorn
uvicorn main:app --reload
```

Open **http://localhost:8000/docs** — every endpoint has a 🔒 lock.

```bash
# Issue a key
curl -X POST "http://localhost:8000/keys?tenant=acme&scopes=read,write"
export KEY="apikee_..."

# Use it
curl -H "x-api-key: $KEY" http://localhost:8000/todos
curl -X POST -H "x-api-key: $KEY" "http://localhost:8000/todos?title=Buy+milk"
curl -H "x-api-key: $KEY" http://localhost:8000/me

# Scope enforcement — 403 without admin
curl -X DELETE -H "x-api-key: $KEY" http://localhost:8000/todos/1
```
