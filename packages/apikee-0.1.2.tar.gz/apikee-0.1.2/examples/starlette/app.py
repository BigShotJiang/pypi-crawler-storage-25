"""
apikee Starlette Example — reads APIKEE_SECRET from env
Run: pip install apikee starlette uvicorn && uvicorn app:app
"""
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route
from apikee import Apikee

apikee = Apikee()
items: dict[str, list] = {}

async def health(req): return JSONResponse({"status": "ok"})

async def create_key(req: Request):
    tenant = req.query_params.get("tenant", "anon")
    key = apikee.create(tenant, scopes=["read","write"])
    return JSONResponse({"key": key})

async def list_items(req: Request):
    claims = req.state.apikee
    return JSONResponse({"tenant": claims.tenant, "items": items.get(claims.tenant, [])})

async def create_item(req: Request):
    claims = req.state.apikee
    if "write" not in claims.scopes:
        return JSONResponse({"error": "INSUFFICIENT_SCOPE"}, 403)
    body   = await req.json()
    bucket = items.setdefault(claims.tenant, [])
    item   = {"id": len(bucket)+1, **body}
    bucket.append(item)
    return JSONResponse(item, status_code=201)

app = Starlette(routes=[
    Route("/health",  health),
    Route("/keys",    create_key,   methods=["POST"]),
    Route("/items",   list_items,   methods=["GET"]),
    Route("/items",   create_item,  methods=["POST"]),
])
app.add_middleware(apikee.middleware)
