# Starlette Example

```bash
pip install apikee starlette uvicorn
uvicorn app:app --reload
```

```bash
curl -X POST "http://localhost:8000/keys?tenant=acme&scopes=read,write"
export KEY="apikee_..."
curl -H "x-api-key: $KEY" http://localhost:8000/items
```
