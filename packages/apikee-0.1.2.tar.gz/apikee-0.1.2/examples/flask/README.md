# Flask Example

```bash
pip install apikee flask
python app.py
```

```bash
# Issue key
curl -X POST "http://localhost:5000/keys?tenant=acme&scopes=read,write"
export KEY="apikee_..."

# Use it
curl -H "x-api-key: $KEY" http://localhost:5000/notes
curl -X POST -H "x-api-key: $KEY" -H "Content-Type: application/json" \
  -d '{"title":"Buy milk"}' http://localhost:5000/notes
curl -H "x-api-key: $KEY" http://localhost:5000/me

# 403 without admin
curl -X DELETE -H "x-api-key: $KEY" http://localhost:5000/notes/1
```
