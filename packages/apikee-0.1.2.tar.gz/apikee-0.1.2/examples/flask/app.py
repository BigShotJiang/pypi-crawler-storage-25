"""
apikee Flask Example — reads APIKEE_SECRET from env
Run: pip install apikee flask && python app.py
"""
from flask import Flask, jsonify, request
from apikee.flask import init_apikee, apikee_required, require_scope, get_claims

app = Flask(__name__)
init_apikee(app, exclude_paths={"/health", "/keys"})
notes: dict[str, list] = {}

@app.get("/health")
def health(): return jsonify(status="ok")

@app.post("/keys")
def create_key():
    from apikee import get_apikee
    key = get_apikee().create(
        request.args.get("tenant", "anon"),
        scopes=request.args.get("scopes", "read,write").split(","),
    )
    return jsonify(key=key)

@app.get("/notes")
@apikee_required
def list_notes():
    c = get_claims()
    return jsonify(tenant=c.tenant, notes=notes.get(c.tenant, []))

@app.post("/notes")
@require_scope("write")
def create_note():
    c = get_claims()
    bucket = notes.setdefault(c.tenant, [])
    note = {"id": len(bucket)+1, **request.json}
    bucket.append(note)
    return jsonify(note), 201

@app.delete("/notes/<int:nid>")
@require_scope("admin")
def delete_note(nid):
    c = get_claims()
    notes[c.tenant] = [n for n in notes.get(c.tenant, []) if n["id"] != nid]
    return jsonify(deleted=nid)

if __name__ == "__main__":
    app.run(debug=True, port=5000)
