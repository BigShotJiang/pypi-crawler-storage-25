"""
LangChain tools for NEAR Protocol.
Generated for: LangChain Tool - NEAR filter account
"""
import requests
import json
import base64
from typing import Optional, Type, Any, List, Dict, Union, Tuple, Set, Callable
from pydantic import BaseModel, Field

try:
    from langchain.tools import BaseTool
except ImportError:
    from langchain_core.tools import BaseTool  # langchain v0.2+

NEAR_RPC_MAINNET = "https://rpc.mainnet.near.org"
NEAR_RPC_TESTNET = "https://rpc.testnet.near.org"


def _near_rpc(method: str, params: Any, network: str = "mainnet") -> dict:
    """Execute NEAR JSON-RPC call."""
    url = NEAR_RPC_MAINNET if network == "mainnet" else NEAR_RPC_TESTNET
    resp = requests.post(url, json={"jsonrpc":"2.0","id":"1","method":method,"params":params}, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    if "error" in data:
        raise RuntimeError(f"NEAR RPC error: {data['error']}")
    return data.get("result", {})


class NEARAccountInput(BaseModel):
    account_id: str = Field(description="NEAR account ID (e.g. example.near)")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARAccountTool(BaseTool):
    """Query NEAR account balance and storage info."""
    name: str = "near_account_info"
    description: str = "Get NEAR account balance and info. Input: account_id, network (optional)"
    args_schema: Type[BaseModel] = NEARAccountInput

    def _run(self, account_id: str, network: str = "mainnet") -> str:
        result = _near_rpc("query", {
            "request_type": "view_account", "finality": "final", "account_id": account_id
        }, network)
        near = int(result.get("amount", 0)) / 10**24
        return json.dumps({"account_id": account_id, "balance_near": f"{near:.4f}",
            "storage_bytes": result.get("storage_usage", 0)})

    async def _arun(self, account_id: str, network: str = "mainnet") -> str:
        return self._run(account_id, network)


class NEARViewFunctionInput(BaseModel):
    contract_id: str = Field(description="NEAR contract ID")
    method_name: str = Field(description="View method name")
    args: dict = Field(default={}, description="Method arguments")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARViewFunctionTool(BaseTool):
    """Call a view function on a NEAR smart contract."""
    name: str = "near_view_function"
    description: str = "Call a NEAR contract view function. Input: contract_id, method_name, args"
    args_schema: Type[BaseModel] = NEARViewFunctionInput

    def _run(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        args_b64 = base64.b64encode(json.dumps(args).encode()).decode()
        result = _near_rpc("query", {
            "request_type": "call_function", "finality": "final",
            "account_id": contract_id, "method_name": method_name, "args_base64": args_b64
        }, network)
        decoded = json.loads(bytes(result["result"]).decode())
        return json.dumps(decoded, indent=2)

    async def _arun(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        return self._run(contract_id, method_name, args, network)


class FilterAccountsInput(BaseModel):
    account_ids: List[str]
    min_balance_near: Optional[float] = None
    max_balance_near: Optional[float] = None
    require_code_hash: Optional[bool] = None
    storage_min_bytes: Optional[int] = None
    network: str = "mainnet"

class NEARFilterAccountsTool(BaseTool):
    name: str = "near_filter_accounts"
    description: str = (
        "Filter a list of NEAR account IDs by criteria: balance range (in NEAR), "
        "whether they have deployed contract code, and minimum storage usage in bytes. "
        "Returns only accounts matching ALL specified filters."
    )
    args_schema: Type[BaseModel] = FilterAccountsInput

    def _fetch_and_filter(self, account_ids: List[str], min_balance_near: Optional[float],
                          max_balance_near: Optional[float], require_code_hash: Optional[bool],
                          storage_min_bytes: Optional[int], network: str) -> Dict[str, Any]:
        matched = []
        skipped = []
        for account_id in account_ids:
            try:
                result = _near_rpc('query', {
                    'request_type': 'view_account',
                    'finality': 'final',
                    'account_id': account_id
                }, network=network)
                if 'error' in result:
                    skipped.append({'account_id': account_id, 'reason': result.get('error', 'rpc error')})
                    continue
                balance_yocto = int(result.get('amount', 0))
                balance_near = balance_yocto / 1e24
                storage_bytes = result.get('storage_usage', 0)
                code_hash = result.get('code_hash', '11111111111111111111111111111111')
                has_code = code_hash != '11111111111111111111111111111111'
                if min_balance_near is not None and balance_near < min_balance_near:
                    continue
                if max_balance_near is not None and balance_near > max_balance_near:
                    continue
                if require_code_hash is not None and has_code != require_code_hash:
                    continue
                if storage_min_bytes is not None and storage_bytes < storage_min_bytes:
                    continue
                matched.append({
                    'account_id': account_id,
                    'balance_near': round(balance_near, 6),
                    'storage_usage_bytes': storage_bytes,
                    'has_contract': has_code,
                    'code_hash': code_hash
                })
            except Exception as e:
                skipped.append({'account_id': account_id, 'reason': str(e)})
        return {'matched': matched, 'matched_count': len(matched),
                'skipped': skipped, 'total_checked': len(account_ids)}

    def _run(self, account_ids: List[str], min_balance_near: Optional[float] = None,
             max_balance_near: Optional[float] = None, require_code_hash: Optional[bool] = None,
             storage_min_bytes: Optional[int] = None, network: str = "mainnet") -> Dict[str, Any]:
        return self._fetch_and_filter(account_ids, min_balance_near, max_balance_near,
                                      require_code_hash, storage_min_bytes, network)

    async def _arun(self, account_ids: List[str], min_balance_near: Optional[float] = None,
                    max_balance_near: Optional[float] = None, require_code_hash: Optional[bool] = None,
                    storage_min_bytes: Optional[int] = None, network: str = "mainnet") -> Dict[str, Any]:
        import asyncio
        return await asyncio.get_event_loop().run_in_executor(
            None, lambda: self._fetch_and_filter(account_ids, min_balance_near, max_balance_near,
                                                  require_code_hash, storage_min_bytes, network))


class FilterAccountsByActivityInput(BaseModel):
    account_ids: List[str]
    min_stake_near: Optional[float] = None
    locked_only: Optional[bool] = None
    network: str = "mainnet"

class NEARFilterAccountsByStakeTool(BaseTool):
    name: str = "near_filter_accounts_by_stake"
    description: str = (
        "Filter NEAR accounts by staking/locking criteria: minimum locked (staked) NEAR amount, "
        "or whether any amount is locked. Useful for identifying validators, delegators, or locked accounts."
    )
    args_schema: Type[BaseModel] = FilterAccountsByActivityInput

    def _fetch_and_filter(self, account_ids: List[str], min_stake_near: Optional[float],
                          locked_only: Optional[bool], network: str) -> Dict[str, Any]:
        matched = []
        skipped = []
        for account_id in account_ids:
            try:
                result = _near_rpc('query', {
                    'request_type': 'view_account',
                    'finality': 'final',
                    'account_id': account_id
                }, network=network)
                if 'error' in result:
                    skipped.append({'account_id': account_id, 'reason': result.get('error', 'rpc error')})
                    continue
                locked_yocto = int(result.get('locked', 0))
                locked_near = locked_yocto / 1e24
                if locked_only is True and locked_near <= 0:
                    continue
                if locked_only is False and locked_near > 0:
                    continue
                if min_stake_near is not None and locked_near < min_stake_near:
                    continue
                matched.append({
                    'account_id': account_id,
                    'locked_near': round(locked_near, 6),
                    'liquid_near': round(int(result.get('amount', 0)) / 1e24, 6),
                    'storage_usage_bytes': result.get('storage_usage', 0)
                })
            except Exception as e:
                skipped.append({'account_id': account_id, 'reason': str(e)})
        return {'matched': matched, 'matched_count': len(matched),
                'skipped': skipped, 'total_checked': len(account_ids)}

    def _run(self, account_ids: List[str], min_stake_near: Optional[float] = None,
             locked_only: Optional[bool] = None, network: str = "mainnet") -> Dict[str, Any]:
        return self._fetch_and_filter(account_ids, min_stake_near, locked_only, network)

    async def _arun(self, account_ids: List[str], min_stake_near: Optional[float] = None,
                    locked_only: Optional[bool] = None, network: str = "mainnet") -> Dict[str, Any]:
        import asyncio
        return await asyncio.get_event_loop().run_in_executor(
            None, lambda: self._fetch_and_filter(account_ids, min_stake_near, locked_only, network))