"""
CLI entry point for the Infinium Claude Code Connector.
"""
from __future__ import annotations

import json
import logging
import re
import sys
from pathlib import Path
from typing import Optional

import click

from . import __version__

_UUID_RE = re.compile(
    r"^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$",
    re.IGNORECASE,
)

_DEFAULT_EVENTS = [
    "SessionStart",
    "SessionEnd",
    "UserPromptSubmit",
    "PreToolUse",
    "PostToolUse",
    "PostToolUseFailure",
    "Stop",
    "SubagentStart",
    "SubagentStop",
]


@click.group()
@click.version_option(version=__version__, prog_name="infinium-connector")
def main() -> None:
    """Infinium Claude Code Connector — bridge Claude Code to Infinium agent tracing.

    \b
    Shortcut: If 'infinium' is not on your PATH, use:
      python -m infinium_connector <command>
    """
    pass


# ---------------------------------------------------------------------------
# init — interactive setup wizard
# ---------------------------------------------------------------------------


@main.command()
@click.option("--agent-id", default=None, help="Infinium Agent ID (non-interactive)")
@click.option("--agent-secret", default=None, help="Infinium Agent Secret (non-interactive)")
@click.option("--base-url", default=None, help="Infinium API base URL")
@click.option("--no-interactive", is_flag=True, help="Skip prompts, use flags only")
def init(
    agent_id: Optional[str],
    agent_secret: Optional[str],
    base_url: Optional[str],
    no_interactive: bool,
) -> None:
    """Set up Infinium tracing for Claude Code (project-level)."""
    from .config import (
        get_active_config_source,
        has_existing_config,
        load_credentials,
        save_credentials,
    )

    if no_interactive:
        _init_non_interactive(agent_id, agent_secret, base_url)
        return

    click.echo()
    click.echo("  Infinium Claude Code Connector")
    click.echo("  ===============================")
    click.echo()

    # Check for existing config
    if has_existing_config():
        existing_id, _, existing_url = load_credentials()
        source = get_active_config_source()
        source_label = {"project": "project", "env": "environment variables"}.get(source, source)
        click.echo("  Existing configuration found:")
        click.echo(f"    Agent ID:  {existing_id[:12]}...")
        click.echo(f"    API URL:   {existing_url}")
        click.echo(f"    Source:    {source_label}")

        # Check where hooks are configured
        hooks_path = _find_existing_hooks()
        if hooks_path:
            click.echo(f"    Hooks:     {hooks_path}")
        click.echo()

        choice = click.prompt(
            "  What would you like to do?\n"
            "    [1] Update credentials\n"
            "    [2] Reconfigure hooks\n"
            "    [3] Full re-setup\n"
            "    [4] Cancel\n\n"
            "  Choice",
            type=click.IntRange(1, 4),
            default=4,
        )

        if choice == 1:
            _update_credentials_interactive(existing_id)
            return
        elif choice == 2:
            # Re-run hook setup with existing credentials
            _setup_hooks_interactive()
            return
        elif choice == 3:
            pass  # Fall through to full setup
        else:
            click.echo("\n  Cancelled.")
            return

    click.echo()
    click.echo("  Tracing will be configured for this project only.")
    click.echo()

    # --- Agent ID ---
    if agent_id:
        entered_id = agent_id
    else:
        entered_id = click.prompt("  Enter your Infinium Agent ID")

    entered_id = entered_id.strip()
    if not _UUID_RE.match(entered_id):
        click.echo(
            f"\n  Warning: '{entered_id}' doesn't look like a UUID. "
            "Proceeding anyway.\n"
        )

    # --- Agent Secret ---
    if agent_secret:
        entered_secret = agent_secret
    else:
        entered_secret = click.prompt(
            "  Enter your Infinium Agent Secret", hide_input=True
        )

    entered_secret = entered_secret.strip()
    if not entered_secret:
        click.echo("\n  Error: Agent Secret cannot be empty.", err=True)
        sys.exit(1)

    url = base_url or "https://platform.i42m.ai/api/v1"

    click.echo()

    # --- Save credentials ---
    path, keyring_ok = save_credentials(entered_id, entered_secret, url)

    click.echo(f"  Config saved to:    {path}")
    if keyring_ok:
        click.echo("  Secret stored in:   OS keyring (secure)")
    else:
        click.echo(
            "  Warning: Could not store secret in OS keyring.\n"
            "  Set INFINIUM_AGENT_SECRET as an environment variable instead."
        )

    # --- Write hooks ---
    hooks_path = _write_hooks()
    click.echo(f"  Hooks written to:   {hooks_path}")

    # Remind about .gitignore
    gitignore_path = Path.cwd() / ".gitignore"
    needs_gitignore = True
    if gitignore_path.exists():
        content = gitignore_path.read_text(encoding="utf-8")
        if ".infinium/" in content or ".infinium" in content:
            needs_gitignore = False
    if needs_gitignore:
        click.echo()
        click.echo("  Tip: Add .infinium/ to your .gitignore to keep config out of git.")

    click.echo()
    click.echo("  Setup complete! Claude Code will now send traces to Infinium.")
    click.echo()
    _print_quick_reference()


def _init_non_interactive(
    agent_id: Optional[str],
    agent_secret: Optional[str],
    base_url: Optional[str],
) -> None:
    """Non-interactive setup for CI/scripting."""
    from .config import save_credentials

    if not agent_id or not agent_secret:
        click.echo(
            "Error: --agent-id and --agent-secret are required with --no-interactive",
            err=True,
        )
        sys.exit(1)

    url = base_url or "https://platform.i42m.ai/api/v1"

    path, keyring_ok = save_credentials(agent_id, agent_secret, url)
    hooks_path = _write_hooks()

    click.echo(f"Config saved to: {path}")
    click.echo(f"Hooks written to: {hooks_path}")
    if not keyring_ok:
        click.echo("Warning: Keyring unavailable. Set INFINIUM_AGENT_SECRET env var.")


# ---------------------------------------------------------------------------
# setup — alias for init (backwards compatibility)
# ---------------------------------------------------------------------------

@main.command(hidden=True)
@click.pass_context
def setup(ctx: click.Context) -> None:
    """Alias for init (backwards compatibility)."""
    ctx.invoke(init)


# ---------------------------------------------------------------------------
# update-credentials
# ---------------------------------------------------------------------------


@main.command("update-credentials")
@click.option("--agent-id", default=None, help="New Agent ID")
@click.option("--agent-secret", default=None, help="New Agent Secret")
def update_credentials(agent_id: Optional[str], agent_secret: Optional[str]) -> None:
    """Update your Infinium credentials."""
    from .config import require_project_config

    require_project_config()
    _update_credentials_interactive(
        override_id=agent_id, override_secret=agent_secret
    )


def _update_credentials_interactive(
    existing_id: Optional[str] = None,
    override_id: Optional[str] = None,
    override_secret: Optional[str] = None,
) -> None:
    """Prompt to update credentials."""
    from .config import load_credentials, save_credentials

    current_id, _, current_url = load_credentials()
    display_id = existing_id or current_id

    click.echo()

    if override_id and override_secret:
        # Fully non-interactive
        new_id = override_id
        new_secret = override_secret
    else:
        if display_id:
            click.echo(f"  Current Agent ID: {display_id[:12]}...")
            change_id = click.confirm("  Change Agent ID?", default=False)
            if change_id:
                new_id = click.prompt("  Enter new Agent ID").strip()
            else:
                new_id = display_id
        else:
            new_id = click.prompt("  Enter your Infinium Agent ID").strip()

        if override_secret:
            new_secret = override_secret
        else:
            new_secret = click.prompt(
                "  Enter your Agent Secret", hide_input=True
            ).strip()

    if not new_secret:
        click.echo("\n  Error: Agent Secret cannot be empty.", err=True)
        return

    path, keyring_ok = save_credentials(
        new_id, new_secret, current_url
    )

    click.echo()
    click.echo(f"  Credentials updated! (saved to {path})")
    if keyring_ok:
        click.echo("  Secret stored in OS keyring.")
    else:
        click.echo(
            "  Warning: Could not store secret in OS keyring.\n"
            "  Set INFINIUM_AGENT_SECRET as an environment variable."
        )
    click.echo()


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------


@main.command()
def status() -> None:
    """Show current configuration."""
    from .config import (
        get_active_config_source,
        is_paused,
        load_credentials,
        project_config_path,
        require_project_config,
    )

    require_project_config()

    agent_id, agent_secret, base_url = load_credentials()
    paused = is_paused()
    source = get_active_config_source()

    click.echo()
    click.echo("  Infinium Connector Status")
    click.echo("  -------------------------")

    # Tracing state
    if paused:
        click.echo("  Tracing:      PAUSED")
    else:
        click.echo("  Tracing:      active")

    if agent_id:
        click.echo(f"  Agent ID:     {agent_id[:12]}...")
    else:
        click.echo("  Agent ID:     (not configured)")

    if agent_secret:
        click.echo("  Secret:       configured")
    else:
        click.echo("  Secret:       (not configured)")

    click.echo(f"  API URL:      {base_url}")

    # Config source
    source_labels = {
        "project": f"project ({project_config_path()})",
        "env": "environment variables",
    }
    if source:
        click.echo(f"  Config from:  {source_labels.get(source, source)}")
    else:
        click.echo("  Config from:  (not found)")

    # Failed trace count
    from . import session_store
    failed_count = session_store.count_failed()
    if failed_count:
        click.echo(f"  Pending retry: {failed_count} failed trace(s)")

    # Last error
    from . import error_log
    last_err = error_log.last_error()
    if last_err:
        err_time = last_err.get("timestamp", "")[:16].replace("T", " ")
        err_msg = last_err.get("message", "")[:60]
        click.echo(f"  Last error:    {err_time} — {err_msg}")
        click.echo("                 Run 'infinium errors' for details.")

    # Check for hooks
    for label, path in [
        ("Hooks", Path.cwd() / ".claude" / "settings.json"),
    ]:
        if path.exists():
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                hooks = data.get("hooks", {})
                infinium_hooks = sum(
                    1
                    for v in hooks.values()
                    if any(
                        "infinium_connector" in str(h)
                        for entry in v
                        for h in entry.get("hooks", [])
                    )
                )
                if infinium_hooks:
                    click.echo(f"  {label}:  {path} ({infinium_hooks} events)")
            except (json.JSONDecodeError, OSError):
                pass

    click.echo()


# ---------------------------------------------------------------------------
# pause
# ---------------------------------------------------------------------------


@main.command()
def pause() -> None:
    """Pause tracing — hooks stay installed but traces are not sent."""
    from .config import is_paused, require_project_config, set_paused

    require_project_config()

    if is_paused():
        click.echo("\n  Tracing is already paused.\n")
        return

    set_paused(True)
    click.echo("\n  Tracing paused. Hooks are still installed but traces will be skipped.")
    click.echo("  Run 'infinium resume' to resume.\n")


# Alias: stop → pause
@main.command("stop", hidden=True)
@click.pass_context
def stop_alias(ctx: click.Context) -> None:
    """Alias for pause."""
    ctx.invoke(pause)


# ---------------------------------------------------------------------------
# resume
# ---------------------------------------------------------------------------


@main.command()
def resume() -> None:
    """Resume tracing after a pause."""
    from .config import is_paused, require_project_config, set_paused

    require_project_config()

    if not is_paused():
        click.echo("\n  Tracing is already active.\n")
        return

    set_paused(False)
    click.echo("\n  Tracing resumed! New Claude Code sessions will send traces.\n")


# Alias: continue → resume (can't use "continue" as Python keyword, but Click is fine)
@main.command("continue", hidden=True)
@click.pass_context
def continue_alias(ctx: click.Context) -> None:
    """Alias for resume."""
    ctx.invoke(resume)


# ---------------------------------------------------------------------------
# uninstall
# ---------------------------------------------------------------------------


@main.command()
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
def uninstall(yes: bool) -> None:
    """Remove the Infinium connector completely."""
    from .config import delete_config, require_project_config

    require_project_config()

    click.echo()
    click.echo("  This will remove:")
    click.echo("    - Infinium hooks from Claude Code settings")
    click.echo("    - Credentials (config file + keyring secret)")
    click.echo()

    if not yes:
        if not click.confirm("  Are you sure?", default=False):
            click.echo("\n  Cancelled.\n")
            return

    # Remove hooks from all locations
    removed_hooks = _remove_hooks()

    # Remove config + keyring
    delete_config()

    click.echo()
    if removed_hooks:
        for p in removed_hooks:
            click.echo(f"  Hooks removed from: {p}")
    else:
        click.echo("  No hooks found to remove.")
    click.echo("  Credentials removed.")
    click.echo()
    click.echo("  Uninstall complete. You can reinstall anytime with:")
    click.echo("    pip install infinium-claude-code-connector")
    click.echo("    infinium init")
    click.echo()
    click.echo("  (or: python -m infinium_connector init)")
    click.echo()


# ---------------------------------------------------------------------------
# test — verify connection
# ---------------------------------------------------------------------------


@main.command("test")
@click.option("--verbose", "-v", is_flag=True, help="Show the full payload")
def test_connection(verbose: bool) -> None:
    """Send a test trace to verify your setup works."""
    from .config import ConnectorConfig, require_project_config
    from .types import InfiniumTracePayload
    from . import sdk_bridge
    from infinium import get_current_iso_datetime

    require_project_config()
    config = ConnectorConfig.load()

    try:
        config.validate()
    except ValueError as e:
        click.echo(f"\n  Configuration error: {e}", err=True)
        sys.exit(1)

    click.echo()
    click.echo(f"  Agent ID:  {config.agent_id[:12]}...")
    click.echo(f"  API URL:   {config.base_url}")
    click.echo("  Sending test trace...")

    payload = InfiniumTracePayload(
        name="Connection Test",
        description="Test trace from Infinium CLI",
        current_datetime=get_current_iso_datetime(),
        duration=0.0,
        input_summary="Test ping",
        output_summary="Connection verified",
        steps=[
            {
                "step_number": 1,
                "action": "test_ping",
                "description": "Verify connector-to-Infinium connectivity",
            }
        ],
    )

    if verbose:
        click.echo()
        click.echo("  Payload:")
        click.echo(json.dumps(payload.to_dict(), indent=2))
        click.echo()

    try:
        result = sdk_bridge.send_trace(config, payload)
        trace_id = result.get("traceId", result.get("id", "unknown"))
        click.echo()
        click.echo(f"  Connection verified! Trace ID: {trace_id}")
        click.echo("  Your setup is working correctly.")
        click.echo()
    except Exception as e:
        click.echo()
        click.echo(f"  Connection failed: {e}", err=True)
        click.echo()
        click.echo("  Troubleshooting:")
        click.echo("    - Check your Agent ID and Secret are correct")
        click.echo("    - Verify your API key is active in Infinium")
        click.echo("    - Check network connectivity to the API")
        click.echo()
        sys.exit(1)


# ---------------------------------------------------------------------------
# retry — resend failed traces
# ---------------------------------------------------------------------------


@main.command()
@click.option("--dry-run", is_flag=True, help="Show what would be retried without sending")
def retry(dry_run: bool) -> None:
    """Retry sending failed traces."""
    from . import session_store
    from .aggregator import SessionAggregator
    from . import sdk_bridge
    from . import history
    from .config import ConnectorConfig, require_project_config

    require_project_config()
    config = ConnectorConfig.load()

    try:
        config.validate()
    except ValueError as e:
        click.echo(f"\n  Configuration error: {e}", err=True)
        sys.exit(1)

    failed_files = session_store.list_failed(config.session_dir)

    if not failed_files:
        click.echo("\n  No failed traces to retry.\n")
        return

    click.echo(f"\n  Found {len(failed_files)} failed trace(s).")

    if dry_run:
        click.echo("  (dry run — not sending)\n")
        for f in failed_files:
            events = session_store.read_failed_events(f)
            event_count = len(events)
            session_id = f.stem[:12]
            click.echo(f"    {f.name}  ({event_count} events, session: {session_id}...)")
        click.echo()
        return

    click.echo()
    succeeded = 0
    failed = 0

    for f in failed_files:
        events = session_store.read_failed_events(f)
        if not events:
            session_store.remove_failed(f)
            continue

        # Replay through aggregator
        aggregator = SessionAggregator(config)
        payload = None
        for ev in events:
            _, p = aggregator.ingest(ev)
            if p is not None:
                payload = p

        if payload is None:
            payloads = aggregator.flush_all()
            payload = payloads[0] if payloads else None

        if payload is None:
            click.echo(f"    {f.stem[:12]}... — skipped (no payload)")
            session_store.remove_failed(f)
            continue

        try:
            result = sdk_bridge.send_trace(config, payload)
            trace_id = result.get("traceId", result.get("id", "unknown"))
            click.echo(f"    {f.stem[:12]}... — sent (trace: {trace_id})")
            session_store.remove_failed(f)
            succeeded += 1

            # Update history
            try:
                history.append_entry({
                    "timestamp": payload.current_datetime,
                    "session_id": f.stem[:12],
                    "trace_id": str(trace_id),
                    "name": payload.name,
                    "turns": len(payload.steps or []),
                    "tool_calls": sum(
                        1 for s in (payload.steps or [])
                        if s.get("action", "").startswith("tool_use")
                    ),
                    "errors": len(payload.errors or []),
                    "duration_s": round(payload.duration, 1),
                    "status": "retried",
                })
            except Exception:
                pass

        except Exception as e:
            click.echo(f"    {f.stem[:12]}... — failed ({e})")
            failed += 1

    click.echo()
    click.echo(f"  Retried {succeeded + failed} trace(s): {succeeded} succeeded, {failed} failed.")
    if failed:
        click.echo("  Failed traces remain in the queue for next retry.")
    click.echo()


# ---------------------------------------------------------------------------
# history — view local trace log
# ---------------------------------------------------------------------------


@main.command()
@click.option("--limit", "-n", default=10, type=int, help="Number of entries to show")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON")
@click.option("--clear", is_flag=True, help="Clear all history")
def history(limit: int, as_json: bool, clear: bool) -> None:
    """View local trace history."""
    from . import history as hist

    if clear:
        if hist.clear_history():
            click.echo("\n  History cleared.\n")
        else:
            click.echo("\n  No history to clear.\n")
        return

    entries = hist.read_entries(limit)

    if not entries:
        click.echo("\n  No trace history yet. Traces will appear here after your next Claude Code session.\n")
        return

    if as_json:
        for e in entries:
            click.echo(json.dumps(e))
        return

    click.echo()
    click.echo(f"  Last {len(entries)} trace(s):")
    click.echo()

    # Table header
    click.echo(
        f"  {'Time':<20} {'Steps':>5} {'Tools':>5} {'Errors':>6} "
        f"{'Status':<8} {'Trace ID'}"
    )
    click.echo(f"  {'-'*20} {'-'*5} {'-'*5} {'-'*6} {'-'*8} {'-'*12}")

    for e in entries:
        ts = e.get("timestamp", "")[:16].replace("T", " ")
        turns = e.get("turns", 0)
        tools = e.get("tool_calls", 0)
        errors = e.get("errors", 0)
        status = e.get("status", "?")
        trace_id = e.get("trace_id") or "—"
        if isinstance(trace_id, str) and len(trace_id) > 12:
            trace_id = trace_id[:12] + "..."

        click.echo(
            f"  {ts:<20} {turns:>5} {tools:>5} {errors:>6} "
            f"{status:<8} {trace_id}"
        )

    click.echo()
    total = hist.count_entries()
    if total > limit:
        click.echo(f"  Showing {len(entries)} of {total} entries. Use --limit to see more.")
        click.echo()


# ---------------------------------------------------------------------------
# errors — view persistent error log
# ---------------------------------------------------------------------------


@main.command()
@click.option("--limit", "-n", default=20, type=int, help="Number of entries to show")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON")
@click.option("--clear", is_flag=True, help="Clear error log")
def errors(limit: int, as_json: bool, clear: bool) -> None:
    """View recent connector errors."""
    from . import error_log

    if clear:
        if error_log.clear_errors():
            click.echo("\n  Error log cleared.\n")
        else:
            click.echo("\n  No error log to clear.\n")
        return

    entries = error_log.read_errors(limit)

    if not entries:
        click.echo("\n  No errors recorded. Everything is working correctly.\n")
        return

    if as_json:
        for e in entries:
            click.echo(json.dumps(e))
        return

    click.echo()
    click.echo(f"  Last {len(entries)} error(s):")
    click.echo()

    click.echo(
        f"  {'Time':<20} {'Type':<18} {'Session':<14} {'Message'}"
    )
    click.echo(f"  {'-'*20} {'-'*18} {'-'*14} {'-'*40}")

    for e in entries:
        ts = e.get("timestamp", "")[:16].replace("T", " ")
        etype = e.get("error_type", "unknown")
        sid = e.get("session_id", "?")
        msg = e.get("message", "")[:50]
        click.echo(f"  {ts:<20} {etype:<18} {sid:<14} {msg}")

    click.echo()


# ---------------------------------------------------------------------------
# start (HTTP server mode)
# ---------------------------------------------------------------------------


@main.command()
@click.option("--host", default=None, help="Bind host (default: 127.0.0.1)")
@click.option("--port", default=None, type=int, help="Bind port (default: 9339)")
@click.option("--log-level", default=None, help="Log level")
def start(
    host: Optional[str],
    port: Optional[int],
    log_level: Optional[str],
) -> None:
    """Start the HTTP server (requires [server] extra)."""
    try:
        import uvicorn  # noqa: F401
    except ImportError:
        click.echo(
            "HTTP server mode requires the [server] extra.\n"
            "Install with: pip install infinium-claude-code-connector[server]",
            err=True,
        )
        sys.exit(1)

    from .config import ConnectorConfig, require_project_config

    require_project_config()
    config = ConnectorConfig.load()
    config.mode = "http"

    if host is not None:
        config.host = host
    if port is not None:
        config.port = port
    if log_level is not None:
        config.log_level = log_level

    try:
        config.validate()
    except ValueError as e:
        click.echo(f"Configuration error: {e}", err=True)
        sys.exit(1)

    logging.basicConfig(
        level=getattr(logging, config.log_level.upper(), logging.INFO),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )

    click.echo("Starting Infinium Claude Code Connector (HTTP server mode)")
    click.echo(f"  Hook URL:  {config.hook_url}")
    click.echo(f"  Agent ID:  {config.agent_id[:8]}...")
    click.echo()

    from .server import create_app

    app = create_app(config)
    uvicorn.run(app, host=config.host, port=config.port, log_level=config.log_level.lower())


# ---------------------------------------------------------------------------
# health
# ---------------------------------------------------------------------------


@main.command()
@click.option("--host", default="127.0.0.1")
@click.option("--port", default=9339, type=int)
def health(host: str, port: int) -> None:
    """Check if the HTTP server is running."""
    import httpx

    url = f"http://{host}:{port}/health"
    try:
        resp = httpx.get(url, timeout=5.0)
        data = resp.json()
        click.echo(f"Status: {data.get('status', 'unknown')}")
        click.echo(f"Version: {data.get('version', 'unknown')}")
        click.echo(f"Active sessions: {data.get('active_sessions', 0)}")
    except Exception as e:
        click.echo(f"Connector not reachable at {url}: {e}", err=True)
        sys.exit(1)


# ---------------------------------------------------------------------------
# cleanup
# ---------------------------------------------------------------------------


@main.command()
@click.option("--max-age", default=3600, type=int, help="Max age in seconds (default: 3600)")
@click.option("--session-dir", default=None, help="Override session directory")
def cleanup(max_age: int, session_dir: Optional[str]) -> None:
    """Remove stale session files."""
    from . import session_store

    removed = session_store.cleanup_stale(max_age, session_dir)
    if removed:
        click.echo(f"Removed {len(removed)} stale session file(s).")
    else:
        click.echo("No stale session files found.")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _write_hooks() -> Path:
    """Write Claude Code command hook settings to the project. Returns the settings file path."""
    hooks_config = {}
    for event_name in _DEFAULT_EVENTS:
        hooks_config[event_name] = [
            {
                "matcher": ".*",
                "hooks": [
                    {
                        "type": "command",
                        "command": "python -m infinium_connector.hook",
                        "timeout": 15000,
                    }
                ],
            }
        ]

    settings_dir = Path.cwd() / ".claude"
    settings_path = settings_dir / "settings.json"

    # Read existing settings
    existing = {}
    if settings_path.exists():
        try:
            existing = json.loads(settings_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass

    if "hooks" not in existing:
        existing["hooks"] = {}
    existing["hooks"].update(hooks_config)

    settings_dir.mkdir(parents=True, exist_ok=True)
    settings_path.write_text(
        json.dumps(existing, indent=2) + "\n", encoding="utf-8"
    )

    return settings_path


def _remove_hooks() -> list[Path]:
    """Remove Infinium hooks from all Claude Code settings files. Returns paths modified."""
    modified = []
    for path in [
        Path.cwd() / ".claude" / "settings.json",
    ]:
        if not path.exists():
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue

        hooks = data.get("hooks", {})
        if not hooks:
            continue

        # Remove any event entries that contain infinium_connector hooks
        cleaned_hooks = {}
        changed = False
        for event_name, entries in hooks.items():
            kept = []
            for entry in entries:
                entry_hooks = entry.get("hooks", [])
                filtered = [
                    h for h in entry_hooks if "infinium_connector" not in str(h)
                ]
                if filtered:
                    entry["hooks"] = filtered
                    kept.append(entry)
                elif entry_hooks:
                    changed = True  # We removed something
            if kept:
                cleaned_hooks[event_name] = kept
            elif entries:
                changed = True

        if changed:
            if cleaned_hooks:
                data["hooks"] = cleaned_hooks
            else:
                del data["hooks"]
            path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
            modified.append(path)

    return modified


def _find_existing_hooks() -> Optional[str]:
    """Find where Infinium hooks are currently configured."""
    path = Path.cwd() / ".claude" / "settings.json"
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            hooks = data.get("hooks", {})
            for entries in hooks.values():
                for entry in entries:
                    for h in entry.get("hooks", []):
                        if "infinium_connector" in str(h):
                            return str(path)
        except (json.JSONDecodeError, OSError):
            pass
    return None


def _print_quick_reference() -> None:
    """Print a quick reference of common commands after setup."""
    click.echo("  Quick Reference")
    click.echo("  ---------------")
    click.echo("  infinium test              Verify your connection works")
    click.echo("  infinium status            Check configuration & tracing state")
    click.echo("  infinium pause             Temporarily stop tracing")
    click.echo("  infinium resume            Resume tracing")
    click.echo("  infinium history           View recent traces")
    click.echo("  infinium errors            View connector errors")
    click.echo("  infinium retry             Resend failed traces")
    click.echo("  infinium update-credentials  Change agent ID or secret")
    click.echo("  infinium uninstall         Remove the connector")
    click.echo()
    click.echo("  Tip: Run 'infinium test' now to verify everything works!")
    click.echo()


def _setup_hooks_interactive() -> None:
    """Write hooks to the project."""
    click.echo()
    hooks_path = _write_hooks()
    click.echo(f"\n  Hooks written to: {hooks_path}")
    click.echo()


if __name__ == "__main__":
    main()
