"""
Local trace history — records a summary of each trace sent to Infinium.

Stored as JSONL at ~/.infinium/history.jsonl. Auto-rotates at 1000 entries.
"""
from __future__ import annotations

import json
import logging
import os
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

_MAX_ENTRIES = 1000


def _history_path() -> Path:
    """Return ~/.infinium/history.jsonl."""
    return Path.home() / ".infinium" / "history.jsonl"


def append_entry(entry: Dict[str, Any]) -> None:
    """Append a single history entry as a JSON line."""
    path = _history_path()
    path.parent.mkdir(parents=True, exist_ok=True)

    line = json.dumps(entry, default=str, separators=(",", ":")) + "\n"
    with open(path, "a", encoding="utf-8") as f:
        f.write(line)

    # Rotate if needed
    _rotate_if_needed(path)


def read_entries(limit: int = 10) -> List[Dict[str, Any]]:
    """Read the last N history entries."""
    path = _history_path()
    if not path.exists():
        return []

    entries: List[Dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                continue

    return entries[-limit:] if limit else entries


def clear_history() -> bool:
    """Delete the history file. Returns True if file existed."""
    path = _history_path()
    if path.exists():
        path.unlink()
        return True
    return False


def count_entries() -> int:
    """Count the number of history entries."""
    path = _history_path()
    if not path.exists():
        return 0
    count = 0
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                count += 1
    return count


def _rotate_if_needed(path: Optional[Path] = None) -> None:
    """Keep only the last _MAX_ENTRIES entries if the file grows too large."""
    path = path or _history_path()
    if not path.exists():
        return

    lines: List[str] = []
    with open(path, "r", encoding="utf-8") as f:
        lines = [l for l in f if l.strip()]

    if len(lines) <= _MAX_ENTRIES:
        return

    # Atomic rotation: write to temp file, then replace
    keep = lines[-_MAX_ENTRIES:]
    try:
        fd, tmp_path = tempfile.mkstemp(
            dir=str(path.parent), suffix=".tmp", prefix="history-"
        )
        with os.fdopen(fd, "w", encoding="utf-8") as tmp:
            tmp.writelines(keep)
        os.replace(tmp_path, str(path))
    except OSError:
        # Fall back to direct write if atomic replace fails
        with open(path, "w", encoding="utf-8") as f:
            f.writelines(keep)
