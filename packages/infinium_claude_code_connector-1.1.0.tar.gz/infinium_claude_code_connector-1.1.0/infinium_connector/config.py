"""
Configuration for the Infinium Claude Code Connector.

Credential loading order (first match wins):
1. Project config (.infinium/config.json in cwd) + keyring
2. Environment variables (override — for CI/Docker)
3. CLI arguments (override everything)
"""
from __future__ import annotations

import json
import logging
import os
import stat
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple

logger = logging.getLogger(__name__)

_KEYRING_SERVICE = "infinium-connector"
_CONFIG_DIR_NAME = ".infinium"
_CONFIG_FILE_NAME = "config.json"


# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------


def project_config_dir(cwd: Optional[Path] = None) -> Path:
    """Return <cwd>/.infinium/."""
    return (cwd or Path.cwd()) / _CONFIG_DIR_NAME


def project_config_path(cwd: Optional[Path] = None) -> Path:
    """Return <cwd>/.infinium/config.json."""
    return project_config_dir(cwd) / _CONFIG_FILE_NAME


# ---------------------------------------------------------------------------
# File I/O
# ---------------------------------------------------------------------------


def _read_config_at(path: Path) -> dict:
    """Read a config file at a specific path, returning empty dict if missing."""
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        logger.warning("Could not read config file %s: %s", path, e)
        return {}


def _write_config_at(path: Path, data: dict) -> Path:
    """Write config data to a specific path with restricted permissions."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")

    # Restrict permissions to owner only (Unix)
    if sys.platform != "win32":
        try:
            path.chmod(stat.S_IRUSR | stat.S_IWUSR)  # 0600
        except OSError:
            pass

    return path


# ---------------------------------------------------------------------------
# Keyring
# ---------------------------------------------------------------------------


def _get_secret_from_keyring(agent_id: str) -> Optional[str]:
    """Retrieve the agent secret from the OS keyring."""
    try:
        import keyring

        secret = keyring.get_password(_KEYRING_SERVICE, agent_id)
        return secret
    except Exception as e:
        logger.debug("Keyring unavailable: %s", e)
        return None


def _set_secret_in_keyring(agent_id: str, secret: str) -> bool:
    """Store the agent secret in the OS keyring. Returns True on success."""
    try:
        import keyring

        keyring.set_password(_KEYRING_SERVICE, agent_id, secret)
        return True
    except Exception as e:
        logger.warning("Could not store secret in keyring: %s", e)
        return False


def _delete_secret_from_keyring(agent_id: str) -> None:
    """Remove the agent secret from the OS keyring."""
    try:
        import keyring

        keyring.delete_password(_KEYRING_SERVICE, agent_id)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Credential loading (project first, then env)
# ---------------------------------------------------------------------------


def _load_from_path(path: Path) -> Tuple[str, str, str]:
    """Load credentials from a specific config file + keyring."""
    data = _read_config_at(path)
    agent_id = data.get("agent_id", "")
    base_url = data.get("base_url", "https://platform.i42m.ai/api/v1")

    agent_secret = ""
    if agent_id:
        agent_secret = _get_secret_from_keyring(agent_id) or ""

    return agent_id, agent_secret, base_url


def load_credentials(cwd: Optional[Path] = None) -> Tuple[str, str, str]:
    """
    Load credentials: project config first, then env vars.

    Returns (agent_id, agent_secret, base_url).
    """
    agent_id = ""
    agent_secret = ""
    base_url = "https://platform.i42m.ai/api/v1"

    # 1. Check project-level config
    proj_path = project_config_path(cwd)
    if proj_path.exists():
        agent_id, agent_secret, base_url = _load_from_path(proj_path)

    # 2. Env vars override (for CI/Docker/headless)
    agent_id = os.environ.get("INFINIUM_AGENT_ID", "") or agent_id
    agent_secret = os.environ.get("INFINIUM_AGENT_SECRET", "") or agent_secret
    base_url = os.environ.get("INFINIUM_BASE_URL", "") or base_url

    return agent_id, agent_secret, base_url


def save_credentials(
    agent_id: str,
    agent_secret: str,
    base_url: str = "https://platform.i42m.ai/api/v1",
    cwd: Optional[Path] = None,
) -> Tuple[Path, bool]:
    """
    Save credentials: agent_id + base_url to project config, secret to keyring.

    Returns (config_file_path, keyring_success).
    """
    path = project_config_path(cwd)

    # Read existing data at that path
    data = _read_config_at(path)
    data["agent_id"] = agent_id
    data["base_url"] = base_url
    written_path = _write_config_at(path, data)

    # Store secret in keyring (per-user)
    keyring_ok = _set_secret_in_keyring(agent_id, agent_secret)

    return written_path, keyring_ok


def has_existing_config(cwd: Optional[Path] = None) -> bool:
    """Check if credentials are already configured (project config)."""
    agent_id, agent_secret, _ = load_credentials(cwd)
    return bool(agent_id and agent_secret)


def require_project_config(cwd: Optional[Path] = None) -> None:
    """Raise click.UsageError if no .infinium/config.json exists in cwd."""
    import click

    path = project_config_path(cwd)
    if not path.exists():
        raise click.UsageError(
            "No Infinium configuration found in this directory.\n"
            "Run this command from your project root (where you ran 'infinium init')."
        )


def get_active_config_source(cwd: Optional[Path] = None) -> Optional[str]:
    """Return which config is active: 'project', 'env', or None."""
    # Check env first (highest priority)
    if os.environ.get("INFINIUM_AGENT_ID"):
        return "env"

    # Check project
    proj_data = _read_config_at(project_config_path(cwd))
    if proj_data.get("agent_id"):
        return "project"

    return None


def is_paused(cwd: Optional[Path] = None) -> bool:
    """Check if tracing is currently paused."""
    proj_data = _read_config_at(project_config_path(cwd))
    return proj_data.get("paused", False) is True


def set_paused(paused: bool, cwd: Optional[Path] = None) -> None:
    """Set the paused state in the project config file."""
    path = project_config_path(cwd)
    data = _read_config_at(path)
    if paused:
        data["paused"] = True
    else:
        data.pop("paused", None)
    _write_config_at(path, data)


def delete_config(cwd: Optional[Path] = None) -> None:
    """Remove project config file and keyring secret."""
    file_path = project_config_path(cwd)
    dir_path = project_config_dir(cwd)

    # Read agent_id before deleting so we can clean keyring
    data = _read_config_at(file_path)
    agent_id = data.get("agent_id", "")
    if agent_id:
        _delete_secret_from_keyring(agent_id)

    if file_path.exists():
        try:
            file_path.unlink()
        except OSError:
            pass

    try:
        dir_path.rmdir()  # Only succeeds if empty
    except OSError:
        pass


@dataclass
class ConnectorConfig:
    """All settings for the connector."""

    # Infinium credentials
    agent_id: str = ""
    agent_secret: str = ""
    base_url: str = "https://platform.i42m.ai/api/v1"

    # Mode: "command" (default, no server) or "http" (requires [server] extra)
    mode: str = "command"

    # Local server (http mode only)
    host: str = "127.0.0.1"
    port: int = 9339
    webhook_path: str = "/hooks/claude-code"

    # Session file storage (command mode only, defaults to system temp dir)
    session_dir: Optional[str] = None

    # Output
    quiet: bool = False  # Suppress stderr trace summaries

    # Behaviour
    flush_on_stop: bool = True
    flush_on_session_end: bool = True
    session_ttl_seconds: int = 3600
    max_input_preview: int = 500
    max_output_preview: int = 500
    log_level: str = "INFO"

    # HTTP client
    timeout: float = 30.0
    max_retries: int = 3
    verify_ssl: bool = True

    @classmethod
    def load(cls, cwd: Optional[Path] = None) -> ConnectorConfig:
        """Load config from credentials file + keyring + env vars."""
        agent_id, agent_secret, base_url = load_credentials(cwd)

        return cls(
            agent_id=agent_id,
            agent_secret=agent_secret,
            base_url=base_url,
            quiet=os.environ.get("CONNECTOR_QUIET", "false").lower() == "true",
            mode=os.environ.get("CONNECTOR_MODE", "command"),
            host=os.environ.get("CONNECTOR_HOST", "127.0.0.1"),
            port=int(os.environ.get("CONNECTOR_PORT", "9339")),
            session_dir=os.environ.get("CONNECTOR_SESSION_DIR") or None,
            webhook_path=os.environ.get("CONNECTOR_WEBHOOK_PATH", "/hooks/claude-code"),
            flush_on_stop=os.environ.get("CONNECTOR_FLUSH_ON_STOP", "true").lower() == "true",
            flush_on_session_end=os.environ.get(
                "CONNECTOR_FLUSH_ON_SESSION_END", "true"
            ).lower() == "true",
            session_ttl_seconds=int(os.environ.get("CONNECTOR_SESSION_TTL", "3600")),
            max_input_preview=int(os.environ.get("CONNECTOR_MAX_INPUT_PREVIEW", "500")),
            max_output_preview=int(os.environ.get("CONNECTOR_MAX_OUTPUT_PREVIEW", "500")),
            log_level=os.environ.get("CONNECTOR_LOG_LEVEL", "INFO"),
            timeout=float(os.environ.get("INFINIUM_TIMEOUT", "30.0")),
            max_retries=int(os.environ.get("INFINIUM_MAX_RETRIES", "3")),
            verify_ssl=os.environ.get("INFINIUM_VERIFY_SSL", "true").lower() == "true",
        )

    # Keep for backwards compatibility
    @classmethod
    def from_env(cls) -> ConnectorConfig:
        """Alias for load()."""
        return cls.load()

    def validate(self) -> None:
        """Raise ValueError if required fields are missing."""
        if not self.agent_id or not self.agent_id.strip():
            raise ValueError(
                "Agent ID is required. Run 'infinium init' to configure."
            )
        if not self.agent_secret or not self.agent_secret.strip():
            raise ValueError(
                "Agent Secret is required. Run 'infinium init' to configure."
            )

    @property
    def hook_url(self) -> str:
        """Full URL for HTTP hook mode."""
        return f"http://{self.host}:{self.port}{self.webhook_path}"
