"""
JSONL-based session file storage for command hook mode.

Each Claude Code session gets a .jsonl file in a temp directory.
Events are appended as single JSON lines. On flush, all events
are read back and replayed through the aggregator.
"""
from __future__ import annotations

import json
import logging
import os
import sys
import tempfile
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

_SESSION_DIR_NAME = "infinium-sessions"


def get_session_dir(override: Optional[str] = None) -> Path:
    """Return the directory for session JSONL files, creating it if needed."""
    if override:
        d = Path(override)
    else:
        d = Path(tempfile.gettempdir()) / _SESSION_DIR_NAME
    d.mkdir(parents=True, exist_ok=True)
    return d


def _session_path(session_id: str, session_dir: Optional[str] = None) -> Path:
    """Return the JSONL file path for a given session ID."""
    # Sanitize session_id for filesystem safety
    safe_id = "".join(c for c in session_id if c.isalnum() or c in "-_")
    if not safe_id:
        safe_id = f"unknown-{uuid.uuid4().hex[:8]}"
    return get_session_dir(session_dir) / f"{safe_id}.jsonl"


def append_event(
    session_id: str,
    event: Dict[str, Any],
    session_dir: Optional[str] = None,
) -> None:
    """Append a single event as a JSON line to the session file."""
    path = _session_path(session_id, session_dir)
    line = json.dumps(event, default=str, separators=(",", ":")) + "\n"

    if sys.platform == "win32":
        _append_locked_win32(path, line.encode("utf-8"))
    else:
        # On Unix, O_APPEND + write is atomic for payloads < PIPE_BUF (4096+)
        with open(path, "a", encoding="utf-8") as f:
            f.write(line)


def _append_locked_win32(path: Path, data: bytes) -> None:
    """Append with exclusive file lock on Windows to prevent concurrent write corruption."""
    import msvcrt

    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o666)
    try:
        try:
            msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
            os.write(fd, data)
            os.lseek(fd, 0, os.SEEK_SET)
            msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
        except (OSError, IOError):
            # Lock failed — write anyway (better than losing the event)
            os.write(fd, data)
    finally:
        os.close(fd)


def read_events(
    session_id: str,
    session_dir: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Read all events for a session, skipping malformed lines."""
    path = _session_path(session_id, session_dir)
    if not path.exists():
        return []

    events: List[Dict[str, Any]] = []
    skipped = 0
    total_lines = 0
    with open(path, "r", encoding="utf-8") as f:
        for line_num, line in enumerate(f, 1):
            total_lines = line_num
            line = line.strip()
            if not line:
                continue
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                skipped += 1
                logger.warning(
                    "Skipping malformed JSON on line %d of %s",
                    line_num,
                    path.name,
                )

    if skipped > 0:
        try:
            from . import error_log

            error_log.append_error(
                error_type="corrupted_jsonl",
                session_id=session_id[:12] if session_id else "unknown",
                message=f"Skipped {skipped} malformed line(s) in session file",
                context={"file": path.name, "total_lines": total_lines},
            )
        except Exception:
            pass

    return events


def _flushed_path(session_id: str, session_dir: Optional[str] = None) -> Path:
    """Return the flush-offset sidecar path for a session."""
    base = _session_path(session_id, session_dir)
    return base.with_suffix(".flushed")


def read_flush_offset(session_id: str, session_dir: Optional[str] = None) -> int:
    """Read the number of events already flushed. Returns 0 if missing or corrupt."""
    path = _flushed_path(session_id, session_dir)
    if not path.exists():
        return 0
    try:
        return int(path.read_text(encoding="utf-8").strip())
    except (ValueError, OSError):
        return 0


def write_flush_offset(
    session_id: str, count: int, session_dir: Optional[str] = None
) -> None:
    """Write the flush offset (number of events already sent)."""
    path = _flushed_path(session_id, session_dir)
    _atomic_write_sidecar(path, str(count) + "\n")


def remove_flush_offset(session_id: str, session_dir: Optional[str] = None) -> None:
    """Delete the flush-offset sidecar file."""
    path = _flushed_path(session_id, session_dir)
    try:
        path.unlink(missing_ok=True)
    except OSError:
        pass


def _atomic_write_sidecar(path: Path, content: str) -> None:
    """Write content atomically via temp file + os.replace."""
    try:
        fd, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(content)
        os.replace(tmp, str(path))
    except OSError:
        # Fall back to direct write
        try:
            os.unlink(tmp)
        except (OSError, UnboundLocalError):
            pass
        path.write_text(content, encoding="utf-8")


# ---------------------------------------------------------------------------
# Consecutive failure tracking
# ---------------------------------------------------------------------------


def _failures_path(session_id: str, session_dir: Optional[str] = None) -> Path:
    """Return the failure-count sidecar path for a session."""
    base = _session_path(session_id, session_dir)
    return base.with_suffix(".failures")


def read_failure_count(session_id: str, session_dir: Optional[str] = None) -> int:
    """Read the number of consecutive flush failures. Returns 0 if missing."""
    path = _failures_path(session_id, session_dir)
    if not path.exists():
        return 0
    try:
        return int(path.read_text(encoding="utf-8").strip())
    except (ValueError, OSError):
        return 0


def increment_failure_count(
    session_id: str, session_dir: Optional[str] = None
) -> int:
    """Increment and return the consecutive failure count."""
    count = read_failure_count(session_id, session_dir) + 1
    _atomic_write_sidecar(_failures_path(session_id, session_dir), str(count) + "\n")
    return count


def reset_failure_count(session_id: str, session_dir: Optional[str] = None) -> None:
    """Reset the failure count (on successful flush)."""
    path = _failures_path(session_id, session_dir)
    try:
        path.unlink(missing_ok=True)
    except OSError:
        pass


def remove_session(
    session_id: str,
    session_dir: Optional[str] = None,
) -> None:
    """Delete the session file and all sidecar files."""
    path = _session_path(session_id, session_dir)
    try:
        path.unlink(missing_ok=True)
    except OSError as e:
        logger.warning("Could not remove session file %s: %s", path, e)
    remove_flush_offset(session_id, session_dir)
    reset_failure_count(session_id, session_dir)


def _failed_dir(session_dir: Optional[str] = None) -> Path:
    """Return the failed/ subdirectory inside the session directory."""
    d = get_session_dir(session_dir) / "failed"
    d.mkdir(parents=True, exist_ok=True)
    return d


def move_to_failed(
    session_id: str,
    session_dir: Optional[str] = None,
) -> Optional[Path]:
    """Move a session file (and its sidecar) to the failed/ directory for later retry."""
    src = _session_path(session_id, session_dir)
    if not src.exists():
        return None

    dest = _failed_dir(session_dir) / src.name
    try:
        src.rename(dest)
        logger.info("Moved failed session to: %s", dest)
    except OSError as e:
        logger.warning("Could not move session to failed/: %s", e)
        return None

    # Also move the sidecar if it exists
    sidecar = _flushed_path(session_id, session_dir)
    if sidecar.exists():
        try:
            sidecar.rename(_failed_dir(session_dir) / sidecar.name)
        except OSError:
            pass

    return dest


def list_failed(session_dir: Optional[str] = None) -> List[Path]:
    """Return list of JSONL files in the failed/ directory."""
    d = get_session_dir(session_dir) / "failed"
    if not d.exists():
        return []
    return sorted(d.glob("*.jsonl"))


def count_failed(session_dir: Optional[str] = None) -> int:
    """Count the number of failed session files."""
    return len(list_failed(session_dir))


def read_failed_events(path: Path) -> List[Dict[str, Any]]:
    """Read all events from a failed session file."""
    if not path.exists():
        return []

    events: List[Dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return events


def remove_failed(path: Path) -> None:
    """Delete a specific failed session file."""
    try:
        path.unlink(missing_ok=True)
    except OSError as e:
        logger.warning("Could not remove failed file %s: %s", path, e)


def cleanup_stale(
    max_age_seconds: int = 3600,
    session_dir: Optional[str] = None,
) -> List[str]:
    """Remove session files older than max_age_seconds. Returns removed filenames."""
    d = get_session_dir(session_dir)
    now = time.time()
    removed: List[str] = []

    for path in d.glob("*.jsonl"):
        try:
            age = now - path.stat().st_mtime
            if age > max_age_seconds:
                path.unlink()
                # Also remove the sidecar
                sidecar = path.with_suffix(".flushed")
                if sidecar.exists():
                    sidecar.unlink(missing_ok=True)
                removed.append(path.stem)
                logger.info("Removed stale session file: %s (age: %ds)", path.name, int(age))
        except OSError as e:
            logger.warning("Error cleaning up %s: %s", path, e)

    # Clean up orphaned sidecar files (no matching .jsonl)
    for suffix in ("*.flushed", "*.failures"):
        for sidecar in d.glob(suffix):
            jsonl = sidecar.with_suffix(".jsonl")
            if not jsonl.exists():
                try:
                    sidecar.unlink()
                except OSError:
                    pass

    return removed
