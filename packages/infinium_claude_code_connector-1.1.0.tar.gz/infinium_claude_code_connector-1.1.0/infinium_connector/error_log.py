"""
Persistent error log for connector failures.

Stored as JSONL at ~/.infinium/errors.jsonl. Auto-rotates at 500 entries.
Gives users visibility into silent failures that stderr logging cannot provide.
"""
from __future__ import annotations

import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

_MAX_ENTRIES = 500


def _error_log_path() -> Path:
    """Return ~/.infinium/errors.jsonl."""
    return Path.home() / ".infinium" / "errors.jsonl"


def append_error(
    error_type: str,
    session_id: str,
    message: str,
    context: Optional[Dict[str, Any]] = None,
) -> None:
    """Append an error entry. Never raises — safe to call from hook."""
    try:
        path = _error_log_path()
        path.parent.mkdir(parents=True, exist_ok=True)

        entry: Dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "error_type": error_type,
            "session_id": session_id[:12] if session_id else "unknown",
            "message": message[:200] if message else "",
        }
        if context:
            entry["context"] = context

        line = json.dumps(entry, default=str, separators=(",", ":")) + "\n"
        with open(path, "a", encoding="utf-8") as f:
            f.write(line)

        _rotate_if_needed(path)
    except Exception:
        pass  # Never crash the hook


def read_errors(limit: int = 20) -> List[Dict[str, Any]]:
    """Read the last N error entries."""
    path = _error_log_path()
    if not path.exists():
        return []

    entries: List[Dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                continue

    return entries[-limit:] if limit else entries


def last_error() -> Optional[Dict[str, Any]]:
    """Return the most recent error entry, or None."""
    entries = read_errors(limit=1)
    return entries[0] if entries else None


def clear_errors() -> bool:
    """Delete the error log. Returns True if file existed."""
    path = _error_log_path()
    if path.exists():
        path.unlink()
        return True
    return False


def _rotate_if_needed(path: Optional[Path] = None) -> None:
    """Keep only the last _MAX_ENTRIES entries if the file grows too large."""
    path = path or _error_log_path()
    if not path.exists():
        return

    lines: List[str] = []
    with open(path, "r", encoding="utf-8") as f:
        lines = [l for l in f if l.strip()]

    if len(lines) <= _MAX_ENTRIES:
        return

    keep = lines[-_MAX_ENTRIES:]
    try:
        fd, tmp_path = tempfile.mkstemp(
            dir=str(path.parent), suffix=".tmp", prefix="errors-"
        )
        with os.fdopen(fd, "w", encoding="utf-8") as tmp:
            tmp.writelines(keep)
        os.replace(tmp_path, str(path))
    except OSError:
        with open(path, "w", encoding="utf-8") as f:
            f.writelines(keep)
