"""
Bridge between connector's InfiniumTracePayload and the infinium-o2 SDK.

Converts aggregated trace payloads into SDK TaskData objects
and sends them via InfiniumClient.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from infinium import (
    InfiniumClient,
    TaskData,
    ExecutionStep,
    ErrorDetail,
    ToolCall,
    EnvironmentContext,
    Development,
    General,
    LlmUsage,
    get_current_iso_datetime,
)

from . import __version__
from .config import ConnectorConfig
from .types import InfiniumTracePayload

logger = logging.getLogger(__name__)


def payload_to_task_data(payload: InfiniumTracePayload) -> TaskData:
    """Convert an InfiniumTracePayload into an SDK TaskData."""
    # Build ExecutionStep list from raw step dicts
    steps: Optional[List[ExecutionStep]] = None
    if payload.steps:
        steps = []
        for s in payload.steps:
            tool_call = None
            tc_dict = s.get("tool_call")
            if tc_dict:
                tc_error = None
                if tc_dict.get("error"):
                    tc_error = ErrorDetail(
                        error_type=tc_dict["error"].get("error_type", "Error"),
                        message=tc_dict["error"].get("message", ""),
                        recoverable=tc_dict["error"].get("recoverable", True),
                    )
                tool_call = ToolCall(
                    tool_name=tc_dict.get("tool_name", "unknown"),
                    duration_ms=tc_dict.get("duration_ms"),
                    input_summary=tc_dict.get("input_summary"),
                    output_summary=tc_dict.get("output_summary"),
                    error=tc_error,
                )

            step_error = None
            if s.get("error"):
                step_error = ErrorDetail(
                    error_type=s["error"].get("error_type", "Error"),
                    message=s["error"].get("message", ""),
                    recoverable=s["error"].get("recoverable", True),
                )

            steps.append(
                ExecutionStep(
                    step_number=s.get("step_number", 0),
                    action=s.get("action", "unknown"),
                    description=s.get("description", ""),
                    duration_ms=s.get("duration_ms"),
                    input_preview=s.get("input_preview"),
                    output_preview=s.get("output_preview"),
                    error=step_error,
                    tool_call=tool_call,
                    metadata=s.get("metadata"),
                )
            )

    # Build ErrorDetail list
    errors: Optional[List[ErrorDetail]] = None
    if payload.errors:
        errors = [
            ErrorDetail(
                error_type=e.get("error_type", "Error"),
                message=e.get("message", ""),
                recoverable=e.get("recoverable", True),
            )
            for e in payload.errors
        ]

    # Build EnvironmentContext
    environment: Optional[EnvironmentContext] = None
    if payload.environment:
        env = payload.environment
        environment = EnvironmentContext(
            framework=env.get("framework"),
            framework_version=env.get("framework_version"),
            sdk_version=env.get("sdk_version"),
            runtime=env.get("runtime"),
            region=env.get("region"),
            custom_tags=env.get("custom_tags"),
        )

    # Build domain sections
    development: Optional[Development] = None
    general: Optional[General] = None
    if payload.sections:
        dev_dict = payload.sections.get("development")
        if dev_dict:
            development = Development(
                framework_used=dev_dict.get("framework_used"),
                files_modified=dev_dict.get("files_modified"),
            )
        gen_dict = payload.sections.get("general")
        if gen_dict:
            general = General(
                tools_used=gen_dict.get("tools_used"),
                tags=gen_dict.get("tags"),
            )

    # Build LlmUsage
    llm_usage: Optional[LlmUsage] = None
    if payload.llm_usage:
        u = payload.llm_usage
        llm_usage = LlmUsage(
            model=u.get("model"),
            provider=u.get("provider"),
            prompt_tokens=u.get("prompt_tokens"),
            completion_tokens=u.get("completion_tokens"),
            total_tokens=u.get("total_tokens"),
            api_calls_count=u.get("api_calls_count"),
        )

    return TaskData(
        name=payload.name,
        description=payload.description,
        current_datetime=payload.current_datetime,
        duration=payload.duration,
        input_summary=payload.input_summary,
        output_summary=payload.output_summary,
        steps=steps,
        errors=errors,
        environment=environment,
        llm_usage=llm_usage,
        development=development,
        general=general,
    )


def send_trace(config: ConnectorConfig, payload: InfiniumTracePayload) -> Dict[str, Any]:
    """
    Convert payload to TaskData and send via InfiniumClient.

    Returns the API response data dict.
    """
    task_data = payload_to_task_data(payload)

    with InfiniumClient(
        agent_id=config.agent_id,
        agent_secret=config.agent_secret,
        base_url=config.base_url,
        timeout=config.timeout,
        max_retries=config.max_retries,
        verify_ssl=config.verify_ssl,
        user_agent=f"infinium-claude-code-connector/{__version__}",
    ) as client:
        response = client.send_task_data(task_data)

    logger.info("Trace sent successfully: %s", response.message)
    return response.data or {}
