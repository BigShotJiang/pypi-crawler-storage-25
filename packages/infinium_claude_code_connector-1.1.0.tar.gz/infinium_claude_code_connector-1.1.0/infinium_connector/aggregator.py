"""
Session aggregator — collects Claude Code hook events and builds Infinium trace payloads.
"""
from __future__ import annotations

import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from . import __version__
from .config import ConnectorConfig
from .types import (
    HookEvent,
    InfiniumTracePayload,
    PromptTurn,
    SessionData,
    SubagentRecord,
    ToolUseRecord,
)

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _truncate(text: Optional[str], limit: int) -> Optional[str]:
    if text is None:
        return None
    if len(text) <= limit:
        return text
    return text[: limit - 3] + "..."


def _parse_hook_event(payload: Dict[str, Any]) -> HookEvent:
    """Parse a raw Claude Code hook JSON payload into a HookEvent."""
    return HookEvent(
        event_name=payload.get("hook_event_name", "Unknown"),
        session_id=payload.get("session_id", "unknown"),
        timestamp=payload.get("timestamp", _now_iso()),
        cwd=payload.get("cwd"),
        permission_mode=payload.get("permission_mode"),
        agent_id=payload.get("agent_id"),
        agent_type=payload.get("agent_type"),
        tool_name=payload.get("tool_name"),
        tool_input=payload.get("tool_input"),
        tool_response=payload.get("tool_response"),
        tool_use_id=payload.get("tool_use_id"),
        prompt=payload.get("prompt"),
        last_assistant_message=payload.get("last_assistant_message"),
        error=payload.get("error"),
        is_interrupt=payload.get("is_interrupt"),
        source=payload.get("source"),
        model=payload.get("model"),
        message=payload.get("message"),
        notification_type=payload.get("notification_type"),
        agent_transcript_path=payload.get("agent_transcript_path"),
        raw=payload,
    )


class SessionAggregator:
    """
    Collects hook events per session and produces Infinium trace payloads.

    Thread-safety: designed for single-threaded async usage (one uvicorn worker).
    """

    def __init__(self, config: ConnectorConfig) -> None:
        self.config = config
        self._sessions: Dict[str, SessionData] = {}
        self._session_timestamps: Dict[str, float] = {}  # monotonic clock

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def ingest(self, raw_payload: Dict[str, Any]) -> Tuple[HookEvent, Optional[InfiniumTracePayload]]:
        """
        Ingest a single hook event.

        Returns the parsed event and, if the event triggers a flush,
        the trace payload ready to send to Infinium.
        """
        event = _parse_hook_event(raw_payload)
        session = self._get_or_create_session(event)
        self._apply_event(session, event)

        payload: Optional[InfiniumTracePayload] = None

        if event.event_name == "SessionEnd" and self.config.flush_on_session_end:
            payload = self._build_payload(session)
            self._remove_session(event.session_id)
        elif event.event_name == "Stop" and self.config.flush_on_stop:
            payload = self._build_payload(session)
            # Keep session alive — more turns may follow

        return event, payload

    def flush_session(self, session_id: str) -> Optional[InfiniumTracePayload]:
        """Force-flush a session and return the payload."""
        session = self._sessions.get(session_id)
        if session is None:
            return None
        payload = self._build_payload(session)
        self._remove_session(session_id)
        return payload

    def flush_all(self) -> List[InfiniumTracePayload]:
        """Flush all active sessions. Returns list of payloads."""
        payloads = []
        for sid in list(self._sessions.keys()):
            p = self.flush_session(sid)
            if p is not None:
                payloads.append(p)
        return payloads

    def evict_stale(self) -> List[str]:
        """Remove sessions older than session_ttl_seconds. Returns evicted IDs."""
        now = time.monotonic()
        cutoff = now - self.config.session_ttl_seconds
        stale = [
            sid for sid, ts in self._session_timestamps.items() if ts < cutoff
        ]
        for sid in stale:
            self._remove_session(sid)
        return stale

    def replay_events(
        self, events: List[Dict[str, Any]]
    ) -> Optional[InfiniumTracePayload]:
        """
        Feed a list of raw event dicts through ingest() and return the payload.

        Used by the command hook path to reconstruct session state from JSONL.
        """
        payload: Optional[InfiniumTracePayload] = None
        for ev in events:
            _, p = self.ingest(ev)
            if p is not None:
                payload = p

        # If no flush was triggered naturally, force-flush all sessions
        if payload is None:
            payloads = self.flush_all()
            payload = payloads[0] if payloads else None

        return payload

    @property
    def active_session_count(self) -> int:
        return len(self._sessions)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _get_or_create_session(self, event: HookEvent) -> SessionData:
        sid = event.session_id
        if sid not in self._sessions:
            self._sessions[sid] = SessionData(
                session_id=sid,
                started_at=event.timestamp,
                cwd=event.cwd,
                permission_mode=event.permission_mode,
            )
            self._session_timestamps[sid] = time.monotonic()
            logger.info("New session tracked: %s", sid[:12])
        else:
            # Refresh timestamp on activity
            self._session_timestamps[sid] = time.monotonic()
        return self._sessions[sid]

    def _remove_session(self, session_id: str) -> None:
        self._sessions.pop(session_id, None)
        self._session_timestamps.pop(session_id, None)

    def _ensure_current_turn(self, session: SessionData) -> PromptTurn:
        if session._current_turn is None:
            turn = PromptTurn(started_at=_now_iso())
            session._current_turn = turn
            session.turns.append(turn)
        return session._current_turn

    def _apply_event(self, session: SessionData, event: HookEvent) -> None:
        handler = getattr(self, f"_handle_{event.event_name}", None)
        if handler is not None:
            handler(session, event)
        else:
            logger.debug("Unhandled event type: %s", event.event_name)

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------

    def _handle_SessionStart(self, session: SessionData, event: HookEvent) -> None:
        session.started_at = event.timestamp
        session.source = event.source
        session.model = event.model

    def _handle_SessionEnd(self, session: SessionData, event: HookEvent) -> None:
        session.ended_at = event.timestamp

    def _handle_UserPromptSubmit(self, session: SessionData, event: HookEvent) -> None:
        # Start a new turn
        turn = PromptTurn(
            prompt=_truncate(event.prompt, self.config.max_input_preview),
            started_at=event.timestamp,
        )
        session._current_turn = turn
        session.turns.append(turn)

    def _handle_PreToolUse(self, session: SessionData, event: HookEvent) -> None:
        turn = self._ensure_current_turn(session)
        tool_name = event.tool_name or "unknown"
        tool_use_id = event.tool_use_id or f"auto-{len(turn.tool_uses)}"

        input_str = None
        if event.tool_input:
            import json

            try:
                input_str = json.dumps(event.tool_input, default=str)
            except (TypeError, ValueError):
                input_str = str(event.tool_input)

        record = ToolUseRecord(
            tool_name=tool_name,
            tool_use_id=tool_use_id,
            input_summary=_truncate(input_str, self.config.max_input_preview),
            started_at=event.timestamp,
        )
        session._pending_tools[tool_use_id] = record

    def _handle_PostToolUse(self, session: SessionData, event: HookEvent) -> None:
        turn = self._ensure_current_turn(session)
        tool_use_id = event.tool_use_id or ""

        record = session._pending_tools.pop(tool_use_id, None)
        if record is None:
            # PostToolUse without matching PreToolUse — create inline
            record = ToolUseRecord(
                tool_name=event.tool_name or "unknown",
                tool_use_id=tool_use_id,
            )

        record.output_summary = _truncate(
            event.tool_response, self.config.max_output_preview
        )
        record.completed_at = event.timestamp
        record.duration_ms = self._compute_duration_ms(
            record.started_at, record.completed_at
        )
        turn.tool_uses.append(record)
        session.total_tool_calls += 1

    def _handle_PostToolUseFailure(self, session: SessionData, event: HookEvent) -> None:
        turn = self._ensure_current_turn(session)
        tool_use_id = event.tool_use_id or ""

        record = session._pending_tools.pop(tool_use_id, None)
        if record is None:
            record = ToolUseRecord(
                tool_name=event.tool_name or "unknown",
                tool_use_id=tool_use_id,
            )

        record.error = _truncate(event.error, self.config.max_output_preview)
        record.completed_at = event.timestamp
        record.duration_ms = self._compute_duration_ms(
            record.started_at, record.completed_at
        )
        turn.tool_uses.append(record)
        session.total_tool_calls += 1
        session.total_errors += 1

    def _handle_Stop(self, session: SessionData, event: HookEvent) -> None:
        turn = self._ensure_current_turn(session)
        turn.response = _truncate(
            event.last_assistant_message, self.config.max_output_preview
        )
        turn.completed_at = event.timestamp
        # Close the current turn
        session._current_turn = None

    def _handle_SubagentStart(self, session: SessionData, event: HookEvent) -> None:
        turn = self._ensure_current_turn(session)
        record = SubagentRecord(
            subagent_id=event.agent_id or "unknown",
            agent_type=event.agent_type,
            started_at=event.timestamp,
        )
        turn.subagents.append(record)
        session.total_subagents += 1

    def _handle_SubagentStop(self, session: SessionData, event: HookEvent) -> None:
        turn = self._ensure_current_turn(session)
        # Try to match existing subagent record
        matched = False
        for sub in turn.subagents:
            if sub.subagent_id == event.agent_id and sub.completed_at is None:
                sub.completed_at = event.timestamp
                sub.transcript_path = event.agent_transcript_path
                matched = True
                break
        if not matched:
            turn.subagents.append(
                SubagentRecord(
                    subagent_id=event.agent_id or "unknown",
                    agent_type=event.agent_type,
                    completed_at=event.timestamp,
                    transcript_path=event.agent_transcript_path,
                )
            )

    def _handle_Notification(self, session: SessionData, event: HookEvent) -> None:
        # Notifications are informational — no action needed for tracing
        pass

    def _handle_PreCompact(self, session: SessionData, event: HookEvent) -> None:
        pass

    def _handle_PostCompact(self, session: SessionData, event: HookEvent) -> None:
        pass

    # ------------------------------------------------------------------
    # Payload building
    # ------------------------------------------------------------------

    def _build_payload(self, session: SessionData) -> InfiniumTracePayload:
        """Convert a SessionData into an Infinium-compatible trace payload."""
        now = _now_iso()
        duration = self._compute_session_duration(session)

        # Build execution steps from turns
        steps: List[Dict[str, Any]] = []
        step_num = 0
        all_errors: List[Dict[str, Any]] = []

        for turn_idx, turn in enumerate(session.turns):
            # Step for the prompt itself
            if turn.prompt:
                step_num += 1
                steps.append(
                    {
                        "step_number": step_num,
                        "action": "user_prompt",
                        "description": f"Turn {turn_idx + 1}: User prompt",
                        "input_preview": turn.prompt,
                        "output_preview": turn.response,
                    }
                )

            # Steps for each tool use
            for tool in turn.tool_uses:
                step_num += 1
                step: Dict[str, Any] = {
                    "step_number": step_num,
                    "action": "tool_use",
                    "description": f"Tool: {tool.tool_name}",
                    "duration_ms": tool.duration_ms,
                    "input_preview": tool.input_summary,
                    "output_preview": tool.output_summary,
                    "tool_call": {
                        "tool_name": tool.tool_name,
                        "duration_ms": tool.duration_ms,
                        "input_summary": tool.input_summary,
                        "output_summary": tool.output_summary,
                    },
                }
                if tool.error:
                    step["error"] = {
                        "error_type": "ToolError",
                        "message": tool.error,
                        "recoverable": True,
                    }
                    all_errors.append(step["error"])
                    step["tool_call"]["error"] = step["error"]
                steps.append(step)

            # Steps for subagents
            for sub in turn.subagents:
                step_num += 1
                steps.append(
                    {
                        "step_number": step_num,
                        "action": "subagent",
                        "description": f"Subagent: {sub.agent_type or sub.subagent_id}",
                        "metadata": {
                            "subagent_id": sub.subagent_id,
                            "agent_type": sub.agent_type,
                            "transcript_path": sub.transcript_path,
                        },
                    }
                )

        # Build name and description
        num_turns = len(session.turns)
        first_prompt = None
        for t in session.turns:
            if t.prompt:
                first_prompt = t.prompt
                break

        if first_prompt:
            clean_prompt = " ".join(first_prompt.split())
            name = _truncate(clean_prompt, 30)
            description = first_prompt
        else:
            name = f"Claude Code session ({num_turns} turn{'s' if num_turns != 1 else ''})"
            description = f"Claude Code session with {session.total_tool_calls} tool calls"

        # Last response as output_summary
        output_summary = None
        for t in reversed(session.turns):
            if t.response:
                output_summary = t.response
                break

        # Environment context
        environment: Dict[str, Any] = {
            "framework": "claude-code",
            "runtime": "claude-code-connector",
            "sdk_version": __version__,
        }
        custom_tags: Dict[str, str] = {}
        if session.model:
            custom_tags["model"] = session.model
        if session.source:
            custom_tags["session_source"] = session.source
        if session.cwd:
            custom_tags["working_directory"] = session.cwd
        if session.permission_mode:
            custom_tags["permission_mode"] = session.permission_mode
        custom_tags["session_id"] = session.session_id
        if custom_tags:
            environment["custom_tags"] = custom_tags

        # Development section (always relevant for Claude Code)
        development: Dict[str, Any] = {
            "framework_used": "claude-code",
        }
        if session.cwd:
            development["files_modified"] = [session.cwd]

        # Collect unique tools used
        tools_used = list(
            {
                tool.tool_name
                for turn in session.turns
                for tool in turn.tool_uses
            }
        )

        sections: Dict[str, Any] = {
            "development": development,
            "general": {
                "tools_used": tools_used,
                "tags": ["claude-code", "ai-coding-agent"],
            },
        }

        return InfiniumTracePayload(
            name=name,
            description=description,
            current_datetime=session.started_at or now,
            duration=duration,
            input_summary=first_prompt,
            output_summary=output_summary,
            steps=steps if steps else None,
            errors=all_errors if all_errors else None,
            environment=environment,
            sections=sections,
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _compute_duration_ms(
        start_iso: Optional[str], end_iso: Optional[str]
    ) -> Optional[int]:
        """Compute duration between two ISO timestamps in milliseconds."""
        if not start_iso or not end_iso:
            return None
        try:
            fmt = "%Y-%m-%dT%H:%M:%SZ"
            start = datetime.strptime(start_iso, fmt)
            end = datetime.strptime(end_iso, fmt)
            return max(0, int((end - start).total_seconds() * 1000))
        except (ValueError, TypeError):
            return None

    @staticmethod
    def _compute_session_duration(session: SessionData) -> float:
        """Compute total session duration in seconds."""
        start = session.started_at
        end = session.ended_at
        if not start:
            return 0.0

        # Use last turn's completed_at if no explicit end
        if not end:
            for turn in reversed(session.turns):
                if turn.completed_at:
                    end = turn.completed_at
                    break

        if not end:
            end = _now_iso()

        try:
            fmt = "%Y-%m-%dT%H:%M:%SZ"
            s = datetime.strptime(start, fmt)
            e = datetime.strptime(end, fmt)
            return max(0.0, (e - s).total_seconds())
        except (ValueError, TypeError):
            return 0.0
