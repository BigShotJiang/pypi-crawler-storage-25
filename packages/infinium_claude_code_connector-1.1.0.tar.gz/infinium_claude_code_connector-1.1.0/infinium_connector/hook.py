"""
Command hook entry point for Claude Code.

Claude Code invokes this script for each hook event, passing JSON on stdin.
Events are accumulated in session JSONL files. On flush events (Stop, SessionEnd),
the session is aggregated and sent to Infinium.

Usage (configured automatically by `infinium init`):
    echo '{"hook_event_name":"Stop","session_id":"abc"}' | python -m infinium_connector.hook
"""
from __future__ import annotations

import json
import logging
import os
import random
import sys
import time

logger = logging.getLogger(__name__)

# Events that trigger a trace flush
_FLUSH_EVENTS = frozenset({"Stop", "SessionEnd"})

# Probability of running stale-file cleanup on non-flush events (1 in 20)
_CLEANUP_PROBABILITY = 0.05

# Application-level retry settings (distinct from SDK HTTP retries)
_APP_RETRIES = 2  # 2 retries = 3 total attempts
_RETRY_DELAY_S = 1.0  # linear backoff: 1s, 2s

# Skip incremental flushes after this many consecutive failures
_MAX_CONSECUTIVE_FAILURES = 3


def main() -> None:
    """Read a hook event from stdin, store it, and flush if needed."""
    # Minimal logging setup — errors go to stderr
    logging.basicConfig(
        level=logging.WARNING,
        format="[infinium-connector] %(levelname)s: %(message)s",
        stream=sys.stderr,
    )

    # Read JSON from stdin
    try:
        raw = sys.stdin.read()
    except Exception:
        return  # Nothing to do if stdin is empty or broken

    if not raw.strip():
        return

    try:
        event = json.loads(raw)
    except json.JSONDecodeError:
        logger.warning("Invalid JSON from Claude Code hook")
        return

    if not isinstance(event, dict):
        return

    event_name = event.get("hook_event_name", "Unknown")
    session_id = event.get("session_id", "unknown")

    # Resolve cwd from the event (Claude Code passes the project directory)
    from pathlib import Path
    event_cwd = Path(event["cwd"]) if event.get("cwd") else None

    # Check if tracing is paused (respects project-level config)
    from .config import is_paused

    if is_paused(cwd=event_cwd):
        return  # Silently skip when paused

    # Lazy imports to minimize startup time for non-flush events
    from . import session_store
    from .config import ConnectorConfig

    config = ConnectorConfig.load(cwd=event_cwd)
    session_dir = config.session_dir

    # Always append the event to the session file
    try:
        session_store.append_event(session_id, event, session_dir)
    except Exception:
        logger.exception("Failed to store event")
        return

    # Flush on Stop or SessionEnd
    if event_name in _FLUSH_EVENTS:
        _flush_session(session_id, event_name, config)
    elif random.random() < _CLEANUP_PROBABILITY:
        # Opportunistic cleanup of stale session files
        try:
            session_store.cleanup_stale(config.session_ttl_seconds, session_dir)
        except Exception:
            logger.debug("Stale session cleanup failed", exc_info=True)


def _flush_session(
    session_id: str, event_name: str, config: "ConnectorConfig"
) -> None:
    """Aggregate and send a trace — incremental on Stop, full summary on SessionEnd."""
    from . import session_store
    from .aggregator import SessionAggregator
    from . import sdk_bridge
    from . import history
    from . import error_log

    try:
        config.validate()
    except ValueError as e:
        logger.error("Cannot send trace — %s", e)
        error_log.append_error(
            "config_error", session_id, str(e),
            context={"event_name": event_name},
        )
        return

    # Read all stored events for this session
    all_events = session_store.read_events(session_id, config.session_dir)
    if not all_events:
        return

    is_session_end = event_name == "SessionEnd"

    # Circuit breaker: skip incremental flushes after repeated failures
    if not is_session_end:
        failure_count = session_store.read_failure_count(
            session_id, config.session_dir
        )
        if failure_count >= _MAX_CONSECUTIVE_FAILURES:
            logger.info(
                "Skipping incremental flush — %d consecutive failures; "
                "will retry at session end",
                failure_count,
            )
            return

    if is_session_end:
        # Full summary: replay everything
        events_to_replay = all_events
        trace_type = "session"
    else:
        # Incremental: only new events since last flush
        offset = session_store.read_flush_offset(session_id, config.session_dir)
        new_events = all_events[offset:]
        if not new_events:
            return  # Nothing new to send

        # Prepend SessionStart if needed (aggregator needs it for model/cwd metadata)
        if offset > 0 and all_events[0].get("hook_event_name") == "SessionStart":
            events_to_replay = [all_events[0]] + new_events
        else:
            events_to_replay = new_events
        trace_type = "turn"

    # Replay through aggregator
    aggregator = SessionAggregator(config)
    payload = None
    for ev in events_to_replay:
        _, p = aggregator.ingest(ev)
        if p is not None:
            payload = p

    # If no payload was produced by the last event, force flush
    if payload is None:
        payloads = aggregator.flush_all()
        payload = payloads[0] if payloads else None

    if payload is None:
        return

    # Prefix summary traces so they're easy to spot
    if is_session_end:
        payload.name = f"(Summary) {payload.name}"

    # Tag the trace type so incremental vs summary are distinguishable
    if payload.environment and "custom_tags" in payload.environment:
        payload.environment["custom_tags"]["trace_type"] = trace_type

    # Extract token usage from Claude Code's transcript file
    transcript_path = None
    for ev in reversed(all_events):
        if ev.get("transcript_path"):
            transcript_path = ev["transcript_path"]
            break

    if transcript_path:
        try:
            from .transcript import read_token_usage

            token_usage = read_token_usage(transcript_path)
            if token_usage:
                payload.llm_usage = {
                    "model": token_usage.model,
                    "provider": "anthropic",
                    "prompt_tokens": token_usage.input_tokens,
                    "completion_tokens": token_usage.output_tokens,
                    "total_tokens": token_usage.input_tokens + token_usage.output_tokens,
                    "api_calls_count": token_usage.api_calls,
                    "cache_creation_input_tokens": token_usage.cache_creation_input_tokens,
                    "cache_read_input_tokens": token_usage.cache_read_input_tokens,
                }
        except Exception:
            logger.debug("Failed to read token usage from transcript", exc_info=True)

    # Extract stats for history
    turns = len(payload.steps or [])
    tool_calls = sum(
        1 for s in (payload.steps or [])
        if s.get("action", "").startswith("tool_use")
    )
    errors = len(payload.errors or [])

    # Send to Infinium (with application-level retry)
    try:
        last_exc: BaseException | None = None
        result = None
        for attempt in range(_APP_RETRIES + 1):
            try:
                result = sdk_bridge.send_trace(config, payload)
                last_exc = None
                break
            except Exception as exc:
                last_exc = exc
                if attempt < _APP_RETRIES:
                    time.sleep(_RETRY_DELAY_S * (attempt + 1))

        if last_exc is not None:
            raise last_exc

        trace_id = result.get("traceId", result.get("id", "unknown"))

        logger.info(
            "Trace sent for session %s (traceId=%s, type=%s)",
            session_id[:12], trace_id, trace_type,
        )

        # Update flush offset on successful incremental send
        if not is_session_end:
            session_store.write_flush_offset(
                session_id, len(all_events), config.session_dir
            )

        # Reset failure count on success
        session_store.reset_failure_count(session_id, config.session_dir)

        # Append to local history
        try:
            history.append_entry({
                "timestamp": payload.current_datetime,
                "session_id": session_id[:12],
                "trace_id": str(trace_id),
                "name": payload.name,
                "turns": turns,
                "tool_calls": tool_calls,
                "errors": errors,
                "duration_s": round(payload.duration, 1),
                "status": "sent",
                "trace_type": trace_type,
            })
        except Exception:
            logger.debug("Failed to append history entry", exc_info=True)

    except Exception as exc:
        error_msg = str(exc)[:200]

        logger.warning("Trace failed for session %s: %s", session_id[:12], error_msg)

        # Write to persistent error log (visible via `infinium errors`)
        error_log.append_error(
            error_type="flush_failed",
            session_id=session_id,
            message=error_msg,
            context={"event_name": event_name, "trace_type": trace_type},
        )

        if is_session_end:
            # Move to failed/ for later retry
            try:
                session_store.move_to_failed(session_id, config.session_dir)
            except Exception:
                logger.debug("Failed to move session to failed/", exc_info=True)

            # Record failure in history
            try:
                history.append_entry({
                    "timestamp": payload.current_datetime,
                    "session_id": session_id[:12],
                    "trace_id": None,
                    "name": payload.name,
                    "turns": turns,
                    "tool_calls": tool_calls,
                    "errors": errors,
                    "duration_s": round(payload.duration, 1),
                    "status": "failed",
                    "error": error_msg,
                    "trace_type": trace_type,
                })
            except Exception:
                logger.debug("Failed to append failure history entry", exc_info=True)
        else:
            # Track consecutive failures for circuit breaker
            session_store.increment_failure_count(session_id, config.session_dir)

        return

    # Clean up session file on SessionEnd (session is done)
    # On Stop, keep the file — more turns may follow
    if is_session_end:
        session_store.remove_session(session_id, config.session_dir)


if __name__ == "__main__":
    main()
