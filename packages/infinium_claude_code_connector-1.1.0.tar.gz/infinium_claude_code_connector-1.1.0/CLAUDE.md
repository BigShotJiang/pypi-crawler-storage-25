# CLAUDE.md

Infinium Claude Code Connector — bridges Claude Code hooks to the Infinium agent tracing API.

## Commands

```bash
pip install -e .              # Install (dev)
infinium init                 # Interactive setup wizard
infinium test                 # Verify connection works
infinium status               # Show current config + tracing state
infinium pause                # Temporarily stop tracing
infinium resume               # Resume tracing
infinium history              # View recent traces
infinium errors               # View connector errors
infinium retry                # Resend failed traces
infinium update-credentials   # Change Agent ID or Secret
infinium uninstall            # Remove connector completely
infinium cleanup              # Remove stale session files
infinium start                # HTTP server mode (optional)
```

If `infinium` is not on PATH, use `python -m infinium_connector <command>`.

## Architecture

```
infinium_connector/
  __init__.py          # Package exports, __version__ (single source of truth)
  __main__.py          # python -m infinium_connector entry point → CLI
  cli.py               # Click CLI (init, test, status, pause, resume, history, retry, etc.)
  config.py            # Credentials: project (.infinium/) → env vars (no global config)
                       # Agent secret stored in OS keyring via `keyring` library
  hook.py              # Command hook entry point (stdin → JSONL → flush → retry)
  session_store.py     # JSONL session file I/O + failed/ directory + Windows file locking
  error_log.py         # Persistent error log (~/.infinium/errors.jsonl) with rotation
  transcript.py        # Read token usage from Claude Code's session transcript
  history.py           # Local trace history (~/.infinium/history.jsonl) with atomic rotation
  sdk_bridge.py        # InfiniumTracePayload → SDK TaskData → send via InfiniumClient
  aggregator.py        # Session event aggregation → trace payloads
  server.py            # Starlette ASGI app (optional HTTP mode, requires [server] extra)
  types.py             # Data models (HookEvent, SessionData, PromptTurn, etc.)
  py.typed             # PEP 561 typed package marker
```

## Credential Resolution Order

1. **Project config** — `.infinium/config.json` in cwd
2. **Environment variables** — `INFINIUM_AGENT_ID`, `INFINIUM_AGENT_SECRET` (override for CI/Docker)

Agent ID + base URL go in the project config file. Agent secret goes in OS keyring (keyed by agent ID).
There is no global config — tracing is always configured per-project.

## Data Flow (Command Mode)

```
Claude Code → command hook → python -m infinium_connector.hook
                                 │ reads JSON from stdin
                                 │ checks: paused? → skip
                                 │ resolves: project config → env vars
                                 ├─ append to {tmpdir}/infinium-sessions/{session_id}.jsonl
                                 └─ on Stop/SessionEnd:
                                      read .jsonl → SessionAggregator → sdk_bridge.send_trace()
                                      → POST /agents/{agent_id}/trace (with app-level retry)
                                      → append to ~/.infinium/history.jsonl
                                      (on failure: log to ~/.infinium/errors.jsonl,
                                       move to failed/ for later retry,
                                       circuit-break after 3 consecutive failures)
```

## Version Management

Version is defined once in `__init__.py` (`__version__`). All other files import it:
- `cli.py` — `@click.version_option`
- `aggregator.py` — `sdk_version` in trace environment
- `sdk_bridge.py` — `user_agent` header
- `server.py` — health endpoint response
- `pyproject.toml` — `dynamic = ["version"]` with `[tool.hatch.version]` pointing to `__init__.py`
