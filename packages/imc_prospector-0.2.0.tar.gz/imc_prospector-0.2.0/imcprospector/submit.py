"""Submitter for IMC Prosperity algorithms."""

import json
import sys
import time
from pathlib import Path
from typing import Any, Optional

import keyring
import requests
from requests_toolbelt import MultipartEncoder

try:
    import readline  # noqa: F401
except ImportError:
    pass

KEYRING_SERVICE = "imcprospector"
KEYRING_USERNAME = "prosperity-id-token"

API_BASE_URL = "https://3dzqiahkw1.execute-api.eu-west-1.amazonaws.com/prod"


def validate_token(token: str) -> bool:
    """Validate that token contains only valid characters."""
    bad_chars = [ch for ch in token if ord(ch) not in range(256)]
    if len(bad_chars) > 0:
        print(f"Token contains invalid character(s): {', '.join(bad_chars)}")
        return False
    return True


def refresh_token() -> None:
    """Prompt user for Prosperity ID token and store it."""
    print(
        """
imc-prospector needs your Prosperity ID token to make authenticated requests to Prosperity's internal API.
Your token is stored in the local storage item with the `CognitoIdentityServiceProvider.<some id>.<email>.idToken` key on the Prosperity website.
You can inspect the local storage items of a website by having the website open in the active tab, pressing F12 to open the browser's developer tools, and going to the Application (Chrome) or Storage (Firefox) tab.
From there, click on Local Storage in the sidebar and select the website that appears underneath the sidebar entry.
Your token is stored in your system's credentials store for convenience.
    """.strip()
    )

    token = input("Prosperity ID token: ")

    if not validate_token(token):
        return refresh_token()

    keyring.set_password(KEYRING_SERVICE, KEYRING_USERNAME, token)


def get_stored_token(retries: int = 3) -> Optional[str]:
    """Get stored token from keyring, with retries."""
    try:
        token = keyring.get_password(KEYRING_SERVICE, KEYRING_USERNAME)

        if token is not None and not validate_token(token):
            return None

        return token
    except Exception:
        if retries <= 0:
            raise

        time.sleep(1)
        return get_stored_token(retries - 1)


def request_with_token(
    method: str, url: str, form_data: Optional[dict[str, Any]] = None, attempt: int = 0
) -> requests.Response:
    """Make an authenticated request to the Prosperity API."""
    token = get_stored_token()

    if token is None:
        refresh_token()
        return request_with_token(method, url, form_data)

    data = None
    headers = {"Authorization": f"Bearer {token}"}

    if form_data is not None:
        encoder = MultipartEncoder(form_data)
        data = encoder
        headers["content-type"] = encoder.content_type

    response = requests.request(method, url, data=data, headers=headers)

    if response.status_code in [401, 403]:
        refresh_token()
        return request_with_token(method, url, form_data)

    if response.status_code == 503:
        print("The Prosperity website is currently in maintenance mode, please try again later")
        sys.exit(1)

    if 500 <= response.status_code < 600:
        print(
            f"Received unexpected HTTP {response.status_code} response from the Prosperity API, retrying request after 5 seconds (attempt {attempt + 1})"
        )
        time.sleep(5)
        return request_with_token(method, url, form_data, attempt + 1)

    response.raise_for_status()
    return response


def format_path(path: Path) -> str:
    """Format path for display (relative to cwd if possible)."""
    cwd = Path.cwd()
    if path.is_relative_to(cwd):
        return str(path.relative_to(cwd))
    else:
        return str(path)


def get_current_round() -> int:
    """Get the current open round ID."""
    print("Retrieving current round")
    response = request_with_token("GET", f"{API_BASE_URL}/rounds").json()
    rounds = response["data"]["rounds"]

    open_round = next((r for r in rounds if r["state"] == "OPEN"), None)
    if open_round is None:
        raise ValueError("No round is currently accepting submissions")

    print(f"Current round: {open_round['name']} (id={open_round['id']})")
    return open_round["id"]


def submit_algorithm(algorithm_file: Path) -> None:
    """Submit an algorithm file to Prosperity."""
    print(f"Submitting {format_path(algorithm_file)}")
    request_with_token(
        "POST",
        f"{API_BASE_URL}/submission/algo",
        {"file": (algorithm_file.name, algorithm_file.read_bytes(), "text/x-python")},
    )


def list_algorithms(round_id: int) -> list[dict[str, Any]]:
    """List all algorithms for a given round."""
    response = request_with_token("GET", f"{API_BASE_URL}/submissions/algo/{round_id}").json()
    return response["data"]["items"]


def get_submission_status(data: dict[str, Any]) -> str:
    """Get formatted submission status."""
    status = data["status"]

    if data.get("active", False):
        status += " (active)"

    return status


def monitor_status(round_id: int, algorithm_file: Path) -> dict[str, Any]:
    """Monitor submission status until completion."""
    print("Monitoring submission status")

    algorithms = list_algorithms(round_id)
    # Prosperity 4 prefixes filenames with a number (e.g. "3-78498.py")
    data = next((a for a in algorithms if a["filename"].endswith(algorithm_file.name)), None)

    if data is None:
        raise ValueError(f"Could not find submission for {algorithm_file.name} in round {round_id}")

    status = get_submission_status(data)
    print(f"Submission status: {status}")

    while data["status"] not in ("FINISHED", "ERROR", "ERROR_FINISHED"):
        time.sleep(0 if data.get("active", False) else 5)

        algorithms = list_algorithms(round_id)
        data = next(a for a in algorithms if a["id"] == data["id"])

        new_status = get_submission_status(data)
        if new_status != status:
            print(f"Submission status changed: {new_status}")
            status = new_status

    return data


def download_graph(data: dict[str, Any], output_file: Path) -> None:
    """Download submission graph data to a file."""
    print(f"Downloading submission data to {format_path(output_file)}")

    url_response = request_with_token("GET", f"{API_BASE_URL}/submissions/algo/{data['id']}/graph")
    graph_url = url_response.json()["data"]["url"]

    download_response = requests.get(graph_url)
    download_response.raise_for_status()

    output_file.parent.mkdir(parents=True, exist_ok=True)
    with output_file.open("wb+") as file:
        file.write(download_response.content)


def log_profit_loss(output_file: Path) -> None:
    """Extract and display final profit/loss from graph data."""
    try:
        graph_data = json.loads(output_file.read_text(encoding="utf-8"))
        if isinstance(graph_data, dict) and "profitLoss" in graph_data:
            pl_data = graph_data["profitLoss"]
            if isinstance(pl_data, dict):
                total = sum(pl_data.values()) if pl_data else 0
                print(f"Final profit / loss: {total:,.0f}")
                return
            elif isinstance(pl_data, (int, float)):
                print(f"Final profit / loss: {pl_data:,.0f}")
                return
        print(f"Graph data saved to {format_path(output_file)}")
    except Exception:
        print(f"Graph data saved to {format_path(output_file)} (could not parse profit/loss)")


def submit(
    algorithm_file: Path,
    output_file: Optional[Path],
    run_checker: bool = True,
    checker_strict: bool = False,
    checker_config: Optional[str] = None,
    force: bool = False,
) -> None:
    """Submit an algorithm, optionally running checker first."""
    from imcprospector.checker import ProsperityChecker, load_config

    if run_checker:
        print("Running algorithm checker...")
        config = load_config(checker_config) if checker_config else None
        checker = ProsperityChecker(config=config, strict=checker_strict)
        result = checker.check_file(str(algorithm_file))

        error_count = sum(1 for i in result.issues if i.severity.value == "error")
        warning_count = sum(1 for i in result.issues if i.severity.value == "warning")

        if not result.valid:
            print(f"\n❌ Checker found {error_count} error(s) and {warning_count} warning(s):")
            for issue in result.issues:
                if issue.severity.value in ("error", "warning"):
                    print(f"  {issue}")

            if error_count > 0:
                if force:
                    print("\n⚠️  Errors found but --force flag used. Continuing with submission...")
                else:
                    print("\n❌ Submission aborted due to errors. Fix issues and try again.")
                    print("   Use --force to bypass errors (not recommended).")
                    sys.exit(1)
            elif warning_count > 0:
                if force:
                    print("\n⚠️  Warnings found but --force flag used. Continuing with submission...")
                else:
                    response = input(f"\n⚠️  Found {warning_count} warning(s). Continue anyway? [y/N]: ").strip().lower()
                    if response not in ('y', 'yes'):
                        print("Submission aborted.")
                        sys.exit(1)
        else:
            print("✅ Checker passed!")

    round_id = get_current_round()

    submit_algorithm(algorithm_file)
    data = monitor_status(round_id, algorithm_file)

    if data["status"] in ("ERROR", "ERROR_FINISHED"):
        print(f"❌ Submission finished with status: {data['status']}")

        if output_file is not None:
            output_with_ext = output_file.with_suffix(".json")
            try:
                download_graph(data, output_with_ext)
            except Exception:
                print("Could not download graph data for errored submission")

        sys.exit(1)

    print(f"✅ Submission completed successfully! (id={data['id']})")

    if output_file is not None:
        output_with_ext = output_file.with_suffix(".json")
        download_graph(data, output_with_ext)
        log_profit_loss(output_with_ext)
