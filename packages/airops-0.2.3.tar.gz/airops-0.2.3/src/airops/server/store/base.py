"""Base types and protocol for run stores."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Any, Protocol, runtime_checkable


class RunStatus(str, Enum):
    """Status of a tool run."""

    QUEUED = "queued"
    RUNNING = "running"
    SUCCESS = "success"
    ERROR = "error"


@dataclass
class RunError:
    """Error details for a failed run."""

    code: str
    message: str
    details: dict[str, Any] | None = None
    traceback: str | None = None


@dataclass
class Run:
    """A tool run record."""

    run_id: str
    status: RunStatus
    created_at: datetime
    updated_at: datetime
    inputs: dict[str, Any]
    outputs: dict[str, Any] | None = None
    error: RunError | None = None


@runtime_checkable
class RunStore(Protocol):
    """Protocol defining the async run store interface.

    All methods are async to support both in-memory (trivially async)
    and network-backed implementations (e.g. InternalApiRunStore with httpx).
    """

    async def create(self, inputs: dict[str, Any]) -> Run:
        """Create a new run in queued state."""
        ...

    async def get(self, run_id: str) -> Run | None:
        """Get a run by ID."""
        ...

    async def set_running(self, run_id: str) -> None:
        """Mark a run as running."""
        ...

    async def set_success(self, run_id: str, outputs: dict[str, Any]) -> None:
        """Mark a run as successful with outputs."""
        ...

    async def set_error(self, run_id: str, error: RunError) -> None:
        """Mark a run as failed with error details."""
        ...

    async def clear(self) -> None:
        """Clear all runs (testing only)."""
        ...
