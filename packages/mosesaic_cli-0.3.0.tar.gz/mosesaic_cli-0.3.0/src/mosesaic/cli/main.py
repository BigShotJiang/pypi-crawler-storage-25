"""Mosesaic CLI — run, inspect, and replay agents."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

import shutil

import anyio
import httpx
import typer
from rich.console import Console

from mosesaic.cli.format import (
    console,
    err_console,
    print_agent_status,
    print_cost_summary,
    print_error,
    print_event_log,
    print_info,
    print_success,
)

_SERVER_LOG = Path.home() / ".mosesaic" / "server.log"


def _auto_start_server(base_url: str) -> bool:
    """Spawn `mosesaic serve` as a detached background process, then poll /health.

    Called only after a ConnectError — so the server is definitely not running.
    Server stdout/stderr go to ~/.mosesaic/server.log.
    Returns True once /health responds, False if it doesn't come up within 10 s.
    """
    # Locate the mosesaic binary reliably — sys.argv[0] is unreliable in uv/pytest
    # environments where it may resolve to the test runner rather than mosesaic.
    mosesaic_bin = shutil.which("mosesaic")
    if mosesaic_bin:
        cmd = [mosesaic_bin, "serve"]
    else:
        # Fallback: run as a Python module (works when mosesaic is on sys.path)
        cmd = [sys.executable, "-m", "mosesaic", "serve"]

    console.print("[dim]Server not running — starting mosesaic serve in background…[/dim]")

    _SERVER_LOG.parent.mkdir(parents=True, exist_ok=True)
    log_fh = _SERVER_LOG.open("a")
    try:
        subprocess.Popen(
            cmd,
            stdout=log_fh,
            stderr=log_fh,
            start_new_session=True,   # detach: survives CLI process exit
        )
    except Exception as exc:
        print_error(f"Could not start server: {exc}\nRun manually: mosesaic serve")
        log_fh.close()
        return False

    # Poll /health until ready (max 10 s)
    for _ in range(20):
        time.sleep(0.5)
        try:
            with httpx.Client(base_url=base_url, timeout=1.0) as c:
                if c.get("/health").is_success:
                    console.print(f"[dim]Server ready. Logs: {_SERVER_LOG}[/dim]")
                    return True
        except (httpx.ConnectError, httpx.TimeoutException):
            continue

    print_error(f"Server did not start within 10 s.\nCheck logs: {_SERVER_LOG}")
    return False

app = typer.Typer(
    name="mosesaic",
    help="Mosesaic — AI agent orchestration framework",
    no_args_is_help=True,
    rich_markup_mode="rich",
)


def _render_progress(event: dict, phases_seen: list[str]) -> None:
    """Render a single progress event to the console."""
    etype = event.get("type", "")
    agent = event.get("agent", "")
    parent = event.get("parent")

    # ── Step start: a director begins ────────────────────────────────────────
    if etype == "step_start" and "director" in agent:
        if agent not in phases_seen:
            phases_seen.append(agent)
        phase = agent.replace("_director", "").replace("_", " ").title()
        console.print(f"\n[cyan]▶[/cyan] Phase: [bold]{phase}[/bold]")

    # ── Spawn start: director spawns a specialist ─────────────────────────────
    elif etype == "spawn_start":
        console.print(f"  [dim]  ↳ spawning [italic]{agent}[/italic][/dim]")

    # ── LLM call: model / provider / tokens / cost ────────────────────────────
    elif etype == "llm_call":
        model = event.get("model") or "?"
        provider = event.get("provider") or "?"
        in_tok = event.get("input_tokens") or 0
        out_tok = event.get("output_tokens") or 0
        cost = event.get("cost_usd") or 0.0
        indent = "    " if parent else "  "
        label = agent
        console.print(
            f"{indent}[dim]{label}[/dim]  "
            f"[green]{provider}[/green]/[cyan]{model}[/cyan]  "
            f"[dim]{in_tok:,}↑ {out_tok:,}↓  ${cost:.4f}[/dim]"
        )


@app.command()
def orchestrate(
    prompt: str = typer.Argument(..., help="Natural language prompt"),
    server: str = typer.Option(
        None, "--server", "-s",
        help="Server URL (default: MOSESAIC_SERVER_URL or http://localhost:8000)",
    ),
    budget: float = typer.Option(1.0, "--budget", "-b", help="Budget in USD"),
    timeout: int = typer.Option(120, "--timeout", "-t", help="Timeout in seconds"),
) -> None:
    """Orchestrate a full AI development lifecycle from a natural language prompt.

    Connects to a running mosesaic server, submits the prompt, and streams
    phase-by-phase progress as the chief director routes through build, verify,
    and other phases.

    Example:
        mosesaic orchestrate "Add a health check endpoint to the REST API"
        mosesaic orchestrate "Fix the divide-by-zero bug in calculator.py"
    """
    base_url = (server or os.environ.get("MOSESAIC_SERVER_URL", "http://localhost:8000")).rstrip("/")

    # Step 1: Start the orchestration run (auto-start server if needed)
    for attempt in range(2):
        try:
            with httpx.Client(base_url=base_url, timeout=30.0) as client:
                resp = client.post(
                    "/orchestrate",
                    json={"prompt": prompt, "budget_usd": budget, "wait": False},
                )
            break  # success — exit retry loop
        except httpx.ConnectError:
            if attempt == 0 and _auto_start_server(base_url):
                continue  # retry now that server is up
            print_error(f"Cannot connect to Mosesaic server at {base_url}.")
            raise typer.Exit(1)

    if not resp.is_success:
        print_error(f"Server error {resp.status_code}: {resp.text}")
        raise typer.Exit(1)

    run_id = resp.json()["run_id"]
    console.print(f"[bold cyan]Orchestrating:[/bold cyan] {prompt}")
    console.print(f"[dim]Run ID: {run_id}[/dim]\n")

    # Step 2: Stream phase events via SSE
    phases_seen: list[str] = []
    final_status = "unknown"

    try:
        with httpx.Client(base_url=base_url, timeout=timeout + 10.0) as client:
            with client.stream("GET", f"/orchestrate/{run_id}/stream") as stream:
                for line in stream.iter_lines():
                    if not line.startswith("data: "):
                        continue
                    data_str = line[6:]
                    if data_str in ("[DONE]", "[TIMEOUT]"):
                        break
                    try:
                        event = json.loads(data_str)
                    except json.JSONDecodeError:
                        continue

                    # Final status event
                    if "status" in event and "from" not in event and "to" not in event and "progress" not in event:
                        final_status = event["status"]
                        break

                    # Progress event — step/spawn/llm_call from the workflow engine
                    if event.get("progress"):
                        _render_progress(event, phases_seen)
                        continue

                    # Legacy bus events (agent runs, not workflow runs)
                    to_agent = event.get("to", "")
                    if "director" in to_agent and to_agent not in phases_seen:
                        phases_seen.append(to_agent)
                        phase = to_agent.replace("_director", "").replace("_", " ").title()
                        console.print(f"\n[cyan]▶[/cyan] Phase: [bold]{phase}[/bold]")
    except httpx.TimeoutException:
        print_error(f"Orchestration did not complete within {timeout}s.")
        raise typer.Exit(1)
    except httpx.ConnectError:
        print_error(f"Lost connection to server at {base_url} while streaming.")
        raise typer.Exit(1)

    if final_status in ("completed", "unknown"):
        print_success("Orchestration complete.")
    else:
        print_error(f"Orchestration ended with status: {final_status}")
        raise typer.Exit(1)

    # Step 3: Fetch full result and render cost table
    try:
        with httpx.Client(base_url=base_url, timeout=10.0) as client:
            result_resp = client.get(f"/orchestrate/{run_id}")
    except httpx.ConnectError:
        return  # non-fatal: stream already completed, just skip the table

    if result_resp.is_success:
        data = result_resp.json()
        run_log = data.get("run_log") or []
        total_cost_usd = data.get("total_cost_usd", 0.0)
        reasoning = data.get("reasoning", "")
        files_created = data.get("files_created") or []
        how_to_install = data.get("how_to_install", "")
        how_to_use = data.get("how_to_use", "")
        how_to_verify = data.get("how_to_verify", "")
        qa_findings = data.get("qa_findings") or []
        test_output = data.get("test_output", "")

        # Phase summary table
        if run_log:
            from rich.table import Table
            table = Table(show_header=True, header_style="bold")
            table.add_column("Phase", style="cyan")
            table.add_column("Summary")
            table.add_column("Cost", justify="right")
            for entry in run_log:
                table.add_row(
                    entry["phase"],
                    entry["summary"],
                    f"${entry['cost_usd']:.3f}",
                )
            table.add_row("", "[bold]Total[/bold]", f"[bold]${total_cost_usd:.3f}[/bold]")
            console.print(table)

        # Files created
        if files_created:
            console.print("\n[bold cyan]Files created:[/bold cyan]")
            for f in files_created:
                console.print(f"  [green]+[/green] {f}")

        # How to install
        if how_to_install:
            console.print("\n[bold cyan]How to install:[/bold cyan]")
            console.print(how_to_install)

        # How to use
        if how_to_use:
            console.print("\n[bold cyan]How to use:[/bold cyan]")
            console.print(how_to_use)

        # How to verify
        if how_to_verify:
            console.print("\n[bold cyan]How to verify:[/bold cyan]")
            console.print(how_to_verify)

        # QA findings
        if qa_findings:
            console.print("\n[bold yellow]QA findings:[/bold yellow]")
            for finding in qa_findings:
                console.print(f"  [yellow]•[/yellow] {finding}")

        # Test output (truncated)
        if test_output and test_output != "No test runner detected.":
            console.print("\n[bold]Test output:[/bold]")
            lines = test_output.splitlines()
            shown = lines[:20]
            console.print("\n".join(shown))
            if len(lines) > 20:
                console.print(f"  [dim]... {len(lines) - 20} more lines[/dim]")

        resource_notes = data.get("resource_notes", "")
        phase_task_hints = data.get("phase_task_hints") or {}
        if resource_notes or phase_task_hints:
            console.print("\n[dim]Resource allocation:[/dim]")
            if resource_notes:
                console.print(f"[dim]  {resource_notes}[/dim]")
            if phase_task_hints:
                hints_str = ", ".join(f"{p}→{h}" for p, h in phase_task_hints.items())
                console.print(f"[dim]  Hints: {hints_str}[/dim]")

        if reasoning:
            console.print(f"\n[dim]Chief Director reasoning: {reasoning}[/dim]")


@app.command()
def version() -> None:
    """Print Mosesaic version information."""
    try:
        from mosesaic._version import __version__
        console.print(f"mosesaic-core  v{__version__}")
    except ImportError:
        console.print("mosesaic-core  (version unknown)")
    console.print("Python         3.12+")
    console.print("Runtime        anyio + uvloop")


@app.command()
def serve(
    host: str | None = typer.Option(None, "--host", help="Override config host"),
    port: int | None = typer.Option(None, "--port", "-p", help="Override config port"),
    with_mcp: bool = typer.Option(False, "--with-mcp", help="Also serve MCP over stdio"),
) -> None:
    """Start the Mosesaic team server.

    Loads mosesaic.toml, starts uvicorn on the configured host:port, and
    (with --with-mcp) also runs the MCP server on stdio so Claude Code can
    connect directly.

    If mosesaic.toml is missing, prompts to run `mosesaic init` first.

    Example:
        mosesaic serve
        mosesaic serve --with-mcp
        mosesaic serve --host 0.0.0.0 --port 9000
    """
    try:
        from mosesaic.team.serve import main as _serve
    except ImportError:
        print_error(
            "mosesaic-team is not installed.\n"
            "Install it: uv add mosesaic-team  or  pip install mosesaic-team"
        )
        raise typer.Exit(1)
    _serve(host=host, port=port, with_mcp=with_mcp)


# ── TOML template for mosesaic init ──────────────────────────────────────────

_INIT_TEMPLATE = """\
# mosesaic.toml — project configuration
# https://github.com/you/mosesaic

[server]
host = "127.0.0.1"
port = 8000

# Enable providers by uncommenting and setting api_key,
# or set the corresponding environment variable instead.

# [[provider]]
# name = "anthropic"
# api_key = "sk-ant-..."   # or: export ANTHROPIC_API_KEY=...

# [[provider]]
# name = "groq"            # free tier
# api_key = "gsk-..."      # or: export GROQ_API_KEY=...

# [[provider]]
# name = "gemini"          # free tier
# api_key = "AIza..."      # or: export GEMINI_API_KEY=...

# [[provider]]
# name = "openrouter"      # free tier available
# api_key = "sk-or-..."    # or: export OPENROUTER_API_KEY=...

# [[provider]]
# name = "cerebras"        # free tier
# api_key = "csk-..."      # or: export CEREBRAS_API_KEY=...

# [[provider]]
# name = "ollama"          # local, no API key needed
# base_url = "http://localhost:11434"

# Per-director model overrides (optional).
# Directors without an entry use registry auto-routing.
# [director.chief]
# provider = "anthropic"
# model = "claude-opus-4-6"
"""

_PROVIDERS = [
    ("anthropic",  "Anthropic",          "ANTHROPIC_API_KEY"),
    ("groq",       "Groq (free)",         "GROQ_API_KEY"),
    ("gemini",     "Gemini (free)",       "GEMINI_API_KEY"),
    ("openrouter", "OpenRouter (free)",   "OPENROUTER_API_KEY"),
    ("cerebras",   "Cerebras (free)",     "CEREBRAS_API_KEY"),
    ("ollama",     "Ollama (local)",      None),  # no key needed
]


def _toml_str(value: str) -> str:
    """Escape a string value for inline TOML double-quoted strings."""
    return value.replace("\\", "\\\\").replace('"', '\\"')


def _build_provider_toml(name: str, api_key: str | None, base_url: str | None) -> str:
    """Build a [[provider]] TOML block. base_url takes precedence over api_key."""
    lines = ['[[provider]]', f'name = "{name}"']
    if base_url:
        lines.append(f'base_url = "{_toml_str(base_url)}"')
    elif api_key:
        lines.append(f'api_key = "{_toml_str(api_key)}"')
    return "\n".join(lines) + "\n"


@app.command()
def init(
    interactive: bool = typer.Option(False, "--interactive", "-i", help="Wizard: prompt for providers + API keys"),
    force: bool = typer.Option(False, "--force", help="Overwrite existing mosesaic.toml"),
) -> None:
    """Create a mosesaic.toml configuration file.

    Template mode (default): writes a fully-commented template.

    Interactive mode (--interactive): prompts you to select providers
    and enter API keys. Keys left blank are expected via env var at runtime.

    Example:
        mosesaic init
        mosesaic init --interactive
        mosesaic init --force   # overwrite existing
    """
    dest = Path("mosesaic.toml")

    if dest.exists() and not force:
        print_error("mosesaic.toml already exists. Use --force to overwrite.")
        raise typer.Exit(1)

    # Ensure ~/.mosesaic/ exists
    home_dir = Path.home() / ".mosesaic"
    home_dir.mkdir(parents=True, exist_ok=True)

    if not interactive:
        dest.write_text(_INIT_TEMPLATE)
        print_success(
            "Written: mosesaic.toml — edit it to enable providers, then run: mosesaic serve"
        )
        return

    # ── Interactive wizard ────────────────────────────────────────────────────
    console.print("\nWhich providers do you have API keys for? (space-separated numbers, or 0 to skip)")
    for i, (_, label, _) in enumerate(_PROVIDERS, 1):
        console.print(f"  {i}. {label}")

    raw = typer.prompt("\nProviders", default="0")
    seen: set[int] = set()
    chosen: list[int] = []
    for tok in raw.split():
        try:
            n = int(tok)
            if 1 <= n <= len(_PROVIDERS) and n not in seen:
                chosen.append(n)
                seen.add(n)
        except ValueError:
            pass

    provider_blocks: list[str] = []

    for n in chosen:
        name, label, env_var = _PROVIDERS[n - 1]
        if name == "ollama":
            provider_blocks.append(_build_provider_toml("ollama", api_key=None, base_url="http://localhost:11434"))
        else:
            key = typer.prompt(f"{env_var} (leave blank to set via env var)", default="", hide_input=True)
            provider_blocks.append(_build_provider_toml(name, api_key=key or None, base_url=None))

    lines = [
        "# mosesaic.toml — project configuration",
        "",
        "[server]",
        'host = "127.0.0.1"',
        "port = 8000",
        "",
    ]
    lines.extend(block for block in provider_blocks)

    dest.write_text("\n".join(lines) + "\n")
    n_configured = len(provider_blocks)
    print_success(
        f"Written: mosesaic.toml  ({n_configured} provider{'s' if n_configured != 1 else ''} configured)\n"
        f"Run: mosesaic serve"
    )


_DEFAULT_AGENT_MODULES = [
    "mosesaic.team.orchestrator.directors",
    "mosesaic.team.agents.analyst",
    "mosesaic.team.agents.architect",
    "mosesaic.team.agents.devops",
    "mosesaic.team.agents.observer",
]


@app.command()
def agents(
    module: str | None = typer.Argument(None, help="Module or file path to scan (e.g. 'myapp.agents'). Defaults to mosesaic team agents."),
) -> None:
    """List all agents defined in a module (default: mosesaic team)."""
    from mosesaic.cli.loader import load_agents_from_module

    modules = [module] if module else _DEFAULT_AGENT_MODULES
    defs = []
    for mod in modules:
        try:
            defs.extend(load_agents_from_module(mod))
        except Exception as e:
            print_error(f"{mod}: {e}")
            raise typer.Exit(1)

    # deduplicate by agent name (directors module re-imports specialists)
    seen: set[str] = set()
    unique_defs = []
    for d in defs:
        if d.name not in seen:
            seen.add(d.name)
            unique_defs.append(d)
    defs = unique_defs

    if not defs:
        console.print("[yellow]No agents found.[/yellow]")
        return

    print_agent_status([
        {
            "name": d.name,
            "budget_usd": d.supervisor_policy.budget_usd,
            "max_restarts": d.supervisor_policy.max_restarts,
            "on_failure": d.supervisor_policy.on_failure,
        }
        for d in defs
    ])


@app.command()
def run(
    agent_spec: str = typer.Argument(
        ...,
        help="Agent to run: 'module:name' or '/path/to/file.py:name'",
    ),
    payload: str = typer.Option(
        "", "--payload", "-p",
        help="Message payload to send (string or JSON)",
    ),
    timeout: float = typer.Option(
        30.0, "--timeout", "-t",
        help="Seconds to wait for agent to complete",
    ),
    log: bool = typer.Option(
        False, "--log", "-l",
        help="Print the full event log after completion",
    ),
) -> None:
    """Run a single agent with an optional payload message.

    Example:
        mosesaic run myapp.agents:researcher --payload "quantum computing"
    """
    from mosesaic.cli.loader import load_agent
    from mosesaic.core.runtime import AgentRuntime

    try:
        definition = load_agent(agent_spec)
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)

    print_info(f"Starting agent '{definition.name}'…")

    # Try to parse payload as JSON, fall back to raw string
    parsed_payload: object
    if payload:
        try:
            parsed_payload = json.loads(payload)
        except json.JSONDecodeError:
            parsed_payload = payload
    else:
        parsed_payload = None

    async def _run() -> None:
        runtime = AgentRuntime()
        runtime.register(definition)

        if parsed_payload is not None:
            await runtime.send_external(definition.name, payload=parsed_payload)

        await runtime.run_until_complete(timeout=timeout)

        if log:
            print_event_log(runtime.event_log(), title=f"Event Log — {definition.name}")

        total = runtime.total_cost_usd()
        if total > 0:
            print_cost_summary(total)

    try:
        anyio.run(_run)
        print_success(f"Agent '{definition.name}' completed.")
    except TimeoutError:
        print_error(f"Agent '{definition.name}' did not complete within {timeout}s.")
        raise typer.Exit(1)
    except Exception as e:
        print_error(f"Agent '{definition.name}' failed: {e}")
        raise typer.Exit(1)


@app.command()
def inspect(
    source: str = typer.Argument(
        ...,
        help="Event log file (.json) or trace_id prefix to filter",
    ),
    trace_id: Optional[str] = typer.Option(
        None, "--trace", "-t",
        help="Filter events by trace_id prefix",
    ),
    agent: Optional[str] = typer.Option(
        None, "--agent", "-a",
        help="Filter events by agent name (from_agent or to_agent)",
    ),
) -> None:
    """Inspect a saved event log file.

    Example:
        mosesaic inspect events.json
        mosesaic inspect events.json --trace abc123
        mosesaic inspect events.json --agent researcher
    """
    path = Path(source)
    if not path.exists():
        print_error(f"File not found: {source}")
        raise typer.Exit(1)

    try:
        raw = json.loads(path.read_text())
        if not isinstance(raw, list):
            raise ValueError("Expected a JSON array of messages")
    except Exception as e:
        print_error(f"Could not parse event log: {e}")
        raise typer.Exit(1)

    # Reconstruct minimal message objects for display
    from mosesaic.core.message import AgentMessage, MessageType
    from uuid import UUID
    from datetime import datetime, timezone

    messages: list[AgentMessage] = []
    for item in raw:
        try:
            messages.append(AgentMessage(
                from_agent=item["from_agent"],
                to_agent=item["to_agent"],
                type=MessageType(item["type"]),
                payload=item.get("payload"),
                trace_id=UUID(item["trace_id"]) if "trace_id" in item else UUID(int=0),
            ))
        except Exception:
            continue  # skip malformed entries

    # Apply filters
    if trace_id:
        messages = [m for m in messages if str(m.trace_id).startswith(trace_id)]
    if agent:
        messages = [m for m in messages if agent in (m.from_agent, m.to_agent)]

    if not messages:
        console.print("[yellow]No matching events found.[/yellow]")
        return

    print_event_log(messages, title=f"Event Log: {source}")
    console.print(f"[dim]{len(messages)} event(s)[/dim]")


@app.command()
def replay(
    source: str = typer.Argument(
        ...,
        help="Event log file (.json) to replay",
    ),
    agent_spec: str = typer.Option(
        ..., "--agent", "-a",
        help="Agent to replay into: 'module:name'",
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run",
        help="Print events that would be replayed without executing",
    ),
    timeout: float = typer.Option(
        30.0, "--timeout", "-t",
        help="Seconds to wait for replay to complete",
    ),
) -> None:
    """Replay a saved event log into an agent — reproduces past behaviour.

    Reads a JSON event log and re-delivers each message to the target agent.
    Useful for debugging: reproduce the exact message sequence that caused a bug.

    Example:
        mosesaic replay events.json --agent myapp.agents:researcher
    """
    path = Path(source)
    if not path.exists():
        print_error(f"File not found: {source}")
        raise typer.Exit(1)

    try:
        raw = json.loads(path.read_text())
        if not isinstance(raw, list):
            raise ValueError("Expected a JSON array")
    except Exception as e:
        print_error(f"Could not parse event log: {e}")
        raise typer.Exit(1)

    from mosesaic.cli.loader import load_agent
    from mosesaic.core.runtime import AgentRuntime

    try:
        definition = load_agent(agent_spec)
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)

    # Collect messages addressed to this agent
    inbound = [item for item in raw if item.get("to_agent") == definition.name]

    if not inbound:
        console.print(f"[yellow]No messages addressed to '{definition.name}' in log.[/yellow]")
        return

    if dry_run:
        console.print(f"[dim]Would replay {len(inbound)} message(s) to '{definition.name}':[/dim]")
        for item in inbound:
            console.print(f"  → {item.get('type', '?')} | {str(item.get('payload', ''))[:60]}")
        return

    print_info(f"Replaying {len(inbound)} message(s) to '{definition.name}'…")

    async def _replay() -> None:
        runtime = AgentRuntime()
        runtime.register(definition)
        for item in inbound:
            await runtime.send_external(definition.name, payload=item.get("payload"))
        await runtime.run_until_complete(timeout=timeout)
        print_event_log(runtime.event_log(), title="Replay Event Log")

    try:
        anyio.run(_replay)
        print_success("Replay complete.")
    except TimeoutError:
        print_error(f"Replay did not complete within {timeout}s.")
        raise typer.Exit(1)
    except Exception as e:
        print_error(f"Replay failed: {e}")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
