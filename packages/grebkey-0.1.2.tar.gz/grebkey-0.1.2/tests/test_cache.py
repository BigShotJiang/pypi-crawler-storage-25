import time
import os
import tempfile

import pytest

from grebkey.cache import ValidationCache


RESULT = {
    "valid": True,
    "key_id": "key_abc123",
    "product_id": "prod_abc",
    "metadata": {},
    "max_activations": 3,
    "current_activations": 1,
    "remaining_activations": 2,
    "machine_activated": True,
    "expires_at": None,
}

KEY = "GREB-TEST-KEY"
FINGERPRINT = "abc123fingerprint"


@pytest.fixture
def cache(tmp_path):
    return ValidationCache(str(tmp_path))


def test_miss_returns_none(cache):
    assert cache.get(KEY, FINGERPRINT) is None


def test_set_and_get(cache):
    cache.set(KEY, FINGERPRINT, RESULT)
    entry = cache.get(KEY, FINGERPRINT)
    assert entry is not None
    assert entry["result"]["valid"] is True
    assert entry["fingerprint"] == FINGERPRINT


def test_different_keys_are_isolated(cache):
    cache.set(KEY, FINGERPRINT, RESULT)
    assert cache.get("DIFFERENT-KEY", FINGERPRINT) is None


def test_different_fingerprints_are_isolated(cache):
    cache.set(KEY, FINGERPRINT, RESULT)
    assert cache.get(KEY, "different_fingerprint") is None


def test_age_seconds_is_recent(cache):
    cache.set(KEY, FINGERPRINT, RESULT)
    entry = cache.get(KEY, FINGERPRINT)
    age = cache.age_seconds(entry)
    assert 0 <= age < 5


def test_key_not_in_filename(cache, tmp_path):
    cache.set(KEY, FINGERPRINT, RESULT)
    files = list(tmp_path.iterdir())
    assert len(files) == 1
    assert KEY not in files[0].name


def test_file_permissions_owner_only(cache, tmp_path):
    cache.set(KEY, FINGERPRINT, RESULT)
    files = list(tmp_path.iterdir())
    mode = oct(os.stat(files[0]).st_mode)[-3:]
    assert mode == "600"


def test_overwrite_updates_validated_at(cache):
    cache.set(KEY, FINGERPRINT, RESULT)
    entry1 = cache.get(KEY, FINGERPRINT)

    time.sleep(0.01)

    updated = {**RESULT, "current_activations": 2, "remaining_activations": 1}
    cache.set(KEY, FINGERPRINT, updated)
    entry2 = cache.get(KEY, FINGERPRINT)

    assert entry2["result"]["current_activations"] == 2
    assert entry2["validated_at"] >= entry1["validated_at"]
