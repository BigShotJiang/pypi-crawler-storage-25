import hashlib

from grebkey.fingerprint import get_machine_fingerprint


def test_returns_hex_string():
    fp = get_machine_fingerprint()
    assert isinstance(fp, str)
    assert len(fp) == 64  # SHA-256 hex digest is always 64 chars
    assert all(c in "0123456789abcdef" for c in fp)


def test_stable_across_calls():
    assert get_machine_fingerprint() == get_machine_fingerprint()


def test_format_is_sha256():
    fp = get_machine_fingerprint()
    # Verify it looks like a valid SHA-256 hex digest
    int(fp, 16)  # raises ValueError if not valid hex
