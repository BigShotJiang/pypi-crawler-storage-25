import json
import time

import pytest
import requests
import responses as responses_lib

from grebkey import GrebKeyClient, GrebKeyError
from grebkey.errors import GrebKeyAPIError, GrebKeyNetworkError

API_URL = "https://grebkey.example.com"
KEY = "GREB-XXXX-XXXX-XXXX-XXXX"

VALID_RESULT = {
    "valid": True,
    "reason": None,
    "key_id": "key_abc123",
    "product_id": "prod_abc",
    "metadata": {},
    "max_activations": 3,
    "current_activations": 1,
    "remaining_activations": 2,
    "machine_activated": True,
    "expires_at": "2027-12-31T00:00:00Z",
}


def make_client(tmp_path, **kwargs):
    return GrebKeyClient(
        api_url=API_URL,
        cache_dir=str(tmp_path),
        **kwargs,
    )


@responses_lib.activate
def test_validate_success(tmp_path):
    responses_lib.add(
        responses_lib.POST,
        f"{API_URL}/v1/validate",
        json=VALID_RESULT,
        status=200,
    )
    client = make_client(tmp_path)
    result = client.validate(KEY)
    assert result.valid is True
    assert result.from_cache is False
    assert result.machine_activated is True
    assert result.key_id == "key_abc123"


@responses_lib.activate
def test_validate_caches_result(tmp_path):
    responses_lib.add(
        responses_lib.POST,
        f"{API_URL}/v1/validate",
        json=VALID_RESULT,
        status=200,
    )
    client = make_client(tmp_path, cache_ttl=3600)
    client.validate(KEY)

    # Second call should NOT hit the network (cache is fresh)
    result2 = client.validate(KEY)
    assert result2.from_cache is True
    assert len(responses_lib.calls) == 1  # only one HTTP call total


@responses_lib.activate
def test_validate_stale_cache_hits_network(tmp_path):
    responses_lib.add(
        responses_lib.POST,
        f"{API_URL}/v1/validate",
        json=VALID_RESULT,
        status=200,
    )
    responses_lib.add(
        responses_lib.POST,
        f"{API_URL}/v1/validate",
        json={**VALID_RESULT, "current_activations": 2},
        status=200,
    )

    # Very short TTL so the cache is immediately stale
    client = make_client(tmp_path, cache_ttl=0)
    client.validate(KEY)
    result2 = client.validate(KEY)

    assert result2.from_cache is False
    assert result2.current_activations == 2
    assert len(responses_lib.calls) == 2


@responses_lib.activate
def test_validate_network_error_within_grace_period(tmp_path):
    responses_lib.add(
        responses_lib.POST,
        f"{API_URL}/v1/validate",
        json=VALID_RESULT,
        status=200,
    )
    client = make_client(tmp_path, cache_ttl=0, grace_period=86400)
    client.validate(KEY)

    # Now make the API unreachable
    responses_lib.add(
        responses_lib.POST,
        f"{API_URL}/v1/validate",
        body=requests.exceptions.ConnectionError("connection refused"),
    )
    result = client.validate(KEY)
    assert result.from_cache is True
    assert result.valid is True


@responses_lib.activate
def test_validate_network_error_grace_period_expired(tmp_path):
    responses_lib.add(
        responses_lib.POST,
        f"{API_URL}/v1/validate",
        json=VALID_RESULT,
        status=200,
    )
    # Zero grace period and zero TTL — expired immediately
    client = make_client(tmp_path, cache_ttl=0, grace_period=0)
    client.validate(KEY)

    responses_lib.add(
        responses_lib.POST,
        f"{API_URL}/v1/validate",
        body=requests.exceptions.ConnectionError("connection refused"),
    )
    with pytest.raises(GrebKeyNetworkError):
        client.validate(KEY)


@responses_lib.activate
def test_validate_no_cache_network_error(tmp_path):
    responses_lib.add(
        responses_lib.POST,
        f"{API_URL}/v1/validate",
        body=requests.exceptions.ConnectionError("connection refused"),
    )
    client = make_client(tmp_path)
    with pytest.raises(GrebKeyNetworkError):
        client.validate(KEY)


@responses_lib.activate
def test_validate_api_error_4xx(tmp_path):
    responses_lib.add(
        responses_lib.POST,
        f"{API_URL}/v1/validate",
        json={"message": "invalid key"},
        status=404,
    )
    client = make_client(tmp_path)
    with pytest.raises(GrebKeyAPIError) as exc_info:
        client.validate(KEY)
    assert exc_info.value.status_code == 404
    assert "invalid key" in exc_info.value.message


@responses_lib.activate
def test_validate_sends_product_id(tmp_path):
    responses_lib.add(
        responses_lib.POST,
        f"{API_URL}/v1/validate",
        json=VALID_RESULT,
        status=200,
    )
    client = make_client(tmp_path, product_id="prod_abc")
    client.validate(KEY)

    sent = json.loads(responses_lib.calls[0].request.body)
    assert sent["product_id"] == "prod_abc"


@responses_lib.activate
def test_validate_result_attributes(tmp_path):
    responses_lib.add(
        responses_lib.POST,
        f"{API_URL}/v1/validate",
        json=VALID_RESULT,
        status=200,
    )
    client = make_client(tmp_path)
    result = client.validate(KEY)

    assert result.max_activations == 3
    assert result.current_activations == 1
    assert result.remaining_activations == 2
    assert result.expires_at == "2027-12-31T00:00:00Z"
    assert result.metadata == {}


@responses_lib.activate
def test_activate_success(tmp_path):
    # validate first to populate cache with key_id
    responses_lib.add(
        responses_lib.POST,
        f"{API_URL}/v1/validate",
        json=VALID_RESULT,
        status=200,
    )
    responses_lib.add(
        responses_lib.POST,
        f"{API_URL}/v1/keys/key_abc123/activate",
        json={"id": "act_xyz", "fingerprint": "fp123"},
        status=200,
    )
    client = make_client(tmp_path)
    activation = client.activate(KEY, label="My Machine")

    assert activation.id == "act_xyz"
    sent = json.loads(responses_lib.calls[1].request.body)
    assert sent["label"] == "My Machine"


@responses_lib.activate
def test_activate_sends_auth_header(tmp_path):
    responses_lib.add(
        responses_lib.POST,
        f"{API_URL}/v1/validate",
        json=VALID_RESULT,
        status=200,
    )
    responses_lib.add(
        responses_lib.POST,
        f"{API_URL}/v1/keys/key_abc123/activate",
        json={"id": "act_xyz", "fingerprint": "fp123"},
        status=200,
    )
    client = make_client(tmp_path)
    client.activate(KEY, api_key="gk_live_secret")

    auth = responses_lib.calls[1].request.headers.get("Authorization")
    assert auth == "Bearer gk_live_secret"


@responses_lib.activate
def test_deactivate_success(tmp_path):
    responses_lib.add(
        responses_lib.POST,
        f"{API_URL}/v1/validate",
        json=VALID_RESULT,
        status=200,
    )
    responses_lib.add(
        responses_lib.POST,
        f"{API_URL}/v1/keys/key_abc123/deactivate",
        json={},
        status=200,
    )
    client = make_client(tmp_path)
    client.deactivate(KEY, api_key="gk_live_secret")

    assert len(responses_lib.calls) == 2


@responses_lib.activate
def test_fingerprint_is_stable(tmp_path):
    client = make_client(tmp_path)
    fp1 = client.get_fingerprint()
    fp2 = client.get_fingerprint()
    assert fp1 == fp2
    assert len(fp1) == 64
