from typing import Optional

import requests

from .cache import ValidationCache
from .errors import GrebKeyAPIError, GrebKeyError, GrebKeyNetworkError
from .fingerprint import get_machine_fingerprint


class ValidationResult:
    def __init__(self, data: dict, from_cache: bool = False):
        self.valid: bool = data.get("valid", False)
        self.reason: Optional[str] = data.get("reason")
        self.key_id: Optional[str] = data.get("key_id")
        self.product_id: Optional[str] = data.get("product_id")
        self.metadata: dict = data.get("metadata", {})
        self.max_activations: Optional[int] = data.get("max_activations")
        self.current_activations: Optional[int] = data.get("current_activations")
        self.remaining_activations: Optional[int] = data.get("remaining_activations")
        self.machine_activated: bool = data.get("machine_activated", False)
        self.expires_at: Optional[str] = data.get("expires_at")
        self.from_cache: bool = from_cache

    def __repr__(self) -> str:
        return (
            f"ValidationResult(valid={self.valid}, reason={self.reason!r}, "
            f"machine_activated={self.machine_activated}, from_cache={self.from_cache})"
        )


class ActivationResult:
    def __init__(self, data: dict):
        self.id: Optional[str] = data.get("id")
        self.fingerprint: Optional[str] = data.get("fingerprint")

    def __repr__(self) -> str:
        return f"ActivationResult(id={self.id!r}, fingerprint={self.fingerprint!r})"


class GrebKeyClient:
    def __init__(
        self,
        api_url: str,
        product_id: Optional[str] = None,
        cache_ttl: int = 3600,
        grace_period: int = 86400,
        cache_dir: Optional[str] = None,
        timeout: int = 10,
    ):
        self._api_url = api_url.rstrip("/")
        self._product_id = product_id
        self._cache_ttl = cache_ttl
        self._grace_period = grace_period
        self._timeout = timeout
        self._cache = ValidationCache(cache_dir or "~/.grebkey/cache")
        self._fingerprint: Optional[str] = None

    def get_fingerprint(self) -> str:
        if self._fingerprint is None:
            self._fingerprint = get_machine_fingerprint()
        return self._fingerprint

    def validate(self, key: str) -> ValidationResult:
        fingerprint = self.get_fingerprint()
        entry = self._cache.get(key, fingerprint)

        # Fresh cache hit — skip network entirely
        if entry is not None and self._cache.age_seconds(entry) < self._cache_ttl:
            return ValidationResult(entry["result"], from_cache=True)

        # Try the network
        try:
            payload = {"key": key, "fingerprint": fingerprint}
            if self._product_id:
                payload["product_id"] = self._product_id

            resp = requests.post(
                f"{self._api_url}/v1/validate",
                json=payload,
                timeout=self._timeout,
            )
            self._raise_for_status(resp)
            result_data = resp.json()
            self._cache.set(key, fingerprint, result_data)
            return ValidationResult(result_data, from_cache=False)

        except (GrebKeyAPIError, GrebKeyNetworkError):
            raise
        except requests.RequestException as exc:
            # Network failure — try grace period fallback
            if entry is not None:
                age = self._cache.age_seconds(entry)
                if self._grace_period > 0 and age < self._grace_period:
                    return ValidationResult(entry["result"], from_cache=True)
            raise GrebKeyNetworkError(
                f"GrebKey API unreachable and no valid cached result: {exc}"
            ) from exc

    def activate(
        self,
        key: str,
        api_key: Optional[str] = None,
        label: Optional[str] = None,
    ) -> ActivationResult:
        fingerprint = self.get_fingerprint()

        # Look up the key_id — we need it for the URL
        key_id = self._resolve_key_id(key)

        payload: dict = {"fingerprint": fingerprint}
        if label is not None:
            payload["label"] = label

        headers = self._auth_headers(api_key)

        try:
            resp = requests.post(
                f"{self._api_url}/v1/keys/{key_id}/activate",
                json=payload,
                headers=headers,
                timeout=self._timeout,
            )
            self._raise_for_status(resp)
            return ActivationResult(resp.json())
        except (GrebKeyAPIError, GrebKeyNetworkError):
            raise
        except requests.RequestException as exc:
            raise GrebKeyNetworkError(f"GrebKey API unreachable: {exc}") from exc

    def deactivate(
        self,
        key: str,
        api_key: Optional[str] = None,
    ) -> None:
        fingerprint = self.get_fingerprint()
        key_id = self._resolve_key_id(key)

        payload = {"fingerprint": fingerprint}
        headers = self._auth_headers(api_key)

        try:
            resp = requests.post(
                f"{self._api_url}/v1/keys/{key_id}/deactivate",
                json=payload,
                headers=headers,
                timeout=self._timeout,
            )
            self._raise_for_status(resp)
        except (GrebKeyAPIError, GrebKeyNetworkError):
            raise
        except requests.RequestException as exc:
            raise GrebKeyNetworkError(f"GrebKey API unreachable: {exc}") from exc

    def _resolve_key_id(self, key: str) -> str:
        """Validate the key and return its key_id, using cache if available."""
        fingerprint = self.get_fingerprint()
        entry = self._cache.get(key, fingerprint)
        if entry and entry["result"].get("key_id"):
            return entry["result"]["key_id"]
        # Fall back to a validate call to get the key_id
        result = self.validate(key)
        if not result.key_id:
            raise GrebKeyError("Could not determine key_id for the provided license key.")
        return result.key_id

    @staticmethod
    def _auth_headers(api_key: Optional[str]) -> dict:
        if api_key:
            return {"Authorization": f"Bearer {api_key}"}
        return {}

    @staticmethod
    def _raise_for_status(resp: requests.Response) -> None:
        if resp.status_code >= 400:
            try:
                message = resp.json().get("message", resp.text)
            except Exception:
                message = resp.text
            raise GrebKeyAPIError(message=message, status_code=resp.status_code)
