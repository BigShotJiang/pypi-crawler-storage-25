import hashlib
import json
import os
import stat
from datetime import datetime, timezone
from typing import Optional


def _key_hash(key: str) -> str:
    return hashlib.sha256(key.encode()).hexdigest()


def _now_utc() -> datetime:
    return datetime.now(timezone.utc)


def _parse_dt(s: str) -> datetime:
    # Python 3.8 doesn't support datetime.fromisoformat with Z suffix
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    return datetime.fromisoformat(s)


class ValidationCache:
    def __init__(self, cache_dir: str):
        self._dir = os.path.expanduser(cache_dir)

    def _cache_path(self, key: str, fingerprint: str) -> str:
        combo = f"{_key_hash(key)}:{fingerprint}"
        filename = hashlib.sha256(combo.encode()).hexdigest() + ".json"
        return os.path.join(self._dir, filename)

    def _ensure_dir(self) -> None:
        os.makedirs(self._dir, exist_ok=True)

    def get(self, key: str, fingerprint: str) -> Optional[dict]:
        path = self._cache_path(key, fingerprint)
        try:
            with open(path, "r") as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return None

    def set(self, key: str, fingerprint: str, result: dict) -> None:
        self._ensure_dir()
        path = self._cache_path(key, fingerprint)
        data = {
            "key_hash": _key_hash(key),
            "fingerprint": fingerprint,
            "validated_at": _now_utc().strftime("%Y-%m-%dT%H:%M:%SZ"),
            "result": result,
        }
        with open(path, "w") as f:
            json.dump(data, f)
        # restrict to owner read/write only on Unix
        try:
            os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)
        except (OSError, AttributeError):
            pass

    def age_seconds(self, entry: dict) -> float:
        validated_at = _parse_dt(entry["validated_at"])
        return (_now_utc() - validated_at).total_seconds()
