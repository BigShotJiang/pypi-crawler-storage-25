class GrebKeyError(Exception):
    """Base exception for all GrebKey errors."""


class GrebKeyNetworkError(GrebKeyError):
    """API unreachable and no valid cache (or grace period expired)."""


class GrebKeyAPIError(GrebKeyError):
    """API returned an error response (4xx/5xx)."""

    def __init__(self, message: str, status_code: int):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
