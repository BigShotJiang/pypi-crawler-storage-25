import hashlib
import os
import platform


def get_machine_fingerprint() -> str:
    """
    Build a stable machine fingerprint from OS-level identifiers.
    Returns a SHA-256 hex string.
    """
    parts = []
    system = platform.system()

    if system == "Linux":
        try:
            with open("/etc/machine-id", "r") as f:
                parts.append(f.read().strip())
        except (FileNotFoundError, PermissionError):
            pass

    elif system == "Darwin":
        try:
            import subprocess
            output = subprocess.check_output(
                ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                text=True,
            )
            for line in output.splitlines():
                if "IOPlatformUUID" in line:
                    uuid = line.split('"')[-2]
                    parts.append(uuid)
                    break
        except Exception:
            pass

    elif system == "Windows":
        try:
            import winreg
            key = winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                r"SOFTWARE\Microsoft\Cryptography",
            )
            value, _ = winreg.QueryValueEx(key, "MachineGuid")
            parts.append(value)
            winreg.CloseKey(key)
        except Exception:
            pass

    # Fallbacks — always included as secondary signals
    parts.append(platform.node())

    try:
        parts.append(os.getlogin())
    except OSError:
        # os.getlogin() can fail in certain environments (e.g. containers)
        parts.append(os.environ.get("USER", os.environ.get("USERNAME", "")))

    raw = "|".join(parts)
    return hashlib.sha256(raw.encode()).hexdigest()
