"""
----------------------------------------------
cuhkit - A CLI-oriented Python package for handling cuhHub Stormworks projects (addons/mods).
https://github.com/cuhHub/cuhkit
----------------------------------------------

Copyright (C) 2026 cuhHub

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

# // Imports
import logging
from coloredlogs import install

# // Main
logger = logging.getLogger("cuhkit")
logger.setLevel(logging.INFO)
install(logger = logger, fmt = "[%(levelname)s] %(asctime)s | %(message)s")

def set_logging_verbose(verbose: bool = False):
    """
    Sets logging level to DEBUG if verbose is True.
    
    Args:
        verbose (bool): Whether to set the logging level to DEBUG. Defaults to False.
    """

    if verbose:
        logger.setLevel(logging.DEBUG)
    else:
        logger.setLevel(logging.INFO)