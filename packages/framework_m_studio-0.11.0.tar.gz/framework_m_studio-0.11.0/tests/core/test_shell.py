"""Tests for shared shell subprocess utility."""

from __future__ import annotations

import subprocess
from unittest.mock import MagicMock, patch

import pytest


class TestShellUtility:
    """Tests for the run_cmd function."""

    def test_run_cmd_returns_stdout(self) -> None:
        """Should execute command and return stripped stdout."""
        from framework_m_studio.core.shell import run_cmd

        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "hello world\n  "

        with patch("subprocess.run", return_value=mock_result) as mock_run:
            result = run_cmd("echo 'hello world'")

            assert result == "hello world"
            mock_run.assert_called_once()

    def test_run_cmd_raises_on_nonzero_when_check_true(self) -> None:
        """Should raise CalledProcessError when check=True and command fails."""
        from framework_m_studio.core.shell import run_cmd

        error = subprocess.CalledProcessError(1, "false", "", "error output")

        with patch("subprocess.run", side_effect=error):
            with pytest.raises(subprocess.CalledProcessError) as exc:
                run_cmd("false", check=True)

            assert exc.value.returncode == 1

    def test_run_cmd_returns_empty_string_when_check_false(self) -> None:
        """Should catch error and return empty string when check=False."""
        from framework_m_studio.core.shell import run_cmd

        error = subprocess.CalledProcessError(1, "false", "", "error output")

        with patch("subprocess.run", side_effect=error):
            # Should not raise
            result = run_cmd("false", check=False)

            assert result == ""

    def test_run_cmd_dry_run_skips_execution(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Should skip subprocess execution and log when dry_run=True."""
        from framework_m_studio.core.shell import run_cmd

        with patch("subprocess.run") as mock_run:
            result = run_cmd("echo 'dangerous'", dry_run=True)

            assert result == ""
            mock_run.assert_not_called()

            captured = capsys.readouterr()
            assert "[DRY RUN]" in captured.out
