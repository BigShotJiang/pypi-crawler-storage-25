"""Tests for Schema Change Detection (SchemaDiffEngine).

TDD tests for parsing Python DocType files, extracting fields,
comparing schemas, and classifying changes as SAFE/WARNING/DANGEROUS.
"""

from __future__ import annotations

from framework_m_studio.schema_diff import (
    SchemaChange,
    SchemaDiffEngine,
)

# ── Sample Python DocType sources for testing ────────────────────────────

DOCTYPE_V1 = '''
"""Invoice DocType."""

from pydantic import Field
from framework_m_core.domain import BaseDocType


class Invoice(BaseDocType):
    """Invoice document."""

    customer: str = Field(description="Customer Name")
    amount: float = Field(description="Invoice Amount")
    status: str = Field(default="Draft", description="Status")
    notes: str | None = Field(default=None, description="Notes")
'''

DOCTYPE_V2_SAFE = '''
"""Invoice DocType — added a nullable field."""

from pydantic import Field
from framework_m_core.domain import BaseDocType


class Invoice(BaseDocType):
    """Invoice document."""

    customer: str = Field(description="Customer Name")
    amount: float = Field(description="Invoice Amount")
    status: str = Field(default="Draft", description="Status")
    notes: str | None = Field(default=None, description="Notes")
    reference: str | None = Field(default=None, description="Reference")
'''

DOCTYPE_V2_RENAMED = '''
"""Invoice DocType — renamed customer to buyer."""

from pydantic import Field
from framework_m_core.domain import BaseDocType


class Invoice(BaseDocType):
    """Invoice document."""

    buyer: str = Field(description="Buyer Name")
    amount: float = Field(description="Invoice Amount")
    status: str = Field(default="Draft", description="Status")
    notes: str | None = Field(default=None, description="Notes")
'''

DOCTYPE_V2_REQUIRED = '''
"""Invoice DocType — made notes required."""

from pydantic import Field
from framework_m_core.domain import BaseDocType


class Invoice(BaseDocType):
    """Invoice document."""

    customer: str = Field(description="Customer Name")
    amount: float = Field(description="Invoice Amount")
    status: str = Field(default="Draft", description="Status")
    notes: str = Field(description="Notes")
'''

DOCTYPE_V2_LABEL = '''
"""Invoice DocType — changed label."""

from pydantic import Field
from framework_m_core.domain import BaseDocType


class Invoice(BaseDocType):
    """Invoice document."""

    customer: str = Field(description="Client Name")
    amount: float = Field(description="Invoice Amount")
    status: str = Field(default="Draft", description="Status")
    notes: str | None = Field(default=None, description="Notes")
'''

DOCTYPE_V2_DROPPED = '''
"""Invoice DocType — dropped notes field."""

from pydantic import Field
from framework_m_core.domain import BaseDocType


class Invoice(BaseDocType):
    """Invoice document."""

    customer: str = Field(description="Customer Name")
    amount: float = Field(description="Invoice Amount")
    status: str = Field(default="Draft", description="Status")
'''


class TestSchemaDiffEngine:
    """Tests for the SchemaDiffEngine."""

    def test_no_changes(self) -> None:
        """Identical sources must produce no changes."""
        engine = SchemaDiffEngine()
        changes = engine.diff(DOCTYPE_V1, DOCTYPE_V1)
        assert len(changes) == 0

    def test_safe_add_nullable_field(self) -> None:
        """Adding a nullable field with default must be SAFE."""
        engine = SchemaDiffEngine()
        changes = engine.diff(DOCTYPE_V1, DOCTYPE_V2_SAFE)

        assert len(changes) == 1
        change = changes[0]
        assert change.field_name == "reference"
        assert change.change_type == "SAFE"
        assert "added" in change.description.lower()

    def test_dangerous_rename_field(self) -> None:
        """Removing 'customer' + adding 'buyer' must flag a DANGEROUS drop."""
        engine = SchemaDiffEngine()
        changes = engine.diff(DOCTYPE_V1, DOCTYPE_V2_RENAMED)

        dangerous = [c for c in changes if c.change_type == "DANGEROUS"]
        assert len(dangerous) >= 1
        dropped_fields = [c.field_name for c in dangerous]
        assert "customer" in dropped_fields

    def test_dangerous_make_required(self) -> None:
        """Making a nullable field required must be DANGEROUS."""
        engine = SchemaDiffEngine()
        changes = engine.diff(DOCTYPE_V1, DOCTYPE_V2_REQUIRED)

        dangerous = [c for c in changes if c.change_type == "DANGEROUS"]
        assert len(dangerous) >= 1
        assert any(c.field_name == "notes" for c in dangerous)

    def test_warning_label_change(self) -> None:
        """Changing a field description/label must be WARNING."""
        engine = SchemaDiffEngine()
        changes = engine.diff(DOCTYPE_V1, DOCTYPE_V2_LABEL)

        warnings = [c for c in changes if c.change_type == "WARNING"]
        assert len(warnings) == 1
        assert warnings[0].field_name == "customer"

    def test_dangerous_drop_field(self) -> None:
        """Dropping a field must be DANGEROUS."""
        engine = SchemaDiffEngine()
        changes = engine.diff(DOCTYPE_V1, DOCTYPE_V2_DROPPED)

        dangerous = [c for c in changes if c.change_type == "DANGEROUS"]
        assert len(dangerous) >= 1
        assert any(c.field_name == "notes" for c in dangerous)


class TestSchemaChange:
    """Tests for the SchemaChange dataclass."""

    def test_creation(self) -> None:
        """SchemaChange must store field_name, change_type, description."""
        change = SchemaChange(
            field_name="customer",
            change_type="DANGEROUS",
            description="Field 'customer' was dropped.",
        )
        assert change.field_name == "customer"
        assert change.change_type == "DANGEROUS"
        assert "dropped" in change.description

    def test_has_dangerous(self) -> None:
        """Utility: check if any change is DANGEROUS."""
        changes = [
            SchemaChange("f1", "SAFE", "ok"),
            SchemaChange("f2", "DANGEROUS", "bad"),
        ]
        assert any(c.change_type == "DANGEROUS" for c in changes)

    def test_can_publish(self) -> None:
        """Can publish if no DANGEROUS changes exist."""
        changes = [
            SchemaChange("f1", "SAFE", "ok"),
            SchemaChange("f2", "WARNING", "careful"),
        ]
        can_publish = not any(c.change_type == "DANGEROUS" for c in changes)
        assert can_publish is True


class TestExtractFields:
    """Tests for the field extraction from Python source."""

    def test_extract_from_valid_source(self) -> None:
        """extract_fields must return field dict from Python source."""
        engine = SchemaDiffEngine()
        fields = engine.extract_fields(DOCTYPE_V1)

        assert "customer" in fields
        assert "amount" in fields
        assert "status" in fields
        assert "notes" in fields
        assert fields["customer"]["type"] == "str"
        assert fields["notes"]["nullable"] is True

    def test_extract_detects_defaults(self) -> None:
        """extract_fields must detect default values."""
        engine = SchemaDiffEngine()
        fields = engine.extract_fields(DOCTYPE_V1)

        assert fields["status"]["has_default"] is True
        assert fields["customer"]["has_default"] is False
