"""Tests for Documentation Generator to increase coverage."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from framework_m_studio.docs.generator import (
    generate_cli_reference,
    run_docs_generate,
)


def test_generate_cli_reference_extended(tmp_path: Path) -> None:
    # 1. Exception running CLI
    with patch(
        "framework_m_studio.core.shell.run_cmd", side_effect=Exception("mock err")
    ):
        doc = generate_cli_reference(tmp_path)
        assert "*Error running CLI" in doc

    # 2. Valid parsing
    fake_help = """
Some header
│ command1   │ Description 1 │
│ cmd2       │ Desc 2        │
│ default    │ Default desc  │
│ -other     │ Other         │
│ no_desc    │               │
│ joined desc│               │
"""

    def mock_run_cmd(*args, **kwargs):
        cmd = args[0]
        if "--help" in cmd and len(cmd) == 4:  # m --help
            return fake_help
        # Help for specific command
        return "detailed help"

    with patch("framework_m_studio.core.shell.run_cmd", side_effect=mock_run_cmd):
        doc2 = generate_cli_reference(tmp_path)
        assert "| `m command1` | Description 1 |" in doc2
        assert "| `m cmd2` | Desc 2 |" in doc2
        assert "default" not in doc2
        assert "-other" not in doc2


def test_run_docs_generate_extended(tmp_path: Path) -> None:
    # Mock scanning
    dt_mock = MagicMock()
    with (
        patch("framework_m_studio.discovery.scan_doctypes", return_value=[dt_mock]),
        patch(
            "framework_m_studio.discovery.doctype_to_dict",
            return_value={"name": "TestDoc"},
        ),
        patch("framework_m_studio.docs.generator.generate_api_reference"),
        patch("framework_m_studio.docs.generator.export_openapi_json") as mock_open_api,
    ):
        # 1. Without openapi_url
        run_docs_generate(output=str(tmp_path / "docs"), project_root=tmp_path)

        # 2. With openapi_url success
        run_docs_generate(
            output=str(tmp_path / "docs"),
            project_root=tmp_path,
            openapi_url="http://test",
        )
        mock_open_api.assert_called_once()

        # 3. With openapi_url exception
        mock_open_api.side_effect = Exception("failed export")
        run_docs_generate(
            output=str(tmp_path / "docs"),
            project_root=tmp_path,
            openapi_url="http://test",
        )
