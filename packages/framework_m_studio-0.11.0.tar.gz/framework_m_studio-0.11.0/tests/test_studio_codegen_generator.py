"""Tests for DocType Test Generator."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from framework_m_studio.codegen.test_generator import (
    _get_test_value,
    _get_update_value,
    _to_snake_case,
    generate_test,
    generate_test_file,
)


def test_to_snake_case() -> None:
    """_to_snake_case should correctly convert various formats."""
    assert _to_snake_case("PascalCase") == "pascal_case"
    assert _to_snake_case("Spaced Words") == "spaced_words"
    assert _to_snake_case("Hyphen-Cased") == "hyphen_cased"
    assert _to_snake_case("already_snake") == "already_snake"
    assert _to_snake_case("Multiple___Underscores") == "multiple_underscores"
    assert _to_snake_case("Numbers123") == "numbers123"


def test_get_test_value() -> None:
    """_get_test_value should return appropriate values for types."""
    assert _get_test_value("str", "title") == '"title_value"'
    assert _get_test_value("int") == "42"
    assert _get_test_value("float") == "3.14"
    assert _get_test_value("bool") == "True"
    assert _get_test_value("date") == "date.today()"
    assert _get_test_value("datetime") == "datetime.now()"
    assert _get_test_value("UUID") == "uuid4()"
    assert _get_test_value("Decimal") == 'Decimal("100.00")'
    assert _get_test_value("unknown") == '"test"'


def test_get_update_value() -> None:
    """_get_update_value should return appropriate update values."""
    assert _get_update_value("str", "title") == '"title_updated"'
    assert _get_update_value("int") == "99"
    assert _get_update_value("float") == "9.99"
    assert _get_update_value("bool") == "False"
    assert _get_update_value("Decimal") == 'Decimal("999.99")'
    assert _get_update_value("unknown") == '"updated"'


def test_generate_test_minimal() -> None:
    """generate_test should handle minimal schemas."""
    schema = {
        "name": "Minimal",
        "fields": [{"name": "title", "type": "str", "required": True}],
    }
    code = generate_test(schema)
    assert "class TestMinimal:" in code
    assert "def test_create_minimal(self)" in code
    assert "from doctypes.minimal import Minimal" in code
    assert 'title="title_value"' in code


def test_generate_test_complex() -> None:
    """generate_test should handle complex schemas with various types."""
    schema = {
        "name": "ComplexDoc",
        "module": "custom.module",
        "fields": [
            {"name": "name", "type": "str", "required": True},
            {"name": "age", "type": "int", "required": False, "default": "18"},
            {"name": "price", "type": "Decimal", "required": True},
            {"name": "registered_at", "type": "datetime", "required": True},
            {"name": "uid", "type": "UUID", "required": True},
            {"name": "birthday", "type": "date", "required": False},
        ],
    }
    code = generate_test(schema)
    assert "from custom.module import ComplexDoc" in code
    assert "from decimal import Decimal" in code
    assert "from datetime import datetime" in code
    assert "from datetime import date" in code
    assert "from uuid import uuid4" in code
    assert "assert doc.age == 18" in code
    assert "assert doc.birthday is None" in code
    assert "def test_update_complex_doc" in code
    assert 'doc.name = "name_updated"' in code


def test_generate_test_no_fields() -> None:
    """generate_test should handle schemas with no fields."""
    schema = {"name": "Empty"}
    code = generate_test(schema)
    assert "class TestEmpty:" in code
    assert "doc = Empty(" in code


@patch("pathlib.Path.mkdir")
@patch("pathlib.Path.write_text")
def test_generate_test_file(
    mock_write: MagicMock, mock_mkdir: MagicMock, tmp_path: Path
) -> None:
    """generate_test_file should create directory and write file."""
    schema = {"name": "TestFile"}
    test_dir = tmp_path / "tests"
    path = generate_test_file(schema, test_dir)

    # We call Path(test_dir).mkdir and write_text
    mock_mkdir.assert_called_with(parents=True, exist_ok=True)
    mock_write.assert_called_once()
    assert path.name == "test_test_file.py"
    assert path.parent == test_dir
