"""Tests for CLI Utilities to increase coverage."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import ClassVar
from unittest.mock import MagicMock, patch

from framework_m_studio.cli.utility import (
    _detect_asgi_symbol,
    _find_app,
    check_ipython_installed,
    console_command,
    entrypoints_command,
    routes_command,
)


def test_check_ipython_installed() -> None:
    # Test True
    with patch.dict(sys.modules, {"IPython": MagicMock()}):
        assert check_ipython_installed() is True

    # Test False
    with patch.dict(sys.modules, {"IPython": None}):
        assert check_ipython_installed() is False


def test_console_command() -> None:
    # 1. IPython installed, with container
    with (
        patch(
            "framework_m_studio.cli.utility.check_ipython_installed", return_value=True
        ),
        patch.dict(
            sys.modules,
            {"IPython": MagicMock(), "framework_m_core.container": MagicMock()},
        ),
    ):
        console_command(with_container=True)
        # Should initialize container and call IPython.embed

    # 2. IPython missing, no container
    with (
        patch(
            "framework_m_studio.cli.utility.check_ipython_installed", return_value=False
        ),
        patch.dict(sys.modules, {"code": MagicMock()}),
    ):
        console_command(with_container=False)


def test_detect_asgi_symbol(tmp_path: Path) -> None:
    app_py = tmp_path / "app.py"

    # syntax err
    app_py.write_text("def class")
    assert _detect_asgi_symbol(app_py) is None

    # top level assign
    app_py.write_text("app = 1")
    assert _detect_asgi_symbol(app_py) == "app"

    # annotated assign
    app_py.write_text("app: int = 1")
    assert _detect_asgi_symbol(app_py) == "app"

    # def create_app
    app_py.write_text("def create_app(): pass")
    assert _detect_asgi_symbol(app_py) == "create_app"


def test_find_app(tmp_path: Path) -> None:
    with patch("pathlib.Path.cwd", return_value=tmp_path):
        # 1. Explicit app overrides all
        assert _find_app("my_app:app") == "my_app:app"

        # 2. Fallback when nothing exists
        assert "framework_m_standard" in _find_app()

        # 3. Exists dynamically
        app_dir = tmp_path / "app"
        app_dir.mkdir()
        init_py = app_dir / "__init__.py"
        init_py.write_text("app = 1")

        assert _find_app() == "app:app"


def test_routes_command() -> None:
    def dummy_fn() -> None:
        pass

    class DummyHandler:
        fn = dummy_fn

    class DummyRoute:
        path: ClassVar[str] = "/test"
        methods: ClassVar[set[str]] = {"GET"}
        route_handler: ClassVar[DummyHandler] = DummyHandler()

    class DummyApp:
        routes: ClassVar[list] = [
            DummyRoute(),
            MagicMock(),
        ]  # second mock has no methods/route_handler

    from litestar import Litestar
    # We must patch isinstance to allow DummyApp or we just use Litestar actual mock

    app_mock = MagicMock(spec=Litestar)
    app_mock.routes = [DummyRoute(), MagicMock()]

    with (
        patch("framework_m_studio.cli.utility._find_app", return_value="test_app:app"),
        patch("importlib.import_module") as mock_import,
    ):
        mod_mock = MagicMock()
        mod_mock.app = app_mock
        mock_import.return_value = mod_mock

        # Test valid app
        routes_command()
        mock_import.assert_called_once_with("test_app")

        # Test not litestar app
        mod_mock.app = "not app"
        routes_command()

        # Test exception
        mock_import.side_effect = Exception("failed import")
        routes_command()


def test_entrypoints_command() -> None:
    # Test we can list entrypoints properly resilient to errors
    ep_mock1 = MagicMock()
    ep_mock1.name = "ep1"
    ep_mock1.value = "val1"

    ep_select_mock = MagicMock()
    ep_select_mock.select.return_value = [ep_mock1]

    with patch("importlib.metadata.entry_points", return_value=ep_select_mock):
        entrypoints_command()

    # Test exceptions in select block don't crash
    ep_select_mock.select.side_effect = Exception("group missing")
    with patch("importlib.metadata.entry_points", return_value=ep_select_mock):
        entrypoints_command()
