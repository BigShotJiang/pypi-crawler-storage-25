"""Tests for Release Orchestrator logic to increase coverage."""

from __future__ import annotations

import os
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from framework_m_studio.cli.release.models import ReleaseConfig, ReleaseUpdate
from framework_m_studio.cli.release.orchestrator import run_release_orchestration


@pytest.fixture
def mock_config() -> ReleaseConfig:
    return ReleaseConfig(
        packages=[],
        sync=[],
        release_branch="release-next",
        target_branch="main",
    )


@pytest.mark.asyncio
@patch("framework_m_studio.cli.release.orchestrator.run_cmd")
@patch("framework_m_studio.cli.release.orchestrator._load_release_config")
@patch("framework_m_studio.cli.release.orchestrator.compute_release_plan")
@patch("framework_m_studio.cli.release.orchestrator.prepare_release")
@patch("framework_m_studio.cli.release.orchestrator._stage_release_files")
@patch("framework_m_studio.cli.release.orchestrator.push_release_branch")
@patch(
    "framework_m_studio.cli.release.orchestrator.create_or_update_mr",
    new_callable=AsyncMock,
)
async def test_run_release_orchestration_unsupported_provider(
    mock_mr: AsyncMock,
    mock_push: MagicMock,
    mock_stage: MagicMock,
    mock_prep: MagicMock,
    mock_plan: MagicMock,
    mock_load: MagicMock,
    mock_run_cmd: MagicMock,
) -> None:
    """Test unsupported provider exits early."""
    with pytest.raises(SystemExit):
        await run_release_orchestration("github", "token", "123")


@pytest.mark.asyncio
@patch("framework_m_studio.cli.release.orchestrator.run_cmd")
@patch("framework_m_studio.cli.release.orchestrator._load_release_config")
@patch("framework_m_studio.cli.release.orchestrator.compute_release_plan")
@patch("framework_m_studio.cli.release.orchestrator.prepare_release")
@patch("framework_m_studio.cli.release.orchestrator._stage_release_files")
@patch("framework_m_studio.cli.release.orchestrator.push_release_branch")
@patch(
    "framework_m_studio.cli.release.orchestrator.create_or_update_mr",
    new_callable=AsyncMock,
)
async def test_run_release_orchestration_no_updates(
    mock_mr: AsyncMock,
    mock_push: MagicMock,
    mock_stage: MagicMock,
    mock_prep: MagicMock,
    mock_plan: MagicMock,
    mock_load: MagicMock,
    mock_run_cmd: MagicMock,
    mock_config: ReleaseConfig,
) -> None:
    """Test early exit when no updates needed."""
    mock_load.return_value = mock_config
    mock_plan.return_value = []

    await run_release_orchestration("gitlab", "token", "123")

    # Should not proceed to branch checkout or MR creation
    mock_prep.assert_not_called()
    mock_mr.assert_not_called()


@pytest.mark.asyncio
@patch("framework_m_studio.cli.release.orchestrator.run_cmd")
@patch("framework_m_studio.cli.release.orchestrator._load_release_config")
@patch("framework_m_studio.cli.release.orchestrator.compute_release_plan")
@patch("framework_m_studio.cli.release.orchestrator.prepare_release")
@patch("framework_m_studio.cli.release.orchestrator._stage_release_files")
@patch("framework_m_studio.cli.release.orchestrator.push_release_branch")
@patch(
    "framework_m_studio.cli.release.orchestrator.create_or_update_mr",
    new_callable=AsyncMock,
)
@patch.dict(os.environ, {"CI": "true", "CITADEL_CI_TOKEN": "123"}, clear=True)
async def test_run_release_orchestration_full_flow(
    mock_mr: AsyncMock,
    mock_push: MagicMock,
    mock_stage: MagicMock,
    mock_prep: MagicMock,
    mock_plan: MagicMock,
    mock_load: MagicMock,
    mock_run_cmd: MagicMock,
    mock_config: ReleaseConfig,
) -> None:
    """Test full release orchestration matching lines 349-420."""
    mock_load.return_value = mock_config

    # Needs at least one primary and one internal update to hit lines 400-418
    updates = [
        ReleaseUpdate(
            component="pkgA",
            component_path="pkgA",
            version_file="pyproject.toml",
            current_version="1.0.0",
            new_version="1.1.0",
            bump="minor",
            changelog="- added feature X",
        ),
        ReleaseUpdate(
            component="pkgB",
            component_path="pkgB",
            version_file="pyproject.toml",
            current_version="1.0.0",
            new_version="1.0.1",
            bump="patch",
            changelog="- internal dependency bump",
        ),
    ]
    mock_plan.return_value = updates

    # Make git status return something so commit is triggered
    def mock_run_cmd_side_effect(*args, **kwargs):
        cmd = args[0]
        if isinstance(cmd, list) and cmd[:2] == ["git", "status"]:
            return "M pyproject.toml"
        return ""

    mock_run_cmd.side_effect = mock_run_cmd_side_effect

    await run_release_orchestration("gitlab", "token123", "proj1")

    # Verify key steps were called
    mock_prep.assert_called_once()
    mock_stage.assert_called_once()
    mock_push.assert_called_once_with(
        mock_config.release_branch, "gitlab.com", "", "token123"
    )
    mock_mr.assert_called_once()

    # Check that description logic was hit
    args, _ = mock_mr.call_args
    desc = args[3]
    assert "Automated Release" in desc
    assert "pkgA" in desc
    assert "Internal Adjustments" in desc


@pytest.mark.asyncio
@patch("framework_m_studio.cli.release.orchestrator.run_cmd")
@patch("framework_m_studio.cli.release.orchestrator._load_release_config")
@patch("framework_m_studio.cli.release.orchestrator.compute_release_plan")
@patch("framework_m_studio.cli.release.orchestrator.prepare_release")
@patch("framework_m_studio.cli.release.orchestrator._stage_release_files")
async def test_run_release_orchestration_dry_run(
    mock_stage: MagicMock,
    mock_prep: MagicMock,
    mock_plan: MagicMock,
    mock_load: MagicMock,
    mock_run_cmd: MagicMock,
    mock_config: ReleaseConfig,
) -> None:
    """Test dry_run exits before git commit."""
    mock_load.return_value = mock_config
    mock_plan.return_value = [
        ReleaseUpdate(
            component="pkgA",
            component_path="pkgA",
            version_file="pyproject.toml",
            current_version="1.0.0",
            new_version="1.1.0",
            bump="minor",
            changelog="- added feature X",
        )
    ]

    await run_release_orchestration("gitlab", "token", "123", dry_run=True)

    mock_stage.assert_called_once()
    # Check that git commit is NOT called
    for call in mock_run_cmd.mock_calls:
        args = call[1]
        cmd = args[0] if args else []
        if isinstance(cmd, list):
            assert cmd[0] != "commit"


@pytest.mark.asyncio
@patch("framework_m_studio.cli.release.orchestrator.run_cmd")
@patch("framework_m_studio.cli.release.orchestrator._load_release_config")
@patch("framework_m_studio.cli.release.orchestrator.compute_release_plan")
@patch("framework_m_studio.cli.release.orchestrator.prepare_release")
@patch("framework_m_studio.cli.release.orchestrator._stage_release_files")
@patch.dict(os.environ, {"CI": "true", "CITADEL_CI_TOKEN": ""}, clear=True)
async def test_run_release_orchestration_no_token(
    mock_stage: MagicMock,
    mock_prep: MagicMock,
    mock_plan: MagicMock,
    mock_load: MagicMock,
    mock_run_cmd: MagicMock,
    mock_config: ReleaseConfig,
) -> None:
    """Test raising ValueError when token is missing."""
    mock_load.return_value = mock_config
    mock_plan.return_value = [
        ReleaseUpdate(
            component="pkgA",
            component_path="pkgA",
            version_file="pyproject.toml",
            current_version="1.0.0",
            new_version="1.1.0",
            bump="minor",
            changelog="- added feature X",
        )
    ]

    def mock_run_cmd_side_effect(*args, **kwargs):
        cmd = args[0]
        if isinstance(cmd, list) and cmd[:2] == ["git", "status"]:
            return "M pyproject.toml"
        return ""

    mock_run_cmd.side_effect = mock_run_cmd_side_effect

    with pytest.raises(ValueError, match="No Git token found"):
        await run_release_orchestration("gitlab", "", "123")
