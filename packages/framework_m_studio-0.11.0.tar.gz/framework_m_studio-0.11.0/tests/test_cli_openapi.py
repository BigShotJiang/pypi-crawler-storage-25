"""Tests for OpenAPI CLI command.

Tests for the `m docs openapi` CLI command following TDD principles.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


class TestDocsOpenAPICommand:
    """Tests for docs_openapi CLI command."""

    def test_docs_openapi_json(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Test exporting OpenAPI schema to JSON."""
        # This import will intentionally fail until the command is implemented
        from framework_m_studio.cli import docs_openapi

        output_file = tmp_path / "openapi.json"
        mock_schema = {
            "openapi": "3.1.0",
            "info": {"title": "Test API", "version": "1.0.0"},
            "paths": {},
        }

        with patch("framework_m_studio.cli.docs.urlopen") as mock_urlopen:
            mock_fp = MagicMock()
            mock_fp.read.return_value = json.dumps(mock_schema).encode()
            mock_fp.__enter__ = MagicMock(return_value=mock_fp)
            mock_fp.__exit__ = MagicMock(return_value=False)
            mock_urlopen.return_value = mock_fp

            docs_openapi(
                openapi_url="http://localhost:8000/schema/openapi.json",
                output=str(output_file),
                markdown=False,
            )

        assert output_file.exists()
        content = json.loads(output_file.read_text())
        assert content["openapi"] == "3.1.0"

        captured = capsys.readouterr()
        assert "Exported OpenAPI schema" in captured.out

    def test_docs_openapi_markdown(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Test exporting OpenAPI schema to Markdown."""
        from framework_m_studio.cli import docs_openapi

        output_file = tmp_path / "api_reference.md"
        mock_schema = {
            "openapi": "3.1.0",
            "info": {"title": "Framework M API", "version": "1.0.0"},
            "paths": {
                "/api/test": {"get": {"summary": "Test endpoint", "tags": ["Test"]}}
            },
        }

        with patch("framework_m_studio.cli.docs.urlopen") as mock_urlopen:
            mock_fp = MagicMock()
            mock_fp.read.return_value = json.dumps(mock_schema).encode()
            mock_fp.__enter__ = MagicMock(return_value=mock_fp)
            mock_fp.__exit__ = MagicMock(return_value=False)
            mock_urlopen.return_value = mock_fp

            docs_openapi(
                openapi_url="http://localhost:8000/schema/openapi.json",
                output=str(output_file),
                markdown=True,
            )

        assert output_file.exists()
        content = output_file.read_text()
        assert "# Framework M API" in content
        assert "## Test" in content
        assert "Test endpoint" in content

        captured = capsys.readouterr()
        assert "Exported OpenAPI markdown" in captured.out
