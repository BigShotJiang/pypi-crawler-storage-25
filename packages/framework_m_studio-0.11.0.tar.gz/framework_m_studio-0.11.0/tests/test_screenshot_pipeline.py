"""Tests for automated screenshot pipeline.

Tests the `m docs screenshots` CLI command following TDD principles.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


class TestScreenshotPipeline:
    """Tests for screenshot automation pipeline."""

    def test_parse_manifest_and_capture(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Test that the pipeline can parse the manifest and route to proper URLs."""
        # This import will intentionally fail until the command is implemented
        from framework_m_studio.cli import docs_screenshots

        manifest_content = """
        screenshots:
          - id: studio-test
            url: /studio/doctypes
            selector: .doctype-table
            viewport: { width: 1280, height: 720 }
            output: docs/images/studio-test.png
          - id: desk-test
            url: /app/Todo/list
            output: docs/images/desk-test.png
        """
        manifest_file = tmp_path / "screenshots.yaml"
        manifest_file.write_text(manifest_content)

        # Mock playwright and yaml to avoid launching real browsers in tests
        with (
            patch(
                "framework_m_studio.cli.docs.sync_playwright", create=True
            ) as mock_sync_playwright,
            patch("framework_m_studio.cli.docs.yaml", create=True) as mock_yaml,
        ):
            # Mock YAML parsing
            mock_yaml.safe_load.return_value = {
                "screenshots": [
                    {
                        "id": "studio-test",
                        "url": "/studio/doctypes",
                        "selector": ".doctype-table",
                        "viewport": {"width": 1280, "height": 720},
                        "output": "docs/images/studio-test.png",
                    },
                    {
                        "id": "desk-test",
                        "url": "/app/Todo/list",
                        "output": "docs/images/desk-test.png",
                    },
                ]
            }

            mock_playwright = MagicMock()
            mock_sync_playwright.return_value.__enter__.return_value = mock_playwright
            mock_browser = MagicMock()
            mock_playwright.chromium.launch.return_value = mock_browser
            mock_context = MagicMock()
            mock_browser.new_context.return_value = mock_context
            mock_page = MagicMock()
            mock_context.new_page.return_value = mock_page

            # Execute the CLI command
            docs_screenshots(
                manifest=str(manifest_file), base_url="http://localhost:8000"
            )

            # Verify interactions
            assert mock_page.goto.call_count == 2

            # Check URLs in call_args_list to be flexible with new keyword arguments
            urls = [call.args[0] for call in mock_page.goto.call_args_list]
            assert "http://localhost:8000/studio/doctypes" in urls
            assert "http://localhost:8000/app/Todo/list" in urls

            mock_page.set_viewport_size.assert_any_call({"width": 1280, "height": 720})
            # Check wait_for_selector calls
            selectors = [
                call.args[0] for call in mock_page.wait_for_selector.call_args_list
            ]
            assert ".doctype-table" in selectors

            assert mock_page.screenshot.call_count == 2
