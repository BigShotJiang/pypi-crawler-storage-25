"""Coverage tests for dev CLI command."""

from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import patch


class TestDevCLICoverage:
    """Tests for the dev command to improve coverage."""

    def test_check_frontend_exists(self, tmp_path: Path) -> None:
        """Test frontend existence check."""
        from framework_m_studio.cli.dev import _check_frontend_exists

        assert not _check_frontend_exists(tmp_path)
        (tmp_path / "package.json").touch()
        assert _check_frontend_exists(tmp_path)

    def test_find_app_explicit(self) -> None:
        """Test app finding with explicit app."""
        from framework_m_studio.cli.dev import _find_app

        assert _find_app("custom:app") == "custom:app"

    def test_find_app_auto_detect(self, tmp_path: Path) -> None:
        """Test app finding via auto-detection."""
        from framework_m_studio.cli.dev import _find_app

        (tmp_path / "app.py").write_text("app = Litestar()")
        with patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path):
            assert _find_app(None) == "app:app"

        (tmp_path / "app.py").unlink()
        (tmp_path / "main.py").write_text("def create_app(): pass")
        with patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path):
            assert _find_app(None) == "main:create_app"

    def test_dev_command_no_frontend(self, tmp_path: Path) -> None:
        """Test dev command without frontend."""
        from framework_m_studio.cli.dev import dev_command

        with (
            patch("framework_m_studio.cli.dev.Manager") as mock_manager,
            patch("framework_m_studio.cli.dev._find_app", return_value="app:app"),
            patch(
                "framework_m_studio.cli.dev._check_frontend_exists", return_value=False
            ),
            patch(
                "framework_m_studio.cli.dev.load_dev_config_from_toml", return_value={}
            ),
            patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path),
            patch.dict(os.environ, {"PYTHONPATH": ""}),
        ):
            dev_command(
                app="app:app", frontend=False, studio=False, enable_worker=False
            )

            mock_instance = mock_manager.return_value
            mock_instance.add_process.assert_called()
            calls = mock_instance.add_process.call_args_list
            names = [c[0][0] for c in calls]
            assert "backend" in names
            assert "frontend" not in names

    def test_dev_command_with_frontend(self, tmp_path: Path) -> None:
        """Test dev command with frontend."""
        from framework_m_studio.cli.dev import dev_command

        frontend_dir = tmp_path / "frontend"
        frontend_dir.mkdir(parents=True, exist_ok=True)
        (frontend_dir / "package.json").touch()

        with (
            patch("framework_m_studio.cli.dev.Manager") as mock_manager,
            patch("framework_m_studio.cli.dev._find_app", return_value="app:app"),
            patch(
                "framework_m_studio.cli.dev._check_frontend_exists", return_value=True
            ),
            patch(
                "framework_m_studio.cli.dev.discover_frontend_plugins", return_value=[]
            ),
            patch("framework_m_studio.cli.dev.generate_plugin_entry"),
            patch("framework_m_studio.cli.dev.generate_vite_config"),
            patch(
                "framework_m_studio.cli.dev.load_dev_config_from_toml", return_value={}
            ),
            patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path),
            patch.dict(os.environ, {"PYTHONPATH": ""}),
        ):
            dev_command(
                app="app:app",
                frontend=True,
                frontend_dir=frontend_dir,
                studio=False,
                enable_worker=False,
            )

            names = [
                c[0][0] for c in mock_manager.return_value.add_process.call_args_list
            ]
            assert "backend" in names
            assert "frontend" in names

    def test_dev_command_with_studio_and_worker(self, tmp_path: Path) -> None:
        """Test dev command with studio and worker enabled."""
        from framework_m_studio.cli.dev import dev_command

        with (
            patch("framework_m_studio.cli.dev.Manager") as mock_manager,
            patch("framework_m_studio.cli.dev._find_app", return_value="app:app"),
            patch(
                "framework_m_studio.cli.dev._check_frontend_exists", return_value=False
            ),
            patch(
                "framework_m_studio.cli.dev.load_dev_config_from_toml", return_value={}
            ),
            patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path),
            patch.dict(os.environ, {"PYTHONPATH": ""}),
        ):
            dev_command(app="app:app", studio=True, enable_worker=True)

            names = [
                c[0][0] for c in mock_manager.return_value.add_process.call_args_list
            ]
            assert "studio" in names
            assert "worker" in names

    def test_dev_command_with_plugins_and_toml(self, tmp_path: Path) -> None:
        """Test dev command with discovered plugins and TOML config."""
        from framework_m_studio.cli.dev import dev_command

        plugins = [
            {
                "name": "app1",
                "path": Path("/tmp/app1/index.ts"),
                "source": "installed",
                "package": "app1",
            }
        ]
        toml_config = {
            "backend_port": 9090,
            "frontend_port": 4040,
            "enable_worker": True,
            "enable_scheduler": True,
        }

        with (
            patch("framework_m_studio.cli.dev.Manager") as mock_manager,
            patch("framework_m_studio.cli.dev._find_app", return_value="app:app"),
            patch(
                "framework_m_studio.cli.dev._check_frontend_exists", return_value=True
            ),
            patch(
                "framework_m_studio.cli.dev.discover_frontend_plugins",
                return_value=plugins,
            ),
            patch(
                "framework_m_studio.cli.dev.load_dev_config_from_toml",
                return_value=toml_config,
            ),
            patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path),
            patch.dict(os.environ, {"PYTHONPATH": ""}),
        ):
            dev_command(app="app:app")

            calls = mock_manager.return_value.add_process.call_args_list
            names = [c[0][0] for c in calls]
            assert "worker" in names
            assert "scheduler" in names

    def test_dev_command_with_procfile(self, tmp_path: Path) -> None:
        """Test dev command loading custom procfile."""
        from framework_m_studio.cli.dev import dev_command

        procfile = tmp_path / "Procfile.dev"
        procfile.write_text("custom: echo 'hello'")

        with (
            patch("framework_m_studio.cli.dev.Manager") as mock_manager,
            patch("framework_m_studio.cli.dev._find_app", return_value="app:app"),
            patch(
                "framework_m_studio.cli.dev._check_frontend_exists", return_value=False
            ),
            patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path),
        ):
            dev_command(procfile=procfile)

            calls = mock_manager.return_value.add_process.call_args_list
            names = [c[0][0] for c in calls]
            assert "custom" in names
