import { Refine, ErrorComponent } from "@refinedev/core";
import { DevtoolsPanel, DevtoolsProvider } from "@refinedev/devtools";
import { RefineKbar, RefineKbarProvider } from "@refinedev/kbar";

import { BrowserRouter, Route, Routes, Outlet } from "react-router";
import routerProvider, {
  NavigateToResource,
  UnsavedChangesNotifier,
  DocumentTitleHandler,
} from "@refinedev/react-router";
import { Layout } from "./components/layout";
import "./App.css";
import { dataProvider } from "./providers/data";
import { ThemeProvider } from "./providers/theme";
import { AggregateBuilderPage } from "./pages/aggregates";
import { DocTypeList, DocTypeEdit } from "./pages/doctypes";
import { PrintBuilderPage } from "./pages/prints/PrintBuilderPage";
import { ShellConfiguratorPage } from "./pages/shell-config";
import { initFieldComponentRegistry } from "./registry";

// Initialize field component registry on app load
initFieldComponentRegistry();

function App() {
  return (
    <ThemeProvider>
      <BrowserRouter basename="/studio/ui">
        <RefineKbarProvider>
          <DevtoolsProvider>
            <Refine
              dataProvider={dataProvider}
              routerProvider={routerProvider}
              resources={[
                {
                  name: "doctypes",
                  list: "/doctypes",
                  create: "/doctypes/create",
                  edit: "/doctypes/edit/:id",
                  meta: {
                    label: "DocTypes",
                    icon: "📄",
                  },
                },
                {
                  name: "print-builder",
                  list: "/prints",
                  meta: {
                    label: "Print Builder",
                    icon: "🖨️",
                  },
                },
                {
                  name: "aggregate-builder",
                  list: "/aggregates",
                  meta: {
                    label: "Aggregate Builder",
                    icon: "🧩",
                  },
                },
                {
                  name: "shell-config",
                  list: "/shell-config",
                  meta: {
                    label: "Shell Config",
                    icon: "🧭",
                  },
                },
              ]}
              options={{
                syncWithLocation: true,
                warnWhenUnsavedChanges: true,
                projectId: "framework-m-studio",
              }}
            >
              <Routes>
                <Route
                  element={
                    <Layout>
                      <Outlet />
                    </Layout>
                  }
                >
                  <Route
                    index
                    element={<NavigateToResource resource="doctypes" />}
                  />
                  <Route path="/doctypes">
                    <Route index element={<DocTypeList />} />
                    <Route path="create" element={<DocTypeEdit />} />
                    <Route path="edit/:id" element={<DocTypeEdit />} />
                  </Route>
                  <Route path="/prints" element={<PrintBuilderPage />} />
                  <Route
                    path="/aggregates"
                    element={<AggregateBuilderPage />}
                  />
                  <Route
                    path="/shell-config"
                    element={<ShellConfiguratorPage />}
                  />
                  <Route path="*" element={<ErrorComponent />} />
                </Route>
              </Routes>
              <RefineKbar />
              <UnsavedChangesNotifier />
              <DocumentTitleHandler />
            </Refine>
            <DevtoolsPanel />
          </DevtoolsProvider>
        </RefineKbarProvider>
      </BrowserRouter>
    </ThemeProvider>
  );
}

export default App;
