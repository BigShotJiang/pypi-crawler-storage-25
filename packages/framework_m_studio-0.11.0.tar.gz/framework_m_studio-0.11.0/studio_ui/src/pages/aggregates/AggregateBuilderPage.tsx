import { useEffect, useMemo, useState } from "react";
import { useTheme } from "../../providers/theme";

interface DocTypeRecord {
  name: string;
}

interface LinkedConfig {
  doctype: string;
  link_field: string;
  cascade: "save_delete" | "save_only" | "none";
}

export function AggregateBuilderPage() {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const [doctypes, setDoctypes] = useState<string[]>([]);
  const [selectedRoot, setSelectedRoot] = useState("");
  const [linkedRows, setLinkedRows] = useState<LinkedConfig[]>([]);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const panelClass = useMemo(
    () =>
      isDark
        ? "border-zinc-700 bg-zinc-900 text-zinc-100"
        : "border-gray-200 bg-white text-gray-900",
    [isDark],
  );

  useEffect(() => {
    const loadDocTypes = async () => {
      const response = await fetch("/studio/api/doctypes");
      const data = (await response.json()) as { doctypes?: DocTypeRecord[] };
      const names = (data.doctypes ?? []).map(item => item.name);
      setDoctypes(names);
      if (names.length > 0 && !selectedRoot) {
        setSelectedRoot(names[0]);
      }
    };

    loadDocTypes().catch(err => setErrorMessage(String(err)));
  }, [selectedRoot]);

  useEffect(() => {
    if (!selectedRoot) {
      setLinkedRows([]);
      return;
    }

    const loadConfig = async () => {
      const response = await fetch(
        `/studio/api/aggregate/config/${encodeURIComponent(selectedRoot)}`,
      );
      const payload = (await response.json()) as {
        linked?: LinkedConfig[];
      };
      setLinkedRows(payload.linked ?? []);
    };

    loadConfig().catch(err => setErrorMessage(String(err)));
  }, [selectedRoot]);

  function addLinkedRow() {
    setLinkedRows(prev => [
      ...prev,
      {
        doctype: doctypes.find(name => name !== selectedRoot) ?? "",
        link_field: "parent",
        cascade: "save_delete",
      },
    ]);
  }

  function updateLinkedRow(index: number, patch: Partial<LinkedConfig>) {
    setLinkedRows(prev =>
      prev.map((row, i) => (i === index ? { ...row, ...patch } : row)),
    );
  }

  function removeLinkedRow(index: number) {
    setLinkedRows(prev => prev.filter((_, i) => i !== index));
  }

  async function saveConfig() {
    setStatusMessage(null);
    setErrorMessage(null);

    if (!selectedRoot) {
      setErrorMessage("Select a root DocType first.");
      return;
    }

    const validRows = linkedRows.filter(row => row.doctype && row.link_field);

    const response = await fetch(
      `/studio/api/aggregate/config/${encodeURIComponent(selectedRoot)}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ linked: validRows }),
      },
    );

    if (!response.ok) {
      setErrorMessage("Failed to save aggregate config.");
      return;
    }

    const payload = (await response.json()) as { linked?: LinkedConfig[] };
    setLinkedRows(payload.linked ?? []);
    setStatusMessage("Aggregate root config saved.");
  }

  return (
    <div className="space-y-6">
      <div>
        <h1
          className={`text-2xl font-semibold ${isDark ? "text-white" : "text-gray-900"}`}
        >
          Aggregate Root Builder
        </h1>
        <p className={`text-sm ${isDark ? "text-zinc-400" : "text-gray-500"}`}>
          Visually link related DocTypes and configure save-cascade behavior.
        </p>
      </div>

      {statusMessage && (
        <p className="text-sm text-emerald-500">{statusMessage}</p>
      )}
      {errorMessage && <p className="text-sm text-red-500">{errorMessage}</p>}

      <div className={`rounded-xl border p-4 ${panelClass}`}>
        <div className="mb-4 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <label className="flex items-center gap-2 text-sm">
            <span>Root DocType</span>
            <select
              value={selectedRoot}
              onChange={e => setSelectedRoot(e.target.value)}
              className={`rounded-lg border px-3 py-2 ${
                isDark
                  ? "border-zinc-700 bg-zinc-800 text-white"
                  : "border-gray-300 bg-white text-gray-900"
              }`}
            >
              <option value="">Select root</option>
              {doctypes.map(name => (
                <option key={name} value={name}>
                  {name}
                </option>
              ))}
            </select>
          </label>

          <div className="flex gap-2">
            <button
              onClick={addLinkedRow}
              className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
            >
              Add Linked DocType
            </button>
            <button
              onClick={saveConfig}
              className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700"
            >
              Save Cascade Config
            </button>
          </div>
        </div>

        <div className="space-y-3">
          {linkedRows.length === 0 ? (
            <p
              className={`text-sm ${isDark ? "text-zinc-400" : "text-gray-500"}`}
            >
              No linked DocTypes configured yet.
            </p>
          ) : (
            linkedRows.map((row, index) => (
              <div
                key={`${row.doctype}-${index}`}
                className={`grid grid-cols-1 gap-2 rounded-lg border p-3 md:grid-cols-12 ${
                  isDark
                    ? "border-zinc-700 bg-zinc-800"
                    : "border-gray-200 bg-gray-50"
                }`}
              >
                <select
                  value={row.doctype}
                  onChange={e =>
                    updateLinkedRow(index, { doctype: e.target.value })
                  }
                  className={`md:col-span-4 rounded-lg border px-3 py-2 ${
                    isDark
                      ? "border-zinc-700 bg-zinc-900 text-white"
                      : "border-gray-300 bg-white text-gray-900"
                  }`}
                >
                  <option value="">Linked DocType</option>
                  {doctypes
                    .filter(name => name !== selectedRoot)
                    .map(name => (
                      <option key={name} value={name}>
                        {name}
                      </option>
                    ))}
                </select>

                <input
                  value={row.link_field}
                  onChange={e =>
                    updateLinkedRow(index, { link_field: e.target.value })
                  }
                  placeholder="link field (e.g. parent_order)"
                  className={`md:col-span-4 rounded-lg border px-3 py-2 ${
                    isDark
                      ? "border-zinc-700 bg-zinc-900 text-white"
                      : "border-gray-300 bg-white text-gray-900"
                  }`}
                />

                <select
                  value={row.cascade}
                  onChange={e =>
                    updateLinkedRow(index, {
                      cascade: e.target.value as LinkedConfig["cascade"],
                    })
                  }
                  className={`md:col-span-3 rounded-lg border px-3 py-2 ${
                    isDark
                      ? "border-zinc-700 bg-zinc-900 text-white"
                      : "border-gray-300 bg-white text-gray-900"
                  }`}
                >
                  <option value="save_delete">save_delete</option>
                  <option value="save_only">save_only</option>
                  <option value="none">none</option>
                </select>

                <button
                  onClick={() => removeLinkedRow(index)}
                  className="md:col-span-1 rounded-lg bg-red-600 px-3 py-2 text-sm text-white hover:bg-red-700"
                >
                  X
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
