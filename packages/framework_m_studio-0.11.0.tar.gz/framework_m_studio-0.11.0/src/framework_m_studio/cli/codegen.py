"""Codegen CLI Commands.

This module provides code generation tools for Framework M.
"""

from __future__ import annotations

from typing import Annotated

import cyclopts

from framework_m_studio.cli.constants import DEFAULT_BACKEND_PORT

codegen_app = cyclopts.App(
    name="codegen",
    help="Code generation tools for Framework M",
)


@codegen_app.command(name="client")
def codegen_client(
    lang: Annotated[
        str,
        cyclopts.Parameter(
            name="--lang",
            help="Target language: ts (TypeScript) or py (Python)",
        ),
    ] = "ts",
    out: Annotated[
        str,
        cyclopts.Parameter(
            name="--out",
            help="Output directory for generated code",
        ),
    ] = "./generated",
    openapi_url: Annotated[
        str,
        cyclopts.Parameter(
            name="--openapi-url",
            help="URL to fetch OpenAPI schema from",
        ),
    ] = f"http://localhost:{DEFAULT_BACKEND_PORT}/schema/openapi.json",
) -> None:
    """Generate API client from OpenAPI schema.

    Examples:
        m codegen client --lang ts --out ./frontend/src/api
        m codegen client --lang py --out ./scripts/api_client
    """
    from pathlib import Path

    from framework_m_studio.sdk_generator import (
        fetch_openapi_schema,
        generate_typescript_client,
        generate_typescript_types,
    )

    print(f"Generating {lang.upper()} client...")
    print(f"  OpenAPI URL: {openapi_url}")
    print(f"  Output: {out}")

    # Create output directory
    output_path = Path(out)
    output_path.mkdir(parents=True, exist_ok=True)

    # Fetch schema and generate
    schema = fetch_openapi_schema(openapi_url)
    if lang.lower() == "ts":
        types_code = generate_typescript_types(schema)
        client_code = generate_typescript_client(schema)
        (output_path / "types.ts").write_text(types_code)
        (output_path / "client.ts").write_text(client_code)


@codegen_app.command(name="doctype")
def codegen_doctype(
    name: Annotated[
        str,
        cyclopts.Parameter(help="DocType class name (PascalCase)"),
    ],
    app: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--app",
            help="Target app directory",
        ),
    ] = None,
) -> None:
    """Generate DocType Python code from schema.

    This is the programmatic version of the Studio UI's
    DocType builder. Useful for CI/CD pipelines.

    Examples:
        m codegen doctype Invoice --app apps/billing
    """
    print(f"Generating DocType: {name}")
    if app:
        print(f"  Target app: {app}")
    print()
    print("⚠️  Not yet implemented. Coming in Phase 07.")
    print("    Will use LibCST for code generation")


__all__ = [
    "codegen_app",
    "codegen_client",
    "codegen_doctype",
]
