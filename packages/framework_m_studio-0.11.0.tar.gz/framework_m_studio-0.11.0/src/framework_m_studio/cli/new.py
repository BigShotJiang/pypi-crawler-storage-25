"""Scaffolding CLI Commands - Create new apps and doctypes.

This module provides CLI commands for scaffolding new Framework M
components using templates.
"""

from __future__ import annotations

import re
import shutil
import subprocess
import sys
from importlib.metadata import version as get_version
from pathlib import Path
from typing import Annotated

import cyclopts

from framework_m_studio.core.shell import run_cmd

new_app = cyclopts.App(
    name="new", help="Scaffold new components (apps, doctypes, frontends)"
)

# =============================================================================
# Template Utilities
# =============================================================================

TEMPLATES_DIR = Path(__file__).parent.parent / "templates"


def _get_template_path(category: str, name: str) -> Path:
    """Get the path to a template file.

    Args:
        category: Template category (e.g., "plugin", "app", "doctype")
        name: Template filename (e.g., "package.json.template")

    Returns:
        Path to the template file
    """
    return TEMPLATES_DIR / category / name


def _load_template(category: str, name: str) -> str:
    """Load a template file's content.

    Args:
        category: Template category
        name: Template filename

    Returns:
        Template content
    """
    return _get_template_path(category, name).read_text()


# =============================================================================
# Name Utilities
# =============================================================================


def to_pascal_case(name: str) -> str:
    """Convert name to PascalCase.

    Examples:
        >>> to_pascal_case("sales_order")
        'SalesOrder'
        >>> to_pascal_case("user")
        'User'
        >>> to_pascal_case("ItemSupplier")
        'ItemSupplier'
        >>> to_pascal_case("Sales Order")
        'SalesOrder'
        >>> to_pascal_case("my-app")
        'MyApp'
    """
    # Normalize separators: replace spaces and hyphens with underscores
    normalized = name.replace(" ", "_").replace("-", "_")

    # Handle snake_case - capitalize first letter of each part, preserve rest
    if "_" in normalized:
        return "".join(
            (word[0].upper() + word[1:]) if word else ""
            for word in normalized.split("_")
        )

    # Already PascalCase or single word - just ensure first letter is uppercase
    return name[0].upper() + name[1:] if name else name


def to_snake_case(name: str) -> str:
    """Convert name to snake_case.

    Examples:
        >>> to_snake_case("SalesOrder")
        'sales_order'
        >>> to_snake_case("user")
        'user'
        >>> to_snake_case("my-app")
        'my_app'
        >>> to_snake_case("Sales Order")
        'sales_order'
    """
    # First, replace spaces and hyphens with underscores
    name = name.replace(" ", "_").replace("-", "_")
    # Insert underscore before uppercase letters
    s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
    result = re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()
    # Collapse multiple underscores
    return re.sub("_+", "_", result)


def normalize_app_name(name: str) -> str:
    """Normalize app name to Python package format.

    Examples:
        >>> normalize_app_name("my-app")
        'my_app'
    """
    return name.replace("-", "_")


# =============================================================================
# App Detection Strategy
# =============================================================================

# Entry point group for discovering installed apps
APPS_ENTRY_POINT_GROUP = "framework_m.apps"


def detect_app_from_cwd() -> str | None:
    """Detect app name from pyproject.toml in cwd or parents.

    Returns:
        App name if found, None otherwise.
    """
    result = find_app_root()
    return result[0] if result else None


def find_app_root() -> tuple[str, Path] | None:
    """Find app name and root directory from pyproject.toml.

    Searches current directory and parents for pyproject.toml.

    Returns:
        Tuple of (app_name, root_path) if found, None otherwise.
    """
    for path in [Path.cwd(), *Path.cwd().parents]:
        pyproject = path / "pyproject.toml"
        if pyproject.exists():
            app_name = parse_project_name(pyproject)
            if app_name:
                return (app_name, path)
    return None


def parse_project_name(pyproject_path: Path) -> str | None:
    """Parse project name from pyproject.toml.

    Args:
        pyproject_path: Path to pyproject.toml

    Returns:
        Normalized project name or None
    """
    try:
        content = pyproject_path.read_text()
        # Simple regex to find name = "..."
        match = re.search(r'name\s*=\s*["\']([^"\']+)["\']', content)
        if match:
            return normalize_app_name(match.group(1))
    except Exception:
        pass
    return None


def is_interactive() -> bool:
    """Check if running in interactive terminal."""
    return sys.stdin.isatty()


def list_installed_apps() -> list[str]:
    """List installed apps from entry points.

    Scans the framework_m.apps entry point group for registered apps.

    Returns:
        List of app names
    """
    from importlib.metadata import entry_points

    eps = entry_points(group=APPS_ENTRY_POINT_GROUP)
    return [ep.name for ep in eps]


def prompt_select(prompt: str, options: list[str]) -> str | None:
    """Prompt user to select from a list of options.

    Args:
        prompt: The prompt message
        options: List of options to choose from

    Returns:
        Selected option or None if cancelled
    """
    if not options:
        return None

    print(f"\n{prompt}")
    for i, opt in enumerate(options, 1):
        print(f"  {i}. {opt}")

    try:
        choice = input("\nEnter number (or 'q' to quit): ").strip()
        if choice.lower() == "q":
            return None

        idx = int(choice) - 1
        if 0 <= idx < len(options):
            return options[idx]
    except (ValueError, EOFError, KeyboardInterrupt):
        pass

    return None


def detect_app(explicit_app: str | None = None) -> str | None:
    """Detect app using the detection strategy.

    Strategy:
    1. Explicit --app parameter wins (unless it's '.' which means current dir)
    2. Auto-detect from pyproject.toml in CWD or parents
    3. None if not found (caller handles interactive/error)

    Args:
        explicit_app: Explicitly provided app name, or '.' for current dir

    Returns:
        App name or None
    """
    # Treat '.' as "use current directory's app"
    if explicit_app and explicit_app != ".":
        return normalize_app_name(explicit_app)

    return detect_app_from_cwd()


def require_app(explicit_app: str | None = None) -> str:
    """Require an app, prompting if necessary.

    Full implementation of App Detection Strategy:
    1. Explicit --app parameter wins
    2. Auto-detect from pyproject.toml
    3. Interactive prompt if TTY
    4. Fail with error if non-interactive

    Args:
        explicit_app: Explicitly provided app name

    Returns:
        App name (guaranteed)

    Raises:
        SystemExit: If app cannot be determined
    """
    # 1. Explicit --app wins
    if explicit_app:
        return normalize_app_name(explicit_app)

    # 2. Auto-detect from CWD
    detected = detect_app_from_cwd()
    if detected:
        return detected

    # 3. Interactive prompt if TTY
    if is_interactive():
        apps = list_installed_apps()
        if apps:
            print("Could not detect app from current directory.")
            selected = prompt_select("Which app?", apps)
            if selected:
                return selected
            print("\nNo app selected.")
        else:
            print("Could not detect app from current directory.")
            print("No apps registered in entry points.")

    # 4. Fail with clear error
    print(
        "Error: Cannot detect app. Use --app <name>.",
        file=sys.stderr,
    )
    raise SystemExit(1)


# =============================================================================
# Scaffold Functions
# =============================================================================


def render_template(template: str, context: dict[str, str]) -> str:
    """Simple template rendering (no Jinja2 dependency).

    Args:
        template: Template string with {{ var }} placeholders
        context: Dict of variable names to values

    Returns:
        Rendered template
    """
    result = template
    for key, value in context.items():
        result = result.replace("{{ " + key + " }}", value)
    return result


def scaffold_doctype(
    doctype_name: str,
    output_dir: Path,
    test_output_dir: Path | None = None,
) -> dict[str, Path]:
    """Create doctype scaffold files.

    Args:
        doctype_name: Name of the doctype (e.g., "Invoice" or "sales_order")
        output_dir: Directory to create files in
        test_output_dir: Optional separate directory for test files (keeps them out of src/)

    Returns:
        Dict mapping file type to created path
    """
    class_name = to_pascal_case(doctype_name)
    snake_name = to_snake_case(doctype_name)

    context = {
        "name": doctype_name,
        "class_name": class_name,
        "snake_name": snake_name,
    }

    # Ensure output directory exists
    output_dir.mkdir(parents=True, exist_ok=True)

    created_files: dict[str, Path] = {}

    # Create doctype files (go in src/)
    doctype_files = [
        ("__init__.py", "doctype", "__init__.py.template"),
        ("doctype.py", "doctype", "doctype.py.template"),
        ("controller.py", "doctype", "controller.py.template"),
    ]

    for filename, category, template_name in doctype_files:
        filepath = output_dir / filename
        template_content = _load_template(category, template_name)
        content = render_template(template_content, context)
        filepath.write_text(content)
        created_files[filename] = filepath

    # Create test file (goes in tests/ directory if specified)
    test_dir = test_output_dir if test_output_dir else output_dir
    test_dir.mkdir(parents=True, exist_ok=True)
    test_filename = f"test_{snake_name}.py"
    test_filepath = test_dir / test_filename
    template_content = _load_template("doctype", "test.py.template")
    test_content = render_template(template_content, context)
    test_filepath.write_text(test_content)
    created_files[test_filename] = test_filepath

    return created_files


# =============================================================================
# CLI Commands
# =============================================================================


@new_app.command(name="doctype")
def new_doctype_command(
    name: Annotated[str, cyclopts.Parameter(help="Name of the new DocType")],
    app: Annotated[
        str | None,
        cyclopts.Parameter(name="--app", help="Target app name"),
    ] = None,
    output: Annotated[
        Path | None,
        cyclopts.Parameter(
            name="--output", help="Output directory (default: doctypes/<name>)"
        ),
    ] = None,
) -> None:
    """Create a new DocType with scaffolded files.

    Creates a new DocType package with:
    - doctype.py (schema definition)
    - controller.py (business logic)
    - test_*.py (pytest tests)

    Examples:
        m new:doctype Invoice
        m new:doctype Invoice --app myapp
        m new:doctype SalesOrder --output ./my_doctypes/sales_order
    """
    # Detect app if not provided
    detected_app = detect_app(app)

    # Find app root directory (where pyproject.toml is)
    app_info = find_app_root()
    app_root = app_info[1] if app_info else Path.cwd()

    if detected_app is None and output is None:
        if is_interactive():
            print("Warning: Could not detect app. Creating in current directory.")
        else:
            print(
                "Error: Cannot detect app. Use --app <name> or --output <path>.",
                file=sys.stderr,
            )
            raise SystemExit(1)

    # Determine output directory
    snake_name = to_snake_case(name)
    test_output_dir: Path | None = None

    if output:
        output_dir = output
        # If explicit output, put tests in parallel tests/ structure
        if "src" in output.parts:
            parts = list(output.parts)
            src_idx = parts.index("src")
            parts[src_idx] = "tests"
            test_output_dir = Path(*parts)
    elif detected_app:
        # Use app_root (not CWD) to construct paths
        # This ensures correct paths even when running from subdirectory
        app_namespace_doctypes = app_root / "src" / detected_app / "doctypes"
        src_doctypes = app_root / "src" / "doctypes"

        if app_namespace_doctypes.exists():
            # Namespaced structure: src/<app>/doctypes/<doctype>/
            output_dir = app_namespace_doctypes / snake_name
            test_output_dir = app_root / "tests" / "doctypes" / snake_name
        elif src_doctypes.exists():
            # Legacy flat structure: src/doctypes/<doctype>/
            output_dir = src_doctypes / snake_name
            test_output_dir = app_root / "tests" / "doctypes" / snake_name
        else:
            # Default: create in namespaced location
            output_dir = app_namespace_doctypes / snake_name
            test_output_dir = app_root / "tests" / "doctypes" / snake_name
    else:
        output_dir = Path.cwd() / snake_name
        test_output_dir = Path.cwd() / "tests" / snake_name

    # Check if directory already exists
    if output_dir.exists():
        print(f"Error: Directory already exists: {output_dir}", file=sys.stderr)
        raise SystemExit(1)

    # Scaffold
    print(f"Creating DocType: {to_pascal_case(name)}")
    print(f"  Location: {output_dir}")
    if test_output_dir:
        print(f"  Tests:    {test_output_dir}")

    created = scaffold_doctype(name, output_dir, test_output_dir)

    print()
    print("✓ Created files:")
    for _filename, filepath in created.items():
        print(f"  - {filepath}")


# =============================================================================
# New App Command
# =============================================================================


# =============================================================================
# Frontend Plugin Templates (loaded from template files)
# =============================================================================


def _load_plugin_template(name: str) -> str:
    """Load a plugin template file.

    Args:
        name: Template filename (e.g., "plugin.config.ts.template")

    Returns:
        Template file contents
    """
    return _load_template("plugin", name)


def scaffold_frontend_plugin(
    app_name: str,
    app_dir: Path,
    frontend_dir_name: str = "frontend",
) -> dict[str, Path]:
    """Create frontend plugin scaffold for an app.

    Creates the frontend plugin directory structure per ADR-0008.
    Templates are loaded from framework_m_studio/templates/plugin/.

    Args:
        app_name: Name of the app (e.g., "wms")
        app_dir: Root directory of the app (e.g., .../wms/)
        frontend_dir_name: Name of the frontend directory (default: "frontend")

    Returns:
        Dict mapping file type to created path
    """
    class_name = to_pascal_case(app_name)
    snake_name = to_snake_case(app_name)

    context = {
        "app_name": snake_name,
        "class_name": class_name,
    }

    frontend_dir = app_dir / frontend_dir_name
    frontend_dir.mkdir(parents=True, exist_ok=True)

    src_dir = frontend_dir / "src"
    src_dir.mkdir(parents=True, exist_ok=True)

    # Ensure required subdirectories exist (ADR-0008)
    for sub in ["pages", "components", "services"]:
        (src_dir / sub).mkdir(parents=True, exist_ok=True)

    created_files: dict[str, Path] = {}

    # Template file → output path mapping
    template_map = {
        "package.json.template": frontend_dir / "package.json",
        "plugin.config.ts.template": src_dir / "plugin.config.ts",
        "index.tsx.template": src_dir / "index.tsx",
        "index.html.template": frontend_dir / "index.html",
        "theme.css.template": src_dir / "theme.css",
        "vite.config.ts.template": frontend_dir / "vite.config.ts",
        "vite.config.mfe.ts.template": frontend_dir / "vite.config.mfe.ts",
        "tsconfig.json.template": frontend_dir / "tsconfig.json",
        "README.md.template": frontend_dir / "README.md",
        "Dashboard.tsx.template": src_dir / "pages" / "Dashboard.tsx",
        ".gitignore.template": frontend_dir / ".gitignore",
    }

    for template_name, output_path in template_map.items():
        template_content = _load_plugin_template(template_name)
        rendered = render_template(template_content, context)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(rendered)
        created_files[str(output_path.relative_to(app_dir))] = output_path

    # Static files (copied as-is)
    static_files = {
        "favicon.png": frontend_dir / "public" / "favicon.png",
    }

    for static_name, output_path in static_files.items():
        source_path = _get_template_path("plugin", static_name)
        if source_path.exists():
            output_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source_path, output_path)
            created_files[str(output_path.relative_to(app_dir))] = output_path

    return created_files


def scaffold_app(
    app_name: str,
    output_dir: Path,
) -> dict[str, Path]:
    """Create app scaffold files.

    Args:
        app_name: Name of the app (e.g., "myapp")
        output_dir: Directory to create app in

    Returns:
        Dict mapping file type to created path
    """
    class_name = to_pascal_case(app_name)
    snake_name = to_snake_case(app_name)

    # Get current versions for the template
    try:
        framework_version = get_version("framework-m")
    except Exception:
        framework_version = "0.4.7"

    try:
        studio_version = get_version("framework-m-studio")
    except Exception:
        studio_version = "0.3.5"

    context = {
        "app_name": snake_name,
        "class_name": class_name,
        "framework_version": framework_version,
        "studio_version": studio_version,
    }

    # Create directory structure
    app_dir = output_dir / snake_name
    app_dir.mkdir(parents=True, exist_ok=True)

    # Create namespaced package: src/<app_name>/
    namespace_dir = app_dir / "src" / snake_name
    namespace_dir.mkdir(parents=True, exist_ok=True)

    # Create doctypes subdirectory
    doctypes_dir = namespace_dir / "doctypes"
    doctypes_dir.mkdir(parents=True, exist_ok=True)

    # Create tests directory
    tests_dir = app_dir / "tests"
    tests_dir.mkdir(parents=True, exist_ok=True)

    created_files: dict[str, Path] = {}

    # Create <app_name>/__init__.py with app configuration
    app_init_content = render_template(
        _load_template("app", "__init__.py.template"), context
    )
    app_init_path = namespace_dir / "__init__.py"
    app_init_path.write_text(app_init_content)
    created_files[f"src/{snake_name}/__init__.py"] = app_init_path

    # Create <app_name>/doctypes/__init__.py
    doctypes_init_content = render_template(
        _load_template("app", "doctypes_init.py.template"), context
    )
    doctypes_init_path = doctypes_dir / "__init__.py"
    doctypes_init_path.write_text(doctypes_init_content)
    created_files[f"src/{snake_name}/doctypes/__init__.py"] = doctypes_init_path

    # Create tests/__init__.py
    tests_init_path = tests_dir / "__init__.py"
    tests_init_path.write_text('"""Tests for the app."""\n')
    created_files["tests/__init__.py"] = tests_init_path

    # Create pyproject.toml
    pyproject_content = render_template(
        _load_template("app", "pyproject.toml.template"), context
    )
    pyproject_path = app_dir / "pyproject.toml"
    pyproject_path.write_text(pyproject_content)
    created_files["pyproject.toml"] = pyproject_path

    # Create README.md
    readme_content = render_template(
        _load_template("app", "README.md.template"), context
    )
    readme_path = app_dir / "README.md"
    readme_path.write_text(readme_content)
    created_files["README.md"] = readme_path

    return created_files


@new_app.command(name="app")
def new_app_command(
    name: Annotated[str, cyclopts.Parameter(help="Name of the new app")],
    output_dir: Annotated[
        Path,
        cyclopts.Parameter(
            name="--output-dir", help="Parent directory for the new app"
        ),
    ] = Path(),
    with_frontend: Annotated[
        bool,
        cyclopts.Parameter(
            name="--with-frontend",
            help="Scaffold a frontend plugin alongside the app",
        ),
    ] = False,
    frontend_dir: Annotated[
        str,
        cyclopts.Parameter(
            name="--frontend-dir",
            help="Name of the frontend directory",
        ),
    ] = "frontend",
) -> None:
    """Create a new Framework M app.

    Creates a minimal app structure with:
    - pyproject.toml (with Framework M dependency)
    - README.md
    - src/<app>/doctypes/ (namespaced structure for DocTypes)

    With --with-frontend, also creates a frontend plugin:
    - frontend/package.json (with framework-m plugin metadata)
    - frontend/src/plugin.config.ts (plugin manifest)
    - frontend/tsconfig.json

    Examples:
        m new:app myapp
        m new:app myapp --output-dir ./apps
        m new:app myapp --with-frontend
    """
    snake_name = to_snake_case(name)
    app_path = output_dir / snake_name

    # Check if directory already exists
    if app_path.exists():
        print(f"Error: Directory already exists: {app_path}", file=sys.stderr)
        raise SystemExit(1)

    print(f"Creating new app: {name}")
    print(f"  Location: {app_path}")
    if with_frontend:
        print("  Frontend: ✓ (plugin scaffolding)")
    print()

    created = scaffold_app(name, output_dir)

    # Optionally scaffold frontend plugin
    frontend_created: dict[str, Path] = {}
    if with_frontend:
        frontend_created = scaffold_frontend_plugin(name, app_path, frontend_dir)
        created.update(frontend_created)

        # Install dependencies for the frontend
        _install_dependencies(app_path / frontend_dir)

    print("✓ Created files:")
    for filepath in created.values():
        print(f"  - {filepath}")

    print()
    print("✓ Created directory structure:")
    print(f"  - {app_path}/src/{snake_name}/doctypes/")
    print(f"  - {app_path}/tests/")
    if with_frontend:
        print(f"  - {app_path}/{frontend_dir}/src/pages/")
        print(f"  - {app_path}/{frontend_dir}/src/components/")
        print(f"  - {app_path}/{frontend_dir}/src/services/")
    print()
    print("Next steps:")
    print(f"  cd {snake_name}")
    print("  m dev")


def _copy_template(source_template: Path, target: Path) -> None:
    """Copy template directory to target location.

    Args:
        source_template: Source template directory
        target: Target directory

    Raises:
        FileExistsError: If target already exists
        RuntimeError: If copy fails
    """
    if target.exists():
        msg = f"Target directory already exists: {target}"
        raise FileExistsError(msg)

    try:
        shutil.copytree(source_template, target)
        print(f"✓ Copied template to {target}")
    except Exception as e:
        msg = f"Failed to copy template: {e}"
        raise RuntimeError(msg) from e


def _install_dependencies(target: Path) -> None:
    """Install pnpm dependencies in target directory.

    Args:
        target: Frontend directory

    Raises:
        RuntimeError: If pnpm install fails
    """
    print("\nInstalling dependencies with pnpm...")
    try:
        run_cmd("pnpm install", cwd=str(target), capture_output=False)
        print("✓ Dependencies installed")
    except subprocess.CalledProcessError as e:
        msg = f"Failed to install dependencies: {e}"
        raise RuntimeError(msg) from e


@new_app.command(name="frontend")
def new_frontend_command(
    target: Annotated[
        Path | None,
        cyclopts.Parameter(
            name=["target"],
            help="Target directory for frontend (default: ./frontend)",
        ),
    ] = None,
) -> None:
    """Initialize a new frontend from template.

    This scaffolds the bundled Desk frontend template to a target directory
    and installs dependencies. The template includes:
    - React + TypeScript + Vite
    - @framework-m/desk npm package integration
    - Unified Sandbox Architecture (Shell + Plugin mode)
    - Standardized library-driven tokens (@framework-m/ui)

    Examples:
        m new:frontend                      # Initialize in ./frontend
        m new:frontend ../my-frontend       # Custom location
    """
    # Detect app name for context
    app_name = detect_app() or "frontend_app"

    # Default to ./frontend if target is not provided
    target = target or Path("frontend")

    # Use unified template-rendering scaffolding
    scaffold_frontend_plugin(app_name, target.parent, target.name)

    # Install dependencies
    _install_dependencies(target)

    print("\n✓ Frontend initialized successfully!")
    print("\nNext steps:")
    print(f"  cd {target}")
    print("  pnpm dev")


__all__ = [
    "APPS_ENTRY_POINT_GROUP",
    "detect_app",
    "detect_app_from_cwd",
    "is_interactive",
    "list_installed_apps",
    "new_app",
    "new_app_command",
    "new_doctype_command",
    "new_frontend_command",
    "prompt_select",
    "require_app",
    "scaffold_app",
    "scaffold_doctype",
    "scaffold_frontend_plugin",
    "to_pascal_case",
    "to_snake_case",
]
