"""Utility CLI commands for Framework M Studio."""

from __future__ import annotations

import ast
import importlib
import sys
from pathlib import Path
from typing import Annotated

import cyclopts
from litestar import Litestar
from rich.console import Console
from rich.table import Table

console = Console()


def check_ipython_installed() -> bool:
    """Check if IPython is installed."""
    try:
        import IPython  # noqa: F401

        return True
    except ImportError:
        return False


def console_command(
    with_container: Annotated[
        bool,
        cyclopts.Parameter(
            name="--with-container", help="Auto-initialize DI container"
        ),
    ] = False,
) -> None:
    """Start an interactive console."""
    namespace = {}
    if with_container:
        from framework_m_core.container import Container

        container = Container()
        # Basic initialization
        namespace["container"] = container
        print("✓ DI Container initialized and available as 'container'")

    if check_ipython_installed():
        import IPython

        IPython.embed(header="Framework M Console", user_ns=namespace)  # type: ignore[no-untyped-call]
    else:
        import code

        code.interact(
            banner="Framework M Console (IPython not installed)", local=namespace
        )


def _detect_asgi_symbol(module_file: Path) -> str | None:
    """Detect ASGI entry symbol in a Python module.

    Returns:
        "app" if a top-level app variable is defined,
        "create_app" if a top-level create_app function is defined,
        otherwise None.
    """
    try:
        source = module_file.read_text(encoding="utf-8")
        tree = ast.parse(source)
    except (OSError, SyntaxError, UnicodeDecodeError):
        return None

    has_create_app = False

    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == "app":
                    return "app"
        elif isinstance(node, ast.AnnAssign):
            if isinstance(node.target, ast.Name) and node.target.id == "app":
                return "app"
        elif (
            isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
            and node.name == "create_app"
        ):
            has_create_app = True

    if has_create_app:
        return "create_app"

    return None


def _find_app(explicit_app: str | None = None) -> str:
    """Find the Litestar app to run by searching common locations."""
    if explicit_app:
        return explicit_app

    cwd = Path.cwd()

    candidates: list[tuple[Path, str]] = [
        (cwd / "app.py", "app"),
        (cwd / "app" / "__init__.py", "app"),
        (cwd / "src" / "app" / "__init__.py", "src.app"),
        (cwd / "main.py", "main"),
    ]

    for module_file, module_name in candidates:
        if module_file.exists():
            symbol = _detect_asgi_symbol(module_file)
            if symbol:
                return f"{module_name}:{symbol}"

    # Fallback to the standard framework app if no local app is found
    return "framework_m_standard.adapters.web.app:create_app"


def routes_command(
    app_path: Annotated[
        str | None,
        cyclopts.Parameter(name="--app", help="App path to inspect"),
    ] = None,
) -> None:
    """List API routes from the application."""
    # Add CWD to python path so we can import the app
    sys.path.insert(0, str(Path.cwd()))

    target_app = _find_app(app_path)

    try:
        module_name, attr_name = target_app.split(":")
        module = importlib.import_module(module_name)
        app_obj = getattr(module, attr_name)

        # Handle factory function
        if callable(app_obj) and not isinstance(app_obj, Litestar):
            app = app_obj()
        else:
            app = app_obj

        if not isinstance(app, Litestar):
            console.print(
                f"[red]Error: {target_app} is not a Litestar application[/red]"
            )
            return

        table = Table(
            title="Application Routes", show_header=True, header_style="bold magenta"
        )
        table.add_column("Path")
        table.add_column("Methods")
        table.add_column("Handler")

        # Inspect routes
        for route in app.routes:
            path = getattr(route, "path", "N/A")

            if hasattr(route, "methods"):
                methods = ", ".join(sorted(route.methods))
            else:
                methods = "WS/ASGI"

            handler = "Unknown"
            if hasattr(route, "route_handler"):
                fn = route.route_handler.fn
                handler = getattr(fn, "__name__", str(fn))

            table.add_row(path, methods, handler)

        console.print(table)

    except Exception as e:
        console.print(f"[red]Failed to load app routes: {e}[/red]")


def entrypoints_command() -> None:
    """List all discovered Framework M entry points."""
    from importlib.metadata import entry_points

    groups = [
        "framework_m.apps",
        "framework_m.frontend",
        "framework_m.shell",
        "framework_m.bootstrap",
        "framework_m.overrides",
        "framework_m.containers",
        "framework_m.adapters.repository",
        "framework_m.adapters.schema_mapper",
        "framework_m.adapters.unit_of_work",
        "framework_m.adapters.permission",
        "framework_m.adapters.event_bus",
        "framework_m_core.cli_commands",
    ]

    table = Table(title="Discovered Framework M Entry Points")
    table.add_column("Group", style="cyan")
    table.add_column("Name", style="green")
    table.add_column("Target", style="magenta")

    all_eps = entry_points()

    for group in groups:
        try:
            # select(group=...) is standard in 3.10+
            eps = all_eps.select(group=group)
            for ep in eps:
                table.add_row(group, ep.name, ep.value)
        except Exception:
            continue

    console.print(table)


__all__ = [
    "console_command",
    "entrypoints_command",
    "routes_command",
]
