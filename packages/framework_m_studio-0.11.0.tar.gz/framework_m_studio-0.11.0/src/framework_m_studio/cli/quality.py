"""Quality assurance commands for Framework M."""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
from typing import Annotated

import cyclopts

from framework_m_studio.core.shell import run_cmd


def get_pythonpath() -> str:
    """Construct PYTHONPATH including current directory and src."""
    cwd = Path.cwd()
    paths = [str(cwd)]

    src = cwd / "src"
    if src.exists():
        paths.append(str(src))

    return ":".join(paths)


def _has_target(args: tuple[str, ...]) -> bool:
    """Check if any argument is a target path (doesn't start with -)."""
    return any(not a.startswith("-") for a in args)


def _run_command(cmd: list[str], cwd: str | Path | None = None) -> None:
    """Run a command and exit with its return code."""
    env = os.environ.copy()

    # Construct PYTHONPATH relative to CWD if provided, else current CWD
    base_dir = Path(cwd) if cwd else Path.cwd()
    paths = [str(base_dir)]
    src = base_dir / "src"
    if src.exists():
        paths.append(str(src))

    # Preserve existing PYTHONPATH
    existing = env.get("PYTHONPATH", "")
    if existing:
        paths.append(existing)

    env["PYTHONPATH"] = ":".join(paths)

    try:
        run_cmd(cmd, cwd=cwd, env=env, capture_output=False)
        sys.exit(0)
    except subprocess.CalledProcessError as e:
        sys.exit(e.returncode)
    except KeyboardInterrupt:
        print("\nInterrupted.")
        sys.exit(130)


def test_command(
    *args: Annotated[str, cyclopts.Parameter(allow_leading_hyphen=True)],
    cwd: Annotated[
        str | None, cyclopts.Parameter(name="--cwd", help="Working directory")
    ] = None,
) -> None:
    """Run tests using pytest.

    All arguments and flags are passed directly to pytest.
    If no arguments are provided, it defaults to the current directory.

    Examples:
        m test                     # Run all tests
        m test tests/unit          # Run specific directory
        m test -s -v               # Run with pytest flags
        m test --coverage          # Run with coverage (if configured via *args)
    """
    cmd = [sys.executable, "-m", "pytest", *args]
    if not _has_target(args):
        cmd.append(".")
    _run_command(cmd, cwd=cwd)


def lint_command(
    *args: Annotated[str, cyclopts.Parameter(allow_leading_hyphen=True)],
    cwd: Annotated[
        str | None, cyclopts.Parameter(name="--cwd", help="Working directory")
    ] = None,
) -> None:
    """Lint using ruff.

    All arguments and flags are passed directly to ruff check.
    If no arguments are provided, it defaults to the current directory.
    """
    cmd = [sys.executable, "-m", "ruff", "check", *args]
    if not _has_target(args):
        cmd.append(".")
    _run_command(cmd, cwd=cwd)


def format_command(
    *args: Annotated[str, cyclopts.Parameter(allow_leading_hyphen=True)],
    cwd: Annotated[
        str | None, cyclopts.Parameter(name="--cwd", help="Working directory")
    ] = None,
) -> None:
    """Format using ruff.

    All arguments and flags are passed directly to ruff format.
    If no arguments are provided, it defaults to the current directory.
    """
    cmd = [sys.executable, "-m", "ruff", "format", *args]
    if not _has_target(args):
        cmd.append(".")
    _run_command(cmd, cwd=cwd)


def typecheck_command(
    *args: Annotated[str, cyclopts.Parameter(allow_leading_hyphen=True)],
    cwd: Annotated[
        str | None, cyclopts.Parameter(name="--cwd", help="Working directory")
    ] = None,
) -> None:
    """Type check using mypy.

    All arguments and flags are passed directly to mypy.
    If no arguments are provided, it defaults to 'src'.
    """
    cmd = [sys.executable, "-m", "mypy", *args]
    if not _has_target(args):
        cmd.append("src")
    _run_command(cmd, cwd=cwd)


def security_command(
    *args: Annotated[str, cyclopts.Parameter(allow_leading_hyphen=True)],
    cwd: Annotated[
        str | None, cyclopts.Parameter(name="--cwd", help="Working directory")
    ] = None,
) -> None:
    """Run security checks using bandit.

    All arguments and flags are passed directly to bandit.
    If no arguments are provided, it defaults to the current directory.
    """
    cmd = [sys.executable, "-m", "bandit", "-r", "-c", "pyproject.toml", *args]
    if not _has_target(args):
        cmd.append(".")
    _run_command(cmd, cwd=cwd)


def verify_doc_numbering(docs_dir: Path) -> list[str]:
    """Verify document numbering in a directory.

    Checks for:
    - No duplicate numbers
    - No skipped numbers (gaps in sequence)
    """
    import re

    errors: list[str] = []
    if not docs_dir.exists() or not docs_dir.is_dir():
        return errors

    numbers: list[int] = []
    files: dict[int, str] = {}

    for f in docs_dir.glob("*.md"):
        if f.name == "index.md":
            continue

        match = re.match(r"(?:rfc-)?(\d+)-.*\.md", f.name)
        if match:
            num_str = match.group(1)
            num = int(num_str)

            if num == 0:
                continue

            if num in files:
                errors.append(
                    f"DUPLICATE: Number {num_str} appears twice: {files[num]} and {f.name}"
                )
            else:
                files[num] = f.name
                numbers.append(num)

    if numbers:
        expected = set(range(1, max(numbers) + 1))
        missing = expected - set(numbers)

        if missing:
            missing_strs = [f"{n:04d}" for n in sorted(missing)]
            errors.append(f"SKIPPED: Missing numbers: {', '.join(missing_strs)}")

    return errors


__all__ = [
    "format_command",
    "get_pythonpath",
    "lint_command",
    "security_command",
    "test_command",
    "typecheck_command",
    "verify_doc_numbering",
]
