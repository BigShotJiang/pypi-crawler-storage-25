"""CLI commands for release orchestration."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Annotated

import cyclopts

from .gitops import GitLabProvider
from .models import ReleaseConfig
from .orchestrator import (
    _load_release_config,
    compute_release_plan,
    create_or_update_mr,
    prepare_release,
    push_release_branch,
    run_release_orchestration,
    tag_and_release,
)

# Main CLI app instance
release_app = cyclopts.App(name="release")


@release_app.command(name="auto")
async def release_auto_command(
    provider: str = "gitlab",
    token: Annotated[str | None, cyclopts.Parameter(help="Git provider token")] = None,
    project_id: Annotated[str | None, cyclopts.Parameter(help="Git project ID")] = None,
    dry_run: Annotated[bool, cyclopts.Parameter(help="Dry run")] = False,
) -> None:
    """Automated multi-package release workflow."""
    await run_release_orchestration(
        provider=provider,
        token=token
        or os.environ.get("CITADEL_CI_TOKEN")
        or os.environ.get("GITLAB_TOKEN")
        or "",
        project_id=project_id or os.environ.get("CI_PROJECT_ID") or "",
        dry_run=dry_run,
    )


@release_app.command(name="plan")
def release_plan_command(
    config: str = "release-config.json", root: str | None = None, json: bool = False
) -> None:
    """Preview which components will be released."""
    root_path = Path(root) if root else Path.cwd()
    release_config = _load_release_config(config, root=root_path)
    updates = compute_release_plan(release_config, root_path)
    if json:
        import json as _json

        print(_json.dumps([u.model_dump() for u in updates], indent=2))
        return
    if not updates:
        print("✅ No releases needed.")
        return
    for u in updates:
        print(f"🚀 {u.component}: {u.current_version} -> {u.new_version} ({u.bump})")


@release_app.command(name="prepare")
def release_prepare_command(
    config: str = "release-config.json",
    branch: str = "release/next",
    root: str | None = None,
    sbom: bool = True,
    dry_run: bool = False,
) -> None:
    """Prepare a release branch with bumped versions."""
    root_path = Path(root) if root else Path.cwd()
    try:
        release_config = _load_release_config(config, root=root_path)
    except FileNotFoundError:
        if dry_run:
            release_config = ReleaseConfig(packages=[])
        else:
            raise

    updates = compute_release_plan(release_config, root_path)
    if not updates:
        if dry_run:
            pass
        else:
            print("✅ No releases needed.")
            return

    if dry_run:
        print(f"[DRY RUN] Would prepare branch {branch} for {len(updates)} components")
        return
    prepare_release(updates, branch, root_path, release_config, sbom=sbom)
    print(f"✅ Prepared release files for {branch}")


@release_app.command(name="push")
def release_push_command(
    branch: str = "release/next",
    host: str | None = None,
    project_path: str | None = None,
    token: str | None = None,
    dry_run: bool = False,
) -> None:
    """Push the release branch to the origin remote."""
    final_host = host or os.environ.get("CI_SERVER_HOST", "gitlab.com")
    final_path = project_path or os.environ.get("CI_PROJECT_PATH", "")
    final_token = (
        token or os.environ.get("CITADEL_CI_TOKEN") or os.environ.get("GITLAB_TOKEN")
    )
    if dry_run:
        print(f"[DRY RUN] Would push branch {branch} to {final_host}/{final_path}")
        return
    if not final_token:
        print("Error: token missing", file=sys.stderr)
        raise SystemExit(1)
    push_release_branch(branch, final_host, final_path, final_token)
    print(f"✅ Pushed branch {branch}")


@release_app.command(name="mr")
async def release_mr_command(
    branch: str = "release/next",
    target_branch: str = "main",
    provider: str = "gitlab",
    token: str | None = None,
    project_id: str | None = None,
    dry_run: bool = False,
) -> None:
    """Create or update a merge request."""
    final_token = (
        token or os.environ.get("CITADEL_CI_TOKEN") or os.environ.get("GITLAB_TOKEN")
    )
    final_project_id = project_id or os.environ.get("CI_PROJECT_ID")

    if provider != "gitlab":
        print(f"Provider '{provider}' not yet supported.", file=sys.stderr)
        raise SystemExit(1)

    if dry_run:
        print(f"[DRY RUN] Would create/update MR for {branch} into {target_branch}")
        return
    if not final_token or not final_project_id:
        print("Error: token/project_id missing", file=sys.stderr)
        raise SystemExit(1)
    provider_cls = GitLabProvider(token=final_token, project_id=final_project_id)
    title = "chore(release): automated multi-package release"
    desc = "## Automated Release"
    await create_or_update_mr(branch, target_branch, title, desc, provider_cls)


@release_app.command(name="tag")
async def release_tag_command(
    config: str = "release-config.json",
    provider: str = "gitlab",
    token: str | None = None,
    project_id: str | None = None,
    dry_run: bool = False,
) -> None:
    """Create tags and releases for updated components."""
    final_token = (
        token or os.environ.get("CITADEL_CI_TOKEN") or os.environ.get("GITLAB_TOKEN")
    )
    final_project_id = project_id or os.environ.get("CI_PROJECT_ID")
    root_path = Path.cwd()

    try:
        release_config = _load_release_config(config, root=root_path)
    except Exception:
        if provider != "gitlab":
            print(f"Provider '{provider}' not yet supported.", file=sys.stderr)
            raise SystemExit(1) from None
        raise

    git_provider: GitLabProvider | None = None
    if final_token and final_project_id:
        if provider == "gitlab":
            git_provider = GitLabProvider(
                token=final_token, project_id=final_project_id
            )
        else:
            print(f"Provider '{provider}' not yet supported.", file=sys.stderr)
            raise SystemExit(1)
    await tag_and_release(release_config, root_path, git_provider, dry_run)


def release_schema_command(output: str | None = None) -> None:
    """Generate JSON schema for the release configuration."""
    from .models import ReleaseConfig

    schema = ReleaseConfig.model_json_schema()
    import json as _json

    content = _json.dumps(schema, indent=2)
    if output:
        Path(output).write_text(content)
    else:
        print(content)
