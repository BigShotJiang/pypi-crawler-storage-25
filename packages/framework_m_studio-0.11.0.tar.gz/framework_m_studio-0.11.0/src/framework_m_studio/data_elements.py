"""Data Elements — Reusable Field Blueprints.

Data Elements are standardized field definitions that can be reused
across DocTypes. They ensure enterprise-wide consistency for fields
like VAT_ID, Currency, Email, etc.

The DataElementRegistry loads blueprints from a JSON file (or K8s
ConfigMap) and tracks which DocType fields are linked to each blueprint.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from pydantic import BaseModel


class DataElement(BaseModel):
    """A reusable field blueprint.

    Defines the canonical label, type, validation, and constraints
    for a field. DocTypes can link their fields to a DataElement
    to inherit these properties and receive update notifications.
    """

    id: str
    """Unique identifier (e.g. 'VAT_ID', 'Currency')."""

    fieldtype: str
    """Field type (e.g. 'Data', 'Currency', 'Int', 'Link')."""

    label: str | None = None
    """Human-readable label. Defaults to id if not provided."""

    length: int | None = None
    """Maximum field length (for Data/varchar fields)."""

    validation: str | None = None
    """Regex pattern for field validation."""

    description: str | None = None
    """Field description / help text."""

    def __init__(self, **data: object) -> None:
        """Initialize DataElement, defaulting label to id."""
        super().__init__(**data)
        if self.label is None:
            self.label = self.id


class DataElementRegistry:
    """Registry of Data Elements (field blueprints).

    Loads from JSON files and tracks blueprint-to-DocType linkages.
    """

    def __init__(self) -> None:
        """Initialize an empty registry."""
        self.elements: dict[str, DataElement] = {}
        self._links: dict[str, list[tuple[str, str]]] = {}
        self._readonly: bool = False

    @property
    def is_readonly(self) -> bool:
        """Whether this registry is read-only (e.g. from ConfigMap)."""
        return self._readonly

    @classmethod
    def from_json(cls, path: Path) -> DataElementRegistry:
        """Load a registry from a JSON file.

        Expected format::

            {
                "elements": [
                    {"id": "VAT_ID", "fieldtype": "Data", ...},
                    ...
                ]
            }

        Args:
            path: Path to the JSON file.

        Returns:
            Populated DataElementRegistry.
        """
        registry = cls()
        data = json.loads(path.read_text())
        for item in data.get("elements", []):
            elem = DataElement(**item)
            registry.elements[elem.id] = elem
        return registry

    @classmethod
    def from_configmap(cls, path: Path) -> DataElementRegistry:
        """Load a read-only registry from a K8s ConfigMap path.

        Typically mounted at ``/etc/studio/blueprints.json``.
        Returns an empty registry if the file does not exist.

        Args:
            path: Path to the ConfigMap JSON file.

        Returns:
            Read-only DataElementRegistry.
        """
        registry = cls()
        registry._readonly = True
        if path.exists():
            data = json.loads(path.read_text())
            for item in data.get("elements", []):
                elem = DataElement(**item)
                registry.elements[elem.id] = elem
        return registry

    @classmethod
    def merge(cls, *registries: DataElementRegistry) -> DataElementRegistry:
        """Merge multiple registries into one.

        Later registries override earlier ones for duplicate IDs.

        Args:
            *registries: Registries to merge.

        Returns:
            New merged DataElementRegistry.
        """
        merged = cls()
        for registry in registries:
            merged.elements.update(registry.elements)
            for element_id, links in registry._links.items():
                if element_id not in merged._links:
                    merged._links[element_id] = []
                merged._links[element_id].extend(links)
        return merged

    def get(self, element_id: str) -> DataElement | None:
        """Get a DataElement by its id.

        Args:
            element_id: The blueprint identifier.

        Returns:
            DataElement or None if not found.
        """
        return self.elements.get(element_id)

    def register(self, element: DataElement) -> None:
        """Register a DataElement at runtime.

        Args:
            element: The DataElement to add.
        """
        self.elements[element.id] = element

    def list_ids(self) -> list[str]:
        """Return all registered element ids.

        Returns:
            List of element id strings.
        """
        return list(self.elements.keys())

    def suggest(self, fieldtype: str) -> list[DataElement]:
        """Return blueprints matching the given fieldtype.

        Used by the Studio UI to offer "Add Field from Blueprint"
        suggestions when the user selects a field type.

        Args:
            fieldtype: Field type to filter by (e.g. 'Data', 'Currency').

        Returns:
            List of matching DataElement instances.
        """
        return [elem for elem in self.elements.values() if elem.fieldtype == fieldtype]

    def link(self, doctype: str, field_name: str, element_id: str) -> None:
        """Link a DocType field to a blueprint.

        Args:
            doctype: DocType name (e.g. 'Invoice').
            field_name: Field name in the DocType (e.g. 'vat_number').
            element_id: Blueprint id to link to.
        """
        if element_id not in self._links:
            self._links[element_id] = []
        self._links[element_id].append((doctype, field_name))

    def get_linked_fields(self, element_id: str) -> list[tuple[str, str]]:
        """Get all DocType fields linked to a blueprint.

        Args:
            element_id: Blueprint id.

        Returns:
            List of (doctype, field_name) tuples.
        """
        return self._links.get(element_id, [])


@dataclass
class BreakingChange:
    """Describes a change between two DataElement versions."""

    field: str
    """Which property changed (e.g. 'fieldtype', 'length')."""

    severity: str
    """One of SAFE, WARNING, DANGEROUS."""

    description: str
    """Human-readable description of the change."""


def detect_breaking_changes(
    old: DataElement,
    new: DataElement,
) -> list[BreakingChange]:
    """Compare two versions of a DataElement and classify changes.

    Classification rules:
    - DANGEROUS: fieldtype change, length reduction
    - WARNING: validation pattern change
    - SAFE: label change, description change, length increase

    Args:
        old: The previous version of the element.
        new: The updated version of the element.

    Returns:
        List of BreakingChange instances.
    """
    changes: list[BreakingChange] = []

    # Fieldtype change → DANGEROUS
    if old.fieldtype != new.fieldtype:
        changes.append(
            BreakingChange(
                field="fieldtype",
                severity="DANGEROUS",
                description=(
                    f"Fieldtype changed from '{old.fieldtype}' to '{new.fieldtype}'. "
                    "This may cause data loss or column type mismatch."
                ),
            )
        )

    # Length change
    if old.length != new.length:
        if (
            new.length is not None
            and old.length is not None
            and new.length < old.length
        ):
            changes.append(
                BreakingChange(
                    field="length",
                    severity="DANGEROUS",
                    description=(
                        f"Length reduced from {old.length} to {new.length}. "
                        "Existing data may be truncated."
                    ),
                )
            )
        else:
            changes.append(
                BreakingChange(
                    field="length",
                    severity="SAFE",
                    description=(f"Length changed from {old.length} to {new.length}."),
                )
            )

    # Label change → SAFE
    if old.label != new.label:
        changes.append(
            BreakingChange(
                field="label",
                severity="SAFE",
                description=(f"Label changed from '{old.label}' to '{new.label}'."),
            )
        )

    # Validation pattern change → WARNING
    if old.validation != new.validation:
        changes.append(
            BreakingChange(
                field="validation",
                severity="WARNING",
                description=(
                    f"Validation pattern changed from '{old.validation}' to "
                    f"'{new.validation}'. Existing data may fail new validation."
                ),
            )
        )

    # Description change → SAFE (not flagged as it's non-breaking)

    return changes
