"""Frontend plugin discovery and configuration utilities."""

from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path
from typing import Any, TypedDict


class FrontendPluginInfo(TypedDict):
    """Frontend plugin metadata discovered from entry points or filesystem."""

    name: str
    path: Path
    source: str  # 'installed' | 'local'
    package: str | None


FRONTEND_PLUGINS_GROUP = "framework_m.frontend"


def _load_entry_point_plugin(ep: Any, resources: Any) -> FrontendPluginInfo | None:
    """Load a single frontend plugin from a Python entry point."""
    try:
        module_path = ep.module.split(":")[0]
        package_name = module_path.split(".")[0]

        try:
            frontend_src = resources.files(package_name) / "frontend"
            if hasattr(frontend_src, "is_dir") and frontend_src.is_dir():
                entry_file = frontend_src / "index.ts"
                if hasattr(entry_file, "is_file") and entry_file.is_file():
                    return FrontendPluginInfo(
                        name=ep.name,
                        path=Path(str(entry_file)),
                        source="installed",
                        package=package_name,
                    )
        except (TypeError, FileNotFoundError, AttributeError):
            pass

        print(f"  Warning: Plugin '{ep.name}' registered but no frontend source found")
        return None

    except Exception as e:
        print(f"  Warning: Failed to load frontend plugin '{ep.name}': {e}")
        return None


def _discover_from_entry_points() -> list[FrontendPluginInfo]:
    """Scan installed Python packages for frontend plugins."""
    from importlib.metadata import entry_points

    plugins: list[FrontendPluginInfo] = []
    try:
        import importlib.resources

        eps = entry_points(group=FRONTEND_PLUGINS_GROUP)
        for ep in eps:
            plugin = _load_entry_point_plugin(ep, importlib.resources)
            if plugin:
                plugins.append(plugin)
    except Exception as e:
        print(f"  Warning: Could not scan entry points: {e}")

    return plugins


def _discover_from_local_apps() -> list[FrontendPluginInfo]:
    """Scan local workspace for frontend plugins.

    This uses a targeted shallow scan of:
    1. Current working directory
    2. Immediate subdirectories of 'apps/'
    For each, it also checks for a 'frontend/' subdirectory.

    Discovery strategy:
    - Check 'package.json' for 'framework-m.plugin' metadata.
    - Fallback to common entry point patterns (index.ts, src/plugin.config.ts).
    - Ignores node_modules and other dependency folders.
    """
    import json

    plugins: list[FrontendPluginInfo] = []
    cwd = Path.cwd()

    # Potential app roots to scan
    app_roots = [cwd]
    apps_dir = cwd / "apps"
    if apps_dir.is_dir():
        app_roots.extend([d for d in apps_dir.iterdir() if d.is_dir()])

    for app_root in app_roots:
        # For each root, also check its 'frontend' subdirectory
        # (This covers various layout conventions)
        for p in [app_root, app_root / "frontend"]:
            # Skip if it doesn't look like a source directory
            if "/node_modules" in str(p) or "/.venv" in str(p):
                continue

            pkg_json = p / "package.json"
            if pkg_json.is_file():
                try:
                    data = json.loads(pkg_json.read_text(encoding="utf-8"))
                    m_config = data.get("framework-m", {})
                    if isinstance(m_config, dict):
                        plugin_rel_path = m_config.get("plugin")

                        if plugin_rel_path and isinstance(plugin_rel_path, str):
                            plugin_entry = p / plugin_rel_path
                            if plugin_entry.exists():
                                plugins.append(
                                    FrontendPluginInfo(
                                        name=data.get("name", app_root.name),
                                        path=plugin_entry,
                                        source="local",
                                        package=None,
                                    )
                                )
                                # Found via metadata - skip fallback check for this directory
                                break
                except Exception:
                    # Ignore parsing errors - fallback will catch standard layouts
                    pass

            # Fallback patterns if no metadata or metadata path doesn't exist
            # Note: order matters (index.ts preferred)
            for pattern in ["index.ts", "src/plugin.config.ts"]:
                entry = p / pattern
                if entry.exists():
                    plugins.append(
                        FrontendPluginInfo(
                            name=app_root.name,
                            path=entry,
                            source="local",
                            package=None,
                        )
                    )
                    break  # Use first fallback match
    return plugins


def discover_frontend_plugins() -> list[FrontendPluginInfo]:
    """Discover frontend plugins from entry points and local apps."""
    plugins: list[FrontendPluginInfo] = []
    plugins.extend(_discover_from_entry_points())
    plugins.extend(_discover_from_local_apps())
    return plugins


def generate_plugin_entry(
    entry_file: Path,
    plugins: Sequence[FrontendPluginInfo | tuple[str, Path]],
) -> None:
    """Generate temporary entry.tsx that imports all app plugins."""
    imports = []
    registrations = []

    for plugin in plugins:
        if isinstance(plugin, tuple):
            app_name, plugin_path = plugin
            source = "local"
            package_name = None
        else:
            app_name = plugin["name"]
            plugin_path = plugin["path"]
            source = plugin["source"]
            package_name = plugin["package"]

        import_name = app_name.replace("-", "_").replace(".", "_")

        if source == "installed":
            package_name = package_name or app_name
            imports.append(
                f'import {{ register as register_{import_name} }} from "@{package_name}/frontend";'
            )
        else:
            try:
                relative_path = plugin_path.relative_to(Path.cwd())
                imports.append(
                    f'import {{ register as register_{import_name} }} from "../../{relative_path}";'
                )
            except ValueError:
                imports.append(
                    f'import {{ register as register_{import_name} }} from "{plugin_path}";'
                )

        registrations.append(f"  register_{import_name}();")

    content = f"""// Auto-generated plugin entry
// DO NOT EDIT - regenerated on each build

{chr(10).join(imports)}

// Register all discovered plugins
export function registerAllPlugins() {{
{chr(10).join(registrations)}
}}

// Auto-register on import
registerAllPlugins();
"""
    entry_file.write_text(content)


def generate_vite_config(config_file: Path, plugins: list[FrontendPluginInfo]) -> None:
    """Generate Vite config with path aliases for installed packages."""
    aliases: dict[str, str] = {}

    for plugin in plugins:
        if plugin["source"] == "installed":
            package_name = plugin["package"] or plugin["name"]
            frontend_dir = plugin["path"].parent
            aliases[f"@{package_name}/frontend"] = str(frontend_dir)

    alias_entries = ",\n      ".join(
        [f'"{key}": "{value}"' for key, value in aliases.items()]
    )

    content = f"""// Auto-generated Vite config for multi-package composition
// DO NOT EDIT - regenerated on each build

import {{ defineConfig }} from 'vite';

export default defineConfig({{
  resolve: {{
    alias: {{
      {alias_entries}
    }}
  }},
  define: {{
    "process.env": {{}}
  }}
}});
"""
    config_file.write_text(content)


__all__ = [
    "FrontendPluginInfo",
    "discover_frontend_plugins",
    "generate_plugin_entry",
    "generate_vite_config",
]
