"""Shared shell subprocess utility."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from typing import Any


def run_cmd(
    cmd: str | list[str],
    cwd: str | Path | None = None,
    check: bool = True,
    dry_run: bool = False,
    env: dict[str, str] | None = None,
    capture_output: bool = True,
) -> str:
    """Run a shell command and return its output.

    Args:
        cmd: The shell command to run.
        cwd: The working directory for the command.
        check: If True, raises subprocess.CalledProcessError on non-zero exit.
        dry_run: If True, prints the command instead of executing it.
        env: Optional environment variables dictionary.
        capture_output: If True, captures stdout/stderr. If False, streams to console.

    Returns:
        The standard output of the command, stripped of whitespace.
        Returns an empty string if dry_run is True, or if check is False and command fails.
    """
    if dry_run:
        cmd_str = cmd if isinstance(cmd, str) else " ".join(cmd)
        print(f"[DRY RUN] Would execute: {cmd_str}")
        return ""

    shell = isinstance(cmd, str)
    kwargs: dict[str, Any] = {
        "shell": shell,
        "cwd": cwd,
        "check": False,
        "env": env,
    }

    if capture_output:
        kwargs["capture_output"] = True
        kwargs["text"] = True

    try:
        result = subprocess.run(cmd, **kwargs)
        if check and result.returncode != 0:
            cmd_str = cmd if isinstance(cmd, str) else " ".join(cmd)
            print(f"Error running command: {cmd_str}", file=sys.stderr)
            if capture_output:
                print(f"Stderr: {result.stderr}", file=sys.stderr)
            raise subprocess.CalledProcessError(
                result.returncode,
                cmd,
                output=getattr(result, "stdout", None),
                stderr=getattr(result, "stderr", None),
            )

        if capture_output and getattr(result, "stdout", None):
            return str(result.stdout).strip()
        return ""
    except subprocess.CalledProcessError:
        if check:
            raise
        return ""
