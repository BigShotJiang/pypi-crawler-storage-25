"""Studio API Routes - File System API.

This module provides the REST API for DocType file operations:
- GET /studio/api/doctypes - List all DocTypes in project
- GET /studio/api/doctype/{name} - Get DocType schema
- POST /studio/api/doctype/{name} - Create/update DocType
- DELETE /studio/api/doctype/{name} - Delete DocType
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, ClassVar
from urllib.parse import quote, urlparse

from litestar import Controller, delete, get, post
from litestar.exceptions import NotFoundException
from pydantic import BaseModel

from framework_m_studio.aggregate_builder import (
    AggregateRootBuilder,
    LinkedDocType,
)
from framework_m_studio.discovery import (
    doctype_to_dict,
    scan_doctypes,
)
from framework_m_studio.git.adapter import GitAdapter
from framework_m_studio.guardrail import GuardrailChecker, PublishGuard
from framework_m_studio.print_adapter import HotSwapMonitor, PrintRepoAdapter
from framework_m_studio.shell_plugin_config import (
    ActionButton,
    SearchProvider,
    ShellPluginConfig,
    SidebarApp,
)
from framework_m_studio.storage.file_adapter import FileAdapter
from framework_m_studio.storage.git_api_adapter import GitApiAdapter

# =============================================================================
# Request/Response Models
# =============================================================================


class ValidatorSchema(BaseModel):
    """Validator constraints for a field."""

    min_length: int | None = None
    max_length: int | None = None
    pattern: str | None = None
    min_value: float | None = None
    max_value: float | None = None


class FieldSchema(BaseModel):
    """Field definition for DocType creation/update."""

    name: str
    type: str
    label: str | None = None
    default: str | None = None
    required: bool = True
    description: str | None = None
    hidden: bool = False
    read_only: bool = False
    link_doctype: str | None = None  # For Link field type - which DocType to link to
    table_doctype: str | None = (
        None  # For Table field type - which DocType for child table
    )
    validators: ValidatorSchema | None = None


class DocTypeSchema(BaseModel):
    """DocType schema for creation/update."""

    name: str
    module: str | None = None
    docstring: str | None = None
    fields: list[FieldSchema] = []


class DocTypeListResponse(BaseModel):
    """Response for listing DocTypes."""

    doctypes: list[dict[str, Any]]
    count: int
    project_root: str


class DocTypeResponse(BaseModel):
    """Response for single DocType."""

    name: str
    module: str
    file_path: str
    docstring: str | None
    fields: list[dict[str, Any]]
    meta: dict[str, Any]


class CreateDocTypeRequest(BaseModel):
    """Request body for creating a DocType."""

    name: str
    app: str | None = None
    docstring: str | None = None
    fields: list[FieldSchema] = []


class MessageResponse(BaseModel):
    """Generic message response."""

    message: str
    file_path: str | None = None


class GuardrailCheckResponse(BaseModel):
    """Response for guardrail checks."""

    has_dangerous: bool
    can_publish: bool
    changes: list[dict[str, str]]


class PublishRequest(BaseModel):
    """Request body for a publish operation."""

    message: str
    author: str = "studio"
    acknowledged: bool = False
    doctype_payload: CreateDocTypeRequest | None = None


class PublishResponse(BaseModel):
    """Response for publish operations."""

    success: bool
    blocked: bool = False
    adapter_type: str
    branch: str | None = None
    commit_sha: str | None = None
    change_request_url: str | None = None
    error: str | None = None
    guardrail: GuardrailCheckResponse | None = None


class PrintLayoutListResponse(BaseModel):
    """Response for print layout listing."""

    doctype: str
    layouts: list[str]


class PrintLayoutRequest(BaseModel):
    """Request body for saving a print layout."""

    content: str


class PrintLayoutResponse(BaseModel):
    """Response for reading/saving print layout files."""

    doctype: str
    template_name: str
    content: str


class PrintPreviewRequest(BaseModel):
    """Request body for previewing a print template."""

    doctype: str
    template_name: str
    data: dict[str, Any] = {}


class PrintPreviewResponse(BaseModel):
    """Response for print preview rendering."""

    success: bool
    html: str = ""
    error: str | None = None


class HotSwapStatusResponse(BaseModel):
    """Current hot-swap monitor status."""

    watching: bool
    repo_path: str
    updates_received: int
    last_update_at: str | None = None


class HotSwapSyncResponse(BaseModel):
    """Response for hot-swap sync events."""

    success: bool
    message: str
    updates_received: int


class AggregateLinkSchema(BaseModel):
    """Schema for linked child DocTypes in aggregate config."""

    doctype: str
    link_field: str
    cascade: str = "save_delete"


class AggregateConfigRequest(BaseModel):
    """Request payload for aggregate root configuration."""

    linked: list[AggregateLinkSchema] = []


class AggregateConfigResponse(BaseModel):
    """Response payload for aggregate root configuration."""

    root: str
    linked: list[AggregateLinkSchema]


class AggregateRootsResponse(BaseModel):
    """Response payload for aggregate root listing."""

    roots: list[str]


class ActionButtonSchema(BaseModel):
    """Wire format for shell action buttons."""

    id: str
    label: str
    action: str
    target: str
    icon: str | None = None
    roles: list[str] = []


class SidebarAppSchema(BaseModel):
    """Wire format for shell sidebar apps."""

    id: str
    label: str
    icon: str
    route: str
    roles: list[str] = []


class SearchProviderSchema(BaseModel):
    """Wire format for shell search providers."""

    id: str
    label: str
    handler: str
    roles: list[str] = []


class ShellConfigRequest(BaseModel):
    """Request payload for shell plugin configurator."""

    action_buttons: list[ActionButtonSchema] = []
    sidebar_apps: list[SidebarAppSchema] = []
    search_providers: list[SearchProviderSchema] = []


class ShellConfigResponse(BaseModel):
    """Response payload for shell plugin configurator."""

    action_buttons: list[ActionButtonSchema]
    sidebar_apps: list[SidebarAppSchema]
    search_providers: list[SearchProviderSchema]


# =============================================================================
# Project Root Detection
# =============================================================================


def get_project_root() -> Path:
    """Get the project root directory.

    Priority:
    1. If CWD has src/doctypes directory, use CWD (local app mode)
    2. If CWD has doctypes directory, use CWD
    3. Look for pyproject.toml or .git in CWD only (don't traverse up)
    4. Fall back to CWD

    This ensures Studio scans only the current directory, not parent repos.
    """
    configured_root = os.environ.get("STUDIO_PROJECT_ROOT")
    if configured_root:
        explicit_root = Path(configured_root).expanduser().resolve()
        if explicit_root.exists():
            return explicit_root

    cwd = Path.cwd()

    # Priority 1: CWD has src/doctypes (standard app structure)
    if (cwd / "src" / "doctypes").exists():
        return cwd

    # Priority 2: CWD has doctypes directly
    if (cwd / "doctypes").exists():
        return cwd

    # Priority 3: CWD has project markers (don't traverse up!)
    if (cwd / "pyproject.toml").exists() or (cwd / ".git").exists():
        return cwd

    # Fall back to configured path
    return cwd


def _find_old_doctype_folder(project_root: Path, doctype_name: str) -> Path | None:
    """Find legacy folder path for a DocType when handling rename operations."""
    for doctype in scan_doctypes(project_root):
        if doctype.name != doctype_name:
            continue

        old_file = Path(doctype.file_path)
        expected_folder = _to_snake_case(doctype_name)
        if old_file.parent.name == expected_folder:
            return old_file.parent

        if old_file.exists():
            old_file.unlink()
        old_controller = old_file.parent / f"{old_file.stem}_controller.py"
        if old_controller.exists():
            old_controller.unlink()
        return None
    return None


def _detect_app_name(project_root: Path, explicit_app: str | None) -> str | None:
    """Resolve app name from request first, then from pyproject metadata."""
    if explicit_app:
        return explicit_app

    pyproject = project_root / "pyproject.toml"
    if not pyproject.exists():
        return None

    content = pyproject.read_text(encoding="utf-8")
    match = re.search(r'name\s*=\s*["\']([^"\']+)["\']', content)
    if not match:
        return None
    return match.group(1).replace("-", "_")


def _resolve_doctype_target_dir(project_root: Path, app_name: str | None) -> Path:
    """Resolve target root directory used for DocType package generation."""
    if app_name:
        namespace_dir = project_root / "src" / app_name / "doctypes"
        if namespace_dir.exists() or not (project_root / "src" / "doctypes").exists():
            return project_root / "src" / app_name
        return project_root / "src"

    target_dir = project_root / "src"
    return target_dir if target_dir.exists() else project_root


def _write_doctype_artifacts(
    doctype_folder: Path,
    class_name: str,
    schema: CreateDocTypeRequest,
    project_root: Path,
    folder_name: str,
) -> None:
    """Generate and write DocType package and tests to disk."""
    doctype_code = _generate_doctype_code(schema)
    (doctype_folder / "doctype.py").write_text(doctype_code, encoding="utf-8")

    controller_code = _generate_controller_code(class_name)
    (doctype_folder / "controller.py").write_text(controller_code, encoding="utf-8")

    init_code = _generate_init_code(class_name)
    (doctype_folder / "__init__.py").write_text(init_code, encoding="utf-8")

    test_code = _generate_test_code(class_name, folder_name)
    tests_dir = project_root / "tests" / "doctypes" / folder_name
    tests_dir.mkdir(parents=True, exist_ok=True)
    (tests_dir / f"test_{folder_name}.py").write_text(test_code, encoding="utf-8")


def _cleanup_renamed_doctype_paths(
    project_root: Path,
    old_name: str,
    old_folder_path: Path | None,
) -> None:
    """Delete old DocType and test folders after a successful rename."""
    if not old_folder_path or not old_folder_path.exists():
        return

    shutil.rmtree(old_folder_path)
    old_tests_dir = project_root / "tests" / "doctypes" / _to_snake_case(old_name)
    if old_tests_dir.exists():
        shutil.rmtree(old_tests_dir)


# =============================================================================
# File System API Controller
# =============================================================================


class DocTypeController(Controller):
    """Controller for DocType file system operations."""

    path = "/studio/api"
    tags: ClassVar[list[str]] = ["Studio - DocTypes"]  # type: ignore[misc]

    @get("/doctypes")
    async def list_doctypes(self) -> DocTypeListResponse:
        """List all DocTypes in the project.

        Scans the project for Python files containing DocType class definitions.
        """
        project_root = get_project_root()

        # Scan for DocTypes
        doctypes = scan_doctypes(project_root)

        return DocTypeListResponse(
            doctypes=[doctype_to_dict(dt) for dt in doctypes],
            count=len(doctypes),
            project_root=str(project_root),
        )

    @get("/doctype/{name:str}")
    async def get_doctype(self, name: str) -> DocTypeResponse:
        """Get a specific DocType by name.

        Args:
            name: DocType class name (e.g., "Todo", "User")
        """
        project_root = get_project_root()

        # Scan for DocTypes and find the matching one
        doctypes = scan_doctypes(project_root)

        for doctype in doctypes:
            if doctype.name == name:
                # Helper to clean validators
                def clean_validators(
                    validators: dict[str, Any],
                ) -> dict[str, Any] | None:
                    if not validators:
                        return None
                    # Remove None/empty values
                    cleaned = {k: v for k, v in validators.items() if v is not None}
                    return cleaned if cleaned else None

                return DocTypeResponse(
                    name=doctype.name,
                    module=doctype.module,
                    file_path=doctype.file_path,
                    docstring=doctype.docstring,
                    fields=[
                        {
                            "name": f.name,
                            "type": f.type,
                            "default": f.default,
                            "required": f.required,
                            "label": f.label,
                            "description": f.description,
                            "link_doctype": f.link_doctype,  # Include Link field metadata
                            "table_doctype": f.table_doctype,  # Include Table field metadata
                            "validators": clean_validators(f.validators),
                        }
                        for f in doctype.fields
                    ],
                    meta=doctype.meta,
                )

        raise NotFoundException(f"DocType '{name}' not found")

    @post("/doctype/{name:str}")
    async def create_or_update_doctype(
        self,
        name: str,
        data: CreateDocTypeRequest,
    ) -> MessageResponse:
        """Create or update a DocType.

        Creates a folder structure with:
        - doctype.py: DocType class definition
        - controller.py: Controller with lifecycle hooks
        - __init__.py: Package exports
        - test_<name>.py: Test file

        Args:
            name: Original DocType class name (from URL path)
            data: DocType schema including fields (data.name is the new name)
        """
        project_root = get_project_root()

        # Sanitize the DocType name for valid Python identifier
        # e.g., "Sales Invoice" -> class "SalesInvoice", folder "sales_invoice"
        sanitized_class_name = _sanitize_doctype_name(data.name)
        sanitized_folder_name = _to_snake_case(sanitized_class_name)

        # Update the data name to the sanitized version
        data.name = sanitized_class_name

        # Check if this is a rename operation
        is_rename = name != sanitized_class_name
        old_folder_path = (
            _find_old_doctype_folder(project_root, name) if is_rename else None
        )

        app_name = _detect_app_name(project_root, data.app)
        target_dir = _resolve_doctype_target_dir(project_root, app_name)

        # Create folder structure: src/<app>/doctypes/<name>/ (namespaced)
        doctype_folder = target_dir / "doctypes" / sanitized_folder_name
        doctype_folder.mkdir(parents=True, exist_ok=True)

        _write_doctype_artifacts(
            doctype_folder=doctype_folder,
            class_name=sanitized_class_name,
            schema=data,
            project_root=project_root,
            folder_name=sanitized_folder_name,
        )

        if is_rename:
            _cleanup_renamed_doctype_paths(
                project_root=project_root,
                old_name=name,
                old_folder_path=old_folder_path,
            )

        action = "renamed" if is_rename else "created"
        return MessageResponse(
            message=f"DocType '{sanitized_class_name}' {action} successfully",
            file_path=str(doctype_folder),
        )

    @delete("/doctype/{name:str}", status_code=200)
    async def delete_doctype(self, name: str) -> MessageResponse:
        """Delete a DocType directory and all its files.

        Args:
            name: DocType class name to delete
        """
        import shutil

        project_root = get_project_root()

        # Find the DocType file
        doctypes = scan_doctypes(project_root)

        for doctype in doctypes:
            if doctype.name == name:
                file_path = Path(doctype.file_path)
                doctype_dir = file_path.parent

                # Delete the entire DocType directory
                if doctype_dir.exists() and doctype_dir.is_dir():
                    shutil.rmtree(doctype_dir)

                    # Also delete the corresponding test directory
                    snake_name = _to_snake_case(name)
                    tests_dir = project_root / "tests" / "doctypes" / snake_name
                    if tests_dir.exists():
                        shutil.rmtree(tests_dir)

                    return MessageResponse(
                        message=f"DocType '{name}' deleted successfully",
                        file_path=str(doctype_dir),
                    )
                elif file_path.exists():
                    # Fallback: delete just the file if no directory
                    file_path.unlink()
                    return MessageResponse(
                        message=f"DocType '{name}' deleted successfully",
                        file_path=str(file_path),
                    )

        raise NotFoundException(f"DocType '{name}' not found")

    @post("/guardrail/check")
    async def guardrail_check(
        self, data: CreateDocTypeRequest
    ) -> GuardrailCheckResponse:
        """Check schema changes and report dangerous modifications.

        The check compares current on-disk DocType source against generated source
        for the submitted schema.
        """
        checker = GuardrailChecker()

        old_source = _load_existing_doctype_source(data.name)
        new_source = _generate_doctype_code(data)
        result = checker.check(old_source, new_source)

        return GuardrailCheckResponse(
            has_dangerous=result.has_dangerous,
            can_publish=result.can_publish,
            changes=result.changes,
        )

    @post("/publish")
    async def publish_changes(self, data: PublishRequest) -> PublishResponse:
        """Publish local Studio changes with optional guardrail acknowledgement."""
        guardrail_response: GuardrailCheckResponse | None = None

        if data.doctype_payload is not None:
            checker = GuardrailChecker()
            gate = PublishGuard()

            old_source = _load_existing_doctype_source(data.doctype_payload.name)
            new_source = _generate_doctype_code(data.doctype_payload)
            guardrail_result = checker.check(old_source, new_source)

            guardrail_response = GuardrailCheckResponse(
                has_dangerous=guardrail_result.has_dangerous,
                can_publish=guardrail_result.can_publish,
                changes=guardrail_result.changes,
            )

            if not gate.allow_publish(guardrail_result, acknowledged=data.acknowledged):
                return PublishResponse(
                    success=False,
                    blocked=True,
                    adapter_type="guardrail",
                    error="Dangerous schema changes require acknowledgement before publish.",
                    guardrail=guardrail_response,
                )

        project_root = get_project_root()

        # Local/indie mode fallback: no git repository detected.
        if not (project_root / ".git").exists():
            file_result = await FileAdapter(project_root).publish(
                message=data.message,
                author=data.author,
            )
            return PublishResponse(
                success=file_result.success,
                adapter_type=file_result.adapter_type,
                guardrail=guardrail_response,
            )

        remote_url = _get_remote_origin_url(project_root)
        if not remote_url:
            file_result = await FileAdapter(project_root).publish(
                message=data.message,
                author=data.author,
            )
            return PublishResponse(
                success=file_result.success,
                adapter_type=file_result.adapter_type,
                error="Git remote not configured; changes remain local.",
                guardrail=guardrail_response,
            )

        git_adapter = GitAdapter()
        storage = GitApiAdapter(
            git_adapter=git_adapter,
            workspace_path=project_root,
            repo_url=remote_url,
        )

        publish_result = await storage.publish(
            message=data.message,
            author=_normalize_author(data.author),
        )

        change_request_url = None
        if publish_result.success and publish_result.branch:
            change_request_url = _build_change_request_url(
                remote_url,
                publish_result.branch,
            )

        return PublishResponse(
            success=publish_result.success,
            adapter_type=publish_result.adapter_type,
            branch=publish_result.branch,
            commit_sha=publish_result.commit_sha,
            change_request_url=change_request_url,
            error=publish_result.error,
            guardrail=guardrail_response,
        )

    @get("/print/layouts/{doctype:str}")
    async def list_print_layouts(self, doctype: str) -> PrintLayoutListResponse:
        """List print templates for a DocType from the print repository."""
        adapter = _get_print_repo_adapter()
        layouts = adapter.list_layouts(doctype)
        return PrintLayoutListResponse(doctype=doctype, layouts=layouts)

    @get("/print/layout/{doctype:str}/{template_name:str}")
    async def get_print_layout(
        self,
        doctype: str,
        template_name: str,
    ) -> PrintLayoutResponse:
        """Read a print template file for Studio editing."""
        repo_path = _get_print_repo_path()
        target = repo_path / doctype / f"{template_name}.html"
        if not target.exists():
            raise NotFoundException(
                f"Print template '{template_name}' not found for '{doctype}'."
            )

        return PrintLayoutResponse(
            doctype=doctype,
            template_name=template_name,
            content=target.read_text(encoding="utf-8"),
        )

    @post("/print/layout/{doctype:str}/{template_name:str}")
    async def save_print_layout(
        self,
        doctype: str,
        template_name: str,
        data: PrintLayoutRequest,
    ) -> PrintLayoutResponse:
        """Save a print template in the print repository."""
        adapter = _get_print_repo_adapter()
        await adapter.save_layout(doctype, template_name, data.content)

        return PrintLayoutResponse(
            doctype=doctype,
            template_name=template_name,
            content=data.content,
        )

    @post("/print/preview")
    async def preview_print_layout(
        self,
        data: PrintPreviewRequest,
    ) -> PrintPreviewResponse:
        """Render a print layout preview with provided sample data."""
        adapter = _get_print_repo_adapter()
        result = await adapter.preview_with_sample(
            doctype=data.doctype,
            template_name=data.template_name,
            data=data.data,
        )
        return PrintPreviewResponse(
            success=result.success,
            html=result.html,
            error=result.error,
        )

    @get("/print/hotswap/status")
    async def print_hotswap_status(self) -> HotSwapStatusResponse:
        """Return hot-swap monitoring status for print repo integration."""
        monitor = _get_hot_swap_monitor()
        return HotSwapStatusResponse(
            watching=monitor.is_watching,
            repo_path=str(monitor.repo_path),
            updates_received=_HOT_SWAP_UPDATES,
            last_update_at=_HOT_SWAP_LAST_UPDATE,
        )

    @post("/print/hotswap/sync")
    async def print_hotswap_sync(self) -> HotSwapSyncResponse:
        """Trigger a hot-swap update event.

        This endpoint is intended for sidecars/GitOps controllers to notify
        the Framework M pod that updated print assets are available.
        """
        monitor = _get_hot_swap_monitor()
        if not monitor.is_watching:
            monitor.start()

        monitor.notify()

        return HotSwapSyncResponse(
            success=True,
            message="Print hot-swap sync event processed.",
            updates_received=_HOT_SWAP_UPDATES,
        )

    @get("/aggregate/roots")
    async def list_aggregate_roots(self) -> AggregateRootsResponse:
        """List configured aggregate roots."""
        builder = _get_aggregate_builder()
        return AggregateRootsResponse(roots=builder.list_roots())

    @get("/aggregate/config/{root:str}")
    async def get_aggregate_config(self, root: str) -> AggregateConfigResponse:
        """Get aggregate configuration for a root DocType."""
        builder = _get_aggregate_builder()
        data = builder.to_dict(root)
        if not data:
            return AggregateConfigResponse(root=root, linked=[])

        return AggregateConfigResponse(
            root=data["root"],
            linked=[AggregateLinkSchema(**item) for item in data["linked"]],
        )

    @post("/aggregate/config/{root:str}")
    async def save_aggregate_config(
        self,
        root: str,
        data: AggregateConfigRequest,
    ) -> AggregateConfigResponse:
        """Save aggregate root links and save-cascade configuration."""
        builder = _get_aggregate_builder()
        if root not in builder.list_roots():
            builder.define(root)

        config = builder.get_config(root)
        if config is not None:
            config.linked = []

        for linked in data.linked:
            builder.link(
                root,
                LinkedDocType(
                    doctype=linked.doctype,
                    link_field=linked.link_field,
                    cascade=linked.cascade,
                ),
            )

        _save_aggregate_builder(builder)

        saved = builder.to_dict(root)
        return AggregateConfigResponse(
            root=saved.get("root", root),
            linked=[AggregateLinkSchema(**item) for item in saved.get("linked", [])],
        )

    @get("/shell/config")
    async def get_shell_config(self, role: str | None = None) -> ShellConfigResponse:
        """Get shell plugin configuration, optionally filtered by role."""
        config = _get_shell_plugin_config()
        buttons = config.get_action_buttons(role=role)
        apps = config.get_sidebar_apps(role=role)
        providers = config.get_search_providers(role=role)

        return ShellConfigResponse(
            action_buttons=[
                ActionButtonSchema(**_action_button_to_dict(b)) for b in buttons
            ],
            sidebar_apps=[SidebarAppSchema(**_sidebar_app_to_dict(a)) for a in apps],
            search_providers=[
                SearchProviderSchema(**_search_provider_to_dict(p)) for p in providers
            ],
        )

    @post("/shell/config")
    async def save_shell_config(self, data: ShellConfigRequest) -> ShellConfigResponse:
        """Save shell plugin configuration (buttons, sidebar apps, providers)."""
        config = ShellPluginConfig()

        for button in data.action_buttons:
            config.register_action_button(ActionButton(**button.model_dump()))

        for app in data.sidebar_apps:
            config.register_sidebar_app(SidebarApp(**app.model_dump()))

        for provider in data.search_providers:
            config.register_search_provider(SearchProvider(**provider.model_dump()))

        _set_shell_plugin_config(config)
        _save_shell_plugin_config(config)

        return ShellConfigResponse(
            action_buttons=data.action_buttons,
            sidebar_apps=data.sidebar_apps,
            search_providers=data.search_providers,
        )


# =============================================================================
# Code Generation Helpers
# =============================================================================


def _sanitize_doctype_name(name: str) -> str:
    """Sanitize DocType name to be valid Python identifier.

    - Replace spaces with underscores
    - Remove all special characters except underscores
    - Convert to PascalCase

    Args:
        name: Raw DocType name (e.g., "Sales Invoice", "sales-order")

    Returns:
        Sanitized PascalCase name (e.g., "SalesInvoice", "SalesOrder")
    """
    # Replace hyphens and spaces with underscores first
    s = re.sub(r"[-\s]+", "_", name)

    # Remove any non-alphanumeric characters except underscores
    s = re.sub(r"\W", "", s)

    # Split by underscores and capitalize first letter of each word
    # Use word[0].upper() + word[1:] instead of capitalize() to preserve case
    parts = s.split("_")
    pascal = "".join((word[0].upper() + word[1:]) if word else "" for word in parts)

    return pascal or "DocType"


def _to_snake_case(name: str) -> str:
    """Convert PascalCase to snake_case."""
    import re

    s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
    return re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()


def _generate_doctype_code(schema: CreateDocTypeRequest) -> str:
    """Generate Python code for a DocType.

    Now uses the Jinja2 template system for consistent code generation.
    """
    from framework_m_studio.codegen.generator import generate_doctype_source

    # Convert CreateDocTypeRequest to dict format expected by generator
    schema_dict = {
        "name": schema.name,
        "docstring": schema.docstring,
        "fields": [
            {
                "name": f.name,
                "type": f.type,
                "required": f.required,
                "label": f.label,
                "default": f.default,
                "description": f.description,
                "link_doctype": f.link_doctype,  # Preserve Link field metadata
                "table_doctype": f.table_doctype,  # Preserve Table field metadata
                "validators": (
                    {
                        "min_length": f.validators.min_length,
                        "max_length": f.validators.max_length,
                        "pattern": f.validators.pattern,
                        "min_value": f.validators.min_value,
                        "max_value": f.validators.max_value,
                    }
                    if f.validators
                    else {}
                ),
            }
            for f in schema.fields
        ],
    }

    return str(generate_doctype_source(schema_dict))


_PRINT_REPO_ADAPTER: PrintRepoAdapter | None = None
_HOT_SWAP_MONITOR: HotSwapMonitor | None = None
_HOT_SWAP_UPDATES = 0
_HOT_SWAP_LAST_UPDATE: str | None = None
_AGGREGATE_BUILDER: AggregateRootBuilder | None = None
_SHELL_PLUGIN_CONFIG: ShellPluginConfig | None = None


def _get_print_repo_path() -> Path:
    """Resolve print repo path for Studio print builder."""
    import os

    configured = os.environ.get("STUDIO_PRINT_REPO_PATH")
    if configured:
        repo_path = Path(configured)
    else:
        repo_path = get_project_root() / ".studio" / "print_repo"

    repo_path.mkdir(parents=True, exist_ok=True)
    return repo_path


def _get_studio_state_dir() -> Path:
    """Return Studio state directory for persisted UI configurations."""
    state_dir = get_project_root() / ".studio"
    state_dir.mkdir(parents=True, exist_ok=True)
    return state_dir


def _get_print_repo_adapter() -> PrintRepoAdapter:
    """Return singleton print repo adapter instance."""
    global _PRINT_REPO_ADAPTER
    if _PRINT_REPO_ADAPTER is None:
        _PRINT_REPO_ADAPTER = PrintRepoAdapter(
            git_adapter=GitAdapter(),
            print_repo_path=_get_print_repo_path(),
        )
    return _PRINT_REPO_ADAPTER


def _on_print_hot_swap_update() -> None:
    """Track update events from hot-swap monitor."""
    global _HOT_SWAP_UPDATES, _HOT_SWAP_LAST_UPDATE
    _HOT_SWAP_UPDATES += 1
    _HOT_SWAP_LAST_UPDATE = datetime.now(UTC).isoformat()


def _get_hot_swap_monitor() -> HotSwapMonitor:
    """Return singleton hot-swap monitor configured for print repo."""
    global _HOT_SWAP_MONITOR
    if _HOT_SWAP_MONITOR is None:
        _HOT_SWAP_MONITOR = HotSwapMonitor(repo_path=_get_print_repo_path())
        _HOT_SWAP_MONITOR.on_update(_on_print_hot_swap_update)
        _HOT_SWAP_MONITOR.start()
    return _HOT_SWAP_MONITOR


def _aggregate_config_path() -> Path:
    """Path for persisted aggregate root configuration."""
    return _get_studio_state_dir() / "aggregate_roots.json"


def _get_aggregate_builder() -> AggregateRootBuilder:
    """Load aggregate builder from persisted config if available."""
    global _AGGREGATE_BUILDER
    if _AGGREGATE_BUILDER is not None:
        return _AGGREGATE_BUILDER

    builder = AggregateRootBuilder()
    path = _aggregate_config_path()
    if path.exists():
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            for item in payload.get("roots", []):
                root = item.get("root")
                if not root:
                    continue
                builder.define(root)
                for linked in item.get("linked", []):
                    builder.link(root, LinkedDocType(**linked))
        except Exception:
            # Keep Studio functional even if persisted config is malformed.
            pass

    _AGGREGATE_BUILDER = builder
    return builder


def _save_aggregate_builder(builder: AggregateRootBuilder) -> None:
    """Persist aggregate root builder state to disk."""
    data = {
        "roots": [builder.to_dict(root) for root in builder.list_roots()],
    }
    _aggregate_config_path().write_text(json.dumps(data, indent=2), encoding="utf-8")


def _shell_config_path() -> Path:
    """Path for persisted shell plugin configuration."""
    return _get_studio_state_dir() / "shell_plugin_config.json"


def _get_shell_plugin_config() -> ShellPluginConfig:
    """Load shell plugin configuration from disk."""
    global _SHELL_PLUGIN_CONFIG
    if _SHELL_PLUGIN_CONFIG is not None:
        return _SHELL_PLUGIN_CONFIG

    path = _shell_config_path()
    if path.exists():
        try:
            _SHELL_PLUGIN_CONFIG = ShellPluginConfig.load(path)
            return _SHELL_PLUGIN_CONFIG
        except Exception:
            pass

    _SHELL_PLUGIN_CONFIG = ShellPluginConfig()
    return _SHELL_PLUGIN_CONFIG


def _set_shell_plugin_config(config: ShellPluginConfig) -> None:
    """Set in-memory shell plugin configuration singleton."""
    global _SHELL_PLUGIN_CONFIG
    _SHELL_PLUGIN_CONFIG = config


def _save_shell_plugin_config(config: ShellPluginConfig) -> None:
    """Persist shell plugin configuration to disk."""
    config.save(_shell_config_path())


def _action_button_to_dict(button: ActionButton) -> dict[str, Any]:
    """Serialize action button to API response dict."""
    return {
        "id": button.id,
        "label": button.label,
        "action": button.action,
        "target": button.target,
        "icon": button.icon,
        "roles": button.roles,
    }


def _sidebar_app_to_dict(app: SidebarApp) -> dict[str, Any]:
    """Serialize sidebar app to API response dict."""
    return {
        "id": app.id,
        "label": app.label,
        "icon": app.icon,
        "route": app.route,
        "roles": app.roles,
    }


def _search_provider_to_dict(provider: SearchProvider) -> dict[str, Any]:
    """Serialize search provider to API response dict."""
    return {
        "id": provider.id,
        "label": provider.label,
        "handler": provider.handler,
        "roles": provider.roles,
    }


def _load_existing_doctype_source(name: str) -> str:
    """Load the existing DocType source, if present."""
    project_root = get_project_root()
    sanitized_name = _sanitize_doctype_name(name)

    for doctype in scan_doctypes(project_root):
        if doctype.name == sanitized_name:
            file_path = Path(doctype.file_path)
            if file_path.exists():
                return file_path.read_text(encoding="utf-8")
            break
    return ""


def _get_remote_origin_url(project_root: Path) -> str | None:
    """Return the repository origin URL when available."""
    try:
        result = subprocess.run(
            ["git", "-C", str(project_root), "remote", "get-url", "origin"],
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode != 0:
            return None
        url = result.stdout.strip()
        return url or None
    except OSError:
        return None


def _normalize_author(author: str) -> str:
    """Normalize author text to a git-compatible author format."""
    author = author.strip()
    if "<" in author and ">" in author:
        return author
    safe = author.replace(" ", "-").lower() or "studio"
    return f"{author} <{safe}@local>"


def _build_change_request_url(repo_url: str, branch: str) -> str | None:
    """Build a PR/MR creation URL for common providers."""
    normalized = repo_url
    if normalized.startswith("git@"):
        # git@github.com:owner/repo.git -> https://github.com/owner/repo
        host_path = normalized[4:]
        host, _, path = host_path.partition(":")
        normalized = f"https://{host}/{path}"

    if normalized.endswith(".git"):
        normalized = normalized[:-4]

    parsed = urlparse(normalized)
    if not parsed.scheme or not parsed.netloc:
        return None

    branch_q = quote(branch, safe="")

    if "github.com" in parsed.netloc:
        return f"{normalized}/compare/main...{branch_q}?expand=1"

    if "gitlab" in parsed.netloc:
        return (
            f"{normalized}/-/merge_requests/new"
            f"?merge_request%5Bsource_branch%5D={branch_q}"
            "&merge_request%5Btarget_branch%5D=main"
        )

    return None


def _generate_controller_code(name: str) -> str:
    """Generate Python code for a Controller.

    Args:
        name: The DocType class name (e.g., "Invoice")

    Returns:
        Generated controller Python code
    """
    doc_line = '        """'
    pass_line = "        pass"

    lines = [
        f'"""Controller for {name} DocType."""',
        "",
        "from __future__ import annotations",
        "",
        "from framework_m_core.domain.base_controller import BaseController",
        f"from .doctype import {name}",
        "",
        "",
        f"class {name}Controller(BaseController[{name}]):",
        f'    """Controller for {name} DocType.',
        "",
        "    Implement custom business logic here.",
        "",
        "    Lifecycle Hooks:",
        "        - validate: Called before save to validate data",
        "        - before_save: Called before persisting to database",
        "        - after_save: Called after successful save",
        "        - before_delete: Called before deleting a document",
        '    """',
        "",
        f"    doctype = {name}",
        "",
        f"    async def validate(self, doc: {name}) -> None:",
        '        """Validate document before saving.',
        "",
        "        Raise ValueError for validation errors.",
        "",
        "        Example:",
        "            if not doc.name:",
        '                raise ValueError("Name is required")',
        doc_line,
        pass_line,
        "",
        f"    async def before_save(self, doc: {name}) -> None:",
        '        """Called before saving a document.',
        "",
        "        Use for setting computed fields or timestamps.",
        doc_line,
        pass_line,
        "",
        f"    async def after_save(self, doc: {name}) -> None:",
        '        """Called after saving a document.',
        "",
        "        Use for side effects like sending notifications.",
        doc_line,
        pass_line,
        "",
        f"    async def before_delete(self, doc: {name}) -> None:",
        '        """Called before deleting a document.',
        "",
        "        Use for cleanup or validation before delete.",
        doc_line,
        pass_line,
        "",
    ]

    return "\n".join(lines)


def _generate_init_code(name: str) -> str:
    """Generate __init__.py code for a DocType package.

    Args:
        name: The DocType class name (e.g., "Invoice")

    Returns:
        Generated __init__.py Python code
    """
    return f'''"""{name} DocType package.

Auto-generated by Framework M Studio.
"""

from .controller import {name}Controller
from .doctype import {name}

__all__ = ["{name}", "{name}Controller"]
'''


def _generate_test_code(name: str, snake_name: str) -> str:
    """Generate test file code for a DocType.

    Args:
        name: The DocType class name (e.g., "Invoice")
        snake_name: Snake case name (e.g., "invoice")

    Returns:
        Generated test Python code
    """
    return f'''"""Tests for {name} DocType.

Auto-generated by Framework M Studio.
"""

from __future__ import annotations

import pytest

from .doctype import {name}


class Test{name}:
    """Tests for {name}."""

    def test_create_{snake_name}(self) -> None:
        """{name} should be creatable."""
        doc = {name}(name="test-001")
        assert doc.name == "test-001"

    def test_{snake_name}_doctype_name(self) -> None:
        """{name} should have correct class name."""
        assert {name}.__name__ == "{name}"
'''


__all__ = [
    "CreateDocTypeRequest",
    "DocTypeController",
    "DocTypeListResponse",
    "DocTypeResponse",
]
