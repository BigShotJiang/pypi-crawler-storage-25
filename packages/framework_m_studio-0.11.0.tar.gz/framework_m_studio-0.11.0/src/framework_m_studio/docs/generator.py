from pathlib import Path
from typing import Any

from framework_m_studio.docs.formatters import (
    generate_doctype_markdown,
    generate_index,
)
from framework_m_studio.docs.openapi import export_openapi_json


def generate_api_reference(
    doctypes: list[dict[str, Any]],
    output_dir: Path,
    project_root: Path | None = None,
) -> None:
    """Generate API reference documentation for all DocTypes.

    Args:
        doctypes: List of DocType info dictionaries.
        output_dir: Output directory for markdown files.
        project_root: The root of the project for creating relative paths. Defaults to CWD.
    """
    output_dir.mkdir(parents=True, exist_ok=True)

    doctype_names = []
    root = project_root or Path.cwd()

    # Sort doctypes by name for consistent output
    sorted_doctypes = sorted(doctypes, key=lambda dt: dt.get("name", "").lower())

    for dt in sorted_doctypes:
        name = dt.get("name", "Unknown")
        doctype_names.append(name)

        md_content = generate_doctype_markdown(dt, root)
        filename = name.lower() + ".md"
        (output_dir / filename).write_text(md_content)

    # Generate index.md
    index_md = generate_index(doctype_names)
    (output_dir / "index.md").write_text(index_md)


def generate_cli_reference(project_root: Path) -> str:
    """Generate CLI command reference from --help output."""
    from framework_m_studio.core.shell import run_cmd

    content = """# CLI Reference

> **Auto-generated from `m --help`** - Do not edit manually.

Framework M provides a CLI for common development tasks.

---

## Commands

"""

    try:
        import os

        env = os.environ.copy()
        env["NO_COLOR"] = "1"
        env["COLUMNS"] = "120"
        help_output = run_cmd(
            ["uv", "run", "m", "--help"],
            cwd=project_root,
            env=env,
        )
    except Exception as e:
        return content + f"*Error running CLI: {e}*"

    # Simple parsing: find lines that look like: │ command   Description │
    import re

    commands = []
    for line in help_output.split("\n"):
        if "│" in line:
            # Extract content between pipes
            parts = [p.strip() for p in line.split("│") if p.strip()]
            if len(parts) >= 1:
                cmd_part = parts[0]
                # If it's a command name (no dashes at start)
                if not cmd_part.startswith("-") and not cmd_part.lower().startswith(
                    "default"
                ):
                    # Split command and description if they are in the same cell
                    # or if they are in separate cells
                    match = re.match(r"^([a-z0-9:-]+)\s+(.+)$", cmd_part)
                    if match:
                        commands.append((match.group(1), match.group(2)))
                    elif len(parts) > 1:
                        commands.append((cmd_part, parts[1]))
                    else:
                        # Just command, maybe description in next cell?
                        commands.append((cmd_part, ""))

    content += "| Command | Description |\n"
    content += "| :--- | :--- |\n"

    unique_cmds = {}
    for cmd, desc in commands:
        if cmd not in unique_cmds:
            unique_cmds[cmd] = desc

    for cmd, desc in sorted(unique_cmds.items()):
        if cmd == "Commands":
            continue
        content += f"| `m {cmd}` | {desc} |\n"

    content += "\n---\n\n## Detailed Usage\n\n"

    # Get detailed help for each command
    for cmd in sorted(unique_cmds.keys()):
        if ":" in cmd:
            continue
        try:
            env["COLUMNS"] = "80"
            out = run_cmd(
                ["uv", "run", "m", cmd, "--help"],
                cwd=project_root,
                env=env,
            )
            if out:
                content += f"### `m {cmd}`\n\n"
                content += f"```text\n{out.strip()}\n```\n\n"
        except Exception:
            pass

    return content


def generate_field_types_doc() -> str:
    """Generate documentation of supported field types."""
    return r"""# Supported Field Types

> **Auto-generated from SchemaMapper** - Do not edit manually.

Framework M supports these Python types for DocType fields.

---

## Basic Types

| Python Type | SQLAlchemy Type | Description |
| :--- | :--- | :--- |
| `str` | `String` | Text field |
| `int` | `Integer` | Integer number |
| `float` | `Float` | Floating point number |
| `bool` | `Boolean` | True/False |
| `Decimal` | `Numeric` | Precise decimal (money) |

## Date/Time Types

| Python Type | SQLAlchemy Type | Description |
| :--- | :--- | :--- |
| `date` | `Date` | Date only |
| `datetime` | `DateTime(timezone=True)` | Date and time (UTC) |
| `time` | `Time` | Time only |

## Optional Types

| Python Type | Description |
| :--- | :--- |
| `str | None` | Optional text |
| `int | None` | Optional integer |

## Collection Types

| Python Type | Description |
|-------------|-------------|
| `list[str]` | List of strings (JSON) |
| `list[ChildDoc]` | Child table |
| `dict[str, Any]` | JSON object |

## Special Types

| Python Type | SQLAlchemy Type | Description |
|-------------|-----------------|-------------|
| `UUID` | `UUID` | Unique identifier |
| `bytes` | `LargeBinary` | Binary data |

---

## Field Options (Pydantic)

```python
from pydantic import Field

# Required field
name: str = Field(description="Name")

# Optional with default
status: str = Field(default="Draft", description="Status")

# Nullable optional
email: str | None = Field(default=None, description="Email")

# With constraints
quantity: int = Field(ge=0, le=1000, description="Quantity")
code: str = Field(min_length=3, max_length=20)
```
"""


def generate_api_endpoints_doc() -> str:
    """Generate documentation of API endpoints."""
    return """# API Endpoints

> **Auto-generated** - Do not edit manually.

Framework M exposes REST APIs for all DocTypes with `api_resource = True`.

---

## Resource API

Base URL: `/api/v1/resource/{DocType}`

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/{DocType}` | List records (paginated) |
| `GET` | `/{DocType}/{id}` | Get single record |
| `POST` | `/{DocType}` | Create record |
| `PUT` | `/{DocType}/{id}` | Update record |
| `DELETE` | `/{DocType}/{id}` | Delete record |

## Query Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `limit` | int | Max records (default: 20, max: 1000) |
| `offset` | int | Skip records |
| `order_by` | str | Sort field (prefix `-` for desc) |
| `filters` | JSON | Filter specs |

## Filter Format

```json
[
  {"field": "status", "operator": "eq", "value": "Active"},
  {"field": "amount", "operator": "gte", "value": 100}
]
```

## Operators

| Operator | Description |
|----------|-------------|
| `eq` | Equals |
| `ne` | Not equals |
| `gt` | Greater than |
| `gte` | Greater than or equal |
| `lt` | Less than |
| `lte` | Less than or equal |
| `like` | Contains (SQL LIKE) |
| `in` | In list |
| `is_null` | Is null |

## Meta API

| Endpoint | Description |
|----------|-------------|
| `GET /api/v1/meta/{DocType}` | Get DocType schema |

Returns JSON Schema for the DocType including:
- Field definitions
- Required fields
- Default values
- Validation rules
"""


def run_docs_generate(
    output: str = "./docs/api",
    project_root: str | Path | None = None,
    openapi_url: str | None = None,
) -> None:
    """Run the documentation generation process.

    Args:
        output: Output directory for the documentation.
        project_root: Root directory of the project to scan.
        openapi_url: Optional URL to fetch OpenAPI schema from.
    """
    from framework_m_studio.discovery import doctype_to_dict, scan_doctypes

    output_dir = Path(output)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Determine project root
    root = Path(project_root) if project_root else Path.cwd()

    # Scan for DocTypes
    doctypes = scan_doctypes(root)
    doctype_infos = [doctype_to_dict(dt) for dt in doctypes]

    # Generate individual API reference files
    generate_api_reference(doctype_infos, output_dir, root)

    print(f"📚 Generated documentation for {len(doctypes)} DocTypes")
    print(f"   Output: {output_dir}")

    # Export OpenAPI if URL provided
    if openapi_url:
        openapi_file = output_dir / "openapi.json"
        try:
            export_openapi_json(openapi_url, openapi_file)
            print(f"   OpenAPI: {openapi_file}")
        except Exception as e:
            print(f"   ⚠️  Failed to export OpenAPI: {e}")
