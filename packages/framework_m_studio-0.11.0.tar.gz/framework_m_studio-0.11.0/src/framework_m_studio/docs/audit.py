"""
Documentation Gap Audit.

Programmatically identify missing docstrings in DocTypes and Protocols.
"""

from __future__ import annotations

from pathlib import Path

from framework_m_studio.discovery import doctype_to_dict, scan_doctypes
from framework_m_studio.protocol_scanner import scan_protocols


def run_docs_audit(
    project_root: Path | None = None,
    protocols_dir: Path | None = None,
) -> bool:
    """Run the documentation gap audit.

    Args:
        project_root: Project root directory.
        protocols_dir: Directory containing Protocol interfaces.

    Returns:
        True if all documentation is present, False if there are gaps.
    """
    root = project_root or Path.cwd()

    if not protocols_dir:
        # Default to framework-m-core interfaces if in the monorepo
        protocols_dir = (
            root
            / "libs"
            / "framework-m-core"
            / "src"
            / "framework_m_core"
            / "interfaces"
        )

    print("🔍 Auditing documentation gaps...\n")
    has_gaps = False

    # 1. Audit DocTypes
    print("📋 Checking DocTypes...")
    doctypes = scan_doctypes(root)
    doctype_gaps = 0

    for dt in doctypes:
        dt_dict = doctype_to_dict(dt)
        if not dt_dict.get("docstring"):
            print(f"  ❌ {dt.name} is missing a description/docstring.")
            has_gaps = True
            doctype_gaps += 1

    if doctype_gaps == 0:
        print(f"  ✅ All {len(doctypes)} DocTypes are documented.")
    else:
        print(
            f"  ⚠️  {doctype_gaps}/{len(doctypes)} DocTypes are missing documentation."
        )

    print("\n🔌 Checking Protocols...")
    protocol_gaps = 0

    try:
        protocols = scan_protocols(protocols_dir)
    except (FileNotFoundError, OSError):
        protocols = []
        print(f"  ⏭️  Protocols directory not found: {protocols_dir}")

    for proto in protocols:
        proto_has_gap = False
        if not proto.get("docstring"):
            print(f"  ❌ Protocol '{proto['name']}' is missing a docstring.")
            proto_has_gap = True

        for method in proto.get("methods", []):
            if not method.get("docstring"):
                print(
                    f"  ❌ Protocol '{proto['name']}' method '{method['name']}' "
                    "is missing a docstring."
                )
                proto_has_gap = True

        if proto_has_gap:
            has_gaps = True
            protocol_gaps += 1

    total_protocols = len(protocols)
    if total_protocols > 0:
        if protocol_gaps == 0:
            print(f"  ✅ All {total_protocols} Protocols are fully documented.")
        else:
            print(
                f"  ⚠️  {protocol_gaps}/{total_protocols} Protocols have missing documentation."
            )

    print("\n📊 Audit Summary:")
    if has_gaps:
        print("  ❌ Documentation gaps found. Please add missing docstrings.")
        return False

    print("  ✅ 100% Documented! Great job.")
    return True
