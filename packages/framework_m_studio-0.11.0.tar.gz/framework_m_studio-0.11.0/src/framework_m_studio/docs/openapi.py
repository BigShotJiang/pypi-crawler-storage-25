"""OpenAPI Documentation Generators.

This module provides utilities to fetch OpenAPI schemas and generate
human-readable markdown documentation from them.
"""

import json
from pathlib import Path
from typing import Any
from urllib.request import Request, urlopen


def export_openapi_json(
    openapi_url: str,
    output_file: Path,
    *,
    timeout: int | None = 30,
) -> None:
    """Export OpenAPI JSON from a running app.

    Args:
        openapi_url: URL to fetch OpenAPI schema from.
        output_file: Output file path for JSON.
        timeout: Request timeout in seconds.
    """
    request = Request(openapi_url)
    request.add_header("Accept", "application/json")

    with urlopen(request, timeout=timeout) as response:  # nosec B310
        schema = json.loads(response.read().decode("utf-8"))

    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text(json.dumps(schema, indent=2))


def generate_openapi_markdown(
    schema: dict[str, Any],
    *,
    include_examples: bool = False,
) -> str:
    """Generate human-readable markdown from OpenAPI schema.

    Groups endpoints by tags and includes method, path, and summary.

    Args:
        schema: OpenAPI JSON schema dict
        include_examples: If True, include request/response examples

    Returns:
        Markdown string
    """
    info = schema.get("info", {})
    title = info.get("title", "API Reference")
    version = info.get("version", "")
    paths = schema.get("paths", {})

    lines = [f"# {title}"]
    if version:
        lines.append(f"\n**Version**: {version}")
    lines.append("")

    # Group endpoints by tag - now store full details if examples needed
    endpoints_by_tag: dict[str, list[dict[str, Any]]] = {}

    for path, methods in paths.items():
        for method, details in methods.items():
            if method in ("get", "post", "put", "patch", "delete"):
                summary = details.get("summary", details.get("operationId", ""))
                tags = details.get("tags", ["Other"])
                for tag in tags:
                    if tag not in endpoints_by_tag:
                        endpoints_by_tag[tag] = []
                    endpoints_by_tag[tag].append(
                        {
                            "method": method.upper(),
                            "path": path,
                            "summary": summary,
                            "details": details if include_examples else {},
                        }
                    )

    # Generate sections by tag
    for tag in sorted(endpoints_by_tag.keys()):
        lines.extend([f"## {tag}", ""])

        lines.extend(
            ["| Method | Path | Description |", "|--------|------|-------------|"]
        )

        for endpoint in endpoints_by_tag[tag]:
            lines.append(
                f"| {endpoint['method']} | `{endpoint['path']}` | {endpoint['summary']} |"
            )

        lines.append("")

        # Include examples if requested
        if include_examples:
            for endpoint in endpoints_by_tag[tag]:
                details = endpoint.get("details", {})

                # Request example
                request_body = details.get("requestBody", {})
                if request_body:
                    content = request_body.get("content", {})
                    json_content = content.get("application/json", {})
                    example = json_content.get("example")
                    if example:
                        lines.append(
                            f"### {endpoint['method']} {endpoint['path']} - Request"
                        )
                        lines.append("")
                        lines.append("```json")
                        lines.append(json.dumps(example, indent=2))
                        lines.append("```")
                        lines.append("")

                # Response example
                responses = details.get("responses", {})
                for status_code, response in responses.items():
                    content = response.get("content", {})
                    json_content = content.get("application/json", {})
                    example = json_content.get("example")
                    if example:
                        lines.append(
                            f"### {endpoint['method']} {endpoint['path']} - Response ({status_code})"
                        )
                        lines.append("")
                        lines.append("```json")
                        lines.append(json.dumps(example, indent=2))
                        lines.append("```")
                        lines.append("")

    return "\n".join(lines)
