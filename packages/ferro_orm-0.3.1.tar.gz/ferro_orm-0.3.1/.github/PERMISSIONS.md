# GitHub Actions Workflow Permissions

This document explains the fine-grained permissions used by each workflow in this repository.

## Overview

All workflows use explicit, fine-grained permissions (principle of least privilege). Each workflow only requests the permissions it needs to function.

**Repository Setting:** The repository-level "Workflow permissions" setting can remain at the default (read-only). Each workflow explicitly declares its required permissions.

---

## Workflow Permissions Breakdown

### 0. CI - Continuous Integration (`ci.yml`)

**Trigger:** Pull requests, push to `main`, manual dispatch

**Permissions:**
```yaml
# No explicit permissions needed
# Uses default read-only permissions
```

**Why These Permissions:**
- Default `contents: read` - Allows the workflow to:
  - Checkout code
  - Read repository contents
  - Run tests and linters
  - No write access needed

**What It Does:**
- Runs all pre-commit hooks (Ruff, rustfmt, clippy, file checks)
- Runs pytest with coverage on multiple Python versions
- Runs Rust tests
- Builds package on multiple platforms
- Checks conventional commit format on PRs
- Uploads coverage to Codecov

**Security:** Read-only access ensures CI cannot modify the repository.

---

### 1. Release (`release.yml`)

**Trigger:** Manual workflow dispatch

**Job graph (top to bottom is execution order):**

```
ci-gate        packaging-smoke
        \      /
      prepare-release                 (computes bump, writes release.patch; no pushes)
     /    |    |    \
build-wheels build-sdist test-wheels verify-docs
                  \    |    /
                promote-pypi           (PyPI Trusted Publishing; first irreversible step)
                      |
                 promote-git           (commit bump, push main, tag, create GH Release + assets)
                      |
                 promote-docs          (deploys MkDocs site pinned to the new tag)
```

Nothing is pushed, tagged, or published until every validation job above
`promote-pypi` has succeeded. PyPI is published first so that if anything
fails, `main` is never advanced to an "orphan" version.

**Permissions (prepare-release):**
```yaml
permissions:
  contents: read
  issues: read
  pull-requests: read
```

Prepare-release only needs read access because it just computes the bump and uploads a patch artifact — it does not push anything.

**Permissions (promote-git):**
```yaml
permissions:
  contents: write
  issues: write
  pull-requests: write
```

- `contents: write` - Allows the job to:
  - Commit version bumps to `pyproject.toml` and `Cargo.toml`
  - Push commits to the `main` branch
  - Create and push git tags (e.g., `v0.3.1`)
  - Create GitHub Releases

- `issues: write` / `pull-requests: write` - Allows semantic-release to
  update issue/PR references in generated release notes.

**What the release flow does:**
- Analyzes conventional commits since the latest tag (fetched explicitly via `fetch-tags: true`)
- Fails fast if the computed version collides with an existing tag (indicates a tag-fetch bug)
- Bumps version in `pyproject.toml` and `Cargo.toml` and finalizes `CHANGELOG.md`
- Validates the bumped tree across wheel builds, sdist, install smoke tests, and `mkdocs build`
- Publishes to PyPI before touching `main`
- Commits bump to `main`, creates the tag, creates the GitHub Release with generated notes, attaches wheels + sdist
- Deploys the MkDocs site pinned to the new tag

**Required Secrets:**
- `RELEASE_DEPLOY_KEY` (private SSH key for a write-enabled deploy key)
- `RELEASE_TOKEN` (recommended PAT for release API actions and downstream workflow triggering, falls back to `GITHUB_TOKEN`)

---

### 2. Build & Publish (jobs in `release.yml`)

**Trigger:** Part of `release.yml` — all build and publish jobs live in the same workflow file.

Build, test, and publish jobs are defined directly in `release.yml` so PyPI Trusted Publishing receives a token with `workflow_ref: release.yml` (reusable workflows are not supported by PyPI).

**Permissions:**

**For build-wheels, build-sdist, test-wheels, verify-docs:** (default - read-only)

**For promote-pypi job:**
```yaml
permissions:
  id-token: write
```

**Why These Permissions:**
- `id-token: write` - Allows the job to request an OIDC token and authenticate with PyPI using Trusted Publishing.

**What It Does:**
- Builds wheels for multiple platforms against the patched (bumped) tree
- Builds source distribution against the patched tree
- Installs wheels and runs a smoke import + in-memory SQLite check
- `promote-pypi` publishes the validated wheels + sdist to PyPI via OIDC

---

### 3. Publish Docs (`publish-docs.yml`)

**Trigger:** Workflow call from `release.yml`

**Permissions:**
```yaml
permissions:
  contents: read
```

**For deploy-docs job:**
```yaml
permissions:
  pages: write
  id-token: write
```

**Why These Permissions:**
- `pages: write` - Allows the workflow to:
  - Deploy the generated MkDocs static site to GitHub Pages
  - Update the Pages deployment for the repository
- `id-token: write` - Allows secure OIDC auth for Pages deployment

**What It Does:**
- Builds MkDocs docs
- Deploys docs to GitHub Pages

---

## Permission Scopes Explained

### `contents: write`
Full access to repository contents, including:
- Committing files
- Pushing to branches
- Creating/deleting tags
- Creating releases

### `contents: read` (default)
Read-only access to repository contents:
- Cloning/checking out code
- Reading files
- Listing branches and tags

### `issues: write`
Permission to modify issues:
- Create, edit, close issues
- Add labels and assignees
- Add comments

### `pull-requests: write`
Permission to modify pull requests:
- Create, edit, close PRs
- Add labels and assignees
- Add comments
- Request reviewers

### `id-token: write`
Permission to request OIDC tokens:
- Get JWT token from GitHub
- Authenticate with external services (PyPI)
- No access to repository contents

### `pages: write`
Permission to manage GitHub Pages deployments:
- Create and update Pages deployments
- Publish static site artifacts to Pages

---

## Security Best Practices

### ✅ Current Setup (Secure)

1. **Principle of Least Privilege**
   - Each workflow only requests permissions it needs
   - No workflows have more permissions than necessary

2. **Explicit Permissions**
   - All permissions are declared in workflow files
   - Easy to audit and review

3. **OIDC Authentication**
   - No long-lived API tokens
   - Tokens expire automatically
   - Tokens are tied to specific workflows

4. **Environment Protection** (publish workflow)
   - Uses `pypi` environment
   - Can require manual approval
   - Additional security layer

### ❌ What We're NOT Doing (Good!)

1. **Not using repository-wide write permissions**
   - Would give all workflows unnecessary access
   - Higher security risk

2. **Not using API tokens**
   - No secrets to manage
   - No token rotation needed

3. **Not granting `packages: write`**
   - Not needed for our use case
   - Reduces attack surface

---

## Troubleshooting

### Workflow Fails with "Permission Denied"

**Check:**
1. Permissions are declared in the workflow file
2. Organization doesn't block fine-grained permissions
3. Branch protection rules allow workflow commits

**Solution:**
- Verify the `permissions:` block exists in the workflow
- Check organization settings allow workflow permissions
- Add `permissions: {}` explicitly to override org defaults

### "Resource not accessible by integration"

**Cause:** Workflow trying to access resource without permission

**Solution:**
- Add the required permission to the workflow's `permissions:` block
- Common missing permissions:
  - `contents: write` for commits/tags
  - `pull-requests: write` for PR comments
  - `issues: write` for issue comments

### Release Completed But Publish/Docs Did Not Run

**Cause:** `release.yml` gates downstream jobs. If CI, packaging smoke, or release creation fails, publish/docs are skipped.

**Solution:**
- Open the failed `release.yml` run and inspect the first failed job.
- Re-run `release.yml` after fixing the upstream failure.

### Release Fails to Push to `main` with GH013 Ruleset Error

**Cause:** Repository rules require pull requests for `main`, and the release actor is not allowed to bypass.

**Solution:**
- Ensure the workflow uses the `RELEASE_DEPLOY_KEY` secret (configured in `release.yml`).
- In repo rulesets for `main`, add the deploy key actor (or your release bot user) to bypass "Changes must be made through a pull request".
- Re-run the Release workflow.

### PyPI Publishing Fails with Authentication Error

**Cause:** Missing `id-token: write` permission

**Solution:**
- Ensure `promote-pypi` job has `id-token: write`
- Verify PyPI trusted publisher is configured correctly
- Check environment name matches (`pypi`)

### Release says "0.3.0 has already been released!" for a version that was already shipped

**Cause:** `actions/checkout@v4` runs `git fetch --no-tags` by default, even with `fetch-depth: 0`. Without tags, `semantic-release` picks an older baseline tag, computes a minor/patch bump, and lands on the same version number as a prior release.

**Solution:**
- The `prepare-release` job sets `fetch-tags: true` on its checkout step and then runs a `git describe` vs `semantic-release --print-last-released-tag` comparison as a guard. Both must be present.
- If this check fails in a run, confirm no one has removed `fetch-tags: true` from the checkout step.

---

## Verification

To verify permissions are working:

### Test Release
```bash
gh workflow run release.yml
# Check that version files are updated and tagged
```

### Test Publish
```bash
# Triggered by release.yml after a successful release
gh run list --workflow=release.yml
```

---

## GitHub Organization Settings

**If fine-grained permissions are blocked:**

1. Go to: https://github.com/organizations/syn54x/settings/actions
2. Under "Workflow permissions":
   - Enable "Read and write permissions" OR
   - Enable "Allow workflows to request permissions explicitly"
3. Save changes

**Current Status:** ✅ All workflows use explicit permissions and should work regardless of org defaults.

---

## Additional Resources

- [GitHub Actions Permissions](https://docs.github.com/en/actions/security-guides/automatic-token-authentication#permissions-for-the-github_token)
- [PyPI Trusted Publishing](https://docs.pypi.org/trusted-publishers/)
- [OIDC in GitHub Actions](https://docs.github.com/en/actions/deployment/security-hardening-your-deployments/about-security-hardening-with-openid-connect)

---

**Last Updated:** 2026-02-13
**Status:** ✅ All workflows properly configured with fine-grained permissions
