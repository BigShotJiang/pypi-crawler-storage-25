# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.3.0] - 2026-05-17

### Added
- `AzureDevOpsServerAdapter` — read-side adapter for Azure DevOps Server
  (releases 2022 / 2020 / 2019 Update 1+ / 2019 RTW; REST 7.0 / 6.0 / 5.1 / 5.0).
  Same method-by-method contract as `AzureDevOpsCloudAdapter`; a programmatic
  parity test asserts the two adapters expose identical public method
  surfaces. Lifted from `ado2gh-core` @ `160de58`.
- `ADOServerClient` — single-host, collection-aware HTTP client with
  auto-discovered REST api-version via the new `api_version_discovery`
  module. `connectionData` probe runs first; falls back to candidate
  iteration over `("7.0", "6.0", "5.1", "5.0")`. Soft-capability probes
  (Graph / Analytics / Package Management) run in parallel and populate
  `SourceCapabilities` flags.
- `BaseADOClient` — abstract base extracted from the existing
  `ADOClient`, sharing the retry / rate-limit / error-mapping loop with
  the new server client.
- `api_version_discovery` module with `SERVER_API_VERSION_CANDIDATES`,
  `ServerProbeResult` (frozen dataclass), and `resolve_server_api_version`.
- `UnsupportedOnAzureDevOpsServerError` typed exception raised when
  capability-gated server-adapter methods hit a missing on-prem
  extension. Carries `capability`, required `api_version`, and optional
  `remediation` for downstream discovery-report consumers.
- `SourceCapabilities.server_default(api_version=...)` factory + new
  soft-capability flags `supports_graph_api`, `supports_analytics_odata`,
  `supports_artifact_feeds`, plus `with_overrides()` for applying probe
  results (whitelist enforced via the new
  `SourceCapabilities.OVERRIDABLE_SOFT_CAPABILITY_KEYS` ClassVar — only
  soft-cap flags are overridable).
- Server integration smoke suite (`tests/integration/test_smoke_server.py`)
  gated on `ADO_SERVER_URL` / `ADO_SERVER_PAT` (and optional
  `ADO_SERVER_COLLECTION`, defaulting to `DefaultCollection`; optional
  `ADO_SERVER_VERIFY_SSL=false` for self-signed lab installs, or a path
  to a CA bundle). Co-exists with the cloud smoke suite under the same
  `integration` marker; each suite gates on its own env-var set, so
  `pytest -m integration` runs whichever has credentials populated.
  Verified end-to-end against a real Azure DevOps Server 2025 instance.

### Changed
- **BREAKING (0.x):** `SourceCapabilities.supports_packages` removed in
  favor of `supports_artifact_feeds`. Functionally equivalent — same
  boolean semantics; renamed for on-prem clarity. Migration: rename
  `caps.supports_packages` reads to `caps.supports_artifact_feeds`.
- The transport class hierarchy was reshaped: `ADOClient` is now a
  module-level alias for the renamed `ADOCloudClient` (extracted from
  the new abstract `BaseADOClient`). Existing imports keep working.
  **Reflection-derived class names change:** `type(client).__name__`
  now returns `"ADOCloudClient"` instead of `"ADOClient"` — telemetry,
  metrics labels, log scrapers, or pickled class metadata that key on
  the old name need to be updated.
- `pagination.py` type annotations migrate from `ADOClient` to
  `BaseADOClient` so the helpers type-check cleanly with both subclasses.
  No runtime change.
- Integration test marker description in `pyproject.toml` updated to
  mention both cloud and server env-var sets.

## [0.2.0] - 2026-05-04

### Added
- ADOClient-aware paginators (#14): `paginate_via_adoclient_continuation_token`,
  `paginate_via_adoclient_skip_top`, and `paginate_via_adoclient_body_continuation_token`.
  These preserve `ADOClient.request`'s retry / rate-limit / error-mapping behavior
  while iterating paged ADO endpoints, so adapter methods can delegate to one-line
  helpers without losing transport guarantees.
- `ADOCredentialSettings` Pydantic Settings class plus the data-layer credential
  resolver (`resolve_ado_credentials`, `parse_env_file`, and supporting helpers)
  in `ado_source_core.auth` (#15). Lifted from `ado2gh-core` per audit §3.B + §3.D
  so downstream consumers (notably the upcoming `ado-scanner`) can build a
  complete credential pipeline without re-implementing the env-resolution rules.
- `pydantic-settings>=2,<3` runtime dependency (required by `ADOCredentialSettings`).

### Changed
- `AzureDevOpsCloudAdapter` paged read methods (`list_projects`, `count_branches`,
  `count_pull_requests`, and the remaining hand-rolled loops in PR-B2) now delegate
  to the new ADOClient-aware paginators (#14). Public API and behavior unchanged;
  retry / rate-limit / error-mapping guarantees preserved.

### Fixed
- Forward-backported three hardenings from `migration-core` PR #7 into
  `ado_source_core.client` (#13), keeping the two libraries' helper code in sync:
  - `_parse_retry_after` clamps negative numeric `Retry-After` values to `0.0` so
    misbehaving servers cannot crash the retry loop on `time.sleep(-1)`.
  - `_extract_response_body` tolerates `httpx.ResponseNotRead` so `APIError`
    construction never raises when called on an unread streaming response.
  - `RESPONSE_BODY_MAX_BYTES` docstring clarifies the slicing unit is characters
    (Python string slicing), not bytes; constant name preserved for drop-in import
    parity with `migration-core`.

## [0.1.0] - 2026-04-29

### Added
- Initial release of `ado-source-core`: read-only Azure DevOps source adapter
  library extracted from `ado2gh-core` per Stage 1 sub-stage 1.1 of the Shyftport
  pilot extraction.
- `ADOClient` async HTTP transport spanning the six ADO hosts (`dev`, `vsrm`,
  `feeds`, `analytics`, `vssps`, `vsaex`) with PAT Basic auth, retry,
  rate-limit handling, tolerant `Retry-After` parser, and error mapping.
- `AzureDevOpsCloudAdapter` implementing `SourceAdapter[Repository, User]` with
  read-side methods for projects, repositories, branches, pull requests, LFS
  detection, large-file analysis, file content, build/release definitions,
  service connections, variable groups, environments, work-item counts,
  classification nodes, custom fields, artifact feeds, test plans, branch
  policies, TFVC changesets, user entitlements, and users.
- `PATAuth` Personal Access Token helper (Basic auth) with redacted `repr` / `str`.
- Pagination helpers: `paginate_continuation_token` and `paginate_skip_top`
  (raw `httpx.AsyncClient` iterators; the ADOClient-aware variants ship in 0.2.0).
- Pydantic models for `Repository`, `User`, `UserEntitlementSummary`,
  `SourceCapabilities`, `SourceType`, `ArtifactFeedInventoryItem`, `BoardSummary`,
  `Pipeline*`, `TestPlanInventoryItem`, `TfvcSummary`, `Inventory` (and
  `InventoryMetadata`, `InventorySummary`, `ProjectInventoryItem`,
  `RepositoryInventoryItem`, `LFSInfo`, `LargeFileInfo`, `ComplexityLevel`,
  `ComplexityScore`).
- Exception hierarchy: `ADOSourceCoreError`, `ConfigError`, `APIError`,
  `AuthenticationError`, `RateLimitError`, plus the `ExitCode` enum.
- Integration smoke-test suite (gated on `ADO_ORG`/`ADO_PAT` env vars). The
  suite surfaced and fixed a Graph API regression where `list_users` was
  sending `api-version=7.1` instead of the required `7.1-preview.1`.
- CI matrix on Python 3.11 / 3.12 / 3.13 (ruff, ruff format, mypy strict,
  pytest) and tag-driven PyPI release workflow via Trusted Publisher (OIDC).

[Unreleased]: https://github.com/n8group-oss/ado-source-core/compare/v0.3.0...HEAD
[0.3.0]: https://github.com/n8group-oss/ado-source-core/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/n8group-oss/ado-source-core/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/n8group-oss/ado-source-core/releases/tag/v0.1.0
