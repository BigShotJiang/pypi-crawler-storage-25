# ADOCredentialSettings + Credential Resolver Lift — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Lift `ADOCredentialSettings` (Pydantic Settings) plus the data-layer half of `ado2gh-core/src/ado2gh/cli/credential_resolver.py` into `ado_source_core.auth`, completing audit §3.B + §3.D.

**Architecture:** Append to existing `auth.py` — keep `PATAuth` untouched at the top, add settings + helpers + `resolve_ado_credentials` below. Drop scanner-specific UX (`prefer_scanner_aliases`, `_SCANNER_*` constants) per audit §3.D; that logic moves to `ado-scanner`'s wrapper. New public symbols (`ADOCredentialSettings`, `DEFAULT_ADO_BASE_URL`, `parse_env_file`, `resolve_ado_credentials`) get exported from `ado_source_core.__init__`. New dep: `pydantic-settings>=2,<3`.

**Tech Stack:** Python 3.11+, Pydantic v2, pydantic-settings v2, pytest, respx (already), monkeypatch.

**Donor:** `n8group-oss/ado2gh-core` @ `160de58`. Donor files: `src/ado2gh/models/config.py`, `src/ado2gh/cli/credential_resolver.py`.

**Spec:** `docs/superpowers/specs/2026-04-30-ado-credential-settings-lift-design.md`.

---

## File map

| File | Type | Responsibility |
|---|---|---|
| `pyproject.toml` | Modify | Add `pydantic-settings>=2,<3` to `[project] dependencies`. |
| `src/ado_source_core/auth.py` | Append | Existing `PATAuth` untouched; append constants, `ADOCredentialSettings`, private helpers, `resolve_ado_credentials`. Update module docstring. |
| `src/ado_source_core/__init__.py` | Modify | Add 4 new public symbols to imports + `__all__` (alphabetical). |
| `tests/unit/test_auth_settings.py` | Create | New file. Cover settings, parser, helpers, resolver. Existing `test_auth.py` (PATAuth) stays. |

---

### Task 1: Add `pydantic-settings` dependency

**Files:**
- Modify: `pyproject.toml`

- [ ] **Step 1: Edit pyproject.toml**

In the `[project] dependencies` block, append `pydantic-settings>=2,<3`:

```toml
dependencies = [
    "httpx>=0.27,<1.0",
    "pydantic>=2.7,<3.0",
    "pydantic-settings>=2,<3",
    "structlog>=24,<26",
]
```

(Keep alphabetical ordering by package name.)

- [ ] **Step 2: Reinstall the hatch env**

Run: `cd ~/projects/n8group-oss/ado-source-core/.worktrees/credential-settings && hatch run pip install -e ".[dev]"`
Expected: `Successfully installed ... pydantic-settings-2.x.x ...`

- [ ] **Step 3: Verify the existing test suite still passes**

Run: `hatch run test`
Expected: `187 passed, 5 deselected` (no regressions from adding the dep).

- [ ] **Step 4: Commit**

```bash
git add pyproject.toml
git commit -m "chore(deps): add pydantic-settings>=2,<3

Required by ADOCredentialSettings (audit §3.B) lifted in the next commit."
```

---

### Task 2: Test `ADOCredentialSettings` (TDD red)

**Files:**
- Create: `tests/unit/test_auth_settings.py`

- [ ] **Step 1: Write the file scaffold + first failing test**

Create `tests/unit/test_auth_settings.py`:

```python
"""Tests for ADOCredentialSettings + credential resolver helpers (audit §3.B + §3.D)."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

from ado_source_core.auth import ADOCredentialSettings


@pytest.fixture(autouse=True)
def _clear_ado_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Strip every ADO_* / ADO2GH_* var from env so each test starts clean."""
    for key in list(monkeypatch.delenv.__self__.environ):  # type: ignore[attr-defined]
        if key.startswith(("ADO_", "ADO2GH_")):
            monkeypatch.delenv(key, raising=False)


class TestADOCredentialSettingsDefaults:
    def test_all_fields_default_to_none(self) -> None:
        settings = ADOCredentialSettings()
        assert settings.ado_pat is None
        assert settings.ado_organization is None


class TestADOCredentialSettingsAliases:
    def test_ado_pat_alias(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("ADO_PAT", "primary")
        settings = ADOCredentialSettings()
        assert settings.ado_pat is not None
        assert settings.ado_pat.get_secret_value() == "primary"

    def test_ado2gh_pat_alias(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("ADO2GH_PAT", "fallback")
        settings = ADOCredentialSettings()
        assert settings.ado_pat is not None
        assert settings.ado_pat.get_secret_value() == "fallback"

    def test_ado_pat_takes_precedence_over_ado2gh_pat(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("ADO_PAT", "primary")
        monkeypatch.setenv("ADO2GH_PAT", "fallback")
        settings = ADOCredentialSettings()
        assert settings.ado_pat is not None
        assert settings.ado_pat.get_secret_value() == "primary"

    def test_ado_organization_alias(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("ADO_ORGANIZATION", "myorg")
        settings = ADOCredentialSettings()
        assert settings.ado_organization == "myorg"

    def test_ado2gh_organization_alias(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("ADO2GH_ORGANIZATION", "myorg-fallback")
        settings = ADOCredentialSettings()
        assert settings.ado_organization == "myorg-fallback"


class TestADOCredentialSettingsSecretMasking:
    def test_repr_does_not_leak_pat(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("ADO_PAT", "super-secret-pat-value")
        settings = ADOCredentialSettings()
        assert "super-secret-pat-value" not in repr(settings)
        assert "super-secret-pat-value" not in str(settings)
```

The autouse fixture's `monkeypatch.delenv.__self__.environ` is a quirky-but-working way to introspect monkeypatch — replace with a cleaner pattern in implementation if needed. (Implementation note: replace with explicit list of keys to clear: `for key in ("ADO_PAT", "ADO2GH_PAT", "ADO_ORGANIZATION", "ADO2GH_ORGANIZATION"): monkeypatch.delenv(key, raising=False)`.)

- [ ] **Step 2: Run tests to verify they fail**

Run: `hatch run test tests/unit/test_auth_settings.py -v`
Expected: `ImportError` / collection error — `ADOCredentialSettings` is not importable yet.

- [ ] **Step 3: Refactor the autouse fixture**

Replace the fragile fixture with:

```python
_ADO_ENV_KEYS = (
    "ADO_PAT",
    "ADO2GH_PAT",
    "ADO_ORGANIZATION",
    "ADO2GH_ORGANIZATION",
)


@pytest.fixture(autouse=True)
def _clear_ado_env(monkeypatch: pytest.MonkeyPatch) -> None:
    for key in _ADO_ENV_KEYS:
        monkeypatch.delenv(key, raising=False)
```

- [ ] **Step 4: Commit (red)**

```bash
git add tests/unit/test_auth_settings.py
git commit -m "test(auth): failing tests for ADOCredentialSettings (audit §3.B)

TDD red phase. Covers defaults, ADO_*/ADO2GH_* aliases, alias precedence,
SecretStr repr masking. Will go green when ADOCredentialSettings is lifted
from ado2gh-core@160de58 in the next commit."
```

---

### Task 3: Implement `ADOCredentialSettings` (TDD green)

**Files:**
- Modify: `src/ado_source_core/auth.py`

- [ ] **Step 1: Update the module docstring**

Replace the existing docstring (lines 1–16) with:

```python
"""Authentication helpers for the Azure DevOps API.

Exposes:

- :class:`PATAuth` — attaches a Personal Access Token to outbound HTTP
  requests via Basic auth.
- :class:`ADOCredentialSettings` — Pydantic Settings model for loading
  Azure DevOps credentials (PAT + organization) from environment variables
  with ``ADO_*`` (primary) and ``ADO2GH_*`` (fallback) alias precedence.
- :func:`parse_env_file` — manual ``.env`` parser. Bypasses ``python-dotenv``
  and pydantic-settings' built-in loader because both silently corrupt
  values inside PyInstaller one-file binaries on macOS.
- :func:`resolve_ado_credentials` — generic data-layer credential resolver
  combining ``os.environ`` and ``.env`` with the documented precedence
  rules. Returns a ``dict[str, str]`` with keys ``"pat"`` and
  ``"organization"``.

Lifted from ``ado2gh-core`` @ ``160de58`` per audit §3.B + §3.D
(``shyftport-specs/plans/audit/extraction-plan.md``). Drift from donor:

- Dropped ``prefer_scanner_aliases`` parameter and the ``_SCANNER_*`` /
  ``_*_FALLBACK_KEYS`` constants — that scanner-flavored UX layer relocates
  to ``ado-scanner`` per audit §3.D.
- Slimmed the diagnostic ``logger.debug`` call at the end of
  ``resolve_ado_credentials`` — the donor block referenced
  scanner-flavored alias variables that no longer exist.
"""
```

- [ ] **Step 2: Add imports**

Below `from dataclasses import dataclass`, add:

```python
import logging
import os
import sys
from pathlib import Path

from pydantic import AliasChoices, Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict

from ado_source_core.exceptions import ConfigError

logger = logging.getLogger(__name__)
```

(Keep the existing `import base64` and `from dataclasses import dataclass`.)

- [ ] **Step 3: Append donor-attribution block + constants + class**

After the existing `PATAuth` (line 53), append:

```python


# Donor: ado2gh-core @ 160de58 — src/ado2gh/models/config.py (ADO half)
# and src/ado2gh/cli/credential_resolver.py (data-layer half). Re-licensed
# MIT; sole-authorship verified per the audit at shyftport-specs.
SETTINGS_CONFIG = SettingsConfigDict(
    env_file=".env",
    env_file_encoding="utf-8",
    populate_by_name=True,
)
DEFAULT_ADO_BASE_URL = "https://dev.azure.com"


class ADOCredentialSettings(BaseSettings):
    """Minimal settings for Azure DevOps credential lookup.

    Loads from environment variables. Each field accepts both the primary
    ``ADO_*`` name and the namespaced ``ADO2GH_*`` alias. Sensitive fields
    use ``SecretStr`` so they mask in ``repr`` / ``str``.
    """

    model_config = SETTINGS_CONFIG

    ado_pat: SecretStr | None = Field(
        default=None,
        description="Azure DevOps Personal Access Token",
        validation_alias=AliasChoices("ADO_PAT", "ADO2GH_PAT"),
    )
    ado_organization: str | None = Field(
        default=None,
        description="Azure DevOps organization name",
        validation_alias=AliasChoices("ADO_ORGANIZATION", "ADO2GH_ORGANIZATION"),
    )
```

- [ ] **Step 4: Run tests to verify green**

Run: `hatch run test tests/unit/test_auth_settings.py -v`
Expected: 8 tests pass (defaults + 5 aliases + 1 precedence + 1 secret-masking).

- [ ] **Step 5: Commit (green)**

```bash
git add src/ado_source_core/auth.py
git commit -m "feat(auth): lift ADOCredentialSettings from ado2gh-core (audit §3.B)

Donor: ado2gh-core@160de58 src/ado2gh/models/config.py (ADO half).
Re-licensed MIT per the audit's sole-authorship verification."
```

---

### Task 4: Test + implement `_clean_env_value` and `_mask`

**Files:**
- Modify: `tests/unit/test_auth_settings.py`
- Modify: `src/ado_source_core/auth.py`

- [ ] **Step 1: Append failing tests**

Add to `tests/unit/test_auth_settings.py`:

```python
from ado_source_core.auth import _clean_env_value, _mask


class TestCleanEnvValue:
    def test_strips_straight_double_quotes(self) -> None:
        assert _clean_env_value('"hello"') == "hello"

    def test_strips_straight_single_quotes(self) -> None:
        assert _clean_env_value("'hello'") == "hello"

    def test_strips_smart_quotes(self) -> None:
        assert _clean_env_value("“hello”") == "hello"
        assert _clean_env_value("‘hello’") == "hello"

    def test_strips_backticks(self) -> None:
        assert _clean_env_value("`hello`") == "hello"

    def test_strips_surrounding_whitespace(self) -> None:
        assert _clean_env_value("  hello  ") == "hello"

    def test_strips_trailing_newline(self) -> None:
        assert _clean_env_value("hello\n") == "hello"


class TestMask:
    def test_short_value_returns_stars(self) -> None:
        assert _mask("abc") == "***"
        assert _mask("12345678") == "***"

    def test_long_value_keeps_first_and_last_4(self) -> None:
        assert _mask("abcdefghij") == "abcd...ghij"

    def test_exactly_9_chars(self) -> None:
        assert _mask("abcdefghi") == "abcd...fghi"
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `hatch run test tests/unit/test_auth_settings.py -v`
Expected: `ImportError: cannot import name '_clean_env_value' from 'ado_source_core.auth'`.

- [ ] **Step 3: Append implementation**

Add to `src/ado_source_core/auth.py` (after the `ADOCredentialSettings` class):

```python


# Characters to strip from .env values — straight quotes, curly/smart quotes,
# backticks, whitespace. macOS text editors (TextEdit, Notes) and some
# terminals auto-replace straight quotes with curly variants, which
# python-dotenv does NOT strip, corrupting PATs and org names.
_STRIP_CHARS = "\"'`“”‘’ \t\n\r"


def _clean_env_value(value: str) -> str:
    """Strip quotes, smart quotes, backticks, and whitespace from a value."""
    return value.strip(_STRIP_CHARS)


def _mask(value: str) -> str:
    """Return first 4 + last 4 chars with middle masked, for safe logging."""
    if len(value) <= 8:
        return "***"
    return f"{value[:4]}...{value[-4:]}"
```

- [ ] **Step 4: Run tests to verify green**

Run: `hatch run test tests/unit/test_auth_settings.py -v`
Expected: all tests pass (8 from Task 3 + 9 new = 17).

- [ ] **Step 5: Commit**

```bash
git add tests/unit/test_auth_settings.py src/ado_source_core/auth.py
git commit -m "feat(auth): lift _clean_env_value + _mask helpers (audit §3.D)

Donor: ado2gh-core@160de58 src/ado2gh/cli/credential_resolver.py."
```

---

### Task 5: Test + implement `_is_frozen` and `parse_env_file`

**Files:**
- Modify: `tests/unit/test_auth_settings.py`
- Modify: `src/ado_source_core/auth.py`

- [ ] **Step 1: Append failing tests**

Add to `tests/unit/test_auth_settings.py`:

```python
from ado_source_core.auth import _is_frozen, parse_env_file


class TestIsFrozen:
    def test_returns_false_under_pytest(self) -> None:
        assert _is_frozen() is False

    def test_returns_true_when_frozen_attrs_set(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.setattr(sys, "frozen", True, raising=False)
        monkeypatch.setattr(sys, "_MEIPASS", str(tmp_path), raising=False)
        assert _is_frozen() is True


class TestParseEnvFile:
    def test_missing_file_returns_empty_dict(self, tmp_path: Path) -> None:
        assert parse_env_file(tmp_path / "absent.env") == {}

    def test_plain_key_value(self, tmp_path: Path) -> None:
        env = tmp_path / ".env"
        env.write_text("FOO=bar\n", encoding="utf-8")
        assert parse_env_file(env) == {"FOO": "bar"}

    def test_double_quoted_value_strips_quotes(self, tmp_path: Path) -> None:
        env = tmp_path / ".env"
        env.write_text('FOO="bar"\n', encoding="utf-8")
        assert parse_env_file(env) == {"FOO": "bar"}

    def test_single_quoted_value_strips_quotes(self, tmp_path: Path) -> None:
        env = tmp_path / ".env"
        env.write_text("FOO='bar'\n", encoding="utf-8")
        assert parse_env_file(env) == {"FOO": "bar"}

    def test_export_prefix_stripped(self, tmp_path: Path) -> None:
        env = tmp_path / ".env"
        env.write_text("export FOO=bar\n", encoding="utf-8")
        assert parse_env_file(env) == {"FOO": "bar"}

    def test_comments_and_blank_lines_ignored(self, tmp_path: Path) -> None:
        env = tmp_path / ".env"
        env.write_text(
            "# comment line\n\nFOO=bar\n   \n# another\nBAZ=qux\n",
            encoding="utf-8",
        )
        assert parse_env_file(env) == {"FOO": "bar", "BAZ": "qux"}

    def test_lines_without_equals_skipped(self, tmp_path: Path) -> None:
        env = tmp_path / ".env"
        env.write_text("NOT_A_KV_LINE\nFOO=bar\n", encoding="utf-8")
        assert parse_env_file(env) == {"FOO": "bar"}

    def test_empty_key_skipped(self, tmp_path: Path) -> None:
        env = tmp_path / ".env"
        env.write_text("=value\nFOO=bar\n", encoding="utf-8")
        assert parse_env_file(env) == {"FOO": "bar"}
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `hatch run test tests/unit/test_auth_settings.py -v`
Expected: `ImportError`.

- [ ] **Step 3: Append implementation**

Add to `src/ado_source_core/auth.py`:

```python


def _is_frozen() -> bool:
    """Return True when running inside a PyInstaller bundle."""
    return getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS")


def parse_env_file(env_path: Path) -> dict[str, str]:
    """Parse a .env file into a dict of key=value pairs.

    Handles:

    - ``KEY=VALUE`` (plain)
    - ``KEY="VALUE"`` and ``KEY='VALUE'`` (quoted, quotes stripped)
    - Comments (lines starting with ``#``)
    - Blank lines
    - ``export KEY=VALUE`` prefix (``export`` stripped)

    This parser intentionally does NOT depend on ``python-dotenv`` because
    ``python-dotenv`` corrupts values inside PyInstaller one-file bundles.
    A missing or unreadable file returns ``{}`` (debug-logged).
    """
    result: dict[str, str] = {}
    try:
        content = env_path.read_text(encoding="utf-8")
    except OSError:
        logger.debug("failed to read %s", env_path, exc_info=True)
        return result

    for raw_line in content.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:]
        if "=" not in line:
            continue
        key, _, val = line.partition("=")
        key = key.strip()
        if not key:
            continue
        val = val.strip()
        if len(val) >= 2 and (
            (val[0] == "'" and val[-1] == "'") or (val[0] == '"' and val[-1] == '"')
        ):
            val = val[1:-1]
        result[key] = val

    return result
```

**Drift note:** donor caught `Exception` for the read; we tighten to `OSError` (`Path.read_text` raises `OSError` subclasses on permission/missing-file errors; `UnicodeDecodeError` derives from `ValueError` and is a programmer-error case we want to surface, not swallow).

- [ ] **Step 4: Run tests to verify green**

Run: `hatch run test tests/unit/test_auth_settings.py -v`
Expected: all tests pass.

- [ ] **Step 5: Commit**

```bash
git add tests/unit/test_auth_settings.py src/ado_source_core/auth.py
git commit -m "feat(auth): lift _is_frozen + parse_env_file (audit §3.D)

Donor: ado2gh-core@160de58 src/ado2gh/cli/credential_resolver.py.

Drift from donor: caught exception narrowed from bare Exception to OSError
on the .env read; UnicodeDecodeError now surfaces as a programmer error
rather than being silently swallowed."
```

---

### Task 6: Test + implement `_resolve_generic_env_value` and `_resolve_env_preferred_value`

**Files:**
- Modify: `tests/unit/test_auth_settings.py`
- Modify: `src/ado_source_core/auth.py`

- [ ] **Step 1: Append failing tests**

Add to `tests/unit/test_auth_settings.py`:

```python
from ado_source_core.auth import (
    _resolve_env_preferred_value,
    _resolve_generic_env_value,
)


class TestResolveGenericEnvValue:
    def test_returns_none_when_no_keys_present(self) -> None:
        assert _resolve_generic_env_value(("FOO", "BAR"), {}) is None

    def test_env_beats_env_file(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("FOO_TEST_KEY", "from-env")
        result = _resolve_generic_env_value(
            ("FOO_TEST_KEY",), {"FOO_TEST_KEY": "from-file"}
        )
        assert result == "from-env"

    def test_env_file_used_when_env_unset(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.delenv("FOO_TEST_KEY", raising=False)
        result = _resolve_generic_env_value(
            ("FOO_TEST_KEY",), {"FOO_TEST_KEY": "from-file"}
        )
        assert result == "from-file"

    def test_first_key_wins(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("PRIMARY_KEY", "primary-val")
        monkeypatch.setenv("SECONDARY_KEY", "secondary-val")
        result = _resolve_generic_env_value(("PRIMARY_KEY", "SECONDARY_KEY"), {})
        assert result == "primary-val"

    def test_frozen_flips_precedence_to_file_first(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.setattr(sys, "frozen", True, raising=False)
        monkeypatch.setattr(sys, "_MEIPASS", str(tmp_path), raising=False)
        monkeypatch.setenv("FOO_FROZEN_KEY", "from-env")
        result = _resolve_generic_env_value(
            ("FOO_FROZEN_KEY",), {"FOO_FROZEN_KEY": "from-file"}
        )
        assert result == "from-file"


class TestResolveEnvPreferredValue:
    def test_primary_env_beats_fallback_env(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("P_KEY", "primary-env")
        monkeypatch.setenv("F_KEY", "fallback-env")
        result = _resolve_env_preferred_value(("P_KEY",), ("F_KEY",), {})
        assert result == "primary-env"

    def test_primary_file_beats_fallback_env_when_primary_env_unset(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.delenv("P_KEY", raising=False)
        monkeypatch.setenv("F_KEY", "fallback-env")
        result = _resolve_env_preferred_value(
            ("P_KEY",), ("F_KEY",), {"P_KEY": "primary-file"}
        )
        assert result == "primary-file"

    def test_fallback_env_beats_fallback_file(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.delenv("P_KEY", raising=False)
        monkeypatch.setenv("F_KEY", "fallback-env")
        result = _resolve_env_preferred_value(
            ("P_KEY",), ("F_KEY",), {"F_KEY": "fallback-file"}
        )
        assert result == "fallback-env"

    def test_returns_none_when_nothing_present(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.delenv("P_KEY", raising=False)
        monkeypatch.delenv("F_KEY", raising=False)
        assert _resolve_env_preferred_value(("P_KEY",), ("F_KEY",), {}) is None

    def test_frozen_returns_primary_file_first(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.setattr(sys, "frozen", True, raising=False)
        monkeypatch.setattr(sys, "_MEIPASS", str(tmp_path), raising=False)
        monkeypatch.setenv("P_KEY", "primary-env")
        result = _resolve_env_preferred_value(
            ("P_KEY",), ("F_KEY",), {"P_KEY": "primary-file"}
        )
        assert result == "primary-file"
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `hatch run test tests/unit/test_auth_settings.py -v`
Expected: `ImportError`.

- [ ] **Step 3: Append implementation**

Add to `src/ado_source_core/auth.py`:

```python


def _resolve_generic_env_value(
    keys: tuple[str, ...], env_file_values: dict[str, str]
) -> str | None:
    """Preserve env-over-.env precedence across generic alias families.

    When running under PyInstaller (``_is_frozen``) the precedence flips —
    the bundled ``.env`` is preferred because PyInstaller's environment
    propagation is unreliable on macOS.
    """
    if _is_frozen():
        for key in keys:
            if key in env_file_values:
                return env_file_values[key]

    for key in keys:
        if key in os.environ:
            return os.environ[key]

    for key in keys:
        if key in env_file_values:
            return env_file_values[key]

    return None


def _resolve_env_preferred_value(
    primary_keys: tuple[str, ...],
    fallback_keys: tuple[str, ...],
    env_file_values: dict[str, str],
) -> str | None:
    """Prefer primary keys globally, then env-over-.env for fallback keys.

    Currently unused by ``resolve_ado_credentials`` (which is generic-only
    after audit §3.D dropped the scanner-alias UX); kept as part of the
    cohesive data-layer toolkit so downstream wrappers can compose with it.
    """
    if _is_frozen():
        for key in primary_keys:
            if key in env_file_values:
                return env_file_values[key]
        for key in fallback_keys:
            if key in env_file_values:
                return env_file_values[key]

    for key in primary_keys:
        if key in os.environ:
            return os.environ[key]
        if key in env_file_values:
            return env_file_values[key]

    for key in fallback_keys:
        if key in os.environ:
            return os.environ[key]

    for key in fallback_keys:
        if key in env_file_values:
            return env_file_values[key]

    return None
```

- [ ] **Step 4: Run tests to verify green**

Run: `hatch run test tests/unit/test_auth_settings.py -v`
Expected: all tests pass.

- [ ] **Step 5: Commit**

```bash
git add tests/unit/test_auth_settings.py src/ado_source_core/auth.py
git commit -m "feat(auth): lift env-resolution helpers (audit §3.D)

Donor: ado2gh-core@160de58 src/ado2gh/cli/credential_resolver.py.

Includes _resolve_env_preferred_value despite no internal caller —
kept as part of the cohesive data-layer toolkit for downstream wrappers."
```

---

### Task 7: Test + implement `resolve_ado_credentials`

**Files:**
- Modify: `tests/unit/test_auth_settings.py`
- Modify: `src/ado_source_core/auth.py`

- [ ] **Step 1: Append failing tests**

Add to `tests/unit/test_auth_settings.py`:

```python
from ado_source_core.auth import resolve_ado_credentials
from ado_source_core.exceptions import ConfigError


class TestResolveADOCredentials:
    def test_happy_path_from_env(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("ADO_PAT", "pat-from-env")
        monkeypatch.setenv("ADO_ORGANIZATION", "org-from-env")
        result = resolve_ado_credentials()
        assert result == {"pat": "pat-from-env", "organization": "org-from-env"}

    def test_happy_path_from_env_file(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        env = tmp_path / ".env"
        env.write_text("ADO_PAT=pat-from-file\nADO_ORGANIZATION=org-from-file\n")
        monkeypatch.chdir(tmp_path)
        result = resolve_ado_credentials()
        assert result == {"pat": "pat-from-file", "organization": "org-from-file"}

    def test_env_beats_env_file(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        env = tmp_path / ".env"
        env.write_text("ADO_PAT=pat-from-file\nADO_ORGANIZATION=org-from-file\n")
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("ADO_PAT", "pat-from-env")
        monkeypatch.setenv("ADO_ORGANIZATION", "org-from-env")
        result = resolve_ado_credentials()
        assert result == {"pat": "pat-from-env", "organization": "org-from-env"}

    def test_ado2gh_alias_used_as_fallback(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("ADO2GH_PAT", "pat-fallback")
        monkeypatch.setenv("ADO2GH_ORGANIZATION", "org-fallback")
        result = resolve_ado_credentials()
        assert result == {"pat": "pat-fallback", "organization": "org-fallback"}

    def test_explicit_organization_argument_overrides_env(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("ADO_PAT", "pat-from-env")
        monkeypatch.setenv("ADO_ORGANIZATION", "ignored-org")
        result = resolve_ado_credentials(organization="explicit-org")
        assert result == {"pat": "pat-from-env", "organization": "explicit-org"}

    def test_missing_pat_raises_config_error(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("ADO_ORGANIZATION", "org")
        with pytest.raises(ConfigError, match="PAT not found"):
            resolve_ado_credentials()

    def test_missing_organization_raises_config_error(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("ADO_PAT", "pat")
        with pytest.raises(ConfigError, match="organization not found"):
            resolve_ado_credentials()

    def test_non_ascii_pat_raises_config_error(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("ADO_PAT", "pat-with-“smart-quotes”-inside")
        monkeypatch.setenv("ADO_ORGANIZATION", "org")
        with pytest.raises(ConfigError, match="non-ASCII"):
            resolve_ado_credentials()

    def test_pat_quotes_are_stripped(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        env = tmp_path / ".env"
        env.write_text('ADO_PAT="quoted-pat"\nADO_ORGANIZATION="quoted-org"\n')
        monkeypatch.chdir(tmp_path)
        result = resolve_ado_credentials()
        assert result == {"pat": "quoted-pat", "organization": "quoted-org"}
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `hatch run test tests/unit/test_auth_settings.py -v`
Expected: `ImportError`.

- [ ] **Step 3: Append implementation**

Add to `src/ado_source_core/auth.py`:

```python


_PAT_ENV_KEYS = ("ADO_PAT", "ADO2GH_PAT")
_ORG_ENV_KEYS = ("ADO_ORGANIZATION", "ADO2GH_ORGANIZATION")


def resolve_ado_credentials(
    *, organization: str | None = None
) -> dict[str, str]:
    """Resolve Azure DevOps credentials from environment and .env file.

    Parses ``.env`` directly and combines it with ``os.environ`` using the
    documented precedence rules (env-over-.env, except under PyInstaller).
    Recognises both ``ADO_*`` (primary) and ``ADO2GH_*`` (fallback) alias
    families.

    Drift from donor (``ado2gh-core@160de58``): the ``prefer_scanner_aliases``
    parameter and the ``_SCANNER_*`` constants were dropped per audit §3.D —
    scanner-flavored UX moves to ``ado-scanner``'s wrapper layer.

    Args:
        organization: When provided, overrides any environment-supplied
            organization value. Useful for CLI ``--organization`` flags.

    Returns:
        ``{"pat": ..., "organization": ...}``.

    Raises:
        ConfigError: If ``pat`` or ``organization`` cannot be resolved, or
            if the PAT contains non-ASCII characters (a strong signal of
            copy-paste corruption from a smart-quote-substituting editor).
    """
    env_path = Path(".env")
    env_file_raw = parse_env_file(env_path) if env_path.is_file() else {}
    env_loaded = bool(env_file_raw)

    raw_pat = _resolve_generic_env_value(_PAT_ENV_KEYS, env_file_raw)
    pat = _clean_env_value(raw_pat) if raw_pat else None
    if not pat:
        raise ConfigError(
            "Azure DevOps PAT not found.\n"
            "  Set ADO_PAT or ADO2GH_PAT in the environment or .env file.\n"
            "  Required scopes: vso.project, vso.code, vso.build, vso.release,\n"
            "  vso.work, vso.packaging, vso.test, vso.serviceendpoint_query,\n"
            "  vso.graph, vso.memberentitlementmanagement, vso.analytics, vso.profile",
            field="ADO_PAT",
        )

    if not pat.isascii():
        raise ConfigError(
            "ADO_PAT contains non-ASCII characters (possible copy-paste corruption).\n"
            "  Open your .env file in a plain-text editor and ensure the PAT value\n"
            "  has no curly/smart quotes or other special characters.",
            field="ADO_PAT",
        )

    raw_org: str | None
    if organization is not None:
        raw_org = organization
    else:
        raw_org = _resolve_generic_env_value(_ORG_ENV_KEYS, env_file_raw)
    org = _clean_env_value(raw_org) if raw_org else None
    if not org:
        raise ConfigError(
            "Azure DevOps organization not found.\n"
            "  Set ADO_ORGANIZATION or ADO2GH_ORGANIZATION in the environment\n"
            "  or .env file, or pass an explicit organization argument.",
            field="ADO_ORGANIZATION",
        )

    env_has_pat = any(key in os.environ for key in _PAT_ENV_KEYS)
    raw_file_pat = next(
        (env_file_raw[key] for key in _PAT_ENV_KEYS if key in env_file_raw),
        None,
    )
    raw_file_org = next(
        (env_file_raw[key] for key in _ORG_ENV_KEYS if key in env_file_raw),
        None,
    )

    logger.debug(
        "credentials resolved: frozen=%s, env_loaded=%s, env_var_set=%s, "
        "env_file_exists=%s, pat_len=%d, pat_preview=%s, "
        "file_raw_pat_len=%s, file_raw_pat_preview=%s, "
        "pat_matches_file=%s, file_raw_org=%s, org=%s, cwd=%s",
        _is_frozen(),
        env_loaded,
        env_has_pat,
        env_path.is_file(),
        len(pat),
        _mask(pat),
        len(raw_file_pat) if raw_file_pat else "N/A",
        _mask(raw_file_pat) if raw_file_pat else "N/A",
        pat == raw_file_pat if raw_file_pat else "N/A",
        raw_file_org,
        org,
        os.getcwd(),
    )

    return {"pat": pat, "organization": org}
```

- [ ] **Step 4: Run tests to verify green**

Run: `hatch run test tests/unit/test_auth_settings.py -v`
Expected: all tests pass.

- [ ] **Step 5: Commit**

```bash
git add tests/unit/test_auth_settings.py src/ado_source_core/auth.py
git commit -m "feat(auth): lift resolve_ado_credentials (audit §3.D)

Donor: ado2gh-core@160de58 src/ado2gh/cli/credential_resolver.py.

Drift from donor:
- Dropped prefer_scanner_aliases parameter and _SCANNER_* constants;
  scanner UX moves to ado-scanner per audit §3.D.
- Slimmed the diagnostic logger.debug block to use the surviving
  generic-alias variables only."
```

---

### Task 8: Export new symbols from package root

**Files:**
- Modify: `src/ado_source_core/__init__.py`

- [ ] **Step 1: Add a failing re-export test**

Append to `tests/unit/test_auth_settings.py`:

```python


class TestPackageRootReExports:
    def test_ado_credential_settings_re_exported(self) -> None:
        import ado_source_core

        assert ado_source_core.ADOCredentialSettings is ADOCredentialSettings  # type: ignore[attr-defined]

    def test_default_ado_base_url_re_exported(self) -> None:
        import ado_source_core
        from ado_source_core.auth import DEFAULT_ADO_BASE_URL

        assert ado_source_core.DEFAULT_ADO_BASE_URL is DEFAULT_ADO_BASE_URL  # type: ignore[attr-defined]

    def test_parse_env_file_re_exported(self) -> None:
        import ado_source_core

        assert ado_source_core.parse_env_file is parse_env_file  # type: ignore[attr-defined]

    def test_resolve_ado_credentials_re_exported(self) -> None:
        import ado_source_core

        assert ado_source_core.resolve_ado_credentials is resolve_ado_credentials  # type: ignore[attr-defined]
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `hatch run test tests/unit/test_auth_settings.py::TestPackageRootReExports -v`
Expected: `AttributeError: module 'ado_source_core' has no attribute 'ADOCredentialSettings'`.

- [ ] **Step 3: Update `src/ado_source_core/__init__.py`**

Modify the docstring's first sentence to include the new symbols. Then update the `from ado_source_core.auth import PATAuth` line to:

```python
from ado_source_core.auth import (
    ADOCredentialSettings,
    DEFAULT_ADO_BASE_URL,
    PATAuth,
    parse_env_file,
    resolve_ado_credentials,
)
```

Then add the new symbols to `__all__` in alphabetical order (`__version__` stays at the bottom). The full updated `__all__` list:

```python
__all__ = [
    "ADOClient",
    "ADOCredentialSettings",
    "ADOSourceCoreError",
    "APIError",
    "ArtifactFeedInventoryItem",
    "AuthenticationError",
    "AzureDevOpsCloudAdapter",
    "BoardSummary",
    "ComplexityLevel",
    "ComplexityScore",
    "ConfigError",
    "DEFAULT_ADO_BASE_URL",
    "ExitCode",
    "Inventory",
    "InventoryMetadata",
    "InventorySummary",
    "LFSInfo",
    "LargeFileInfo",
    "PATAuth",
    "PipelineAnalysis",
    "PipelineInventoryItem",
    "PipelineMigrationComplexity",
    "PipelineStepInfo",
    "PipelineType",
    "ProjectInventoryItem",
    "RateLimitError",
    "Repository",
    "RepositoryInventoryItem",
    "SourceAdapter",
    "SourceCapabilities",
    "SourceType",
    "TaskSupportLevel",
    "TestPlanInventoryItem",
    "TfvcSummary",
    "User",
    "UserEntitlementSummary",
    "__version__",
    "paginate_continuation_token",
    "paginate_skip_top",
    "parse_env_file",
    "resolve_ado_credentials",
]
```

Update the docstring (replace the existing one) to:

```python
"""Package initialization for ado_source_core.

Exposes version metadata, the ``SourceAdapter`` abstract base class plus
the concrete ``AzureDevOpsCloudAdapter`` for the read-side core, the
read-side Pydantic models, the exception hierarchy, the ``PATAuth``
helper plus the ``ADOCredentialSettings`` Pydantic Settings model and
the ``resolve_ado_credentials`` data-layer helper, the pagination
iterators, and the core ``ADOClient`` HTTP transport.
"""
```

- [ ] **Step 4: Run tests to verify green**

Run: `hatch run test -v`
Expected: all tests pass (existing 187 + new auth-settings tests).

- [ ] **Step 5: Commit**

```bash
git add src/ado_source_core/__init__.py tests/unit/test_auth_settings.py
git commit -m "feat(auth): re-export ADOCredentialSettings + resolver from package root

Adds ADOCredentialSettings, DEFAULT_ADO_BASE_URL, parse_env_file, and
resolve_ado_credentials to ado_source_core's public surface. Alphabetical
sort preserved in __all__."
```

---

### Task 9: Verification sweep

**Files:** none modified.

- [ ] **Step 1: ruff lint**

Run: `hatch run ruff check src tests`
Expected: clean (`All checks passed!`).

- [ ] **Step 2: ruff format check**

Run: `hatch run ruff format --check src tests`
Expected: clean (`X files already formatted`).

- [ ] **Step 3: mypy strict**

Run: `hatch run mypy src`
Expected: clean (`Success: no issues found in N source files`).

- [ ] **Step 4: full pytest run**

Run: `hatch run test`
Expected: all tests pass; **deselected count must remain 5 (the integration markers)**.

- [ ] **Step 5: import smoke check**

Run:
```bash
hatch run python -c "from ado_source_core import ADOCredentialSettings, DEFAULT_ADO_BASE_URL, parse_env_file, resolve_ado_credentials; print('ok')"
```
Expected: `ok`.

- [ ] **Step 6: If any of the above fails, fix in-place and re-run from Step 1.**

If formatter complained, run `hatch run ruff format src tests` and stage the diff into the most recent feature commit (`git add -p` + `git commit --amend --no-edit`). If lint/mypy errors are surfaced, fix and add a small fixup commit per item — keep noisy commits, the supervisor will squash on merge.

- [ ] **Step 7: Push the branch**

Run: `git push -u origin feat/ado-credential-settings`

---

### Task 10: Codex adversarial review

**Files:** none until findings come back.

- [ ] **Step 1: Dispatch codex:rescue**

Invoke skill `codex:rescue` (via the Skill tool or Agent tool with subagent_type `codex:codex-rescue`) with a prompt summarising:
- Branch: `feat/ado-credential-settings` (pushed)
- Spec: `docs/superpowers/specs/2026-04-30-ado-credential-settings-lift-design.md`
- Donor: `ado2gh-core@160de58`
- Asked review: hidden donor-fidelity gaps, type-tightening drift not covered in commit messages, missed test cases (smart-quote PAT, frozen-mode resolver, .env precedence edge cases), public-vs-private classification of helpers, anything that would block a clean Copilot pass.

- [ ] **Step 2: Apply findings**

For each finding, decide:
- **Apply** → add a fixup commit with a clear `fix(auth): <summary> (codex)` message.
- **Defer** → respond inline with rationale; if it's a deferred audit follow-up, document it in the PR body.

- [ ] **Step 3: Re-run verification sweep (Task 9 steps 1–5)**

Make sure nothing regressed.

- [ ] **Step 4: Push fixups**

Run: `git push`

---

### Task 11: Open PR + iterate on Copilot

**Files:** none.

- [ ] **Step 1: Create the PR**

Run:
```bash
gh pr create --title "feat(auth): lift ADOCredentialSettings + credential resolver from ado2gh-core" --body "$(cat <<'EOF'
## Summary

Lands the deferred half of audit §3 (`shyftport-specs/plans/audit/extraction-plan.md` §3.B + §3.D). PR #6 (`PATAuth`) only landed the dataclass; this PR completes the auth module by lifting `ADOCredentialSettings` (Pydantic Settings) plus the data-layer half of `ado2gh-core/src/ado2gh/cli/credential_resolver.py`.

Donor: `n8group-oss/ado2gh-core` @ `160de58`. Re-licensed MIT per the audit's sole-authorship verification.

### New public symbols

- `ADOCredentialSettings` — Pydantic Settings (PAT + organization, ADO_*/ADO2GH_* aliases).
- `DEFAULT_ADO_BASE_URL` — `"https://dev.azure.com"`.
- `parse_env_file` — manual `.env` parser (PyInstaller-safe).
- `resolve_ado_credentials` — generic data-layer resolver returning `dict[str, str]`.

### Drift from donor

- Dropped `prefer_scanner_aliases` parameter and `_SCANNER_*` / `_*_FALLBACK_KEYS` constants — scanner UX layer relocates to `ado-scanner` per audit §3.D.
- Slimmed the diagnostic `logger.debug(...)` block in `resolve_ado_credentials` to reference only the surviving generic-alias variables.
- Narrowed the `parse_env_file` exception catch from bare `Exception` to `OSError`. `UnicodeDecodeError` is now surfaced as a programmer-error rather than silently swallowed.

### New dependency

- `pydantic-settings>=2,<3` (added to `[project] dependencies`).

### Tooling

- `[tool.hatch.envs.default.scripts] test = "pytest {args:-v}"` so `hatch run test` works (pre-commit gate prerequisite). CI's plain `pytest -v` is unaffected.

## Test plan

- [ ] CI lint (`ruff check`, `ruff format --check`)
- [ ] CI typecheck (`mypy src` strict)
- [ ] CI test (`pytest -v` on 3.11/3.12/3.13)
- [ ] Smoke import: `python -c "from ado_source_core import ADOCredentialSettings, parse_env_file, resolve_ado_credentials"`

🤖 Generated with [Claude Code](https://claude.com/claude-code)
EOF
)"
```
Expected: PR URL printed.

- [ ] **Step 2: Wait for Copilot review**

Run: `gh pr view --web` to track. Copilot review is auto-triggered by the org-level ruleset.

- [ ] **Step 3: Iterate on findings**

For each Copilot comment:
- Apply or rebut with rationale.
- Push a fixup commit per logical fix.

- [ ] **Step 4: Confirm CI green and Copilot satisfied**

Run: `gh pr checks` and `gh pr view --comments`.

- [ ] **Step 5: Escalate to supervisor**

Reply: "PR ready for merge approval — <URL>". Do NOT merge — supervisor squash-merges.

---

## Self-review

- **Spec coverage:** Each spec section maps to a task: pyproject dep → Task 1; tests + implementation per symbol → Tasks 2–7; re-exports → Task 8; verification → Task 9; Codex → Task 10; PR → Task 11.
- **Placeholders:** None — every step has either exact code, an exact command + expected output, or both.
- **Type consistency:** `ADOCredentialSettings` (class), `DEFAULT_ADO_BASE_URL` (str constant), `parse_env_file(env_path: Path) -> dict[str, str]`, `resolve_ado_credentials(*, organization: str | None = None) -> dict[str, str]` — used identically across tasks.
- **Donor fidelity:** Drift is explicit in commit messages (Tasks 5, 6, 7) and the module docstring (Task 3). Re-license attribution is in `auth.py`'s donor-comment block (Task 3, Step 3).
