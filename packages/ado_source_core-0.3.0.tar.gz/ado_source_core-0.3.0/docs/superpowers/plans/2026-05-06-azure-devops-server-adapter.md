# Azure DevOps Server Adapter Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add `AzureDevOpsServerAdapter` to `ado-source-core` v0.3.0 with the same read-side surface as `AzureDevOpsCloudAdapter`, plus an api-version discovery mechanism that lets the adapter automatically negotiate the highest mutually-supported REST API version against an Azure DevOps Server instance (releases 2022 / 2020 / 2019 Update 1+ / 2019 RTW; REST 7.0 / 6.0 / 5.1 / 5.0).

**Architecture:** Extract abstract `BaseADOClient` from the existing `ADOClient`; rename current concrete to `ADOCloudClient`; add `ADOServerClient` sibling. `ADOClient = ADOCloudClient` alias preserves existing imports. New `api_version_discovery.py` module probes `/_apis/connectionData` first with candidate-iteration fallback; eager soft-capability probes (Graph / Analytics / Package Management) populate `SourceCapabilities` flags. `AzureDevOpsServerAdapter` is a sibling of `AzureDevOpsCloudAdapter` (NOT a subclass) — eager-raise on capability flags via new `UnsupportedOnAzureDevOpsServerError`.

**Tech Stack:** Python 3.11+, httpx (async), respx (test mocking), Pydantic v2, pytest + pytest-asyncio, ruff, mypy strict.

**Spec:** `docs/superpowers/specs/2026-05-06-azure-devops-server-adapter-design.md`

**Branch:** `feat/azure-devops-server-adapter` (worktree at `.worktrees/server-adapter/`)

**Donor:** `n8group-oss/ado2gh-core` @ `160de58` — `src/ado2gh/adapters/ado_server.py`

---

## File Structure

### Files created

| Path | Purpose |
|---|---|
| `src/ado_source_core/api_version_discovery.py` | Probe logic + `SERVER_API_VERSION_CANDIDATES` + `ServerProbeResult` + `resolve_server_api_version`. |
| `src/ado_source_core/adapters/ado_server.py` | `AzureDevOpsServerAdapter` (sibling of `AzureDevOpsCloudAdapter`). |
| `tests/unit/test_client_base.py` | Shared `BaseADOClient.request()` retry/rate-limit/error-mapping loop tests via a tiny `_TinyClient` subclass. |
| `tests/unit/test_client_server.py` | `ADOServerClient` construction + `_select_client` + `request` + `connect` lifecycle tests. |
| `tests/unit/test_api_version_discovery.py` | `resolve_server_api_version` + soft-capability probe tests. |
| `tests/unit/test_adapters_ado_server.py` | `AzureDevOpsServerAdapter` per-method conformance + capability-gating + parity + lifecycle tests. |
| `tests/integration/test_smoke_server.py` | 5 read-only integration tests against a real Server instance, gated on env vars. |

### Files modified

| Path | Change |
|---|---|
| `src/ado_source_core/client.py` | Extract `BaseADOClient` abstract. Rename `ADOClient` → `ADOCloudClient`. Add `ADOServerClient`. Add `ADOClient = ADOCloudClient` alias. |
| `src/ado_source_core/exceptions.py` | Add `UnsupportedOnAzureDevOpsServerError`. |
| `src/ado_source_core/models/source_capabilities.py` | Drop `supports_packages`. Add `supports_graph_api`, `supports_analytics_odata`, `supports_artifact_feeds` fields. Add `server_default()` classmethod. Add `with_overrides()` method + `OVERRIDABLE_SOFT_CAPABILITY_KEYS`. |
| `src/ado_source_core/pagination.py` | Migrate type imports from `ADOClient` → `BaseADOClient`. |
| `src/ado_source_core/adapters/__init__.py` | Export `AzureDevOpsServerAdapter`. |
| `src/ado_source_core/__init__.py` | Extend `__all__` (alphabetical insert): `ADOServerClient`, `ADOCloudClient`, `AzureDevOpsServerAdapter`, `BaseADOClient`, `SERVER_API_VERSION_CANDIDATES`, `ServerProbeResult`, `UnsupportedOnAzureDevOpsServerError`, `resolve_server_api_version`. |
| `tests/integration/conftest.py` | Add `ado_server_url` / `ado_server_collection` / `ado_server_pat` / `server_client` fixtures. Make `_env_or_skip` suite-aware. |
| `tests/unit/test_models_source_capabilities.py` | Add tests for `server_default()`, soft-cap flag defaults, `with_overrides()` whitelist, `compatibility_mode` for 5.0/5.1. |
| `tests/unit/test_exceptions.py` | Add tests for `UnsupportedOnAzureDevOpsServerError`. |
| `pyproject.toml` | Update `[tool.pytest.ini_options].markers` description to mention both env-var sets. |
| `README.md` | Add "Cloud vs Server" section with comprehensive capability matrix + Server quickstart. |
| `CHANGELOG.md` | Populate `[Unreleased]` block with Added / Changed (BREAKING) entries. |

### Verification commands (run after every meaningful change)

```bash
cd /home/marcin/projects/n8group-oss/ado-source-core/.worktrees/server-adapter
ruff check src tests
ruff format --check src tests
mypy src
pytest -v
```

The integration suite (`-m integration`) is deselected by default in `pyproject.toml`. To run it manually:

```bash
ADO_ORG=<org> ADO_PAT=<pat> ADO_SERVER_URL=<url> ADO_SERVER_PAT=<pat> pytest -v -m integration
```

---

## Task 1: Refactor — extract `BaseADOClient`, alias `ADOClient = ADOCloudClient`, migrate paginator types

**Goal:** Pure refactor. Zero behavior change for cloud consumers. Every existing cloud test passes unchanged. Lays the abstract base for `ADOServerClient`.

**Files:**
- Modify: `src/ado_source_core/client.py`
- Modify: `src/ado_source_core/pagination.py`
- Create: `tests/unit/test_client_base.py`
- Modify: `tests/unit/test_client.py` (NO CHANGES — verify still green)

### Task 1.1 — Write the failing parity test for `BaseADOClient`

- [ ] **Step 1: Create `tests/unit/test_client_base.py`**

```python
"""BaseADOClient shared transport-loop tests.

A tiny `_TinyClient(BaseADOClient)` defined inside this module exercises the
shared retry / rate-limit / error-mapping loop independently of cloud or
server. One place to assert loop semantics so future backends don't have
to re-prove them.
"""

from __future__ import annotations

import asyncio

import httpx
import pytest
import respx

from ado_source_core import APIError, AuthenticationError, PATAuth, RateLimitError
from ado_source_core.client import BaseADOClient


_TINY_BASE = "https://tiny.example.com"


class _TinyClient(BaseADOClient):
    """Minimal BaseADOClient subclass — single host, fixed api-version."""

    def __init__(self, *, auth: PATAuth, max_retries: int = 3) -> None:
        self._max_retries = max_retries
        self._clients = {
            "dev": httpx.AsyncClient(
                base_url=_TINY_BASE,
                headers={"Accept": "application/json", **auth.headers()},
                timeout=5.0,
            ),
        }

    @property
    def api_version(self) -> str:
        return "9.9"


@pytest.fixture
def auth() -> PATAuth:
    return PATAuth(token="dummy-pat")


_recorded_sleeps: list[float] = []


async def _instant_sleep(seconds: float) -> None:
    _recorded_sleeps.append(seconds)


@pytest.fixture(autouse=True)
def _no_sleep(monkeypatch: pytest.MonkeyPatch) -> None:
    _recorded_sleeps.clear()
    monkeypatch.setattr(asyncio, "sleep", _instant_sleep)


class TestBaseADOClientRequest:
    @pytest.mark.asyncio
    async def test_injects_api_version_query_param(self, auth: PATAuth) -> None:
        async with _TinyClient(auth=auth) as client:
            with respx.mock(base_url=_TINY_BASE) as mock:
                route = mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                await client.request("GET", "/_apis/projects")
                assert route.calls[0].request.url.params["api-version"] == "9.9"

    @pytest.mark.asyncio
    async def test_skip_api_version_omits_param(self, auth: PATAuth) -> None:
        async with _TinyClient(auth=auth) as client:
            with respx.mock(base_url=_TINY_BASE) as mock:
                route = mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={})
                )
                await client.request(
                    "GET", "/_apis/connectionData", skip_api_version=True
                )
                assert "api-version" not in route.calls[0].request.url.params

    @pytest.mark.asyncio
    async def test_401_maps_to_authentication_error(self, auth: PATAuth) -> None:
        async with _TinyClient(auth=auth) as client:
            with respx.mock(base_url=_TINY_BASE) as mock:
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(401, json={"message": "no"})
                )
                with pytest.raises(AuthenticationError):
                    await client.request("GET", "/_apis/projects")

    @pytest.mark.asyncio
    async def test_429_retries_then_raises_rate_limit(self, auth: PATAuth) -> None:
        async with _TinyClient(auth=auth, max_retries=2) as client:
            with respx.mock(base_url=_TINY_BASE) as mock:
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(429, headers={"Retry-After": "1"})
                )
                with pytest.raises(RateLimitError) as exc_info:
                    await client.request("GET", "/_apis/projects")
                assert exc_info.value.retry_after == 1.0
                # Verify retry actually waited the Retry-After value (1s) on attempt 0.
                assert _recorded_sleeps == [1.0]

    @pytest.mark.asyncio
    async def test_503_retries_with_exponential_backoff(self, auth: PATAuth) -> None:
        async with _TinyClient(auth=auth, max_retries=3) as client:
            with respx.mock(base_url=_TINY_BASE) as mock:
                mock.get("/_apis/projects").mock(
                    side_effect=[
                        httpx.Response(503),
                        httpx.Response(503),
                        httpx.Response(200, json={"value": []}),
                    ]
                )
                response = await client.request("GET", "/_apis/projects")
                assert response.status_code == 200
                # Verify exponential backoff: 2**0=1, 2**1=2.
                assert _recorded_sleeps == [1.0, 2.0]

    @pytest.mark.asyncio
    async def test_network_error_raises_api_error_with_none_status(
        self, auth: PATAuth
    ) -> None:
        async with _TinyClient(auth=auth, max_retries=2) as client:
            with respx.mock(base_url=_TINY_BASE) as mock:
                mock.get("/_apis/projects").mock(side_effect=httpx.ConnectError("boom"))
                with pytest.raises(APIError) as exc_info:
                    await client.request("GET", "/_apis/projects")
                assert exc_info.value.status_code is None
                # Verify exponential backoff was attempted on retry: 2**0=1.
                assert _recorded_sleeps == [1.0]
```

- [ ] **Step 2: Run the test to verify it fails**

```bash
pytest tests/unit/test_client_base.py -v 2>&1 | head -30
```

Expected: pytest collection fails with `ImportError: cannot import name 'BaseADOClient' from 'ado_source_core.client'` (collection error, not per-test failures — tests don't run because the module-level import fails).

### Task 1.2 — Extract `BaseADOClient` from current `ADOClient`

- [ ] **Step 1: Edit `src/ado_source_core/client.py` — replace the `ADOClient` class with `BaseADOClient` + `ADOCloudClient` + module-level alias**

Read the current file: it contains module docstring (preserve), `API_VERSION = "7.1"`, `_parse_retry_after`, `_extract_response_body`, `HostName = str`, `class ADOClient`. Replace ONLY the `class ADOClient` block (currently lines ~135–303) with:

```python
class BaseADOClient(ABC):
    """Shared transport contract for ADO REST clients (cloud + server).

    Owns: ``request()`` retry+rate-limit+error-mapping loop, ``close()``
    over ``self._clients.values()`` (deduplicated), async context manager.

    Subclasses own: host-to-httpx-client routing (via ``_clients`` dict),
    api-version policy (via ``api_version`` abstract property), base URLs.
    """

    _clients: dict[HostName, httpx.AsyncClient]
    _max_retries: int

    @property
    @abstractmethod
    def api_version(self) -> str:
        """The api-version query-param value applied to every request."""

    def _select_client(self, host: HostName) -> httpx.AsyncClient:
        """Return the httpx client for a logical host name.

        Default: lookup in ``self._clients``. Subclasses with a single physical
        client (e.g., ``ADOServerClient``) can keep this default by aliasing
        all logical hosts to the same client in ``self._clients``.
        """
        return self._clients[host]

    def httpx_client(self, host: HostName = "dev") -> httpx.AsyncClient:
        """Return the underlying ``httpx.AsyncClient`` for a given host.

        Useful for the pagination iterators in ``ado_source_core.pagination``,
        which take a raw ``httpx.AsyncClient`` rather than a ``BaseADOClient``.

        On ``ADOServerClient``, every host name returns the same single
        client. Do NOT infer routing, TLS target, or endpoint family from
        ``client.httpx_client("vssps").base_url`` on Server — the
        collection URL is always returned regardless of host argument.
        """
        return self._select_client(host)

    async def request(
        self,
        method: str,
        url: str,
        *,
        host: HostName = "dev",
        params: Mapping[str, Any] | None = None,
        skip_api_version: bool = False,
        **kwargs: Any,
    ) -> httpx.Response:
        """Make an authenticated API request with retry + error mapping.

        - 401/403 -> ``AuthenticationError``
        - 429 -> retried up to ``max_retries`` honouring the ``Retry-After``
          header; raises ``RateLimitError`` once retries are exhausted.
        - 503 -> retried up to ``max_retries`` with exponential backoff.
        - Other ``httpx`` transport errors -> retried up to ``max_retries``,
          then ``APIError`` once exhausted.
        - Any other 4xx / 5xx -> ``APIError`` (no retry).
        """
        client = self._select_client(host)

        merged_params: dict[str, Any] = dict(params or {})
        if not skip_api_version:
            merged_params.setdefault("api-version", self.api_version)

        response: httpx.Response | None = None
        for attempt in range(self._max_retries):
            try:
                response = await client.request(method, url, params=merged_params, **kwargs)
            except httpx.HTTPError as exc:
                if attempt < self._max_retries - 1:
                    await asyncio.sleep(2**attempt)
                    continue
                raise APIError(f"Network error: {exc}", status_code=None) from exc

            if (
                response.status_code == HTTPStatus.SERVICE_UNAVAILABLE
                and attempt < self._max_retries - 1
            ):
                await asyncio.sleep(2**attempt)
                continue

            if response.status_code == HTTPStatus.TOO_MANY_REQUESTS:
                retry_after = _parse_retry_after(
                    response.headers.get("Retry-After"), attempt=attempt
                )
                if attempt < self._max_retries - 1:
                    await asyncio.sleep(retry_after)
                    continue
                raise RateLimitError(
                    "Azure DevOps rate limit exceeded",
                    status_code=int(HTTPStatus.TOO_MANY_REQUESTS),
                    response_body=_extract_response_body(response),
                    retry_after=retry_after,
                )

            break

        assert response is not None
        if response.status_code == HTTPStatus.UNAUTHORIZED:
            raise AuthenticationError(
                "Invalid PAT or insufficient permissions",
                status_code=int(HTTPStatus.UNAUTHORIZED),
                response_body=_extract_response_body(response),
            )
        if response.status_code == HTTPStatus.FORBIDDEN:
            raise AuthenticationError(
                "Access denied — check PAT scopes",
                status_code=int(HTTPStatus.FORBIDDEN),
                response_body=_extract_response_body(response),
            )
        if response.status_code >= HTTPStatus.BAD_REQUEST:
            raise APIError(
                "Azure DevOps API error",
                status_code=response.status_code,
                response_body=_extract_response_body(response),
            )
        return response

    async def close(self) -> None:
        """Close all underlying httpx clients (deduplicated). Resilient to partial failures."""
        seen: set[int] = set()
        for host, c in self._clients.items():
            if id(c) in seen:
                continue
            seen.add(id(c))
            try:
                await c.aclose()
            except Exception:
                logger.warning(
                    "Failed to close %s client (base_url=%s)",
                    host,
                    c.base_url,
                    exc_info=True,
                )

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.close()


class ADOCloudClient(BaseADOClient):
    """Concrete HTTP client for Azure DevOps Services (the cloud product).

    Manages one ``httpx.AsyncClient`` per ADO API host. Pinned api-version
    is the module-level ``API_VERSION`` constant (``"7.1"``).
    """

    def __init__(  # noqa: PLR0913 - configuration knobs are keyword-only
        self,
        *,
        organization: str,
        auth: PATAuth,
        base_url: str = "https://dev.azure.com",
        verify_ssl: bool | str = True,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        self._organization = organization
        self._max_retries = max_retries

        common_kwargs: dict[str, Any] = {
            "headers": {"Accept": "application/json", **auth.headers()},
            "verify": verify_ssl,
            "timeout": timeout,
        }

        self._clients = {
            "dev": httpx.AsyncClient(base_url=f"{base_url}/{organization}", **common_kwargs),
            "vsrm": httpx.AsyncClient(
                base_url=f"https://vsrm.dev.azure.com/{organization}", **common_kwargs
            ),
            "feeds": httpx.AsyncClient(
                base_url=f"https://feeds.dev.azure.com/{organization}", **common_kwargs
            ),
            "analytics": httpx.AsyncClient(
                base_url=f"https://analytics.dev.azure.com/{organization}",
                **common_kwargs,
            ),
            "vssps": httpx.AsyncClient(
                base_url=f"https://vssps.dev.azure.com/{organization}", **common_kwargs
            ),
            "vsaex": httpx.AsyncClient(
                base_url=f"https://vsaex.dev.azure.com/{organization}", **common_kwargs
            ),
        }

    @property
    def api_version(self) -> str:
        return API_VERSION

    @property
    def organization(self) -> str:
        return self._organization


# Backwards-compatibility alias. Existing imports continue to work:
#   from ado_source_core.client import ADOClient
#   ado_source_core.ADOClient
# `isinstance(x, ADOClient)` matches cloud clients (alias preserves identity).
# Reflection-derived class names change: type(client).__name__ now returns
# "ADOCloudClient", not "ADOClient". See CHANGELOG [Unreleased].
ADOClient = ADOCloudClient
```

- [ ] **Step 2: Update imports at the top of `src/ado_source_core/client.py`**

Replace the existing import block (currently the first ~20 lines after the module docstring) with this exact block. Order matters — ruff `I` (isort) enforces it:

```python
from __future__ import annotations

import asyncio
import logging
from abc import ABC, abstractmethod
from datetime import UTC, datetime
from email.utils import parsedate_to_datetime
from http import HTTPStatus
from types import MappingProxyType, TracebackType
from typing import TYPE_CHECKING, Any, Self
from urllib.parse import urlparse

import httpx

from ado_source_core.exceptions import (
    APIError,
    AuthenticationError,
    ConfigError,
    RateLimitError,
)

if TYPE_CHECKING:
    from collections.abc import Mapping

    from ado_source_core.auth import PATAuth
```

Notes:
- `abc` is new (for `BaseADOClient(ABC)` + `@abstractmethod`).
- `MappingProxyType` is new (for `ADOServerClient.capability_overrides` in Task 2).
- `urllib.parse.urlparse` is new (for `_resolve_collection_base_url` in Task 2).
- `ConfigError` is new in the exceptions import (also for Task 2).
- The relative ordering above is what ruff's isort produces; pasting the block as-is avoids an `I001` lint failure on the next sweep.

- [ ] **Step 3: Update the module docstring of `client.py`**

Find the existing module docstring (top of file, lines 1–26) and append a new paragraph after the existing content describing the cloud host fanout:

```
**Class hierarchy (since v0.3.0):**

- ``BaseADOClient`` (abstract) — owns the ``request()`` retry / rate-limit /
  error-mapping loop, ``close()``, and the async context manager protocol.
- ``ADOCloudClient(BaseADOClient)`` — six pinned httpx clients for the
  cloud host fanout (``dev`` / ``vsrm`` / ``feeds`` / ``analytics`` /
  ``vssps`` / ``vsaex``); fixed ``api_version = "7.1"``.
- ``ADOServerClient(BaseADOClient)`` — single httpx client at the
  ``{base_url}/{collection}`` URL; auto-discovered ``api_version``.
- ``ADOClient = ADOCloudClient`` module-level alias preserves
  backwards compatibility for existing imports.

**Drift from previous shape:** the prior single concrete ``ADOClient`` class
is renamed to ``ADOCloudClient`` and the shared transport concerns are
extracted to ``BaseADOClient``. Existing call sites
(``ADOClient(organization=..., auth=...)``,
``client.request(method, url, host=...)``,
``client.httpx_client(host)``) work unchanged. Reflection-derived class
names (``type(client).__name__``) now return ``"ADOCloudClient"`` instead
of ``"ADOClient"`` — telemetry that keys on the old name needs updating.
```

- [ ] **Step 4: Run the new test to verify it passes**

```bash
pytest tests/unit/test_client_base.py -v
```

Expected: All 6 tests PASS.

- [ ] **Step 5: Run the existing client + adapter test suite to verify zero regression**

```bash
pytest tests/unit/test_client.py tests/unit/test_adapters_ado_cloud.py tests/unit/test_pagination.py -v
```

Expected: All existing tests PASS unchanged.

### Task 1.3 — Migrate `pagination.py` type annotations to `BaseADOClient`

- [ ] **Step 1: Edit `src/ado_source_core/pagination.py`**

Find the `if TYPE_CHECKING:` block (currently lines 43–44):

```python
if TYPE_CHECKING:
    from ado_source_core.client import ADOClient, HostName
```

Replace with:

```python
if TYPE_CHECKING:
    from ado_source_core.client import BaseADOClient, HostName
```

Then find every occurrence of `client: ADOClient` in the function signatures of `paginate_via_adoclient_continuation_token`, `paginate_via_adoclient_skip_top`, and `paginate_via_adoclient_body_continuation_token` (currently three occurrences), and replace each with `client: BaseADOClient`.

- [ ] **Step 2: Run pagination tests + cloud adapter tests to verify no regression**

```bash
pytest tests/unit/test_pagination.py tests/unit/test_adapters_ado_cloud.py -v
```

Expected: All tests PASS.

- [ ] **Step 3: Run mypy to verify type narrowing still works**

```bash
mypy src
```

Expected: `Success: no issues found in N source files`.

### Task 1.4 — Run full sweep, lint, and commit

- [ ] **Step 1: Run the full verification sweep**

```bash
ruff check src tests
ruff format --check src tests
mypy src
pytest -v
```

Expected: All clean.

- [ ] **Step 2: Stage and commit**

```bash
git add src/ado_source_core/client.py src/ado_source_core/pagination.py tests/unit/test_client_base.py
git commit -m "$(cat <<'EOF'
refactor(transport): extract BaseADOClient; alias ADOClient = ADOCloudClient

Pure refactor — zero behavior change for cloud consumers. Extracts the
shared retry/rate-limit/error-mapping loop into an abstract
BaseADOClient. The previous concrete ADOClient class is renamed to
ADOCloudClient; ADOClient becomes a module-level alias for backwards
compatibility. pagination.py type imports migrate from ADOClient to
BaseADOClient so the helpers type-check cleanly with both subclasses.

New tests/unit/test_client_base.py defines a tiny _TinyClient subclass
inside the test module to exercise the shared loop independently of
cloud or server, so future backends don't have to re-prove loop
semantics in their own suites.

Reflection-derived class names change: type(client).__name__ now
returns "ADOCloudClient" instead of "ADOClient" — telemetry / metrics
labels keyed on the old name need updating.

Sub-stage 1.4 of the Shyftport pilot extraction (Server adapter).
Spec: docs/superpowers/specs/2026-05-06-azure-devops-server-adapter-design.md

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

- [ ] **Step 3: Push**

```bash
git push
```

Expected: Push succeeds; the feature branch is updated on origin.

---

## Task 2: `ADOServerClient` — single-host, collection-aware, no discovery yet

**Goal:** Add the concrete `ADOServerClient` sibling. Construction-time only — no probe wiring yet (that comes in Task 3). Explicit `api_version=` is required at this stage; the discovery wiring lights up in Task 3.

**Files:**
- Modify: `src/ado_source_core/client.py`
- Modify: `src/ado_source_core/exceptions.py` (only if `ConfigError` needs no change — it's already there from earlier auth work)
- Create: `tests/unit/test_client_server.py`

### Task 2.1 — Write the failing tests for `ADOServerClient` construction + URL normalization

- [ ] **Step 1: Create `tests/unit/test_client_server.py` with construction tests**

```python
"""ADOServerClient construction + transport tests.

Construction-only at this stage (Task 2). The connect() probe wiring is
exercised in Task 3 once api_version_discovery lands.
"""

from __future__ import annotations

import asyncio
from typing import Any

import httpx
import pytest
import respx

from ado_source_core import ConfigError, PATAuth
from ado_source_core.client import ADOServerClient, BaseADOClient


_BASE = "https://devops.example.com:8080/tfs"
_COLLECTION = "DefaultCollection"
_RESOLVED = f"{_BASE}/{_COLLECTION}"


@pytest.fixture
def auth() -> PATAuth:
    return PATAuth(token="dummy-pat")


def _make_client(auth: PATAuth, **overrides: Any) -> ADOServerClient:
    kwargs: dict[str, Any] = {
        "base_url": _BASE,
        "collection": _COLLECTION,
        "auth": auth,
        "api_version": "7.0",  # bypasses probe at this stage
        "max_retries": 3,
    }
    kwargs.update(overrides)
    return ADOServerClient(**kwargs)


async def _instant_sleep(_seconds: float) -> None:
    return None


@pytest.fixture(autouse=True)
def _no_sleep(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(asyncio, "sleep", _instant_sleep)


class TestConstruction:
    def test_subclasses_base(self, auth: PATAuth) -> None:
        client = _make_client(auth)
        assert isinstance(client, BaseADOClient)

    def test_builds_single_httpx_client(self, auth: PATAuth) -> None:
        client = _make_client(auth)
        single = client.httpx_client("dev")
        assert str(single.base_url).rstrip("/") == _RESOLVED

    def test_all_logical_hosts_alias_to_same_client(self, auth: PATAuth) -> None:
        client = _make_client(auth)
        dev = client.httpx_client("dev")
        for host in ("vsrm", "feeds", "analytics", "vssps", "vsaex"):
            assert client.httpx_client(host) is dev

    def test_authorization_header_attached(self, auth: PATAuth) -> None:
        client = _make_client(auth)
        assert client.httpx_client("dev").headers["Authorization"].startswith("Basic ")

    def test_collection_property(self, auth: PATAuth) -> None:
        client = _make_client(auth)
        assert client.collection == _COLLECTION

    def test_explicit_api_version_bypasses_probe(self, auth: PATAuth) -> None:
        client = _make_client(auth, api_version="6.0")
        assert client.api_version == "6.0"
        assert client.resolved_api_version == "6.0"

    def test_resolved_api_version_is_none_before_connect_when_no_explicit(
        self, auth: PATAuth
    ) -> None:
        client = ADOServerClient(
            base_url=_BASE, collection=_COLLECTION, auth=auth,
            # NO api_version passed
        )
        assert client.resolved_api_version is None

    def test_api_version_property_raises_runtime_error_before_connect(
        self, auth: PATAuth
    ) -> None:
        client = ADOServerClient(
            base_url=_BASE, collection=_COLLECTION, auth=auth,
        )
        with pytest.raises(RuntimeError, match="not connected"):
            _ = client.api_version


class TestUrlNormalization:
    @pytest.mark.parametrize(
        ("base_url", "collection", "expected"),
        [
            (
                "https://devops/",
                "DefaultCollection",
                "https://devops/DefaultCollection",
            ),
            (
                "https://devops:8080/tfs",
                "DefaultCollection",
                "https://devops:8080/tfs/DefaultCollection",
            ),
            (
                "https://devops/tfs/DefaultCollection",
                "DefaultCollection",
                "https://devops/tfs/DefaultCollection",
            ),
            (
                "https://devops/tfs/DefaultCollection/",
                "DefaultCollection",
                "https://devops/tfs/DefaultCollection",
            ),
        ],
    )
    def test_collection_url_normalization(
        self, auth: PATAuth, base_url: str, collection: str, expected: str,
    ) -> None:
        client = ADOServerClient(
            base_url=base_url, collection=collection, auth=auth, api_version="7.0",
        )
        assert str(client.httpx_client("dev").base_url).rstrip("/") == expected

    def test_embedded_basic_auth_in_base_url_raises_config_error(
        self, auth: PATAuth
    ) -> None:
        with pytest.raises(ConfigError, match="embedded credentials"):
            ADOServerClient(
                base_url="https://user:pass@devops/tfs",
                collection="DefaultCollection",
                auth=auth,
                api_version="7.0",
            )


class TestSelectClient:
    @pytest.mark.parametrize("host", ["dev", "vsrm", "feeds", "analytics", "vssps", "vsaex"])
    def test_select_client_returns_single_client_for_every_host(
        self, auth: PATAuth, host: str
    ) -> None:
        client = _make_client(auth)
        assert client.httpx_client(host) is client.httpx_client("dev")

    @pytest.mark.asyncio
    async def test_close_closes_single_client_once(self, auth: PATAuth) -> None:
        client = _make_client(auth)
        single = client.httpx_client("dev")
        await client.close()
        assert single.is_closed
        # Idempotent — second close() must not raise.
        await client.close()


class TestAenterCloseOnConnectFailure:
    """At Task 2 stage, connect() raises NotImplementedError unless an explicit
    api_version is set. Verify __aenter__ closes the httpx client when
    connect() raises so a probe failure does not leak the underlying socket."""

    @pytest.mark.asyncio
    async def test_close_runs_when_connect_raises(self, auth: PATAuth) -> None:
        # No explicit api_version=, so connect() will raise NotImplementedError.
        client = ADOServerClient(
            base_url=_BASE, collection=_COLLECTION, auth=auth,
        )
        single = client.httpx_client("dev")
        with pytest.raises(NotImplementedError):
            await client.__aenter__()
        assert single.is_closed


class TestRequest:
    @pytest.mark.asyncio
    async def test_api_version_query_param_uses_explicit_value(
        self, auth: PATAuth
    ) -> None:
        async with _make_client(auth, api_version="6.0") as client:
            with respx.mock(base_url=_RESOLVED) as mock:
                route = mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                await client.request("GET", "/_apis/projects")
                assert route.calls[0].request.url.params["api-version"] == "6.0"

    @pytest.mark.asyncio
    async def test_skip_api_version_omits_param(self, auth: PATAuth) -> None:
        async with _make_client(auth) as client:
            with respx.mock(base_url=_RESOLVED) as mock:
                route = mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={})
                )
                await client.request(
                    "GET", "/_apis/connectionData", skip_api_version=True
                )
                assert "api-version" not in route.calls[0].request.url.params
```

- [ ] **Step 2: Run the test to verify it fails**

```bash
pytest tests/unit/test_client_server.py -v 2>&1 | head -30
```

Expected: All tests fail with `ImportError: cannot import name 'ADOServerClient' from 'ado_source_core.client'`.

### Task 2.2 — Implement `ADOServerClient` + `_resolve_collection_base_url`

- [ ] **Step 1: Add `_resolve_collection_base_url` helper to `src/ado_source_core/client.py`**

Insert at module level (after `_extract_response_body` and before `HostName = str`):

```python
def _resolve_collection_base_url(base_url: str, collection: str) -> str:
    """Normalize ``{base_url}/{collection}`` into a single URL.

    Lifted from ``ado2gh-core/src/ado2gh/adapters/ado_server.py:18`` @
    ``160de58``. Drift: rejects embedded basic auth in ``base_url``
    (donor allowed it, which conflicts with the PAT ``Authorization``
    header and creates a credential-leak risk).

    Strips a trailing slash. If ``base_url`` already ends with
    ``/{collection}``, returns it unchanged (no double-suffixing).
    Raises :class:`ConfigError` if ``base_url`` contains embedded
    ``user:password@`` credentials.
    """
    parsed = urlparse(base_url)
    if parsed.username or parsed.password:
        raise ConfigError(
            "base_url must not contain embedded credentials "
            "(found user:password@host); use the `auth=` argument instead.",
            field="base_url",
        )
    root = base_url.rstrip("/")
    suffix = f"/{collection}"
    if root.endswith(suffix):
        return root
    return f"{root}{suffix}"
```

No additional import edits — `urlparse`, `ConfigError`, and `MappingProxyType` were all added in Task 1.2 Step 2 above (Task 1's full sorted import block already includes them in anticipation of Task 2's needs).

- [ ] **Step 2: Add `ADOServerClient` class to `src/ado_source_core/client.py`**

Insert after the `ADOClient = ADOCloudClient` alias line:

```python
class ADOServerClient(BaseADOClient):
    """Concrete HTTP client for self-hosted Azure DevOps Server (on-prem).

    Single-host, collection-aware. The api-version is auto-discovered at
    ``connect()`` time via :mod:`ado_source_core.api_version_discovery`,
    or pinned explicitly by passing ``api_version=`` to ``__init__``.

    All six logical host names (``dev`` / ``vsrm`` / ``feeds`` /
    ``analytics`` / ``vssps`` / ``vsaex``) alias to the single underlying
    httpx client — calls that pass an explicit ``host=`` argument are
    route-safe but the URL is always the collection-scoped base.

    Two-phase init: ``__init__`` is sync and never makes HTTP calls;
    ``connect()`` runs the probe. The ``async with`` form runs
    ``connect()`` automatically via ``__aenter__``, with a ``try/except``
    wrapper that closes the httpx client and re-raises if the probe
    fails — preventing socket leaks on auth or network errors during
    context entry.
    """

    def __init__(  # noqa: PLR0913 - configuration knobs are keyword-only
        self,
        *,
        base_url: str,
        collection: str,
        auth: PATAuth,
        verify_ssl: bool | str = True,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
        max_retries: int = DEFAULT_MAX_RETRIES,
        api_version: str | None = None,
    ) -> None:
        self._max_retries = max_retries
        self._collection = collection
        self._collection_base_url = _resolve_collection_base_url(base_url, collection)
        self._explicit_api_version = api_version
        self._resolved_api_version: str | None = api_version
        self._graph_api_version: str | None = None
        self._capability_overrides: dict[str, bool] = {}
        self._capability_notes: list[str] = []

        common_kwargs: dict[str, Any] = {
            "headers": {"Accept": "application/json", **auth.headers()},
            "verify": verify_ssl,
            "timeout": timeout,
        }
        single = httpx.AsyncClient(base_url=self._collection_base_url, **common_kwargs)
        # All logical hosts route to the same single httpx client. The
        # adapter is responsible for capability-gating any call that would
        # hit an endpoint missing on Server (vssps Graph, vsaex member
        # entitlements, analytics OData) BEFORE the request goes out.
        self._clients = {h: single for h in ("dev", "vsrm", "feeds", "analytics", "vssps", "vsaex")}

    @property
    def api_version(self) -> str:
        if self._resolved_api_version is None:
            raise RuntimeError(
                "ADOServerClient is not connected — use `async with` or call "
                "`await client.connect()` before issuing requests."
            )
        return self._resolved_api_version

    @property
    def resolved_api_version(self) -> str | None:
        """Diagnostic accessor: ``None`` until ``connect()`` runs (or until an
        explicit ``api_version=`` was passed to ``__init__``)."""
        return self._resolved_api_version

    @property
    def capability_overrides(self) -> Mapping[str, bool]:
        """Read-only view of probe-discovered soft-capability overrides.
        Empty until ``connect()`` runs."""
        return MappingProxyType(self._capability_overrides)

    @property
    def graph_api_version(self) -> str | None:
        """The api-version variant that worked for the Graph soft-cap probe
        (e.g. ``"7.0-preview.1"`` or plain ``"7.0"``). ``None`` until
        ``connect()`` runs OR when the Graph capability is False.

        Adapter-level callers (``list_users``) MUST use this value, not
        ``api_version``, to send requests to ``/_apis/graph/users``."""
        return self._graph_api_version

    @property
    def capability_notes(self) -> tuple[str, ...]:
        """Read-only view of probe-time diagnostic notes (e.g., PAT scope
        ambiguity warnings). Empty until ``connect()`` runs."""
        return tuple(self._capability_notes)

    @property
    def collection(self) -> str:
        return self._collection

    async def connect(self) -> None:
        """Run the api-version + soft-capability probe. Idempotent.

        Wired in Task 3 once :mod:`ado_source_core.api_version_discovery`
        lands. At this stage (Task 2), an explicit ``api_version=`` to
        ``__init__`` is required.
        """
        if self._resolved_api_version is not None:
            return
        raise NotImplementedError(
            "api_version_discovery wiring lands in Task 3. "
            "Pass api_version= to __init__ to bypass probing for now."
        )

    async def __aenter__(self) -> Self:
        try:
            await self.connect()
        except BaseException:
            # Don't leak the httpx client built in __init__.
            await self.close()
            raise
        return self
```

No additional import edits — `MappingProxyType` was already added in Task 1.2 Step 2.

- [ ] **Step 3: Run the new tests to verify they pass**

```bash
pytest tests/unit/test_client_server.py -v
```

Expected: All construction + url-normalization + select-client + request tests PASS.

- [ ] **Step 4: Run the full unit suite to verify zero regression**

```bash
ruff check src tests && ruff format --check src tests && mypy src && pytest -v
```

Expected: All clean.

### Task 2.3 — Re-export `ADOServerClient` and `BaseADOClient` from `ado_source_core`

- [ ] **Step 1: Edit `src/ado_source_core/__init__.py`**

Add to the `from ado_source_core.client import` line:

```python
from ado_source_core.client import ADOClient, ADOCloudClient, ADOServerClient, BaseADOClient
```

Insert into `__all__`:

```python
"ADOClient",
"ADOCloudClient",
"ADOServerClient",
...
"BaseADOClient",
```

The existing list is mostly alphabetical except for `"DEFAULT_ADO_BASE_URL"` which sits before `"ADOClient"`. Don't try to "fix" that ordering in this PR — leave existing entries in place and insert the new entries in their alphabetical slots. Run `python -c "import ast, sys; src=open('src/ado_source_core/__init__.py').read(); print(src.count('\"ADO'))"` after the edit as a sanity check that you added the expected number of new `\"ADO*\"` entries.

- [ ] **Step 2: Run the import-shape test to verify**

```bash
python -c "from ado_source_core import ADOClient, ADOCloudClient, ADOServerClient, BaseADOClient; print('OK')"
```

Expected: `OK`.

### Task 2.4 — Commit

- [ ] **Step 1: Full sweep**

```bash
ruff check src tests && ruff format --check src tests && mypy src && pytest -v
```

- [ ] **Step 2: Commit**

```bash
git add src/ado_source_core/client.py src/ado_source_core/__init__.py tests/unit/test_client_server.py
git commit -m "$(cat <<'EOF'
feat(transport): add ADOServerClient (single-host, collection-aware)

Adds ADOServerClient as a sibling of ADOCloudClient on top of the
abstract BaseADOClient extracted in the prior commit. Single httpx
client at {base_url}/{collection}; all six logical host names alias
to the same client so inherited paginators that pass host=... are
route-safe.

Construction-only: connect() raises NotImplementedError unless an
explicit api_version= was passed to __init__. The api_version_discovery
wiring lands in the next commit.

_resolve_collection_base_url normalizes the base URL (strips trailing
slash, avoids double-suffixing) and rejects embedded user:pass@host
basic auth in the URL — that conflicts with the PAT Authorization
header and creates a credential-leak risk. Drift from donor
ado_server.py @ 160de58: donor accepted embedded auth.

__aenter__ wraps connect() in try/except + close() so a failed probe
does not leak the httpx client. Tests assert the close-on-failure
path lands in Task 3 alongside the discovery wiring.

Spec: docs/superpowers/specs/2026-05-06-azure-devops-server-adapter-design.md

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

- [ ] **Step 3: Push**

```bash
git push
```

---

## Task 3: `api_version_discovery` module + wire into `ADOServerClient.connect()`

**Goal:** Add the discovery module with `connectionData` probe + candidate iteration fallback + soft-capability probing. Wire it into `ADOServerClient.connect()`. Add `__aenter__` close-on-failure test.

**Files:**
- Create: `src/ado_source_core/api_version_discovery.py`
- Modify: `src/ado_source_core/client.py` (replace `connect()` body)
- Modify: `src/ado_source_core/__init__.py` (re-export discovery symbols)
- Create: `tests/unit/test_api_version_discovery.py`
- Modify: `tests/unit/test_client_server.py` (add `TestConnect` class)

### Task 3.1 — Write the failing tests for `resolve_server_api_version`

- [ ] **Step 1: Create `tests/unit/test_api_version_discovery.py`**

```python
"""api_version_discovery module tests.

Covers:
- connectionData success path (parametrized over advertised versions)
- connectionData missing/malformed apiVersion → fall through
- candidate iteration paths (each candidate succeeds first try)
- candidate iteration: all fail → APIError
- auth error during version probe → AuthenticationError propagates
- soft-capability probes: 200/404/401/429/5xx handling
- Graph preview-suffix retry on 400
- Analytics collection→project fallback on 404
- soft-cap probes run concurrently
"""

from __future__ import annotations

import asyncio
from typing import Any

import httpx
import pytest
import respx

from ado_source_core import (
    APIError,
    AuthenticationError,
    PATAuth,
    RateLimitError,
)
from ado_source_core.api_version_discovery import (
    SERVER_API_VERSION_CANDIDATES,
    ServerProbeResult,
    resolve_server_api_version,
)
from ado_source_core.client import ADOServerClient


_BASE = "https://devops.example.com/tfs"
_COLLECTION = "DefaultCollection"
_RESOLVED = f"{_BASE}/{_COLLECTION}"


@pytest.fixture
def auth() -> PATAuth:
    return PATAuth(token="dummy-pat")


@pytest.fixture
def client(auth: PATAuth) -> ADOServerClient:
    """A non-connected ADOServerClient with no explicit api_version."""
    return ADOServerClient(
        base_url=_BASE, collection=_COLLECTION, auth=auth, max_retries=2,
    )


async def _instant_sleep(_seconds: float) -> None:
    return None


@pytest.fixture(autouse=True)
def _no_sleep(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(asyncio, "sleep", _instant_sleep)


def _all_caps_ok(mock: respx.MockRouter) -> None:
    """Set up the 3 soft-cap probe mocks to return 200, so a happy version
    probe doesn't choke on the cap probes."""
    mock.get("/_apis/graph/users").mock(return_value=httpx.Response(200, json={"value": []}))
    mock.get("/_odata/v4.0-preview/$metadata").mock(return_value=httpx.Response(200, text="<edmx/>"))
    mock.get("/_apis/packaging/feeds").mock(return_value=httpx.Response(200, json={"value": []}))


class TestResolveSnapping:
    @pytest.mark.parametrize(
        ("advertised", "expected"),
        [
            ("7.0", "7.0"),
            ("7.1", "7.0"),
            ("6.0", "6.0"),
            ("5.1", "5.1"),
            ("5.0", "5.0"),
        ],
    )
    @pytest.mark.asyncio
    async def test_advertised_snaps_to_highest_candidate_le(
        self, auth: PATAuth, advertised: str, expected: str
    ) -> None:
        client = ADOServerClient(
            base_url=_BASE, collection=_COLLECTION, auth=auth, max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": advertised})
                )
                _all_caps_ok(mock)
                result = await resolve_server_api_version(client)
                assert result.api_version == expected
                assert result.probe_strategy == "connection_data"
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_advertised_below_lowest_candidate_falls_through(
        self, auth: PATAuth
    ) -> None:
        # advertised "4.1" is below all candidates → fall through to candidate iteration.
        client = ADOServerClient(
            base_url=_BASE, collection=_COLLECTION, auth=auth, max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "4.1"})
                )
                # Candidate iteration: 7.0 returns 400, 6.0 returns 200.
                projects_route = mock.get("/_apis/projects").mock(
                    side_effect=[
                        httpx.Response(400),
                        httpx.Response(200, json={"value": [{"name": "P1"}]}),
                    ]
                )
                _all_caps_ok(mock)
                result = await resolve_server_api_version(client)
                assert result.api_version == "6.0"
                assert result.probe_strategy == "candidate_iteration"
                assert projects_route.call_count == 2
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_connection_data_404_falls_through(self, auth: PATAuth) -> None:
        client = ADOServerClient(
            base_url=_BASE, collection=_COLLECTION, auth=auth, max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(return_value=httpx.Response(404))
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(200, json={"value": [{"name": "P1"}]})
                )
                _all_caps_ok(mock)
                result = await resolve_server_api_version(client)
                assert result.api_version == "7.0"
                assert result.probe_strategy == "candidate_iteration"
        finally:
            await client.close()

    @pytest.mark.parametrize(
        "payload",
        [
            {},                                       # missing apiVersion
            {"apiVersion": ""},                       # empty
            {"apiVersion": "7"},                      # one component
            {"apiVersion": "7.0.0"},                  # three components
            {"apiVersion": "7.x"},                    # non-int component
            {"apiVersion": 7.0},                      # non-string
            {"locationServiceData": {"apiVersion": "7.0"}},  # nested success
        ],
    )
    @pytest.mark.asyncio
    async def test_connection_data_payload_shapes(
        self, auth: PATAuth, payload: dict[str, Any]
    ) -> None:
        client = ADOServerClient(
            base_url=_BASE, collection=_COLLECTION, auth=auth, max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json=payload)
                )
                # If the parser extracts a valid version, no candidate
                # iteration happens. If it falls through, candidate
                # iteration succeeds on 7.0.
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(200, json={"value": [{"name": "P1"}]})
                )
                _all_caps_ok(mock)
                result = await resolve_server_api_version(client)
                assert result.api_version == "7.0"
        finally:
            await client.close()


class TestCandidateIteration:
    @pytest.mark.parametrize("first_ok", SERVER_API_VERSION_CANDIDATES)
    @pytest.mark.asyncio
    async def test_each_candidate_succeeds_first(
        self, auth: PATAuth, first_ok: str
    ) -> None:
        client = ADOServerClient(
            base_url=_BASE, collection=_COLLECTION, auth=auth, max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(return_value=httpx.Response(404))
                # Build a side_effect list that returns 400 for every
                # candidate above first_ok and 200 starting at first_ok.
                idx = SERVER_API_VERSION_CANDIDATES.index(first_ok)
                effects = [httpx.Response(400)] * idx + [
                    httpx.Response(200, json={"value": [{"name": "P1"}]})
                ]
                mock.get("/_apis/projects").mock(side_effect=effects)
                _all_caps_ok(mock)
                result = await resolve_server_api_version(client)
                assert result.api_version == first_ok
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_all_candidates_fail_raises_api_error(self, auth: PATAuth) -> None:
        client = ADOServerClient(
            base_url=_BASE, collection=_COLLECTION, auth=auth, max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(return_value=httpx.Response(404))
                mock.get("/_apis/projects").mock(return_value=httpx.Response(400))
                with pytest.raises(APIError, match="Unable to determine"):
                    await resolve_server_api_version(client)
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_auth_error_during_version_probe_propagates(
        self, auth: PATAuth
    ) -> None:
        client = ADOServerClient(
            base_url=_BASE, collection=_COLLECTION, auth=auth, max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(return_value=httpx.Response(404))
                mock.get("/_apis/projects").mock(return_value=httpx.Response(401))
                with pytest.raises(AuthenticationError):
                    await resolve_server_api_version(client)
        finally:
            await client.close()


class TestSoftCapabilityProbes:
    @pytest.mark.asyncio
    async def test_graph_200_on_preview_suffix_records_preview_variant(
        self, auth: PATAuth,
    ) -> None:
        """When the preview-suffix probe succeeds first, the result must
        carry ``graph_api_version="7.0-preview.1"`` so list_users uses
        the preview suffix at call time."""
        client = ADOServerClient(
            base_url=_BASE, collection=_COLLECTION, auth=auth, max_retries=2,
        )
        try:
            # Also need a project for the connectionData-success Analytics
            # fallback hint (added in the synthesis pass).
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "7.0"})
                )
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(
                        200, json={"value": [{"name": "ProjA"}]},
                    )
                )
                _all_caps_ok(mock)
                result = await resolve_server_api_version(client)
                assert result.capability_overrides["supports_graph_api"] is True
                # Default _all_caps_ok mock matches both preview and plain
                # variants on the first call, so the preview suffix wins.
                assert result.graph_api_version == "7.0-preview.1"
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_graph_400_invalid_api_version_retries_plain(
        self, auth: PATAuth,
    ) -> None:
        """When preview returns 400 InvalidApiVersion, retry plain — the
        result must record ``graph_api_version="7.0"`` (plain)."""
        client = ADOServerClient(
            base_url=_BASE, collection=_COLLECTION, auth=auth, max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "7.0"})
                )
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(
                        200, json={"value": [{"name": "ProjA"}]},
                    )
                )
                mock.get("/_odata/v4.0-preview/$metadata").mock(
                    return_value=httpx.Response(200, text="<edmx/>")
                )
                mock.get("/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                # First Graph call (preview suffix) returns 400 with the
                # InvalidPreviewVersion typeKey, second (plain) returns 200.
                graph_route = mock.get("/_apis/graph/users").mock(
                    side_effect=[
                        httpx.Response(
                            400,
                            json={"typeKey": "VssInvalidPreviewVersionException"},
                        ),
                        httpx.Response(200, json={"value": []}),
                    ]
                )
                result = await resolve_server_api_version(client)
                assert result.capability_overrides["supports_graph_api"] is True
                assert result.graph_api_version == "7.0"
                assert graph_route.call_count == 2
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_graph_400_unrelated_propagates(self, auth: PATAuth) -> None:
        """A 400 that is NOT InvalidApiVersion must propagate, not silently
        try the next variant."""
        client = ADOServerClient(
            base_url=_BASE, collection=_COLLECTION, auth=auth, max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "7.0"})
                )
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(
                        200, json={"value": [{"name": "ProjA"}]},
                    )
                )
                mock.get("/_odata/v4.0-preview/$metadata").mock(
                    return_value=httpx.Response(200, text="<edmx/>")
                )
                mock.get("/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                mock.get("/_apis/graph/users").mock(
                    return_value=httpx.Response(
                        400, json={"typeKey": "VssSomeOtherException"},
                    )
                )
                with pytest.raises(APIError):
                    await resolve_server_api_version(client)
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_graph_404_marks_false(self, auth: PATAuth) -> None:
        client = ADOServerClient(
            base_url=_BASE, collection=_COLLECTION, auth=auth, max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "7.0"})
                )
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(
                        200, json={"value": [{"name": "ProjA"}]},
                    )
                )
                mock.get("/_apis/graph/users").mock(return_value=httpx.Response(404))
                mock.get("/_odata/v4.0-preview/$metadata").mock(
                    return_value=httpx.Response(200, text="<edmx/>")
                )
                mock.get("/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                result = await resolve_server_api_version(client)
                assert result.capability_overrides["supports_graph_api"] is False
                assert result.graph_api_version is None
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_graph_401_marks_false_with_diagnostic_note(
        self, auth: PATAuth,
    ) -> None:
        client = ADOServerClient(
            base_url=_BASE, collection=_COLLECTION, auth=auth, max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "7.0"})
                )
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(
                        200, json={"value": [{"name": "ProjA"}]},
                    )
                )
                mock.get("/_apis/graph/users").mock(return_value=httpx.Response(401))
                mock.get("/_odata/v4.0-preview/$metadata").mock(
                    return_value=httpx.Response(200, text="<edmx/>")
                )
                mock.get("/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                result = await resolve_server_api_version(client)
                assert result.capability_overrides["supports_graph_api"] is False
                assert result.graph_api_version is None
                assert any("supports_graph_api" in n for n in result.capability_notes)
                assert any(
                    "PAT" in n or "scope" in n for n in result.capability_notes
                )
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_analytics_collection_404_falls_back_project_scoped(
        self, auth: PATAuth
    ) -> None:
        client = ADOServerClient(
            base_url=_BASE, collection=_COLLECTION, auth=auth, max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "7.0"})
                )
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(200, json={"value": [{"name": "ProjA"}]})
                )
                mock.get("/_apis/graph/users").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                mock.get("/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                # Collection-scoped 404, project-scoped 200.
                mock.get("/_odata/v4.0-preview/$metadata").mock(
                    return_value=httpx.Response(404)
                )
                mock.get("/ProjA/_odata/v4.0-preview/$metadata").mock(
                    return_value=httpx.Response(200, text="<edmx/>")
                )
                result = await resolve_server_api_version(client)
                assert result.capability_overrides["supports_analytics_odata"] is True
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_429_during_cap_probe_propagates(self, auth: PATAuth) -> None:
        client = ADOServerClient(
            base_url=_BASE, collection=_COLLECTION, auth=auth, max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "7.0"})
                )
                mock.get("/_apis/graph/users").mock(
                    return_value=httpx.Response(429, headers={"Retry-After": "1"})
                )
                mock.get("/_odata/v4.0-preview/$metadata").mock(
                    return_value=httpx.Response(200, text="<edmx/>")
                )
                mock.get("/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                with pytest.raises(RateLimitError):
                    await resolve_server_api_version(client)
        finally:
            await client.close()


class TestServerProbeResultDataclass:
    def test_default_field_values(self) -> None:
        r = ServerProbeResult(api_version="7.0")
        assert r.api_version == "7.0"
        assert r.capability_overrides == {}
        assert r.capability_notes == []
        assert r.probe_strategy == "connection_data"

    def test_frozen(self) -> None:
        from dataclasses import FrozenInstanceError

        r = ServerProbeResult(api_version="7.0")
        with pytest.raises(FrozenInstanceError):
            r.api_version = "9.9"  # type: ignore[misc]
```

- [ ] **Step 2: Run the test to verify all fail**

```bash
pytest tests/unit/test_api_version_discovery.py -v 2>&1 | head -30
```

Expected: All fail with `ImportError: cannot import name ... from 'ado_source_core.api_version_discovery'`.

### Task 3.2 — Implement `api_version_discovery.py`

- [ ] **Step 1: Create `src/ado_source_core/api_version_discovery.py`**

```python
"""Server REST api-version discovery + soft-capability probing.

Lifted from ``n8group-oss/ado2gh-core/src/ado2gh/adapters/ado_server.py`` @
``160de58``, specifically the ``_probe_supported_api_version`` method
(donor lines 101-119). Re-licensed BUSL-1.1 -> MIT under the sole-author
consent path documented in
``shyftport-specs/plans/audit/migration-core-base-decision.md``.

**Drift from donor:**

1. Probes ``/_apis/connectionData`` first; donor went straight to
   candidate iteration. Reason: cuts typical construction cost from
   up-to-4 round-trips to 1 when connectionData exposes a parseable
   apiVersion.
2. Folds three soft-capability probes (Graph / Analytics / Package
   Management) into the same probe pass, executed in parallel via
   ``asyncio.gather``. Donor had no equivalent — it hard-coded
   ``supports_user_entitlements=False`` and short-circuited
   ``query_work_item_counts`` via ``compatibility_mode``.
3. Returns a structured ``ServerProbeResult`` (frozen dataclass) instead
   of a bare api-version string. Reason: soft-cap probes need to fan out
   structured results — overrides for the flag set + diagnostic notes
   for ambiguity (PAT-scope-may-be-missing cases).
4. Soft-cap probes that get 401/403 mark the capability ``False`` AND
   record a diagnostic note, instead of propagating. Preserves
   usability when a PAT lacks one specific scope (e.g., ``vso.analytics``)
   but is otherwise valid.
5. Graph soft-cap probe + ``list_users`` use a probe-resolved
   preview-suffix-aware api-version (try ``-preview.1`` first, fall back
   to plain on ``400 InvalidApiVersion``), matching Microsoft's
   per-deployment variation.
6. Analytics soft-cap probe falls back from collection-scoped to
   project-scoped on 404 — Server 2019 may not expose collection-level
   metadata even when Analytics is installed.
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from http import HTTPStatus
from typing import TYPE_CHECKING, Any

from ado_source_core.exceptions import APIError, AuthenticationError

if TYPE_CHECKING:
    from ado_source_core.client import ADOServerClient

logger = logging.getLogger(__name__)


SERVER_API_VERSION_CANDIDATES: tuple[str, ...] = ("7.0", "6.0", "5.1", "5.0")
"""Supported REST api-versions for ADO Server, highest first.

- ``7.0`` -> Azure DevOps Server 2022
- ``6.0`` -> Azure DevOps Server 2020
- ``5.1`` -> Azure DevOps Server 2019 Update 1+
- ``5.0`` -> Azure DevOps Server 2019 RTW

TFS 2018 (REST 4.x) and earlier are out of scope for v0.3.0.
"""


@dataclass(frozen=True)
class ServerProbeResult:
    """Result of a one-shot probe at ``ADOServerClient.connect()`` time.

    .. note::
        ``frozen=True`` is shallow — the contained ``capability_overrides``
        dict and ``capability_notes`` list are still mutable. Treat them
        as read-only after construction; the dataclass-frozen guarantee
        only prevents reassigning the top-level attributes.
    """

    api_version: str
    """The resolved REST api-version (e.g. ``"7.0"``)."""

    graph_api_version: str | None = None
    """The api-version variant that worked for the Graph soft-cap probe
    (e.g. ``"7.0-preview.1"`` or plain ``"7.0"``). ``None`` when the
    Graph capability is False (probe failed). The adapter's ``list_users``
    must use this value, NOT the plain ``api_version``, to avoid the
    cloud-vs-server preview-suffix mismatch."""

    capability_overrides: dict[str, bool] = field(default_factory=dict)
    capability_notes: list[str] = field(default_factory=list)
    probe_strategy: str = "connection_data"


async def resolve_server_api_version(client: ADOServerClient) -> ServerProbeResult:
    """Resolve the highest mutually-supported REST api-version + soft caps.

    Args:
        client: A non-connected :class:`ADOServerClient` (no explicit
            ``api_version=`` passed to ``__init__``).

    Returns:
        A :class:`ServerProbeResult` with the resolved api-version, the
        three soft-capability overrides, any diagnostic notes from the
        probe, and the strategy used (``"connection_data"`` if
        connectionData succeeded, ``"candidate_iteration"`` otherwise).

    Raises:
        AuthenticationError: If the version probe (NOT a soft-cap probe)
            returns 401 or 403. Soft-cap auth failures take the
            diagnostic-note path so a missing-scope PAT doesn't crash
            discovery for endpoints the same PAT IS authorized for.
        APIError: If every candidate api-version returns 4xx/5xx.
        RateLimitError: If 429 hits during any probe step.

    Round-trip cost (sequential phases; each phase is one wallclock unit):

    - **Best case** (connectionData exposes parseable apiVersion):
      1 connectionData + 1 ``/_apis/projects?$top=1`` (for Analytics
      fallback hint) + 1 wallclock unit for 3 parallel soft-cap probes
      = **3 sequential phases**.
    - **Worst case** (connectionData unreachable + every candidate up to
      the last fails + Graph needs preview retry + Analytics needs
      project-scoped fallback): up to 1 + 4 + ~3 = **8 sequential calls**
      before the result lands.

    The extra ``/_apis/projects`` round-trip on the connectionData-success
    path is a deliberate cost: without it, the Analytics soft-cap probe
    cannot fall back to project-scoped ``$metadata`` on Server 2019
    deployments where the collection-level URL 404s. Since the probe
    runs once per ``ADOServerClient.connect()``, the cost is amortized
    across the adapter's lifetime.
    """
    # Phase 1: try connectionData first.
    advertised = await _fetch_connection_data_api_version(client)
    api_version: str
    probe_strategy: str
    first_project: str | None = None
    if advertised is not None and (snapped := _snap_to_candidate(advertised)) is not None:
        api_version = snapped
        probe_strategy = "connection_data"
        # Even on connectionData success, fetch one project name so the
        # Analytics soft-cap probe can fall back to project-scoped
        # /_odata/$metadata on a 404 (Server 2019 may not expose
        # collection-level $metadata even when Analytics is installed).
        first_project = await _fetch_first_project_name(
            client, api_version=api_version,
        )
    else:
        # Phase 2: candidate iteration. Returns (api_version, first_project_name).
        api_version, first_project = await _iterate_candidates(client)
        probe_strategy = "candidate_iteration"

    # Phase 3: soft-capability probes (parallel).
    overrides, notes, graph_api_version = await _probe_soft_capabilities(
        client, api_version=api_version, project_hint=first_project,
    )

    return ServerProbeResult(
        api_version=api_version,
        graph_api_version=graph_api_version,
        capability_overrides=overrides,
        capability_notes=notes,
        probe_strategy=probe_strategy,
    )


async def _fetch_first_project_name(
    client: ADOServerClient, *, api_version: str,
) -> str | None:
    """Best-effort: fetch the first project name. Returns None on any error
    (this is only for the Analytics fallback hint; failures are non-fatal)."""
    try:
        response = await client.request(
            "GET", "/_apis/projects",
            params={"$top": "1", "api-version": api_version},
            skip_api_version=True,
        )
    except (APIError, AuthenticationError):
        return None
    try:
        value = response.json().get("value", [])
        if value:
            name = value[0].get("name")
            return name if isinstance(name, str) else None
    except (ValueError, KeyError, TypeError, IndexError):
        pass
    return None


async def _fetch_connection_data_api_version(client: ADOServerClient) -> str | None:
    """``GET /_apis/connectionData`` with ``skip_api_version=True``.

    Returns the parsed ``apiVersion`` (top-level or under
    ``locationServiceData``), or ``None`` if the response is unreachable
    or unparseable. Auth errors propagate.
    """
    try:
        response = await client.request(
            "GET", "/_apis/connectionData", skip_api_version=True,
        )
    except AuthenticationError:
        raise
    except APIError:
        return None
    try:
        payload = response.json()
    except ValueError:
        return None
    return _extract_advertised_api_version(payload)


def _extract_advertised_api_version(payload: Any) -> str | None:
    """Return the first path that contains a parseable ``<int>.<int>`` version.

    If the top-level ``apiVersion`` is present but malformed (empty string,
    wrong type, wrong shape), fall through and try the nested
    ``locationServiceData.apiVersion`` path before giving up.
    """
    if not isinstance(payload, dict):
        return None
    for path in (("apiVersion",), ("locationServiceData", "apiVersion")):
        node: Any = payload
        for key in path:
            if not isinstance(node, dict) or key not in node:
                node = None
                break
            node = node[key]
        if isinstance(node, str) and node and _parse_version(node) is not None:
            return node
    return None


def _snap_to_candidate(advertised: str) -> str | None:
    """Return the highest candidate that is ``<= advertised``.

    Returns ``None`` if no candidate matches (e.g., advertised below the
    lowest candidate, or advertised unparseable).
    """
    advertised_tuple = _parse_version(advertised)
    if advertised_tuple is None:
        return None
    for candidate in SERVER_API_VERSION_CANDIDATES:
        candidate_tuple = _parse_version(candidate)
        if candidate_tuple is not None and candidate_tuple <= advertised_tuple:
            return candidate
    return None


def _parse_version(value: Any) -> tuple[int, int] | None:
    """Parse ``"<int>.<int>"`` strictly. Return ``None`` on anything weird."""
    if not isinstance(value, str):
        return None
    parts = value.split(".")
    if len(parts) != 2:
        return None
    try:
        return (int(parts[0]), int(parts[1]))
    except ValueError:
        return None


async def _iterate_candidates(client: ADOServerClient) -> tuple[str, str | None]:
    """Try each candidate; return ``(api_version, first_project_name)``.

    The first project name (when discoverable) is hoisted out so the
    Analytics soft-cap probe can fall back to a project-scoped URL
    without a second ``/_apis/projects`` round-trip.
    """
    last_status: int | None = None
    for candidate in SERVER_API_VERSION_CANDIDATES:
        try:
            response = await client.request(
                "GET", "/_apis/projects",
                params={"$top": "1", "api-version": candidate},
                skip_api_version=True,
            )
        except AuthenticationError:
            raise
        except APIError as exc:
            if exc.status_code in {HTTPStatus.BAD_REQUEST, HTTPStatus.NOT_FOUND}:
                last_status = exc.status_code
                continue
            raise
        first_project: str | None = None
        try:
            value = response.json().get("value", [])
            if value:
                first_project = value[0].get("name")
        except (ValueError, KeyError, TypeError):
            first_project = None
        return candidate, first_project

    raise APIError(
        f"Unable to determine a supported Azure DevOps Server REST API version. "
        f"Tried {list(SERVER_API_VERSION_CANDIDATES)}; last response status: {last_status}.",
        status_code=last_status,
    )


_SOFT_CAP_SCOPE_HINT = {
    "supports_graph_api": "the Graph PAT scope",
    "supports_analytics_odata": "the Analytics PAT scope",
    "supports_artifact_feeds": "the Packaging PAT scope",
}


async def _probe_soft_capabilities(
    client: ADOServerClient, *, api_version: str, project_hint: str | None,
) -> tuple[dict[str, bool], list[str], str | None]:
    """Fire 3 soft-capability probes in parallel.

    Returns ``(overrides, notes, graph_api_version)`` where:

    - ``overrides`` is a dict with the three soft-capability boolean flags.
    - ``notes`` carries diagnostic lines for ambiguous outcomes
      (e.g. 401 → flag False but PAT-scope may be the cause).
    - ``graph_api_version`` is the api-version variant that worked for the
      Graph probe (``"<resolved>-preview.1"`` or plain ``"<resolved>"``),
      or ``None`` when the Graph capability is False. The adapter's
      ``list_users`` method must use this exact value, NOT ``api_version``.
    """
    notes: list[str] = []

    GraphProbeResult = tuple[bool, str | None]

    async def _graph_probe_or_note() -> GraphProbeResult:
        try:
            return await _probe_graph(client, api_version=api_version)
        except AuthenticationError as exc:
            scope = _SOFT_CAP_SCOPE_HINT["supports_graph_api"]
            notes.append(
                f"supports_graph_api probe returned {exc.status_code}; the "
                f"capability may exist but the PAT lacks {scope}."
            )
            return False, None

    async def _bool_probe_or_note(
        capability: str, do_probe: Callable[[], Awaitable[bool]],
    ) -> bool:
        try:
            return await do_probe()
        except AuthenticationError as exc:
            scope = _SOFT_CAP_SCOPE_HINT.get(capability, "the required PAT scope")
            notes.append(
                f"{capability} probe returned {exc.status_code}; the capability "
                f"may exist but the PAT lacks {scope}."
            )
            return False

    graph_result, analytics, feeds = await asyncio.gather(
        _graph_probe_or_note(),
        _bool_probe_or_note(
            "supports_analytics_odata",
            lambda: _probe_analytics(
                client, api_version=api_version, project_hint=project_hint,
            ),
        ),
        _bool_probe_or_note(
            "supports_artifact_feeds",
            lambda: _probe_feeds(client, api_version=api_version),
        ),
    )
    graph_supported, graph_api_version = graph_result

    overrides = {
        "supports_graph_api": graph_supported,
        "supports_analytics_odata": analytics,
        "supports_artifact_feeds": feeds,
    }
    return overrides, notes, graph_api_version


def _is_invalid_api_version_400(exc: APIError) -> bool:
    """Detect Microsoft's ``VssInvalidPreviewVersionException`` envelope on a 400."""
    if exc.status_code != HTTPStatus.BAD_REQUEST:
        return False
    body = exc.response_body or {}
    parsed = body.get("parsed") if isinstance(body, dict) else None
    candidates = (body, parsed) if isinstance(parsed, dict) else (body,)
    for candidate in candidates:
        if not isinstance(candidate, dict):
            continue
        type_key = candidate.get("typeKey")
        if isinstance(type_key, str) and "InvalidPreviewVersion" in type_key:
            return True
        message = candidate.get("message") or candidate.get("text")
        if isinstance(message, str) and "InvalidPreviewVersion" in message:
            return True
        if isinstance(message, str) and "api-version" in message.lower():
            # Some Server builds return a plainer "Invalid API version" body
            # without the typeKey; treat any 400 with "api-version" in the
            # message as the same signal.
            return True
    return False


async def _probe_graph(
    client: ADOServerClient, *, api_version: str,
) -> tuple[bool, str | None]:
    """Probe ``/_apis/graph/users`` with ``-preview.1`` first; on
    400 InvalidApiVersion, retry plain. Returns ``(True, variant_used)``
    on the first 200, ``(False, None)`` on 404 / 501 / both 400s."""
    for variant in (f"{api_version}-preview.1", api_version):
        try:
            await client.request(
                "GET", "/_apis/graph/users",
                params={"$top": "1", "api-version": variant},
                skip_api_version=True,
            )
        except APIError as exc:
            if exc.status_code in {HTTPStatus.NOT_FOUND, HTTPStatus.NOT_IMPLEMENTED}:
                return False, None
            if _is_invalid_api_version_400(exc):
                continue  # try next variant — only invalid-version 400s
            raise
        return True, variant
    return False, None


async def _probe_analytics(
    client: ADOServerClient, *, api_version: str, project_hint: str | None,
) -> bool:
    """Probe collection-scoped ``$metadata``; on 404, fall back project-scoped."""
    try:
        await client.request(
            "GET", "/_odata/v4.0-preview/$metadata",
            params={"api-version": api_version},
            skip_api_version=True,
        )
    except APIError as exc:
        if exc.status_code != HTTPStatus.NOT_FOUND:
            raise
        # Fall back: project-scoped.
        if project_hint is None:
            return False
        try:
            await client.request(
                "GET", f"/{project_hint}/_odata/v4.0-preview/$metadata",
                params={"api-version": api_version},
                skip_api_version=True,
            )
        except APIError as exc2:
            if exc2.status_code in {HTTPStatus.NOT_FOUND, HTTPStatus.NOT_IMPLEMENTED}:
                return False
            raise
        return True
    return True


async def _probe_feeds(client: ADOServerClient, *, api_version: str) -> bool:
    """Probe ``/_apis/packaging/feeds`` with the resolved api-version."""
    try:
        await client.request(
            "GET", "/_apis/packaging/feeds",
            params={"$top": "1", "api-version": api_version},
            skip_api_version=True,
        )
    except APIError as exc:
        if exc.status_code in {HTTPStatus.NOT_FOUND, HTTPStatus.NOT_IMPLEMENTED}:
            return False
        raise
    return True
```

- [ ] **Step 2: Re-export discovery symbols from `ado_source_core/__init__.py`**

Add to the imports:

```python
from ado_source_core.api_version_discovery import (
    SERVER_API_VERSION_CANDIDATES,
    ServerProbeResult,
    resolve_server_api_version,
)
```

Insert into `__all__` (alphabetical):

```python
"SERVER_API_VERSION_CANDIDATES",
"ServerProbeResult",
"resolve_server_api_version",
```

- [ ] **Step 3: Wire the probe into `ADOServerClient.connect()`**

In `src/ado_source_core/client.py`, replace the `connect()` body:

```python
    async def connect(self) -> None:
        """Run the api-version + soft-capability probe. Idempotent."""
        if self._resolved_api_version is not None and self._explicit_api_version is not None:
            # Explicit api_version=; still run soft-cap probes for capability safety.
            if self._capability_overrides:
                return
            from ado_source_core.api_version_discovery import (  # noqa: PLC0415
                _probe_soft_capabilities,
            )

            overrides, notes, graph_api_version = await _probe_soft_capabilities(
                self,
                api_version=self._resolved_api_version,
                project_hint=None,
            )
            self._capability_overrides = dict(overrides)
            self._capability_notes = list(notes)
            self._graph_api_version = graph_api_version
            return
        if self._resolved_api_version is not None:
            return  # already probed
        from ado_source_core.api_version_discovery import (  # noqa: PLC0415
            resolve_server_api_version,
        )

        result = await resolve_server_api_version(self)
        self._resolved_api_version = result.api_version
        self._graph_api_version = result.graph_api_version
        self._capability_overrides = dict(result.capability_overrides)
        self._capability_notes = list(result.capability_notes)
```

- [ ] **Step 4: Run the discovery tests**

```bash
pytest tests/unit/test_api_version_discovery.py -v
```

Expected: All tests PASS.

### Task 3.3 — Add `__aenter__` close-on-failure test + `connect()` integration tests in `test_client_server.py`

- [ ] **Step 1: Append `TestConnect` and `TestAenterFailure` to `tests/unit/test_client_server.py`**

```python
def _server_happy_probe_mocks(mock: respx.MockRouter) -> None:
    """Set up the full probe-success mock surface: connectionData + projects
    fallback + 3 soft-cap probes all returning 200."""
    mock.get("/_apis/connectionData").mock(
        return_value=httpx.Response(200, json={"apiVersion": "7.0"})
    )
    mock.get("/_apis/projects").mock(
        return_value=httpx.Response(200, json={"value": [{"name": "ProjA"}]})
    )
    mock.get("/_apis/graph/users").mock(
        return_value=httpx.Response(200, json={"value": []})
    )
    mock.get("/_odata/v4.0-preview/$metadata").mock(
        return_value=httpx.Response(200, text="<edmx/>")
    )
    mock.get("/_apis/packaging/feeds").mock(
        return_value=httpx.Response(200, json={"value": []})
    )


class TestConnect:
    @pytest.mark.asyncio
    async def test_connect_runs_probe_and_caches_result(self, auth: PATAuth) -> None:
        client = ADOServerClient(
            base_url=_BASE, collection=_COLLECTION, auth=auth, max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                _server_happy_probe_mocks(mock)
                await client.connect()
                assert client.resolved_api_version == "7.0"
                assert client.graph_api_version == "7.0-preview.1"
                assert client.capability_overrides == {
                    "supports_graph_api": True,
                    "supports_analytics_odata": True,
                    "supports_artifact_feeds": True,
                }
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_connect_is_idempotent(self, auth: PATAuth) -> None:
        client = ADOServerClient(
            base_url=_BASE, collection=_COLLECTION, auth=auth, max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                cd = mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "7.0"})
                )
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(
                        200, json={"value": [{"name": "ProjA"}]},
                    )
                )
                mock.get("/_apis/graph/users").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                mock.get("/_odata/v4.0-preview/$metadata").mock(
                    return_value=httpx.Response(200, text=""),
                )
                mock.get("/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                await client.connect()
                await client.connect()
                assert cd.call_count == 1
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_aenter_runs_connect_automatically(self, auth: PATAuth) -> None:
        with respx.mock(base_url=_RESOLVED) as mock:
            _server_happy_probe_mocks(mock)
            async with ADOServerClient(
                base_url=_BASE, collection=_COLLECTION, auth=auth, max_retries=2,
            ) as client:
                assert client.resolved_api_version == "7.0"

    @pytest.mark.asyncio
    async def test_aenter_closes_client_on_connect_failure(self, auth: PATAuth) -> None:
        from ado_source_core import AuthenticationError

        client_ref: ADOServerClient | None = None
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(return_value=httpx.Response(404))
                mock.get("/_apis/projects").mock(return_value=httpx.Response(401))
                with pytest.raises(AuthenticationError):
                    async with ADOServerClient(
                        base_url=_BASE, collection=_COLLECTION, auth=auth, max_retries=2,
                    ) as client_ref:  # noqa: F841 — we just want to capture for the assertion
                        pass
        except Exception:
            raise
        # After __aenter__'s except path runs, the underlying httpx client
        # should have been closed. Reach in via the failed client_ref:
        # but client_ref was never assigned because __aenter__ raised before
        # binding. Recreate and re-test more directly:
        client = ADOServerClient(
            base_url=_BASE, collection=_COLLECTION, auth=auth, max_retries=2,
        )
        single = client.httpx_client("dev")
        with respx.mock(base_url=_RESOLVED) as mock:
            mock.get("/_apis/connectionData").mock(return_value=httpx.Response(404))
            mock.get("/_apis/projects").mock(return_value=httpx.Response(401))
            with pytest.raises(AuthenticationError):
                await client.__aenter__()
        assert single.is_closed

    @pytest.mark.asyncio
    async def test_explicit_api_version_skips_version_probe_but_runs_caps(
        self, auth: PATAuth,
    ) -> None:
        """Explicit api_version= bypasses the connectionData/candidate-iteration
        version probe but soft-cap probes still run on connect()."""
        with respx.mock(base_url=_RESOLVED) as mock:
            # Soft-cap mocks ARE required (the probe still runs).
            graph = mock.get("/_apis/graph/users").mock(
                return_value=httpx.Response(200, json={"value": []})
            )
            analytics = mock.get("/_odata/v4.0-preview/$metadata").mock(
                return_value=httpx.Response(200, text="<edmx/>")
            )
            feeds = mock.get("/_apis/packaging/feeds").mock(
                return_value=httpx.Response(200, json={"value": []})
            )
            # connectionData mock NOT set — if the version probe runs, respx
            # raises on an unhandled call and the test fails. That's the
            # contract: explicit api_version= skips the version probe.
            async with ADOServerClient(
                base_url=_BASE, collection=_COLLECTION, auth=auth,
                api_version="6.0", max_retries=2,
            ) as client:
                assert client.api_version == "6.0"
                assert client.capability_overrides == {
                    "supports_graph_api": True,
                    "supports_analytics_odata": True,
                    "supports_artifact_feeds": True,
                }
            # All 3 soft-cap probes ran exactly once.
            assert graph.call_count == 1
            assert analytics.call_count == 1
            assert feeds.call_count == 1


class TestConcurrentSoftCapProbes:
    """Verify that the 3 soft-cap probes (Graph / Analytics / Feeds) run
    concurrently via asyncio.gather, not sequentially. Avoids depending on
    respx's async-side-effect handling (which varies by version) by
    monkeypatching the inner probe functions directly."""

    @pytest.mark.asyncio
    async def test_three_soft_cap_probes_run_concurrently(
        self, auth: PATAuth, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        from ado_source_core import api_version_discovery as avd

        client = ADOServerClient(
            base_url=_BASE, collection=_COLLECTION, auth=auth,
            api_version="7.0", max_retries=2,
        )
        in_flight = 0
        max_in_flight = 0
        gate = asyncio.Event()

        async def _gated_call() -> bool:
            nonlocal in_flight, max_in_flight
            in_flight += 1
            max_in_flight = max(max_in_flight, in_flight)
            if in_flight >= 3:
                gate.set()
            await gate.wait()
            in_flight -= 1
            return True

        async def _fake_probe_graph(_client: Any, *, api_version: str) -> tuple[bool, str | None]:
            ok = await _gated_call()
            return ok, api_version if ok else None

        async def _fake_probe_analytics(
            _client: Any, *, api_version: str, project_hint: str | None,
        ) -> bool:
            return await _gated_call()

        async def _fake_probe_feeds(_client: Any, *, api_version: str) -> bool:
            return await _gated_call()

        monkeypatch.setattr(avd, "_probe_graph", _fake_probe_graph)
        monkeypatch.setattr(avd, "_probe_analytics", _fake_probe_analytics)
        monkeypatch.setattr(avd, "_probe_feeds", _fake_probe_feeds)

        try:
            overrides, notes, graph_api_version = await avd._probe_soft_capabilities(
                client, api_version="7.0", project_hint=None,
            )
            assert max_in_flight == 3, (
                f"expected 3 concurrent probes, observed max {max_in_flight}"
            )
            assert overrides == {
                "supports_graph_api": True,
                "supports_analytics_odata": True,
                "supports_artifact_feeds": True,
            }
            assert graph_api_version == "7.0"
            assert notes == []
        finally:
            await client.close()
```

- [ ] **Step 2: Run the new tests**

```bash
pytest tests/unit/test_client_server.py::TestConnect -v
```

Expected: All TestConnect cases PASS.

### Task 3.4 — Full sweep + commit

- [ ] **Step 1: Full verification sweep**

```bash
ruff check src tests && ruff format --check src tests && mypy src && pytest -v
```

Expected: All clean.

- [ ] **Step 2: Commit**

```bash
git add src/ado_source_core/api_version_discovery.py src/ado_source_core/client.py src/ado_source_core/__init__.py tests/unit/test_api_version_discovery.py tests/unit/test_client_server.py
git commit -m "$(cat <<'EOF'
feat(transport): add api_version_discovery module

Probes /_apis/connectionData first; falls back to candidate iteration
over ("7.0","6.0","5.1","5.0"), covering Server 2022 / 2020 / 2019
Update 1+ / 2019 RTW. Soft-capability probes (Graph / Analytics /
Package Management) run in parallel via asyncio.gather and populate
SourceCapabilities flags.

Soft-cap probes that get 401/403 mark the capability False AND record
a diagnostic note (instead of propagating) — preserves usability when
a PAT lacks one specific scope but is otherwise valid.

Graph probe + list_users use a probe-resolved preview-suffix-aware
api-version (try -preview.1 first, plain fallback on
400 InvalidApiVersion). Analytics probe falls back collection→project
on 404 (Server 2019 may not expose collection-level $metadata even
when Analytics is installed).

ADOServerClient.connect() now wires this discovery in; __aenter__
closes the httpx client on probe failure to prevent socket leaks.

Donor: ado2gh-core/src/ado2gh/adapters/ado_server.py:101 @ 160de58.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
git push
```

---

## Task 4: `UnsupportedOnAzureDevOpsServerError`

**Goal:** Add the typed exception used by `AzureDevOpsServerAdapter` to signal capability gaps. Required `api_version` field, optional `remediation`, mandatory `capability` name.

**Files:**
- Modify: `src/ado_source_core/exceptions.py`
- Modify: `src/ado_source_core/__init__.py`
- Modify: `tests/unit/test_exceptions.py`

### Task 4.1 — Failing tests

- [ ] **Step 1: Append to `tests/unit/test_exceptions.py`**

```python
class TestUnsupportedOnAzureDevOpsServerError:
    def test_carries_required_capability_and_api_version(self) -> None:
        from ado_source_core import UnsupportedOnAzureDevOpsServerError

        exc = UnsupportedOnAzureDevOpsServerError(
            "Graph not available",
            capability="supports_graph_api",
            api_version="7.0",
        )
        assert exc.capability == "supports_graph_api"
        assert exc.api_version == "7.0"
        assert exc.remediation is None

    def test_carries_optional_remediation(self) -> None:
        from ado_source_core import UnsupportedOnAzureDevOpsServerError

        exc = UnsupportedOnAzureDevOpsServerError(
            "Graph not available",
            capability="supports_graph_api",
            api_version="7.0",
            remediation="Install the Graph extension.",
        )
        assert exc.remediation == "Install the Graph extension."

    def test_subclasses_ado_source_core_error(self) -> None:
        from ado_source_core import (
            ADOSourceCoreError,
            UnsupportedOnAzureDevOpsServerError,
        )

        exc = UnsupportedOnAzureDevOpsServerError(
            "x", capability="y", api_version="7.0",
        )
        assert isinstance(exc, ADOSourceCoreError)

    def test_str_returns_message(self) -> None:
        from ado_source_core import UnsupportedOnAzureDevOpsServerError

        exc = UnsupportedOnAzureDevOpsServerError(
            "Graph API is not available",
            capability="supports_graph_api",
            api_version="7.0",
        )
        assert str(exc) == "Graph API is not available"

    def test_api_version_is_required_keyword(self) -> None:
        from ado_source_core import UnsupportedOnAzureDevOpsServerError

        with pytest.raises(TypeError):
            # Missing api_version=
            UnsupportedOnAzureDevOpsServerError(  # type: ignore[call-arg]
                "x", capability="y",
            )
```

If `test_exceptions.py` doesn't currently import `pytest`, add it at the top.

- [ ] **Step 2: Run the test to verify it fails**

```bash
pytest tests/unit/test_exceptions.py::TestUnsupportedOnAzureDevOpsServerError -v 2>&1 | head -20
```

Expected: All fail with `ImportError: cannot import name 'UnsupportedOnAzureDevOpsServerError' from 'ado_source_core'`.

### Task 4.2 — Implement the exception

- [ ] **Step 1: Append to `src/ado_source_core/exceptions.py`**

After the `RateLimitError` class:

```python
class UnsupportedOnAzureDevOpsServerError(ADOSourceCoreError):
    """Raised when a capability is unavailable on this Azure DevOps Server instance.

    Carries enough structured context for downstream tooling (notably
    ``ado-scanner``'s discovery report) to surface a useful "what was
    missed and why" line without parsing the message.

    Attributes:
        capability: The ``SourceCapabilities`` field name that gated this
            call (e.g., ``"supports_graph_api"``,
            ``"supports_analytics_odata"``,
            ``"supports_artifact_feeds"``,
            ``"supports_user_entitlements"``).
        api_version: The Server REST api-version that was probed and
            resolved on this instance — required so discovery reports can
            write a meaningful "missed on Server <version>" line.
        remediation: Optional admin-oriented hint about how to enable the
            missing capability (e.g., "Install the Graph extension via
            the server administration console"). ``None`` when no
            remediation is appropriate (typically only for hard-False
            capabilities like ``supports_user_entitlements``).
    """

    def __init__(
        self,
        message: str,
        *,
        capability: str,
        api_version: str,
        remediation: str | None = None,
        exit_code: ExitCode = ExitCode.USER_ERROR,
    ) -> None:
        super().__init__(message, exit_code=exit_code)
        self.capability = capability
        self.api_version = api_version
        self.remediation = remediation
```

- [ ] **Step 2: Re-export from `src/ado_source_core/__init__.py`**

Add to the existing `from ado_source_core.exceptions import (...)` block:

```python
from ado_source_core.exceptions import (
    ADOSourceCoreError,
    APIError,
    AuthenticationError,
    ConfigError,
    ExitCode,
    RateLimitError,
    UnsupportedOnAzureDevOpsServerError,
)
```

Insert into `__all__` (alphabetical): `"UnsupportedOnAzureDevOpsServerError"`.

- [ ] **Step 3: Run the new tests**

```bash
pytest tests/unit/test_exceptions.py::TestUnsupportedOnAzureDevOpsServerError -v
```

Expected: All 5 tests PASS.

### Task 4.3 — Full sweep + commit

- [ ] **Step 1: Full sweep**

```bash
ruff check src tests && ruff format --check src tests && mypy src && pytest -v
```

- [ ] **Step 2: Commit**

```bash
git add src/ado_source_core/exceptions.py src/ado_source_core/__init__.py tests/unit/test_exceptions.py
git commit -m "$(cat <<'EOF'
feat(exceptions): add UnsupportedOnAzureDevOpsServerError

Typed exception for capability gaps on Azure DevOps Server. Carries
required `capability` (the SourceCapabilities flag name), required
`api_version` (the Server REST version that was probed), and optional
`remediation` (admin-oriented hint for enabling the missing extension).

Required api_version makes discovery-report consumers' lives easier —
every raise site has it (it's read off caps.api_version), and reports
need it to write "missed on Server <version>" lines.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
git push
```

(Task 4 push step.)

---

## Task 5: `SourceCapabilities` — drop `supports_packages`, add 3 soft-cap flags + `server_default()` + `with_overrides()` whitelist

**Goal:** Land the model-level changes the adapter relies on. BREAKING (0.x): removes `supports_packages`. Adds the three soft-capability flags, `server_default()` factory, `with_overrides()` method with whitelist enforcement, `OVERRIDABLE_SOFT_CAPABILITY_KEYS` constant.

**Files:**
- Modify: `src/ado_source_core/models/source_capabilities.py`
- Modify: `tests/unit/test_models_source_capabilities.py`

### Task 5.1 — Failing tests

- [ ] **Step 1: Append to `tests/unit/test_models_source_capabilities.py`**

The existing file already imports `pytest`, `SourceCapabilities`, and `SourceType` (verify with `head -10 tests/unit/test_models_source_capabilities.py`). Append ONLY the new test classes shown below — do NOT re-add those imports.

```python
class TestServerDefault:
    def test_returns_server_source_type(self) -> None:
        caps = SourceCapabilities.server_default()
        assert caps.source_type == SourceType.AZURE_DEVOPS_SERVER

    def test_default_api_version_is_7_0(self) -> None:
        caps = SourceCapabilities.server_default()
        assert caps.api_version == "7.0"

    def test_supports_user_entitlements_is_hard_false(self) -> None:
        caps = SourceCapabilities.server_default()
        assert caps.supports_user_entitlements is False

    def test_supports_collections_is_true(self) -> None:
        caps = SourceCapabilities.server_default()
        assert caps.supports_collections is True

    def test_compatibility_mode_5_1(self) -> None:
        caps = SourceCapabilities.server_default(api_version="5.1")
        assert caps.compatibility_mode is True
        assert any("5.1" in n for n in caps.notes)

    def test_compatibility_mode_5_0(self) -> None:
        caps = SourceCapabilities.server_default(api_version="5.0")
        assert caps.compatibility_mode is True
        assert any("5.0" in n for n in caps.notes)

    def test_compatibility_mode_off_for_6_0(self) -> None:
        caps = SourceCapabilities.server_default(api_version="6.0")
        assert caps.compatibility_mode is False
        assert caps.notes == []


class TestSoftCapabilityFlags:
    def test_default_true_on_cloud(self) -> None:
        caps = SourceCapabilities.cloud_default()
        assert caps.supports_graph_api is True
        assert caps.supports_analytics_odata is True
        assert caps.supports_artifact_feeds is True

    def test_default_true_on_server_before_overrides(self) -> None:
        caps = SourceCapabilities.server_default()
        assert caps.supports_graph_api is True
        assert caps.supports_analytics_odata is True
        assert caps.supports_artifact_feeds is True

    def test_supports_packages_is_removed(self) -> None:
        caps = SourceCapabilities.cloud_default()
        assert not hasattr(caps, "supports_packages")


class TestWithOverridesWhitelist:
    def test_applies_soft_cap_overrides(self) -> None:
        caps = SourceCapabilities.server_default()
        new = caps.with_overrides({
            "supports_graph_api": False,
            "supports_analytics_odata": False,
            "supports_artifact_feeds": False,
        })
        assert new.supports_graph_api is False
        assert new.supports_analytics_odata is False
        assert new.supports_artifact_feeds is False

    def test_returns_new_instance(self) -> None:
        caps = SourceCapabilities.server_default()
        new = caps.with_overrides({"supports_graph_api": False})
        assert caps.supports_graph_api is True   # original unchanged
        assert new.supports_graph_api is False
        assert new is not caps

    def test_rejects_non_whitelisted_key(self) -> None:
        caps = SourceCapabilities.server_default()
        with pytest.raises(ValueError, match="disallowed"):
            caps.with_overrides({"supports_user_entitlements": True})

    def test_rejects_unknown_key(self) -> None:
        caps = SourceCapabilities.server_default()
        with pytest.raises(ValueError, match="disallowed"):
            caps.with_overrides({"unknown_capability": True})

    def test_appends_notes(self) -> None:
        caps = SourceCapabilities.server_default(api_version="5.1")
        new = caps.with_overrides(
            {"supports_graph_api": False},
            notes=["graph probe returned 401; PAT may lack vso.graph"],
        )
        assert len(new.notes) == len(caps.notes) + 1
        assert any("vso.graph" in n for n in new.notes)

    def test_overridable_keys_constant(self) -> None:
        assert SourceCapabilities.OVERRIDABLE_SOFT_CAPABILITY_KEYS == frozenset({
            "supports_graph_api",
            "supports_analytics_odata",
            "supports_artifact_feeds",
        })
```

- [ ] **Step 2: Run the test — verify failures**

```bash
pytest tests/unit/test_models_source_capabilities.py -v 2>&1 | head -40
```

Expected: New tests fail with `AttributeError: type object 'SourceCapabilities' has no attribute 'server_default'` (and similar).

### Task 5.2 — Implement the model changes

- [ ] **Step 1: Edit `src/ado_source_core/models/source_capabilities.py`**

Replace the **entire file** (module docstring + imports + class) with the block below. The replacement preserves the donor citation header from the existing file and adds a `**Drift from previous shape (v0.3.0):**` section to the module docstring. Don't paste this block INTO the existing class body — it IS the new file contents:

```python
"""Source capability models shared by discovery, planning, and migration.

Lifted from `n8group-oss/ado2gh-core/src/ado2gh/models/source_capabilities.py`
@ `160de58` per Stage 1 sub-stage 1.1 task 1.1.5. Re-licensed BUSL-1.1 -> MIT
under the sole-author consent path documented in
`shyftport-specs/plans/audit/migration-core-base-decision.md` §5.

**Drift from previous shape (v0.3.0):**

- ``supports_packages`` removed (replaced by ``supports_artifact_feeds``,
  functionally equivalent; renamed for on-prem clarity). BREAKING at the
  model level — consumers reading the field need to switch to the new name.
- New soft-capability flags: ``supports_graph_api``,
  ``supports_analytics_odata``, ``supports_artifact_feeds`` (default
  ``True`` so ``cloud_default`` doesn't have to spell them out).
- New ``server_default(api_version=...)`` classmethod for ADO Server.
- New ``with_overrides()`` method applying probe-discovered flag changes.
  Whitelist enforcement: only the three soft-capability fields are
  overridable; hard-False ``supports_user_entitlements`` cannot be flipped.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from enum import StrEnum
from typing import ClassVar

from pydantic import BaseModel, ConfigDict, Field


class SourceType(StrEnum):
    """Supported Azure DevOps source variants."""

    AZURE_DEVOPS_CLOUD = "azure-devops-cloud"
    AZURE_DEVOPS_SERVER = "azure-devops-server"


class SourceCapabilities(BaseModel):
    """Capability flags for a specific source adapter instance."""

    model_config = ConfigDict(extra="forbid")

    source_type: SourceType
    api_version: str = "7.1"
    supports_collections: bool = False
    supports_user_entitlements: bool = True
    supports_pipelines: bool = True
    supports_pull_request_threads: bool = True

    # Soft-capability flags — default True so cloud_default doesn't list them.
    # On Server, may be flipped to False by probe results via with_overrides().
    supports_graph_api: bool = True
    supports_analytics_odata: bool = True
    supports_artifact_feeds: bool = True

    compatibility_mode: bool = False
    notes: list[str] = Field(default_factory=list)

    OVERRIDABLE_SOFT_CAPABILITY_KEYS: ClassVar[frozenset[str]] = frozenset({
        "supports_graph_api",
        "supports_analytics_odata",
        "supports_artifact_feeds",
    })

    @classmethod
    def cloud_default(cls) -> SourceCapabilities:
        """Default capabilities for Azure DevOps Services."""
        return cls(source_type=SourceType.AZURE_DEVOPS_CLOUD)

    @classmethod
    def server_default(cls, *, api_version: str = "7.0") -> SourceCapabilities:
        """Conservative defaults for Azure DevOps Server.

        Hard-False on Server (cannot be flipped by ``with_overrides``):

        - ``supports_user_entitlements`` — vsaex Member Entitlements API
          is cloud-only.

        Probe-resolvable on Server (default ``True``; ``with_overrides``
        may flip based on optional-extension presence):

        - ``supports_graph_api``
        - ``supports_analytics_odata``
        - ``supports_artifact_feeds``

        ``compatibility_mode=True`` iff ``api_version`` is ``"5.0"``
        (Server 2019 RTW) or ``"5.1"`` (Server 2019 Update 1+). The notes
        list records which exact api-version triggered compatibility
        mode.
        """
        compatibility_mode = api_version in {"5.0", "5.1"}
        notes: list[str] = []
        if compatibility_mode:
            notes.append(
                f"Server 2019 compatibility mode enabled (api-version {api_version})"
            )
        return cls(
            source_type=SourceType.AZURE_DEVOPS_SERVER,
            api_version=api_version,
            supports_collections=True,
            supports_user_entitlements=False,
            compatibility_mode=compatibility_mode,
            notes=notes,
        )

    def with_overrides(
        self,
        overrides: Mapping[str, bool],
        *,
        notes: Sequence[str] = (),
    ) -> SourceCapabilities:
        """Return a copy with whitelisted soft-capability overrides applied.

        Only ``OVERRIDABLE_SOFT_CAPABILITY_KEYS`` may be passed in
        ``overrides``; any other key (including hard-False
        ``supports_user_entitlements``) raises :class:`ValueError`.

        ``notes`` are appended to ``self.notes`` so probe-time diagnostics
        (e.g., PAT-scope ambiguity warnings) carry through to the
        capability set returned by ``adapter.get_capabilities()``.
        """
        unknown = set(overrides) - self.OVERRIDABLE_SOFT_CAPABILITY_KEYS
        if unknown:
            raise ValueError(
                f"with_overrides only accepts soft-capability keys "
                f"{sorted(self.OVERRIDABLE_SOFT_CAPABILITY_KEYS)}; "
                f"got disallowed keys: {sorted(unknown)}"
            )
        data = self.model_dump()
        data.update(overrides)
        if notes:
            data["notes"] = [*data.get("notes", []), *notes]
        return type(self).model_validate(data)
```

- [ ] **Step 2: Run the new tests**

```bash
pytest tests/unit/test_models_source_capabilities.py -v
```

Expected: All tests PASS.

- [ ] **Step 3: Run the full unit suite to confirm no other test depended on `supports_packages`**

```bash
pytest -v 2>&1 | tail -30
```

Expected: All PASS. If any test fails referencing `supports_packages`, update it to `supports_artifact_feeds`.

### Task 5.3 — Full sweep + commit

- [ ] **Step 1: Full sweep**

```bash
ruff check src tests && ruff format --check src tests && mypy src && pytest -v
```

- [ ] **Step 2: Commit**

```bash
git add src/ado_source_core/models/source_capabilities.py tests/unit/test_models_source_capabilities.py
git commit -m "$(cat <<'EOF'
feat(models): server_default + soft-cap flags + with_overrides whitelist

BREAKING (0.x): SourceCapabilities.supports_packages removed in favor of
supports_artifact_feeds (functionally equivalent; renamed for on-prem
clarity).

Adds server_default(api_version=...) factory, three new soft-capability
flags (supports_graph_api, supports_analytics_odata, supports_artifact_feeds)
defaulting to True, with_overrides() with whitelist enforcement
(OVERRIDABLE_SOFT_CAPABILITY_KEYS), and append-notes hook so probe-time
diagnostics carry into adapter.get_capabilities().

compatibility_mode triggers on api_version in {"5.0","5.1"} — Server 2019
RTW + Update 1+ — with the note line recording which.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
git push
```

(Task 5 push step.)

---

## Task 6: `AzureDevOpsServerAdapter`

**Goal:** Implement the sibling adapter with the full read-side surface mirroring `AzureDevOpsCloudAdapter`. Capability-gated methods (`list_users`, `query_work_item_counts`, `list_artifact_feeds`, `list_user_entitlements`) use the eager-raise pattern from the spec. New file uses `host="dev"` default everywhere — server adapter NEVER passes an explicit `host=` argument since all hosts alias to the single httpx client.

**Files:**
- Create: `src/ado_source_core/adapters/ado_server.py`
- Modify: `src/ado_source_core/adapters/__init__.py`
- Modify: `src/ado_source_core/__init__.py`
- Create: `tests/unit/test_adapters_ado_server.py`

### Task 6.1 — Implement `AzureDevOpsServerAdapter`

- [ ] **Step 1: Create `src/ado_source_core/adapters/ado_server.py`**

```python
"""Concrete Azure DevOps Server adapter.

Lifted from ``n8group-oss/ado2gh-core/src/ado2gh/adapters/ado_server.py`` @
``160de58``. Re-licensed BUSL-1.1 -> MIT under the sole-author consent
path documented in ``shyftport-specs/plans/audit/migration-core-base-decision.md``.

**Drift from donor:**

- Sibling of :class:`AzureDevOpsCloudAdapter`, NOT a subclass. The new
  ``ADOClient``/``BaseADOClient`` shape diverges from the donor's
  adapter-internal httpx clients; with transport extracted, every
  cloud method's body would need a parallel server method anyway
  (different host strategy, different api-version policy). The
  sibling-and-parity-test approach catches the same drift risk that
  inheritance catches by construction.
- Capability-gated methods raise :class:`UnsupportedOnAzureDevOpsServerError`
  on the False branch. Donor's compatibility-mode short-circuited
  ``query_work_item_counts`` to zeros and ``list_user_entitlements``
  to ``[]``; we drop that — discovery reports must surface "what was
  missed and why," not silently zero out.
- ``host=`` argument is never passed (every server method relies on
  the default). The single httpx client is collection-scoped; logical
  hosts alias to it.
- ``list_users`` uses the probe-resolved api-version stored on the
  capability set (preview-suffix-aware via the discovery probe).
"""

from __future__ import annotations

from http import HTTPStatus
from typing import TYPE_CHECKING, Any, Self

from ado_source_core.adapters.source import SourceAdapter
from ado_source_core.exceptions import (
    APIError,
    AuthenticationError,
    UnsupportedOnAzureDevOpsServerError,
)
from ado_source_core.models.repository import Repository
from ado_source_core.models.source_capabilities import SourceCapabilities
from ado_source_core.models.user import User
from ado_source_core.pagination import (
    paginate_via_adoclient_continuation_token,
    paginate_via_adoclient_skip_top,
)

if TYPE_CHECKING:
    from types import TracebackType

    from ado_source_core.client import ADOServerClient


class AzureDevOpsServerAdapter(SourceAdapter[Repository, User]):
    """Concrete read-side adapter for Azure DevOps Server (on-prem).

    Sibling of :class:`AzureDevOpsCloudAdapter` — same method-by-method
    contract, identical signatures, identical return-shape semantics. The
    server-side body uses a single collection-scoped HTTP client and
    eager-raises :class:`UnsupportedOnAzureDevOpsServerError` on
    capabilities that the resolved Server instance does not expose.

    Construct around a connected (or about-to-be-connected) ``ADOServerClient``::

        async with ADOServerClient(
            base_url="https://devops.example.com:8080/tfs",
            collection="DefaultCollection",
            auth=PATAuth(token=...),
        ) as client:
            async with AzureDevOpsServerAdapter(client=client) as adapter:
                projects = await adapter.list_projects()
                caps = await adapter.get_capabilities()
                if caps.supports_graph_api:
                    users = await adapter.list_users()
    """

    def __init__(
        self,
        *,
        client: ADOServerClient,
        capabilities: SourceCapabilities | None = None,
    ) -> None:
        self._client = client
        self._capabilities: SourceCapabilities | None = capabilities

    @property
    def client(self) -> ADOServerClient:
        return self._client

    async def get_capabilities(self) -> SourceCapabilities:
        """Return the resolved capability set, building it lazily on first call.

        Ensures the underlying client has been probe-resolved before the
        capability set is built — calls ``await self._client.connect()``
        which is idempotent. This prevents a stale-default capability set
        being cached from a constructor-only state where probe overrides
        haven't been applied yet.
        """
        if self._capabilities is not None:
            return self._capabilities
        await self._client.connect()  # idempotent; ensures probe state populated
        base = SourceCapabilities.server_default(api_version=self._client.api_version)
        self._capabilities = base.with_overrides(
            self._client.capability_overrides,
            notes=self._client.capability_notes,
        )
        return self._capabilities

    # --- Authentication probe ---

    async def verify_credentials(self) -> bool:
        """Verify PAT by probing projects, repos, and builds scopes."""
        try:
            projects_resp = await self._client.request(
                "GET", "/_apis/projects", params={"$top": "1"},
            )
            projects = projects_resp.json().get("value", [])
            if projects:
                project_name = projects[0]["name"]
                await self._client.request(
                    "GET", f"/{project_name}/_apis/git/repositories",
                )
                await self._client.request(
                    "GET", f"/{project_name}/_apis/build/definitions",
                    params={"$top": "1"},
                )
        except AuthenticationError as exc:
            raise AuthenticationError(
                "Azure DevOps Server authentication failed.\n"
                "  Verify the PAT and collection permissions for project, "
                "code, and build read access on the target server.\n"
                "  Ensure base_url points at the Azure DevOps Server root or "
                "collection URL.",
                status_code=exc.status_code,
            ) from exc
        return True

    # --- Project methods ---

    async def list_projects(
        self, *, state_filter: str = "wellFormed",
    ) -> list[dict[str, Any]]:
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client, "/_apis/projects",
                params={"stateFilter": state_filter, "$top": "100"},
            )
        ]

    async def get_project_details(self, project_id: str) -> dict[str, Any]:
        response = await self._client.request(
            "GET", f"/_apis/projects/{project_id}",
            params={"includeCapabilities": "true"},
        )
        result: dict[str, Any] = response.json()
        return result

    async def get_process_template(self, process_type_id: str) -> dict[str, Any]:
        response = await self._client.request(
            "GET", f"/_apis/work/processes/{process_type_id}",
        )
        result: dict[str, Any] = response.json()
        return result

    # --- Repository methods ---

    async def list_repositories(
        self, *, workspace: str | None = None, project: str | None = None,
        page: int = 1, page_size: int = 100,
    ) -> list[Repository]:
        if not project:
            raise ValueError("project is required for ADO repo listing")
        response = await self._client.request(
            "GET", f"/{project}/_apis/git/repositories",
            params={"includeHidden": "true"},
        )
        data = response.json()
        repos: list[Repository] = []
        for r in data.get("value", []):
            default_branch = r.get("defaultBranch") or "refs/heads/main"
            if default_branch.startswith("refs/heads/"):
                default_branch = default_branch[len("refs/heads/"):]
            repos.append(
                Repository(
                    id=r["id"], name=r["name"],
                    full_name=f"{project}/{r['name']}",
                    description=r.get("description"),
                    project_name=project, default_branch=default_branch,
                    is_disabled=r.get("isDisabled", False),
                    is_in_maintenance=r.get("isInMaintenance", False),
                    is_fork=r.get("isFork", False),
                    size_bytes=r.get("size"),
                    clone_url_https=r.get("remoteUrl"),
                    clone_url_ssh=r.get("sshUrl"),
                    source="azure-devops",
                )
            )
        return repos

    async def get_repository(self, repo_id: str) -> Repository | None:
        raise NotImplementedError

    async def count_branches(self, repo_id: str) -> int:
        project, repo = repo_id.split("/", 1)
        count = 0
        async for _ in paginate_via_adoclient_continuation_token(
            self._client,
            f"/{project}/_apis/git/repositories/{repo}/refs",
            params={"filter": "heads/", "$top": "100"},
        ):
            count += 1
        return count

    async def count_pull_requests(
        self, repo_id: str, *, state: str | None = None,
    ) -> int:
        project, repo = repo_id.split("/", 1)
        count = 0
        async for _ in paginate_via_adoclient_skip_top(
            self._client,
            f"/{project}/_apis/git/repositories/{repo}/pullrequests",
            params={"searchCriteria.status": state or "all"},
            page_size=100,
        ):
            count += 1
        return count

    async def detect_lfs_patterns(
        self, repo_id: str, *, branch: str | None = None,
    ) -> dict[str, Any]:
        project, repo = repo_id.split("/", 1)
        params: dict[str, Any] = {"path": ".gitattributes", "includeContent": "true"}
        if branch:
            params["versionDescriptor.version"] = branch
            params["versionDescriptor.versionType"] = "branch"
        try:
            response = await self._client.request(
                "GET", f"/{project}/_apis/git/repositories/{repo}/items",
                params=params,
            )
            data = response.json()
            content: str = data.get("content", "")
            min_tokens_for_attr = 2
            patterns: list[str] = []
            for line in content.splitlines():
                stripped = line.strip()
                if not stripped or stripped.startswith("#"):
                    continue
                tokens = stripped.split()
                if len(tokens) < min_tokens_for_attr:
                    continue
                has_positive = any(tok == "filter=lfs" for tok in tokens)
                has_negation = any(tok == "-filter=lfs" for tok in tokens)
                if has_positive and not has_negation:
                    patterns.append(tokens[0])
            return {"has_lfs": bool(patterns), "patterns": patterns}
        except APIError as exc:
            if exc.status_code == HTTPStatus.NOT_FOUND:
                return {"has_lfs": False, "patterns": []}
            raise

    async def analyze_large_files(
        self, repo_id: str, *, branch: str | None = None,
        threshold_bytes: int = 100_000_000,
    ) -> dict[str, Any]:
        project, repo = repo_id.split("/", 1)
        ref_name = branch or "main"
        try:
            refs_response = await self._client.request(
                "GET", f"/{project}/_apis/git/repositories/{repo}/refs",
                params={"filter": f"heads/{ref_name}", "$top": "1"},
            )
            refs_list = refs_response.json().get("value", [])
            if not refs_list:
                return {"large_files": []}
            commit_id = refs_list[0]["objectId"]
            commit_response = await self._client.request(
                "GET", f"/{project}/_apis/git/repositories/{repo}/commits/{commit_id}",
            )
            commit_data = commit_response.json()
            tree_sha = commit_data.get("treeSha1") or commit_data.get("treeId")
            if not tree_sha:
                return {"large_files": []}
            tree_response = await self._client.request(
                "GET", f"/{project}/_apis/git/repositories/{repo}/trees/{tree_sha}",
                params={"recursive": "true"},
            )
            entries = tree_response.json().get("treeEntries", [])
            large_files = [
                {"path": e.get("relativePath", ""), "size_bytes": e.get("size", 0)}
                for e in entries
                if e.get("gitObjectType") == "blob" and e.get("size", 0) >= threshold_bytes
            ]
            return {"large_files": large_files}
        except APIError as exc:
            if exc.status_code == HTTPStatus.NOT_FOUND:
                return {"large_files": []}
            raise

    async def get_file_content(
        self, project: str, repo_id: str, path: str, *, branch: str | None = None,
    ) -> str | None:
        params: dict[str, Any] = {"path": path, "includeContent": "true"}
        if branch:
            params["versionDescriptor.version"] = branch
            params["versionDescriptor.versionType"] = "branch"
        try:
            response = await self._client.request(
                "GET", f"/{project}/_apis/git/repositories/{repo_id}/items",
                params=params,
            )
        except APIError as exc:
            if exc.status_code == HTTPStatus.NOT_FOUND:
                return None
            raise
        data = response.json()
        content: str | None = data.get("content")
        return content

    # --- Pipeline methods (build & release definitions) ---

    async def list_build_definitions(self, project: str) -> list[dict[str, Any]]:
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client, f"/{project}/_apis/build/definitions",
                params={"$top": "100"},
            )
        ]

    async def get_build_definition(
        self, project: str, definition_id: int,
    ) -> dict[str, Any]:
        response = await self._client.request(
            "GET", f"/{project}/_apis/build/definitions/{definition_id}",
        )
        result: dict[str, Any] = response.json()
        return result

    async def list_release_definitions(self, project: str) -> list[dict[str, Any]]:
        # On Server, classic Release Management lives under the same
        # collection-scoped URL — no separate vsrm host.
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client, f"/{project}/_apis/release/definitions",
                params={"$top": "100"},
            )
        ]

    async def get_release_definition(
        self, project: str, definition_id: int,
    ) -> dict[str, Any]:
        response = await self._client.request(
            "GET", f"/{project}/_apis/release/definitions/{definition_id}",
        )
        result: dict[str, Any] = response.json()
        return result

    # --- Service connection / variable group / environment methods ---

    async def list_service_connections(self, project: str) -> list[dict[str, Any]]:
        response = await self._client.request(
            "GET", f"/{project}/_apis/serviceendpoint/endpoints",
        )
        result: list[dict[str, Any]] = response.json().get("value", [])
        return result

    async def list_variable_groups(self, project: str) -> list[dict[str, Any]]:
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client, f"/{project}/_apis/distributedtask/variablegroups",
                params={"$top": "100"},
            )
        ]

    async def list_environments(self, project: str) -> list[dict[str, Any]]:
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client, f"/{project}/_apis/distributedtask/environments",
                params={"$top": "100"},
            )
        ]

    # --- Work item / classification methods ---

    async def query_work_item_counts(self, project: str) -> dict[str, Any]:
        """Query work-item counts via collection-base, project-scoped OData.

        Eager-raises :class:`UnsupportedOnAzureDevOpsServerError` if the
        Analytics extension is not installed on the resolved Server
        instance.
        """
        caps = await self.get_capabilities()
        if not caps.supports_analytics_odata:
            raise UnsupportedOnAzureDevOpsServerError(
                "Analytics OData is not available on this Azure DevOps Server instance "
                "(the optional Analytics extension is not installed or could not be probed).",
                capability="supports_analytics_odata",
                api_version=caps.api_version,
                remediation=(
                    "The Analytics extension is required for "
                    "/_odata/v4.0-preview/WorkItems. Auto-installed on Server 2020+; "
                    "on Server 2019, install via the server administration console "
                    "(Marketplace → install on collection)."
                ),
            )
        response = await self._client.request(
            "GET", f"/{project}/_odata/v4.0-preview/WorkItems",
            params={
                "$apply": "groupby((WorkItemType,State),aggregate($count as Count))",
            },
            skip_api_version=True,
        )
        data = response.json()
        by_type: dict[str, int] = {}
        by_state: dict[str, int] = {}
        total = 0
        for item in data.get("value", []):
            wit = item.get("WorkItemType") or "Unknown"
            state = item.get("State") or "Unknown"
            count = item.get("Count", 0)
            by_type[wit] = by_type.get(wit, 0) + count
            by_state[state] = by_state.get(state, 0) + count
            total += count
        return {"total": total, "by_type": by_type, "by_state": by_state}

    async def get_classification_nodes(self, project: str) -> dict[str, Any]:
        response = await self._client.request(
            "GET", f"/{project}/_apis/wit/classificationnodes",
            params={"$depth": "10"},
        )
        result: dict[str, Any] = response.json()
        return result

    async def get_custom_fields_count(
        self, process_id: str, work_item_type_ref_name: str,
    ) -> int:
        response = await self._client.request(
            "GET",
            f"/_apis/work/processes/{process_id}/workItemTypes/"
            f"{work_item_type_ref_name}/fields",
        )
        data = response.json()
        return sum(
            1 for f in data.get("value", []) if f.get("customization") == "custom"
        )

    # --- Artifact feed / test plan / branch policy / TFVC methods ---

    async def list_artifact_feeds(
        self, project: str | None = None,
    ) -> list[dict[str, Any]]:
        """List artifact feeds.

        Eager-raises :class:`UnsupportedOnAzureDevOpsServerError` if the
        Package Management extension is not installed.
        """
        caps = await self.get_capabilities()
        if not caps.supports_artifact_feeds:
            raise UnsupportedOnAzureDevOpsServerError(
                "Artifact feeds are not available on this Azure DevOps Server "
                "instance (the optional Package Management extension is not "
                "installed or could not be probed).",
                capability="supports_artifact_feeds",
                api_version=caps.api_version,
                remediation=(
                    "The Package Management extension is required for "
                    "/_apis/packaging/feeds. Install via the server administration "
                    "console (Marketplace → install on collection)."
                ),
            )
        url = (
            f"/{project}/_apis/packaging/feeds"
            if project else "/_apis/packaging/feeds"
        )
        response = await self._client.request("GET", url)
        result: list[dict[str, Any]] = response.json().get("value", [])
        return result

    async def list_test_plans(self, project: str) -> list[dict[str, Any]]:
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client, f"/{project}/_apis/testplan/plans",
                params={"$top": "100"},
            )
        ]

    async def list_branch_policies(self, project: str) -> list[dict[str, Any]]:
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client, f"/{project}/_apis/git/policy/configurations",
                params={"$top": "100"},
            )
        ]

    async def list_tfvc_changesets(self, project: str) -> dict[str, Any]:
        try:
            response = await self._client.request(
                "GET", f"/{project}/_apis/tfvc/changesets",
                params={"$top": "1", "$orderby": "id desc"},
            )
            data = response.json()
            changesets = data.get("value", [])
            if not changesets:
                return {"total_changesets": 0, "latest_changeset_date": None}
            latest = changesets[0]
            total = 0
            async for _ in paginate_via_adoclient_skip_top(
                self._client, f"/{project}/_apis/tfvc/changesets",
                page_size=100,
            ):
                total += 1
            return {
                "total_changesets": total,
                "latest_changeset_date": latest.get("createdDate"),
            }
        except APIError as exc:
            if exc.status_code == HTTPStatus.NOT_FOUND:
                return {"total_changesets": 0, "latest_changeset_date": None}
            raise

    # --- User / entitlement methods ---

    async def list_user_entitlements(self) -> list[dict[str, Any]]:
        """**Always raises** on Server — the vsaex Member Entitlements API is
        cloud-only.
        """
        caps = await self.get_capabilities()
        raise UnsupportedOnAzureDevOpsServerError(
            "Member Entitlements (vsaex) API is cloud-only and not available "
            "on Azure DevOps Server.",
            capability="supports_user_entitlements",
            api_version=caps.api_version,
            remediation=(
                "Member Entitlements (vsaex) API is cloud-only. On Azure "
                "DevOps Server, list users via list_users() (Graph API) or "
                "query /_apis/identities directly through the underlying client."
            ),
        )

    async def list_users(
        self, *, workspace: str | None = None,
        page: int = 1, page_size: int = 100,
    ) -> list[User]:
        """List users via the Graph API.

        Eager-raises :class:`UnsupportedOnAzureDevOpsServerError` if the
        Graph extension is not installed. Uses the **probe-resolved Graph
        api-version** (``self._client.graph_api_version``) — that is the
        variant (``-preview.1`` suffix or plain) that the Graph
        soft-capability probe established works on this Server instance.
        Sending plain ``caps.api_version`` here would 400 on Server
        deployments that require the preview suffix.
        """
        caps = await self.get_capabilities()
        if not caps.supports_graph_api:
            raise UnsupportedOnAzureDevOpsServerError(
                "Graph API is not available on this Azure DevOps Server "
                "instance (the optional Graph extension is not installed "
                "or could not be probed).",
                capability="supports_graph_api",
                api_version=caps.api_version,
                remediation=(
                    "The Graph extension is required for /_apis/graph/users. "
                    "On Server 2019+, install the Graph extension via the "
                    "server administration console (Marketplace → install on "
                    "collection)."
                ),
            )
        graph_api_version = self._client.graph_api_version
        # supports_graph_api is True only when the probe found a working
        # variant, so graph_api_version must be set. Defensive fallback for
        # the unlikely case where capabilities were constructor-injected
        # without a corresponding probe run.
        if graph_api_version is None:
            graph_api_version = caps.api_version
        return [
            User(
                id=entry.get("descriptor", entry.get("originId", "")),
                username=entry.get("principalName", ""),
                display_name=entry.get("displayName"),
                email=entry.get("mailAddress"),
                source="azure-devops",
            )
            async for entry in paginate_via_adoclient_continuation_token(
                self._client, "/_apis/graph/users",
                params={"api-version": graph_api_version},
            )
        ]

    async def get_user(self, user_id: str) -> User | None:
        raise NotImplementedError

    # --- Lifecycle ---

    async def close(self) -> None:
        await self._client.close()

    async def __aenter__(self) -> Self:
        # Idempotent — ADOServerClient.connect() is itself idempotent.
        # Ensures the underlying client is probe-resolved before per-method
        # calls run, even if the caller forgot to use `async with` on the
        # client itself.
        await self._client.connect()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.close()
```

- [ ] **Step 2: Re-export from `src/ado_source_core/adapters/__init__.py`**

```python
"""Source-system adapter abstractions and concrete implementations."""

from ado_source_core.adapters.ado_cloud import AzureDevOpsCloudAdapter
from ado_source_core.adapters.ado_server import AzureDevOpsServerAdapter
from ado_source_core.adapters.source import SourceAdapter

__all__ = ["AzureDevOpsCloudAdapter", "AzureDevOpsServerAdapter", "SourceAdapter"]
```

- [ ] **Step 3: Re-export from `src/ado_source_core/__init__.py`**

Add to the imports line: `from ado_source_core.adapters import AzureDevOpsCloudAdapter, AzureDevOpsServerAdapter, SourceAdapter`. Insert into `__all__` (alphabetical): `"AzureDevOpsServerAdapter"`.

- [ ] **Step 4: Quick smoke — adapter constructs and import succeeds**

```bash
python -c "from ado_source_core import AzureDevOpsServerAdapter; print('OK')"
```

Expected: `OK`.

### Task 6.2 — Write the unit-test file

- [ ] **Step 1: Create `tests/unit/test_adapters_ado_server.py`**

Contents (this is the full test surface — large file, but each test class is small and self-contained):

```python
"""AzureDevOpsServerAdapter unit tests.

Mirrors the cloud adapter tests' shape (one class per method asserting URL
shape + api-version + return-type) plus capability-gating dual-branch
tests, method-set parity test, and pagination-compatibility tests.

Tests use respx to mock the underlying single httpx client at the
collection-scoped base URL.
"""

from __future__ import annotations

import asyncio
import inspect
from typing import Any

import httpx
import pytest
import respx

from ado_source_core import (
    APIError,
    AuthenticationError,
    AzureDevOpsCloudAdapter,
    AzureDevOpsServerAdapter,
    PATAuth,
    Repository,
    SourceCapabilities,
    SourceType,
    UnsupportedOnAzureDevOpsServerError,
    User,
)
from ado_source_core.adapters.source import SourceAdapter
from ado_source_core.client import ADOServerClient


_BASE = "https://devops.example.com/tfs"
_COLLECTION = "DefaultCollection"
_RESOLVED = f"{_BASE}/{_COLLECTION}"


@pytest.fixture
def auth() -> PATAuth:
    return PATAuth(token="dummy-pat")


def _make_client(auth: PATAuth, **overrides: Any) -> ADOServerClient:
    """Server client with explicit api_version=7.0 — bypasses version probe.

    Also seeds ``_capability_overrides`` and ``_graph_api_version`` so any
    subsequent ``await client.connect()`` short-circuits via the
    "explicit api_version + non-empty capability_overrides" path. Adapter
    tests that call ``get_capabilities()`` (which delegates to
    ``connect()``) won't hit unmocked soft-cap probe URLs as a result.
    """
    kwargs: dict[str, Any] = {
        "base_url": _BASE, "collection": _COLLECTION, "auth": auth,
        "api_version": "7.0", "max_retries": 3,
    }
    kwargs.update(overrides)
    client = ADOServerClient(**kwargs)
    client._capability_overrides = {  # type: ignore[attr-defined]
        "supports_graph_api": True,
        "supports_analytics_odata": True,
        "supports_artifact_feeds": True,
    }
    client._graph_api_version = "7.0"  # type: ignore[attr-defined]
    return client


def _make_adapter(
    auth: PATAuth, *, capabilities: SourceCapabilities | None = None,
) -> AzureDevOpsServerAdapter:
    return AzureDevOpsServerAdapter(client=_make_client(auth), capabilities=capabilities)


async def _instant_sleep(_seconds: float) -> None:
    return None


@pytest.fixture(autouse=True)
def _no_sleep(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(asyncio, "sleep", _instant_sleep)


# ---------------------------------------------------------------------------
# Construction / capabilities / lifecycle
# ---------------------------------------------------------------------------


class TestConstruction:
    def test_subclasses_source_adapter(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        assert isinstance(adapter, SourceAdapter)

    def test_NOT_subclass_of_cloud_adapter(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        assert not isinstance(adapter, AzureDevOpsCloudAdapter)


class TestGetCapabilities:
    @pytest.mark.asyncio
    async def test_first_call_applies_overrides_on_top_of_server_default(
        self, auth: PATAuth,
    ) -> None:
        client = _make_client(auth)
        # Simulate a connected client with probe overrides + notes.
        client._capability_overrides = {  # type: ignore[attr-defined]
            "supports_graph_api": False,
            "supports_analytics_odata": False,
            "supports_artifact_feeds": False,
        }
        client._capability_notes = [  # type: ignore[attr-defined]
            "supports_graph_api probe returned 401; PAT may lack vso.graph"
        ]
        adapter = AzureDevOpsServerAdapter(client=client)
        try:
            caps = await adapter.get_capabilities()
            assert caps.source_type == SourceType.AZURE_DEVOPS_SERVER
            assert caps.api_version == "7.0"
            assert caps.supports_user_entitlements is False
            assert caps.supports_graph_api is False
            assert caps.supports_analytics_odata is False
            assert caps.supports_artifact_feeds is False
            assert any("vso.graph" in n for n in caps.notes)
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_subsequent_calls_return_cached(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            caps1 = await adapter.get_capabilities()
            caps2 = await adapter.get_capabilities()
            assert caps1 is caps2
        finally:
            await adapter.close()


class TestVerifyCredentials:
    @pytest.mark.asyncio
    async def test_happy_path(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(
                        200, json={"value": [{"name": "ProjA", "id": "p1"}]},
                    )
                )
                mock.get("/ProjA/_apis/git/repositories").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                mock.get("/ProjA/_apis/build/definitions").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                assert await adapter.verify_credentials() is True
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_401_on_first_probe_raises_with_server_remediation(
        self, auth: PATAuth,
    ) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/projects").mock(return_value=httpx.Response(401))
                with pytest.raises(AuthenticationError, match="Azure DevOps Server"):
                    await adapter.verify_credentials()
        finally:
            await adapter.close()


# ---------------------------------------------------------------------------
# Per-method conformance — one class per method, URL shape + api-version + type.
# ---------------------------------------------------------------------------


class TestListProjects:
    @pytest.mark.asyncio
    async def test_collection_scoped_url_and_api_version(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                route = mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(
                        200, json={"value": [{"id": "p1", "name": "ProjA"}]}
                    )
                )
                projects = await adapter.list_projects()
                assert projects[0]["name"] == "ProjA"
                assert route.calls[0].request.url.params["api-version"] == "7.0"
        finally:
            await adapter.close()


class TestGetProjectDetails:
    @pytest.mark.asyncio
    async def test_url_includes_capabilities_query(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                route = mock.get("/_apis/projects/p1").mock(
                    return_value=httpx.Response(200, json={"id": "p1"})
                )
                result = await adapter.get_project_details("p1")
                assert result == {"id": "p1"}
                assert route.calls[0].request.url.params["includeCapabilities"] == "true"
        finally:
            await adapter.close()


class TestGetProcessTemplate:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/work/processes/agile").mock(
                    return_value=httpx.Response(200, json={"name": "Agile"})
                )
                result = await adapter.get_process_template("agile")
                assert result["name"] == "Agile"
        finally:
            await adapter.close()


class TestListRepositories:
    @pytest.mark.asyncio
    async def test_returns_typed_repository_list(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/git/repositories").mock(
                    return_value=httpx.Response(200, json={"value": [
                        {"id": "r1", "name": "RepoA",
                         "defaultBranch": "refs/heads/main",
                         "size": 1024, "remoteUrl": "https://...",
                         "sshUrl": "git@..."},
                    ]})
                )
                repos = await adapter.list_repositories(project="ProjA")
                assert len(repos) == 1
                assert isinstance(repos[0], Repository)
                assert repos[0].default_branch == "main"
                assert repos[0].full_name == "ProjA/RepoA"
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_missing_project_raises(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with pytest.raises(ValueError, match="project is required"):
                await adapter.list_repositories()
        finally:
            await adapter.close()


class TestGetRepository:
    @pytest.mark.asyncio
    async def test_raises_not_implemented(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with pytest.raises(NotImplementedError):
                await adapter.get_repository("any/id")
        finally:
            await adapter.close()


class TestCountBranches:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/git/repositories/RepoA/refs").mock(
                    return_value=httpx.Response(200, json={"value": [
                        {"name": "refs/heads/main"},
                        {"name": "refs/heads/dev"},
                    ]})
                )
                count = await adapter.count_branches("ProjA/RepoA")
                assert count == 2
        finally:
            await adapter.close()


class TestCountPullRequests:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/git/repositories/RepoA/pullrequests").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": 1}]})
                )
                count = await adapter.count_pull_requests("ProjA/RepoA")
                assert count == 1
        finally:
            await adapter.close()


class TestDetectLfsPatterns:
    @pytest.mark.asyncio
    async def test_finds_filter_lfs(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/git/repositories/RepoA/items").mock(
                    return_value=httpx.Response(200, json={
                        "content": "*.psd filter=lfs diff=lfs merge=lfs -text\n",
                    })
                )
                result = await adapter.detect_lfs_patterns("ProjA/RepoA")
                assert result == {"has_lfs": True, "patterns": ["*.psd"]}
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_404_returns_empty(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/git/repositories/RepoA/items").mock(
                    return_value=httpx.Response(404)
                )
                result = await adapter.detect_lfs_patterns("ProjA/RepoA")
                assert result == {"has_lfs": False, "patterns": []}
        finally:
            await adapter.close()


class TestAnalyzeLargeFiles:
    @pytest.mark.asyncio
    async def test_finds_large_blob(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/git/repositories/RepoA/refs").mock(
                    return_value=httpx.Response(200, json={"value": [
                        {"objectId": "abc"}
                    ]})
                )
                mock.get("/ProjA/_apis/git/repositories/RepoA/commits/abc").mock(
                    return_value=httpx.Response(200, json={"treeId": "tree123"})
                )
                mock.get("/ProjA/_apis/git/repositories/RepoA/trees/tree123").mock(
                    return_value=httpx.Response(200, json={"treeEntries": [
                        {"gitObjectType": "blob", "size": 200_000_000,
                         "relativePath": "huge.bin"}
                    ]})
                )
                result = await adapter.analyze_large_files("ProjA/RepoA")
                assert result["large_files"][0]["path"] == "huge.bin"
        finally:
            await adapter.close()


class TestGetFileContent:
    @pytest.mark.asyncio
    async def test_returns_content(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/git/repositories/RepoA/items").mock(
                    return_value=httpx.Response(200, json={"content": "hello"})
                )
                result = await adapter.get_file_content("ProjA", "RepoA", "README.md")
                assert result == "hello"
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_404_returns_none(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/git/repositories/RepoA/items").mock(
                    return_value=httpx.Response(404)
                )
                result = await adapter.get_file_content("ProjA", "RepoA", "missing")
                assert result is None
        finally:
            await adapter.close()


class TestListBuildDefinitions:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/build/definitions").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": 1}]})
                )
                result = await adapter.list_build_definitions("ProjA")
                assert result == [{"id": 1}]
        finally:
            await adapter.close()


class TestGetBuildDefinition:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/build/definitions/42").mock(
                    return_value=httpx.Response(200, json={"id": 42})
                )
                result = await adapter.get_build_definition("ProjA", 42)
                assert result == {"id": 42}
        finally:
            await adapter.close()


class TestListReleaseDefinitions:
    @pytest.mark.asyncio
    async def test_url_is_collection_scoped_not_vsrm(self, auth: PATAuth) -> None:
        """Server adapter must NOT route to vsrm.dev.azure.com."""
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                route = mock.get("/ProjA/_apis/release/definitions").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": 1}]})
                )
                result = await adapter.list_release_definitions("ProjA")
                assert result == [{"id": 1}]
                assert route.calls[0].request.url.host == "devops.example.com"
        finally:
            await adapter.close()


class TestGetReleaseDefinition:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/release/definitions/7").mock(
                    return_value=httpx.Response(200, json={"id": 7})
                )
                result = await adapter.get_release_definition("ProjA", 7)
                assert result == {"id": 7}
        finally:
            await adapter.close()


class TestListServiceConnections:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/serviceendpoint/endpoints").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": "se1"}]})
                )
                result = await adapter.list_service_connections("ProjA")
                assert result == [{"id": "se1"}]
        finally:
            await adapter.close()


class TestListVariableGroups:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/distributedtask/variablegroups").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": 1}]})
                )
                result = await adapter.list_variable_groups("ProjA")
                assert result == [{"id": 1}]
        finally:
            await adapter.close()


class TestListEnvironments:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/distributedtask/environments").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": 1}]})
                )
                result = await adapter.list_environments("ProjA")
                assert result == [{"id": 1}]
        finally:
            await adapter.close()


class TestGetClassificationNodes:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                route = mock.get("/ProjA/_apis/wit/classificationnodes").mock(
                    return_value=httpx.Response(200, json={"depth": 0})
                )
                result = await adapter.get_classification_nodes("ProjA")
                assert result == {"depth": 0}
                assert route.calls[0].request.url.params["$depth"] == "10"
        finally:
            await adapter.close()


class TestGetCustomFieldsCount:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get(
                    "/_apis/work/processes/proc1/workItemTypes/Bug/fields"
                ).mock(
                    return_value=httpx.Response(200, json={"value": [
                        {"customization": "custom"},
                        {"customization": "system"},
                    ]})
                )
                count = await adapter.get_custom_fields_count("proc1", "Bug")
                assert count == 1
        finally:
            await adapter.close()


class TestListTestPlans:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/testplan/plans").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": 1}]})
                )
                result = await adapter.list_test_plans("ProjA")
                assert result == [{"id": 1}]
        finally:
            await adapter.close()


class TestListBranchPolicies:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/git/policy/configurations").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": 1}]})
                )
                result = await adapter.list_branch_policies("ProjA")
                assert result == [{"id": 1}]
        finally:
            await adapter.close()


class TestListTfvcChangesets:
    @pytest.mark.asyncio
    async def test_returns_summary(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/tfvc/changesets").mock(
                    side_effect=[
                        httpx.Response(200, json={"value": [
                            {"createdDate": "2026-04-01T00:00:00Z"}
                        ]}),
                        httpx.Response(200, json={"value": [{"id": 1}, {"id": 2}]}),
                        httpx.Response(200, json={"value": []}),
                    ]
                )
                result = await adapter.list_tfvc_changesets("ProjA")
                assert result["total_changesets"] == 2
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_404_returns_empty(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/tfvc/changesets").mock(
                    return_value=httpx.Response(404)
                )
                result = await adapter.list_tfvc_changesets("ProjA")
                assert result == {"total_changesets": 0, "latest_changeset_date": None}
        finally:
            await adapter.close()


class TestGetUser:
    @pytest.mark.asyncio
    async def test_raises_not_implemented(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with pytest.raises(NotImplementedError):
                await adapter.get_user("any-id")
        finally:
            await adapter.close()


# ---------------------------------------------------------------------------
# Capability gating — dual-branch tests for each gated method.
# ---------------------------------------------------------------------------


def _server_caps(**overrides: bool) -> SourceCapabilities:
    """Build a server capability set with optional flag overrides."""
    base = SourceCapabilities.server_default(api_version="7.0")
    if overrides:
        whitelisted = {
            k: v for k, v in overrides.items()
            if k in SourceCapabilities.OVERRIDABLE_SOFT_CAPABILITY_KEYS
        }
        return base.with_overrides(whitelisted)
    return base


class TestListUsersGating:
    @pytest.mark.asyncio
    async def test_supports_graph_api_true_uses_probe_resolved_preview_variant(
        self, auth: PATAuth,
    ) -> None:
        """When the probe stored ``graph_api_version="7.0-preview.1"``,
        ``list_users`` MUST send that exact value, not plain
        ``caps.api_version`` (this is the cloud-vs-server delta)."""
        client = _make_client(auth)
        client._graph_api_version = "7.0-preview.1"  # type: ignore[attr-defined]
        adapter = AzureDevOpsServerAdapter(
            client=client,
            capabilities=_server_caps(supports_graph_api=True),
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                route = mock.get("/_apis/graph/users").mock(
                    return_value=httpx.Response(200, json={"value": [
                        {"descriptor": "u1", "principalName": "alice@x",
                         "displayName": "Alice", "mailAddress": "alice@x"}
                    ]})
                )
                users = await adapter.list_users()
                assert len(users) == 1
                assert isinstance(users[0], User)
                assert (
                    route.calls[0].request.url.params["api-version"]
                    == "7.0-preview.1"
                )
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_supports_graph_api_true_with_plain_variant(
        self, auth: PATAuth,
    ) -> None:
        """When the probe found that plain ``7.0`` worked (preview returned
        400), ``list_users`` MUST send plain ``7.0``."""
        client = _make_client(auth)
        client._graph_api_version = "7.0"  # type: ignore[attr-defined]
        adapter = AzureDevOpsServerAdapter(
            client=client,
            capabilities=_server_caps(supports_graph_api=True),
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                route = mock.get("/_apis/graph/users").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                await adapter.list_users()
                assert route.calls[0].request.url.params["api-version"] == "7.0"
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_supports_graph_api_false_raises(self, auth: PATAuth) -> None:
        adapter = AzureDevOpsServerAdapter(
            client=_make_client(auth),
            capabilities=_server_caps(supports_graph_api=False),
        )
        try:
            with pytest.raises(UnsupportedOnAzureDevOpsServerError) as exc_info:
                await adapter.list_users()
            assert exc_info.value.capability == "supports_graph_api"
            assert exc_info.value.api_version == "7.0"
            assert exc_info.value.remediation is not None
            assert "Graph extension" in exc_info.value.remediation
        finally:
            await adapter.close()


class TestQueryWorkItemCountsGating:
    @pytest.mark.asyncio
    async def test_supports_analytics_odata_true_returns_counts(
        self, auth: PATAuth,
    ) -> None:
        adapter = AzureDevOpsServerAdapter(
            client=_make_client(auth),
            capabilities=_server_caps(supports_analytics_odata=True),
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_odata/v4.0-preview/WorkItems").mock(
                    return_value=httpx.Response(200, json={"value": [
                        {"WorkItemType": "Bug", "State": "Active", "Count": 3},
                    ]})
                )
                result = await adapter.query_work_item_counts("ProjA")
                assert result["total"] == 3
                assert result["by_type"]["Bug"] == 3
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_supports_analytics_odata_false_raises(self, auth: PATAuth) -> None:
        adapter = AzureDevOpsServerAdapter(
            client=_make_client(auth),
            capabilities=_server_caps(supports_analytics_odata=False),
        )
        try:
            with pytest.raises(UnsupportedOnAzureDevOpsServerError) as exc_info:
                await adapter.query_work_item_counts("ProjA")
            assert exc_info.value.capability == "supports_analytics_odata"
            assert exc_info.value.remediation is not None
            assert "Analytics extension" in exc_info.value.remediation
        finally:
            await adapter.close()


class TestListArtifactFeedsGating:
    @pytest.mark.asyncio
    async def test_supports_artifact_feeds_true_with_project(
        self, auth: PATAuth,
    ) -> None:
        adapter = AzureDevOpsServerAdapter(
            client=_make_client(auth),
            capabilities=_server_caps(supports_artifact_feeds=True),
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": "f1"}]})
                )
                result = await adapter.list_artifact_feeds("ProjA")
                assert result == [{"id": "f1"}]
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_supports_artifact_feeds_true_without_project(
        self, auth: PATAuth,
    ) -> None:
        """No project arg → collection-level URL `/_apis/packaging/feeds`."""
        adapter = AzureDevOpsServerAdapter(
            client=_make_client(auth),
            capabilities=_server_caps(supports_artifact_feeds=True),
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                route = mock.get("/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": "f0"}]})
                )
                result = await adapter.list_artifact_feeds()
                assert result == [{"id": "f0"}]
                assert route.call_count == 1
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_supports_artifact_feeds_false_raises(self, auth: PATAuth) -> None:
        adapter = AzureDevOpsServerAdapter(
            client=_make_client(auth),
            capabilities=_server_caps(supports_artifact_feeds=False),
        )
        try:
            with pytest.raises(UnsupportedOnAzureDevOpsServerError) as exc_info:
                await adapter.list_artifact_feeds("ProjA")
            assert exc_info.value.capability == "supports_artifact_feeds"
            assert exc_info.value.remediation is not None
            assert "Package Management" in exc_info.value.remediation
        finally:
            await adapter.close()


class TestListUserEntitlementsAlwaysRaises:
    @pytest.mark.asyncio
    async def test_raises_with_capability_user_entitlements(
        self, auth: PATAuth,
    ) -> None:
        # Even with a capability set that has supports_user_entitlements=True
        # (impossible normally, but constructible via direct model build),
        # the method MUST raise — it's a hard-coded raise.
        # Using server_default which sets it to False.
        adapter = _make_adapter(auth)
        try:
            with pytest.raises(UnsupportedOnAzureDevOpsServerError) as exc_info:
                await adapter.list_user_entitlements()
            assert exc_info.value.capability == "supports_user_entitlements"
            assert exc_info.value.api_version == "7.0"
            assert exc_info.value.remediation is not None
            assert "cloud-only" in exc_info.value.remediation
        finally:
            await adapter.close()


# ---------------------------------------------------------------------------
# Method-set parity test
# ---------------------------------------------------------------------------


def _public_async_methods(cls: type) -> dict[str, inspect.Signature]:
    out: dict[str, inspect.Signature] = {}
    for name, member in inspect.getmembers(cls):
        if name.startswith("_"):
            continue
        if not callable(member):
            continue
        if inspect.iscoroutinefunction(member):
            out[name] = inspect.signature(member)
    return out


class TestMethodSetParity:
    """Sibling-not-subclass means we need a programmatic check that the
    cloud and server adapters expose the same public method surface AND
    the lifecycle dunders (`__aenter__` / `__aexit__` / `close`)."""

    def test_method_names_match(self) -> None:
        cloud = set(_public_async_methods(AzureDevOpsCloudAdapter))
        server = set(_public_async_methods(AzureDevOpsServerAdapter))
        assert cloud == server, (
            f"Public method set diverged.\n"
            f"  Only in cloud: {sorted(cloud - server)}\n"
            f"  Only in server: {sorted(server - cloud)}"
        )

    def test_signatures_match(self) -> None:
        cloud = _public_async_methods(AzureDevOpsCloudAdapter)
        server = _public_async_methods(AzureDevOpsServerAdapter)
        for name in cloud:
            assert cloud[name] == server[name], (
                f"Signature divergence on {name}:\n"
                f"  cloud:  {cloud[name]}\n"
                f"  server: {server[name]}"
            )

    @pytest.mark.parametrize("dunder", ["__aenter__", "__aexit__", "close"])
    def test_lifecycle_dunder_signatures_match(self, dunder: str) -> None:
        """`__aenter__` / `__aexit__` / `close` are part of the contract too —
        any divergence in these breaks `async with adapter` interop."""
        cloud_sig = inspect.signature(getattr(AzureDevOpsCloudAdapter, dunder))
        server_sig = inspect.signature(getattr(AzureDevOpsServerAdapter, dunder))
        assert cloud_sig == server_sig, (
            f"Signature divergence on {dunder}:\n"
            f"  cloud:  {cloud_sig}\n"
            f"  server: {server_sig}"
        )


# ---------------------------------------------------------------------------
# Pagination compatibility
# ---------------------------------------------------------------------------


class TestPaginationCompatibility:
    """The ADOClient-aware paginators in pagination.py take a BaseADOClient.
    Confirm each helper works transparently against an ADOServerClient."""

    @pytest.mark.asyncio
    async def test_continuation_token_paginator(self, auth: PATAuth) -> None:
        # list_projects exercises paginate_via_adoclient_continuation_token.
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/projects").mock(
                    side_effect=[
                        httpx.Response(
                            200,
                            json={"value": [{"id": "p1", "name": "A"}]},
                            headers={"x-ms-continuationtoken": "page2"},
                        ),
                        httpx.Response(200, json={"value": [{"id": "p2", "name": "B"}]}),
                    ]
                )
                projects = await adapter.list_projects()
                assert [p["name"] for p in projects] == ["A", "B"]
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_skip_top_paginator(self, auth: PATAuth) -> None:
        # count_pull_requests exercises paginate_via_adoclient_skip_top.
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/git/repositories/RepoA/pullrequests").mock(
                    side_effect=[
                        httpx.Response(200, json={"value": [{"id": i} for i in range(100)]}),
                        httpx.Response(200, json={"value": [{"id": 100}]}),
                    ]
                )
                count = await adapter.count_pull_requests("ProjA/RepoA")
                assert count == 101
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_body_continuation_token_paginator_accepts_server_client(
        self, auth: PATAuth,
    ) -> None:
        """The body-token paginator isn't exercised by any server-adapter
        method (vsaex Member Entitlements is hard-False on Server), so we
        invoke it directly to confirm it accepts an ADOServerClient."""
        from ado_source_core.pagination import (
            paginate_via_adoclient_body_continuation_token,
        )
        client = _make_client(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/userentitlements").mock(
                    return_value=httpx.Response(200, json={"items": [{"id": "u1"}]})
                )
                items = [
                    item
                    async for item in paginate_via_adoclient_body_continuation_token(
                        client, "/_apis/userentitlements", items_key="items",
                    )
                ]
                assert items == [{"id": "u1"}]
        finally:
            await client.close()


# ---------------------------------------------------------------------------
# Lifecycle
# ---------------------------------------------------------------------------


class TestLifecycle:
    @pytest.mark.asyncio
    async def test_close_closes_underlying_client(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        single = adapter.client.httpx_client("dev")
        await adapter.close()
        assert single.is_closed

    @pytest.mark.asyncio
    async def test_double_close_is_idempotent(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        await adapter.close()
        await adapter.close()  # must not raise

    @pytest.mark.asyncio
    async def test_aenter_runs_underlying_connect(self, auth: PATAuth) -> None:
        """`async with adapter` calls client.connect(), which is idempotent.

        ``_make_client`` pre-seeds ``client._capability_overrides`` and
        ``_graph_api_version`` so the explicit-api-version path of
        ``connect()`` short-circuits without issuing any HTTP — no respx
        mocks needed for this test.
        """
        async with _make_adapter(auth) as adapter:
            assert adapter.client.api_version == "7.0"
```

- [ ] **Step 2: Run the new tests**

```bash
pytest tests/unit/test_adapters_ado_server.py -v 2>&1 | tail -40
```

Expected: All ~50 tests PASS. If `TestMethodSetParity` fails, the cloud and server adapters expose different public method sets — fix the missing/extra methods on the server adapter before proceeding.

### Task 6.3 — Full sweep + commit

- [ ] **Step 1: Full sweep**

```bash
ruff check src tests && ruff format --check src tests && mypy src && pytest -v
```

Expected: All clean.

- [ ] **Step 2: Commit**

```bash
git add src/ado_source_core/adapters/ado_server.py src/ado_source_core/adapters/__init__.py src/ado_source_core/__init__.py tests/unit/test_adapters_ado_server.py
git commit -m "feat(adapter): AzureDevOpsServerAdapter

Sibling of AzureDevOpsCloudAdapter (NOT a subclass) with the full
read-side surface mirroring cloud's contract. Capability-gated methods
(list_users, query_work_item_counts, list_artifact_feeds,
list_user_entitlements) eager-raise UnsupportedOnAzureDevOpsServerError
with capability + api_version + remediation populated for downstream
discovery-report consumers.

Sibling-not-subclass decision is verified by a method-set parity test
(introspection-based) that asserts cloud and server expose the same
public async method names with identical signatures — drift-vector
mitigation since we can't rely on inheritance.

list_users uses the probe-resolved api-version stored on the capability
set (preview-suffix-aware via discovery). list_user_entitlements
ALWAYS raises (vsaex is cloud-only); v0.4.0 may add a degraded
fallback via /_apis/identities.

Donor: ado2gh-core/src/ado2gh/adapters/ado_server.py @ 160de58.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>"
git push
```

(Task 6 push step.)

---

## Task 7: Integration smoke suite for Server

**Goal:** Add 5 read-only integration tests gated on `ADO_SERVER_URL` / `ADO_SERVER_PAT` (and optional `ADO_SERVER_COLLECTION`). Update conftest fixtures + `_env_or_skip` to be suite-aware. Update `pyproject.toml` marker description.

**Files:**
- Modify: `tests/integration/conftest.py`
- Create: `tests/integration/test_smoke_server.py`
- Modify: `pyproject.toml`

### Task 7.1 — Update conftest with server fixtures + suite-aware skip messages

- [ ] **Step 1: Edit `tests/integration/conftest.py`**

Replace the file contents with:

```python
"""Integration test fixtures.

Skips suites whose env vars are not populated. Both cloud and server suites
co-exist under one ``integration`` marker; each gates its fixtures on its
own env-var set, so ``pytest -m integration`` runs whichever has
credentials populated.
"""

from __future__ import annotations

import os
from collections.abc import AsyncIterator

import pytest
import pytest_asyncio

from ado_source_core import ADOClient, ADOServerClient, PATAuth


def _env_or_skip(name: str, *, suite: str = "integration") -> str:
    value = os.environ.get(name)
    if not value:
        pytest.skip(f"skipping {suite} integration tests: {name} not set")
    return value


# --- Cloud fixtures -----------------------------------------------------------


@pytest.fixture(scope="session")
def ado_org() -> str:
    return _env_or_skip("ADO_ORG", suite="cloud")


@pytest.fixture(scope="session")
def ado_pat() -> str:
    return _env_or_skip("ADO_PAT", suite="cloud")


@pytest_asyncio.fixture(scope="session", loop_scope="session")
async def client(ado_org: str, ado_pat: str) -> AsyncIterator[ADOClient]:
    """One ADOClient per session — avoids rebuilding 6 httpx clients per test."""
    async with ADOClient(organization=ado_org, auth=PATAuth(token=ado_pat)) as c:
        yield c


# --- Server fixtures ----------------------------------------------------------


@pytest.fixture(scope="session")
def ado_server_url() -> str:
    return _env_or_skip("ADO_SERVER_URL", suite="server")


@pytest.fixture(scope="session")
def ado_server_collection() -> str:
    return os.environ.get("ADO_SERVER_COLLECTION", "DefaultCollection")


@pytest.fixture(scope="session")
def ado_server_pat() -> str:
    return _env_or_skip("ADO_SERVER_PAT", suite="server")


@pytest_asyncio.fixture(scope="session", loop_scope="session")
async def server_client(
    ado_server_url: str, ado_server_collection: str, ado_server_pat: str,
) -> AsyncIterator[ADOServerClient]:
    """One ADOServerClient per session. __aenter__ runs the api-version
    + capability probe."""
    async with ADOServerClient(
        base_url=ado_server_url,
        collection=ado_server_collection,
        auth=PATAuth(token=ado_server_pat),
    ) as c:
        yield c
```

### Task 7.2 — Failing test for server smoke suite

- [ ] **Step 1: Create `tests/integration/test_smoke_server.py`**

```python
"""Read-only smoke tests against a real Azure DevOps Server instance.

Gated by the ``integration`` pytest marker plus the env vars enforced in
``conftest.py``. Hits the real Server REST API but only via read endpoints,
so the suite is idempotent and safe to run repeatedly. The branch/PR-count
test caps repo discovery at ``_MAX_DISCOVERY_PROJECTS`` to keep API
traffic bounded on large collections.

Run locally::

    ADO_SERVER_URL=<url> ADO_SERVER_PAT=<pat> \\
      [ADO_SERVER_COLLECTION=<coll>] \\
      pytest tests/integration/test_smoke_server.py -m integration -v
"""

from __future__ import annotations

import pytest

from ado_source_core import (
    ADOServerClient,
    AzureDevOpsServerAdapter,
    Repository,
    UnsupportedOnAzureDevOpsServerError,
    User,
)

pytestmark = [
    pytest.mark.integration,
    pytest.mark.asyncio(loop_scope="session"),
]

_MAX_DISCOVERY_PROJECTS = 5


async def test_verify_credentials_succeeds(server_client: ADOServerClient) -> None:
    adapter = AzureDevOpsServerAdapter(client=server_client)
    assert await adapter.verify_credentials() is True


async def test_list_projects_returns_iterable(server_client: ADOServerClient) -> None:
    adapter = AzureDevOpsServerAdapter(client=server_client)
    projects = await adapter.list_projects()
    assert isinstance(projects, list)
    if not projects:
        pytest.skip("collection has no projects to query")
    first = projects[0]
    assert "id" in first
    assert "name" in first


async def test_list_repositories_for_first_project(
    server_client: ADOServerClient,
) -> None:
    adapter = AzureDevOpsServerAdapter(client=server_client)
    projects = await adapter.list_projects()
    if not projects:
        pytest.skip("collection has no projects to query")
    project_name = projects[0]["name"]
    repos = await adapter.list_repositories(project=project_name)
    assert isinstance(repos, list)
    for repo in repos:
        assert isinstance(repo, Repository)
        assert repo.source == "azure-devops"
        assert repo.project_name == project_name


async def test_count_branches_and_prs_for_first_repo(
    server_client: ADOServerClient,
) -> None:
    adapter = AzureDevOpsServerAdapter(client=server_client)
    projects = await adapter.list_projects()

    repo_for_counts: Repository | None = None
    project_name_for_counts: str | None = None
    for project in projects[:_MAX_DISCOVERY_PROJECTS]:
        repos = await adapter.list_repositories(project=project["name"])
        for repo in repos:
            if not repo.is_disabled:
                repo_for_counts = repo
                project_name_for_counts = project["name"]
                break
        if repo_for_counts is not None:
            break

    if repo_for_counts is None or project_name_for_counts is None:
        pytest.skip(
            f"no enabled repositories found in first {_MAX_DISCOVERY_PROJECTS} "
            "projects; cannot exercise counts"
        )

    repo_id = f"{project_name_for_counts}/{repo_for_counts.id}"
    branch_count = await adapter.count_branches(repo_id)
    pr_count = await adapter.count_pull_requests(repo_id)

    assert isinstance(branch_count, int)
    assert isinstance(pr_count, int)
    assert branch_count >= 0
    assert pr_count >= 0


async def test_list_users_or_assert_unsupported_when_graph_unavailable(
    server_client: ADOServerClient,
) -> None:
    """Drives a contract assertion either way — does NOT skip.

    If Graph is installed on this Server instance, expect User[] back.
    If not, expect UnsupportedOnAzureDevOpsServerError with the right
    capability + remediation fields.
    """
    adapter = AzureDevOpsServerAdapter(client=server_client)
    caps = await adapter.get_capabilities()
    if caps.supports_graph_api:
        users = await adapter.list_users()
        assert isinstance(users, list)
        for user in users:
            assert isinstance(user, User)
            assert user.source == "azure-devops"
    else:
        with pytest.raises(UnsupportedOnAzureDevOpsServerError) as exc_info:
            await adapter.list_users()
        assert exc_info.value.capability == "supports_graph_api"
        assert exc_info.value.api_version == caps.api_version
        assert exc_info.value.remediation is not None
        assert "Graph extension" in exc_info.value.remediation
```

### Task 7.3 — Update marker description

- [ ] **Step 1: Edit `pyproject.toml`**

Find the `[tool.pytest.ini_options]` block:

```toml
markers = [
    "integration: requires ADO_ORG and ADO_PAT env vars; hits real ADO API",
]
```

Replace with:

```toml
markers = [
    "integration: requires ADO_ORG+ADO_PAT (cloud suite) and/or ADO_SERVER_URL+ADO_SERVER_PAT (server suite); hits real ADO API",
]
```

### Task 7.4 — Verify the unit suite still skips integration; commit

- [ ] **Step 1: Run the unit suite — confirm integration tests are deselected**

```bash
pytest -v 2>&1 | tail -10
```

Expected: All unit tests PASS. The `addopts = "-m 'not integration'"` in `pyproject.toml` already deselects the marker, so cloud + server smoke tests are skipped silently.

- [ ] **Step 2: Run the integration suite explicitly without env vars set**

Use a subshell so the `unset` does NOT mutate the caller's shell environment (the engineer may have these vars set for a real run later in the same session):

```bash
(unset ADO_ORG ADO_PAT ADO_SERVER_URL ADO_SERVER_PAT && pytest -v -m integration tests/integration/) 2>&1 | tail -20
```

Expected: All cloud + server tests SKIP with messages like "skipping cloud integration tests: ADO_ORG not set" and "skipping server integration tests: ADO_SERVER_URL not set".

- [ ] **Step 3: Full sweep + commit**

```bash
ruff check src tests && ruff format --check src tests && mypy src && pytest -v
git add tests/integration/conftest.py tests/integration/test_smoke_server.py pyproject.toml
git commit -m "test(integration): server smoke suite gated on ADO_SERVER_URL/PAT

Five read-only integration tests against a real Azure DevOps Server
instance, mirroring the cloud smoke suite shape. Co-exists with the
cloud suite under the same 'integration' marker; each suite gates on
its own env-var set, so pytest -m integration runs whichever has
credentials populated.

The list_users test does NOT skip when Graph is unavailable — it
asserts the UnsupportedOnAzureDevOpsServerError contract instead.
Drives a contract assertion either way, surfacing capability gaps in
the discovery output rather than silently passing them.

conftest._env_or_skip is now suite-aware — emits messages like
'skipping server integration tests: ADO_SERVER_URL not set' so mixed
cloud/server skips are unambiguous in CI logs.

Marker description in pyproject.toml updated to mention both env-var
sets.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>"
git push
```

(Task 7 push step.)

---

## Task 8: Documentation — README + CHANGELOG

**Goal:** Add a "Cloud vs Server" section to README with comprehensive capability matrix + Server quickstart. Populate `[Unreleased]` in CHANGELOG with Added / Changed (BREAKING) entries.

**Files:**
- Modify: `README.md`
- Modify: `CHANGELOG.md`

### Task 8.1 — README "Cloud vs Server" section

- [ ] **Step 1: Edit `README.md`** — insert a new section after the "Quickstart" code block (currently after line 29, before "## Status")

```markdown
## Cloud vs Server

`ado-source-core` ships two adapters:

- `AzureDevOpsCloudAdapter` — for Azure DevOps Services (`dev.azure.com/{org}`).
  REST API pinned to 7.1.
- `AzureDevOpsServerAdapter` — for self-hosted Azure DevOps Server (the
  on-prem product, formerly TFS). REST api-version is auto-discovered at
  construction time via `/_apis/connectionData` + candidate iteration.

### Supported Server versions

| Server release            | REST api-version |
| ------------------------- | ---------------- |
| Azure DevOps Server 2022  | 7.0              |
| Azure DevOps Server 2020  | 6.0              |
| Azure DevOps Server 2019 Update 1+ | 5.1     |
| Azure DevOps Server 2019 RTW | 5.0           |

TFS 2018 (REST 4.x) and earlier are out of scope for v0.3.0. Server
deployments with PATs disabled at the org-policy level (or NTLM-only
deployments behind enterprise SSO) are not supported — PAT support is
a hard prerequisite. NTLM/Negotiate auth is a v0.4.0 candidate.

### Server quickstart

```python
import asyncio
from ado_source_core import (
    ADOServerClient, AzureDevOpsServerAdapter, PATAuth,
    UnsupportedOnAzureDevOpsServerError,
)

async def main():
    auth = PATAuth(token="your-server-pat")
    async with ADOServerClient(
        base_url="https://devops.example.com:8080/tfs",
        collection="DefaultCollection",
        auth=auth,
    ) as client:
        adapter = AzureDevOpsServerAdapter(client=client)
        caps = await adapter.get_capabilities()
        print(f"Resolved api-version: {caps.api_version}")
        print(f"Notes: {caps.notes}")

        # Always-available calls work the same as on cloud:
        for project in await adapter.list_projects():
            print(project["name"])

        # Optional calls gate on capability flags:
        if caps.supports_graph_api:
            for user in await adapter.list_users():
                print(user.username)
        else:
            print("Graph extension not installed; user listing unavailable.")

        # Capabilities that don't exist on Server raise:
        try:
            await adapter.list_user_entitlements()
        except UnsupportedOnAzureDevOpsServerError as exc:
            print(f"Skipped {exc.capability}: {exc.remediation}")

asyncio.run(main())
```

### Capability matrix

Comprehensive flag-by-flag state across both adapters:

| Capability                      | Cloud | Server                                          | Notes                                                                  |
| ------------------------------- | ----- | ----------------------------------------------- | ---------------------------------------------------------------------- |
| `supports_collections`          | False | True                                            | Server is collection-scoped; cloud is org-scoped.                       |
| `supports_pipelines`            | True  | True                                            | Build defs + classic release defs both available.                       |
| `supports_pull_request_threads` | True  | True                                            | Available on Server 2019+.                                              |
| `supports_user_entitlements`    | True  | **False (hard)**                                | vsaex Member Entitlements API is cloud-only.                            |
| `supports_graph_api`            | True  | **Probed**                                      | Requires the Graph extension on Server.                                 |
| `supports_analytics_odata`      | True  | **Probed**                                      | Auto-installed on Server 2020+; manual install on Server 2019.          |
| `supports_artifact_feeds`       | True  | **Probed**                                      | Requires the Package Management extension on Server.                    |
| `compatibility_mode`            | False | True iff api-version is `5.0` or `5.1`          | Server 2019 (RTW or Update 1+) — adapter behavior unchanged; flag is informational. |

When a probe-resolvable capability is `False`, the corresponding adapter
methods raise `UnsupportedOnAzureDevOpsServerError` with `capability`,
`api_version`, and `remediation` fields populated for downstream
discovery reports.
```

- [ ] **Step 2: Verify the markdown structure**

```bash
python <<'PY'
import pathlib, re
src = pathlib.Path("README.md").read_text()
# Section heading present.
assert "## Cloud vs Server" in src, "missing section heading"
# Capability matrix table present.
assert "| Capability " in src, "missing matrix header"
# Each expected capability row, asserted by exact string.
expected_rows = [
    "supports_collections",
    "supports_pipelines",
    "supports_pull_request_threads",
    "supports_user_entitlements",
    "supports_graph_api",
    "supports_analytics_odata",
    "supports_artifact_feeds",
    "compatibility_mode",
]
for row in expected_rows:
    assert row in src, f"matrix missing row: {row}"
# Server quickstart code fence present and balanced.
fences = re.findall(r"^```", src, flags=re.MULTILINE)
assert len(fences) % 2 == 0, "unmatched code fences"
# Supported-versions table has all 4 release rows.
for release in ("Server 2022", "Server 2020", "Server 2019 Update 1", "Server 2019 RTW"):
    assert release in src, f"missing {release} row"
print("OK")
PY
```

Expected: `OK`.

### Task 8.2 — CHANGELOG `[Unreleased]` block

- [ ] **Step 1: Edit `CHANGELOG.md`**

Replace the empty `## [Unreleased]` block (currently line 8) with:

```markdown
## [Unreleased]

### Added
- `AzureDevOpsServerAdapter` — read-side adapter for Azure DevOps Server
  (releases 2022 / 2020 / 2019 Update 1+ / 2019 RTW; REST 7.0 / 6.0 / 5.1 / 5.0).
  Same method-by-method contract as `AzureDevOpsCloudAdapter`; a programmatic
  parity test asserts the two adapters expose identical public method
  surfaces. Lifted from `ado2gh-core` @ `160de58`.
- `ADOServerClient` — single-host, collection-aware HTTP client with
  auto-discovered REST api-version via the new `api_version_discovery`
  module. `connectionData` probe runs first; falls back to candidate
  iteration over `("7.0", "6.0", "5.1", "5.0")`. Soft-capability probes
  (Graph / Analytics / Package Management) run in parallel and populate
  `SourceCapabilities` flags.
- `BaseADOClient` — abstract base extracted from the existing
  `ADOClient`, sharing the retry / rate-limit / error-mapping loop with
  the new server client.
- `api_version_discovery` module with `SERVER_API_VERSION_CANDIDATES`,
  `ServerProbeResult` (frozen dataclass), and `resolve_server_api_version`.
- `UnsupportedOnAzureDevOpsServerError` typed exception raised when
  capability-gated server-adapter methods hit a missing on-prem
  extension. Carries `capability`, required `api_version`, and optional
  `remediation` for downstream discovery-report consumers.
- `SourceCapabilities.server_default(api_version=...)` factory + new
  soft-capability flags `supports_graph_api`, `supports_analytics_odata`,
  `supports_artifact_feeds`, plus `with_overrides()` for applying probe
  results (whitelist enforced — only soft-cap flags are overridable).
- Server integration smoke suite (`tests/integration/test_smoke_server.py`)
  gated on `ADO_SERVER_URL` / `ADO_SERVER_PAT` (and optional
  `ADO_SERVER_COLLECTION`, defaulting to `DefaultCollection`). Co-exists
  with the cloud smoke suite under the same `integration` marker; each
  suite gates on its own env-var set, so `pytest -m integration` runs
  whichever has credentials populated.

### Changed
- **BREAKING (0.x):** `SourceCapabilities.supports_packages` removed in
  favor of `supports_artifact_feeds`. Functionally equivalent — same
  boolean semantics; renamed for on-prem clarity. Migration: rename
  `caps.supports_packages` reads to `caps.supports_artifact_feeds`.
- The transport class hierarchy was reshaped: `ADOClient` is now a
  module-level alias for the renamed `ADOCloudClient` (extracted from
  the new abstract `BaseADOClient`). Existing imports keep working.
  **Reflection-derived class names change:** `type(client).__name__`
  now returns `"ADOCloudClient"` instead of `"ADOClient"` — telemetry,
  metrics labels, log scrapers, or pickled class metadata that key on
  the old name need to be updated.
- `pagination.py` type annotations migrate from `ADOClient` to
  `BaseADOClient` so the helpers type-check cleanly with both subclasses.
  No runtime change.
- Integration test marker description in `pyproject.toml` updated to
  mention both cloud and server env-var sets.
```

- [ ] **Step 2: Verify the existing `[Unreleased]` anchor remains unchanged**

The file already has:

```
[Unreleased]: https://github.com/n8group-oss/ado-source-core/compare/v0.2.0...HEAD
```

Leave that line as-is — no edit needed in this PR. The v0.3.0 anchor lands when the version bump commit happens (separately, not in this PR).

### Task 8.3 — Final sweep + commit

- [ ] **Step 1: Full sweep**

```bash
ruff check src tests && ruff format --check src tests && mypy src && pytest -v
```

Expected: All clean.

- [ ] **Step 2: Commit**

```bash
git add README.md CHANGELOG.md
git commit -m "docs: README Cloud vs Server section + CHANGELOG [Unreleased]

Adds a 'Cloud vs Server' README section with supported Server versions
table (2022 / 2020 / 2019 Update 1+ / 2019 RTW → REST 7.0 / 6.0 / 5.1 / 5.0),
Server quickstart, and a comprehensive capability matrix (full state of
all flags, not deltas-only).

Populates the CHANGELOG [Unreleased] block with Added entries for every
new public symbol and Changed entries calling out:
- BREAKING (0.x) removal of supports_packages → supports_artifact_feeds
- ADOClient → ADOCloudClient class hierarchy reshape (with reflection
  caveat)
- pagination.py type annotation migration

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>"
git push
```

(Task 8 push step.)

---

## Final verification before opening the PR

- [ ] **Step 1: Run the complete sweep**

```bash
cd /home/marcin/projects/n8group-oss/ado-source-core/.worktrees/server-adapter
ruff check src tests
ruff format --check src tests
mypy src
pytest -v
```

Expected: Everything clean.

- [ ] **Step 2: Confirm branch state**

```bash
git log --oneline main..HEAD
git status -s
```

Expected: Eight `feat:` / `refactor:` / `test:` / `docs:` commits on top of the two `docs(spec)` / `docs(plan)` commits. Working tree clean.

- [ ] **Step 3: Codex adversarial review of the implemented code (BEFORE final push)**

**Prerequisite:** the executing agent must have access to the
`codex:codex-rescue` subagent (Claude Code with the codex plugin
installed). If you don't have it available, dispatch a generic
`general-purpose` subagent prompted with "adversarial code-review of
the diff against `main`; surface critical/high/medium findings with
file:line references" — it's a weaker but viable substitute.

Apply Critical and High findings as code fixes BEFORE pushing the final
commit. Medium and Low findings can be addressed in follow-up commits
on the same branch (still pre-merge). If a Critical finding requires a
plan change rather than just a code fix, escalate to the supervisor
agent before patching.

- [ ] **Step 4: Open the PR**

```bash
gh pr create --title "feat: Azure DevOps Server adapter + api-version discovery (2022/2020/2019)" --body "$(cat <<'EOF'
## Summary

- Adds `AzureDevOpsServerAdapter` for Azure DevOps Server (releases 2022 / 2020 / 2019 Update 1+ / 2019 RTW; REST 7.0 / 6.0 / 5.1 / 5.0). Same read-side surface as the cloud adapter; method-set parity test enforces the contract.
- Auto-discovers REST api-version via `/_apis/connectionData` + candidate iteration; soft-capability probes (Graph / Analytics / Package Management) populate `SourceCapabilities` flags.
- Eager-raise `UnsupportedOnAzureDevOpsServerError` on missing-capability calls, with `capability` / `api_version` / `remediation` populated for downstream discovery-report consumers.

Spec: `docs/superpowers/specs/2026-05-06-azure-devops-server-adapter-design.md`
Donor: `n8group-oss/ado2gh-core` @ `160de58`

## Breaking change (0.x)

- `SourceCapabilities.supports_packages` removed — replaced by `supports_artifact_feeds`. Migration: rename field reads.

See `CHANGELOG.md` `[Unreleased]` block for the full list.

## Test plan

- [ ] All unit tests green (`pytest -v`)
- [ ] mypy strict clean (`mypy src`)
- [ ] ruff clean (`ruff check src tests` + `ruff format --check src tests`)
- [ ] Cloud integration smoke green (existing — verify no regression):
      `ADO_ORG=<org> ADO_PAT=<pat> pytest -m integration tests/integration/test_smoke.py -v`
- [ ] Server integration smoke green (NEW — requires user-supplied credentials):
      `ADO_SERVER_URL=<url> ADO_SERVER_PAT=<pat> pytest -m integration tests/integration/test_smoke_server.py -v`
- [ ] Codex adversarial review pass over the implementation diff (before final push)
- [ ] GitHub Copilot review on the PR (mandatory before merge)

🤖 Generated with [Claude Code](https://claude.com/claude-code)
EOF
)"
```

- [ ] **Step 5: Request Copilot review**

```bash
gh pr edit --add-reviewer '@copilot'
```

The `@copilot` form is the documented `gh` CLI alias for the GitHub Copilot review bot (verified against `gh pr edit` reference). The older `github-copilot[bot]` literal is NOT accepted as a reviewer login by `gh pr edit` and will fail. Alternatively, use the GitHub UI's "Reviewers → Copilot" option.

- [ ] **Step 6: Iterate on findings until green**

Address Copilot's line-level findings + Codex's deeper findings in follow-up commits on the same branch. Push after each fix. Do NOT merge — the user (supervisor) merges once both reviewers are satisfied AND the server integration suite has been run green at least once against a real Server instance.

---



