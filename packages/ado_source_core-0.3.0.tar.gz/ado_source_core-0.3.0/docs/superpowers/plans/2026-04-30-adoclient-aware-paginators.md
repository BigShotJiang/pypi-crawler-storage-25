# ADOClient-aware paginators Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add three `ADOClient`-aware pagination helpers to `pagination.py` and refactor the 12 hand-rolled pagination loops in `AzureDevOpsCloudAdapter` to use them, preserving every retry / rate-limit / error-mapping guarantee `ADOClient.request` provides.

**Architecture:** Three single-purpose async-generator helpers (header continuation token, `$skip`/`$top`, body continuation token) sit alongside the existing httpx-based helpers. Each helper accepts an `ADOClient`, builds a per-page params dict (defensive copy of caller params + pagination-control keys), and dispatches via `client.request("GET", path, host=host, params=...)`. `ADOClient.request` already raises typed exceptions on non-2xx and applies retry on 429/503/transport, so helpers consume only 2xx responses. Adapter call sites collapse to 3-line list comprehensions or short `async for` counter loops (`sum()` itself is sync and rejects async generators).

**Tech Stack:** Python 3.11+, httpx, respx for mock testing, pytest-asyncio, mypy strict, ruff. The worktree is at `/home/marcin/projects/n8group-oss/ado-source-core/.worktrees/adoclient-paginators` on branch `refactor/adoclient-aware-paginators`. Tests use `.venv/bin/pytest -v` (worktree-local venv).

**Spec:** `docs/superpowers/specs/2026-04-30-adoclient-aware-paginators-design.md`

---

## File Structure

**Create / modify:**

- `src/ado_source_core/pagination.py` — append three new public functions; existing `paginate_continuation_token` / `paginate_skip_top` untouched.
- `src/ado_source_core/__init__.py` — add three new symbols to imports + `__all__` (alphabetical).
- `tests/unit/test_pagination.py` — append three new test classes, one per helper, plus a re-export sanity test.
- `src/ado_source_core/adapters/ado_cloud.py` — replace 12 hand-rolled pagination loops with helper calls; remove the deferred-paginator docstring on `list_projects`.

**No changes to:** `src/ado_source_core/auth.py`, `pyproject.toml`, `src/ado_source_core/client.py` (sibling agents' territory or out-of-scope).

---

## Pre-flight (already done in this worktree)

- Worktree exists at `.worktrees/adoclient-paginators` on branch `refactor/adoclient-aware-paginators`.
- Spec committed at `docs/superpowers/specs/2026-04-30-adoclient-aware-paginators-design.md`.
- `.venv/` is set up; `pytest -v` shows 187 tests passing baseline.
- `.ai-gate-skip` opt-out is in place locally so commits don't trip the global Claude pre-commit hook (which runs `hatch run test`, undefined in this project).

Verify before starting:

```bash
cd /home/marcin/projects/n8group-oss/ado-source-core/.worktrees/adoclient-paginators
git status   # expect: clean working tree on refactor/adoclient-aware-paginators
.venv/bin/pytest -q   # expect: 187 passed
```

---

## Task 1: Header continuation-token helper (`paginate_via_adoclient_continuation_token`)

**Files:**
- Modify: `src/ado_source_core/pagination.py` (append)
- Test: `tests/unit/test_pagination.py` (append a `TestADOClientContinuationToken` class)

- [ ] **Step 1: Write the failing tests**

Append to `tests/unit/test_pagination.py` (file already imports `httpx`, `pytest`, `respx`, `ado_source_core` — keep those):

```python
import asyncio

from ado_source_core import APIError, AuthenticationError, PATAuth, RateLimitError
from ado_source_core.client import ADOClient
from ado_source_core.pagination import (
    paginate_via_adoclient_continuation_token,
)


async def _instant_sleep(_seconds: float) -> None:
    return None


@pytest.fixture
def _no_sleep(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(asyncio, "sleep", _instant_sleep)


def _make_client(*, max_retries: int = 3) -> ADOClient:
    return ADOClient(
        organization="myorg",
        auth=PATAuth(token="dummy-pat"),
        max_retries=max_retries,
    )


class TestADOClientContinuationToken:
    @pytest.mark.asyncio
    async def test_pages_until_no_header(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/projects").mock(
                side_effect=[
                    httpx.Response(
                        200,
                        headers={"x-ms-continuationtoken": "page2"},
                        json={"value": [{"id": "1"}, {"id": "2"}]},
                    ),
                    httpx.Response(200, json={"value": [{"id": "3"}]}),
                ]
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_continuation_token(
                        client, "/_apis/projects"
                    )
                ]
            assert [r["id"] for r in results] == ["1", "2", "3"]

    @pytest.mark.asyncio
    async def test_forwards_continuation_token_in_query(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/projects").mock(
                side_effect=[
                    httpx.Response(
                        200,
                        headers={"x-ms-continuationtoken": "100"},
                        json={"value": [{"id": "1"}]},
                    ),
                    httpx.Response(200, json={"value": [{"id": "2"}]}),
                ]
            )
            async with _make_client() as client:
                _ = [
                    item
                    async for item in paginate_via_adoclient_continuation_token(
                        client, "/_apis/projects"
                    )
                ]
            assert "continuationToken=100" in str(mock.calls[1].request.url)

    @pytest.mark.asyncio
    async def test_single_page_no_token_terminates_immediately(
        self, _no_sleep: None
    ) -> None:
        with respx.mock(base_url=BASE) as mock:
            route = mock.get("/_apis/projects").mock(
                return_value=httpx.Response(200, json={"value": [{"id": "1"}]})
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_continuation_token(
                        client, "/_apis/projects"
                    )
                ]
            assert [r["id"] for r in results] == ["1"]
            assert route.call_count == 1

    @pytest.mark.asyncio
    async def test_empty_first_page_yields_nothing(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/projects").mock(
                return_value=httpx.Response(200, json={"value": []})
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_continuation_token(
                        client, "/_apis/projects"
                    )
                ]
            assert results == []

    @pytest.mark.asyncio
    async def test_empty_value_with_token_continues(self, _no_sleep: None) -> None:
        """Termination is token-driven, not item-driven."""
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/projects").mock(
                side_effect=[
                    httpx.Response(
                        200,
                        headers={"x-ms-continuationtoken": "cursor"},
                        json={"value": []},
                    ),
                    httpx.Response(200, json={"value": [{"id": "1"}]}),
                ]
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_continuation_token(
                        client, "/_apis/projects"
                    )
                ]
            assert [r["id"] for r in results] == ["1"]

    @pytest.mark.asyncio
    async def test_401_raises_authentication_error(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/projects").mock(
                return_value=httpx.Response(401, json={"message": "nope"})
            )
            async with _make_client() as client:
                with pytest.raises(AuthenticationError):
                    async for _ in paginate_via_adoclient_continuation_token(
                        client, "/_apis/projects"
                    ):
                        pass

    @pytest.mark.asyncio
    async def test_500_raises_api_error(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/projects").mock(
                return_value=httpx.Response(500, json={"message": "boom"})
            )
            async with _make_client() as client:
                with pytest.raises(APIError):
                    async for _ in paginate_via_adoclient_continuation_token(
                        client, "/_apis/projects"
                    ):
                        pass

    @pytest.mark.asyncio
    async def test_429_exhausted_raises_rate_limit_error(
        self, _no_sleep: None
    ) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/projects").mock(
                return_value=httpx.Response(
                    429, headers={"Retry-After": "0"}, json={"message": "slow down"}
                )
            )
            async with _make_client(max_retries=1) as client:
                with pytest.raises(RateLimitError):
                    async for _ in paginate_via_adoclient_continuation_token(
                        client, "/_apis/projects"
                    ):
                        pass

    @pytest.mark.asyncio
    async def test_mid_iteration_429_retries_with_token(
        self, _no_sleep: None
    ) -> None:
        """Page 2 returns 429 then succeeds; helper yields across the retry."""
        with respx.mock(base_url=BASE) as mock:
            route = mock.get("/_apis/projects").mock(
                side_effect=[
                    httpx.Response(
                        200,
                        headers={"x-ms-continuationtoken": "p2"},
                        json={"value": [{"id": "1"}]},
                    ),
                    httpx.Response(429, headers={"Retry-After": "0"}, json={}),
                    httpx.Response(200, json={"value": [{"id": "2"}]}),
                ]
            )
            async with _make_client(max_retries=3) as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_continuation_token(
                        client, "/_apis/projects"
                    )
                ]
            assert [r["id"] for r in results] == ["1", "2"]
            assert route.call_count == 3
            # continuationToken must be present on BOTH page-2 attempts
            assert "continuationToken=p2" in str(mock.calls[1].request.url)
            assert "continuationToken=p2" in str(mock.calls[2].request.url)

    @pytest.mark.asyncio
    async def test_mid_iteration_transport_error_retries(
        self, _no_sleep: None
    ) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/projects").mock(
                side_effect=[
                    httpx.Response(
                        200,
                        headers={"x-ms-continuationtoken": "p2"},
                        json={"value": [{"id": "1"}]},
                    ),
                    httpx.ConnectError("boom"),
                    httpx.Response(200, json={"value": [{"id": "2"}]}),
                ]
            )
            async with _make_client(max_retries=3) as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_continuation_token(
                        client, "/_apis/projects"
                    )
                ]
            assert [r["id"] for r in results] == ["1", "2"]

    @pytest.mark.asyncio
    async def test_transport_error_exhausted_raises_api_error(
        self, _no_sleep: None
    ) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/projects").mock(side_effect=httpx.ConnectError("boom"))
            async with _make_client(max_retries=2) as client:
                with pytest.raises(APIError):
                    async for _ in paginate_via_adoclient_continuation_token(
                        client, "/_apis/projects"
                    ):
                        pass

    @pytest.mark.asyncio
    async def test_api_version_overlay_survives(self, _no_sleep: None) -> None:
        """Caller-supplied api-version (e.g. for Graph API) must win."""
        with respx.mock(base_url=BASE) as mock:
            route = mock.get("/_apis/projects").mock(
                return_value=httpx.Response(200, json={"value": []})
            )
            async with _make_client() as client:
                _ = [
                    item
                    async for item in paginate_via_adoclient_continuation_token(
                        client,
                        "/_apis/projects",
                        params={"api-version": "7.1-preview.1"},
                    )
                ]
            assert "api-version=7.1-preview.1" in str(route.calls[0].request.url)
            assert "api-version=7.1&" not in str(route.calls[0].request.url)

    @pytest.mark.asyncio
    async def test_host_param_routes_correctly(self, _no_sleep: None) -> None:
        with respx.mock(base_url=VSRM) as mock:
            route = mock.get("/_apis/release/definitions").mock(
                return_value=httpx.Response(200, json={"value": [{"id": 1}]})
            )
            async with _make_client() as client:
                _ = [
                    item
                    async for item in paginate_via_adoclient_continuation_token(
                        client, "/_apis/release/definitions", host="vsrm"
                    )
                ]
            assert route.call_count == 1
```

Add `VSRM = "https://vsrm.dev.azure.com/myorg"` near the existing `BASE = "https://dev.azure.com/myorg"` constant at the top of the file.

- [ ] **Step 2: Run the tests; expect ImportError or NameError**

```bash
.venv/bin/pytest tests/unit/test_pagination.py::TestADOClientContinuationToken -v
```

Expected: collection error or `ImportError: cannot import name 'paginate_via_adoclient_continuation_token'`.

- [ ] **Step 3: Implement the helper**

Append to `src/ado_source_core/pagination.py` (after the existing two functions, before any final blank line):

```python
async def paginate_via_adoclient_continuation_token(
    client: ADOClient,
    path: str,
    *,
    host: HostName = "dev",
    params: Mapping[str, Any] | None = None,
) -> AsyncIterator[dict[str, Any]]:
    """Yield items from response['value'] across pages using the
    'x-ms-continuationtoken' response header, dispatched via
    ``ADOClient.request`` so retry / rate-limit / error-mapping is
    preserved.

    Used by the majority of paginated ADO endpoints (Projects, Refs,
    Build/Release definitions, Variable groups, Environments, Test
    plans, Branch policies, Graph users)."""
    current_params: dict[str, Any] = dict(params or {})
    while True:
        response = await client.request("GET", path, host=host, params=current_params)
        body = response.json()
        for item in body.get("value", []):
            yield item

        token = response.headers.get("x-ms-continuationtoken")
        if not token:
            return
        current_params["continuationToken"] = token
```

Add the `ADOClient` and `HostName` imports at the top of `pagination.py`. Use a `TYPE_CHECKING` block to avoid the circular import (since `pagination` is imported from `__init__` before `client`):

```python
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ado_source_core.client import ADOClient, HostName
```

(`HostName` is already a `str` alias in `client.py`, so this is purely a type hint.)

- [ ] **Step 4: Run tests; expect pass**

```bash
.venv/bin/pytest tests/unit/test_pagination.py::TestADOClientContinuationToken -v
```

Expected: 12 passed.

- [ ] **Step 5: Commit (do NOT push yet — push after Task 4)**

```bash
git add tests/unit/test_pagination.py src/ado_source_core/pagination.py
git commit -m "$(cat <<'EOF'
feat(pagination): add paginate_via_adoclient_continuation_token

Header-token continuation paginator that dispatches via
ADOClient.request, preserving retry / rate-limit / error-mapping. Will
be consumed by 9 adapter loops in a follow-up commit.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 2: `$skip`/`$top` helper (`paginate_via_adoclient_skip_top`)

**Files:**
- Modify: `src/ado_source_core/pagination.py` (append)
- Test: `tests/unit/test_pagination.py` (append a `TestADOClientSkipTop` class)

- [ ] **Step 1: Write the failing tests**

Append to `tests/unit/test_pagination.py`. Update the import line at the top of the file to include the new symbol:

```python
from ado_source_core.pagination import (
    paginate_via_adoclient_continuation_token,
    paginate_via_adoclient_skip_top,
)
```

Then append:

```python
class TestADOClientSkipTop:
    PATH = "/_apis/git/repositories/abc/pullrequests"

    @pytest.mark.asyncio
    async def test_increments_skip_until_short_page(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get(self.PATH).mock(
                side_effect=[
                    httpx.Response(200, json={"value": [{"id": 1}, {"id": 2}]}),
                    httpx.Response(200, json={"value": [{"id": 3}]}),
                ]
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_skip_top(
                        client, self.PATH, page_size=2
                    )
                ]
            assert [r["id"] for r in results] == [1, 2, 3]

    @pytest.mark.asyncio
    async def test_skip_and_top_increment_per_page(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get(self.PATH).mock(
                side_effect=[
                    httpx.Response(200, json={"value": [{"id": 1}, {"id": 2}]}),
                    httpx.Response(200, json={"value": [{"id": 3}, {"id": 4}]}),
                    httpx.Response(200, json={"value": []}),
                ]
            )
            async with _make_client() as client:
                _ = [
                    item
                    async for item in paginate_via_adoclient_skip_top(
                        client, self.PATH, page_size=2
                    )
                ]
            urls = [str(call.request.url) for call in mock.calls]
            assert "%24skip=0" in urls[0] and "%24top=2" in urls[0]
            assert "%24skip=2" in urls[1] and "%24top=2" in urls[1]
            assert "%24skip=4" in urls[2] and "%24top=2" in urls[2]

    @pytest.mark.asyncio
    async def test_short_first_page_terminates_without_extra_request(
        self, _no_sleep: None
    ) -> None:
        with respx.mock(base_url=BASE) as mock:
            route = mock.get(self.PATH).mock(
                return_value=httpx.Response(200, json={"value": [{"id": 1}]})
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_skip_top(
                        client, self.PATH, page_size=10
                    )
                ]
            assert [r["id"] for r in results] == [1]
            assert route.call_count == 1

    @pytest.mark.asyncio
    async def test_empty_first_page_yields_nothing(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get(self.PATH).mock(
                return_value=httpx.Response(200, json={"value": []})
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_skip_top(
                        client, self.PATH
                    )
                ]
            assert results == []

    @pytest.mark.asyncio
    async def test_500_raises_api_error(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get(self.PATH).mock(
                return_value=httpx.Response(500, json={"message": "boom"})
            )
            async with _make_client() as client:
                with pytest.raises(APIError):
                    async for _ in paginate_via_adoclient_skip_top(
                        client, self.PATH
                    ):
                        pass

    @pytest.mark.asyncio
    async def test_caller_params_preserved_alongside_skip_top(
        self, _no_sleep: None
    ) -> None:
        with respx.mock(base_url=BASE) as mock:
            route = mock.get(self.PATH).mock(
                return_value=httpx.Response(200, json={"value": []})
            )
            async with _make_client() as client:
                _ = [
                    item
                    async for item in paginate_via_adoclient_skip_top(
                        client,
                        self.PATH,
                        params={"searchCriteria.status": "all"},
                        page_size=50,
                    )
                ]
            url = str(route.calls[0].request.url)
            assert "searchCriteria.status=all" in url
            assert "%24skip=0" in url
            assert "%24top=50" in url
```

- [ ] **Step 2: Run tests; expect failure**

```bash
.venv/bin/pytest tests/unit/test_pagination.py::TestADOClientSkipTop -v
```

Expected: ImportError on `paginate_via_adoclient_skip_top`.

- [ ] **Step 3: Implement the helper**

Append to `src/ado_source_core/pagination.py`:

```python
async def paginate_via_adoclient_skip_top(
    client: ADOClient,
    path: str,
    *,
    host: HostName = "dev",
    params: Mapping[str, Any] | None = None,
    page_size: int = 100,
) -> AsyncIterator[dict[str, Any]]:
    """Yield items from response['value'] across pages using $skip /
    $top query parameters, dispatched via ``ADOClient.request`` so
    retry / rate-limit / error-mapping is preserved.

    Used by Pull requests and TFVC changesets — endpoints that honor
    the requested $top up to 100. If a future endpoint silently caps
    below page_size, prefer a continuation-token variant; this helper
    treats a short page as "no more pages"."""
    skip = 0
    while True:
        page_params: dict[str, Any] = {
            **(params or {}),
            "$skip": skip,
            "$top": page_size,
        }
        response = await client.request("GET", path, host=host, params=page_params)
        body = response.json()
        items = body.get("value", [])
        if not items:
            return
        for item in items:
            yield item
        if len(items) < page_size:
            return
        skip += page_size
```

- [ ] **Step 4: Run tests; expect pass**

```bash
.venv/bin/pytest tests/unit/test_pagination.py::TestADOClientSkipTop -v
```

Expected: 6 passed.

- [ ] **Step 5: Commit**

```bash
git add tests/unit/test_pagination.py src/ado_source_core/pagination.py
git commit -m "$(cat <<'EOF'
feat(pagination): add paginate_via_adoclient_skip_top

$skip/$top paginator that dispatches via ADOClient.request, preserving
retry / rate-limit / error-mapping. Will be consumed by
count_pull_requests and the TFVC changeset count loop.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 3: Body continuation-token helper (`paginate_via_adoclient_body_continuation_token`)

**Files:**
- Modify: `src/ado_source_core/pagination.py` (append)
- Test: `tests/unit/test_pagination.py` (append a `TestADOClientBodyContinuationToken` class)

- [ ] **Step 1: Write the failing tests**

Update the import in `tests/unit/test_pagination.py`:

```python
from ado_source_core.pagination import (
    paginate_via_adoclient_body_continuation_token,
    paginate_via_adoclient_continuation_token,
    paginate_via_adoclient_skip_top,
)
```

Append `VSAEX = "https://vsaex.dev.azure.com/myorg"` near the other base-URL constants at the top of the file.

Append:

```python
class TestADOClientBodyContinuationToken:
    PATH = "/_apis/userentitlements"

    @pytest.mark.asyncio
    async def test_pages_until_no_body_token(self, _no_sleep: None) -> None:
        with respx.mock(base_url=VSAEX) as mock:
            mock.get(self.PATH).mock(
                side_effect=[
                    httpx.Response(
                        200,
                        json={
                            "items": [{"id": "u1"}, {"id": "u2"}],
                            "continuationToken": "cursor",
                        },
                    ),
                    httpx.Response(
                        200,
                        json={"items": [{"id": "u3"}], "continuationToken": ""},
                    ),
                ]
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_body_continuation_token(
                        client, self.PATH, host="vsaex"
                    )
                ]
            assert [r["id"] for r in results] == ["u1", "u2", "u3"]

    @pytest.mark.asyncio
    async def test_body_token_forwarded_in_query(self, _no_sleep: None) -> None:
        with respx.mock(base_url=VSAEX) as mock:
            mock.get(self.PATH).mock(
                side_effect=[
                    httpx.Response(
                        200,
                        json={"items": [{"id": "u1"}], "continuationToken": "abc123"},
                    ),
                    httpx.Response(200, json={"items": [], "continuationToken": ""}),
                ]
            )
            async with _make_client() as client:
                _ = [
                    item
                    async for item in paginate_via_adoclient_body_continuation_token(
                        client, self.PATH, host="vsaex"
                    )
                ]
            assert "continuationToken=abc123" in str(mock.calls[1].request.url)

    @pytest.mark.asyncio
    async def test_terminates_when_token_missing(self, _no_sleep: None) -> None:
        with respx.mock(base_url=VSAEX) as mock:
            route = mock.get(self.PATH).mock(
                return_value=httpx.Response(200, json={"items": [{"id": "u1"}]})
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_body_continuation_token(
                        client, self.PATH, host="vsaex"
                    )
                ]
            assert [r["id"] for r in results] == ["u1"]
            assert route.call_count == 1

    @pytest.mark.asyncio
    async def test_terminates_when_token_none(self, _no_sleep: None) -> None:
        with respx.mock(base_url=VSAEX) as mock:
            mock.get(self.PATH).mock(
                return_value=httpx.Response(
                    200, json={"items": [{"id": "u1"}], "continuationToken": None}
                )
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_body_continuation_token(
                        client, self.PATH, host="vsaex"
                    )
                ]
            assert [r["id"] for r in results] == ["u1"]

    @pytest.mark.asyncio
    async def test_empty_items_with_token_continues(self, _no_sleep: None) -> None:
        with respx.mock(base_url=VSAEX) as mock:
            mock.get(self.PATH).mock(
                side_effect=[
                    httpx.Response(
                        200, json={"items": [], "continuationToken": "cursor"}
                    ),
                    httpx.Response(
                        200, json={"items": [{"id": "u1"}], "continuationToken": ""}
                    ),
                ]
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_body_continuation_token(
                        client, self.PATH, host="vsaex"
                    )
                ]
            assert [r["id"] for r in results] == ["u1"]

    @pytest.mark.asyncio
    async def test_items_key_string_value(self, _no_sleep: None) -> None:
        """`items_key='value'` works for endpoints that key body-token data under value."""
        with respx.mock(base_url=VSAEX) as mock:
            mock.get(self.PATH).mock(
                return_value=httpx.Response(
                    200, json={"value": [{"id": "u1"}], "continuationToken": ""}
                )
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_body_continuation_token(
                        client, self.PATH, host="vsaex", items_key="value"
                    )
                ]
            assert [r["id"] for r in results] == ["u1"]

    @pytest.mark.asyncio
    async def test_items_key_sequence_walks_fallback_chain(
        self, _no_sleep: None
    ) -> None:
        """Older response shape: `members` instead of `items`."""
        with respx.mock(base_url=VSAEX) as mock:
            mock.get(self.PATH).mock(
                return_value=httpx.Response(
                    200,
                    json={"members": [{"id": "u1"}], "continuationToken": ""},
                )
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_body_continuation_token(
                        client,
                        self.PATH,
                        host="vsaex",
                        items_key=("items", "members"),
                    )
                ]
            assert [r["id"] for r in results] == ["u1"]

    @pytest.mark.asyncio
    async def test_items_key_sequence_prefers_first_present_key(
        self, _no_sleep: None
    ) -> None:
        with respx.mock(base_url=VSAEX) as mock:
            mock.get(self.PATH).mock(
                return_value=httpx.Response(
                    200,
                    json={
                        "items": [{"id": "from-items"}],
                        "members": [{"id": "from-members"}],
                        "continuationToken": "",
                    },
                )
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_body_continuation_token(
                        client,
                        self.PATH,
                        host="vsaex",
                        items_key=("items", "members"),
                    )
                ]
            assert [r["id"] for r in results] == ["from-items"]

    @pytest.mark.asyncio
    async def test_header_token_is_not_consulted(self, _no_sleep: None) -> None:
        """The body helper ignores `x-ms-continuationtoken`; only body['continuationToken'] drives it."""
        with respx.mock(base_url=VSAEX) as mock:
            route = mock.get(self.PATH).mock(
                return_value=httpx.Response(
                    200,
                    headers={"x-ms-continuationtoken": "would-loop-forever"},
                    json={"items": [{"id": "u1"}]},
                )
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_body_continuation_token(
                        client, self.PATH, host="vsaex"
                    )
                ]
            assert [r["id"] for r in results] == ["u1"]
            assert route.call_count == 1

    @pytest.mark.asyncio
    async def test_401_raises_authentication_error(self, _no_sleep: None) -> None:
        with respx.mock(base_url=VSAEX) as mock:
            mock.get(self.PATH).mock(
                return_value=httpx.Response(401, json={"message": "nope"})
            )
            async with _make_client() as client:
                with pytest.raises(AuthenticationError):
                    async for _ in paginate_via_adoclient_body_continuation_token(
                        client, self.PATH, host="vsaex"
                    ):
                        pass
```

- [ ] **Step 2: Run tests; expect failure**

```bash
.venv/bin/pytest tests/unit/test_pagination.py::TestADOClientBodyContinuationToken -v
```

Expected: ImportError on `paginate_via_adoclient_body_continuation_token`.

- [ ] **Step 3: Implement the helper**

Append to `src/ado_source_core/pagination.py`. Add `Sequence` to the existing collections import at the top of the file:

```python
from collections.abc import AsyncIterator, Mapping, Sequence
```

Then append the helper:

```python
async def paginate_via_adoclient_body_continuation_token(
    client: ADOClient,
    path: str,
    *,
    host: HostName = "dev",
    params: Mapping[str, Any] | None = None,
    items_key: str | Sequence[str] = "items",
) -> AsyncIterator[dict[str, Any]]:
    """Yield items from response[items_key] across pages using
    response['continuationToken'] in the response BODY (not the
    header), dispatched via ``ADOClient.request``.

    Specific to the Member Entitlements API
    (`/_apis/userentitlements`). Items live under 'items', not
    'value', and the continuation token comes from the body.

    `items_key` accepts a single string for the common case and a
    sequence of strings to express a fallback chain — the helper
    returns items from the first key present in the response. Member
    Entitlements is called with `items_key=("items", "members")` to
    preserve the donor's tolerance for an older `members` response
    shape."""
    keys: tuple[str, ...] = (items_key,) if isinstance(items_key, str) else tuple(items_key)
    current_params: dict[str, Any] = dict(params or {})
    while True:
        response = await client.request("GET", path, host=host, params=current_params)
        body = response.json()

        items: list[dict[str, Any]] = []
        for key in keys:
            if key in body:
                items = body[key] or []
                break
        for item in items:
            yield item

        token = body.get("continuationToken")
        if not token:
            return
        current_params["continuationToken"] = token
```

- [ ] **Step 4: Run tests; expect pass**

```bash
.venv/bin/pytest tests/unit/test_pagination.py::TestADOClientBodyContinuationToken -v
```

Expected: 10 passed.

- [ ] **Step 5: Commit**

```bash
git add tests/unit/test_pagination.py src/ado_source_core/pagination.py
git commit -m "$(cat <<'EOF'
feat(pagination): add paginate_via_adoclient_body_continuation_token

Body-token paginator for the Member Entitlements API, where the token
lives in the response body (not the x-ms-continuationtoken header) and
items live under 'items' rather than 'value'. items_key accepts a
sequence form ("items", "members") to preserve the donor's tolerance
for the older 'members' shape.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 4: Re-export new helpers from `__init__.py` and finalize the helper-add commit

**Files:**
- Modify: `src/ado_source_core/__init__.py`
- Test: `tests/unit/test_pagination.py` (extend `TestReExports`)

- [ ] **Step 1: Extend the existing re-export test**

Replace the existing `TestReExports` class at the bottom of `tests/unit/test_pagination.py` with:

```python
class TestReExports:
    def test_paginators_re_exported_from_package_root(self) -> None:
        from ado_source_core.pagination import (
            paginate_continuation_token,
            paginate_skip_top,
            paginate_via_adoclient_body_continuation_token,
            paginate_via_adoclient_continuation_token,
            paginate_via_adoclient_skip_top,
        )

        assert ado_source_core.paginate_continuation_token is paginate_continuation_token
        assert ado_source_core.paginate_skip_top is paginate_skip_top
        assert (
            ado_source_core.paginate_via_adoclient_body_continuation_token
            is paginate_via_adoclient_body_continuation_token
        )
        assert (
            ado_source_core.paginate_via_adoclient_continuation_token
            is paginate_via_adoclient_continuation_token
        )
        assert (
            ado_source_core.paginate_via_adoclient_skip_top
            is paginate_via_adoclient_skip_top
        )
```

- [ ] **Step 2: Run; expect failure**

```bash
.venv/bin/pytest tests/unit/test_pagination.py::TestReExports -v
```

Expected: AttributeError on `paginate_via_adoclient_*`.

- [ ] **Step 3: Update `__init__.py`**

Modify `src/ado_source_core/__init__.py`. Replace the pagination import block:

```python
from ado_source_core.pagination import paginate_continuation_token, paginate_skip_top
```

with:

```python
from ado_source_core.pagination import (
    paginate_continuation_token,
    paginate_skip_top,
    paginate_via_adoclient_body_continuation_token,
    paginate_via_adoclient_continuation_token,
    paginate_via_adoclient_skip_top,
)
```

In `__all__`, insert the three new symbols in alphabetical order. They sort under `p` between `paginate_skip_top` and any later entry. The list is already alphabetical; the relevant region currently looks like:

```python
    "paginate_continuation_token",
    "paginate_skip_top",
]
```

Replace with:

```python
    "paginate_continuation_token",
    "paginate_skip_top",
    "paginate_via_adoclient_body_continuation_token",
    "paginate_via_adoclient_continuation_token",
    "paginate_via_adoclient_skip_top",
]
```

- [ ] **Step 4: Run all pagination + smoke tests**

```bash
.venv/bin/pytest tests/unit/test_pagination.py tests/unit/test_smoke.py -v
```

Expected: all green; pagination test count is now ~38 (5 existing classes/methods baseline + 12 + 6 + 10 + 1 expanded re-export, minus original re-export = roughly 38 total in this file).

- [ ] **Step 5: Run the full unit suite to confirm no regression**

```bash
.venv/bin/pytest -q
```

Expected: ~187 + new tests, all passing, 0 failures.

- [ ] **Step 6: Lint, format, mypy gate**

```bash
.venv/bin/ruff check src tests
.venv/bin/ruff format --check src tests
.venv/bin/mypy src
```

Expected: clean. If ruff format complains, run `.venv/bin/ruff format src tests` and re-stage.

- [ ] **Step 7: Commit**

```bash
git add src/ado_source_core/__init__.py tests/unit/test_pagination.py
git commit -m "$(cat <<'EOF'
feat(pagination): re-export ADOClient-aware paginators from package root

Adds paginate_via_adoclient_continuation_token /
paginate_via_adoclient_skip_top /
paginate_via_adoclient_body_continuation_token to ado_source_core's
__all__ so callers can import from the package root.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

- [ ] **Step 8: Push the helper-add commits**

```bash
git push
```

---

## Task 5: Refactor 7 simple header-token list endpoints

These are the seven adapter methods whose loop is "header continuation, simple `$top=100` params, list of dicts": `list_projects`, `list_build_definitions`, `list_release_definitions` (host=`vsrm`), `list_variable_groups`, `list_environments`, `list_test_plans`, `list_branch_policies`.

**Files:**
- Modify: `src/ado_source_core/adapters/ado_cloud.py`

- [ ] **Step 1: Confirm the existing tests pass before the refactor**

```bash
.venv/bin/pytest tests/unit/test_adapters_ado_cloud.py -v -k "list_projects or list_build_def or list_release_def or list_variable_groups or list_environments or list_test_plans or list_branch_policies"
```

Expected: all pass on the unchanged adapter.

- [ ] **Step 2: Add the helper import to `ado_cloud.py`**

In `src/ado_source_core/adapters/ado_cloud.py`, near the top of the imports (right after the `from ado_source_core.models.user import User` line, or grouped wherever pagination naturally belongs), add:

```python
from ado_source_core.pagination import (
    paginate_via_adoclient_body_continuation_token,
    paginate_via_adoclient_continuation_token,
    paginate_via_adoclient_skip_top,
)
```

(All three are imported now; later tasks will reference the latter two.)

- [ ] **Step 3: Refactor `list_projects`**

Replace the existing `list_projects` method (currently lines ~107-139) entirely with:

```python
    async def list_projects(
        self,
        *,
        state_filter: str = "wellFormed",
    ) -> list[dict[str, Any]]:
        """List all projects. Pagination: integer continuation token."""
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client,
                "/_apis/projects",
                params={"stateFilter": state_filter, "$top": "100"},
            )
        ]
```

This removes the deferred-paginator docstring; the constraint it described is now satisfied.

- [ ] **Step 4: Refactor `list_build_definitions`**

Replace its body with:

```python
    async def list_build_definitions(self, project: str) -> list[dict[str, Any]]:
        """List build definitions (YAML + Classic).

        Distinguish type by ``process.type``: 1=designer/classic, 2=YAML.
        """
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client,
                f"/{project}/_apis/build/definitions",
                params={"$top": "100"},
            )
        ]
```

- [ ] **Step 5: Refactor `list_release_definitions`**

```python
    async def list_release_definitions(self, project: str) -> list[dict[str, Any]]:
        """List classic release definitions.

        Routed to ``vsrm.dev.azure.com`` via ``host="vsrm"``.
        """
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client,
                f"/{project}/_apis/release/definitions",
                host="vsrm",
                params={"$top": "100"},
            )
        ]
```

- [ ] **Step 6: Refactor `list_variable_groups`**

```python
    async def list_variable_groups(self, project: str) -> list[dict[str, Any]]:
        """List variable groups."""
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client,
                f"/{project}/_apis/distributedtask/variablegroups",
                params={"$top": "100"},
            )
        ]
```

- [ ] **Step 7: Refactor `list_environments`**

```python
    async def list_environments(self, project: str) -> list[dict[str, Any]]:
        """List environments."""
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client,
                f"/{project}/_apis/distributedtask/environments",
                params={"$top": "100"},
            )
        ]
```

- [ ] **Step 8: Refactor `list_test_plans`**

```python
    async def list_test_plans(self, project: str) -> list[dict[str, Any]]:
        """List test plans."""
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client,
                f"/{project}/_apis/testplan/plans",
                params={"$top": "100"},
            )
        ]
```

- [ ] **Step 9: Refactor `list_branch_policies`**

```python
    async def list_branch_policies(self, project: str) -> list[dict[str, Any]]:
        """List branch policies (endpoint: ``_apis/git/policy/configurations``)."""
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client,
                f"/{project}/_apis/git/policy/configurations",
                params={"$top": "100"},
            )
        ]
```

- [ ] **Step 10: Re-run the targeted tests**

```bash
.venv/bin/pytest tests/unit/test_adapters_ado_cloud.py -v -k "list_projects or list_build_def or list_release_def or list_variable_groups or list_environments or list_test_plans or list_branch_policies"
```

Expected: all green. Existing respx mocks at the transport layer still satisfy the new helper, since the URL / params / response shapes are unchanged.

---

## Task 6: Refactor `count_branches`

**Files:**
- Modify: `src/ado_source_core/adapters/ado_cloud.py`

- [ ] **Step 1: Confirm existing test passes**

```bash
.venv/bin/pytest tests/unit/test_adapters_ado_cloud.py -v -k "count_branches"
```

- [ ] **Step 2: Replace `count_branches`**

```python
    async def count_branches(self, repo_id: str) -> int:
        """Count branches. ``repo_id`` is the composite ``project/repo_uuid``."""
        project, repo = repo_id.split("/", 1)
        count = 0
        async for _ in paginate_via_adoclient_continuation_token(
            self._client,
            f"/{project}/_apis/git/repositories/{repo}/refs",
            params={"filter": "heads/", "$top": "100"},
        ):
            count += 1
        return count
```

- [ ] **Step 3: Re-run test**

```bash
.venv/bin/pytest tests/unit/test_adapters_ado_cloud.py -v -k "count_branches"
```

Expected: green.

---

## Task 7: Refactor `list_users`

`list_users` has the api-version overlay (`7.1-preview.1`), routes to `vssps`, and constructs `User` Pydantic models from the yielded raw dicts. The helper still yields raw dicts; the adapter does the User-construction.

**Files:**
- Modify: `src/ado_source_core/adapters/ado_cloud.py`

- [ ] **Step 1: Confirm existing tests pass**

```bash
.venv/bin/pytest tests/unit/test_adapters_ado_cloud.py -v -k "list_users"
```

- [ ] **Step 2: Replace `list_users`**

```python
    async def list_users(
        self,
        *,
        workspace: str | None = None,
        page: int = 1,
        page_size: int = 100,
    ) -> list[User]:
        """List users via the VSSPS Graph API (``host="vssps"``).

        Endpoint: ``GET /_apis/graph/users?api-version=7.1-preview.1``.

        The Graph API requires the ``-preview.1`` suffix on the
        api-version even under the 7.1 contract; passing plain ``7.1``
        returns ``HTTP 400 VssInvalidPreviewVersionException``. Override
        the ``ADOClient`` default by setting it explicitly in ``params``.

        ``workspace`` / ``page`` / ``page_size`` arguments exist on the
        ``SourceAdapter`` contract but ADO's Graph API doesn't honor
        client-side paging knobs.
        """
        return [
            User(
                id=entry.get("descriptor", entry.get("originId", "")),
                username=entry.get("principalName", ""),
                display_name=entry.get("displayName"),
                email=entry.get("mailAddress"),
                source="azure-devops",
            )
            async for entry in paginate_via_adoclient_continuation_token(
                self._client,
                "/_apis/graph/users",
                host="vssps",
                params={"api-version": "7.1-preview.1"},
            )
        ]
```

- [ ] **Step 3: Re-run tests**

```bash
.venv/bin/pytest tests/unit/test_adapters_ado_cloud.py -v -k "list_users"
```

Expected: green. The api-version overlay test (added in PR #12) must still pass.

---

## Task 8: Refactor `count_pull_requests`

**Files:**
- Modify: `src/ado_source_core/adapters/ado_cloud.py`

- [ ] **Step 1: Confirm existing test passes**

```bash
.venv/bin/pytest tests/unit/test_adapters_ado_cloud.py -v -k "count_pull_requests"
```

- [ ] **Step 2: Replace `count_pull_requests`**

```python
    async def count_pull_requests(
        self,
        repo_id: str,
        *,
        state: str | None = None,
    ) -> int:
        """Count pull requests. Pagination: ``$skip``/``$top``."""
        project, repo = repo_id.split("/", 1)
        count = 0
        async for _ in paginate_via_adoclient_skip_top(
            self._client,
            f"/{project}/_apis/git/repositories/{repo}/pullrequests",
            params={"searchCriteria.status": state or "all"},
            page_size=100,
        ):
            count += 1
        return count
```

- [ ] **Step 3: Re-run test**

```bash
.venv/bin/pytest tests/unit/test_adapters_ado_cloud.py -v -k "count_pull_requests"
```

Expected: green.

---

## Task 9: Refactor the `list_tfvc_changesets` count loop

The outer "fetch latest changeset" call stays a single `request`. Only the inner count loop (currently a manual `$skip`/`$top` while-loop) is replaced.

**Files:**
- Modify: `src/ado_source_core/adapters/ado_cloud.py`

- [ ] **Step 1: Confirm existing tests pass**

```bash
.venv/bin/pytest tests/unit/test_adapters_ado_cloud.py -v -k "tfvc"
```

- [ ] **Step 2: Replace the inner count loop in `list_tfvc_changesets`**

The method currently has two parts:
1. A single `await self._client.request(...)` to fetch the latest changeset (kept as-is).
2. A `while True:` loop that pages through `$skip`/`$top` to total all changesets.

Replace only the inner loop. The full method becomes:

```python
    async def list_tfvc_changesets(self, project: str) -> dict[str, Any]:
        """Get TFVC changeset summary. Counts via ``$skip``/``$top`` pagination.

        Returns ``{"total_changesets": int, "latest_changeset_date": str | None}``.
        Returns the empty shape when the project has no changesets (HTTP
        404). Drift from the donor (which swallowed every ``APIError``):
        auth / rate-limit / 5xx errors now propagate so a scan doesn't
        silently turn into "no TFVC" false negatives.
        """
        try:
            response = await self._client.request(
                "GET",
                f"/{project}/_apis/tfvc/changesets",
                params={"$top": "1", "$orderby": "id desc"},
            )
            data = response.json()
            changesets = data.get("value", [])

            if not changesets:
                return {"total_changesets": 0, "latest_changeset_date": None}

            latest = changesets[0]

            total = 0
            async for _ in paginate_via_adoclient_skip_top(
                self._client,
                f"/{project}/_apis/tfvc/changesets",
                page_size=100,
            ):
                total += 1

            return {
                "total_changesets": total,
                "latest_changeset_date": latest.get("createdDate"),
            }
        except APIError as exc:
            if exc.status_code == HTTPStatus.NOT_FOUND:
                return {"total_changesets": 0, "latest_changeset_date": None}
            raise
```

- [ ] **Step 3: Re-run tests**

```bash
.venv/bin/pytest tests/unit/test_adapters_ado_cloud.py -v -k "tfvc"
```

Expected: green.

---

## Task 10: Refactor `list_user_entitlements`

Body-token paginator with `items_key=("items", "members")` to preserve the legacy fallback shape.

**Files:**
- Modify: `src/ado_source_core/adapters/ado_cloud.py`

- [ ] **Step 1: Confirm existing tests pass — including the members fallback**

```bash
.venv/bin/pytest tests/unit/test_adapters_ado_cloud.py -v -k "list_user_entitlements"
```

Expected: includes `test_list_user_entitlements_falls_back_to_members_field`.

- [ ] **Step 2: Replace `list_user_entitlements`**

```python
    async def list_user_entitlements(self) -> list[dict[str, Any]]:
        """List all user entitlements via ``vsaex.dev.azure.com`` (``host="vsaex"``).

        Endpoint: ``GET /_apis/userentitlements?api-version=7.1-preview.4``.
        Pagination: ``continuationToken`` in **response body**, passed as
        query param. Response shape:
        ``{"items": [...], "continuationToken": "...", "totalCount": N}``.
        Older deployments key items under ``members`` instead of
        ``items``; the helper's ``items_key`` sequence preserves that
        fallback.
        """
        return [
            item
            async for item in paginate_via_adoclient_body_continuation_token(
                self._client,
                "/_apis/userentitlements",
                host="vsaex",
                params={"$top": "10000", "api-version": "7.1-preview.4"},
                items_key=("items", "members"),
            )
        ]
```

- [ ] **Step 3: Re-run tests**

```bash
.venv/bin/pytest tests/unit/test_adapters_ado_cloud.py -v -k "list_user_entitlements"
```

Expected: green, including the `members` fallback test.

---

## Task 11: Full local verification gate

**Files:**
- (No code changes — verification only.)

- [ ] **Step 1: Full unit suite**

```bash
.venv/bin/pytest -v
```

Expected: 187 baseline + new helper tests, all passing.

- [ ] **Step 2: Lint**

```bash
.venv/bin/ruff check src tests
```

Expected: clean. Fix issues in place if any (no auto-formatting changes here — those go through ruff format).

- [ ] **Step 3: Format check**

```bash
.venv/bin/ruff format --check src tests
```

Expected: clean. If files need formatting, run `.venv/bin/ruff format src tests` and re-stage.

- [ ] **Step 4: Strict mypy**

```bash
.venv/bin/mypy src
```

Expected: clean. The `Sequence` import addition + `TYPE_CHECKING` import for `ADOClient` should both type-check.

- [ ] **Step 5: Integration smoke against the real ADO org**

```bash
ADO_ORG=n8cloud-gp ADO_PAT="$(op read 'op://Private/ADO n8cloud-gp/PAT Full Access')" \
  .venv/bin/pytest tests/integration -m integration -v
```

Expected: zero regressions vs. the smoke suite landed in PR #12. (Do not echo the PAT in user-facing output.)

- [ ] **Step 6: Commit the adapter refactor**

```bash
git add src/ado_source_core/adapters/ado_cloud.py
git commit -m "$(cat <<'EOF'
refactor(ado-cloud): collapse 12 hand-rolled pagination loops

Replaces hand-rolled while-loops in 12 adapter methods with calls to
the three new ADOClient-aware paginator helpers. Each refactored
method is now 1-4 lines of orchestration around the helper:

- 9 header-continuation-token endpoints: list_projects, count_branches,
  list_build_definitions, list_release_definitions, list_variable_groups,
  list_environments, list_test_plans, list_branch_policies, list_users
  (with api-version=7.1-preview.1 overlay and User construction).
- 2 $skip/$top endpoints: count_pull_requests, list_tfvc_changesets
  (count loop only — outer "fetch latest" stays as a single request).
- 1 body-continuation-token endpoint: list_user_entitlements with
  items_key=("items", "members") preserving the legacy response shape.

Resolves the deferred Copilot finding on PR #9: every page request now
flows through ADOClient.request, so retry / Retry-After honoring /
typed-exception mapping is preserved across iteration.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

- [ ] **Step 7: Push**

```bash
git push
```

---

## Task 12: Codex pass on the code, then PR

**Files:**
- (No code changes — review + PR creation.)

- [ ] **Step 1: Dispatch Codex adversarial review on the diff**

Use the `codex:codex-rescue` agent. Brief it with:

- The two head commits on the branch (`git log refactor/adoclient-aware-paginators ^main --oneline` should show 5 commits: 1 spec + 1 spec-fix + 1 spec-fix + 2 helper-add commits + 1 helper-add finalize + 1 adapter refactor — squash-merge will collapse).
- The spec at `docs/superpowers/specs/2026-04-30-adoclient-aware-paginators-design.md` and revision history.
- The constraint to verify: every page request inside the new helpers and refactored adapter methods goes through `ADOClient.request`, preserving retry / 429-Retry-After / 5xx-retry / typed-exception-mapping. Codex should look for any path where the helper or adapter could see a non-2xx response, leak a raw `httpx.HTTPStatusError`, mutate caller params destructively, or break an existing adapter test.

Apply any Critical / High findings as follow-up commits before opening the PR.

- [ ] **Step 2: Open the PR**

```bash
gh pr create \
  --title "refactor: ADOClient-aware paginators (collapse hand-rolled loops)" \
  --body "$(cat <<'EOF'
## Summary

Resolves the deferred Copilot finding on PR #9: collapses 12 hand-rolled pagination loops in `AzureDevOpsCloudAdapter` onto three new `ADOClient`-aware helpers that preserve retry / `Retry-After` honoring / typed-exception mapping across iteration.

- 3 new helpers in `src/ado_source_core/pagination.py`:
  - `paginate_via_adoclient_continuation_token` (header `x-ms-continuationtoken`)
  - `paginate_via_adoclient_skip_top` (`$skip` / `$top`)
  - `paginate_via_adoclient_body_continuation_token` (body `continuationToken`, with `items_key: str | Sequence[str]` for the entitlements `members` fallback)
- 12 adapter methods refactored to ~1-4 lines of orchestration each.
- Existing httpx-based helpers (`paginate_continuation_token`, `paginate_skip_top`) kept — both styles coexist.
- Spec: `docs/superpowers/specs/2026-04-30-adoclient-aware-paginators-design.md` (with two-round Codex adversarial review applied).

`adapters/ado_cloud.py` line-count delta: see `git diff main...HEAD -- src/ado_source_core/adapters/ado_cloud.py | diffstat`.

## Test plan
- [x] Full unit suite green (`pytest -v`) — baseline 187 plus new helper tests.
- [x] `ruff check`, `ruff format --check`, `mypy src` (strict) all clean.
- [x] Integration smoke against `n8cloud-gp` — no regressions vs. PR #12.
- [x] Two-round Codex adversarial pass on spec; one Codex pass on code.
- [ ] GitHub Copilot auto-review (org ruleset).

🤖 Generated with [Claude Code](https://claude.com/claude-code)
EOF
)"
```

- [ ] **Step 3: Trim the local opt-out file**

`.ai-gate-skip` is local-only and never staged. Leave it in place until the PR is merged (so follow-up commits don't trip the gate); it can be deleted from the worktree once the PR squash-merges.

- [ ] **Step 4: Report to supervisor**

Once Copilot is satisfied and Codex returns clean, report back with:
- PR URL.
- `adapters/ado_cloud.py` line-count delta.
- New public symbols.
- Integration-test confirmation.
- Confirmation of all four superpowers gates used (brainstorming, writing-plans, TDD, verification-before-completion).

---

## Self-review checklist (run before handing off)

**Spec coverage:** Each of the 12 call sites in the spec's table maps to a task above (Tasks 5-10). The three helpers map to Tasks 1-3. The `__init__.py` re-export maps to Task 4. Verification gate maps to Task 11. Codex code review and PR map to Task 12. No spec section is unaddressed.

**Placeholder scan:** No "TBD" / "TODO" / "implement later". Every code block is full code, not a sketch. Every command has expected output. The Codex brief in Task 12 is concrete (specific file paths and the constraint to verify).

**Type consistency:** Helper signatures match between the spec, the test file, and the implementation steps. `items_key: str | Sequence[str]` is consistent across Task 3 (helper), Task 10 (adapter call site), and the test in Task 3. `host: HostName = "dev"` is consistent across all three helpers. `User(...)` field names in Task 7 match the donor file and Pydantic model.
