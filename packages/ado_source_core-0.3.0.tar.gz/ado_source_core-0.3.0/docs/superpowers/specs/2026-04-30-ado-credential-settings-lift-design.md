# Design: ADOCredentialSettings + credential-resolver lift

**Date:** 2026-04-30
**Status:** Approved (supervisor agent A2)
**Audit references:** `shyftport-specs/plans/audit/extraction-plan.md` §3.B + §3.D
**Donor:** `n8group-oss/ado2gh-core` @ `160de58`
**Target file:** `src/ado_source_core/auth.py` (append to existing PATAuth)

## Goal

Land everything still missing from audit §3 in `ado-source-core/auth.py` so that
sub-stage 1.2 (`ado-scanner`) can pick up a complete auth module from PyPI. The
prior session landed only `PATAuth` (PR #6, partial 1.1.7); this PR lands the
remaining `ADOCredentialSettings` + the data-layer half of the credential
resolver.

## Public API additions

Exported from `ado_source_core.auth` and listed in `ado_source_core.__all__`:

| Symbol | Type | Purpose |
|---|---|---|
| `ADOCredentialSettings` | `class(BaseSettings)` | Pydantic Settings — `ado_pat: SecretStr \| None`, `ado_organization: str \| None`. AliasChoices for `ADO_*` and `ADO2GH_*`. |
| `DEFAULT_ADO_BASE_URL` | `str` constant | `"https://dev.azure.com"` — Cloud default. |
| `parse_env_file` | `(env_path: Path) -> dict[str, str]` | Manual `.env` parser (PyInstaller-safe; bypasses python-dotenv). |
| `resolve_ado_credentials` | `(*, organization: str \| None = None) -> dict[str, str]` | Generic resolver. No `prefer_scanner_aliases` knob — scanner UX moves to `ado-scanner`. |

Returns `dict[str, str]` (not TypedDict — donor signature preserved).

## Module-private helpers

Underscore-prefixed, NOT in `__all__`:

- `_resolve_generic_env_value`
- `_resolve_env_preferred_value` — unreachable from this module's public
  surface (only the generic-alias path is exercised), but lifted anyway because
  it is part of the cohesive data-layer toolkit downstream wrappers may
  compose with. Tests exercise it directly to keep it honest code.
- `_clean_env_value`
- `_mask`
- `_is_frozen`

Module-level private constants: `_PAT_ENV_KEYS`, `_ORG_ENV_KEYS`,
`_STRIP_CHARS`, `SETTINGS_CONFIG`.

## Drift from donor

Documented in module docstring and in the commit message. Donor SHA `160de58`,
donor paths `src/ado2gh/models/config.py` and
`src/ado2gh/cli/credential_resolver.py`.

1. **Drop `prefer_scanner_aliases` parameter** and the `_SCANNER_*` /
   `_*_FALLBACK_KEYS` constants. Scanner UX layer relocates to `ado-scanner`
   per audit §3.D.
2. **Slim the diagnostic `logger.debug(...)` block** at the end of
   `resolve_ado_credentials`. The donor block references scanner-flavored
   alias variables (`pat_file_keys`, `org_file_keys`) that no longer exist
   without scanner mode. New block logs `_is_frozen()`, env-loaded flag, env
   var presence, .env file presence, masked PAT preview, and resolved org.

Everything else (sync signature, the manual .env parser justification, the
ASCII-only PAT validation, ConfigError raises, SecretStr on PAT) is lifted
verbatim.

## Module organization

Single file `src/ado_source_core/auth.py`. Order:

1. Module docstring (existing — updated to reflect the broader surface).
2. Donor attribution block (3-line `# Donor: ...` comment) before the
   appended symbols.
3. Existing `PATAuth` (untouched).
4. `SETTINGS_CONFIG` and `DEFAULT_ADO_BASE_URL` constants.
5. `ADOCredentialSettings` class.
6. Private constants (`_PAT_ENV_KEYS`, `_ORG_ENV_KEYS`, `_STRIP_CHARS`).
7. Private helpers (`_clean_env_value`, `_mask`, `_is_frozen`,
   `_resolve_generic_env_value`, `_resolve_env_preferred_value`).
8. Public `parse_env_file`.
9. Public `resolve_ado_credentials`.

## Tests

New file `tests/unit/test_auth_settings.py`. Existing `tests/unit/test_auth.py`
(PATAuth tests) is untouched. TDD per `superpowers:test-driven-development`.

Test cases:

- **`ADOCredentialSettings`**: defaults all None; `ADO_PAT` alias; `ADO2GH_PAT`
  alias; `ADO_ORGANIZATION` alias; `ADO2GH_ORGANIZATION` alias; SecretStr
  masks `repr`; `ADO_PAT` takes precedence over `ADO2GH_PAT`.
- **`parse_env_file`**: plain `KEY=VALUE`; quoted (single + double, stripped);
  `export KEY=VALUE`; comment lines (`#`); blank lines; missing file → `{}`;
  malformed lines (no `=`) skipped; empty key skipped.
- **`_clean_env_value`**: straight quotes, smart quotes (`“”‘’`),
  backticks, surrounding whitespace, trailing newline.
- **`_mask`**: ≤8 chars → `"***"`; >8 chars → `"abcd...wxyz"`.
- **`_is_frozen`**: returns False under pytest.
- **`_resolve_generic_env_value`**: env-over-.env when not frozen; .env-over-env
  when frozen (monkeypatch `sys.frozen`); first-key-wins ordering; missing →
  `None`.
- **`_resolve_env_preferred_value`**: primary preferred globally over
  fallback; primary env-over-.env; fallback env-over-.env; frozen flips both
  to .env-over-env.
- **`resolve_ado_credentials`**: happy path (env only); happy path (.env only,
  via tmp_path + monkeypatch.chdir); env beats .env; missing PAT raises
  `ConfigError`; non-ASCII PAT raises `ConfigError`; missing org raises
  `ConfigError`; explicit `organization=` arg beats env; PAT cleaned of
  surrounding quotes.

## Files touched

| File | Change |
|---|---|
| `pyproject.toml` | Add `pydantic-settings>=2,<3` to `[project] dependencies`. |
| `src/ado_source_core/auth.py` | Append per "Module organization" above. Existing PATAuth unchanged. Module docstring updated. |
| `src/ado_source_core/__init__.py` | Add 4 new public symbols to imports + `__all__`, alphabetical. |
| `tests/unit/test_auth_settings.py` | New file, ~28 test cases. |

Files explicitly NOT touched (sibling A3 territory):
`src/ado_source_core/pagination.py`, `src/ado_source_core/adapters/ado_cloud.py`,
`tests/unit/test_pagination.py`, `tests/unit/test_adapters_ado_cloud.py`. Only
shared file is `__init__.py`'s `__all__` list — alphabetical so trivial rebase.

## Verification (before final push)

- `ruff check src tests`
- `ruff format --check src tests`
- `mypy src` (strict)
- `pytest -v`

Plus a `codex:rescue` adversarial pass between code-ready and final push.

## Out of scope (deferred to follow-ups)

- ADOClient-aware paginators (handoff §2 — sibling A3 may or may not pick this up).
- migration-core upstream backports (handoff §3).
- Tag + publish v0.1.0 / v0.2.0 (user-side OIDC env setup gates this).
