# ADOClient-aware paginators (collapse hand-rolled loops)

**Date:** 2026-04-30
**Status:** approved by supervisor 2026-04-30; ready for plan
**Origin:** Copilot finding on PR #9 (ado-source-core), deferred. Captured in
`shyftport-specs:plans/2026-04-28-handoff-substage-1-1-paused.md`
section "2. ADOClient-aware paginators".

## Goal

Add `ADOClient`-aware pagination helpers to
`src/ado_source_core/pagination.py` that route every page request through
`ADOClient.request`, preserving its retry / rate-limit / error-mapping
behavior, and refactor the 12 hand-rolled pagination loops in
`AzureDevOpsCloudAdapter` to use them.

The existing `httpx.AsyncClient`-based helpers (`paginate_continuation_token`
/ `paginate_skip_top`) **stay** — they still satisfy task 1.1.8's contract.
Both styles coexist.

## Non-goals

- Changing any part of `ADOClient`'s public surface (constructor, `request`
  signature, host-name vocabulary). The new helpers consume the existing
  `request()` API.
- Refactoring endpoints that have no pagination loop (`list_repositories`,
  `list_service_connections`, `list_artifact_feeds`,
  `get_classification_nodes`, single-shot reads like `get_project_details`).
- Touching `src/ado_source_core/auth.py` or `pyproject.toml` (sibling
  agent A2's territory).

## Three new public symbols

All three are async generators yielding `dict[str, Any]` items, using
`client.request("GET", path, host=host, params=...)` to fetch each page.
All three are `keyword-only` for `host` / `params` to mirror
`ADOClient.request`.

```python
async def paginate_via_adoclient_continuation_token(
    client: ADOClient,
    path: str,
    *,
    host: str = "dev",
    params: Mapping[str, Any] | None = None,
) -> AsyncIterator[dict[str, Any]]:
    """Yield items from response['value'] across pages using the
    'x-ms-continuationtoken' response header.

    Used by the majority of paginated ADO endpoints (Projects, Refs,
    Build/Release definitions, Variable groups, Environments, Test plans,
    Branch policies, Graph users)."""
```

```python
async def paginate_via_adoclient_skip_top(
    client: ADOClient,
    path: str,
    *,
    host: str = "dev",
    params: Mapping[str, Any] | None = None,
    page_size: int = 100,
) -> AsyncIterator[dict[str, Any]]:
    """Yield items from response['value'] across pages using
    $skip / $top query parameters.

    Used by Pull requests and TFVC changesets."""
```

```python
async def paginate_via_adoclient_body_continuation_token(
    client: ADOClient,
    path: str,
    *,
    host: str = "dev",
    params: Mapping[str, Any] | None = None,
    items_key: str | Sequence[str] = "items",
) -> AsyncIterator[dict[str, Any]]:
    """Yield items from response[items_key] across pages using
    response['continuationToken'] in the response BODY (not the
    header).

    Specific to the Member Entitlements API
    (`/_apis/userentitlements`). Items live under 'items', not 'value';
    the continuation token comes from the body, not the header.

    `items_key` accepts a single string for the common case and a
    sequence of strings to express a fallback chain — the helper
    returns items from the first key present in the response. Member
    Entitlements is called with `items_key=("items", "members")` to
    preserve the donor's tolerance for an older `members` response
    shape (covered by `test_list_user_entitlements_falls_back_to_members_field`)."""
```

### Why three helpers and not one

`/_apis/userentitlements` has both a different items key (`items`) and a
different token source (body). One overloaded helper with two flags
turns into a coordination problem the moment a fourth API quirk shows
up; three single-purpose helpers each fit on a screen and have an
obvious test surface.

### Naming consistency

The skip-top helper takes `page_size: int = 100` (matching the existing
httpx helper's parameter name), even though the brief sketched
`top=100`. `page_size` is the variable's role; `$top` is the query
parameter that ends up on the wire. Confirmed with supervisor.

## Behavior contract every helper must satisfy

1. **Every page request goes through `ADOClient.request`.**
   - 401/403 → `AuthenticationError` (raised, not retried)
   - 429 → retried with `Retry-After` honoring; `RateLimitError` after
     retries exhausted
   - 503 / `httpx.HTTPError` → retried with exponential backoff;
     `APIError` after retries exhausted
   - Other 4xx / 5xx → `APIError`

   The new helpers do **not** call `response.raise_for_status()` (the
   existing httpx-based helpers do). `ADOClient.request` already raises
   the typed exception above before returning, so any response the
   helper sees is a 2xx and `.json()` is safe to call.
2. **`api-version` overlays survive.** `ADOClient.request` uses
   `merged_params.setdefault("api-version", API_VERSION)`. A caller that
   passes `params={"api-version": "7.1-preview.1"}` (Graph API) or
   `"7.1-preview.4"` (Member Entitlements) wins. Helpers must merge
   their pagination-control keys (`continuationToken`, `$skip`, `$top`)
   into a copy of the caller's params; they must not strip or override
   `api-version`.
3. **`host` is forwarded to `ADOClient.request`.** Default `"dev"`,
   matching `ADOClient.request`. Caller-supplied values like `"vsrm"`,
   `"vssps"`, `"vsaex"` route to the correct host base URL.
4. **Termination is identical to the existing httpx helpers.**
   - Continuation-token (header) terminates when the response has no
     `x-ms-continuationtoken` header or the value is empty.
   - Continuation-token (body) terminates when `data["continuationToken"]`
     is missing, `None`, or empty.
   - $skip/$top terminates when a page is empty or shorter than
     `page_size` (avoiding the wasted "is there more?" round trip).

## Adapter call sites to refactor (12 loops)

Each method collapses to either a 3-line list comprehension (lists) or a
2-line `sum(1 async for …)` (counts), with the per-call-site arguments
spelled out below. Behavior-significant params (filters, status
selectors, large `$top` overrides) are preserved 1:1 with the donor.

### Header continuation token (9)

| Method | Path | Host | Caller params | Result transform |
|---|---|---|---|---|
| `list_projects` | `/_apis/projects` | `dev` | `{"stateFilter": state_filter, "$top": "100"}` | `[item async for item in helper(...)]` |
| `count_branches` | `/{project}/_apis/git/repositories/{repo}/refs` | `dev` | `{"filter": "heads/", "$top": "100"}` | `sum(1 async for _ in helper(...))` |
| `list_build_definitions` | `/{project}/_apis/build/definitions` | `dev` | `{"$top": "100"}` | list comprehension |
| `list_release_definitions` | `/{project}/_apis/release/definitions` | `vsrm` | `{"$top": "100"}` | list comprehension |
| `list_variable_groups` | `/{project}/_apis/distributedtask/variablegroups` | `dev` | `{"$top": "100"}` | list comprehension |
| `list_environments` | `/{project}/_apis/distributedtask/environments` | `dev` | `{"$top": "100"}` | list comprehension |
| `list_test_plans` | `/{project}/_apis/testplan/plans` | `dev` | `{"$top": "100"}` | list comprehension |
| `list_branch_policies` | `/{project}/_apis/git/policy/configurations` | `dev` | `{"$top": "100"}` | list comprehension |
| `list_users` | `/_apis/graph/users` | `vssps` | `{"api-version": "7.1-preview.1"}` | list comprehension that builds typed `User` models from each `entry` |

### `$skip` / `$top` (2)

| Method | Path | Host | Caller params | Result transform |
|---|---|---|---|---|
| `count_pull_requests` | `/{project}/_apis/git/repositories/{repo}/pullrequests` | `dev` | `{"searchCriteria.status": state or "all"}` | `sum(1 async for _ in helper(..., page_size=100))` |
| `list_tfvc_changesets` (count loop only) | `/{project}/_apis/tfvc/changesets` | `dev` | `{}` (the outer "fetch latest" call still does one explicit `request` with `{"$top": "1", "$orderby": "id desc"}`) | `sum(1 async for _ in helper(..., page_size=100))` |

These two endpoints are documented to honor the requested `$top` value
up to 100; the existing donor loops rely on this and the refactored
loops keep the same termination semantics ("page is empty or shorter
than `page_size`"). If a future endpoint silently caps below
`page_size`, it must use a body / continuation-token variant instead.

### Body continuation token (1)

| Method | Path | Host | Caller params | Result transform |
|---|---|---|---|---|
| `list_user_entitlements` | `/_apis/userentitlements` | `vsaex` | `{"$top": "10000", "api-version": "7.1-preview.4"}` | `[item async for item in helper(..., items_key=("items", "members"))]` |

The `items_key=("items", "members")` tuple preserves the donor's
fallback to the older `members` response shape (covered by
`test_list_user_entitlements_falls_back_to_members_field`).

After the refactor each method should be one to four lines of
orchestration around the helper, and the deferred-paginator docstring on
`list_projects` should be removed. The donor `User` mapping inside
`list_users` remains intact — the helper yields raw dicts, and the
adapter's list comprehension constructs `User(...)` from each yielded
entry.

## Tests

### New unit tests in `tests/unit/test_pagination.py`

For each new helper — using `respx` to mock at the httpx layer and a
real `ADOClient` instance — verify:

1. Happy path: pages through to termination, yields all items in order.
2. Single page (no continuation marker): yields once, makes one request.
3. Empty first page: yields nothing.
4. Continuation marker forwarded correctly on the next request
   (`continuationToken=...` query param for header / body variants;
   `$skip` increments by `page_size` for skip-top).
5. **Empty page mid-iteration with a continuation marker continues, not
   terminates** (header + body helpers). The token, not item presence,
   drives termination — matching the existing httpx helper behavior.
   - Header helper test shape: page 1 returns `{"value": []}` plus a
     non-empty `x-ms-continuationtoken` response header, page 2 returns
     `{"value": [{"id": "1"}]}` and no header.
   - Body helper test shape: page 1 returns
     `{"items": [], "continuationToken": "cursor"}`, page 2 returns
     `{"items": [{"id": "1"}], "continuationToken": ""}` (or omits the
     field). Use the configured `items_key` for the items array and the
     body field `"continuationToken"` for the marker.
   In both cases the helper must yield the page-2 item, not stop after
   page 1.
6. **Error mapping is preserved.** This is the contract that justifies
   the new helpers: a 401 response must raise `AuthenticationError`
   (not `httpx.HTTPStatusError`); a 500 must raise `APIError`; a 429
   with no `Retry-After` and `max_retries=1` must raise
   `RateLimitError`. One test per error class is enough at the
   single-request level — the deeper retry mechanics already have
   coverage in `test_client.py`.
7. **Mid-iteration retry preservation (the constraint-proof tests).**
   Page 1 returns a continuation marker. Page 2 first returns 429 with
   `Retry-After: 0`, then on retry returns the next batch of items
   plus no marker. The helper must:
   - yield items from page 1, then yield items from the post-retry
     page-2 response;
   - call the same path twice on page 2 (initial + retry), with the
     `continuationToken` query param present on **both** retry attempts
     (params merge survives across retries inside `ADOClient.request`);
   - terminate after page 2 with no marker.
   Add the equivalent test for a transient `httpx.ConnectError` raised
   on the page-2 request that succeeds on retry, and a transport-error
   test that exhausts retries and raises `APIError` from inside the
   iteration.
8. (Body-continuation-token only) `items_key` accepts both a single
   string (`"items"`, `"value"`) and a sequence (`("items", "members")`)
   that walks the chain and returns items from the first key present in
   the response.
9. (Body-continuation-token only) Header-token is **not** consulted —
   document the divergence with a test where the response carries
   `x-ms-continuationtoken` but no body token: the helper must
   terminate after the first page.

### Adapter tests

`tests/unit/test_adapters_ado_cloud.py` exercises every refactored
method already. Mock surface is unchanged (URL, params, JSON body,
headers), so existing tests should pass without modification. If a test
mocked `httpx.AsyncClient` directly (rather than via `respx`), it may
need minor adaptation; respx mocks at the transport layer and is
agnostic to whether the caller is the httpx helper or the new
ADOClient-aware helper.

### Integration

Re-run the smoke suite against `n8cloud-gp` after lint / format / mypy /
unit pass:

```
ADO_ORG=n8cloud-gp ADO_PAT="$(op read 'op://Private/ADO n8cloud-gp/PAT Full Access')" \
  pytest tests/integration -m integration -v
```

Required: zero regressions vs. the smoke suite landed in PR #12.

## Public surface change (`__init__.py`)

Add three new symbols to `__all__` in alphabetical position. Existing
imports of `paginate_continuation_token` / `paginate_skip_top` remain
unchanged.

```python
from ado_source_core.pagination import (
    paginate_continuation_token,
    paginate_skip_top,
    paginate_via_adoclient_body_continuation_token,
    paginate_via_adoclient_continuation_token,
    paginate_via_adoclient_skip_top,
)
```

(Note alphabetic ordering: `body_continuation_token` < `continuation_token`
< `skip_top`.)

## Coordination with sibling agents

- **A1 (migration-core):** different repo, no overlap.
- **A2 (ado-source-core auth.py + pyproject.toml):** the only shared
  file is `src/ado_source_core/__init__.py`'s `__all__` list. Whichever
  PR lands second rebases trivially because `__all__` is alphabetical.

## Commit cadence

Per the workflow rules in the dispatch brief: commit early, push every
~30 minutes or before any long operation. Expected commit shape:

1. `refactor: add ADOClient-aware paginator helpers (3 new functions)`
   — pagination.py + tests/unit/test_pagination.py + __init__.py.
2. `refactor: collapse adapter pagination loops onto ADOClient-aware helpers`
   — adapters/ado_cloud.py and any minor adapter-test adjustments.

Two commits keeps the helper-add and the call-site refactor reviewable
independently. Squash on merge anyway, but a reviewer should be able to
see the helper landing first.

## Verification gate (before requesting merge)

- `ruff check src tests`
- `ruff format --check src tests`
- `mypy src` (strict)
- `pytest -v` (unit; should remain ≥ 187 — the diff adds tests)
- Integration smoke against `n8cloud-gp` (no regressions)

## Codex review checkpoints

Per the dispatch brief workflow:
1. After this design doc lands → Codex pass on the spec.
2. After both commits land on the branch → Codex pass on the code.

Codex is the right reviewer for the constraint-preservation question
("does the new helper actually preserve every retry/rate-limit/error-
mapping invariant `ADOClient.request` provides?"). Copilot
auto-reviews the PR via the org-level ruleset.
