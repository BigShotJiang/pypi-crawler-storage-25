# Design: Azure DevOps Server adapter + api-version discovery

**Date:** 2026-05-06
**Status:** Revised after Codex adversarial review (supervisor agent A6)
**Audit references:** `shyftport-specs/plans/audit/extraction-plan.md` (RO bucket); `shyftport-specs/plans/audit/read-only-modules.md`
**Donor:** `n8group-oss/ado2gh-core` @ `160de58` — `src/ado2gh/adapters/ado_server.py`
**Target package:** `ado-source-core` v0.3.0
**Branch:** `feat/azure-devops-server-adapter`

## Goal

Add `AzureDevOpsServerAdapter` to `ado-source-core` with the same read-side
surface as `AzureDevOpsCloudAdapter`, plus an api-version discovery mechanism
that lets the adapter automatically negotiate the highest mutually-supported
REST API version against an Azure DevOps Server instance. The result lets
`ado-scanner` and the future `ado2gh-core` migration engine target on-prem
Azure DevOps Server installations (releases 2022 / 2020 / 2019 Update 1+ /
2019 RTW, REST API versions 7.0 / 6.0 / 5.1 / 5.0).

The transport layer is refactored to share concerns between cloud and server
via an abstract `BaseADOClient`; the existing concrete `ADOClient` becomes an
alias for the renamed `ADOCloudClient` so existing imports keep working.

## Public API additions

Exported from `ado_source_core` and listed in `__all__` (alphabetical) at the
end of work:

| Symbol | Type | Purpose |
|---|---|---|
| `BaseADOClient` | `class(ABC)` | Shared transport contract — auth/retry/rate-limit/error-mapping. Public so consumers can type-annotate code that accepts either backend. |
| `ADOServerClient` | `class(BaseADOClient)` | Single-host, collection-aware HTTP client with auto-discovered REST api-version. |
| `ADOCloudClient` | `class(BaseADOClient)` | New name for the existing 6-host cloud client. `ADOClient = ADOCloudClient` alias preserves existing imports. |
| `AzureDevOpsServerAdapter` | `class(SourceAdapter[Repository, User])` | Concrete read-side adapter for Azure DevOps Server. |
| `UnsupportedOnAzureDevOpsServerError` | `class(ADOSourceCoreError)` | Raised when a capability is unavailable on the resolved Server instance. Carries `capability: str`, `remediation: str \| None`, `api_version: str` (required). |
| `SERVER_API_VERSION_CANDIDATES` | `tuple[str, ...]` | `("7.0", "6.0", "5.1", "5.0")` — supported Server REST api-versions, highest first. |
| `ServerProbeResult` | `frozen dataclass` | Result of `resolve_server_api_version`: `api_version`, `capability_overrides`, `probe_strategy`. |
| `resolve_server_api_version` | `async function` | Public probe entrypoint exposed for advanced use (custom client wrapping, diagnostics). |
| `SourceCapabilities.server_default` | `classmethod` | Factory mirroring `cloud_default`; takes resolved `api_version=`. |
| `SourceCapabilities.with_overrides` | `method` | Returns a copy with probe-discovered flag overrides applied. Whitelist: only the three soft-capability fields are overridable. |
| `SourceCapabilities.supports_graph_api` | `bool` field | Default `True`; probed on Server. |
| `SourceCapabilities.supports_analytics_odata` | `bool` field | Default `True`; probed on Server. |
| `SourceCapabilities.supports_artifact_feeds` | `bool` field | Default `True`; probed on Server. Replaces `supports_packages`. |

## Public API removals

| Symbol | Replacement |
|---|---|
| `SourceCapabilities.supports_packages` | `supports_artifact_feeds` (functionally equivalent; renamed for on-prem clarity). |

This is a breaking change at the `SourceCapabilities` model level. We are at
v0.2.x → v0.3.0, so consumers reading the field need to switch to the new
name. The CHANGELOG `[Unreleased]` block calls this out with an explicit
migration instruction. Verified: no test currently asserts against
`supports_packages`, so commit 5 (the model change) does not require
existing-test updates beyond the field-default-list scan.

## Backwards-compatibility notes

- `from ado_source_core.client import ADOClient` and
  `ado_source_core.ADOClient` continue to work; `ADOClient` is a
  module-level alias for `ADOCloudClient`.
- `isinstance(x, ADOClient)` continues to match cloud clients (alias
  preserves identity).
- **Reflection-derived class names change:** `type(client).__name__` and
  `type(client).__qualname__` now return `"ADOCloudClient"` instead of
  `"ADOClient"`. Telemetry, metrics labels, log scrapers, or pickled class
  metadata that key on the old name need to be updated. CHANGELOG
  `[Unreleased]` block notes this.
- `pagination.py`'s type annotations migrate from `ADOClient` to
  `BaseADOClient` so the helpers type-check cleanly with both subclasses.
  Runtime behavior unchanged.

## Architecture

### Module map

```
src/ado_source_core/
├── client.py
│   ├── BaseADOClient (abstract)
│   ├── ADOCloudClient(BaseADOClient)              # renamed from ADOClient
│   ├── ADOServerClient(BaseADOClient)             # NEW
│   └── ADOClient = ADOCloudClient                 # alias for backwards compat
├── api_version_discovery.py                       # NEW
│   ├── SERVER_API_VERSION_CANDIDATES = ("7.0", "6.0", "5.1", "5.0")
│   ├── ServerProbeResult (frozen dataclass)
│   └── async resolve_server_api_version(client) -> ServerProbeResult
├── adapters/
│   ├── source.py                                  # unchanged
│   ├── ado_cloud.py                               # unchanged
│   └── ado_server.py                              # NEW
│       └── AzureDevOpsServerAdapter
├── exceptions.py
│   └── UnsupportedOnAzureDevOpsServerError        # NEW
├── models/
│   └── source_capabilities.py
│       ├── SourceCapabilities                     # +3 flags, -1 flag
│       ├── server_default(api_version=...)        # NEW
│       └── with_overrides(...)                    # NEW
└── __init__.py                                    # __all__ extended
```

### Layering

```
AzureDevOpsServerAdapter   ← typed call layer; gates calls on capability flags
        │
        ▼
ADOServerClient            ← transport layer; owns api-version, single httpx
        │                    client, soft-capability overrides from probe
        ▼
BaseADOClient              ← shared retry/rate-limit/error-mapping/close()
        │
        ▼
httpx.AsyncClient          ← raw HTTP
```

The cloud side mirrors this: `AzureDevOpsCloudAdapter` → `ADOCloudClient` →
`BaseADOClient` → `httpx`. Both adapters use the same paginators in
`pagination.py` unchanged — those take a `BaseADOClient` (typed today as
`ADOClient` via the alias).

### Boundary properties

- `BaseADOClient.request()` owns the entire transport contract: auth header
  injection (already done at `__init__` via `httpx` headers); `api-version`
  query-param injection (`skip_api_version=True` to bypass); retry on 429/503
  with `Retry-After` parsing; `httpx.HTTPError`-tolerant retry; error mapping
  to `AuthenticationError` / `RateLimitError` / `APIError`. Both subclasses
  inherit verbatim — no duplication.
- `_select_client(host)` is the only routing seam each subclass overrides
  (or shares via the default lookup in `self._clients`). Cloud returns a
  distinct httpx client per host; Server returns the same single client for
  every host, so inherited logic that passes `host="vssps"` is route-safe
  (never `KeyError`s). The adapter is responsible for capability-gating
  before any unsupported call goes out, so the alias-lookup never actually
  runs against Server.
- `httpx_client(host)` on Server returns the same single httpx client for
  every host argument. This is documented in the method's docstring with a
  warning to debug consumers: do NOT infer routing, TLS target, or endpoint
  family from `client.httpx_client("vssps").base_url` on Server — the
  collection URL is always returned. Use `type(client).__name__` or
  `isinstance(client, ADOServerClient)` instead.
- `api_version` property is overridden by Server to return the resolved
  version cached during `connect()`; Cloud returns the static `"7.1"`
  module constant.
- Pagination helpers untouched at the runtime level. They accept any
  `BaseADOClient` subclass and pass `host=` through. Type annotations in
  `pagination.py` migrate from `ADOClient` to `BaseADOClient` so the
  helpers type-check cleanly with both subclasses (bundled into commit 1).
- `AzureDevOpsServerAdapter` is a sibling of `AzureDevOpsCloudAdapter`, NOT
  a subclass. The decision is driven by transport-shape divergence: cloud's
  six pinned httpx clients vs server's single collection-scoped client mean
  any `super()`-call from a server method to a cloud method's body would
  carry a `host=` argument that no longer makes sense at the URL level
  (e.g., `host="vsrm"` on cloud routes to `vsrm.dev.azure.com`; on server
  it routes to the same single client and the URL path determines the
  endpoint). The donor's subclass-and-override pattern only re-implements
  two methods, but our refactor of `ADOClient` makes that pattern
  un-natural for the others. Sibling adapters are easier to read in
  isolation, easier to unit-test, and easier to retire one day if Server
  gets dropped.
- **Drift-vector mitigation:** because the two adapters can diverge, a
  dedicated **method-set parity test** (introspection-based) asserts that
  `AzureDevOpsCloudAdapter` and `AzureDevOpsServerAdapter` expose the same
  set of public method names with identical signatures. Any future cloud
  method addition that's missed on server (or vice versa) fails CI.

## Components

### `BaseADOClient` (abstract, in `client.py`)

```python
class BaseADOClient(ABC):
    _clients: dict[str, httpx.AsyncClient]
    _max_retries: int

    @property
    @abstractmethod
    def api_version(self) -> str: ...

    def _select_client(self, host: HostName) -> httpx.AsyncClient:
        return self._clients[host]

    def httpx_client(self, host: HostName = "dev") -> httpx.AsyncClient:
        return self._select_client(host)

    async def request(
        self,
        method: str,
        url: str,
        *,
        host: HostName = "dev",
        params: Mapping[str, Any] | None = None,
        skip_api_version: bool = False,
        **kwargs: Any,
    ) -> httpx.Response:
        # Existing retry/rate-limit/error-mapping loop, lifted verbatim from
        # the current ADOClient.request(). Uses self.api_version for the
        # default api-version query param.

    async def close(self) -> None:
        # Iterate self._clients.values() (deduplicated), close each, log
        # warnings on partial close failure.

    async def __aenter__(self) -> Self: return self
    async def __aexit__(self, *exc) -> None: await self.close()
```

### `ADOCloudClient` (renamed from `ADOClient`)

Identical body to today's `ADOClient` — keeps `organization`, six named
`httpx.AsyncClient` instances pinned to the cloud host fanout, fixed
`api_version = API_VERSION = "7.1"`. The module-level alias
`ADOClient = ADOCloudClient` preserves every existing import (test
fixtures, integration conftest, downstream consumers). No behavior change
for cloud users.

### `ADOServerClient` (new)

```python
class ADOServerClient(BaseADOClient):
    def __init__(
        self,
        *,
        base_url: str,                         # "https://devops.example.com:8080/tfs"
        collection: str,                       # "DefaultCollection"
        auth: PATAuth,
        verify_ssl: bool | str = True,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
        max_retries: int = DEFAULT_MAX_RETRIES,
        api_version: str | None = None,        # if set, skip probing
    ) -> None: ...

    @property
    def api_version(self) -> str:
        # Raises RuntimeError with the message
        #   "ADOServerClient is not connected — use `async with` or call
        #    `await client.connect()` before issuing requests."
        # if connect() has not run AND no explicit api_version was passed
        # to __init__.

    @property
    def resolved_api_version(self) -> str | None:
        # Diagnostic: None until connect() runs.

    @property
    def capability_overrides(self) -> Mapping[str, bool]:
        # Read-only MappingProxyType view, populated by connect().

    @property
    def collection(self) -> str: ...

    async def connect(self) -> None:
        # Idempotent. Calls api_version_discovery.resolve_server_api_version,
        # stores api_version + capability_overrides on the instance.

    async def __aenter__(self) -> Self:
        try:
            await self.connect()
        except BaseException:
            await self.close()  # don't leak the httpx client built in __init__
            raise
        return self

    async def close(self) -> None:
        # Closes the single underlying httpx client exactly once.
```

`__init__` builds **one** httpx client at
`{base_url}/{collection}` (after `_resolve_collection_base_url` strips a
trailing slash, avoids double-suffixing if `base_url` already ends with
`/{collection}`, AND raises `ConfigError` if the URL contains embedded
basic auth like `https://user:pass@devops/tfs` — embedded credentials
conflict with the `Authorization: Basic <PAT>` header and create a leak
risk). All six logical host names (`dev`, `vsrm`, `feeds`, `analytics`,
`vssps`, `vsaex`) alias to that single client in `self._clients`, so
`_select_client(host)` returns it for any value. Closing iterates the
deduplicated set (one entry).

Two-phase init: `__init__` is sync and never makes HTTP calls; `connect()`
runs the probe. The `async with` form runs `connect()` automatically via
`__aenter__`, with a `try/except` wrapper that closes the httpx client and
re-raises if the probe fails — preventing socket leaks on auth or network
errors during context entry. Manual users call `await client.connect()`
after construction.

**`api_version=` escape hatch.** Setting `api_version=` at construction
bypasses the **api-version** probe (the round-trip to `/_apis/connectionData`
+ candidate iteration) but soft-capability probes still run during
`connect()` so the capability set stays authoritative. This protects the
"all required information collected" guarantee: an explicit api-version
doesn't disable capability safety. Useful in tests (skip the version probe;
assert static api-version flows through) and in environments where
`connectionData` + candidate iteration are firewalled but the optional
extension probes are reachable.

### `api_version_discovery.py` (new)

```python
SERVER_API_VERSION_CANDIDATES: tuple[str, ...] = ("7.0", "6.0", "5.1", "5.0")
"""Supported REST api-versions for ADO Server, highest first.
- 7.0 -> Azure DevOps Server 2022
- 6.0 -> Azure DevOps Server 2020
- 5.1 -> Azure DevOps Server 2019 Update 1+
- 5.0 -> Azure DevOps Server 2019 RTW
TFS 2018 (REST 4.x) and earlier are out of scope for v0.3.0.
"""


@dataclass(frozen=True)
class ServerProbeResult:
    api_version: str
    capability_overrides: dict[str, bool] = field(default_factory=dict)
    capability_notes: list[str] = field(default_factory=list)  # lifted to SourceCapabilities.notes
    probe_strategy: str = "connection_data"   # or "candidate_iteration"


async def resolve_server_api_version(client: ADOServerClient) -> ServerProbeResult: ...
```

**Logging:** new module uses stdlib `logging.getLogger(__name__)` to match
`ado_source_core.client`. The donor used `structlog`; we drop that dep
inside this module. (The package-level `structlog>=24,<26` runtime
dependency is unused after this PR and is flagged for removal in v0.4.0.)

**Strategy:**

1. `GET /_apis/connectionData` (with `skip_api_version=True`). The
   `connectionData` payload is a structured response of `instanceId`,
   `authenticatedUser`, `authorizedUser`, and `locationServiceData`. The
   top-level `apiVersion` field is **best-effort**: in practice it is
   emitted on Server 2020+ (verified via donor production usage) but may
   be absent on Server 2019 RTW. We extract it tolerantly via
   `payload.get("apiVersion")` AND `payload.get("locationServiceData",
   {}).get("apiVersion")`. If parseable, snap to the highest candidate
   that is `<= advertised`. Strategy = `"connection_data"`. If the field
   is missing or unparseable, fall through to step 2 — connectionData
   remains useful for auth verification + base-URL validation even when
   the version field is absent.
2. Fallback: iterate `SERVER_API_VERSION_CANDIDATES` top-down, calling
   `GET /_apis/projects?$top=1&api-version=<candidate>` (with
   `skip_api_version=True`). Accept the first that returns 200. Strategy =
   `"candidate_iteration"`.
3. If every candidate returns 4xx/5xx (excluding auth errors, which
   propagate), raise `APIError` with the last status seen and the candidate
   list in the message.

`_parse_version` accepts only `"<int>.<int>"`. Edge cases that return
`None` (and trigger fallthrough): missing field entirely; non-string
type; empty string; `"7"` (one component); `"7.0.0"` (three components);
`"7.x"` (non-integer component).

After api-version resolves, fire soft-capability probes in parallel via
`asyncio.gather`. Each probe maps `200` → `True`, `404`/`501` → `False`.
**Auth errors (`401`/`403`) on a soft-cap probe** map to `False` AND
append a diagnostic line to the result's `capability_notes` list — for
example `"supports_analytics_odata probe returned 401; the capability
may exist but the PAT lacks the required scope (vso.analytics)."` This
keeps a missing-scope deployment usable for the calls the PAT IS
authorized for, and surfaces the ambiguity to discovery-report consumers
via `SourceCapabilities.notes`. Rate-limit errors (`429`) and 5xx still
propagate from soft-cap probes — those are infrastructure problems, not
capability questions.

**Probe shapes:**

- `supports_graph_api` — try
  `GET /_apis/graph/users?$top=1&api-version=<resolved>-preview.1` first
  (Graph is preview-versioned on cloud and on some Server deployments);
  on `400 InvalidApiVersion`, retry with plain `api-version=<resolved>`
  (donor's pattern). Accept the first that returns 200. The
  `list_users` adapter method must use the same versioning that worked
  for the probe — store the resolved Graph api-version string on the
  capability set as a separate field-or-note so the adapter can read it
  back without re-probing.
- `supports_analytics_odata` — try collection-scoped
  `GET /_odata/v4.0-preview/$metadata` first; on `404`, retry with
  project-scope using the project name we already discovered during
  candidate iteration: `GET /{project}/_odata/v4.0-preview/$metadata`.
  Mark `True` only if at least one variant returns 200. (Analytics is
  auto-installed on Server 2020+ but requires manual extension install
  on Server 2019; both forms must be tried.)
- `supports_artifact_feeds` — `GET /_apis/packaging/feeds?$top=1&api-version=<resolved>`.
  No fallback needed — Package Management uses the standard collection-scoped
  REST surface when installed.

Worst case: 1 connectionData + 4 candidates + (2 graph attempts + 2 analytics
attempts + 1 feeds) = 5 sequential then 2 sequential round-trips. Best case:
1 connectionData + (3 parallel cap probes, single-call each) = 2 sequential
round-trips.

### `AzureDevOpsServerAdapter` (new)

```python
class AzureDevOpsServerAdapter(SourceAdapter[Repository, User]):
    def __init__(
        self,
        *,
        client: ADOServerClient,
        capabilities: SourceCapabilities | None = None,
    ) -> None: ...

    @property
    def client(self) -> ADOServerClient: ...

    async def get_capabilities(self) -> SourceCapabilities:
        if self._capabilities is not None:
            return self._capabilities
        base = SourceCapabilities.server_default(api_version=self._client.api_version)
        self._capabilities = base.with_overrides(
            self._client.capability_overrides,
            notes=self._client.capability_notes,  # carries probe-ambiguity diagnostics
        )
        return self._capabilities

    async def __aenter__(self) -> Self:
        # Ensures the underlying client probe ran before adapter use, even if
        # the caller forgot to use `async with ADOServerClient(...)` outside.
        # Idempotent — ADOServerClient.connect() is itself idempotent.
        await self._client.connect()
        return self

    # __aexit__ is inherited from SourceAdapter (calls self.close()).

    # ... per-method implementations (see method-by-method contract below) ...
```

Constructor takes an `ADOServerClient`. The client must be connected
(probe-resolved) before per-method calls run; the adapter's `__aenter__`
override calls `await self._client.connect()` so the recommended usage:

```python
async with ADOServerClient(...) as client:                     # probes here
    async with AzureDevOpsServerAdapter(client=client) as adapter:
        ...
# OR, equivalently — adapter alone also probes:
async with AzureDevOpsServerAdapter(client=ADOServerClient(...)) as adapter:
    ...
```

Like `AzureDevOpsCloudAdapter`, accepts an explicit `capabilities=`
override — useful for tests that want to assert eager-raise behavior
without running a probe.

### `UnsupportedOnAzureDevOpsServerError` (new)

```python
class UnsupportedOnAzureDevOpsServerError(ADOSourceCoreError):
    """Raised when a capability is unavailable on this Azure DevOps Server instance.

    Carries enough structured context for downstream tooling (notably
    ado-scanner's discovery report) to surface a useful "what was missed"
    line without parsing the message.
    """

    def __init__(
        self,
        message: str,
        *,
        capability: str,                       # e.g. "supports_graph_api"
        api_version: str,                      # the server's resolved api-version (required)
        remediation: str | None = None,        # short admin-oriented hint
        exit_code: ExitCode = ExitCode.USER_ERROR,
    ) -> None:
        super().__init__(message, exit_code=exit_code)
        self.capability = capability
        self.api_version = api_version
        self.remediation = remediation
```

`api_version` is required — every raise site has access to
`caps.api_version` (the resolved server REST version) and discovery-report
consumers need it to write a meaningful "missed on Server <version>" line.

### `SourceCapabilities` extensions

```python
class SourceCapabilities(BaseModel):
    model_config = ConfigDict(extra="forbid")

    source_type: SourceType
    api_version: str = "7.1"
    supports_collections: bool = False
    supports_user_entitlements: bool = True
    # supports_packages REMOVED — replaced by supports_artifact_feeds.
    supports_pipelines: bool = True
    supports_pull_request_threads: bool = True

    # NEW soft capabilities — default True so cloud_default doesn't list them.
    supports_graph_api: bool = True
    supports_analytics_odata: bool = True
    supports_artifact_feeds: bool = True

    compatibility_mode: bool = False
    notes: list[str] = Field(default_factory=list)

    @classmethod
    def cloud_default(cls) -> "SourceCapabilities":
        return cls(source_type=SourceType.AZURE_DEVOPS_CLOUD)

    OVERRIDABLE_SOFT_CAPABILITY_KEYS: ClassVar[frozenset[str]] = frozenset({
        "supports_graph_api",
        "supports_analytics_odata",
        "supports_artifact_feeds",
    })

    @classmethod
    def server_default(cls, *, api_version: str = "7.0") -> "SourceCapabilities":
        compatibility_mode = api_version in {"5.0", "5.1"}
        notes: list[str] = []
        if compatibility_mode:
            notes.append(f"Server 2019 compatibility mode enabled (api-version {api_version})")
        return cls(
            source_type=SourceType.AZURE_DEVOPS_SERVER,
            api_version=api_version,
            supports_collections=True,
            supports_user_entitlements=False,   # hard-False on Server
            compatibility_mode=compatibility_mode,
            notes=notes,
        )

    def with_overrides(
        self,
        overrides: Mapping[str, bool],
        *,
        notes: Sequence[str] = (),
    ) -> "SourceCapabilities":
        # Whitelist enforcement: only the three soft-capability fields can be
        # overridden by probe results. Attempts to override any other field
        # (including hard-False supports_user_entitlements) raise ValueError.
        unknown = set(overrides) - self.OVERRIDABLE_SOFT_CAPABILITY_KEYS
        if unknown:
            raise ValueError(
                f"with_overrides only accepts soft-capability keys "
                f"{sorted(self.OVERRIDABLE_SOFT_CAPABILITY_KEYS)}; "
                f"got disallowed keys: {sorted(unknown)}"
            )
        data = self.model_dump()
        data.update(overrides)
        if notes:
            data["notes"] = [*data.get("notes", []), *notes]
        return type(self).model_validate(data)
```

`server_default()` sets the always-known flags conservatively:

- `supports_user_entitlements=False` (hard — vsaex API is cloud-only).
  Cannot be flipped by `with_overrides()` (whitelist enforcement).
- Soft flags (`supports_graph_api`, `supports_analytics_odata`,
  `supports_artifact_feeds`) keep their model defaults of `True`; the
  probe at `connect()` time may demote any of them to `False` via
  `with_overrides()` — these are the ONLY fields the whitelist allows.
- `supports_collections=True`.
- `supports_pipelines=True` (build defs + classic release defs both exist).
- `supports_pull_request_threads=True` (PR threads exist on 2019+).
- `compatibility_mode=True` iff `api_version` is `"5.0"` (Server 2019 RTW)
  or `"5.1"` (Server 2019 Update 1+). The note line records which exact
  api-version triggered compatibility mode so consumers can branch on it
  if needed.

## Method-by-method contract (`AzureDevOpsServerAdapter`)

Every public method on `AzureDevOpsCloudAdapter` has exactly one corresponding
method here with the **same signature** and the **same return-shape semantics**.
Methods either implement the call against the Server URL shape, or raise
`UnsupportedOnAzureDevOpsServerError` based on the resolved capability set.

| Cloud method | Server behavior | Capability gate | URL on Server |
|---|---|---|---|
| `verify_credentials` | Same 3-step probe (projects → repos → builds) | None | `/_apis/projects` then `/{project}/_apis/...` |
| `get_capabilities` | Returns cached probe result | None | n/a |
| `list_projects` | Identical | None | `/_apis/projects` |
| `get_project_details` | Identical | None | `/_apis/projects/{id}` |
| `get_process_template` | Identical | None | `/_apis/work/processes/{id}` |
| `list_repositories` | Identical | None | `/{project}/_apis/git/repositories` |
| `get_repository` | `NotImplementedError` (matches cloud) | None | n/a |
| `count_branches` | Identical | None | `/{project}/_apis/git/repositories/{repo}/refs` |
| `count_pull_requests` | Identical | None | `/{project}/_apis/git/repositories/{repo}/pullrequests` |
| `detect_lfs_patterns` | Identical | None | `/{project}/_apis/git/repositories/{repo}/items` |
| `analyze_large_files` | Identical | None | `/{project}/_apis/git/repositories/{repo}/(refs\|commits\|trees)` |
| `get_file_content` | Identical | None | `/{project}/_apis/git/repositories/{repo}/items` |
| `list_build_definitions` | Identical | None | `/{project}/_apis/build/definitions` |
| `get_build_definition` | Identical | None | `/{project}/_apis/build/definitions/{id}` |
| `list_release_definitions` | Identical (collection-scoped, single-host) | None | `/{project}/_apis/release/definitions` |
| `get_release_definition` | Identical | None | `/{project}/_apis/release/definitions/{id}` |
| `list_service_connections` | Identical | None | `/{project}/_apis/serviceendpoint/endpoints` |
| `list_variable_groups` | Identical | None | `/{project}/_apis/distributedtask/variablegroups` |
| `list_environments` | Identical | None | `/{project}/_apis/distributedtask/environments` |
| `query_work_item_counts` | Collection-base, project-scoped OData | `supports_analytics_odata` | `/{collection}/{project}/_odata/v4.0-preview/WorkItems` |
| `get_classification_nodes` | Identical | None | `/{project}/_apis/wit/classificationnodes` |
| `get_custom_fields_count` | Identical | None | `/_apis/work/processes/{id}/workItemTypes/{wit}/fields` |
| `list_artifact_feeds` | Identical (collection-scoped) | `supports_artifact_feeds` | `/{project}/_apis/packaging/feeds` or `/_apis/packaging/feeds` |
| `list_test_plans` | Identical | None | `/{project}/_apis/testplan/plans` |
| `list_branch_policies` | Identical | None | `/{project}/_apis/git/policy/configurations` |
| `list_tfvc_changesets` | Identical | None | `/{project}/_apis/tfvc/changesets` |
| `list_user_entitlements` | **Always raises** | `supports_user_entitlements` (hard False) | n/a |
| `list_users` | Probe-resolved Graph api-version (preview-suffix-aware) | `supports_graph_api` | `/_apis/graph/users` |
| `get_user` | `NotImplementedError` (matches cloud) | None | n/a |
| `close` | Closes the single httpx client | None | n/a |

**`AzureDevOpsServerAdapter` does NOT pass `host=` arguments** — it relies
on the default `host="dev"`. The server client's `_select_client` returns
the same single httpx client for every host value, but server adapter
methods omit the argument entirely so the call signature is honest about
the single-host transport. Tests assert the URL is collection-scoped and
that no `vsrm.dev.azure.com` / `analytics.dev.azure.com` etc. URL ever
goes out from the server adapter.

**Eager-raise pattern at method top:**

```python
async def list_users(
    self, *, workspace=None, page=1, page_size=100,
) -> list[User]:
    caps = await self.get_capabilities()
    if not caps.supports_graph_api:
        raise UnsupportedOnAzureDevOpsServerError(
            "Graph API is not available on this Azure DevOps Server instance "
            "(the optional Graph extension is not installed).",
            capability="supports_graph_api",
            remediation=(
                "Install the Graph extension on Azure DevOps Server "
                "(admin → extensions) to enable /_apis/graph/users."
            ),
            api_version=caps.api_version,
        )
    return [
        User(...)
        async for entry in paginate_via_adoclient_continuation_token(
            self._client,
            "/_apis/graph/users",
            params={"api-version": caps.api_version},
        )
    ]
```

**Remediation strings** for each gated method:

| capability | remediation |
|---|---|
| `supports_user_entitlements` | "Member Entitlements (vsaex) API is cloud-only. On Azure DevOps Server, list users via `list_users()` (Graph API) or query `/_apis/identities` directly." |
| `supports_graph_api` | "The Graph extension is required for `/_apis/graph/users`. On Server 2019+, install the Graph extension via the server administration console (Marketplace → install on collection)." |
| `supports_analytics_odata` | "The Analytics extension is required for `/_odata/v4.0-preview/WorkItems`. Auto-installed on Server 2020+; on Server 2019, install via the server administration console (Marketplace → install on collection)." |
| `supports_artifact_feeds` | "The Package Management extension is required for `/_apis/packaging/feeds`. Install via the server administration console (Marketplace → install on collection)." |

Remediation strings reference "the server administration console" because
the exact navigation path varies by Server release (2019: Server admin →
Extensions; 2020+: Collection settings → Extensions). Discovery-report
consumers can extend the message with deployment-specific paths if needed.

**Behavior deltas from cloud worth flagging in module docstring:**

1. **Graph api-version on Server is probe-resolved.** Cloud's `list_users`
   uses `api-version=7.1-preview.1` because plain `7.1` returns 400 there;
   Server may accept either form depending on the extension build. The
   probe (see `api_version_discovery.py`) tries `<resolved>-preview.1`
   first, falls back to plain `<resolved>` on `400 InvalidApiVersion`,
   and stores the working version on the capability set. The adapter's
   `list_users` reads it back via `caps.api_version` — no per-call probe.
2. The `host=` argument is unused on server: every server-adapter method
   omits it, relying on the default. The single httpx client is collection-scoped.
3. `query_work_item_counts` on Server hits collection-base, project-scoped
   `/{collection}/{project}/_odata/v4.0-preview/WorkItems` (same path
   suffix as cloud, no separate `analytics.*` host).
4. The donor's `compatibility_mode` short-circuited `query_work_item_counts`
   to return zeros and `list_user_entitlements` to return `[]`. We do not
   preserve that. The eager-raise on `supports_analytics_odata=False` /
   `supports_user_entitlements=False` is the correct signal — silently
   zero counts and empty lists mask coverage gaps in discovery reports.

## Data flow

### Construction + connect

```
1. user → ADOServerClient(base_url, collection, auth)         # sync, no HTTP
2. user → async with adapter (or await client.connect())
3. ADOServerClient.connect()
     → resolve_server_api_version(client)
        → GET /_apis/connectionData                           # 1 round-trip
        → [if needed] GET /_apis/projects?$top=1 × N          # 0..4 round-trips
        → asyncio.gather(
             GET /_apis/graph/users?$top=1                    # may retry preview/plain
             GET /_odata/v4.0-preview/$metadata               # may retry collection/project
             GET /_apis/packaging/feeds?$top=1                # single
          )                                                   # 1 wallclock unit
     → returns ServerProbeResult(api_version, capability_overrides, capability_notes)
   client._resolved_api_version = "7.0"
   client._capability_overrides = {"supports_graph_api": False, ...}
   client._capability_notes = ["supports_analytics_odata probe returned 401; ..."]
```

### Per-call

```
adapter.list_users()
  → adapter.get_capabilities()                                # cached
  → check caps.supports_graph_api
  → [if True] paginate_via_adoclient_continuation_token(
        client, "/_apis/graph/users",
        params={"api-version": caps.api_version},   # probe-resolved (preview-aware)
     )
     → client.request("GET", "/_apis/graph/users",
                       params={"api-version": ..., "continuationToken": ...})
       → BaseADOClient.request retry loop
       → httpx.AsyncClient(base_url=collection_base_url).request(...)
  → [if False] raise UnsupportedOnAzureDevOpsServerError(
        ..., capability="supports_graph_api", api_version=caps.api_version,
        remediation="...",
     )
```

## Error handling

| Failure mode | Where it surfaces | Type |
|---|---|---|
| Wrong PAT or insufficient scopes on the **version probe** | `resolve_server_api_version` | `AuthenticationError` (server-flavored remediation) |
| Wrong PAT or insufficient scopes on a **soft-capability probe** | `resolve_server_api_version` | Capability marked `False` + diagnostic line in `capability_notes` (NOT raised — preserves usability) |
| Wrong PAT or insufficient scopes on a **per-call** request | `BaseADOClient.request` | `AuthenticationError` |
| Server reachable, no candidate api-version works | `resolve_server_api_version` | `APIError` (last status + candidate list in message) |
| Network error / DNS / TLS / connectionData timeout | `BaseADOClient.request` after retries exhausted | `APIError` (synthetic `status_code=None`) |
| Rate limit (429) on any probe or per-call request | `BaseADOClient.request` after retries exhausted | `RateLimitError` (with `retry_after`) |
| Capability-gated method called on instance lacking the extension | Adapter method (eager check) | `UnsupportedOnAzureDevOpsServerError` (with `capability`, `remediation`, `api_version`) |
| `client.api_version` accessed before `connect()` | `ADOServerClient.api_version` property | `RuntimeError` ("ADOServerClient is not connected — use `async with` or call `await client.connect()`...") |
| Disallowed override key passed to `with_overrides` (anything other than the 3 soft-cap keys) | `SourceCapabilities.with_overrides` | `ValueError` with the disallowed-keys list |
| `__aenter__` raises during `connect()` (auth, network, etc.) | `ADOServerClient.__aenter__` | Re-raised; the partial client is closed first via `await self.close()` to prevent socket leak |
| `base_url` contains embedded basic auth (`https://user:pass@host/...`) | `_resolve_collection_base_url` (called from `__init__`) | `ConfigError` ("base_url must not contain embedded credentials; use the `auth=` argument") |

Auth errors at the version-probe layer get a server-flavored remediation
message that mentions PAT scopes, collection permissions, and the
`base_url` shape (matching the donor's `_server_auth_error` helper).
Soft-capability auth failures take the diagnostic-note path so a PAT
that lacks `vso.analytics` doesn't crash discovery for projects/repos
that the same PAT IS authorized to read.

## Test coverage

### Unit tests

**`tests/unit/test_client_server.py` (~30 tests)**

```
TestConstruction
  - builds single httpx client at {base_url}/{collection}
  - collection trailing-slash + double-suffix handling (3 cases)
  - embedded basic auth in base_url -> ConfigError
  - Authorization header attached
  - explicit api_version= bypasses VERSION probe (capability probes still run
    on connect() — verified via respx round-trip count)
  - explicit api_version= AND skip-soft-cap-probes path is NOT supported
    (no public knob; soft caps always probe)
  - resolved_api_version is None before connect()
  - api_version property raises RuntimeError before connect() with the
    documented message ("...use `async with` or call `await client.connect()`...")

TestSelectClient
  - all 6 logical hosts route to the same single client (parametrized)
  - close() closes the underlying client exactly once (deduplicated)

TestRequest
  - api-version query param injected from resolved version
  - skip_api_version=True omits the query param
  - 401 / 403 / 429 / 503 / transport-error mapping (smoke per case)

TestConnect
  - calls resolve_server_api_version, caches result
  - idempotent (second connect() is a no-op)
  - __aenter__ runs connect() automatically
  - __aenter__ closes the httpx client when connect() raises (auth fail);
    asserts no leaked open socket via httpx client `is_closed`
  - capability_overrides exposed as MappingProxyType (read-only)
  - capability_notes exposed as a tuple/read-only sequence
```

**`tests/unit/test_client_base.py` (~6 tests, NEW)**

A tiny `_TinyClient(BaseADOClient)` defined inside the test module exercises
the shared retry / rate-limit / error-mapping loop independently of cloud or
server. One place to assert loop semantics so future backends don't have to
re-prove them.

**`tests/unit/test_api_version_discovery.py` (~22 tests)**

```
TestResolveServerApiVersion
  - connectionData success: parametrized over advertised in
    {"7.0","7.1","6.0","5.1","5.0","4.1"} -> snaps to highest <= advertised
  - connectionData payload nests apiVersion under locationServiceData
  - connectionData payload missing apiVersion field entirely -> falls through
  - _parse_version edge cases: "", "7", "7.0.0", "7.x", non-string types,
    None -> all return None and trigger fallthrough (parametrized)
  - candidate iteration: each candidate succeeds first try (4 cases:
    7.0/6.0/5.1/5.0)
  - candidate iteration: all return 400 -> APIError with last status +
    candidate list in message
  - auth error during VERSION probe -> AuthenticationError propagates
    (server-flavored remediation message)
  - probe_strategy field reflects path taken ("connection_data" vs
    "candidate_iteration")

TestProbeSoftCapabilities
  - graph 200 (preview suffix) -> supports_graph_api=True
  - graph 400 InvalidApiVersion on preview, 200 on plain -> True (retry path)
  - graph 404 (both suffix variants) -> supports_graph_api=False
  - graph 401 -> supports_graph_api=False AND capability_notes carries the
    "PAT may lack vso.graph scope" line (NOT raised)
  - analytics collection-scoped 200 -> supports_analytics_odata=True
  - analytics collection-scoped 404, project-scoped 200 -> True (fallback)
  - analytics both variants 404 -> False
  - analytics 401 on either variant -> False + diagnostic note
  - feeds 200 -> supports_artifact_feeds=True
  - feeds 404 -> False
  - feeds 401 -> False + diagnostic note
  - 429 during ANY soft-cap probe -> RateLimitError propagates (not False)
  - 5xx during ANY soft-cap probe -> APIError propagates
  - soft-cap probes run concurrently (assert via asyncio.Event ordering)
```

**`tests/unit/test_adapters_ado_server.py` (~50 tests)**

```
TestConstruction
  - subclasses SourceAdapter (not AzureDevOpsCloudAdapter)
  - server_default capabilities flag set with hard-False user_entitlements
  - __aenter__ runs underlying client.connect() (idempotent — verified via
    respx round-trip count)

TestMethodSetParity
  - public method names on AzureDevOpsServerAdapter == public method names
    on AzureDevOpsCloudAdapter (introspection: dir() filtered to non-dunder
    coroutines minus a documented exception list)
  - signatures match (inspect.signature compare per method)

TestGetCapabilities
  - first call applies probe overrides on top of server_default
  - subsequent calls return cached set
  - api_version reflects resolved version
  - capability_notes from probe carried through to caps.notes

TestVerifyCredentials
  - happy path (3 probes succeed)
  - 401 on first probe -> AuthenticationError with server remediation
  - 403 on repos probe -> AuthenticationError

# One per public method — URL shape + api-version + return type.
# For capability-gated methods, see TestCapabilityGating for the False branch.
TestListProjects, TestGetProjectDetails, TestGetProcessTemplate,
TestListRepositories, TestGetRepository (asserts NotImplementedError parity),
TestCountBranches, TestCountPullRequests,
TestDetectLfsPatterns, TestAnalyzeLargeFiles, TestGetFileContent,
TestListBuildDefinitions, TestGetBuildDefinition,
TestListReleaseDefinitions (asserts collection-scoped, NOT vsrm.dev.azure.com),
TestGetReleaseDefinition, TestListServiceConnections,
TestListVariableGroups, TestListEnvironments,
TestQueryWorkItemCounts_True (collection-base, project-scoped /_odata happy path),
TestGetClassificationNodes, TestGetCustomFieldsCount,
TestListArtifactFeeds_True (collection-scoped happy path),
TestListTestPlans, TestListBranchPolicies, TestListTfvcChangesets,
TestListUsers_True (probe-resolved Graph api-version),
TestGetUser (asserts NotImplementedError parity)

TestCapabilityGating  # dual-branch for each gated method
  - list_users:
      - supports_graph_api=True  -> hits URL, returns User[]
      - supports_graph_api=False -> raises UnsupportedOn...; exception fields
        populated (capability, remediation, api_version)
  - query_work_item_counts:
      - supports_analytics_odata=True  -> hits URL, returns counts dict
      - supports_analytics_odata=False -> raises UnsupportedOn...
  - list_artifact_feeds:
      - supports_artifact_feeds=True  -> hits URL, returns feed list
      - supports_artifact_feeds=False -> raises UnsupportedOn...
  - list_user_entitlements:
      - supports_user_entitlements=False (always) -> raises UnsupportedOn...
        with capability="supports_user_entitlements" and a non-empty
        remediation string

TestPaginationCompatibility  # one per paginator helper, against server adapter
  - paginate_via_adoclient_continuation_token: list_projects round-trip
  - paginate_via_adoclient_skip_top: count_pull_requests round-trip
  - paginate_via_adoclient_body_continuation_token: not exercised by server
    adapter directly (cloud uses it for vsaex which is hard-False on server);
    asserted via a synthetic adapter call instead, confirming the helper
    signature accepts an ADOServerClient

TestLifecycle
  - close() closes the single httpx client; second close() is harmless
  - __aexit__ on adapter delegates to self.close()
```

**Extensions to existing files**

`test_models_source_capabilities.py` (~7 tests):
- `server_default()` returns `AZURE_DEVOPS_SERVER`
- `server_default(api_version="5.1")` -> `compatibility_mode=True` + notes
- `server_default(api_version="5.0")` -> `compatibility_mode=True` + notes
  (Server 2019 RTW)
- `server_default(api_version="6.0")` -> `compatibility_mode=False`
- `server_default()` sets `supports_user_entitlements=False`
- new flags default to `True`
- `with_overrides()` applies whitelisted overrides; raises ValueError on
  any non-whitelisted key (including hard `supports_user_entitlements`)
- `with_overrides(notes=[...])` appends to `caps.notes`

`test_exceptions.py` (~2 tests):
- `UnsupportedOnAzureDevOpsServerError` carries `capability`, required
  `api_version`, optional `remediation`
- subclasses `ADOSourceCoreError`

### Integration tests — `tests/integration/test_smoke_server.py` (5 tests)

Gated on `ADO_SERVER_URL` + `ADO_SERVER_PAT` + (optional)
`ADO_SERVER_COLLECTION` (defaults to `"DefaultCollection"`).

```
test_verify_credentials_succeeds
test_list_projects_returns_iterable
test_list_repositories_for_first_project
test_count_branches_and_prs_for_first_repo
test_list_users_or_assert_unsupported_when_graph_unavailable
   # NOT a skip — drives a contract assertion either way:
   # - if caps.supports_graph_api: assert User[] returned
   # - else: assert UnsupportedOnAzureDevOpsServerError with the
   #         expected capability/remediation fields
```

The cloud and server suites co-exist under the same `integration` marker;
each gates its fixtures on its own env-var set, so
`pytest -m integration` runs whichever has credentials populated. The
marker description in `pyproject.toml` is updated to reflect both env-var
sets:

```toml
markers = [
    "integration: requires ADO_ORG+ADO_PAT (cloud suite) and/or ADO_SERVER_URL+ADO_SERVER_PAT (server suite); hits real ADO API",
]
```

`tests/integration/conftest.py` extensions:

```python
def _env_or_skip(name: str, *, suite: str = "integration") -> str:
    """Skip with a suite-specific reason if env var is missing."""
    value = os.environ.get(name)
    if not value:
        pytest.skip(f"skipping {suite} integration tests: {name} not set")
    return value

@pytest.fixture(scope="session")
def ado_server_url() -> str:
    return _env_or_skip("ADO_SERVER_URL", suite="server")

@pytest.fixture(scope="session")
def ado_server_collection() -> str:
    return os.environ.get("ADO_SERVER_COLLECTION", "DefaultCollection")

@pytest.fixture(scope="session")
def ado_server_pat() -> str:
    return _env_or_skip("ADO_SERVER_PAT", suite="server")

@pytest_asyncio.fixture(scope="session", loop_scope="session")
async def server_client(ado_server_url, ado_server_collection, ado_server_pat):
    async with ADOServerClient(
        base_url=ado_server_url,
        collection=ado_server_collection,
        auth=PATAuth(token=ado_server_pat),
    ) as client:
        yield client
```

The cloud-side `_env_or_skip` calls update to `suite="cloud"` so the
existing skip messages also become suite-specific.

## Documentation deltas

### README.md — new "Cloud vs Server" section (after Quickstart)

- Two-adapter overview.
- Supported Server versions table (2022 / 2020 / 2019 Update 1+ / 2019 RTW →
  REST 7.0 / 6.0 / 5.1 / 5.0).
- TFS 2018 + earlier out of scope for v0.3.0 (revisit on explicit demand).
- Server quickstart code block showing `ADOServerClient` + adapter +
  capability branching + `UnsupportedOnAzureDevOpsServerError` handling.
- **Comprehensive capability matrix** (NOT a deltas-only table). Cloud
  column + Server column + Notes column for every flag in
  `SourceCapabilities`, so a reader sees the full state without having
  to cross-reference. Includes `supports_user_entitlements`,
  `supports_collections`, `compatibility_mode`, `supports_pipelines`,
  `supports_pull_request_threads`, plus the three soft-capability flags.

### CHANGELOG.md — `[Unreleased]` block

```
### Added
- AzureDevOpsServerAdapter — read-side adapter for Azure DevOps Server
  (releases 2022 / 2020 / 2019 Update 1+ / 2019 RTW; REST 7.0 / 6.0 / 5.1 / 5.0).
- ADOServerClient + new BaseADOClient (ADOClient is now an alias for ADOCloudClient).
- api_version_discovery module (connectionData first, candidate iteration fallback).
- UnsupportedOnAzureDevOpsServerError with capability / api_version / remediation.
- SourceCapabilities.server_default(api_version=...) + 3 new flags + with_overrides().

### Changed
- BREAKING (0.x): SourceCapabilities.supports_packages removed in favor of
  supports_artifact_feeds. Migration: rename `caps.supports_packages` reads
  to `caps.supports_artifact_feeds` (functionally equivalent — same boolean
  semantics; renamed for on-prem clarity).
- The transport class hierarchy was reshaped: `ADOClient` is now a
  module-level alias for the renamed `ADOCloudClient` (extracted from a new
  abstract `BaseADOClient`). Existing imports keep working. Reflection-derived
  class names (`type(client).__name__`) now return `"ADOCloudClient"` instead
  of `"ADOClient"` — telemetry, metrics labels, log scrapers, or pickled
  class metadata that key on the old name need to be updated.
```

### Donor attribution headers

Each new file gets a donor citation block + drift notes modeled after
`adapters/source.py`'s pattern (multi-paragraph module docstring with
"Lifted from ...", re-license trail, and a "**Drift from upstream:**"
section enumerating intentional divergences). The exact line count varies
per module — what matters is the structure.

- `client.py` updates the existing module docstring with drift notes for the
  base/cloud/server split.
- `api_version_discovery.py` cites the donor's
  `_probe_supported_api_version` (donor lines 101–119) and lists the
  drift toward connectionData-first + soft-capability probing.
- `adapters/ado_server.py` cites the entire donor module and lists the
  drift toward sibling-not-subclass + eager-raise + structured probe result.

## Drift from donor

Documented in each touched file's module docstring AND in the relevant
commit message. The donor is `n8group-oss/ado2gh-core` @ `160de58`.

1. **Donor `AzureDevOpsServerAdapter` subclasses `AzureDevOpsCloudAdapter`.**
   We do NOT subclass — sibling adapters with shared base for the transport
   only. Reason: the new `ADOClient`/`BaseADOClient` shape diverges from the
   donor's adapter-internal httpx clients. The donor only overrides two
   methods (`query_work_item_counts`, `list_user_entitlements`) plus
   `_request`; the rest inherit transparently because the donor's adapter
   owned its own httpx clients. With transport extracted to a sibling
   `ADOServerClient`, every cloud method's body would need a parallel
   server method anyway (different host strategy, different api-version
   policy), which makes inheritance carry no useful weight. The
   sibling-and-parity-test approach catches the same drift risk that
   inheritance catches by construction.
2. **Donor builds 6 httpx clients all pointing at the same collection URL.**
   We build one. `_select_client(host)` aliases all logical hosts to that
   one client (preserves call-site compatibility for inherited paginators).
3. **Donor's compatibility-mode short-circuits.** `query_work_item_counts`
   returning `{"total": 0, ...}` and `list_user_entitlements` returning
   `[]` are dropped. Replaced with `UnsupportedOnAzureDevOpsServerError`
   raised from a capability gate. Reason: discovery reports must surface
   "what was missed and why," not silently zero out.
4. **Donor probes via candidate iteration only.** We probe `connectionData`
   first; fall back to candidate iteration. Reason: cuts typical
   construction cost from up-to-4 round-trips to 1 when connectionData
   exposes a parseable apiVersion.
5. **Donor returns `string` from probe.** We return `ServerProbeResult`
   (frozen dataclass with `api_version`, `capability_overrides`,
   `capability_notes`, `probe_strategy`). Reason: the soft-capability
   probes need to fan out structured results — overrides for the flag
   set + notes for ambiguity diagnostics (PAT-scope-may-be-missing
   cases) — which is cleaner than mutating adapter state from inside the
   discovery module.
6. **Donor's `_request` reimplements the entire retry/rate-limit/error-map
   loop with materially less coverage.** We instead reuse the existing
   `BaseADOClient.request` extracted from the current cloud client —
   which already had 503 retry, `Retry-After`-aware 429 retry, and
   `_extract_response_body` payload preservation (forward-backported
   from `migration-core` PR #7 in `ado-source-core` PR #13). The drift
   relative to the donor is "preserve and unify existing
   `ado-source-core` transport hardenings under `BaseADOClient`,"
   not "introduce new fixes."
7. **Soft-capability probing is new.** Donor had no equivalent — it
   simply hard-coded `supports_user_entitlements=False` and short-
   circuited `query_work_item_counts`. We add three eager soft-cap
   probes (Graph / Analytics / Package Management) so consumers can
   pre-check via `get_capabilities()`, and the adapter eager-raises
   on the False branch with a typed exception.

Cloud-vs-Server behavior delta (NOT donor drift, but worth flagging):
- `list_users` on cloud uses `api-version=7.1-preview.1` (vssps host);
  on Server, the api-version that works for Graph is probe-resolved
  per-deployment (preview suffix tried first, plain on 400 fallback).
  Both are "correct" — the suffix policy is a Microsoft choice that
  varies between Cloud and Server installations.

## Workflow

The work happens in a fresh worktree at
`.worktrees/server-adapter/` (gitignored) on a fresh branch
`feat/azure-devops-server-adapter`. Commits are pushed after each green
TDD cycle so power-loss never costs more than the in-flight test cycle.
Codex adversarial review ran on this spec (5 parallel chunks) before
implementation; another Codex pass runs after the code is ready but
before final push. Copilot review is requested on the PR as the final
gate before squash-merge.

### Commit sequence

The spec + plan land on `feat/azure-devops-server-adapter` BEFORE the
implementation commits, matching prior PRs in this repo (PR #14, #15):

- **Commit 0a** (already on branch as `fc5e7ab`):
  `docs(spec): Azure DevOps Server adapter + api-version discovery design`
- **Commit 0b** (next, before any code):
  `docs(plan): Azure DevOps Server adapter implementation plan` — produced
  by `superpowers:writing-plans` and committed alongside the spec.

Then 8 implementation commits in one PR:

1. `refactor(transport): extract BaseADOClient; alias ADOClient = ADOCloudClient` (also migrates `pagination.py` type annotations from `ADOClient` to `BaseADOClient`)
2. `feat(transport): add ADOServerClient (single-host, collection-aware, dynamic api-version)`
3. `feat(transport): add api_version_discovery module + wire into ADOServerClient`
4. `feat(exceptions): add UnsupportedOnAzureDevOpsServerError`
5. `feat(models): SourceCapabilities.server_default + new soft-cap flags + with_overrides whitelist; remove supports_packages`
6. `feat(adapter): AzureDevOpsServerAdapter`
7. `test(integration): server smoke suite gated on ADO_SERVER_URL/PAT`
8. `docs: README Cloud vs Server section + CHANGELOG [Unreleased]`

Each implementation commit is independently buildable + green (`ruff
check`, `ruff format --check`, `mypy src`, `pytest -v`).

### PR open vs merge candidate

- **PR can open as draft** with unit-only green (commits 1–6 + 8). The
  integration suite (commit 7) lands in the same PR but its smoke tests
  skip-with-clear-reason when `ADO_SERVER_URL` / `ADO_SERVER_PAT` are not
  set in the runner environment. The unit suite is the gate for opening
  the PR.
- **Merge candidate** requires the server integration suite to have run
  green at least once against a real Server instance (locally or via a
  Codespaces secret). This is the supervisor's call — the PR description
  records the integration result + which Server version was probed.

## Out of scope for v0.3.0

- **NTLM / Negotiate / Windows-integrated auth.** The donor uses PAT-only;
  we keep the same. ADO Server 2019 RTW+ supports PATs via the same
  Basic-with-empty-username scheme as cloud, so `PATAuth` works as-is.
  **PAT support is a hard v0.3.0 deployment prerequisite — Server
  installations with PATs disabled at the org-policy level (or
  NTLM/Negotiate-only deployments behind enterprise SSO) cannot use this
  adapter.** NTLM/Negotiate is a v0.4.0 candidate.
- **TFS 2018 (REST 4.x) and earlier.** The candidate list intentionally
  stops at `5.0`. Out of scope for v0.3.0; reconsider on explicit demand.
  TFS 2018's REST shape is similar in URL form (`{instance}/{collection}/
  _apis/...`) but the api-version contract differs and we have not
  verified the soft-capability probe shapes against 4.x — supporting it
  needs probe testing, not just adding `"4.1"` to the candidate list.
- **The `ado2gh-core` factory rewire** (cloud-or-server selection at the
  consumer level). That's `ado2gh-core` work; this PR only ships the
  building blocks.
- **`get_repository` and `get_user`** — neither is implemented on the cloud
  adapter (both raise `NotImplementedError`). Server matches.
- **Degraded `list_user_entitlements` via `/_apis/identities`.** The
  v0.3.0 server adapter raises `UnsupportedOnAzureDevOpsServerError`
  because the vsaex Member Entitlements API is cloud-only. Implementing
  a degraded fallback that returns identity-shaped data would change the
  return contract (`list[dict[str, Any]]` shape would diverge from cloud's
  user-entitlement shape) and is deferred to v0.4.0. v0.3.0 consumers
  needing user-discovery data on Server should call `list_users()`
  (Graph API) when `supports_graph_api=True`, or call `/_apis/identities`
  directly through the underlying client.
- **`structlog` dependency removal.** The `structlog>=24,<26` runtime
  dependency in `pyproject.toml` is unused after this PR (donor used it;
  `ado-source-core` modules all use stdlib `logging`). Removal is a
  separate small PR for v0.4.0.

## Open questions and dependencies

- **Need an ADO Server instance URL + PAT for integration tests.** The
  user does not yet have one provisioned for this project. Per the
  workflow above: the PR opens as draft with unit-only green; merge
  candidacy requires the server integration suite to run green at least
  once against a real Server instance.
- **Sibling agents A4 (`ado2gh-core` rewire) and A5 (`ado-scanner`
  bootstrap) work in different repos.** The only file with potential
  collision is `src/ado_source_core/__init__.py`'s `__all__` list, which
  is alphabetical — whichever PR lands second rebases trivially.
