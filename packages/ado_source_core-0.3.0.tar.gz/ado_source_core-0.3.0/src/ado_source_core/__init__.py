"""Package initialization for ado_source_core.

Exposes version metadata, the ``SourceAdapter`` abstract base class plus
the concrete ``AzureDevOpsCloudAdapter`` for the read-side core, the
read-side Pydantic models, the exception hierarchy, the ``PATAuth``
helper plus the ``ADOCredentialSettings`` Pydantic Settings model and
the ``resolve_ado_credentials`` data-layer helper, the pagination
iterators, and the core ``ADOClient`` HTTP transport.
"""

from ado_source_core.adapters import (
    AzureDevOpsCloudAdapter,
    AzureDevOpsServerAdapter,
    SourceAdapter,
)
from ado_source_core.api_version_discovery import (
    SERVER_API_VERSION_CANDIDATES,
    ServerProbeResult,
    resolve_server_api_version,
)
from ado_source_core.auth import (
    DEFAULT_ADO_BASE_URL,
    ADOCredentialSettings,
    PATAuth,
    parse_env_file,
    resolve_ado_credentials,
)
from ado_source_core.client import ADOClient, ADOCloudClient, ADOServerClient, BaseADOClient
from ado_source_core.exceptions import (
    ADOSourceCoreError,
    APIError,
    AuthenticationError,
    ConfigError,
    ExitCode,
    RateLimitError,
    UnsupportedOnAzureDevOpsServerError,
)
from ado_source_core.models import (
    ArtifactFeedInventoryItem,
    BoardSummary,
    ComplexityLevel,
    ComplexityScore,
    Inventory,
    InventoryMetadata,
    InventorySummary,
    LargeFileInfo,
    LFSInfo,
    PipelineAnalysis,
    PipelineInventoryItem,
    PipelineMigrationComplexity,
    PipelineStepInfo,
    PipelineType,
    ProjectInventoryItem,
    Repository,
    RepositoryInventoryItem,
    SourceCapabilities,
    SourceType,
    TaskSupportLevel,
    TestPlanInventoryItem,
    TfvcSummary,
    User,
    UserEntitlementSummary,
)
from ado_source_core.pagination import (
    paginate_continuation_token,
    paginate_skip_top,
    paginate_via_adoclient_body_continuation_token,
    paginate_via_adoclient_continuation_token,
    paginate_via_adoclient_skip_top,
)

__all__ = [
    "DEFAULT_ADO_BASE_URL",
    "SERVER_API_VERSION_CANDIDATES",
    "ADOClient",
    "ADOCloudClient",
    "ADOCredentialSettings",
    "ADOServerClient",
    "ADOSourceCoreError",
    "APIError",
    "ArtifactFeedInventoryItem",
    "AuthenticationError",
    "AzureDevOpsCloudAdapter",
    "AzureDevOpsServerAdapter",
    "BaseADOClient",
    "BoardSummary",
    "ComplexityLevel",
    "ComplexityScore",
    "ConfigError",
    "ExitCode",
    "Inventory",
    "InventoryMetadata",
    "InventorySummary",
    "LFSInfo",
    "LargeFileInfo",
    "PATAuth",
    "PipelineAnalysis",
    "PipelineInventoryItem",
    "PipelineMigrationComplexity",
    "PipelineStepInfo",
    "PipelineType",
    "ProjectInventoryItem",
    "RateLimitError",
    "Repository",
    "RepositoryInventoryItem",
    "ServerProbeResult",
    "SourceAdapter",
    "SourceCapabilities",
    "SourceType",
    "TaskSupportLevel",
    "TestPlanInventoryItem",
    "TfvcSummary",
    "UnsupportedOnAzureDevOpsServerError",
    "User",
    "UserEntitlementSummary",
    "__version__",
    "paginate_continuation_token",
    "paginate_skip_top",
    "paginate_via_adoclient_body_continuation_token",
    "paginate_via_adoclient_continuation_token",
    "paginate_via_adoclient_skip_top",
    "parse_env_file",
    "resolve_ado_credentials",
    "resolve_server_api_version",
]

try:
    from ado_source_core._version import __version__
except ModuleNotFoundError as exc:
    if exc.name == "ado_source_core._version":
        __version__ = "0.0.0+unknown"
    else:
        raise
