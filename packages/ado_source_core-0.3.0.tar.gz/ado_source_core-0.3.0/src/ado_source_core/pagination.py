"""Pagination iterators for Azure DevOps REST endpoints.

Per Stage 1 sub-stage 1.1 task 1.1.8 of the Shyftport pilot extraction
(``shyftport-specs:plans/2026-04-27-stage-1-pilot-extraction.md``).

ADO uses several pagination strategies depending on the endpoint (per
``ado2gh-core/CLAUDE.md``):

- **Continuation token** (header ``x-ms-continuationtoken``): used by
  Projects, Refs/branches, Build/Release definitions, Variable groups,
  Environments. The header carries either an integer or string token;
  ``paginate_continuation_token`` forwards whatever value comes back as
  the ``continuationToken`` query parameter on the next request.
- ``$skip`` / ``$top`` (numeric offset + page size as query params):
  used by Pull requests, TFVC changesets. Implemented by
  ``paginate_skip_top``.
- **No pagination**: a few endpoints (e.g., Service connections) return
  the full result set in one call. Callers use ``client.get(url)``
  directly — no helper here.

This module contains two families of iterators:

- **Thin httpx-based** (``paginate_continuation_token``,
  ``paginate_skip_top``): delegate directly to a raw
  ``httpx.AsyncClient`` and raise bare ``httpx.HTTPStatusError`` from
  ``raise_for_status`` so callers can wrap or replace as needed. No
  retries, no rate-limit handling, no structured exceptions.
- **ADOClient-aware** (``paginate_via_adoclient_continuation_token``,
  ``paginate_via_adoclient_skip_top``,
  ``paginate_via_adoclient_body_continuation_token``): delegate to
  ``BaseADOClient.request`` so retries, rate-limit handling, and the
  structured ``ADOSourceCoreError`` hierarchy apply uniformly across
  page boundaries.
"""

from __future__ import annotations

from collections.abc import AsyncIterator, Mapping, Sequence
from typing import TYPE_CHECKING, Any

import httpx

if TYPE_CHECKING:
    from ado_source_core.client import BaseADOClient, HostName


async def paginate_continuation_token(
    client: httpx.AsyncClient,
    url: str,
    *,
    params: Mapping[str, Any] | None = None,
    headers: Mapping[str, str] | None = None,
) -> AsyncIterator[dict[str, Any]]:
    """Yield items across pages using the ``x-ms-continuationtoken`` header.

    Each page's response body is expected to carry a ``"value"`` array.
    When the response includes an ``x-ms-continuationtoken`` header, its
    value is added to the query params as ``continuationToken`` for the
    next request. The iterator terminates when the header is absent or
    empty.
    """
    current_params: dict[str, Any] = dict(params or {})
    request_headers = dict(headers or {})
    while True:
        response = await client.get(url, params=current_params, headers=request_headers)
        response.raise_for_status()
        body = response.json()
        for item in body.get("value", []):
            yield item

        token = response.headers.get("x-ms-continuationtoken")
        if not token:
            return
        current_params["continuationToken"] = token


async def paginate_skip_top(
    client: httpx.AsyncClient,
    url: str,
    *,
    params: Mapping[str, Any] | None = None,
    headers: Mapping[str, str] | None = None,
    page_size: int = 100,
) -> AsyncIterator[dict[str, Any]]:
    """Yield items across pages using ``$skip`` and ``$top`` query params.

    Increments ``$skip`` by ``page_size`` after each full page. Terminates
    when a page comes back empty or shorter than ``page_size`` (avoiding
    one wasted "is there more?" request that always returns empty).
    """
    skip = 0
    request_headers = dict(headers or {})
    while True:
        current_params: dict[str, Any] = {
            **(params or {}),
            "$skip": skip,
            "$top": page_size,
        }
        response = await client.get(url, params=current_params, headers=request_headers)
        response.raise_for_status()
        body = response.json()
        items = body.get("value", [])
        if not items:
            return
        for item in items:
            yield item
        if len(items) < page_size:
            return
        skip += page_size


async def paginate_via_adoclient_continuation_token(
    client: BaseADOClient,
    path: str,
    *,
    host: HostName = "dev",
    params: Mapping[str, Any] | None = None,
) -> AsyncIterator[dict[str, Any]]:
    """Yield items from response['value'] across pages using the
    'x-ms-continuationtoken' response header, dispatched via
    ``BaseADOClient.request`` so retry / rate-limit / error-mapping is
    preserved.

    Used by the majority of paginated ADO endpoints (Projects, Refs,
    Build/Release definitions, Variable groups, Environments, Test
    plans, Branch policies, Graph users)."""
    current_params: dict[str, Any] = dict(params or {})
    while True:
        response = await client.request("GET", path, host=host, params=current_params)
        body = response.json()
        for item in body.get("value", []):
            yield item

        token = response.headers.get("x-ms-continuationtoken")
        if not token:
            return
        current_params["continuationToken"] = token


async def paginate_via_adoclient_skip_top(
    client: BaseADOClient,
    path: str,
    *,
    host: HostName = "dev",
    params: Mapping[str, Any] | None = None,
    page_size: int = 100,
) -> AsyncIterator[dict[str, Any]]:
    """Yield items from response['value'] across pages using $skip /
    $top query parameters, dispatched via ``BaseADOClient.request`` so
    retry / rate-limit / error-mapping is preserved.

    Used by Pull requests and TFVC changesets — endpoints that honor
    the requested $top up to 100. If a future endpoint silently caps
    below page_size, prefer a continuation-token variant; this helper
    treats a short page as "no more pages"."""
    skip = 0
    while True:
        page_params: dict[str, Any] = {
            **(params or {}),
            "$skip": skip,
            "$top": page_size,
        }
        response = await client.request("GET", path, host=host, params=page_params)
        body = response.json()
        items = body.get("value", [])
        if not items:
            return
        for item in items:
            yield item
        if len(items) < page_size:
            return
        skip += page_size


async def paginate_via_adoclient_body_continuation_token(
    client: BaseADOClient,
    path: str,
    *,
    host: HostName = "dev",
    params: Mapping[str, Any] | None = None,
    items_key: str | Sequence[str] = "items",
) -> AsyncIterator[dict[str, Any]]:
    """Yield items from response[items_key] across pages using
    response['continuationToken'] in the response BODY (not the
    header), dispatched via ``BaseADOClient.request``.

    Specific to the Member Entitlements API
    (`/_apis/userentitlements`). Items live under 'items', not
    'value', and the continuation token comes from the body.

    `items_key` accepts a single string for the common case and a
    sequence of strings to express a fallback chain — the helper
    returns items from the first key present in the response. Member
    Entitlements is called with `items_key=("items", "members")` to
    preserve the donor's tolerance for an older `members` response
    shape."""
    keys: tuple[str, ...] = (items_key,) if isinstance(items_key, str) else tuple(items_key)
    current_params: dict[str, Any] = dict(params or {})
    while True:
        response = await client.request("GET", path, host=host, params=current_params)
        body = response.json()

        items: list[dict[str, Any]] = []
        for key in keys:
            if key in body:
                items = body[key] or []
                break
        for item in items:
            yield item

        token = body.get("continuationToken")
        if not token:
            return
        current_params["continuationToken"] = token
