"""Authentication helpers for the Azure DevOps API.

Exposes:

- :class:`PATAuth` — attaches a Personal Access Token to outbound HTTP
  requests via Basic auth.
- :class:`ADOCredentialSettings` — Pydantic Settings model for loading
  Azure DevOps credentials (PAT + organization) from environment variables
  with ``ADO_*`` (primary) and ``ADO2GH_*`` (fallback) alias precedence.
- :func:`parse_env_file` — manual ``.env`` parser. Bypasses
  ``python-dotenv`` and pydantic-settings' built-in loader because both
  silently corrupt values inside PyInstaller one-file binaries on macOS.
- :func:`resolve_ado_credentials` — generic data-layer credential resolver
  combining ``os.environ`` and ``.env`` with the documented precedence
  rules. Returns a ``dict[str, str]`` with keys ``"pat"`` and
  ``"organization"``.

Lifted from ``ado2gh-core`` @ ``160de58`` per audit §3.B + §3.D
(``shyftport-specs/plans/audit/extraction-plan.md``). Drift from donor:

- Dropped ``prefer_scanner_aliases`` parameter and the ``_SCANNER_*`` /
  ``_*_FALLBACK_KEYS`` constants — that scanner-flavored UX layer
  relocates to ``ado-scanner`` per audit §3.D.
- Slimmed the diagnostic ``logger.debug`` call at the end of
  ``resolve_ado_credentials`` — the donor block referenced
  scanner-flavored alias variables that no longer exist.
- Narrowed the ``parse_env_file`` exception catch from bare ``Exception``
  to ``(OSError, UnicodeDecodeError)``. The donor's bare-Exception catch
  was deliberately tolerant of malformed ``.env`` files (corrupted bytes
  on PyInstaller bundles, mis-encoded files); surfacing that as a hard
  error would break credential resolution for users whose ``.env`` is
  bad — preserving tolerant fallback is the right call.
- Reworded the org-missing ``ConfigError`` from "use --organization flag"
  to "pass an explicit organization argument". This is a library, not a
  CLI; the wording reflects the lifted call shape.
"""

from __future__ import annotations

import base64
import logging
import os
import sys
from dataclasses import dataclass
from pathlib import Path

from pydantic import AliasChoices, Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict

from ado_source_core.exceptions import ConfigError

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class PATAuth:
    """Personal Access Token authentication for Azure DevOps.

    ADO accepts PATs as HTTP Basic auth with an empty username. The
    ``Authorization`` header carries ``Basic <encoded>`` where
    ``<encoded>`` is ``base64.b64encode(f":{token}".encode())``.
    Concretely, with ``token="my-pat"`` the encoded payload is the
    literal four-byte string ``":my-pat"`` run through standard
    base64, yielding::

        Authorization: Basic Om15LXBhdA==

    The frozen dataclass + ``__repr__`` override prevent accidental
    credential leakage through ``repr(auth)`` / ``str(auth)`` /
    ``f"{auth}"`` / log lines.
    """

    token: str

    def headers(self) -> dict[str, str]:
        """Return the auth header(s) to attach to outbound requests."""
        encoded = base64.b64encode(f":{self.token}".encode()).decode()
        return {"Authorization": f"Basic {encoded}"}

    def __repr__(self) -> str:
        return "PATAuth(token=<redacted>)"

    def __str__(self) -> str:
        return self.__repr__()


# Donor: ado2gh-core @ 160de58 — src/ado2gh/models/config.py (ADO half)
# and src/ado2gh/cli/credential_resolver.py (data-layer half). Re-licensed
# MIT; sole-authorship verified per the audit at shyftport-specs.
SETTINGS_CONFIG = SettingsConfigDict(
    env_file=".env",
    env_file_encoding="utf-8",
    populate_by_name=True,
)
DEFAULT_ADO_BASE_URL = "https://dev.azure.com"


class ADOCredentialSettings(BaseSettings):
    """Minimal settings for Azure DevOps credential lookup.

    Loads from environment variables and from a ``.env`` file in the
    current working directory (per ``SETTINGS_CONFIG`` — pydantic-settings'
    built-in ``DotEnvSettingsSource``). Each field accepts both the
    primary ``ADO_*`` name and the namespaced ``ADO2GH_*`` alias.
    Sensitive fields use ``SecretStr`` so they mask in ``repr`` / ``str``.

    .. warning::
        On macOS PyInstaller one-file binaries, pydantic-settings'
        ``DotEnvSettingsSource`` silently corrupts ``.env`` values (same
        bug as ``python-dotenv``). Frozen apps should use
        :func:`resolve_ado_credentials` instead, which parses ``.env``
        manually and is PyInstaller-safe.
    """

    model_config = SETTINGS_CONFIG

    ado_pat: SecretStr | None = Field(
        default=None,
        description="Azure DevOps Personal Access Token",
        validation_alias=AliasChoices("ADO_PAT", "ADO2GH_PAT"),
    )
    ado_organization: str | None = Field(
        default=None,
        description="Azure DevOps organization name",
        validation_alias=AliasChoices("ADO_ORGANIZATION", "ADO2GH_ORGANIZATION"),
    )


# Characters to strip from .env values — straight quotes, curly/smart quotes,
# backticks, whitespace. macOS text editors (TextEdit, Notes) and some
# terminals auto-replace straight quotes with curly variants, which
# python-dotenv does NOT strip, corrupting PATs and org names.
_STRIP_CHARS = "\"'`“”‘’ \t\n\r"  # noqa: RUF001 - intentional smart-quote chars to strip

_PAT_ENV_KEYS = ("ADO_PAT", "ADO2GH_PAT")
_ORG_ENV_KEYS = ("ADO_ORGANIZATION", "ADO2GH_ORGANIZATION")


def _clean_env_value(value: str) -> str:
    """Strip quotes, smart quotes, backticks, and whitespace from a value."""
    return value.strip(_STRIP_CHARS)


def _mask(value: str) -> str:
    """Return first 4 + last 4 chars with middle masked, for safe logging."""
    if len(value) <= 8:  # noqa: PLR2004 - donor mask threshold (first 4 + last 4)
        return "***"
    return f"{value[:4]}...{value[-4:]}"


def _is_frozen() -> bool:
    """Return True when running inside a PyInstaller bundle."""
    return getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS")


def parse_env_file(env_path: Path) -> dict[str, str]:
    """Parse a .env file into a dict of key=value pairs.

    Handles:

    - ``KEY=VALUE`` (plain)
    - ``KEY="VALUE"`` and ``KEY='VALUE'`` (quoted, quotes stripped)
    - Comments (lines starting with ``#``)
    - Blank lines
    - ``export KEY=VALUE`` prefix (``export`` stripped)

    This parser intentionally does NOT depend on ``python-dotenv`` because
    ``python-dotenv`` corrupts values inside PyInstaller one-file bundles.
    A missing or unreadable file returns ``{}`` (debug-logged).
    """
    result: dict[str, str] = {}
    try:
        content = env_path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        logger.debug("failed to read %s", env_path, exc_info=True)
        return result

    for raw_line in content.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:]
        if "=" not in line:
            continue
        key, _, val = line.partition("=")
        key = key.strip()
        if not key:
            continue
        val = val.strip()
        if len(val) >= 2 and (  # noqa: PLR2004 - quote-pair stripping needs ≥2 chars
            (val[0] == "'" and val[-1] == "'") or (val[0] == '"' and val[-1] == '"')
        ):
            val = val[1:-1]
        result[key] = val

    return result


def _resolve_generic_env_value(
    keys: tuple[str, ...], env_file_values: dict[str, str]
) -> str | None:
    """Preserve env-over-.env precedence across generic alias families.

    When running under PyInstaller (``_is_frozen``) the precedence flips —
    the bundled ``.env`` is preferred because PyInstaller's environment
    propagation is unreliable on macOS.
    """
    if _is_frozen():
        for key in keys:
            if key in env_file_values:
                return env_file_values[key]

    for key in keys:
        if key in os.environ:
            return os.environ[key]

    for key in keys:
        if key in env_file_values:
            return env_file_values[key]

    return None


def _resolve_env_preferred_value(  # noqa: PLR0911 - donor's PyInstaller-aware precedence ladder
    primary_keys: tuple[str, ...],
    fallback_keys: tuple[str, ...],
    env_file_values: dict[str, str],
) -> str | None:
    """Prefer primary keys globally, then env-over-.env for fallback keys.

    Currently unused by :func:`resolve_ado_credentials` (which is
    generic-only after audit §3.D dropped the scanner-alias UX); kept as
    part of the cohesive data-layer toolkit so downstream wrappers can
    compose with it.
    """
    if _is_frozen():
        for key in primary_keys:
            if key in env_file_values:
                return env_file_values[key]
        for key in fallback_keys:
            if key in env_file_values:
                return env_file_values[key]

    for key in primary_keys:
        if key in os.environ:
            return os.environ[key]
        if key in env_file_values:
            return env_file_values[key]

    for key in fallback_keys:
        if key in os.environ:
            return os.environ[key]

    for key in fallback_keys:
        if key in env_file_values:
            return env_file_values[key]

    return None


def resolve_ado_credentials(*, organization: str | None = None) -> dict[str, str]:
    """Resolve Azure DevOps credentials from environment and .env file.

    Parses ``.env`` directly and combines it with ``os.environ`` using the
    documented precedence rules (env-over-.env, except under PyInstaller).
    Recognises both ``ADO_*`` (primary) and ``ADO2GH_*`` (fallback) alias
    families.

    Drift from donor (``ado2gh-core@160de58``): the
    ``prefer_scanner_aliases`` parameter and the ``_SCANNER_*`` constants
    were dropped per audit §3.D — scanner-flavored UX moves to
    ``ado-scanner``'s wrapper layer.

    Args:
        organization: When provided, overrides any environment-supplied
            organization value. Useful for CLI ``--organization`` flags.

    Returns:
        ``{"pat": ..., "organization": ...}``.

    Raises:
        ConfigError: If ``pat`` or ``organization`` cannot be resolved, or
            if the PAT contains non-ASCII characters (a strong signal of
            copy-paste corruption from a smart-quote-substituting editor).
    """
    env_path = Path(".env")
    env_file_raw = parse_env_file(env_path) if env_path.is_file() else {}
    env_loaded = bool(env_file_raw)

    raw_pat = _resolve_generic_env_value(_PAT_ENV_KEYS, env_file_raw)
    pat = _clean_env_value(raw_pat) if raw_pat else None
    if not pat:
        raise ConfigError(
            "Azure DevOps PAT not found.\n"
            "  Set ADO_PAT or ADO2GH_PAT in the environment or .env file.\n"
            "  Required scopes: vso.project, vso.code, vso.build, vso.release,\n"
            "  vso.work, vso.packaging, vso.test, vso.serviceendpoint_query,\n"
            "  vso.graph, vso.memberentitlementmanagement, vso.analytics, vso.profile",
            field="ADO_PAT",
        )

    if not pat.isascii():
        raise ConfigError(
            "ADO_PAT contains non-ASCII characters (possible copy-paste corruption).\n"
            "  Open your .env file in a plain-text editor and ensure the PAT value\n"
            "  has no curly/smart quotes or other special characters.",
            field="ADO_PAT",
        )

    raw_org: str | None
    if organization is not None:
        raw_org = organization
    else:
        raw_org = _resolve_generic_env_value(_ORG_ENV_KEYS, env_file_raw)
    org = _clean_env_value(raw_org) if raw_org else None
    if not org:
        raise ConfigError(
            "Azure DevOps organization not found.\n"
            "  Set ADO_ORGANIZATION or ADO2GH_ORGANIZATION in the environment\n"
            "  or .env file, or pass an explicit organization argument.",
            field="ADO_ORGANIZATION",
        )

    env_has_pat = any(key in os.environ for key in _PAT_ENV_KEYS)
    raw_file_pat = next(
        (env_file_raw[key] for key in _PAT_ENV_KEYS if key in env_file_raw),
        None,
    )
    raw_file_org = next(
        (env_file_raw[key] for key in _ORG_ENV_KEYS if key in env_file_raw),
        None,
    )

    logger.debug(
        "credentials resolved: frozen=%s, env_loaded=%s, env_var_set=%s, "
        "env_file_exists=%s, pat_len=%d, pat_preview=%s, "
        "file_raw_pat_len=%s, file_raw_pat_preview=%s, "
        "pat_matches_file=%s, file_raw_org=%s, org=%s, cwd=%s",
        _is_frozen(),
        env_loaded,
        env_has_pat,
        env_path.is_file(),
        len(pat),
        _mask(pat),
        len(raw_file_pat) if raw_file_pat else "N/A",
        _mask(raw_file_pat) if raw_file_pat else "N/A",
        pat == raw_file_pat if raw_file_pat else "N/A",
        raw_file_org,
        org,
        os.getcwd(),
    )

    return {"pat": pat, "organization": org}
