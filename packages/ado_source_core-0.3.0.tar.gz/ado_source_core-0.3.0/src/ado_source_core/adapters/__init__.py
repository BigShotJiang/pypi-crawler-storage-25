"""Source-system adapter abstractions and concrete implementations."""

from ado_source_core.adapters.ado_cloud import AzureDevOpsCloudAdapter
from ado_source_core.adapters.ado_server import AzureDevOpsServerAdapter
from ado_source_core.adapters.source import SourceAdapter

__all__ = ["AzureDevOpsCloudAdapter", "AzureDevOpsServerAdapter", "SourceAdapter"]
