"""SourceAdapter abstract base class for source-system API clients.

Vendored from `n8group-oss/migration-core` (BUSL-1.1) at commit
`fa225aa412f5cea68defd1d73ae1476d3210da78`, source path
`src/migration_core/adapters/base.py`. The class was originally introduced
in commit `91331a5 — feat: extract shared GitHub adapters and identity
clients`.

Re-licensed under MIT for inclusion in `ado-source-core` with the consent
of all original commit authors. The audit at `n8group-oss/shyftport-specs`
verified sole authorship (Marcin Noczynski) on both
`src/migration_core/adapters/base.py` and `src/migration_core/exceptions.py`
at vendoring time. The decision rationale is recorded at
`shyftport-specs/plans/audit/migration-core-base-decision.md`. Drift
re-check cadence: quarterly, per the audit's §6.

Only `SourceAdapter` was vendored from migration-core's `base.py`;
migration-core's `TargetAdapter` stays in `migration-core` per the audit.

**Drift from upstream:** the class body is preserved as-is from
migration-core except for three minor type-annotation tightenings applied
during vendoring to keep the file clean under mypy strict and to preserve
concrete-subclass typing through the async context manager:

1. `__aenter__` returns `Self` (from `typing`) instead of
   `SourceAdapter[R, U]` so `async with` callers retain the concrete
   adapter type.
2. `__aexit__`'s `exc_tb` is typed `TracebackType | None` (from `types`)
   instead of `Any`.
3. The class docstring's "10-method contract" wording is clarified to
   note the count is the explicit API surface (5 abstract + 5 default)
   and excludes the dunder context-manager methods.

These improvements should be backported to `migration-core` to keep the
quarterly re-vendor diff small (tracked as a follow-up).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from types import TracebackType
from typing import Any, Generic, Self, TypeVar

R = TypeVar("R")
U = TypeVar("U")


class SourceAdapter(ABC, Generic[R, U]):
    """Abstract base class for source system adapters.

    The explicit API surface is a 10-method contract — 5 abstract methods
    and 5 non-abstract defaults that raise `NotImplementedError`. The class
    additionally implements `__aenter__` / `__aexit__` so subclasses are
    usable as async context managers without re-implementing the protocol.

    Products extend with platform-specific methods:
    - ADOSourceAdapter adds list_projects, list_build_definitions, etc.
    - BitbucketSourceAdapter adds get_branch_protection, get_pipeline_config, etc.
    - Future GitLabSourceAdapter adds GitLab-specific methods.
    """

    @abstractmethod
    async def list_repositories(
        self,
        *,
        workspace: str | None = None,
        project: str | None = None,
        page: int = 1,
        page_size: int = 100,
    ) -> list[R]:
        """List repositories from the source system."""
        ...

    @abstractmethod
    async def get_repository(self, repo_id: str) -> R | None:
        """Get a single repository by ID or full name."""
        ...

    @abstractmethod
    async def list_users(
        self,
        *,
        workspace: str | None = None,
        page: int = 1,
        page_size: int = 100,
    ) -> list[U]:
        """List users from the source system."""
        ...

    @abstractmethod
    async def get_user(self, user_id: str) -> U | None:
        """Get a single user by ID or username."""
        ...

    @abstractmethod
    async def close(self) -> None:
        """Close connections and release resources."""
        ...

    async def __aenter__(self) -> Self:
        """Async context manager entry."""
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Async context manager exit - closes connections."""
        await self.close()

    async def verify_credentials(self) -> bool:
        """Verify that credentials are valid."""
        raise NotImplementedError("verify_credentials not implemented")

    async def count_branches(self, repo_id: str) -> int:
        """Count branches in a repository."""
        raise NotImplementedError("count_branches not implemented")

    async def count_pull_requests(
        self,
        repo_id: str,
        *,
        state: str | None = None,
    ) -> int:
        """Count pull requests in a repository."""
        raise NotImplementedError("count_pull_requests not implemented")

    async def analyze_large_files(
        self,
        repo_id: str,
        *,
        branch: str | None = None,
        threshold_bytes: int = 100_000_000,
    ) -> Any:
        """Analyze repository for large files."""
        raise NotImplementedError("analyze_large_files not implemented")

    async def detect_lfs_patterns(
        self,
        repo_id: str,
        *,
        branch: str | None = None,
    ) -> Any:
        """Detect LFS configuration from .gitattributes."""
        raise NotImplementedError("detect_lfs_patterns not implemented")
