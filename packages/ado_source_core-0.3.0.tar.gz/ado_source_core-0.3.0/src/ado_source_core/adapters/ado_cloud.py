"""Concrete Azure DevOps Cloud adapter.

Lifted from ``n8group-oss/ado2gh-core/src/ado2gh/adapters/ado_cloud.py`` @
``160de58`` per Stage 1 sub-stage 1.1 task 1.1.9 PART B of the Shyftport
pilot extraction (``shyftport-specs:plans/2026-04-27-stage-1-pilot-extraction.md``).

Lifts the entire read-side surface of the donor adapter:

- **Project / repository / branch / PR / LFS / file-content** methods —
  PR-B1 (#9).
- **Pipelines / project resources / users / entitlements / TFVC** —
  this PR (PR-B2).

Architecture differences vs the donor:

- Constructor takes a pre-built :class:`ADOClient` instead of constructing
  6 ``httpx.AsyncClient`` instances internally. The transport concerns
  (auth, retry, rate-limit, error mapping) live on ``ADOClient``.
- Donor's ``await self._request("GET", url, params=...)`` becomes
  ``await self._client.request("GET", url, params=...)``. Donor's
  ``client=self._vsrm_client`` (etc.) becomes ``host="vsrm"``.
- Subclasses :class:`SourceAdapter[Repository, User]` directly. The
  donor's intermediate ``ADOSourceAdapter`` abstract base (that adds
  ADO-specific abstract methods on top of ``SourceAdapter``) is not
  lifted as a separate class; if a future caller needs the abstract
  contract, it can land then.
"""

from __future__ import annotations

from http import HTTPStatus
from typing import TYPE_CHECKING, Any, Self

from ado_source_core.adapters.source import SourceAdapter
from ado_source_core.exceptions import APIError, AuthenticationError
from ado_source_core.models.repository import Repository
from ado_source_core.models.source_capabilities import SourceCapabilities
from ado_source_core.models.user import User
from ado_source_core.pagination import (
    paginate_via_adoclient_body_continuation_token,
    paginate_via_adoclient_continuation_token,
    paginate_via_adoclient_skip_top,
)

if TYPE_CHECKING:
    from types import TracebackType

    from ado_source_core.client import ADOClient


class AzureDevOpsCloudAdapter(SourceAdapter[Repository, User]):
    """Concrete read-side adapter for Azure DevOps Services (cloud).

    Composes :class:`ADOClient` for HTTP transport. Every method on this
    class translates a typed call into one or more REST requests, parses
    the JSON response, and returns either a Pydantic model or a typed
    Python value.
    """

    def __init__(
        self,
        *,
        client: ADOClient,
        capabilities: SourceCapabilities | None = None,
    ) -> None:
        self._client = client
        self._capabilities = capabilities or SourceCapabilities.cloud_default()

    @property
    def client(self) -> ADOClient:
        """The underlying transport client (rare; callers usually shouldn't reach in)."""
        return self._client

    async def get_capabilities(self) -> SourceCapabilities:
        """Return the static Azure DevOps Services capability set."""
        return self._capabilities

    # --- Authentication probe ---

    async def verify_credentials(self) -> bool:
        """Verify PAT by probing projects, repos, and builds scopes."""
        try:
            projects_resp = await self._client.request(
                "GET",
                "/_apis/projects",
                params={"$top": "1"},
            )
            projects = projects_resp.json().get("value", [])
            if projects:
                project_name = projects[0]["name"]
                await self._client.request(
                    "GET",
                    f"/{project_name}/_apis/git/repositories",
                )
                await self._client.request(
                    "GET",
                    f"/{project_name}/_apis/build/definitions",
                    params={"$top": "1"},
                )
        except AuthenticationError as exc:
            raise AuthenticationError(
                "PAT lacks required read scopes for discovery.\n"
                "  Required scopes: vso.project, vso.code, vso.build, vso.release,\n"
                "  vso.work, vso.packaging, vso.test, vso.serviceendpoint_query,\n"
                "  vso.analytics, vso.profile",
                status_code=exc.status_code,
            ) from exc
        return True

    # --- Project methods ---

    async def list_projects(
        self,
        *,
        state_filter: str = "wellFormed",
    ) -> list[dict[str, Any]]:
        """List all projects. Pagination: integer continuation token."""
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client,
                "/_apis/projects",
                params={"stateFilter": state_filter, "$top": "100"},
            )
        ]

    async def get_project_details(self, project_id: str) -> dict[str, Any]:
        """Get a single project with capabilities (VCS type, process template)."""
        response = await self._client.request(
            "GET",
            f"/_apis/projects/{project_id}",
            params={"includeCapabilities": "true"},
        )
        result: dict[str, Any] = response.json()
        return result

    async def get_process_template(self, process_type_id: str) -> dict[str, Any]:
        """Get process template details by ``processTypeId``."""
        response = await self._client.request(
            "GET",
            f"/_apis/work/processes/{process_type_id}",
        )
        result: dict[str, Any] = response.json()
        return result

    # --- Repository methods ---

    async def list_repositories(
        self,
        *,
        workspace: str | None = None,
        project: str | None = None,
        page: int = 1,
        page_size: int = 100,
    ) -> list[Repository]:
        """List all Git repositories in a project.

        Uses ``includeHidden=true`` to include disabled repos. ADO returns
        all repos in one call - ``page`` / ``page_size`` aren't honored
        but kept on the signature to satisfy the ``SourceAdapter``
        contract.
        """
        if not project:
            raise ValueError("project is required for ADO repo listing")

        response = await self._client.request(
            "GET",
            f"/{project}/_apis/git/repositories",
            params={"includeHidden": "true"},
        )
        data = response.json()

        repos: list[Repository] = []
        for r in data.get("value", []):
            default_branch = r.get("defaultBranch") or "refs/heads/main"
            if default_branch.startswith("refs/heads/"):
                default_branch = default_branch[len("refs/heads/") :]

            repos.append(
                Repository(
                    id=r["id"],
                    name=r["name"],
                    full_name=f"{project}/{r['name']}",
                    description=r.get("description"),
                    project_name=project,
                    default_branch=default_branch,
                    is_disabled=r.get("isDisabled", False),
                    is_in_maintenance=r.get("isInMaintenance", False),
                    is_fork=r.get("isFork", False),
                    size_bytes=r.get("size"),
                    clone_url_https=r.get("remoteUrl"),
                    clone_url_ssh=r.get("sshUrl"),
                    source="azure-devops",
                )
            )
        return repos

    async def get_repository(self, repo_id: str) -> Repository | None:
        """Not implemented in this lift; tracked for follow-up."""
        raise NotImplementedError

    async def count_branches(self, repo_id: str) -> int:
        """Count branches. ``repo_id`` is the composite ``project/repo_uuid``."""
        project, repo = repo_id.split("/", 1)
        count = 0
        async for _ in paginate_via_adoclient_continuation_token(
            self._client,
            f"/{project}/_apis/git/repositories/{repo}/refs",
            params={"filter": "heads/", "$top": "100"},
        ):
            count += 1
        return count

    async def count_pull_requests(
        self,
        repo_id: str,
        *,
        state: str | None = None,
    ) -> int:
        """Count pull requests. Pagination: ``$skip``/``$top``."""
        project, repo = repo_id.split("/", 1)
        count = 0
        async for _ in paginate_via_adoclient_skip_top(
            self._client,
            f"/{project}/_apis/git/repositories/{repo}/pullrequests",
            params={"searchCriteria.status": state or "all"},
            page_size=100,
        ):
            count += 1
        return count

    async def detect_lfs_patterns(
        self,
        repo_id: str,
        *,
        branch: str | None = None,
    ) -> dict[str, Any]:
        """Detect LFS patterns from ``.gitattributes`` (uses ``includeContent=true``).

        Returns ``{"has_lfs": bool, "patterns": list[str]}``. Returns
        empty result when the file is absent (HTTP 404). Drift from the
        donor (which swallowed every ``APIError``): authentication
        failures, rate-limit responses, and 5xx errors are now
        re-raised so they don't silently turn into "no LFS" false
        negatives during a scan.
        """
        project, repo = repo_id.split("/", 1)
        params: dict[str, Any] = {
            "path": ".gitattributes",
            "includeContent": "true",
        }
        if branch:
            params["versionDescriptor.version"] = branch
            params["versionDescriptor.versionType"] = "branch"

        try:
            response = await self._client.request(
                "GET",
                f"/{project}/_apis/git/repositories/{repo}/items",
                params=params,
            )
            data = response.json()
            content: str = data.get("content", "")

            # Detect positive LFS patterns using token-level matching.
            # split() handles both space and tab separators.
            # Excludes negations ("-filter=lfs") and comment lines.
            patterns: list[str] = []
            for line in content.splitlines():
                stripped = line.strip()
                if not stripped or stripped.startswith("#"):
                    continue
                tokens = stripped.split()
                # A .gitattributes line needs at least <pattern> <attr> to
                # carry an attribute; one-token lines are syntactically
                # incomplete and the donor skips them.
                min_tokens_for_attr = 2
                if len(tokens) < min_tokens_for_attr:
                    continue
                has_positive = any(tok == "filter=lfs" for tok in tokens)
                has_negation = any(tok == "-filter=lfs" for tok in tokens)
                if has_positive and not has_negation:
                    patterns.append(tokens[0])
            has_lfs = bool(patterns)

            return {"has_lfs": has_lfs, "patterns": patterns}
        except APIError as exc:
            if exc.status_code == HTTPStatus.NOT_FOUND:
                return {"has_lfs": False, "patterns": []}
            raise

    async def analyze_large_files(
        self,
        repo_id: str,
        *,
        branch: str | None = None,
        threshold_bytes: int = 100_000_000,
    ) -> dict[str, Any]:
        """Analyze the repo tree for files >= ``threshold_bytes``.

        Walks ``refs -> commits -> trees`` to enumerate blob sizes.
        Returns ``{"large_files": [{"path": str, "size_bytes": int}, ...]}``.
        Returns an empty list when the requested branch / commit / tree
        cannot be located (HTTP 404). Drift from the donor (which
        swallowed every ``APIError``): authentication failures,
        rate-limit responses, and 5xx errors are now re-raised so they
        don't silently turn into "no large files" false negatives
        during a scan.
        """
        project, repo = repo_id.split("/", 1)
        ref_name = branch or "main"
        try:
            refs_response = await self._client.request(
                "GET",
                f"/{project}/_apis/git/repositories/{repo}/refs",
                params={"filter": f"heads/{ref_name}", "$top": "1"},
            )
            refs_data = refs_response.json()
            refs_list = refs_data.get("value", [])
            if not refs_list:
                return {"large_files": []}

            commit_id = refs_list[0]["objectId"]

            commit_response = await self._client.request(
                "GET",
                f"/{project}/_apis/git/repositories/{repo}/commits/{commit_id}",
            )
            commit_data = commit_response.json()
            tree_sha = commit_data.get("treeSha1") or commit_data.get("treeId")
            if not tree_sha:
                return {"large_files": []}

            tree_response = await self._client.request(
                "GET",
                f"/{project}/_apis/git/repositories/{repo}/trees/{tree_sha}",
                params={"recursive": "true"},
            )
            tree_data = tree_response.json()

            entries = tree_data.get("treeEntries", [])
            large_files = []
            for entry in entries:
                if entry.get("gitObjectType") == "blob":
                    size = entry.get("size", 0)
                    if size >= threshold_bytes:
                        large_files.append(
                            {
                                "path": entry.get("relativePath", ""),
                                "size_bytes": size,
                            }
                        )

            return {"large_files": large_files}
        except APIError as exc:
            if exc.status_code == HTTPStatus.NOT_FOUND:
                return {"large_files": []}
            raise

    async def get_file_content(
        self,
        project: str,
        repo_id: str,
        path: str,
        *,
        branch: str | None = None,
    ) -> str | None:
        """Fetch a file's text content from a Git repository.

        Returns ``None`` if the file does not exist (HTTP 404).
        Re-raises auth / rate-limit / server errors so callers can react.
        """
        params: dict[str, Any] = {
            "path": path,
            "includeContent": "true",
        }
        if branch:
            params["versionDescriptor.version"] = branch
            params["versionDescriptor.versionType"] = "branch"

        try:
            response = await self._client.request(
                "GET",
                f"/{project}/_apis/git/repositories/{repo_id}/items",
                params=params,
            )
        except APIError as exc:
            if exc.status_code == HTTPStatus.NOT_FOUND:
                return None
            raise

        data = response.json()
        content: str | None = data.get("content")
        return content

    # --- Pipeline methods (build & release definitions) ---

    async def list_build_definitions(self, project: str) -> list[dict[str, Any]]:
        """List build definitions (YAML + Classic).

        Distinguish type by ``process.type``: 1=designer/classic, 2=YAML.
        """
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client,
                f"/{project}/_apis/build/definitions",
                params={"$top": "100"},
            )
        ]

    async def get_build_definition(self, project: str, definition_id: int) -> dict[str, Any]:
        """Get a single build definition with full detail (process/phases/steps)."""
        response = await self._client.request(
            "GET",
            f"/{project}/_apis/build/definitions/{definition_id}",
        )
        result: dict[str, Any] = response.json()
        return result

    async def list_release_definitions(self, project: str) -> list[dict[str, Any]]:
        """List classic release definitions.

        Routed to ``vsrm.dev.azure.com`` via ``host="vsrm"``.
        """
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client,
                f"/{project}/_apis/release/definitions",
                host="vsrm",
                params={"$top": "100"},
            )
        ]

    async def get_release_definition(self, project: str, definition_id: int) -> dict[str, Any]:
        """Get a single release definition with full detail (environments/tasks)."""
        response = await self._client.request(
            "GET",
            f"/{project}/_apis/release/definitions/{definition_id}",
            host="vsrm",
        )
        result: dict[str, Any] = response.json()
        return result

    # --- Service connection / variable group / environment methods ---

    async def list_service_connections(self, project: str) -> list[dict[str, Any]]:
        """List service connections. No pagination - returns all at once."""
        response = await self._client.request(
            "GET",
            f"/{project}/_apis/serviceendpoint/endpoints",
        )
        data = response.json()
        result: list[dict[str, Any]] = data.get("value", [])
        return result

    async def list_variable_groups(self, project: str) -> list[dict[str, Any]]:
        """List variable groups."""
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client,
                f"/{project}/_apis/distributedtask/variablegroups",
                params={"$top": "100"},
            )
        ]

    async def list_environments(self, project: str) -> list[dict[str, Any]]:
        """List environments."""
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client,
                f"/{project}/_apis/distributedtask/environments",
                params={"$top": "100"},
            )
        ]

    # --- Board / work-item methods ---

    async def query_work_item_counts(self, project: str) -> dict[str, Any]:
        """Query work-item counts using the Analytics OData API.

        Routed to ``analytics.dev.azure.com`` via ``host="analytics"``.
        OData uses versioned URL paths (``v4.0-preview``), not
        ``api-version`` — passes ``skip_api_version=True``.
        """
        response = await self._client.request(
            "GET",
            f"/{project}/_odata/v4.0-preview/WorkItems",
            host="analytics",
            params={
                "$apply": "groupby((WorkItemType,State),aggregate($count as Count))",
            },
            skip_api_version=True,
        )
        data = response.json()

        by_type: dict[str, int] = {}
        by_state: dict[str, int] = {}
        total = 0

        for item in data.get("value", []):
            # `or` intentionally coerces both None and empty strings to "Unknown"
            wit = item.get("WorkItemType") or "Unknown"
            state = item.get("State") or "Unknown"
            count = item.get("Count", 0)
            by_type[wit] = by_type.get(wit, 0) + count
            by_state[state] = by_state.get(state, 0) + count
            total += count

        return {"total": total, "by_type": by_type, "by_state": by_state}

    async def get_classification_nodes(self, project: str) -> dict[str, Any]:
        """Get area and iteration classification nodes. No pagination."""
        response = await self._client.request(
            "GET",
            f"/{project}/_apis/wit/classificationnodes",
            params={"$depth": "10"},
        )
        result: dict[str, Any] = response.json()
        return result

    async def get_custom_fields_count(
        self,
        process_id: str,
        work_item_type_ref_name: str,
    ) -> int:
        """Count custom fields for a work item type (``customization == 'custom'``)."""
        response = await self._client.request(
            "GET",
            f"/_apis/work/processes/{process_id}/workItemTypes/{work_item_type_ref_name}/fields",
        )
        data = response.json()
        return sum(1 for f in data.get("value", []) if f.get("customization") == "custom")

    # --- Artifact feed methods ---

    async def list_artifact_feeds(
        self,
        project: str | None = None,
    ) -> list[dict[str, Any]]:
        """List artifact feeds via ``feeds.dev.azure.com`` (``host="feeds"``).

        No pagination - returns all at once.
        """
        url = f"/{project}/_apis/packaging/feeds" if project else "/_apis/packaging/feeds"
        response = await self._client.request("GET", url, host="feeds")
        data = response.json()
        result: list[dict[str, Any]] = data.get("value", [])
        return result

    # --- Test plan methods ---

    async def list_test_plans(self, project: str) -> list[dict[str, Any]]:
        """List test plans."""
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client,
                f"/{project}/_apis/testplan/plans",
                params={"$top": "100"},
            )
        ]

    # --- Branch policy methods ---

    async def list_branch_policies(self, project: str) -> list[dict[str, Any]]:
        """List branch policies (endpoint: ``_apis/git/policy/configurations``)."""
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client,
                f"/{project}/_apis/git/policy/configurations",
                params={"$top": "100"},
            )
        ]

    # --- TFVC methods ---

    async def list_tfvc_changesets(self, project: str) -> dict[str, Any]:
        """Get TFVC changeset summary. Counts via ``$skip``/``$top`` pagination.

        Returns ``{"total_changesets": int, "latest_changeset_date": str | None}``.
        Returns the empty shape when the project has no changesets (HTTP
        404). Drift from the donor (which swallowed every ``APIError``):
        auth / rate-limit / 5xx errors now propagate so a scan doesn't
        silently turn into "no TFVC" false negatives.
        """
        try:
            response = await self._client.request(
                "GET",
                f"/{project}/_apis/tfvc/changesets",
                params={"$top": "1", "$orderby": "id desc"},
            )
            data = response.json()
            changesets = data.get("value", [])

            if not changesets:
                return {"total_changesets": 0, "latest_changeset_date": None}

            latest = changesets[0]

            total = 0
            async for _ in paginate_via_adoclient_skip_top(
                self._client,
                f"/{project}/_apis/tfvc/changesets",
                page_size=100,
            ):
                total += 1

            return {
                "total_changesets": total,
                "latest_changeset_date": latest.get("createdDate"),
            }
        except APIError as exc:
            if exc.status_code == HTTPStatus.NOT_FOUND:
                return {"total_changesets": 0, "latest_changeset_date": None}
            raise

    # --- User / entitlement methods ---

    async def list_user_entitlements(self) -> list[dict[str, Any]]:
        """List all user entitlements via ``vsaex.dev.azure.com`` (``host="vsaex"``).

        Endpoint: ``GET /_apis/userentitlements?api-version=7.1-preview.4``.
        Pagination: ``continuationToken`` in **response body**, passed as
        query param. Response shape:
        ``{"items": [...], "continuationToken": "...", "totalCount": N}``.
        Older deployments key items under ``members`` instead of
        ``items``; the helper's ``items_key`` sequence preserves that
        fallback.
        """
        return [
            item
            async for item in paginate_via_adoclient_body_continuation_token(
                self._client,
                "/_apis/userentitlements",
                host="vsaex",
                params={"$top": "10000", "api-version": "7.1-preview.4"},
                items_key=("items", "members"),
            )
        ]

    async def list_users(
        self,
        *,
        workspace: str | None = None,
        page: int = 1,
        page_size: int = 100,
    ) -> list[User]:
        """List users via the VSSPS Graph API (``host="vssps"``).

        Endpoint: ``GET /_apis/graph/users?api-version=7.1-preview.1``.

        The Graph API requires the ``-preview.1`` suffix on the
        api-version even under the 7.1 contract; passing plain ``7.1``
        returns ``HTTP 400 VssInvalidPreviewVersionException``. Override
        the ``ADOClient`` default by setting it explicitly in ``params``.

        ``workspace`` / ``page`` / ``page_size`` arguments exist on the
        ``SourceAdapter`` contract but ADO's Graph API doesn't honor
        client-side paging knobs.
        """
        return [
            User(
                id=entry.get("descriptor", entry.get("originId", "")),
                username=entry.get("principalName", ""),
                display_name=entry.get("displayName"),
                email=entry.get("mailAddress"),
                source="azure-devops",
            )
            async for entry in paginate_via_adoclient_continuation_token(
                self._client,
                "/_apis/graph/users",
                host="vssps",
                params={"api-version": "7.1-preview.1"},
            )
        ]

    async def get_user(self, user_id: str) -> User | None:
        """Not implemented in this lift; tracked for follow-up."""
        raise NotImplementedError

    # --- Lifecycle ---

    async def close(self) -> None:
        """Close the underlying ADOClient (and therefore all 6 httpx clients)."""
        await self._client.close()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.close()
