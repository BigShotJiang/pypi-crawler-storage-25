"""Concrete Azure DevOps Server adapter.

Lifted from ``n8group-oss/ado2gh-core/src/ado2gh/adapters/ado_server.py`` @
``160de58``. Re-licensed BUSL-1.1 -> MIT under the sole-author consent
path documented in ``shyftport-specs/plans/audit/migration-core-base-decision.md``.

**Drift from donor:**

- Sibling of :class:`AzureDevOpsCloudAdapter`, NOT a subclass. The new
  ``ADOClient``/``BaseADOClient`` shape diverges from the donor's
  adapter-internal httpx clients; with transport extracted, every
  cloud method's body would need a parallel server method anyway
  (different host strategy, different api-version policy). The
  sibling-and-parity-test approach catches the same drift risk that
  inheritance catches by construction.
- Capability-gated methods raise :class:`UnsupportedOnAzureDevOpsServerError`
  on the False branch. Donor's compatibility-mode short-circuited
  ``query_work_item_counts`` to zeros and ``list_user_entitlements``
  to ``[]``; we drop that — discovery reports must surface "what was
  missed and why," not silently zero out.
- ``host=`` argument is never passed (every server method relies on
  the default). The single httpx client is collection-scoped; logical
  hosts alias to it.
- ``list_users`` uses the probe-resolved Graph api-version stored on
  ``ADOServerClient.graph_api_version`` (preview-suffix-aware via the
  discovery probe). The capability set carries ``supports_graph_api``
  / ``api_version``; the Graph-specific api-version variant lives on
  the client because it differs from the rest-of-API api-version
  (``"7.0-preview.1"`` vs plain ``"7.0"``, per Microsoft's
  per-deployment variation).
"""

from __future__ import annotations

from http import HTTPStatus
from typing import TYPE_CHECKING, Any, Self

from ado_source_core.adapters.source import SourceAdapter
from ado_source_core.exceptions import (
    APIError,
    AuthenticationError,
    UnsupportedOnAzureDevOpsServerError,
)
from ado_source_core.models.repository import Repository
from ado_source_core.models.source_capabilities import SourceCapabilities
from ado_source_core.models.user import User
from ado_source_core.pagination import (
    paginate_via_adoclient_continuation_token,
    paginate_via_adoclient_skip_top,
)

if TYPE_CHECKING:
    from types import TracebackType

    from ado_source_core.client import ADOServerClient


class AzureDevOpsServerAdapter(SourceAdapter[Repository, User]):
    """Concrete read-side adapter for Azure DevOps Server (on-prem).

    Sibling of :class:`AzureDevOpsCloudAdapter` — same method-by-method
    contract, identical signatures, identical return-shape semantics. The
    server-side body uses a single collection-scoped HTTP client and
    eager-raises :class:`UnsupportedOnAzureDevOpsServerError` on
    capabilities that the resolved Server instance does not expose.

    Construct around a connected (or about-to-be-connected) ``ADOServerClient``::

        async with ADOServerClient(
            base_url="https://devops.example.com:8080/tfs",
            collection="DefaultCollection",
            auth=PATAuth(token=...),
        ) as client:
            async with AzureDevOpsServerAdapter(client=client) as adapter:
                projects = await adapter.list_projects()
                caps = await adapter.get_capabilities()
                if caps.supports_graph_api:
                    users = await adapter.list_users()
    """

    def __init__(
        self,
        *,
        client: ADOServerClient,
        capabilities: SourceCapabilities | None = None,
    ) -> None:
        """Construct around a (possibly unconnected) ``ADOServerClient``.

        The ``capabilities=`` parameter is intended for tests that need to
        bypass the probe (e.g., to assert eager-raise behavior with a
        hand-crafted :class:`SourceCapabilities`). Production callers should
        omit it and let :meth:`get_capabilities` probe automatically —
        passing a stale capability set without invoking
        :meth:`ADOServerClient.connect` first means :meth:`list_users` will
        use whichever api-version was baked into the test capability set
        rather than the probe-discovered one.
        """
        self._client = client
        self._capabilities: SourceCapabilities | None = capabilities

    @property
    def client(self) -> ADOServerClient:
        return self._client

    async def get_capabilities(self) -> SourceCapabilities:
        """Return the resolved capability set, building it lazily on first call.

        Ensures the underlying client has been probe-resolved before the
        capability set is built — calls ``await self._client.connect()``
        which is idempotent. This prevents a stale-default capability set
        being cached from a constructor-only state where probe overrides
        haven't been applied yet.
        """
        if self._capabilities is not None:
            return self._capabilities
        await self._client.connect()  # idempotent; ensures probe state populated
        base = SourceCapabilities.server_default(api_version=self._client.api_version)
        self._capabilities = base.with_overrides(
            self._client.capability_overrides,
            notes=self._client.capability_notes,
        )
        return self._capabilities

    # --- Authentication probe ---

    async def verify_credentials(self) -> bool:
        """Verify PAT by probing projects, repos, and builds scopes.

        Safe to call standalone — no ``async with adapter:`` required.
        Calls ``await self._client.connect()`` at the top, which is
        idempotent: it returns immediately if the underlying client is
        already connected, or runs the api-version + soft-capability
        probes if not. This guarantees the probe-discovered api-version
        is populated before the verification requests fire, so callers
        who construct ``ADOServerClient`` without an explicit
        ``api_version=`` get a network-level credential check rather
        than a ``RuntimeError`` from the unconnected api-version
        property.

        The ``connect()`` call is intentionally INSIDE the try-except so
        an auth failure during the api-version probe (e.g., a bad PAT
        on the connectionData round-trip) gets remapped to the
        server-flavored remediation message, matching the spec's error
        contract for version-probe auth failures.
        """
        try:
            await self._client.connect()
            projects_resp = await self._client.request(
                "GET",
                "/_apis/projects",
                params={"$top": "1"},
            )
            projects = projects_resp.json().get("value", [])
            if projects:
                project_name = projects[0]["name"]
                await self._client.request(
                    "GET",
                    f"/{project_name}/_apis/git/repositories",
                )
                await self._client.request(
                    "GET",
                    f"/{project_name}/_apis/build/definitions",
                    params={"$top": "1"},
                )
        except AuthenticationError as exc:
            raise AuthenticationError(
                "Azure DevOps Server authentication failed.\n"
                "  Verify the PAT and collection permissions for project, "
                "code, and build read access on the target server.\n"
                "  Ensure base_url points at the Azure DevOps Server root or "
                "collection URL.",
                status_code=exc.status_code,
                response_body=exc.response_body,
            ) from exc
        return True

    # --- Project methods ---

    async def list_projects(
        self,
        *,
        state_filter: str = "wellFormed",
    ) -> list[dict[str, Any]]:
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client,
                "/_apis/projects",
                params={"stateFilter": state_filter, "$top": "100"},
            )
        ]

    async def get_project_details(self, project_id: str) -> dict[str, Any]:
        response = await self._client.request(
            "GET",
            f"/_apis/projects/{project_id}",
            params={"includeCapabilities": "true"},
        )
        result: dict[str, Any] = response.json()
        return result

    async def get_process_template(self, process_type_id: str) -> dict[str, Any]:
        response = await self._client.request(
            "GET",
            f"/_apis/work/processes/{process_type_id}",
        )
        result: dict[str, Any] = response.json()
        return result

    # --- Repository methods ---

    async def list_repositories(
        self,
        *,
        workspace: str | None = None,
        project: str | None = None,
        page: int = 1,
        page_size: int = 100,
    ) -> list[Repository]:
        if not project:
            raise ValueError("project is required for ADO repo listing")
        response = await self._client.request(
            "GET",
            f"/{project}/_apis/git/repositories",
            params={"includeHidden": "true"},
        )
        data = response.json()
        repos: list[Repository] = []
        for r in data.get("value", []):
            default_branch = r.get("defaultBranch") or "refs/heads/main"
            if default_branch.startswith("refs/heads/"):
                default_branch = default_branch[len("refs/heads/") :]
            repos.append(
                Repository(
                    id=r["id"],
                    name=r["name"],
                    full_name=f"{project}/{r['name']}",
                    description=r.get("description"),
                    project_name=project,
                    default_branch=default_branch,
                    is_disabled=r.get("isDisabled", False),
                    is_in_maintenance=r.get("isInMaintenance", False),
                    is_fork=r.get("isFork", False),
                    size_bytes=r.get("size"),
                    clone_url_https=r.get("remoteUrl"),
                    clone_url_ssh=r.get("sshUrl"),
                    source="azure-devops",
                )
            )
        return repos

    async def get_repository(self, repo_id: str) -> Repository | None:
        raise NotImplementedError

    async def count_branches(self, repo_id: str) -> int:
        project, repo = repo_id.split("/", 1)
        count = 0
        async for _ in paginate_via_adoclient_continuation_token(
            self._client,
            f"/{project}/_apis/git/repositories/{repo}/refs",
            params={"filter": "heads/", "$top": "100"},
        ):
            count += 1
        return count

    async def count_pull_requests(
        self,
        repo_id: str,
        *,
        state: str | None = None,
    ) -> int:
        project, repo = repo_id.split("/", 1)
        count = 0
        async for _ in paginate_via_adoclient_skip_top(
            self._client,
            f"/{project}/_apis/git/repositories/{repo}/pullrequests",
            params={"searchCriteria.status": state or "all"},
            page_size=100,
        ):
            count += 1
        return count

    async def detect_lfs_patterns(
        self,
        repo_id: str,
        *,
        branch: str | None = None,
    ) -> dict[str, Any]:
        project, repo = repo_id.split("/", 1)
        params: dict[str, Any] = {"path": ".gitattributes", "includeContent": "true"}
        if branch:
            params["versionDescriptor.version"] = branch
            params["versionDescriptor.versionType"] = "branch"
        try:
            response = await self._client.request(
                "GET",
                f"/{project}/_apis/git/repositories/{repo}/items",
                params=params,
            )
            data = response.json()
            content: str = data.get("content", "")
            min_tokens_for_attr = 2
            patterns: list[str] = []
            for line in content.splitlines():
                stripped = line.strip()
                if not stripped or stripped.startswith("#"):
                    continue
                tokens = stripped.split()
                if len(tokens) < min_tokens_for_attr:
                    continue
                has_positive = any(tok == "filter=lfs" for tok in tokens)
                has_negation = any(tok == "-filter=lfs" for tok in tokens)
                if has_positive and not has_negation:
                    patterns.append(tokens[0])
            return {"has_lfs": bool(patterns), "patterns": patterns}
        except APIError as exc:
            if exc.status_code == HTTPStatus.NOT_FOUND:
                return {"has_lfs": False, "patterns": []}
            raise

    async def analyze_large_files(
        self,
        repo_id: str,
        *,
        branch: str | None = None,
        threshold_bytes: int = 100_000_000,
    ) -> dict[str, Any]:
        project, repo = repo_id.split("/", 1)
        ref_name = branch or "main"
        try:
            refs_response = await self._client.request(
                "GET",
                f"/{project}/_apis/git/repositories/{repo}/refs",
                params={"filter": f"heads/{ref_name}", "$top": "1"},
            )
            refs_list = refs_response.json().get("value", [])
            if not refs_list:
                return {"large_files": []}
            commit_id = refs_list[0]["objectId"]
            commit_response = await self._client.request(
                "GET",
                f"/{project}/_apis/git/repositories/{repo}/commits/{commit_id}",
            )
            commit_data = commit_response.json()
            tree_sha = commit_data.get("treeSha1") or commit_data.get("treeId")
            if not tree_sha:
                return {"large_files": []}
            tree_response = await self._client.request(
                "GET",
                f"/{project}/_apis/git/repositories/{repo}/trees/{tree_sha}",
                params={"recursive": "true"},
            )
            entries = tree_response.json().get("treeEntries", [])
            large_files = [
                {"path": e.get("relativePath", ""), "size_bytes": e.get("size", 0)}
                for e in entries
                if e.get("gitObjectType") == "blob" and e.get("size", 0) >= threshold_bytes
            ]
            return {"large_files": large_files}
        except APIError as exc:
            if exc.status_code == HTTPStatus.NOT_FOUND:
                return {"large_files": []}
            raise

    async def get_file_content(
        self,
        project: str,
        repo_id: str,
        path: str,
        *,
        branch: str | None = None,
    ) -> str | None:
        params: dict[str, Any] = {"path": path, "includeContent": "true"}
        if branch:
            params["versionDescriptor.version"] = branch
            params["versionDescriptor.versionType"] = "branch"
        try:
            response = await self._client.request(
                "GET",
                f"/{project}/_apis/git/repositories/{repo_id}/items",
                params=params,
            )
        except APIError as exc:
            if exc.status_code == HTTPStatus.NOT_FOUND:
                return None
            raise
        data = response.json()
        content: str | None = data.get("content")
        return content

    # --- Pipeline methods (build & release definitions) ---

    async def list_build_definitions(self, project: str) -> list[dict[str, Any]]:
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client,
                f"/{project}/_apis/build/definitions",
                params={"$top": "100"},
            )
        ]

    async def get_build_definition(
        self,
        project: str,
        definition_id: int,
    ) -> dict[str, Any]:
        response = await self._client.request(
            "GET",
            f"/{project}/_apis/build/definitions/{definition_id}",
        )
        result: dict[str, Any] = response.json()
        return result

    async def list_release_definitions(self, project: str) -> list[dict[str, Any]]:
        # On Server, classic Release Management lives under the same
        # collection-scoped URL — no separate vsrm host.
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client,
                f"/{project}/_apis/release/definitions",
                params={"$top": "100"},
            )
        ]

    async def get_release_definition(
        self,
        project: str,
        definition_id: int,
    ) -> dict[str, Any]:
        response = await self._client.request(
            "GET",
            f"/{project}/_apis/release/definitions/{definition_id}",
        )
        result: dict[str, Any] = response.json()
        return result

    # --- Service connection / variable group / environment methods ---

    async def list_service_connections(self, project: str) -> list[dict[str, Any]]:
        response = await self._client.request(
            "GET",
            f"/{project}/_apis/serviceendpoint/endpoints",
        )
        result: list[dict[str, Any]] = response.json().get("value", [])
        return result

    async def list_variable_groups(self, project: str) -> list[dict[str, Any]]:
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client,
                f"/{project}/_apis/distributedtask/variablegroups",
                params={"$top": "100"},
            )
        ]

    async def list_environments(self, project: str) -> list[dict[str, Any]]:
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client,
                f"/{project}/_apis/distributedtask/environments",
                params={"$top": "100"},
            )
        ]

    # --- Work item / classification methods ---

    async def query_work_item_counts(self, project: str) -> dict[str, Any]:
        """Query work-item counts via collection-base, project-scoped OData.

        Eager-raises :class:`UnsupportedOnAzureDevOpsServerError` if the
        Analytics extension is not installed on the resolved Server
        instance.
        """
        caps = await self.get_capabilities()
        if not caps.supports_analytics_odata:
            raise UnsupportedOnAzureDevOpsServerError(
                "Analytics OData is not available on this Azure DevOps Server instance "
                "(the optional Analytics extension is not installed or could not be probed).",
                capability="supports_analytics_odata",
                api_version=caps.api_version,
                remediation=(
                    "The Analytics extension is required for "
                    "/_odata/v4.0-preview/WorkItems. Auto-installed on Server 2020+; "
                    "on Server 2019, install via the server administration console "
                    "(Marketplace → install on collection)."
                ),
            )
        response = await self._client.request(
            "GET",
            f"/{project}/_odata/v4.0-preview/WorkItems",
            params={
                "$apply": "groupby((WorkItemType,State),aggregate($count as Count))",
            },
            skip_api_version=True,
        )
        data = response.json()
        by_type: dict[str, int] = {}
        by_state: dict[str, int] = {}
        total = 0
        for item in data.get("value", []):
            wit = item.get("WorkItemType") or "Unknown"
            state = item.get("State") or "Unknown"
            count = item.get("Count", 0)
            by_type[wit] = by_type.get(wit, 0) + count
            by_state[state] = by_state.get(state, 0) + count
            total += count
        return {"total": total, "by_type": by_type, "by_state": by_state}

    async def get_classification_nodes(self, project: str) -> dict[str, Any]:
        response = await self._client.request(
            "GET",
            f"/{project}/_apis/wit/classificationnodes",
            params={"$depth": "10"},
        )
        result: dict[str, Any] = response.json()
        return result

    async def get_custom_fields_count(
        self,
        process_id: str,
        work_item_type_ref_name: str,
    ) -> int:
        response = await self._client.request(
            "GET",
            f"/_apis/work/processes/{process_id}/workItemTypes/{work_item_type_ref_name}/fields",
        )
        data = response.json()
        return sum(1 for f in data.get("value", []) if f.get("customization") == "custom")

    # --- Artifact feed / test plan / branch policy / TFVC methods ---

    async def list_artifact_feeds(
        self,
        project: str | None = None,
    ) -> list[dict[str, Any]]:
        """List artifact feeds.

        Eager-raises :class:`UnsupportedOnAzureDevOpsServerError` if the
        Package Management extension is not installed.
        """
        caps = await self.get_capabilities()
        if not caps.supports_artifact_feeds:
            raise UnsupportedOnAzureDevOpsServerError(
                "Artifact feeds are not available on this Azure DevOps Server "
                "instance (the optional Package Management extension is not "
                "installed or could not be probed).",
                capability="supports_artifact_feeds",
                api_version=caps.api_version,
                remediation=(
                    "The Package Management extension is required for "
                    "/_apis/packaging/feeds. Install via the server administration "
                    "console (Marketplace → install on collection)."
                ),
            )
        url = f"/{project}/_apis/packaging/feeds" if project else "/_apis/packaging/feeds"
        response = await self._client.request("GET", url)
        result: list[dict[str, Any]] = response.json().get("value", [])
        return result

    async def list_test_plans(self, project: str) -> list[dict[str, Any]]:
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client,
                f"/{project}/_apis/testplan/plans",
                params={"$top": "100"},
            )
        ]

    async def list_branch_policies(self, project: str) -> list[dict[str, Any]]:
        return [
            item
            async for item in paginate_via_adoclient_continuation_token(
                self._client,
                f"/{project}/_apis/git/policy/configurations",
                params={"$top": "100"},
            )
        ]

    async def list_tfvc_changesets(self, project: str) -> dict[str, Any]:
        try:
            response = await self._client.request(
                "GET",
                f"/{project}/_apis/tfvc/changesets",
                params={"$top": "1", "$orderby": "id desc"},
            )
            data = response.json()
            changesets = data.get("value", [])
            if not changesets:
                return {"total_changesets": 0, "latest_changeset_date": None}
            latest = changesets[0]
            total = 0
            async for _ in paginate_via_adoclient_skip_top(
                self._client,
                f"/{project}/_apis/tfvc/changesets",
                page_size=100,
            ):
                total += 1
            return {
                "total_changesets": total,
                "latest_changeset_date": latest.get("createdDate"),
            }
        except APIError as exc:
            if exc.status_code == HTTPStatus.NOT_FOUND:
                return {"total_changesets": 0, "latest_changeset_date": None}
            raise

    # --- User / entitlement methods ---

    async def list_user_entitlements(self) -> list[dict[str, Any]]:
        """**Always raises** on Server — the vsaex Member Entitlements API is
        cloud-only.
        """
        caps = await self.get_capabilities()
        raise UnsupportedOnAzureDevOpsServerError(
            "Member Entitlements (vsaex) API is cloud-only and not available "
            "on Azure DevOps Server.",
            capability="supports_user_entitlements",
            api_version=caps.api_version,
            remediation=(
                "Member Entitlements (vsaex) API is cloud-only. On Azure "
                "DevOps Server, list users via list_users() (Graph API) or "
                "query /_apis/identities directly through the underlying client."
            ),
        )

    async def list_users(
        self,
        *,
        workspace: str | None = None,
        page: int = 1,
        page_size: int = 100,
    ) -> list[User]:
        """List users via the Graph API.

        Eager-raises :class:`UnsupportedOnAzureDevOpsServerError` if the
        Graph extension is not installed. Uses the **probe-resolved Graph
        api-version** (``self._client.graph_api_version``) — that is the
        variant (``-preview.1`` suffix or plain) that the Graph
        soft-capability probe established works on this Server instance.
        Sending plain ``caps.api_version`` here would 400 on Server
        deployments that require the preview suffix.
        """
        caps = await self.get_capabilities()
        if not caps.supports_graph_api:
            raise UnsupportedOnAzureDevOpsServerError(
                "Graph API is not available on this Azure DevOps Server "
                "instance (the optional Graph extension is not installed "
                "or could not be probed).",
                capability="supports_graph_api",
                api_version=caps.api_version,
                remediation=(
                    "The Graph extension is required for /_apis/graph/users. "
                    "On Server 2019+, install the Graph extension via the "
                    "server administration console (Marketplace → install on "
                    "collection)."
                ),
            )
        graph_api_version = self._client.graph_api_version
        # supports_graph_api is True only when the probe found a working
        # variant, so graph_api_version must be set. Defensive fallback for
        # the unlikely case where capabilities were constructor-injected
        # without a corresponding probe run.
        if graph_api_version is None:
            graph_api_version = caps.api_version
        return [
            User(
                id=entry.get("descriptor", entry.get("originId", "")),
                username=entry.get("principalName", ""),
                display_name=entry.get("displayName"),
                email=entry.get("mailAddress"),
                source="azure-devops",
            )
            async for entry in paginate_via_adoclient_continuation_token(
                self._client,
                "/_apis/graph/users",
                params={"api-version": graph_api_version},
            )
        ]

    async def get_user(self, user_id: str) -> User | None:
        raise NotImplementedError

    # --- Lifecycle ---

    async def close(self) -> None:
        await self._client.close()

    async def __aenter__(self) -> Self:
        # Idempotent — ADOServerClient.connect() is itself idempotent.
        # Ensures the underlying client is probe-resolved before per-method
        # calls run, even if the caller forgot to use `async with` on the
        # client itself.
        await self._client.connect()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.close()
