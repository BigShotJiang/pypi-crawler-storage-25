"""Server REST api-version discovery + soft-capability probing.

Lifted from ``n8group-oss/ado2gh-core/src/ado2gh/adapters/ado_server.py`` @
``160de58``, specifically the ``_probe_supported_api_version`` method
(donor lines 101-119). Re-licensed BUSL-1.1 -> MIT under the sole-author
consent path documented in
``shyftport-specs/plans/audit/migration-core-base-decision.md``.

**Drift from donor:**

1. Probes ``/_apis/connectionData`` first; donor went straight to
   candidate iteration. Reason: cuts typical construction cost from
   up-to-4 round-trips to 1 when connectionData exposes a parseable
   apiVersion.
2. Folds three soft-capability probes (Graph / Analytics / Package
   Management) into the same probe pass, executed in parallel via
   ``asyncio.gather``. Donor had no equivalent — it hard-coded
   ``supports_user_entitlements=False`` and short-circuited
   ``query_work_item_counts`` via ``compatibility_mode``.
3. Returns a structured ``ServerProbeResult`` (frozen dataclass) instead
   of a bare api-version string. Reason: soft-cap probes need to fan out
   structured results — overrides for the flag set + diagnostic notes
   for ambiguity (PAT-scope-may-be-missing cases).
4. Soft-cap probes that get 401/403 mark the capability ``False`` AND
   record a diagnostic note, instead of propagating. Preserves
   usability when a PAT lacks one specific scope (e.g., ``vso.analytics``)
   but is otherwise valid.
5. Graph soft-cap probe + ``list_users`` use a probe-resolved
   preview-suffix-aware api-version (try ``-preview.1`` first, fall back
   to plain on ``400 InvalidApiVersion``), matching Microsoft's
   per-deployment variation.
6. Analytics soft-cap probe falls back from collection-scoped to
   project-scoped on 404 — Server 2019 may not expose collection-level
   metadata even when Analytics is installed.
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass, field
from http import HTTPStatus
from types import MappingProxyType
from typing import TYPE_CHECKING, Any

from ado_source_core.exceptions import APIError, AuthenticationError

if TYPE_CHECKING:
    from ado_source_core.client import ADOServerClient

logger = logging.getLogger(__name__)


SERVER_API_VERSION_CANDIDATES: tuple[str, ...] = ("7.0", "6.0", "5.1", "5.0")
"""Supported REST api-versions for ADO Server, highest first.

- ``7.0`` -> Azure DevOps Server 2022
- ``6.0`` -> Azure DevOps Server 2020
- ``5.1`` -> Azure DevOps Server 2019 Update 1+
- ``5.0`` -> Azure DevOps Server 2019 RTW

TFS 2018 (REST 4.x) and earlier are out of scope for v0.3.0.
"""


@dataclass(frozen=True)
class ServerProbeResult:
    """Result of a one-shot probe at ``ADOServerClient.connect()`` time.

    The dataclass is deeply immutable: ``capability_overrides`` is exposed
    as a ``Mapping[str, bool]`` view (wrapped in ``MappingProxyType`` at
    construction time) and ``capability_notes`` as a ``tuple[str, ...]``.
    Together with ``frozen=True``, this means the returned instance — and
    every public field on it — is safe to share across consumers without
    risk of accidental post-return mutation. Callers that need a mutable
    copy should explicitly build one (e.g., ``dict(result.capability_overrides)``
    or ``list(result.capability_notes)``).
    """

    api_version: str
    """The resolved REST api-version (e.g. ``"7.0"``)."""

    graph_api_version: str | None = None
    """The api-version variant that worked for the Graph soft-cap probe
    (e.g. ``"7.0-preview.1"`` or plain ``"7.0"``). ``None`` when the
    Graph capability is False (probe failed). The adapter's ``list_users``
    must use this value, NOT the plain ``api_version``, to avoid the
    cloud-vs-server preview-suffix mismatch."""

    capability_overrides: Mapping[str, bool] = field(
        default_factory=lambda: MappingProxyType({}),
    )
    capability_notes: tuple[str, ...] = field(default_factory=tuple)
    probe_strategy: str = "connection_data"


async def resolve_server_api_version(client: ADOServerClient) -> ServerProbeResult:
    """Resolve the highest mutually-supported REST api-version + soft caps.

    Args:
        client: A non-connected :class:`ADOServerClient` (no explicit
            ``api_version=`` passed to ``__init__``).

    Returns:
        A :class:`ServerProbeResult` with the resolved api-version, the
        three soft-capability overrides, any diagnostic notes from the
        probe, and the strategy used (``"connection_data"`` if
        connectionData succeeded, ``"candidate_iteration"`` otherwise).

    Raises:
        AuthenticationError: If the version probe (NOT a soft-cap probe)
            returns 401 or 403. Soft-cap auth failures take the
            diagnostic-note path so a missing-scope PAT doesn't crash
            discovery for endpoints the same PAT IS authorized for.
        APIError: If every candidate api-version returns 4xx/5xx.
        RateLimitError: If 429 hits during any probe step.

    Round-trip cost (sequential phases; each phase is one wallclock unit):

    - **Best case** (connectionData exposes parseable apiVersion):
      1 connectionData + 1 ``/_apis/projects?$top=1`` (for Analytics
      fallback hint) + 1 wallclock unit for 3 parallel soft-cap probes
      = **3 sequential phases**.
    - **Worst case** (connectionData unreachable + every candidate up to
      the last fails + Graph needs preview retry + Analytics needs
      project-scoped fallback): up to 1 + 4 + ~3 = **8 sequential calls**
      before the result lands.

    The extra ``/_apis/projects`` round-trip on the connectionData-success
    path is a deliberate cost: without it, the Analytics soft-cap probe
    cannot fall back to project-scoped ``$metadata`` on Server 2019
    deployments where the collection-level URL 404s. Since the probe
    runs once per ``ADOServerClient.connect()``, the cost is amortized
    across the adapter's lifetime.
    """
    # Phase 1: try connectionData first.
    advertised = await _fetch_connection_data_api_version(client)
    api_version: str
    probe_strategy: str
    first_project: str | None = None
    if advertised is not None and (snapped := _snap_to_candidate(advertised)) is not None:
        api_version = snapped
        probe_strategy = "connection_data"
        logger.debug(
            "ADO Server connectionData advertised %s; snapped to %s",
            advertised,
            api_version,
        )
        # Even on connectionData success, fetch one project name so the
        # Analytics soft-cap probe can fall back to project-scoped
        # /_odata/$metadata on a 404 (Server 2019 may not expose
        # collection-level $metadata even when Analytics is installed).
        first_project = await _fetch_first_project_name(
            client,
            api_version=api_version,
        )
    else:
        # Phase 2: candidate iteration. Returns (api_version, first_project_name).
        api_version, first_project = await _iterate_candidates(client)
        probe_strategy = "candidate_iteration"
        logger.debug(
            "ADO Server connectionData unparseable (advertised=%r); "
            "candidate-iteration resolved api_version=%s",
            advertised,
            api_version,
        )

    # Phase 3: soft-capability probes (parallel).
    overrides, notes, graph_api_version = await probe_soft_capabilities(
        client,
        api_version=api_version,
        project_hint=first_project,
    )

    return ServerProbeResult(
        api_version=api_version,
        graph_api_version=graph_api_version,
        capability_overrides=MappingProxyType(dict(overrides)),
        capability_notes=tuple(notes),
        probe_strategy=probe_strategy,
    )


async def _fetch_first_project_name(
    client: ADOServerClient,
    *,
    api_version: str,
) -> str | None:
    """Best-effort: fetch the first project name for the Analytics fallback hint.

    Auth errors, rate-limit errors (429), 5xx, and network errors all
    propagate per the documented :func:`resolve_server_api_version`
    contract; only 400/404 fall through to ``None`` (the projects
    endpoint genuinely being unavailable). ``RateLimitError`` inherits
    from :class:`APIError`, so re-raising via the same
    ``except APIError as exc:`` clause correctly propagates it.

    Symmetric with :func:`_fetch_connection_data_api_version`: callers
    must not silently swallow infrastructure errors (429 / 5xx) here
    either, or the Analytics soft-cap probe could falsely mark
    ``supports_analytics_odata=False`` while the deployment is just
    transiently unhealthy or rate-limited.
    """
    try:
        response = await client.request(
            "GET",
            "/_apis/projects",
            params={"$top": "1", "api-version": api_version},
            skip_api_version=True,
        )
    except AuthenticationError:
        raise
    except APIError as exc:
        if exc.status_code in {HTTPStatus.BAD_REQUEST, HTTPStatus.NOT_FOUND}:
            return None
        raise
    try:
        value = response.json().get("value", [])
        if value:
            name = value[0].get("name")
            return name if isinstance(name, str) else None
    except (ValueError, KeyError, TypeError, IndexError, AttributeError):
        pass
    return None


async def _fetch_connection_data_api_version(client: ADOServerClient) -> str | None:
    """``GET /_apis/connectionData`` with ``skip_api_version=True``.

    Returns the parsed ``apiVersion`` (top-level or under
    ``locationServiceData``), or ``None`` if the endpoint isn't available
    on this Server (400/404) or the response body isn't parseable JSON.

    Auth errors, rate-limit errors (429), 5xx, and network errors all
    propagate; only 400/404 fall through to ``None``. ``RateLimitError``
    inherits from :class:`APIError`, so re-raising via the same
    ``except APIError as exc:`` clause correctly propagates it.
    """
    try:
        response = await client.request(
            "GET",
            "/_apis/connectionData",
            skip_api_version=True,
        )
    except AuthenticationError:
        raise
    except APIError as exc:
        if exc.status_code in {HTTPStatus.BAD_REQUEST, HTTPStatus.NOT_FOUND}:
            return None
        raise
    try:
        payload = response.json()
    except ValueError:
        return None
    return _extract_advertised_api_version(payload)


def _extract_advertised_api_version(payload: Any) -> str | None:
    """Return the first path that contains a parseable ``<int>.<int>`` version.

    If the top-level ``apiVersion`` is present but malformed (empty string,
    wrong type, wrong shape), fall through and try the nested
    ``locationServiceData.apiVersion`` path before giving up.
    """
    if not isinstance(payload, dict):
        return None
    for path in (("apiVersion",), ("locationServiceData", "apiVersion")):
        node: Any = payload
        for key in path:
            if not isinstance(node, dict) or key not in node:
                node = None
                break
            node = node[key]
        if isinstance(node, str) and node and _parse_version(node) is not None:
            return node
    return None


def _snap_to_candidate(advertised: str) -> str | None:
    """Return the highest candidate that is ``<= advertised``.

    Returns ``None`` if no candidate matches (e.g., advertised below the
    lowest candidate, or advertised unparseable).
    """
    advertised_tuple = _parse_version(advertised)
    if advertised_tuple is None:
        return None
    for candidate in SERVER_API_VERSION_CANDIDATES:
        candidate_tuple = _parse_version(candidate)
        if candidate_tuple is not None and candidate_tuple <= advertised_tuple:
            return candidate
    return None


_VERSION_PARTS_EXPECTED = 2


def _parse_version(value: Any) -> tuple[int, int] | None:
    """Parse ``"<int>.<int>"`` strictly. Return ``None`` on anything weird."""
    if not isinstance(value, str):
        return None
    parts = value.split(".")
    if len(parts) != _VERSION_PARTS_EXPECTED:
        return None
    try:
        return (int(parts[0]), int(parts[1]))
    except ValueError:
        return None


async def _iterate_candidates(client: ADOServerClient) -> tuple[str, str | None]:
    """Try each candidate; return ``(api_version, first_project_name)``.

    The first project name (when discoverable) is hoisted out so the
    Analytics soft-cap probe can fall back to a project-scoped URL
    without a second ``/_apis/projects`` round-trip.
    """
    last_status: int | None = None
    for candidate in SERVER_API_VERSION_CANDIDATES:
        try:
            response = await client.request(
                "GET",
                "/_apis/projects",
                params={"$top": "1", "api-version": candidate},
                skip_api_version=True,
            )
        except AuthenticationError:
            raise
        except APIError as exc:
            if exc.status_code in {HTTPStatus.BAD_REQUEST, HTTPStatus.NOT_FOUND}:
                last_status = exc.status_code
                continue
            raise
        first_project: str | None = None
        try:
            value = response.json().get("value", [])
            if value:
                name = value[0].get("name")
                if isinstance(name, str):
                    first_project = name
        except (ValueError, KeyError, TypeError, AttributeError):
            first_project = None
        return candidate, first_project

    raise APIError(
        f"Unable to determine a supported Azure DevOps Server REST API version. "
        f"Tried {list(SERVER_API_VERSION_CANDIDATES)}; last response status: {last_status}.",
        status_code=last_status,
    )


_SOFT_CAP_SCOPE_HINT = {
    "supports_graph_api": "the Graph PAT scope (vso.graph)",
    "supports_analytics_odata": "the Analytics PAT scope (vso.analytics)",
    "supports_artifact_feeds": "the Packaging PAT scope (vso.packaging)",
}


async def probe_soft_capabilities(
    client: ADOServerClient,
    *,
    api_version: str,
    project_hint: str | None,
) -> tuple[dict[str, bool], list[str], str | None]:
    """Fire 3 soft-capability probes in parallel.

    Returns ``(overrides, notes, graph_api_version)`` where:

    - ``overrides`` is a dict with the three soft-capability boolean flags.
    - ``notes`` carries diagnostic lines for ambiguous outcomes
      (e.g. 401 → flag False but PAT-scope may be the cause).
    - ``graph_api_version`` is the api-version variant that worked for the
      Graph probe (``"<resolved>-preview.1"`` or plain ``"<resolved>"``),
      or ``None`` when the Graph capability is False. The adapter's
      ``list_users`` method must use this exact value, NOT ``api_version``.
    """
    notes: list[str] = []

    GraphProbeResult = tuple[bool, str | None]

    async def _graph_probe_or_note() -> GraphProbeResult:
        try:
            return await _probe_graph(client, api_version=api_version)
        except AuthenticationError as exc:
            scope = _SOFT_CAP_SCOPE_HINT["supports_graph_api"]
            notes.append(
                f"supports_graph_api probe returned {exc.status_code}; the "
                f"capability may exist but the PAT lacks {scope}."
            )
            return False, None

    async def _bool_probe_or_note(
        capability: str,
        do_probe: Callable[[], Awaitable[bool]],
    ) -> bool:
        try:
            return await do_probe()
        except AuthenticationError as exc:
            scope = _SOFT_CAP_SCOPE_HINT.get(capability, "the required PAT scope")
            notes.append(
                f"{capability} probe returned {exc.status_code}; the capability "
                f"may exist but the PAT lacks {scope}."
            )
            return False

    graph_result, analytics, feeds = await asyncio.gather(
        _graph_probe_or_note(),
        _bool_probe_or_note(
            "supports_analytics_odata",
            lambda: _probe_analytics(
                client,
                api_version=api_version,
                project_hint=project_hint,
            ),
        ),
        _bool_probe_or_note(
            "supports_artifact_feeds",
            lambda: _probe_feeds(client, api_version=api_version),
        ),
    )
    graph_supported, graph_api_version = graph_result

    graph_note = next((n for n in notes if n.startswith("supports_graph_api")), None)
    analytics_note = next((n for n in notes if n.startswith("supports_analytics_odata")), None)
    feeds_note = next((n for n in notes if n.startswith("supports_artifact_feeds")), None)
    logger.debug(
        "Graph capability=%s; api_version=%s; note=%r",
        graph_supported,
        graph_api_version,
        graph_note,
    )
    logger.debug(
        "Analytics capability=%s; note=%r",
        analytics,
        analytics_note,
    )
    logger.debug(
        "Packaging Feeds capability=%s; note=%r",
        feeds,
        feeds_note,
    )

    overrides = {
        "supports_graph_api": graph_supported,
        "supports_analytics_odata": analytics,
        "supports_artifact_feeds": feeds,
    }
    return overrides, notes, graph_api_version


def _is_invalid_api_version_400(exc: APIError) -> bool:
    """Detect Microsoft's ``VssInvalidPreviewVersionException`` envelope on a 400."""
    if exc.status_code != HTTPStatus.BAD_REQUEST:
        return False
    body = exc.response_body or {}
    parsed = body.get("parsed") if isinstance(body, dict) else None
    candidates = (body, parsed) if isinstance(parsed, dict) else (body,)
    for candidate in candidates:
        if not isinstance(candidate, dict):
            continue
        type_key = candidate.get("typeKey")
        if isinstance(type_key, str) and "InvalidPreviewVersion" in type_key:
            return True
        message = candidate.get("message") or candidate.get("text")
        if isinstance(message, str) and "InvalidPreviewVersion" in message:
            return True
        if isinstance(message, str) and "api-version" in message.lower():
            # Some Server builds return a plainer "Invalid API version" body
            # without the typeKey; treat any 400 with "api-version" in the
            # message as the same signal.
            return True
    return False


async def _probe_graph(
    client: ADOServerClient,
    *,
    api_version: str,
) -> tuple[bool, str | None]:
    """Probe ``/_apis/graph/users`` with ``-preview.1`` first; on
    400 InvalidApiVersion, retry plain. Returns ``(True, variant_used)``
    on the first 200, ``(False, None)`` on 404 / 501 / both 400s.

    Both 404 ``Not Found`` AND 501 ``Not Implemented`` demote the
    capability — Server deployments without the Graph endpoint
    installed/enabled return either status depending on the IIS layer.
    """
    for variant in (f"{api_version}-preview.1", api_version):
        try:
            await client.request(
                "GET",
                "/_apis/graph/users",
                params={"$top": "1", "api-version": variant},
                skip_api_version=True,
            )
        except APIError as exc:
            if exc.status_code in {HTTPStatus.NOT_FOUND, HTTPStatus.NOT_IMPLEMENTED}:
                return False, None
            if _is_invalid_api_version_400(exc):
                continue  # try next variant — only invalid-version 400s
            raise
        return True, variant
    return False, None


async def _probe_analytics(
    client: ADOServerClient,
    *,
    api_version: str,
    project_hint: str | None,
) -> bool:
    """Probe collection-scoped ``$metadata``; on 404 / 501, fall back project-scoped.

    A 404 OR 501 from the collection-scoped probe demotes the capability
    via the project-scoped fallback (and to ``False`` when no project
    hint is available). 501 ``Not Implemented`` is returned by Server
    deployments that don't have the Analytics extension installed at
    all — symmetric with :func:`_probe_graph` and :func:`_probe_feeds`,
    which both treat 404 and 501 as "capability not present". Other
    error statuses propagate as :class:`APIError`.

    Note: the Analytics OData ``$metadata`` endpoint does NOT accept a REST
    ``api-version`` query parameter (the OData service version is encoded
    in the URL path: ``v4.0-preview``). We pass ``skip_api_version=True``
    so :meth:`BaseADOClient.request` does not auto-inject one. The
    ``api_version`` argument is retained for symmetry with the other soft-cap
    probes and for future use if Microsoft starts gating $metadata on
    api-version, but it is intentionally NOT sent on the wire.
    """
    del api_version  # not sent on the wire — see docstring
    try:
        await client.request(
            "GET",
            "/_odata/v4.0-preview/$metadata",
            skip_api_version=True,
        )
    except APIError as exc:
        if exc.status_code not in {HTTPStatus.NOT_FOUND, HTTPStatus.NOT_IMPLEMENTED}:
            raise
        # Fall back: project-scoped.
        if project_hint is None:
            return False
        try:
            await client.request(
                "GET",
                f"/{project_hint}/_odata/v4.0-preview/$metadata",
                skip_api_version=True,
            )
        except APIError as exc2:
            if exc2.status_code in {HTTPStatus.NOT_FOUND, HTTPStatus.NOT_IMPLEMENTED}:
                return False
            raise
        return True
    return True


async def _probe_feeds(client: ADOServerClient, *, api_version: str) -> bool:
    """Probe ``/_apis/packaging/feeds`` with the resolved api-version.

    Both 404 ``Not Found`` AND 501 ``Not Implemented`` demote the
    capability — Server deployments without the Package Management
    extension installed return either status depending on whether
    the route is missing entirely or stubbed by IIS.
    """
    try:
        await client.request(
            "GET",
            "/_apis/packaging/feeds",
            params={"$top": "1", "api-version": api_version},
            skip_api_version=True,
        )
    except APIError as exc:
        if exc.status_code in {HTTPStatus.NOT_FOUND, HTTPStatus.NOT_IMPLEMENTED}:
            return False
        raise
    return True
