"""Exception hierarchy for ado-source-core.

Two donors merged here per Stage 1 sub-stage 1.1 task 1.1.6 and the
disentanglement audit
(`shyftport-specs:plans/audit/migration-core-base-decision.md` §1A and
`shyftport-specs:plans/audit/extraction-plan.md` §3.E):

1. **Vendored from `n8group-oss/migration-core`** (BUSL-1.1, re-licensed
   MIT under the sole-author consent path documented in the audit;
   verified at vendoring time):

   - `migration_core/exceptions.py` @ `fa225aa` -> `ExitCode` (IntEnum)
   - `migration_core/exceptions.py` @ `fa225aa` -> `MigrationError`
     **renamed to `ADOSourceCoreError`** as the package-local base.

2. **Lifted from `n8group-oss/ado2gh-core`** (BUSL-1.1, re-licensed MIT
   under the same sole-author trail):

   - `ado2gh/exceptions.py` @ `160de58` -> `ConfigError`, `APIError`,
     `AuthenticationError`, `RateLimitError`. These were donor classes
     inheriting from `ADO2GHError` (which inherited from
     `MigrationError`); now they inherit directly from
     `ADOSourceCoreError`, eliminating the donor's intermediate base.

The donor's `ValidationError`, `GitError`, `StateError` deliberately
**stay in `ado2gh-core`** per audit §3.E:

- `ValidationError` is consumed only by migration-side
  `services/target_bootstrap.py:7,26,46` (Codex pass-1 M1).
- `GitError` and `StateError` are migration-side concerns (clone/push,
  state store).

After sub-stage 1.3 rewires `ado2gh-core`, its `ADO2GHError` will
inherit from `ADOSourceCoreError` imported here, and the migration-side
classes above will inherit from `ADO2GHError`.
"""

from __future__ import annotations

from enum import IntEnum
from typing import Any


class ExitCode(IntEnum):
    """CLI exit codes."""

    SUCCESS = 0
    USER_ERROR = 1
    SYSTEM_ERROR = 2


class ADOSourceCoreError(Exception):
    """Base for all ado-source-core errors.

    Vendored from migration-core's `MigrationError` and renamed to keep
    the package-local hierarchy self-contained. Carries a CLI `exit_code`
    so downstream tools (ado-scanner, ado2gh, future Shyftport engines)
    can map errors to process exit codes consistently.
    """

    def __init__(
        self,
        message: str,
        *,
        exit_code: ExitCode = ExitCode.USER_ERROR,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.exit_code = exit_code

    def __str__(self) -> str:
        return self.message


class ConfigError(ADOSourceCoreError):
    """Configuration-related errors (missing PAT, bad org name, etc.)."""

    def __init__(
        self,
        message: str,
        *,
        field: str | None = None,
        exit_code: ExitCode = ExitCode.USER_ERROR,
    ) -> None:
        super().__init__(message, exit_code=exit_code)
        self.field = field


class APIError(ADOSourceCoreError):
    """API communication errors (non-2xx HTTP responses, network failures)."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        response_body: dict[str, Any] | None = None,
        exit_code: ExitCode = ExitCode.SYSTEM_ERROR,
    ) -> None:
        # Use `is not None` (not truthiness) so a falsy-but-set status_code
        # (the synthetic `0` some HTTP libraries emit on connection failure,
        # for instance) still gets the "(HTTP 0)" suffix attached. The donor
        # files in migration-core and ado2gh-core use truthiness here; this
        # is intentional drift to be backported upstream so the next
        # quarterly re-vendor diff stays small.
        full_message = f"{message} (HTTP {status_code})" if status_code is not None else message
        super().__init__(full_message, exit_code=exit_code)
        self.status_code = status_code
        self.response_body = response_body


class AuthenticationError(APIError):
    """Authentication-specific API errors (typically HTTP 401 / 403)."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        response_body: dict[str, Any] | None = None,
        exit_code: ExitCode = ExitCode.USER_ERROR,
    ) -> None:
        super().__init__(
            message,
            status_code=status_code,
            response_body=response_body,
            exit_code=exit_code,
        )


class RateLimitError(APIError):
    """Rate limiting error (HTTP 429) with retry guidance.

    ADO Cloud uses 200 TSTUs per 5-min sliding window. The `Retry-After`
    response header indicates seconds to wait; ado-source-core surfaces
    that value as `retry_after` so callers can implement backoff.
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        response_body: dict[str, Any] | None = None,
        retry_after: float | None = None,
        exit_code: ExitCode = ExitCode.SYSTEM_ERROR,
    ) -> None:
        super().__init__(
            message,
            status_code=status_code,
            response_body=response_body,
            exit_code=exit_code,
        )
        self.retry_after = retry_after


class UnsupportedOnAzureDevOpsServerError(ADOSourceCoreError):
    """Raised when a capability is unavailable on this Azure DevOps Server instance.

    Carries enough structured context for downstream tooling (notably
    ``ado-scanner``'s discovery report) to surface a useful "what was
    missed and why" line without parsing the message.

    Attributes:
        capability: The ``SourceCapabilities`` field name that gated this
            call (e.g., ``"supports_graph_api"``,
            ``"supports_analytics_odata"``,
            ``"supports_artifact_feeds"``,
            ``"supports_user_entitlements"``).
        api_version: The Server REST api-version that was probed and
            resolved on this instance — required so discovery reports can
            write a meaningful "missed on Server <version>" line.
        remediation: Optional admin-oriented hint about how to enable the
            missing capability (e.g., "Install the Graph extension via
            the server administration console"). ``None`` when no
            remediation is appropriate (typically only for hard-False
            capabilities like ``supports_user_entitlements``).
    """

    def __init__(
        self,
        message: str,
        *,
        capability: str,
        api_version: str,
        remediation: str | None = None,
        exit_code: ExitCode = ExitCode.USER_ERROR,
    ) -> None:
        super().__init__(message, exit_code=exit_code)
        self.capability = capability
        self.api_version = api_version
        self.remediation = remediation
