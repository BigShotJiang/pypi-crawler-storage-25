"""Board/work item models for ado-source-core.

Lifted from `n8group-oss/ado2gh-core/src/ado2gh/models/board.py` @ `160de58`
per Stage 1 sub-stage 1.1 task 1.1.5. Re-licensed BUSL-1.1 -> MIT.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field, field_validator


class BoardSummary(BaseModel):
    """Work item board summary for a project."""

    model_config = ConfigDict(extra="forbid")

    process_template: str = Field(description="Process template name (Agile, Scrum, CMMI, Basic)")
    total_work_items: int = Field(default=0, description="Total work items across all types")
    work_items_by_type: dict[str, int] = Field(
        default_factory=dict, description="Work item counts by type"
    )
    work_items_by_state: dict[str, int] = Field(
        default_factory=dict, description="Work item counts by state"
    )
    area_count: int = Field(default=0, description="Number of area paths")
    iteration_count: int = Field(default=0, description="Number of iteration paths")
    custom_field_count: int = Field(default=0, description="Number of custom fields")

    @field_validator("work_items_by_type", "work_items_by_state", mode="before")
    @classmethod
    def _coerce_none_keys(cls, v: dict[str | None, int] | None) -> dict[str, int]:
        """ADO Analytics OData API can return null for State/WorkItemType."""
        if not isinstance(v, dict):
            return {}
        result: dict[str, int] = {}
        for key, count in v.items():
            coerced = key.strip() if isinstance(key, str) and key.strip() else "Unknown"
            result[coerced] = result.get(coerced, 0) + count
        return result
