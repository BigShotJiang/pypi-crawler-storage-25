"""Pydantic models for Azure DevOps entities."""

from ado_source_core.models.artifact import ArtifactFeedInventoryItem
from ado_source_core.models.board import BoardSummary
from ado_source_core.models.inventory import (
    ComplexityLevel,
    ComplexityScore,
    Inventory,
    InventoryMetadata,
    InventorySummary,
    LargeFileInfo,
    LFSInfo,
    ProjectInventoryItem,
    RepositoryInventoryItem,
)
from ado_source_core.models.pipeline import (
    PipelineAnalysis,
    PipelineInventoryItem,
    PipelineMigrationComplexity,
    PipelineStepInfo,
    PipelineType,
    TaskSupportLevel,
)
from ado_source_core.models.repository import Repository
from ado_source_core.models.source_capabilities import SourceCapabilities, SourceType
from ado_source_core.models.test_plan import TestPlanInventoryItem
from ado_source_core.models.tfvc import TfvcSummary
from ado_source_core.models.user import User, UserEntitlementSummary

__all__ = [
    "ArtifactFeedInventoryItem",
    "BoardSummary",
    "ComplexityLevel",
    "ComplexityScore",
    "Inventory",
    "InventoryMetadata",
    "InventorySummary",
    "LFSInfo",
    "LargeFileInfo",
    "PipelineAnalysis",
    "PipelineInventoryItem",
    "PipelineMigrationComplexity",
    "PipelineStepInfo",
    "PipelineType",
    "ProjectInventoryItem",
    "Repository",
    "RepositoryInventoryItem",
    "SourceCapabilities",
    "SourceType",
    "TaskSupportLevel",
    "TestPlanInventoryItem",
    "TfvcSummary",
    "User",
    "UserEntitlementSummary",
]
