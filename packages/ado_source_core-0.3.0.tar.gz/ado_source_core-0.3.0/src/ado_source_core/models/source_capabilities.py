"""Source capability models shared by discovery, planning, and migration.

Lifted from `n8group-oss/ado2gh-core/src/ado2gh/models/source_capabilities.py`
@ `160de58` per Stage 1 sub-stage 1.1 task 1.1.5. Re-licensed BUSL-1.1 -> MIT
under the sole-author consent path documented in
`shyftport-specs/plans/audit/migration-core-base-decision.md` §5.

**Drift from the v0.2.x shape (introduced in v0.3.0):**

- ``supports_packages`` removed (replaced by ``supports_artifact_feeds``,
  functionally equivalent; renamed for on-prem clarity). BREAKING at the
  model level — consumers reading the field need to switch to the new name.
- New soft-capability flags: ``supports_graph_api``,
  ``supports_analytics_odata``, ``supports_artifact_feeds`` (default
  ``True`` so ``cloud_default`` doesn't have to spell them out).
- New ``server_default(api_version=...)`` classmethod for ADO Server.
- New ``with_overrides()`` method applying probe-discovered flag changes.
  Whitelist enforcement: only the three soft-capability fields are
  overridable; hard-False ``supports_user_entitlements`` cannot be flipped.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from enum import StrEnum
from typing import ClassVar

from pydantic import BaseModel, ConfigDict, Field


class SourceType(StrEnum):
    """Supported Azure DevOps source variants."""

    AZURE_DEVOPS_CLOUD = "azure-devops-cloud"
    AZURE_DEVOPS_SERVER = "azure-devops-server"


class SourceCapabilities(BaseModel):
    """Capability flags for a specific source adapter instance."""

    model_config = ConfigDict(extra="forbid")

    source_type: SourceType
    api_version: str = "7.1"
    supports_collections: bool = False
    supports_user_entitlements: bool = True
    supports_pipelines: bool = True
    supports_pull_request_threads: bool = True

    # Soft-capability flags — default True so cloud_default doesn't list them.
    # On Server, may be flipped to False by probe results via with_overrides().
    supports_graph_api: bool = True
    supports_analytics_odata: bool = True
    supports_artifact_feeds: bool = True

    compatibility_mode: bool = False
    notes: list[str] = Field(default_factory=list)

    OVERRIDABLE_SOFT_CAPABILITY_KEYS: ClassVar[frozenset[str]] = frozenset(
        {
            "supports_graph_api",
            "supports_analytics_odata",
            "supports_artifact_feeds",
        }
    )

    @classmethod
    def cloud_default(cls) -> SourceCapabilities:
        """Default capabilities for Azure DevOps Services."""
        return cls(source_type=SourceType.AZURE_DEVOPS_CLOUD)

    @classmethod
    def server_default(cls, *, api_version: str = "7.0") -> SourceCapabilities:
        """Conservative defaults for Azure DevOps Server.

        Hard-False on Server (cannot be flipped by ``with_overrides``):

        - ``supports_user_entitlements`` — vsaex Member Entitlements API
          is cloud-only.

        Probe-resolvable on Server (default ``True``; ``with_overrides``
        may flip based on optional-extension presence):

        - ``supports_graph_api``
        - ``supports_analytics_odata``
        - ``supports_artifact_feeds``

        ``compatibility_mode=True`` iff ``api_version`` is ``"5.0"``
        (Server 2019 RTW) or ``"5.1"`` (Server 2019 Update 1+). The notes
        list records which exact api-version triggered compatibility
        mode.
        """
        compatibility_mode = api_version in {"5.0", "5.1"}
        notes: list[str] = []
        if compatibility_mode:
            notes.append(f"Server 2019 compatibility mode enabled (api-version {api_version})")
        return cls(
            source_type=SourceType.AZURE_DEVOPS_SERVER,
            api_version=api_version,
            supports_collections=True,
            supports_user_entitlements=False,
            compatibility_mode=compatibility_mode,
            notes=notes,
        )

    def with_overrides(
        self,
        overrides: Mapping[str, bool],
        *,
        notes: Sequence[str] = (),
    ) -> SourceCapabilities:
        """Return a copy with whitelisted soft-capability overrides applied.

        Only ``OVERRIDABLE_SOFT_CAPABILITY_KEYS`` may be passed in
        ``overrides``; any other key (including hard-False
        ``supports_user_entitlements``) raises :class:`ValueError`.

        ``notes`` are appended to ``self.notes`` so probe-time diagnostics
        (e.g., PAT-scope ambiguity warnings) carry through to the
        capability set returned by ``adapter.get_capabilities()``.
        """
        unknown = set(overrides) - self.OVERRIDABLE_SOFT_CAPABILITY_KEYS
        if unknown:
            raise ValueError(
                f"with_overrides only accepts soft-capability keys "
                f"{sorted(self.OVERRIDABLE_SOFT_CAPABILITY_KEYS)}; "
                f"got disallowed keys: {sorted(unknown)}"
            )
        data = self.model_dump()
        data.update(overrides)
        if notes:
            data["notes"] = [*data.get("notes", []), *notes]
        return type(self).model_validate(data)
