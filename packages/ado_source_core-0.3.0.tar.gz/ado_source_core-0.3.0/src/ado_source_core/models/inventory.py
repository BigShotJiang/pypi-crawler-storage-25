"""Inventory models for ado-source-core discovery output.

Lifted from `n8group-oss/ado2gh-core/src/ado2gh/models/inventory.py` @ `160de58`
per Stage 1 sub-stage 1.1 task 1.1.5. Re-licensed BUSL-1.1 -> MIT.

Two mechanical adjustments at lift time:

1. Internal imports rewritten from `ado2gh.models.<X>` to
   `ado_source_core.models.<X>`.
2. The donor's `# noqa: TC001` / `# noqa: TC003` directives were dropped:
   ado-source-core's ruff config does not enable those checks (the donor's
   did), and the imports are unconditionally needed at runtime — Pydantic
   v2 introspects model annotations to build validators, so the imported
   types must live outside `TYPE_CHECKING`.
"""

from __future__ import annotations

import json
from datetime import datetime
from enum import StrEnum
from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field

from ado_source_core.models.artifact import ArtifactFeedInventoryItem
from ado_source_core.models.board import BoardSummary
from ado_source_core.models.pipeline import (
    PipelineAnalysis,
    PipelineInventoryItem,
    PipelineMigrationComplexity,
    PipelineType,
)
from ado_source_core.models.source_capabilities import SourceCapabilities
from ado_source_core.models.test_plan import TestPlanInventoryItem
from ado_source_core.models.tfvc import TfvcSummary
from ado_source_core.models.user import UserEntitlementSummary


class ComplexityLevel(StrEnum):
    """Complexity classification levels."""

    SIMPLE = "simple"
    MODERATE = "moderate"
    COMPLEX = "complex"


class ComplexityScore(BaseModel):
    """Complexity scoring result."""

    model_config = ConfigDict(extra="forbid")

    level: ComplexityLevel = Field(default=ComplexityLevel.SIMPLE)
    score: int = Field(default=0, ge=0, description="Numeric score 0-100")
    notes: list[str] = Field(default_factory=list, description="Scoring notes")


class LargeFileInfo(BaseModel):
    """Information about a large file in a repository."""

    model_config = ConfigDict(extra="forbid")

    path: str = Field(description="File path relative to repo root")
    size_bytes: int = Field(ge=0, description="File size in bytes")


class LFSInfo(BaseModel):
    """Git LFS usage information."""

    model_config = ConfigDict(extra="forbid")

    has_lfs: bool = Field(default=False, description="Whether repo uses LFS")
    patterns: list[str] = Field(default_factory=list, description="LFS tracked patterns")


class RepositoryInventoryItem(BaseModel):
    """Repository with analysis results for the inventory.

    Extends the base Repository fields with analysis data populated during
    discovery: branch/PR counts, complexity scoring, large file analysis, LFS info.
    """

    model_config = ConfigDict(extra="forbid")

    # Core identification (mirrors Repository)
    id: str
    name: str
    full_name: str
    description: str | None = None
    source: str = "azure-devops"
    project_name: str

    # Status (ADO-specific — NO "archived" field)
    is_disabled: bool = False
    is_in_maintenance: bool = False
    default_branch: str
    is_fork: bool = False

    # Size and metrics
    size_bytes: int | None = None
    branch_count: int | None = None
    pr_count: int | None = None

    # Clone URLs
    clone_url_https: str | None = None
    clone_url_ssh: str | None = None

    # Timestamps
    created_at: datetime | None = None
    updated_at: datetime | None = None

    # Analysis results (populated during discovery)
    complexity: ComplexityScore
    large_files: list[LargeFileInfo] = Field(default_factory=list)
    lfs: LFSInfo = Field(default_factory=LFSInfo)
    pipelines: PipelineAnalysis | None = None
    warnings: list[str] = Field(default_factory=list)


class InventoryMetadata(BaseModel):
    """Metadata about the inventory generation.

    `generated_by` defaults to ``"ado-source-core"`` (this library); callers
    that build inventories from a higher-level tool (e.g. ``ado-scanner``,
    ``ado2gh``, a Shyftport engine) should pass their own product name so
    consumers of the resulting JSON can tell which tool produced it.
    """

    model_config = ConfigDict(extra="forbid")

    schema_version: str = "1.0.0"
    generated_at: datetime
    generated_by: str = "ado-source-core"
    source_type: str = "azure-devops-cloud"
    organization: str
    project_filter: list[str] | None = None
    source_capabilities: SourceCapabilities | None = None


class InventorySummary(BaseModel):
    """Aggregated summary statistics for the inventory."""

    model_config = ConfigDict(extra="forbid")

    total_projects: int = 0
    total_projects_git: int = 0
    total_projects_tfvc: int = 0
    total_repositories: int = 0
    total_pipelines: int = 0
    total_pipelines_yaml: int = 0
    total_pipelines_classic_build: int = 0
    total_pipelines_classic_release: int = 0
    total_work_items: int = 0
    total_artifact_feeds: int = 0
    total_test_plans: int = 0
    total_size_bytes: int = 0
    total_service_connections: int = 0
    total_variable_groups: int = 0
    total_environments: int = 0
    complexity_simple: int = 0
    complexity_moderate: int = 0
    complexity_complex: int = 0
    repos_with_large_files: int = 0
    repos_with_lfs: int = 0
    repos_disabled: int = 0
    repos_with_pipelines: int = 0
    pipeline_complexity_trivial: int = 0
    pipeline_complexity_low: int = 0
    pipeline_complexity_medium: int = 0
    pipeline_complexity_high: int = 0
    total_pipeline_steps: int = 0
    total_pipeline_steps_supported: int = 0
    total_pipeline_steps_partially_supported: int = 0
    total_pipeline_steps_unsupported: int = 0
    total_pipeline_steps_script: int = 0
    total_users: int = 0
    total_warnings: int = 0


class ProjectInventoryItem(BaseModel):
    """All discovered entities for a single ADO project."""

    model_config = ConfigDict(extra="forbid")

    id: str
    name: str
    description: str | None = None
    state: str = "wellFormed"
    visibility: str = "private"
    vcs_type: str = Field(description="Version control type: 'Git' or 'Tfvc'")
    process_template: str = Field(default="Unknown", description="Process template name")

    repositories: list[RepositoryInventoryItem] = Field(default_factory=list)
    tfvc: TfvcSummary | None = None
    pipelines: list[PipelineInventoryItem] = Field(default_factory=list)
    boards: BoardSummary | None = None
    artifact_feeds: list[ArtifactFeedInventoryItem] = Field(default_factory=list)
    test_plans: list[TestPlanInventoryItem] = Field(default_factory=list)

    # Counts from pipeline discovery
    service_connection_count: int = 0
    variable_group_count: int = 0
    environment_count: int = 0

    created_at: datetime | None = None
    updated_at: datetime | None = None


class Inventory(BaseModel):
    """Root inventory model for a full organization discovery."""

    model_config = ConfigDict(extra="forbid")

    metadata: InventoryMetadata
    summary: InventorySummary
    projects: list[ProjectInventoryItem]
    user_summary: UserEntitlementSummary | None = None

    @classmethod
    def from_projects(  # noqa: PLR0912, PLR0915 - aggregation by design (lifted verbatim)
        cls,
        *,
        projects: list[ProjectInventoryItem],
        metadata: InventoryMetadata,
    ) -> Inventory:
        """Create an Inventory and calculate summary statistics from projects."""
        summary = InventorySummary()
        summary.total_projects = len(projects)

        for project in projects:
            # VCS type counts
            if project.vcs_type == "Git":
                summary.total_projects_git += 1
            elif project.vcs_type == "Tfvc":
                summary.total_projects_tfvc += 1

            # Repository stats
            summary.total_repositories += len(project.repositories)
            for repo in project.repositories:
                if repo.size_bytes is not None:
                    summary.total_size_bytes += repo.size_bytes
                if repo.is_disabled:
                    summary.repos_disabled += 1
                if repo.large_files:
                    summary.repos_with_large_files += 1
                if repo.lfs.has_lfs:
                    summary.repos_with_lfs += 1
                summary.total_warnings += len(repo.warnings)

                # Pipeline analysis distribution
                if repo.pipelines and repo.pipelines.has_pipelines:
                    summary.repos_with_pipelines += 1
                    summary.total_pipeline_steps += repo.pipelines.total_step_count
                    summary.total_pipeline_steps_supported += repo.pipelines.supported_step_count
                    summary.total_pipeline_steps_partially_supported += (
                        repo.pipelines.partially_supported_step_count
                    )
                    summary.total_pipeline_steps_unsupported += (
                        repo.pipelines.unsupported_step_count
                    )
                    summary.total_pipeline_steps_script += repo.pipelines.script_step_count
                    match repo.pipelines.migration_complexity:
                        case PipelineMigrationComplexity.TRIVIAL:
                            summary.pipeline_complexity_trivial += 1
                        case PipelineMigrationComplexity.LOW:
                            summary.pipeline_complexity_low += 1
                        case PipelineMigrationComplexity.MEDIUM:
                            summary.pipeline_complexity_medium += 1
                        case PipelineMigrationComplexity.HIGH:
                            summary.pipeline_complexity_high += 1

                # Complexity distribution
                if repo.complexity.level == ComplexityLevel.SIMPLE:
                    summary.complexity_simple += 1
                elif repo.complexity.level == ComplexityLevel.MODERATE:
                    summary.complexity_moderate += 1
                elif repo.complexity.level == ComplexityLevel.COMPLEX:
                    summary.complexity_complex += 1

            # Pipeline stats
            summary.total_pipelines += len(project.pipelines)
            for pipeline in project.pipelines:
                if pipeline.pipeline_type == PipelineType.YAML:
                    summary.total_pipelines_yaml += 1
                elif pipeline.pipeline_type == PipelineType.CLASSIC_BUILD:
                    summary.total_pipelines_classic_build += 1
                elif pipeline.pipeline_type == PipelineType.CLASSIC_RELEASE:
                    summary.total_pipelines_classic_release += 1

            # Board stats
            if project.boards:
                summary.total_work_items += project.boards.total_work_items

            # Other entity counts
            summary.total_artifact_feeds += len(project.artifact_feeds)
            summary.total_test_plans += len(project.test_plans)
            summary.total_service_connections += project.service_connection_count
            summary.total_variable_groups += project.variable_group_count
            summary.total_environments += project.environment_count

            # TFVC warnings
            if project.tfvc:
                summary.total_warnings += len(project.tfvc.warnings)

        return cls(
            metadata=metadata,
            summary=summary,
            projects=projects,
        )

    def to_json_file(self, path: str | Path) -> None:
        """Write inventory to a JSON file."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(self.model_dump_json(indent=2))

    @classmethod
    def from_json_file(cls, path: str | Path) -> Inventory:
        """Load inventory from a JSON file."""
        path = Path(path)
        data = json.loads(path.read_text())
        return cls.model_validate(data)
