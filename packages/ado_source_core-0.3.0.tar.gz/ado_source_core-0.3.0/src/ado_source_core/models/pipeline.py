"""Pipeline models for ado-source-core.

Lifted from `n8group-oss/ado2gh-core/src/ado2gh/models/pipeline.py` @ `160de58`
per Stage 1 sub-stage 1.1 task 1.1.5. Re-licensed BUSL-1.1 -> MIT.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class PipelineType(StrEnum):
    """Pipeline type classification."""

    YAML = "yaml"
    CLASSIC_BUILD = "classic_build"
    CLASSIC_RELEASE = "classic_release"
    DESIGNER = "designer"


class TaskSupportLevel(StrEnum):
    """Support level for an ADO task in GitHub Actions migration."""

    SUPPORTED = "supported"
    PARTIALLY_SUPPORTED = "partially_supported"
    UNSUPPORTED = "unsupported"
    SCRIPT = "script"


class PipelineStepInfo(BaseModel):
    """Individual step/task in a pipeline with its GitHub Actions mapping."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(description="Task reference e.g. 'DotNetCoreCLI@2' or 'script'")
    display_name: str | None = Field(default=None, description="Step display name")
    step_type: str = Field(
        description=(
            "Step type, e.g. 'task', 'script', 'bash', 'powershell', 'pwsh', "
            "'checkout', 'download', 'publish', 'template'"
        )
    )
    support_level: TaskSupportLevel = Field(description="GitHub Actions support level")
    github_action: str | None = Field(default=None, description="Equivalent GitHub Action")
    notes: str | None = Field(default=None, description="Migration notes for this step")


class PipelineMigrationComplexity(StrEnum):
    """Migration complexity classification for pipeline conversion."""

    TRIVIAL = "trivial"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class PipelineAnalysis(BaseModel):
    """Pipeline migration analysis results for a repository."""

    model_config = ConfigDict(extra="forbid")

    has_pipelines: bool = False
    total_step_count: int = Field(default=0, ge=0)
    supported_step_count: int = Field(default=0, ge=0)
    partially_supported_step_count: int = Field(default=0, ge=0)
    unsupported_step_count: int = Field(default=0, ge=0)
    script_step_count: int = Field(default=0, ge=0)
    migration_complexity: PipelineMigrationComplexity = PipelineMigrationComplexity.TRIVIAL
    migration_notes: list[str] = Field(default_factory=list)
    # Feature flags
    uses_caches: bool = False
    uses_services: bool = False
    uses_artifacts: bool = False
    uses_deployment_environments: bool = False
    uses_parallel_steps: bool = False
    uses_conditions: bool = False
    uses_docker: bool = False


class PipelineInventoryItem(BaseModel):
    """Pipeline inventory item."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(description="Pipeline definition ID")
    name: str = Field(description="Pipeline name")
    pipeline_type: PipelineType = Field(description="Pipeline type")
    project_name: str = Field(description="Parent project name")
    folder: str | None = Field(default=None, description="Pipeline folder path")
    has_triggers: bool = Field(default=False, description="Whether pipeline has triggers")
    repo_name: str | None = Field(default=None, description="Associated repository name")
    yaml_path: str | None = Field(default=None, description="YAML file path in repo")
    steps: list[PipelineStepInfo] = Field(default_factory=list, description="Analyzed steps")
    analysis: PipelineAnalysis | None = Field(
        default=None,
        description="Per-pipeline step analysis",
    )
