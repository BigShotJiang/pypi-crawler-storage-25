"""Repository data model for ado-source-core.

Lifted from `n8group-oss/ado2gh-core/src/ado2gh/models/repository.py` @
`160de58` per Stage 1 sub-stage 1.1 task 1.1.4 of
`n8group-oss/shyftport-specs:plans/2026-04-27-stage-1-pilot-extraction.md`
and the disentanglement audit (`shyftport-specs:plans/audit/read-only-modules.md`).

ado2gh-core is BUSL-1.1; this package is MIT. The lift is a re-license
of the model snippet; sole-author trail (Marcin Noczynski) verified at
lift time on the donor file. The donor's CHANGELOG records the lift.
"""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class Repository(BaseModel, frozen=True):
    """Base repository from a source system.

    Frozen (immutable) Pydantic model representing a git repository, used
    as the read-side base shape during discovery. Downstream applications
    can extend it with analysis results (complexity, large file scans,
    LFS detection, etc.) by subclassing or composition.

    Note: ADO has no "archived" concept. Repos use is_disabled (boolean)
    which is the closest equivalent. The bb2gh "archived" field is
    intentionally NOT present to avoid confusion.
    """

    model_config = ConfigDict(extra="forbid")

    # Core identification
    id: str = Field(description="Repository UUID")
    name: str = Field(description="Repository name/slug")
    full_name: str = Field(description="Full path (project/repo)")
    description: str | None = Field(default=None, description="Repository description")
    source: str = Field(default="azure-devops", description="Source system identifier")
    project_name: str = Field(description="ADO project name")

    # ADO-specific status fields (no "archived" — ADO uses is_disabled)
    is_disabled: bool = Field(default=False, description="ADO isDisabled flag")
    is_in_maintenance: bool = Field(default=False, description="ADO transient maintenance state")
    default_branch: str = Field(description="Default branch name")
    is_fork: bool = Field(default=False, description="Whether repository is a fork")

    # Size and metrics
    size_bytes: int | None = Field(default=None, ge=0, description="Repository size in bytes")

    # URLs
    clone_url_https: str | None = Field(default=None, description="HTTPS clone URL")
    clone_url_ssh: str | None = Field(default=None, description="SSH clone URL")

    # Timestamps
    created_at: datetime | None = Field(default=None, description="Creation timestamp")
    updated_at: datetime | None = Field(default=None, description="Last update timestamp")
