"""Artifact feed models for ado-source-core.

Lifted from `n8group-oss/ado2gh-core/src/ado2gh/models/artifact.py` @ `160de58`
per Stage 1 sub-stage 1.1 task 1.1.5. Re-licensed BUSL-1.1 -> MIT.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class ArtifactFeedInventoryItem(BaseModel):
    """Artifact feed inventory item."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(description="Feed ID")
    name: str = Field(description="Feed name")
    feed_type: str = Field(default="unknown", description="Feed type (npm, nuget, maven, etc.)")
    package_count: int = Field(default=0, description="Number of packages in feed")
    upstream_sources: list[str] = Field(default_factory=list, description="Upstream source names")
