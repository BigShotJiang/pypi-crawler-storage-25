"""TFVC models for ado-source-core.

Lifted from `n8group-oss/ado2gh-core/src/ado2gh/models/tfvc.py` @ `160de58`
per Stage 1 sub-stage 1.1 task 1.1.5. Re-licensed BUSL-1.1 -> MIT.

Donor's `# noqa: TC003` directive on the datetime import was dropped:
ado-source-core's ruff config does not enable TC003 (the donor's did),
and Pydantic v2 needs `datetime` importable at runtime to build validators.
"""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field


class TfvcSummary(BaseModel):
    """TFVC summary for a project that uses TFVC instead of Git."""

    total_changesets: int = Field(description="Number of changesets (commits equivalent)")
    latest_changeset_date: datetime | None = Field(
        default=None, description="Date of most recent changeset"
    )
    warnings: list[str] = Field(
        default_factory=lambda: ["TFVC requires git-tfs migration"],
        description="Warnings always includes TFVC migration note",
    )
