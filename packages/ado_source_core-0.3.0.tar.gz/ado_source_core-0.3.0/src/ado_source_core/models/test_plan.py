"""Test plan models for ado-source-core.

Lifted from `n8group-oss/ado2gh-core/src/ado2gh/models/test_plan.py` @ `160de58`
per Stage 1 sub-stage 1.1 task 1.1.5. Re-licensed BUSL-1.1 -> MIT.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class TestPlanInventoryItem(BaseModel):
    """Test plan inventory item."""

    __test__ = False  # Prevent pytest collection (class name starts with "Test")
    model_config = ConfigDict(extra="forbid")

    id: str = Field(description="Test plan ID")
    name: str = Field(description="Test plan name")
    test_suite_count: int = Field(default=0, description="Number of test suites")
    test_case_count: int = Field(default=0, description="Number of test cases")
    automated_count: int = Field(default=0, description="Number of automated test cases")
    manual_count: int = Field(default=0, description="Number of manual test cases")
