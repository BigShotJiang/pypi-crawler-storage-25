"""User and UserEntitlementSummary data models for ado-source-core.

Lifted from `n8group-oss/ado2gh-core/src/ado2gh/models/user.py` @ `160de58`
per Stage 1 sub-stage 1.1 task 1.1.5. Re-licensed BUSL-1.1 -> MIT under the
sole-author consent path documented in
`shyftport-specs/plans/audit/migration-core-base-decision.md` §5 (same
trail as the Repository lift in PR #3).
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class User(BaseModel, frozen=True):
    """User from a source or target system."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(description="User unique identifier")
    username: str = Field(description="Username / login")
    display_name: str | None = Field(default=None, description="Display name")
    email: str | None = Field(default=None, description="Email address")
    avatar_url: str | None = Field(default=None, description="Avatar URL")
    source: str = Field(default="azure-devops", description="Source system")


class UserEntitlementSummary(BaseModel):
    """Organization-level user entitlement summary by license type."""

    model_config = ConfigDict(extra="forbid")

    total_users: int = Field(default=0, ge=0)
    by_license_type: dict[str, int] = Field(default_factory=dict)
