"""Core HTTP client for the Azure DevOps REST API.

Lifted from ``n8group-oss/ado2gh-core/src/ado2gh/adapters/ado_cloud.py`` @
``160de58`` per Stage 1 sub-stage 1.1 task 1.1.9 of the Shyftport pilot
extraction (``shyftport-specs:plans/2026-04-27-stage-1-pilot-extraction.md``).

This module owns only the **transport layer**: 6 ``httpx.AsyncClient``
instances (one per ADO API host), the ``request`` method with automatic
retry, rate-limit, and error mapping to ``ado_source_core`` exceptions,
plus async-context-manager lifecycle. The 25+ domain methods that consume
``ADOClient`` (``list_projects``, ``list_repositories``, etc.) and produce
typed Pydantic results live on ``AzureDevOpsCloudAdapter`` and will land
in a follow-up PR (1.1.9b) to keep this PR reviewable.

ADO uses 6 hostnames for different concerns:

- ``dev.azure.com/{org}``        — main REST API (projects, repos, builds, work items)
- ``vsrm.dev.azure.com/{org}``   — release management
- ``feeds.dev.azure.com/{org}``  — artifact feeds
- ``analytics.dev.azure.com/{org}`` — Analytics OData (work item counts)
- ``vssps.dev.azure.com/{org}``  — Graph API (user identities)
- ``vsaex.dev.azure.com/{org}``  — Member Entitlements

All clients share the same authentication (``PATAuth``), default
``Accept: application/json`` header, and timeout.

**Class hierarchy (since v0.3.0):**

- ``BaseADOClient`` (abstract) — owns the ``request()`` retry / rate-limit /
  error-mapping loop, ``close()``, and the async context manager protocol.
- ``ADOCloudClient(BaseADOClient)`` — six pinned httpx clients for the
  cloud host fanout (``dev`` / ``vsrm`` / ``feeds`` / ``analytics`` /
  ``vssps`` / ``vsaex``); fixed ``api_version = "7.1"``.
- ``ADOServerClient(BaseADOClient)`` — single httpx client at the
  ``{base_url}/{collection}`` URL; auto-discovered ``api_version``.
- ``ADOClient = ADOCloudClient`` module-level alias preserves
  backwards compatibility for existing imports.

**Drift from previous shape:** the prior single concrete ``ADOClient`` class
is renamed to ``ADOCloudClient`` and the shared transport concerns are
extracted to ``BaseADOClient``. Existing call sites
(``ADOClient(organization=..., auth=...)``,
``client.request(method, url, host=...)``,
``client.httpx_client(host)``) work unchanged. Reflection-derived class
names (``type(client).__name__``) now return ``"ADOCloudClient"`` instead
of ``"ADOClient"`` — telemetry that keys on the old name needs updating.
"""

from __future__ import annotations

import asyncio
import logging
from abc import ABC, abstractmethod
from datetime import UTC, datetime
from email.utils import parsedate_to_datetime
from http import HTTPStatus
from types import MappingProxyType, TracebackType
from typing import TYPE_CHECKING, Any, Self
from urllib.parse import urlparse

import httpx

from ado_source_core.exceptions import (
    APIError,
    AuthenticationError,
    ConfigError,
    RateLimitError,
)

if TYPE_CHECKING:
    from collections.abc import Mapping

    from ado_source_core.auth import PATAuth

logger = logging.getLogger(__name__)

API_VERSION = "7.1"
"""Default ``api-version`` query parameter applied to every request."""

DEFAULT_TIMEOUT_SECONDS = 30.0
DEFAULT_MAX_RETRIES = 3
RESPONSE_BODY_MAX_BYTES = 4096
"""Cap on the size of the ``response_body`` text snippet preserved on
``APIError`` to keep error logs reasonably bounded when ADO returns a
huge HTML error page.

Note: applied to Python string slicing so the unit is *characters*, not
bytes despite the historical name. Non-ASCII content can therefore exceed
the byte bound by up to 4x under UTF-8. Kept named ``..._MAX_BYTES`` for
drop-in import parity with ``migration-core``; rename if/when both
libraries change the name in lockstep."""


def _parse_retry_after(value: str | None, *, attempt: int) -> float:
    """Parse a ``Retry-After`` header tolerantly.

    Per RFC 7231 the value is either an integer seconds count OR an
    HTTP-date. ADO almost always sends seconds, but some servers (and
    proxies) send a date string. If neither parse succeeds we fall back
    to exponential backoff (``2 ** attempt``) so a malformed header
    cannot crash the request loop.
    """
    if not value:
        return float(2**attempt)
    try:
        # Clamp at 0.0: ``Retry-After`` is defined as a non-negative delay
        # (RFC 7231 §7.1.3) and ``time.sleep(-1)`` raises, so a misbehaving
        # server emitting "-1" must not poison the retry loop.
        # Forward-backported from ``migration-core`` PR #7.
        return max(float(value), 0.0)
    except ValueError:
        pass
    try:
        when = parsedate_to_datetime(value)
        # ``parsedate_to_datetime`` may return a naive datetime if the
        # header had no timezone; treat it as UTC.
        if when.tzinfo is None:
            when = when.replace(tzinfo=UTC)
        delta = (when - datetime.now(tz=UTC)).total_seconds()
        return max(delta, 0.0)
    except (TypeError, ValueError):
        return float(2**attempt)


def _extract_response_body(response: httpx.Response) -> dict[str, Any]:
    """Best-effort capture of an error response body for ``APIError``.

    Tries to parse JSON first (the ADO REST API normally returns JSON
    error envelopes). Falls back to a ``{"text": <truncated>}`` shape so
    callers always get a structured ``response_body`` they can log or
    inspect, regardless of content type. Body text is truncated at
    :data:`RESPONSE_BODY_MAX_BYTES` characters to bound log size.
    """
    # ``httpx.ResponseNotRead`` is added to the catch-all so this helper is
    # safe to call from APIError construction even when the response body
    # was streamed and never read. Forward-backported from ``migration-core``
    # PR #7.
    try:
        parsed = response.json()
    except (ValueError, httpx.DecodingError, httpx.ResponseNotRead):
        parsed = None
    if isinstance(parsed, dict):
        return parsed
    try:
        text = response.text or ""
    except httpx.ResponseNotRead:
        text = ""
    truncated = text[:RESPONSE_BODY_MAX_BYTES]
    body: dict[str, Any] = {"text": truncated}
    if len(text) > RESPONSE_BODY_MAX_BYTES:
        body["truncated"] = True
        body["original_length"] = len(text)
    if parsed is not None:
        body["parsed"] = parsed
    return body


def _resolve_collection_base_url(base_url: str, collection: str) -> str:
    """Normalize ``{base_url}/{collection}`` into a single URL.

    Lifted from ``ado2gh-core/src/ado2gh/adapters/ado_server.py:18`` @
    ``160de58``. Drift: rejects embedded basic auth in ``base_url``
    (donor allowed it, which conflicts with the PAT ``Authorization``
    header and creates a credential-leak risk).

    Strips a trailing slash. If ``base_url`` already ends with
    ``/{collection}``, returns it unchanged (no double-suffixing).
    Raises :class:`ConfigError` if ``base_url`` contains embedded
    ``user:password@`` credentials.
    """
    parsed = urlparse(base_url)
    if parsed.username or parsed.password:
        raise ConfigError(
            "base_url must not contain embedded credentials "
            "(found user:password@host); use the `auth=` argument instead.",
            field="base_url",
        )
    root = base_url.rstrip("/")
    suffix = f"/{collection}"
    if root.endswith(suffix):
        return root
    return f"{root}{suffix}"


HostName = str
"""Type alias documenting the named hosts: ``dev`` / ``vsrm`` / ``feeds`` /
``analytics`` / ``vssps`` / ``vsaex``."""


class BaseADOClient(ABC):
    """Shared transport contract for ADO REST clients (cloud + server).

    Owns: ``request()`` retry+rate-limit+error-mapping loop, ``close()``
    over ``self._clients.values()`` (deduplicated), async context manager.

    Subclasses own: host-to-httpx-client routing (via ``_clients`` dict),
    api-version policy (via ``api_version`` abstract property), base URLs.
    """

    _clients: dict[HostName, httpx.AsyncClient]
    _max_retries: int

    @property
    @abstractmethod
    def api_version(self) -> str:
        """The api-version query-param value applied to every request."""

    def _select_client(self, host: HostName) -> httpx.AsyncClient:
        """Return the httpx client for a logical host name.

        Default: lookup in ``self._clients``. Subclasses with a single physical
        client (e.g., ``ADOServerClient``) can keep this default by aliasing
        all logical hosts to the same client in ``self._clients``.
        """
        return self._clients[host]

    def httpx_client(self, host: HostName = "dev") -> httpx.AsyncClient:
        """Return the underlying ``httpx.AsyncClient`` for a given host.

        Useful for the thin pagination iterators in
        ``ado_source_core.pagination`` that take a raw ``httpx.AsyncClient``
        — namely ``paginate_continuation_token`` and ``paginate_skip_top``.
        The ADOClient-aware paginators
        (``paginate_via_adoclient_continuation_token``,
        ``paginate_via_adoclient_skip_top``,
        ``paginate_via_adoclient_body_continuation_token``) take a
        ``BaseADOClient`` directly and do not need this accessor.

        On ``ADOServerClient``, every host name returns the same single
        client. Do NOT infer routing, TLS target, or endpoint family from
        ``client.httpx_client("vssps").base_url`` on Server — the
        collection URL is always returned regardless of host argument.
        """
        return self._select_client(host)

    async def request(
        self,
        method: str,
        url: str,
        *,
        host: HostName = "dev",
        params: Mapping[str, Any] | None = None,
        skip_api_version: bool = False,
        **kwargs: Any,
    ) -> httpx.Response:
        """Make an authenticated API request with retry + error mapping.

        - 401/403 -> ``AuthenticationError``
        - 429 -> retried up to ``max_retries`` honouring the ``Retry-After``
          header; raises ``RateLimitError`` once retries are exhausted.
        - 503 -> retried up to ``max_retries`` with exponential backoff.
        - Other ``httpx`` transport errors -> retried up to ``max_retries``,
          then ``APIError`` once exhausted.
        - Any other 4xx / 5xx -> ``APIError`` (no retry).
        """
        client = self._select_client(host)

        merged_params: dict[str, Any] = dict(params or {})
        if not skip_api_version:
            merged_params.setdefault("api-version", self.api_version)

        response: httpx.Response | None = None
        for attempt in range(self._max_retries):
            try:
                response = await client.request(method, url, params=merged_params, **kwargs)
            except httpx.HTTPError as exc:
                if attempt < self._max_retries - 1:
                    await asyncio.sleep(2**attempt)
                    continue
                raise APIError(f"Network error: {exc}", status_code=None) from exc

            if (
                response.status_code == HTTPStatus.SERVICE_UNAVAILABLE
                and attempt < self._max_retries - 1
            ):
                await asyncio.sleep(2**attempt)
                continue

            if response.status_code == HTTPStatus.TOO_MANY_REQUESTS:
                retry_after = _parse_retry_after(
                    response.headers.get("Retry-After"), attempt=attempt
                )
                if attempt < self._max_retries - 1:
                    await asyncio.sleep(retry_after)
                    continue
                raise RateLimitError(
                    "Azure DevOps rate limit exceeded",
                    status_code=int(HTTPStatus.TOO_MANY_REQUESTS),
                    response_body=_extract_response_body(response),
                    retry_after=retry_after,
                )

            break

        # Invariant: the loop above runs at least once because both
        # ADOCloudClient.__init__ and ADOServerClient.__init__ validate
        # ``max_retries >= 1`` and raise ``ValueError`` otherwise. That makes
        # ``response`` non-None on every reachable path through the loop
        # (either assigned successfully, or raised before the break).
        assert response is not None
        if response.status_code == HTTPStatus.UNAUTHORIZED:
            raise AuthenticationError(
                "Invalid PAT or insufficient permissions",
                status_code=int(HTTPStatus.UNAUTHORIZED),
                response_body=_extract_response_body(response),
            )
        if response.status_code == HTTPStatus.FORBIDDEN:
            raise AuthenticationError(
                "Access denied — check PAT scopes",
                status_code=int(HTTPStatus.FORBIDDEN),
                response_body=_extract_response_body(response),
            )
        if response.status_code >= HTTPStatus.BAD_REQUEST:
            raise APIError(
                "Azure DevOps API error",
                status_code=response.status_code,
                response_body=_extract_response_body(response),
            )
        return response

    async def close(self) -> None:
        """Close all underlying httpx clients (deduplicated). Resilient to partial failures."""
        seen: set[int] = set()
        for host, c in self._clients.items():
            if id(c) in seen:
                continue
            seen.add(id(c))
            try:
                await c.aclose()
            except Exception:
                logger.warning(
                    "Failed to close %s client (base_url=%s)",
                    host,
                    c.base_url,
                    exc_info=True,
                )

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.close()


class ADOCloudClient(BaseADOClient):
    """Concrete HTTP client for Azure DevOps Services (the cloud product).

    Manages one ``httpx.AsyncClient`` per ADO API host. Pinned api-version
    is the module-level ``API_VERSION`` constant (``"7.1"``).
    """

    def __init__(  # noqa: PLR0913 - configuration knobs are keyword-only
        self,
        *,
        organization: str,
        auth: PATAuth,
        base_url: str = "https://dev.azure.com",
        verify_ssl: bool | str = True,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        # Validate before constructing any httpx.AsyncClient so a misconfigured
        # caller fails fast without leaking sockets. ValueError (not ConfigError)
        # because this is an invalid programming argument, not a runtime
        # config-resolution issue.
        if max_retries < 1:
            raise ValueError(
                f"max_retries must be >= 1; got {max_retries}. "
                "BaseADOClient.request()'s retry loop requires at least one attempt."
            )
        self._organization = organization
        self._max_retries = max_retries

        common_kwargs: dict[str, Any] = {
            "headers": {"Accept": "application/json", **auth.headers()},
            "verify": verify_ssl,
            "timeout": timeout,
        }

        self._clients = {
            "dev": httpx.AsyncClient(base_url=f"{base_url}/{organization}", **common_kwargs),
            "vsrm": httpx.AsyncClient(
                base_url=f"https://vsrm.dev.azure.com/{organization}", **common_kwargs
            ),
            "feeds": httpx.AsyncClient(
                base_url=f"https://feeds.dev.azure.com/{organization}", **common_kwargs
            ),
            "analytics": httpx.AsyncClient(
                base_url=f"https://analytics.dev.azure.com/{organization}",
                **common_kwargs,
            ),
            "vssps": httpx.AsyncClient(
                base_url=f"https://vssps.dev.azure.com/{organization}", **common_kwargs
            ),
            "vsaex": httpx.AsyncClient(
                base_url=f"https://vsaex.dev.azure.com/{organization}", **common_kwargs
            ),
        }

    @property
    def api_version(self) -> str:
        return API_VERSION

    @property
    def organization(self) -> str:
        return self._organization


# Backwards-compatibility alias. Existing imports continue to work:
#   from ado_source_core.client import ADOClient
#   ado_source_core.ADOClient
# `isinstance(x, ADOClient)` matches cloud clients (alias preserves identity).
# Reflection-derived class names change: type(client).__name__ now returns
# "ADOCloudClient", not "ADOClient". See CHANGELOG [Unreleased].
ADOClient = ADOCloudClient


class ADOServerClient(BaseADOClient):
    """Concrete HTTP client for self-hosted Azure DevOps Server (on-prem).

    Single-host, collection-aware. The api-version is auto-discovered at
    ``connect()`` time via :mod:`ado_source_core.api_version_discovery`,
    or pinned explicitly by passing ``api_version=`` to ``__init__``.

    All six logical host names (``dev`` / ``vsrm`` / ``feeds`` /
    ``analytics`` / ``vssps`` / ``vsaex``) alias to the single underlying
    httpx client — calls that pass an explicit ``host=`` argument are
    route-safe but the URL is always the collection-scoped base.

    Two-phase init: ``__init__`` is sync and never makes HTTP calls;
    ``connect()`` runs the probe. The ``async with`` form runs
    ``connect()`` automatically via ``__aenter__``, with a ``try/except``
    wrapper that closes the httpx client and re-raises if the probe
    fails — preventing socket leaks on auth or network errors during
    context entry.
    """

    def __init__(  # noqa: PLR0913 - configuration knobs are keyword-only
        self,
        *,
        base_url: str,
        collection: str,
        auth: PATAuth,
        verify_ssl: bool | str = True,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
        max_retries: int = DEFAULT_MAX_RETRIES,
        api_version: str | None = None,
    ) -> None:
        # Validate before constructing the httpx.AsyncClient so a misconfigured
        # caller fails fast without leaking sockets. ValueError (not ConfigError)
        # because this is an invalid programming argument, not a runtime
        # config-resolution issue.
        if max_retries < 1:
            raise ValueError(
                f"max_retries must be >= 1; got {max_retries}. "
                "BaseADOClient.request()'s retry loop requires at least one attempt."
            )
        self._max_retries = max_retries
        self._collection = collection
        self._collection_base_url = _resolve_collection_base_url(base_url, collection)
        self._explicit_api_version = api_version
        self._resolved_api_version: str | None = api_version
        self._graph_api_version: str | None = None
        self._capability_overrides: dict[str, bool] = {}
        self._capability_notes: list[str] = []
        # Guards the probe section in connect() so concurrent callers don't
        # run duplicate probes or race on the writes to _resolved_api_version /
        # _capability_overrides / _capability_notes / _graph_api_version.
        self._connect_lock = asyncio.Lock()

        common_kwargs: dict[str, Any] = {
            "headers": {"Accept": "application/json", **auth.headers()},
            "verify": verify_ssl,
            "timeout": timeout,
        }
        single = httpx.AsyncClient(base_url=self._collection_base_url, **common_kwargs)
        # All logical hosts route to the same single httpx client. The
        # adapter is responsible for capability-gating any call that would
        # hit an endpoint missing on Server (vssps Graph, vsaex member
        # entitlements, analytics OData) BEFORE the request goes out.
        self._clients = {h: single for h in ("dev", "vsrm", "feeds", "analytics", "vssps", "vsaex")}

    @property
    def api_version(self) -> str:
        if self._resolved_api_version is None:
            raise RuntimeError(
                "ADOServerClient is not connected — use `async with` or call "
                "`await client.connect()` before issuing requests."
            )
        return self._resolved_api_version

    @property
    def resolved_api_version(self) -> str | None:
        """Diagnostic accessor: ``None`` until ``connect()`` runs (or until an
        explicit ``api_version=`` was passed to ``__init__``)."""
        return self._resolved_api_version

    @property
    def capability_overrides(self) -> Mapping[str, bool]:
        """Read-only view of probe-discovered soft-capability overrides.
        Empty until ``connect()`` runs."""
        return MappingProxyType(self._capability_overrides)

    @property
    def graph_api_version(self) -> str | None:
        """The api-version variant that worked for the Graph soft-cap probe
        (e.g. ``"7.0-preview.1"`` or plain ``"7.0"``). ``None`` until
        ``connect()`` runs OR when the Graph capability is False.

        Adapter-level callers (``list_users``) MUST use this value, not
        ``api_version``, to send requests to ``/_apis/graph/users``."""
        return self._graph_api_version

    @property
    def capability_notes(self) -> tuple[str, ...]:
        """Read-only view of probe-time diagnostic notes (e.g., PAT scope
        ambiguity warnings). Empty until ``connect()`` runs."""
        return tuple(self._capability_notes)

    @property
    def collection(self) -> str:
        return self._collection

    async def connect(self) -> None:
        """Run the api-version + soft-capability probe. Idempotent and
        concurrency-safe: concurrent callers serialize on
        ``self._connect_lock`` so only one probe runs per instance.

        Probe completion is tracked via ``_capability_overrides`` (always
        populated with the 3 soft-cap keys after a successful probe;
        empty until then). Using this as the "already probed" sentinel
        is correct on both paths — the explicit-``api_version=`` path
        also runs the soft-cap probes and writes into
        ``_capability_overrides``.
        """
        # Fast path: avoid taking the lock once the probe has completed.
        if self._capability_overrides:
            return
        async with self._connect_lock:
            # Re-check inside the lock: another coroutine may have
            # completed the probe while we were waiting on the lock.
            if self._capability_overrides:
                return
            if self._explicit_api_version is not None:
                # Explicit api_version=; still run soft-cap probes for
                # capability safety. Pre-fetch a project name for the
                # Analytics soft-cap probe's collection→project fallback.
                # On Server 2019, Analytics is commonly only project-scoped:
                # a None project_hint causes _probe_analytics to bail on
                # the collection-level 404 and falsely mark
                # supports_analytics_odata=False, so query_work_item_counts
                # would eager-raise even on installs where the working
                # project-scoped endpoint exists.
                from ado_source_core.api_version_discovery import (  # noqa: PLC0415
                    _fetch_first_project_name,
                    probe_soft_capabilities,
                )

                assert self._resolved_api_version is not None  # set in __init__
                project_hint = await _fetch_first_project_name(
                    self,
                    api_version=self._resolved_api_version,
                )
                overrides, notes, graph_api_version = await probe_soft_capabilities(
                    self,
                    api_version=self._resolved_api_version,
                    project_hint=project_hint,
                )
                self._capability_overrides = dict(overrides)
                self._capability_notes = list(notes)
                self._graph_api_version = graph_api_version
                return
            from ado_source_core.api_version_discovery import (  # noqa: PLC0415
                resolve_server_api_version,
            )

            result = await resolve_server_api_version(self)
            self._resolved_api_version = result.api_version
            self._graph_api_version = result.graph_api_version
            self._capability_overrides = dict(result.capability_overrides)
            self._capability_notes = list(result.capability_notes)

    async def __aenter__(self) -> Self:
        try:
            await self.connect()
        except BaseException:
            # Don't leak the httpx client built in __init__.
            await self.close()
            raise
        return self
