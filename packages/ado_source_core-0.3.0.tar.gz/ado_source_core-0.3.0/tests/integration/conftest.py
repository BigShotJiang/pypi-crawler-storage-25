"""Integration test fixtures.

Skips suites whose env vars are not populated. Both cloud and server suites
co-exist under one ``integration`` marker; each gates its fixtures on its
own env-var set, so ``pytest -m integration`` runs whichever has
credentials populated.
"""

from __future__ import annotations

import os
from collections.abc import AsyncIterator

import pytest
import pytest_asyncio

from ado_source_core import ADOClient, ADOServerClient, PATAuth


def _env_or_skip(name: str, *, suite: str = "integration") -> str:
    value = os.environ.get(name)
    if not value:
        pytest.skip(f"skipping {suite} integration tests: {name} not set")
    return value


# --- Cloud fixtures -----------------------------------------------------------


@pytest.fixture(scope="session")
def ado_org() -> str:
    return _env_or_skip("ADO_ORG", suite="cloud")


@pytest.fixture(scope="session")
def ado_pat() -> str:
    return _env_or_skip("ADO_PAT", suite="cloud")


@pytest_asyncio.fixture(scope="session", loop_scope="session")
async def client(ado_org: str, ado_pat: str) -> AsyncIterator[ADOClient]:
    """One ADOClient per session — avoids rebuilding 6 httpx clients per test."""
    async with ADOClient(organization=ado_org, auth=PATAuth(token=ado_pat)) as c:
        yield c


# --- Server fixtures ----------------------------------------------------------


@pytest.fixture(scope="session")
def ado_server_url() -> str:
    return _env_or_skip("ADO_SERVER_URL", suite="server")


@pytest.fixture(scope="session")
def ado_server_collection() -> str:
    return os.environ.get("ADO_SERVER_COLLECTION", "DefaultCollection")


@pytest.fixture(scope="session")
def ado_server_pat() -> str:
    return _env_or_skip("ADO_SERVER_PAT", suite="server")


@pytest.fixture(scope="session")
def ado_server_verify_ssl() -> bool | str:
    """TLS verification for the Server suite.

    - Unset / ``true`` / ``1`` / ``yes`` / ``on`` → ``True`` (default; verify)
    - ``false`` / ``0`` / ``no`` / ``off`` → ``False`` (skip verification; lab
      self-signed cert scenario)
    - Any other non-empty value → treated as a path to a CA bundle (passed
      through to ``httpx`` verbatim).
    """
    raw = os.environ.get("ADO_SERVER_VERIFY_SSL", "").strip()
    if not raw:
        return True
    lowered = raw.lower()
    if lowered in {"1", "true", "yes", "on"}:
        return True
    if lowered in {"0", "false", "no", "off"}:
        return False
    return raw  # treat as CA-bundle path


@pytest_asyncio.fixture(scope="session", loop_scope="session")
async def server_client(
    ado_server_url: str,
    ado_server_collection: str,
    ado_server_pat: str,
    ado_server_verify_ssl: bool | str,
) -> AsyncIterator[ADOServerClient]:
    """One ADOServerClient per session. __aenter__ runs the api-version
    + capability probe.

    For lab Server installs with self-signed certificates, set
    ``ADO_SERVER_VERIFY_SSL=false`` (or pass a path to a CA bundle).
    """
    async with ADOServerClient(
        base_url=ado_server_url,
        collection=ado_server_collection,
        auth=PATAuth(token=ado_server_pat),
        verify_ssl=ado_server_verify_ssl,
    ) as c:
        yield c
