"""Read-only smoke tests against a real Azure DevOps Server instance.

Gated by the ``integration`` pytest marker plus the env vars enforced in
``conftest.py``. Hits the real Server REST API but only via read endpoints,
so the suite is idempotent and safe to run repeatedly. The branch/PR-count
test caps repo discovery at ``_MAX_DISCOVERY_PROJECTS`` to keep API
traffic bounded on large collections.

Run locally::

    ADO_SERVER_URL=<url> ADO_SERVER_PAT=<pat> \\
      [ADO_SERVER_COLLECTION=<coll>] \\
      pytest tests/integration/test_smoke_server.py -m integration -v
"""

from __future__ import annotations

import pytest

from ado_source_core import (
    ADOServerClient,
    AzureDevOpsServerAdapter,
    Repository,
    UnsupportedOnAzureDevOpsServerError,
    User,
)

pytestmark = [
    pytest.mark.integration,
    pytest.mark.asyncio(loop_scope="session"),
]

_MAX_DISCOVERY_PROJECTS = 5


async def test_verify_credentials_succeeds(server_client: ADOServerClient) -> None:
    adapter = AzureDevOpsServerAdapter(client=server_client)
    assert await adapter.verify_credentials() is True


async def test_list_projects_returns_iterable(server_client: ADOServerClient) -> None:
    adapter = AzureDevOpsServerAdapter(client=server_client)
    projects = await adapter.list_projects()
    assert isinstance(projects, list)
    if not projects:
        pytest.skip("collection has no projects to query")
    first = projects[0]
    assert "id" in first
    assert "name" in first


async def test_list_repositories_for_first_project(
    server_client: ADOServerClient,
) -> None:
    adapter = AzureDevOpsServerAdapter(client=server_client)
    projects = await adapter.list_projects()
    if not projects:
        pytest.skip("collection has no projects to query")
    project_name = projects[0]["name"]
    repos = await adapter.list_repositories(project=project_name)
    assert isinstance(repos, list)
    for repo in repos:
        assert isinstance(repo, Repository)
        assert repo.source == "azure-devops"
        assert repo.project_name == project_name


async def test_count_branches_and_prs_for_first_repo(
    server_client: ADOServerClient,
) -> None:
    adapter = AzureDevOpsServerAdapter(client=server_client)
    projects = await adapter.list_projects()

    repo_for_counts: Repository | None = None
    project_name_for_counts: str | None = None
    for project in projects[:_MAX_DISCOVERY_PROJECTS]:
        repos = await adapter.list_repositories(project=project["name"])
        for repo in repos:
            if not repo.is_disabled:
                repo_for_counts = repo
                project_name_for_counts = project["name"]
                break
        if repo_for_counts is not None:
            break

    if repo_for_counts is None or project_name_for_counts is None:
        pytest.skip(
            f"no enabled repositories found in first {_MAX_DISCOVERY_PROJECTS} "
            "projects; cannot exercise counts"
        )

    repo_id = f"{project_name_for_counts}/{repo_for_counts.id}"
    branch_count = await adapter.count_branches(repo_id)
    pr_count = await adapter.count_pull_requests(repo_id)

    assert isinstance(branch_count, int)
    assert isinstance(pr_count, int)
    assert branch_count >= 0
    assert pr_count >= 0


async def test_list_users_or_assert_unsupported_when_graph_unavailable(
    server_client: ADOServerClient,
) -> None:
    """Drives a contract assertion either way — does NOT skip.

    If Graph is installed on this Server instance, expect User[] back.
    If not, expect UnsupportedOnAzureDevOpsServerError with the right
    capability + remediation fields.
    """
    adapter = AzureDevOpsServerAdapter(client=server_client)
    caps = await adapter.get_capabilities()
    if caps.supports_graph_api:
        users = await adapter.list_users()
        assert isinstance(users, list)
        for user in users:
            assert isinstance(user, User)
            assert user.source == "azure-devops"
    else:
        with pytest.raises(UnsupportedOnAzureDevOpsServerError) as exc_info:
            await adapter.list_users()
        assert exc_info.value.capability == "supports_graph_api"
        assert exc_info.value.api_version == caps.api_version
        assert exc_info.value.remediation is not None
        assert "Graph extension" in exc_info.value.remediation
