"""Pagination iterator tests."""

import asyncio

import httpx
import pytest
import respx

import ado_source_core
from ado_source_core import APIError, AuthenticationError, PATAuth, RateLimitError
from ado_source_core.client import ADOClient
from ado_source_core.pagination import (
    paginate_continuation_token,
    paginate_skip_top,
    paginate_via_adoclient_body_continuation_token,
    paginate_via_adoclient_continuation_token,
    paginate_via_adoclient_skip_top,
)

BASE = "https://dev.azure.com/myorg"
VSRM = "https://vsrm.dev.azure.com/myorg"
VSAEX = "https://vsaex.dev.azure.com/myorg"


class TestContinuationTokenPagination:
    @pytest.mark.asyncio
    async def test_follows_x_ms_continuationtoken_header(self) -> None:
        """Pages through until no continuation-token header is returned."""
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/projects").mock(
                side_effect=[
                    httpx.Response(
                        200,
                        headers={"x-ms-continuationtoken": "page2"},
                        json={"value": [{"id": "1"}, {"id": "2"}]},
                    ),
                    httpx.Response(200, json={"value": [{"id": "3"}]}),
                ]
            )
            async with httpx.AsyncClient(base_url=BASE) as client:
                results = [
                    item
                    async for item in paginate_continuation_token(
                        client, "/_apis/projects", params={"api-version": "7.1"}
                    )
                ]
            assert [r["id"] for r in results] == ["1", "2", "3"]

    @pytest.mark.asyncio
    async def test_handles_integer_continuation_token(self) -> None:
        """ADO Projects/Variable groups emit integer tokens; passed through as-is."""
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/projects").mock(
                side_effect=[
                    httpx.Response(
                        200,
                        headers={"x-ms-continuationtoken": "100"},
                        json={"value": [{"id": "1"}]},
                    ),
                    httpx.Response(200, json={"value": [{"id": "2"}]}),
                ]
            )
            async with httpx.AsyncClient(base_url=BASE) as client:
                results = [
                    item
                    async for item in paginate_continuation_token(
                        client, "/_apis/projects", params={"api-version": "7.1"}
                    )
                ]
            assert [r["id"] for r in results] == ["1", "2"]
            # Verify the token was forwarded on the second request
            second_request = mock.calls[1].request
            assert "continuationToken=100" in str(second_request.url)

    @pytest.mark.asyncio
    async def test_single_page_without_token_terminates_immediately(self) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/projects").mock(
                return_value=httpx.Response(200, json={"value": [{"id": "1"}]})
            )
            async with httpx.AsyncClient(base_url=BASE) as client:
                results = [
                    item async for item in paginate_continuation_token(client, "/_apis/projects")
                ]
            assert [r["id"] for r in results] == ["1"]
            assert mock.calls.call_count == 1

    @pytest.mark.asyncio
    async def test_empty_first_page_yields_nothing(self) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/projects").mock(return_value=httpx.Response(200, json={"value": []}))
            async with httpx.AsyncClient(base_url=BASE) as client:
                results = [
                    item async for item in paginate_continuation_token(client, "/_apis/projects")
                ]
            assert results == []

    @pytest.mark.asyncio
    async def test_raises_on_non_2xx(self) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/projects").mock(
                return_value=httpx.Response(500, json={"message": "boom"})
            )
            async with httpx.AsyncClient(base_url=BASE) as client:
                with pytest.raises(httpx.HTTPStatusError):
                    async for _ in paginate_continuation_token(client, "/_apis/projects"):
                        pass


class TestSkipTopPagination:
    @pytest.mark.asyncio
    async def test_increments_skip_until_empty_page(self) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/git/repositories/abc/pullrequests").mock(
                side_effect=[
                    httpx.Response(200, json={"value": [{"id": 1}, {"id": 2}]}),
                    httpx.Response(200, json={"value": [{"id": 3}]}),
                ]
            )
            async with httpx.AsyncClient(base_url=BASE) as client:
                results = [
                    item
                    async for item in paginate_skip_top(
                        client,
                        "/_apis/git/repositories/abc/pullrequests",
                        params={"api-version": "7.1"},
                        page_size=2,
                    )
                ]
            assert [r["id"] for r in results] == [1, 2, 3]

    @pytest.mark.asyncio
    async def test_short_page_terminates_without_extra_request(self) -> None:
        """When page is shorter than page_size, no further request is made."""
        with respx.mock(base_url=BASE) as mock:
            route = mock.get("/_apis/git/repositories/abc/pullrequests").mock(
                return_value=httpx.Response(200, json={"value": [{"id": 1}, {"id": 2}]})
            )
            async with httpx.AsyncClient(base_url=BASE) as client:
                results = [
                    item
                    async for item in paginate_skip_top(
                        client,
                        "/_apis/git/repositories/abc/pullrequests",
                        page_size=10,
                    )
                ]
            assert [r["id"] for r in results] == [1, 2]
            assert route.call_count == 1

    @pytest.mark.asyncio
    async def test_empty_first_page_yields_nothing(self) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/git/repositories/abc/pullrequests").mock(
                return_value=httpx.Response(200, json={"value": []})
            )
            async with httpx.AsyncClient(base_url=BASE) as client:
                results = [
                    item
                    async for item in paginate_skip_top(
                        client, "/_apis/git/repositories/abc/pullrequests"
                    )
                ]
            assert results == []

    @pytest.mark.asyncio
    async def test_skip_and_top_in_query_params(self) -> None:
        """Each request must carry the right $skip and $top values."""
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/git/repositories/abc/pullrequests").mock(
                side_effect=[
                    httpx.Response(200, json={"value": [{"id": 1}, {"id": 2}]}),
                    httpx.Response(200, json={"value": [{"id": 3}, {"id": 4}]}),
                    httpx.Response(200, json={"value": []}),
                ]
            )
            async with httpx.AsyncClient(base_url=BASE) as client:
                _ = [
                    item
                    async for item in paginate_skip_top(
                        client,
                        "/_apis/git/repositories/abc/pullrequests",
                        page_size=2,
                    )
                ]
            urls = [str(call.request.url) for call in mock.calls]
            assert "%24skip=0" in urls[0] and "%24top=2" in urls[0]
            assert "%24skip=2" in urls[1] and "%24top=2" in urls[1]
            assert "%24skip=4" in urls[2] and "%24top=2" in urls[2]

    @pytest.mark.asyncio
    async def test_raises_on_non_2xx(self) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/git/repositories/abc/pullrequests").mock(
                return_value=httpx.Response(500, json={"message": "boom"})
            )
            async with httpx.AsyncClient(base_url=BASE) as client:
                with pytest.raises(httpx.HTTPStatusError):
                    async for _ in paginate_skip_top(
                        client, "/_apis/git/repositories/abc/pullrequests"
                    ):
                        pass


class TestReExports:
    def test_paginators_re_exported_from_package_root(self) -> None:
        assert ado_source_core.paginate_continuation_token is paginate_continuation_token
        assert ado_source_core.paginate_skip_top is paginate_skip_top
        assert (
            ado_source_core.paginate_via_adoclient_body_continuation_token
            is paginate_via_adoclient_body_continuation_token
        )
        assert (
            ado_source_core.paginate_via_adoclient_continuation_token
            is paginate_via_adoclient_continuation_token
        )
        assert ado_source_core.paginate_via_adoclient_skip_top is paginate_via_adoclient_skip_top


async def _instant_sleep(_seconds: float) -> None:
    return None


@pytest.fixture
def _no_sleep(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(asyncio, "sleep", _instant_sleep)


def _make_client(*, max_retries: int = 3) -> ADOClient:
    return ADOClient(
        organization="myorg",
        auth=PATAuth(token="dummy-pat"),
        max_retries=max_retries,
    )


class TestADOClientContinuationToken:
    @pytest.mark.asyncio
    async def test_pages_until_no_header(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/projects").mock(
                side_effect=[
                    httpx.Response(
                        200,
                        headers={"x-ms-continuationtoken": "page2"},
                        json={"value": [{"id": "1"}, {"id": "2"}]},
                    ),
                    httpx.Response(200, json={"value": [{"id": "3"}]}),
                ]
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_continuation_token(
                        client, "/_apis/projects"
                    )
                ]
            assert [r["id"] for r in results] == ["1", "2", "3"]

    @pytest.mark.asyncio
    async def test_forwards_continuation_token_in_query(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/projects").mock(
                side_effect=[
                    httpx.Response(
                        200,
                        headers={"x-ms-continuationtoken": "100"},
                        json={"value": [{"id": "1"}]},
                    ),
                    httpx.Response(200, json={"value": [{"id": "2"}]}),
                ]
            )
            async with _make_client() as client:
                _ = [
                    item
                    async for item in paginate_via_adoclient_continuation_token(
                        client, "/_apis/projects"
                    )
                ]
            assert "continuationToken=100" in str(mock.calls[1].request.url)

    @pytest.mark.asyncio
    async def test_single_page_no_token_terminates_immediately(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            route = mock.get("/_apis/projects").mock(
                return_value=httpx.Response(200, json={"value": [{"id": "1"}]})
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_continuation_token(
                        client, "/_apis/projects"
                    )
                ]
            assert [r["id"] for r in results] == ["1"]
            assert route.call_count == 1

    @pytest.mark.asyncio
    async def test_empty_first_page_yields_nothing(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/projects").mock(return_value=httpx.Response(200, json={"value": []}))
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_continuation_token(
                        client, "/_apis/projects"
                    )
                ]
            assert results == []

    @pytest.mark.asyncio
    async def test_empty_value_with_token_continues(self, _no_sleep: None) -> None:
        """Termination is token-driven, not item-driven."""
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/projects").mock(
                side_effect=[
                    httpx.Response(
                        200,
                        headers={"x-ms-continuationtoken": "cursor"},
                        json={"value": []},
                    ),
                    httpx.Response(200, json={"value": [{"id": "1"}]}),
                ]
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_continuation_token(
                        client, "/_apis/projects"
                    )
                ]
            assert [r["id"] for r in results] == ["1"]

    @pytest.mark.asyncio
    async def test_401_raises_authentication_error(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/projects").mock(
                return_value=httpx.Response(401, json={"message": "nope"})
            )
            async with _make_client() as client:
                with pytest.raises(AuthenticationError):
                    async for _ in paginate_via_adoclient_continuation_token(
                        client, "/_apis/projects"
                    ):
                        pass

    @pytest.mark.asyncio
    async def test_500_raises_api_error(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/projects").mock(
                return_value=httpx.Response(500, json={"message": "boom"})
            )
            async with _make_client() as client:
                with pytest.raises(APIError):
                    async for _ in paginate_via_adoclient_continuation_token(
                        client, "/_apis/projects"
                    ):
                        pass

    @pytest.mark.asyncio
    async def test_429_exhausted_raises_rate_limit_error(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/projects").mock(
                return_value=httpx.Response(
                    429, headers={"Retry-After": "0"}, json={"message": "slow down"}
                )
            )
            async with _make_client(max_retries=1) as client:
                with pytest.raises(RateLimitError):
                    async for _ in paginate_via_adoclient_continuation_token(
                        client, "/_apis/projects"
                    ):
                        pass

    @pytest.mark.asyncio
    async def test_mid_iteration_429_retries_with_token(self, _no_sleep: None) -> None:
        """Page 2 returns 429 then succeeds; helper yields across the retry."""
        with respx.mock(base_url=BASE) as mock:
            route = mock.get("/_apis/projects").mock(
                side_effect=[
                    httpx.Response(
                        200,
                        headers={"x-ms-continuationtoken": "p2"},
                        json={"value": [{"id": "1"}]},
                    ),
                    httpx.Response(429, headers={"Retry-After": "0"}, json={}),
                    httpx.Response(200, json={"value": [{"id": "2"}]}),
                ]
            )
            async with _make_client(max_retries=3) as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_continuation_token(
                        client, "/_apis/projects"
                    )
                ]
            assert [r["id"] for r in results] == ["1", "2"]
            assert route.call_count == 3
            # continuationToken must be present on BOTH page-2 attempts
            assert "continuationToken=p2" in str(mock.calls[1].request.url)
            assert "continuationToken=p2" in str(mock.calls[2].request.url)

    @pytest.mark.asyncio
    async def test_mid_iteration_transport_error_retries(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/projects").mock(
                side_effect=[
                    httpx.Response(
                        200,
                        headers={"x-ms-continuationtoken": "p2"},
                        json={"value": [{"id": "1"}]},
                    ),
                    httpx.ConnectError("boom"),
                    httpx.Response(200, json={"value": [{"id": "2"}]}),
                ]
            )
            async with _make_client(max_retries=3) as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_continuation_token(
                        client, "/_apis/projects"
                    )
                ]
            assert [r["id"] for r in results] == ["1", "2"]

    @pytest.mark.asyncio
    async def test_transport_error_exhausted_raises_api_error(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get("/_apis/projects").mock(side_effect=httpx.ConnectError("boom"))
            async with _make_client(max_retries=2) as client:
                with pytest.raises(APIError):
                    async for _ in paginate_via_adoclient_continuation_token(
                        client, "/_apis/projects"
                    ):
                        pass

    @pytest.mark.asyncio
    async def test_api_version_overlay_survives(self, _no_sleep: None) -> None:
        """Caller-supplied api-version (e.g. for Graph API) must win."""
        with respx.mock(base_url=BASE) as mock:
            route = mock.get("/_apis/projects").mock(
                return_value=httpx.Response(200, json={"value": []})
            )
            async with _make_client() as client:
                _ = [
                    item
                    async for item in paginate_via_adoclient_continuation_token(
                        client,
                        "/_apis/projects",
                        params={"api-version": "7.1-preview.1"},
                    )
                ]
            assert "api-version=7.1-preview.1" in str(route.calls[0].request.url)
            assert "api-version=7.1&" not in str(route.calls[0].request.url)

    @pytest.mark.asyncio
    async def test_host_param_routes_correctly(self, _no_sleep: None) -> None:
        with respx.mock(base_url=VSRM) as mock:
            route = mock.get("/_apis/release/definitions").mock(
                return_value=httpx.Response(200, json={"value": [{"id": 1}]})
            )
            async with _make_client() as client:
                _ = [
                    item
                    async for item in paginate_via_adoclient_continuation_token(
                        client, "/_apis/release/definitions", host="vsrm"
                    )
                ]
            assert route.call_count == 1


class TestADOClientSkipTop:
    PATH = "/_apis/git/repositories/abc/pullrequests"

    @pytest.mark.asyncio
    async def test_increments_skip_until_short_page(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get(self.PATH).mock(
                side_effect=[
                    httpx.Response(200, json={"value": [{"id": 1}, {"id": 2}]}),
                    httpx.Response(200, json={"value": [{"id": 3}]}),
                ]
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_skip_top(
                        client, self.PATH, page_size=2
                    )
                ]
            assert [r["id"] for r in results] == [1, 2, 3]

    @pytest.mark.asyncio
    async def test_skip_and_top_increment_per_page(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get(self.PATH).mock(
                side_effect=[
                    httpx.Response(200, json={"value": [{"id": 1}, {"id": 2}]}),
                    httpx.Response(200, json={"value": [{"id": 3}, {"id": 4}]}),
                    httpx.Response(200, json={"value": []}),
                ]
            )
            async with _make_client() as client:
                _ = [
                    item
                    async for item in paginate_via_adoclient_skip_top(
                        client, self.PATH, page_size=2
                    )
                ]
            urls = [str(call.request.url) for call in mock.calls]
            assert "%24skip=0" in urls[0] and "%24top=2" in urls[0]
            assert "%24skip=2" in urls[1] and "%24top=2" in urls[1]
            assert "%24skip=4" in urls[2] and "%24top=2" in urls[2]

    @pytest.mark.asyncio
    async def test_short_first_page_terminates_without_extra_request(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            route = mock.get(self.PATH).mock(
                return_value=httpx.Response(200, json={"value": [{"id": 1}]})
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_skip_top(
                        client, self.PATH, page_size=10
                    )
                ]
            assert [r["id"] for r in results] == [1]
            assert route.call_count == 1

    @pytest.mark.asyncio
    async def test_empty_first_page_yields_nothing(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get(self.PATH).mock(return_value=httpx.Response(200, json={"value": []}))
            async with _make_client() as client:
                results = [
                    item async for item in paginate_via_adoclient_skip_top(client, self.PATH)
                ]
            assert results == []

    @pytest.mark.asyncio
    async def test_500_raises_api_error(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            mock.get(self.PATH).mock(return_value=httpx.Response(500, json={"message": "boom"}))
            async with _make_client() as client:
                with pytest.raises(APIError):
                    async for _ in paginate_via_adoclient_skip_top(client, self.PATH):
                        pass

    @pytest.mark.asyncio
    async def test_caller_params_preserved_alongside_skip_top(self, _no_sleep: None) -> None:
        with respx.mock(base_url=BASE) as mock:
            route = mock.get(self.PATH).mock(return_value=httpx.Response(200, json={"value": []}))
            async with _make_client() as client:
                _ = [
                    item
                    async for item in paginate_via_adoclient_skip_top(
                        client,
                        self.PATH,
                        params={"searchCriteria.status": "all"},
                        page_size=50,
                    )
                ]
            url = str(route.calls[0].request.url)
            assert "searchCriteria.status=all" in url
            assert "%24skip=0" in url
            assert "%24top=50" in url


class TestADOClientBodyContinuationToken:
    PATH = "/_apis/userentitlements"

    @pytest.mark.asyncio
    async def test_pages_until_no_body_token(self, _no_sleep: None) -> None:
        with respx.mock(base_url=VSAEX) as mock:
            mock.get(self.PATH).mock(
                side_effect=[
                    httpx.Response(
                        200,
                        json={
                            "items": [{"id": "u1"}, {"id": "u2"}],
                            "continuationToken": "cursor",
                        },
                    ),
                    httpx.Response(
                        200,
                        json={"items": [{"id": "u3"}], "continuationToken": ""},
                    ),
                ]
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_body_continuation_token(
                        client, self.PATH, host="vsaex"
                    )
                ]
            assert [r["id"] for r in results] == ["u1", "u2", "u3"]

    @pytest.mark.asyncio
    async def test_body_token_forwarded_in_query(self, _no_sleep: None) -> None:
        with respx.mock(base_url=VSAEX) as mock:
            mock.get(self.PATH).mock(
                side_effect=[
                    httpx.Response(
                        200,
                        json={"items": [{"id": "u1"}], "continuationToken": "abc123"},
                    ),
                    httpx.Response(200, json={"items": [], "continuationToken": ""}),
                ]
            )
            async with _make_client() as client:
                _ = [
                    item
                    async for item in paginate_via_adoclient_body_continuation_token(
                        client, self.PATH, host="vsaex"
                    )
                ]
            assert "continuationToken=abc123" in str(mock.calls[1].request.url)

    @pytest.mark.asyncio
    async def test_terminates_when_token_missing(self, _no_sleep: None) -> None:
        with respx.mock(base_url=VSAEX) as mock:
            route = mock.get(self.PATH).mock(
                return_value=httpx.Response(200, json={"items": [{"id": "u1"}]})
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_body_continuation_token(
                        client, self.PATH, host="vsaex"
                    )
                ]
            assert [r["id"] for r in results] == ["u1"]
            assert route.call_count == 1

    @pytest.mark.asyncio
    async def test_terminates_when_token_none(self, _no_sleep: None) -> None:
        with respx.mock(base_url=VSAEX) as mock:
            mock.get(self.PATH).mock(
                return_value=httpx.Response(
                    200, json={"items": [{"id": "u1"}], "continuationToken": None}
                )
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_body_continuation_token(
                        client, self.PATH, host="vsaex"
                    )
                ]
            assert [r["id"] for r in results] == ["u1"]

    @pytest.mark.asyncio
    async def test_empty_items_with_token_continues(self, _no_sleep: None) -> None:
        with respx.mock(base_url=VSAEX) as mock:
            mock.get(self.PATH).mock(
                side_effect=[
                    httpx.Response(200, json={"items": [], "continuationToken": "cursor"}),
                    httpx.Response(200, json={"items": [{"id": "u1"}], "continuationToken": ""}),
                ]
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_body_continuation_token(
                        client, self.PATH, host="vsaex"
                    )
                ]
            assert [r["id"] for r in results] == ["u1"]

    @pytest.mark.asyncio
    async def test_items_key_string_value(self, _no_sleep: None) -> None:
        """`items_key='value'` works for endpoints that key body-token data under value."""
        with respx.mock(base_url=VSAEX) as mock:
            mock.get(self.PATH).mock(
                return_value=httpx.Response(
                    200, json={"value": [{"id": "u1"}], "continuationToken": ""}
                )
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_body_continuation_token(
                        client, self.PATH, host="vsaex", items_key="value"
                    )
                ]
            assert [r["id"] for r in results] == ["u1"]

    @pytest.mark.asyncio
    async def test_items_key_sequence_walks_fallback_chain(self, _no_sleep: None) -> None:
        """Older response shape: `members` instead of `items`."""
        with respx.mock(base_url=VSAEX) as mock:
            mock.get(self.PATH).mock(
                return_value=httpx.Response(
                    200,
                    json={"members": [{"id": "u1"}], "continuationToken": ""},
                )
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_body_continuation_token(
                        client,
                        self.PATH,
                        host="vsaex",
                        items_key=("items", "members"),
                    )
                ]
            assert [r["id"] for r in results] == ["u1"]

    @pytest.mark.asyncio
    async def test_items_key_sequence_prefers_first_present_key(self, _no_sleep: None) -> None:
        with respx.mock(base_url=VSAEX) as mock:
            mock.get(self.PATH).mock(
                return_value=httpx.Response(
                    200,
                    json={
                        "items": [{"id": "from-items"}],
                        "members": [{"id": "from-members"}],
                        "continuationToken": "",
                    },
                )
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_body_continuation_token(
                        client,
                        self.PATH,
                        host="vsaex",
                        items_key=("items", "members"),
                    )
                ]
            assert [r["id"] for r in results] == ["from-items"]

    @pytest.mark.asyncio
    async def test_header_token_is_not_consulted(self, _no_sleep: None) -> None:
        """Body helper ignores `x-ms-continuationtoken`; only body token drives it."""
        with respx.mock(base_url=VSAEX) as mock:
            route = mock.get(self.PATH).mock(
                return_value=httpx.Response(
                    200,
                    headers={"x-ms-continuationtoken": "would-loop-forever"},
                    json={"items": [{"id": "u1"}]},
                )
            )
            async with _make_client() as client:
                results = [
                    item
                    async for item in paginate_via_adoclient_body_continuation_token(
                        client, self.PATH, host="vsaex"
                    )
                ]
            assert [r["id"] for r in results] == ["u1"]
            assert route.call_count == 1

    @pytest.mark.asyncio
    async def test_401_raises_authentication_error(self, _no_sleep: None) -> None:
        with respx.mock(base_url=VSAEX) as mock:
            mock.get(self.PATH).mock(return_value=httpx.Response(401, json={"message": "nope"}))
            async with _make_client() as client:
                with pytest.raises(AuthenticationError):
                    async for _ in paginate_via_adoclient_body_continuation_token(
                        client, self.PATH, host="vsaex"
                    ):
                        pass
