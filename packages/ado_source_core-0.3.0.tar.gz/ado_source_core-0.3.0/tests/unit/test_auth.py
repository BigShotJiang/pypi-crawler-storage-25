"""PAT authentication tests."""

import base64
import dataclasses

import pytest

import ado_source_core
from ado_source_core.auth import PATAuth


class TestPATAuthHeaders:
    def test_produces_basic_auth_header(self) -> None:
        auth = PATAuth(token="my-pat")
        headers = auth.headers()
        assert "Authorization" in headers
        # ADO uses Basic auth with empty username and PAT as password:
        # base64(":my-pat") = "Om15LXBhdA=="
        assert headers["Authorization"] == "Basic Om15LXBhdA=="

    def test_header_round_trips_back_to_token(self) -> None:
        auth = PATAuth(token="some-token-with-special-chars-=+/!")
        encoded = auth.headers()["Authorization"].removeprefix("Basic ")
        decoded = base64.b64decode(encoded).decode()
        assert decoded == ":some-token-with-special-chars-=+/!"

    def test_only_authorization_header_returned(self) -> None:
        auth = PATAuth(token="abc")
        assert list(auth.headers().keys()) == ["Authorization"]


class TestPATAuthRepr:
    def test_repr_redacts_token(self) -> None:
        auth = PATAuth(token="my-secret-pat")
        assert "my-secret-pat" not in repr(auth)
        assert "redacted" in repr(auth).lower()

    def test_str_redacts_token(self) -> None:
        auth = PATAuth(token="another-secret")
        assert "another-secret" not in str(auth)


class TestPATAuthFrozen:
    def test_is_dataclass(self) -> None:
        auth = PATAuth(token="t1")
        assert dataclasses.is_dataclass(auth)

    def test_token_immutable(self) -> None:
        auth = PATAuth(token="t1")
        with pytest.raises(dataclasses.FrozenInstanceError):
            auth.token = "t2"  # type: ignore[misc]
        assert auth.token == "t1"


class TestPATAuthReExport:
    def test_re_exported_from_package_root(self) -> None:
        assert ado_source_core.PATAuth is PATAuth
