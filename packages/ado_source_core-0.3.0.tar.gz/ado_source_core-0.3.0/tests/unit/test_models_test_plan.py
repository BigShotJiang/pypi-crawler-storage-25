"""TestPlanInventoryItem model tests."""

import pytest
from pydantic import ValidationError

import ado_source_core
from ado_source_core.models import TestPlanInventoryItem


def test_test_plan_minimal() -> None:
    plan = TestPlanInventoryItem(id="tp1", name="My Plan")
    assert plan.id == "tp1"
    assert plan.test_suite_count == 0


def test_test_plan_extra_rejected() -> None:
    with pytest.raises(ValidationError):
        TestPlanInventoryItem(id="tp1", name="My Plan", unknown="x")  # type: ignore[call-arg]


def test_test_plan_not_collected_by_pytest() -> None:
    """The model class itself must not be auto-collected as a pytest test class."""
    assert TestPlanInventoryItem.__test__ is False


def test_test_plan_re_exported() -> None:
    assert ado_source_core.TestPlanInventoryItem is TestPlanInventoryItem
