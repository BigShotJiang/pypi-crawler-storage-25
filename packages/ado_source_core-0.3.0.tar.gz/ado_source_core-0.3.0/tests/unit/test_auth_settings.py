"""Tests for ADOCredentialSettings + credential resolver helpers (audit §3.B + §3.D)."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

import ado_source_core
from ado_source_core.auth import (
    _ORG_ENV_KEYS,
    _PAT_ENV_KEYS,
    DEFAULT_ADO_BASE_URL,
    ADOCredentialSettings,
    _clean_env_value,
    _is_frozen,
    _mask,
    _resolve_env_preferred_value,
    _resolve_generic_env_value,
    parse_env_file,
    resolve_ado_credentials,
)
from ado_source_core.exceptions import ConfigError

_ADO_ENV_KEYS = (
    "ADO_PAT",
    "ADO2GH_PAT",
    "ADO_ORGANIZATION",
    "ADO2GH_ORGANIZATION",
)


@pytest.fixture(autouse=True)
def _clear_ado_env(monkeypatch: pytest.MonkeyPatch) -> None:
    for key in _ADO_ENV_KEYS:
        monkeypatch.delenv(key, raising=False)


class TestADOCredentialSettingsDefaults:
    def test_all_fields_default_to_none(self) -> None:
        settings = ADOCredentialSettings()
        assert settings.ado_pat is None
        assert settings.ado_organization is None


class TestADOCredentialSettingsAliases:
    def test_ado_pat_alias(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("ADO_PAT", "primary")
        settings = ADOCredentialSettings()
        assert settings.ado_pat is not None
        assert settings.ado_pat.get_secret_value() == "primary"

    def test_ado2gh_pat_alias(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("ADO2GH_PAT", "fallback")
        settings = ADOCredentialSettings()
        assert settings.ado_pat is not None
        assert settings.ado_pat.get_secret_value() == "fallback"

    def test_ado_pat_takes_precedence_over_ado2gh_pat(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("ADO_PAT", "primary")
        monkeypatch.setenv("ADO2GH_PAT", "fallback")
        settings = ADOCredentialSettings()
        assert settings.ado_pat is not None
        assert settings.ado_pat.get_secret_value() == "primary"

    def test_ado_organization_alias(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("ADO_ORGANIZATION", "myorg")
        settings = ADOCredentialSettings()
        assert settings.ado_organization == "myorg"

    def test_ado2gh_organization_alias(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("ADO2GH_ORGANIZATION", "myorg-fallback")
        settings = ADOCredentialSettings()
        assert settings.ado_organization == "myorg-fallback"


class TestADOCredentialSettingsSecretMasking:
    def test_repr_does_not_leak_pat(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("ADO_PAT", "super-secret-pat-value")
        settings = ADOCredentialSettings()
        assert "super-secret-pat-value" not in repr(settings)
        assert "super-secret-pat-value" not in str(settings)


class TestCleanEnvValue:
    def test_strips_straight_double_quotes(self) -> None:
        assert _clean_env_value('"hello"') == "hello"

    def test_strips_straight_single_quotes(self) -> None:
        assert _clean_env_value("'hello'") == "hello"

    def test_strips_smart_quotes(self) -> None:
        assert _clean_env_value("“hello”") == "hello"
        assert _clean_env_value("‘hello’") == "hello"  # noqa: RUF001 - intentional smart quotes

    def test_strips_backticks(self) -> None:
        assert _clean_env_value("`hello`") == "hello"

    def test_strips_surrounding_whitespace(self) -> None:
        assert _clean_env_value("  hello  ") == "hello"

    def test_strips_trailing_newline(self) -> None:
        assert _clean_env_value("hello\n") == "hello"


class TestMask:
    def test_short_value_returns_stars(self) -> None:
        assert _mask("abc") == "***"
        assert _mask("12345678") == "***"

    def test_long_value_keeps_first_and_last_4(self) -> None:
        assert _mask("abcdefghij") == "abcd...ghij"

    def test_exactly_9_chars(self) -> None:
        assert _mask("abcdefghi") == "abcd...fghi"


class TestIsFrozen:
    def test_returns_false_under_pytest(self) -> None:
        assert _is_frozen() is False

    def test_returns_true_when_frozen_attrs_set(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.setattr(sys, "frozen", True, raising=False)
        monkeypatch.setattr(sys, "_MEIPASS", str(tmp_path), raising=False)
        assert _is_frozen() is True


class TestParseEnvFile:
    def test_missing_file_returns_empty_dict(self, tmp_path: Path) -> None:
        assert parse_env_file(tmp_path / "absent.env") == {}

    def test_plain_key_value(self, tmp_path: Path) -> None:
        env = tmp_path / ".env"
        env.write_text("FOO=bar\n", encoding="utf-8")
        assert parse_env_file(env) == {"FOO": "bar"}

    def test_double_quoted_value_strips_quotes(self, tmp_path: Path) -> None:
        env = tmp_path / ".env"
        env.write_text('FOO="bar"\n', encoding="utf-8")
        assert parse_env_file(env) == {"FOO": "bar"}

    def test_single_quoted_value_strips_quotes(self, tmp_path: Path) -> None:
        env = tmp_path / ".env"
        env.write_text("FOO='bar'\n", encoding="utf-8")
        assert parse_env_file(env) == {"FOO": "bar"}

    def test_export_prefix_stripped(self, tmp_path: Path) -> None:
        env = tmp_path / ".env"
        env.write_text("export FOO=bar\n", encoding="utf-8")
        assert parse_env_file(env) == {"FOO": "bar"}

    def test_comments_and_blank_lines_ignored(self, tmp_path: Path) -> None:
        env = tmp_path / ".env"
        env.write_text(
            "# comment line\n\nFOO=bar\n   \n# another\nBAZ=qux\n",
            encoding="utf-8",
        )
        assert parse_env_file(env) == {"FOO": "bar", "BAZ": "qux"}

    def test_lines_without_equals_skipped(self, tmp_path: Path) -> None:
        env = tmp_path / ".env"
        env.write_text("NOT_A_KV_LINE\nFOO=bar\n", encoding="utf-8")
        assert parse_env_file(env) == {"FOO": "bar"}

    def test_empty_key_skipped(self, tmp_path: Path) -> None:
        env = tmp_path / ".env"
        env.write_text("=value\nFOO=bar\n", encoding="utf-8")
        assert parse_env_file(env) == {"FOO": "bar"}

    def test_non_utf8_bytes_returns_empty_dict(self, tmp_path: Path) -> None:
        # Donor's tolerant fallback: a corrupted .env (non-UTF8 bytes) must not
        # crash credential resolution — return {} so the caller falls back to
        # os.environ. Latin-1 ý (0xfd) is invalid UTF-8.
        env = tmp_path / ".env"
        env.write_bytes(b"FOO=\xfd\xfd\xfd\n")
        assert parse_env_file(env) == {}

    def test_value_containing_equals_signs(self, tmp_path: Path) -> None:
        # ADO PATs can include "=" characters; partition("=") must split on
        # the FIRST "=" only and preserve the rest of the value verbatim.
        env = tmp_path / ".env"
        env.write_text("FOO=a=b=c\n", encoding="utf-8")
        assert parse_env_file(env) == {"FOO": "a=b=c"}

    def test_unbalanced_leading_quote_preserved(self, tmp_path: Path) -> None:
        # Quote-pair stripping requires both ends to match; a single dangling
        # quote is preserved verbatim (donor behavior).
        env = tmp_path / ".env"
        env.write_text('FOO="unbalanced\n', encoding="utf-8")
        assert parse_env_file(env) == {"FOO": '"unbalanced'}


class TestResolveGenericEnvValue:
    def test_returns_none_when_no_keys_present(self) -> None:
        assert _resolve_generic_env_value(("FOO", "BAR"), {}) is None

    def test_env_beats_env_file(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("FOO_TEST_KEY", "from-env")
        result = _resolve_generic_env_value(("FOO_TEST_KEY",), {"FOO_TEST_KEY": "from-file"})
        assert result == "from-env"

    def test_env_file_used_when_env_unset(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("FOO_TEST_KEY", raising=False)
        result = _resolve_generic_env_value(("FOO_TEST_KEY",), {"FOO_TEST_KEY": "from-file"})
        assert result == "from-file"

    def test_first_key_wins(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("PRIMARY_KEY", "primary-val")
        monkeypatch.setenv("SECONDARY_KEY", "secondary-val")
        result = _resolve_generic_env_value(("PRIMARY_KEY", "SECONDARY_KEY"), {})
        assert result == "primary-val"

    def test_frozen_flips_precedence_to_file_first(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.setattr(sys, "frozen", True, raising=False)
        monkeypatch.setattr(sys, "_MEIPASS", str(tmp_path), raising=False)
        monkeypatch.setenv("FOO_FROZEN_KEY", "from-env")
        result = _resolve_generic_env_value(("FOO_FROZEN_KEY",), {"FOO_FROZEN_KEY": "from-file"})
        assert result == "from-file"


class TestResolveEnvPreferredValue:
    def test_primary_env_beats_fallback_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("P_KEY", "primary-env")
        monkeypatch.setenv("F_KEY", "fallback-env")
        result = _resolve_env_preferred_value(("P_KEY",), ("F_KEY",), {})
        assert result == "primary-env"

    def test_primary_file_beats_fallback_env_when_primary_env_unset(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.delenv("P_KEY", raising=False)
        monkeypatch.setenv("F_KEY", "fallback-env")
        result = _resolve_env_preferred_value(("P_KEY",), ("F_KEY",), {"P_KEY": "primary-file"})
        assert result == "primary-file"

    def test_fallback_env_beats_fallback_file(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("P_KEY", raising=False)
        monkeypatch.setenv("F_KEY", "fallback-env")
        result = _resolve_env_preferred_value(("P_KEY",), ("F_KEY",), {"F_KEY": "fallback-file"})
        assert result == "fallback-env"

    def test_returns_none_when_nothing_present(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("P_KEY", raising=False)
        monkeypatch.delenv("F_KEY", raising=False)
        assert _resolve_env_preferred_value(("P_KEY",), ("F_KEY",), {}) is None

    def test_frozen_returns_primary_file_first(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.setattr(sys, "frozen", True, raising=False)
        monkeypatch.setattr(sys, "_MEIPASS", str(tmp_path), raising=False)
        monkeypatch.setenv("P_KEY", "primary-env")
        result = _resolve_env_preferred_value(("P_KEY",), ("F_KEY",), {"P_KEY": "primary-file"})
        assert result == "primary-file"


class TestResolveADOCredentials:
    def test_happy_path_from_env(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("ADO_PAT", "pat-from-env")
        monkeypatch.setenv("ADO_ORGANIZATION", "org-from-env")
        result = resolve_ado_credentials()
        assert result == {"pat": "pat-from-env", "organization": "org-from-env"}

    def test_happy_path_from_env_file(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        env = tmp_path / ".env"
        env.write_text("ADO_PAT=pat-from-file\nADO_ORGANIZATION=org-from-file\n")
        monkeypatch.chdir(tmp_path)
        result = resolve_ado_credentials()
        assert result == {"pat": "pat-from-file", "organization": "org-from-file"}

    def test_env_beats_env_file(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        env = tmp_path / ".env"
        env.write_text("ADO_PAT=pat-from-file\nADO_ORGANIZATION=org-from-file\n")
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("ADO_PAT", "pat-from-env")
        monkeypatch.setenv("ADO_ORGANIZATION", "org-from-env")
        result = resolve_ado_credentials()
        assert result == {"pat": "pat-from-env", "organization": "org-from-env"}

    def test_ado2gh_alias_used_as_fallback(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("ADO2GH_PAT", "pat-fallback")
        monkeypatch.setenv("ADO2GH_ORGANIZATION", "org-fallback")
        result = resolve_ado_credentials()
        assert result == {"pat": "pat-fallback", "organization": "org-fallback"}

    def test_explicit_organization_argument_overrides_env(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("ADO_PAT", "pat-from-env")
        monkeypatch.setenv("ADO_ORGANIZATION", "ignored-org")
        result = resolve_ado_credentials(organization="explicit-org")
        assert result == {"pat": "pat-from-env", "organization": "explicit-org"}

    def test_missing_pat_raises_config_error(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("ADO_ORGANIZATION", "org")
        with pytest.raises(ConfigError, match="PAT not found"):
            resolve_ado_credentials()

    def test_missing_organization_raises_config_error(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("ADO_PAT", "pat")
        with pytest.raises(ConfigError, match="organization not found"):
            resolve_ado_credentials()

    def test_non_ascii_pat_raises_config_error(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.chdir(tmp_path)
        # Smart quotes simulate the macOS copy-paste corruption case.
        monkeypatch.setenv("ADO_PAT", "pat-with-“smart-quotes”-inside")
        monkeypatch.setenv("ADO_ORGANIZATION", "org")
        with pytest.raises(ConfigError, match="non-ASCII"):
            resolve_ado_credentials()

    def test_pat_quotes_are_stripped(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        env = tmp_path / ".env"
        env.write_text('ADO_PAT="quoted-pat"\nADO_ORGANIZATION="quoted-org"\n')
        monkeypatch.chdir(tmp_path)
        result = resolve_ado_credentials()
        assert result == {"pat": "quoted-pat", "organization": "quoted-org"}

    def test_explicit_organization_argument_overrides_env_file(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        env = tmp_path / ".env"
        env.write_text("ADO_PAT=pat\nADO_ORGANIZATION=ignored-from-file\n")
        monkeypatch.chdir(tmp_path)
        result = resolve_ado_credentials(organization="explicit-org")
        assert result == {"pat": "pat", "organization": "explicit-org"}

    def test_frozen_mode_env_file_pat_wins_over_env_var(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        # Locks the public-API contract: under PyInstaller, .env beats env vars.
        monkeypatch.setattr(sys, "frozen", True, raising=False)
        monkeypatch.setattr(sys, "_MEIPASS", str(tmp_path), raising=False)
        env = tmp_path / ".env"
        env.write_text("ADO_PAT=pat-from-file\nADO_ORGANIZATION=org-from-file\n")
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("ADO_PAT", "pat-from-env-loses")
        monkeypatch.setenv("ADO_ORGANIZATION", "org-from-env-loses")
        result = resolve_ado_credentials()
        assert result == {"pat": "pat-from-file", "organization": "org-from-file"}


class TestEnvKeyOrderingContract:
    """Pin the alias precedence ordering: ADO_* must beat ADO2GH_*."""

    def test_pat_env_keys_ordering(self) -> None:
        assert _PAT_ENV_KEYS == ("ADO_PAT", "ADO2GH_PAT")

    def test_org_env_keys_ordering(self) -> None:
        assert _ORG_ENV_KEYS == ("ADO_ORGANIZATION", "ADO2GH_ORGANIZATION")


class TestPackageRootReExports:
    def test_ado_credential_settings_re_exported(self) -> None:
        assert ado_source_core.ADOCredentialSettings is ADOCredentialSettings

    def test_default_ado_base_url_re_exported(self) -> None:
        assert ado_source_core.DEFAULT_ADO_BASE_URL is DEFAULT_ADO_BASE_URL

    def test_parse_env_file_re_exported(self) -> None:
        assert ado_source_core.parse_env_file is parse_env_file

    def test_resolve_ado_credentials_re_exported(self) -> None:
        assert ado_source_core.resolve_ado_credentials is resolve_ado_credentials
