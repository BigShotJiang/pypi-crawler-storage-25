"""Inventory model tests."""

from datetime import UTC, datetime
from pathlib import Path

import pytest
from pydantic import ValidationError

import ado_source_core
from ado_source_core.models import (
    ArtifactFeedInventoryItem,
    ComplexityLevel,
    ComplexityScore,
    Inventory,
    InventoryMetadata,
    LargeFileInfo,
    LFSInfo,
    PipelineAnalysis,
    PipelineInventoryItem,
    PipelineMigrationComplexity,
    PipelineType,
    ProjectInventoryItem,
    RepositoryInventoryItem,
    TestPlanInventoryItem,
    TfvcSummary,
)


def _meta() -> InventoryMetadata:
    return InventoryMetadata(
        generated_at=datetime(2026, 4, 28, tzinfo=UTC),
        organization="contoso",
    )


def _repo(name: str = "repo1", **overrides: object) -> RepositoryInventoryItem:
    base: dict[str, object] = {
        "id": "r1",
        "name": name,
        "full_name": f"P/{name}",
        "project_name": "P",
        "default_branch": "main",
        "complexity": ComplexityScore(),
    }
    base.update(overrides)
    return RepositoryInventoryItem(**base)  # type: ignore[arg-type]


def _project(**overrides: object) -> ProjectInventoryItem:
    base: dict[str, object] = {"id": "p1", "name": "P", "vcs_type": "Git"}
    base.update(overrides)
    return ProjectInventoryItem(**base)  # type: ignore[arg-type]


class TestComplexityScore:
    def test_defaults(self) -> None:
        score = ComplexityScore()
        assert score.level == ComplexityLevel.SIMPLE
        assert score.score == 0

    def test_negative_score_rejected(self) -> None:
        with pytest.raises(ValidationError):
            ComplexityScore(score=-1)


class TestLargeFileInfoAndLFS:
    def test_large_file_info(self) -> None:
        info = LargeFileInfo(path="big.bin", size_bytes=10_000_000)
        assert info.size_bytes == 10_000_000

    def test_large_file_negative_size_rejected(self) -> None:
        with pytest.raises(ValidationError):
            LargeFileInfo(path="big.bin", size_bytes=-1)

    def test_lfs_defaults(self) -> None:
        lfs = LFSInfo()
        assert lfs.has_lfs is False
        assert lfs.patterns == []


class TestRepositoryInventoryItem:
    def test_minimal(self) -> None:
        repo = _repo()
        assert repo.is_disabled is False
        assert repo.large_files == []
        assert repo.lfs.has_lfs is False
        assert repo.pipelines is None


class TestInventoryFromProjects:
    def test_summary_aggregates_repository_and_pipeline_stats(self) -> None:
        repo_a = _repo(
            "a",
            size_bytes=100,
            is_disabled=True,
            large_files=[LargeFileInfo(path="x", size_bytes=1)],
            lfs=LFSInfo(has_lfs=True, patterns=["*.bin"]),
            warnings=["one", "two"],
            pipelines=PipelineAnalysis(
                has_pipelines=True,
                total_step_count=5,
                supported_step_count=3,
                partially_supported_step_count=1,
                unsupported_step_count=1,
                migration_complexity=PipelineMigrationComplexity.MEDIUM,
            ),
            complexity=ComplexityScore(level=ComplexityLevel.MODERATE),
        )
        repo_b = _repo("b", complexity=ComplexityScore(level=ComplexityLevel.COMPLEX))
        project = _project(
            repositories=[repo_a, repo_b],
            pipelines=[
                PipelineInventoryItem(
                    id="p1", name="yp", pipeline_type=PipelineType.YAML, project_name="P"
                ),
                PipelineInventoryItem(
                    id="p2", name="cb", pipeline_type=PipelineType.CLASSIC_BUILD, project_name="P"
                ),
            ],
            service_connection_count=2,
            variable_group_count=3,
        )

        inv = Inventory.from_projects(projects=[project], metadata=_meta())

        s = inv.summary
        assert s.total_projects == 1
        assert s.total_projects_git == 1
        assert s.total_repositories == 2
        assert s.total_size_bytes == 100
        assert s.repos_disabled == 1
        assert s.repos_with_large_files == 1
        assert s.repos_with_lfs == 1
        assert s.repos_with_pipelines == 1
        assert s.pipeline_complexity_medium == 1
        assert s.complexity_moderate == 1
        assert s.complexity_complex == 1
        assert s.total_pipelines == 2
        assert s.total_pipelines_yaml == 1
        assert s.total_pipelines_classic_build == 1
        assert s.total_service_connections == 2
        assert s.total_variable_groups == 3
        assert s.total_warnings == 2

    def test_tfvc_project_counted(self) -> None:
        project = _project(
            vcs_type="Tfvc",
            tfvc=TfvcSummary(total_changesets=10, warnings=["a", "b"]),
        )
        inv = Inventory.from_projects(projects=[project], metadata=_meta())
        assert inv.summary.total_projects_tfvc == 1
        assert inv.summary.total_warnings == 2

    def test_pipeline_complexity_buckets_all_count_independently(self) -> None:
        """Cover the trivial/low/medium/high cases of the migration_complexity match."""

        def _repo_with_complexity(
            name: str, complexity: PipelineMigrationComplexity
        ) -> RepositoryInventoryItem:
            return _repo(
                name,
                pipelines=PipelineAnalysis(has_pipelines=True, migration_complexity=complexity),
            )

        project = _project(
            repositories=[
                _repo_with_complexity("a", PipelineMigrationComplexity.TRIVIAL),
                _repo_with_complexity("b", PipelineMigrationComplexity.LOW),
                _repo_with_complexity("c", PipelineMigrationComplexity.MEDIUM),
                _repo_with_complexity("d", PipelineMigrationComplexity.HIGH),
            ],
        )
        s = Inventory.from_projects(projects=[project], metadata=_meta()).summary

        assert s.repos_with_pipelines == 4
        assert s.pipeline_complexity_trivial == 1
        assert s.pipeline_complexity_low == 1
        assert s.pipeline_complexity_medium == 1
        assert s.pipeline_complexity_high == 1

    def test_pipeline_step_subtotals_aggregate(self) -> None:
        """Cover total_pipeline_steps_{supported, partially_supported, unsupported, script}."""
        repo = _repo(
            "a",
            pipelines=PipelineAnalysis(
                has_pipelines=True,
                total_step_count=10,
                supported_step_count=4,
                partially_supported_step_count=2,
                unsupported_step_count=3,
                script_step_count=1,
            ),
        )
        project = _project(repositories=[repo])
        s = Inventory.from_projects(projects=[project], metadata=_meta()).summary

        assert s.total_pipeline_steps == 10
        assert s.total_pipeline_steps_supported == 4
        assert s.total_pipeline_steps_partially_supported == 2
        assert s.total_pipeline_steps_unsupported == 3
        assert s.total_pipeline_steps_script == 1

    def test_classic_release_pipelines_counted(self) -> None:
        """Cover the classic-release branch of the pipeline_type if/elif chain."""
        project = _project(
            pipelines=[
                PipelineInventoryItem(
                    id="p1",
                    name="release",
                    pipeline_type=PipelineType.CLASSIC_RELEASE,
                    project_name="P",
                ),
            ],
        )
        s = Inventory.from_projects(projects=[project], metadata=_meta()).summary
        assert s.total_pipelines_classic_release == 1

    def test_artifact_test_plan_environment_totals(self) -> None:
        """Cover total_artifact_feeds, total_test_plans, total_environments."""
        project = _project(
            artifact_feeds=[
                ArtifactFeedInventoryItem(id="f1", name="feed1"),
                ArtifactFeedInventoryItem(id="f2", name="feed2"),
            ],
            test_plans=[TestPlanInventoryItem(id="tp1", name="plan1")],
            environment_count=4,
        )
        s = Inventory.from_projects(projects=[project], metadata=_meta()).summary

        assert s.total_artifact_feeds == 2
        assert s.total_test_plans == 1
        assert s.total_environments == 4


class TestInventoryMetadataDefaults:
    def test_generated_by_defaults_to_package_name(self) -> None:
        meta = InventoryMetadata(
            generated_at=datetime(2026, 4, 28, tzinfo=UTC), organization="contoso"
        )
        assert meta.generated_by == "ado-source-core"


class TestInventoryJSONRoundTrip:
    def test_round_trip(self, tmp_path: Path) -> None:
        inv = Inventory.from_projects(
            projects=[_project(repositories=[_repo()])],
            metadata=_meta(),
        )
        out = tmp_path / "inv.json"
        inv.to_json_file(out)
        loaded = Inventory.from_json_file(out)
        assert loaded.summary.total_repositories == 1
        assert loaded.metadata.organization == "contoso"
        assert loaded.projects[0].repositories[0].name == "repo1"


class TestInventoryReExports:
    def test_inventory_models_re_exported(self) -> None:
        for name in (
            "ComplexityLevel",
            "ComplexityScore",
            "LargeFileInfo",
            "LFSInfo",
            "RepositoryInventoryItem",
            "InventoryMetadata",
            "InventorySummary",
            "ProjectInventoryItem",
            "Inventory",
        ):
            assert hasattr(ado_source_core, name), name
