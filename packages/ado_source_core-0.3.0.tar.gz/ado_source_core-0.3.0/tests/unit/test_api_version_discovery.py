"""api_version_discovery module tests.

Covers:
- connectionData success path (parametrized over advertised versions)
- connectionData missing/malformed apiVersion → fall through
- candidate iteration paths (each candidate succeeds first try)
- candidate iteration: all fail → APIError
- auth error during version probe → AuthenticationError propagates
- soft-capability probes: 200/404/401/429/5xx handling
- Graph preview-suffix retry on 400
- Analytics collection→project fallback on 404
- soft-cap probes run concurrently
"""

from __future__ import annotations

import asyncio
from typing import Any

import httpx
import pytest
import respx

from ado_source_core import (
    APIError,
    AuthenticationError,
    PATAuth,
    RateLimitError,
)
from ado_source_core.api_version_discovery import (
    SERVER_API_VERSION_CANDIDATES,
    ServerProbeResult,
    resolve_server_api_version,
)
from ado_source_core.client import ADOServerClient

_BASE = "https://devops.example.com/tfs"
_COLLECTION = "DefaultCollection"
_RESOLVED = f"{_BASE}/{_COLLECTION}"


@pytest.fixture
def auth() -> PATAuth:
    return PATAuth(token="dummy-pat")


@pytest.fixture
def client(auth: PATAuth) -> ADOServerClient:
    """A non-connected ADOServerClient with no explicit api_version."""
    return ADOServerClient(
        base_url=_BASE,
        collection=_COLLECTION,
        auth=auth,
        max_retries=2,
    )


async def _instant_sleep(_seconds: float) -> None:
    return None


@pytest.fixture(autouse=True)
def _no_sleep(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(asyncio, "sleep", _instant_sleep)


def _all_caps_ok(mock: respx.MockRouter) -> None:
    """Set up the 3 soft-cap probe mocks to return 200, so a happy version
    probe doesn't choke on the cap probes."""
    mock.get("/_apis/graph/users").mock(return_value=httpx.Response(200, json={"value": []}))
    mock.get("/_odata/v4.0-preview/$metadata").mock(
        return_value=httpx.Response(200, text="<edmx/>")
    )
    mock.get("/_apis/packaging/feeds").mock(return_value=httpx.Response(200, json={"value": []}))


class TestResolveSnapping:
    @pytest.mark.parametrize(
        ("advertised", "expected"),
        [
            ("7.0", "7.0"),
            ("7.1", "7.0"),
            ("6.0", "6.0"),
            ("5.1", "5.1"),
            ("5.0", "5.0"),
        ],
    )
    @pytest.mark.asyncio
    async def test_advertised_snaps_to_highest_candidate_le(
        self, auth: PATAuth, advertised: str, expected: str
    ) -> None:
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": advertised})
                )
                # Snap path runs the Analytics-fallback-hint /_apis/projects call.
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(200, json={"value": [{"name": "P1"}]})
                )
                _all_caps_ok(mock)
                result = await resolve_server_api_version(client)
                assert result.api_version == expected
                assert result.probe_strategy == "connection_data"
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_advertised_below_lowest_candidate_falls_through(self, auth: PATAuth) -> None:
        # advertised "4.1" is below all candidates → fall through to candidate iteration.
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "4.1"})
                )
                # Candidate iteration: 7.0 returns 400, 6.0 returns 200.
                projects_route = mock.get("/_apis/projects").mock(
                    side_effect=[
                        httpx.Response(400),
                        httpx.Response(200, json={"value": [{"name": "P1"}]}),
                    ]
                )
                _all_caps_ok(mock)
                result = await resolve_server_api_version(client)
                assert result.api_version == "6.0"
                assert result.probe_strategy == "candidate_iteration"
                assert projects_route.call_count == 2
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_connection_data_404_falls_through(self, auth: PATAuth) -> None:
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(return_value=httpx.Response(404))
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(200, json={"value": [{"name": "P1"}]})
                )
                _all_caps_ok(mock)
                result = await resolve_server_api_version(client)
                assert result.api_version == "7.0"
                assert result.probe_strategy == "candidate_iteration"
        finally:
            await client.close()

    @pytest.mark.parametrize(
        "payload",
        [
            {},  # missing apiVersion
            {"apiVersion": ""},  # empty
            {"apiVersion": "7"},  # one component
            {"apiVersion": "7.0.0"},  # three components
            {"apiVersion": "7.x"},  # non-int component
            {"apiVersion": 7.0},  # non-string
            {"locationServiceData": {"apiVersion": "7.0"}},  # nested success
        ],
    )
    @pytest.mark.asyncio
    async def test_connection_data_payload_shapes(
        self, auth: PATAuth, payload: dict[str, Any]
    ) -> None:
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json=payload)
                )
                # If the parser extracts a valid version, no candidate
                # iteration happens. If it falls through, candidate
                # iteration succeeds on 7.0.
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(200, json={"value": [{"name": "P1"}]})
                )
                _all_caps_ok(mock)
                result = await resolve_server_api_version(client)
                assert result.api_version == "7.0"
        finally:
            await client.close()


class TestCandidateIteration:
    @pytest.mark.parametrize("first_ok", SERVER_API_VERSION_CANDIDATES)
    @pytest.mark.asyncio
    async def test_each_candidate_succeeds_first(self, auth: PATAuth, first_ok: str) -> None:
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(return_value=httpx.Response(404))
                # Build a side_effect list that returns 400 for every
                # candidate above first_ok and 200 starting at first_ok.
                idx = SERVER_API_VERSION_CANDIDATES.index(first_ok)
                effects = [httpx.Response(400)] * idx + [
                    httpx.Response(200, json={"value": [{"name": "P1"}]})
                ]
                mock.get("/_apis/projects").mock(side_effect=effects)
                _all_caps_ok(mock)
                result = await resolve_server_api_version(client)
                assert result.api_version == first_ok
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_all_candidates_fail_raises_api_error(self, auth: PATAuth) -> None:
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(return_value=httpx.Response(404))
                mock.get("/_apis/projects").mock(return_value=httpx.Response(400))
                with pytest.raises(APIError, match="Unable to determine"):
                    await resolve_server_api_version(client)
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_auth_error_during_version_probe_propagates(self, auth: PATAuth) -> None:
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(return_value=httpx.Response(404))
                mock.get("/_apis/projects").mock(return_value=httpx.Response(401))
                with pytest.raises(AuthenticationError):
                    await resolve_server_api_version(client)
        finally:
            await client.close()


class TestSoftCapabilityProbes:
    @pytest.mark.asyncio
    async def test_graph_200_on_preview_suffix_records_preview_variant(
        self,
        auth: PATAuth,
    ) -> None:
        """When the preview-suffix probe succeeds first, the result must
        carry ``graph_api_version="7.0-preview.1"`` so list_users uses
        the preview suffix at call time."""
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            # Also need a project for the connectionData-success Analytics
            # fallback hint (added in the synthesis pass).
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "7.0"})
                )
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(
                        200,
                        json={"value": [{"name": "ProjA"}]},
                    )
                )
                _all_caps_ok(mock)
                result = await resolve_server_api_version(client)
                assert result.capability_overrides["supports_graph_api"] is True
                # Default _all_caps_ok mock matches both preview and plain
                # variants on the first call, so the preview suffix wins.
                assert result.graph_api_version == "7.0-preview.1"
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_graph_400_invalid_api_version_retries_plain(
        self,
        auth: PATAuth,
    ) -> None:
        """When preview returns 400 InvalidApiVersion, retry plain — the
        result must record ``graph_api_version="7.0"`` (plain)."""
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "7.0"})
                )
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(
                        200,
                        json={"value": [{"name": "ProjA"}]},
                    )
                )
                mock.get("/_odata/v4.0-preview/$metadata").mock(
                    return_value=httpx.Response(200, text="<edmx/>")
                )
                mock.get("/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                # First Graph call (preview suffix) returns 400 with the
                # InvalidPreviewVersion typeKey, second (plain) returns 200.
                graph_route = mock.get("/_apis/graph/users").mock(
                    side_effect=[
                        httpx.Response(
                            400,
                            json={"typeKey": "VssInvalidPreviewVersionException"},
                        ),
                        httpx.Response(200, json={"value": []}),
                    ]
                )
                result = await resolve_server_api_version(client)
                assert result.capability_overrides["supports_graph_api"] is True
                assert result.graph_api_version == "7.0"
                assert graph_route.call_count == 2
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_graph_400_unrelated_propagates(self, auth: PATAuth) -> None:
        """A 400 that is NOT InvalidApiVersion must propagate, not silently
        try the next variant."""
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "7.0"})
                )
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(
                        200,
                        json={"value": [{"name": "ProjA"}]},
                    )
                )
                mock.get("/_odata/v4.0-preview/$metadata").mock(
                    return_value=httpx.Response(200, text="<edmx/>")
                )
                mock.get("/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                mock.get("/_apis/graph/users").mock(
                    return_value=httpx.Response(
                        400,
                        json={"typeKey": "VssSomeOtherException"},
                    )
                )
                with pytest.raises(APIError):
                    await resolve_server_api_version(client)
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_graph_404_marks_false(self, auth: PATAuth) -> None:
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "7.0"})
                )
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(
                        200,
                        json={"value": [{"name": "ProjA"}]},
                    )
                )
                mock.get("/_apis/graph/users").mock(return_value=httpx.Response(404))
                mock.get("/_odata/v4.0-preview/$metadata").mock(
                    return_value=httpx.Response(200, text="<edmx/>")
                )
                mock.get("/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                result = await resolve_server_api_version(client)
                assert result.capability_overrides["supports_graph_api"] is False
                assert result.graph_api_version is None
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_graph_401_marks_false_with_diagnostic_note(
        self,
        auth: PATAuth,
    ) -> None:
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "7.0"})
                )
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(
                        200,
                        json={"value": [{"name": "ProjA"}]},
                    )
                )
                mock.get("/_apis/graph/users").mock(return_value=httpx.Response(401))
                mock.get("/_odata/v4.0-preview/$metadata").mock(
                    return_value=httpx.Response(200, text="<edmx/>")
                )
                mock.get("/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                result = await resolve_server_api_version(client)
                assert result.capability_overrides["supports_graph_api"] is False
                assert result.graph_api_version is None
                assert any("supports_graph_api" in n for n in result.capability_notes)
                assert any("PAT" in n or "scope" in n for n in result.capability_notes)
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_analytics_collection_404_falls_back_project_scoped(self, auth: PATAuth) -> None:
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "7.0"})
                )
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(200, json={"value": [{"name": "ProjA"}]})
                )
                mock.get("/_apis/graph/users").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                mock.get("/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                # Collection-scoped 404, project-scoped 200.
                mock.get("/_odata/v4.0-preview/$metadata").mock(return_value=httpx.Response(404))
                mock.get("/ProjA/_odata/v4.0-preview/$metadata").mock(
                    return_value=httpx.Response(200, text="<edmx/>")
                )
                result = await resolve_server_api_version(client)
                assert result.capability_overrides["supports_analytics_odata"] is True
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_analytics_collection_501_falls_back_to_project_scoped(
        self,
        auth: PATAuth,
    ) -> None:
        """A 501 Not Implemented from the collection-scoped Analytics
        ``$metadata`` probe must be treated as "capability not present"
        on the collection scope and fall through to the project-scoped
        fallback — symmetric with the 404 case and with the existing
        404+501 handling on the project-scoped probe and the other
        soft-cap probes (``_probe_graph``, ``_probe_feeds``).
        """
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "7.0"})
                )
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(200, json={"value": [{"name": "ProjA"}]})
                )
                mock.get("/_apis/graph/users").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                mock.get("/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                # Collection-scoped 501, project-scoped 200.
                mock.get("/_odata/v4.0-preview/$metadata").mock(return_value=httpx.Response(501))
                mock.get("/ProjA/_odata/v4.0-preview/$metadata").mock(
                    return_value=httpx.Response(200, text="<edmx/>")
                )
                result = await resolve_server_api_version(client)
                assert result.capability_overrides["supports_analytics_odata"] is True
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_analytics_collection_501_with_no_project_returns_false(
        self,
        auth: PATAuth,
    ) -> None:
        """When the Analytics extension is not installed (collection-scoped
        $metadata returns 501) AND the collection has no projects (so the
        Analytics probe receives ``project_hint=None``), the capability
        must demote to ``False`` rather than propagate as ``APIError``
        and break ``connect()`` / discovery.
        """
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "7.0"})
                )
                # Empty collection — _fetch_first_project_name returns None.
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                mock.get("/_apis/graph/users").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                mock.get("/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                # Collection-scoped 501; no project-scoped fallback should fire.
                collection_route = mock.get("/_odata/v4.0-preview/$metadata").mock(
                    return_value=httpx.Response(501)
                )
                result = await resolve_server_api_version(client)
                assert result.capability_overrides["supports_analytics_odata"] is False
                assert collection_route.call_count == 1
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_analytics_probe_omits_api_version_query_param(
        self,
        auth: PATAuth,
    ) -> None:
        """The Analytics OData ``$metadata`` endpoint encodes its OData
        service version in the URL path (``v4.0-preview``) and does NOT
        accept the REST ``api-version`` query parameter. The probe must
        match the exact URL shape used by ``query_work_item_counts`` so
        a working endpoint isn't falsely demoted on a probe that
        diverges from the real call.
        """
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "7.0"})
                )
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(
                        200,
                        json={"value": [{"name": "ProjA"}]},
                    )
                )
                mock.get("/_apis/graph/users").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                mock.get("/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                # Collection-scoped probe -> 404 so we exercise the project
                # fallback too; both URLs must be free of api-version.
                collection_route = mock.get("/_odata/v4.0-preview/$metadata").mock(
                    return_value=httpx.Response(404)
                )
                project_route = mock.get("/ProjA/_odata/v4.0-preview/$metadata").mock(
                    return_value=httpx.Response(200, text="<edmx/>")
                )
                await resolve_server_api_version(client)
                assert collection_route.call_count == 1
                assert "api-version" not in collection_route.calls[0].request.url.params
                assert project_route.call_count == 1
                assert "api-version" not in project_route.calls[0].request.url.params
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_429_during_cap_probe_propagates(self, auth: PATAuth) -> None:
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "7.0"})
                )
                # Snap path runs the Analytics-fallback-hint /_apis/projects call.
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(200, json={"value": [{"name": "P1"}]})
                )
                mock.get("/_apis/graph/users").mock(
                    return_value=httpx.Response(429, headers={"Retry-After": "1"})
                )
                mock.get("/_odata/v4.0-preview/$metadata").mock(
                    return_value=httpx.Response(200, text="<edmx/>")
                )
                mock.get("/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                with pytest.raises(RateLimitError):
                    await resolve_server_api_version(client)
        finally:
            await client.close()


class TestConnectionDataPropagation:
    """``_fetch_connection_data_api_version`` must only fall through on
    400/404 (connectionData unavailable). 429 / 5xx / network errors must
    propagate so the resolver doesn't silently fall back into candidate
    iteration while rate-limited or while the server is unhealthy."""

    @pytest.mark.asyncio
    async def test_connection_data_429_propagates(self, auth: PATAuth) -> None:
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(429, headers={"Retry-After": "1"})
                )
                # Must NOT silently fall through to candidate iteration.
                with pytest.raises(RateLimitError):
                    await resolve_server_api_version(client)
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_connection_data_503_propagates(self, auth: PATAuth) -> None:
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(return_value=httpx.Response(503))
                with pytest.raises(APIError) as excinfo:
                    await resolve_server_api_version(client)
                assert excinfo.value.status_code == 503
        finally:
            await client.close()


class TestFirstProjectFetchPropagation:
    """``_fetch_first_project_name`` must only fall through on 400/404
    (the projects endpoint genuinely being unavailable). 429 / 5xx /
    network errors must propagate so the resolver doesn't silently
    fall back into the Analytics-False branch while rate-limited or
    while the server is unhealthy.

    Symmetric with ``TestConnectionDataPropagation`` — the fix-up
    mirrors the same narrow-catch pattern applied to
    ``_fetch_connection_data_api_version`` in round 1.
    """

    @pytest.mark.asyncio
    async def test_first_project_fetch_429_propagates_on_discovery_path(
        self, auth: PATAuth
    ) -> None:
        """connectionData succeeds → resolver runs the projects fetch for
        the Analytics fallback hint → projects returns 429 → ``RateLimitError``
        must propagate, NOT be swallowed into ``project_hint=None``."""
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "7.0"})
                )
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(429, headers={"Retry-After": "1"})
                )
                # Soft-cap probes never run because the projects fetch
                # raises before ``probe_soft_capabilities`` is reached;
                # registering them would trip respx's
                # assert_all_called check.
                with pytest.raises(RateLimitError):
                    await resolve_server_api_version(client)
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_first_project_fetch_503_propagates_on_discovery_path(
        self, auth: PATAuth
    ) -> None:
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "7.0"})
                )
                mock.get("/_apis/projects").mock(return_value=httpx.Response(503))
                with pytest.raises(APIError) as excinfo:
                    await resolve_server_api_version(client)
                assert excinfo.value.status_code == 503
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_first_project_fetch_429_propagates_on_explicit_path(self, auth: PATAuth) -> None:
        """Explicit ``api_version=`` path also pre-fetches a project name
        for the Analytics soft-cap probe's collection→project fallback.
        429 there must propagate, mirroring the discovery path."""
        with respx.mock(base_url=_RESOLVED) as mock:
            mock.get("/_apis/projects").mock(
                return_value=httpx.Response(429, headers={"Retry-After": "1"})
            )
            client = ADOServerClient(
                base_url=_BASE,
                collection=_COLLECTION,
                auth=auth,
                api_version="6.0",
                max_retries=2,
            )
            try:
                with pytest.raises(RateLimitError):
                    await client.connect()
            finally:
                await client.close()


class TestServerProbeResultDataclass:
    def test_default_field_values(self) -> None:
        r = ServerProbeResult(api_version="7.0")
        assert r.api_version == "7.0"
        assert dict(r.capability_overrides) == {}
        assert r.capability_notes == ()
        assert r.probe_strategy == "connection_data"

    def test_frozen(self) -> None:
        from dataclasses import FrozenInstanceError  # noqa: PLC0415

        r = ServerProbeResult(api_version="7.0")
        with pytest.raises(FrozenInstanceError):
            r.api_version = "9.9"  # type: ignore[misc]

    def test_capability_overrides_is_immutable_view(self) -> None:
        r = ServerProbeResult(api_version="7.0")
        # MappingProxyType doesn't support item assignment.
        with pytest.raises(TypeError):
            r.capability_overrides["supports_graph_api"] = False  # type: ignore[index]

    def test_capability_notes_is_tuple(self) -> None:
        r = ServerProbeResult(api_version="7.0")
        assert isinstance(r.capability_notes, tuple)
