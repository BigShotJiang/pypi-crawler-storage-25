"""AzureDevOpsCloudAdapter happy-path tests.

One representative test per method (donor was production-tested in
ado2gh-core). Tests use respx to mock the underlying httpx clients.
"""

from __future__ import annotations

import asyncio
from typing import Any

import httpx
import pytest
import respx

from ado_source_core import (
    APIError,
    AuthenticationError,
    PATAuth,
    Repository,
    SourceCapabilities,
    SourceType,
    User,
)
from ado_source_core.adapters.ado_cloud import AzureDevOpsCloudAdapter
from ado_source_core.adapters.source import SourceAdapter
from ado_source_core.client import ADOClient

BASE = "https://dev.azure.com/myorg"
VSRM = "https://vsrm.dev.azure.com/myorg"
FEEDS = "https://feeds.dev.azure.com/myorg"
ANALYTICS = "https://analytics.dev.azure.com/myorg"
VSSPS = "https://vssps.dev.azure.com/myorg"
VSAEX = "https://vsaex.dev.azure.com/myorg"


@pytest.fixture
def auth() -> PATAuth:
    return PATAuth(token="dummy-pat")


def _make_adapter(auth: PATAuth, **client_overrides: Any) -> AzureDevOpsCloudAdapter:
    client_kwargs: dict[str, Any] = {
        "organization": "myorg",
        "auth": auth,
        "max_retries": 3,
    }
    client_kwargs.update(client_overrides)
    return AzureDevOpsCloudAdapter(client=ADOClient(**client_kwargs))


async def _instant_sleep(_seconds: float) -> None:
    return None


@pytest.fixture(autouse=True)
def _no_sleep(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(asyncio, "sleep", _instant_sleep)


class TestConstruction:
    def test_subclasses_source_adapter(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        assert isinstance(adapter, SourceAdapter)

    def test_default_capabilities_are_cloud(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)

        # Capabilities are a coroutine; await them
        async def _check() -> None:
            caps = await adapter.get_capabilities()
            assert caps.source_type == SourceType.AZURE_DEVOPS_CLOUD

        asyncio.run(_check())

    def test_explicit_capabilities_override_default(self, auth: PATAuth) -> None:
        explicit = SourceCapabilities(
            source_type=SourceType.AZURE_DEVOPS_SERVER, supports_pipelines=False
        )
        adapter = AzureDevOpsCloudAdapter(
            client=ADOClient(organization="myorg", auth=auth),
            capabilities=explicit,
        )

        async def _check() -> None:
            caps = await adapter.get_capabilities()
            assert caps.source_type == SourceType.AZURE_DEVOPS_SERVER
            assert caps.supports_pipelines is False

        asyncio.run(_check())


class TestVerifyCredentials:
    @pytest.mark.asyncio
    async def test_succeeds_when_all_three_probes_succeed(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(
                        200, json={"value": [{"name": "MyProject", "id": "p1"}]}
                    )
                )
                mock.get("/MyProject/_apis/git/repositories").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                mock.get("/MyProject/_apis/build/definitions").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                assert await adapter.verify_credentials() is True

    @pytest.mark.asyncio
    async def test_succeeds_when_no_projects_visible(self, auth: PATAuth) -> None:
        """If projects list is empty, repo+build probes are skipped — still True."""
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                assert await adapter.verify_credentials() is True

    @pytest.mark.asyncio
    async def test_translates_authentication_error_to_friendly_message(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/_apis/projects").mock(return_value=httpx.Response(401))
                with pytest.raises(AuthenticationError) as exc_info:
                    await adapter.verify_credentials()
                assert "Required scopes" in str(exc_info.value)


class TestProjects:
    @pytest.mark.asyncio
    async def test_list_projects_paginates_via_continuation_token(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/_apis/projects").mock(
                    side_effect=[
                        httpx.Response(
                            200,
                            headers={"x-ms-continuationtoken": "100"},
                            json={"value": [{"id": "p1"}, {"id": "p2"}]},
                        ),
                        httpx.Response(200, json={"value": [{"id": "p3"}]}),
                    ]
                )
                projects = await adapter.list_projects()
                assert [p["id"] for p in projects] == ["p1", "p2", "p3"]

    @pytest.mark.asyncio
    async def test_get_project_details_includes_capabilities_param(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                route = mock.get("/_apis/projects/p1").mock(
                    return_value=httpx.Response(200, json={"id": "p1", "name": "P1"})
                )
                result = await adapter.get_project_details("p1")
                assert result == {"id": "p1", "name": "P1"}
                assert "includeCapabilities=true" in str(route.calls[0].request.url)

    @pytest.mark.asyncio
    async def test_get_process_template(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/_apis/work/processes/proc-uuid").mock(
                    return_value=httpx.Response(200, json={"name": "Agile"})
                )
                result = await adapter.get_process_template("proc-uuid")
                assert result == {"name": "Agile"}


class TestRepositories:
    @pytest.mark.asyncio
    async def test_list_repositories_returns_typed_models(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/git/repositories").mock(
                    return_value=httpx.Response(
                        200,
                        json={
                            "value": [
                                {
                                    "id": "r1",
                                    "name": "repo1",
                                    "defaultBranch": "refs/heads/main",
                                    "size": 12345,
                                    "remoteUrl": "https://x/repo1",
                                    "isDisabled": False,
                                    "isInMaintenance": False,
                                    "isFork": False,
                                },
                            ]
                        },
                    )
                )
                repos = await adapter.list_repositories(project="MyProject")
                assert len(repos) == 1
                assert isinstance(repos[0], Repository)
                assert repos[0].name == "repo1"
                assert repos[0].full_name == "MyProject/repo1"
                # refs/heads/ prefix stripped from default_branch
                assert repos[0].default_branch == "main"
                assert repos[0].size_bytes == 12345
                assert repos[0].clone_url_https == "https://x/repo1"

    @pytest.mark.asyncio
    async def test_list_repositories_handles_missing_default_branch(self, auth: PATAuth) -> None:
        """Empty repos return defaultBranch=null; lift falls back to refs/heads/main -> main."""
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/git/repositories").mock(
                    return_value=httpx.Response(
                        200,
                        json={"value": [{"id": "r1", "name": "empty"}]},
                    )
                )
                repos = await adapter.list_repositories(project="MyProject")
                assert repos[0].default_branch == "main"

    @pytest.mark.asyncio
    async def test_list_repositories_requires_project(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with pytest.raises(ValueError):
                await adapter.list_repositories()

    @pytest.mark.asyncio
    async def test_get_repository_raises_not_implemented(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with pytest.raises(NotImplementedError):
                await adapter.get_repository("MyProject/abc-123")


class TestBranchesAndPullRequests:
    @pytest.mark.asyncio
    async def test_count_branches_paginates_continuation(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/git/repositories/abc/refs").mock(
                    side_effect=[
                        httpx.Response(
                            200,
                            headers={"x-ms-continuationtoken": "abc"},
                            json={"value": [{"name": "1"}, {"name": "2"}]},
                        ),
                        httpx.Response(200, json={"value": [{"name": "3"}]}),
                    ]
                )
                count = await adapter.count_branches("MyProject/abc")
                assert count == 3

    @pytest.mark.asyncio
    async def test_count_pull_requests_paginates_skip_top(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/git/repositories/abc/pullrequests").mock(
                    side_effect=[
                        httpx.Response(200, json={"value": [{"id": i} for i in range(100)]}),
                        httpx.Response(200, json={"value": [{"id": i} for i in range(50)]}),
                    ]
                )
                count = await adapter.count_pull_requests("MyProject/abc")
                assert count == 150


class TestLFSAndLargeFiles:
    @pytest.mark.asyncio
    async def test_detect_lfs_patterns_parses_gitattributes(self, auth: PATAuth) -> None:
        gitattributes = (
            "# comment line\n"
            "*.bin filter=lfs diff=lfs merge=lfs -text\n"
            "*.pdf filter=lfs\n"
            "small/* -filter=lfs\n"  # negation; should be excluded
            "no-attrs-here\n"  # single token; should be skipped
        )
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/git/repositories/abc/items").mock(
                    return_value=httpx.Response(200, json={"content": gitattributes})
                )
                result = await adapter.detect_lfs_patterns("MyProject/abc", branch="main")
                assert result["has_lfs"] is True
                assert result["patterns"] == ["*.bin", "*.pdf"]

    @pytest.mark.asyncio
    async def test_detect_lfs_patterns_returns_empty_on_404(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/git/repositories/abc/items").mock(
                    return_value=httpx.Response(404, json={"message": "no such file"})
                )
                result = await adapter.detect_lfs_patterns("MyProject/abc")
                assert result == {"has_lfs": False, "patterns": []}

    @pytest.mark.asyncio
    async def test_detect_lfs_patterns_propagates_authentication_error(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/git/repositories/abc/items").mock(
                    return_value=httpx.Response(401)
                )
                with pytest.raises(AuthenticationError):
                    await adapter.detect_lfs_patterns("MyProject/abc")

    @pytest.mark.asyncio
    async def test_detect_lfs_patterns_propagates_500(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/git/repositories/abc/items").mock(
                    return_value=httpx.Response(500, text="server boom")
                )
                with pytest.raises(APIError):
                    await adapter.detect_lfs_patterns("MyProject/abc")

    @pytest.mark.asyncio
    async def test_analyze_large_files_walks_refs_commit_tree(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/git/repositories/abc/refs").mock(
                    return_value=httpx.Response(
                        200,
                        json={"value": [{"objectId": "commit-abc"}]},
                    )
                )
                mock.get("/MyProject/_apis/git/repositories/abc/commits/commit-abc").mock(
                    return_value=httpx.Response(200, json={"treeId": "tree-xyz"})
                )
                mock.get("/MyProject/_apis/git/repositories/abc/trees/tree-xyz").mock(
                    return_value=httpx.Response(
                        200,
                        json={
                            "treeEntries": [
                                {
                                    "gitObjectType": "blob",
                                    "relativePath": "small.txt",
                                    "size": 100,
                                },
                                {
                                    "gitObjectType": "blob",
                                    "relativePath": "huge.bin",
                                    "size": 200_000_000,
                                },
                                {
                                    "gitObjectType": "tree",
                                    "relativePath": "subdir",
                                    "size": 999_999_999,
                                },
                            ]
                        },
                    )
                )
                result = await adapter.analyze_large_files(
                    "MyProject/abc", threshold_bytes=100_000_000
                )
                assert result == {"large_files": [{"path": "huge.bin", "size_bytes": 200_000_000}]}

    @pytest.mark.asyncio
    async def test_analyze_large_files_returns_empty_when_branch_missing(
        self, auth: PATAuth
    ) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/git/repositories/abc/refs").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                result = await adapter.analyze_large_files("MyProject/abc")
                assert result == {"large_files": []}

    @pytest.mark.asyncio
    async def test_analyze_large_files_returns_empty_on_404(self, auth: PATAuth) -> None:
        """A 404 anywhere in the refs->commit->tree walk is a no-blob signal."""
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/git/repositories/abc/refs").mock(
                    return_value=httpx.Response(404)
                )
                result = await adapter.analyze_large_files("MyProject/abc")
                assert result == {"large_files": []}

    @pytest.mark.asyncio
    async def test_analyze_large_files_propagates_authentication_error(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/git/repositories/abc/refs").mock(
                    return_value=httpx.Response(401)
                )
                with pytest.raises(AuthenticationError):
                    await adapter.analyze_large_files("MyProject/abc")

    @pytest.mark.asyncio
    async def test_analyze_large_files_propagates_500(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/git/repositories/abc/refs").mock(
                    return_value=httpx.Response(500, text="server boom")
                )
                with pytest.raises(APIError):
                    await adapter.analyze_large_files("MyProject/abc")


class TestFileContent:
    @pytest.mark.asyncio
    async def test_get_file_content_returns_text(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/git/repositories/abc/items").mock(
                    return_value=httpx.Response(200, json={"content": "hello world"})
                )
                content = await adapter.get_file_content("MyProject", "abc", "README.md")
                assert content == "hello world"

    @pytest.mark.asyncio
    async def test_get_file_content_returns_none_on_404(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/git/repositories/abc/items").mock(
                    return_value=httpx.Response(404)
                )
                content = await adapter.get_file_content("MyProject", "abc", "missing.md")
                assert content is None

    @pytest.mark.asyncio
    async def test_get_file_content_raises_other_api_errors(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/git/repositories/abc/items").mock(
                    return_value=httpx.Response(500, text="boom")
                )
                with pytest.raises(APIError):
                    await adapter.get_file_content("MyProject", "abc", "README.md")


class TestGetUserStub:
    """``get_user`` remains a stub — full impl is intentionally skipped."""

    @pytest.mark.asyncio
    async def test_get_user_raises_not_implemented(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with pytest.raises(NotImplementedError):
                await adapter.get_user("alice")


class TestBuildAndReleaseDefinitions:
    @pytest.mark.asyncio
    async def test_list_build_definitions_paginates(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/build/definitions").mock(
                    side_effect=[
                        httpx.Response(
                            200,
                            headers={"x-ms-continuationtoken": "abc"},
                            json={"value": [{"id": 1}, {"id": 2}]},
                        ),
                        httpx.Response(200, json={"value": [{"id": 3}]}),
                    ]
                )
                defs = await adapter.list_build_definitions("MyProject")
                assert [d["id"] for d in defs] == [1, 2, 3]

    @pytest.mark.asyncio
    async def test_get_build_definition(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/build/definitions/42").mock(
                    return_value=httpx.Response(200, json={"id": 42, "name": "CI"})
                )
                result = await adapter.get_build_definition("MyProject", 42)
                assert result == {"id": 42, "name": "CI"}

    @pytest.mark.asyncio
    async def test_list_release_definitions_routes_to_vsrm(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=VSRM) as mock:
                mock.get("/MyProject/_apis/release/definitions").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": 1}]})
                )
                defs = await adapter.list_release_definitions("MyProject")
                assert [d["id"] for d in defs] == [1]

    @pytest.mark.asyncio
    async def test_get_release_definition_routes_to_vsrm(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=VSRM) as mock:
                mock.get("/MyProject/_apis/release/definitions/7").mock(
                    return_value=httpx.Response(200, json={"id": 7, "name": "Deploy"})
                )
                result = await adapter.get_release_definition("MyProject", 7)
                assert result == {"id": 7, "name": "Deploy"}


class TestServiceConnectionsAndVariableGroupsAndEnvironments:
    @pytest.mark.asyncio
    async def test_list_service_connections(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/serviceendpoint/endpoints").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": "sc1"}]})
                )
                result = await adapter.list_service_connections("MyProject")
                assert [r["id"] for r in result] == ["sc1"]

    @pytest.mark.asyncio
    async def test_list_variable_groups_paginates(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/distributedtask/variablegroups").mock(
                    side_effect=[
                        httpx.Response(
                            200,
                            headers={"x-ms-continuationtoken": "100"},
                            json={"value": [{"id": 1}]},
                        ),
                        httpx.Response(200, json={"value": [{"id": 2}]}),
                    ]
                )
                groups = await adapter.list_variable_groups("MyProject")
                assert [g["id"] for g in groups] == [1, 2]

    @pytest.mark.asyncio
    async def test_list_environments_paginates(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/distributedtask/environments").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": 1}, {"id": 2}]})
                )
                envs = await adapter.list_environments("MyProject")
                assert [e["id"] for e in envs] == [1, 2]


class TestWorkItemAnalytics:
    @pytest.mark.asyncio
    async def test_query_work_item_counts_routes_to_analytics(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=ANALYTICS) as mock:
                route = mock.get("/MyProject/_odata/v4.0-preview/WorkItems").mock(
                    return_value=httpx.Response(
                        200,
                        json={
                            "value": [
                                {"WorkItemType": "Bug", "State": "Active", "Count": 5},
                                {"WorkItemType": "Bug", "State": "Resolved", "Count": 2},
                                {"WorkItemType": "Task", "State": "Active", "Count": 3},
                                # None / missing-state row coerced to "Unknown"
                                {"WorkItemType": "User Story", "State": None, "Count": 1},
                            ]
                        },
                    )
                )
                result = await adapter.query_work_item_counts("MyProject")
                assert result["total"] == 11
                assert result["by_type"] == {"Bug": 7, "Task": 3, "User Story": 1}
                assert result["by_state"] == {"Active": 8, "Resolved": 2, "Unknown": 1}
                # OData uses versioned paths; ADOClient should NOT inject api-version
                assert "api-version" not in str(route.calls[0].request.url)

    @pytest.mark.asyncio
    async def test_get_classification_nodes(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/wit/classificationnodes").mock(
                    return_value=httpx.Response(200, json={"value": [{"name": "Area"}]})
                )
                result = await adapter.get_classification_nodes("MyProject")
                assert result == {"value": [{"name": "Area"}]}

    @pytest.mark.asyncio
    async def test_get_custom_fields_count(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/_apis/work/processes/proc1/workItemTypes/Bug/fields").mock(
                    return_value=httpx.Response(
                        200,
                        json={
                            "value": [
                                {"name": "f1", "customization": "custom"},
                                {"name": "f2", "customization": "system"},
                                {"name": "f3", "customization": "custom"},
                            ]
                        },
                    )
                )
                count = await adapter.get_custom_fields_count("proc1", "Bug")
                assert count == 2


class TestArtifactFeeds:
    @pytest.mark.asyncio
    async def test_list_artifact_feeds_routes_to_feeds_org_scoped(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=FEEDS) as mock:
                mock.get("/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": "f1"}]})
                )
                feeds = await adapter.list_artifact_feeds()
                assert [f["id"] for f in feeds] == ["f1"]

    @pytest.mark.asyncio
    async def test_list_artifact_feeds_project_scoped(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=FEEDS) as mock:
                route = mock.get("/MyProject/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                await adapter.list_artifact_feeds("MyProject")
                assert route.call_count == 1


class TestTestPlansAndBranchPolicies:
    @pytest.mark.asyncio
    async def test_list_test_plans_paginates(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/testplan/plans").mock(
                    side_effect=[
                        httpx.Response(
                            200,
                            headers={"x-ms-continuationtoken": "tp2"},
                            json={"value": [{"id": 1}]},
                        ),
                        httpx.Response(200, json={"value": [{"id": 2}]}),
                    ]
                )
                plans = await adapter.list_test_plans("MyProject")
                assert [p["id"] for p in plans] == [1, 2]

    @pytest.mark.asyncio
    async def test_list_branch_policies_paginates(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/git/policy/configurations").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": "bp1"}]})
                )
                policies = await adapter.list_branch_policies("MyProject")
                assert [p["id"] for p in policies] == ["bp1"]


class TestTfvcChangesets:
    @pytest.mark.asyncio
    async def test_list_tfvc_changesets_summary(self, auth: PATAuth) -> None:
        """Walks: latest probe -> $skip/$top counter -> summary dict."""
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/tfvc/changesets").mock(
                    side_effect=[
                        # latest probe
                        httpx.Response(
                            200,
                            json={
                                "value": [
                                    {"changesetId": 1234, "createdDate": "2026-04-28T01:02:03Z"}
                                ]
                            },
                        ),
                        # counter pages: 100, 50, then natural termination
                        httpx.Response(200, json={"value": [{"id": i} for i in range(100)]}),
                        httpx.Response(200, json={"value": [{"id": i} for i in range(50)]}),
                    ]
                )
                summary = await adapter.list_tfvc_changesets("MyProject")
                assert summary == {
                    "total_changesets": 150,
                    "latest_changeset_date": "2026-04-28T01:02:03Z",
                }

    @pytest.mark.asyncio
    async def test_list_tfvc_changesets_empty_when_no_data(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/tfvc/changesets").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                summary = await adapter.list_tfvc_changesets("MyProject")
                assert summary == {"total_changesets": 0, "latest_changeset_date": None}

    @pytest.mark.asyncio
    async def test_list_tfvc_changesets_returns_empty_on_404(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/tfvc/changesets").mock(
                    return_value=httpx.Response(404, json={"message": "no tfvc"})
                )
                summary = await adapter.list_tfvc_changesets("MyProject")
                assert summary == {"total_changesets": 0, "latest_changeset_date": None}

    @pytest.mark.asyncio
    async def test_list_tfvc_changesets_propagates_500(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/tfvc/changesets").mock(
                    return_value=httpx.Response(500, text="boom")
                )
                with pytest.raises(APIError):
                    await adapter.list_tfvc_changesets("MyProject")

    @pytest.mark.asyncio
    async def test_list_tfvc_changesets_propagates_500_from_count_loop(self, auth: PATAuth) -> None:
        """Probe succeeds; the inner $skip/$top counter then raises 500.

        Proves the try/except wrapper covers the paginator iteration —
        not just the outer "fetch latest" probe.
        """
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/tfvc/changesets").mock(
                    side_effect=[
                        httpx.Response(
                            200, json={"value": [{"id": 9, "createdDate": "2024-01-01"}]}
                        ),
                        httpx.Response(500, text="boom"),
                    ]
                )
                with pytest.raises(APIError):
                    await adapter.list_tfvc_changesets("MyProject")

    @pytest.mark.asyncio
    async def test_list_tfvc_changesets_returns_empty_on_404_from_count_loop(
        self, auth: PATAuth
    ) -> None:
        """Probe succeeds; the inner $skip/$top counter then 404s.

        Proves the 404→empty translation also covers the inner loop.
        """
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=BASE) as mock:
                mock.get("/MyProject/_apis/tfvc/changesets").mock(
                    side_effect=[
                        httpx.Response(
                            200, json={"value": [{"id": 9, "createdDate": "2024-01-01"}]}
                        ),
                        httpx.Response(404, json={"message": "gone"}),
                    ]
                )
                summary = await adapter.list_tfvc_changesets("MyProject")
                assert summary == {"total_changesets": 0, "latest_changeset_date": None}


class TestUsersAndEntitlements:
    @pytest.mark.asyncio
    async def test_list_user_entitlements_routes_to_vsaex(self, auth: PATAuth) -> None:
        """Pagination via response-body continuationToken (not header)."""
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=VSAEX) as mock:
                mock.get("/_apis/userentitlements").mock(
                    side_effect=[
                        httpx.Response(
                            200,
                            json={
                                "items": [{"id": "u1"}, {"id": "u2"}],
                                "continuationToken": "page2",
                                "totalCount": 3,
                            },
                        ),
                        httpx.Response(
                            200,
                            json={"items": [{"id": "u3"}], "continuationToken": ""},
                        ),
                    ]
                )
                ents = await adapter.list_user_entitlements()
                assert [e["id"] for e in ents] == ["u1", "u2", "u3"]

    @pytest.mark.asyncio
    async def test_list_user_entitlements_falls_back_to_members_field(self, auth: PATAuth) -> None:
        """Older response shape used `members` instead of `items`."""
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=VSAEX) as mock:
                mock.get("/_apis/userentitlements").mock(
                    return_value=httpx.Response(
                        200, json={"members": [{"id": "u1"}], "continuationToken": ""}
                    )
                )
                ents = await adapter.list_user_entitlements()
                assert [e["id"] for e in ents] == ["u1"]

    @pytest.mark.asyncio
    async def test_list_users_routes_to_vssps_returns_typed_models(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=VSSPS) as mock:
                mock.get("/_apis/graph/users").mock(
                    side_effect=[
                        httpx.Response(
                            200,
                            headers={"x-ms-continuationtoken": "cursor"},
                            json={
                                "value": [
                                    {
                                        "descriptor": "aad.abc",
                                        "principalName": "alice@example.com",
                                        "displayName": "Alice",
                                        "mailAddress": "alice@example.com",
                                    }
                                ]
                            },
                        ),
                        httpx.Response(
                            200,
                            json={
                                "value": [
                                    {
                                        "descriptor": "aad.def",
                                        "principalName": "bob@example.com",
                                        "displayName": "Bob",
                                        "mailAddress": None,
                                    }
                                ]
                            },
                        ),
                    ]
                )
                users = await adapter.list_users()
                assert len(users) == 2
                assert isinstance(users[0], User)
                assert users[0].id == "aad.abc"
                assert users[0].username == "alice@example.com"
                assert users[0].display_name == "Alice"
                assert users[0].email == "alice@example.com"
                assert users[1].email is None

    @pytest.mark.asyncio
    async def test_list_users_sends_preview_api_version(self, auth: PATAuth) -> None:
        async with _make_adapter(auth) as adapter:
            with respx.mock(base_url=VSSPS) as mock:
                route = mock.get("/_apis/graph/users").mock(
                    return_value=httpx.Response(200, json={"value": []}),
                )
                await adapter.list_users()
                assert route.calls.call_count == 1
                request = route.calls.last.request
                assert request.url.params["api-version"] == "7.1-preview.1"


class TestLifecycle:
    @pytest.mark.asyncio
    async def test_close_closes_underlying_client(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        await adapter.close()
        for host in ("dev", "vsrm", "feeds", "analytics", "vssps", "vsaex"):
            assert adapter.client.httpx_client(host).is_closed

    @pytest.mark.asyncio
    async def test_async_context_manager_closes_on_exit(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        async with adapter:
            pass
        assert adapter.client.httpx_client("dev").is_closed
