"""BaseADOClient shared transport-loop tests.

A tiny `_TinyClient(BaseADOClient)` defined inside this module exercises the
shared retry / rate-limit / error-mapping loop independently of cloud or
server. One place to assert loop semantics so future backends don't have
to re-prove them.
"""

from __future__ import annotations

import asyncio

import httpx
import pytest
import respx

from ado_source_core import APIError, AuthenticationError, PATAuth, RateLimitError
from ado_source_core.client import BaseADOClient

_TINY_BASE = "https://tiny.example.com"


class _TinyClient(BaseADOClient):
    """Minimal BaseADOClient subclass — single host, fixed api-version."""

    def __init__(self, *, auth: PATAuth, max_retries: int = 3) -> None:
        self._max_retries = max_retries
        self._clients = {
            "dev": httpx.AsyncClient(
                base_url=_TINY_BASE,
                headers={"Accept": "application/json", **auth.headers()},
                timeout=5.0,
            ),
        }

    @property
    def api_version(self) -> str:
        return "9.9"


@pytest.fixture
def auth() -> PATAuth:
    return PATAuth(token="dummy-pat")


_recorded_sleeps: list[float] = []


async def _instant_sleep(seconds: float) -> None:
    _recorded_sleeps.append(seconds)


@pytest.fixture(autouse=True)
def _no_sleep(monkeypatch: pytest.MonkeyPatch) -> None:
    _recorded_sleeps.clear()
    monkeypatch.setattr(asyncio, "sleep", _instant_sleep)


class TestBaseADOClientRequest:
    @pytest.mark.asyncio
    async def test_injects_api_version_query_param(self, auth: PATAuth) -> None:
        async with _TinyClient(auth=auth) as client:
            with respx.mock(base_url=_TINY_BASE) as mock:
                route = mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                await client.request("GET", "/_apis/projects")
                assert route.calls[0].request.url.params["api-version"] == "9.9"

    @pytest.mark.asyncio
    async def test_skip_api_version_omits_param(self, auth: PATAuth) -> None:
        async with _TinyClient(auth=auth) as client:
            with respx.mock(base_url=_TINY_BASE) as mock:
                route = mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={})
                )
                await client.request("GET", "/_apis/connectionData", skip_api_version=True)
                assert "api-version" not in route.calls[0].request.url.params

    @pytest.mark.asyncio
    async def test_401_maps_to_authentication_error(self, auth: PATAuth) -> None:
        async with _TinyClient(auth=auth) as client:
            with respx.mock(base_url=_TINY_BASE) as mock:
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(401, json={"message": "no"})
                )
                with pytest.raises(AuthenticationError):
                    await client.request("GET", "/_apis/projects")

    @pytest.mark.asyncio
    async def test_429_retries_then_raises_rate_limit(self, auth: PATAuth) -> None:
        async with _TinyClient(auth=auth, max_retries=2) as client:
            with respx.mock(base_url=_TINY_BASE) as mock:
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(429, headers={"Retry-After": "1"})
                )
                with pytest.raises(RateLimitError) as exc_info:
                    await client.request("GET", "/_apis/projects")
                assert exc_info.value.retry_after == 1.0
                # Verify retry actually waited the Retry-After value (1s) on attempt 0.
                assert _recorded_sleeps == [1.0]

    @pytest.mark.asyncio
    async def test_503_retries_with_exponential_backoff(self, auth: PATAuth) -> None:
        async with _TinyClient(auth=auth, max_retries=3) as client:
            with respx.mock(base_url=_TINY_BASE) as mock:
                mock.get("/_apis/projects").mock(
                    side_effect=[
                        httpx.Response(503),
                        httpx.Response(503),
                        httpx.Response(200, json={"value": []}),
                    ]
                )
                response = await client.request("GET", "/_apis/projects")
                assert response.status_code == 200
                # Verify exponential backoff: 2**0=1, 2**1=2.
                assert _recorded_sleeps == [1.0, 2.0]

    @pytest.mark.asyncio
    async def test_network_error_raises_api_error_with_none_status(self, auth: PATAuth) -> None:
        async with _TinyClient(auth=auth, max_retries=2) as client:
            with respx.mock(base_url=_TINY_BASE) as mock:
                mock.get("/_apis/projects").mock(side_effect=httpx.ConnectError("boom"))
                with pytest.raises(APIError) as exc_info:
                    await client.request("GET", "/_apis/projects")
                assert exc_info.value.status_code is None
                # Verify exponential backoff was attempted on retry: 2**0=1.
                assert _recorded_sleeps == [1.0]
