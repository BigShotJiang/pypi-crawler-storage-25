"""Pipeline model tests."""

import pytest
from pydantic import ValidationError

import ado_source_core
from ado_source_core.models import (
    PipelineAnalysis,
    PipelineInventoryItem,
    PipelineMigrationComplexity,
    PipelineStepInfo,
    PipelineType,
    TaskSupportLevel,
)


def test_pipeline_type_values() -> None:
    assert PipelineType.YAML == "yaml"
    assert PipelineType.CLASSIC_BUILD == "classic_build"


def test_task_support_level_values() -> None:
    assert TaskSupportLevel.SUPPORTED == "supported"
    assert TaskSupportLevel.SCRIPT == "script"


def test_pipeline_migration_complexity_values() -> None:
    assert PipelineMigrationComplexity.TRIVIAL == "trivial"
    assert PipelineMigrationComplexity.HIGH == "high"


def test_pipeline_step_info_minimal() -> None:
    step = PipelineStepInfo(
        name="DotNetCoreCLI@2",
        step_type="task",
        support_level=TaskSupportLevel.SUPPORTED,
    )
    assert step.name == "DotNetCoreCLI@2"
    assert step.display_name is None
    assert step.notes is None


def test_pipeline_analysis_defaults() -> None:
    analysis = PipelineAnalysis()
    assert analysis.has_pipelines is False
    assert analysis.total_step_count == 0
    assert analysis.migration_complexity == PipelineMigrationComplexity.TRIVIAL
    assert analysis.uses_docker is False


def test_pipeline_analysis_negative_count_rejected() -> None:
    with pytest.raises(ValidationError):
        PipelineAnalysis(total_step_count=-1)


def test_pipeline_inventory_item_minimal() -> None:
    item = PipelineInventoryItem(
        id="p1",
        name="My Pipeline",
        pipeline_type=PipelineType.YAML,
        project_name="MyProject",
    )
    assert item.id == "p1"
    assert item.has_triggers is False
    assert item.steps == []
    assert item.analysis is None


def test_pipeline_inventory_item_extra_rejected() -> None:
    with pytest.raises(ValidationError):
        PipelineInventoryItem(  # type: ignore[call-arg]
            id="p1",
            name="My Pipeline",
            pipeline_type=PipelineType.YAML,
            project_name="MyProject",
            unknown="x",
        )


def test_pipeline_models_re_exported() -> None:
    assert ado_source_core.PipelineType is PipelineType
    assert ado_source_core.TaskSupportLevel is TaskSupportLevel
    assert ado_source_core.PipelineMigrationComplexity is PipelineMigrationComplexity
    assert ado_source_core.PipelineStepInfo is PipelineStepInfo
    assert ado_source_core.PipelineAnalysis is PipelineAnalysis
    assert ado_source_core.PipelineInventoryItem is PipelineInventoryItem
