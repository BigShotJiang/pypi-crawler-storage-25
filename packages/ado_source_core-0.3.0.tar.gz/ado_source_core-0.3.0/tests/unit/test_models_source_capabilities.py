"""SourceType and SourceCapabilities model tests."""

import pytest
from pydantic import ValidationError

import ado_source_core
from ado_source_core.models import SourceCapabilities, SourceType


def test_source_type_values() -> None:
    assert SourceType.AZURE_DEVOPS_CLOUD == "azure-devops-cloud"
    assert SourceType.AZURE_DEVOPS_SERVER == "azure-devops-server"


def test_capabilities_minimal() -> None:
    caps = SourceCapabilities(source_type=SourceType.AZURE_DEVOPS_SERVER)
    assert caps.source_type == SourceType.AZURE_DEVOPS_SERVER
    assert caps.api_version == "7.1"
    assert caps.supports_pipelines is True


def test_capabilities_cloud_default() -> None:
    caps = SourceCapabilities.cloud_default()
    assert caps.source_type == SourceType.AZURE_DEVOPS_CLOUD


def test_capabilities_extra_rejected() -> None:
    with pytest.raises(ValidationError):
        SourceCapabilities(  # type: ignore[call-arg]
            source_type=SourceType.AZURE_DEVOPS_CLOUD, unknown="x"
        )


def test_capabilities_re_exported() -> None:
    assert ado_source_core.SourceCapabilities is SourceCapabilities
    assert ado_source_core.SourceType is SourceType


class TestServerDefault:
    def test_returns_server_source_type(self) -> None:
        caps = SourceCapabilities.server_default()
        assert caps.source_type == SourceType.AZURE_DEVOPS_SERVER

    def test_default_api_version_is_7_0(self) -> None:
        caps = SourceCapabilities.server_default()
        assert caps.api_version == "7.0"

    def test_supports_user_entitlements_is_hard_false(self) -> None:
        caps = SourceCapabilities.server_default()
        assert caps.supports_user_entitlements is False

    def test_supports_collections_is_true(self) -> None:
        caps = SourceCapabilities.server_default()
        assert caps.supports_collections is True

    def test_compatibility_mode_5_1(self) -> None:
        caps = SourceCapabilities.server_default(api_version="5.1")
        assert caps.compatibility_mode is True
        assert any("5.1" in n for n in caps.notes)

    def test_compatibility_mode_5_0(self) -> None:
        caps = SourceCapabilities.server_default(api_version="5.0")
        assert caps.compatibility_mode is True
        assert any("5.0" in n for n in caps.notes)

    def test_compatibility_mode_off_for_6_0(self) -> None:
        caps = SourceCapabilities.server_default(api_version="6.0")
        assert caps.compatibility_mode is False
        assert caps.notes == []


class TestSoftCapabilityFlags:
    def test_default_true_on_cloud(self) -> None:
        caps = SourceCapabilities.cloud_default()
        assert caps.supports_graph_api is True
        assert caps.supports_analytics_odata is True
        assert caps.supports_artifact_feeds is True

    def test_default_true_on_server_before_overrides(self) -> None:
        caps = SourceCapabilities.server_default()
        assert caps.supports_graph_api is True
        assert caps.supports_analytics_odata is True
        assert caps.supports_artifact_feeds is True

    def test_supports_packages_is_removed(self) -> None:
        caps = SourceCapabilities.cloud_default()
        assert not hasattr(caps, "supports_packages")


class TestWithOverridesWhitelist:
    def test_applies_soft_cap_overrides(self) -> None:
        caps = SourceCapabilities.server_default()
        new = caps.with_overrides(
            {
                "supports_graph_api": False,
                "supports_analytics_odata": False,
                "supports_artifact_feeds": False,
            }
        )
        assert new.supports_graph_api is False
        assert new.supports_analytics_odata is False
        assert new.supports_artifact_feeds is False

    def test_returns_new_instance(self) -> None:
        caps = SourceCapabilities.server_default()
        new = caps.with_overrides({"supports_graph_api": False})
        assert caps.supports_graph_api is True  # original unchanged
        assert new.supports_graph_api is False
        assert new is not caps

    def test_rejects_non_whitelisted_key(self) -> None:
        caps = SourceCapabilities.server_default()
        with pytest.raises(ValueError, match="disallowed"):
            caps.with_overrides({"supports_user_entitlements": True})

    def test_rejects_unknown_key(self) -> None:
        caps = SourceCapabilities.server_default()
        with pytest.raises(ValueError, match="disallowed"):
            caps.with_overrides({"unknown_capability": True})

    def test_appends_notes(self) -> None:
        caps = SourceCapabilities.server_default(api_version="5.1")
        new = caps.with_overrides(
            {"supports_graph_api": False},
            notes=["graph probe returned 401; PAT may lack vso.graph"],
        )
        assert len(new.notes) == len(caps.notes) + 1
        assert any("vso.graph" in n for n in new.notes)

    def test_overridable_keys_constant(self) -> None:
        assert SourceCapabilities.OVERRIDABLE_SOFT_CAPABILITY_KEYS == frozenset(
            {
                "supports_graph_api",
                "supports_analytics_odata",
                "supports_artifact_feeds",
            }
        )
