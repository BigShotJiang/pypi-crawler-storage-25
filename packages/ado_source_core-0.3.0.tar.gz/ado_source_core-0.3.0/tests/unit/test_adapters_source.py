"""Verify the vendored SourceAdapter ABC contract.

Stage 1.1.3 of the Shyftport pilot extraction. Vendored from
n8group-oss/migration-core; see src/ado_source_core/adapters/source.py
for the re-license trail.
"""

import pytest

import ado_source_core
from ado_source_core.adapters.source import SourceAdapter


def test_source_adapter_is_abstract() -> None:
    """SourceAdapter cannot be instantiated directly — abstract methods unimplemented."""
    with pytest.raises(TypeError):
        SourceAdapter()  # type: ignore[abstract,type-var]


def test_source_adapter_lists_required_abstract_methods() -> None:
    """The 5-abstract / 5-default contract from migration-core is preserved."""
    abstract_methods = SourceAdapter.__abstractmethods__
    assert abstract_methods == frozenset(
        {
            "list_repositories",
            "get_repository",
            "list_users",
            "get_user",
            "close",
        }
    )


def test_source_adapter_re_exported_from_package_root() -> None:
    """SourceAdapter is part of ado_source_core's public API."""
    assert ado_source_core.SourceAdapter is SourceAdapter
