"""AzureDevOpsServerAdapter unit tests.

Mirrors the cloud adapter tests' shape (one class per method asserting URL
shape + api-version + return-type) plus capability-gating dual-branch
tests, method-set parity test, and pagination-compatibility tests.

Tests use respx to mock the underlying single httpx client at the
collection-scoped base URL.
"""

from __future__ import annotations

import asyncio
import inspect
from typing import Any

import httpx
import pytest
import respx

from ado_source_core import (
    AuthenticationError,
    AzureDevOpsCloudAdapter,
    AzureDevOpsServerAdapter,
    PATAuth,
    Repository,
    SourceCapabilities,
    SourceType,
    UnsupportedOnAzureDevOpsServerError,
    User,
)
from ado_source_core.adapters.source import SourceAdapter
from ado_source_core.client import ADOServerClient
from ado_source_core.pagination import paginate_via_adoclient_body_continuation_token

_BASE = "https://devops.example.com/tfs"
_COLLECTION = "DefaultCollection"
_RESOLVED = f"{_BASE}/{_COLLECTION}"


@pytest.fixture
def auth() -> PATAuth:
    return PATAuth(token="dummy-pat")


def _make_client(auth: PATAuth, **overrides: Any) -> ADOServerClient:
    """Server client with explicit api_version=7.0 — bypasses version probe.

    Also seeds ``_capability_overrides`` and ``_graph_api_version`` so any
    subsequent ``await client.connect()`` short-circuits via the
    "explicit api_version + non-empty capability_overrides" path. Adapter
    tests that call ``get_capabilities()`` (which delegates to
    ``connect()``) won't hit unmocked soft-cap probe URLs as a result.
    """
    kwargs: dict[str, Any] = {
        "base_url": _BASE,
        "collection": _COLLECTION,
        "auth": auth,
        "api_version": "7.0",
        "max_retries": 3,
    }
    kwargs.update(overrides)
    client = ADOServerClient(**kwargs)
    client._capability_overrides = {  # type: ignore[attr-defined]
        "supports_graph_api": True,
        "supports_analytics_odata": True,
        "supports_artifact_feeds": True,
    }
    client._graph_api_version = "7.0"  # type: ignore[attr-defined]
    return client


def _make_adapter(
    auth: PATAuth,
    *,
    capabilities: SourceCapabilities | None = None,
) -> AzureDevOpsServerAdapter:
    return AzureDevOpsServerAdapter(client=_make_client(auth), capabilities=capabilities)


async def _instant_sleep(_seconds: float) -> None:
    return None


@pytest.fixture(autouse=True)
def _no_sleep(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(asyncio, "sleep", _instant_sleep)


# ---------------------------------------------------------------------------
# Construction / capabilities / lifecycle
# ---------------------------------------------------------------------------


class TestConstruction:
    def test_subclasses_source_adapter(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        assert isinstance(adapter, SourceAdapter)

    def test_NOT_subclass_of_cloud_adapter(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        assert not isinstance(adapter, AzureDevOpsCloudAdapter)


class TestGetCapabilities:
    @pytest.mark.asyncio
    async def test_first_call_applies_overrides_on_top_of_server_default(
        self,
        auth: PATAuth,
    ) -> None:
        client = _make_client(auth)
        # Simulate a connected client with probe overrides + notes.
        client._capability_overrides = {  # type: ignore[attr-defined]
            "supports_graph_api": False,
            "supports_analytics_odata": False,
            "supports_artifact_feeds": False,
        }
        client._capability_notes = [  # type: ignore[attr-defined]
            "supports_graph_api probe returned 401; PAT may lack vso.graph"
        ]
        adapter = AzureDevOpsServerAdapter(client=client)
        try:
            caps = await adapter.get_capabilities()
            assert caps.source_type == SourceType.AZURE_DEVOPS_SERVER
            assert caps.api_version == "7.0"
            assert caps.supports_user_entitlements is False
            assert caps.supports_graph_api is False
            assert caps.supports_analytics_odata is False
            assert caps.supports_artifact_feeds is False
            assert any("vso.graph" in n for n in caps.notes)
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_subsequent_calls_return_cached(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            caps1 = await adapter.get_capabilities()
            caps2 = await adapter.get_capabilities()
            assert caps1 is caps2
        finally:
            await adapter.close()


class TestVerifyCredentials:
    @pytest.mark.asyncio
    async def test_happy_path(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(
                        200,
                        json={"value": [{"name": "ProjA", "id": "p1"}]},
                    )
                )
                mock.get("/ProjA/_apis/git/repositories").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                mock.get("/ProjA/_apis/build/definitions").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                assert await adapter.verify_credentials() is True
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_401_on_first_probe_raises_with_server_remediation(
        self,
        auth: PATAuth,
    ) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/projects").mock(return_value=httpx.Response(401))
                with pytest.raises(AuthenticationError, match="Azure DevOps Server"):
                    await adapter.verify_credentials()
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_connectionData_auth_failure_remaps_to_server_remediation(
        self,
        auth: PATAuth,
    ) -> None:
        """A 401 during the underlying ``connect()`` (e.g., bad PAT on the
        connectionData round-trip) must surface the server-flavored
        remediation message — not the generic transport message from
        ``BaseADOClient.request``.

        This covers the contract from the spec's error-handling table
        (lines 719-733): version-probe auth failures get the
        server-flavored remediation. The fix moved the ``connect()`` call
        inside ``verify_credentials``'s ``try/except AuthenticationError``
        block so the same remap applies to probe-time auth failures as to
        per-call probe failures.
        """
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        adapter = AzureDevOpsServerAdapter(client=client)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                # connectionData returns 401 — auth failure during the
                # api-version probe before verify_credentials' own probe
                # sequence runs. BaseADOClient.request remaps this to
                # AuthenticationError("Invalid PAT or insufficient
                # permissions"); verify_credentials must then remap THAT
                # to the server-flavored remediation.
                mock.get("/_apis/connectionData").mock(return_value=httpx.Response(401))
                with pytest.raises(AuthenticationError, match="Azure DevOps Server") as excinfo:
                    await adapter.verify_credentials()
                # Remediation message includes the server-specific guidance
                # (PAT scopes, collection permissions, base_url shape).
                assert "PAT" in str(excinfo.value)
                assert "collection" in str(excinfo.value)
                assert "base_url" in str(excinfo.value)
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_verify_credentials_preserves_response_body_in_remapped_error(
        self,
        auth: PATAuth,
    ) -> None:
        """The ``AuthenticationError`` raised by ``verify_credentials`` must
        carry the original ``response_body`` from the underlying
        ``BaseADOClient.request`` failure so callers retain the
        server-provided diagnostics in addition to the improved
        server-flavored remediation text.

        Previously only ``status_code`` was preserved on the remap, which
        dropped useful upstream context (e.g. the ``"message"`` field
        from an ADO error envelope).
        """
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                # 401 with a structured JSON envelope — this becomes
                # AuthenticationError.response_body inside BaseADOClient.
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(
                        401,
                        json={"message": "Server-side reason"},
                    )
                )
                with pytest.raises(AuthenticationError) as excinfo:
                    await adapter.verify_credentials()
                exc = excinfo.value
                # Existing assertion: server-flavored remediation text.
                assert "Azure DevOps Server" in str(exc)
                assert "PAT" in str(exc)
                # New assertion: response_body survived the remap.
                assert exc.response_body is not None
                assert exc.response_body.get("message") == "Server-side reason"
                # And status_code is still preserved (regression guard).
                assert exc.status_code == 401
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_probe_based_standalone_invocation_self_bootstraps(
        self,
        auth: PATAuth,
    ) -> None:
        """``verify_credentials`` self-bootstraps via ``client.connect()``.

        Constructs a probe-based adapter (no explicit ``api_version=``, no
        prior ``connect()`` call, no ``async with``) and asserts that
        calling ``verify_credentials`` directly succeeds. Without the
        ``await self._client.connect()`` at the top of
        ``verify_credentials``, the api-version property would raise
        ``RuntimeError: ADOServerClient is not connected`` instead of
        running the network-level credential check the method's name
        promises.
        """
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        adapter = AzureDevOpsServerAdapter(client=client)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                # Probe path: connectionData advertises a snappable version,
                # then /_apis/projects?$top=1 returns one project name so
                # the Analytics soft-cap probe has a fallback hint.
                mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "7.0"})
                )
                # Soft-cap probes (parallel) — all succeed.
                mock.get("/_apis/graph/users").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                mock.get("/_odata/v4.0-preview/$metadata").mock(
                    return_value=httpx.Response(200, text="<edmx/>")
                )
                mock.get("/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                # verify_credentials happy-path: projects list, then
                # repositories + build definitions for the first project.
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(
                        200,
                        json={"value": [{"name": "ProjA", "id": "p1"}]},
                    )
                )
                mock.get("/ProjA/_apis/git/repositories").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                mock.get("/ProjA/_apis/build/definitions").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                assert await adapter.verify_credentials() is True
                # connect() actually ran — api-version got populated.
                assert adapter.client.api_version == "7.0"
        finally:
            await adapter.close()


# ---------------------------------------------------------------------------
# Per-method conformance — one class per method, URL shape + api-version + type.
# ---------------------------------------------------------------------------


class TestListProjects:
    @pytest.mark.asyncio
    async def test_collection_scoped_url_and_api_version(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                route = mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(
                        200, json={"value": [{"id": "p1", "name": "ProjA"}]}
                    )
                )
                projects = await adapter.list_projects()
                assert projects[0]["name"] == "ProjA"
                assert route.calls[0].request.url.params["api-version"] == "7.0"
        finally:
            await adapter.close()


class TestGetProjectDetails:
    @pytest.mark.asyncio
    async def test_url_includes_capabilities_query(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                route = mock.get("/_apis/projects/p1").mock(
                    return_value=httpx.Response(200, json={"id": "p1"})
                )
                result = await adapter.get_project_details("p1")
                assert result == {"id": "p1"}
                assert route.calls[0].request.url.params["includeCapabilities"] == "true"
        finally:
            await adapter.close()


class TestGetProcessTemplate:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/work/processes/agile").mock(
                    return_value=httpx.Response(200, json={"name": "Agile"})
                )
                result = await adapter.get_process_template("agile")
                assert result["name"] == "Agile"
        finally:
            await adapter.close()


class TestListRepositories:
    @pytest.mark.asyncio
    async def test_returns_typed_repository_list(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/git/repositories").mock(
                    return_value=httpx.Response(
                        200,
                        json={
                            "value": [
                                {
                                    "id": "r1",
                                    "name": "RepoA",
                                    "defaultBranch": "refs/heads/main",
                                    "size": 1024,
                                    "remoteUrl": "https://...",
                                    "sshUrl": "git@...",
                                },
                            ]
                        },
                    )
                )
                repos = await adapter.list_repositories(project="ProjA")
                assert len(repos) == 1
                assert isinstance(repos[0], Repository)
                assert repos[0].default_branch == "main"
                assert repos[0].full_name == "ProjA/RepoA"
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_missing_project_raises(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with pytest.raises(ValueError, match="project is required"):
                await adapter.list_repositories()
        finally:
            await adapter.close()


class TestGetRepository:
    @pytest.mark.asyncio
    async def test_raises_not_implemented(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with pytest.raises(NotImplementedError):
                await adapter.get_repository("any/id")
        finally:
            await adapter.close()


class TestCountBranches:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/git/repositories/RepoA/refs").mock(
                    return_value=httpx.Response(
                        200,
                        json={
                            "value": [
                                {"name": "refs/heads/main"},
                                {"name": "refs/heads/dev"},
                            ]
                        },
                    )
                )
                count = await adapter.count_branches("ProjA/RepoA")
                assert count == 2
        finally:
            await adapter.close()


class TestCountPullRequests:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/git/repositories/RepoA/pullrequests").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": 1}]})
                )
                count = await adapter.count_pull_requests("ProjA/RepoA")
                assert count == 1
        finally:
            await adapter.close()


class TestDetectLfsPatterns:
    @pytest.mark.asyncio
    async def test_finds_filter_lfs(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/git/repositories/RepoA/items").mock(
                    return_value=httpx.Response(
                        200,
                        json={
                            "content": "*.psd filter=lfs diff=lfs merge=lfs -text\n",
                        },
                    )
                )
                result = await adapter.detect_lfs_patterns("ProjA/RepoA")
                assert result == {"has_lfs": True, "patterns": ["*.psd"]}
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_404_returns_empty(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/git/repositories/RepoA/items").mock(
                    return_value=httpx.Response(404)
                )
                result = await adapter.detect_lfs_patterns("ProjA/RepoA")
                assert result == {"has_lfs": False, "patterns": []}
        finally:
            await adapter.close()


class TestAnalyzeLargeFiles:
    @pytest.mark.asyncio
    async def test_finds_large_blob(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/git/repositories/RepoA/refs").mock(
                    return_value=httpx.Response(200, json={"value": [{"objectId": "abc"}]})
                )
                mock.get("/ProjA/_apis/git/repositories/RepoA/commits/abc").mock(
                    return_value=httpx.Response(200, json={"treeId": "tree123"})
                )
                mock.get("/ProjA/_apis/git/repositories/RepoA/trees/tree123").mock(
                    return_value=httpx.Response(
                        200,
                        json={
                            "treeEntries": [
                                {
                                    "gitObjectType": "blob",
                                    "size": 200_000_000,
                                    "relativePath": "huge.bin",
                                }
                            ]
                        },
                    )
                )
                result = await adapter.analyze_large_files("ProjA/RepoA")
                assert result["large_files"][0]["path"] == "huge.bin"
        finally:
            await adapter.close()


class TestGetFileContent:
    @pytest.mark.asyncio
    async def test_returns_content(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/git/repositories/RepoA/items").mock(
                    return_value=httpx.Response(200, json={"content": "hello"})
                )
                result = await adapter.get_file_content("ProjA", "RepoA", "README.md")
                assert result == "hello"
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_404_returns_none(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/git/repositories/RepoA/items").mock(
                    return_value=httpx.Response(404)
                )
                result = await adapter.get_file_content("ProjA", "RepoA", "missing")
                assert result is None
        finally:
            await adapter.close()


class TestListBuildDefinitions:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/build/definitions").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": 1}]})
                )
                result = await adapter.list_build_definitions("ProjA")
                assert result == [{"id": 1}]
        finally:
            await adapter.close()


class TestGetBuildDefinition:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/build/definitions/42").mock(
                    return_value=httpx.Response(200, json={"id": 42})
                )
                result = await adapter.get_build_definition("ProjA", 42)
                assert result == {"id": 42}
        finally:
            await adapter.close()


class TestListReleaseDefinitions:
    @pytest.mark.asyncio
    async def test_url_is_collection_scoped_not_vsrm(self, auth: PATAuth) -> None:
        """Server adapter must NOT route to vsrm.dev.azure.com."""
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                route = mock.get("/ProjA/_apis/release/definitions").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": 1}]})
                )
                result = await adapter.list_release_definitions("ProjA")
                assert result == [{"id": 1}]
                assert route.calls[0].request.url.host == "devops.example.com"
        finally:
            await adapter.close()


class TestGetReleaseDefinition:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/release/definitions/7").mock(
                    return_value=httpx.Response(200, json={"id": 7})
                )
                result = await adapter.get_release_definition("ProjA", 7)
                assert result == {"id": 7}
        finally:
            await adapter.close()


class TestListServiceConnections:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/serviceendpoint/endpoints").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": "se1"}]})
                )
                result = await adapter.list_service_connections("ProjA")
                assert result == [{"id": "se1"}]
        finally:
            await adapter.close()


class TestListVariableGroups:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/distributedtask/variablegroups").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": 1}]})
                )
                result = await adapter.list_variable_groups("ProjA")
                assert result == [{"id": 1}]
        finally:
            await adapter.close()


class TestListEnvironments:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/distributedtask/environments").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": 1}]})
                )
                result = await adapter.list_environments("ProjA")
                assert result == [{"id": 1}]
        finally:
            await adapter.close()


class TestGetClassificationNodes:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                route = mock.get("/ProjA/_apis/wit/classificationnodes").mock(
                    return_value=httpx.Response(200, json={"depth": 0})
                )
                result = await adapter.get_classification_nodes("ProjA")
                assert result == {"depth": 0}
                assert route.calls[0].request.url.params["$depth"] == "10"
        finally:
            await adapter.close()


class TestGetCustomFieldsCount:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/work/processes/proc1/workItemTypes/Bug/fields").mock(
                    return_value=httpx.Response(
                        200,
                        json={
                            "value": [
                                {"customization": "custom"},
                                {"customization": "system"},
                            ]
                        },
                    )
                )
                count = await adapter.get_custom_fields_count("proc1", "Bug")
                assert count == 1
        finally:
            await adapter.close()


class TestListTestPlans:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/testplan/plans").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": 1}]})
                )
                result = await adapter.list_test_plans("ProjA")
                assert result == [{"id": 1}]
        finally:
            await adapter.close()


class TestListBranchPolicies:
    @pytest.mark.asyncio
    async def test_url(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/git/policy/configurations").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": 1}]})
                )
                result = await adapter.list_branch_policies("ProjA")
                assert result == [{"id": 1}]
        finally:
            await adapter.close()


class TestListTfvcChangesets:
    @pytest.mark.asyncio
    async def test_returns_summary(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/tfvc/changesets").mock(
                    side_effect=[
                        httpx.Response(
                            200,
                            json={"value": [{"createdDate": "2026-04-01T00:00:00Z"}]},
                        ),
                        httpx.Response(200, json={"value": [{"id": 1}, {"id": 2}]}),
                        httpx.Response(200, json={"value": []}),
                    ]
                )
                result = await adapter.list_tfvc_changesets("ProjA")
                assert result["total_changesets"] == 2
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_404_returns_empty(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/tfvc/changesets").mock(return_value=httpx.Response(404))
                result = await adapter.list_tfvc_changesets("ProjA")
                assert result == {"total_changesets": 0, "latest_changeset_date": None}
        finally:
            await adapter.close()


class TestGetUser:
    @pytest.mark.asyncio
    async def test_raises_not_implemented(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        try:
            with pytest.raises(NotImplementedError):
                await adapter.get_user("any-id")
        finally:
            await adapter.close()


# ---------------------------------------------------------------------------
# Capability gating — dual-branch tests for each gated method.
# ---------------------------------------------------------------------------


def _server_caps(**overrides: bool) -> SourceCapabilities:
    """Build a server capability set with optional flag overrides."""
    base = SourceCapabilities.server_default(api_version="7.0")
    if overrides:
        whitelisted = {
            k: v
            for k, v in overrides.items()
            if k in SourceCapabilities.OVERRIDABLE_SOFT_CAPABILITY_KEYS
        }
        return base.with_overrides(whitelisted)
    return base


class TestListUsersGating:
    @pytest.mark.asyncio
    async def test_supports_graph_api_true_uses_probe_resolved_preview_variant(
        self,
        auth: PATAuth,
    ) -> None:
        """When the probe stored ``graph_api_version="7.0-preview.1"``,
        ``list_users`` MUST send that exact value, not plain
        ``caps.api_version`` (this is the cloud-vs-server delta).
        """
        client = _make_client(auth)
        client._graph_api_version = "7.0-preview.1"  # type: ignore[attr-defined]
        adapter = AzureDevOpsServerAdapter(
            client=client,
            capabilities=_server_caps(supports_graph_api=True),
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                route = mock.get("/_apis/graph/users").mock(
                    return_value=httpx.Response(
                        200,
                        json={
                            "value": [
                                {
                                    "descriptor": "u1",
                                    "principalName": "alice@x",
                                    "displayName": "Alice",
                                    "mailAddress": "alice@x",
                                }
                            ]
                        },
                    )
                )
                users = await adapter.list_users()
                assert len(users) == 1
                assert isinstance(users[0], User)
                assert route.calls[0].request.url.params["api-version"] == "7.0-preview.1"
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_supports_graph_api_true_with_plain_variant(
        self,
        auth: PATAuth,
    ) -> None:
        """When the probe found that plain ``7.0`` worked (preview returned
        400), ``list_users`` MUST send plain ``7.0``.
        """
        client = _make_client(auth)
        client._graph_api_version = "7.0"  # type: ignore[attr-defined]
        adapter = AzureDevOpsServerAdapter(
            client=client,
            capabilities=_server_caps(supports_graph_api=True),
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                route = mock.get("/_apis/graph/users").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                await adapter.list_users()
                assert route.calls[0].request.url.params["api-version"] == "7.0"
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_supports_graph_api_false_raises(self, auth: PATAuth) -> None:
        adapter = AzureDevOpsServerAdapter(
            client=_make_client(auth),
            capabilities=_server_caps(supports_graph_api=False),
        )
        try:
            with pytest.raises(UnsupportedOnAzureDevOpsServerError) as exc_info:
                await adapter.list_users()
            assert exc_info.value.capability == "supports_graph_api"
            assert exc_info.value.api_version == "7.0"
            assert exc_info.value.remediation is not None
            assert "Graph extension" in exc_info.value.remediation
        finally:
            await adapter.close()


class TestQueryWorkItemCountsGating:
    @pytest.mark.asyncio
    async def test_supports_analytics_odata_true_returns_counts(
        self,
        auth: PATAuth,
    ) -> None:
        adapter = AzureDevOpsServerAdapter(
            client=_make_client(auth),
            capabilities=_server_caps(supports_analytics_odata=True),
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_odata/v4.0-preview/WorkItems").mock(
                    return_value=httpx.Response(
                        200,
                        json={
                            "value": [
                                {
                                    "WorkItemType": "Bug",
                                    "State": "Active",
                                    "Count": 3,
                                },
                            ]
                        },
                    )
                )
                result = await adapter.query_work_item_counts("ProjA")
                assert result["total"] == 3
                assert result["by_type"]["Bug"] == 3
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_supports_analytics_odata_false_raises(self, auth: PATAuth) -> None:
        adapter = AzureDevOpsServerAdapter(
            client=_make_client(auth),
            capabilities=_server_caps(supports_analytics_odata=False),
        )
        try:
            with pytest.raises(UnsupportedOnAzureDevOpsServerError) as exc_info:
                await adapter.query_work_item_counts("ProjA")
            assert exc_info.value.capability == "supports_analytics_odata"
            assert exc_info.value.remediation is not None
            assert "Analytics extension" in exc_info.value.remediation
        finally:
            await adapter.close()


class TestListArtifactFeedsGating:
    @pytest.mark.asyncio
    async def test_supports_artifact_feeds_true_with_project(
        self,
        auth: PATAuth,
    ) -> None:
        adapter = AzureDevOpsServerAdapter(
            client=_make_client(auth),
            capabilities=_server_caps(supports_artifact_feeds=True),
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": "f1"}]})
                )
                result = await adapter.list_artifact_feeds("ProjA")
                assert result == [{"id": "f1"}]
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_supports_artifact_feeds_true_without_project(
        self,
        auth: PATAuth,
    ) -> None:
        """No project arg -> collection-level URL `/_apis/packaging/feeds`."""
        adapter = AzureDevOpsServerAdapter(
            client=_make_client(auth),
            capabilities=_server_caps(supports_artifact_feeds=True),
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                route = mock.get("/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": "f0"}]})
                )
                result = await adapter.list_artifact_feeds()
                assert result == [{"id": "f0"}]
                assert route.call_count == 1
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_supports_artifact_feeds_false_raises(self, auth: PATAuth) -> None:
        adapter = AzureDevOpsServerAdapter(
            client=_make_client(auth),
            capabilities=_server_caps(supports_artifact_feeds=False),
        )
        try:
            with pytest.raises(UnsupportedOnAzureDevOpsServerError) as exc_info:
                await adapter.list_artifact_feeds("ProjA")
            assert exc_info.value.capability == "supports_artifact_feeds"
            assert exc_info.value.remediation is not None
            assert "Package Management" in exc_info.value.remediation
        finally:
            await adapter.close()


class TestListUserEntitlementsAlwaysRaises:
    @pytest.mark.asyncio
    async def test_raises_with_capability_user_entitlements(
        self,
        auth: PATAuth,
    ) -> None:
        # Even with a capability set that has supports_user_entitlements=True
        # (impossible normally, but constructible via direct model build),
        # the method MUST raise — it's a hard-coded raise.
        # Using server_default which sets it to False.
        adapter = _make_adapter(auth)
        try:
            with pytest.raises(UnsupportedOnAzureDevOpsServerError) as exc_info:
                await adapter.list_user_entitlements()
            assert exc_info.value.capability == "supports_user_entitlements"
            assert exc_info.value.api_version == "7.0"
            assert exc_info.value.remediation is not None
            assert "cloud-only" in exc_info.value.remediation
        finally:
            await adapter.close()


# ---------------------------------------------------------------------------
# Method-set parity test
# ---------------------------------------------------------------------------


def _public_async_methods(cls: type) -> dict[str, inspect.Signature]:
    out: dict[str, inspect.Signature] = {}
    for name, member in inspect.getmembers(cls):
        if name.startswith("_"):
            continue
        if not callable(member):
            continue
        if inspect.iscoroutinefunction(member):
            out[name] = inspect.signature(member)
    return out


class TestMethodSetParity:
    """Sibling-not-subclass means we need a programmatic check that the
    cloud and server adapters expose the same public method surface AND
    the lifecycle dunders (`__aenter__` / `__aexit__` / `close`).
    """

    def test_method_names_match(self) -> None:
        cloud = set(_public_async_methods(AzureDevOpsCloudAdapter))
        server = set(_public_async_methods(AzureDevOpsServerAdapter))
        assert cloud == server, (
            f"Public method set diverged.\n"
            f"  Only in cloud: {sorted(cloud - server)}\n"
            f"  Only in server: {sorted(server - cloud)}"
        )

    def test_signatures_match(self) -> None:
        cloud = _public_async_methods(AzureDevOpsCloudAdapter)
        server = _public_async_methods(AzureDevOpsServerAdapter)
        for name in cloud:
            assert cloud[name] == server[name], (
                f"Signature divergence on {name}:\n"
                f"  cloud:  {cloud[name]}\n"
                f"  server: {server[name]}"
            )

    @pytest.mark.parametrize("dunder", ["__aenter__", "__aexit__", "close"])
    def test_lifecycle_dunder_signatures_match(self, dunder: str) -> None:
        """`__aenter__` / `__aexit__` / `close` are part of the contract too —
        any divergence in these breaks `async with adapter` interop.
        """
        cloud_sig = inspect.signature(getattr(AzureDevOpsCloudAdapter, dunder))
        server_sig = inspect.signature(getattr(AzureDevOpsServerAdapter, dunder))
        assert cloud_sig == server_sig, (
            f"Signature divergence on {dunder}:\n  cloud:  {cloud_sig}\n  server: {server_sig}"
        )


# ---------------------------------------------------------------------------
# Pagination compatibility
# ---------------------------------------------------------------------------


class TestPaginationCompatibility:
    """The ADOClient-aware paginators in pagination.py take a BaseADOClient.
    Confirm each helper works transparently against an ADOServerClient.
    """

    @pytest.mark.asyncio
    async def test_continuation_token_paginator(self, auth: PATAuth) -> None:
        # list_projects exercises paginate_via_adoclient_continuation_token.
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/projects").mock(
                    side_effect=[
                        httpx.Response(
                            200,
                            json={"value": [{"id": "p1", "name": "A"}]},
                            headers={"x-ms-continuationtoken": "page2"},
                        ),
                        httpx.Response(200, json={"value": [{"id": "p2", "name": "B"}]}),
                    ]
                )
                projects = await adapter.list_projects()
                assert [p["name"] for p in projects] == ["A", "B"]
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_skip_top_paginator(self, auth: PATAuth) -> None:
        # count_pull_requests exercises paginate_via_adoclient_skip_top.
        adapter = _make_adapter(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/ProjA/_apis/git/repositories/RepoA/pullrequests").mock(
                    side_effect=[
                        httpx.Response(
                            200,
                            json={"value": [{"id": i} for i in range(100)]},
                        ),
                        httpx.Response(200, json={"value": [{"id": 100}]}),
                    ]
                )
                count = await adapter.count_pull_requests("ProjA/RepoA")
                assert count == 101
        finally:
            await adapter.close()

    @pytest.mark.asyncio
    async def test_body_continuation_token_paginator_accepts_server_client(
        self,
        auth: PATAuth,
    ) -> None:
        """The body-token paginator isn't exercised by any server-adapter
        method (vsaex Member Entitlements is hard-False on Server), so we
        invoke it directly to confirm it accepts an ADOServerClient.
        """
        client = _make_client(auth)
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                mock.get("/_apis/userentitlements").mock(
                    return_value=httpx.Response(200, json={"items": [{"id": "u1"}]})
                )
                items = [
                    item
                    async for item in paginate_via_adoclient_body_continuation_token(
                        client,
                        "/_apis/userentitlements",
                        items_key="items",
                    )
                ]
                assert items == [{"id": "u1"}]
        finally:
            await client.close()


# ---------------------------------------------------------------------------
# Lifecycle
# ---------------------------------------------------------------------------


class TestLifecycle:
    @pytest.mark.asyncio
    async def test_close_closes_underlying_client(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        single = adapter.client.httpx_client("dev")
        await adapter.close()
        assert single.is_closed

    @pytest.mark.asyncio
    async def test_double_close_is_idempotent(self, auth: PATAuth) -> None:
        adapter = _make_adapter(auth)
        await adapter.close()
        await adapter.close()  # must not raise

    @pytest.mark.asyncio
    async def test_aenter_runs_underlying_connect(self, auth: PATAuth) -> None:
        """`async with adapter` calls client.connect(), which is idempotent.

        ``_make_client`` pre-seeds ``client._capability_overrides`` and
        ``_graph_api_version`` so the explicit-api-version path of
        ``connect()`` short-circuits without issuing any HTTP — no respx
        mocks needed for this test.
        """
        async with _make_adapter(auth) as adapter:
            assert adapter.client.api_version == "7.0"
