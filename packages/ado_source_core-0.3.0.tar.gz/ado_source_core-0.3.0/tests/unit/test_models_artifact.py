"""ArtifactFeedInventoryItem model tests."""

import pytest
from pydantic import ValidationError

import ado_source_core
from ado_source_core.models import ArtifactFeedInventoryItem


def test_artifact_feed_minimal() -> None:
    feed = ArtifactFeedInventoryItem(id="f1", name="my-feed")
    assert feed.id == "f1"
    assert feed.feed_type == "unknown"
    assert feed.package_count == 0
    assert feed.upstream_sources == []


def test_artifact_feed_extra_rejected() -> None:
    with pytest.raises(ValidationError):
        ArtifactFeedInventoryItem(id="f1", name="my-feed", unknown="x")  # type: ignore[call-arg]


def test_artifact_feed_re_exported() -> None:
    assert ado_source_core.ArtifactFeedInventoryItem is ArtifactFeedInventoryItem
