"""TfvcSummary model tests."""

from datetime import UTC, datetime

import pytest
from pydantic import ValidationError

import ado_source_core
from ado_source_core.models import TfvcSummary


def test_tfvc_minimal() -> None:
    summary = TfvcSummary(total_changesets=42)
    assert summary.total_changesets == 42
    assert summary.latest_changeset_date is None


def test_tfvc_default_warning_present() -> None:
    summary = TfvcSummary(total_changesets=0)
    assert summary.warnings == ["TFVC requires git-tfs migration"]


def test_tfvc_default_warnings_are_per_instance() -> None:
    """Default factory must produce a fresh list per instance (not a shared one)."""
    a = TfvcSummary(total_changesets=0)
    b = TfvcSummary(total_changesets=1)
    a.warnings.append("only on a")
    assert b.warnings == ["TFVC requires git-tfs migration"]


def test_tfvc_with_timestamp() -> None:
    now = datetime(2026, 4, 28, tzinfo=UTC)
    summary = TfvcSummary(total_changesets=10, latest_changeset_date=now)
    assert summary.latest_changeset_date == now


def test_tfvc_required_field_missing() -> None:
    with pytest.raises(ValidationError):
        TfvcSummary()  # type: ignore[call-arg]


def test_tfvc_re_exported() -> None:
    assert ado_source_core.TfvcSummary is TfvcSummary
