"""Exception hierarchy tests."""

import pytest

import ado_source_core
from ado_source_core import UnsupportedOnAzureDevOpsServerError
from ado_source_core.exceptions import (
    ADOSourceCoreError,
    APIError,
    AuthenticationError,
    ConfigError,
    ExitCode,
    RateLimitError,
)


class TestExitCode:
    def test_values(self) -> None:
        assert ExitCode.SUCCESS == 0
        assert ExitCode.USER_ERROR == 1
        assert ExitCode.SYSTEM_ERROR == 2


class TestADOSourceCoreError:
    def test_base_carries_message_and_default_exit_code(self) -> None:
        err = ADOSourceCoreError("boom")
        assert err.message == "boom"
        assert err.exit_code == ExitCode.USER_ERROR
        assert str(err) == "boom"

    def test_explicit_exit_code(self) -> None:
        err = ADOSourceCoreError("boom", exit_code=ExitCode.SYSTEM_ERROR)
        assert err.exit_code == ExitCode.SYSTEM_ERROR

    def test_is_exception(self) -> None:
        with pytest.raises(ADOSourceCoreError):
            raise ADOSourceCoreError("boom")


class TestConfigError:
    def test_inheritance(self) -> None:
        assert issubclass(ConfigError, ADOSourceCoreError)

    def test_carries_field(self) -> None:
        err = ConfigError("missing pat", field="ADO_PAT")
        assert err.field == "ADO_PAT"
        assert err.exit_code == ExitCode.USER_ERROR

    def test_field_optional(self) -> None:
        err = ConfigError("misconfigured")
        assert err.field is None


class TestAPIError:
    def test_inheritance(self) -> None:
        assert issubclass(APIError, ADOSourceCoreError)

    def test_carries_status_code_and_response_body(self) -> None:
        err = APIError("bad request", status_code=400, response_body={"key": "value"})
        assert err.status_code == 400
        assert err.response_body == {"key": "value"}
        assert "HTTP 400" in str(err)

    def test_default_exit_code_is_system(self) -> None:
        err = APIError("server boom", status_code=500)
        assert err.exit_code == ExitCode.SYSTEM_ERROR

    def test_message_without_status_code_is_unchanged(self) -> None:
        err = APIError("network blip")
        assert str(err) == "network blip"
        assert err.status_code is None

    def test_status_code_zero_still_appends_http_suffix(self) -> None:
        """Regression: falsy-but-set status_code (e.g., 0 on connection failure)
        must still produce the "(HTTP 0)" suffix. Earlier truthy-check would
        silently drop it. See exceptions.py:APIError.__init__ for the
        intentional drift from upstream.
        """
        err = APIError("connection lost", status_code=0)
        assert str(err) == "connection lost (HTTP 0)"
        assert err.status_code == 0


class TestAuthenticationError:
    def test_inheritance(self) -> None:
        assert issubclass(AuthenticationError, APIError)
        assert issubclass(AuthenticationError, ADOSourceCoreError)

    def test_carries_status_code(self) -> None:
        err = AuthenticationError("unauthorized", status_code=401)
        assert err.status_code == 401
        # Auth defaults to USER_ERROR (operator-fixable PAT issue)
        assert err.exit_code == ExitCode.USER_ERROR


class TestRateLimitError:
    def test_inheritance(self) -> None:
        assert issubclass(RateLimitError, APIError)
        assert issubclass(RateLimitError, ADOSourceCoreError)

    def test_carries_retry_after(self) -> None:
        err = RateLimitError("rate limited", status_code=429, retry_after=42.0)
        assert err.retry_after == 42.0
        assert err.status_code == 429

    def test_default_exit_code_is_system(self) -> None:
        err = RateLimitError("rate limited", status_code=429)
        assert err.exit_code == ExitCode.SYSTEM_ERROR


class TestRaisingAndCatching:
    def test_can_catch_subclass_via_base(self) -> None:
        with pytest.raises(ADOSourceCoreError) as exc_info:
            raise AuthenticationError("auth", status_code=401)
        assert isinstance(exc_info.value, AuthenticationError)

    def test_can_catch_rate_limit_via_api_error(self) -> None:
        with pytest.raises(APIError) as exc_info:
            raise RateLimitError("limited", status_code=429, retry_after=10.0)
        assert isinstance(exc_info.value, RateLimitError)


class TestUnsupportedOnAzureDevOpsServerError:
    def test_carries_required_capability_and_api_version(self) -> None:
        exc = UnsupportedOnAzureDevOpsServerError(
            "Graph not available",
            capability="supports_graph_api",
            api_version="7.0",
        )
        assert exc.capability == "supports_graph_api"
        assert exc.api_version == "7.0"
        assert exc.remediation is None

    def test_carries_optional_remediation(self) -> None:
        exc = UnsupportedOnAzureDevOpsServerError(
            "Graph not available",
            capability="supports_graph_api",
            api_version="7.0",
            remediation="Install the Graph extension.",
        )
        assert exc.remediation == "Install the Graph extension."

    def test_subclasses_ado_source_core_error(self) -> None:
        exc = UnsupportedOnAzureDevOpsServerError(
            "x",
            capability="y",
            api_version="7.0",
        )
        assert isinstance(exc, ADOSourceCoreError)

    def test_str_returns_message(self) -> None:
        exc = UnsupportedOnAzureDevOpsServerError(
            "Graph API is not available",
            capability="supports_graph_api",
            api_version="7.0",
        )
        assert str(exc) == "Graph API is not available"

    def test_api_version_is_required_keyword(self) -> None:
        with pytest.raises(TypeError):
            # Missing api_version=
            UnsupportedOnAzureDevOpsServerError(  # type: ignore[call-arg]
                "x",
                capability="y",
            )


class TestReExports:
    def test_re_exported_from_package_root(self) -> None:
        for name in (
            "ADOSourceCoreError",
            "APIError",
            "AuthenticationError",
            "ConfigError",
            "ExitCode",
            "RateLimitError",
        ):
            assert hasattr(ado_source_core, name), name
