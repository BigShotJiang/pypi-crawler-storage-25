"""BoardSummary model tests."""

import pytest
from pydantic import ValidationError

import ado_source_core
from ado_source_core.models import BoardSummary


def test_board_minimal() -> None:
    board = BoardSummary(process_template="Agile")
    assert board.process_template == "Agile"
    assert board.total_work_items == 0
    assert board.work_items_by_type == {}


def test_board_extra_rejected() -> None:
    with pytest.raises(ValidationError):
        BoardSummary(process_template="Agile", unknown="x")  # type: ignore[call-arg]


def test_board_coerces_none_and_blank_keys_to_unknown() -> None:
    """ADO Analytics OData can return null/blank keys for State/WorkItemType."""
    board = BoardSummary(
        process_template="Agile",
        work_items_by_type={None: 3, "": 2, "  ": 1, "Bug": 5},  # type: ignore[dict-item]
    )
    assert board.work_items_by_type == {"Unknown": 6, "Bug": 5}


def test_board_coerces_non_dict_to_empty() -> None:
    board = BoardSummary(
        process_template="Agile",
        work_items_by_state=None,  # type: ignore[arg-type]
    )
    assert board.work_items_by_state == {}


def test_board_re_exported() -> None:
    assert ado_source_core.BoardSummary is BoardSummary
