"""User and UserEntitlementSummary model tests."""

import pytest
from pydantic import ValidationError

import ado_source_core
from ado_source_core.models import User, UserEntitlementSummary
from ado_source_core.models.user import User as DirectUser


def test_user_minimal() -> None:
    user = User(id="u1", username="alice")
    assert user.username == "alice"
    assert user.source == "azure-devops"
    assert user.display_name is None


def test_user_is_frozen() -> None:
    user = User(id="u1", username="alice")
    with pytest.raises(ValidationError):
        user.username = "bob"  # type: ignore[misc]


def test_user_extra_fields_rejected() -> None:
    with pytest.raises(ValidationError):
        User(id="u1", username="alice", unknown="x")  # type: ignore[call-arg]


def test_user_entitlement_summary_defaults() -> None:
    summary = UserEntitlementSummary()
    assert summary.total_users == 0
    assert summary.by_license_type == {}


def test_user_entitlement_summary_negative_total_rejected() -> None:
    with pytest.raises(ValidationError):
        UserEntitlementSummary(total_users=-1)


def test_user_re_exported() -> None:
    assert ado_source_core.User is User
    assert User is DirectUser
    assert ado_source_core.UserEntitlementSummary is UserEntitlementSummary
