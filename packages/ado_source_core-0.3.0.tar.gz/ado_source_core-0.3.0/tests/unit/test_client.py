"""ADOClient tests.

Covers the transport-layer behavior: 6-host construction, host routing,
api-version injection, retry/rate-limit, error mapping, and lifecycle.
"""

from __future__ import annotations

import asyncio
from typing import Any

import httpx
import pytest
import respx

import ado_source_core
from ado_source_core import (
    APIError,
    AuthenticationError,
    PATAuth,
    RateLimitError,
)
from ado_source_core.client import (
    API_VERSION,
    RESPONSE_BODY_MAX_BYTES,
    ADOClient,
    _extract_response_body,
    _parse_retry_after,
)


@pytest.fixture
def auth() -> PATAuth:
    return PATAuth(token="dummy-pat")


def _make_client(auth: PATAuth, **overrides: Any) -> ADOClient:
    """Construct an ADOClient with no-sleep retry defaults for tests."""
    kwargs: dict[str, Any] = {
        "organization": "myorg",
        "auth": auth,
        "max_retries": 3,
    }
    kwargs.update(overrides)
    return ADOClient(**kwargs)


async def _instant_sleep(_seconds: float) -> None:
    """Replacement for asyncio.sleep used in retry tests."""
    return None


@pytest.fixture(autouse=True)
def _no_sleep(monkeypatch: pytest.MonkeyPatch) -> None:
    """Make asyncio.sleep a no-op so retry tests don't actually wait."""
    monkeypatch.setattr(asyncio, "sleep", _instant_sleep)


def _base_url(client: ADOClient, host: str) -> str:
    """Return the underlying httpx base_url normalized (no trailing slash)."""
    return str(client.httpx_client(host).base_url).rstrip("/")


class TestConstruction:
    def test_creates_six_clients_with_correct_base_urls(self, auth: PATAuth) -> None:
        client = _make_client(auth)
        assert _base_url(client, "dev") == "https://dev.azure.com/myorg"
        assert _base_url(client, "vsrm") == "https://vsrm.dev.azure.com/myorg"
        assert _base_url(client, "feeds") == "https://feeds.dev.azure.com/myorg"
        assert _base_url(client, "analytics") == "https://analytics.dev.azure.com/myorg"
        assert _base_url(client, "vssps") == "https://vssps.dev.azure.com/myorg"
        assert _base_url(client, "vsaex") == "https://vsaex.dev.azure.com/myorg"

    def test_authorization_header_attached(self, auth: PATAuth) -> None:
        client = _make_client(auth)
        for host in ("dev", "vsrm", "feeds", "analytics", "vssps", "vsaex"):
            assert client.httpx_client(host).headers["Authorization"].startswith("Basic ")

    def test_organization_property(self, auth: PATAuth) -> None:
        client = _make_client(auth)
        assert client.organization == "myorg"

    def test_alternate_base_url(self, auth: PATAuth) -> None:
        client = _make_client(auth, base_url="https://example.local")
        # Only the dev host honours base_url; the others are hardcoded ADO hostnames.
        assert _base_url(client, "dev") == "https://example.local/myorg"
        assert _base_url(client, "vsrm") == "https://vsrm.dev.azure.com/myorg"

    def test_constructor_rejects_max_retries_zero(self, auth: PATAuth) -> None:
        """``max_retries=0`` would skip the retry loop entirely and trip the
        ``assert response is not None`` in ``BaseADOClient.request()``. Reject
        at construction time with a clear ``ValueError`` so the failure mode
        is fail-fast and grep-friendly."""
        with pytest.raises(ValueError, match="max_retries"):
            _make_client(auth, max_retries=0)

    def test_constructor_rejects_max_retries_negative(self, auth: PATAuth) -> None:
        """Negative ``max_retries`` is also invalid (and ``range(-1)`` is empty
        too); validation must catch it the same way."""
        with pytest.raises(ValueError, match="max_retries"):
            _make_client(auth, max_retries=-1)


class TestRequestRouting:
    @pytest.mark.asyncio
    async def test_default_host_is_dev(self, auth: PATAuth) -> None:
        async with _make_client(auth) as client:
            with respx.mock(base_url="https://dev.azure.com/myorg") as mock:
                route = mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                await client.request("GET", "/_apis/projects")
                assert route.call_count == 1

    @pytest.mark.asyncio
    async def test_named_host_routes_to_correct_client(self, auth: PATAuth) -> None:
        async with _make_client(auth) as client:
            with respx.mock(base_url="https://vsrm.dev.azure.com/myorg") as mock:
                route = mock.get("/_apis/release/definitions").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                await client.request("GET", "/_apis/release/definitions", host="vsrm")
                assert route.call_count == 1


class TestApiVersionInjection:
    @pytest.mark.asyncio
    async def test_api_version_added_by_default(self, auth: PATAuth) -> None:
        async with _make_client(auth) as client:
            with respx.mock(base_url="https://dev.azure.com/myorg") as mock:
                route = mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                await client.request("GET", "/_apis/projects")
                assert f"api-version={API_VERSION}" in str(route.calls[0].request.url)

    @pytest.mark.asyncio
    async def test_skip_api_version_omits_param(self, auth: PATAuth) -> None:
        async with _make_client(auth) as client:
            with respx.mock(base_url="https://analytics.dev.azure.com/myorg") as mock:
                route = mock.get("/myproject/_odata/v4.0-preview/WorkItemSnapshot").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                await client.request(
                    "GET",
                    "/myproject/_odata/v4.0-preview/WorkItemSnapshot",
                    host="analytics",
                    skip_api_version=True,
                )
                assert "api-version" not in str(route.calls[0].request.url)

    @pytest.mark.asyncio
    async def test_caller_api_version_overrides_default(self, auth: PATAuth) -> None:
        async with _make_client(auth) as client:
            with respx.mock(base_url="https://dev.azure.com/myorg") as mock:
                route = mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                await client.request(
                    "GET",
                    "/_apis/projects",
                    params={"api-version": "6.0"},
                )
                assert "api-version=6.0" in str(route.calls[0].request.url)


class TestErrorMapping:
    @pytest.mark.asyncio
    async def test_401_raises_authentication_error(self, auth: PATAuth) -> None:
        async with _make_client(auth) as client:
            with respx.mock(base_url="https://dev.azure.com/myorg") as mock:
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(401, json={"message": "unauth"})
                )
                with pytest.raises(AuthenticationError) as exc_info:
                    await client.request("GET", "/_apis/projects")
                assert exc_info.value.status_code == 401

    @pytest.mark.asyncio
    async def test_403_raises_authentication_error(self, auth: PATAuth) -> None:
        async with _make_client(auth) as client:
            with respx.mock(base_url="https://dev.azure.com/myorg") as mock:
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(403, json={"message": "forbidden"})
                )
                with pytest.raises(AuthenticationError) as exc_info:
                    await client.request("GET", "/_apis/projects")
                assert exc_info.value.status_code == 403

    @pytest.mark.asyncio
    async def test_500_raises_api_error(self, auth: PATAuth) -> None:
        async with _make_client(auth) as client:
            with respx.mock(base_url="https://dev.azure.com/myorg") as mock:
                mock.get("/_apis/projects").mock(return_value=httpx.Response(500, text="boom"))
                with pytest.raises(APIError) as exc_info:
                    await client.request("GET", "/_apis/projects")
                assert exc_info.value.status_code == 500

    @pytest.mark.asyncio
    async def test_api_error_populates_response_body_from_json(self, auth: PATAuth) -> None:
        """JSON error envelope from ADO is parsed into APIError.response_body."""
        async with _make_client(auth) as client:
            with respx.mock(base_url="https://dev.azure.com/myorg") as mock:
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(
                        500, json={"message": "Server boom", "typeKey": "InternalError"}
                    )
                )
                with pytest.raises(APIError) as exc_info:
                    await client.request("GET", "/_apis/projects")
                assert exc_info.value.response_body == {
                    "message": "Server boom",
                    "typeKey": "InternalError",
                }

    @pytest.mark.asyncio
    async def test_api_error_response_body_falls_back_to_text(self, auth: PATAuth) -> None:
        """Non-JSON body is wrapped as {'text': <body>}."""
        async with _make_client(auth) as client:
            with respx.mock(base_url="https://dev.azure.com/myorg") as mock:
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(502, text="<html>gateway timeout</html>")
                )
                with pytest.raises(APIError) as exc_info:
                    await client.request("GET", "/_apis/projects")
                body = exc_info.value.response_body
                assert body is not None
                assert body["text"] == "<html>gateway timeout</html>"

    @pytest.mark.asyncio
    async def test_api_error_response_body_truncates_huge_payload(self, auth: PATAuth) -> None:
        """Multi-MB error pages are truncated to keep logs bounded."""
        async with _make_client(auth) as client:
            big_body = "x" * 50_000
            with respx.mock(base_url="https://dev.azure.com/myorg") as mock:
                mock.get("/_apis/projects").mock(return_value=httpx.Response(500, text=big_body))
                with pytest.raises(APIError) as exc_info:
                    await client.request("GET", "/_apis/projects")
                body = exc_info.value.response_body
                assert body is not None
                assert len(body["text"]) == 4096
                assert body["truncated"] is True
                assert body["original_length"] == 50_000

    @pytest.mark.asyncio
    async def test_authentication_error_carries_response_body(self, auth: PATAuth) -> None:
        async with _make_client(auth) as client:
            with respx.mock(base_url="https://dev.azure.com/myorg") as mock:
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(401, json={"message": "unauth"})
                )
                with pytest.raises(AuthenticationError) as exc_info:
                    await client.request("GET", "/_apis/projects")
                assert exc_info.value.response_body == {"message": "unauth"}

    @pytest.mark.asyncio
    async def test_network_error_after_max_retries_raises_api_error(self, auth: PATAuth) -> None:
        async with _make_client(auth) as client:
            with respx.mock(base_url="https://dev.azure.com/myorg") as mock:
                mock.get("/_apis/projects").mock(side_effect=httpx.ConnectError("net down"))
                with pytest.raises(APIError) as exc_info:
                    await client.request("GET", "/_apis/projects")
                assert exc_info.value.status_code is None
                # 3 attempts, all transport-failed
                assert mock.calls.call_count == 3


class TestRetries:
    @pytest.mark.asyncio
    async def test_503_retried_then_succeeds(self, auth: PATAuth) -> None:
        async with _make_client(auth) as client:
            with respx.mock(base_url="https://dev.azure.com/myorg") as mock:
                mock.get("/_apis/projects").mock(
                    side_effect=[
                        httpx.Response(503, text="busy"),
                        httpx.Response(200, json={"value": []}),
                    ]
                )
                response = await client.request("GET", "/_apis/projects")
                assert response.status_code == 200
                assert mock.calls.call_count == 2

    @pytest.mark.asyncio
    async def test_429_retried_with_retry_after_then_succeeds(self, auth: PATAuth) -> None:
        async with _make_client(auth) as client:
            with respx.mock(base_url="https://dev.azure.com/myorg") as mock:
                mock.get("/_apis/projects").mock(
                    side_effect=[
                        httpx.Response(429, headers={"Retry-After": "0"}, text="slow down"),
                        httpx.Response(200, json={"value": []}),
                    ]
                )
                response = await client.request("GET", "/_apis/projects")
                assert response.status_code == 200
                assert mock.calls.call_count == 2

    @pytest.mark.asyncio
    async def test_429_exhausted_raises_rate_limit_error(self, auth: PATAuth) -> None:
        async with _make_client(auth) as client:
            with respx.mock(base_url="https://dev.azure.com/myorg") as mock:
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(429, headers={"Retry-After": "30"}, text="full")
                )
                with pytest.raises(RateLimitError) as exc_info:
                    await client.request("GET", "/_apis/projects")
                assert exc_info.value.status_code == 429
                assert exc_info.value.retry_after == 30.0
                assert mock.calls.call_count == 3

    @pytest.mark.asyncio
    async def test_429_without_retry_after_uses_exponential_backoff(self, auth: PATAuth) -> None:
        """Missing Retry-After header should still complete and exhaust retries."""
        async with _make_client(auth) as client:
            with respx.mock(base_url="https://dev.azure.com/myorg") as mock:
                mock.get("/_apis/projects").mock(return_value=httpx.Response(429, text="full"))
                with pytest.raises(RateLimitError):
                    await client.request("GET", "/_apis/projects")
                assert mock.calls.call_count == 3

    @pytest.mark.asyncio
    async def test_429_with_garbage_retry_after_does_not_crash(self, auth: PATAuth) -> None:
        """Non-numeric, non-HTTP-date Retry-After must fall back to backoff (no crash)."""
        async with _make_client(auth) as client:
            with respx.mock(base_url="https://dev.azure.com/myorg") as mock:
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(
                        429,
                        headers={"Retry-After": "not-a-number-or-date"},
                        text="ratelimited",
                    )
                )
                with pytest.raises(RateLimitError) as exc_info:
                    await client.request("GET", "/_apis/projects")
                assert exc_info.value.status_code == 429
                # Three attempts even with garbage header — proves no crash on parse.
                assert mock.calls.call_count == 3
                # retry_after falls back to the last attempt's exponential backoff (2 ** 2 = 4).
                assert exc_info.value.retry_after == 4.0

    @pytest.mark.asyncio
    async def test_429_with_http_date_retry_after(self, auth: PATAuth) -> None:
        """HTTP-date Retry-After parses successfully; iteration completes."""
        async with _make_client(auth) as client:
            http_date = "Wed, 21 Oct 2026 07:28:00 GMT"
            with respx.mock(base_url="https://dev.azure.com/myorg") as mock:
                mock.get("/_apis/projects").mock(
                    side_effect=[
                        httpx.Response(429, headers={"Retry-After": http_date}, text="slow"),
                        httpx.Response(200, json={"value": []}),
                    ]
                )
                response = await client.request("GET", "/_apis/projects")
                assert response.status_code == 200


class TestSuccessPath:
    @pytest.mark.asyncio
    async def test_returns_response_on_2xx(self, auth: PATAuth) -> None:
        async with _make_client(auth) as client:
            with respx.mock(base_url="https://dev.azure.com/myorg") as mock:
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(200, json={"value": [{"id": "1"}]})
                )
                response = await client.request("GET", "/_apis/projects")
                assert response.status_code == 200
                assert response.json() == {"value": [{"id": "1"}]}


class TestLifecycle:
    @pytest.mark.asyncio
    async def test_close_closes_all_six_clients(self, auth: PATAuth) -> None:
        client = _make_client(auth)
        await client.close()
        for host in ("dev", "vsrm", "feeds", "analytics", "vssps", "vsaex"):
            assert client.httpx_client(host).is_closed

    @pytest.mark.asyncio
    async def test_async_context_manager_closes_on_exit(self, auth: PATAuth) -> None:
        async with _make_client(auth) as client:
            pass
        for host in ("dev", "vsrm", "feeds", "analytics", "vssps", "vsaex"):
            assert client.httpx_client(host).is_closed


class TestReExports:
    def test_ado_client_exported_from_package_root(self) -> None:
        assert ado_source_core.ADOClient is ADOClient


class TestParseRetryAfterNegativeClamp:
    """Forward-backport from migration-core PR #7: negative numeric values
    must clamp to 0.0 because ``Retry-After`` is defined as a non-negative
    delay (RFC 7231 §7.1.3) and ``time.sleep(-1)`` raises."""

    def test_negative_integer_clamped(self) -> None:
        assert _parse_retry_after("-1", attempt=0) == 0.0

    def test_negative_float_clamped(self) -> None:
        assert _parse_retry_after("-30.5", attempt=2) == 0.0


class TestExtractResponseBodyResponseNotRead:
    """Forward-backport from migration-core PR #7: ``_extract_response_body``
    is called from ``APIError`` construction paths and must never raise.
    Streaming ``httpx.Response`` objects whose body has not been read raise
    ``httpx.ResponseNotRead`` from ``response.json()`` / ``response.text``;
    catch that and fall back to a ``{"text": ""}`` shape."""

    def test_unread_streaming_response_does_not_raise(self) -> None:
        resp = httpx.Response(503, stream=httpx.ByteStream(b"<html>boom</html>"))
        body = _extract_response_body(resp)
        assert body == {"text": ""}


class TestResponseBodyConstantImportable:
    """Forward-backport from migration-core PR #7: ``RESPONSE_BODY_MAX_BYTES``
    is module-level and importable so callers can reason about the cap."""

    def test_constant_value(self) -> None:
        assert RESPONSE_BODY_MAX_BYTES == 4096
