"""ADOServerClient construction + transport tests.

Construction-only at this stage (Task 2). The connect() probe wiring is
exercised in Task 3 once api_version_discovery lands.
"""

from __future__ import annotations

import asyncio
from typing import Any

import httpx
import pytest
import respx

from ado_source_core import ConfigError, PATAuth
from ado_source_core.client import ADOServerClient, BaseADOClient

_BASE = "https://devops.example.com:8080/tfs"
_COLLECTION = "DefaultCollection"
_RESOLVED = f"{_BASE}/{_COLLECTION}"


@pytest.fixture
def auth() -> PATAuth:
    return PATAuth(token="dummy-pat")


def _make_client(auth: PATAuth, **overrides: Any) -> ADOServerClient:
    kwargs: dict[str, Any] = {
        "base_url": _BASE,
        "collection": _COLLECTION,
        "auth": auth,
        "api_version": "7.0",  # bypasses probe at this stage
        "max_retries": 3,
    }
    kwargs.update(overrides)
    return ADOServerClient(**kwargs)


async def _instant_sleep(_seconds: float) -> None:
    return None


@pytest.fixture(autouse=True)
def _no_sleep(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(asyncio, "sleep", _instant_sleep)


class TestConstruction:
    def test_subclasses_base(self, auth: PATAuth) -> None:
        client = _make_client(auth)
        assert isinstance(client, BaseADOClient)

    def test_builds_single_httpx_client(self, auth: PATAuth) -> None:
        client = _make_client(auth)
        single = client.httpx_client("dev")
        assert str(single.base_url).rstrip("/") == _RESOLVED

    def test_all_logical_hosts_alias_to_same_client(self, auth: PATAuth) -> None:
        client = _make_client(auth)
        dev = client.httpx_client("dev")
        for host in ("vsrm", "feeds", "analytics", "vssps", "vsaex"):
            assert client.httpx_client(host) is dev

    def test_authorization_header_attached(self, auth: PATAuth) -> None:
        client = _make_client(auth)
        assert client.httpx_client("dev").headers["Authorization"].startswith("Basic ")

    def test_collection_property(self, auth: PATAuth) -> None:
        client = _make_client(auth)
        assert client.collection == _COLLECTION

    def test_explicit_api_version_bypasses_probe(self, auth: PATAuth) -> None:
        client = _make_client(auth, api_version="6.0")
        assert client.api_version == "6.0"
        assert client.resolved_api_version == "6.0"

    def test_resolved_api_version_is_none_before_connect_when_no_explicit(
        self, auth: PATAuth
    ) -> None:
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            # NO api_version passed
        )
        assert client.resolved_api_version is None

    def test_api_version_property_raises_runtime_error_before_connect(self, auth: PATAuth) -> None:
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
        )
        with pytest.raises(RuntimeError, match="not connected"):
            _ = client.api_version

    def test_constructor_rejects_max_retries_zero(self, auth: PATAuth) -> None:
        """``max_retries=0`` would skip the retry loop entirely and trip the
        ``assert response is not None`` in ``BaseADOClient.request()``. Reject
        at construction time with a clear ``ValueError`` so the failure mode
        is fail-fast and grep-friendly."""
        with pytest.raises(ValueError, match="max_retries"):
            _make_client(auth, max_retries=0)

    def test_constructor_rejects_max_retries_negative(self, auth: PATAuth) -> None:
        """Negative ``max_retries`` is also invalid (and ``range(-1)`` is empty
        too); validation must catch it the same way."""
        with pytest.raises(ValueError, match="max_retries"):
            _make_client(auth, max_retries=-1)


class TestUrlNormalization:
    @pytest.mark.parametrize(
        ("base_url", "collection", "expected"),
        [
            (
                "https://devops/",
                "DefaultCollection",
                "https://devops/DefaultCollection",
            ),
            (
                "https://devops:8080/tfs",
                "DefaultCollection",
                "https://devops:8080/tfs/DefaultCollection",
            ),
            (
                "https://devops/tfs/DefaultCollection",
                "DefaultCollection",
                "https://devops/tfs/DefaultCollection",
            ),
            (
                "https://devops/tfs/DefaultCollection/",
                "DefaultCollection",
                "https://devops/tfs/DefaultCollection",
            ),
        ],
    )
    def test_collection_url_normalization(
        self,
        auth: PATAuth,
        base_url: str,
        collection: str,
        expected: str,
    ) -> None:
        client = ADOServerClient(
            base_url=base_url,
            collection=collection,
            auth=auth,
            api_version="7.0",
        )
        assert str(client.httpx_client("dev").base_url).rstrip("/") == expected

    def test_embedded_basic_auth_in_base_url_raises_config_error(self, auth: PATAuth) -> None:
        with pytest.raises(ConfigError, match="embedded credentials"):
            ADOServerClient(
                base_url="https://user:pass@devops/tfs",
                collection="DefaultCollection",
                auth=auth,
                api_version="7.0",
            )


class TestSelectClient:
    @pytest.mark.parametrize("host", ["dev", "vsrm", "feeds", "analytics", "vssps", "vsaex"])
    def test_select_client_returns_single_client_for_every_host(
        self, auth: PATAuth, host: str
    ) -> None:
        client = _make_client(auth)
        assert client.httpx_client(host) is client.httpx_client("dev")

    @pytest.mark.asyncio
    async def test_close_closes_single_client_once(self, auth: PATAuth) -> None:
        client = _make_client(auth)
        single = client.httpx_client("dev")
        await client.close()
        assert single.is_closed
        # Idempotent — second close() must not raise.
        await client.close()


class TestRequest:
    @pytest.mark.asyncio
    async def test_api_version_query_param_uses_explicit_value(self, auth: PATAuth) -> None:
        with respx.mock(base_url=_RESOLVED) as mock:
            # Explicit api_version= still triggers soft-cap probes on connect();
            # mock all 3 to keep the test focused on the api-version param.
            mock.get("/_apis/graph/users").mock(
                return_value=httpx.Response(200, json={"value": []})
            )
            mock.get("/_odata/v4.0-preview/$metadata").mock(
                return_value=httpx.Response(200, text="<edmx/>")
            )
            mock.get("/_apis/packaging/feeds").mock(
                return_value=httpx.Response(200, json={"value": []})
            )
            route = mock.get("/_apis/projects").mock(
                return_value=httpx.Response(200, json={"value": []})
            )
            async with _make_client(auth, api_version="6.0") as client:
                await client.request("GET", "/_apis/projects")
                assert route.calls[0].request.url.params["api-version"] == "6.0"

    @pytest.mark.asyncio
    async def test_skip_api_version_omits_param(self, auth: PATAuth) -> None:
        with respx.mock(base_url=_RESOLVED) as mock:
            # Explicit api_version= still triggers soft-cap probes on connect();
            # mock all 3 plus the Analytics-fallback-hint /_apis/projects call
            # to keep the test focused on the skip behavior.
            mock.get("/_apis/graph/users").mock(
                return_value=httpx.Response(200, json={"value": []})
            )
            mock.get("/_odata/v4.0-preview/$metadata").mock(
                return_value=httpx.Response(200, text="<edmx/>")
            )
            mock.get("/_apis/packaging/feeds").mock(
                return_value=httpx.Response(200, json={"value": []})
            )
            mock.get("/_apis/projects").mock(return_value=httpx.Response(200, json={"value": []}))
            route = mock.get("/_apis/connectionData").mock(
                return_value=httpx.Response(200, json={})
            )
            async with _make_client(auth) as client:
                await client.request("GET", "/_apis/connectionData", skip_api_version=True)
                assert "api-version" not in route.calls[0].request.url.params


def _server_happy_probe_mocks(mock: respx.MockRouter) -> None:
    """Set up the full probe-success mock surface: connectionData + projects
    fallback + 3 soft-cap probes all returning 200."""
    mock.get("/_apis/connectionData").mock(
        return_value=httpx.Response(200, json={"apiVersion": "7.0"})
    )
    mock.get("/_apis/projects").mock(
        return_value=httpx.Response(200, json={"value": [{"name": "ProjA"}]})
    )
    mock.get("/_apis/graph/users").mock(return_value=httpx.Response(200, json={"value": []}))
    mock.get("/_odata/v4.0-preview/$metadata").mock(
        return_value=httpx.Response(200, text="<edmx/>")
    )
    mock.get("/_apis/packaging/feeds").mock(return_value=httpx.Response(200, json={"value": []}))


class TestConnect:
    @pytest.mark.asyncio
    async def test_connect_runs_probe_and_caches_result(self, auth: PATAuth) -> None:
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                _server_happy_probe_mocks(mock)
                await client.connect()
                assert client.resolved_api_version == "7.0"
                assert client.graph_api_version == "7.0-preview.1"
                assert client.capability_overrides == {
                    "supports_graph_api": True,
                    "supports_analytics_odata": True,
                    "supports_artifact_feeds": True,
                }
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_connect_is_idempotent(self, auth: PATAuth) -> None:
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                cd = mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "7.0"})
                )
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(
                        200,
                        json={"value": [{"name": "ProjA"}]},
                    )
                )
                mock.get("/_apis/graph/users").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                mock.get("/_odata/v4.0-preview/$metadata").mock(
                    return_value=httpx.Response(200, text=""),
                )
                mock.get("/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                await client.connect()
                await client.connect()
                assert cd.call_count == 1
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_aenter_runs_connect_automatically(self, auth: PATAuth) -> None:
        with respx.mock(base_url=_RESOLVED) as mock:
            _server_happy_probe_mocks(mock)
            async with ADOServerClient(
                base_url=_BASE,
                collection=_COLLECTION,
                auth=auth,
                max_retries=2,
            ) as client:
                assert client.resolved_api_version == "7.0"

    @pytest.mark.asyncio
    async def test_aenter_closes_client_on_connect_failure(self, auth: PATAuth) -> None:
        from ado_source_core import AuthenticationError  # noqa: PLC0415

        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        single = client.httpx_client("dev")
        with respx.mock(base_url=_RESOLVED) as mock:
            mock.get("/_apis/connectionData").mock(return_value=httpx.Response(404))
            mock.get("/_apis/projects").mock(return_value=httpx.Response(401))
            with pytest.raises(AuthenticationError):
                await client.__aenter__()
        assert single.is_closed

    @pytest.mark.asyncio
    async def test_explicit_api_version_skips_version_probe_but_runs_caps(
        self,
        auth: PATAuth,
    ) -> None:
        """Explicit api_version= bypasses the connectionData/candidate-iteration
        version probe but soft-cap probes still run on connect()."""
        with respx.mock(base_url=_RESOLVED) as mock:
            # Soft-cap mocks ARE required (the probe still runs).
            graph = mock.get("/_apis/graph/users").mock(
                return_value=httpx.Response(200, json={"value": []})
            )
            analytics = mock.get("/_odata/v4.0-preview/$metadata").mock(
                return_value=httpx.Response(200, text="<edmx/>")
            )
            feeds = mock.get("/_apis/packaging/feeds").mock(
                return_value=httpx.Response(200, json={"value": []})
            )
            # The Analytics-fallback-hint /_apis/projects probe also runs on
            # the explicit-api_version path so the soft-cap probe can fall
            # back to project-scoped /_odata/$metadata on a 404.
            mock.get("/_apis/projects").mock(
                return_value=httpx.Response(200, json={"value": [{"name": "ProjA"}]})
            )
            # connectionData mock NOT set — if the version probe runs, respx
            # raises on an unhandled call and the test fails. That's the
            # contract: explicit api_version= skips the version probe.
            async with ADOServerClient(
                base_url=_BASE,
                collection=_COLLECTION,
                auth=auth,
                api_version="6.0",
                max_retries=2,
            ) as client:
                assert client.api_version == "6.0"
                assert client.capability_overrides == {
                    "supports_graph_api": True,
                    "supports_analytics_odata": True,
                    "supports_artifact_feeds": True,
                }
            # All 3 soft-cap probes ran exactly once.
            assert graph.call_count == 1
            assert analytics.call_count == 1
            assert feeds.call_count == 1

    @pytest.mark.asyncio
    async def test_concurrent_connect_runs_probe_only_once(self, auth: PATAuth) -> None:
        """Concurrent ``connect()`` callers must serialize on the per-instance
        lock so the connectionData probe (and the rest of the version-resolve
        flow) fires exactly once. Without the lock, multiple coroutines that
        observe ``_resolved_api_version is None`` together would each launch
        a duplicate probe and race on the writes to instance state.
        """
        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            max_retries=2,
        )
        try:
            with respx.mock(base_url=_RESOLVED) as mock:
                cd = mock.get("/_apis/connectionData").mock(
                    return_value=httpx.Response(200, json={"apiVersion": "7.0"})
                )
                mock.get("/_apis/projects").mock(
                    return_value=httpx.Response(
                        200,
                        json={"value": [{"name": "ProjA"}]},
                    )
                )
                mock.get("/_apis/graph/users").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                mock.get("/_odata/v4.0-preview/$metadata").mock(
                    return_value=httpx.Response(200, text="<edmx/>"),
                )
                mock.get("/_apis/packaging/feeds").mock(
                    return_value=httpx.Response(200, json={"value": []})
                )
                # Five coroutines all hit connect() concurrently.
                await asyncio.gather(*(client.connect() for _ in range(5)))
                # Only one of them ran the probe; the other four observed
                # the populated state inside the lock and returned early.
                assert cd.call_count == 1
                assert client.resolved_api_version == "7.0"
        finally:
            await client.close()

    @pytest.mark.asyncio
    async def test_explicit_api_version_passes_project_hint_to_soft_caps(
        self,
        auth: PATAuth,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Explicit api_version= path must pre-fetch the first project name
        and pass it as ``project_hint`` to ``probe_soft_capabilities``.

        Without this, ``_probe_analytics`` returns False on a collection-level
        404 (Server 2019 commonly only exposes Analytics project-scoped) and
        ``query_work_item_counts`` would eager-raise even on installs where
        the project-scoped probe would have succeeded.
        """
        from ado_source_core import api_version_discovery as avd  # noqa: PLC0415

        captured: dict[str, Any] = {}

        async def _capturing_probe(
            client: Any,
            *,
            api_version: str,
            project_hint: str | None,
        ) -> tuple[dict[str, bool], list[str], str | None]:
            captured["api_version"] = api_version
            captured["project_hint"] = project_hint
            return (
                {
                    "supports_graph_api": True,
                    "supports_analytics_odata": True,
                    "supports_artifact_feeds": True,
                },
                [],
                f"{api_version}-preview.1",
            )

        monkeypatch.setattr(avd, "probe_soft_capabilities", _capturing_probe)

        with respx.mock(base_url=_RESOLVED) as mock:
            # Only /_apis/projects needs to be reachable on this path —
            # probe_soft_capabilities is monkey-patched, so its inner
            # network calls do not fire.
            mock.get("/_apis/projects").mock(
                return_value=httpx.Response(
                    200,
                    json={"value": [{"name": "ProjA"}]},
                )
            )
            async with ADOServerClient(
                base_url=_BASE,
                collection=_COLLECTION,
                auth=auth,
                api_version="6.0",
                max_retries=2,
            ) as client:
                assert client.api_version == "6.0"
        assert captured["project_hint"] == "ProjA"
        assert captured["api_version"] == "6.0"


class TestConcurrentSoftCapProbes:
    """Verify that the 3 soft-cap probes (Graph / Analytics / Feeds) run
    concurrently via asyncio.gather, not sequentially. Avoids depending on
    respx's async-side-effect handling (which varies by version) by
    monkeypatching the inner probe functions directly."""

    @pytest.mark.asyncio
    async def test_three_soft_cap_probes_run_concurrently(
        self,
        auth: PATAuth,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        from ado_source_core import api_version_discovery as avd  # noqa: PLC0415

        client = ADOServerClient(
            base_url=_BASE,
            collection=_COLLECTION,
            auth=auth,
            api_version="7.0",
            max_retries=2,
        )
        in_flight = 0
        max_in_flight = 0
        gate = asyncio.Event()

        async def _gated_call() -> bool:
            nonlocal in_flight, max_in_flight
            in_flight += 1
            max_in_flight = max(max_in_flight, in_flight)
            if in_flight >= 3:
                gate.set()
            await gate.wait()
            in_flight -= 1
            return True

        async def _fake_probe_graph(_client: Any, *, api_version: str) -> tuple[bool, str | None]:
            ok = await _gated_call()
            return ok, api_version if ok else None

        async def _fake_probe_analytics(
            _client: Any,
            *,
            api_version: str,
            project_hint: str | None,
        ) -> bool:
            return await _gated_call()

        async def _fake_probe_feeds(_client: Any, *, api_version: str) -> bool:
            return await _gated_call()

        monkeypatch.setattr(avd, "_probe_graph", _fake_probe_graph)
        monkeypatch.setattr(avd, "_probe_analytics", _fake_probe_analytics)
        monkeypatch.setattr(avd, "_probe_feeds", _fake_probe_feeds)

        try:
            overrides, notes, graph_api_version = await avd.probe_soft_capabilities(
                client,
                api_version="7.0",
                project_hint=None,
            )
            assert max_in_flight == 3, f"expected 3 concurrent probes, observed max {max_in_flight}"
            assert overrides == {
                "supports_graph_api": True,
                "supports_analytics_odata": True,
                "supports_artifact_feeds": True,
            }
            assert graph_api_version == "7.0"
            assert notes == []
        finally:
            await client.close()
