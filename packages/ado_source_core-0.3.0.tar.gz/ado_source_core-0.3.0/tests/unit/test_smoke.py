"""Smoke test — ensures package imports."""

import ado_source_core


def test_import() -> None:
    assert ado_source_core.__version__
