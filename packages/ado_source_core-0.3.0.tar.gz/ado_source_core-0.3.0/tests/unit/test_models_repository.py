"""Repository model tests.

Stage 1.1.4 of the Shyftport pilot extraction. Validates the lifted
Repository Pydantic model preserves the donor's contract verbatim.
Donor: n8group-oss/ado2gh-core/src/ado2gh/models/repository.py.
"""

from datetime import UTC, datetime

import pytest
from pydantic import ValidationError

import ado_source_core
from ado_source_core.models import Repository as ReExportedRepository
from ado_source_core.models.repository import Repository


def _minimal_kwargs() -> dict[str, str]:
    return {
        "id": "abc-123",
        "name": "my-repo",
        "full_name": "MyProject/my-repo",
        "project_name": "MyProject",
        "default_branch": "refs/heads/main",
    }


class TestRepositoryRequiredFields:
    def test_minimal_repository(self) -> None:
        repo = Repository(**_minimal_kwargs())
        assert repo.id == "abc-123"
        assert repo.name == "my-repo"
        assert repo.full_name == "MyProject/my-repo"
        assert repo.project_name == "MyProject"
        assert repo.default_branch == "refs/heads/main"

    def test_missing_required_field_raises(self) -> None:
        kwargs = _minimal_kwargs()
        del kwargs["name"]
        with pytest.raises(ValidationError):
            Repository(**kwargs)


class TestRepositoryDefaults:
    def test_status_defaults(self) -> None:
        repo = Repository(**_minimal_kwargs())
        assert repo.is_disabled is False
        assert repo.is_in_maintenance is False
        assert repo.is_fork is False

    def test_optional_fields_default_to_none(self) -> None:
        repo = Repository(**_minimal_kwargs())
        assert repo.description is None
        assert repo.size_bytes is None
        assert repo.clone_url_https is None
        assert repo.clone_url_ssh is None
        assert repo.created_at is None
        assert repo.updated_at is None

    def test_source_defaults_to_azure_devops(self) -> None:
        repo = Repository(**_minimal_kwargs())
        assert repo.source == "azure-devops"


class TestRepositoryFrozenAndStrict:
    def test_repository_is_frozen(self) -> None:
        repo = Repository(**_minimal_kwargs())
        with pytest.raises(ValidationError):
            repo.name = "renamed"  # type: ignore[misc]

    def test_extra_fields_rejected(self) -> None:
        kwargs = {**_minimal_kwargs(), "unknown_field": "x"}
        with pytest.raises(ValidationError):
            Repository(**kwargs)


class TestRepositorySizeValidation:
    def test_negative_size_rejected(self) -> None:
        kwargs = {**_minimal_kwargs(), "size_bytes": -1}
        with pytest.raises(ValidationError):
            Repository(**kwargs)

    def test_zero_size_accepted(self) -> None:
        repo = Repository(**_minimal_kwargs(), size_bytes=0)
        assert repo.size_bytes == 0


class TestRepositoryTimestamps:
    def test_timestamps_round_trip(self) -> None:
        now = datetime(2026, 4, 28, 12, 0, 0, tzinfo=UTC)
        repo = Repository(**_minimal_kwargs(), created_at=now, updated_at=now)
        assert repo.created_at == now
        assert repo.updated_at == now


class TestRepositoryReExport:
    def test_repository_exported_from_models_package(self) -> None:
        assert ReExportedRepository is Repository

    def test_repository_exported_from_package_root(self) -> None:
        assert ado_source_core.Repository is Repository
