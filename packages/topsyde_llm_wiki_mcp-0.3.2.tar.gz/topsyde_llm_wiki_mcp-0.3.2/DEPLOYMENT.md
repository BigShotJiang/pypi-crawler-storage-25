# Deployment

This package publishes to PyPI as `topsyde-llm-wiki-mcp`.

## Important Constraint

`topsyde-llm-wiki-mcp` is not a fully standalone server package today.

The published package provides the MCP entrypoint, but at runtime it still loads the query engine from a local `llm-wiki` checkout via:

- `LLM_WIKI_ROOT/agents/query/query_engine.py`
- `LLM_WIKI_ROOT/projects/`

That means publishing to PyPI is valid, but anyone running the package still needs a local `llm-wiki` repo checkout and must set `LLM_WIKI_ROOT` to it.

## Package Metadata

Release metadata lives in `pyproject.toml`:

- package name: `topsyde-llm-wiki-mcp`
- current version: `0.1.0`
- console script: `topsyde-llm-wiki-mcp = "llm_wiki_mcp:main"`

Before releasing, update `version` in `pyproject.toml` to the intended release version.

## Prerequisites

- `uv` installed locally
- PyPI access for the `topsyde-llm-wiki-mcp` project
- a PyPI token with upload permission
- a local `llm-wiki` checkout for runtime verification

Optional runtime env vars:

- `LLM_WIKI_ROOT` - required at runtime
- `LLM_WIKI_PROJECT` - optional default project key
- `MODEL` - optional backend selector passed through to the query engine

## First Release Check

Before the first real upload, confirm that the package name is actually
publishable from your PyPI account.

Important PyPI detail:

- `topsyde-llm-wiki-mcp` and `topsyde_llm_wiki_mcp` normalize to the same project name
- a `403 ... isn't allowed to upload to project ...` response means one of:
  - the project name is already owned by another account
  - the token belongs to an account that is not an owner/collaborator on that project

If that happens on the first release, the fix is not in `uv` or packaging. You
must either:

1. publish under a different package name by changing `project.name` in
   `pyproject.toml`, or
2. upload with credentials that are allowed to publish that exact PyPI project

Do not keep retrying the same `uv publish` command until this is resolved.

## Release Steps

1. Sync the local environment.

```bash
UV_CACHE_DIR=.uv-cache uv sync --locked
```

2. Run the focused regression suite for the package boundary.

From the repo root:

```bash
.venv/bin/pytest tests/test_query_engine.py tests/test_measure_llm.py tests/test_mcp_server.py tests/test_query_cli.py tests/test_llm_client_real.py -q
```

3. Build the package distributions.

From `mcp/`:

```bash
UV_CACHE_DIR=.uv-cache uv build
```

Artifacts should be written to `mcp/dist/`.

4. Inspect the build output.

```bash
ls -lah dist/
```

5. Publish to PyPI.

```bash
export UV_PUBLISH_TOKEN="pypi-..."
UV_CACHE_DIR=.uv-cache uv publish
```

Equivalent one-shot form:

```bash
UV_CACHE_DIR=.uv-cache uv publish --token "$UV_PUBLISH_TOKEN"
```

If PyPI returns a `403` saying your user is not allowed to upload to
`topsyde-llm-wiki-mcp`, stop there and resolve the package-name ownership issue before
retrying.

## Post-Release Verification

After publishing, verify both installation and runtime assumptions.

1. Confirm the new release appears on PyPI.

2. Verify the package installs and the CLI resolves:

```bash
uvx topsyde-llm-wiki-mcp
```

3. Verify runtime against a real repo checkout:

```bash
export LLM_WIKI_ROOT=/abs/path/to/llm-wiki
export LLM_WIKI_PROJECT=rpg_game
uvx topsyde-llm-wiki-mcp
```

4. If you want to pin the exact published version during verification:

```bash
export LLM_WIKI_ROOT=/abs/path/to/llm-wiki
uvx --from topsyde-llm-wiki-mcp==0.1.0 topsyde-llm-wiki-mcp
```

## Version Bumps

This repo does not currently include a checked-in CI release workflow for this package. Treat versioning and publishing as a manual process.

Recommended order:

1. Update `version` in `mcp/pyproject.toml`
2. Run the focused tests
3. Build with `uv build`
4. Publish with `uv publish`
5. Verify with `uvx` and a real `LLM_WIKI_ROOT`

## Trusted Publishing

`uv publish` supports trusted publishing, but this repo does not currently include checked-in GitHub Actions or equivalent release automation for `topsyde-llm-wiki-mcp`.

If a CI-based publish flow is added later, update this file and make that workflow the canonical release path.

## Troubleshooting

### `uv build` fails while resolving `hatchling` or other build dependencies

`uv build` may need network access to fetch build requirements. Retry with working network access, or ensure the environment can reach the configured Python package index.

### `uv publish` fails with authentication errors

Check the PyPI token and package permissions. `uv publish --help` supports:

- `--token`
- `--username` / `--password`
- `--trusted-publishing`
- `--publish-url`
- `--check-url`

### `uv publish` fails with `403 ... isn't allowed to upload to project 'topsyde-llm-wiki-mcp'`

This is a project-ownership problem, not a bad wheel or bad `uv` invocation.

Most likely causes:

- `topsyde-llm-wiki-mcp` is already claimed on PyPI by another owner
- the token/user is valid, but does not have upload permission for that project

Fix by either:

- renaming the package in `pyproject.toml` to an available name, then rebuilding
  and republishing
- or using credentials for an account that owns that PyPI project

### `uvx topsyde-llm-wiki-mcp` installs but the server fails at runtime

That usually means the runtime repo dependency is missing or misconfigured. Confirm:

- `LLM_WIKI_ROOT` points to a real `llm-wiki` checkout
- `agents/query/query_engine.py` exists under that checkout
- `projects/` exists under that checkout

### The published package runs, but queries fail

Remember that the MCP package delegates to the repo-local query engine. Runtime failures may come from:

- missing `LLM_WIKI_ROOT`
- bad `LLM_WIKI_PROJECT`
- missing/stale `projects/<key>/state/latest/` products
- local model/backend configuration issues in the underlying `llm-wiki` repo
