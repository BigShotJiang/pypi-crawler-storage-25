# CLAUDE.md

## Project Overview

`topsyde-llm-wiki-mcp` is a single-module FastMCP server that exposes `llm-wiki` query tools to MCP-aware agents.

## Commands

```bash
uv sync
uv run llm_wiki_mcp.py
uvx topsyde-llm-wiki-mcp
uv build
```

## Architecture

- Single-module server: `llm_wiki_mcp.py`
- Query calls route into `agents.query.query_engine`
- `LLM_WIKI_ROOT` is required so the server can import the engine and locate registered projects
- `enrich_gap(..., auto_update=...)` can detach `make update PROJECT=<key> AUTO=1` through the repo-local wrapper when enabled

## Gotchas

- Query operations always use the engine's weak-model mapping; do not add a separate query-model env var.
- `get_wiki_page` is for raw page content after `query_wiki` returns citations.
- `query_wiki(..., raw=True)` skips the synthesizer and returns router-selected pages as `pages_content: [{page_path, content}]`. Confidence comes from the router in that path; gap-emission on `confidence < LOW_CONFIDENCE_THRESHOLD` (0.66) still fires and `synthesizer_model` serializes as `null` in the inbox item.
- When `query_wiki` returns low confidence and an `emitted_gap_id`, do not stop at the weak answer. After targeted source verification, call `enrich_gap` with the missing verified context, or ask the operator first if the extra verification would be costly or ambiguous.
- `LLM_WIKI_AUTO_UPDATE=1` enables detached auto-update by default for `enrich_gap`; per-call `auto_update=True|False` overrides the env var.
- `flag_stale_answer` is the symmetric complement to `query_wiki` gap emission: `query_wiki` catches "wiki admitted IDK" (`confidence < 0.66`), while `flag_stale_answer` catches "wiki confidently lied" (`confidence >= 0.66` but verified wrong). Both produce inbox gap-notes for `make update`, but they intentionally use different `source` values: `mcp-auto` versus `agent-flagged`.
- Auto-update is lockfile-gated per project at `projects/<key>/state/.update.lock`; logs are written to `projects/<key>/logs/auto-update-<timestamp>.log`.
