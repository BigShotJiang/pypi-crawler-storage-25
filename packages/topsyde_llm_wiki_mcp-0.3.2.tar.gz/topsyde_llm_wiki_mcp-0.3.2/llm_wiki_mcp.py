#!/usr/bin/env python3

from __future__ import annotations

import importlib.util
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, Protocol, cast


def _autoload_dotenv() -> None:
    path = Path.cwd() / ".env"
    if not path.is_file():
        return
    for line in path.read_text().splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


_autoload_dotenv()
LLM_WIKI_ROOT = os.environ["LLM_WIKI_ROOT"]

LOW_CONFIDENCE_THRESHOLD = 0.66

if TYPE_CHECKING:
    from fastmcp import FastMCP as RuntimeFastMCP
else:
    try:
        from fastmcp import FastMCP as RuntimeFastMCP
    except ImportError:
        class RuntimeFastMCP:  # pragma: no cover
            def __init__(self, name: str):
                self.name = name
                self._tools: dict[str, Any] = {}
                self._resources: dict[str, Any] = {}
                self._resource_templates: dict[str, Any] = {}

            def tool(self):
                def decorator(func):
                    self._tools[func.__name__] = func
                    return func

                return decorator

            def resource(self, uri: str):
                def decorator(func):
                    registry = self._resource_templates if "{" in uri else self._resources
                    registry[uri] = func
                    return func

                return decorator

            def run(self):
                return None


sys.path.insert(0, LLM_WIKI_ROOT)

from agents._shared import inbox_writer


mcp = RuntimeFastMCP("llm-wiki")

TOOL_NAMES = [
    "query_wiki",
    "enrich_gap",
    "flag_stale_answer",
    "list_wiki_projects",
    "get_wiki_page",
]
RESOURCE_URIS = [
    "llm-wiki://capabilities",
]
RESOURCE_TEMPLATE_URIS = [
    "llm-wiki://project/{project_key}/index",
    "llm-wiki://project/{project_key}/latest/{product}{?format}",
    "llm-wiki://project/{project_key}/page/{page_path*}",
]
LATEST_PRODUCT_FILES = {
    "ranking": {"md": "ranking-snapshot.md", "json": "ranking-snapshot.json"},
    "validation": {"md": "validation-report.md", "json": "validation-findings.json"},
    "measurement": {"md": "measurement-report.md", "json": "measurement-report.json"},
    "ingest": {"md": "ingest-report.md", "json": "ingest-findings.json"},
}


class QueryFunction(Protocol):
    def __call__(
        self,
        project_key: str,
        question: str,
        *,
        projects_root: Path | None = None,
        raw: bool = False,
    ) -> dict[str, Any]: ...


def _root() -> Path:
    return Path(LLM_WIKI_ROOT)


def _utc_now() -> datetime:
    return datetime.now(timezone.utc).replace(microsecond=0)


def _format_utc_timestamp(now: datetime | None = None) -> str:
    current = now or _utc_now()
    return current.strftime("%Y-%m-%dT%H:%M:%SZ")


def _format_log_timestamp(now: datetime | None = None) -> str:
    current = now or _utc_now()
    return current.strftime("%Y-%m-%dT%H-%M-%SZ")


def _load_query_function() -> QueryFunction:
    engine_path = _root() / "agents" / "query" / "query_engine.py"
    if not engine_path.is_file():
        raise FileNotFoundError(f"query engine not found: {engine_path}")
    spec = importlib.util.spec_from_file_location("llm_wiki_query_engine", engine_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"could not load query engine from {engine_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    query_fn = getattr(module, "query", None)
    if not callable(query_fn):
        raise RuntimeError(f"query engine at {engine_path} does not expose callable query()")
    return cast(QueryFunction, query_fn)


def _projects_root() -> Path:
    return _root() / "projects"


def _resolve_project_key(project_key: str | None) -> str:
    if project_key:
        return project_key
    default_project = os.environ.get("LLM_WIKI_PROJECT")
    if default_project:
        return default_project
    raise ValueError("project_key is required when LLM_WIKI_PROJECT is not set")


def _project_dir(project_key: str) -> Path:
    path = _projects_root() / project_key
    if not path.is_dir():
        raise FileNotFoundError(f"project not found: {path}")
    return path


def _resolve_project_file(project_dir: Path, relative_path: str) -> Path:
    resolved_project_dir = project_dir.resolve()
    candidate = (resolved_project_dir / relative_path).resolve()
    try:
        candidate.relative_to(resolved_project_dir)
    except ValueError as exc:
        raise ValueError("path must stay within the project directory") from exc
    if not candidate.is_file():
        raise FileNotFoundError(f"file not found: {relative_path}")
    return candidate


def _latest_product_path(project_dir: Path, product: str, format: str) -> Path:
    product_mapping = LATEST_PRODUCT_FILES.get(product)
    if product_mapping is None:
        raise ValueError(f"unknown latest product: {product}")
    if format not in ("md", "json"):
        raise ValueError(f"unsupported latest product format: {format}")
    return _resolve_project_file(project_dir, f"state/latest/{product_mapping[format]}")


def _auto_update_requested(auto_update: bool | None) -> tuple[bool, str]:
    if auto_update is True:
        return True, "triggered"
    if auto_update is False:
        return False, "skipped:override"
    if os.environ.get("LLM_WIKI_AUTO_UPDATE") == "1":
        return True, "triggered"
    return False, "disabled"


def _auto_update_lock_path(project_dir: Path) -> Path:
    return project_dir / "state" / ".update.lock"


def _acquire_update_lock(lock_path: Path) -> bool:
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
    try:
        fd = os.open(lock_path, flags)
    except FileExistsError:
        return False
    try:
        with os.fdopen(fd, "w") as handle:
            handle.write(f"{_format_utc_timestamp()}\n")
    except Exception:
        lock_path.unlink(missing_ok=True)
        raise
    return True


def _auto_update_log_path(project_dir: Path) -> Path:
    return project_dir / "logs" / f"auto-update-{_format_log_timestamp()}.log"


def _to_repo_relative(path: Path) -> str:
    return path.relative_to(_root()).as_posix()


def _trigger_auto_update(project_dir: Path, project_key: str) -> tuple[bool, str, str | None]:
    lock_path = _auto_update_lock_path(project_dir)
    if not _acquire_update_lock(lock_path):
        return False, "skipped:already-running", None

    wrapper_path = _root() / "scripts" / "_auto_update_wrapper.sh"
    if not wrapper_path.is_file():
        lock_path.unlink(missing_ok=True)
        raise FileNotFoundError(f"auto-update wrapper not found: {wrapper_path}")

    log_path = _auto_update_log_path(project_dir)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_handle = log_path.open("w")
    try:
        subprocess.Popen(
            ["bash", str(wrapper_path), project_key, str(lock_path)],
            cwd=str(_root()),
            stdout=log_handle,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
            env={**os.environ, "AUTO": "1"},
        )
    except Exception:
        log_handle.close()
        lock_path.unlink(missing_ok=True)
        raise
    log_handle.close()
    return True, "triggered", _to_repo_relative(log_path)


def _with_auto_update_meta(
    item: dict[str, Any],
    *,
    triggered: bool,
    status: str,
    log_path: str | None,
) -> dict[str, Any]:
    response = dict(item)
    response["auto_update_triggered"] = triggered
    response["auto_update_status"] = status
    response["auto_update_log_path"] = log_path
    return response


def _last_update_at(project_dir: Path) -> str | None:
    candidates = [
        project_dir / "state" / "latest" / "measurement-report.json",
        project_dir / "state" / "freshness.json",
        project_dir / "state" / "update-state.json",
    ]
    for path in candidates:
        if not path.is_file():
            continue
        try:
            data = json.loads(path.read_text())
        except json.JSONDecodeError:
            continue
        for key in ("measured_at", "updated_at", "last_completed_at"):
            value = data.get(key)
            if value:
                return str(value)
    return None


@mcp.resource("llm-wiki://capabilities")
def capabilities_resource() -> dict[str, Any]:
    return {
        "server": "llm-wiki",
        "purpose": (
            "Local-first repository second-brain server exposing stable project reads "
            "plus tool-based wiki querying and correction workflows."
        ),
        "tools": TOOL_NAMES,
        "resources": RESOURCE_URIS,
        "resource_templates": RESOURCE_TEMPLATE_URIS,
        "recommended_flow": [
            "list_wiki_projects",
            "query_wiki",
            "get_wiki_page",
        ],
    }


@mcp.resource("llm-wiki://project/{project_key}/index")
def project_index_resource(project_key: str) -> str:
    project_dir = _project_dir(project_key)
    return _resolve_project_file(project_dir, "index.md").read_text()


@mcp.resource("llm-wiki://project/{project_key}/latest/{product}{?format}")
def latest_product_resource(project_key: str, product: str, format: str = "md") -> dict[str, Any] | str:
    project_dir = _project_dir(project_key)
    product_path = _latest_product_path(project_dir, product, format)
    if format == "json":
        return json.loads(product_path.read_text())
    return product_path.read_text()


@mcp.resource("llm-wiki://project/{project_key}/page/{page_path*}")
def wiki_page_resource(project_key: str, page_path: str) -> str:
    project_dir = _project_dir(project_key)
    return _resolve_project_file(project_dir, page_path).read_text()


@mcp.tool()
def query_wiki(
    project_key: str | None = None,
    question: str = "",
    raw: bool = False,
) -> dict:
    """Ask a question about a registered llm-wiki project and get a cited
    answer from its maintained second-brain wiki.

    Call this FIRST - before Read, Grep, or Explore - whenever the user asks
    about architecture, systems, modules, design, or how-it-works of a
    project with a registered wiki. The wiki is a curated, pre-compiled
    summary layer with inline `file_path:line_number` citations; skipping it
    forces you to re-derive knowledge from raw source at roughly 15-20x the
    context cost (measured: ~700 tokens for a synthesized answer vs. 12k-17k
    tokens to read the underlying implementation files).

    Use for questions like:
      - "How does X work in project Y?"
      - "What are the main components of Y?"
      - "Trace feature Z end-to-end in Y"
      - "What's the design of the Y system?"

    Two response modes:

    - `raw=False` (default): the router picks relevant pages and a
      weak-model synthesizer folds them into a prose `answer` with
      `citations`. Cheapest path for one-shot questions. The synthesizer
      uses a small model (gpt-5.4-mini / claude-haiku-4-5), so its
      reasoning is weaker than yours - trust citations over prose when they
      disagree.
    - `raw=True`: the router still runs, but the synthesizer is skipped.
      Returns `pages_content: [{page_path, content}]` with the raw markdown
      of each selected page, and `answer` is an empty string. Use this
      when: (a) you expect multiple follow-up questions on the same topic
      (raw pages cache in your context and avoid repeat round-trips);
      (b) you want to own the synthesis quality yourself (you are a
      stronger model than the synthesizer); (c) the user explicitly asked
      for the full page(s). Token cost: slightly higher agent context
      (~1.5-2x the synthesized answer) but zero synthesizer LLM cost on the
      server, and no second round-trip on follow-ups.

    Returns (both modes): answer, citations (wiki page paths),
    confidence (0-1 from router in raw mode, from synthesizer in default
    mode; low confidence means the wiki was not good enough on its own),
    pages_read, pages_considered, router_model, synthesizer_model
    (null in raw mode), tokens_consumed.

    Low-confidence follow-up rule: when confidence is below 0.66,
    `query_wiki` automatically emits a gap-note into
    `projects/<key>/inbox/` and sets `emitted_gap_id`. Do not stop at
    the weak answer. After targeted source reading, either:
      - call `enrich_gap(project_key, emitted_gap_id, notes, ...)`
        immediately with the verified context the wiki missed, or
      - ask the operator before doing that extra verification if the
        added source work would be costly or ambiguous.
    In other words: low confidence should normally end in `enrich_gap`,
    not a chat-only correction that never reaches the inbox/update path.

    Raw-mode additionally returns `pages_content` with the full markdown
    of each router-selected page.

    If you don't know the project_key, call list_wiki_projects first and
    match against the agent's cwd via `repo_paths`.
    """
    resolved = _resolve_project_key(project_key)
    project_dir = _project_dir(resolved)
    query_fn = _load_query_function()
    response = dict(query_fn(resolved, question, projects_root=_projects_root(), raw=raw))

    emitted_gap_id = None
    if float(response.get("confidence", 0.0)) < LOW_CONFIDENCE_THRESHOLD:
        citations = response.get("citations") or []
        pages_read = response.get("pages_read") or []
        target_hint = ""
        if citations:
            target_hint = str(citations[0])
        elif pages_read:
            target_hint = str(pages_read[0])
        item = inbox_writer.write_gap(
            project_dir,
            source="mcp-auto",
            question=question,
            target_hint=target_hint,
            confidence=float(response.get("confidence", 0.0)),
            pages_read=response.get("pages_read"),
            pages_considered=response.get("pages_considered"),
            router_model=response.get("router_model"),
            synthesizer_model=response.get("synthesizer_model"),
        )
        emitted_gap_id = item["id"]

    response["emitted_gap_id"] = emitted_gap_id
    return response


@mcp.tool()
def enrich_gap(project_key: str, gap_id: str, notes: str, auto_update: bool | None = None) -> dict:
    """Append operator/agent verification notes to an existing inbox
    gap-note. Call this AFTER query_wiki returned low confidence (the
    emitted_gap_id is in that response) AND you've done the targeted
    source reading that produced context the wiki lacked. The notes are
    folded into the inbox item so the ingest pipeline has your
    verification work as input for the next `make update`.

    What to put in `notes`: concrete findings with full repo-relative
    paths and line numbers (e.g., `server/Handlers/Entities/MobReducers.cs:42`,
    not `MobReducers.cs:42` - the apply stage validates citations resolve
    to real files and rejects basename shorthand). Capture the specific
    answer the wiki was missing, not generic "look here" pointers.

    Second and subsequent enrichments append to existing notes with a
    `\\n\\n---\\n\\n` separator, so multiple callers can layer context
    on the same gap-note. The source flips from `mcp-auto` to
    `agent-enriched` on first enrichment.

    Optional auto-update can spawn `make update AUTO=1` for this project
    in a detached subprocess after the gap-note is enriched. The MCP
    call returns immediately without waiting. Precedence:

      - `auto_update=True`  -> always spawn (unless lockfile blocks)
      - `auto_update=False` -> never spawn (overrides env)
      - `auto_update=None`  -> honor `LLM_WIKI_AUTO_UPDATE` env
                               (the literal string "1" enables it;
                                anything else disables)

    Auto-update is lockfile-gated at
    `projects/<key>/state/.update.lock`, so only one detached update runs
    per project at a time. Response fields:

      - `auto_update_triggered`: bool
      - `auto_update_status`: "triggered" | "disabled" | "skipped:override"
                              | "skipped:already-running"
      - `auto_update_log_path`: repo-relative path under
        `projects/<key>/logs/` when triggered, else null

    The wrapper removes the lockfile on exit, but `SIGKILL` can strand it;
    the operator must then remove `state/.update.lock` manually. Logs are
    kept locally (not committed).
    """
    project_dir = _project_dir(project_key)
    path = inbox_writer.inbox_path(project_dir, gap_id)
    if not path.is_file():
        raise FileNotFoundError(f"gap-note not found: {gap_id}")

    item = json.loads(path.read_text())
    existing_notes = item.get("enriched_notes")
    if existing_notes:
        item["enriched_notes"] = f"{existing_notes}\n\n---\n\n{notes}"
    else:
        item["enriched_notes"] = notes
    if item.get("source") == "mcp-auto":
        item["source"] = "agent-enriched"
    inbox_writer.atomic_write_item(project_dir, item)

    should_update, disabled_status = _auto_update_requested(auto_update)
    if not should_update:
        return _with_auto_update_meta(
            item,
            triggered=False,
            status=disabled_status,
            log_path=None,
        )

    triggered, status, log_path = _trigger_auto_update(project_dir, project_key)
    return _with_auto_update_meta(
        item,
        triggered=triggered,
        status=status,
        log_path=log_path,
    )


@mcp.tool()
def flag_stale_answer(
    project_key: str,
    question: str,
    correction_notes: str,
    citations: list[str] | None = None,
    original_confidence: float | None = None,
    router_model: str | None = None,
    synthesizer_model: str | None = None,
    auto_update: bool | None = None,
) -> dict:
    """Flag a confidently-wrong `query_wiki` answer and optionally trigger
    a corrective wiki update. Use this when `query_wiki` returned
    `confidence >= 0.66` BUT you verified the answer against source and
    found it wrong or stale.

    What to put in `correction_notes`: the specific factual correction,
    with repo-relative `file_path:line_number` citations proving the wiki
    was wrong. Do NOT use basename shorthand - the apply stage rejects it.

    `citations` should be the citations from the bad response so ingest
    can inspect and rewrite the right pages. The first citation becomes
    `target_hint`.

    `original_confidence`, `router_model`, and `synthesizer_model` are
    optional telemetry capturing which model got it wrong and how
    confidently.

    `auto_update` honors the same semantics as `enrich_gap`:
      - `True`  -> always spawn (unless lockfile blocks)
      - `False` -> never spawn (overrides env)
      - `None`  -> honor `LLM_WIKI_AUTO_UPDATE` env

    Returns the written inbox item plus `auto_update_triggered`,
    `auto_update_status`, and `auto_update_log_path`.
    """
    project_dir = _project_dir(project_key)

    citations_list = list(citations or [])
    target_hint = citations_list[0] if citations_list else ""

    item = inbox_writer.write_gap(
        project_dir,
        source="agent-flagged",
        question=question,
        target_hint=target_hint,
        confidence=original_confidence,
        pages_read=citations_list or None,
        router_model=router_model,
        synthesizer_model=synthesizer_model,
        enriched_notes=correction_notes,
    )

    should_update, disabled_status = _auto_update_requested(auto_update)
    if not should_update:
        return _with_auto_update_meta(
            item,
            triggered=False,
            status=disabled_status,
            log_path=None,
        )

    triggered, status, log_path = _trigger_auto_update(project_dir, project_key)
    return _with_auto_update_meta(
        item,
        triggered=triggered,
        status=status,
        log_path=log_path,
    )


@mcp.tool()
def list_wiki_projects() -> list[dict]:
    """List all projects with a maintained second-brain wiki. Call this when
    you need to know which projects are registered, or before query_wiki
    if you're unsure of the project_key.

    Auto-selection: compare your current working directory against each
    project's `repo_paths`. When cwd is inside a repo_path, that project
    is the right `project_key` for query_wiki. If none match, ask the
    user which project to target rather than guessing.

    Returns per project: key, name (display), repo_paths (list of repo
    roots), tags, last_update_at (ISO timestamp; older dates mean the
    wiki may have drifted from HEAD).

    This tool is free - no LLM calls, just filesystem reads.
    """
    projects: list[dict] = []
    for state_file in sorted(_projects_root().glob("*/state/project.json")):
        data = json.loads(state_file.read_text())
        project_dir = state_file.parents[1]
        projects.append(
            {
                "key": data.get("key", project_dir.name),
                "name": data.get("name", project_dir.name),
                "repo_paths": data.get("repo_paths", []),
                "tags": data.get("tags", []),
                "last_update_at": _last_update_at(project_dir),
            }
        )
    return projects


@mcp.tool()
def get_wiki_page(project_key: str | None = None, page_path: str = "") -> dict:
    """Fetch the raw markdown of a single wiki page by path. Cheap - no
    LLM calls, just a filesystem read.

    When to use:
      - AFTER query_wiki returned citations and you want a specific page
        in full (synthesized answer missed a nuance, confidence was low,
        or the user asked for the whole page).
      - When you already know the exact page path from a prior call or
        from the user.

    When NOT to use:
      - For exploration or browsing. Call query_wiki first - it picks
        pages by question, which is far cheaper than reading blind.
      - To scrape the whole wiki. That's what the project's index.md
        plus pages.json is for; ask the operator, don't spider.

    Consider `query_wiki(..., raw=True)` instead when you don't yet know
    which page to read but expect to need the full content - it combines
    routing and fetching in one call.

    `page_path` is resolved relative to the project directory and cannot
    escape it (`../` traversal is blocked).
    """
    resolved = _resolve_project_key(project_key)
    project_dir = _project_dir(resolved)
    candidate = _resolve_project_file(project_dir, page_path)
    return {
        "project_key": resolved,
        "page_path": page_path,
        "content": candidate.read_text(),
    }


def main() -> int:
    try:
        mcp.run()
    except KeyboardInterrupt:
        try:
            sys.stdout.flush()
            sys.stderr.flush()
        finally:
            os._exit(130)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
