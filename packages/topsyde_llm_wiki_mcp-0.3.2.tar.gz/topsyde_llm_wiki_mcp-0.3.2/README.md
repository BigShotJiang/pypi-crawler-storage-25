# topsyde-llm-wiki-mcp

MCP server exposing `llm-wiki` second-brain queries to AI agents.

## Surface

### Tools

- `query_wiki`
- `enrich_gap`
- `flag_stale_answer`
- `list_wiki_projects`
- `get_wiki_page`

### Resources

- `llm-wiki://capabilities`
- `llm-wiki://project/{project_key}/index`
- `llm-wiki://project/{project_key}/latest/{product}{?format}`
- `llm-wiki://project/{project_key}/page/{page_path*}`

The resource layer is intentionally read-only and file-backed. LLM-backed query
and correction flows remain tools.

## Environment

- `LLM_WIKI_ROOT` - absolute path to the `llm-wiki` repository
- `LLM_WIKI_PROJECT` - optional default project key
- `MODEL` - optional backend selector passed through to the query engine

## Commands

```bash
uv sync
uv run llm_wiki_mcp.py
uvx topsyde-llm-wiki-mcp
```

## Deployment

See `DEPLOYMENT.md` for the PyPI release flow and the runtime `LLM_WIKI_ROOT` requirement.
