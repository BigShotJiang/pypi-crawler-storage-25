#!/usr/bin/env bash

set -euo pipefail

cd "$(dirname "$0")"

if [[ -f .env ]]; then
  set -a
  . .env
  set +a
fi

: "${PYPI_TOKEN:?PYPI_TOKEN not set - export it or put it in mcp/.env}"

rm -rf dist
uv build
uv publish --username __token__ --password "$PYPI_TOKEN"
