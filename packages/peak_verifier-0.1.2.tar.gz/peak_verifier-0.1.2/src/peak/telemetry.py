"""Keystroke telemetry models for PEAK interviews."""

from __future__ import annotations

from pydantic import BaseModel, Field


class KeystrokeTelemetry(BaseModel):
    """Raw keystroke telemetry captured during answer input."""

    keystroke_intervals: list[float] = Field(default_factory=list)
    paste_events: int = 0
    paste_char_count: int = 0
    backspace_count: int = 0
    total_keystrokes: int = 0
    time_to_first_keystroke: float = 0.0
    total_time: float = 0.0
    question_id: str = ""


class BotScore(BaseModel):
    """Aggregated bot-likelihood score from telemetry analysis."""

    score: float = Field(ge=0.0, le=1.0, description="0=human, 1=bot")
    signals: dict[str, float] = Field(default_factory=dict)
    reasoning: str = ""
