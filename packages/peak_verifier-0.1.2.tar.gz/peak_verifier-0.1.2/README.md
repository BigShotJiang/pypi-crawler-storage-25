# peak-verifier

Run with [uv](https://docs.astral.sh/uv/):

```bash
uvx --from peak-verifier peak --repo OWNER/REPO --pr N
```
