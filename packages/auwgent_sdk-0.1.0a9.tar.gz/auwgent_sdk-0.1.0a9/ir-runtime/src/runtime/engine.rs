use crate::errors::{AuwgentError, AuwgentResult};
use crate::evaluator::Evaluator;
use crate::intent_parser::block_orchestrator::BlockOrchestrator as Orchestrator;
use crate::runtime::drivers::{ModelDriver, ModelEvent, TokenUsage, FinishReason, ModelMetadata};
use crate::runtime::session::SessionState;
use crate::types::*;
use futures_util::StreamExt;
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::collections::HashMap;
use std::sync::{Arc, Mutex};

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct AggregateUsage {
    pub prompt_tokens: u32,
    pub completion_tokens: u32,
    pub total_tokens: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TurnMetadata {
    pub turn_index: usize,
    pub usage: TokenUsage,
    pub finish_reason: Option<FinishReason>,
    pub model: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct RunMetadata {
    pub aggregate: AggregateUsage,
    pub turns: Vec<TurnMetadata>,
}

pub type ToolImplementation = Arc<
    dyn Fn(Value) -> futures_util::future::BoxFuture<'static, Result<Value, String>> + Send + Sync,
>;

// ═══════════════════════════════════════════════════════════════════════════
// INTENT EVENT TYPES
// ═══════════════════════════════════════════════════════════════════════════

/// Control returned by an intent handler to override default behavior.
#[derive(Debug, Clone)]
pub enum IntentControl {
    /// Skip this intent — don't execute the tool/workflow
    Skip,
    /// Use this result instead of executing the tool
    Override { result: Value },
}

/// Intent callback signature.
///
/// Receives the intent name and value. Returns:
///   - `None` → engine proceeds normally (auto-execute)
///   - `Some(IntentControl::Skip)` → skip this intent
///   - `Some(IntentControl::Override { result })` → use this result
/// Intent callback for standard synchronous handlers.
/// Receives (intent_name, intent_value, agent_name).
pub type IntentCallback = Arc<dyn Fn(String, Value, String) -> Option<IntentControl> + Send + Sync>;

/// Async intent callback for handlers that need to await.
/// Receives (intent_name, intent_value, agent_name).
pub type AsyncIntentCallback = Arc<
    dyn Fn(String, Value, String) -> futures_util::future::BoxFuture<'static, Option<IntentControl>>
        + Send
        + Sync,
>;

/// Async callback for preloading a helper's session history before it runs.
/// Receives `(helper_name, empty_session_json)`. Returns an optional `SessionState` JSON string.
pub type AsyncSessionPreloadCallback = Arc<
    dyn Fn(String, String) -> futures_util::future::BoxFuture<'static, Option<String>>
        + Send
        + Sync,
>;

/// Async callback for saving a helper's session history after it completes.
/// Receives `(helper_name, completed_session_json)`.
pub type SessionSaveCallback =
    Arc<dyn Fn(String, String) -> futures_util::future::BoxFuture<'static, ()> + Send + Sync>;

/// Async callback that fires right before the LLM generates a response.
/// Receives (input_text, system_prompt, context_json).
/// Returns a JSON object containing optional "prompt" (String) and "stack" (Array of Strings).
pub type AsyncLlmStartCallback = Arc<
    dyn Fn(String, String, String) -> futures_util::future::BoxFuture<'static, Value> + Send + Sync,
>;

/// Async callback that fires right after the LLM completes its generation stream.
/// Receives the full raw LLM response and the system prompt.
pub type AsyncLlmEndCallback =
    Arc<dyn Fn(String, String) -> futures_util::future::BoxFuture<'static, ()> + Send + Sync>;

/// Async callback fired before an engine run begins.
/// Receives `(session_json, context_json)` and may return a replacement session JSON.
pub type AsyncRunStartCallback = Arc<
    dyn Fn(String, String) -> futures_util::future::BoxFuture<'static, Option<String>>
        + Send
        + Sync,
>;

/// Async callback fired after an engine run completes successfully.
/// Receives `(session_json, context_json)`.
pub type AsyncRunCompleteCallback =
    Arc<dyn Fn(String, String) -> futures_util::future::BoxFuture<'static, ()> + Send + Sync>;

/// Async callback fired when an engine run errors.
/// Receives `(error_json, session_json, context_json)` and returns `true` to swallow.
pub type AsyncErrorCallback = Arc<
    dyn Fn(String, Option<String>, String) -> futures_util::future::BoxFuture<'static, bool>
        + Send
        + Sync,
>;

/// Generic middleware event callback.
/// Receives an event JSON payload and may return an optional response JSON payload.
pub type AsyncMiddlewareEventCallback =
    Arc<dyn Fn(String) -> futures_util::future::BoxFuture<'static, Option<String>> + Send + Sync>;

// ═══════════════════════════════════════════════════════════════════════════
// AUWGENT ENGINE
// ═══════════════════════════════════════════════════════════════════════════

pub struct AuwgentEngine {
    ir: AgentIR,
    session: Arc<Mutex<SessionState>>,
    tools: Arc<Mutex<HashMap<String, ToolImplementation>>>,
    orchestrator: Arc<Mutex<Orchestrator>>,
    drivers: Arc<Mutex<HashMap<String, Arc<dyn ModelDriver>>>>,
    context: Arc<Mutex<Option<Value>>>,
    /// Pending intents collected by the orchestrator callback
    pending_intents: Arc<Mutex<Vec<(String, Value)>>>,
    /// Track intents that were emitted as partials to avoid duplicate complete emissions
    emitted_partial_intents: Arc<Mutex<std::collections::HashSet<(String, String)>>>,
    /// Tool/workflow results accumulated during the current turn
    /// Format: (name, args, result) where args is the input and result is the output
    pending_tool_results: Arc<Mutex<Vec<(String, Value, Value)>>>,
    /// Accumulated raw response for the current turn
    current_raw_response: Arc<Mutex<String>>,
    /// Last terminal response payload produced during the current LLM cycle
    last_turn_response_value: Arc<Mutex<Value>>,
    /// User-facing intent callback
    intent_handler: Arc<Mutex<Option<AsyncIntentCallback>>>,
    partial_intent_handler: Arc<Mutex<Option<Arc<dyn Fn(String, Value, String) + Send + Sync>>>>,
    session_preload_handler: Arc<Mutex<Option<AsyncSessionPreloadCallback>>>,
    session_save_handler: Arc<Mutex<Option<SessionSaveCallback>>>,
    llm_start_handler: Arc<Mutex<Option<AsyncLlmStartCallback>>>,
    llm_end_handler: Arc<Mutex<Option<AsyncLlmEndCallback>>>,
    run_start_handler: Arc<Mutex<Option<AsyncRunStartCallback>>>,
    run_complete_handler: Arc<Mutex<Option<AsyncRunCompleteCallback>>>,
    error_handler: Arc<Mutex<Option<AsyncErrorCallback>>>,
    middleware_event_handler: Arc<Mutex<Option<AsyncMiddlewareEventCallback>>>,
    fast_forward_stack: Arc<Mutex<Option<Vec<String>>>>,
    /// Tracking if a terminal response (text/schema) was emitted during the current run
    terminal_response_emitted: Arc<Mutex<bool>>,
    /// Tracking if a FINAL terminal response (text/schema) was emitted.
    /// Custom intents count as terminal but NOT final (focus stays on the agent).
    final_response_emitted: Arc<Mutex<bool>>,
    /// Original user input for the current run cycle (used for teleportation follow-ups)
    user_input: Arc<Mutex<Option<serde_json::Value>>>,
    /// Accumulated run metadata across turns
    pub last_run_metadata: Arc<Mutex<RunMetadata>>,
}

impl AuwgentEngine {
    pub fn new(ir: AgentIR) -> Self {
        let mut orchestrator = Orchestrator::new();

        // Register standard Auwgent intentsn
        orchestrator.register_intent("tool_call");
        orchestrator.register_intent("workflow_call");
        orchestrator.register_intent("response_schema");
        orchestrator.register_intent("response_text");
        orchestrator.register_intent("helper_call");

        // Register custom intents from IR
        if let Some(custom) = &ir.custom_intents {
            for ci in custom {
                orchestrator.register_intent(&ci.name);
                orchestrator.register_custom_intent_shape(
                    &ci.name,
                    &ci.fields.0,
                    ir.types.as_ref(),
                );
            }
        }

        for tool in &ir.tools {
            orchestrator.register_tool_shape(&tool.name, &tool.params.0, ir.types.as_ref());
        }

        for workflow in &ir.workflows {
            orchestrator.register_workflow_shape(
                &workflow.name,
                &workflow.params.0,
                ir.types.as_ref(),
            );
        }

        for helper in &ir.helpers {
            orchestrator.register_helper_shape(
                &helper.name,
                helper.input.as_ref().map(|v| &v.0),
                ir.types.as_ref(),
            );
        }

        if let Some(output) = &ir.output {
            orchestrator.register_output_shape(&output.0, ir.types.as_ref());
        }

        let pending_intents = Arc::new(Mutex::new(Vec::new()));
        let intents_for_handler = Arc::clone(&pending_intents);
        let emitted_partial_intents = Arc::new(Mutex::new(std::collections::HashSet::new()));

        orchestrator.on_intent_ready(Arc::new(move |name, value| {
            if let Ok(mut pending) = intents_for_handler.lock() {
                // Check if this exact intent (by name and value) is already pending
                // This prevents duplicates when the same intent is emitted during
                // streaming and then again during finalization
                let already_pending = pending.iter().any(|(n, v)| n == &name && v == &value);

                if !already_pending {
                    pending.push((name, value));
                }
            }
        }));

        Self {
            ir,
            session: Arc::new(Mutex::new(SessionState::new())),
            tools: Arc::new(Mutex::new(HashMap::new())),
            orchestrator: Arc::new(Mutex::new(orchestrator)),
            drivers: Arc::new(Mutex::new(HashMap::new())),
            context: Arc::new(Mutex::new(None)),
            pending_intents,
            emitted_partial_intents,
            pending_tool_results: Arc::new(Mutex::new(Vec::new())),
            current_raw_response: Arc::new(Mutex::new(String::new())),
            last_turn_response_value: Arc::new(Mutex::new(Value::Null)),
            intent_handler: Arc::new(Mutex::new(None)),
            partial_intent_handler: Arc::new(Mutex::new(None)),
            session_preload_handler: Arc::new(Mutex::new(None)),
            session_save_handler: Arc::new(Mutex::new(None)),
            llm_start_handler: Arc::new(Mutex::new(None)),
            llm_end_handler: Arc::new(Mutex::new(None)),
            run_start_handler: Arc::new(Mutex::new(None)),
            run_complete_handler: Arc::new(Mutex::new(None)),
            error_handler: Arc::new(Mutex::new(None)),
            middleware_event_handler: Arc::new(Mutex::new(None)),
            fast_forward_stack: Arc::new(Mutex::new(None)),
            terminal_response_emitted: Arc::new(Mutex::new(false)),
            final_response_emitted: Arc::new(Mutex::new(false)),
            user_input: Arc::new(Mutex::new(None)),
            last_run_metadata: Arc::new(Mutex::new(RunMetadata::default())),
        }
    }

    pub fn on_sub_engine_start(&self, handler: AsyncSessionPreloadCallback) {
        *self.session_preload_handler.lock().unwrap() = Some(handler);
    }

    pub fn on_sub_engine_complete(&self, handler: SessionSaveCallback) {
        *self.session_save_handler.lock().unwrap() = Some(handler);
    }

    pub fn on_llm_start(&self, handler: AsyncLlmStartCallback) {
        *self.llm_start_handler.lock().unwrap() = Some(handler);
    }

    pub fn on_llm_end(&self, handler: AsyncLlmEndCallback) {
        *self.llm_end_handler.lock().unwrap() = Some(handler);
    }

    pub fn on_run_start(&self, handler: AsyncRunStartCallback) {
        *self.run_start_handler.lock().unwrap() = Some(handler);
    }

    pub fn on_run_complete(&self, handler: AsyncRunCompleteCallback) {
        *self.run_complete_handler.lock().unwrap() = Some(handler);
    }

    pub fn on_error(&self, handler: AsyncErrorCallback) {
        *self.error_handler.lock().unwrap() = Some(handler);
    }

    pub fn on_middleware_event(&self, handler: AsyncMiddlewareEventCallback) {
        *self.middleware_event_handler.lock().unwrap() = Some(handler);
    }

    pub fn register_driver(&self, provider_type: &str, driver: Arc<dyn ModelDriver>) {
        self.drivers
            .lock()
            .unwrap()
            .insert(provider_type.to_string(), driver);
    }

    pub fn set_context(&self, context: Value) {
        *self.context.lock().unwrap() = Some(context);
    }

    pub fn register_tool(&self, name: &str, implementation: ToolImplementation) {
        self.tools
            .lock()
            .unwrap()
            .insert(name.to_string(), implementation);
    }

    pub fn on_intent(&self, handler: AsyncIntentCallback) {
        *self.intent_handler.lock().unwrap() = Some(handler);
    }

    /// Register a sync intent callback (convenience wrapper).
    pub fn on_intent_sync(&self, handler: IntentCallback) {
        let handler = handler.clone();
        *self.intent_handler.lock().unwrap() = Some(Arc::new(move |name, value, agent| {
            let result = handler(name, value, agent);
            Box::pin(async move { result })
        }));
    }

    /// Register a partial intent callback.
    ///
    /// This fires as <reponse_text> or [block] data streams in, BEFORE the intent block is
    /// complete. Useful for:
    /// - Streaming partial `response_text` to the UI as tokens arrive
    /// - Showing tool call args as they're being typed by the LLM
    /// - Progress indicators for long structured outputs
    ///
    /// Register a partial intent callback.
    pub fn on_intent_partial(&self, handler: Arc<dyn Fn(String, Value, String) + Send + Sync>) {
        // Wire into the orchestrator's partial handler
        let user_handler = handler.clone();
        let emitted_partials = Arc::clone(&self.emitted_partial_intents);
        let agent_name = self.ir.name.clone();
        let partial_cursor: Arc<Mutex<HashMap<String, String>>> = Arc::new(Mutex::new(HashMap::new()));

        self.orchestrator
            .lock()
            .unwrap()
            .on_intent_partial(Arc::new(move |name, value| {
                // Track this partial emission to prevent duplicate complete emission
                let value_hash = serde_json::to_string(&value).unwrap_or_default();
                let partial_key = (name.clone(), value_hash);

                if let Ok(mut partials) = emitted_partials.lock() {
                    partials.insert(partial_key);
                }

                let value = if name == "response_text" {
                    if let Some(text) = value
                        .get("snapshot")
                        .and_then(|snapshot| snapshot.get("text"))
                        .and_then(Value::as_str)
                    {
                        let segment = value
                            .get("segment")
                            .and_then(Value::as_u64)
                            .unwrap_or(0);
                        let key = format!("{agent_name}:{name}:{segment}");
                        let previous = partial_cursor
                            .lock()
                            .ok()
                            .and_then(|cursor| cursor.get(&key).cloned())
                            .unwrap_or_default();
                        let delta = if text.starts_with(&previous) {
                            &text[previous.len()..]
                        } else {
                            text
                        };
                        if let Ok(mut cursor) = partial_cursor.lock() {
                            cursor.insert(key, text.to_string());
                        }
                        let mut updated = value.clone();
                        if let Value::Object(ref mut map) = updated {
                            map.insert("delta".to_string(), Value::String(delta.to_string()));
                        }
                        updated
                    } else {
                        value
                    }
                } else {
                    value
                };

                // Call user handler with current agent name
                user_handler(name, value, agent_name.clone());
            }));
        *self.partial_intent_handler.lock().unwrap() = Some(handler);
    }

    pub fn clear_intent_handlers(&self) {
        *self.intent_handler.lock().unwrap() = None;
        *self.partial_intent_handler.lock().unwrap() = None;
        self.orchestrator.lock().unwrap().on_intent_partial(Arc::new(|_, _| {}));
    }

    pub fn clear_sub_engine_handlers(&self) {
        *self.session_preload_handler.lock().unwrap() = None;
        *self.session_save_handler.lock().unwrap() = None;
    }

    pub fn clear_llm_handlers(&self) {
        *self.llm_start_handler.lock().unwrap() = None;
        *self.llm_end_handler.lock().unwrap() = None;
    }

    pub fn clear_run_handlers(&self) {
        *self.run_start_handler.lock().unwrap() = None;
        *self.run_complete_handler.lock().unwrap() = None;
        *self.error_handler.lock().unwrap() = None;
    }

    pub fn clear_middleware_handler(&self) {
        *self.middleware_event_handler.lock().unwrap() = None;
    }

    // ── Session export/import for host runtime hooks ──────────────────────

    /// Export the session state as JSON for the host to persist.
    pub fn export_session(&self) -> AuwgentResult<String> {
        self.session
            .lock()
            .unwrap()
            .export()
            .map_err(AuwgentError::Serialization)
    }

    /// Import a session state from JSON, restoring conversation history.
    pub fn import_session(&self, json: &str) -> AuwgentResult<()> {
        *self.session.lock().unwrap() =
            SessionState::import(json).map_err(AuwgentError::Serialization)?;
        Ok(())
    }

    /// Access the session state directly (for testing/CLI).
    pub fn session(&self) -> std::sync::MutexGuard<'_, SessionState> {
        self.session.lock().unwrap()
    }

    /// Clear the session (start a fresh conversation).
    pub fn clear_session(&self) {
        self.session.lock().unwrap().clear();
    }

    /// Get a reference to the session state. (Removed: Cannot return ref to Mutex guard easily)
    // pub fn session(&self) -> &SessionState { ... }

    // ── Embedding ─────────────────────────────────────────────────────────
    pub async fn embed(&self, text: &str) -> AuwgentResult<Vec<f32>> {
        let (driver, model_name, config) = self.get_embedding_config()?;
        driver
            .embed(&model_name, text, config)
            .await
            .map_err(AuwgentError::Driver)
    }

    pub async fn embed_batch(&self, texts: &[String]) -> AuwgentResult<Vec<Vec<f32>>> {
        let (driver, model_name, config) = self.get_embedding_config()?;
        driver
            .embed_batch(&model_name, texts, config)
            .await
            .map_err(AuwgentError::Driver)
    }

    fn get_embedding_config(&self) -> AuwgentResult<(Arc<dyn ModelDriver>, String, Option<Value>)> {
        let model_entry = self
            .ir
            .model_config
            .first()
            .ok_or(AuwgentError::MissingConfig("No model config".into()))?;
        let default_config = model_entry
            .default_config
            .as_ref()
            .ok_or(AuwgentError::MissingConfig("No default config".into()))?;

        let embedding_provider =
            default_config
                .embedding
                .as_ref()
                .ok_or(AuwgentError::MissingConfig(
                    "No embedding model configured".into(),
                ))?;

        let evaluator = Evaluator::new(&self.ir);
        let mut scope = HashMap::new();
        // Use a block to minimize lock duration
        if let Some(ctx) = self.context.lock().unwrap().as_ref() {
            scope.insert("context".to_string(), ctx.clone());
        }

        let provider_info = evaluator.evaluate_provider(embedding_provider, &mut scope)?;

        let provider_type = provider_info["provider"].as_str().unwrap_or("gemini");
        let provider_id = if provider_type == "custom" {
            provider_info["id"].as_str().unwrap_or("custom")
        } else {
            provider_type
        };

        let model_name = provider_info["modelName"].as_str().ok_or_else(|| {
            AuwgentError::MissingConfig("modelName is required for embedding".into())
        })?;

        let config_params = provider_info.get("config").cloned();

        let driver = self
            .drivers
            .lock()
            .unwrap()
            .get(provider_id)
            .ok_or_else(|| AuwgentError::NoDriver)?
            .clone();

        Ok((driver, model_name.to_string(), config_params))
    }

    fn build_event_context(
        &self,
        active_agent: &str,
        raw_block: Option<String>,
        system_prompt: Option<String>,
    ) -> Value {
        let session = self.session.lock().unwrap();
        serde_json::json!({
            "activeAgent": active_agent,
            "stack": session.stack,
            "rootAgent": session.stack.first().cloned().unwrap_or_else(|| self.ir.name.clone()),
            "systemPrompt": system_prompt.or_else(|| session.system_prompt.clone()),
            "rawBlock": raw_block,
        })
    }

    async fn fire_middleware_event(&self, event: Value) -> Option<Value> {
        let handler = self.middleware_event_handler.lock().unwrap().clone();
        let payload = serde_json::to_string(&event).ok()?;
        let response = handler?.clone()(payload).await?;
        serde_json::from_str(&response).ok()
    }

    async fn apply_intent_middleware(
        &self,
        name: &str,
        value: &Value,
        active_agent: &str,
    ) -> Option<IntentControl> {
        let raw_block = value
            .get("_raw")
            .and_then(Value::as_str)
            .map(|value| value.to_string());
        let event = serde_json::json!({
            "type": "intent",
            "name": name,
            "value": value,
            "context": self.build_event_context(active_agent, raw_block, None),
        });
        let response = self.fire_middleware_event(event).await?;
        Self::parse_intent_control_response(&response)
    }

    async fn apply_llm_start_middleware(
        &self,
        prompt: &str,
        system_prompt: &str,
        active_agent: &str,
    ) -> Option<Value> {
        self.fire_middleware_event(serde_json::json!({
            "type": "llm_start",
            "prompt": prompt,
            "context": self.build_event_context(active_agent, None, Some(system_prompt.to_string())),
        }))
        .await
    }

    async fn notify_llm_end_middleware(
        &self,
        response: &Value,
        system_prompt: &str,
        active_agent: &str,
        turn_metadata: &TurnMetadata,
    ) {
        let mut response_with_metadata = response.clone();
        if let Some(obj) = response_with_metadata.as_object_mut() {
            obj.insert("metadata".to_string(), serde_json::to_value(turn_metadata).unwrap_or(Value::Null));
        } else if let Value::String(s) = response {
            response_with_metadata = serde_json::json!({
                "text": s,
                "metadata": turn_metadata
            });
        } else {
            response_with_metadata = serde_json::json!({
                "value": response,
                "metadata": turn_metadata
            });
        }

        let _ = self
            .fire_middleware_event(serde_json::json!({
                "type": "llm_end",
                "response": response_with_metadata,
                "context": self.build_event_context(active_agent, None, Some(system_prompt.to_string())),
            }))
            .await;
    }

    fn strip_raw_field(&self, mut value: Value) -> Value {
        if let Value::Object(ref mut map) = value {
            map.remove("_raw");
        }
        value
    }

    fn parse_intent_control_response(response: &Value) -> Option<IntentControl> {
        match response {
            Value::Null => None,
            Value::Object(obj) => {
                if obj.get("skip").and_then(Value::as_bool) == Some(true) {
                    Some(IntentControl::Skip)
                } else {
                    obj.get("result")
                        .cloned()
                        .map(|result| IntentControl::Override { result })
                }
            }
            _ => None,
        }
    }

    // ── Agentic Loop ──────────────────────────────────────────────────────

    /// Execute the agentic loop.
    ///
    /// `initial_stack`: Optional stack for Stack-Aware Resumption. When provided,
    /// the engine fast-forwards through intermediate agents without calling the LLM,
    /// resuming directly at the deepest (last) agent in the stack.
    pub async fn run(
        &self,
        input: Option<Value>,
        initial_stack: Option<Vec<String>>,
    ) -> AuwgentResult<()> {
        // println!("[DEBUG] AuwgentEngine::run - Agent: {}, Input: {:?}, Initial Stack: {:?}", self.ir.name, input, initial_stack);
        // ── Stack-Aware Resumption ─────────────────────────────────────────
        {
            let mut session = self.session.lock().unwrap();

            // 1. Initialize session stack if empty
            if session.stack.is_empty() {
                session.stack = vec![self.ir.name.clone()];
            }

            // 2. If an explicit stack was passed (e.g. from SDK), sync it to session
            if let Some(stack) = initial_stack {
                session.stack = stack;
            }

            // 3. Set fast-forward focus based on session stack
            // Root agent (index 0) is US, so we skip it for teleportation logic
            if session.stack.len() > 1 {
                // println!("[DEBUG] Teleportation active. Target stack: {:?}", session.stack);
                *self.fast_forward_stack.lock().unwrap() = Some(session.stack[1..].to_vec());
            } else {
                *self.fast_forward_stack.lock().unwrap() = None;
            }
        }

        // let initial_input_val = {
        //     let mut session = self.session.lock().unwrap();
        //     if session.turns.is_empty() && session.initial_input.is_none() {
        //         session.initial_input = input.clone();
        //     }
        //     session.initial_input.clone()
        // };

        let mut scope = HashMap::new();
        {
            // Always insert context into scope — use the actual value if set, otherwise
            // an empty object so context.* references evaluate to null instead of crashing.
            let ctx_val = self.context.lock().unwrap()
                .clone()
                .unwrap_or_else(|| serde_json::json!({}));
            scope.insert("context".to_string(), ctx_val.clone());
            scope.insert("ctx".to_string(), ctx_val);
        }

        let evaluator = Evaluator::new(&self.ir);

        // 1. Evaluate Model Info
        let model_entry = self
            .ir
            .model_config
            .first()
            .ok_or(AuwgentError::MissingConfig("No model config".into()))?;
        let default_config = model_entry
            .default_config
            .as_ref()
            .ok_or(AuwgentError::MissingConfig("No default config".into()))?;

        if let Some(ctx) = self.context.lock().unwrap().as_ref() {
            scope.insert("context".to_string(), ctx.clone());
        }

        let model_info = evaluator.evaluate_model(default_config, &mut scope)?;
        let provider_type = model_info["type"]
            .as_str()
            .or_else(|| model_info["provider"].as_str())
            .unwrap_or("gemini");
        let provider_id = if provider_type == "custom" {
            model_info["id"].as_str().unwrap_or("custom")
        } else {
            provider_type
        };
        let model_name = model_info["modelName"]
            .as_str()
            .unwrap_or("gemini-2.0-flash");
        let config_params = model_info.get("config").cloned();

        // 2. Generate system prompt and set it on the session
        let system_prompt = self.generate_prompt(None)?;
        self.session
            .lock()
            .unwrap()
            .set_system_prompt(&system_prompt);

        if let Some(response) = self
            .fire_middleware_event(serde_json::json!({
                "type": "run_start",
                "session": serde_json::from_str::<Value>(&self.export_session()?).map_err(AuwgentError::Serialization)?,
                "context": self.build_event_context(&self.ir.name, None, Some(system_prompt.clone())),
            }))
            .await
        {
            if let Some(updated_session) = response.get("session") {
                self.import_session(&serde_json::to_string(updated_session).map_err(AuwgentError::Serialization)?)?;
                self.sync_fast_forward_from_session();
            }
        }

        let run_start_handler = self.run_start_handler.lock().unwrap().clone();
        if let Some(h) = run_start_handler {
            let session_json = self.export_session()?;
            let context_json = self.serialize_host_context()?;
            if let Some(updated_session_json) = h(session_json, context_json).await {
                self.import_session(&updated_session_json)?;
                self.sync_fast_forward_from_session();
            }
        }

        // Regenerate the system prompt now that run_start middleware has had a chance
        // to call setContext(). This ensures any context injected during onRunStart
        // is reflected in the current run's system prompt, not just the next one.
        let system_prompt = self.generate_prompt(None)?;
        self.session
            .lock()
            .unwrap()
            .set_system_prompt(&system_prompt);

        // 3. Build the initial user input
        let initial_user_input = match input.as_ref() {
            Some(Value::String(s)) => Some(s.clone()),
            Some(v) => Some(serde_json::to_string(v).map_err(AuwgentError::Serialization)?),
            None => None,
        };

        *self.terminal_response_emitted.lock().unwrap() = false;
        *self.final_response_emitted.lock().unwrap() = false;

        // Start the first turn if an explicit input is provided AND we are not teleporting.
        // If we ARE teleporting, the turn will be started by the target agent.
        let is_teleporting = self.fast_forward_stack.lock().unwrap().is_some();

        if let Some(user_input) = initial_user_input {
            if !is_teleporting {
                self.session.lock().unwrap().start_turn(&user_input);
            }
        } else if self.session.lock().unwrap().turns.is_empty() {
            // Safety fallback: if no input and session is empty, start one
            if !is_teleporting {
                self.session.lock().unwrap().start_turn("");
            }
        }

        // Read max loops from lifecycle config, fallback to 12
        let max_loops: usize = self
            .ir
            .lifecycle
            .as_ref()
            .and_then(|lc| lc.0.get("maxMessages").and_then(|v| v.as_u64()))
            .map(|v| v as usize)
            .unwrap_or(12);

        *self.last_run_metadata.lock().unwrap() = RunMetadata::default();

        let mut loop_count = 0;

        let run_result = async {
            loop {
            loop_count += 1;
            if loop_count > max_loops {
                return Err(AuwgentError::MaxLoopsExceeded(max_loops));
            }

            if loop_count == 1 {
                *self.user_input.lock().unwrap() = input.clone();
            }

            self.current_raw_response.lock().unwrap().clear();
            *self.last_turn_response_value.lock().unwrap() = Value::Null;
            self.pending_tool_results.lock().unwrap().clear();
            self.emitted_partial_intents.lock().unwrap().clear();
            self.orchestrator.lock().unwrap().reset();

            // ── Stack-Aware Resumption: TELEPORTATION ─────────────────────
            // If we have a fast-forward stack, skip the LLM entirely and
            // inject a synthetic helper_call intent to jump straight to
            // the target agent. This is the core of Execution-Tunneling.
            let next_helper = {
                let ffs_lock = self.fast_forward_stack.lock().unwrap();
                ffs_lock.as_ref().and_then(|ffs| ffs.first().cloned())
            };

            if let Some(mut next_helper) = next_helper {
                // If the next helper is ACTUALLY this agent, consume it and look deeper
                if next_helper == self.ir.name {
                    let mut lock = self.fast_forward_stack.lock().unwrap();
                    if let Some(ffs) = lock.as_mut() {
                        if !ffs.is_empty() {
                            ffs.remove(0);
                        }
                        if ffs.is_empty() {
                            *lock = None;
                            continue; // Exit teleportation, go to LLM
                        }
                        next_helper = ffs.first().cloned().unwrap();
                    } else {
                        continue;
                    }
                }

                // Inject synthetic helper_call — no LLM needed
                let synthetic_intent = serde_json::json!({
                    "type": next_helper,
                    "args": {
                        "user_text": input.as_ref().and_then(|v| v.as_str()).unwrap_or("")
                    }
                });

                self.pending_intents
                    .lock()
                    .unwrap()
                    .push(("helper_call".to_string(), synthetic_intent));

                // Process the synthetic intent
                let (_terminal, actions, hard_stop) = self.process_intents().await?;

                if hard_stop {
                    // Record the teleportation turn in the parent session if it finished here
                    let raw_resp = self.current_raw_response.lock().unwrap().clone();
                    if !raw_resp.is_empty() {
                        self.session.lock().unwrap().set_model_response(&raw_resp);
                    }
                    break;
                }
                if actions {
                    let results_payload = self.build_results_payload();
                    self.session.lock().unwrap().start_turn(&results_payload);
                }
                continue;
            }

            // If this is the first turn (the actual user prompt, not a tool feedback cycle),
            // fire the onLlmStart interceptor. It can return a modified string.
            if loop_count == 1 {
                let start_handler = self.llm_start_handler.lock().unwrap().clone();
                if let Some(h) = start_handler {
                    let sys_prompt = self
                        .session
                        .lock()
                        .unwrap()
                        .system_prompt
                        .clone()
                        .unwrap_or_default();
                    let input_text = self
                        .session
                        .lock()
                        .unwrap()
                        .turns
                        .last()
                        .map(|t| t.input.clone())
                        .unwrap_or_default();

                    let context_json = {
                        let ctx_lock = self.context.lock().unwrap();
                        serde_json::to_string(ctx_lock.as_ref().unwrap_or(&Value::Null))
                            .unwrap_or_default()
                    };

                    let mut result = h(input_text.clone(), sys_prompt.clone(), context_json).await;

                    if let Some(middleware_result) = self
                        .apply_llm_start_middleware(&input_text, &sys_prompt, &self.ir.name)
                        .await
                    {
                        if let Some(modified) = middleware_result.get("prompt").and_then(|v| v.as_str()) {
                            result["prompt"] = Value::String(modified.to_string());
                        }
                        if let Some(new_stack) = middleware_result.get("stack").and_then(|v| v.as_array()) {
                            result["stack"] = Value::Array(new_stack.clone());
                        }
                    }

                    if let Some(modified) = result.get("prompt").and_then(|v| v.as_str()) {
                        self.session.lock().unwrap().set_input(modified.to_string());
                    }

                    if let Some(new_stack) = result.get("stack").and_then(|v| v.as_array()) {
                        let stack_vec: Vec<String> = new_stack
                            .iter()
                            .filter_map(|v| v.as_str().map(|s| s.to_string()))
                            .collect();
                        if !stack_vec.is_empty() {
                            let mut session = self.session.lock().unwrap();
                            session.stack = stack_vec;

                            // Re-evaluate teleportation!
                            if session.stack.len() > 1 {
                                *self.fast_forward_stack.lock().unwrap() =
                                    Some(session.stack[1..].to_vec());
                                drop(session); // Important: release lock before continuing
                                continue; // Restart loop to trigger teleportation check at line 489
                            }
                        }
                    }
                }
            }

            // Build message history from session state (AFTER potential interception)
            let messages = self.session.lock().unwrap().to_messages();

            // Stream from the driver using full message history
            let stream_res = {
                let driver = self
                    .drivers
                    .lock()
                    .unwrap()
                    .get(provider_id)
                    .ok_or_else(|| AuwgentError::NoDriver)?
                    .clone();
                driver
                    .stream_generate(model_name, &messages, config_params.clone())
                    .await
            };

            let mut stream = match stream_res {
                Ok(s) => s,
                Err(e) => {
                    // Critical failure during the request phase (e.g. network error, invalid API key)
                    self.fire_intent("error".to_string(), serde_json::json!({ "message": e }))
                        .await;

                    // Ensure the session is not left with a hanging turn
                    self.session
                        .lock()
                        .unwrap()
                        .set_model_response(format!("(request error: {})", e));

                    return Err(AuwgentError::Driver(e));
                }
            };

            let mut actions_performed = false;
            let mut turn_usage = TokenUsage::default();
            let mut turn_finish_reason = None;

            while let Some(chunk_res) = stream.next().await {
                match chunk_res {
                    Ok(ModelEvent::ContentChunk(text)) => {
                        if !text.is_empty() {
                            self.current_raw_response.lock().unwrap().push_str(&text);
                        }
                        self.orchestrator.lock().unwrap().write(&text);
                        let process_res = self.process_intents().await;
                        let (_terminal, actions, hard_stop) = match process_res {
                            Ok(res) => res,
                            Err(e) => {
                                let raw_resp = self.current_raw_response.lock().unwrap().clone();
                                if !raw_resp.is_empty() {
                                    self.session.lock().unwrap().set_model_response(&raw_resp);
                                }
                                return Err(e);
                            }
                        };
                        if actions {
                            actions_performed = true;
                        }
                        if hard_stop {
                            let raw_resp = self.current_raw_response.lock().unwrap().clone();
                            if !raw_resp.is_empty() {
                                self.session.lock().unwrap().set_model_response(&raw_resp);
                            }
                            break;
                        }
                    }
                    Ok(ModelEvent::Usage(usage)) => {
                        turn_usage = usage;
                    }
                    Ok(ModelEvent::FinishReason(fr)) => {
                        turn_finish_reason = Some(fr);
                    }
                    Ok(ModelEvent::Metadata(meta)) => {
                        turn_usage = meta.usage;
                        turn_finish_reason = meta.finish_reason;
                    }
                    Err(e) => {
                        // Fire error as intent if handler exists
                        self.fire_intent(
                            "error".to_string(),
                            serde_json::json!({ "message": e.clone() }),
                        )
                        .await;

                        // Ensure we don't leave a hanging turn with no response in the session
                        // if we are about to return an error.
                        self.session
                            .lock()
                            .unwrap()
                            .set_model_response(format!("(error: {})", e));

                        return Err(AuwgentError::StreamError(e));
                    }
                }
            }

            let turn_metadata = TurnMetadata {
                turn_index: loop_count - 1,
                usage: turn_usage.clone(),
                finish_reason: turn_finish_reason.clone(),
                model: model_name.to_string(),
            };

            {
                let mut meta_lock = self.last_run_metadata.lock().unwrap();
                meta_lock.aggregate.prompt_tokens += turn_usage.prompt_tokens;
                meta_lock.aggregate.completion_tokens += turn_usage.completion_tokens;
                meta_lock.aggregate.total_tokens += turn_usage.total_tokens;
                meta_lock.turns.push(turn_metadata.clone());
            }

            // Finalize parsing
            let _final_val = self.orchestrator.lock().unwrap().end();

            let process_res = self.process_intents().await;
            let (_terminal, actions, hard_stop) = match process_res {
                Ok(res) => res,
                Err(e) => {
                    let raw_resp = self.current_raw_response.lock().unwrap().clone();
                    if !raw_resp.is_empty() {
                        self.session.lock().unwrap().set_model_response(&raw_resp);
                    }
                    return Err(e);
                }
            };
            if actions {
                actions_performed = true;
            }

            // Fire LLM end hook
            let end_handler = self.llm_end_handler.lock().unwrap().clone();
            if let Some(h) = end_handler {
                let sys_prompt = self
                    .session
                    .lock()
                    .unwrap()
                    .system_prompt
                    .clone()
                    .unwrap_or_default();
                let raw_resp = self.current_raw_response.lock().unwrap().clone();
                h(raw_resp, sys_prompt).await;
            }

            let sys_prompt = self
                .session
                .lock()
                .unwrap()
                .system_prompt
                .clone()
                .unwrap_or_default();
            self.notify_llm_end_middleware(
                &(self.last_turn_response_value()),
                &sys_prompt,
                &self.ir.name,
                &turn_metadata,
            )
            .await;

            // Save the raw LLM output in the session history so the exact
            // textual response is visible in logs and follow-up turns.
            let raw_resp = self.current_raw_response.lock().unwrap().clone();
            if !raw_resp.is_empty() {
                self.session.lock().unwrap().set_model_response(&raw_resp);
            }

            // Decide if we loop or stop
            if hard_stop {
                break;
            }

            // If the model performed actions, we MUST loop to feed the results back.
            // We only stop if there are no pending tool/helper results to provide.
            if !actions_performed {
                // Ensure the session has SOME model response before exiting the loop.
                // If the loop is ending and 'set_model_response' was never called,
                // we should at least mark it.
                let mut session = self.session.lock().unwrap();
                if let Some(turn) = session.current_turn_mut() {
                    if turn.model_response.is_empty() {
                        turn.model_response = "(no response)".to_string();
                    }
                }
                break;
            }

            // Feed tool/workflow results back to the LLM as the next turn's input
            let results_payload = self.build_results_payload();
            self.session.lock().unwrap().start_turn(&results_payload);
            }

            Ok(())
        }
        .await;

        match run_result {
            Ok(()) => {
                if let Some(_) = self
                    .fire_middleware_event(serde_json::json!({
                        "type": "run_complete",
                        "session": serde_json::from_str::<Value>(&self.export_session()?).map_err(AuwgentError::Serialization)?,
                        "context": self.build_event_context(&self.ir.name, None, None),
                    }))
                    .await
                {
                }
                let run_complete_handler = self.run_complete_handler.lock().unwrap().clone();
                if let Some(h) = run_complete_handler {
                    let session_json = self.export_session()?;
                    let context_json = self.serialize_host_context()?;
                    h(session_json, context_json).await;
                }
                Ok(())
            }
            Err(err) => {
                let middleware_response = self
                    .fire_middleware_event(serde_json::json!({
                        "type": "error",
                        "error": { "message": err.to_string() },
                        "session": self.export_session().ok().and_then(|session| serde_json::from_str::<Value>(&session).ok()),
                        "context": self.build_event_context(&self.ir.name, None, None),
                    }))
                    .await;
                let error_handler = self.error_handler.lock().unwrap().clone();
                if let Some(h) = error_handler {
                    let error_json = serde_json::json!({ "message": err.to_string() }).to_string();
                    let session_json = self.export_session().ok();
                    let context_json = self.serialize_host_context()?;
                    if h(error_json, session_json, context_json).await {
                        return Ok(());
                    }
                }
                if middleware_response
                    .as_ref()
                    .and_then(|response| response.get("swallow"))
                    .and_then(Value::as_bool)
                    .unwrap_or(false)
                {
                    return Ok(());
                }
                Err(err)
            }
        }
    }

    /// Build a structured payload of tool/workflow results to feed back to
    /// the LLM on the next turn using result blocks.
    fn build_results_payload(&self) -> String {
        let results = self.pending_tool_results.lock().unwrap();
        if results.is_empty() {
            return String::new();
        }

        let mut blocks = Vec::new();
        for (name, args, result) in &*results {
            let payload = serde_json::json!({
                "name": name,
                "args": args,
                "result": result
            });

            let body = serde_yaml::to_string(&payload)
                .unwrap_or_default()
                .trim()
                .trim_start_matches("---")
                .trim()
                .to_string();

            blocks.push(format!("[result]\n{}\n[/result]", body));
        }

        blocks.join("\n\n")
    }

    /// Fire the user's intent callback (if registered).
    /// Returns the control signal, or None if no handler / handler returns None.
    async fn fire_intent(&self, name: String, value: Value) -> Option<IntentControl> {
        let handler = self.intent_handler.lock().unwrap().clone();
        if let Some(h) = handler {
            h(name, value, self.ir.name.clone()).await
        } else {
            None
        }
    }

    pub async fn process_intents(&self) -> AuwgentResult<(bool, bool, bool)> {
        let intents = {
            let mut pending = self
                .pending_intents
                .lock()
                .expect("pending_intents mutex poisoned");
            std::mem::take(&mut *pending)
        };

        let mut has_terminal = false;
        let mut has_actions = false;
        let mut hard_stop = false;

        let mut tool_results: Vec<(String, Value, Value)> = Vec::new();

        for (name, mut value) in intents {
            // println!("[DEBUG] Processing intent: {} -> {}", name, serde_json::to_string(&value).unwrap_or_default());
            let control = if let Some(control) = self
                .apply_intent_middleware(&name, &value, &self.ir.name)
                .await
            {
                Some(control)
            } else {
                self.fire_intent(name.clone(), self.strip_raw_field(value.clone()))
                    .await
            };

            // Strip _raw before internal processing (tool execution, etc.)
            if let Value::Object(ref mut map) = value {
                map.remove("_raw");
            }

            match name.as_str() {
                "tool_call" => {
                    match control {
                        Some(IntentControl::Skip) => {
                            // User chose to skip — fire a skip notification
                            self.fire_intent("tool_skipped".to_string(), value.clone())
                                .await;
                            continue;
                        }
                        Some(IntentControl::Override { result }) => {
                            // User provided a custom result
                            let tool_name = value["type"].as_str().unwrap_or("").to_string();
                            let args = value["args"].clone();
                            self.fire_intent(
                                "tool_result".to_string(),
                                serde_json::json!({
                                    "name": tool_name,
                                    "args": args,
                                    "result": result,
                                    "overridden": true,
                                }),
                            )
                            .await;
                            tool_results.push((tool_name, args, result));
                            has_actions = true;
                        }
                        None => {
                            // Default: auto-execute the tool
                            let (tool_name, args, result) = self.execute_tool(&value).await?;
                            // Fire tool_result intent
                            self.fire_intent(
                                "tool_result".to_string(),
                                serde_json::json!({
                                    "name": tool_name,
                                    "args": args,
                                    "result": result,
                                }),
                            )
                            .await;
                            tool_results.push((tool_name, args, result));
                            has_actions = true;
                        }
                    }
                }
                "workflow_call" => match control {
                    Some(IntentControl::Skip) => continue,
                    Some(IntentControl::Override { result }) => {
                        let wf_name = value["type"].as_str().unwrap_or("").to_string();
                        let args = value["args"].clone();
                        tool_results.push((format!("workflow:{}", wf_name), args, result));
                        has_actions = true;
                    }
                    None => {
                        let (wf_name, args, result) = self.execute_workflow(&value).await?;
                        self.fire_intent(
                            "workflow_result".to_string(),
                            serde_json::json!({
                                "name": wf_name,
                                "args": args,
                                "result": result,
                            }),
                        )
                        .await;
                        tool_results.push((format!("workflow:{}", wf_name), args, result));
                        has_actions = true;
                    }
                },
                "helper_call" => match control {
                    Some(IntentControl::Skip) => continue,
                    Some(IntentControl::Override { result }) => {
                        let helper_name = value["type"].as_str().unwrap_or("").to_string();
                        let args = value["args"].clone();
                        tool_results.push((format!("helper:{}", helper_name), args, result));
                        has_actions = true;
                    }
                    None => {
                        let (helper_name, args, result) = self.execute_helper(&value).await?;

                        // Check if the helper signaled a hard stop (handoff mod="user")
                        if let Some(obj) = result.as_object() {
                            if obj
                                .get("__handoff_stop")
                                .and_then(|v| v.as_bool())
                                .unwrap_or(false)
                            {
                                // The helper already streamed its terminal intent directly to the user.
                                // We tell the parent engine to stop looping immediately, but only AFTER processing other sibling intents.
                                has_terminal = true;
                                hard_stop = true;
                                // DO NOT break here anymore, continue to other intents in the same turn
                            }
                        }

                        self.fire_intent(
                            "helper_result".to_string(),
                            serde_json::json!({
                                "name": helper_name,
                                "args": args,
                                "result": result,
                            }),
                        )
                        .await;
                        tool_results.push((format!("helper:{}", helper_name), args, result));
                        has_actions = true;
                    }
                },
                "response_schema" | "response_text" => {
                    // Terminal intents — already fired to user above
                    has_terminal = true;
                    *self.last_turn_response_value.lock().unwrap() = value.clone();
                    *self.terminal_response_emitted.lock().unwrap() = true;
                    *self.final_response_emitted.lock().unwrap() = true;
                }
                _ => {
                    // Custom / unknown intents — already fired to user.
                    // We treat these as terminal (waiting for user input).
                    has_terminal = true;
                    *self.last_turn_response_value.lock().unwrap() = value.clone();
                    *self.terminal_response_emitted.lock().unwrap() = true;
                }
            }
        }

        // Store tool results
        self.pending_tool_results
            .lock()
            .unwrap()
            .extend(tool_results);

        Ok((has_terminal, has_actions, hard_stop))
    }

    async fn execute_tool(&self, call: &Value) -> AuwgentResult<(String, Value, Value)> {
        let tool_name = call["type"].as_str().unwrap_or("").to_string();
        let args = call["args"].clone();

        let imp = self.tools.lock().unwrap().get(&tool_name).cloned();
        if let Some(imp) = imp {
            match imp(args.clone()).await {
                Ok(val) => Ok((tool_name, args, val)),
                Err(e) => {
                    // Fire a specific tool_error intent so the host can react
                    let error_value = serde_json::json!({
                        "tool": tool_name,
                        "message": e,
                    });
                    self.fire_intent(
                        "tool_error".to_string(),
                        error_value.clone(),
                    )
                    .await;
                    let _ = self
                        .fire_middleware_event(serde_json::json!({
                            "type": "error",
                            "error": {
                                "kind": "tool_error",
                                "tool": tool_name,
                                "message": e,
                            },
                            "session": Value::Null,
                            "context": self.build_event_context(&self.ir.name, None, None),
                        }))
                        .await;
                    // Return the error as the result — the LLM will see it
                    // and can retry or adjust
                    Ok((tool_name, args, serde_json::json!({ "error": e })))
                }
            }
        } else {
            let message = format!("Tool not found: {}", tool_name);
            self.fire_intent(
                "tool_error".to_string(),
                serde_json::json!({
                    "tool": tool_name,
                    "message": message,
                }),
            )
            .await;
            let _ = self
                .fire_middleware_event(serde_json::json!({
                    "type": "error",
                    "error": {
                        "kind": "tool_error",
                        "tool": tool_name,
                        "message": message,
                    },
                    "session": Value::Null,
                    "context": self.build_event_context(&self.ir.name, None, None),
                }))
                .await;
            Ok((
                tool_name.clone(),
                args,
                serde_json::json!({ "error": format!("Tool '{}' is not registered", tool_name) }),
            ))
        }
    }

    async fn execute_workflow(&self, call: &Value) -> AuwgentResult<(String, Value, Value)> {
        let wf_name = call["type"].as_str().unwrap_or("").to_string();
        let args = call["args"].clone();

        let body_clone = {
            let wf = match self.ir.workflows.iter().find(|w| w.name == wf_name) {
                Some(w) => w,
                None => {
                    return Ok((
                        wf_name.clone(),
                        args.clone(),
                        serde_json::json!({ "error": format!("Workflow not found: {}", wf_name) }),
                    ));
                }
            };
            wf.body.clone()
        };

        // Create evaluator WITH tools
        let mut tool_fns: HashMap<String, crate::evaluator::SyncToolFn> = HashMap::new();
        {
            let tools = self.tools.lock().unwrap();
            let ir_tools = &self.ir.tools;

            for (name, imp) in &*tools {
                let imp = imp.clone();
                let name_clone = name.clone();

                // Find tool definition to get parameter names
                let param_names: Vec<String> = ir_tools
                    .iter()
                    .find(|t| t.name == *name)
                    .and_then(|t| t.params.0.as_object())
                    .map(|params: &serde_json::Map<String, Value>| {
                        let mut names: Vec<_> = params.keys().cloned().collect();
                        names.sort(); // Ensure consistent ordering
                        names
                    })
                    .unwrap_or_default();

                tool_fns.insert(
                    name.clone(),
                    std::sync::Arc::new(move |fn_args: Vec<Value>| {
                        // Convert positional args to named args object
                        let arg_val = if param_names.is_empty() {
                            // No params defined - pass args as-is (legacy behavior)
                            if fn_args.len() == 1 {
                                fn_args.into_iter().next().unwrap_or(Value::Null)
                            } else {
                                Value::Array(fn_args)
                            }
                        } else {
                            // Convert positional args to named args object
                            let mut args_obj: serde_json::Map<String, Value> =
                                serde_json::Map::new();
                            for (i, param_name) in param_names.iter().enumerate() {
                                if let Some(arg_value) = fn_args.get(i) {
                                    args_obj.insert(param_name.clone(), arg_value.clone());
                                }
                            }
                            Value::Object(args_obj)
                        };

                        let rt = tokio::runtime::Handle::current();
                        let imp = imp.clone();
                        std::thread::spawn(move || rt.block_on(imp(arg_val)))
                            .join()
                            .map_err(|_| format!("Tool '{}' panicked", name_clone))?
                    }),
                );
            }
        }

        let ir_clone = self.ir.clone();

        let mut scope = HashMap::new();
        if let Some(obj) = args.as_object() {
            for (k, v) in obj {
                scope.insert(k.clone(), v.clone());
            }
        }
        // Inject context into workflow scope
        if let Some(ctx) = self.context.lock().unwrap().as_ref() {
            scope.insert("context".to_string(), ctx.clone());
        }

        let mut last_result = Value::Null;
        for stmt in &body_clone {
            let eval_result = {
                let evaluator = Evaluator::with_tools(&ir_clone, tool_fns.clone());
                evaluator.evaluate(stmt, &mut scope)?
            };

            if let Some(obj) = eval_result.as_object() {
                if obj
                    .get("__requires_async_helper_call")
                    .and_then(|v| v.as_bool())
                    .unwrap_or(false)
                {
                    let target_helper = obj
                        .get("helper_name")
                        .and_then(|v| v.as_str())
                        .unwrap_or("");
                    let helper_args = obj.get("args").unwrap_or(&Value::Null).clone();

                    let helper_call = serde_json::json!({
                        "type": target_helper,
                        "args": helper_args
                    });
                    let (_, _, sub_result) = self.execute_helper(&helper_call).await?;
                    last_result = sub_result;
                    continue;
                }

                if obj
                    .get("__requires_async_transfer")
                    .and_then(|v| v.as_bool())
                    .unwrap_or(false)
                {
                    let target_helper = obj.get("target").and_then(|v| v.as_str()).unwrap_or("");
                    let helper_call = serde_json::json!({
                        "type": target_helper,
                        "args": {}
                    });
                    let (_, _, sub_result) = self.execute_helper(&helper_call).await?;

                    if let Some(res_obj) = sub_result.as_object() {
                        if res_obj
                            .get("__handoff_stop")
                            .and_then(|v| v.as_bool())
                            .unwrap_or(false)
                        {
                            return Ok((wf_name, args, sub_result));
                        }
                    }

                    last_result = sub_result;
                    continue;
                }
            }

            last_result = eval_result;
        }

        Ok((wf_name, args, last_result))
    }

    /// Execute a helper as a fully-featured nested engine.
    ///
    /// The helper gets:
    ///  - Its own AgentIR (correct prompt, tools, workflows, output schema)
    ///  - All authorized parent tools (filtered via `helperToolGrants`)
    ///  - All parent drivers (shared via Arc — no recreation)
    ///  - Full agentic loop via `sub_engine.run()` — multi-turn, tool calls,
    ///    skip/override controls, workflows — everything the main agent can do.
    ///
    /// The only thing helpers cannot do is invoke other helpers.
    ///
    /// Returns a `BoxFuture` (heap-allocated future) to break the async recursion
    /// cycle: `run → process_intents → execute_workflow → execute_helper → sub_engine.run()`
    fn execute_helper<'a>(
        &'a self,
        call: &'a Value,
    ) -> futures_util::future::BoxFuture<'a, AuwgentResult<(String, Value, Value)>> {
        let session_preload_handler = self.session_preload_handler.clone();
        let session_save_handler = self.session_save_handler.clone();

        Box::pin(async move {
            use crate::runtime::helper_runner::{HandoffMode, build_sub_agent_context};

            let helper_name = call["type"].as_str().unwrap_or("").to_string();
            let args = call["args"].clone();

            // 1. Push helper to session stack (only if NOT teleporting)
            {
                let mut session = self.session.lock().unwrap();
                let is_teleporting = {
                    let ffs_lock = self.fast_forward_stack.lock().unwrap();
                    ffs_lock.is_some()
                };

                if is_teleporting {
                    // println!("[DEBUG] Teleportation in progress for {}. Skipping stack push.", helper_name);
                } else {
                    // println!("[DEBUG] Pushing helper to stack: {}", helper_name);
                    session.stack.push(helper_name.clone());
                }
            }

            // 2. Build the sub-agent IR
            let sub_ctx = build_sub_agent_context(&self.ir, &helper_name)?;

            // Clone helper tool names before moving sub_ctx.ir
            let helper_tool_names: Vec<String> =
                sub_ctx.ir.tools.iter().map(|t| t.name.clone()).collect();

            // Also collect helper workflow tool names
            let mut helper_workflow_tool_names: Vec<String> = Vec::new();
            for workflow in &sub_ctx.ir.workflows {
                for tool in &workflow.tools {
                    helper_workflow_tool_names.push(tool.name.clone());
                }
            }

            // 2. Construct a fresh sub-engine
            let sub_engine = AuwgentEngine::new(sub_ctx.ir);

            // 3. Share all parent drivers
            {
                let drivers = self.drivers.lock().unwrap();
                let mut sub_drivers = sub_engine.drivers.lock().unwrap();
                for (provider_type, driver) in &*drivers {
                    sub_drivers.insert(provider_type.clone(), Arc::clone(driver));
                }
            }

            // 4. Inject authorized parent tools AND helper's own tools
            {
                let tools = self.tools.lock().unwrap();
                let mut sub_tools = sub_engine.tools.lock().unwrap();

                // Add authorized parent tools
                for tool_name in &sub_ctx.authorized_parent_tool_names {
                    if let Some(imp) = tools.get(tool_name) {
                        sub_tools.insert(tool_name.clone(), Arc::clone(imp));
                    }
                }

                // Add helper's own tools
                for tool_name in &helper_tool_names {
                    if let Some(imp) = tools.get(tool_name) {
                        sub_tools.insert(tool_name.clone(), Arc::clone(imp));
                    }
                }

                // Add helper's workflow tools
                for tool_name in &helper_workflow_tool_names {
                    if let Some(imp) = tools.get(tool_name) {
                        sub_tools.insert(tool_name.clone(), Arc::clone(imp));
                    }
                }
            }

            // 5. Propagate context
            if let Some(ctx) = self.context.lock().unwrap().as_ref() {
                sub_engine.set_context(ctx.clone());
            }

            // 6. Wire intent handlers
            match sub_ctx.handoff_mode {
                HandoffMode::User | HandoffMode::ThenContinue => {
                    if let Some(handler) = self.intent_handler.lock().unwrap().as_ref() {
                        sub_engine.on_intent(Arc::clone(handler));
                    }
                    if let Some(handler) = self.partial_intent_handler.lock().unwrap().as_ref() {
                        sub_engine.on_intent_partial(Arc::clone(handler));
                    }
                }
                HandoffMode::Return => {}
            }

            // Inherit hooks (middleware listeners)
            {
                let h = self.llm_start_handler.lock().unwrap().clone();
                if let Some(handler) = h {
                    sub_engine.on_llm_start(handler);
                }
            }
            {
                let h = self.llm_end_handler.lock().unwrap().clone();
                if let Some(handler) = h {
                    sub_engine.on_llm_end(handler);
                }
            }
            {
                let h = self.run_start_handler.lock().unwrap().clone();
                if let Some(handler) = h {
                    sub_engine.on_run_start(handler);
                }
            }
            {
                let h = self.run_complete_handler.lock().unwrap().clone();
                if let Some(handler) = h {
                    sub_engine.on_run_complete(handler);
                }
            }
            {
                let h = self.error_handler.lock().unwrap().clone();
                if let Some(handler) = h {
                    sub_engine.on_error(handler);
                }
            }

            // Pre-generate system prompt
            if let Ok(system_prompt) = sub_engine.generate_prompt(None) {
                sub_engine
                    .session
                    .lock()
                    .unwrap()
                    .set_system_prompt(&system_prompt);
            }

            // Preload session
            let preload_fn = session_preload_handler.lock().unwrap().clone();
            if let Some(f) = preload_fn {
                let empty_session = sub_engine
                    .export_session()
                    .unwrap_or_else(|_| "{}".to_string());
                let _ = self
                    .fire_middleware_event(serde_json::json!({
                        "type": "sub_engine_start",
                        "helper": helper_name.clone(),
                        "session": serde_json::from_str::<Value>(&empty_session).unwrap_or(Value::Null),
                        "context": self.build_event_context(&helper_name, None, None),
                    }))
                    .await;
                if let Some(loaded_json) = f(helper_name.clone(), empty_session).await {
                    let _ = sub_engine.import_session(&loaded_json);
                }
            }

            // Propagate fast-forward stack
            let sub_initial_stack = {
                let mut ffs_lock = self.fast_forward_stack.lock().unwrap();
                let stack = ffs_lock.as_ref().and_then(|ffs| {
                    if ffs.first().map(|s| s.as_str()) == Some(helper_name.as_str()) {
                        let mut sub_stack = vec![helper_name.clone()];
                        sub_stack.extend_from_slice(&ffs[1..]);
                        Some(sub_stack)
                    } else {
                        None
                    }
                });
                if stack.is_some() {
                    // println!("[DEBUG] Propagating sub-stack to {}: {:?}", helper_name, stack);
                    *ffs_lock = None;
                }
                stack
            };

            let sub_input = {
                let mut user_input_lock = self.user_input.lock().unwrap();
                let is_resuming_at_target =
                    sub_initial_stack.as_ref().map_or(false, |s| s.len() == 1);

                if is_resuming_at_target {
                    // This is the target of teleportation!
                    // Feed the original user message to the sub-engine.
                    // println!("[DEBUG] {} is the teleportation target. Injecting user input: {:?}", helper_name, user_input_lock);
                    user_input_lock.take()
                } else if sub_initial_stack.is_some() {
                    // Still traversing the stack — no input for this intermediate agent
                    None
                } else {
                    // First time calling this helper — use the provided arguments
                    Some(args.clone())
                }
            };

            sub_engine.run(sub_input, sub_initial_stack).await?;

            // Save session
            let save_fn = session_save_handler.lock().unwrap().clone();
            if let Some(f) = save_fn {
                if let Ok(completed_json) = sub_engine.export_session() {
                    f(helper_name.clone(), completed_json).await;
                }
            }
            if let Ok(completed_json) = sub_engine.export_session() {
                let _ = self
                    .fire_middleware_event(serde_json::json!({
                        "type": "sub_engine_complete",
                        "helper": helper_name.clone(),
                        "session": serde_json::from_str::<Value>(&completed_json).unwrap_or(Value::Null),
                        "context": self.build_event_context(&helper_name, None, None),
                    }))
                    .await;
            }

            let final_resp = sub_engine
                .session
                .lock()
                .unwrap()
                .turns
                .last()
                .map(|t| t.model_response.clone())
                .unwrap_or_default();

            let emitted_terminal = *sub_engine.terminal_response_emitted.lock().unwrap();
            let emitted_final = *sub_engine.final_response_emitted.lock().unwrap();

            match sub_ctx.handoff_mode {
                HandoffMode::User => {
                    if emitted_final {
                        // Pop stack — final response delivered, return to parent
                        self.session.lock().unwrap().stack.pop();
                        Ok((
                            helper_name,
                            args,
                            serde_json::json!({ "__handoff_stop": true }),
                        ))
                    } else if emitted_terminal {
                        // DO NOT pop stack — still in helper (e.g. asking questions via custom intent)
                        Ok((
                            helper_name,
                            args,
                            serde_json::json!({ "__handoff_stop": true }),
                        ))
                    } else {
                        // NO terminal response at all? Helper might be broken or just finished tools.
                        // We still treat it as a stop if handoff is user.
                        Ok((
                            helper_name,
                            args,
                            serde_json::json!({ "__handoff_stop": true }),
                        ))
                    }
                }
                HandoffMode::ThenContinue => {
                    if emitted_final {
                        // Pop stack — focus returns to parent
                        self.session.lock().unwrap().stack.pop();
                        let msg = serde_json::json!({
                            "status": "complete",
                            "note": format!("{} has responded to the user directly. No further action needed.
                            unless you have distinct that is differ from what we have completed entirely.
                            you can end by providing a useful commet to the user
                            ", &helper_name)
                        });
                        Ok((helper_name, args, msg))
                    } else if emitted_terminal {
                        // DO NOT pop stack — still in helper (e.g. asking questions via custom intent)
                        Ok((
                            helper_name,
                            args,
                            serde_json::json!({ "__handoff_stop": true }),
                        ))
                    } else {
                        // Default to stop if something went wrong but we are in thenContinue
                        Ok((
                            helper_name,
                            args,
                            serde_json::json!({ "__handoff_stop": true }),
                        ))
                    }
                }
                HandoffMode::Return => {
                    if emitted_final {
                        // Pop stack — focus returns to parent
                        self.session.lock().unwrap().stack.pop();
                        Ok((
                            helper_name,
                            args,
                            serde_json::json!({ "result": final_resp }),
                        ))
                    } else if emitted_terminal {
                        // DO NOT pop stack — still in helper (e.g. asking questions via custom intent)
                        Ok((
                            helper_name,
                            args,
                            serde_json::json!({ "__handoff_stop": true }),
                        ))
                    } else {
                        // For Return mode, if no terminal response, it might be an error or unexpected finish.
                        // We pop and return what we have (could be empty or last turn).
                        self.session.lock().unwrap().stack.pop();
                        Ok((
                            helper_name,
                            args,
                            serde_json::json!({ "result": final_resp }),
                        ))
                    }
                }
            }
        })
    }

    pub fn write_llm_chunk(&self, chunk: &str) {
        self.orchestrator.lock().unwrap().write(chunk);
    }

    pub fn end_llm_stream(&self) -> Value {
        self.orchestrator.lock().unwrap().end()
    }

    fn sync_fast_forward_from_session(&self) {
        let session = self.session.lock().unwrap();
        if session.stack.len() > 1 {
            *self.fast_forward_stack.lock().unwrap() = Some(session.stack[1..].to_vec());
        } else {
            *self.fast_forward_stack.lock().unwrap() = None;
        }
    }

    fn last_turn_response_value(&self) -> Value {
        self.last_turn_response_value.lock().unwrap().clone()
    }

    fn serialize_host_context(&self) -> AuwgentResult<String> {
        let session = self.session.lock().unwrap();
        let context_json = serde_json::json!({
            "activeAgent": self.ir.name,
            "stack": session.stack,
            "systemPrompt": session.system_prompt,
        });
        serde_json::to_string(&context_json).map_err(AuwgentError::Serialization)
    }

    pub fn generate_prompt(&self, helper_name: Option<String>) -> AuwgentResult<String> {
        if let Some(name) = helper_name {
            let sub_ctx = crate::runtime::helper_runner::build_sub_agent_context(&self.ir, &name)?;
            let sub_engine = AuwgentEngine::new(sub_ctx.ir);

            // Propagate context so prompt evaluation works
            if let Some(ctx) = self.context.lock().unwrap().as_ref() {
                sub_engine.set_context(ctx.clone());
            }

            sub_engine.generate_prompt(None)
        } else {
            self.generate_main_prompt()
        }
    }

    fn generate_main_prompt(&self) -> AuwgentResult<String> {
        let evaluator = Evaluator::new(&self.ir);
        let mut scope = HashMap::new();

        // Always inject context into scope — use the actual value if set, otherwise
        // an empty object so context.* references evaluate gracefully instead of crashing.
        {
            let ctx_val = self.context.lock().unwrap()
                .clone()
                .unwrap_or_else(|| serde_json::json!({}));
            scope.insert("context".to_string(), ctx_val.clone());
            scope.insert("ctx".to_string(), ctx_val);
        }

        let entry = self
            .ir
            .model_config
            .first()
            .ok_or(AuwgentError::MissingConfig("No model config".into()))?;
        let default = entry
            .default_config
            .as_ref()
            .ok_or(AuwgentError::MissingConfig("No default config".into()))?;

        let parsed_prompt: crate::types::Expression =
            serde_json::from_value(default.prompt.0.clone())
                .map_err(|e| AuwgentError::Evaluation(format!("Prompt parse error: {}", e)))?;
        let prompt_val = evaluator.evaluate(&parsed_prompt, &mut scope)?;
        let mut prompt = prompt_val.as_str().unwrap_or("").to_string();

        // ── Magic Context DX: Automatic context injection ─────────────────
        if let Some(ctx) = self.context.lock().unwrap().as_ref() {
            if let Some(obj) = ctx.as_object() {
                let mut filtered_ctx = serde_json::Map::new();
                for (k, v) in obj {
                    let is_empty = match v {
                        Value::Null => true,
                        Value::Array(a) => a.is_empty(),
                        Value::Object(o) => o.is_empty(),
                        Value::String(s) => s.is_empty(),
                        _ => false,
                    };
                    if !is_empty {
                        filtered_ctx.insert(k.clone(), v.clone());
                    }
                }

                if !filtered_ctx.is_empty() {
                    if let Ok(yaml) = serde_yaml::to_string(&Value::Object(filtered_ctx)) {
                        prompt.push_str("\n\n# ADDITIONAL CONTEXT\n");
                        prompt.push_str(yaml.trim());
                    }
                }
            }
        }

        let intents = crate::intents::generate_block_protocol_prompt(&self.ir);
        if !intents.is_empty() {
            prompt.push_str("\n\n");
            prompt.push_str(&intents);
        }

        Ok(prompt)
    }
}
