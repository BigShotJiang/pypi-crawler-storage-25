from ewoksfluo.gui.mesh_widget import OWMeshWidget
from ewoksfluo.tasks.example_data.tasks import MeshSingleScanMultiDetectorGroups


class OWMeshSingleScanMultiDetectorGroups(
    OWMeshWidget,
    ewokstaskclass=MeshSingleScanMultiDetectorGroups,
):
    name = "Mesh (multi detector groups)"
    description = "XRF test data of one scan with multiple groups"

    def _init_control_area(self):
        super()._init_control_area(
            stack=False, multidetector=True, multigroup=True, mosaic=False
        )
