from ewoksfluo.gui.mesh_widget import OWMeshWidget
from ewoksfluo.tasks.example_data.tasks import MosaicMeshMultiDetectorGroups


class OWMosaicMeshMultiDetectorGroups(
    OWMeshWidget,
    ewokstaskclass=MosaicMeshMultiDetectorGroups,
):
    name = "Mosaic Mesh (multi detector groups)"
    description = "XRF test data of one scan with multiple detector groups"

    def _init_control_area(self):
        super()._init_control_area(
            stack=False, multidetector=True, multigroup=True, mosaic=True
        )
