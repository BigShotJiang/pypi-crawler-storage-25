from dataclasses import dataclass
from typing import List
from typing import NamedTuple
from typing import Optional

from ...io import hdf5
from ...io import output_uri
from ..pymca_config import PyMcaXrfConfiguration


class FitUris(NamedTuple):
    bliss_scan_uris: List[str]
    detector_name: str
    output_root_uri: str
    output_root_group: Optional[str] = None
    xrf_spectra_uri_template: str = "instrument/{}/data"
    energy_uri_template: str = "instrument/positioners/{}"
    energy_name: Optional[str] = None

    @property
    def xrf_spectra_uris(self) -> List[str]:
        template = self.xrf_spectra_uri_template
        return [
            f"{bliss_scan_uri}/{template.format(self.detector_name)}"
            for bliss_scan_uri in self.bliss_scan_uris
        ]

    @property
    def full_output_root_uri(self) -> str:
        _, scan_h5path0 = hdf5.split_h5uri(self.bliss_scan_uris[0])
        return output_uri.compose_full_output_uri(
            self.output_root_uri,
            default_output_data_path=scan_h5path0,
            extra_data_paths=(self.output_root_group, output_uri.DEFAULT_FIT_NAME),
        )

    @property
    def output_parent_uri(self) -> str:
        return hdf5.join_h5url(self.full_output_root_uri, self.detector_name)

    @property
    def beam_energy_uris(self) -> List[Optional[str]]:
        if not self.energy_name:
            return [None] * len(self.bliss_scan_uris)
        template = self.energy_uri_template
        return [
            f"{bliss_scan_uri}/{template.format(self.energy_name)}"
            for bliss_scan_uri in self.bliss_scan_uris
        ]


@dataclass
class ProgressStats:
    seconds_read: float = 0.0
    seconds_process: float = 0.0
    seconds_write: float = 0.0


class FitTask(NamedTuple):
    xrf_spectra_uri: str
    beam_energy_uri: Optional[str]
    start_in: int
    stop_in: int
    start_out: int
    stop_out: int
    output_parent_uri: str
    progress: ProgressStats

    @property
    def num_spectra(self) -> int:
        return self.stop_in - self.start_in


class FitArguments(NamedTuple):
    configuration: PyMcaXrfConfiguration
    quantification: Optional[bool]
    individual_weights: Optional[bool]
    positive_peak_areas: Optional[bool]
    energy_multiplier: Optional[bool]
    fast_fitting: Optional[bool]
    native_fitting: Optional[bool]
    native_legacy_fitting: Optional[bool]
    diagnostics: Optional[bool]
