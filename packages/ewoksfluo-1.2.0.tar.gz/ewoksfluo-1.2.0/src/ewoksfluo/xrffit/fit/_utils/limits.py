import numpy


def expand_data(
    axis_indices,
    data: numpy.ndarray,
    axis_size: int,
    axis: int = 0,
    fill_value=numpy.nan,
) -> numpy.ndarray:
    """Expand ``data`` defined on a subset of ``axis_indices`` into an
    array of length ``axis_size`` along the specified ``axis``.
    """
    shape = list(data.shape)
    shape[axis] = axis_size
    data_full = numpy.full(shape, fill_value, dtype=data.dtype)
    indexer = [slice(None)] * data.ndim
    indexer[axis] = axis_indices
    data_full[tuple(indexer)] = data
    return data_full
