from typing import Tuple

import numpy
from PyMca5.PyMcaPhysics.xrf import ClassMcaTheory


def channel_info(
    mca_theory: ClassMcaTheory,
) -> Tuple[numpy.ndarray, numpy.ndarray]:
    """Return MCA channel indices use for fitting and the raw data."""
    channels = mca_theory.xdata[:, 0]
    raw_channels = mca_theory.xdata0
    return channels, raw_channels


def energy_info(mca_theory: ClassMcaTheory, channels: numpy.ndarray) -> numpy.ndarray:
    """Return MCA bin energies use for fitting and the raw data."""
    zero, gain = mca_theory.parameters[:2]
    energies = zero + gain * channels
    return energies
