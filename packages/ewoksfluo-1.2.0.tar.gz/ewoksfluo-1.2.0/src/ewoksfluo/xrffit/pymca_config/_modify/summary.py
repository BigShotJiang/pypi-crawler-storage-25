from typing import List
from typing import Optional

import numpy

from ..model import PyMcaXrfConfiguration


def configuration_summary(
    configuration: PyMcaXrfConfiguration,
    quantification: Optional[dict],
    fast_fitting: bool,
) -> List[str]:
    fit = configuration.fit
    concentrations = configuration.concentrations
    attenuators = configuration.attenuator_views
    matrix = attenuators["Matrix"]

    ind = numpy.array(fit.energyflag).astype(bool)
    _energy = numpy.array(fit.energy)[ind]
    _weights = numpy.array(fit.energyweight)[ind]
    _weights = _weights / _weights.sum() * 100
    _scatter = numpy.array(fit.energyscatter)[ind]

    summary: List[str] = [
        f"{en} keV (Rate = {w:.2f}%, Scatter {'ON' if scat else 'OFF'})"
        for en, w, scat in zip(_energy, _weights, _scatter)
    ]

    if quantification:
        summary.extend(
            [
                f"flux = {concentrations.flux:e} ph/sec",
                f"time = {concentrations.time} s",
                f"active area = {concentrations.area} cm^2",
                f"sample-detector distance = {concentrations.distance} cm",
                f"angle IN = {matrix.incidence_angle} deg",
                f"angle OUT = {matrix.exit_angle} deg",
            ]
        )

    if matrix.enabled:
        summary.append(f"Matrix = {matrix.material}")
    else:
        summary.append("Matrix = <DISABLED>")

    summary.append(f"Linear = {'YES' if fit.linearfitflag else 'NO'}")
    summary.append(f"Fast fitting = {'YES' if fast_fitting else 'NO'}")
    summary.append(f"Error propagation = {'Poisson' if fit.fitweight else 'OFF'}")
    summary.append(f"Matrix adjustment = {'ON' if fit.strategyflag else 'OFF'}")

    return summary
