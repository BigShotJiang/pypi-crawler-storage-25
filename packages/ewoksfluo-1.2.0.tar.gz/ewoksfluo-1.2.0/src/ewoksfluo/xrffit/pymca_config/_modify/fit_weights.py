import logging
from typing import Optional

from ..model import PyMcaXrfConfiguration

logger = logging.getLogger(__name__)


def set_fit_weights(
    configuration: PyMcaXrfConfiguration, quantification: Optional[dict]
):
    if configuration.fit.fitweight:
        if quantification:
            logger.warning(
                "Fit weights stays enabled. May reduce fit quality for low-count spectra, "
                "but uncertainties will remain correct."
            )
        else:
            logger.warning(
                "Disabling fit weights because no quantification is done. "
                "Fit quality improves for low-count spectra, but uncertainties will be incorrect."
            )
            configuration.fit.fitweight = 0
