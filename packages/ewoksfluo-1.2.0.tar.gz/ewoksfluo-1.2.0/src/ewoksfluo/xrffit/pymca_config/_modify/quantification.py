import logging
from typing import Dict

from ..model import PyMcaXrfConfiguration
from .matrix import ensure_matrix

logger = logging.getLogger(__name__)


def enable_quantification(
    configuration: PyMcaXrfConfiguration, quantification: Dict[str, float]
):
    concentrations = configuration.concentrations
    attenuators = configuration.attenuator_views
    matrix = attenuators["Matrix"]

    if "flux" in quantification:
        concentrations.flux = quantification["flux"]
        logger.warning(
            "PyMca configuration: set flux to %e photons/s", concentrations.flux
        )

    if "time" in quantification:
        concentrations.time = quantification["time"]
        logger.warning(
            "PyMca configuration: set effective measurment time to %f s",
            concentrations.time,
        )

    if "area" in quantification:
        concentrations.area = quantification["area"]
        logger.warning(
            "PyMca configuration: set active detector area to %f cm^2",
            concentrations.area,
        )

    if "distance" in quantification:
        concentrations.distance = quantification["distance"]
        logger.warning(
            "PyMca configuration: set sample-detector distance to %f cm",
            concentrations.distance,
        )

    ensure_matrix(configuration)

    if "anglein" in quantification:
        matrix.incidence_angle = quantification["anglein"]
        logger.warning(
            "PyMca configuration: set incident angle to %f degrees",
            concentrations.incidence_angle,
        )

    if "angleout" in quantification:
        matrix.exit_angle = quantification["angleout"]
        logger.warning(
            "PyMca configuration: set exit angle to %f degrees",
            concentrations.exit_angle,
        )

    if "anglein" in quantification and "angleout" in quantification:
        matrix.scattering_angle = quantification["anglein"] + quantification["angleout"]
        logger.warning(
            "PyMca configuration: set scattering angle to %f degrees",
            concentrations.scattering_angle,
        )
