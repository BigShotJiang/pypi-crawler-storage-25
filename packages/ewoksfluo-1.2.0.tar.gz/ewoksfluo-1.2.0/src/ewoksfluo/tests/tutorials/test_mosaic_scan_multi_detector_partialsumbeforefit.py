from typing import Any
from typing import Dict
from typing import List
from typing import Tuple

from . import assert_results
from . import expected_results


def test_mosaic_scan_multi_detector_partialsumbeforefit_without_qt(tmp_path):
    assert_results.assert_without_qt(
        "mosaic_mesh_multi_detector_partialsumbeforefit.ows",
        get_inputs(tmp_path),
        get_expected_outputs(tmp_path),
        get_expected_hdf5(tmp_path),
    )


def test_mosaic_scan_multi_detector_partialsumbeforefit_with_qt(
    ewoks_orange_canvas, tmp_path
):
    assert_results.assert_with_qt(
        ewoks_orange_canvas,
        "mosaic_mesh_multi_detector_partialsumbeforefit.ows",
        get_inputs(tmp_path),
        get_expected_outputs(tmp_path),
        get_expected_hdf5(tmp_path),
    )


def get_inputs(tmp_path) -> List[Dict[str, Any]]:
    return [
        {
            "label": "Mosaic Mesh (multi detector groups)",
            "name": "output_filename",
            "value": str(tmp_path / "input.h5"),
        },
        {
            "label": "Concat BLISS scans",
            "name": "bliss_scan_uri",
            "value": str(tmp_path / "concat.h5::/1.1"),
        },
        {
            "label": "Partial Sum Spectra",
            "name": "output_root_uri",
            "value": str(tmp_path / "output.h5::/1.1"),
        },
    ]


def get_expected_outputs(tmp_path) -> Dict[str, Dict[str, Any]]:
    bliss_scan_uri = str(tmp_path / "output.h5::/1.1")
    output_root_uri = str(tmp_path / "output.h5::/1.1")
    return {
        "Mosaic Mesh (multi detector groups)": {
            "config": str(tmp_path / "input.h5::/1.1/theory/configuration/data"),
            "configs": [str(tmp_path / "input.h5::/1.1/theory/configuration/data")] * 2,
            "detector_groups": {
                "mcasum0": ["mca0", "mca1"],
                "mcasum1": ["mca2", "mca3"],
            },
            "detector_normalization_template": "0.1/<instrument/{}/live_time>",
            "expo_time": 0.1,
            "filenames": [str(tmp_path / "input.h5")],
            "monitor_name": "I0",
            "monitor_normalization_template": "1000000/<instrument/{}/data>",
            "scan_ranges": [(1, 6)],
        },
        "Pick scans": {
            "bliss_scan_uris": [
                str(tmp_path / f"input.h5::/{i+1}.1") for i in range(6)
            ],
        },
        "Concat BLISS scans": {
            "bliss_scan_uri": str(tmp_path / "concat.h5::/1.1"),
        },
        "Partial Sum Spectra": {
            "detector_names": ["mcasum0", "mcasum1"],
            "bliss_scan_uri": bliss_scan_uri,
            "xrf_spectra_uri_template": "instrument/{}/data",
            "output_root_uri": output_root_uri,
            "output_root_group": None,
        },
        "Fit scan (multi detector)": {
            "bliss_scan_uri": bliss_scan_uri,
            "detector_names": ["mcasum0", "mcasum1"],
            "output_root_uri": output_root_uri,
            "output_root_group": None,
            "xrf_results_uris": [
                str(tmp_path / "output.h5::/1.1/fit/mcasum0/results"),
                str(tmp_path / "output.h5::/1.1/fit/mcasum1/results"),
            ],
        },
        "Sum Fit Results": {
            "xrf_results_uri": str(tmp_path / "output.h5::/1.1/sum/results"),
            "bliss_scan_uri": bliss_scan_uri,
            "output_root_uri": output_root_uri,
            "output_root_group": None,
        },
        "Normalize": {
            "bliss_scan_uri": bliss_scan_uri,
            "output_root_uri": output_root_uri,
            "output_root_group": None,
            "xrf_results_uri": str(tmp_path / "output.h5::/1.1/norm/results"),
        },
        "Raw Counters": {
            "bliss_scan_uri": bliss_scan_uri,
            "output_root_uri": output_root_uri,
            "output_root_group": None,
            "xrf_results_uri": str(tmp_path / "output.h5::/1.1/merge/results"),
        },
        "Regrid": {
            "bliss_scan_uri": bliss_scan_uri,
            "output_root_uri": output_root_uri,
            "output_root_group": None,
            "xrf_results_uri": str(tmp_path / "output.h5::/1.1/regrid/results"),
        },
    }


def get_expected_hdf5(tmp_path) -> Tuple[str, Dict[str, Any]]:
    output_path = tmp_path / "output.h5"
    datatype = expected_results.DataType(
        nmca=4,
        nmcasum=2,
        nscans=1,
        ndim0=54,
        ndim1=64,
        mosaic=True,
        partial_mca_sum=True,
    )
    expected = expected_results.build_expected(datatype)
    return output_path, expected
