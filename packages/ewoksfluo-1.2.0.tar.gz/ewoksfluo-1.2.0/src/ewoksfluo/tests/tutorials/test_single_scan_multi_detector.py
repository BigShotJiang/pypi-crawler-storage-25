from typing import Any
from typing import Dict
from typing import List
from typing import Tuple

from . import assert_results
from . import expected_results


def test_single_scan_multi_detector_without_qt(tmp_path):
    assert_results.assert_without_qt(
        "mesh_single_scan_multi_detector.ows",
        get_inputs(tmp_path),
        get_expected_outputs(tmp_path),
        get_expected_hdf5(tmp_path),
    )


def test_single_scan_multi_detector_with_qt(ewoks_orange_canvas, tmp_path):
    assert_results.assert_with_qt(
        ewoks_orange_canvas,
        "mesh_single_scan_multi_detector.ows",
        get_inputs(tmp_path),
        get_expected_outputs(tmp_path),
        get_expected_hdf5(tmp_path),
    )


def get_inputs(tmp_path) -> List[Dict[str, Any]]:
    return [
        {
            "label": "Mesh (multi detector)",
            "name": "output_filename",
            "value": str(tmp_path / "input.h5"),
        },
        {
            "label": "Fit scan (multi detector)",
            "name": "output_root_uri",
            "value": str(tmp_path / "output.h5::/1.1"),
        },
    ]


def get_expected_outputs(tmp_path) -> Dict[str, Dict[str, Any]]:
    bliss_scan_uri = str(tmp_path / "input.h5::/1.1")
    output_root_uri = str(tmp_path / "output.h5::/1.1")
    return {
        "Mesh (multi detector)": {
            "config": str(tmp_path / "input.h5::/1.1/theory/configuration/data"),
            "configs": [str(tmp_path / "input.h5::/1.1/theory/configuration/data")] * 2,
            "detector_names": ["mca0", "mca1"],
            "expo_time": 0.1,
            "filename": str(tmp_path / "input.h5"),
            "monitor_name": "I0",
            "monitor_normalization_template": "1000000/<instrument/{}/data>",
            "detector_normalization_template": "0.1/<instrument/{}/live_time>",
            "scan_number": 1,
        },
        "Pick scan": {"bliss_scan_uri": bliss_scan_uri},
        "Fit scan (multi detector)": {
            "xrf_results_uris": [
                str(tmp_path / "output.h5::/1.1/fit/mca0/results"),
                str(tmp_path / "output.h5::/1.1/fit/mca1/results"),
            ],
            "bliss_scan_uri": bliss_scan_uri,
            "detector_names": ["mca0", "mca1"],
            "output_root_uri": output_root_uri,
            "output_root_group": None,
        },
        "Sum Fit Results": {
            "xrf_results_uri": str(tmp_path / "output.h5::/1.1/sum/results"),
            "bliss_scan_uri": bliss_scan_uri,
            "output_root_uri": output_root_uri,
            "output_root_group": None,
        },
        "Normalize": {
            "xrf_results_uri": str(tmp_path / "output.h5::/1.1/norm/results"),
            "bliss_scan_uri": bliss_scan_uri,
            "output_root_uri": output_root_uri,
            "output_root_group": None,
        },
        "Raw Counters": {
            "xrf_results_uri": str(tmp_path / "output.h5::/1.1/merge/results"),
            "bliss_scan_uri": bliss_scan_uri,
            "output_root_uri": output_root_uri,
            "output_root_group": None,
        },
        "Regrid": {
            "xrf_results_uri": str(tmp_path / "output.h5::/1.1/regrid/results"),
            "bliss_scan_uri": bliss_scan_uri,
            "output_root_uri": output_root_uri,
            "output_root_group": None,
        },
    }


def get_expected_hdf5(tmp_path) -> Tuple[str, Dict[str, Any]]:
    output_path = tmp_path / "output.h5"
    datatype = expected_results.DataType(
        nmca=2,
        nmcasum=0,
        nscans=1,
        ndim0=55,
        ndim1=66,
        mosaic=False,
        partial_mca_sum=False,
    )
    expected = expected_results.build_expected(datatype)
    return output_path, expected
