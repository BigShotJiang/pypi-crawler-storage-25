from typing import Any
from typing import Dict
from typing import List
from typing import Tuple

from . import assert_results
from . import expected_results


def test_single_scan_multi_detector_partialsumbeforefit_without_qt(tmp_path):
    assert_results.assert_without_qt(
        "mesh_single_scan_multi_detector_partialsumbeforefit.ows",
        get_inputs(tmp_path),
        get_expected_outputs(tmp_path),
        get_expected_hdf5(tmp_path),
    )


def test_single_scan_multi_detector_partialsumbeforefit_with_qt(
    ewoks_orange_canvas, tmp_path
):
    assert_results.assert_with_qt(
        ewoks_orange_canvas,
        "mesh_single_scan_multi_detector_partialsumbeforefit.ows",
        get_inputs(tmp_path),
        get_expected_outputs(tmp_path),
        get_expected_hdf5(tmp_path),
    )


def get_inputs(tmp_path) -> List[Dict[str, Any]]:
    return [
        {
            "label": "Mesh (multi detector groups)",
            "name": "output_filename",
            "value": str(tmp_path / "input.h5"),
        },
        {
            "label": "Partial Sum Spectra",
            "name": "output_root_uri",
            "value": str(tmp_path / "output.h5"),
        },
    ]


def get_expected_outputs(tmp_path) -> Dict[str, Dict[str, Any]]:
    bliss_scan_uri = str(tmp_path / "output.h5::/1.1")
    output_root_uri = str(tmp_path / "output.h5::/1.1")
    return {
        "Mesh (multi detector groups)": {
            "config": str(tmp_path / "input.h5::/1.1/theory/configuration/data"),
            "configs": [str(tmp_path / "input.h5::/1.1/theory/configuration/data")] * 2,
            "detector_groups": {
                "mcasum0": ["mca0", "mca1"],
                "mcasum1": ["mca2", "mca3"],
            },
            "expo_time": 0.1,
            "filename": str(tmp_path / "input.h5"),
            "monitor_name": "I0",
            "monitor_normalization_template": "1000000/<instrument/{}/data>",
            "detector_normalization_template": "0.1/<instrument/{}/live_time>",
            "scan_number": 1,
        },
        "Pick scan": {"bliss_scan_uri": str(tmp_path / "input.h5::/1.1")},
        "Partial Sum Spectra": {
            "detector_names": ["mcasum0", "mcasum1"],
            "bliss_scan_uri": bliss_scan_uri,
            "xrf_spectra_uri_template": "instrument/{}/data",
            "output_root_uri": output_root_uri,
            "output_root_group": None,
        },
        "Fit scan (multi detector)": {
            "detector_names": ["mcasum0", "mcasum1"],
            "xrf_results_uris": [
                str(tmp_path / "output.h5::/1.1/fit/mcasum0/results"),
                str(tmp_path / "output.h5::/1.1/fit/mcasum1/results"),
            ],
            "bliss_scan_uri": bliss_scan_uri,
            "output_root_uri": output_root_uri,
            "output_root_group": None,
        },
        "Sum Fit Results": {
            "xrf_results_uri": str(tmp_path / "output.h5::/1.1/sum/results"),
            "bliss_scan_uri": bliss_scan_uri,
            "output_root_uri": output_root_uri,
            "output_root_group": None,
        },
        "Normalize": {
            "xrf_results_uri": str(tmp_path / "output.h5::/1.1/norm/results"),
            "bliss_scan_uri": bliss_scan_uri,
            "output_root_uri": output_root_uri,
            "output_root_group": None,
        },
        "Raw Counters": {
            "xrf_results_uri": str(tmp_path / "output.h5::/1.1/merge/results"),
            "bliss_scan_uri": bliss_scan_uri,
            "output_root_uri": output_root_uri,
            "output_root_group": None,
        },
        "Regrid": {
            "xrf_results_uri": str(tmp_path / "output.h5::/1.1/regrid/results"),
            "bliss_scan_uri": bliss_scan_uri,
            "output_root_uri": output_root_uri,
            "output_root_group": None,
        },
    }


def get_expected_hdf5(tmp_path) -> Tuple[str, Dict[str, Any]]:
    output_path = tmp_path / "output.h5"
    datatype = expected_results.DataType(
        nmca=4,
        nmcasum=2,
        nscans=1,
        ndim0=55,
        ndim1=66,
        mosaic=False,
        partial_mca_sum=True,
    )
    expected = expected_results.build_expected(datatype)
    return output_path, expected
