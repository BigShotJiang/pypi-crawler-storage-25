"""``fruxon agents`` — browse, inspect, and test agents from the terminal.

Solves the discovery problem: without this, a new user has nothing to
type for ``fruxon run <agent>`` short of opening the dashboard. The
``list`` subcommand surfaces every agent in the org; ``get`` drills
into one for the details a CLI user typically wants (display name,
description, deployed revision, tags); ``test`` runs a *draft* flow
definition against an existing agent without publishing it — the
"validate before you ship" loop, scriptable for CI.
"""

from __future__ import annotations

import json
from typing import Annotated

import typer

from fruxon.cli import app
from fruxon.cli._shared import build_client, load_json_body, print_connect_nudge
from fruxon.exceptions import FruxonError
from fruxon.fruxon import Agent, FruxonClient
from fruxon.ui import (
    dashboard_url,
    print_banner,
    resolve_output_format,
    say_err,
    say_info,
    say_ok,
    stderr,
)

agents_app = typer.Typer(
    help="Browse and inspect agents in your org.",
    no_args_is_help=True,
)
app.add_typer(agents_app, name="agents")


# ─────────────────────────────────────────────────────────────────────────────
# list
# ─────────────────────────────────────────────────────────────────────────────


@agents_app.command("list")
def agents_list(
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    api_key: Annotated[
        str | None,
        typer.Option("--api-key", "-k", envvar="FRUXON_API_KEY", help="API key override."),
    ] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option(
            "--output",
            "-o",
            help=(
                "Output format: table (default for humans), json (machines, default in "
                "agent mode), id (one ID per line, pipe-safe). Under FRUXON_AGENT_MODE / "
                "CLAUDECODE / CI the implicit default flips to json."
            ),
        ),
    ] = None,
    disabled: Annotated[
        bool,
        typer.Option(
            "--all",
            help="Include disabled agents (default: only enabled ones).",
        ),
    ] = False,
):
    """List every agent in your org.

    Defaults to a human-readable table. Use ``--output id`` for pipe-safe
    one-ID-per-line output (good for shell loops); ``--output json`` for
    machine consumption with the full agent payload we expose.

    Examples:
        fruxon agents list
        fruxon agents list --output json
        fruxon agents list --output id | xargs -n1 fruxon run
    """
    output = resolve_output_format(output, human_default="table", agent_default="json")
    if output not in {"table", "json", "id"}:
        say_err(
            f"Unknown output format: [bold]{output}[/bold]",
            hint="Valid formats: table, json, id.",
        )
        raise typer.Exit(code=1)

    client = build_client(org, api_key, base_url)

    # Spinner only when stderr is interactive — keeps CI logs and pipe
    # captures noise-free.
    try:
        if stderr.is_terminal and output != "id":
            with stderr.status("[bold]Fetching agents…[/bold]"):
                agents = client.list_agents()
        else:
            agents = client.list_agents()
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_list_error(e))
        raise typer.Exit(code=1) from e

    # Distinguish the two "empty" cases so the hint actually fits the
    # situation. A first-time user with zero agents in their org needs
    # to be pointed at the dashboard; a user whose agents are all
    # disabled needs to know ``--all`` exists. Same flat "No agents
    # to show" message used to swallow both — useless in both cases.
    all_agents = agents
    visible_agents = all_agents if disabled else [a for a in all_agents if a.enabled]

    if not visible_agents:
        if not all_agents:
            # Truly empty org — onboarding moment, not a filter quirk.
            # JSON callers get an empty array (already returned above
            # in the output branches below) so this say_info is purely
            # for the human-facing path.
            if output == "json":
                print("[]")
                return
            if output == "id":
                return
            say_info(
                "No agents deployed in this org yet.",
                hint=f"Create one in the dashboard: [link]{dashboard_url()}[/link]",
            )
            return
        # Some agents exist but every one is disabled.
        if output == "json":
            print("[]")
            return
        if output == "id":
            return
        say_info(
            "All agents in this org are disabled.",
            hint="Use [bold]--all[/bold] to include disabled agents.",
        )
        return

    agents = visible_agents

    if output == "id":
        # One ID per line on stdout for trivial shell composition.
        for a in agents:
            print(a.id)
        return

    if output == "json":
        print(json.dumps([_agent_to_dict(a) for a in agents], indent=2))
        return

    if stderr.is_terminal:
        print_banner(subtitle=f"agents · {len(agents)}")
    stderr.print()
    stderr.print(_build_table(agents))


@agents_app.command("get")
def agents_get(
    agent: Annotated[str, typer.Argument(help="Agent identifier to fetch.")],
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    api_key: Annotated[
        str | None,
        typer.Option("--api-key", "-k", envvar="FRUXON_API_KEY", help="API key override."),
    ] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option(
            "--output",
            "-o",
            help=(
                "Output format: text (default for humans), json (machines, default in "
                "agent mode). Under FRUXON_AGENT_MODE / CLAUDECODE / CI the implicit "
                "default flips to json."
            ),
        ),
    ] = None,
):
    """Show one agent's details.

    Examples:
        fruxon agents get support-agent
        fruxon agents get support-agent --output json
    """
    output = resolve_output_format(output, human_default="text", agent_default="json")
    if output not in {"text", "json"}:
        say_err(
            f"Unknown output format: [bold]{output}[/bold]",
            hint="Valid formats: text, json.",
        )
        raise typer.Exit(code=1)

    client = build_client(org, api_key, base_url)

    try:
        if stderr.is_terminal and output == "text":
            with stderr.status(f"[bold]Fetching agent [cyan]{agent}[/cyan]…[/bold]"):
                fetched = client.get_agent(agent)
                parameters = _fetch_parameters_safely(client, fetched)
        else:
            fetched = client.get_agent(agent)
            parameters = _fetch_parameters_safely(client, fetched)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_get_error(e, agent, client))
        raise typer.Exit(code=1) from e

    if output == "json":
        payload = _agent_to_dict(fetched)
        payload["parameters"] = parameters
        print(json.dumps(payload, indent=2))
        return

    if stderr.is_terminal:
        print_banner(subtitle=f"agent · {fetched.id}")
    stderr.print()
    say_ok(f"[bold]{fetched.display_name or fetched.id}[/bold]")
    if fetched.description:
        stderr.print(f"     [dim]{fetched.description}[/dim]")
    stderr.print()
    _say_kv("id", fetched.id)
    # A current_revision of 0 means "no published revision" — surfacing it
    # as the literal "0" confuses newcomers (they think revision zero is
    # deployed). Render it as ``(none)`` with a hint instead.
    rev_label = (
        str(fetched.current_revision) if fetched.current_revision else "[yellow](none)[/yellow] · not yet deployed"
    )
    _say_kv("revision", rev_label)
    _say_kv("enabled", "yes" if fetched.enabled else "no")
    if fetched.tags:
        _say_kv("tags", ", ".join(fetched.tags))

    # Input parameters: the single most useful piece of info before running
    # an agent. Without this users have to fail a request to learn the right
    # key names. Empty/missing list is fine — some agents take no params.
    if parameters:
        _say_kv("parameters", ", ".join(parameters))
        stderr.print()
        stderr.print(
            f"     [dim]Run with:[/dim] fruxon run [bold]{fetched.id}[/bold] "
            f"{' '.join(f'-p {p}=…' for p in parameters)}"
        )
    elif not fetched.current_revision:
        # No deployed revision → `fruxon run` would 404 with a confusing
        # message. Tell the user up-front rather than letting them
        # discover it the hard way.
        stderr.print()
        stderr.print(
            "     [dim]This agent has no deployed revision — "
            "[bold]fruxon run[/bold] will fail until one is published.[/dim]"
        )


@agents_app.command("test")
def agents_test(
    agent: Annotated[str, typer.Argument(help="Agent identifier the draft belongs to.")],
    file: Annotated[
        str | None,
        typer.Option(
            "--file",
            "-f",
            help="Draft definition JSON (an AgentTestRequest body). Pass `-` to read from stdin.",
        ),
    ] = None,
    schema: Annotated[
        bool,
        typer.Option(
            "--schema",
            help=(
                "Print the JSON schema for --file (AgentTestRequest) and exit. "
                "No request is made. Pipe to an LLM or save for reference."
            ),
        ),
    ] = False,
    param: Annotated[
        list[str] | None,
        typer.Option(
            "--param",
            "-p",
            help=(
                "Runtime parameter — `key=value` (string) or `key:=42` (typed JSON). "
                "Repeatable. Overlays the file's parameters."
            ),
        ),
    ] = None,
    base_revision: Annotated[
        int | None,
        typer.Option(
            "--base-revision",
            help=(
                "Revision the draft is based on — masked secrets resolve from its stored "
                "configs. Overrides the file; defaults to the agent's current revision."
            ),
        ),
    ] = None,
    session_id: Annotated[
        str | None,
        typer.Option("--session", "-s", help="Session ID for multi-turn continuity."),
    ] = None,
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    api_key: Annotated[
        str | None,
        typer.Option("--api-key", "-k", envvar="FRUXON_API_KEY", help="API key override."),
    ] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    stream: Annotated[
        bool,
        typer.Option(
            "--stream/--no-stream",
            help=(
                "Stream the run as it happens (default). --no-stream waits for the full "
                "result; implied by --output json/table."
            ),
        ),
    ] = True,
    output: Annotated[
        str | None,
        typer.Option(
            "--output",
            "-o",
            help="Output format: text (default), json, table. json/table imply --no-stream.",
        ),
    ] = None,
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="Expand tool calls in the streaming view (full args + results)."),
    ] = False,
):
    """Run a draft flow against an existing agent without publishing it.

    This is the "validate before you ship" loop. ``--file`` is a draft
    agent definition — an ``AgentTestRequest`` JSON body carrying the
    candidate ``flow`` plus its ``subAgents``, ``assets``,
    ``integrationConfigs``, ``llmConfigs``, and ``baseRevision``. The
    ``agent`` argument scopes the run to an existing agent: it gates
    Editor access and resolves masked secrets from the base revision's
    stored configs.

    The result is identical in shape to ``fruxon run`` — same streaming
    view, same ``--output`` formats, same duration/cost/record footer —
    because ``:test`` returns the same envelope as ``:execute``. The
    only difference is *what* runs: a draft from a file, not the
    deployed revision.

    Keep the definition file in your repo and this becomes a CI gate:
    exit code is 0 on success, non-zero on failure.

    Examples:
        fruxon agents test my-agent --file ./agent.json -p query="hello"
        fruxon agents test my-agent --file ./agent.json --no-stream -o json
        cat agent.json | fruxon agents test my-agent --file -

    Procedural guide:
        fruxon skills show fruxon-build-agent       # how to author the flow
        fruxon skills show fruxon-debug-revision    # if validation fails
    """
    from fruxon.cli._schema import print_schema
    from fruxon.cli.run import _hint_for_run_error, _render_sync_result, _run_stream
    from fruxon.output import FORMATS
    from fruxon.params import ParamError
    from fruxon.params import parse as parse_params

    # --schema short-circuits before any auth or file IO: it just prints
    # the AgentTestRequest JSON schema (sourced from the live OpenAPI
    # spec) so a caller — usually an LLM — can author a valid --file body.
    if schema:
        print_schema("AgentTestRequest", base_url=base_url)
        return

    if not file:
        say_err(
            "Missing required option [bold]--file[/bold].",
            hint="Pass a path to an AgentTestRequest JSON file, or [bold]--schema[/bold] to see the shape.",
        )
        raise typer.Exit(code=1)

    output = resolve_output_format(output, human_default="text", agent_default="json")
    if output not in FORMATS:
        say_err(
            f"Unknown output format: [bold]{output}[/bold]",
            hint=f"Valid formats: {', '.join(FORMATS)}.",
        )
        raise typer.Exit(code=1)
    # json/table need the full result envelope — silently drop streaming
    # rather than making the user also type --no-stream (same rule as run).
    if output != "text":
        stream = False

    # Load the draft definition. ``-`` reads stdin so the file can be
    # piped (`cat agent.json | fruxon agents test … --file -`).
    request = load_json_body(file, what="an AgentTestRequest object (flow, subAgents, configs, …)")

    # Overlay runtime parameters from -p onto whatever the file carries.
    # CLI flags win — the file holds the draft *shape*, -p holds the
    # inputs for this particular run.
    try:
        flag_params = parse_params(flag_values=param, params_file=None, stdin_input=False)
    except ParamError as exc:
        say_err(str(exc), hint="Run [bold]fruxon agents test --help[/bold] for accepted parameter forms.")
        raise typer.Exit(code=1) from exc
    if flag_params:
        merged = dict(request.get("parameters") or {})
        merged.update(flag_params)
        request["parameters"] = merged

    if base_revision is not None:
        request["baseRevision"] = base_revision
    if session_id is not None:
        request["sessionId"] = session_id

    client = build_client(org, api_key, base_url)

    if stderr.is_terminal:
        print_banner(subtitle=f"test · {agent}")

    if stream:
        _run_stream(
            lambda: client.stream_test(agent, request),
            agent=agent,
            client=client,
            verbose=verbose,
        )
        return

    with stderr.status(f"[bold]Testing draft against [cyan]{agent}[/cyan]…[/bold]"):
        try:
            result = client.test(agent, request)
        except FruxonError as e:
            say_err(str(e), hint=_hint_for_run_error(e, agent=agent, client=client))
            raise typer.Exit(code=1) from e

    _render_sync_result(result, output, agent=agent)


def _fetch_parameters_safely(client: FruxonClient, fetched: Agent) -> list[str]:
    """Fetch the deployed revision's parameter names, swallowing errors.

    A failure here (no revision deployed, server returns 404 on the
    parameters endpoint, …) shouldn't tank the whole ``agents get`` —
    the agent metadata is still useful on its own. Returning an empty
    list lets the rendering path skip the parameters row gracefully.
    """
    if not fetched.current_revision:
        return []
    try:
        return client.get_agent_parameters(fetched.id, fetched.current_revision)
    except FruxonError:
        return []


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────


def _build_table(agents: list[Agent]):
    """Render an agent list as a rich Table.

    Column shape is tuned for readability across terminal widths:

    * **ID** — the must-have. ``no_wrap=True`` keeps each row on one
      line; long IDs truncate with ``…`` rather than wrapping into
      multi-line entries that destroy scannability.
    * **Name** — wraps with ellipsis overflow if needed.
    * **Status** — fixed-width, near the ID so it stays visible even
      when narrow widths force right-side columns to shrink.
    * **Rev** — small right-aligned column.
    * **Tags** — last because it's the first column to truncate.
      Hard-capped at 24 chars; previously wrapped into 4+ line entries
      on agents with many tags, which made the table unreadable.

    Imported lazily so callers that don't render a table (``--output id``,
    ``--output json``) don't pay for the Table machinery.
    """
    from rich.table import Table

    table = Table(
        show_header=True,
        header_style="bold",
        show_edge=False,
        pad_edge=False,
        box=None,
        # ``padding=(0, 1)`` gives one column of gap between cells.
        # With 5 columns the inter-cell gaps consume 4 chars total,
        # leaving more room for content on narrow terminals (80 col
        # ssh sessions, tmux panes, etc.) before Rich starts
        # shrinking columns into ``…``.
        padding=(0, 1),
    )
    # ``no_wrap=True`` on every column forces single-line-per-row.
    # Combined with ``overflow="ellipsis"`` Rich truncates cells that
    # overflow the column width with ``…`` instead of wrapping —
    # critical for table scannability when an agent has many tags or
    # a long display name.
    #
    # Status and Rev sit right after ID (the eye-tracking priority)
    # and use ``no_wrap`` without a max so they always render in
    # full. ID / Name / Tags carry ``max_width`` to bound how much
    # space each grabs on a wide terminal and to anchor the
    # ellipsis-truncation point on narrow ones. Old layout used to
    # let Tags steal the row and wrap across 8 lines for agents with
    # many tags.
    table.add_column("ID", style="bold", no_wrap=True, overflow="ellipsis", max_width=24)
    table.add_column("Status", justify="right", no_wrap=True)
    # ``Rev`` doubles as the runnability indicator: ``fruxon run`` needs a
    # deployed revision, so an agent showing ``(none)`` here will 404. We
    # render that case in yellow + italic so the eye can scan a long list
    # and spot which agents are draft-only without opening each one.
    table.add_column("Rev", justify="right", style="dim", no_wrap=True)
    table.add_column("Name", no_wrap=True, overflow="ellipsis", max_width=20)
    table.add_column("Tags", style="dim", no_wrap=True, overflow="ellipsis", max_width=22)

    for a in agents:
        status = "[green]enabled[/green]" if a.enabled else "[dim]disabled[/dim]"
        rev = str(a.current_revision) if a.current_revision else "[yellow](none)[/yellow]"
        # Empty-tag cell renders blank rather than ``—`` — visually
        # collides with the "no revision" placeholder otherwise.
        tags = ", ".join(a.tags) if a.tags else ""
        table.add_row(a.id, status, rev, a.display_name or "", tags)
    return table


def _agent_to_dict(agent: Agent) -> dict:
    """Serialize the SDK Agent for ``--output json``. camelCase keys to match
    the underlying API payload — easier for callers piping into ``jq``."""
    return {
        "id": agent.id,
        "displayName": agent.display_name,
        "description": agent.description,
        "enabled": agent.enabled,
        "currentRevision": agent.current_revision,
        "tags": agent.tags,
    }


def _say_kv(key: str, value: str) -> None:
    """Two-column key/value line in the same style as the rest of the chrome."""
    stderr.print(f"     [dim]{key:<10}[/dim] {value}")


def _hint_for_write_error(error: FruxonError) -> str | None:
    """Hint generator for the agent-build / revision write commands.

    Validation failures (400/422) on `agents create` / `revisions create`
    / `revisions deploy` are exactly the moment the LLM author is most
    receptive to procedural guidance — they hit something they didn't
    expect, and the *next* thing they do is search for a way out. Point
    them at the skill that solves their class of error rather than
    leaving them to grep docs.
    """
    from fruxon.exceptions import AuthenticationError, ForbiddenError, ValidationError

    if isinstance(error, ValidationError):
        return (
            "Diagnose with: [bold]fruxon skills show fruxon-debug-revision[/bold]\n"
            "Inspect the request body — invalid parameters or missing required fields."
        )
    if isinstance(error, AuthenticationError):
        return "Run [bold]fruxon whoami[/bold] to confirm your key, then [bold]fruxon login[/bold] to refresh."
    if isinstance(error, ForbiddenError):
        return "Your key doesn't have write access to this org. Confirm with [bold]fruxon whoami[/bold]."
    return None


def _hint_for_list_error(error: FruxonError) -> str | None:
    from fruxon.exceptions import AuthenticationError, ForbiddenError

    if isinstance(error, AuthenticationError):
        return (
            "Run [bold]fruxon whoami[/bold] to confirm which key is in play, then [bold]fruxon login[/bold] to refresh."
        )
    if isinstance(error, ForbiddenError):
        return "Your key doesn't grant access to this org. Confirm with [bold]fruxon whoami[/bold]."
    return None


def _hint_for_get_error(error: FruxonError, agent: str, client: FruxonClient) -> str | None:
    """Hint generator for ``agents get``.

    NotFound is the high-traffic case — typos in agent IDs are common.
    We fetch the org's agent list and use ``difflib.get_close_matches``
    to surface a "did you mean?" suggestion. Network errors during
    that lookup are swallowed: the user is already in an error path
    and a second failure on top would be hostile.
    """
    from fruxon.exceptions import NotFoundError

    if isinstance(error, NotFoundError):
        import difflib

        try:
            candidates = [a.id for a in client.list_agents()]
            suggestions = difflib.get_close_matches(agent, candidates, n=1, cutoff=0.6)
        except Exception:
            suggestions = []
        if suggestions:
            return (
                f"Did you mean [bold]{suggestions[0]}[/bold]?  "
                f"Run with: [bold]fruxon agents get {suggestions[0]}[/bold]"
            )
        return (
            f"No agent matches [bold]{agent}[/bold] in this org. "
            "Try [bold]fruxon agents list[/bold] to see what's available."
        )
    return _hint_for_list_error(error)


# ─────────────────────────────────────────────────────────────────────────────
# create — provision a new agent shell
# ─────────────────────────────────────────────────────────────────────────────


@agents_app.command("create")
def agents_create(
    file: Annotated[
        str | None,
        typer.Option("--file", "-f", help="CreateAgent JSON body. `-` reads stdin."),
    ] = None,
    schema: Annotated[
        bool,
        typer.Option("--schema", help="Print the JSON schema for --file (CreateAgent) and exit."),
    ] = False,
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    api_key: Annotated[
        str | None,
        typer.Option("--api-key", "-k", envvar="FRUXON_API_KEY", help="API key override."),
    ] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option("--output", "-o", help="Output format: text (default), json."),
    ] = None,
):
    """Create a new agent shell from a JSON definition.

    `--file` is a CreateAgent body: `id`, `displayName`, `description`,
    `type`, optional `tags`/`avatarFileId`. The agent starts with no
    deployed revision — wire one with `fruxon agents revisions create`.

    Examples:
        fruxon agents create --file ./agent.json
        fruxon agents create --schema > schema.json

    Procedural guide:
        fruxon skills show fruxon-build-agent
    """
    from fruxon.cli._schema import print_schema

    if schema:
        print_schema("CreateAgent", base_url=base_url)
        return
    if not file:
        say_err(
            "Missing required option [bold]--file[/bold].",
            hint="Pass a JSON file, or [bold]--schema[/bold] to see the shape.",
        )
        raise typer.Exit(code=1)

    output = resolve_output_format(output, human_default="text", agent_default="json")
    body = load_json_body(file, what="a CreateAgent object (id, displayName, type, …)")
    client = build_client(org, api_key, base_url)
    try:
        result = client.create_agent(body)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_write_error(e))
        raise typer.Exit(code=1) from e

    if output == "json":
        print(json.dumps(result, indent=2))
        return
    agent_id = result.get("id") if isinstance(result, dict) else None
    say_ok(f"Created agent [bold]{agent_id}[/bold]")
    if agent_id:
        stderr.print()
        stderr.print(
            f"     [dim]Next:[/dim] fruxon agents revisions create [bold]{agent_id}[/bold] --file <revision.json>"
        )


# ─────────────────────────────────────────────────────────────────────────────
# revisions — create / deploy
# ─────────────────────────────────────────────────────────────────────────────

revisions_app = typer.Typer(
    help="Create and deploy agent revisions.",
    no_args_is_help=True,
)
agents_app.add_typer(revisions_app, name="revisions")


@revisions_app.command("create")
def revisions_create(
    agent: Annotated[str, typer.Argument(help="Agent identifier to add the revision to.")],
    file: Annotated[
        str | None,
        typer.Option("--file", "-f", help="CreateAgentRevision JSON body. `-` reads stdin."),
    ] = None,
    schema: Annotated[
        bool,
        typer.Option("--schema", help="Print the JSON schema for --file (CreateAgentRevision) and exit."),
    ] = False,
    deploy: Annotated[
        bool,
        typer.Option("--deploy", help="Deploy the revision immediately after creating it."),
    ] = False,
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    api_key: Annotated[
        str | None,
        typer.Option("--api-key", "-k", envvar="FRUXON_API_KEY", help="API key override."),
    ] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option("--output", "-o", help="Output format: text (default), json."),
    ] = None,
):
    """Create a new revision for an existing agent.

    `--file` is a CreateAgentRevision body: `flow`, `subAgents`,
    `integrationConfigs`, `llmConfigs`, `assets`, etc. Pass `--deploy`
    to flip the new revision live in the same call.

    Examples:
        fruxon agents revisions create my-agent --file ./rev.json
        fruxon agents revisions create my-agent --file ./rev.json --deploy
        fruxon agents revisions create my-agent --schema > schema.json

    Procedural guide:
        fruxon skills show fruxon-build-agent       # how to author the flow
        fruxon skills show fruxon-use-integrations  # wiring tools into a step
        fruxon skills show fruxon-debug-revision    # if validation fails
    """
    from fruxon.cli._schema import print_schema

    if schema:
        print_schema("CreateAgentRevision", base_url=base_url)
        return
    if not file:
        say_err(
            "Missing required option [bold]--file[/bold].",
            hint="Pass a JSON file, or [bold]--schema[/bold] to see the shape.",
        )
        raise typer.Exit(code=1)

    output = resolve_output_format(output, human_default="text", agent_default="json")
    body = load_json_body(file, what="a CreateAgentRevision object (flow, subAgents, configs, …)")
    client = build_client(org, api_key, base_url)
    try:
        result = client.create_revision(agent, body)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_write_error(e))
        raise typer.Exit(code=1) from e

    # The server returns the revision number under ``agentRevision``;
    # the older ``revision`` key is kept as a fallback for compatibility
    # with self-hosted backends that haven't picked up the rename.
    revision_no = None
    if isinstance(result, dict):
        revision_no = result.get("agentRevision") or result.get("revision")

    if deploy and revision_no is not None:
        try:
            client.deploy_revision(agent, revision_no)
        except FruxonError as e:
            say_err(f"Created revision {revision_no}, but deploy failed: {e}")
            raise typer.Exit(code=1) from e

    if output == "json":
        print(json.dumps(result, indent=2))
        return
    suffix = " and deployed" if deploy else ""
    say_ok(f"Created revision [bold]{revision_no}[/bold] for [bold]{agent}[/bold]{suffix}")
    if not deploy and revision_no is not None:
        stderr.print()
        stderr.print(f"     [dim]Deploy:[/dim] fruxon agents revisions deploy [bold]{agent}[/bold] {revision_no}")
    # If the revision pulls in integration configs that still need a human
    # (per-user OAuth, empty secret params, …), surface the dashboard
    # links so the user can finish setup without hunting through the UI.
    configs = result.get("integrationConfigs") if isinstance(result, dict) else None
    if isinstance(configs, list):
        print_connect_nudge(configs)


@revisions_app.command("get")
def revisions_get(
    agent: Annotated[str, typer.Argument(help="Agent identifier.")],
    revision: Annotated[
        int | None,
        typer.Argument(help="Revision number to fetch. Defaults to the agent's current deployed revision."),
    ] = None,
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    api_key: Annotated[
        str | None,
        typer.Option("--api-key", "-k", envvar="FRUXON_API_KEY", help="API key override."),
    ] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
):
    """Print a revision's full body — the seed for the next revision.

    The output is the same JSON shape `revisions create` accepts on `--file`
    (plus a few server-stamped fields like `agentRevision`, `createdAt`).
    Pipe it through `jq` and back into `revisions create` to iterate on an
    existing revision without re-authoring from scratch:

    \b
    fruxon agents revisions get my-agent \\
        | jq '{comment: "tweak prompt", flow, subAgents, integrationConfigs, llmConfigs, assets}' \\
        | fruxon agents revisions create my-agent --file - --deploy

    Examples:
        fruxon agents revisions get my-agent          # current deployed revision
        fruxon agents revisions get my-agent 3        # a specific revision
        fruxon agents revisions get my-agent | jq .flow
    """
    client = build_client(org, api_key, base_url)

    target_revision: int | str
    if revision is None:
        try:
            fetched = client.get_agent(agent)
        except FruxonError as e:
            say_err(str(e), hint=_hint_for_get_error(e, agent, client))
            raise typer.Exit(code=1) from e
        if not fetched.current_revision:
            say_err(
                f"[bold]{agent}[/bold] has no deployed revision yet.",
                hint=(
                    "Pass an explicit revision number, or create one with [bold]fruxon agents revisions create[/bold]."
                ),
            )
            raise typer.Exit(code=1)
        target_revision = fetched.current_revision
    else:
        target_revision = revision

    try:
        body = client.get_revision(agent, target_revision)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_get_error(e, agent, client))
        raise typer.Exit(code=1) from e

    # Always print JSON on stdout — this command exists to feed pipes.
    # A text view would only get in the way of the documented use case
    # (jq → create-revision).
    print(json.dumps(body, indent=2))


@revisions_app.command("deploy")
def revisions_deploy(
    agent: Annotated[str, typer.Argument(help="Agent identifier.")],
    revision: Annotated[int, typer.Argument(help="Revision number to deploy.")],
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    api_key: Annotated[
        str | None,
        typer.Option("--api-key", "-k", envvar="FRUXON_API_KEY", help="API key override."),
    ] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
):
    """Deploy a previously-created revision so `fruxon run` uses it."""
    client = build_client(org, api_key, base_url)
    try:
        client.deploy_revision(agent, revision)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_write_error(e))
        raise typer.Exit(code=1) from e
    say_ok(f"Deployed revision [bold]{revision}[/bold] of [bold]{agent}[/bold]")
