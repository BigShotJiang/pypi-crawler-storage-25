"""Fruxon CLI · entry point.

The Typer ``app`` is the singleton every command registers against. Each
command lives in its own module under ``fruxon.cli.*`` and imports the
shared ``app`` from here. Importing those modules at package load is what
binds their ``@app.command()`` decorators to ``app``.

The packaging entry point points at ``fruxon.cli:app`` (see
``pyproject.toml`` ``[project.scripts]``).
"""

from __future__ import annotations

import atexit
import json
import sys
from typing import Annotated

import typer
from typer.core import TyperGroup

from fruxon import credentials
from fruxon.ui import (
    cli_docs_url,
    dashboard_url,
    get_version,
    is_agent_mode,
    maybe_print_update_notice,
    print_banner,
    print_welcome,
    say_err,
)


class _FruxonTyperGroup(TyperGroup):
    """Branded replacement for Typer's stock ``no such command`` error.

    Click's default renders the failure as a bordered ASCII box that
    looks nothing like the rest of Fruxon's UI:

        ╭─ Error ──────────────────────────────────╮
        │ No such command 'foobar'.                │
        ╰──────────────────────────────────────────╯

    We override ``get_command`` to catch the miss before Click raises,
    print the Fruxon-styled ``✗`` line + a "did you mean?" suggestion
    via :mod:`difflib`, then exit. Same exit code (2 — Click's
    ``UsageError.exit_code``) so scripts checking ``$?`` see the same
    signal.
    """

    def get_command(self, ctx, cmd_name):
        cmd = super().get_command(ctx, cmd_name)
        if cmd is not None:
            return cmd

        # Branded error path. Build a "did you mean?" suggestion from
        # the registered subcommand names — same difflib pattern we use
        # for agent IDs so the UX feels consistent.
        import difflib

        candidates = list(self.commands.keys())
        suggestions = difflib.get_close_matches(cmd_name, candidates, n=1, cutoff=0.6)
        if suggestions:
            hint = (
                f"Did you mean [bold]fruxon {suggestions[0]}[/bold]?  "
                "Run [bold]fruxon --help[/bold] for the full command list."
            )
        else:
            hint = "Run [bold]fruxon --help[/bold] for the full command list."
        say_err(f"Unknown command [bold]{cmd_name}[/bold].", hint=hint)
        ctx.exit(2)
        return None  # unreachable but keeps the type checker happy


# Print the "newer fruxon is available" notice (if any) at the tail of
# every invocation. Registered at CLI load so it fires regardless of
# which subcommand ran, including --help and error exits. The notifier
# already swallows every exception internally — atexit handlers must
# never raise, so this is the right place.
atexit.register(maybe_print_update_notice)

app = typer.Typer(
    help="Fruxon CLI · tools for working with the Fruxon platform.",
    pretty_exceptions_enable=False,
    cls=_FruxonTyperGroup,
)


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: Annotated[
        bool,
        typer.Option("--version", "-V", help="Print the CLI version and exit."),
    ] = False,
):
    """Fruxon CLI · agent execution and platform tooling.

    Docs: https://docs.fruxon.com/guides/cli

    Credentials are resolved in this order (first non-empty wins):
      1. Explicit flags (--api-key / --org / --base-url)
      2. Environment variables (FRUXON_API_KEY / FRUXON_ORG / FRUXON_BASE_URL)
      3. The credentials file managed by `fruxon login` (~/.fruxon/credentials)

    Environment:
      FRUXON_API_KEY        Default API key for `fruxon run`.
      FRUXON_ORG            Default organization.
      FRUXON_BASE_URL       Override the API base URL (staging / self-hosted).
      FRUXON_CONFIG_DIR     Override the credentials directory (default ~/.fruxon).
      FRUXON_DASHBOARD_URL  Where `fruxon login` points the browser.
      FRUXON_DOCS_URL       Override the docs root (default https://docs.fruxon.com).
      FRUXON_CLI_DOCS_URL   Override the CLI-guide URL surfaced in the welcome screen.
      FRUXON_GLYPH          Override the brand glyph (default: ✻).
      FRUXON_BRAND_COLOR    Override the brand color (e.g. `#7c5cff`, `cyan`).
      FRUXON_NO_BANNER=1    Suppress all branding chrome.
      FRUXON_AGENT_MODE=1   Optimize for AI-agent / script consumption — no
                            banner, JSON manifest on bare invocation. Also
                            auto-detected from CLAUDECODE=1 / CI=1.
      NO_COLOR=1            Standard convention — disables all color output.
    """
    if version:
        print_banner()
        raise typer.Exit()

    if ctx.invoked_subcommand is not None:
        return

    # Bare ``fruxon`` — the highest-leverage moment in the whole UX.
    # First-run users decide whether to keep going based on what
    # appears here; AI agents pattern-match on it to decide how to
    # use the tool. We serve two surfaces from the same entrypoint:
    #
    # * Agent mode (Claude Code, CI, ``FRUXON_AGENT_MODE=1``) →
    #   single-line JSON manifest on stdout describing state +
    #   next-step commands. No banner, no chrome. An LLM reads
    #   this once and is fluent in Fruxon.
    # * Human mode → branded welcome with state-aware CTAs.
    #   Branching on signed-in vs not surfaces the right next door:
    #   first-time users see "sign in" before everything else;
    #   signed-in users see the productive paths instead.
    creds = credentials.load()
    signed_in = bool(credentials.resolve_api_key(None))

    if is_agent_mode():
        _print_agent_manifest(creds=creds, signed_in=signed_in)
        raise typer.Exit()

    _print_human_welcome(creds=creds, signed_in=signed_in)
    raise typer.Exit()


def _print_human_welcome(*, creds: credentials.StoredCredentials, signed_in: bool) -> None:
    """Branded welcome for a person sitting at the terminal.

    Tone target: Claude Code's startup card — one tagline, two
    state-aware CTAs, one universal escape hatch (``--help``).
    Deliberately NOT dumping the Typer commands table — that's
    a wall of duplicated info one keystroke away via ``--help``.
    """
    tagline = "Run, build, and orchestrate AI agents from your terminal."

    lines: list[str] = [tagline, ""]
    if signed_in:
        org_label = f"org [bold]{creds.org}[/bold]" if creds.org else "no default org"
        lines.append(f"[green]✓[/green] Signed in · {org_label}")
        lines.append("")
        lines.append("Try:   [bold]fruxon agents list[/bold]    — browse what's deployed")
        lines.append("       [bold]fruxon run[/bold] <agent>    — execute one")
        lines.append("       [bold]fruxon chat[/bold] <agent>   — open an interactive REPL")
    else:
        lines.append("[yellow]›[/yellow] Not signed in")
        lines.append("")
        lines.append("Sign in:       [bold]fruxon login[/bold]")
        lines.append(f"No account?    Visit [link]{dashboard_url()}[/link]")

    lines.append("")
    lines.append("All commands:  [bold]fruxon --help[/bold]")
    lines.append("Diagnostics:   [bold]fruxon doctor[/bold]")
    # The skill catalog is a hub — `fruxon-meet` lists every other skill in
    # its own body, so surfacing one entry point opens the whole catalog to
    # a newcomer (human or LLM) on the very first screen they see.
    lines.append("Guides:        [bold]fruxon skills show fruxon-meet[/bold]")
    # Docs link is the single best "I'm stuck, what does this do" door.
    # Put it last so it doesn't compete with the in-terminal CTAs, but
    # always present so it's one click away from the very first screen.
    lines.append(f"Docs:          [link]{cli_docs_url()}[/link]")

    print_welcome(tips=lines)


def _print_agent_manifest(*, creds: credentials.StoredCredentials, signed_in: bool) -> None:
    """One-line JSON manifest for AI agents and scripts.

    The shape is intentionally tiny and stable: name, version,
    auth state, and a ``next`` object pointing at the commands an
    LLM should reach for. The goal is "an LLM reads this once and
    knows what to do" — not a full schema dump (that's the future
    ``fruxon describe``).

    Stdout, not stderr — agents expect their parseable signal on
    stdout. JSON one-liner so it composes cleanly with ``| jq``.
    """
    manifest = {
        "name": "fruxon",
        "version": get_version(),
        "signed_in": signed_in,
        "org": creds.org if signed_in else None,
        "next": (
            {
                "agents": "fruxon agents list --output json",
                "run": "fruxon run <agent> -p key=value --output json",
                "chat": "fruxon chat <agent>",
                "trace": "fruxon trace <agent> <record-id> --output json",
                # Skills carry procedural how-to context (building agents,
                # using integrations, debugging revisions). An LLM that
                # parses this manifest discovers the catalog before it
                # makes its first real call.
                "skills": "fruxon skills list --output json",
                "help": "fruxon --help",
                "docs": cli_docs_url(),
            }
            if signed_in
            else {
                "login": "fruxon login --api-key <KEY>",
                "dashboard": dashboard_url(),
                "help": "fruxon --help",
                "docs": cli_docs_url(),
            }
        ),
    }
    sys.stdout.write(json.dumps(manifest) + "\n")
    sys.stdout.flush()


# ─────────────────────────────────────────────────────────────────────────────
# Command registration
# ─────────────────────────────────────────────────────────────────────────────
#
# Importing the command modules below executes their ``@app.command()`` and
# ``app.add_typer(...)`` calls, wiring every subcommand into the singleton
# above. The order doesn't matter for correctness — only for the order they
# show up in ``fruxon --help``.

from fruxon.cli import agents as _agents  # noqa: E402, F401
from fruxon.cli import auth as _auth  # noqa: E402, F401
from fruxon.cli import chat as _chat  # noqa: E402, F401
from fruxon.cli import config as _config  # noqa: E402, F401
from fruxon.cli import doctor as _doctor  # noqa: E402, F401
from fruxon.cli import integrations as _integrations  # noqa: E402, F401
from fruxon.cli import llm_providers as _llm_providers  # noqa: E402, F401
from fruxon.cli import run as _run  # noqa: E402, F401
from fruxon.cli import skills as _skills  # noqa: E402, F401
from fruxon.cli import tools as _tools  # noqa: E402, F401
from fruxon.cli import trace as _trace  # noqa: E402, F401

if __name__ == "__main__":
    app()
