"""``fruxon llm-providers`` — discover the LLM providers and models available
to the tenant.

When authoring an agent revision, the ``provider.providerId`` and
``provider.model`` strings are passed through to the provider's SDK
as-is — a typo lands as a runtime "unsupported model 'X' for provider
'Y'" error. The ``fruxon-build-agent`` skill explicitly tells LLM
authors not to guess model names. This command surfaces the same
information the platform uses internally, so the build loop has a
first-class CLI step for discovery instead of a raw API call.
"""

from __future__ import annotations

import json
from typing import Annotated

import typer

from fruxon.cli import app
from fruxon.cli._shared import build_client
from fruxon.exceptions import FruxonError
from fruxon.ui import print_banner, resolve_output_format, say_err, say_info, say_ok, stderr

llm_providers_app = typer.Typer(
    help="Browse the LLM providers and models available to your tenant.",
    no_args_is_help=True,
)
app.add_typer(llm_providers_app, name="llm-providers")


@llm_providers_app.command("list")
def llm_providers_list(
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    api_key: Annotated[
        str | None,
        typer.Option("--api-key", "-k", envvar="FRUXON_API_KEY", help="API key override."),
    ] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option(
            "--output",
            "-o",
            help=(
                "Output format: table (default for humans), json (machines, default in "
                "agent mode), id (one ID per line, pipe-safe)."
            ),
        ),
    ] = None,
):
    """List the LLM providers wired to this tenant.

    Examples:
        fruxon llm-providers list
        fruxon llm-providers list --output id | xargs -n1 fruxon llm-providers models
        fruxon llm-providers list --output json | jq '.[].provider.id'
    """
    output = resolve_output_format(output, human_default="table", agent_default="json")
    if output not in {"table", "json", "id"}:
        say_err(f"Unknown output format: [bold]{output}[/bold]", hint="Valid formats: table, json, id.")
        raise typer.Exit(code=1)

    client = build_client(org, api_key, base_url)
    try:
        if stderr.is_terminal and output != "id":
            with stderr.status("[bold]Fetching LLM providers…[/bold]"):
                providers = client.list_llm_providers()
        else:
            providers = client.list_llm_providers()
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e

    if not providers:
        if output == "json":
            print("[]")
            return
        if output == "id":
            return
        say_info(
            "No LLM providers are wired to this tenant.",
            hint="Configure one in the dashboard, then re-run this command.",
        )
        return

    if output == "id":
        for p in providers:
            pid = _provider_id(p)
            if pid:
                print(pid)
        return
    if output == "json":
        print(json.dumps(providers, indent=2))
        return

    if stderr.is_terminal:
        print_banner(subtitle=f"llm-providers · {len(providers)}")
    stderr.print()
    stderr.print(_build_providers_table(providers))


@llm_providers_app.command("get")
def llm_providers_get(
    provider: Annotated[str, typer.Argument(help="Provider ID (e.g. anthropic, openai).")],
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    api_key: Annotated[
        str | None,
        typer.Option("--api-key", "-k", envvar="FRUXON_API_KEY", help="API key override."),
    ] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
):
    """Print the full provider payload — provider metadata, config schema, and models.

    Always emits JSON on stdout; the payload is too rich for a useful
    text view. Use ``fruxon llm-providers models <id>`` for a pipe-safe
    model list.

    Examples:
        fruxon llm-providers get anthropic | jq '.models[].id'
        fruxon llm-providers get openai    | jq '.configMetadata'
    """
    client = build_client(org, api_key, base_url)
    try:
        body = client.get_llm_provider(provider)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e
    print(json.dumps(body, indent=2))


@llm_providers_app.command("models")
def llm_providers_models(
    provider: Annotated[str, typer.Argument(help="Provider ID to list models for.")],
    org: Annotated[str | None, typer.Option("--org", help="Organization identifier override.")] = None,
    api_key: Annotated[
        str | None,
        typer.Option("--api-key", "-k", envvar="FRUXON_API_KEY", help="API key override."),
    ] = None,
    base_url: Annotated[str | None, typer.Option("--base-url", help="API base URL override.")] = None,
    output: Annotated[
        str | None,
        typer.Option(
            "--output",
            "-o",
            help=(
                "Output format: table (default for humans), json (machines, default in "
                "agent mode), id (one ID per line, pipe-safe)."
            ),
        ),
    ] = None,
):
    """List the models a provider exposes.

    The model IDs printed here are the exact strings to pass as
    ``provider.model`` when authoring an agent revision — copy/paste safe,
    no guessing.

    Examples:
        fruxon llm-providers models anthropic
        fruxon llm-providers models anthropic --output id
        fruxon llm-providers models openai --output json | jq '.[].id'
    """
    output = resolve_output_format(output, human_default="table", agent_default="json")
    if output not in {"table", "json", "id"}:
        say_err(f"Unknown output format: [bold]{output}[/bold]", hint="Valid formats: table, json, id.")
        raise typer.Exit(code=1)

    client = build_client(org, api_key, base_url)
    try:
        body = client.get_llm_provider(provider)
    except FruxonError as e:
        say_err(str(e), hint=_hint_for_error(e))
        raise typer.Exit(code=1) from e

    models = body.get("models") if isinstance(body, dict) else None
    if not isinstance(models, list):
        models = []

    if output == "id":
        for m in models:
            mid = m.get("id") if isinstance(m, dict) else None
            if mid:
                print(mid)
        return
    if output == "json":
        print(json.dumps(models, indent=2))
        return

    if not models:
        say_info(f"No models reported for provider [bold]{provider}[/bold].")
        return

    if stderr.is_terminal:
        print_banner(subtitle=f"models · {provider} · {len(models)}")
    stderr.print()
    stderr.print(_build_models_table(models))


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────


def _provider_id(payload: dict) -> str | None:
    """The id field lives one level down — ``{"provider": {"id": …}, "models": [...]}``."""
    if not isinstance(payload, dict):
        return None
    provider = payload.get("provider")
    if isinstance(provider, dict):
        pid = provider.get("id")
        if isinstance(pid, str):
            return pid
    return None


def _build_providers_table(providers: list[dict]):
    from rich.table import Table

    table = Table(show_header=True, header_style="bold", show_edge=False, pad_edge=False, box=None, padding=(0, 1))
    table.add_column("ID", style="bold", no_wrap=True, overflow="ellipsis", max_width=20)
    table.add_column("Name", no_wrap=True, overflow="ellipsis", max_width=24)
    table.add_column("Models", justify="right", no_wrap=True, style="dim")
    table.add_column("Description", overflow="ellipsis", max_width=48, style="dim")
    for p in providers:
        provider = p.get("provider") if isinstance(p, dict) else {}
        provider = provider if isinstance(provider, dict) else {}
        models = p.get("models") if isinstance(p, dict) else []
        models_count = len(models) if isinstance(models, list) else 0
        table.add_row(
            provider.get("id") or "",
            provider.get("name") or "",
            str(models_count),
            provider.get("description") or "",
        )
    return table


def _build_models_table(models: list[dict]):
    from rich.table import Table

    table = Table(show_header=True, header_style="bold", show_edge=False, pad_edge=False, box=None, padding=(0, 1))
    table.add_column("ID", style="bold", no_wrap=True, overflow="ellipsis", max_width=32)
    table.add_column("Name", no_wrap=True, overflow="ellipsis", max_width=24)
    table.add_column("Description", overflow="ellipsis", max_width=60, style="dim")
    for m in models:
        if not isinstance(m, dict):
            continue
        table.add_row(m.get("id") or "", m.get("name") or "", m.get("description") or "")
    return table


def _hint_for_error(error: FruxonError) -> str | None:
    from fruxon.exceptions import AuthenticationError, ForbiddenError, NotFoundError

    if isinstance(error, AuthenticationError):
        return "Run [bold]fruxon whoami[/bold] to confirm your key, then [bold]fruxon login[/bold] to refresh."
    if isinstance(error, ForbiddenError):
        return "Your key doesn't grant access to this resource. Confirm with [bold]fruxon whoami[/bold]."
    if isinstance(error, NotFoundError):
        return "Unknown provider. Run [bold]fruxon llm-providers list[/bold] to see what's wired."
    return None


# Suppress unused-import warnings for helpers that are part of the public
# rendering pipeline but only referenced inside the command functions above.
_ = say_ok
