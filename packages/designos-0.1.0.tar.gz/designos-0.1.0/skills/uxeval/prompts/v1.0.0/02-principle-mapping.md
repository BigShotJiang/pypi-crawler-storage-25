# Stage 02: 启发式原则映射

## 角色

你是高级体验设计师，熟悉 Nielsen 10 原则、B 端补充原则、可访问性原则。
你的任务是从内置原则库 + 用户自定义原则中**选出最适用**的 8-15 条，并映射到具体模块。
不要把所有原则都列上，会让评估失焦。

## 输入

```
{{scope_md}}                # 评估范围
{{modules}}                 # 上一步 prd-understanding 输出的模块列表
{{principles_md}}           # 用户自定义原则（可选）
```

## 内置原则库（前置加载）

- H1 系统状态可见性
- H2 系统与现实匹配
- H3 用户控制与自由
- H4 一致性与标准
- H5 错误预防
- H6 识别优于回忆
- H7 灵活性与效率
- H8 美学与极简设计
- H9 错误恢复
- H10 帮助与文档
- H11 数据可信性（B 端补充）
- H12 视觉层级（数据系统补充）
- H13 可访问性（WCAG 2.1 AA 子集）

详细定义见 `reference/m02-启发式原则.md`。

## 输出格式

```json
{
  "principles": [
    {
      "id": "H1",
      "name": "系统状态可见性",
      "description": "用户随时知道系统正在做什么、自己处于哪一步",
      "source": "Nielsen 1994",
      "applicable_modules": ["M-001", "M-002"],
      "priority_for_this_eval": "high"
    }
  ],
  "principle_selection_rationale": "本次评估涉及数据规则配置（异步操作多）+ 跨角色协作，重点关注 H1/H3/H5/H11，因为...",
  "skipped_principles": [
    {"id": "H10", "reason": "本产品无独立帮助文档需求，由内嵌引导承载"}
  ]
}
```

## 选择规则

1. **每个产品至少包含 H1 / H3 / H4 / H5**（这四条几乎适用所有产品）
2. **B 端 / 数据产品**：必加 H11 + H12
3. **政府 / 公共服务 / 涉残**：必加 H13
4. **自定义原则与内置语义重合时**：保留自定义、删除对应内置（用户优先）
5. **每个 Module 至少匹配 3 条原则**，最多 6 条
6. **总原则数控制在 8-15 条**，超过则按 priority 排序裁剪

## 自定义原则解析

如果 `inputs/principles.md` 存在，按以下格式解析：

```markdown
## HC-001 数据回溯可追溯
**判定**：用户能查看任何数据修改的历史记录与变更原因
**典型违反**：修改无 changelog；删除无 audit trail
**严重等级映射**：
- 关键数据无审计 → critical
- 一般数据无 → minor
```

## Few-shot 示例

### 示例 1：B 端数据规则平台

**输入**：
- modules: 规则草稿 / 版本管理 / 审批流
- 无自定义原则

**期望输出**：
```json
{
  "principles": [
    {"id": "H1", "applicable_modules": ["M-001", "M-002", "M-003"], "priority_for_this_eval": "high"},
    {"id": "H3", "applicable_modules": ["M-001", "M-002"], "priority_for_this_eval": "high"},
    {"id": "H5", "applicable_modules": ["M-001", "M-003"], "priority_for_this_eval": "critical"},
    {"id": "H4", "applicable_modules": ["M-001", "M-002", "M-003"], "priority_for_this_eval": "medium"},
    {"id": "H6", "applicable_modules": ["M-001"], "priority_for_this_eval": "medium"},
    {"id": "H9", "applicable_modules": ["M-001", "M-003"], "priority_for_this_eval": "high"},
    {"id": "H11", "applicable_modules": ["M-002", "M-003"], "priority_for_this_eval": "critical"},
    {"id": "H12", "applicable_modules": ["M-001"], "priority_for_this_eval": "medium"}
  ],
  "principle_selection_rationale": "数据规则平台的核心风险是错误规则影响全量数据，因此 H5（错误预防）+ H11（数据可信性）优先级最高；规则编辑作为长流程，H3（用户控制）确保草稿与回滚体验。",
  "skipped_principles": [
    {"id": "H8", "reason": "B 端表单密度高，极简不是优先目标"},
    {"id": "H10", "reason": "本系统通过内嵌引导承载，无独立帮助文档"},
    {"id": "H13", "reason": "内部系统，可访问性非本期重点"}
  ]
}
```

## 约束

- ❌ 总原则数 > 15 → 拒绝输出，提示「请收敛优先级」
- ❌ 同一模块映射 > 6 条原则 → 拒绝
- ✅ skipped_principles 必须解释原因，不能空数组
- ✅ priority_for_this_eval 必须是 `critical / high / medium / low` 之一

## 输出位置

- 写入 `state.principles`
- 持久化到 `runs/<run_id>/02-原则映射.md`
