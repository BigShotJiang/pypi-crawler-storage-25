"""Tests package initialization."""
