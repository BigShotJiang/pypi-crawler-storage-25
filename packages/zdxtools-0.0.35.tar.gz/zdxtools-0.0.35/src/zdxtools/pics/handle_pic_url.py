from zdxtools.dx_os.dx_os import dx_os
import os
from zdxtools.spider_tools.spider_tools import spider_tools
from zdxtools.pics.compress_png import compress_png_overwrite
from zdxtools.pics.convert_pic_to_webp import convert_pic_to_webp
def handle_pic_url( picUrl,dirpath = False,proxies = False,DJANGO = True):
    '''
    自动转换图片为webp格式 返回新的路径
    :param picUrl:
    :return:
    '''
    if not dirpath:
        dirpath = os.getcwd()
    # 获得随机新名字
    newName = dx_os.get_new_file_name(picUrl.split('?')[0], uuidFlag=True)

    # 新的下载路径
    newpath = os.path.join(dirpath, newName)
    # 下载图片
    ret = spider_tools.down_pic(newpath, url=picUrl, header=spider_tools.return_header(choice=True),
                                proxies=proxies)
    compress_png_overwrite(newpath)
    if os.path.exists(newpath):
        newpath = convert_pic_to_webp(newpath, DELETE=True)
    # 更新主图
    if DJANGO:
        webUrl = f'/static/pics/{os.path.basename(newpath)}'
    return webUrl