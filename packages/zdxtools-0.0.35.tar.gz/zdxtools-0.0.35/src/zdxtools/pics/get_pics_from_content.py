import re
def get_pics_from_content(content):
    # PicPattern = '(http(?![\s\S]{1,50}<).*?(?:jpg|png|webp))"'

    PicPattern = '(http(?:.(?!<))*?(?:jpg|png|webp|jpeg))"'
    PicPattern = '(?:https?:)?//[^\s"<>]+?\.(?:jpg|png|webp|jpeg)'
    # print(content)
    picUrls = re.findall(PicPattern, content)
    return picUrls