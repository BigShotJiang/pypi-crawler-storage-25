from tqdm import tqdm
from zdxtools.pics.get_pics_from_content import get_pics_from_content
from zdxtools.pics.handle_pic_url import handle_pic_url
def handle_pics_of_content(content,dirpath = False):
    picUrls = get_pics_from_content(content)
    with tqdm(total=len(picUrls), desc='更新内容中的图片', leave=False, ncols=100, unit='张', unit_scale=True) as pbar:
        for picUrl in picUrls:
            webUrl = handle_pic_url(picUrl,dirpath = dirpath)
            content = content.replace(picUrl, webUrl)
            pbar.update(1)

    return content