def gif_to_jpg_first_frame(gif_path, DELETE = False,quality = 95):
    import os
    from PIL import Image
    """
    将GIF的第一帧转换为JPG
    :param gif_path: 输入GIF文件路径
    :param jpg_path: 输出JPG文件路径
    """
    if '.gif' not in gif_path: return gif_path
    try:
        # 打开GIF文件
        jpg_path = f'''{gif_path.split('.')[0]}.jpg'''
        with Image.open(gif_path) as img:
            # 确保读取第一帧
            img.seek(0)
            # 转换为RGB模式（JPG不支持透明通道，GIF可能有透明通道）
            rgb_img = img.convert('RGB')
            # 保存为JPG
            rgb_img.save(jpg_path, 'JPEG', quality=quality)
        if DELETE:
            os.remove(gif_path)
    except Exception as e:
        print(e)
        return False
    return jpg_path