from airtest.core.api import device, exists, Template
from poco.drivers.android.uiautomation import AndroidUiautomationPoco
import cv2
import easyocr


def get_text_near_img(
        img_path,
        threshold=0.8,
        # 相对于找到的图片，要截图的区域偏移
        offset_x=0,
        offset_y=-250,
        crop_w=500,
        crop_h=120,
        save_path="my_cropped_image.png",  # 保存的文件名
        SavePic=True,

):
    """
    找到图片 → 截取旁边区域 → OCR 识别文字
    全版本 Airtest 兼容，绝对不报错
    """
    # 1. 查找目标图片
    # # 获取屏幕分辨率 (width, height)
    # width, height = device().get_current_resolution()
    #
    # print(f"屏幕宽度：{width}")
    # print(f"屏幕高度：{height}")
    # print(f"完整分辨率：{width}x{height}")
    pos = exists(Template(img_path, threshold=threshold))
    if not pos:
        print("未找到图片")
        return None

    x, y = pos
    x1 = x + offset_x
    y1 = y + offset_y
    x2 = x1 + crop_w
    y2 = y1 + crop_h

    # 2. 全屏截图（兼容所有版本）
    frame = device().snapshot()

    # 3. 裁剪区域（numpy 兼容写法，解决 .crop() 报错）
    cropped = frame[y1:y2, x1:x2]
    if SavePic:
        # 4. 保存图片到本地 ✅
        cv2.imwrite(save_path, cropped)
        print(f"✅ 截图已保存：{save_path}")

    reader = easyocr.Reader(['ch_sim', 'en'])
    text = reader.readtext(cropped, detail=0)
    text = '_'.join(text).replace(' ', '_')
    return text
