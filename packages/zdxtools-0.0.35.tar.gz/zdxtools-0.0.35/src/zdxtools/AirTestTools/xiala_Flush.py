from airtest.core.api import sleep,swipe

def xiala_Flush(v1 = (640, 450) , vector = [0, 0.3], duration=0.5,sleeptime = 3):
    print("正在下拉刷新...")
    # 从屏幕上方 20% 下拉到 80% 位置（标准刷新）
    swipe(v1, vector=vector, duration=duration)
    sleep(sleeptime)