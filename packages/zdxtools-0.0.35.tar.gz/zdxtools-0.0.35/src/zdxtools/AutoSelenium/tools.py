from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait


class AutoSelenium:
    browser = None
    def __init__(self):pass
    @classmethod
    def js_click(cls, browser = False,Xpath = '',timeout=10):
        if not browser:browser = cls.browser

        '''
        有些时候需要 JS 点击，这样能提高点击的成功率
        '''
        select_box = WebDriverWait(browser, timeout).until(
            EC.element_to_be_clickable((By.XPATH, Xpath))
        )

        # 【关键】把 .click() 替换成这一行 JS 点击
        browser.execute_script("arguments[0].click();", select_box)
    @classmethod
    def js_scroll_click(cls, browser = False,Xpath = '',timeout=10):
        '''
        滚动到让按钮显示出来再点击
        '''
        if not browser:browser = cls.browser

        # 2. 定位目标选项（文字自己改）
        target_option = WebDriverWait(browser, timeout).until(
            EC.presence_of_element_located(
                (By.XPATH, Xpath)
            )
        )

        # 3. ✅ 关键：JS 自动滚动到该选项，让它出现在可视区域
        browser.execute_script("arguments[0].scrollIntoView(true);", target_option)

        # 4. 点击选择
        target_option.click()
    @classmethod
    def send_keys(cls, browser = False,Xpath = '',content = ''):
        if not browser:browser = cls.browser
        eles = browser.find_elements(By.XPATH, Xpath)
        if eles:eles[0].send_keys(content)
