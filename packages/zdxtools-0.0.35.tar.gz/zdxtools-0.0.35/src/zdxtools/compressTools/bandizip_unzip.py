import shutil
import subprocess
import os

def get_bz_path():
    """自动从环境变量查找 bz.exe"""
    bz = shutil.which("bz.exe")
    if bz:
        return bz

    default_paths = [
        r"C:\Program Files\Bandizip\bz.exe",
        r"C:\Program Files (x86)\Bandizip\bz.exe",
    ]
    for p in default_paths:
        if os.path.exists(p):
            return p
    return None

def bandizip_unzip(zip_path, out_dir=None, password=None, delete_after_unzip=True):
    bz_path = get_bz_path()
    if not bz_path:
        print("未找到 bz.exe，请安装 Bandizip")
        return

    if not os.path.exists(zip_path):
        print("压缩包不存在")
        return

    # 不填out_dir则自动生成同名文件夹
    if out_dir is None:
        zip_dir = os.path.dirname(zip_path)
        zip_name = os.path.splitext(os.path.basename(zip_path))[0]
        out_dir = os.path.join(zip_dir, zip_name)

    os.makedirs(out_dir, exist_ok=True)

    # ✅ 修复列表越界：正确构建命令
    cmd = [bz_path, "x", "-y"]
    if password:
        cmd.append(f"-p:{password}")
    cmd.append(f"-o:{out_dir}")
    cmd.append(zip_path)

    try:
        # ✅ 修复编码乱码错误：encoding="gbk" + errors替换
        subprocess.run(
            cmd,
            check=True,
            capture_output=True,
            encoding="gbk",
            errors="replace",
            creationflags=subprocess.CREATE_NO_WINDOW
        )
        print("✅ 解压成功:", out_dir)

        # 自动删除原压缩包
        if delete_after_unzip:
            os.remove(zip_path)
            print("🗑️ 已删除原压缩包")

    except subprocess.CalledProcessError as e:
        print(f"❌ 解压失败：{e.stderr}")
        out_dir = False
    except Exception as e:
        print(f"❌ 未知错误：{str(e)}")
        out_dir = False
    return out_dir
# ===================== 调用示例（极简版） =====================
if __name__ == '__main__':
    # 不写 out_dir，自动解压到压缩包所在目录的同名文件夹
    bandizip_unzip(
        zip_path=r"F:\人物卡\待制作\洛奇英雄传 新纪元\洛奇英雄传 新纪元.rar",
        password=None,
        delete_after_unzip=True
    )