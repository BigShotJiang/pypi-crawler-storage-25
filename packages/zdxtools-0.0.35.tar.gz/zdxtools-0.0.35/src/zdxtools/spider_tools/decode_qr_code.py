import cv2
from pyzbar import pyzbar


def decode_qr_code(image_path):
    """
    识别二维码图片，返回解析出的网址/内容
    :param image_path: 二维码图片路径（本地/网络URL）
    :return: 识别结果（字符串）
    """

    # 读取图片
    img = cv2.imread(image_path)
    if img is None:
        return False

    # 解码二维码/条形码
    decoded_objects = pyzbar.decode(img)

    # 遍历识别结果
    for obj in decoded_objects:
        # 获取二维码数据（bytes转字符串）
        qr_data = obj.data.decode("utf-8")
        # 返回识别到的内容（通常是网址）
        return qr_data

    return False


# ==================== 使用示例 ====================
if __name__ == '__main__':
    # 替换成你的二维码图片路径（本地文件/绝对路径都可以）
    qr_image = r"F:\test\image-53.jpg"

    # 调用函数识别
    result = decode_qr_code(qr_image)
    print("识别结果：", result)