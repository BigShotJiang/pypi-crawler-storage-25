"""Agent API client using httpx"""

from __future__ import annotations

import functools

import httpx

from noqa_runner.adapters.http.base_client import BaseHttpClient
from noqa_runner.domain.exceptions import AgentAPIError, InvalidTokenError
from noqa_runner.domain.models.preparation import PreparationResult
from noqa_runner.domain.models.state.flow import FlowItemRaw
from noqa_runner.domain.models.state.state import State
from noqa_runner.logging_config import get_logger
from noqa_runner.utils.retry_decorator import with_retry

logger = get_logger(__name__)


def handle_agent_api_errors(func):
    """Decorator to catch HTTP errors and convert them to AgentAPIError or InvalidTokenError"""

    @functools.wraps(func)
    async def wrapper(self, *args, **kwargs):
        try:
            return await func(self, *args, **kwargs)
        except Exception as e:
            status_code = (
                getattr(e, "response", None)
                and getattr(e.response, "status_code", None)
                or 0
            )
            error_message = str(e)

            if hasattr(e, "response") and hasattr(e.response, "text"):
                error_message = e.response.text or error_message

            logger.error(
                "agent_api_error",
                method=func.__name__,
                status_code=status_code,
                error=error_message,
                exc_info=True,
            )

            if status_code == 401:
                raise InvalidTokenError

            raise AgentAPIError(status_code=status_code, error_message=error_message)

    return wrapper


class AgentApiAdapter(BaseHttpClient):
    """Adapter for Agent API operations"""

    def __init__(self, base_url: str, api_token: str):
        super().__init__(
            base_url=base_url,
            headers={"Authorization": f"Bearer {api_token}"},
            timeout=30.0,
            limits=httpx.Limits(
                max_connections=10, max_keepalive_connections=5, keepalive_expiry=30.0
            ),
            verify=False,
        )

    @handle_agent_api_errors
    @with_retry(max_attempts=5)
    async def prepare_test(
        self,
        case_id: str | None = None,
        flows: list[FlowItemRaw] | None = None,
        case_name: str = "",
    ) -> PreparationResult:
        """Prepare test — sends either case_id or inline flows."""
        if case_id:
            payload = {"case_id": case_id}
        else:
            payload = {"flows": [f.model_dump() for f in flows], "case_name": case_name}
        response = await self._post("/v1/agent/preparation", json=payload)
        response.raise_for_status()
        return PreparationResult.model_validate(response.json())

    @handle_agent_api_errors
    @with_retry(max_attempts=5)
    async def execute_step(self, state: State, screenshot_base64: str) -> State:
        """Execute test step by sending state and screenshot to agent API"""
        payload = {"state": state.model_dump(), "screenshot_base64": screenshot_base64}
        response = await self._post("/v1/agent/step", json=payload)
        response.raise_for_status()
        return State(**response.json())
