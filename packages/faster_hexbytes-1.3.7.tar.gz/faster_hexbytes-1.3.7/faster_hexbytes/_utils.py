import binascii
from typing import (
    Final,
    Union,
)


unhexlify: Final = binascii.unhexlify


def to_bytes(val: Union[bytes, str, bytearray, bool, int, memoryview]) -> bytes:
    """
    Equivalent to: `faster_eth_utils.hexstr_if_str(faster_eth_utils.to_bytes, val)` .

    Convert a hex string, integer, or bool, to a bytes representation.
    Alternatively, pass through bytes or bytearray as a bytes value.
    """
    if isinstance(val, bytes):
        return val
    elif isinstance(val, str):
        return hexstr_to_bytes(val)
    elif isinstance(val, bytearray):
        return bytes(val)
    elif isinstance(val, bool):
        return b"\x01" if val else b"\x00"
    elif isinstance(val, int):
        # Note that this int check must come after the bool check, because
        #   isinstance(True, int) is True
        if val < 0:
            raise ValueError(f"Cannot convert negative integer {val} to bytes")
        else:
            return val.to_bytes(max(1, (val.bit_length() + 7) // 8), "big")
    elif isinstance(val, memoryview):
        return bytes(val)
    else:
        raise TypeError(f"Cannot convert {val!r} of type {type(val)} to bytes")


def hexstr_to_bytes(hexstr: str) -> bytes:
    if hexstr.startswith("0x") or hexstr.startswith("0X"):
        non_prefixed_hex = hexstr[2:]
    else:
        non_prefixed_hex = hexstr

    if not non_prefixed_hex:
        return b""

    # if the hex string is odd-length, then left-pad it to an even length
    if len(non_prefixed_hex) & 1:
        padded_hex = "0" + non_prefixed_hex
    else:
        padded_hex = non_prefixed_hex

    try:
        ascii_hex = padded_hex.encode("ascii")
    except UnicodeDecodeError:
        raise ValueError(
            f"hex string {padded_hex} may only contain [0-9a-fA-F] characters"
        )
    else:
        return unhexlify(ascii_hex)
