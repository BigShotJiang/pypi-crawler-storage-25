"""Live integration tests for all provider engines.

These tests call real provider APIs and verify that every field of the final
Response is populated correctly — including `cost`, `usage`, and `performance`.

Run exclusively:
    pytest -m live

Skip during normal CI:
    pytest tests/ -m "not live"

Outputs are saved to tests/gen/engine/live/run/{provider}_{safe_model}_{scenario}_{mode}.json
so you can inspect the raw payloads after a run.

API keys are read from environment variables:
    ANTHROPIC_API_KEY, OPENAI_API_KEY, GOOGLE_API_KEY, XAI_API_KEY

Scenarios
---------
ONLY_SYSTEM      — system message only (edge case; lenient assertions)
ONLY_USER        — single user message
SYSTEM_AND_USER  — system prompt + user message; asserts system prompt is respected
TOOL_CALL        — model must issue a tool call
CONTEXT_ROLE     — system + CONTEXT + user; verifies CONTEXT is handled without errors

TOOL_CALL_RESULT is tested separately via test_chat_tool_call_result /
test_stream_tool_call_result, which run a real TOOL_CALL first to capture
the provider-specific tool call IDs and any reasoning content, then replay
the full multi-turn conversation to avoid format mismatches.
"""

from __future__ import annotations

# standard
import base64
import json
import os
from dataclasses import asdict
from enum import Enum
from pathlib import Path
from typing import Callable

# third party
import pytest

# custom
from sunwaee.modules.gen.engine.factory import get_engine
from sunwaee.modules.gen.engine.types import (
    FileAttachment,
    Message,
    Response,
    Role,
    StopReason,
    Tool,
    ToolCall,
)

# ---------------------------------------------------------------------------
# Configuration
#
# Adjust these lists to control which engines run for each test group.
# ---------------------------------------------------------------------------

# Main test matrix — all scenario + TOOL_CALL_RESULT + image attachment tests.
ENGINES: list[tuple[str, str]] = [
    ("anthropic", "claude-haiku-4-5"),
    ("deepseek", "deepseek-chat"),
    ("google", "gemini-3.1-flash-lite-preview"),
    ("moonshot", "kimi-k2.5"),
    ("openai", "gpt-5.4-nano"),
    ("xai", "grok-4-1-fast"),
]

# Vision-capable subset of ENGINES (deepseek-chat has supports_vision=False).
VISION_ENGINES: list[tuple[str, str]] = [e for e in ENGINES if e[1] != "deepseek-chat"]

# Cheapest models per provider for prompt-caching verification.
# Anthropic: extended thinking must be disabled (thinking_budget=0) — when
#   thinking is enabled the API does not write/read prompt cache tokens.
# Google/xAI: caching is implicit / undocumented; the test only asserts
#   cache_read_tokens >= 0 (request succeeds), not that there was a hit.
CACHE_ENGINES: list[tuple[str, str]] = [
    ("anthropic", "claude-haiku-4-5"),
    ("openai", "gpt-5.4-nano"),
    ("google", "gemini-3.1-flash-lite-preview"),
    ("xai", "grok-4-1-fast"),
]

# Providers known to report cache_read_tokens > 0 on a warm cache.
# Anthropic does not report cache tokens when extended thinking is active, so
# it is excluded here — the test still runs but only asserts >= 0.
STRICT_CACHE_PROVIDERS: set[str] = {"openai"}

# Models used in the three-provider chain test (turn order: index 0 → 1 → 2).
THREE_CHAIN_PROVIDERS: list[tuple[str, str]] = [
    ("openai", "gpt-5-nano"),
    ("anthropic", "claude-haiku-4-5"),
    ("google", "gemini-3.1-flash-lite-preview"),
]

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

# 32×32 solid-red PNG — meets xAI's 512-pixel minimum and all other providers' size floors.
_PNG = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAIAAAD8GO2jAAAAKElEQVR4nO3NsQ0AAAzCMP5/un0CNkuZ41wybXsHAAAAAAAAAAAAxR4yw/wuPL6QkAAAAABJRU5ErkJggg=="
)

# Static system prompt used for caching tests.  Repeated to exceed the per-provider
# minimum cacheable block size:
#   - claude-haiku-4-5: 4,096 tokens  ← binding constraint
#   - claude-sonnet-4-6: 2,048 tokens
#   - openai (gpt-*): 1,024 tokens
# Each copy is ~1,067 tokens; ×4 ≈ 4,270 tokens, clearing the haiku threshold.
_STATIC_SYSTEM = """\
# ECOSYSTEM

SUNWAEE organizes all user data in a two-level hierarchy: Workspace → Project → {Chats, Notes, Tasks, Files}.

- Workspace: top-level container (e.g. "Personal", "Work"). Every user has a permanent "Personal" workspace.
- Project: optional sub-container within a workspace.

Object types:
- Chat: a conversation thread.
- Job: a completed AI turn (request + response cycle). Read-only.
- Note: free-form document (title + markdown body).
- Task: actionable item with status (todo/in_progress/done), priority (low/medium/high).
- File: virtual filesystem entry.
- Log: append-only activity history. Read-only.

Scope defaults: for create, list, and search operations pass the current workspace_id and project_id explicitly.

# AEGIS

When Aegis is enabled, sensitive values are replaced with typed placeholders (e.g. %%EMAIL_1%%, %%API_KEY_1%%).
Treat each placeholder as a stand-in for a real value. Never invent the underlying value.
Reference placeholders by name when needed. If a task requires the real value, tell the user.

# GUIDELINES

- Be concise; match response length to question complexity; no preamble or filler.
- Think and respond in the user's language.
- Use clean markdown.
- Do not introduce yourself unless asked; if asked: state name and current engine.
- Infer, don't interrogate: infer parameters from context; ask only when genuinely ambiguous.
- No IDs in responses: never show UUIDs; always refer to objects by name or title.
- No tool narration: don't say "I'll search your notes..."; act silently and present results naturally.
- Translate errors: never surface raw tool error messages; explain in plain language.
- Confirmation pattern: create → just do it and briefly confirm; update → state what's changing before acting.
- No delete: you cannot delete any object; suggest alternatives.
- Deliverable-first: when output is a document or script, produce the actual thing.

# VOICE

Be direct, capable, and unsentimental. Produce output, not commentary.
No "Certainly!", no "Great question!", no "I'd be happy to help."

# FORMATTING

- Inline math: use $...$
- Display math: use $$...$$
- Never use \\( \\) or \\[ \\] for inline/display math.
- Diagrams: use mermaid code fences — the UI renders them as SVG.
- Tool results: use a markdown table when presenting multiple items with several attributes.

# TOOLS

## Fetch Before Responding

When a query touches personal data, retrieve context before formulating a response.
Fetch triggers: possessive queries ("my tasks", "my notes"), status queries, history queries, continuation.
Pattern: list or search to find candidates → read only specific items → respond with current data.
Batch related fetches in the same turn rather than doing sequential round-trips.

## Limits

All list and search actions: default limit 25, maximum 100.
If results are truncated, the response includes {"_more": true, "hint": "..."}.
Re-call with a higher limit (up to 100) before responding.

## Note

- list/search to find notes; read only specific items needed.
- create/update only when explicitly requested; always pass workspace_id.
- Prefer over task for reference material, drafts, and long-form content.

## Task

- list excludes done tasks by default; use status_filter="done" to opt in.
- create/update only when explicitly requested; always pass workspace_id.
- Infer title, priority, and due date from context.
- Use ISO 8601 for all date fields; always include the UTC offset.
- Completing a recurring task auto-spawns the next instance.

## File

- list/search/read: call to answer questions about the user's files.
- create: text content only — use for scripts, documents, reports, and plans you generate.
- update: replaces full content — read first if you need to preserve existing text.

## Chat

- update: pass the current chat ID as id; can update title, workspace_id, and project_id.
- list/search/read: call when the user asks about other chats or past conversations.

## Workspace / Project

- Call only when explicitly requested, or to resolve a name to an ID.
- Never autonomously create a workspace or project mid-conversation.
- Personal workspace cannot be renamed or deleted.
""" * 4

TOOLS: list[Tool] = [
    Tool(
        name="update_chat",
        description="Update the current chat title.",
        parameters={
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "The new chat title."},
            },
            "required": ["title"],
        },
        fn=lambda title: json.dumps({"before": "New Chat", "after": title}),
    ),
]

_TOOL_FNS: dict[str, Callable] = {t.name: t.fn for t in TOOLS if t.fn}

SCENARIOS: dict[str, list[Message]] = {
    "ONLY_SYSTEM": [
        Message(role=Role.SYSTEM, content="Respond with 'ok'."),
    ],
    "ONLY_USER": [
        Message(role=Role.USER, content="Respond with 'ok'."),
    ],
    "SYSTEM_AND_USER": [
        Message(role=Role.SYSTEM, content="Start all your answers with <START>."),
        Message(role=Role.USER, content="Respond with 'ok'."),
    ],
    "TOOL_CALL": [
        Message(role=Role.USER, content="Update this chat name to 'Test Chat'."),
    ],
    "FILE_ATTACHMENT": [
        Message(
            role=Role.USER,
            content="What is the magic word in the attached file? Reply with only that word.",
            attachments=[
                FileAttachment(
                    data=b"The magic word is SUNWAEE.",
                    filename="secret.txt",
                )
            ],
        )
    ],
    "CONTEXT_ROLE": [
        Message(role=Role.SYSTEM, content="You are Sun, a helpful AI assistant."),
        Message(
            role=Role.CONTEXT,
            content=(
                "Current date: 2026-01-01\n"
                "Current engine: test-model\n"
                'Current chat: abc123 "Test Chat"\n'
                'Current workspace: ws1 "Personal"'
            ),
        ),
        Message(role=Role.USER, content="Respond with 'ok'."),
    ],
}

_TOOL_SCENARIOS = {"TOOL_CALL"}
SCENARIO_NAMES = list(SCENARIOS.keys())

RUN_DIR = Path(__file__).parent / "run"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _execute_tool(name: str, arguments: dict) -> str:
    fn = _TOOL_FNS.get(name)
    return fn(**arguments) if fn else json.dumps({"error": f"unknown tool: {name}"})


def _to_dict(obj):  # type: ignore[return]
    """Recursively convert dataclasses / Enums to plain JSON-serialisable types."""
    if hasattr(obj, "__dataclass_fields__"):
        return {k: _to_dict(v) for k, v in asdict(obj).items()}
    if isinstance(obj, list):
        return [_to_dict(i) for i in obj]
    if isinstance(obj, Enum):
        return obj.value
    return obj


def _save(data: dict, name: str) -> None:
    RUN_DIR.mkdir(parents=True, exist_ok=True)
    safe = name.replace("/", "-")
    (RUN_DIR / f"{safe}.json").write_text(json.dumps(data, indent=2))


def _key_for(provider: str) -> str:
    return f"{provider.upper()}_API_KEY"


def _assert_base_fields(r: Response, *, streaming: bool) -> None:
    """Assert provider identity and absence of error — common to all scenarios."""
    assert r.provider, "provider must be non-empty"
    assert r.model, "model must be non-empty"
    assert r.streaming is streaming, f"expected streaming={streaming}"
    assert r.synthetic is False
    assert r.error is None, f"unexpected error: {r.error}"
    assert r.stop_reason is not None, "stop_reason must be set on the final response"


def _assert_usage_cost_perf(r: Response) -> None:
    """Assert usage, cost, and performance are fully populated."""
    assert r.usage is not None, "usage must be set"
    assert r.usage.input_tokens > 0, "input_tokens must be > 0"
    assert r.usage.output_tokens > 0, "output_tokens must be > 0"
    assert r.usage.total_tokens > 0, "total_tokens must be > 0"

    assert r.performance is not None, "performance must be set"
    assert r.performance.total_duration > 0, "total_duration must be > 0"
    assert r.performance.throughput > 0, "throughput must be > 0"

    assert r.cost is not None, "cost must be set — engine did not call compute_cost()"
    assert r.cost.input >= 0, "cost.input must be >= 0"
    assert r.cost.output >= 0, "cost.output must be >= 0"
    assert r.cost.total > 0, "cost.total must be > 0"


def _assert_final_response(r: Response, *, streaming: bool, scenario_name: str) -> None:
    """Assert the terminal Response for a given scenario.

    For streaming the final chunk carries only metadata (stop_reason, usage,
    cost, performance) — content and tool_calls live in earlier chunks and are
    asserted separately in each streaming test.
    """
    if scenario_name == "ONLY_SYSTEM":
        assert r.provider, "provider must be non-empty"
        assert r.model, "model must be non-empty"
        return

    _assert_base_fields(r, streaming=streaming)
    _assert_usage_cost_perf(r)

    if scenario_name in (
        "ONLY_USER",
        "SYSTEM_AND_USER",
        "FILE_ATTACHMENT",
        "CONTEXT_ROLE",
    ):
        assert (
            r.stop_reason == StopReason.END_TURN
        ), f"expected END_TURN, got {r.stop_reason}"
        if not streaming:
            assert r.content, "content must be non-empty for a text reply"
            assert r.tool_calls is None, "tool_calls must be None when no tools given"

    elif scenario_name == "TOOL_CALL":
        assert (
            r.stop_reason == StopReason.TOOL_USE
        ), f"expected TOOL_USE, got {r.stop_reason}"
        if not streaming:
            assert r.tool_calls, "tool_calls must be populated for TOOL_CALL scenario"
            call = r.tool_calls[0]
            assert call.name == "update_chat", f"unexpected tool name: {call.name!r}"
            assert (
                call.arguments.get("title") == "Test Chat"
            ), f"unexpected title argument: {call.arguments!r}"

    elif scenario_name == "TOOL_CALL_RESULT":
        assert (
            r.stop_reason == StopReason.END_TURN
        ), f"expected END_TURN, got {r.stop_reason}"
        if not streaming:
            assert r.content, "content must be non-empty after tool result"


def _assert_content_chunk(r: Response) -> None:
    """Assert a streaming intermediate chunk (no stop_reason, no terminal fields)."""
    assert r.provider, "provider must be non-empty"
    assert r.model, "model must be non-empty"
    assert r.streaming is True
    assert r.stop_reason is None, "intermediate chunks must not carry stop_reason"
    assert r.cost is None
    assert r.usage is None
    assert r.performance is None


def _collect_stream(chunks: list[Response]) -> tuple[str, str, list[ToolCall]]:
    """Return (accumulated_content, accumulated_reasoning, all_tool_calls) from chunks."""
    content = "".join(
        c.content or "" for c in chunks if c.stop_reason is None and not c.synthetic
    )
    reasoning = "".join(
        c.reasoning_content or ""
        for c in chunks
        if c.stop_reason is None and not c.synthetic
    )
    tool_calls = [tc for c in chunks if c.tool_calls for tc in c.tool_calls]
    return content, reasoning, tool_calls


async def _run_full_turn(
    provider: str,
    model: str,
    history: list[Message],
) -> tuple[list[Message], Response]:
    """Run one complete agentic turn for a provider.

    Loops until END_TURN (or MAX_TOKENS), executing tool calls inline.
    Returns the updated history (all intermediate + final messages appended)
    and the terminal Response.
    """
    messages = list(history)
    engine = get_engine(provider, model)

    for _ in range(10):
        response = await engine.chat(messages, tools=TOOLS)

        if response.stop_reason == StopReason.TOOL_USE and response.tool_calls:
            assistant_msg = Message(
                role=Role.ASSISTANT,
                content=response.content,
                reasoning_content=response.reasoning_content,
                reasoning_signature=response.reasoning_signature,
                tool_calls=response.tool_calls,
            )
            tool_msgs = [
                Message(
                    role=Role.TOOL,
                    content=_execute_tool(tc.name, tc.arguments),
                    tool_call_id=tc.id,
                )
                for tc in response.tool_calls
            ]
            messages += [assistant_msg] + tool_msgs
        else:
            messages.append(Message(role=Role.ASSISTANT, content=response.content))
            return messages, response

    raise AssertionError(
        f"{provider}/{model}: turn did not finish within 10 iterations"
    )


def _assert_tool_was_called(history: list[Message], expected_title: str) -> None:
    """Verify that the most recent tool message in history carries the expected title."""
    tool_msgs = [m for m in history if m.role == Role.TOOL]
    assert tool_msgs, "no tool messages found in history"
    last_result = json.loads(tool_msgs[-1].content or "{}")
    assert (
        last_result.get("after") == expected_title
    ), f"expected tool to set title to {expected_title!r}, got {last_result!r}"


# ---------------------------------------------------------------------------
# Tests — scenarios (chat)
# ---------------------------------------------------------------------------


@pytest.mark.live
@pytest.mark.parametrize("scenario_name", SCENARIO_NAMES)
@pytest.mark.parametrize("provider,model", ENGINES)
async def test_chat_scenario(provider: str, model: str, scenario_name: str) -> None:
    """chat() must return a correctly populated Response for every scenario."""
    if not os.environ.get(_key_for(provider)):
        pytest.skip(f"{_key_for(provider)} not set")

    messages = SCENARIOS[scenario_name]
    tools = TOOLS if scenario_name in _TOOL_SCENARIOS else None

    engine = get_engine(provider, model)
    response = await engine.chat(messages, tools=tools)

    _save(_to_dict(response), f"{provider}_{model}_{scenario_name}_chat")
    _assert_final_response(response, streaming=False, scenario_name=scenario_name)

    if scenario_name == "SYSTEM_AND_USER":
        assert (
            "<START>" in (response.content or "").upper()
        ), f"system prompt not respected — content: {response.content!r}"


# ---------------------------------------------------------------------------
# Tests — scenarios (stream)
# ---------------------------------------------------------------------------


@pytest.mark.live
@pytest.mark.parametrize("scenario_name", SCENARIO_NAMES)
@pytest.mark.parametrize("provider,model", ENGINES)
async def test_stream_scenario(provider: str, model: str, scenario_name: str) -> None:
    """stream() must yield intermediate chunks followed by a terminal chunk
    that carries stop_reason, usage, performance, and cost.
    """
    if not os.environ.get(_key_for(provider)):
        pytest.skip(f"{_key_for(provider)} not set")

    messages = SCENARIOS[scenario_name]
    tools = TOOLS if scenario_name in _TOOL_SCENARIOS else None

    engine = get_engine(provider, model)
    chunks: list[Response] = [c async for c in engine.stream(messages, tools=tools)]

    _save(
        {"chunks": [_to_dict(c) for c in chunks]},
        f"{provider}_{model}_{scenario_name}_stream",
    )

    assert chunks, "stream must yield at least one chunk"

    for i, chunk in enumerate(chunks):
        assert chunk.provider == provider, f"chunk[{i}].provider mismatch"
        assert chunk.model == model, f"chunk[{i}].model mismatch"
        assert chunk.streaming is True, f"chunk[{i}].streaming must be True"

    final = chunks[-1]

    if scenario_name == "ONLY_SYSTEM":
        assert final.provider
        assert final.model
        return

    intermediate = [c for c in chunks if c.stop_reason is None and not c.synthetic]
    for chunk in intermediate:
        _assert_content_chunk(chunk)

    _assert_final_response(final, streaming=True, scenario_name=scenario_name)

    accumulated_content, _, all_tool_calls = _collect_stream(chunks)

    if scenario_name in ("ONLY_USER", "SYSTEM_AND_USER"):
        assert accumulated_content, "accumulated content must be non-empty"

    if scenario_name == "SYSTEM_AND_USER":
        assert (
            "<START>" in accumulated_content.upper()
        ), f"system prompt not respected — accumulated: {accumulated_content!r}"

    if scenario_name == "TOOL_CALL":
        assert all_tool_calls, "no tool calls found across stream chunks"
        call = all_tool_calls[0]
        assert call.name == "update_chat", f"unexpected tool name: {call.name!r}"
        assert (
            call.arguments.get("title") == "Test Chat"
        ), f"unexpected title argument: {call.arguments!r}"


# ---------------------------------------------------------------------------
# Tests — TOOL_CALL_RESULT (dynamic: builds on real TOOL_CALL output)
#
# Using static hardcoded assistant messages fails because providers use
# different tool call ID formats (e.g. Google uses the function name;
# moonshot appends ":0"; OpenAI generates its own IDs) and thinking-enabled
# models require reasoning_content in assistant turns.
#
# These tests run a real TOOL_CALL first to capture the provider-specific
# response, then replay the full multi-turn conversation.
# ---------------------------------------------------------------------------


@pytest.mark.live
@pytest.mark.parametrize("provider,model", ENGINES)
async def test_chat_tool_call_result(provider: str, model: str) -> None:
    """Full tool-use loop via chat(): TOOL_CALL → execute → text reply."""
    if not os.environ.get(_key_for(provider)):
        pytest.skip(f"{_key_for(provider)} not set")

    engine = get_engine(provider, model)
    user_messages: list[Message] = list(SCENARIOS["TOOL_CALL"])

    tc_response = await engine.chat(user_messages, tools=TOOLS)
    assert (
        tc_response.stop_reason == StopReason.TOOL_USE
    ), f"expected TOOL_USE from step 1, got {tc_response.stop_reason}"
    assert tc_response.tool_calls, "expected tool_calls in step 1 response"

    assistant_msg = Message(
        role=Role.ASSISTANT,
        content=tc_response.content,
        reasoning_content=tc_response.reasoning_content,
        reasoning_signature=tc_response.reasoning_signature,
        tool_calls=tc_response.tool_calls,
    )
    tool_msgs = [
        Message(
            role=Role.TOOL,
            content=_execute_tool(tc.name, tc.arguments),
            tool_call_id=tc.id,
        )
        for tc in tc_response.tool_calls
    ]

    final_messages = user_messages + [assistant_msg] + tool_msgs
    final_response = await engine.chat(final_messages, tools=TOOLS)

    _save(
        {
            "tool_call_response": _to_dict(tc_response),
            "final_response": _to_dict(final_response),
        },
        f"{provider}_{model}_TOOL_CALL_RESULT_chat",
    )

    _assert_final_response(
        final_response, streaming=False, scenario_name="TOOL_CALL_RESULT"
    )


@pytest.mark.live
@pytest.mark.parametrize("provider,model", ENGINES)
async def test_stream_tool_call_result(provider: str, model: str) -> None:
    """Full tool-use loop via stream(): TOOL_CALL → execute → text reply."""
    if not os.environ.get(_key_for(provider)):
        pytest.skip(f"{_key_for(provider)} not set")

    engine = get_engine(provider, model)
    user_messages: list[Message] = list(SCENARIOS["TOOL_CALL"])

    tc_chunks: list[Response] = [
        c async for c in engine.stream(user_messages, tools=TOOLS)
    ]
    tc_final = tc_chunks[-1]
    assert (
        tc_final.stop_reason == StopReason.TOOL_USE
    ), f"expected TOOL_USE from step 1 stream, got {tc_final.stop_reason}"

    tc_content, tc_reasoning, all_tool_calls = _collect_stream(tc_chunks)
    tc_reasoning_sig = next(
        (c.reasoning_signature for c in tc_chunks if c.reasoning_signature), None
    )
    assert all_tool_calls, "no tool calls found across step 1 stream chunks"

    assistant_msg = Message(
        role=Role.ASSISTANT,
        content=tc_content or None,
        reasoning_content=tc_reasoning or None,
        reasoning_signature=tc_reasoning_sig,
        tool_calls=all_tool_calls,
    )
    tool_msgs = [
        Message(
            role=Role.TOOL,
            content=_execute_tool(tc.name, tc.arguments),
            tool_call_id=tc.id,
        )
        for tc in all_tool_calls
    ]

    final_messages = user_messages + [assistant_msg] + tool_msgs
    final_chunks: list[Response] = [
        c async for c in engine.stream(final_messages, tools=TOOLS)
    ]
    final = final_chunks[-1]

    _save(
        {
            "step1_chunks": [_to_dict(c) for c in tc_chunks],
            "step2_chunks": [_to_dict(c) for c in final_chunks],
        },
        f"{provider}_{model}_TOOL_CALL_RESULT_stream",
    )

    assert final_chunks, "step 2 stream must yield at least one chunk"

    for i, chunk in enumerate(final_chunks):
        assert chunk.provider == provider, f"step2 chunk[{i}].provider mismatch"
        assert chunk.model == model, f"step2 chunk[{i}].model mismatch"
        assert chunk.streaming is True

    intermediate = [
        c for c in final_chunks if c.stop_reason is None and not c.synthetic
    ]
    for chunk in intermediate:
        _assert_content_chunk(chunk)

    _assert_final_response(final, streaming=True, scenario_name="TOOL_CALL_RESULT")

    accumulated_content, _, _ = _collect_stream(final_chunks)
    assert (
        accumulated_content
    ), "accumulated content must be non-empty after tool result"


# ---------------------------------------------------------------------------
# Tests — image attachment
# ---------------------------------------------------------------------------


@pytest.mark.live
@pytest.mark.parametrize("provider,model", VISION_ENGINES)
async def test_chat_image_attachment(provider: str, model: str) -> None:
    """chat() must accept a PNG image attachment and return a non-empty text reply."""
    if not os.environ.get(_key_for(provider)):
        pytest.skip(f"{_key_for(provider)} not set")

    engine = get_engine(provider, model)
    messages = [
        Message(
            role=Role.USER,
            content="Describe this image in one sentence.",
            attachments=[FileAttachment(data=_PNG, filename="pixel.png")],
        )
    ]
    response = await engine.chat(messages)

    _save(_to_dict(response), f"{provider}_{model}_IMAGE_ATTACHMENT_chat")

    _assert_base_fields(response, streaming=False)
    _assert_usage_cost_perf(response)
    assert response.stop_reason == StopReason.END_TURN
    assert response.content, "content must be non-empty after image attachment"
    assert response.tool_calls is None


@pytest.mark.live
@pytest.mark.parametrize("provider,model", VISION_ENGINES)
async def test_stream_image_attachment(provider: str, model: str) -> None:
    """stream() must accept a PNG image attachment and yield a non-empty text reply."""
    if not os.environ.get(_key_for(provider)):
        pytest.skip(f"{_key_for(provider)} not set")

    engine = get_engine(provider, model)
    messages = [
        Message(
            role=Role.USER,
            content="Describe this image in one sentence.",
            attachments=[FileAttachment(data=_PNG, filename="pixel.png")],
        )
    ]
    chunks: list[Response] = [c async for c in engine.stream(messages)]

    _save(
        {"chunks": [_to_dict(c) for c in chunks]},
        f"{provider}_{model}_IMAGE_ATTACHMENT_stream",
    )

    assert chunks
    final = chunks[-1]

    for i, chunk in enumerate(chunks):
        assert chunk.provider == provider, f"chunk[{i}].provider mismatch"
        assert chunk.model == model, f"chunk[{i}].model mismatch"
        assert chunk.streaming is True

    intermediate = [c for c in chunks if c.stop_reason is None and not c.synthetic]
    for chunk in intermediate:
        _assert_content_chunk(chunk)

    _assert_base_fields(final, streaming=True)
    _assert_usage_cost_perf(final)
    assert final.stop_reason == StopReason.END_TURN

    accumulated_content, _, _ = _collect_stream(chunks)
    assert (
        accumulated_content
    ), "accumulated content must be non-empty after image attachment"


# ---------------------------------------------------------------------------
# Tests — three-provider chain
#
# Each provider completes its ENTIRE turn (including any tool calls within it),
# appends a final assistant message to the shared history, then hands off to
# the next provider.  The next provider sees the full history — including tool
# call IDs, reasoning fields, and thought_signatures from the previous provider
# — and must accept it without any translation.
#
# Turn structure:
#   user message
#   → provider N: (tool call → tool result)* → final text reply
#   → assistant message appended to history
#   → user sends another message
#   → provider N+1 picks up
#
# Configured via THREE_CHAIN_PROVIDERS at the top of this file.
# ---------------------------------------------------------------------------


@pytest.mark.live
async def test_chat_three_provider_chain() -> None:
    """Three providers each complete a full tool-call turn in one shared chat.

    Turn 1 — providers[0]: renames chat to '{provider} Chat'
    Turn 2 — providers[1]: sees [0]'s history, renames to its own name
    Turn 3 — providers[2]: sees full history, renames to its own name

    Each provider must call update_chat with the correct title and accept the
    accumulated history built by all preceding providers.
    """
    for provider, _ in THREE_CHAIN_PROVIDERS:
        if not os.environ.get(_key_for(provider)):
            pytest.skip(f"{_key_for(provider)} not set")

    (p1, m1), (p2, m2), (p3, m3) = THREE_CHAIN_PROVIDERS
    name1 = f"{p1.capitalize()} Chat"
    name2 = f"{p2.capitalize()} Chat"
    name3 = f"{p3.capitalize()} Chat"

    history: list[Message] = [
        Message(role=Role.USER, content=f"Rename this chat to '{name1}'."),
    ]

    history, r1 = await _run_full_turn(p1, m1, history)
    assert r1.stop_reason == StopReason.END_TURN, f"turn1/{p1}: {r1.stop_reason}"
    assert r1.content
    _assert_tool_was_called(history, name1)
    _assert_usage_cost_perf(r1)

    history.append(Message(role=Role.USER, content=f"Now rename it to '{name2}'."))
    history, r2 = await _run_full_turn(p2, m2, history)
    assert r2.stop_reason == StopReason.END_TURN, f"turn2/{p2}: {r2.stop_reason}"
    assert r2.content
    _assert_tool_was_called(history, name2)
    _assert_usage_cost_perf(r2)

    history.append(Message(role=Role.USER, content=f"Now rename it to '{name3}'."))
    history, r3 = await _run_full_turn(p3, m3, history)
    assert r3.stop_reason == StopReason.END_TURN, f"turn3/{p3}: {r3.stop_reason}"
    assert r3.content
    _assert_tool_was_called(history, name3)
    _assert_usage_cost_perf(r3)

    _save(
        {
            f"turn1_{p1}": _to_dict(r1),
            f"turn2_{p2}": _to_dict(r2),
            f"turn3_{p3}": _to_dict(r3),
            "history_length": len(history),
        },
        "three_provider_chain_chat",
    )


# ---------------------------------------------------------------------------
# Tests — prompt caching
#
# Verifies that keeping the system prompt stable (and injecting per-turn
# context as Role.CONTEXT) produces cache hits by turn 2.
#
# - Anthropic: explicit cache_control on the system block; cache_read_tokens
#   is not reported when extended thinking is active, so only >= 0 is asserted.
# - OpenAI: automatic prefix caching; cache_read_tokens > 0 on turn 2.
# - Google / xAI: implicit / undocumented caching — request must succeed;
#   cache_read_tokens is informational only (not asserted > 0).
#
# Configured via CACHE_ENGINES and STRICT_CACHE_PROVIDERS at the top of this file.
# ---------------------------------------------------------------------------


@pytest.mark.live
@pytest.mark.parametrize("provider,model", CACHE_ENGINES)
async def test_cache_two_turns(provider: str, model: str) -> None:
    """Static system + CONTEXT role: turn 2 must show cache_read_tokens >= 0 (> 0 for openai)."""
    if not os.environ.get(_key_for(provider)):
        pytest.skip(f"{_key_for(provider)} not set")

    engine = get_engine(provider, model)

    # Turn 1 — establish the cache
    t1_messages: list[Message] = [
        Message(role=Role.SYSTEM, content=_STATIC_SYSTEM),
        Message(
            role=Role.CONTEXT, content="date: 2026-01-01\nengine: test-model\nturn: 1"
        ),
        Message(role=Role.USER, content="Reply with the single word 'ok'."),
    ]
    r1 = await engine.chat(t1_messages)
    assert r1.usage is not None, "turn 1: usage must be set"
    assert r1.content, "turn 1: content must be non-empty"

    # Turn 2 — same static system; history from turn 1; new context + user message
    t2_messages: list[Message] = [
        Message(role=Role.SYSTEM, content=_STATIC_SYSTEM),
        Message(
            role=Role.CONTEXT, content="date: 2026-01-01\nengine: test-model\nturn: 1"
        ),
        Message(role=Role.USER, content="Reply with the single word 'ok'."),
        Message(role=Role.ASSISTANT, content=r1.content),
        Message(
            role=Role.CONTEXT, content="date: 2026-01-01\nengine: test-model\nturn: 2"
        ),
        Message(role=Role.USER, content="Reply with the single word 'done'."),
    ]
    r2 = await engine.chat(t2_messages)
    assert r2.usage is not None, "turn 2: usage must be set"

    _save(
        {"turn1": _to_dict(r1), "turn2": _to_dict(r2)},
        f"{provider}_{model}_CACHE_two_turns",
    )

    assert (
        r2.usage.cache_read_tokens >= 0
    ), "cache_read_tokens must be a non-negative integer"
    if provider in STRICT_CACHE_PROVIDERS:
        assert r2.usage.cache_read_tokens > 0, (
            f"turn 2: expected cache_read_tokens > 0 for {provider}/{model}; "
            f"got {r2.usage.cache_read_tokens} (turn 1 cache_write={r1.usage.cache_write_tokens})"
        )
