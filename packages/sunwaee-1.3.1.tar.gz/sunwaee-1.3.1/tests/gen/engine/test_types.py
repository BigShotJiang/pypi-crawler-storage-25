# standard
import io
from typing import Annotated, Literal

# third party
import pytest

# custom
from sunwaee.modules.gen.engine.types import (
    Cost,
    Error,
    FileAttachment,
    Message,
    Performance,
    Response,
    Role,
    StopReason,
    ToolCall,
    Usage,
    make_non_stream_performance,
    resolve_tokens,
)
from sunwaee.core.tools import tool

### FIXTURES


def _make_docx(text: str) -> bytes:
    from docx import Document

    doc = Document()
    doc.add_paragraph(text)
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def _make_xlsx(text: str) -> bytes:
    from openpyxl import Workbook

    wb = Workbook()
    ws = wb.active
    ws.title = "Sheet1"
    ws.cell(row=1, column=1, value=text)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _make_pptx(text: str) -> bytes:
    from pptx import Presentation
    from pptx.util import Inches

    prs = Presentation()
    slide = prs.slides.add_slide(prs.slide_layouts[5])
    txBox = slide.shapes.add_textbox(Inches(1), Inches(1), Inches(4), Inches(1))
    txBox.text_frame.text = text
    buf = io.BytesIO()
    prs.save(buf)
    return buf.getvalue()


def _make_pdf(text: str = "Hello PDF sentence.") -> bytes:
    """Build a minimal but valid PDF with a Type1 font and extractable text."""
    stream = f"BT /F1 12 Tf 72 720 Td ({text}) Tj ET".encode()
    obj1 = b"<< /Type /Catalog /Pages 2 0 R >>"
    obj2 = b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>"
    obj3 = (
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
        b"/Contents 4 0 R "
        b"/Resources << /Font << /F1 << /Type /Font /Subtype /Type1 "
        b"/BaseFont /Helvetica /Encoding /WinAnsiEncoding >> >> >> >>"
    )
    obj4 = f"<< /Length {len(stream)} >>".encode()

    def _obj(num: int, d: bytes, s: bytes | None = None) -> bytes:
        parts = [f"{num} 0 obj\n".encode(), d]
        if s is not None:
            parts += [b"\nstream\n", s, b"\nendstream"]
        parts.append(b"\nendobj\n")
        return b"".join(parts)

    header = b"%PDF-1.4\n"
    objs = [_obj(1, obj1), _obj(2, obj2), _obj(3, obj3), _obj(4, obj4, stream)]

    offsets: list[int] = []
    pos = len(header)
    for o in objs:
        offsets.append(pos)
        pos += len(o)

    body = b"".join(objs)
    xref_pos = len(header) + len(body)
    # xref entries must be exactly 20 bytes each
    xref = b"xref\n0 5\n" + b"0000000000 65535 f \n"
    for off in offsets:
        xref += f"{off:010d} 00000 n \n".encode()
    trailer = (
        f"trailer\n<< /Size 5 /Root 1 0 R >>\nstartxref\n{xref_pos}\n%%EOF\n"
    ).encode()
    return header + body + xref + trailer


### FILE ATTACHMENT


def test_file_attachment_txt_auto_detect():
    att = FileAttachment(data=b"hello world", filename="notes.txt")
    assert att.media_type == "text/plain"
    assert att.is_text is True
    assert att.is_image is False


def test_file_attachment_png_auto_detect():
    att = FileAttachment(data=b"\x89PNG...", filename="photo.png")
    assert att.media_type == "image/png"
    assert att.is_image is True
    assert att.is_text is False


def test_file_attachment_unsupported_type_raises():
    with pytest.raises(ValueError, match="unsupported media type"):
        FileAttachment(data=b"data", filename="archive.zip")


def test_file_attachment_as_text_utf8_errors_replaced():
    att = FileAttachment(data=b"hello \xff world", filename="test.txt")
    result = att.as_text()
    assert isinstance(result, str)
    assert "hello" in result
    assert "\xff" not in result


def test_file_attachment_json_accepted():
    att = FileAttachment(data=b'{"key": "value"}', filename="data.json")
    assert att.media_type == "application/json"
    assert att.is_text is True
    assert att.as_text() == '{"key": "value"}'


def test_file_attachment_pdf_accepted():
    pdf_bytes = _make_pdf("Hello PDF sentence.")
    att = FileAttachment(data=pdf_bytes, filename="report.pdf")
    assert att.media_type == "application/pdf"
    assert att.is_text is True
    result = att.as_text()
    assert "Hello PDF" in result


def test_file_attachment_docx_accepted():
    docx_bytes = _make_docx("Hello DOCX")
    att = FileAttachment(data=docx_bytes, filename="doc.docx")
    assert att.media_type == (
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    )
    assert att.is_text is True
    assert "Hello DOCX" in att.as_text()


def test_file_attachment_xlsx_accepted():
    xlsx_bytes = _make_xlsx("Hello XLSX")
    att = FileAttachment(data=xlsx_bytes, filename="data.xlsx")
    assert att.media_type == (
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    assert att.is_text is True
    result = att.as_text()
    assert "Hello XLSX" in result
    assert "[Sheet: Sheet1]" in result


def test_file_attachment_pptx_accepted():
    pptx_bytes = _make_pptx("Hello PPTX")
    att = FileAttachment(data=pptx_bytes, filename="deck.pptx")
    assert att.media_type == (
        "application/vnd.openxmlformats-officedocument.presentationml.presentation"
    )
    assert att.is_text is True
    result = att.as_text()
    assert "Hello PPTX" in result
    assert "[Slide 1]" in result


def test_file_attachment_as_base64():
    att = FileAttachment(data=b"abc", filename="img.png")
    import base64

    assert att.as_base64() == base64.b64encode(b"abc").decode()


def test_file_attachment_explicit_media_type_bypasses_detection():
    att = FileAttachment(data=b"data", filename="unknown", media_type="image/jpeg")
    assert att.media_type == "image/jpeg"
    assert att.is_image is True


def test_file_attachment_csv_is_text():
    att = FileAttachment(data=b"a,b,c\n1,2,3", filename="table.csv")
    assert att.is_text is True
    assert att.as_text() == "a,b,c\n1,2,3"


### TYPES


def test_message_defaults():
    m = Message(role=Role.USER, content="hello")
    assert m.reasoning_content is None
    assert m.reasoning_signature is None
    assert m.tool_call_id is None
    assert m.tool_calls is None


def test_message_with_reasoning():
    m = Message(
        role=Role.ASSISTANT,
        content="answer",
        reasoning_content="I think...",
        reasoning_signature="sig-abc",
    )
    assert m.reasoning_content == "I think..."
    assert m.reasoning_signature == "sig-abc"


def test_response_defaults():
    r = Response(
        content="hi",
        tool_calls=None,
        usage=Usage(input_tokens=10, output_tokens=5),
        stop_reason=StopReason.END_TURN,
    )
    assert r.reasoning_content is None
    assert r.reasoning_signature is None


def test_response_with_reasoning():
    r = Response(
        content=None,
        tool_calls=None,
        usage=Usage(input_tokens=10, output_tokens=5),
        stop_reason=StopReason.END_TURN,
        reasoning_content="chain of thought",
        reasoning_signature="sig-xyz",
    )
    assert r.reasoning_content == "chain of thought"
    assert r.reasoning_signature == "sig-xyz"


def test_response_identity_defaults():
    r = Response()
    assert r.provider == ""
    assert r.model == ""
    assert r.streaming is False
    assert r.error is None
    assert r.cost is None
    assert r.performance is None
    assert r.usage is None


def test_response_streaming_flag():
    r = Response(provider="anthropic", model="claude-x", streaming=True)
    assert r.streaming is True
    assert r.provider == "anthropic"
    assert r.model == "claude-x"


def test_error_defaults():
    e = Error()
    assert e.message == ""
    assert e.status_code == 0


def test_performance_defaults():
    p = Performance()
    assert p.latency == 0.0
    assert p.reasoning_duration == 0.0
    assert p.content_duration == 0.0
    assert p.total_duration == 0.0
    assert p.throughput == 0


def test_cost_defaults():
    c = Cost()
    assert c.input == 0.0
    assert c.output == 0.0
    assert c.total == 0.0


def test_usage_defaults():
    u = Usage()
    assert u.input_tokens == 0
    assert u.output_tokens == 0
    assert u.total_tokens == 0


def test_make_non_stream_performance_split():
    # 100 reasoning chars, 300 content chars → 25% / 75% split
    r = Response(
        reasoning_content="a" * 100, content="b" * 300, usage=Usage(output_tokens=40)
    )
    perf = make_non_stream_performance(r, total_duration=2.0)
    assert perf.total_duration == 2.0
    assert perf.latency == 2.0
    assert abs(perf.reasoning_duration - 0.5) < 1e-9  # 100/400 * 2.0
    assert abs(perf.content_duration - 1.5) < 1e-9  # 300/400 * 2.0
    assert perf.throughput == 20  # 40 tokens / 2.0 s


def test_make_non_stream_performance_no_content():
    # No chars → reasoning_duration and content_duration both 0
    r = Response(usage=Usage(output_tokens=10))
    perf = make_non_stream_performance(r, total_duration=1.0)
    assert perf.reasoning_duration == 0.0
    assert perf.content_duration == 0.0
    assert perf.throughput == 10


def test_make_non_stream_performance_reasoning_only():
    r = Response(reasoning_content="thinking...", usage=Usage(output_tokens=5))
    perf = make_non_stream_performance(r, total_duration=1.0)
    assert perf.reasoning_duration == 1.0
    assert perf.content_duration == 0.0


def test_resolve_tokens_no_total():
    # total==0: computed as input + output
    inp, out, tot = resolve_tokens(100, 50, 0)
    assert inp == 100
    assert out == 50
    assert tot == 150


def test_resolve_tokens_consistent():
    # input + output already equals total: no change
    inp, out, tot = resolve_tokens(100, 50, 150)
    assert inp == 100
    assert out == 50
    assert tot == 150


def test_resolve_tokens_reasoning_gap():
    # total > input + output: reasoning tokens fill the gap, output is corrected
    inp, out, tot = resolve_tokens(360, 26, 625)
    assert inp == 360
    assert tot == 625
    assert out == 625 - 360  # 265 — reasoning tokens absorbed into output


def test_tool_call():
    tc = ToolCall(id="call-1", name="tasks", arguments={"action": "list"})
    assert tc.id == "call-1"
    assert tc.name == "tasks"
    assert tc.arguments == {"action": "list"}


### TOOL DECORATOR


def test_tool_required_param():
    @tool("A simple tool.")
    def my_tool(name: str) -> str:
        return name

    assert my_tool._tool.name == "my_tool"
    assert my_tool._tool.description == "A simple tool."
    assert my_tool._tool.parameters["required"] == ["name"]
    assert my_tool._tool.parameters["properties"]["name"] == {"type": "string"}


def test_tool_optional_param_not_in_required():
    @tool("Optional param tool.")
    def my_tool(name: str | None = None) -> str:
        return name or ""

    assert "name" not in my_tool._tool.parameters["required"]


def test_tool_annotated_description():
    @tool("Annotated tool.")
    def my_tool(
        query: Annotated[str, "Search query"],
    ) -> str:
        return query

    prop = my_tool._tool.parameters["properties"]["query"]
    assert prop["type"] == "string"
    assert prop["description"] == "Search query"


def test_tool_literal_becomes_enum():
    @tool("Enum tool.")
    def my_tool(
        action: Annotated[Literal["create", "list", "delete"], "Action to perform"],
    ) -> str:
        return action

    prop = my_tool._tool.parameters["properties"]["action"]
    assert prop["type"] == "string"
    assert prop["enum"] == ["create", "list", "delete"]
    assert prop["description"] == "Action to perform"
    assert my_tool._tool.parameters["required"] == ["action"]


def test_tool_list_param():
    @tool("List param tool.")
    def my_tool(tags: Annotated[list[str] | None, "Tag list"] = None) -> str:
        return ""

    prop = my_tool._tool.parameters["properties"]["tags"]
    assert prop["type"] == "array"
    assert prop["items"] == {"type": "string"}
    assert "tags" not in my_tool._tool.parameters["required"]


def test_tool_primitive_types():
    @tool("Primitives.")
    def my_tool(count: int, score: float, active: bool) -> str:
        return ""

    props = my_tool._tool.parameters["properties"]
    assert props["count"]["type"] == "integer"
    assert props["score"]["type"] == "number"
    assert props["active"]["type"] == "boolean"
    assert my_tool._tool.parameters["required"] == ["count", "score", "active"]


def test_tool_fn_is_callable():
    @tool("Callable tool.")
    def my_tool(x: str) -> str:
        return x.upper()

    assert my_tool._tool.fn is not None
    assert my_tool._tool.fn("hello") == "HELLO"


def test_tool_optional_annotated_not_required():
    @tool("Optional annotated.")
    def my_tool(
        query: Annotated[str | None, "Optional query"] = None,
    ) -> str:
        return ""

    assert "query" not in my_tool._tool.parameters["required"]
    prop = my_tool._tool.parameters["properties"]["query"]
    assert prop["description"] == "Optional query"
