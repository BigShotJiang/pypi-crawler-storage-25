# standard
import json

# third party
# custom
from sunwaee.core.logger import _configure
from sunwaee.core.tools import ok, err, tool
from sunwaee.modules.gen.tools import TOOLS


def test_ok_returns_json_string():
    result = ok({"key": "value"})
    parsed = json.loads(result)
    assert parsed == {"ok": True, "data": {"key": "value"}}


def test_ok_with_list():
    result = ok([1, 2, 3])
    parsed = json.loads(result)
    assert parsed["ok"] is True
    assert parsed["data"] == [1, 2, 3]


def test_ok_with_none():
    result = ok(None)
    parsed = json.loads(result)
    assert parsed["data"] is None


def test_err_returns_json_string():
    result = err("Something went wrong")
    parsed = json.loads(result)
    assert parsed == {"ok": False, "error": "Something went wrong"}


def test_tools_is_empty_list():
    assert TOOLS == []


def test_ok_with_git_diff():
    result = ok({"key": "value"}, git_diff="diff --git a/f b/f\n+added")
    parsed = json.loads(result)
    assert parsed["ok"] is True
    assert parsed["git_diff"] == "diff --git a/f b/f\n+added"


def test_configure_noop_when_handlers_already_present():
    # _configure() already ran at import time; calling it again hits `if root.handlers: return`
    _configure()


def test_tool_unknown_type_falls_back_to_string():
    """An annotation that isn't a recognized type maps to {"type": "string"}."""

    class CustomType:
        pass

    @tool("Fallback type test.")
    def my_tool(x: CustomType) -> str:
        return ""

    assert my_tool._tool.parameters["properties"]["x"] == {"type": "string"}
