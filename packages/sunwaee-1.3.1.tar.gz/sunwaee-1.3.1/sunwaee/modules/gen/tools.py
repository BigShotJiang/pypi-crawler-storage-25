# standard
# third party
# custom
from sunwaee.modules.gen.engine.types import Tool

TOOLS: list[Tool] = []
