# standard
# third party
# custom

try:
    from sunwaee._version import __version__
except ImportError:  # pragma: no cover
    __version__ = "0.0.0.dev0"
