# bamboo-coding

Outbound client for the Bamboo Coding controller.

## Install

```bash
pip install bamboo-coding
```

## Usage

```bash
bamboo-coding setup            # configure default profile
bamboo-coding run              # connect to the controller
```

The client reads its configuration from `~/.bamboo-coding/bamboo-coding.toml`.
