from __future__ import annotations

from .protocol import AgentRegisterMessage, ClientStatusMessage


def _build_common_payload(*, client_id: str, hostname: str, version: str, platform_name: str, capabilities: list[dict], roots: list[dict] | None, repositories: list[dict] | None, active_tasks: int, queued_tasks: int, max_concurrent_tasks: int, connected: bool) -> dict:
    root_payload = roots if roots is not None else (repositories or [])
    return {
        "protocol_version": 2,
        "client_id": client_id,
        "client_info": {
            "hostname": hostname,
            "version": version,
            "platform": platform_name,
        },
        "capabilities": capabilities,
        "roots": root_payload,
        "connectivity": {"controller": {"connected": connected}},
        "runtime_health": {
            "active_tasks": active_tasks,
            "queued_tasks": queued_tasks,
            "max_concurrent_tasks": max_concurrent_tasks,
        },
    }


def build_register_message(*, client_id: str, hostname: str, version: str, platform_name: str, capabilities: list[dict], roots: list[dict] | None = None, repositories: list[dict] | None = None, active_tasks: int, queued_tasks: int, max_concurrent_tasks: int, connected: bool = True) -> AgentRegisterMessage:
    payload = _build_common_payload(
        client_id=client_id,
        hostname=hostname,
        version=version,
        platform_name=platform_name,
        capabilities=capabilities,
        roots=roots,
        repositories=repositories,
        active_tasks=active_tasks,
        queued_tasks=queued_tasks,
        max_concurrent_tasks=max_concurrent_tasks,
        connected=connected,
    )
    return AgentRegisterMessage(**payload)


def build_status_message(*, client_id: str, hostname: str, version: str, platform_name: str, reason: str, capabilities: list[dict], roots: list[dict] | None = None, repositories: list[dict] | None = None, active_tasks: int, queued_tasks: int, max_concurrent_tasks: int, connected: bool) -> ClientStatusMessage:
    payload = _build_common_payload(
        client_id=client_id,
        hostname=hostname,
        version=version,
        platform_name=platform_name,
        capabilities=capabilities,
        roots=roots,
        repositories=repositories,
        active_tasks=active_tasks,
        queued_tasks=queued_tasks,
        max_concurrent_tasks=max_concurrent_tasks,
        connected=connected,
    )
    payload["reason"] = reason
    return ClientStatusMessage(**payload)
