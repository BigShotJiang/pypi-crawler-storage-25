from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import re
import signal
import sys
import time
from dataclasses import asdict
from pathlib import Path
from typing import Awaitable, Callable

from .config import (
    DEFAULT_PROFILE,
    SERVERS_DIRNAME,
    AgentConfig,
    _load_toml,
    load_config,
)
from .controller_client import ControllerConnection
from .terminal_runtime import ClientTerminalRuntime
from .journal import RuntimeJournal
from .status import build_register_message, build_status_message
from .protocol import (
    TaskEventMessage,
    TaskMessage,
    TaskResultMessage,
    TerminalCloseMessage,
    TerminalInputMessage,
    TerminalKillMessage,
    TerminalListRequest,
    TerminalOpenMessage,
    TerminalResizeMessage,
    TerminalSignalMessage,
)


LOGGER = logging.getLogger(__name__)
INITIAL_RETRY_DELAY = 1
MAX_RETRY_DELAY = 8
TaskExecutor = Callable[[TaskMessage], Awaitable[dict]]


class ConfigError(RuntimeError):
    pass


class AgentRuntime:
    def __init__(
        self,
        executor: TaskExecutor,
        config: AgentConfig | None = None,
        profile: str | None = None,
    ):
        self.config = config or load_config(profile or DEFAULT_PROFILE)
        self.profile = profile or getattr(self.config, "profile", None) or DEFAULT_PROFILE
        self.executor = executor
        self.journal = RuntimeJournal(self.config.journal_path)
        self.connection = ControllerConnection(self.config.controller_url, token=self.config.token)
        self.terminals = ClientTerminalRuntime(
            send_status=self.connection.send_terminal_status,
            send_output=self.connection.send_terminal_output,
            send_closed=self.connection.send_terminal_closed,
            send_heartbeat=self.connection.send_terminal_heartbeat,
        )
        self.last_registration_message = ""

    def capabilities(self) -> list[dict]:
        return [
            {"capability": "fs.tree", "actions": ["get"]},
            {"capability": "fs.browse", "actions": ["get"]},
            {"capability": "fs.file.read", "actions": ["get"]},
            {"capability": "fs.file.read_raw", "actions": ["get"]},
            {"capability": "git.file.read_original", "actions": ["get"]},
            {"capability": "repo.file.read_original", "actions": ["get"]},
            {"capability": "fs.file.write", "actions": ["put"]},
            {"capability": "fs.folder.create", "actions": ["post"]},
            {"capability": "fs.path.delete", "actions": ["delete"]},
            {"capability": "fs.path.rename", "actions": ["put"]},
            {"capability": "git.diff", "actions": ["get"]},
            {"capability": "git.status", "actions": ["get"]},
            {"capability": "git.commits", "actions": ["list"]},
            {"capability": "git.commit_details", "actions": ["get"]},
            {"capability": "git.stage", "actions": ["post"]},
            {"capability": "git.unstage", "actions": ["post"]},
            {"capability": "git.branches.list", "actions": ["get"]},
            {"capability": "git.branches.create", "actions": ["post"]},
            {"capability": "git.branches.checkout", "actions": ["put"]},
            {"capability": "git.branches.delete", "actions": ["delete"]},
            {"capability": "git.branches.merge", "actions": ["post"]},
            {"capability": "git.commit.create", "actions": ["post"]},
            {"capability": "git.remotes.list", "actions": ["get"]},
            {"capability": "git.remotes.add", "actions": ["post"]},
            {"capability": "git.remotes.remove", "actions": ["delete"]},
            {"capability": "git.remotes.push", "actions": ["post"]},
            {"capability": "git.remotes.pull", "actions": ["post"]},
            {"capability": "repo.tree", "actions": ["get"]},
            {"capability": "repo.browse", "actions": ["get"]},
            {"capability": "repo.diff", "actions": ["get"]},
            {"capability": "repo.status", "actions": ["get"]},
            {"capability": "repo.commits", "actions": ["list"]},
            {"capability": "repo.commit_details", "actions": ["get"]},
            {"capability": "repo.file.read", "actions": ["get"]},
            {"capability": "repo.file.write", "actions": ["put"]},
            {"capability": "repo.stage", "actions": ["post"]},
            {"capability": "repo.unstage", "actions": ["post"]},
            {"capability": "repo.branches.list", "actions": ["get"]},
            {"capability": "repo.branches.create", "actions": ["post"]},
            {"capability": "repo.branches.checkout", "actions": ["put"]},
            {"capability": "repo.branches.delete", "actions": ["delete"]},
            {"capability": "repo.branches.merge", "actions": ["post"]},
            {"capability": "repo.commit.create", "actions": ["post"]},
            {"capability": "repo.search", "actions": ["post"]},
            {"capability": "git.search", "actions": ["post"]},
            {"capability": "terminal.open", "actions": ["post"]},
            {"capability": "terminal.input", "actions": ["post"]},
            {"capability": "terminal.resize", "actions": ["post"]},
            {"capability": "terminal.close", "actions": ["post"]},
            {"capability": "terminal.list", "actions": ["post"]},
        ]

    def roots(self) -> list[dict]:
        return [{"path": item.path, "name": item.name} for item in self.config.repositories]

    def repositories(self) -> list[dict]:
        return [asdict(item) for item in self.config.repositories]

    def runtime_health(self) -> tuple[int, int, int]:
        active = len(self.journal.list_active_tasks())
        queued = 0
        return active, queued, self.config.max_concurrent_tasks

    def _persist_token(self, token: str) -> None:
        self.config.token_path.parent.mkdir(parents=True, exist_ok=True)
        self.config.token_path.write_text(json.dumps({"token": token}), encoding="utf-8")
        self.connection.token = token

    def validate_config(self) -> None:
        errors = validate_runtime_config(self.config)
        if errors:
            raise ConfigError("\n".join(errors))

    def prepare_storage(self) -> None:
        self.config.token_path.parent.mkdir(parents=True, exist_ok=True)
        self.config.journal_path.parent.mkdir(parents=True, exist_ok=True)

    async def register_once(self) -> bool:
        await self.connection.connect()
        active, queued, max_concurrent = self.runtime_health()
        register = build_register_message(
            client_id=self.config.client_id,
            hostname=self.config.hostname,
            version=self.config.version,
            platform_name="python",
            capabilities=self.capabilities(),
            roots=self.roots(),
            active_tasks=active,
            queued_tasks=queued,
            max_concurrent_tasks=max_concurrent,
            connected=True,
        )
        registration = await self.connection.send_register(register)
        self.last_registration_message = str(registration.get("message") or "")
        approved = bool(registration.get("approved", False))
        token = registration.get("token")
        if approved and isinstance(token, str) and token:
            self._persist_token(token)
        return approved

    async def _sleep_before_retry(self, delay: int, reason: str, stop_event: asyncio.Event | None = None) -> bool:
        LOGGER.warning("%s; retrying in %ss", reason, delay)
        if stop_event is None:
            await asyncio.sleep(delay)
            return False
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=delay)
            return True
        except asyncio.TimeoutError:
            return False

    def _reload_config(self) -> None:
        """Re-read the profile's config from disk so user fixes apply without restart."""
        try:
            new_config = load_config(self.profile)
        except Exception as exc:
            LOGGER.warning("Failed to reload config for profile '%s': %s", self.profile, exc)
            return
        url_changed = new_config.controller_url != self.config.controller_url
        token_changed = new_config.token != self.config.token
        self.config = new_config
        if url_changed:
            self.connection = ControllerConnection(new_config.controller_url, token=new_config.token)
            self.terminals.send_status = self.connection.send_terminal_status
            self.terminals.send_output = self.connection.send_terminal_output
            self.terminals.send_closed = self.connection.send_terminal_closed
            self.terminals.send_heartbeat = self.connection.send_terminal_heartbeat
        elif token_changed:
            self.connection.token = new_config.token

    async def _safe_cleanup(self, reason: str) -> None:
        """Close terminals and connection without letting cleanup failures kill the loop."""
        try:
            await self.terminals.close_all(reason=reason)
        except Exception as exc:
            LOGGER.warning("Error closing terminals during '%s': %s", reason, exc)
        try:
            await self.connection.close()
        except Exception as exc:
            LOGGER.warning("Error closing controller connection during '%s': %s", reason, exc)

    async def run(self, stop_event: asyncio.Event | None = None) -> None:
        retry_delay = INITIAL_RETRY_DELAY

        while True:
            if stop_event is not None and stop_event.is_set():
                break

            try:
                self._reload_config()
                self.validate_config()
                self.prepare_storage()
            except ConfigError as exc:
                await self._safe_cleanup("config_error")
                if await self._sleep_before_retry(
                    retry_delay, f"Config error: {exc}", stop_event
                ):
                    break
                retry_delay = min(retry_delay * 2, MAX_RETRY_DELAY)
                continue
            except Exception as exc:
                await self._safe_cleanup("config_load_error")
                if await self._sleep_before_retry(
                    retry_delay, f"Failed to prepare runtime: {exc}", stop_event
                ):
                    break
                retry_delay = min(retry_delay * 2, MAX_RETRY_DELAY)
                continue

            try:
                approved = await self.register_once()
                if not approved:
                    await self._safe_cleanup("pending_approval")
                    reason = self.last_registration_message or "Client approval is still pending"
                    if await self._sleep_before_retry(retry_delay, reason, stop_event):
                        break
                    retry_delay = min(retry_delay * 2, MAX_RETRY_DELAY)
                    continue
                retry_delay = INITIAL_RETRY_DELAY
                await self.connection.listen(self.handle_task, self.handle_terminal_message)
                await self._safe_cleanup("controller_disconnected")
                if stop_event is not None and stop_event.is_set():
                    break
                if await self._sleep_before_retry(retry_delay, "Controller connection closed", stop_event):
                    break
                retry_delay = min(retry_delay * 2, MAX_RETRY_DELAY)
            except asyncio.CancelledError:
                await self._safe_cleanup("cancelled")
                raise
            except ConnectionRefusedError as exc:
                await self._safe_cleanup("connection_failed")
                if await self._sleep_before_retry(retry_delay, f"Controller connection failed: {exc}", stop_event):
                    break
                retry_delay = min(retry_delay * 2, MAX_RETRY_DELAY)
            except Exception as exc:
                await self._safe_cleanup("runtime_error")
                if await self._sleep_before_retry(retry_delay, f"Client runtime error: {exc}", stop_event):
                    break
                retry_delay = min(retry_delay * 2, MAX_RETRY_DELAY)

        await self._safe_cleanup("stopped")

    async def handle_terminal_message(
        self,
        message: (
            TerminalOpenMessage
            | TerminalInputMessage
            | TerminalResizeMessage
            | TerminalCloseMessage
            | TerminalSignalMessage
            | TerminalKillMessage
            | TerminalListRequest
        ),
    ) -> None:
        if isinstance(message, TerminalOpenMessage):
            await self.terminals.open_terminal(message)
        elif isinstance(message, TerminalInputMessage):
            await self.terminals.input_terminal(message)
        elif isinstance(message, TerminalResizeMessage):
            await self.terminals.resize_terminal(message.terminal_id, cols=message.cols, rows=message.rows)
        elif isinstance(message, TerminalCloseMessage):
            await self.terminals.close_terminal(message.terminal_id, reason=message.reason or "controller_closed")
        elif isinstance(message, TerminalSignalMessage):
            await self.terminals.signal_terminal(message)
        elif isinstance(message, TerminalKillMessage):
            await self.terminals.close_terminal(message.terminal_id, reason="user_kill")
        elif isinstance(message, TerminalListRequest):
            response = self.terminals.list_sessions(message.workspace_path)
            await self.connection.send_terminal_list_response(response)

    async def handle_task(self, task: TaskMessage) -> None:
        self.journal.record_task_received(
            task_id=task.task_id,
            repo_id=task.repo_id,
            capability=task.capability,
            action=task.action,
            params=task.params,
        )
        self.journal.append_event(task_id=task.task_id, event_type="accepted", status="running", payload={"message": "started"})
        await self.connection.send_event(TaskEventMessage(task_id=task.task_id, status="running", message="started"))
        try:
            result = await self.executor(task)
            self.journal.record_terminal_result(task_id=task.task_id, status="succeeded", result=result)
            await self.connection.send_result(TaskResultMessage(task_id=task.task_id, success=True, result=result))
        except Exception as exc:
            self.journal.record_terminal_result(task_id=task.task_id, status="failed", error=str(exc))
            await self.connection.send_result(TaskResultMessage(task_id=task.task_id, success=False, error=str(exc)))
        active, queued, max_concurrent = self.runtime_health()
        await self.connection.send_status(
            build_status_message(
                client_id=self.config.client_id,
                hostname=self.config.hostname,
                version=self.config.version,
                platform_name="python",
                reason="task_update",
                capabilities=self.capabilities(),
                roots=self.roots(),
                active_tasks=active,
                queued_tasks=queued,
                max_concurrent_tasks=max_concurrent,
                connected=True,
            )
        )


def validate_runtime_config(config: AgentConfig) -> list[str]:
    errors: list[str] = []
    if not config.config_path.exists():
        errors.append(f"Config file not found at {config.config_path}. Run `bamboo-coding setup` first.")
        return errors
    if not config.profile_exists:
        available = ", ".join(config.available_profiles) or "(none)"
        setup_hint = (
            "bamboo-coding setup"
            if config.profile == DEFAULT_PROFILE
            else f"bamboo-coding setup {config.profile}"
        )
        errors.append(
            f"Profile '{config.profile}' not found in {config.config_path}. "
            f"Available profiles: {available}. Run `{setup_hint}` to create it."
        )
        return errors
    if not config.allowed_roots:
        errors.append(
            f"No allowed roots configured for profile '{config.profile}' in {config.config_path}. "
            f"Run `bamboo-coding setup{'' if config.profile == DEFAULT_PROFILE else ' ' + config.profile}` "
            "to configure them."
        )
    return errors


_BARE_KEY_RE = re.compile(r"^[A-Za-z0-9_-]+$")


def _toml_string(value: str) -> str:
    return json.dumps(value)


def _toml_value(value: object) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, str):
        return _toml_string(value)
    if isinstance(value, int):
        return str(value)
    if isinstance(value, (list, tuple)):
        return "[" + ", ".join(_toml_value(item) for item in value) + "]"
    raise TypeError(f"unsupported toml value type: {type(value).__name__}")


def _toml_table_header(profile: str) -> str:
    if _BARE_KEY_RE.match(profile):
        return f"[servers.{profile}]"
    return f"[servers.{_toml_string(profile)}]"


def _render_servers_toml(servers: dict[str, dict]) -> str:
    blocks: list[str] = []
    for name, profile_data in servers.items():
        lines = [_toml_table_header(name)]
        for key, value in profile_data.items():
            lines.append(f"{key} = {_toml_value(value)}")
        blocks.append("\n".join(lines))
    if not blocks:
        return ""
    return "\n\n".join(blocks) + "\n"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Bamboo Coding client")
    parser.add_argument("--config", help="Path to bamboo-coding.toml")
    subparsers = parser.add_subparsers(dest="command")

    setup_parser = subparsers.add_parser("setup", help="Create or edit a Bamboo Coding server profile")
    setup_parser.add_argument("name", nargs="?", help=f"Profile name (default: '{DEFAULT_PROFILE}')")
    setup_parser.add_argument("--controller-url", help="Controller websocket URL")
    setup_parser.add_argument("--root", action="append", dest="roots", help="Allowed root path; pass more than once for multiple roots")
    setup_parser.add_argument("--client-id", help="Client identifier advertised to the controller")
    setup_parser.add_argument("--hostname", help="Hostname advertised to the controller")
    setup_parser.add_argument("--force", action="store_true", help="Overwrite the profile if it already exists")

    run_parser = subparsers.add_parser("run", help="Run the Bamboo Coding client")
    run_parser.add_argument("name", nargs="?", help=f"Profile to connect with (default: '{DEFAULT_PROFILE}')")

    stop_parser = subparsers.add_parser("stop", help="Stop all running Bamboo Coding client processes on this machine")
    stop_parser.add_argument("--force", action="store_true", help="Send SIGKILL instead of SIGTERM")
    stop_parser.add_argument("--timeout", type=float, default=5.0, help="Seconds to wait for graceful exit before reporting (default: 5)")
    return parser


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command is None:
        args.command = "run"
    if not hasattr(args, "name"):
        args.name = None
    return args


def _is_interactive() -> bool:
    return sys.stdin.isatty()


def _prompt(label: str, default: str) -> str:
    suffix = f" [{default}]" if default else ""
    try:
        response = input(f"{label}{suffix}: ").strip()
    except EOFError:
        return default
    return response or default


def _prompt_roots(default_roots: list[str]) -> list[str]:
    default_text = ", ".join(default_roots)
    raw = _prompt("Allowed roots (comma-separated)", default_text)
    return [
        str(Path(item.strip()).expanduser().resolve())
        for item in raw.split(",")
        if item.strip()
    ]


def _confirm(prompt: str, default_yes: bool = True) -> bool:
    suffix = "[Y/n]" if default_yes else "[y/N]"
    try:
        response = input(f"{prompt} {suffix}: ").strip().lower()
    except EOFError:
        return False
    if not response:
        return default_yes
    return response in ("y", "yes")


def _migrate_legacy_storage(legacy_path: Path, profile: str) -> Path | None:
    """Move a legacy default token/journal file to the per-profile location.

    Returns the new path if a migration occurred, else None.
    """
    if not legacy_path.exists():
        return None
    new_path = legacy_path.parent / SERVERS_DIRNAME / profile / legacy_path.name
    if new_path.exists():
        return None
    new_path.parent.mkdir(parents=True, exist_ok=True)
    legacy_path.rename(new_path)
    return new_path


def setup_command(args: argparse.Namespace) -> int:
    profile = args.name or DEFAULT_PROFILE
    if not _BARE_KEY_RE.match(profile):
        print(
            f"Invalid profile name '{profile}'. Use letters, digits, underscore, or dash.",
            file=sys.stderr,
        )
        return 1

    config = load_config(profile)
    config_path = config.config_path
    interactive = _is_interactive()
    profile_in_new_layout = config.profile_exists and not config.legacy_client_section

    if profile_in_new_layout and not interactive and not args.force:
        print(
            f"Profile '{profile}' already exists in {config_path}. Use --force to overwrite it.",
            file=sys.stderr,
        )
        return 1

    default_roots = [
        str(Path(root).expanduser().resolve())
        for root in (args.roots or list(config.allowed_roots) or [str(Path.cwd().resolve())])
    ]
    default_client_id = args.client_id or config.client_id
    default_controller_url = args.controller_url or config.controller_url

    if interactive:
        if profile_in_new_layout:
            print(f"Editing profile '{profile}' in {config_path}")
            print("Press Enter to keep the current value.\n")
        elif config.legacy_client_section:
            print(f"Migrating legacy [client] section to profile '{profile}' in {config_path}")
            print("Press Enter to keep the current value.\n")
        else:
            print(f"Creating profile '{profile}' in {config_path}")
            print("Press Enter to accept the default value.\n")
        controller_url = _prompt("Controller URL", default_controller_url)
        client_id = _prompt("Client ID", default_client_id)
        default_hostname = args.hostname or config.hostname or client_id
        hostname = _prompt("Hostname", default_hostname)
        allowed_roots = _prompt_roots(default_roots)

        roots_text = ", ".join(allowed_roots) if allowed_roots else "(none)"
        print("\nConfiguration to write:")
        print(f"  Profile        : {profile}")
        print(f"  Controller URL : {controller_url}")
        print(f"  Client ID      : {client_id}")
        print(f"  Hostname       : {hostname}")
        print(f"  Allowed roots  : {roots_text}")
        print()
        if not _confirm(f"Write profile '{profile}' to {config_path}?", default_yes=True):
            print("Aborted; no changes made.")
            return 0
    else:
        controller_url = default_controller_url
        client_id = default_client_id
        hostname = args.hostname or config.hostname or client_id
        allowed_roots = default_roots

    raw_config = _load_toml(config_path) if config_path.exists() else {}
    existing_servers = raw_config.get("servers")
    servers: dict[str, dict] = (
        {name: dict(data) for name, data in existing_servers.items() if isinstance(data, dict)}
        if isinstance(existing_servers, dict)
        else {}
    )
    servers[profile] = {
        "controller_url": controller_url,
        "client_id": client_id,
        "hostname": hostname,
        "allowed_roots": list(allowed_roots),
        "max_concurrent_tasks": config.max_concurrent_tasks,
    }

    migrated_files: list[Path] = []
    creating_default_in_new_layout = (
        profile == DEFAULT_PROFILE and not (config.profile_exists and not config.legacy_client_section)
    )
    if creating_default_in_new_layout:
        for legacy_path in (config.token_path, config.journal_path):
            moved = _migrate_legacy_storage(legacy_path, profile)
            if moved is not None:
                migrated_files.append(moved)

    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(_render_servers_toml(servers), encoding="utf-8")
    print(f"Wrote profile '{profile}' to {config_path}")
    for moved in migrated_files:
        print(f"Migrated legacy storage to {moved}")
    if profile == DEFAULT_PROFILE:
        print("Next: bamboo-coding run")
    else:
        print(f"Next: bamboo-coding run {profile}")
    return 0


async def _run_runtime(runtime: AgentRuntime, stop_event: asyncio.Event | None = None) -> None:
    """Supervise runtime.run; restart it if it ever leaks an exception.

    The only way out is `stop_event` being set (via SIGINT/SIGTERM/SIGHUP) or a
    `KeyboardInterrupt`/`SystemExit` propagating up — everything else is logged
    and the loop restarts.
    """
    owns_signal_handlers = stop_event is None
    if stop_event is None:
        stop_event = asyncio.Event()

    registered_signals: list[signal.Signals] = []
    if owns_signal_handlers:
        loop = asyncio.get_running_loop()
        for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
            try:
                loop.add_signal_handler(signum, stop_event.set)
                registered_signals.append(signum)
            except (NotImplementedError, RuntimeError, AttributeError, ValueError):
                continue

    retry_delay = INITIAL_RETRY_DELAY
    try:
        while not stop_event.is_set():
            try:
                await runtime.run(stop_event=stop_event)
                if stop_event.is_set():
                    break
                LOGGER.warning("runtime.run returned unexpectedly; restarting")
            except (KeyboardInterrupt, SystemExit):
                stop_event.set()
                raise
            except asyncio.CancelledError:
                raise
            except BaseException as exc:  # noqa: BLE001 - supervisor must catch everything
                LOGGER.exception("Unhandled exception in runtime; restarting in %ss: %s", retry_delay, exc)

            try:
                await asyncio.wait_for(stop_event.wait(), timeout=retry_delay)
                break
            except asyncio.TimeoutError:
                pass
            retry_delay = min(retry_delay * 2, MAX_RETRY_DELAY)
    finally:
        if owns_signal_handlers:
            loop = asyncio.get_event_loop()
            for signum in registered_signals:
                try:
                    loop.remove_signal_handler(signum)
                except (RuntimeError, ValueError):
                    continue


def run_command(args: argparse.Namespace) -> int:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")

    from .capabilities.repo import execute_task

    profile = args.name or DEFAULT_PROFILE
    config = load_config(profile)
    errors = validate_runtime_config(config)
    for error in errors:
        print(error, file=sys.stderr)
    if errors:
        LOGGER.warning(
            "Starting runtime supervisor anyway; fix the config and the client will recover automatically."
        )

    repositories = {item.repo_id: item.path for item in config.repositories}

    async def _execute(task: TaskMessage) -> dict:
        # execute_task is synchronous and may shell out to git (which can take
        # hundreds of ms or more for large repos). Running it on the event
        # loop stalls websocket pings and trips the 20s ping_timeout.
        return await asyncio.to_thread(execute_task, task, repositories)

    runtime = AgentRuntime(_execute, config=config, profile=profile)
    try:
        asyncio.run(_run_runtime(runtime))
    except KeyboardInterrupt:
        LOGGER.info("Client interrupted")
    return 0


def _is_bamboo_client(argv: list[str]) -> bool:
    """Return True if argv looks like a running `bamboo-coding` client (run mode)."""
    if not argv:
        return False
    has_marker = any(
        Path(token).name == "bamboo-coding" or "bamboo_coding.main" in token
        for token in argv
    )
    if not has_marker:
        return False
    for token in argv:
        if token in ("setup", "stop"):
            return False
    return True


def _find_running_clients() -> list[tuple[int, list[str]]]:
    """Walk /proc to find running bamboo-coding client processes (Linux only)."""
    results: list[tuple[int, list[str]]] = []
    proc_dir = Path("/proc")
    if not proc_dir.exists():
        return results
    self_pid = os.getpid()
    for entry in proc_dir.iterdir():
        if not entry.name.isdigit():
            continue
        pid = int(entry.name)
        if pid == self_pid:
            continue
        try:
            raw = (entry / "cmdline").read_bytes()
        except (FileNotFoundError, PermissionError, OSError):
            continue
        if not raw:
            continue
        argv = [part.decode("utf-8", errors="replace") for part in raw.split(b"\x00") if part]
        if _is_bamboo_client(argv):
            results.append((pid, argv))
    return results


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def stop_command(args: argparse.Namespace) -> int:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    if sys.platform != "linux":
        print("'bamboo-coding stop' is only supported on Linux (it reads /proc).", file=sys.stderr)
        return 2

    clients = _find_running_clients()
    if not clients:
        print("No running bamboo-coding clients found.")
        return 0

    print(f"Found {len(clients)} running client process(es):")
    for pid, argv in clients:
        print(f"  PID {pid}: {' '.join(argv)}")

    sig = signal.SIGKILL if args.force else signal.SIGTERM
    sig_name = "SIGKILL" if args.force else "SIGTERM"
    sent: list[int] = []
    for pid, _ in clients:
        try:
            os.kill(pid, sig)
            sent.append(pid)
            print(f"Sent {sig_name} to PID {pid}")
        except ProcessLookupError:
            print(f"PID {pid} already exited")
        except PermissionError:
            print(f"Permission denied for PID {pid}; rerun with sudo")

    if not sent or args.force:
        return 0

    deadline = time.monotonic() + max(args.timeout, 0.0)
    remaining = list(sent)
    while remaining and time.monotonic() < deadline:
        time.sleep(0.2)
        remaining = [pid for pid in remaining if _pid_alive(pid)]

    if remaining:
        print(
            f"{len(remaining)} client(s) still running after {args.timeout}s: {remaining}. "
            "Re-run with --force to send SIGKILL."
        )
        return 1
    print("All targeted clients exited.")
    return 0


def main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)
    if args.config:
        os.environ["BAMBOO_CODING_CONFIG_PATH"] = args.config

    if args.command == "setup":
        code = setup_command(args)
    elif args.command == "stop":
        code = stop_command(args)
    else:
        code = run_command(args)

    if code:
        raise SystemExit(code)


if __name__ == "__main__":
    main()
