from __future__ import annotations

import asyncio
import inspect
import os
import shlex
import signal as _signal
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable

from bamboo_ssh import TerminalSession, stream_terminal_output

from .protocol import (
    TerminalClosedMessage,
    TerminalHeartbeatMessage,
    TerminalInputMessage,
    TerminalListRequest,
    TerminalListResponse,
    TerminalOpenMessage,
    TerminalOutputMessage,
    TerminalSessionSummary,
    TerminalSignalMessage,
    TerminalStatusMessage,
)
from .scrollback_buffer import ScrollbackBuffer


_ALLOWED_STATUSES = {"attached", "detached", "exited", "suspected_hang"}


MessageCallback = Callable[[Any], Awaitable[None] | None]
DEFAULT_OUTPUT_FLUSH_INTERVAL = 0.05
DEFAULT_HEARTBEAT_INTERVAL = 10.0
MAX_PENDING_OUTPUT_CHARS = 262144
TRUNCATED_OUTPUT_NOTICE = "\r\n[terminal output truncated while relay caught up]\r\n"


def build_initial_cwd_command(path: str) -> str:
    if not path:
        return ''
    target = Path(path).expanduser()
    resolved = target.resolve(strict=False)
    working_dir = resolved if resolved.is_dir() else resolved.parent
    return f"cd {shlex.quote(str(working_dir))}\n"


@dataclass
class ActiveTerminalSession:
    terminal_id: str
    session: TerminalSession
    reader_task: asyncio.Task | None = None
    output_task: asyncio.Task | None = None
    heartbeat_task: asyncio.Task | None = None
    output_event: asyncio.Event = field(default_factory=asyncio.Event)
    pending_output: list[str] = field(default_factory=list)
    pending_output_chars: int = 0
    output_truncated: bool = False
    scrollback: ScrollbackBuffer = field(default_factory=ScrollbackBuffer)
    cwd: str = ""
    created_at: float = 0.0
    detached_at: float | None = None
    status: str = "attached"
    cols: int = 120
    rows: int = 32
    exit_code: int | None = None


class ClientTerminalRuntime:
    def __init__(
        self,
        *,
        send_status: MessageCallback,
        send_output: MessageCallback,
        send_closed: MessageCallback,
        send_heartbeat: MessageCallback | None = None,
        output_flush_interval: float = DEFAULT_OUTPUT_FLUSH_INTERVAL,
        heartbeat_interval: float = DEFAULT_HEARTBEAT_INTERVAL,
        max_pending_output_chars: int = MAX_PENDING_OUTPUT_CHARS,
    ):
        self.send_status = send_status
        self.send_output = send_output
        self.send_closed = send_closed
        self.send_heartbeat = send_heartbeat or (lambda _message: None)
        self.output_flush_interval = output_flush_interval
        self.heartbeat_interval = heartbeat_interval
        self.max_pending_output_chars = max_pending_output_chars
        self.sessions: dict[str, ActiveTerminalSession] = {}

    async def open_terminal(self, message: TerminalOpenMessage) -> None:
        existing = self.sessions.get(message.terminal_id)
        if existing is not None:
            await self._reattach(existing, message)
            return
        await self._emit(
            self.send_status,
            TerminalStatusMessage(terminal_id=message.terminal_id, status='starting'),
        )
        session = TerminalSession.start(cols=message.cols, rows=message.rows, command=build_initial_cwd_command(message.path))
        active = ActiveTerminalSession(
            terminal_id=message.terminal_id,
            session=session,
            cwd=message.path,
            created_at=time.time(),
            cols=message.cols,
            rows=message.rows,
        )
        self.sessions[message.terminal_id] = active
        active.output_task = asyncio.create_task(
            self._flush_output_loop(message.terminal_id),
            name=f'terminal-output:{message.terminal_id}',
        )
        active.heartbeat_task = asyncio.create_task(
            self._heartbeat_loop(message.terminal_id),
            name=f'terminal-heartbeat:{message.terminal_id}',
        )
        active.reader_task = asyncio.create_task(
            self._stream_terminal(message.terminal_id, session),
            name=f'terminal:{message.terminal_id}',
        )

    async def _reattach(self, active: ActiveTerminalSession, message: TerminalOpenMessage) -> None:
        active.status = "attached"
        active.detached_at = None
        if (message.cols, message.rows) != (active.cols, active.rows):
            try:
                active.session.resize(message.cols, message.rows)
            except Exception as exc:
                await self._emit(
                    self.send_status,
                    TerminalStatusMessage(terminal_id=message.terminal_id, status='error', message=str(exc)),
                )
            active.cols = message.cols
            active.rows = message.rows
        snapshot = active.scrollback.snapshot()
        if snapshot:
            await self._emit(
                self.send_output,
                TerminalOutputMessage(terminal_id=message.terminal_id, data=snapshot),
            )
        await self._emit(
            self.send_status,
            TerminalStatusMessage(terminal_id=message.terminal_id, status='reattached'),
        )

    async def input_terminal(self, message: TerminalInputMessage) -> None:
        active = self.sessions.get(message.terminal_id)
        if active is None:
            return
        try:
            active.session.write(message.data)
        except Exception as exc:
            await self._emit(
                self.send_status,
                TerminalStatusMessage(terminal_id=message.terminal_id, status='error', message=str(exc)),
            )
            await self.close_terminal(message.terminal_id, reason='write_failed')

    async def resize_terminal(self, terminal_id: str, *, cols: int, rows: int) -> None:
        active = self.sessions.get(terminal_id)
        if active is None:
            return
        try:
            active.session.resize(cols, rows)
        except Exception as exc:
            await self._emit(
                self.send_status,
                TerminalStatusMessage(terminal_id=terminal_id, status='error', message=str(exc)),
            )
            await self.close_terminal(terminal_id, reason='resize_failed')

    async def close_terminal(
        self,
        terminal_id: str,
        *,
        reason: str = 'closed',
        emit_closed: bool = True,
        exit_code: int | None = None,
    ) -> None:
        active = self.sessions.pop(terminal_id, None)
        if active is None:
            return
        active.session.close()
        current_task = asyncio.current_task()
        for task in (active.reader_task, active.output_task, active.heartbeat_task):
            if task is None or task is current_task:
                continue
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        await self._flush_pending_output(active)
        if exit_code is None:
            exit_code = getattr(getattr(active.session, 'process', None), 'returncode', None)
        active.exit_code = exit_code
        active.status = "exited"
        if emit_closed:
            await self._emit(
                self.send_closed,
                TerminalClosedMessage(terminal_id=terminal_id, reason=reason, exit_code=exit_code),
            )

    async def close_all(self, reason: str = 'shutdown') -> None:
        for terminal_id in list(self.sessions):
            await self.close_terminal(terminal_id, reason=reason)

    async def signal_terminal(self, message: TerminalSignalMessage) -> None:
        active = self.sessions.get(message.terminal_id)
        if active is None:
            return
        master_fd = active.session.master_fd
        try:
            pgid = os.tcgetpgrp(master_fd)
        except OSError:
            return
        sig = _signal.SIGINT if message.signal == "SIGINT" else _signal.SIGTERM
        try:
            os.killpg(pgid, sig)
        except ProcessLookupError:
            pass

    def list_sessions(self, workspace_path: str) -> TerminalListResponse:
        summaries: list[TerminalSessionSummary] = []
        for terminal_id, active in self.sessions.items():
            if active.cwd != workspace_path:
                continue
            summary_status = active.status if active.status in _ALLOWED_STATUSES else "attached"
            summaries.append(
                TerminalSessionSummary(
                    terminal_id=terminal_id,
                    cwd=active.cwd,
                    created_at=active.created_at,
                    detached_at=active.detached_at,
                    status=summary_status,
                    exit_code=active.exit_code,
                )
            )
        return TerminalListResponse(workspace_path=workspace_path, sessions=summaries)

    async def _stream_terminal(self, terminal_id: str, session: TerminalSession) -> None:
        async def send_json(payload: dict) -> None:
            message_type = payload.get('type')
            if message_type == 'ready':
                await self._emit(self.send_status, TerminalStatusMessage(terminal_id=terminal_id, status='ready'))
            elif message_type == 'cmd':
                self._queue_output(terminal_id, str(payload.get('data') or ''))

        try:
            await stream_terminal_output(session, send_json)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            if terminal_id in self.sessions:
                await self._emit(
                    self.send_status,
                    TerminalStatusMessage(terminal_id=terminal_id, status='error', message=str(exc)),
                )
        finally:
            active = self.sessions.get(terminal_id)
            if active is not None:
                exit_code = getattr(getattr(active.session, 'process', None), 'returncode', None)
                await self.close_terminal(terminal_id, reason='session_ended', exit_code=exit_code)

    def _queue_output(self, terminal_id: str, data: str) -> None:
        if not data:
            return
        active = self.sessions.get(terminal_id)
        if active is None:
            return
        active.pending_output.append(data)
        active.scrollback.append(data)
        active.pending_output_chars += len(data)
        while active.pending_output_chars > self.max_pending_output_chars and active.pending_output:
            removed = active.pending_output.pop(0)
            active.pending_output_chars -= len(removed)
            active.output_truncated = True
        active.output_event.set()

    async def _flush_output_loop(self, terminal_id: str) -> None:
        try:
            while True:
                active = self.sessions.get(terminal_id)
                if active is None:
                    return
                await active.output_event.wait()
                await asyncio.sleep(self.output_flush_interval)
                active = self.sessions.get(terminal_id)
                if active is None:
                    return
                await self._flush_pending_output(active)
        except asyncio.CancelledError:
            raise

    async def _flush_pending_output(self, active: ActiveTerminalSession) -> None:
        if not active.pending_output and not active.output_truncated:
            active.output_event.clear()
            return
        payload = ''.join(active.pending_output)
        active.pending_output.clear()
        active.pending_output_chars = 0
        if active.output_truncated:
            payload = f'{TRUNCATED_OUTPUT_NOTICE}{payload}'
            active.output_truncated = False
        active.output_event.clear()
        if payload:
            await self._emit(
                self.send_output,
                TerminalOutputMessage(terminal_id=active.terminal_id, data=payload),
            )

    async def _heartbeat_loop(self, terminal_id: str) -> None:
        try:
            while True:
                await asyncio.sleep(self.heartbeat_interval)
                active = self.sessions.get(terminal_id)
                if active is None:
                    return
                process = getattr(active.session, 'process', None)
                poll = getattr(process, 'poll', None)
                exit_code = poll() if callable(poll) else getattr(process, 'returncode', None)
                process_alive = exit_code is None
                await self._emit(
                    self.send_heartbeat,
                    TerminalHeartbeatMessage(terminal_id=terminal_id, process_alive=process_alive),
                )
                if not process_alive:
                    await self.close_terminal(terminal_id, reason='session_ended', exit_code=exit_code)
                    return
        except asyncio.CancelledError:
            raise

    async def _emit(self, callback: MessageCallback, message: Any) -> None:
        result = callback(message)
        if inspect.isawaitable(result):
            await result
