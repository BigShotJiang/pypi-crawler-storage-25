class BrowserPortMock:
    pass
