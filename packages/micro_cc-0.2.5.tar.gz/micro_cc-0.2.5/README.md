# micro · cc — cognitive compute

```
  ███╗   ███╗██╗ ██████╗██████╗  ██████╗
  ████╗ ████║██║██╔════╝██╔══██╗██╔═══██╗
  ██╔████╔██║██║██║     ██████╔╝██║   ██║
  ██║╚██╔╝██║██║██║     ██╔══██╗██║   ██║
  ██║ ╚═╝ ██║██║╚██████╗██║  ██║╚██████╔╝
  ╚═╝     ╚═╝╚═╝ ╚═════╝╚═╝  ╚═╝ ╚═════╝
       c o g n i t i v e  c o m p u t e
```

> Knowledge work is, by extension, a coding problem.

Frontier models with full system access — shell, filesystem, browser, MCP — running directly on the metal. Verbose, thorough planning paired with unrestricted file operations means micro·cc can take on complex multi-step work autonomously. Point it at any project directory and go.

## Install

Please use `iTerm2`. Highly recommended terminal UI.

```bash
pip install micro-cc
```

On first launch, micro·cc creates `~/.micro-cc/` with an example `.env` — add your API keys there and restart. That directory is also where conversation history and project state live.

Recommended terminal: **iTerm2** (macOS).

## Platform

Built and tested on macOS. Works on Linux. Windows should work via `pip install` + any modern terminal — iTerm2 is macOS-only but micro·cc doesn't depend on it, it just looks best there.

## Environment

Edit `~/.micro-cc/.env` — set **one** endpoint:

```
# Option 1: Anthropic direct + OpenAI for embeddings
ANTHROPIC_API_KEY=sk-ant-
OPENAI_API_KEY=sk-proj-

# Option 2: LiteLLM proxy (Bedrock, Azure, etc.)
# LITELLM_BASE_URL=https://your-proxy.com
# LITELLM_API_KEY=sk-...

# Web search (always needed for search tools)
SERPAPI_KEY=
```

## Usage

```bash
microcc /path/to/your/project
```

**Controls:**
- `Enter` — submit prompt
- `Shift+Enter` — newline
- `Escape` — interrupt
- `/clear` — reset conversation
- `/model` — switch model
- `/exit` — quit

## Data

```
~/.micro-cc/
  .env                              API keys
  projects/
    {project}_{hash}/
      messages.jsonl                conversation history
      summary.json                  sliding-window summary
      project_path.txt              maps hash back to directory
```

## Tools

| Tool | Description |
|------|-------------|
| `bash_` | Shell execution in project_dir |
| `read_` | Read files with line numbers, offset/limit |
| `write_` | Create/overwrite files, auto-creates dirs |
| `edit_` | Surgical string replacement (fails if ambiguous) |
| `glob_` | Find files by pattern, sorted by mtime |
| `grep_` | Regex search with context lines |
| `browser_` | Web browsing and page extraction (beta) |
| `computer_use_` | Screen interaction and GUI automation (beta) |

All tools are discoverable — use `search_tools` to find more at runtime.

Relative paths resolve to `project_dir`. Absolute paths work anywhere.

## Architecture

```
start_live_.py (CLI)                textual TUI
       │
       │ async for event in claude_loop()
       ▼
claude_loop_.py (Core)              API calls, tool execution, JSONL storage
       │
       │ execute_tool_call()
       ▼
tools/                              bash_, file ops, browser, computer_use
       │
       ▼
~/.micro-cc/projects/{hash}/        conversation persistence
```

Full system access plus verbose planning. The model reads your codebase, writes plans, executes tools, observes results, iterates — until the work is done.
