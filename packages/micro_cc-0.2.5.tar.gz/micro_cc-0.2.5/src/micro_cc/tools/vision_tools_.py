from micro_cc.utils.helpers import sanitize_and_encode_image_, get_endpoint
from micro_cc.models.anthropic import a_model_call
from micro_cc.models.litellm import l_model_call
import os


async def vision(img_path: str, query: str, *, project_dir) -> str:
    """Analyze images to extract visual information or answer questions.

    Handles photographs, diagrams, charts, screenshots, and images with text.

    Args:
        img_path: Absolute or relative path to the image file
        query: What to ask about the image
    """
    try:
        if not os.path.isabs(img_path):
            img_path = os.path.join(project_dir, img_path)

        if not os.path.exists(img_path):
            return f"[File not found: {img_path}] — (potential issue: macOS uses special Unicode characters in filenames when screenshot is taken - ask user to try to rename the file for you!)"

        encoded_string = sanitize_and_encode_image_(img_path)
        if get_endpoint() == "LiteLLM":
            resp = await l_model_call(input=query, encoded_image=encoded_string)
        else:
            resp = await a_model_call(input=query, encoded_image=encoded_string)
        return resp.content[0].text

    except Exception as e:
        return f"Vision error: {str(e)}"
