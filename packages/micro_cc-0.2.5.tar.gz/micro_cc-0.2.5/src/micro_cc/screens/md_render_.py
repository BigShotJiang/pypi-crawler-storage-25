"""
Customized Rich Markdown rendering.

Subclasses rich.markdown.Markdown to fix:
- CodeBlock: no full-width background, no padding (was thick panels)
- Heading h1: left-aligned, not centered
"""

from rich.markdown import Markdown, CodeBlock, Heading
from rich.syntax import Syntax
from rich.style import Style
from rich.console import Console, ConsoleOptions, RenderResult
from rich.text import Text


class CleanCodeBlock(CodeBlock):
    """Code block without full-width background panel."""

    def __rich_console__(
        self, console: Console, options: ConsoleOptions
    ) -> RenderResult:
        code = str(self.text).rstrip()
        yield Syntax(
            code,
            self.lexer_name,
            theme=self.theme,
            word_wrap=True,
            padding=0,
            background_color="default",
        )


class CleanHeading(Heading):
    """Heading that's always left-aligned (h1 not centered)."""

    def __rich_console__(
        self, console: Console, options: ConsoleOptions
    ) -> RenderResult:
        text = self.text.copy()
        text.justify = "left"
        yield text


class CleanMarkdown(Markdown):
    """Markdown with clean code blocks and left-aligned headings."""

    elements = {**Markdown.elements}
    elements["fence"] = CleanCodeBlock
    elements["code_block"] = CleanCodeBlock
    elements["heading_open"] = CleanHeading


class DimMarkdown(CleanMarkdown):
    """Same as CleanMarkdown but everything renders dim (for thinking)."""

    def __init__(self, markup: str, **kwargs):
        super().__init__(markup, **kwargs)
        self.style = "dim"


def render_md(content: str, dim: bool = False):
    """Return a Rich renderable for markdown content."""
    if dim:
        return DimMarkdown(content)
    return CleanMarkdown(content)
