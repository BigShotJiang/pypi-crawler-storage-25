from textual.widget import Widget
from textual.widgets import Static
from rich.text import Text
from rich.console import Group
from micro_cc.screens.md_render_ import render_md

BANNER = """\
[bold white]███╗   ███╗ ██████╗ ██████╗ ███████╗██╗[/]
[bold white]████╗ ████║██╔═══██╗██╔══██╗██╔════╝██║[/]
[bold white]██╔████╔██║██║   ██║██║  ██║█████╗  ██║[/]
[dim]██║╚██╔╝██║██║   ██║██║  ██║██╔══╝  ██║[/]
[dim]██║ ╚═╝ ██║╚██████╔╝██████╔╝███████╗███████╗[/]
[dim]╚═╝     ╚═╝ ╚═════╝ ╚═════╝ ╚══════╝╚══════╝[/]
[dim]───────[/] [bold]on the metal[/] [dim]─────────────────────[/]
[dim italic]Knowledge work is by extension a coding problem.[/]

[white]enter[/] [dim]submit[/] [dim]·[/] [white]esc[/] [dim]interrupt[/] [dim]·[/] [white]/model[/] [dim]switch[/] [dim]·[/] [white]/rewind[/] [dim]undo[/] [dim]·[/] [white]/copy[/] [dim]clipboard[/] [dim]·[/] [white]/clear[/] [dim]reset[/] [dim]·[/] [white]/exit[/] [dim]quit[/]
"""


# ── Per-message widget (cached render) ──────────────────────


class MessageRow(Static):
    """One message = one widget. Render is cached; history rows never re-render."""

    DEFAULT_CSS = "MessageRow { height: auto; }"

    def __init__(self, msg: dict, **kw):
        super().__init__(**kw)
        self._msg = msg
        self._rendered = None  # cached Rich renderable

    def _build(self):
        """Build Rich renderable from msg dict. Called once, then cached."""
        msg = self._msg
        t = msg["type"]
        if t == "user":
            return Text(f"› {msg['content']}", style="bold")
        elif t == "user_queued":
            return Text(f"⋯queued {msg['content']}", style="dim italic #ffA500")
        elif t == "text":
            return render_md(msg["content"])
        elif t == "thinking":
            return Group(
                Text("∴ Thinking", style="dim italic"),
                render_md(msg["content"], dim=True),
            )
        elif t == "tool_call":
            name = msg['name']
            result = msg.get('result')
            if result is None:
                return Text(f"⟐ {name} ⋯", style="yellow")
            return Text(f"⟐ {name} → {str(result)[:40]}…", style="dim")
        elif t == "error":
            return Text(f"△ {msg['content']}", style="red")
        elif t == "approval":
            inp = msg.get('input', {})
            name = msg['name']
            _sep = Text("·" * 40, style="dim")
            if name == "bash_":
                code = inp.get('command', str(inp))
                return Group(
                    Text(f"◇ {name}  [y/N]", style="bold yellow"),
                    render_md(f"```bash\n{code}\n```"),
                    _sep,
                )
            elif name == "edit_":
                parts = [Text(f"◇ {name}  [y/N]", style="bold yellow")]
                fp = inp.get('file_path', '')
                if fp:
                    parts.append(Text(f"  {fp}", style="dim"))
                old = inp.get('old_string', '')
                new = inp.get('new_string', '')
                if old or new:
                    diff = f"```diff\n- {old}\n+ {new}\n```" if old else f"```\n{new}\n```"
                    parts.append(render_md(diff))
                parts.append(_sep)
                return Group(*parts)
            elif name == "write_":
                parts = [Text(f"◇ {name}  [y/N]", style="bold yellow")]
                fp = inp.get('file_path', '')
                if fp:
                    parts.append(Text(f"  {fp}", style="dim"))
                content = inp.get('content', '')
                if content:
                    preview = content[:500] + ("…" if len(content) > 500 else "")
                    parts.append(render_md(f"```\n{preview}\n```"))
                parts.append(_sep)
                return Group(*parts)
            return Group(
                Text(f"◇ {name}  [y/N]", style="bold yellow"),
                Text(f"  {str(inp)[:80]}…", style="dim"),
            )
        return Text("")

    def render(self):
        if self._rendered is None:
            self._rendered = self._build()
        return self._rendered

    def invalidate_cache(self):
        """Force re-render (e.g. tool_call gets its result)."""
        self._rendered = None
        self.refresh(layout=True)

    def update_msg(self, msg: dict):
        """Update the backing data and invalidate cache."""
        self._msg = msg
        self.invalidate_cache()


# ── Streaming widget (active text/thinking) ─────────────────


class StreamingRow(Static):
    """Dedicated widget for the currently-streaming text/thinking block.
    Only this widget re-renders during streaming — history is untouched.
    Implements CC-style stable prefix: completed markdown blocks are cached,
    only the trailing incomplete block gets re-parsed."""

    DEFAULT_CSS = "StreamingRow { height: auto; }"

    def __init__(self, mode="text", **kw):
        super().__init__(**kw)
        self._mode = mode  # "text" or "thinking"
        self._content = ""
        # Stable prefix caching (CC pattern)
        self._stable_content = ""
        self._stable_rendered = None

    def append(self, chunk: str):
        """Append text — called from buffered flush."""
        self._content += chunk

    def render(self):
        if self._mode == "thinking":
            parts = [Text("∴ Thinking", style="dim italic")]
            if self._content:
                parts.append(render_md(self._content, dim=True))
            return Group(*parts)

        # Text mode — stable prefix optimization
        # Find the last double-newline boundary (markdown block separator)
        boundary = self._content.rfind("\n\n")
        if boundary > len(self._stable_content):
            # Everything before boundary is stable — cache it
            self._stable_content = self._content[:boundary]
            self._stable_rendered = render_md(self._stable_content)

        if self._stable_rendered and boundary > 0:
            # Render: cached prefix + fresh suffix
            suffix = self._content[boundary:]
            return Group(self._stable_rendered, render_md(suffix))
        else:
            return render_md(self._content) if self._content else Text("")

    def get_content(self):
        return self._content

    def flush_display(self):
        """Called by the 50ms timer to push accumulated text to screen."""
        self.refresh(layout=True)


# ── Message container ────────────────────────────────────────


class MessageList(Widget):
    """Container for MessageRow widgets. Kept for backwards compat
    with CSS selectors and compose(). Now just a vertical container."""

    DEFAULT_CSS = "MessageList { height: auto; }"

    def render(self):
        # Children are mounted dynamically — nothing to render here
        return Text("")
