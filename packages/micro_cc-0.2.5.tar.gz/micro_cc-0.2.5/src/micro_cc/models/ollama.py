"""Ollama model caller — fully standalone.

Talks to a locally running Ollama daemon via its OpenAI-compatible
endpoint at http://localhost:11434/v1.

Handled internally — no dependency on other model callers:
- Anthropic message format → OpenAI chat format conversion
- Tool schema conversion (Anthropic shape → OpenAI function shape)
- Streaming wrapper that yields Anthropic-shaped events
- Ollama-specific quirks:
    * thinking field is `reasoning` (not `reasoning_content` like LiteLLM/DeepSeek)
    * final stream chunk with include_usage has empty `choices` list
    * `think: True` passed via extra_body toggles reasoning mode
    * `num_ctx` passed via extra_body.options overrides the 4K default

Env vars:
    OLLAMA_BASE_URL   default http://localhost:11434/v1
    OLLAMA_MODEL      user picks any tag pulled via `ollama pull <tag>`
    OLLAMA_NUM_CTX    default 32768 — fits Qwen3-14B KV cache in ~5GB
    OLLAMA_MAX_OUTPUT default 4096  — generation budget per response
"""

from typing import List, Dict, Any, Optional, Union
from openai import AsyncOpenAI
from dotenv import load_dotenv
from dataclasses import dataclass, field
import asyncio
import json
import os

load_dotenv(os.path.expanduser("~/.micro-cc/.env"))
load_dotenv()


# ---------------------------------------------------------------------------
# Response shape — same as Anthropic SDK so claude_loop_.py works unchanged
# ---------------------------------------------------------------------------

@dataclass
class ContentBlock:
    type: str
    text: str = ""
    thinking: str = ""
    signature: str = ""
    name: str = ""
    input: dict = field(default_factory=dict)
    id: str = ""


@dataclass
class Response:
    content: list = field(default_factory=list)


# ---------------------------------------------------------------------------
# Converters — Anthropic format → OpenAI chat format
# ---------------------------------------------------------------------------

def _tools_to_openai(anthropic_tools, mcp_openai_tools=None):
    """Anthropic tool schemas + MCP tools → OpenAI function-calling format."""
    out = []
    for t in anthropic_tools:
        out.append({
            "type": "function",
            "function": {
                "name": t["name"],
                "description": t.get("description", ""),
                "parameters": t.get("input_schema", {}),
            },
        })
    if mcp_openai_tools:
        out.extend(mcp_openai_tools)
    return out or None


def _msgs_to_openai(anthropic_msgs):
    """Convert Anthropic-format message list to OpenAI chat format.

    Handles: system, user (string/multimodal/tool_result),
    assistant (string/tool_use blocks). Thinking blocks are dropped —
    local models can't replay signed thinking, and Ollama's OpenAI-compat
    endpoint doesn't accept them on the resend path.
    """
    out = []
    for msg in anthropic_msgs:
        role = msg.get("role")
        content = msg.get("content", "")

        if role == "system":
            out.append({"role": "system", "content": content})
            continue

        # --- Assistant with content blocks ---
        if role == "assistant" and isinstance(content, list):
            text_parts = []
            tool_calls = []
            for block in content:
                if not isinstance(block, dict):
                    continue
                btype = block.get("type")
                if btype == "text":
                    text_parts.append(block["text"])
                elif btype == "tool_use":
                    tool_calls.append({
                        "id": block["id"],
                        "type": "function",
                        "function": {
                            "name": block["name"],
                            "arguments": json.dumps(block["input"]),
                        },
                    })
                # thinking blocks: intentionally skipped for Ollama

            m = {
                "role": "assistant",
                "content": "\n".join(text_parts) if text_parts else None,
            }
            if tool_calls:
                m["tool_calls"] = tool_calls
            out.append(m)
            continue

        # --- User with content blocks (tool_result, text, image, document) ---
        if role == "user" and isinstance(content, list):
            tool_results = []
            other_parts = []

            for block in content:
                if not isinstance(block, dict):
                    continue
                btype = block.get("type")
                if btype == "tool_result":
                    tool_results.append({
                        "role": "tool",
                        "tool_call_id": block["tool_use_id"],
                        "content": block.get("content", ""),
                    })
                elif btype == "text":
                    other_parts.append({"type": "text", "text": block["text"]})
                elif btype == "image":
                    source = block.get("source", {})
                    media = source.get("media_type", "image/jpeg")
                    other_parts.append({
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:{media};base64,{source.get('data', '')}",
                        },
                    })
                elif btype == "document":
                    other_parts.append({
                        "type": "text",
                        "text": "[PDF document attached]",
                    })

            out.extend(tool_results)

            if other_parts:
                if len(other_parts) == 1 and other_parts[0].get("type") == "text":
                    out.append({"role": "user", "content": other_parts[0]["text"]})
                else:
                    out.append({"role": "user", "content": other_parts})
            continue

        # --- Simple string content ---
        out.append({"role": role, "content": content})

    return out


# ---------------------------------------------------------------------------
# Response wrappers — OpenAI shape → Anthropic-like Response
# ---------------------------------------------------------------------------

def _extract_reasoning(obj) -> str:
    """Ollama surfaces thinking on `reasoning` via model_dump; OpenAI client
    doesn't type that attribute, so fall back to model_dump().get('reasoning')."""
    rc = getattr(obj, "reasoning", None)
    if rc:
        return rc
    try:
        dumped = obj.model_dump()
        return dumped.get("reasoning") or ""
    except Exception:
        return ""


def _wrap_response(openai_resp):
    """Non-streaming OpenAI ChatCompletion → Anthropic-like Response."""
    choice = openai_resp.choices[0]
    msg = choice.message
    blocks = []

    reasoning = _extract_reasoning(msg)
    if reasoning:
        blocks.append(ContentBlock(type="thinking", thinking=reasoning, signature=""))

    if msg.content:
        blocks.append(ContentBlock(type="text", text=msg.content))

    if msg.tool_calls:
        for tc in msg.tool_calls:
            try:
                args = json.loads(tc.function.arguments)
            except (json.JSONDecodeError, TypeError):
                args = {}
            blocks.append(ContentBlock(
                type="tool_use",
                name=tc.function.name,
                input=args,
                id=tc.id,
            ))

    return Response(content=blocks)


async def _wrap_stream(openai_stream):
    """Accumulate OpenAI chunks, yield Anthropic-shaped events,
    finish with a final Response containing all content blocks."""
    text = ""
    thinking = ""
    tool_calls = {}  # index → {id, name, args}
    usage = {}

    async for chunk in openai_stream:
        # Final usage-only chunks have empty choices (Ollama sends this
        # when stream_options.include_usage is on).
        if not chunk.choices:
            u = getattr(chunk, "usage", None)
            if u:
                usage["input"] = getattr(u, "prompt_tokens", 0)
                usage["output"] = getattr(u, "completion_tokens", 0)
            continue

        delta = chunk.choices[0].delta

        # Visible text
        if delta.content:
            text += delta.content
            yield {"type": "text_delta", "text": delta.content}

        # Thinking — Ollama uses `reasoning`, not `reasoning_content`
        rc = _extract_reasoning(delta)
        if rc:
            thinking += rc
            yield {"type": "thinking_delta", "thinking": rc}

        # Tool calls — must buffer arguments across chunks
        if delta.tool_calls:
            for tc in delta.tool_calls:
                idx = tc.index
                if idx not in tool_calls:
                    tool_calls[idx] = {
                        "id": tc.id or "",
                        "name": tc.function.name if tc.function else "",
                        "args": "",
                    }
                if tc.function and tc.function.arguments:
                    tool_calls[idx]["args"] += tc.function.arguments

        # Some Ollama builds attach usage on the final non-empty chunk
        u = getattr(chunk, "usage", None)
        if u:
            usage["input"] = getattr(u, "prompt_tokens", 0)
            usage["output"] = getattr(u, "completion_tokens", 0)

    blocks = []
    if thinking:
        blocks.append(ContentBlock(type="thinking", thinking=thinking, signature=""))
    if text:
        blocks.append(ContentBlock(type="text", text=text))
    for tc in tool_calls.values():
        args = json.loads(tc["args"]) if tc["args"] else {}
        blocks.append(ContentBlock(type="tool_use", name=tc["name"], input=args, id=tc["id"]))

    yield {"type": "response", "response": Response(content=blocks), "usage": usage}


# ---------------------------------------------------------------------------
# Main entry point — same signature pattern as models/anthropic.py
# ---------------------------------------------------------------------------

async def o_model_call(
    input: Union[List[Dict[str, Any]], str],
    model: str = None,
    encoded_image: Optional[Union[str, List[str]]] = None,
    tools: Optional[List[Dict[str, Any]]] = None,
    mcp_openai_tools: list = None,
    stream: bool = False,
    thinking: bool = False,
    max_tokens: int = None,
    client_timeout: int = 480,
    pdf: str = None,
    retries: int = 3,
):
    base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434/v1")
    model = model or os.getenv("OLLAMA_MODEL")
    num_ctx = int(os.getenv("OLLAMA_NUM_CTX", "32768"))
    if max_tokens is None:
        max_tokens = int(os.getenv("OLLAMA_MAX_OUTPUT", "4096"))

    client = AsyncOpenAI(
        base_url=base_url,
        api_key="ollama",  # dummy — Ollama ignores the key
        timeout=client_timeout,
    )
    base_sleep = 2

    # ---- Build messages ----
    messages = []
    if pdf:
        messages = [{"role": "user", "content": f"[PDF document attached]\n\n{input}"}]
    elif encoded_image:
        content = []
        imgs = [encoded_image] if isinstance(encoded_image, str) else encoded_image
        for img in imgs:
            content.append({
                "type": "image_url",
                "image_url": {"url": f"data:image/jpeg;base64,{img}"},
            })
        content.append({"type": "text", "text": input})
        messages = [{"role": "user", "content": content}]
    elif isinstance(input, str):
        messages = [{"role": "user", "content": input}]
    else:
        messages = _msgs_to_openai(input)

    # ---- API parameters ----
    # Ollama-specific: num_ctx in extra_body.options, think toggle at root
    extra_body = {"options": {"num_ctx": num_ctx}}
    if thinking:
        extra_body["think"] = True

    api_params = {
        "model": model,
        "max_tokens": max_tokens,
        "stream": stream,
        "messages": messages,
        "extra_body": extra_body,
    }

    if stream:
        api_params["stream_options"] = {"include_usage": True}

    if tools:
        openai_tools = _tools_to_openai(tools, mcp_openai_tools=mcp_openai_tools)
        if openai_tools:
            api_params["tools"] = openai_tools
            api_params["tool_choice"] = "auto"

    # ---- Call with retries ----
    for attempt in range(retries):
        try:
            response = await client.chat.completions.create(**api_params)
            if stream:
                return _wrap_stream(response)
            else:
                return _wrap_response(response)

        except Exception as e:
            import traceback
            print(f"\n[ollama model_call]: {e}", flush=True)
            traceback.print_exc()
            if attempt < retries - 1:
                sleep_time = base_sleep * (2 ** attempt)
                print(
                    f"\n[ollama model_call]: Retrying in {sleep_time}s (attempt {attempt + 1}/{retries})..."
                )
                await asyncio.sleep(sleep_time)
            else:
                print(f"\n[ollama model_call]: Failed after {retries} attempts")

    return None
