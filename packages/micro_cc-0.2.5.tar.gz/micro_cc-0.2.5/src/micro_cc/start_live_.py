import asyncio
import os
import re
import subprocess
import sys
import platform
from micro_cc.claude_loop_ import claude_loop
from micro_cc.utils.msg_store_ import load_msgs, rewind_msgs, summarize_and_trim, store_msgs, erase_msgs, erase_summary
from micro_cc.utils.tokenization_simple import token_stats
from micro_cc.tools.browser_tool_ import close_browser
from micro_cc.utils.process_tracker import init as init_process_tracker
from micro_cc.cache.redis_cache import RedisStateManager
from micro_cc.screens.window_overlay_ import MessageList, MessageRow, StreamingRow, BANNER
from micro_cc.utils.file_watcher_ import FileWatcher
from textual.app import App, ComposeResult
from textual.containers import Vertical, VerticalScroll
from textual.widgets import Static
from textual.binding import Binding
from textual.widgets import TextArea
from textual.message import Message
from textual.widgets import LoadingIndicator
from textual.widgets import OptionList
from collections import deque

# --------------- sleep inhibitor ---------------
# macOS: caffeinate -i  (prevent idle sleep)
# Windows: SetThreadExecutionState  (prevent idle sleep)
# Linux: systemd-inhibit (prevent idle sleep)

def _inhibit_sleep():
    """Start preventing system idle sleep. Returns a handle to pass to _allow_sleep()."""
    _sys = platform.system()
    if _sys == "Darwin":
        return subprocess.Popen(["caffeinate", "-i"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    elif _sys == "Windows":
        try:
            import ctypes
            ES_CONTINUOUS = 0x80000000
            ES_SYSTEM_REQUIRED = 0x00000001
            ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS | ES_SYSTEM_REQUIRED)
        except Exception:
            pass
        return "windows"
    elif _sys == "Linux":
        try:
            return subprocess.Popen(
                ["systemd-inhibit", "--what=idle", "--who=micro-cc", "--why=AI streaming", "sleep", "infinity"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
        except FileNotFoundError:
            return None
    return None

def _allow_sleep(handle):
    """Release the sleep inhibition."""
    if handle is None:
        return
    if isinstance(handle, subprocess.Popen):
        handle.terminate()
        handle.wait()
    elif handle == "windows":
        try:
            import ctypes
            ES_CONTINUOUS = 0x80000000
            ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS)
        except Exception:
            pass

class PromptInput(TextArea):
    """Multiline input: Enter submits, Shift+Enter inserts newline."""

    _paste_store = {}
    _paste_id = 0
    _PASTE_THRESH = 200
    SLASH_COMMANDS = ["/clear", "/copy", "/exit", "/model", "/rewind"]
    BRACKETS = {"(": ")", "[": "]", "{": "}", '"': '"', "'": "'"}

    def _handle_paste(self, text):
        """Intercept large pastes with a placeholder, pass short ones through."""
        if len(text) > self._PASTE_THRESH:
            PromptInput._paste_id += 1
            pid = PromptInput._paste_id
            self._paste_store[pid] = text
            n_lines = text.count('\n') + 1
            self.insert(f"⟪paste:{pid}|{len(text)} chars, {n_lines} lines⟫")
        else:
            self.insert(text)

    async def _on_paste(self, event):
        event.prevent_default()
        self._handle_paste(event.text)

    def update_suggestion(self):
        text = self.text
        if text.startswith("/") and "\n" not in text:
            matches = [c for c in self.SLASH_COMMANDS if c.startswith(text)]
            if matches:
                self.suggestion = matches[0][len(text) :]
                return
        self.suggestion = ""

    async def _on_key(self, event):
        if event.key in ("shift+enter", "ctrl+j"):
            event.prevent_default()
            self.insert("\n")
            return
        if event.key == "tab":
            if self.suggestion:
                self.insert(self.suggestion)
                event.prevent_default()
                event.stop()
                return
        if event.character in self.BRACKETS:
            self.insert(event.character + self.BRACKETS[event.character])
            self.move_cursor_relative(columns=-1)
            event.prevent_default()
        if event.key == "enter":
            event.prevent_default()
            self.post_message(self.Submitted(self))
            return
        await super()._on_key(event)

    class Submitted(Message):
        def __init__(self, textarea):
            super().__init__()
            self.value = textarea.text


class MicroApp(App):

    MODEL_OPTIONS = ["opus-4.7", "sonnet-4.6", "haiku-4.5"]

    _current_model = "sonnet-4.6"
    _trim_budget = 80000

    ALLOW_SELECT = True

    # BINDINGS is a list of tuples that maps (or binds)
    # keys to actions in your app. The first value in
    # the tuple is the key; the second value is the
    # name of the action; the final value
    # is a short description.
    BINDINGS = [
        Binding("escape", "cancel_query", "Interrupt"),
    ]

    # TCSS works

    # Same model as CSS — selectors target Textual's widget DOM tree:
    # ┌───────────┬───────────────────────────┬──────────────────────────┐
    # │ Selector  │          Targets          │         Example          │
    # ├───────────┼───────────────────────────┼──────────────────────────┤
    # │ #id       │ Widget with id="..."      │ #loader, #statusbar      │
    # ├───────────┼───────────────────────────┼──────────────────────────┤
    # │ ClassName │ Widget class name         │ PromptInput, MessageList │
    # ├───────────┼───────────────────────────┼──────────────────────────┤
    # │ .class    │ Widget with classes="..." │ .highlighted             │
    # └───────────┴───────────────────────────┴──────────────────────────┘

    # The styles cascade down the DOM just like CSS. MessageList gets scrollbar styles because Textual widgets with overflow:
    # auto (the default for scrollable containers) automatically render scrollbars — you're just restyling the built-in ones.

    # How to discover what you can style

    # Every Textual widget exposes a set of CSS properties. 

    # For PromptInput (inherits from TextArea):
    # PromptInput {
    #     border: solid white;          /* what you have now */
    #     border: round green;          /* rounded corners, green */
    #     border: double $accent;       /* double-line border */
    #     border: none;                 /* remove it */
    #     background: $surface;
    #     color: $text;
    #     padding: 1 2;                 /* vertical horizontal */
    #     margin: 0 1;
    #     scrollbar-color: white;
    #     cursor-color: white;          /* TextArea-specific: the blinking cursor */
    #     selection-color: $accent;     /* TextArea-specific: selected text bg */
    # }

    # Border styles available: ascii, blank, dashed, double, heavy, hidden, hkey, inner, none, outer, panel, round, solid, tall,
    # vkey, wide

    # Pseudo-classes work too:
    # PromptInput:focus {
    #     border: solid $accent;        /* highlight when focused */
    # }

    # Color tokens — Textual has built-in theme variables: $primary, $secondary, $accent, $surface, $background, $text,
    # $text-muted, $error, $warning, $success, or use direct colors like red, #ff0000, rgb(255,0,0).

    # Quick way to experiment

    # Textual has a live CSS reload. Run with:

    # textual run --dev start_live_.py

    # Then edit microcc-styles.tcss — changes apply instantly without restarting. Also textual CLI has textual colors to preview
    # the palette and textual borders to preview all border styles.

    CSS_PATH = "screens/microcc-styles.tcss"

    def __init__(self, project_dir, watcher, messages):
        super().__init__()
        self._project_dir = project_dir
        self._watcher = watcher
        self.__existing_msgs = messages
        self._state_mgr = RedisStateManager()
        self._loop_msgs = None  # entire loop_msgs owned
        self._msg_rows = []     # ordered list of msg dicts (for /copy + cancel)
        ## user queries queueing
        self._queue = deque()
        self._query_active = False
        init_process_tracker()

    _pending_approval = None  # asyncio.Event when waiting
    _approval_result = None # True/False bool
    _streaming = None       # active StreamingRow widget

    def on_paste(self, event) -> None:
        prompt = self.query_one(PromptInput)
        if not prompt.has_focus:
            event.prevent_default()
            event.stop()
            prompt.focus()
            prompt._handle_paste(event.text)

    def get_rewind_options(self, messages):
        """Last 10 user messages for the rewind picker, oldest-first, 80-char labels."""
        options = []
        for msg in messages:
            if msg.get("role") != "user":
                continue
            content = msg.get("content", "")
            if not isinstance(content, str) or content.strip().startswith("<system-reminder>"):
                continue
            options.append(content.strip().replace("\n", " ")[:80])
        return options[-10:]

    def compose(self) -> ComposeResult:
        yield Static(BANNER)  # always at top
        with VerticalScroll(id="messages-scroll"):
            yield MessageList()
        with Vertical(id="bottom-bar"):
            yield LoadingIndicator(id="loader")
            yield OptionList(*MicroApp.MODEL_OPTIONS, id="model-picker")
            yield OptionList(id="rewind-picker")
            yield PromptInput(id="prompt")
            yield Static("", id="statusbar")

    def _status_text(self):
        s = f"⏣ {self._project_dir} | ◈ {self._current_model}"
        if token_stats["input"]:
            t = token_stats
            s += f" | in: {t['input']:,}"
            if t["trimmed"]:
                s += f" (cut {t['trimmed']:,})"
            s += f"/{t['max']:,} out: {t['output']:,}"
        s += " | ⌥+click to select"
        return s

    def _refresh_status(self):
        self.query_one("#statusbar", Static).update(self._status_text())

    def _scroll_to_bottom(self):
        scroller = self.query_one("#messages-scroll")
        if scroller.scroll_y >= scroller.max_scroll_y - 1:
            scroller.scroll_end(animate=False)

    async def _mount_row(self, msg: dict) -> MessageRow:
        """Mount a new MessageRow into the message list container."""
        row = MessageRow(msg)
        self._msg_rows.append(msg)
        await self.query_one(MessageList).mount(row)
        self._scroll_to_bottom()
        return row

    def _finalize_streaming(self):
        """Convert active StreamingRow into a permanent MessageRow."""
        if self._streaming is not None:
            content = self._streaming.get_content()
            mode = self._streaming._mode
            self._streaming.remove()
            self._streaming = None
            if content.strip():
                msg = {"type": mode, "content": content}
                row = MessageRow(msg)
                self._msg_rows.append(msg)
                self.query_one(MessageList).mount(row)

    def action_cancel_query(self):
        # If a picker is open, ESC just closes it — no cancel
        for picker_id in ("#model-picker", "#rewind-picker"):
            picker = self.query_one(picker_id)
            if picker.display:
                picker.display = False
                self.query_one(PromptInput).focus()
                return

        self.workers.cancel_all()
        # Clear pending approval so next submit isn't swallowed
        if self._pending_approval is not None:
            self._pending_approval.set()
        self._pending_approval = None
        self._approval_result = None
        if self._loop_msgs is not None:
            # Capture partial streaming text from UI into API msgs
            if self._streaming is not None:
                partial = self._streaming.get_content().strip()
                if partial:
                    self._loop_msgs.append({"role": "assistant", "content": partial})
            self._finalize_streaming()
            store_msgs(self._project_dir, self._loop_msgs)
        err = {"type": "error", "content": " interrupted"}
        self._msg_rows.append(err)
        self.query_one(MessageList).mount(MessageRow(err))
        self._scroll_to_bottom()
        self.query_one("#loader").display = False

        ## clean queue
        for _, row in self._queue:
            row.remove()
        self._queue.clear()

        # self.query_one(PromptInput).disabled = False ### now we are queueing always user msgs
        self.query_one(PromptInput).focus()

    async def on_mount(self):
        # Start background services
        self._watcher.start()
        self._state_mgr.start_cleanup_task()

        # Status bar
        self._refresh_status()

        # Load history — mount each as a MessageRow widget
        history_msgs = []
        for msg in self.__existing_msgs:
            role = msg.get("role")
            content = msg.get("content", "")

            if role == "system":
                continue

            if role == "user":
                if isinstance(content, str) and not content.startswith(
                    "<system-reminder>"
                ):
                    history_msgs.append({"type": "user", "content": content.strip()})
                elif isinstance(content, list):
                    for block in content:
                        if (
                            isinstance(block, dict)
                            and block.get("type") == "tool_result"
                        ):
                            out = str(block.get("content", ""))[:200]
                            history_msgs.append(
                                {"type": "tool_call", "name": "tool", "result": out.strip()}
                            )

            elif role == "assistant":
                if isinstance(content, str):
                    history_msgs.append({"type": "text", "content": content})
                elif isinstance(content, list):
                    for block in content:
                        if isinstance(block, dict):
                            if block.get("type") == "text":
                                history_msgs.append(
                                    {"type": "text", "content": block["text"]}
                                )
                            elif block.get("type") == "tool_use":
                                history_msgs.append(
                                    {"type": "tool_call", "name": block["name"], "result": "·"}
                                )

        # Batch mount all history rows at once (much faster than one-by-one)
        container = self.query_one(MessageList)
        rows = [MessageRow(m) for m in history_msgs]
        self._msg_rows = history_msgs
        await container.mount_all(rows)
        self.call_after_refresh(lambda: self.query_one("#messages-scroll").scroll_end(animate=False))

    # PromptInput posts a custom message at line 49:
    # self.post_message(self.Submitted(self))
    # Textual's message dispatch rule:
    # 1. Takes the widget class name → PromptInput → snake_case → prompt_input
    # 2. Takes the message class name → Submitted → snake_case → submitted
    # 3. Looks for on_{widget}_{message} → on_prompt_input_submitted
    # The message bubbles up the DOM (widget → parent → screen → app) until something handles it. Since MicroApp defines
    # on_prompt_input_submitted, it catches it at the app level.
    # So three dispatch mechanisms:
    # ┌────────────────────┬──────────────────────────────┬─────────────────────────────┐
    # │     Mechanism      │          Convention          │           Example           │
    # ├────────────────────┼──────────────────────────────┼─────────────────────────────┤
    # │ Key events         │ _on_key() override           │ PromptInput._on_key()       │
    # ├────────────────────┼──────────────────────────────┼─────────────────────────────┤
    # │ Bindings → Actions │ action_{name} method         │ action_cancel_query()       │
    # ├────────────────────┼──────────────────────────────┼─────────────────────────────┤
    # │ Messages           │ on_{widget}_{message} method │ on_prompt_input_submitted() │
    # └────────────────────┴──────────────────────────────┴─────────────────────────────┘

    # class PromptInput(TextArea):         # inherit from TextArea
    #     class Submitted(Message):        # define a custom Message class, nested
    #         ...

    #     async def _on_key(self, event):                    # override key handler
    #         if event.key == "enter":
    #             self.post_message(self.Submitted(self))    # emit our custom message

    # Three things to understand:

    # A) _on_key is a method, not a class. It's a function defined on Widget (the base of every Textual widget). Its signature is async
    # def _on_key(self, event: events.Key). When the user presses a key, Textual calls this method on the focused widget. You override
    # it in your subclass to do something custom.

    # You didn't see it in the TextArea docs because it's inherited from Widget, not defined on TextArea. The Widget class has hooks
    # like _on_key, _on_mount, _on_click, _on_focus, etc. — one for every low-level event. Any widget can override them.

    # B) class Submitted(Message) is a nested class declaration. It's just a class, happens to be defined inside another class for
    # namespacing. It inherits from Message (Textual's base event class). By living inside PromptInput, it becomes accessible as
    # PromptInput.Submitted or self.Submitted — and Textual's dispatcher knows to map it to on_prompt_input_submitted.

    # Why nest it? Convention. It groups the message with the widget that emits it. PromptInput.Submitted reads naturally: "the
    # Submitted message for PromptInput."

    # C) self.post_message(self.Submitted(self)) — three parts:

    # - self.Submitted(self) — construct a new instance of the nested Submitted class. The argument self is the PromptInput instance
    # being passed to Submitted.__init__ (look at your code: def __init__(self, textarea): super().__init__(); self.value =
    # textarea.text). So the message carries a reference to the text area.
    # - self.post_message(...) — emit that message into the bubble system. post_message is a method defined on MessagePump (which Widget
    # inherits from). It takes one argument: a Message instance. It puts the message on the event queue, which then bubbles it up the
    # DOM tree. This is the only way widgets communicate with their ancestors.

    # So the whole line reads: "Create a Submitted message carrying a reference to me, and send it upward." Then somewhere up the tree
    # (in MicroApp), on_prompt_input_submitted catches it and reads event.value.

    # 3. query_one, run_worker — where do these come from?

    # They're inherited, not App-specific. Here's the hierarchy:

    # MessagePump                    ← event queue, post_message
    #     └── DOMNode                  ← tree membership, query_one, workers, run_worker
    #         ├── Widget              ← rendering, focus, _on_key, mount
    #         │    └── TextArea
    #         │         └── PromptInput
    #         │    └── OptionList, Static, Button, ...
    #         └── App                 ← the root node
    #             └── MicroApp

    # Both Widget and App inherit from DOMNode. That's why the same methods work on both:

    # ┌─────────────────────┬─────────────┬───────────────────────────────────────────────────────────┐
    # │       Method        │ Defined in  │                       Available on                        │
    # ├─────────────────────┼─────────────┼───────────────────────────────────────────────────────────┤
    # │ query_one(selector) │ DOMNode     │ Any widget AND the app                                    │
    # ├─────────────────────┼─────────────┼───────────────────────────────────────────────────────────┤
    # │ query(selector)     │ DOMNode     │ Any widget AND the app                                    │
    # ├─────────────────────┼─────────────┼───────────────────────────────────────────────────────────┤
    # │ run_worker(...)     │ DOMNode     │ Any widget AND the app                                    │
    # ├─────────────────────┼─────────────┼───────────────────────────────────────────────────────────┤
    # │ workers (attribute) │ DOMNode     │ Any widget AND the app                                    │
    # ├─────────────────────┼─────────────┼───────────────────────────────────────────────────────────┤
    # │ mount(widget)       │ Widget      │ Any widget AND the app                                    │
    # ├─────────────────────┼─────────────┼───────────────────────────────────────────────────────────┤
    # │ post_message(msg)   │ MessagePump │ Any widget AND the app                                    │
    # ├─────────────────────┼─────────────┼───────────────────────────────────────────────────────────┤
    # │ _on_key             │ Widget      │ Only widgets (App handles keys differently, via bindings) │
    # ├─────────────────────┼─────────────┼───────────────────────────────────────────────────────────┤
    # │ action_*            │ DOMNode     │ Any widget AND the app (triggered by bindings)            │
    # ├─────────────────────┼─────────────┼───────────────────────────────────────────────────────────┤
    # │ CSS_PATH, BINDINGS  │ DOMNode     │ Class-level on App or any widget                          │
    # └─────────────────────┴─────────────┴───────────────────────────────────────────────────────────┘

    # So when you write self.query_one("#loader") inside MicroApp, it works because App inherits query_one from DOMNode. But the same
    # call inside a Widget subclass would also work — it searches from that widget's position in the tree, not from the root.

    # self.run_worker(self.do_query(query), exclusive=True) — run_worker is on DOMNode. It spawns a background async task. The
    # exclusive=True flag cancels any previous worker on the same node before starting this one.

    async def on_prompt_input_submitted(self, event):
        # replaces your prompt_toolkit loop
        query = event.value.strip()
        query = re.sub(
            r'⟪paste:(\d+)\|\d+ chars, \d+ lines⟫',
            lambda m: PromptInput._paste_store.get(int(m.group(1)), m.group(0)),
            query,
        )
        PromptInput._paste_store.clear()
        PromptInput._paste_id = 0
        if self._pending_approval is not None and not self._pending_approval.is_set():
            self._approval_result = query.lower() in ("", "y", "yes")
            self._pending_approval.set()
            self.query_one(PromptInput).clear()
            return
        if not query:
            return
        # Slash commands
        if query.lower() in ("/exit", "/quit"):
            self.exit()  # Textual's built-in — closes app, returns from app.run()
            return

        if query.lower() == "/clear":
            erase_msgs(self._project_dir)
            erase_summary(self._project_dir)
            import shutil
            await close_browser()
            for ss_folder in (".browser_screenshots", ".computer_screenshots"):
                ss_dir = os.path.join(self._project_dir, ss_folder)
                if os.path.isdir(ss_dir):
                    shutil.rmtree(ss_dir)
            # Remove all MessageRow widgets and clear backing data
            container = self.query_one(MessageList)
            await container.remove_children()
            self._msg_rows = []
            self._finalize_streaming()
            token_stats.update(input=0, output=0, trimmed=0, max=0)
            self._refresh_status()
            self.query_one("#statusbar", Static).update("⇤ all messages erased")
            await asyncio.sleep(1.5)
            self.query_one("#statusbar", Static).update(self._status_text())
            self.query_one(PromptInput).clear()
            return

        if query.lower() == "/copy":
            lines = []
            for msg in self._msg_rows:
                t = msg["type"]
                if t == "user":
                    lines.append(f"› {msg['content']}")
                elif t == "text":
                    lines.append(msg["content"])
                elif t == "thinking":
                    lines.append(f"[thinking] {msg['content']}")
                elif t == "tool_call":
                    result = msg.get("result") or "⋯"
                    lines.append(f"⟐ {msg['name']} → {result}")
                elif t == "error":
                    lines.append(f"△ {msg['content']}")
            # Include streaming content if active
            if self._streaming is not None:
                content = self._streaming.get_content()
                if content.strip():
                    lines.append(content)
            text = "\n\n".join(lines)
            self.copy_to_clipboard(text)
            self.query_one("#statusbar", Static).update("✓ Copied to clipboard")
            await asyncio.sleep(1.5)
            self.query_one("#statusbar", Static).update(self._status_text())
            self.query_one(PromptInput).clear()
            return

        if query.lower() == "/model":
            picker = self.query_one("#model-picker")
            picker.display = True
            picker.focus()
            self.query_one(PromptInput).clear()
            return

        if query.lower() == "/rewind":
            rewind_picker = self.query_one("#rewind-picker")
            rewind_picker.clear_options()
            msgs = load_msgs(self._project_dir)
            for label in self.get_rewind_options(msgs):
                rewind_picker.add_option(label)
            rewind_picker.display = True
            rewind_picker.focus()
            self.query_one(PromptInput).clear()
            return

        if self._query_active:
            row = await self._mount_row(
                {"type": "user_queued", "content": query}
            )  # render as dim pending
            self._queue.append((query, row))
            self.query_one(PromptInput).clear()
            return

        # Normal query — mount user message row, then run loop
        await self._mount_row({"type": "user", "content": query})
        self.query_one(PromptInput).clear()
        self._query_active = True
        self.run_worker(self.do_query(query), exclusive=True)

    async def on_option_list_option_selected(self, event: OptionList.OptionSelected):
        picker_id = event.option_list.id

        if picker_id == "model-picker":
            self._current_model = str(event.option.prompt)
            self.query_one("#model-picker").display = False
            self._refresh_status()
            self.query_one(PromptInput).focus()

        elif picker_id == "rewind-picker":
            content_prefix = str(event.option.prompt)
            self.query_one("#rewind-picker").display = False

            # Truncate JSONL and get remaining messages
            remaining = rewind_msgs(self._project_dir, content_prefix)

            # Clear UI and re-render from remaining messages
            container = self.query_one(MessageList)
            await container.remove_children()
            self._msg_rows = []
            self._finalize_streaming()

            # Re-mount history (same logic as on_mount)
            history_msgs = []
            for msg in remaining:
                role = msg.get("role")
                content = msg.get("content", "")
                if role == "system":
                    continue
                if role == "user":
                    if isinstance(content, str) and not content.startswith("<system-reminder>"):
                        history_msgs.append({"type": "user", "content": content.strip()})
                    elif isinstance(content, list):
                        for block in content:
                            if isinstance(block, dict) and block.get("type") == "tool_result":
                                out = str(block.get("content", ""))[:200]
                                history_msgs.append({"type": "tool_call", "name": "tool", "result": out.strip()})
                elif role == "assistant":
                    if isinstance(content, str):
                        history_msgs.append({"type": "text", "content": content})
                    elif isinstance(content, list):
                        for block in content:
                            if isinstance(block, dict):
                                if block.get("type") == "text":
                                    history_msgs.append({"type": "text", "content": block["text"]})
                                elif block.get("type") == "tool_use":
                                    history_msgs.append({"type": "tool_call", "name": block["name"], "result": "·"})

            rows = [MessageRow(m) for m in history_msgs]
            self._msg_rows = history_msgs
            await container.mount_all(rows)

            # Put the rewound message text into prompt for re-submission
            prompt = self.query_one(PromptInput)
            prompt.clear()
            prompt.insert(content_prefix)
            prompt.focus()
            self._refresh_status()

    async def do_query(self, query):
        self.query_one("#loader").display = True

        # self.query_one(PromptInput).disabled = True ## now we are queueing all user msgs

        self._loop_msgs = load_msgs(self._project_dir)
        container = self.query_one(MessageList)

        # Track tool_call rows by ID for targeted updates
        tool_call_rows = {}       # tool_id → MessageRow
        approval_rows = {}        # tool_id → MessageRow

        sleep_handle = _inhibit_sleep()
        try:
            async for event in claude_loop(
                query=query,
                msgs=self._loop_msgs,
                project_dir=self._project_dir,
                watcher=self._watcher,
                model=self._current_model,
                max_tokens=self._trim_budget,
            ):
                etype = event.get("type")

                # Persist only when msgs actually changed
                if etype in ("tool_call", "tool_result", "final_text", "done", "error"):
                    store_msgs(self._project_dir, self._loop_msgs)

                if etype in ("text_delta", "thinking_delta", "tool_call", "tool_result"):
                    self.query_one("#loader").display = False
                    self._refresh_status()

                if etype == "text_delta":
                    # Mount StreamingRow if not active, or switch mode
                    if self._streaming is None or self._streaming._mode != "text":
                        self._finalize_streaming()
                        self._streaming = StreamingRow(mode="text")
                        await container.mount(self._streaming)
                    # Per-char animation — only StreamingRow re-renders (cheap)
                    for ch in event.get("content", ""):
                        self._streaming.append(ch)
                        self._streaming.flush_display()
                        self._scroll_to_bottom()
                        await asyncio.sleep(0.01)

                elif etype == "thinking_delta":
                    if self._streaming is None or self._streaming._mode != "thinking":
                        self._finalize_streaming()
                        self._streaming = StreamingRow(mode="thinking")
                        await container.mount(self._streaming)
                    for ch in event.get("content", ""):
                        self._streaming.append(ch)
                        self._streaming.flush_display()
                        self._scroll_to_bottom()
                        await asyncio.sleep(0.01)

                elif etype == "tool_call":
                    # Finalize any streaming text before tool call
                    self._finalize_streaming()
                    msg = {
                        "type": "tool_call",
                        "name": event.get("name", "?"),
                        "id": event.get("id"),
                        "result": None,
                    }
                    row = MessageRow(msg)
                    self._msg_rows.append(msg)
                    tool_call_rows[event.get("id")] = (row, msg)
                    await container.mount(row)
                    self._scroll_to_bottom()

                elif etype == "tool_result":
                    tool_id = event.get("id")
                    if tool_id in tool_call_rows:
                        row, msg = tool_call_rows[tool_id]
                        msg["result"] = event.get("output", "")[:40]
                        row.update_msg(msg)  # targeted re-render of just this row
                    self._refresh_status()
                    self.query_one("#loader").display = True

                elif etype == "approval_request":
                    approval = event.get("approval")
                    tool_id = event.get("id")
                    name = event.get("name", "")
                    inp = event.get("input", {})

                    msg = {"type": "approval", "id": tool_id, "name": name, "input": inp}
                    row = MessageRow(msg)
                    approval_rows[tool_id] = row
                    self._msg_rows.append(msg)
                    await container.mount(row)
                    self._scroll_to_bottom()

                    self.query_one(PromptInput).focus()
                    self._pending_approval = asyncio.Event()
                    self._approval_result = None
                    await self._pending_approval.wait()

                    approval["approved"] = self._approval_result
                    if tool_id in approval_rows:
                        arow = approval_rows.pop(tool_id)
                        if not self._approval_result:
                            new_msg = {"type": "error", "content": f" {name} cancelled"}
                            arow.update_msg(new_msg)
                            # Update backing data too
                            for i, m in enumerate(self._msg_rows):
                                if m.get("type") == "approval" and m.get("id") == tool_id:
                                    self._msg_rows[i] = new_msg
                                    break
                        else:
                            arow.remove()
                            self._msg_rows = [m for m in self._msg_rows if not (m.get("type") == "approval" and m.get("id") == tool_id)]
                    self._pending_approval = None

                elif etype == "final_text":
                    self._finalize_streaming()
                    asyncio.create_task(summarize_and_trim(self._project_dir, self._loop_msgs))

                elif etype == "error":
                    self._finalize_streaming()
                    err = {"type": "error", "content": event.get("message", "Unknown error")}
                    self._msg_rows.append(err)
                    await container.mount(MessageRow(err))
                    self._scroll_to_bottom()

                elif etype == "done":
                    self._finalize_streaming()

        except asyncio.CancelledError:
            if self._loop_msgs is not None:
                store_msgs(self._project_dir, self._loop_msgs)
            self._finalize_streaming()
            err = {"type": "error", "content": " interrupted"}
            self._msg_rows.append(err)
            await container.mount(MessageRow(err))
            self._scroll_to_bottom()
        finally:
            _allow_sleep(sleep_handle)
            self._pending_approval = None
            self._finalize_streaming()
            self.query_one("#loader").display = False

            # self.query_one(PromptInput).disabled = False ## now we are queueing all user msgs

            self.query_one(PromptInput).focus()
            self._refresh_status()
            self._query_active = False

            if self._queue:
                next_q, next_row = self._queue.popleft()
                next_row.update_msg({"type": "user", "content": next_q})  # promote visually
                self._query_active = True
                self.run_worker(self.do_query(next_q), exclusive=True)

    def on_unmount(self):
        self._watcher.stop()
        self._state_mgr.stop_cleanup_task()


OLLAMA_ENV_BLOCK = """\
# OR Option 3 Ollama (local open-weight main loop)
#   Install: brew install ollama && brew services start ollama
#   Pull a model — pick one that fits your RAM:
#     ollama pull qwen3:4b           (2.5GB, any Mac — smoke test baseline)
#     ollama pull qwen3:8b           (5.2GB, good on 16GB+)
#     ollama pull qwen3:14b          (9.3GB, needs 24GB+ comfortably)
#     ollama pull qwen3-coder:30b    (19GB MoE, needs 36GB+, best coder)
#   Then uncomment below and set OLLAMA_MODEL to the tag you pulled.
# OLLAMA_BASE_URL=http://localhost:11434/v1
# OLLAMA_MODEL=qwen3:4b
#
#   Context budget — local models are much smaller than Sonnet (200K).
#   KV cache grows linearly with context. Smaller model = more headroom.
#     qwen3:4b   → NUM_CTX=16384, TRIM=12288  (safe everywhere)
#     qwen3:8b   → NUM_CTX=24576, TRIM=20480
#     qwen3:14b  → NUM_CTX=32768, TRIM=28000  (36GB Macs only)
# OLLAMA_NUM_CTX=16384
# OLLAMA_MAX_OUTPUT=4096
# MICRO_CC_TRIM_BUDGET=12288
#
#   IMPORTANT — Ollama handles only the main reasoning loop. Vision, web
#   search, and semantic tool discovery still hit cloud APIs. You must keep
#   OPENAI_API_KEY set even when using Ollama:
#     - search_tools uses embeddings (OpenAI text-embedding-3-small)
#     - vision tool disabled on Ollama
#   OPENAI_API_KEY=sk-proj-...
"""


ENV_EXAMPLE = f"""\
# Choose one only:
# Choose which to use uncomment by removing # and add API keys

# Option 1 Anthropic for models + OpenAI for embeddings
# ANTHROPIC_API_KEY=sk-ant-
# OPENAI_API_KEY=sk-proj-

# OR Option 2 if using LiteLLM proxy for Bedrock Anthropic
# LITELLM_BASE_URL=https://your-proxy.com
# LITELLM_API_KEY=sk-...

{OLLAMA_ENV_BLOCK}
# Shared always needed for web-search
# SERPAPI_KEY=
"""


from importlib.metadata import version as _pkg_version
__version__ = _pkg_version("micro-cc")


def _ensure_home_dir():
    """Create ~/.micro-cc with example .env on first run.

    For existing installs, append new option blocks (e.g. Ollama) to the
    user's .env non-destructively — we only append if the sentinel string
    is absent. Their existing keys and customizations are untouched.
    """
    home = os.path.expanduser("~/.micro-cc")
    os.makedirs(os.path.join(home, "projects"), exist_ok=True)
    env_path = os.path.join(home, ".env")

    if not os.path.exists(env_path):
        with open(env_path, "w") as f:
            f.write(ENV_EXAMPLE)
        print(f"\n  Created {env_path} — add your API keys before starting.\n")
        sys.exit(0)

    # Upgrade path — existing .env, append new option blocks if missing.
    with open(env_path) as f:
        current = f.read()

    if "OLLAMA_BASE_URL" not in current:
        with open(env_path, "a") as f:
            if not current.endswith("\n"):
                f.write("\n")
            f.write("\n" + OLLAMA_ENV_BLOCK)
        print(f"\n  ✓ micro-cc added a new option to {env_path}")
        print("    Option 3: Ollama (local open-weight models). Your existing")
        print("    config is untouched — open the file to review the new block.\n")


def _preflight_ollama():
    """Validate Ollama setup when OLLAMA_BASE_URL is set.

    Checks: OLLAMA_MODEL set, daemon reachable, model pulled.
    Prints friendly onboarding on failure, exits cleanly.
    Returns (model, trim_budget) for the caller to apply to MicroApp.
    """
    import urllib.request
    import json as _json

    base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434/v1")
    tags_url = base_url.rstrip("/").removesuffix("/v1") + "/api/tags"
    model = os.getenv("OLLAMA_MODEL")

    if not model:
        print("\n[micro-cc] Ollama selected but OLLAMA_MODEL is not set.")
        print("[micro-cc] Edit ~/.micro-cc/.env and set e.g. OLLAMA_MODEL=qwen3:14b\n")
        sys.exit(1)

    try:
        with urllib.request.urlopen(tags_url, timeout=2) as resp:
            data = _json.loads(resp.read())
    except Exception:
        print(f"\n[micro-cc] Ollama daemon not reachable at {base_url}")
        print("[micro-cc] Install and start Ollama:")
        print("           brew install ollama")
        print("           brew services start ollama   # auto-starts on login, runs in background")
        print("[micro-cc] Then pull the model you want:")
        print(f"           ollama pull {model}\n")
        sys.exit(1)

    tags = [m.get("name", "") for m in data.get("models", [])]
    if model not in tags:
        print(f"\n[micro-cc] Ollama model '{model}' is not pulled on this machine.")
        print(f"[micro-cc] Run: ollama pull {model}")
        if tags:
            print("[micro-cc] Currently pulled:")
            for t in tags:
                print(f"           {t}")
        print()
        sys.exit(1)

    num_ctx = int(os.getenv("OLLAMA_NUM_CTX", "32768"))
    max_out = int(os.getenv("OLLAMA_MAX_OUTPUT", "4096"))
    trim = int(os.getenv("MICRO_CC_TRIM_BUDGET", str(max(num_ctx - max_out, 4096))))

    print(f"\n[micro-cc] ✓ Ollama ready — model={model}")
    print(f"[micro-cc]   num_ctx={num_ctx}  trim_budget={trim}  max_output={max_out}")
    print("[micro-cc]   Local models have much smaller context than Sonnet (200K).")
    print("[micro-cc]   Qwen3 native is 40K — we reserve 32K input + 4K output so KV cache")
    print("[micro-cc]   fits in RAM. Context will fill faster. Override via OLLAMA_NUM_CTX /")
    print("[micro-cc]   MICRO_CC_TRIM_BUDGET in ~/.micro-cc/.env.\n")

    return model, trim


def _check_update():
    """Check PyPI for newer version, auto-upgrade if available."""
    try:
        import subprocess
        import json
        from urllib.request import urlopen
        resp = urlopen("https://pypi.org/pypi/micro-cc/json", timeout=3)
        latest = json.loads(resp.read()).get("info", {}).get("version", "")
        if latest and latest != __version__:
            print(f"\n  ⬆ Updating micro-cc {__version__} → {latest}...")
            subprocess.run(
                [sys.executable, "-m", "pip", "install", "--upgrade", "micro-cc", "-q"],
                check=True,
            )
            print("  ✓ Updated. Restarting...\n")
            os.execv(sys.executable, [sys.executable] + sys.argv)
    except Exception:
        pass  # offline or PyPI unreachable — continue normally


def start_():
    _ensure_home_dir()
    _check_update()

    from micro_cc.utils.helpers import get_endpoint
    if get_endpoint() == "Ollama":
        ollama_model, ollama_trim = _preflight_ollama()
        MicroApp._current_model = ollama_model
        MicroApp.MODEL_OPTIONS = [ollama_model]
        MicroApp._trim_budget = ollama_trim

    if len(sys.argv) > 1:
        project_dir = os.path.abspath(sys.argv[1])
    else:
        project_dir = os.getcwd()

    existing_msgs = load_msgs(project_dir)
    watcher = FileWatcher(project_dir)

    app = MicroApp(project_dir, watcher=watcher, messages=existing_msgs)
    app.run()


if __name__ == "__main__":
    start_()
