from __future__ import annotations

import hashlib
import os
import shutil
from pathlib import Path
from typing import Optional

HASH_CHUNK_SIZE = 1024 * 1024
PREFIX_SIZE = 256
_MISSING = object()
_OPEN_FLAGS = os.O_RDONLY | getattr(os, "O_BINARY", 0)


def _normalize_root_dir(folder_path):
    root_dir = Path(folder_path).expanduser().resolve()
    if not root_dir.exists():
        raise FileNotFoundError(f"Folder does not exist: {root_dir}")
    if not root_dir.is_dir():
        raise NotADirectoryError(f"Path is not a folder: {root_dir}")
    return root_dir


def _normalize_duplicates_dir(root_dir, duplicates_dir):
    if duplicates_dir is None:
        return None

    duplicates_path = Path(duplicates_dir).expanduser()
    if not duplicates_path.is_absolute():
        duplicates_path = root_dir / duplicates_path

    duplicates_path = duplicates_path.resolve()
    if duplicates_path == root_dir:
        raise ValueError("duplicates_dir cannot be the same as folder_path")
    if duplicates_path.exists() and not duplicates_path.is_dir():
        raise NotADirectoryError(f"duplicates_dir is not a folder: {duplicates_path}")
    return duplicates_path


def _normalized_fs_path(path):
    return os.path.normcase(os.path.abspath(os.fspath(path)))


def _is_under_normalized_path(path, parent_path):
    normalized_path = _normalized_fs_path(path)
    return normalized_path == parent_path or normalized_path.startswith(parent_path + os.sep)


def _iter_files(root_dir, recursive, duplicates_dir):
    skip_dir = _normalized_fs_path(duplicates_dir) if duplicates_dir is not None else None
    folders = [os.fspath(root_dir)]

    while folders:
        folder = folders.pop()
        try:
            with os.scandir(folder) as entries:
                for entry in entries:
                    try:
                        if entry.is_dir(follow_symlinks=False):
                            if recursive and (skip_dir is None or not _is_under_normalized_path(entry.path, skip_dir)):
                                folders.append(entry.path)
                            continue

                        if not entry.is_file(follow_symlinks=False):
                            continue
                        if skip_dir is not None and _is_under_normalized_path(
                            entry.path,
                            skip_dir,
                        ):
                            continue

                        stat_result = entry.stat(follow_symlinks=False)
                    except OSError:
                        continue

                    yield entry.path, stat_result.st_size
        except OSError:
            continue


def _calculate_md5(file_path):
    with open(file_path, "rb") as file_obj:
        if hasattr(hashlib, "file_digest"):
            return hashlib.file_digest(file_obj, "md5").digest()

        md5 = hashlib.md5()
        while chunk := file_obj.read(HASH_CHUNK_SIZE):
            md5.update(chunk)
    return md5.digest()


def _read_prefix(file_path, file_size):
    read_size = min(PREFIX_SIZE, file_size)
    fd = os.open(file_path, _OPEN_FLAGS)
    try:
        return os.read(fd, read_size)
    finally:
        os.close(fd)


def _add_to_group(groups, key, file_path):
    stored = groups.get(key, _MISSING)
    if stored is _MISSING:
        groups[key] = file_path
    elif isinstance(stored, list):
        stored.append(file_path)
    else:
        groups[key] = [stored, file_path]


def _group_files_by_size(root_dir, recursive, duplicates_dir):
    size_to_files = {}
    total_files = 0

    for file_path, file_size in _iter_files(root_dir, recursive, duplicates_dir):
        total_files += 1
        _add_to_group(size_to_files, file_size, file_path)

    return size_to_files, total_files


def _build_available_path(target_path):
    if not target_path.exists():
        return target_path

    suffix_index = 1
    while True:
        candidate = target_path.with_name(f"{target_path.stem}__dup{suffix_index}{target_path.suffix}")
        if not candidate.exists():
            return candidate
        suffix_index += 1


def _build_move_target(root_dir, duplicates_dir, duplicate_path):
    relative_path = Path(duplicate_path).relative_to(root_dir)
    target_path = duplicates_dir / relative_path
    return _build_available_path(target_path)


def _handle_duplicate(root_dir, duplicates_path, duplicate_path, dry_run):
    if duplicates_path is None:
        if not dry_run:
            os.remove(duplicate_path)
        return

    move_target = _build_move_target(root_dir, duplicates_path, duplicate_path)
    if not dry_run:
        move_target.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(duplicate_path, str(move_target))


def _process_same_prefix_files(root_dir, duplicates_path, file_paths, file_size, dry_run):
    md5_to_path = {}
    duplicate_hashes = set()
    duplicate_files = 0
    reclaimed_bytes = 0

    for file_path in file_paths:
        file_hash = _calculate_md5(file_path)
        kept_path = md5_to_path.get(file_hash)

        if kept_path is None:
            md5_to_path[file_hash] = file_path
            continue

        duplicate_files += 1
        reclaimed_bytes += file_size
        duplicate_hashes.add(file_hash)
        _handle_duplicate(root_dir, duplicates_path, file_path, dry_run)

    return duplicate_files, len(duplicate_hashes), reclaimed_bytes


def _process_same_size_files(root_dir, duplicates_path, file_paths, file_size, dry_run):
    prefix_to_files = {}
    duplicate_files = 0
    duplicate_groups = 0
    reclaimed_bytes = 0

    for file_path in file_paths:
        _add_to_group(prefix_to_files, _read_prefix(file_path, file_size), file_path)

    for same_prefix_files in prefix_to_files.values():
        if not isinstance(same_prefix_files, list):
            continue

        result = _process_same_prefix_files(
            root_dir,
            duplicates_path,
            same_prefix_files,
            file_size,
            dry_run,
        )
        duplicate_files += result[0]
        duplicate_groups += result[1]
        reclaimed_bytes += result[2]

    return duplicate_files, duplicate_groups, reclaimed_bytes


def md5unique(
    folder_path: str | Path,
    recursive: bool = True,
    duplicates_dir: Optional[Path] = None,
    dry_run: bool = False,
):
    """
    对指定文件夹中的文件按 MD5 去重。

    处理规则：
    1. 先按文件大小分组，只有大小相同的文件才继续处理。
    2. 同大小文件先比较前 256 字节，用来快速缩小候选范围。
    3. 前 256 字节相同的候选再计算完整文件 MD5。
    4. 完整文件 MD5 相同则认为重复，只保留首次扫描到的文件。
    5. 重复文件默认删除；传入 `duplicates_dir` 时移动到该目录。

    Args:
        - folder_path: 要去重的目标文件夹路径。
        - recursive: 是否递归扫描子目录，默认为 True。
        - duplicates_dir: 重复文件移动到的目录；为 None 时表示直接删除重复文件。
        - dry_run: 是否只预演不实际删除或移动，默认为 False。

    Returns:
        - dict，包含扫描目录、总文件数、唯一文件数、重复文件数、重复组数、可回收字节数等汇总信息。
    """

    root_dir = _normalize_root_dir(folder_path)
    duplicates_path = _normalize_duplicates_dir(root_dir, duplicates_dir)
    size_to_files, total_files = _group_files_by_size(root_dir, recursive, duplicates_path)

    reclaimed_bytes = 0
    duplicate_files = 0
    duplicate_groups = 0

    for file_size, same_size_files in size_to_files.items():
        if not isinstance(same_size_files, list):
            continue

        result = _process_same_size_files(
            root_dir,
            duplicates_path,
            same_size_files,
            file_size,
            dry_run,
        )
        duplicate_files += result[0]
        duplicate_groups += result[1]
        reclaimed_bytes += result[2]

    return {
        "root_dir": str(root_dir),
        "total_files": total_files,
        "unique_files": total_files - duplicate_files,
        "duplicate_files": duplicate_files,
        "duplicate_groups": duplicate_groups,
        "reclaimed_bytes": reclaimed_bytes,
        "dry_run": dry_run,
        "duplicates_dir": str(duplicates_path) if duplicates_path else None,
    }


if __name__ == "__main__":
    import time
    from pathlib import Path

    dir_path = Path("images")
    subdir = [d for d in dir_path.iterdir() if d.is_dir()]
    # 排序
    subdir.sort()

    for sub in subdir:
        stime = time.time()
        result = md5unique(sub, recursive=True)
        etime = time.time()
        print(f"处理目录 {sub} 用时 {etime - stime:.2f} 秒")
        print(f"结果: {result}")
        print("-" * 50 + "\n\n")
