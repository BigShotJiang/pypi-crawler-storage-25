"""`fastmdx` is the PyPI alias for FastMDXplorer.

The canonical package is `fastmdxplorer`. This alias exists so that
`pip install fastmdx` works for users who type the shorter name.

Recommended usage in code:

    import fastmdxplorer as fastmdx       # preferred

The bare `import fastmdx` form also works and re-exports the
`fastmdxplorer` namespace.
"""

import warnings

# Re-export the canonical package's public surface.
from fastmdxplorer import *  # noqa: F401,F403
from fastmdxplorer import (  # noqa: F401
    FastMDXplorer,
    __author__,
    __citation__,
    __doi__,
    __expansion__,
    __license__,
    __version__,
)

# Friendly notice when the alias is imported directly.
warnings.warn(
    "Importing 'fastmdx' is supported as a PyPI/import alias for "
    "'fastmdxplorer'. The recommended idiom is "
    "`import fastmdxplorer as fastmdx`. The CLI command is also `fastmdx`.",
    stacklevel=2,
)
