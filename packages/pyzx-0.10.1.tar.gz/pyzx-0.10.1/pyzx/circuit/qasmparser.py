# PyZX - Python library for quantum circuit rewriting 
#        and optimization using the ZX-calculus
# Copyright (C) 2018 - Aleks Kissinger and John van de Wetering

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

#    http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import math
import re
from fractions import Fraction
from typing import List, Dict, Tuple, Optional

from . import Circuit
from .gates import Gate, qasm_gate_table, Measurement, Reset, ConditionalGate
from ..utils import settings


class QASMParser(object):
    """Class for parsing QASM source files into circuit descriptions."""

    def __init__(self) -> None:
        self.qasm_version:int = settings.default_qasm_version
        self.gates: List[Gate] = []
        self.custom_gates: Dict[str,Circuit] = {}
        self.registers: Dict[str,Tuple[int,int]] = {}
        self.cregisters: Dict[str,int] = {}
        self.qubit_count: int = 0
        self.bit_count: int = 0
        self.circuit: Optional[Circuit] = None

    def parse(self, s: str, strict:bool=True) -> Circuit:
        self.gates = []
        self.custom_gates = {}
        self.registers = {}
        self.cregisters = {}
        self.qubit_count = 0
        self.bit_count = 0
        self.circuit = None
        lines = s.splitlines()
        r = []
        #strip comments
        for s in lines:
            if s.find("//")!=-1:
                t = s[0:s.find("//")].strip()
            else: t = s.strip()
            if t: r.append(t)

        match = re.fullmatch(r"OPENQASM ([23])(\.\d+)?;", r[0])
        if match and match.group(1):
            self.qasm_version = int(match.group(1))
            r.pop(0)
        elif strict:
            raise TypeError("File does not start with supported OPENQASM descriptor.")

        if self.qasm_version == 2 and r[0].startswith('include "qelib1.inc";') or \
                self.qasm_version == 3 and r[0].startswith('include "stdgates.inc";'):
            r.pop(0)
        elif strict:
            raise TypeError("File is not importing standard library")

        data = "\n".join(r)
        # Strip the custom command definitions from the normal commands
        while True:
            i = data.find("gate ")
            if i == -1: break
            j = data.find("}", i)
            self.parse_custom_gate(data[i:j+1])
            data = data[:i] + data[j+1:]
        data = self._expand_if_blocks(data)
        # Parse the regular commands.
        commands = [s.strip() for s in data.split(";") if s.strip()]
        for c in commands:
            self.gates.extend(self.parse_command(c, self.registers))

        self.bit_count = sum(self.cregisters.values())
        circ = Circuit(self.qubit_count, bit_amount=self.bit_count)
        circ.gates = self.gates
        self.circuit = circ
        return self.circuit

    @staticmethod
    def _expand_if_blocks(s: str) -> str:
        """Expand braced if-blocks into flat if-statements.

        E.g. ``if (c==1) { x q[0]; z q[1]; }`` becomes
        ``if (c==1) x q[0]; if (c==1) z q[1];``

        This is done before semicolon-splitting so that the braces do
        not break the command boundaries.  Nested if-blocks (e.g.
        ``if (c==1) { if (c==0) { x q[0]; } }``) are rejected.
        """
        pattern = re.compile(r'if\s*\([^)]*\)\s*\{')
        while True:
            m = pattern.search(s)
            if m is None:
                break
            prefix = m.group()          # e.g. "if (c==1) {"
            condition = prefix[:prefix.rfind('{')].strip()  # "if (c==1)"
            brace_start = m.end()
            try:
                brace_end = s.index('}', brace_start)
            except ValueError:
                raise TypeError(
                    "Unterminated if-block (missing closing '}}') near: "
                    "{}".format(s[m.start():m.start() + 80].strip()))
            body = s[brace_start:brace_end]
            # Reject nested if-blocks.
            if '{' in body:
                raise TypeError(
                    "Nested if-blocks are not supported: {}".format(
                        s[m.start():brace_end + 1].strip()))
            inner_cmds = [c.strip() for c in body.split(';') if c.strip()]
            expanded = '; '.join(condition + ' ' + c for c in inner_cmds) + ';'
            s = s[:m.start()] + expanded + s[brace_end + 1:]
        return s

    def parse_custom_gate(self, data: str) -> None:
        data = data[5:]
        spec, body = data.split("{",1)
        if "(" in spec:
            i = spec.find("(")
            j = spec.find(")")
            if spec[i+1:j].strip():
                raise TypeError("Arguments for custom gates are currently"
                                " not supported: {}".format(data))
            spec = spec[:i] + spec[j+1:]
        spec = spec.strip()
        if " " in spec:
            name, args = spec.split(" ",1)
            name = name.strip()
            args = args.strip()
        else:
            raise TypeError("Custom gate specification doesn't have any "
                            "arguments: {}".format(data))
        registers : Dict[str,Tuple[int,int]] = {}
        qubit_count = 0
        for a in args.split(","):
            a = a.strip()
            if a in registers:
                raise TypeError("Duplicate variable name: {}".format(data))
            registers[a] = (qubit_count,1)
            qubit_count += 1

        body = body[:-1].strip()
        commands = [s.strip() for s in body.split(";") if s.strip()]
        circ = Circuit(qubit_count)
        for c in commands:
            for g in self.parse_command(c, registers):
                circ.add_gate(g)
        self.custom_gates[name] = circ

    def extract_command_parts(self, c: str) -> Tuple[str,List[Fraction],List[str]]:
        if self.qasm_version == 3:
            # Convert some OpenQASM 3 commands into OpenQASM 2 format.
            c = re.sub(r"^bit\[(\d+)] (\w+)$", r"creg \2[\1]", c)
            c = re.sub(r"^qubit\[(\d+)] (\w+)$", r"qreg \2[\1]", c)
            c = re.sub(r"^(\w+)\[(\d+)] = measure (\w+)\[(\d+)]$", r"measure \3[\4] -> \1[\2]", c)
        right_bracket = c.find(")")
        name, rest = c.split(" ", 1) if right_bracket == -1\
            else [c[:right_bracket+1], c[right_bracket+1:]]
        args = [s.strip() for s in rest.split(",") if s.strip()]
        left_bracket = name.find('(')
        phases = []
        if left_bracket != -1:
            if right_bracket == -1:
                raise TypeError("Mismatched bracket: {}.".format(name))
            vals = name[left_bracket+1:right_bracket].split(',')
            phases = [self.parse_phase_arg(val) for val in vals]
            name = name[:left_bracket]
        return name, phases, args

    def parse_command(self, c: str, registers: Dict[str,Tuple[int,int]]) -> List[Gate]:
        gates: List[Gate] = []
        # Handle `if (creg == val) gate args;` before extract_command_parts,
        # because the parentheses in `if(...)` confuse the phase parser.
        if_match = re.match(r'if\s*\(\s*(\w+)\s*==\s*(\d+)\s*\)\s*(.*)', c)
        if if_match:
            reg_name = if_match.group(1)
            cond_val = int(if_match.group(2))
            inner_cmd = if_match.group(3)
            if reg_name not in self.cregisters:
                raise TypeError("Unknown classical register '{}'".format(reg_name))
            reg_size = self.cregisters[reg_name]
            inner_gates = self.parse_command(inner_cmd, registers)
            for ig in inner_gates:
                gates.append(ConditionalGate(reg_name, cond_val, ig, reg_size))
            return gates
        name, phases, args = self.extract_command_parts(c)
        if name in ("barrier", "id"): return gates
        if name == "creg":
            regname, sizep = args[0].split("[", 1)
            size = int(sizep[:-1])
            self.cregisters[regname] = size
            return gates
        if name == "measure":
            # Strip all spaces so we can split on '->' regardless of spacing.
            raw = args[0].replace(' ', '')
            target, result_bit = raw.split('->')
            if '[' in target:
                # Single qubit: measure q[0] -> c[0];
                regname, target_idx = target.split('[', 1)
                if regname not in registers:
                    raise TypeError("Invalid register {}".format(regname))
                target_qbit = registers[regname][0] + int(target_idx[:-1])
                result_reg_name, result_idx = result_bit.split('[', 1)
                result_index = int(result_idx[:-1])
                if result_reg_name not in self.cregisters:
                    raise TypeError("Undeclared classical register {}".format(
                        result_reg_name))
                if result_index >= self.cregisters[result_reg_name]:
                    raise TypeError(
                        "Index {} out of range for classical register {} "
                        "of size {}".format(
                            result_index, result_reg_name,
                            self.cregisters[result_reg_name]))
                gate = Measurement(target_qbit, result_symbol="{}[{}]".format(result_reg_name, result_index))
                gates.append(gate)
            else:
                # Register broadcast: measure q -> c.
                if target not in registers:
                    raise TypeError("Invalid register {}".format(target))
                if result_bit not in self.cregisters:
                    raise TypeError("Undeclared classical register {}".format(
                        result_bit))
                start, size = registers[target]
                if size > self.cregisters[result_bit]:
                    raise TypeError(
                        "Quantum register {} (size {}) is larger than "
                        "classical register {} (size {})".format(
                            target, size, result_bit,
                            self.cregisters[result_bit]))
                for i in range(size):
                    gate = Measurement(start + i, result_symbol="{}[{}]".format(result_bit, i))
                    gates.append(gate)
            return gates
        if name == "reset":
            # Reset initializes a qubit to |0⟩ state.
            # In OpenQASM: `reset q[0];` or `reset q;` (for entire register)
            for a in args:
                if "[" in a:
                    regname, valp = a.split("[", 1)
                    val = int(valp[:-1])
                    if regname not in registers:
                        raise TypeError("Invalid register {}".format(regname))
                    qubit = registers[regname][0] + val
                    gates.append(Reset(qubit))
                else:
                    if a not in registers:
                        raise TypeError("Invalid register {}".format(a))
                    start, size = registers[a]
                    for i in range(size):
                        gates.append(Reset(start + i))
            return gates
        if name in ("opaque",):
            raise TypeError("Unsupported operation {}".format(c))
        if name == "qreg":
            regname, sizep = args[0].split("[",1)
            size = int(sizep[:-1])
            registers[regname] = (self.qubit_count, size)
            self.qubit_count += size
            return gates
        qubit_values = []
        is_range = False
        dim = 1
        for a in args:
            if "[" in a:
                # Split at the first '[' to handle multi-character register names
                regname, valp = a.split("[",1)
                # Remove the trailing ']' before converting to int
                val = int(valp[:-1])
                if regname not in registers: 
                    raise TypeError("Invalid register {}".format(regname))
                qubit_values.append([registers[regname][0]+val])
            else:
                if is_range:
                    if registers[a][1] != dim:
                        raise TypeError("Error in parsing {}: Register sizes do not match".format(c))
                else:
                    dim = registers[a][1]
                is_range = True
                s = registers[a][0]
                qubit_values.append(list(range(s,s + dim)))
        if is_range:
            for i in range(len(qubit_values)):
                if len(qubit_values[i]) != dim:
                    qubit_values[i] = [qubit_values[i][0]]*dim
        for j in range(dim):
            argset = [q[j] for q in qubit_values]
            if name in self.custom_gates:
                circ = self.custom_gates[name]
                if len(argset) != circ.qubits:
                    raise TypeError("Argument amount does not match gate spec: {}".format(c))
                for g in circ.gates:
                    gates.append(g.reposition(argset))
            elif name in ('x', 'y', 'z', 's', 't', 'h', 'sx'):
                if len(phases) != 0: raise TypeError("Invalid specification {}".format(c))
                g = qasm_gate_table[name](argset[0])  # type: ignore # mypy can't handle Gate subclasses with different number of parameters
                gates.append(g)
            elif name in ('sdg', 'tdg', 'sxdg'):
                if len(phases) != 0: raise TypeError("Invalid specification {}".format(c))
                g = qasm_gate_table[name](argset[0],adjoint=True)  # type: ignore
                gates.append(g)
            elif name in ('rx', 'ry', 'rz', 'p', 'u1'):
                if len(phases) != 1: raise TypeError("Invalid specification {}".format(c))
                g = qasm_gate_table[name](argset[0],phase=phases[0])  # type: ignore
                gates.append(g)
            elif name == 'u2':
                if len(phases) != 2: raise TypeError("Invalid specification {}".format(c))
                gates.append(qasm_gate_table[name](argset[0], phases[0], phases[1]))  # type: ignore
            elif name in ('u3', 'u', 'U'):
                if len(phases) != 3: raise TypeError("Invalid specification {}".format(c))
                gates.append(qasm_gate_table[name](argset[0], phases[0], phases[1], phases[2]))  # type: ignore
            elif name in ('cx', 'CX', 'cy', 'cz', 'ch', 'csx', 'swap'):
                if len(phases) != 0: raise TypeError("Invalid specification {}".format(c))
                g = qasm_gate_table[name](control=argset[0],target=argset[1])  # type: ignore
                gates.append(g)
            elif name in ('crx', 'cry', 'crz', 'cp', 'cphase', 'cu1', 'rxx', 'rzz'):
                if len(phases) != 1: raise TypeError("Invalid specification {}".format(c))
                g = qasm_gate_table[name](argset[0],argset[1],phase=phases[0])  # type: ignore
                gates.append(g)
            elif name in ('ccx', 'ccz', 'cswap'):
                if len(phases) != 0: raise TypeError("Invalid specification {}".format(c))
                g = qasm_gate_table[name](ctrl1=argset[0],ctrl2=argset[1],target=argset[2])  # type: ignore
                gates.append(g)
            elif name == 'cu3':
                if len(phases) != 3: raise TypeError("Invalid specification {}".format(c))
                g = qasm_gate_table[name](control=argset[0],target=argset[1],theta=phases[0],phi=phases[1],rho=phases[2])  # type: ignore
                gates.append(g)
            elif name == 'cu':
                if len(phases) != 4: raise TypeError("Invalid specification {}".format(c))
                g = qasm_gate_table[name](control=argset[0],target=argset[1],theta=phases[0],phi=phases[1],rho=phases[2],gamma=phases[3])  # type: ignore
                gates.append(g)
            else:
                raise TypeError("Invalid specification: {}".format(c))
        return gates

    def parse_phase_arg(self, val):
        try:
            phase = float(val)/math.pi
        except ValueError:
            if val.find('pi') == -1: raise TypeError("Invalid specification {}".format(val))
            try:
                val = val.replace('pi', '')
                val = val.replace('*','')
                if val.find('/') != -1:
                    n, d = val.split('/',1)
                    n = n.strip()
                    if not n: n = 1
                    elif n == '-': n = -1
                    else: n = int(n)
                    d = int(d.strip())
                    phase = Fraction(n,d)
                else:
                    val = val.strip()
                    if not val: phase = 1
                    elif val == '-': phase = -1
                    else: phase = float(val)
            except: raise TypeError("Invalid specification {}".format(val))
        phase = Fraction(phase).limit_denominator(settings.float_to_fraction_max_denominator)
        return phase


def qasm(s: str) -> Circuit:
    """Parses a string representing a program in QASM, and outputs a `Circuit`."""
    p = QASMParser()
    return p.parse(s, strict=False)

