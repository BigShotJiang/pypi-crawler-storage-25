# PyZX - Python library for quantum circuit rewriting 
#        and optimization using the ZX-calculus
# Copyright (C) 2018 - Aleks Kissinger and John van de Wetering

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

#    http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import unittest
from fractions import Fraction
import itertools
import json
import os
import sys
import tempfile
if __name__ == '__main__':
    sys.path.append('..')
    sys.path.append('.')

from pyzx.graph import Graph
from pyzx.utils import EdgeType, VertexType
from pyzx.generate import identity

import numpy as np
from pyzx.tensor import compare_tensors
from pyzx.graph.scalar import Scalar



class TestGraphBasicMethods(unittest.TestCase):

    def test_empty_graph(self):
        g = Graph()
        self.assertEqual(g.num_vertices(),0)
        self.assertEqual(g.num_edges(),0)

    def test_add_remove_vertices(self):
        g = Graph()
        v = g.add_vertex()
        self.assertEqual(g.num_vertices(),1)
        g.add_vertices(3)
        self.assertEqual(g.num_vertices(),4)
        g.remove_vertex(v)
        self.assertEqual(g.num_vertices(),3)

    def test_edges(self):
        g = Graph()
        v1, v2, v3 = g.add_vertices(3)
        g.add_edge((v1,v2))
        self.assertEqual(g.num_edges(),1)
        self.assertTrue(g.connected(v1,v2))
        self.assertTrue(v2 in g.neighbors(v1))
        self.assertEqual(g.vertex_degree(v1), 1)
        self.assertFalse(g.connected(v1,v3))
        e = g.edge(v1,v2)
        self.assertEqual(g.edge_type(e),EdgeType.SIMPLE)
        g.set_edge_type(e,EdgeType.HADAMARD)
        self.assertEqual(g.edge_type(e),EdgeType.HADAMARD)
        g.remove_edge(e)
        self.assertEqual(g.num_edges(),0)
        self.assertFalse(g.connected(v1,v2))

    def test_self_loop(self):
        g = Graph()
        v1 = g.add_vertex(VertexType.X, 0, 0)
        v2 = g.add_vertex(VertexType.Z, 0, 0)
        g.add_edge((v1,v1))
        g.add_edge((v2,v2))

        self.assertEqual(g.num_edges(),0)
        self.assertEqual(g.vertex_degree(v1), 0)
        self.assertEqual(g.vertex_degree(v2), 0)
        self.assertEqual(g.phases()[0], 0)
        self.assertEqual(g.phases()[1], 0)

    def test_self_loop_had_edge(self):
        g = Graph()
        v1 = g.add_vertex(VertexType.X, 0, 0)
        v2 = g.add_vertex(VertexType.Z, 0, 0)
        g.add_edge((v1,v1), edgetype=EdgeType.HADAMARD)
        g.add_edge((v2,v2), edgetype=EdgeType.HADAMARD)

        self.assertEqual(g.num_edges(),0)
        self.assertEqual(g.vertex_degree(v1), 0)
        self.assertEqual(g.vertex_degree(v2), 0)
        self.assertEqual(g.phases()[0], 1)
        self.assertEqual(g.phases()[1], 1)

    def test_set_attributes(self):
        g = Graph()
        v = g.add_vertex()
        self.assertEqual(g.phase(v),0)
        g.set_phase(v,1)
        self.assertEqual(g.phase(v),1)
        self.assertEqual(g.type(v),VertexType.BOUNDARY)
        g.set_type(v,VertexType.X)
        self.assertEqual(g.type(v),VertexType.X)
        self.assertFalse(g.is_ground(v))
        g.set_ground(v)
        self.assertTrue(g.is_ground(v))
        g.set_row(v,3)
        self.assertEqual(g.row(v),3)
        g.set_qubit(v,2)
        self.assertEqual(g.qubit(v),2)

    def test_add_edge_table_same_type(self):
        g = Graph()
        v1, v2 = g.add_vertices(2)
        g.set_type(v1,VertexType.Z)
        g.set_type(v2,VertexType.Z)
        etab = {(v1,v2):[2,0]}
        g.add_edge_table(etab)
        self.assertTrue(g.connected(v1,v2))
        self.assertEqual((g.phase(v1),g.phase(v2)),(0,0))
        g.remove_edge(g.edge(v1,v2))
        self.assertFalse(g.connected(v1,v2))
        etab = {(v1,v2):[0,2]}
        g.add_edge_table(etab)
        self.assertFalse(g.connected(v1,v2))
        etab = {(v1,v2): [1,1]}
        g.add_edge_table(etab)
        self.assertEqual(g.edge_type(g.edge(v1,v2)),EdgeType.SIMPLE)
        self.assertTrue((g.phase(v1)==1  and g.phase(v2)==0) or (g.phase(v1)==0 and g.phase(v2)==1))

    def test_add_edge_table_different_type(self):
        g = Graph()
        v1, v2 = g.add_vertices(2)
        g.set_type(v1,VertexType.Z)
        g.set_type(v2,VertexType.X)
        etab = {(v1,v2):[0,2]}
        g.add_edge_table(etab)
        self.assertTrue(g.connected(v1,v2))
        self.assertEqual((g.phase(v1),g.phase(v2)),(0,0))
        g.remove_edge(g.edge(v1,v2))
        self.assertFalse(g.connected(v1,v2))
        etab = {(v1,v2):[2,0]}
        g.add_edge_table(etab)
        self.assertFalse(g.connected(v1,v2))
        etab = {(v1,v2): [1,1]}
        g.add_edge_table(etab)
        self.assertEqual(g.edge_type(g.edge(v1,v2)),EdgeType.HADAMARD)
        self.assertTrue((g.phase(v1)==1  and g.phase(v2)==0) or (g.phase(v1)==0 and g.phase(v2)==1))

    def test_copy(self):
        g = Graph()
        v1, v2 = g.add_vertices(2)
        g.add_edge((v1,v2),EdgeType.HADAMARD)
        g2 = g.copy()
        self.assertEqual(g.num_vertices(),g2.num_vertices())
        self.assertEqual(g.num_edges(),g2.num_edges())
        v1, v2 = list(g2.vertices())
        self.assertEqual(g.edge_type(g.edge(v1,v2)),EdgeType.HADAMARD)

    def test_clone_grounds(self):
        """clone() should preserve ground status of vertices."""
        for backend in ["simple", "multigraph"]:
            with self.subTest(backend=backend):
                g = Graph(backend=backend)
                v1 = g.add_vertex(VertexType.Z, 0, 0)
                v2 = g.add_vertex(VertexType.Z, 0, 1, ground=True)
                g.add_edge((v1, v2))
                g2 = g.clone()
                self.assertTrue(g2.is_ground(v2))
                self.assertFalse(g2.is_ground(v1))

    def test_tensor_grounds(self):
        """tensor() should preserve grounds from the other graph."""
        for backend in ["simple", "multigraph"]:
            with self.subTest(backend=backend):
                g1 = Graph(backend=backend)
                g1.add_vertex(VertexType.Z, 0, 0)

                g2 = Graph(backend=backend)
                g2.add_vertex(VertexType.Z, 0, 0, ground=True)

                g = g1.tensor(g2)
                self.assertEqual(len(g.grounds()), 1)

    def test_adjoint_scalar(self):
        g = Graph()
        scalar = Scalar()
        scalar.phase = Fraction(1, 4)
        scalar.phasenodes = [Fraction(1, 2), Fraction(1, 4)]
        scalar.floatfactor = 1.3 + 0.1*1j
        scalar.power2 = 2
        g.scalar = scalar
        g_adj = g.adjoint()
        self.assertAlmostEqual(g_adj.scalar.to_number(), scalar.to_number().conjugate())

    def test_adjoint_z_box_label(self):
        from pyzx.utils import get_z_box_label, set_z_box_label
        g = Graph()
        v = g.add_vertex(VertexType.Z_BOX)
        set_z_box_label(g, v, (2+3j))
        g_adj = g.adjoint()
        adj_v = list(g_adj.vertices())[0]
        self.assertEqual(get_z_box_label(g_adj, adj_v), (2-3j))

    def test_adjoint_h_box_label(self):
        from pyzx.utils import get_h_box_label, set_h_box_label
        g = Graph()
        v = g.add_vertex(VertexType.H_BOX)
        set_h_box_label(g, v, (2+3j))
        g_adj = g.adjoint()
        adj_v = list(g_adj.vertices())[0]
        self.assertEqual(get_h_box_label(g_adj, adj_v), (2-3j))

    def test_adjoint_h_box_phase(self):
        """Adjoint of a phase-based H-box should negate the phase
        without converting to a complex label."""
        from pyzx.utils import hbox_has_complex_label
        g = Graph()
        phase = Fraction(1, 2)
        v = g.add_vertex(VertexType.H_BOX, phase=phase)
        self.assertFalse(hbox_has_complex_label(g, v))
        g_adj = g.adjoint()
        adj_v = list(g_adj.vertices())[0]
        self.assertEqual(g_adj.phase(adj_v), (-phase) % 2)
        self.assertFalse(hbox_has_complex_label(g_adj, adj_v))

    def test_set_phase_rejects_complex(self):
        g = Graph()
        v = g.add_vertex(VertexType.Z)
        with self.assertRaises(TypeError):
            g.set_phase(v, (1+2j))

    def test_add_vertex_rejects_complex_phase(self):
        from pyzx.symbolic import Poly, Term, Var
        g = Graph()
        var = Var('x')
        phase = Poly([((3+2j), Term([(var, 1)]))])
        with self.assertRaises(TypeError):
            g.add_vertex(VertexType.Z, phase=phase)

    @unittest.skipUnless(np, "numpy needs to be installed for this to run")
    def test_remove_isolated_vertex_preserves_semantics(self):
        g = Graph()
        v = g.add_vertex(VertexType.Z,0,0)
        g2 = g.copy()
        g2.remove_isolated_vertices()
        self.assertTrue(compare_tensors(g,g2,preserve_scalar=True))
        self.assertAlmostEqual(g2.scalar.to_number(),2)
        g.set_phase(v,Fraction(1))
        g2 = g.copy()
        g2.remove_isolated_vertices()
        self.assertTrue(compare_tensors(g,g2))
        self.assertAlmostEqual(g2.scalar.to_number(),0)

    @unittest.skipUnless(np, "numpy needs to be installed for this to run")
    def test_remove_isolated_pair_preserves_semantics(self):
        for i,j in itertools.product([VertexType.Z,VertexType.X],repeat=2):
            for k in [EdgeType.SIMPLE, EdgeType.HADAMARD]:
                for phase1, phase2 in itertools.product([0,1,2],[0,4,5]):
                    with self.subTest(i=i,j=j,k=k,phase1=phase1,phase2=phase2):
                        g = Graph()
                        v = g.add_vertex(i,0,0,phase=phase1)
                        w = g.add_vertex(j,1,0,phase=phase2)
                        g.add_edge((v,w),k)
                        g2 = g.copy()
                        g2.remove_isolated_vertices()
                        self.assertEqual(g2.num_vertices(),0)
                        self.assertTrue(compare_tensors(g,g2))

class TestGraphCircuitMethods(unittest.TestCase):

    def setUp(self):
        """Sets up a two qubit circuit containing a single CNOT with some phases."""
        self.graph = Graph()
        g = self.graph
        i1 = g.add_vertex(VertexType.BOUNDARY,0,0) #add_vertex(type,qubit_index,row_index,phase=0)
        i2 = g.add_vertex(VertexType.BOUNDARY,1,0)
        g.set_inputs((i1,i2))
        v = g.add_vertex(VertexType.Z,0,1,Fraction(1,2))
        w = g.add_vertex(VertexType.X,1,1,Fraction(1,1))
        o1 = g.add_vertex(VertexType.BOUNDARY,0,2)
        o2 = g.add_vertex(VertexType.BOUNDARY,1,2)
        g.set_outputs((o1, o2))
        g.add_edges([(i1,v),(i2,w),(v,w),(v,o1),(w,o2)])
        self.i1, self.i2, self.v, self.w, self.o1, self.o2 = i1, i2, v, w, o1, o2

    def test_qubit_index_and_depth(self):
        g = self.graph
        self.assertEqual(g.depth(),2)
        self.assertEqual(g.qubit_count(),2)

    def test_adjoint(self):
        g = self.graph
        adj = g.adjoint()
        self.assertEqual(g.num_vertices(),adj.num_vertices())
        self.assertEqual(g.num_edges(),adj.num_edges())
        self.assertEqual(g.depth(), adj.depth())
        self.assertEqual(g.qubit_count(), adj.qubit_count())

        v = [i for i in g.vertices() if g.type(i)==VertexType.Z][0]
        w = [i for i in adj.vertices() if adj.type(i)==VertexType.Z][0]
        self.assertEqual(g.phase(v),(-adj.phase(v))%2)
        self.assertEqual(g.vertex_degree(v),adj.vertex_degree(w))

    def test_compose_basic(self):
        g = self.graph.copy()
        g.compose(g)
        self.assertEqual((g.num_inputs(),g.num_outputs()),(2,2))

    @unittest.skipUnless(np, "numpy needs to be installed for this to run")
    def test_compose_unitary(self):
        g = self.graph
        g.set_edge_type(g.edge(self.v,self.o1),EdgeType.HADAMARD)
        g2 = g.adjoint()
        g2.compose(g)
        self.assertTrue(compare_tensors(g2,identity(2), False))


class TestGraphSaveLoad(unittest.TestCase):
    """Tests for graph save/load functionality."""

    def setUp(self):
        """Create a simple test graph."""
        self.graph = Graph()
        g = self.graph
        v1 = g.add_vertex(VertexType.BOUNDARY, 0, 0)
        v2 = g.add_vertex(VertexType.Z, 0, 1, Fraction(1, 4))
        v3 = g.add_vertex(VertexType.X, 0, 2)
        v4 = g.add_vertex(VertexType.BOUNDARY, 0, 3)
        g.add_edge((v1, v2))
        g.add_edge((v2, v3), EdgeType.HADAMARD)
        g.add_edge((v3, v4))
        g.set_inputs((v1,))
        g.set_outputs((v4,))

    def test_save_load_json(self):
        """Test saving and loading a graph in JSON format."""
        with tempfile.NamedTemporaryFile(suffix='.json', delete=False) as f:
            filename = f.name
        try:
            self.graph.save(filename)
            loaded = Graph.load(filename)
            self.assertEqual(self.graph.num_vertices(), loaded.num_vertices())
            self.assertEqual(self.graph.num_edges(), loaded.num_edges())
        finally:
            os.unlink(filename)

    def test_save_load_json_explicit_format(self):
        """Test saving and loading with explicit format specification."""
        with tempfile.NamedTemporaryFile(suffix='.txt', delete=False) as f:
            filename = f.name
        try:
            self.graph.save(filename, fmt='json')
            loaded = Graph.load(filename, fmt='json')
            self.assertEqual(self.graph.num_vertices(), loaded.num_vertices())
            self.assertEqual(self.graph.num_edges(), loaded.num_edges())
        finally:
            os.unlink(filename)

    def test_save_load_tikz(self):
        """Test saving and loading a graph in TikZ format."""
        with tempfile.NamedTemporaryFile(suffix='.tikz', delete=False) as f:
            filename = f.name
        try:
            self.graph.save(filename)
            loaded = Graph.load(filename, warn_overlap=False)
            self.assertEqual(self.graph.num_vertices(), loaded.num_vertices())
            self.assertEqual(self.graph.num_edges(), loaded.num_edges())
        finally:
            os.unlink(filename)

    def test_save_unknown_format_raises(self):
        """Test that saving with unknown format raises ValueError."""
        with tempfile.NamedTemporaryFile(suffix='.xyz', delete=False) as f:
            filename = f.name
        try:
            with self.assertRaises(ValueError) as ctx:
                self.graph.save(filename)
            self.assertIn("Cannot infer format", str(ctx.exception))
        finally:
            os.unlink(filename)

    def test_save_unsupported_format_raises(self):
        """Test that saving with unsupported format raises ValueError."""
        with tempfile.NamedTemporaryFile(suffix='.json', delete=False) as f:
            filename = f.name
        try:
            with self.assertRaises(ValueError) as ctx:
                self.graph.save(filename, fmt='xml')
            self.assertIn("Unsupported format", str(ctx.exception))
        finally:
            os.unlink(filename)

    def test_load_unknown_format_raises(self):
        """Test that loading with unknown format raises ValueError."""
        with tempfile.NamedTemporaryFile(suffix='.xyz', delete=False) as f:
            f.write(b'test')
            filename = f.name
        try:
            with self.assertRaises(ValueError) as ctx:
                Graph.load(filename)
            self.assertIn("Cannot infer format", str(ctx.exception))
        finally:
            os.unlink(filename)

    def test_qgraph_extension(self):
        """Test that .qgraph extension is recognized as JSON."""
        with tempfile.NamedTemporaryFile(suffix='.qgraph', delete=False) as f:
            filename = f.name
        try:
            self.graph.save(filename)
            loaded = Graph.load(filename)
            self.assertEqual(self.graph.num_vertices(), loaded.num_vertices())
        finally:
            os.unlink(filename)


class TestPhaseGadget(unittest.TestCase):

    def test_add_phase_gadget_basic(self):
        g = Graph()
        v1 = g.add_vertex(VertexType.Z, 0, 0)
        v2 = g.add_vertex(VertexType.Z, 1, 0)
        v3 = g.add_vertex(VertexType.Z, 2, 0)

        hub, phase_v = g.add_phase_gadget(Fraction(1, 4), [v1, v2, v3])

        self.assertEqual(g.phase(hub), 0)
        self.assertEqual(g.vertex_degree(hub), 4)
        self.assertEqual(g.phase(phase_v), Fraction(1, 4))
        self.assertEqual(g.vertex_degree(phase_v), 1)
        self.assertTrue(g.is_phase_gadget(hub))

    def test_add_phase_gadget_single_target(self):
        g = Graph()
        v1 = g.add_vertex(VertexType.Z, 0, 0)

        hub, phase_v = g.add_phase_gadget(Fraction(1, 2), [v1])

        self.assertEqual(g.phase(hub), 0)
        self.assertEqual(g.phase(phase_v), Fraction(1, 2))
        self.assertEqual(g.vertex_degree(hub), 2)

    def test_add_phase_gadget_empty_targets_error(self):
        g = Graph()
        with self.assertRaises(ValueError):
            g.add_phase_gadget(Fraction(1, 4), [])

    def test_add_phase_gadget_custom_vertex_type(self):
        g = Graph()
        v1 = g.add_vertex(VertexType.X, 0, 0)
        v2 = g.add_vertex(VertexType.X, 1, 0)

        hub, phase_v = g.add_phase_gadget(
            Fraction(3, 4), [v1, v2],
            vertex_type=VertexType.X
        )

        self.assertEqual(g.type(hub), VertexType.X)
        self.assertEqual(g.type(phase_v), VertexType.X)

    def test_add_phase_gadget_custom_edge_type(self):
        g = Graph()
        v1 = g.add_vertex(VertexType.Z, 0, 0)
        v2 = g.add_vertex(VertexType.Z, 1, 0)

        hub, phase_v = g.add_phase_gadget(
            Fraction(1, 4), [v1, v2],
            edge_type=EdgeType.SIMPLE
        )

        e1 = g.edge(hub, v1)
        e2 = g.edge(hub, v2)
        self.assertEqual(g.edge_type(e1), EdgeType.SIMPLE)
        self.assertEqual(g.edge_type(e2), EdgeType.SIMPLE)

        e_phase = g.edge(hub, phase_v)
        self.assertEqual(g.edge_type(e_phase), EdgeType.HADAMARD)


class TestVarRegistryPropagation(unittest.TestCase):
    """Tests that variable type metadata is preserved through graph transforms."""

    def _make_bool_var_circuit(self):
        """Create a single-wire circuit with a boolean variable 'b' on a Z spider."""
        from pyzx.symbolic import new_var
        g = Graph()
        phase = new_var('b', is_bool=True, registry=g.var_registry)
        i = g.add_vertex(VertexType.BOUNDARY, 0, 0)
        v = g.add_vertex(VertexType.Z, 0, 1, phase=phase)
        o = g.add_vertex(VertexType.BOUNDARY, 0, 2)
        g.add_edges([(i, v), (v, o)])
        g.set_inputs((i,))
        g.set_outputs((o,))
        return g, v

    def _make_identity_wire(self):
        """Create a single-wire identity circuit."""
        g = Graph()
        i = g.add_vertex(VertexType.BOUNDARY, 0, 0)
        o = g.add_vertex(VertexType.BOUNDARY, 0, 1)
        g.add_edge((i, o))
        g.set_inputs((i,))
        g.set_outputs((o,))
        return g

    def _check_bool_var(self, g):
        self.assertTrue(g.var_registry.get_type('b', default=False))

    def test_subgraph_from_vertices_preserves_var_registry(self):
        g, v = self._make_bool_var_circuit()
        self._check_bool_var(g.subgraph_from_vertices([v]))

    def test_subgraph_from_vertices_excludes_unused_vars(self):
        """Only variables used by subgraph vertices should be copied."""
        from pyzx.symbolic import new_var
        g = Graph()
        alpha = new_var('alpha', is_bool=False, registry=g.var_registry)
        beta = new_var('beta', is_bool=True, registry=g.var_registry)
        v1 = g.add_vertex(VertexType.Z, 0, 0, phase=alpha)
        v2 = g.add_vertex(VertexType.Z, 0, 1, phase=beta)
        g.add_edge((v1, v2))

        sub = g.subgraph_from_vertices([v1])
        self.assertIn('alpha', sub.var_registry.vars())
        self.assertNotIn('beta', sub.var_registry.vars())

    def test_subgraph_from_vertices_z_box_label_vars(self):
        """Variables in Z-box labels should be copied to the subgraph."""
        from pyzx.symbolic import new_var
        from pyzx.utils import get_z_box_label, set_z_box_label
        g = Graph()
        alpha = new_var('alpha', is_bool=False, registry=g.var_registry)
        beta = new_var('beta', is_bool=True, registry=g.var_registry)
        v1 = g.add_vertex(VertexType.Z_BOX, 0, 0)
        set_z_box_label(g, v1, alpha)
        v2 = g.add_vertex(VertexType.Z, 0, 1, phase=beta)
        g.add_edge((v1, v2))

        sub = g.subgraph_from_vertices([v1])
        self.assertIn('alpha', sub.var_registry.vars())
        self.assertNotIn('beta', sub.var_registry.vars())

    def test_subgraph_from_vertices_does_not_mutate_parent(self):
        """Creating a subgraph should not rebind the parent graph's Vars."""
        from pyzx.symbolic import new_var
        g = Graph()
        alpha = new_var('alpha', is_bool=False, registry=g.var_registry)
        v1 = g.add_vertex(VertexType.Z, 0, 0, phase=alpha)

        parent_var = next(iter(g.phase(v1).free_vars()))
        self.assertIs(parent_var._registry, g.var_registry)

        sub = g.subgraph_from_vertices([v1])

        self.assertIs(parent_var._registry, g.var_registry)
        sub_var = next(iter(sub.phase(v1).free_vars()))
        self.assertIs(sub_var._registry, sub.var_registry)

    def test_merge_preserves_var_registry(self):
        g, _ = self._make_bool_var_circuit()
        target = Graph()
        target.merge(g)
        self._check_bool_var(target)
        # Verify variables in phases are bound to target's registry.
        target.var_registry.set_type('b', False)
        v = [v for v in target.vertices() if target.type(v) == VertexType.Z][0]
        var = next(iter(target.phase(v).free_vars()))
        self.assertFalse(var.is_bool)

    def test_tensor_preserves_var_registry(self):
        g, _ = self._make_bool_var_circuit()
        self._check_bool_var(self._make_identity_wire().tensor(g))

    def test_compose_preserves_var_registry(self):
        g, _ = self._make_bool_var_circuit()
        wire = self._make_identity_wire()
        wire.compose(g)
        self._check_bool_var(wire)

    def test_apply_diff_preserves_var_registry(self):
        from pyzx.graph.diff import GraphDiff
        g, _ = self._make_bool_var_circuit()
        empty = Graph()
        empty.add_vertex(VertexType.Z, 0, 0)
        result = GraphDiff(empty, g).apply_diff(empty)
        self._check_bool_var(result)


if __name__ == '__main__':
    unittest.main()
