# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.0.0]

### Added in version 2.0.0

* Made the project installable from PyPI
* `.gitlab-ci.yml` file to scan for secrets

### Changed in version 2.0.0

* Increased the version number
* Fixed the exposed port of the Docker image
* Got rid of `getlist()`
* Updated the documentation with information how to start the honeypot at boot
time
* Fixed bugs in the Discord, PostgreSQL, Slack, and Telegram output plugins
* Better Python 2.x/3.x compatibility
* Completely rewritten `Dockerfile`, uses hardened images
* Fixed a bug in the reporting (`ip` was referenced before being determined)

## [1.0.1]

### Changed in version 1.0.1

* Increased the version number
* Improved the encoding of non-ASCII input
* Added rate limiting to the Discord, Slack, and Telegram plugins

## [1.0.0]

### Added in version 1.0.0

* Initial release
* Implemented the honeypot using the Twisted framework
* Made the honeypot compatible with Python 3.x
* Config file support
* Various command-line options
* Log rotation
* Support for the `report_public_ip` config file option
* A script for starting, stopping, and restarting the honeypot
* Documentation
* Output plugin support
* Output plugins for
  * CouchDB
  * Datadog
  * Discord
  * Elasticsearch
  * HPFeeds
  * InfluxDB 2.0 (Python 3.6+ only)
  * JSON
  * Kafka
  * MongoDB
  * MySQL
  * NLCV API
  * PostgeSQL
  * Redis
  * RethinkDB
  * Slack
  * Socket
  * SQLite3
  * Syslog
  * Telegram
  * text
  * XMPP
