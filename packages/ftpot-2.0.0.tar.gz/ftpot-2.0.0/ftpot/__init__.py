# ftpot: the installable Python package for the ftpot honeypot.
#
# After `pip install ftpot`, use the `ftpot` command:
#
#   ftpot init    -- scaffold a working directory
#   ftpot run     -- start the honeypot in the foreground
#   ftpot start   -- start the honeypot in the background
#   ftpot stop    -- stop the background honeypot
#   ftpot restart -- restart the honeypot (stop and start the honeypot in
#                    the background)
#   ftpot status  -- show running status
#
# NOTE: ftpot/honeypot.py is generated at build time by the build_py
# hook in setup.py - it is a copy of the top-level honeypot.py bundled so
# that the `ftpot run/start` entry point can locate and run it.
# It is listed in .gitignore and should not be committed.
#
# Contents:
#   cli.py        the `ftpot` console entry point (init/run/start/stop/status)
#   honeypot.py   the main honeypot script (copied from repo root at build time)
#   data/         bundled read-only assets copied to the working directory
#                 by `ftpot init`:
#     docs/       documentation and SQL schema files
#     etc/        default configuration templates
#     test/       test.py for verifying a running honeypot
