CREATE TABLE IF NOT EXISTS `connections` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `session` CHAR(32) NOT NULL,
  `timestamp` DATETIME DEFAULT NULL,
  `operation` INT DEFAULT NULL,
  `ip` VARCHAR(15) DEFAULT NULL,
  `remote_port` INT DEFAULT NULL,
  `local_host` VARCHAR(15) DEFAULT NULL,
  `local_port` INT DEFAULT NULL,
  `sensor` INT DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `time_idx` (`timestamp`),
  KEY `ip_idx` (`ip`),
  KEY `ip2_idx` (`timestamp`, `ip`)
);

CREATE TABLE IF NOT EXISTS `operations` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `op_name` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE (`op_name`)
);

CREATE TABLE IF NOT EXISTS `credentials` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `session` CHAR(32) NOT NULL,
  `username` INT DEFAULT NULL,
  `password` INT DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE IF NOT EXISTS `usernames` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE (`username`)
);

CREATE TABLE IF NOT EXISTS `passwords` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `password` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE (`password`)
);

CREATE TABLE IF NOT EXISTS `commands` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `session` VARCHAR(32) NOT NULL,
  `cmd` INT DEFAULT NULL,
  `args` INT DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE IF NOT EXISTS `cmds` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `cmd_name` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE(`cmd_name`)
);

CREATE TABLE IF NOT EXISTS `arglines` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `arg_line` VARCHAR(255),
  PRIMARY KEY (`id`),
  UNIQUE(`arg_line`)
);

CREATE TABLE IF NOT EXISTS `sensors` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE (`name`)
);

CREATE TABLE IF NOT EXISTS `geolocation` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `ip` VARCHAR(15) DEFAULT NULL,
  `country_name` VARCHAR(45) DEFAULT '',
  `country_iso_code` VARCHAR(2) DEFAULT '',
  `city_name` VARCHAR(128) DEFAULT '',
  `org` VARCHAR(128) DEFAULT '',
  `org_asn` INT DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE(`ip`)
);
