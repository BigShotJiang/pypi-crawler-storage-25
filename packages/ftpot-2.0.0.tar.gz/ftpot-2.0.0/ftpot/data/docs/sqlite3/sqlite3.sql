CREATE TABLE IF NOT EXISTS `connections` (
  `id` INTEGER PRIMARY KEY,
  `session` VARCHAR(32) NOT NULL,
  `timestamp` DATETIME DEFAULT NULL,
  `ip` VARCHAR(15) DEFAULT NULL,
  `remote_port` INT(11) DEFAULT NULL,
  `operation` INT(4) DEFAULT NULL,
  `local_host` VARCHAR(15) DEFAULT NULL,
  `local_port` INT(11) DEFAULT NULL,
  `sensor` INT(4) DEFAULT NULL
);

CREATE INDEX IF NOT EXISTS `time_idx` ON `connections` (`timestamp`);
CREATE INDEX IF NOT EXISTS `ip_idx` ON `connections` (`ip`);
CREATE INDEX IF NOT EXISTS `ip2_idx` ON `connections` (`timestamp`, `ip`);

CREATE TABLE IF NOT EXISTS `operations` (
  `id` INTEGER PRIMARY KEY,
  `op_name` VARCHAR(20) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS `credentials` (
  `id` INTEGER PRIMARY KEY,
  `session` VARCHAR(32) NOT NULL,
  `username` INT(4) DEFAULT NULL,
  `password` INT(4) DEFAULT NULL
);

CREATE TABLE IF NOT EXISTS `usernames` (
  `id` INTEGER PRIMARY KEY,
  `username` VARCHAR(255) DEFAULT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS `passwords` (
  `id` INTEGER PRIMARY KEY,
  `password` VARCHAR(255) DEFAULT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS `commands` (
  `id` INTEGER PRIMARY KEY,
  `session` VARCHAR(32) NOT NULL,
  `cmd` INT(4) DEFAULT NULL,
  `args` INT(4) DEFAULT NULL
);

CREATE TABLE IF NOT EXISTS `cmds` (
  `id` INTEGER PRIMARY KEY,
  `cmd_name` VARCHAR(20) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS `arglines` (
  `id` INTEGER PRIMARY KEY,
  `arg_line` VARCHAR(255) DEFAULT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS `sensors` (
  `id` INTEGER PRIMARY KEY,
  `name` VARCHAR(255) DEFAULT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS `geolocation` (
  `id` INTEGER PRIMARY KEY,
  `ip` VARCHAR(15) DEFAULT NULL UNIQUE,
  `country_name` VARCHAR(45) DEFAULT '',
  `country_iso_code` VARCHAR(2) DEFAULT '',
  `city_name` VARCHAR(128) DEFAULT '',
  `org` VARCHAR(128) DEFAULT '',
  `org_asn` INT(11) DEFAULT NULL
);
