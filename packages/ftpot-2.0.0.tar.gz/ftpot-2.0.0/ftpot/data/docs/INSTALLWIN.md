# Installation guide (on Windows)

(For installation on Ubuntu, see the corresponding [installation document](INSTALL.md))

- [Installation guide (on Windows)](#installation-guide-on-windows)
  - [Step 1: Install the dependencies](#step-1-install-the-dependencies)
  - [Step 2: Open port 21 for TCP traffic](#step-2-open-port-21-for-tcp-traffic)
  - [Step 3: Create a user account](#step-3-create-a-user-account)
  - [Step 4: Install the honeypot](#step-4-install-the-honeypot)
    - [Installing from PyPI (recommended)](#installing-from-pypi-recommended)
    - [Installing from the repo](#installing-from-the-repo)
  - [Step 5: Initialize the working directory](#step-5-initialize-the-working-directory)
  - [Step 6: Create a configuration file](#step-6-create-a-configuration-file)
  - [Step 7: Start the honeypot](#step-7-start-the-honeypot)
  - [Step 8: Testing the honeypot](#step-8-testing-the-honeypot)
  - [Step 9: Make the honeypot start at boot time](#step-9-make-the-honeypot-start-at-boot-time)
  - [Configure additional output plugins (OPTIONAL)](#configure-additional-output-plugins-optional)
  - [Docker usage (OPTIONAL)](#docker-usage-optional)
  - [Command-line options](#command-line-options)
  - [Upgrading the honeypot](#upgrading-the-honeypot)

## Step 1: Install the dependencies

Log in as a user with Administrator privileges and install the following
programs (if they are not already present):

- **Python**. The latest version of Python 3.x is preferred, although the
  honeypot is compatible with Python 2.7. You can download it from
  [python.org](https://www.python.org/downloads/windows/). Download the
  installer for your platform (64-bit or 32-bit). Make sure to install it
  for all users and not just for the current one, and tick the option to
  add Python to the `PATH` variable of the environment.

- **Database server** (optional). If you want the honeypot to send the data
  it collects to a local database server (e.g., MySQL), make sure to install
  it — again, for all users and not just for the current one.

- The latest version of the **VS C++ redistributable** (required by some of
  the database output plugins, e.g., for MySQL). Version 14 or higher should
  be fine. You can download it from
  [there](https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170).

## Step 2: Open port 21 for TCP traffic

If TCP port 21 is not already opened for incoming connections on your
firewall and router, you must open it now. How exactly to do this from a NAT
router depends on the router model; please consult the instruction manual of
the router.

To open the port on the firewall, open a PowerShell window as Administrator
and use:

```powershell
New-NetFirewallRule -DisplayName 'TCP-21' -Profile @('Domain', 'Private') -Direction Inbound -Action Allow -Protocol TCP -LocalPort 21
```

## Step 3: Create a user account

It is strongly recommended to run the honeypot as a dedicated user with no
administrative privileges (named `HoneyPotter` in our example):

```powershell
Import-Module Microsoft.Powershell.LocalAccounts -SkipEditionCheck
$password = ConvertTo-SecureString "PASSWORD" -AsPlainText -Force
New-LocalUser -Name "HoneyPotter" -Password $password -FullName "HoneyPotter" -Description "Honeypots Account"
Add-LocalGroupMember -Group "Users" -Member "HoneyPotter"
```

Make sure to specify a proper password for that user instead of "PASSWORD".

If you *really* need to be able to log in as this user over RDP, execute the
following line:

```powershell
Add-LocalGroupMember -Group "Remote Desktop Users" -Member "HoneyPotter"
```

However, this is *strongly* discouraged. RDP is a serious attack surface - if
you expose it to the Internet, you will be attacked immediately. Make sure the
user has a very strong and hard-to-guess password, and preferably put some
restriction on who can connect via RDP to this machine - e.g., by putting it
behind a VPN, a Secure Gateway (if the machine is on an Active Directory
network; something which is itself discouraged), or use a firewall rule to
specify which particular IP addresses are allowed to connect to this machine via
RDP - something along the lines of

```powershell
# List on the next line the IP addreses permitted to connect to this machine
$AllowedIPs = @("IP address 1","IP address 2",...)
Get-NetFirewallRule -DisplayGroup "Remote Desktop" | Disable-NetFirewallRule
Get-NetFirewallRule -DisplayName "Restricted RDP" -ErrorAction SilentlyContinue | Remove-NetFirewallRule
New-NetFirewallRule -DisplayName "Restricted RDP" -Direction Inbound -Protocol TCP -LocalPort 3389 -Action Allow -RemoteAddress $AllowedIPs -Profile Any
```

Log out of the Administrator account and log into the account of the newly
created user HoneyPotter.

## Step 4: Install the honeypot

Open a PowerShell window and create a virtual environment. For modern versions
of Python (i.e., 3.6+), use just

```powershell
PS C:\> python -m venv C:\ftpot-env
```

For the obsolete Python 2.7, use

```powershell
PS C:\> pip install "virtualenv==20.15.1"
PS C:\> virtualenv ftpot-env
```

Then activate the virtual environment:

```powershell
PS C:\> .\ftpot-env\Scripts\activate.ps1
```

and update `pip`

```powershell
(ftpot-env) PS C:\> python -m pip install pip --upgrade
```

How you should proceed further depends on whether you want to install the
honeypot from the repo (usually done for testing purposes) or from PyPI
(the recommended approach).

### Installing from PyPI (recommended)

Installing from PyPI is very simple. Just use

```powershell
(ftpot-env) PS C:\> pip install --prefer-binary ftpot[plugin_list]
```

Here, `plugin_list` is a comma-separated list of output plugin names whose
dependencies you want to install. You do not need to install the dependencies
for all existing plugins. For instance, if you plan to use only the `mysql`
and `redisdb` plugins, use `[mysql,redisdb]`. If you want to install the
dependencies for all plugins, use `[all]`.

The output plugins `discord`, `jsonlog`, `localsyslog`, `socketlog`, `sqlite`,
`telegram`, and `textlog` have no dependencies of their own. If you plan to use
only one or more of those, omit the `[plugin_list]` part entirely. It won't hurt
to specify such a plugin (e.g., `[mysql,jsonlog]`) but this is essentially
equivalent to omitting it.

If, after installation, you decide that you're going to use yet another plugin,
simply run the installation command again with the new plugin included in the
`plugin_list`

### Installing from the repo

Ensure that the `build` module is installed, clone the repo, build the
distribution wheel, and install from it:

```powershell
(ftpot-env) PS C:\> pip install build --upgrade
(ftpot-env) PS C:\> git clone https://gitlab.com/bontchev/ftpot.git
(ftpot-env) PS C:\> cd .\ftpot
(ftpot-env) PS C:\ftpot> python -m build
(ftpot-env) PS C:\ftpot> pip install --prefer-binary "$((Get-Item dist\ftpot-*-py2.py3-none-any.whl).FullName)[plugin_list]"
```

where `plugin_list` is as described in the previous section.

## Step 5: Initialize the working directory

Create a directory where the honeypot will store its configuration, data,
documentation, and logs, then initialize it:

```powershell
(ftpot-env) PS C:\> mkdir .\ftpot-workdir
(ftpot-env) PS C:\> cd .\ftpot-workdir
(ftpot-env) PS C:\ftpot-workdir> ftpot init
```

This creates the `etc\`, `log\`, `data\`, and `responses\` subdirectories and
populates them with the default configuration files and response stubs. It also
copies `test.py` (for verifying the honeypot is working), `Dockerfile`, and
`geoipupdtask.ps1` (for scheduling automatic GeoIP database updates) into the
working directory.

## Step 6: Create a configuration file

The configuration for the honeypot is stored in `etc\honeypot.cfg.base` and
`etc\honeypot.cfg`. Both the `*.cfg.base` and the `*.cfg` files are read on
startup but entries from the `*.cfg` files take precedence. The `*.base` files
contain the default settings and should not be edited — they may be overwritten
by future updates. All your customisations should go into the `*.cfg` files.

To run with a standard configuration there is no need to change anything.

For instance, in order to enable JSON logging, create `etc\honeypot.cfg` file
and put in it only the following:

```ini
[output_jsonlog]
enabled = true
logfile = log/ftpot.json
epoch_timestamp = true
```

For more information about how to configure additional output plugins, please
consult the appropriate `READMEWIN.md` file in the subdirectory corresponding
to the plugin inside the `docs\` directory.

**Note on testing:** The default blacklist excludes the logging of connections
from `127.0.0.1` and `192.168.0.0/16`. If you run just `test.py` (with no
arguments) from the same machine as the honeypot, you will not see any log
output because the connection will not be logged. Either run `test.py` with the
option `-H <your-external-IP>`, or temporarily clear the blacklist in
`etc\honeypot.cfg`:

```ini
[honeypot]
blacklist =
```

Next, create a self-signed digital certificate and place it in the `data\`
directory (you'll need the program `openssl` - e.g., available
[from there](https://slproweb.com/products/Win32OpenSSL.html) installed in a
directory listed in the `PATH` variable of the environment):

```powershell
(ftpot-env) PS C:\ftpot-workdir> openssl req -x509 -newkey rsa:4096 -keyout .\data\server.pem -out .\data\server.pem -sha256 -days 3650 -nodes -subj "/C=XX/L=CityName/O=CompanyName/OU=CompanySectionName/CN=CommonNameOrHostname"
```

Make sure you specify a meaningful country code (`XX`), city (`CityName`),
company name (`ComanyName`), company department (`CompanySectionName`), and host
name (`CommonNameOrHostname`). The certificate will expire in about 10 years
(3650 days); make sure to renew it afterwards.

## Step 7: Start the honeypot

From the working directory, with the virtual environment active:

```powershell
(ftpot-env) PS C:\> cd C:\ftpot-workdir
(ftpot-env) PS C:\ftpot-workdir> ftpot start
(ftpot-env) PS C:\ftpot-workdir> ftpot status
The honeypot is running (PID: 12345).
```

To run in the foreground (useful for debugging):

```powershell
(ftpot-env) PS C:\ftpot-workdir> ftpot run
```

Stop it by pressing Ctrl-C.

To stop the honeypot when it is running in the background, use

```powershell
(ftpot-env) PS C:\ftpot-workdir> ftpot stop
Stopping honeypot (PID 12345)... Stopped.
```

## Step 8: Testing the honeypot

Once the honeypot is set up and running at a particular IP address, you can
use the program `test.py` to test that it is working correctly and is emulating
every command as it should.

The general usage of the program is:

```prompt
usage: test.py [-h] [-v] [-p PORT] [-H HOST] [-b] [-o OUTPUTFILE] inputfile

Test the FTP honeypot

positional arguments:
  inputfile             File with test commands

options:
  -h, --help            show this help message and exit
  -v, --version         show program's version number and exit
  -p PORT, --port PORT  Port to send data to (default: 21)
  -H HOST, --host HOST  Host to communicate with (default: hostname)
  -b, --verbose         Echo to stdout the lines sent to the server
  -o OUTPUTFILE, --output OUTPUTFILE
                        Output file (default: stdout)
```

You can use it with the provided file `input` to feed to the honeypot all the
commands it can emulate, save the responses from it, and compare them with the
contents of the file `baseline`, which contains the correct responses.

Assuming that the honeypot is running on `localhost` (see the note about the
blacklist above), port `21`, use

```powershell
PS C:\ftpot-workdir> python test.py -H 127.0.0.1 -b -o output .\docs\input
PS C:\ftpot-workdir> Compare-Object -ReferenceObject (Get-Content .\docs\baseline | Select-Object -Skip 1) -DifferenceObject (Get-Content .\output | Select-Object -Skip 1) 
```

The difference between the two files should be minimal - only in the first
line, which contains the external IP address of the machine that the honeypot
is running on.

## Step 9: Make the honeypot start at boot time

To create a task that starts the honeypot at boot time, open a PowerShell
window as `Administrator` and enter:

```powershell
$Trigger = New-ScheduledTaskTrigger -AtStartup
$Action = New-ScheduledTaskAction -Execute "C:\ftpot-env\Scripts\ftpot.exe" -Argument "start" -WorkingDirectory "C:\ftpot-workdir"
$Settings = New-ScheduledTaskSettingsSet -Hidden -Compatibility Win8
Register-ScheduledTask -Action $Action -TaskName "FtPot" -Trigger $Trigger -Settings $Settings -User "HoneyPotter" -Password "PASSWORD"
```

Make sure to supply the password for the user `HoneyPotter` instead of
"PASSWORD", and adjust the paths if you used different locations.

In order for the user `HoneyPotter` to be able to run tasks at startup, though,
he must have the `SeBatchLogonRight` right - which, by default, he does not.
Unfortunately, there is no way to give him this right via pure PowerShell, so
you'll have to do it from the GUI.

Log in as Administrator, if not already logged in as such, open the `Start` menu
and in the search field enter `secpol.msc` and press Enter. This will start the
Local Security Policy editor. Find
`Local Policies -> User Rights Assignment -> Log on as a batch job` and
double-click it. Press `Add User or Group` enter the user name `HoneyPotter`
and press the two `OK` buttons to close the dialogs.

## Configure additional output plugins (OPTIONAL)

The honeypot automatically outputs event data as text to stdout (or to a log
file, if configured). Additional output plugins can be configured to record
the data in other ways. Supported output plugins currently include:

Destination|Plugin Name
---|---
CouchDB|couch
[Datadog](datadog/README.md)|datadog
[Discord](discord/README.md)|discord
Elasticsearch|elastic
HPFeeds|hpfeed
InfluxDB 2.0|influx2
JSON|jsonlog
Kafka|kafka
MongoDB|mongodb
[MySQL](mysql/READMEWIN.md)|mysql
NLCV API|nlcvapi
[PostgreSQL](postgres/READMEWIN.md)|postgres
Redis|redisdb
RethinkDB|rethinkdblog
[Slack](slack/README.md)|slack
Socket|socketlog
[SQLite3](sqlite3/READMEWIN.md)|sqlite
Syslog|localsyslog
[Telegram](telegram/README.md)|telegram
Text|textlog
XMPP|xmpp

More plugins are likely to be added in the future.

See `docs\[plugin]\READMEWIN.md` for details on each plugin or click on the
names in the above table that are clickable.

**Note:** The `influx2` plugin requires Python 3.x and cannot be used with
Python 2.7. The `localsyslog` plugin works only on Linux.

## Docker usage (OPTIONAL)

Log in as the user `HoneyPotter`, open a PowerShell window, activate the
virtual environment, get the honeypot version number, deactivate the virtual
environment, and build the Docker image from the working directory (the
`Dockerfile` was placed there by `ftpot init`):

```powershell
PS C:\> cd C:\ftpot-workdir
PS C:\ftpot-workdir> .\ftpot-env\scripts\activate.ps1
(ftpot-env) PS C:\ftpot-workdir> $version = ftpot --version
(ftpot-env) PS C:\ftpot-workdir> deactivate

# Build with all plugins (default)
PS C:\ftpot-workdir> docker build --build-arg VERSION=$version -t ftpot .

# Or build with specific plugins only (e.g., only mysql and kafka)
PS C:\ftpot-workdir> docker build --build-arg VERSION=$version --build-arg PLUGINS=mysql,kafka -t ftpot .

# Run, mounting your config and data directories
PS C:\ftpot-workdir> docker run -d -p 21:21/tcp `
  -v ${PWD}\etc\honeypot.cfg:/ftpot/etc/honeypot.cfg `
  -v ${PWD}\data:/ftpot/data `
  ftpot
```

## Command-line options

The honeypot supports the following command-line options:

```bash
  -h, --help            show this help message and exit
  -v, --version         show program's version number and exit
  -w WORKDIR, --workdir WORKDIR
                        Working directory (overrides FTPOT_WORKDIR and cwd)
```

It also supports the following subcommands:

```bash
    init                Scaffold a working directory
    run                 Start the honeypot in the foreground
    start               Start the honeypot in the background
    stop                Stop the backgrounded honeypot
    restart             Restart (stop and start) the honeypot in the background
    status              Show running status
```

All subcommands accept `-w / --workdir DIR` to specify the working directory
explicitly, overriding the `FTPOT_WORKDIR` environment variable and the
current directory.

The `run`, `start`, and `restart` subcommands also accept the options

```bash
  -h, --help            show this help message and exit
  -p PORT, --port PORT  Port to listen on (default: 21)
  -l LOGFILE, --logfile LOGFILE
                        Log file (default: stdout)
  -s SENSOR, --sensor SENSOR
                        Sensor name (default: hostname)
```

Settings specified via command-line options take precedence over the
corresponding settings in the configuration files.

## Upgrading the honeypot

Stop the honeypot, upgrade the package, re-initialize (to pick up any new
default config or response files), and restart:

```powershell
PS C:\> cd C:\ftpot-workdir
PS C:\ftpot-workdir> C:\ftpot-env\Scripts\activate.ps1
(ftpot-env) PS C:\ftpot-workdir> ftpot stop
(ftpot-env) PS C:\ftpot-workdir> pip install --prefer-binary --upgrade ftpot[plugin_list]
(ftpot-env) PS C:\ftpot-workdir> ftpot init
(ftpot-env) PS C:\ftpot-workdir> ftpot start
```

where `[plugin_list]` is as explained above.

Note that `ftpot init` is safe to re-run — it never overwrites files that
you have already edited or created (such as `etc\honeypot.cfg`). It only
copies files that are missing, so any new defaults added by an upgrade are
picked up automatically.
