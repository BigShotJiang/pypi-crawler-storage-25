#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import print_function

from argparse import ArgumentParser
from sys import stderr, stdout


try:
    from ftplib import FTP
except ImportError:
    print('Could not import module "ftplib"; try "pip install ftplib".', file=stderr)
    exit(1)


__description__ = 'Test the FTP honeypot'
__license__ = 'GPL'
__VERSION__ = '1.0.0'
__author__ = 'Vesselin Bontchev'
__email__ = 'vbontchev@yahoo.com'


def get_options():
    parser = ArgumentParser(description=__description__)

    parser.add_argument('-v', '--version', action='version', version='%(prog)s version ' + __VERSION__)
    parser.add_argument('-p', '--port', type=int, default=21,
                        help='Port to send data to (default: %(default)d)')
    parser.add_argument('-H', '--host', default='127.0.0.1',
                        help='Host to communicate with (default: %(default)s)')
    parser.add_argument('-b', '--verbose', action='store_true',
                        help='Echo to stdout the lines sent to the server')
    parser.add_argument('-o', '--output', dest='outputfile', default=None,
                        help='Output file (default: stdout)')
    parser.add_argument('inputfile', help='File with test commands')
    args = parser.parse_args()
    return args


def main():
    args = get_options()

    output_file = open(args.outputfile, 'w') if args.outputfile is not None else stdout

    ftp = FTP()
    try:
        ftp.connect(args.host, args.port)
    except ConnectionRefusedError:
        print('Could not connect to {}:{}.'.format(args.host, args.port), file=stderr)
        return
    resp = ftp.getwelcome()
    print(resp, file=output_file)

    with open(args.inputfile) as f:
        for line in f:
            line = line.strip()
            print(line, file=output_file)
            if len(line) and line[0] != '#':
                if args.verbose:
                    print('Testing: "{}".'.format(line))
                try:
                    resp = ftp.sendcmd(line)
                    print(resp, file=output_file)
                except OSError as e:
                    print('Error: {}.'.format(e.strerror))
                    break
                except Exception as e:
                    print(e, file=output_file)

    ftp.close()

    if args.outputfile is not None:
        output_file.close()


if __name__ == '__main__':
    main()
