# Testing the Honeypot

Once the honeypot is set up and running at a particular IP address, you can
use the program `test.py` to test that it is working correctly and is emulating
every command as it should.

The general usage of the program is:

```prompt
usage: test.py [-h] [-v] [-p PORT] [-H HOST] [-b] [-o OUTPUTFILE] inputfile

Test the FTP honeypot

positional arguments:
  inputfile             File with test commands

options:
  -h, --help            show this help message and exit
  -v, --version         show program's version number and exit
  -p PORT, --port PORT  Port to send data to (default: 21)
  -H HOST, --host HOST  Host to communicate with (default: hostname)
  -b, --verbose         Echo to stdout the lines sent to the server
  -o OUTPUTFILE, --output OUTPUTFILE
                        Output file (default: stdout)
```

You can use it with the provided file `input` to feed to the honeypot all the
commands it can emulate, save the responses from it, and compare them with the
contents of the file `baseline`, which contains the correct responses.

Assuming that the honeypot is running on `localhost`, port `21`, use

```bash
python test.py -H 127.0.0.1 -b -o output input
diff output baseline
```

The difference between the two files should be minimal - only in the first
line, which contains the external IP address of the machine that the honeypot
is running on.
