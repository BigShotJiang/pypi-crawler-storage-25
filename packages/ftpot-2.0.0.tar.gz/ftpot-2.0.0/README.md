# FTPot: an FTP Honeypot

This is a honeypot simulating an FTP server. It borrows some ideas from
[ftp-honeypot](https://github.com/0xNslabs/ftp-honeypot).

The honeypot does not emulate a full FTP server with files and directories -
it only records the IP of the attacker, as well as the username and password
used, if any, and returns a "bad login credentials" error.

## Prerequisites

- a working database server (only if you use an output plugin that outputs to
a database - e.g., MySQL)

## Usage

Check the [Linux installation guide](ftpot/data/docs/INSTALL.md) or the
[Windows installation guide](ftpot/data/docs/INSTALLWIN.md) for complete
instructions on how to install, configure, and run the honeypot.
