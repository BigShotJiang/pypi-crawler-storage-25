
from __future__ import absolute_import

from core import output
from core.config import CONFIG
from core.tools import geolocate

from geoip2.database import Reader
from psycopg2 import OperationalError

from twisted.enterprise.adbapi import ConnectionPool
from twisted.python.log import msg


class Output(output.Output):

    def start(self):
        host = CONFIG.get('output_postgres', 'host', fallback='localhost')
        port = CONFIG.getint('output_postgres', 'port', fallback=5432)
        username = CONFIG.get('output_postgres', 'username', fallback='ftpot')
        password = CONFIG.get('output_postgres', 'password')
        database = CONFIG.get('output_postgres', 'database', fallback='ftpot')
        self.debug = CONFIG.getboolean('output_postgres', 'debug', fallback=False)
        self.geoip = CONFIG.getboolean('output_postgres', 'geoip', fallback=True)

        try:
            self.dbh = ConnectionPool(
                'psycopg2',
                database=database,
                user=username,
                password=password,
                host=host,
                port=port,
                cp_min=1,
                cp_max=1
            )
        except OperationalError as e:
            msg('output_postgres: postgres Error: {}'.format(e))

        if self.geoip:
            geoipdb_city_path = CONFIG.get('output_postgres', 'geoip_citydb', fallback='data/GeoLite2-City.mmdb')
            geoipdb_asn_path  = CONFIG.get('output_postgres', 'geoip_asndb', fallback='data/GeoLite2-ASN.mmdb')
            try:
                self.reader_city = Reader(geoipdb_city_path)
            except Exception:
                self.reader_city = None
                msg('Failed to open City GeoIP database {}'.format(geoipdb_city_path))
            try:
                self.reader_asn = Reader(geoipdb_asn_path)
            except Exception:
                self.reader_asn = None
                msg('Failed to open ASN GeoIP database {}'.format(geoipdb_asn_path))

    def stop(self):
        if self.geoip:
            if self.reader_city is not None:
                self.reader_city.close()
            if self.reader_asn is not None:
                self.reader_asn.close()

    def write(self, event):
        self.dbh.runInteraction(self.connect_event, event)

    def simple_query(self, txn, sql, args, returns_value=True):
        if self.debug:
            msg('output_postgres: postgres query: {} {}'.format(sql, repr(args)))
        result = None
        try:
            txn.execute(sql, args)
            if returns_value:
                result = txn.fetchone()
        except Exception as e:
            msg('output_postgres: postgres Error: {}'.format(e))
        return result

    def get_id(self, txn, table, column, entry):
        r = self.simple_query(
            txn,
            "SELECT id FROM {} WHERE {} = %s".format(table, column),
            (entry, ))
        if r:
            id = int(r[0])
        else:
            r = self.simple_query(
                txn,
                "INSERT INTO {} ({}) VALUES (%s) RETURNING id".format(table, column),
                (entry, ))
            if r:
                id = int(r[0])
            else:
                id = 0
        return id

    def connect_event(self, txn, event):
        remote_ip = event['src_ip']
        operation_id = self.get_id(txn, 'operations', 'op_name', event['operation'])
        sensor_id = self.get_id(txn, 'sensors', 'sname', event['sensor'])

        self.simple_query(
            txn,
            """
            INSERT INTO connections (
                sess_no, time_stamp, ip, remote_port, operation,
                local_host, local_port, sensor)
            VALUES (%s, to_timestamp(%s), %s, %s, %s, %s, %s, %s)
            """,
            (event['session'], event['unixtime'], remote_ip, event['src_port'], operation_id,
             event['dst_ip'], event['dst_port'], sensor_id, ),
            False
        )

        if 'command' in event:
            cmd_id = self.get_id(txn, 'cmds', 'cmd_name', event['command'])
            if 'args' in event:
                args_id = self.get_id(txn, 'arglines', 'arg_line', event['args'])
            else:
                args_id = 0
            self.simple_query(
                txn,
                """
                INSERT INTO commands (sess_no, cmd, args) VALUES(%s, %s, %s)
                """,
                (event['session'], cmd_id, args_id, ),
                False
            )

        if event['operation'].lower() == 'login':
            usr_id = self.get_id(txn, 'usernames', 'username', event['username'])
            pwd_id = self.get_id(txn, 'passwords', 'passwd', event['password'])
            self.simple_query(
                txn,
                """
                INSERT INTO credentials (sess_no, username, passwd) VALUES(%s, %s, %s)
                """,
                (event['session'], usr_id, pwd_id, ),
                False
            )

        if self.geoip:
            country, country_code, city, org, asn_num = geolocate(remote_ip, self.reader_city, self.reader_asn)
            self.simple_query(
                txn,
                """
                INSERT INTO geolocation (ip, country_name, country_iso_code, city_name, org, org_asn)
                VALUES (%s, %s, %s, %s, %s, %s)
                ON CONFLICT (ip) DO UPDATE SET
                    country_name = EXCLUDED.country_name,
                    country_iso_code = EXCLUDED.country_iso_code,
                    city_name = EXCLUDED.city_name,
                    org = EXCLUDED.org,
                    org_asn = EXCLUDED.org_asn
                """,
                (remote_ip, country, country_code, city, org, asn_num, ),
                False
            )
