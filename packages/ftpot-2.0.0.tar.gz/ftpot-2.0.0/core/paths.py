"""
paths.py - Single source of truth for runtime path resolution.

The honeypot needs a "working directory" containing:
  etc/          config files (honeypot-launch.cfg.base, honeypot.cfg.base)
  data/         geolocation databases, SQLite db, etc.
  log/          rotating log files (created on demand)

Priority for locating the working directory:
  1. FTPOT_WORKDIR environment variable
  2. Current working directory

The bundled read-only defaults (etc/honeypot.cfg.base) are installed inside the
`ftpot` package and located via the package's own __file__ attribute, which
works on all Python versions without requiring pkg_resources or
importlib.resources.
"""

from __future__ import absolute_import


from os import getcwd, environ
from os.path import abspath, dirname, join


def get_workdir():
    """Return the absolute path to the runtime working directory."""
    env = environ.get('FTPOT_WORKDIR', '').strip()
    if env:
        return abspath(env)
    return getcwd()


def workdir_path(*parts):
    """Return an absolute path rooted at the working directory."""
    return join(get_workdir(), *parts)


def bundled(*parts):
    """
    Return the filesystem path to a file bundled inside the installed package.
    Arguments are path components relative to the ftpot/data/ directory,
    passed as separate strings (like os.path.join) to avoid hardcoded separators.

    Uses the package's own __file__ to locate the data directory, which works
    on all Python versions (2.7+) without requiring pkg_resources or
    importlib.resources.
    """
    # ftpot/data/ lives alongside this module's package (core/ is a sibling
    # of ftpot/), so we go up one level from core/ to find ftpot/data/.
    here = dirname(abspath(__file__))
    package_dir = join(dirname(here), 'ftpot')
    return join(package_dir, 'data', *parts)
