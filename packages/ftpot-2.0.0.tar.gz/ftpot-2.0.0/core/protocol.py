
from __future__ import absolute_import

from ipaddress import ip_address, ip_network
from sys import version_info
from time import time
from uuid import uuid4

from core.tools import (
    decode,
    encode,
    get_local_ip,
    get_utc_time,
    printable,
    write_event
)

from twisted.internet.ssl import PrivateCertificate
from twisted.internet.protocol import ServerFactory
from twisted.protocols.basic import LineReceiver
from twisted.python.log import msg


if version_info[0] >= 3:
    def unicode(x):
        return x


class MyFTPServer(LineReceiver):
    def __init__(self, options):
        self.cfg = options
        self.userReceived = False
        self.user = ''
        self.is_fttps = False

    def connectionMade(self):
        self.session = uuid4().hex[:12]
        self.report_event('connect')
        self.send_line('220 ProFTPD 1.3.4b Server (TP-Share) [{}]'.format(self.cfg['public_ip']))

    def lineReceived(self, line):
        line = decode(line)
        parts = line.split(None, 1)
        if parts:
            command = parts[0].upper()
            args = parts[1] if len(parts) > 1 else ''
            self.report_event('command', command, args)
            self.process_command(command, args)

    def connectionLost(self, reason):
        self.report_event('disconnect', reason.value)
        self.session = None
        self.userReceived = False
        self.user = ''
        self.is_fttps = False

    def report_event(self, operation, username=None, password=None):
        operation = operation.lower()
        unix_time = time()
        peer = self.transport.getPeer()
        ip = peer.host
        for network in self.cfg['blacklist']:
            if ip_address(unicode(ip)) in ip_network(unicode(network)):
                return
        port = peer.port
        event = {
            'eventid': 'ftpot.' + operation,
            'operation': operation,
            'timestamp': get_utc_time(unix_time),
            'unixtime': unix_time,
            'src_ip': ip,
            'src_port': port,
            'dst_port': self.cfg['port'],
            'sensor': self.cfg['sensor'],
            'dst_ip': self.cfg['public_ip'] if self.cfg['report_public_ip'] else get_local_ip(),
            'session': self.session
        }
        if operation == 'login':
            event['username'] = printable(username)
            event['password'] = printable(password)
            message = 'Login with username: "{}", password: "{}" from {}:{}.'.format(
                event['username'],
                event['password'],
                ip,
                port
            )
        elif operation == 'connect':
            message = 'Connection made from {}:{}.'.format(ip, port)
        elif operation == 'command':
            command = printable(username)
            event['command'] = command
            if password:
                event['args'] = printable(password)
                command += ' ' + event['args']
            else:
                event['args'] = ''
            message = 'Command "{}" from {}:{}.'.format(command, ip, port)
        elif operation == 'disconnect':
            message = '{}:{} disconnected. Reason: {}'.format(ip, port, username)
        else:
            command = printable(username)
            event['command'] = command
            if password:
                event['args'] = printable(password)
                command += ' ' + event['args']
            message = 'Unknown operation "{}" from {}:{}.'.format(command, ip, port)
        msg(message)
        write_event(event, self.cfg)

    def send_line(self, line):
        self.transport.write(encode(line + '\r\n'))

    def process_command(self, command, args):
        needs_auth = [
            'PASV', 'CWD', 'XCWD', 'CDUP', 'XCUP', 'SMNT',
            'EPRT', 'EPSV', 'ALLO', 'RNFR', 'RNTO', 'DELE', 'MDTM',
            'RMD', 'XRMD', 'MKD', 'XMKD', 'PWD', 'XPWD', 'SIZE',
            'STRU', 'MODE', 'RETR', 'STOR', 'STOU', 'APPE', 'SITE',
            'REST', 'ABOR', 'LIST', 'NLST', 'STAT', 'MLSD', 'MLST'
        ]
        help_msg = (
            "214-The following commands are recognized (* =>'s unimplemented):\r\n"
            ' CWD     XCWD    CDUP    XCUP    SMNT*   QUIT    PORT    PASV\r\n'
            ' EPRT    EPSV    ALLO*   RNFR    RNTO    DELE    MDTM    RMD\r\n'
            ' XRMD    MKD     XMKD    PWD     XPWD    SIZE    SYST    HELP\r\n'
            ' NOOP    FEAT    OPTS    AUTH    CCC     CONF*   ENC*    MIC*\r\n'
            ' PBSZ*   PROT*   TYPE    STRU    MODE    RETR    STOR    STOU\r\n'
            ' APPE    REST    ABOR    USER    PASS    ACCT*   REIN*   LIST\r\n'
            ' NLST    STAT    SITE    MLSD    MLST\r\n'
            '214 Direct comments to root@0.0.0.0'
        )
        feat_msg = (
            '211-Features:\r\n'
            ' MDTM\r\n'
            ' MFMT\r\n'
            ' TVFS\r\n'
            ' UTF8\r\n'
            ' MFF modify;UNIX.group;UNIX.mode;\r\n'
            ' MLST modify*;perm*;size*;type*;unique*;UNIX.group*;UNIX.mode*;UNIX.owner*;\r\n'
            ' LANG en-US*\r\n'
            ' REST STREAM\r\n'
            ' SIZE\r\n'
            '211 End'
        )
        if command == 'USER':
            self.userReceived = True
            self.user = args
            self.send_line('331 Password required for {}.'.format(args))
        elif command == 'PASS' and self.userReceived:
            self.report_event('login', self.user, args)
            self.send_line('530 Login incorrect.')
            self.userReceived = False
        elif command == 'OPTS':
            if args:
                self.send_line('200 UTF8 set to on')
            else:
                self.send_line('501 Invalid number of arguments')
        elif command == 'NOOP':
            self.send_line('200 NOOP command successful')
        elif command == 'SYST':
            self.send_line('215 UNIX Type: L8')
        elif command == 'TYPE':
            if args:
                arg = args.split(None, 1)[0]
                if arg.lower() in ['a', 'i', 'l']:
                    self.send_line('200 Type set to {}'.format(arg.upper()))
                else:
                    self.send_line("500 'TYPE {}' not understood".format(arg))
            else:
                self.send_line("500 'TYPE' not understood")
        elif command == 'HOST':
            if args:
                arg = args.split(None, 1)[0]
                self.send_line('504 {}: Unknown hostname provided'.format(arg))
            else:
                self.send_line("500 'HOST' not understood")
        elif command == 'AUTH':
            if len(args) == 0:
                self.send_line('504 AUTH requires at least one argument')
            elif args.upper().strip() not in ['TLS', 'TLS-C', 'SSL', 'TLS-P']:
                self.send_line('500 AUTH not understood')
            elif self.is_fttps:
                self.send_line('200 User is already authenticated.')
            elif self.cfg['factory_options'] is not None:
                self.send_line('234 AUTH TLS successful')
                self.transport.startTLS(self.cfg['factory_options'])
                self.is_fttps = True
            else:
                self.send_line('500 AUTH not understood')
        elif command == 'CCC':
            if not self.is_fttps:
                self.send_line('533 Command channel is alredy cleared')
            else:
                self.send_line('200 Clear Command Channel OK')
                self.transport.stopTLS()
                self.is_fttps = False
        elif command == 'HELP':
            if args:
                self.process_help(args)
            else:
                self.send_line(help_msg)
        elif command == 'FEAT':
            self.send_line(feat_msg)
        elif command == 'QUIT':
            self.send_line('221 Goodbye.')
            self.transport.loseConnection()
        elif command in needs_auth:
            self.send_line('530 Please login with USER and PASS')
        else:
            self.send_line('500 {} not understood'.format(command))

    def process_help(self, args):
        required_path = [
            'CWD', 'XCWD', 'RNFR', 'RNTO', 'DELE', 'MDTM', 'STOR',
            'RMD', 'XRMD', 'MKD', 'XMKD', 'SIZE', 'RETR', 'APPE'
        ]
        optional_path = [
            'LIST', 'STAT', 'MLSD', 'MLST'
        ]
        help_texts = {
            'CDUP': '(up one directory)',
            'XCUP': '(up one directory)',
            'SMNT': 'is not implemented',
            'QUIT': '(close control connection)',
            'PORT': '<sp> h1,h2,h3,h4,p1,p2',
            'PASV': '(returns address/port)',
            'EPRT': '<sp> |proto|addr|port|',
            'EPSV': '(returns port |||port|)',
            'ALLO': 'is not implemented (ignored)',
            'PWD': '(returns current working directory)',
            'XPWD': '(returns current working directory)',
            'SYST': '(returns system type)',
            'HELP': '[<sp> command]',
            'NOOP': '(no operation)',
            'FEAT': '(returns feature list)',
            'OPTS': '<sp> command [<sp> options]',
            'AUTH': '<sp> base64-data',
            'CCC': '(clears protection level)',
            'CONF': '<sp> base64-data',
            'ENC': '<sp> base64-data',
            'MIC': '<sp> base64-data',
            'PBSZ': '<sp> protection buffer size',
            'PROT': '<sp> protection code',
            'TYPE': '<sp> type-code (A, I, L 7, L 8)',
            'STRU': 'is not implemented (always F)',
            'MODE': 'is not implemented (always S)',
            'STOU': '(store unique filename)',
            'REST': '<sp> byte-count',
            'ABOR': '(abort current operation)',
            'USER': '<sp> username',
            'PASS': '<sp> password',
            'NLST': '[<sp> (pathname)]',
            'ACCT': 'is not implemented',
            'REIN': 'is not implemented',
        }
        command = args.split(None, 1)[0].upper()
        if command in required_path:
            self.send_line('214 Syntax: {} <sp> pathname'.format(command))
        elif command in optional_path:
            self.send_line('214 Syntax: {} [<sp> pathname]'.format(command))
        elif command in help_texts:
            self.send_line('214 Syntax: {} {}'.format(command, help_texts[command]))
        elif command == 'SITE':
            self.send_line('214-HELP\r\n CHGRP\r\n214 CHMOD')
        else:
            self.send_line("502 Unknown command '{}'".format(command))


class MyFTPFactory(ServerFactory):
    def __init__(self, cfg):
        cfg['factory_options'] = None
        if cfg['cert']:
            cert_data = ''
            try:
                with open(cfg['cert']) as f:
                    cert_data += f.read()
            except OSError:
                msg('Could not read the file "{}".'.format(cfg['cert']))
            if cert_data:
                cfg['factory_options'] = PrivateCertificate.loadPEM(cert_data).options()
        self.cfg = cfg

    def buildProtocol(self, addr):
        return MyFTPServer(self.cfg)
