#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
加密锁屏功能 API 路由

密码存储：/home/pi/.xgo-blockly/lock.json
加密状态 = 密码文件是否存在
密码使用 SHA-256 + salt 哈希存储
"""

import os
import json
import hashlib
import secrets
import time
from datetime import datetime
from flask import Blueprint, request, jsonify

encryption_bp = Blueprint('encryption', __name__, url_prefix='/api/encryption')

# 密码文件路径（树莓派默认路径）
LOCK_FILE_PATH = '/home/pi/.xgo-blockly/lock.json'
# 其他系统 fallback 路径
FALLBACK_LOCK_FILE_PATH = os.path.expanduser('~/.xgo-blockly/lock.json')

# 内存中的 session token 存储：{token: timestamp}
_active_tokens = {}
# token 最大数量
MAX_TOKENS = 50


def _get_lock_file_path():
    """获取密码文件路径，自动适配不同系统"""
    if os.path.exists(LOCK_FILE_PATH) or os.path.exists('/home/pi'):
        return LOCK_FILE_PATH
    return FALLBACK_LOCK_FILE_PATH


def _ensure_dir(filepath):
    """确保文件所在目录存在"""
    d = os.path.dirname(filepath)
    if d and not os.path.exists(d):
        os.makedirs(d, exist_ok=True)


def _read_lock_data():
    """读取密码文件内容"""
    path = _get_lock_file_path()
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None


def _write_lock_data(data):
    """写入密码文件"""
    path = _get_lock_file_path()
    _ensure_dir(path)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def _delete_lock_file():
    """删除密码文件"""
    path = _get_lock_file_path()
    if os.path.exists(path):
        os.remove(path)


def _hash_password(password, salt=None):
    """SHA-256 + salt 哈希密码"""
    if salt is None:
        salt = secrets.token_hex(16)
    h = hashlib.sha256()
    h.update((password + salt).encode('utf-8'))
    return h.hexdigest(), salt


def _generate_token():
    """生成随机 session token"""
    return secrets.token_hex(32)


def _clean_expired_tokens():
    """清理过期 token（超过 24 小时未活动）"""
    now = time.time()
    expired = [t for t, ts in _active_tokens.items() if now - ts > 86400]
    for t in expired:
        del _active_tokens[t]


def _store_token(token):
    """存储 token"""
    _clean_expired_tokens()
    # 防止 token 数过多
    if len(_active_tokens) >= MAX_TOKENS:
        oldest = sorted(_active_tokens.items(), key=lambda x: x[1])
        for t, _ in oldest[:10]:
            del _active_tokens[t]
    _active_tokens[token] = time.time()


@encryption_bp.route('/status', methods=['GET'])
def status():
    """检查加密是否启用"""
    lock_data = _read_lock_data()
    enabled = lock_data is not None and 'password_hash' in lock_data
    return jsonify({'enabled': enabled})


@encryption_bp.route('/set', methods=['POST'])
def set_password():
    """设置密码（首次设置或修改）"""
    try:
        data = request.get_json()
        if not data or 'password' not in data:
            return jsonify({'success': False, 'message': '缺少 password 参数'}), 400

        password = data.get('password', '')
        old_password = data.get('old_password', '')

        # 如果已有密码，需要验证旧密码
        existing = _read_lock_data()
        if existing and 'password_hash' in existing:
            if not old_password:
                return jsonify({'success': False, 'message': '已设置密码，需要提供旧密码进行修改'}), 400
            old_hash, _ = _hash_password(old_password, existing.get('salt', ''))
            if old_hash != existing['password_hash']:
                return jsonify({'success': False, 'message': '旧密码错误'}), 403

        # 密码长度校验
        if len(password) < 1:
            return jsonify({'success': False, 'message': '密码不能为空'}), 400

        password_hash, salt = _hash_password(password)
        lock_data = {
            'password_hash': password_hash,
            'salt': salt,
            'created_at': datetime.now().isoformat()
        }
        _write_lock_data(lock_data)
        return jsonify({'success': True, 'message': '密码设置成功'})

    except Exception as e:
        return jsonify({'success': False, 'message': f'设置密码失败：{str(e)}'}), 500


@encryption_bp.route('/verify', methods=['POST'])
def verify_password():
    """验证密码，成功后返回 session token"""
    try:
        data = request.get_json()
        if not data or 'password' not in data:
            return jsonify({'success': False, 'message': '缺少 password 参数'}), 400

        password = data.get('password', '')
        lock_data = _read_lock_data()

        if not lock_data or 'password_hash' not in lock_data:
            return jsonify({'success': False, 'message': '未设置密码'}), 400

        password_hash, _ = _hash_password(password, lock_data.get('salt', ''))
        if password_hash != lock_data['password_hash']:
            return jsonify({'success': False, 'message': '密码错误'}), 403

        # 生成 session token
        token = _generate_token()
        _store_token(token)

        return jsonify({'success': True, 'token': token, 'message': '验证成功'})

    except Exception as e:
        return jsonify({'success': False, 'message': f'验证失败：{str(e)}'}), 500


@encryption_bp.route('/remove', methods=['POST'])
def remove_password():
    """移除密码"""
    try:
        data = request.get_json()
        if not data or 'password' not in data:
            return jsonify({'success': False, 'message': '缺少 password 参数'}), 400

        password = data.get('password', '')
        lock_data = _read_lock_data()

        if not lock_data or 'password_hash' not in lock_data:
            return jsonify({'success': False, 'message': '未设置密码'}), 400

        password_hash, _ = _hash_password(password, lock_data.get('salt', ''))
        if password_hash != lock_data['password_hash']:
            return jsonify({'success': False, 'message': '密码错误'}), 403

        _delete_lock_file()
        # 清除所有 token
        _active_tokens.clear()
        return jsonify({'success': True, 'message': '密码已移除，加密功能已关闭'})

    except Exception as e:
        return jsonify({'success': False, 'message': f'移除密码失败：{str(e)}'}), 500
