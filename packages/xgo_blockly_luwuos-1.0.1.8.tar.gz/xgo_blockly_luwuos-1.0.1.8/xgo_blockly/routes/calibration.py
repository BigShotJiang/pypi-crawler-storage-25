#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
摄像头标定 API 路由
提供棋盘格标定的图像捕获、状态查询、执行标定和重置功能
"""

import logging
import time
import cv2
import numpy as np
from flask import Blueprint, jsonify

from ..services.camera_calibration import (
    load_calibration,
    run_calibration,
    delete_calibration,
    CHESSBOARD_SIZE,
)

logger = logging.getLogger(__name__)

# 创建标定蓝图
calibration_bp = Blueprint('calibration', __name__, url_prefix='/api/calibration')

# 模块级状态：存储已捕获的标定图像
_captured_images = []


def _capture_frame():
    """
    从摄像头捕获一帧图像（BGR 格式）。
    使用 320x240 分辨率，确保与标定参数一致。
    Returns:
        numpy array (BGR) 或 None
    """
    # 先关闭 REPL 会话，释放实时模式可能占用的摄像头
    try:
        from ..services.repl_session import repl_session_manager
        repl_session_manager.shutdown()
        import time as _time
        _time.sleep(0.5)
    except Exception:
        pass

    # 方式1: libcamera-still（CM5 libcamera 驱动，首选）
    try:
        import subprocess, os
        tmp_path = '/tmp/calibration_capture.jpg'
        result = subprocess.run(
            ['libcamera-still', '-o', tmp_path, '--nopreview', '-t', '500',
             '--width', '320', '--height', '240'],
            capture_output=True, timeout=10
        )
        if result.returncode == 0 and os.path.exists(tmp_path):
            frame = cv2.imread(tmp_path)
            try:
                os.remove(tmp_path)
            except Exception:
                pass
            if frame is not None:
                logger.info("标定捕获: libcamera-still 成功")
                return frame
    except Exception as e:
        logger.debug("标定捕获: libcamera-still 不可用: %s", e)

    # 方式2: Picamera2（CM5 Python 接口，fallback）
    picam = None
    try:
        from picamera2 import Picamera2
        from libcamera import Transform

        picam = Picamera2()
        config = picam.create_still_configuration(
            main={"size": (320, 240), "format": "RGB888"},
            transform=Transform(hflip=0, vflip=0)
        )
        picam.configure(config)
        picam.start()
        time.sleep(1)
        # 丢弃前5帧，等待自动曝光稳定
        for _ in range(5):
            picam.capture_array()
            time.sleep(0.1)
        image = picam.capture_array()
        picam.stop()
        picam.close()
        picam = None

        if image is not None:
            # RGB -> BGR for OpenCV
            frame = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
            logger.info("标定捕获: Picamera2 成功")
            return frame
    except Exception as e:
        logger.debug("标定捕获: Picamera2 不可用: %s", e)
        if picam is not None:
            try:
                picam.stop()
                picam.close()
            except Exception:
                pass

    logger.warning("标定捕获: 所有方式均失败")
    return None


@calibration_bp.route('/capture', methods=['POST'])
def capture():
    """捕获一帧棋盘格图像用于标定"""
    global _captured_images

    frame = _capture_frame()
    if frame is None:
        return jsonify({
            'success': False,
            'message': '无法从摄像头捕获图像，请确保摄像头已连接'
        }), 500

    # 检测棋盘格角点
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    ret, corners = cv2.findChessboardCorners(gray, CHESSBOARD_SIZE, None)

    if not ret:
        return jsonify({
            'success': False,
            'message': '未在图像中检测到棋盘格角点，请调整摄像头角度后重试',
            'captured_count': len(_captured_images)
        })

    # 检测到棋盘格，保存图像
    _captured_images.append(frame)

    return jsonify({
        'success': True,
        'message': f'成功捕获第 {len(_captured_images)} 张棋盘格图像',
        'captured_count': len(_captured_images)
    })


@calibration_bp.route('/status', methods=['GET'])
def status():
    """获取当前已捕获的图像数量和标定状态"""
    import os
    from ..services.camera_calibration import CALIBRATION_FILE

    has_calibration = os.path.exists(CALIBRATION_FILE)
    calibration_info = None
    if has_calibration:
        try:
            import json
            with open(CALIBRATION_FILE, 'r') as f:
                data = json.load(f)
            calibration_info = {
                'rms_error': data.get('rms_error'),
                'image_size': data.get('image_size'),
            }
        except Exception:
            pass

    return jsonify({
        'success': True,
        'captured_count': len(_captured_images),
        'has_calibration': has_calibration,
        'calibration_info': calibration_info
    })


@calibration_bp.route('/run', methods=['POST'])
def run():
    """执行标定计算，返回重投影误差"""
    global _captured_images

    if len(_captured_images) < 3:
        return jsonify({
            'success': False,
            'message': f'当前仅有 {len(_captured_images)} 张图像，至少需要3张才能进行标定'
        })

    result = run_calibration(_captured_images)
    return jsonify(result)


@calibration_bp.route('/reset', methods=['POST'])
def reset():
    """重置标定数据，恢复默认参数"""
    global _captured_images
    _captured_images = []
    delete_calibration()

    return jsonify({
        'success': True,
        'message': '已重置标定数据并恢复默认参数'
    })
