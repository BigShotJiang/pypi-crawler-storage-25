#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
文件管理服务
封装所有文件系统操作
"""

import os
import shutil


class FileManager:
    def list_dir(self, path):
        """列出目录内容，返回文件/文件夹列表，每项包含 name, type, size, modified"""
        entries = []
        for name in os.listdir(path):
            full_path = os.path.join(path, name)
            try:
                stat = os.stat(full_path)
                entries.append({
                    'name': name,
                    'type': 'directory' if os.path.isdir(full_path) else 'file',
                    'size': stat.st_size,
                    'modified': stat.st_mtime
                })
            except OSError:
                entries.append({
                    'name': name,
                    'type': 'unknown',
                    'size': 0,
                    'modified': ''
                })
        return entries

    def read_file(self, path):
        """读取文本文件内容"""
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()

    def write_file(self, path, content):
        """写入文本文件"""
        dir_path = os.path.dirname(path)
        if dir_path:
            os.makedirs(dir_path, exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)

    def mkdir(self, path):
        """创建目录（支持递归）"""
        os.makedirs(path, exist_ok=True)

    def delete(self, path):
        """删除文件或目录"""
        if os.path.isdir(path):
            shutil.rmtree(path)
        else:
            os.remove(path)

    def rename(self, old_path, new_path):
        """重命名/移动"""
        new_dir = os.path.dirname(new_path)
        if new_dir:
            os.makedirs(new_dir, exist_ok=True)
        os.rename(old_path, new_path)

    def get_file_info(self, path):
        """获取单个文件/目录信息"""
        stat = os.stat(path)
        return {
            'name': os.path.basename(path),
            'type': 'directory' if os.path.isdir(path) else 'file',
            'size': stat.st_size,
            'modified': stat.st_mtime
        }


file_manager = FileManager()
