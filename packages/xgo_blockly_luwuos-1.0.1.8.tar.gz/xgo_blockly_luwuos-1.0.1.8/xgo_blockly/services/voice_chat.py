# -*- coding: utf-8 -*-
"""
语音对话模块 - 整合 ASR + LLM(流式+Function Call) + TTS
支持半双工模式，屏幕显示当前状态
"""

import os
import json
import time
import base64
import asyncio
import threading
import websocket
import websockets
import requests
import psutil
from typing import Optional, Callable, Dict, Any, List
from openai import OpenAI
from enum import Enum

# 抑制 ALSA 警告信息（仅影响 stderr，不影响功能）
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = '1'
os.environ['ALSA_CARD'] = 'default'  # 避免 ALSA 搜索不存在的设备

# 导入 voice_chat 专用工具模块（支持包导入和直接运行两种模式）
try:
    from .voice_chat_tools import (
        VoiceChatToolExecutor,
        get_tool_definitions as get_voice_chat_tools,
        is_hardware_available,
        get_model_type,
        get_xgo_edu,  # 用于屏幕显示
    )
except ImportError:
    from voice_chat_tools import (
        VoiceChatToolExecutor,
        get_tool_definitions as get_voice_chat_tools,
        is_hardware_available,
        get_model_type,
        get_xgo_edu,  # 用于屏幕显示
    )

# 兼容性：从工具模块获取硬件状态
HAS_XGO = is_hardware_available()
_xgo_model_type = get_model_type()
print(f"✓ voice_chat: 机型={_xgo_model_type}, 硬件可用={HAS_XGO}")


class ToolExecutor:
    """
    voice_chat.py 专用工具执行器
    
    使用独立的 voice_chat_tools.py 模块，避免与 agents/tools 耦合。
    """
    
    def __init__(self, api_key: str = None):
        self._executor = VoiceChatToolExecutor(api_key)
    
    def get_tools(self) -> List[Dict]:
        """获取所有工具定义"""
        return self._executor.get_tools()
    
    def execute(self, tool_name: str, arguments: Dict) -> str:
        """执行工具"""
        return self._executor.execute(tool_name, arguments)


# 工具定义已移至 voice_chat_tools.py
# TOOL_DEFINITIONS 通过 ToolExecutor.get_tools() 获取


def cleanup_conflicting_processes():
    """
    清理可能导致资源冲突的进程
    
    解决卡住的 Python 进程（disk-sleep 状态）占用硬件的问题
    
    Returns:
        清理的进程数量
    """
    killed_count = 0
    
    try:
        for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'status']):
            try:
                if proc.info['name'] and 'python' in proc.info['name'].lower():
                    cmdline = proc.info['cmdline']
                    if not cmdline:
                        continue
                    
                    cmdline_str = ' '.join(cmdline)
                    proc_status = proc.info.get('status', '')
                    
                    # 跳过当前进程
                    if proc.pid == os.getpid():
                        continue
                    
                    should_kill = False
                    reason = ""
                    
                    # 情况1: disk-sleep 状态的 Python 进程（硬件阻塞）
                    if proc_status == psutil.STATUS_DISK_SLEEP:
                        should_kill = True
                        reason = "disk-sleep 硬件阻塞"
                    
                    # 情况2: 之前卡住的语音对话进程
                    elif 'voice_chat' in cmdline_str and proc.pid != os.getpid():
                        # 检查是否是旧进程（运行超过 5 分钟）
                        try:
                            create_time = proc.create_time()
                            if time.time() - create_time > 300:
                                should_kill = True
                                reason = "旧 voice_chat 进程"
                        except:
                            pass
                    
                    if should_kill:
                        print(f"[清理] 终止进程: PID={proc.pid}, 原因={reason}")
                        print(f"        命令: {cmdline_str[:80]}...")
                        
                        proc_obj = psutil.Process(proc.pid)
                        
                        # 先尝试优雅终止
                        proc_obj.terminate()
                        try:
                            proc_obj.wait(timeout=2)
                        except psutil.TimeoutExpired:
                            # 强制杀死
                            proc_obj.kill()
                            proc_obj.wait(timeout=2)
                        
                        killed_count += 1
                        
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
            except Exception as e:
                print(f"[清理] 检查进程时出错: {e}")
                continue
                
    except Exception as e:
        print(f"[清理] 清理进程时出错: {e}")
    
    if killed_count > 0:
        print(f"[清理] 已清理 {killed_count} 个冲突进程，等待资源释放...")
        time.sleep(1.5)  # 等待资源释放
    else:
        print("[清理] 未发现冲突进程")
    
    return killed_count


class VoiceChatState(Enum):
    """语音对话状态"""
    IDLE = "idle"           # 空闲
    LISTENING = "listening" # 倾听中
    THINKING = "thinking"   # 思考中
    SPEAKING = "speaking"   # 说话中


class ScreenDisplay:
    """屏幕显示管理"""
    
    @staticmethod
    def show_state(state: VoiceChatState, extra_text: str = ""):
        """显示当前状态"""
        # 通过函数获取 _xgo_edu（避免导入时的快照问题）
        xgo_edu = get_xgo_edu()
        
        if not HAS_XGO or xgo_edu is None:
            print(f"[屏幕] {state.value} {extra_text}")
            return
        
        try:
            xgo_edu.lcd_clear()  # 清屏
            
            if state == VoiceChatState.LISTENING:
                xgo_edu.lcd_text(10, 50, "倾听中...", "blue", 24)
            elif state == VoiceChatState.THINKING:
                xgo_edu.lcd_text(10, 50, "思考中...", "orange", 24)
            elif state == VoiceChatState.SPEAKING:
                xgo_edu.lcd_text(10, 50, "说话中...", "green", 24)
            elif state == VoiceChatState.IDLE:
                xgo_edu.lcd_text(10, 50, "待命中", "gray", 24)
            
            if extra_text:
                # 显示额外文本（如识别结果）
                xgo_edu.lcd_text(10, 90, extra_text[:20], "white", 16)
        except Exception as e:
            print(f"屏幕显示错误: {e}")


class ASRClient:
    """阿里云 ASR WebSocket 客户端"""
    
    def __init__(self, api_key: str, enable_vad: bool = True, silence_duration_ms: int = 800, vad_threshold: float = 0.5):
        self.api_key = api_key
        self.enable_vad = enable_vad
        self.silence_duration_ms = silence_duration_ms
        self.vad_threshold = vad_threshold
        self.base_url = "wss://dashscope.aliyuncs.com/api-ws/v1/realtime"
        self.model = "qwen3-asr-flash-realtime"
        
        self.ws = None
        self.is_running = False
        self.is_connected = False  # 新增：连接是否真正就绪
        self.is_session_ready = False  # 新增：会话配置是否完成
        self.transcript = ""
        self.on_transcript: Optional[Callable[[str], None]] = None
        self.on_final: Optional[Callable[[str], None]] = None
    
    def _on_open(self, ws):
        """连接建立"""
        print("ASR: WebSocket 连接已建立")
        self.is_connected = True
        
        # 发送会话配置
        session_config = {
            "event_id": f"event_{int(time.time() * 1000)}",
            "type": "session.update",
            "session": {
                "modalities": ["text"],
                "input_audio_format": "pcm",
                "sample_rate": 16000,
                "input_audio_transcription": {"language": "zh"},
                "turn_detection": {
                    "type": "server_vad",
                    "threshold": self.vad_threshold,  # VAD 阈值，越高越不敏感（减少噪音误识别）
                    "silence_duration_ms": self.silence_duration_ms
                } if self.enable_vad else None
            }
        }
        print(f"ASR: 发送配置 VAD={self.enable_vad}, silence_ms={self.silence_duration_ms}")
        ws.send(json.dumps(session_config))
    
    def _on_message(self, ws, message):
        """收到消息"""
        try:
            data = json.loads(message)
            event_type = data.get("type", "")
            
            # 调试日志：打印所有事件类型
            if event_type not in ("conversation.item.input_audio_transcription.delta",):
                print(f"ASR 事件: {event_type}")
            
            if event_type == "session.created":
                print(f"ASR: 会话创建成功, session_id={data.get('session', {}).get('id', 'N/A')}")
            
            elif event_type == "session.updated":
                print("ASR: 会话配置完成，等待语音输入...")
                self.is_session_ready = True
            
            elif event_type == "conversation.item.input_audio_transcription.delta":
                # 增量识别结果
                delta = data.get("delta", "")
                if delta:
                    print(f"ASR 增量: '{delta}'")
                    if self.on_transcript:
                        self.on_transcript(delta)
            
            elif event_type == "conversation.item.input_audio_transcription.completed":
                # 最终识别结果
                self.transcript = data.get("transcript", "")
                print(f"ASR 最终结果: '{self.transcript}' (长度={len(self.transcript)})")
                # VAD 模式下，completed 事件表示说话结束，触发 on_final
                if self.on_final:
                    self.on_final(self.transcript)
                self.is_running = False
            
            elif event_type == "input_audio_buffer.speech_started":
                print("ASR: 🎤 检测到语音开始")
            
            elif event_type == "input_audio_buffer.speech_stopped":
                print("ASR: 🔇 检测到语音结束")
            
            elif event_type == "session.finished":
                # 会话结束
                self.transcript = data.get("transcript", self.transcript)
                print(f"ASR: 会话结束, transcript='{self.transcript}'")
                if self.on_final:
                    self.on_final(self.transcript)
                self.is_running = False
                ws.close()
            
            elif event_type == "error":
                error_info = data.get("error", {})
                print(f"ASR 服务端错误: {error_info}")
                
        except json.JSONDecodeError as e:
            print(f"ASR 消息解析错误: {e}, raw={message[:200]}")
    
    def _on_error(self, ws, error):
        print(f"ASR 错误: {error}")
        self.is_connected = False
        self.is_session_ready = False
    
    def _on_close(self, ws, close_status_code, close_msg):
        print(f"ASR 连接关闭: {close_status_code}")
        self.is_running = False
        self.is_connected = False
        self.is_session_ready = False
    
    def start(self):
        """启动 ASR 连接"""
        url = f"{self.base_url}?model={self.model}"
        headers = [
            f"Authorization: Bearer {self.api_key}",
            "OpenAI-Beta: realtime=v1"
        ]
        
        self.is_running = True
        self.is_connected = False
        self.is_session_ready = False
        self.transcript = ""
        
        self.ws = websocket.WebSocketApp(
            url,
            header=headers,
            on_open=self._on_open,
            on_message=self._on_message,
            on_error=self._on_error,
            on_close=self._on_close
        )
        
        # 在后台线程运行（设为 daemon，程序退出时自动终止）
        self._ws_thread = threading.Thread(target=self.ws.run_forever, daemon=True)
        self._ws_thread.start()
        
        # 等待会话真正就绪（而非简单等待固定时间）
        timeout = 5.0  # 最多等待5秒
        start_time = time.time()
        while not self.is_session_ready and (time.time() - start_time) < timeout:
            if not self.is_running:  # 连接已关闭，无需继续等待
                break
            time.sleep(0.05)
        
        if self.is_session_ready:
            print("ASR: 会话就绪，可以开始发送音频")
        else:
            print(f"ASR: ⚠️ 会话初始化超时 (connected={self.is_connected}, session_ready={self.is_session_ready})")
    
    def send_audio(self, audio_data: bytes):
        """发送音频数据"""
        if not self.is_session_ready:
            # 会话未就绪，跳过发送（避免"socket is already closed"错误）
            return
        
        if self.ws and self.is_running:
            encoded = base64.b64encode(audio_data).decode('utf-8')
            event = {
                "event_id": f"event_{int(time.time() * 1000)}",
                "type": "input_audio_buffer.append",
                "audio": encoded
            }
            try:
                self.ws.send(json.dumps(event))
                # 每发送10次打印一次，避免日志太多
                if not hasattr(self, '_send_count'):
                    self._send_count = 0
                self._send_count += 1
                if self._send_count % 10 == 1:
                    print(f"ASR: 已发送 {self._send_count} 块音频 ({len(audio_data)} bytes/块)")
            except Exception as e:
                print(f"ASR: 发送音频失败: {e}")
                self.is_session_ready = False  # 标记会话不可用
    
    def finish(self):
        """结束识别"""
        if self.ws and self.is_running:
            finish_event = {
                "event_id": f"event_{int(time.time() * 1000)}",
                "type": "session.finish"
            }
            self.ws.send(json.dumps(finish_event))
    
    def wait_for_result(self, timeout: float = 30) -> str:
        """等待最终结果"""
        start_time = time.time()
        while self.is_running and (time.time() - start_time) < timeout:
            time.sleep(0.1)
        return self.transcript


class TTSClient:
    """阿里云 TTS WebSocket 客户端"""
    
    def __init__(self, api_key: str, voice: str = "Cherry"):
        self.api_key = api_key
        self.voice = voice
        self.base_url = "wss://dashscope.aliyuncs.com/api-ws/v1/realtime?model=qwen3-tts-flash-realtime"
        self.ws = None
        self.audio_buffer = bytearray()
        self.is_done = False
        self.session_ready = False
    
    async def connect(self):
        """建立连接"""
        headers = {"Authorization": f"Bearer {self.api_key}"}
        self.ws = await websockets.connect(self.base_url, additional_headers=headers)
        
        # 配置会话
        config = {
            "event_id": f"event_{int(time.time() * 1000)}",
            "type": "session.update",
            "session": {
                "mode": "server_commit",
                "voice": self.voice,
                "language_type": "Auto",
                "response_format": "pcm",
                "sample_rate": 24000
            }
        }
        await self.ws.send(json.dumps(config))
        
        # 等待会话配置完成
        while not self.session_ready:
            try:
                message = await asyncio.wait_for(self.ws.recv(), timeout=5.0)
                data = json.loads(message)
                event_type = data.get("type", "")
                print(f"TTS 事件: {event_type}")
                
                if event_type == "session.created":
                    print(f"TTS 会话创建: {data.get('session', {}).get('id')}")
                elif event_type == "session.updated":
                    print("TTS 会话配置完成")
                    self.session_ready = True
                elif event_type == "error":
                    print(f"TTS 错误: {data.get('error', {})}")
                    break
            except asyncio.TimeoutError:
                print("TTS 等待会话配置超时")
                break
    
    async def synthesize(self, text: str, audio_callback: Optional[Callable[[bytes], None]] = None):
        """合成语音"""
        if not self.session_ready:
            print("TTS 会话未就绪")
            return bytes()
        
        # 过滤 emoji（TTS 不支持）
        import re
        text = re.sub(r'[\U0001F300-\U0001F9FF]', '', text)
        
        self.is_done = False
        self.audio_buffer = bytearray()
        
        # 发送文本（server_commit 模式下，服务端会自动按句切分并触发合成）
        event = {
            "event_id": f"event_{int(time.time() * 1000)}",
            "type": "input_text_buffer.append",
            "text": text
        }
        await self.ws.send(json.dumps(event))
        print(f"TTS 发送文本: {text[:50]}...")

        # 文本已全部发送，通知服务端结束会话（不是触发合成；合成由 append 自动触发）
        finish_event = {
            "event_id": f"event_{int(time.time() * 1000)}",
            "type": "session.finish"
        }
        await self.ws.send(json.dumps(finish_event))
        print("TTS 发送 session.finish（结束会话）")
        
        # 处理响应
        try:
            async for message in self.ws:
                data = json.loads(message)
                event_type = data.get("type", "")
                
                if event_type == "response.audio.delta":
                    # 音频增量
                    audio_bytes = base64.b64decode(data.get("delta", ""))
                    self.audio_buffer.extend(audio_bytes)
                    if audio_callback:
                        audio_callback(audio_bytes)
                
                elif event_type == "response.done":
                    print("TTS 响应完成")
                    self.is_done = True
                    break
                
                elif event_type == "session.finished":
                    print("TTS 会话结束")
                    break
                
                elif event_type == "error":
                    print(f"TTS 错误: {data.get('error', {})}")
                    break
                    
        except websockets.exceptions.ConnectionClosed:
            print("TTS 连接关闭")
        except Exception as e:
            print(f"TTS 异常: {e}")
        
        return bytes(self.audio_buffer)
    
    async def close(self):
        """关闭连接"""
        if self.ws:
            await self.ws.close()


class StreamingTTSPlayer:
    """流式 TTS 播放器 - 单一长连接

    采用阿里云 server_commit 模式的标准用法：
        1. 整次对话只建立一个 WebSocket 连接
        2. 后台 _recv_loop 持续接收音频增量并实时写入扬声器
        3. 调用方通过 append_text 持续追加文本片段（服务端自动切句合成）
        4. 全部文本发送完毕后调用 finish 发送 session.finish 并等待结束
    """

    def __init__(self, api_key: str, voice: str = "Cherry"):
        self.api_key = api_key
        self.voice = voice
        self.base_url = "wss://dashscope.aliyuncs.com/api-ws/v1/realtime?model=qwen3-tts-flash-realtime"
        self.ws = None
        self.audio_stream = None
        self.pyaudio_instance = None
        self.sample_rate = 24000

        self._session_ready = False
        self._closed = False
        self._first_audio_event = asyncio.Event()
        self._session_finished_event = asyncio.Event()
        self._recv_task: Optional[asyncio.Task] = None
        self._error: Optional[str] = None

    async def connect(self):
        """建立连接、配置会话并启动后台接收循环"""
        import pyaudio

        # 初始化 pyaudio 输出流
        self.pyaudio_instance = pyaudio.PyAudio()
        self.audio_stream = self.pyaudio_instance.open(
            format=pyaudio.paInt16,
            channels=1,
            rate=self.sample_rate,
            output=True,
            frames_per_buffer=1024
        )

        # 建立 WebSocket 连接
        headers = {"Authorization": f"Bearer {self.api_key}"}
        self.ws = await websockets.connect(self.base_url, additional_headers=headers)

        # 配置会话（server_commit 模式：服务端自动按句切分并触发合成）
        config = {
            "event_id": f"event_{int(time.time() * 1000)}",
            "type": "session.update",
            "session": {
                "mode": "server_commit",
                "voice": self.voice,
                "language_type": "Auto",
                "response_format": "pcm",
                "sample_rate": self.sample_rate
            }
        }
        await self.ws.send(json.dumps(config))

        # 启动后台接收循环
        self._recv_task = asyncio.create_task(self._recv_loop())

        # 等待 session.updated（最多 5s）
        wait_start = time.time()
        while not self._session_ready and (time.time() - wait_start) < 5.0:
            if self._error or self._closed:
                break
            await asyncio.sleep(0.05)

        if not self._session_ready:
            raise RuntimeError(f"TTS 会话初始化失败: {self._error or '超时'}")

        print("流式 TTS 会话就绪（长连接模式）")

    async def _recv_loop(self):
        """后台接收循环：实时写入音频流，监听结束/错误事件"""
        try:
            async for message in self.ws:
                data = json.loads(message)
                event_type = data.get("type", "")

                if event_type == "session.updated":
                    self._session_ready = True

                elif event_type == "response.audio.delta":
                    audio_bytes = base64.b64decode(data.get("delta", ""))
                    if self.audio_stream and audio_bytes:
                        try:
                            self.audio_stream.write(audio_bytes)
                        except Exception as e:
                            print(f"TTS 音频写入错误: {e}")
                    if not self._first_audio_event.is_set():
                        self._first_audio_event.set()

                elif event_type == "session.finished":
                    print("TTS session.finished")
                    self._session_finished_event.set()
                    break

                elif event_type == "error":
                    err = data.get("error", {})
                    print(f"流式 TTS 错误事件: {err}")
                    self._error = str(err)

        except websockets.exceptions.ConnectionClosed:
            pass
        except Exception as e:
            print(f"TTS 接收循环异常: {e}")
            self._error = str(e)
        finally:
            # 无论如何解锁等待者，避免上层死等
            self._first_audio_event.set()
            self._session_finished_event.set()

    async def append_text(self, text: str):
        """向同一连接持续追加文本（服务端自动切句合成）"""
        if not self.ws or not self._session_ready or self._closed:
            return
        # 过滤 emoji（TTS 不支持）
        import re
        text = re.sub(r'[\U0001F300-\U0001F9FF]', '', text)
        if not text.strip():
            return
        event = {
            "event_id": f"event_{int(time.time() * 1000)}",
            "type": "input_text_buffer.append",
            "text": text
        }
        try:
            await self.ws.send(json.dumps(event))
        except Exception as e:
            print(f"TTS append_text 失败: {e}")
            self._error = str(e)

    async def wait_first_audio(self, timeout: float = 30.0):
        """等待首段音频到达（用于切换屏幕状态）"""
        try:
            await asyncio.wait_for(self._first_audio_event.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            pass

    async def finish(self, timeout: float = 60.0):
        """通知服务端文本已发送完毕，等待全部音频播放完成"""
        if self.ws and not self._closed:
            try:
                event = {
                    "event_id": f"event_{int(time.time() * 1000)}",
                    "type": "session.finish"
                }
                await self.ws.send(json.dumps(event))
            except Exception as e:
                print(f"TTS finish 发送失败: {e}")
        try:
            await asyncio.wait_for(self._session_finished_event.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            print("TTS 等待 session.finished 超时")

    async def close(self):
        """关闭连接和音频流"""
        self._closed = True

        # 取消后台接收任务
        if self._recv_task and not self._recv_task.done():
            self._recv_task.cancel()
            try:
                await self._recv_task
            except (asyncio.CancelledError, Exception):
                pass

        try:
            if self.ws:
                await self.ws.close()
        except:
            pass

        try:
            if self.audio_stream:
                self.audio_stream.stop_stream()
                self.audio_stream.close()
        except:
            pass

        try:
            if self.pyaudio_instance:
                self.pyaudio_instance.terminate()
        except:
            pass


class LLMClient:
    """LLM 客户端（支持流式 + Function Call + 多轮记忆）"""
    
    # 全局会话实例（用于多轮记忆）
    _global_instance: Optional['LLMClient'] = None
    _max_rounds: int = 10  # 最多保留 10 轮对话
    
    @classmethod
    def get_or_create(cls, api_key: str, model_id: str = "qwen-plus") -> 'LLMClient':
        """获取或创建全局实例（用于多轮记忆）"""
        if cls._global_instance is None or cls._global_instance.model_id != model_id:
            cls._global_instance = cls(api_key, model_id)
        return cls._global_instance
    
    @classmethod
    def clear_history(cls):
        """清除会话历史"""
        if cls._global_instance:
            cls._global_instance.messages = []
    
    def __init__(self, api_key: str, model_id: str = "qwen-plus"):
        self.api_key = api_key
        self.client = OpenAI(
            api_key=api_key,
            base_url="https://dashscope.aliyuncs.com/compatible-mode/v1"
        )
        self.model_id = model_id
        self.messages: List[Dict] = []
        
        # 使用统一的工具执行器（自动包含通用 + 机型特有工具）
        self._tool_executor = ToolExecutor(api_key)
        self.tools = self._tool_executor.get_tools()
    
    # TTS 输出限制（自动追加，防止用户覆盖）
    _TTS_CONSTRAINT = "回复中不要使用*、表情符号、特殊符号，只用纯文本。"
    
    def set_system_prompt(self, prompt: str):
        """设置系统提示词（保留历史，限制轮数，自动追加 TTS 限制）"""
        # 找到现有的非 system 消息
        history = [m for m in self.messages if m.get("role") != "system"]
        
        # 限制最多 10 轮（20 条消息：10 个 user + 10 个 assistant）
        max_messages = self._max_rounds * 2
        if len(history) > max_messages:
            history = history[-max_messages:]
        
        # 修复：截断后可能导致 tool 消息与 tool_calls 配对断裂
        # 如果历史开头是孤立的 tool 消息，需要删除它们
        while history and history[0].get("role") == "tool":
            history.pop(0)
        
        # 自动追加 TTS 限制（避免特殊符号导致 TTS 问题）
        full_prompt = f"{prompt} {self._TTS_CONSTRAINT}"
        
        # 重建消息列表：system + 历史
        self.messages = [{"role": "system", "content": full_prompt}] + history
    
    def chat_stream(self, user_input: str, tools_enabled: bool = True, 
                   on_token: Optional[Callable[[str], None]] = None) -> str:
        """流式对话（支持多轮 Function Call）"""
        self.messages.append({"role": "user", "content": user_input})
        
        # 最多循环 10 轮工具调用，防止无限循环
        max_tool_rounds = 10
        
        for round_num in range(max_tool_rounds):
            # 构建 LLM 调用参数
            kwargs = {
                "model": self.model_id,
                "messages": self.messages,
                "stream": True,
                "extra_body": {
                    "enable_search": True,      # 启用联网搜索
                    "enable_thinking": False    # 关闭思考模式
                }
            }
            if tools_enabled and self.tools:
                kwargs["tools"] = self.tools
            
            response = self.client.chat.completions.create(**kwargs)
            
            # 收集响应
            full_content = ""
            tool_calls = []
            current_tool_call = None
            assistant_message = {"role": "assistant", "content": ""}
            
            for chunk in response:
                if chunk.choices:
                    delta = chunk.choices[0].delta
                    
                    # 处理文本内容
                    if delta.content:
                        full_content += delta.content
                        if on_token:
                            on_token(delta.content)
                    
                    # 处理工具调用
                    if delta.tool_calls:
                        for tc in delta.tool_calls:
                            if tc.index is not None:
                                while len(tool_calls) <= tc.index:
                                    tool_calls.append({"name": "", "arguments": "", "id": ""})
                                if tc.function.name:
                                    tool_calls[tc.index]["name"] = tc.function.name
                                if tc.function.arguments:
                                    tool_calls[tc.index]["arguments"] += tc.function.arguments
                                if tc.id:
                                    tool_calls[tc.index]["id"] = tc.id
            
            # 检查是否有工具调用
            if not tool_calls:
                # 没有工具调用，正常结束
                break
            
            # 有工具调用：先保存助手的 tool_calls 消息
            if tool_calls:
                assistant_message["content"] = full_content
                assistant_message["tool_calls"] = [
                    {
                        "id": tc["id"],
                        "type": "function",
                        "function": {
                            "name": tc["name"],
                            "arguments": tc["arguments"]
                        }
                    }
                    for tc in tool_calls
                ]
                self.messages.append(assistant_message)
            
            # 执行所有工具调用
            for tc in tool_calls:
                if tc["name"]:
                    print(f"执行工具: {tc['name']}")
                    args = json.loads(tc["arguments"]) if tc["arguments"] else {}
                    result = self._tool_executor.execute(tc["name"], args)
                    
                    # 将工具结果作为独立消息添加
                    tool_message = {
                        "role": "tool",
                        "tool_call_id": tc["id"],
                        "content": result
                    }
                    self.messages.append(tool_message)
                    
                    # 追加结果到 full_content 用于最终返回
                    full_content += f"\n{result}"
            
            print(f"工具执行完成，进行第 {round_num + 2} 轮 LLM 调用...")
        
        # 记录助手最终回复（不含工具调用部分的内容）
        self.messages.append({"role": "assistant", "content": full_content})
        
        return full_content


def record_and_asr_realtime(api_key: str, max_duration: float = 30, silence_duration_ms: int = 800, vad_threshold: float = 0.5) -> str:
    """
    实时录音 + ASR（边录边识别，VAD 自动检测结束）
    
    Args:
        api_key: API 密钥
        max_duration: 最大录音时长（秒），防止无限录音
        silence_duration_ms: VAD 静音检测阈值（毫秒）
        vad_threshold: VAD 灵敏度阈值（0-1），越小越敏感
    
    Returns:
        识别出的文本
    """
    import pyaudio
    
    CHUNK = 3200  # 0.1s 的音频数据 (16000 * 0.1 * 2 bytes)
    FORMAT = pyaudio.paInt16
    CHANNELS = 1
    RATE = 16000
    
    print(f"ASR: 初始化录音参数 CHUNK={CHUNK}, RATE={RATE}, max_duration={max_duration}s")
    
    # 创建 ASR 客户端
    asr = ASRClient(api_key, enable_vad=True, silence_duration_ms=silence_duration_ms, vad_threshold=vad_threshold)
    
    # 录音完成标志
    recording_done = threading.Event()
    final_result = {"text": ""}
    
    def on_final(text):
        print(f"ASR: on_final 回调触发, text='{text}'")
        final_result["text"] = text
        recording_done.set()
    
    asr.on_final = on_final
    
    # 启动 ASR
    print("ASR: 启动 WebSocket 连接...")
    asr.start()
    # start() 内部已等待会话就绪，无需额外等待
    print(f"ASR: 连接状态 is_running={asr.is_running}, session_ready={asr.is_session_ready}")
    
    # 开始录音
    p = pyaudio.PyAudio()
    
    # 打印音频设备信息
    try:
        default_input = p.get_default_input_device_info()
        print(f"ASR: 默认输入设备: {default_input.get('name', 'Unknown')}, index={default_input.get('index')}")
    except Exception as e:
        print(f"ASR: 获取默认输入设备失败: {e}")
    
    stream = p.open(format=FORMAT, channels=CHANNELS,
                   rate=RATE, input=True,
                   frames_per_buffer=CHUNK)
    
    print("🎤 开始录音（说完会自动停止）...")
    
    # 检查会话是否就绪
    if not asr.is_session_ready:
        print("ASR: ⚠️ 会话未就绪，无法录音")
        stream.stop_stream()
        stream.close()
        p.terminate()
        return ""
    
    start_time = time.time()
    chunk_count = 0
    try:
        while asr.is_running and asr.is_session_ready and (time.time() - start_time) < max_duration:
            try:
                data = stream.read(CHUNK, exception_on_overflow=False)
                chunk_count += 1
                asr.send_audio(data)
                
                # 检查音频数据是否有效（非静音）
                if chunk_count == 1:
                    # 计算第一块音频的音量
                    import struct
                    samples = struct.unpack(f'{len(data)//2}h', data)
                    max_amplitude = max(abs(s) for s in samples)
                    print(f"ASR: 首块音频 max_amplitude={max_amplitude} (静音阈值约<500)")
                    
            except Exception as e:
                print(f"录音读取错误: {e}")
                break
            
            # 检查是否已完成
            if recording_done.is_set():
                print(f"ASR: recording_done 被设置，退出录音循环")
                break
    finally:
        elapsed = time.time() - start_time
        print(f"ASR: 录音循环结束, 共 {chunk_count} 块, 耗时 {elapsed:.1f}s, is_running={asr.is_running}")
        stream.stop_stream()
        stream.close()
        p.terminate()
    
    # 如果 VAD 没有自动结束，手动结束
    if not recording_done.is_set():
        print("ASR: VAD 未自动结束，手动调用 finish()")
        asr.finish()
        recording_done.wait(timeout=5)
        if not recording_done.is_set():
            print("ASR: ⚠️ 等待 on_final 超时!")
    
    duration = time.time() - start_time
    print(f"录音结束，时长: {duration:.1f}秒, 最终结果: '{final_result['text']}'")
    
    return final_result["text"]


def play_audio(audio_data: bytes, sample_rate: int = 24000):
    """播放音频（跨平台支持）"""
    import platform
    import tempfile
    import subprocess
    import struct
    import wave
    
    if not audio_data:
        print("播放: 没有音频数据")
        return
    
    system = platform.system()
    print(f"播放: 平台={system}, 音频大小={len(audio_data)} bytes")
    
    try:
        if system == "Darwin":  # macOS
            # 转换 PCM 为 WAV（afplay 需要 WAV 格式）
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as f:
                temp_path = f.name
                with wave.open(f, 'wb') as wav:
                    wav.setnchannels(1)
                    wav.setsampwidth(2)  # 16-bit
                    wav.setframerate(sample_rate)
                    wav.writeframes(audio_data)
            
            print(f"播放: 使用 afplay 播放 {temp_path}")
            # 使用 afplay 播放
            subprocess.run(['afplay', temp_path], check=True)
            os.unlink(temp_path)
            print("播放: 完成")
            
        else:  # Linux / 树莓派
            with tempfile.NamedTemporaryFile(suffix='.pcm', delete=False) as f:
                f.write(audio_data)
                temp_path = f.name
            
            print(f"播放: 使用 mplayer 播放 {temp_path}")
            # 使用 mplayer 播放
            os.system(f"mplayer -really-quiet -af resample={sample_rate} -rawaudio channels=1:rate={sample_rate}:samplesize=2 {temp_path} 2>/dev/null")
            os.unlink(temp_path)
            print("播放: 完成")
            
    except Exception as e:
        print(f"播放错误: {e}")


async def voice_chat_async(
    api_key: str,
    system_prompt: str = "你是XGO机器人助手，可以控制机器人运动和执行动作。回答要简洁。",
    voice: str = "Cherry",
    model_id: str = "qwen-plus",
    tools_enabled: bool = True,
    listen_duration: float = 30,
    vad_threshold: float = 0.5
) -> Dict[str, str]:
    """
    异步语音对话（单轮）
    
    Args:
        listen_duration: 最大录音时长（秒），VAD 会自动检测说话结束
        vad_threshold: VAD 灵敏度阈值（0-1），越小越敏感，默认 0.5
    
    Returns:
        {"user": 用户说的话, "reply": AI回复}
    """
    result = {"user": "", "reply": ""}
    
    # 0. 清理可能冲突的进程（卡住的进程等）
    cleanup_conflicting_processes()
    
    # 耗时统计
    t_start = time.time()
    print(f"\n{'='*50}")
    print(f"🎯 语音对话开始")
    print(f"{'='*50}")
    
    # 1. 显示倾听状态
    ScreenDisplay.show_state(VoiceChatState.LISTENING)
    
    # 2. 实时录音 + ASR（VAD 自动检测结束）
    t_asr_start = time.time()
    print(f"\n⏱️  [{t_asr_start - t_start:.2f}s] ASR 开始录音...")
    user_text = record_and_asr_realtime(api_key, max_duration=listen_duration, vad_threshold=vad_threshold)
    t_asr_end = time.time()
    print(f"✅ [{t_asr_end - t_start:.2f}s] ASR 完成，耗时: {t_asr_end - t_asr_start:.2f}s")
    result["user"] = user_text
    
    if not user_text:
        result["reply"] = "没有听清，请再说一次"
        ScreenDisplay.show_state(VoiceChatState.IDLE)
        return result
    
    print(f"🗣️  用户: {user_text}")
    ScreenDisplay.show_state(VoiceChatState.LISTENING, user_text[:20])
    
    # 3. 显示思考状态
    ScreenDisplay.show_state(VoiceChatState.THINKING)
    
    # 4. LLM + TTS 并发流式管道（边生成边播放）
    llm = LLMClient.get_or_create(api_key, model_id)
    llm.set_system_prompt(system_prompt)
    
    # 句子队列（用于 LLM 和 TTS 之间通信）
    sentence_queue = asyncio.Queue()
    sentence_buffer = ""
    full_reply = ""
    sentence_delimiters = set("。！？.!?~～，,\n")  # 包含逗号、换行，更快响应
    tts_failed = False
    
    # 耗时统计变量
    t_llm_start = time.time()
    t_first_token = None
    t_first_sentence = None
    sentence_count = 0
    
    # 获取事件循环（用于跨线程通信）
    loop = asyncio.get_running_loop()
    
    def on_token(token: str):
        """LLM token 回调（在 executor 线程中运行）"""
        nonlocal sentence_buffer, full_reply, t_first_token, t_first_sentence, sentence_count
        
        # 记录首个 token 时间
        if t_first_token is None:
            t_first_token = time.time()
            print(f"\n⏱️  [{t_first_token - t_start:.2f}s] LLM 首个 token，等待: {t_first_token - t_llm_start:.2f}s")
        
        sentence_buffer += token
        full_reply += token
        
        # 检查是否有完整句子（可能一次产出多句）
        while True:
            found = False
            for i, char in enumerate(sentence_buffer):
                if char in sentence_delimiters:
                    sentence = sentence_buffer[:i+1].strip()
                    sentence_buffer = sentence_buffer[i+1:]
                    if sentence:
                        sentence_count += 1
                        # 记录首句时间
                        if t_first_sentence is None:
                            t_first_sentence = time.time()
                            print(f"📝 [{t_first_sentence - t_start:.2f}s] LLM 首句完成: \"{sentence[:20]}...\"")
                        # 跨线程放入队列
                        loop.call_soon_threadsafe(sentence_queue.put_nowait, sentence)
                    found = True
                    break
            if not found:
                break
    
    async def llm_task():
        """LLM 生成任务（在线程池中运行同步代码）"""
        nonlocal sentence_buffer
        
        print(f"\n⏱️  [{time.time() - t_start:.2f}s] LLM 开始请求...")
        
        await loop.run_in_executor(
            None, 
            lambda: llm.chat_stream(user_text, tools_enabled=tools_enabled, on_token=on_token)
        )
        
        t_llm_end = time.time()
        print(f"✅ [{t_llm_end - t_start:.2f}s] LLM 完成，总耗时: {t_llm_end - t_llm_start:.2f}s，共 {sentence_count} 句")
        
        # 处理剩余文本
        if sentence_buffer.strip():
            await sentence_queue.put(sentence_buffer.strip())
        
        # 放入结束标记
        await sentence_queue.put(None)
    
    async def tts_task():
        """TTS 播放任务（长连接 + 持续追加文本，服务端自动切句合成）"""
        nonlocal tts_failed
        tts_player = None
        appended_count = 0
        watch_task = None
        t_tts_start = time.time()

        try:
            print(f"⏱️  [{time.time() - t_start:.2f}s] TTS 连接中...")
            tts_player = StreamingTTSPlayer(api_key, voice)
            await tts_player.connect()
            print(f"✅ [{time.time() - t_start:.2f}s] TTS 连接就绪，耗时: {time.time() - t_tts_start:.2f}s")

            # 后台任务：首段音频到达时切换屏幕到"说话中"
            async def watch_first_audio():
                await tts_player.wait_first_audio()
                if not tts_failed:
                    ScreenDisplay.show_state(VoiceChatState.SPEAKING)
                    print(f"\n🔊 [{time.time() - t_start:.2f}s] TTS 开始播放首段音频")

            watch_task = asyncio.create_task(watch_first_audio())

            # 持续从队列取句子，向同一连接追加文本
            while True:
                t_wait_start = time.time()
                sentence = await sentence_queue.get()
                t_wait_end = time.time()

                if sentence is None:
                    break

                appended_count += 1
                t_append_start = time.time()
                await tts_player.append_text(sentence)
                t_append_end = time.time()
                print(f"   📝 第{appended_count}段 追加耗时: {t_append_end - t_append_start:.3f}s | 等待: {t_wait_end - t_wait_start:.2f}s | \"{sentence[:15]}...\"")

            # LLM 已结束 → 通知服务端文本结束，并等待全部音频播放完毕
            print(f"⏱️  [{time.time() - t_start:.2f}s] TTS 文本发送完毕，等待播放完成...")
            await tts_player.finish()

        except Exception as e:
            print(f"❌ 流式 TTS 错误: {e}")
            tts_failed = True
            # 清空队列，让 LLM 任务能正常结束
            while True:
                try:
                    item = sentence_queue.get_nowait()
                    if item is None:
                        break
                except asyncio.QueueEmpty:
                    break
        finally:
            if watch_task and not watch_task.done():
                watch_task.cancel()
            if tts_player:
                await tts_player.close()
            t_tts_end = time.time()
            print(f"✅ [{t_tts_end - t_start:.2f}s] TTS 完成，共追加 {appended_count} 段文本，总耗时: {t_tts_end - t_tts_start:.2f}s")
    
    # 5. 并发执行 LLM 生成和 TTS 播放
    try:
        await asyncio.gather(llm_task(), tts_task())
    except Exception as e:
        print(f"❌ 流式管道错误: {e}")
    
    # 如果流式 TTS 失败，回退到批量模式
    if tts_failed and full_reply:
        print(f"\n⚠️  回退到批量 TTS 模式")
        ScreenDisplay.show_state(VoiceChatState.SPEAKING)
        try:
            tts = TTSClient(api_key, voice)
            await tts.connect()
            audio = await tts.synthesize(full_reply)
            await tts.close()
            if audio:
                play_audio(audio)
        except Exception as e:
            print(f"❌ 批量 TTS 也失败: {e}")
    
    result["reply"] = full_reply
    
    # 总耗时统计
    t_end = time.time()
    print(f"\n{'='*50}")
    print(f"🏁 语音对话完成，总耗时: {t_end - t_start:.2f}s")
    print(f"   ASR: {t_asr_end - t_asr_start:.2f}s | LLM首token: {(t_first_token - t_llm_start):.2f}s" if t_first_token else "")
    print(f"   AI: {full_reply[:50]}..." if len(full_reply) > 50 else f"   AI: {full_reply}")
    print(f"{'='*50}\n")
    
    # 6. 恢复空闲状态
    ScreenDisplay.show_state(VoiceChatState.IDLE)
    
    return result


def voice_chat(
    api_key: str,
    system_prompt: str = "你是XGO机器人助手，可以控制机器人运动和执行动作。回答要简洁。",
    voice: str = "Cherry",
    model_id: str = "qwen-plus",
    tools_enabled: bool = True,
    listen_duration: float = 30,
    vad_threshold: float = 0.5
) -> Dict[str, str]:
    """
    语音对话（同步接口）
    
    Args:
        api_key: 阿里云 API 密钥
        system_prompt: 系统提示词
        voice: TTS 音色 (Cherry/Serena/Ethan/Chelsie)
        model_id: LLM 模型 ID
        tools_enabled: 是否启用工具调用
        listen_duration: 最大录音时长（秒），VAD 会自动检测说话结束
        vad_threshold: VAD 灵敏度阈值（0-1），越小越敏感，默认 0.5
    
    Returns:
        {"user": 用户说的话, "reply": AI回复}
    """
    return asyncio.run(voice_chat_async(
        api_key=api_key,
        system_prompt=system_prompt,
        voice=voice,
        model_id=model_id,
        tools_enabled=tools_enabled,
        listen_duration=listen_duration,
        vad_threshold=vad_threshold
    ))


# 测试
if __name__ == "__main__":
    api_key = os.environ.get("DASHSCOPE_API_KEY", "")
    if api_key:
        result = voice_chat(api_key)
        print(f"\n对话结果: {result}")
    else:
        print("请设置 DASHSCOPE_API_KEY 环境变量")
