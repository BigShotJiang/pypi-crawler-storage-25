#!/usr/bin/env python3
"""
REPL Worker - 持久化 Python REPL 子进程脚本

被后端作为子进程启动，通过 stdin/stdout 以 JSON Lines 协议通信。
所有 exec() 在同一个 namespace 中执行，变量跨执行保留。
"""

import sys
import json
import signal
import traceback
import atexit

# 保护原始 stdout/stderr，所有协议输出走这里
_original_stdout = sys.stdout
_original_stderr = sys.stderr


def _send(data):
    """将 dict 序列化为 JSON 并写一行到 _original_stdout，立即 flush。"""
    line = json.dumps(data, ensure_ascii=False)
    _original_stdout.write(line + "\n")
    _original_stdout.flush()


class JsonLineWriter:
    """替换 sys.stdout/sys.stderr 的写入器，将输出实时转为 JSON 格式。"""

    def __init__(self):
        pass

    def write(self, text):
        if text:
            _send({"type": "output", "text": text})

    def flush(self):
        pass

    def isatty(self):
        return False


def _sigint_handler(signum, frame):
    """SIGINT 信号处理：中断当前执行但不退出进程。"""
    raise KeyboardInterrupt


def _execute(code, namespace):
    """执行用户代码，捕获输出和异常。"""
    _send({"type": "started"})

    # 替换 stdout/stderr
    writer = JsonLineWriter()
    sys.stdout = writer
    sys.stderr = writer

    try:
        exec(code, namespace)
        # 恢复 stdout/stderr
        sys.stdout = _original_stdout
        sys.stderr = _original_stderr
        _send({"type": "complete", "success": True})
    except KeyboardInterrupt:
        sys.stdout = _original_stdout
        sys.stderr = _original_stderr
        _send({"type": "complete", "success": True, "interrupted": True})
    except Exception:
        sys.stdout = _original_stdout
        sys.stderr = _original_stderr
        tb = traceback.format_exc()
        # 错误信息（最后一行，去掉末尾换行）
        error_msg = tb.strip().split("\n")[-1]
        _send({"type": "error", "text": tb})
        _send({"type": "complete", "success": False, "error": error_msg})


def _reset(namespace):
    """清空命名空间。"""
    namespace.clear()
    _send({"type": "reset_complete"})


def _cleanup_resources():
    """进程退出时清理 XGOEDU 硬件资源（摄像头、GPIO 等）"""
    try:
        # 尝试从已执行的命名空间中找到 XGOEDU 实例并清理
        from edulib import XGOEDU
        if XGOEDU._instance is not None:
            XGOEDU._instance.cleanup()
    except Exception:
        pass


def main():
    # 注册退出清理钩子
    atexit.register(_cleanup_resources)

    # 注册 SIGINT 处理
    signal.signal(signal.SIGINT, _sigint_handler)

    namespace = {}

    # 主循环：从 stdin 逐行读取 JSON 命令
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue

        try:
            cmd = json.loads(line)
        except json.JSONDecodeError:
            _send({"type": "error", "text": f"Invalid JSON: {line}\n"})
            continue

        action = cmd.get("action")

        if action == "execute":
            code = cmd.get("code", "")
            _execute(code, namespace)
        elif action == "reset":
            _reset(namespace)
        else:
            _send({"type": "error", "text": f"Unknown action: {action}\n"})


if __name__ == "__main__":
    main()
