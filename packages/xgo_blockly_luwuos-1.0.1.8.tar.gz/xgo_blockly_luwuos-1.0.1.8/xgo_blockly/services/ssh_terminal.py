#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
终端 WebSocket 服务
使用 pty + websockets 实现本机 bash shell 的双向通信

多会话独立模式：每个 WebSocket 连接各开一个独立 PTY，断开时只清理自己的 session。
"""

import os
import pty
import subprocess
import asyncio
import websockets
import struct
import fcntl
import termios
import json
import signal
import logging
import threading

logger = logging.getLogger(__name__)

WS_PORT = 9010

# 全局多会话管理
_sessions = {}            # {session_id: TerminalSession}
_sessions_lock = threading.Lock()
MAX_SESSIONS = 5          # 最大并发终端数


class TerminalSession:
    """管理一个 PTY shell 会话"""

    def __init__(self):
        self.process = None
        self.fd = None
        self.closed = False

    def start(self):
        """启动 PTY shell"""
        master_fd, slave_fd = pty.openpty()
        self.process = subprocess.Popen(
            ['bash'],
            stdin=slave_fd,
            stdout=slave_fd,
            stderr=slave_fd,
            preexec_fn=os.setsid,
            env={**os.environ, 'TERM': 'xterm-256color'}
        )
        os.close(slave_fd)
        self.fd = master_fd
        logger.info(f"PTY shell started, PID: {self.process.pid}, FD: {self.fd}")

    def resize(self, rows, cols):
        """调整终端大小"""
        if self.fd is not None and not self.closed:
            try:
                winsize = struct.pack('HHHH', rows, cols, 0, 0)
                fcntl.ioctl(self.fd, termios.TIOCSWINSZ, winsize)
            except OSError as e:
                logger.warning(f"Failed to resize terminal: {e}")

    def stop(self):
        """停止 shell 并清理资源，可安全重复调用"""
        if self.closed:
            return
        self.closed = True

        pid_info = self.process.pid if self.process else 'N/A'
        fd_info = self.fd

        # 关闭进程：先 SIGTERM，等待后 SIGKILL
        if self.process and self.process.poll() is None:
            try:
                os.killpg(os.getpgid(self.process.pid), signal.SIGTERM)
            except (OSError, ProcessLookupError):
                pass
            try:
                self.process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                logger.warning(f"Process {pid_info} did not exit after SIGTERM, sending SIGKILL")
                try:
                    os.killpg(os.getpgid(self.process.pid), signal.SIGKILL)
                except (OSError, ProcessLookupError):
                    pass
                try:
                    self.process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    logger.error(f"Process {pid_info} still alive after SIGKILL")
            except Exception:
                pass

        self.process = None

        # 关闭 fd
        if self.fd is not None:
            try:
                os.close(self.fd)
            except OSError:
                pass
            self.fd = None

        logger.info(f"Terminal session stopped, PID was: {pid_info}, FD was: {fd_info}")


async def terminal_handler(websocket, path=None):
    """WebSocket 连接处理函数（多会话独立模式）"""
    session_id = id(websocket)

    # 检查并发数限制
    with _sessions_lock:
        if len(_sessions) >= MAX_SESSIONS:
            # 清理可能已死的旧 session
            dead_ids = [sid for sid, s in _sessions.items() if s.closed]
            for sid in dead_ids:
                del _sessions[sid]
            # 再次检查
            if len(_sessions) >= MAX_SESSIONS:
                await websocket.send(json.dumps({
                    'type': 'output',
                    'data': 'Error: Too many terminal sessions (max 5)\r\n'
                }))
                await websocket.close()
                return

        session = TerminalSession()
        _sessions[session_id] = session

    session.start()
    logger.info(f"New terminal session {session_id}, PID: {session.process.pid}, active: {len(_sessions)}")

    async def read_pty():
        """持续读取 PTY 输出并发送给前端，事件驱动零延迟"""
        loop = asyncio.get_event_loop()
        queue = asyncio.Queue()

        def on_readable():
            try:
                data = os.read(session.fd, 4096)
                if data:
                    queue.put_nowait(data)
                else:
                    queue.put_nowait(None)  # EOF
            except (OSError, ValueError):
                queue.put_nowait(None)

        loop.add_reader(session.fd, on_readable)
        try:
            while not session.closed:
                try:
                    data = await asyncio.wait_for(queue.get(), timeout=5.0)
                    if data is None:
                        break
                    await websocket.send(json.dumps({
                        'type': 'output',
                        'data': data.decode('utf-8', errors='replace')
                    }))
                except asyncio.TimeoutError:
                    continue
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    if not session.closed:
                        logger.error(f"PTY read unexpected error: {e}")
                    break
        finally:
            try:
                loop.remove_reader(session.fd)
            except Exception:
                pass

    read_task = asyncio.ensure_future(read_pty())

    try:
        async for message in websocket:
            if session.closed:
                break
            try:
                msg = json.loads(message)
                msg_type = msg.get('type')
                if msg_type == 'input':
                    os.write(session.fd, msg['data'].encode('utf-8'))
                elif msg_type == 'resize':
                    session.resize(msg.get('rows', 24), msg.get('cols', 80))
            except (json.JSONDecodeError, KeyError, OSError) as e:
                logger.error(f"Error processing message: {e}")
    except websockets.exceptions.ConnectionClosed:
        logger.info("WebSocket connection closed")
    finally:
        read_task.cancel()
        try:
            await read_task
        except (asyncio.CancelledError, Exception):
            pass
        session.stop()
        with _sessions_lock:
            _sessions.pop(session_id, None)
        logger.info(f"Terminal session {session_id} cleaned up, active: {len(_sessions)}")


async def start_terminal_server():
    """启动终端 WebSocket 服务"""
    server = await websockets.serve(terminal_handler, '0.0.0.0', WS_PORT)
    logger.info(f"Terminal WebSocket server started on port {WS_PORT}")
    return server


def run_terminal_server_in_thread():
    """在独立线程中运行 WebSocket 服务"""

    def _run():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(start_terminal_server())
        loop.run_forever()

    thread = threading.Thread(target=_run, daemon=True)
    thread.start()
    logger.info("Terminal server thread started")
