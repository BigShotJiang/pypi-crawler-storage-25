#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
摄像头标定模块
提供 CM5 摄像头（320x240）的内参标定功能，包括：
- 默认预估标定参数
- 棋盘格标定执行
- 参数持久化（JSON）
- 统一加载接口
"""

import os
import json
import logging
import numpy as np
import cv2

logger = logging.getLogger(__name__)

# 标定文件存储路径
CALIBRATION_DIR = os.path.expanduser("~/.xgo_blockly")
CALIBRATION_FILE = os.path.join(CALIBRATION_DIR, "camera_calibration.json")

# 棋盘格参数
CHESSBOARD_SIZE = (9, 6)  # 内角点数量（列, 行）


def get_default_params():
    """
    返回 CM5 摄像头 320x240 分辨率下的默认内参矩阵和畸变系数。
    由 640x480 标定数据（rms_error=0.336）等比缩放而来（fx/fy/cx/cy 各除以 2）。
    """
    camera_matrix = np.array([
        [169.8590391531136, 0.0, 161.1067169098169],
        [0.0, 169.3671313361189, 118.28065124904922],
        [0.0, 0.0, 1.0]
    ], dtype=np.float64)

    dist_coeffs = np.array([
        -0.11437112919147858, 0.20363775915796883,
        0.0006716431996742911, -0.0024595950263239363,
        -0.10009324071505243
    ], dtype=np.float64)

    return camera_matrix, dist_coeffs


def save_calibration(camera_matrix, dist_coeffs, rms_error=None):
    """
    将标定结果保存为 JSON 文件。

    Args:
        camera_matrix: 3x3 内参矩阵 (numpy array)
        dist_coeffs: 畸变系数 (numpy array)
        rms_error: 重投影误差 (float, 可选)
    """
    os.makedirs(CALIBRATION_DIR, exist_ok=True)

    data = {
        "camera_matrix": camera_matrix.tolist(),
        "dist_coeffs": dist_coeffs.tolist(),
        "image_size": [320, 240],
    }
    if rms_error is not None:
        data["rms_error"] = rms_error

    with open(CALIBRATION_FILE, "w") as f:
        json.dump(data, f, indent=2)

    logger.info("标定参数已保存到 %s", CALIBRATION_FILE)


def load_calibration():
    """
    加载标定参数。优先读取用户标定文件，不存在则返回默认参数。

    Returns:
        (camera_matrix, dist_coeffs) — 均为 numpy array
    """
    if os.path.exists(CALIBRATION_FILE):
        try:
            with open(CALIBRATION_FILE, "r") as f:
                data = json.load(f)
            camera_matrix = np.array(data["camera_matrix"], dtype=np.float64)
            dist_coeffs = np.array(data["dist_coeffs"], dtype=np.float64)
            logger.info("已加载用户标定参数: %s", CALIBRATION_FILE)
            return camera_matrix, dist_coeffs
        except Exception as e:
            logger.warning("读取标定文件失败，使用默认参数: %s", e)

    logger.info("使用默认标定参数")
    return get_default_params()


def delete_calibration():
    """删除用户标定文件，恢复为默认参数。"""
    if os.path.exists(CALIBRATION_FILE):
        os.remove(CALIBRATION_FILE)
        logger.info("已删除标定文件，恢复默认参数")


def run_calibration(images):
    """
    使用棋盘格图案执行摄像头标定。

    Args:
        images: 灰度图像列表 (list of numpy arrays)

    Returns:
        dict: {
            "success": bool,
            "rms_error": float or None,
            "camera_matrix": list or None,
            "dist_coeffs": list or None,
            "images_used": int,
            "message": str
        }
    """
    if not images or len(images) < 3:
        return {
            "success": False,
            "rms_error": None,
            "camera_matrix": None,
            "dist_coeffs": None,
            "images_used": len(images) if images else 0,
            "message": "至少需要3张有效的棋盘格图像才能进行标定"
        }

    # 准备物体坐标（棋盘格角点在真实世界中的位置）
    objp = np.zeros((CHESSBOARD_SIZE[0] * CHESSBOARD_SIZE[1], 3), np.float32)
    objp[:, :2] = np.mgrid[0:CHESSBOARD_SIZE[0], 0:CHESSBOARD_SIZE[1]].T.reshape(-1, 2)

    obj_points = []  # 3D 世界坐标
    img_points = []  # 2D 图像坐标

    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)

    for img in images:
        gray = img if len(img.shape) == 2 else cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        ret, corners = cv2.findChessboardCorners(gray, CHESSBOARD_SIZE, None)
        if ret:
            corners_refined = cv2.cornerSubPix(gray, corners, (11, 11), (-1, -1), criteria)
            obj_points.append(objp)
            img_points.append(corners_refined)

    if len(obj_points) < 3:
        return {
            "success": False,
            "rms_error": None,
            "camera_matrix": None,
            "dist_coeffs": None,
            "images_used": len(obj_points),
            "message": f"仅检测到 {len(obj_points)} 张有效棋盘格图像，至少需要3张"
        }

    h, w = images[0].shape[:2]
    rms, camera_matrix, dist_coeffs, rvecs, tvecs = cv2.calibrateCamera(
        obj_points, img_points, (w, h), None, None
    )

    # 根据 rms_error 判断标定质量
    RMS_GOOD = 1.0
    RMS_ACCEPTABLE = 2.0

    if rms > RMS_ACCEPTABLE:
        # 质量太差，不保存，提示重新标定
        logger.warning("标定质量较差 (rms=%.4f > %.1f)，不保存结果", rms, RMS_ACCEPTABLE)
        return {
            "success": False,
            "quality": "poor",
            "rms_error": round(rms, 6),
            "camera_matrix": camera_matrix.tolist(),
            "dist_coeffs": dist_coeffs.flatten().tolist(),
            "images_used": len(obj_points),
            "message": f"标定质量较差（重投影误差: {rms:.4f}，阈值: {RMS_ACCEPTABLE}），请重新拍摄更多角度的照片后再试"
        }

    # 质量可接受，保存结果
    save_calibration(camera_matrix, dist_coeffs, rms_error=rms)

    if rms > RMS_GOOD:
        # 一般质量，保存但给警告
        logger.info("标定质量一般 (rms=%.4f)，已保存", rms)
        return {
            "success": True,
            "quality": "warning",
            "rms_error": round(rms, 6),
            "camera_matrix": camera_matrix.tolist(),
            "dist_coeffs": dist_coeffs.flatten().tolist(),
            "images_used": len(obj_points),
            "message": f"标定已保存，但质量一般（重投影误差: {rms:.4f}），建议重新拍摄以获得更好的精度"
        }

    # 质量优秀
    return {
        "success": True,
        "quality": "good",
        "rms_error": round(rms, 6),
        "camera_matrix": camera_matrix.tolist(),
        "dist_coeffs": dist_coeffs.flatten().tolist(),
        "images_used": len(obj_points),
        "message": f"标定成功，使用了 {len(obj_points)} 张图像，重投影误差: {rms:.6f}"
    }
