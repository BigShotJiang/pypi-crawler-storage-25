# -*- coding: utf-8 -*-
"""
REPL 会话管理器

管理持久化的 Python REPL 子进程（repl_worker.py），
通过 JSON Lines 协议通信，支持代码执行、重置、中断等操作。
"""

import os
import sys
import json
import signal
import subprocess
import threading
import logging
import psutil

logger = logging.getLogger(__name__)

# repl_worker.py 脚本路径
_WORKER_SCRIPT = os.path.join(os.path.dirname(__file__), 'repl_worker.py')


class ReplSession:
    """管理一个持久化的 Python REPL 子进程。"""

    def __init__(self):
        self.process = None
        self._lock = threading.Lock()
        self._interrupted = False  # 用户主动中断标志

    def start(self):
        """启动 repl_worker.py 子进程。"""
        if self.is_alive():
            return

        env = os.environ.copy()
        env['PYTHONUNBUFFERED'] = '1'
        env['PYTHONIOENCODING'] = 'utf-8'

        # 树莓派 SPI LCD 使用 linuxfb 平台，避免 Qt 默认尝试 xcb 崩溃
        from .code_executor import CodeExecutor
        if CodeExecutor.is_raspberry_pi():
            env['QT_QPA_PLATFORM'] = 'linuxfb:fb=/dev/fb-spi'

        self.process = subprocess.Popen(
            [sys.executable, _WORKER_SCRIPT],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
            bufsize=0,  # 无缓冲
        )
        logger.info(f"REPL worker 已启动, PID={self.process.pid}")

    def execute(self, code):
        """
        向子进程发送代码执行命令。

        这是一个生成器函数，yield 每个从 worker 返回的 JSON dict。
        读到 {"type": "complete", ...} 时停止。
        如果子进程已死亡，自动重启并先 yield 一条提示。
        """
        if not self.is_alive():
            self.start()
            yield {"type": "output", "text": "[REPL 子进程已重启]\n"}

        # 进入新一轮执行，清除上次的中断标志
        self._interrupted = False

        cmd = json.dumps({"action": "execute", "code": code}, ensure_ascii=False) + "\n"

        with self._lock:
            try:
                self.process.stdin.write(cmd.encode('utf-8'))
                self.process.stdin.flush()
            except (BrokenPipeError, OSError) as e:
                logger.error(f"写入 stdin 失败: {e}")
                yield {"type": "error", "text": f"REPL 子进程通信失败: {e}\n"}
                yield {"type": "complete", "success": False, "error": str(e)}
                return

            # 逐行读取 stdout 中的 JSON 输出
            while True:
                try:
                    raw = self.process.stdout.readline()
                except (OSError, ValueError) as e:
                    logger.error(f"读取 stdout 失败: {e}")
                    yield {"type": "error", "text": f"读取输出失败: {e}\n"}
                    yield {"type": "complete", "success": False, "error": str(e)}
                    return

                if not raw:
                    # 子进程退出，stdout 关闭
                    if self._interrupted:
                        # 用户主动停止：worker 进程已被强杀
                        logger.info("REPL worker 已被用户中断")
                        yield {"type": "output", "text": "执行已停止\n"}
                        yield {"type": "complete", "success": True, "interrupted": True}
                    else:
                        logger.warning("REPL worker stdout 已关闭，子进程可能已退出")
                        yield {"type": "error", "text": "REPL 子进程意外退出\n"}
                        yield {"type": "complete", "success": False, "error": "子进程意外退出"}
                    return

                line = raw.decode('utf-8', errors='replace').strip()
                if not line:
                    continue

                try:
                    data = json.loads(line)
                except json.JSONDecodeError:
                    logger.warning(f"无法解析 JSON: {line}")
                    continue

                yield data

                if data.get("type") == "complete":
                    return

    def reset(self):
        """重置子进程的命名空间。"""
        if not self.is_alive():
            return

        cmd = json.dumps({"action": "reset"}) + "\n"

        with self._lock:
            try:
                self.process.stdin.write(cmd.encode('utf-8'))
                self.process.stdin.flush()

                # 读取 reset_complete 确认
                while True:
                    raw = self.process.stdout.readline()
                    if not raw:
                        logger.warning("reset 时 worker 已退出")
                        return
                    line = raw.decode('utf-8', errors='replace').strip()
                    if not line:
                        continue
                    try:
                        data = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if data.get("type") == "reset_complete":
                        logger.info("REPL 命名空间已重置")
                        return
            except (BrokenPipeError, OSError) as e:
                logger.error(f"reset 失败: {e}")

    def interrupt(self):
        """
        强制中断当前执行：直接杀掉 worker 进程树。

        SIGINT 在 C 扩展阻塞 I/O（pyaudio.read、cv2.VideoCapture.read 等）
        中无法可靠投递 KeyboardInterrupt，因此采用与"上传模式"一致的
        进程树强杀策略。下次 execute() 会通过 is_alive() 检查自动重启
        worker（命名空间清空，但保证 100% 可停）。
        """
        if not self.is_alive():
            return
        logger.info(f"正在强制中断 REPL worker (PID={self.process.pid})...")
        self._interrupted = True
        # 复用 shutdown 的进程树清理逻辑（terminate → wait → kill）
        self.shutdown()

    def is_alive(self):
        """检查子进程是否存活。"""
        return self.process is not None and self.process.poll() is None

    def shutdown(self):
        """完全关闭子进程，使用 psutil 清理进程树。"""
        if self.process is None:
            return

        pid = self.process.pid
        logger.info(f"正在关闭 REPL worker (PID={pid})...")

        # 1. 关闭 stdin，触发 worker 主循环退出
        try:
            self.process.stdin.close()
        except OSError:
            pass

        # 2. 使用 psutil 清理子进程树
        try:
            parent = psutil.Process(pid)
            children = parent.children(recursive=True)

            # 先 terminate 所有子进程
            for child in children:
                try:
                    child.terminate()
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass

            # 等待子进程结束
            gone, alive = psutil.wait_procs(children, timeout=3)

            # 强制 kill 仍存活的子进程
            for p in alive:
                try:
                    p.kill()
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass

        # 3. 终止主进程
        try:
            self.process.terminate()
            self.process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            try:
                self.process.kill()
                self.process.wait(timeout=2)
            except Exception:
                pass
        except Exception:
            pass

        logger.info(f"REPL worker (PID={pid}) 已关闭")
        self.process = None


class ReplSessionManager:
    """
    REPL 会话管理器（单例模式）。

    支持按 session_id 隔离的多会话管理，每个浏览器标签页独立会话。
    执行前自动停掉"运行"模式的进程。
    """

    def __init__(self):
        self._sessions = {}  # session_id -> ReplSession
        self._lock = threading.Lock()

    def execute(self, code, session_id='default'):
        """
        在指定会话中执行代码。如果会话未启动则自动 start（懒启动）。

        执行前会停掉"运行"模式的进程。
        返回一个生成器，yield JSON dict。
        """
        # 懒导入，避免循环依赖
        from .code_executor import execution_manager
        execution_manager.stop_all_executions()

        with self._lock:
            if session_id not in self._sessions or not self._sessions[session_id].is_alive():
                if session_id in self._sessions:
                    self._sessions[session_id].shutdown()
                self._sessions[session_id] = ReplSession()
            session = self._sessions[session_id]

        return session.execute(code)

    def reset(self, session_id=None):
        """重置指定会话的 REPL 命名空间，不传 session_id 则重置所有。"""
        with self._lock:
            if session_id:
                if session_id in self._sessions:
                    self._sessions[session_id].reset()
            else:
                for s in self._sessions.values():
                    s.reset()

    def interrupt(self, session_id=None):
        """中断指定会话的当前执行，不传 session_id 则中断所有。"""
        with self._lock:
            if session_id:
                if session_id in self._sessions:
                    self._sessions[session_id].interrupt()
            else:
                for s in self._sessions.values():
                    s.interrupt()

    def shutdown(self, session_id=None):
        """关闭指定会话，不传 session_id 则关闭所有。"""
        with self._lock:
            if session_id:
                if session_id in self._sessions:
                    self._sessions[session_id].shutdown()
                    del self._sessions[session_id]
            else:
                for s in self._sessions.values():
                    s.shutdown()
                self._sessions.clear()

    def is_alive(self, session_id='default'):
        """返回指定会话是否存活。"""
        with self._lock:
            return session_id in self._sessions and self._sessions[session_id].is_alive()


# 模块级单例
repl_session_manager = ReplSessionManager()
