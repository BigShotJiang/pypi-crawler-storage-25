import subprocess
import time
import random
import importlib.util
import os
import sys

# ─── INTERNAL CONFIG ──────────────────────────────────────────────────────────
_WORDS_PER_SECOND = 3
# ─────────────────────────────────────────────────────────────────────────────

try:
    import pyautogui as _pag
    _PAG_AVAILABLE = True
except ImportError:
    _PAG_AVAILABLE = False


def _get_source(file_number):
    spec = importlib.util.find_spec("labdawg")
    if spec is None:
        raise RuntimeError("labdawg module not found.")
    package_dir = os.path.dirname(spec.origin)
    path = os.path.join(package_dir, "templates", f"{file_number}.py")
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Template {file_number}.py not found. Choose a number from 1 to 22."
        )
    with open(path, "r", encoding="utf-8", newline="") as f:
        raw = f.read()
    # Normalise line endings: strip \r so CRLF and CR become plain \n
    return raw.replace("\r\n", "\n").replace("\r", "\n")


def _char_delay(wps=_WORDS_PER_SECOND, avg_word_len=5):
    cps = wps * (avg_word_len + 1)
    return 1.0 / cps


def _line_delay(line, base_delay):
    """Return a human-like pause that scales with line length."""
    stripped = line.strip()
    # Base time = how long it would take to type this many characters
    char_count = max(len(line), 1)
    typing_time = char_count * base_delay * random.uniform(0.7, 1.3)

    # Extra pauses at structural boundaries
    if stripped.startswith(("def ", "class ", "if __name__")):
        typing_time += random.uniform(0.4, 0.9)
    if stripped.startswith("#"):
        typing_time += random.uniform(0.1, 0.3)
    if stripped == "":
        typing_time = random.uniform(0.15, 0.35)

    return typing_time


def _set_clipboard(text):
    """
    Copy text to the system clipboard.
    Tries pyperclip first (always installed alongside pyautogui),
    then falls back to platform-native methods.
    """
    try:
        import pyperclip
        pyperclip.copy(text)
        return
    except Exception:
        pass

    # Windows fallback via ctypes
    if sys.platform == "win32":
        try:
            import ctypes
            import ctypes.wintypes

            GMEM_MOVEABLE = 0x0002
            CF_UNICODETEXT = 13

            ctypes.windll.user32.OpenClipboard(0)
            ctypes.windll.user32.EmptyClipboard()
            encoded = text.encode("utf-16-le") + b"\x00\x00"
            h = ctypes.windll.kernel32.GlobalAlloc(GMEM_MOVEABLE, len(encoded))
            p = ctypes.windll.kernel32.GlobalLock(h)
            ctypes.memmove(p, encoded, len(encoded))
            ctypes.windll.kernel32.GlobalUnlock(h)
            ctypes.windll.user32.SetClipboardData(CF_UNICODETEXT, h)
            ctypes.windll.user32.CloseClipboard()
            return
        except Exception:
            pass

    # macOS fallback
    if sys.platform == "darwin":
        try:
            proc = subprocess.Popen(
                ["pbcopy"], stdin=subprocess.PIPE
            )
            proc.communicate(text.encode("utf-8"))
            return
        except Exception:
            pass

    # Linux fallback via xclip or xsel
    for cmd in (["xclip", "-selection", "clipboard"], ["xsel", "--clipboard", "--input"]):
        try:
            proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
            proc.communicate(text.encode("utf-8"))
            return
        except Exception:
            continue

    raise RuntimeError(
        "Cannot access clipboard. Install pyperclip: pip install pyperclip"
    )


def _clear_current_line():
    """
    Delete whatever IDLE has auto-indented on the current line.
    Home → Shift+End selects the whole line content, then Delete wipes it.
    """
    _pag.hotkey("home")
    time.sleep(0.04)
    _pag.hotkey("shift", "end")
    time.sleep(0.04)
    _pag.press("delete")
    time.sleep(0.06)


def _paste():
    """Paste clipboard content at current cursor position."""
    if sys.platform == "darwin":
        _pag.hotkey("command", "v")
    else:
        _pag.hotkey("ctrl", "v")
    time.sleep(0.05)


def _type_code(source, base_delay):
    """
    Type source code line by line using clipboard paste.

    Each line is placed into the clipboard verbatim (with its exact
    leading spaces) and then pasted with Ctrl+V / Cmd+V.  This
    completely avoids:
      - pyautogui.typewrite() silently dropping characters it cannot
        map (quotes, backslash, braces, etc.)
      - IDLE auto-indent doubling the indentation after Enter
    Human-like delays are added between lines so the typing still
    looks natural.
    """
    lines = source.split("\n")

    for line_num, line in enumerate(lines):
        # ── clear IDLE's auto-indent before pasting our exact line ──
        # (on line 0 the cursor is at column 0 already; on subsequent
        #  lines IDLE may have indented automatically after Enter)
        if line_num > 0:
            _clear_current_line()

        # ── paste the exact line content (spaces + code) ──
        if line:                         # skip set+paste for blank lines
            _set_clipboard(line)
            _paste()

        # ── press Enter to move to the next line (skip after last line) ──
        if line_num < len(lines) - 1:
            _pag.press("enter")
            # Human-like delay that approximates the time to type this line
            wait = _line_delay(line, base_delay)
            time.sleep(wait)


def _launch_idle_new_file():
    """
    Open IDLE and create a new script window, then reliably focus it.

    Strategy:
      1. Launch IDLE (which opens the Shell window).
      2. Wait for IDLE to be ready.
      3. Press Ctrl+N to open a new File (script) window.
      4. Wait for the script window to appear.
      5. Use pygetwindow (if available) to bring the untitled script
         window to the front; otherwise fall back to a safe click in
         the upper-left quadrant where the new window typically appears.

    Fix: we no longer click dead-centre of the screen (which lands on
    the Shell). We activate the script window by title first, and only
    fall back to a positional click as a last resort.
    """
    subprocess.Popen([sys.executable, "-m", "idlelib.idle"])
    time.sleep(3.5)

    _pag.hotkey("ctrl", "n")
    time.sleep(2.5)

    focused = False
    try:
        import pygetwindow as gw
        candidates = [w for w in gw.getAllWindows()
                      if "untitled" in w.title.lower() or "new file" in w.title.lower()]
        if candidates:
            win = candidates[0]
            win.activate()
            time.sleep(0.6)
            focused = True
    except Exception:
        pass

    if not focused:
        w, h = _pag.size()
        # Click in the upper-left quadrant (where the new script window opens)
        # rather than dead centre (which hits the Shell window behind it)
        _pag.click(w // 4, h // 4)
        time.sleep(0.5)
        _pag.click(w // 4, h // 3)
        time.sleep(0.3)


def write(n):
    """
    Open a new IDLE script window and type out template <n> in a human-like way.
    Code is typed with its original indentation preserved exactly.

    Usage (inside IDLE shell):
        import labdawg
        labdawg.write(8)
    """
    if not _PAG_AVAILABLE:
        raise ImportError(
            "pyautogui is required. Install it with: pip install pyautogui"
        )

    if not isinstance(n, int) or not (1 <= n <= 22):
        raise ValueError("Please choose a number from 1 to 22.")

    source = _get_source(n)
    base_delay = _char_delay()

    print(1)

    for i in range(5, 0, -1):
        time.sleep(1)

    _launch_idle_new_file()
    _type_code(source, base_delay)
