import nltk

ps = nltk.stem.PorterStemmer()

words = ["program", "programs", "programmer", "programming", "programmers"]

for w in words:
    print(w, ":", ps.stem(w))
