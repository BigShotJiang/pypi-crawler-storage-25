class Person:
   def __init__(self, name):
       self.name = name
       self.children = []

   def add_child(self, child):
       self.children.append(child)
       print(f"{child.name} is the child of {self.name}")

   def display_children(self):
       if self.children:
           print(f"{self.name}'s Children:")
           for child in self.children:
               print(child.name)
       else:
            print(f"{self.name} has no children.")
            

father = Person("John")
mother = Person("Jane")
son = Person("Alex")
daughter = Person("Emma")
father.add_child(son)
father.add_child(daughter)
mother.add_child(son)
mother.add_child(daughter)
father.display_children()
mother.display_children()
