name=str(input("enter the name:"))
age=int(input("enter the age:"))
if(age>=18):
        print(f"{name} eligible to vote")
else:
    print(f"{name} not eligible to vote")
