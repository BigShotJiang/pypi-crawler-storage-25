def withconc(item, lst):
    return lst + [item]
def withoutconc(item, lst):
    return [lst, item]
print("With Conc: ", withconc(3, [1,2]))
print("Without Conc: ", withoutconc(3, [1,2]))
