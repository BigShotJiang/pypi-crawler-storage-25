punctuation = "!@#$%^&*()_[]{}\\?/.,<>"

text = input("Enter the string: ")
no_punc = ""

for char in text:
    if char not in punctuation:
        no_punc = no_punc + char

print(no_punc)

text = input("Enter a string: ")

words = text.split()
words.sort()

for word in words:
    print(word)
