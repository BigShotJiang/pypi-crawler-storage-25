import numpy as np

def pr(links,num_pages,iterations,damping=0.85):
    ranks=np.ones(num_pages)/num_pages
    m=np.zeros((num_pages,num_pages))
    for page,outgoing_links in links.items():
        if outgoing_links:
            for link in outgoing_links:
                if 0<=link<num_pages:
                    m[link,page]=1/len(outgoing_links)
                else:
                    print(f"warning:ignoring invalid link {link} from page {page}")
        else:
            m[:,page]=1/num_pages
    m=damping*m+(1-damping)/num_pages
    print("iteration results:")
    for i in range(iterations):
        new_rank=np.dot(m,ranks)
        print(f"iteration{i+1}:{new_rank}")
        ranks=new_rank
    return ranks


num_pages=int(input("enter number of pages:"))
iterations=int(input("enter the number of iterations:"))
web_graph={}
for i in range(num_pages):
    links=list(map(int,input(f"enter outgoing links from page{i}(space-sep):").split()))
    web_graph[i]=[link for link in links if 0<=link<num_pages]
ranks=pr(web_graph,num_pages,iterations)
for i,rank in enumerate(ranks):
    print(f"final rank page{i}:{rank:.4f}")
