import numpy as np

def centroid(data,k):
    return data[np.random.choice(data.shape[0],k,replace=False)]

def clust(data,centroids):
    dist = np.linalg.norm(data[:,np.newaxis]-centroids,axis=2)
    return np.argmin(dist,axis=1)

def update(data,clusters,k):
    return np.array([data[clusters == i].mean(axis=0) for i in range(k)])

def kmeans(data,k,max_iter = 100):
    centroids=centroid(data,k)
    for _ in range(max_iter):
        clusters=clust(data,centroids)
        new_centroids= update(data,clusters,k)
        if np.all(centroids == new_centroids):
            break
        centroids=new_centroids
    return centroids,clusters


num_points=int(input("Enter the number of data points:"))
num_features=int(input("Enter the number of features:"))

k=int(input("Enter the number of clusters:"))
data =[]
print("Enter datapoints(space-separated values):")
for _ in range(num_points):
    point=list(map(float,input().split()))
    data.append(point)

data=np.array(data)

centroids,clusters= kmeans(data,k)
print("FinalCentroids:")
print(centroids)
print("Clusterassignment:")
print(clusters)
