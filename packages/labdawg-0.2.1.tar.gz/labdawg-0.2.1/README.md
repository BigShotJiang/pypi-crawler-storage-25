# labdawg

Example Python package.

Usage:

```python
from labdawg import display
display()
```