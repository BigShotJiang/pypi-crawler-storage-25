
import numpy as np
import bcijelly


def test_load_data() -> None:
    import bcijelly as bj

    cases = [
        {
            "dataset_name": "11_Speech",
            "protocol": "train-test",
            "task": "speech",
            "subject_index": 0,
            "day_index": 0,
            "split_ratio": "8:2",
            "seed": 42,
        },
        {
            "dataset_name": "8_ReachingMCPMC_Regression_Test",
            "protocol": "single_day",
            "task": "regression",
            "subject_index": 0,
            "day_index": 0,
            "split_ratio": "7:1:2",
            "seed": 42,
        },
        {
            "dataset_name": "1_FALCONM1-A",
            "protocol": "cross_day",
            "task": "classification",
            "subject_index": 0,
            "split_ratio": "7:1:2",
            "seed": 42,
        },
    ]

    for case in cases:
        loaded_data = bj.load_data(verbose=False, **case)

        train_x, train_y = loaded_data.train_dataset[:2]
        test_x, test_y = loaded_data.test_dataset[:2]

        assert train_x.shape[0] == train_y.shape[0]
        assert test_x.shape[0] == test_y.shape[0]
        assert loaded_data.requested_task == case["task"]

        if loaded_data.val_dataset is not None:
            val_x, val_y = loaded_data.val_dataset[:2]
            assert val_x.shape[0] == val_y.shape[0]


def test_demo() -> None:

    import bcijelly as bj

    loaded_data = bj.load_data(
        dataset_name="5_Jango_force",
        protocol="single_day", task="regression",
        subject_index=0, day_index=0, split_ratio="8:2",
    )
    model = bcijelly.model.transformer(task="regression")
    train_result = model.train(
        loaded_data.train_dataset, loaded_data.val_dataset,
        epochs=1,
    )
    test_result = model.test(loaded_data.test_dataset)

    bj.summary(loaded_data, model, train_result, test_result)


def test_single_day_classification() -> None:
    '''
        单天任务示例。
        完整的使用流程包括：
        1. 创建模型实例，例如 bcijelly.model.transformer(task="classification")。这一步决定了使用哪个模型以及任务类型。
        2. 调用 bcijelly.load_data 加载数据，得到 loaded_data。
        3. 调用模型实例的 train 函数进行训练，得到 train_result。
        4. 调用模型实例的 test 函数进行测试，得到 test_result。
        5. 调用 bcijelly.summary 对结果进行总结和展示。
    '''

    model = bcijelly.model.transformer(task="classification")

    loaded_data = bcijelly.load_data(
        dataset_name="1_FALCONM1-A",            # 选择数据集
        protocol="single_day",                  # "single_day" | "cross_day"，此处演示单天解码
        task="classification",                  # 显式声明任务类型，触发能力声明校验
        subject_index=0,                        # 范围: [0, n_subjects - 1]
        day_index=0,                            # 范围: [0, n_days - 1]
        split_ratio="7:1:2",                  # 2段表示 train:test，3段表示 train:val:test
        seed=42,                                # int，单天解码中用于设置划分测试集和验证集的随机种子
        # auto_download_missing=True,           # 设置本地缺数据时自动从Hugging Face下载，默认为True
        verbose=False,
    )

    train_result = model.train(
        train_dataset=loaded_data.train_dataset,
        val_dataset=loaded_data.val_dataset,    # loaded_data.val_dataset 或 None
        seed=42,  # int
        device="auto",
        run_name="demo_single_day_transformer", # 用于结果目录命名
        epochs=1,
        plot=False,
        verbose=False,
    )

    test_result = model.test(
        test_dataset=loaded_data.test_dataset,
        verbose=False,
    )

    bcijelly.summary(
        loaded_data=loaded_data,                # bj.load_data 的返回结果
        model=model,
        train_result=train_result,              # model.train 返回结果
        test_result=test_result,                # model.test 返回结果
        mode="compact",                            # "compact" | "full"，控制 summary 展示的详细程度
    )



def test_cross_day_classification() -> None:
    '''
        跨天任务示例。
        在测试代码部分，我们演示了两种计算测试结果的方式：
        1. 将所有测试日的数据合在一起进行测试，得到一个整体的测试结果。
        2. 对每一个测试日的数据单独进行测试，得到每个测试日的测试结果，然后计算这些测试结果的平均值作为整体的测试结果。
        用户根据自己的需求选择其中一种方式。
    '''

    model = bcijelly.model.transformer(task="classification")

    loaded_data = bcijelly.load_data(
        dataset_name="1_FALCONM1-A",
        protocol="cross_day",                   # "single_day" | "cross_day"，此处演示跨天解码
        task="classification",                  # 显式声明任务类型，触发能力声明校验
        subject_index=0,                        # 范围: [0, n_subjects - 1]
        split_ratio="7:1:2",                  # 2段表示 train:test，3段表示 train:val:test
        # auto_download_missing=True,           # 设置本地缺数据时自动从Hugging Face下载，默认为True
        verbose=False,
    )

    train_result = model.train(
        train_dataset=loaded_data.train_dataset,
        val_dataset=loaded_data.val_dataset,    # loaded_data.val_dataset 或 None
        seed=42,  # int
        device="auto",
        run_name="demo_cross_day_transformer",  # 用于结果目录命名
        epochs=1,
        plot=False,
        verbose=False,
    )

    # # 所有测试日共同测试
    # test_result = model.test(
    #     test_dataset=loaded_data.test_dataset,
    #     verbose=False,
    # )

    # 每一个测试日单独测试
    day_acc_list: list[float] = []
    for one_day_test_dataset in loaded_data.test_day_datasets:
        one_day_result = model.test(
            test_dataset=one_day_test_dataset,
            verbose=False,
        )
        day_acc_list.append(float(one_day_result["acc"]))

    test_result = {
        "acc": float(np.mean(day_acc_list)),
        "per_day_acc": day_acc_list,
    }

    bcijelly.summary(
        loaded_data=loaded_data,                # bj.load_data 的返回结果
        model=model,
        train_result=train_result,              # model.train 返回结果
        test_result=test_result,                # model.test 返回结果
        mode="compact",                            # "compact" | "full"
    )


def test_single_day_regression() -> None:
    model = bcijelly.model.transformer(task="regression")

    loaded_data = bcijelly.load_data(
        dataset_name="5_Jango_force",
        protocol="single_day",
        task="regression",
        subject_index=0,
        day_index=0,
        split_ratio="7:1:2",
        seed=42,
        verbose=False,
    )

    train_result = model.train(
        train_dataset=loaded_data.train_dataset,
        val_dataset=loaded_data.val_dataset,
        seed=42,
        device="auto",
        run_name="demo_single_day_transformer_regression_jango",
        epochs=1,
        plot=False,
        verbose=False,
    )

    test_result = model.test(
        test_dataset=loaded_data.test_dataset,
        verbose=False,
    )

    compact_summary = bcijelly.summary(
        loaded_data=loaded_data,
        model=model,
        train_result=train_result,
        test_result=test_result,
        mode="compact",
    )
    full_summary = bcijelly.summary(
        loaded_data=loaded_data,
        model=model,
        train_result=train_result,
        test_result=test_result,
        mode="full",
    )

    assert compact_summary["compact"]["dataset"] == "5_Jango_force"
    assert compact_summary["compact"]["module"] == "transformer"
    assert compact_summary["compact"]["task"] == "regression"
    assert "r2" in compact_summary["compact"]
    assert full_summary["module"]["primary_test_metric"] == "r2"
    assert full_summary["loaded_data"]["requested_task"] == "regression"


def test_cross_day_regression() -> None:
    model = bcijelly.model.transformer(task="regression")

    loaded_data = bcijelly.load_data(
        dataset_name="5_Jango_force",
        protocol="cross_day",
        task="regression",
        subject_index=0,
        split_ratio="7:1:2",
        verbose=False,
    )

    train_result = model.train(
        train_dataset=loaded_data.train_dataset,
        val_dataset=loaded_data.val_dataset,
        seed=42,
        device="auto",
        run_name="demo_cross_day_transformer_regression_jango",
        epochs=1,
        plot=False,
        verbose=False,
    )

    day_r2_list: list[float] = []
    for one_day_test_dataset in loaded_data.test_day_datasets:
        one_day_result = model.test(
            test_dataset=one_day_test_dataset,
            verbose=False,
        )
        day_r2_list.append(float(one_day_result["r2"]))

    test_result = {
        "r2": float(np.mean(day_r2_list)),
        "per_day_r2": day_r2_list,
    }

    compact_summary = bcijelly.summary(
        loaded_data=loaded_data,
        model=model,
        train_result=train_result,
        test_result=test_result,
        mode="compact",
    )
    full_summary = bcijelly.summary(
        loaded_data=loaded_data,
        model=model,
        train_result=train_result,
        test_result=test_result,
        mode="full",
    )

    assert compact_summary["compact"]["dataset"] == "5_Jango_force"
    assert compact_summary["compact"]["protocol"] == "cross_day"
    assert compact_summary["compact"]["module"] == "transformer"
    assert compact_summary["compact"]["task"] == "regression"
    assert "r2" in compact_summary["compact"]
    assert full_summary["module"]["task_type"] == "regression"
    assert full_summary["loaded_data"]["has_test_day_datasets"] is True


def test_train_test_speech() -> None:

    model = bcijelly.model.lfads(task="speech")

    loaded_data = bcijelly.load_data(
        dataset_name="11_Speech",
        protocol="train-test", task="speech",
        split_ratio="3:3:1",
        verbose=False,
    )

    train_result = model.train(
        loaded_data.train_dataset, loaded_data.val_dataset,
        run_name="demo_train_test_speech",
        epochs=1,
        verbose=False,
    )

    test_result = model.test(
        loaded_data.test_dataset,
        verbose=False,
    )

    bcijelly.summary(
        loaded_data, model, 
        train_result, test_result,
        mode="compact",
    )


if __name__ == "__main__":
    # test_load_data()
    test_demo()
