from __future__ import annotations

from bcijelly.dataset._load_data_capability import LOAD_DATA_CAPABILITY_DECLARATION


def test_load_data_capability_declaration_contract() -> None:
    assert LOAD_DATA_CAPABILITY_DECLARATION.get("schema_version") == "internal.v1"

    supported_protocols = LOAD_DATA_CAPABILITY_DECLARATION.get("supported_protocols")
    assert supported_protocols == ["single_day", "cross_day", "train-test", "train-val-test"]

    supported_tasks = LOAD_DATA_CAPABILITY_DECLARATION.get("supported_tasks")
    assert supported_tasks == ["classification", "regression", "speech"]

    protocol_notes = LOAD_DATA_CAPABILITY_DECLARATION.get("protocol_notes")
    assert isinstance(protocol_notes, dict)
    for protocol_name in supported_protocols:
        note = protocol_notes.get(protocol_name)
        assert isinstance(note, dict)
        assert isinstance(note.get("purpose"), str)
        assert isinstance(note.get("file_patterns"), list)
        assert isinstance(note.get("use_cases"), list)

    task_notes = LOAD_DATA_CAPABILITY_DECLARATION.get("task_notes")
    assert isinstance(task_notes, dict)
    for task_name in supported_tasks:
        note = task_notes.get(task_name)
        assert isinstance(note, dict)
        assert isinstance(note.get("target_keys"), list)
        assert isinstance(note.get("behavior"), str)

    task_handling = LOAD_DATA_CAPABILITY_DECLARATION.get("task_handling")
    assert isinstance(task_handling, dict)
    assert task_handling.get("validated_against_dataset_declaration") is True
    assert task_handling.get("controls_data_loading_branch") is True

    format_constraints = LOAD_DATA_CAPABILITY_DECLARATION.get("format_constraints")
    assert isinstance(format_constraints, dict)

    split_files = format_constraints.get("split_files")
    assert isinstance(split_files, dict)
    assert split_files.get("supported_protocols") == ["single_day", "train-test", "train-val-test"]

    protocol_compatibility = LOAD_DATA_CAPABILITY_DECLARATION.get("protocol_compatibility")
    assert isinstance(protocol_compatibility, dict)
    assert protocol_compatibility.get("single_day_is_compatible_with_declared") == [
        "train-test",
        "train-val-test",
    ]
    assert protocol_compatibility.get("train-test_and_train-val-test_are_mutually_incompatible") is True
