from __future__ import annotations

import argparse
import inspect
from pathlib import Path
from typing import Any, Sequence

import numpy as np

import bcijelly as bj


# ============================================================
# 用户通常会改的配置
# ============================================================
MODULE_NAME = "transformer"  # "stabilization" | "transformer" | "lstm" | "cycle_gan" | "lfads"
TASK = "classification"  # "classification" | "regression"
DATASET_NAME = "10_VisualGratingTask"
PROTOCOL = "single_day"  # "single_day" | "cross_day"
SUBJECT_INDEX = 0
SEED = 42
DEVICE = "auto"

# 仅 single_day 使用
DAY_INDEX = 0
SPLIT_RATIO = "7:1:2"

# QUICK 只是测试时少跑一点，不建议作为正式用户接口对外强调。
QUICK = True

VERBOSE_LOAD_DATA = False
VERBOSE_MODEL_RESULTS = False
SUMMARY_MODE = "compact"  # "compact" | "full"


# 仅用于测试脚本自己的轻量覆盖，不代表正式用户必须设置这些参数。
TEST_ONLY_TRAIN_OVERRIDES: dict[str, dict[str, Any]] = {
    "stabilization": {"epochs": 10, "fa_n_restarts": 1, "fa_max_its": 500},
    "transformer": {"epochs": 1},
    "lstm": {"epochs": 1},
    "lfads": {"epochs": 2},
    "cycle_gan": {"epochs": 2, "decoder_epochs": 4},
}


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="User-style BCIJelly demo script")
    parser.add_argument(
        "--auto-download-missing",
        dest="auto_download_missing",
        action="store_true",
        default=True,
        help="Automatically download dataset when it is missing locally.",
    )
    parser.add_argument(
        "--no-auto-download-missing",
        dest="auto_download_missing",
        action="store_false",
        help="Do not download dataset automatically when it is missing locally.",
    )
    return parser.parse_args(argv)


def _filter_kwargs(func: Any, kwargs: dict[str, Any]) -> dict[str, Any]:
    owner = getattr(func, "__self__", None)
    backend = getattr(owner, "_backend", None)
    backend_func = getattr(backend, getattr(func, "__name__", ""), None)
    signature = inspect.signature(backend_func) if backend_func is not None else inspect.signature(func)
    allowed = set(signature.parameters)
    return {key: value for key, value in kwargs.items() if key in allowed}


def _primary_metric_name(model: Any, task: str) -> str:
    metric = getattr(model, "PRIMARY_TEST_METRIC", None)
    if isinstance(metric, str) and metric:
        return metric
    return "acc" if task == "classification" else "r2"


def _build_user_train_kwargs(
    *,
    module_name: str,
    train_dataset: tuple[np.ndarray, np.ndarray],
    val_dataset: tuple[np.ndarray, np.ndarray] | None,
    # output_dir: Path,
    run_name: str,
) -> dict[str, Any]:
    kwargs: dict[str, Any] = {
        "train_dataset": train_dataset,
        "seed": SEED,
        "device": DEVICE,
        "run_name": run_name,
        "plot": False,
        "verbose": VERBOSE_MODEL_RESULTS,
    }
    if val_dataset is not None:
        kwargs["val_dataset"] = val_dataset

    if QUICK:
        kwargs.update(TEST_ONLY_TRAIN_OVERRIDES.get(module_name, {}))

    return kwargs


def _build_user_test_kwargs(
    *,
    test_dataset: tuple[np.ndarray, np.ndarray],
) -> dict[str, Any]:
    """更贴近真实用户调用的最小 test kwargs。"""
    return {
        "test_dataset": test_dataset,
        "verbose": VERBOSE_MODEL_RESULTS,
    }


def main(argv: Sequence[str] | None = None) -> None:
    args = parse_args(argv)

    if TASK not in {"classification", "regression"}:
        raise ValueError(f"Unsupported TASK: {TASK!r}")
    if PROTOCOL not in {"single_day", "cross_day"}:
        raise ValueError(f"Unsupported PROTOCOL: {PROTOCOL!r}")

    model = getattr(bj.model, MODULE_NAME)(task=TASK)

    load_kwargs = {
        "dataset_name": DATASET_NAME,
        "protocol": PROTOCOL,
        "task": TASK,
        "subject_index": SUBJECT_INDEX,
        "auto_download_missing": args.auto_download_missing,
        "verbose": VERBOSE_LOAD_DATA,
    }
    if PROTOCOL == "single_day":
        load_kwargs["seed"] = SEED
        load_kwargs["day_index"] = DAY_INDEX
        load_kwargs["split_ratio"] = SPLIT_RATIO

    loaded_result = bj.load_data(**load_kwargs)

    train_day = loaded_result.job.train_day if loaded_result.job else "unknown_train"
    test_day = loaded_result.job.test_day if loaded_result.job else "unknown_test"
    subject_name = getattr(loaded_result.job, "subject_name", None) if loaded_result.job else None
    subject_prefix = f"{subject_name}__" if subject_name else ""
    run_name = (
        f"{DATASET_NAME}__{subject_prefix}{PROTOCOL}__{MODULE_NAME}__{TASK}__seed{SEED}"
        f"__train-{train_day}__test-{test_day}"
    )

    print("=" * 80)
    print("Loaded data")
    print(f"dataset      : {DATASET_NAME}")
    print(f"module       : {MODULE_NAME}")
    print(f"task         : {TASK}")
    print(f"protocol     : {PROTOCOL}")
    print(f"subject_index: {SUBJECT_INDEX}")
    if subject_name is not None:
        print(f"subject_name : {subject_name}")
    if PROTOCOL == "single_day":
        print(f"day_index    : {DAY_INDEX}")
    print(f"train shape  : {loaded_result.train_dataset[0].shape}, {loaded_result.train_dataset[1].shape}")
    if loaded_result.val_dataset is not None:
        print(f"val shape    : {loaded_result.val_dataset[0].shape}, {loaded_result.val_dataset[1].shape}")
    else:
        print("val shape    : None")
    print(f"test shape   : {loaded_result.test_dataset[0].shape}, {loaded_result.test_dataset[1].shape}")
    if loaded_result.aligned_shape is not None:
        print(f"aligned shape: {loaded_result.aligned_shape}")
    print("=" * 80)

    train_kwargs = _build_user_train_kwargs(
        module_name=MODULE_NAME,
        train_dataset=loaded_result.train_dataset,
        val_dataset=loaded_result.val_dataset,
        run_name=run_name,
    )
    filtered_train_kwargs = _filter_kwargs(model.train, train_kwargs)
    train_result = model.train(**filtered_train_kwargs)

    metric_name = _primary_metric_name(model, TASK)

    if PROTOCOL == "cross_day" and loaded_result.test_day_datasets:
        day_metrics: list[float] = []
        last_test_result: dict[str, Any] | None = None
        for one_day_test_dataset in loaded_result.test_day_datasets:
            test_kwargs = _build_user_test_kwargs(test_dataset=one_day_test_dataset)
            filtered_test_kwargs = _filter_kwargs(model.test, test_kwargs)
            last_test_result = model.test(**filtered_test_kwargs)
            day_metrics.append(float(last_test_result[metric_name]))
        metric_value = float(np.mean(day_metrics)) if day_metrics else float("nan")
        test_result = {
            metric_name: metric_value,
            f"per_day_{metric_name}": day_metrics,
        }
        if last_test_result is not None:
            for key, value in last_test_result.items():
                if key not in test_result:
                    test_result[key] = value
    else:
        test_kwargs = _build_user_test_kwargs(test_dataset=loaded_result.test_dataset)
        filtered_test_kwargs = _filter_kwargs(model.test, test_kwargs)
        test_result = model.test(**filtered_test_kwargs)
        metric_value = float(test_result[metric_name])

    bj.summary(
        loaded_data=loaded_result,
        model=model,
        train_result=train_result,
        test_result=test_result,
        mode=SUMMARY_MODE,
    )


def test_for_user() -> None:
    main([])


if __name__ == "__main__":
    main()
