from __future__ import annotations

import pytest

import bcijelly as bj


def test_model_supported_tasks_declaration() -> None:
    assert bj.model.get_supported_tasks("transformer") == (
        "classification",
        "regression",
        "speech",
    )
    assert bj.model.get_supported_tasks("lstm") == (
        "classification",
        "regression",
        "speech",
    )
    assert bj.model.get_supported_tasks("cycle_gan") == (
        "classification",
        "regression",
    )
    assert bj.model.get_supported_tasks("lfads") == (
        "classification",
        "regression",
    )
    assert bj.model.get_supported_tasks("stabilization") == (
        "classification",
        "regression",
    )


def test_model_constructor_rejects_unsupported_task() -> None:
    with pytest.raises(ValueError, match="does not support task"):
        bj.model.stabilization(task="speech")

    with pytest.raises(ValueError, match="does not support task"):
        bj.model.cycle_gan(task="speech")

    with pytest.raises(ValueError, match="does not support task"):
        bj.model.lfads(task="speech")


def test_model_constructor_accepts_supported_task() -> None:
    _ = bj.model.transformer(task="speech")
    _ = bj.model.lstm(task="speech")
