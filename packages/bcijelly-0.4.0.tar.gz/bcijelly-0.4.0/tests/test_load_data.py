from __future__ import annotations

import inspect
import os
import warnings
from pathlib import Path
from typing import Any

import numpy as np
import pytest

import bcijelly as bj
from bcijelly.model.presets import get_module_params
from bcijelly.dataset._io import parse_split_ratio


DATASET_NAME = os.getenv("BCIJELLY_TEST_DATASET", "None")
PROTOCOL = os.getenv("BCIJELLY_TEST_PROTOCOL", "single_day").strip()
SEED = int(os.getenv("BCIJELLY_TEST_SEED", "42"))
SUBJECT_INDEX = int(os.getenv("BCIJELLY_TEST_SUBJECT_INDEX", "0"))
DAY_INDEX = int(os.getenv("BCIJELLY_TEST_DAY_INDEX", "0"))
SPLIT_RATIO = os.getenv("BCIJELLY_TEST_SPLIT_RATIO", "7:1:2")
AUTO_DOWNLOAD_MISSING = os.getenv("BCIJELLY_TEST_AUTO_DOWNLOAD", "1") not in {"0", "false", "False"}
QUICK = os.getenv("BCIJELLY_TEST_QUICK", "1") not in {"0", "false", "False"}
DEVICE = os.getenv("BCIJELLY_TEST_DEVICE", "auto")
VERBOSE_LOAD_DATA = os.getenv("BCIJELLY_TEST_VERBOSE_LOAD_DATA", "0") in {"1", "true", "True"}
MODULE_NAME = os.getenv("BCIJELLY_TEST_MODULE_NAME", "transformer").strip()
TASK = os.getenv("BCIJELLY_TEST_TASK", "classification").strip()


def _model_internal_val_ratio(split_ratio: str) -> float:
    parts = parse_split_ratio(split_ratio)
    if len(parts) == 2:
        return 0.0
    train_ratio, val_ratio, _ = parts
    denominator = train_ratio + val_ratio
    return 0.0 if denominator <= 0 else val_ratio / denominator

def _resolve_model_factory(module_name: str, task: str):
    if not module_name:
        raise ValueError("BCIJELLY_TEST_MODULE_NAME 不能为空。")
    if task not in {"classification", "regression", "speech"}:
        raise ValueError(
            "Unsupported TASK: "
            f"{task!r}. Expected one of ['classification', 'regression', 'speech']."
        )
    return getattr(bj.model, module_name)


def _create_model(module_name: str, task: str):
    try:
        factory = _resolve_model_factory(module_name, task)
        return factory(task=task)
    except Exception as exc:  # pragma: no cover
        pytest.skip(f"无法创建模型实例 bcijelly.model.{module_name}(task={task!r}): {exc!r}")


def _split_model_params(model: Any, params: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    backend = getattr(model, "_backend", None)
    train_func = getattr(backend, "train", model.train)
    test_func = getattr(backend, "test", model.test)
    train_signature = inspect.signature(train_func)
    test_signature = inspect.signature(test_func)
    train_allowed = set(train_signature.parameters)
    test_allowed = set(test_signature.parameters)
    train_kwargs = {key: value for key, value in params.items() if key in train_allowed}
    test_kwargs = {key: value for key, value in params.items() if key in test_allowed}
    return train_kwargs, test_kwargs


def _get_runtime_module_params(
    *,
    module_name: str,
    task: str,
    protocol: str,
    seed: int,
    output_dir: Path,
    run_name: str,
    device: str,
    quick: bool,
) -> dict[str, Any]:
    params = get_module_params(
        module_name=module_name,
        task=task,
        protocol=protocol,
        quick=quick,
    )
    params["seed"] = seed
    params["output_dir"] = str(output_dir)
    params["run_name"] = run_name
    params["device"] = device
    return params


def _merge_datasets(
    first: tuple[np.ndarray, np.ndarray],
    second: tuple[np.ndarray, np.ndarray] | None,
) -> tuple[np.ndarray, np.ndarray]:
    if second is None:
        return first
    first_x, first_y = first
    second_x, second_y = second
    return (
        np.concatenate([first_x, second_x], axis=0),
        np.concatenate([first_y, second_y], axis=0),
    )


def _prepare_train_inputs(
    model: Any,
    train_dataset: tuple[np.ndarray, np.ndarray],
    val_dataset: tuple[np.ndarray, np.ndarray] | None,
    explicit_val_ratio: float,
) -> tuple[tuple[np.ndarray, np.ndarray], dict[str, Any]]:
    backend = getattr(model, "_backend", None)
    train_func = getattr(backend, "train", model.train)
    train_signature = inspect.signature(train_func)
    train_params = train_signature.parameters

    supports_external_val = bool(
        getattr(model, "SUPPORTS_EXTERNAL_VAL", False)
        or "val_dataset" in train_params
        or "val_datapath" in train_params
    )
    supports_train_without_val = bool(getattr(model, "SUPPORTS_TRAIN_WITHOUT_VAL", True))
    auto_split_val_if_missing = bool(getattr(model, "AUTO_SPLIT_VAL_IF_MISSING", False))

    train_dataset_for_fit = train_dataset
    extra_train_kwargs: dict[str, Any] = {}

    if val_dataset is not None:
        if supports_external_val and "val_dataset" in train_params:
            extra_train_kwargs["val_dataset"] = val_dataset
            if "val_ratio" in train_params:
                extra_train_kwargs["val_ratio"] = 0.0
        else:
            warnings.warn(
                f"{model.__name__}.train() 不支持外部 val_dataset，"
                "将把外部 val 合并回 train，并交给模型按自身规则处理。",
                stacklevel=2,
            )
            train_dataset_for_fit = _merge_datasets(train_dataset, val_dataset)
            if "val_ratio" in train_params and explicit_val_ratio > 0.0:
                extra_train_kwargs["val_ratio"] = explicit_val_ratio
    else:
        if not supports_train_without_val:
            if auto_split_val_if_missing:
                warnings.warn(
                    f"{model.__name__}.train() 需要验证集，且当前未提供外部 val_dataset；"
                    "将交给模型内部按 val_ratio 重新切分。",
                    stacklevel=2,
                )
                if "val_ratio" in train_params and explicit_val_ratio > 0.0:
                    extra_train_kwargs["val_ratio"] = explicit_val_ratio
            else:
                raise ValueError(
                    f"{model.__name__}.train() 既不支持无 val 训练，也未声明缺失时自动切分 val。"
                )
        else:
            if "val_ratio" in train_params:
                extra_train_kwargs["val_ratio"] = 0.0

    return train_dataset_for_fit, extra_train_kwargs


def _primary_test_metric(model: Any, task: str) -> str:
    metric_name = getattr(model, "PRIMARY_TEST_METRIC", None)
    if isinstance(metric_name, str) and metric_name:
        return metric_name
    if task == "classification":
        return "acc"
    if task == "speech":
        return "cer"
    return "r2"


def _task_type(model: Any) -> str | None:
    value = getattr(model, "TASK_TYPE", None)
    return value if isinstance(value, str) else None


def _extract_test_metric(test_result: dict[str, Any], metric_name: str) -> float:
    if metric_name not in test_result:
        raise KeyError(f"model.test() 返回结果中缺少指标 {metric_name!r}: {sorted(test_result)}")
    return float(test_result[metric_name])


def _run_module(
    *,
    module_name: str,
    task: str,
    protocol: str,
    train_dataset: tuple[np.ndarray, np.ndarray],
    val_dataset: tuple[np.ndarray, np.ndarray] | None,
    test_dataset: tuple[np.ndarray, np.ndarray],
    test_day_datasets: list[tuple[np.ndarray, np.ndarray]] | None,
    seed: int,
    output_dir: Path,
    run_name: str,
    device: str,
    quick: bool,
    explicit_val_ratio: float,
) -> tuple[float, str, str]:
    model = _create_model(module_name, task)

    declared_task = _task_type(model)
    if declared_task is not None:
        assert declared_task == task, (
            f"模块声明的 TASK_TYPE={declared_task!r}，与测试任务 TASK={task!r} 不一致"
        )

    params = _get_runtime_module_params(
        module_name=module_name,
        task=task,
        protocol=protocol,
        seed=seed,
        output_dir=output_dir,
        run_name=run_name,
        device=device,
        quick=quick,
    )
    train_kwargs, test_kwargs = _split_model_params(model, params)

    train_dataset_for_fit, extra_train_kwargs = _prepare_train_inputs(
        model,
        train_dataset,
        val_dataset,
        explicit_val_ratio=explicit_val_ratio,
    )
    train_kwargs.update(extra_train_kwargs)

    train_result = model.train(train_dataset=train_dataset_for_fit, **train_kwargs)
    assert isinstance(train_result, dict), "model.train() 应返回 dict"

    metric_name = _primary_test_metric(model, task)
    if protocol == "cross_day" and test_day_datasets:
        day_metrics: list[float] = []
        for one_day_test_dataset in test_day_datasets:
            test_result = model.test(test_dataset=one_day_test_dataset, **test_kwargs)
            assert isinstance(test_result, dict), "model.test() 应返回 dict"
            day_metrics.append(_extract_test_metric(test_result, metric_name))
        metric_value = float(np.mean(day_metrics)) if day_metrics else float("nan")
    else:
        test_result = model.test(test_dataset=test_dataset, **test_kwargs)
        assert isinstance(test_result, dict), "model.test() 应返回 dict"
        metric_value = _extract_test_metric(test_result, metric_name)

    run_dir = train_result.get("run_dir") or str(output_dir / run_name)

    
    print()
    print("Train result:")
    print(train_result)
    print("Test result:")
    print(test_result)

    return metric_value, str(run_dir), metric_name


@pytest.fixture(scope="session")
def loaded_result():
    kwargs: dict[str, Any] = {
        "dataset_name": DATASET_NAME,
        "protocol": PROTOCOL,
        "task": TASK,
        "subject_index": SUBJECT_INDEX,
        "day_index": DAY_INDEX,
        "split_ratio": SPLIT_RATIO,
        "auto_download_missing": AUTO_DOWNLOAD_MISSING,
        "verbose": VERBOSE_LOAD_DATA,
    }
    if PROTOCOL == "single_day":
        kwargs["seed"] = SEED
    return bj.load_data(**kwargs)


def test_datasets(loaded_result, tmp_path: Path):
    train_day = loaded_result.job.train_day if loaded_result.job else "unknown_train"
    test_day = loaded_result.job.test_day if loaded_result.job else "unknown_test"
    subject_name = loaded_result.job.subject_name if loaded_result.job else None
    subject_prefix = f"{subject_name}__" if subject_name else ""

    run_name = (
        f"{DATASET_NAME}__{subject_prefix}{PROTOCOL}__{MODULE_NAME}__{TASK}__seed{SEED}"
        f"__train-{train_day}__test-{test_day}"
    )

    metric_value, run_dir, metric_name = _run_module(
        module_name=MODULE_NAME,
        task=TASK,
        protocol=PROTOCOL,
        train_dataset=loaded_result.train_dataset,
        val_dataset=loaded_result.val_dataset,
        test_dataset=loaded_result.test_dataset,
        test_day_datasets=loaded_result.test_day_datasets,
        seed=SEED,
        output_dir=tmp_path,
        run_name=run_name,
        device=DEVICE,
        quick=QUICK,
        explicit_val_ratio=_model_internal_val_ratio(SPLIT_RATIO),
    )

    assert np.isfinite(metric_value), f"{metric_name} 不是有限数: {metric_value}"
    if metric_name == "acc":
        assert 0.0 <= metric_value <= 1.0, f"accuracy 超出范围: {metric_value}"
    assert isinstance(run_dir, str) and run_dir.strip(), "run_dir 应为非空字符串"

    summary_bits = [
        f"dataset={DATASET_NAME}",
        f"protocol={PROTOCOL}",
        f"module={MODULE_NAME}",
        f"task={TASK}",
        f"subject_index={SUBJECT_INDEX}",
    ]
    if subject_name:
        summary_bits.append(f"subject_name={subject_name}")
    if PROTOCOL == "single_day":
        summary_bits.append(f"day_index={DAY_INDEX}")
    summary_bits.append(f"{metric_name}={metric_value:.4f}")
    summary_bits.append(f"run_dir={run_dir}")
    print("\n" + " | ".join(summary_bits))
