from __future__ import annotations

from pathlib import Path

from bcijelly.dataset._discovery import _detect_root_storage_format
from bcijelly.dataset._types import DATASET_FORMAT_SPLIT_FILES


def _touch(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(b"")


def test_detect_split_files_from_suffix_with_extra_npz(tmp_path: Path) -> None:
    dataset_root = tmp_path / "11_Speech"
    _touch(dataset_root / "Speech_Train.npz")
    _touch(dataset_root / "Speech_Test.npz")
    _touch(dataset_root / "data_SpeechBCI_preprocessed.npz")

    structure = _detect_root_storage_format("11_Speech", dataset_root)
    assert structure.storage_format == DATASET_FORMAT_SPLIT_FILES
    assert structure.train_file is not None and structure.train_file.name == "Speech_Train.npz"
    assert structure.test_file is not None and structure.test_file.name == "Speech_Test.npz"
    assert structure.val_file is None


def test_detect_train_val_test_from_suffix(tmp_path: Path) -> None:
    dataset_root = tmp_path / "demo"
    _touch(dataset_root / "sample_train.npz")
    _touch(dataset_root / "sample_val.npz")
    _touch(dataset_root / "sample_test.npz")

    structure = _detect_root_storage_format("demo", dataset_root)
    assert structure.storage_format == DATASET_FORMAT_SPLIT_FILES
    assert structure.train_file is not None and structure.train_file.name == "sample_train.npz"
    assert structure.val_file is not None and structure.val_file.name == "sample_val.npz"
    assert structure.test_file is not None and structure.test_file.name == "sample_test.npz"
