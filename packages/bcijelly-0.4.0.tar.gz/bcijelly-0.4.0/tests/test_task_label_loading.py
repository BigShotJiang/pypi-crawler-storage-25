from __future__ import annotations

import numpy as np
import pytest

from bcijelly.dataset._io import load_speech_npz, load_task_npz
from bcijelly.dataset._loading import load_data


def _save_npz(path, *, label_key: str) -> None:
    x = np.random.randn(8, 16, 4).astype(np.float32)
    if label_key == "regression_target":
        y = np.random.randn(8, 16, 2).astype(np.float32)
    else:
        y = np.arange(8, dtype=np.int64)
    np.savez(path, neural_activity=x, **{label_key: y})


def test_load_task_npz_regression_key(tmp_path) -> None:
    npz_path = tmp_path / "regression.npz"
    _save_npz(npz_path, label_key="regression_target")

    x, y, key = load_task_npz(npz_path, task="regression")
    assert x.shape[0] == y.shape[0] == 8
    assert key == "regression_target"


def test_load_task_npz_speech_key(tmp_path) -> None:
    npz_path = tmp_path / "speech.npz"
    _save_npz(npz_path, label_key="speech_label")

    x, y, key = load_task_npz(npz_path, task="speech")
    assert x.shape[0] == y.shape[0] == 8
    assert key == "speech_label"


def test_load_speech_npz_returns_five_tuple(tmp_path) -> None:
    npz_path = tmp_path / "speech_seq.npz"
    x = np.random.randn(8, 16, 4).astype(np.float32)
    y = np.random.randint(0, 10, size=(8, 7), dtype=np.int32)
    x_len = np.full((8,), 16, dtype=np.int32)
    y_len = np.full((8,), 7, dtype=np.int32)
    day_idx = np.zeros((8,), dtype=np.int64)
    np.savez(
        npz_path,
        neural_activity=x,
        speech_label=y,
        X_len=x_len,
        y_len=y_len,
        dayIdx=day_idx,
    )

    loaded_x, loaded_y, loaded_x_len, loaded_y_len, loaded_day_idx, key = load_speech_npz(npz_path)
    assert loaded_x.shape == x.shape
    assert loaded_y.shape == y.shape
    assert loaded_x_len.shape == (8,)
    assert loaded_y_len.shape == (8,)
    assert loaded_day_idx.shape == (8,)
    assert key == "speech_label"


def test_load_speech_npz_defaults_missing_dayidx_to_zero(tmp_path) -> None:
    npz_path = tmp_path / "speech_seq_no_dayidx.npz"
    x = np.random.randn(4, 10, 3).astype(np.float32)
    y = np.random.randint(0, 5, size=(4, 6), dtype=np.int32)
    x_len = np.full((4, 1), 10, dtype=np.int32)
    y_len = np.full((4, 1), 6, dtype=np.int32)
    np.savez(npz_path, neural_activity=x, speech_label=y, X_len=x_len, y_len=y_len)

    _, _, _, _, loaded_day_idx, _ = load_speech_npz(npz_path)
    assert np.array_equal(loaded_day_idx, np.zeros((4,), dtype=np.int64))


def test_load_data_speech_split_files_returns_five_tuple() -> None:
    loaded = load_data(
        dataset_name="11_Speech",
        protocol="train-test",
        task="speech",
        subject_index=0,
        day_index=0,
        split_ratio="8:2",
        seed=42,
        verbose=False,
    )

    assert len(loaded.train_dataset) == 5
    assert len(loaded.test_dataset) == 5
    train_x, train_y, train_x_len, train_y_len, train_day_idx = loaded.train_dataset
    test_x, test_y, test_x_len, test_y_len, test_day_idx = loaded.test_dataset
    assert train_x.shape[0] == train_y.shape[0] == train_x_len.shape[0] == train_y_len.shape[0] == train_day_idx.shape[0]
    assert test_x.shape[0] == test_y.shape[0] == test_x_len.shape[0] == test_y_len.shape[0] == test_day_idx.shape[0]
    assert loaded.requested_task == "speech"


def test_load_data_speech_train_test_three_part_split_ratio_splits_train_val() -> None:
    base_loaded = load_data(
        dataset_name="11_Speech",
        protocol="train-test",
        task="speech",
        subject_index=0,
        day_index=0,
        split_ratio="8:2",
        seed=42,
        verbose=False,
    )

    with pytest.warns(UserWarning, match="explicit test data cannot be repartitioned"):
        loaded = load_data(
            dataset_name="11_Speech",
            protocol="train-test",
            task="speech",
            subject_index=0,
            day_index=0,
            split_ratio="7:1:2",
            seed=42,
            verbose=False,
        )

    assert loaded.val_dataset is not None
    assert len(loaded.train_dataset) == 5
    assert len(loaded.val_dataset) == 5
    assert len(loaded.test_dataset) == 5
    assert loaded.train_dataset[0].shape[0] + loaded.val_dataset[0].shape[0] == base_loaded.train_dataset[0].shape[0]
    assert loaded.test_dataset[0].shape[0] == base_loaded.test_dataset[0].shape[0]


def test_load_data_rejects_unsupported_task_early() -> None:
    with pytest.raises(ValueError, match="Unsupported task"):
        load_data(dataset_name="11_Speech", protocol="single_day", task="unknown_task")
