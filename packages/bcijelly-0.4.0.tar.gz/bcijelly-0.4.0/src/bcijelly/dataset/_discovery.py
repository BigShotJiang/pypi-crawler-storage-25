from __future__ import annotations

import json
import math
import warnings
from pathlib import Path
from typing import Any, Iterable

import numpy as np

from ._types import (
    DATASET_COMPATIBILITY_FILENAMES,
    DATASET_FORMAT_DAY_FILES,
    DATASET_FORMAT_MULTI_SUBJECT,
    DATASET_FORMAT_SINGLE_FILE,
    DATASET_FORMAT_SPLIT_FILES,
    DATASET_FORMAT_VIRTUAL_SESSIONS,
    DEFAULT_DATA_DIR,
    DEFAULT_HF_REPO_ID,
    DEFAULT_HF_REPO_TYPE,
    DataLoadResult,
    DatasetJob,
    DatasetStructure,
    DayRef,
    day_ref_label,
    day_ref_name,
    ensure_dataset_available,
    make_virtual_day_ref,
)
from ._io import allocate_split_counts

_SINGLE_DAY_COMPAT_DECLARED_PROTOCOLS = {"train-test", "train-val-test"}


def _find_split_file_by_role(npz_files: list[Path], role: str) -> Path | None:
    role = role.lower().strip()

    exact_name = f"{role}.npz"
    exact_matches = [path for path in npz_files if path.name.lower() == exact_name]
    if len(exact_matches) == 1:
        return exact_matches[0]
    if len(exact_matches) > 1:
        raise ValueError(f"Ambiguous split files for role '{role}': {[p.name for p in exact_matches]}")

    suffix_candidates = (f"_{role}", f"-{role}")
    suffix_matches = [
        path
        for path in npz_files
        if any(path.stem.lower().endswith(suffix) for suffix in suffix_candidates)
    ]
    if len(suffix_matches) == 1:
        return suffix_matches[0]
    if len(suffix_matches) > 1:
        raise ValueError(f"Ambiguous split files for role '{role}': {[p.name for p in suffix_matches]}")

    return None


def _print_dataset_summary(
    structure: DatasetStructure,
    *,
    selected_subject_index: int | None = None,
    selected_subject_name: str | None = None,
    verbose: bool = False,
) -> None:
    print("[load_data] dataset:", structure.dataset_name)
    print("[load_data] dataset_root:", structure.dataset_root)
    print("[load_data] dataset_format:", structure.storage_format)
    if structure.storage_format == DATASET_FORMAT_MULTI_SUBJECT:
        print(f"[load_data] subject_count: {len(structure.subject_names)}")
        for idx, (name, path) in enumerate(zip(structure.subject_names, structure.subject_paths)):
            npz_count = len(sorted(path.rglob("*.npz")))
            if verbose:
                print(f"[load_data]   subject[{idx}] = {name} | npz_count={npz_count}")
        if selected_subject_index is not None and selected_subject_name is not None:
            print(
                f"[load_data] selected_subject: index={selected_subject_index}, name={selected_subject_name}"
            )
    else:
        npz_count = 0
        if structure.storage_format == DATASET_FORMAT_SPLIT_FILES:
            npz_count = (
                int(structure.train_file is not None)
                + int(structure.val_file is not None)
                + int(structure.test_file is not None)
            )
        else:
            npz_count = len(structure.files)
        print("[load_data] subject_count: 1")
        print(f"[load_data]   subject[0] = <anonymous> | npz_count={npz_count}")
        if selected_subject_index is not None:
            print("[load_data] selected_subject: index=0, name=<anonymous>")


def _print_job_summary(
    job: DatasetJob,
    result: DataLoadResult,
    *,
    verbose: bool = False,
) -> None:
    subject_prefix = ""
    if job.subject_name is not None and job.subject_index is not None:
        subject_prefix = f"subject[{job.subject_index}]={job.subject_name} | "

    if job.protocol == "single_day":
        if result.val_dataset is None:
            val_count = 0
        else:
            val_count = int(result.val_dataset[0].shape[0])
        print(
            "[load_data] single_day | "
            f"{subject_prefix}day_index={job.day_index} | day={job.train_day} | "
            f"train={result.train_dataset[0].shape[0]} | val={val_count} | test={result.test_dataset[0].shape[0]}"
        )
        if verbose:
            print(f"[load_data] single_day file: {day_ref_label(job.train_path)}")
    else:
        train_day_count = len(job.train_paths or [])
        val_day_count = len(job.val_paths or [])
        test_day_count = len(job.test_paths or [])
        print(
            "[load_data] cross_day | "
            f"{subject_prefix}train_days={train_day_count} | val_days={val_day_count} | test_days={test_day_count}"
        )
        if verbose:
            print("[load_data] train_files:")
            for path in job.train_paths or []:
                print("[load_data]   -", day_ref_label(path))
            print("[load_data] val_files:")
            for path in job.val_paths or []:
                print("[load_data]   -", day_ref_label(path))
            print("[load_data] test_files:")
            for path in job.test_paths or []:
                print("[load_data]   -", day_ref_label(path))


def _visual_grating_session_mmdd(day_ref: Any) -> int:
    name = day_ref_name(day_ref)
    parts = name.split("-")
    if len(parts) < 3:
        raise ValueError(f"Unexpected visual grating session name: {name}")
    suffix = parts[-1].removesuffix(".mat")
    return int(suffix)


def _build_visual_grating_cross_day_job(
    dataset_name: str,
    files: list[DayRef],
    *,
    subject_name: str | None = None,
    subject_index: int | None = None,
) -> DatasetJob:
    filtered = [path for path in files if _visual_grating_session_mmdd(path) < 1000]
    if len(filtered) < 3:
        raise ValueError(
            f"{dataset_name} cross_day requires at least 3 same-subject sessions "
            f"after excluding ECoG-1 sessions, got {len(filtered)}"
        )

    sorted_files = sorted(filtered, key=_visual_grating_session_mmdd)
    val_files = [path for path in sorted_files if _visual_grating_session_mmdd(path) == 805]
    test_files = [path for path in sorted_files if _visual_grating_session_mmdd(path) == 806]
    train_files = [
        path for path in sorted_files if _visual_grating_session_mmdd(path) not in {805, 806}
    ]

    if not train_files or not val_files or not test_files:
        raise ValueError(
            f"{dataset_name} cross_day expected train/val/test sessions with 0805 as val and 0806 as test."
        )

    return DatasetJob(
        protocol="cross_day",
        dataset=dataset_name,
        train_paths=train_files,
        val_paths=val_files,
        test_paths=test_files,
        train_path=train_files[0],
        test_path=test_files[0],
        train_day=f"{day_ref_name(train_files[0])}__to__{day_ref_name(train_files[-1])}",
        val_day=f"{day_ref_name(val_files[0])}__to__{day_ref_name(val_files[-1])}",
        test_day=f"{day_ref_name(test_files[0])}__to__{day_ref_name(test_files[-1])}",
        dataset_format=DATASET_FORMAT_VIRTUAL_SESSIONS,
        subject_name=subject_name,
        subject_index=subject_index,
    )


def _sorted_directories(path: Path) -> list[Path]:
    return sorted(child for child in path.iterdir() if child.is_dir())


def _sorted_npz_files(path: Path) -> list[Path]:
    return sorted(child for child in path.glob("*.npz"))


def _detect_root_storage_format(dataset_name: str, dataset_root: Path) -> DatasetStructure:
    direct_npz = _sorted_npz_files(dataset_root)
    direct_dirs = _sorted_directories(dataset_root)

    if dataset_name == "10_VisualGratingTask":
        if not direct_npz:
            raise FileNotFoundError(f"Dataset '{dataset_name}' exists but no .npz files were found in {dataset_root}")
        master_path = direct_npz[0]
        with np.load(master_path, allow_pickle=True) as data:
            if "file_info" not in data.files:
                raise KeyError(
                    f"{master_path} must contain file_info to be expanded into virtual sessions."
                )
            session_names = sorted(str(x) for x in np.unique(np.asarray(data["file_info"])))
        files: list[DayRef] = [make_virtual_day_ref(master_path, session_name) for session_name in session_names]
        return DatasetStructure(
            dataset_name=dataset_name,
            dataset_root=dataset_root,
            storage_format=DATASET_FORMAT_VIRTUAL_SESSIONS,
            files=files,
        )

    if direct_dirs and direct_npz:
        raise ValueError(
            f"Dataset '{dataset_name}' has mixed root structure under {dataset_root}: "
            "both subject subdirectories and root-level .npz files were found."
        )

    if direct_dirs:
        subject_names: list[str] = []
        subject_paths: list[Path] = []
        for subject_dir in direct_dirs:
            if any(subject_dir.glob("*.npz")):
                subject_names.append(subject_dir.name)
                subject_paths.append(subject_dir)
        if not subject_paths:
            raise FileNotFoundError(
                f"Dataset '{dataset_name}' has subdirectories but none of them contains .npz files: {dataset_root}"
            )
        return DatasetStructure(
            dataset_name=dataset_name,
            dataset_root=dataset_root,
            storage_format=DATASET_FORMAT_MULTI_SUBJECT,
            subject_names=subject_names,
            subject_paths=subject_paths,
        )

    if not direct_npz:
        raise FileNotFoundError(f"Dataset '{dataset_name}' exists but no .npz files were found in {dataset_root}")

    train_split = _find_split_file_by_role(direct_npz, "train")
    test_split = _find_split_file_by_role(direct_npz, "test")
    val_split = _find_split_file_by_role(direct_npz, "val")

    if train_split is not None and test_split is not None:
        return DatasetStructure(
            dataset_name=dataset_name,
            dataset_root=dataset_root,
            storage_format=DATASET_FORMAT_SPLIT_FILES,
            train_file=train_split,
            val_file=val_split,
            test_file=test_split,
        )

    if len(direct_npz) == 1:
        return DatasetStructure(
            dataset_name=dataset_name,
            dataset_root=dataset_root,
            storage_format=DATASET_FORMAT_SINGLE_FILE,
            files=direct_npz,
        )

    return DatasetStructure(
        dataset_name=dataset_name,
        dataset_root=dataset_root,
        storage_format=DATASET_FORMAT_DAY_FILES,
        files=direct_npz,
    )


def discover_dataset_structure(
    dataset_name: str,
    *,
    data_dir: Path | None = None,
    auto_download_missing: bool = True,
    repo_id: str = DEFAULT_HF_REPO_ID,
    repo_type: str = DEFAULT_HF_REPO_TYPE,
) -> DatasetStructure:
    root = data_dir or DEFAULT_DATA_DIR
    dataset_root = ensure_dataset_available(
        dataset_name,
        data_dir=root,
        auto_download=auto_download_missing,
        repo_id=repo_id,
        repo_type=repo_type,
    )
    return _detect_root_storage_format(dataset_name, dataset_root)


def _normalize_string_list(field_name: str, value: Any, source_path: Path) -> list[str] | None:
    if value is None:
        return None
    if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
        raise ValueError(
            f"Invalid field '{field_name}' in {source_path}: expected a list of strings, got {type(value).__name__}."
        )
    return value


def _load_dataset_compatibility(dataset_root: Path) -> tuple[dict[str, Any], Path] | None:
    for filename in DATASET_COMPATIBILITY_FILENAMES:
        compatibility_path = dataset_root / filename
        if not compatibility_path.exists():
            continue
        with compatibility_path.open("r", encoding="utf-8") as fp:
            payload = json.load(fp)
        if not isinstance(payload, dict):
            raise ValueError(
                f"Invalid dataset compatibility file {compatibility_path}: top-level JSON value must be an object."
            )
        return payload, compatibility_path
    return None


def _validate_dataset_compatibility(
    *,
    dataset_name: str,
    dataset_root: Path,
    protocol: str,
    task: str | None,
) -> None:
    compatibility_loaded = _load_dataset_compatibility(dataset_root)
    if compatibility_loaded is None:
        return

    payload, source_path = compatibility_loaded
    declared_protocols = _normalize_string_list("protocols", payload.get("protocols"), source_path)
    declared_tasks = _normalize_string_list("tasks", payload.get("tasks"), source_path)

    protocol_match = False
    if not declared_protocols:
        protocol_match = True
    elif protocol in declared_protocols:
        protocol_match = True
    elif protocol == "single_day" and any(
        declared in _SINGLE_DAY_COMPAT_DECLARED_PROTOCOLS for declared in declared_protocols
    ):
        protocol_match = True

    if not protocol_match:
        raise ValueError(
            "Dataset capability mismatch: "
            f"dataset='{dataset_name}', requested protocol='{protocol}', "
            f"declared protocols={declared_protocols}."
        )

    if task is not None and declared_tasks and task not in declared_tasks:
        raise ValueError(
            "Dataset capability mismatch: "
            f"dataset='{dataset_name}', requested task='{task}', "
            f"declared tasks={declared_tasks}."
        )


def _resolve_subject_structure(
    root_structure: DatasetStructure,
    *,
    subject_index: int = 0,
    fallback_to_first_subject: bool = False,
) -> tuple[DatasetStructure, int | None, str | None]:
    if root_structure.storage_format != DATASET_FORMAT_MULTI_SUBJECT:
        if subject_index != 0:
            message = (
                f"Dataset '{root_structure.dataset_name}' does not have subject subdirectories, "
                f"so only subject_index=0 is valid. Got subject_index={subject_index}."
            )
            if not fallback_to_first_subject:
                raise IndexError(message)
            warnings.warn(message + " Falling back to subject_index=0.", stacklevel=2)
        return root_structure, 0, None

    if not root_structure.subject_paths:
        raise FileNotFoundError(f"Dataset '{root_structure.dataset_name}' has no usable subject folders.")

    if subject_index < 0 or subject_index >= len(root_structure.subject_paths):
        message = (
            f"subject_index={subject_index} is out of range for dataset '{root_structure.dataset_name}'. "
            f"Available subjects: {list(enumerate(root_structure.subject_names))}"
        )
        if not fallback_to_first_subject:
            raise IndexError(message)
        warnings.warn(message + " Falling back to subject_index=0.", stacklevel=2)
        subject_index = 0

    subject_path = root_structure.subject_paths[subject_index]
    subject_name = root_structure.subject_names[subject_index]
    selected_structure = _detect_root_storage_format(root_structure.dataset_name, subject_path)
    return selected_structure, subject_index, subject_name


def discover_dataset(
    dataset_name: str,
    *,
    data_dir: Path | None = None,
    max_days_per_dataset: int | None = None,
    auto_download_missing: bool = True,
    repo_id: str = DEFAULT_HF_REPO_ID,
    repo_type: str = DEFAULT_HF_REPO_TYPE,
    subject_index: int = 0,
    fallback_to_first_subject: bool = False,
) -> list[DayRef]:
    structure = discover_dataset_structure(
        dataset_name,
        data_dir=data_dir,
        auto_download_missing=auto_download_missing,
        repo_id=repo_id,
        repo_type=repo_type,
    )
    selected_structure, _, _ = _resolve_subject_structure(
        structure,
        subject_index=subject_index,
        fallback_to_first_subject=fallback_to_first_subject,
    )

    files = list(selected_structure.files)
    if max_days_per_dataset is not None:
        files = files[:max_days_per_dataset]
    if not files and selected_structure.storage_format in {DATASET_FORMAT_DAY_FILES, DATASET_FORMAT_SINGLE_FILE, DATASET_FORMAT_VIRTUAL_SESSIONS}:
        raise FileNotFoundError(
            f"Dataset '{dataset_name}' exists but no usable .npz files were found in {selected_structure.dataset_root}"
        )
    return files


def discover_datasets(
    dataset_names: Iterable[str],
    *,
    data_dir: Path | None = None,
    max_days_per_dataset: int | None = None,
    auto_download_missing: bool = True,
    repo_id: str = DEFAULT_HF_REPO_ID,
    repo_type: str = DEFAULT_HF_REPO_TYPE,
    subject_index: int = 0,
    fallback_to_first_subject: bool = False,
) -> dict[str, list[DayRef]]:
    result: dict[str, list[DayRef]] = {}
    for dataset_name in dataset_names:
        result[dataset_name] = discover_dataset(
            dataset_name,
            data_dir=data_dir,
            max_days_per_dataset=max_days_per_dataset,
            auto_download_missing=auto_download_missing,
            repo_id=repo_id,
            repo_type=repo_type,
            subject_index=subject_index,
            fallback_to_first_subject=fallback_to_first_subject,
        )
    return result


def get_declared_protocols(dataset_root: Path) -> set[str] | None:
    compatibility_loaded = _load_dataset_compatibility(dataset_root)
    if compatibility_loaded is None:
        return None
    payload, source_path = compatibility_loaded
    declared_protocols = _normalize_string_list("protocols", payload.get("protocols"), source_path)
    if not declared_protocols:
        return set()
    return set(declared_protocols)


def build_jobs(
    dataset_name: str,
    files: list[DayRef],
    protocols: Iterable[str],
    *,
    dataset_format: str = DATASET_FORMAT_DAY_FILES,
    subject_name: str | None = None,
    subject_index: int | None = None,
    split_parts: tuple[int, ...] = (7, 1, 2),
) -> list[DatasetJob]:
    protocol_set = set(protocols)
    jobs: list[DatasetJob] = []

    if "single_day" in protocol_set:
        for day_index, path in enumerate(files):
            jobs.append(
                DatasetJob(
                    protocol="single_day",
                    dataset=dataset_name,
                    train_path=path,
                    test_path=path,
                    train_day=day_ref_name(path),
                    test_day=day_ref_name(path),
                    dataset_format=dataset_format,
                    subject_name=subject_name,
                    subject_index=subject_index,
                    day_index=day_index,
                )
            )

    if "cross_day" in protocol_set:
        if dataset_format in {DATASET_FORMAT_SINGLE_FILE, DATASET_FORMAT_SPLIT_FILES}:
            raise ValueError(
                f"Dataset '{dataset_name}' uses format '{dataset_format}', which only supports protocol='single_day'."
            )

        if dataset_name == "10_VisualGratingTask":
            warnings.warn(
                "10_VisualGratingTask uses a fixed cross_day split strategy "
                "(val=0805, test=0806); provided split_ratio/split_parts is ignored.",
                stacklevel=2,
            )
            jobs.append(
                _build_visual_grating_cross_day_job(
                    dataset_name,
                    files,
                    subject_name=subject_name,
                    subject_index=subject_index,
                )
            )
            return jobs

        train_count, val_count, test_count = allocate_split_counts(len(files), split_parts)

        train_files = files[:train_count]
        val_files = files[train_count : train_count + val_count]
        test_files = files[train_count + val_count :]

        jobs.append(
            DatasetJob(
                protocol="cross_day",
                dataset=dataset_name,
                train_paths=train_files,
                val_paths=val_files,
                test_paths=test_files,
                train_path=train_files[0],
                test_path=test_files[0],
                train_day=f"{day_ref_name(train_files[0])}__to__{day_ref_name(train_files[-1])}",
                val_day=(
                    f"{day_ref_name(val_files[0])}__to__{day_ref_name(val_files[-1])}"
                    if val_files
                    else ""
                ),
                test_day=f"{day_ref_name(test_files[0])}__to__{day_ref_name(test_files[-1])}",
                dataset_format=dataset_format,
                subject_name=subject_name,
                subject_index=subject_index,
            )
        )

    return jobs
