# bcijelly 0.3.0

bcijelly is a toolkit for invasive BCI data loading and baseline modeling workflows.

0.4.0 updates:

- supporting speech

0.3.0 updates:

- model APIs

- singleday seed optional



## Language README

- [English README](README_EN.md)
- [中文 README](README_CN.md)

## Core docs

- [load_data Guide (English)](docs/load-data-guide.en.md)
- [load_data 指南（中文）](docs/load-data-guide.zh-CN.md)
