"""Tests for config module — load/save/validate."""

import json
import os
import pytest

from dke_forge import config


class TestConfigLoadSave:
    def test_load_missing_file(self, tmp_path, monkeypatch):
        monkeypatch.setattr(config, "CONFIG_FILE", str(tmp_path / "nope.json"))
        assert config.load() == {}

    def test_save_and_load(self, tmp_path, monkeypatch):
        monkeypatch.setattr(config, "CONFIG_DIR", str(tmp_path))
        monkeypatch.setattr(config, "CONFIG_FILE", str(tmp_path / "cfg.json"))
        config.set_value("url", "http://localhost:8420")
        loaded = config.load()
        assert loaded["url"] == "http://localhost:8420"

    def test_set_multiple_keys(self, tmp_path, monkeypatch):
        monkeypatch.setattr(config, "CONFIG_DIR", str(tmp_path))
        monkeypatch.setattr(config, "CONFIG_FILE", str(tmp_path / "cfg.json"))
        config.set_value("url", "http://localhost:8420")
        config.set_value("api_key", "fga_test")
        loaded = config.load()
        assert loaded["url"] == "http://localhost:8420"
        assert loaded["api_key"] == "fga_test"

    def test_overwrite_key(self, tmp_path, monkeypatch):
        monkeypatch.setattr(config, "CONFIG_DIR", str(tmp_path))
        monkeypatch.setattr(config, "CONFIG_FILE", str(tmp_path / "cfg.json"))
        config.set_value("api_key", "old")
        config.set_value("api_key", "new")
        assert config.get("api_key") == "new"


class TestConfigValidation:
    def test_invalid_key_rejected(self, tmp_path, monkeypatch):
        monkeypatch.setattr(config, "CONFIG_DIR", str(tmp_path))
        monkeypatch.setattr(config, "CONFIG_FILE", str(tmp_path / "cfg.json"))
        with pytest.raises(ValueError, match="Unknown config key"):
            config.set_value("bogus", "value")

    def test_all_valid_keys_accepted(self, tmp_path, monkeypatch):
        monkeypatch.setattr(config, "CONFIG_DIR", str(tmp_path))
        monkeypatch.setattr(config, "CONFIG_FILE", str(tmp_path / "cfg.json"))
        for key in config.VALID_KEYS:
            config.set_value(key, "test")
        loaded = config.load()
        assert len(loaded) == len(config.VALID_KEYS)


class TestConfigPermissions:
    def test_file_is_600(self, tmp_path, monkeypatch):
        cfg_file = tmp_path / "cfg.json"
        monkeypatch.setattr(config, "CONFIG_DIR", str(tmp_path))
        monkeypatch.setattr(config, "CONFIG_FILE", str(cfg_file))
        config.set_value("api_key", "fga_secret")
        mode = oct(cfg_file.stat().st_mode & 0o777)
        assert mode == "0o600"


class TestConfigGet:
    def test_get_existing(self, tmp_path, monkeypatch):
        monkeypatch.setattr(config, "CONFIG_DIR", str(tmp_path))
        monkeypatch.setattr(config, "CONFIG_FILE", str(tmp_path / "cfg.json"))
        config.set_value("url", "http://test")
        assert config.get("url") == "http://test"

    def test_get_missing_returns_none(self, tmp_path, monkeypatch):
        monkeypatch.setattr(config, "CONFIG_FILE", str(tmp_path / "nope.json"))
        assert config.get("url") is None
