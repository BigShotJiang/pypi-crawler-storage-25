"""Tests for the FastMCP server — one-per-tool dispatch assertions.

Mirrors the mocking style in ``test_client.py``, but one level higher:
here we mock the ``ForgeClient`` instance directly (not the underlying
``requests.request``) and assert each ``@mcp.tool()`` function delegates
to the right client method with the right args.

If the ``mcp`` Python SDK is not installed (only ``.[dev]`` was used),
this module is skipped cleanly — it is gated behind
``pytest.importorskip("mcp")``.
"""

import asyncio

import pytest
from unittest.mock import MagicMock, patch

pytest.importorskip("mcp")

from dke_forge import mcp as forge_mcp  # noqa: E402


def _run(coro):
    return asyncio.run(coro)


@pytest.fixture
def mock_client():
    client = MagicMock()
    with patch.object(forge_mcp, "_client", client):
        yield client


# -- Foundation ----------------------------------------------------------

class TestFoundation:
    def test_forge_graph_stats(self, mock_client):
        mock_client.graph_stats.return_value = {"nodes": 1, "edges": 0}
        result = _run(forge_mcp.forge_graph_stats())
        mock_client.graph_stats.assert_called_once_with()
        assert result == {"nodes": 1, "edges": 0}


# -- Navigation ----------------------------------------------------------

class TestNavigation:
    def test_forge_query_function(self, mock_client):
        mock_client.graph_function.return_value = {}
        _run(forge_mcp.forge_query_function("foo"))
        mock_client.graph_function.assert_called_once_with("foo", None, None)

    def test_forge_callers_of_default_depth(self, mock_client):
        mock_client.graph_callers.return_value = {}
        _run(forge_mcp.forge_callers_of("foo"))
        mock_client.graph_callers.assert_called_once_with("foo", 2, None, None)

    def test_forge_callers_of_explicit_depth(self, mock_client):
        mock_client.graph_callers.return_value = {}
        _run(forge_mcp.forge_callers_of("foo", depth=5))
        mock_client.graph_callers.assert_called_once_with("foo", 5, None, None)

    def test_forge_callees_of(self, mock_client):
        mock_client.graph_callees.return_value = {}
        _run(forge_mcp.forge_callees_of("foo", depth=3))
        mock_client.graph_callees.assert_called_once_with("foo", 3, None, None)

    def test_forge_depends_on(self, mock_client):
        mock_client.graph_depends.return_value = {}
        _run(forge_mcp.forge_depends_on("src/a.cpp"))
        mock_client.graph_depends.assert_called_once_with("src/a.cpp")

    def test_forge_impact_analysis_default(self, mock_client):
        mock_client.graph_impact.return_value = {}
        _run(forge_mcp.forge_impact_analysis("foo"))
        mock_client.graph_impact.assert_called_once_with("foo", "modify", None, None)

    def test_forge_impact_analysis_rename(self, mock_client):
        mock_client.graph_impact.return_value = {}
        _run(forge_mcp.forge_impact_analysis("foo", change_type="rename"))
        mock_client.graph_impact.assert_called_once_with("foo", "rename", None, None)

    # -- FG-SUBSTRATE-MULTI-DEF-POLICY Slice 4: branch + file qualifiers --

    def test_forge_query_function_with_branch(self, mock_client):
        mock_client.graph_function.return_value = {}
        _run(forge_mcp.forge_query_function("foo", branch="4c373c25a9e2b1f8"))
        mock_client.graph_function.assert_called_once_with(
            "foo", "4c373c25a9e2b1f8", None)

    def test_forge_query_function_with_file_qualifier(self, mock_client):
        mock_client.graph_function.return_value = {}
        _run(forge_mcp.forge_query_function("foo", file="src/foo.c"))
        mock_client.graph_function.assert_called_once_with(
            "foo", None, "src/foo.c")

    def test_forge_callers_of_with_branch(self, mock_client):
        mock_client.graph_callers.return_value = {}
        _run(forge_mcp.forge_callers_of("foo", depth=3, branch="aabbccdd00112233"))
        mock_client.graph_callers.assert_called_once_with(
            "foo", 3, "aabbccdd00112233", None)

    def test_forge_callees_of_with_branch(self, mock_client):
        mock_client.graph_callees.return_value = {}
        _run(forge_mcp.forge_callees_of("foo", branch="aabbccdd00112233"))
        mock_client.graph_callees.assert_called_once_with(
            "foo", 2, "aabbccdd00112233", None)

    def test_forge_impact_analysis_with_branch(self, mock_client):
        mock_client.graph_impact.return_value = {}
        _run(forge_mcp.forge_impact_analysis(
            "foo", change_type="rename", branch="deadbeefcafef00d"))
        mock_client.graph_impact.assert_called_once_with(
            "foo", "rename", "deadbeefcafef00d", None)

    def test_forge_callgraph_reachable_no_via(self, mock_client):
        mock_client.graph_reachable.return_value = []
        _run(forge_mcp.forge_callgraph_reachable("entry"))
        mock_client.graph_reachable.assert_called_once_with("entry", None)

    def test_forge_callgraph_reachable_with_via(self, mock_client):
        mock_client.graph_reachable.return_value = []
        _run(forge_mcp.forge_callgraph_reachable("entry", via="Implements"))
        mock_client.graph_reachable.assert_called_once_with("entry", "Implements")

    def test_forge_find_implementers(self, mock_client):
        mock_client.graph_implementers.return_value = []
        _run(forge_mcp.forge_find_implementers("Base"))
        mock_client.graph_implementers.assert_called_once_with("Base")


# -- Architecture --------------------------------------------------------

class TestArchitecture:
    def test_forge_dead_code_default(self, mock_client):
        mock_client.graph_dead_code.return_value = []
        _run(forge_mcp.forge_dead_code())
        mock_client.graph_dead_code.assert_called_once_with(True)

    def test_forge_dead_code_include_tests(self, mock_client):
        mock_client.graph_dead_code.return_value = []
        _run(forge_mcp.forge_dead_code(exclude_tests=False))
        mock_client.graph_dead_code.assert_called_once_with(False)

    def test_forge_subgraph_module(self, mock_client):
        mock_client.graph_subgraph.return_value = {}
        _run(forge_mcp.forge_subgraph(module="render"))
        mock_client.graph_subgraph.assert_called_once_with(module="render")

    def test_forge_subgraph_functions_list(self, mock_client):
        mock_client.graph_subgraph.return_value = {}
        _run(forge_mcp.forge_subgraph(functions=["a", "b"], max_depth=0))
        mock_client.graph_subgraph.assert_called_once_with(
            functions=["a", "b"], max_depth=0
        )

    def test_forge_subgraph_no_args(self, mock_client):
        mock_client.graph_subgraph.return_value = {}
        _run(forge_mcp.forge_subgraph())
        mock_client.graph_subgraph.assert_called_once_with()


# -- Rules ---------------------------------------------------------------

class TestRules:
    def test_forge_rules(self, mock_client):
        mock_client.graph_rules.return_value = []
        _run(forge_mcp.forge_rules())
        mock_client.graph_rules.assert_called_once_with()

    def test_forge_check_rules(self, mock_client):
        mock_client.graph_check.return_value = []
        _run(forge_mcp.forge_check_rules("foo"))
        mock_client.graph_check.assert_called_once_with("foo")


# -- Provenance ----------------------------------------------------------

class TestProvenance:
    def test_forge_contradictions(self, mock_client):
        mock_client.graph_contradictions.return_value = []
        _run(forge_mcp.forge_contradictions())
        mock_client.graph_contradictions.assert_called_once_with()

    def test_forge_last_modified(self, mock_client):
        mock_client.graph_last_modified.return_value = {}
        _run(forge_mcp.forge_last_modified("foo"))
        mock_client.graph_last_modified.assert_called_once_with("foo")

    def test_forge_provenance_edge(self, mock_client):
        mock_client.graph_provenance.return_value = {}
        _run(forge_mcp.forge_provenance(edge_id=42))
        mock_client.graph_provenance.assert_called_once_with(
            edge_id=42, node_id=None, property=None
        )

    def test_forge_provenance_node_property(self, mock_client):
        mock_client.graph_provenance.return_value = {}
        _run(forge_mcp.forge_provenance(node_id=7, property="signature"))
        mock_client.graph_provenance.assert_called_once_with(
            edge_id=None, node_id=7, property="signature"
        )

    def test_forge_reasoning_trace_cascade(self, mock_client):
        mock_client.graph_reasoning_trace.return_value = {}
        _run(forge_mcp.forge_reasoning_trace(
            "cascade", name="foo", change_type="rename"
        ))
        mock_client.graph_reasoning_trace.assert_called_once_with(
            "cascade", "foo", "rename"
        )

    def test_forge_reasoning_trace_check_all(self, mock_client):
        mock_client.graph_reasoning_trace.return_value = {}
        _run(forge_mcp.forge_reasoning_trace("check_all"))
        mock_client.graph_reasoning_trace.assert_called_once_with(
            "check_all", None, None
        )


# -- Patterns ------------------------------------------------------------

class TestPatterns:
    def test_forge_patterns(self, mock_client):
        mock_client.graph_patterns_similar.return_value = []
        _run(forge_mcp.forge_patterns("foo"))
        mock_client.graph_patterns_similar.assert_called_once_with("foo")

    def test_forge_pattern_catalog(self, mock_client):
        mock_client.graph_patterns.return_value = []
        _run(forge_mcp.forge_pattern_catalog())
        mock_client.graph_patterns.assert_called_once_with()

    def test_forge_pattern_detail_by_id(self, mock_client):
        mock_client.graph_pattern.return_value = {}
        _run(forge_mcp.forge_pattern_detail(pattern_id=3))
        mock_client.graph_pattern.assert_called_once_with(3)
        mock_client.graph_pattern_by_name.assert_not_called()

    def test_forge_pattern_detail_by_name(self, mock_client):
        mock_client.graph_pattern_by_name.return_value = {}
        _run(forge_mcp.forge_pattern_detail(name="visitor"))
        mock_client.graph_pattern_by_name.assert_called_once_with("visitor")
        mock_client.graph_pattern.assert_not_called()

    def test_forge_pattern_detail_neither_raises(self, mock_client):
        with pytest.raises(ValueError):
            _run(forge_mcp.forge_pattern_detail())

    def test_forge_learn_patterns(self, mock_client):
        mock_client.admin_learn_patterns.return_value = {}
        _run(forge_mcp.forge_learn_patterns(
            similarity_threshold=0.8, min_exemplars=3
        ))
        mock_client.admin_learn_patterns.assert_called_once_with(0.8, 3)


# -- Generation-prep -----------------------------------------------------

class TestGenerationPrep:
    def test_forge_envelope(self, mock_client):
        mock_client.envelope.return_value = {}
        _run(forge_mcp.forge_envelope("foo", "add timeout", max_context=50))
        mock_client.envelope.assert_called_once_with("foo", "add timeout", 50)

    def test_forge_envelope_default_max_context(self, mock_client):
        mock_client.envelope.return_value = {}
        _run(forge_mcp.forge_envelope("foo", "task"))
        mock_client.envelope.assert_called_once_with("foo", "task", None)


# -- Ingestion -----------------------------------------------------------

class TestIngestion:
    def test_forge_scan(self, mock_client):
        mock_client.scan.return_value = {}
        _run(forge_mcp.forge_scan("/repo", commit="abc"))
        mock_client.scan.assert_called_once_with("/repo", "abc")

    def test_forge_scan_no_commit(self, mock_client):
        mock_client.scan.return_value = {}
        _run(forge_mcp.forge_scan("/repo"))
        mock_client.scan.assert_called_once_with("/repo", None)

    def test_forge_scan_status(self, mock_client):
        mock_client.scan_status.return_value = {}
        _run(forge_mcp.forge_scan_status("sid"))
        mock_client.scan_status.assert_called_once_with("sid")

    def test_forge_ingest(self, mock_client):
        mock_client.ingest.return_value = {}
        files = [{"path": "a.cpp", "content": "x"}]
        _run(forge_mcp.forge_ingest(files, commit="abc"))
        mock_client.ingest.assert_called_once_with(files, "abc")


# -- Generation ----------------------------------------------------------


class TestMeta:
    def test_forge_health(self, mock_client):
        mock_client.health.return_value = {}
        _run(forge_mcp.forge_health())
        mock_client.health.assert_called_once_with()

    def test_forge_auth_verify(self, mock_client):
        mock_client.auth_verify.return_value = {}
        _run(forge_mcp.forge_auth_verify())
        mock_client.auth_verify.assert_called_once_with()


# -- Config resolution ---------------------------------------------------

class TestConfigResolution:
    def test_env_wins_over_config(self, monkeypatch):
        monkeypatch.setenv("FORGE_URL", "https://env.example")
        monkeypatch.setenv("FORGE_API_KEY", "env-key")
        with patch.object(forge_mcp._config, "load", return_value={
            "url": "https://cfg.example", "api_key": "cfg-key"
        }):
            url, api_key, _graph = forge_mcp._resolve_config()
        assert url == "https://env.example"
        assert api_key == "env-key"

    def test_config_fallback(self, monkeypatch):
        monkeypatch.delenv("FORGE_URL", raising=False)
        monkeypatch.delenv("FORGE_API_KEY", raising=False)
        with patch.object(forge_mcp._config, "load", return_value={
            "url": "https://cfg.example", "api_key": "cfg-key"
        }):
            url, api_key, _graph = forge_mcp._resolve_config()
        assert url == "https://cfg.example"
        assert api_key == "cfg-key"

    def test_default_url_when_all_unset(self, monkeypatch):
        monkeypatch.delenv("FORGE_URL", raising=False)
        monkeypatch.delenv("FORGE_API_KEY", raising=False)
        monkeypatch.delenv("FORGE_GRAPH", raising=False)
        with patch.object(forge_mcp._config, "load", return_value={}):
            url, api_key, graph = forge_mcp._resolve_config()
        from dke_forge.config import DEFAULT_URL
        assert url == DEFAULT_URL
        assert api_key == ""
        assert graph is None

    def test_forge_graph_env_picked_up(self, monkeypatch):
        monkeypatch.setenv("FORGE_GRAPH", "featurex")
        monkeypatch.delenv("FORGE_URL", raising=False)
        monkeypatch.delenv("FORGE_API_KEY", raising=False)
        with patch.object(forge_mcp._config, "load", return_value={}):
            _url, _key, graph = forge_mcp._resolve_config()
        assert graph == "featurex"


# -- Tool registration ---------------------------------------------------

class TestToolRegistration:
    """All tools are present as module-level coroutine functions.

    FG-SUBSTRATE-MULTI-DEF-POLICY L1 finish-cycle + dead-MCP retirement
    (2026-04-24): 9 tools retired alongside the forge-api endpoints they
    called — `forge_semantic_search`, `forge_semantic_neighbors`,
    `forge_embed`, `forge_embed_status`, `forge_generate`,
    `forge_generate_docs`, `forge_write_test`, `forge_extract_method`,
    `forge_naming_suggest`. Per `project_dkeforge_tool_not_tool_user.md`
    forge doesn't call external LLMs; these tools targeted external
    inference (Voyage embed, Anthropic scribe) and are gone. Tool
    surface 54 → 45, categories 13 → 11 (Semantic Search + Generation
    retired).
    """

    EXPECTED_TOOLS = [
        # Foundation
        "forge_graph_stats",
        # Graphs (FG-96 A2 multi-graph)
        "forge_list_graphs", "forge_create_graph", "forge_get_graph",
        "forge_rename_graph", "forge_delete_graph",
        "forge_promote_default_graph",
        # Navigation
        "forge_query_function", "forge_callers_of", "forge_callees_of",
        "forge_depends_on", "forge_impact_analysis",
        "forge_callgraph_reachable", "forge_find_implementers",
        # Architecture (Wave 0 + Wave 1 / FG-30)
        "forge_dead_code", "forge_subgraph",
        "forge_circular_deps", "forge_god_classes", "forge_architecture_map",
        "forge_api_surface", "forge_abstractions", "forge_data_flow",
        "forge_module_topology",
        # Change (Wave 2 / FG-32)
        "forge_refactor_preview", "forge_breaking_change",
        "forge_deprecation_path", "forge_risky_change",
        "forge_commit_impact", "forge_review",
        # Rules
        "forge_rules", "forge_check_rules",
        # Provenance
        "forge_contradictions", "forge_last_modified",
        "forge_provenance", "forge_reasoning_trace",
        # Patterns
        "forge_patterns", "forge_pattern_catalog",
        "forge_pattern_detail", "forge_learn_patterns",
        # Generation-prep
        "forge_envelope",
        # Ingestion
        "forge_scan", "forge_scan_status", "forge_ingest",
        # Meta
        "forge_health", "forge_auth_verify",
        # Invitations (FG-API-INVITATION-RESEND + FG-API-INVITATION-PREVIEW)
        "forge_invitation_resend", "forge_invitation_preview",
    ]

    def test_count(self):
        # 54 → 45 after retiring the 9 tools that called deleted
        # forge-api endpoints (Voyage + Anthropic + Scribe stack).
        # 45 → 47 with the FG-API-INVITATION-{RESEND,PREVIEW} L2
        # follow-on (new Invitations category).
        assert len(self.EXPECTED_TOOLS) == 47

    def test_all_present_as_coroutines(self):
        for name in self.EXPECTED_TOOLS:
            fn = getattr(forge_mcp, name, None)
            assert fn is not None, f"tool missing: {name}"
            assert asyncio.iscoroutinefunction(fn), (
                f"tool not async: {name}"
            )


# -- Architecture Suite (FG-30 Phase 1.2.D) -----------------------------


class TestArchitectureSuite:
    def test_forge_circular_deps_defaults(self, mock_client):
        mock_client.analysis_circular_deps.return_value = {"cycles": []}
        _run(forge_mcp.forge_circular_deps())
        mock_client.analysis_circular_deps.assert_called_once_with(
            None, None, None,
        )

    def test_forge_circular_deps_all_params(self, mock_client):
        mock_client.analysis_circular_deps.return_value = {"cycles": []}
        _run(forge_mcp.forge_circular_deps(
            scope="module", max_cycles=10, max_length=50,
        ))
        mock_client.analysis_circular_deps.assert_called_once_with(
            "module", 10, 50,
        )

    def test_forge_god_classes_default(self, mock_client):
        mock_client.analysis_god_classes.return_value = {"entries": []}
        _run(forge_mcp.forge_god_classes())
        mock_client.analysis_god_classes.assert_called_once_with(None)

    def test_forge_god_classes_threshold(self, mock_client):
        mock_client.analysis_god_classes.return_value = {"entries": []}
        _run(forge_mcp.forge_god_classes(threshold=30))
        mock_client.analysis_god_classes.assert_called_once_with(30)

    def test_forge_architecture_map_all_params(self, mock_client):
        mock_client.analysis_architecture_map.return_value = {"top_nodes": []}
        _run(forge_mcp.forge_architecture_map(
            top_n=100, damping=0.85, max_iterations=50, tolerance=1e-6,
        ))
        mock_client.analysis_architecture_map.assert_called_once_with(
            100, 0.85, 50, 1e-6,
        )

    def test_forge_api_surface_by_id(self, mock_client):
        mock_client.analysis_api_surface.return_value = {"public_symbols": []}
        _run(forge_mcp.forge_api_surface(module_id=42))
        mock_client.analysis_api_surface.assert_called_once_with(42, None)

    def test_forge_api_surface_by_name(self, mock_client):
        mock_client.analysis_api_surface.return_value = {"public_symbols": []}
        _run(forge_mcp.forge_api_surface(module_name="render"))
        mock_client.analysis_api_surface.assert_called_once_with(None, "render")

    def test_forge_abstractions_min_group_size(self, mock_client):
        mock_client.analysis_abstractions.return_value = {"groups": []}
        _run(forge_mcp.forge_abstractions(min_group_size=4))
        mock_client.analysis_abstractions.assert_called_once_with(4)

    def test_forge_data_flow_forward_default(self, mock_client):
        mock_client.analysis_data_flow.return_value = {"reached": []}
        _run(forge_mcp.forge_data_flow(source_name="parse"))
        mock_client.analysis_data_flow.assert_called_once_with(
            None, "parse", None, None, None,
        )

    def test_forge_data_flow_with_paths(self, mock_client):
        mock_client.analysis_data_flow.return_value = {"reached": [], "paths": []}
        _run(forge_mcp.forge_data_flow(
            source_id=1, max_depth=10, direction="backward", include_paths=True,
        ))
        mock_client.analysis_data_flow.assert_called_once_with(
            1, None, 10, "backward", True,
        )

    def test_forge_module_topology(self, mock_client):
        mock_client.analysis_module_topology.return_value = {
            "modules": [], "deps": [],
        }
        _run(forge_mcp.forge_module_topology())
        mock_client.analysis_module_topology.assert_called_once_with()


# -- Change Suite (FG-32 Phase 2.1.C) -----------------------------------


class TestChangeSuite:
    def test_forge_refactor_preview_required_only(self, mock_client):
        mock_client.change_refactor_preview.return_value = {"found": True}
        _run(forge_mcp.forge_refactor_preview("old", "new"))
        mock_client.change_refactor_preview.assert_called_once_with(
            "old", "new", None,
        )

    def test_forge_refactor_preview_with_kind(self, mock_client):
        mock_client.change_refactor_preview.return_value = {}
        _run(forge_mcp.forge_refactor_preview("Foo", "Bar", kind="Type"))
        mock_client.change_refactor_preview.assert_called_once_with(
            "Foo", "Bar", "Type",
        )

    def test_forge_breaking_change(self, mock_client):
        mock_client.change_breaking_change.return_value = {"found": True}
        _run(forge_mcp.forge_breaking_change(
            "f", "int", ["const std::string&", "std::size_t"],
        ))
        mock_client.change_breaking_change.assert_called_once_with(
            "f", "int", ["const std::string&", "std::size_t"],
        )

    def test_forge_deprecation_path_defaults(self, mock_client):
        mock_client.change_deprecation_path.return_value = {}
        _run(forge_mcp.forge_deprecation_path("OldApi"))
        mock_client.change_deprecation_path.assert_called_once_with(
            "OldApi", None, None,
        )

    def test_forge_deprecation_path_all_params(self, mock_client):
        mock_client.change_deprecation_path.return_value = {}
        _run(forge_mcp.forge_deprecation_path(
            "OldApi", kind="Function", max_depth=50,
        ))
        mock_client.change_deprecation_path.assert_called_once_with(
            "OldApi", "Function", 50,
        )

    def test_forge_risky_change(self, mock_client):
        mock_client.change_risky.return_value = {"score": 0.0}
        _run(forge_mcp.forge_risky_change("abc123"))
        mock_client.change_risky.assert_called_once_with("abc123")

    def test_forge_commit_impact(self, mock_client):
        mock_client.change_commit_impact.return_value = {"touched_count": 0}
        _run(forge_mcp.forge_commit_impact("abc123"))
        mock_client.change_commit_impact.assert_called_once_with("abc123")

    def test_forge_review_commit_only(self, mock_client):
        mock_client.change_review.return_value = {"risk_score": 0.0}
        _run(forge_mcp.forge_review("abc123"))
        mock_client.change_review.assert_called_once_with("abc123", None)

    def test_forge_review_with_focus_area_top_n(self, mock_client):
        mock_client.change_review.return_value = {}
        _run(forge_mcp.forge_review("abc123", focus_area_top_n=10))
        mock_client.change_review.assert_called_once_with("abc123", 10)


# -- Semantic Search (FG-29 Phase 1.1.C) --------------------------------


class TestGraphs:
    def test_forge_list_graphs(self, mock_client):
        mock_client.list_graphs.return_value = {"graphs": [],
                                                 "default_graph_id": ""}
        _run(forge_mcp.forge_list_graphs())
        mock_client.list_graphs.assert_called_once_with()

    def test_forge_create_graph(self, mock_client):
        mock_client.create_graph.return_value = {"id": "g1",
                                                   "slug": "a", "name": "A"}
        _run(forge_mcp.forge_create_graph("a", "A"))
        mock_client.create_graph.assert_called_once_with("a", "A")

    def test_forge_get_graph(self, mock_client):
        mock_client.get_graph.return_value = {"id": "g1"}
        _run(forge_mcp.forge_get_graph("g1"))
        mock_client.get_graph.assert_called_once_with("g1")

    def test_forge_rename_graph_slug_only(self, mock_client):
        mock_client.rename_graph.return_value = {"id": "g1"}
        _run(forge_mcp.forge_rename_graph("g1", slug="new"))
        mock_client.rename_graph.assert_called_once_with("g1", "new", None)

    def test_forge_delete_graph_with_reassign(self, mock_client):
        mock_client.delete_graph.return_value = {"deleted": True}
        _run(forge_mcp.forge_delete_graph("g1",
                                            reassign_default_to="g2"))
        mock_client.delete_graph.assert_called_once_with("g1", "g2")

    def test_forge_promote_default_graph(self, mock_client):
        mock_client.promote_default_graph.return_value = {
            "default_graph_id": "g1"}
        _run(forge_mcp.forge_promote_default_graph("g1"))
        mock_client.promote_default_graph.assert_called_once_with("g1")


# FG-API-INVITATION-{RESEND,PREVIEW} L2 follow-on — workspace
# invitation lifecycle. Mocked-client pattern same as TestGraphs;
# verifies the MCP wrapper dispatches to the right ForgeClient
# method with the right args.
class TestInvitations:
    def test_forge_invitation_resend(self, mock_client):
        mock_client.invitation_resend.return_value = {
            "token": "abc", "email_sent": True,
            "accept_url": "https://dke-forge.com/accept-invitation.html?token=abc",
        }
        _run(forge_mcp.forge_invitation_resend("abc"))
        mock_client.invitation_resend.assert_called_once_with("abc")

    def test_forge_invitation_preview(self, mock_client):
        mock_client.invitation_preview.return_value = {
            "workspace_name": "Acme",
            "invitee_email": "alice@example.com",
            "role": "contributor",
            "state": "pending",
            "expires_at": 1234567890,
        }
        result = _run(forge_mcp.forge_invitation_preview("abc"))
        mock_client.invitation_preview.assert_called_once_with("abc")
        # MCP layer is a pure adapter — passes the dict through unchanged.
        assert result["state"] == "pending"
        assert result["workspace_name"] == "Acme"
