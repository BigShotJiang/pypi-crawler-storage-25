"""Configuration file management for dke-forge CLI."""

import json
import os

CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".config", "dke-forge")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")

VALID_KEYS = {"url", "api_key", "model"}
DEFAULT_URL = "https://dke-forge.com"


def load():
    if not os.path.exists(CONFIG_FILE):
        return {}
    with open(CONFIG_FILE) as f:
        return json.load(f)


def save(cfg):
    os.makedirs(CONFIG_DIR, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=2)
        f.write("\n")
    os.chmod(CONFIG_FILE, 0o600)


def get(key):
    return load().get(key)


def set_value(key, value):
    if key not in VALID_KEYS:
        raise ValueError(
            f"Unknown config key: {key}. Valid: {', '.join(sorted(VALID_KEYS))}"
        )
    cfg = load()
    cfg[key] = value
    save(cfg)
