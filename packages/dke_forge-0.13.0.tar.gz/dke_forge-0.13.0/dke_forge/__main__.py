from dke_forge.cli import main

main()
