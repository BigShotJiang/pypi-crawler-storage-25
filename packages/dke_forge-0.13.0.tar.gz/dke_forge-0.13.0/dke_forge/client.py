"""ForgeClient — REST client for the DKE-Forge API."""

import requests
from urllib.parse import quote


class ForgeError(Exception):
    """Error returned by the DKE-Forge API or connection layer."""

    def __init__(self, status_code, message):
        self.status_code = status_code
        self.message = message
        super().__init__(f"HTTP {status_code}: {message}" if status_code else message)


class ForgeClient:
    """Python client for the DKE-Forge code intelligence API.

    Usage::

        from dke_forge import ForgeClient

        client = ForgeClient("https://dke-forge.com", api_key="fga_...")
        stats = client.graph_stats()
    """

    def __init__(self, url, api_key="", timeout=120, graph=None):
        """Initialize the client.

        `graph` is an optional X-Forge-Graph routing hint — may be a
        graph id or a slug. When set, every request carries the header
        so the server routes to that graph instead of the workspace
        default. None disables routing (workspace default_graph_id is
        used).
        """
        self.url = url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self.graph = graph

    def _headers(self):
        h = {"Content-Type": "application/json"}
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        if self.graph:
            h["X-Forge-Graph"] = self.graph
        return h

    def _request(self, method, path, timeout=None, **kwargs):
        try:
            r = requests.request(
                method,
                f"{self.url}{path}",
                headers=self._headers(),
                timeout=timeout or self.timeout,
                **kwargs,
            )
        except requests.ConnectionError:
            raise ForgeError(0, f"Cannot connect to {self.url}")
        except requests.Timeout:
            raise ForgeError(0, "Request timed out")
        if not r.ok:
            try:
                msg = r.json().get("error", r.text)
            except Exception:
                msg = r.text
            raise ForgeError(r.status_code, msg)
        if r.status_code == 204:
            return {}
        return r.json()

    def _get(self, path, params=None):
        return self._request("GET", path, params=params)

    def _post(self, path, data=None, timeout=None):
        return self._request("POST", path, json=data, timeout=timeout)

    def _delete(self, path, params=None):
        return self._request("DELETE", path, params=params)

    def _patch(self, path, data=None):
        return self._request("PATCH", path, json=data)

    @staticmethod
    def _encode(name):
        return quote(name, safe="")

    # -- Public endpoints --

    def health(self):
        return self._get("/health")

    def register(self, email, name):
        return self._post("/v1/register", {"email": email, "name": name})

    # -- Auth --

    def auth_verify(self):
        return self._post("/v1/auth/verify")

    # -- Graph queries (Tier 1: Oracle) --

    def graph_stats(self):
        return self._get("/v1/graph/stats")

    # FG-SUBSTRATE-MULTI-DEF-POLICY Slice 4: `branch` + `file` kwargs
    # plumb the forge-api BranchView qualifiers through to the MCP layer.
    # `branch` = 16-char def_hash → narrows a multi-branch response to
    # one branch. `file` = translation-unit path → narrows when a name
    # is declared in multiple TUs. Both are omitted from the query when
    # unset so pre-Slice-3b consumers see no change.
    def graph_function(self, name, branch=None, file=None):
        params = {}
        if branch is not None: params["branch"] = branch
        if file   is not None: params["file"]   = file
        return self._get(
            f"/v1/graph/function/{self._encode(name)}",
            params if params else None,
        )

    def graph_callers(self, name, depth=2, branch=None, file=None):
        params = {"depth": depth}
        if branch is not None: params["branch"] = branch
        if file   is not None: params["file"]   = file
        return self._get(f"/v1/graph/callers/{self._encode(name)}", params)

    def graph_callees(self, name, depth=2, branch=None, file=None):
        params = {"depth": depth}
        if branch is not None: params["branch"] = branch
        if file   is not None: params["file"]   = file
        return self._get(f"/v1/graph/callees/{self._encode(name)}", params)

    def graph_depends(self, name):
        return self._get(f"/v1/graph/depends/{self._encode(name)}")

    def graph_impact(self, name, change_type="modify", branch=None, file=None):
        params = {"change_type": change_type}
        if branch is not None: params["branch"] = branch
        if file   is not None: params["file"]   = file
        return self._get(
            f"/v1/graph/impact/{self._encode(name)}", params,
        )

    def graph_rules(self):
        return self._get("/v1/graph/rules")

    def graph_check(self, name):
        return self._post("/v1/graph/check", {"name": name})

    def graph_patterns(self):
        return self._get("/v1/graph/patterns")

    def graph_pattern(self, pattern_id):
        return self._get(f"/v1/graph/pattern/{pattern_id}")

    # -- Graph queries (Wave 0 extensions) --

    def graph_patterns_similar(self, name):
        return self._get(f"/v1/graph/patterns/similar/{self._encode(name)}")

    def graph_pattern_by_name(self, name):
        return self._get(f"/v1/graph/pattern/by-name/{self._encode(name)}")

    def graph_implementers(self, name):
        return self._get(f"/v1/graph/implementers/{self._encode(name)}")

    def graph_dead_code(self, exclude_tests=True):
        return self._get(
            "/v1/graph/dead-code",
            {"exclude_tests": 1 if exclude_tests else 0},
        )

    def graph_subgraph(self, **filters):
        """Focused subgraph export.

        Accepted filters: ``module`` (str), ``type`` (str), ``functions``
        (list or comma-joined str), ``max_depth`` (int). Unknown keys are
        silently dropped; the server enforces the real contract.
        """
        params = {}
        for key in ("module", "type", "max_depth"):
            if filters.get(key) is not None:
                params[key] = filters[key]
        fns = filters.get("functions")
        if fns:
            params["functions"] = ",".join(fns) if isinstance(fns, (list, tuple)) else fns
        return self._get("/v1/graph/subgraph", params or None)

    def graph_reachable(self, name, via=None):
        params = {"via": via} if via else None
        return self._get(f"/v1/graph/reachable/{self._encode(name)}", params)

    def graph_contradictions(self):
        return self._get("/v1/graph/contradictions")

    def graph_last_modified(self, name):
        return self._get(f"/v1/graph/last-modified/{self._encode(name)}")

    def graph_provenance(self, edge_id=None, node_id=None, property=None):
        """Provenance for either an edge or a node property.

        Must pass ``edge_id`` OR both ``node_id`` and ``property``.
        """
        if edge_id is not None:
            params = {"edge_id": edge_id}
        elif node_id is not None and property is not None:
            params = {"node_id": node_id, "property": property}
        else:
            raise ValueError(
                "graph_provenance requires either edge_id or (node_id + property)"
            )
        return self._get("/v1/graph/provenance", params)

    def graph_reasoning_trace(self, query_type, name=None, change_type=None):
        """Inference trace for a derived query.

        ``query_type`` is ``"cascade"`` or ``"check_all"``. Cascade requires
        ``name``; optional ``change_type`` defaults server-side to ``"modify"``.
        """
        params = {"query_type": query_type}
        if name is not None:
            params["name"] = name
        if change_type is not None:
            params["change_type"] = change_type
        return self._get("/v1/graph/reasoning-trace", params)

    # -- Envelope (Tier 2) --

    def envelope(self, name, task, max_context=None):
        body = {"name": name, "task": task}
        if max_context is not None:
            body["max_context"] = max_context
        return self._post("/v1/envelope", body)

    # -- Multi-graph management (FG-96) --

    def list_graphs(self):
        """List every alive graph in the workspace plus the current
        ``default_graph_id``."""
        return self._get("/v1/graphs")

    def create_graph(self, slug, name):
        """Create a new graph in the workspace. ``slug`` must match
        ``[a-z0-9][a-z0-9-]{0,39}``. Gated on a funded LCN balance.
        Returns the new GraphRow (dict)."""
        return self._post("/v1/graphs", {"slug": slug, "name": name})

    def get_graph(self, graph_id):
        return self._get(f"/v1/graphs/{self._encode(graph_id)}")

    def rename_graph(self, graph_id, slug=None, name=None):
        """Update slug and/or name. Pass either or both — at least one
        is required. Returns the updated GraphRow."""
        body = {}
        if slug is not None:
            body["slug"] = slug
        if name is not None:
            body["name"] = name
        return self._patch(f"/v1/graphs/{self._encode(graph_id)}", body)

    def delete_graph(self, graph_id, reassign_default_to=None):
        """Soft-delete a graph. If the target is the current default,
        pass ``reassign_default_to`` (another alive graph id in the same
        workspace) — the soft-delete fails with 409 otherwise."""
        params = None
        if reassign_default_to:
            params = {"reassign_default_to": reassign_default_to}
        return self._delete(
            f"/v1/graphs/{self._encode(graph_id)}", params=params)

    def promote_default_graph(self, graph_id):
        """Repoint ``tenants.default_graph_id`` to the named graph."""
        return self._post(
            f"/v1/graphs/{self._encode(graph_id)}/default")

    def scan(self, path, commit=None):
        """Start an async repository scan.

        Returns ``{scan_id, status, commit}`` immediately (HTTP 202). The
        server runs the ingest on a background thread; poll
        :meth:`scan_status` for progress and completion. The ``dke-forge
        scan`` CLI preserves a synchronous UX by polling on the caller's
        behalf.
        """
        body = {"path": path}
        if commit:
            body["commit"] = commit
        return self._post("/v1/scan", body, timeout=30)

    def scan_status(self, scan_id):
        return self._get(f"/v1/scan/{self._encode(scan_id)}")

    def ingest(self, files, commit=None):
        body = {"files": files}
        if commit:
            body["commit"] = commit
        return self._post("/v1/ingest", body, timeout=300)

    # -- Analysis / Architecture suite (Wave 1 / FG-30) --

    def analysis_circular_deps(self, scope=None, max_cycles=None, max_length=None):
        """Cycles in DependsOn + Includes edges.

        ``scope`` is ``"all"`` (default, server-side) | ``"file"`` |
        ``"module"`` | ``"library"``. ``max_cycles`` / ``max_length`` cap
        the result to keep responses bounded on pathological graphs.
        """
        params = {}
        if scope is not None:
            params["scope"] = scope
        if max_cycles is not None:
            params["max_cycles"] = max_cycles
        if max_length is not None:
            params["max_length"] = max_length
        return self._get("/v1/analysis/circular-deps", params or None)

    def analysis_god_classes(self, threshold=None):
        """Types whose combined outgoing degree exceeds ``threshold``."""
        params = {"threshold": threshold} if threshold is not None else None
        return self._get("/v1/analysis/god-classes", params)

    def analysis_architecture_map(
        self,
        top_n=None,
        damping=None,
        max_iterations=None,
        tolerance=None,
    ):
        """Top-N most-central nodes by PageRank.

        ``damping`` must be in ``(0, 1)`` (enforced server-side).
        """
        params = {}
        if top_n is not None:
            params["top_n"] = top_n
        if damping is not None:
            params["damping"] = damping
        if max_iterations is not None:
            params["max_iterations"] = max_iterations
        if tolerance is not None:
            params["tolerance"] = tolerance
        return self._get("/v1/analysis/architecture-map", params or None)

    def analysis_api_surface(self, module_id=None, module_name=None):
        """Auto-detected public boundary for a module.

        Must pass exactly one of ``module_id`` (uint64) or
        ``module_name``. Server returns 404 when the module is not found.
        """
        if module_id is not None:
            params = {"module_id": module_id}
        elif module_name is not None:
            params = {"module_name": module_name}
        else:
            raise ValueError(
                "analysis_api_surface requires module_id or module_name"
            )
        return self._get("/v1/analysis/api-surface", params)

    def analysis_abstractions(self, min_group_size=None):
        """Candidate interfaces from shared method shapes.

        ``min_group_size`` must be ``>= 2`` (enforced server-side).
        """
        params = (
            {"min_group_size": min_group_size}
            if min_group_size is not None else None
        )
        return self._get("/v1/analysis/abstractions", params)

    def analysis_data_flow(
        self,
        source_id=None,
        source_name=None,
        max_depth=None,
        direction=None,
        include_paths=None,
    ):
        """Taint-tracking BFS over Calls + HasParam + UsesType.

        Must pass exactly one of ``source_id`` (uint64) or
        ``source_name``. ``direction`` is ``"forward"`` (default) |
        ``"backward"`` | ``"both"``. ``include_paths`` attaches the full
        edge-labeled paths to each reached node.
        """
        if source_id is not None:
            params = {"source_id": source_id}
        elif source_name is not None:
            params = {"source_name": source_name}
        else:
            raise ValueError(
                "analysis_data_flow requires source_id or source_name"
            )
        if max_depth is not None:
            params["max_depth"] = max_depth
        if direction is not None:
            params["direction"] = direction
        if include_paths is not None:
            params["include_paths"] = 1 if include_paths else 0
        return self._get("/v1/analysis/data-flow", params)

    def analysis_module_topology(self):
        """Module-Module dependency graph with edge-count weights."""
        return self._get("/v1/analysis/module-topology")

    # -- Change suite (Wave 2 / FG-32) --

    def change_refactor_preview(self, symbol_name, new_name, kind=None):
        """Preview the impact of renaming a symbol (Oracle / Tier 1).

        Returns the affected callers, tests, and files plus any rule
        conflicts triggered by the proposed name. ``kind`` is an optional
        ``NodeType`` name filter (``"Function"`` | ``"Type"`` |
        ``"Variable"`` ...) used when the symbol is ambiguous.
        """
        body = {"symbol_name": symbol_name, "new_name": new_name}
        if kind is not None:
            body["kind"] = kind
        return self._post("/v1/change/refactor-preview", body)

    def change_breaking_change(self, symbol_name, new_return_type, new_param_types):
        """Signature-change impact analysis (Oracle / Tier 1).

        ``new_param_types`` is an ordered list of parameter-type strings.
        Returns affected callers with per-caller mismatch descriptions,
        the breaking test set, and any contradictions surfaced by the
        reasoner against the proposed signature.
        """
        body = {
            "symbol_name": symbol_name,
            "new_return_type": new_return_type,
            "new_param_types": list(new_param_types),
        }
        return self._post("/v1/change/breaking-change", body)

    def change_deprecation_path(self, symbol_name, kind=None, max_depth=None):
        """Staged deprecation plan — migrate-then-remove ordering (Envelope / Tier 2).

        Walks the canonical reverse-dep edge set
        (``Calls + DependsOn + UsesType + InheritsFrom``) via
        ``ForgeReasoner::analyzeCascade`` to compute a per-depth
        migration plan. ``max_depth`` caps the closure (default 100;
        0 = target only). ``kind`` is an optional ``NodeType`` filter.
        """
        body = {"symbol_name": symbol_name}
        if kind is not None:
            body["kind"] = kind
        if max_depth is not None:
            body["max_depth"] = max_depth
        return self._post("/v1/change/deprecation-path", body)

    def change_risky(self, commit):
        """Risk score for a commit tag (Envelope / Tier 2).

        Composite of thermal mean + pattern-drift rate + rule-violation
        rate across the nodes tagged with the commit SHA. Returns
        ``{score, breakdown, touched_*, rule_violations, pattern_violations}``
        where each ``pattern_violations`` entry is
        ``{touched_node_id, drifted_pattern_id}``.
        """
        return self._get("/v1/change/risky", {"commit": commit})

    def change_commit_impact(self, commit):
        """Structural impact of a commit tag (Oracle / Tier 1).

        Returns ``{commit_sha, touched_count, touched_node_ids,
        cascade_summary, contradictions}`` — cascade_summary has
        ``total_direct``, ``total_transitive``, ``modules_affected``,
        ``files_affected``.
        """
        return self._get("/v1/change/commit-impact", {"commit": commit})

    def change_review(self, commit, focus_area_top_n=None):
        """Composite commit review (Envelope / Tier 2).

        Wraps ``change_commit_impact`` with pattern-alignment +
        rule-violation summaries and a ranked list of recommended focus
        areas. ``focus_area_top_n`` caps the focus-area list (default 5;
        0 = unlimited).
        """
        params = {"commit": commit}
        if focus_area_top_n is not None:
            params["focus_area_top_n"] = focus_area_top_n
        return self._get("/v1/change/review", params)

    # -- Invitations (FG-API-INVITATION-RESEND + FG-API-INVITATION-PREVIEW) --
    #
    # Workspace invitation lifecycle endpoints. Resend re-triggers the
    # email for a live invite without rotating the token (so accept-urls
    # already shared remain valid); preview is a public lookup-by-token
    # for UI rendering before the user clicks Accept. Pairs with
    # forge-api 0.20.0.

    def invitation_resend(self, token):
        """Resend the invitation email for a live invite (token preserved).

        Recovery path for the "Resend outage / invitee can't find email"
        failure mode. Auth: workspace member with ManageMembers
        permission (owner or admin in practice). Returns the same shape
        as create — invitation row + ``accept_url`` + ``email_sent``.

        Status semantics mirror Accept: 410 if revoked or expired, 409
        if already accepted, 404 if the token doesn't exist or belongs
        to another workspace (we deliberately don't leak existence
        cross-tenant).
        """
        return self._post(f"/v1/invitations/{self._encode(token)}/resend")

    def invitation_preview(self, token):
        """Public lookup-by-token returning invite metadata for UI rendering.

        No auth required — the token IS the auth, same posture as the
        accept endpoint. Always returns 200 with a ``state`` field
        (``pending`` / ``revoked`` / ``accepted`` / ``expired``) so the
        UI caller can render a single shape across all states; 404 only
        when the token is unknown. Other fields: ``workspace_id``,
        ``workspace_name``, ``invitee_email``, ``role``, ``expires_at``.
        ``invited_by`` user_id is deliberately omitted (PII not useful
        to UI).
        """
        return self._get(f"/v1/invitations/{self._encode(token)}/preview")

    # -- Admin --

    def admin_create_tenant(self, name, tier=None):
        body = {"name": name}
        if tier is not None:
            body["tier"] = tier
        return self._post("/v1/admin/tenants", body)

    def admin_list_tenants(self):
        return self._get("/v1/admin/tenants")

    def admin_revoke_tenant(self, tenant_id):
        return self._delete(f"/v1/admin/tenants/{tenant_id}")

    def admin_learn_patterns(self, similarity_threshold=None, min_exemplars=None):
        body = {}
        if similarity_threshold is not None:
            body["similarity_threshold"] = similarity_threshold
        if min_exemplars is not None:
            body["min_exemplars"] = min_exemplars
        return self._post("/v1/admin/patterns/learn", body or None)
