"""Human-readable output formatters for DKE-Forge API responses."""

import json as json_module


def as_json(data):
    return json_module.dumps(data, indent=2)


def _kv(pairs, indent=2):
    if not pairs:
        return ""
    width = max(len(k) for k, _ in pairs) + 1
    prefix = " " * indent
    return "\n".join(f"{prefix}{k + ':':<{width + 1}} {v}" for k, v in pairs)


# -- Public endpoints --


def health(data):
    return _kv([
        ("Status", data.get("status", "?")),
        ("Version", data.get("version", "?")),
    ], indent=0)


def register_result(data):
    lines = [
        "Registered successfully!",
        "",
        _kv([
            ("Email", data.get("email", "?")),
            ("Name", data.get("name", "?")),
            ("Tier", f"{data.get('tier', '?')} ({data.get('tier_level', '?')})"),
            ("API Key", data.get("api_key", "?")),
        ]),
        "",
        "Save your API key -- it will not be shown again.",
        f"Run: dke-forge config set api_key {data.get('api_key', '<key>')}",
    ]
    return "\n".join(lines)


# -- Auth --


def auth_info(data):
    return _kv([
        ("Name", data.get("name", "?")),
        ("Email", data.get("email", "?")),
        ("Tier", f"{data.get('tier', '?')} ({data.get('tier_level', '?')})"),
        ("Status", data.get("status", "?")),
    ])


# -- Graph queries --


def stats(data):
    lines = [
        f"Nodes: {data.get('node_count', 0):,}",
        f"Edges: {data.get('edge_count', 0):,}",
    ]
    nt = data.get("node_types", {})
    if nt:
        lines.append("")
        lines.append("Node Types:")
        for k, v in sorted(nt.items(), key=lambda x: -x[1]):
            lines.append(f"  {k:<16} {v:>8,}")
    tz = data.get("thermal_zones", {})
    if tz:
        lines.append("")
        lines.append("Thermal Zones:")
        for zone in ["hot", "warm", "cold", "frozen"]:
            if zone in tz:
                lines.append(f"  {zone:<16} {tz[zone]:>8,}")
    return "\n".join(lines)


def function_list(data):
    if not data:
        return "No results."
    lines = []
    for fn in data:
        props = fn.get("props", {})
        loc = fn.get("file", "?")
        if props.get("line"):
            loc = f"{loc}:{props['line']}"
        lines.append(fn.get("name", "?"))
        lines.append(f"  File:        {loc}")
        lines.append(f"  Temperature: {fn.get('temperature', 0):.2f}")
        lines.append(f"  Confidence:  {fn.get('confidence', 0):.2f}")
        if props.get("signature"):
            lines.append(f"  Signature:   {props['signature']}")
        lines.append("")
    return "\n".join(lines)


def depends(data):
    if not data:
        return "No dependencies."
    lines = []
    for dep in data:
        target = dep.get("target", {})
        lines.append(
            f"  {dep.get('edge_type', '?'):<14} "
            f"{target.get('name', '?'):<30} "
            f"{dep.get('confidence', 0):.2f}"
        )
    return "\n".join(lines)


def impact(data):
    changed = data.get("changed", {})
    lines = [
        f"Impact: {data.get('change_type', 'modify')} {changed.get('name', '?')}",
        f"  Direct:      {len(data.get('directly_affected', []))} functions",
        f"  Transitive:  {len(data.get('transitively_affected', []))} functions",
        f"  Tests:       {len(data.get('test_cases_affected', []))} test cases",
    ]
    files = data.get("files_to_update", [])
    if files:
        lines.append(f"  Files:       {', '.join(files)}")
    return "\n".join(lines)


def rules(data):
    if not data:
        return "No rules defined."
    lines = ["Rules:"]
    for r in data:
        lines.append(
            f"  {r.get('severity', '?'):<6} "
            f"{r.get('name', '?'):<24} "
            f"{r.get('target_type', '?'):<10} "
            f"{r.get('message', '')}"
        )
    return "\n".join(lines)


def violations(data):
    if not data:
        return "No violations."
    lines = ["Violations:"]
    for v in data:
        lines.append(
            f"  {v.get('severity', '?'):<6} "
            f"{v.get('rule', '?'):<24} "
            f"{v.get('message', '')}"
        )
    return "\n".join(lines)


def pattern_list(data):
    if not data:
        return "No patterns learned."
    lines = [f"  {'ID':<8} {'Name':<28} {'Confidence':>10} {'Exemplars':>10}"]
    for p in data:
        lines.append(
            f"  {p.get('id', '?'):<8} "
            f"{p.get('name', '?'):<28} "
            f"{p.get('confidence', 0):>10.2f} "
            f"{p.get('props', {}).get('exemplar_count', '?'):>10}"
        )
    return "\n".join(lines)


def pattern_detail(data):
    lines = [
        f"Pattern: {data.get('name', '?')} (ID: {data.get('id', '?')})",
        f"  Temperature: {data.get('temperature', 0):.2f}",
        f"  Confidence:  {data.get('confidence', 0):.2f}",
        f"  Exemplars:   {data.get('exemplar_count', '?')}",
    ]
    centroid = data.get("centroid", {})
    if centroid:
        lines.append("")
        lines.append("  Centroid:")
        for k, v in sorted(centroid.items()):
            lines.append(f"    {k:<16} {v:.1f}")
    exemplars = data.get("exemplars", [])
    if exemplars:
        lines.append("")
        lines.append("  Exemplar Functions:")
        for ex in exemplars:
            lines.append(f"    {ex.get('name', '?'):<24} {ex.get('file', '?')}")
    return "\n".join(lines)


# -- Envelope --


def envelope(data):
    lines = [
        f"Target:   {data.get('target', {}).get('name', '?')}",
        f"Task:     {data.get('task', '?')}",
        f"Callers:  {data.get('callers', 0)}  Callees: {data.get('callees', 0)}  "
        f"Types: {data.get('type_deps', 0)}  Co-located: {data.get('co_located', 0)}",
        f"Rules:    {data.get('rules', 0)}  Patterns: {data.get('patterns', 0)}",
        "",
        data.get("envelope_text", ""),
    ]
    return "\n".join(lines)


# -- Generate --


def generate_result(data):
    status = "ACCEPTED" if data.get("accepted") else "REJECTED"
    lines = [
        f"Generation: {data.get('target', '?')}  [{status}]",
        f"  Provider:  {data.get('provider', '?')}",
        f"  Attempts:  {data.get('attempts', '?')}",
        f"  Duration:  {data.get('total_ms', 0) / 1000:.1f}s",
    ]
    for attempt in data.get("attempt_details", []):
        n = attempt.get("attempt", "?")
        ok = "pass" if attempt.get("compile_ok") else "FAIL"
        lines.append(f"  Attempt {n}: compile={ok}")
        if attempt.get("compile_output"):
            for line in attempt["compile_output"].splitlines()[:5]:
                lines.append(f"    {line}")
        for v in attempt.get("violations", []):
            lines.append(f"    {v.get('severity', '?')}: {v.get('message', '')}")
    if data.get("accepted") and data.get("code"):
        lines.append("")
        lines.append("--- Generated Code ---")
        lines.append(data["code"])
        lines.append("---")
    return "\n".join(lines)


# -- Scan / Ingest --


def scan_started(data):
    return _kv([
        ("Scan ID", data.get("scan_id", "?")),
        ("Status", data.get("status", "?")),
        ("Commit", data.get("commit", "?")),
    ])


def scan_status(data):
    lines = [_kv([
        ("Scan ID", data.get("id", "?")),
        ("Status", data.get("status", "?")),
        ("Files", f"{data.get('files_processed', 0)}/{data.get('total_files', 0)}"),
        ("Nodes", f"{data.get('total_nodes', 0):,}"),
        ("Edges", f"{data.get('total_edges', 0):,}"),
        ("Commit", data.get("commit", "?")),
    ])]
    if data.get("error"):
        lines.append(f"  Error: {data['error']}")
    return "\n".join(lines)


def ingest_result(data):
    return _kv([
        ("Files ingested", str(data.get("files_ingested", 0))),
        ("Files skipped", str(data.get("files_skipped", 0))),
        ("Nodes created", f"{data.get('nodes_created', 0):,}"),
        ("Edges created", f"{data.get('edges_created', 0):,}"),
        ("Errors", str(data.get("errors", 0))),
    ])


# -- Embedding / Semantic search (Wave 1 / FG-29) --


def embed_started(data):
    return _kv([
        ("Job ID", data.get("job_id", "?")),
        ("Status", data.get("status", "?")),
        ("Mode", data.get("mode", "?")),
        ("Provider", data.get("provider", "?")),
        ("Model", data.get("model", "?")),
        ("Dim", str(data.get("dim", "?"))),
    ])


def embed_status(data):
    lines = [_kv([
        ("Job ID", data.get("id", "?")),
        ("Status", data.get("status", "?")),
        ("Mode", data.get("mode", "?")),
        ("Provider", data.get("provider", "?")),
        ("Model", data.get("model", "?")),
        ("Functions", f"{data.get('functions_processed', 0)}/{data.get('total_functions', 0)}"),
        ("Tokens", f"{data.get('total_tokens', 0):,}"),
        ("Commit", data.get("commit", "?")),
    ])]
    if data.get("error"):
        lines.append(f"  Error: {data['error']}")
    return "\n".join(lines)


def semantic_search(data):
    hits = data.get("hits", [])
    lines = [_kv([
        ("Query", data.get("query", "?")),
        ("Mode", data.get("mode", "?")),
        ("Provider", data.get("provider", "?")),
        ("Model", data.get("model", "?")),
        ("Hits", str(len(hits))),
    ])]
    for i, h in enumerate(hits, 1):
        lines.append("")
        lines.append(f"  [{i}] {h.get('function', '?')}  "
                     f"(similarity {h.get('similarity', 0.0):.4f})")
        if h.get("file"):
            lines.append(f"      file: {h['file']}:{h.get('line', '?')}")
        if h.get("signature"):
            sig = h["signature"].strip().split("\n", 1)[0]
            lines.append(f"      sig:  {sig[:120]}")
        if h.get("docstring"):
            doc = h["docstring"].strip().split("\n", 1)[0]
            lines.append(f"      doc:  {doc[:120]}")
        if h.get("callers"):
            names = ", ".join(c["name"] for c in h["callers"][:5])
            more = " (+…)" if len(h["callers"]) > 5 else ""
            lines.append(f"      callers: {names}{more}")
        if h.get("callees"):
            names = ", ".join(c["name"] for c in h["callees"][:5])
            more = " (+…)" if len(h["callees"]) > 5 else ""
            lines.append(f"      callees: {names}{more}")
    return "\n".join(lines)


# -- Architecture Suite (Wave 1 / FG-30) --


def circular_deps(data):
    cycles = data.get("cycles", [])
    lines = [_kv([
        ("Scope", data.get("scope", "?")),
        ("File cycles", str(data.get("file_cycles_found", 0))),
        ("Module cycles", str(data.get("module_cycles_found", 0))),
        ("Library cycles", str(data.get("library_cycles_found", 0))),
        ("Returned", str(len(cycles))),
        ("Truncated", "yes" if data.get("truncated") else "no"),
    ])]
    for i, c in enumerate(cycles, 1):
        names = " -> ".join(c.get("names", []))
        lines.append("")
        lines.append(f"  [{i}] ({c.get('scope', '?')}, len={c.get('length', 0)})")
        lines.append(f"      {names}")
    return "\n".join(lines)


def god_classes(data):
    entries = data.get("entries", [])
    if not entries:
        return f"No types exceed threshold {data.get('threshold', '?')}."
    lines = [
        f"Threshold: {data.get('threshold', '?')}",
        f"  {'Degree':>8}  {'HasMember':>9}  {'UsesType':>8}  {'Calls':>6}  Type",
    ]
    for e in entries:
        lines.append(
            f"  {e.get('total_degree', 0):>8}  "
            f"{e.get('has_member_count', 0):>9}  "
            f"{e.get('uses_type_count', 0):>8}  "
            f"{e.get('call_via_member_cnt', 0):>6}  "
            f"{e.get('name', '?')}"
        )
    return "\n".join(lines)


def architecture_map(data):
    top = data.get("top_nodes", [])
    lines = [_kv([
        ("Damping", f"{data.get('damping', 0):.3f}"),
        ("Iterations", str(data.get("iterations_run", 0))),
        ("Converged", "yes" if data.get("converged") else "no"),
        ("Top nodes", str(len(top))),
    ])]
    if top:
        lines.append("")
        lines.append(f"  {'#':>3}  {'PageRank':>10}  {'Type':<10}  Name")
        for i, n in enumerate(top, 1):
            lines.append(
                f"  {i:>3}  {n.get('pagerank', 0):>10.5f}  "
                f"{n.get('type', '?'):<10}  {n.get('name', '?')}"
            )
    return "\n".join(lines)


def api_surface(data):
    symbols = data.get("public_symbols", [])
    lines = [_kv([
        ("Module", f"{data.get('module_name', '?')} (id {data.get('module_id', '?')})"),
        ("Public symbols", str(len(symbols))),
    ])]
    for s in symbols:
        callers = s.get("caller_modules", [])
        lines.append("")
        lines.append(
            f"  {s.get('type', '?'):<10} {s.get('name', '?')}  "
            f"(callers={s.get('external_caller_count', 0)})"
        )
        if callers:
            lines.append(f"      from: {', '.join(callers)}")
    return "\n".join(lines)


def abstractions(data):
    groups = data.get("groups", [])
    if not groups:
        return f"No candidate interfaces at min_group_size={data.get('min_group_size', '?')}."
    lines = [f"min_group_size: {data.get('min_group_size', '?')}  groups: {len(groups)}"]
    for i, g in enumerate(groups, 1):
        names = g.get("function_names", [])
        lines.append("")
        lines.append(f"  [{i}] shape: {g.get('shape', '?')}")
        lines.append(f"      functions ({len(names)}): {', '.join(names)}")
    return "\n".join(lines)


def data_flow(data):
    reached = data.get("reached", [])
    paths = data.get("paths", [])
    lines = [_kv([
        ("Source ID", str(data.get("source_id", "?"))),
        ("Direction", data.get("direction", "?")),
        ("Max depth", str(data.get("max_depth", "?"))),
        ("Reached", str(len(reached))),
        ("Truncated", "yes" if data.get("truncated") else "no"),
    ])]
    if reached:
        lines.append("")
        lines.append(f"  {'Depth':>5}  {'Type':<10}  Name")
        for n in reached:
            lines.append(
                f"  {n.get('depth', 0):>5}  "
                f"{n.get('type', '?'):<10}  {n.get('name', '?')}"
            )
    if paths:
        lines.append("")
        lines.append(f"  Paths: {len(paths)}")
        for i, p in enumerate(paths, 1):
            edges = " -> ".join(p.get("edge_types", []))
            lines.append(f"    [{i}] {edges}")
    return "\n".join(lines)


def module_topology(data):
    modules = data.get("modules", [])
    deps = data.get("deps", [])
    lines = [_kv([
        ("Modules", str(len(modules))),
        ("Dependencies", str(len(deps))),
    ])]
    if modules:
        lines.append("")
        lines.append("  Modules:")
        for m in modules:
            lines.append(f"    {m.get('name', '?')}")
    if deps:
        lines.append("")
        lines.append(f"  {'Weight':>6}  From  ->  To")
        for d in deps:
            lines.append(
                f"  {d.get('weight', 0):>6}  "
                f"{d.get('from_name', '?')}  ->  {d.get('to_name', '?')}"
            )
    return "\n".join(lines)


# -- Change Suite (Wave 2 / FG-32) --


def refactor_preview(data):
    lines = [_kv([
        ("Target", f"{data.get('target_name', '?')} "
                   f"({data.get('target_kind', '?')}, "
                   f"id {data.get('target_node_id', '?')})"),
        ("Found", "yes" if data.get("found") else "no"),
        ("Callers", str(data.get("affected_callers", 0))),
        ("Tests", str(data.get("affected_tests", 0))),
        ("Files", str(data.get("affected_files", 0))),
    ])]
    conflicts = data.get("conflicts", [])
    if conflicts:
        lines.append("")
        lines.append(f"  Rule conflicts ({len(conflicts)}):")
        for c in conflicts:
            lines.append(
                f"    {c.get('kind', '?'):<16} "
                f"{c.get('message', '')}"
            )
    return "\n".join(lines)


def breaking_change(data):
    lines = [_kv([
        ("Target", f"{data.get('target_name', '?')} "
                   f"(id {data.get('target_node_id', '?')})"),
        ("Found", "yes" if data.get("found") else "no"),
        ("Old signature", data.get("old_signature", "?")),
        ("New signature", data.get("new_signature", "?")),
        ("Breaking tests", str(data.get("breaking_tests", 0))),
    ])]
    callers = data.get("affected_callers", [])
    if callers:
        lines.append("")
        lines.append(f"  Affected callers ({len(callers)}):")
        for c in callers:
            lines.append(
                f"    {c.get('caller_name', '?'):<32} "
                f"{c.get('mismatch_description', '')}"
            )
    contras = data.get("contradictions", [])
    if contras:
        lines.append("")
        lines.append(f"  Contradictions ({len(contras)}):")
        for c in contras:
            lines.append(
                f"    {c.get('kind', '?'):<16} "
                f"{c.get('message', '')}"
            )
    return "\n".join(lines)


def deprecation_path(data):
    stages = data.get("stages", [])
    lines = [_kv([
        ("Target", f"{data.get('target_name', '?')} "
                   f"(id {data.get('target_node_id', '?')})"),
        ("Found", "yes" if data.get("found") else "no"),
        ("Stages", str(len(stages))),
    ])]
    if stages:
        lines.append("")
        lines.append(f"  {'Order':>5}  {'Depth':>5}  {'Action':<8}  Caller")
        for s in stages:
            lines.append(
                f"  {s.get('order', 0):>5}  "
                f"{s.get('depth', 0):>5}  "
                f"{s.get('action', '?'):<8}  "
                f"{s.get('caller_name', '?')}"
            )
    final = data.get("final_stage") or {}
    if final.get("action"):
        lines.append("")
        lines.append(
            f"  Final: {final.get('action', '?')} "
            f"{final.get('caller_name', '?')}"
        )
        if final.get("action_message"):
            lines.append(f"    {final['action_message']}")
    return "\n".join(lines)


def risky_change(data):
    bd = data.get("breakdown", {})
    lines = [_kv([
        ("Commit", data.get("commit_sha", "?")),
        ("Score", f"{data.get('score', 0):.3f}"),
        ("Touched", str(data.get("touched_count", 0))),
        ("Thermal mean", f"{bd.get('thermal_mean', 0):.3f}"),
        ("Pattern rate", f"{bd.get('pattern_rate', 0):.3f}"),
        ("Rule rate", f"{bd.get('rule_rate', 0):.3f}"),
    ])]
    rv = data.get("rule_violations", [])
    if rv:
        lines.append("")
        lines.append(f"  Rule violations ({len(rv)}):")
        for v in rv:
            lines.append(
                f"    {v.get('action', '?'):<8} "
                f"{v.get('rule_name', '?'):<24} "
                f"{v.get('message', '')}"
            )
    pv = data.get("pattern_violations", [])
    if pv:
        lines.append("")
        lines.append(f"  Pattern drifts ({len(pv)}):")
        for p in pv:
            lines.append(
                f"    node {p.get('touched_node_id', '?'):<8} "
                f"drifted-from pattern {p.get('drifted_pattern_id', '?')}"
            )
    return "\n".join(lines)


def commit_impact(data):
    cs = data.get("cascade_summary", {})
    lines = [_kv([
        ("Commit", data.get("commit_sha", "?")),
        ("Touched", str(data.get("touched_count", 0))),
        ("Direct", str(cs.get("total_direct", 0))),
        ("Transitive", str(cs.get("total_transitive", 0))),
        ("Modules affected", str(cs.get("modules_affected", 0))),
        ("Files affected", str(cs.get("files_affected", 0))),
    ])]
    contras = data.get("contradictions", [])
    if contras:
        lines.append("")
        lines.append(f"  Contradictions ({len(contras)}):")
        for c in contras:
            lines.append(
                f"    {c.get('kind', '?'):<16} "
                f"{c.get('message', '')}"
            )
    return "\n".join(lines)


def commit_review(data):
    si = data.get("structural_impact", {}) or {}
    cs = si.get("cascade_summary", {}) or {}
    lines = [_kv([
        ("Commit", data.get("commit_sha", "?")),
        ("Risk score", f"{data.get('risk_score', 0):.3f}"),
        ("Touched", str(data.get("touched_count", 0))),
        ("Direct", str(cs.get("total_direct", 0))),
        ("Transitive", str(cs.get("total_transitive", 0))),
        ("Modules affected", str(cs.get("modules_affected", 0))),
        ("Files affected", str(cs.get("files_affected", 0))),
    ])]
    contras = data.get("contradictions", [])
    if contras:
        lines.append("")
        lines.append(f"  Contradictions ({len(contras)}):")
        for c in contras:
            lines.append(
                f"    {c.get('kind', '?'):<16} "
                f"{c.get('message', '')}"
            )
    rv = data.get("rule_violations", [])
    if rv:
        lines.append("")
        lines.append(f"  Rule violations ({len(rv)}):")
        for v in rv:
            lines.append(
                f"    {v.get('action', '?'):<8} "
                f"{v.get('rule_name', '?'):<24} "
                f"{v.get('message', '')}"
            )
    pa = data.get("pattern_alignment", [])
    if pa:
        lines.append("")
        lines.append(f"  Pattern alignment ({len(pa)}):")
        for e in pa:
            lines.append(
                f"    {e.get('node_name', '?'):<32} "
                f"~ {e.get('pattern_name', '?'):<24} "
                f"sim={e.get('similarity', 0):.3f}"
            )
    focus = data.get("recommended_focus_areas", [])
    if focus:
        lines.append("")
        lines.append(f"  Recommended focus areas ({len(focus)}):")
        for f in focus:
            lines.append(f"    - {f}")
    return "\n".join(lines)


# -- Admin --


def tenant_created(data):
    lines = [
        "Tenant created:",
        "",
        _kv([
            ("ID", data.get("id", "?")),
            ("Name", data.get("name", "?")),
            ("Tier", f"{data.get('tier', '?')} ({data.get('tier_level', '?')})"),
            ("API Key", data.get("api_key", "?")),
        ]),
    ]
    return "\n".join(lines)


def tenant_list(data):
    if not data:
        return "No tenants."
    lines = [f"  {'ID':<20} {'Name':<20} {'Tier':<10} {'Revoked':<8}"]
    for t in data:
        lines.append(
            f"  {t.get('id', '?'):<20} "
            f"{t.get('name', '?'):<20} "
            f"{t.get('tier', '?'):<10} "
            f"{'yes' if t.get('revoked') else 'no':<8}"
        )
    return "\n".join(lines)


def tenant_revoked(data):
    return f"Tenant {data.get('tenant_id', '?')} revoked."


def patterns_learned(data):
    return _kv([
        ("Created", str(data.get("patterns_created", 0))),
        ("Updated", str(data.get("patterns_updated", 0))),
        ("Promoted", str(data.get("patterns_promoted", 0))),
        ("Total", str(data.get("total_patterns", 0))),
    ])
