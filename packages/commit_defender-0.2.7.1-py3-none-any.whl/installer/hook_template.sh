#!/usr/bin/env sh
# commit-defender pre-commit hook
# Installed by: commit-defender install
# To bypass (not recommended): git commit --no-verify

set -e

REPO_ROOT="$(git rev-parse --show-toplevel)"
STAGED="$(git diff --cached --name-only --diff-filter=ACMR)"

[ -z "$STAGED" ] && exit 0

PYTHON="${COMMIT_DEFENDER_PYTHON:-{{PYTHON}}}"

if ! command -v "${PYTHON}" >/dev/null 2>&1; then
    echo "commit-defender: python not found at '${PYTHON}' — skipping." >&2
    exit 0
fi

export CD_REPO_PATH="${REPO_ROOT}"
export CD_STAGED_FILES="${STAGED}"

"${PYTHON}" -m commit_defender.entrypoint 1>&2
exit $?
