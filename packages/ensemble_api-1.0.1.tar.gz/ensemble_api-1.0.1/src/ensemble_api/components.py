"""
# ensemble_api - Modular Meta-compiler Framework.
# Copyright (C) 2026 MGoosePlayZ
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 3 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, see <https://www.gnu.org/licenses/>.
"""

import numpy as np
from .errors import *

class RegisterFile:
    def __init__(self, size_regs:int, has_zero_reg:bool=True):
        """
        Fixed width array of numbers.
        :param size_regs: Size of the array. Must be a power of 2.
        """
        if (size_regs > 0 and (size_regs & (size_regs - 1))) != 0:
            raise ValueError(f"Size must be a power of 2 (received {size_regs}).")
        self.file = np.zeros(size_regs, dtype=np.int64)
        self.has_zero_reg = has_zero_reg

    def __getitem__(self, item):
        if isinstance(item, int) and not (0 <= item < len(self.file)):
            raise IndexError("Register index out of bounds.")
        return self.file[item]

    def __setitem__(self, key, value):
        if key == 0 and self.has_zero_reg:
            return
        if isinstance(key, int) and not (0 <= key < len(self.file)):
            raise IndexError("Register index out of bounds.")
        self.file[key] = value

    def __delitem__(self, key):
        self.file[key] = 0

    def __len__(self):
        return len(self.file)

    def __iter__(self):
        return iter(self.file)

    def __repr__(self):
        return f"RegisterFile(size={len(self.file)})"

    def __str__(self):
        return f"[{", ".join(str(int(val)) for val in self.file)}]"

    def __contains__(self, item):
        return 0 <= item < len(self.file)

    def __reversed__(self):
        for reg in reversed(self.file):
            yield reg

    def reset(self):
        """Resets all registers to 0."""
        self.file.fill(0)

    def dump(self) -> dict:
        """Returns a dictionary representation of the current state."""
        return {f"R{i}": int(val) for i, val in enumerate(self.file)}


class AccessMemory:
    def __init__(self, size_bytes: int):
        """
        Byte-addressable memory array.
        :param size_bytes: Total size of memory in bytes. Must be a power of 2.
        """
        if (size_bytes > 0 and (size_bytes & (size_bytes - 1))) != 0:
            raise ValueError(f"Size must be a power of 2 (received {size_bytes}).")
        self.size_bytes = size_bytes
        self.memory = np.zeros(size_bytes, dtype=np.uint8)

    def __delitem__(self, key):
        self.memory[key] = 0

    def __len__(self):
        return len(self.memory)

    def __iter__(self):
        return iter(self.memory)

    def __repr__(self):
        return f"AccessMemory(size={len(self.memory)})"

    def __str__(self):
        if len(self.memory) > 32:
            return f"[{', '.join(str(int(v)) for v in self.memory[:16])} ... {', '.join(str(int(v)) for v in self.memory[-16:])}]"
        return f"[{', '.join(str(int(val)) for val in self.memory)}]"

    def __contains__(self, item):
        return 0 <= item < len(self.memory)

    def __reversed__(self):
        for mem in reversed(self.memory):
            yield mem

    def read_byte(self, address: int):
        return int(self.memory[address])

    def write_byte(self, address: int, value: int):
        self.memory[address] = value & 0xFF

    def read_word(self, address: int, byte_width: int = 4):
        if not (0 <= address <= self.size_bytes - byte_width):
            raise SegFaultError(f"Out of bounds word read ({address + byte_width})")
        bytes_data = self.memory[address: address + byte_width]
        return int.from_bytes(bytes_data, signed=False, byteorder='little')

    def write_word(self, address: int, value: int, byte_width: int = 4):
        if not (0 <= address <= self.size_bytes - byte_width):
            raise SegFaultError(f"Out of bounds word write ({address + byte_width})")
        bytes_data = int.to_bytes(value & ((1 << (byte_width * 8)) - 1), byte_width, byteorder='little',)
        self.memory[address: address + byte_width] = np.frombuffer(bytes_data, dtype=np.uint8)

    def reset(self):
        self.memory.fill(0)

class CallStack:
    def __init__(self, size_nodes):
        if size_nodes <= 0 or (size_nodes & (size_nodes - 1)) != 0:
            raise ValueError(f"Size must be a power of 2 (received {size_nodes}).")
        self.stack = np.zeros(size_nodes, dtype=np.uint64)
        self.size_nodes = size_nodes
        self.pointer = 0

    def __getitem__(self, item):
        if isinstance(item, int) and not (0 <= item < len(self.stack)):
            raise IndexError("Stack index out of bounds.")
        return self.stack[item]

    def __setitem__(self, key, value):
        if isinstance(key, int) and not (0 <= key < len(self.stack)):
            raise IndexError("Stack index out of bounds.")
        self.stack[key] = value

    def __delitem__(self, key):
        self.stack[key] = 0

    def __len__(self):
        return len(self.stack)

    def __iter__(self):
        return iter(self.stack)

    def __repr__(self):
        return f"CallStack(size={len(self.stack)})"

    def __str__(self):
        return f"[{", ".join(str(int(val)) for val in self.stack)}]"

    def __contains__(self, item):
        return 0 <= item < len(self.stack)

    def __reversed__(self):
        for mem in reversed(self.stack):
            yield mem

    def push(self, value):
        if self.pointer >= self.size_nodes:
            raise StackOverflowError(f"Cannot push to node {self.size_nodes}.")
        self.stack[self.pointer] = value
        self.pointer += 1

    def pop(self):
        if self.pointer <= 0:
            raise StackUnderflowError("Cannot pop from an empty stack.")
        self.pointer -= 1
        return self.stack[self.pointer]

    def peek(self):
        if self.pointer <= 0:
            raise StackUnderflowError("Cannot peek at an empty stack.")
        return self.stack[self.pointer - 1]

class Program:
    def __init__(self, file):
        self.code = []
        self.counter = 0
        self.context = {}
        for line in file.splitlines():
            self.code.append(line)

    def __getitem__(self, item):
        return self.code[item]

    def __setitem__(self, key, value):
        self.code[key] = value

    def __delitem__(self, key):
        del self.code[key]

    def __len__(self):
        return len(self.code)

    def __iter__(self):
        return iter(self.code)

    def __repr__(self):
        return f"Program(file={"\n".join(str(item) for item in self.code)})"

    def __str__(self):
        return "\n".join(str(item) for item in self.code)

    def __contains__(self, item):
        return 0 <= item < len(self.code)

    def __reversed__(self):
        for line in reversed(self.code):
            yield line

    def current(self):
        return self.code[self.counter]

    def increment(self):
        self.counter += 1

    def decrement(self):
        self.counter -= 1

    def set(self, line):
        self.counter = line

    def read(self, line):
        return self.code[line]

    def line_num(self):
        return self.counter

    def num_lines(self):
        return len(self.code)

    def run(self):
        self.context["program"] = self

        while True:
            try:
                line_of_code = self.current()
                if line_of_code.strip():
                    exec(line_of_code, self.context)
                if self.current() == line_of_code:
                    self.increment()

            except IndexError:
                break