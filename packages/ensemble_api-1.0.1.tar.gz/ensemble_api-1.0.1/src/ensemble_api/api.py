"""
# ensemble_api - Modular Meta-compiler Framework.
# Copyright (C) 2026 MGoosePlayZ
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 3 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, see <https://www.gnu.org/licenses/>.
"""

import re, shlex
from . import errors

from .components import Program

def tokenize(line: str) -> list:
    lexer = shlex.shlex(line, posix=False)
    lexer.quotes = '"\''
    lexer.wordchars += "'-"
    lexer.commenters = ""
    try:
        return list(lexer)
    except ValueError:
        return line.split()

def validate_opcode(tokens: list, schema: dict) -> bool:
    if not tokens:
        return True
    return tokens[0] in schema

def validate_input_num(tokens: list, schema: dict) -> bool:
    if not tokens or tokens[0] not in schema:
        return False
    expected_types = schema[tokens[0]][0]
    if expected_types == 'a':
        return True
    return len(tokens) == len(expected_types) + 1

def validate_register(text: str) -> bool:
    return bool(re.fullmatch(r"^r\d+$", text))

def validate_immediate(text: str) -> bool:
    return bool(re.fullmatch(r"^-?\d+$", text))


def validate_string(text: str) -> bool:
    if not isinstance(text, str):
        return False
    is_double_quoted = text.startswith('"') and text.endswith('"')
    is_single_quoted = text.startswith("'") and text.endswith("'")
    return is_double_quoted or is_single_quoted

def validate_input_type(tokens: list, schema: dict) -> bool:
    if not tokens or tokens[0] not in schema:
        return False

    expected_types = schema[tokens[0]][0]
    args = tokens[1:]

    if expected_types == 'a':
        return True

    if len(args) != len(expected_types):
        return False

    for arg, t_type in zip(args, expected_types):
        if t_type == 'r' and not validate_register(arg):
            return False
        elif t_type == 'i' and not validate_immediate(arg):
            return False
        elif t_type == 's' and not validate_string(arg):
            return False
    return True

def validate_syntax(tokens: list, schema: dict) -> bool:
    if not tokens:
        return True
    if not validate_opcode(tokens, schema):
        return False
    if not validate_input_num(tokens, schema):
        return False
    if not validate_input_type(tokens, schema):
        return False
    return True

def compile_regs(tokens: list) -> list:
    converted = []
    for tok in tokens:
        if validate_register(tok):
            converted.append(re.sub(r'\br(\d+)\b', r'reg[\1]', tok))
        else:
            converted.append(tok)
    return converted

def compile_toks(tokens: list, schema: dict) -> str:
    if not tokens:
        return ""
    opcode = tokens[0]
    if not validate_opcode(tokens, schema):
        raise errors.OpcodeError(f"Unknown opcode: {opcode}")

    expected_types = schema[opcode][0]
    template = schema[opcode][1]
    converted_tokens = compile_regs(tokens)
    args = converted_tokens[1:]

    if expected_types == 'a':
        combined_args = " ".join(args)
        return template.format(combined_args)

    return template.format(*args)

def compile_line(line: str, schema: dict) -> str:
    tokens = tokenize(line)
    if not validate_syntax(tokens, schema):
        raise SyntaxError(f"Invalid syntax in '{line}'")
    return compile_toks(tokens, schema)

def compile_code(code: str, schema: dict) -> Program:
    compiled = """"""
    compiled += f"{schema["$STARTUP$"]}\n"
    for line in code.splitlines():
        compiled += f"{compile_line(line, schema)}\n"
    compiled += f"{schema["$SHUTOFF$"]}\n"
    return Program(compiled)