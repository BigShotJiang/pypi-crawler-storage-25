"""
# ensemble_api - Modular Meta-compiler Framework.
# Copyright (C) 2026 MGoosePlayZ
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 3 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, see <https://www.gnu.org/licenses/>.
"""

class StackOverflowError(OverflowError):
    """Raised when attempting to push to a full bounded stack."""
    pass

class StackUnderflowError(IndexError):
    """Raised when popping or peeking from an empty stack."""
    pass

class SegFaultError(IndexError):
    """Raised when trying to write to inaccessible memory."""
    pass

class OpcodeError(NameError):
    """Raised when an invalid opcode is called"""
    pass

class LexError(ValueError):
    """Raised when an exception happened during lexing."""
    pass

class ParseError(ValueError):
    """Raised when an exception happened during parsing."""
    pass