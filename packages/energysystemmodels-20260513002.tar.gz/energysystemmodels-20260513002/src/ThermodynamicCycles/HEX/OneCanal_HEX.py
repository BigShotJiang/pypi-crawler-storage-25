"""HEX_OneCanal -- echangeur a un seul canal couple a une paroi a temperature
fixee (Modelica HeatExchanger.HEX_OneCanal.HEX_OneCanal).

Un fluide circule dans un canal et echange de la chaleur avec une paroi a
temperature T_wall imposee. La puissance echangee est calculee par UA*LMTD.

Equations :
    Q_flow = U * A * LMTD
    LMTD = (dT_left - dT_right) / ln(dT_left / dT_right)
    dT_left  = T_wall - T_a   (entree)
    dT_right = T_wall - T_b   (sortie)
    Bilan energie : Q_flow = m_flow * (h_b - h_a)
    Sans perte de charge : P_b = P_a

Comme T_b est inconnu, le systeme est implicite : on resout par iteration
de point fixe (h_b -> T_b -> LMTD -> Q -> h_b).

Convention Python :
    Inlet   -> port_a (entree fluide)
    Outlet  -> port_b (sortie fluide)
    T_wall_degC : temperature de la paroi (degC)
"""

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort
from CoolProp.CoolProp import PropsSI
import math
import pandas as pd


class Object:
    def __init__(self):
        self.Timestamp = None

        self.Inlet = FluidPort()
        self.Outlet = FluidPort()

        # Parametres
        self.U = 100.0                # W/m2/K
        self.A = 1.0                  # m2
        self.T_wall_degC = 100.0      # paroi
        self.max_iter = 50
        self.tol = 1e-3               # K

        # Sorties
        self.Q_flow_W = None
        self.LMTD = None
        self.Ti_degC = None
        self.To_degC = None
        self.df = []

    def calculate(self):
        fluid = self.Inlet.fluid
        P = self.Inlet.P
        h_a = self.Inlet.h
        m = self.Inlet.F if self.Inlet.F is not None else 0.0

        T_a = PropsSI('T', 'P', P, 'H', h_a, fluid)
        T_w = self.T_wall_degC + 273.15

        UA = self.U * self.A

        # Initialisation : T_b = T_a (pas d'echange)
        T_b = T_a
        h_b = h_a
        Q = 0.0

        if m > 1e-9:
            for _ in range(self.max_iter):
                dT_l = T_w - T_a
                dT_r = T_w - T_b

                # LMTD avec protection (regularisation pour dT_l ~ dT_r)
                if abs(dT_l - dT_r) < 1e-6:
                    LMTD = 0.5 * (dT_l + dT_r)
                elif dT_l * dT_r <= 0:
                    # Croisement : impossible physiquement, on plafonne
                    LMTD = 0.5 * (dT_l + dT_r)
                else:
                    LMTD = (dT_l - dT_r) / math.log(dT_l / dT_r)

                Q = UA * LMTD
                h_b_new = h_a + Q / m
                T_b_new = PropsSI('T', 'P', P, 'H', h_b_new, fluid)

                if abs(T_b_new - T_b) < self.tol:
                    T_b = T_b_new
                    h_b = h_b_new
                    break
                T_b = T_b_new
                h_b = h_b_new

        self.LMTD = (T_w - T_a + T_w - T_b) / 2 if m <= 1e-9 else None
        self.Q_flow_W = Q

        self.Outlet.fluid = fluid
        self.Outlet.P = P
        self.Outlet.h = h_b
        self.Outlet.F = m

        self.Ti_degC = T_a - 273.15
        self.To_degC = T_b - 273.15

        self.df = pd.DataFrame(
            {'HEX_OneCanal': [self.Timestamp, fluid, m, self.Ti_degC,
                              self.To_degC, self.T_wall_degC,
                              Q / 1000.0, UA]},
            index=['Timestamp', 'fluid', 'F_kgs', 'Ti_degC', 'To_degC',
                   'Twall_degC', 'Q_kW', 'UA_WK'])
