"""HEX_Pinch_Monophasic -- echangeur monophasique dimensionne par contrainte de pincement
(Modelica HeatExchanger.HEX_Pinch.HEX_Pinch_Monophasic).

PROBLEME DE DESIGN : on connait les debits et les temperatures d'entree des deux
fluides, on impose une valeur cible de pincement (delta T minimum), et on
calcule la surface d'echange A necessaire.

Distinct de :
- NUT_HEX (UA impose -> calcule T outlets, problème opérationnel)
- DTLM_HEX (T outlets imposes -> calcule UA, problème inverse explicite)
- Pinch_Monophasic (pinch impose -> calcule T outlets puis A, problème de dimensionnement)

Equations :
    pinch = min(dT_left, dT_right) ou contrainte sur un cote (selon pinch_loc)
        dT_left  = T2a - T1b   (= T_hot_in - T_cold_out, cote gauche)
        dT_right = T2b - T1a   (= T_hot_out - T_cold_in, cote droit)
    Q = m1 * Cp1 * (T1b - T1a) = m2 * Cp2 * (T2a - T2b)
    LMTD = (dT_left - dT_right) / ln(dT_left / dT_right)
    A = Q / (U * LMTD)

Convention pinch_loc :
- "left"  : pinch a gauche (Side1b2a) -> T1b = T2a - pinch
- "right" : pinch a droite (Side1a2b) -> T2b = T1a + pinch
- "auto"  : on essaie les deux et on prend celui qui donne A > 0 le plus grand
            (= la situation la plus contraignante)

Convention Python (NUT_HEX style : Inlet1=chaud, Inlet2=froid -- inverse Modelica
mais aligne sur NUT_HEX existant pour homogeneite de la bibliotheque) :
    Inlet1, Outlet1 : canal chaud
    Inlet2, Outlet2 : canal froid
"""

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort
from CoolProp.CoolProp import PropsSI
import math
import pandas as pd


class Object:
    def __init__(self):
        self.Timestamp = None

        self.Inlet1 = FluidPort()       # canal chaud
        self.Outlet1 = FluidPort()
        self.Inlet2 = FluidPort()       # canal froid
        self.Outlet2 = FluidPort()

        # Parametres design
        self.U = 200.0                  # W/m2/K
        self.pinch = 5.0                # K -- delta T minimum cible
        self.pinch_loc = "auto"         # "left", "right", "auto"

        # Sorties
        self.A = None                   # m2 -- surface calculee
        self.Q_flow = None              # W
        self.LMTD = None                # K
        self.dT_left = None             # T2a - T1b
        self.dT_right = None            # T2b - T1a
        self.df = []

    def _solve_for_loc(self, T1a, T2a, m1, m2, cp1, cp2, loc):
        """Resout pour une localisation du pinch donnee.
        Convention : Inlet1=chaud (T1a > T2a), Inlet2=froid.
        En contre-courant :
          dT_left  = T1b - T2a  (cote ou le chaud sort, le froid entre)
          dT_right = T1a - T2b  (cote ou le chaud entre, le froid sort)
        Renvoie (A, Q, LMTD, dT_l, dT_r, T1b, T2b) ou None."""
        if loc == "left":
            # Pinch sur le cote gauche : dT_left = pinch -> T1b = T2a + pinch
            T1b = T2a + self.pinch
            Q = m1 * cp1 * (T1a - T1b)        # > 0 si T1a > T1b (chaud cede chaleur)
            if Q <= 0:
                return None
            T2b = T2a + Q / (m2 * cp2)
            dT_l = T1b - T2a
            dT_r = T1a - T2b
        elif loc == "right":
            # Pinch sur le cote droit : dT_right = pinch -> T2b = T1a - pinch
            T2b = T1a - self.pinch
            Q = m2 * cp2 * (T2b - T2a)        # > 0 si T2b > T2a (froid recoit chaleur)
            if Q <= 0:
                return None
            T1b = T1a - Q / (m1 * cp1)
            dT_l = T1b - T2a
            dT_r = T1a - T2b
        else:
            return None

        # Verification physique : le pinch doit etre respecte des deux cotes
        if dT_l < self.pinch - 1e-6 or dT_r < self.pinch - 1e-6:
            return None  # pinch viole de l'autre cote -> pas la bonne loc

        if abs(dT_l - dT_r) < 1e-6:
            LMTD = 0.5 * (dT_l + dT_r)
        elif dT_l <= 0 or dT_r <= 0:
            return None
        else:
            LMTD = (dT_l - dT_r) / math.log(dT_l / dT_r)

        if LMTD <= 0:
            return None

        A = Q / (self.U * LMTD)
        return (A, Q, LMTD, dT_l, dT_r, T1b, T2b)

    def calculate(self):
        f1 = self.Inlet1.fluid
        f2 = self.Inlet2.fluid
        P1 = self.Inlet1.P
        P2 = self.Inlet2.P
        h1a = self.Inlet1.h
        h2a = self.Inlet2.h
        m1 = self.Inlet1.F if self.Inlet1.F is not None else 0.0
        m2 = self.Inlet2.F if self.Inlet2.F is not None else 0.0

        T1a = PropsSI('T', 'P', P1, 'H', h1a, f1)
        T2a = PropsSI('T', 'P', P2, 'H', h2a, f2)

        if T1a <= T2a + self.pinch:
            raise ValueError(
                f"HEX_Pinch_Monophasic : T1a={T1a-273.15:.1f}°C doit > "
                f"T2a={T2a-273.15:.1f}°C + pinch={self.pinch}K")

        cp1 = PropsSI('C', 'P', P1, 'H', h1a, f1)
        cp2 = PropsSI('C', 'P', P2, 'H', h2a, f2)

        if self.pinch_loc == "auto":
            sol_left = self._solve_for_loc(T1a, T2a, m1, m2, cp1, cp2, "left")
            sol_right = self._solve_for_loc(T1a, T2a, m1, m2, cp1, cp2, "right")
            candidates = [s for s in (sol_left, sol_right) if s is not None]
            if not candidates:
                raise ValueError("HEX_Pinch_Monophasic : aucune solution physique")
            # Prendre celui qui demande la plus grande surface
            # (= configuration realiste / la plus contraignante)
            sol = max(candidates, key=lambda s: s[0])
        else:
            sol = self._solve_for_loc(T1a, T2a, m1, m2, cp1, cp2, self.pinch_loc)
            if sol is None:
                raise ValueError(
                    f"HEX_Pinch_Monophasic : pinch_loc={self.pinch_loc} infaisable")

        self.A, self.Q_flow, self.LMTD, self.dT_left, self.dT_right, T1b, T2b = sol

        # Sorties FluidPort
        h1b = h1a - self.Q_flow / m1
        h2b = h2a + self.Q_flow / m2

        self.Outlet1.fluid = f1
        self.Outlet1.P = P1
        self.Outlet1.h = h1b
        self.Outlet1.F = m1
        self.Outlet2.fluid = f2
        self.Outlet2.P = P2
        self.Outlet2.h = h2b
        self.Outlet2.F = m2

        self.df = pd.DataFrame(
            {'HEX_Pinch_Monophasic': [
                self.Timestamp, f1, f2, m1, m2,
                T1a - 273.15, T1b - 273.15, T2a - 273.15, T2b - 273.15,
                self.Q_flow / 1000.0, self.LMTD,
                self.dT_left, self.dT_right, self.pinch,
                self.A]},
            index=['Timestamp', 'fluid_hot', 'fluid_cold', 'm_hot_kgs', 'm_cold_kgs',
                   'T1a_degC', 'T1b_degC', 'T2a_degC', 'T2b_degC',
                   'Q_kW', 'LMTD_K', 'dT_left_K', 'dT_right_K', 'pinch_K',
                   'A_m2'])
