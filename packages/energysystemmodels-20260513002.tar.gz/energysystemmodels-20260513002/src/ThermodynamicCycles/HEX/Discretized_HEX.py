"""HEX_Discretized -- echangeur contre-courant discretise en N noeuds
(Modelica HeatExchanger.HEX_discretized).

Le HEX est decoupe en N volumes finis. Chaque noeud du canal 1 (froid) echange
de la chaleur avec le noeud correspondant du canal 2 (chaud) en convention
contre-courant. Cette discretisation permet de capturer le changement de phase
et les profils de temperature non-lineaires.

Equations (regime permanent, par noeud i, contre-courant) :
    Q_i = UA/N * (T2_i - T1_i)            (avec T1_i en partant de port_a1, T2_i de port_b2)
    h1_{i+1} = h1_i + Q_i / m_1
    h2_i = h2_{i+1} + Q_i / m_2

On resout iterativement en partant des conditions aux limites :
  h1_0 = Inlet1.h (entree froide a gauche)
  h2_N = Inlet2.h (entree chaude a droite, sort a gauche)

Convention Python :
    Inlet1, Outlet1 : canal 1 froid (gauche -> droite)
    Inlet2, Outlet2 : canal 2 chaud (droite -> gauche, contre-courant)
"""

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort
from CoolProp.CoolProp import PropsSI
import pandas as pd


class Object:
    def __init__(self):
        self.Timestamp = None

        self.Inlet1 = FluidPort()
        self.Outlet1 = FluidPort()
        self.Inlet2 = FluidPort()
        self.Outlet2 = FluidPort()

        # Parametres
        self.U = 200.0                # W/m2/K
        self.A = 10.0                 # m2 totale
        self.N = 10                   # nombre de noeuds
        self.max_iter = 200
        self.tol = 1e-3               # K

        # Sorties
        self.Q_total_W = None
        self.T1_profile_degC = None   # liste N+1 temperatures canal 1
        self.T2_profile_degC = None   # liste N+1 temperatures canal 2
        self.df = []

    def calculate(self):
        f1 = self.Inlet1.fluid
        f2 = self.Inlet2.fluid
        P1 = self.Inlet1.P
        P2 = self.Inlet2.P
        h1_in = self.Inlet1.h
        h2_in = self.Inlet2.h
        m1 = self.Inlet1.F if self.Inlet1.F is not None else 0.0
        m2 = self.Inlet2.F if self.Inlet2.F is not None else 0.0
        N = self.N

        UA_per_node = self.U * self.A / N

        if m1 < 1e-9 or m2 < 1e-9 or UA_per_node <= 0:
            self.Q_total_W = 0.0
            self.Outlet1.fluid = f1
            self.Outlet1.P = P1
            self.Outlet1.h = h1_in
            self.Outlet1.F = m1
            self.Outlet2.fluid = f2
            self.Outlet2.P = P2
            self.Outlet2.h = h2_in
            self.Outlet2.F = m2
            return

        # Initialisation : profils lineaires
        T1_in = PropsSI('T', 'P', P1, 'H', h1_in, f1)
        T2_in = PropsSI('T', 'P', P2, 'H', h2_in, f2)

        # h_canal1[i] : enthalpie au noeud i (i=0..N), 0 = entree, N = sortie
        # h_canal2[i] : enthalpie au noeud i, mais physiquement le canal 2 va de droite (i=N, entree)
        #              vers gauche (i=0, sortie).
        h1 = [h1_in] * (N + 1)
        # estimation initiale : on affecte une valeur intermediaire
        cp2 = PropsSI('C', 'P', P2, 'H', h2_in, f2)
        h2 = [h2_in] * (N + 1)

        for it in range(self.max_iter):
            h1_new = [h1_in] + [0.0] * N
            h2_new = [0.0] * N + [h2_in]

            # March from left to right for canal 1, from right to left for canal 2
            # On utilise les valeurs courantes pour calculer Q_i
            # Q_i echange entre noeud "i" du canal 1 (cote froid) et noeud "i" du canal 2
            # alignement contre-courant : noeud i correspond a la meme abscisse spatiale

            # Pour chaque element i (1..N), Q_i = UA/N * (T2_i_avg - T1_i_avg)
            # ou T*_i_avg = avg de T*_{i-1} et T*_i
            # Iteration : on passe de h1[i-1] a h1[i] et de h2[i] a h2[i-1]

            T1 = [PropsSI('T', 'P', P1, 'H', max(h1[i], 1.0), f1) for i in range(N + 1)]
            T2 = [PropsSI('T', 'P', P2, 'H', max(h2[i], 1.0), f2) for i in range(N + 1)]

            # Marche canal 1 : de gauche (0) a droite (N)
            for i in range(1, N + 1):
                # element i: entre noeud i-1 et noeud i sur canal 1
                # alignement contre-courant : meme element pour canal 2 entre noeud i et noeud i-1
                T1_avg = 0.5 * (T1[i - 1] + T1[i])
                T2_avg = 0.5 * (T2[i - 1] + T2[i])
                Q_i = UA_per_node * (T2_avg - T1_avg)
                h1_new[i] = h1_new[i - 1] + Q_i / m1

            # Marche canal 2 : de droite (N) a gauche (0)
            for i in range(N - 1, -1, -1):
                T1_avg = 0.5 * (T1[i] + T1[i + 1])
                T2_avg = 0.5 * (T2[i] + T2[i + 1])
                Q_i = UA_per_node * (T2_avg - T1_avg)
                h2_new[i] = h2_new[i + 1] + Q_i / m2

            # Test convergence
            max_dh = max(abs(h1_new[i] - h1[i]) for i in range(N + 1))
            max_dh = max(max_dh, max(abs(h2_new[i] - h2[i]) for i in range(N + 1)))

            # Relaxation
            alpha = 0.5
            h1 = [(1 - alpha) * h1[i] + alpha * h1_new[i] for i in range(N + 1)]
            h2 = [(1 - alpha) * h2[i] + alpha * h2_new[i] for i in range(N + 1)]

            if max_dh < self.tol * 4180:  # tol en K * Cp ~ tol en J/kg
                break

        # Profils
        T1 = [PropsSI('T', 'P', P1, 'H', max(h1[i], 1.0), f1) for i in range(N + 1)]
        T2 = [PropsSI('T', 'P', P2, 'H', max(h2[i], 1.0), f2) for i in range(N + 1)]
        self.T1_profile_degC = [t - 273.15 for t in T1]
        self.T2_profile_degC = [t - 273.15 for t in T2]

        # Energie totale
        self.Q_total_W = m1 * (h1[N] - h1[0])

        # Connecteurs sortie
        self.Outlet1.fluid = f1
        self.Outlet1.P = P1
        self.Outlet1.h = h1[N]
        self.Outlet1.F = m1
        self.Outlet2.fluid = f2
        self.Outlet2.P = P2
        self.Outlet2.h = h2[0]
        self.Outlet2.F = m2

        self.df = pd.DataFrame(
            {'HEX_Discretized': [self.Timestamp, f1, f2, m1, m2, N,
                                 T1[0] - 273.15, T1[N] - 273.15,
                                 T2[N] - 273.15, T2[0] - 273.15,
                                 self.Q_total_W / 1000.0, self.U * self.A]},
            index=['Timestamp', 'fluid1', 'fluid2', 'F1_kgs', 'F2_kgs', 'N',
                   'T1in_degC', 'T1out_degC', 'T2in_degC', 'T2out_degC',
                   'Q_kW', 'UA_WK'])
