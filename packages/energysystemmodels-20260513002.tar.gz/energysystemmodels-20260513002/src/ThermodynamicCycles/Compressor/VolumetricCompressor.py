"""VolumetricCompressor -- compresseur volumetrique (Modelica RotatingMachines.Compressor).

Le debit massique est determine par la cylindree, la frequence de rotation et
la masse volumique d'aspiration : m_flow = epsilon_v * V_s * f_rotor * rho_a
La compression est isentropique avec rendement epsilon_s.

Equations :
    V_dot = epsilon_v * V_s * f_rotor              (debit volumique aspiration)
    m_flow = V_dot * rho(state_a)                  (debit massique)
    h_iso_b = h(P_b, S_a)                          (etat isentropique)
    h_b = h_a + (h_iso_b - h_a) / epsilon_s        (compression reelle)
    P_ext = m_flow * (h_b - h_a)                   (puissance arbre)

Convention Python :
    Inlet  -> port_a (aspiration)
    Outlet -> port_b (refoulement)
    L'utilisateur impose : Inlet (fluide, P, h), Outlet.P, V_s, f_rotor
    Le composant calcule : m_flow, Outlet.h, P_ext
"""

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort
from CoolProp.CoolProp import PropsSI
import pandas as pd


class Object:
    def __init__(self):
        self.Timestamp = None

        self.Inlet = FluidPort()
        self.Outlet = FluidPort()

        # Parametres
        self.epsilon_v = 1.0          # rendement volumetrique
        self.epsilon_s = 0.7          # rendement isentropique
        self.V_s = 1e-4               # cylindree (m3)
        self.f_rotor = 50.0           # frequence rotor (Hz)

        # Sorties
        self.V_dot_su = None          # debit volumique aspiration (m3/s)
        self.m_flow = None            # debit massique (kg/s)
        self.P_ext = None             # puissance arbre (W)
        self.Q_losses = None          # pertes (W) = m_flow*(h_iso - h_b) si refroidi
        self.T_iso_K = None           # temp refoulement isentropique
        self.T_out_K = None           # temp refoulement reelle
        self.df = []

    def calculate(self):
        fluid = self.Inlet.fluid
        P_a = self.Inlet.P
        h_a = self.Inlet.h
        P_b = self.Outlet.P

        # Etat aspiration
        rho_a = PropsSI('D', 'P', P_a, 'H', h_a, fluid)
        S_a = PropsSI('S', 'P', P_a, 'H', h_a, fluid)

        # Debit
        self.V_dot_su = self.epsilon_v * self.V_s * self.f_rotor
        self.m_flow = self.V_dot_su * rho_a

        # Compression isentropique
        h_iso_b = PropsSI('H', 'P', P_b, 'S', S_a, fluid)
        self.T_iso_K = PropsSI('T', 'P', P_b, 'S', S_a, fluid)

        # Compression reelle (rendement)
        h_b = h_a + (h_iso_b - h_a) / self.epsilon_s
        self.T_out_K = PropsSI('T', 'P', P_b, 'H', h_b, fluid)

        self.P_ext = self.m_flow * (h_b - h_a)

        # Connecteur sortie
        self.Outlet.fluid = fluid
        self.Outlet.h = h_b
        self.Outlet.F = self.m_flow
        self.Inlet.F = self.m_flow

        Ti_degC = PropsSI('T', 'P', P_a, 'H', h_a, fluid) - 273.15
        self.df = pd.DataFrame(
            {'VolumetricCompressor': [
                self.Timestamp, fluid, self.f_rotor, self.V_s,
                self.V_dot_su * 3600, self.m_flow,
                Ti_degC, self.T_iso_K - 273.15, self.T_out_K - 273.15,
                self.P_ext / 1000.0, P_a / 1e5, P_b / 1e5]},
            index=['Timestamp', 'fluid', 'f_rotor_Hz', 'V_s_m3',
                   'V_dot_m3h', 'm_flow_kgs',
                   'Ti_degC', 'Tiso_degC', 'To_degC',
                   'P_ext_kW', 'Pa_bar', 'Pb_bar'])
