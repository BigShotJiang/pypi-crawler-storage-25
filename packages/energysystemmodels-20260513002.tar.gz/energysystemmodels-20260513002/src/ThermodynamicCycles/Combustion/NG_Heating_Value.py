import pandas as pd
import re
from typing import List

class NG_Heating_Value:

    # Masse atomique en g/mol
    atomic_weights = {"C":12.011, "H":1.00794, "O":15.9994, "N":14.00674}

    @staticmethod
    def molar_mass(formula):
        """Calcule la masse molaire d'une formule chimique simple (C,H,O,N)"""
        formula_clean = formula.replace("n-","").replace("i-","").replace("neo-","")
        matches = re.findall(r'([CHON])(\d*)', formula_clean)
        mass = 0
        for elem, num in matches:
            n = int(num) if num else 1
            mass += NG_Heating_Value.atomic_weights[elem] * n
        return mass

    # Données des composants
    data = [
        ["Methane", "CH4", 891.56, 802.69, 0.0447,  2.232],
        ["Ethane", "C2H6", 1562.14, 1428.84, 0.0922, 1.756],
        ["Propane", "C3H8", 2221.10, 2043.37, 0.1338, 1.685],
        ["n-Butane", "n-C4H10", 2879.76, 2657.60, 0.1871,  1.731],
        ["i-Butane", "i-C4H10", 2870.58, 2648.42, 0.1789,  1.693],
        ["n-Pentane", "n-C5H12", 3538.60, 3272.00, 0.251,  2.313],
        ["i-Pentane", "i-C5H12", 3531.68, 3265.08, 0.228,  2.313],
        ["neo-Pentane", "neo-C5H12", 3517.43, 3250.83, 0.2121,  2.313],
        ["n-Hexane", "n-C6H14", 4198.24, 3887.21, 0.295,  2.259],
        ["Nitrogen", "N2", 0.0, 0.0, 0.0173,  1.025],
        ["Carbon dioxide", "CO2", 0.0, 0.0, 0.0748,  0.650],
        ["Hydrogen", "H2", 286.15, 241.72, -0.0048,  10.140]
    ]
    columns = ["Component","Formula","HHV","LHV","b_factor","Cp"]
    df = pd.DataFrame(data, columns=columns)

    class GasComponent:
        """Classe interne pour représenter un composant gazeux"""
        def __init__(self, formula: str, x: float):
            self.formula = formula
            self.x = x
            # Masse molaire
            self.M = NG_Heating_Value.molar_mass(formula)
            # Chercher les propriétés dans le DataFrame
            row = NG_Heating_Value.df.loc[NG_Heating_Value.df['Formula'] == formula]
            if not row.empty:
                self.HHV = row['HHV'].values[0]
                self.LHV = row['LHV'].values[0]
                self.b = row['b_factor'].values[0]
                self.Cp = row['Cp'].values[0]
            else:
                self.HHV = 0
                self.LHV = 0
                self.b = 0
                self.Cp = 0

    def __init__(self, comps: List['NG_Heating_Value.GasComponent']):
        self.c = comps
        self.df = self.to_dataframe()

    def M_mix(self):
        return sum(ci.x * ci.M for ci in self.c)

    def Cp_mix(self):
        return sum(ci.x * ci.Cp for ci in self.c)

    def HHV_mol(self):
        return sum(ci.x * ci.HHV for ci in self.c)

    def LHV_mol(self):
        return sum(ci.x * ci.LHV for ci in self.c)

    def sum_b(self):
        return sum(ci.x * ci.b for ci in self.c)

    def Z(self):
        return 1 - self.sum_b()**2

    def to_dataframe(self):
        M = self.M_mix()
        Cp = self.Cp_mix()
        Hs = self.HHV_mol()
        Hi = self.LHV_mol()
        Z = self.Z()
        R = 8.314510
        P = 101.325
        T = 273.15
        M_AIR = 28.9626
        Z_AIR = 0.99958

        HHV_vol_MJ_Nm3 = Hs * P / (R * T)
        LHV_vol_MJ_Nm3 = Hi * P / (R * T)
        HHV_vol_real_MJ_Nm3 = HHV_vol_MJ_Nm3 / Z
        LHV_vol_real_MJ_Nm3 = LHV_vol_MJ_Nm3 / Z
        HHV_vol_kWh_Nm3 = HHV_vol_real_MJ_Nm3 / 3.6
        LHV_vol_kWh_Nm3 = LHV_vol_real_MJ_Nm3 / 3.6

        density = (P / (R * T)) * M
        density_real = density / Z
        d_rel = M / M_AIR
        relative_d_rel = d_rel * Z_AIR / Z

        HHV_mass_MJ_kg = Hs / M
        LHV_mass_MJ_kg = Hi / M

        Wobbe_index = HHV_vol_MJ_Nm3 / (d_rel ** 0.5)
        Wobbe_real = (HHV_vol_MJ_Nm3 / Z) / (relative_d_rel ** 0.5)

        data = [
            ["Cp", Cp, "J/kg/K"],
            ["Z mix", Z, "-"],
            ["HHV mass (PCS)", HHV_mass_MJ_kg, "MJ/kg"],
            ["LHV mass (PCI)", LHV_mass_MJ_kg, "MJ/kg"],
            ["HHV vol", HHV_vol_MJ_Nm3, "MJ/Nm3"],
            ["LHV vol", LHV_vol_MJ_Nm3, "MJ/Nm3"],
            ["HHV real", HHV_vol_real_MJ_Nm3, "MJ/Nm3"],
            ["LHV real", LHV_vol_real_MJ_Nm3, "MJ/Nm3"],
            ["HHV vol", HHV_vol_kWh_Nm3, "kWh/Nm3"],
            ["LHV vol", LHV_vol_kWh_Nm3, "kWh/Nm3"],
            ["Density", density, "kg/Nm3"],
            ["Density real", density_real, "kg/Nm3"],
            ["Relative density", d_rel, "-"],
            ["Relative density real", relative_d_rel, "-"],
            ["Wobbe index", Wobbe_index, "MJ/Nm3"],
            ["Wobbe real", Wobbe_real, "MJ/Nm3"],
        ]
        return pd.DataFrame(data, columns=["Property", "Value", "Unit"])


