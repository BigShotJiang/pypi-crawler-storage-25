import numpy as np
import pandas as pd
import re
from ThermodynamicCycles.Combustion.NG_Heating_Value import NG_Heating_Value
from ThermodynamicCycles.FluidPort.FluidPort import FluidPort
from CoolProp.CoolProp import PropsSI

try:
    from CoolProp.CoolProp import PropsSI as _CP_PropsSI
    _HAS_COOLPROP = True
except ImportError:
    _HAS_COOLPROP = False


class FlueGasPort:
    """Port compatible FluidPort pour mélange de fumées (CO2, H2O, N2, O2, Ar).

    Calcule les propriétés thermodynamiques du mélange à partir de la
    composition volumique et de la température, en utilisant CoolProp
    pour chaque composant individuel (le mélange complet n'est pas géré
    par CoolProp à pression atmosphérique).

    Conforme EN12952-15 : enthalpies par composant, point de rosée,
    chaleur latente de condensation.
    """

    # Molar masses (g/mol)
    M = {'CO2': 44.01, 'H2O': 18.015, 'N2': 28.013, 'O2': 32.0, 'Ar': 39.948}

    # CoolProp names for individual species
    _CP = {'CO2': 'CarbonDioxide', 'N2': 'Nitrogen', 'O2': 'Oxygen', 'Ar': 'Argon'}

    # Latent heat of water at 25°C (kJ/kg) — EN12952-15 §4.2
    LATENT_HEAT_25 = 2442.5

    def __init__(self):
        self.fluid = "flue_gas"
        self.F = None           # kg/s
        self.F_Nm3h = None      # Nm3/h total
        self.P = 101325         # Pa
        self.T = None           # K
        self.h = None           # J/kg (enthalpie massique mix, ref 25°C)
        self.S = None
        self.rho = None         # kg/m3 at T
        self.rho_Nm3 = None     # kg/Nm3 (at 0°C, 101325 Pa)
        self.cp = None          # J/kg/K
        self.composition = {}   # {'CO2': vol_frac, ...}
        self.T_condensation = None  # °C (dew point)
        self.df = pd.DataFrame()

    def set_composition(self, composition):
        """Set volumetric composition (fractions, must sum to ~1)."""
        total = sum(composition.values())
        self.composition = {sp: v / total for sp, v in composition.items()}

    def calculate_properties(self, T_ref_C=25.0):
        """Calculate all thermodynamic properties at self.T and self.P.

        Uses CoolProp for CO2, N2, O2, Ar individual enthalpies.
        Uses steam tables (CoolProp at low P) for H2O vapor.
        """
        if self.T is None or not self.composition:
            return

        T_K = self.T
        T_ref_K = T_ref_C + 273.15
        P = self.P

        # --- Molar mass and density of mix ---
        M_mix = sum(self.composition.get(sp, 0) * self.M.get(sp, 28) for sp in self.composition)
        self.rho_Nm3 = M_mix / 22.414  # kg/Nm3
        self.rho = M_mix * P / (8.314510 * T_K * 1000)  # kg/m3 ideal gas

        # --- Enthalpy of each component (J/kg_mix) ---
        h_mix = 0.0   # J/kg of mix
        cp_mix = 0.0  # J/kg/K of mix

        for sp, x_vol in self.composition.items():
            mass_frac = x_vol * self.M.get(sp, 28) / M_mix

            if sp == 'H2O':
                h_sp, cp_sp = self._h2o_vapor_props(T_K, T_ref_K)
            elif sp in self._CP:
                h_sp, cp_sp = self._coolprop_props(sp, T_K, T_ref_K, P)
            else:
                h_sp = 1300.0 * (T_K - T_ref_K)  # fallback ~N2
                cp_sp = 1300.0

            h_mix += mass_frac * h_sp
            cp_mix += mass_frac * cp_sp

        self.h = h_mix    # J/kg relative to T_ref
        self.cp = cp_mix  # J/kg/K at T

        # --- Flow conversion ---
        if self.F_Nm3h is not None and self.F is None:
            self.F = self.F_Nm3h * self.rho_Nm3 / 3600.0
        elif self.F is not None and self.F_Nm3h is None:
            self.F_Nm3h = self.F * 3600.0 / self.rho_Nm3

        # --- Dew point from H2O partial pressure ---
        x_H2O = self.composition.get('H2O', 0)
        if x_H2O > 0:
            P_H2O = x_H2O * P
            if P_H2O > 610.78:
                ln_r = np.log(P_H2O / 610.78)
                self.T_condensation = 237.29 * ln_r / (17.2694 - ln_r)
            else:
                self.T_condensation = 0.0
        else:
            self.T_condensation = 0.0

        # --- Build df ---
        self._build_df()

    def enthalpy_at(self, T_C, T_ref_C=25.0):
        """Enthalpy of the mix at T_C in kW per (Nm3/h of mix), ref T_ref_C."""
        T_K = T_C + 273.15
        T_ref_K = T_ref_C + 273.15
        h = 0.0  # kJ/Nm3_mix
        for sp, x_vol in self.composition.items():
            if sp == 'H2O':
                h_sp_kg, _ = self._h2o_vapor_props(T_K, T_ref_K)
            elif sp in self._CP:
                h_sp_kg, _ = self._coolprop_props(sp, T_K, T_ref_K, self.P)
            else:
                h_sp_kg = 1300.0 * (T_K - T_ref_K)
            rho_sp = self.M.get(sp, 28) / 22.414  # kg/Nm3 of species
            h += x_vol * h_sp_kg * rho_sp / 1000.0  # kJ/Nm3_mix
        return h / 3600.0  # kW per (Nm3/h)

    def condensation_heat(self, T_fg_C):
        """Heat recoverable by condensing water between T_condensation and T_fg.

        Returns (kW per Nm3/h of mix, kg_condensed per Nm3/h of mix).
        """
        if self.T_condensation is None or T_fg_C >= self.T_condensation:
            return 0.0, 0.0

        x_H2O = self.composition.get('H2O', 0)
        Psat_fg = 610.78 * np.exp(17.2694 * T_fg_C / (T_fg_C + 237.29))
        x_sat = Psat_fg / self.P
        fg_dry = 1.0 - x_H2O
        H2O_remaining = x_sat / (1 - x_sat) * fg_dry if x_sat < 1 else x_H2O
        H2O_condensed_Nm3 = max(0, x_H2O - H2O_remaining)
        kg_condensed = H2O_condensed_Nm3 * 18.015 / 22.414  # kg per Nm3 mix

        latent = kg_condensed * self.LATENT_HEAT_25 / 3600.0  # kW per Nm3/h
        sensible = kg_condensed * 4.18 * (self.T_condensation - T_fg_C) / 3600.0
        return latent + sensible, kg_condensed

    @staticmethod
    def _coolprop_props(species, T_K, T_ref_K, P):
        """Enthalpy (J/kg) and Cp (J/kg/K) from CoolProp for a pure gas."""
        cp_name = FlueGasPort._CP[species]
        try:
            h = PropsSI('H', 'T', T_K, 'P', P, cp_name) - PropsSI('H', 'T', T_ref_K, 'P', P, cp_name)
            cp = PropsSI('C', 'T', T_K, 'P', P, cp_name)
            return h, cp
        except Exception:
            # Fallback Cp
            fallback = {'CO2': 900, 'N2': 1040, 'O2': 920, 'Ar': 520}
            cp_fb = fallback.get(species, 1000)
            return cp_fb * (T_K - T_ref_K), cp_fb

    @staticmethod
    def _h2o_vapor_props(T_K, T_ref_K):
        """Sensible enthalpy (J/kg) and Cp (J/kg/K) of steam (vapor-vapor)."""
        try:
            P_low = 1000  # 1 kPa — well below saturation to stay vapor
            h = PropsSI('H', 'T', T_K, 'P', P_low, 'Water') - PropsSI('H', 'T', max(T_ref_K, 273.16), 'P', P_low, 'Water')
            cp = PropsSI('C', 'T', T_K, 'P', P_low, 'Water')
            return h, cp
        except Exception:
            return 1860.0 * (T_K - T_ref_K), 1860.0

    def _build_df(self):
        rows = [
            ('Fluid', self.fluid),
            ('F (kg/s)', round(self.F, 3) if self.F else 'N/A'),
            ('F (Nm3/h)', round(self.F_Nm3h, 1) if self.F_Nm3h else 'N/A'),
            ('T (C)', round(self.T - 273.15, 1)),
            ('P (Pa)', round(self.P, 0)),
            ('h (J/kg, ref 25C)', round(self.h, 1) if self.h else 'N/A'),
            ('Cp (J/kg/K)', round(self.cp, 1) if self.cp else 'N/A'),
            ('rho (kg/Nm3)', round(self.rho_Nm3, 4) if self.rho_Nm3 else 'N/A'),
            ('T_condensation (C)', round(self.T_condensation, 1) if self.T_condensation else 'N/A'),
        ]
        for sp, xv in self.composition.items():
            rows.append((f'{sp} (vol)', round(float(xv), 4)))
        self.df = pd.DataFrame(rows, columns=['Parameter', 'Value']).set_index('Parameter')


class NG_Boiler_Efficiency:
    """
    EN12952-15 / EN12953-11 indirect method boiler efficiency calculator.
    Computes heat losses (flue gas sensible, CO, radiation, condensation)
    and derives LHV/HHV efficiencies for natural gas boilers.
    Uses CoolProp for precise gas enthalpies when available.
    """

    R = 8.314510          # J/mol/K
    VMOL = 22.414e-3      # m3/mol at 0C, 101.325 kPa
    T_NTP = 273.15        # K (Normal Temperature 0C)
    P_NTP = 101.325       # kPa

    # Dry air molar composition
    DRY_AIR = {'CO2': 0.00033, 'O2': 0.20946, 'N2': 0.78102, 'Ar': 0.00919}

    # CoolProp fluid names
    _CP_NAMES = {'CO2': 'CarbonDioxide', 'N2': 'Nitrogen', 'O2': 'Oxygen', 'Ar': 'Argon'}

    # Fallback Cp in kJ/Nm3/K (if CoolProp unavailable)
    FG_CP_FALLBACK = {'CO2': 1.7, 'H2O': 1.5, 'N2': 1.3, 'O2': 1.3, 'Ar': 0.93}

    # Radiation loss constants
    RADIATION_CONSTANT = {'water_tube': 0.0113, 'fire_tube': 0.0072}

    # CO net calorific value kJ/Nm3
    NCV_CO = 12633.0

    @staticmethod
    def _enthalpy_Nm3(species, T_K):
        """Enthalpy of gas species at T_K in kJ/Nm3, relative to 0 kJ at 0°C.

        Uses CoolProp if available, otherwise Cp fallback.
        For H2O: uses CoolProp at 1 kPa (superheated vapor) to avoid phase change.
        """
        rho_map = {'CO2': 1.977, 'H2O': 0.8034, 'N2': 1.250, 'O2': 1.429, 'Ar': 1.784}
        rho = rho_map.get(species, 1.3)

        if _HAS_COOLPROP and species != 'H2O':
            cp_name = NG_Boiler_Efficiency._CP_NAMES.get(species)
            if cp_name:
                try:
                    h = PropsSI('H', 'T', T_K, 'P', 101325, cp_name)
                    h0 = PropsSI('H', 'T', 273.15, 'P', 101325, cp_name)
                    return (h - h0) * rho / 1000.0  # J/kg * kg/Nm3 / 1000 -> kJ/Nm3
                except Exception:
                    pass

        if _HAS_COOLPROP and species == 'H2O':
            try:
                h = PropsSI('H', 'T', T_K, 'P', 1000, 'Water')
                h0 = PropsSI('H', 'T', 273.16, 'P', 1000, 'Water')
                return (h - h0) * rho / 1000.0
            except Exception:
                pass

        # Fallback: constant Cp
        Cp = NG_Boiler_Efficiency.FG_CP_FALLBACK.get(species, 1.3)
        return Cp * (T_K - 273.15)

    # Latent heat of water vaporization kJ/kg at 25C
    LATENT_HEAT_WATER = 2442.5

    def __init__(
        self,
        gas_composition: dict,
        ng_flow_Nm3h: float = None,
        ng_temperature_C: float = 25.0,
        ng_LHV_kWh_Nm3: float = None,
        flue_gas_temperature_C: float = 180.0,
        O2_measured: float = 0.035,
        O2_basis: str = 'dry',
        CO_ppm: float = 0.0,
        ambient_temperature_C: float = 25.0,
        ambient_RH: float = 0.5,
        ambient_pressure_mbar: float = 1013.25,
        air_temperature_C: float = None,
        boiler_type: str = 'water_tube',
        design_useful_heat_kW: float = 1000.0,
        electrical_credit_kW: float = 0.0,
        other_heat_credit_kW: float = 0.0,
        T_ref: float = 25.0,
    ):
        self.gas_composition = gas_composition
        self.ng_flow = ng_flow_Nm3h
        self.ng_temperature = ng_temperature_C
        self.ng_LHV_kWh_Nm3_input = ng_LHV_kWh_Nm3
        self.T_fg = flue_gas_temperature_C
        self.O2_measured = O2_measured
        self.O2_basis = O2_basis
        self.CO_ppm = CO_ppm
        self.T_amb = ambient_temperature_C
        self.RH = ambient_RH
        self.P_atm = ambient_pressure_mbar * 100.0  # Pa
        self.T_air = air_temperature_C if air_temperature_C is not None else ambient_temperature_C
        self.boiler_type = boiler_type
        self.design_useful_heat_kW = design_useful_heat_kW
        self.electrical_credit = electrical_credit_kW
        self.other_heat_credit = other_heat_credit_kW
        self.T_ref = T_ref
        self.df = None

        # Water side (like Simple_HEX)
        self.Inlet = FluidPort()
        self.Inlet.fluid = "water"
        self.Outlet = FluidPort()
        self.Outlet.fluid = "water"
        self.To = None  # Target outlet water temperature (°C)

        # Flue gas outlet port
        self.FG_Outlet = FlueGasPort()

    def calculate(self):
        # --- 0. Water side: compute Qth needed if To is set ---
        self.Qth = None
        if self.To is not None and self.Inlet.F is not None and self.Inlet.h is not None:
            self.Outlet.P = self.Inlet.P
            self.Outlet.F = self.Inlet.F
            self.Outlet.fluid = self.Inlet.fluid
            self.Outlet.T = self.To + 273.15
            self.Outlet.h = PropsSI('H', 'P', self.Outlet.P, 'T', self.Outlet.T, self.Outlet.fluid)
            self.Outlet.S = PropsSI('S', 'P', self.Outlet.P, 'T', self.Outlet.T, self.Outlet.fluid)
            self.Qth = self.Inlet.F * (self.Outlet.h - self.Inlet.h) / 1000.0  # kW

        # Use ng_flow=1 for efficiency calculation if not provided (unitaire)
        if self.ng_flow is None:
            self.ng_flow = 1.0
            self._auto_flow = True
        else:
            self._auto_flow = False

        # --- 1. NG properties via NG_Heating_Value ---
        comps = [
            NG_Heating_Value.GasComponent(formula, x)
            for formula, x in self.gas_composition.items()
        ]
        ng_props = NG_Heating_Value(comps)
        props_df = ng_props.df

        def get_prop(name, unit):
            row = props_df[(props_df['Property'] == name) & (props_df['Unit'] == unit)]
            return row['Value'].values[0] if not row.empty else None

        LHV_kWh = get_prop('LHV vol', 'kWh/Nm3') if self.ng_LHV_kWh_Nm3_input is None else self.ng_LHV_kWh_Nm3_input
        HHV_kWh = get_prop('HHV vol', 'kWh/Nm3')
        density = get_prop('Density real', 'kg/Nm3')
        Cp_mass = ng_props.Cp_mix()  # J/kg/K

        # --- 2. NG heat power ---
        Cp_kWh_Nm3_K = (Cp_mass * density) / 3.6e6  # J/kg/K * kg/Nm3 -> J/Nm3/K -> kWh/Nm3/K
        sensible_heat = Cp_kWh_Nm3_K * (self.ng_temperature - self.T_ref)
        Q_ng_LHV = (LHV_kWh + sensible_heat) * self.ng_flow  # kW
        Q_ng_HHV = (HHV_kWh + sensible_heat) * self.ng_flow  # kW

        # --- 3. Ambient air moisture ---
        Psat = 610.78 * np.exp(17.2694 * self.T_amb / (self.T_amb + 237.29))  # Pa
        Pw = self.RH * Psat
        x_H2O_air = Pw / self.P_atm  # molar fraction

        # --- 4-5. Wet air composition ---
        wet_air = {}
        for species, xi in self.DRY_AIR.items():
            wet_air[species] = xi * (1 - x_H2O_air)
        wet_air['H2O'] = x_H2O_air

        # --- 6. Stoichiometric combustion ---
        stoich_O2 = 0.0    # Nm3 O2 per Nm3 fuel
        stoich_CO2 = 0.0   # Nm3 CO2 produced per Nm3 fuel
        stoich_H2O = 0.0   # Nm3 H2O produced per Nm3 fuel
        stoich_N2_fuel = 0.0

        for formula, x in self.gas_composition.items():
            if formula == 'N2':
                stoich_N2_fuel += x
                continue
            if formula == 'CO2':
                stoich_CO2 += x
                continue
            if formula == 'H2':
                stoich_O2 += x * 0.5
                stoich_H2O += x * 1.0
                continue

            # Parse CnHm
            clean = formula.replace("n-", "").replace("i-", "").replace("neo-", "")
            matches = re.findall(r'([CHON])(\d*)', clean)
            atoms = {elem: int(num) if num else 1 for elem, num in matches}
            n_C = atoms.get('C', 0)
            n_H = atoms.get('H', 0)

            if n_C == 0 and n_H == 0:
                continue

            O2_needed = n_C + n_H / 4.0
            stoich_O2 += x * O2_needed
            stoich_CO2 += x * n_C
            stoich_H2O += x * n_H / 2.0

        # Stoichiometric air (Nm3 air / Nm3 fuel) based on O2 in dry air
        stoich_air = stoich_O2 / self.DRY_AIR['O2']

        # --- 7. Excess air from O2 measurement ---
        O2_dry_frac = self.O2_measured
        if self.O2_basis == 'wet':
            # Convert wet O2 to dry O2 (approximate)
            # Need iterative approach, but use first approximation
            O2_dry_frac = self.O2_measured / (1 - x_H2O_air)

        O2_dry_pct = O2_dry_frac * 100.0
        O2_ref_pct = self.DRY_AIR['O2'] * 100.0

        total_air_ratio = O2_ref_pct / (O2_ref_pct - O2_dry_pct)
        total_air = stoich_air * total_air_ratio  # Nm3 wet air / Nm3 fuel
        excess_air_pct = (total_air_ratio - 1) * 100.0

        # --- 8. Flue gas composition (Nm3 per Nm3 fuel) ---
        fg = {}
        fg['CO2'] = stoich_CO2 + total_air * wet_air.get('CO2', 0)
        fg['H2O'] = stoich_H2O + total_air * wet_air.get('H2O', 0)
        fg['O2'] = total_air * wet_air.get('O2', 0) - stoich_O2
        fg['N2'] = stoich_N2_fuel + total_air * wet_air.get('N2', 0)
        fg['Ar'] = total_air * wet_air.get('Ar', 0)

        fg_total = sum(fg.values())  # Nm3 flue gas / Nm3 fuel
        fg_dry = fg_total - fg['H2O']

        # Flue gas flows
        fg_flow = fg_total * self.ng_flow  # Nm3/h
        fg_flow_dry = fg_dry * self.ng_flow

        # H2O volume fraction in flue gas
        x_H2O_fg = fg['H2O'] / fg_total

        # --- 9-10. Flue gas sensible heat loss (CoolProp or fallback) ---
        T_fg_K = self.T_fg + 273.15
        T_ref_K = self.T_ref + 273.15
        # Enthalpy of each species at T_fg and T_ref (kJ/Nm3)
        fg_enthalpy = 0.0  # kJ per Nm3 of fuel
        for sp, vol in fg.items():
            h_fg = self._enthalpy_Nm3(sp, T_fg_K)
            h_ref = self._enthalpy_Nm3(sp, T_ref_K)
            fg_enthalpy += vol * (h_fg - h_ref)

        flue_gas_loss = fg_enthalpy * self.ng_flow / 3600.0  # kW

        # CO loss
        CO_loss = self.CO_ppm * 1e-6 * fg_flow_dry * self.NCV_CO / 3600.0  # kW

        # Radiation loss
        k_rad = self.RADIATION_CONSTANT.get(self.boiler_type, 0.0113)
        radiation_loss = k_rad * self.design_useful_heat_kW ** 0.7  # kW

        # --- 11. Condensation check ---
        # Dew point from H2O partial pressure in flue gas
        P_H2O_fg = x_H2O_fg * self.P_atm  # Pa
        # Inverse of Antoine: T_dew = 237.29 * ln(P/610.78) / (17.2694 - ln(P/610.78))
        if P_H2O_fg > 0:
            ln_ratio = np.log(P_H2O_fg / 610.78)
            T_condensation = 237.29 * ln_ratio / (17.2694 - ln_ratio)
        else:
            T_condensation = 0.0

        condensation_recovery = 0.0
        if self.T_fg < T_condensation:
            # Saturation pressure at flue gas temperature
            Psat_fg = 610.78 * np.exp(17.2694 * self.T_fg / (self.T_fg + 237.29))
            # Maximum H2O that can remain as vapor (mole fraction)
            x_H2O_sat = Psat_fg / self.P_atm
            # Condensed water: difference in Nm3 per Nm3 fuel
            H2O_remaining_vapor = x_H2O_sat / (1 - x_H2O_sat) * (fg_total - fg['H2O'])
            H2O_condensed_Nm3 = max(0, fg['H2O'] - H2O_remaining_vapor)  # Nm3/Nm3_fuel
            # Convert to kg: 1 Nm3 H2O = 18.015 / 22.414 = 0.8034 kg
            H2O_condensed_kg_per_Nm3_fuel = H2O_condensed_Nm3 * 18.015 / 22.414
            H2O_condensed_kg_h = H2O_condensed_kg_per_Nm3_fuel * self.ng_flow

            # Latent heat recovery
            latent_recovery = H2O_condensed_kg_h * self.LATENT_HEAT_WATER / 3600.0  # kW
            # Sensible heat recovery from cooling condensate from T_condensation to T_fg
            sensible_recovery = H2O_condensed_kg_h * 4.18 * (T_condensation - self.T_fg) / 3600.0  # kW
            condensation_recovery = latent_recovery + sensible_recovery

        # --- 12. Boiler efficiency (indirect method) ---
        heat_credits = self.electrical_credit + self.other_heat_credit

        # Water vapor remaining after condensation (Nm3/Nm3_fuel)
        if self.T_fg < T_condensation:
            H2O_vapor = H2O_remaining_vapor
            H2O_condensed = fg['H2O'] - H2O_remaining_vapor
        else:
            H2O_vapor = fg['H2O']
            H2O_condensed = 0.0

        H2O_vapor_kg_h = H2O_vapor * self.ng_flow * 18.015 / 22.414
        H2O_condensed_kg_h = H2O_condensed * self.ng_flow * 18.015 / 22.414

        # Condensate loss: water leaving envelope at T_fg (sensible heat)
        condensate_loss = H2O_condensed_kg_h * 4.18 * (self.T_fg - self.T_ref) / 3600.0  # kW

        # === LHV basis ===
        # Condensation recovery = latent + sensible heat recovered
        total_losses_LHV = flue_gas_loss + CO_loss + radiation_loss - condensation_recovery
        efficiency_LHV = 1.0 - total_losses_LHV / (Q_ng_LHV + heat_credits) if (Q_ng_LHV + heat_credits) > 0 else 0.0

        # === HHV basis ===
        # Flue gas loss includes latent heat of water REMAINING as vapor
        latent_vapor = H2O_vapor_kg_h * self.LATENT_HEAT_WATER / 3600.0  # kW
        flue_gas_loss_HHV = flue_gas_loss + latent_vapor
        total_losses_HHV = flue_gas_loss_HHV + CO_loss + radiation_loss + condensate_loss
        efficiency_HHV = 1.0 - total_losses_HHV / (Q_ng_HHV + heat_credits) if (Q_ng_HHV + heat_credits) > 0 else 0.0

        # --- 13. Useful heat ---
        useful_heat_LHV = efficiency_LHV * Q_ng_LHV + heat_credits
        useful_heat_HHV = efficiency_HHV * Q_ng_HHV + heat_credits

        # --- 14. Adapt NG flow to water side demand ---
        if self._auto_flow and self.Qth is not None and efficiency_LHV > 0:
            # Qth = kW needed, efficiency is per Nm3, LHV in kWh/Nm3
            self.ng_flow = self.Qth / (efficiency_LHV * LHV_kWh)
            # Recalculate absolute values with real flow
            Q_ng_LHV = (LHV_kWh + sensible_heat) * self.ng_flow
            Q_ng_HHV = (HHV_kWh + sensible_heat) * self.ng_flow
            fg_flow = fg_total * self.ng_flow
            fg_flow_dry = fg_dry * self.ng_flow
            flue_gas_loss = fg_enthalpy * self.ng_flow / 3600.0
            CO_loss = self.CO_ppm * 1e-6 * fg_flow_dry * self.NCV_CO / 3600.0
            H2O_vapor_kg_h = H2O_vapor * self.ng_flow * 18.015 / 22.414
            H2O_condensed_kg_h = H2O_condensed * self.ng_flow * 18.015 / 22.414
            condensate_loss = H2O_condensed_kg_h * 4.18 * (self.T_fg - self.T_ref) / 3600.0
            if self.T_fg < T_condensation:
                H2O_cond_kg_Nm3 = (fg['H2O'] - H2O_remaining_vapor) * 18.015 / 22.414
                cond_kg_h = H2O_cond_kg_Nm3 * self.ng_flow
                latent_r = cond_kg_h * self.LATENT_HEAT_WATER / 3600.0
                sensible_r = cond_kg_h * 4.18 * (T_condensation - self.T_fg) / 3600.0
                condensation_recovery = latent_r + sensible_r
            else:
                condensation_recovery = 0.0
            total_losses_LHV = flue_gas_loss + CO_loss + radiation_loss - condensation_recovery
            useful_heat_LHV = efficiency_LHV * Q_ng_LHV + heat_credits
            latent_vapor = H2O_vapor_kg_h * self.LATENT_HEAT_WATER / 3600.0
            flue_gas_loss_HHV = flue_gas_loss + latent_vapor
            total_losses_HHV = flue_gas_loss_HHV + CO_loss + radiation_loss + condensate_loss
            useful_heat_HHV = efficiency_HHV * Q_ng_HHV + heat_credits

        # --- Build output DataFrame ---
        rows = [
            ('--- INPUTS ---', ''),
            ('NG flow (Nm3/h)', round(self.ng_flow, 2)),
            ('LHV (kWh/Nm3)', round(LHV_kWh, 4)),
            ('HHV (kWh/Nm3)', round(HHV_kWh, 4)),
            ('T flue gas (C)', round(self.T_fg, 1)),
            ('O2 dry (%)', round(O2_dry_pct, 2)),
            ('Boiler type', self.boiler_type),
            ('--- COMBUSTION ---', ''),
            ('Air/fuel ratio (Nm3/Nm3)', round(total_air, 3)),
            ('Excess air (%)', round(excess_air_pct, 1)),
            ('Flue gas flow (Nm3/h)', round(fg_flow, 1)),
            ('Condensation T (C)', round(T_condensation, 1)),
            ('--- HEAT BALANCE (LHV) ---', ''),
            ('NG heat input (kW)', round(Q_ng_LHV, 1)),
            ('Flue gas loss (kW)', round(flue_gas_loss, 1)),
            ('CO loss (kW)', round(CO_loss, 2)),
            ('Radiation loss (kW)', round(radiation_loss, 2)),
            ('Condensation recovery (kW)', round(condensation_recovery, 2)),
            ('Total losses (kW)', round(total_losses_LHV, 1)),
            ('Heat credits (kW)', round(heat_credits, 1)),
            ('Useful heat (kW)', round(useful_heat_LHV, 1)),
            ('Efficiency LHV (%)', round(efficiency_LHV * 100, 2)),
            ('--- HEAT BALANCE (HHV) ---', ''),
            ('Efficiency HHV (%)', round(efficiency_HHV * 100, 2)),
        ]

        if self.To is not None:
            rows += [
                ('--- WATER SIDE ---', ''),
                ('Water inlet T (C)', round(PropsSI('T', 'P', self.Inlet.P, 'H', self.Inlet.h, self.Inlet.fluid) - 273.15, 1) if self.Inlet.h else 'N/A'),
                ('Water outlet T (C)', round(self.To, 1)),
                ('Water flow (kg/s)', round(self.Inlet.F, 3) if self.Inlet.F else 'N/A'),
                ('Qth demand (kW)', round(self.Qth, 1) if self.Qth else 'N/A'),
            ]

        self.df = pd.DataFrame(rows, columns=['Parameter', 'Value'])
        self.df = self.df.set_index('Parameter')

        # Store key results as attributes for programmatic access
        self.LHV_kWh_Nm3 = LHV_kWh
        self.HHV_kWh_Nm3 = HHV_kWh
        self.Q_ng_LHV = Q_ng_LHV
        self.Q_ng_HHV = Q_ng_HHV
        self.efficiency_LHV = efficiency_LHV
        self.efficiency_HHV = efficiency_HHV
        self.useful_heat_LHV = useful_heat_LHV
        self.useful_heat_HHV = useful_heat_HHV
        self.excess_air_pct = excess_air_pct
        self.air_fuel_ratio = total_air
        self.fg_flow_Nm3h = fg_flow
        self.T_condensation = T_condensation
        self.condensation_recovery = condensation_recovery
        self.flue_gas_loss = flue_gas_loss
        self.radiation_loss = radiation_loss
        self.CO_loss = CO_loss
        self.total_losses_LHV = total_losses_LHV

        # --- Populate flue gas outlet port ---
        self.FG_Outlet.set_composition({sp: fg[sp] / fg_total for sp in fg})
        self.FG_Outlet.T = self.T_fg + 273.15
        self.FG_Outlet.P = self.P_atm
        self.FG_Outlet.F_Nm3h = fg_flow
        self.FG_Outlet.F = None  # recalculated in calculate_properties
        self.FG_Outlet.calculate_properties(T_ref_C=self.T_ref)

        return self.df
