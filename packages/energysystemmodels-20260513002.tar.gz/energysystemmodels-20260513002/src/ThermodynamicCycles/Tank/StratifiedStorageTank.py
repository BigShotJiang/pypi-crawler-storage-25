"""StratifiedStorageTank — ballon de stockage d'eau chaude stratifié.

Traduction Python du modele Modelica `StratifiedStorageTank.mo`
(2 entrees / 2 sorties, N couches, convection upwind + conduction + pertes
ambiantes). Integration temporelle explicite (Euler) avec sous-pas pour
garantir la stabilite du terme diffusif/advectif sur un pas global self.t.

Convention des connecteurs (FluidPort)
--------------------------------------
- port_cold_a : entree froide (bas)        F > 0 si entrante
- port_hot_a  : entree chaude (haut)       F > 0 si entrante
- port_hot_b  : sortie chaude (haut)       F > 0 si sortante
- port_cold_b : sortie froide (bas)        F > 0 si sortante

Bilan masse a volume constant (a respecter par l'utilisateur) :
    F_cold_a + F_hot_a = F_cold_b + F_hot_b
"""

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort
from CoolProp.CoolProp import PropsSI
import pandas as pd
import math


class Object:
    def __init__(self):
        self.Timestamp = None

        # Connecteurs (convention Modelica : _a = inlet, _b = outlet)
        self.port_cold_a = FluidPort()
        self.port_cold_b = FluidPort()
        self.port_hot_a = FluidPort()
        self.port_hot_b = FluidPort()

        # ---- Geometrie ----
        self.Hball = 2.0                    # hauteur ballon (m)
        self.Dball = 1.78412396043743       # diametre ballon (m)
        self.N = 10                         # nombre de couches
        self.Hstr_1 = None                  # hauteur couche 1 (top), defaut 2*Hball/N
        self.Hstr_N = None                  # hauteur couche N (bottom), defaut 2*Hball/N

        # ---- Parametres physiques ----
        self.rho = 1000.0                   # masse volumique eau (kg/m3)
        self.C = 4192.22                    # chaleur massique eau (J/kg/K)
        self.U = 1.0                        # coefficient global de transmission (W/m2/K)
        self.lamda = 0.62                   # conductivite thermique eau (W/m/K)
        self.Tamb_degC = 12.0               # temperature ambiante (degC)
        self.Tinit_degC = 12.0              # temperature initiale uniforme (degC)

        # ---- Pas de temps & integration ----
        self.t = 3600                       # pas de temps global (s)
        self.n_substeps = 100               # sous-pas Euler explicite

        # ---- Etat interne ----
        self.T = None                       # vecteur temperatures couches (K)
        self.T_degC = None                  # idem en degC
        self._Tinit_K_const = None          # Tinit fixe pour Delta_u (style Modelica)
        self._initialized = False

        # ---- Geometrie calculee ----
        self.V = None
        self.Vstr_1 = None
        self.Vstr_N = None
        self.Vstr = None
        self.Hstr = None
        self.A1 = None
        self.An = None
        self.Ai = None

        # ---- Sorties energetiques ----
        self.P = None                       # puissance par couche (W) en fin de pas
        self.P_ballon = None                # somme(P[i]) en W
        self.Qstr_J = None                  # energie echangee sur le pas (J)
        self.Qstr_kWh = None
        self.Qstr_kW = None
        self.cumul_Qstr_kWh = 0.0
        self.Delta_u_J = None               # energie stockee absolue / Tinit (J)
        self.Delta_u_kWh = None

        self.df = []

    # ------------------------------------------------------------------
    # Initialisation geometrie + temperature
    # ------------------------------------------------------------------
    def _init_geometry(self):
        pi = math.pi
        N = self.N
        if N < 3:
            raise ValueError("N doit etre >= 3 (couches top, milieu, bottom)")

        if self.Hstr_1 is None:
            self.Hstr_1 = 2.0 * self.Hball / N
        if self.Hstr_N is None:
            self.Hstr_N = 2.0 * self.Hball / N

        self.V = pi * self.Dball ** 2 / 4.0 * self.Hball
        self.Vstr_1 = pi * self.Hstr_1 * (self.Dball / 2.0) ** 2
        self.Vstr_N = pi * self.Hstr_N * (self.Dball / 2.0) ** 2
        self.Vstr = (self.V - (self.Vstr_1 + self.Vstr_N)) / (N - 2)
        self.Hstr = (self.Hball - (self.Hstr_1 + self.Hstr_N)) / (N - 2)

        self.Ai = 2.0 * pi * (self.Dball / 2.0) * self.Hstr
        self.A1 = pi * (self.Dball / 2.0) ** 2 + 2.0 * pi * (self.Dball / 2.0) * self.Hstr_1
        self.An = pi * (self.Dball / 2.0) ** 2 + 2.0 * pi * (self.Dball / 2.0) * self.Hstr_N

    def _init_temperatures(self):
        Tinit_K = self.Tinit_degC + 273.15
        self.T = [Tinit_K] * self.N
        self._Tinit_K_const = Tinit_K

    # ------------------------------------------------------------------
    # Pas de calcul (avance la solution de self.t secondes)
    # ------------------------------------------------------------------
    def calculate(self):
        if not self._initialized:
            self._init_geometry()
            self._init_temperatures()
            self._initialized = True

        pi = math.pi
        N = self.N
        C = self.C
        rho = self.rho
        lamda = self.lamda
        D = self.Dball
        Tamb = self.Tamb_degC + 273.15

        # ---- Lecture des debits (kg/s, positifs) ----
        F_hot_a = self.port_hot_a.F if self.port_hot_a.F is not None else 0.0
        F_cold_a = self.port_cold_a.F if self.port_cold_a.F is not None else 0.0
        F_hot_b = self.port_hot_b.F if self.port_hot_b.F is not None else 0.0
        F_cold_b = self.port_cold_b.F if self.port_cold_b.F is not None else 0.0

        # Reconstruction des m_flow signes (convention Modelica : >0 entrant)
        m_hot_a = +F_hot_a
        m_cold_a = +F_cold_a
        m_hot_b = -F_hot_b
        m_cold_b = -F_cold_b

        # Verification bilan masse a volume constant
        bilan = m_hot_a + m_cold_a + m_hot_b + m_cold_b
        if abs(bilan) > 1e-9:
            print(f"[StratifiedTank] ATTENTION bilan masse non nul : {bilan:.4g} kg/s "
                  f"(F_cold_a={F_cold_a}, F_hot_a={F_hot_a}, "
                  f"F_cold_b={F_cold_b}, F_hot_b={F_hot_b})")

        # ---- Temperatures d'entree (depuis enthalpies + pression) ----
        if self.port_hot_a.h is not None and self.port_hot_a.P is not None:
            T_hot_a = PropsSI('T', 'P', self.port_hot_a.P, 'H', self.port_hot_a.h,
                              self.port_hot_a.fluid)
        else:
            T_hot_a = self.T[0]  # fallback : pas de flux entrant chaud

        if self.port_cold_a.h is not None and self.port_cold_a.P is not None:
            T_cold_a = PropsSI('T', 'P', self.port_cold_a.P, 'H', self.port_cold_a.h,
                               self.port_cold_a.fluid)
        else:
            T_cold_a = self.T[N - 1]

        # ---- Variations de debits ascendant/descendant (signe Modelica) ----
        m_plus = m_cold_a + m_cold_b      # > 0 : flux ascendant net
        m_moins = m_hot_a + m_hot_b       # > 0 : flux descendant net
        PP = 1.0 if m_plus > 0 else 0.0
        MM = 1.0 if m_moins > 0 else 0.0

        # ---- Sauvegarde T pour calcul Qstr de pas ----
        T_before = list(self.T)

        # ---- Integration Euler explicite avec sous-pas ----
        dt = self.t / float(self.n_substeps)
        coef_diff_1 = lamda * D ** 2 * pi / self.Hstr_1 / 4.0
        coef_diff_N = lamda * D ** 2 * pi / self.Hstr_N / 4.0
        coef_diff_i = lamda * D ** 2 * pi / self.Hstr / 4.0
        cap_1 = rho * C * self.Vstr_1
        cap_N = rho * C * self.Vstr_N
        cap_i = rho * C * self.Vstr

        P = [0.0] * N
        for _ in range(self.n_substeps):
            T_new = [0.0] * N

            # Couche 1 (top) -- contient port_hot_a (entree) et port_hot_b (sortie)
            T1 = self.T[0]
            T2 = self.T[1]
            P[0] = (m_hot_a * C * T_hot_a
                    + m_hot_b * C * T1
                    + PP * m_plus * C * T2
                    + MM * m_moins * C * (-T1)
                    + coef_diff_1 * (T2 - T1)
                    + self.U * self.A1 * (Tamb - T1))
            T_new[0] = T1 + dt * P[0] / cap_1

            # Couche N (bottom) -- contient port_cold_a (entree) et port_cold_b (sortie)
            TN = self.T[N - 1]
            TNm1 = self.T[N - 2]
            P[N - 1] = (m_cold_a * C * T_cold_a
                        + m_cold_b * C * TN
                        + PP * m_plus * C * (-TN)
                        + MM * m_moins * C * TNm1
                        + coef_diff_N * (TNm1 - TN)
                        + self.U * self.An * (Tamb - TN))
            T_new[N - 1] = TN + dt * P[N - 1] / cap_N

            # Couches intermediaires
            for i in range(1, N - 1):
                Ti = self.T[i]
                Tip1 = self.T[i + 1]
                Tim1 = self.T[i - 1]
                P[i] = (PP * m_plus * C * (Tip1 - Ti)
                        + MM * m_moins * C * (Tim1 - Ti)
                        + coef_diff_i * (Tip1 + Tim1 - 2.0 * Ti)
                        + self.U * self.Ai * (Tamb - Ti))
                T_new[i] = Ti + dt * P[i] / cap_i

            self.T = T_new

        # ---- Sorties ----
        self.T_degC = [Ti - 273.15 for Ti in self.T]
        self.P = P
        self.P_ballon = sum(P)

        T_hot_b_K = self.T[0]
        T_cold_b_K = self.T[N - 1]

        # Energie echangee sur le pas (somme par couche avec son volume reel)
        V_layer = [self.Vstr_1] + [self.Vstr] * (N - 2) + [self.Vstr_N]
        delta_J = sum(rho * V_layer[i] * C * (self.T[i] - T_before[i]) for i in range(N))
        self.Qstr_J = delta_J
        self.Qstr_kWh = delta_J / 3.6e6
        self.Qstr_kW = self.Qstr_kWh / (self.t / 3600.0)
        self.cumul_Qstr_kWh += self.Qstr_kWh

        # Energie stockee absolue / Tinit (style Modelica : V/N moyen)
        self.Delta_u_J = sum(rho * self.V / N * C * (Ti - self._Tinit_K_const)
                             for Ti in self.T)
        self.Delta_u_kWh = self.Delta_u_J / 3.6e6

        # ---- Connecteurs sortants ----
        # Pression : ballon a pression unique (port_hot_a impose)
        P_tank = self.port_hot_a.P if self.port_hot_a.P is not None else self.port_cold_a.P
        fluid = self.port_hot_a.fluid

        self.port_hot_b.fluid = fluid
        self.port_hot_b.P = P_tank
        if P_tank is not None:
            self.port_hot_b.h = PropsSI('H', 'P', P_tank, 'T', T_hot_b_K, fluid)

        self.port_cold_b.fluid = fluid
        self.port_cold_b.P = P_tank
        if P_tank is not None:
            self.port_cold_b.h = PropsSI('H', 'P', P_tank, 'T', T_cold_b_K, fluid)

        # ---- DataFrame de reporting ----
        self.df = pd.DataFrame(
            {'StratifiedStorageTank': [
                self.Timestamp, fluid,
                T_hot_a - 273.15, T_cold_a - 273.15,
                F_hot_a, F_cold_a, F_hot_b, F_cold_b,
                T_hot_b_K - 273.15, T_cold_b_K - 273.15,
                self.Qstr_kWh, self.Qstr_kW, self.cumul_Qstr_kWh,
                self.Delta_u_kWh, self.P_ballon,
            ]},
            index=[
                'Timestamp', 'fluid',
                'T_hot_a_degC', 'T_cold_a_degC',
                'F_hot_a', 'F_cold_a', 'F_hot_b', 'F_cold_b',
                'T_hot_b_degC', 'T_cold_b_degC',
                'Qstr_kWh', 'Qstr_kW', 'cumul_Qstr_kWh',
                'Delta_u_kWh', 'P_ballon_W',
            ])
