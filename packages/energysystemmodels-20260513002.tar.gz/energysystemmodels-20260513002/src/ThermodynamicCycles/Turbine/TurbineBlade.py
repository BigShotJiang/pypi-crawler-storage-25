"""TurbineBlade -- turbine a aubes avec equation de Stodola
(Modelica RotatingMachines.TurbineBlade).

Differe de la turbine volumetrique : le debit est lie a la pression amont/aval
par l'equation de Stodola (ellipse) :  m_flow^2 = K * (P_a^2 - P_b^2) / T_a

Equations :
    m_flow^2 = K * (P_a^2 - P_b^2) / T_a    (Stodola)
    h_iso_b = h(P_b, S_a)
    h_b = h_a + (h_iso_b - h_a) * epsilon_s   (detente reelle)
    P_ext = -m_flow * (h_b - h_a)             (puissance recuperee, P_ext > 0)

Convention Python :
    Inlet  -> port_a (haute pression)
    Outlet -> port_b (basse pression)
"""

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort
from CoolProp.CoolProp import PropsSI
import math
import pandas as pd


class Object:
    def __init__(self):
        self.Timestamp = None

        self.Inlet = FluidPort()
        self.Outlet = FluidPort()

        self.epsilon_s = 0.7          # rendement isentropique
        self.K = 1.0                  # coefficient Stodola (kg^2.K.s^-2.Pa^-2)
        self.purpose = "simulation"   # "simulation" : K impose / "design" : dp impose
        self.dp_design = 1e5          # delta P pour mode design

        # Sorties
        self.m_flow = None
        self.P_ext = None
        self.T_iso_K = None
        self.T_out_K = None
        self.df = []

    def calculate(self):
        fluid = self.Inlet.fluid
        P_a = self.Inlet.P
        h_a = self.Inlet.h

        if self.purpose == "design":
            P_b = P_a - self.dp_design
        else:
            P_b = self.Outlet.P
            if P_b is None:
                raise ValueError("TurbineBlade simulation : Outlet.P doit etre defini")

        T_a = PropsSI('T', 'P', P_a, 'H', h_a, fluid)
        S_a = PropsSI('S', 'P', P_a, 'H', h_a, fluid)

        # Stodola
        if P_a <= P_b:
            self.m_flow = 0.0
        else:
            self.m_flow = math.sqrt(self.K * (P_a ** 2 - P_b ** 2) / T_a)

        # Detente
        h_iso_b = PropsSI('H', 'P', P_b, 'S', S_a, fluid)
        self.T_iso_K = PropsSI('T', 'P', P_b, 'S', S_a, fluid)
        h_b = h_a + (h_iso_b - h_a) * self.epsilon_s
        self.T_out_K = PropsSI('T', 'P', P_b, 'H', h_b, fluid)

        self.P_ext = -self.m_flow * (h_b - h_a)  # > 0 produite

        self.Outlet.fluid = fluid
        self.Outlet.P = P_b
        self.Outlet.h = h_b
        self.Outlet.F = self.m_flow
        self.Inlet.F = self.m_flow

        Ti_degC = T_a - 273.15
        self.df = pd.DataFrame(
            {'TurbineBlade': [self.Timestamp, fluid, self.m_flow, Ti_degC,
                              self.T_iso_K - 273.15, self.T_out_K - 273.15,
                              self.P_ext / 1000.0, P_a / 1e5, P_b / 1e5]},
            index=['Timestamp', 'fluid', 'm_flow_kgs', 'Ti_degC',
                   'Tiso_degC', 'To_degC', 'P_ext_kW', 'Pa_bar', 'Pb_bar'])
