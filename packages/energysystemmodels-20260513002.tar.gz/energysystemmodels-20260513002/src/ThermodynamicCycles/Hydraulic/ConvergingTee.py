"""ConvergingTee -- te convergent (Modelica PressureLoss.Tee.ConvergingWye).

Deux flux entrants se rejoignent en un seul flux sortant :
- Inlet_St : flux principal (axe)
- Inlet_S  : flux lateral (branche, angle alpha)
- Outlet   : flux combine (commun)

Coefficients de perte (Idel'cik diagrammes 7-22 a 7-25) :
- ksi_St_to_C = perte ramenee a V_C (vitesse combinee)
- ksi_S_to_C  = perte ramenee a V_C

Pour un te a 90°, sections egales :
    Q_s/Q_c    : 0.0    0.2    0.4    0.6    0.8    1.0
    ksi_St->C  : 0.04  -0.04   0.13   0.39   0.67   0.95
    ksi_S->C   : -1.20 -0.40   0.08   0.47   0.73   0.92

Bilan masse : F_C = F_St + F_S (conservation).
Bilan thermique : h_C = (F_St*h_St + F_S*h_S) / F_C (melange).

Convention Python :
    Inlet_St -> port axe (entree principale)
    Inlet_S  -> port lateral (entree branche)
    Outlet   -> port C (combined, sortie)
"""

import math
import pandas as pd
from CoolProp.CoolProp import PropsSI

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort


class Object:
    def __init__(self):
        self.Timestamp = None

        self.Inlet_St = FluidPort()
        self.Inlet_S = FluidPort()
        self.Outlet = FluidPort()

        # Parametres
        self.d_hyd = 0.04                # m -- diametre commun
        self.alpha = math.pi / 2         # rad -- angle de la branche

        # Sorties
        self.rho = None
        self.A = None
        self.V_C = None
        self.q_ratio = None              # Q_S / Q_C
        self.ksi_St = None
        self.ksi_S = None
        self.dP_St_to_C = None
        self.dP_S_to_C = None
        self.df = []

    def calculate(self):
        fluid = self.Inlet_St.fluid
        P_St = self.Inlet_St.P
        P_S = self.Inlet_S.P
        h_St = self.Inlet_St.h
        h_S = self.Inlet_S.h
        m_St = self.Inlet_St.F if self.Inlet_St.F is not None else 0.0
        m_S = self.Inlet_S.F if self.Inlet_S.F is not None else 0.0

        m_C = m_St + m_S
        if m_C <= 0:
            self.Outlet.fluid = fluid
            self.Outlet.P = P_St
            self.Outlet.h = h_St
            self.Outlet.F = 0.0
            return

        # Enthalpie combinee (melange)
        h_C = (m_St * h_St + m_S * h_S) / m_C
        # Pression de reference pour le rho : on utilise P_St (les deux entrees devraient avoir P proche)
        self.rho = PropsSI('D', 'P', P_St, 'H', h_C, fluid)

        self.A = math.pi * self.d_hyd ** 2 / 4
        self.V_C = m_C / (self.rho * self.A) if self.A > 0 else 0.0
        self.q_ratio = m_S / m_C

        q = self.q_ratio
        # Fits polynomiaux Idel'cik 90° sections egales
        # ksi_St->C : negatif a faible q (succion par effet Venturi)
        self.ksi_St = 0.04 - 0.40 * q + 1.30 * q ** 2
        # ksi_S->C : grand a faible q, croit avec q
        # Modulation par alpha
        alpha_corr = math.sin(self.alpha)
        self.ksi_S = (-1.20 + 4.00 * q - 1.90 * q ** 2) * alpha_corr

        dynamic_C = 0.5 * self.rho * self.V_C ** 2
        self.dP_St_to_C = self.ksi_St * dynamic_C
        self.dP_S_to_C = self.ksi_S * dynamic_C

        # P_C : reference = P_St - dP_St->C (les deux pressions doivent converger
        # vers P_C -- si pas equilibre, l'utilisateur a impose des P incoherentes)
        P_C = P_St - self.dP_St_to_C

        self.Outlet.fluid = fluid
        self.Outlet.P = P_C
        self.Outlet.h = h_C
        self.Outlet.F = m_C

        self.df = pd.DataFrame(
            {'ConvergingTee': [self.Timestamp, fluid,
                               m_St, m_S, m_C, self.q_ratio,
                               self.V_C, self.ksi_St, self.ksi_S,
                               self.dP_St_to_C, self.dP_S_to_C,
                               math.degrees(self.alpha)]},
            index=['Timestamp', 'fluid',
                   'F_St_kgs', 'F_S_kgs', 'F_C_kgs', 'q_ratio',
                   'V_C_ms', 'ksi_St', 'ksi_S',
                   'dP_St_C_Pa', 'dP_S_C_Pa', 'alpha_deg'])
