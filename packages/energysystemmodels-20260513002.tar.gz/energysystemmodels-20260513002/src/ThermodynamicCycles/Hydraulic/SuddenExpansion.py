"""SuddenExpansion -- elargissement brusque (Modelica PressureLoss.Orifice.SuddenExpansionOrifice).

Perte de charge par theoreme de Borda-Carnot :
    ksi_LOC = (1 - A_small/A_large)^2     (ramene a V_small = V_amont)
    delta_P_friction = ksi * 0.5 * rho * V_small^2

Bilan statique (Bernoulli generalise):
    P_static_amont + 0.5*rho*V_small^2 = P_static_aval + 0.5*rho*V_large^2 + delta_P_friction
    => P_aval - P_amont = 0.5*rho*(V_small^2 - V_large^2) - delta_P_friction
       (la pression statique remonte, mais moins qu'en ecoulement parfait)

Convention Python :
    Inlet  -> port amont (cote petite section, vitesse elevee)
    Outlet -> port aval (cote grande section)
    Parametres : d_hyd_small, d_hyd_large
"""

import math
import pandas as pd
from CoolProp.CoolProp import PropsSI

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort


class Object:
    def __init__(self):
        self.Timestamp = None

        self.Inlet = FluidPort()
        self.Outlet = FluidPort()

        # Parametres
        self.d_hyd_small = 0.04          # m -- amont (Inlet)
        self.d_hyd_large = 0.10          # m -- aval (Outlet)

        # Sorties
        self.rho = None
        self.A_small = None
        self.A_large = None
        self.V_small = None
        self.V_large = None
        self.ksi_loc = None
        self.delta_P_friction = None     # frottement (perte irreversible)
        self.delta_P_static = None       # variation P statique (= -dP_cinetique + dP_friction)
        self.df = []

    def calculate(self):
        fluid = self.Inlet.fluid
        P = self.Inlet.P
        h = self.Inlet.h
        m = self.Inlet.F if self.Inlet.F is not None else 0.0

        self.rho = PropsSI('D', 'P', P, 'H', h, fluid)

        self.A_small = math.pi * self.d_hyd_small ** 2 / 4
        self.A_large = math.pi * self.d_hyd_large ** 2 / 4

        self.V_small = m / (self.rho * self.A_small) if self.A_small > 0 else 0.0
        self.V_large = m / (self.rho * self.A_large) if self.A_large > 0 else 0.0

        # Borda-Carnot
        ratio = self.A_small / self.A_large if self.A_large > 0 else 0.0
        self.ksi_loc = (1.0 - ratio) ** 2

        self.delta_P_friction = self.ksi_loc * 0.5 * self.rho * self.V_small ** 2

        # Variation pression statique : dP_cinetique = 0.5*rho*(V_small^2 - V_large^2) > 0
        # P_aval = P_amont + dP_cinetique - dP_friction
        dP_cinetique = 0.5 * self.rho * (self.V_small ** 2 - self.V_large ** 2)
        # P_static rises if dP_cinetique > dP_friction
        delta_P_total = dP_cinetique - self.delta_P_friction
        self.delta_P_static = delta_P_total

        self.Outlet.fluid = fluid
        self.Outlet.h = h
        self.Outlet.F = m
        self.Outlet.P = P + delta_P_total       # >0 -> P static remonte

        self.df = pd.DataFrame(
            {'SuddenExpansion': [self.Timestamp, fluid, m,
                                 self.d_hyd_small * 1000, self.d_hyd_large * 1000,
                                 self.V_small, self.V_large,
                                 self.ksi_loc, self.delta_P_friction,
                                 self.delta_P_static]},
            index=['Timestamp', 'fluid', 'F_kgs',
                   'd_small_mm', 'd_large_mm',
                   'V_small_ms', 'V_large_ms',
                   'ksi_loc', 'dP_friction_Pa', 'dP_static_Pa'])
