"""CurvedBend -- coude courbe (Modelica PressureLoss.Bend.CurvedBend).

Perte de charge dans un coude courbe = singularité (turning) + friction le long de la longueur developpee.

Equations (Idel'cik / Modelica.Fluid.Dissipation):
    L_dev = R_0 * delta              (longueur developpee)
    Re = rho * V * d_hyd / eta
    lambda_FRI = friction factor (Colebrook)
    ksi_loc = 0.21 / (R_0/d_hyd)^2.5  pour delta=90°
              x f_delta(delta) pour autres angles
    delta_P = (ksi_loc + lambda_FRI * L_dev/d_hyd) * 0.5 * rho * V^2

Convention Python :
    Inlet  -> port amont (I)
    Outlet -> port aval  (O)
    Parametres : d_hyd, R_0, delta (rad), K (rugosite m)
"""

import math
import pandas as pd
from CoolProp.CoolProp import PropsSI

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort


class Object:
    def __init__(self):
        self.Timestamp = None

        self.Inlet = FluidPort()
        self.Outlet = FluidPort()

        # Parametres
        self.d_hyd = 0.04                # m
        self.R_0 = None                  # m -- rayon de courbure (defaut : 0.5*d_hyd)
        self.delta = math.pi / 2         # rad -- angle (defaut 90°)
        self.K = 0.0015e-3               # m -- rugosite

        # Sorties
        self.rho = None
        self.eta = None
        self.A = None
        self.V = None
        self.Re = None
        self.ksi_loc = None              # coefficient singularite
        self.lambda_FRI = None
        self.delta_P = None              # Pa
        self.df = []

    @staticmethod
    def _friction_factor(Re, k_d):
        """Colebrook-White explicit (Swamee-Jain)."""
        if Re < 2300:
            return 64.0 / max(Re, 1.0)
        return 0.25 / (math.log10(k_d / 3.7 + 5.74 / Re ** 0.9)) ** 2

    def calculate(self):
        if self.R_0 is None:
            self.R_0 = 0.5 * self.d_hyd

        fluid = self.Inlet.fluid
        P = self.Inlet.P
        h = self.Inlet.h
        m = self.Inlet.F if self.Inlet.F is not None else 0.0

        self.rho = PropsSI('D', 'P', P, 'H', h, fluid)
        self.eta = PropsSI('V', 'P', P, 'H', h, fluid)

        self.A = math.pi * self.d_hyd ** 2 / 4
        self.V = m / (self.rho * self.A) if self.A > 0 else 0.0
        self.Re = self.rho * self.V * self.d_hyd / self.eta if self.eta > 0 else 0.0

        # Coefficient singularite (Idel'cik / Modelica Dissipation)
        # Pour delta=90°, R/d=0.5 -> ksi ~ 0.21/(0.5)^2.5 ~ 1.19
        # Generalisation : ksi = 0.21 / (R0/d_hyd)^2.5 * (delta/90°)
        delta_deg = math.degrees(self.delta)
        f_delta = delta_deg / 90.0       # facteur lineaire approche
        if (self.R_0 / self.d_hyd) > 0:
            self.ksi_loc = 0.21 / (self.R_0 / self.d_hyd) ** 2.5 * f_delta
        else:
            self.ksi_loc = 1.19 * f_delta

        # Friction le long de la longueur developpee
        L_dev = self.R_0 * self.delta
        k_d = self.K / self.d_hyd
        self.lambda_FRI = self._friction_factor(self.Re, k_d)

        ksi_total = self.ksi_loc + self.lambda_FRI * L_dev / self.d_hyd
        self.delta_P = ksi_total * 0.5 * self.rho * self.V ** 2

        # Connecteur sortie (isenthalpique, P decroit)
        self.Outlet.fluid = fluid
        self.Outlet.h = h
        self.Outlet.F = m
        self.Outlet.P = P - self.delta_P

        self.df = pd.DataFrame(
            {'CurvedBend': [self.Timestamp, fluid, m, self.d_hyd * 1000,
                            self.R_0 / self.d_hyd, delta_deg,
                            self.V, self.Re,
                            self.ksi_loc, self.lambda_FRI,
                            self.delta_P, self.delta_P / 100]},
            index=['Timestamp', 'fluid', 'F_kgs', 'd_hyd_mm',
                   'R0_d_hyd', 'delta_deg',
                   'V_ms', 'Re', 'ksi_loc', 'lambda_FRI',
                   'dP_Pa', 'dP_mbar'])
