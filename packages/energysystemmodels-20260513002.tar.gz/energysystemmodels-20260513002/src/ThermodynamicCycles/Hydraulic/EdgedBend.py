"""EdgedBend -- coude vif (Modelica PressureLoss.Bend.EdgedBend).

Perte de charge dans un coude a angle vif (sans rayon de courbure).
Correlation Idel'cik :
    ksi_loc = 0.95 * sin(delta/2)^2 + 2.05 * sin(delta/2)^4
    A 90°   : ksi ~ 0.95 + 2.05 = 1.1
    A 45°   : ksi ~ 0.137
    A 30°   : ksi ~ 0.063

Convention Python :
    Inlet  -> port amont (I)
    Outlet -> port aval  (O)
    Parametres : d_hyd, delta (rad), K (rugosite, optionnel)
"""

import math
import pandas as pd
from CoolProp.CoolProp import PropsSI

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort


class Object:
    def __init__(self):
        self.Timestamp = None

        self.Inlet = FluidPort()
        self.Outlet = FluidPort()

        # Parametres
        self.d_hyd = 0.04                # m
        self.delta = math.pi / 2         # rad -- angle (defaut 90°)

        # Sorties
        self.rho = None
        self.eta = None
        self.A = None
        self.V = None
        self.Re = None
        self.ksi_loc = None
        self.delta_P = None              # Pa
        self.df = []

    def calculate(self):
        fluid = self.Inlet.fluid
        P = self.Inlet.P
        h = self.Inlet.h
        m = self.Inlet.F if self.Inlet.F is not None else 0.0

        self.rho = PropsSI('D', 'P', P, 'H', h, fluid)
        self.eta = PropsSI('V', 'P', P, 'H', h, fluid)

        self.A = math.pi * self.d_hyd ** 2 / 4
        self.V = m / (self.rho * self.A) if self.A > 0 else 0.0
        self.Re = self.rho * self.V * self.d_hyd / self.eta if self.eta > 0 else 0.0

        # Correlation Idel'cik pour coude vif
        s = math.sin(self.delta / 2)
        self.ksi_loc = 0.95 * s ** 2 + 2.05 * s ** 4

        self.delta_P = self.ksi_loc * 0.5 * self.rho * self.V ** 2

        self.Outlet.fluid = fluid
        self.Outlet.h = h
        self.Outlet.F = m
        self.Outlet.P = P - self.delta_P

        self.df = pd.DataFrame(
            {'EdgedBend': [self.Timestamp, fluid, m, self.d_hyd * 1000,
                           math.degrees(self.delta),
                           self.V, self.Re, self.ksi_loc,
                           self.delta_P, self.delta_P / 100]},
            index=['Timestamp', 'fluid', 'F_kgs', 'd_hyd_mm',
                   'delta_deg', 'V_ms', 'Re', 'ksi_loc',
                   'dP_Pa', 'dP_mbar'])
