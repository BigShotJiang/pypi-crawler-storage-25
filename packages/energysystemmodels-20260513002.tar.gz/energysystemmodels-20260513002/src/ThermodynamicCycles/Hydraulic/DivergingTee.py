"""DivergingTee -- te divergent (Modelica PressureLoss.Tee.DivergingWye).

Un seul flux entrant (port commun C, "combined") se separe en deux flux sortants :
- branche straight (St) : continue dans l'axe
- branche side (S)      : derive a un angle alpha (typiquement 90°)

Coefficients de perte (Idel'cik diagrammes 7-15 a 7-19) :
- ksi_C_to_St = perte ramenee a V_C (vitesse combinee)
- ksi_C_to_S  = perte ramenee a V_C

Pour un te a angle 90° et sections egales (cas standard) :
    Q_s/Q_c    : 0.0    0.2    0.4    0.6    0.8    1.0
    ksi_C->St  : 0.04   0.17   0.30   0.41   0.51   0.60
    ksi_C->S   : 1.00   1.00   1.01   1.05   1.13   1.20

On utilise une approximation polynomiale fittee sur ces valeurs.

Convention Python :
    Inlet     -> port C (combined, entree)
    Outlet_St -> port St (straight, sortie axe)
    Outlet_S  -> port S (side, sortie laterale)
    L'utilisateur impose F_C en entree et F_S sur la branche side.
    F_St est calcule par bilan masse : F_St = F_C - F_S.
"""

import math
import pandas as pd
from CoolProp.CoolProp import PropsSI

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort


class Object:
    def __init__(self):
        self.Timestamp = None

        self.Inlet = FluidPort()         # port C (combined)
        self.Outlet_St = FluidPort()     # port straight
        self.Outlet_S = FluidPort()      # port side branch

        # Parametres
        self.d_hyd = 0.04                # m -- diametre commun
        self.alpha = math.pi / 2         # rad -- angle de la branche (defaut 90°)

        # Sorties
        self.rho = None
        self.A = None
        self.V_C = None
        self.q_ratio = None              # Q_s / Q_c
        self.ksi_St = None
        self.ksi_S = None
        self.dP_C_to_St = None
        self.dP_C_to_S = None
        self.df = []

    def calculate(self):
        fluid = self.Inlet.fluid
        P = self.Inlet.P
        h = self.Inlet.h
        m_C = self.Inlet.F if self.Inlet.F is not None else 0.0
        m_S = self.Outlet_S.F if self.Outlet_S.F is not None else 0.0

        # Bilan masse : m_St = m_C - m_S
        m_St = m_C - m_S
        if m_St < 0:
            raise ValueError("DivergingTee : F_S > F_C (impossible)")

        self.rho = PropsSI('D', 'P', P, 'H', h, fluid)
        self.A = math.pi * self.d_hyd ** 2 / 4
        self.V_C = m_C / (self.rho * self.A) if self.A > 0 else 0.0
        self.q_ratio = m_S / m_C if m_C > 0 else 0.0

        q = self.q_ratio
        # Fits polynomiaux Idel'cik 90° sections egales
        self.ksi_St = 0.04 + 0.65 * q + 0.05 * q ** 2
        # Modulation par alpha (90° -> sin=1.0 ; 45° -> 0.707)
        alpha_corr = math.sin(self.alpha)
        self.ksi_S = (1.00 + 0.20 * q ** 2) * alpha_corr

        # Pertes (referencees a V_C)
        dynamic_C = 0.5 * self.rho * self.V_C ** 2
        self.dP_C_to_St = self.ksi_St * dynamic_C
        self.dP_C_to_S = self.ksi_S * dynamic_C

        # Connecteurs sortie
        self.Outlet_St.fluid = fluid
        self.Outlet_St.h = h
        self.Outlet_St.F = m_St
        self.Outlet_St.P = P - self.dP_C_to_St

        self.Outlet_S.fluid = fluid
        self.Outlet_S.h = h
        self.Outlet_S.P = P - self.dP_C_to_S

        self.df = pd.DataFrame(
            {'DivergingTee': [self.Timestamp, fluid,
                              m_C, m_St, m_S, self.q_ratio,
                              self.V_C, self.ksi_St, self.ksi_S,
                              self.dP_C_to_St, self.dP_C_to_S,
                              math.degrees(self.alpha)]},
            index=['Timestamp', 'fluid',
                   'F_C_kgs', 'F_St_kgs', 'F_S_kgs', 'q_ratio',
                   'V_C_ms', 'ksi_St', 'ksi_S',
                   'dP_C_St_Pa', 'dP_C_S_Pa', 'alpha_deg'])
