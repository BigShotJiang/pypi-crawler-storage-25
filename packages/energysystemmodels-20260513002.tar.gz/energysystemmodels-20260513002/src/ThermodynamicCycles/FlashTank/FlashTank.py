"""FlashTank -- detente flash a pression imposee (Modelica FlashTank.FlashTank_pressureFixed).

Principe : un fluide (souvent sous-refroidi/sature) entre a P_a, est detendu
a P_flash < P_a, ce qui produit un melange diphasique. Le ballon flash separe
la vapeur (port_b) du liquide (port_c) saturees a P_flash.

Equations :
    port_a.p = p_port_a (parametre / impose)
    port_b.p = port_c.p = p_flash (= port_a.p ici, sans perte locale)
    Bilan masse :  m_a = m_b + m_c
    Bilan energie : m_a * h_a = m_b * h_b + m_c * h_c
    h_b = dewEnthalpy(p_flash)        (vapeur saturee)
    h_c = bubbleEnthalpy(p_flash)     (liquide sature)
    -> x = (h_a - h_c) / (h_b - h_c)  (fraction vapeur produite)

Convention Python :
    Inlet           -> port_a (haute pression amont, monophasique liquide en general)
    Outlet_vapor    -> port_b (vapeur saturee a P_flash)
    Outlet_liquid   -> port_c (liquide sature a P_flash)

Note : si l'entree est superchauffee  (h_a > h_b),  x est plafonne a 1 (tout vapeur).
       Si sous-refroidie (h_a < h_c), x = 0 (pas de flash).
"""

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort
from CoolProp.CoolProp import PropsSI
import pandas as pd


class Object:
    def __init__(self):
        self.Timestamp = None

        self.Inlet = FluidPort()
        self.Outlet_vapor = FluidPort()
        self.Outlet_liquid = FluidPort()

        # Pression de flash (Pa). Si None, on prend Inlet.P (pas de detente).
        self.P_flash = None

        # Sorties
        self.x = None               # fraction vapeur produite
        self.h_vapor = None
        self.h_liquid = None
        self.T_flash_degC = None
        self.Q_flash_W = None       # chaleur latente liberee = m_b * (h_b - h_c)
        self.df = []

    def calculate(self):
        fluid = self.Inlet.fluid
        P_a = self.Inlet.P
        h_a = self.Inlet.h
        F_a = self.Inlet.F if self.Inlet.F is not None else 0.0

        P_flash = self.P_flash if self.P_flash is not None else P_a

        # Enthalpies de saturation a P_flash
        self.h_liquid = PropsSI('H', 'P', P_flash, 'Q', 0, fluid)
        self.h_vapor = PropsSI('H', 'P', P_flash, 'Q', 1, fluid)
        T_sat = PropsSI('T', 'P', P_flash, 'Q', 0, fluid)
        self.T_flash_degC = T_sat - 273.15

        # Fraction vapeur produite : conservation enthalpie h_a = x*h_v + (1-x)*h_l
        # -> x = (h_a - h_l)/(h_v - h_l), borne dans [0,1]
        if self.h_vapor > self.h_liquid:
            x_raw = (h_a - self.h_liquid) / (self.h_vapor - self.h_liquid)
        else:
            x_raw = 0.0
        x = max(0.0, min(1.0, x_raw))
        self.x = x

        F_vapor = x * F_a
        F_liquid = (1.0 - x) * F_a

        # Outlet vapeur (port_b)
        self.Outlet_vapor.fluid = fluid
        self.Outlet_vapor.P = P_flash
        self.Outlet_vapor.h = self.h_vapor
        self.Outlet_vapor.F = F_vapor

        # Outlet liquide (port_c)
        self.Outlet_liquid.fluid = fluid
        self.Outlet_liquid.P = P_flash
        self.Outlet_liquid.h = self.h_liquid
        self.Outlet_liquid.F = F_liquid

        # Chaleur latente extraite par la vapeur produite
        self.Q_flash_W = F_vapor * (self.h_vapor - self.h_liquid)

        self.df = pd.DataFrame(
            {'FlashTank': [self.Timestamp, fluid, F_a, P_a / 1e5,
                           P_flash / 1e5, self.T_flash_degC, x,
                           F_vapor, F_liquid, self.Q_flash_W / 1000.0]},
            index=['Timestamp', 'fluid', 'F_in_kgs', 'P_in_bar', 'P_flash_bar',
                   'T_flash_degC', 'x', 'F_vapor_kgs', 'F_liquid_kgs',
                   'Q_flash_kW'])
