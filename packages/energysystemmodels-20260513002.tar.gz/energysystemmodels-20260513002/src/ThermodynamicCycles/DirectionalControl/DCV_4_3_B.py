"""DCV_4_3_B -- vanne directionnelle 4 voies / 3 positions, centre type B
(Modelica DirectionalControl.DCV_4_3_B).

4 ports : A, B, P, T - 3 positions (entier u dans {-1, 0, 1}) :
  - u = -1 : P->B et A->T  (mouvement inverse)
  - u =  0 : tous les ports bloques (centre ferme, type B)
  - u = +1 : P->A et B->T  (mouvement direct)

Convention Python :
    Inlet_P, Outlet_T : cote alimentation
    port_A, port_B    : cote actionneur
    u (int)           : -1 / 0 / +1
"""

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort
import pandas as pd


class Object:
    def __init__(self):
        self.Timestamp = None

        self.Inlet_P = FluidPort()
        self.Outlet_T = FluidPort()
        self.port_A = FluidPort()
        self.port_B = FluidPort()

        self.u = 0                     # -1 / 0 / +1
        self.df = []

    def calculate(self):
        if self.u == 0:
            # Tous les debits bloques
            self.port_A.F = 0.0
            self.port_B.F = 0.0
            self.Outlet_T.F = 0.0
            label = "centre bloque"
        elif self.u > 0:
            # P -> A, B -> T
            self.port_A.fluid = self.Inlet_P.fluid
            self.port_A.P = self.Inlet_P.P
            self.port_A.h = self.Inlet_P.h
            self.port_A.F = self.Inlet_P.F if self.Inlet_P.F is not None else 0.0

            self.Outlet_T.fluid = self.port_B.fluid
            self.Outlet_T.P = self.port_B.P
            self.Outlet_T.h = self.port_B.h
            self.Outlet_T.F = self.port_B.F if self.port_B.F is not None else 0.0
            label = "P->A, B->T"
        else:  # u < 0
            # P -> B, A -> T
            self.port_B.fluid = self.Inlet_P.fluid
            self.port_B.P = self.Inlet_P.P
            self.port_B.h = self.Inlet_P.h
            self.port_B.F = self.Inlet_P.F if self.Inlet_P.F is not None else 0.0

            self.Outlet_T.fluid = self.port_A.fluid
            self.Outlet_T.P = self.port_A.P
            self.Outlet_T.h = self.port_A.h
            self.Outlet_T.F = self.port_A.F if self.port_A.F is not None else 0.0
            label = "P->B, A->T"

        self.df = pd.DataFrame(
            {'DCV_4_3_B': [self.Timestamp, label, int(self.u),
                           (self.Inlet_P.F if self.Inlet_P.F is not None else 0.0)]},
            index=['Timestamp', 'route', 'u', 'F_supply_kgs'])
