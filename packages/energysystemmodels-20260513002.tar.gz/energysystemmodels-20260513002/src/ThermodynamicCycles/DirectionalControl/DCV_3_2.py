"""DCV_3_2 -- vanne directionnelle 3 voies / 2 positions
(Modelica DirectionalControl.DCV_3_2).

3 ports : A, P, T - 2 positions logiques (booleen u) :
  - u = False (repos) : P -> A (T isole)
  - u = True  (active) : T -> A (P isole)

Modelisation : on transmet integralement le fluide d'un cote a l'autre selon u.
Le port A peut etre entree (recoit) ou sortie (envoie) selon le scenario, mais
par defaut on suppose que A est cote utilisation (port commun) et P, T sont
les ports d'alimentation alternatives.

Convention Python :
    Inlet_P, Inlet_T : entrees (deux sources alternatives)
    Outlet_A         : sortie commune
    u (bool)         : True -> source = T, False -> source = P
"""

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort
import pandas as pd


class Object:
    def __init__(self):
        self.Timestamp = None

        self.Inlet_P = FluidPort()
        self.Inlet_T = FluidPort()
        self.Outlet_A = FluidPort()

        self.u = False                # False : P -> A,  True : T -> A
        self.df = []

    def calculate(self):
        if self.u:
            src = self.Inlet_T
            label = "T->A"
        else:
            src = self.Inlet_P
            label = "P->A"

        self.Outlet_A.fluid = src.fluid
        self.Outlet_A.P = src.P
        self.Outlet_A.h = src.h
        self.Outlet_A.F = src.F if src.F is not None else 0.0

        # Le port non actif n'a pas de debit
        # (on ne touche pas a Inlet_X.F : c'est une lecture seule depuis l'amont)

        self.df = pd.DataFrame(
            {'DCV_3_2': [self.Timestamp, label, bool(self.u),
                         self.Outlet_A.F if self.Outlet_A.F is not None else 0.0,
                         (self.Outlet_A.P / 1e5) if self.Outlet_A.P else None]},
            index=['Timestamp', 'route', 'u', 'F_kgs', 'P_bar'])
