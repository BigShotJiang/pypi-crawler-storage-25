"""DCV_4_2 -- vanne directionnelle 4 voies / 2 positions
(Modelica DirectionalControl.DCV_4_2).

4 ports : A, B, P, T - 2 positions logiques (booleen u) :
  - u = False : P->A et B->T  (cylindre s'etend, fluide retour vers reservoir)
  - u = True  : P->B et A->T  (cylindre se retracte)

Modelisation : la vanne route deux paires de ports selon l'etat u.
Pas de melange ; chaque chemin est independant.

Convention Python :
    Inlet_P, Outlet_T : alimentation et retour (cote pompe)
    Outlet_A, Outlet_B : sorties cote actionneur
    Si u=False : Inlet_P -> Outlet_A,  Inlet_B -> Outlet_T (B est entree retour)
    Pour ne pas multiplier les ports, on a :
      Inlet_P, Outlet_A, Outlet_B, Outlet_T toutes orientees "sortie"
      mais le sens depend de u.

Pour simplifier l'API : 4 ports nommes selon l'orientation Modelica
    port_P (input), port_T (output, retour reservoir)
    port_A, port_B : "ports utilisateur" (entree ou sortie selon u)
"""

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort
import pandas as pd


class Object:
    def __init__(self):
        self.Timestamp = None

        # Cote alimentation
        self.Inlet_P = FluidPort()       # Pression supply (en provenance pompe)
        self.Outlet_T = FluidPort()      # Retour vers reservoir

        # Cote actionneur (le sens depend de u)
        # Pour conformer au pattern, on les nomme tous Outlet_*
        # Quand u=False : A est sortie alimentee par P, B est "entree retour" vers T
        # Quand u=True  : B est sortie alimentee par P, A est "entree retour" vers T
        self.port_A = FluidPort()
        self.port_B = FluidPort()

        self.u = False
        self.df = []

    def calculate(self):
        if not self.u:
            # P -> A (alimentation), B -> T (retour)
            # port_A devient la sortie alimentee par Inlet_P
            self.port_A.fluid = self.Inlet_P.fluid
            self.port_A.P = self.Inlet_P.P
            self.port_A.h = self.Inlet_P.h
            self.port_A.F = self.Inlet_P.F if self.Inlet_P.F is not None else 0.0

            # Outlet_T est alimente par port_B (qui est entree dans ce mode)
            self.Outlet_T.fluid = self.port_B.fluid
            self.Outlet_T.P = self.port_B.P
            self.Outlet_T.h = self.port_B.h
            self.Outlet_T.F = self.port_B.F if self.port_B.F is not None else 0.0

            label = "P->A, B->T"
        else:
            # P -> B (alimentation), A -> T (retour)
            self.port_B.fluid = self.Inlet_P.fluid
            self.port_B.P = self.Inlet_P.P
            self.port_B.h = self.Inlet_P.h
            self.port_B.F = self.Inlet_P.F if self.Inlet_P.F is not None else 0.0

            self.Outlet_T.fluid = self.port_A.fluid
            self.Outlet_T.P = self.port_A.P
            self.Outlet_T.h = self.port_A.h
            self.Outlet_T.F = self.port_A.F if self.port_A.F is not None else 0.0

            label = "P->B, A->T"

        self.df = pd.DataFrame(
            {'DCV_4_2': [self.Timestamp, label, bool(self.u),
                         (self.Inlet_P.F if self.Inlet_P.F is not None else 0.0)]},
            index=['Timestamp', 'route', 'u', 'F_supply_kgs'])
