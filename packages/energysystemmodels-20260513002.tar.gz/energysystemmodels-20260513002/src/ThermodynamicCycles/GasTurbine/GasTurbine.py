"""GasTurbine -- cycle de Brayton complet (Modelica GasTurbine.GasTurbine).

Compose de :
    Compresseur volumetrique  (port_a -> compresseur)
    Combustor                  (compresseur -> combustor)
    Turbine                    (combustor -> port_b)

Le compresseur et la turbine partagent la meme frequence de rotation (arbre
mecanique). Cette implementation expose la frequence rotor comme parametre
et calcule la puissance nette P_ext = P_turbine + P_compresseur (P_compresseur
est negatif car consomme).

Convention Python :
    Inlet  -> port_a (admission air ambiant)
    Outlet -> port_b (echappement gaz brules)
"""

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort
from ThermodynamicCycles.Compressor.VolumetricCompressor import Object as VolCompressor
from ThermodynamicCycles.GasTurbine.Combustor import Object as Combustor
import pandas as pd

# Pour la turbine, on reutilise existant Turbine.py
from ThermodynamicCycles.Turbine.Turbine import Object as Turbine


class Object:
    def __init__(self):
        self.Timestamp = None

        self.Inlet = FluidPort()
        self.Outlet = FluidPort()

        # Parametres
        self.f_rotor = 50.0           # Hz
        self.P_combustor = 8e5        # pression chambre combustion (Pa)

        # Compresseur
        self.epsilon_v_comp = 1.0
        self.epsilon_s_comp = 0.7
        self.V_s_comp = 1e-4

        # Combustor
        self.LHV = 43e6
        self.eta_combustion = 1.0
        self.m_fuel = 0.07            # kg/s

        # Turbine
        self.epsilon_s_tur = 0.7
        self.V_s_tur = 1e-4

        # Sous-composants
        self.compressor = VolCompressor()
        self.combustor = Combustor()
        self.turbine = Turbine()

        # Sorties
        self.P_ext = None
        self.P_compressor = None
        self.P_turbine = None
        self.eta_thermal = None
        self.df = []

    def calculate(self):
        # 1. Compresseur : Inlet -> Pcomb
        self.compressor.Inlet.fluid = self.Inlet.fluid
        self.compressor.Inlet.P = self.Inlet.P
        self.compressor.Inlet.h = self.Inlet.h
        self.compressor.Outlet.P = self.P_combustor
        self.compressor.epsilon_v = self.epsilon_v_comp
        self.compressor.epsilon_s = self.epsilon_s_comp
        self.compressor.V_s = self.V_s_comp
        self.compressor.f_rotor = self.f_rotor
        self.compressor.calculate()

        # 2. Combustor
        self.combustor.Inlet.fluid = self.compressor.Outlet.fluid
        self.combustor.Inlet.P = self.compressor.Outlet.P
        self.combustor.Inlet.h = self.compressor.Outlet.h
        self.combustor.Inlet.F = self.compressor.Outlet.F
        self.combustor.LHV = self.LHV
        self.combustor.eta_combustion = self.eta_combustion
        self.combustor.m_fuel = self.m_fuel
        self.combustor.calculate()

        # 3. Turbine : detente jusqu'a P_outlet (impose par Outlet.P)
        # La turbine existante (Turbine.py) attend HP_bar et eta_is.
        # On utilise le nouveau pattern : Inlet + Outlet.P + epsilon_s
        self.turbine.Inlet.fluid = self.combustor.Outlet.fluid
        self.turbine.Inlet.P = self.combustor.Outlet.P
        self.turbine.Inlet.h = self.combustor.Outlet.h
        self.turbine.Inlet.F = self.combustor.Outlet.F

        # On essaie d'utiliser l'API existante de Turbine.py (HP_bar etc.)
        # Si ca ne fonctionne pas, on retombe sur un calcul direct
        try:
            self.turbine.HP_bar = self.combustor.Outlet.P / 1e5
            self.turbine.LP_bar = (self.Outlet.P / 1e5
                                   if self.Outlet.P is not None else 1.013)
            self.turbine.eta_is = self.epsilon_s_tur
            self.turbine.calculate()
        except Exception:
            # Calcul direct si API differente
            from CoolProp.CoolProp import PropsSI
            S_in = PropsSI('S', 'P', self.combustor.Outlet.P, 'H',
                           self.combustor.Outlet.h, self.combustor.Outlet.fluid)
            P_out = self.Outlet.P
            h_iso = PropsSI('H', 'P', P_out, 'S', S_in,
                            self.combustor.Outlet.fluid)
            h_out = (self.combustor.Outlet.h
                     + self.epsilon_s_tur * (h_iso - self.combustor.Outlet.h))
            self.turbine.Outlet.fluid = self.combustor.Outlet.fluid
            self.turbine.Outlet.P = P_out
            self.turbine.Outlet.h = h_out
            self.turbine.Outlet.F = self.combustor.Outlet.F
            self.P_turbine = -self.combustor.Outlet.F * (h_out - self.combustor.Outlet.h)

        self.Outlet.fluid = self.turbine.Outlet.fluid
        self.Outlet.P = self.turbine.Outlet.P
        self.Outlet.h = self.turbine.Outlet.h
        self.Outlet.F = self.turbine.Outlet.F

        # Bilans
        self.P_compressor = self.compressor.P_ext  # > 0 = consomme
        if hasattr(self.turbine, 'P_ext') and self.turbine.P_ext is not None:
            self.P_turbine = self.turbine.P_ext
        # Si la turbine existante stocke W_turbine ailleurs, on essaie:
        if self.P_turbine is None:
            self.P_turbine = (self.combustor.Outlet.F
                              * (self.combustor.Outlet.h - self.Outlet.h))

        self.P_ext = self.P_turbine - self.P_compressor
        if self.combustor.P_fuel > 0:
            self.eta_thermal = self.P_ext / self.combustor.P_fuel
        else:
            self.eta_thermal = 0.0

        self.df = pd.DataFrame(
            {'GasTurbine': [self.Timestamp, self.Inlet.fluid,
                            self.compressor.m_flow, self.m_fuel,
                            self.combustor.To_degC,
                            self.P_compressor / 1000.0,
                            self.combustor.P_fuel / 1000.0,
                            self.P_turbine / 1000.0,
                            self.P_ext / 1000.0,
                            self.eta_thermal]},
            index=['Timestamp', 'fluid', 'm_air_kgs', 'm_fuel_kgs',
                   'T_combustor_degC', 'P_compr_kW', 'P_fuel_kW',
                   'P_turbine_kW', 'P_net_kW', 'eta_thermal'])
