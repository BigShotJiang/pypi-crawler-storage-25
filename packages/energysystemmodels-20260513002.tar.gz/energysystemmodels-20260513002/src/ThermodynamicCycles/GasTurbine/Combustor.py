"""Combustor -- chambre de combustion (Modelica GasTurbine.Combustor).

Modelisation simplifiee : pas de chimie, juste apport de chaleur via le
pouvoir calorifique inferieur du combustible.

Equations :
    Bilan masse : m_a + m_fuel = m_b
    Pression : port_a.p = port_b.p (sans perte de charge)
    Bilan energie :
        m_b * h_b = (m_a + m_fuel) * h_a + P_fuel - Q_cooling
        avec P_fuel = m_fuel * LHV * eta_combustion

Hypothese du modele Modelica : enthalpie du combustible = enthalpie du gaz amont,
donc le terme P_fuel apparait directement comme apport.

Convention Python :
    Inlet  -> port_a (air comprime)
    Outlet -> port_b (gaz brules)
    m_fuel : debit de combustible (kg/s)
"""

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort
from CoolProp.CoolProp import PropsSI
import pandas as pd


class Object:
    def __init__(self):
        self.Timestamp = None

        self.Inlet = FluidPort()
        self.Outlet = FluidPort()

        # Parametres
        self.LHV = 43e6                   # J/kg, gas naturel par defaut
        self.eta_combustion = 1.0         # rendement de combustion
        self.m_fuel = 0.0                 # debit combustible (kg/s)
        self.Q_cooling = 0.0              # pertes refroidissement (W)

        # Sorties
        self.P_fuel = None                # puissance thermique apportee (W)
        self.Ti_degC = None
        self.To_degC = None
        self.df = []

    def calculate(self):
        fluid = self.Inlet.fluid
        P_a = self.Inlet.P
        h_a = self.Inlet.h
        m_a = self.Inlet.F if self.Inlet.F is not None else 0.0

        self.P_fuel = self.m_fuel * self.LHV * self.eta_combustion
        m_b = m_a + self.m_fuel

        if m_b < 1e-12:
            h_b = h_a
        else:
            # Bilan : m_b*h_b = m_a*h_a + m_fuel*h_a + P_fuel - Q_cooling
            #              = (m_a + m_fuel)*h_a + P_fuel - Q_cooling
            #              = m_b*h_a + P_fuel - Q_cooling
            h_b = h_a + (self.P_fuel - self.Q_cooling) / m_b

        self.Outlet.fluid = fluid
        self.Outlet.P = P_a            # iso-pression
        self.Outlet.h = h_b
        self.Outlet.F = m_b

        self.Ti_degC = PropsSI('T', 'P', P_a, 'H', h_a, fluid) - 273.15
        self.To_degC = PropsSI('T', 'P', P_a, 'H', h_b, fluid) - 273.15

        self.df = pd.DataFrame(
            {'Combustor': [self.Timestamp, fluid, m_a, self.m_fuel, m_b,
                           self.Ti_degC, self.To_degC,
                           self.P_fuel / 1000.0, self.eta_combustion]},
            index=['Timestamp', 'fluid', 'm_air_kgs', 'm_fuel_kgs',
                   'm_out_kgs', 'Ti_degC', 'To_degC',
                   'P_fuel_kW', 'eta_comb'])
