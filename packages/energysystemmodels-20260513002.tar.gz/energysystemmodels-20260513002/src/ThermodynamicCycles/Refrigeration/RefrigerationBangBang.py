"""RefrigerationBangBang -- groupe froid avec commande tout-ou-rien hysteretique
(Modelica VolBal.GroupeFrig).

Logique :
  - quand T_mesure >= T_opening : groupe DEMARRE (P_f := P_f_opening)
  - quand T_mesure <= T_closing : groupe ARRETE (P_f := 0)
  - entre les deux : etat conserve (hysteresis)

Convention :
  - T_opening > T_closing (ex : -39 et -40 degC pour une chambre froide)
  - P_f_opening : puissance frigorifique (W) lorsque le groupe tourne

Le composant lit T (du ColdStorageTank) et publie P_f (vers le tank).
"""

import pandas as pd


class Object:
    def __init__(self):
        self.Timestamp = None

        # Parametres
        self.T_opening = 273.15 - 39.0     # K -- demarrage
        self.T_closing = 273.15 - 40.0     # K -- arret
        self.P_f_opening = 3000.0          # W

        # Etat persistent (relais bistable)
        self.is_on = False                 # False = arrete, True = en marche

        # Inputs
        self.T_measured = 273.15 - 40.0    # K (a actualiser avant calculate())

        # Sorties
        self.P_f_out = 0.0                 # W (vers le tank)
        self.df = []

    def calculate(self):
        # Mise a jour de l'etat selon hysteresis
        if not self.is_on and self.T_measured >= self.T_opening:
            self.is_on = True
        elif self.is_on and self.T_measured <= self.T_closing:
            self.is_on = False

        self.P_f_out = self.P_f_opening if self.is_on else 0.0

        self.df = pd.DataFrame(
            {'RefrigerationBangBang': [self.Timestamp,
                                       self.T_measured - 273.15,
                                       self.T_opening - 273.15,
                                       self.T_closing - 273.15,
                                       self.is_on, self.P_f_out]},
            index=['Timestamp', 'T_meas_degC', 'T_open_degC', 'T_close_degC',
                   'is_on', 'P_f_W'])
