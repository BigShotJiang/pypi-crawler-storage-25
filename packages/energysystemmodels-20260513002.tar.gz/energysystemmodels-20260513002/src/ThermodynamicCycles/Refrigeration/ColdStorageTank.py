"""ColdStorageTank -- chambre/ballon froid avec apport thermique et groupe froid
(Modelica VolBal.Ballon).

Modele simplifie d'une enceinte refrigeree :
- masse thermique m = rho * V (eau/saumure equivalente)
- apport thermique externe Q_air (W) -- pertes parois, infiltrations, etc.
- extraction par groupe froid Q_f (W) -- positif quand le groupe est ON

Bilan d'energie (forme reduite) :
    m * Cp * dT/dt = Q_air - Q_f

Cette ecriture est mathematiquement equivalente a la formulation Modelica :
    m*Cp*der(T) = -Qf + debit*Cp*(Te-T)
    avec  Te = T + Q_air/(debit*Cp)  =>  debit*Cp*(Te-T) = Q_air

Etat persistent : T (Kelvin), updates par Euler explicite a chaque calculate().
"""

import pandas as pd


class Object:
    def __init__(self):
        self.Timestamp = None

        # Parametres physiques
        self.V = 60e-3             # m3 (volume thermique equivalent)
        self.rho = 1060.0          # kg/m3 (saumure typique)
        self.Cp = 3060.0           # J/kg/K
        self.Q_air = 2000.0        # W (apport thermique externe constant ou variable)

        # Pas de temps
        self.t = 60.0              # s

        # Inputs externes (a actualiser avant calculate())
        self.Q_f_in = 0.0          # W (cooling du groupe froid, >= 0)

        # Etat persistent
        self.T = 273.15 - 40.0     # K (init -40 degC)

        # Sorties
        self.m = None
        self.dT_dt = None
        self.df = []

    def calculate(self):
        # masse thermique
        self.m = self.rho * self.V

        # bilan energie : m*Cp * dT/dt = Q_air - Q_f
        self.dT_dt = (self.Q_air - self.Q_f_in) / (self.m * self.Cp)

        # Euler explicite
        self.T += self.t * self.dT_dt

        self.df = pd.DataFrame(
            {'ColdStorageTank': [self.Timestamp, self.T - 273.15,
                                 self.Q_air, self.Q_f_in,
                                 self.dT_dt * 60, self.m, self.V * 1000]},
            index=['Timestamp', 'T_degC', 'Q_air_W', 'Q_f_W',
                   'dT_dt_K_per_min', 'm_kg', 'V_L'])
