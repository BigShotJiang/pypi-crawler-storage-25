"""Correlations pour le modele de croissance du givre
(Modelica Croissance_Du_Givre.mo - functions package).
"""

import math


def Kff(rho_f):
    """Conductivite thermique du givre (W/m/K), correlation Yonko-Sepsy.
    rho_f en kg/m3."""
    return 0.024248 + 0.00072311 * rho_f + 1.183e-6 * rho_f ** 2


def rho_ff(Ts):
    """Densite du givre (kg/m3), correlation Hayashi 1977.
    Ts en K, valable Ts < 273.15."""
    return 650.0 * math.exp(0.227 * (Ts - 273.15))


def ECKERT_DRAKE(Ts):
    """Coefficient de diffusion binaire vapeur-air (m2/s), correlation Eckert-Drake.
    Ts en K."""
    return 9.756e-10 * Ts ** 1.81


def Pvsat(T):
    """Pression de vapeur saturante (Pa) selon ASHRAE 2005 Handbook.
    T en K. Bascule a T = 273.15 K."""
    if T < 273.15:
        return math.exp(
            -5.6745359e3 / T
            + 6.3925247e0
            + (-9.677843e-3) * T
            + 6.2215701e-7 * T ** 2
            + 2.0747825e-9 * T ** 3
            + (-9.484024e-13) * T ** 4
            + 4.1635019e0 * math.log(T)
        )
    return math.exp(
        -5.8002206e3 / T
        + 1.3914993e0
        + (-4.8640239e-2) * T
        + 4.1764768e-5 * T ** 2
        + (-1.4452063e-8) * T ** 3
        + 6.5459673e0 * math.log(T)
    )


def P_de_vap(Ti, HRi):
    """Pression partielle de vapeur (Pa). Ti K, HRi en [0,1]."""
    return HRi * Pvsat(Ti)


def Humid_absolue(Pv, HR):
    """Humidite absolue kg/kg air sec. Pv en Pa, HR effectif (peut differer de 1)."""
    return 0.62198 * Pv / (101300 - HR * Pv)


def Re(rho, V, L, Mu):
    """Nombre de Reynolds."""
    return rho * V * L / Mu


def Pr(Cp, Mu, K):
    """Nombre de Prandtl."""
    return Cp * Mu / K


def Nu_Plaque(Re_val, Pr_val):
    """Nombre de Nusselt pour plaque plane (ASHRAE 2005)."""
    if Re_val < 5e5:
        return 0.664 * Re_val ** 0.5 * Pr_val ** (1 / 3)      # laminaire
    return 0.037 * Re_val ** 0.8 * Pr_val ** (1 / 3)           # turbulent


def Colburn_Factor(ReD, d0, df, St, Sl, ft, fs):
    """Colburn j-factor pour echangeur a tubes ailettes (correlation finned tubes)."""
    return (0.0208 * ReD ** (-0.2871 + 0.5322 * (d0 / St)
                             - 1.2856 * (ft / fs) + 0.1845 * (Sl / St))
            * (d0 / St) ** (-2.5950)
            * (ft / fs) ** 0.7905
            * (Sl / St) ** 0.2391
            * (d0 / df) ** 0.2761)
