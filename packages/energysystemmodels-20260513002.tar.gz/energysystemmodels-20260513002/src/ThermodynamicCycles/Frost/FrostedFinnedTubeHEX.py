"""FrostedFinnedTubeHEX -- echangeur tube-ailettes en condition de givrage.

Implementation fidele du modele these Hadid (2012)
[https://pastel.hal.science/tel-01674498v1] section 6 du chapitre 2,
avec corrélations VALIDEES experimentalement (60 essais maquettes M01-M04) :

  - Côté air     : Briggs-Young recalee Hadid (eq 2.91, +-8%)
  - Transfert masse : fonction de Lewis recalee (eq 2.90, +-15%)
  - Côté refrigerant : Sieder-Tate ou Dittus-Boelter selon regime
  - Pertes de pression : Vampola modifiee Hadid (eq 2.92)
  - Croissance givre : modele 1D N noeuds (deja dans Frost/CroissanceDuGivre)

Couplages physiques :
  Air humide --[h_a, h_m]--> [givre] --[K_ff/delta_f]--> ailette --[Tube]--> refrigerant

Variables d'etat dynamiques (persistent entre calculate()) :
  - delta_f   : epaisseur couche de givre (m)
  - rho_f     : densite givre (kg/m3)
  - T-profile : temperatures dans la couche de givre (K)
  - Frost     : masse cumulee (kg)

Convention :
  - Inlet_air, Outlet_air         : FluidPort cote air (humid air)
  - Inlet_ref, Outlet_ref         : FluidPort cote refrigerant
  Mais les FluidPort ne supportent pas l'humidite -> on stocke HR_in
  comme parametre de classe pour l'instant.
"""

import math

import numpy as np
import pandas as pd
from CoolProp.CoolProp import PropsSI
from scipy.optimize import fsolve

from ThermodynamicCycles.Frost.correlations import (
    Kff, Pvsat, ECKERT_DRAKE, Humid_absolue, P_de_vap,
)
from ThermodynamicCycles.Frost.correlations_thesis import (
    Briggs_Young_dry, Briggs_Young_frosted,
    supersaturation_factor, Lewis_function_Hadid, mass_transfer_coefficient,
    Vampola_dP_frosted, Robinson_Briggs_dP_dry,
    Nu_internal_laminar_developing, Nu_internal_DittusBoelter,
    hydraulic_diameter_Vampola,
)
from ThermodynamicCycles.Frost.TubeFinGeometry import Object as TubeFinGeometry


class Object:
    def __init__(self):
        self.Timestamp = None

        # ----- Geometrie (instanciee mais parametrable) -----
        self.geom = TubeFinGeometry()

        # ----- Conditions amont air -----
        self.fluid_air = 'air'
        self.T_in_air = 286.0           # K
        self.P_air = 101325.0           # Pa
        self.HR_in = 0.50               # humidite relative
        self.m_a = 0.22                 # kg/s -- debit d'air (peut chuter avec dP)
        self.use_frosted_correlation = True  # True: eq 2.91, False: eq 2.83

        # ----- Conditions amont refrigerant -----
        self.fluid_ref = 'water'        # ex 'water' (saumure), 'R134a', etc.
        self.T_in_ref = 233.15          # K (-40 degC)
        self.P_ref = 2e5                # Pa
        self.m_ref = 0.5                # kg/s -- debit refrigerant (frigoporteur)

        # ----- Constantes physiques -----
        self.Cp_a = 1006.0              # J/kg/K -- air sec
        self.rho_a = 1.198              # kg/m3
        self.mu_a = 1.82e-5             # Pa.s
        self.k_a = 0.02581              # W/m/K
        self.Lsv = 2834.5e3             # J/kg

        # ----- Pas de temps & integration -----
        self.t = 60.0                   # s
        self.n_substeps_frost = 30      # sous-pas pour solveur frost

        # ----- Etat dynamique -----
        self.delta_f = 1e-5             # m -- epaisseur initiale givre
        self.rho_f = 25.0               # kg/m3 -- densite initiale givre
        self.Frost = 0.0                # kg -- masse cumulee
        self.T_frost = None             # profil T dans le givre (Nx noeuds)
        self.Nx_frost = 4               # nombre de noeuds dans le givre (these: Nx=4)

        # ----- Sorties (mises a jour par calculate()) -----
        self.V_face = None              # vitesse frontale (m/s)
        self.V_max = None               # vitesse a S_min (m/s)
        self.Re_d = None
        self.Pr = None
        self.Nu_air = None
        self.h_a = None                 # coeff air (W/m2/K)
        self.h_m = None                 # coeff masse
        self.S_super = None             # facteur sursaturation
        self.Le_f = None                # fonction de Lewis
        self.h_i = None                 # coeff refrigerant (W/m2/K)
        self.Re_ref = None
        self.Q_sens = None              # W
        self.Q_lat = None               # W
        self.Q_total = None             # W
        self.T_out_air = None           # K
        self.HR_out = None
        self.T_out_ref = None           # K
        self.T_s_givre = None           # K (surface du givre, T[Nx])
        self.T_p = None                 # K (paroi ailette)
        self.dP_air = None              # Pa
        self.m_f = None                 # kg/s flux d'eau
        self.df = None

        self._initialized = False

    # ------------------------------------------------------------------
    # Initialisation T-profile
    # ------------------------------------------------------------------
    def _init_state(self):
        Tinit = self.T_in_ref + 5.0  # initialisation legerement au-dessus de Tref
        self.T_frost = [Tinit] * self.Nx_frost
        self._initialized = True

    # ------------------------------------------------------------------
    # Solveur frost growth (N noeuds 1D, similaire CroissanceDuGivre)
    # ------------------------------------------------------------------
    def _solve_frost_profile(self, Tp, A_T, Qsens, Qlat):
        """Resout le profil T dans la couche de givre.
        Returns (T_new, m_f, m_rho, m_delta).
        """
        Nx = self.Nx_frost
        R = 8.3143
        Lsv = self.Lsv
        Mv = 0.018
        Pt = 101300.0
        rho_ice = 917.0
        F = 0.0
        k_par = 10.0
        S_input = 0.0  # sursaturation interne (pas le S exterieur)

        kff_val = Kff(self.rho_f)
        Epsilon = self.rho_f / rho_ice
        Mu_diff = ((1 - Epsilon) / (1 - 0.58 * Epsilon)
                   + F * k_par * Epsilon * (1 - Epsilon) ** k_par)
        m_f = Qlat / Lsv
        dx = self.delta_f / Nx

        def residuals(T_vec):
            T = T_vec.tolist()
            Pv = [Pvsat(T[i]) * (1 + S_input) for i in range(Nx)]
            Ds = [ECKERT_DRAKE(T[i]) for i in range(Nx)]
            f = [Ds[i] * (Mv ** 2 * Lsv) / (R ** 2 * T[i] ** 3)
                 * (Pv[i] * Pt) / (Pt - Pv[i]) for i in range(Nx)]

            res = np.zeros(Nx)
            res[0] = (kff_val * (T[1] - T[0]) / dx
                      - kff_val * (T[0] - Tp) / dx
                      + Lsv * Mu_diff * f[1] * (T[1] - T[0]) / dx)
            for i in range(1, Nx - 1):
                res[i] = (kff_val * (T[i + 1] - T[i])
                          - kff_val * (T[i] - T[i - 1])
                          + Lsv * Mu_diff * f[i + 1] * (T[i + 1] - T[i])
                          - Lsv * Mu_diff * f[i - 1] * (T[i] - T[i - 1]))
            res[Nx - 1] = (Qsens
                           - A_T * kff_val * (T[Nx - 1] - T[Nx - 2]) / dx
                           + Lsv * m_f
                           - A_T * Lsv * Mu_diff
                           * f[Nx - 2] * (T[Nx - 1] - T[Nx - 2]) / dx)
            return res

        T0 = np.array(self.T_frost)
        sol, info, ier, msg = fsolve(residuals, T0, full_output=True, xtol=1e-6)
        T_new = sol.tolist()

        # Recalcul f[i] pour repartition m_rho/m_delta
        Pv = [Pvsat(T_new[i]) * (1 + S_input) for i in range(Nx)]
        Ds = [ECKERT_DRAKE(T_new[i]) for i in range(Nx)]
        f = [Ds[i] * (Mv ** 2 * Lsv) / (R ** 2 * T_new[i] ** 3)
             * (Pv[i] * Pt) / (Pt - Pv[i]) for i in range(Nx)]

        flux_diff_surface = (A_T * Mu_diff * f[Nx - 2]
                             * (T_new[Nx - 1] - T_new[Nx - 2]) / dx)
        m_rho = min(flux_diff_surface, m_f)
        m_delta = m_f - m_rho
        return T_new, m_f, m_rho, m_delta

    # ------------------------------------------------------------------
    # Boucle principale
    # ------------------------------------------------------------------
    def calculate(self):
        if not self._initialized:
            self._init_state()

        # ====== 1. Geometrie courante (avec Y_eff = Y0 + 2*delta_f) ======
        self.geom.delta_f = self.delta_f
        self.geom.calculate()
        g = self.geom

        # ====== 2. Vitesses cote air ======
        # Section frontale par tube : S_face * L_T
        # m_a est le debit total sur toute la maquette (N_T tubes)
        # Pour 1 tube : m_a_tube = m_a / N_T
        S_face_tube = g.S_face * g.L_T          # m2 par tube
        S_min_tube = g.S_min * g.L_T            # m2 par tube
        # Vitesse frontale (sur section S_face)
        # Si on traite l'echangeur entier : S_face_total = S_face * L_T * N_T_par_rangee
        # mais on travaille par tube ici
        m_a_tube = self.m_a / g.N_T
        self.V_face = m_a_tube / (self.rho_a * S_face_tube)
        self.V_max = self.V_face * (g.S_face / g.S_min)

        # ====== 3. Re, Pr cote air ======
        self.Re_d = g.d_r * self.rho_a * self.V_max / self.mu_a
        Cp_air_humid = self.Cp_a   # approximation : Cp humid air ~ Cp dry air
        self.Pr = self.mu_a * Cp_air_humid / self.k_a

        # ====== 4. Coefficient h_a (selon regime) ======
        if self.use_frosted_correlation:
            self.Nu_air = Briggs_Young_frosted(
                self.Re_d, g.H, g.s, g.Y_eff, self.Pr)
        else:
            self.Nu_air = Briggs_Young_dry(
                self.Re_d, g.H, g.s, g.Y_eff, self.Pr)
        self.h_a = self.Nu_air * self.k_a / g.d_r

        # ====== 5. Coefficient h_i refrigerant ======
        # On utilise les proprietes CoolProp si possible
        try:
            rho_ref = PropsSI('D', 'P', self.P_ref, 'T', self.T_in_ref, self.fluid_ref)
            mu_ref = PropsSI('V', 'P', self.P_ref, 'T', self.T_in_ref, self.fluid_ref)
            k_ref = PropsSI('L', 'P', self.P_ref, 'T', self.T_in_ref, self.fluid_ref)
            Cp_ref = PropsSI('C', 'P', self.P_ref, 'T', self.T_in_ref, self.fluid_ref)
        except Exception:
            # fallback saumure Temper-55 type
            rho_ref, mu_ref, k_ref, Cp_ref = 1100.0, 0.01, 0.4, 3060.0

        m_ref_tube = self.m_ref / g.N_T
        V_ref = m_ref_tube / (rho_ref * math.pi * g.d_i ** 2 / 4)
        self.Re_ref = rho_ref * V_ref * g.d_i / mu_ref
        Pr_ref = Cp_ref * mu_ref / k_ref

        if self.Re_ref < 2300:
            Nu_ref = Nu_internal_laminar_developing(
                self.Re_ref, Pr_ref, g.d_i, g.L_T)
        else:
            Nu_ref = Nu_internal_DittusBoelter(self.Re_ref, Pr_ref, heating=True)
        self.h_i = Nu_ref * k_ref / g.d_i

        # ====== 6. Pression de vapeur entree air & calcul iteratif Ts =====
        Pv_in = P_de_vap(self.T_in_air, self.HR_in)
        w_in = Humid_absolue(Pv_in, self.HR_in)

        # Iteration sur Ts pour resoudre couplage Q_sens = Q_lat = Q via UA
        # Approche simplifiee : on suppose Ts ≈ T_frost[N-1] (lagged)
        if self.T_frost is None:
            Ts = self.T_in_ref + 5.0
        else:
            Ts = self.T_frost[-1]

        # Fonction de Lewis recalee
        Pvsat_Ts = Pvsat(Ts)
        self.S_super = supersaturation_factor(Pv_in, Pvsat_Ts)
        self.Le_f = Lewis_function_Hadid(self.S_super)
        self.h_m = mass_transfer_coefficient(self.h_a, self.Le_f, Cp_air_humid)

        # ====== 7. Flux Q_sens et Q_lat (sur la maquette entiere) ======
        N_rows = 1   # Single tube model. Pour multi-rangees = N_T (en parallele air)
        A_T_total = g.A_T * g.N_T

        self.Q_sens = self.h_a * A_T_total * (self.T_in_air - Ts)
        w_s = Humid_absolue(Pvsat_Ts, 1.0)
        self.Q_lat = self.h_m * A_T_total * self.Lsv * (w_in - w_s)
        self.m_f = self.Q_lat / self.Lsv

        # ====== 8. Air sortie (refroidissement + deshumidification) =====
        self.Q_total = self.Q_sens + self.Q_lat
        self.T_out_air = self.T_in_air - self.Q_total / (self.m_a * Cp_air_humid)
        # Humidite sortie :  m_f = m_a * (w_in - w_out)
        w_out = w_in - self.m_f / self.m_a
        # Conversion w_out -> HR_out a T_out_air
        Pvsat_out = Pvsat(self.T_out_air)
        if Pvsat_out > 0:
            self.HR_out = (w_out * 101325) / (0.62198 + w_out) / Pvsat_out
        else:
            self.HR_out = 0.0

        # ====== 9. Couplage paroi : R_air + R_givre + R_paroi + R_ref ======
        # On calcule la temperature paroi Tp via UA equivalent
        # R_air = 1/(h_a*A_T) ; R_givre = delta_f/(K_ff*A_T) ;
        # R_tube = ln(d_r/d_i)/(2pi*k_tube*L_T*N_T)
        # R_ref = 1/(h_i*A_int*N_T)
        R_air = 1.0 / (self.h_a * A_T_total)
        R_givre = (self.delta_f / (Kff(self.rho_f) * A_T_total)
                   if self.delta_f > 1e-9 else 0.0)
        R_tube = (math.log(g.d_r / g.d_i)
                  / (2.0 * math.pi * g.k_tube * g.L_T * g.N_T))
        R_ref = 1.0 / (self.h_i * g.A_int * g.N_T)
        # Bilan : Q_sens = (T_in_air - T_out_ref) / (R_total)
        # On prend Ts = T_in_air - Q_sens*R_air, Tp = Ts - Q_sens*R_givre
        Ts_calc = self.T_in_air - self.Q_sens * R_air
        Tp_calc = Ts_calc - self.Q_sens * R_givre
        T_int_paroi_calc = Tp_calc - self.Q_sens * R_tube
        self.T_p = Tp_calc
        self.T_s_givre = Ts_calc

        # T sortie refrigerant
        self.T_out_ref = self.T_in_ref + self.Q_total / (self.m_ref * Cp_ref)

        # ====== 10. Croissance givre 1D (solveur fsolve) =====
        try:
            T_new, m_f_check, m_rho, m_delta = self._solve_frost_profile(
                self.T_p, A_T_total, self.Q_sens, self.Q_lat)
            self.T_frost = T_new
        except Exception:
            # fallback : pas de mise a jour si solveur echoue
            m_rho, m_delta = self.m_f * 0.5, self.m_f * 0.5

        # Integration Euler explicite des etats dynamiques
        if A_T_total > 0 and self.rho_f > 0:
            self.delta_f += self.t * m_delta / (A_T_total * self.rho_f)
        if A_T_total > 0 and self.delta_f > 0:
            self.rho_f += self.t * m_rho / (A_T_total * self.delta_f)
        self.Frost += self.t * self.m_f

        # Securisation
        self.delta_f = max(self.delta_f, 1e-7)
        self.rho_f = max(10.0, min(self.rho_f, 917.0 * 0.95))

        # ====== 11. Perte de pression (Vampola modifiee Hadid) =====
        d_v = hydraulic_diameter_Vampola(g.A_tube, g.A_fin, g.d_r, g.N_fin)
        try:
            self.dP_air = Vampola_dP_frosted(
                self.Re_d, g.P_t, g.d_r, g.s, g.Y_eff,
                d_v, g.H, self.rho_a, self.V_max)
        except Exception:
            self.dP_air = Robinson_Briggs_dP_dry(
                self.Re_d, g.P_t, g.P_d, g.d_r, self.rho_a, self.V_max)

        # ====== 12. Reporting =====
        self.df = pd.DataFrame(
            {'FrostedFinnedTubeHEX': [
                self.Timestamp,
                self.delta_f * 1000, self.rho_f, self.Frost * 1000,
                self.T_in_air - 273.15, self.T_out_air - 273.15,
                self.T_in_ref - 273.15, self.T_out_ref - 273.15,
                self.T_s_givre - 273.15, self.T_p - 273.15,
                self.HR_in, self.HR_out, self.S_super, self.Le_f,
                self.V_face, self.V_max, self.Re_d, self.Re_ref,
                self.h_a, self.h_m, self.h_i,
                self.Q_sens, self.Q_lat, self.Q_total,
                self.dP_air, self.m_f * 1e6,
                self.geom.A_T, self.geom.s * 1000, self.geom.Y_eff * 1000]},
            index=['Timestamp',
                   'delta_f_mm', 'rho_f', 'Frost_g',
                   'Tair_in_degC', 'Tair_out_degC',
                   'Tref_in_degC', 'Tref_out_degC',
                   'Ts_givre_degC', 'Tp_paroi_degC',
                   'HR_in', 'HR_out', 'S_super', 'Le_f',
                   'V_face', 'V_max', 'Re_d_air', 'Re_ref',
                   'h_a_W_m2K', 'h_m_kg_m2s', 'h_i_W_m2K',
                   'Q_sens_W', 'Q_lat_W', 'Q_total_W',
                   'dP_air_Pa', 'm_f_mg_s',
                   'A_T_m2', 's_mm', 'Y_eff_mm'])
