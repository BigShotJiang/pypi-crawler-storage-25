"""Air -- conditions amont air humide (Modelica Croissance_Du_Givre.Air).

Calcule les flux sensible et latent sur la surface du givre :
    Q_sens = h_a * A_T * (T_in - Ts)
    Q_lat  = h_m * A_T * Lsv * (w_in - w_s(Ts))
    Q_sens + Q_lat = m_a * Cp_a * (T_in - T_out)

h_a est obtenu via correlation Nusselt plaque plane (ASHRAE).
h_m via analogie Lewis : h_m = h_a / (Le * Cp_a)
"""

import pandas as pd

from ThermodynamicCycles.Frost.correlations import (
    Pvsat, Humid_absolue, Re, Pr, Nu_Plaque,
)


class Object:
    def __init__(self):
        # Parametres physiques (defauts du Modelica)
        self.T_in = 286.0            # K  -- 13 degC
        self.m_a = 0.22              # kg/s
        self.V = 2.12                # m/s
        self.L = 0.506               # m  -- longueur plaque
        self.HR_in = 0.50            # humidite relative
        self.Cp_a = 1006.0           # J/kg/K
        self.rho_a = 1.198           # kg/m3
        self.Mu_a = 1.82e-5          # Pa.s
        self.k_a = 0.02581           # W/m/K
        self.Lsv = 2834.5e3          # J/kg
        self.Le = 1.0                # nombre de Lewis
        # Mode w_in : 0.0039 par defaut Modelica (w_in fixe sur tout le temps)
        self.w_in = 0.0039

        # Inputs (depuis surface) -- mis a jour avant calculate()
        self.Ts = 273.15             # K -- temp surface du givre (du modele frost)
        self.A_T = 0.506 * 0.304     # m2 (vient de Fin)

        # Sorties
        self.h_a = None
        self.h_m = None
        self.w_s = None
        self.Q_sens = None
        self.Q_lat = None
        self.T_out = None
        self.Re = None
        self.Nu = None
        self.df = None

    def calculate(self):
        # h_a via Nusselt plaque plane
        self.Re = Re(self.rho_a, self.V, self.L, self.Mu_a)
        self.Nu = Nu_Plaque(self.Re, Pr(self.Cp_a, self.Mu_a, self.k_a))
        self.h_a = self.k_a * self.Nu / self.L
        self.h_m = self.h_a / (self.Le * self.Cp_a)

        # Humidite saturante a la surface
        self.w_s = Humid_absolue(Pvsat(self.Ts), 1.0)

        # Flux
        self.Q_sens = self.h_a * self.A_T * (self.T_in - self.Ts)
        self.Q_lat = self.h_m * self.A_T * self.Lsv * (self.w_in - self.w_s)

        # Temperature sortie
        self.T_out = self.T_in - (self.Q_sens + self.Q_lat) / (self.m_a * self.Cp_a)

        self.df = pd.DataFrame(
            {'Air': [self.T_in - 273.15, self.T_out - 273.15, self.Ts - 273.15,
                     self.HR_in, self.w_in, self.w_s,
                     self.h_a, self.h_m,
                     self.Q_sens, self.Q_lat, self.Re, self.Nu]},
            index=['Tin_degC', 'Tout_degC', 'Ts_degC',
                   'HR_in', 'w_in_kgkg', 'w_s_kgkg',
                   'h_a_W_m2K', 'h_m_kgs_m2',
                   'Q_sens_W', 'Q_lat_W', 'Re', 'Nu'])
