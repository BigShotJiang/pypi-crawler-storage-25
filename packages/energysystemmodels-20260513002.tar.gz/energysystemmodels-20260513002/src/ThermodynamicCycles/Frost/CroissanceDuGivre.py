"""CroissanceDuGivre -- modele dynamique de croissance du givre
(Modelica Croissance_Du_Givre.CroissanceDuGivre).

Discretisation de la couche de givre en Nx noeuds. A chaque pas de temps :
1. Resolution du systeme non-lineaire pour le profil T[1..Nx] avec :
   - Conduction par Kff(rho_f)
   - Diffusion de vapeur avec terme latent Lsv*Mu*f[i]*(T[i+1]-T[i])
   - Conditions limites : T[0]=Tp (paroi froide), Q[Nx]=Qsens-conduction (surface)
2. Integration explicite de :
   - delta_f (epaisseur)  : der(delta_f) = m_delta / (A_T * rho_f)
   - rho_f (densite)      : der(rho_f) = m_rho / (A_T * delta_f)
   - Frost (masse cumulee): der(Frost) = m_f

Etat persistent entre appels : T (profil), delta_f, rho_f, Frost.
"""

import math

import numpy as np
import pandas as pd
from scipy.optimize import fsolve

from ThermodynamicCycles.Frost.correlations import (
    Kff, Pvsat, ECKERT_DRAKE,
)


class Object:
    def __init__(self):
        # Parametres
        self.Nx = 10                   # nombre de noeuds dans le givre
        self.R = 8.3143                # J/K/mol
        self.Lsv = 2834.5e3            # J/kg (chaleur latente sublimation)
        self.Mv = 0.018                # kg/mol (masse molaire vapeur)
        self.Pt = 101300.0             # Pa  (pression totale)
        self.rho_ice = 917.0           # kg/m3 (densite glace)
        self.k_par = 10.0              # parametre de Mu (Le Gall)
        self.S_input = 0.0             # sursaturation (0 par defaut)

        # Pas de temps
        self.t = 60.0                  # s -- pas pour Euler explicite

        # Inputs (depuis Fin et Air)
        self.Tp = 248.0                # K -- temp paroi (Fin)
        self.A_T = 0.506 * 0.304       # m2 (Fin)
        self.Qlat_in = 0.0             # W (Air, transfert masse via Lsv)
        self.Qsens_in = 0.0            # W (Air, conduction)

        # Etat (persiste entre calculate())
        self.T = None                  # K, list Nx (profil)
        self.delta_f = 1e-4            # m (epaisseur initiale)
        self.rho_f = 25.0              # kg/m3 (densite initiale)
        self.Frost = 0.0               # kg/m2 (masse cumulee)

        # Outputs intermediaires
        self.dx = None
        self.Pv = None
        self.f = None
        self.Mu = None
        self.m_f = None
        self.m_rho = None
        self.m_delta = None
        self.Q_fin = None
        self.Ts = None
        self.df = None

        self._initialized = False

    def _initialize_state(self):
        # Profil T initial : interpolation lineaire entre Tp et 273.15K
        self.T = np.linspace(self.Tp, 273.15, self.Nx).tolist()
        self._initialized = True

    def _residuals(self, T_vec, kff_val, Mu, dx, m_f):
        """Residus du systeme non-lineaire pour le profil T."""
        N = self.Nx
        T = T_vec.tolist()

        # Pression de vapeur et f[i] a chaque noeud
        Pv = [Pvsat(T[i]) * (1 + self.S_input) for i in range(N)]
        Ds = [ECKERT_DRAKE(T[i]) for i in range(N)]
        f = [Ds[i] * (self.Mv ** 2 * self.Lsv) / (self.R ** 2 * T[i] ** 3)
             * (Pv[i] * self.Pt) / (self.Pt - Pv[i])
             for i in range(N)]

        res = np.zeros(N)
        # i = 0 (Modelica i=1) : avec paroi
        res[0] = (kff_val * (T[1] - T[0]) / dx
                  - kff_val * (T[0] - self.Tp) / dx
                  + self.Lsv * Mu * f[1] * (T[1] - T[0]) / dx)
        # i = 1..N-2 (Modelica 2..Nx-1)
        for i in range(1, N - 1):
            res[i] = (kff_val * (T[i + 1] - T[i])
                      - kff_val * (T[i] - T[i - 1])
                      + self.Lsv * Mu * f[i + 1] * (T[i + 1] - T[i])
                      - self.Lsv * Mu * f[i - 1] * (T[i] - T[i - 1]))
        # i = N-1 (Modelica Nx) : surface, conditions Q_sens + latent
        res[N - 1] = (self.Qsens_in
                      - self.A_T * kff_val * (T[N - 1] - T[N - 2]) / dx
                      + self.Lsv * m_f
                      - self.A_T * self.Lsv * Mu
                      * f[N - 2] * (T[N - 1] - T[N - 2]) / dx)
        return res

    def calculate(self):
        if not self._initialized:
            self._initialize_state()

        N = self.Nx
        self.dx = self.delta_f / N
        kff_val = Kff(self.rho_f)

        # Resistance a la diffusion (Le Gall eq. 26)
        Epsilon = self.rho_f / self.rho_ice
        F = 0.0
        self.Mu = ((1 - Epsilon) / (1 - 0.58 * Epsilon)
                   + F * self.k_par * Epsilon * (1 - Epsilon) ** self.k_par)

        # Flux massique total impose par Air
        self.m_f = self.Qlat_in / self.Lsv

        # Resolution du profil T (systeme non-lineaire) -- on sature m_f dans residuals
        T0 = np.array(self.T)
        sol = fsolve(self._residuals, T0,
                     args=(kff_val, self.Mu, self.dx, self.m_f),
                     full_output=True, xtol=1e-6)
        T_new, info, ier, msg = sol
        if ier != 1:
            # Convergence imparfaite : on accepte la meilleure estimation
            pass
        self.T = T_new.tolist()
        self.Ts = self.T[-1]

        # Recalcul Pv et f sur la nouvelle solution
        Pv = [Pvsat(self.T[i]) * (1 + self.S_input) for i in range(N)]
        Ds = [ECKERT_DRAKE(self.T[i]) for i in range(N)]
        f = [Ds[i] * (self.Mv ** 2 * self.Lsv) / (self.R ** 2 * self.T[i] ** 3)
             * (Pv[i] * self.Pt) / (self.Pt - Pv[i])
             for i in range(N)]
        self.Pv = Pv
        self.f = f

        # Repartition m_f entre densification (m_rho) et croissance (m_delta)
        flux_diff_surface = (self.A_T * self.Mu * f[N - 2]
                             * (self.T[N - 1] - self.T[N - 2]) / self.dx)
        self.m_rho = min(flux_diff_surface, self.m_f)
        self.m_delta = self.m_f - self.m_rho

        # Q_fin
        self.Q_fin = kff_val * (self.T[0] - self.Tp) / self.dx * self.A_T

        # Integration Euler explicite
        if self.A_T > 0 and self.rho_f > 0:
            self.delta_f += self.t * self.m_delta / (self.A_T * self.rho_f)
        if self.A_T > 0 and self.delta_f > 0:
            self.rho_f += self.t * self.m_rho / (self.A_T * self.delta_f)
        self.Frost += self.t * self.m_f

        # Securisation : delta_f, rho_f >= seuils physiques
        self.delta_f = max(self.delta_f, 1e-6)
        self.rho_f = max(self.rho_f, 10.0)
        self.rho_f = min(self.rho_f, self.rho_ice * 0.95)

        self.df = pd.DataFrame(
            {'CroissanceDuGivre': [
                self.Tp - 273.15, self.Ts - 273.15, self.A_T,
                self.delta_f * 1000, self.rho_f, self.Frost,
                self.m_f * 1e6, self.m_delta * 1e6, self.m_rho * 1e6,
                self.Mu, kff_val, self.Q_fin]},
            index=['Tp_degC', 'Ts_degC', 'A_T_m2',
                   'delta_f_mm', 'rho_f_kgm3', 'Frost_kg',
                   'm_f_mgs', 'm_delta_mgs', 'm_rho_mgs',
                   'Mu', 'Kff_W_mK', 'Q_fin_W'])
