"""TubeFinGeometry -- geometrie tube a ailettes rondes discontinues
(these Hadid 2012, modele "Geometrie" section 6.2.1).

Calcule l'ensemble des grandeurs geometriques derivees a partir des parametres
constructeur. La couche de givre modifie l'epaisseur effective d'ailette Y_eff
qui evolue dans le temps : Y_eff = Y0 + 2*delta_f (givre des deux cotes).

Parametres principaux (M01P3 these par defaut) :
  d_r   : diametre exterieur tube (m)         = 25.4e-3
  e     : epaisseur paroi tube (m)            = 2.108e-3
  H     : hauteur ailette (m)                 = 15.075e-3
  Y0    : epaisseur ailette nue (m)           = 0.3e-3
  FPI   : fins per inch                       = 10
  P_t   : pas transversal (m)                 = 63.5e-3
  L_T   : longueur d'un tube (m)              = 1.016
  N_T   : nombre total de tubes               = 16

Grandeurs derivees :
  d_i = d_r - 2*e            (diametre interieur)
  P_fin = 0.0254 / FPI       (pas d'ailette)
  s     = P_fin - Y_eff      (espacement inter-ailettes effectif)
  P_d = P_t * cos(pi/6)      (pas diagonal)
  S_face = P_t               (section maximale par unite de longueur)
  S_min = S_face - 2*N_fin/L_T*Y_eff*H - d_r  (section minimale)
  V_max / V_face = S_face / S_min    (effet venturi inter-ailettes)
  N_fin = (FPI/0.0254) * L_T (nombre d'ailettes par tube)
  S_fin = 2*pi*((d_r/2 + H)^2 - (d_r/2)^2)   (surface annulaire de l'ailette)
  A_fin = N_fin * S_fin      (surface ailettes par tube)
  A_tube = pi * d_r * L_T    (surface tube nu par tube)
  A_T   = A_fin + A_tube     (surface d'echange totale ext.)
  A_int = pi * d_i * L_T     (surface interne)
"""

import math
import pandas as pd


class Object:
    def __init__(self):
        # ----- parametres geometriques (defauts M01P3 these) -----
        self.d_r = 25.4e-3              # m  -- diametre exterieur tube
        self.e = 2.108e-3               # m  -- epaisseur paroi tube
        self.H = 15.075e-3              # m  -- hauteur ailette
        self.Y0 = 0.3e-3                # m  -- epaisseur ailette nue
        self.FPI = 10                   # fins per inch
        self.P_t = 63.5e-3              # m  -- pas transversal
        self.L_T = 0.254 * 4            # m  -- longueur d'un tube (1.016 m)
        self.N_T = 16                   # nombre total de tubes
        self.k_tube = 54.0              # W/m/K -- carbon steel
        self.eta_fin = 0.95             # rendement d'ailette (HBK ASHRAE 2005)

        # ----- input dynamique -----
        self.delta_f = 0.0              # m  -- epaisseur couche de givre (chaque cote)

        # ----- sorties calculees -----
        self.d_i = None
        self.P_fin = None
        self.Y_eff = None
        self.s = None
        self.P_d = None
        self.S_face = None
        self.S_min = None
        self.N_fin = None
        self.S_fin = None
        self.A_fin = None
        self.A_tube = None
        self.A_T = None
        self.A_int = None
        self.eta_s = None
        self.df = None

    def calculate(self):
        # ----- diametres -----
        self.d_i = self.d_r - 2 * self.e
        self.P_fin = 0.0254 / self.FPI

        # ----- epaisseur effective d'ailette (avec givre des 2 cotes) -----
        self.Y_eff = self.Y0 + 2.0 * self.delta_f
        self.s = self.P_fin - self.Y_eff
        if self.s <= 0:
            self.s = 1e-6  # securite : givre comble totalement l'espace

        # ----- pas diagonal et sections -----
        self.P_d = self.P_t * math.cos(math.pi / 6)
        self.S_face = self.P_t
        # Nombre d'ailettes par metre de tube
        N_fin_per_m = self.FPI / 0.0254
        # Section minimale par unite de longueur (m^2/m)
        # S_min = S_face - 2 * (N_fin/L) * Y_eff * H - d_r
        self.S_min = self.S_face - 2.0 * N_fin_per_m * self.Y_eff * self.H - self.d_r
        if self.S_min <= 0:
            self.S_min = 1e-6

        # ----- surfaces d'echange (par tube) -----
        self.N_fin = N_fin_per_m * self.L_T
        # Surface annulaire double-face d'une ailette
        # S_fin = 2 * (pi*((d_r/2+H)^2 - (d_r/2)^2))
        self.S_fin = 2.0 * math.pi * ((self.d_r / 2.0 + self.H) ** 2
                                      - (self.d_r / 2.0) ** 2)
        self.A_fin = self.N_fin * self.S_fin
        self.A_tube = math.pi * self.d_r * self.L_T  # pas de retrait pour ailettes
        self.A_T = self.A_tube + self.A_fin
        self.A_int = math.pi * self.d_i * self.L_T

        # ----- rendement de surface ailetee (efficacite globale) -----
        self.eta_s = 1.0 - (self.A_fin / self.A_T) * (1.0 - self.eta_fin)

        self.df = pd.DataFrame(
            {'TubeFinGeometry': [
                self.d_r * 1000, self.d_i * 1000,
                self.H * 1000, self.Y0 * 1000, self.Y_eff * 1000,
                self.s * 1000, self.FPI, self.P_t * 1000, self.L_T,
                self.S_face * 1000, self.S_min * 1000,
                self.S_face / self.S_min,
                self.A_T, self.A_int, self.A_fin, self.A_tube,
                self.eta_s, self.delta_f * 1000]},
            index=['d_r_mm', 'd_i_mm', 'H_mm', 'Y0_mm', 'Y_eff_mm',
                   's_mm', 'FPI', 'Pt_mm', 'L_T_m',
                   'S_face_mm', 'S_min_mm', 'venturi_ratio',
                   'A_T_m2', 'A_int_m2', 'A_fin_m2', 'A_tube_m2',
                   'eta_s', 'delta_f_mm'])
