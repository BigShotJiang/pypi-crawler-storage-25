"""Correlations validees de la these de Zoheir HADID (MINES ParisTech, 2012).

Reference : Hadid, Z. (2012). Gazeification du GNL par cycle de Brayton associe
a une boucle caloportrice et une pompe a chaleur. These doctorale,
Ecole Nationale Superieure des Mines de Paris.
HAL Id: tel-01674498  https://pastel.hal.science/tel-01674498v1

Ces correlations sont specifiques aux **echangeurs a tubes ailetes ronds
discontinus** en condition de givrage (evaporateurs frigorifiques).

Validation experimentale (60 essais sur maquettes M01P3, M02P3, M03P3, M04P3) :
  - Flux de chaleur sensible : +-8 %
  - Masse de givre cumulee  : +-15 %
  - Flux de chaleur total   : +-12 %

Domaine geometrique des maquettes utilisees :
  d_r = 25.4 mm, H = 15.075 mm (M01-M03) / 12.7 mm (M04)
  Y0  = 0.3 mm  (epaisseur ailette)
  FPI = 10 (M01, M02) / 6 (M03, M04)
  P_t = 63.5 mm (pas transversal)
"""

import math


# =============================================================================
# COTE AIR -- transfert de chaleur convectif h_a
# =============================================================================

def Briggs_Young_dry(Re_d, H, s, Y, Pr):
    """Briggs-Young modifiee Hadid, regime sec (eq 2.83 these).

    Nu = 0.8849 * Re_d^0.478 * (H/s)^-0.2 * (Y/s)^-0.1134 * Pr^(1/3)
    (= 6.6042 * 0.134 * Re_d^(0.681 - 0.203) ...)
    """
    return 0.8849 * Re_d ** 0.478 * (H / s) ** -0.2 * (Y / s) ** -0.1134 * Pr ** (1 / 3)


def Briggs_Young_frosted(Re_d, H, s, Y, Pr):
    """Briggs-Young recalee Hadid pour conditions de givrage (eq 2.91 these).

    Nu = 0.1008 * Re_d^0.7204 * (H/s)^-0.3995 * (Y/s)^-0.2359 * Pr^(1/3)

    Recalee sur 60 essais. Precision flux sensible : +-8 %.
    """
    return 0.1008 * Re_d ** 0.7204 * (H / s) ** -0.3995 * (Y / s) ** -0.2359 * Pr ** (1 / 3)


def Briggs_Young_original_1963(Re_d, H, s, Y, Pr):
    """Briggs-Young (1963) corrélation originale littérature (eq 2.70)."""
    return 0.134 * Re_d ** 0.681 * (H / s) ** -0.2 * (Y / s) ** -0.1134 * Pr ** (1 / 3)


def Krupiczka_2003(Re_d, H, s, Y, d_r, Pr):
    """Krupiczka et al (2003), tubes a ailettes extrudees (eq 2.77)."""
    return (0.182 * Re_d ** 0.633 * (H / s) ** -0.2 * (Y / s) ** -0.1134
            * (d_r / s) ** 0.141 * Pr ** (1 / 3))


def Vampola_1966(Re_d, P_t, d_r, s, Y):
    """Vampola (1966), tubes a ailettes rondes en quinconce (eq 2.78).

    Note : utilise diametre hydraulique d_v specifique (eq 2.79).
    """
    return (0.251 * Re_d ** 0.67
            * ((P_t - d_r) / d_r) ** -0.2
            * ((P_t - d_r) / (s + Y) + 1) ** -0.2)


def Ganguli_1985(Re_d, A_tube, A_tube_fin, Pr):
    """Ganguli et al (1985), >= 3 rangees de tubes ailetes (eq 2.80)."""
    return 0.38 * Re_d ** 0.6 * (A_tube / A_tube_fin) ** 0.15 * Pr ** (1 / 3)


# =============================================================================
# COTE AIR -- pertes de pression
# =============================================================================

def Robinson_Briggs_dP_dry(Re_d, P_t, P_d, d_r, rho_air, V_max):
    """Robinson-Briggs perte de pression regime sec (eq 2.84-2.85).

    f = 9.465 * Re_d^-0.316 * (P_t/d_r)^-0.927 * (P_t/P_d)^0.515
    dP = f * 2 * rho_air * V_max^2
    """
    f = 9.465 * Re_d ** -0.316 * (P_t / d_r) ** -0.927 * (P_t / P_d) ** 0.515
    return f * 2.0 * rho_air * V_max ** 2


def Vampola_dP_dry(Re_d, P_t, d_r, s, Y, d_v, rho_air, V_max):
    """Vampola (1966) perte de pression regime sec (eq 2.86)."""
    return (0.7315 * rho_air * V_max ** 2 * Re_d ** -0.245
            * ((P_t - d_r) / d_r) ** -0.9
            * ((P_t - d_r) / (s + Y) + 1) ** 0.70
            * (d_v / d_r) ** 0.9)


def Vampola_dP_frosted(Re_d, P_t, d_r, s, Y, d_v, H, rho_air, V_max):
    """Vampola modifiee Hadid pour conditions de givrage (eq 2.92 these).

    dP = a * rho * V_max^2 * Re_d^b * ((P_t-d_r)/d_r)^c
         * ((P_t-d_r)/(s+Y) + 1)^d * (d_v/d_r)^e * (H/s)^f * (Y/s)^g

    Coefficients selon le regime :
      Si Re_d <= 1000 : a=0.361,  b=-2.886, c=49.516, d=1.442, e=9.154,  f=-0.847, g=0.693
      Si Re_d >  1000 : a=1.289,  b=-0.306, c=-5.244, d=2.277, e=5.321,  f=-1.765, g=0.919
    """
    if Re_d <= 1000:
        a, b, c, d, e_, f, g = 0.361, -2.886, 49.516, 1.442, 9.154, -0.847, 0.693
    else:
        a, b, c, d, e_, f, g = 1.289, -0.306, -5.244, 2.277, 5.321, -1.765, 0.919

    return (a * rho_air * V_max ** 2 * Re_d ** b
            * ((P_t - d_r) / d_r) ** c
            * ((P_t - d_r) / (s + Y) + 1) ** d
            * (d_v / d_r) ** e_
            * (H / s) ** f
            * (Y / s) ** g)


# =============================================================================
# TRANSFERT DE MASSE -- fonction de Lewis recalee Hadid
# =============================================================================

def supersaturation_factor(Pv_air, Pvsat_surface):
    """Facteur de sursaturation relative S (eq 2.89 these).

    S = (Pv(HR, Ta) - Pvsat(Ts)) / Pv(HR, Ta)

    Force motrice de changement de phase. S > 0 pour condensation/sublimation.
    """
    if Pv_air <= 0:
        return 0.0
    return (Pv_air - Pvsat_surface) / Pv_air


def Lewis_function_Hadid(S):
    """Fonction de Lewis recalee en condition de givrage (eq 2.90 these).

    Le_f = 0.79 * ((0.37 + S) / S)^1.8

    Tend vers 0.79 pour S grand, infini quand S -> 0 (regime sec).
    Validee : masse de givre predite a +-15 %.
    """
    if S <= 1e-6:
        return float('inf')   # regime sec : pas de transfert de masse
    return 0.79 * ((0.37 + S) / S) ** 1.8


def mass_transfer_coefficient(h_a, Le_f, Cp_air_humid):
    """Coefficient de transfert de masse selon analogie Chilton-Colburn (eq).

    h_m = h_a / (Le_f * Cp_ah)
    """
    if Le_f == float('inf') or Le_f <= 0:
        return 0.0
    return h_a / (Le_f * Cp_air_humid)


# =============================================================================
# COTE REFRIGERANT INTERNE -- Nusselt en regime laminaire
# =============================================================================

def Nu_internal_laminar_developing(Re, Pr, d_i, L_T):
    """Nusselt interne, regime laminaire en developpement (eq 2.87 these).

    Nu = 3.66 + 0.065 * (d_i/L_T) * Re * Pr / (1 + 0.04 * [(d_i/L_T) * Re * Pr]^(2/3))
    """
    x = (d_i / L_T) * Re * Pr
    return 3.66 + 0.065 * x / (1.0 + 0.04 * x ** (2 / 3))


def Nu_internal_SiederTate(Re, Pr, d_i, L_T, mu_bulk, mu_wall):
    """Nusselt interne Sieder-Tate, regime laminaire (eq 2.88 these).

    Nu = 1.86 * (Re*Pr / (L_T/d_i))^(1/3) * (mu/mu_wall)^0.14

    Valable pour L_T/d_i < (Re*Pr/8) * (mu/mu_wall)^0.42.
    """
    return 1.86 * (Re * Pr / (L_T / d_i)) ** (1 / 3) * (mu_bulk / mu_wall) ** 0.14


def Nu_internal_DittusBoelter(Re, Pr, heating=True):
    """Nusselt interne turbulent Dittus-Boelter, conduites lisses.

    Nu = 0.023 * Re^0.8 * Pr^n  (n=0.4 chauffage, 0.3 refroidissement)
    Domaine : 1e4 < Re < 1.2e5, 0.7 < Pr < 120, L/D > 60.
    """
    n = 0.4 if heating else 0.3
    return 0.023 * Re ** 0.8 * Pr ** n


# =============================================================================
# Diametre hydraulique Vampola (utilise dans correlations Vampola)
# =============================================================================

def hydraulic_diameter_Vampola(A_tube, A_fin, d_r, N_fin):
    """Diametre hydraulique Vampola (eq 2.79 these).

    d_v = (A_tube * d_r + A_fin * sqrt(A_fin / (2 * N_fin))) / A_tube_fin
    """
    A_tube_fin = A_tube + A_fin
    return (A_tube * d_r + A_fin * math.sqrt(A_fin / (2 * N_fin))) / A_tube_fin
