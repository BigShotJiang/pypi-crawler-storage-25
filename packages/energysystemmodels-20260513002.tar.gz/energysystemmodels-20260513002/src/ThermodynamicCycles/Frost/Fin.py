"""Fin -- ailette froide (Modelica Croissance_Du_Givre.Fin).

Fournit la temperature de paroi Tp et la surface d'echange A_T au modele de
croissance du givre. Equivalent du connecteur Paroi cote Modelica.
"""

import math
import pandas as pd


class Object:
    def __init__(self):
        # Parametres geometriques (defauts du Modelica)
        self.R_tube = 0.0254 / 2     # m  -- rayon tube
        self.h_fin = 0.015075        # m  -- hauteur ailette
        self.Tp = 248.0              # K  -- temp paroi (-25 degC)
        self.A_T_override = None     # m2 -- si None, utilise 0.506*0.304

        # Sorties
        self.A_fin = None
        self.A_T = None
        self.df = None

    def calculate(self):
        self.A_fin = 2 * math.pi * ((self.R_tube + self.h_fin) ** 2 - self.R_tube ** 2)
        # Modelica fixe A_T = 0.506 * 0.304 directement
        self.A_T = self.A_T_override if self.A_T_override is not None else 0.506 * 0.304

        self.df = pd.DataFrame(
            {'Fin': [self.Tp - 273.15, self.A_fin, self.A_T, self.R_tube, self.h_fin]},
            index=['Tp_degC', 'A_fin_m2', 'A_T_m2', 'R_tube_m', 'h_fin_m'])
