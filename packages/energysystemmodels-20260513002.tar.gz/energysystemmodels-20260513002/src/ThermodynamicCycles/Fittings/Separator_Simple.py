"""Separator_Simple -- separateur liquide/vapeur statique (Modelica Fittings.Separator_Simple).

Equations :
    x = vapourQuality(state_a)            (titre vapeur a l'entree)
    port_c.m_flow = -x * port_a.m_flow    (vapeur sort en c)
    port_b.m_flow = -(1-x) * port_a.m_flow (liquide sort en b)
    port_a.p = port_b.p = port_c.p
    port_b.h_outflow = bubbleEnthalpy(p)  (liquide sature)
    port_c.h_outflow = dewEnthalpy(p)     (vapeur saturee)

Convention Python :
    Inlet           -> port_a (entree diphasique)
    Outlet_liquid   -> port_b (liquide sature)
    Outlet_vapor    -> port_c (vapeur saturee)
"""

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort
from CoolProp.CoolProp import PropsSI
import pandas as pd


class Object:
    def __init__(self):
        self.Timestamp = None

        self.Inlet = FluidPort()
        self.Outlet_liquid = FluidPort()
        self.Outlet_vapor = FluidPort()

        # Sorties
        self.x = None                 # titre vapeur entree
        self.h_liquid = None
        self.h_vapor = None
        self.T_sat_degC = None
        self.df = []

    def calculate(self):
        fluid = self.Inlet.fluid
        P = self.Inlet.P
        h_in = self.Inlet.h
        F_in = self.Inlet.F if self.Inlet.F is not None else 0.0

        # Enthalpies de saturation a la pression d'entree
        self.h_liquid = PropsSI('H', 'P', P, 'Q', 0, fluid)
        self.h_vapor = PropsSI('H', 'P', P, 'Q', 1, fluid)
        T_sat = PropsSI('T', 'P', P, 'Q', 0, fluid)
        self.T_sat_degC = T_sat - 273.15

        # Titre vapeur a l'entree (clip [0,1])
        if self.h_vapor > self.h_liquid:
            x = (h_in - self.h_liquid) / (self.h_vapor - self.h_liquid)
        else:
            x = 0.0
        x = max(0.0, min(1.0, x))
        self.x = x

        # Repartition des debits
        F_liquid = (1.0 - x) * F_in
        F_vapor = x * F_in

        # Outlet liquide (sature, port_b)
        self.Outlet_liquid.fluid = fluid
        self.Outlet_liquid.P = P
        self.Outlet_liquid.h = self.h_liquid
        self.Outlet_liquid.F = F_liquid

        # Outlet vapeur (saturee, port_c)
        self.Outlet_vapor.fluid = fluid
        self.Outlet_vapor.P = P
        self.Outlet_vapor.h = self.h_vapor
        self.Outlet_vapor.F = F_vapor

        self.df = pd.DataFrame(
            {'Separator_Simple': [self.Timestamp, fluid, F_in, x, F_liquid,
                                  F_vapor, self.T_sat_degC, P / 1e5]},
            index=['Timestamp', 'fluid', 'F_in_kgs', 'x_in', 'F_liquid_kgs',
                   'F_vapor_kgs', 'Tsat_degC', 'P_bar'])
