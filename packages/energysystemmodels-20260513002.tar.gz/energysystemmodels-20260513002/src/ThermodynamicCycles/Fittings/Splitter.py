"""Splitter -- repartiteur 1 entree / 2 sorties (Modelica Fittings.Splitter).

Equations :
    port_b.m_flow = -Ratio * port_a.m_flow         (Ratio fraction vers port_b)
    port_c.m_flow = -(1-Ratio) * port_a.m_flow
    port_b.h_outflow = port_c.h_outflow = h_a       (memes proprietes thermo)
    port_b.p = port_c.p = port_a.p                  (sans perte de charge)

Convention Python :
    Inlet     -> port_a (entree)
    Outlet_b  -> port_b (sortie 1, fraction Ratio du debit)
    Outlet_c  -> port_c (sortie 2, fraction 1-Ratio)
"""

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort
from CoolProp.CoolProp import PropsSI
import pandas as pd


class Object:
    def __init__(self):
        self.Timestamp = None

        self.Inlet = FluidPort()
        self.Outlet_b = FluidPort()
        self.Outlet_c = FluidPort()

        # Ratio : fraction du debit dirigee vers Outlet_b (0..1)
        self.Ratio = 0.5

        # Sorties calculees
        self.F_b = None
        self.F_c = None
        self.df = []

    def calculate(self):
        if not (0.0 <= self.Ratio <= 1.0):
            raise ValueError(f"Ratio doit etre dans [0,1], recu {self.Ratio}")

        F_a = self.Inlet.F if self.Inlet.F is not None else 0.0
        self.F_b = self.Ratio * F_a
        self.F_c = (1.0 - self.Ratio) * F_a

        # Propagation proprietes (memes h et P sur les 2 sorties)
        for out, F in ((self.Outlet_b, self.F_b), (self.Outlet_c, self.F_c)):
            out.fluid = self.Inlet.fluid
            out.P = self.Inlet.P
            out.h = self.Inlet.h
            out.F = F

        # T pour reporting
        if self.Inlet.h is not None and self.Inlet.P is not None:
            T_degC = PropsSI('T', 'P', self.Inlet.P, 'H', self.Inlet.h,
                             self.Inlet.fluid) - 273.15
        else:
            T_degC = None

        self.df = pd.DataFrame(
            {'Splitter': [self.Timestamp, self.Inlet.fluid, F_a, self.F_b,
                          self.F_c, self.Ratio, T_degC]},
            index=['Timestamp', 'fluid', 'F_in_kgs', 'F_b_kgs', 'F_c_kgs',
                   'Ratio', 'T_degC'])
