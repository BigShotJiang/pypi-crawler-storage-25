"""Mixer -- melangeur 2 entrees / 1 sortie (Modelica Fittings.Mixer).

Equations :
    port_a.p = port_b.p = port_c.p                              (no dP)
    port_a.m_flow + port_b.m_flow + port_c.m_flow = 0           (mass balance)
    -> F_c = F_a + F_b
    h_c = (F_a*h_a + F_b*h_b) / F_c                             (energy balance)

Convention Python :
    Inlet_a, Inlet_b -> port_a, port_b (deux entrees)
    Outlet           -> port_c (sortie)
"""

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort
from CoolProp.CoolProp import PropsSI
import pandas as pd


class Object:
    def __init__(self):
        self.Timestamp = None

        self.Inlet_a = FluidPort()
        self.Inlet_b = FluidPort()
        self.Outlet = FluidPort()

        # Sorties
        self.T_degC = None
        self.df = []

    def calculate(self):
        F_a = self.Inlet_a.F if self.Inlet_a.F is not None else 0.0
        F_b = self.Inlet_b.F if self.Inlet_b.F is not None else 0.0
        F_c = F_a + F_b

        if F_c <= 0:
            # Melange degenere : pas de flux
            self.Outlet.fluid = self.Inlet_a.fluid or self.Inlet_b.fluid
            self.Outlet.P = self.Inlet_a.P or self.Inlet_b.P
            self.Outlet.h = self.Inlet_a.h or self.Inlet_b.h
            self.Outlet.F = 0.0
        else:
            h_a = self.Inlet_a.h if self.Inlet_a.h is not None else 0.0
            h_b = self.Inlet_b.h if self.Inlet_b.h is not None else 0.0
            h_c = (F_a * h_a + F_b * h_b) / F_c

            self.Outlet.fluid = self.Inlet_a.fluid or self.Inlet_b.fluid
            # Pression : reference sur Inlet_a (les 3 ports devraient avoir la meme)
            self.Outlet.P = self.Inlet_a.P if self.Inlet_a.P is not None else self.Inlet_b.P
            self.Outlet.h = h_c
            self.Outlet.F = F_c

        # T pour reporting
        if self.Outlet.h is not None and self.Outlet.P is not None and F_c > 0:
            self.T_degC = PropsSI('T', 'P', self.Outlet.P, 'H', self.Outlet.h,
                                  self.Outlet.fluid) - 273.15
        else:
            self.T_degC = None

        Ta = (PropsSI('T', 'P', self.Inlet_a.P, 'H', self.Inlet_a.h,
                      self.Inlet_a.fluid) - 273.15
              if self.Inlet_a.h is not None else None)
        Tb = (PropsSI('T', 'P', self.Inlet_b.P, 'H', self.Inlet_b.h,
                      self.Inlet_b.fluid) - 273.15
              if self.Inlet_b.h is not None else None)

        self.df = pd.DataFrame(
            {'Mixer': [self.Timestamp, self.Outlet.fluid, F_a, F_b, F_c,
                       Ta, Tb, self.T_degC]},
            index=['Timestamp', 'fluid', 'F_a_kgs', 'F_b_kgs', 'F_c_kgs',
                   'Ta_degC', 'Tb_degC', 'Tc_degC'])
