"""Ejector -- ejecteur composite (Modelica Ejector.Ejector).

Combinaison de Nozzle + Mixing_Chamber + Diffuser pour former un ejecteur complet.

Schema :
    port_a (HP primaire) ---> Nozzle ---> Mixing_Chamber.primary
    port_b (BP secondaire) -----------> Mixing_Chamber.secondary
    Mixing_Chamber.outlet ---> Diffuser ---> port_c (sortie recompressee)

Convention Python :
    Inlet_primary    -> port_a (haute pression, ex. detente du condenseur)
    Inlet_secondary  -> port_b (basse pression, ex. evaporateur)
    Outlet           -> port_c (sortie recompressee vers condenseur)

Parametres :
    epsilon_s, epsilon_m, epsilon_d : rendements des 3 sous-composants
    A_nozzle : section de la tuyere
    P_intermediate : pression intermediaire dans la chambre de melange
                      (= pression de port_b en convention ejecteur)
"""

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort
from ThermodynamicCycles.Ejector.Nozzle import Object as Nozzle
from ThermodynamicCycles.Ejector.Mixing_Chamber import Object as MixingChamber
from ThermodynamicCycles.Ejector.Diffuser import Object as Diffuser
import pandas as pd


class Object:
    def __init__(self):
        self.Timestamp = None

        self.Inlet_primary = FluidPort()
        self.Inlet_secondary = FluidPort()
        self.Outlet = FluidPort()

        # Parametres
        self.epsilon_s = 0.7
        self.epsilon_m = 0.8
        self.epsilon_d = 0.7
        self.A_nozzle = 1e-3

        # Sous-composants
        self.nozzle = Nozzle()
        self.mixer = MixingChamber()
        self.diffuser = Diffuser()

        # Sortie reporting
        self.entrainment_ratio = None  # m_secondary / m_primary
        self.compression_ratio = None  # P_out / P_secondary
        self.df = []

    def calculate(self):
        # 1. Nozzle : detente de port_a vers P_intermediate (= P_secondary)
        self.nozzle.Inlet.fluid = self.Inlet_primary.fluid
        self.nozzle.Inlet.P = self.Inlet_primary.P
        self.nozzle.Inlet.h = self.Inlet_primary.h
        self.nozzle.Outlet.P = self.Inlet_secondary.P  # P_intermediate
        self.nozzle.epsilon_s = self.epsilon_s
        self.nozzle.A = self.A_nozzle
        self.nozzle.calculate()

        # 2. Mixing_Chamber
        self.mixer.Inlet_primary.fluid = self.nozzle.Outlet.fluid
        self.mixer.Inlet_primary.P = self.nozzle.Outlet.P
        self.mixer.Inlet_primary.h = self.nozzle.Outlet.h
        self.mixer.Inlet_primary.F = self.nozzle.Outlet.F

        self.mixer.Inlet_secondary.fluid = self.Inlet_secondary.fluid
        self.mixer.Inlet_secondary.P = self.Inlet_secondary.P
        self.mixer.Inlet_secondary.h = self.Inlet_secondary.h
        self.mixer.Inlet_secondary.F = (self.Inlet_secondary.F
                                        if self.Inlet_secondary.F is not None
                                        else 0.0)

        self.mixer.epsilon_m = self.epsilon_m
        self.mixer.v_1 = self.nozzle.v_1
        self.mixer.calculate()

        # 3. Diffuser
        self.diffuser.Inlet.fluid = self.mixer.Outlet.fluid
        self.diffuser.Inlet.P = self.mixer.Outlet.P
        self.diffuser.Inlet.h = self.mixer.Outlet.h
        self.diffuser.Inlet.F = self.mixer.Outlet.F
        self.diffuser.epsilon_d = self.epsilon_d
        self.diffuser.v_3 = self.mixer.v_3
        self.diffuser.calculate()

        # Outlet ejecteur
        self.Outlet.fluid = self.diffuser.Outlet.fluid
        self.Outlet.P = self.diffuser.Outlet.P
        self.Outlet.h = self.diffuser.Outlet.h
        self.Outlet.F = self.diffuser.Outlet.F

        # Indicateurs cles
        m_p = self.nozzle.m_flow
        m_s = self.mixer.Inlet_secondary.F
        if m_p > 1e-9:
            self.entrainment_ratio = m_s / m_p
        else:
            self.entrainment_ratio = 0.0
        if self.Inlet_secondary.P and self.Inlet_secondary.P > 0:
            self.compression_ratio = self.Outlet.P / self.Inlet_secondary.P
        else:
            self.compression_ratio = None

        self.df = pd.DataFrame(
            {'Ejector': [self.Timestamp, self.Inlet_primary.fluid,
                         m_p, m_s, m_p + m_s,
                         self.Inlet_primary.P / 1e5,
                         self.Inlet_secondary.P / 1e5,
                         self.Outlet.P / 1e5,
                         self.entrainment_ratio, self.compression_ratio]},
            index=['Timestamp', 'fluid', 'm_primary', 'm_secondary', 'm_total',
                   'Pp_bar', 'Ps_bar', 'Pout_bar',
                   'entrainment_ratio', 'compression_ratio'])
