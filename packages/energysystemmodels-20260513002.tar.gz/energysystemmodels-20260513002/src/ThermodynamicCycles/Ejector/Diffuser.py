"""Diffuser -- diffuseur d'ejecteur (Modelica Ejector.Diffuser).

Recompresse le melange post-choc en convertissant l'energie cinetique en
pression. Sortie supposee au repos (v_out = 0).

Equations :
    h_b - h_a = v_3^2 / 2                              (bilan energie : E_kin -> enthalpie)
    h_es - h_a = epsilon_d * (h_b - h_a)               (rendement isentropique inverse)
    h_es = h(P_b, S_a)                                 (etat isentropique)

Convention Python :
    Inlet  -> port_a (entree post-choc, vitesse v_3)
    Outlet -> port_b (sortie au repos, recompresse)
    v_3 : vitesse entree (input)
"""

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort
from CoolProp.CoolProp import PropsSI
from scipy.optimize import brentq
import pandas as pd


class Object:
    def __init__(self):
        self.Timestamp = None

        self.Inlet = FluidPort()
        self.Outlet = FluidPort()

        self.epsilon_d = 0.7          # rendement diffuseur
        self.v_3 = 100.0              # vitesse entree (m/s)

        # Sorties
        self.h_es = None              # enthalpie isentropique sortie
        self.P_out = None             # pression de sortie calculee
        self.df = []

    def calculate(self):
        fluid = self.Inlet.fluid
        P_a = self.Inlet.P
        h_a = self.Inlet.h
        m = self.Inlet.F if self.Inlet.F is not None else 0.0

        # Bilan energie (port_b au repos)
        h_b = h_a + 0.5 * self.v_3 ** 2

        # Enthalpie isentropique correspondante (compression)
        S_a = PropsSI('S', 'P', P_a, 'H', h_a, fluid)
        self.h_es = h_a + self.epsilon_d * (h_b - h_a)

        # Trouver P_b tel que h(P_b, S_a) = h_es (compression isentropique amenant a h_es)
        # h_es > h_a -> P_b > P_a
        try:
            def f(P):
                return PropsSI('H', 'P', P, 'S', S_a, fluid) - self.h_es
            # encadrement : P_a (h=h_a) jusqu'a 10*P_a
            P_lo = P_a
            P_hi = 10.0 * P_a
            for _ in range(20):
                if f(P_hi) > 0:
                    break
                P_hi *= 2.0
            self.P_out = brentq(f, P_lo, P_hi, xtol=10.0)
        except Exception:
            # Fallback : compression incompressible approx
            rho = PropsSI('D', 'P', P_a, 'H', h_a, fluid)
            self.P_out = P_a + rho * 0.5 * self.v_3 ** 2 * self.epsilon_d

        self.Outlet.fluid = fluid
        self.Outlet.P = self.P_out
        self.Outlet.h = h_b
        self.Outlet.F = m

        self.df = pd.DataFrame(
            {'Diffuser': [self.Timestamp, fluid, m, self.v_3,
                          P_a / 1e5, self.P_out / 1e5,
                          self.epsilon_d, h_a / 1000.0, h_b / 1000.0]},
            index=['Timestamp', 'fluid', 'F_kgs', 'v3_ms',
                   'Pa_bar', 'Pb_bar', 'eps_d', 'ha_kJkg', 'hb_kJkg'])
