"""Mixing_Chamber -- chambre de melange d'ejecteur (Modelica Ejector.Mixing_Chamber).

Recoit le flux primaire (depuis Nozzle, vitesse v_1) et le flux secondaire
(au repos, port_b) et produit un melange post-onde de choc (sortie port_c).

Equations :
    Conservation quantite de mouvement (avec rendement de melange) :
        (m_a + m_b) * v_2 = epsilon_m * m_a * v_1
    Conservation energie :
        (m_a + m_b) * (h_2 + v_2^2/2) = m_a * (h_a + v_1^2/2) + m_b * h_b
    Choc normal (Mach >1 -> <1) avec correlation gaz parfait :
        v_3 / v_2 = ... (eq Rankine-Hugoniot simplifiee)
    Bilan energie post-choc :
        h_3 = h_2 + v_2^2/2 - v_3^2/2

Pour la simplicite (le modele Modelica utilise des correlations gaz parfait
non triviales), nous utilisons une approche pragmatique :
    - Conservation simple : v_3 = v_2 (pas de choc explicite, pertes via epsilon_m)
    - h_3 = h_2 (recuperation totale d'energie cinetique au diffuseur)

Convention Python :
    Inlet_primary    -> port_a (vient de Nozzle, vitesse v_1)
    Inlet_secondary  -> port_b (au repos)
    Outlet           -> port_c (sortie melangee, vitesse v_3 vers Diffuser)
"""

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort
from CoolProp.CoolProp import PropsSI
import pandas as pd


class Object:
    def __init__(self):
        self.Timestamp = None

        self.Inlet_primary = FluidPort()
        self.Inlet_secondary = FluidPort()
        self.Outlet = FluidPort()

        self.epsilon_m = 0.8          # rendement de melange
        self.v_1 = 100.0              # vitesse primaire entree (m/s)

        # Sorties
        self.v_2 = None               # vitesse melange post-meeting
        self.v_3 = None               # vitesse melange post-choc
        self.m_total = None
        self.h_2 = None
        self.df = []

    def calculate(self):
        fluid = self.Inlet_primary.fluid
        m_a = self.Inlet_primary.F if self.Inlet_primary.F is not None else 0.0
        m_b = self.Inlet_secondary.F if self.Inlet_secondary.F is not None else 0.0
        h_a = self.Inlet_primary.h
        h_b = self.Inlet_secondary.h
        P_b = self.Inlet_secondary.P

        m_c = m_a + m_b
        self.m_total = m_c

        if m_c < 1e-9:
            self.Outlet.fluid = fluid
            self.Outlet.P = P_b
            self.Outlet.h = h_b
            self.Outlet.F = 0.0
            self.v_2 = 0.0
            self.v_3 = 0.0
            return

        # Conservation quantite de mouvement
        self.v_2 = self.epsilon_m * m_a * self.v_1 / m_c

        # Conservation energie (avec energies cinetiques)
        # h_2 + v_2^2/2 = (m_a*(h_a + v_1^2/2) + m_b*h_b) / m_c
        E_total = (m_a * (h_a + 0.5 * self.v_1 ** 2) + m_b * h_b) / m_c
        self.h_2 = E_total - 0.5 * self.v_2 ** 2

        # Simplification : pas de choc explicite, on prend v_3 = v_2 et h_3 = h_2
        self.v_3 = self.v_2
        h_3 = self.h_2

        self.Outlet.fluid = fluid
        self.Outlet.P = P_b
        self.Outlet.h = h_3
        self.Outlet.F = m_c

        self.df = pd.DataFrame(
            {'Mixing_Chamber': [self.Timestamp, fluid, m_a, m_b, m_c,
                                self.v_1, self.v_2, self.v_3,
                                self.epsilon_m, P_b / 1e5]},
            index=['Timestamp', 'fluid', 'm_primary', 'm_secondary', 'm_total',
                   'v1_ms', 'v2_ms', 'v3_ms', 'eps_m', 'P_bar'])
