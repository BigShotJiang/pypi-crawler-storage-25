"""Nozzle -- tuyere (Modelica Ejector.Nozzle).

Detente d'un fluide haute pression vers basse pression avec acceleration.
Le fluide est suppose initialement au repos (v_a = 0).

Equations :
    P_a, h_a -> S_a (entropie a l'aspiration)
    h_iso_b = h(P_b, S_a)              (etat isentropique apres detente)
    h_b = h_a - epsilon_s * (h_a - h_iso_b)    (h_b est l'enthalpie reelle)
    v_1^2 / 2 = epsilon_s * (h_a - h_iso_b)    (vitesse en sortie)
    m_flow = v_1 * rho_b * A           (continuite)

Convention Python :
    Inlet  -> port_a (entree HP, fluide au repos)
    Outlet -> port_b (sortie BP, fluide accelere)
"""

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort
from CoolProp.CoolProp import PropsSI
import math
import pandas as pd


class Object:
    def __init__(self):
        self.Timestamp = None

        self.Inlet = FluidPort()
        self.Outlet = FluidPort()

        self.epsilon_s = 0.7          # rendement isentropique
        self.A = 1e-3                 # section sortie (m2)

        # Sorties
        self.v_1 = None               # vitesse sortie (m/s)
        self.m_flow = None            # debit massique (kg/s)
        self.x = None                 # titre vapeur en sortie
        self.df = []

    def calculate(self):
        fluid = self.Inlet.fluid
        P_a = self.Inlet.P
        h_a = self.Inlet.h
        P_b = self.Outlet.P

        S_a = PropsSI('S', 'P', P_a, 'H', h_a, fluid)
        h_iso_b = PropsSI('H', 'P', P_b, 'S', S_a, fluid)

        # Vitesse sortie
        delta_h = max(0.0, h_a - h_iso_b)
        self.v_1 = math.sqrt(2 * self.epsilon_s * delta_h)

        # Enthalpie sortie reelle
        h_b = h_a - self.epsilon_s * delta_h

        # Densite sortie
        rho_b = PropsSI('D', 'P', P_b, 'H', h_b, fluid)

        # Debit
        self.m_flow = self.v_1 * rho_b * self.A

        # Titre vapeur sortie
        try:
            h_l = PropsSI('H', 'P', P_b, 'Q', 0, fluid)
            h_v = PropsSI('H', 'P', P_b, 'Q', 1, fluid)
            self.x = max(0.0, min(1.0, (h_b - h_l) / (h_v - h_l)))
        except Exception:
            self.x = None

        self.Outlet.fluid = fluid
        self.Outlet.h = h_b
        self.Outlet.F = self.m_flow
        self.Inlet.F = self.m_flow

        self.df = pd.DataFrame(
            {'Nozzle': [self.Timestamp, fluid, P_a / 1e5, P_b / 1e5,
                        self.v_1, self.m_flow, self.x, rho_b]},
            index=['Timestamp', 'fluid', 'Pa_bar', 'Pb_bar',
                   'v1_ms', 'm_flow_kgs', 'x_out', 'rho_out'])
