"""Heater -- chauffe avec puissance imposee (Modelica EnergySystems.Components.Heater).

Equations (Heater_withoutIntVol) :
    port_a.p = port_b.p                  (no pressure loss)
    port_a.m_flow + port_b.m_flow = 0    (mass balance, no storage)
    Q_flow = u * Q_flow_nominal          (Q_flow positif = chaleur recue par le fluide)
    -Q_flow = port_a.m_flow * h_a + port_b.m_flow * h_b
    -> h_b = h_a + Q_flow / m_a

Convention Python :
    Inlet  -> port_a (entree, F > 0)
    Outlet -> port_b (sortie, F = Inlet.F)
"""

from ThermodynamicCycles.FluidPort.FluidPort import FluidPort
from CoolProp.CoolProp import PropsSI
import pandas as pd


class Object:
    def __init__(self):
        self.Timestamp = None

        self.Inlet = FluidPort()
        self.Outlet = FluidPort()

        # Parametres
        self.Q_flow_nominal = 1.0e5   # W -- puissance nominale
        self.u = 1.0                  # ratio (0..1) puissance reelle / nominale
        # Variante : imposer directement Q_flow_W (override de u*Q_flow_nominal)
        self.Q_flow_W = None

        # Sorties
        self.Q_flow = None            # W effectivement transferes
        self.Ti_degC = None
        self.To_degC = None
        self.df = []

    def calculate(self):
        # Conservation masse + pression
        self.Outlet.fluid = self.Inlet.fluid
        self.Outlet.F = self.Inlet.F
        self.Outlet.P = self.Inlet.P

        # Puissance imposee
        if self.Q_flow_W is not None:
            self.Q_flow = self.Q_flow_W
        else:
            self.Q_flow = self.u * self.Q_flow_nominal

        if self.Inlet.F is None or self.Inlet.F <= 0:
            self.Outlet.h = self.Inlet.h
            self.Q_flow = 0.0
        else:
            self.Outlet.h = self.Inlet.h + self.Q_flow / self.Inlet.F

        # Temperatures
        self.Ti_degC = PropsSI('T', 'P', self.Inlet.P, 'H', self.Inlet.h,
                               self.Inlet.fluid) - 273.15
        self.To_degC = PropsSI('T', 'P', self.Outlet.P, 'H', self.Outlet.h,
                               self.Outlet.fluid) - 273.15

        self.df = pd.DataFrame(
            {'Heater': [self.Timestamp, self.Inlet.fluid, self.Inlet.F,
                        self.Q_flow / 1000.0, self.Ti_degC, self.To_degC,
                        self.Inlet.P / 1e5]},
            index=['Timestamp', 'fluid', 'F_kgs', 'Q_flow_kW',
                   'Ti_degC', 'To_degC', 'P_bar'])
