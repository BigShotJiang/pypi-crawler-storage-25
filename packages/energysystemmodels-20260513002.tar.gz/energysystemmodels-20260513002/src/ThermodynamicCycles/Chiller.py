# =============================================================================
# Chiller Model (Evaporator + Compressor + Desuperheater + Condenser + Expansion_Valve)
# =============================================================================

import CoolProp.CoolProp as CP
import pandas as pd
from ThermodynamicCycles.Evaporator import Evaporator
from ThermodynamicCycles.Compressor import Compressor
from ThermodynamicCycles.Desuperheater import Desuperheater
from ThermodynamicCycles.Expansion_Valve import Expansion_Valve
from ThermodynamicCycles.Condenser import Condenser
from ThermodynamicCycles.Connect import Fluid_connect

from ThermodynamicCycles import Temperature_Entropy_Chart

class Object:
    def __init__(self, fluid='R134a', evap_params=None, comp_params=None, cond_params=None):
        # Initialize chiller components
        self.EVAP = Evaporator.Object()
        self.COMP = Compressor.Object()
        self.DESURCH = Desuperheater.Object()
        self.COND = Condenser.Object()
        self.DET = Expansion_Valve.Object()

        # Set fluid for all components
        self.fluid = fluid
        self.EVAP.fluid = self.fluid
        self.COMP.fluid = self.fluid
        self.DESURCH.fluid = self.fluid
        self.COND.fluid = self.fluid
        self.DET.fluid = self.fluid

        # Set parameters for each component
        self.set_evaporator_parameters(evap_params)
        self.set_compressor_parameters(comp_params)
        self.set_condenser_parameters(cond_params)

        self.points=[]

    def set_evaporator_parameters(self, params):
        if params:
            self.EVAP.Ti_degC= params.get('Ti_degC', 5)
            self.EVAP.surchauff = params.get('surchauff', 2)
            self.EVAP.Inlet.F = params.get('F', 1)
            

    def set_compressor_parameters(self, params):
        if params:
            self.COMP.Tcond_degC = params.get('Tcond_degC', 40)
            self.COMP.eta_is = params.get('eta_is', 0.8)
            self.COMP.Tdischarge_target = params.get('Tdischarge_target', 80)
            if 'Q_comp' in params:
                self.COMP.Q_comp = params['Q_comp']

    def set_condenser_parameters(self, params):
        if params:
            self.COND.subcooling = params.get('subcooling', 2)

    def calculate_cycle(self):
        # Calculation algorithm
        self.EVAP.Inlet.h = CP.PropsSI('H', 'P', 1 * 1e5, 'T', 40 + 273.15, self.fluid)
        self.EVAP.calculate() 
        Fluid_connect(self.COMP.Inlet, self.EVAP.Outlet)
        self.COMP.calculate()
        Fluid_connect(self.DESURCH.Inlet, self.COMP.Outlet)
        self.DESURCH.calculate()
        Fluid_connect(self.COND.Inlet, self.DESURCH.Outlet)
        self.COND.calculate()
        Fluid_connect(self.DET.Inlet, self.COND.Outlet)
        Fluid_connect(self.DET.Outlet, self.EVAP.Inlet)
        self.DET.calculate()
        Fluid_connect(self.EVAP.Inlet, self.DET.Outlet)
        self.EVAP.calculate() # Recalculate evaporator

        self.EER = self.EVAP.Q_evap / self.COMP.Q_comp
        self.Q_condTot = self.COND.Q_cond + self.DESURCH.Qdesurch
        self.COP = self.Q_condTot / self.COMP.Q_comp

        T_evap = self.EVAP.Ti_degC
        T_cond = self.COMP.Tcond_degC
        lift = T_cond - T_evap
        COP_Carnot = (T_cond + 273.15) / lift if lift > 0 else float('inf')

        self.df = pd.DataFrame({'Chiller': [
            self.fluid,
            round(T_evap, 1), round(T_cond, 1), round(lift, 1),
            round(self.EER, 3), round(self.COP, 3),
            round(COP_Carnot, 2),
            round(self.COP / COP_Carnot * 100, 1) if COP_Carnot < float('inf') else 0,
            round(self.COMP.Q_comp / 1000, 2),
            round(self.COMP.Q_losses / 1000, 2),
            round(self.EVAP.Q_evap / 1000, 2),
            round(self.Q_condTot / 1000, 2),
            round(self.COMP.Outlet.T - 273.15, 1),
            round(self.EVAP.Pi / 1e5, 2),
            round(self.COND.Psat / 1e5, 2),
        ]}, index=[
            'Fluid', 'T_evap (C)', 'T_cond (C)', 'Lift (K)',
            'EER', 'COP', 'COP_Carnot', 'Eta_Carnot (%)',
            'Q_comp (kW)', 'Q_losses (kW)', 'Q_evap (kW)', 'Q_condTot (kW)',
            'T_refoulement (C)', 'P_evap (bar)', 'P_cond (bar)',
        ])


        self.points = [
            {"T": self.EVAP.Tsv - 273.15, "S": self.EVAP.Ssv},
            {"T": self.EVAP.Outlet.T - 273.15, "S": self.EVAP.Outlet.S},
            {"T": self.COMP.Outlet.T - 273.15, "S": self.COMP.Outlet.S},
            {"T": self.DESURCH.Outlet.T - 273.15, "S": self.DESURCH.Outlet.S},
            {"T": self.COND.Tl_sat- 273.15, "S": self.COND.Sl_sat},
            {"T": self.COND.Outlet.T - 273.15, "S": self.COND.Outlet.S},
            {"T": self.DET.Outlet.T- 273.15, "S": self.DET.Outlet.S},
            {"T": self.EVAP.Tsv - 273.15, "S": self.EVAP.Ssv}
        ]
      



    def print_results(self):
        print(self.df)
        # Print Results
        print("COMPONENT DATAFRAMES:\n")
        print("Compressor:")
        print(self.COMP.df)
        print("\nEvaporator:")
        print(self.EVAP.df)
        print("\nDesuperheater:")
        print(self.DESURCH.df)
        print("\nCondenser:")
        print(self.COND.df)
        print("\nExpansion Valve:")
        print(self.DET.df)



    def summary(self):
        """Retourne un DataFrame de synthese du cycle frigorifique."""
        T_evap = self.EVAP.Ti_degC
        T_cond = self.COMP.Tcond_degC
        lift = T_cond - T_evap
        COP_carnot = (T_cond + 273.15) / lift if lift > 0 else float('inf')
        eta_carnot = self.COP / COP_carnot if COP_carnot < float('inf') else 0

        rows = [
            ("Fluide", self.fluid),
            ("T evaporation (degC)", f"{T_evap:.1f}"),
            ("T condensation (degC)", f"{T_cond:.1f}"),
            ("Lift thermique (K)", f"{lift:.1f}"),
            ("COP chauffage", f"{self.COP:.2f}"),
            ("EER froid", f"{self.EER:.2f}"),
            ("COP Carnot", f"{COP_carnot:.2f}"),
            ("Efficacite Carnot", f"{eta_carnot:.1%}"),
            ("Q condenseur (kW)", f"{self.Q_condTot/1000:.1f}"),
            ("Q evaporateur (kW)", f"{self.EVAP.Q_evap/1000:.1f}"),
            ("W compresseur (kW)", f"{self.COMP.Q_comp/1000:.1f}"),
            ("T refoulement (degC)", f"{self.COMP.Outlet.T - 273.15:.1f}"),
            ("P evaporation (bar)", f"{self.EVAP.Outlet.P/1e5:.2f}"),
            ("P condensation (bar)", f"{self.COMP.Outlet.P/1e5:.2f}"),
        ]
        return pd.DataFrame(rows, columns=["Indicateur", "Valeur"])

    @staticmethod
    def parametric_study(fluid, T_source_range, T_cible_range,
                         superheat=5, subcool=3, eta_is=0.78,
                         save_fig=None):
        """Etude parametrique COP vs temperatures source/cible.

        Parameters
        ----------
        fluid : str
            Fluide frigorigene (ex: 'R134a').
        T_source_range : list or array
            Temperatures source a tester (degC).
        T_cible_range : list or array
            Temperatures cible a tester (degC).
        superheat : float
            Surchauffe evaporateur (K).
        subcool : float
            Sous-refroidissement condenseur (K).
        eta_is : float
            Rendement isentropique compresseur.
        save_fig : str or None
            Chemin image a sauvegarder.

        Returns
        -------
        pd.DataFrame
            Resultats pour chaque combinaison (T_source, T_cible).
        """
        import numpy as np
        import matplotlib.pyplot as plt

        resultats = []
        for T_src in T_source_range:
            for T_cib in T_cible_range:
                if T_cib <= T_src:
                    continue
                try:
                    ch = Object(
                        fluid=fluid,
                        evap_params={'Ti_degC': T_src, 'surchauff': superheat, 'F': 1.0},
                        comp_params={'Tcond_degC': T_cib, 'eta_is': eta_is,
                                     'Tdischarge_target': T_cib + 40},
                        cond_params={'subcooling': subcool}
                    )
                    ch.calculate_cycle()
                    lift = T_cib - T_src
                    COP_carnot = (T_cib + 273.15) / lift
                    resultats.append({
                        'T_source (degC)': T_src,
                        'T_cible (degC)': T_cib,
                        'Lift (K)': lift,
                        'COP': round(ch.COP, 2),
                        'EER': round(ch.EER, 2),
                        'COP Carnot': round(COP_carnot, 2),
                        'Eta Carnot (%)': round(ch.COP / COP_carnot * 100, 1),
                        'W_comp (kW)': round(ch.COMP.Q_comp / 1000, 1),
                        'Q_cond (kW)': round(ch.Q_condTot / 1000, 1),
                    })
                except Exception:
                    pass

        df = pd.DataFrame(resultats)

        if not df.empty and save_fig is not None:
            # Graphique COP vs Lift pour chaque T_source
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

            for T_src in sorted(df['T_source (degC)'].unique()):
                sub = df[df['T_source (degC)'] == T_src]
                ax1.plot(sub['Lift (K)'], sub['COP'], 'o-', label=f'T_src={T_src} degC')
                ax2.plot(sub['T_cible (degC)'], sub['W_comp (kW)'], 's-',
                         label=f'T_src={T_src} degC')

            ax1.set_xlabel('Lift thermique (K)')
            ax1.set_ylabel('COP chauffage')
            ax1.set_title('COP PAC vs Lift thermique')
            ax1.grid(True, alpha=0.3)
            ax1.legend()

            ax2.set_xlabel('Temperature cible (degC)')
            ax2.set_ylabel('Puissance compresseur (kW)')
            ax2.set_title('Consommation electrique vs Temperature')
            ax2.grid(True, alpha=0.3)
            ax2.legend()

            fig.tight_layout()
            fig.savefig(save_fig, dpi=150)
            plt.show()

        return df

    def plot(self, figsize=(10, 6)):
        chart = Temperature_Entropy_Chart.Object(self.fluid)
        chart.add_points(self.points)
        chart.show(draw_arrows=True, figsize=figsize)

    # Alias pour compatibilite
    plot_TS_diagram = plot


