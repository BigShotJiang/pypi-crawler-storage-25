import pvlib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

class SolarSystem:
    def __init__(self, latitude, longitude, name, altitude, timezone, azimut, inclinaison):
        self.latitude = latitude
        self.longitude = longitude
        self.name = name
        self.altitude = altitude
        self.timezone = timezone
        self.azimut = azimut
        self.inclinaison = inclinaison
        self.weather = None
        self.module = None
        self.inverter = None
        self.temperature_model_parameters = None
        self.system = None
        self.solpos = None
        self.dni_extra = None
        self.airmass = None
        self.pressure = None
        self.am_abs = None
        self.aoi = None
        self.total_irradiance = None
        self.cell_temperature = None
        self.effective_irradiance = None
        self.dc = None
        self.ac = None
        self.annual_energy = None
        self.df = None

    def retrieve_module_inverter_data(self,
            module_name='Canadian_Solar_CS5P_220M___2009_',
            inverter_name='ABB__MICRO_0_25_I_OUTD_US_208__208V_',
            temperature_model='open_rack_glass_glass'):
        sandia_modules = pvlib.pvsystem.retrieve_sam('SandiaMod')
        sapm_inverters = pvlib.pvsystem.retrieve_sam('cecinverter')
        self.module = sandia_modules[module_name]
        self.inverter = sapm_inverters[inverter_name]
        self.temperature_model_parameters = pvlib.temperature.TEMPERATURE_MODEL_PARAMETERS['sapm'][temperature_model]

    def retrieve_weather_data(self):
        # Récupération des données météorologiques TMY à partir de PVGIS pour l'emplacement spécifié
        weather = pvlib.iotools.get_pvgis_tmy(self.latitude, self.longitude, map_variables=True)[0]
        weather.index.name = "utc_time"  # Définition du nom de l'index des données météorologiques
        self.weather = weather
        #print("Données météorologiques typiques :", self.weather)

    def calculate_solar_parameters(self):
        if self.weather is None:
            self.retrieve_weather_data()
        self.system = {'module': self.module, 'inverter': self.inverter, 'surface_azimuth': self.azimut}
        # Définition de l'inclinaison de la surface du système solaire
        self.system['surface_tilt'] = self.inclinaison
        # Calcul de la position solaire
        self.solpos = pvlib.solarposition.get_solarposition(
            time=self.weather.index,
            latitude=self.latitude,
            longitude=self.longitude,
            altitude=self.altitude,
            temperature=self.weather["temp_air"],
            pressure=pvlib.atmosphere.alt2pres(self.altitude),
        )
        #print("position du soleil===", self.solpos)
        # Calcul du rayonnement solaire supplémentaire
        self.dni_extra = pvlib.irradiance.get_extra_radiation(self.weather.index)
        #print("rayonnement solaire suplémentaire", self.dni_extra)
        # Calcul de la masse d'air relative
        self.airmass = pvlib.atmosphere.get_relative_airmass(self.solpos['apparent_zenith'])
        #print("masse d'air relative", self.airmass)
        # Calcul de la pression atmosphérique
        self.pressure = pvlib.atmosphere.alt2pres(self.altitude)
        #print("pression atm", self.pressure)
        # Calcul de la masse d'air absolue
        self.am_abs = pvlib.atmosphere.get_absolute_airmass(self.airmass, self.pressure)
        #print("masse d'air absolue", self.am_abs)
        # Calcul de l'angle d'incidence
        self.aoi = pvlib.irradiance.aoi(
            self.system['surface_tilt'],
            self.system['surface_azimuth'],
            self.solpos["apparent_zenith"],
            self.solpos["azimuth"],
        )
        #print("angle d'incidence", self.aoi)
        # Calcul du rayonnement solaire total
        self.total_irradiance = pvlib.irradiance.get_total_irradiance(
            self.system['surface_tilt'],
            self.system['surface_azimuth'],
            self.solpos['apparent_zenith'],
            self.solpos['azimuth'],
            self.weather['dni'],
            self.weather['ghi'],
            self.weather['dhi'],
            dni_extra=self.dni_extra,
            model='haydavies',
        )
        #print("rayonnement solaire total", self.total_irradiance)
        # Calcul de la température des cellules solaires
        self.cell_temperature = pvlib.temperature.sapm_cell(
            self.total_irradiance['poa_global'],
            self.weather["temp_air"],
            self.weather["wind_speed"],
            **self.temperature_model_parameters,
        )
        #print("température des cellules solaires", self.cell_temperature)
        # Calcul du rayonnement solaire effectif
        self.effective_irradiance = pvlib.pvsystem.sapm_effective_irradiance(
            self.total_irradiance['poa_direct'],
            self.total_irradiance['poa_diffuse'],
            self.am_abs,
            self.aoi,
            self.module,
        )
        #print("rayonnement solaire effectif", self.effective_irradiance)
        # Calcul de la puissance CC (courant continu)
        self.dc = pvlib.pvsystem.sapm(self.effective_irradiance, self.cell_temperature, self.module)
        #print("puissance CC", self.dc)
        # Calcul de la puissance CA (courant alternatif)
        self.ac = pvlib.inverter.sandia(self.dc['v_mp'], self.dc['p_mp'], self.inverter)
        #print("puissance CA (courant alternatif)", self.ac)
        # Calcul de l'énergie annuelle
        self.annual_energy = self.ac.sum()

        module_area = self.module['Area'] if self.module is not None else 0
        module_wc = self.module['Impo'] * self.module['Vmpo'] if self.module is not None else 0
        prod_kwh = self.annual_energy / 1000

        self.df = pd.DataFrame({'SolarSystem': [
            self.name,
            f"{self.latitude:.3f}",
            f"{self.longitude:.3f}",
            f"{self.azimut}",
            f"{self.inclinaison}",
            self.module.name if self.module is not None else "N/A",
            f"{module_area:.3f}",
            f"{module_wc:.1f}",
            self.inverter.name if self.inverter is not None else "N/A",
            f"{prod_kwh:.1f}",
            f"{prod_kwh / (module_wc / 1000):.0f}" if module_wc > 0 else "N/A",
        ]}, index=[
            'Site', 'Latitude (deg)', 'Longitude (deg)',
            'Azimut (deg)', 'Inclinaison (deg)',
            'Module', 'Surface module (m2)', 'Puissance STC (Wc)',
            'Onduleur',
            'Production / module (kWh/an)',
            'Productivite (kWh/kWc/an)',
        ])

    def summary(self, nb_modules=1, module_wc=None,
                capex_eur_m2=None, opex_eur_m2=None,
                tarif_elec_eur_mwh=None, duree_vie=25):
        """Retourne un DataFrame de synthese technique et economique.

        Parameters
        ----------
        nb_modules : int
            Nombre de modules dans l'installation.
        module_wc : float or None
            Puissance crete d'un module en Wc.
        capex_eur_m2 : float or None
            Cout d'investissement par m2 de panneau installe (EUR/m2).
            Si None, pas d'analyse economique.
        opex_eur_m2 : float or None
            Cout d'exploitation annuel par m2 (EUR/m2/an).
        tarif_elec_eur_mwh : float or None
            Prix de l'electricite valorisee (EUR/MWh).
        duree_vie : int
            Duree de vie du projet en annees (defaut 25 ans).
        """
        if module_wc is None:
            module_wc = self.module['Impo'] * self.module['Vmpo']

        prod_module_kwh = self.annual_energy / 1000
        productivite = prod_module_kwh / (module_wc / 1000)
        puissance_kwc = nb_modules * module_wc / 1000
        prod_totale_mwh = prod_module_kwh * nb_modules / 1000
        module_area = self.module['Area'] if self.module is not None else 1.65
        surface_m2 = nb_modules * module_area

        rows = [
            ("--- SIMULATION ---", ""),
            ("Site", self.name),
            ("Module", self.module.name if self.module is not None else "N/A"),
            ("Surface module", f"{module_area:.3f} m2"),
            ("Nb modules", nb_modules),
            ("Puissance crete", f"{puissance_kwc:.1f} kWc"),
            ("Surface capteurs", f"{surface_m2:.0f} m2"),
            ("Production / module", f"{prod_module_kwh:.1f} kWh/an"),
            ("Productivite specifique", f"{productivite:.0f} kWh/kWc/an"),
            ("Production totale", f"{prod_totale_mwh:.1f} MWh/an"),
        ]

        if all(v is not None for v in [capex_eur_m2, opex_eur_m2,
                                        tarif_elec_eur_mwh]):
            capex = surface_m2 * capex_eur_m2
            opex = surface_m2 * opex_eur_m2
            valorisation = prod_totale_mwh * tarif_elec_eur_mwh
            gain_net = valorisation - opex
            payback = capex / gain_net if gain_net > 0 else np.inf
            roi = ((gain_net * duree_vie - capex) / capex * 100) if capex > 0 else 0

            # TRI : taux r tel que sum(gain_net/(1+r)^t, t=1..N) = capex
            tri = 0.0
            if gain_net > 0 and capex > 0:
                from scipy.optimize import brentq
                def npv(r):
                    return sum(gain_net / (1 + r) ** t
                               for t in range(1, duree_vie + 1)) - capex
                try:
                    tri = brentq(npv, -0.5, 5.0) * 100
                except Exception:
                    tri = 0.0

            rows += [
                ("--- HYPOTHESES ECO ---", ""),
                ("CAPEX", f"{capex_eur_m2} EUR/m2"),
                ("OPEX", f"{opex_eur_m2} EUR/m2/an"),
                ("Tarif electricite", f"{tarif_elec_eur_mwh} EUR/MWh"),
                ("Duree de vie", f"{duree_vie} ans"),
                ("--- RESULTATS ECO ---", ""),
                ("Investissement", f"{capex/1000:.0f} kEUR"),
                ("Valorisation annuelle", f"{valorisation/1000:.1f} kEUR/an"),
                ("OPEX annuel", f"{opex/1000:.1f} kEUR/an"),
                ("Gain net annuel", f"{gain_net/1000:.1f} kEUR/an"),
                ("Payback", f"{payback:.1f} ans"),
                ("ROI ({0} ans)".format(duree_vie), f"{roi:.0f} %"),
                ("TRI", f"{tri:.1f} %"),
            ]

        return pd.DataFrame(rows, columns=["Indicateur", "Valeur"])

    def plot(self, figsize=(14, 5), nb_modules=1):
        """Trace la production horaire AC et le profil mensuel."""
        ac_kw = self.ac * nb_modules / 1000

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=figsize)

        ax1.plot(ac_kw.values, linewidth=0.3)
        ax1.set_xlabel('Heure de l\'annee')
        ax1.set_ylabel('Production AC (kW)')
        ax1.set_title(f'{self.name} - Production horaire ({nb_modules} modules)')
        ax1.grid(True, alpha=0.3)

        monthly = ac_kw.resample('ME').sum()
        total_mwh = abs(ac_kw.sum()) / 1000
        ax2.bar(range(len(monthly)), monthly.values, color='orange')
        ax2.set_xticks(range(len(monthly)))
        ax2.set_xticklabels(['J','F','M','A','M','J','J','A','S','O','N','D'][:len(monthly)])
        ax2.set_ylabel('Production mensuelle (kWh)')
        ax2.set_title(f'{self.name} - Profil mensuel | Total : {total_mwh:.1f} MWh/an')
        ax2.grid(axis='y', alpha=0.3)

        plt.tight_layout()
        plt.show()
        return fig

    def to_excel(self, filename=None, nb_modules=1):
        """Exporte la production horaire en fichier Excel.

        Parameters
        ----------
        filename : str or None
            Chemin du fichier. Si None, genere '{name}_production.xlsx'.
        nb_modules : int
            Nombre de modules (defaut 1).

        Returns
        -------
        str
            Chemin du fichier cree.
        """
        if filename is None:
            filename = f"{self.name.replace(' ', '_')}_production.xlsx"

        df_export = pd.DataFrame({
            'Production_AC_kW': self.ac * nb_modules / 1000,
            'Irradiance_POA_W_m2': self.total_irradiance['poa_global'],
            'T_cellule_C': self.cell_temperature,
            'T_air_C': self.weather['temp_air'],
        })
        df_export.index.name = 'datetime_utc'

        with pd.ExcelWriter(filename, engine='openpyxl') as writer:
            df_export.to_excel(writer, sheet_name='Horaire')
            df_export.resample('ME').sum().to_excel(writer, sheet_name='Mensuel')
            self.df.to_excel(writer, sheet_name='Synthese')

        print(f"Export : {filename}")
        return filename

    def plot_annual_energy(self):
        energies = pd.Series({self.name: self.annual_energy})
        energies.plot(kind='bar', rot=0)
        plt.ylabel('Rendement energetique annuel (Wh)')

    @staticmethod
    def orientation_study(latitude, longitude, name, altitude, timezone,
                          scenarios):
        """Etude parametrique d'orientation et d'inclinaison.

        Parameters
        ----------
        latitude, longitude, name, altitude, timezone :
            Parametres du site (identiques a __init__).
        scenarios : list[dict]
            Liste de dicts avec cles 'nom', 'azimut', 'inclinaison'.

        Returns
        -------
        df : pd.DataFrame
            Tableau comparatif trie par production decroissante.
        df_monthly : pd.DataFrame
            Production mensuelle (kWh/kWc) par scenario (colonnes)
            et par mois (index).
        """
        resultats = []
        monthly_data = {}
        for sc in scenarios:
            pv = SolarSystem(
                latitude=latitude, longitude=longitude,
                name=sc['nom'], altitude=altitude,
                timezone=timezone,
                azimut=sc['azimut'], inclinaison=sc['inclinaison']
            )
            pv.retrieve_module_inverter_data()
            pv.calculate_solar_parameters()

            module_wc = pv.module['Impo'] * pv.module['Vmpo']
            ac_kwh_kwc = pv.ac / module_wc
            monthly = ac_kwh_kwc.resample('ME').sum()
            monthly.index = range(1, len(monthly) + 1)
            monthly_data[sc['nom']] = monthly

            prod_kwh_kwc = pv.annual_energy / 1000 / (module_wc / 1000)
            resultats.append({
                'Configuration': sc['nom'],
                'Azimut (deg)': sc['azimut'],
                'Inclinaison (deg)': sc['inclinaison'],
                'Production (kWh/kWc/an)': round(prod_kwh_kwc, 1),
            })

        df = pd.DataFrame(resultats)
        prod_max = df['Production (kWh/kWc/an)'].max()
        df['Ecart vs Optimal (%)'] = (
            (df['Production (kWh/kWc/an)'] - prod_max) / prod_max * 100
        ).round(1)
        df = df.sort_values('Production (kWh/kWc/an)', ascending=False)
        df = df.reset_index(drop=True)

        df_monthly = pd.DataFrame(monthly_data)
        return df, df_monthly

    @staticmethod
    def plot_orientation_study(df, df_monthly, name='', save_fig=None):
        """Trace les profils mensuels par orientation.

        Parameters
        ----------
        df : pd.DataFrame
            Resultat de orientation_study() (tableau annuel).
        df_monthly : pd.DataFrame
            Profils mensuels par scenario.
        name : str
            Nom du site (pour le titre).
        save_fig : str or None
            Chemin fichier image. Si None, pas de sauvegarde.
        """
        fig, ax = plt.subplots(figsize=(12, 6))
        mois_labels = ['Jan','Fev','Mar','Avr','Mai','Jun',
                       'Jul','Aou','Sep','Oct','Nov','Dec']
        totaux = df.set_index('Configuration')['Production (kWh/kWc/an)']
        for col in df_monthly.columns:
            total = totaux.get(col, df_monthly[col].sum())
            ax.plot(df_monthly.index, df_monthly[col], 'o-',
                    linewidth=1.5, markersize=4,
                    label=f'{col} ({total:.0f} kWh/kWc/an)')
        ax.set_xticks(range(1, len(df_monthly) + 1))
        ax.set_xticklabels(mois_labels[:len(df_monthly)])
        ax.set_xlabel('Mois')
        ax.set_ylabel('Production mensuelle (kWh/kWc)')
        ax.set_title(f'Profil mensuel par orientation - {name}')
        ax.legend(fontsize=11)
        ax.grid(True, alpha=0.3)
        fig.tight_layout()
        if save_fig:
            fig.savefig(save_fig, dpi=150)
        plt.show()
        return fig