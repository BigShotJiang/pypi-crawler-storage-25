from datetime import date
import json
import os
from dateutil.parser import parse
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from Facture.df_utils import add_row, build_section_df, format_number

current_directory = os.path.dirname(os.path.abspath(__file__))
coefficients_file_path = os.path.join(current_directory, 'coefficients_sonalgaz_elec.json')

class input_Facture:
    def __init__(self, start, end, 
                 kWh_pointe=0, kWh_pleine=0, kWh_jour=0, 
                 kWh_nuit=0, kWh_hors_pointe=0, kWh_poste_unique=0,
                 cadran_1_kWh=None, cadran_2_kWh=None, cadran_3_kWh=None,
                 kvarh_reactif=0,
                 PMA_kW=0,
                 taxe_produits_energetiques_cDA_kWh=0):  # Taxe vente produits énergétiques
        if not isinstance(start, date):
            start = parse(start).date()
        if not isinstance(end, date):
            end = parse(end).date()
        
        self.start = start
        self.end = end
        self.kWh_pointe = kWh_pointe
        self.kWh_pleine = kWh_pleine
        self.kWh_jour = kWh_jour
        self.kWh_nuit = kWh_nuit
        self.kWh_hors_pointe = kWh_hors_pointe
        self.kWh_poste_unique = kWh_poste_unique
        self.cadran_1_kWh = cadran_1_kWh
        self.cadran_2_kWh = cadran_2_kWh
        self.cadran_3_kWh = cadran_3_kWh
        self.kvarh_reactif = kvarh_reactif
        self.PMA_kW = PMA_kW
        self.taxe_produits_energetiques_cDA_kWh = taxe_produits_energetiques_cDA_kWh

class input_Contrat:
    def __init__(self, code_tarif="41", PMD_kW=0):
        self.code_tarif = code_tarif
        self.PMD_kW = PMD_kW
        # La tension sera déterminée automatiquement dans get_coefficients

class Sonalgaz_Elec:
    DEFAULT_TAXE_PRODUITS_ENERGETIQUES_CDA_KWH_HTA = 3
    SUPPORTED_HTA_CODES = ("41", "42", "43", "44")

    def __init__(self, contrat, facture):
        self.contrat = contrat
        self.facture = facture
        self.coefficients = None
        self.nb_jours = (self.facture.end - self.facture.start).days + 1
        
        # Montants calculés
        self.montant_fixe = 0
        self.montant_PMD = 0
        self.montant_PMA = 0
        self.montant_energie = 0
        self.montant_reactif = 0
        self.montant_total = 0
        self.montant_tva = 0
        self.montant_total_ttc = 0
        self.montant_taxe_produits_energetiques = 0
        self.montant_total_facture = 0
        self.simulation_tarifs_result = None
        
        # DataFrame pour le résumé
        self.df = pd.DataFrame(columns=["Composante", "Montant (DA)"])

    def get_coefficients(self):
        """Récupère les coefficients selon le code tarif."""
        with open(coefficients_file_path, 'r') as f:
            data = json.load(f)
            
        for coef in data["coefficients"]:
            if (coef["code_tarif"] == self.contrat.code_tarif and
                parse(coef["date_debut"]).date() <= self.facture.start <= parse(coef["date_fin"]).date()):
                # Détermine la tension à partir du code tarif trouvé
                self.contrat.tension = coef["tension"]
                self.coefficients = coef  # Stocke les coefficients
                return coef
                
        raise ValueError(f"Aucun coefficient trouvé pour le code tarif {self.contrat.code_tarif}")

    def calculate(self, include_simulation=True):
        """Calcule tous les éléments de la facture selon le niveau de tension."""
        # Si les 3 cadrans sont renseignés pour un code HTA 41/42/43/44,
        # on applique le mapping automatiquement au tarif saisi.
        if self._has_three_cadrans(self.facture) and str(self.contrat.code_tarif) in self.SUPPORTED_HTA_CODES:
            self._apply_cadrans_to_current_tariff()

        coef = self.get_coefficients()
        tension = coef["tension"]  # Récupère la tension depuis les coefficients
        
        if tension == "BT":
            self._calculate_BT(coef)
        elif tension in ["HTA", "HTB"]:
            self._calculate_HT(tension, coef)
        else:
            raise ValueError(f"Niveau de tension non reconnu : {tension}")

        # Simulation comparative multi-tarifs uniquement pour HTA sur 3 cadrans,
        # sans perturber les objets internes créés pendant la simulation.
        if (
            include_simulation
            and tension == "HTA"
            and str(self.contrat.code_tarif) in self.SUPPORTED_HTA_CODES
            and self._has_three_cadrans(self.facture)
        ):
            self.simulation_tarifs_result = self.simulate_hta_tariffs_from_cadrans(
                tarif_reference=str(self.contrat.code_tarif),
                include_simulation=False,
            )
            self._append_simulation_to_summary_df()

    def _calculate_BT(self, coef):
        """Calcul spécifique pour la Basse Tension."""
        # 1. Redevance Fixe (trimestrielle)
        self.montant_fixe = coef["fixe_DA_mois"] * 3  # Trimestre

        # 2. Facturation PMD
        self.montant_PMD = coef["souscription_DA_kW_mois"] * self.contrat.PMD_kW * 3  # Trimestre

        # 3. Energie Active selon code tarif
        if self.contrat.code_tarif in ["51M", "51NM", "52M", "52NM", "53M", "53NM"]:
            # Calcul par poste horaire
            self.montant_energie = (
                coef["point_cDA_kWh"]/100 * self.facture.kWh_pointe +
                coef["Pleine_cDA_kWh"]/100 * self.facture.kWh_pleine +
                coef["jour_cDA_kWh"]/100 * self.facture.kWh_jour +
                coef["hors_pointe_cDA_kWh"]/100 * self.facture.kWh_hors_pointe +
                coef["Nuit_cDA_kWh"]/100 * self.facture.kWh_nuit +
                coef["Poste_unique_cDA_kWh"]/100 * self.facture.kWh_poste_unique
            )
        elif self.contrat.code_tarif in ["54M", "54NM"]:
            # Calcul par tranches
            energie_mensuelle = self.facture.kWh_poste_unique / 3  # moyenne mensuelle
            self.montant_energie = self._calculate_tranches(energie_mensuelle, coef) * 3

        # 4. Total trimestriel
        self.montant_total = (
            self.montant_fixe +
            self.montant_PMD +
            self.montant_energie
        )

        # Taxe sur vente de produits énergétiques (hors HTVA)
        self.montant_taxe_produits_energetiques = self._calculate_taxe_produits_energetiques()

        # TVA (19% sur HTVA)
        self.montant_tva = self.montant_total * 0.19
        self.montant_total_ttc = self.montant_total + self.montant_tva
        self.montant_total_facture = self.montant_total_ttc + self.montant_taxe_produits_energetiques

        # Mise à jour du DataFrame de résumé
        self._update_dataframe()

    def _calculate_HT(self, niveau, coef):
        """Calcul spécifique pour la Haute et Très Haute Tension (HTA/HTB)."""
        # 1. Redevance Fixe
        self.montant_fixe = coef["fixe_DA_mois"]
        
        # 2. Facturation PMD (Puissance Mise à Disposition)
        self.montant_PMD = coef["souscription_DA_kW_mois"] * self.contrat.PMD_kW
        
        # 3. Facturation PMA (Puissance Maximale Absorbée)
        self.montant_PMA = coef["absorbee_DA_kW_mois"] * self.facture.PMA_kW
        
        # 4. Energie Active selon le code tarif
        self.montant_energie = 0
        if niveau == "HTB" and self.contrat.code_tarif == "31":
            self.montant_energie = (
                coef["point_cDA_kWh"]/100 * self.facture.kWh_pointe +
                coef["Pleine_cDA_kWh"]/100 * self.facture.kWh_pleine +
                coef["Nuit_cDA_kWh"]/100 * self.facture.kWh_nuit
            )
        elif niveau == "HTB" and self.contrat.code_tarif == "32":
            self.montant_energie = coef["Poste_unique_cDA_kWh"]/100 * self.facture.kWh_poste_unique
        elif niveau == "HTA":
            self.montant_energie = (
                coef["point_cDA_kWh"]/100 * self.facture.kWh_pointe +
                coef["Pleine_cDA_kWh"]/100 * self.facture.kWh_pleine +
                coef["jour_cDA_kWh"]/100 * self.facture.kWh_jour +
                coef["hors_pointe_cDA_kWh"]/100 * self.facture.kWh_hors_pointe +
                coef["Nuit_cDA_kWh"]/100 * self.facture.kWh_nuit +
                coef["Poste_unique_cDA_kWh"]/100 * self.facture.kWh_poste_unique
            )

        # 5. Energie Réactive (uniquement pour HTA et HTB)
        energie_totale = (
            self.facture.kWh_pointe +
            self.facture.kWh_pleine +
            self.facture.kWh_jour +
            self.facture.kWh_nuit +
            self.facture.kWh_hors_pointe +
            self.facture.kWh_poste_unique
        )
        
        # Calcul du seuil de dépassement (50% de l'énergie active)
        seuil_reactif = 0.5 * energie_totale
        
        # Calcul du dépassement ou du non-dépassement
        depassement = self.facture.kvarh_reactif - seuil_reactif
        print(f"dépassement réactif : {depassement} kvarh (seuil : {seuil_reactif} kvarh)")
        
        # Application du tarif selon dépassement ou non
        if depassement > 0:
            # Malus sur le dépassement
            self.montant_reactif = depassement * coef["reactive_malus_cDA_kvarh"]/100
        else:
            # Bonus sur l'énergie réactive en dessous du seuil
            self.montant_reactif = depassement * coef["reactive_bonus_cDA_kvarh"]/100

        # 6. Total
        self.montant_total = (
            self.montant_fixe +
            self.montant_PMD +
            self.montant_PMA +
            self.montant_energie +
            self.montant_reactif
        )

        # Calcul de la TVA (19% sur l'énergie HT)
        self.montant_tva = self.montant_total * 0.19

        # Taxe sur vente de produits énergétiques (hors HTVA)
        self.montant_taxe_produits_energetiques = self._calculate_taxe_produits_energetiques()
        
        # Calcul du total TTC
        self.montant_total_ttc = self.montant_total + self.montant_tva
        self.montant_total_facture = self.montant_total_ttc + self.montant_taxe_produits_energetiques

        # Mise à jour du DataFrame
        periode = "mois"
        self._update_dataframe(periode)

    def _update_dataframe(self, periode="mois"):
        """Mise à jour du DataFrame avec les résultats."""
        # Calcul des énergies totales en MWh/Mvarh
        energie_active_MWh = (
            self.facture.kWh_pointe +
            self.facture.kWh_pleine +
            self.facture.kWh_jour +
            self.facture.kWh_nuit +
            self.facture.kWh_hors_pointe +
            self.facture.kWh_poste_unique
        ) / 1000  # Conversion en MWh
        
        energie_reactive_Mvarh = self.facture.kvarh_reactif / 1000  # Conversion en Mvarh
        
        # Début du DataFrame avec les consommations
        composantes = [
            ("Energie Active totale (MWh)", f"{energie_active_MWh:,.2f}"),
            ("Energie Réactive totale (Mvarh)", f"{energie_reactive_Mvarh:,.2f}"),
            ("", "")  # Ligne vide pour la séparation
        ]
        
        # Reste des composantes
        composantes.extend([
            (f"Redevance Fixe (DA/{periode})", f"{self.montant_fixe:,.2f}"),
            (f"PMD-Puissance mise à disposition (DA/{periode})", f"{self.montant_PMD:,.2f}")
        ])
        
        if self.contrat.tension in ["HTA", "HTB"]:
            composantes.extend([
                (f"PMA-Puissance maximale atteinte (DA/{periode})", f"{self.montant_PMA:,.2f}")
            ])
            
            # Détail de l'énergie active selon le niveau de tension et code tarif
            coef = self.coefficients
            if self.contrat.tension == "HTB" and self.contrat.code_tarif == "31":
                for poste, kWh in [
                    ("Pointe", self.facture.kWh_pointe),
                    ("Pleine", self.facture.kWh_pleine),
                    ("Nuit", self.facture.kWh_nuit)
                ]:
                    if kWh > 0:
                        montant = coef[f'{poste.lower()}_cDA_kWh' if poste == "Nuit" 
                                     else f'{"point" if poste == "Pointe" else poste.lower()}_cDA_kWh']/100 * kWh
                        composantes.append((f"Energie {poste} (DA/mois)", f"{montant:,.2f}"))
                        
            elif self.contrat.tension == "HTB" and self.contrat.code_tarif == "32":
                if self.facture.kWh_poste_unique > 0:
                    montant = coef['Poste_unique_cDA_kWh']/100 * self.facture.kWh_poste_unique
                    composantes.append(("Energie Poste Unique (DA/mois)", f"{montant:,.2f}"))
                    
            elif self.contrat.tension == "HTA":
                # Mapping des postes horaires selon le code tarif
                postes_tarif = {
                    "41": ["Pointe", "Pleine", "Jour", "Hors Pointe", "Nuit", "Poste Unique"],
                    "42": ["Pointe", "Hors Pointe"],  # Uniquement Pointe et Hors Pointe
                    "43": ["Pointe", "Jour", "Nuit"],
                    "44": ["Poste Unique"]
                }
                
                mapping_coef = {
                    "Pointe": ("point_cDA_kWh", "kWh_pointe"),
                    "Pleine": ("Pleine_cDA_kWh", "kWh_pleine"),
                    "Jour": ("jour_cDA_kWh", "kWh_jour"),
                    "Hors Pointe": ("hors_pointe_cDA_kWh", "kWh_hors_pointe"),
                    "Nuit": ("Nuit_cDA_kWh", "kWh_nuit"),
                    "Poste Unique": ("Poste_unique_cDA_kWh", "kWh_poste_unique")
                }
                
                for poste in postes_tarif.get(self.contrat.code_tarif, []):
                    coef_name, attr_name = mapping_coef[poste]
                    kWh = getattr(self.facture, attr_name)
                    if kWh > 0:
                        montant = coef[coef_name]/100 * kWh
                        composantes.append((f"Energie {poste} (DA/mois)", f"{montant:,.2f}"))
            
            if self.montant_reactif != 0:
                composantes.extend([
                    (f"Energie Réactive (DA/{periode})", f"{self.montant_reactif:,.2f}")
                ])
        
        # Calcul du prix moyen par MWh
        energie_totale_MWh = (
            self.facture.kWh_pointe +
            self.facture.kWh_pleine +
            self.facture.kWh_jour +
            self.facture.kWh_nuit +
            self.facture.kWh_hors_pointe +
            self.facture.kWh_poste_unique
        ) / 1000  # Conversion en MWh
        
        prix_moyen_MWh = self.montant_total / energie_totale_MWh if energie_totale_MWh > 0 else 0
       
        composantes.extend([
            (f"Energie Active Total (DA/{periode})", f"{self.montant_energie:,.2f}"),
            (f"Prix moyen énergie active (DA HTVA/MWh)", f"{prix_moyen_MWh:,.2f}"),
            (f"Total HTVA (DA/{periode})", f"{self.montant_total:,.2f}"),
            (f"TVA 19% (DA/{periode})", f"{self.montant_tva:,.2f}"),
            (f"Total TTC (DA/{periode})", f"{self.montant_total_ttc:,.2f}")
        ])

        if self.montant_taxe_produits_energetiques:
            composantes.extend([
                (f"Taxe vente produits énergétiques (DA/{periode})", f"{self.montant_taxe_produits_energetiques:,.2f}"),
                (f"Total Facture (DA/{periode})", f"{self.montant_total_facture:,.2f}")
            ])
        
        self.df = pd.DataFrame(composantes, columns=["Composante", "Montant (DA)"])
        pd.set_option('display.float_format', lambda x: '{:,.2f}'.format(x))

        # --- DataFrames auditables (Option B) ---
        self._build_df_sections(periode)

    def _build_df_sections(self, periode="mois"):
        """Construire les DataFrames auditables avec formules."""
        coef = self.coefficients

        # df_contrat
        rows = []
        add_row(rows, "Code tarif", entrees=self.contrat.code_tarif)
        add_row(rows, "Tension", entrees=self.contrat.tension)
        add_row(rows, "PMD (kW)", entrees=format_number(self.contrat.PMD_kW, 0, "kW"))
        if hasattr(self.facture, "PMA_kW") and self.facture.PMA_kW:
            add_row(rows, "PMA (kW)", entrees=format_number(self.facture.PMA_kW, 0, "kW"))
        add_row(rows, "Période", entrees="{} au {}".format(self.facture.start, self.facture.end))
        kWh_total = (self.facture.kWh_pointe + self.facture.kWh_pleine + self.facture.kWh_jour
                     + self.facture.kWh_nuit + self.facture.kWh_hors_pointe + self.facture.kWh_poste_unique)
        add_row(rows, "Énergie active totale", entrees=format_number(kWh_total, 0, "kWh"),
                formule="Somme postes")
        if self.facture.kvarh_reactif:
            add_row(rows, "Énergie réactive", entrees=format_number(self.facture.kvarh_reactif, 0, "kvarh"))
        self.df_contrat = build_section_df(rows)

        # df_fourniture
        rows = []
        add_row(rows, "Redevance fixe",
                formule="fixe_DA_{}".format(periode),
                coefficient=format_number(coef.get("fixe_DA_mois", 0), 2, "DA/{}".format(periode)),
                resultat=self.montant_fixe)
        add_row(rows, "PMD (puissance souscrite)",
                formule="PMD x souscription",
                entrees=format_number(self.contrat.PMD_kW, 0, "kW"),
                coefficient=format_number(coef.get("souscription_DA_kW_mois", 0), 4, "DA/kW/{}".format(periode)),
                resultat=self.montant_PMD)
        if self.contrat.tension in ["HTA", "HTB"] and self.facture.PMA_kW:
            add_row(rows, "PMA (puissance max atteinte)",
                    formule="PMA x absorbée",
                    entrees=format_number(self.facture.PMA_kW, 0, "kW"),
                    coefficient=format_number(coef.get("absorbee_DA_kW_mois", 0), 4, "DA/kW/{}".format(periode)),
                    resultat=self.montant_PMA)

        # Énergie active par poste
        mapping_coef = {
            "Pointe": ("point_cDA_kWh", self.facture.kWh_pointe),
            "Pleine": ("Pleine_cDA_kWh", self.facture.kWh_pleine),
            "Jour": ("jour_cDA_kWh", self.facture.kWh_jour),
            "Nuit": ("Nuit_cDA_kWh", self.facture.kWh_nuit),
            "Hors Pointe": ("hors_pointe_cDA_kWh", self.facture.kWh_hors_pointe),
            "Poste Unique": ("Poste_unique_cDA_kWh", self.facture.kWh_poste_unique),
        }
        for poste, (coef_key, kwh) in mapping_coef.items():
            c_val = coef.get(coef_key, 0)
            if kwh and c_val:
                montant = round(c_val / 100 * kwh, 2)
                add_row(rows, "Énergie {}".format(poste),
                        formule="kWh x cDA/kWh / 100",
                        entrees=format_number(kwh, 0, "kWh"),
                        coefficient=format_number(c_val, 4, "cDA/kWh"),
                        resultat=montant)

        # Réactif
        if hasattr(self, "montant_reactif") and self.montant_reactif != 0:
            seuil = (self.facture.kWh_pointe + self.facture.kWh_pleine + self.facture.kWh_jour
                     + self.facture.kWh_nuit + self.facture.kWh_hors_pointe + self.facture.kWh_poste_unique) * 0.5
            label = "Réactif (malus)" if self.montant_reactif > 0 else "Réactif (bonus)"
            taux_key = "reactive_malus_cDA_kvarh" if self.montant_reactif > 0 else "reactive_bonus_cDA_kvarh"
            add_row(rows, label,
                    formule="(kvarh - seuil_50%) x taux / 100",
                    entrees=format_number(self.facture.kvarh_reactif, 0, "kvarh"),
                    coefficient=format_number(coef.get(taux_key, 0), 4, "cDA/kvarh"),
                    resultat=self.montant_reactif)

        add_row(rows, "= Total énergie active",
                formule="Somme postes",
                resultat=self.montant_energie)
        self.df_fourniture_detail = build_section_df(rows)

        # df_taxes
        rows = []
        add_row(rows, "TVA 19%",
                formule="Total_HT x 19%",
                entrees=format_number(self.montant_total, 2, "DA"),
                coefficient="19%",
                resultat=self.montant_tva)
        if self.montant_taxe_produits_energetiques:
            kWh_total_val = (self.facture.kWh_pointe + self.facture.kWh_pleine + self.facture.kWh_jour
                     + self.facture.kWh_nuit + self.facture.kWh_hors_pointe + self.facture.kWh_poste_unique)
            add_row(rows, "Taxe vente produits énergétiques",
                formule="kWh_total x cDA/kWh / 100",
                entrees=format_number(kWh_total_val, 0, "kWh"),
                coefficient=format_number(self.facture.taxe_produits_energetiques_cDA_kWh, 4, "cDA/kWh"),
                resultat=self.montant_taxe_produits_energetiques)
        self.df_taxes = build_section_df(rows)

        # df_totaux
        rows = []
        add_row(rows, "Total HTVA", resultat=self.montant_total)
        add_row(rows, "TVA", resultat=self.montant_tva)
        add_row(rows, "= Total TTC", formule="HTVA + TVA", resultat=self.montant_total_ttc)
        if self.montant_taxe_produits_energetiques:
            add_row(rows, "Taxe vente produits énergétiques", resultat=self.montant_taxe_produits_energetiques)
            add_row(rows, "= Total Facture", formule="Total TTC + taxe produits énergétiques",
                    resultat=self.montant_total_facture)
        kWh_total_val = (self.facture.kWh_pointe + self.facture.kWh_pleine + self.facture.kWh_jour
                         + self.facture.kWh_nuit + self.facture.kWh_hors_pointe + self.facture.kWh_poste_unique)
        if kWh_total_val > 0:
            add_row(rows, "Coût DA/MWh (HTVA)",
                    formule="Total_HT / MWh",
                    resultat=round(self.montant_total / (kWh_total_val / 1000), 2))
        self.df_totaux = build_section_df(rows)

    def _calculate_taxe_produits_energetiques(self):
        """Calcule la taxe sur vente de produits énergétiques à partir de l'énergie active."""
        taux_cda_kwh = getattr(self.facture, "taxe_produits_energetiques_cDA_kWh", 0) or 0
        if taux_cda_kwh <= 0 and getattr(self.contrat, "tension", None) == "HTA":
            taux_cda_kwh = self.DEFAULT_TAXE_PRODUITS_ENERGETIQUES_CDA_KWH_HTA
        if taux_cda_kwh <= 0:
            return 0
        kWh_total_val = (self.facture.kWh_pointe + self.facture.kWh_pleine + self.facture.kWh_jour
                         + self.facture.kWh_nuit + self.facture.kWh_hors_pointe + self.facture.kWh_poste_unique)
        return taux_cda_kwh / 100 * kWh_total_val

    def get_dataframes(self):
        """Retourne un dictionnaire de tous les DataFrames sections."""
        return {
            "df_contrat": getattr(self, "df_contrat", None),
            "df_fourniture_detail": getattr(self, "df_fourniture_detail", None),
            "df_taxes": getattr(self, "df_taxes", None),
            "df_totaux": getattr(self, "df_totaux", None),
        }

    @staticmethod
    def _has_three_cadrans(facture):
        """Retourne True si les 3 cadrans sont tous renseignés."""
        return all(
            getattr(facture, attr, None) is not None
            for attr in ("cadran_1_kWh", "cadran_2_kWh", "cadran_3_kWh")
        )

    def _apply_cadrans_to_current_tariff(self):
        """Applique les 3 cadrans au tarif courant en remplissant les postes utiles."""
        postes = self._map_cadrans_to_postes(
            str(self.contrat.code_tarif),
            self.facture.cadran_1_kWh,
            self.facture.cadran_2_kWh,
            self.facture.cadran_3_kWh,
        )
        self.facture.kWh_pointe = postes["kWh_pointe"]
        self.facture.kWh_pleine = postes["kWh_pleine"]
        self.facture.kWh_jour = postes["kWh_jour"]
        self.facture.kWh_nuit = postes["kWh_nuit"]
        self.facture.kWh_hors_pointe = postes["kWh_hors_pointe"]
        self.facture.kWh_poste_unique = postes["kWh_poste_unique"]

    def _append_simulation_to_summary_df(self):
        """Ajoute les scénarios multi-tarifs à la table de sortie principale."""
        if not self.simulation_tarifs_result:
            return

        sims = self.simulation_tarifs_result["simulations"]
        tarif_ref = self.simulation_tarifs_result["tarif_reference"]
        best = self.simulation_tarifs_result["tarif_optimal"]
        gain_da = self.simulation_tarifs_result["gain_DA"]
        gain_pct = self.simulation_tarifs_result["gain_pct"]

        rows = [
            ("", ""),
            ("Scenarios autres tarifs HTA (3 cadrans)", ""),
        ]
        for code in self.SUPPORTED_HTA_CODES:
            rows.append(
                (f"Scenario T{code} - Total Facture (DA/mois)", f"{sims[code]['montant_total_facture']:,.2f}")
            )

        rows.extend(
            [
                ("Tarif de reference", f"T{tarif_ref}"),
                ("Tarif recommande (minimum facture)", f"T{best}"),
                ("Gain potentiel (DA/mois)", f"{gain_da:,.2f}"),
                ("Gain potentiel (%)", f"{gain_pct:,.2f}%"),
                ("Suggestion", f"Modifier vers T{best} pour optimiser la facture"),
            ]
        )

        sim_df = pd.DataFrame(rows, columns=["Composante", "Montant (DA)"])
        self.df = pd.concat([self.df, sim_df], ignore_index=True)

    @staticmethod
    def _map_cadrans_to_postes(code_tarif, cadran_1_kWh, cadran_2_kWh, cadran_3_kWh):
        """Mappe l'entrée 3 cadrans vers les postes kWh selon T41/T42/T43/T44."""
        c1 = float(cadran_1_kWh)
        c2 = float(cadran_2_kWh)
        c3 = float(cadran_3_kWh)

        postes = {
            "kWh_pointe": 0,
            "kWh_pleine": 0,
            "kWh_jour": 0,
            "kWh_nuit": 0,
            "kWh_hors_pointe": 0,
            "kWh_poste_unique": 0,
        }

        if code_tarif == "41":
            postes["kWh_pointe"] = c1
            postes["kWh_pleine"] = c2
            postes["kWh_nuit"] = c3
        elif code_tarif == "42":
            postes["kWh_pointe"] = c2
            postes["kWh_hors_pointe"] = c1 + c3
        elif code_tarif == "43":
            postes["kWh_nuit"] = c1
            postes["kWh_jour"] = c2 + c3
        elif code_tarif == "44":
            postes["kWh_poste_unique"] = c1 + c2 + c3
        else:
            raise ValueError(f"Code tarif HTA non supporté pour simulation 3 cadrans: {code_tarif}")

        return postes

    def simulate_hta_tariffs_from_cadrans(self, tarif_reference=None, include_simulation=False):
        """
        Simule T41/T42/T43/T44 a partir des 3 cadrans et retourne le meilleur tarif
        ainsi que le gain vs tarif de reference.
        """
        if not self._has_three_cadrans(self.facture):
            raise ValueError(
                "Les 3 cadrans doivent etre renseignes (cadran_1_kWh, cadran_2_kWh, cadran_3_kWh)."
            )

        if tarif_reference is None:
            tarif_reference = self.contrat.code_tarif
        tarif_reference = str(tarif_reference)

        simulations = {}
        for code in self.SUPPORTED_HTA_CODES:
            postes = self._map_cadrans_to_postes(
                code,
                self.facture.cadran_1_kWh,
                self.facture.cadran_2_kWh,
                self.facture.cadran_3_kWh,
            )

            facture_sim = input_Facture(
                start=self.facture.start,
                end=self.facture.end,
                kvarh_reactif=self.facture.kvarh_reactif,
                PMA_kW=self.facture.PMA_kW,
                taxe_produits_energetiques_cDA_kWh=self.facture.taxe_produits_energetiques_cDA_kWh,
                cadran_1_kWh=self.facture.cadran_1_kWh,
                cadran_2_kWh=self.facture.cadran_2_kWh,
                cadran_3_kWh=self.facture.cadran_3_kWh,
                **postes,
            )
            contrat_sim = input_Contrat(code_tarif=code, PMD_kW=self.contrat.PMD_kW)
            calc_sim = Sonalgaz_Elec(contrat_sim, facture_sim)
            calc_sim.calculate(include_simulation=include_simulation)

            simulations[code] = {
                "postes_kWh": postes,
                "montant_total": calc_sim.montant_total,
                "montant_tva": calc_sim.montant_tva,
                "montant_total_ttc": calc_sim.montant_total_ttc,
                "montant_total_facture": calc_sim.montant_total_facture,
            }

        if tarif_reference not in simulations:
            raise ValueError(
                f"tarif_reference doit etre dans {self.SUPPORTED_HTA_CODES}, recu: {tarif_reference}"
            )

        tarif_optimal, detail_optimal = min(
            simulations.items(), key=lambda item: item[1]["montant_total_facture"]
        )

        montant_reference = simulations[tarif_reference]["montant_total_facture"]
        montant_optimal = detail_optimal["montant_total_facture"]
        gain_DA = montant_reference - montant_optimal
        gain_pct = (gain_DA / montant_reference * 100) if montant_reference else 0

        return {
            "tarif_reference": tarif_reference,
            "montant_reference": montant_reference,
            "simulations": simulations,
            "tarif_optimal": tarif_optimal,
            "montant_optimal": montant_optimal,
            "gain_DA": gain_DA,
            "gain_pct": gain_pct,
        }

    def __repr__(self):
        if hasattr(self, "df_totaux") and self.df_totaux is not None:
            return self.df_totaux.to_string()
        return f"Sonalgaz_Elec(code_tarif={getattr(self, 'code_tarif', '?')})"

    def plot(self, title="Facture d'Électricité SONALGAZ (DA)", figsize=(8, 6)):
        """Affiche un graphique en donut des composantes principales de la facture."""
        # Séparation de l'énergie réactive en bonus/malus
        reactif_bonus = min(0, self.montant_reactif)  # Valeur négative ou 0
        reactif_malus = max(0, self.montant_reactif)  # Valeur positive ou 0
        taxe_val = getattr(self, "montant_taxe_produits_energetiques", 0) or 0
        
        # Ajuster les labels et valeurs selon le type d'énergie réactive
        if reactif_bonus < 0:
            labels = ['Fixe et PMD(Puissance mise à disposition)', 'PMA(Puissance maximale atteinte)', 'Énergie', 'Réactif (bonus)', 'TVA']
            values = [
                self.montant_fixe + self.montant_PMD,
                self.montant_PMA,
                self.montant_energie,
                abs(reactif_bonus),  # Conversion en positif pour l'affichage
                self.montant_tva
            ]
        else:
            labels = ['Fixe et PMD(Puissance mise à disposition)', 'PMA(Puissance maximale atteinte)', 'Énergie', 'Réactif (malus)', 'TVA']
            values = [
                self.montant_fixe + self.montant_PMD,
                self.montant_PMA,
                self.montant_energie,
                reactif_malus,
                self.montant_tva
            ]

        # La taxe produits énergétiques est hors assiette TVA et affichée séparément.
        if taxe_val > 0:
            labels.append('Taxe produits énergétiques (hors TVA)')
            values.append(taxe_val)
        
        colors = ['#4CAF50', '#2196F3', '#F44336', '#9C27B0', '#FFC107', '#607D8B']
        
        total = self.montant_total_facture if taxe_val > 0 else self.montant_total_ttc
        
        fig, ax = plt.subplots(figsize=figsize)
        
        wedges, texts, autotexts = ax.pie(
            values,
            labels=None,
            autopct='%1.1f%%',
            startangle=90,
            colors=colors,
            wedgeprops=dict(width=0.4, edgecolor='w'),
            pctdistance=0.8,
            textprops={'fontsize': 12}
        )
        
        ax.axis('equal')
        plt.title(title, fontsize=12, pad=16)
        
        # Ajout du total au centre du donut
        ax.text(0, 0, f"{total:,.2f} DA", ha='center', va='center', fontsize=14, fontweight='bold')
        
        # Légende en bas à gauche avec indication bonus/malus
        y_start = -0.05
        y_step = 0.07
        x_rect = -0.12
        x_text = -0.05
        
        for i, (label, val, color) in enumerate(zip(labels, values, colors)):
            y = y_start - i * y_step
            rect = Rectangle((x_rect, y - 0.02), 0.04, 0.04, facecolor=color, transform=ax.transAxes, clip_on=False)
            ax.add_patch(rect)
            # Affichage du signe négatif pour le bonus
            if "bonus" in label:
                ax.text(x_text, y, f"{label} : -{val:,.2f} DA",
                       transform=ax.transAxes,
                       ha='left', va='center',
                       fontsize=11, weight='bold')
            else:
                ax.text(x_text, y, f"{label} : {val:,.2f} DA",
                       transform=ax.transAxes,
                       ha='left', va='center',
                       fontsize=11, weight='bold')
        
        plt.tight_layout()
        plt.show()

    def plot_detail(self, title="Détail des Composantes de la Facture SONALGAZ", figsize=(16, 6)):
        """Affiche un graphique en cascade (waterfall) des composantes détaillées."""
        fig, axs = plt.subplots(1, 2, figsize=figsize)  # Changé de 3 à 2 graphiques

        def plot_waterfall(ax, labels, values, title):
            cum_values = [0]
            for v in values:
                cum_values.append(cum_values[-1] + v)

            colors = ['green' if v >= 0 else 'red' for v in values]
            for i, (label, val) in enumerate(zip(labels, values)):
                ax.bar(i, val, bottom=cum_values[i], color=colors[i], edgecolor='black')
                y_text = cum_values[i] + val / 2
                ax.text(i, y_text, f"{val:.2f} DA", ha='center', va='center', fontsize=9,
                        color='black' if abs(val) > 20 else 'black')

            total = sum(values)
            ax.set_xticks(range(len(labels)))
            ax.set_xticklabels(labels, rotation=45, ha='right')
            ax.axhline(0, color='black', linewidth=0.8)
            ax.set_title(f"{title}\nTotal : {total:,.2f} DA", fontsize=12)
            ax.grid(axis='y', linestyle='--', alpha=0.5)

        # Composantes fixes
        fixes_labels = ['Redevance Fixe', 'PMD-Puissance mise à disposition', 'PMA-Puissance maximale atteinte']
        fixes_values = [
            self.montant_fixe,
            self.montant_PMD,
            self.montant_PMA
        ]
        plot_waterfall(axs[0], fixes_labels, fixes_values, "Composantes Fixes")

        # Énergie active et réactive
        energie_labels = []
        energie_values = []
        
        # Ajout des composantes d'énergie active selon le code tarif
        if self.contrat.code_tarif == "42":
            energie_labels.extend(['Pointe', 'Hors Pointe'])
            energie_values.extend([
                self.coefficients['point_cDA_kWh']/100 * self.facture.kWh_pointe,
                self.coefficients['hors_pointe_cDA_kWh']/100 * self.facture.kWh_hors_pointe
            ])
        else:
            energie_labels.extend(['Pointe', 'Pleine', 'Jour', 'Nuit', 'Hors Pointe'])
            energie_values.extend([
                self.coefficients['point_cDA_kWh']/100 * self.facture.kWh_pointe,
                self.coefficients['Pleine_cDA_kWh']/100 * self.facture.kWh_pleine,
                self.coefficients['jour_cDA_kWh']/100 * self.facture.kWh_jour,
                self.coefficients['Nuit_cDA_kWh']/100 * self.facture.kWh_nuit,
                self.coefficients['hors_pointe_cDA_kWh']/100 * self.facture.kWh_hors_pointe
            ])
        
        # Ajout de l'énergie réactive
        energie_labels.append('Réactive')
        energie_values.append(self.montant_reactif)

        # Taxes affichées séparément (TVA + taxe produits énergétiques hors TVA)
        energie_labels.append('TVA')
        energie_values.append(self.montant_tva)
        if getattr(self, "montant_taxe_produits_energetiques", 0) > 0:
            energie_labels.append('Taxe produits énergétiques (hors TVA)')
            energie_values.append(self.montant_taxe_produits_energetiques)
        
        plot_waterfall(axs[1], energie_labels, energie_values, "Énergies et Taxes")

        plt.suptitle(title, fontsize=16, y=0.97)
        plt.tight_layout(rect=[0, 0, 1, 0.93])
        plt.show()