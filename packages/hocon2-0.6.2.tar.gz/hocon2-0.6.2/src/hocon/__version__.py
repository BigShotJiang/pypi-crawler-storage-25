"""Version."""

__title__ = "hocon"
__description__ = "A modern HOCON parser with json-like API."
__version__ = "0.6.2"
