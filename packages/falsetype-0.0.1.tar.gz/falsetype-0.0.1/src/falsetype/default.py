from typing import Type, TypeVar

T = TypeVar('T')


def FalseType(cls: Type[T]) -> T:
    """Return an instance of the given type that always evaluates to False in boolean context."""

    class FalseValueClass(cls):  # type: ignore
        def __bool__(self) -> bool:
            return False

        def __setattr__(self, key, value):
            raise AttributeError("Can't set attributes on FalseType")

        def __setitem__(self, key, value):
            raise TypeError("Can't set items on FalseType")

        def __getattr__(self, item):
            raise AttributeError("Can't get attributes on FalseType")

        def __getitem__(self, item):
            raise TypeError("Can't get items on FalseType")

    FalseValueClass.__name__ = f"{cls.__name__}"
    FalseValueClass.__qualname__ = f"{cls.__qualname__}"

    return FalseValueClass()
