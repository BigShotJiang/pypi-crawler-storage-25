from .default import FalseType

__version__ = "0.0.1"
