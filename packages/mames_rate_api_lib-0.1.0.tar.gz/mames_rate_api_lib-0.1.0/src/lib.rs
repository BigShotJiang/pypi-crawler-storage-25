use pyo3::prelude::*;
use pyo3::exceptions::PyRuntimeError;
use minacalc_rs::{Calc, RoxCalcExt};
use std::path::PathBuf;
use std::collections::HashMap;

/// Python側で `rate.overall` のようにアクセスするための構造体
#[pyclass]
#[derive(Clone)]
pub struct RateScores {
    #[pyo3(get)] pub overall: f64,
    #[pyo3(get)] pub stream: f64,
    #[pyo3(get)] pub jumpstream: f64,
    #[pyo3(get)] pub handstream: f64,
    #[pyo3(get)] pub stamina: f64,
    #[pyo3(get)] pub jackspeed: f64,
    #[pyo3(get)] pub chordjack: f64,
    #[pyo3(get)] pub technical: f64,
}

/// メインの計算関数。Pythonからは `mames_rate_api_lib.calculate(path)` として呼ばれる
#[pyfunction]
// 【変更1】戻り値のHashMapのキーを f64 から String に変更しました
pub fn calculate(input: String) -> PyResult<HashMap<String, RateScores>> {
    let calc = Calc::new().map_err(|_| {
        PyRuntimeError::new_err("Calcの初期化に失敗しました")
    })?;

    let path = PathBuf::from(&input);

    let msd_results = calc.calculate_all_rates_from_file(&path, true).map_err(|_| {
        PyRuntimeError::new_err("ファイルからのレート計算に失敗しました")
    })?;

    // 返り値となる Rust の HashMap
    // 【変更2】キーの型を String として明示的に指定しました
    let mut result_map: HashMap<String, RateScores> = HashMap::new();

    let rates = [0.7, 1.0, 1.5, 2.0];
    let rate_indices = [0, 3, 8, 13];

    for (rate, &index) in rates.iter().zip(rate_indices.iter()) {
        if index < msd_results.msds.len() {
            let scores = &msd_results.msds[index];

            // Pythonに渡すための構造体を生成
            let rate_scores = RateScores {
                overall: scores.overall as f64,
                stream: scores.stream as f64,
                jumpstream: scores.jumpstream as f64,
                handstream: scores.handstream as f64,
                stamina: scores.stamina as f64,
                jackspeed: scores.jackspeed as f64,
                chordjack: scores.chordjack as f64,
                technical: scores.technical as f64,
            };

            // HashMapに挿入 (PyO3が自動でPythonのdictに変換してくれます)
            // 【変更3】rate (f64) を .to_string() で文字列に変換してキーにしました
            result_map.insert(rate.to_string(), rate_scores);
        }
    }

    Ok(result_map)
}

/// Pythonモジュールの定義
#[pymodule]
fn mames_rate_api_lib(_py: Python, m: &PyModule) -> PyResult<()> {
    // モジュールに calculate 関数を登録
    m.add_function(wrap_pyfunction!(calculate, m)?)?;
    // RateScores クラスも登録しておく
    m.add_class::<RateScores>()?;
    Ok(())
}