"""Weightscope patch format (.wsp) — sparse delta-as-patch.

Layout:
    4B magic "WSP2" | 4B LE uint32 header_size | utf-8 JSON header | zstd(blobs)

The zstd stream is the concatenation of per-tensor blobs. The header's
`blob_offset` / `blob_size` fields slice into the *decompressed* stream.

Tensor kinds:
    - "delta": blob = [indices (uint32 or uint64)] || [raw B-values]
               Apply: overwrite base[indices] with values.
    - "new":   blob = [raw full tensor bytes] (tensor only in B)
               Apply: insert tensor into the output.

Tensor names listed in `only_in_a` are deleted from the output on apply.

Base integrity is checked via sha256 of the raw base-tensor bytes. Apply
will refuse to run unless every referenced base tensor matches, unless the
caller explicitly disables verification.
"""
from __future__ import annotations

import hashlib
import io
import json
import struct
from dataclasses import dataclass
from typing import Any, BinaryIO

import numpy as np
import torch
import zstandard as zstd

MAGIC = b"WSP2"
FORMAT_VERSION = "0.2"

# Numpy has no bfloat16, so we serialize bf16 bytes as int16 (identical bit
# layout) and reinterpret on load. Keep this table tight — unsupported dtypes
# raise rather than silently falling through.
_TORCH_BY_NAME: dict[str, torch.dtype] = {
    "float32": torch.float32,
    "float16": torch.float16,
    "bfloat16": torch.bfloat16,
    "int8": torch.int8,
    "uint8": torch.uint8,
    "int16": torch.int16,
    "int32": torch.int32,
    "int64": torch.int64,
}
_NP_BY_TORCH: dict[torch.dtype, np.dtype] = {
    torch.float32: np.dtype(np.float32),
    torch.float16: np.dtype(np.float16),
    torch.int8: np.dtype(np.int8),
    torch.uint8: np.dtype(np.uint8),
    torch.int16: np.dtype(np.int16),
    torch.int32: np.dtype(np.int32),
    torch.int64: np.dtype(np.int64),
}


def dtype_name(t: torch.Tensor) -> str:
    return str(t.dtype).removeprefix("torch.")


def torch_dtype(name: str) -> torch.dtype:
    if name not in _TORCH_BY_NAME:
        raise ValueError(f"Unsupported dtype for patch: {name}")
    return _TORCH_BY_NAME[name]


def tensor_to_bytes(t: torch.Tensor) -> bytes:
    """Raw little-endian byte representation of a tensor's values."""
    t = t.detach().contiguous().cpu()
    if t.dtype == torch.bfloat16:
        return t.view(torch.int16).numpy().tobytes()
    return t.numpy().tobytes()


def bytes_to_tensor(buf: bytes, shape: tuple[int, ...], dtype_name_: str) -> torch.Tensor:
    dt = torch_dtype(dtype_name_)
    if dt == torch.bfloat16:
        arr = np.frombuffer(buf, dtype=np.int16).copy()
        t = torch.from_numpy(arr).view(torch.bfloat16)
    else:
        arr = np.frombuffer(buf, dtype=_NP_BY_TORCH[dt]).copy()
        t = torch.from_numpy(arr)
    return t.reshape(shape)


def tensor_sha256(t: torch.Tensor) -> str:
    return hashlib.sha256(tensor_to_bytes(t)).hexdigest()


def _index_width_for(numel: int) -> int:
    return 4 if numel < (1 << 32) else 8


def _index_np_dtype(width: int) -> np.dtype:
    return np.dtype(np.uint32) if width == 4 else np.dtype(np.uint64)


@dataclass
class TensorRecord:
    """Manifest entry for one tensor in a patch."""
    kind: str                # "delta" | "new"
    name: str
    shape: tuple[int, ...]
    dtype: str
    blob_offset: int
    blob_size: int
    # delta-only:
    n_changed: int = 0
    index_width: int = 4
    base_sha256: str = ""

    def to_json(self) -> dict[str, Any]:
        d = {
            "kind": self.kind,
            "name": self.name,
            "shape": list(self.shape),
            "dtype": self.dtype,
            "blob_offset": self.blob_offset,
            "blob_size": self.blob_size,
        }
        if self.kind == "delta":
            d["n_changed"] = self.n_changed
            d["index_width"] = self.index_width
            d["base_sha256"] = self.base_sha256
        return d

    @classmethod
    def from_json(cls, d: dict[str, Any]) -> "TensorRecord":
        return cls(
            kind=d["kind"],
            name=d["name"],
            shape=tuple(d["shape"]),
            dtype=d["dtype"],
            blob_offset=d["blob_offset"],
            blob_size=d["blob_size"],
            n_changed=d.get("n_changed", 0),
            index_width=d.get("index_width", 4),
            base_sha256=d.get("base_sha256", ""),
        )


class PatchWriter:
    """Build a .wsp patch incrementally, then flush to a file handle.

    Blobs are buffered in memory so the final header can reference exact
    offsets into the decompressed stream. This is fine — even for a 70B
    model a high-sparsity delta is well under a few GB and fits.
    """

    def __init__(self, model_a: str, model_b: str, threshold: float) -> None:
        self.model_a = model_a
        self.model_b = model_b
        self.threshold = threshold
        self._blob = io.BytesIO()
        self._records: list[TensorRecord] = []
        self._only_in_a: list[str] = []

    def add_delta(
        self,
        name: str,
        base: torch.Tensor,
        target: torch.Tensor,
        threshold: float,
    ) -> TensorRecord:
        if base.shape != target.shape:
            # Shape change: fall back to full replacement.
            return self.add_full(name, target)
        delta = (base.float() - target.float()).abs()
        mask = (delta > threshold).flatten()
        changed = torch.nonzero(mask, as_tuple=False).flatten()
        n_changed = int(changed.numel())

        numel = base.numel()
        width = _index_width_for(numel)
        idx_np = changed.numpy().astype(_index_np_dtype(width), copy=False)
        # Pull values at those indices from target (cast-safe via flatten view).
        values = target.detach().contiguous().cpu().flatten()[changed]

        offset = self._blob.tell()
        self._blob.write(idx_np.tobytes())
        self._blob.write(tensor_to_bytes(values))
        size = self._blob.tell() - offset

        rec = TensorRecord(
            kind="delta",
            name=name,
            shape=tuple(base.shape),
            dtype=dtype_name(target),
            blob_offset=offset,
            blob_size=size,
            n_changed=n_changed,
            index_width=width,
            base_sha256=tensor_sha256(base),
        )
        self._records.append(rec)
        return rec

    def add_full(self, name: str, tensor: torch.Tensor) -> TensorRecord:
        offset = self._blob.tell()
        self._blob.write(tensor_to_bytes(tensor))
        size = self._blob.tell() - offset
        rec = TensorRecord(
            kind="new",
            name=name,
            shape=tuple(tensor.shape),
            dtype=dtype_name(tensor),
            blob_offset=offset,
            blob_size=size,
        )
        self._records.append(rec)
        return rec

    def mark_deleted(self, name: str) -> None:
        self._only_in_a.append(name)

    def write(self, fp: BinaryIO) -> None:
        header = {
            "version": FORMAT_VERSION,
            "model_a": self.model_a,
            "model_b": self.model_b,
            "threshold": self.threshold,
            "codec": "csr-zstd",
            "tensors": [r.to_json() for r in self._records],
            "only_in_a": list(self._only_in_a),
        }
        header_bytes = json.dumps(header, separators=(",", ":")).encode("utf-8")
        payload = zstd.ZstdCompressor(level=10).compress(self._blob.getvalue())
        fp.write(MAGIC)
        fp.write(struct.pack("<I", len(header_bytes)))
        fp.write(header_bytes)
        fp.write(payload)


@dataclass
class ParsedPatch:
    header: dict[str, Any]
    records: list[TensorRecord]
    blob: bytes  # decompressed

    @property
    def model_a(self) -> str:
        return self.header.get("model_a", "")

    @property
    def model_b(self) -> str:
        return self.header.get("model_b", "")

    @property
    def threshold(self) -> float:
        return float(self.header.get("threshold", 0.0))

    @property
    def only_in_a(self) -> list[str]:
        return list(self.header.get("only_in_a", []))

    def slice(self, rec: TensorRecord) -> bytes:
        return self.blob[rec.blob_offset : rec.blob_offset + rec.blob_size]


def read_patch(fp: BinaryIO) -> ParsedPatch:
    magic = fp.read(4)
    if magic != MAGIC:
        raise ValueError(f"Not a weightscope patch (bad magic: {magic!r})")
    (header_size,) = struct.unpack("<I", fp.read(4))
    header = json.loads(fp.read(header_size).decode("utf-8"))
    if header.get("version") != FORMAT_VERSION:
        raise ValueError(
            f"Unsupported patch version {header.get('version')!r}; "
            f"this weightscope supports {FORMAT_VERSION}"
        )
    compressed = fp.read()
    blob = zstd.ZstdDecompressor().decompress(compressed)
    records = [TensorRecord.from_json(d) for d in header["tensors"]]
    return ParsedPatch(header=header, records=records, blob=blob)


def decode_delta(rec: TensorRecord, blob_slice: bytes) -> tuple[np.ndarray, torch.Tensor]:
    """Return (indices, values) from a delta blob."""
    np_idx = _index_np_dtype(rec.index_width)
    idx_bytes = rec.n_changed * rec.index_width
    indices = np.frombuffer(blob_slice[:idx_bytes], dtype=np_idx).copy()
    values = bytes_to_tensor(blob_slice[idx_bytes:], (rec.n_changed,), rec.dtype)
    return indices, values
