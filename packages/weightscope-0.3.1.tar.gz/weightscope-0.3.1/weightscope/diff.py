"""Core sparse tensor diff."""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path

import torch
from safetensors import safe_open

from weightscope.loader import fetch, index_tensors
from weightscope.names import build_canonical_index, canonical_name


# Bytes-per-value for delta-size estimation. Conservative — actual format
# overhead (varint indices, block headers) ignored at this resolution.
_BYTES_PER_DTYPE = {
    "torch.float32": 4,
    "torch.float16": 2,
    "torch.bfloat16": 2,
    "torch.int8": 1,
    "torch.uint8": 1,
    "torch.int16": 2,
    "torch.int32": 4,
    "torch.int64": 8,
}


def _bytes_per_value(dtype_str: str) -> int:
    return _BYTES_PER_DTYPE.get(dtype_str, 2)


@dataclass
class TensorDiff:
    """Per-tensor diff statistics."""

    name: str
    shape: tuple[int, ...]
    n_params: int
    n_changed: int          # |delta| > threshold
    max_delta: float
    mean_abs_delta: float
    dtype: str

    @property
    def sparsity(self) -> float:
        """Fraction of params unchanged."""
        return 1.0 - (self.n_changed / max(self.n_params, 1))

    @property
    def compressed_bytes(self) -> int:
        """Estimate sparse-delta size: 4-byte index + dtype-bytes value
        per changed param. Header overhead ignored."""
        return self.n_changed * (4 + _bytes_per_value(self.dtype))

    @property
    def full_bytes(self) -> int:
        return self.n_params * _bytes_per_value(self.dtype)


@dataclass
class ModelDiff:
    """Aggregate diff across all tensors of two models."""

    model_a: str
    model_b: str
    threshold: float = 1e-6
    tensors: list[TensorDiff] = field(default_factory=list)
    only_in_a: list[str] = field(default_factory=list)
    only_in_b: list[str] = field(default_factory=list)
    # Tensors that paired via canonical-name normalization rather than exact
    # name match. Each entry is (name_in_a, name_in_b). Empty when both sides
    # use identical naming conventions.
    renames: list[tuple[str, str]] = field(default_factory=list)

    @property
    def total_params(self) -> int:
        return sum(t.n_params for t in self.tensors)

    @property
    def total_changed(self) -> int:
        return sum(t.n_changed for t in self.tensors)

    @property
    def overall_sparsity(self) -> float:
        if not self.total_params:
            return 0.0
        return 1.0 - (self.total_changed / self.total_params)

    @property
    def compressed_delta_bytes(self) -> int:
        return sum(t.compressed_bytes for t in self.tensors)

    @property
    def full_model_bytes(self) -> int:
        return sum(t.full_bytes for t in self.tensors)

    @property
    def compression_ratio(self) -> float:
        return self.full_model_bytes / max(self.compressed_delta_bytes, 1)


def diff_tensor(
    name: str,
    t_a: torch.Tensor,
    t_b: torch.Tensor,
    threshold: float = 1e-6,
) -> TensorDiff:
    """Compute sparse diff stats for one tensor pair.

    Shape mismatches are treated as a full reset (every param counted as changed).
    """
    if t_a.shape != t_b.shape:
        return TensorDiff(
            name=name,
            shape=tuple(t_b.shape),
            n_params=t_b.numel(),
            n_changed=t_b.numel(),
            max_delta=float("inf"),
            mean_abs_delta=float("inf"),
            dtype=str(t_b.dtype),
        )

    # Up-cast to float32 so bf16/fp16 subtraction doesn't lose precision.
    delta = (t_a.float() - t_b.float()).abs()
    n_changed = int((delta > threshold).sum().item())
    max_delta = float(delta.max().item()) if delta.numel() else 0.0
    mean_abs = float(delta.mean().item()) if delta.numel() else 0.0
    return TensorDiff(
        name=name,
        shape=tuple(t_a.shape),
        n_params=t_a.numel(),
        n_changed=n_changed,
        max_delta=max_delta,
        mean_abs_delta=mean_abs,
        dtype=str(t_a.dtype),
    )


def diff_models(
    model_a: str,
    model_b: str,
    threshold: float = 1e-6,
    revision_a: str | None = None,
    revision_b: str | None = None,
    cache_dir: str | None = None,
    progress: Callable[[int, str], None] | None = None,
) -> ModelDiff:
    """Compute sparse diff between two HuggingFace model checkpoints.

    Streams tensors one at a time from .safetensors files. Memory cost is
    O(largest single tensor pair), not O(full model).

    Args:
        model_a, model_b: HuggingFace model IDs (e.g. "meta-llama/Llama-3.2-1B").
        threshold: |a - b| <= threshold is treated as unchanged.
        revision_a, revision_b: Optional git revisions / tags.
        cache_dir: HuggingFace cache directory.
        progress: Optional callback(n_diffed, last_tensor_name) for UI.

    Returns:
        ModelDiff with per-tensor stats and aggregate properties.
    """
    dir_a = fetch(model_a, revision=revision_a, cache_dir=cache_dir)
    dir_b = fetch(model_b, revision=revision_b, cache_dir=cache_dir)

    file_b_for = index_tensors(dir_b)
    files_a = sorted(dir_a.glob("*.safetensors"))
    if not files_a:
        raise FileNotFoundError(f"No .safetensors files for {model_a} in {dir_a}")

    # Fallback lookup: canonical_name(A-name) -> original B-name. Lets a
    # re-upload that uses a different wrapper prefix (model./module./...)
    # still pair with the original, provided shapes match.
    b_canonical = build_canonical_index(list(file_b_for.keys()))

    md = ModelDiff(model_a=model_a, model_b=model_b, threshold=threshold)
    paired_b_names: set[str] = set()

    for f_a in files_a:
        with safe_open(f_a, framework="pt") as st_a:
            for key in st_a.keys():
                b_name = _pair_name(key, file_b_for, b_canonical)
                if b_name is None:
                    md.only_in_a.append(key)
                    continue
                t_a = st_a.get_tensor(key)
                with safe_open(file_b_for[b_name], framework="pt") as st_b:
                    t_b = st_b.get_tensor(b_name)
                # Record the rename only when the names actually differ — the
                # canonical match may have agreed with the exact name.
                if b_name != key:
                    md.renames.append((key, b_name))
                md.tensors.append(diff_tensor(key, t_a, t_b, threshold))
                paired_b_names.add(b_name)
                if progress is not None:
                    progress(len(md.tensors), key)

    md.only_in_b = sorted(set(file_b_for.keys()) - paired_b_names)
    return md


def _pair_name(
    a_name: str,
    file_b_for: dict[str, str],
    b_canonical: dict[str, str],
) -> str | None:
    """Find the name in B that matches ``a_name``, or None.

    Exact match wins. Otherwise try canonical-name fallback. Shape
    verification happens implicitly downstream in ``diff_tensor``, which
    flags shape mismatches as full resets — so a bad pairing is still
    reported, just as a shape-mismatch signal rather than an architecture
    change.
    """
    if a_name in file_b_for:
        return a_name
    return b_canonical.get(canonical_name(a_name))
