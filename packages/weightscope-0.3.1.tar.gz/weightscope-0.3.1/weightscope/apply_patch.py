"""Apply a weightscope .wsp patch to a base checkpoint."""
from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

import torch
from safetensors import safe_open
from safetensors.torch import save_file

from weightscope.loader import fetch, index_tensors
from weightscope.names import build_canonical_index, canonical_name
from weightscope.patch import ParsedPatch, decode_delta, read_patch, tensor_sha256


def _resolve_base(base: str, cache_dir: str | None = None) -> Path:
    """Accept either a local directory of .safetensors or a HF model ID."""
    p = Path(base)
    if p.exists() and p.is_dir():
        return p
    return fetch(base, cache_dir=cache_dir)


def apply_patch(
    patch_path: Path,
    base: str,
    out_path: Path,
    verify: bool = True,
    cache_dir: str | None = None,
    progress: Callable[[int, str], None] | None = None,
) -> dict[str, int]:
    """Apply .wsp to base, writing a single consolidated .safetensors file.

    Args:
        patch_path: path to a .wsp patch file.
        base: HF model ID or local directory holding base .safetensors shards.
        out_path: output .safetensors file (single consolidated file).
        verify: when True, abort if any base-tensor sha256 doesn't match the
            patch manifest. Disable only for debugging.
    """
    with open(patch_path, "rb") as fp:
        parsed: ParsedPatch = read_patch(fp)

    base_dir = _resolve_base(base, cache_dir=cache_dir)
    file_for = index_tensors(base_dir)
    base_canonical = build_canonical_index(list(file_for.keys()))

    patched_names: set[str] = set()  # populated with resolved base names
    deleted_base_names: set[str] = set()
    out: dict[str, torch.Tensor] = {}

    # Resolve "only_in_a" names against the actual base (same name-normalization
    # rules apply, since the base may be a re-upload with different wrapping).
    for name in parsed.only_in_a:
        if name in file_for:
            deleted_base_names.add(name)
            continue
        resolved = base_canonical.get(canonical_name(name))
        if resolved is not None:
            deleted_base_names.add(resolved)

    # 1) Apply patch records first. These either overwrite or add tensors.
    for i, rec in enumerate(parsed.records):
        slice_ = parsed.slice(rec)
        if rec.kind == "delta":
            # Resolve the base tensor name: exact match, then canonical fallback.
            base_name = rec.name if rec.name in file_for else base_canonical.get(
                canonical_name(rec.name)
            )
            if base_name is None:
                raise KeyError(
                    f"Base {base!r} is missing tensor {rec.name!r} (no "
                    "canonical-name fallback matched either). Is this the "
                    "right base checkpoint?"
                )
            with safe_open(file_for[base_name], framework="pt") as st:
                base_t = st.get_tensor(base_name)
            if verify:
                got = tensor_sha256(base_t)
                if got != rec.base_sha256:
                    raise ValueError(
                        f"Base tensor {rec.name!r} hash mismatch. "
                        f"Patch expects {rec.base_sha256[:12]}..., "
                        f"got {got[:12]}.... Wrong base checkpoint? "
                        "Use --no-verify to force."
                    )
            indices, values = decode_delta(rec, slice_)
            flat = base_t.detach().contiguous().cpu().flatten().clone()
            if values.dtype != flat.dtype:
                values = values.to(flat.dtype)
            idx_t = torch.from_numpy(indices.astype("int64", copy=False))
            flat[idx_t] = values
            out[rec.name] = flat.reshape(rec.shape).contiguous()
            patched_names.add(base_name)
        elif rec.kind == "new":
            from weightscope.patch import bytes_to_tensor
            out[rec.name] = bytes_to_tensor(slice_, rec.shape, rec.dtype).contiguous()
        else:
            raise ValueError(f"Unknown record kind: {rec.kind!r}")
        if progress is not None:
            progress(i + 1, rec.name)

    # 2) Carry forward base tensors we haven't patched or deleted. They keep
    #    their original base names since the patch didn't touch them.
    for name, f in file_for.items():
        if name in patched_names or name in deleted_base_names:
            continue
        with safe_open(f, framework="pt") as st:
            out[name] = st.get_tensor(name).contiguous()

    out_path.parent.mkdir(parents=True, exist_ok=True)
    save_file(out, str(out_path))
    return {
        "n_patched": len(parsed.records),
        "n_deleted": len(deleted_base_names),
        "n_total": len(out),
        "out_bytes": out_path.stat().st_size,
    }
