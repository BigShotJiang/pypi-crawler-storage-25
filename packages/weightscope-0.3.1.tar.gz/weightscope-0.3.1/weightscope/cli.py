"""CLI entry point for weightscope.

Subcommands:
    diff   — markdown report of sparse tensor diff (default if no subcommand)
    export — build a sparse delta patch (.wsp) from A to B
    apply  — apply a .wsp patch to a base checkpoint
"""
from __future__ import annotations

import sys
from pathlib import Path

import click
from rich.console import Console
from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn

from weightscope.apply_patch import apply_patch
from weightscope.diff import diff_models
from weightscope.export_patch import export_patch
from weightscope.report import render_markdown

console = Console()


def _progress_cb(progress: Progress, task_id) -> "callable":  # type: ignore[name-defined]
    def cb(n: int, name: str) -> None:
        display = name if len(name) <= 40 else "..." + name[-37:]
        progress.update(task_id, description=f"{n} tensors (last: {display})")
    return cb


@click.group(
    invoke_without_command=True,
    context_settings={"help_option_names": ["-h", "--help"]},
)
@click.version_option(package_name="weightscope")
@click.pass_context
def main(ctx: click.Context) -> None:
    """Weightscope — X-ray for AI model weights."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@main.command("diff")
@click.argument("model_a")
@click.argument("model_b")
@click.option("--threshold", type=float, default=1e-6, show_default=True,
              help="Treat abs(a - b) <= threshold as unchanged.")
@click.option("--output", "-o", type=click.Path(path_type=Path), default=None,
              help="Write markdown report to file. Default: stdout.")
@click.option("--cache-dir", type=click.Path(path_type=Path), default=None,
              help="HuggingFace cache directory.")
@click.option("--revision-a", default=None, help="Git revision / tag for model A.")
@click.option("--revision-b", default=None, help="Git revision / tag for model B.")
def diff_cmd(
    model_a: str,
    model_b: str,
    threshold: float,
    output: Path | None,
    cache_dir: Path | None,
    revision_a: str | None,
    revision_b: str | None,
) -> None:
    """Compute sparse tensor diff between two HuggingFace model checkpoints."""
    console.print("[bold cyan]weightscope diff[/]")
    console.print(f"  A: [green]{model_a}[/]")
    console.print(f"  B: [green]{model_b}[/]")
    console.print(f"  Threshold: {threshold}\n")

    with Progress(
        SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
        BarColumn(), console=console, transient=True,
    ) as prog:
        task = prog.add_task("Diffing tensors...", total=None)
        try:
            md = diff_models(
                model_a, model_b,
                threshold=threshold,
                revision_a=revision_a,
                revision_b=revision_b,
                cache_dir=str(cache_dir) if cache_dir else None,
                progress=_progress_cb(prog, task),
            )
        except Exception as e:
            console.print(f"[red]Error:[/] {e}")
            sys.exit(1)

    report = render_markdown(md)
    if output:
        output.write_text(report, encoding="utf-8")
        console.print(f"[green]OK[/] Report written to [cyan]{output}[/]")
    else:
        click.echo(report)


@main.command("export")
@click.argument("model_a")
@click.argument("model_b")
@click.option("--output", "-o", type=click.Path(path_type=Path), required=True,
              help="Output .wsp patch file.")
@click.option("--threshold", type=float, default=1e-6, show_default=True,
              help="Treat abs(a - b) <= threshold as unchanged (not in patch).")
@click.option("--cache-dir", type=click.Path(path_type=Path), default=None,
              help="HuggingFace cache directory.")
@click.option("--revision-a", default=None, help="Git revision / tag for model A.")
@click.option("--revision-b", default=None, help="Git revision / tag for model B.")
def export_cmd(
    model_a: str,
    model_b: str,
    output: Path,
    threshold: float,
    cache_dir: Path | None,
    revision_a: str | None,
    revision_b: str | None,
) -> None:
    """Build a sparse delta patch (.wsp) turning model A into model B."""
    console.print("[bold cyan]weightscope export[/]")
    console.print(f"  A (base):   [green]{model_a}[/]")
    console.print(f"  B (target): [green]{model_b}[/]")
    console.print(f"  Out:        [cyan]{output}[/]")
    console.print(f"  Threshold:  {threshold}\n")

    with Progress(
        SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
        BarColumn(), console=console, transient=True,
    ) as prog:
        task = prog.add_task("Building patch...", total=None)
        try:
            stats = export_patch(
                model_a, model_b,
                out_path=output,
                threshold=threshold,
                revision_a=revision_a,
                revision_b=revision_b,
                cache_dir=str(cache_dir) if cache_dir else None,
                progress=_progress_cb(prog, task),
            )
        except Exception as e:
            console.print(f"[red]Error:[/] {e}")
            sys.exit(1)

    mb = stats["patch_bytes"] / (1024 * 1024)
    console.print(
        f"[green]OK[/] Wrote patch: "
        f"{stats['n_delta']} delta, {stats['n_new']} new, "
        f"{stats['n_deleted']} deleted — [bold]{mb:.2f} MB[/]"
    )


@main.command("apply")
@click.argument("patch_path", type=click.Path(path_type=Path, exists=True))
@click.argument("base")
@click.option("--output", "-o", type=click.Path(path_type=Path), required=True,
              help="Output consolidated .safetensors file.")
@click.option("--no-verify", is_flag=True, default=False,
              help="Skip sha256 verification of base tensors.")
@click.option("--cache-dir", type=click.Path(path_type=Path), default=None,
              help="HuggingFace cache directory (for HF-id bases).")
def apply_cmd(
    patch_path: Path,
    base: str,
    output: Path,
    no_verify: bool,
    cache_dir: Path | None,
) -> None:
    """Apply a .wsp patch to a base checkpoint (HF model ID or local dir)."""
    console.print("[bold cyan]weightscope apply[/]")
    console.print(f"  Patch: [cyan]{patch_path}[/]")
    console.print(f"  Base:  [green]{base}[/]")
    console.print(f"  Out:   [cyan]{output}[/]")
    if no_verify:
        console.print("  [yellow]Base verification disabled (--no-verify)[/]")
    console.print()

    with Progress(
        SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
        BarColumn(), console=console, transient=True,
    ) as prog:
        task = prog.add_task("Applying patch...", total=None)
        try:
            stats = apply_patch(
                patch_path=patch_path,
                base=base,
                out_path=output,
                verify=not no_verify,
                cache_dir=str(cache_dir) if cache_dir else None,
                progress=_progress_cb(prog, task),
            )
        except Exception as e:
            console.print(f"[red]Error:[/] {e}")
            sys.exit(1)

    mb = stats["out_bytes"] / (1024 * 1024)
    console.print(
        f"[green]OK[/] {stats['n_total']} tensors written "
        f"({stats['n_patched']} patched, {stats['n_deleted']} deleted) "
        f"— [bold]{mb:.2f} MB[/]"
    )


if __name__ == "__main__":
    main()
