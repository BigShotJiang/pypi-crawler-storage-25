"""Tensor-name normalization for cross-uploader diffs.

Different uploaders produce the same weights under slightly different names:

    _orig_mod.model.layers.0.self_attn.q_proj.weight   # torch.compile artifact
    module.model.layers.0.self_attn.q_proj.weight      # DataParallel / DDP artifact
    model.layers.0.self_attn.q_proj.weight             # vanilla HF transformers
    layers.0.self_attn.q_proj.weight                   # base model hoisted out of wrapper

We canonicalize by stripping a small set of well-known wrapper prefixes. These
prefixes come from PyTorch conventions (how ``nn.Module`` nests its state dict)
and are safe to strip — they don't distinguish real weights.

**Safety net**: callers must still verify tensor shapes match before pairing a
canonical-matched pair. Matching names alone is not enough. If an uploader has
a tensor literally named ``model.something_weird``, stripping ``model.`` could
produce a false match — but only if the resulting canonical name collides with
a real unrelated tensor. Shape verification catches that.
"""
from __future__ import annotations

# Order matters: strip outer wrappers first so inner ones become visible.
_WRAPPER_PREFIXES: tuple[str, ...] = (
    "_orig_mod.",   # torch.compile
    "module.",      # DataParallel / DistributedDataParallel
    "model.",       # AutoModelForX wrapping its backbone as self.model
)


def canonical_name(name: str) -> str:
    """Strip wrapper prefixes from a tensor name.

    Applied iteratively because an uploader can nest wrappers
    (e.g. ``module._orig_mod.model.layers.0...``).
    """
    changed = True
    while changed:
        changed = False
        for p in _WRAPPER_PREFIXES:
            if name.startswith(p):
                name = name[len(p):]
                changed = True
    return name


def build_canonical_index(names: list[str]) -> dict[str, str]:
    """Return a ``canonical -> first-original`` map for a list of tensor names.

    If two originals share a canonical (rare but possible — e.g. one side has
    ``model.layers.0.X`` and ``layers.0.X`` both), the first one wins. The
    caller can still disambiguate by trying the exact name first.
    """
    out: dict[str, str] = {}
    for n in names:
        out.setdefault(canonical_name(n), n)
    return out
