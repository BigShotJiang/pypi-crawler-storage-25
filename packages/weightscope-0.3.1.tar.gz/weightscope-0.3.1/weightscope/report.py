"""Markdown report rendering for ModelDiff."""
from __future__ import annotations

from weightscope.diff import ModelDiff
from weightscope.interpret import render_interpretation


def _human_bytes(n: float) -> str:
    units = ("B", "KB", "MB", "GB", "TB", "PB")
    val = float(n)
    for unit in units:
        if val < 1024:
            return f"{val:.1f} {unit}"
        val /= 1024
    return f"{val:.1f} EB"


def _layer_prefix(name: str, depth: int = 3) -> str:
    """Group tensors by leading dot-separated prefix for layer-level rollup.

    e.g. 'transformer.h.5.attn.c_proj.weight' with depth=3 -> 'transformer.h.5'
    """
    parts = name.split(".")
    return ".".join(parts[:depth]) if len(parts) >= depth else name


def render_markdown(diff: ModelDiff, top_n: int = 15) -> str:
    """Render a ModelDiff as a markdown report."""
    lines: list[str] = []
    lines.append(f"# Model diff: `{diff.model_a}` vs `{diff.model_b}`")
    lines.append("")
    lines.append(f"Threshold: `abs(a - b) > {diff.threshold:g}`")
    lines.append("")

    lines.append("## Summary")
    lines.append("")
    lines.append(f"- Total params compared: **{diff.total_params:,}**")
    lines.append(
        f"- Changed params: **{diff.total_changed:,}** "
        f"({(1 - diff.overall_sparsity) * 100:.2f}%)"
    )
    lines.append(
        f"- Sparsity (unchanged fraction): **{diff.overall_sparsity * 100:.2f}%**"
    )
    lines.append(f"- Full model size: **{_human_bytes(diff.full_model_bytes)}**")
    lines.append(
        f"- Sparse delta size (estimated): "
        f"**{_human_bytes(diff.compressed_delta_bytes)}**"
    )
    lines.append(f"- Compression ratio: **{diff.compression_ratio:.1f}x**")
    lines.append("")

    lines.append(render_interpretation(diff))

    if diff.only_in_a:
        lines.append(f"### Tensors only in `{diff.model_a}` ({len(diff.only_in_a)})")
        for name in diff.only_in_a[:20]:
            lines.append(f"- `{name}`")
        if len(diff.only_in_a) > 20:
            lines.append(f"- ... and {len(diff.only_in_a) - 20} more")
        lines.append("")

    if diff.only_in_b:
        lines.append(f"### Tensors only in `{diff.model_b}` ({len(diff.only_in_b)})")
        for name in diff.only_in_b[:20]:
            lines.append(f"- `{name}`")
        if len(diff.only_in_b) > 20:
            lines.append(f"- ... and {len(diff.only_in_b) - 20} more")
        lines.append("")

    layer_stats: dict[str, dict[str, int]] = {}
    for t in diff.tensors:
        prefix = _layer_prefix(t.name)
        s = layer_stats.setdefault(prefix, {"n_params": 0, "n_changed": 0, "tensors": 0})
        s["n_params"] += t.n_params
        s["n_changed"] += t.n_changed
        s["tensors"] += 1

    layer_rows = sorted(
        layer_stats.items(),
        key=lambda kv: kv[1]["n_changed"] / max(kv[1]["n_params"], 1),
        reverse=True,
    )

    lines.append("## Most-changed layer groups")
    lines.append("")
    lines.append("| Layer prefix | Tensors | Params | Changed | % changed |")
    lines.append("|---|---:|---:|---:|---:|")
    for prefix, s in layer_rows[:top_n]:
        pct = (s["n_changed"] / max(s["n_params"], 1)) * 100
        lines.append(
            f"| `{prefix}` | {s['tensors']} | {s['n_params']:,} | "
            f"{s['n_changed']:,} | {pct:.2f}% |"
        )
    lines.append("")

    lines.append("## Top tensors by absolute change")
    lines.append("")
    lines.append("| Tensor | Shape | Params | Changed | % changed | Max delta |")
    lines.append("|---|---|---:|---:|---:|---:|")
    for t in sorted(diff.tensors, key=lambda x: x.n_changed, reverse=True)[:top_n]:
        pct = (1 - t.sparsity) * 100
        shape = "x".join(str(s) for s in t.shape)
        lines.append(
            f"| `{t.name}` | {shape} | {t.n_params:,} | "
            f"{t.n_changed:,} | {pct:.2f}% | {t.max_delta:.4g} |"
        )
    lines.append("")

    lines.append("---")
    lines.append("> Need private diffs on your own checkpoints, hosted history, "
                 "or signed compliance reports? See https://weightscope.dev")

    return "\n".join(lines)
