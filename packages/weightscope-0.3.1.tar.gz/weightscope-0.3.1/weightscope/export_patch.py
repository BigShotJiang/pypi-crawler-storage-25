"""Build a weightscope .wsp patch from two HuggingFace checkpoints."""
from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

from safetensors import safe_open

from weightscope.loader import fetch, index_tensors
from weightscope.names import build_canonical_index, canonical_name
from weightscope.patch import PatchWriter


def export_patch(
    model_a: str,
    model_b: str,
    out_path: Path,
    threshold: float = 1e-6,
    revision_a: str | None = None,
    revision_b: str | None = None,
    cache_dir: str | None = None,
    progress: Callable[[int, str], None] | None = None,
) -> dict[str, int]:
    """Write a sparse-delta patch (.wsp) that turns model A into model B.

    Returns a small stats dict: {n_delta, n_new, n_deleted, patch_bytes}.
    Names are matched exactly first, then via canonical-name normalization.
    The patch stores A's names so ``apply`` can find the same tensors on
    the base — with the same fallback on apply.
    """
    dir_a = fetch(model_a, revision=revision_a, cache_dir=cache_dir)
    dir_b = fetch(model_b, revision=revision_b, cache_dir=cache_dir)

    file_b_for = index_tensors(dir_b)
    files_a = sorted(dir_a.glob("*.safetensors"))
    if not files_a:
        raise FileNotFoundError(f"No .safetensors files for {model_a} in {dir_a}")

    b_canonical = build_canonical_index(list(file_b_for.keys()))
    writer = PatchWriter(model_a=model_a, model_b=model_b, threshold=threshold)
    paired_b_names: set[str] = set()
    n_delta = n_new = 0

    for f_a in files_a:
        with safe_open(f_a, framework="pt") as st_a:
            for key in st_a.keys():
                b_name = (
                    key if key in file_b_for
                    else b_canonical.get(canonical_name(key))
                )
                if b_name is None:
                    writer.mark_deleted(key)
                    continue
                t_a = st_a.get_tensor(key)
                with safe_open(file_b_for[b_name], framework="pt") as st_b:
                    t_b = st_b.get_tensor(b_name)
                writer.add_delta(key, t_a, t_b, threshold)
                paired_b_names.add(b_name)
                n_delta += 1
                if progress is not None:
                    progress(n_delta + n_new, key)

    # Tensors present only in B -> store full (keyed by B's original name).
    only_in_b = sorted(set(file_b_for.keys()) - paired_b_names)
    for key in only_in_b:
        with safe_open(file_b_for[key], framework="pt") as st_b:
            t_b = st_b.get_tensor(key)
        writer.add_full(key, t_b)
        n_new += 1
        if progress is not None:
            progress(n_delta + n_new, key)

    with open(out_path, "wb") as fp:
        writer.write(fp)

    return {
        "n_delta": n_delta,
        "n_new": n_new,
        "n_deleted": len(writer._only_in_a),
        "patch_bytes": out_path.stat().st_size,
    }
