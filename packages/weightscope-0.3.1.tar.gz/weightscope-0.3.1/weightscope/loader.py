"""HuggingFace model weight loading via huggingface_hub + safetensors."""
from __future__ import annotations

from pathlib import Path

from huggingface_hub import snapshot_download
from safetensors import safe_open


def fetch(
    model_id: str,
    revision: str | None = None,
    cache_dir: str | None = None,
) -> Path:
    """Resolve a model source to a local directory of .safetensors files.

    Accepts either a HuggingFace repo ID (e.g. ``Qwen/Qwen2.5-0.5B``) or a
    path to a local directory. HF IDs are downloaded via ``snapshot_download``
    (only .safetensors + .json — we skip tokenizer/text artifacts). Local
    directories are returned as-is so the same loader code can run against
    synthetic test fixtures without hitting the network.
    """
    p = Path(model_id)
    if p.exists() and p.is_dir():
        return p
    return Path(
        snapshot_download(
            repo_id=model_id,
            revision=revision,
            cache_dir=cache_dir,
            allow_patterns=["*.safetensors", "*.json"],
        )
    )


def index_tensors(model_dir: Path) -> dict[str, str]:
    """Build a tensor_name -> safetensors_file_path index for one model.

    Lets us look up tensor B for a given name without scanning every file.
    """
    files = sorted(model_dir.glob("*.safetensors"))
    if not files:
        raise FileNotFoundError(
            f"No .safetensors files in {model_dir}. "
            "Pickle/.bin checkpoints are not supported in this MVP."
        )
    index: dict[str, str] = {}
    for f in files:
        with safe_open(f, framework="pt") as st:
            for key in st.keys():
                index[key] = str(f)
    return index
