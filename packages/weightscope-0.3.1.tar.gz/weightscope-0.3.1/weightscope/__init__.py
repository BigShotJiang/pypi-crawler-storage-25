"""Weightscope — X-ray for AI model weights."""
from weightscope.apply_patch import apply_patch
from weightscope.diff import ModelDiff, TensorDiff, diff_models, diff_tensor
from weightscope.export_patch import export_patch
from weightscope.interpret import Fact, Inference, collect_facts, infer, render_interpretation
from weightscope.names import canonical_name
from weightscope.patch import FORMAT_VERSION as PATCH_FORMAT_VERSION
from weightscope.report import render_markdown

__version__ = "0.3.1"
__all__ = [
    "diff_models",
    "diff_tensor",
    "TensorDiff",
    "ModelDiff",
    "render_markdown",
    "export_patch",
    "apply_patch",
    "PATCH_FORMAT_VERSION",
    "Fact",
    "Inference",
    "collect_facts",
    "infer",
    "render_interpretation",
    "canonical_name",
]
