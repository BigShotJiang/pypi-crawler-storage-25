"""Round-trip tests for the .wsp export/apply pipeline.

Uses synthetic safetensors on disk — no HF download.
"""
from __future__ import annotations

from pathlib import Path

import pytest
import torch
from safetensors.torch import save_file

from weightscope import apply_patch, export_patch
from weightscope.patch import (
    ParsedPatch,
    bytes_to_tensor,
    read_patch,
    tensor_sha256,
    tensor_to_bytes,
)


def _make_model(dir_: Path, tensors: dict[str, torch.Tensor]) -> None:
    dir_.mkdir(parents=True, exist_ok=True)
    save_file(tensors, str(dir_ / "model.safetensors"))


def _load_flat(path: Path) -> dict[str, torch.Tensor]:
    from safetensors import safe_open
    out: dict[str, torch.Tensor] = {}
    with safe_open(path, framework="pt") as st:
        for k in st.keys():
            out[k] = st.get_tensor(k)
    return out


def _tensors_equal(a: torch.Tensor, b: torch.Tensor) -> bool:
    return a.shape == b.shape and a.dtype == b.dtype and torch.equal(a, b)


def test_tensor_bytes_roundtrip_fp32():
    t = torch.randn(50, 40, dtype=torch.float32)
    got = bytes_to_tensor(tensor_to_bytes(t), tuple(t.shape), "float32")
    assert _tensors_equal(got, t)


def test_tensor_bytes_roundtrip_bf16():
    t = torch.randn(50, 40).to(torch.bfloat16)
    got = bytes_to_tensor(tensor_to_bytes(t), tuple(t.shape), "bfloat16")
    assert _tensors_equal(got, t)


def test_tensor_sha256_stable():
    torch.manual_seed(0)
    t1 = torch.randn(10, 10)
    t2 = t1.clone()
    assert tensor_sha256(t1) == tensor_sha256(t2)
    t2[0, 0] += 1.0
    assert tensor_sha256(t1) != tensor_sha256(t2)


@pytest.fixture
def lora_pair(tmp_path: Path) -> tuple[Path, Path, dict[str, torch.Tensor]]:
    """A tiny 'base' model and a 'target' that differs by ~1% LoRA-like mask."""
    torch.manual_seed(42)
    base = {
        "layer1.weight": torch.randn(100, 100, dtype=torch.float32),
        "layer2.weight": torch.randn(50, 100, dtype=torch.float32),
        "embed.weight": torch.randn(200, 100).to(torch.bfloat16),
    }
    target = {}
    for k, v in base.items():
        nv = v.clone()
        mask = torch.rand_like(v.float()) < 0.01
        nv = nv.float() + mask.float() * 0.5
        target[k] = nv.to(v.dtype)
    dir_a = tmp_path / "a"
    dir_b = tmp_path / "b"
    _make_model(dir_a, base)
    _make_model(dir_b, target)
    return dir_a, dir_b, target


def test_export_patch_creates_file(lora_pair, tmp_path):
    dir_a, dir_b, _ = lora_pair
    patch = tmp_path / "p.wsp"
    stats = export_patch(str(dir_a), str(dir_b), out_path=patch, threshold=1e-6)
    assert patch.exists()
    assert stats["n_delta"] == 3
    assert stats["n_new"] == 0
    assert stats["n_deleted"] == 0
    assert stats["patch_bytes"] > 0


def test_roundtrip_identity(lora_pair, tmp_path):
    """export(A, B) -> apply(patch, A) must reproduce B bitwise."""
    dir_a, dir_b, target = lora_pair
    patch = tmp_path / "p.wsp"
    export_patch(str(dir_a), str(dir_b), out_path=patch, threshold=1e-9)
    out = tmp_path / "out.safetensors"
    apply_patch(patch_path=patch, base=str(dir_a), out_path=out)
    got = _load_flat(out)
    for name, expected in target.items():
        assert name in got, f"missing {name}"
        assert _tensors_equal(got[name], expected), f"mismatch on {name}"


def test_patch_is_smaller_than_full_for_sparse_delta(lora_pair, tmp_path):
    dir_a, dir_b, target = lora_pair
    patch = tmp_path / "p.wsp"
    export_patch(str(dir_a), str(dir_b), out_path=patch, threshold=1e-6)
    full_bytes = sum(t.numel() * t.element_size() for t in target.values())
    assert patch.stat().st_size < full_bytes * 0.5, (
        f"patch={patch.stat().st_size} vs full={full_bytes}: "
        "expected <50% for 1% LoRA-like delta"
    )


def test_apply_rejects_wrong_base(lora_pair, tmp_path):
    """sha256 verification should block applying a patch to an unrelated base."""
    dir_a, dir_b, _ = lora_pair
    # Build a wrong base with the same tensor names but different values.
    torch.manual_seed(999)
    wrong = {
        "layer1.weight": torch.randn(100, 100, dtype=torch.float32),
        "layer2.weight": torch.randn(50, 100, dtype=torch.float32),
        "embed.weight": torch.randn(200, 100).to(torch.bfloat16),
    }
    dir_wrong = tmp_path / "wrong"
    _make_model(dir_wrong, wrong)
    patch = tmp_path / "p.wsp"
    export_patch(str(dir_a), str(dir_b), out_path=patch)
    with pytest.raises(ValueError, match="hash mismatch"):
        apply_patch(patch_path=patch, base=str(dir_wrong), out_path=tmp_path / "out.st")


def test_no_verify_lets_mismatched_base_through(lora_pair, tmp_path):
    dir_a, dir_b, _ = lora_pair
    patch = tmp_path / "p.wsp"
    export_patch(str(dir_a), str(dir_b), out_path=patch, threshold=1e-9)
    out = tmp_path / "out.safetensors"
    # Apply to the CORRECT base but with --no-verify — must still succeed.
    apply_patch(patch_path=patch, base=str(dir_a), out_path=out, verify=False)
    assert out.exists()


def test_new_tensor_in_b_is_stored_full(tmp_path):
    base = {"layer.weight": torch.randn(10, 10)}
    target = {
        "layer.weight": base["layer.weight"].clone(),
        "new_head.weight": torch.randn(5, 10),
    }
    dir_a = tmp_path / "a"; dir_b = tmp_path / "b"
    _make_model(dir_a, base); _make_model(dir_b, target)
    patch = tmp_path / "p.wsp"
    stats = export_patch(str(dir_a), str(dir_b), out_path=patch)
    assert stats["n_new"] == 1
    out = tmp_path / "out.safetensors"
    apply_patch(patch_path=patch, base=str(dir_a), out_path=out)
    got = _load_flat(out)
    assert "new_head.weight" in got
    assert _tensors_equal(got["new_head.weight"], target["new_head.weight"])


def test_only_in_a_is_dropped_on_apply(tmp_path):
    base = {
        "keep.weight": torch.randn(10, 10),
        "removed.weight": torch.randn(5, 5),
    }
    target = {"keep.weight": base["keep.weight"].clone()}
    dir_a = tmp_path / "a"; dir_b = tmp_path / "b"
    _make_model(dir_a, base); _make_model(dir_b, target)
    patch = tmp_path / "p.wsp"
    stats = export_patch(str(dir_a), str(dir_b), out_path=patch)
    assert stats["n_deleted"] == 1
    out = tmp_path / "out.safetensors"
    apply_patch(patch_path=patch, base=str(dir_a), out_path=out)
    got = _load_flat(out)
    assert "removed.weight" not in got
    assert "keep.weight" in got


def test_patch_header_introspection(lora_pair, tmp_path):
    dir_a, dir_b, _ = lora_pair
    patch = tmp_path / "p.wsp"
    export_patch(str(dir_a), str(dir_b), out_path=patch, threshold=5e-7)
    with open(patch, "rb") as fp:
        parsed: ParsedPatch = read_patch(fp)
    assert parsed.header["version"] == "0.2"
    assert parsed.threshold == 5e-7
    assert {r.name for r in parsed.records} == {
        "layer1.weight", "layer2.weight", "embed.weight"
    }
    for rec in parsed.records:
        assert rec.kind == "delta"
        assert rec.base_sha256  # non-empty
