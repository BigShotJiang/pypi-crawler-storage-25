"""Smoke tests for diff logic — synthetic tensors, no HF download."""
from __future__ import annotations

import torch

from weightscope.diff import ModelDiff, diff_tensor
from weightscope.report import render_markdown


def test_identical_tensors_are_fully_sparse():
    a = torch.randn(100, 100)
    d = diff_tensor("layer.weight", a, a.clone(), threshold=1e-9)
    assert d.n_changed == 0
    assert d.sparsity == 1.0


def test_random_tensors_are_almost_fully_changed():
    torch.manual_seed(0)
    a = torch.randn(100, 100)
    b = torch.randn(100, 100)
    d = diff_tensor("layer.weight", a, b, threshold=1e-6)
    assert d.n_changed >= 9000  # essentially all 10000 elements differ
    assert d.sparsity < 0.1


def test_lora_like_change_is_99_percent_sparse():
    """LoRA-like: only a few % of weights are perturbed."""
    torch.manual_seed(0)
    a = torch.randn(100, 100)
    b = a.clone()
    mask = torch.rand_like(b) < 0.01
    b = torch.where(mask, b + 0.5, b)
    d = diff_tensor("layer.weight", a, b, threshold=1e-6)
    assert 50 < d.n_changed < 150  # ~1% of 10000
    assert d.sparsity > 0.95


def test_shape_mismatch_treats_as_full_change():
    a = torch.randn(100, 100)
    b = torch.randn(101, 100)
    d = diff_tensor("layer.weight", a, b, threshold=1e-6)
    assert d.n_changed == d.n_params


def test_compressed_size_smaller_than_full_for_sparse():
    torch.manual_seed(0)
    a = torch.randn(1000, 1000)
    b = a.clone()
    mask = torch.rand_like(b) < 0.001  # 0.1% changed
    b = torch.where(mask, b + 0.5, b)
    d = diff_tensor("w", a, b, threshold=1e-6)
    assert d.compressed_bytes < d.full_bytes


def test_render_markdown_smoke():
    torch.manual_seed(0)
    a = torch.randn(50, 50)
    b = a.clone()
    b[0, 0] += 1.0
    td = diff_tensor("layer.weight", a, b, threshold=1e-6)
    md = ModelDiff(
        model_a="dummy/a",
        model_b="dummy/b",
        threshold=1e-6,
        tensors=[td],
    )
    report = render_markdown(md)
    assert "Model diff:" in report
    assert "dummy/a" in report
    assert "dummy/b" in report
    assert "layer.weight" in report
