"""Tests for tensor-name normalization + cross-uploader matching.

Synthesizes two 'models' as safetensors on disk where one side uses a
wrapper prefix (module. / _orig_mod. / model.) and the other doesn't.
Diff/export/apply must all pair the tensors despite the name mismatch.
"""
from __future__ import annotations

from pathlib import Path

import pytest
import torch
from safetensors import safe_open
from safetensors.torch import save_file

from weightscope import apply_patch, diff_models, export_patch
from weightscope.names import build_canonical_index, canonical_name


def _save(dir_: Path, tensors: dict[str, torch.Tensor]) -> None:
    dir_.mkdir(parents=True, exist_ok=True)
    save_file(tensors, str(dir_ / "model.safetensors"))


def _load(path: Path) -> dict[str, torch.Tensor]:
    out: dict[str, torch.Tensor] = {}
    with safe_open(path, framework="pt") as st:
        for k in st.keys():
            out[k] = st.get_tensor(k)
    return out


# ---- canonical_name -----------------------------------------------------

@pytest.mark.parametrize("raw,expected", [
    ("layers.0.self_attn.q_proj.weight",
     "layers.0.self_attn.q_proj.weight"),
    ("model.layers.0.self_attn.q_proj.weight",
     "layers.0.self_attn.q_proj.weight"),
    ("module.model.layers.0.self_attn.q_proj.weight",
     "layers.0.self_attn.q_proj.weight"),
    ("_orig_mod.module.model.layers.0.self_attn.q_proj.weight",
     "layers.0.self_attn.q_proj.weight"),
    # Prefix-like substring in the middle shouldn't be stripped.
    ("layers.0.mlp.model_stub.weight",
     "layers.0.mlp.model_stub.weight"),
])
def test_canonical_name_examples(raw, expected):
    assert canonical_name(raw) == expected


def test_build_canonical_index_prefers_first_seen():
    names = ["model.w", "w", "module.model.w"]
    idx = build_canonical_index(names)
    assert idx == {"w": "model.w"}  # first-original wins


# ---- cross-uploader diff + patch ---------------------------------------

@pytest.fixture
def mixed_naming_pair(tmp_path: Path):
    """A has ``model.`` prefix; B has no prefix. Same underlying weights."""
    torch.manual_seed(11)
    a_weights = {
        "model.layer1.weight": torch.randn(64, 64, dtype=torch.float32),
        "model.layer2.weight": torch.randn(32, 64, dtype=torch.float32),
    }
    # B holds the same shapes, perturbed by ~2%.
    b_weights = {}
    for k, v in a_weights.items():
        bare = k.removeprefix("model.")
        nv = v.clone()
        mask = torch.rand_like(nv) < 0.02
        nv = nv + mask.float() * 0.5
        b_weights[bare] = nv
    dir_a = tmp_path / "A"; dir_b = tmp_path / "B"
    _save(dir_a, a_weights); _save(dir_b, b_weights)
    return dir_a, dir_b, a_weights, b_weights


def test_diff_pairs_tensors_across_naming_conventions(mixed_naming_pair):
    dir_a, dir_b, a_w, b_w = mixed_naming_pair
    md = diff_models(str(dir_a), str(dir_b), threshold=1e-9)
    # Should match on canonical name — no stragglers in only_in_a / only_in_b.
    assert not md.only_in_a, md.only_in_a
    assert not md.only_in_b, md.only_in_b
    assert len(md.tensors) == 2
    assert sorted((a, b) for a, b in md.renames) == [
        ("model.layer1.weight", "layer1.weight"),
        ("model.layer2.weight", "layer2.weight"),
    ]


def test_export_apply_roundtrips_across_naming_conventions(
    mixed_naming_pair, tmp_path,
):
    """Classic cross-uploader flow: A uses model.X; B uses X. Export a patch
    from A to B, then apply it back onto A, and confirm we reconstruct B."""
    dir_a, dir_b, a_w, b_w = mixed_naming_pair
    patch = tmp_path / "p.wsp"
    stats = export_patch(str(dir_a), str(dir_b), out_path=patch, threshold=1e-9)
    assert stats["n_delta"] == 2
    assert stats["n_new"] == 0
    assert stats["n_deleted"] == 0

    out = tmp_path / "out.safetensors"
    apply_patch(patch_path=patch, base=str(dir_a), out_path=out)
    got = _load(out)
    # Patch records carry A's names, so output uses A-style names. Each tensor
    # should match B's values bit-exactly.
    for a_name, expected_v in zip(["model.layer1.weight", "model.layer2.weight"],
                                  [b_w["layer1.weight"], b_w["layer2.weight"]]):
        assert a_name in got
        assert torch.equal(got[a_name], expected_v), f"mismatch on {a_name}"


def test_apply_to_renamed_base_still_works(tmp_path):
    """Patch was built on ``model.*``-prefixed A; user applies it against a
    locally-saved base that hoisted ``model.`` off. canonical_name fallback
    on the base lookup should still resolve every tensor."""
    torch.manual_seed(3)
    a_weights = {
        "model.w": torch.randn(16, 16, dtype=torch.float32),
    }
    b_weights = {
        "model.w": a_weights["model.w"] + 0.01,
    }
    dir_a = tmp_path / "A"; dir_b = tmp_path / "B"
    _save(dir_a, a_weights); _save(dir_b, b_weights)
    patch = tmp_path / "p.wsp"
    export_patch(str(dir_a), str(dir_b), out_path=patch, threshold=1e-9)

    # Same weights as A, but saved under a hoisted name.
    dir_a_renamed = tmp_path / "A_renamed"
    _save(dir_a_renamed, {"w": a_weights["model.w"]})

    out = tmp_path / "out.safetensors"
    apply_patch(patch_path=patch, base=str(dir_a_renamed), out_path=out)
    got = _load(out)
    assert "model.w" in got
    assert torch.equal(got["model.w"], b_weights["model.w"])


def test_canonical_match_doesnt_mask_true_only_in_b(tmp_path):
    """If B truly has an extra tensor with no canonical match in A, it must
    still be reported as only_in_b (stored as 'new' in patches)."""
    a = {"layer.weight": torch.randn(8, 8)}
    b = {"layer.weight": a["layer.weight"].clone(),
         "extra.head.weight": torch.randn(4, 8)}
    dir_a = tmp_path / "A"; dir_b = tmp_path / "B"
    _save(dir_a, a); _save(dir_b, b)
    md = diff_models(str(dir_a), str(dir_b))
    assert md.only_in_b == ["extra.head.weight"]

    patch = tmp_path / "p.wsp"
    stats = export_patch(str(dir_a), str(dir_b), out_path=patch)
    assert stats["n_new"] == 1
