import re
import threading
import time
from unittest.mock import Mock, patch

import pytest

from wristband.django_auth.config_resolver import ConfigResolver
from wristband.django_auth.exceptions import WristbandError
from wristband.django_auth.models import AuthConfig, SdkConfiguration


class TestConfigResolverValidation:
    """Test cases for ConfigResolver validation logic."""

    def test_validate_client_id_empty(self):
        """Test validation fails with empty client_id."""
        config = AuthConfig(
            client_id="",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
        )

        with pytest.raises(TypeError, match="The \\[client_id\\] config must have a value."):
            ConfigResolver(config)

    def test_validate_client_id_whitespace(self):
        """Test validation fails with whitespace-only client_id."""
        config = AuthConfig(
            client_id="   ",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
        )

        with pytest.raises(TypeError, match="The \\[client_id\\] config must have a value."):
            ConfigResolver(config)

    def test_validate_client_secret_empty(self):
        """Test validation fails with empty client_secret."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="",
            wristband_application_vanity_domain="test.wristband.dev",
        )

        with pytest.raises(TypeError, match="The \\[client_secret\\] config must have a value."):
            ConfigResolver(config)

    def test_validate_client_secret_whitespace(self):
        """Test validation fails with whitespace-only client_secret."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="   ",
            wristband_application_vanity_domain="test.wristband.dev",
        )

        with pytest.raises(TypeError, match="The \\[client_secret\\] config must have a value."):
            ConfigResolver(config)

    def test_validate_login_state_secret_too_short(self):
        """Test validation fails with short login_state_secret."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            login_state_secret="short",
        )

        with pytest.raises(
            TypeError, match="The \\[login_state_secret\\] config must have a value of at least 32 characters."
        ):
            ConfigResolver(config)

    def test_validate_login_state_secret_none_allowed(self):
        """Test validation passes with None login_state_secret."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            login_state_secret=None,
        )

        # Should not raise
        ConfigResolver(config)

    def test_validate_vanity_domain_empty(self):
        """Test validation fails with empty vanity domain."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="",
        )

        with pytest.raises(TypeError, match="The \\[wristband_application_vanity_domain\\] config must have a value."):
            ConfigResolver(config)

    def test_validate_vanity_domain_whitespace(self):
        """Test validation fails with whitespace-only vanity domain."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="   ",
        )

        with pytest.raises(TypeError, match="The \\[wristband_application_vanity_domain\\] config must have a value."):
            ConfigResolver(config)

    def test_validate_token_expiration_buffer_negative(self):
        """Test validation fails with negative token_expiration_buffer."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            token_expiration_buffer=-1,
        )

        with pytest.raises(
            TypeError, match="The \\[token_expiration_buffer\\] config must be greater than or equal to 0."
        ):
            ConfigResolver(config)

    def test_validate_auto_configure_disabled_missing_login_url(self):
        """Test validation fails when auto-configure disabled and login_url missing."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            auto_configure_enabled=False,
        )

        with pytest.raises(
            TypeError, match="The \\[login_url\\] config must have a value when auto-configure is disabled."
        ):
            ConfigResolver(config)

    def test_validate_auto_configure_disabled_missing_redirect_uri(self):
        """Test validation fails when auto-configure disabled and redirect_uri missing."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            auto_configure_enabled=False,
            login_url="https://test.com/login",
        )

        with pytest.raises(
            TypeError, match="The \\[redirect_uri\\] config must have a value when auto-configure is disabled."
        ):
            ConfigResolver(config)

    def test_validate_tenant_name_placeholder_missing_in_login_url(self):
        """Test validation fails when tenant name placeholder missing from login_url."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            auto_configure_enabled=False,
            login_url="https://test.com/login",
            redirect_uri="https://{tenant_name}.test.com/callback",
            parse_tenant_from_root_domain="test.com",
        )

        with pytest.raises(TypeError, match='The \\[login_url\\] must contain the "\\{tenant_name\\}" placeholder'):
            ConfigResolver(config)

    def test_validate_tenant_name_placeholder_missing_in_redirect_uri(self):
        """Test validation fails when tenant name placeholder missing from redirect_uri."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            auto_configure_enabled=False,
            login_url="https://{tenant_name}.test.com/login",
            redirect_uri="https://test.com/callback",
            parse_tenant_from_root_domain="test.com",
        )

        with pytest.raises(TypeError, match='The \\[redirect_uri\\] must contain the "\\{tenant_name\\}" placeholder'):
            ConfigResolver(config)

    def test_validate_tenant_name_placeholder_present_without_parsing(self):
        """Test validation fails when tenant name placeholder present but parsing disabled."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            auto_configure_enabled=False,
            login_url="https://{tenant_name}.test.com/login",
            redirect_uri="https://test.com/callback",
        )

        with pytest.raises(TypeError, match='The \\[login_url\\] cannot contain the "\\{tenant_name\\}" placeholder'):
            ConfigResolver(config)

    def test_validate_partial_url_configs_with_auto_configure(self):
        """Test validation of partial URL configs when auto-configure is enabled."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            auto_configure_enabled=True,
            login_url="https://test.com/login",
            parse_tenant_from_root_domain="test.com",
        )

        with pytest.raises(TypeError, match='The \\[login_url\\] must contain the "\\{tenant_name\\}" placeholder'):
            ConfigResolver(config)

    def test_valid_configuration_passes(self):
        """Test that valid configuration passes validation."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            auto_configure_enabled=False,
            login_url="https://{tenant_name}.test.com/login",
            redirect_uri="https://{tenant_name}.test.com/callback",
            parse_tenant_from_root_domain="test.com",
            login_state_secret="a" * 32,
        )

        # Should not raise
        resolver = ConfigResolver(config)
        assert resolver is not None

    def test_validate_parse_tenant_from_root_domain_with_port(self):
        """Test validation fails when parse_tenant_from_root_domain includes a port."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            parse_tenant_from_root_domain="example.com:8080",
        )

        with pytest.raises(
            TypeError, match=re.escape("The [parse_tenant_from_root_domain] config should not include a port.")
        ):
            ConfigResolver(config)


class TestConfigResolverStaticConfigurations:
    """Test cases for static configuration getters."""

    def setup_method(self):
        """Set up test fixtures."""
        self.config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            login_state_secret="a" * 32,
            dangerously_disable_secure_cookies=True,
            scopes=["custom", "scopes"],
            token_expiration_buffer=120,
        )
        self.resolver = ConfigResolver(self.config)

    def test_get_client_id(self):
        """Test get_client_id returns correct value."""
        assert self.resolver.get_client_id() == "test_client"

    def test_get_client_secret(self):
        """Test get_client_secret returns correct value."""
        assert self.resolver.get_client_secret() == "test_secret"

    def test_get_login_state_secret_custom(self):
        """Test get_login_state_secret returns custom value when provided."""
        assert self.resolver.get_login_state_secret() == "a" * 32

    def test_get_login_state_secret_fallback(self):
        """Test get_login_state_secret falls back to client_secret."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
        )
        resolver = ConfigResolver(config)
        assert resolver.get_login_state_secret() == "test_secret"

    def test_get_wristband_application_vanity_domain(self):
        """Test get_wristband_application_vanity_domain returns correct value."""
        assert self.resolver.get_wristband_application_vanity_domain() == "test.wristband.dev"

    def test_get_dangerously_disable_secure_cookies_true(self):
        """Test get_dangerously_disable_secure_cookies when set to True."""
        assert self.resolver.get_dangerously_disable_secure_cookies() is True

    def test_get_dangerously_disable_secure_cookies_default(self):
        """Test get_dangerously_disable_secure_cookies default value."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
        )
        resolver = ConfigResolver(config)
        assert resolver.get_dangerously_disable_secure_cookies() is False

    def test_get_scopes_custom(self):
        """Test get_scopes returns custom scopes."""
        assert self.resolver.get_scopes() == ["custom", "scopes"]

    def test_get_scopes_default(self):
        """Test get_scopes returns default scopes."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
        )
        resolver = ConfigResolver(config)
        assert resolver.get_scopes() == ["openid", "offline_access", "email"]

    def test_get_scopes_empty_list_uses_default(self):
        """Test get_scopes uses defaults when empty list provided."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            scopes=[],
        )
        resolver = ConfigResolver(config)
        assert resolver.get_scopes() == ["openid", "offline_access", "email"]

    def test_get_auto_configure_enabled_default(self):
        """Test get_auto_configure_enabled returns default True."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
        )
        resolver = ConfigResolver(config)
        assert resolver.get_auto_configure_enabled() is True

    def test_get_auto_configure_enabled_false(self):
        """Test get_auto_configure_enabled when set to False."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            auto_configure_enabled=False,
            login_url="https://test.com/login",
            redirect_uri="https://test.com/callback",
        )
        resolver = ConfigResolver(config)
        assert resolver.get_auto_configure_enabled() is False

    def test_get_token_expiration_buffer_custom(self):
        """Test get_token_expiration_buffer returns custom value."""
        assert self.resolver.get_token_expiration_buffer() == 120

    def test_get_token_expiration_buffer_default(self):
        """Test get_token_expiration_buffer returns default value."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
        )
        resolver = ConfigResolver(config)
        assert resolver.get_token_expiration_buffer() == 60


class TestConfigResolverDynamicConfigurations:
    """Test cases for dynamic configuration getters."""

    def setup_method(self):
        """Set up test fixtures."""
        self.valid_sdk_config = SdkConfiguration(
            login_url="https://sdk.example.com/login",
            redirect_uri="https://sdk.example.com/callback",
            custom_application_login_page_url="https://sdk.example.com/custom-login",
            is_application_custom_domain_active=True,
            login_url_tenant_domain_suffix=None,
        )

    def test_manual_config_takes_precedence(self):
        """Test that manual configuration takes precedence over auto-config."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            login_url="https://{tenant_name}.manual.com/login",
            redirect_uri="https://{tenant_name}.manual.com/callback",
            custom_application_login_page_url="https://manual.com/custom",
            is_application_custom_domain_active=False,
            parse_tenant_from_root_domain="manual.com",
        )

        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()
            mock_client.get_sdk_configuration = Mock(return_value=self.valid_sdk_config)
            mock_client_class.return_value = mock_client

            resolver = ConfigResolver(config)

            assert resolver.get_login_url() == "https://{tenant_name}.manual.com/login"
            assert resolver.get_redirect_uri() == "https://{tenant_name}.manual.com/callback"
            assert resolver.get_custom_application_login_page_url() == "https://manual.com/custom"
            assert resolver.get_is_application_custom_domain_active() is False
            assert resolver.get_parse_tenant_from_root_domain() == "manual.com"

    def test_auto_config_fallback(self):
        """Test auto-configuration fallback when manual values not provided."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            auto_configure_enabled=True,
        )

        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()
            mock_client.get_sdk_configuration = Mock(return_value=self.valid_sdk_config)
            mock_client_class.return_value = mock_client

            resolver = ConfigResolver(config)

            assert resolver.get_login_url() == "https://sdk.example.com/login"
            assert resolver.get_redirect_uri() == "https://sdk.example.com/callback"
            assert resolver.get_custom_application_login_page_url() == "https://sdk.example.com/custom-login"
            assert resolver.get_is_application_custom_domain_active() is True
            assert resolver.get_parse_tenant_from_root_domain() == ""

    def test_auto_config_disabled_fallbacks(self):
        """Test fallback values when auto-config is disabled."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            auto_configure_enabled=False,
            login_url="https://manual.com/login",
            redirect_uri="https://manual.com/callback",
        )
        resolver = ConfigResolver(config)

        assert resolver.get_custom_application_login_page_url() == ""
        assert resolver.get_is_application_custom_domain_active() is False
        assert resolver.get_parse_tenant_from_root_domain() == ""

    def test_auto_config_none_values(self):
        """Test handling of None values from auto-config."""
        sdk_config = SdkConfiguration(
            login_url="https://sdk.example.com/login",
            redirect_uri="https://sdk.example.com/callback",
            custom_application_login_page_url=None,
            is_application_custom_domain_active=False,
            login_url_tenant_domain_suffix=None,
        )

        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            auto_configure_enabled=True,
        )

        with patch.object(ConfigResolver, "_load_sdk_config") as mock_load:
            mock_load.return_value = sdk_config
            resolver = ConfigResolver(config)

            assert resolver.get_custom_application_login_page_url() == ""
            assert resolver.get_is_application_custom_domain_active() is False
            assert resolver.get_parse_tenant_from_root_domain() == ""


class TestConfigResolverSdkConfigFetching:
    """Test cases for SDK configuration fetching and caching."""

    def setup_method(self):
        """Set up test fixtures."""
        self.config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
        )
        self.valid_sdk_config = SdkConfiguration(
            login_url="https://sdk.example.com/login",
            redirect_uri="https://sdk.example.com/callback",
            is_application_custom_domain_active=True,
        )

    def test_sdk_config_caching(self):
        """Test that SDK config is cached after first fetch."""
        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()
            mock_client.get_sdk_configuration = Mock(return_value=self.valid_sdk_config)
            mock_client_class.return_value = mock_client

            resolver = ConfigResolver(self.config)

            # First call should fetch
            result1 = resolver.get_login_url()
            assert result1 == "https://sdk.example.com/login"

            # Second call should use cache
            result2 = resolver.get_redirect_uri()
            assert result2 == "https://sdk.example.com/callback"

            # Should only have called the API once
            mock_client.get_sdk_configuration.assert_called_once()

    def test_sdk_config_retry_logic(self):
        """Test retry logic for SDK config fetching."""
        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()
            # Fail twice, succeed on third attempt
            mock_client.get_sdk_configuration = Mock(
                side_effect=[Exception("Network error 1"), Exception("Network error 2"), self.valid_sdk_config]
            )
            mock_client_class.return_value = mock_client

            resolver = ConfigResolver(self.config)

            result = resolver.get_login_url()
            assert result == "https://sdk.example.com/login"
            assert mock_client.get_sdk_configuration.call_count == 3

    def test_sdk_config_fetch_failure_after_max_retries(self):
        """Test failure after maximum retry attempts."""
        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()
            mock_client.get_sdk_configuration = Mock(side_effect=Exception("Persistent network error"))
            mock_client_class.return_value = mock_client

            resolver = ConfigResolver(self.config)

            with pytest.raises(WristbandError) as exc_info:
                resolver.get_login_url()

            assert exc_info.value.error == "sdk_config_fetch_failed"
            assert "Failed to fetch SDK configuration after 3 attempts" in exc_info.value.error_description
            assert mock_client.get_sdk_configuration.call_count == 3

    def test_preload_sdk_config(self):
        """Test preload_sdk_config method."""
        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()
            mock_client.get_sdk_configuration = Mock(return_value=self.valid_sdk_config)
            mock_client_class.return_value = mock_client

            resolver = ConfigResolver(self.config)

            # Preload config
            resolver.preload_sdk_config()
            assert mock_client.get_sdk_configuration.call_count == 1

            # Subsequent calls should use cache
            result = resolver.get_login_url()
            assert result == "https://sdk.example.com/login"
            assert mock_client.get_sdk_configuration.call_count == 1

    def test_thread_safety_multiple_threads(self):
        """Test that multiple threads don't cause duplicate requests."""
        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()

            # Add delay to simulate network request
            def delayed_response():
                time.sleep(0.1)
                return self.valid_sdk_config

            mock_client.get_sdk_configuration = Mock(side_effect=delayed_response)
            mock_client_class.return_value = mock_client

            resolver = ConfigResolver(self.config)
            results = []
            exceptions = []

            def worker():
                try:
                    result = resolver.get_login_url()
                    results.append(result)
                except Exception as e:
                    exceptions.append(e)

            # Create multiple threads
            threads = [threading.Thread(target=worker) for _ in range(3)]

            # Start all threads
            for thread in threads:
                thread.start()

            # Wait for all threads to complete
            for thread in threads:
                thread.join()

            # Should only have made one API call
            mock_client.get_sdk_configuration.assert_called_once()
            assert len(exceptions) == 0
            assert all(result == "https://sdk.example.com/login" for result in results)

    def test_error_allows_retry_after_failure(self):
        """Test that errors reset to allow retry."""
        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()
            mock_client.get_sdk_configuration = Mock(
                side_effect=[
                    Exception("First error"),
                    Exception("Second error"),
                    Exception("Third error"),
                    self.valid_sdk_config,  # Success on retry
                ]
            )
            mock_client_class.return_value = mock_client

            resolver = ConfigResolver(self.config)

            # First attempt should fail after 3 retries
            with pytest.raises(WristbandError):
                resolver.get_login_url()
            assert mock_client.get_sdk_configuration.call_count == 3

            # Second attempt should succeed
            result = resolver.get_redirect_uri()
            assert result == "https://sdk.example.com/callback"
            assert mock_client.get_sdk_configuration.call_count == 4

    def test_sdk_config_fetch_with_delay_and_retry(self):
        """Test SDK config fetch with realistic network delays and retries."""
        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()

            # Simulate network timeouts then success
            def delayed_error_then_success():
                time.sleep(0.05)  # Small delay
                if mock_client.get_sdk_configuration.call_count <= 2:
                    raise Exception("Network timeout")
                return SdkConfiguration(
                    login_url="https://sdk.example.com/login",
                    redirect_uri="https://sdk.example.com/callback",
                    is_application_custom_domain_active=False,
                )

            mock_client.get_sdk_configuration = Mock(side_effect=delayed_error_then_success)
            mock_client_class.return_value = mock_client

            config = AuthConfig(
                client_id="test_client",
                client_secret="test_secret",
                wristband_application_vanity_domain="test.wristband.dev",
            )
            resolver = ConfigResolver(config)

            start_time = time.time()
            result = resolver.get_login_url()
            end_time = time.time()

            # Should succeed on third attempt
            assert result == "https://sdk.example.com/login"
            assert mock_client.get_sdk_configuration.call_count == 3
            # Should have taken some time due to retries and delays
            assert end_time - start_time >= 0.15  # 3 calls * 0.05s delay + retry delays


class TestConfigResolverDynamicValidation:
    """Test cases for dynamic configuration validation."""

    def setup_method(self):
        """Set up test fixtures."""
        self.config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
        )

    def test_validate_missing_login_url_in_sdk_config(self):
        """Test validation fails when SDK config missing login_url."""
        invalid_sdk_config = SdkConfiguration(
            login_url="", redirect_uri="https://sdk.example.com/callback", is_application_custom_domain_active=False
        )

        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()
            mock_client.get_sdk_configuration = Mock(return_value=invalid_sdk_config)
            mock_client_class.return_value = mock_client

            resolver = ConfigResolver(self.config)

            with pytest.raises(WristbandError) as exc_info:
                resolver.get_login_url()

            assert exc_info.value.error == "sdk_config_invalid"
            assert "missing required field: login_url" in exc_info.value.error_description

    def test_validate_missing_redirect_uri_in_sdk_config(self):
        """Test validation fails when SDK config missing redirect_uri."""
        invalid_sdk_config = SdkConfiguration(
            login_url="https://sdk.example.com/login", redirect_uri="", is_application_custom_domain_active=False
        )

        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()
            mock_client.get_sdk_configuration = Mock(return_value=invalid_sdk_config)
            mock_client_class.return_value = mock_client

            resolver = ConfigResolver(self.config)

            with pytest.raises(WristbandError) as exc_info:
                resolver.get_redirect_uri()

            assert exc_info.value.error == "sdk_config_invalid"
            assert (
                "The [redirect_uri] could not be resolved. Provide it explicitly in your SDK config "
                "or ensure your Wristband OAuth2 Client has a single redirect URI configured."
                in exc_info.value.error_description
            )

    def test_validate_null_redirect_uri_in_sdk_config_without_manual_override(self):
        """Test validation fails when SDK config returns null redirect_uri and no manual override provided."""
        null_redirect_sdk_config = SdkConfiguration(
            login_url="https://sdk.example.com/login",
            redirect_uri=None,
            is_application_custom_domain_active=False,
        )

        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()
            mock_client.get_sdk_configuration = Mock(return_value=null_redirect_sdk_config)
            mock_client_class.return_value = mock_client

            resolver = ConfigResolver(self.config)

            with pytest.raises(WristbandError) as exc_info:
                resolver.get_redirect_uri()

            assert exc_info.value.error == "sdk_config_invalid"
            assert "The [redirect_uri] could not be resolved" in exc_info.value.error_description

    def test_manual_redirect_uri_overrides_null_sdk_redirect_uri(self):
        """Test that manual redirect_uri succeeds when SDK config returns null (multiple redirect URIs registered)."""
        null_redirect_sdk_config = SdkConfiguration(
            login_url="https://sdk.example.com/login",
            redirect_uri=None,
            is_application_custom_domain_active=False,
        )

        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            redirect_uri="https://manual.example.com/callback",
        )

        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()
            mock_client.get_sdk_configuration = Mock(return_value=null_redirect_sdk_config)
            mock_client_class.return_value = mock_client

            resolver = ConfigResolver(config)
            result = resolver.get_redirect_uri()
            assert result == "https://manual.example.com/callback"

    def test_validate_resolved_config_with_tenant_name(self):
        """Test validation of resolved config with tenant name parsing."""
        # SDK config without tenant name placeholders
        sdk_config = SdkConfiguration(
            login_url="https://sdk.example.com/login",
            redirect_uri="https://sdk.example.com/callback",
            is_application_custom_domain_active=False,
        )

        # Manual config with tenant name parsing
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            parse_tenant_from_root_domain="test.com",
        )

        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()
            mock_client.get_sdk_configuration = Mock(return_value=sdk_config)
            mock_client_class.return_value = mock_client

            resolver = ConfigResolver(config)

            with pytest.raises(WristbandError) as exc_info:
                resolver.get_login_url()

            assert exc_info.value.error == "config_validation_error"
            assert "must contain the" in exc_info.value.error_description
            assert "tenant_name" in exc_info.value.error_description

    def test_validate_resolved_config_without_tenant_name(self):
        """Test validation fails when tenant name_placeholder present but parsing disabled."""
        # SDK config with tenant name placeholders
        sdk_config = SdkConfiguration(
            login_url="https://{tenant_name}.sdk.example.com/login",
            redirect_uri="https://sdk.example.com/callback",
            is_application_custom_domain_active=False,
        )

        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()
            mock_client.get_sdk_configuration = Mock(return_value=sdk_config)
            mock_client_class.return_value = mock_client

            resolver = ConfigResolver(self.config)

            with pytest.raises(WristbandError) as exc_info:
                resolver.get_login_url()

            assert exc_info.value.error == "config_validation_error"
            assert "cannot contain the" in exc_info.value.error_description
            assert "tenant_name" in exc_info.value.error_description


class TestConfigResolverEdgeCases:
    """Test cases for edge cases and integration scenarios."""

    def test_boolean_handling_for_custom_domain_active(self):
        """Test proper boolean handling for is_application_custom_domain_active."""
        # Test explicit False
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            is_application_custom_domain_active=False,
        )
        resolver = ConfigResolver(config)
        assert resolver.get_is_application_custom_domain_active() is False

        # Test explicit True
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            is_application_custom_domain_active=True,
        )
        resolver = ConfigResolver(config)
        assert resolver.get_is_application_custom_domain_active() is True

        # Test None with auto-config
        sdk_config = SdkConfiguration(
            login_url="https://sdk.example.com/login",
            redirect_uri="https://sdk.example.com/callback",
            is_application_custom_domain_active=False,
        )
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
        )
        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()
            mock_client.get_sdk_configuration = Mock(return_value=sdk_config)
            mock_client_class.return_value = mock_client

            resolver = ConfigResolver(config)
            assert resolver.get_is_application_custom_domain_active() is False

    def test_empty_string_values(self):
        """Test handling of empty string values."""
        sdk_config = SdkConfiguration(
            login_url="https://sdk.example.com/login",
            redirect_uri="https://sdk.example.com/callback",
            custom_application_login_page_url=None,
            is_application_custom_domain_active=True,
        )

        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            custom_application_login_page_url="",
            parse_tenant_from_root_domain="",
        )

        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()
            mock_client.get_sdk_configuration = Mock(return_value=sdk_config)
            mock_client_class.return_value = mock_client

            resolver = ConfigResolver(config)
            assert resolver.get_custom_application_login_page_url() == ""
            assert resolver.get_parse_tenant_from_root_domain() == ""

    def test_mixed_manual_and_auto_config(self):
        """Test mixed manual and auto-configuration."""
        sdk_config = SdkConfiguration(
            login_url="https://sdk.example.com/login",
            redirect_uri="https://sdk.example.com/callback",
            custom_application_login_page_url=None,
            is_application_custom_domain_active=False,
            login_url_tenant_domain_suffix=None,
        )

        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            login_url="https://manual.example.com/login",  # Manual override
            # redirect_uri will come from auto-config
        )

        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()
            mock_client.get_sdk_configuration = Mock(return_value=sdk_config)
            mock_client_class.return_value = mock_client

            resolver = ConfigResolver(config)

            assert resolver.get_login_url() == "https://manual.example.com/login"  # Manual
            assert resolver.get_redirect_uri() == "https://sdk.example.com/callback"  # Auto-config
            assert resolver.get_custom_application_login_page_url() == ""  # Auto-config empty
            assert resolver.get_parse_tenant_from_root_domain() == ""  # Auto-config empty

    def test_error_preserves_original_message(self):
        """Test that error messages preserve original exception details."""
        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()
            original_error = Exception("Network connection failed")
            mock_client.get_sdk_configuration = Mock(side_effect=original_error)
            mock_client_class.return_value = mock_client

            config = AuthConfig(
                client_id="test_client",
                client_secret="test_secret",
                wristband_application_vanity_domain="test.wristband.dev",
            )
            resolver = ConfigResolver(config)

            with pytest.raises(WristbandError) as exc_info:
                resolver.get_login_url()

            assert "Network connection failed" in str(exc_info.value.error_description)

    def test_validate_resolved_config_precedence(self):
        """Test that manual config values take precedence in validation."""
        # Manual config has correct tenant name placeholder
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            login_url="https://{tenant_name}.manual.com/login",
            parse_tenant_from_root_domain="manual.com",
        )

        # SDK config would fail validation if used
        sdk_config = SdkConfiguration(
            login_url="https://sdk.example.com/login",  # No tenant placeholder
            redirect_uri="https://{tenant_name}.sdk.com/callback",
            is_application_custom_domain_active=True,
        )

        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()
            mock_client.get_sdk_configuration = Mock(return_value=sdk_config)
            mock_client_class.return_value = mock_client

            resolver = ConfigResolver(config)

            # Should not raise validation error because manual login_url is used
            result = resolver.get_login_url()
            assert result == "https://{tenant_name}.manual.com/login"

    def test_wristband_api_client_initialization(self):
        """Test that WristbandApiClient is initialized correctly."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
        )

        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            ConfigResolver(config)
            mock_client_class.assert_called_once_with("test.wristband.dev", "test_client", "test_secret")

    def test_concurrent_thread_access(self):
        """Test concurrent access from multiple threads."""
        sdk_config = SdkConfiguration(
            login_url="https://sdk.example.com/login",
            redirect_uri="https://sdk.example.com/callback",
            is_application_custom_domain_active=False,
        )

        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()

            # Add delay to simulate network request
            def delayed_response():
                time.sleep(0.1)
                return sdk_config

            mock_client.get_sdk_configuration = Mock(side_effect=delayed_response)
            mock_client_class.return_value = mock_client

            config = AuthConfig(
                client_id="test_client",
                client_secret="test_secret",
                wristband_application_vanity_domain="test.wristband.dev",
            )
            resolver = ConfigResolver(config)

            results = []
            exceptions = []

            def worker(getter_method):
                try:
                    result = getattr(resolver, getter_method)()
                    results.append(result)
                except Exception as e:
                    exceptions.append(e)

            # Start multiple threads with different getters
            threads = [
                threading.Thread(target=worker, args=("get_login_url",)),
                threading.Thread(target=worker, args=("get_redirect_uri",)),
                threading.Thread(target=worker, args=("get_is_application_custom_domain_active",)),
            ]

            for thread in threads:
                thread.start()

            for thread in threads:
                thread.join()

            # Should only make one API call
            mock_client.get_sdk_configuration.assert_called_once()
            assert len(exceptions) == 0
            assert len(results) == 3

    def test_tenant_name_placeholder_in_redirect_uri_without_parsing(self):
        """Test redirect_uri validation without parsing."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            auto_configure_enabled=False,
            login_url="https://test.com/login",
            redirect_uri="https://{tenant_name}.test.com/callback",
        )

        with pytest.raises(TypeError, match='cannot contain the "\\{tenant_name\\}" placeholder'):
            ConfigResolver(config)

    def test_tenant_name_placeholder_in_login_url_partial_validation(self):
        """Test partial validation login_url without parsing."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            login_url="https://{tenant_name}.test.com/login",
        )

        with pytest.raises(TypeError, match='cannot contain the "\\{tenant_name\\}" placeholder'):
            ConfigResolver(config)

    def test_tenant_name_placeholder_missing_in_redirect_uri_partial_validation(self):
        """Test partial validation when redirect_uri missing tenant name placeholder but parsing enabled."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            redirect_uri="https://test.com/callback",  # no tenant name placeholder
            parse_tenant_from_root_domain="test.com",  # parsing enabled
        )

        with pytest.raises(TypeError, match='must contain the "\\{tenant_name\\}" placeholder'):
            ConfigResolver(config)

    def test_redirect_uri_tenant_name_placeholder_present_without_parsing(self):
        """Test redirect_uri has tenant name placeholder but parsing disabled."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            redirect_uri="https://{tenant_name}.test.com/callback",  # has tenant name placeholder
            # parse_tenant_from_root_domain is None/empty - parsing disabled
        )

        with pytest.raises(TypeError, match='cannot contain the "\\{tenant_name\\}" placeholder'):
            ConfigResolver(config)

    def test_validate_resolved_redirect_uri_missing_tenant_name_placeholder(self):
        """Test resolved config validation when redirect_uri missing tenant name placeholder."""
        sdk_config = SdkConfiguration(
            login_url="https://{tenant_name}.sdk.example.com/login",
            redirect_uri="https://sdk.example.com/callback",  # missing tenant name placeholder
            is_application_custom_domain_active=False,
            login_url_tenant_domain_suffix="example.com",  # This enables tenant parsing
        )

        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
        )

        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()
            mock_client.get_sdk_configuration = Mock(return_value=sdk_config)
            mock_client_class.return_value = mock_client

            resolver = ConfigResolver(config)

            with pytest.raises(WristbandError) as exc_info:
                resolver.get_redirect_uri()  # This should trigger the validation

            assert "must contain the" in exc_info.value.error_description
            assert "redirect_uri" in exc_info.value.error_description

    def test_validate_resolved_redirect_uri_has_tenant_name_placeholder_without_parsing(self):
        """Test resolved config validation when redirect_uri has tenant name placeholder but parsing disabled."""
        sdk_config = SdkConfiguration(
            login_url="https://sdk.example.com/login",  # no tenant name placeholder
            redirect_uri="https://{tenant_name}.sdk.example.com/callback",  # has tenant name placeholder
            is_application_custom_domain_active=False,
            login_url_tenant_domain_suffix=None,  # No tenant parsing (falsy)
        )

        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
        )

        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()
            mock_client.get_sdk_configuration = Mock(return_value=sdk_config)
            mock_client_class.return_value = mock_client

            resolver = ConfigResolver(config)

            with pytest.raises(WristbandError) as exc_info:
                resolver.get_redirect_uri()

            assert "cannot contain the" in exc_info.value.error_description
            assert "redirect_uri" in exc_info.value.error_description

    def test_cache_thread_safety_with_error_recovery(self):
        """Test cache thread safety when errors occur and recovery happens."""
        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()

            # Track total call count across all attempts
            total_call_count = 0

            def error_then_success():
                nonlocal total_call_count
                total_call_count += 1
                if total_call_count <= 3:  # First 3 calls fail
                    raise Exception(f"Error {total_call_count}")
                return SdkConfiguration(
                    login_url="https://sdk.example.com/login",
                    redirect_uri="https://sdk.example.com/callback",
                    is_application_custom_domain_active=True,
                )

            mock_client.get_sdk_configuration = Mock(side_effect=error_then_success)
            mock_client_class.return_value = mock_client

            config = AuthConfig(
                client_id="test_client",
                client_secret="test_secret",
                wristband_application_vanity_domain="test.wristband.dev",
            )
            resolver = ConfigResolver(config)

            # First call should fail after retries
            with pytest.raises(WristbandError):
                resolver.get_login_url()

            # Verify we made 3 attempts
            assert total_call_count == 3

            # Second call should succeed (this will be the 4th total call)
            result = resolver.get_redirect_uri()
            assert result == "https://sdk.example.com/callback"
            assert total_call_count == 4  # One more call that succeeded

    def test_config_validation_with_whitespace_values(self):
        """Test config validation handles whitespace-only values correctly."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            parse_tenant_from_root_domain="   ",  # whitespace only
            login_url="https://test.com/login",
        )

        # Should treat whitespace as falsy and not require tenant name placeholder
        resolver = ConfigResolver(config)  # Should not raise
        assert resolver.get_parse_tenant_from_root_domain() == "   "

    def test_sdk_config_fetch_with_delay_and_retry(self):
        """Test SDK config fetch with realistic network delays and retries."""
        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()

            # Simulate network timeouts then success
            def delayed_error_then_success():
                time.sleep(0.05)  # Small delay
                if mock_client.get_sdk_configuration.call_count <= 2:
                    raise Exception("Network timeout")
                return SdkConfiguration(
                    login_url="https://sdk.example.com/login",
                    redirect_uri="https://sdk.example.com/callback",
                    is_application_custom_domain_active=False,
                )

            mock_client.get_sdk_configuration = Mock(side_effect=delayed_error_then_success)
            mock_client_class.return_value = mock_client

            config = AuthConfig(
                client_id="test_client",
                client_secret="test_secret",
                wristband_application_vanity_domain="test.wristband.dev",
            )
            resolver = ConfigResolver(config)

            start_time = time.time()
            result = resolver.get_login_url()
            end_time = time.time()

            # Should succeed on third attempt
            assert result == "https://sdk.example.com/login"
            assert mock_client.get_sdk_configuration.call_count == 3
            # Should have taken some time due to retries and delays
            assert end_time - start_time >= 0.15  # 3 calls * 0.05s delay + retry delays

    def test_concurrent_preload_and_get_requests(self):
        """Test concurrent preload and getter requests with threading."""
        sdk_config = SdkConfiguration(
            login_url="https://sdk.example.com/login",
            redirect_uri="https://sdk.example.com/callback",
            is_application_custom_domain_active=False,
        )

        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()

            # Add delay to simulate network request
            def delayed_response():
                time.sleep(0.1)
                return sdk_config

            mock_client.get_sdk_configuration = Mock(side_effect=delayed_response)
            mock_client_class.return_value = mock_client

            config = AuthConfig(
                client_id="test_client",
                client_secret="test_secret",
                wristband_application_vanity_domain="test.wristband.dev",
            )
            resolver = ConfigResolver(config)

            results = []
            exceptions = []

            def preload_worker():
                try:
                    resolver.preload_sdk_config()  # Returns None
                    results.append(None)
                except Exception as e:
                    exceptions.append(e)

            def getter_worker(method_name):
                try:
                    result = getattr(resolver, method_name)()
                    results.append(result)
                except Exception as e:
                    exceptions.append(e)

            # Start preload and getters concurrently
            threads = [
                threading.Thread(target=preload_worker),
                threading.Thread(target=getter_worker, args=("get_login_url",)),
                threading.Thread(target=getter_worker, args=("get_redirect_uri",)),
            ]

            for thread in threads:
                thread.start()

            for thread in threads:
                thread.join()

            # Should only make one API call
            mock_client.get_sdk_configuration.assert_called_once()
            assert len(exceptions) == 0
            assert len(results) == 3
            # Preload returns None, getters return values
            assert None in results
            assert "https://sdk.example.com/login" in results
            assert "https://sdk.example.com/callback" in results


class TestConfigResolverBackwardCompatibility:
    """Test cases for backward compatibility with {tenant_domain} placeholder."""

    def test_tenant_domain_placeholder_still_works_in_login_url(self):
        """Test that {tenant_domain} placeholder still works for backward compatibility."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            auto_configure_enabled=False,
            login_url="https://{tenant_domain}.test.com/login",
            redirect_uri="https://{tenant_domain}.test.com/callback",
            parse_tenant_from_root_domain="test.com",
            login_state_secret="a" * 32,
        )

        # Should not raise - {tenant_domain} still valid
        resolver = ConfigResolver(config)
        assert resolver is not None

    def test_tenant_domain_placeholder_still_works_in_redirect_uri(self):
        """Test that {tenant_domain} placeholder still works in redirect_uri."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            auto_configure_enabled=False,
            login_url="https://{tenant_domain}.test.com/login",
            redirect_uri="https://{tenant_domain}.test.com/callback",
            parse_tenant_from_root_domain="test.com",
        )

        # Should not raise
        resolver = ConfigResolver(config)
        assert resolver is not None

    def test_mixed_placeholders_not_allowed(self):
        """Test that mixing {tenant_name} and {tenant_domain} is handled."""
        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
            auto_configure_enabled=False,
            login_url="https://{tenant_name}.test.com/login",
            redirect_uri="https://{tenant_domain}.test.com/callback",
            parse_tenant_from_root_domain="test.com",
        )

        # Should not raise - both placeholders are valid
        resolver = ConfigResolver(config)
        assert resolver is not None

    def test_tenant_domain_in_sdk_config_still_works(self):
        """Test that SDK config with {tenant_domain} placeholder still works."""
        sdk_config = SdkConfiguration(
            login_url="https://{tenant_domain}.sdk.example.com/login",
            redirect_uri="https://{tenant_domain}.sdk.example.com/callback",
            is_application_custom_domain_active=False,
            login_url_tenant_domain_suffix="example.com",
        )

        config = AuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            wristband_application_vanity_domain="test.wristband.dev",
        )

        with patch("wristband.django_auth.config_resolver.WristbandApiClient") as mock_client_class:
            mock_client = Mock()
            mock_client.get_sdk_configuration = Mock(return_value=sdk_config)
            mock_client_class.return_value = mock_client

            resolver = ConfigResolver(config)

            # Should not raise validation error
            result = resolver.get_login_url()
            assert result == "https://{tenant_domain}.sdk.example.com/login"
