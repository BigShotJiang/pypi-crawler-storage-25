//! `Solver` — the top-level driver: a phase stack, depth-first search with
//! implicit backtracking. Ported from `rez/src/rez/solver.py` (`Solver`).
//!
//! Backtracking is implicit in the stack: when a phase fails it is pushed; the
//! next step pops and archives it, then resumes the alternative phase beneath
//! (the "without selection" half produced by an earlier `split`).

use super::context::SolverContext;
use super::failure::{FailureReason, SolverStatus};
use super::phase::ResolvePhase;
use super::requirement::{Requirement, RequirementList};
use super::scope::ScopeError;
use super::variant::PackageVariant;
use crate::rez_solver::context::PackageRepo;
use std::rc::Rc;

/// The top-level package solver. Mirrors rez's `Solver`.
pub struct Solver {
    ctx: Rc<SolverContext>,
    phase_stack: Vec<ResolvePhase>,
    failed_phase_list: Vec<ResolvePhase>,
    solve_count: usize,
}

impl Solver {
    /// Create a solver for `package_requests` against `repo`.
    ///
    /// The repository is shared via `Rc`, so resolving many requests against
    /// the same repo never copies it. Fails only if a top-level request names
    /// a package family or version absent from the repository (rez raises too).
    pub fn new(
        package_requests: Vec<Requirement>,
        repo: Rc<PackageRepo>,
    ) -> Result<Self, ScopeError> {
        let request_list = RequirementList::new(package_requests);

        // A conflicting request fails immediately, with no scopes.
        if let Some((req1, req2)) = request_list.conflict() {
            let failure =
                FailureReason::DependencyConflicts(vec![super::failure::DependencyConflict {
                    dependency: req1.clone(),
                    conflicting_request: req2.clone(),
                }]);
            let ctx = Rc::new(SolverContext::new(repo, request_list));
            let phase = ResolvePhase::failed(&ctx, failure);
            return Ok(Solver {
                ctx,
                phase_stack: vec![phase],
                failed_phase_list: Vec::new(),
                solve_count: 0,
            });
        }

        let ctx = Rc::new(SolverContext::new(repo, request_list));
        let phase = ResolvePhase::new(&ctx)?;
        Ok(Solver {
            ctx,
            phase_stack: vec![phase],
            failed_phase_list: Vec::new(),
            solve_count: 0,
        })
    }

    /// The current solver status. Mirrors rez's `Solver.status`.
    pub fn status(&self) -> SolverStatus {
        if self.ctx.request_list.conflict().is_some() {
            return SolverStatus::Failed;
        }
        let st = self.phase_stack.last().unwrap().status;
        if st == SolverStatus::Cyclic {
            SolverStatus::Failed
        } else if self.phase_stack.len() > 1 {
            if st == SolverStatus::Solved {
                SolverStatus::Solved
            } else {
                SolverStatus::Unsolved
            }
        } else if matches!(st, SolverStatus::Pending | SolverStatus::Exhausted) {
            SolverStatus::Unsolved
        } else {
            st
        }
    }

    /// Number of solve steps executed.
    pub fn num_solves(&self) -> usize {
        self.solve_count
    }

    /// Number of failed solve steps.
    pub fn num_fails(&self) -> usize {
        let mut n = self.failed_phase_list.len();
        if matches!(
            self.phase_stack.last().unwrap().status,
            SolverStatus::Failed | SolverStatus::Cyclic
        ) {
            n += 1;
        }
        n
    }

    /// Run the solve to completion. Mirrors rez's `Solver.solve` (without the
    /// callback loop — the port has no solve callbacks).
    pub fn solve(&mut self) {
        while self.status() == SolverStatus::Unsolved {
            self.solve_step();
        }
    }

    /// Perform a single solve step. Mirrors rez's `Solver.solve_step`.
    fn solve_step(&mut self) {
        if self.status() != SolverStatus::Unsolved {
            return;
        }

        let mut phase = self.phase_stack.pop().unwrap();

        // A previously failed phase on top: archive it and take the real
        // unsolved phase beneath — this is the implicit backtrack.
        if phase.status == SolverStatus::Failed {
            self.failed_phase_list.push(phase);
            phase = self.phase_stack.pop().unwrap();
        }

        // An exhausted phase must be split before it can be solved further.
        if phase.status == SolverStatus::Exhausted {
            let (first, next) = phase.split();
            self.phase_stack.push(next);
            phase = first;
        }

        let new_phase = phase.solve();
        self.solve_count += 1;

        match new_phase.status {
            SolverStatus::Failed => self.phase_stack.push(new_phase),
            SolverStatus::Solved => {
                // Solved, but may contain a dependency cycle.
                let final_phase = new_phase.finalise();
                self.phase_stack.push(final_phase);
            }
            SolverStatus::Exhausted => self.phase_stack.push(new_phase),
            other => unreachable!("solve() produced unexpected phase status {other:?}"),
        }
    }

    /// The resolved variants, or `None` if the solve did not succeed.
    pub fn resolved_packages(&self) -> Option<Vec<Rc<PackageVariant>>> {
        if self.status() != SolverStatus::Solved {
            return None;
        }
        Some(self.phase_stack.last().unwrap().solved_variants())
    }

    /// A human-readable failure description, or `None` if the solve did not
    /// fail. Mirrors the gist of rez's `Solver.failure_description`.
    pub fn failure_description(&self) -> Option<String> {
        if self.status() != SolverStatus::Failed {
            return None;
        }
        // The most appropriate failed phase: the current top if it is
        // failed/cyclic, else the first archived failure.
        let top = self.phase_stack.last().unwrap();
        let phase = if matches!(top.status, SolverStatus::Failed | SolverStatus::Cyclic) {
            top
        } else {
            self.failed_phase_list.first().unwrap_or(top)
        };
        Some(match phase.failure_reason() {
            Some(reason) => reason.description(),
            None => "solver failed with unknown reason".to_string(),
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::PackageData;

    fn pkg(requires: &[&str], variants: &[&[&str]]) -> PackageData {
        PackageData {
            requires: requires.iter().map(|s| s.to_string()).collect(),
            variants: variants
                .iter()
                .map(|v| v.iter().map(|s| s.to_string()).collect())
                .collect(),
        }
    }

    fn repo(entries: Vec<(&str, Vec<(&str, PackageData)>)>) -> PackageRepo {
        entries
            .into_iter()
            .map(|(name, versions)| {
                (
                    name.to_string(),
                    versions
                        .into_iter()
                        .map(|(v, d)| (v.to_string(), d))
                        .collect(),
                )
            })
            .collect()
    }

    fn solve(repo: PackageRepo, requests: &[&str]) -> Solver {
        let reqs = requests.iter().map(|s| Requirement::parse(s)).collect();
        let mut solver = Solver::new(reqs, Rc::new(repo)).expect("solver construction");
        solver.solve();
        solver
    }

    fn resolved_set(solver: &Solver) -> Vec<(String, String)> {
        let mut out: Vec<(String, String)> = solver
            .resolved_packages()
            .unwrap()
            .iter()
            .map(|v| (v.name().to_string(), v.version().to_string()))
            .collect();
        out.sort();
        out
    }

    #[test]
    fn test_trivial_single_package() {
        let solver = solve(repo(vec![("foo", vec![("1.0", pkg(&[], &[]))])]), &["foo"]);
        assert_eq!(solver.status(), SolverStatus::Solved);
        assert_eq!(resolved_set(&solver), vec![("foo".into(), "1.0".into())]);
    }

    #[test]
    fn test_picks_highest_version() {
        let solver = solve(
            repo(vec![(
                "foo",
                vec![
                    ("1.0", pkg(&[], &[])),
                    ("2.0", pkg(&[], &[])),
                    ("1.5", pkg(&[], &[])),
                ],
            )]),
            &["foo"],
        );
        assert_eq!(resolved_set(&solver), vec![("foo".into(), "2.0".into())]);
    }

    #[test]
    fn test_transitive_dependency() {
        let solver = solve(
            repo(vec![
                ("app", vec![("1.0", pkg(&["lib-2"], &[]))]),
                (
                    "lib",
                    vec![("1.0", pkg(&[], &[])), ("2.0", pkg(&["base"], &[]))],
                ),
                ("base", vec![("3.0", pkg(&[], &[]))]),
            ]),
            &["app"],
        );
        assert_eq!(solver.status(), SolverStatus::Solved);
        assert_eq!(
            resolved_set(&solver),
            vec![
                ("app".into(), "1.0".into()),
                ("base".into(), "3.0".into()),
                ("lib".into(), "2.0".into()),
            ]
        );
    }

    #[test]
    fn test_version_constraint_intersection() {
        // app needs lib-1+<3, other needs lib<2  =>  lib-1.x
        let solver = solve(
            repo(vec![
                ("app", vec![("1.0", pkg(&["lib-1+<3"], &[]))]),
                ("other", vec![("1.0", pkg(&["lib<2"], &[]))]),
                (
                    "lib",
                    vec![
                        ("1.0", pkg(&[], &[])),
                        ("2.0", pkg(&[], &[])),
                        ("3.0", pkg(&[], &[])),
                    ],
                ),
            ]),
            &["app", "other"],
        );
        assert_eq!(solver.status(), SolverStatus::Solved);
        assert_eq!(
            resolved_set(&solver),
            vec![
                ("app".into(), "1.0".into()),
                ("lib".into(), "1.0".into()),
                ("other".into(), "1.0".into()),
            ]
        );
    }

    #[test]
    fn test_conflict_request_fails() {
        // foo-1 and foo-2 cannot both be satisfied.
        let solver = solve(
            repo(vec![(
                "foo",
                vec![("1.0", pkg(&[], &[])), ("2.0", pkg(&[], &[]))],
            )]),
            &["foo-1", "foo-2"],
        );
        assert_eq!(solver.status(), SolverStatus::Failed);
        assert!(solver.resolved_packages().is_none());
    }

    #[test]
    fn test_unsatisfiable_transitive_fails() {
        // app needs lib-5, but only lib-1 exists.
        let solver = solve(
            repo(vec![
                ("app", vec![("1.0", pkg(&["lib-5"], &[]))]),
                ("lib", vec![("1.0", pkg(&[], &[]))]),
            ]),
            &["app"],
        );
        assert_eq!(solver.status(), SolverStatus::Failed);
    }

    #[test]
    fn test_conflict_requirement_excludes_version() {
        // app pulls lib (any); !lib-2 forbids lib-2  => lib-1.0
        let solver = solve(
            repo(vec![
                ("app", vec![("1.0", pkg(&["lib"], &[]))]),
                ("lib", vec![("1.0", pkg(&[], &[])), ("2.0", pkg(&[], &[]))]),
            ]),
            &["app", "!lib-2"],
        );
        assert_eq!(solver.status(), SolverStatus::Solved);
        assert_eq!(
            resolved_set(&solver),
            vec![("app".into(), "1.0".into()), ("lib".into(), "1.0".into())],
        );
    }

    #[test]
    fn test_weak_reference_does_not_pull_in() {
        // ~lib-1 must NOT pull lib into the resolve on its own.
        let solver = solve(
            repo(vec![
                ("foo", vec![("1.0", pkg(&[], &[]))]),
                ("lib", vec![("1.0", pkg(&[], &[]))]),
            ]),
            &["foo", "~lib-1"],
        );
        assert_eq!(solver.status(), SolverStatus::Solved);
        // only foo is resolved — lib was not requested, only weakly referenced
        assert_eq!(resolved_set(&solver), vec![("foo".into(), "1.0".into())]);
    }

    #[test]
    fn test_variant_selection() {
        // foo has two variants; the solver should pick one and resolve its deps.
        let solver = solve(
            repo(vec![
                (
                    "foo",
                    vec![("1.0", pkg(&[], &[&["maya-2024"], &["maya-2025"]]))],
                ),
                (
                    "maya",
                    vec![("2024.0", pkg(&[], &[])), ("2025.0", pkg(&[], &[]))],
                ),
            ]),
            &["foo"],
        );
        assert_eq!(solver.status(), SolverStatus::Solved);
        let set = resolved_set(&solver);
        assert!(set.contains(&("foo".into(), "1.0".into())));
        // exactly one maya variant was chosen
        assert_eq!(set.iter().filter(|(n, _)| n == "maya").count(), 1);
    }

    #[test]
    fn test_cycle_detection() {
        // a -> b -> a is a dependency cycle.
        let solver = solve(
            repo(vec![
                ("a", vec![("1.0", pkg(&["b"], &[]))]),
                ("b", vec![("1.0", pkg(&["a"], &[]))]),
            ]),
            &["a"],
        );
        assert_eq!(solver.status(), SolverStatus::Failed);
    }
}
