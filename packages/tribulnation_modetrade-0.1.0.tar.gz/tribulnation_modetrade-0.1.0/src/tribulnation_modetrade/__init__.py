"""
### Tribulnation Modetrade
> An SDK to connect Modetrade with the Tribulnation ecosystem.

- Details
"""