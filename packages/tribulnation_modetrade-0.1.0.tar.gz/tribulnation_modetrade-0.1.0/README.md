# Tribulnation Modetrade SDK

> An SDK to connect Modetrade with the Tribulnation ecosystem.

🚧 Under construction.