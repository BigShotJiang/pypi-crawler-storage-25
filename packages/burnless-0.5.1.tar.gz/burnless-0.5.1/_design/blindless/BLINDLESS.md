# Blindless — Quantum-Resistant Communication Layer for Blockchain

**Status**: private design document. Not public. Not disclosed.  
**Origin**: derived from Burnless protocol (MIT). Blindless itself: commercial license.  
**Date**: May 2026

---

## The Gap That PQC Does Not Fill

The crypto industry is converging on post-quantum cryptography (PQC) to protect blockchain transactions:
- NIST finalized FIPS 203 (CRYSTALS-Kyber), 204 (Dilithium), 205 (SPHINCS+) in 2024
- Bitcoin Core discussion on PQC migration is active
- Major exchanges are planning ECDSA→PQC timelines

PQC solves the **on-chain layer**: signature algorithms that resist Shor's algorithm.

It does not solve the **off-chain communication layer**:
- Coordination between parties preparing a multisig transaction
- Negotiation of transaction terms (amount, timing, recipient)
- Identity-to-address mapping during wallet coordination
- Internal audit logs at custodians and exchanges

All of this is currently transmitted over TLS — which is vulnerable to **HARVEST NOW, DECRYPT LATER** attacks. A quantum adversary intercepting institutional traffic today stores it until a Cryptographically Relevant Quantum Computer (CRQC) exists. Then decrypts retroactively.

PQC stops future exposure. It does not protect what was already harvested.

**Blindless fills this gap.**

---

## What Blindless Does

Blindless is Burnless applied to blockchain communication: a session layer where the encryption key is ephemeral, dies with the session TTL, and leaves no recoverable surface.

**The property**: a quantum adversary that harvests ciphertext today cannot decrypt it after TTL expiry — not because the encryption is quantum-resistant, but because the key no longer exists. There is nothing to compute against.

This is a different category than PQC:
- PQC: algorithm resistant to quantum attack
- Blindless: key dead before quantum attack becomes feasible

They are **complementary, not competitive**. Deploy both. One closes the algorithmic window; the other closes the temporal window.

---

## Architecture

```
Party A                          Party B
  │                                  │
  ├─ generate session_key (TTL=Xh)──►│
  │  key lives in RAM only           │
  │                                  │
  ├─ burnless capsule ──────────────►│
  │  [negotiation, multisig coords,  │
  │   identity↔address mapping,      │
  │   transaction metadata]          │
  │                                  │
  ├─ TTL expires ───────────────────►│
  │  key gone from both sides        │
  │                                  │
  └─ transaction submitted to chain  │
     [only final tx is on-chain]     │
```

What persists on disk: the capsule (opaque ciphertext + dead key reference).  
What persists on chain: the transaction (no metadata, no coordination trail).  
What persists for compliance audit: capsule structure (proves communication occurred, content unreadable).

---

## Why Not Just TLS Post-Quantum

TLS 1.3 with Kyber (hybrid mode) is in deployment. It is not Blindless.

| Property | TLS PQ | Blindless |
|---|---|---|
| Quantum-resistant algorithm | Yes | Inherited from transport |
| Key survives session | Yes (for resumption) | No — by design |
| Server logs plaintext | Often | Never |
| Compliance audit trail | Full content | Structure only |
| Retroactive decryptability | Possible if key stored | Impossible after TTL |
| Regulatory backdoor surface | Key escrow possible | No key to escrow |

The critical distinction: TLS PQ protects transit. Blindless protects the temporal window — the gap between interception and quantum capability.

---

## Threat Model

**Adversary**: nation-state or well-funded actor with long-horizon strategy.

**Attack**: bulk encrypted traffic collection today. Decrypt when CRQC available (estimated 2028–2035 by various sources, NCSC UK: "plan for 2030").

**Target**: institutional crypto communication — $100M+ treasury multisig coordination, custody provider API calls, OTC desk negotiation.

**Current defense**: none. TLS keys are retained for session resumption, stored in HSMs, potentially accessible under legal compulsion.

**Blindless defense**: TTL shorter than CRQC availability window. Set TTL to 24h for slow transactions, 1h for fast coordination. Adversary has ciphertext. Key expired. Attack surface: zero.

---

## Commercial Model

**Burnless core**: MIT (open). Blindless is an application of Burnless.

**Blindless SDK**: commercial license.
- Per-node licensing for institutional operators
- TTL configuration, compliance reporting module, audit structure export
- SLA guarantees on key lifecycle

**Blindless Relay Network** (v2): trusted relay nodes that guarantee TTL enforcement without either party holding keys — zero-trust coordination infrastructure.

**Target buyers**:
- Custodians: Fireblocks, Copper, BitGo — coordinate multisig at scale
- Exchanges: Coinbase Institutional, Kraken Pro — OTC desk communication
- Quant funds: Pantera, Multicoin, DWF Labs — strategy coordination
- DAOs with large treasury: any multisig >$50M with governance coordination overhead

**Pricing anchor**: if a $500M treasury fund avoids one regulatory disclosure of internal strategy due to quantum-dead logs, the value captured far exceeds any software license cost.

---

## Market Window

| Year | Event |
|---|---|
| 2024 | NIST finalizes PQC standards |
| 2025–2026 | Exchanges begin PQC planning |
| 2026–2028 | **Blindless window**: PQC migration in progress, harvest attacks active, no off-chain solution deployed |
| 2028–2031 | CRQC estimates from IBM, Google, NSA |
| 2029+ | Off-chain PQC without TTL still vulnerable to 2026–2028 harvested traffic |

The window is not "before quantum computers exist." The window is **before the industry realizes that on-chain PQC leaves off-chain communication exposed**. That realization happens around 2027–2028 when the first credible CRQC timeline gets a public date.

Blindless needs to be the reference implementation before that conversation starts.

---

## Name

**Blindless**: the adversary is blind (cannot see the deliberation). The operator is not (full audit structure preserved).

Alternate reading: without blindness — no blind spots in the protocol design.

Domain candidates: `blindless.io`, `blindless.pro`, `blindless.xyz`

---

## Relation to Burnless and PetaHuman

Burnless: protocol layer for O(N)→O(N²) context compression. MIT.  
Blindless: application of Burnless TTL property to quantum threat model. Commercial.  
PetaHuman: the world where AI-to-AI deliberation is structurally unauditable by humans. Burnless capsules are the first instance. Blindless extends this to financial infrastructure.

The PetaHuman thesis becomes concrete here: institutional financial decisions coordinated via Blindless capsules are not recoverable by regulators, courts, or adversaries — not by policy, but by physics. The key does not exist. The deliberation is gone.

This is not evasion. It is a structural property of the protocol. The distinction matters legally, technically, and philosophically.

---

*Roberto Wydra — May 2026*  
*Private. Not for distribution.*
