# Brief Codex — Burnless v0.5.1 release prep

## Contexto

Burnless está em v0.5.0 no PyPI + GitHub público (https://github.com/Rudekwydra/burnless). O commit `e1f3fbe` (já no main, já push'ed) adicionou 2 features que merecem release v0.5.1:

1. **Friendly mode V1** — decoder agora preserva tom/voz do usuário na resposta. Default ON via `compression.voice_match: true`. Comando `/voice on|off` no shell. ~5% extra tokens, UX muito mais quente.
2. **Init UX fix** — quando rodar `burnless init` em projeto já inicializado, mostra mensagem amigável sugerindo `burnless` (entrar shell). README clarificado: setup já cobre init.

Detalhes em `~/.claude/projects/-Users-roberto/memory/project_burnless_friendly_mode.md`.

## Sua tarefa (autônomo, sem perguntar)

Trabalha em `/Users/roberto/antigravity/burnless`.

1. **Bump version pra 0.5.1**
   - Editar `pyproject.toml` (campo `version`)
   - Se houver `src/burnless/__init__.py` com `__version__`, atualizar também
   - Se houver `src/burnless/_version.py` ou similar, idem

2. **Adicionar/criar CHANGELOG.md** entry pra v0.5.1
   - Se já existir CHANGELOG.md, prepende. Se não, cria com header padrão (Keep a Changelog format).
   - Conteúdo:
     ```
     ## [0.5.1] — 2026-05-03
     ### Added
     - Friendly mode V1: decoder mirrors user's tone/slang/register in replies (default ON, ~5% extra tokens). Toggle via `/voice on|off` in shell or `compression.voice_match` in config.yaml.
     ### Changed
     - `burnless init` in already-initialized project shows friendly hint instead of bare warning.
     - README: clarified that `burnless setup` covers init; documented `rm -rf .burnless/` as uninstall path.
     ```

3. **Rodar testes** (se existirem)
   - `pytest -q` ou `python -m pytest tests/` (descobrir o command)
   - Se passarem todos, prossegue. Se algum falhar, ABORTAR e gravar o erro em `_codex_run.log`.

4. **Build sdist + wheel** (NÃO upload pro PyPI — Roberto faz manual)
   - `python -m pip install --quiet --upgrade build` (se não tiver)
   - `python -m build`
   - Confirmar que `dist/burnless-0.5.1.tar.gz` e `dist/burnless-0.5.1-py3-none-any.whl` existem

5. **Commit + tag**
   - `git add` arquivos modificados (pyproject, __init__, CHANGELOG.md, dist/* se for tracked — provavelmente não é)
   - `git commit -m "Release v0.5.1 — Friendly mode V1 + init UX"` (sem co-author trailer)
   - `git tag -a v0.5.1 -m "v0.5.1 — Friendly mode V1"`
   - **NÃO faça push automático.** Deixa pro Roberto revisar e dar `git push --tags`.

6. **Log tudo em `_codex_run.log`** no diretório do projeto:
   - O que você fez em cada passo
   - Output dos testes
   - Build artifacts gerados
   - Mensagem final: "Ready for `git push origin main --tags` + `twine upload dist/burnless-0.5.1*`"

## Restrições

- **Não use rede externa** além do necessário pra `pip install build` (sandbox workspace-write deve permitir)
- **NÃO publique no PyPI** — apenas prepare. Roberto faz upload manual.
- **NÃO push pro GitHub** — apenas commit + tag local.
- **Se algo falhar em qualquer passo**, ABORTA, grava o erro completo no log, e sai com exit 1.

Quando terminar, o resultado final esperado:
- Working tree limpo (com mudanças commitadas)
- Tag local `v0.5.1`
- `dist/burnless-0.5.1.tar.gz` + `.whl` prontos pra upload
- `_codex_run.log` com summary completo
