from __future__ import annotations

from typing import Any

from ..http import HttpClient
from ..types import MessageDetails, SendMessageAccepted, SendMessageInput


class MessagesResource:
    def __init__(self, http: HttpClient):
        self._http = http

    def send(self, input: SendMessageInput) -> SendMessageAccepted:
        body: dict[str, Any] = {
            "templateId": input["templateId"],
            "destinationNumber": input["destinationNumber"],
            "variables": input.get("variables") or {},
        }
        return self._http.request_json(method="POST", path="/v1/messages/send", body=body)

    def get(self, id: str) -> MessageDetails:
        return self._http.request_json(method="GET", path=f"/v1/messages/{id}")
