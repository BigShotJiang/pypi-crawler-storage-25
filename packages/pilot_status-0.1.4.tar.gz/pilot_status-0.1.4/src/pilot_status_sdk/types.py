from __future__ import annotations

from typing import Literal, TypedDict

Environment = Literal["TEST", "LIVE"]

MessageStatus = Literal["QUEUED", "SENT", "DELIVERED", "FAILED", "READ"]


class SendMessageInput(TypedDict, total=False):
    templateId: str
    destinationNumber: str
    variables: dict[str, str]


class SendMessageAccepted(TypedDict):
    id: str
    correlationId: str
    status: MessageStatus
    createdAt: str
    origin: str


class MessageDetails(TypedDict):
    id: str
    status: MessageStatus
    correlationId: str
    destinationNumber: str
    template: str
    createdAt: str
    sentAt: str | None
    deliveredAt: str | None
    readAt: str | None
    errorMessage: str | None


class DashboardDailyMessages(TypedDict):
    date: str
    count: int


class DashboardStatusDistribution(TypedDict):
    queued: int
    sent: int
    delivered: int
    failed: int
    read: int


class DashboardStats(TypedDict):
    totalSent: int
    totalFailed: int
    sentPercentChange: float
    failedPercentChange: float
    failureRate: float
    dailyMessages: list[DashboardDailyMessages]
    statusDistribution: DashboardStatusDistribution

