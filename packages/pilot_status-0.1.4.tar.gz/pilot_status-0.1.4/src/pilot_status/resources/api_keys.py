from __future__ import annotations

from typing import Any

from ..http import HttpClient
from ..types import ApiKeyCreateInput, ApiKeyCreated, ApiKeyListItem


class ApiKeysResource:
    def __init__(self, http: HttpClient):
        self._http = http

    def list(self) -> list[ApiKeyListItem]:
        return self._http.request_json(method="GET", path="/v1/api-keys")

    def create(self, input: ApiKeyCreateInput) -> ApiKeyCreated:
        body: dict[str, Any] = {"name": input["name"]}
        if "webhookId" in input:
            body["webhookId"] = input["webhookId"]
        if "whatsappInstanceId" in input:
            body["whatsappInstanceId"] = input["whatsappInstanceId"]
        if "retentionDays" in input:
            body["retentionDays"] = input["retentionDays"]
        return self._http.request_json(method="POST", path="/v1/api-keys", body=body)
