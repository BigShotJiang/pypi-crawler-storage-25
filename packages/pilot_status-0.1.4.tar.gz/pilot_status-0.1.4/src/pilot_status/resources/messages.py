from __future__ import annotations

from typing import Any

from ..http import HttpClient
from ..types import MessageDetails, OptInCheckResult, SendMessageAccepted, SendMessageInput


class MessagesResource:
    def __init__(self, http: HttpClient):
        self._http = http

    def send(self, input: SendMessageInput) -> SendMessageAccepted:
        body: dict[str, Any] = {
            "templateId": input["templateId"],
            "destinationNumber": input["destinationNumber"],
            "variables": input.get("variables") or {},
        }
        if "deliverAt" in input:
            body["deliverAt"] = input["deliverAt"]
        if "deliverUntil" in input:
            body["deliverUntil"] = input["deliverUntil"]
        return self._http.request_json(method="POST", path="/v1/messages/send", body=body)

    def get(self, id: str) -> MessageDetails:
        return self._http.request_json(method="GET", path=f"/v1/messages/{id}")

    def check_opt_in(self, destination_number: str) -> OptInCheckResult:
        return self._http.request_json(
            method="GET",
            path="/v1/messages/opt-in",
            query={"destinationNumber": destination_number},
        )
