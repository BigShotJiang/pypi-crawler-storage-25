from __future__ import annotations

from typing import Literal, Optional, TypedDict, Union

from typing_extensions import NotRequired

from ..types import Environment


class MessageSentData(TypedDict):
    messageId: Optional[str]
    internalMessageId: str
    correlationId: NotRequired[str]
    environment: Environment
    destinationNumber: str
    content: str
    status: Literal["SENT"]
    sentAt: str


class MessageSentEvent(TypedDict):
    event: Literal["message.sent"]
    data: MessageSentData


class MessageDeliveredData(TypedDict):
    messageId: Optional[str]
    internalMessageId: str
    correlationId: NotRequired[str]
    environment: Environment
    destinationNumber: str
    content: str
    status: Literal["DELIVERED"]
    deliveredAt: str


class MessageDeliveredEvent(TypedDict):
    event: Literal["message.delivered"]
    data: MessageDeliveredData


class MessageReadData(TypedDict):
    messageId: Optional[str]
    internalMessageId: str
    correlationId: NotRequired[str]
    environment: Environment
    destinationNumber: str
    content: str
    status: Literal["READ"]
    readAt: str


class MessageReadEvent(TypedDict):
    event: Literal["message.read"]
    data: MessageReadData


class MessageFailedData(TypedDict):
    messageId: Optional[str]
    internalMessageId: str
    correlationId: NotRequired[str]
    environment: Environment
    destinationNumber: str
    content: str
    status: Literal["FAILED"]
    failedAt: str
    errorMessage: str


class MessageFailedEvent(TypedDict):
    event: Literal["message.failed"]
    data: MessageFailedData


MessageReplyData = TypedDict(
    "MessageReplyData",
    {
        "from": str,
        "destinationNumber": str,
        "content": str,
        "replyContent": str,
        "receivedAt": str,
        "messageId": Optional[str],
        "quotedMessageId": Optional[str],
        "messageRepliedId": Optional[str],
        "correlationId": NotRequired[str],
        "environment": Environment,
        "buttonId": Optional[str],
    },
)


MessageReplyEvent = TypedDict(
    "MessageReplyEvent",
    {
        "event": Literal["message.reply"],
        "data": MessageReplyData,
    },
)

MessageReceivedData = TypedDict(
    "MessageReceivedData",
    {
        "fromMe": bool,
        "from": str,
        "fromName": Optional[str],
        "destinationNumber": str,
        "content": str,
        "receivedAt": str,
        "messageId": Optional[str],
        "correlationId": NotRequired[str],
        "environment": Environment,
        "whatsappInstanceName": Optional[str],
    },
)


MessageReceivedEvent = TypedDict(
    "MessageReceivedEvent",
    {
        "event": Literal["message.received"],
        "data": MessageReceivedData,
    },
)


MessageGroupData = TypedDict(
    "MessageGroupData",
    {
        "fromNumber": Optional[str],
        "fromName": Optional[str],
        "fromMe": bool,
        "groupName": Optional[str],
        "content": str,
        "environment": Environment,
        "messageId": Optional[str],
    },
)


MessageGroupEvent = TypedDict(
    "MessageGroupEvent",
    {
        "event": Literal["message.group"],
        "data": MessageGroupData,
    },
)


class OptinCreatedData(TypedDict):
    projectId: str
    environment: Environment
    whatsappInstanceName: str
    destinationNumber: str
    destinationHash: str
    isFirstOptIn: bool
    firstOptInAt: str
    lastSeenAt: str
    fromName: NotRequired[Optional[str]]


class OptinCreatedEvent(TypedDict):
    event: Literal["optin.created"]
    data: OptinCreatedData


class NumberCreatedData(TypedDict):
    numberId: str
    whatsappInstanceName: str
    displayName: str
    number: str
    status: str
    createdAt: str
    environment: Environment


class NumberCreatedEvent(TypedDict):
    event: Literal["number.created"]
    data: NumberCreatedData


class NumberConnectedData(TypedDict):
    numberId: str
    whatsappInstanceName: str
    displayName: str
    number: Optional[str]
    previousState: str
    nextState: str
    connectedAt: str
    environment: Environment


class NumberConnectedEvent(TypedDict):
    event: Literal["number.connected"]
    data: NumberConnectedData


class NumberDisconnectedData(TypedDict):
    numberId: str
    whatsappInstanceName: str
    displayName: str
    number: Optional[str]
    source: Literal["healthcheck"]
    previousState: str
    nextState: str
    connectionState: Optional[str]
    presenceStatus: int
    disconnectedAt: str
    environment: Environment


class NumberDisconnectedEvent(TypedDict):
    event: Literal["number.disconnected"]
    data: NumberDisconnectedData


class NumberRemovedData(TypedDict):
    numberId: str
    whatsappInstanceName: str
    displayName: str
    number: str
    previousState: str
    removedAt: str
    environment: Environment


class NumberRemovedEvent(TypedDict):
    event: Literal["number.removed"]
    data: NumberRemovedData


CustomerWebhookEvent = Union[
    MessageSentEvent,
    MessageDeliveredEvent,
    MessageReadEvent,
    MessageFailedEvent,
    MessageReplyEvent,
    MessageReceivedEvent,
    MessageGroupEvent,
    OptinCreatedEvent,
    NumberCreatedEvent,
    NumberConnectedEvent,
    NumberDisconnectedEvent,
    NumberRemovedEvent,
]
