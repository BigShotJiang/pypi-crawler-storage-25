from __future__ import annotations

from typing import Callable

import urllib.request

from .http import HttpClient, HttpClientOptions
from .resources import AnalyticsResource, ApiKeysResource, MessagesResource, NumbersResource, ProjectsResource


class PilotStatusClient:
    def __init__(
        self,
        *,
        api_key: str,
        timeout_s: float = 30.0,
        user_agent: str | None = None,
        get_retries: int = 2,
        transport: Callable[[urllib.request.Request, float], tuple[int, dict[str, str], str]] | None = None,
    ):
        base_url = "https://pilotstatus.online"
        http = HttpClient(
            HttpClientOptions(
                base_url=base_url,
                api_key=api_key,
                timeout_s=timeout_s,
                user_agent=user_agent,
                get_retries=get_retries,
                transport=transport,
            )
        )
        self.messages = MessagesResource(http)
        self.analytics = AnalyticsResource(http)
        self.projects = ProjectsResource(http)
        self.api_keys = ApiKeysResource(http)
        self.numbers = NumbersResource(http)
