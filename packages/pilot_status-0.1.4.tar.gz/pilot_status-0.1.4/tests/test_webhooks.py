import unittest

from pilot_status.webhooks.parse import WebhookParseError, is_customer_webhook_event, parse_customer_webhook


class TestWebhooks(unittest.TestCase):
    def test_parse_message_failed(self):
        payload = {
            "event": "message.failed",
            "data": {
                "messageId": "m_123",
                "internalMessageId": "ps_123",
                "correlationId": "corr_1",
                "environment": "TEST",
                "destinationNumber": "+5511999999999",
                "content": "hello",
                "status": "FAILED",
                "failedAt": "2026-01-01T00:00:00.000Z",
                "errorMessage": "oops",
            },
        }
        event = parse_customer_webhook(payload)
        self.assertEqual(event["event"], "message.failed")
        self.assertEqual(event["data"]["status"], "FAILED")
        self.assertEqual(event["data"]["correlationId"], "corr_1")

    def test_is_customer_webhook_event_true(self):
        payload = {
            "event": "message.sent",
            "data": {
                "messageId": "m_123",
                "internalMessageId": "ps_123",
                "environment": "LIVE",
                "destinationNumber": "+5511999999999",
                "content": "hello",
                "status": "SENT",
                "sentAt": "2026-01-01T00:00:00.000Z",
            },
        }
        self.assertTrue(is_customer_webhook_event(payload))

    def test_parse_message_received(self):
        payload = {
            "event": "message.received",
            "data": {
                "fromMe": False,
                "from": "5511999999999",
                "environment": "LIVE",
                "destinationNumber": "5511888888888",
                "content": "oi",
                "receivedAt": "2026-01-01T00:00:00.000Z",
                "messageId": "msg_in_1",
                "correlationId": "corr_rcv",
            },
        }
        event = parse_customer_webhook(payload)
        self.assertEqual(event["event"], "message.received")
        self.assertEqual(event["data"]["fromMe"], False)
        self.assertEqual(event["data"]["correlationId"], "corr_rcv")

    def test_parse_optin_created(self):
        payload = {
            "event": "optin.created",
            "data": {
                "projectId": "p_1",
                "environment": "LIVE",
                "whatsappInstanceName": "Pilot Status",
                "destinationNumber": "",
                "destinationHash": "hash",
                "fromName": "Contato",
                "isFirstOptIn": True,
                "firstOptInAt": "2026-01-01T00:00:00.000Z",
                "lastSeenAt": "2026-01-01T00:00:00.000Z",
            },
        }
        event = parse_customer_webhook(payload)
        self.assertEqual(event["event"], "optin.created")
        self.assertEqual(event["data"]["projectId"], "p_1")
        self.assertEqual(event["data"]["fromName"], "Contato")

    def test_parse_optin_created_without_from_name(self):
        payload = {
            "event": "optin.created",
            "data": {
                "projectId": "p_1",
                "environment": "LIVE",
                "whatsappInstanceName": "Pilot Status",
                "destinationNumber": "+5511999999999",
                "destinationHash": "hash",
                "isFirstOptIn": False,
                "firstOptInAt": "2026-01-01T00:00:00.000Z",
                "lastSeenAt": "2026-01-01T00:00:00.000Z",
            },
        }
        event = parse_customer_webhook(payload)
        self.assertEqual(event["event"], "optin.created")
        self.assertNotIn("fromName", event["data"])

    def test_parse_message_group(self):
        payload = {
            "event": "message.group",
            "data": {
                "fromNumber": "5511999999999",
                "fromName": "Ismael Ash",
                "fromMe": False,
                "groupName": "My Group",
                "content": "Boa",
                "environment": "LIVE",
                "messageId": "k_in",
            },
        }
        event = parse_customer_webhook(payload)
        self.assertEqual(event["event"], "message.group")
        self.assertEqual(event["data"]["groupName"], "My Group")

    def test_parse_invalid_payload_raises(self):
        with self.assertRaises(WebhookParseError) as ctx:
            parse_customer_webhook({"event": "message.sent", "data": {}})
        self.assertGreaterEqual(len(ctx.exception.issues), 1)

    def test_parse_number_created(self):
        payload = {
            "event": "number.created",
            "data": {
                "numberId": "n1",
                "whatsappInstanceName": "PS-t1-abc",
                "displayName": "Main",
                "number": "5511999999999",
                "status": "CONNECTING",
                "createdAt": "2026-01-01T00:00:00.000Z",
                "environment": "TEST",
            },
        }
        event = parse_customer_webhook(payload)
        self.assertEqual(event["event"], "number.created")
        self.assertEqual(event["data"]["numberId"], "n1")

    def test_parse_number_disconnected(self):
        payload = {
            "event": "number.disconnected",
            "data": {
                "numberId": "n1",
                "whatsappInstanceName": "PS-t1-abc",
                "displayName": "Main",
                "number": "5511999999999",
                "source": "healthcheck",
                "previousState": "OPEN",
                "nextState": "CLOSE",
                "connectionState": "close",
                "presenceStatus": 500,
                "disconnectedAt": "2026-01-01T00:00:00.000Z",
                "environment": "LIVE",
            },
        }
        event = parse_customer_webhook(payload)
        self.assertEqual(event["event"], "number.disconnected")
        self.assertEqual(event["data"]["source"], "healthcheck")


if __name__ == "__main__":
    unittest.main()
