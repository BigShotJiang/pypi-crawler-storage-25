"""Promptree exception hierarchy."""


class PromptreeError(Exception):
    """Base class for promptree errors."""


class AmbiguousTemplateError(PromptreeError):
    """Raised when multiple template files match the same attribute."""


class TemplateNotFoundError(PromptreeError):
    """Raised when no matching template or directory is found."""


__all__ = [
    "PromptreeError",
    "AmbiguousTemplateError",
    "TemplateNotFoundError",
]
