"""Module entrypoint for ``python -m promptree``."""

from promptree._cli import main


raise SystemExit(main())
