"""Root entry point for promptree."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import jinja2

from promptree._node import SUPPORTED_EXTENSIONS, TemplateNode


class Promptree(TemplateNode):
    """Root prompt tree backed by a Jinja environment."""

    def __init__(
        self,
        path: str | Path,
        *,
        extensions: tuple[str, ...] = SUPPORTED_EXTENSIONS,
        globals: dict[str, Any] | None = None,
    ):
        path = Path(path).resolve()
        if not path.is_dir():
            raise NotADirectoryError(f"Prompt directory not found: {path}")

        env = jinja2.Environment(
            loader=jinja2.FileSystemLoader(str(path)),
            undefined=jinja2.StrictUndefined,
            keep_trailing_newline=True,
        )
        if globals:
            env.globals.update(globals)

        super().__init__(
            env=env,
            base_path=path,
            rel_prefix="",
            extensions=extensions,
        )

    def __getattr__(self, name: str) -> Any:
        """Treat the root object as dynamic for static analyzers.

        The raw ``Promptree`` API resolves attributes from the filesystem at runtime,
        so editors cannot know whether a given child is a directory node or a template
        callable. Returning ``Any`` here avoids false-positive "not callable" errors
        for direct ``Promptree(...)`` usage. Consumers that want precise IDE typing
        should use ``promptree generate`` and import the generated package instead.
        """
        return super().__getattr__(name)

    def __repr__(self) -> str:
        return f"Promptree({self._base_path})"


__all__ = ["Promptree"]
