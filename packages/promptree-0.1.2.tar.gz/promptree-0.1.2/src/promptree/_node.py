"""Directory node wrapper for promptree templates."""

from __future__ import annotations

from pathlib import Path

import jinja2

from promptree._exceptions import AmbiguousTemplateError, TemplateNotFoundError
from promptree._template import TemplateCallable


SUPPORTED_EXTENSIONS = (".jinja", ".j2", ".md", ".txt", ".html", ".xml")


class TemplateNode:
    """Represents a template directory."""

    def __init__(
        self,
        env: jinja2.Environment,
        base_path: Path,
        rel_prefix: str,
        extensions: tuple[str, ...],
    ):
        self._env = env
        self._base_path = base_path
        self._rel_prefix = rel_prefix
        self._extensions = extensions

    def __getattr__(self, name: str) -> TemplateNode | TemplateCallable:
        if name.startswith("_"):
            raise AttributeError(name)

        dir_path = self._base_path / name
        matches = self._template_matches(name)

        if dir_path.is_dir() and matches:
            raise AmbiguousTemplateError(
                f"'{name}' matches both a directory and template files: {[m.name for m in matches]}. "
                "Rename the directory or files to remove ambiguity."
            )

        if dir_path.is_dir():
            node = TemplateNode(
                self._env,
                dir_path,
                f"{self._rel_prefix}{name}/",
                self._extensions,
            )
            self.__dict__[name] = node
            return node

        if len(matches) > 1:
            raise AmbiguousTemplateError(
                f"'{name}' matches multiple files: {[m.name for m in matches]}. "
                "Rename files to remove ambiguity."
            )
        if not matches:
            raise TemplateNotFoundError(f"No template or directory '{name}' in {self._base_path}")

        rel_path = f"{self._rel_prefix}{matches[0].name}"
        tpl = TemplateCallable(self._env, rel_path, matches[0])
        self.__dict__[name] = tpl
        return tpl

    def __dir__(self) -> list[str]:
        """Enable tab-completion in interactive shells."""
        directory_names: set[str] = set()
        template_matches: dict[str, list[Path]] = {}

        for child in self._base_path.iterdir():
            if child.name.startswith(("_", ".")):
                continue
            if child.is_dir():
                directory_names.add(child.name)
            elif child.is_file() and child.suffix in self._extensions:
                template_matches.setdefault(child.stem, []).append(child)

        items: set[str] = set()
        for name in sorted(directory_names | template_matches.keys()):
            if name in directory_names and name in template_matches:
                continue
            if len(template_matches.get(name, [])) > 1:
                continue
            items.add(name)
        return sorted(items)

    def __repr__(self) -> str:
        return f"TemplateNode({self._base_path.name}/, children={list(self.__dir__())})"

    def _template_matches(self, name: str) -> list[Path]:
        matches: list[Path] = []
        for ext in self._extensions:
            candidate = self._base_path / f"{name}{ext}"
            if candidate.is_file():
                matches.append(candidate)
        return matches


__all__ = ["SUPPORTED_EXTENSIONS", "TemplateNode"]
