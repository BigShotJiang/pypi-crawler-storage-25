"""Template callable wrapper."""

from __future__ import annotations

from functools import cached_property
from pathlib import Path
from typing import Any

import jinja2
from jinja2 import meta


class TemplateCallable:
    """Represents a single template file as a callable object."""

    def __init__(self, env: jinja2.Environment, rel_path: str, file_path: Path):
        self._env = env
        self._rel_path = rel_path
        self._file_path = file_path
        self._template = env.get_template(rel_path)

    def __call__(self, **kwargs: Any) -> str:
        return self._template.render(**kwargs)

    @cached_property
    def variables(self) -> frozenset[str]:
        """Return undeclared variables referenced by the template source."""
        loader = self._env.loader
        if loader is None:
            raise RuntimeError("TemplateCallable.variables requires an environment with a loader")

        source, _, _ = loader.get_source(self._env, self._rel_path)
        ast = self._env.parse(source)
        return frozenset(meta.find_undeclared_variables(ast))

    def __repr__(self) -> str:
        return f"TemplateCallable({self._file_path.name}, vars={set(self.variables)})"


__all__ = ["TemplateCallable"]
