"""Tests for individual template callables."""

from __future__ import annotations

import pytest
from jinja2 import UndefinedError


def test_template_callable_renders_with_variables(basic_tree) -> None:
    """Templates with declared variables should render correctly."""
    system = basic_tree.system
    assert system.variables == frozenset({"name"})
    assert repr(system) == "TemplateCallable(system.md, vars={'name'})"
    assert system(name="Claude") == "System prompt for Claude.\n"

    greeting = basic_tree.user.greeting
    assert greeting(name="Tim") == "Hello Tim!\n"

    farewell = basic_tree.user.farewell
    assert farewell(name="Tim") == "Goodbye Tim.\n"


def test_template_callable_without_variables(no_vars_tree) -> None:
    """Templates without variables should still be callable with no args."""
    static = no_vars_tree.static
    assert static.variables == frozenset()
    assert repr(static) == "TemplateCallable(static.md, vars=set())"
    assert static() == "Static prompt.\n"


def test_template_callable_raises_for_missing_variables(basic_tree) -> None:
    """StrictUndefined should surface missing variables at render time."""
    with pytest.raises(UndefinedError):
        basic_tree.system()


def test_jinja_extends_and_include_render(jinja_features_tree) -> None:
    """Jinja inheritance and includes should render through the template loader."""
    rendered = jinja_features_tree.child(title="Header", body="Section")

    assert "Base start" in rendered
    assert "Header: Header" in rendered
    assert "Child body: Section" in rendered
    assert "Base end" in rendered
