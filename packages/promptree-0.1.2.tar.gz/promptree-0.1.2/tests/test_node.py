"""Tests for template directory nodes."""

from __future__ import annotations

from pathlib import Path

import pytest

from promptree import AmbiguousTemplateError, Promptree, TemplateCallable, TemplateNode, TemplateNotFoundError


def test_getattr_resolves_directories_and_templates(basic_tree) -> None:
    """Directory names should resolve to TemplateNode instances and files to TemplateCallable."""
    user = basic_tree.user
    assert isinstance(user, TemplateNode)
    assert basic_tree.user is user

    greeting = user.greeting
    assert isinstance(greeting, TemplateCallable)
    assert user.greeting is greeting
    assert repr(user) == "TemplateNode(user/, children=['farewell', 'greeting'])"


def test_dir_lists_child_names(basic_tree) -> None:
    """__dir__ should expose accessible child names in sorted order."""
    assert dir(basic_tree) == ["system", "user"]
    assert dir(basic_tree.user) == ["farewell", "greeting"]


def test_ambiguous_template_raises(ambiguous_tree) -> None:
    """Multiple matching extensions should raise a hard error."""
    with pytest.raises(AmbiguousTemplateError, match="matches multiple files"):
        ambiguous_tree.prompt


def test_missing_template_raises(basic_tree) -> None:
    """Missing files and directories should raise TemplateNotFoundError."""
    with pytest.raises(TemplateNotFoundError, match="No template or directory 'missing'"):
        basic_tree.missing


def test_private_names_are_not_resolved(basic_tree) -> None:
    """Internal attribute names should not be routed through template lookup."""
    with pytest.raises(AttributeError):
        getattr(basic_tree, "_private")


def test_directory_and_file_name_collision_is_ambiguous(tmp_path: Path) -> None:
    """A directory and template file sharing a stem should be treated as ambiguous."""
    prompt_dir = tmp_path / "prompts"
    prompt_dir.mkdir()
    (prompt_dir / "prompt").mkdir()
    (prompt_dir / "prompt.md").write_text("Hello {{ name }}!\n", encoding="utf-8")

    tree = Promptree(prompt_dir)

    assert "prompt" not in dir(tree)
    with pytest.raises(AmbiguousTemplateError, match="matches both a directory and template files"):
        tree.prompt
