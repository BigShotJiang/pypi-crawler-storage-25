"""Shared pytest fixtures for promptree tests."""

from __future__ import annotations

from pathlib import Path

import pytest

from promptree import Promptree


@pytest.fixture(scope="session")
def fixtures_dir() -> Path:
    """Return the root directory for test prompt fixtures."""
    return Path(__file__).resolve().parent / "fixtures"


@pytest.fixture()
def basic_tree(fixtures_dir: Path) -> Promptree:
    """Prompt tree backed by the basic fixture set."""
    return Promptree(fixtures_dir / "basic")


@pytest.fixture()
def ambiguous_tree(fixtures_dir: Path) -> Promptree:
    """Prompt tree with an intentionally ambiguous template stem."""
    return Promptree(fixtures_dir / "ambiguous")


@pytest.fixture()
def no_vars_tree(fixtures_dir: Path) -> Promptree:
    """Prompt tree with a static template."""
    return Promptree(fixtures_dir / "no_vars")


@pytest.fixture()
def jinja_features_tree(fixtures_dir: Path) -> Promptree:
    """Prompt tree exercising extends and include support."""
    return Promptree(fixtures_dir / "jinja_features")
