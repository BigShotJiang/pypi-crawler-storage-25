System prompt for {{ name }}.
