Static prompt.
