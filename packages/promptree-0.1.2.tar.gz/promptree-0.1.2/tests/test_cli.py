"""Tests for the promptree CLI."""

from __future__ import annotations

import shutil
from pathlib import Path

from promptree._cli import _DebouncedAction, main
from promptree._generator import generate_stubs


def test_generate_writes_promptree_package(tmp_path: Path, fixtures_dir: Path) -> None:
    """generate should write the runtime module and stub file."""
    prompt_dir = tmp_path / "basic"
    shutil.copytree(fixtures_dir / "basic", prompt_dir)

    assert main(["generate", str(prompt_dir)]) == 0

    init_py = prompt_dir / "__init__.py"
    init_pyi = prompt_dir / "__init__.pyi"
    expected_py, expected_pyi = generate_stubs(prompt_dir)

    assert init_py.read_text(encoding="utf-8") == expected_py
    assert init_pyi.read_text(encoding="utf-8") == expected_pyi

    assert main(["check", str(prompt_dir)]) == 0


def test_generate_skips_existing_custom_init(tmp_path: Path, fixtures_dir: Path, capsys) -> None:
    """generate should not overwrite an existing non-promptree __init__.py."""
    prompt_dir = tmp_path / "basic"
    shutil.copytree(fixtures_dir / "basic", prompt_dir)
    custom_init = prompt_dir / "__init__.py"
    custom_init.write_text("custom init\n", encoding="utf-8")

    assert main(["generate", str(prompt_dir)]) == 0

    captured = capsys.readouterr()
    assert "skipping existing non-generated" in captured.err
    assert custom_init.read_text(encoding="utf-8") == "custom init\n"
    assert (prompt_dir / "__init__.pyi").exists()


def test_generate_honors_extensions_and_init_only(tmp_path: Path) -> None:
    """generate should accept custom extensions and skip __init__.pyi when requested."""
    prompt_dir = tmp_path / "custom"
    prompt_dir.mkdir()
    (prompt_dir / "prompt.prompt").write_text("Hello {{ name }}!\n", encoding="utf-8")

    assert main(["generate", str(prompt_dir), "--extensions", ".prompt", "--init-only"]) == 0

    assert (prompt_dir / "__init__.py").exists()
    assert not (prompt_dir / "__init__.pyi").exists()

    expected_py, _ = generate_stubs(prompt_dir, (".prompt",))
    assert (prompt_dir / "__init__.py").read_text(encoding="utf-8") == expected_py


def test_check_reports_out_of_sync(tmp_path: Path, fixtures_dir: Path, capsys) -> None:
    """check should fail and print a diff when generated files are stale."""
    prompt_dir = tmp_path / "basic"
    shutil.copytree(fixtures_dir / "basic", prompt_dir)
    assert main(["generate", str(prompt_dir)]) == 0

    (prompt_dir / "system.md").write_text("System prompt for {{ name }} and {{ style }}.\n", encoding="utf-8")

    assert main(["check", str(prompt_dir)]) == 1

    captured = capsys.readouterr()
    assert "is out of sync" in captured.out
    assert "style" in captured.out


def test_check_ignores_custom_init_when_stub_is_current(tmp_path: Path, fixtures_dir: Path) -> None:
    """check should not fail just because __init__.py is user-managed."""
    prompt_dir = tmp_path / "basic"
    shutil.copytree(fixtures_dir / "basic", prompt_dir)

    custom_init = prompt_dir / "__init__.py"
    custom_init.write_text("custom init\n", encoding="utf-8")
    _, expected_pyi = generate_stubs(prompt_dir)
    (prompt_dir / "__init__.pyi").write_text(expected_pyi, encoding="utf-8")

    assert main(["check", str(prompt_dir)]) == 0


def test_debounced_action_coalesces_triggers() -> None:
    """Repeated watch triggers should collapse into a single callback."""
    calls: list[str] = []
    timers: list[object] = []

    class FakeTimer:
        def __init__(self, delay_seconds: float, callback):
            self.delay_seconds = delay_seconds
            self.callback = callback
            self.cancelled = False
            self.started = False
            self.daemon = False
            timers.append(self)

        def start(self) -> None:
            self.started = True

        def cancel(self) -> None:
            self.cancelled = True

        def fire(self) -> None:
            if not self.cancelled:
                self.callback()

    debounced = _DebouncedAction(0.1, lambda: calls.append("ran"), timer_factory=FakeTimer)

    debounced.trigger()
    first = timers[0]
    debounced.trigger()
    second = timers[1]

    assert first.started
    assert first.cancelled
    assert second.started
    assert not second.cancelled
    assert calls == []

    second.fire()
    assert calls == ["ran"]
