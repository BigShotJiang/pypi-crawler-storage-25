"""Tests for the Promptree root object."""

from __future__ import annotations

from pathlib import Path

import pytest

from promptree import Promptree


def test_promptree_rejects_non_directory(tmp_path: Path) -> None:
    """Promptree should fail fast when the root path is missing."""
    with pytest.raises(NotADirectoryError, match="Prompt directory not found"):
        Promptree(tmp_path / "missing")


def test_promptree_repr_uses_resolved_path(fixtures_dir: Path) -> None:
    """Promptree repr should expose the resolved root path."""
    tree = Promptree(fixtures_dir / "basic")
    assert repr(tree) == f"Promptree({(fixtures_dir / 'basic').resolve()})"


def test_promptree_globals_are_available(tmp_path: Path) -> None:
    """Globals passed into Promptree should be visible during render."""
    prompts = tmp_path / "prompts"
    prompts.mkdir()
    (prompts / "greeting.md").write_text("Hello {{ app_name }}!\n", encoding="utf-8")

    tree = Promptree(prompts, globals={"app_name": "Promptree"})

    assert tree.greeting() == "Hello Promptree!\n"
    assert tree.greeting.variables == frozenset()
