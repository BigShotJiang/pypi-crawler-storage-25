"""Coverage gap tests for client modules.

Extracted from test_122_coverage_gaps.py:
- FFBBDataClient search_multiple_* and delegation tests
"""

from __future__ import annotations

import unittest
from unittest.mock import MagicMock


class TestFFBBDataClientCoverage(unittest.TestCase):
    """ffbb_data_client.py -- cover search_multiple_* with None names."""

    def test_search_multiple_with_none_names_returns_none(self) -> None:
        from ffbb_data_client.clients.ffbb_data_client import FFBBDataClient

        api_client = MagicMock()
        meili_client = MagicMock()
        client = FFBBDataClient(api_client, meili_client)

        self.assertIsNone(client.search_multiple_competitions(None))
        self.assertIsNone(client.search_multiple_organismes(None))
        self.assertIsNone(client.search_multiple_pratiques(None))
        self.assertIsNone(client.search_multiple_rencontres(None))
        self.assertIsNone(client.search_multiple_salles(None))
        self.assertIsNone(client.search_multiple_terrains(None))
        self.assertIsNone(client.search_multiple_tournois(None))

    def test_search_multiple_with_empty_list_returns_none(self) -> None:
        from ffbb_data_client.clients.ffbb_data_client import FFBBDataClient

        api_client = MagicMock()
        meili_client = MagicMock()
        client = FFBBDataClient(api_client, meili_client)

        self.assertIsNone(client.search_multiple_competitions([]))
        self.assertIsNone(client.search_multiple_organismes([]))

    def test_get_competition_delegates(self) -> None:
        from ffbb_data_client.clients.ffbb_data_client import FFBBDataClient

        api_client = MagicMock()
        api_client.get_competition.return_value = "result"
        meili_client = MagicMock()
        client = FFBBDataClient(api_client, meili_client)

        result = client.get_competition(competition_id=123)
        self.assertEqual(result, "result")
        api_client.get_competition.assert_called_once()

    def test_get_organisme_delegates(self) -> None:
        from ffbb_data_client.clients.ffbb_data_client import FFBBDataClient

        api_client = MagicMock()
        api_client.get_organisme.return_value = "org_result"
        meili_client = MagicMock()
        client = FFBBDataClient(api_client, meili_client)

        result = client.get_organisme(organisme_id=456)
        self.assertEqual(result, "org_result")

    def test_get_poule_delegates(self) -> None:
        from ffbb_data_client.clients.ffbb_data_client import FFBBDataClient

        api_client = MagicMock()
        api_client.get_poule.return_value = "poule_result"
        meili_client = MagicMock()
        client = FFBBDataClient(api_client, meili_client)

        result = client.get_poule(poule_id=789)
        self.assertEqual(result, "poule_result")

    def test_get_classement_delegates(self) -> None:
        from ffbb_data_client.clients.ffbb_data_client import FFBBDataClient

        api_client = MagicMock()
        api_client.get_classement.return_value = "classement_result"
        meili_client = MagicMock()
        client = FFBBDataClient(api_client, meili_client)

        result = client.get_classement(poule_id=123)
        self.assertEqual(result, "classement_result")
        api_client.get_classement.assert_called_once_with(123, cached_session=None)


if __name__ == "__main__":
    unittest.main()
