"""
LetsWork stdio MCP proxy.

Claude Code connects to this as a stdio MCP server (reliable, no streaming issues).
This proxy forwards all tool calls to the host's HTTP MCP server using a proper
MCP client session (required by FastMCP's streamable HTTP transport).

Reconnects automatically if the tunnel drops. Sends a keepalive ping every 30s
to prevent Cloudflare from closing idle connections.

Usage (done automatically by `letswork join`):
    claude mcp add letswork -- letswork-proxy --url <URL> --token <TOKEN>
"""
import sys
import asyncio
import argparse
import logging
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.client.streamable_http import streamablehttp_client
from mcp import ClientSession, types

log = logging.getLogger("letswork.proxy")

_RECONNECT_DELAYS = [1, 2, 5, 10, 30]  # seconds between attempts
_KEEPALIVE_INTERVAL = 30               # seconds between keepalive pings


def _setup_logging(debug: bool) -> None:
    level = logging.DEBUG if debug else logging.WARNING
    logging.basicConfig(
        stream=sys.stderr,
        level=level,
        format="[proxy %(levelname)s] %(message)s",
    )


def make_proxy_server(base_url: str, token: str) -> tuple:
    """Create an MCP Server that forwards calls to the remote host via a proper session."""
    url = base_url.rstrip("/")
    if not url.endswith("/mcp"):
        url = url + "/mcp"

    server = Server("letswork-proxy")
    _session: ClientSession | None = None
    _session_lock = asyncio.Lock()

    async def _get_session() -> ClientSession:
        if _session is None:
            raise RuntimeError("Not connected to host — reconnecting, please retry in a moment")
        return _session

    @server.list_tools()
    async def list_tools() -> list[types.Tool]:
        session = await _get_session()
        result = await session.list_tools()
        tools = []
        for t in result.tools:
            schema = t.inputSchema if t.inputSchema else {"type": "object", "properties": {}}
            schema = dict(schema)
            props = dict(schema.get("properties", {}))
            props.pop("token", None)
            schema["properties"] = props
            required = [r for r in schema.get("required", []) if r != "token"]
            if required:
                schema["required"] = required
            elif "required" in schema:
                del schema["required"]
            tools.append(types.Tool(
                name=t.name,
                description=t.description or "",
                inputSchema=schema,
            ))
        return tools

    @server.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
        session = await _get_session()
        arguments = {**arguments, "token": token}
        log.debug(f"→ {name}({[k for k in arguments if k != 'token']})")
        try:
            result = await session.call_tool(name, arguments)
        except Exception as e:
            log.error(f"✗ {name} failed: {e}")
            raise
        out = [types.TextContent(type="text", text=item.text)
               for item in result.content if item.type == "text"]
        if not out:
            out.append(types.TextContent(type="text", text=str(result)))
        log.debug(f"← {name} OK")
        return out

    async def _keepalive(session: ClientSession) -> None:
        """Ping host every 30s so Cloudflare doesn't close the idle connection."""
        while True:
            await asyncio.sleep(_KEEPALIVE_INTERVAL)
            try:
                await session.call_tool("ping", {"token": token})
                log.debug("keepalive ping OK")
            except Exception as e:
                log.debug(f"keepalive ping failed: {e}")
                break  # session is dead — let the outer loop reconnect

    async def _connect_loop(read_stream, write_stream) -> None:
        nonlocal _session
        attempt = 0
        first = True

        while True:
            try:
                log.debug(f"Connecting to host at {url} (attempt {attempt + 1})")
                async with streamablehttp_client(url) as (host_read, host_write, _):
                    async with ClientSession(host_read, host_write) as session:
                        await session.initialize()
                        async with _session_lock:
                            _session = session
                        attempt = 0
                        log.debug("Connected to host MCP server")

                        if first:
                            first = False
                            # Start serving stdio on first connect
                            asyncio.ensure_future(
                                server.run(read_stream, write_stream,
                                           server.create_initialization_options())
                            )

                        # Run keepalive until connection drops
                        await _keepalive(session)

            except Exception as e:
                async with _session_lock:
                    _session = None
                if first:
                    # Failed on very first attempt — bail out, Claude Code will show error
                    log.error(f"Initial connection failed: {e}")
                    raise
                delay = _RECONNECT_DELAYS[min(attempt, len(_RECONNECT_DELAYS) - 1)]
                attempt += 1
                log.debug(f"Disconnected ({e}), retrying in {delay}s...")
                await asyncio.sleep(delay)

    async def run(read_stream, write_stream):
        await _connect_loop(read_stream, write_stream)

    return server, run


async def _main(url: str, token: str, debug: bool) -> None:
    _setup_logging(debug)
    log.debug(f"Starting proxy → {url}")
    _server, run = make_proxy_server(url, token)
    async with stdio_server() as (read_stream, write_stream):
        await run(read_stream, write_stream)


def main() -> None:
    parser = argparse.ArgumentParser(description="LetsWork MCP stdio proxy")
    parser.add_argument("--url", required=True, help="Host MCP URL")
    parser.add_argument("--token", required=True, help="Session token")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    args = parser.parse_args()
    asyncio.run(_main(args.url, args.token, args.debug))


if __name__ == "__main__":
    main()
