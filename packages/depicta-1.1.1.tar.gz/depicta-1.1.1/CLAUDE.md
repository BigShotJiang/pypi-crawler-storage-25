# Development Directives (MANDATORY — no exceptions)

1. **Security first**: every line of code, every config, every decision. Absolute priority. No exceptions.
2. **Production-grade only**: no shortcuts, no half implementations, no placeholders. Ship-ready code or don't ship.
3. **Test relentlessly**: write test suites, run them often, maintain coverage. Tests are not optional.
4. **Follow coding conventions**: see `../management/coding-conventions.md`. Consistent style, comments, maintainable code.
5. **Review after every feature**: test → code review (security, quality, complexity, performance) → fix → ship.
6. **Design thoroughly before coding**: design → review → ask questions → adjust.
7. **Iterate**: use ralph-loop or similar iterative workflows for quality refinement.
8. **Use skills**: invoke relevant skills (TDD, debugging, code-review, brainstorming, etc.).

# Core Design Principles

1. **ISO 27001-aligned security** in every feature and decision
2. **Legal compliance by design** (GDPR, EU AI Act, Greek law, consumer protection)
3. **Tax compliance by design** (VAT, myDATA, invoicing, revenue recognition)

These are NON-NEGOTIABLE.

# Project Context

- **Product**: Depicta (depicta.ai) — API-first generative image service
- **This repo**: Python CLI — thin HTTP client over the Depicta API
- **Design spec**: `../management/design/2026-03-29-cli-design.md`
- **Contract spec**: `../cli-spec/contract.yaml` (single source of truth for commands/flags/output)
- **Coding conventions**: `../management/coding-conventions.md`
- **Decisions log**: `docs/decisions.md`
- **Reference CLI**: `../imagor/src/imagor/` (same libraries, different backend)

# Running Tests

```bash
# Unit tests
uv run pytest tests/ -v

# Integration tests (requires cli-spec mock server + bats)
cd ../cli-spec
DEPICTA_CLI=$(which depicta) make test
```

# Key Patterns

- Sync httpx (not async) — one request per command, no concurrency needed
- Global flags on each command function (not Typer callback) — works in any position
- Three output modes: human (TTY), json (--json), pipe (non-TTY without --json)
- stdout = file path (pipe) or JSON (--json). stderr = Rich display or JSON errors.
