# CLI Python — Python Command-Line Tool

## What This Is

A proprietary Python CLI that lets users interact with the imagor-saas API from the terminal. Distributed via PyPI (`pip install <name>`) but NOT open source.

## Responsibilities

- Authenticate with the imagor-saas API (API key from config or environment)
- Expose all operations as CLI commands: create, edit, icon, diagram, combine, story
- Support piping between commands (e.g., `create "a cat" | edit - "add a hat"`)
- Display costs before and after generation
- Show credit balance
- Format conversion and local image operations

## How It Differs From the Original imagor CLI

The original `../imagor/` CLI talks directly to OpenRouter with a user's own API key. This CLI talks to **our SaaS API**, which handles model routing, prompt engineering, safety, and billing.

```
Original:  CLI --> OpenRouter (user's key)
SaaS CLI:  CLI --> imagor-saas API (user's API key) --> OpenRouter (our key)
```

## Key Design Constraints

- **Proprietary**: distributed as a package on PyPI, source code is not public
- **Thin client**: all business logic lives in the API. The CLI is just a user-friendly wrapper around HTTP calls.
- **Config**: API key stored in `~/.config/<name>/config.json` or via environment variable
- **Output**: images saved to local filesystem, with optional display in terminal (kitty/iTerm2 protocols)

## Tech Stack

- Python 3.10+
- Typer (CLI framework, same as original imagor)
- Rich (pretty console output)
- httpx (HTTP client)

## Related Components

- `../image-worker/` — Internal image worker (CLI talks to gateway, not directly)
- `../imagor/` — Reference implementation (similar CLI structure, different backend)
- `../skill/` — Claude Code skill files (alternative access method)

## Key Design Constraints

- **ISO 27001-aligned**: API keys stored securely (OS keyring or encrypted config, never in shell history). No sensitive data in logs or error output.
- **Legal compliance**: CLI must display AI-generated content disclaimer. Respect C2PA metadata in delivered images.
- **Tax compliance**: cost display must match what the API charges (no discrepancies between displayed and billed amounts).

## Reference

- Full design doc: `../management/design/2026-03-04-imagor-saas-design.md`
- Core principles: ISO 27001 security, legal compliance, tax compliance in every decision
