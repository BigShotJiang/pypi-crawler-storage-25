# Decisions

## HTTP Client (2026-03-29)

- **Choice → sync httpx**: CLI is a thin client making 1-3 HTTP requests per command. Sync simplifies code, testing, and error handling. Async adds complexity without benefit here. Story polling uses time.sleep() loop.

## Global Flags on Each Command (2026-03-29)

- **Choice → repeat global flag annotations per command**: Typer callback-based global flags must appear before the command name. By putting flags on each command function, they work in any position. Uses shared type annotations in flags.py to avoid duplication.

## Output Mode Detection (2026-03-29)

- **Choice → three modes (human/json/pipe)**: human (TTY), json (--json), pipe (non-TTY, no flags). Pipe mode outputs file path only to stdout, enabling shell pipe chains without JSON parsing between stages.
