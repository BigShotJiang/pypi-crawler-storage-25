"""Configuration file I/O and authentication precedence."""

from __future__ import annotations

import json
import os
import stat
from pathlib import Path
from typing import Any


def _config_dir() -> Path:
    """Return XDG-compliant config directory for Depicta."""
    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        base = Path(xdg)
    elif os.name == "nt":
        base = Path(os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming")))
    else:
        base = Path.home() / ".config"
    return base / "depicta"


def config_path() -> Path:
    """Return the full path to the config file."""
    return _config_dir() / "config.json"


def load_config() -> dict[str, Any]:
    """Load config from disk. Returns empty dict if file is missing."""
    path = config_path()
    if path.exists():
        result: dict[str, Any] = json.loads(path.read_text())
        return result
    return {}


def save_config(data: dict[str, Any]) -> None:
    """Save config to disk with 0600 permissions."""
    path = config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n")
    os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)


def resolve_api_key(flag_key: str | None = None) -> str | None:
    """Resolve API key. Precedence: flag > env > config."""
    if flag_key:
        return flag_key
    env_key = os.environ.get("DEPICTA_API_KEY")
    if env_key:
        return env_key
    return load_config().get("api_key")


def resolve_api_url(flag_url: str | None = None) -> str:
    """Resolve API base URL. Precedence: flag > env > config > default."""
    if flag_url:
        return flag_url
    env_url = os.environ.get("DEPICTA_API_URL")
    if env_url:
        return env_url
    url: str = load_config().get("api_url", "https://api.depicta.ai")
    return url


def mask_key(key: str) -> str:
    """Mask API key for safe display: shows first 13 chars + ****."""
    if len(key) > 13:
        return key[:13] + "****"
    return key[:4] + "****"
