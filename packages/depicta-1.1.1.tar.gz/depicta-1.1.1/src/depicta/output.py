"""Output formatting — TTY detection, three output modes, Rich display."""

from __future__ import annotations

import json
import sys
from enum import Enum, auto
from typing import Any

from rich.console import Console

stderr_console = Console(stderr=True)


class OutputMode(Enum):
    """CLI output modes per contract spec."""

    HUMAN = auto()  # TTY or --human: Rich to stderr, file path to stdout
    JSON = auto()  # --json: full JSON to stdout, JSON errors to stderr
    PIPE = auto()  # non-TTY: file path to stdout, minimal stderr


def detect_mode(
    *,
    force_json: bool = False,
    force_human: bool = False,
) -> OutputMode:
    """Determine output mode from flags and TTY state."""
    if force_json:
        return OutputMode.JSON
    if force_human:
        return OutputMode.HUMAN
    if sys.stdout.isatty():
        return OutputMode.HUMAN
    return OutputMode.PIPE


# ---------------------------------------------------------------------------
# JSON formatters
# ---------------------------------------------------------------------------


def format_generation_json(
    *,
    file_path: str,
    cost_eur: str,
    balance_eur: str,
    image_hash: str,
    model: str,
) -> str:
    """Format a generation result as JSON."""
    return json.dumps(
        {
            "file": file_path,
            "cost_eur": cost_eur,
            "balance_eur": balance_eur,
            "image_hash": image_hash,
            "model": model,
            "ai_generated": True,
        }
    )


def format_processing_json(*, file_path: str) -> str:
    """Format a processing result as JSON."""
    return json.dumps({"file": file_path})


def format_balance_json(*, balance_eur: str, held_eur: str) -> str:
    """Format a balance result as JSON."""
    return json.dumps({"balance_eur": balance_eur, "held_eur": held_eur})


def format_version_json(*, version: str) -> str:
    """Format a version result as JSON."""
    return json.dumps({"version": version})


def format_story_json(*, result: dict[str, Any]) -> str:
    """Format a completed story result as JSON."""
    return json.dumps(result)


# ---------------------------------------------------------------------------
# Printers (handle all three modes)
# ---------------------------------------------------------------------------


def print_generation(
    file_path: str,
    data: dict[str, Any],
    mode: OutputMode,
    quiet: bool = False,
) -> None:
    """Print a generation result in the appropriate mode."""
    if mode == OutputMode.JSON:
        print(
            format_generation_json(
                file_path=file_path,
                cost_eur=data.get("cost_eur", "0"),
                balance_eur=data.get("balance_eur", "0"),
                image_hash=data.get("image_hash", ""),
                model=data.get("model", ""),
            )
        )
    elif mode == OutputMode.HUMAN:
        if not quiet:
            stderr_console.print(f"[green]✓[/] Saved to {file_path}")
            if "cost_eur" in data:
                stderr_console.print(f"  Cost: EUR {data['cost_eur']}")
            if "balance_eur" in data:
                bal = float(data["balance_eur"])
                style = "green" if bal > 5 else "yellow" if bal > 1 else "red"
                stderr_console.print(
                    f"  Balance: [{style}]EUR {data['balance_eur']}[/{style}]"
                )
        print(file_path)
    else:
        # Pipe mode — file path only
        print(file_path)


def print_processing(
    file_path: str,
    mode: OutputMode,
    quiet: bool = False,
) -> None:
    """Print a processing result."""
    if mode == OutputMode.JSON:
        print(format_processing_json(file_path=file_path))
    elif mode == OutputMode.HUMAN:
        if not quiet:
            stderr_console.print(f"[green]✓[/] Saved to {file_path}")
        print(file_path)
    else:
        print(file_path)


def print_error(error: dict[str, Any], mode: OutputMode) -> None:
    """Print an error to stderr."""
    if mode in (OutputMode.JSON, OutputMode.PIPE):
        print(json.dumps(error), file=sys.stderr)
    else:
        stderr_console.print(f"[red]Error:[/] {error.get('message', 'Unknown error')}")


def warn_api_key_flag(mode: OutputMode, quiet: bool = False) -> None:
    """Emit the shell history warning when --api-key is used."""
    if quiet:
        return
    msg = (
        "Warning: passing API keys via command line may expose them"
        " in shell history. Prefer DEPICTA_API_KEY env var."
    )
    if mode == OutputMode.HUMAN:
        stderr_console.print(f"[yellow]{msg}[/]")
    else:
        print(msg, file=sys.stderr)
