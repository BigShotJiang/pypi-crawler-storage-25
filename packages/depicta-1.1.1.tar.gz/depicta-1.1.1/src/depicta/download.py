"""Image download, temp directory management, and output path logic."""

from __future__ import annotations

import os
import tempfile
import uuid
from datetime import datetime
from pathlib import Path


def temp_dir() -> Path:
    """Return user-specific temp directory: /tmp/depicta-{uid}/."""
    uid = os.getuid() if hasattr(os, "getuid") else os.getpid()
    d = Path(tempfile.gettempdir()) / f"depicta-{uid}"
    d.mkdir(parents=True, exist_ok=True)
    return d


def make_output_path(
    command: str,
    ext: str = "png",
    output: str | None = None,
    output_dir: str | None = None,
) -> Path:
    """Determine output file path. Priority: output > output_dir > temp_dir."""
    if output:
        p = Path(output)
        p.parent.mkdir(parents=True, exist_ok=True)
        return p

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    unique = uuid.uuid4().hex[:6]
    filename = f"{command}_{unique}_{ts}.{ext}"

    d = Path(output_dir) if output_dir else temp_dir()
    d.mkdir(parents=True, exist_ok=True)
    return d / filename


def save_bytes(
    data: bytes,
    command: str,
    ext: str = "png",
    output: str | None = None,
    output_dir: str | None = None,
) -> Path:
    """Save raw bytes to disk and return the path."""
    path = make_output_path(command, ext, output, output_dir)
    path.write_bytes(data)
    return path
