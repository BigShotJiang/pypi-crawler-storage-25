"""Shared Typer flag annotations for all commands."""

from __future__ import annotations

from typing import Annotated

import typer

# ---------------------------------------------------------------------------
# Global flags (on every command)
# ---------------------------------------------------------------------------

JsonFlag = Annotated[bool, typer.Option("--json", help="Force JSON output")]
HumanFlag = Annotated[bool, typer.Option("--human", help="Force human-readable output")]
ApiKeyOpt = Annotated[str | None, typer.Option("--api-key", help="Override API key")]
ApiUrlOpt = Annotated[str | None, typer.Option("--api-url", hidden=True)]
QuietFlag = Annotated[
    bool, typer.Option("--quiet", "-q", help="Suppress informational output")
]

# ---------------------------------------------------------------------------
# Generation flags
# ---------------------------------------------------------------------------

ModelOpt = Annotated[
    str | None, typer.Option("--model", "-m", help="Model name or alias")
]
SizeOpt = Annotated[
    str | None, typer.Option("--size", "-s", help="Aspect ratio (e.g., 16:9)")
]
ImageSizeOpt = Annotated[
    str | None, typer.Option("--image-size", help="Resolution: 1K, 2K, 4K")
]
OutputOpt = Annotated[
    str | None, typer.Option("--output", "-o", help="Output file path")
]
OutputDirOpt = Annotated[
    str | None, typer.Option("--output-dir", "-d", help="Output directory")
]
FormatOpt = Annotated[
    str | None, typer.Option("--format", "-f", help="Output format: png, jpg, webp")
]
QualityOpt = Annotated[int, typer.Option("--quality", help="JPEG/WebP quality 0-100")]
StrictnessOpt = Annotated[
    str | None,
    typer.Option("--strictness", help="Classification strictness: normal, liberal"),
]
ReferenceOpt = Annotated[
    list[str] | None,
    typer.Option(
        "--reference", "-r", help="Reference image as PATH:DESCRIPTION (repeatable)"
    ),
]

# ---------------------------------------------------------------------------
# Processing flags
# ---------------------------------------------------------------------------

WidthOpt = Annotated[int | None, typer.Option("--width", help="Width in pixels")]
HeightOpt = Annotated[int | None, typer.Option("--height", help="Height in pixels")]
XOpt = Annotated[int, typer.Option("--x", help="X coordinate")]
YOpt = Annotated[int, typer.Option("--y", help="Y coordinate")]
CropWidthOpt = Annotated[int, typer.Option("--width", help="Crop width")]
CropHeightOpt = Annotated[int, typer.Option("--height", help="Crop height")]
ColorsOpt = Annotated[
    int | None,
    typer.Option(
        "--colors",
        help="Max colors 2-256 (optional, omit for auto PSNR-guided optimization)",
    ),
]
MinPsnrOpt = Annotated[
    float | None,
    typer.Option("--min-psnr", help="Min PSNR quality floor (optional, default: 38.0)"),
]

# ---------------------------------------------------------------------------
# Story flags
# ---------------------------------------------------------------------------

TimeoutOpt = Annotated[int, typer.Option("--timeout", help="Max wait time in seconds")]

# ---------------------------------------------------------------------------
# Diagram flags
# ---------------------------------------------------------------------------

DiagramTypeOpt = Annotated[
    str | None, typer.Option("--type", "-t", help="Diagram type")
]
