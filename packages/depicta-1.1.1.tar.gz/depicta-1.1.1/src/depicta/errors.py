"""Error types and HTTP status to exit code mapping."""

from __future__ import annotations

from typing import Any

EXIT_SUCCESS = 0
EXIT_GENERAL = 1
EXIT_AUTH = 2
EXIT_CREDITS = 3
EXIT_REJECTED = 4
EXIT_RATE_LIMITED = 5

_STATUS_TO_EXIT: dict[int, int] = {
    401: EXIT_AUTH,
    402: EXIT_CREDITS,
    403: EXIT_REJECTED,
    429: EXIT_RATE_LIMITED,
}


class DepictaError(Exception):
    """API error with structured details and exit code."""

    def __init__(
        self,
        message: str,
        error_code: str,
        exit_code: int,
        extra: dict[str, Any] | None = None,
    ):
        super().__init__(message)
        self.error_code = error_code
        self.exit_code = exit_code
        self.extra = extra or {}

    def to_dict(self) -> dict[str, Any]:
        """Serialize for JSON error output."""
        d: dict[str, Any] = {"error": self.error_code, "message": str(self)}
        d.update(self.extra)
        return d


def error_from_response(status_code: int, body: dict[str, Any]) -> DepictaError:
    """Create a DepictaError from an API error response."""
    error_code = body.get("error", "general_error")
    message = body.get("message", f"API error ({status_code})")
    exit_code = _STATUS_TO_EXIT.get(status_code, EXIT_GENERAL)
    extra = {k: v for k, v in body.items() if k not in ("error", "message")}
    return DepictaError(message, error_code, exit_code, extra)
