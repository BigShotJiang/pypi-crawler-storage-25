"""Guidelines commands: search."""

from __future__ import annotations

import json
from typing import Annotated

import typer

from depicta.client import DepictaClient
from depicta.config import resolve_api_key, resolve_api_url
from depicta.errors import EXIT_AUTH, DepictaError
from depicta.flags import ApiKeyOpt, ApiUrlOpt, HumanFlag, JsonFlag, QuietFlag
from depicta.output import OutputMode, detect_mode, stderr_console, warn_api_key_flag

app = typer.Typer(no_args_is_help=True)


def _make_client(
    api_key: str | None,
    api_url: str | None,
    mode: OutputMode,
    quiet: bool,
) -> DepictaClient:
    """Resolve auth, warn if flag used, create client."""
    key = resolve_api_key(api_key)
    if not key:
        raise DepictaError("No API key configured.", "authentication_error", EXIT_AUTH)
    if api_key:
        warn_api_key_flag(mode, quiet)
    return DepictaClient(key, resolve_api_url(api_url))


@app.command("search")
def search_cmd(
    query: Annotated[str, typer.Argument(help="Search query")],
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    api_key: ApiKeyOpt = None,
    api_url: ApiUrlOpt = None,
    quiet: QuietFlag = False,
) -> None:
    """Search content guidelines by keyword."""
    mode = detect_mode(force_json=json_output, force_human=human_output)
    client = _make_client(api_key, api_url, mode, quiet)

    # GET with query parameter
    resp = client._client.get("/v1/guidelines/search", params={"q": query})
    if resp.status_code >= 400:
        client._raise_error(resp)
    data = resp.json()
    client.close()

    if mode == OutputMode.JSON:
        print(json.dumps(data))
    elif mode == OutputMode.HUMAN and not quiet:
        results = data.get("guidelines", [])
        if not results:
            stderr_console.print(f"No guidelines found for '{query}'")
            return
        for r in results:
            stderr_console.print(f"\n[bold cyan]{r['title']}[/] ({r['slug']})")
            stderr_console.print(r["content"])
    else:
        # Pipe mode — print raw JSON
        print(json.dumps(data))
