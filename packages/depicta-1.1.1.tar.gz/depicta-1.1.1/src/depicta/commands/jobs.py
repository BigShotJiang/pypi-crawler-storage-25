"""Jobs commands: list, get."""

from __future__ import annotations

import json
from typing import Annotated

import typer
from rich.table import Table

from depicta.client import DepictaClient
from depicta.config import resolve_api_key, resolve_api_url
from depicta.errors import EXIT_AUTH, DepictaError
from depicta.flags import ApiKeyOpt, ApiUrlOpt, HumanFlag, JsonFlag, QuietFlag
from depicta.output import OutputMode, detect_mode, stderr_console, warn_api_key_flag

app = typer.Typer(no_args_is_help=True)


def _make_client(
    api_key: str | None,
    api_url: str | None,
    mode: OutputMode,
    quiet: bool,
) -> DepictaClient:
    """Resolve auth, warn if flag used, create client."""
    key = resolve_api_key(api_key)
    if not key:
        raise DepictaError("No API key configured.", "authentication_error", EXIT_AUTH)
    if api_key:
        warn_api_key_flag(mode, quiet)
    return DepictaClient(key, resolve_api_url(api_url))


@app.command("list")
def list_cmd(
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    api_key: ApiKeyOpt = None,
    api_url: ApiUrlOpt = None,
    quiet: QuietFlag = False,
) -> None:
    """List recent generation jobs."""
    mode = detect_mode(force_json=json_output, force_human=human_output)
    client = _make_client(api_key, api_url, mode, quiet)
    data = client.get("/v1/jobs")
    client.close()
    jobs = data.get("generations", [])

    if mode == OutputMode.JSON:
        print(json.dumps(jobs))
    elif mode == OutputMode.HUMAN and not quiet:
        if not jobs:
            stderr_console.print("No recent jobs.")
            return
        table = Table(title="Recent Jobs")
        table.add_column("ID", style="cyan")
        table.add_column("Status")
        table.add_column("Created")
        for j in jobs:
            table.add_row(
                j.get("job_id", ""), j.get("status", ""), j.get("created_at", "")
            )
        stderr_console.print(table)
    else:
        print(json.dumps(jobs))


@app.command("get")
def get_cmd(
    job_id: Annotated[str, typer.Argument(help="Job ID")],
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    api_key: ApiKeyOpt = None,
    api_url: ApiUrlOpt = None,
    quiet: QuietFlag = False,
) -> None:
    """Get a specific job by ID."""
    mode = detect_mode(force_json=json_output, force_human=human_output)
    client = _make_client(api_key, api_url, mode, quiet)
    job = client.get(f"/v1/jobs/{job_id}")
    client.close()

    if mode == OutputMode.JSON:
        print(json.dumps(job))
    elif mode == OutputMode.HUMAN and not quiet:
        result = job.get("result", {}) or {}
        stderr_console.print(f"Job: {job.get('job_id', job_id)}")
        stderr_console.print(f"Status: {job.get('status', 'unknown')}")
        if "image_url" in result:
            stderr_console.print(f"Image: {result['image_url']}")
        stderr_console.print(f"Cost: EUR {result.get('cost_eur', '—')}")
    else:
        print(json.dumps(job))
