"""Processing commands: crop, resize, convert, optimize, remove-bg."""

from __future__ import annotations

import sys
from typing import Annotated, Any

import typer

from depicta.client import DepictaClient
from depicta.config import resolve_api_key, resolve_api_url
from depicta.download import save_bytes
from depicta.errors import EXIT_AUTH, DepictaError
from depicta.flags import (
    ApiKeyOpt,
    ApiUrlOpt,
    ColorsOpt,
    CropHeightOpt,
    CropWidthOpt,
    HeightOpt,
    HumanFlag,
    JsonFlag,
    MinPsnrOpt,
    OutputDirOpt,
    OutputOpt,
    QuietFlag,
    WidthOpt,
    XOpt,
    YOpt,
)
from depicta.output import OutputMode, detect_mode, print_processing, warn_api_key_flag

app = typer.Typer(no_args_is_help=True)


def _resolve_input(path: str) -> str:
    """Resolve input: file path, stdin (-), or URL."""
    if path == "-":
        line = sys.stdin.readline().strip()
        if not line:
            raise typer.Exit(1)
        return line
    return path


def _make_client(
    api_key: str | None, api_url: str | None, mode: OutputMode, quiet: bool
) -> DepictaClient:
    """Resolve auth, warn if flag used, create client."""
    key = resolve_api_key(api_key)
    if not key:
        raise DepictaError("No API key configured.", "authentication_error", EXIT_AUTH)
    if api_key:
        warn_api_key_flag(mode, quiet)
    url = resolve_api_url(api_url)
    return DepictaClient(key, url)


def _run_processing(
    *,
    client: DepictaClient,
    endpoint: str,
    input_path: str,
    body: dict[str, Any],
    mode: OutputMode,
    quiet: bool,
    command: str,
    output: str | None,
    output_dir: str | None,
) -> None:
    """Shared processing flow: upload input -> POST -> download -> print."""
    upload_resp = client.upload_file("/v1/upload", input_path)
    body["input_image_url"] = upload_resp["upload_url"]
    resp, _, _ = client.post_json(endpoint, body)
    image_data = client.download_bytes(resp["image_url"])
    path = save_bytes(image_data, command, output=output, output_dir=output_dir)
    print_processing(str(path.resolve()), mode, quiet)
    client.close()


@app.command("crop")
def crop_cmd(
    input_path: Annotated[str, typer.Argument(help="Input image (or - for stdin)")],
    x: XOpt = 0,
    y: YOpt = 0,
    width: CropWidthOpt = 100,
    height: CropHeightOpt = 100,
    output: OutputOpt = None,
    output_dir: OutputDirOpt = None,
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    api_key: ApiKeyOpt = None,
    api_url: ApiUrlOpt = None,
    quiet: QuietFlag = False,
) -> None:
    """Crop image by coordinates."""
    mode = detect_mode(force_json=json_output, force_human=human_output)
    client = _make_client(api_key, api_url, mode, quiet)
    resolved = _resolve_input(input_path)
    _run_processing(
        client=client,
        endpoint="/v1/process/crop",
        input_path=resolved,
        body={"x": x, "y": y, "width": width, "height": height},
        mode=mode,
        quiet=quiet,
        command="crop",
        output=output,
        output_dir=output_dir,
    )


@app.command("resize")
def resize_cmd(
    input_path: Annotated[str, typer.Argument(help="Input image (or - for stdin)")],
    width: WidthOpt = None,
    height: HeightOpt = None,
    output: OutputOpt = None,
    output_dir: OutputDirOpt = None,
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    api_key: ApiKeyOpt = None,
    api_url: ApiUrlOpt = None,
    quiet: QuietFlag = False,
) -> None:
    """Resize image."""
    mode = detect_mode(force_json=json_output, force_human=human_output)
    client = _make_client(api_key, api_url, mode, quiet)
    resolved = _resolve_input(input_path)
    body: dict[str, Any] = {}
    if width is not None:
        body["width"] = width
    if height is not None:
        body["height"] = height
    _run_processing(
        client=client,
        endpoint="/v1/process/resize",
        input_path=resolved,
        body=body,
        mode=mode,
        quiet=quiet,
        command="resize",
        output=output,
        output_dir=output_dir,
    )


@app.command("convert")
def convert_cmd(
    input_path: Annotated[str, typer.Argument(help="Input image (or - for stdin)")],
    fmt: Annotated[
        str, typer.Option("--format", "-f", help="Target format: png, jpg, webp")
    ] = "png",
    output: OutputOpt = None,
    output_dir: OutputDirOpt = None,
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    api_key: ApiKeyOpt = None,
    api_url: ApiUrlOpt = None,
    quiet: QuietFlag = False,
) -> None:
    """Convert image format."""
    mode = detect_mode(force_json=json_output, force_human=human_output)
    client = _make_client(api_key, api_url, mode, quiet)
    resolved = _resolve_input(input_path)
    _run_processing(
        client=client,
        endpoint="/v1/process/convert",
        input_path=resolved,
        body={"format": fmt},
        mode=mode,
        quiet=quiet,
        command="convert",
        output=output,
        output_dir=output_dir,
    )


@app.command("optimize")
def optimize_cmd(
    input_path: Annotated[str, typer.Argument(help="Input image (or - for stdin)")],
    colors: ColorsOpt = None,
    min_psnr: MinPsnrOpt = None,
    output: OutputOpt = None,
    output_dir: OutputDirOpt = None,
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    api_key: ApiKeyOpt = None,
    api_url: ApiUrlOpt = None,
    quiet: QuietFlag = False,
) -> None:
    """Optimize image compression."""
    mode = detect_mode(force_json=json_output, force_human=human_output)
    client = _make_client(api_key, api_url, mode, quiet)
    resolved = _resolve_input(input_path)
    body: dict[str, Any] = {}
    if colors is not None:
        body["colors"] = colors
    if min_psnr is not None:
        body["min_psnr"] = min_psnr
    _run_processing(
        client=client,
        endpoint="/v1/process/optimize",
        input_path=resolved,
        body=body,
        mode=mode,
        quiet=quiet,
        command="optimize",
        output=output,
        output_dir=output_dir,
    )


@app.command("remove-bg")
def remove_bg_cmd(
    input_path: Annotated[str, typer.Argument(help="Input image (or - for stdin)")],
    output: OutputOpt = None,
    output_dir: OutputDirOpt = None,
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    api_key: ApiKeyOpt = None,
    api_url: ApiUrlOpt = None,
    quiet: QuietFlag = False,
) -> None:
    """Remove image background."""
    mode = detect_mode(force_json=json_output, force_human=human_output)
    client = _make_client(api_key, api_url, mode, quiet)
    resolved = _resolve_input(input_path)
    _run_processing(
        client=client,
        endpoint="/v1/process/remove-background",
        input_path=resolved,
        body={},
        mode=mode,
        quiet=quiet,
        command="remove-bg",
        output=output,
        output_dir=output_dir,
    )


@app.command("blur")
def blur_cmd(
    input_path: Annotated[str, typer.Argument(help="Input image (or - for stdin)")],
    radius: Annotated[
        float,
        typer.Option("--radius", help="Blur radius in pixels (required, e.g. 5.0)"),
    ] = ...,  # type: ignore[assignment]
    output: OutputOpt = None,
    output_dir: OutputDirOpt = None,
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    api_key: ApiKeyOpt = None,
    api_url: ApiUrlOpt = None,
    quiet: QuietFlag = False,
) -> None:
    """Apply Gaussian blur."""
    mode = detect_mode(force_json=json_output, force_human=human_output)
    client = _make_client(api_key, api_url, mode, quiet)
    resolved = _resolve_input(input_path)
    _run_processing(
        client=client,
        endpoint="/v1/process/blur",
        input_path=resolved,
        body={"radius": radius},
        mode=mode,
        quiet=quiet,
        command="blur",
        output=output,
        output_dir=output_dir,
    )


@app.command("sharpen")
def sharpen_cmd(
    input_path: Annotated[str, typer.Argument(help="Input image (or - for stdin)")],
    amount: Annotated[
        float | None,
        typer.Option("--amount", help="Sharpening amount (optional, API default: 1.5)"),
    ] = None,
    threshold: Annotated[
        float | None,
        typer.Option(
            "--threshold", help="Edge detection threshold (optional, API default: 3)"
        ),
    ] = None,
    output: OutputOpt = None,
    output_dir: OutputDirOpt = None,
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    api_key: ApiKeyOpt = None,
    api_url: ApiUrlOpt = None,
    quiet: QuietFlag = False,
) -> None:
    """Sharpen image."""
    mode = detect_mode(force_json=json_output, force_human=human_output)
    client = _make_client(api_key, api_url, mode, quiet)
    resolved = _resolve_input(input_path)
    body: dict[str, Any] = {}
    if amount is not None:
        body["amount"] = amount
    if threshold is not None:
        body["threshold"] = threshold
    _run_processing(
        client=client,
        endpoint="/v1/process/sharpen",
        input_path=resolved,
        body=body,
        mode=mode,
        quiet=quiet,
        command="sharpen",
        output=output,
        output_dir=output_dir,
    )


@app.command("denoise")
def denoise_cmd(
    input_path: Annotated[str, typer.Argument(help="Input image (or - for stdin)")],
    strength: Annotated[
        int | None,
        typer.Option(
            "--strength", help="Denoising intensity 1-40 (optional, default: 10)"
        ),
    ] = None,
    output: OutputOpt = None,
    output_dir: OutputDirOpt = None,
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    api_key: ApiKeyOpt = None,
    api_url: ApiUrlOpt = None,
    quiet: QuietFlag = False,
) -> None:
    """Reduce chroma noise."""
    mode = detect_mode(force_json=json_output, force_human=human_output)
    client = _make_client(api_key, api_url, mode, quiet)
    resolved = _resolve_input(input_path)
    body: dict[str, Any] = {}
    if strength is not None:
        body["strength"] = strength
    _run_processing(
        client=client,
        endpoint="/v1/process/denoise",
        input_path=resolved,
        body=body,
        mode=mode,
        quiet=quiet,
        command="denoise",
        output=output,
        output_dir=output_dir,
    )


@app.command("adjust")
def adjust_cmd(
    input_path: Annotated[str, typer.Argument(help="Input image (or - for stdin)")],
    brightness: Annotated[float | None, typer.Option("--brightness")] = None,
    contrast: Annotated[float | None, typer.Option("--contrast")] = None,
    saturation: Annotated[float | None, typer.Option("--saturation")] = None,
    output: OutputOpt = None,
    output_dir: OutputDirOpt = None,
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    api_key: ApiKeyOpt = None,
    api_url: ApiUrlOpt = None,
    quiet: QuietFlag = False,
) -> None:
    """Adjust brightness, contrast, saturation."""
    mode = detect_mode(force_json=json_output, force_human=human_output)
    client = _make_client(api_key, api_url, mode, quiet)
    resolved = _resolve_input(input_path)
    body: dict[str, Any] = {}
    if brightness is not None:
        body["brightness"] = brightness
    if contrast is not None:
        body["contrast"] = contrast
    if saturation is not None:
        body["saturation"] = saturation
    _run_processing(
        client=client,
        endpoint="/v1/process/adjust",
        input_path=resolved,
        body=body,
        mode=mode,
        quiet=quiet,
        command="adjust",
        output=output,
        output_dir=output_dir,
    )


@app.command("grayscale")
def grayscale_cmd(
    input_path: Annotated[str, typer.Argument(help="Input image (or - for stdin)")],
    output: OutputOpt = None,
    output_dir: OutputDirOpt = None,
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    api_key: ApiKeyOpt = None,
    api_url: ApiUrlOpt = None,
    quiet: QuietFlag = False,
) -> None:
    """Convert to grayscale."""
    mode = detect_mode(force_json=json_output, force_human=human_output)
    client = _make_client(api_key, api_url, mode, quiet)
    resolved = _resolve_input(input_path)
    _run_processing(
        client=client,
        endpoint="/v1/process/grayscale",
        input_path=resolved,
        body={},
        mode=mode,
        quiet=quiet,
        command="grayscale",
        output=output,
        output_dir=output_dir,
    )


@app.command("invert")
def invert_cmd(
    input_path: Annotated[str, typer.Argument(help="Input image (or - for stdin)")],
    output: OutputOpt = None,
    output_dir: OutputDirOpt = None,
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    api_key: ApiKeyOpt = None,
    api_url: ApiUrlOpt = None,
    quiet: QuietFlag = False,
) -> None:
    """Invert image colors."""
    mode = detect_mode(force_json=json_output, force_human=human_output)
    client = _make_client(api_key, api_url, mode, quiet)
    resolved = _resolve_input(input_path)
    _run_processing(
        client=client,
        endpoint="/v1/process/invert",
        input_path=resolved,
        body={},
        mode=mode,
        quiet=quiet,
        command="invert",
        output=output,
        output_dir=output_dir,
    )


@app.command("flip")
def flip_cmd(
    input_path: Annotated[str, typer.Argument(help="Input image (or - for stdin)")],
    direction: Annotated[
        str,
        typer.Option(
            "--direction", help="Flip direction: horizontal or vertical (required)"
        ),
    ] = ...,  # type: ignore[assignment]
    output: OutputOpt = None,
    output_dir: OutputDirOpt = None,
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    api_key: ApiKeyOpt = None,
    api_url: ApiUrlOpt = None,
    quiet: QuietFlag = False,
) -> None:
    """Flip image horizontally or vertically."""
    mode = detect_mode(force_json=json_output, force_human=human_output)
    client = _make_client(api_key, api_url, mode, quiet)
    resolved = _resolve_input(input_path)
    _run_processing(
        client=client,
        endpoint="/v1/process/flip",
        input_path=resolved,
        body={"direction": direction},
        mode=mode,
        quiet=quiet,
        command="flip",
        output=output,
        output_dir=output_dir,
    )


@app.command("auto-orient")
def auto_orient_cmd(
    input_path: Annotated[str, typer.Argument(help="Input image (or - for stdin)")],
    output: OutputOpt = None,
    output_dir: OutputDirOpt = None,
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    api_key: ApiKeyOpt = None,
    api_url: ApiUrlOpt = None,
    quiet: QuietFlag = False,
) -> None:
    """Auto-orient based on EXIF data."""
    mode = detect_mode(force_json=json_output, force_human=human_output)
    client = _make_client(api_key, api_url, mode, quiet)
    resolved = _resolve_input(input_path)
    _run_processing(
        client=client,
        endpoint="/v1/process/auto-orient",
        input_path=resolved,
        body={},
        mode=mode,
        quiet=quiet,
        command="auto-orient",
        output=output,
        output_dir=output_dir,
    )


@app.command("alpha-to-color")
def alpha_to_color_cmd(
    input_path: Annotated[str, typer.Argument(help="Input image (or - for stdin)")],
    color: Annotated[
        str | None,
        typer.Option(
            "--color", help="Background color, #RRGGBB (optional, default: #FFFFFF)"
        ),
    ] = None,
    output: OutputOpt = None,
    output_dir: OutputDirOpt = None,
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    api_key: ApiKeyOpt = None,
    api_url: ApiUrlOpt = None,
    quiet: QuietFlag = False,
) -> None:
    """Replace transparency with a solid color."""
    mode = detect_mode(force_json=json_output, force_human=human_output)
    client = _make_client(api_key, api_url, mode, quiet)
    resolved = _resolve_input(input_path)
    _run_processing(
        client=client,
        endpoint="/v1/process/alpha-to-color",
        input_path=resolved,
        body={"color": color} if color else {},
        mode=mode,
        quiet=quiet,
        command="alpha-to-color",
        output=output,
        output_dir=output_dir,
    )


@app.command("color-to-alpha")
def color_to_alpha_cmd(
    input_path: Annotated[str, typer.Argument(help="Input image (or - for stdin)")],
    color: Annotated[
        str, typer.Option("--color", help="Color to make transparent (#RRGGBB)")
    ] = "#FFFFFF",
    tolerance: Annotated[
        float | None, typer.Option("--tolerance", help="Color matching tolerance")
    ] = None,
    output: OutputOpt = None,
    output_dir: OutputDirOpt = None,
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    api_key: ApiKeyOpt = None,
    api_url: ApiUrlOpt = None,
    quiet: QuietFlag = False,
) -> None:
    """Make a color transparent."""
    mode = detect_mode(force_json=json_output, force_human=human_output)
    client = _make_client(api_key, api_url, mode, quiet)
    resolved = _resolve_input(input_path)
    body: dict[str, Any] = {"color": color}
    if tolerance is not None:
        body["tolerance"] = tolerance
    _run_processing(
        client=client,
        endpoint="/v1/process/color-to-alpha",
        input_path=resolved,
        body=body,
        mode=mode,
        quiet=quiet,
        command="color-to-alpha",
        output=output,
        output_dir=output_dir,
    )


@app.command("rotate")
def rotate_cmd(
    input_path: Annotated[str, typer.Argument(help="Input image (or - for stdin)")],
    angle: Annotated[
        float,
        typer.Option(
            "--angle", help="Rotation angle in degrees, -360 to 360 (required)"
        ),
    ] = ...,  # type: ignore[assignment]
    expand: Annotated[
        bool | None, typer.Option("--expand", help="Expand canvas to fit")
    ] = None,
    fill_color: Annotated[
        str | None,
        typer.Option(
            "--fill-color",
            help="Fill color for exposed areas, #RRGGBB (optional, default: #FFFFFF)",
        ),
    ] = None,
    output: OutputOpt = None,
    output_dir: OutputDirOpt = None,
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    api_key: ApiKeyOpt = None,
    api_url: ApiUrlOpt = None,
    quiet: QuietFlag = False,
) -> None:
    """Rotate image by angle."""
    mode = detect_mode(force_json=json_output, force_human=human_output)
    client = _make_client(api_key, api_url, mode, quiet)
    resolved = _resolve_input(input_path)
    body: dict[str, Any] = {"angle": angle}
    if expand is not None:
        body["expand"] = expand
    if fill_color is not None:
        body["fill_color"] = fill_color
    _run_processing(
        client=client,
        endpoint="/v1/process/rotate",
        input_path=resolved,
        body=body,
        mode=mode,
        quiet=quiet,
        command="rotate",
        output=output,
        output_dir=output_dir,
    )


@app.command("trim")
def trim_cmd(
    input_path: Annotated[str, typer.Argument(help="Input image (or - for stdin)")],
    tolerance: Annotated[
        float | None, typer.Option("--tolerance", help="Border detection tolerance")
    ] = None,
    output: OutputOpt = None,
    output_dir: OutputDirOpt = None,
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    api_key: ApiKeyOpt = None,
    api_url: ApiUrlOpt = None,
    quiet: QuietFlag = False,
) -> None:
    """Auto-trim borders."""
    mode = detect_mode(force_json=json_output, force_human=human_output)
    client = _make_client(api_key, api_url, mode, quiet)
    resolved = _resolve_input(input_path)
    body: dict[str, Any] = {}
    if tolerance is not None:
        body["tolerance"] = tolerance
    _run_processing(
        client=client,
        endpoint="/v1/process/trim",
        input_path=resolved,
        body=body,
        mode=mode,
        quiet=quiet,
        command="trim",
        output=output,
        output_dir=output_dir,
    )


@app.command("pad")
def pad_cmd(
    input_path: Annotated[str, typer.Argument(help="Input image (or - for stdin)")],
    width: Annotated[
        int, typer.Option("--width", help="Target width in pixels (required)")
    ] = ...,  # type: ignore[assignment]
    height: Annotated[
        int, typer.Option("--height", help="Target height in pixels (required)")
    ] = ...,  # type: ignore[assignment]
    color: Annotated[
        str | None,
        typer.Option(
            "--color", help="Padding color, #RRGGBB (optional, default: #FFFFFF)"
        ),
    ] = None,
    gravity: Annotated[
        str | None, typer.Option("--gravity", help="Image position")
    ] = None,
    output: OutputOpt = None,
    output_dir: OutputDirOpt = None,
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    api_key: ApiKeyOpt = None,
    api_url: ApiUrlOpt = None,
    quiet: QuietFlag = False,
) -> None:
    """Add padding around image."""
    mode = detect_mode(force_json=json_output, force_human=human_output)
    client = _make_client(api_key, api_url, mode, quiet)
    resolved = _resolve_input(input_path)
    body: dict[str, Any] = {"width": width, "height": height}
    if color is not None:
        body["color"] = color
    if gravity is not None:
        body["gravity"] = gravity
    _run_processing(
        client=client,
        endpoint="/v1/process/pad",
        input_path=resolved,
        body=body,
        mode=mode,
        quiet=quiet,
        command="pad",
        output=output,
        output_dir=output_dir,
    )


@app.command("metadata-strip")
def metadata_strip_cmd(
    input_path: Annotated[str, typer.Argument(help="Input image (or - for stdin)")],
    keep_icc: Annotated[
        bool | None, typer.Option("--keep-icc", help="Keep ICC profile")
    ] = None,
    output: OutputOpt = None,
    output_dir: OutputDirOpt = None,
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    api_key: ApiKeyOpt = None,
    api_url: ApiUrlOpt = None,
    quiet: QuietFlag = False,
) -> None:
    """Strip image metadata."""
    mode = detect_mode(force_json=json_output, force_human=human_output)
    client = _make_client(api_key, api_url, mode, quiet)
    resolved = _resolve_input(input_path)
    body: dict[str, Any] = {}
    if keep_icc is not None:
        body["keep_icc"] = keep_icc
    _run_processing(
        client=client,
        endpoint="/v1/process/metadata-strip",
        input_path=resolved,
        body=body,
        mode=mode,
        quiet=quiet,
        command="metadata-strip",
        output=output,
        output_dir=output_dir,
    )


@app.command("overlay")
def overlay_cmd(
    input_path: Annotated[str, typer.Argument(help="Input image (or - for stdin)")],
    overlay_path: Annotated[
        str, typer.Option("--overlay", help="Overlay image path")
    ] = "",
    x: Annotated[int, typer.Option("--x", help="X position")] = 0,
    y: Annotated[int, typer.Option("--y", help="Y position")] = 0,
    opacity: Annotated[
        float | None, typer.Option("--opacity", help="Overlay opacity (0.0-1.0)")
    ] = None,
    output: OutputOpt = None,
    output_dir: OutputDirOpt = None,
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    api_key: ApiKeyOpt = None,
    api_url: ApiUrlOpt = None,
    quiet: QuietFlag = False,
) -> None:
    """Overlay an image on top of another."""
    mode = detect_mode(force_json=json_output, force_human=human_output)
    client = _make_client(api_key, api_url, mode, quiet)
    resolved = _resolve_input(input_path)
    # Upload both images
    upload_resp = client.upload_file("/v1/upload", resolved)
    overlay_resp = client.upload_file("/v1/upload", overlay_path)
    body: dict[str, Any] = {
        "input_image_url": upload_resp["upload_url"],
        "overlay_image_url": overlay_resp["upload_url"],
        "x": x,
        "y": y,
    }
    if opacity is not None:
        body["opacity"] = opacity
    # overlay uploads both images before POSTing, so we bypass _run_processing
    resp, _, _ = client.post_json("/v1/process/overlay", body)
    image_data = client.download_bytes(resp["image_url"])
    path = save_bytes(image_data, "overlay", output=output, output_dir=output_dir)
    print_processing(str(path.resolve()), mode, quiet)
    client.close()
