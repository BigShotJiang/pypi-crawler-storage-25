"""Auth commands: login, logout, status."""

from __future__ import annotations

import json
import os
import sys
from typing import Annotated

import typer
from rich.prompt import Prompt

from depicta.client import DepictaClient
from depicta.config import (
    load_config,
    mask_key,
    resolve_api_key,
    resolve_api_url,
    save_config,
)
from depicta.errors import EXIT_AUTH, DepictaError
from depicta.flags import ApiUrlOpt, HumanFlag, JsonFlag, QuietFlag
from depicta.output import OutputMode, detect_mode, stderr_console

app = typer.Typer(no_args_is_help=True)


@app.command("login")
def login_cmd(
    api_url: ApiUrlOpt = None,
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    quiet: QuietFlag = False,
) -> None:
    """Configure API key."""
    mode = detect_mode(force_json=json_output, force_human=human_output)

    stderr_console.print("Get your API key at https://depicta.ai/dashboard/api-keys")

    if sys.stdin.isatty():
        key = Prompt.ask("API key", password=True, console=stderr_console)
    else:
        key = sys.stdin.readline().strip()

    if not key:
        raise DepictaError("No API key provided", "authentication_error", EXIT_AUTH)

    url = resolve_api_url(api_url)
    client = DepictaClient(key, url)
    try:
        profile = client.get("/v1/account/profile")
    except DepictaError:
        raise
    finally:
        client.close()

    email = profile.get("user", {}).get("email", "unknown")

    cfg = load_config()
    cfg["api_key"] = key
    save_config(cfg)

    if mode == OutputMode.JSON:
        print(json.dumps({"status": "authenticated", "email": email}))
    elif not quiet:
        stderr_console.print(f"[green]Authenticated as {email}[/]")


@app.command("logout")
def logout_cmd(
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    quiet: QuietFlag = False,
) -> None:
    """Remove stored credentials."""
    mode = detect_mode(force_json=json_output, force_human=human_output)

    cfg = load_config()
    cfg.pop("api_key", None)
    save_config(cfg)

    if mode == OutputMode.JSON:
        print(json.dumps({"status": "logged_out"}))
    elif not quiet:
        stderr_console.print("Credentials removed.")


@app.command("status")
def status_cmd(
    api_key: Annotated[str | None, typer.Option("--api-key")] = None,
    api_url: ApiUrlOpt = None,
    json_output: JsonFlag = False,
    human_output: HumanFlag = False,
    quiet: QuietFlag = False,
) -> None:
    """Show current auth state."""
    mode = detect_mode(force_json=json_output, force_human=human_output)

    key = resolve_api_key(api_key)
    if not key:
        if mode == OutputMode.JSON:
            print(json.dumps({"method": "none", "authenticated": False}))
        elif not quiet:
            stderr_console.print("Not authenticated. Run [bold]depicta auth login[/].")
        return

    if api_key:
        method = "flag"
    elif os.environ.get("DEPICTA_API_KEY"):
        method = "env"
    else:
        method = "config"

    masked = mask_key(key)

    url = resolve_api_url(api_url)
    client = DepictaClient(key, url)
    try:
        profile = client.get("/v1/account/profile")
        email = profile.get("user", {}).get("email", "unknown")
    except DepictaError:
        email = None
    finally:
        client.close()

    if mode == OutputMode.JSON:
        result = {
            "method": method,
            "key_prefix": masked,
            "authenticated": email is not None,
        }
        if email:
            result["email"] = email
        print(json.dumps(result))
    elif not quiet:
        stderr_console.print(f"Auth method: {method}")
        stderr_console.print(f"Key: {masked}")
        if email:
            stderr_console.print(f"Account: {email}")
        else:
            stderr_console.print("[red]Key is invalid[/]")
