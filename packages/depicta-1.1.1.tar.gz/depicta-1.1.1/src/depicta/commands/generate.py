"""Generation commands: image, graphic, diagram, edit, combine."""

from __future__ import annotations

import sys
from typing import Annotated, Any

import typer

from depicta.client import DepictaClient
from depicta.config import resolve_api_key, resolve_api_url
from depicta.download import save_bytes
from depicta.errors import EXIT_AUTH, DepictaError
from depicta.flags import (
    ApiKeyOpt,
    ApiUrlOpt,
    DiagramTypeOpt,
    FormatOpt,
    HumanFlag,
    ImageSizeOpt,
    JsonFlag,
    ModelOpt,
    OutputDirOpt,
    OutputOpt,
    QualityOpt,
    QuietFlag,
    ReferenceOpt,
    SizeOpt,
    StrictnessOpt,
)
from depicta.output import OutputMode, detect_mode, print_generation, warn_api_key_flag


def _resolve_input(path: str) -> str:
    """Resolve input: file path, stdin (-), or URL."""
    if path == "-":
        line = sys.stdin.readline().strip()
        if not line:
            raise typer.Exit(1)
        return line
    return path


def _pick_format_url(resp: dict[str, Any], fmt: str) -> tuple[str, str]:
    """Pick the download URL and hash for the requested format.

    The API returns three variants in resp["formats"]. Falls back to
    resp["image_url"] (PNG) if formats map is absent.
    Returns (url, hash).
    """
    formats = resp.get("formats", {})
    api_fmt = "jpeg" if fmt in ("jpg", "jpeg") else fmt
    variant = formats.get(api_fmt)
    if variant:
        return variant["url"], variant.get("hash", resp.get("image_hash", ""))
    return resp["image_url"], resp.get("image_hash", "")


def _save_last_job_id(job_id: str) -> None:
    """Store last job ID in config dir for recovery via 'depicta jobs list'."""
    from depicta.config import _config_dir

    path = _config_dir() / "last_job_id"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(job_id)


def _recover_from_job(
    client: DepictaClient, job_id: str, fmt: str
) -> tuple[str, str] | None:
    """Try to recover download URL from a job ID via GET /v1/jobs/{id}."""
    try:
        job = client.get(f"/v1/jobs/{job_id}")
        # Job response may have formats map or image_url
        return _pick_format_url(job, fmt)
    except Exception:
        return None


def _run_generation(
    *,
    client: DepictaClient,
    endpoint: str,
    body: dict[str, Any],
    mode: OutputMode,
    quiet: bool,
    command: str,
    output: str | None,
    output_dir: str | None,
    fmt: str | None,
) -> None:
    """Shared generation flow: POST, pick format variant, download with retry, print."""
    try:
        resp, _, headers = client.post_json(endpoint, body)
    except Exception as e:
        err_str = str(e).lower()
        if any(token in err_str for token in ("connect", "timeout", "network")):
            from depicta.output import stderr_console

            stderr_console.print(
                "[yellow]Generation may have completed. Check: depicta jobs list[/]"
            )
        raise
    job_id = headers.get("x-depicta-job-id", "")
    if job_id:
        _save_last_job_id(job_id)
    ext = fmt or "png"
    download_url, image_hash = _pick_format_url(resp, ext)

    # Download with retry via job recovery
    import time

    image_data = None
    last_err = None
    for attempt in range(3):
        try:
            image_data = client.download_bytes(download_url)
            break
        except Exception as e:
            last_err = e
            if attempt < 2 and job_id:
                if not quiet:
                    from depicta.output import stderr_console

                    stderr_console.print(
                        "[yellow]Download failed"
                        f" (attempt {attempt + 1}/3),"
                        " retrying via job recovery...[/]"
                    )
                time.sleep(1)
                recovered = _recover_from_job(client, job_id, ext)
                if recovered:
                    download_url, image_hash = recovered

    if image_data is None:
        raise last_err  # type: ignore[misc]

    path = save_bytes(
        image_data, command, ext=ext, output=output, output_dir=output_dir
    )
    resp_for_output = {**resp, "image_hash": image_hash}
    print_generation(str(path.resolve()), resp_for_output, mode, quiet)
    client.close()


def _make_client(
    api_key: str | None, api_url: str | None, mode: OutputMode, quiet: bool
) -> DepictaClient:
    """Resolve auth, warn if flag used, create client."""
    key = resolve_api_key(api_key)
    if not key:
        raise DepictaError(
            "No API key configured. Run 'depicta auth login' or set DEPICTA_API_KEY.",
            "authentication_error",
            EXIT_AUTH,
        )
    if api_key:
        warn_api_key_flag(mode, quiet)
    url = resolve_api_url(api_url)
    return DepictaClient(key, url)


def _add_optional(body: dict[str, Any], key: str, value: Any) -> None:
    """Add a key to the body if the value is not None."""
    if value is not None:
        body[key] = value


def _upload_references(
    client: DepictaClient,
    references: list[str] | None,
) -> list[dict[str, str]] | None:
    """Parse -r PATH:DESCRIPTION entries, upload each, return ReferenceImage list.

    Returns None when no references were given so the field is omitted entirely.
    Raises DepictaError if any entry is malformed.
    """
    if not references:
        return None
    result: list[dict[str, str]] = []
    for entry in references:
        if ":" not in entry:
            raise DepictaError(
                f"Invalid --reference value '{entry}'. Expected PATH:DESCRIPTION.",
                "validation_error",
                2,
            )
        path, description = entry.split(":", 1)
        if not path or not description:
            raise DepictaError(
                f"Invalid --reference '{entry}'. Both PATH and DESCRIPTION required.",
                "validation_error",
                2,
            )
        upload_resp = client.upload_file("/v1/upload", _resolve_input(path))
        result.append({"url": upload_resp["upload_url"], "description": description})
    return result


edit_app = typer.Typer(
    no_args_is_help=True, help="Edit an existing image, graphic, or diagram"
)
combine_app = typer.Typer(
    no_args_is_help=True, help="Combine images, graphics, or diagrams"
)


def _create_command(
    *,
    prompt: str,
    client: DepictaClient,
    endpoint: str,
    command: str,
    model: str | None,
    size: str | None,
    image_size: str | None,
    references: list[str] | None,
    strictness: str | None,
    diagram_type: str | None,
    mode: OutputMode,
    quiet: bool,
    output: str | None,
    output_dir: str | None,
    fmt: str | None,
) -> None:
    """Shared generate-create flow (image/graphic/diagram)."""
    body: dict[str, Any] = {"prompt": prompt}
    _add_optional(body, "model", model)
    _add_optional(body, "aspect_ratio", size)
    _add_optional(body, "image_size", image_size)
    _add_optional(body, "strictness", strictness)
    _add_optional(body, "diagram_type", diagram_type)
    _add_optional(body, "reference_images", _upload_references(client, references))
    _run_generation(
        client=client,
        endpoint=endpoint,
        body=body,
        mode=mode,
        quiet=quiet,
        command=command,
        output=output,
        output_dir=output_dir,
        fmt=fmt,
    )


def _edit_command(
    *,
    input_path: str,
    prompt: str,
    client: DepictaClient,
    endpoint: str,
    command: str,
    model: str | None,
    size: str | None,
    image_size: str | None,
    references: list[str] | None,
    strictness: str | None,
    diagram_type: str | None,
    mode: OutputMode,
    quiet: bool,
    output: str | None,
    output_dir: str | None,
    fmt: str | None,
) -> None:
    """Shared edit flow (edit image/graphic/diagram)."""
    upload_resp = client.upload_file("/v1/upload", _resolve_input(input_path))
    body: dict[str, Any] = {
        "prompt": prompt,
        "input_image_url": upload_resp["upload_url"],
    }
    _add_optional(body, "model", model)
    _add_optional(body, "aspect_ratio", size)
    _add_optional(body, "image_size", image_size)
    _add_optional(body, "strictness", strictness)
    _add_optional(body, "diagram_type", diagram_type)
    _add_optional(body, "reference_images", _upload_references(client, references))
    _run_generation(
        client=client,
        endpoint=endpoint,
        body=body,
        mode=mode,
        quiet=quiet,
        command=command,
        output=output,
        output_dir=output_dir,
        fmt=fmt,
    )


def _combine_command(
    *,
    images: list[str],
    prompt: str | None,
    default_prompt: str,
    client: DepictaClient,
    endpoint: str,
    command: str,
    model: str | None,
    size: str | None,
    image_size: str | None,
    references: list[str] | None,
    strictness: str | None,
    diagram_type: str | None,
    mode: OutputMode,
    quiet: bool,
    output: str | None,
    output_dir: str | None,
    fmt: str | None,
) -> None:
    """Shared combine flow (combine image/graphic/diagram)."""
    if not 2 <= len(images) <= 5:
        raise DepictaError(
            f"combine requires 2-5 images, got {len(images)}.",
            "validation_error",
            2,
        )
    urls = []
    for img in images:
        resp = client.upload_file("/v1/upload", _resolve_input(img))
        urls.append(resp["upload_url"])
    body: dict[str, Any] = {
        "input_image_urls": urls,
        "prompt": prompt or default_prompt,
    }
    _add_optional(body, "model", model)
    _add_optional(body, "aspect_ratio", size)
    _add_optional(body, "image_size", image_size)
    _add_optional(body, "strictness", strictness)
    _add_optional(body, "diagram_type", diagram_type)
    _add_optional(body, "reference_images", _upload_references(client, references))
    _run_generation(
        client=client,
        endpoint=endpoint,
        body=body,
        mode=mode,
        quiet=quiet,
        command=command,
        output=output,
        output_dir=output_dir,
        fmt=fmt,
    )


def register(app: typer.Typer) -> None:
    """Register all generation commands on the Typer app."""

    @app.command("image")
    def image_cmd(
        prompt: Annotated[str, typer.Argument(help="Text prompt")],
        model: ModelOpt = None,
        size: SizeOpt = None,
        image_size: ImageSizeOpt = None,
        reference: ReferenceOpt = None,
        output: OutputOpt = None,
        output_dir: OutputDirOpt = None,
        fmt: FormatOpt = None,
        quality: QualityOpt = 85,
        strictness: StrictnessOpt = None,
        json_output: JsonFlag = False,
        human_output: HumanFlag = False,
        api_key: ApiKeyOpt = None,
        api_url: ApiUrlOpt = None,
        quiet: QuietFlag = False,
    ) -> None:
        """Generate image from text."""
        mode = detect_mode(force_json=json_output, force_human=human_output)
        client = _make_client(api_key, api_url, mode, quiet)
        _create_command(
            prompt=prompt,
            client=client,
            endpoint="/v1/generate/image",
            command="image",
            model=model,
            size=size,
            image_size=image_size,
            references=reference,
            strictness=strictness,
            diagram_type=None,
            mode=mode,
            quiet=quiet,
            output=output,
            output_dir=output_dir,
            fmt=fmt,
        )

    @app.command("graphic")
    def graphic_cmd(
        prompt: Annotated[str, typer.Argument(help="Graphic description")],
        model: ModelOpt = None,
        size: SizeOpt = None,
        image_size: ImageSizeOpt = None,
        reference: ReferenceOpt = None,
        output: OutputOpt = None,
        output_dir: OutputDirOpt = None,
        fmt: FormatOpt = None,
        quality: QualityOpt = 85,
        strictness: StrictnessOpt = None,
        json_output: JsonFlag = False,
        human_output: HumanFlag = False,
        api_key: ApiKeyOpt = None,
        api_url: ApiUrlOpt = None,
        quiet: QuietFlag = False,
    ) -> None:
        """Generate icon, logo, or clipart."""
        mode = detect_mode(force_json=json_output, force_human=human_output)
        client = _make_client(api_key, api_url, mode, quiet)
        _create_command(
            prompt=prompt,
            client=client,
            endpoint="/v1/generate/graphic",
            command="graphic",
            model=model,
            size=size,
            image_size=image_size,
            references=reference,
            strictness=strictness,
            diagram_type=None,
            mode=mode,
            quiet=quiet,
            output=output,
            output_dir=output_dir,
            fmt=fmt,
        )

    @app.command("diagram")
    def diagram_cmd(
        prompt: Annotated[str, typer.Argument(help="Diagram description")],
        model: ModelOpt = None,
        diagram_type: DiagramTypeOpt = None,
        size: SizeOpt = None,
        image_size: ImageSizeOpt = None,
        reference: ReferenceOpt = None,
        output: OutputOpt = None,
        output_dir: OutputDirOpt = None,
        fmt: FormatOpt = None,
        quality: QualityOpt = 85,
        strictness: StrictnessOpt = None,
        json_output: JsonFlag = False,
        human_output: HumanFlag = False,
        api_key: ApiKeyOpt = None,
        api_url: ApiUrlOpt = None,
        quiet: QuietFlag = False,
    ) -> None:
        """Generate a diagram."""
        mode = detect_mode(force_json=json_output, force_human=human_output)
        client = _make_client(api_key, api_url, mode, quiet)
        _create_command(
            prompt=prompt,
            client=client,
            endpoint="/v1/generate/diagram",
            command="diagram",
            model=model,
            size=size,
            image_size=image_size,
            references=reference,
            strictness=strictness,
            diagram_type=diagram_type,
            mode=mode,
            quiet=quiet,
            output=output,
            output_dir=output_dir,
            fmt=fmt,
        )

    # --- edit subcommands ---

    @edit_app.command("image")
    def edit_image_cmd(
        input_path: Annotated[str, typer.Argument(help="Input image (or - for stdin)")],
        prompt: Annotated[str, typer.Argument(help="Edit instructions")],
        model: ModelOpt = None,
        size: SizeOpt = None,
        image_size: ImageSizeOpt = None,
        reference: ReferenceOpt = None,
        output: OutputOpt = None,
        output_dir: OutputDirOpt = None,
        fmt: FormatOpt = None,
        quality: QualityOpt = 85,
        strictness: StrictnessOpt = None,
        json_output: JsonFlag = False,
        human_output: HumanFlag = False,
        api_key: ApiKeyOpt = None,
        api_url: ApiUrlOpt = None,
        quiet: QuietFlag = False,
    ) -> None:
        """Edit a photo or image."""
        mode = detect_mode(force_json=json_output, force_human=human_output)
        client = _make_client(api_key, api_url, mode, quiet)
        _edit_command(
            input_path=input_path,
            prompt=prompt,
            client=client,
            endpoint="/v1/edit/image",
            command="edit-image",
            model=model,
            size=size,
            image_size=image_size,
            references=reference,
            strictness=strictness,
            diagram_type=None,
            mode=mode,
            quiet=quiet,
            output=output,
            output_dir=output_dir,
            fmt=fmt,
        )

    @edit_app.command("graphic")
    def edit_graphic_cmd(
        input_path: Annotated[
            str, typer.Argument(help="Input graphic (or - for stdin)")
        ],
        prompt: Annotated[str, typer.Argument(help="Edit instructions")],
        model: ModelOpt = None,
        size: SizeOpt = None,
        image_size: ImageSizeOpt = None,
        reference: ReferenceOpt = None,
        output: OutputOpt = None,
        output_dir: OutputDirOpt = None,
        fmt: FormatOpt = None,
        quality: QualityOpt = 85,
        strictness: StrictnessOpt = None,
        json_output: JsonFlag = False,
        human_output: HumanFlag = False,
        api_key: ApiKeyOpt = None,
        api_url: ApiUrlOpt = None,
        quiet: QuietFlag = False,
    ) -> None:
        """Edit an icon, logo, or clipart."""
        mode = detect_mode(force_json=json_output, force_human=human_output)
        client = _make_client(api_key, api_url, mode, quiet)
        _edit_command(
            input_path=input_path,
            prompt=prompt,
            client=client,
            endpoint="/v1/edit/graphic",
            command="edit-graphic",
            model=model,
            size=size,
            image_size=image_size,
            references=reference,
            strictness=strictness,
            diagram_type=None,
            mode=mode,
            quiet=quiet,
            output=output,
            output_dir=output_dir,
            fmt=fmt,
        )

    @edit_app.command("diagram")
    def edit_diagram_cmd(
        input_path: Annotated[
            str, typer.Argument(help="Input diagram (or - for stdin)")
        ],
        prompt: Annotated[str, typer.Argument(help="Edit instructions")],
        model: ModelOpt = None,
        diagram_type: DiagramTypeOpt = None,
        size: SizeOpt = None,
        image_size: ImageSizeOpt = None,
        reference: ReferenceOpt = None,
        output: OutputOpt = None,
        output_dir: OutputDirOpt = None,
        fmt: FormatOpt = None,
        quality: QualityOpt = 85,
        strictness: StrictnessOpt = None,
        json_output: JsonFlag = False,
        human_output: HumanFlag = False,
        api_key: ApiKeyOpt = None,
        api_url: ApiUrlOpt = None,
        quiet: QuietFlag = False,
    ) -> None:
        """Edit a diagram."""
        mode = detect_mode(force_json=json_output, force_human=human_output)
        client = _make_client(api_key, api_url, mode, quiet)
        _edit_command(
            input_path=input_path,
            prompt=prompt,
            client=client,
            endpoint="/v1/edit/diagram",
            command="edit-diagram",
            model=model,
            size=size,
            image_size=image_size,
            references=reference,
            strictness=strictness,
            diagram_type=diagram_type,
            mode=mode,
            quiet=quiet,
            output=output,
            output_dir=output_dir,
            fmt=fmt,
        )

    app.add_typer(edit_app, name="edit")

    # --- combine subcommands ---

    @combine_app.command("image")
    def combine_image_cmd(
        images: Annotated[
            list[str],
            typer.Argument(help="Image paths to combine (2-5, or - for stdin)"),
        ],
        prompt: Annotated[
            str | None,
            typer.Option("--prompt", "-p", help="Composition instructions"),
        ] = None,
        model: ModelOpt = None,
        size: SizeOpt = None,
        image_size: ImageSizeOpt = None,
        reference: ReferenceOpt = None,
        output: OutputOpt = None,
        output_dir: OutputDirOpt = None,
        fmt: FormatOpt = None,
        quality: QualityOpt = 85,
        strictness: StrictnessOpt = None,
        json_output: JsonFlag = False,
        human_output: HumanFlag = False,
        api_key: ApiKeyOpt = None,
        api_url: ApiUrlOpt = None,
        quiet: QuietFlag = False,
    ) -> None:
        """Combine 2-5 photos or images into one composition."""
        mode = detect_mode(force_json=json_output, force_human=human_output)
        client = _make_client(api_key, api_url, mode, quiet)
        _combine_command(
            images=images,
            prompt=prompt,
            default_prompt="Combine these images naturally",
            client=client,
            endpoint="/v1/combine/image",
            command="combine-image",
            model=model,
            size=size,
            image_size=image_size,
            references=reference,
            strictness=strictness,
            diagram_type=None,
            mode=mode,
            quiet=quiet,
            output=output,
            output_dir=output_dir,
            fmt=fmt,
        )

    @combine_app.command("graphic")
    def combine_graphic_cmd(
        images: Annotated[
            list[str],
            typer.Argument(help="Image paths to combine (2-5, or - for stdin)"),
        ],
        prompt: Annotated[
            str | None,
            typer.Option("--prompt", "-p", help="Composition instructions"),
        ] = None,
        model: ModelOpt = None,
        size: SizeOpt = None,
        image_size: ImageSizeOpt = None,
        reference: ReferenceOpt = None,
        output: OutputOpt = None,
        output_dir: OutputDirOpt = None,
        fmt: FormatOpt = None,
        quality: QualityOpt = 85,
        strictness: StrictnessOpt = None,
        json_output: JsonFlag = False,
        human_output: HumanFlag = False,
        api_key: ApiKeyOpt = None,
        api_url: ApiUrlOpt = None,
        quiet: QuietFlag = False,
    ) -> None:
        """Combine 2-5 icons, logos, or graphics."""
        mode = detect_mode(force_json=json_output, force_human=human_output)
        client = _make_client(api_key, api_url, mode, quiet)
        _combine_command(
            images=images,
            prompt=prompt,
            default_prompt="Combine these graphics naturally",
            client=client,
            endpoint="/v1/combine/graphic",
            command="combine-graphic",
            model=model,
            size=size,
            image_size=image_size,
            references=reference,
            strictness=strictness,
            diagram_type=None,
            mode=mode,
            quiet=quiet,
            output=output,
            output_dir=output_dir,
            fmt=fmt,
        )

    @combine_app.command("diagram")
    def combine_diagram_cmd(
        images: Annotated[
            list[str],
            typer.Argument(help="Image paths to combine (2-5, or - for stdin)"),
        ],
        prompt: Annotated[
            str | None,
            typer.Option("--prompt", "-p", help="Composition instructions"),
        ] = None,
        model: ModelOpt = None,
        diagram_type: DiagramTypeOpt = None,
        size: SizeOpt = None,
        image_size: ImageSizeOpt = None,
        reference: ReferenceOpt = None,
        output: OutputOpt = None,
        output_dir: OutputDirOpt = None,
        fmt: FormatOpt = None,
        quality: QualityOpt = 85,
        strictness: StrictnessOpt = None,
        json_output: JsonFlag = False,
        human_output: HumanFlag = False,
        api_key: ApiKeyOpt = None,
        api_url: ApiUrlOpt = None,
        quiet: QuietFlag = False,
    ) -> None:
        """Combine 2-5 diagrams into one composition."""
        mode = detect_mode(force_json=json_output, force_human=human_output)
        client = _make_client(api_key, api_url, mode, quiet)
        _combine_command(
            images=images,
            prompt=prompt,
            default_prompt="Combine these diagrams naturally",
            client=client,
            endpoint="/v1/combine/diagram",
            command="combine-diagram",
            model=model,
            size=size,
            image_size=image_size,
            references=reference,
            strictness=strictness,
            diagram_type=diagram_type,
            mode=mode,
            quiet=quiet,
            output=output,
            output_dir=output_dir,
            fmt=fmt,
        )

    app.add_typer(combine_app, name="combine")
