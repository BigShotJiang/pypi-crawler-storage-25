"""Depicta CLI command modules."""
