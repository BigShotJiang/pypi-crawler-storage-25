"""Story command: async submit/poll + story status."""

from __future__ import annotations

import json
import signal
import time
from pathlib import Path
from typing import Annotated, Any

import typer

from depicta.client import DepictaClient
from depicta.config import resolve_api_key, resolve_api_url
from depicta.errors import EXIT_AUTH, EXIT_GENERAL, DepictaError
from depicta.flags import (
    ApiKeyOpt,
    ApiUrlOpt,
    FormatOpt,
    HumanFlag,
    JsonFlag,
    OutputDirOpt,
    QualityOpt,
    QuietFlag,
    TimeoutOpt,
)
from depicta.output import (
    OutputMode,
    detect_mode,
    format_story_json,
    stderr_console,
    warn_api_key_flag,
)

POLL_INTERVAL = 3


def _make_client(
    api_key: str | None, api_url: str | None, mode: OutputMode, quiet: bool
) -> DepictaClient:
    key = resolve_api_key(api_key)
    if not key:
        raise DepictaError("No API key configured.", "authentication_error", EXIT_AUTH)
    if api_key:
        warn_api_key_flag(mode, quiet)
    return DepictaClient(key, resolve_api_url(api_url))


def _poll_story(
    client: DepictaClient,
    job_id: str,
    output_dir: Path,
    mode: OutputMode,
    quiet: bool,
    timeout: int,
) -> dict[str, Any]:
    """Poll story job until completion. Returns final result dict."""
    interrupted = False

    def _handle_sigint(sig: int, frame: Any) -> None:
        nonlocal interrupted
        interrupted = True

    old_handler = signal.signal(signal.SIGINT, _handle_sigint)
    start = time.monotonic()
    downloaded: set[int] = set()

    try:
        while True:
            if interrupted:
                stderr_console.print(
                    f"\nInterrupted. Resume with: depicta story status {job_id}",
                    style="yellow",
                )
                raise SystemExit(1)

            elapsed = time.monotonic() - start
            if elapsed > timeout:
                stderr_console.print(
                    f"\nTimeout. Resume with: depicta story status {job_id}",
                    style="yellow",
                )
                raise SystemExit(1)

            status = client.get(f"/v1/generate/story/{job_id}")

            result = status.get("result", {})
            scenes = result.get("scenes", [])
            for i, scene in enumerate(scenes):
                if i not in downloaded and "image_url" in scene:
                    img = client.download_bytes(scene["image_url"])
                    scene_path = output_dir / f"scene-{i + 1:02d}.png"
                    scene_path.write_bytes(img)
                    downloaded.add(i)
                    if mode == OutputMode.HUMAN and not quiet:
                        total = status.get("scenes_total", "?")
                        stderr_console.print(f"  Scene {i + 1}/{total} downloaded")

            if status["status"] == "completed":
                final_scenes = []
                for i, scene in enumerate(result["scenes"]):
                    scene_path = output_dir / f"scene-{i + 1:02d}.png"
                    final_scenes.append(
                        {
                            "file": str(scene_path.resolve()),
                        }
                    )
                return {
                    "job_id": job_id,
                    "title": result.get("title", ""),
                    "scenes": final_scenes,
                    "cost_eur": result.get("cost_eur", "0"),
                    "balance_eur": result.get("balance_eur", "0"),
                }

            if status["status"] == "failed":
                raise DepictaError(
                    "Story generation failed", "general_error", EXIT_GENERAL
                )

            time.sleep(POLL_INTERVAL)
    finally:
        signal.signal(signal.SIGINT, old_handler)


def register(app: typer.Typer) -> None:
    """Register story commands on the Typer app."""

    story_app = typer.Typer(no_args_is_help=True)

    @story_app.command("run")
    def story_run_cmd(
        storyboard: Annotated[str, typer.Argument(help="Storyboard JSON file")],
        output_dir: OutputDirOpt = None,
        fmt: FormatOpt = None,
        quality: QualityOpt = 85,
        timeout: TimeoutOpt = 600,
        json_output: JsonFlag = False,
        human_output: HumanFlag = False,
        api_key: ApiKeyOpt = None,
        api_url: ApiUrlOpt = None,
        quiet: QuietFlag = False,
    ) -> None:
        """Generate multi-scene story from storyboard JSON."""

        mode = detect_mode(force_json=json_output, force_human=human_output)
        client = _make_client(api_key, api_url, mode, quiet)

        board = json.loads(Path(storyboard).read_text())

        resp, _, _ = client.post_json("/v1/generate/story", board)
        job_id = resp["job_id"]

        if mode == OutputMode.HUMAN and not quiet:
            stderr_console.print(f"Story submitted (job {job_id}). Polling...")

        out_dir = Path(output_dir or f"./depicta-story-{int(time.time())}")
        out_dir.mkdir(parents=True, exist_ok=True)

        result = _poll_story(client, job_id, out_dir, mode, quiet, timeout)
        client.close()

        if mode == OutputMode.JSON:
            print(format_story_json(result=result))
        elif mode == OutputMode.HUMAN:
            if not quiet:
                stderr_console.print(
                    f"[green]✓[/] Story complete: {len(result['scenes'])} scenes"
                )
                stderr_console.print(f"  Total cost: EUR {result['cost_eur']}")
            print(str(out_dir.resolve()))
        else:
            print(str(out_dir.resolve()))

    @story_app.command("status")
    def story_status_cmd(
        job_id: Annotated[str, typer.Argument(help="Story job ID")],
        json_output: JsonFlag = False,
        human_output: HumanFlag = False,
        api_key: ApiKeyOpt = None,
        api_url: ApiUrlOpt = None,
        quiet: QuietFlag = False,
    ) -> None:
        """Poll status of an async story job."""
        mode = detect_mode(force_json=json_output, force_human=human_output)
        client = _make_client(api_key, api_url, mode, quiet)
        status = client.get(f"/v1/generate/story/{job_id}")
        client.close()

        if mode == OutputMode.JSON:
            print(json.dumps(status))
        elif mode == OutputMode.HUMAN and not quiet:
            stderr_console.print(f"Job: {status.get('job_id', job_id)}")
            stderr_console.print(f"Status: {status['status']}")
            completed = status.get("scenes_completed", 0)
            total = status.get("scenes_total", "?")
            stderr_console.print(f"Progress: {completed}/{total}")

    app.add_typer(story_app, name="story", help="Story generation")
