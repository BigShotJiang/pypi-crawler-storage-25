"""Depicta API client — sync httpx."""

from __future__ import annotations

from typing import Any

import httpx

from depicta.errors import error_from_response


class DepictaClient:
    """Sync HTTP client for the Depicta API."""

    def __init__(self, api_key: str, base_url: str, timeout: float = 360.0):
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._client = httpx.Client(
            base_url=self._base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=httpx.Timeout(timeout, connect=10.0),
        )

    def get(self, path: str) -> dict[str, Any]:
        """GET request. Raises DepictaError on non-2xx."""
        resp = self._client.get(path)
        if resp.status_code >= 400:
            self._raise_error(resp)
        result: dict[str, Any] = resp.json()
        return result

    def post_json(
        self, path: str, body: dict[str, Any]
    ) -> tuple[dict[str, Any], int, dict[str, str]]:
        """POST JSON request. Returns (body, status_code, headers). Raises on error."""
        resp = self._client.post(path, json=body)
        if resp.status_code >= 400:
            self._raise_error(resp)
        resp_body: dict[str, Any] = resp.json()
        return resp_body, resp.status_code, dict(resp.headers)

    def upload_file(self, path: str, file_path: str) -> dict[str, Any]:
        """Upload a file via multipart/form-data."""
        with open(file_path, "rb") as f:
            resp = httpx.post(
                f"{self._base_url}{path}",
                files={"image": f},
                headers={"Authorization": f"Bearer {self._api_key}"},
                timeout=120.0,
            )
        if resp.status_code >= 400:
            self._raise_error(resp)
        result: dict[str, Any] = resp.json()
        return result

    def download_bytes(self, url: str) -> bytes:
        """Download raw bytes from an absolute URL."""
        resp = httpx.get(url, timeout=120.0)
        resp.raise_for_status()
        return resp.content

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def _raise_error(self, resp: httpx.Response) -> None:
        """Parse error response and raise DepictaError."""
        try:
            body = resp.json()
        except Exception:
            body = {"error": "general_error", "message": resp.text}
        raise error_from_response(resp.status_code, body)
