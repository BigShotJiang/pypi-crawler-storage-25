"""Shared test fixtures."""

from __future__ import annotations

import os
from pathlib import Path

import pytest


@pytest.fixture
def tmp_config_dir(tmp_path: Path) -> Path:
    """Provide an isolated config directory."""
    config_dir = tmp_path / "config"
    config_dir.mkdir()
    os.environ["XDG_CONFIG_HOME"] = str(config_dir)
    yield config_dir
    os.environ.pop("XDG_CONFIG_HOME", None)


@pytest.fixture
def tmp_output_dir(tmp_path: Path) -> Path:
    """Provide an isolated output directory."""
    out = tmp_path / "output"
    out.mkdir()
    return out
