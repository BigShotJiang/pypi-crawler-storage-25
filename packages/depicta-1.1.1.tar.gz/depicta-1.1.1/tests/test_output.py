"""Tests for output module."""

from __future__ import annotations

import json
from unittest.mock import patch

from depicta.output import (
    OutputMode,
    detect_mode,
    format_balance_json,
    format_generation_json,
)


def test_detect_mode_json_flag() -> None:
    assert detect_mode(force_json=True) == OutputMode.JSON


def test_detect_mode_human_flag() -> None:
    assert detect_mode(force_human=True) == OutputMode.HUMAN


def test_detect_mode_tty() -> None:
    with patch("sys.stdout") as mock_stdout:
        mock_stdout.isatty.return_value = True
        assert detect_mode() == OutputMode.HUMAN


def test_detect_mode_pipe() -> None:
    with patch("sys.stdout") as mock_stdout:
        mock_stdout.isatty.return_value = False
        assert detect_mode() == OutputMode.PIPE


def test_format_generation_json() -> None:
    result = format_generation_json(
        file_path="/tmp/test.png",
        cost_eur="0.045000",
        balance_eur="4.955000",
        image_hash="sha256-abc",
        model="flux-1.1-pro",
    )
    parsed = json.loads(result)
    assert parsed["file"] == "/tmp/test.png"
    assert parsed["cost_eur"] == "0.045000"
    assert parsed["ai_generated"] is True


def test_format_balance_json() -> None:
    result = format_balance_json(balance_eur="4.950000", held_eur="0.050000")
    parsed = json.loads(result)
    assert parsed["balance_eur"] == "4.950000"
    assert parsed["held_eur"] == "0.050000"
