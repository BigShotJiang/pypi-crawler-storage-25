"""Tests for config module."""

from __future__ import annotations

import os
import stat
from pathlib import Path

import pytest

from depicta.config import (
    config_path,
    load_config,
    mask_key,
    resolve_api_key,
    resolve_api_url,
    save_config,
)


def test_config_path_uses_xdg(tmp_config_dir: Path) -> None:
    path = config_path()
    assert str(tmp_config_dir) in str(path)
    assert path.name == "config.json"


def test_load_config_empty(tmp_config_dir: Path) -> None:
    assert load_config() == {}


def test_save_and_load_config(tmp_config_dir: Path) -> None:
    data = {"api_key": "dpct_test123", "api_url": "https://example.com"}
    save_config(data)
    loaded = load_config()
    assert loaded["api_key"] == "dpct_test123"
    assert loaded["api_url"] == "https://example.com"


def test_save_config_permissions(tmp_config_dir: Path) -> None:
    save_config({"api_key": "test"})
    path = config_path()
    mode = stat.S_IMODE(path.stat().st_mode)
    assert mode == 0o600


def test_resolve_api_key_flag_first(tmp_config_dir: Path) -> None:
    os.environ["DEPICTA_API_KEY"] = "env_key"
    save_config({"api_key": "config_key"})
    assert resolve_api_key("flag_key") == "flag_key"
    os.environ.pop("DEPICTA_API_KEY")


def test_resolve_api_key_env_second(tmp_config_dir: Path) -> None:
    os.environ["DEPICTA_API_KEY"] = "env_key"
    save_config({"api_key": "config_key"})
    assert resolve_api_key(None) == "env_key"
    os.environ.pop("DEPICTA_API_KEY")


def test_resolve_api_key_config_third(tmp_config_dir: Path) -> None:
    os.environ.pop("DEPICTA_API_KEY", None)
    save_config({"api_key": "config_key"})
    assert resolve_api_key(None) == "config_key"


def test_resolve_api_key_none(tmp_config_dir: Path) -> None:
    os.environ.pop("DEPICTA_API_KEY", None)
    assert resolve_api_key(None) is None


def test_resolve_api_url_default(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    os.environ.pop("DEPICTA_API_URL", None)
    monkeypatch.setattr("depicta.config._config_dir", lambda: tmp_path)
    assert resolve_api_url(None) == "https://api.depicta.ai"


def test_resolve_api_url_flag() -> None:
    assert resolve_api_url("https://custom.api") == "https://custom.api"


def test_mask_key_long() -> None:
    assert mask_key("dpct_a1B2c3D4e5F6") == "dpct_a1B2c3D4****"


def test_mask_key_short() -> None:
    assert mask_key("dpct") == "dpct****"
