"""Tests for download module."""

from __future__ import annotations

import os
from pathlib import Path

from depicta.download import make_output_path, save_bytes, temp_dir


def test_temp_dir_includes_uid() -> None:
    d = temp_dir()
    uid = os.getuid() if hasattr(os, "getuid") else os.getpid()
    assert f"depicta-{uid}" in str(d)


def test_make_output_path_explicit(tmp_path: Path) -> None:
    out = tmp_path / "out.png"
    result = make_output_path("image", "png", output=str(out))
    assert result == out


def test_make_output_path_output_dir(tmp_path: Path) -> None:
    result = make_output_path("image", "png", output_dir=str(tmp_path))
    assert result.parent == tmp_path
    assert result.suffix == ".png"
    assert "image_" in result.name


def test_make_output_path_default() -> None:
    result = make_output_path("graphic", "webp")
    assert "depicta-" in str(result.parent)
    assert result.suffix == ".webp"


def test_save_bytes(tmp_path: Path) -> None:
    data = b"\x89PNG\r\n\x1a\n"
    path = save_bytes(data, "test", output_dir=str(tmp_path))
    assert path.exists()
    assert path.read_bytes() == data
