#!/usr/bin/env python3
"""Enumerate all slugs for each tier: clawhub (curated), awesome-list.

Outputs:
  runs/tier-slugs/clawhub.txt   — slugs live on clawhub.ai
  runs/tier-slugs/awesome.txt   — slugs in VoltAgent/awesome-openclaw-skills

Usage:
    python scripts/collect_tier_slugs.py
"""

from __future__ import annotations

import json
import string
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from kura.popular import (  # noqa: E402
    CLAWHUB_SEARCH,
    fetch_awesome_all_slugs,
)


def enumerate_clawhub() -> set[str]:
    """Walk the clawhub search API with many queries to collect all slugs.

    The API requires a non-empty `q`. Using all single-letter and
    digit queries (plus common 2-char prefixes) gets close to full
    coverage. Clawhub returns up to 100 per call.
    """
    # Single letters + digits (36) + common 2-letter combos (100 common)
    # plus all aa-zz (676). Total ~810 queries; most dedupe quickly.
    letters = string.ascii_lowercase
    queries = (
        list(letters)
        + list(string.digits)
        + [a + b for a in letters for b in letters]
    )

    all_slugs: set[str] = set()
    for i, q in enumerate(queries):
        url = (
            f"{CLAWHUB_SEARCH}?"
            f"q={urllib.parse.quote(q)}&sort=downloads&limit=100"
        )
        try:
            req = urllib.request.Request(
                url, headers={"User-Agent": "kura/0.1"},
            )
            with urllib.request.urlopen(req, timeout=15) as r:
                data = json.loads(r.read())
        except (urllib.error.URLError, TimeoutError, OSError):
            continue

        new = {
            item["slug"]
            for item in data.get("results", [])
            if "slug" in item
        }
        all_slugs |= new
        print(
            f"  [{i+1}/{len(queries)}] q='{q}': "
            f"{len(new)} new, {len(all_slugs)} total",
            file=sys.stderr, flush=True,
        )
        time.sleep(0.1)  # be polite

    return all_slugs


def enumerate_awesome() -> set[str]:
    """Union of slugs across the README + all category sub-pages."""
    return fetch_awesome_all_slugs()


def main() -> int:
    out = Path("runs/tier-slugs")
    out.mkdir(parents=True, exist_ok=True)

    print("Enumerating clawhub slugs...", file=sys.stderr)
    clawhub = enumerate_clawhub()
    (out / "clawhub.txt").write_text(
        "\n".join(sorted(clawhub)) + "\n",
    )
    print(
        f"\nClawhub: {len(clawhub)} slugs -> "
        f"{out / 'clawhub.txt'}",
        file=sys.stderr,
    )

    print("\nEnumerating awesome-list slugs...", file=sys.stderr)
    awesome = enumerate_awesome()
    (out / "awesome.txt").write_text(
        "\n".join(sorted(awesome)) + "\n",
    )
    print(
        f"Awesome-list: {len(awesome)} slugs -> "
        f"{out / 'awesome.txt'}",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
