#!/usr/bin/env python3
"""Compare two kura run directories (typically algo vs LLM).

Joins on qualified_name and reports per-tool score delta plus
which issue codes changed.

Usage:
    python scripts/compare_runs.py runs/popular-algo runs/popular-llm
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path


def load_scores(run_dir: Path) -> dict[str, dict]:
    """Returns {qualified_name: {score, token_count, ...}}."""
    csv_path = run_dir / "scores.csv"
    if not csv_path.exists():
        raise FileNotFoundError(
            f"No scores.csv in {run_dir}"
        )
    out = {}
    with csv_path.open() as f:
        r = csv.DictReader(f)
        for row in r:
            out[row["qualified_name"]] = row
    return out


def load_issues(
    run_dir: Path,
) -> dict[str, set[str]]:
    """Returns {qualified_name: {issue_codes}}."""
    csv_path = run_dir / "issues.csv"
    if not csv_path.exists():
        return {}
    out: dict[str, set[str]] = {}
    with csv_path.open() as f:
        r = csv.DictReader(f)
        for row in r:
            out.setdefault(
                row["qualified_name"], set(),
            ).add(row["code"])
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("algo_dir", type=Path)
    ap.add_argument("llm_dir", type=Path)
    ap.add_argument(
        "--out", type=Path,
        default=Path("runs/comparison"),
        help="Output directory.",
    )
    ap.add_argument(
        "--top", type=int, default=10,
        help="Print top N biggest disagreements.",
    )
    args = ap.parse_args()

    algo = load_scores(args.algo_dir)
    llm = load_scores(args.llm_dir)
    algo_issues = load_issues(args.algo_dir)
    llm_issues = load_issues(args.llm_dir)

    common = sorted(set(algo) & set(llm))
    rows = []
    for name in common:
        a = int(algo[name]["score"])
        b = int(llm[name]["score"])
        delta = b - a
        added = (
            llm_issues.get(name, set())
            - algo_issues.get(name, set())
        )
        removed = (
            algo_issues.get(name, set())
            - llm_issues.get(name, set())
        )
        rows.append({
            "qualified_name": name,
            "algo_score": a,
            "llm_score": b,
            "delta": delta,
            "issues_added_by_llm": ",".join(sorted(added)),
            "issues_removed_by_llm": ",".join(
                sorted(removed),
            ),
        })

    # Write CSV
    args.out.mkdir(parents=True, exist_ok=True)
    csv_path = args.out / "delta.csv"
    with csv_path.open("w", newline="") as f:
        w = csv.DictWriter(
            f, fieldnames=list(rows[0].keys()),
        )
        w.writeheader()
        w.writerows(rows)

    # Summary stats
    raised = sum(1 for r in rows if r["delta"] > 0)
    lowered = sum(1 for r in rows if r["delta"] < 0)
    same = sum(1 for r in rows if r["delta"] == 0)
    print(
        f"Compared {len(rows)} tools: "
        f"LLM raised {raised}, lowered {lowered}, "
        f"unchanged {same}",
        file=sys.stderr,
    )

    # Biggest disagreements
    by_abs = sorted(
        rows, key=lambda r: abs(r["delta"]), reverse=True,
    )
    print(
        f"\nTop {args.top} biggest disagreements:",
        file=sys.stderr,
    )
    print(
        f"{'qualified_name':<50} "
        f"{'algo':>5} {'llm':>5} {'delta':>6}",
        file=sys.stderr,
    )
    for r in by_abs[:args.top]:
        print(
            f"{r['qualified_name']:<50} "
            f"{r['algo_score']:>5} "
            f"{r['llm_score']:>5} "
            f"{r['delta']:>+6}",
            file=sys.stderr,
        )

    print(f"\nDelta CSV: {csv_path}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
