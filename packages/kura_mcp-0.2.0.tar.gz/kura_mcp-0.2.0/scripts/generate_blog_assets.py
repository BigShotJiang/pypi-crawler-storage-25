#!/usr/bin/env python3
"""Generate `findings.md` and blog-ready charts from run directories.

Reads:
  - runs/full-scale/   — full repo run
  - runs/popular-algo/ — popular-seed algo-only run (optional)
  - runs/popular-llm/  — popular-seed LLM-enhanced run (optional)
  - scripts/predictions.md — pre-registered hypotheses

Writes:
  - runs/blog/findings.md   — prediction-vs-observed summary
  - runs/blog/*.csv         — derived aggregations

Usage:
    python scripts/generate_blog_assets.py [--full-dir runs/full-scale]
"""

from __future__ import annotations

import argparse
import csv
import statistics
import sys
from collections import Counter
from pathlib import Path


def _load_scores(run_dir: Path) -> list[dict]:
    csv_path = run_dir / "scores.csv"
    if not csv_path.exists():
        return []
    with csv_path.open() as f:
        return list(csv.DictReader(f))


def _load_issues(run_dir: Path) -> list[dict]:
    csv_path = run_dir / "issues.csv"
    if not csv_path.exists():
        return []
    with csv_path.open() as f:
        return list(csv.DictReader(f))


def _load_boilerplate(run_dir: Path) -> list[dict]:
    csv_path = run_dir / "boilerplate.csv"
    if not csv_path.exists():
        return []
    with csv_path.open() as f:
        return list(csv.DictReader(f))


def _load_similarity(run_dir: Path) -> list[dict]:
    csv_path = run_dir / "similarity.csv"
    if not csv_path.exists():
        return []
    with csv_path.open() as f:
        return list(csv.DictReader(f))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument(
        "--full-dir", type=Path,
        default=Path("runs/full-scale"),
    )
    ap.add_argument(
        "--popular-algo", type=Path,
        default=Path("runs/popular-algo"),
    )
    ap.add_argument(
        "--popular-llm", type=Path,
        default=Path("runs/popular-llm"),
    )
    ap.add_argument(
        "--predictions", type=Path,
        default=Path("scripts/predictions.md"),
    )
    ap.add_argument(
        "--out", type=Path,
        default=Path("runs/blog"),
    )
    args = ap.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)

    full_scores = _load_scores(args.full_dir)
    full_issues = _load_issues(args.full_dir)
    full_bp = _load_boilerplate(args.full_dir)
    full_sims = _load_similarity(args.full_dir)

    if not full_scores:
        print(
            f"Error: no scores.csv in {args.full_dir}",
            file=sys.stderr,
        )
        return 1

    findings = []
    findings.append("# Findings\n")
    findings.append(
        f"Based on {len(full_scores)} skills analyzed.\n"
    )

    # Headline stats
    scores = [int(r["score"]) for r in full_scores]
    tokens = [int(r["token_count"]) for r in full_scores]
    words_median = statistics.median(scores)
    findings.append("## Headline numbers\n")
    findings.append(f"- Tools analyzed: {len(full_scores)}")
    findings.append(
        f"- Median quality score: {words_median:.0f}/100"
    )
    findings.append(
        f"- Mean quality score: "
        f"{statistics.mean(scores):.1f}/100"
    )
    findings.append(
        f"- Total tokens: {sum(tokens):,}"
    )
    findings.append(
        f"- Median tokens/tool: "
        f"{int(statistics.median(tokens))}"
    )
    findings.append("")

    # H1: Parameter doc / return value
    tools_with = Counter()
    for i in full_issues:
        tools_with[i["code"]] += 1
    # Unique tools
    tool_codes: dict[str, set[str]] = {}
    for i in full_issues:
        tool_codes.setdefault(
            i["qualified_name"], set(),
        ).add(i["code"])
    h1_codes = {
        "MISSING_PARAM_DESC", "NO_RETURN_VALUE",
        "NAME_RESTATES_DESC",
    }
    tools_hitting_h1 = sum(
        1 for c in tool_codes.values()
        if c & h1_codes
    )
    pct_h1 = 100 * tools_hitting_h1 / len(full_scores)
    findings.append("## H1: Parameter docs / return docs\n")
    findings.append(
        f"- Tools with ≥1 of {{MISSING_PARAM_DESC, "
        f"NO_RETURN_VALUE, NAME_RESTATES_DESC}}: "
        f"**{tools_hitting_h1}** ({pct_h1:.1f}%)"
    )
    findings.append("")

    # H3: behavioral overrides
    overrides = tools_with.get("BEHAVIORAL_OVERRIDE", 0)
    pct_override = 100 * overrides / len(full_scores)
    findings.append("## H3: Behavioral overrides\n")
    findings.append(
        f"- Skills flagged BEHAVIORAL_OVERRIDE: "
        f"**{overrides}** ({pct_override:.2f}%)"
    )
    findings.append("")

    # H4: boilerplate
    if full_bp:
        total_wasted = sum(
            int(r["wasted_tokens"]) for r in full_bp
        )
        pct_wasted = 100 * total_wasted / sum(tokens)
        findings.append("## H4: Boilerplate waste\n")
        findings.append(
            f"- Boilerplate phrases repeated 3+ times: "
            f"**{len(full_bp)}**"
        )
        findings.append(
            f"- Total eliminable tokens: "
            f"**{total_wasted:,}** ({pct_wasted:.1f}% "
            f"of catalog)"
        )
        findings.append("")
        findings.append(
            "### Top-5 repeated parameter descriptions"
        )
        findings.append("")
        findings.append(
            "| Author | Count | Wasted | Text |"
        )
        findings.append(
            "|--------|-------|--------|------|"
        )
        for row in full_bp[:5]:
            findings.append(
                f"| {row['source']} | "
                f"{row['count']} | "
                f"{row['wasted_tokens']} | "
                f"{row['description_preview'][:60]} |"
            )
        findings.append("")

    # H6: duplicate clusters
    if full_sims:
        findings.append("## H6: Near-duplicates\n")
        high_sim = [
            s for s in full_sims
            if float(s["score"]) >= 0.9
        ]
        findings.append(
            f"- Similarity pairs ≥0.9: "
            f"**{len(high_sim)}**"
        )
        findings.append("")

    # H7: popular vs full
    if args.popular_algo.exists():
        pop_scores = _load_scores(args.popular_algo)
        if pop_scores:
            pop_med = statistics.median(
                int(r["score"]) for r in pop_scores
            )
            findings.append("## H7: Popular vs full catalog\n")
            findings.append(
                f"- Popular median: **{pop_med:.0f}/100**"
            )
            findings.append(
                f"- Full catalog median: "
                f"**{words_median:.0f}/100**"
            )
            findings.append(
                f"- Delta: **{pop_med - words_median:+.0f}**"
            )
            findings.append("")

    # Predictions reference
    findings.append("## Pre-registered predictions\n")
    if args.predictions.exists():
        findings.append(
            f"See [{args.predictions}]"
            f"(../../{args.predictions})"
        )
    else:
        findings.append(
            "⚠ No predictions.md found — cannot compare."
        )
    findings.append("")

    out_path = args.out / "findings.md"
    out_path.write_text("\n".join(findings) + "\n")
    print(f"Wrote {out_path}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
