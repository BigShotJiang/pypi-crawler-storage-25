#!/usr/bin/env python3
"""Filter a full-scale run into a tier subset (clawhub or awesome-list).

Reads runs/full-scale/*.csv and a slug list from
runs/tier-slugs/<name>.txt. Produces runs/<name>-tier/*.csv with
only the rows whose tool name matches a slug in the tier.

Usage:
    python scripts/filter_tier.py --tier clawhub
    python scripts/filter_tier.py --tier awesome
"""

from __future__ import annotations

import argparse
import csv
import shutil
import sys
from pathlib import Path


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument(
        "--tier",
        choices=["clawhub", "awesome"],
        required=True,
    )
    ap.add_argument(
        "--full-dir", type=Path,
        default=Path("runs/full-scale"),
    )
    ap.add_argument(
        "--slugs-dir", type=Path,
        default=Path("runs/tier-slugs"),
    )
    ap.add_argument(
        "--out", type=Path, default=None,
    )
    args = ap.parse_args()

    slugs_file = args.slugs_dir / f"{args.tier}.txt"
    if not slugs_file.exists():
        print(
            f"Error: {slugs_file} not found. "
            f"Run collect_tier_slugs.py first.",
            file=sys.stderr,
        )
        return 1

    slugs = {
        line.strip()
        for line in slugs_file.read_text().splitlines()
        if line.strip()
    }
    print(
        f"Loaded {len(slugs)} {args.tier} slugs",
        file=sys.stderr,
    )

    scores_csv = args.full_dir / "scores.csv"
    if not scores_csv.exists():
        print(
            f"Error: {scores_csv} not found. "
            f"Run full-scale scan first.",
            file=sys.stderr,
        )
        return 1

    # Filter strategy depends on tier:
    # - clawhub slugs = bare skill name -> match against `name`
    # - awesome slugs = <author>-<skill> -> try all hyphen splits
    #   and match against qualified_name prefix `<author>/<skill>/`
    keep_names: set[str] = set()
    out = args.out or Path(f"runs/{args.tier}-tier")
    out.mkdir(parents=True, exist_ok=True)

    rows = []
    with scores_csv.open() as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames
        all_rows = list(reader)

    if args.tier == "clawhub":
        # Clawhub slug = bare skill slug, may match directory name
        # (qualified_name parts[1]) or frontmatter name (row['name'])
        for row in all_rows:
            parts = row["qualified_name"].split("/")
            dir_name = parts[1] if len(parts) >= 2 else ""
            if (
                dir_name in slugs
                or row["name"] in slugs
            ):
                rows.append(row)
                keep_names.add(row["qualified_name"])
    else:  # awesome: author-skill format
        # Build two indexes: by directory name (slug uses this) and
        # by frontmatter name (fallback). qualified_name format is
        # <author>/<dir_path>/<frontmatter_name>.
        by_author_dir: dict[tuple[str, str], dict] = {}
        by_author_frontmatter: dict[tuple[str, str], dict] = {}
        for row in all_rows:
            parts = row["qualified_name"].split("/")
            if len(parts) >= 2:
                author = parts[0]
                # Directory portion = middle of qualified_name
                # (there may be nested dirs, but typically one)
                dir_name = parts[1]
                by_author_dir[(author, dir_name)] = row
                by_author_frontmatter[
                    (author, row["name"])
                ] = row
        # For each slug, try all hyphen splits, directory first
        for slug in slugs:
            hyphens = [
                i for i, c in enumerate(slug) if c == "-"
            ]
            matched = False
            for pos in hyphens:
                author_pref = slug[:pos]
                skill = slug[pos + 1:]
                for index in (
                    by_author_dir, by_author_frontmatter,
                ):
                    if (author_pref, skill) in index:
                        row = index[(author_pref, skill)]
                        if row["qualified_name"] not in keep_names:
                            rows.append(row)
                            keep_names.add(
                                row["qualified_name"],
                            )
                        matched = True
                        break
                if matched:
                    break

    with (out / "scores.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)
    print(
        f"Scores: kept {len(rows)} rows -> "
        f"{out / 'scores.csv'}",
        file=sys.stderr,
    )

    # Filter other CSVs by qualified_name
    for fname in ("issues.csv", "similarity.csv"):
        src = args.full_dir / fname
        if not src.exists():
            continue
        kept = 0
        with src.open() as rf, (out / fname).open(
            "w", newline="",
        ) as wf:
            reader = csv.DictReader(rf)
            writer = csv.DictWriter(
                wf, fieldnames=reader.fieldnames,
            )
            writer.writeheader()
            for r in reader:
                if fname == "issues.csv":
                    if r["qualified_name"] in keep_names:
                        writer.writerow(r)
                        kept += 1
                elif fname == "similarity.csv":
                    if (
                        r["tool_a"] in keep_names
                        and r["tool_b"] in keep_names
                    ):
                        writer.writerow(r)
                        kept += 1
        print(
            f"{fname}: kept {kept} rows",
            file=sys.stderr,
        )

    # Boilerplate doesn't apply (no per-tool mapping)
    bp = args.full_dir / "boilerplate.csv"
    if bp.exists():
        shutil.copy(bp, out / "boilerplate.csv")

    return 0


if __name__ == "__main__":
    sys.exit(main())
