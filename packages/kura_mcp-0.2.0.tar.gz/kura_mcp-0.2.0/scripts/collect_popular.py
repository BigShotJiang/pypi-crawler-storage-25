#!/usr/bin/env python3
"""Collect a "popular" subset of openclaw skills for analysis.

Strategy:
  1. Fetch top-ranked slugs from clawhub API (sort=downloads)
  2. Resolve each slug to a local directory in the cloned repo
  3. Prepend the 7 kdnuggets-featured skills (external validation)
  4. Cap at --limit (default 100)
  5. Copy selected skill directories to --out/skills/<author>/<skill>/

Produces:
  <out>/skills/            — copies of selected skills
  <out>/seed_manifest.json — metadata for each selected skill
  <out>/unresolved.txt     — clawhub slugs that couldn't be mapped
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
from pathlib import Path

# Ensure we can import from src/kura/ when run as a script
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from kura.popular import (  # noqa: E402
    KDNUGGETS_SEED,
    build_skill_index,
    fetch_clawhub_ranked,
    resolve_slug,
)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument(
        "--skills-root",
        type=Path,
        default=Path(
            os.environ.get(
                "KURA_SKILLS_ROOT",
                str(Path.home() / "openclaw-skills" / "skills"),
            )
        ),
        help="Local path to the cloned openclaw/skills repo's "
        "'skills/' directory. Defaults to "
        "~/openclaw-skills/skills, or the KURA_SKILLS_ROOT env var.",
    )
    ap.add_argument(
        "--out",
        type=Path,
        default=Path("runs/popular-seed"),
        help="Output directory.",
    )
    ap.add_argument(
        "--limit",
        type=int,
        default=100,
        help="Maximum number of skills to include.",
    )
    args = ap.parse_args()

    skills_root: Path = args.skills_root
    out: Path = args.out

    if not skills_root.is_dir():
        print(
            f"Error: skills root not found: {skills_root}",
            file=sys.stderr,
        )
        return 1

    cache_path = Path.home() / ".kura" / "skill_index.json"
    print(
        f"Building local skill index (cached at {cache_path})...",
        file=sys.stderr,
    )

    def _p(msg):
        print(f"  {msg}", file=sys.stderr, flush=True)

    index = build_skill_index(
        skills_root,
        cache_path=cache_path,
        progress=_p,
    )
    print(
        f"  Indexed {sum(len(v) for v in index.values())} "
        f"skills under {len(index)} unique names",
        file=sys.stderr,
    )

    print(
        "Fetching popularity ranking from clawhub API...",
        file=sys.stderr,
    )
    ranked = fetch_clawhub_ranked()
    print(
        f"  Got {len(ranked)} unique slugs from API",
        file=sys.stderr,
    )

    manifest: list[dict] = []
    unresolved: list[str] = []
    seen_paths: set[Path] = set()

    # Pass 1: kdnuggets seed (always included)
    for author, skill in KDNUGGETS_SEED:
        path = skills_root / author / skill
        slug = f"{author}-{skill}"
        if path.is_dir():
            manifest.append({
                "source": "kdnuggets",
                "slug": slug,
                "author": author,
                "skill": skill,
                "local_path": str(path),
                "rank": None,
                "occurrences": None,
            })
            seen_paths.add(path)
        else:
            unresolved.append(f"{slug} (kdnuggets)")

    # Pass 2: clawhub ranked, resolve and dedupe
    for i, item in enumerate(ranked):
        if len(manifest) >= args.limit:
            break
        slug = item["slug"]
        path = resolve_slug(slug, skills_root, index=index)
        if path is None:
            unresolved.append(slug)
            continue
        if path in seen_paths:
            continue
        parts = path.relative_to(skills_root).parts
        if len(parts) < 2:
            continue
        manifest.append({
            "source": "clawhub",
            "slug": slug,
            "author": parts[0],
            "skill": "/".join(parts[1:]),
            "display_name": item.get("displayName"),
            "summary": item.get("summary"),
            "local_path": str(path),
            "rank": i,
            "occurrences": item.get("occurrences"),
        })
        seen_paths.add(path)

    # Write output
    out.mkdir(parents=True, exist_ok=True)
    dest_skills = out / "skills"
    if dest_skills.exists():
        shutil.rmtree(dest_skills)
    dest_skills.mkdir()

    for entry in manifest:
        src = Path(entry["local_path"])
        dst = dest_skills / entry["author"] / entry["skill"]
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(src, dst)

    (out / "seed_manifest.json").write_text(
        json.dumps(manifest, indent=2),
    )
    (out / "unresolved.txt").write_text(
        "\n".join(unresolved) + "\n" if unresolved else "",
    )

    # Summary
    print(
        f"\nCollected {len(manifest)} skills "
        f"(cap: {args.limit})",
        file=sys.stderr,
    )
    print(
        f"  kdnuggets: "
        f"{sum(1 for m in manifest if m['source'] == 'kdnuggets')}",
        file=sys.stderr,
    )
    print(
        f"  clawhub:   "
        f"{sum(1 for m in manifest if m['source'] == 'clawhub')}",
        file=sys.stderr,
    )
    print(
        f"  unresolved slugs: {len(unresolved)}",
        file=sys.stderr,
    )
    print(f"\nOutput: {out}/", file=sys.stderr)
    print(
        f"Next: kura scan --no-similarity --run-dir "
        f"runs/popular-algo/ {out}/skills",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
