#!/usr/bin/env python3
"""Pre-publication sanity checks on runs/full-scale/.

For each check: print a verdict (PASS / CONCERN / FAIL), the raw
numbers, and 3-5 concrete examples so we can eyeball them.

Run AFTER runs/full-scale is populated.
"""

from __future__ import annotations

import argparse
import csv
import os
import random
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

# Paths — override via CLI args or env vars.
SKILLS_ROOT = Path(
    os.environ.get(
        "KURA_SKILLS_ROOT",
        str(Path.home() / "openclaw-skills" / "skills"),
    )
)
RUN = Path(
    os.environ.get("KURA_RUN_DIR", "runs/full-scale")
)

random.seed(42)


def print_header(title: str) -> None:
    print(f"\n{'=' * 70}\n{title}\n{'=' * 70}")


def load_scores() -> list[dict]:
    with (RUN / "scores.csv").open() as f:
        return list(csv.DictReader(f))


def load_issues() -> list[dict]:
    with (RUN / "issues.csv").open() as f:
        return list(csv.DictReader(f))


def skill_md(qualified_name: str) -> tuple[str, str]:
    """Return (full_text, description_as_parser_sees_it) for a
    qualified_name. Derives the path from `<author>/<skill>/<name>`."""
    parts = qualified_name.split("/")
    if len(parts) < 2:
        return "", ""
    # Try first two components as author/skill; may need deeper
    for depth in (2, 3, 4):
        if len(parts) >= depth:
            candidate = SKILLS_ROOT.joinpath(*parts[:depth])
            for fname in ("SKILL.md", "skill.md", "Skill.md"):
                p = candidate / fname
                if p.is_file():
                    try:
                        return p.read_text(
                            encoding="utf-8", errors="replace",
                        ), str(p)
                    except OSError:
                        return "", str(p)
    return "", ""


def description_of(skill_text: str) -> str:
    """Extract just the description (frontmatter or first para)."""
    m = re.match(
        r"^---\s*\n(.*?)\n---\s*\n(.*)", skill_text, re.DOTALL,
    )
    if m:
        import yaml
        try:
            fm = yaml.safe_load(m.group(1))
            if isinstance(fm, dict) and fm.get("description"):
                d = fm["description"]
                return d if isinstance(d, str) else str(d)
        except Exception:
            pass
    # first paragraph
    for para in skill_text.split("\n\n"):
        p = para.strip()
        if p and not p.startswith("#"):
            return p[:500]
    return ""


# ==================================================================
# 1. NO_RETURN_VALUE false-positive check
# ==================================================================

def check_no_return_value(issues: list[dict]) -> None:
    print_header("1. NO_RETURN_VALUE — is the 91% real?")
    flagged = [
        i for i in issues if i["code"] == "NO_RETURN_VALUE"
    ]
    flagged_names = {i["qualified_name"] for i in flagged}

    # Find skills that DID pass (no such issue)
    all_names = {
        row["qualified_name"] for row in load_scores()
    }
    passing = all_names - flagged_names

    # Sample 5 from each, show description
    print(f"Flagged: {len(flagged)}  Passing: {len(passing)}")
    sample_flag = random.sample(
        list(flagged_names), min(5, len(flagged_names))
    )
    sample_pass = random.sample(
        list(passing), min(5, len(passing))
    )

    print(
        "\nA. 5 random SKIPPED (should mention return):"
    )
    for name in sample_pass:
        text, path = skill_md(name)
        desc = description_of(text)[:200]
        print(f"\n  [{name}]")
        print(f"  {desc!r}")

    print(
        "\nB. 5 random FLAGGED (should NOT mention return):"
    )
    for name in sample_flag:
        text, path = skill_md(name)
        desc = description_of(text)[:200]
        print(f"\n  [{name}]")
        print(f"  {desc!r}")


# ==================================================================
# 2. Score-0 skills — are they empty or parser bugs?
# ==================================================================

def check_score_zero(scores: list[dict]) -> None:
    print_header("2. Score=0 skills — empty or parser bug?")
    zeros = [s for s in scores if int(s["score"]) == 0]
    print(f"Total score-0 skills: {len(zeros)}")
    for s in zeros[:10]:
        text, path = skill_md(s["qualified_name"])
        desc = description_of(text)
        first_lines = text[:150].replace("\n", "\\n")
        print(f"\n  [{s['qualified_name']}]")
        print(f"  path: {path}")
        print(f"  description: {desc!r}")
        print(f"  raw start: {first_lines!r}")


# ==================================================================
# 3. 1.00-similarity pairs — real clones?
# ==================================================================

def check_similarity_duplicates() -> None:
    print_header("3. 1.00-similarity pairs — real text clones?")
    sims_path = RUN / "similarity.csv"
    if not sims_path.exists():
        print("  (no similarity.csv)")
        return
    with sims_path.open() as f:
        sims = list(csv.DictReader(f))
    perfect = [
        s for s in sims if float(s["score"]) >= 0.999
    ]
    print(f"Pairs with score ≥0.999: {len(perfect)}")
    for s in random.sample(perfect, min(5, len(perfect))):
        da, _ = skill_md(s["tool_a"])
        db, _ = skill_md(s["tool_b"])
        dea = description_of(da)[:150]
        deb = description_of(db)[:150]
        identical = (dea == deb)
        print(
            f"\n  A: {s['tool_a']}\n  B: {s['tool_b']}"
            f"  identical_desc: {identical}"
        )
        if not identical:
            print(f"  A.desc: {dea!r}")
            print(f"  B.desc: {deb!r}")
        else:
            print(f"  desc:    {dea!r}")


# ==================================================================
# 4. BEHAVIORAL_OVERRIDE false positives
# ==================================================================

def check_behavioral_override(issues: list[dict]) -> None:
    print_header("4. BEHAVIORAL_OVERRIDE — 147 flagged, real?")
    flags = [
        i for i in issues
        if i["code"] == "BEHAVIORAL_OVERRIDE"
    ]
    print(f"Total flagged: {len(flags)}")
    sample = random.sample(flags, min(8, len(flags)))
    for f in sample:
        text, _ = skill_md(f["qualified_name"])
        desc = description_of(text)[:300]
        print(f"\n  [{f['qualified_name']}]")
        print(f"  {desc!r}")


# ==================================================================
# 5. H1 calculation sanity
# ==================================================================

def check_h1_calculation(issues: list[dict]) -> None:
    print_header(
        "5. H1 calculation: ≥1 of {MISSING_PARAM_DESC, "
        "NO_RETURN_VALUE, NAME_RESTATES_DESC}"
    )
    tool_codes: dict[str, set[str]] = defaultdict(set)
    for i in issues:
        tool_codes[i["qualified_name"]].add(i["code"])
    h1_codes = {
        "MISSING_PARAM_DESC", "NO_RETURN_VALUE",
        "NAME_RESTATES_DESC",
    }
    total_tools = len(
        list(load_scores()),
    )  # already consumed; recompute
    hit_each: Counter[str] = Counter()
    for codes in tool_codes.values():
        for c in codes & h1_codes:
            hit_each[c] += 1
    hit_any = sum(
        1 for codes in tool_codes.values()
        if codes & h1_codes
    )
    print(f"Total skills scanned: {total_tools}")
    for c, n in hit_each.items():
        print(f"  {c}: {n} ({100*n/total_tools:.1f}%)")
    print(
        f"Union (≥1 of above): "
        f"{hit_any} ({100*hit_any/total_tools:.1f}%)"
    )


# ==================================================================
# 6. Clawhub slug mismatch
# ==================================================================

def check_clawhub_coverage(scores: list[dict]) -> None:
    print_header("6. Clawhub slug matching coverage")
    clawhub_file = Path("runs/tier-slugs/clawhub.txt")
    if not clawhub_file.exists():
        print("  (no clawhub slugs file)")
        return
    slugs = {
        line.strip()
        for line in clawhub_file.read_text().splitlines()
        if line.strip()
    }
    names = {s["name"] for s in scores}
    matched = slugs & names
    missed = slugs - names
    print(f"Clawhub slugs: {len(slugs)}")
    print(f"Matched in full-scale scan: {len(matched)}")
    print(f"Missed: {len(missed)}")
    print(
        f"Coverage: {100*len(matched)/len(slugs):.1f}%"
    )
    print("\nFirst 10 unmatched slugs (may not be in archive):")
    for s in sorted(missed)[:10]:
        print(f"  {s}")


# ==================================================================
# 7. Repo SHA recording
# ==================================================================

def check_repo_sha(archive_repo: Path) -> None:
    print_header("7. Reproducibility: repo commit SHAs")
    import subprocess
    for label, path in [
        ("archive", archive_repo),
        ("kura", Path(__file__).parent.parent),
    ]:
        try:
            sha = subprocess.check_output(
                ["git", "-C", str(path), "rev-parse", "HEAD"],
                timeout=10,
            ).decode().strip()
            print(f"{label} HEAD SHA: {sha}")
        except Exception as e:
            print(f"{label}: ERROR {e}")


# ==================================================================

def main() -> int:
    global SKILLS_ROOT, RUN
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument(
        "--skills-root", type=Path,
        default=SKILLS_ROOT,
        help="Local path to the cloned skills repo's "
        "'skills/' directory (or set KURA_SKILLS_ROOT).",
    )
    ap.add_argument(
        "--run-dir", type=Path,
        default=RUN,
        help="Path to a kura run directory (or set KURA_RUN_DIR).",
    )
    args = ap.parse_args()
    SKILLS_ROOT = args.skills_root
    RUN = args.run_dir

    scores = load_scores()
    issues = load_issues()
    check_no_return_value(issues)
    check_score_zero(scores)
    check_similarity_duplicates()
    check_behavioral_override(issues)
    check_h1_calculation(issues)
    check_clawhub_coverage(scores)
    check_repo_sha(archive_repo=SKILLS_ROOT.parent)
    return 0


if __name__ == "__main__":
    sys.exit(main())
