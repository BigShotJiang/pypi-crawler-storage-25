"""Approximate nearest-neighbor similarity for large catalogs.

Uses hnswlib to build an in-memory HNSW index. For a 13.7k-skill
catalog with k=20 neighbors per query, this is ~1000x faster than
the O(n²) exact path in similarity.py.

The embeddings come from `EmbeddingCache` so repeat runs are fast.
"""

from __future__ import annotations

import numpy as np

from kura.models import SimilarityResult, ToolDescriptor


def find_conflicts_ann(
    tools: list[ToolDescriptor],
    embeddings: np.ndarray,
    threshold: float = 0.85,
    k: int = 20,
) -> list[SimilarityResult]:
    """ANN similarity via HNSW. Requires hnswlib + numpy.

    Returns all pairs (i, j) with i<j where cosine similarity ≥
    threshold. `scope` is auto-set based on whether tools share
    a `source`.
    """
    import hnswlib

    if len(tools) < 2:
        return []

    dim = embeddings.shape[1]
    index = hnswlib.Index(space="ip", dim=dim)
    index.init_index(
        max_elements=len(tools),
        ef_construction=200,
        M=16,
    )
    index.add_items(
        embeddings, np.arange(len(tools)),
    )
    index.set_ef(max(k * 2, 50))

    # Query all at once
    labels, distances = index.knn_query(
        embeddings, k=min(k, len(tools)),
    )
    # distances are 1 - inner_product for normalized vectors,
    # so cosine similarity = 1 - distance
    sims = 1.0 - distances

    pairs: set[tuple[int, int]] = set()
    results: list[SimilarityResult] = []
    for i in range(len(tools)):
        for col in range(labels.shape[1]):
            j = int(labels[i, col])
            if j == i:
                continue
            score = float(sims[i, col])
            if score < threshold:
                continue
            lo, hi = min(i, j), max(i, j)
            if (lo, hi) in pairs:
                continue
            pairs.add((lo, hi))

            scope = (
                "intra_server"
                if tools[lo].source == tools[hi].source
                else "cross_server"
            )
            results.append(SimilarityResult(
                tool_a=tools[lo],
                tool_b=tools[hi],
                score=score,
                explanation=_explain(
                    tools[lo], tools[hi],
                ),
                scope=scope,
            ))

    results.sort(key=lambda r: r.score, reverse=True)
    return results


def _explain(
    a: ToolDescriptor, b: ToolDescriptor,
) -> str:
    """Brief explanation — shared terms in descriptions."""
    aw = set(a.description.lower().split())
    bw = set(b.description.lower().split())
    stop = {
        "a", "an", "the", "is", "to", "and", "or",
        "for", "in", "on", "with", "of",
    }
    common = (aw & bw) - stop
    if common:
        shared = ", ".join(sorted(common)[:5])
        return f"Shared terms: {shared}"
    return "Semantically similar."
