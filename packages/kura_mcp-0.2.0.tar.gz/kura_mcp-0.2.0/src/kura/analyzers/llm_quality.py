"""LLM-enhanced quality scoring.

Re-evaluates rules 4 (context), 7 (vague), 10 (name restates)
with semantic judgment and adds an overall usefulness assessment.

Requires: pip install kura-mcp[suggest]
"""

import asyncio
import json
import os
import re

from kura.models import QualityIssue, QualityResult, ToolDescriptor

# Rules the LLM re-evaluates, with their issue codes and max points
_LLM_RULES = {
    "system_context": {"code": "NO_CONTEXT", "max": 7},
    "vague_description": {"code": "VAGUE_DESCRIPTION", "max": 8},
    "name_restates": {"code": "NAME_RESTATES_DESC", "max": 5},
}

# Overall usefulness score -> point adjustment
_USEFULNESS_MAP = {
    range(1, 4): -10,   # 1-3: nearly unusable
    range(4, 6): -5,    # 4-5: confusing
    range(6, 8): 0,     # 6-7: acceptable
    range(8, 10): 3,    # 8-9: good
    range(10, 11): 5,   # 10: excellent
}


def _build_prompt(tool: ToolDescriptor) -> str:
    """Build the evaluation prompt for a single tool."""
    params_summary = "None"
    if tool.parameters:
        lines = []
        for p in tool.parameters[:15]:
            desc = p.description or "(no description)"
            req = " [required]" if p.required else ""
            lines.append(f"  - {p.name}: {desc}{req}")
        params_summary = "\n".join(lines)

    return f"""Evaluate this MCP tool description for quality.

Tool name: {tool.name}
Source server: {tool.source}
Description: {tool.description or "(empty)"}
Parameters:
{params_summary}

Answer these four questions. Return ONLY valid JSON, no other text.

1. system_context: Does the description make clear what system, \
service, or platform this tool operates on? Pass if a developer \
would know WHERE this tool acts.
2. vague_description: Is the description actually helpful? Pass if \
it gives a clear picture of what the tool does. Fail if it is \
generic, trivially obvious, or adds no real information.
3. name_restates: Does the description add meaningful information \
beyond what the tool name already conveys? Pass if description \
adds value, fail if it just reformulates the name.
4. overall_usefulness: On a scale of 1-10, could an LLM agent use \
this tool correctly given ONLY this name, description, and \
parameters? Consider: would the agent know when to choose this \
tool over alternatives, what inputs to provide, and what to \
expect back?

{{"system_context": {{"pass": bool, "reason": "..."}}, \
"vague_description": {{"pass": bool, "reason": "..."}}, \
"name_restates": {{"pass": bool, "reason": "..."}}, \
"overall_usefulness": {{"score": N, "reason": "..."}}}}"""


def _parse_llm_response(text: str) -> dict | None:
    """Extract JSON from LLM response text."""
    # Try direct parse
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError):
        pass

    # Try extracting from markdown fences
    m = re.search(
        r"```(?:json)?\s*\n?(.*?)\n?```",
        text, re.DOTALL,
    )
    if m:
        try:
            return json.loads(m.group(1))
        except (json.JSONDecodeError, TypeError):
            pass

    # Try extracting the first {...} block
    m = re.search(r"\{.*\}", text, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(0))
        except (json.JSONDecodeError, TypeError):
            pass

    return None


def _apply_llm_verdict(
    result: QualityResult,
    verdict: dict,
) -> QualityResult:
    """Adjust a QualityResult based on the LLM verdict."""
    delta = 0

    for key, rule_info in _LLM_RULES.items():
        llm_rule = verdict.get(key)
        if not isinstance(llm_rule, dict):
            continue

        code = rule_info["code"]
        max_pts = rule_info["max"]
        passed = llm_rule.get("pass", True)
        reason = llm_rule.get("reason", "")

        # Determine what the algorithmic rule awarded
        had_issue = any(
            i.code == code for i in result.issues
        )
        algo_pts = 0 if had_issue else max_pts

        # Remove old algorithmic issue for this rule
        result.issues = [
            i for i in result.issues if i.code != code
        ]

        if passed:
            llm_pts = max_pts
        else:
            llm_pts = 0
            result.issues.append(QualityIssue(
                code=code,
                message=reason or f"LLM: {key} check failed.",
                severity="warning",
                source="llm",
            ))

        delta += llm_pts - algo_pts

    # Overall usefulness adjustment
    usefulness = verdict.get("overall_usefulness", {})
    if isinstance(usefulness, dict):
        score_val = usefulness.get("score", 7)
        reason = usefulness.get("reason", "")
        adjustment = 0
        for score_range, adj in _USEFULNESS_MAP.items():
            if score_val in score_range:
                adjustment = adj
                break

        delta += adjustment

        if adjustment < 0:
            result.issues.append(QualityIssue(
                code="LLM_USEFULNESS",
                message=f"LLM usefulness: {score_val}/10. "
                f"{reason}",
                severity="warning",
                source="llm",
            ))
        elif adjustment > 0 and reason:
            result.issues.append(QualityIssue(
                code="LLM_USEFULNESS",
                message=f"LLM usefulness: {score_val}/10. "
                f"{reason}",
                severity="info",
                source="llm",
            ))

    result.score = min(max(result.score + delta, 0), 100)
    result.llm_enhanced = True
    return result


# --- LLM client ---

async def _call_llm(prompt: str, model: str) -> str:
    """Call an LLM provider and return the response text."""
    if model == "anthropic":
        from anthropic import AsyncAnthropic
        client = AsyncAnthropic()
        resp = await asyncio.wait_for(
            client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=500,
                messages=[{"role": "user", "content": prompt}],
            ),
            timeout=30,
        )
        return resp.content[0].text

    elif model == "openai":
        from openai import AsyncOpenAI
        client = AsyncOpenAI()
        resp = await asyncio.wait_for(
            client.chat.completions.create(
                model="gpt-4o-mini",
                max_tokens=500,
                messages=[{"role": "user", "content": prompt}],
            ),
            timeout=30,
        )
        return resp.choices[0].message.content

    elif model == "google":
        from google import genai
        client = genai.Client(
            api_key=os.environ.get("GOOGLE_API_KEY"),
        )
        resp = await asyncio.wait_for(
            client.aio.models.generate_content(
                model="gemini-flash-latest",
                contents=prompt,
            ),
            timeout=30,
        )
        return resp.text

    else:
        raise ValueError(f"Unknown model provider: {model}")


async def _enhance_one(
    result: QualityResult,
    model: str,
    semaphore: asyncio.Semaphore,
    log_fp=None,
) -> QualityResult:
    """Enhance a single tool's quality result via LLM.

    If `log_fp` is a writable file handle, each prompt + raw
    response is dumped as a JSON line for later inspection.
    """
    async with semaphore:
        prompt = _build_prompt(result.tool)
        try:
            text = await _call_llm(prompt, model)
        except asyncio.TimeoutError:
            if log_fp:
                log_fp.write(json.dumps({
                    "tool": result.tool.qualified_name,
                    "model": model,
                    "prompt": prompt,
                    "error": "timeout",
                }) + "\n")
                log_fp.flush()
            return result
        except Exception as e:
            # Rate limit, auth error, etc. — fall back
            if log_fp:
                log_fp.write(json.dumps({
                    "tool": result.tool.qualified_name,
                    "model": model,
                    "prompt": prompt,
                    "error": type(e).__name__ + ": " + str(e),
                }) + "\n")
                log_fp.flush()
            return result

        if log_fp:
            log_fp.write(json.dumps({
                "tool": result.tool.qualified_name,
                "model": model,
                "prompt": prompt,
                "response": text,
            }) + "\n")
            log_fp.flush()

        verdict = _parse_llm_response(text)
        if verdict is None:
            return result

        return _apply_llm_verdict(result, verdict)


async def llm_enhance_results(
    results: list[QualityResult],
    model: str = "anthropic",
    on_progress: object = None,
    log_path: object = None,
) -> list[QualityResult]:
    """Enhance quality results using LLM evaluation.

    Args:
        results: Algorithmic quality results to enhance.
        model: LLM provider ("anthropic", "openai", "google").
        on_progress: Called after each tool is processed.

    Returns the same list with adjusted scores and issues.
    """
    # Validate API key is available
    key_vars = {
        "anthropic": "ANTHROPIC_API_KEY",
        "openai": "OPENAI_API_KEY",
        "google": "GOOGLE_API_KEY",
    }
    key_var = key_vars.get(model)
    if key_var and not os.environ.get(key_var):
        raise RuntimeError(
            f"Set {key_var} environment variable to use "
            f"--llm with --model {model}"
        )

    semaphore = asyncio.Semaphore(5)

    log_fp = None
    if log_path:
        from pathlib import Path as PathLib
        p = PathLib(log_path)
        p.parent.mkdir(parents=True, exist_ok=True)
        log_fp = p.open("w")

    async def process(result):
        enhanced = await _enhance_one(
            result, model, semaphore, log_fp,
        )
        if on_progress:
            on_progress()
        return enhanced

    try:
        return await asyncio.gather(
            *[process(r) for r in results]
        )
    finally:
        if log_fp:
            log_fp.close()
