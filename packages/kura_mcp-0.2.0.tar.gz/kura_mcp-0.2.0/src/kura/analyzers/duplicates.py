"""Cluster near-duplicate tools using union-find on similarity pairs."""

from __future__ import annotations

from kura.models import SimilarityResult


def cluster_duplicates(
    similarities: list[SimilarityResult],
    min_score: float = 0.95,
) -> list[list[str]]:
    """Group tools into connected clusters via union-find.

    Any two tools connected by a similarity edge with score ≥
    min_score end up in the same cluster. Returns a list of
    clusters (each a list of qualified_names), sorted by size.
    """
    parent: dict[str, str] = {}

    def find(x: str) -> str:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a: str, b: str) -> None:
        parent.setdefault(a, a)
        parent.setdefault(b, b)
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    for sim in similarities:
        if sim.score < min_score:
            continue
        union(
            sim.tool_a.qualified_name,
            sim.tool_b.qualified_name,
        )

    clusters: dict[str, list[str]] = {}
    for name in parent:
        root = find(name)
        clusters.setdefault(root, []).append(name)

    # Only keep clusters with ≥2 members (singletons aren't duplicates)
    return sorted(
        [c for c in clusters.values() if len(c) >= 2],
        key=len,
        reverse=True,
    )
