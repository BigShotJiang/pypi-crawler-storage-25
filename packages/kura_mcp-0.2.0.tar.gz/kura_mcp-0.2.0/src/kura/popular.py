"""Fetch popular skills from the clawhub registry and map them to local paths.

Primary source: clawhub REST API at https://clawhub.ai/api/v1/search
    ?q=<term>&sort=downloads&limit=N

The API requires a non-empty `q` parameter. We merge results from a
handful of common-letter queries to approximate a "top-N by downloads"
global ranking without an exposed list endpoint.

Fallback / supplementary: parse the VoltAgent/awesome-openclaw-skills
README for a category-specific sample.

External validation: the 7 skills featured in the kdnuggets article
are always included regardless of API availability.
"""

from __future__ import annotations

import json
import re
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

CLAWHUB_SEARCH = "https://clawhub.ai/api/v1/search"
AWESOME_README = (
    "https://raw.githubusercontent.com/"
    "VoltAgent/awesome-openclaw-skills/main/README.md"
)

# Seed queries — single letters and common short words. Each call
# returns up to `per_query_limit` results ranked by downloads; merging
# approximates a global top-N since heavily downloaded skills tend to
# appear across many letter queries.
DEFAULT_SEED_QUERIES = [
    "a", "e", "i", "o", "the", "agent", "skill", "tool",
    "code", "search", "git", "web", "data", "file",
]

# 7 skills featured in the kdnuggets "essential" article.
# Format: (author, skill_name)
KDNUGGETS_SEED: list[tuple[str, str]] = [
    ("steipete", "gog"),
    ("steipete", "wacli"),
    ("arun-8687", "tavily-search"),
    ("steipete", "summarize"),
    ("steipete", "obsidian"),
    ("oswalpalash", "ontology"),
    ("thomasansems", "n8n"),
]


# -------------------------------------------------------------------
# Clawhub API
# -------------------------------------------------------------------

def _http_get_json(url: str, timeout: float = 15) -> dict:
    req = urllib.request.Request(
        url, headers={"User-Agent": "kura-popular/0.1"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def fetch_clawhub_ranked(
    seed_queries: list[str] | None = None,
    per_query_limit: int = 50,
) -> list[dict]:
    """Fetch and merge downloads-ranked results across seed queries.

    Returns a list of dicts like {slug, displayName, summary,
    occurrences, first_seen_rank} sorted by occurrence count then by
    the best rank seen. Occurrence = how many seed queries returned
    this slug in their top-N.
    """
    if seed_queries is None:
        seed_queries = DEFAULT_SEED_QUERIES

    slug_info: dict[str, dict] = {}

    for q in seed_queries:
        url = (
            f"{CLAWHUB_SEARCH}?"
            f"q={urllib.parse.quote(q)}&"
            f"sort=downloads&"
            f"limit={per_query_limit}"
        )
        try:
            data = _http_get_json(url)
        except (urllib.error.URLError, TimeoutError, OSError):
            continue

        for rank, item in enumerate(data.get("results", [])):
            slug = item.get("slug")
            if not slug:
                continue
            info = slug_info.setdefault(
                slug,
                {
                    "slug": slug,
                    "displayName": item.get("displayName", slug),
                    "summary": item.get("summary", ""),
                    "occurrences": 0,
                    "best_rank": rank,
                },
            )
            info["occurrences"] += 1
            if rank < info["best_rank"]:
                info["best_rank"] = rank

    # Rank: more occurrences first, then earlier best_rank
    return sorted(
        slug_info.values(),
        key=lambda x: (-x["occurrences"], x["best_rank"]),
    )


# -------------------------------------------------------------------
# Awesome-list parser (fallback / supplementary)
# -------------------------------------------------------------------

_LINK_RE = re.compile(
    r"^\s*-\s*\[(?P<name>[^\]]+)\]"
    r"\(https://clawskills\.sh/skills/(?P<slug>[^)]+)\)"
    r"(?:\s*-\s*(?P<summary>.+))?",
)

_HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*$")


def parse_awesome_list(
    markdown: str,
) -> dict[str, list[dict]]:
    """Parse an awesome-list markdown into {category: [entries]}.

    Works on the main README and on individual category sub-pages.
    """
    out: dict[str, list[dict]] = {}
    current = "_uncategorized"
    for line in markdown.splitlines():
        h = _HEADING_RE.match(line)
        if h and len(h.group(1)) in (1, 2, 3):
            current = h.group(2).strip()
            out.setdefault(current, [])
            continue
        m = _LINK_RE.match(line)
        if m:
            out.setdefault(current, []).append({
                "name": m.group("name"),
                "slug": m.group("slug"),
                "summary": (m.group("summary") or "").strip(),
            })
    return out


def fetch_awesome_list() -> str:
    req = urllib.request.Request(
        AWESOME_README,
        headers={"User-Agent": "kura-popular/0.1"},
    )
    with urllib.request.urlopen(req, timeout=15) as resp:
        return resp.read().decode("utf-8")


def fetch_awesome_all_slugs() -> set[str]:
    """Fetch the README PLUS every `categories/*.md` sub-page and
    return the union of slugs. The main README only highlights a
    fraction per category; the per-category pages list all entries.
    """
    import re
    req = urllib.request.Request(
        AWESOME_README,
        headers={"User-Agent": "kura-popular/0.1"},
    )
    with urllib.request.urlopen(req, timeout=15) as resp:
        readme = resp.read().decode("utf-8")
    slugs: set[str] = {
        m for m in re.findall(
            r"clawskills\.sh/skills/([^)\s]+)", readme,
        )
    }
    pages = sorted(set(re.findall(
        r"\]\((categories/[^)]+\.md)\)", readme,
    )))
    base = (
        "https://raw.githubusercontent.com/"
        "VoltAgent/awesome-openclaw-skills/main/"
    )
    for p in pages:
        try:
            url = base + p
            r = urllib.request.Request(
                url, headers={"User-Agent": "kura-popular/0.1"},
            )
            text = urllib.request.urlopen(
                r, timeout=15,
            ).read().decode("utf-8")
            slugs |= {
                m for m in re.findall(
                    r"clawskills\.sh/skills/([^)\s]+)", text,
                )
            }
        except (urllib.error.URLError, OSError):
            continue
    return slugs


# -------------------------------------------------------------------
# Slug -> local path resolution
# -------------------------------------------------------------------

def build_skill_index(
    skills_root: Path,
    cache_path: Path | None = None,
    progress: object = None,
) -> dict[str, list[Path]]:
    """Walk skills_root once and build {skill_name: [paths]}.

    Clawhub slugs don't encode the author, so to resolve a slug
    we index every local directory by its final name and look up
    matches.

    If `cache_path` is given, reads/writes a JSON cache so repeat
    runs skip the filesystem walk.
    """
    if cache_path and cache_path.exists():
        data = json.loads(cache_path.read_text())
        return {
            name: [Path(p) for p in paths]
            for name, paths in data.items()
        }

    index: dict[str, list[Path]] = {}
    author_dirs = [
        d for d in skills_root.iterdir() if d.is_dir()
    ]
    total = len(author_dirs)
    for i, author_dir in enumerate(author_dirs):
        if progress and i % 500 == 0:
            progress(f"Indexing {i}/{total} authors...")
        try:
            entries = list(author_dir.iterdir())
        except (OSError, PermissionError):
            continue
        for skill_dir in entries:
            if not skill_dir.is_dir():
                continue
            if _has_skill_md(skill_dir):
                index.setdefault(
                    skill_dir.name, [],
                ).append(skill_dir)

    if cache_path:
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        cache_path.write_text(json.dumps({
            name: [str(p) for p in paths]
            for name, paths in index.items()
        }))
    return index


def resolve_slug(
    slug: str,
    skills_root: Path,
    index: dict[str, list[Path]] | None = None,
) -> Path | None:
    """Resolve a clawhub slug to a local skill path.

    Tries in order:
      1. Exact match on the whole slug as skill name
      2. Split on each hyphen, treat right side as skill name and
         prefer matches whose parent-author starts with left side
      3. Fuzzy: return the first indexed skill whose name == slug

    Returns None if no match found.
    """
    if index is None:
        index = build_skill_index(skills_root)

    # 1. Exact match on slug as skill name
    if slug in index:
        return _pick_best(index[slug])

    # 2. Progressive hyphen split — left=author prefix, right=skill
    hyphens = [i for i, c in enumerate(slug) if c == "-"]
    for pos in hyphens:
        author_prefix = slug[:pos].lower()
        skill_part = slug[pos + 1:]
        if skill_part in index:
            for path in index[skill_part]:
                author_name = path.parent.name.lower()
                # skill_part matches; prefer author prefix match
                if author_name.startswith(author_prefix):
                    return path
            # Skill part matched but author prefix didn't — still
            # return the best candidate
            return _pick_best(index[skill_part])

    return None


def _pick_best(paths: list[Path]) -> Path:
    """If a skill name appears under multiple authors, pick one.

    Heuristic: the skill with the most files (likely more developed).
    """
    return max(paths, key=lambda p: sum(1 for _ in p.rglob("*")))


def _has_skill_md(path: Path) -> bool:
    """Check for SKILL.md without iterating (faster on WSL)."""
    for candidate in ("SKILL.md", "skill.md", "Skill.md"):
        if (path / candidate).is_file():
            return True
    return False
