"""Persistent embedding cache for large-scale similarity.

Stores sentence-transformer embeddings in a single compressed `.npz`
file keyed by a content hash. Re-runs skip embedding for tools whose
(name, description, sorted params) are unchanged.

Layout of the `.npz` file:
  - `hashes`: 1D array of str (hex SHA1s)
  - `embeddings`: 2D array (N, D) of float32

On read, we construct `dict[hash_hex, row_index]` for O(1) lookup.
"""

from __future__ import annotations

import hashlib
from pathlib import Path

import numpy as np

from kura.models import ToolDescriptor


def _tool_hash(tool: ToolDescriptor) -> str:
    """SHA1 of a stable representation of the tool."""
    h = hashlib.sha1()
    h.update(tool.name.encode("utf-8"))
    h.update(b"|")
    h.update(tool.description.encode("utf-8"))
    h.update(b"|")
    # Sort params by name for stability
    for p in sorted(tool.parameters, key=lambda x: x.name):
        h.update(p.name.encode("utf-8"))
        h.update(b":")
        h.update((p.description or "").encode("utf-8"))
        h.update(b";")
    return h.hexdigest()


def _tool_text_for_embedding(tool: ToolDescriptor) -> str:
    """Same formatter used by similarity.py. Duplicated here to
    avoid importing the optional similarity module."""
    parts = [
        tool.name.replace("_", " "),
        tool.description,
    ]
    if tool.parameters:
        names = ", ".join(
            p.name.replace("_", " ")
            for p in tool.parameters[:10]
        )
        parts.append(f"Parameters: {names}")
    return " | ".join(parts)


class EmbeddingCache:
    """Persistent file-based embedding cache."""

    def __init__(self, path: Path):
        self.path = Path(path)
        self._hashes: list[str] = []
        self._embeddings: np.ndarray | None = None
        self._index: dict[str, int] = {}
        self._load()

    def _load(self) -> None:
        if not self.path.exists():
            return
        try:
            data = np.load(self.path, allow_pickle=False)
            self._hashes = list(data["hashes"])
            self._embeddings = data["embeddings"]
            self._index = {
                h: i for i, h in enumerate(self._hashes)
            }
        except Exception:
            # Corrupted cache — start fresh.
            self._hashes = []
            self._embeddings = None
            self._index = {}

    def save(self) -> None:
        if self._embeddings is None or not self._hashes:
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        # np.savez auto-appends .npz; use an explicit tmp file path.
        tmp = self.path.parent / (self.path.name + ".tmp")
        with tmp.open("wb") as f:
            np.savez(
                f,
                hashes=np.array(self._hashes),
                embeddings=self._embeddings,
            )
        tmp.replace(self.path)

    def get_or_compute(
        self,
        tools: list[ToolDescriptor],
        progress: object = None,
    ) -> np.ndarray:
        """Return embeddings aligned to `tools`. Computes only
        tools whose hash isn't already cached."""
        hashes = [_tool_hash(t) for t in tools]
        missing_idx: list[int] = [
            i for i, h in enumerate(hashes)
            if h not in self._index
        ]

        if missing_idx:
            if progress:
                progress(
                    f"Embedding {len(missing_idx)} new "
                    f"tools ({len(hashes) - len(missing_idx)} "
                    f"from cache)..."
                )
            from sentence_transformers import (
                SentenceTransformer,
            )
            model = SentenceTransformer(
                "all-MiniLM-L6-v2",
            )
            texts = [
                _tool_text_for_embedding(tools[i])
                for i in missing_idx
            ]
            new_embs = model.encode(
                texts,
                normalize_embeddings=True,
                show_progress_bar=False,
                batch_size=64,
            ).astype(np.float32)

            # Append to cache storage
            new_hashes = [hashes[i] for i in missing_idx]
            if self._embeddings is None:
                self._embeddings = new_embs
                self._hashes = new_hashes
            else:
                self._embeddings = np.vstack(
                    [self._embeddings, new_embs],
                )
                self._hashes.extend(new_hashes)
            for i, h in enumerate(new_hashes):
                self._index[h] = (
                    len(self._hashes) - len(new_hashes) + i
                )
            self.save()

        # Return aligned array
        out = np.empty(
            (len(tools), self._embeddings.shape[1]),
            dtype=np.float32,
        )
        for i, h in enumerate(hashes):
            out[i] = self._embeddings[self._index[h]]
        return out
