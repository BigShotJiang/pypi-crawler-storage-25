"""Matplotlib-based PNG charts for scan reports.

Kept minimal — histograms + bar charts. Optional dependency;
falls back to no-op if matplotlib is not installed.
"""

from __future__ import annotations

from collections import Counter
from pathlib import Path

from kura.models import ScanReport


def write_charts(report: ScanReport, out_dir: Path) -> None:
    """Write PNGs to out_dir. Requires matplotlib."""
    import matplotlib
    matplotlib.use("Agg")  # no display
    import matplotlib.pyplot as plt

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    _chart_score_histogram(report, out_dir, plt)
    _chart_issue_frequency(report, out_dir, plt)
    _chart_token_histogram(report, out_dir, plt)
    _chart_boilerplate(report, out_dir, plt)


def _chart_score_histogram(
    report: ScanReport, out_dir: Path, plt,
) -> None:
    scores = [q.score for q in report.quality_results]
    if not scores:
        return
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.hist(
        scores, bins=20, range=(0, 100),
        edgecolor="black", alpha=0.8,
    )
    ax.set_xlabel("Quality score")
    ax.set_ylabel("Number of tools")
    ax.set_title(
        f"Quality score distribution ({len(scores)} tools)"
    )
    ax.axvline(
        sum(scores) / len(scores), color="red",
        linestyle="--", label=f"Mean: {sum(scores)/len(scores):.1f}",
    )
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_dir / "score_histogram.png", dpi=120)
    plt.close(fig)


def _chart_issue_frequency(
    report: ScanReport, out_dir: Path, plt,
) -> None:
    counter: Counter[str] = Counter()
    for q in report.quality_results:
        for issue in q.issues:
            counter[issue.code] += 1
    if not counter:
        return
    codes, counts = zip(
        *counter.most_common(),
    )
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.barh(codes, counts, edgecolor="black", alpha=0.8)
    ax.set_xlabel("Count")
    ax.set_title("Issues by rule")
    ax.invert_yaxis()
    fig.tight_layout()
    fig.savefig(out_dir / "issue_frequency.png", dpi=120)
    plt.close(fig)


def _chart_token_histogram(
    report: ScanReport, out_dir: Path, plt,
) -> None:
    tokens = [t.token_count for t in report.token_results]
    if not tokens:
        return
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.hist(tokens, bins=30, edgecolor="black", alpha=0.8)
    ax.set_xlabel("Tokens per tool")
    ax.set_ylabel("Number of tools")
    ax.set_title("Token count distribution")
    fig.tight_layout()
    fig.savefig(out_dir / "token_histogram.png", dpi=120)
    plt.close(fig)


def _chart_boilerplate(
    report: ScanReport, out_dir: Path, plt,
) -> None:
    if not report.boilerplate:
        return
    top = report.boilerplate[:10]
    labels = [
        (bp.description[:40] + "..." if
         len(bp.description) > 40 else bp.description)
        for bp in top
    ]
    wasted = [bp.wasted_tokens for bp in top]
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.barh(labels, wasted, edgecolor="black", alpha=0.8)
    ax.set_xlabel("Wasted tokens")
    ax.set_title("Top-10 repeated parameter descriptions")
    ax.invert_yaxis()
    fig.tight_layout()
    fig.savefig(out_dir / "boilerplate.png", dpi=120)
    plt.close(fig)
