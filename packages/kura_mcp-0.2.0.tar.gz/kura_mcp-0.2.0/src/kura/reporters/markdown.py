"""Generate a markdown summary of a scan report."""

from __future__ import annotations

import statistics
from collections import Counter
from pathlib import Path

from kura.models import ScanReport


def write_summary_md(
    report: ScanReport, path: Path,
) -> None:
    lines: list[str] = []
    lines.append("# Kura Scan Summary\n")
    lines.append(
        f"- **Tools scanned:** {len(report.tools)}"
    )
    lines.append(
        f"- **Overall catalog health:** "
        f"{report.overall_health}/100"
    )
    lines.append(
        f"- **Total tokens:** {report.total_tokens:,}"
    )
    if report.boilerplate:
        wasted = sum(
            b.wasted_tokens for b in report.boilerplate
        )
        lines.append(
            f"- **Boilerplate waste:** {wasted:,} tokens "
            f"({len(report.boilerplate)} phrases repeated)"
        )

    lines.append("")
    _append_score_distribution(lines, report)
    _append_issue_frequency(lines, report)
    _append_top_worst(lines, report)
    _append_top_best(lines, report)
    _append_top_boilerplate(lines, report)
    _append_duplicates(lines, report)

    path.write_text("\n".join(lines) + "\n")


def _append_score_distribution(
    lines: list[str], report: ScanReport,
) -> None:
    if not report.quality_results:
        return
    scores = [q.score for q in report.quality_results]
    lines.append("## Score distribution\n")
    lines.append(
        f"- Median: {statistics.median(scores):.0f}"
    )
    lines.append(
        f"- Mean: {statistics.mean(scores):.1f}"
    )
    lines.append(f"- Min: {min(scores)}, Max: {max(scores)}")
    buckets = {
        "0-20": 0, "21-40": 0, "41-60": 0,
        "61-80": 0, "81-100": 0,
    }
    for s in scores:
        if s <= 20:
            buckets["0-20"] += 1
        elif s <= 40:
            buckets["21-40"] += 1
        elif s <= 60:
            buckets["41-60"] += 1
        elif s <= 80:
            buckets["61-80"] += 1
        else:
            buckets["81-100"] += 1
    total = len(scores)
    lines.append("")
    lines.append("| Range | Count | % |")
    lines.append("|-------|-------|---|")
    for rng, count in buckets.items():
        pct = 100 * count / total
        lines.append(f"| {rng} | {count} | {pct:.1f}% |")
    lines.append("")


def _append_issue_frequency(
    lines: list[str], report: ScanReport,
) -> None:
    counter: Counter[str] = Counter()
    for q in report.quality_results:
        for issue in q.issues:
            counter[issue.code] += 1
    if not counter:
        return
    total_tools = len(report.quality_results)
    lines.append("## Issue frequency\n")
    lines.append("| Code | Count | % of tools |")
    lines.append("|------|-------|------------|")
    for code, count in counter.most_common():
        pct = 100 * count / total_tools
        lines.append(f"| {code} | {count} | {pct:.1f}% |")
    lines.append("")


def _append_top_worst(
    lines: list[str], report: ScanReport, n: int = 10,
) -> None:
    worst = sorted(
        report.quality_results, key=lambda q: q.score,
    )[:n]
    if not worst:
        return
    lines.append(f"## Top {n} lowest-scoring tools\n")
    lines.append("| Tool | Score | Issues |")
    lines.append("|------|-------|--------|")
    for q in worst:
        lines.append(
            f"| `{q.tool.qualified_name}` | "
            f"{q.score}/100 | {len(q.issues)} |"
        )
    lines.append("")


def _append_top_best(
    lines: list[str], report: ScanReport, n: int = 10,
) -> None:
    best = sorted(
        report.quality_results,
        key=lambda q: q.score, reverse=True,
    )[:n]
    if not best:
        return
    lines.append(f"## Top {n} highest-scoring tools\n")
    lines.append("| Tool | Score |")
    lines.append("|------|-------|")
    for q in best:
        lines.append(
            f"| `{q.tool.qualified_name}` | {q.score}/100 |"
        )
    lines.append("")


def _append_top_boilerplate(
    lines: list[str], report: ScanReport, n: int = 10,
) -> None:
    if not report.boilerplate:
        return
    lines.append(f"## Top {n} repeated parameter descriptions\n")
    lines.append(
        "| Source | Count | Wasted | Description |"
    )
    lines.append(
        "|--------|-------|--------|-------------|"
    )
    for bp in report.boilerplate[:n]:
        preview = bp.description[:80].replace("|", "\\|")
        if len(bp.description) > 80:
            preview += "..."
        lines.append(
            f"| {bp.source} | {bp.count} | "
            f"{bp.wasted_tokens} | {preview} |"
        )
    lines.append("")


def _append_duplicates(
    lines: list[str], report: ScanReport, n: int = 10,
) -> None:
    sims = report.similarities or []
    intra = report.intra_similarities or []
    if not sims and not intra:
        return
    lines.append("## Similarity pairs\n")
    total = len(sims) + len(intra)
    lines.append(
        f"- Cross-server pairs: {len(sims)}"
    )
    lines.append(
        f"- Intra-server pairs: {len(intra)}"
    )
    lines.append(f"- Total: {total}")
    lines.append("")

    all_sims = sorted(
        list(sims) + list(intra),
        key=lambda s: s.score, reverse=True,
    )[:n]
    if all_sims:
        lines.append(f"### Top {len(all_sims)} similar pairs\n")
        lines.append("| A | B | Score | Scope |")
        lines.append("|---|---|-------|-------|")
        for s in all_sims:
            lines.append(
                f"| `{s.tool_a.qualified_name}` | "
                f"`{s.tool_b.qualified_name}` | "
                f"{s.score:.2f} | {s.scope} |"
            )
        lines.append("")
