"""Write a scan report to a self-contained run directory.

Produces JSON, multiple CSVs, a markdown summary, and optional
matplotlib charts. Designed for reproducible analysis runs that can
be shared or diffed against previous runs.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path

from kura.models import ScanReport
from kura.reporters.json_out import report_json


def _clean(s: object) -> str:
    """Strip control chars / whitespace that break csv.writer."""
    if s is None:
        return ""
    text = str(s)
    # Replace any control char (except normal ASCII printable) with space
    cleaned = "".join(
        c if c == " " or 32 <= ord(c) < 127
        or ord(c) >= 128
        else " "
        for c in text
    )
    return " ".join(cleaned.split())


def write_run_dir(
    report: ScanReport,
    run_dir: Path,
    *,
    charts: bool = True,
    markdown: bool = True,
) -> None:
    """Write full report, CSVs, markdown, and charts to run_dir."""
    run_dir = Path(run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)

    # Full JSON (reuse existing serializer)
    (run_dir / "report.json").write_text(report_json(report))

    # Per-tool CSV
    _write_scores_csv(report, run_dir / "scores.csv")
    _write_issues_csv(report, run_dir / "issues.csv")
    if report.boilerplate:
        _write_boilerplate_csv(
            report, run_dir / "boilerplate.csv",
        )
    _write_similarity_csv(report, run_dir / "similarity.csv")

    if markdown:
        from kura.reporters.markdown import write_summary_md
        write_summary_md(report, run_dir / "summary.md")

    if charts:
        try:
            from kura.reporters.charts import write_charts
            write_charts(report, run_dir / "charts")
        except ImportError:
            # matplotlib not installed — skip silently
            pass


def _write_scores_csv(report: ScanReport, path: Path) -> None:
    token_map = {
        t.tool.qualified_name: t.token_count
        for t in report.token_results
    }
    outlier_map = {
        t.tool.qualified_name: t.is_outlier
        for t in report.token_results
    }
    with path.open("w", newline="") as f:
        w = csv.writer(f, quoting=csv.QUOTE_MINIMAL)
        w.writerow([
            "qualified_name", "source", "name", "score",
            "token_count", "is_outlier", "issue_count",
            "llm_enhanced",
        ])
        for q in sorted(
            report.quality_results, key=lambda x: x.score,
        ):
            name = q.tool.qualified_name
            w.writerow([
                _clean(name),
                _clean(q.tool.source),
                _clean(q.tool.name),
                q.score,
                token_map.get(name, 0),
                int(outlier_map.get(name, False)),
                len(q.issues),
                int(q.llm_enhanced),
            ])


def _write_issues_csv(report: ScanReport, path: Path) -> None:
    with path.open("w", newline="") as f:
        w = csv.writer(f, quoting=csv.QUOTE_MINIMAL)
        w.writerow([
            "qualified_name", "code", "severity",
            "source", "message",
        ])
        for q in report.quality_results:
            for issue in q.issues:
                w.writerow([
                    _clean(q.tool.qualified_name),
                    _clean(issue.code),
                    _clean(issue.severity),
                    _clean(issue.source),
                    _clean(issue.message),
                ])


def _write_boilerplate_csv(
    report: ScanReport, path: Path,
) -> None:
    with path.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow([
            "source", "count", "wasted_tokens",
            "description_preview",
        ])
        for bp in report.boilerplate:
            preview = _clean(bp.description[:100])
            w.writerow([
                _clean(bp.source), bp.count,
                bp.wasted_tokens, preview,
            ])


def _write_similarity_csv(
    report: ScanReport, path: Path,
) -> None:
    all_sims = []
    if report.similarities:
        all_sims.extend(report.similarities)
    if report.intra_similarities:
        all_sims.extend(report.intra_similarities)
    if not all_sims:
        return
    with path.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["tool_a", "tool_b", "score", "scope"])
        for s in all_sims:
            w.writerow([
                _clean(s.tool_a.qualified_name),
                _clean(s.tool_b.qualified_name),
                round(s.score, 4),
                _clean(s.scope),
            ])


# Backward compat: write just the manifest if we were given one
def write_manifest(manifest: dict, path: Path) -> None:
    path.write_text(json.dumps(manifest, indent=2))
