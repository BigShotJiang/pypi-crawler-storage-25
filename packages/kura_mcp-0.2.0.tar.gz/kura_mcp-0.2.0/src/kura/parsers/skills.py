"""Parse OpenClaw SKILL.md files from directories."""

import json
import re
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import yaml

from kura.models import ToolDescriptor


def parse_skills_directory(
    path: Path,
    max_workers: int = 16,
) -> list[ToolDescriptor]:
    """Scan a directory tree for SKILL.md files and parse them.

    If a skill index cache exists at ~/.kura/skill_index.json AND
    its paths match `path`, use it to skip the expensive rglob.
    Parses files in parallel with a thread pool (fast for slow
    filesystems like WSL /mnt/c).
    """
    skill_files = _load_from_cache(path)
    if not skill_files:
        skill_files = list(path.rglob("[Ss][Kk][Ii][Ll][Ll].[Mm][Dd]"))

    if not skill_files:
        skill_files = list(path.rglob("*.md"))

    if max_workers > 1 and len(skill_files) > 100:
        with ThreadPoolExecutor(
            max_workers=max_workers,
        ) as ex:
            results = list(ex.map(
                lambda p: _parse_skill_file(p, root=path),
                skill_files,
            ))
    else:
        results = [
            _parse_skill_file(p, root=path)
            for p in skill_files
        ]

    return [t for t in results if t is not None]


def _load_from_cache(root: Path) -> list[Path]:
    """If the skill-index cache exists and matches `root`,
    return the list of SKILL.md paths from it. Otherwise []."""
    cache_path = Path.home() / ".kura" / "skill_index.json"
    if not cache_path.exists():
        return []
    try:
        data = json.loads(cache_path.read_text())
    except (OSError, json.JSONDecodeError):
        return []

    root_str = str(root.resolve())
    files: list[Path] = []
    for _name, paths in data.items():
        for p in paths:
            if not p.startswith(root_str):
                continue
            for candidate in (
                "SKILL.md", "skill.md", "Skill.md",
            ):
                f = Path(p) / candidate
                if f.is_file():
                    files.append(f)
                    break
    return files


def _parse_skill_file(path: Path, root: Path) -> ToolDescriptor | None:
    """Parse a single SKILL.md file."""
    try:
        content = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return None

    # Extract YAML frontmatter
    frontmatter = {}
    body = content
    fm_match = re.match(r"^---\s*\n(.*?)\n---\s*\n(.*)", content, re.DOTALL)
    if fm_match:
        try:
            parsed = yaml.safe_load(fm_match.group(1))
            frontmatter = parsed if isinstance(parsed, dict) else {}
        except yaml.YAMLError:
            frontmatter = {}
        body = fm_match.group(2)

    # Extract name from frontmatter or directory name
    name = frontmatter.get("name", "")
    if not isinstance(name, str):
        name = ""
    if not name:
        # Use parent directory name as skill name
        rel = path.relative_to(root)
        name = rel.parent.name if rel.parent != Path(".") else path.stem

    # Extract description from frontmatter or first paragraph of body
    description = frontmatter.get("description", "")
    if not isinstance(description, str):
        description = str(description) if description else ""
    if not description:
        description = _extract_first_paragraph(body)

    # Build relative source path
    try:
        source = str(path.relative_to(root).parent)
    except ValueError:
        source = str(path.parent)

    return ToolDescriptor(
        name=name,
        source=source,
        source_type="skill",
        description=description,
        raw_config=frontmatter,
    )


def _extract_first_paragraph(markdown: str) -> str:
    """Extract the first non-empty, non-heading paragraph from markdown."""
    lines = markdown.strip().split("\n")
    paragraph_lines = []

    for line in lines:
        stripped = line.strip()
        # Skip headings and empty lines before first paragraph
        if not paragraph_lines:
            if not stripped or stripped.startswith("#"):
                continue
        # End paragraph at empty line or heading
        if paragraph_lines and (not stripped or stripped.startswith("#")):
            break
        paragraph_lines.append(stripped)

    return " ".join(paragraph_lines)[:500]  # Cap at 500 chars
