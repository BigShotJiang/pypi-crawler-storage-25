#!/usr/bin/env python3
"""
AgentOS CLI tool
"""

import argparse
import os
import platform
import subprocess
import sys
from pathlib import Path

VERSION = "0.1.2"
IMAGE_NAME = "nuwax-docker-images-registry.cn-hangzhou.cr.aliyuncs.com/nuwax/nuwax-agent-client:latest"
CONTAINER_NAME = "agentos-client"

COLORS = {
    "green": "\033[0;32m",
    "yellow": "\033[1;33m",
    "red": "\033[0;31m",
    "cyan": "\033[0;36m",
    "reset": "\033[0m",
}


def color(name, text):
    return f"{COLORS.get(name, '')}{text}{COLORS['reset']}"


def info(text):
    print(color("green", f"[INFO]  {text}"))


def warn(text):
    print(color("yellow", f"[WARN]  {text}"))


def error(text):
    print(color("red", f"[ERROR] {text}"))


# ============================================================
# Docker Registry Mirrors (acceleration)
# ============================================================

DOCKER_MIRRORS = [
    "https://docker.1ms.run",
    "https://hub-mirror.c.163.com",
    "https://docker.m.daocloud.io",
]


def configure_docker_mirrors():
    """配置 Docker 镜像加速器，加快拉取速度"""
    system = platform.system()
    info("正在检查 Docker 镜像加速配置...")

    if system == "Linux":
        _configure_linux_mirrors()
    elif system == "Darwin":
        _configure_darwin_mirrors()
    elif system == "Windows":
        _configure_windows_mirrors()


def _configure_linux_mirrors():
    """Linux 上配置 daemon.json 镜像加速"""
    daemon_json = Path("/etc/docker/daemon.json")

    # 检查是否已配置
    if daemon_json.exists():
        import json
        try:
            existing = json.loads(daemon_json.read_text())
            if "registry-mirrors" in existing:
                info("Docker 镜像加速已配置")
                return
        except (json.JSONDecodeError, IOError):
            pass

    # 写入配置
    config = {"registry-mirrors": DOCKER_MIRRORS}
    if daemon_json.exists():
        try:
            import json
            existing = json.loads(daemon_json.read_text())
            existing.update(config)
            config = existing
        except (json.JSONDecodeError, IOError):
            pass

    try:
        daemon_json.write_text(json.dumps(config, indent=2))
        info("已写入 Docker 镜像加速配置")

        # 重载 Docker daemon
        subprocess.run(
            ["sudo", "systemctl", "reload", "docker"],
            capture_output=True, text=True
        )
        # 如果 reload 失败，尝试 restart
        result = subprocess.run(
            ["docker", "info"], capture_output=True, text=True, timeout=5
        )
        if result.returncode != 0:
            subprocess.run(["sudo", "systemctl", "restart", "docker"])
            info("Docker 已重启")
    except PermissionError:
        warn("无权限写入 /etc/docker/daemon.json，跳过镜像加速配置")


def _configure_darwin_mirrors():
    """macOS 上配置 ~/.docker/daemon.json 镜像加速"""
    daemon_json = Path.home() / ".docker" / "daemon.json"
    daemon_json.parent.mkdir(parents=True, exist_ok=True)

    if daemon_json.exists():
        import json
        try:
            existing = json.loads(daemon_json.read_text())
            if "registry-mirrors" in existing:
                info("Docker 镜像加速已配置")
                return
            existing.update({"registry-mirrors": DOCKER_MIRRORS})
            config = existing
        except (json.JSONDecodeError, IOError):
            config = {"registry-mirrors": DOCKER_MIRRORS}
    else:
        config = {"registry-mirrors": DOCKER_MIRRORS}

    daemon_json.write_text(json.dumps(config, indent=2))
    info("已写入 macOS Docker 镜像加速配置 (~/.docker/daemon.json)")
    info("请重启 Docker Desktop 使配置生效")


def _configure_windows_mirrors():
    """Windows 上配置 %PROGRAMDATA%\\Docker\\config\\daemon.json 镜像加速"""
    import json
    docker_config_dir = Path(os.environ.get("PROGRAMDATA", "")) / "Docker" / "config"
    daemon_json = docker_config_dir / "daemon.json"
    daemon_config_dir = Path(os.environ.get("PROGRAMDATA", "")) / "Docker" / "config" / "daemon"
    daemon_json_alt = daemon_config_dir / "daemon.json"

    # Docker Desktop on Windows 配置文件可能在两个位置
    for config_path in [daemon_json, daemon_json_alt]:
        if config_path.exists():
            try:
                existing = json.loads(config_path.read_text())
                if "registry-mirrors" in existing:
                    info("Docker 镜像加速已配置")
                    return
                existing.update({"registry-mirrors": DOCKER_MIRRORS})
                config = existing
            except (json.JSONDecodeError, IOError):
                config = {"registry-mirrors": DOCKER_MIRRORS}
            config_path.write_text(json.dumps(config, indent=2))
            info(f"已写入 Windows Docker 镜像加速配置: {config_path}")
            info("请重启 Docker Desktop 使配置生效")
            return

    # 如果两个位置都不存在，写入到默认位置
    docker_config_dir.mkdir(parents=True, exist_ok=True)
    config = {"registry-mirrors": DOCKER_MIRRORS}
    daemon_json.write_text(json.dumps(config, indent=2))
    info(f"已写入 Windows Docker 镜像加速配置: {daemon_json}")
    info("请重启 Docker Desktop 使配置生效")


# ============================================================
# Docker
# ============================================================

def docker_installed():
    """检查 Docker 是否已安装并运行"""
    try:
        result = subprocess.run(
            ["docker", "info"], capture_output=True, text=True,
            timeout=10
        )
        if result.returncode == 0:
            return True
    except (subprocess.SubprocessError, FileNotFoundError):
        pass
    return False


def check_docker():
    """检查 Docker，未安装则自动安装"""
    if docker_installed():
        return

    warn("未检测到 Docker，开始自动安装...")
    install_docker()

    # 安装后验证
    if not docker_installed():
        error("Docker 安装完成但服务未启动，请手动检查")
        sys.exit(1)

    info(f"Docker 已安装: {subprocess.run(['docker', '--version'], capture_output=True, text=True).stdout.strip()}")


def install_docker():
    """自动安装 Docker"""
    system = platform.system()

    if system == "Windows":
        _install_docker_windows()
    elif system == "Darwin":
        _install_docker_mac()
    else:
        _install_docker_linux()

    # 启动服务
    if system != "Windows":
        info("正在启动 Docker 服务...")
        subprocess.run(["sudo", "systemctl", "start", "docker"])
        subprocess.run(["sudo", "systemctl", "enable", "docker"])

    info("Docker 安装完成，请重新运行此命令")
    sys.exit(0)


def _install_docker_windows():
    info("正在安装 Docker Desktop (Windows)...")

    # 优先使用 winget（Win10/11 内置）
    try:
        result = subprocess.run(
            ["winget", "--version"], capture_output=True, text=True
        )
        if result.returncode == 0:
            info("使用 winget 安装...")
            # winget 在已安装时会返回非零退出码，不视为失败
            subprocess.run([
                "winget", "install", "-e", "--id", "Docker.DockerDesktop",
                "--accept-package-agreements", "--accept-source-agreements"
            ])
            _auto_start_docker("windows")
            return
    except FileNotFoundError:
        pass

    # 备选：PowerShell 下载安装
    info("winget 不可用，使用 PowerShell 下载安装...")
    docker_installer_url = (
        "https://desktop.docker.com/win/main/amd64/Docker%20Desktop%20Installer.exe"
    )
    installer_path = os.path.join(
        os.environ.get("TEMP", "."), "DockerDesktopInstaller.exe"
    )

    info(f"正在下载: {docker_installer_url}")
    run_cmd([
        "powershell", "-Command",
        f"Invoke-WebRequest -Uri '{docker_installer_url}' "
        f"-OutFile '{installer_path}'"
    ])

    info("正在安装 Docker Desktop...")
    subprocess.run([installer_path, "install", "--quiet", "--accept-license"])

    _auto_start_docker("windows")


def _install_docker_mac():
    info("正在安装 Docker Desktop (macOS)...")

    # 优先使用 Homebrew
    try:
        result = subprocess.run(
            ["brew", "--version"], capture_output=True, text=True
        )
        if result.returncode == 0:
            info("使用 Homebrew 安装...")
            subprocess.run(["brew", "install", "--cask", "docker"])
            _auto_start_docker("mac")
            return
    except FileNotFoundError:
        pass

    # 备选：下载 dmg 安装
    info("Homebrew 不可用，直接下载 Docker Desktop...")
    docker_dmg_url = (
        "https://desktop.docker.com/mac/main/arm64/Docker.dmg"
    )
    dmg_path = "/tmp/Docker.dmg"

    info(f"正在下载: {docker_dmg_url}")
    run_cmd(["curl", "-fsSL", docker_dmg_url, "-o", dmg_path])

    info("正在挂载并安装...")
    result = subprocess.run(
        ["hdiutil", "attach", dmg_path],
        capture_output=True, text=True
    )
    mount_point = None
    for line in result.stdout.splitlines():
        if "Docker" in line and "/Volumes/" in line:
            mount_point = line.split("/Volumes/")[-1].strip()
            break

    if mount_point:
        subprocess.run([
            "cp", "-R", f"/Volumes/{mount_point}/Docker.app", "/Applications/"
        ])
        subprocess.run(["hdiutil", "detach", f"/Volumes/{mount_point}"])

    os.remove(dmg_path)
    _auto_start_docker("mac")


def _auto_start_docker(platform):
    """安装后自动启动 Docker Desktop，轮询等待就绪"""
    print()
    info("正在启动 Docker Desktop...")

    if platform == "windows":
        try:
            subprocess.Popen(
                ["C:\\Program Files\\Docker\\Docker\\Docker Desktop.exe"],
                creationflags=subprocess.CREATE_NO_WINDOW
            )
        except FileNotFoundError:
            error("Docker Desktop 安装路径未找到，请在开始菜单手动启动")
            sys.exit(1)
    elif platform == "mac":
        subprocess.Popen(["open", "/Applications/Docker.app"])

    print()
    info("Docker Desktop 正在初始化，请稍候...")
    print("  （如需接受许可协议，请在弹出的窗口中点击 Accept）")

    _wait_for_docker_ready()


def _wait_for_docker_ready(timeout=300):
    """轮询等待 Docker 就绪，最多等待 timeout 秒"""
    import time
    start = time.time()
    dots = 0
    while time.time() - start < timeout:
        try:
            result = subprocess.run(
                ["docker", "info"],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                print()
                info("Docker 已就绪")
                return
        except (subprocess.SubprocessError, FileNotFoundError):
            pass

        # 每 3 秒打印一个点
        dots += 1
        if dots % 5 == 0:
            elapsed = int(time.time() - start)
            print(f"\r  等待中... ({elapsed}s)", end="", flush=True)

        time.sleep(3)

    print()
    error(f"Docker 在 {timeout}s 内未就绪，请稍后重试")
    sys.exit(1)


def _install_docker_linux():
    try:
        with open("/etc/os-release") as f:
            os_release = f.read()
    except FileNotFoundError:
        os_release = ""

    if "ubuntu" in os_release or "debian" in os_release:
        _install_docker_debian()
    elif "centos" in os_release or "rhel" in os_release or "rocky" in os_release or "almalinux" in os_release:
        _install_docker_centos()
    else:
        _install_docker_generic()


def _install_docker_debian():
    info("正在安装 Docker (Debian/Ubuntu)...")
    run_cmd(["sudo", "apt-get", "update"])
    run_cmd([
        "sudo", "apt-get", "install", "-y",
        "ca-certificates", "curl", "gnupg", "lsb-release",
    ])
    run_cmd(["sudo", "install", "-m", "0755", "-d", "/etc/apt/keyrings"])
    try:
        run_cmd([
            "sudo", "bash", "-c",
            "curl -fsSL https://mirrors.aliyun.com/docker-ce/linux/ubuntu/gpg "
            "| gpg --dearmor -o /etc/apt/keyrings/docker.gpg"
        ])
    except RuntimeError:
        run_cmd([
            "sudo", "bash", "-c",
            "curl -fsSL https://mirrors.aliyun.com/docker-ce/linux/debian/gpg "
            "| gpg --dearmor -o /etc/apt/keyrings/docker.gpg"
        ])
    run_cmd(["sudo", "chmod", "a+r", "/etc/apt/keyrings/docker.gpg"])
    run_cmd([
        "sudo", "bash", "-c",
        "echo 'deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] "
        "https://mirrors.aliyun.com/docker-ce/linux/ubuntu $(lsb_release -cs) stable' "
        "> /etc/apt/sources.list.d/docker.list"
    ])
    run_cmd(["sudo", "apt-get", "update"])
    run_cmd([
        "sudo", "apt-get", "install", "-y",
        "docker-ce", "docker-ce-cli", "containerd.io", "docker-compose-plugin",
    ])


def _install_docker_centos():
    info("正在安装 Docker (CentOS/RHEL)...")
    run_cmd(["sudo", "yum", "install", "-y", "yum-utils"])
    try:
        run_cmd([
            "sudo", "yum-config-manager", "--add-repo",
            "https://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo"
        ])
    except RuntimeError:
        run_cmd([
            "sudo", "yum-config-manager", "--add-repo",
            "https://download.docker.com/linux/centos/docker-ce.repo"
        ])
    run_cmd([
        "sudo", "yum", "install", "-y",
        "docker-ce", "docker-ce-cli", "containerd.io", "docker-compose-plugin",
    ])


def _install_docker_generic():
    info("正在安装 Docker (通用脚本)...")
    run_cmd(["sudo", "bash", "-c", "curl -fsSL https://get.docker.com | sh -s -- --mirror Aliyun"])


def compose_command():
    """返回可用的 docker compose 命令"""
    for cmd in [["docker", "compose"], ["docker-compose"]]:
        try:
            result = subprocess.run(
                cmd + ["version"], capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                return cmd
        except (subprocess.SubprocessError, FileNotFoundError):
            continue
    return None


def run_cmd(cmd, check=True):
    """执行 shell 命令"""
    print(color("cyan", f"$ {' '.join(cmd)}"))
    result = subprocess.run(cmd)
    if check and result.returncode != 0:
        raise RuntimeError(f"命令执行失败: {' '.join(cmd)}")
    return result


def pull_image():
    """拉取镜像（带进度显示）"""
    info(f"正在拉取镜像: {IMAGE_NAME}")
    print()

    process = subprocess.Popen(
        ["docker", "pull", IMAGE_NAME],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, bufsize=1
    )

    layers = {}  # layer_id -> {status, progress}
    total_lines = 0
    dots = 0

    for line in process.stdout:
        line = line.strip()
        if not line:
            continue
        total_lines += 1

        # 解析 docker pull 输出: "layer_id: status progress" 或 "status"
        if ":" in line and ("Downloading" in line or "Extracting" in line or "Pulling fs layer" in line or "Waiting" in line or "Verifying Checksum" in line or "Download complete" in line or "Pull complete" in line or "Already exists" in line):
            parts = line.split(":", 1)
            layer_id = parts[0].strip()
            status_and_progress = parts[1].strip() if len(parts) > 1 else ""
            layers[layer_id] = status_and_progress
        elif line and not line.startswith("{"):
            # 非结构化输出（如 "latest: Pulling from ..."）
            print(f"  {line}")

        # 每 20 行刷新一次显示
        dots += 1
        if dots % 20 == 0:
            _print_pull_progress(layers)

    process.wait()

    print()  # 最终刷新
    _print_pull_progress(layers, final=True)

    if process.returncode != 0:
        error("镜像拉取失败")
        sys.exit(1)

    info("镜像拉取完成")
    print()


def _print_pull_progress(layers, final=False):
    """打印拉取进度"""
    total = len(layers)
    if total == 0:
        return

    completed = 0
    downloading = 0
    for layer_id, status in layers.items():
        if "Pull complete" in status or "Download complete" in status or "Already exists" in status:
            completed += 1
        elif "Downloading" in status or "Extracting" in status:
            downloading += 1

    # 提取进度百分比
    pct_str = ""
    for layer_id, status in layers.items():
        if "Downloading" in status or "Extracting" in status:
            # 匹配 "xx.xxB / xx.xxB" 格式
            import re
            match = re.search(r'([\d.]+\w+)\s*/\s*([\d.]+\w+)', status)
            if match:
                try:
                    current = _to_bytes(match.group(1))
                    total_bytes = _to_bytes(match.group(2))
                    if total_bytes > 0:
                        pct = current / total_bytes * 100
                        pct_str = f"  {layer_id[:12]}: {pct:.0f}%"
                        break
                except (ValueError, IndexError):
                    pass

    bar_len = 30
    if completed > 0:
        filled = int(bar_len * completed / total)
        bar = "█" * filled + "░" * (bar_len - filled)
    else:
        bar = "░" * bar_len

    sys.stdout.write(f"\r  [{bar}] {completed}/{total} 层{pct_str}   ")
    if final:
        sys.stdout.write("\n")
    sys.stdout.flush()


def _to_bytes(size_str):
    """将 '123.4MB', '1.2GB', '567kB' 等转为字节"""
    size_str = size_str.strip().upper()
    import re
    match = re.match(r'([\d.]+)\s*(B|KB|MB|GB|TB)', size_str)
    if not match:
        return 0
    value = float(match.group(1))
    unit = match.group(2)
    multipliers = {"B": 1, "KB": 1024, "MB": 1024**2, "GB": 1024**3, "TB": 1024**4}
    return int(value * multipliers.get(unit, 1))


def ensure_image():
    """确保镜像存在（带整体进度）"""
    result = subprocess.run(
        ["docker", "image", "inspect", IMAGE_NAME],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        pull_image()
    else:
        info("镜像已存在，跳过拉取")


# ============================================================
# Config
# ============================================================

def get_config_dir():
    """获取配置目录"""
    return Path.home() / ".agentos"


def get_compose_file():
    return get_config_dir() / "docker-compose.yml"


def get_env_file():
    return get_config_dir() / ".env"


def get_saved_key():
    """获取 NUWAX_SAVED_KEY"""
    # 优先级: 环境变量 > .env 文件
    key = os.environ.get("NUWAX_SAVED_KEY")
    if key:
        return key

    env_file = get_env_file()
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            if line.startswith("NUWAX_SAVED_KEY="):
                return line.split("=", 1)[1].strip()

    return None


def save_saved_key(key):
    """保存 key 到 .env"""
    config_dir = get_config_dir()
    config_dir.mkdir(parents=True, exist_ok=True)

    env_file = get_env_file()
    env_file.write_text(f"# AgentOS 配置\nNUWAX_SAVED_KEY={key}\n")
    info(f"已保存 key 到 {env_file}")


# ============================================================
# Setup
# ============================================================

def setup(key=None, force=False):
    """首次安装/设置"""
    print()
    print("=" * 50)
    print("  AgentOS 安装")
    print("=" * 50)
    print()

    # 1. 检查/安装 Docker
    check_docker()

    # 2. 配置镜像加速
    configure_docker_mirrors()

    # 3. 检查 docker compose
    compose = compose_command()
    if not compose:
        error("未找到 docker compose 或 docker-compose 命令")
        print("  请安装 Docker Compose")
        sys.exit(1)

    info(f"使用 compose 命令: {' '.join(compose)}")

    # 4. 检查/拉取镜像（带进度）
    ensure_image()

    # 5. 获取 key
    if key:
        saved_key = key
    else:
        saved_key = get_saved_key()

    if not saved_key:
        saved_key = input(color("yellow", "[输入] 请输入 NUWAX_SAVED_KEY: ")).strip()
        if not saved_key:
            error("key 不能为空")
            sys.exit(1)

    save_saved_key(saved_key)

    # 6. 部署 compose 文件
    deploy_compose(saved_key, force)

    print()
    info("安装完成！")
    info(f"配置文件: {get_config_dir()}")
    print()
    print("  后续使用命令:")
    print("    agentos start    启动容器")
    print("    agentos stop     停止容器")
    print("    agentos restart  重启容器")
    print("    agentos status   查看状态")
    print()


def deploy_compose(key, force=False):
    """部署 docker-compose.yml"""
    config_dir = get_config_dir()
    config_dir.mkdir(parents=True, exist_ok=True)

    compose_file = get_compose_file()

    if compose_file.exists() and not force:
        info(f"docker-compose.yml 已存在: {compose_file}")
        return

    # 从包内读取模板
    compose_template = """services:
  agentos-client:
    image: {image}
    container_name: {container_name}
    restart: always
    ports:
      - "6080:6080"
    volumes:
      - agentos_home:/home/user
      - ./app/app.asar:/opt/NuwaClaw/resources/app.asar
      - ./desktop/gogeoclaw.desktop:/usr/share/applications/@nuwax-ainuwaclaw.desktop
      - ./desktop/terminal.desktop:/usr/share/applications/user-terminal.desktop
      - ./desktop/vscode.desktop:/usr/share/applications/user-vscode.desktop
      - ./desktop/chromium.desktop:/usr/share/applications/chromium-browser.desktop
      - ./icons/@nuwax-ainuwaclaw.png:/usr/share/icons/hicolor/512x512/apps/@nuwax-ainuwaclaw.png
      - ./wallpaper/gogeoDesk.jpg:/usr/share/backgrounds/xfce/wallpaper.jpeg

    environment:
      - TZ=Asia/Shanghai
      - NUWAX_SERVER_HOST=https://agentos.topprismdata.com/claw-api
      - NUWAX_AGENT_PORT=60006
      - NUWAX_FILE_SERVER_PORT=60005
      - NUWAX_WORKSPACE_DIR=/home/user/nuwaxbot/workspace
      - NUWAX_SAVED_KEY={key}

volumes:
  agentos_home:
"""

    content = compose_template.format(
        image=IMAGE_NAME,
        container_name=CONTAINER_NAME,
        key=key,
    )

    compose_file.write_text(content)
    info(f"已生成 docker-compose.yml: {compose_file}")

    # 创建目录结构
    for d in ["app", "desktop", "icons", "wallpaper"]:
        (config_dir / d).mkdir(exist_ok=True)
    info("目录结构已创建")


# ============================================================
# Commands
# ============================================================

def cmd_start():
    compose = compose_command()
    if not compose:
        error("未找到 docker compose")
        sys.exit(1)

    compose_file = get_compose_file()
    if not compose_file.exists():
        warn("未找到配置，请先运行: agentos setup")
        sys.exit(1)

    info("启动 AgentOS Client...")
    run_cmd(compose + ["-f", str(compose_file), "up", "-d"])

    print()
    info("容器已启动")
    print()
    print("  访问地址: http://localhost:6080")
    print()


def cmd_stop():
    compose = compose_command()
    if not compose:
        error("未找到 docker compose")
        sys.exit(1)

    compose_file = get_compose_file()
    if not compose_file.exists():
        warn("未找到配置")
        sys.exit(1)

    info("停止 AgentOS Client...")
    run_cmd(compose + ["-f", str(compose_file), "down"])
    info("容器已停止")


def cmd_restart():
    cmd_stop()
    print()
    cmd_start()


def cmd_status():
    result = subprocess.run(
        ["docker", "ps", "-a", "--filter", f"name={CONTAINER_NAME}",
         "--format", "table {{.Names}}\t{{.Status}}\t{{.Ports}}"],
        capture_output=True, text=True
    )
    print(result.stdout)

    if CONTAINER_NAME not in result.stdout:
        warn("容器不存在，请先运行: agentos setup")


def cmd_logs():
    result = subprocess.run(
        ["docker", "logs", "--tail", "50", CONTAINER_NAME],
        capture_output=True, text=True
    )
    print(result.stdout)
    print(result.stderr)


def cmd_update_key(new_key):
    """更新 key"""
    save_saved_key(new_key)

    compose_file = get_compose_file()
    if compose_file.exists():
        content = compose_file.read_text()
        content = content.replace(
            "NUWAX_SAVED_KEY=",
            f"NUWAX_SAVED_KEY={new_key}"
        )
        compose_file.write_text(content)
        info("已更新 docker-compose.yml 中的 key")

    info("如需生效，请运行: agentos restart")


def cmd_redeploy():
    """重新部署（删除旧配置重新生成）"""
    compose_file = get_compose_file()
    if compose_file.exists():
        compose_file.unlink()
        info("已删除旧配置")

    key = get_saved_key()
    if key:
        setup(key=key, force=True)
    else:
        warn("未找到已保存的 key，请先运行: agentos setup")
        sys.exit(1)


# ============================================================
# CLI
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        prog="agentos",
        description="AgentOS Client Docker 容器管理工具",
    )
    parser.add_argument(
        "--version", action="version", version=f"agentos {VERSION}"
    )

    subparsers = parser.add_subparsers(dest="command", help="命令")

    # setup
    p_setup = subparsers.add_parser("setup", help="首次安装/设置")
    p_setup.add_argument("--key", help="NUWAX_SAVED_KEY")
    p_setup.add_argument("--force", action="store_true", help="强制重新生成配置")

    # start
    subparsers.add_parser("start", help="启动容器")

    # stop
    subparsers.add_parser("stop", help="停止容器")

    # restart
    subparsers.add_parser("restart", help="重启容器")

    # status
    subparsers.add_parser("status", help="查看容器状态")

    # logs
    subparsers.add_parser("logs", help="查看容器日志")

    # update-key
    p_key = subparsers.add_parser("update-key", help="更新 NUWAX_SAVED_KEY")
    p_key.add_argument("key", help="新的 key")

    # redeploy
    subparsers.add_parser("redeploy", help="重新部署（重新生成配置并重启）")

    args = parser.parse_args()

    if args.command == "setup":
        setup(key=args.key, force=args.force)
    elif args.command == "start":
        cmd_start()
    elif args.command == "stop":
        cmd_stop()
    elif args.command == "restart":
        cmd_restart()
    elif args.command == "status":
        cmd_status()
    elif args.command == "logs":
        cmd_logs()
    elif args.command == "update-key":
        cmd_update_key(args.key)
    elif args.command == "redeploy":
        cmd_redeploy()
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
