"""Extras route handlers for NetBox custom field management."""

import asyncio
from typing import Annotated

from fastapi import APIRouter, Depends

from proxbox_api.exception import ProxboxException
from proxbox_api.logger import logger
from proxbox_api.netbox_rest import rest_first_async, rest_reconcile_async
from proxbox_api.proxmox_to_netbox.models import NetBoxCustomFieldSyncState
from proxbox_api.runtime_settings import get_float
from proxbox_api.session.netbox import NetBoxAsyncSessionDep
from proxbox_api.utils.retry import is_netbox_overwhelmed_error

router = APIRouter()
_CUSTOM_FIELDS_CACHE: tuple[dict[str, object], ...] | None = None
_CUSTOM_FIELDS_LOCK = asyncio.Lock()


def _coerce_object_type_entry(item: object) -> str | None:
    if isinstance(item, str):
        return item
    if isinstance(item, dict):
        if "app_label" in item and "model" in item:
            return f"{item['app_label']}.{item['model']}"
        name = item.get("name")
        if isinstance(name, str):
            return name
    return None


def _normalize_current_object_types(raw_current: object) -> list[str]:
    if not isinstance(raw_current, list):
        return []
    normalized: list[str] = []
    for item in raw_current:
        coerced = _coerce_object_type_entry(item)
        if coerced is not None:
            normalized.append(coerced)
    return normalized


async def _fetch_existing_custom_field(netbox_session: object, name: str) -> object | None:
    try:
        return await rest_first_async(
            netbox_session,
            "/api/extras/custom-fields/",
            query={"name": name, "limit": 2},
        )
    except Exception as exc:
        logger.warning(
            "Could not pre-fetch custom field '%s' for object_types union: %s",
            name,
            exc,
        )
        return None


async def _union_object_types_with_current(
    netbox_session: object,
    custom_field: dict[str, object],
) -> None:
    """Mutate ``custom_field['object_types']`` to be (current ∪ desired).

    NetBox custom fields have an ``object_types`` list that operators sometimes
    expand manually. Without this merge, ``rest_reconcile_async`` would PATCH
    the field back to the hardcoded list on every restart, wiping operator
    additions. Pre-merging makes desired a superset of current so the diff
    only adds entries — never removes them.
    """
    desired = custom_field.get("object_types")
    name = custom_field.get("name")
    if not isinstance(desired, list) or not name:
        return
    existing = await _fetch_existing_custom_field(netbox_session, name)
    if existing is None:
        return
    current = _normalize_current_object_types(existing.serialize().get("object_types"))
    union = list(dict.fromkeys([*desired, *current]))
    operator_added = [item for item in union if item not in desired]
    if operator_added:
        logger.info(
            "Preserving operator-added object_types for custom field '%s': %s",
            name,
            ", ".join(operator_added),
        )
    custom_field["object_types"] = union


def _resolve_custom_field_delay() -> float:
    return get_float(
        settings_key="custom_fields_request_delay",
        env="PROXBOX_CUSTOM_FIELDS_REQUEST_DELAY",
        default=0.0,
        minimum=0.0,
    )


@router.get(
    "/extras/custom-fields/create",
    response_model=list[dict[str, object]],
    response_model_exclude_none=True,
    response_model_exclude_unset=True,
)
async def create_custom_fields(  # noqa: C901
    netbox_session: NetBoxAsyncSessionDep,
) -> list[dict]:
    """Create custom fields in NetBox for Proxmox synchronization."""
    global _CUSTOM_FIELDS_CACHE
    if _CUSTOM_FIELDS_CACHE is not None:
        return [dict(field) for field in _CUSTOM_FIELDS_CACHE]

    async with _CUSTOM_FIELDS_LOCK:
        if _CUSTOM_FIELDS_CACHE is not None:
            return [dict(field) for field in _CUSTOM_FIELDS_CACHE]
        custom_fields: list = [
            {
                "object_types": ["virtualization.virtualmachine"],
                "type": "integer",
                "name": "proxmox_vm_id",
                "label": "VM ID",
                "description": "Proxmox Virtual Machine or Container ID",
                "ui_visible": "always",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": ["virtualization.virtualmachine"],
                "type": "text",
                "name": "proxmox_vm_type",
                "label": "VM Type",
                "description": "Proxmox VM type (qemu or lxc)",
                "ui_visible": "always",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": ["virtualization.virtualmachine"],
                "type": "boolean",
                "name": "proxmox_start_at_boot",
                "label": "Start at Boot",
                "description": "Proxmox Start at Boot Option",
                "ui_visible": "always",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": ["virtualization.virtualmachine"],
                "type": "boolean",
                "name": "proxmox_unprivileged_container",
                "label": "Unprivileged Container",
                "description": "Proxmox Unprivileged Container",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": ["virtualization.virtualmachine"],
                "type": "boolean",
                "name": "proxmox_qemu_agent",
                "label": "QEMU Guest Agent",
                "description": "Proxmox QEMU Guest Agent",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": ["virtualization.virtualmachine"],
                "type": "text",
                "name": "proxmox_search_domain",
                "label": "Search Domain",
                "description": "Proxmox Search Domain",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": [
                    "dcim.device",
                    "virtualization.virtualmachine",
                ],
                "type": "url",
                "name": "proxmox_link",
                "label": "Proxmox Link",
                "description": "Link to Proxmox web interface",
                "ui_visible": "always",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": [
                    "dcim.device",
                    "virtualization.virtualmachine",
                ],
                "type": "text",
                "name": "proxmox_node",
                "label": "Proxmox Node",
                "description": "Proxmox node hosting this device/VM",
                "ui_visible": "always",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": [
                    "dcim.device",
                    "virtualization.virtualmachine",
                ],
                "type": "text",
                "name": "proxmox_cluster",
                "label": "Proxmox Cluster",
                "description": "Proxmox cluster name",
                "ui_visible": "always",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": ["virtualization.virtualmachine"],
                "type": "text",
                "name": "proxmox_status",
                "label": "Proxmox Status",
                "description": "Current status in Proxmox",
                "ui_visible": "always",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": ["virtualization.virtualmachine"],
                "type": "integer",
                "name": "proxmox_uptime",
                "label": "Uptime (seconds)",
                "description": "VM uptime in seconds",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": [
                    "dcim.device",
                    "virtualization.virtualmachine",
                ],
                "type": "text",
                "name": "proxmox_tags",
                "label": "Proxmox Tags",
                "description": "Comma-separated tags from Proxmox",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": [
                    "dcim.device",
                    "virtualization.virtualmachine",
                ],
                "type": "text",
                "name": "proxmox_os",
                "label": "Operating System",
                "description": "Operating system from Proxmox",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": [
                    "dcim.device",
                    "virtualization.virtualmachine",
                ],
                "type": "text",
                "name": "proxmox_storage",
                "label": "Storage",
                "description": "Storage disk size",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": [
                    "dcim.device",
                    "virtualization.virtualmachine",
                ],
                "type": "text",
                "name": "proxmox_disk",
                "label": "Disk (GB)",
                "description": "Total disk size in GB",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": [
                    "dcim.device",
                    "virtualization.virtualmachine",
                ],
                "type": "text",
                "name": "proxmox_interfaces",
                "label": "Network Interfaces",
                "description": "Network interface count",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": ["ipam.ipaddress"],
                "type": "text",
                "name": "proxmox_interface",
                "label": "Proxmox Interface",
                "description": "Proxmox network interface name",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": [
                    "dcim.device",
                    "virtualization.virtualmachine",
                ],
                "type": "text",
                "name": "proxmox_vmid",
                "label": "Proxmox VMID",
                "description": "VM ID for reference",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": ["ipam.ipaddress"],
                "type": "text",
                "name": "proxmox_mac",
                "label": "Proxmox MAC",
                "description": "MAC address from Proxmox",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": [
                    "dcim.device",
                    "virtualization.virtualmachine",
                ],
                "type": "text",
                "name": "proxmox_notes",
                "label": "Proxmox Notes",
                "description": "Notes from Proxmox",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": ["ipam.vlan"],
                "type": "integer",
                "name": "proxmox_vlan_id",
                "label": "Proxmox VLAN ID",
                "description": "VLAN ID from Proxmox",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": [
                    "virtualization.cluster",
                    "virtualization.clustergroup",
                ],
                "type": "text",
                "name": "proxmox_cluster_name",
                "label": "Cluster Name",
                "description": "Cluster name from Proxmox",
                "ui_visible": "always",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": [
                    "virtualization.cluster",
                    "virtualization.clustergroup",
                ],
                "type": "text",
                "name": "proxmox_cluster_status",
                "label": "Cluster Status",
                "description": "Cluster status from Proxmox",
                "ui_visible": "always",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": [
                    "dcim.device",
                    "virtualization.virtualmachine",
                ],
                "type": "text",
                "name": "proxmox_tcp_states",
                "label": "TCP States",
                "description": "TCP connection states",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": [
                    "dcim.device",
                    "virtualization.virtualmachine",
                ],
                "type": "text",
                "name": "proxmox_cpu_type",
                "label": "CPU Type",
                "description": "CPU type from Proxmox",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": ["ipam.ipaddress"],
                "type": "text",
                "name": "proxmox_ip_addresses",
                "label": "IP Addresses",
                "description": "All IP addresses from Proxmox",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": [
                    "virtualization.cluster",
                ],
                "type": "integer",
                "name": "proxmox_cluster_id",
                "label": "Cluster ID",
                "description": "Proxmox cluster ID",
                "ui_visible": "always",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": [
                    "dcim.device",
                    "virtualization.virtualmachine",
                ],
                "type": "text",
                "name": "proxmox_storage_ids",
                "label": "Storage IDs",
                "description": "Comma-separated storage IDs",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": [
                    "dcim.device",
                    "virtualization.virtualmachine",
                ],
                "type": "text",
                "name": "proxmox_storage_names",
                "label": "Storage Names",
                "description": "Comma-separated storage names",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": [
                    "dcim.device",
                    "virtualization.virtualmachine",
                ],
                "type": "text",
                "name": "proxmox_device_names",
                "label": "Device Names",
                "description": "Comma-separated device names",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": ["virtualization.virtualmachine"],
                "type": "integer",
                "name": "proxmox_migration_duration",
                "label": "Migration Duration",
                "description": "Migration duration in seconds",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": ["virtualization.virtualmachine"],
                "type": "text",
                "name": "proxmox_migration_type",
                "label": "Migration Type",
                "description": "Migration type (live / offline)",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": ["virtualization.virtualdisk"],
                "type": "object",
                "name": "proxbox_storage_id",
                "label": "Proxbox Storage",
                "related_object_type": "netbox_proxbox.proxmoxstorage",
                "description": "Proxmox storage hosting this virtual disk",
                "ui_visible": "always",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": ["virtualization.vminterface"],
                "type": "object",
                "name": "proxbox_bridge",
                "label": "Proxbox Bridge",
                "related_object_type": "dcim.interface",
                "description": "Node-level bridge interface (vmbr) used by this VM interface",
                "ui_visible": "always",
                "ui_editable": "hidden",
                "weight": 100,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": [
                    "dcim.device",
                    "dcim.devicerole",
                    "dcim.devicetype",
                    "dcim.interface",
                    "dcim.manufacturer",
                    "dcim.site",
                    "ipam.ipaddress",
                    "ipam.vlan",
                    "virtualization.cluster",
                    "virtualization.clustertype",
                    "virtualization.virtualdisk",
                    "virtualization.virtualmachine",
                    "virtualization.vminterface",
                ],
                "type": "datetime",
                "name": "proxmox_last_updated",
                "label": "Last Updated",
                "description": "Proxmox Plugin last modified this object",
                "ui_visible": "always",
                "ui_editable": "hidden",
                "weight": 200,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": [
                    "dcim.device",
                    "virtualization.cluster",
                    "virtualization.virtualmachine",
                ],
                "type": "text",
                "name": "proxbox_last_run_id",
                "label": "Last Run ID",
                "description": "UUID of the most recent Proxbox sync run that touched this object.",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 250,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxbox",
            },
            {
                "object_types": ["dcim.device"],
                "type": "text",
                "name": "hardware_chassis_serial",
                "label": "Chassis Serial",
                "description": "Chassis serial reported by dmidecode -t 3",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 300,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": ["dcim.device"],
                "type": "text",
                "name": "hardware_chassis_manufacturer",
                "label": "Chassis Manufacturer",
                "description": "Chassis manufacturer reported by dmidecode -t 3",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 300,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": ["dcim.device"],
                "type": "text",
                "name": "hardware_chassis_product",
                "label": "Chassis Product",
                "description": "System product name reported by dmidecode -t 1",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 300,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": ["dcim.interface"],
                "type": "integer",
                "name": "nic_speed_gbps",
                "label": "NIC Speed (Gbps)",
                "description": "Negotiated link speed reported by ethtool, in Gbps",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 300,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": ["dcim.interface"],
                "type": "text",
                "name": "nic_duplex",
                "label": "NIC Duplex",
                "description": "Duplex mode reported by ethtool",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 300,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
            {
                "object_types": ["dcim.interface"],
                "type": "boolean",
                "name": "nic_link",
                "label": "NIC Link Up",
                "description": "Link-detected status reported by ethtool",
                "ui_visible": "if-set",
                "ui_editable": "hidden",
                "weight": 300,
                "filter_logic": "loose",
                "search_weight": 1000,
                "group_name": "Proxmox",
            },
        ]
        fields = []
        had_failures = False
        overloaded = False
        failed_fields: list[dict[str, str]] = []
        request_delay = _resolve_custom_field_delay()

        for custom_field in custom_fields:
            try:
                await _union_object_types_with_current(netbox_session, custom_field)
                record = await rest_reconcile_async(
                    netbox_session,
                    "/api/extras/custom-fields/",
                    lookup={"name": custom_field["name"]},
                    payload=custom_field,
                    schema=NetBoxCustomFieldSyncState,
                    current_normalizer=lambda record: {
                        "name": record.get("name"),
                        "type": record.get("type"),
                        "label": record.get("label"),
                        "description": record.get("description"),
                        "ui_visible": record.get("ui_visible"),
                        "ui_editable": record.get("ui_editable"),
                        "weight": record.get("weight"),
                        "filter_logic": record.get("filter_logic"),
                        "search_weight": record.get("search_weight"),
                        "group_name": record.get("group_name"),
                        "object_types": record.get("object_types"),
                        "related_object_type": record.get("related_object_type"),
                    },
                )
                fields.append(record.serialize())
            except ProxboxException as e:
                had_failures = True
                failed_fields.append(
                    {
                        "name": str(custom_field.get("name", "unknown")),
                        "error": str(e.message),
                    }
                )
                overloaded = overloaded or is_netbox_overwhelmed_error(e)
                logger.warning(
                    "Failed to create/update custom field '%s': %s - %s",
                    custom_field.get("name", "unknown"),
                    e.message,
                    e.detail,
                )
                if overloaded:
                    break
            except Exception as e:
                had_failures = True
                failed_fields.append(
                    {
                        "name": str(custom_field.get("name", "unknown")),
                        "error": str(e),
                    }
                )
                overloaded = overloaded or is_netbox_overwhelmed_error(e)
                logger.warning(
                    "Failed to create/update custom field '%s': %s",
                    custom_field.get("name", "unknown"),
                    str(e),
                )
                if overloaded:
                    break

            if request_delay > 0:
                await asyncio.sleep(request_delay)

        if had_failures:
            if overloaded:
                raise ProxboxException(
                    message="NetBox is overwhelmed. Please retry this action in a few moments.",
                    detail={
                        "reason": "netbox_overwhelmed",
                        "created_count": len(fields),
                        "failed_fields": failed_fields,
                    },
                )

            raise ProxboxException(
                message="Failed to create all NetBox custom fields.",
                detail={
                    "reason": "custom_field_sync_failed",
                    "created_count": len(fields),
                    "failed_fields": failed_fields,
                },
            )

        _CUSTOM_FIELDS_CACHE = tuple(dict(field) for field in fields)
        return fields


CreateCustomFieldsDep = Annotated[list[dict], Depends(create_custom_fields)]
