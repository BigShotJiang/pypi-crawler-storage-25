import os


def reach_api_bearer_header() -> str:
    """Bearer token shared across reach internal APIs (callback / event / ops / data-bridge).

    Reads from `lambda_function_api_key` env var — the canonical name matching SSM
    `/api-keys/{env}/lambda-function-api-key`. Consumer lambdas must inject this var
    (via their serverless.yml + /terraform .lambda.tf, or infra/env.tf if puller-style).
    Empty when unset → produces `Bearer ` and downstream APIs answer 401.
    """
    token = os.environ.get("lambda_function_api_key", "")
    return f"Bearer {token}"
