import os
from typing import Optional

import requests


class OutscraperClient:
    def __init__(self, token=None, webhook_url=None):
        self.environment = os.environ.get("ENV", "Staging")
        self.base_url = "https://api.outscraper.cloud"
        self.token = token or os.environ.get("outscraper_token", "")
        self.webhook_url = webhook_url or os.environ.get("outscraper_webhook_url", "")

    @property
    def headers(self):
        common_headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

        return {**common_headers, "X-API-KEY": self.token}

    def search_google_maps_reviews(
        self,
        google_place_id: str,
        last_pagination_id: Optional[str] = None,
        start_ts: Optional[int] = None,
        cutoff_ts: Optional[int] = None,
        reviews_limit: int = 0,
    ):
        if not reviews_limit or reviews_limit < 0:
            reviews_limit = 0
        if reviews_limit > 10000:
            reviews_limit = 10000

        params = {
            "query": google_place_id,
            "webhook": self.webhook_url,
            "reviewsLimit": reviews_limit,
            "sort": "newest",
        }

        if last_pagination_id:
            params["lastPaginationId"] = last_pagination_id

        if start_ts is not None:
            params["start"] = start_ts

        if cutoff_ts is not None:
            params["cutoff"] = cutoff_ts

        return requests.get(
            f"{self.base_url}/google-maps-reviews", headers=self.headers, params=params
        )

    def get_job_details(self, job_id: str):
        """Perform a GET request to retrieve details for a specific job using its job_id."""
        url = f"{self.base_url}/requests/{job_id}"
        response = requests.get(url, headers=self.headers)
        return response

    def get_balance(self):
        url = f"{self.base_url}/profile/balance"
        response = requests.get(url, headers=self.headers)
        return response
