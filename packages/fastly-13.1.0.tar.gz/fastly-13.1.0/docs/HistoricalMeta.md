# HistoricalMeta

Meta information about the scope of the query in a human readable format.

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**to** | **str** |  | [optional] 
**_from** | **str** |  | [optional] 
**by** | **str** |  | [optional] 
**region** | **str** |  | [optional] 
**datacenter** | **str** |  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


