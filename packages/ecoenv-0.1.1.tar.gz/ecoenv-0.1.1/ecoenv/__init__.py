from .env_request import get_environment_data, autenticateEE, clear_cache

__all__ = [
    "get_environment_data",
    "autenticateEE",
    "clear_cache",
]


def version() -> str:
    return "0.1.0"


def describe() -> str:
    description = (
        "Eco Env Library\n"
        f"Version: {version()}\n"
        "Implement functions to get environment data from GEE as:\n"
        " - get_environment_data\n"
        " - autenticateEE\n"
        " - clear_cache\n"
    )
    print(description)
    return description