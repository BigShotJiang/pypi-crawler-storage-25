from tomoscan.tests.datasets import GitlabProject
from platformdirs import PlatformDirs

_dirs = PlatformDirs("nxtomomill")

GitlabDataset = GitlabProject(
    branch_name="nxtomomill",
    host="https://gitlab.esrf.fr",
    cache_dir=_dirs.user_cache_dir,
    token=None,
    project_id=4299,  # https://gitlab.esrf.fr/tomotools/ci_datasets
)
