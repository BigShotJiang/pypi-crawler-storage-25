from __future__ import annotations

import h5py
from silx.io.utils import h5py_read_dataset

__all__ = [
    "BlissActiveConfig",
]


class BlissActiveConfig:
    """
    hold the bliss active config. Can retrieve the 'tomo_detector' that contains information about the optic
    """

    def __init__(self) -> None:
        self._tomo_detector: None | tuple[str, ...] = None

    @property
    def tomo_detector(self) -> tuple[str, ...] | None:
        return self._tomo_detector

    @staticmethod
    def from_hdf5_group(group: h5py.Group):
        """
        Create an instance of 'BlissActiveConfig' from a group (containing the bliss active configuration).
        """
        if not isinstance(group, h5py.Group):
            raise TypeError

        bliss_config = BlissActiveConfig()
        if "tomo_detector" in group:
            bliss_config._tomo_detector = h5py_read_dataset(group["tomo_detector"])
        return bliss_config
