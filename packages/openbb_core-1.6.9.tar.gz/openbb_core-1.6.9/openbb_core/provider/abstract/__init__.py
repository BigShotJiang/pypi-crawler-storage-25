"""OpenBB Provider Abstract Class."""
