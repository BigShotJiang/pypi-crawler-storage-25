"""
SPDX-License-Identifier: AGPL-3.0-or-later
SPDX-FileCopyrightText: Copyright (C) 2026 pyTax4Fun2 contributors
pyTax4Fun2 - Python implementation of Tax4Fun2 for functional profiling of microbial communities.
See LICENSE for full license details.

Install dependencies for Tax4Fun2 Python implementation.
"""

import os
import sys
import subprocess
import shutil
import tarfile
import zipfile
import platform
import tempfile
from pathlib import Path
from typing import Optional
import warnings

import requests
from tqdm import tqdm

from .utils import (
    validate_directory, download_with_checksum, 
    run_command, pyTax4Fun2Error, calculate_md5, TOOL_VERSIONS, DEFAULT_CONFIG
)


def check_blast_installation(blast_bin_dir: Path) -> bool:
    """
    Verify BLAST installation.
    
    Args:
        blast_bin_dir: Path to BLAST bin directory
        
    Returns:
        bool: True if BLAST is working
    """
    system = platform.system().lower()
    blast_binary = blast_bin_dir / "bin" / "blastn"
    
    if system == "windows":
        blast_binary = blast_binary.with_suffix(".exe")
    
    if not blast_binary.exists():
        # Check for alternative names
        blast_candidates = list((blast_bin_dir / "bin").glob("blastn*"))
        if not blast_candidates:
            return False
        blast_binary = blast_candidates[0]
    
    try:
        result = subprocess.run(
            [str(blast_binary), "-version"],
            capture_output=True,
            text=True,
            timeout=5,
            shell=False  # Explicitly set shell=False for security
        )
        return result.returncode == 0 and "blastn" in result.stdout.lower()
    except Exception:
        return False


def build_dependencies(
    path_to_reference_data: str = "pyTax4Fun2_ReferenceData",
    install_suggested_packages: bool = True,
    use_force: bool = False,
    blast_version: Optional[str] = None  # Made optional
) -> bool:
    """
    Install dependencies for Tax4Fun2.
    
    Args:
        path_to_reference_data: Path to reference data directory
        install_suggested_packages: Install required Python packages
        use_force: Overwrite existing installation
        blast_version: BLAST+ version to download (None for default)
        
    Returns:
        bool: True if successful
        
    Raises:
        pyTax4Fun2Error: If installation fails
    """
    print("Installing Tax4Fun2 dependencies")
    
    # Use default version if not specified
    if blast_version is None:
        blast_version = TOOL_VERSIONS.get("blast", "2.14.0+")
    
    # Validate reference data directory
    ref_path = Path(path_to_reference_data)
    validate_directory(ref_path, "Reference data directory")
    
    # Check required subdirectories
    required_dirs = ["KEGG", "Ref100NR", "Ref99NR", "SILVA", "TOOLS"]
    for d in required_dirs:
        dir_path = ref_path / d
        if not dir_path.exists():
            warnings.warn(f"Missing directory in reference data: {d}")
    
    # Check for existing BLAST installation
    blast_bin_dir = ref_path / "blast_bin"
    if blast_bin_dir.exists():
        if use_force:
            print("Removing existing BLAST installation...")
            shutil.rmtree(blast_bin_dir)
        else:
            raise pyTax4Fun2Error(
                "BLAST binary folder already exists. Use use_force=True to overwrite."
            )
    
    # Install Python packages if requested
    if install_suggested_packages:
        print("Installing required Python packages...")
        required_packages = [
            "polars>=0.20.0",
            "numpy>=1.21.0",
            "biopython>=1.79",
            "requests>=2.28.0",
            "tqdm>=4.64.0",
            "psutil>=5.9.0",
            "scipy>=1.9.0",
        ]
        
        for pkg in required_packages:
            try:
                print(f"  Installing {pkg}...")
                subprocess.check_call([
                    sys.executable, "-m", "pip", "install", pkg
                ], shell=False)
            except subprocess.CalledProcessError as e:
                warnings.warn(f"Failed to install {pkg}: {str(e)}")
        
        print("Python packages installed successfully")
    
    # Determine BLAST download URL based on OS and architecture
    system = platform.system().lower()
    machine = platform.machine().lower()
    
    # Map system names
    if system == "windows":
        os_name = "win64"
        archive_ext = ".tar.gz"
    elif system == "darwin":
        os_name = "macosx"
        archive_ext = ".tar.gz"
    elif system == "linux":
        os_name = "linux"
        archive_ext = ".tar.gz"
    else:
        raise pyTax4Fun2Error(f"Unsupported operating system: {system}")
    
    # Check architecture
    if "64" in machine or "x86_64" in machine or "amd64" in machine:
        arch = "x64"
    elif "arm" in machine or "aarch64" in machine:
        arch = "aarch64"
    else:
        arch = "x64"  # Default assumption
    
    # Try multiple BLAST URL patterns
    base_urls = [
        "https://ftp.ncbi.nlm.nih.gov/blast/executables/blast+/LATEST",
        f"https://ftp.ncbi.nlm.nih.gov/blast/executables/blast+/{blast_version}"
    ]
    
    # Try to find working URL
    blast_url = None
    for base_url in base_urls:
        if system == "windows":
            filename = f"ncbi-blast-{blast_version}-{arch}-{os_name}{archive_ext}"
        else:
            filename = f"ncbi-blast-{blast_version}-{arch}-{os_name}{archive_ext}"
        
        test_url = f"{base_url}/{filename}"
        
        print(f"Testing URL: {test_url}")
        try:
            response = requests.head(test_url, timeout=10)
            if response.status_code == 200:
                blast_url = test_url
                break
        except:
            continue
    
    if not blast_url:
        # Try generic URL
        if system == "windows":
            blast_url = f"https://ftp.ncbi.nlm.nih.gov/blast/executables/blast+/LATEST/ncbi-blast-{blast_version}-{arch}-{os_name}{archive_ext}"
        else:
            blast_url = f"https://ftp.ncbi.nlm.nih.gov/blast/executables/blast+/LATEST/ncbi-blast-{blast_version}-{arch}-{os_name}{archive_ext}"
    
    print(f"Downloading BLAST+ version {blast_version}...")
    
    try:
        # Download BLAST+
        download_file = ref_path / "ncbi-blast.tar.gz"
        
        print(f"Downloading from: {blast_url}")
        
        # Download with progress bar
        try:
            download_with_checksum(
                url=blast_url,
                destfile=download_file,
                expected_md5=None,  # Can't verify MD5 for latest
                show_progress=True
            )
        except Exception as download_error:
            warnings.warn(f"Download failed: {str(download_error)}")
            print("Please download BLAST manually from: https://blast.ncbi.nlm.nih.gov/Blast.cgi?CMD=Web&PAGE_TYPE=BlastDocs&DOC_TYPE=Download")
            return False
        
        # Extract BLAST+
        print("Extracting BLAST+...")
        
        # Create temporary directory for extraction
        temp_dir = ref_path / "blast_temp"
        temp_dir.mkdir(exist_ok=True)
        
        # Extract tar.gz
        try:
            with tarfile.open(download_file, "r:gz") as tar:
                tar.extractall(path=temp_dir)
        except Exception as e:
            # Try with different compression
            try:
                with tarfile.open(download_file, "r:*") as tar:
                    tar.extractall(path=temp_dir)
            except Exception as e2:
                raise pyTax4Fun2Error(f"Failed to extract archive: {str(e2)}")
        
        # Find the extracted directory
        extracted_dirs = list(temp_dir.glob("ncbi-blast-*"))
        if not extracted_dirs:
            # Try alternative pattern
            extracted_dirs = list(temp_dir.glob("*"))
        
        if not extracted_dirs:
            raise pyTax4Fun2Error("Could not find BLAST directory in archive")
        
        blast_source_dir = extracted_dirs[0]
        
        # Move to final location
        shutil.move(str(blast_source_dir), str(blast_bin_dir))
        
        # Clean up
        shutil.rmtree(temp_dir)
        if download_file.exists():
            download_file.unlink()
        
        # Test BLAST installation
        print("Testing BLAST installation...")
        success = check_blast_installation(blast_bin_dir)  # Now this function is defined!
        
        if success:
            print("✅ BLAST+ installation successful")
        else:
            warnings.warn("BLAST installation may have issues")
        
        # Install other tools if missing
        install_additional_tools(ref_path, use_force)
        
        return True
        
    except Exception as e:
        # Clean up on error
        if download_file.exists():
            download_file.unlink()
        if temp_dir.exists():
            shutil.rmtree(temp_dir)
        if blast_bin_dir.exists():
            shutil.rmtree(blast_bin_dir)
        raise pyTax4Fun2Error(f"Failed to install BLAST+: {str(e)}")


def install_additional_tools(
    ref_path: Path,
    use_force: bool = False
) -> None:
    """
    Install additional tools (DIAMOND, Prodigal, VSEARCH) if not present.
    
    Args:
        ref_path: Path to reference data directory
        use_force: Overwrite existing installations
    """
    tools_dir = ref_path / "TOOLS"
    
    # Check and install DIAMOND
    diamond_dir = tools_dir / f"diamond_v{TOOL_VERSIONS['diamond']}"
    if not diamond_dir.exists() or use_force:
        print("DIAMOND not found. Please download and install manually:")
        print("  https://github.com/bbuchfink/diamond/releases")
        print(f"  Place diamond executable in: {diamond_dir}")
    
    # Check and install Prodigal
    prodigal_dir = tools_dir / f"prodigal_v{TOOL_VERSIONS['prodigal']}"
    if not prodigal_dir.exists() or use_force:
        print("Prodigal not found. Please download and install manually:")
        print("  https://github.com/hyattpd/Prodigal")
        print(f"  Place prodigal executable in: {prodigal_dir}")
    
    # Check and install VSEARCH
    vsearch_dir = tools_dir / f"vsearch_v{TOOL_VERSIONS['vsearch']}"
    if not vsearch_dir.exists() or use_force:
        print("VSEARCH not found. Please download and install manually:")
        print("  https://github.com/torognes/vsearch")
        print(f"  Place vsearch executable in: {vsearch_dir}")
    
    # Check system PATH for tools
    check_system_tools()


def check_system_tools() -> None:
    """
    Check if required tools are available in system PATH.
    """
    required_tools = ["diamond", "prodigal", "vsearch", "blastn", "makeblastdb"]
    
    print("\nChecking for tools in system PATH:")
    
    for tool in required_tools:
        try:
            if platform.system() == "Windows":
                result = subprocess.run(
                    ["where", tool],
                    capture_output=True,
                    text=True,
                    shell=False
                )
            else:
                result = subprocess.run(
                    ["which", tool],
                    capture_output=True,
                    text=True,
                    shell=False
                )
            
            if result.returncode == 0:
                location = result.stdout.strip().split('\n')[0]
                print(f"  ✅ {tool}: Found at {location}")
            else:
                print(f"  ❌ {tool}: Not found in PATH")
        except Exception as e:
            print(f"  ❌ {tool}: Error checking: {str(e)}")


# Remove the duplicate check_blast_installation function from the bottom of the file
# since we've already defined it at the top

def install_python_packages(package_list: list) -> None:
    """
    Install Python packages.
    
    Args:
        package_list: List of package names/versions
    """
    for pkg in package_list:
        try:
            print(f"Installing {pkg}...")
            subprocess.check_call([
                sys.executable, "-m", "pip", "install", pkg
            ], shell=False)
        except subprocess.CalledProcessError as e:
            warnings.warn(f"Failed to install {pkg}: {str(e)}")
            # Try without version specifier
            pkg_name = pkg.split(">=")[0].split("==")[0].strip()
            try:
                subprocess.check_call([
                    sys.executable, "-m", "pip", "install", pkg_name
                ], shell=False)
            except:
                print(f"Warning: Could not install {pkg_name}")


def setup_environment() -> None:
    """
    Setup environment variables for Tax4Fun2.
    """
    # Add current directory to PATH for tools
    current_dir = str(Path.cwd())
    
    if platform.system() == "Windows":
        path_var = os.environ.get("PATH", "")
        if current_dir not in path_var:
            os.environ["PATH"] = f"{current_dir};{path_var}"
    else:
        path_var = os.environ.get("PATH", "")
        if current_dir not in path_var:
            os.environ["PATH"] = f"{current_dir}:{path_var}"
    
    # Set TMPDIR for compatibility
    os.environ["TMPDIR"] = str(Path(tempfile.gettempdir()))
    
    print("Environment setup complete")


def verify_installation(path_to_reference_data: str) -> dict:
    """
    Verify all dependencies are installed correctly.
    
    Args:
        path_to_reference_data: Path to reference data directory
        
    Returns:
        dict: Installation status for each component
    """
    ref_path = Path(path_to_reference_data)
    
    status = {
        "blast": False,
        "diamond": False,
        "prodigal": False,
        "vsearch": False,
        "python_packages": False,
        "reference_data": False,
    }
    
    # Check BLAST
    blast_bin_dir = ref_path / "blast_bin"
    if blast_bin_dir.exists():
        status["blast"] = check_blast_installation(blast_bin_dir)
    
    # Check other tools
    tools_to_check = [
        ("diamond", ref_path / "TOOLS" / f"diamond_v{TOOL_VERSIONS['diamond']}"),
        ("prodigal", ref_path / "TOOLS" / f"prodigal_v{TOOL_VERSIONS['prodigal']}"),
        ("vsearch", ref_path / "TOOLS" / f"vsearch_v{TOOL_VERSIONS['vsearch']}"),
    ]
    
    for tool_name, tool_path in tools_to_check:
        # Check in reference directory
        if tool_path.exists():
            # Look for executable
            if platform.system() == "Windows":
                exe_pattern = f"{tool_name}.exe"
            elif platform.system() == "Darwin":
                exe_pattern = f"{tool_name}.macos"
            else:
                exe_pattern = f"{tool_name}.linux"
            
            exe_files = list(tool_path.glob(exe_pattern))
            if exe_files:
                status[tool_name] = True
        else:
            # Check system PATH
            try:
                if platform.system() == "Windows":
                    subprocess.run(["where", tool_name], 
                                 capture_output=True, check=True, shell=False)
                else:
                    subprocess.run(["which", tool_name], 
                                 capture_output=True, check=True, shell=False)
                status[tool_name] = True
            except:
                status[tool_name] = False
    
    # Check Python packages
    required_packages = ["polars", "numpy", "biopython", "requests", "tqdm"]
    try:
        import importlib
        for pkg in required_packages:
            importlib.import_module(pkg)
        status["python_packages"] = True
    except ImportError:
        status["python_packages"] = False
    
    # Check reference data
    required_dirs = ["KEGG", "Ref100NR", "Ref99NR", "SILVA"]
    status["reference_data"] = all(
        (ref_path / d).exists() for d in required_dirs
    )
    
    return status


# Add/modify in build_dependencies.py

def build_dependencies_bioconda(
    path_to_reference_data: str = "pyTax4Fun2_ReferenceData",
    use_force: bool = False
) -> bool:
    """
    Setup dependencies for Bioconda deployment.
    In Bioconda, tools are installed via conda, so we just need to:
    1. Verify they're available
    2. Create symlinks/references if needed
    
    Args:
        path_to_reference_data: Path to reference data directory
        use_force: Overwrite existing links
        
    Returns:
        bool: True if successful
    """
    from .tool_manager import get_tool_manager
    from .utils import verify_all_tools
    
    print("Setting up pyTax4Fun2 for Bioconda deployment")
    print("=" * 60)
    
    ref_path = Path(path_to_reference_data)
    tools_dir = ref_path / "TOOLS"
    
    # Verify tools are available in conda environment
    print("\nVerifying tools in conda environment...")
    status = verify_all_tools(ref_path)
    
    all_good = True
    missing_tools = []
    
    for tool_name, tool_status in status.items():
        if tool_status["found"] and tool_status["working"]:
            print(f"  ✓ {tool_name}: {tool_status['version']} at {tool_status['path']}")
        elif tool_status["found"] and not tool_status["working"]:
            print(f"  ⚠ {tool_name}: Found but not working - {tool_status['error']}")
            all_good = False
            missing_tools.append(tool_name)
        else:
            print(f"  ✗ {tool_name}: Not found")
            all_good = False
            missing_tools.append(tool_name)
    
    if not all_good:
        tool_mgr = get_tool_manager(ref_path)
        print("\nMissing tools detected!")
        print(tool_mgr.suggest_installation(missing_tools))
        
        # In Bioconda, we should fail if tools are missing
        return False
    
    # Create symlinks in TOOLS directory for backward compatibility
    if tools_dir.exists() or use_force:
        print("\nCreating compatibility symlinks in TOOLS directory...")
        tools_dir.mkdir(exist_ok=True)
        
        tool_mgr = get_tool_manager(ref_path)
        
        for tool_name in status.keys():
            tool_path = tool_mgr.find_tool(tool_name)
            if tool_path:
                # Create version directory
                version = status[tool_name]["version"]
                if version and version != "unknown":
                    # Extract version number
                    import re
                    version_match = re.search(r'(\d+\.\d+\.\d+)', version)
                    if version_match:
                        version = version_match.group(1)
                    else:
                        version = "unknown"
                else:
                    version = "unknown"
                
                tool_version_dir = tools_dir / f"{tool_name}_v{version}"
                tool_version_dir.mkdir(exist_ok=True)
                
                # Create symlink
                link_path = tool_version_dir / tool_path.name
                if not link_path.exists() or use_force:
                    if link_path.exists():
                        link_path.unlink()
                    # Use absolute path for symlink
                    link_path.symlink_to(tool_path.absolute())
                    print(f"  Created: {link_path} -> {tool_path}")
    
    print("\n" + "=" * 60)
    print("Bioconda setup complete!")
    return True


def print_installation_guide() -> None:
    """
    Print installation guide for manual setup.
    """
    print("\n" + "="*60)
    print("Tax4Fun2 Installation Guide")
    print("="*60)
    
    print("\n1. Required External Tools:")
    print("   - BLAST+ (≥ 2.9.0): https://blast.ncbi.nlm.nih.gov/Blast.cgi")
    print("   - DIAMOND (≥ 0.9.24): https://github.com/bbuchfink/diamond")
    print("   - Prodigal (≥ 2.6.3): https://github.com/hyattpd/Prodigal")
    print("   - VSEARCH (≥ 2.14.1): https://github.com/torognes/vsearch")
    
    print("\n2. Installation Options:")
    print("   A. Automatic (recommended):")
    print("      python -c 'import tax4fun2; tax4fun2.build_dependencies()'")
    print("   B. Manual:")
    print("      - Download tools and place in pyTax4Fun2_ReferenceData/TOOLS/")
    print("      - Download BLAST+ and extract to pyTax4Fun2_ReferenceData/blast_bin/")
    
    print("\n3. Reference Data:")
    print("   Run: tax4fun2.build_reference_data()")
    print("   Or download from: https://cloudstor.aarnet.edu.au/plus/s/...")
    
    print("\n4. Verification:")
    print("   Run: tax4fun2.verify_installation()")
    print("="*60)


def main():
    """Command-line interface for building dependencies."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Install dependencies for Tax4Fun2"
    )
    parser.add_argument(
        "--reference-data", 
        default="pyTax4Fun2_ReferenceData",
        help="Path to reference data directory"
    )
    parser.add_argument(
        "--no-packages", 
        action="store_true",
        help="Skip Python package installation"
    )
    parser.add_argument(
        "--force", 
        action="store_true",
        help="Overwrite existing installations"
    )
    parser.add_argument(
        "--blast-version", 
        default="2.14.0+",
        help="BLAST+ version to download"
    )
    parser.add_argument(
        "--verify", 
        action="store_true",
        help="Verify installation after setup"
    )
    
    args = parser.parse_args()
    
    try:
        success = build_dependencies(
            path_to_reference_data=args.reference_data,
            install_suggested_packages=not args.no_packages,
            use_force=args.force,
            blast_version=args.blast_version
        )
        
        if success:
            print("\n✅ Dependencies installed successfully!")
            
            if args.verify:
                print("\nVerifying installation...")
                status = verify_installation(args.reference_data)
                
                print("\nInstallation Status:")
                for component, installed in status.items():
                    status_icon = "✅" if installed else "❌"
                    print(f"  {status_icon} {component}: {'Installed' if installed else 'Missing'}")
                
                if all(status.values()):
                    print("\n🎉 All components installed successfully!")
                else:
                    print("\n⚠️  Some components are missing. See installation guide.")
                    print_installation_guide()
        
    except Exception as e:
        print(f"\n❌ Error: {str(e)}")
        print_installation_guide()
        sys.exit(1)


if __name__ == "__main__":
    main()
    