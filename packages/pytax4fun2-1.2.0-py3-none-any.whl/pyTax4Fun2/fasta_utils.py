"""
SPDX-License-Identifier: AGPL-3.0-or-later
SPDX-FileCopyrightText: Copyright (C) 2026 pyTax4Fun2 contributors
pyTax4Fun2 - Python implementation of Tax4Fun2 for functional profiling of microbial communities.
See LICENSE for full license details.

Advanced FASTA utilities using polars_bio for Tax4Fun2.
"""

from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple, Union, Iterator
import warnings
import polars as pl
import numpy as np

try:
    import polars_bio as plb
    HAS_POLARS_BIO = True
except ImportError:
    HAS_POLARS_BIO = False
    warnings.warn(
        "polars_bio not installed. Install with: pip install polars-bio"
    )

from .utils import (
    pyTax4Fun2Error, validate_file,
    read_fasta_streaming, write_fasta_polars, read_fasta_polars  # ADDED IMPORTS
)


def calculate_gc_content(sequences_df: pl.DataFrame) -> pl.DataFrame:
    """
    Calculate GC content for sequences in DataFrame.
    
    Args:
        sequences_df: DataFrame with 'sequence' column
        
    Returns:
        DataFrame with added 'gc_content' column
    """
    if sequences_df.is_empty():
        return sequences_df
    
    return sequences_df.with_columns(
        (pl.col("sequence").str.count_matches(r"[GCgc]") / 
         pl.col("sequence").str.len_bytes() * 100)
        .alias("gc_content")
    )


def calculate_sequence_stats(sequences_df: pl.DataFrame) -> Dict[str, Any]:
    """
    Calculate comprehensive statistics for sequences.
    
    Args:
        sequences_df: DataFrame with sequence data
        
    Returns:
        Dictionary with statistics
    """
    if sequences_df.is_empty():
        return {
            "num_sequences": 0,
            "total_length": 0,
            "avg_length": 0,
            "min_length": 0,
            "max_length": 0,
            "avg_gc": 0
        }
    
    # Calculate lengths
    sequences_df = sequences_df.with_columns(
        pl.col("sequence").str.len_bytes().alias("length")
    )
    
    # Calculate GC content
    sequences_df = calculate_gc_content(sequences_df)
    
    return {
        "num_sequences": sequences_df.height,
        "total_length": sequences_df["length"].sum(),
        "avg_length": sequences_df["length"].mean(),
        "min_length": sequences_df["length"].min(),
        "max_length": sequences_df["length"].max(),
        "avg_gc": sequences_df["gc_content"].mean()
    }


def filter_sequences_by_length(
    sequences_df: pl.DataFrame,
    min_length: int = 0,
    max_length: int = 1000000
) -> pl.DataFrame:
    """
    Filter sequences by length.
    
    Args:
        sequences_df: Input sequences
        min_length: Minimum sequence length
        max_length: Maximum sequence length
        
    Returns:
        Filtered DataFrame
    """
    if sequences_df.is_empty():
        return sequences_df
    
    sequences_df = sequences_df.with_columns(
        pl.col("sequence").str.len_bytes().alias("length")
    )
    
    return sequences_df.filter(
        (pl.col("length") >= min_length) &
        (pl.col("length") <= max_length)
    ).drop("length")


def deduplicate_sequences(
    sequences_df: pl.DataFrame,
    by_sequence: bool = True,
    by_id: bool = False
) -> pl.DataFrame:
    """
    Remove duplicate sequences.
    
    Args:
        sequences_df: Input sequences
        by_sequence: Deduplicate by sequence content
        by_id: Deduplicate by sequence ID
        
    Returns:
        Deduplicated DataFrame
    """
    if sequences_df.is_empty():
        return sequences_df
    
    if by_sequence and by_id:
        # Deduplicate by both
        return sequences_df.unique(
            subset=["id", "sequence"],
            keep="first"
        )
    elif by_sequence:
        # Deduplicate by sequence only, keep first occurrence
        return sequences_df.unique(
            subset=["sequence"],
            keep="first"
        )
    elif by_id:
        # Deduplicate by ID only
        return sequences_df.unique(
            subset=["id"],
            keep="first"
        )
    else:
        return sequences_df


def rename_sequences(
    sequences_df: pl.DataFrame,
    prefix: str = "seq",
    start_index: int = 1
) -> pl.DataFrame:
    """
    Rename sequences with consistent naming.
    
    Args:
        sequences_df: Input sequences
        prefix: Prefix for sequence IDs
        start_index: Starting index
        
    Returns:
        DataFrame with renamed sequences
    """
    if sequences_df.is_empty():
        return sequences_df
    
    new_ids = [f"{prefix}_{i}" for i in range(start_index, start_index + sequences_df.height)]
    
    return sequences_df.with_columns(
        pl.Series("id", new_ids)
    )


def split_fasta_by_size(
    input_file: Path,
    output_dir: Path,
    max_sequences_per_file: int = 10000
) -> List[Path]:
    """
    Split large FASTA file into smaller files.
    
    Args:
        input_file: Input FASTA file
        output_dir: Output directory
        max_sequences_per_file: Maximum sequences per output file
        
    Returns:
        List of output file paths
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    output_files = []
    
    file_counter = 1
    current_chunk = []
    
    for chunk_df in read_fasta_streaming(input_file, chunk_size=1000):
        current_chunk.append(chunk_df)
        
        # Check if we've reached the limit
        total_in_chunk = sum(df.height for df in current_chunk)
        
        if total_in_chunk >= max_sequences_per_file:
            # Write current chunk
            combined_df = pl.concat(current_chunk)
            output_file = output_dir / f"chunk_{file_counter:04d}.fasta"
            write_fasta_polars(combined_df, output_file)  # This uses our fixed function
            output_files.append(output_file)
            
            # Reset for next chunk
            current_chunk = []
            file_counter += 1
    
    # Write remaining sequences
    if current_chunk:
        combined_df = pl.concat(current_chunk)
        output_file = output_dir / f"chunk_{file_counter:04d}.fasta"
        write_fasta_polars(combined_df, output_file)  # This uses our fixed function
        output_files.append(output_file)
    
    return output_files


def compare_fasta_files(
    file1: Path,
    file2: Path,
    compare_by: str = "sequence"  # "sequence" or "id"
) -> Dict[str, Any]:
    """
    Compare two FASTA files.
    
    Args:
        file1: First FASTA file
        file2: Second FASTA file
        compare_by: What to compare by
        
    Returns:
        Dictionary with comparison results
    """
    df1 = read_fasta_polars(file1)
    df2 = read_fasta_polars(file2)
    
    if compare_by == "sequence":
        set1 = set(df1["sequence"].to_list())
        set2 = set(df2["sequence"].to_list())
    else:  # compare_by == "id"
        set1 = set(df1["id"].to_list())
        set2 = set(df2["id"].to_list())
    
    common = set1.intersection(set2)
    unique_to_1 = set1 - set2
    unique_to_2 = set2 - set1
    
    return {
        "file1_count": len(set1),
        "file2_count": len(set2),
        "common_count": len(common),
        "unique_to_file1_count": len(unique_to_1),
        "unique_to_file2_count": len(unique_to_2),
        "jaccard_similarity": len(common) / len(set1.union(set2)) if set1.union(set2) else 0
    }


def extract_subsequences(
    sequences_df: pl.DataFrame,
    start_pos: int = 1,
    end_pos: Optional[int] = None,
    length: Optional[int] = None
) -> pl.DataFrame:
    """
    Extract subsequences from sequences.
    
    Args:
        sequences_df: Input sequences
        start_pos: Start position (1-based)
        end_pos: End position (optional)
        length: Length to extract (optional)
        
    Returns:
        DataFrame with extracted subsequences
    """
    if sequences_df.is_empty():
        return sequences_df
    
    def extract_sequence(seq: str, start: int, end: Optional[int], length: Optional[int]) -> str:
        """Extract subsequence from a sequence."""
        seq_len = len(seq)
        
        # Validate start position
        if start < 1:
            start = 1
        elif start > seq_len:
            start = seq_len
        
        # Calculate end position
        if end is not None:
            if end < start:
                end = start
            elif end > seq_len:
                end = seq_len
        elif length is not None:
            end = min(start + length - 1, seq_len)
        else:
            end = seq_len
        
        # Extract (0-based indexing)
        return seq[start-1:end]
    
    # Apply extraction
    extracted_seqs = []
    for seq in sequences_df["sequence"].to_list():
        extracted_seqs.append(extract_sequence(seq, start_pos, end_pos, length))
    
    return sequences_df.with_columns(
        pl.Series("sequence", extracted_seqs),
        pl.col("description") + f" | extracted:{start_pos}-{end_pos or 'end'}"
    )


def find_sequence_pattern(
    sequences_df: pl.DataFrame,
    pattern: str,
    case_sensitive: bool = False
) -> pl.DataFrame:
    """
    Find sequences containing a specific pattern.
    
    Args:
        sequences_df: Input sequences
        pattern: Pattern to search for (regex)
        case_sensitive: Whether search is case sensitive
        
    Returns:
        DataFrame with matching sequences
    """
    if sequences_df.is_empty():
        return sequences_df
    
    # Prepare pattern
    if not case_sensitive:
        pattern = f"(?i){pattern}"  # Case insensitive flag
    
    # Find matches
    matches = sequences_df.filter(
        pl.col("sequence").str.contains(pattern)
    )
    
    return matches


def translate_nucleotide_to_protein(
    sequences_df: pl.DataFrame,
    genetic_code: int = 11  # Standard bacterial genetic code
) -> pl.DataFrame:
    """
    Translate nucleotide sequences to protein sequences.
    
    Args:
        sequences_df: DataFrame with nucleotide sequences
        genetic_code: NCBI genetic code number (11 for bacteria)
        
    Returns:
        DataFrame with protein sequences
    """
    if sequences_df.is_empty():
        return sequences_df
    
    try:
        from Bio.Seq import Seq
        from Bio.Alphabet import generic_dna
        
        translated_seqs = []
        
        for seq_str in sequences_df["sequence"].to_list():
            # Ensure sequence length is multiple of 3
            seq_len = len(seq_str)
            truncated_len = seq_len - (seq_len % 3)
            
            if truncated_len > 0:
                # Translate using BioPython
                seq_obj = Seq(seq_str[:truncated_len])
                protein_seq = str(seq_obj.translate(table=genetic_code, to_stop=True))
                translated_seqs.append(protein_seq)
            else:
                translated_seqs.append("")
        
        # Create new DataFrame with protein sequences
        protein_df = sequences_df.with_columns(
            pl.Series("protein_sequence", translated_seqs)
        ).rename({"sequence": "nucleotide_sequence", "protein_sequence": "sequence"})
        
        # Filter out empty translations
        protein_df = protein_df.filter(pl.col("sequence").str.len_bytes() > 0)
        
        return protein_df
        
    except ImportError:
        warnings.warn("BioPython not installed, cannot translate sequences")
        return sequences_df


def calculate_sequence_similarity(
    seq1: str,
    seq2: str,
    method: str = "identity"
) -> float:
    """
    Calculate similarity between two sequences.
    
    Args:
        seq1: First sequence
        seq2: Second sequence
        method: Similarity method ('identity' or 'levenshtein')
        
    Returns:
        Similarity score (0-1)
    """
    if not seq1 or not seq2:
        return 0.0
    
    if method == "identity":
        # Simple identity calculation
        min_len = min(len(seq1), len(seq2))
        if min_len == 0:
            return 0.0
        
        matches = sum(1 for a, b in zip(seq1[:min_len], seq2[:min_len]) if a == b)
        return matches / min_len
    
    elif method == "levenshtein":
        try:
            import textdistance
            # Normalized Levenshtein distance
            distance = textdistance.levenshtein.normalized_similarity(seq1, seq2)
            return distance
        except ImportError:
            warnings.warn("textdistance not installed, using identity method")
            return calculate_sequence_similarity(seq1, seq2, method="identity")
    
    else:
        raise ValueError(f"Unknown similarity method: {method}")
        