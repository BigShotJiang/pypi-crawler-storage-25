"""
SPDX-License-Identifier: AGPL-3.0-or-later
SPDX-FileCopyrightText: Copyright (C) 2026 pyTax4Fun2 contributors
pyTax4Fun2 - Python implementation of Tax4Fun2 for functional profiling of microbial communities.
See LICENSE for full license details.

Diversity and statistical visualizations.
"""

"""
TODO:
Recorded warnings here to be noted:
PYTHON3_SITE_PACKAGES_PATH/sklearn/manifold/_mds.py:744: FutureWarning: The default value of `n_init` will change from 4 to 1 in 1.9. To suppress this warning, provide some value of `n_init`.
  warnings.warn(
PYTHON3_SITE_PACKAGES_PATH/sklearn/manifold/_mds.py:754: FutureWarning: The default value of `init` will change from 'random' to 'classical_mds' in 1.10. To suppress this warning, provide some value of `init`.
  warnings.warn(
PYTHON3_SITE_PACKAGES_PATH/sklearn/manifold/_mds.py:771: FutureWarning: The `dissimilarity` parameter is deprecated and will be removed in 1.10. Use `metric` instead.
  warnings.warn(
"""

import warnings
# Suppress scikit-learn deprecation warnings (temporary until we update parameters)
warnings.filterwarnings("ignore", category=FutureWarning, module="sklearn")
# Suppress scikit-bio negative eigenvalue warnings (normal for non-Euclidean distances)
warnings.filterwarnings("ignore", category=RuntimeWarning, module="skbio")

import os
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Optional, List, Union, Dict, Any, Tuple
from scipy import stats
from scipy.stats import shapiro, levene, f_oneway, kruskal, ttest_ind, mannwhitneyu
from statsmodels.stats.multicomp import pairwise_tukeyhsd
from statsmodels.stats.multitest import multipletests
from itertools import combinations
import polars as pl

# Alpha diversity metrics from scikit-bio
try:
    from skbio.diversity import alpha as skbio_alpha
    from skbio.diversity.alpha import *
    HAS_SKBIO = True
except ImportError:
    HAS_SKBIO = False
    warnings.warn("scikit-bio not installed. Install with: pip install scikit-bio")

# Metric groups for easy selection
ALPHA_METRIC_GROUPS = {
    'all_richness': ['ace', 'chao1', 'doubles', 'margalef', 'menhinick', 
                     'observed_features', 'osd', 'singles', 'sobs'],
    'all_diversity': ['brillouin_d', 'enspie', 'fisher_alpha', 'hill', 'inv_simpson',
                      'kempton_taylor_q', 'renyi', 'shannon', 'simpson', 'tsallis'],
    'all_evenness': ['heip_e', 'mcintosh_e', 'pielou_e', 'simpson_e'],
    'all_dominance': ['berger_parker_d', 'dominance', 'gini_index', 'mcintosh_d',
                      'simpson_d', 'strong'],
    'all_coverage': ['esty_ci', 'goods_coverage', 'lladser_ci', 'lladser_pe', 'robbins'],
    'all': ['ace', 'chao1', 'doubles', 'margalef', 'menhinick', 'observed_features',
            'osd', 'singles', 'sobs', 'brillouin_d', 'enspie', 'fisher_alpha',
            'hill', 'inv_simpson', 'kempton_taylor_q', 'renyi', 'shannon',
            'simpson', 'tsallis', 'heip_e', 'mcintosh_e', 'pielou_e', 'simpson_e',
            'berger_parker_d', 'dominance', 'gini_index', 'mcintosh_d', 'simpson_d',
            'strong', 'esty_ci', 'goods_coverage', 'lladser_ci', 'lladser_pe', 'robbins']
}

ALPHA_METRIC_GROUPS_PHYLOGENETIC = {
    'all_richness':['faith_pd']
}

# Phylogenetic metrics that require a tree
PHYLOGENETIC_METRICS = ['faith_pd', 'phydiv']


def detect_input_type(df: pd.DataFrame, tree_path: Optional[Union[str, Path]] = None) -> str:
    """
    Detect if DataFrame contains KO functional or OTU taxonomic data.
    
    Args:
        df: Input DataFrame
        tree_path: Optional phylogenetic tree path
    
    Returns:
        str: 'functional' or 'otu'
    """
    # Check for KO column (functional data)
    ko_indicators = ['KO', 'KEGG', 'GENE', 'FUNCTION', 'KO_ID', 'KEGG_ORTHOLOG']
    for col in df.columns[:min(5, len(df.columns))]:
        if col.upper() in ko_indicators:
            return 'functional'
    
    # Check if tree is provided - likely OTU data
    if tree_path is not None:
        return 'otu'
    
    # Check column naming patterns
    first_col = df.columns[0].lower()
    if 'otu' in first_col or 'taxon' in first_col or 'asv' in first_col or 'feature' in first_col:
        return 'otu'
    
    # Check for description column patterns
    for col in df.columns[:3]:
        if 'taxonomy' in col.lower() or 'lineage' in col.lower():
            return 'otu'
    
    # Default to functional (backward compatible)
    return 'functional'


def _paired_two_group_comparison(df, groups, method, alpha, subject_col, time_col):
    """
    Handle paired 2-group comparisons (e.g., before/after).
    
    Args:
        df: DataFrame with 'value' and 'group' columns
        groups: List of two group names (e.g., ['Before', 'After'])
        method: Statistical method
        alpha: Significance level
        subject_col: Column name with subject IDs
        time_col: Column name with time point labels
    
    Returns:
        dict: mapping of group to letter(s)
    """
    from scipy.stats import ttest_rel, wilcoxon, shapiro
    import numpy as np
    
    group1, group2 = groups
    
    # Get paired data
    data1 = df[df['group'] == group1].set_index(subject_col)['value']
    data2 = df[df['group'] == group2].set_index(subject_col)['value']
    
    # Align by subject ID
    common_subjects = data1.index.intersection(data2.index)
    if len(common_subjects) < 2:
        print(f"  Warning: Need at least 2 paired subjects for {group1} vs {group2}, found {len(common_subjects)}")
        return {group1: 'a', group2: 'a'}
    
    paired_data1 = data1[common_subjects].values
    paired_data2 = data2[common_subjects].values
    
    # Check normality of differences
    differences = paired_data2 - paired_data1
    if len(differences) >= 3:
        _, p_norm = shapiro(differences)
        normal = p_norm > 0.05
    else:
        normal = True  # Assume normal for small samples
    
    # Choose test
    if method == 'auto':
        use_parametric = normal
    elif method in ['parametric', 'paired-t']:
        use_parametric = True
    elif method in ['nonparametric', 'wilcoxon']:
        use_parametric = False
    else:
        use_parametric = normal
    
    if use_parametric:
        stat, p_val = ttest_rel(paired_data1, paired_data2)
        test_name = "Paired t-test"
    else:
        stat, p_val = wilcoxon(paired_data1, paired_data2)
        test_name = "Wilcoxon signed-rank"
    
    # Assign letters
    mean1, mean2 = np.mean(paired_data1), np.mean(paired_data2)
    if p_val < alpha:
        return {group1: 'a', group2: 'b'} if mean1 > mean2 else {group1: 'b', group2: 'a'}
    else:
        return {group1: 'a', group2: 'a'}


def _paired_multi_group_comparison(df, groups, method, alpha, subject_col, time_col):
    """
    Handle paired multi-group comparisons (3+ time points) using repeated measures.
    
    Args:
        df: DataFrame with 'value' and 'group' columns
        groups: List of group names (time points)
        method: Statistical method
        alpha: Significance level
        subject_col: Column name with subject IDs
        time_col: Column name with time point labels
    
    Returns:
        dict: mapping of group to letter(s)
    """
    from scipy.stats import friedmanchisquare, wilcoxon
    from itertools import combinations
    import numpy as np
    import pandas as pd
    
    # Get data in wide format (subjects × time points)
    pivot_df = df.pivot(index=subject_col, columns=time_col, values='value')
    pivot_df = pivot_df.dropna()  # Keep only complete cases
    
    if pivot_df.shape[0] < 3:
        print(f"  Warning: Need at least 3 subjects for repeated measures, found {pivot_df.shape[0]}")
        return {g: 'a' for g in groups}
    
    # Check if data is approximately normal (simplified)
    use_parametric = False  # Default to non-parametric for simplicity
    
    if method == 'parametric' or (method == 'auto' and use_parametric):
        try:
            from statsmodels.stats.anova import AnovaRM
            # Reshape to long format for statsmodels
            long_df = pivot_df.reset_index().melt(id_vars=subject_col, var_name=time_col, value_name='value')
            aovrm = AnovaRM(long_df, 'value', subject_col, within=[time_col])
            res = aovrm.fit()
            p_val = res.anova_table['Pr > F'][0]
            test_name = "Repeated measures ANOVA"
            use_parametric = True
        except Exception as e:
            print(f"  Warning: Repeated measures ANOVA failed: {e}")
            use_parametric = False
    
    if not use_parametric:
        # Friedman test
        stat, p_val = friedmanchisquare(*[pivot_df[g].values for g in groups])
        test_name = "Friedman test"
    
    # Post-hoc tests if significant
    if p_val < alpha:
        n_comparisons = len(groups) * (len(groups) - 1) // 2
        significant_pairs = []
        
        for g1, g2 in combinations(groups, 2):
            if use_parametric:
                from scipy.stats import ttest_rel
                _, p_pair = ttest_rel(pivot_df[g1], pivot_df[g2])
            else:
                _, p_pair = wilcoxon(pivot_df[g1], pivot_df[g2])
            
            p_corrected = p_pair * n_comparisons
            if p_corrected < alpha:
                significant_pairs.append((g1, g2))
        
        return _generate_cld(groups, significant_pairs)
    else:
        return {g: 'a' for g in groups}
        

def calculate_statistical_annotation(
    data: np.ndarray,
    groups: np.ndarray,
    method: str = 'auto',
    alpha: float = 0.05,
    paired: bool = False,
    subject_ids: Optional[np.ndarray] = None,
    time_points: Optional[np.ndarray] = None
) -> Dict[str, str]:
    """
    Calculate compact letter display for group comparisons.
    
    Args:
        data: array of values
        groups: array of group labels
        method: statistical method ('auto', 'parametric', 'nonparametric', 
                't-test', 'mannwhitney', 'anova', 'kruskal')
        alpha: significance level
        paired: Whether samples are paired/dependent
        subject_ids: Subject IDs for paired designs (required if paired=True)
        time_points: Time point labels for paired designs (required if paired=True)
    
    Returns:
        dict: mapping of group to letter(s)
    """
    import pandas as pd
    
    df = pd.DataFrame({'value': data, 'group': groups})
    
    groups_unique = df['group'].unique()
    n_groups = len(groups_unique)
    
    # Handle paired/dependent designs
    if paired:
        if subject_ids is None or time_points is None:
            raise ValueError("subject_ids and time_points are required when paired=True")
        
        df['subject'] = subject_ids
        df['time'] = time_points
        
        if n_groups == 2:
            return _paired_two_group_comparison(df, groups_unique, method, alpha, 'subject', 'time')
        else:
            return _paired_multi_group_comparison(df, groups_unique, method, alpha, 'subject', 'time')
    
    # Original independent groups code
    if n_groups == 2:
        return _two_group_comparison(df, groups_unique, method, alpha)
    else:
        return _multi_group_comparison(df, groups_unique, method, alpha)


def _two_group_comparison(df, groups, method, alpha):
    """Handle 2-group comparisons with appropriate test."""
    group1_data = df[df['group'] == groups[0]]['value'].dropna().values
    group2_data = df[df['group'] == groups[1]]['value'].dropna().values
    group1_name, group2_name = groups[0], groups[1]
    
    # Determine which test to use
    use_parametric = False
    
    if method == 'auto':
        # Check normality and variance for both groups
        _, p1 = shapiro(group1_data) if len(group1_data) >= 3 else (0, 1)
        _, p2 = shapiro(group2_data) if len(group2_data) >= 3 else (0, 1)
        normal = p1 > 0.05 and p2 > 0.05
        
        if normal and len(group1_data) >= 3 and len(group2_data) >= 3:
            _, levene_p = levene(group1_data, group2_data)
            use_parametric = levene_p > 0.05
        else:
            use_parametric = False
    
    elif method in ['parametric', 't-test']:
        use_parametric = True
    elif method in ['nonparametric', 'wilcoxon']:
        use_parametric = False
    else:
        # Default to auto
        use_parametric = False
    
    # Perform the test
    if use_parametric:
        stat, p_val = ttest_ind(group1_data, group2_data, equal_var=True)
        test_name = "t-test"
    else:
        stat, p_val = mannwhitneyu(group1_data, group2_data, alternative='two-sided')
        test_name = "Mann-Whitney U"
    
    # Assign letters
    if p_val < alpha:
        # Significant difference - different letters
        # Order by mean for consistent labeling
        mean1, mean2 = np.mean(group1_data), np.mean(group2_data)
        if mean1 > mean2:
            return {group1_name: 'a', group2_name: 'b'}
        else:
            return {group1_name: 'b', group2_name: 'a'}
    else:
        # No significant difference - same letter
        return {group1_name: 'a', group2_name: 'a'}


def _multi_group_comparison(df, groups, method, alpha):
    """Handle multi-group comparisons (>=3 groups)."""
    group_data = [df[df['group'] == g]['value'].dropna().values for g in groups]
    
    # Determine which test to use
    use_parametric = False
    
    if method == 'auto':
        # Check normality for all groups
        normal_groups = []
        for data in group_data:
            if len(data) >= 3:
                _, p = shapiro(data)
                normal_groups.append(p > 0.05)
            else:
                normal_groups.append(True)  # Assume normal for small groups
        
        all_normal = all(normal_groups)
        
        if all_normal:
            # Check homogeneity of variance
            _, levene_p = levene(*group_data)
            use_parametric = levene_p > 0.05
        else:
            use_parametric = False
    
    elif method == 'parametric':
        use_parametric = True
    elif method == 'nonparametric':
        use_parametric = False
    elif method == 'anova':
        use_parametric = True
    elif method == 'kruskal':
        use_parametric = False
    else:
        use_parametric = False
    
    # Perform the test
    if use_parametric:
        # ANOVA
        f_stat, p_val = f_oneway(*group_data)
        test_name = "ANOVA"
        
        if p_val < alpha:
            # Post-hoc: Tukey HSD
            tukey = pairwise_tukeyhsd(df['value'], df['group'], alpha=alpha)
            significant_pairs = []
            for row in tukey.summary().data[1:]:
                if row[5] < alpha:
                    significant_pairs.append((row[0], row[1]))
        else:
            significant_pairs = []
    else:
        # Kruskal-Wallis
        h_stat, p_val = kruskal(*group_data)
        test_name = "Kruskal-Wallis"
        
        if p_val < alpha:
            # Post-hoc: pairwise Mann-Whitney with Bonferroni correction
            n_comparisons = len(groups) * (len(groups) - 1) // 2
            bonferroni_alpha = alpha / n_comparisons
            
            significant_pairs = []
            for i, g1 in enumerate(groups):
                for g2 in groups[i+1:]:
                    data1 = df[df['group'] == g1]['value'].dropna().values
                    data2 = df[df['group'] == g2]['value'].dropna().values
                    _, p = mannwhitneyu(data1, data2, alternative='two-sided')
                    if p < bonferroni_alpha:
                        significant_pairs.append((g1, g2))
        else:
            significant_pairs = []
    
    # Generate compact letter display
    if p_val >= alpha:
        # No significant differences - all same letter
        return {g: 'a' for g in groups}
    else:
        return _generate_cld(groups, significant_pairs)


def _generate_cld(groups, significant_pairs):
    """Generate compact letter display from significant pairs."""
    import string
    from collections import defaultdict
    
    # Build graph of non-significant relationships
    non_sig_graph = defaultdict(set)
    for i, g1 in enumerate(groups):
        for g2 in groups[i+1:]:
            if (g1, g2) not in significant_pairs and (g2, g1) not in significant_pairs:
                non_sig_graph[g1].add(g2)
                non_sig_graph[g2].add(g1)
    
    # Assign letters
    letters = {}
    available_letters = list(string.ascii_lowercase)
    
    # Sort groups by mean for consistent ordering (optional)
    # group_means = {g: np.mean(df[df['group'] == g]['value']) for g in groups}
    # sorted_groups = sorted(groups, key=lambda g: group_means[g], reverse=True)
    sorted_groups = groups  # Keep original order
    
    for group in sorted_groups:
        used_letters = set()
        for neighbor in non_sig_graph[group]:
            if neighbor in letters:
                used_letters.add(letters[neighbor])
        
        # Find first available letter
        assigned = False
        for letter in available_letters:
            if letter not in used_letters:
                letters[group] = letter
                assigned = True
                break
        
        if not assigned:
            # Use combination of letters
            letters[group] = ''.join(available_letters[:2])
    
    return letters


def validate_phylogenetic_metrics(metrics: List[str], input_type: str, tree_path: Optional[Union[str, Path]] = None) -> Tuple[bool, List[str], List[str]]:
    """
    Validate that phylogenetic metrics are used with appropriate data.
    
    Args:
        metrics: List of metrics to calculate
        input_type: 'functional' or 'otu'
        tree_path: Path to phylogenetic tree
    
    Returns:
        Tuple[bool, List[str], List[str]]: (is_valid, valid_metrics, warnings)
    """
    valid_metrics = []
    warnings_list = []
    
    for metric in metrics:
        if metric in PHYLOGENETIC_METRICS:
            if input_type == 'functional':
                warnings_list.append(
                    f"Metric '{metric}' is not applicable to KO functional data. "
                    f"Skipping. Use OTU table with phylogenetic tree for this metric."
                )
            elif tree_path is None:
                warnings_list.append(
                    f"Metric '{metric}' requires a phylogenetic tree. "
                    f"Please provide --tree. Skipping."
                )
            else:
                valid_metrics.append(metric)
        else:
            valid_metrics.append(metric)
    
    return len(valid_metrics) > 0, valid_metrics, warnings_list


def load_phylogenetic_tree(tree_source: Union[str, Path]) -> Any:
    """
    Load phylogenetic tree from file or string content.
    
    Args:
        tree_source: File path or Newick string content
    
    Returns:
        TreeNode: Loaded tree object
    """
    from skbio import TreeNode
    
    tree_source_str = str(tree_source)
    
    # Check if this is a file path
    is_file_path = Path(tree_source_str).exists()
    
    # Check if it contains Newick characters and is not a valid path
    is_newick_content = (not is_file_path and 
                         '(' in tree_source_str and 
                         ':' in tree_source_str and
                         len(tree_source_str) > 50)
    
    if is_file_path:
        # It's a file path
        print(f"  Loading phylogenetic tree from file: {tree_source_str}")
        return TreeNode.read(tree_source_str)
    elif is_newick_content:
        # It's the tree content string
        print(f"  Parsing tree from string (length: {len(tree_source_str)} chars)")
        return TreeNode.read([tree_source_str])
    else:
        # Try as file anyway, if that fails try as string
        try:
            if Path(tree_source_str).exists():
                return TreeNode.read(tree_source_str)
            else:
                return TreeNode.read([tree_source_str])
        except Exception as e:
            raise ValueError(f"Could not parse tree from source: {tree_source_str[:100]}... Error: {str(e)}")


def calculate_alpha_metrics(
    abundance_matrix: np.ndarray,
    metric: str,
    phylogenetic_tree: Optional[Any] = None,
    confidence_interval: float = 0.95,
    feature_names: Optional[List[str]] = None,
    phydiv_type: str = 'rPD',
    phydiv_theta: Optional[float] = None,
    phydiv_rooted: Optional[bool] = None
) -> np.ndarray:
    """
    Calculate a specific alpha diversity metric for all samples.
    """
    from skbio.diversity import alpha as skbio_alpha
    
    # Handle phydiv specially
    if metric == 'phydiv':
        # Use the dedicated phydiv function
        results_dict = calculate_phydiv_metrics(
            abundance_matrix,
            feature_names,
            phylogenetic_tree,
            metric_type=phydiv_type,
            custom_theta=phydiv_theta,
            force_rooted=phydiv_rooted
        )
        
        # Determine which metric to return
        if phydiv_theta is not None:
            # Custom theta case - use the generated metric name
            if phydiv_rooted is None:
                phydiv_rooted = phylogenetic_tree.is_root() if phylogenetic_tree else True
            metric_key = f"{'r' if phydiv_rooted else 'u'}PDw_theta_{str(phydiv_theta).replace('.', '')}"
            return results_dict[metric_key]
        elif phydiv_type == 'all':
            # For 'all', we need to create a DataFrame with all metrics
            # But for now, return the first one and warn
            first_key = list(results_dict.keys())[0]
            print(f"  Note: 'all' selected for phydiv, using {first_key} for main calculation")
            # Also store all metrics in a global or return them separately
            # For now, just return the first
            return results_dict[first_key]
        else:
            # Specific metric type
            if phydiv_type in results_dict:
                return results_dict[phydiv_type]
            else:
                # Try to find by name
                for key in results_dict:
                    if phydiv_type in key:
                        return results_dict[key]
                raise ValueError(f"Metric {phydiv_type} not found in results")
    
    # Original code for other metrics...
    results = []
    for sample_idx, sample_abundances in enumerate(abundance_matrix):
        try:
            if metric == 'ace':
                val = skbio_alpha.ace(sample_abundances)
            elif metric == 'chao1':
                val = skbio_alpha.chao1(sample_abundances)
            elif metric == 'chao1_ci':
                lower, upper = skbio_alpha.chao1_ci(sample_abundances, confidence_interval)
                val = (lower + upper) / 2
            elif metric == 'doubles':
                val = skbio_alpha.doubles(sample_abundances)
            elif metric == 'faith_pd':
                if phylogenetic_tree is None:
                    raise ValueError("Phylogenetic tree required for faith_pd")
                if feature_names is None:
                    raise ValueError("Feature names (taxa) required for faith_pd")
                val = skbio_alpha.faith_pd(sample_abundances, feature_names, phylogenetic_tree)
            elif metric == 'margalef':
                val = skbio_alpha.margalef(sample_abundances)
            elif metric == 'menhinick':
                val = skbio_alpha.menhinick(sample_abundances)
            elif metric == 'michaelis_menten_fit':
                val = skbio_alpha.michaelis_menten_fit(sample_abundances)[0]
            elif metric == 'observed_features':
                val = skbio_alpha.observed_features(sample_abundances)
            elif metric == 'osd':
                observed, singles, doubles = skbio_alpha.osd(sample_abundances)
                val = observed
            elif metric == 'singles':
                val = skbio_alpha.singles(sample_abundances)
            elif metric == 'sobs':
                val = skbio_alpha.sobs(sample_abundances)
            elif metric == 'brillouin_d':
                val = skbio_alpha.brillouin_d(sample_abundances)
            elif metric == 'enspie':
                val = skbio_alpha.enspie(sample_abundances)
            elif metric == 'fisher_alpha':
                val = skbio_alpha.fisher_alpha(sample_abundances)
            elif metric == 'hill':
                val = skbio_alpha.hill(sample_abundances, 1)
            elif metric == 'inv_simpson':
                val = skbio_alpha.inv_simpson(sample_abundances)
            elif metric == 'kempton_taylor_q':
                val = skbio_alpha.kempton_taylor_q(sample_abundances)
            elif metric == 'renyi':
                val = skbio_alpha.renyi(sample_abundances, 1)
            elif metric == 'shannon':
                val = skbio_alpha.shannon(sample_abundances)
            elif metric == 'simpson':
                val = skbio_alpha.simpson(sample_abundances)
            elif metric == 'tsallis':
                val = skbio_alpha.tsallis(sample_abundances, 1)
            elif metric == 'heip_e':
                val = skbio_alpha.heip_e(sample_abundances)
            elif metric == 'mcintosh_e':
                val = skbio_alpha.mcintosh_e(sample_abundances)
            elif metric == 'pielou_e':
                val = skbio_alpha.pielou_e(sample_abundances)
            elif metric == 'simpson_e':
                val = skbio_alpha.simpson_e(sample_abundances)
            elif metric == 'berger_parker_d':
                val = skbio_alpha.berger_parker_d(sample_abundances)
            elif metric == 'dominance':
                val = skbio_alpha.dominance(sample_abundances)
            elif metric == 'gini_index':
                val = skbio_alpha.gini_index(sample_abundances)
            elif metric == 'mcintosh_d':
                val = skbio_alpha.mcintosh_d(sample_abundances)
            elif metric == 'simpson_d':
                val = skbio_alpha.simpson_d(sample_abundances)
            elif metric == 'strong':
                val = skbio_alpha.strong(sample_abundances)
            elif metric == 'esty_ci':
                lower, upper = skbio_alpha.esty_ci(sample_abundances, confidence_interval)
                val = (lower + upper) / 2
            elif metric == 'goods_coverage':
                val = skbio_alpha.goods_coverage(sample_abundances)
            elif metric == 'lladser_ci':
                lower, upper, r = skbio_alpha.lladser_ci(sample_abundances, confidence_interval)
                val = (lower + upper) / 2
            elif metric == 'lladser_pe':
                val = skbio_alpha.lladser_pe(sample_abundances)
            elif metric == 'robbins':
                val = skbio_alpha.robbins(sample_abundances)
            else:
                raise ValueError(f"Unknown metric: {metric}")
            
            results.append(val)
            
        except Exception as e:
            warnings.warn(f"Metric '{metric}' failed for sample {sample_idx}: {str(e)}")
            results.append(np.nan)
    
    return np.array(results)    


def calculate_phydiv_metrics(
    abundance_matrix: np.ndarray,
    feature_names: List[str],
    tree: Any,
    metric_type: str = 'rPD',
    custom_theta: Optional[float] = None,
    force_rooted: Optional[bool] = None
) -> Dict[str, np.ndarray]:
    """
    Calculate various phylogenetic diversity metrics using phydiv.
    
    Returns:
        Dict mapping clean metric names to arrays of values
    """
    from skbio.diversity.alpha import phydiv
    
    n_samples = abundance_matrix.shape[0]
    
    # Define all 10 metric configurations with clean display names
    all_metrics_config = [
        {"name": "Faith's PD (rPD)", "code": "Faith's PD", "rooted": True, "weight": 0},
        {"name": "Unrooted PD (uPD)", "code": "uPD", "rooted": False, "weight": 0},
        {"name": "Weighted PD (rPDw)", "code": "rPDw", "rooted": True, "weight": 1},
        {"name": "Balance-weighted PD (uPDw)", "code": "uPDw", "rooted": False, "weight": 1},
        {"name": "Partial PD (θ=0.25, rooted)", "code": "rPDw_theta_0.25", "rooted": True, "weight": 0.25},
        {"name": "Partial PD (θ=0.25, unrooted)", "code": "uPDw_theta_0.25", "rooted": False, "weight": 0.25},
        {"name": "Partial PD (θ=0.5, rooted)", "code": "rPDw_theta_0.5", "rooted": True, "weight": 0.5},
        {"name": "Partial PD (θ=0.5, unrooted)", "code": "uPDw_theta_0.5", "rooted": False, "weight": 0.5},
        {"name": "Partial PD (θ=0.75, rooted)", "code": "rPDw_theta_0.75", "rooted": True, "weight": 0.75},
        {"name": "Partial PD (θ=0.75, unrooted)", "code": "uPDw_theta_0.75", "rooted": False, "weight": 0.75},
    ]
    
    # Handle custom theta
    if custom_theta is not None:
        if force_rooted is None:
            force_rooted = tree.is_root() if hasattr(tree, 'is_root') else True
        
        rooted_val = force_rooted
        weight_val = custom_theta
        
        # Create clean display name for custom metric
        if rooted_val:
            metric_name = f"Custom PD (θ={custom_theta}, rooted)"
            metric_code = f"rPDw_theta_{str(custom_theta).replace('.', '')}"
        else:
            metric_name = f"Custom PD (θ={custom_theta}, unrooted)"
            metric_code = f"uPDw_theta_{str(custom_theta).replace('.', '')}"
        
        config = {
            "name": metric_name,
            "code": metric_code,
            "rooted": rooted_val,
            "weight": weight_val
        }
        metrics_to_calc = [config]
        
    elif metric_type == 'all':
        metrics_to_calc = all_metrics_config
        
    else:
        # Find the matching configuration
        matching = [m for m in all_metrics_config if m["code"] == metric_type]
        if not matching:
            # Try to match by name
            matching = [m for m in all_metrics_config if metric_type in m["code"] or metric_type in m["name"]]
        
        if matching:
            metrics_to_calc = matching
        else:
            print(f"  Warning: Unknown phydiv type '{metric_type}', using Faith's PD (rPD)")
            metrics_to_calc = [all_metrics_config[0]]
    
    results = {}
    
    print(f"  Calculating {len(metrics_to_calc)} phylogenetic diversity metrics...")
    
    for config in metrics_to_calc:
        values = []
        rooted_param = config["rooted"] if force_rooted is None else force_rooted
        weight_param = config["weight"]
        
        # Override with force_rooted if provided
        if force_rooted is not None:
            rooted_param = force_rooted
        
        for sample_idx in range(n_samples):
            try:
                val = phydiv(
                    abundance_matrix[sample_idx, :],
                    feature_names,
                    tree,
                    rooted=rooted_param,
                    weight=weight_param,
                    validate=True
                )
                values.append(val)
            except Exception as e:
                print(f"  Warning: {config['name']} failed for sample {sample_idx}: {e}")
                values.append(np.nan)
        
        # Store results with clean display name (no duplicate)
        results[config["name"]] = np.array(values)
    
    return results    
    

def compact_letter_display(data, groups, alpha=0.05):
    """
    Calculate compact letter display (CLD) for group comparisons.
    
    Args:
        data: array of values
        groups: array of group labels
        alpha: significance level
    
    Returns:
        dict: mapping of group to letter(s)
    """
    # Create DataFrame
    df = pd.DataFrame({'value': data, 'group': groups})
    groups_unique = df['group'].unique()
    n_groups = len(groups_unique)
    
    # Check normality for ANOVA assumption
    normal = True
    for group in groups_unique:
        group_data = df[df['group'] == group]['value'].dropna()
        if len(group_data) >= 3:
            _, p = shapiro(group_data)
            if p < 0.05:
                normal = False
                break
    
    # Check homogeneity of variance
    groups_data = [df[df['group'] == g]['value'].dropna().values for g in groups_unique]
    _, levene_p = levene(*groups_data)
    
    # Choose appropriate test
    if normal and levene_p > 0.05:
        # Use ANOVA + Tukey HSD
        f_stat, p_val = f_oneway(*groups_data)
        if p_val < alpha:
            tukey = pairwise_tukeyhsd(df['value'], df['group'], alpha=alpha)
            # Extract significant pairs
            sig_pairs = []
            for row in tukey.summary().data[1:]:
                if row[5] < alpha:  # p-value < alpha
                    sig_pairs.append((row[0], row[1]))
        else:
            sig_pairs = []
    else:
        # Use Kruskal-Wallis + pairwise Mann-Whitney with Bonferroni
        h_stat, p_val = kruskal(*groups_data)
        if p_val < alpha:
            sig_pairs = []
            n_comparisons = n_groups * (n_groups - 1) // 2
            bonferroni_alpha = alpha / n_comparisons
            
            for i, g1 in enumerate(groups_unique):
                for g2 in groups_unique[i+1:]:
                    data1 = df[df['group'] == g1]['value'].dropna().values
                    data2 = df[df['group'] == g2]['value'].dropna().values
                    _, p = mannwhitneyu(data1, data2, alternative='two-sided')
                    if p < bonferroni_alpha:
                        sig_pairs.append((g1, g2))
        else:
            sig_pairs = []
    
    # Calculate compact letter display
    letters = {}
    if not sig_pairs:
        # No significant differences - all same letter
        for group in groups_unique:
            letters[group] = 'a'
    else:
        # Build graph of non-significant relationships
        from collections import defaultdict
        
        # Create adjacency matrix of non-significant pairs
        nonsig_matrix = defaultdict(set)
        for i, g1 in enumerate(groups_unique):
            for g2 in groups_unique[i+1:]:
                if (g1, g2) not in sig_pairs and (g2, g1) not in sig_pairs:
                    nonsig_matrix[g1].add(g2)
                    nonsig_matrix[g2].add(g1)
        
        # Assign letters using greedy algorithm
        import string
        available_letters = list(string.ascii_lowercase)
        group_to_letter = {}
        
        # Sort groups by mean value for consistent ordering
        group_means = {g: df[df['group'] == g]['value'].mean() for g in groups_unique}
        sorted_groups = sorted(groups_unique, key=lambda g: group_means[g], reverse=True)
        
        for group in sorted_groups:
            # Find letters already used by connected groups
            used_letters = set()
            for neighbor in nonsig_matrix[group]:
                if neighbor in group_to_letter:
                    used_letters.add(group_to_letter[neighbor])
            
            # Assign first available letter not used
            for letter in available_letters:
                if letter not in used_letters:
                    group_to_letter[group] = letter
                    break
            
            # If no letter available, use combination
            if group not in group_to_letter:
                group_to_letter[group] = ''.join(available_letters[:2])
        
        letters = group_to_letter
    
    return letters
    
    
def plot_alpha_diversity(
    functional_profiles: Union[str, Path, pl.DataFrame],
    metadata: Optional[pd.DataFrame] = None,
    group_col: Optional[str] = None,
    metrics: List[str] = ['shannon', 'sobs', 'pielou_e'],
    plot_type: str = 'box',
    confidence_interval: float = 0.95,
    rarefy: bool = False,
    rarefaction_depth: Optional[int] = None,
    rarefaction_repeats: int = 100,
    phylogenetic_tree: Optional[Union[str, Path]] = None,
    input_type: str = 'auto',
    output_file: Optional[str] = None,
    figsize: tuple = (12, 8),
    phydiv_type: str = 'rPD',
    phydiv_theta: Optional[float] = None,
    phydiv_rooted: Optional[bool] = None,
    stats_annotate: bool = False,
    stats_alpha: float = 0.05,
    stats_method: str = 'auto',
    stats_footer: bool = True,
    apply_fdr: bool = True,
    fdr_method: str = 'bh',
    paired: bool = False,
    subject_id_col: Optional[str] = None,
    time_col: Optional[str] = None
) -> pd.DataFrame:    
    """
    Plot alpha diversity metrics using scikit-bio implementations.
    
    Args:
        functional_profiles: Path to functional profile file or DataFrame
        metadata: Sample metadata DataFrame
        group_col: Column name for grouping
        metrics: List of alpha diversity metrics to calculate
        plot_type: Type of plot ('box', 'violin', 'bar', 'scatter', 'line')
        confidence_interval: Confidence interval level for metrics that support it
        rarefy: Whether to rarefy samples to even depth
        rarefaction_depth: Depth for rarefaction (if None, uses minimum sample sum)
        rarefaction_repeats: Number of rarefaction repeats
        phylogenetic_tree: Path to phylogenetic tree file (for faith_pd/phydiv)
        input_type: 'auto', 'functional', or 'otu'
        output_file: Output file path for plot
        figsize: Figure size (width, height)
        phydiv_type: Type of phylogenetic diversity metric
        phydiv_theta: Custom theta for phydiv
        phydiv_rooted: Force rooted/unrooted calculation
        stats_annotate: Add statistical annotation (compact letter display)
        stats_alpha: Significance level for statistical tests
        stats_method: Statistical method ('auto', 'parametric', 'nonparametric', etc.)
        stats_footer: Show footer explaining the annotation
        apply_fdr: Apply False Discovery Rate correction for multiple testing
        paired: Whether samples are paired/dependent (e.g., before/after)
        subject_id_col: Column name in metadata for subject IDs (required if paired=True)
        time_col: Column name in metadata for time points (required if paired=True)
    
    Returns:
        DataFrame with calculated alpha diversity metrics
    """
    if not HAS_SKBIO:
        raise ImportError("scikit-bio is required for alpha diversity calculations. ""Install with: pip install scikit-bio")
    
    # Load data if path provided
    if isinstance(functional_profiles, (str, Path)):
        df = pl.read_csv(functional_profiles, separator="\t")
    else:
        df = functional_profiles
    
    # Convert to pandas for easier manipulation
    pdf = df.to_pandas()
    
    # Detect input type if auto
    if input_type == 'auto':
        input_type = detect_input_type(pdf, phylogenetic_tree)
        print(f"  Auto-detected input type: {input_type}")
    
    # Validate phylogenetic metrics
    valid, valid_metrics, warnings = validate_phylogenetic_metrics(metrics, input_type, phylogenetic_tree)
    for warning in warnings:
        print(f"  ⚠ {warning}")
    
    if not valid:
        raise ValueError("No valid metrics after filtering. Please use appropriate metrics for your data type.")
    
    metrics = valid_metrics
    
    # Identify KO/OTU column and sample columns
    exclude_cols = []
    feature_names = None
    
    if input_type == 'functional':
        # For KO data
        ko_col = None
        for col in pdf.columns:
            if col.upper() in ['KO', 'KEGG', 'GENE', 'FUNCTION', 'KO_ID']:
                ko_col = col
                exclude_cols.append(col)
                break
            elif col.lower() in ['description', 'desc', 'ko_description']:
                exclude_cols.append(col)
        
        if ko_col is None:
            ko_col = pdf.columns[0]
            exclude_cols.append(ko_col)
        
        feature_names = pdf[ko_col].tolist()
        
    else:
        # For OTU data
        for col in pdf.columns:
            if col.lower() in ['otu', 'asv', 'taxon', 'taxonomy', 'feature', 'id', 'feature_id']:
                feature_names = pdf[col].tolist()
                exclude_cols.append(col)
                break
            elif col.lower() in ['description', 'taxonomy', 'lineage']:
                exclude_cols.append(col)
        
        # If still no feature_names, use first column
        if feature_names is None:
            feature_names = pdf.iloc[:, 0].tolist()
            exclude_cols.append(pdf.columns[0])
    
    # Get sample columns (numeric columns except excluded)
    sample_cols = []
    for col in pdf.columns:
        if col in exclude_cols:
            continue
        if pd.api.types.is_numeric_dtype(pdf[col]):
            sample_cols.append(col)
    
    if len(sample_cols) < 1:
        raise ValueError("No sample columns found in the data")
    
    print(f"  Found {len(sample_cols)} samples and {pdf.shape[0]} features")
    print(f"  Input type: {input_type}")
    
    # Extract abundance matrix (samples × features)
    abundance_matrix = pdf[sample_cols].T.values
    
    # Load phylogenetic tree if needed
    tree = None
    if phylogenetic_tree and any(m in PHYLOGENETIC_METRICS or m == 'phydiv' for m in metrics):
        try:
            from skbio import TreeNode
            print(f"  Loading phylogenetic tree from: {phylogenetic_tree}")
            tree = TreeNode.read(str(phylogenetic_tree))
            print(f"  Tree loaded with {len(list(tree.tips()))} tips")
        except Exception as e:
            print(f"  ⚠ Failed to load tree: {str(e)}")
            metrics = [m for m in metrics if m not in PHYLOGENETIC_METRICS and m != 'phydiv']
            print(f"  Removed phylogenetic metrics, using: {metrics}")
    
    # Initialize list to track actual column names for plotting
    actual_metric_names = []
    
    # Calculate metrics directly
    diversity_df = pd.DataFrame(index=sample_cols)
    
    for metric in metrics:
        if metric == 'phydiv':
            # Handle phydiv specially
            if phydiv_theta is not None:
                # Custom metric case
                rooted_str = 'r' if phydiv_rooted else 'u' if phydiv_rooted is not None else 'r'
                metric_name = f"{rooted_str}PDw_theta_{str(phydiv_theta).replace('.', '')}"
                values = calculate_alpha_metrics(
                    abundance_matrix, metric, tree, confidence_interval, feature_names,
                    phydiv_type=phydiv_type,
                    phydiv_theta=phydiv_theta,
                    phydiv_rooted=phydiv_rooted
                )
                diversity_df[metric_name] = values
                actual_metric_names.append(metric_name)
                print(f"  Calculated custom metric: {metric_name}")
                
            elif phydiv_type == 'all':
                # For 'all', calculate all 10 metrics
                results_dict = calculate_phydiv_metrics(
                    abundance_matrix, feature_names, tree,
                    metric_type='all',
                    custom_theta=None,
                    force_rooted=phydiv_rooted
                )
                for key, values in results_dict.items():
                    diversity_df[key] = values
                    actual_metric_names.append(key)
                print(f"  Calculated {len(results_dict)} phylogenetic diversity metrics")
                
            else:
                # Standard phydiv type
                values = calculate_alpha_metrics(
                    abundance_matrix, metric, tree, confidence_interval, feature_names,
                    phydiv_type=phydiv_type,
                    phydiv_theta=phydiv_theta,
                    phydiv_rooted=phydiv_rooted
                )
                diversity_df[phydiv_type] = values
                actual_metric_names.append(phydiv_type)
                print(f"  Calculated metric: {phydiv_type}")
        else:
            # Standard metrics
            values = calculate_alpha_metrics(
                abundance_matrix, metric, tree, confidence_interval, feature_names
            )
            diversity_df[metric] = values
            actual_metric_names.append(metric)
    
    # Add metadata if provided
    if metadata is not None:
        common_samples = [s for s in sample_cols if s in metadata.index]
        if len(common_samples) == 0:
            try:
                if metadata.index.name is None:
                    first_col = metadata.columns[0]
                    metadata = metadata.set_index(first_col)
                    common_samples = [s for s in sample_cols if s in metadata.index]
            except:
                pass
        
        if common_samples:
            diversity_df = diversity_df.loc[common_samples]
            for col in metadata.columns:
                if col not in diversity_df.columns:
                    diversity_df[col] = metadata.loc[common_samples, col]
    
    # Determine which columns to plot (use actual metric names)
    plot_metrics = actual_metric_names
    
    # Extract subject IDs and time points for paired analysis if needed
    subject_ids = None
    time_points = None
    if paired and metadata is not None and group_col:
        if subject_id_col is None or time_col is None:
            raise ValueError("subject_id_col and time_col are required when paired=True")
        
        if subject_id_col not in diversity_df.columns:
            raise ValueError(f"Subject ID column '{subject_id_col}' not found in metadata")
        if time_col not in diversity_df.columns:
            raise ValueError(f"Time column '{time_col}' not found in metadata")
        
        subject_ids = diversity_df[subject_id_col].values
        time_points = diversity_df[time_col].values
        print(f"  Paired design detected: {len(np.unique(subject_ids))} subjects, {len(np.unique(time_points))} time points")
    
    # Create plot
    fig, axes = create_alpha_diversity_plot(
        diversity_df, plot_metrics, group_col, plot_type, figsize,
        stats_annotate=stats_annotate,
        stats_alpha=stats_alpha,
        stats_method=stats_method,
        stats_footer=stats_footer,
        apply_fdr=apply_fdr,
        fdr_method=fdr_method,
        paired=paired,
        subject_ids=subject_ids,
        time_points=time_points
    )
    
    # Add title based on phydiv type
    if 'phydiv' in metrics:
        if phydiv_theta is not None:
            title_suffix = f" - Custom (θ={phydiv_theta}, {'rooted' if phydiv_rooted else 'unrooted'})"
        elif phydiv_type == 'all':
            title_suffix = " - All 10 Phylogenetic Diversity Metrics"
        else:
            title_suffix = f" - {phydiv_type}"
        plt.suptitle(f'Alpha Diversity Metrics{title_suffix}', y=1.02, fontsize=16, fontweight='bold')
    else:
        plt.suptitle('Alpha Diversity Metrics', y=1.02, fontsize=16, fontweight='bold')
    
    plt.tight_layout()
    
    if output_file:
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
    
    import matplotlib
    if matplotlib.get_backend() != 'Agg':
        plt.show()
    
    return diversity_df

def add_statistical_annotation(ax, metric, groups, letters, group_col, diversity_df, plot_type, positions=None):
    """
    Add compact letter display to any plot type.
    
    Args:
        ax: matplotlib axis
        metric: metric name
        groups: list of group names
        letters: dict mapping group to letter(s)
        group_col: column name for grouping
        diversity_df: DataFrame with data
        plot_type: type of plot ('box', 'violin', 'bar', 'scatter', 'line')
        positions: optional pre-computed x-positions for groups
    """
    if not letters:
        return
    
    # Get current y-limits
    y_min, y_max = ax.get_ylim()
    y_range = y_max - y_min
    
    # Determine x-positions based on plot type
    if positions is None:
        if plot_type in ['box', 'violin', 'bar']:
            # These typically use 1, 2, 3... positions
            x_positions = {group: i+1 for i, group in enumerate(groups)}
        elif plot_type == 'scatter':
            # Scatter uses categorical positions
            x_positions = {group: i for i, group in enumerate(groups)}
        elif plot_type == 'line':
            # Line plots - use index positions
            x_positions = {group: i for i, group in enumerate(groups)}
        else:
            x_positions = {group: i+1 for i, group in enumerate(groups)}
    else:
        x_positions = positions
    
    # Add letters
    for i, group in enumerate(groups):
        if group in letters:
            # Get x-position
            x_pos = x_positions.get(group, i+1)
            
            # Get data for this group to calculate optimal y-position
            group_data = diversity_df[diversity_df[group_col] == group][metric].dropna()
            if len(group_data) > 0:
                data_max = group_data.max()
                data_min = group_data.min()
                data_range = data_max - data_min
                
                # Calculate y-position based on data or axis limits
                if y_max > data_max:
                    # Use axis limits if they extend beyond data
                    y_pos = y_max - y_range * 0.05
                else:
                    # Place above the highest data point
                    y_pos = data_max + data_range * 0.1
                    # Extend y-limit to include the letter
                    ax.set_ylim(y_min, y_pos + data_range * 0.05)
            else:
                # Fallback: use axis limits
                y_pos = y_max - y_range * 0.05
            
            # Add text with background box
            ax.text(x_pos, y_pos, letters[group], 
                   ha='center', va='bottom', 
                   fontsize=10, fontweight='bold', 
                   bbox=dict(boxstyle='round,pad=0.2', facecolor='white', alpha=0.8, edgecolor='none'))
                   
    
def create_alpha_diversity_plot(
    diversity_df: pd.DataFrame,
    metrics: List[str],
    group_col: Optional[str],
    plot_type: str,
    figsize: tuple,
    stats_annotate: bool = False,
    stats_alpha: float = 0.05,
    stats_method: str = 'auto',
    stats_footer: bool = True,
    verbose_stats: bool = True,
    apply_fdr: bool = True,
    fdr_method: str = 'bh',
    paired: bool = False,
    subject_ids: Optional[np.ndarray] = None,
    time_points: Optional[np.ndarray] = None
) -> Tuple[plt.Figure, np.ndarray]:
    """
    Create alpha diversity plot based on specified type.
    
    Args:
        diversity_df: DataFrame with diversity metrics
        metrics: List of metrics to plot
        group_col: Column for grouping
        plot_type: Type of plot
        figsize: Figure size
        stats_annotate: Add statistical annotation
        stats_alpha: Significance level for statistical tests
        stats_method: Statistical method ('auto', 'parametric', 'nonparametric', etc.)
        stats_footer: Show footer explaining the annotation
        verbose_stats: Print detailed statistical results to console
        apply_fdr: Apply False Discovery Rate correction for multiple testing
        paired: Whether samples are paired/dependent
        subject_ids: Subject IDs for paired designs
        time_points: Time point labels for paired designs
    
    Returns:
        Tuple[plt.Figure, np.ndarray]: (figure, axes_array)
    """
    from scipy.stats import shapiro, levene, f_oneway, kruskal, ttest_ind, mannwhitneyu
    from statsmodels.stats.multicomp import pairwise_tukeyhsd
    from itertools import combinations
    import warnings
    
    n_metrics = len(metrics)
    n_cols = min(3, n_metrics)
    n_rows = (n_metrics + n_cols - 1) // n_cols
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=figsize)
    if n_metrics == 1:
        axes = np.array([axes])
    axes = axes.flatten()
    
    # Hide empty subplots
    for i in range(n_metrics, len(axes)):
        axes[i].set_visible(False)
    
    # Color palette
    if group_col and group_col in diversity_df.columns:
        n_groups = len(diversity_df[group_col].unique())
        colors = sns.color_palette("husl", n_colors=n_groups)
    else:
        colors = sns.color_palette("husl", n_colors=1)
    
    # Calculate compact letter display for each metric if requested
    cld_results = {}
    statistical_results = {}
    
    if stats_annotate and group_col and group_col in diversity_df.columns:
        for metric in metrics:
            if metric in diversity_df.columns:
                data = diversity_df[metric].dropna().values
                groups = diversity_df[group_col].dropna().values
                if len(data) > 0 and len(groups) > 0:
                    cld_results[metric] = calculate_statistical_annotation(
                        data, groups, method=stats_method, alpha=stats_alpha,
                        paired=paired,
                        subject_ids=subject_ids,
                        time_points=time_points
                    )
                    
                    if verbose_stats:
                        statistical_results[metric] = _calculate_full_statistics(
                            data, groups, metric, stats_alpha, stats_method
                        )
    
    # Print detailed statistical report to console
    if verbose_stats and statistical_results:
        _print_alpha_statistical_report(
            statistical_results, 
            stats_alpha, 
            stats_method, 
            apply_fdr=apply_fdr,
            fdr_method=fdr_method
        )
    
    for idx, metric in enumerate(metrics):
        ax = axes[idx]
        
        if group_col and group_col in diversity_df.columns:
            groups = diversity_df[group_col].unique()
            letters = cld_results.get(metric, {})
            
            # Store the maximum y-value across all groups for this metric
            max_y = diversity_df[metric].max()
            min_y = diversity_df[metric].min()
            y_range = max_y - min_y
            y_offset = y_range * 0.1  # 10% above the maximum value
            
            if plot_type == 'box':
                data_to_plot = [diversity_df[diversity_df[group_col] == g][metric].dropna() 
                              for g in groups]
                bp = ax.boxplot(data_to_plot, patch_artist=True, positions=range(1, len(groups)+1))
                for patch, color in zip(bp['boxes'], colors[:len(groups)]):
                    patch.set_facecolor(color)
                ax.set_xticklabels(groups, rotation=45, ha='right')
                
                # Add statistical annotation ABOVE the boxes
                if letters:
                    print(f"  DEBUG: Adding letters for {metric}: {letters}")  # Debug output
                    
                    for i, group in enumerate(groups):
                        if group in letters:
                            group_data = diversity_df[diversity_df[group_col] == group][metric].dropna()
                            if len(group_data) > 0:
                                group_max = group_data.max()
                                # Get current y-limits
                                y_min, y_max = ax.get_ylim()
                                # Place letter at 95% of y-max (inside plot area)
                                y_pos = y_max - (y_max - y_min) * 0.05
                                
                                # Alternative: place just above highest point
                                # y_pos = group_max + (y_max - y_min) * 0.02
                                
                                letter = letters[group]
                                print(f"    Group {group}: letter='{letter}', pos=({i+1}, {y_pos:.4f})")
                                
                                ax.text(i+1, y_pos, letter, 
                                       ha='center', va='bottom', 
                                       fontsize=12, fontweight='bold', 
                                       color='black',  # Explicit color
                                       bbox=dict(boxstyle='round,pad=0.2', 
                                                facecolor='white', 
                                                edgecolor='black', 
                                                alpha=0.9))
                else:
                    print(f"  DEBUG: No letters for {metric}")  # Debug output
            
            elif plot_type == 'violin':
                data_to_plot = [diversity_df[diversity_df[group_col] == g][metric].dropna() 
                              for g in groups]
                parts = ax.violinplot(data_to_plot, positions=range(1, len(groups)+1), 
                                     showmeans=True, showmedians=True)
                for i, pc in enumerate(parts['bodies']):
                    pc.set_facecolor(colors[i % len(colors)])
                    pc.set_alpha(0.7)
                ax.set_xticks(range(1, len(groups) + 1))
                ax.set_xticklabels(groups, rotation=45, ha='right')
                
                if letters:
                    for i, group in enumerate(groups):
                        if group in letters:
                            group_data = diversity_df[diversity_df[group_col] == group][metric].dropna()
                            if len(group_data) > 0:
                                group_max = group_data.max()
                                y_pos = group_max + y_offset
                                ax.text(i+1, y_pos, letters[group], ha='center', va='bottom',
                                       fontsize=12, fontweight='bold',
                                       bbox=dict(boxstyle='round,pad=0.2', facecolor='white',
                                                edgecolor='black', alpha=0.9))
            
            elif plot_type == 'bar':
                means = [diversity_df[diversity_df[group_col] == g][metric].mean() for g in groups]
                stds = [diversity_df[diversity_df[group_col] == g][metric].std() for g in groups]
                x_pos = range(len(groups))
                bars = ax.bar(x_pos, means, yerr=stds, capsize=5, 
                              color=colors[:len(groups)], alpha=0.7)
                ax.set_xticks(x_pos)
                ax.set_xticklabels(groups, rotation=45, ha='right')
                
                if letters:
                    for i, group in enumerate(groups):
                        if group in letters:
                            bar_height = means[i]
                            y_pos = bar_height + stds[i] + y_offset
                            ax.text(i, y_pos, letters[group], ha='center', va='bottom',
                                   fontsize=12, fontweight='bold',
                                   bbox=dict(boxstyle='round,pad=0.2', facecolor='white',
                                            edgecolor='black', alpha=0.9))
            
            elif plot_type == 'scatter':
                for i, g in enumerate(groups):
                    group_data = diversity_df[diversity_df[group_col] == g]
                    ax.scatter([i] * len(group_data), group_data[metric], 
                             color=colors[i], alpha=0.6, s=50, label=g)
                ax.set_xticks(range(len(groups)))
                ax.set_xticklabels(groups, rotation=45, ha='right')
                ax.legend()
                
                if letters:
                    for i, group in enumerate(groups):
                        if group in letters:
                            group_data = diversity_df[diversity_df[group_col] == group][metric].dropna()
                            if len(group_data) > 0:
                                group_max = group_data.max()
                                y_pos = group_max + y_offset
                                ax.text(i, y_pos, letters[group], ha='center', va='bottom',
                                       fontsize=12, fontweight='bold',
                                       bbox=dict(boxstyle='round,pad=0.2', facecolor='white',
                                                edgecolor='black', alpha=0.9))
            
            elif plot_type == 'line':
                for i, g in enumerate(groups):
                    group_data = diversity_df[diversity_df[group_col] == g]
                    x = range(len(group_data))
                    ax.plot(x, group_data[metric].values, 
                          color=colors[i], marker='o', label=g, alpha=0.7)
                ax.set_xlabel('Sample Index')
                ax.legend()
                
                if letters:
                    for i, g in enumerate(groups):
                        if g in letters:
                            group_data = diversity_df[diversity_df[group_col] == g][metric].dropna()
                            if len(group_data) > 0:
                                last_y = group_data.values[-1]
                                y_pos = last_y + y_offset
                                ax.text(len(group_data)-1, y_pos, letters[g], ha='center', va='bottom',
                                       fontsize=12, fontweight='bold',
                                       bbox=dict(boxstyle='round,pad=0.2', facecolor='white',
                                                edgecolor='black', alpha=0.9))
        else:
            # Ungrouped plot - no letters to add
            if plot_type == 'box':
                ax.boxplot(diversity_df[metric].dropna())
                ax.set_xticklabels([metric])
            elif plot_type == 'violin':
                parts = ax.violinplot(diversity_df[metric].dropna(), showmeans=True)
                parts['bodies'][0].set_facecolor(colors[0])
                parts['bodies'][0].set_alpha(0.7)
                ax.set_xticks([1])
                ax.set_xticklabels([metric])
            elif plot_type == 'bar':
                x_pos = range(len(diversity_df))
                ax.bar(x_pos, diversity_df[metric].values, color='steelblue', alpha=0.7)
                ax.set_xlabel('Samples')
                ax.set_xticks(x_pos)
                ax.set_xticklabels(diversity_df.index, rotation=45, ha='right')
            elif plot_type == 'scatter':
                ax.scatter(range(len(diversity_df)), diversity_df[metric].values, 
                         color='steelblue', alpha=0.6, s=50)
                ax.set_xlabel('Samples')
                ax.set_xticks(range(len(diversity_df)))
                ax.set_xticklabels(diversity_df.index, rotation=45, ha='right')
            elif plot_type == 'line':
                ax.plot(diversity_df[metric].values, 'o-', color='steelblue', alpha=0.7)
                ax.set_xlabel('Sample Index')
                ax.set_xticks(range(len(diversity_df)))
                ax.set_xticklabels(diversity_df.index, rotation=45, ha='right')
        
        ax.set_ylabel(metric)
        ax.set_title(metric, fontweight='bold')
        ax.grid(True, alpha=0.3)
        
        # Adjust y-limit to accommodate letters
        if stats_annotate and letters:
            y_min, y_max = ax.get_ylim()
            ax.set_ylim(y_min, y_max + y_offset * 1.5)
    
    # Add footer with statistical annotation info if used
    if stats_annotate and group_col and group_col in diversity_df.columns and stats_footer:
        # Get method description for footer
        method_desc = {
            'auto': 'auto-detected',
            'parametric': 'parametric (ANOVA/t-test)',
            'nonparametric': 'non-parametric (Kruskal-Wallis/Mann-Whitney)',
            't-test': 't-test',
            'mannwhitney': 'Mann-Whitney U',
            'anova': 'ANOVA',
            'kruskal': 'Kruskal-Wallis'
        }.get(stats_method, stats_method)
        
        # Add paired note if applicable
        paired_note = " (paired/dependent design)" if paired else ""
        
        fig.text(0.5, 0.02, 
                f"Statistical annotation: groups sharing the same letter are not significantly different "
                f"(α={stats_alpha}, method={method_desc}{paired_note})",
                ha='center', fontsize=8, style='italic',
                bbox=dict(boxstyle='round,pad=0.2', facecolor='white', alpha=0.8, edgecolor='none'))
    
    return fig, axes

def _calculate_full_statistics(
    data: np.ndarray,
    groups: np.ndarray,
    metric_name: str,
    alpha: float,
    method: str
) -> Dict[str, Any]:
    """
    Calculate comprehensive statistical results for a single metric.
    
    Returns:
        Dict containing all statistical results for console reporting
    """
    unique_groups = np.unique(groups)
    n_groups = len(unique_groups)
    group_data = {g: data[groups == g] for g in unique_groups}
    
    results = {
        'metric': metric_name,
        'n_groups': n_groups,
        'groups': unique_groups.tolist(),
        'group_stats': {},
        'normality': {},
        'assumptions': {},
        'test': None,
        'test_statistic': None,
        'p_value': None,
        'p_value_raw': None,
        'effect_size': None,
        'effect_name': None,
        'significant': False,
        'posthoc': None
    }
    
    # Collect group statistics
    for g in unique_groups:
        g_data = group_data[g]
        results['group_stats'][g] = {
            'n': len(g_data),
            'mean': np.mean(g_data),
            'std': np.std(g_data),
            'median': np.median(g_data),
            'iqr': np.percentile(g_data, 75) - np.percentile(g_data, 25)
        }
    
    # Shapiro-Wilk normality test per group
    normal_groups = []
    for g in unique_groups:
        g_data = group_data[g]
        if len(g_data) >= 3:
            w, p = shapiro(g_data)
            results['normality'][g] = {'statistic': w, 'p_value': p, 'normal': p > alpha}
            normal_groups.append(p > alpha)
        else:
            results['normality'][g] = {'statistic': None, 'p_value': None, 'normal': True}
            normal_groups.append(True)
    
    all_normal = all(normal_groups)
    results['assumptions']['all_normal'] = all_normal
    
    # Levene test for homogeneity of variance
    if all_normal and n_groups >= 2:
        group_data_list = [group_data[g] for g in unique_groups]
        if all(len(d) >= 2 for d in group_data_list):
            stat, p = levene(*group_data_list)
            results['assumptions']['levene'] = {'statistic': stat, 'p_value': p, 'equal_var': p > alpha}
            equal_var = p > alpha
        else:
            results['assumptions']['levene'] = {'error': 'Insufficient samples'}
            equal_var = True
    else:
        results['assumptions']['levene'] = {'skipped': 'Normality violated or <2 groups'}
        equal_var = False
    
    # Determine test based on method and assumptions
    use_parametric = False
    
    if method == 'auto':
        use_parametric = all_normal and equal_var
    elif method in ['parametric', 't-test', 'anova']:
        use_parametric = True
    elif method in ['nonparametric', 'wilcoxon', 'kruskal']:
        use_parametric = False
    
    # Perform statistical test
    if n_groups == 2:
        g1, g2 = unique_groups
        data1 = group_data[g1]
        data2 = group_data[g2]
        
        if use_parametric:
            # t-test
            t_stat, p_val = ttest_ind(data1, data2, equal_var=equal_var)
            results['test'] = 't-test'
            results['test_statistic'] = t_stat
            results['p_value_raw'] = p_val
            results['p_value'] = p_val
            
            # Cohen's d effect size
            pooled_std = np.sqrt(((len(data1)-1)*np.var(data1) + (len(data2)-1)*np.var(data2)) / 
                                 (len(data1)+len(data2)-2))
            results['effect_size'] = (np.mean(data1) - np.mean(data2)) / pooled_std if pooled_std > 0 else 0
            results['effect_name'] = "Cohen's d"
        else:
            # Mann-Whitney U
            u_stat, p_val = mannwhitneyu(data1, data2, alternative='two-sided')
            results['test'] = 'Mann-Whitney U'
            results['test_statistic'] = u_stat
            results['p_value_raw'] = p_val
            results['p_value'] = p_val
            
            # r = Z / sqrt(N) effect size
            n1, n2 = len(data1), len(data2)
            z_score = (u_stat - (n1*n2/2)) / np.sqrt(n1*n2*(n1+n2+1)/12)
            results['effect_size'] = abs(z_score) / np.sqrt(n1 + n2)
            results['effect_name'] = 'r'
    
    else:  # n_groups >= 3
        group_data_list = [group_data[g] for g in unique_groups]
        
        if use_parametric:
            # ANOVA
            f_stat, p_val = f_oneway(*group_data_list)
            results['test'] = 'ANOVA'
            results['test_statistic'] = f_stat
            results['p_value_raw'] = p_val
            results['p_value'] = p_val
            
            # Eta-squared effect size
            grand_mean = np.mean(data)
            ss_between = sum(len(d) * (np.mean(d) - grand_mean)**2 for d in group_data_list)
            ss_total = sum((data - grand_mean)**2)
            results['effect_size'] = ss_between / ss_total if ss_total > 0 else 0
            results['effect_name'] = 'η²'
            
            # Store raw data for post-hoc
            results['posthoc_data'] = {
                'data': data,
                'groups': groups,
                'alpha': alpha
            }
        else:
            # Kruskal-Wallis
            h_stat, p_val = kruskal(*group_data_list)
            results['test'] = 'Kruskal-Wallis'
            results['test_statistic'] = h_stat
            results['p_value_raw'] = p_val
            results['p_value'] = p_val
            
            # Epsilon-squared effect size
            n = len(data)
            k = n_groups
            results['effect_size'] = (h_stat - k + 1) / (n - k) if n > k else 0
            results['effect_name'] = 'ε²'
            
            # Store raw data for post-hoc
            results['posthoc_data'] = {
                'group_data': group_data,
                'groups': unique_groups,
                'alpha': alpha,
                'n_comparisons': n_groups * (n_groups - 1) // 2
            }
    
    return results


def _apply_fdr_correction(
    statistical_results: Dict[str, Dict], 
    alpha: float = 0.05,
    method: str = 'bh'
) -> Dict[str, Dict]:
    """
    Apply multiple testing correction to p-values.
    
    Available methods:
    
    False Discovery Rate (FDR) - Controls expected proportion of false positives:
        'bh'     = Benjamini-Hochberg (1995) - Standard FDR, assumes independence
        'by'     = Benjamini-Yekutieli (2001) - Handles arbitrary dependencies
        'tsbh'   = Two-stage Benjamini-Hochberg - Adaptive, more powerful
        'tsbky'  = Two-stage Benjamini-Yekutieli - Adaptive + dependency handling
    
    Family-wise Error Rate (FWER) - Controls probability of ANY false positive:
        'bonferroni' = Bonferroni - Most conservative: p * m
        'holm'       = Holm-Bonferroni - Step-down, more powerful than Bonferroni
        'sidak'      = Šidák - Assumes independence: 1 - (1 - α)^(1/m)
    
    Other:
        'none'   = No correction
    
    Args:
        statistical_results: Dictionary of results per metric
        alpha: Significance level
        method: Correction method
    
    Returns:
        Updated statistical_results with corrected p-values
    """
    from statsmodels.stats.multitest import multipletests
    import numpy as np
    
    # Collect all raw p-values
    metrics = []
    raw_pvalues = []
    
    for metric_name, results in statistical_results.items():
        if results.get('p_value_raw') is not None:
            metrics.append(metric_name)
            raw_pvalues.append(results['p_value_raw'])
    
    if len(raw_pvalues) == 0:
        return statistical_results
    
    n_tests = len(raw_pvalues)
    
    # Method mapping for statsmodels
    sm_method_map = {
        'bh': 'fdr_bh',
        'by': 'fdr_by',
        'tsbh': 'fdr_tsbh',
        'tsbky': 'fdr_tsbky',
        'bonferroni': 'bonferroni',
        'holm': 'holm',
        'sidak': 'sidak',
    }
    
    # Handle 'none' method
    if method == 'none':
        p_corrected = np.array(raw_pvalues)
        rejected = p_corrected < alpha
        method_name = "None (raw p-values)"
        is_fdr = False
        
    # Use statsmodels for standard methods
    elif method in sm_method_map:
        rejected, p_corrected, _, _ = multipletests(
            raw_pvalues, 
            alpha=alpha, 
            method=sm_method_map[method]
        )
        is_fdr = method in ['bh', 'by', 'tsbh', 'tsbky']
        
        # Get method name for display
        method_names = {
            'bh': 'Benjamini-Hochberg',
            'by': 'Benjamini-Yekutieli',
            'tsbh': 'Two-stage Benjamini-Hochberg',
            'tsbky': 'Two-stage Benjamini-Yekutieli',
            'bonferroni': 'Bonferroni',
            'holm': 'Holm-Bonferroni',
            'sidak': 'Šidák'
        }
        method_name = method_names.get(method, method)
    
    else:
        raise ValueError(f"Unknown correction method: {method}")
    
    # Update results with corrected p-values
    for i, metric_name in enumerate(metrics):
        statistical_results[metric_name]['p_value'] = float(p_corrected[i])
        statistical_results[metric_name]['significant'] = bool(rejected[i])
        statistical_results[metric_name]['correction_method'] = method_name
        statistical_results[metric_name]['correction_type'] = 'FDR' if is_fdr else 'FWER' if method != 'none' else 'none'
        statistical_results[metric_name]['n_tests'] = n_tests
        statistical_results[metric_name]['alpha_raw'] = alpha
    
    return statistical_results
    
    
def _calculate_and_print_posthoc(results: Dict, fdr_applied: bool, alpha: float):
    """
    Calculate and print post-hoc comparisons.
    """
    posthoc_data = results['posthoc_data']
    
    if results['test'] == 'ANOVA':
        # Tukey HSD
        df = pd.DataFrame({'value': posthoc_data['data'], 'group': posthoc_data['groups']})
        tukey = pairwise_tukeyhsd(df['value'], df['group'], alpha=alpha)
        
        print("    Tukey HSD:")
        print(f"    {'Comparison':<20} {'Difference':<12} {'P-value':<12} {'Significant':<12}")
        print("    " + "-" * 60)
        
        for row in tukey.summary().data[1:]:
            g1, g2, diff, p_adj, lower, upper, reject = row[:7]
            p_str = f"{p_adj:.4f}" if p_adj >= 0.0001 else f"{p_adj:.2e}"
            sig_mark = "✓" if reject else "✗"
            print(f"    {g1} vs {g2:<10} {diff:.4f}      {p_str:<12} {sig_mark:<12}")
    
    elif results['test'] == 'Kruskal-Wallis':
        # Pairwise Mann-Whitney with Bonferroni
        group_data = posthoc_data['group_data']
        groups = posthoc_data['groups']
        n_comparisons = posthoc_data['n_comparisons']
        bonferroni_alpha = alpha / n_comparisons
        
        print("    Pairwise Mann-Whitney (Bonferroni corrected):")
        print(f"    {'Comparison':<20} {'U-statistic':<12} {'Raw p':<12} {'Corrected p':<12} {'Significant':<12}")
        print("    " + "-" * 75)
        
        for g1, g2 in combinations(groups, 2):
            data1 = group_data[g1]
            data2 = group_data[g2]
            u_stat, p_raw = mannwhitneyu(data1, data2, alternative='two-sided')
            p_corrected = p_raw * n_comparisons
            
            p_raw_str = f"{p_raw:.4f}" if p_raw >= 0.0001 else f"{p_raw:.2e}"
            p_corr_str = f"{p_corrected:.4f}" if p_corrected >= 0.0001 else f"{p_corrected:.2e}"
            sig_mark = "✓" if p_corrected < alpha else "✗"
            
            print(f"    {g1} vs {g2:<10} {u_stat:.4f}     {p_raw_str:<12} {p_corr_str:<12} {sig_mark:<12}")


def _print_alpha_statistical_report(
    statistical_results: Dict[str, Dict],
    alpha: float,
    method: str,
    apply_fdr: bool = True,
    fdr_method: str = 'bh'
):
    """
    Print comprehensive statistical report to console.
    
    Args:
        statistical_results: Dictionary of results per metric
        alpha: Significance level
        method: Statistical method used
        apply_fdr: Apply multiple testing correction
        fdr_method: Correction method
    """
    # Apply correction if requested
    if apply_fdr and len(statistical_results) > 1:
        statistical_results = _apply_fdr_correction(statistical_results, alpha, fdr_method)
        correction_applied = True
    else:
        correction_applied = False
    
    # Get correction info
    correction_info = ""
    if correction_applied:
        first_result = next(iter(statistical_results.values()))
        correction_method = first_result.get('correction_method', fdr_method)
        correction_type = first_result.get('correction_type', 'FDR')
        n_tests = first_result.get('n_tests', len(statistical_results))
        correction_info = f"Multiple testing correction: {correction_method} ({correction_type})\nNumber of tests: {n_tests}"
    
    print("\n" + "="*80)
    print("ALPHA DIVERSITY STATISTICAL REPORT")
    print("="*80)
    print(f"Significance level (α): {alpha}")
    print(f"Statistical test method: {method}")
    if correction_applied:
        print(correction_info)
    print()
    
    # ... rest of the function (same as before) ...
    
    # In the summary table header, indicate correction method
    if correction_applied:
        method_display = {
            'Benjamini-Hochberg': 'FDR (BH)',
            'Benjamini-Yekutieli': 'FDR (BY)',
            'Two-stage Benjamini-Hochberg': 'FDR (TSBH)',
            'Two-stage Benjamini-Yekutieli': 'FDR (TSBKY)',
            'Bonferroni': 'FWER (Bonf)',
            'Holm-Bonferroni': 'FWER (Holm)',
            'Šidák': 'FWER (Šidák)'
        }.get(correction_method, correction_method)
        
        print(f"{'Metric':<20} {'Test':<20} {'Raw p':<12} {'Corr p':<12} {'Method':<12} {'Signif':<8} {'Effect':<10}")
        print("-" * 100)
        
        for metric_name, results in statistical_results.items():
            p_raw = results.get('p_value_raw', results['p_value'])
            p_corr = results['p_value']
            
            p_raw_str = f"{p_raw:.4f}" if p_raw >= 0.0001 else f"{p_raw:.2e}"
            p_corr_str = f"{p_corr:.4f}" if p_corr >= 0.0001 else f"{p_corr:.2e}"
            sig_mark = "✓" if results['significant'] else "✗"
            print(f"{metric_name:<20} {results['test'][:19]:<20} {p_raw_str:<12} {p_corr_str:<12} {method_display:<12} {sig_mark:<8} {results['effect_size']:.4f}")
    else:
        # No correction - original format
        print(f"{'Metric':<20} {'Test':<20} {'P-value':<12} {'Signif':<8} {'Effect Size':<12} {'Effect':<10}")
        print("-" * 80)
        
        for metric_name, results in statistical_results.items():
            p_val = results['p_value']
            p_str = f"{p_val:.4f}" if p_val >= 0.0001 else f"{p_val:.2e}"
            sig_mark = "✓" if results['significant'] else "✗"
            print(f"{metric_name:<20} {results['test'][:19]:<20} {p_str:<12} {sig_mark:<8} {results['effect_size']:.4f}      {results['effect_name']}")
    
    # Add method comparison guidance
    print("\n" + "="*80)
    print("MULTIPLE TESTING CORRECTION GUIDANCE:")
    print("="*80)
    print("""
    ┌────────────────┬────────────────────────────────────────────────────────────────┐
    │ Method         │ When to Use                                                    │
    ├────────────────┼────────────────────────────────────────────────────────────────┤
    │ BH (default)   │ Most common FDR method. Assumes tests are independent or       │
    │                │ positively dependent. Good balance of power and control.       │
    │                │ Recommended for most microbiome studies.                       │
    ├────────────────┼────────────────────────────────────────────────────────────────┤
    │ BY             │ Use when tests may have arbitrary dependencies (e.g.,          │
    │                │ correlated OTUs, redundant KOs). More conservative than BH.    │
    ├────────────────┼────────────────────────────────────────────────────────────────┤
    │ TSBH / TSBKY   │ Adaptive methods that can be more powerful than BH/BY.         │
    │                │ Use with larger sample sizes (n > 20 per group).               │
    ├────────────────┼────────────────────────────────────────────────────────────────┤
    │ Bonferroni     │ Most conservative. Controls probability of ANY false positive. │
    │                │ Use when false positives are extremely costly. Often too       │
    │                │ conservative for microbiome data.                              │
    ├────────────────┼────────────────────────────────────────────────────────────────┤
    │ Holm           │ Step-down improvement on Bonferroni. More powerful while       │
    │                │ still controlling FWER. Good alternative to Bonferroni.        │
    ├────────────────┼────────────────────────────────────────────────────────────────┤
    │ Šidák          │ Slightly less conservative than Bonferroni. Assumes            │
    │                │ independence between tests.                                    │
    ├────────────────┼────────────────────────────────────────────────────────────────┤
    │ None           │ Use raw p-values. Only recommended for exploratory analyses    │
    │                │ or when testing a single hypothesis.                           │
    └────────────────┴────────────────────────────────────────────────────────────────┘
    """)
    print("="*80)
    
    
def plot_alpha_diversity_rarefaction(
    functional_profiles: Union[str, Path, pl.DataFrame],
    max_depth: Optional[int] = None,
    steps: int = 10,
    repeats: int = 10,
    metrics: List[str] = ['sobs', 'shannon'],
    confidence_interval: float = 0.95,
    separate_plots: bool = False,
    output_file: Optional[str] = None,
    figsize: tuple = (12, 8)
) -> plt.Figure:
    """Plot rarefaction curves for alpha diversity metrics."""
    if not HAS_SKBIO:
        raise ImportError("scikit-bio is required for rarefaction curves. "
                         "Install with: pip install scikit-bio")
    
    from skbio.diversity import alpha as skbio_alpha
    
    if isinstance(functional_profiles, (str, Path)):
        df = pl.read_csv(functional_profiles, separator="\t")
    else:
        df = functional_profiles
    
    pdf = df.to_pandas()
    
    ko_col = None
    for col in pdf.columns:
        if col.upper() in ['KO', 'KEGG', 'GENE', 'FUNCTION']:
            ko_col = col
            break
    
    if ko_col is None:
        ko_col = pdf.columns[0]
    
    exclude_cols = [ko_col, 'description', 'pathway', 'ko_description']
    sample_cols = []
    for col in pdf.columns:
        if col in exclude_cols:
            continue
        if pd.api.types.is_numeric_dtype(pdf[col]):
            sample_cols.append(col)
    
    n_samples = len(sample_cols)
    print(f"  Found {n_samples} samples and {pdf.shape[0]} features")
    
    sample_depths = pdf[sample_cols].sum()
    
    if max_depth is None:
        max_depth = int(sample_depths.min())
        print(f"  Using max depth: {max_depth} (minimum sample sum)")
    else:
        print(f"  Using max depth: {max_depth}")
    
    depth_steps = np.linspace(100, max_depth, steps, dtype=int)
    print(f"  Evaluating at {steps} depth points: {depth_steps[0]}-{depth_steps[-1]}")
    
    rarefaction_results = {metric: {sample: [] for sample in sample_cols} for metric in metrics}
    
    print(f"  Performing rarefaction with {repeats} repeats...")
    from tqdm import tqdm
    
    for sample_idx, sample in enumerate(tqdm(sample_cols, desc="  Processing samples")):
        abundances = pdf[sample].values
        total = int(abundances.sum())
        
        if total < depth_steps[0]:
            print(f"  ⚠ Sample {sample} has low depth ({total}), skipping...")
            continue
        
        for depth in depth_steps:
            if total >= depth:
                probs = abundances / total if total > 0 else np.ones_like(abundances) / len(abundances)
                metric_values = {metric: [] for metric in metrics}
                
                for repeat in range(repeats):
                    rarefied = np.random.multinomial(depth, probs)
                    
                    for metric in metrics:
                        try:
                            if metric == 'sobs':
                                val = np.sum(rarefied > 0)
                            elif metric == 'shannon':
                                val = skbio_alpha.shannon(rarefied)
                            elif metric == 'simpson':
                                val = skbio_alpha.simpson(rarefied)
                            elif metric == 'inv_simpson':
                                val = skbio_alpha.inv_simpson(rarefied)
                            elif metric == 'chao1':
                                val = skbio_alpha.chao1(rarefied)
                            elif metric == 'ace':
                                val = skbio_alpha.ace(rarefied)
                            elif metric == 'pielou_e':
                                val = skbio_alpha.pielou_e(rarefied)
                            elif metric == 'fisher_alpha':
                                val = skbio_alpha.fisher_alpha(rarefied)
                            elif metric == 'berger_parker_d':
                                val = skbio_alpha.berger_parker_d(rarefied)
                            else:
                                val = getattr(skbio_alpha, metric)(rarefied)
                            
                            metric_values[metric].append(val)
                        except Exception as e:
                            pass
                
                for metric in metrics:
                    if metric_values[metric]:
                        values = np.array(metric_values[metric])
                        mean_val = np.mean(values)
                        ci_lower = np.percentile(values, (1 - confidence_interval) * 100 / 2)
                        ci_upper = np.percentile(values, 100 - (1 - confidence_interval) * 100 / 2)
                        
                        rarefaction_results[metric][sample].append({
                            'depth': depth,
                            'mean': mean_val,
                            'ci_lower': ci_lower,
                            'ci_upper': ci_upper
                        })
    
    if separate_plots:
        figs = []
        for metric in metrics:
            fig, ax = plt.subplots(figsize=figsize)
            
            for sample in sample_cols:
                if rarefaction_results[metric][sample]:
                    data = rarefaction_results[metric][sample]
                    depths = [d['depth'] for d in data]
                    means = [d['mean'] for d in data]
                    ci_lower = [d['ci_lower'] for d in data]
                    ci_upper = [d['ci_upper'] for d in data]
                    
                    ax.plot(depths, means, 'o-', label=sample, alpha=0.7, linewidth=2)
                    ax.fill_between(depths, ci_lower, ci_upper, alpha=0.2)
            
            ax.set_xlabel('Sequencing Depth', fontsize=12)
            ax.set_ylabel(metric.replace('_', ' ').title(), fontsize=12)
            ax.set_title(f'{metric.replace("_", " ").title()} Rarefaction Curve', 
                        fontsize=14, fontweight='bold')
            ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
            ax.grid(True, alpha=0.3)
            
            plt.tight_layout()
            
            if output_file and len(metrics) == 1:
                plt.savefig(output_file, dpi=300, bbox_inches='tight')
            
            figs.append(fig)
        
        if output_file and len(metrics) > 1:
            base, ext = os.path.splitext(output_file)
            for i, (metric, fig) in enumerate(zip(metrics, figs)):
                metric_file = f"{base}_{metric}{ext}"
                fig.savefig(metric_file, dpi=300, bbox_inches='tight')
                print(f"  Saved: {metric_file}")
        
        return figs[0] if len(figs) == 1 else figs
    
    else:
        n_metrics = len(metrics)
        n_cols = min(2, n_metrics)
        n_rows = (n_metrics + n_cols - 1) // n_cols
        
        fig, axes = plt.subplots(n_rows, n_cols, figsize=figsize)
        if n_metrics == 1:
            axes = np.array([axes])
        axes = axes.flatten()
        
        for i in range(n_metrics, len(axes)):
            axes[i].set_visible(False)
        
        colors = plt.cm.tab20(np.linspace(0, 1, len(sample_cols)))
        
        for idx, metric in enumerate(metrics):
            ax = axes[idx]
            
            for sample_idx, sample in enumerate(sample_cols):
                if rarefaction_results[metric][sample]:
                    data = rarefaction_results[metric][sample]
                    depths = [d['depth'] for d in data]
                    means = [d['mean'] for d in data]
                    ci_lower = [d['ci_lower'] for d in data]
                    ci_upper = [d['ci_upper'] for d in data]
                    
                    color = colors[sample_idx % len(colors)]
                    ax.plot(depths, means, 'o-', color=color, 
                           label=sample if idx == 0 else "", 
                           alpha=0.7, linewidth=2)
                    ax.fill_between(depths, ci_lower, ci_upper, 
                                   color=color, alpha=0.15)
            
            ax.set_xlabel('Sequencing Depth', fontsize=10)
            ax.set_ylabel(metric.replace('_', ' ').title(), fontsize=10)
            ax.set_title(metric.replace('_', ' ').title(), fontweight='bold')
            ax.grid(True, alpha=0.3)
            
            if idx == 0:
                ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=8)
        
        plt.suptitle('Alpha Diversity Rarefaction Curves', y=1.02, 
                    fontsize=16, fontweight='bold')
        plt.tight_layout()
        
        if output_file:
            plt.savefig(output_file, dpi=300, bbox_inches='tight')
        
        import matplotlib
        if matplotlib.get_backend() != 'Agg':
            plt.show()
        return fig


def plot_beta_diversity(
    functional_profiles,
    metadata=None,
    color_col=None,
    method='pca',
    distance_metric=None,
    phylogenetic_tree=None,
    input_type='auto',
    nmds_trials=10,
    nmds_max_iter=500,
    output_file=None,
    figsize=(10, 8),
    return_stats=True,
    show_stats=False,
    stats_alpha=0.3,
    # Hull parameters
    add_hulls: bool = False,
    hull_style: str = 'concave',
    hull_alpha: float = 0.25,
    hull_linewidth: float = 2.0,
    hull_concavity: float = 2.0,
    hull_expand: float = 0.02,
    # Centroids and labels
    add_centroids: bool = False,
    centroid_marker: str = 'X',
    centroid_size: int = 200,
    centroid_linewidth: int = 2,
    add_labels: bool = False,
    label_size: int = 10,
    # Outlier detection
    highlight_outliers: bool = False,
    outlier_threshold: float = 0,
    outlier_marker: str = 'o',
    outlier_edgecolor: str = 'red',
    outlier_facecolor: str = 'none',
    outlier_size: int = 150,
    outlier_linewidth: float = 3.0,
    # Avoid cluttering and overlapping labels
    label_avoid_overlap: bool = False,
    label_arrow: bool = False,        
    label_arrow_color: str = 'gray',
    # Label adjustment and control
    label_expand_points: float = 1.2,
    label_expand_text: float = 1.2,
    label_force_points: float = 0.5,
    label_force_text: float = 0.5,
    label_bg_alpha: float = 0.85
):
    """
    Plot beta diversity using dimensionality reduction.
    Supports both KO functional and OTU taxonomic data with phylogenetic tree.
    """
    from sklearn.decomposition import PCA
    from sklearn.manifold import TSNE, MDS
    from scipy.spatial.distance import pdist, squareform
    import umap
    import polars as pl
    import pandas as pd
    import numpy as np
    import matplotlib.pyplot as plt
    from matplotlib.patches import Polygon as MPLPolygon
    import warnings
    from pathlib import Path
    
    from pyTax4Fun2.beta_stats import (
        PHYLOGENETIC_DISTANCE_METRICS,
        unweighted_unifrac_pairwise,
        weighted_unifrac_pairwise,
        unweighted_unifrac_normalized_pairwise,
        weighted_unifrac_normalized_pairwise,
        aitchison_pairwise,
        kulczynski1_pairwise,
        format_clustering_report,
        cluster_quality_from_distance_matrix
    )
    from pyTax4Fun2.plot_diversity import detect_input_type, load_phylogenetic_tree
    
    # Prepare data
    if isinstance(functional_profiles, (str, Path)):
        functional_profiles = pl.read_csv(functional_profiles, separator="\t")
    
    pdf = functional_profiles.to_pandas()
    
    # Detect input type if auto
    if input_type == 'auto':
        input_type = detect_input_type(pdf, phylogenetic_tree)
        print(f"  Auto-detected input type: {input_type}")
    
    # Identify sample columns
    exclude_cols = []
    feature_names = None
    
    if input_type == 'functional':
        # For KO data
        ko_col = None
        for col in pdf.columns:
            if col.upper() in ['KO', 'KEGG', 'GENE', 'FUNCTION', 'KO_ID']:
                ko_col = col
                exclude_cols.append(col)
                break
            elif col.lower() in ['description', 'desc', 'ko_description']:
                exclude_cols.append(col)
        
        if ko_col is None:
            ko_col = pdf.columns[0]
            exclude_cols.append(ko_col)
        
        feature_names = pdf[ko_col].tolist()
        
    else:
        # For OTU data
        for col in pdf.columns:
            if col.lower() in ['otu', 'asv', 'taxon', 'taxonomy', 'feature', 'id', 'feature_id']:
                feature_names = pdf[col].tolist()
                exclude_cols.append(col)
                break
            elif col.lower() in ['description', 'taxonomy', 'lineage']:
                exclude_cols.append(col)
        
        if feature_names is None:
            feature_names = pdf.iloc[:, 0].tolist()
            exclude_cols.append(pdf.columns[0])
    
    sample_cols = []
    for col in pdf.columns:
        if col in exclude_cols:
            continue
        if pd.api.types.is_numeric_dtype(pdf[col]):
            sample_cols.append(col)
    
    if len(sample_cols) < 2:
        raise ValueError(f"Need at least 2 samples, found {len(sample_cols)}")
    
    print(f"  Found {len(sample_cols)} samples")
    print(f"  Input type: {input_type}")
    
    X = pdf[sample_cols].T.values
    sample_names = sample_cols
    
    stats = {
        'method': method,
        'n_samples': len(sample_cols),
        'n_features': X.shape[1],
        'distance_metric': distance_metric,
        'sample_names': sample_cols,
        'input_type': input_type,
        'coordinates': None,
        'eigenvalues': None,
        'variance_explained': None,
        'stress': None,
        'silhouette': None,
        'calinski_harabasz': None,
        'davies_bouldin': None,
        'shepard_correlation': None,
        'feature_contributions': None,
        'convergence': None,
        'iterations': None,
        'metadata_correlations': {},
        'outlier_samples': {}
    }
    
    use_distance = distance_metric is not None
    
    # Load phylogenetic tree if needed
    tree = None
    if distance_metric and distance_metric in PHYLOGENETIC_DISTANCE_METRICS:
        if input_type == 'functional':
            print(f"  ⚠ Metric '{distance_metric}' is phylogenetic and not applicable to KO functional data. Falling back to Euclidean distance.")
            distance_metric = 'euclidean'
            use_distance = True
        elif phylogenetic_tree is None:
            raise ValueError(f"Phylogenetic tree required for metric: {distance_metric}")
        else:
            try:
                tree = load_phylogenetic_tree(phylogenetic_tree)
                print(f"  Tree loaded with {len(list(tree.tips()))} tips")
            except Exception as e:
                print(f"  ⚠ Failed to load phylogenetic tree: {str(e)}")
                print(f"  Falling back to Bray-Curtis distance")
                distance_metric = 'braycurtis'
                use_distance = True
                tree = None
    
    distances = None
    condensed_distances = None
    
    if use_distance and method.lower() not in ['pca']:
        print(f"  Computing {distance_metric} distance matrix...")
        try:
            if distance_metric in PHYLOGENETIC_DISTANCE_METRICS and tree is not None:
                if distance_metric == 'unweighted_unifrac':
                    condensed_distances = unweighted_unifrac_pairwise(
                        X, tree, sample_names, taxa_ids=feature_names
                    )
                elif distance_metric == 'unweighted_unifrac_normalized':
                    condensed_distances = unweighted_unifrac_normalized_pairwise(
                        X, tree, sample_names, taxa_ids=feature_names
                    )
                elif distance_metric == 'weighted_unifrac':
                    condensed_distances = weighted_unifrac_pairwise(
                        X, tree, sample_names, taxa_ids=feature_names, normalized=False
                    )
                elif distance_metric == 'weighted_unifrac_normalized':
                    condensed_distances = weighted_unifrac_normalized_pairwise(
                        X, tree, sample_names, taxa_ids=feature_names
                    )
                else:
                    condensed_distances = pdist(X, metric=distance_metric)
            elif distance_metric == 'aitchison':
                condensed_distances = aitchison_pairwise(X)
            elif distance_metric == 'kulczynski1':
                binary_mode = (input_type == 'otu')
                condensed_distances = kulczynski1_pairwise(X, binary_mode=binary_mode)
            else:
                condensed_distances = pdist(X, metric=distance_metric)
            
            distances = squareform(condensed_distances)
            print(f"  Distance matrix shape: {distances.shape}")
            
            stats['distance_matrix'] = distances
            stats['condensed_distances'] = condensed_distances
            stats['distance_metric'] = distance_metric
            
        except Exception as e:
            print(f"  ⚠ Failed to compute {distance_metric} distances: {str(e)}")
            fallback_metric = 'braycurtis' if input_type == 'otu' else 'euclidean'
            print(f"  Falling back to {fallback_metric} distance")
            condensed_distances = pdist(X, metric=fallback_metric)
            distances = squareform(condensed_distances)
            distance_metric = fallback_metric
            stats['distance_metric'] = distance_metric
    
    # ============= ORDINATION =============
    if method.lower() == 'pca':
        reducer = PCA(n_components=min(10, X.shape[0], X.shape[1]))
        coords = reducer.fit_transform(X)
        
        stats.update({
            'eigenvalues': reducer.explained_variance_,
            'variance_explained': reducer.explained_variance_ratio_,
            'cumulative_variance': np.cumsum(reducer.explained_variance_ratio_),
            'components': reducer.components_,
            'singular_values': reducer.singular_values_,
            'noise_variance': reducer.noise_variance_,
            'n_components': reducer.n_components_
        })
        
        variance = reducer.explained_variance_ratio_
        xlabel = f'PC1 ({variance[0]:.1%})'
        ylabel = f'PC2 ({variance[1]:.1%})'
        title = f'PCA of {"OTU" if input_type == "otu" else "Functional"} Profiles'
        plot_coords = coords[:, :2]
        
    elif method.lower() == 'pcoa':
        if not use_distance:
            metric = 'braycurtis' if input_type == 'otu' else 'braycurtis'
            print(f"  No distance metric specified, using {metric} for PCoA")
            condensed = pdist(X, metric=metric)
            distances = squareform(condensed)
            distance_metric = metric
            stats['distance_metric'] = distance_metric
        
        reducer = MDS(
            n_components=min(10, len(sample_cols)-1),
            dissimilarity='precomputed',
            random_state=42,
            n_init=4,
            max_iter=300,
            metric=True,
            eps=1e-4,
            verbose=0
        )
        
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            coords = reducer.fit_transform(distances)
        
        n = distances.shape[0]
        J = np.eye(n) - np.ones((n, n)) / n
        B = -0.5 * J @ (distances**2) @ J
        eigenvalues, eigenvectors = np.linalg.eigh(B)
        
        idx = np.argsort(eigenvalues)[::-1]
        eigenvalues = eigenvalues[idx]
        eigenvectors = eigenvectors[:, idx]
        
        positive_eigenvals = eigenvalues[eigenvalues > 0]
        if len(positive_eigenvals) > 0:
            variance_explained = positive_eigenvals / positive_eigenvals.sum()
        else:
            variance_explained = np.zeros(len(eigenvalues))
        
        stats.update({
            'eigenvalues': eigenvalues,
            'variance_explained': variance_explained,
            'cumulative_variance': np.cumsum(variance_explained),
            'stress': reducer.stress_ if hasattr(reducer, 'stress_') else None,
            'dissimilarity_matrix': distances,
            'n_components': reducer.n_components
        })
        
        from scipy.stats import spearmanr
        fitted_distances = pdist(coords, metric='euclidean')
        stats['shepard_correlation'] = spearmanr(condensed_distances, fitted_distances)[0]
        
        xlabel = f'PCoA1 ({variance_explained[0]:.1%})' if len(variance_explained) > 0 else 'PCoA1'
        ylabel = f'PCoA2 ({variance_explained[1]:.1%})' if len(variance_explained) > 1 else 'PCoA2'
        title = f'PCoA of {"OTU" if input_type == "otu" else "Functional"} Profiles (metric: {distance_metric})'
        plot_coords = coords[:, :2]
    
    elif method.lower() == 'tsne':
        if use_distance:
            reducer = TSNE(
                n_components=2,
                metric='precomputed',
                random_state=42,
                perplexity=min(30, len(sample_cols)-1),
                early_exaggeration=12,
                learning_rate='auto',
                n_iter=1000,
                n_iter_without_progress=300,
                min_grad_norm=1e-7,
                init='random',
                verbose=0
            )
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                plot_coords = reducer.fit_transform(distances)
            
            stats.update({
                'kl_divergence': reducer.kl_divergence_,
                'n_iter': reducer.n_iter_,
                'perplexity': reducer.perplexity,
                'n_components': 2
            })
        else:
            reducer = TSNE(
                n_components=2,
                random_state=42,
                perplexity=min(30, len(sample_cols)-1),
                early_exaggeration=12,
                learning_rate='auto',
                n_iter=1000,
                n_iter_without_progress=300,
                min_grad_norm=1e-7,
                init='random',
                verbose=0
            )
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                plot_coords = reducer.fit_transform(X)
            
            stats.update({
                'kl_divergence': reducer.kl_divergence_,
                'n_iter': reducer.n_iter_,
                'perplexity': reducer.perplexity,
                'n_components': 2
            })
        
        xlabel = 't-SNE 1'
        ylabel = 't-SNE 2'
        title = f't-SNE of {"OTU" if input_type == "otu" else "Functional"} Profiles'
        if use_distance:
            title += f' (metric: {distance_metric})'
    
    elif method.lower() == 'umap':
        if use_distance:
            reducer = umap.UMAP(
                n_components=2,
                metric='precomputed',
                random_state=42,
                n_neighbors=min(15, len(sample_cols)-1),
                min_dist=0.1,
                spread=1.0,
                negative_sample_rate=5,
                init='spectral',
                n_epochs=200,
                learning_rate=1.0,
                verbose=False
            )
            plot_coords = reducer.fit_transform(distances)
            
            stats.update({
                'n_neighbors': reducer.n_neighbors,
                'min_dist': reducer.min_dist,
                'spread': reducer.spread,
                'n_components': 2
            })
        else:
            reducer = umap.UMAP(
                n_components=2,
                random_state=42,
                n_neighbors=min(15, len(sample_cols)-1),
                min_dist=0.1,
                spread=1.0,
                negative_sample_rate=5,
                init='spectral',
                n_epochs=200,
                learning_rate=1.0,
                verbose=False
            )
            plot_coords = reducer.fit_transform(X)
            
            stats.update({
                'n_neighbors': reducer.n_neighbors,
                'min_dist': reducer.min_dist,
                'spread': reducer.spread,
                'n_components': 2
            })
        
        xlabel = 'UMAP 1'
        ylabel = 'UMAP 2'
        title = f'UMAP of {"OTU" if input_type == "otu" else "Functional"} Profiles'
        if use_distance:
            title += f' (metric: {distance_metric})'
    
    elif method.lower() == 'nmds':
        if not use_distance:
            metric = 'braycurtis' if input_type == 'otu' else 'braycurtis'
            print(f"  No distance metric specified, using {metric} for NMDS")
            condensed = pdist(X, metric=metric)
            distances = squareform(condensed)
            condensed_distances = condensed
            distance_metric = metric
            stats['distance_metric'] = distance_metric
            stats['condensed_distances'] = condensed_distances
            stats['distance_matrix'] = distances
        
        best_stress = float('inf')
        best_coords = None
        best_reducer = None
        all_stresses = []
        
        print(f"  Running NMDS with {nmds_trials} random starts...")
        
        for i in range(nmds_trials):
            nmds = MDS(
                n_components=2,
                dissimilarity='precomputed',
                random_state=i,
                max_iter=nmds_max_iter,
                eps=1e-4,
                n_init=4,
                metric=False,
                verbose=0
            )
            
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                coords_try = nmds.fit_transform(distances)
            
            stress = nmds.stress_
            all_stresses.append(stress)
            
            if stress < best_stress:
                best_stress = stress
                best_coords = coords_try
                best_reducer = nmds
                print(f"    Start {i+1}: stress = {stress:.4f}")
        
        plot_coords = best_coords
        
        from scipy.stats import spearmanr, pearsonr
        fitted_distances = pdist(plot_coords, metric='euclidean')
        
        original_distances = stats.get('condensed_distances')
        if original_distances is None:
            original_distances = squareform(distances, checks=False)
        
        shepard_corr_spearman = spearmanr(original_distances, fitted_distances)[0]
        shepard_corr_pearson = pearsonr(original_distances, fitted_distances)[0]
        
        stats.update({
            'stress': best_stress,
            'stress_normalized': best_stress / (len(sample_cols) * (len(sample_cols)-1) / 2),
            'all_stresses': all_stresses,
            'stress_mean': np.mean(all_stresses),
            'stress_std': np.std(all_stresses),
            'stress_min': np.min(all_stresses),
            'stress_max': np.max(all_stresses),
            'shepard_correlation_spearman': shepard_corr_spearman,
            'shepard_correlation_pearson': shepard_corr_pearson,
            'convergence': best_reducer.n_iter_ < best_reducer.max_iter if best_reducer else False,
            'iterations': best_reducer.n_iter_ if best_reducer else None,
            'dissimilarity_matrix': distances,
            'n_trials': nmds_trials,
            'best_trial': np.argmin(all_stresses) + 1,
            'n_components': 2
        })
        
        if best_stress < 0.05:
            stats['stress_quality'] = 'Excellent - no risk of misinterpretation'
        elif best_stress < 0.1:
            stats['stress_quality'] = 'Good - reliable ordination'
        elif best_stress < 0.2:
            stats['stress_quality'] = 'Fair - usable but with caution'
        elif best_stress < 0.3:
            stats['stress_quality'] = 'Poor - questionable reliability'
        else:
            stats['stress_quality'] = 'Very poor - arbitrary configuration'
        
        xlabel = 'NMDS1'
        ylabel = 'NMDS2'
        title = f'NMDS of {"OTU" if input_type == "otu" else "Functional"} Profiles (stress = {best_stress:.3f})'
    
    else:
        raise ValueError(f"Unknown method: {method}")
    
    stats['coordinates'] = plot_coords
    
    # ============= SILHOUETTE SCORES (only if distance matrix exists) =============
    silhouette_per_sample = {}
    if metadata is not None and color_col and color_col in metadata.columns and distances is not None:
        try:
            from pyTax4Fun2.beta_stats import cluster_quality_from_distance_matrix
            from sklearn.preprocessing import LabelEncoder
            
            colors_meta = metadata.loc[sample_cols, color_col]
            le = LabelEncoder()
            labels = le.fit_transform(colors_meta)
            
            # Use the distance matrix to compute silhouette
            quality_results = cluster_quality_from_distance_matrix(
                distances, 
                labels,
                sample_cols
            )
            
            if 'silhouette_per_sample' in quality_results:
                silhouette_per_sample = quality_results['silhouette_per_sample']
                stats['silhouette_per_sample'] = silhouette_per_sample
                stats['silhouette'] = quality_results.get('silhouette', 0)
                
                # Use outlier_threshold
                outlier_samples = {
                    sample: score for sample, score in silhouette_per_sample.items() 
                    if score < outlier_threshold
                }
                stats['outlier_samples'] = outlier_samples
                print(f"  Found {len(outlier_samples)} outlier(s): {list(outlier_samples.keys())}")
                        
                stats['label_mapping'] = {int(k): v for k, v in enumerate(le.classes_)}
        except ImportError:
            print("  ⚠ scikit-learn not installed. Install with: pip install scikit-learn")
        except Exception as e:
            print(f"  ⚠ Could not calculate silhouette score: {str(e)}")
    
    if metadata is not None:
        for col in metadata.columns:
            if col != color_col and pd.api.types.is_numeric_dtype(metadata[col]):
                try:
                    from scipy.stats import pearsonr, spearmanr
                    for axis_idx in range(min(2, plot_coords.shape[1])):
                        axis_name = ['Axis1', 'Axis2'][axis_idx]
                        axis_values = plot_coords[:, axis_idx]
                        metadata_values = metadata.loc[sample_cols, col].values
                        
                        pearson_corr, pearson_p = pearsonr(axis_values, metadata_values)
                        spearman_corr, spearman_p = spearmanr(axis_values, metadata_values)
                        
                        stats['metadata_correlations'][f'{col}_{axis_name}'] = {
                            'pearson': {'correlation': pearson_corr, 'p_value': pearson_p},
                            'spearman': {'correlation': spearman_corr, 'p_value': spearman_p}
                        }
                except Exception:
                    pass
    
    # Create plot
    fig, ax = plt.subplots(figsize=figsize)
    
    # Get colors for groups
    if metadata is not None and color_col and color_col in metadata.columns:
        colors_meta = metadata.loc[sample_cols, color_col]
        
        if pd.api.types.is_categorical_dtype(colors_meta) or colors_meta.dtype == 'object':
            unique_cats = colors_meta.unique()
            if len(unique_cats) <= 10:
                color_map = plt.cm.tab10(np.linspace(0, 1, len(unique_cats)))
            else:
                color_map = plt.cm.tab20(np.linspace(0, 1, len(unique_cats)))
            group_colors = {cat: color_map[i] for i, cat in enumerate(unique_cats)}
            
            # ============= HULL DRAWING =============
            if add_hulls:
                print("  Drawing hulls...")
                use_concave = (hull_style == 'concave')
                if use_concave:
                    try:
                        import alphashape
                        HAS_ALPHASHAPE = True
                    except ImportError:
                        print("  ⚠ alphashape not installed. Falling back to convex hulls.")
                        print("    Install with: pip install alphashape shapely")
                        use_concave = False
                
                for cat in unique_cats:
                    mask = colors_meta == cat
                    group_points = plot_coords[mask.values]
                    
                    if len(group_points) < 3:
                        if len(group_points) > 0:
                            print(f"  Warning: Not enough points for hull in group {cat} (n={len(group_points)}, need ≥3)")
                        continue
                    
                    if use_concave and len(group_points) < 4:
                        print(f"  Note: Group {cat} has only {len(group_points)} points. Using convex hull (concave requires ≥4 for reliable results)")
                        use_concave_for_group = False
                    else:
                        use_concave_for_group = use_concave
                    
                    hull_vertices = None
                    
                    if use_concave_for_group:
                        alpha = max(0.05, min(0.5, 0.25 * (5.0 / max(1.0, hull_concavity))))
                        alpha_tried = []
                        success = False
                        
                        for attempt_alpha in [alpha, alpha * 0.8, alpha * 1.2, 0.3, 0.2, 0.15, 0.1]:
                            if round(attempt_alpha, 3) in [round(a, 3) for a in alpha_tried]:
                                continue
                            alpha_tried.append(attempt_alpha)
                            
                            try:
                                concave_hull = alphashape.alphashape(group_points, attempt_alpha)
                                
                                if concave_hull.is_empty:
                                    continue
                                
                                if concave_hull.geom_type == 'Polygon':
                                    hull_vertices = np.array(concave_hull.exterior.coords)
                                    success = True
                                    if abs(attempt_alpha - alpha) > 0.01:
                                        print(f"    Using adjusted alpha={attempt_alpha:.3f} for {cat}")
                                    break
                                    
                                elif concave_hull.geom_type == 'MultiPolygon':
                                    polygons = list(concave_hull.geoms)
                                    if polygons:
                                        valid_polygons = [p for p in polygons if p.area > 0.01]
                                        if valid_polygons:
                                            largest = max(valid_polygons, key=lambda p: p.area)
                                            hull_vertices = np.array(largest.exterior.coords)
                                            success = True
                                            break
                                            
                                elif concave_hull.geom_type == 'GeometryCollection':
                                    polygons = [geom for geom in concave_hull.geoms if geom.geom_type == 'Polygon']
                                    if polygons:
                                        largest = max(polygons, key=lambda p: p.area)
                                        hull_vertices = np.array(largest.exterior.coords)
                                        success = True
                                        break
                                        
                            except Exception:
                                continue
                        
                        if not success:
                            print(f"    Could not create concave hull for {cat}, using convex hull")
                            use_concave_for_group = False
                    
                    if not use_concave_for_group:
                        from scipy.spatial import ConvexHull
                        try:
                            hull = ConvexHull(group_points)
                            hull_vertices = group_points[hull.vertices]
                        except Exception as e:
                            print(f"    Convex hull failed for {cat}: {str(e)}")
                            hull_vertices = None
                    
                    if hull_vertices is not None:
                        if hull_expand > 0:
                            center = np.mean(hull_vertices, axis=0)
                            hull_vertices = center + (hull_vertices - center) * (1 + hull_expand)
                        
                        polygon = MPLPolygon(
                            hull_vertices,
                            fill=True,
                            facecolor=group_colors[cat],
                            edgecolor=group_colors[cat],
                            alpha=hull_alpha,
                            linewidth=hull_linewidth,
                            linestyle='-',
                            zorder=1
                        )
                        ax.add_patch(polygon)
                        print(f"    Drew {hull_style} hull for {cat} with {len(hull_vertices)} vertices")
            
            # ============= SCATTER POINTS =============
            print("  Drawing scatter points...")
            for i, cat in enumerate(unique_cats):
                mask = colors_meta == cat
                ax.scatter(
                    plot_coords[mask, 0], plot_coords[mask, 1],
                    label=cat, color=group_colors[cat], s=100, alpha=0.9,
                    edgecolors='black', linewidth=0.8, zorder=5
                )
            
            # ============= CENTROIDS =============
            if add_centroids:
                print("  Drawing centroids...")
                for cat in unique_cats:
                    mask = colors_meta == cat
                    group_points = plot_coords[mask.values]
                    if len(group_points) > 0:
                        centroid = np.mean(group_points, axis=0)
                        ax.scatter(
                            centroid[0], centroid[1],
                            marker=centroid_marker,
                            s=centroid_size,
                            color=group_colors[cat],
                            edgecolors='black',
                            linewidth=centroid_linewidth,
                            zorder=6
                        )
                        
                        if add_labels:
                            ax.annotate(
                                cat,
                                (centroid[0], centroid[1]),
                                xytext=(10, 8),
                                textcoords='offset points',
                                fontsize=label_size,
                                fontweight='bold',
                                bbox=dict(boxstyle='round,pad=0.3', facecolor='white', alpha=0.9, edgecolor='gray'),
                                zorder=7
                            )
            
            # ============= OUTLIER HIGHLIGHTING =============
            if highlight_outliers and silhouette_per_sample:
                outlier_samples = stats.get('outlier_samples', {})
                print(f"  Highlighting {len(outlier_samples)} outlier(s): {list(outlier_samples.keys())}")
                first_outlier = True
                for sample, score in outlier_samples.items():
                    if sample in sample_cols:
                        idx = sample_cols.index(sample)
                        ax.scatter(
                            plot_coords[idx, 0], plot_coords[idx, 1],
                            marker=outlier_marker,
                            s=outlier_size,
                            facecolors=outlier_facecolor,
                            edgecolors=outlier_edgecolor,
                            linewidth=outlier_linewidth,
                            zorder=10,
                            label='Outlier' if first_outlier else ""
                        )
                        first_outlier = False
                        ax.annotate(
                            f"{sample}\n({score:.3f})",
                            (plot_coords[idx, 0], plot_coords[idx, 1]),
                            xytext=(10, 12),
                            textcoords='offset points',
                            fontsize=8,
                            color=outlier_edgecolor,
                            weight='bold',
                            bbox=dict(boxstyle='round,pad=0.2', facecolor='white', alpha=0.9),
                            zorder=11
                        )
            
            # Add legend
            handles, labels = ax.get_legend_handles_labels()
            unique = dict(zip(labels, handles))
            ax.legend(unique.values(), unique.keys(), bbox_to_anchor=(1.05, 1), loc='upper left')
            
        else:
            scatter = ax.scatter(
                plot_coords[:, 0], plot_coords[:, 1],
                c=colors_meta, cmap='viridis', s=100, alpha=0.8,
                edgecolors='black', linewidth=0.5
            )
            plt.colorbar(scatter, ax=ax, label=color_col)
    else:
        ax.scatter(
            plot_coords[:, 0], plot_coords[:, 1],
            alpha=0.7, s=100, c='steelblue',
            edgecolors='black', linewidth=0.5
        )
    
    # Add sample labels for small datasets with optional overlap avoidance
    if len(sample_cols) <= 20:
        if label_avoid_overlap:
            try:
                from adjustText import adjust_text
                
                texts = []
                for i, sample in enumerate(sample_cols):
                    # Create text with background for better readability
                    texts.append(ax.text(
                        plot_coords[i, 0], plot_coords[i, 1],
                        sample, 
                        fontsize=8, 
                        alpha=0.85,
                        bbox=dict(boxstyle='round,pad=0.3', facecolor='white', alpha=0.85, edgecolor='gray', linewidth=0.5)
                    ))
                
                # Adjust labels with better parameters
                adjust_text(
                    texts,
                    # Expansion parameters
                    expand_points=(1.2, 1.2),      # Space from points (default 1.5)
                    expand_text=(1.2, 1.2),        # Space between labels (default 1.5)
                    expand_objects=(1.2, 1.2),     # Space from other objects
                    
                    # Force parameters
                    force_points=(0.5, 0.5),       # Repulsion from points (default 1.0)
                    force_text=(0.5, 0.5),         # Repulsion between labels (default 1.0)
                    
                    # Arrow parameters
                    arrowprops=dict(arrowstyle='->', color=label_arrow_color, alpha=0.6, lw=0.8) if label_arrow else None,
                    
                    # Layout parameters
                    lim=500,                       # Iteration limit (default 500)
                    precision=0.01,               # Precision for optimization
                    only_move={'points': 'y', 'text': 'xy'},  # Allow text to move freely
                    
                    # Avoid moving labels too far
                    save_steps=False,
                    add_arrows=label_arrow
                )
                
                print(f"  Using adjustText with custom parameters (expand_points=1.2, force_points=0.5)")
            except ImportError:
                print("  ⚠ adjustText not installed. Install with: pip install adjustText")
                print("  Falling back to default label placement")
                # Fallback to original method
                for i, sample in enumerate(sample_cols):
                    ax.annotate(
                        sample, (plot_coords[i, 0], plot_coords[i, 1]),
                        fontsize=8, alpha=0.7, xytext=(8, 8),
                        textcoords='offset points', 
                        bbox=dict(boxstyle='round,pad=0.2', facecolor='white', alpha=0.7),
                        zorder=8
                    )
        else:
            # Original method
            for i, sample in enumerate(sample_cols):
                ax.annotate(
                    sample, (plot_coords[i, 0], plot_coords[i, 1]),
                    fontsize=8, alpha=0.7, xytext=(8, 8),
                    textcoords='offset points',
                    bbox=dict(boxstyle='round,pad=0.2', facecolor='white', alpha=0.7),
                    zorder=8
                )
            
    ax.set_xlabel(xlabel, fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.axhline(y=0, color='gray', linestyle='--', alpha=0.3)
    ax.axvline(x=0, color='gray', linestyle='--', alpha=0.3)
    ax.grid(True, alpha=0.2)
    
    plt.tight_layout()
    
    if output_file:
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
        print(f"Plot saved to: {output_file}")
    
    import matplotlib
    if matplotlib.get_backend() != 'Agg':
        plt.show()
    
    if return_stats:
        return fig, plot_coords, stats
    else:
        return fig, plot_coords
        